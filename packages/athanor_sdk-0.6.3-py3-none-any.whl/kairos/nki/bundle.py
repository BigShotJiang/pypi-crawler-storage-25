"""kairos.nki.bundle — Pydantic ``Bundle`` manifest model + loader.

Per ATH-1100 Phase 1: defines the ``bundle.toml`` schema that becomes
the single source of truth for each NKI kernel bundle. Phases 2-5 of
ATH-1100 (cost_model / prover / testing / cert / cli) consume this
model — bundle authors write ``bundle.toml``, framework reads it,
everything else is generated.

Schema (see ``examples/customer/nki_attention_v3_online_demo/bundle.toml``
for the canonical example):

.. code-block:: toml

    [bundle]
    name = "attn_fwd_v3_online"
    description = "Online-softmax variant of attn_fwd_v3"
    kernel_lane = "decoder-attention"

    [bundle.kernel]
    algorithm_module = "algorithm"
    baseline_fn = "baseline_attention"
    improved_fn = "improved_attention"
    reference_fn = "reference_attention"
    nki_jit_baseline = "attn_fwd_v3_baseline"   # optional
    nki_jit_improved = "attn_fwd_v3_online"     # optional

    [bundle.lean]
    spec_file = "spec/AttnFwdV3Online.lean"
    theorems = ["softmax_shift_invariance", ...]
    pythia_citations = ["Pythia.Numerical.Softmax.softmax_shift_invariance", ...]

    [bundle.bound]
    formula_worst_case = "8 * tile_count * eps_fp32 * out_max"
    formula_av = "sqrt(2 * tile_count * log(2/alpha)) * eps_fp32 * out_max"
    alpha_default = 0.05

    [bundle.test]
    seqlen_sweep = [512, 1024, 2048, 4096]
    n_random_trials = 32
    d_head = 128
    shapes = ["basic_shape", "tiny_seqlen", ...]

    [bundle.prover_layers]
    enabled = ["lean", "z3", "simulator", "numpy_differential"]

Loading:

    >>> from kairos.nki import load_manifest
    >>> b = load_manifest("examples/customer/nki_attention_v3_online_demo/bundle.toml")
    >>> b.kernel.improved_fn
    'improved_attention'
    >>> b.bound.alpha_default
    0.05
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

if sys.version_info >= (3, 11):  # pragma: no cover
    import tomllib as _toml_loader
else:
    import tomli as _toml_loader  # type: ignore[no-redef]


class BundleManifestError(ValueError):
    """Raised when a ``bundle.toml`` is malformed or fails validation."""


class BundleKernel(BaseModel):
    """Kernel-implementation paths inside a bundle directory.

    All function names are looked up on the ``algorithm_module`` Python
    module at the bundle's path. The two ``nki_jit_*`` fields are
    optional — bundles that don't ship a ``@nki.jit`` kernel (e.g. SDK-
    dispatch-only bundles like GQA) leave them ``None``.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    algorithm_module: str = Field(
        ...,
        description="Python module name in the bundle dir holding the "
        "baseline/improved/reference functions.",
    )
    baseline_fn: str = Field(..., description="Numpy baseline function name.")
    improved_fn: str = Field(..., description="Numpy improved function name.")
    reference_fn: str = Field(..., description="FP64 reference function name.")
    nki_jit_baseline: str | None = Field(
        default=None,
        description="Optional ``@nki.jit`` baseline kernel function name.",
    )
    nki_jit_improved: str | None = Field(
        default=None,
        description="Optional ``@nki.jit`` improved kernel function name.",
    )


class BundleLean(BaseModel):
    """Lean spec + theorem-citation declarations for a bundle.

    ``theorems`` are the theorem names declared in ``spec_file``;
    ``pythia_citations`` are the fully-qualified Pythia paths each
    proof body cites (in the order matching ``theorems``). Future
    phases will compile-check that the citation paths resolve in the
    pinned Pythia revision.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    spec_file: str = Field(
        ...,
        description="Bundle-relative path to the Lean spec file "
        "(e.g. ``spec/AttnFwdV3Online.lean``).",
    )
    theorems: list[str] = Field(
        ...,
        min_length=1,
        description="Theorem names declared in spec_file.",
    )
    pythia_citations: list[str] = Field(
        default_factory=list,
        description="Fully-qualified Pythia paths the proof bodies cite. "
        "Same length as theorems when populated.",
    )

    @field_validator("pythia_citations")
    @classmethod
    def _citations_aligned_or_empty(cls, v: list[str]) -> list[str]:
        # Allow empty (proofs not yet wired) OR same length as theorems.
        # Cross-field validation against `theorems` is done in Bundle.
        return v


class BundleBound(BaseModel):
    """Numerical-error bound formulas for the bundle.

    Stored as **string** symbolic expressions (not evaluated here) so
    the cost-model + Z3 + Lean layers can re-parse the same canonical
    form. The framework's bound-evaluator (Phase 2) compiles these to
    a callable for ``proven_error_bound()`` / ``av_error_bound()`` use.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    formula_worst_case: str = Field(
        ...,
        description='Symbolic worst-case bound, e.g. '
        '"8 * tile_count * eps_fp32 * out_max".',
    )
    formula_av: str | None = Field(
        default=None,
        description='Optional anytime-valid bound, e.g. '
        '"sqrt(2 * tile_count * log(2/alpha)) * eps_fp32 * out_max".',
    )
    alpha_default: float = Field(
        default=0.05,
        gt=0.0,
        lt=1.0,
        description="Default α for AV bound (used by verify scaffold).",
    )


class BundleTest(BaseModel):
    """Test-shape declarations for the bundle's verify scaffold.

    ``shapes`` are well-known test-class identifiers (``basic_shape``,
    ``tiny_seqlen``, ``one_tile_boundary``, ``memory_savings``, etc.)
    that the shared :mod:`kairos.nki.testing` runner knows how to
    dispatch. Custom test classes can be added via the ``algorithm_module``.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    seqlen_sweep: list[int] = Field(
        ...,
        min_length=1,
        description="Sequence lengths to sweep in the verify runner.",
    )
    n_random_trials: int = Field(
        default=32,
        ge=1,
        description="Number of random Gaussian-input trials per shape.",
    )
    d_head: int = Field(
        default=128,
        ge=1,
        description="Head dimension. Defaults to PARTITION_SIZE.",
    )
    shapes: list[str] = Field(
        default_factory=lambda: ["basic_shape"],
        min_length=1,
        description="Test-class identifiers.",
    )


class BundleProverLayers(BaseModel):
    """Which prover layers from :mod:`kairos.nki.prover` to apply.

    Each layer is a registered :class:`ProverAdapter` (Phase 3). The
    bundle declares which layers are enabled; the verify-runner
    dispatches them in order, collecting verdicts. Adding a new prover
    technology is a single new adapter file under
    ``src/kairos/nki/prover/`` plus appending its name here.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    enabled: list[str] = Field(
        default_factory=lambda: ["numpy_differential"],
        min_length=1,
        description='Prover-layer names. Known: "lean", "z3", "ebmc", '
        '"acl2", "simulator", "numpy_differential".',
    )


class Bundle(BaseModel):
    """Top-level bundle manifest. Loaded from ``bundle.toml`` via
    :func:`load_manifest`.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str = Field(
        ...,
        min_length=1,
        description='Bundle name; e.g. "attn_fwd_v3_online".',
    )
    description: str = Field(..., min_length=1)
    kernel_lane: str = Field(
        default="generic",
        description='Customer-facing lane label (e.g. "decoder-attention").',
    )

    kernel: BundleKernel
    lean: BundleLean
    bound: BundleBound
    test: BundleTest
    prover_layers: BundleProverLayers = Field(default_factory=BundleProverLayers)

    @field_validator("name")
    @classmethod
    def _name_kebab_or_snake(cls, v: str) -> str:
        # Bundle names are used as filesystem paths + as fully-qualified
        # identifiers downstream — restrict to safe identifier chars.
        if not all(c.isalnum() or c in "_-" for c in v):
            raise BundleManifestError(
                f"bundle.name must be alphanumeric / underscore / hyphen; got {v!r}"
            )
        return v


def _validate_lean_alignment(bundle: Bundle) -> None:
    """Cross-field check: pythia_citations is empty OR same length as theorems."""
    pc = bundle.lean.pythia_citations
    if pc and len(pc) != len(bundle.lean.theorems):
        raise BundleManifestError(
            f"bundle.lean.pythia_citations length ({len(pc)}) must equal "
            f"bundle.lean.theorems length ({len(bundle.lean.theorems)}) "
            f"or be empty (proofs not yet wired)."
        )


def load_manifest(path: str | Path) -> Bundle:
    """Parse and validate ``bundle.toml`` at ``path``.

    Args:
        path: Filesystem path to the ``bundle.toml`` file.

    Returns:
        Validated :class:`Bundle` model.

    Raises:
        BundleManifestError: On any TOML parse failure, schema validation
            failure, or cross-field validation failure. The Pydantic
            ``ValidationError`` message is wrapped for a single error
            class boundary.
        FileNotFoundError: If ``path`` does not exist.

    Example:
        >>> from kairos.nki import load_manifest
        >>> b = load_manifest("examples/customer/nki_attention_v3_online_demo/bundle.toml")
        >>> b.name
        'attn_fwd_v3_online'
        >>> b.prover_layers.enabled
        ['lean', 'z3', 'simulator', 'numpy_differential']
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"bundle manifest not found: {path}")

    try:
        with path.open("rb") as f:
            raw: dict[str, Any] = _toml_loader.load(f)
    except _toml_loader.TOMLDecodeError as e:
        raise BundleManifestError(f"invalid TOML in {path}: {e}") from e

    # Top-level can be either {"bundle": {...}} (one canonical shape) or
    # the bundle fields hoisted to the top. We accept both for ergonomic
    # reasons but normalize to the nested shape.
    if "bundle" in raw and isinstance(raw["bundle"], dict):
        # tomli flattens [bundle.kernel] into raw["bundle"]["kernel"], so
        # the [bundle] table itself contains the top-level fields plus
        # nested sub-models. Lift the nested ones up.
        bundle_data = dict(raw["bundle"])
    else:
        bundle_data = dict(raw)

    try:
        bundle = Bundle(**bundle_data)
    except Exception as e:  # pydantic ValidationError or our own
        raise BundleManifestError(
            f"bundle.toml schema validation failed in {path}:\n  {e}"
        ) from e

    _validate_lean_alignment(bundle)
    return bundle
