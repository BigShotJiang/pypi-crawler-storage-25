"""Per-kernel-class sweep generators for kairos.nki.lean_extractor.

The base extractor's gate-1 takes a flat ``tile_sizes`` list and samples
1-D tile pairs uniformly. Real NKI kernels live in structured tile-PSUM
shapes: matmul has (M,K)×(K,N), attention has (head_dim×seq) tuples per
Q/K/V, normalisations have (channel,) plus per-channel scale/bias. A
single 1-D sweep can't exercise the tile-decomposition correctness that
those kernels actually claim.

This module provides a *generator registry* keyed by kernel class. Each
generator yields a list of ``KernelInputs`` tuples — opaque payload for
the LLM-proposed kernel and the customer reference, which both must
accept the same shape. The extractor's gate-1 harness adapts to the
generator's output instead of hardcoding 1-D random floats.

Designed to evolve: today's matmul generator is a uniform random sweep;
the FP8/quantization integration (asabi Pythia.NumericalAnalysis) will
replace it with rounding-mode-aware generators that target boundary
cases (subnormals, smallest-fp8-step, accumulator overflow). The
contract is the same — emit a list of input tuples — so the LLM proposer
and the harness don't change when a class gains a smarter generator.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Callable, Sequence


@dataclass(frozen=True)
class KernelInputs:
    """One sample for the gate-1 differential test.

    ``args`` is passed to both ``kernel(*args)`` and ``reference(*args)``.
    The harness checks numerical equivalence between the two outputs.
    ``shape_label`` is a short human-readable tag for failure messages
    (e.g. ``"M=8,K=64,N=16"``).
    """

    args: tuple
    shape_label: str


# Generator signature: (seed, n_trials) -> list[KernelInputs].
GeneratorFn = Callable[[int, int], list[KernelInputs]]


_REGISTRY: dict[str, GeneratorFn] = {}


def register(kernel_class: str, fn: GeneratorFn) -> None:
    """Register a generator for one kernel class.

    Repeated registrations overwrite. The catalog ships a default set
    and customer sessions can override per their own NKI patterns.
    """
    _REGISTRY[kernel_class] = fn


def get(kernel_class: str) -> GeneratorFn:
    """Look up a generator. Raises ``KeyError`` for unknown classes —
    the caller picks the kernel-class explicitly so a typo surfaces
    early rather than silently using a wrong-shape sweep."""
    if kernel_class not in _REGISTRY:
        known = ", ".join(sorted(_REGISTRY)) or "(none)"
        raise KeyError(
            f"unknown kernel_class={kernel_class!r}; registered: {known}"
        )
    return _REGISTRY[kernel_class]


def known_classes() -> list[str]:
    return sorted(_REGISTRY)


# ── Default generators ───────────────────────────────────────────────


def _gen_elementwise(seed: int, n_trials: int) -> list[KernelInputs]:
    """1-D tile pairs. Element-wise add / mul / sub. Uniform [-1,1]."""
    rng = random.Random(seed)
    sizes = (4, 16, 64, 256)
    out: list[KernelInputs] = []
    for _ in range(n_trials):
        n = rng.choice(sizes)
        a = [rng.uniform(-1.0, 1.0) for _ in range(n)]
        b = [rng.uniform(-1.0, 1.0) for _ in range(n)]
        out.append(KernelInputs(args=(a, b), shape_label=f"n={n}"))
    return out


def _gen_matmul(seed: int, n_trials: int) -> list[KernelInputs]:
    """(M, K) × (K, N) matmul tile-PSUM shapes.

    K is the partition dim (NKI's PARTITION_SIZE = 128 is the canonical
    Trainium constraint). We sample K from {32, 64, 128} to exercise
    both within-partition and crossing-partition tile patterns. M and
    N are smaller to keep the sweep cheap.
    """
    rng = random.Random(seed)
    out: list[KernelInputs] = []
    for _ in range(n_trials):
        m = rng.choice((4, 8, 16))
        k = rng.choice((32, 64, 128))
        n = rng.choice((4, 8, 16))
        a = [[rng.uniform(-1.0, 1.0) for _ in range(k)] for _ in range(m)]
        b = [[rng.uniform(-1.0, 1.0) for _ in range(n)] for _ in range(k)]
        out.append(KernelInputs(args=(a, b), shape_label=f"M={m},K={k},N={n}"))
    return out


def _gen_norm(seed: int, n_trials: int) -> list[KernelInputs]:
    """Per-channel norm: (n,) input, scalar epsilon, and an output
    of the same shape. Caller's reference and proposed kernel both
    take ``(x, epsilon)`` and return a list of length n."""
    rng = random.Random(seed)
    out: list[KernelInputs] = []
    for _ in range(n_trials):
        n = rng.choice((16, 64, 256, 1024))
        x = [rng.uniform(-1.0, 1.0) for _ in range(n)]
        eps = rng.choice((1e-5, 1e-6, 1e-8))
        out.append(KernelInputs(args=(x, eps), shape_label=f"n={n},eps={eps:.1e}"))
    return out


def _gen_attention(seed: int, n_trials: int) -> list[KernelInputs]:
    """Q/K/V attention tile shapes: each is (seq, head_dim).

    Sample head_dim from {32, 64, 128} (typical attention head sizes
    on Trainium) and seq from {16, 32, 64} to keep the sweep cheap.
    Caller's reference and proposed kernel both take ``(Q, K, V)``."""
    rng = random.Random(seed)
    out: list[KernelInputs] = []
    for _ in range(n_trials):
        seq = rng.choice((16, 32, 64))
        head = rng.choice((32, 64, 128))
        q = [[rng.uniform(-1.0, 1.0) for _ in range(head)] for _ in range(seq)]
        k = [[rng.uniform(-1.0, 1.0) for _ in range(head)] for _ in range(seq)]
        v = [[rng.uniform(-1.0, 1.0) for _ in range(head)] for _ in range(seq)]
        out.append(
            KernelInputs(args=(q, k, v), shape_label=f"seq={seq},head={head}")
        )
    return out


# ── FP8-aware generators ─────────────────────────────────────────────
#
# These target numerical-correctness boundary cases that uniform-random
# sweeps miss. The integration with asabi's Pythia.NumericalAnalysis
# (when it ships) replaces the manual sample tables here with primitive-
# derived bounds — but the registry contract stays the same, so existing
# callers don't change.
#
# FP8 reference: E4M3 has 4-bit exponent + 3-bit mantissa, no infinity.
# Max representable ≈ 448, smallest normal ≈ 2^-6 ≈ 0.0156, smallest
# subnormal ≈ 2^-9 ≈ 0.00195. E5M2 (5+2) has Max ≈ 57344 and supports
# infinity. The boundary samples below cover both formats' interesting
# values without binding to a specific format choice.


_FP8_BOUNDARY_VALUES = (
    # E4M3 smallest subnormal range — underflow pathway
    1.95e-3,
    -1.95e-3,
    # E4M3 smallest normal — boundary between subnormal and normal
    1.56e-2,
    -1.56e-2,
    # E4M3 max — overflow pathway when summing positives
    448.0,
    -448.0,
    # Mid-range — no edge effects, baseline
    1.0,
    -1.0,
    0.5,
    # Zeros — sign-of-zero behaviour
    0.0,
    -0.0,
    # Mantissa-grid boundary near 1: smallest E4M3 step at exp=0 is
    # 1/8 ≈ 0.125, so 1 + 0.125 should be representable but
    # 1 + 0.0625 would round to 1 (or 1.125 depending on rounding mode)
    1.125,
    1.0625,
)


def _gen_fp8_elementwise(seed: int, n_trials: int) -> list[KernelInputs]:
    """Element-wise sweep biased toward FP8 boundary values.

    Half the trials use uniform random in [-1, 1], half mix in values
    sampled from `_FP8_BOUNDARY_VALUES` to exercise underflow/overflow/
    rounding-grid pathways. A correctness contract that holds across
    this distribution generalises better to FP8 quantization than
    uniform-random alone.
    """
    rng = random.Random(seed)
    out: list[KernelInputs] = []
    for trial in range(n_trials):
        n = rng.choice((4, 16, 64))
        if trial % 2 == 0:
            a = [rng.uniform(-1.0, 1.0) for _ in range(n)]
            b = [rng.uniform(-1.0, 1.0) for _ in range(n)]
            label = f"n={n}"
        else:
            a = [rng.choice(_FP8_BOUNDARY_VALUES) for _ in range(n)]
            b = [rng.choice(_FP8_BOUNDARY_VALUES) for _ in range(n)]
            label = f"n={n},boundary"
        out.append(KernelInputs(args=(a, b), shape_label=label))
    return out


def _gen_fp8_matmul(seed: int, n_trials: int) -> list[KernelInputs]:
    """Matmul sweep biased toward FP8 accumulator-overflow boundary.

    The matmul accumulator is the canonical FP8 correctness concern:
    a sum of many small products can overflow the FP8 range even when
    each individual product fits. Half the trials sample from a normal
    [-1, 1] range; half mix in boundary values that, when summed across
    the K dimension, can overflow if the kernel is single-precision-FP8
    accumulator-only (instead of FP32-accumulator with FP8 inputs as
    the spec requires).
    """
    rng = random.Random(seed)
    out: list[KernelInputs] = []
    for trial in range(n_trials):
        m = rng.choice((4, 8))
        k = rng.choice((32, 64, 128))
        n = rng.choice((4, 8))
        if trial % 2 == 0:
            a = [
                [rng.uniform(-1.0, 1.0) for _ in range(k)] for _ in range(m)
            ]
            b = [
                [rng.uniform(-1.0, 1.0) for _ in range(n)] for _ in range(k)
            ]
            label = f"M={m},K={k},N={n}"
        else:
            a = [
                [rng.choice(_FP8_BOUNDARY_VALUES) for _ in range(k)]
                for _ in range(m)
            ]
            b = [
                [rng.choice(_FP8_BOUNDARY_VALUES) for _ in range(n)]
                for _ in range(k)
            ]
            label = f"M={m},K={k},N={n},boundary"
        out.append(KernelInputs(args=(a, b), shape_label=label))
    return out


register("elementwise", _gen_elementwise)
register("matmul", _gen_matmul)
register("norm", _gen_norm)
register("attention", _gen_attention)
register("fp8_elementwise", _gen_fp8_elementwise)
register("fp8_matmul", _gen_fp8_matmul)


__all__ = [
    "KernelInputs",
    "GeneratorFn",
    "register",
    "get",
    "known_classes",
]
