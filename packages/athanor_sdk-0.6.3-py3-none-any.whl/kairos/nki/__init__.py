"""kairos.nki — NKI kernel catalog adapter (Bet A — ATH-890 follow-up).

Bridges the existing :class:`kairos.verticals.neuron_nki.NeuronNKIPlugin`
verifier to the SDK's tracing surface so catalog-production runs from
``athanor-builder/solve/neuron/run.sh`` show up on the tahoe Verification
Coverage card. Without this bridge, the foundry orchestrator produces
real verification artifacts but the NKI counter on /analytics stays at
zero — bundles are verified in-place but never emit a ``solve_runs``
row tagged with ``vertical=neuron_nki``.

Public surface
--------------

* :func:`run_bundle` — open an :func:`kairos.observe.observe` session,
  invoke ``NeuronNKIPlugin.verify`` on the bundle, emit a single
  ``nki_kernel_verified`` trace event with the verdict + bundle summary
  payload, and return the ``run_id`` so callers can link to
  ``/analytics/runs/<run_id>``.

Run-subtype convention
----------------------

Trace events emit under ``run_subtype="theorem_proving"`` to match the
existing customer-block-certificate flow (see
``examples/customer/toy_fifo_chain/demo_driver.py``). NKI kernel
verification doesn't *prove theorems* in the strict Lean sense, but the
``theorem_proving`` subtype is the one the dashboard surfaces as
"verification" runs and is the same lane the silicon-blocks card
uses — keeping the two flows on the same subtype lets the Verification
Coverage card aggregate cleanly across both.

Why this is in ``kairos.nki`` and not ``kairos.verticals.neuron_nki``
--------------------------------------------------------------------

``kairos.verticals.neuron_nki`` is the ``VerifierPlugin`` that the
``built-in pipeline`` dispatches to when intent calls for kernel-port
verification. ``kairos.nki`` is the customer-facing catalog adapter:
intended to be called directly by the foundry pipeline + by the
``nki_verify`` MCP tool's "with phone-home" variant. Keeping them
separate avoids loading the trace-sink machinery in the plugin's hot
path (where it's used per-task during pipeline dispatch and we don't
want a new ``solve_runs`` row per task).
"""
from __future__ import annotations

from kairos.nki._adapter import RunBundleResult, run_bundle
from kairos.nki.bundle import (
    Bundle,
    BundleBound,
    BundleKernel,
    BundleLean,
    BundleProverLayers,
    BundleTest,
    BundleManifestError,
    load_manifest,
)

# Public surface:
#   * run_bundle / RunBundleResult — Bet A catalog adapter (existing,
#     pre-ATH-1100). Bridges NeuronNKIPlugin.verify to the trace sink.
#   * Bundle / load_manifest / Bundle* sub-models — ATH-1100 Phase 1.
#     Manifest-driven bundle protocol; consumed by future
#     ``kairos.nki.cost_model``, ``kairos.nki.prover``,
#     ``kairos.nki.testing``, ``kairos.nki.cert`` modules.
__all__ = [
    "run_bundle",
    "RunBundleResult",
    "Bundle",
    "BundleBound",
    "BundleKernel",
    "BundleLean",
    "BundleProverLayers",
    "BundleTest",
    "BundleManifestError",
    "load_manifest",
]
