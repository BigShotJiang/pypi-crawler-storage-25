"""kairos.nki._adapter — implementation of :func:`run_bundle`.

Split out from ``kairos.nki/__init__.py`` so the public surface stays
small + the implementation is testable without going through re-export.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from kairos.trace import TraceSink
from kairos.verticals.neuron_nki import NeuronNKIPlugin


@dataclass(frozen=True)
class RunBundleResult:
    """Outcome of :func:`run_bundle`.

    The ``run_id`` is the ``solve_runs`` primary key the catalog can
    point customers at via ``https://tahoe.athanor-ai.com/analytics/
    runs/<run_id>``. The ``verdict_outcome`` mirrors the underlying
    :class:`Verdict.outcome` so callers can branch without re-parsing
    the verdict dict.
    """

    run_id: str
    verdict_outcome: str
    verdict_source: str
    verdict_reason: str
    verdict_details: dict[str, Any]


def _kernel_name_from_bundle(bundle: Path) -> str:
    """Derive a kernel name from the bundle directory.

    Catalog convention is ``solve/neuron/catalog/<date>/<kernel>/``,
    so the bundle's directory name is the kernel slug.
    """
    return bundle.name


def _summary_payload(
    *,
    bundle_path: Path,
    kernel_name: str,
    verdict_outcome: str,
    verdict_source: str,
    verdict_reason: str,
    verdict_details: dict[str, Any],
) -> dict[str, Any]:
    """Build the payload for the ``nki_kernel_verified`` trace event.

    Keep it small: the verdict already carries the per-report flags
    in ``details.reports_pass``; payload-side we add the bundle path
    + kernel name + the verdict triple so the dashboard renderer can
    show "Kernel <name>: <outcome>" without round-tripping to the
    bundle directory.
    """
    return {
        "kernel_name": kernel_name,
        "bundle_path": str(bundle_path),
        "verdict": {
            "outcome": verdict_outcome,
            "source": verdict_source,
            "reason": verdict_reason,
        },
        "reports_pass": dict(verdict_details.get("reports_pass") or {}),
        "exit_code": verdict_details.get("exit_code"),
    }


def run_bundle(
    bundle_path: str | Path,
    *,
    kernel_name: str | None = None,
    timeout_sec: int = 300,
    sink: TraceSink | None = None,
    organization_id: str | None = None,
) -> RunBundleResult:
    """Verify an NKI kernel bundle with full trace emission.

    Opens an :func:`kairos.observe.observe` session, runs
    :meth:`NeuronNKIPlugin.verify` on the bundle, emits a single
    ``nki_kernel_verified`` event, and returns a
    :class:`RunBundleResult` carrying the ``run_id`` + verdict triple.

    :param bundle_path: Absolute or cwd-relative directory containing
        ``verify.py`` + ``kernel.py`` + optionally ``reports/*.json``.
    :param kernel_name: Stable kernel slug for trace ``task_id``. If
        ``None`` the bundle directory name is used.
    :param timeout_sec: Wall-clock timeout for ``verify.py``. Forwarded
        to :meth:`NeuronNKIPlugin.verify`.
    :param sink: Optional :class:`TraceSink` override. Defaults to
        ``default_sink_from_env`` (Supabase when ``ATHANOR_SYNC_TOKEN``
        is set, NoopTraceSink otherwise — matches the demo driver's
        zero-phone-home posture for offline / dev runs).
    :param organization_id: ATH-1236 — explicit customer org UUID stamped
        on the parent ``solve_runs`` row. When set, forwarded through
        ``observe(organization_id=...)`` to ``sink.open_run`` so the
        recorded row is tagged with the caller's customer org rather
        than falling through the env/license/sync-token waterfall to
        the host-VM ambient org. Customers running ``run_bundle`` on
        their own infra should pass their own org UUID; ``None``
        (default) preserves pre-ATH-1236 behavior (env/license/token
        resolution). Per ATH-1234 root-cause analysis: customer-B
        invocations without explicit org_id previously mis-attributed
        to internal-fleet org because run_bundle didn't propagate
        org_id, breaking customer-corpus filtering.

    :returns: :class:`RunBundleResult` with ``run_id``, ``verdict_outcome``,
        ``verdict_source``, ``verdict_reason``, ``verdict_details``.

    :raises FileNotFoundError: When the bundle directory doesn't exist.
        Validation of bundle contents (verify.py/kernel.py) happens
        inside the plugin and surfaces as ``verdict_outcome="error"``
        rather than raising — callers branch on outcome, not on
        exceptions.
    """
    bundle = Path(bundle_path)
    if not bundle.is_dir():
        raise FileNotFoundError(
            f"NKI bundle directory not found: {bundle!s}. "
            "Pass an absolute or cwd-relative path to a directory "
            "containing verify.py + kernel.py."
        )

    resolved_kernel_name = kernel_name or _kernel_name_from_bundle(bundle)

    # ``kairos/__init__.py`` rebinds ``kairos.observe`` to the
    # ``observe`` function (so ``import kairos.observe; kairos.observe``
    # is the function, not the module). Use ``sys.modules`` to get the
    # actual module so we can call its ``emit``. Same gotcha the demo
    # driver hits — keep the workaround inline so a refactor of
    # ``kairos/__init__.py`` will also have to revisit this site.
    import kairos.observe  # noqa: F401 — force-load the module
    obs = sys.modules["kairos.observe"]

    if sink is None:
        from kairos.trace import default_sink_from_env
        sink = default_sink_from_env()

    plugin = NeuronNKIPlugin()

    with obs.observe(
        sink=sink,
        run_subtype="theorem_proving",
        task_id=resolved_kernel_name,
        vertical="neuron_nki",
        organization_id=organization_id,  # ATH-1236
    ) as ctx:
        verdict = plugin.verify(
            intent={"target": {"file": str(bundle)}},
            witness={"bundle_path": str(bundle)},
            timeout_sec=float(timeout_sec),
        )

        verdict_details = dict(verdict.details or {})
        payload = _summary_payload(
            bundle_path=bundle,
            kernel_name=resolved_kernel_name,
            verdict_outcome=verdict.outcome,
            verdict_source=verdict.source,
            verdict_reason=verdict.reason or "",
            verdict_details=verdict_details,
        )
        obs.emit(
            "nki_kernel_verified",
            payload,
            run_subtype="theorem_proving",
            silent_if_no_session=False,
        )

        return RunBundleResult(
            run_id=ctx.run_id,
            verdict_outcome=verdict.outcome,
            verdict_source=verdict.source,
            verdict_reason=verdict.reason or "",
            verdict_details=verdict_details,
        )
