"""Generic swarm sweep over a list of Lean ``sorry`` targets.

This is the customer-facing primitive that composes the three SDK
building-blocks under one entry-point so callers don't have to wire
:func:`kairos.lean_cycle.cycle_prove` + :class:`kairos.fleet.FleetOrchestrator`
+ :func:`kairos.observe.observe` themselves.

Design constraints (Aidan, 2026-04-27):

* **No hardcoded agents.** The SDK ships zero defaults for which
  models to fan out to — :class:`SorrySwarmConfig` requires the caller
  to supply the drafter list. Internal users (research, qa) and
  external customers all parameterize the same way.
* **Generic.** The same module powers both Pythia's internal sorry
  sweep and any customer running ``kairos.sorry_swarm`` against their
  own Lean project. Pythia-specific tooling (``tools/sorry_swarm.py``
  in the pythia repo) is a thin wrapper over this primitive.
* **Configurable guardrails.** Cost cap, smoke-gate thresholds, and
  axiom-audit policy are all caller-supplied with sensible defaults;
  no policy is baked in.

Composition flow per call:

#. For each target in ``targets``, :class:`FleetOrchestrator` fans
   out to every drafter in parallel.
#. Each drafter runs :func:`cycle_prove` (draft → verify → refine).
#. The whole sweep runs inside a :func:`kairos.observe.observe`
   session (ATH-1236 migration from the older
   ``litellm_trace_session`` wrapper, which only captured litellm
   calls AND never opened a parent ``solve_runs`` row) so every
   per-attempt event flows through ``sdk_agent_events`` (and the
   dashboard renders the conversation thread per ATH-800 + the
   per-attempt chips per ATH-805 + a visible parent run per ATH-1236).
#. Each closure passes through ``config.axiom_audit``; only
   axiom-clean closures count as ``closed_clean``.
#. The sweep enforces a smoke gate at ``config.smoke_size``: when
   the smoke set produces fewer than ``config.smoke_min_closures``
   axiom-clean closures, the sweep aborts before scaling.
#. The sweep tracks ``total_cost_usd`` across every drafter call;
   when the cap is reached, dispatch of the next target halts
   (in-flight targets always run to completion).

The output is a :class:`SorrySwarmResult` aggregating per-target
outcomes + sweep-level counts + an abort reason when one fired.
"""
from __future__ import annotations

import logging
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from kairos.fleet.fleet_orchestrator import FleetOrchestrator, FleetRunSummary
from kairos.lean_cycle import CycleResult, CycleTarget
from kairos.observe import observe


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Defaults — exposed so customers can extend them rather than redefine.
# ---------------------------------------------------------------------------

#: Lean's three foundational axioms. A theorem that uses only these is
#: "axiom-clean" by Mathlib's standard. Customers committed to a
#: stricter universe pass an empty allowlist; customers willing to
#: tolerate user-defined axioms pass a wider allowlist.
PYTHIA_DEFAULT_AXIOM_ALLOWLIST: frozenset[str] = frozenset({
    "propext",
    "Classical.choice",
    "Quot.sound",
})


# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SorrySwarmConfig:
    """Caller-supplied configuration for one swarm sweep.

    No field defaults pick a model on the customer's behalf —
    ``drafters`` is required. The other fields default to values
    suitable for an internal Pythia-style sweep but every one is
    overridable.

    Attributes:
        drafters: List of drafter handles. Each must satisfy the
            :class:`kairos.fleet.fleet_orchestrator._DrafterProtocol`
            shape (``.alias: str`` + ``.cycle_prove(target, **kwargs)``).
            The SDK ships no defaults; the caller decides which
            models to fan out to.
        cost_cap_usd: Hard cap on total LLM spend across the whole
            sweep. Dispatch of the next target halts when total
            cost exceeds this; in-flight targets run to completion.
            Default 200.0 (matches the cto-handoff guardrail for
            the internal Pythia sweep).
        smoke_size: First N targets are the smoke gate. When N targets
            have completed and fewer than ``smoke_min_closures`` are
            axiom-clean, the sweep aborts. Set to 0 to disable smoke
            gating. Default 5.
        smoke_min_closures: Minimum axiom-clean closures across the
            smoke set required to scale to the rest. Default 1.
        axiom_audit: Per-closure audit predicate. Signature
            ``(target, candidate_text) -> list[str]``; returns the
            list of forbidden axioms used (empty = clean). When None,
            uses :func:`default_axiom_audit` against
            :data:`PYTHIA_DEFAULT_AXIOM_ALLOWLIST`. Customers can
            replace with a stricter or looser policy or with a
            transitive ``#print axioms`` audit that runs Lake.
        max_rounds_per_target: Forwarded to :func:`cycle_prove`.
        on_target_done: Optional streaming callback fired after each
            target's swarm fan-out completes. Args: ``(target_id,
            summary, forbidden_axioms_used)``. Useful for posting
            per-target progress to a TUI / Slack / progress bar.
        preflight: Forwarded to :meth:`FleetOrchestrator.run`. When
            True (default), the orchestrator runs
            ``kairos.preflight.fleet_gate`` against host-side keys
            BEFORE the swarm fan-out — catches a broken adapter or
            stale lake project on call 1 instead of after the loop
            has burned customer money. Set to False when the wrapper
            has its own preflight or when preflight is genuinely
            unwanted (e.g. local-only sandbox runs).
        preflight_lake_project: Override the target's
            ``lake_project`` for the preflight verify round-trip.
            Useful when targets across the sweep share a common
            project root (e.g. all Pythia targets) and you'd rather
            preflight once against that root than per-target.
        preflight_module_path: Override the synthesized
            ``<scratch_namespace>.PreflightSmoke`` module path
            used by the preflight. Required when the target's
            scratch namespace doesn't actually exist in the lake
            project (research's compose-test 2026-04-27 hit
            preflight failures because the placeholder namespace
            wasn't a real module).
    """

    drafters: list[Any]
    cost_cap_usd: float = 200.0
    smoke_size: int = 5
    smoke_min_closures: int = 1
    axiom_audit: Optional[Callable[[CycleTarget, str], list[str]]] = None
    max_rounds_per_target: int = 4
    on_target_done: Optional[Callable[[str, FleetRunSummary, list[str]], None]] = None
    preflight: bool = True
    preflight_lake_project: Optional[str] = None
    preflight_module_path: Optional[str] = None


@dataclass
class TargetOutcome:
    """Per-target result from a sweep: fleet summary + audit verdict.

    The ``axiom_clean`` flag is the source-of-truth for "this counts
    as a closure" — a closed proof that uses a non-allowlisted axiom
    is ``closed=True`` but ``axiom_clean=False`` and is reported
    separately in :class:`SorrySwarmResult`.
    """

    target_id: str
    summary: FleetRunSummary
    closed: bool
    axiom_clean: bool
    forbidden_axioms: list[str] = field(default_factory=list)
    closing_alias: Optional[str] = None
    closing_candidate: Optional[str] = None


@dataclass
class SorrySwarmResult:
    """Aggregate result of a full sweep.

    The four count attributes always satisfy:
    ``targets_attempted == targets_closed_clean + targets_closed_dirty
    + targets_failed``. ``aborted=True`` indicates the sweep stopped
    before all input targets were dispatched (cost cap or smoke gate);
    in that case ``targets_attempted < len(targets)`` for the input.
    """

    targets_attempted: int
    targets_closed_clean: int
    targets_closed_dirty: int
    targets_failed: int
    total_cost_usd: float
    total_wall_sec: float
    per_target: list[TargetOutcome]
    aborted: bool
    abort_reason: Optional[str]
    session_id: str

    def summarize(self) -> str:
        """Human-readable one-screen summary suitable for a CLI."""
        lines = [
            f"sorry_swarm: {self.targets_closed_clean}/{self.targets_attempted} "
            f"axiom-clean closures · ${self.total_cost_usd:.2f} · "
            f"{self.total_wall_sec:.1f}s",
        ]
        if self.targets_closed_dirty > 0:
            lines.append(
                f"  ⚠ {self.targets_closed_dirty} closed but axiom-impure "
                f"(used non-allowlisted axioms — see per_target)"
            )
        if self.targets_failed > 0:
            lines.append(f"  ✗ {self.targets_failed} not closed by any drafter")
        if self.aborted:
            lines.append(f"  ⛔ aborted: {self.abort_reason}")
        lines.append(f"  session_id: {self.session_id}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Default axiom audit
# ---------------------------------------------------------------------------


def default_axiom_audit(
    allowlist: frozenset[str] = PYTHIA_DEFAULT_AXIOM_ALLOWLIST,
) -> Callable[[CycleTarget, str], list[str]]:
    """Build an axiom-audit predicate that allowlists a fixed set.

    The returned callable scans the candidate text for ``axiom NAME``
    declarations and returns the list of declared axiom names that
    fall outside ``allowlist``. Empty list means clean.

    **This is a syntactic check on the candidate body only.** It
    catches the obvious failure mode (a drafter that just declares
    ``axiom foo : MyTheorem`` and uses it). It does NOT do a
    transitive ``#print axioms`` check against Lake-built theorems
    — for that, supply a custom predicate that runs
    ``lake env lean -e "#print axioms <name>"`` and parses the output.

    Args:
        allowlist: axiom names that are permitted. Names outside the
            set are reported as forbidden. Default is the Pythia /
            Mathlib trio (``propext``, ``Classical.choice``,
            ``Quot.sound``).

    Returns:
        A callable matching the ``axiom_audit`` signature on
        :class:`SorrySwarmConfig`.
    """
    # Axiom declarations have the shape:
    #   [private|protected]? axiom NAME [{IMPLICITS}] [(EXPLICITS)] : TYPE
    # NAME may be a dotted path (`Classical.choice`, `MyNs.MyAxiom`) so
    # the capture group accepts \w + dot. Multi-line so each declaration
    # is matched at its anchor point in the candidate body.
    #
    # Lean comments come in three forms — `--` line comments, `/-` block
    # comments, `/-! ... -/` doc-block. We pre-strip those before scanning
    # so a candidate that contains `-- axiom foo : True` in a comment
    # doesn't false-positive.
    decl_re = re.compile(
        r"^\s*(?:private\s+|protected\s+)?axiom\s+([\w.]+)",
        re.MULTILINE,
    )
    # Strip line comments (`--` to end-of-line) and block comments
    # (`/- ... -/` including `/-! ... -/` doc blocks). Block comments
    # nest in Lean; we don't try to handle nesting and accept the very
    # rare false-positive that a nested `/-` cancels stripping early.
    line_comment_re = re.compile(r"--[^\n]*")
    block_comment_re = re.compile(r"/-.*?-/", re.DOTALL)

    def _audit(_target: CycleTarget, candidate: str) -> list[str]:
        # Strip comments first so axiom-shaped strings inside them
        # don't trigger the audit. Order matters: block comments may
        # contain `--` which we don't want to consume early.
        cleaned = block_comment_re.sub("", candidate)
        cleaned = line_comment_re.sub("", cleaned)
        forbidden: list[str] = []
        for m in decl_re.finditer(cleaned):
            name = m.group(1)
            if name not in allowlist:
                forbidden.append(name)
        return forbidden

    return _audit


# ---------------------------------------------------------------------------
# Main entry-point
# ---------------------------------------------------------------------------


def sorry_swarm(
    targets: list[CycleTarget],
    config: SorrySwarmConfig,
    *,
    session_id: Optional[str] = None,
    organization_id: Optional[str] = None,
) -> SorrySwarmResult:
    """Run a swarm sweep over a list of Lean ``sorry`` targets.

    This is the entry-point internal users + customers call. Behavior
    is fully driven by ``config``; the SDK contributes the composition
    of cycle_prove + FleetOrchestrator + observe but no policy.

    Args:
        targets: list of :class:`CycleTarget` — one per ``sorry`` to
            close. Caller is responsible for discovery (typically by
            scanning a Lake project).
        config: caller-supplied :class:`SorrySwarmConfig`. Must carry
            at least one drafter.
        session_id: optional explicit session ID for the trace
            session. Defaults to a UUID-prefixed
            ``sorry-swarm-<8-hex>`` slug.
        organization_id: ATH-1236 — explicit customer org UUID stamped
            on the parent ``solve_runs`` row opened by the internal
            ``observe()`` session this function holds open for the
            sweep. When set, forwarded to ``observe(organization_id=...)``
            so the recorded row is tagged with the caller's customer
            org rather than falling through the env/license/sync-token
            waterfall to the host-VM ambient org. Customers running
            ``sorry_swarm`` on their own infra should pass their own
            org UUID; ``None`` (default) preserves pre-ATH-1236
            behavior (env/license/token waterfall). Mirror of the same
            kwarg on :func:`kairos.nki.run_bundle`,
            :func:`kairos.lean_orchestrate.race`, and
            :func:`kairos.lean_orchestrate.solve` — together they form
            the peer write-path propagation chain for customer-
            attribution. Note: pre-ATH-1236 sorry_swarm used the
            litellm-only ``litellm_trace_session`` wrapper which never
            opened a parent solve_runs row at all; this PR migrates it
            to the unified ``observe()`` wrapper (ATH-524 superset)
            both to wire ``organization_id`` AND to surface a parent
            row on the dashboard — direct customers no longer have a
            silent gap where ``sorry_swarm`` sweeps don't produce a
            visible run.

    Returns:
        :class:`SorrySwarmResult` aggregating per-target outcomes +
        sweep-level counts. On a graceful early halt
        (cost-cap / smoke-gate), ``aborted=True`` and
        ``abort_reason`` is populated.

    Raises:
        ValueError: ``config.drafters`` is empty (the SDK ships no
            defaults; the caller must provide drafters).
    """
    # Aidan 2026-04-27: swarm + agent orchestration is paid-tier only
    # ("too good to give out for free"). Same product gate as
    # ``Orchestrator``, ``prove``, ``sv.swarm``, etc.
    from kairos.license_scope import require_product
    require_product("solve")

    sweep_session_id = session_id or f"sorry-swarm-{uuid.uuid4().hex[:8]}"

    if not targets:
        return SorrySwarmResult(
            targets_attempted=0, targets_closed_clean=0,
            targets_closed_dirty=0, targets_failed=0,
            total_cost_usd=0.0, total_wall_sec=0.0,
            per_target=[], aborted=False, abort_reason=None,
            session_id=sweep_session_id,
        )

    if not config.drafters:
        raise ValueError(
            "sorry_swarm requires ≥1 drafter; SDK ships no defaults — "
            "the caller decides which models to fan out to"
        )

    audit = config.axiom_audit or default_axiom_audit()
    orchestrator = FleetOrchestrator(drafters=list(config.drafters))

    per_target: list[TargetOutcome] = []
    total_cost = 0.0
    total_wall = 0.0
    aborted = False
    abort_reason: Optional[str] = None
    smoke_gate_fired = False

    # ATH-1236: migrated from litellm_trace_session → observe() (ATH-524
    # superset captures both litellm + native Anthropic). The migration
    # has two effects: (1) sorry_swarm sweeps now produce a visible
    # parent solve_runs row on the dashboard (litellm_trace_session
    # never opened one), and (2) organization_id forwarding wires
    # through observe() → sink.open_run for customer-attribution.
    # spawn_reason = sorry_swarm_direct names the SDK boundary the
    # customer crossed. run_subtype = "swarm" is the canonical
    # multi-proposer label (the pre-ATH-1236 "sorry_swarm" string was
    # not in the RunSubtype Literal — silently allowed at runtime but
    # type-lint-invalid; migrating restores the contract).
    with observe(
        session_id=sweep_session_id,
        spawn_reason="sorry_swarm_direct",
        run_subtype="swarm",
        organization_id=organization_id,
    ):
        for target in targets:
            # Cost cap pre-check. In-flight targets always finish; we
            # halt the next dispatch only.
            if total_cost >= config.cost_cap_usd:
                aborted = True
                abort_reason = (
                    f"cost cap reached "
                    f"(${total_cost:.2f} ≥ ${config.cost_cap_usd:.2f})"
                )
                break

            # Smoke-gate fires once, after smoke_size targets have
            # completed. When fewer than smoke_min_closures axiom-clean
            # closures have landed, abort before scaling.
            if (
                not smoke_gate_fired
                and config.smoke_size > 0
                and len(per_target) >= config.smoke_size
            ):
                smoke_gate_fired = True
                clean_so_far = sum(1 for t in per_target if t.axiom_clean)
                if clean_so_far < config.smoke_min_closures:
                    aborted = True
                    abort_reason = (
                        f"smoke gate failed: {clean_so_far}/"
                        f"{config.smoke_size} axiom-clean closures "
                        f"(needed ≥ {config.smoke_min_closures})"
                    )
                    break

            t0 = time.time()
            try:
                summary = orchestrator.run(
                    target,
                    max_rounds=config.max_rounds_per_target,
                    preflight=config.preflight,
                    preflight_lake_project=config.preflight_lake_project,
                    preflight_module_path=config.preflight_module_path,
                )
            except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                logger.warning(
                    "sorry_swarm: target %s threw — %s: %s",
                    target.tid, type(e).__name__, e,
                )
                outcome = TargetOutcome(
                    target_id=target.tid,
                    summary=FleetRunSummary(
                        target_id=target.tid,
                        outcomes={"_dispatch_error": {"error": str(e)[:200]}},
                        wall_seconds=time.time() - t0,
                        fleet_aliases=[],
                    ),
                    closed=False,
                    axiom_clean=False,
                )
                per_target.append(outcome)
                total_wall += time.time() - t0
                continue

            outcome = _build_target_outcome(target, summary, audit)
            target_cost = _sum_target_cost(summary)
            total_cost += target_cost
            total_wall += time.time() - t0
            per_target.append(outcome)

            if config.on_target_done is not None:
                try:
                    config.on_target_done(
                        target.tid, summary, outcome.forbidden_axioms,
                    )
                except Exception:
                    logger.exception(
                        "sorry_swarm: on_target_done callback raised — "
                        "swallowed so the sweep continues",
                    )

    closed_clean = sum(1 for t in per_target if t.axiom_clean)
    closed_dirty = sum(
        1 for t in per_target if t.closed and not t.axiom_clean
    )
    failed = sum(1 for t in per_target if not t.closed)

    return SorrySwarmResult(
        targets_attempted=len(per_target),
        targets_closed_clean=closed_clean,
        targets_closed_dirty=closed_dirty,
        targets_failed=failed,
        total_cost_usd=total_cost,
        total_wall_sec=total_wall,
        per_target=per_target,
        aborted=aborted,
        abort_reason=abort_reason,
        session_id=sweep_session_id,
    )


# ---------------------------------------------------------------------------
# Helpers (private — exposed via __all__ only as needed)
# ---------------------------------------------------------------------------


def _build_target_outcome(
    target: CycleTarget,
    summary: FleetRunSummary,
    audit: Callable[[CycleTarget, str], list[str]],
) -> TargetOutcome:
    """Pull a TargetOutcome out of one fleet run.

    Strategy: iterate drafters by their first-close round to find the
    fastest closer; run the audit on its candidate. When multiple
    drafters closed, the fastest-by-wall is the canonical closer.
    """
    closing_alias = summary.first_closer()
    if closing_alias is None:
        return TargetOutcome(
            target_id=target.tid, summary=summary,
            closed=False, axiom_clean=False,
        )

    closing_outcome = summary.outcomes.get(closing_alias)
    if not isinstance(closing_outcome, CycleResult):
        # Should be unreachable since first_closer only returns
        # drafters with a CycleResult, but defensive.
        return TargetOutcome(
            target_id=target.tid, summary=summary,
            closed=True, axiom_clean=False,
            closing_alias=closing_alias,
        )

    closing_round = next(
        (
            r for r in closing_outcome.rounds
            if r.proof_result.compiles
            and not r.proof_result.has_sorry
            and not r.proof_result.banned
        ),
        None,
    )
    closing_candidate = closing_round.candidate if closing_round else None
    forbidden = (
        audit(target, closing_candidate) if closing_candidate else []
    )

    return TargetOutcome(
        target_id=target.tid, summary=summary,
        closed=True,
        axiom_clean=len(forbidden) == 0,
        forbidden_axioms=forbidden,
        closing_alias=closing_alias,
        closing_candidate=closing_candidate,
    )


def _sum_target_cost(summary: FleetRunSummary) -> float:
    """Sum cost across every drafter / round for one target.

    Reads from ``CycleAttempt.drafter_resp_meta['cost_usd']`` which
    the litellm-flavored drafters set per call. Drafters that don't
    populate cost (e.g. local vLLM) contribute 0.
    """
    total = 0.0
    for outcome in summary.outcomes.values():
        if not isinstance(outcome, CycleResult):
            continue
        for r in outcome.rounds:
            cost = r.drafter_resp_meta.get("cost_usd")
            if isinstance(cost, (int, float)):
                total += float(cost)
    return total


__all__ = [
    "PYTHIA_DEFAULT_AXIOM_ALLOWLIST",
    "SorrySwarmConfig",
    "SorrySwarmResult",
    "TargetOutcome",
    "default_axiom_audit",
    "sorry_swarm",
]
