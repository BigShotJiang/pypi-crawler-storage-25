"""kairos.lean_cycle — cycle-engine drafter for hard Lean targets.

The single-shot drafter pattern (one prompt, one candidate, one verify
call) breaks down on Aristotle-grade theorems where the model's first
draft references the right structure but gets a lemma name or arg
shape wrong. The OpenGauss / lean4-skills / Aristotle approach is to
loop:

    1. Draft a candidate.
    2. verify_proof. If closed, return.
    3. Otherwise, hand the candidate + the lake-build error back to the
       model and ask it to refine. Go to (1).

This module ships that loop as a single drop-in helper:

    from kairos.lean_cycle import cycle_prove
    result = cycle_prove(target, drafter=client, max_rounds=4)

The drafter must be a `kairos.model_client.ModelClient` (any backend
that produces `ModelResponse` with `content`). The target carries the
shape that the swarm-side `swarm_pythia.Target` carries: imports, opens,
header, lake project + module path for verification.

Reference: github.com/math-inc/OpenGauss bridges Claude Code to
cameronfreer/lean4-skills via subprocess, parsing stream-json events to
detect "verified" / "has sorry" / "needs refinement". This helper does
the same loop natively in Python, eliminating the Claude Code
dependency and surfacing structured trace events through
`kairos.observe` if a session is active. Intended use: 4th drafter in
multi-agent swarms for hard pythia targets where single-shot success
rate is below 30%.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from .lean import ProofResult, verify_proof
# Optional Lean LSP goal-state injector. If leanclient isn't installed
# (default), goal_at() returns None and we fall back to error-only
# refinement prompts.
from .lean_lsp import LSP_AVAILABLE, goal_at


@dataclass
class CycleTarget:
    """Minimal shape needed to run a cycle-engine pass on one theorem.

    `imports`, `opens`, `header` describe the candidate prefix; the
    drafter completes after the trailing `:= `. `lake_project` +
    `module_path` are passed through to `verify_proof`.
    """
    tid: str
    imports: list[str]
    opens: list[str]
    header: str  # e.g. "theorem foo (x : Nat) : x + 0 = x"
    lake_project: Path
    module_path: str  # e.g. "Pythia.Scratch.SwarmDogfood.Foo"
    scratch_namespace: str = "Pythia.Scratch.SwarmDogfood"
    timeout_per_attempt: int = 180


@dataclass
class CycleAttempt:
    """One draft+verify pair inside the loop."""
    round: int
    drafter_alias: str
    candidate: str
    proof_result: ProofResult
    wall_sec: float
    drafter_resp_meta: dict = field(default_factory=dict)


@dataclass
class CycleResult:
    """Outcome of a complete cycle-engine pass on one target."""
    tid: str
    closed: bool
    final_attempt: Optional[CycleAttempt]
    rounds: list[CycleAttempt]
    total_wall_sec: float

    @property
    def round_count(self) -> int:
        return len(self.rounds)

    @property
    def first_close_round(self) -> Optional[int]:
        for a in self.rounds:
            # ATH-948 fix: include axiom_clean is not False so a proof
            # leaking sorryAx via vacuous self-reference is not
            # mistakenly counted as a closed round. Same soundness
            # class as `banned`.
            r = a.proof_result
            if (
                r.compiles
                and not r.has_sorry
                and not r.banned
                and r.axiom_clean is not False
            ):
                return a.round
        return None


_CODE_FENCE_RE = re.compile(r"```(?:lean)?\s*\n(.*?)```", re.DOTALL)

# Tokens that legitimately START a Lean 4 proof body. Used to strip
# prose preambles when the drafter ignored the "no prose" instruction
# in `_initial_prompt`. Matched at line start (with optional leading
# whitespace) so they don't false-positive on a `by` mid-prose like
# "this can be proven by induction".
#
# Calibration: <https://tahoe.athanor-ai.com/solve-runs/bdf9cd0c-...>
# (sam 2026-04-27) — ~30-50% of Sonnet attempts emit a 1-3 sentence
# preamble like "Looking at this theorem, I need to prove..." before
# the actual proof body. Without this strip, the prose ends up in the
# candidate and lake fails with parse errors. Keeping it empirically-
# motivated rather than aspirational.
_PROOF_BODY_OPENER_TOKENS = frozenset({
    "by", "fun", "exact", "refine", "refine'",
    "calc", "show",
})


def _line_starts_with_opener(line: str) -> bool:
    """True iff the first whitespace-delimited token of `line` is a
    Lean-proof opener. Distinct from `_looks_like_lean` because this
    is line-level (caller has already lstripped or split)."""
    s = line.lstrip()
    if not s:
        return False
    # Term-mode dotted-or-`@`-prefixed lemma reference.
    if s.startswith("@"):
        return True
    first = s.split(None, 1)[0].rstrip(":")
    return first in _PROOF_BODY_OPENER_TOKENS


def _strip_prose_preamble(text: str) -> str:
    """If `text` has prose before the actual Lean proof, drop the prose.

    Walks lines top-to-bottom; the first line whose first token is a
    Lean-proof opener (or whose mid-line content has `:= by` followed
    by an opener) becomes the new start. Everything before is preamble
    and gets dropped.

    If no opener is found, returns the input unchanged so the caller's
    error path still surfaces something the pytest fixture can grep.
    """
    lines = text.splitlines()
    for i, line in enumerate(lines):
        s = line.lstrip()
        if not s:
            continue
        if _line_starts_with_opener(line):
            return "\n".join(lines[i:])
        # Mid-line `:= by` form: model echoes the theorem signature
        # `theorem foo := by ...`. Drop everything before `:=`.
        idx = line.find(":= ")
        if idx >= 0:
            tail = line[idx + 3:]
            if _line_starts_with_opener(tail):
                rest = "\n".join(lines[i + 1:])
                return tail.lstrip() + (("\n" + rest) if rest else "")
    return text


def _looks_like_lean(text: str) -> bool:
    """True if `text` plausibly starts a Lean 4 proof (after strip).

    Lightweight surface-form check; the real verdict is `lake env lean`
    on the substituted module. Used by `cycle_prove` to decide whether
    a Sonnet-style prose-only response should trigger an immediate
    regen with a stricter prompt rather than wasting a `verify_proof`
    call on text that obviously can't compile.

    Heuristic: the first non-blank line must either start with one of
    the recognised tactic-mode openers OR look like a term-mode lemma
    reference (a dotted identifier, with optional `@` prefix and
    arguments). We REJECT bare-noun first tokens (`Looking`, `The`,
    etc.) by requiring either a recognised opener or a token that
    contains a `.` (dotted lemma) — generic English words rarely
    contain a literal period followed by another identifier.
    """
    for raw in text.splitlines():
        s = raw.lstrip()
        if not s:
            continue
        if _line_starts_with_opener(s):
            return True
        # Term-mode: dotted lemma reference, e.g. `Nat.zero_le n`,
        # `@Foo.bar a b`. Reject bare-noun openers.
        first = s.split(None, 1)[0].lstrip("@")
        if "." in first and first.replace("_", "").replace(".", "").isalnum():
            return True
        # Explicit prose rejection
        _PROSE_STARTS = (
            "i ", "let me", "looking", "the ", "this ", "here ",
            "we ", "to ", "first", "note", "since", "recall",
            "observe", "consider", "proof:", "solution:",
        )
        if s.lower().startswith(_PROSE_STARTS):
            return False
        return False  # first non-blank line wasn't Lean → bail
    return False


def _extract_proof_body(text: str) -> str:
    """Strip the markdown code fence, the leading `:= `, and any
    chat-style prose preamble. Returns just the proof body that goes
    after the theorem header.

    Three layers, applied in order:

      1. If a ```lean ... ``` fence exists, take its contents (existing
         behaviour, kept for backward compat with code-fence-emitting
         drafters).
      2. Drop a leading `:= ` if the model echoed the theorem header.
      3. Drop any prose preamble before the first Lean-proof opener
         (`by`, `fun`, `exact`, etc.) — handles the Sonnet
         chat-prior-leak case where the drafter writes "Looking at
         this theorem..." before the actual `by` block.

    Layer 3 is no-op for clean drafter output; the cost is one
    line-walk over the response.
    """
    m = _CODE_FENCE_RE.search(text)
    if m:
        text = m.group(1)
    text = text.strip()
    # Drop a leading `:= ` if the model echoed it.
    if text.startswith(":= "):
        text = text[3:]
    elif text.startswith(":="):
        text = text[2:]
    text = text.strip()
    # Layer 3: prose-preamble strip.
    text = _strip_prose_preamble(text)
    return text.strip()


def _build_module_text(target: CycleTarget, candidate: str) -> str:
    imps = "\n".join(f"import {m}" for m in target.imports)
    ops = "\n".join(f"open {ns}" for ns in target.opens)
    return (
        f"{imps}\n\n"
        f"{ops}\n\n"
        f"namespace {target.scratch_namespace}\n\n"
        f"{target.header} := {candidate}\n\n"
        f"end {target.scratch_namespace}\n"
    )


def _initial_prompt(target: CycleTarget) -> tuple[str, str]:
    """System + user prompt for the first round (no prior errors)."""
    autocomplete = (
        "\n".join(f"import {m}" for m in target.imports)
        + "\n\n"
        + "\n".join(f"open {ns}" for ns in target.opens)
        + f"\n\nnamespace {target.scratch_namespace}\n\n"
        + target.header
        + " := "
    )
    sys_msg = (
        "You are an expert Lean 4 theorem prover. Output ONLY valid Lean 4 syntax. "
        "NEVER output English prose, explanations, or commentary. "
        "Your ENTIRE response must be parseable by the Lean 4 compiler. "
        "Start with: by, fun, exact, refine, calc, show, or a term-mode lemma name. "
        "Banned: sorry, admit, native_decide, decide. "
        "Banned: English sentences, markdown, 'I will', 'Let me', 'Looking at'. "
        "If you output ANY English prose, the response is rejected and wasted. "
        "Produce minimal proofs against Mathlib + Pythia vocabulary."
    )
    user_msg = (
        "Continue this Lean 4 file. Output ONLY the proof body that goes "
        "after the trailing `:= ` (i.e. starting with `by` for tactic "
        "mode or a term for term mode). No prose, no markdown, no "
        "theorem restatement.\n\n"
        f"```lean\n{autocomplete}\n```"
    )
    return sys_msg, user_msg


_ERROR_LINE_COL_RE = re.compile(
    r":(\d+):(\d+):\s*(?:warning:|error:)?\s*",
)


def _first_candidate_error_position(
    candidate_file_rel: str, errors: list[str],
) -> tuple[int, int] | None:
    """Find the (line, col) of the first error tagged with the
    candidate's own file path. Returns None if no candidate-tagged
    error has a position. Used to pick the cursor position for the
    LSP goal query.
    """
    for line in errors:
        if candidate_file_rel not in line:
            continue
        # Skip the file path itself and find the trailing :LINE:COL:.
        # Line shapes: "error: <path>:LINE:COL: ..." or
        # "warning: <path>:LINE:COL: ...".
        idx = line.find(candidate_file_rel)
        tail = line[idx + len(candidate_file_rel):]
        m = _ERROR_LINE_COL_RE.match(tail)
        if m:
            return int(m.group(1)), int(m.group(2))
    return None


def _refinement_prompt(
    target: CycleTarget,
    last_candidate: str,
    last_errors: list[str],
    *,
    inject_goal_state: bool = True,
) -> tuple[str, str]:
    """System + user prompt for a refinement round (prior candidate +
    its lake-build errors threaded back in).

    Errors are filtered to lines that are EITHER tagged with the
    candidate's own file path OR are unprefixed `error:` lines from
    Lean itself (no path prefix == the running build's current file).
    Lake's stdout is dominated by import-tree warnings (linter noise,
    unused-variable warnings, sorry stubs in unrelated downstream
    modules); without filtering, Sonnet sees only that noise and
    can't tell what's wrong with its own candidate. Empirical: pre-
    filter, Sonnet produced identical broken candidates across 4
    refinement rounds; post-filter the model finally sees the actual
    parse / type-class error and can act on it.

    Then truncated at 30 lines / 4 KB to keep prompt in budget. Lake
    errors are verbose; the first 30 useful lines almost always contain
    the actionable diagnostic.
    """
    candidate_file_rel = target.module_path.replace(".", "/") + ".lean"
    relevant: list[str] = []
    for line in last_errors:
        line = line.rstrip()
        if not line:
            continue
        # Keep: lines about the candidate's file, plus generic build-
        # failure / Lean-exit lines, plus standalone error: lines that
        # are not tagged with another file's path (== no slash in the
        # text between "error:" and the first colon delimiter).
        is_candidate_tagged = candidate_file_rel in line
        is_unprefixed_error = (
            line.startswith("error:")
            and "/" not in line.split(":", 2)[0]
        )
        is_terminal_error = line.strip() in (
            "error: build failed",
            "error: Lean exited with code 1",
        )
        if is_candidate_tagged or is_unprefixed_error or is_terminal_error:
            relevant.append(line)

    # If nothing remained after filtering (defensive), fall back to the
    # raw error list so we don't show the model a blank diagnostic.
    src = relevant if relevant else last_errors

    err_lines: list[str] = []
    seen_chars = 0
    for line in src:
        if seen_chars > 4000 or len(err_lines) >= 30:
            break
        line = line.rstrip()
        if not line:
            continue
        err_lines.append(line)
        seen_chars += len(line)

    err_block = "\n".join(err_lines) if err_lines else "(no diagnostic captured)"

    # Optional Lean LSP goal-state injection. The goal Lean sees at
    # the proof-body entry (right after `:= `) is what a model needs
    # to pick the right Mathlib lemma instead of guessing identifiers.
    # We probe a small window of positions to handle the common case
    # where the candidate's parse error means the LSP returns "no
    # goals" at the error line itself (Lean exited the elaborator
    # before reaching that point); the entry-point line still has
    # the initial goal which is what the model needs to see.
    #
    # Probe order:
    #   1. The line of the FIRST error tagged with the candidate's
    #      file (caller's most-relevant position).
    #   2. The line where the proof body STARTS in the constructed
    #      file (computed from imports + opens + namespace + header
    #      structure). This is the canonical goal-entry point.
    #   3. A small backward window from each probe so we land on a
    #      line that's actually elaborated.
    #
    # No-op when:
    #   - leanclient isn't installed (LSP_AVAILABLE = False)
    #   - the LSP failed to start
    #   - all probe positions return None / "no goals"
    goal_block: str | None = None
    if inject_goal_state and LSP_AVAILABLE:
        # Compute the line where `:= ` lives in the constructed file:
        # imports (N), blank (1), opens (M), blank (1), namespace (1),
        # blank (1), header lines (K). The header's last line carries
        # the trailing `:= `.
        header_lines = target.header.split("\n")
        body_entry_line = (
            len(target.imports)
            + 1  # blank after imports
            + len(target.opens)
            + 1  # blank after opens
            + 1  # `namespace ...`
            + 1  # blank after namespace
            + len(header_lines)
        )
        # End-of-line column for the body-entry line; LSP accepts
        # anything beyond the line end + clamps to EOL.
        body_entry_col = len(header_lines[-1]) + 4  # `:= ` + room

        candidates: list[tuple[int, int]] = []
        err_pos = _first_candidate_error_position(candidate_file_rel, last_errors)
        if err_pos is not None:
            candidates.append(err_pos)
        candidates.append((body_entry_line, body_entry_col))
        # Backward fallbacks if the primary position has no goal
        # (LSP returns "no goals" once Lean exits the elaborator).
        for back in range(1, 6):
            candidates.append((body_entry_line - back, body_entry_col))

        for (line, col) in candidates:
            if line < 1:
                continue
            attempt = goal_at(
                lake_project=str(target.lake_project),
                module_path=target.module_path,
                line=line, character=col,
                timeout=30,
            )
            if attempt and "no goals" not in attempt.lower():
                goal_block = attempt
                break

    sys_msg = (
        "You are an expert Lean 4 theorem prover refining a previous "
        "attempt. The previous candidate did not compile. "
        "Output ONLY valid Lean 4 syntax — NO English prose, NO explanations. "
        "Your ENTIRE response must be the corrected proof body. "
        "Start with: by, fun, exact, refine, calc, show, or a term. "
        "Banned: sorry, admit, native_decide, decide, English sentences."
    )

    user_parts = [
        f"Theorem (header):\n```lean\n{target.header} := <YOUR PROOF HERE>\n```",
        f"Previous candidate (failed to compile):\n```lean\n{last_candidate}\n```",
        f"Lake build error:\n```\n{err_block}\n```",
    ]
    if goal_block:
        # Truncate goal to keep prompt in budget — Lean prints big
        # contexts for some Mathlib goals.
        truncated = goal_block[:2000]
        user_parts.append(
            f"Goal state at the error position (Lean LSP):\n```\n"
            f"{truncated}\n```"
        )
    user_parts.append(
        "Output ONLY the corrected proof body that goes after `:= `. "
        "Match the actual Mathlib lemma names and argument shapes; do "
        "not invent identifiers. If the goal state is shown, anchor "
        "your proof on the visible hypotheses and goal type."
    )
    user_msg = "\n\n".join(user_parts)
    return sys_msg, user_msg


def cycle_prove(
    target: CycleTarget,
    drafter: Any,
    *,
    drafter_alias: str = "drafter",
    max_rounds: int = 4,
    temperature: float = 0.0,
    max_tokens: int = 800,
    on_round: Optional[Callable[[CycleAttempt], None]] = None,
) -> CycleResult:
    """Run a draft → verify → refine loop on one Lean target.

    Args:
        target: the theorem to prove (imports, opens, header, project).
        drafter: a `kairos.model_client.ModelClient`-compatible object
            that supports `format_messages(sys, user)` + `call(messages,
            temperature, max_tokens)` returning a ModelResponse.
        drafter_alias: short name for trace / logs (e.g. "sonnet").
        max_rounds: hard cap on draft+verify pairs. Default 4 mirrors
            the OpenGauss/lean4-skills cycle-engine default; below 2
            the loop adds little over single-shot, above 8 returns
            diminishing.
        temperature: 0 for the first round (deterministic baseline);
            refinement rounds bump to 0.7 to escape a stuck pattern.
            Subclasses can override by passing their own drafter.
        max_tokens: per-call budget. Reasoning models (Kimi K2.5,
            Gemini-3-flash) may auto-clamp this up via
            `min_tokens_for_reasoning`.
        on_round: optional callback invoked after each verify with the
            CycleAttempt. Useful for streaming progress to a TUI or
            posting per-round trace events.

    Returns:
        CycleResult with full per-round history. `closed=True` iff some
        round produced a candidate where verify_proof reported
        `compiles AND not has_sorry AND not banned`. The loop stops
        at the first such round.

    Tier classification: paid (requires the ``solve`` product). Aidan
    2026-04-27 directive — agent-orchestration shapes (cycle, swarm,
    fleet) are paid-only. Free-tier callers should use
    :func:`kairos.simple_prove` (single-shot, no refine loop).
    """
    # Paid-tier gate. Same as FleetOrchestrator + sorry_swarm + prove.
    from kairos.license_scope import require_product
    require_product("solve")

    rounds: list[CycleAttempt] = []
    last_candidate = ""
    last_errors: list[str] = []
    t_start = time.time()

    for round_idx in range(1, max_rounds + 1):
        if round_idx == 1:
            sys_msg, user_msg = _initial_prompt(target)
            temp = temperature
        else:
            sys_msg, user_msg = _refinement_prompt(
                target, last_candidate, last_errors,
            )
            # Bump temperature on refinement rounds — if the model is
            # making the same mistake at temp=0, it will keep making it.
            temp = max(temperature, 0.7)

        t_call = time.time()
        try:
            resp = drafter.call(
                messages=drafter.format_messages(sys_msg, user_msg),
                temperature=temp,
                max_tokens=max_tokens,
            )
            text = resp.content or ""
        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            attempt = CycleAttempt(
                round=round_idx,
                drafter_alias=drafter_alias,
                candidate="",
                proof_result=ProofResult(
                    compiles=False,
                    errors=[f"drafter_error: {type(e).__name__}: {e!s:.200}"],
                ),
                wall_sec=time.time() - t_call,
                drafter_resp_meta={"error": str(e)[:200]},
            )
            rounds.append(attempt)
            if on_round:
                on_round(attempt)
            # Drafter errors usually persist (auth, network); abort.
            break

        candidate = _extract_proof_body(text)
        # Fix #3: if extraction left us with prose-only output (no
        # Lean-proof opener anywhere), short-circuit before the
        # ~30s `verify_proof` call. The next round will retry with
        # bumped temperature + the refinement prompt's stricter
        # framing. Saves ~30s per non-Lean attempt across the swarm.
        if candidate and not _looks_like_lean(candidate):
            result = ProofResult(
                compiles=False,
                errors=["non_lean_response"],
            )
            attempt = CycleAttempt(
                round=round_idx,
                drafter_alias=drafter_alias,
                candidate=candidate[:300],
                proof_result=result,
                wall_sec=time.time() - t_call,
                drafter_resp_meta={
                    "non_lean_response": True,
                    "first_60_chars": candidate[:60],
                },
            )
            rounds.append(attempt)
            if on_round:
                on_round(attempt)
            last_candidate = candidate
            last_errors = ["non_lean_response: drafter emitted prose with no Lean-proof opener"]
            continue
        # Build module text + verify.
        code = _build_module_text(target, candidate) if candidate else ""
        if not candidate:
            result = ProofResult(
                compiles=False,
                errors=["empty_candidate"],
            )
        else:
            result = verify_proof(
                code,
                lake_project=str(target.lake_project),
                module_path=target.module_path,
                timeout=target.timeout_per_attempt,
            )

        wall = time.time() - t_call
        meta = {
            "finish_reason": getattr(resp, "finish_reason", None) if candidate else None,
            "completion_tokens": getattr(resp, "completion_tokens", 0) if candidate else 0,
            "reasoning_len": len(getattr(resp, "reasoning_content", None) or "") if candidate else 0,
            "round_temperature": temp,
        }
        attempt = CycleAttempt(
            round=round_idx,
            drafter_alias=drafter_alias,
            candidate=candidate,
            proof_result=result,
            wall_sec=wall,
            drafter_resp_meta=meta,
        )
        rounds.append(attempt)
        if on_round:
            on_round(attempt)

        closed = (
            result.compiles
            and not result.has_sorry
            and not result.banned
            # ATH-948: axiom_clean=False is a soundness failure (proof
            # depends on sorryAx via vacuous self-reference); must NOT
            # count as a closed round. axiom_clean=None means audit
            # was skipped (e.g. theorem name not extractable) — fail-
            # open since the customer-side audit gate is downstream.
            and result.axiom_clean is not False
        )
        if closed:
            break

        last_candidate = candidate
        last_errors = list(result.errors or [])

    final = rounds[-1] if rounds else None
    closed_overall = (
        final is not None
        and final.proof_result.compiles
        and not final.proof_result.has_sorry
        and not final.proof_result.banned
        # ATH-948: same soundness gate as the per-round closed check
        # above. Without this, the cycle reports closed_overall=True
        # for an unsound final round.
        and final.proof_result.axiom_clean is not False
    )
    result = CycleResult(
        tid=target.tid,
        closed=closed_overall,
        final_attempt=final,
        rounds=rounds,
        total_wall_sec=time.time() - t_start,
    )

    # ATH-841 — default-on emit. Same non-raising pattern as
    # kairos.lean.verify_proof; observe.emit picks up an active context
    # if the caller is inside `with observe()` / `session()`, otherwise
    # auto-bootstraps a free-tier observe context with the JSONL
    # backstop so a bypass driver still produces traces.
    try:
        from kairos.observe import emit as _emit
        _emit(
            "cycle_prove_attempt",
            {
                "tid": target.tid,
                "drafter_alias": drafter_alias,
                "rounds_run": len(rounds),
                "max_rounds": max_rounds,
                "closed": closed_overall,
                "final_compiles": (
                    final.proof_result.compiles if final else False
                ),
                "final_has_sorry": (
                    final.proof_result.has_sorry if final else False
                ),
                "final_score": (
                    final.proof_result.score if final else 0.0
                ),
                "total_wall_sec": result.total_wall_sec,
            },
            run_subtype="theorem_proving",
        )
    except Exception:
        # Best-effort emit; don't break cycle_prove's return contract.
        import logging as _logging
        _logging.getLogger(__name__).exception(
            "cycle_prove: ATH-841 emit failed — swallowing",
        )

    return result
