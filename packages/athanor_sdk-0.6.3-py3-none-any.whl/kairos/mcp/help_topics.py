"""kairos.mcp.help_topics — agent self-onboarding content (ATH-829 Phase 1).

Content (not behavior). Static dicts the MCP server returns when an
agent asks "what can you do?" or "how do I use you?". Pure Python,
no dependencies, no paid imports.

## Why this module exists

Customer agents (Claude Code, Cursor, Cline, Leanstral, etc.) connect
to the kairos MCP server fresh. They see the tool list, but tool
docstrings alone don't answer:

- Which tool do I pick when I have a Lean theorem?
- What's the difference between `simple_prove` and `solve`?
- When should I use my own outer-Opus context vs let kairos decompose?

The MCP server exposes:

1. A `capabilities://kairos` resource the agent reads on first connect.
2. A `kairos.help(topic)` tool the agent calls for specific guidance.
3. A `decision_tree://kairos/lean` resource that maps "you have X →
   try Y → if fail → try Z" so the agent's planner has a deterministic
   reasoning path.

This module owns the CONTENT. The MCP server (slice 3) owns the
transport that exposes it.

## Customer-Opus pattern reflected here

The decision tree assumes the customer's outer agent IS Opus and
wants to drive decomposition. When the agent picks `lean.solve`
without `internal_planner_model`, kairos returns `decompose_hints` and
the agent recurses. The help content tells the agent this explicitly
so it knows to expect that contract.
"""
from __future__ import annotations

from typing import Any


# ── Capability descriptor — what the kairos MCP server is + does ─────


def get_capabilities(license_tier: str = "free") -> dict[str, Any]:
    """Return the capability descriptor the agent reads on first connect.

    :param license_tier: ``"free"`` (no license file or KAIROS_DEV_NO_LICENSE
        present and bypass active) or ``"paid"`` (valid license with
        ``solve`` product). Drives which tools are advertised.

    :returns: JSON-serialisable dict with:

        * ``tier``: the license tier, lets agents branch on it
        * ``verifiers``: list of verifier modules + their tools
        * ``onboarding``: pointer to ``kairos.help`` for deeper guidance
    """
    free_lean_tools = [
        {
            "name": "simple_prove_template",
            "description": (
                "Single-shot Lean proof attempt with optional iterative "
                "refinement. BYO-LLM. Use this FIRST for every theorem; "
                "it's the cheapest path."
            ),
            "use_when": "you have a Lean theorem statement (or NL hypothesis)",
        },
        {
            "name": "verify_proof",
            "description": (
                "Atomic Lean proof compile + axiom audit. No LLM. "
                "Use this when you have a candidate proof and want to "
                "check it cleanly."
            ),
            "use_when": "you have a complete proof candidate",
        },
        {
            "name": "dispatch",
            "description": (
                "Pythia tactic-ladder dispatcher (simp → linarith → "
                "aesop → stat_lemma → SMT). No LLM. "
                "Use this for goals likely to fall to deterministic tactics."
            ),
            "use_when": "you have a goal that looks tactic-ladder shaped",
        },
        {
            "name": "certify",
            "description": (
                "Axiom-cleanliness audit on an existing Lean proof. "
                "Returns 8-check structured JSON. No LLM. "
                "Use this before merging to verify the proof's trust boundary."
            ),
            "use_when": "you're about to commit a Lean proof and want to certify it",
        },
        {
            "name": "verify_batch",
            "description": (
                "Bulk Lean compile across many candidates. No LLM. "
                "Use this when you've generated N candidates and need fast pass/fail."
            ),
            "use_when": "you have many candidates from a sampling pass",
        },
        {
            "name": "list_pythia_templates",
            "description": (
                "Returns the catalogue of Pythia template patterns "
                "(Bonferroni, Bernstein, etc.) that simple_prove can match against."
            ),
            "use_when": "you want to discover what Pythia knows out-of-the-box",
        },
    ]

    paid_lean_tools = [
        {
            "name": "lean_race",
            "description": (
                "Race multiple LLM drafters on one target in parallel; "
                "first axiom-clean closure wins. Returns RaceResult with "
                "per-drafter outcomes. Use when one model isn't enough or "
                "you want diversity."
            ),
            "use_when": (
                "simple_prove_template didn't close it AND you have multiple "
                "drafters available"
            ),
        },
        {
            "name": "lean_solve",
            "description": (
                "Decompose-and-conquer Lean proof orchestrator. Tries "
                "simple_prove → race → returns structured decompose_hints "
                "for your outer agent (default) OR calls an internal "
                "planner if internal_planner_model is set. The default flow "
                "is designed for Opus-as-outer-orchestrator: kairos hands "
                "decomposition back to YOU because you have higher-bandwidth "
                "context (file state, Mathlib hints, prior failures) than a "
                "fresh internal Opus call would rebuild."
            ),
            "use_when": (
                "you want kairos to handle the cheap-first → race → decompose "
                "flow without your having to wire it"
            ),
        },
    ]

    paid_other_tools = [
        {
            "name": "ebmc_verify",
            "description": "EBMC hardware verification — atomic verify call.",
            "use_when": "you have an EBMC spec and want to compile-check it",
            "phase_status": "scheduled for Phase 2 of ATH-829",
        },
        {
            "name": "ebmc_solve",
            "description": "EBMC CEGAR orchestration with iterative refinement.",
            "use_when": "you have a complex EBMC obligation that needs CEGAR",
            "phase_status": "scheduled for Phase 2 of ATH-829",
        },
    ]

    if license_tier == "paid":
        verifiers = [
            {
                "name": "lean",
                "tools": free_lean_tools + paid_lean_tools,
            },
            {
                "name": "ebmc",
                "tools": paid_other_tools,
            },
        ]
    else:
        verifiers = [
            {
                "name": "lean",
                "tools": free_lean_tools,
            },
        ]

    return {
        "kairos_version": "0.x",  # filled by server at runtime
        "tier": license_tier,
        "byo_llm_supported": True,
        "verifiers": verifiers,
        "onboarding": {
            "first_step": (
                "Read decision_tree://kairos/lean for the canonical "
                "Lean-target reasoning path."
            ),
            "help_topics_available": list(_HELP_TOPICS.keys()),
            "call_pattern": "use kairos.help(topic) for specific guidance",
        },
    }


# ── Decision trees — deterministic reasoning paths for agent loops ────


_DECISION_TREE_LEAN = {
    "title": "Lean target — pick a tool",
    "rationale": (
        "Tools are ordered cheapest-first. Each step's failure points to "
        "the next escalation. If you reach the bottom, you've exhausted "
        "kairos and need to either decompose manually or escalate to "
        "Aristotle (paid third-party closure service)."
    ),
    "steps": [
        {
            "step": 1,
            "action": "Call simple_prove_template(hypothesis, refine_on_failure=True)",
            "tier": "free",
            "on_proved": "DONE — commit the proof",
            "on_failed": "Read result.next_actions; pick a typed action; retry. If still failed after refinement, go to step 2.",
        },
        {
            "step": 2,
            "action": "Call lean_race(target, drafters=[goedel, flash, sonnet], n=10)",
            "tier": "paid",
            "on_proved_clean": "DONE — commit RaceResult.closing_candidate",
            "on_failed": "Go to step 3.",
            "skip_when": "free tier (this tool is paid)",
        },
        {
            "step": 3,
            "action": "Call lean_solve(target). Default mode (internal_planner_model=None) returns decompose_hints.",
            "tier": "paid",
            "on_proved": "DONE",
            "on_decompose_hints": (
                "YOU are the planner. For each hint: build a sub-target "
                "from hint.sub_target_source, call lean_solve recursively, "
                "assemble the parent proof from the closed sub-lemmas."
            ),
            "skip_when": "free tier",
        },
        {
            "step": 4,
            "action": "Escalate to Aristotle (paid third-party). Submit the target via kairos.aristotle_dispatch or your own queue tool.",
            "tier": "paid + Aristotle account",
            "on_proved": "DONE — review for vacuous-witness tricks before merging",
            "on_failed": (
                "The target is genuinely hard. Decompose by hand using your "
                "domain knowledge, or wait for Mathlib infrastructure to land."
            ),
        },
    ],
}


def get_decision_tree(verifier: str) -> dict[str, Any]:
    """Return the canonical decision tree for one verifier.

    :param verifier: ``"lean"`` (currently the only one — EBMC/Dafny/etc.
        trees land in Phase 2/3 of ATH-829).
    :returns: dict with ``title``, ``rationale``, ``steps``. Empty dict
        for unknown verifiers (lets agents detect the gap cleanly).
    """
    if verifier == "lean":
        return dict(_DECISION_TREE_LEAN)
    return {}


# ── help(topic) — specific guidance for canonical agent questions ─────


_HELP_TOPICS: dict[str, dict[str, str]] = {
    "getting_started": {
        "summary": "Connect → read capabilities → pick a verifier → follow its decision tree.",
        "details": (
            "1. Call kairos.help('list_topics') to see all available topics.\n"
            "2. Read capabilities://kairos to learn which tools are licensed for your tier.\n"
            "3. For Lean: read decision_tree://kairos/lean — it's a deterministic path "
            "from cheapest tool (simple_prove_template) to most-orchestrated (solve with "
            "outer-agent decomposition).\n"
            "4. Free tier: simple_prove_template, verify_proof, certify, dispatch, "
            "verify_batch, list_pythia_templates.\n"
            "5. Paid tier (license required): adds lean_race, lean_solve, and the "
            "EBMC/Dafny/CBMC/Verus surfaces."
        ),
    },
    "lean_simple_prove": {
        "summary": (
            "Single-shot Lean proof. Always try this first. BYO-LLM. "
            "Set refine_on_failure=True to auto-iterate on parse / type-mismatch errors."
        ),
        "details": (
            "Pass a hypothesis (NL or Lean signature). The SDK matches it against "
            "Pythia templates first (deterministic, no LLM), falls through to your "
            "BYO-LLM if no template matches. Result has `proved: bool`, `lean_source: "
            "str`, `next_actions: list[NextAction]` (typed retry hints when proved=False), "
            "`refinement_history` (when refine_on_failure=True). The next_actions list "
            "is your retry-loop driver — pick one, apply the suggestion, re-call "
            "simple_prove_template with the revised hypothesis."
        ),
    },
    "lean_solve_decomposition": {
        "summary": (
            "lean_solve with internal_planner_model=None hands decomposition to YOU. "
            "Read result.decompose_hints; expand each into a sub-target; recurse."
        ),
        "details": (
            "When you (the customer agent) ARE Opus 4.7 already, you have higher-bandwidth "
            "context than a fresh internal Opus call could rebuild — file state, Mathlib "
            "hints, prior failed attempts. So lean_solve's default behavior is to RACE "
            "drafters first (cheap + parallel), and on full-fail return structured "
            "decompose_hints to YOU. Each hint has:\n"
            "  - sub_target_name: a Lean-identifier-shaped name you can use verbatim\n"
            "  - sub_target_source: the suggested signature, often `have h_i : ... := ?_`\n"
            "  - why_blocked: plain text rationale + per-drafter error summary\n"
            "  - suggested_drafters: optional list to prioritize on the sub-target's race\n"
            "Build a sub CycleTarget per hint, call lean_solve(sub_target) recursively, "
            "assemble the parent proof from the sub-lemmas: "
            "`have h1 := <closed_sub1>; have h2 := <closed_sub2>; <combine>`."
        ),
    },
    "lean_solve_internal_planner": {
        "summary": (
            "Set internal_planner_model when your outer agent ISN'T Opus and you want "
            "kairos to bring its own planner."
        ),
        "details": (
            "Use case: your customer agent is Sonnet or smaller, and you want kairos to "
            "handle the decomposition step internally with an Opus call. Pass "
            "`internal_planner_model='anthropic/claude-opus-4-6'` (or any model that "
            "passes structured decomposition prompts). On race-fail, kairos calls the "
            "planner, parses sub-targets, and recursively solves them. "
            "result.sub_solves has the per-sub-target trajectory; result.proved is True "
            "iff every sub-lemma closed AND parent assembly succeeded.\n"
            "Cost trade-off: you pay an extra Opus call per decompose level. Default "
            "behavior (planner=None) is cheaper if your outer agent is Opus already."
        ),
    },
    "bulletproof_loop": {
        "summary": (
            "Refinement-loop pattern: don't submit and pray, loop until lake passes. "
            "Use lean_verify on every emit; use lean_check_signature before committing "
            "to a decomposition or proof attempt."
        ),
        "details": (
            "ATH-829 Phase 1.4 enforcement: prompts can't enforce correct Lean usage; "
            "tool-driven loops can. The pattern your outer agent should run:\n\n"
            "  1. Generate a Lean candidate (proof body, decomposition signature).\n"
            "  2. Call `lean_verify(code, lake_project, module_path)` — or "
            "`lean_check_signature(stmt, imports, opens, lake_project)` for "
            "signature-only checks before committing to a proof attempt.\n"
            "  3. If `compiles=False` (or `ok=False`), feed the errors back into your "
            "next-attempt prompt and re-emit. Don't accept the first emit; iterate.\n"
            "  4. Stop only when lake says the proof type-checks AND axioms are "
            "allowlisted (kairos guards both).\n\n"
            "Internal kairos modules already follow this: `lean_cycle.cycle_prove` "
            "loops the drafter on per-attempt errors; `lean_solve` with internal "
            "decomposition signature-checks each sub-lemma against lake before "
            "recursing. The two MCP tools (lean_verify + lean_check_signature) "
            "give your outer agent the same primitives so it can run its own "
            "refinement loop without the orchestration layer.\n\n"
            "Why it matters: a Lean signature can look plausible to an LLM and "
            "still not type-check (undefined identifier, wrong implicit, missing "
            "open). Without the loop, you'd silently waste downstream proof "
            "attempts on a malformed sub-target. The loop catches that in 1-3 "
            "seconds of lake compile."
        ),
    },
    "ebmc_cegar": {
        "summary": "EBMC CEGAR loop — iterative spec-refinement for hardware verification.",
        "details": (
            "Coming in ATH-829 Phase 2. Will follow the same `verify` / `solve` shape as "
            "Lean — kairos.ebmc.verify is atomic compile, kairos.ebmc.solve is the "
            "orchestrated CEGAR loop. Paid-tier only; no free-tier EBMC."
        ),
    },
    "choosing_a_tool": {
        "summary": "Match your input shape to the cheapest tool that handles it.",
        "details": (
            "Have an NL hypothesis? simple_prove_template.\n"
            "Have a Lean theorem signature with sorry? simple_prove_template, then lean_solve.\n"
            "Have a complete proof candidate? verify_proof.\n"
            "Have many candidates? verify_batch.\n"
            "Have an EBMC spec? ebmc_verify (paid).\n"
            "Have a hardware design + properties? ebmc_solve (paid, CEGAR).\n"
            "Use kairos.help('lean_solve_decomposition') for the multi-step orchestration shape."
        ),
    },
    "list_topics": {
        "summary": "Available help topics (call kairos.help(topic) on each):",
        "details": "",  # filled below at module-load time
    },
}

# Build list_topics at module-load time (data, not behavior)
_HELP_TOPICS["list_topics"]["details"] = "\n".join(
    f"  - {t}: {info['summary']}" for t, info in _HELP_TOPICS.items() if t != "list_topics"
)


def get_help_topic(topic: str) -> dict[str, str]:
    """Look up a help topic. Unknown topic returns a discovery hint
    pointing the agent at ``list_topics``.

    :param topic: One of the keys in ``_HELP_TOPICS`` (call
        ``get_help_topic("list_topics")`` to enumerate).
    :returns: dict with ``summary`` and ``details``. Always non-empty
        — even unknown topics return guidance.
    """
    if topic in _HELP_TOPICS:
        return dict(_HELP_TOPICS[topic])
    return {
        "summary": f"Unknown topic: {topic!r}",
        "details": (
            "Call kairos.help('list_topics') to see all available topics. "
            "If you're unsure where to start, try kairos.help('getting_started')."
        ),
    }


__all__ = [
    "get_capabilities",
    "get_decision_tree",
    "get_help_topic",
]
