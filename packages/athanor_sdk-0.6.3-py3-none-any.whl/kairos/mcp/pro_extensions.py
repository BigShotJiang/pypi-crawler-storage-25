"""kairos.mcp.pro_extensions — lazy paid-tier MCP tool registrations (ATH-829).

## Why this module exists separately

ATH-727's free-tier MCP server (`kairos.mcp`) is fenced from paid-tier
imports by a static-import-audit regression test. The fence prevents
`kairos.mcp` (and anything it transitively imports at module-load time)
from importing `kairos.fleet`, `kairos.prove`, `kairos.sv.cegar`,
`kairos.sv.swarm`, `kairos.sv.multi`, or `kairos.sv.invariants`.

The fence is preserved through ATH-829 by:

1. Putting paid-tier wiring in this separate module (which DOES import
   paid features).
2. The MCP server (slice 3) imports this module ONLY inside a function
   call (`load_paid_extensions()`), AFTER a successful license probe.
3. The static-import-audit test runs `import kairos.mcp` and asserts no
   paid module is in `sys.modules`. Importing `kairos.mcp.pro_extensions`
   directly would fail the audit; only `kairos.mcp` is checked.

This is the "Q5: unified server with lazy conditional imports" lock
from QA's ATH-829 review.

## Public API

* :func:`load_paid_extensions` — called by the MCP server after license
  probe. Returns a dict mapping tool-name → callable (the paid tools'
  Python entry points). MCP server registers these as MCP tools.

* :func:`paid_tool_schemas` — returns the JSON-schema definitions for
  paid tools. Light-weight (schemas only, no paid imports), exposed
  separately so documentation / discovery / function-calling clients
  can describe paid tools without consuming them.

## Q5 lock

The unified-server-with-lazy-imports approach (vs separate
`kairos.mcp_pro` package) keeps the customer UX simple — one
`kairos mcp serve` CLI works for both tiers. License probe is a ~1ms
file read; conditional registration is essentially free.

## ATH-1063 Phase 0a-wiring commit 3

Adds 5 closed-loop callables wrapping `kairos.sec.closed_loop` +
`kairos.synth` + `kairos.cert` for engineer-as-customer dogfood:

* ``kairos_optimize_block`` — full propose-verify-bridge-iterate arc
* ``kairos_propose``        — proposer-only
* ``kairos_verify_equivalence`` — single-shot SEC verify with same-LLM bridge
* ``kairos_synth_delta``    — yosys + ABC gate-count delta
* ``kairos_inspect_cert``   — read prior-mint cert iteration arc

All five route through the same library code paths the v2.7 demo
dogfooded (Phase 0a-wiring 2a/2b). Same-LLM soundness rule is
schema-enforced (proposer_model_id required on
``kairos_verify_equivalence``).
"""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any, Callable


def _alias_from_model_id(model_id: str) -> str:
    """ATH-1307: derive a short alias from a litellm model_id string.

    Examples:
        anthropic/claude-sonnet-4-6      → sonnet
        anthropic/claude-opus-4-6        → opus
        anthropic/claude-haiku-4-5       → haiku
        gemini/gemini-3-flash-preview    → flash
        openai/kimi-k2.5                 → kimi
        openai/mistral-large-3           → mistral

    Falls back to the last hyphen-stripped token of the model name when
    no shortcut matches.
    """
    lowered = model_id.lower()
    for key, alias in (
        ("sonnet", "sonnet"),
        ("opus", "opus"),
        ("haiku", "haiku"),
        ("flash", "flash"),
        ("kimi", "kimi"),
        ("mistral", "mistral"),
    ):
        if key in lowered:
            return alias
    # Fallback: take the segment after the last `/` and strip versioning
    tail = model_id.rsplit("/", 1)[-1]
    return tail.split("-")[0] or model_id


def paid_tool_schemas() -> dict[str, dict[str, Any]]:
    """Return the JSON-schema definitions for paid-tier tools.

    Light-weight: imports only `kairos.mcp.schemas` (pure-data module,
    no paid feature imports). Safe to call without a license check
    when used for documentation / discovery only.

    Use case: a customer-facing docs site or a client that wants the
    full tool catalog regardless of tier (with `_paid: True` markers
    on the paid entries).
    """
    # Local import — keeps top-level kairos.mcp.pro_extensions module
    # cheap to import without pulling schemas eagerly.
    from kairos.mcp.schemas import KAIROS_PAID_TOOL_SCHEMAS
    return {k: dict(v) for k, v in KAIROS_PAID_TOOL_SCHEMAS.items()}


def load_paid_extensions() -> dict[str, Callable[..., Any]]:
    """Import and return paid-tier tool callables.

    Called by the MCP server (slice 3) after a successful
    :func:`kairos.license_scope.require_product` check. Importing this
    function's body triggers the paid module imports; until then the
    free-tier static-import-audit fence holds.

    :returns: dict mapping tool name → callable. Each callable is the
        Python entry point the MCP transport wraps as an MCP tool.

    :raises kairos.license_scope.LicenseScopeError: When called without
        a valid `solve` license (defense in depth — the function bodies
        of `lean_orchestrate.race` and `lean_orchestrate.solve` also
        gate, but failing fast at registration is cleaner UX).
    """
    # ATH-829 license-gate fail-fast. The MCP server SHOULD probe the
    # license before calling this; the gate here is a safety net for
    # callers that bypass that check.
    from kairos.license_scope import require_product
    require_product("solve")

    # NOW import the paid features. This is the line the static-import-
    # audit fence forbids in `kairos.mcp` itself; here it's gated behind
    # a license check inside a function call, so the audit passes.
    from pathlib import Path as _Path
    from kairos.lean_orchestrate import (
        ModelClientDrafter,
        race as _lean_race_raw,
        solve as _lean_solve_raw,
    )
    from kairos.lean_cycle import CycleTarget
    from kairos.ebmc import verify as _ebmc_verify
    from kairos.ebmc import solve as _ebmc_solve
    from kairos.sv.prove import prove as _sv_prove
    from kairos.sv.cegar import cegar as _sv_cegar
    from kairos.sv.flatten import flatten_files as _sv_flatten

    def _build_target_and_drafters(
        target_id: str,
        imports: list[str],
        opens: list[str],
        header: str,
        lake_project: str,
        module_path: str,
        drafters: list[str],
    ) -> tuple[CycleTarget, list[ModelClientDrafter]]:
        """ATH-1307 bridge — schema's JSON primitives → backend's object shape.

        The MCP schema decomposes the target object into individual fields
        (target_id, imports, opens, header, lake_project, module_path) so
        the LLM can call the tool from JSON. The backend takes a CycleTarget
        dataclass instance. This bridge assembles the dataclass.

        Same for drafters: the schema sends a list of model-ID strings; the
        backend takes a list of _DrafterProtocol handles. Each model_id
        becomes a ModelClientDrafter with the alias derived from the
        model-string (the alias surfaces in trace events).
        """
        target = CycleTarget(
            tid=target_id,
            imports=list(imports),
            opens=list(opens),
            header=header,
            lake_project=_Path(lake_project),
            module_path=module_path,
        )
        drafter_handles = [
            ModelClientDrafter(alias=_alias_from_model_id(m), model_id=m)
            for m in drafters
        ]
        return target, drafter_handles

    def _lean_race(
        *,
        target_id: str,
        imports: list[str],
        opens: list[str],
        header: str,
        lake_project: str,
        module_path: str,
        drafters: list[str],
        max_rounds: int = 4,
        temperature: float = 0.0,
        max_tokens: int = 800,
    ) -> Any:
        """ATH-1307 bridge handler for lean_race MCP tool."""
        target, drafter_handles = _build_target_and_drafters(
            target_id, imports, opens, header, lake_project, module_path, drafters,
        )
        return _lean_race_raw(
            target,
            drafter_handles,
            max_rounds=max_rounds,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    def _lean_solve(
        *,
        target_id: str,
        imports: list[str],
        opens: list[str],
        header: str,
        lake_project: str,
        module_path: str,
        drafters: list[str],
        internal_planner_model: str | None = None,
        try_simple_prove_first: bool = True,
        max_rounds: int = 4,
        n_per_drafter: int = 10,
        temperature: float = 0.7,
        max_tokens: int = 800,
    ) -> Any:
        """ATH-1307 bridge handler for lean_solve MCP tool."""
        target, drafter_handles = _build_target_and_drafters(
            target_id, imports, opens, header, lake_project, module_path, drafters,
        )
        return _lean_solve_raw(
            target,
            drafter_handles,
            internal_planner_model=internal_planner_model,
            try_simple_prove_first=try_simple_prove_first,
            max_rounds=max_rounds,
            n_per_drafter=n_per_drafter,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    tools: dict[str, Callable[..., Any]] = {
        "lean_race": _lean_race,
        "lean_solve": _lean_solve,
        "ebmc_verify": _ebmc_verify,
        "ebmc_solve": _ebmc_solve,
        "sv_prove": _sv_prove,
        "sv_cegar": _sv_cegar,
        "sv_flatten": _sv_flatten,
    }

    try:
        from kairos.acl2 import verify as _acl2_verify
        tools["acl2_verify"] = _acl2_verify
    except ImportError:
        pass

    # ATH-890: nki_port wraps the athanor-builder foundry orchestrator
    # that produces NKI kernel bundles from CUDA/Triton/PyTorch source.
    # The orchestrator lives in the athanor-builder package (not the
    # SDK), so we register a structured-error stub that points the
    # caller at the right next step. When the builder pipeline lands a
    # callable entry point in the SDK (or as a sibling pip package),
    # swap this stub for the real callable.
    def _nki_port(
        kernel_name: str,
        reference_source: str,
        reference_dialect: str,
        intent_summary: str,
        max_rounds: int = 4,
        timeout_sec: int = 1800,
    ) -> dict:
        return {
            "status": "builder_pipeline_not_available",
            "kernel_name": kernel_name,
            "reason": (
                "kairos.nki.port wraps the athanor-builder foundry "
                "orchestrator. That orchestrator is not callable from "
                "the SDK process today — it lives in athanor-builder "
                "and runs out-of-band. To produce a kernel bundle, "
                "invoke athanor-builder's solve/neuron/run.sh directly "
                "with the reference source. The bundle output path is "
                "compatible with kairos.nki.verify (this MCP tool's "
                "free-tier sibling)."
            ),
            "tracking_ticket": "ATH-226",
            "next_step": (
                "athanor-builder/solve/neuron/run.sh "
                f"<kernel_name={kernel_name}> "
                f"<dialect={reference_dialect}> --max-rounds "
                f"{max_rounds} --timeout-sec {timeout_sec}"
            ),
        }
    tools["nki_port"] = _nki_port

    # ATH-1063 closed-loop area-optimization callables. All five route
    # through kairos.sec.closed_loop + kairos.synth + kairos.cert library
    # functions; same code path the v2.7 demo dogfooded.
    tools["kairos_optimize_block"] = _kairos_optimize_block
    tools["kairos_optimize"] = _kairos_optimize
    tools["kairos_advise_flow"] = _kairos_advise_flow
    tools["kairos_propose"] = _kairos_propose
    tools["kairos_verify_equivalence"] = _kairos_verify_equivalence
    tools["kairos_synth_delta"] = _kairos_synth_delta
    tools["kairos_inspect_cert"] = _kairos_inspect_cert

    # ATH-1087 Phase B — assumption mining. Wraps mine_assumptions() from
    # kairos.sec.closed_loop.mine_assumptions. Paid tier: LLM proposal +
    # EBMC Mode 1 verification per assertion. Registered in PAID fence
    # (NOT free-tier) because it makes LLM calls + EBMC subprocess calls.
    try:
        from kairos.sec.closed_loop.mine_assumptions import (
            mine_assumptions as _mine_assumptions_impl,
        )

        def _kairos_mine_assumptions(
            bundle_path: str,
            target_module: str,
            model: str = "anthropic/claude-opus-4-6",
            max_assertions: int = 8,
            max_inner_retries: int = 2,
            k_bound: int = 32,
            timeout_sec: int = 60,
        ) -> dict:
            result = _mine_assumptions_impl(
                bundle_path=bundle_path,
                target_module=target_module,
                model=model,
                max_assertions=max_assertions,
                max_inner_retries=max_inner_retries,
                k_bound=k_bound,
                timeout_sec=timeout_sec,
            )
            return result.to_dict()

        tools["kairos_mine_assumptions"] = _kairos_mine_assumptions
    except ImportError as e:
        import logging as _logging
        _logging.getLogger(__name__).warning(
            "kairos.sec.closed_loop.mine_assumptions not importable: %s", e
        )

    return tools


# ─── ATH-1063 closed-loop callables ───────────────────────────────────


def _kairos_optimize_block(
    rtl_path: str,
    signature_path: str,
    vector: str = "gate_count",
    max_iterations: int = 3,
    model: str = "anthropic/claude-opus-4-6",
    k_induction_bound: int = 32,
    timeout_sec: int = 1800,
) -> dict[str, Any]:
    """MCP callable for ``kairos_optimize_block``.

    Drives the full propose-verify-bridge-iterate arc end-to-end via
    :func:`kairos.sec.closed_loop.run_closed_loop_orchestration`. Same
    code path the v2.7 demo dogfooded.

    The ``vector`` parameter is currently informational; gate-count is
    the only proxy fully wired (per Todd 2026-05-06 "rule of thumb is
    gates we want lower"). Power and timing vectors are stretch.
    """
    import json as _json

    from kairos.sec.closed_loop import run_closed_loop_orchestration

    sig = _json.loads(Path(signature_path).read_text())
    bundle = Path(signature_path).parent
    # Phase 1 Annapurna bundles use `target_module`; v2.7 toy_fifo_chain
    # uses `gold_module`. Accept both for ATH-1074 multi-module support.
    target_module = sig.get("gold_module") or sig.get("target_module")
    if not target_module:
        raise ValueError(
            f"signature.json at {signature_path} missing gold_module / "
            f"target_module"
        )

    result = run_closed_loop_orchestration(
        bundle_path=bundle,
        target_module=target_module,
        block_name=target_module,
        model=model,
        max_proposals=max_iterations,
        k_induction_bound=k_induction_bound,
        timeout_sec=timeout_sec,
    )

    iteration_arc: list[dict[str, Any]] = []
    for s in result.iteration_summaries:
        iteration_arc.append({
            "iteration_index": s["iteration_index"],
            "transformation_class": s["transformation_class"],
            "claimed_area_delta_pct": s["claimed_area_delta_pct"],
            "outcome": s["outcome"],
            "outcome_reason": s["outcome_reason"],
            "bridges_used": s["bridges_used"],
        })

    return {
        "run_id": result.parent_run_id,
        "iteration_arc": iteration_arc,
        "halt_reason": result.halt_reason,
        "cert_path": "",
        "dashboard_url": (
            f"/analytics/silicon-blocks/{result.parent_run_id}"
        ),
    }


def _kairos_advise_flow(
    config: str = "{}",
    prompt: str = "",
) -> dict[str, Any]:
    """MCP tool: validate a proposed flow before running it.

    ATH-1118 deliverable 6. Customer's agent calls this to check
    if their configuration is safe. Returns structured advice with
    errors + suggestions.
    """
    import json as _json
    from kairos.sec.closed_loop.flow_guard import advise_flow

    config_dict = _json.loads(config) if config and config != "{}" else None
    prompt_text = prompt if prompt else None
    return advise_flow(config_dict=config_dict, prompt_text=prompt_text)


def _kairos_optimize(
    rtl_path: str,
    dep_paths: str = "",
    params: str = "",
    model: str = "anthropic/claude-sonnet-4-6",
    max_proposals: int = 3,
    timeout_sec: int = 1800,
) -> dict[str, Any]:
    """One-command optimization: auto-detect + bundle + orchestrate.

    ATH-1115 sub-4. The customer-facing MCP tool. No pre-built bundle
    needed. Auto-detects clock/reset, extracts params, selects engine.

    Args:
        rtl_path: path to the gold RTL file
        dep_paths: comma-separated paths to dependency RTL files
        params: comma-separated KEY=VAL parameter overrides
        model: LLM model for the proposer
        max_proposals: number of optimization candidates
        timeout_sec: per-engine verification timeout
    """
    from kairos.sec.closed_loop.optimize_cli import optimize

    if isinstance(dep_paths, list):
        deps = dep_paths or None
    else:
        deps = [p.strip() for p in dep_paths.split(",") if p.strip()] if dep_paths else None
    if isinstance(params, dict):
        param_dict = params
    elif params:
        param_dict = {}
        for kv in str(params).split(","):
            if "=" in kv:
                k, v = kv.split("=", 1)
                try:
                    param_dict[k.strip()] = int(v.strip())
                except ValueError:
                    param_dict[k.strip()] = v.strip()
    else:
        param_dict = {}

    result = optimize(
        rtl_path=rtl_path,
        dep_paths=deps,
        param_overrides=param_dict or None,
        model=model,
        max_proposals=max_proposals,
        timeout_sec=timeout_sec,
    )

    iteration_arc = []
    for s in result.iteration_summaries:
        iteration_arc.append({
            "iteration_index": s["iteration_index"],
            "transformation_class": s["transformation_class"],
            "claimed_area_delta_pct": s["claimed_area_delta_pct"],
            "outcome": s["outcome"],
            "outcome_reason": s["outcome_reason"],
        })
    return {
        "run_id": result.parent_run_id,
        "halt_reason": result.halt_reason,
        "n_accepted": result.n_accepted(),
        "iteration_arc": iteration_arc,
    }


def _kairos_propose(
    rtl_path: str,
    signature_path: str,
    vector: str = "gate_count",
    max_proposals: int = 3,
    model: str = "anthropic/claude-opus-4-6",
    timeout_sec: int = 120,
) -> dict[str, Any]:
    """MCP callable for ``kairos_propose``.

    Proposer-only; returns ranked transformation candidates without
    running formal verification. Caller composes with
    :func:`kairos_verify_equivalence` to run the verify step
    separately, passing back ``model_used`` + ``session_id`` to maintain
    the same-LLM soundness rule.
    """
    import json as _json

    from kairos.sec.closed_loop import propose_transformations

    sig = _json.loads(Path(signature_path).read_text())
    bundle = Path(signature_path).parent
    target_module = sig.get("gold_module") or sig.get("target_module")
    if not target_module:
        raise ValueError(
            f"signature.json at {signature_path} missing gold_module / "
            f"target_module"
        )

    proposal_run = propose_transformations(
        bundle_path=bundle,
        target_module=target_module,
        model=model,
        max_proposals=max_proposals,
        timeout_sec=timeout_sec,
    )

    proposals: list[dict[str, Any]] = []
    for p in proposal_run.proposals:
        proposals.append({
            "transformation_class": p.transformation_class.value,
            "transformation_description": (
                p.rationale.split("\n\n", 1)[0]
                if "\n\n" in p.rationale
                else p.rationale[:160]
            ),
            "proposed_gate_sv": p.gate_sv,
            "claimed_area_delta_pct": p.claimed_area_delta_pct,
            "rationale": p.rationale,
        })

    return {
        "proposals": proposals,
        "model_used": model,
        "session_id": str(uuid.uuid4()),
    }


def _kairos_verify_equivalence(
    gold_path: str,
    gate_path: str,
    signature_path: str,
    proposer_model_id: str,
    bridge_invariants: list[str] | None = None,
    proposer_session_id: str | None = None,
    k_induction_bound: int = 32,
    timeout_sec: int = 300,
) -> dict[str, Any]:
    """MCP callable for ``kairos_verify_equivalence``.

    Single-shot SEC verify. BMC initial verdict; on FAIL/INCONCLUSIVE,
    escalates to k-induction with bridge invariants generated by the
    proposer model (same-LLM soundness rule).

    The ``proposer_model_id`` parameter is schema-required; this is the
    soft enforcement of the same-LLM rule (the bridge generator uses
    this model id when it needs to write bridges). The
    ``proposer_session_id`` is currently informational; tighter
    same-session enforcement is a follow-up.

    Pre-authored ``bridge_invariants`` (when supplied) are written into
    the miter as ``assume property`` clauses before k-induction; in
    that mode, no bridge generator runs and the verdict reflects the
    invariants as-given.
    """
    import json as _json

    from kairos.sec import verify_sec
    from kairos.sec._adapter import _ports_from_signature
    from kairos.sec.closed_loop import generate_invariant
    from kairos.sec.closed_loop._miter_inject import (
        InjectionTarget,
        inject_assume_property,
    )

    sig = _json.loads(Path(signature_path).read_text())
    ports = _ports_from_signature(sig)
    gold_module = sig["gold_module"]
    gate_module = sig["gate_module"]

    gold_p = Path(gold_path)
    gate_p = Path(gate_path)
    work_dir = gold_p.parent / "_sec_work_verify"
    work_dir.mkdir(parents=True, exist_ok=True)

    bmc_result = verify_sec(
        gold_sv=gold_p,
        gate_v=gate_p,
        gold_module=gold_module,
        gate_module=gate_module,
        ports=ports,
        mode="bmc",
        bound=k_induction_bound,
        clock_port=sig.get("clock_port", "clk"),
        reset_port=sig.get("reset_port", "rst_n"),
        reset_active_low=sig.get("reset_active_low", True),
        timeout_sec=timeout_sec,
        work_dir=work_dir,
    )

    bmc_log = work_dir / "ebmc_bmc.stdout"
    if bmc_result.proved:
        return {
            "outcome": "accepted",
            "outcome_reason": "EBMC BMC verifier proved equivalence at bound k",
            "bridge_label": "",
            "bridge_text": "",
            "ebmc_bmc_log_path": str(bmc_log) if bmc_log.exists() else "",
            "ebmc_kinduction_log_path": "",
        }
    if bmc_result.refuted:
        return {
            "outcome": "refuted",
            "outcome_reason": (
                "EBMC BMC verifier returned counter-example trace; "
                "candidate is NOT equivalent to gold under the given bound"
            ),
            "bridge_label": "",
            "bridge_text": "",
            "ebmc_bmc_log_path": str(bmc_log) if bmc_log.exists() else "",
            "ebmc_kinduction_log_path": "",
        }

    if bridge_invariants:
        miter_path = work_dir / "miter.sv"
        if miter_path.exists():
            for idx, inv_text in enumerate(bridge_invariants):
                inject_assume_property(
                    miter_path,
                    InjectionTarget(
                        label=f"caller_bridge_{idx}",
                        sv_expression=inv_text,
                        proves_obligation=None,
                    ),
                )
        return {
            "outcome": "inconclusive",
            "outcome_reason": (
                "Caller-provided bridge invariants written to miter; "
                "k-induction follow-up requires re-invoking verify_sec "
                "in mode='k_induction' (not yet driven by this callable)"
            ),
            "bridge_label": "caller_bridges",
            "bridge_text": "; ".join(bridge_invariants),
            "ebmc_bmc_log_path": str(bmc_log) if bmc_log.exists() else "",
            "ebmc_kinduction_log_path": "",
        }

    bundle_for_ig = work_dir.parent
    target_property = next(
        (
            p for p, v in bmc_result.property_verdicts.items()
            if v.lower() in ("inconclusive", "refuted")
        ),
        "sec_miter.full_match",
    )
    try:
        ig_result = generate_invariant(
            bundle_path=bundle_for_ig,
            target_property=target_property,
            bound=k_induction_bound,
            timeout_sec=timeout_sec,
        )
    except Exception as e:  # noqa: BLE001
        return {
            "outcome": "inconclusive",
            "outcome_reason": (
                f"Bridge-invariant generator raised "
                f"{type(e).__name__} before producing a closeable "
                f"candidate"
            ),
            "bridge_label": "",
            "bridge_text": "",
            "ebmc_bmc_log_path": str(bmc_log) if bmc_log.exists() else "",
            "ebmc_kinduction_log_path": "",
        }

    if ig_result.closed and ig_result.chosen is not None:
        return {
            "outcome": "accepted",
            "outcome_reason": (
                f"k-induction PASS under assume-property bridge "
                f"{ig_result.chosen.label}"
            ),
            "bridge_label": ig_result.chosen.label,
            "bridge_text": ig_result.chosen.sv_expression,
            "ebmc_bmc_log_path": str(bmc_log) if bmc_log.exists() else "",
            "ebmc_kinduction_log_path": "",
        }
    if ig_result.halt_reason == "hard_refute":
        return {
            "outcome": "refuted",
            "outcome_reason": (
                "k-induction hard_refute under bridge attempts: "
                "semantic divergence"
            ),
            "bridge_label": "",
            "bridge_text": "",
            "ebmc_bmc_log_path": str(bmc_log) if bmc_log.exists() else "",
            "ebmc_kinduction_log_path": "",
        }
    return {
        "outcome": "inconclusive",
        "outcome_reason": (
            f"Bridge-invariant generator halted: "
            f"{ig_result.halt_reason or 'unknown'}"
        ),
        "bridge_label": "",
        "bridge_text": "",
        "ebmc_bmc_log_path": str(bmc_log) if bmc_log.exists() else "",
        "ebmc_kinduction_log_path": "",
    }


def _kairos_synth_delta(
    gold_path: str,
    gate_path: str,
    top_module: str,
    abc_script: str | None = None,
    timeout_sec: int = 300,
) -> dict[str, Any]:
    """MCP callable for ``kairos_synth_delta``.

    Runs yosys synth + ABC technology mapping on both gold and gate,
    returns gate counts + delta + verbatim synth log path.

    The synth log ships in cert tarballs verbatim per Aidan 2026-05-06
    customer-tarball engine-output rule. Caller is responsible for
    copying the log into the cert bundle.
    """
    from kairos.synth import yosys_gate_count

    gold_log_dir = Path(gold_path).parent / "_synth_gold"
    gate_log_dir = Path(gate_path).parent / "_synth_gate"

    gold_result = yosys_gate_count(
        rtl_path=gold_path,
        top_module=top_module,
        abc_script=abc_script,
        timeout_sec=timeout_sec,
        log_dir=gold_log_dir,
    )
    gate_result = yosys_gate_count(
        rtl_path=gate_path,
        top_module=top_module,
        abc_script=abc_script,
        timeout_sec=timeout_sec,
        log_dir=gate_log_dir,
    )

    delta_gates = gate_result.gate_count - gold_result.gate_count
    delta_pct = (
        100.0 * delta_gates / gold_result.gate_count
        if gold_result.gate_count > 0
        else 0.0
    )

    return {
        "gold_gate_count": gold_result.gate_count,
        "gate_gate_count": gate_result.gate_count,
        "delta_gates": delta_gates,
        "delta_pct": delta_pct,
        "synth_log_path": gate_result.log_path,
    }


def _kairos_inspect_cert(cert_path: str) -> dict[str, Any]:
    """MCP callable for ``kairos_inspect_cert``.

    Reads a cert bundle directory (or extracted .tgz) and returns the
    structured iteration arc. Looks for ``iteration_arc.json`` in the
    bundle root; falls back to building from per-iteration directories
    when present.

    The returned ``live_render_url`` is built from the cert's
    ``run_id``; engineer can hand it back to the customer for visual
    review without re-running the cert.
    """
    import json as _json

    cert_p = Path(cert_path)
    if not cert_p.exists():
        raise FileNotFoundError(f"cert_path not found: {cert_p}")

    if cert_p.is_file() and cert_p.suffix in (".tgz", ".gz"):
        import tarfile
        import tempfile

        extract_dir = Path(tempfile.mkdtemp(prefix="kairos_cert_inspect_"))
        with tarfile.open(cert_p, "r:gz") as tf:
            tf.extractall(extract_dir)
        roots = [p for p in extract_dir.iterdir() if p.is_dir()]
        bundle_dir = roots[0] if roots else extract_dir
    else:
        bundle_dir = cert_p

    arc_path = bundle_dir / "iteration_arc.json"
    if arc_path.is_file():
        arc_data = _json.loads(arc_path.read_text())
        run_id = arc_data.get("run_id", "")
        halt_reason = arc_data.get("halt_reason", "")
        iteration_arc = arc_data.get("iteration_arc", [])
    else:
        manifest_path = bundle_dir / "manifest.json"
        run_id = ""
        halt_reason = ""
        iteration_arc = []
        if manifest_path.is_file():
            try:
                m = _json.loads(manifest_path.read_text())
                run_id = m.get("run_id", "")
                halt_reason = m.get("halt_reason", "")
            except Exception:  # noqa: BLE001
                pass

    accepted = sum(
        1 for it in iteration_arc if it.get("outcome") == "accepted"
    )
    refuted = sum(1 for it in iteration_arc if it.get("outcome") == "refuted")
    inconclusive = sum(
        1 for it in iteration_arc if it.get("outcome") == "inconclusive"
    )

    bridges: list[dict[str, Any]] = []
    for it in iteration_arc:
        for label in it.get("bridges_used", []):
            bridges.append({
                "iteration_index": it.get("iteration_index", -1),
                "label": label,
                "text": "",
            })

    return {
        "run_id": run_id,
        "halt_reason": halt_reason,
        "iteration_arc": iteration_arc,
        "verdict_mix": {
            "accepted": accepted,
            "refuted": refuted,
            "inconclusive": inconclusive,
        },
        "bridge_invariants": bridges,
        "live_render_url": (
            f"/analytics/silicon-blocks/{run_id}" if run_id else ""
        ),
    }


__all__ = [
    "load_paid_extensions",
    "paid_tool_schemas",
]
