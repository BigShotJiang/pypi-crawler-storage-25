'''
Created on 21 Sept 2025

@author: alex
'''
import pandas as pd
from pathlib import Path
from pandas.core.frame import DataFrame
import os
from homebrewlibra.data_tools.__init__ import __OHLCVD_COLUMNS
from homebrewlibra.helper_market.convert_timestamp_date import parse_unix_ts, make_col_unique
from homebrewlibra.helper_market.trades_fields import numercal_col

import logging
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
__logger = logging.getLogger(__name__)


def load_csv_trades(path, convert_timestamp='timestamp', index_col=None, convert_2_floats=None)->DataFrame:
  df = pd.read_csv(path)               
  if isinstance(convert_timestamp,str) and convert_timestamp in df.columns:
    df[convert_timestamp]=parse_unix_ts(df[convert_timestamp])
    __logger.info(f"Columns '{convert_timestamp}' converted to datetime format ")
  numercal_col(df,col=convert_2_floats,inplace=True)
  if isinstance(index_col,str) :
    if index_col in df.columns:
      df = df.set_index(index_col).sort_index()
      __logger.info(f"loaded history {len(df)} records from {df.index.min()} to {df.index.max()}\n columns {df.columns} from file {path} ") 
    else:
      __logger.warning(f"loaded history {len(df)} records. field {index_col} , so no index setup ")
  else:    
      __logger.info(f"loaded history {len(df)} records\n columns {df.columns} from file {path} No indexing ") 
  return df 

# Columns are usually: open, high, low, close, volume
def save_csv_trades(df_data:DataFrame,file_path=None,unique_col=None):
  if(os.path.exists(file_path)):
    __logger.warning(f" override file {file_path} ")
  if isinstance(unique_col,str) and unique_col in df_data.columns:
    tmp=make_col_unique(df_data,unique_col=unique_col)
  else:
    tmp=df_data
  res = tmp.to_csv(file_path)
  __logger.info(f" response has {len(df_data)}  records, {len(tmp)} unique records were saved to {file_path} with result {res}")
  del tmp
  return res 

# If you need only OHLCV:
if __name__ == "__main__":
# Example path pattern used by Freqtrade:
# user_data/data/<exchange>/<pair>/<timeframe>.feather
  path = Path("user_data/data/BTC_USDC-1m.feather",follow_symlinks=True)  # adjust to your layout
  df=load_csv_trades(path)
  df.reset_index(inplace=True)
  ohlcv = df[__OHLCVD_COLUMNS]
  print(ohlcv.head())
  path = Path("user_data/feather/BTC_USDC-trades.feather",follow_symlinks=True)
  res = save_csv_trades(df,path)
