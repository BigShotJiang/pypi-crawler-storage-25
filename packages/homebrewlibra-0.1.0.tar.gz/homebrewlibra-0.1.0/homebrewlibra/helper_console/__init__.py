import pandas as pd 
#setup console size 
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1400)
pd.set_option('display.max_colwidth', 35)
print(" → Wide pandas display activated")
console_options_set=True
__all__ = [
  "console_options_set"
  ]
  