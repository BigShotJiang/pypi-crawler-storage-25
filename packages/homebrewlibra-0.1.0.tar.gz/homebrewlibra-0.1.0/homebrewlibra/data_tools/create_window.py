'''
Created on 27 Feb 2026

@author: alex
'''
import numpy as np 
from typing import Tuple, Optional, Union
import logging 
__logger = logging.getLogger(__name__)




def filter_valid_pivots(
    pivots: np.ndarray,
    n_time: int,
    window_size: int = 1, # just current value )
    horizon: int = 1,
) -> np.ndarray:
    """
    Returns only those pivot indices (window END positions) that are valid,
    i.e. have enough history before them and enough future after them.

    Parameters
    ----------
    pivots : np.ndarray
        Candidate window-end indices (0-based)
    n_time : int
        Total number of time steps in the data
    window_size : int
        Required length of input window
    horizon : int
        How many steps ahead the target is (0 = predict current end, 1 = next step, ...)

    Returns
    -------
    valid_pivots : np.ndarray
        Filtered array of valid pivot indices, sorted if input was sorted
    """
    pivots = np.asarray(pivots, dtype=np.int64).ravel()

    # Minimum pivot index needed to have full window
    min_pivot = window_size - 1

    # Maximum pivot index so that pivot + horizon is still inside data
    max_pivot = n_time - horizon -1# 

    valid_mask = (pivots >= min_pivot) & (pivots <= max_pivot)

    return pivots[valid_mask]



def check_params_values(y, denominator, n_time, n_features,  window_size, horizon, axis):
# ────────────────────────────────────────────────
#  Prepare inputs
# ────────────────────────────────────────────────
  if axis != 0:
    raise NotImplementedError("Only axis=0 is currently supported.")
  if denominator is None:
    denominate_flag=False
    denominator=np.ones(shape=(n_time))
  else:
    denominate_flag=True
    denominator = np.asarray(denominator).ravel()
  if len(denominator) != n_time:
    raise ValueError("denominator length must match x_orig time dimension")
  if y is not None and y.shape[0] != n_time:
    raise ValueError("y must have same time dimension as x_orig")
  if window_size < 1:
    raise ValueError("window_size >= 1 required")
  if horizon < 0:
    raise ValueError("horizon >= 0 required")

  return denominate_flag
# ────────────────────────────────────────────────
#  Prepare inputs
# ────────────────────────────────────────────────

def create_window(
    x_orig: np.ndarray,
    y_orig: Optional[np.ndarray],
    denominator: np.ndarray| None=None,
    window_size: int=1, # just one current X
    horizon: int = 0, # one ahead
    axis: int = 0,
    pivots: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """

    Creates normalized sliding windows for Conv1D / time-series models.
    
    For each valid pivot p (window END index):
        - Takes x_orig[p - window_size + 1 : p + 1]
        - Divides the ENTIRE window by denominator[p]  (exactly the formula you wanted)
        - Collects into 3D array (n_samples, window_size, n_features)
    
    Parameters
    ----------
    x_orig : np.ndarray
        Features. Shape (n_time, n_features) or (n_time,) for univariate.
    y_orig : np.ndarray or None
        Targets. Shape (n_time,) or (n_time, n_targets).
    denominator : np.ndarray
        1D array of length n_time to divide by (value at window END).
    window_size : int
        Length of each input window (>= 1).
    horizon : int
        How many steps ahead the target is (default 1).
    axis : int
        Currently only 0 is supported (time axis). You can extend later.
    pivots : np.ndarray
        Candidate window-end indices (0-based). Only valid ones are kept.
        If pivots is None → uses all possible valid positions.
    
    Returns
    -------
    X_windows : np.ndarray
        Shape (n_valid_windows, window_size, n_features)
        → ready for Conv1D / LSTM / Transformer input.
    y_matched_or_indices : np.ndarray
        If y_orig is not None  → actual target values at (pivot + horizon)
        If y_orig is None      → array of target indices (so you can do y_orig[indices] later)
        Creates normalized sliding windows.

    """
    # ────────────────────────────────────────────────
    #  Prepare inputs
    # ────────────────────────────────────────────────
    if x_orig.ndim == 1:
      x_orig = x_orig.reshape(-1, 1)
    n_time, n_features = x_orig.shape
    if y_orig is not None:
      y_orig = np.asarray(y_orig)

    denominate_flag = check_params_values(y_orig, denominator, n_time, n_features, window_size, horizon, axis)

    # ────────────────────────────────────────────────
    #  Determine pivots
    # ────────────────────────────────────────────────
    if pivots is None:
        # Use every possible valid end position
        pivots = np.arange(n_time)

    valid_pivots = filter_valid_pivots(
        pivots=pivots,
        n_time=n_time,
        window_size=window_size,
        horizon=horizon,
    )

    num_samples = len(valid_pivots)

    if num_samples == 0:
        # Early return with correct empty shapes
        X_empty = np.empty((0, window_size, n_features), dtype=x_orig.dtype)
        if y_orig is not None:
            y_empty = np.empty((0,) + y_orig.shape[1:], dtype=y_orig.dtype)
        else:
            y_empty = np.empty((0,), dtype=np.int64)
        return X_empty, y_empty

    # ────────────────────────────────────────────────
    #  Build X windows
    # ────────────────────────────────────────────────
    X_windows = np.empty((num_samples, window_size, n_features), dtype=x_orig.dtype)
    window_a = np.array(range(-window_size+1,+ 1))
    for k, p in enumerate(valid_pivots):
        window_data = x_orig[window_a+p] #(0 : window_size)+p ]
        if denominate_flag:
          window_data /= denominator[p]
        X_windows[k] = window_data
    # ────────────────────────────────────────────────
    #  Build targets / indices
    # ────────────────────────────────────────────────
    target_indices = valid_pivots + horizon

    if y_orig is not None:
        y_matched = y_orig[target_indices]
    else:
        y_matched = target_indices

    return X_windows, y_matched
  