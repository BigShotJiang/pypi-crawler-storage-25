DEFAULT_TRADES_COLUMNS = ['timestamp', 'id',      'price', 'amount',  'side',     'type',         'cost']
TRADES_2_OHLCV_COLUMNS = [
  'date','open','high','low','close','volume',
  'miscellaneous',
  'volume_sell',
  'volume_buy',
  'customers_sell',
  'customers_buy',

  ]
# fields  in order as it come from exchange
CONVERT_TRADES_COLUMNS = {
  'kraken': {
    'price':'price',
    'amount':'volume',
    'timestamp':'timestamp',
    'buy/sell': 'side',
    'market/limit':'type',
    'miscellaneous':'misc',
    'trade_id':'id',

    }
  }
__OHLCVD_COLUMNS       = ['date','open','high','low','close','volume']
__fields_names_kraken={
  'amount':'volume',
  'side'  :'buy/sell',
  '*buy'   :'b',
  '*sell'  :'s',
  'type'  :'market/limit',
  '*market':'m',
  '*limit' :'l',
  'price' :'price',
  'id'    :'trade_id',
  'timestamp':'timestamp',
  'cost':'misc'

  }
__fields_names_freqtrade={
  'amount' :'amount',
  'side'   :'side',
  '*buy'    :'buy',
  '*sell'   :'sell',
  'type'   :'type',
  '*market' :'market',
  '*limit'  :'limit',
  'price'  :'price',
  'id'     :'id',
  'timestamp':'timestamp',
  'cost':'cost'
  }
__fields_names_dict={
  'kraken': __fields_names_kraken,
  'freqtrade': __fields_names_freqtrade
  }

__all__=[
  '__TIMEFRAME_MAX',
  '__TRADES_COLUMNS',
  '__OHLCVD_COLUMNS',
  'TRADES_2_OHLCV_COLUMNS',
  '__fields_names_dict',
  ]
