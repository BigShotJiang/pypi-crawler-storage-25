'''
Created on 31 Jan 2026

@author: alex
'''
from pathlib import Path 
import argparse
import logging
from datetime import datetime, timezone

__logger = logging.getLogger(__name__)

def parse_args(**kwargs):
    base_path=kwargs.get('base_path')
    base_data=kwargs.get('base_data') 
    base_models=kwargs.get('base_models') 
    base_results=kwargs.get('base_results')
    file_path_template=kwargs.get('file_path_template') 
    periods_list=kwargs.get('periods_list')
    pair_list=kwargs.get('pair_list')
    ALLOWED_COMMANDS = kwargs.get('ALLOWED_COMMANDS')
    parser = argparse.ArgumentParser(
        description="Market Data processing project ",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter   # THIS LINE IS GOLD
    )
    # ── PAIRS ─────────────────────────────────────────────────────
    parser.add_argument(
      'command',
      nargs='*',                               # ← makes it optional
      default=ALLOWED_COMMANDS[0],  # ← used when nothing is given
      choices=ALLOWED_COMMANDS,
      help="Command to execute (default: %(default)s)"
      )
    parser.add_argument(
        '-p', '--pairs',
        nargs='+',
        default=pair_list,           # ← your real default
        metavar='PAIR',
        help='Space-separated list of trading pairs (default: %(default)s)'
    )
# need to review 
    parser.add_argument(
        '--file_path_template',
        type=str,
        default=str(file_path_template),
        metavar='STR',
        help='Mask forming file name for history data ( default: %(default)s)'
    )

    # ── TIMERANGE ────────────────────────────────────────────────
    parser.add_argument(
        '--periods_list',
        type=str,
        nargs='?',
        default=periods_list,
        metavar='YYYYMMDD',                      # ← example: from 2025-11-16 to now
        help='Timerange in format: YYYYMMDD  (default: %(default)s)'
    )

    parser.add_argument(
        '--periods_dev',
        type=str,
        nargs='+',
        default=periods_list[-2:-2],
        metavar='YYYYMMDD',                      # ← example: from 2025-11-16 to now
        help='Timerange for validation in format: YYYYMMDD  (default: %(default)s)'
    )

    parser.add_argument(
        '--periods_test',
        type=str,
        nargs='+',
        default=periods_list[-1:-1],
        metavar='YYYYMMDD',                      # ← example: from 2025-11-16 to now
        help='Timerange for validation in format: YYYYMMDD  (default: %(default)s)'
    )
    # ── OTHER COMMON OPTIONS (add whatever you need) ─────────────
    parser.add_argument(
        '--exchange', '-e',
        type=str,
        default=str('kraken'),
        metavar='EXCHANGE',
        help='Crypto exchange name (kraken only implemented )'
    )
    parser.add_argument(
        '--base_path', '-b',
        type=Path,
        default=Path(base_path,follow_symlinks=True),
        metavar='PATH',
        help='directory for files'
    )
    parser.add_argument(
        '--base_data','-d',
        type=Path,
        default=Path(base_data,follow_symlinks=True),
        metavar='PATH',
        help='directory for prepared history data files '
    )
    parser.add_argument(
        '--base_models','-m',
        type=Path,
        default=Path(base_models,follow_symlinks=True),
        metavar='PATH',
        help='directory for prepared models files '
    )
    parser.add_argument(
        '--base_results','-r',
        type=Path,
        default=Path(base_results),
        metavar='PATH',
        help='directory for model results  files '
    )
    parser.add_argument(
      '--force_update','-f',
      action='store_true',
      default=False,  # ← used when nothing is given
      help="force update/compute files (default: %(default)s)"
      )
    parser.add_argument(
      '--update','-u',
      action='store_true',
      default=False,  # ← used when nothing is given
      help="update/continue load data (default: %(default)s) its depend on \n"\
        "implementation set functions.\n"\
        "implemented in download data from exchange , \n"\
        "processing other files are WILL RECREATE for now "
      )
    parser.add_argument(
      '--market_type','-t',
      type=str,
      nargs='?',                               # ← makes it optional
      choices=['buy','sel'],
      default='buy',  # ← used when nothing is given
      help="type of market 'buy' or 'sell' (default: %(default)s)"
      )
    parser.add_argument(
      '--epochs',
      type=int,
      nargs='?',                               # ← makes it optional
      default=50,  # ← used when nothing is given
      help="default number of epoch ' (default: %(default)s)"
      )
    parser.add_argument(
      '--batches',
      type=int,
      nargs='?',                               # ← makes it optional
      default=32,  # ← used when nothing is given
      help="default batch size' (default: %(default)s)"
      )

    args = parser.parse_args()

    # ── POST-PROCESSING (very useful) ─────────────────────────────
    # Make sure output dir exists
    if args.periods_list is None:
      args.periods_list = datetime.now(timezone.utc).strftime("%Y%m") + "01"
    if len(args.periods_test) == 0 :
      args.periods_test = datetime.now(timezone.utc).strftime("%Y%m") + "01"
    #args.base_data.mkdir(parents=True, exist_ok=True)
    #args.base_models.mkdir(parents=True, exist_ok=True)
    #args.base_path.mkdir(parents=True, exist_ok=True)
    #args.base_results.mkdir(parents=True, exist_ok=True)
    
    __logger.info("\n=== CONFIGURATION ===")
    for key, value in args._get_kwargs():
      __logger.info(f"{key:12} : {value}")
    __logger.info("\n=== CONFIGURATION ===")  
  

    return args
