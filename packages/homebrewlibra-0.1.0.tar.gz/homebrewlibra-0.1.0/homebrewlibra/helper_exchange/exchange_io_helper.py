'''
Created on 9 Jan 2026

@author: alex
'''
import pandas as pd
from datetime import datetime, timezone# , tzinfo#, timedelta
from pandas.core.frame import DataFrame
from types import NoneType
from time import sleep
from homebrewlibra.helper_market.convert_timestamp_date import utc_string_to_timestamp,\
  make_col_unique
from homebrewlibra.data_tools.__init__ import CONVERT_TRADES_COLUMNS
from homebrewlibra.helper_data.set_default_index import set_default_index
#----------
import http.client
import urllib.request
import urllib.parse
import hashlib
import hmac
import base64
import json
import time
import requests
from homebrewlibra.helper_exchange.exchange_io_kraken import KrakenExchange
#from homebrewlibra.helper_exchange.exchange_io_binance import BinanceExchange
from homebrewlibra.helper_data.set_default_index import set_default_index
from homebrewlibra.helper_market.convert_trades_to_OHLCV import normalize_trades_column_names
# The format code string matching the input string
# %Y for year (e.g., 2025)
# %m for month (e.g., 11)
# %d for day (e.g., 15)
# %H for hour (24-hour format, e.g., 10)
# %M for minute (e.g., 01)
# %S for second (e.g., 00)
format_str = "%Y-%m-%dT%H:%M:%SZ"

import logging
__logger = logging.getLogger(__name__)



def load_trades_exchange(
    exchange:str='kraken',
    pair:str="BTCAUD",
    count:int=1000, 
    since:str | datetime | None  = None, 
    last_date:str | datetime | None = None, 
    format_date_str:str=format_str,
    **kwarg 
    )->dict:
  if exchange.lower().__eq__("kraken"):
    exch=KrakenExchange()
  elif exchange.lower().__eq__("binance"):
    exch= BinanceExchange()
  else:
    raise ValueError(f"exchange {exchange} not implemented ")
  ddf:dict={"__since": since}
  timestamp_from = since.timestamp()#.astype('float64')
  timestamp_finish = last_date.timestamp()#.astype('float64')
  if 'ddf' in kwarg.keys(): # exiting data
    pdf = kwarg.pop("ddf",None)
    if isinstance(pdf,DataFrame) and 'timestamp' in pdf.columns: # compare all
#      pdf = set_default_index(pdf,default_index='timestamp') 
#     will use directly access to the nax ID number last 
      #database should be de-indexed  
      if 'timestamp' in pdf.index.names:
        pdf.reset_index(drop=False,inplace=True)
      if 'timestamp' in pdf.columns:
        #tmp1  = pdf['timestamp'].iloc[-1].timestamp()#*1000000.0
        mid = pdf['id'].max()
        tmp = pdf.loc[pdf['id'] == mid, 'timestamp'].iloc[0].timestamp()
      else:
        tmp = 0.0
        __logger.error(f"error - no 'timestamp' column found ")
      
      if tmp < timestamp_from:
        __logger.warning(f"passed 'ddf' item last record is "\
                         f"<{pd.to_datetime(tmp, unit='s')}> less then "\
                         f"<{pd.to_datetime(timestamp_from, unit='s')}> from which we start" 
                         )
      else:
        #save passed base to start from and change start index 
        timestamp_from = tmp
        #pdf.reset_index(drop=False,inplace=True)
        pdf=set_default_index(df=pdf,default_index='id') #set index of records id 
        pdf.reset_index(inplace=True, drop=False)
        ddf[pair]=pdf 
      ddf[ "__since" ] = timestamp_from
      __logger.info(f"passed  'ddf' item has data so we continue load from  {pd.to_datetime(timestamp_from, unit='s')}")  
    else:
      __logger.warning(f"passed  'ddf' item is not DataFrame with 'timestamp' field load from {pd.to_datetime(timestamp_from, unit='s')}")  
  else:
    __logger.info(f"No passed  'ddf' item, so we start load from  {pd.to_datetime(timestamp_from, unit='s')}")  
      
  exchange_columns_name= CONVERT_TRADES_COLUMNS.get(exchange,'kraken') 
  # loop(timestamp_begin<timestamp_finish:
  print(  f"Time up to   :{pd.to_datetime(timestamp_finish, unit='s')} -- {timestamp_finish}")
  while(True):
    print(f"{pair} since :{pd.to_datetime(timestamp_from, unit='s')} -- {pd.to_datetime(timestamp_finish, unit='s')}")
    if(timestamp_from >= timestamp_finish): # exit this loop
      break
    #   load data from exchange
    try:
      response = exch.query(pair, timestamp_from) # timestamp in unix time 
    except requests.exceptions.RequestException as e:
      __logger.exception(e)
    except ResourceWarning as e:
        __logger.info(f" {e} for expected date {pd.to_datetime(timestamp_finish, unit='s')} {pd.to_datetime(timestamp_from, unit='s')}")
        sleep (10)
        continue # with the same data 

    try:
      resdict = response.get("result")
      resdict.pop('last',None)
      for cpair in resdict.keys():
#        if cpair.lower() == "last":
##          lastrecord = float(int(resdict[cpair])+1)/1000000000.0
#          lastrecord  = resdict[cpair]         
##          timestamp_from =  np.float64(lastrecord[:len(lastrecord)-9] + "." + lastrecord[len(lastrecord)-9:-1])
#          continue
        # FIELDS ORDER MIGHT BE DIFFEREN FOR TABLE IN DDF use columns from __ini__ is safer 
        pdf:DataFrame = pd.DataFrame(resdict[cpair],columns=list(exchange_columns_name.items().mapping.values()))
        pdf = normalize_trades_column_names(pdf, exchange=exchange, inplace=True) # remove duplicates of trade_id
        
        mid = pdf['id'].max()
        tmp = pdf.loc[pdf['id'] == mid, 'timestamp'].iloc[0].timestamp()
        timestamp_from = tmp # pdf['timestamp'].iloc[-1].timestamp() # for next batch 
        # or as datetime pd.to_datetime(pdf['timestamp'].iloc[-1], unit='s')
        mid = pdf['id'].min()
        tmp = pdf.loc[pdf['id'] == mid, 'timestamp'].iloc[0].timestamp()
        if tmp > timestamp_finish:
          continue # downloaded outside scope  bo need to add  
        if cpair in ddf.keys():
          # appending 
          tdf:DataFrame = ddf.get(cpair)
#          tdf.set_default_index(pdf,default_index=['id']) #set index of records id 
#          tdf = make_col_unique(tdf, unique_col='id') # new ve3rsion of df unindexed 
          # check if last downloaded already among ddf records
          if pdf['timestamp'].isin(tdf['timestamp']).all():
            __logger.info( "all records already included, skip to exit")
            timestamp_from = timestamp_finish
            continue
          else:    
#           pdf = make_col_unique(df=tdf, unique_col='id')
            pdf=pd.concat([tdf,pdf],axis=0) 
            #save updated dataframe into lib
            del tdf
        ddf[cpair]=pdf
    except BaseException as e:
      __logger.exception(f"unable process {pair}, got error {e}")

    sleep(1.5) # timeout between requests 
  print(  f"Time up to :{pd.to_datetime(timestamp_from, unit='s')} -- {timestamp_from}")
  __logger.info(f"loading all data completed")
  return ddf

def request(method: str = "GET", path: str = "", query: dict | None = None, body: dict | None = None, public_key: str = "", private_key: str = "", environment: str = "") -> http.client.HTTPResponse:
    url = environment + path
    query_str = ""
    if query is not None and len(query) > 0:
        query_str = urllib.parse.urlencode(query)
        url += "?" + query_str
    nonce = ""
    if len(public_key) > 0:
        if body is None:
            body = {}
#        nonce = body.get("nonce",get_nonce())
        body["nonce"] = body.get("nonce",get_nonce())
        if nonce is None:
            nonce = get_nonce()
            body["nonce"] = nonce
    headers = {}
    body_str = ""
    if body is not None and len(body) > 0:
        body_str = json.dumps(body)
        headers["Content-Type"] = "application/json"
    if len(public_key) > 0:
        headers["API-Key"] = public_key
        headers["API-Sign"] = get_signature(private_key, query_str+body_str, nonce, path)
    req = urllib.request.Request(
        method=method,
        url=url,
        data=body_str.encode(),
        headers=headers,
    )
    return urllib.request.urlopen(req)

def get_nonce() -> str:
    return str(int(time.time() * 1000))

def get_signature(private_key: str, data: str, nonce: str, path: str) -> str:
    return sign(
        private_key=private_key,
        message=path.encode() + hashlib.sha256(
                (nonce + data)
            .encode()
        ).digest()
    )

def sign(private_key: str, message: bytes) -> str:
    return base64.b64encode(
        hmac.new(
            key=base64.b64decode(private_key),
            msg=message,
            digestmod=hashlib.sha512,
        ).digest()
    ).decode()

 