'''
Created on 10 Jan 2026
*** frosen
@author: greqrtrade
'''
#type classConfig= dict
#type ExchangeConfig= dict
#type ExchangeWS= dict

#import numpy as np 
import http.client
import urllib.request
import urllib.parse
import hashlib
import hmac
import base64
import json
import time
import ccxt
import ccxt.pro as ccxt_pro
#from threading import Lock
#from time import sleep
from typing import Any#, Literal, TypeGuard, TypeVar
from types import NoneType
from typing import Union
import requests
import logging
from datetime import datetime
__logger = logging.getLogger(__name__)



class KrakenExchange():

  _params: dict = {"trading_agreement": "agree"}
  
  
  def query(self,pair:str, since:str|datetime="", count:int=1000, asset_class:str=""):
    query_body:dict= {
              "pair": pair,
          }
    if 0< count < 1000 :
      query_body["count"] = count
    if len(asset_class) >0 :
      query_body["asset_class"]=asset_class
    try:
      if isinstance(since,datetime):
        since=since.timestamp()
      since_int = int(since)
      if 0 < since_int < 1e31 :
        query_body["since"] = since
    except BaseException:
      __logger.error(f"unable convert time {since} into seconds of Unix time for query, step skipped ")

    response = self.request(method="GET", 
      path="/0/public/Trades", 
      query=query_body, 
      environment="https://api.kraken.com")
        #
    #
    # first check data for errors 
    #
    # 
    #convert http->str->json
    r_str = response.read().decode()
    rdict = json.loads(r_str)
    # check results 
    for keyn in ["error","result"]:
      resdict:Union[NoneType,dict,str] = rdict.get(keyn,None)
      if isinstance(resdict, NoneType):
        raise requests.exceptions.RequestException(f"returned data has error : key {keyn} missed ",exc_info=True)
      else:
        if (keyn.lower() == "error") & (len(resdict)> 0) :
            raise requests.exceptions.RequestException(f"request return error {resdict}, exit  ",)
        elif (keyn.lower() == "result"): 
          if (len(resdict) == 0) :
            raise requests.exceptions.RequestException(" no result section provided ")
          else:
#            resdict.pop('last')
            if len(resdict[pair]) < 1:
              raise ResourceWarning("No records found")
        # then we have dict with results in resdict
    # export into dataframes per pair collected into dict 'ddf'   

    return rdict
   
  def request(self, method: str = "GET", path: str = "", query: dict | None = None, body: dict | None = {}, public_key: str = "", private_key: str = "", environment: str = "") -> http.client.HTTPResponse:
      url = environment + path
      query_str = ""
      if query is not None and len(query) > 0:
          query_str = urllib.parse.urlencode(query)
          url += "?" + query_str
      nonce = ""
      if len(public_key) > 0:
          if body is None:
              body = {}
          body["nonce"] = body.get("nonce",self.get_nonce())
      headers = {}
      body_str = ""
      if body is not None and len(body) > 0:
          body_str = json.dumps(body)
          headers["Content-Type"] = "application/json"
      if len(public_key) > 0:
          headers["API-Key"] = public_key
          headers["API-Sign"] = self.get_signature(private_key, query_str+body_str, nonce, path)
      req = urllib.request.Request(
          method=method,
          url=url,
          data=body_str.encode(),
          headers=headers,
      )
      return urllib.request.urlopen(req)
  
  def get_nonce(self) -> str:
      return str(int(time.time() * 1000))
  
  def get_signature(self,private_key: str, data: str, nonce: str, path: str) -> str:
      return self.sign(
          private_key=private_key,
          message=path.encode() + hashlib.sha256(
                  (nonce + data)
              .encode()
          ).digest()
      )
  
  def sign(self, private_key: str, message: bytes) -> str:
      return base64.b64encode(
          hmac.new(
              key=base64.b64decode(private_key),
              msg=message,
              digestmod=hashlib.sha512,
          ).digest()
      ).decode()
  
  def __init__(
        self,
        *,
        config: dict| None = None,
        exchange_config: dict | None = None,
        validate: bool = True,
        load_leverage_tiers: bool = False,
    ) -> None:
    self._api: ccxt.Exchange
    self._api_async: ccxt_pro.Exchange
    self._ws_async: ccxt_pro.Exchange = None
    self._exchange_ws: dict | None = None
    self._markets: dict = {}
    self._trading_fees: dict[str, Any] = {}
    self._leverage_tiers: dict[str, list[dict]] = {}
#    # Lock event loop. This is necessary to avoid race-conditions when using force* commands
#    # Due to funding fee fetching.
#    self._loop_lock = Lock()
#    self.loop = self._init_async_loop()
    self._config: Config = {}
    pass
