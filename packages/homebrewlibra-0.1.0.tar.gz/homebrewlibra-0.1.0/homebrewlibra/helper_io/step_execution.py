'''
Created on 15 Jan 2026

@author: alex
'''
from pandas.core.frame import   DataFrame
from pathlib import Path
from homebrewlibra.helper_feather.feather_io_helper import load_feather_trades,\
  save_feather_trades 
#from homebrewlibra.helper_csv.csv_io_helper import save_csv_trades

import logging 
__logger = logging.getLogger(__name__)


from typing import Callable

def step_execution(file_name:str|Path, func_name:Callable, **kwargs):
  """
  # this rountine 
  # either load existing data from path provided to dataframe df_out
  # or  executed func_name on passed dafaframe df and rest arguments
  # and save result DataFrame df_out to the file , path provided and return
  # new functionality :
  # key: --force_update  - 
        delete exiting data file and 
        process finc_name and 
        save new version datafile 
  # key: --update  
        load exiting data file and 
        process finc_name ( adding data ) and 
        save new version datafile
        if file originally missed or does not have Dataframe data processing 
        func_name same as --force update 
        func_name responsibility to correct add data it received loaded 
        DataFrame as optional argument 'ddf'
    
  """
  try:
    callout=False
    path_file=Path(file_name,follow_symlinks=True)
    __logger.info(f"--Process:{file_name}")
    if kwargs.get('force_update',False):
      callout =True
      __logger.warning(f"Force update applied ")
    if path_file.exists():
      df_out: DataFrame = load_feather_trades(path_file)
      __logger.debug(f"loaded existing data ")
    else:
      df_out=None
      callout=True
      __logger.info(f"data does not exist ")
          
    if kwargs.get('update',False) and not callout and isinstance(df_out,DataFrame):
      kwargs['ddf']=df_out  # change 'since from' in func_name for ADDING MISSED DATA 
      callout=True 
      __logger.info(f"data exist and Update requested")
    if callout:
      df_out: DataFrame =func_name(**kwargs )
      save_feather_trades(df_out, path_file)
  
    return df_out
  except BaseException as e:
    __logger.fatal(e,exc_info=True)
    
