'''
Created on 21 Sept 2025

@author: alex
'''
import pandas as pd
from pathlib import Path
from pandas.core.frame import DataFrame
#from types import NoneType
import os
from homebrewlibra.data_tools.__init__ import __OHLCVD_COLUMNS
from homebrewlibra.core.timestamp import parse_unix_ts
from homebrewlibra.core.fields import numercal_col

import logging
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
__logger = logging.getLogger(__name__)
__logger.setLevel(logging.DEBUG)

def load_feather_trades(path, convert_timestamp='timestamp', index_col=None, convert_2_floats=None)->DataFrame:
  df = pd.read_feather(path)               # requires pyarrow installed
  __logger.info(f"loaded {len(df)} records from file {path} ")
  if isinstance(convert_timestamp,str) and convert_timestamp in df.columns:
    df[convert_timestamp]=parse_unix_ts(df[convert_timestamp])
    __logger.info(f"Columns '{convert_timestamp}' converted to datetime format ")
  numercal_col(df,col=convert_2_floats,inplace=True)
  if isinstance(index_col,str) :
    if index_col in df.index.names:
      __logger.info(f" +Index {index_col} already applied no further action ")
    elif index_col in df.columns:
      df.set_index(index_col, inplace=True).sort_index()
      __logger.info(f" +Index {index_col} applied ")
    else:
      __logger.warning(f" -field {index_col} missed, so no index applied")
  else:
      __logger.info(f" +No indexing  required ")
  return df
# Columns are usually: open, high, low, close, volume
def save_feather_trades(df_data:DataFrame=None,file_path:Path=None,unique_col=None):
  if df_data is None:
    __logger.info(f" passed dataframe is None.  Nothing saved ")
    return None
  file_path.parent.mkdir(parents=True, exist_ok=True)
  if(os.path.exists(file_path)):
    __logger.warning(f" override file {file_path} ")
  #tmp=make_col_unique(df_data,unique_col=unique_col)
  res = df_data.to_feather(file_path)
  __logger.info(f" response has {len(df_data)}  records, {len(df_data)} unique records were saved to {file_path} with result {res}")
#  del tmp
  return res

# If you need only OHLCV:
if __name__ == "__main__":
# Example path pattern used by Freqtrade:
# user_data/data/<exchange>/<pair>/<timeframe>.feather
  path = Path("user_data/data/BTC_USDC-1m.feather",follow_symlinks=True)  # adjust to your layout
  df=load_feather_trades(path)
  df.reset_index(inplace=True)
  ohlcv = df[__OHLCVD_COLUMNS]
  print(ohlcv.head())
  path = Path("user_data/feather/BTC_USDC-trades.feather",follow_symlinks=True)
  res = save_feather_trades(df,path)
