'''
Created on 23 Jan 2026

@author: alex
'''
import pandas as pd
import numpy as np 
import logging 
__logger = logging.getLogger(__name__)

def make_lag(df:pd.DataFrame,lag_range=None)->pd.DataFrame:

  if lag_range is None :
    return df
  numeric_cols = df.select_dtypes(include=np.number).columns

  # Create all lagged columns at once
  lagged_dict = {
      f"{col}_lag_{lag}": df[col].shift(lag)
        for col in numeric_cols
          for lag in lag_range
  }

  # Add them all in one go — no warning
  return df.assign(**lagged_dict).fillna(0)