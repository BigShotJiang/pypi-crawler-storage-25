'''
Created on 23 Jan 2026

@author: alex
'''
import logging 
from pandas import DataFrame
__logger = logging.getLogger(__name__)

def set_default_index(df:DataFrame, default_index:str|list=['timestamp','date'])->DataFrame:
    # Check required columns
    if not default_index:
      msg = "❌ Warning: default index column passed as None"
      __logger.error(msg)
    else:
      active_index= (None in df.index.names)
      if isinstance(default_index, str):
        default_index=[default_index]
      for idx in default_index:
        # required field already in index
        if idx in df.index.names:
          return df
        # required field as column
        if idx in df.columns:
          df.reset_index(drop=active_index,inplace=True)
          df.set_index(idx,inplace=True)
          df.sort_index(inplace=True)
          return df
      msg=(f"❌ Warning: no provided columns [{default_index}] found in database")
      __logger.warn(msg)
      raise ValueError(msg)
    

  