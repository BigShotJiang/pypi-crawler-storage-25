'''
Created on 23 Jan 2026

@author: alex
'''
import pandas as pd
import logging 
from homebrewlibra.helper_data.get_columns import get_columns
__logger = logging.getLogger(__name__)

def make_normalize(df:pd.DataFrame, ratio_name='weight',criteria_name='peaks', modify_list=['open','close','mean', 'weight'])->pd.DataFrame:
  """
  columns in modify_list replaced by its ratio to ratio_name value at the last point where criteria_name was non zero
  
  df[modify_list] /= df[ratio_name].where(df[criteria_name] != 0 ) 
      
  """
  try:
    df['~~temp'] = (df[ratio_name].where(df[criteria_name] != 0).ffill()).fillna(1)
    for col in modify_list:
      df[col] = (df[col]/df['~~temp']).fillna(1)
    df.drop('~~temp',inplace=True,errors='ignore')
  except BaseException as e:
    __logger.fatal(e)
    
  return df
#
#
#
def make_categorize(df:pd.DataFrame, modify_list:list=[])->(pd.DataFrame,dict):
  try:
    mappings = {}
    if len(modify_list) == 0 :
      modify_list=df.columns  # list was missed - take care about all non numerical  
    modify_list = get_columns(df,modify_list ) # matched to existing df 
    for col in df[modify_list].select_dtypes(exclude='number').columns:
      df[col] = df[col].astype('category')
      mappings[col] = dict(enumerate(df[col].cat.categories))
      df[col] = df[col].cat.codes.astype('int32')
    return df,mappings
  except BaseException as e:
    __logger.fatal(e)
