'''
Created on 23 Jan 2026

@author: alex
'''
import logging 
from typing import List
from pandas.core.frame import DataFrame
__logger = logging.getLogger(__name__)

def get_columns(df:DataFrame,list_columns:List[str])->List[str]:
  try:
    if isinstance(list_columns,str):
      list_columns = [list_columns]
    if isinstance(list_columns,list):
      feature_cols = [col for col in list_columns if col in df.columns ]
      if feature_cols:
        __logger.debug(f" feature_cols  are '{feature_cols}'")
        return feature_cols
      else:
        msg = "None of the requested columns exist in the DataFrame"
    else:
      msg = f"type of list_columns expected to be a <class 'list'> but it is {type(list_columns)}"
    raise ValueError(msg)
      
  except ValueError as e:   
      __logger.exception(e)
      raise ValueError(e)
