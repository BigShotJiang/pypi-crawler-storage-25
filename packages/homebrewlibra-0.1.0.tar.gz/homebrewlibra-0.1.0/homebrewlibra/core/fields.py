"""Field name mapping and type coercion utilities."""
import logging
from typing import Dict, List, Union

import pandas as pd
from pandas import DataFrame

logger = logging.getLogger(__name__)


def _get_fields_names_dict():
    """Lazy import to avoid circular deps at module level."""
    from homebrewlibra.data_tools import __fields_names_dict
    return __fields_names_dict


def check_fields(df: DataFrame, fields_match: Dict[str, str] = None) -> Dict[str, str]:
    """Auto-detect or validate DataFrame column names against predefined field dictionaries.

    Returns a standardized name-to-column mapping.
    """
    logger.setLevel(logging.INFO)
    if fields_match is None:
        best_match = 0
        best_dict = {}
        fields_names_dict = _get_fields_names_dict()
        for key, flds in fields_names_dict.items():
            logger.debug(f"Processing dict {key}")
            fields_matched = check_fields(df=df, fields_match=flds)
            if len(fields_matched) == len(flds):
                logger.debug(f"accepted dict {key}")
                break
            else:
                if len(fields_matched) >= best_match:
                    best_dict = fields_matched
                    best_match = len(best_dict)
                logger.debug(f"best match dict {key}")
        return fields_matched if best_match == 0 else best_dict
    else:
        sv = ""
        fields_matched = {}
        for k, v in fields_match.items():
            vs = str(v)
            ks = str(k)
            if ks.startswith("*"):
                if sv != "" and any(df[sv] == v):
                    logger.debug(f" value '{v}' for key '{ks}' value found in '{sv}'")
                    fields_matched[ks] = sv
                else:
                    logger.warning(f" value '{v}' for key '{k}' does not exist in field '{sv}'")
                    continue
            else:
                if ks in df.columns:
                    logger.debug(f" The key '{ks}' already exist as field name ")
                    fields_matched[ks] = ks
                    sv = ks
                elif vs in df.columns:
                    logger.debug(f" The value '{vs}' for key '{ks}' exist as field ")
                    fields_matched[ks] = vs
                    sv = vs
                else:
                    logger.warning(f" The value '{vs}' for key '{ks}' does not exist as field ")
                    continue
        return fields_matched


def numercal_col(df: DataFrame, col: Union[str, List[str]] = None, inplace: bool = True) -> DataFrame:
    """Convert specified DataFrame columns to numeric via pd.to_numeric."""
    newdf = df if inplace else df.copy(deep=True)
    if col is None:
        return newdf
    columns = []
    if isinstance(col, str):
        col = [col]
    for icol in col:
        if icol in df.columns:
            columns.append(icol)
    if len(columns) > 0:
        newdf[columns] = newdf[columns].apply(pd.to_numeric, errors="coerce")
    else:
        raise ValueError(f"passed 'col={col}', but should be either list of strings or string ")
    return newdf
