"""Timestamp and date utilities."""
import pandas as pd
from pandas import DataFrame
from datetime import datetime, timezone

try:
    from homebrewlibra.helper_date import __TIMEFRAME_MAX
except ImportError:
    __TIMEFRAME_MAX = 1e11  # seconds threshold


def make_col_unique(df: DataFrame, unique_col: str = "trade_id", ignore_index: bool = False) -> DataFrame:
    """Drop duplicate rows based on a given column, keeping the first occurrence."""
    if unique_col is not None:
        df.drop_duplicates(unique_col, keep="first", inplace=True, ignore_index=ignore_index)
    return df


def parse_unix_ts(col):
    """Auto-detect seconds vs milliseconds and convert to datetime."""
    if pd.api.types.is_datetime64_any_dtype(col):
        return col
    col = pd.to_numeric(col, errors="coerce")
    if col.max() < __TIMEFRAME_MAX:
        return pd.to_datetime(col, unit="s", utc=True)
    else:
        return pd.to_datetime(col, unit="ms", utc=True)


def utc_string_to_timestamp(date_string: str, date_format: str) -> datetime:
    """Convert a UTC date string to a timezone-aware datetime."""
    dt_object = datetime.strptime(date_string, date_format)
    return dt_object.replace(tzinfo=timezone.utc)
