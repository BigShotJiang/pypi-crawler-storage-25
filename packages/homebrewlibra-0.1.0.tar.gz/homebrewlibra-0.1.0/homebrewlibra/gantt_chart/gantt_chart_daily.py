# Gantt Chart Generator - Updated Version
# Timestamp: 2025-03-09 12:45 UTC

import pandas as pd
import matplotlib.pyplot as plt
import argparse
import os
from matplotlib.backends.backend_pdf import PdfPages

WORKDAY_HOURS = 8
WORKDAY_MINUTES = WORKDAY_HOURS * 60

parser = argparse.ArgumentParser(description="Generate a Gantt chart from a CSV file with multi-page workday splitting.")
parser.add_argument("csv_file", type=str, help="Path to the CSV file")
args = parser.parse_args()

csv_basename = os.path.splitext(os.path.basename(args.csv_file))[0]
pdf_filename = f"{csv_basename}.pdf"

df = pd.read_csv(args.csv_file)

df["Start"] = pd.to_datetime(df["Start"], unit="s").dt.floor("min")
df["Length"] = df["Length"].astype(int)
df["End"] = df["Start"] + pd.to_timedelta(df["Length"], unit="s")

time_min = df["Start"].min()
time_max = df["End"].max()

time_current = time_min
time_pages = [time_min]

while time_current < time_max:
    next_time = df[df["Start"] >= time_current + pd.Timedelta(minutes=WORKDAY_MINUTES)]["Start"].min()
    if pd.isna(next_time):  
        break
    time_pages.append(next_time)
    time_current = next_time

time_ranges = [(time_pages[i], time_pages[i + 1]) for i in range(len(time_pages) - 1)]

with PdfPages(pdf_filename) as pdf:
    for start_time, end_time in time_ranges:
        fig, ax = plt.subplots(figsize=(11, 6))

        df_page = df[(df["Start"] >= start_time) & (df["Start"] < end_time)]

        unique_items = df_page["Item"].unique()
        color_map = {item: plt.colormaps.get_cmap("tab20")(i % 20) for i, item in enumerate(unique_items)}

        for _, row in df_page.iterrows():
            color = color_map[row["Item"]]
            ax.barh(row["Machine"], (row["End"] - row["Start"]).total_seconds() / 60,
                    left=(row["Start"] - start_time).total_seconds() / 60,
                    color=color, edgecolor="black")

        ax.set_xlabel("Time (HH:MM)")
        ax.set_ylabel("Machine")
        ax.set_title(f"Gantt Chart: {start_time.strftime('%Y-%m-%d')}")
        ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: (start_time + pd.Timedelta(minutes=x)).strftime("%H:%M")))
        ax.invert_yaxis()
        ax.grid(True, linestyle="--", linewidth=0.5, zorder=0)

        pdf.savefig(fig)
        plt.close(fig)

print(f"Multi-page PDF '{pdf_filename}' generated successfully!")
