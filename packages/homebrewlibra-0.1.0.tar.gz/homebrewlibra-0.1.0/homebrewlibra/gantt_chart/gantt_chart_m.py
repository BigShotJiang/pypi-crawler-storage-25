import pandas as pd
import matplotlib.pyplot as plt
import argparse
import os
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages

def format_name(name):
    if isinstance(name, str):
        return name.split("~", 1)[0][:20]
    return str(name)

# --- Argument Parsing ---
parser = argparse.ArgumentParser(description="Generate a single-type Gantt chart from a CSV file.")
parser.add_argument("csv_file", type=str, help="Path to the CSV file")
parser.add_argument("-t", "--type", required=True, help="Field name to group bars by (e.g. Machine, Item, Operation)")
parser.add_argument("-c", "--center", default=None, help="Field to display inside each bar")
parser.add_argument("-f", "--filter", default=None, help="(Placeholder) Filtering expression like Machine=BENCH")

args = parser.parse_args()

# --- File Check ---
if not os.path.isfile(args.csv_file):
    print(f"Error: File '{args.csv_file}' not found.")
    exit(1)

# --- Load CSV ---
df = pd.read_csv(args.csv_file)

# --- Validate Columns ---
available_columns = df.columns.tolist()
for required_col in [args.type, args.center] if args.center else [args.type]:
    if required_col not in df.columns:
        print(f"\n❌ Column '{required_col}' not found in CSV.")
        print("✅ Available columns:", ", ".join(available_columns))
        exit(1)

# --- Time Preprocessing ---
df["Start"] = pd.to_datetime(df["Start"], unit="s")
df["Length"] = df["Length"].astype(int)
df["End"] = df["Start"] + pd.to_timedelta(df["Length"], unit='s')
df = df.sort_values(by=["Start"])

# --- Setup Output Filename ---
csv_basename = os.path.splitext(os.path.basename(args.csv_file))[0]
pdf_filename = f"{csv_basename}_{args.type}.pdf"

# --- PDF Generation ---
time_min = df["Start"].min()
time_max = df["End"].max()

with PdfPages(pdf_filename) as pdf:
    current_day = time_min.normalize()
    while current_day < time_max:
        next_day = current_day + pd.Timedelta(days=1)
        df_page = df[(df["Start"] >= current_day) & (df["Start"] < next_day)]

        if df_page.empty:
            current_day = next_day
            continue

        fig, ax = plt.subplots(figsize=(9, 6), constrained_layout=True)
        ax.set_title(f"{args.type}s on {current_day.strftime('%Y-%m-%d')}")
        ax.set_xlabel("Time")
        ax.set_ylabel(args.type)

        time_step = pd.Timedelta(minutes=60)
        day_end = df_page["End"].max() + time_step
        ax.set_xlim(current_day, day_end)
        major_ticks = pd.date_range(start=current_day, end=day_end, freq='h')
        ax.set_xticks(major_ticks)
        ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: pd.to_datetime(x, unit='d').strftime("%H:%M")))
        ax.tick_params(axis='x', labelsize=6)

        unique_types = sorted(df_page[args.type].unique())
        cmap = plt.get_cmap("tab20")
        type_colors = {val: cmap(i / max(1, len(unique_types) - 1)) for i, val in enumerate(unique_types)}

        for _, row in df_page.iterrows():
            y_label = format_name(row[args.type])
            color = type_colors[row[args.type]]
            ax.barh(
                y_label, (row["End"] - row["Start"]),
                left=row["Start"], color=color, edgecolor="black"
            )
            if args.center and row["Length"] > 1800:
                label = format_name(row[args.center])
                ax.text(
                    row["Start"] + pd.to_timedelta(row["Length"] / 2, unit='s'),
                    y_label, label,
                    va='center', ha='center', fontsize=5, color='black', weight='bold'
                )

        ax.invert_yaxis()

        # Legend (if reasonable number of categories)
        if len(type_colors) <= 19:
            legend_patches = [
                plt.Line2D([0], [0], color=col, lw=4, label=format_name(lbl))
                for lbl, col in type_colors.items()
            ]
            ax.legend(handles=legend_patches, loc="upper right", title=args.type + "s", fontsize=7)

        pdf.savefig(fig)
        plt.close(fig)
        current_day = next_day

print(f"✅ Gantt chart PDF '{pdf_filename}' generated.")
