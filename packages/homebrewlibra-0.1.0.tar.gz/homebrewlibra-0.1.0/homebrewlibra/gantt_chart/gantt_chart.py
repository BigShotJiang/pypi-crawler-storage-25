# Gantt Chart Generator - Updated Version
# Timestamp: 2025-03-09 12:45 UTC
# changed by Alex 
import pandas as pd
import matplotlib.pyplot as plt
import argparse
import os
import numpy as np
#import hashlib
#from datetime import datetime, timedelta
from matplotlib.backends.backend_pdf import PdfPages
#from matplotlib import units
#from setuptools._vendor.more_itertools.more import substrings
#from sympy.physics.units.definitions.unit_definitions import seconds
#import string

# Argument parser for CSV input file
parser = argparse.ArgumentParser(description="Generate a Gantt chart from a CSV file.")
parser.add_argument("csv_file", type=str, help="Path to the CSV file")
args = parser.parse_args()

# Check if CSV file exists
if not os.path.isfile(args.csv_file):
    print(f"Error: File '{args.csv_file}' not found.")
    exit(1)

# Extract the base name from the CSV file and set the PDF filename
csv_basename = os.path.splitext(os.path.basename(args.csv_file))[0]
pdf_filename = f"{csv_basename}.pdf"  # Match CSV name

# Load CSV file
df = pd.read_csv(args.csv_file)

# Convert Unix timestamps to readable datetime format

def format_time(timestamp):
    if isinstance(timestamp, np.datetime64):
        timestamp = pd.Timestamp(timestamp).to_pydatetime()
    return timestamp.strftime('%Y-%m-%d %H:%M')
def format_name(name):
    if isinstance(name, str):
        if "~" in name :
            name = name[:name.index("~", 1)]
        else :
            name = name[:20]
    return name
# Apply conversion to Start and Length columns
df["Start" ] = pd.to_datetime(df["Start"],unit="s")
df["Length"] = df["Length"].astype(int)  # Ensure integer values
df["End"   ] = df["Start"] + pd.to_timedelta(df["Length"], unit='s')  # Calculate end time
df = df.sort_values(by=["Start"])

time_min = df["Start"].min()
time_max = df["End"  ].max() # 1 sday window
# Sort data by start time to ensure proper plotting

# Split into multiple pages based on 1-day (8-hour) work shifts
#workday_duration = timedelta(hours=8)
# time_pages = [time_min]
# Create a multipage PDF
with PdfPages(pdf_filename) as pdf:

    time_current = time_min.normalize() 
    
    while time_current < time_max:
        df_page  = df[(df["Start"] >= time_min.normalize())]
        time_min = df_page["Start"].min()
        tmp = time_min.normalize() + pd.Timedelta(days = 1 )
        df_page  = df_page[(df_page["Start"] < tmp)]
        time_step = pd.Timedelta(minutes=60) #(time_max - time_min) / num_major_ticks  # Calculate step size
        time_max = df_page["End"].max()+ time_step * 0.5  # records in one day window& (df["Start"] <  time_current)]
    
        # --- First Figure: Machine-Based Gantt Chart ---
        fig, ax = plt.subplots(figsize=(9, 6), constrained_layout=True)
        ax.set_xlim(time_min, time_max)  # Offset for right boundary
        ax.set_xlabel("Time")
        ax.set_ylabel("Centre")
        ax.set_title(f"Production Centres on {time_min.strftime('%Y-%m-%d')}")
        # Round time_min down to the nearest full hour
        time_min_rounded = time_min
        # Round time_max up to the nearest full hour
        time_max_rounded = time_max
        # Generate major ticks at 1-hour intervals
        major_ticks = pd.date_range(start=time_min_rounded, end=time_max_rounded, freq='h')
        # Apply major ticks
        ax.set_xticks(major_ticks)
        # Format X-axis labels to display hours correctly
        ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: pd.to_datetime(x, unit='d').strftime("%H:%M")))
        ax.tick_params(axis='x', labelsize=4)  # Adjust the size as needed
    
        unique_items = sorted(df_page["Item"].unique())
        color_map = plt.colormaps.get_cmap("tab20")
        item_color_map = {item: color_map(i / max(1, len(unique_items) - 1)) for i, item in enumerate(unique_items)}
    
#        item_labels = {}
        for index, row in df_page.iterrows():
            color = item_color_map[row["Item"]]
            ax.barh(
            format_name(row["Machine"]), (row["End"] - row["Start"]) , left=row["Start"],
                color=color, edgecolor="black"
            )
            text_width = row["Length"] #ax.transData.transform( pd.to_timedelta(row["Length"], unit='s'))[0]
            if text_width > 1800:
                ax.text(row["Start"] + pd.to_timedelta(row["Length"] / 2, unit='s'), format_name(row["Machine"]), 
                        format_name(row["Item"]),
                        va='center', ha='center', fontsize=4, color='black', weight='bold')
#            if row["Item"] not in item_labels:
#                item_labels[row["Item"]] = color
        ax.invert_yaxis()
    
#        for mark in time_marks:
#            ax.axvline(mark, color='gray', linestyle='--', linewidth=0.5, zorder=0)
#            ax.text(mark, ax.get_ylim()[0], format_time(mark), rotation=90, verticalalignment='bottom', fontsize=8)
    
        if len(item_color_map) <= 19:
            legend_patches = [plt.Line2D([0], [0], color=color, lw=4, label=f"Item {item}") 
                              for item, color in item_color_map.items()]
            ax.legend(handles=legend_patches, loc="upper right", title="Items", fontsize=8)
        
        pdf.savefig(fig)
        plt.close(fig)
    
        # --- Second Figure: Item-Based Gantt Chart ---
        fig, ax = plt.subplots(figsize=(9, 6), constrained_layout=True)
        unique_operations = sorted(df_page["Machine"].unique())
        operation_color_map = {op: color_map(i / max(1, len(unique_operations) - 1)) for i, op in enumerate(unique_operations)}
        operation_labels = {}
    
        for index, row in df_page.iterrows():
            color = operation_color_map[row["Machine"]]
            ax.barh(
            format_name(row["Item"]), pd.to_timedelta(row["Length"], unit='s'), left=row["Start"],
                color=color, edgecolor="black"
            )
            #text_width = ax.transData.transform(((row["Start"] - time_min).total_seconds() + row["Length"], 0))[0] - ax.transData.transform(((row["Start"] - time_min).total_seconds(), 0))[0]
            #if text_width > 20: # look like this calculation is incorrect 
            text_width = row["Length"] #ax.transData.transform( pd.to_timedelta(row["Length"], unit='s'))[0]
            if text_width > 1800:                ax.text(row["Start"] + pd.to_timedelta(row["Length"] / 2, unit='s'), format_name(row["Item"]), str(format_name(row["Machine"])),
                        va='center', ha='center', fontsize=4, color='black', weight='bold')
            if row["Machine"] not in operation_labels:
                operation_labels[row["Machine"]] = color
    
        ax.set_xlim(time_min, time_max)  # Offset for right boundary
        ax.set_xlabel("Time")
        ax.set_ylabel("Item")
        ax.set_title(f"Operations by Item on {time_min.strftime('%Y-%m-%d')}")
        ax.set_xticks(major_ticks)
        # Format X-axis labels to display hours correctly
        ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: pd.to_datetime(x, unit='d').strftime("%H:%M")))
        ax.invert_yaxis()
    
#        for mark in time_marks:
#            ax.axvline(mark, color='gray', linestyle='--', linewidth=0.5, zorder=0)
#            ax.text(mark, ax.get_ylim()[0], format_time(mark), rotation=90, verticalalignment='bottom', fontsize=8)
    
        if len(operation_labels) <= 19:
            legend_patches = [plt.Line2D([0], [0], color=color, lw=4, label=f" {format_name(op)}") # use operation_color_map
                              for op, color in operation_labels.items()]
            ax.legend(handles=legend_patches, loc="upper right", title="Operations", fontsize=8)

#        ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: (time_min + pd.Timedelta(minutes=x)).strftime("%H:%M")))
        
        pdf.savefig(fig)
        plt.close(fig)
    
        # --- Legend Pages (if more than 19 items) ---
#        if len(item_labels) > 19 or len(operation_labels) > 19:
#            legend_items = list(item_labels.items()) if len(item_labels) > 19 else list(operation_labels.items())
#            max_items_per_page = 60
#            num_pages = (len(legend_items) + max_items_per_page - 1) // max_items_per_page
    
#            for page in range(num_pages):
#                fig_legend, ax_legend = plt.subplots(figsize=(6, min(max_items_per_page, len(legend_items[page * max_items_per_page:])) * 0.5 + 1))
#                ax_legend.axis("off")
#                legend_patches = [plt.Line2D([0], [0], color=color, lw=4, label=f"Item {item}")
#                                  for item, color in legend_items[page * max_items_per_page:(page + 1) * max_items_per_page]]
#                ax_legend.legend(handles=legend_patches, loc="center", title="Legend", fontsize=10)
#                pdf.savefig(fig_legend)
#                plt.close(fig_legend)
        time_min = time_min.normalize()+ pd.Timedelta(days=1)
        time_max = min ( time_min + pd.Timedelta(days=1), df["End"].max())
        time_current  = time_min
print(f"Multi-page PDF '{pdf_filename}' generated successfully!")
