import pandas as pd
import matplotlib.pyplot as plt
import argparse
import os
import numpy as np
import hashlib
from matplotlib.backends.backend_pdf import PdfPages

# Argument parser for CSV input file
parser = argparse.ArgumentParser(description="Generate a Gantt chart from a CSV file.")
parser.add_argument("csv_file", type=str, help="Path to the CSV file")
args = parser.parse_args()

# Check if CSV file exists
if not os.path.isfile(args.csv_file):
    print(f"Error: File '{args.csv_file}' not found.")
    exit(1)

# Extract the base name from the CSV file and set the PDF filename
csv_basename = os.path.splitext(os.path.basename(args.csv_file))[0]
pdf_filename = f"{csv_basename}.pdf"  # Match CSV name

# Load CSV file
df = pd.read_csv(args.csv_file)

# Sort data by start time to ensure proper plotting
df = df.sort_values(by=["Start"])

# Create a multipage PDF
with PdfPages(pdf_filename) as pdf:

    # --- First Figure: Gantt Chart ---
    fig, ax = plt.subplots(figsize=(10, 6))

    # Generate distinct colors using a colormap with more variation
    unique_items = sorted(df["Item"].unique())
    color_map = plt.colormaps.get_cmap("tab20")
    
    # Assign colors using unique indices
    item_color_map = {item: color_map(i / max(1, len(unique_items) - 1)) for i, item in enumerate(unique_items)}

    item_labels = {}  # Store unique items for the legend

    # Plot bars for each task
    for index, row in df.iterrows():
        color = item_color_map[row["Item"]]
        bar = ax.barh(
            row["Machine"], row["Length"], left=row["Start"],
            color=color, edgecolor="black"
        )
        
        # Check if the text fits inside the bar
        text_width = ax.transData.transform((row["Start"] + row["Length"], 0))[0] - ax.transData.transform((row["Start"], 0))[0]
        if text_width > 20:  # Minimum width threshold for text visibility
            ax.text(row["Start"] + row["Length"] / 2, row["Machine"], str(row["Item"]),
                    va='center', ha='center', fontsize=8, color='black', weight='bold')
        
        if row["Item"] not in item_labels:
            item_labels[row["Item"]] = color  # Store item color

    # Labels and formatting
    ax.set_xlabel("Time")
    ax.set_ylabel("Machine")
    ax.set_title("Gantt Chart of Scheduling")
    ax.invert_yaxis()  # Invert y-axis for correct order

    # Add legend on the first page if items <= 19
    if len(item_labels) <= 19:
        legend_patches = [plt.Line2D([0], [0], color=color, lw=4, label=f"Item {item}") 
                          for item, color in item_labels.items()]
        ax.legend(handles=legend_patches, loc="upper right", title="Items", fontsize=8)
    
    # Save first page
    pdf.savefig(fig)
    plt.close(fig)

    # --- Legend Pages (if more than 19 items) ---
    if len(item_labels) > 19:
        legend_items = list(item_labels.items())
        max_items_per_page = 60
        num_pages = (len(legend_items) + max_items_per_page - 1) // max_items_per_page

        for page in range(num_pages):
            fig_legend, ax_legend = plt.subplots(figsize=(6, min(max_items_per_page, len(legend_items[page * max_items_per_page:])) * 0.5 + 1))
            ax_legend.axis("off")  # Hide axes

            # Create legend entries for this page
            legend_patches = [plt.Line2D([0], [0], color=color, lw=4, label=f"Item {item}")
                              for item, color in legend_items[page * max_items_per_page:(page + 1) * max_items_per_page]]
            ax_legend.legend(handles=legend_patches, loc="center", title="Items", fontsize=10)

            # Save legend page
            pdf.savefig(fig_legend)
            plt.close(fig_legend)

print(f"Multi-page PDF '{pdf_filename}' generated successfully!")
