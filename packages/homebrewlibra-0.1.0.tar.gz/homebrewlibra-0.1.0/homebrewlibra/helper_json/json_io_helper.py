'''
Created on 16 Nov 2025

@author: alex
'''
import pandas as pd
import os
import logging
from typing import Union
from pandas.core.frame import DataFrame
import json
from jsonschema import validate, ValidationError
from types import NoneType
from homebrewlibra.helper_date.__init__ import __TIMEFRAME_MAX
from homebrewlibra.helper_json.__init__ import __TRADES_COLUMNS

__logger = logging.getLogger(__name__)
__logger.setLevel(logging.INFO)

#
#
#
def load_json_trades(file_path)->DataFrame:
  df = pd.read_json(file_path)               # requires json installed
  df.columns=__TRADES_COLUMNS
  if 'date'  in df.columns:
    srcc='date'
  elif 'timestamp' in df.columns:
    srcc='timestamp'
    if df['timestamp'].iloc[-1] < __TIMEFRAME_MAX:
      unit_s='s'
    else:
      unit_s='ms'
    df['date'] = pd.to_datetime(df[srcc], utc=True,unit=unit_s,errors='raise')
  else:
    __logger.warning(f"loaded history {len(df)} records. neither date not timestamp found , so no index setup ")
  if 'trade_id' in df.columns:
    olen=len(df)
    df.set_index('trade_id',inplace=True)
    df.drop_duplicates(inplace=True)
    __logger.info(f"loaded history {olen} records from trade_id {df.index.min()} to {df.index.max()} uniquerecords {len(df)}\n columns {df.columns} from file {file_path} ") 
  elif 'date' in df.columns:
    df = df.set_index('date').sort_index()
    __logger.info(f"loaded history {len(df)} records from {df.index.min().ctime()} to {df.index.max().ctime()}\n columns {df.columns} from file {file_path} ") 
  return df 
#
#
#

def save_json_trades(df_data:Union[dict,list,DataFrame],file_path=None):
  if(os.path.exists(file_path)):
    __logger.warning(f" override file {file_path} ")
  

  with open(file_path, "w") as fp:
    if isinstance(df_data,DataFrame):
      tmp=df_data.reset_index()
      res = tmp.to_json(fp, indent=2)
      del tmp
    else:
      if(not isinstance(is_valid_json(df_data), bool)):
        res = json.dump(df_data, fp, indent=2)
      else:
        res=False
        __logger.error(f"json structure was not validated and written ")  
  __logger.info(f" response has {len(df_data)} records which were saved to {fp.name} with result {res}")

  return res 

def is_valid_json(json_instance:Union[str,list,dict], js_schema:Union[dict,NoneType]=None)->Union[bool,list,dict]:
    try:
      if isinstance(json_instance,str):
        js_tmp=json.loads(json_instance)
      if not isinstance(js_schema,NoneType):
        validate(instance=js_tmp, schema=js_schema)
      return js_tmp
          
    except (json.JSONDecodeError, ValidationError) as e:
      __logger.warning(f"validation issue {e}")
      return False

if __name__ == '__main__':
    """
    this module used for export and import data in files  in json format  
    """
    from pathlib import Path
    file_path = Path("user_data/json/XBTAUD.json",follow_symlinks=True)  # adjust to your layout
    df = load_json_trades(file_path)
    df.reset_index(inplace=True)
    ohlcv = df[__TRADES_COLUMNS]
    file_path = Path("user_data/json/XBTAUD-tmp.json",follow_symlinks=True)
    ret= save_json_trades(df,file_path)
    print(ohlcv.head())
