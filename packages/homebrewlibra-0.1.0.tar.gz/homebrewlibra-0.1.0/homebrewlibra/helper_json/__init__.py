from homebrewlibra.helper_date.__init__ import __TIMEFRAME_MAX
__TRADES_COLUMNS       = ['timestamp', 'trade_id','price', 'volume',  'buy/sell', 'market/limit', 'miscellaneous']
