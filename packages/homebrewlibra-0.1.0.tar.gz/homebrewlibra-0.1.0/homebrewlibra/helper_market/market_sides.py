'''
Created on 9 Jan 2026

@author: alex
'''
"""
class MyClass(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
"""
from pandas.core.frame import  Series, DataFrame
#import pandas as pd 
#from homebrewlibra.helper_market.convert_trades_to_OHLCV import trades_as_2OHLCV
#from homebrewlibra.helper_feather.feather_io_helper import load_feather_trades 
#from pathlib import Path
#from plot_tools import plot_prices, plot_prices_OMWC
#import matplotlib.pyplot as plt
import logging

from homebrewlibra.helper_market.split_trades_to_sides import trades_split_by_side
from homebrewlibra.helper_market.trades_fields import (
  check_fields
#, numercal_col
  )
#from homebrewlibra.helper_market.convert_timestamp_date import parse_unix_ts
#from homebrewlibra.helper_market.convert_timestamp_date import make_col_unique



logger = logging.getLogger(__name__)


def market_sides(ticker_data:DataFrame)-> (DataFrame, DataFrame):
    fields_matched = check_fields(ticker_data) #,fields_matchfields_names_freqtrade)
    markets={
      "df_buy":[ 
          {fields_matched.get('side'):fields_matched.get('*buy' ),fields_matched.get('type'):fields_matched.get('*market')},
          {fields_matched.get('side'):fields_matched.get('*sell'),fields_matched.get('type'):fields_matched.get('*limit' )},
        ],
      "df_sel":[ 
          {fields_matched.get('side'):fields_matched.get('*sell'),fields_matched.get('type'):fields_matched.get('*market' )},
          {fields_matched.get('side'):fields_matched.get('*buy' ),fields_matched.get('type'):fields_matched.get('*limit')},
        ]
      }
    timestamp_name = fields_matched.get('timestamp')
    tradeid_name   = fields_matched.get('id')
#    float_cols=[
#      fields_matched.get('amount'),
#      fields_matched.get('price'),
#      fields_matched.get('cost'),
#      ]
#    numercal_col(df=ticker_data, col=float_cols, inplace=True)
#    ticker_data[tradeid_name]=ticker_data[tradeid_name].astype('Int64')
#    # convert it to datetime
#    if timestamp_name in ticker_data.columns:
#      ticker_data[timestamp_name] = parse_unix_ts(ticker_data[timestamp_name])
#    ticker_data = make_col_unique(df=ticker_data, unique_col=tradeid_name)
    d_markets= trades_split_by_side(df=ticker_data, markets=markets)
    df_buy = d_markets.get('df_buy')
    df_sel = d_markets.get('df_sel')
    # grouping by  and make calc params got one 
    df_buy.set_index(tradeid_name, drop=False, inplace=True )
    df_sel.set_index(tradeid_name, drop=False, inplace=True )
    df_buy.sort_index(inplace=True)
    df_sel.sort_index(inplace=True)
    
    def set_gouping_table(df:DataFrame, grouping_col:str,matched_cols:dict,grouping_new:str = 'date')->DataFrame:
      newdf:DataFrame=df.copy(deep=True)
      newdf[grouping_new]=df[grouping_col].dt.floor('120min')
      price = matched_cols.get('price','price')
      amount= matched_cols.get('amount','amount')
      type_c  = matched_cols.get('type','type')
      type_v  = matched_cols.get('*market','market')
      trade_id= matched_cols.get('id','id')
      
      def complex_group_processing(group:DataFrame)->Series:
        newseries:Series = Series({
          'open'  :( group[price].iloc[ 0]),
          'close' :( group[price].iloc[-1]),
          'mean'  :( group[price].mean()  ),
          'weight':((group[price]*group[amount]).sum()/
                     group[amount].sum()
                    ),
          'volume':( group[amount].sum()),
          'cost'  :((group[price]*group[amount]).sum()),
          'first' :( group[trade_id ]),#group.index[ 0]),
          'unique':(max((group[type_c] == type_v).sum(),1))
          })
        
        return newseries
#      original_columns = newdf.columns.tolist()
      newdf   = newdf.groupby(grouping_new, sort=False).apply(complex_group_processing, include_groups=False)
#      newdf.drop(columns=original_columns, errors='ignore', inplace=True)
      return newdf
    df_bnew = set_gouping_table(df=df_buy, grouping_col=timestamp_name, matched_cols = fields_matched )
    df_snew = set_gouping_table(df=df_sel, grouping_col=timestamp_name, matched_cols = fields_matched )
    return df_bnew,df_snew
