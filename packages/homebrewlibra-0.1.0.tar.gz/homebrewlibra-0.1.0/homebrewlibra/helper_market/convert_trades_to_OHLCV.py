'''
Created on 18 Nov 2025

@author: alex
'''
from pandas.core.frame import DataFrame
import pandas as pd
from homebrewlibra.data_tools import CONVERT_TRADES_COLUMNS
from homebrewlibra.helper_market.convert_timestamp_date import make_col_unique,\
  parse_unix_ts
from homebrewlibra.helper_market.trades_fields import numercal_col, check_fields


import logging
__logger = logging.getLogger(__name__)

def normalize_trades_column_names(df:DataFrame,exchange:str='kraken',inplace=True)-> DataFrame:
  try:
    if inplace :
      tdf=df
    else:
      tdf=df.copy()
    fields_matched = check_fields(tdf)
    rename_mapping=CONVERT_TRADES_COLUMNS.get(exchange)
    tdf.rename(columns=rename_mapping,inplace=True)
    #,fields_matchfields_names_freqtrade)
    timestamp_name = fields_matched.get('timestamp')
    tradeid_name   = fields_matched.get('id')
    float_cols=[
      fields_matched.get('amount'),
      fields_matched.get('price'),
      fields_matched.get('cost'),
      ]
    numercal_col(df=tdf, col=float_cols, inplace=True)
    if tradeid_name in tdf.columns:
      tdf[tradeid_name]=tdf[tradeid_name].astype('Int64')
    else:
      if tradeid_name in tdf.index.names:
        # future - check type 
        pass
      else:
        __logger.debug(f"field <{tradeid_name}> not found ")
    # convert it to datetime
    if timestamp_name in tdf.columns:
      tdf[timestamp_name] = parse_unix_ts(tdf[timestamp_name])
   

    return tdf
  except ValueError as e:
    __logger.exception(e,exc_info=True)
  except BaseException as e:
    __logger.exception(e,exc_info=True)
    raise e
    
  
def trades_as_2OHLCV(df:DataFrame, 
                     timeframe='5T',
                     fields_names={},   
                     sum_cols = ['v_bl',
                                 'v_bm',
                                 'v_sl',
                                 'v_sm'
                                 ]
                     )->DataFrame:
  """
  function calculates from trades for specified timeframe the prices OHLC, 
  Volume total and specific volumes for selected side/market ( buy or sell ) 
  assumption that Volume  for side buy form by buy market and sell limit  ( rising price )
  You write
  Pandas understands as
  '60s'60 seconds → 1 minute
  '1min'/'1T'     → 1 minute
  '5min'/'5T'      → 5 minutes
  '1h'             → 1 hour
  '1d'             → 1 day
   
   fields_names={},  MEANS USE FREQUTRADE FORMAT OF FEATHER TRADES 
   
    sum_cols = ['v_bl',
               'v_bm',
               'v_sl',
               'v_sm'
               ]
  COULD BE ANY EXISTING FIRLDS BUT THESE ONE above WILL BE CEATED AS SUM('amount') 
  for trades with side buy/sell and market_type limit/market which forming 
  field name v_<side><market_type>  when they not in dataframe.
     
   """
  __logger.setLevel(logging.DEBUG) 
  def get(name, default=None):
      return fields_names.get(name, default or name)
  amount      = get('amount','amount')
  side        = get('side'  ,'side')
  buy         = get('buy'   ,'buy')
  sell        = get('sell'  ,'sell')
  market_type = get('type'  ,'type')
  market      = get('market','market')
  limit       = get('limit' ,'limit')
  price_col   = get('price' ,'price')
  time_col    = get('timestamp' ,'timestamp')
  price_open  = get('open' ,'open')
  price_high  = get('high' ,'high')
  price_low   = get('low'  ,'low')
  price_close = get('close','close')
  price_volume= get('volume','volume')
  trade_id_col= get('trade_id','trade_id') 
  trade_count = get('trade_count','trade_count')
  first_trade = get('first_trade','first_trade')
  last_trade  = get('last_trade','last_trade')
  gaps        = get('gaps','gaps')
  # Default fallback: if not in dict → use this name
  try:
    # first make columns in sum_cols list
    for col in sum_cols:
      if col in df.columns:
        __logger.debug(f" column {col} already exist in dataframe ")
      else:
        __logger.debug(f" column {col} will be created ")
        match col:
          case 'v_bl':
            df['v_bl'  ] =  -df[amount].where(((df[side]==buy ) & (df[market_type]==limit  )) , 0 ).apply(pd.to_numeric, errors='coerce')    
          case 'v_bm':
            df['v_bm'  ] =   df[amount].where(((df[side]==buy ) & (df[market_type]==market )) , 0 ).apply(pd.to_numeric, errors='coerce')    
          case 'v_sl':
            df['v_sl'  ] =  df[amount].where(((df[side]==sell) & (df[market_type]==limit  )) , 0 ).apply(pd.to_numeric, errors='coerce')
          case 'v_sm':
            df['v_sm'  ] =  -df[amount].where(((df[side]==sell) & (df[market_type]==market )) , 0 ).apply(pd.to_numeric, errors='coerce')
    # ───── STEP 1: convert to float and create total volume per original row (per trade) ─────
#    cols_to_sum = df[sum_cols].select_dtypes(include='object').columns
#    df[cols_to_sum ] = df[cols_to_sum].apply(pd.to_numeric, errors='coerce')
    df[price_volume] = df[sum_cols].sum(axis=1)   # ← this is the real total volume per trade
    # Price → float
    df[price_col   ] = pd.to_numeric(df[price_col], errors='coerce') 
    # trade_id → integer (Int64 handles NaN safely, unlike int64)
    df[trade_id_col] = pd.to_numeric(df[trade_id_col], errors='coerce').astype('Int64')
    
    # ───── STEP 2: build perfect 1-second candles with total volume + breakdown ─────
            
    df_1s_raw = (df
        .groupby(pd.Grouper(key=time_col, freq=timeframe, closed='left', label='left'))
        .agg(
            **{
              price_open  :  (price_col,  'first'),
              price_high  :  (price_col,    'max'),
              price_low   :  (price_col,    'min'),
              price_close :  (price_col,   'last'),
              price_volume:  (price_volume,  'sum'),   # ← total volume (what exchanges show)
              trade_count :  (trade_id_col, 'count'),
              first_trade :  (trade_id_col, 'first'),
              last_trade  : (trade_id_col, 'last'),
              gaps        : (trade_id_col, lambda x: 0 if len(x) < 2 else max(0, int(x.iat[-1] - x.iat[0] + 1 - len(x)))),
            },
            # ← Keep your full breakdown (vm+, vm-, power, etc.)
            **{col: (col, 'sum') for col in sum_cols}
        )
        .reset_index()
    )
    # ───── STEP 2: Audit — prove we lost NOTHING ─────
    total_trades_before  = len(df)
    total_volume_before  = df[price_volume].sum()
    
    total_trades_after   = df_1s_raw[trade_count].sum()
    total_volume_after   = df_1s_raw[price_volume].sum()
    
    print("DATA LOSS CHECK:")
    print(f"   Original trades : {total_trades_before:,}")
    print(f"   Summed trades   : {total_trades_after:,}  → difference = {total_trades_before - total_trades_after}")
    print(f"   Original volume : {total_volume_before:,.2f}")
    print(f"   Summed volume   : {total_volume_after:,.2f}  → difference = {total_volume_before - total_volume_after:.2f}")
    print()
    
    # You will see: difference = 0.000 → perfect!
    
    # ───── STEP 3: Count how many candles are empty ─────
    empty_by_open   =  df_1s_raw[price_open].isna().sum()
    empty_by_volume = (df_1s_raw[price_volume] == 0).sum()
    empty_by_trades = (df_1s_raw[trade_count] == 0).sum()
    
    print(f"Empty candles (open is NaN)     : {empty_by_open}")
    print(f"Empty candles (volume == 0)     : {empty_by_volume}")
    print(f"Empty candles (no trades)       : {empty_by_trades}")
    print(f"Total candles created           : {len(df_1s_raw)}")
    print()
    
    # ───── STEP 4: Now safely drop empty candles (your choice) ─────
    # Option A: drop if open is NaN (recommended)
    df_candle = df_1s_raw.dropna(subset=[price_open]).copy()
    
    # Option B: drop if volume == 0 (sometimes better, because price can be same as previous)
    # df_candle = df_1s_raw[df_1s_raw['volume'] > 0].copy()
    
    # Option C: drop only if no trades at all
    # df_candle = df_1s_raw[df_1s_raw['trade_count'] > 0].copy()
    
    # Final check
    print(f"Final clean candles: {len(df_candle)} (removed {len(df_1s_raw) - len(df_candle)} empty ones)")    
    # Optional: nice boolean flag
    df_candle['has_gap'] = df_candle[gaps] > 0    
    # Show result
    print(df_candle.head())
    print(df_candle.dtypes)
  except ValueError as e:
    __logger.error(f"trades_as_2OHLCV: {e}",exc_info=True)
  return df_candle


if __name__ == '__main__':
  import argparse
  from pathlib import Path
  from homebrewlibra.helper_feather.feather_io_helper import load_feather_trades, save_feather_trades
  def main():
    fields_names_kraken={
      'amount':'volume',
      'side'  :'buy/sell', 
      'type'  :'market/limit',
      'buy'   :'b',
      'sell'  :'s',
      'market':'m',
      'limit' :'l',
      'price':'price',
      
      }
  
    logging.basicConfig(
      level=logging.DEBUG,
      format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
      )
  #  ch = logging.StreamHandler()
  #  ch.setLevel(logging.DEBUG)
  #  __logger.addHandler(ch)                 # ← this line was missing!
    __logger.handlers                       # → should show the handler now
  #  __logger.setLevel(logging.DEBUG)
    args = vars(parse_args())
    print("\n=== CONFIGURATION ===")
    for key, value in args.items():
        print(f"{key:12} : {value}")
    print()  
    # Parse the string into a datetime object
    date_time_start=args.get('timerange','')
    if len(date_time_start) == 0 :
      date_time_start=None
    pairs=  args.get('pairs','BTC/USDT')
    if isinstance(pairs, str):
      pairs=[pairs]
    file_path = args.get('path','./user_data/')
    file_pair_mask = args.get('pair_file_mask','file.feather')
    file_name_mask = f"{file_path}/{file_pair_mask}"
    for pair in pairs:
      src_file_name = file_name_mask.format(pair=pair.replace('/','_'),tframe='trades',from_date=date_time_start) 
      for tframe in args.get('timeframes','5min'):
        __logger.info(f"Processing {pair} from {src_file_name} ")
        df_pair = load_feather_trades(path=src_file_name, convert_timestamp='timestamp', index_col=None)
        __logger.info(f"Generate OHLCV file {tframe}")
        df_candle = trades_as_2OHLCV(df=df_pair, 
                       timeframe=tframe,
                       fields_names=fields_names_kraken,   
                       sum_cols = ['v_bl',
                                   'v_bm',
                                   'v_sl',
                                   'v_sm'
                                   ]
                       )
        candlepath =  file_name_mask.format(pair=pair.replace('/','_'),tframe=tframe,from_date=date_time_start) 
        save_feather_trades(df_data=df_candle,file_path=candlepath,unique_col=None)
        __logger.info(f"Processing {pair} written to {candlepath} ")
        
  def parse_args():
      parser = argparse.ArgumentParser(
          description="High-performance crypto trade history downloader→ candle builder",
          formatter_class=argparse.ArgumentDefaultsHelpFormatter   # THIS LINE IS GOLD
      )
  
      # ── PAIRS ─────────────────────────────────────────────────────
      group_pairs = parser.add_mutually_exclusive_group()
      group_pairs.add_argument(
          '-p', '--pairs',
          nargs='+',
          default='BTCUSDT ETHUSDT',           # ← your real default
          metavar='PAIR',
          help='Space-separated list of trading pairs (default: %(default)s)'
      )
      group_pairs.add_argument(
          '--pair-file-mask',
          type=Path,
          default=Path('{pair}-{tframe}-{from_date}.feather',follow_symlinks=True),
          metavar='FILE',
          help='Mask forming file name for history data ( default: %(default)s)'
      )
  
      # ── TIMERANGE ────────────────────────────────────────────────
      parser.add_argument(
          '--timerange',
          type=str,
          default='2025-01-01',                      # ← example: from 2025-11-16 to now
          help='Timerange in freqtrade format: YYYY-MM-DD (default: %(default)s)'
      )
  
      parser.add_argument(
          '--path', '-d',
          type=Path,
          default=Path('./user_data/feather/',follow_symlinks=True),
          help='directory for history'
      )
      parser.add_argument(
          '--timeframes', '-t',
          nargs='+',
          default=['5min'], #['1min', , '15min', '1h', '4h', '1d'],
          help='Timeframes to generate Nmin Mh Xd (  (default: %(default)s) )'
      )
  
      args = parser.parse_args()
  
      # ── POST-PROCESSING (very useful) ─────────────────────────────
      # Make sure output dir exists
      if not args.path.exists():
        msg = f" path {args.output} does not exist "
        __logger.exception(msg=msg)
        raise NotADirectoryError(msg)
      
      return args
  main()
