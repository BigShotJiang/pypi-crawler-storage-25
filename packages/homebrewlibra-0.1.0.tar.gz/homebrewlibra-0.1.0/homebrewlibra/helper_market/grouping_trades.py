'''
Created on 17 Dec 2025

@author: alex
'''
from pandas.core.frame import DataFrame
from pandas.core.series import Series
import logging
import inspect
from typing import Callable

__logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s + %(name)s  - %(levelname)s - %(message)s')

#
#
#

def make_apply_func(
    apply_func:callable, 
    matched_cols:dict=None, 
    **kwargs
    )->Callable:
  """
  Factory function that creates a wrapper (homebrewlibra.helper_func) around the provided 
  apply_func.
  This wrapper injects column name mappings from matched_cols into kwargs if 
  provided, allowing the apply_func to use standardized column names regardless 
  of the actual DataFrame column names.
  
  Sample usage:
  newdf = newdf.groupby(grouping_new, sort=False).apply(
      make_apply_func(threshold, category, my_homebrewlibra.helper_func)  
      # Note: This sample seems incomplete; likely meant to pass apply_func 
      and other args.
  )
  
  Parameters:
  - apply_func: The main function to apply to each group 
  (e.g., complex_group_processing).
  - matched_cols: Optional dict mapping standard keys ('price', 'amount', etc.) 
  to actual column names in the DataFrame.
  - **kwargs: Additional keyword arguments passed to apply_func.
  
  Returns:
  - A helper function that can be used in DataFrame.groupby().apply().
  """
  # Get the names of parameters that apply_func actually accepts
  try:
    sig = inspect.signature(apply_func)
#    call_kwargs = set(sig.parameters)  # dict()
#    if 'group' in sig.parameters and list(sig.parameters)[0] == 'group':
#            call_kwargs.discard('group')
    # Remove 'group' if it's positional (very common pattern)
#    if 'group' in sig.parameters and list(sig.parameters)[0] == 'group':
#      valid_names.discard('group')  # we'll pass it positionally
  
  except (ValueError, TypeError):
    # Fallback for functions without signature (builtins, C extensions, etc.)
    pass
  try:
    if isinstance(matched_cols,dict): 
      """
      matched_cols - dictionary of actual names for dataframe table matched to 
      predefined meaning required for further calc    
      """
#      new_params:dict=kwargs
      scol=list(matched_cols.keys())[0]
      
      for col in matched_cols:
         
        if col[0] == "*":
          var_name = scol+"_val"+col[1:]
        else:
          scol=col
          var_name = col +"_name"
        # form dict with changed values 
        if var_name not in kwargs.keys() and var_name in (sig.parameters):
          # add for replacement list 
          kwargs[var_name]= matched_cols.get(col)
          
    # if new_params exist - apply it as default values 
#      if len(kwargs) >0:
#        call_kwargs = {
#            pname :kwargs.get(pname,p.default)
#                for pname, p in sig.parameters.items()
#            }
      if 'group' in kwargs.keys():
        kwargs.pop('group')
        __logger.debug("'group' removed")
    else:
      __logger.warning("no matched_cols provided")
  except (ValueError, TypeError) as e:
    # report error in data provided
      __logger.error(f"unable to update matched_cols data {e}")

  # helper func should have only one parameter, but we need more.
  # we add predefined names pairs into kwargs 
  # passed apply_func take group as first arg and optional as kward  
  def helper_func(group):
      return apply_func(group,**kwargs )
  return helper_func
#
#
#

def group_filter_template(
    group:DataFrame,
    timestamp_name:str,
    price_name:str,
    amount_name:str,
    type_name:str,
    type_val_:str,
    side_name:str,
    side_val_:str,
    id_name:str,
    **kwargs,  
    )->Series:
  """
  groups trades which looks like single market order splitted to match each 
  existing and matched limit orders on the same or next orderbook level.
  this series expected to be 
  single market followed by other operation 
  ( error/warning if it will be same side operation on the same timestamp)
  within timestamp  chain incrementing to next possible closest 
  along with change price ( increase for market buy and decrease for market sell
  and ended with market   
  
  last bit expecting 
    
  This is useful for removing insignificant trades or data points in financial 
  processing.
    
    Parameters:
    - group: A pandas DataFrame subgroup from groupby.
    - **kwargs: 'amount' (column name for amount), 'amount_min' 
    (threshold value, default 0.00).
    
    Returns:
    - The original group if it meets the threshold, else an empty DataFrame (head(0)).
  """
  try:
    msg0=" parameter price_name "
    msg1=f"has value{price_name}" if price_name is None else f"missed"
    __logger.debug(msg0.join(msg1))
    msg0=" parameter amount_name "
    msg1=f"has value{amount_name}" if amount_name is None else f"missed"
    __logger.debug(msg0.join(msg1))
    msg0=" parameter id_name "
    msg1=f"has value{id_name}" if id_name is None else f"missed"
    __logger.debug(msg0.join(msg1))
    msg0=" parameter type_name "
    msg1=f"has value{type_name}" if type_name is None else f"missed"
    __logger.debug(msg0.join(msg1))
    msg0=" parameter type_val_ "
    msg1=f"has value{type_val_}" if type_val_ is None else f"missed"
    __logger.debug(msg0.join(msg1))
    msg0=" parameter timestamp_name "
    msg1=f"has value{timestamp_name}" if timestamp_name is None else f"missed"
    __logger.debug(msg0.join(msg1))
    msg0=" parameter side_name "
    msg1=f"has value{side_name}" if side_name is None else f"missed"
    __logger.debug(msg0.join(msg1))
    msg0=" parameter side_val_ "
    msg1=f"has value{side_val_}" if side_val_ is None else f"missed"
    __logger.debug(msg0.join(msg1))
    
    newseries:Series = Series({})
    newseries:DataFrame=group
  except ValueError as e:
    __logger.exception(f"{e} processing ",exc_info=True) 
  return newseries

  
#
#
#
 
def group_processing_omwc( 
    group:DataFrame , 
    timestamp_name:str,
    price_name:str='price', 
    amount_name:str='amount', 
    id_name:str='id',
    type_name:str='type',
    keep_columns:list=[],
    **kwargs
    )->Series:
  """
    Processes a grouped DataFrame (e.g., from groupby) to compute aggregated 
    statistics for trading/financial data, such as open/close prices, mean, 
    weighted average, volume, cost, etc.
    
    This function extracts key metrics from the group, assuming columns 
    like price, amount, type, and id.
    It handles potential errors gracefully by logging them.
    
    Parameters:
    - group: A pandas DataFrame subgroup from groupby.
    - **kwargs: Column name overrides (e.g., 'price' for price column name) and
    values (e.g., '*market' for type filter).
    
    Returns:
    - A pandas Series with computed metrics: 'open', 'close', 'mean', 
    'weight' (weighted avg), 'volume', 'cost', 'first' (trade_id), 
    'unique' (count of market types or at least 1).

old params 

  price_name = kwargs.get('price', 'price')
  amount_name = kwargs.get('amount','amount')
  trade_id = kwargs.get('id','id')
  use to calc unique orders in this timeframe 
  type_name  = kwargs.get('type','type')
  type_valmarket = kwargs.get('*market','market')
  """  

  try:
    price_name = 'weight' if 'weight' in group.columns else price_name
    price_open = 'open'   if 'open'   in group.columns else price_name
    price_clos = 'close'  if 'close'  in group.columns else price_name
    tmp_amount =  group[amount_name].sum()
    tmp_cost   = (group[price_name]* group[amount_name]).sum()
    
    newseries:Series = Series({
      'open'      :( group[price_open].iloc[ 0]),
      'close'     :( group[price_clos].iloc[-1]),
      'mean'      :( group[price_name].mean()  ),
      'weight'    :( tmp_cost/tmp_amount ),
      amount_name :( tmp_amount),
      'cost'      :( tmp_cost),
      id_name     :( group[id_name ].iloc[-1]),#group.index[ 0]),
      'count'     :( len(group)),
      type_name   :( group[type_name].iloc[-1]),
      })
    for cl in     keep_columns:
      if  cl in group.columns:
        newseries[cl]    =(group[cl].iloc[-1])
        newseries[cl+'0']=(group[cl].iloc[0])
            

  except ValueError as e:
    __logger.exception(e,exc_info=True)
  
  return newseries


def group_processing_drop(group:DataFrame, cost_name, **kwargs)->Series:
  """
  Filters out "noise" groups where the total amount is below a minimum threshold.
  If the group's total amount > amount_min, returns the original group; 
  otherwise, returns an empty DataFrame.
    
  This is useful for removing insignificant trades or data points in financial 
  processing.
    
    Parameters:
    - group: A pandas DataFrame subgroup from groupby.
    
    Returns:
    - The original group if it meets the threshold, else an empty DataFrame (head(0)).
  """
  
  len2save = 0 if group[cost_name].iloc[0] < kwargs.get('mincost',100.0) else len(group)
  new_group:DataFrame=group.iloc[0:len2save]
  return new_group


#
#
#

def group_filter_jointrades(
    group:DataFrame,
    price_name:str,
    amount_name:str,
    cost_name:str,
    )->DataFrame:
  """
  groups trades which looks like single market order splitted to match each 
  existing and matched limit orders on the same or next orderbook level.
  this series expected to be 
  single market followed by other operation 
  ( error/warning if it will be same side operation on the same timestamp)
  within timestamp  chain incrementing to next possible closest 
  along with change price ( increase for market buy and decrease for market sell
  and ended with market   
  
  last bit expecting 
    
  This is useful for removing insignificant trades or data points in financial 
  processing.
    
    Parameters:
    - group: A pandas DataFrame subgroup from groupby.
    - **kwargs used new fields names : 
    (threshold value, default 0.00).
    
    Returns:
    - The original group if it meets the threshold, else an empty DataFrame (head(0)).
  """
  try:
    tmp_amount = group[amount_name].sum()
    tmp_cost   = (group[price_name]* group[amount_name]).sum()
    newseries   =group.tail(1)
    idx=newseries.index[-1]
     
    newseries.loc[idx, price_name ] = tmp_cost/tmp_amount
    newseries.loc[idx, amount_name] = tmp_amount
    if cost_name in group.columns:
      newseries.loc[idx, cost_name  ] = tmp_cost

  except ValueError as e:
    __logger.exception(f"{e} processing ",exc_info=True) 
  return newseries
#
#
#

def table_grouping_by(
    df:DataFrame, 
    grouping_col:str='timestamp',
    grouping_new:str = None,
    matched_cols:dict=None, 
    apply_func=None,
    drop_grouping:bool=False,
    **kwargs
    )->DataFrame:
  """
  
    Prepares and groups a DataFrame by a time-based column each timestamps ,
    then applies a processing function to each group.
    
    This function creates a new grouping column if needed, groups the DataFrame, and applies the specified apply_func
    (default: complex_group_processing) using the make_apply_func wrapper for column mapping.
    
    Parameters:
    - df: Input pandas DataFrame.
    - grouping_col: Existing column to base the new grouping on (e.g., a datetime column).
    - grouping_new: Name of the new grouping column (default 'date').
    - matched_cols: Dict for column name mappings (passed to make_apply_func).
    - apply_func: Function to apply to each group (default complex_group_processing).
    - **kwargs: Additional args passed to apply_func.
    
    Returns:
    - A new DataFrame with grouped and processed data.
    
    Raises:
    - ValueError if grouping_col is not in the DataFrame.
  """
  
  newdf:DataFrame=df.copy(deep=True)
#  newdf.reset_index(drop=True)
  if isinstance(grouping_col, list) or ( isinstance(grouping_col, str) and 
                                         grouping_col in newdf.columns) : 
#    if grouping_new is None:
#      grouping_new = grouping_col
    if not grouping_new in newdf.columns:
      # create index column 
      if grouping_new == 'priceup':
        __logger.debug(f"grouping each raising trend value of {grouping_col}")
        if isinstance(grouping_col, str):
          grouping_col =[grouping_col] # make single item list 
        drop_mask = (df[grouping_col].min(axis=1, skipna=True, numeric_only=True) < 
                     df[grouping_col].min(axis=1, skipna=True, numeric_only=True).shift(-1)
                    )
        grouping_new = drop_mask.cumsum()
      elif grouping_new == 'pricedown':
        __logger.debug(f"grouping each declining trend value of {grouping_col}")
        if isinstance(grouping_col, str):
          grouping_col =[grouping_col] # make a single item list 
        drop_mask = (df[grouping_col].min(axis=1, skipna=True, numeric_only=True) > 
                     df[grouping_col].min(axis=1, skipna=True, numeric_only=True).shift(-1)
                    )
        grouping_new = drop_mask.cumsum()
      elif grouping_new == 'mincost':
        mincost= kwargs.get('mincost',100.0)
        __logger.debug(f"drop records below  {grouping_col}")
        drop_mask = df[grouping_col] > mincost # to filter out below min 
        grouping_new = drop_mask
        kwargs['cost_name'] = grouping_col
      else:
        __logger.debug(f"grouping each unique value of {grouping_col}")
        grouping_new = newdf[grouping_col].copy()
        #drop_grouping=True
      #create new column
    else:
      #drop_grouping=True
      grouping_new = newdf[grouping_new].copy()
      __logger.debug(f"grouping_new={grouping_new} was passed ")
  else:
    raise ValueError(f" 'grouping_col'={grouping_col} is not defined in dataframe")
  
  if apply_func == None:
    apply_func = group_filter_jointrades
    __logger.debug("use default group processing function")

  grouped = newdf.groupby(grouping_new, sort=True)
  newdf   = grouped.apply(
    make_apply_func(
      apply_func=apply_func, 
      matched_cols=matched_cols,
      **kwargs),
    include_groups=False
    )
  
  if drop_grouping :
    newdf.reset_index( drop=drop_grouping,  inplace=True)
  print("--->",newdf.index.names," : ",newdf.columns)
  return newdf
####################
#
#
####################

def set_grouping_table_v0(
    df:DataFrame, 
    grouping_col:str=None,
    grouping_new:str = 'date',
    matched_cols:dict=None, 
    apply_func=group_processing_omwc,
    **kwargs)->DataFrame:
  """
  
    Prepares and groups a DataFrame by a time-based column (e.g., flooring timestamps to 120-minute intervals),
    then applies a processing function to each group.
    
    This function creates a new grouping column if needed, groups the DataFrame, and applies the specified apply_func
    (default: complex_group_processing) using the make_apply_func wrapper for column mapping.
    
    Parameters:
    - df: Input pandas DataFrame.
    - grouping_col: Existing column to base the new grouping on (e.g., a datetime column).
    - grouping_new: Name of the new grouping column (default 'date').
    - matched_cols: Dict for column name mappings (passed to make_apply_func).
    - apply_func: Function to apply to each group (default complex_group_processing).
    - **kwargs: Additional args passed to apply_func.
    
    Returns:
    - A new DataFrame with grouped and processed data.
    
    Raises:
    - ValueError if grouping_col is not in the DataFrame.
  """
  
  newdf:DataFrame=df.copy(deep=True)
  
  if not grouping_new in newdf.columns:
    if grouping_col in newdf.columns:
      newdf[grouping_new]=df[grouping_col].dt.floor('120min')
    else:
      raise ValueError(f" 'grouping_col'={grouping_col} is not defined in dataframe")
  else:
    __logger.debug(f"grouping_new={grouping_new} was passed ")
  if apply_func == group_processing_omwc:
    __logger.debug("use default group processing function")

  newdf   = newdf.groupby(grouping_new, sort=False).apply(
    make_apply_func(
      apply_func=apply_func, 
      matched_cols=matched_cols, 
      **kwargs), 
    include_groups=False)
#      newdf.drop(columns=original_columns, errors='ignore', inplace=True)
  return newdf
####################
#
#
####################


#def set_grouping_table_v1(
#    df:DataFrame, 
#    grouping_col:str,
#    matched_cols:dict,
#    grouping_new:str = 'date',
#    apply_func=None,
#    )->DataFrame:
#  newdf:DataFrame=df.copy(deep=True)
#  newdf[grouping_new]=df[grouping_col].dt.floor('120min')
#  price = matched_cols.get('price','price')
#  amount= matched_cols.get('amount','amount')
#  type_c  = matched_cols.get('type','type')
#  type_v  = matched_cols.get('*market','market')
#  trade_id= matched_cols.get('id','id')
#  def complex_group_processing(group:DataFrame)->Series:
#    newseries:Series = Series({
#      'open'  :( group[price].iloc[ 0]),
#      'close' :( group[price].iloc[-1]),
#      'mean'  :( group[price].mean()  ),
#      'weight':((group[price]*group[amount]).sum()/
#                 group[amount].sum()
#                ),
#      'volume':( group[amount].sum()),
#      'cost'  :((group[price]*group[amount]).sum()),
#      'first' :( group[trade_id ]),#group.index[ 0]),
#      'unique':(max((group[type_c] == type_v).sum(),1))
#      })
#    
#    return newseries
##      original_columns = newdf.columns.tolist()
#  newdf   = newdf.groupby(grouping_new, sort=False).apply(complex_group_processing, include_groups=False)
##      newdf.drop(columns=original_columns, errors='ignore', inplace=True)
#  return newdf

