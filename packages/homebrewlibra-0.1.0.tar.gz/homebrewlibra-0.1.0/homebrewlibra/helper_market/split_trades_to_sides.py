'''
Created on 18 Nov 2025

@author: alex
'''
import argparse
import logging
from pandas.core.frame import DataFrame
from pathlib import Path
from typing import Dict, List 
import pandas as pd

__logger = logging.getLogger(__name__)

def trades_split_by_side(
    df:DataFrame,
    markets: Dict[str, List[Dict[str, str]]] = None 
    )->DataFrame:
  """
  Splits trades DataFrame into separate DataFrames based on logical conditions
    defined in `markets`. Each market (e.g., 'buy', 'sell') gets its own filtered DataFrame.

  Multiple dicts in the list → OR
  Conditions inside inner dict → AND
  
    Example:
        'buy': [
            {'side': 'b', 'type': 'm'},   # buyer market order
            {'side': 's', 'type': 'l'}    # taker hit seller's limit → still aggressive buy
        ]

    Parameters:
    -----------
    df : DataFrame
        Raw trades with columns like side, type, etc.
    markets : dict
        Structure defining which trades belong to which aggressive side.

    Returns:
    --------
    Dict[str, DataFrame]
        { 'buy': df_buy, 'sell': df_sell, ... } – each is a filtered view/copy of original rows
     
   """
  if markets is None:
    markets = {
      'b' : [ 
        {'side':'buy','type':'market'},
        {'side':'sell','type':'limit'}
      ],
      's' :[
        {'side':'buy','type':'limit'},
        {'side':'sell','type':'market'}
      ]
    }
  result:Dict[str,DataFrame] = {}   
  for market_name, condition_groups in markets.items():
    filtered = df.head(0).copy()
    for cond in condition_groups:
      # Build AND mask for this condition group
      mask = None
      for col, val in cond.items():
          col_mask = (df[col] == val)
          mask = col_mask if mask is None else (mask & col_mask)
        
      if mask is not None and mask.any():
        try:
#          filtered = pd.concat([filtered,df[mask]], ignore_index=True,copy=True)   # ← HERE: ignore_index=True
          filtered = pd.concat([filtered,df[mask]])#, ignore_index=True,copy=True)   # ← HERE: ignore_index=True
        except BaseException as e:
          __logger.exception( f"Error in filtering records : mask pointing to {len(mask)} records and got error {e} ")
          raise e

    # Final clean index from 0, 1, 2, ...
#    filtered.reset_index(drop=True,inplace=True)
#    filtered = make_col_unique(filtered,unique_col='id')
    result[market_name] = filtered
  return result

if __name__ == '__main__':
  from data_tools import CONVERT_TRADES_COLUMNS
  from homebrewlibra.helper_feather.feather_io_helper import load_feather_trades, save_feather_trades
  from homebrewlibra.helper_market.convert_timestamp_date import make_col_unique

  def parse_args():
    parser = argparse.ArgumentParser(
        description="High-performance crypto trade history downloader→ candle builder",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter   # THIS LINE IS GOLD
    )

    # ── PAIRS ─────────────────────────────────────────────────────
    group_pairs = parser.add_mutually_exclusive_group()
    group_pairs.add_argument(
        '-p', '--pairs',
        nargs='+',
        default='BTC/USDT ETH/USDT',           # ← your real default
        metavar='PAIR',
        help='Space-separated list of trading pairs (default: %(default)s)'
    )
    group_pairs.add_argument(
        '--pair-file',
        type=Path,
        default=Path('BTC_USDT-trades.feather',follow_symlinks=True),
        metavar='FILE',
        help='file name for historical trades data ( default: %(default)s)'
    )

    # ── TIMERANGE ────────────────────────────────────────────────

    parser.add_argument(
        '--path', '-d',
        type=Path,
        default=Path('./user_data/feather/',follow_symlinks=True),
        help='directory for history'
    )

    args = parser.parse_args()

    # ── POST-PROCESSING (very useful) ─────────────────────────────
    # Make sure output dir exists
    if not args.path.exists():
      msg = f" path {args.path} does not exist "
      __logger.exception(msg=msg)
      raise NotADirectoryError(msg)
    
    return args
  def main():
#  fields_names_kraken={
#    'amount':'volume',
#    'side'  :'buy/sell', 
#    'type'  :'market/limit',
#    'buy'   :'b',
#    'sell'  :'s',
#    'market':'m',
#    'limit' :'l',
#    'price':'price',
#    
#    }
#
    logging.basicConfig(
      level=logging.DEBUG,
      format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
      )
  #  ch = logging.StreamHandler()
  #  ch.setLevel(logging.DEBUG)
  #  __logger.addHandler(ch)                 # ← this line was missing!
    __logger.handlers                       # → should show the handler now
  #  __logger.setLevel(logging.DEBUG)
    args = vars(parse_args())
    print("\n=== CONFIGURATION ===")
    for key, value in args.items():
        print(f"{key:12} : {value}")
    print()  
    # Parse the string into a datetime object
    pairs=args['pairs']
    file_path = args.get('path','./user_data/')
  #  file_pair = args.get('pair_file','file.feather')
    file_name_mask = "{file_path}/{pair}{market}-{tframe}.feather"
    for pair in pairs:
      src_file_name = file_name_mask.format(
        file_path=file_path,
        pair=pair.replace('/','_'),
        market='', 
        tframe='trades') 
      __logger.info(f"Processing {pair} from {src_file_name} ")
      df_pair = load_feather_trades(path=src_file_name, convert_timestamp=None, index_col=None)
      df_markets = trades_split_by_side(
        df=df_pair, 
        markets=None
      )
      for mrkt in df_markets.keys():
        df_trades=df_markets[mrkt]
        file_new =  file_name_mask.format(file_path=file_path, pair=pair.replace('/','_'),market=mrkt.capitalize(), tframe='trades')
        save_feather_trades(df_data=df_trades,file_path=file_new,unique_col='id')
        __logger.info(f"Processing {pair} written to {file_new} ")
      


    main()
