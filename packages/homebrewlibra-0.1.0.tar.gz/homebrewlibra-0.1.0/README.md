# HomeBrewLibra

Modular utilities for market data processing and analysis.

## Installation

### Minimal (core only)
```bash
pip install homebrewlibra
```

### With I/O helpers (feather, CSV)
```bash
pip install "homebrewlibra[io]"
```

### For data preparation (market + data + I/O)
```bash
pip install "homebrewlibra[market,data,io]"
```

### For exchange connectivity
```bash
pip install "homebrewlibra[exchange]"
```

### With plotting
```bash
pip install "homebrewlibra[plot]"
```

### Everything (backward compatible)
```bash
pip install "homebrewlibra[all]"
```

## Subpackages

| Subpackage | Extras | Dependencies | Description |
|------------|--------|-------------|-------------|
| `core` | (none) | pandas, numpy | Shared utilities: timestamp parsing, field mapping |
| `helper_market` | `[market]` | core | Trade splitting, grouping, peak detection helpers |
| `helper_data` | `[data]` | core | DataFrame combination, index analysis |
| `helper_feather` | `[io]` | pyarrow | Feather file I/O |
| `helper_csv` | `[io]` | (none) | CSV file I/O |
| `helper_io` | `[io]` | core | Step execution, file caching |
| `helper_exchange` | `[exchange]` | ccxt, requests | Exchange API connectivity |
| `helper_plot` | `[plot]` | matplotlib | Plotting tools |
| `gantt_chart` | `[chart]` | matplotlib | Gantt chart generation |

## Changes in 0.1.0

- **Removed**: `helper_model` (ML utilities). Use `model-core` package instead.
- **Added**: `core` subpackage to break circular imports.
- **Added**: Optional extras `[io]`, `[market]`, `[data]`, `[exchange]`, `[plot]`, `[all]`.
- **Changed**: `pyproject.toml` now declares minimal core deps; heavy deps moved to extras.

## Contributing

Please [fork this project on GitHub](https://github.com/Alex-Glebov/HomeBrewLibra) and send a pull request.
