"""
lapq.models — Dataclasses for all QPU-1 API responses.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator, List, Optional


@dataclass
class JobResult:
    """Returned by every execution call."""

    success: bool
    job_id: Optional[str]
    status: str          # "completed" | "failed" | "queued" | "running"
    output: str          # raw string output from the QPU
    raw: dict = field(repr=False)  # full JSON response for power users

    def __str__(self) -> str:
        return (
            f"JobResult(job_id={self.job_id!r}, status={self.status!r}, "
            f"output={self.output!r})"
        )

    @property
    def bits(self) -> str:
        """Measurement result as a clean bit-string (no trailing newline)."""
        return self.output.strip()

    @property
    def failed(self) -> bool:
        return self.status == "failed" or not self.success


@dataclass
class BatchResult:
    """Returned by :meth:`~lapq.QPU1.batch`."""

    success: bool
    results: List[JobResult]
    raw: dict = field(repr=False)

    def __iter__(self) -> Iterator[JobResult]:
        return iter(self.results)

    def __len__(self) -> int:
        return len(self.results)


@dataclass
class TranspileResult:
    """Returned by :meth:`~lapq.QPU1.transpile`."""

    success: bool
    qreg_code: str
    original_format: str
    raw: dict = field(repr=False)

    def __str__(self) -> str:
        return self.qreg_code


@dataclass
class ValidateResult:
    """Returned by :meth:`~lapq.QPU1.validate`."""

    success: bool
    valid: bool
    issues: List[str]
    stats: dict
    raw: dict = field(repr=False)

    def __bool__(self) -> bool:
        return self.valid


@dataclass
class QuotaInfo:
    """Returned by :meth:`~lapq.QPU1.quota`."""

    jobs_used_today: int
    max_jobs_per_day: int
    max_qubits_per_job: int
    tier: str
    remaining: int

    def __str__(self) -> str:
        return (
            f"QuotaInfo(tier={self.tier!r}, remaining={self.remaining}, "
            f"used={self.jobs_used_today}/{self.max_jobs_per_day})"
        )
