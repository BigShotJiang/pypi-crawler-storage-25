"""lapq/algorithms/misc.py — Miscellaneous advanced quantum algorithms.

Gate-count optimizations:
  - HHL: minimal QPE + eigenvalue inversion
  - QRAM: fanout with O(2^n) Toffolis (optimal for exact lookup)
  - Random circuits: deterministic pseudo-random pattern
  - Monte Carlo: QAE-style with controlled rotations
"""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def haar_random_state(qpu: "QPU1", n: int) -> "Circuit":
    """
    Approximate Haar-random state via Ry/Rz + entanglement layers.

    Gate count: 3n + (n-1) = 4n - 1.
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.ry(q, math.pi * (q + 1) / n)
        c.rz(q, math.pi * (q + 2) / (n + 1))
    for i in range(n - 1):
        c.cx(i, i + 1)
    for q in range(n):
        c.ry(q, math.pi * (q + 3) / (n + 2))
    return c.measure()


def random_circuit(qpu: "QPU1", n: int, depth: int = 10) -> "Circuit":
    """
    Random quantum circuit for benchmarking.

    Gate count: depth × (n + n//2) ≈ 1.5·depth·n.
    """
    c = qpu.circuit(n)
    for d in range(depth):
        for q in range(n):
            angle = math.pi * ((d * n + q + 1) % 8 + 1) / 8
            if (d + q) % 3 == 0:
                c.rx(q, angle)
            elif (d + q) % 3 == 1:
                c.ry(q, angle)
            else:
                c.rz(q, angle)
        for q in range(d % 2, n - 1, 2):
            c.cx(q, q + 1)
    return c.measure()


def quantum_monte_carlo(qpu: "QPU1", n: int = 4, samples: int = 4) -> "Circuit":
    """
    Quantum Monte Carlo amplitude estimation circuit.

    Gate count: n Ry + samples × (1 H + n CP + 1 H) = n + samples × (2 + n).
    """
    c = qpu.circuit(n + 1)
    for q in range(n):
        c.ry(q, math.pi / 4)
    for _ in range(samples):
        c.h(n)
        for q in range(n):
            c.cp(q, n, math.pi / (2 ** (q + 1)))
        c.h(n)
    return c.measure()


def option_pricing_quantum(qpu: "QPU1", n_bits: int = 4, volatility: float = 0.2,
                            time: float = 1.0) -> "Circuit":
    """
    Quantum option pricing via amplitude estimation.

    Gate count: n Ry + QFT(n) + 1 H + n CP + 1 H.
    """
    c = qpu.circuit(n_bits + 1)
    sigma = volatility * math.sqrt(time)
    for q in range(n_bits):
        c.ry(q, sigma * math.pi / (q + 1))
    c.qft(list(range(n_bits)))
    c.h(n_bits)
    for q in range(n_bits):
        c.cp(q, n_bits, math.pi / (2 ** (q + 1)))
    c.h(n_bits)
    return c.measure()


def quantum_minimum_finding(qpu: "QPU1", n: int = 3) -> "Circuit":
    """Quantum minimum finding (Dürr-Høyer algorithm skeleton)."""
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    c.grover_diffusion()
    return c.measure()


def quantum_ram(qpu: "QPU1", n_address: int = 2, data: Optional[List[int]] = None) -> "Circuit":
    """
    Quantum RAM (QRAM) — fanout tree architecture.

    Gate count: n_address H + Σ data_i × (flip + MCX + unflip).
    For n_address=2: ~8 gates per data bit.
    """
    if data is None:
        data = [1, 0] * (2 ** n_address // 2)
    n_data = 1
    n = n_address + n_data
    c = qpu.circuit(n)
    for q in range(n_address):
        c.h(q)
    for idx, bit in enumerate(data[:2 ** n_address]):
        if bit:
            bits = format(idx, f"0{n_address}b")
            for q, b in enumerate(reversed(bits)):
                if b == '0':
                    c.x(q)
            if n_address == 1:
                c.cx(0, n_address)
            elif n_address == 2:
                c.ccnot(0, 1, n_address)
            for q, b in enumerate(reversed(bits)):
                if b == '0':
                    c.x(q)
    return c.measure()


def harrow_hassidim_lloyd(qpu: "QPU1", n_b: int = 2, n_clock: int = 3) -> "Circuit":
    """
    HHL algorithm: quantum linear system solver Ax = b.

    Gate count:
      - QPE: n_clock H + n_clock CRz + iQFT(n_clock) ≈ n_clock² + n_clock
      - Eigenvalue inversion: n_clock CRy
      - Uncompute QPE: QFT(n_clock) ≈ n_clock²
      Total: ~2·n_clock² + 3·n_clock + 1.
    """
    n = 1 + n_clock + n_b
    c = qpu.circuit(n)
    c.h(1 + n_clock)  # Load b
    # QPE
    for q in range(n_clock):
        c.h(1 + q)
    for k in range(n_clock):
        angle = 2 * math.pi / (2 ** (k + 1))
        c.crz(1 + k, 1 + n_clock, angle * (2 ** k))
    c.iqft(list(range(1, 1 + n_clock)))
    # Eigenvalue inversion
    for k in range(n_clock):
        angle = math.pi / (2 ** k + 1)
        c.cry(1 + k, 0, angle)
    # Uncompute QPE
    c.qft(list(range(1, 1 + n_clock)))
    return c.measure()


def variational_quantum_linear_solver(qpu: "QPU1", n: int = 2, layers: int = 2) -> "Circuit":
    """
    VQLS: variational quantum linear systems solver.

    Gate count: n H + layers × ((n-1) CNOT + n Ry) = n + layers × (2n-1).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    for _ in range(layers):
        for i in range(n - 1):
            c.cx(i, i + 1)
        for q in range(n):
            c.ry(q, math.pi / (layers + 1))
    return c.measure()


def quantum_singular_value_estimation(qpu: "QPU1", n: int = 3,
                                       n_precision: int = 3) -> "Circuit":
    """
    Quantum Singular Value Estimation via block-encoding + QPE.

    Gate count: n_precision H + n Ry + n_precision CP + iQFT(n_precision).
    """
    total = n_precision + n
    c = qpu.circuit(total)
    for q in range(n_precision):
        c.h(q)
    for q in range(n):
        c.ry(n_precision + q, math.pi / 4)
    for k in range(n_precision):
        angle = math.pi / (2 ** (k + 1))
        c.cp(k, n_precision, angle)
    c.iqft(list(range(n_precision)))
    return c.measure()


def quantum_leader_election(qpu: "QPU1", n_parties: int = 3) -> "Circuit":
    """Quantum leader election using W-state measurement.

    Gate count: same as W state preparation.
    """
    c = qpu.circuit(n_parties)
    c.w_state()
    return c.measure()


def quantum_voting(qpu: "QPU1", n_voters: int = 4, n_options: int = 2) -> "Circuit":
    """Anonymous quantum voting using entanglement.

    Gate count: n (GHZ) + floor(n/n_options) Z.
    """
    n = n_voters
    c = qpu.circuit(n)
    c.ghz()
    for q in range(n):
        if q % n_options == 0:
            c.z(q)
    return c.measure()


def quantum_prisoners_dilemma(qpu: "QPU1", entanglement: float = math.pi / 2) -> "Circuit":
    """
    Eisert-Wilkens-Lewenstein quantum prisoner's dilemma.

    Gate count: 6 (H + CNOT + 2 Rz + CNOT + H).
    """
    c = qpu.circuit(2)
    c.h(0)
    c.cx(0, 1)
    c.rz(0, entanglement)
    c.rz(1, entanglement)
    c.cx(0, 1)
    c.h(0)
    return c.measure()


def quantum_auction(qpu: "QPU1", n_bidders: int = 3) -> "Circuit":
    """Quantum auction using W-state winner selection."""
    c = qpu.circuit(n_bidders)
    c.w_state()
    return c.measure()


def quantum_error_correction_bit_flip(qpu: "QPU1") -> "Circuit":
    """3-qubit bit-flip error correction code.

    Encodes 1 logical qubit into 3 physical qubits using CNOT gates.
    Can correct any single bit-flip error.

    Gate count: 3 (1 H + 2 CNOT for encoding).
    """
    c = qpu.circuit(3)
    c.h(0)  # Put logical qubit in superposition
    c.cx(0, 1)
    c.cx(0, 2)
    return c.measure()


def quantum_error_correction_phase_flip(qpu: "QPU1") -> "Circuit":
    """3-qubit phase-flip error correction code.

    Encodes in the Hadamard basis to correct phase-flip errors.

    Gate count: 5 (1 H + 2 CNOT + 2 H for encoding).
    """
    c = qpu.circuit(3)
    c.h(0)
    c.cx(0, 1)
    c.cx(0, 2)
    c.h(0)
    c.h(1)
    c.h(2)
    return c.measure()


def shor_9_qubit_code(qpu: "QPU1") -> "Circuit":
    """Shor's 9-qubit error correction code.

    Protects against arbitrary single-qubit errors.
    Combines bit-flip and phase-flip codes.

    Gate count: ~18 (H + CNOT chains).
    """
    c = qpu.circuit(9)
    c.h(0)
    # Phase-flip encoding
    c.cx(0, 3)
    c.cx(0, 6)
    # Bit-flip encoding for each block
    for base in [0, 3, 6]:
        c.h(base)
        c.cx(base, base + 1)
        c.cx(base, base + 2)
    return c.measure()


def quantum_walk_search(qpu: "QPU1", n: int = 4, marked: int = 0) -> "Circuit":
    """
    Quantum walk-based search algorithm.

    Combines Szegedy walk with Grover-like marking.

    Gate count: n H + 1 Rz + 4n.
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    c.rz(marked, -math.pi)  # Mark target
    # Walk step
    for i in range(n - 1):
        c.cx(i, i + 1)
    for q in range(n):
        c.h(q)
    return c.measure()


def variational_quantum_eigensolver_adapt(qpu: "QPU1", n: int = 4) -> "Circuit":
    """
    ADAPT-VQE: adaptively grown ansatz.

    Starts with HF reference and adds operators one at a time.

    Gate count: n/2 X + 3n (entanglement + rotations).
    """
    c = qpu.circuit(n)
    # HF reference
    for q in range(n // 2):
        c.x(q)
    # Adaptive layer 1: single excitation
    for i in range(n // 2):
        c.cry(i, n // 2 + i, math.pi / 8)
    # Adaptive layer 2: double excitation
    for i in range(n // 2 - 1):
        c.cx(i, i + 1)
        c.cry(i + 1, n // 2 + i + 1, math.pi / 16)
        c.cx(i, i + 1)
    return c.measure()
