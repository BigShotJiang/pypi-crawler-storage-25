"""lapq/algorithms/dynamics.py — Dynamics, Lattice Models & Metrology algorithms.

Gate-count optimizations:
  - RZZ/RXX/RYY use 1 CNOT each (optimal)
  - Dynamical decoupling: fused Rz+X sequences
  - Ramsey/Hahn echo: minimal H-Rz-H pattern
  - Heisenberg model: 3 gates per bond per step (RXX+RYY+RZZ)
"""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def schrodinger_evolution(qpu: "QPU1", n: int, time: float = 1.0,
                           steps: int = 4) -> "Circuit":
    """
    Trotterized Schrödinger time evolution for a chain (ZZ + X Hamiltonian).

    Gate count: n H + steps × ((n-1)×3 + n) = n + steps × (4n-3).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rzz(i, i + 1, dt)
        for q in range(n):
            c.rx(q, dt)
    return c.measure()


def uhrig_dynamical_decoupling(qpu: "QPU1", n: int, n_pulses: int = 4) -> "Circuit":
    """
    Uhrig Dynamical Decoupling (UDD) sequence.

    Applies X pulses at Uhrig-optimal times to suppress decoherence.
    Pulse times: t_k = sin²(πk/(2M+2)) where M = n_pulses.

    Gate count: n H + n_pulses × 2n = n(1 + 2·n_pulses).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    for k in range(1, n_pulses + 1):
        angle = math.pi * math.sin(math.pi * k / (2 * n_pulses + 2)) ** 2
        for q in range(n):
            c.rz(q, angle)
            c.x(q)
    return c.measure()


def carr_purcell_meiboom_gill(qpu: "QPU1", n: int, n_echoes: int = 4) -> "Circuit":
    """
    CPMG spin-echo sequence for dynamical decoupling.

    Gate count: n H + n_echoes × 3n = n(1 + 3·n_echoes).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    interval = math.pi / (2 * n_echoes)
    for _ in range(n_echoes):
        for q in range(n):
            c.rz(q, interval)
            c.x(q)
            c.rz(q, interval)
    return c.measure()


def xy_decoupling(qpu: "QPU1", n: int, seq_len: int = 4) -> "Circuit":
    """
    XY-4 / XY-8 dynamical decoupling sequence.

    Alternates X and Y pulses with free evolution intervals.

    Gate count: n H + seq_len × 2n.
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    interval = math.pi / (2 * seq_len)
    for i in range(seq_len):
        for q in range(n):
            c.rz(q, interval)
            if i % 2 == 0:
                c.x(q)
            else:
                c.y(q)
    return c.measure()


def heisenberg_model(qpu: "QPU1", n: int, J: float = 1.0, time: float = 1.0,
                      steps: int = 4) -> "Circuit":
    """
    Isotropic Heisenberg model: H = J Σ (XX + YY + ZZ).

    Gate count: n H + steps × (n-1)×3×3 = n + 9·steps·(n-1).
    Each bond needs RXX + RYY + RZZ = 3 two-qubit gates, each 1 CNOT.
    Total CNOTs: 3·steps·(n-1).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rxx(i, i + 1, J * dt)
            c.ryy(i, i + 1, J * dt)
            c.rzz(i, i + 1, J * dt)
    return c.measure()


def transverse_ising_model(qpu: "QPU1", n: int, J: float = 1.0, h: float = 0.5,
                            time: float = 1.0, steps: int = 4) -> "Circuit":
    """
    Transverse-field Ising model: H = -J Σ ZZ - h Σ X.

    Gate count: n H + steps × ((n-1)×3 + n) = n + steps × (4n-3).
    CNOTs: steps × (n-1).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rzz(i, i + 1, 2 * J * dt)
        for q in range(n):
            c.rx(q, 2 * h * dt)
    return c.measure()


def xy_model(qpu: "QPU1", n: int, J: float = 1.0, h: float = 0.5,
              time: float = 1.0, steps: int = 4) -> "Circuit":
    """XY Model: H = J Σ (XX + YY) - h Σ Z.

    Gate count: n H + steps × ((n-1)×2×3 + n) = n + steps × (7n-6).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rxx(i, i + 1, J * dt)
            c.ryy(i, i + 1, J * dt)
        for q in range(n):
            c.rz(q, h * dt)
    return c.measure()


def ramsey_interferometry(qpu: "QPU1", n: int = 1, wait_time: float = 0.5) -> "Circuit":
    """
    Ramsey interferometry for quantum sensing.
    H → free evolution (Rz) → H → measure.

    Gate count: 3n (H + Rz + H per qubit).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
        c.rz(q, 2 * math.pi * wait_time)
        c.h(q)
    return c.measure()


def spin_echo_sensing(qpu: "QPU1", n: int = 1, interrogation_time: float = 0.5) -> "Circuit":
    """
    Spin-echo (Hahn echo) quantum sensing circuit.

    H → Rz → X → Rz → X → H. The X pulses refocus static noise.

    Gate count: 5n (H + Rz + X + Rz + X + H per qubit, but 2 X's cancel noise).
    Reduced: 5n (can't fuse further due to different roles).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
        c.rz(q, math.pi * interrogation_time)
        c.x(q)
        c.rz(q, math.pi * interrogation_time)
        c.x(q)
        c.h(q)
    return c.measure()


def quantum_magnetometry(qpu: "QPU1", n: int = 1, field_strength: float = 0.1) -> "Circuit":
    """Quantum magnetometry sensor (Ramsey protocol)."""
    return ramsey_interferometry(qpu, n, wait_time=field_strength)


def heisenberg_limited_sensing(qpu: "QPU1", n_probes: int = 4,
                                parameter: float = 0.1) -> "Circuit":
    """
    Heisenberg-limited phase estimation using GHZ probe state.

    Achieves 1/n scaling (vs 1/√n for classical).

    Gate count: n (GHZ) + n (Rz) + (n-1) CNOT + 1 H = 3n.
    """
    c = qpu.circuit(n_probes)
    c.ghz()
    for q in range(n_probes):
        c.rz(q, parameter * n_probes)
    # Inverse GHZ for readout
    for q in range(1, n_probes):
        c.cx(0, q)
    c.h(0)
    return c.measure()


def xxz_model(qpu: "QPU1", n: int, Jxy: float = 1.0, Jz: float = 0.5,
               time: float = 1.0, steps: int = 4) -> "Circuit":
    """
    XXZ model: H = Jxy Σ (XX + YY) + Jz Σ ZZ.

    Interpolates between Heisenberg (Jxy=Jz) and Ising (Jxy=0) models.

    Gate count: n + steps × ((n-1)×9) = n + 9·steps·(n-1).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rxx(i, i + 1, Jxy * dt)
            c.ryy(i, i + 1, Jxy * dt)
            c.rzz(i, i + 1, Jz * dt)
    return c.measure()


def floquet_dynamics(qpu: "QPU1", n: int, periods: int = 4) -> "Circuit":
    """
    Floquet (periodically driven) quantum dynamics.

    Alternates between XX coupling and Z-field.

    Gate count: n + periods × ((n-1)×3 + n) = n + periods×(4n-3).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    for period in range(periods):
        for i in range(n - 1):
            c.rxx(i, i + 1, math.pi / 4)
        for q in range(n):
            c.rz(q, math.pi * (period + 1) / (2 * periods))
    return c.measure()
