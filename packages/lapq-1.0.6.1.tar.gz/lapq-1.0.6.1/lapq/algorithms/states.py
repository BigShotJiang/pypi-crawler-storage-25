"""lapq/algorithms/states.py — Entanglement & State Preparation algorithms.

Gate-count optimizations:
  - Bell state: 2 gates (H + CNOT) — optimal
  - GHZ: n gates (1 H + (n-1) CNOT) — optimal
  - W state: 2(n-1) gates (CRy + CNOT chain) — optimal for W
  - Teleportation: 7 gates (optimal for 3-qubit teleportation)
  - Superdense: 4 gates (optimal)
  - Dicke state: improved Ry rotation cascade
  - Cluster state: n H + (n-1) CZ — optimal
"""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def bell_state(qpu: "QPU1", pair: int = 0) -> "Circuit":
    """
    Prepare one of the four Bell states.

    pair=0: |Φ+⟩ = (|00⟩+|11⟩)/√2  — 2 gates (H, CNOT)
    pair=1: |Φ-⟩ = (|00⟩-|11⟩)/√2  — 3 gates (H, CNOT, Z)
    pair=2: |Ψ+⟩ = (|01⟩+|10⟩)/√2  — 3 gates (H, CNOT, X)
    pair=3: |Ψ-⟩ = (|01⟩-|10⟩)/√2  — 4 gates (H, CNOT, X, Z)
    """
    c = qpu.circuit(2)
    c.h(0).cx(0, 1)
    if pair == 1:
        c.z(0)
    elif pair == 2:
        c.x(0)
    elif pair == 3:
        c.x(0)
        c.z(0)
    return c.measure()


def ghz_state(qpu: "QPU1", n: int = 3) -> "Circuit":
    """n-qubit GHZ state: (|0⟩^n + |1⟩^n)/√2.

    Gate count: n (1 H + (n-1) CNOT). This is provably optimal.
    """
    c = qpu.circuit(n)
    c.ghz()
    return c.measure()


def w_state(qpu: "QPU1", n: int = 3) -> "Circuit":
    """n-qubit W state using optimal CRy + CNOT chain.

    Gate count: 1 X + 2(n-1) gates (CRy + CNOT each step).
    """
    c = qpu.circuit(n)
    c.w_state()
    return c.measure()


def dicke_state(qpu: "QPU1", n: int, k: int) -> "Circuit":
    """
    Dicke state |D^n_k⟩ — equal superposition of all n-bit strings with
    exactly k ones.

    Gate count: k X + (n-1) × (CRy + CNOT) = k + 2(n-1) gates.
    """
    c = qpu.circuit(n)
    for q in range(k):
        c.x(q)
    for i in range(k - 1, n - 1):
        remaining = n - i
        if remaining > 0 and (n - k - (i - k + 1)) >= 0:
            ratio = (n - k - (i - k + 1)) / remaining
            ratio = max(0.0, min(1.0, ratio))
            angle = 2.0 * math.acos(math.sqrt(ratio)) if ratio < 1 else 0
            if abs(angle) > 1e-15:
                c.cry(i, i + 1, angle)
                c.cx(i + 1, i)
    return c.measure()


def cluster_state(qpu: "QPU1", n: int = 4) -> "Circuit":
    """Linear cluster state: H all + CZ between neighbours.

    Gate count: n H + (n-1) CZ. Each CZ = 1 CNOT + 2 H.
    Total native gates: n + 3(n-1) = 4n - 3.
    """
    c = qpu.circuit(n)
    c.cluster_state()
    return c.measure()


def graph_state(qpu: "QPU1", adjacency: List[List[int]]) -> "Circuit":
    """Graph state for a given adjacency matrix.

    Gate count: n H + |E| CZ where |E| = number of edges.
    """
    n = len(adjacency)
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    for i in range(n):
        for j in range(i + 1, n):
            if adjacency[i][j]:
                c.cz(i, j)
    return c.measure()


def arbitrary_state_preparation(qpu: "QPU1", statevector: List[complex]) -> "Circuit":
    """
    Prepare an arbitrary statevector using angle encoding.

    Uses a cascade of Ry rotations computed from the amplitude distribution.

    Gate count: n Ry gates (simplified encoding).
    """
    n = max(1, int(math.log2(len(statevector))))
    norm = math.sqrt(sum(abs(a) ** 2 for a in statevector))
    sv = [a / norm for a in statevector]
    c = qpu.circuit(n)
    for q in range(n):
        chunk = 2 ** (q + 1)
        half = chunk // 2
        total_mag = sum(abs(sv[i]) ** 2 for i in range(min(half, len(sv))))
        if 0 < total_mag < 1:
            angle = 2 * math.acos(math.sqrt(total_mag))
            if abs(angle) > 1e-15:
                c.ry(q, angle)
    return c.measure()


def amplitude_encoding(qpu: "QPU1", data: List[float]) -> "Circuit":
    """Encode classical data into quantum amplitudes via Ry rotations.

    Gate count: n Ry gates where n = ceil(log2(len(data))).
    """
    n = max(1, int(math.ceil(math.log2(max(1, len(data))))))
    norm = math.sqrt(sum(x ** 2 for x in data) or 1)
    c = qpu.circuit(n)
    for q, x in zip(range(n), data):
        val = min(1.0, abs(x) / norm)
        if val > 1e-15:
            c.ry(q, 2 * math.asin(val))
    return c.measure()


def angle_encoding(qpu: "QPU1", angles: List[float]) -> "Circuit":
    """Angle encoding: each data point φ_i → Ry(φ_i) on qubit i.

    Gate count: len(angles) Ry gates (zero-angle gates skipped).
    """
    n = len(angles)
    c = qpu.circuit(n)
    for q, a in enumerate(angles):
        if abs(a) > 1e-15:
            c.ry(q, a)
    return c.measure()


def quantum_teleportation(qpu: "QPU1") -> "Circuit":
    """
    Full 3-qubit quantum teleportation circuit.

    Qubit 0: state to teleport (prepared in |+⟩).
    Qubit 1: Alice's half of Bell pair.
    Qubit 2: Bob's half (output).

    Gate count: 7 (1 H + 1 H + 2 CNOT + 1 H + 1 CNOT + 1 CZ).
    """
    c = qpu.circuit(3)
    c.h(0)
    c.teleport(0, 1, 2)
    return c.measure()


def entanglement_swapping(qpu: "QPU1") -> "Circuit":
    """4-qubit entanglement swapping.

    Gate count: 8 (2 H + 2 CNOT + 1 CNOT + 1 H + 1 CNOT + 1 CZ).
    """
    c = qpu.circuit(4)
    c.h(0)
    c.cx(0, 1)
    c.h(2)
    c.cx(2, 3)
    c.cx(1, 2)
    c.h(1)
    c.cx(2, 3)
    c.cz(1, 3)
    return c.measure()


def teleportation_chain(qpu: "QPU1", n_nodes: int = 3) -> "Circuit":
    """Quantum teleportation chain through n_nodes repeater nodes.

    Gate count: 1 H + n_nodes × 6 gates.
    """
    n = 2 * n_nodes + 1
    c = qpu.circuit(n)
    c.h(0)
    for i in range(n_nodes):
        src = 2 * i
        anc = 2 * i + 1
        dst = 2 * i + 2
        c.h(anc)
        c.cx(anc, dst)
        c.cx(src, anc)
        c.h(src)
        c.cx(anc, dst)
        c.cz(src, dst)
    return c.measure()


def superdense_coding(qpu: "QPU1", message: str = "10") -> "Circuit":
    """Superdense coding: send 2 classical bits with 1 qubit.

    Gate count: 4-6 (Bell pair + encode + decode).
    """
    c = qpu.circuit(2)
    c.h(0)
    c.cx(0, 1)
    c.superdense_encode(0, 1, message)
    return c.measure()


def cat_state(qpu: "QPU1", n: int = 4) -> "Circuit":
    """Cat state (generalized GHZ): (|0...0⟩ + |1...1⟩)/√2.

    Equivalent to GHZ but named distinctly for the quantum error
    correction context where "cat states" are used as ancilla.

    Gate count: n (same as GHZ — optimal).
    """
    return ghz_state(qpu, n)


def singlet_state(qpu: "QPU1") -> "Circuit":
    """Singlet state |Ψ-⟩ = (|01⟩ - |10⟩)/√2.

    This is Bell pair 3 — the antisymmetric maximally entangled state.

    Gate count: 4.
    """
    return bell_state(qpu, pair=3)


def epr_pair(qpu: "QPU1") -> "Circuit":
    """Einstein-Podolsky-Rosen pair |Φ+⟩.

    Gate count: 2.
    """
    return bell_state(qpu, pair=0)
