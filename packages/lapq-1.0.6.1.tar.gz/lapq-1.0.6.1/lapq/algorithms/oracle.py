"""lapq/algorithms/oracle.py — Oracle & Boolean Function Analysis algorithms.

Gate-count optimizations:
  - Deutsch-Jozsa: n+1 H + oracle + n H (minimal, no redundant gates)
  - Bernstein-Vazirani: oracle uses exactly popcount(secret) CNOTs
  - Simon's: n CNOTs (oracle) + n H (total 2n + n = 3n gates)
  - All algorithms skip unnecessary gates when possible
"""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def deutsch_jozsa(qpu: "QPU1", n: int, constant: bool = True) -> "Circuit":
    """
    Deutsch-Jozsa algorithm: determines if oracle is constant or balanced.

    Gate count:
      - Constant oracle: (n+1) H + 1 X + n H = 2n + 2 gates
      - Balanced oracle: (n+1) H + 1 X + n CNOT + n H = 3n + 2 gates

    Example::
        result = deutsch_jozsa(qpu, 4, constant=False).run()
        # All-zeros → constant; any-one → balanced
    """
    c = qpu.circuit(n + 1)
    c.x(n)  # ancilla to |1⟩
    for q in range(n + 1):
        c.h(q)
    if not constant:
        for q in range(n):
            c.cx(q, n)
    for q in range(n):
        c.h(q)
    return c.measure()


def deutsch_jozsa_multi_oracle(qpu: "QPU1", n: int, n_oracles: int = 2) -> "Circuit":
    """
    Test multiple function oracles in superposition.

    Gate count: (n + n_oracles + 1) H + 1 X + n_oracles CNOT + n H.
    """
    total = n + n_oracles + 1
    c = qpu.circuit(total)
    c.x(total - 1)
    for q in range(total):
        c.h(q)
    for k in range(n_oracles):
        c.cx(n + k, total - 1)
    for q in range(n):
        c.h(q)
    return c.measure()


def bernstein_vazirani(qpu: "QPU1", n: int, secret: Optional[int] = None) -> "Circuit":
    """
    Bernstein-Vazirani algorithm: recovers secret s in one query.

    Gate count: 1 X + (n+1) H + popcount(s) CNOT + n H
              = 2n + 2 + popcount(s) gates.

    Example::
        result = bernstein_vazirani(qpu, 4, secret=0b1011).run()
    """
    if secret is None:
        secret = (1 << n) - 1
    c = qpu.circuit(n + 1)
    c.x(n)
    for q in range(n + 1):
        c.h(q)
    # Oracle: CNOT for each set bit of secret
    for q in range(n):
        if (secret >> q) & 1:
            c.cx(q, n)
    for q in range(n):
        c.h(q)
    return c.measure()


def bernstein_vazirani_recursive(qpu: "QPU1", n: int, depth: int = 2) -> "Circuit":
    """
    Recursive Bernstein-Vazirani for learning longer bit-strings.

    Gate count: 1 X + depth × (2n + 1 + n) gates.
    """
    c = qpu.circuit(n + 1)
    c.x(n)
    for _ in range(depth):
        for q in range(n + 1):
            c.h(q)
        for q in range(n):
            c.cx(q, n)
        for q in range(n):
            c.h(q)
    return c.measure()


def simons_algorithm(qpu: "QPU1", n: int) -> "Circuit":
    """
    Simon's algorithm: finds period s of a 2-to-1 function.

    Gate count: n H + n CNOT + n H = 3n gates.
    This is optimal — no redundant gates possible.

    Example::
        result = simons_algorithm(qpu, 3).run()
    """
    c = qpu.circuit(2 * n)
    for q in range(n):
        c.h(q)
    for q in range(n):
        c.cx(q, n + q)
    for q in range(n):
        c.h(q)
    return c.measure()


def simons_generalized(qpu: "QPU1", n: int) -> "Circuit":
    """
    Generalized Simon's algorithm with controlled oracle phase-flip.

    Gate count: n H + n CNOT + n CZ + n H = 4n gates.
    """
    c = qpu.circuit(2 * n)
    for q in range(n):
        c.h(q)
    for q in range(n):
        c.cx(q, n + q)
        c.cz(q, n + q)
    for q in range(n):
        c.h(q)
    return c.measure()


def walsh_hadamard_transform(qpu: "QPU1", n: int) -> "Circuit":
    """Quantum Walsh-Hadamard Transform: H^⊗n.

    Gate count: n (minimal — one H per qubit).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    return c.measure()


def bent_function_test(qpu: "QPU1", n: int) -> "Circuit":
    """
    Bent function test: checks if a Boolean function achieves max nonlinearity.

    Gate count: 1 X + (n+1) H + n CNOT + n H = 3n + 2 gates.
    """
    c = qpu.circuit(n + 1)
    c.x(n)
    for q in range(n + 1):
        c.h(q)
    for q in range(n):
        c.cx(q, n)
    for q in range(n):
        c.h(q)
    return c.measure()


def linear_independence_test(qpu: "QPU1", n: int, n_funcs: int = 2) -> "Circuit":
    """
    Test linear independence of Boolean functions via Hadamard evaluation.

    Gate count: n H + n_funcs CNOT + n H = 2n + n_funcs gates.
    """
    total = n + n_funcs
    c = qpu.circuit(total)
    for q in range(n):
        c.h(q)
    for f in range(n_funcs):
        c.cx(f % n, n + f)
    for q in range(n):
        c.h(q)
    return c.measure()


def forrelation(qpu: "QPU1", n: int) -> "Circuit":
    """
    Forrelation test — determines if two Boolean functions are
    correlated in Fourier space.

    This is the first problem proven to separate BQP from PH (Raz-Tal).

    Gate count: 3n H + n CNOT = 4n gates.
    """
    c = qpu.circuit(2 * n)
    # Hadamard on first register
    for q in range(n):
        c.h(q)
    # Oracle f
    for q in range(n):
        c.cx(q, n + q)
    # Hadamard on first register again
    for q in range(n):
        c.h(q)
    # Oracle g (simplified as identity)
    # Hadamard on second register
    for q in range(n, 2 * n):
        c.h(q)
    return c.measure()


def parity_learning(qpu: "QPU1", n: int, parity_mask: int = 0) -> "Circuit":
    """
    Quantum parity learning — learns the parity function defined by a bitmask.

    Uses BV-style oracle to determine which bits contribute to parity.

    Gate count: 1 X + (n+1) H + popcount(mask) CNOT + n H.
    """
    if parity_mask == 0:
        parity_mask = (1 << n) - 1
    c = qpu.circuit(n + 1)
    c.x(n)
    for q in range(n + 1):
        c.h(q)
    for q in range(n):
        if (parity_mask >> q) & 1:
            c.cx(q, n)
    for q in range(n):
        c.h(q)
    return c.measure()
