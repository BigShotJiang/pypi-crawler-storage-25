"""lapq/algorithms/walks.py — Quantum Walks algorithms.

Gate-count optimizations:
  - Discrete walk: H + CNOT per step (2 gates/step)
  - Continuous walk: Trotterized with RXX/RYY (2 CNOTs per bond per step)
  - Coined walk: coin op + shift in 2 gates per step
  - CTQW search: oracle + evolution in minimal gates
"""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def discrete_quantum_walk_line(qpu: "QPU1", n_steps: int = 4) -> "Circuit":
    """
    Discrete-time quantum walk on an infinite line.

    1 coin qubit + ceil(log2(2·n_steps+1)) position qubits.

    Gate count: 1 H (init) + n_steps × (1 H + 1 CNOT) = 1 + 2·n_steps.
    """
    n_pos = max(2, int(math.ceil(math.log2(2 * n_steps + 2))))
    n = 1 + n_pos
    c = qpu.circuit(n)
    c.h(0)
    for _ in range(n_steps):
        c.h(0)
        c.cx(0, 1)
        if n_pos > 1:
            c.ccnot(0, 1, 2)
    return c.measure()


def discrete_quantum_walk_cycle(qpu: "QPU1", n_nodes: int = 4, steps: int = 4) -> "Circuit":
    """
    Discrete quantum walk on a cycle graph with n_nodes nodes.

    Gate count: 1 H + steps × (1 H + (n_pos) CNOT).
    """
    n_pos = max(2, int(math.ceil(math.log2(n_nodes + 1))))
    n = 1 + n_pos
    c = qpu.circuit(n)
    c.h(0)
    for _ in range(steps):
        c.h(0)
        for p in range(1, n):
            c.cx(0, p)
    return c.measure()


def discrete_quantum_walk_graph(qpu: "QPU1", adjacency: List[List[int]],
                                 steps: int = 3) -> "Circuit":
    """
    Discrete quantum walk on a graph (adjacency matrix).

    Gate count: 1 H + steps × (1 H + |E| CNOT).
    """
    n_nodes = len(adjacency)
    n_pos = max(2, int(math.ceil(math.log2(n_nodes + 1))))
    n = 1 + n_pos
    c = qpu.circuit(n)
    c.h(0)
    for _ in range(steps):
        c.h(0)
        for i in range(n_nodes):
            for j in range(i + 1, n_nodes):
                if adjacency[i][j]:
                    c.cx(0, 1 + (j % n_pos))
    return c.measure()


def continuous_quantum_walk(qpu: "QPU1", n: int, time: float = 1.0,
                             steps: int = 4) -> "Circuit":
    """
    Continuous-time quantum walk via Trotterized evolution.

    H = adjacency matrix → RXX + RYY interactions.

    Gate count: n H + steps × (n-1)×2×3 = n + 6·steps·(n-1).
    CNOTs: 2·steps·(n-1).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rxx(i, i + 1, dt)
            c.ryy(i, i + 1, dt)
    return c.measure()


def ctqw_search(qpu: "QPU1", n: int, marked_node: int = 0,
                time: float = math.pi / 2) -> "Circuit":
    """
    Continuous-time quantum walk search on a complete graph.

    Gate count: n H + 1 Rz + steps × ((n-1)×3 + n) = n + 1 + 4×(4n-3).
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
    c.rz(marked_node, -2 * time)
    dt = time / 4
    for _ in range(4):
        for i in range(n - 1):
            c.rzz(i, i + 1, dt)
        for q in range(n):
            c.rx(q, dt)
    return c.measure()


def coined_walk_1d(qpu: "QPU1", steps: int = 4, coin: str = "H") -> "Circuit":
    """
    1D coined quantum walk with Hadamard or Grover coin.

    Gate count:
      - Hadamard coin: 1 H + steps × (1 H + 1 CNOT) = 1 + 2·steps
      - Grover coin:   1 H + steps × (3 + 1 CNOT) = 1 + 4·steps
    """
    n_pos = max(2, int(math.ceil(math.log2(2 * steps + 2))))
    n = 1 + n_pos
    c = qpu.circuit(n)
    c.h(0)
    for _ in range(steps):
        if coin == "G":
            c.h(0)
            c.z(0)
            c.h(0)
        else:
            c.h(0)
        c.cx(0, 1)
    return c.measure()


def coined_walk_2d(qpu: "QPU1", steps: int = 3) -> "Circuit":
    """
    2D coined quantum walk with 2 coin qubits + 2 position registers.

    Gate count: 2 H + steps × (2 H + 2 CNOT) = 2 + 4·steps.
    """
    n = 6  # 2 coin + 2 pos-x + 2 pos-y
    c = qpu.circuit(n)
    c.h(0)
    c.h(1)
    for _ in range(steps):
        c.h(0)
        c.h(1)
        c.cx(0, 2)
        c.cx(1, 4)
    return c.measure()


def szegedy_walk(qpu: "QPU1", n: int, steps: int = 3) -> "Circuit":
    """
    Szegedy quantum walk — quantized version of a classical Markov chain.

    Uses two copies of the state space with reflection operators.

    Gate count: 2n H + steps × (n CNOT + n H + n CNOT + n H) = 2n + 4n·steps.
    """
    total = 2 * n
    c = qpu.circuit(total)
    for q in range(n):
        c.h(q)
        c.h(n + q)
    for _ in range(steps):
        # Reflection about column space
        for q in range(n):
            c.cx(q, n + q)
        for q in range(n):
            c.h(q)
        # Reflection about row space
        for q in range(n):
            c.cx(n + q, q)
        for q in range(n):
            c.h(n + q)
    return c.measure()
