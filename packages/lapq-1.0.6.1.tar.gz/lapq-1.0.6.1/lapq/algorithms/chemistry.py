"""lapq/algorithms/chemistry.py — Simulation & Chemistry algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional, Dict

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def vqe_molecular(qpu: "QPU1", n_qubits: int, n_layers: int = 2) -> "Circuit":
    """
    VQE ansatz (hardware-efficient) for molecular simulation.

    Parameters
    ----------
    n_qubits: Number of spin-orbitals (qubits).
    n_layers: Depth of the variational ansatz.

    Example::

        result = vqe_molecular(qpu, 4, n_layers=3).run()
    """
    c = qpu.circuit(n_qubits)
    for q in range(n_qubits): c.ry(q, math.pi / 4)
    for _ in range(n_layers):
        for i in range(n_qubits - 1):
            c.cx(i, i + 1)
        for q in range(n_qubits):
            c.ry(q, math.pi / 4)
            c.rz(q, math.pi / 8)
    return c.measure()


def vqe_hydrogen_chain(qpu: "QPU1", n_atoms: int) -> "Circuit":
    """VQE for linear H-chain with *n_atoms* hydrogen atoms (2 qubits per atom)."""
    return vqe_molecular(qpu, n_atoms * 2, n_layers=3)


def vqe_lattice_model(qpu: "QPU1", sites: int, periodic: bool = False) -> "Circuit":
    """VQE for Hubbard/Heisenberg lattice model on *sites* sites."""
    c = qpu.circuit(sites)
    for q in range(sites): c.ry(q, math.pi / 3)
    for i in range(sites - 1):
        c.rzz(i, i + 1, math.pi / 4)
    if periodic and sites > 2:
        c.rzz(0, sites - 1, math.pi / 4)
    for q in range(sites): c.ry(q, math.pi / 6)
    return c.measure()


def vqe_custom_hamiltonian(qpu: "QPU1", n_qubits: int, pauli_terms: List[Dict],
                            n_layers: int = 2) -> "Circuit":
    """
    VQE with hardware-efficient ansatz for a custom Hamiltonian.

    Parameters
    ----------
    pauli_terms: List of dicts like {"qubit": int, "axis": "X"|"Y"|"Z", "coeff": float}.

    Example::

        terms = [{"qubit": 0, "axis": "Z", "coeff": 0.5}, {"qubit": 1, "axis": "X", "coeff": 0.3}]
        vqe_custom_hamiltonian(qpu, 2, terms).run()
    """
    c = qpu.circuit(n_qubits)
    for q in range(n_qubits): c.h(q)
    for _ in range(n_layers):
        for i in range(n_qubits - 1):
            c.cx(i, i + 1)
        for term in pauli_terms:
            q, ax, coeff = term["qubit"], term["axis"].upper(), term.get("coeff", 1.0)
            if ax == "X": c.rx(q, coeff * math.pi / 4)
            elif ax == "Y": c.ry(q, coeff * math.pi / 4)
            elif ax == "Z": c.rz(q, coeff * math.pi / 4)
    return c.measure()


def phase_estimation(qpu: "QPU1", n_precision: int, n_target: int = 1) -> "Circuit":
    """
    Quantum Phase Estimation (QPE) circuit skeleton.

    Parameters
    ----------
    n_precision: Precision qubits (ancilla register).
    n_target:    Target register size.

    The unitary U is approximated as a series of CRz gates.
    Replace with your own controlled-U for real applications.

    Example::

        result = phase_estimation(qpu, 4).run()
    """
    n = n_precision + n_target
    c = qpu.circuit(n)
    # Prepare target
    c.x(n - 1)
    # Superpose precision qubits
    for q in range(n_precision): c.h(q)
    # Controlled-U^(2^k) approximation
    for k in range(n_precision):
        angle = 2 * math.pi / (2 ** (k + 1))
        c.crz(k, n - 1, 2 ** k * angle)
    # Inverse QFT on precision register
    c.iqft(list(range(n_precision)))
    return c.measure()


def iterative_phase_estimation(qpu: "QPU1", n_precision: int) -> "Circuit":
    """
    Iterative QPE — uses only 1 ancilla + target qubit.
    Classically post-processes one bit at a time.
    """
    c = qpu.circuit(2)  # 1 ancilla + 1 target
    c.x(1)  # target in |1⟩ (eigenstate)
    for k in range(n_precision):
        c.h(0)
        angle = 2 * math.pi / (2 ** (k + 1))
        c.crz(0, 1, angle)
        c.h(0)
    return c.measure()


def phase_estimation_kitaev(qpu: "QPU1", phase: float) -> "Circuit":
    """
    Kitaev's single-ancilla phase estimation for phase *phase* ∈ [0, 1).
    """
    c = qpu.circuit(2)
    c.h(0).x(1)
    c.crz(0, 1, 2 * math.pi * phase)
    c.h(0)
    return c.measure()


def trotter_suzuki_simulation(qpu: "QPU1", n: int, time: float,
                               steps: int = 4, order: int = 1) -> "Circuit":
    """
    Trotterized Hamiltonian simulation for the transverse-field Ising model.

    Parameters
    ----------
    n:     Number of spins.
    time:  Total evolution time.
    steps: Number of Trotter steps.
    order: 1 (first-order) or 2 (Suzuki-Trotter).
    """
    c = qpu.circuit(n)
    dt = time / steps
    for _ in range(steps):
        # ZZ interactions
        for i in range(n - 1):
            c.rzz(i, i + 1, dt)
        # Transverse field (X direction)
        for q in range(n):
            c.rx(q, dt)
        if order == 2:
            for q in range(n):
                c.rx(q, dt / 2)
    return c.measure()


def quantum_walk_simulation(qpu: "QPU1", n_position: int, steps: int = 4) -> "Circuit":
    """
    Discrete quantum walk on a line (coin + position register).

    Parameters
    ----------
    n_position: Qubits for position register.
    steps:      Number of walk steps.
    """
    n = 1 + n_position  # 1 coin + n_position
    c = qpu.circuit(n)
    c.h(0)  # coin in superposition
    for _ in range(steps):
        # Coin flip (Hadamard)
        c.h(0)
        # Shift: controlled incrementing of position
        c.cx(0, 1)
        if n_position > 1:
            c.ccnot(0, 1, 2)
    return c.measure()


def ising_model_evolution(qpu: "QPU1", n: int, J: float, h: float, time: float,
                           steps: int = 4) -> "Circuit":
    """
    Real-time evolution of the transverse-field Ising model H = -J Σ ZZ - h Σ X.

    Parameters
    ----------
    n:     Number of spins.
    J:     ZZ coupling strength.
    h:     Transverse field strength.
    time:  Total evolution time t.
    steps: Trotter steps.
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rzz(i, i + 1, 2 * J * dt)
        for q in range(n):
            c.rx(q, 2 * h * dt)
    return c.measure()


def hubbard_model_simulation(qpu: "QPU1", sites: int, U: float, t_hop: float,
                              time: float, steps: int = 4) -> "Circuit":
    """
    Trotterized Fermi-Hubbard model simulation (Jordan-Wigner encoding).

    Parameters
    ----------
    sites:  Number of lattice sites (2 qubits per site: spin-up + spin-down).
    U:      On-site Coulomb repulsion.
    t_hop:  Hopping amplitude.
    time:   Total evolution time.
    steps:  Trotter steps.
    """
    n = 2 * sites
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    dt = time / steps
    for _ in range(steps):
        # Hopping terms
        for i in range(sites - 1):
            c.rxx(2*i, 2*(i+1), t_hop * dt)
            c.ryy(2*i, 2*(i+1), t_hop * dt)
        # On-site interaction
        for i in range(sites):
            c.rzz(2*i, 2*i+1, U * dt / 2)
    return c.measure()


def ucc_ansatz(qpu: "QPU1", n_orbitals: int, n_electrons: int) -> "Circuit":
    """
    Unitary Coupled Cluster Singles & Doubles (UCCSD) ansatz skeleton.

    Parameters
    ----------
    n_orbitals: Number of spin-orbitals (qubits).
    n_electrons: Number of electrons.
    """
    c = qpu.circuit(n_orbitals)
    # HF reference state: fill lowest n_electrons orbitals
    for q in range(n_electrons):
        c.x(q)
    # Single excitations
    for i in range(n_electrons):
        for a in range(n_electrons, n_orbitals):
            c.cry(i, a, math.pi / 8)
    # Double excitations (pairwise)
    for i in range(n_electrons - 1):
        for a in range(n_electrons, n_orbitals - 1):
            c.cx(i, a)
            c.cry(i+1, a+1, math.pi / 8)
            c.cx(i, a)
    return c.measure()
