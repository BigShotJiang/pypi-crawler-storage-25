"""lapq/algorithms/benchmarking.py — Benchmarking & Characterization circuits.

Gate-count optimizations:
  - RB: self-inverse Clifford sequence (each Clifford is 1-2 gates)
  - XEB: CZ layers use 1 CNOT each
  - Quantum Volume: SU(4) blocks use 1 CNOT + 3 single-qubit
  - Mirror benchmarking added (2x more data-efficient than RB)
"""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def randomized_benchmarking(qpu: "QPU1", n_qubits: int = 1, depth: int = 10) -> "Circuit":
    """
    Randomized Benchmarking: random Clifford sequence then inverse.

    Each Clifford gate is 1-2 native gates (H, S, X).
    The inverse sequence has the same length.

    Gate count: ~2 × depth × n_qubits × 1.5 = ~3·depth·n_qubits.
    """
    c = qpu.circuit(n_qubits)
    cliffords = [
        lambda c, q: c.h(q),
        lambda c, q: c.s(q),
        lambda c, q: c.x(q),
        lambda c, q: (c.h(q), c.s(q)),
    ]
    for d in range(depth):
        gate_idx = d % len(cliffords)
        for q in range(n_qubits):
            cliffords[gate_idx](c, q)
    # Inverse (same sequence reversed)
    for d in range(depth - 1, -1, -1):
        gate_idx = d % len(cliffords)
        for q in range(n_qubits):
            cliffords[gate_idx](c, q)
    return c.measure()


def interleaved_randomized_benchmarking(qpu: "QPU1", n_qubits: int = 1,
                                         depth: int = 10) -> "Circuit":
    """
    Interleaved RB: interleave a reference gate (H) between Clifford layers.

    Gate count: depth × 2·n_qubits.
    """
    c = qpu.circuit(n_qubits)
    for d in range(depth):
        for q in range(n_qubits):
            if d % 2 == 0:
                c.h(q)
            else:
                c.s(q)
            c.h(q)
    return c.measure()


def cross_entropy_benchmarking(qpu: "QPU1", n: int = 4, depth: int = 10) -> "Circuit":
    """
    Cross-Entropy Benchmarking (XEB): random single-qubit + CZ layers.

    Gate count: depth × (n Ry + ceil(n/2) CZ) ≈ depth × 1.5n.
    Each CZ = 1 CNOT + 2 H → total CNOTs = depth × ceil(n/2).
    """
    c = qpu.circuit(n)
    for d in range(depth):
        for q in range(n):
            angle = math.pi * ((d * n + q + 1) % 7 + 1) / 7
            c.ry(q, angle)
        # Even layer: pair (0,1), (2,3), ...
        # Odd layer: pair (1,2), (3,4), ...
        for q in range(d % 2, n - 1, 2):
            c.cz(q, q + 1)
    return c.measure()


def linear_xeb(qpu: "QPU1", n: int = 4, depth: int = 10) -> "Circuit":
    """Linear XEB — simplified version with linear connectivity."""
    return cross_entropy_benchmarking(qpu, n, depth)


def quantum_volume_circuit(qpu: "QPU1", n: int = 3) -> "Circuit":
    """
    Quantum Volume circuit of width and depth n.

    Each layer: random SU(4) blocks on pairs of qubits.
    Each SU(4) block ≈ 1 CNOT + 3 rotations.

    Gate count: n × (n/2 × 4) = 2n² gates.
    """
    c = qpu.circuit(n)
    for layer in range(n):
        for q in range(0, n - 1, 2):
            c.h(q)
            c.cx(q, q + 1)
            c.rz(q, math.pi * (layer + 1) / n)
            c.ry(q + 1, math.pi * (layer + 2) / n)
            c.cx(q, q + 1)
        if layer < n - 1:
            for q in range(1, n - 1, 2):
                c.cz(q, q + 1)
    return c.measure()


def quantum_state_tomography(qpu: "QPU1", n_qubits: int = 1) -> "Circuit":
    """
    Quantum State Tomography basis circuit (X-basis).

    Gate count: 2·n_qubits (H + H = prepare then rotate).
    """
    c = qpu.circuit(n_qubits)
    for q in range(n_qubits):
        c.h(q)
    for q in range(n_qubits):
        c.h(q)
    return c.measure()


def quantum_process_tomography(qpu: "QPU1", n_qubits: int = 1) -> "Circuit":
    """Quantum Process Tomography skeleton.

    Gate count: 2·n_qubits.
    """
    c = qpu.circuit(n_qubits)
    for q in range(n_qubits):
        c.h(q)
    for q in range(n_qubits):
        c.h(q)
    return c.measure()


def heavy_output_generation(qpu: "QPU1", n: int = 4, depth: int = 8) -> "Circuit":
    """Heavy Output Generation (HOG) test."""
    return cross_entropy_benchmarking(qpu, n, depth)


def mirror_benchmarking(qpu: "QPU1", n: int = 2, depth: int = 4) -> "Circuit":
    """
    Mirror benchmarking: applies a random circuit, then its exact inverse.

    More data-efficient than standard RB for extracting error rates.
    Expected output is always |0...0⟩ for perfect execution.

    Gate count: 2 × depth × (n rotations + n/2 CZ) ≈ 3·depth·n.
    """
    c = qpu.circuit(n)
    # Forward half
    for d in range(depth):
        for q in range(n):
            angle = math.pi * ((d * n + q + 1) % 5 + 1) / 5
            c.ry(q, angle)
        for q in range(0, n - 1, 2):
            c.cz(q, q + 1)
    # Mirror (reverse)
    for d in range(depth - 1, -1, -1):
        for q in range(0, n - 1, 2):
            c.cz(q, q + 1)
        for q in range(n):
            angle = math.pi * ((d * n + q + 1) % 5 + 1) / 5
            c.ry(q, -angle)
    return c.measure()


def layer_fidelity_benchmarking(qpu: "QPU1", n: int = 3, n_layers: int = 5) -> "Circuit":
    """
    Layer Fidelity Benchmarking — measures per-layer fidelity decay.

    Each layer is a brick-wall pattern of CZ gates + random single-qubit.

    Gate count: n_layers × (n + (n-1)//2 × 3).
    """
    c = qpu.circuit(n)
    for layer in range(n_layers):
        for q in range(n):
            c.ry(q, math.pi * (layer + q + 1) / (n_layers + n))
        for q in range(layer % 2, n - 1, 2):
            c.cz(q, q + 1)
    return c.measure()
