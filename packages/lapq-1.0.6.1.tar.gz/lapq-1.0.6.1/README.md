# lapq — LAP Technologies SDK for QPU-1

[![PyPI version](https://img.shields.io/pypi/v/lapq.svg)](https://pypi.org/project/lapq/)
[![Python versions](https://img.shields.io/pypi/pyversions/lapq.svg)](https://pypi.org/project/lapq/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**lapq** is a powerful Python SDK for the **QPU-1** quantum processor, designed for both beginners and experts. It features a library of **170+ quantum algorithms** across 12 categories and an automatic gate decomposition engine that handles all the math for you.

**Made by SK Mahammad Saad Amin | LAP Technologies**

---

## 🔑 API Access

To use this library, you need a QPU-1 API key.

**Get your key here:** [https://qpu-1.lovable.app/api-access](https://qpu-1.lovable.app/api-access)

---

## 📦 Installation

```bash
pip install lapq
```

---

## 🚀 Quick Start

### Basic Usage

```python
from lapq import QPU1

# Initialize client
qpu = QPU1("your_api_key_here")

# Run a Bell State circuit
result = qpu.circuit(2).h(0).cnot(0, 1).run()
print(f"Result: {result.bits}")  # e.g. "00" or "11"
```

### Three Levels of Access

#### 1. High-Level Algorithms (150+ ready-to-run)

```python
from lapq.algorithms import bell_state, grover, vqe_molecular, shors_factorization

# Bell state
result = bell_state(qpu).run()

# Grover's search for state |5⟩ on 3 qubits
result = grover(qpu, n=3, marked=[5]).run()
print(result.bits)  # "101"

# VQE molecular simulation
result = vqe_molecular(qpu, n_qubits=4).run()
```

#### 2. Mid-Level Circuit Builder (Fluent API)

```python
result = qpu.circuit(3).h(0).crx(0, 1, 0.5).cswap(0, 1, 2).ccz(0, 1, 2).run()
```

#### 3. Low-Level Raw Access (Qreg / Qiskit / OpenQASM)

```python
# Raw Qreg
qpu.run_qreg("q = Qreg(2)\nq.H(0)\nq.CNOT(0,1)\nprint(q.measure())")

# Qiskit
qpu.run_qiskit("""
from qiskit import QuantumCircuit
qc = QuantumCircuit(2)
qc.h(0); qc.cx(0, 1); qc.measure_all()
""")

# OpenQASM
qpu.run_openqasm("""
OPENQASM 2.0;
include "qelib1.inc";
qreg q[2]; creg c[2];
h q[0]; cx q[0],q[1];
measure q -> c;
""")
```

---

## 🛠 Features

### 170+ Quantum Algorithms

| Category | Examples |
|---|---|
| **Search & Optimization** | Grover, QAOA MaxCut, Amplitude Amplification, TSP |
| **Chemistry & Simulation** | VQE, QPE, Trotter-Suzuki, Hubbard Model |
| **Machine Learning** | QNN, QSVM, QGAN, Quantum Autoencoder |
| **Cryptography** | BB84, E91, Shor's Factorization, Quantum Money |
| **Oracle & Boolean** | Deutsch-Jozsa, Bernstein-Vazirani, Simon's |
| **Transforms & Arithmetic** | QFT, Adder, Multiplier, Comparator, GCD |
| **States & Communication** | Bell, GHZ, W, Teleportation, Superdense |
| **Quantum Walks** | Discrete, Continuous, Coined, Szegedy |
| **Benchmarking** | RB, XEB, Quantum Volume, Mirror |
| **Dynamics & Lattice** | Heisenberg, Ising, XY Model, Floquet |
| **ECC Shor** | Shor's for Elliptic Curve Cryptography (P-256, secp256k1) |
| **Miscellaneous** | HHL, VQLS, Monte Carlo, Error Correction |

### Auto Gate Decomposition

Use high-level gates like `CZ`, `CSWAP`, `CCZ`, `RXX`, `RYY`, `RZZ`, `ECR`, and more — they are automatically decomposed into QPU-1 native primitives (H, X, Y, Z, S, T, Rx, Ry, Rz, CNOT, CCNOT, SWAP) with minimal CNOT count.

### Batch Execution

```python
results = qpu.batch_fast([
    qpu.circuit(2).h(0).cnot(0, 1),
    qpu.circuit(3).ghz(),
    qpu.circuit(4).qft(),
])
for r in results:
    print(r.bits)
```

---

## 📊 Circuit Inspection

Generate and inspect circuits without an API key:

```python
from lapq.circuit import Circuit

c = Circuit(3, client=None)
c.h(0).cnot(0, 1).cnot(1, 2)
print(c.to_qreg())   # View Qreg source code
print(c.gate_count()) # Gate count
c.draw()              # Pretty-print circuit
```

---

## 📄 License

Distributed under the MIT License. See `LICENSE` for more information.

---

## 🔗 Links

- **QPU-1 Dashboard**: [https://qpu-1.lovable.app](https://qpu-1.lovable.app)
- **API Key Signup**: [https://qpu-1.lovable.app/api-access](https://qpu-1.lovable.app/api-access)
- **PyPI**: [https://pypi.org/project/lapq/](https://pypi.org/project/lapq/)
