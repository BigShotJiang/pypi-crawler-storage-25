"""Shape rendering helpers for DrawingML writer."""

from __future__ import annotations

import html
import logging
from collections.abc import Iterable

from svg2ooxml.common.conversions.bidi import is_rtl_text
from svg2ooxml.common.conversions.opacity import opacity_to_ppt
from svg2ooxml.drawingml.generator import DrawingMLPathGenerator, px_to_emu

# Import centralized XML builders for safe DrawingML generation
from svg2ooxml.drawingml.xml_builder import (
    a_elem,
    a_sub,
    blur,
    color_choice,
    effect_list,
    glow,
    outer_shadow,
    reflection,
    soft_edge,
    srgb_color,
    to_string,
)
from svg2ooxml.filters.utils.dml import is_effect_dag, merge_effect_fragments
from svg2ooxml.ir.effects import (
    BlurEffect,
    CustomEffect,
    Effect,
    GlowEffect,
    ReflectionEffect,
    ShadowEffect,
    SoftEdgeEffect,
)
from svg2ooxml.ir.geometry import LineSegment, Rect
from svg2ooxml.ir.scene import Path as IRPath
from svg2ooxml.ir.shapes import Circle, Ellipse, Line, Polygon, Polyline, Rectangle
from svg2ooxml.ir.text import Run, TextAnchor, TextFrame, WordArtCandidate
from svg2ooxml.policy.constants import FALLBACK_BITMAP


def _descr_attr(metadata) -> str:
    """Return ` descr="..."` attribute string if element has a description."""
    if not isinstance(metadata, dict):
        return ""
    desc = metadata.get("description")
    if not desc:
        return ""
    return f' descr="{html.escape(str(desc), quote=True)}"'


def _vert_attr(metadata) -> str:
    """Return ` vert="vert"` or ` vert="vert270"` for vertical writing mode."""
    if not isinstance(metadata, dict):
        return ""
    wm = metadata.get("writing_mode")
    if wm in ("vert", "vert270"):
        return f' vert="{wm}"'
    return ""


def _rot_attr(metadata) -> str:
    """Return ` rot="angle"` for text shape rotation (degrees × 60000)."""
    if not isinstance(metadata, dict):
        return ""
    deg = metadata.get("text_rotation_deg")
    if deg is not None and abs(float(deg)) > 0.01:
        ppt_angle = int(round(float(deg) * 60000))
        return f' rot="{ppt_angle}"'
    return ""


def render_rectangle(
    rect: Rectangle,
    shape_id: int,
    *,
    template: str,
    paint_to_fill,
    stroke_to_xml,
    hyperlink_xml: str = "",
) -> str:
    bounds = rect.bounds
    preset = "roundRect" if rect.is_rounded else "rect"
    av_list = (
        _round_rect_adjustment_block(bounds.width, bounds.height, rect.corner_radius)
        if rect.is_rounded
        else "        <a:avLst/>\n"
    )
    return template.format(
        SHAPE_ID=shape_id,
        X_EMU=px_to_emu(bounds.x),
        Y_EMU=px_to_emu(bounds.y),
        WIDTH_EMU=px_to_emu(bounds.width),
        HEIGHT_EMU=px_to_emu(bounds.height),
        PRESET=preset,
        AV_LIST=av_list,
        FILL_XML=_format_block(paint_to_fill(rect.fill, shape_bbox=bounds), "        "),
        STROKE_XML=_format_block(
            stroke_to_xml(rect.stroke, metadata=rect.metadata), "        "
        ),
        HYPERLINK_XML=hyperlink_xml,
        EFFECTS_XML=_effect_block(rect.effects),
        DESCR_ATTR=_descr_attr(rect.metadata),
    )


def render_circle(
    circle: Circle,
    shape_id: int,
    *,
    template: str,
    paint_to_fill,
    stroke_to_xml,
    hyperlink_xml: str = "",
) -> str:
    size = circle.radius * 2.0
    bounds = Rect(
        x=circle.center.x - circle.radius,
        y=circle.center.y - circle.radius,
        width=size,
        height=size,
    )
    return render_preset_shape(
        bounds=bounds,
        shape_id=shape_id,
        preset="ellipse",
        template=template,
        fill_xml=_format_block(
            paint_to_fill(circle.fill, shape_bbox=bounds), "        "
        ),
        stroke_xml=_format_block(
            stroke_to_xml(circle.stroke, metadata=circle.metadata), "        "
        ),
        effects_xml=_effect_block(circle.effects),
        hyperlink_xml=hyperlink_xml,
        descr_attr=_descr_attr(circle.metadata),
    )


def render_ellipse(
    ellipse: Ellipse,
    shape_id: int,
    *,
    template: str,
    paint_to_fill,
    stroke_to_xml,
    hyperlink_xml: str = "",
) -> str:
    bounds = Rect(
        x=ellipse.center.x - ellipse.radius_x,
        y=ellipse.center.y - ellipse.radius_y,
        width=ellipse.radius_x * 2.0,
        height=ellipse.radius_y * 2.0,
    )
    return render_preset_shape(
        bounds=bounds,
        shape_id=shape_id,
        preset="ellipse",
        template=template,
        fill_xml=_format_block(
            paint_to_fill(ellipse.fill, shape_bbox=bounds), "        "
        ),
        stroke_xml=_format_block(
            stroke_to_xml(ellipse.stroke, metadata=ellipse.metadata), "        "
        ),
        effects_xml=_effect_block(ellipse.effects),
        hyperlink_xml=hyperlink_xml,
        descr_attr=_descr_attr(ellipse.metadata),
    )


def render_preset_shape(
    *,
    bounds: Rect,
    shape_id: int,
    preset: str,
    template: str,
    fill_xml: str,
    stroke_xml: str,
    effects_xml: str,
    hyperlink_xml: str = "",
    descr_attr: str = "",
) -> str:
    return template.format(
        SHAPE_ID=shape_id,
        PRESET=preset,
        X_EMU=px_to_emu(bounds.x),
        Y_EMU=px_to_emu(bounds.y),
        WIDTH_EMU=px_to_emu(bounds.width),
        HEIGHT_EMU=px_to_emu(bounds.height),
        FILL_XML=fill_xml,
        STROKE_XML=stroke_xml,
        EFFECTS_XML=effects_xml,
        HYPERLINK_XML=hyperlink_xml,
        DESCR_ATTR=descr_attr,
    )


def render_path(
    path: IRPath,
    shape_id: int,
    *,
    template: str,
    paint_to_fill,
    stroke_to_xml,
    path_generator: DrawingMLPathGenerator,
    policy_for,
    logger: logging.Logger,
    hyperlink_xml: str = "",
) -> str:
    fill_xml = _format_block(paint_to_fill(path.fill, shape_bbox=path.bbox), "        ")
    stroke_xml = _format_block(
        stroke_to_xml(path.stroke, metadata=path.metadata), "        "
    )
    policy_geom = policy_for(path.metadata, "geometry")
    shape_name = f"Path {shape_id}"
    if policy_geom.get("suggest_fallback") == FALLBACK_BITMAP:
        logger.warning(
            "Path %s marked for bitmap fallback by policy; emitting native geometry until bitmap exporter is available.",
            shape_id,
        )
    fill_mode = "norm" if path.fill else "none"
    stroke_mode = "true" if path.stroke else "false"
    geometry = path_generator.generate_custom_geometry(
        path.segments,
        fill_mode=fill_mode,
        stroke_mode=stroke_mode,
        closed=path.is_closed,
    )
    bounds = geometry.bounds

    return template.format(
        SHAPE_ID=shape_id,
        SHAPE_NAME=shape_name,
        X_EMU=px_to_emu(bounds.x),
        Y_EMU=px_to_emu(bounds.y),
        WIDTH_EMU=geometry.width_emu,
        HEIGHT_EMU=geometry.height_emu,
        GEOMETRY_XML=_format_block(geometry.xml, "        "),
        FILL_XML=fill_xml,
        STROKE_XML=stroke_xml,
        HYPERLINK_XML=hyperlink_xml,
        EFFECTS_XML=_effect_block(path.effects),
        DESCR_ATTR=_descr_attr(path.metadata),
    )


def render_line(
    line: Line,
    shape_id: int,
    *,
    template: str,
    path_generator: DrawingMLPathGenerator,
    stroke_to_xml,
    paint_to_fill,
    policy_for,
    hyperlink_xml: str = "",
) -> str:
    shape_name = f"Line {shape_id}"

    segments = [LineSegment(line.start, line.end)]
    geometry = path_generator.generate_custom_geometry(
        segments,
        fill_mode="none",
        stroke_mode="true" if line.stroke else "false",
        closed=False,
    )
    bounds = geometry.bounds

    return template.format(
        SHAPE_ID=shape_id,
        SHAPE_NAME=shape_name,
        X_EMU=px_to_emu(bounds.x),
        Y_EMU=px_to_emu(bounds.y),
        WIDTH_EMU=geometry.width_emu,
        HEIGHT_EMU=geometry.height_emu,
        GEOMETRY_XML=_format_block(geometry.xml, "        "),
        FILL_XML=_format_block(paint_to_fill(None), "        "),
        STROKE_XML=_format_block(
            stroke_to_xml(line.stroke, metadata=line.metadata), "        "
        ),
        EFFECTS_XML=_effect_block(line.effects),
        HYPERLINK_XML=hyperlink_xml,
        DESCR_ATTR=_descr_attr(line.metadata),
    )


def render_polyline(
    polyline: Polyline,
    shape_id: int,
    *,
    template: str,
    path_generator: DrawingMLPathGenerator,
    paint_to_fill,
    stroke_to_xml,
    policy_for,
    hyperlink_xml: str = "",
) -> str:
    return _render_polygonal_shape(
        polyline,
        shape_id,
        template=template,
        path_generator=path_generator,
        paint_to_fill=paint_to_fill,
        stroke_to_xml=stroke_to_xml,
        policy_for=policy_for,
        hyperlink_xml=hyperlink_xml,
        closed=False,
    )


def render_polygon(
    polygon: Polygon,
    shape_id: int,
    *,
    template: str,
    path_generator: DrawingMLPathGenerator,
    paint_to_fill,
    stroke_to_xml,
    policy_for,
    hyperlink_xml: str = "",
) -> str:
    return _render_polygonal_shape(
        polygon,
        shape_id,
        template=template,
        path_generator=path_generator,
        paint_to_fill=paint_to_fill,
        stroke_to_xml=stroke_to_xml,
        policy_for=policy_for,
        hyperlink_xml=hyperlink_xml,
        closed=True,
    )


def _is_frame_rtl(frame: TextFrame) -> bool:
    """Determine if a text frame should use RTL paragraph direction."""
    direction = getattr(frame, "direction", None)
    if direction == "rtl":
        return True
    if direction == "ltr":
        return False
    # Auto-detect from text content
    text = frame.text_content
    return bool(text) and is_rtl_text(text)


def _resolve_alignment(anchor: TextAnchor, *, rtl: bool) -> str:
    """Map text-anchor to DrawingML alignment, flipping for RTL."""
    if rtl:
        return {
            TextAnchor.START: "r",
            TextAnchor.MIDDLE: "ctr",
            TextAnchor.END: "l",
        }.get(anchor, "r")
    return {
        TextAnchor.START: "l",
        TextAnchor.MIDDLE: "ctr",
        TextAnchor.END: "r",
    }.get(anchor, "l")


_LOW_PROFILE_WORDART_PRESETS = frozenset(
    {
        "textPlain",
        "textArchUp",
        "textArchDown",
        "textWave1",
        "textSlantUp",
        "textSlantDown",
    }
)
_MEDIUM_PROFILE_WORDART_PRESETS = frozenset(
    {
        "textCanUp",
        "textCanDown",
        "textInflate",
        "textDeflate",
        "textInflateTop",
        "textInflateBottom",
    }
)


def _normalize_wordart_bbox(frame: TextFrame, candidate: WordArtCandidate) -> Rect:
    """Tighten WordArt height so it tracks textbox sizing more closely.

    Text boxes intentionally reserve extra leading to avoid clipping. Native
    WordArt uses the outer shape as its warp envelope, so reusing the same
    height tends to make single-line WordArt appear vertically inflated.
    """
    bbox = frame.bbox
    runs = frame.runs or []
    if bbox.height <= 0.0 or not runs or frame.is_multiline:
        return bbox

    max_font_pt = max((run.font_size_pt for run in runs), default=0.0)
    if max_font_pt <= 0.0:
        return bbox

    if candidate.preset in _LOW_PROFILE_WORDART_PRESETS:
        profile_scale = 1.1
    elif candidate.preset in _MEDIUM_PROFILE_WORDART_PRESETS:
        profile_scale = 1.2
    else:
        return bbox

    max_font_px = max_font_pt * (96.0 / 72.0)
    stroke_padding_px = max((run.stroke_width_px or 0.0 for run in runs), default=0.0)
    target_height = min(
        bbox.height,
        max_font_px * profile_scale + stroke_padding_px,
    )
    if target_height >= bbox.height * 0.98:
        return bbox

    center_y = bbox.y + (bbox.height / 2.0)
    return Rect(
        x=bbox.x,
        y=center_y - (target_height / 2.0),
        width=bbox.width,
        height=target_height,
    )


def render_textframe(
    frame: TextFrame,
    shape_id: int,
    *,
    template: str,
    policy_for,
    logger: logging.Logger,
    hyperlink_xml: str = "",
    register_run_navigation=None,
) -> str:
    bbox = frame.bbox
    rtl = _is_frame_rtl(frame)
    align = _resolve_alignment(frame.anchor, rtl=rtl)

    policy_text = policy_for(getattr(frame, "metadata", None), "text")
    note_parts: list[str] = []
    behavior = policy_text.get("rendering_behavior")
    if isinstance(behavior, str) and behavior:
        note_parts.append(f"rendering_behavior={behavior}")
        if behavior != "outline":
            logger.warning(
                "Text frame %s requests %s rendering; emitting live text until fallback support lands.",
                shape_id,
                behavior,
            )
    fallback_font = policy_text.get("font_fallback")
    if isinstance(fallback_font, str) and fallback_font:
        note_parts.append(f"font_fallback={fallback_font}")

    shape_name = f"Text {shape_id}"
    if note_parts:
        logger.debug("Text frame %s policy notes: %s", shape_id, "; ".join(note_parts))

    runs_xml = _resolve_runs_xml(frame, register_run_navigation)

    return template.format(
        SHAPE_ID=shape_id,
        SHAPE_NAME=shape_name,
        X_EMU=px_to_emu(bbox.x),
        Y_EMU=px_to_emu(bbox.y),
        WIDTH_EMU=px_to_emu(bbox.width),
        HEIGHT_EMU=px_to_emu(bbox.height),
        TEXT_ALIGN=align,
        RTL_ATTR=' rtl="1"' if rtl else "",
        RUNS_XML=runs_xml,
        HYPERLINK_XML=hyperlink_xml,
        DESCR_ATTR=_descr_attr(getattr(frame, "metadata", None)),
        VERT_ATTR=_vert_attr(getattr(frame, "metadata", None)),
        ROT_ATTR=_rot_attr(getattr(frame, "metadata", None)),
    )


def render_wordart(
    frame: TextFrame,
    candidate: WordArtCandidate,
    shape_id: int,
    *,
    template: str,
    policy_for,
    logger: logging.Logger,
    hyperlink_xml: str = "",
    register_run_navigation=None,
) -> str:
    bbox = _normalize_wordart_bbox(frame, candidate)
    rtl = _is_frame_rtl(frame)
    align = _resolve_alignment(frame.anchor, rtl=rtl)

    policy_text = policy_for(getattr(frame, "metadata", None), "text")
    note_parts: list[str] = []
    if policy_text:
        for key, value in sorted(policy_text.items()):
            note_parts.append(f"{key}={value}")

    if candidate.fallback_strategy:
        note_parts.append(f"fallback={candidate.fallback_strategy}")
    note_parts.append(f"confidence={candidate.confidence:.2f}")

    shape_name = f"WordArt {shape_id}"
    if note_parts:
        logger.debug("WordArt %s policy notes: %s", shape_id, "; ".join(note_parts))

    runs_xml = _resolve_runs_xml(frame, register_run_navigation)

    body_extra = ""

    if candidate.fallback_strategy and candidate.fallback_strategy != "vector_outline":
        logger.info(
            "WordArt %s prefers native preset '%s' with fallback %s",
            shape_id,
            candidate.preset,
            candidate.fallback_strategy,
        )

    return template.format(
        SHAPE_ID=shape_id,
        SHAPE_NAME=shape_name,
        X_EMU=px_to_emu(bbox.x),
        Y_EMU=px_to_emu(bbox.y),
        WIDTH_EMU=px_to_emu(bbox.width),
        HEIGHT_EMU=px_to_emu(bbox.height),
        TEXT_ALIGN=align,
        RTL_ATTR=' rtl="1"' if rtl else "",
        WARP_PRESET=candidate.preset,
        BODY_EXTRA=body_extra,
        RUNS_XML=runs_xml,
        HYPERLINK_XML=hyperlink_xml,
        DESCR_ATTR=_descr_attr(getattr(frame, "metadata", None)),
        VERT_ATTR=_vert_attr(getattr(frame, "metadata", None)),
        ROT_ATTR=_rot_attr(getattr(frame, "metadata", None)),
    )


def build_runs_xml(runs: Iterable[Run], register_navigation=None) -> str:
    fragments: list[str] = []
    for run in runs:
        text = (run.text or "").replace("\r\n", "\n").replace("\r", "\n")
        parts = text.split("\n") if text else [""]
        navigation_handler = None
        if (
            register_navigation is not None
            and getattr(run, "navigation", None) is not None
        ):
            navigation_registered = False

            def _navigation_factory(segment_text: str, _run=run):
                nonlocal navigation_registered
                if navigation_registered:
                    return None
                navigation_registered = True
                return register_navigation(_run.navigation, segment_text)

            navigation_handler = _navigation_factory
        for index, segment in enumerate(parts):
            if index > 0:
                fragments.append("<a:br/>")
            fragments.append(run_fragment(run, segment, navigation_handler))
    return "".join(fragments)


def _resolve_runs_xml(frame: TextFrame, register_navigation) -> str:
    # Prefer IR runs when they carry attributes (lang, font_variant) that
    # the pre-built resvg runs_xml would miss.
    ir_runs = frame.runs or []
    has_enriched_attrs = any(
        getattr(r, "language", None) or getattr(r, "font_variant", None)
        for r in ir_runs
    )
    if not has_enriched_attrs:
        resvg_runs = _resvg_runs_xml(frame, register_navigation)
        if resvg_runs:
            return resvg_runs
    runs_xml = build_runs_xml(ir_runs, register_navigation=register_navigation)
    if not runs_xml:
        runs_xml = build_runs_xml(
            [Run(text="", font_family="Arial", font_size_pt=12.0)],
            register_navigation=register_navigation,
        )
    return runs_xml


def _resvg_runs_xml(frame: TextFrame, register_navigation) -> str:
    metadata = getattr(frame, "metadata", None)
    if not isinstance(metadata, dict):
        return ""
    resvg_text = metadata.get("resvg_text")
    if not isinstance(resvg_text, dict):
        return ""
    if resvg_text.get("strategy") != "runs":
        return ""
    runs_xml = resvg_text.get("runs_xml")
    if not isinstance(runs_xml, str) or not runs_xml.strip():
        return ""
    if register_navigation is not None and _frame_has_navigation(frame):
        return ""
    return runs_xml


def _frame_has_navigation(frame: TextFrame) -> bool:
    return any(getattr(run, "navigation", None) is not None for run in frame.runs or [])


def run_fragment(run: Run, text_segment: str, navigation_factory) -> str:
    size = max(100, int(round(run.font_size_pt * 100)))
    attributes = [f'sz="{size}"']
    if run.bold:
        attributes.append('b="1"')
    if run.italic:
        attributes.append('i="1"')
    if run.underline:
        attributes.append('u="sng"')
    if run.strike:
        attributes.append('strike="sng"')
    if getattr(run, "kerning", None) is not None:
        kern_value = int(round(float(run.kerning) * 1000))
        attributes.append(f'kern="{kern_value}"')
    effective_spacing = getattr(run, "letter_spacing", None)
    word_spacing = getattr(run, "word_spacing", None)
    if word_spacing is not None and text_segment:
        # Approximate word-spacing by distributing it as extra letter-spacing
        # proportional to the number of spaces vs total characters.
        space_count = text_segment.count(" ")
        if space_count > 0 and len(text_segment) > 1:
            extra_per_char = (float(word_spacing) * space_count) / (
                len(text_segment) - 1
            )
            base = float(effective_spacing) if effective_spacing is not None else 0.0
            effective_spacing = base + extra_per_char
    if effective_spacing is not None:
        spacing_value = int(round(float(effective_spacing) * 1000))
        attributes.append(f'spc="{spacing_value}"')
    font_variant = getattr(run, "font_variant", None)
    if font_variant == "small-caps":
        attributes.append('cap="small"')
    baseline_shift = getattr(run, "baseline_shift", 0.0)
    if baseline_shift:
        # DrawingML baseline is percentage × 1000 (e.g. 30000 = 30% superscript)
        baseline_pct = int(round(baseline_shift * 1000))
        attributes.append(f'baseline="{baseline_pct}"')
    language = getattr(run, "language", None)
    if language:
        attributes.append(f'lang="{html.escape(language, quote=True)}"')

    rgb = (run.rgb or "000000").upper()
    font_family = html.escape(run.font_family or "Arial", quote=True)
    east_asian = html.escape(
        getattr(run, "east_asian_font", "") or run.font_family or "Arial", quote=True
    )
    complex_script = html.escape(
        getattr(run, "complex_script_font", "") or run.font_family or "Arial",
        quote=True,
    )

    # Build a:r element with lxml
    r = a_elem("r")

    # Build a:rPr with attributes
    rPr = a_elem("rPr")
    for attr_str in attributes:
        # Parse attribute strings like 'sz="1200"'
        if "=" in attr_str:
            key, val = attr_str.split("=", 1)
            rPr.set(key, val.strip('"'))

    # 1. Add outline (ln) - MUST come before fill
    if run.has_stroke:
        ln_elem = a_sub(rPr, "ln", w=str(px_to_emu(run.stroke_width_px or 1.0)))
        strokeFill = a_sub(ln_elem, "solidFill")
        stroke_rgb = (run.stroke_rgb or "000000").upper()
        stroke_alpha = opacity_to_ppt(run.stroke_opacity or 1.0)
        strokeFill.append(
            color_choice(
                stroke_rgb,
                alpha=stroke_alpha if stroke_alpha < 100000 else None,
                theme_color=getattr(run, "stroke_theme_color", None),
            )
        )

    # 2. Add solidFill
    solidFill = a_sub(rPr, "solidFill")
    fill_alpha = opacity_to_ppt(run.fill_opacity)
    solidFill.append(
        color_choice(
            rgb,
            alpha=fill_alpha if fill_alpha < 100000 else None,
            theme_color=getattr(run, "theme_color", None),
        )
    )

    # 3. Add font typefaces
    a_sub(rPr, "latin", typeface=font_family)
    a_sub(rPr, "ea", typeface=east_asian)
    a_sub(rPr, "cs", typeface=complex_script)

    # Add navigation if present
    if navigation_factory is not None:
        nav_elem = navigation_factory(text_segment)
        if nav_elem is not None:
            rPr.append(nav_elem)

    r.append(rPr)

    # Build a:t element
    text_value = text_segment
    preserve = False
    if text_value == "":
        text_value = " "
        preserve = True
    elif text_value.startswith(" ") or text_value.endswith(" "):
        preserve = True

    t = a_elem("t")
    t.text = text_value  # lxml handles escaping
    if preserve:
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")

    r.append(t)

    return to_string(r)


def _round_rect_adjustment_block(width: float, height: float, radius: float) -> str:
    avLst = a_elem("avLst")

    if width > 0 and height > 0 and radius > 0:
        min_dim = min(width, height)
        max_corner = min_dim / 2.0
        effective_radius = min(radius, max_corner)
        ratio_x = (effective_radius / width) * 100 if width > 0 else 0.0
        ratio_y = (effective_radius / height) * 100 if height > 0 else 0.0
        ratio = min(50.0, max(ratio_x, ratio_y))
        adj = int(round(ratio * 1000))
        a_sub(avLst, "gd", name="adj", fmla=f"val {adj}")

    xml = to_string(avLst)
    # Add indentation for formatting
    return "        " + xml.replace("\n", "\n        ") + "\n"


def _render_polygonal_shape(
    shape: Polyline | Polygon,
    shape_id: int,
    *,
    template: str,
    path_generator: DrawingMLPathGenerator,
    paint_to_fill,
    stroke_to_xml,
    policy_for,
    hyperlink_xml: str,
    closed: bool,
) -> str:
    points = getattr(shape, "points", [])
    if len(points) < (3 if closed else 2):
        raise ValueError("Polygonal shape requires sufficient points")

    segments = [LineSegment(points[i], points[i + 1]) for i in range(len(points) - 1)]
    if closed:
        segments.append(LineSegment(points[-1], points[0]))

    geometry = path_generator.generate_custom_geometry(
        segments,
        fill_mode="norm" if closed and getattr(shape, "fill", None) else "none",
        stroke_mode="true" if getattr(shape, "stroke", None) else "false",
        closed=closed,
    )
    bounds = geometry.bounds

    shape_name = f"{'Polygon' if closed else 'Polyline'} {shape_id}"

    fill_xml = paint_to_fill(getattr(shape, "fill", None), shape_bbox=bounds)
    stroke_xml = stroke_to_xml(
        getattr(shape, "stroke", None), metadata=getattr(shape, "metadata", None)
    )

    return template.format(
        SHAPE_ID=shape_id,
        SHAPE_NAME=shape_name,
        X_EMU=px_to_emu(bounds.x),
        Y_EMU=px_to_emu(bounds.y),
        WIDTH_EMU=geometry.width_emu,
        HEIGHT_EMU=geometry.height_emu,
        GEOMETRY_XML=_format_block(geometry.xml, "        "),
        FILL_XML=_format_block(fill_xml, "        "),
        STROKE_XML=_format_block(stroke_xml, "        "),
        EFFECTS_XML=_effect_block(getattr(shape, "effects", [])),
        HYPERLINK_XML=hyperlink_xml,
        DESCR_ATTR=_descr_attr(getattr(shape, "metadata", None)),
    )


def _format_block(xml: str, indent: str) -> str:
    if not xml:
        return ""
    lines = xml.splitlines()
    return "\n".join(indent + line for line in lines) + "\n"


def _effect_block(effects: Iterable[Effect]) -> str:
    effect_strings: list[str] = []
    for effect in effects or []:
        xml = _effect_to_drawingml(effect)
        if xml:
            effect_strings.append(xml.strip())

    if not effect_strings:
        return ""

    # Preserve alpha/composite graphs via effectDag when present.
    if any(is_effect_dag(fragment) for fragment in effect_strings):
        merged = merge_effect_fragments(*effect_strings, prefer_container="effectDag")
        if merged:
            return _format_block(merged, "        ")
        return _format_block("".join(effect_strings), "        ")

    # Single effect without effectLst wrapper — return as-is
    if len(effect_strings) == 1 and "<a:effectLst" not in effect_strings[0]:
        return _format_block(effect_strings[0], "        ")

    # Merge all effectLst content into one, dedup, filter, and reorder
    merged = _merge_effect_lists("".join(effect_strings))
    if not merged:
        return ""
    return _format_block(merged, "        ")


def _merge_effect_lists(xml: str) -> str:
    """Merge all top-level effectLst elements into one, dedup and reorder.

    ECMA-376 CT_EffectList (§20.1.8.26) allows only:
    blur, fillOverlay, glow, innerShdw, outerShdw, prstShdw, reflection, softEdge
    — each at most once.  Invalid children are dropped.
    """
    from lxml import etree

    _NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
    _EFFLST_TAG = f"{{{_NS}}}effectLst"
    _VALID_CHILDREN = {
        f"{{{_NS}}}{local}"
        for local in [
            "blur",
            "fillOverlay",
            "glow",
            "innerShdw",
            "outerShdw",
            "prstShdw",
            "reflection",
            "softEdge",
        ]
    }
    _TAG_ORDER = {
        f"{{{_NS}}}{local}": i
        for i, local in enumerate(
            [
                "blur",
                "fillOverlay",
                "glow",
                "innerShdw",
                "outerShdw",
                "prstShdw",
                "reflection",
                "softEdge",
            ]
        )
    }

    try:
        root = etree.fromstring(f'<root xmlns:a="{_NS}">{xml}</root>')
    except etree.XMLSyntaxError:
        return xml

    # Collect valid children from ALL top-level effectLst elements
    # (keep last occurrence per tag; ignore non-effectLst children and
    # non-standard effectLst children like alphaModFix)
    seen: dict[str, etree._Element] = {}
    for child in root:
        if child.tag == _EFFLST_TAG:
            for effect_child in child:
                if effect_child.tag in _VALID_CHILDREN:
                    seen[effect_child.tag] = effect_child
        elif child.tag in _VALID_CHILDREN:
            # Bare effects without effectLst wrapper
            seen[child.tag] = child

    if not seen:
        return ""

    ordered = sorted(seen.values(), key=lambda e: _TAG_ORDER.get(e.tag, 999))

    parts: list[str] = []
    for elem in ordered:
        s = etree.tostring(elem, encoding="unicode")
        s = s.replace(f' xmlns:a="{_NS}"', "")
        parts.append(s)

    return f"<a:effectLst>{''.join(parts)}</a:effectLst>"


def _effect_to_drawingml(effect: Effect) -> str:
    """Convert effect to DrawingML XML using safe lxml builders.

    Args:
        effect: Effect object (Blur, SoftEdge, Glow, Shadow, Reflection, or Custom)

    Returns:
        DrawingML XML string with <a:effectLst> wrapper
    """
    if isinstance(effect, CustomEffect):
        return (effect.drawingml or "").strip()

    if isinstance(effect, BlurEffect):
        return to_string(effect_list(blur(effect.to_emu())))

    if isinstance(effect, SoftEdgeEffect):
        return to_string(effect_list(soft_edge(effect.to_emu())))

    if isinstance(effect, GlowEffect):
        color = (effect.color or "FFFFFF").upper()
        color_elem = srgb_color(color)
        return to_string(effect_list(glow(effect.to_emu(), color_elem)))

    if isinstance(effect, ShadowEffect):
        blur_rad, dist = effect.to_emu()
        direction = effect.to_direction_emu()
        alpha = effect.to_alpha_val()
        color = (effect.color or "000000").upper()
        color_elem = srgb_color(color, alpha=alpha)
        shadow = outer_shadow(
            blur_rad, dist, direction, color_elem, algn="ctr", rotWithShape="0"
        )
        return to_string(effect_list(shadow))

    if isinstance(effect, ReflectionEffect):
        blur_rad, dist = effect.to_emu()
        start_alpha, end_alpha = effect.to_alpha_vals()
        return to_string(
            effect_list(reflection(blur_rad, dist, start_alpha, end_alpha))
        )

    return ""


__all__ = [
    "build_runs_xml",
    "render_line",
    "render_polyline",
    "render_polygon",
    "render_circle",
    "render_ellipse",
    "render_path",
    "render_rectangle",
    "render_textframe",
    "render_preset_shape",
    "render_wordart",
    "run_fragment",
]
