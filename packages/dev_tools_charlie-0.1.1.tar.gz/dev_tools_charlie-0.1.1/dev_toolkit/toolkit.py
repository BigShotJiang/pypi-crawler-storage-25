from importlib.resources import path
import os
import sys
import re
import platform
import subprocess
import shutil
import datetime
import requests
from bs4 import BeautifulSoup
from rich.console import Console
from rich.panel import Panel
from rich import print

console = Console()
HEADERS = {"User-Agent": "Mozilla/5.0"}
PROJECTS_DIR = "/home/charlie/projects"
CURRENT_PROJECT_FILE = os.path.join(PROJECTS_DIR, ".current_project")
COMMANDS = {}
COMMAND_META = {}

def command(name, section="GENERAL", description=""):
    def wrapper(func):
        COMMANDS[name] = func
        COMMAND_META[name] = {
            "section": section,
            "description": description
        }
        return func
    return wrapper

@command("help", section="SYSTEM TOOLS", description="Show this help menu")
def show_help():
    colors = {
        "SYSTEM TOOLS": "cyan",
        "FILE TOOLS": "green",
        "NOTES": "magenta",
        "WEB TOOLS": "yellow",
        "GENERAL": "white",
    }

    grouped = {}

    for name, meta in COMMAND_META.items():
        section = meta["section"]
        grouped.setdefault(section, []).append((name, meta["description"]))

    output = []

    for section, items in grouped.items():
        color = colors.get(section, "white")

        output.append(f"\n[{color} bold]{section}[/]\n")

        for name, desc in sorted(items):
            output.append(f"  [{color}]{name:<12}[/] - {desc}")

    console.print(Panel.fit("\n".join(output), title="Available Commands"))
# -------------------------
# HEADER
# -------------------------
def header(title):
    console.print(Panel.fit(f"⚙️ {title}", style="cyan bold"))

# -------------------------
# PROJECT HELPERS
# -------------------------


def ensure_projects_dir():
    os.makedirs(PROJECTS_DIR, exist_ok=True)


def get_current_project():
    try:
        with open(CURRENT_PROJECT_FILE, "r") as f:
            return f.read().strip()
    except:
        return None


def set_current_project(name):
    ensure_projects_dir()
    with open(CURRENT_PROJECT_FILE, "w") as f:
        f.write(name)


def project_path(name):
    return os.path.join(PROJECTS_DIR, name)


def get_project_path():
    name = get_current_project()
    if not name:
        return None
    return project_path(name)

# -------------------------
# HOME PAGE
# -------------------------
def home():
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        header("HOME DASHBOARD")

        print("[bold green]1[/] System Tools")
        print("[bold green]2[/] File Tools")
        print("[bold green]3[/] Notes")
        print("[bold green]4[/] Web Tools")
        print("[bold green]5[/] Projects")
        print("[bold red]6[/] Exit")

        choice = input("\nSelect: ")

        if choice == "1":
            system_page()
        elif choice == "2":
            file_page()
        elif choice == "3":
            notes_page()
        elif choice == "4":
            web_page()
        elif choice == "5":
            project_page()

        elif choice == "6":
            break
        else:
            console.print("[red]Invalid option[/]")
            input("Enter to continue...")


# -------------------------
# SYSTEM PAGE
# -------------------------
def system_page():
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        header("SYSTEM TOOLS")

        print("[green]1[/] System Info")
        print("[green]2[/] Disk Usage")
        print("[green]3[/] Memory Usage")
        print("[green]4[/] Run Command")
        print("[green]5[/] Running Processes")
        print("[green]6[/] Python Info")
        print("[red]7[/] Back")

        choice = input("\nSelect: ")

        if choice == "1":
            system_info()
        elif choice == "2":
            disk_usage()
        elif choice == "3":
            memory_usage()
        elif choice == "4":
            run_command()
        elif choice == "5":
            show_processes()
        elif choice == "6":
            python_info()
        elif choice == "7":
            break

        input("\nEnter to continue...")



@command("disk", section="SYSTEM TOOLS", description="Show disk usage")
def disk_usage():
    total, used, free = shutil.disk_usage("/")

    console.print(
        Panel.fit(
            f"""Total: {total // (2**30)} GB
Used: {used // (2**30)} GB
Free: {free // (2**30)} GB""",
            title="Disk Usage",
            style="green",
        )
    )


@command("mem", section="SYSTEM TOOLS", description="Show memory usage")
def memory_usage():
    try:
        with open("/proc/meminfo") as f:
            meminfo = f.read()

        total = int(re.search(r"MemTotal:\s+(\d+)", meminfo).group(1))
        free = int(re.search(r"MemAvailable:\s+(\d+)", meminfo).group(1))

        used = total - free

        console.print(
            Panel.fit(
                f"""Total: {total // 1024} MB
Used: {used // 1024} MB
Free: {free // 1024} MB""",
                title="Memory Usage",
                style="cyan",
            )
        )
    except:
        print("Memory info not available")


@command("run", section="SYSTEM TOOLS", description="Run terminal command")
def run_command():
    cmd = input("Enter command: ")

    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

        console.print(
            Panel.fit(
                result.stdout if result.stdout else "No output",
                title="Output",
                style="yellow",
            )
        )

        if result.stderr:
            console.print(Panel.fit(result.stderr, title="Errors", style="red"))

    except Exception as e:
        print(f"Error: {e}")


@command("ps", section="SYSTEM TOOLS", description="Show running processes")
def show_processes():
    try:
        result = subprocess.run(["ps", "aux"], capture_output=True, text=True)
        lines = result.stdout.split("\n")[:20]

        console.print(
            Panel.fit("\n".join(lines), title="Processes (top 20)", style="magenta")
        )
    except:
        print("Could not fetch processes")


@command("pyinfo", section="SYSTEM TOOLS", description="Show Python version")
def python_info():
    try:
        version = subprocess.check_output(["python3", "--version"], text=True)
        packages = subprocess.check_output(["pip", "list"], text=True)

        console.print(Panel.fit(version, title="Python Version", style="green"))
        console.print(
            Panel.fit(packages[:1000], title="Installed Packages", style="cyan")
        )

    except Exception as e:
        print(f"Error: {e}")


@command("sysinfo", section="SYSTEM TOOLS", description="Show system info")
def system_info():
    console.print(
        Panel.fit(
            f"""OS: {platform.system()}
Version: {platform.version()}
Machine: {platform.machine()}
Time: {datetime.datetime.now()}""",
            title="System Info",
            style="cyan",
        )
    )


# -------------------------
# FILE PAGE
# -------------------------
def file_page():
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        header("FILE TOOLS")

        print("[green]1[/] List Files")
        print("[green]2[/] Create File")
        print("[green]3[/] Delete File")
        print("[green]4[/] Edit File")
        print("[green]5[/] Search Files")
        print("[green]6[/] Run Python File")
        print("[red]7[/] Back")

        choice = input("\nSelect: ")

        if choice == "1":
            file_lister()
        elif choice == "2":
            create_file()
        elif choice == "3":
            delete_file()
        elif choice == "4":
            edit_file()
        elif choice == "5":
            search_files()
        elif choice == "6":
            run_python_file()
        elif choice == "7":
            break

        input("\nEnter to continue...")


@command("ls", section="FILE TOOLS", description="List files in project")
def file_lister():
    path = get_project_path() or "."
    console.print(Panel.fit("\n".join(os.listdir(path)), title="Files"))


@command("touch", section="FILE TOOLS", description="Create a new file")
def create_file():
    path = get_project_path() or "."
    name = input("File name: ")

    full_path = os.path.join(path, name)

    if os.path.exists(full_path):
        print("File already exists")
    else:
        open(full_path, "w").close()
        print("File created ✔")


@command("rm", section="FILE TOOLS", description="Delete a file")
def delete_file():
    path = get_project_path() or "."
    name = input("File to delete: ")

    full_path = os.path.join(path, name)

    if os.path.exists(full_path):
        confirm = input("Are you sure? (y/n): ")
        if confirm.lower() == "y":
            os.remove(full_path)
            print("Deleted ✔")
    else:
        print("File not found")


@command("edit", section="FILE TOOLS", description="Edit a file interactively")
def edit_file():
    path = get_project_path() or "."
    name = input("File to edit: ")

    full_path = os.path.join(path, name)

    if not os.path.exists(full_path):
        print("File not found")
        return

    print("Enter content (type 'SAVE' on new line to finish):")

    lines = []
    while True:
        line = input()
        if line == "SAVE":
            break
        lines.append(line)

    with open(full_path, "w") as f:
        f.write("\n".join(lines))

    print("Saved ✔")


@command("find", section="FILE TOOLS", description="Search for files")
def search_files():
    path = get_project_path() or "."
    query = input("Search: ").lower()

    results = []

    for root, dirs, files in os.walk(path):
        for file in files:
            if query in file.lower():
                results.append(os.path.join(root, file))

    if results:
        console.print(Panel.fit("\n".join(results), title="Results"))
    else:
        print("No matches")


@command("runpy", section="FILE TOOLS", description="Run a Python file in project venv")
def run_python_file():
    path = get_project_path() or "."
    filename = input("Python file to run: ")

    full_path = os.path.join(path, filename)

    if not os.path.exists(full_path):
        print("File not found")
        return

    if not filename.endswith(".py"):
        print("Not a Python file")
        return

    # detect venv python
    project_name = get_current_project()
    python_exec = "python3"

    if project_name:
        proj_path = project_path(project_name)

        # try project-named venv
        candidate = os.path.join(proj_path, project_name, "bin", "python")
        if os.path.exists(candidate):
            python_exec = candidate
        else:
            # fallback to old venv
            candidate = os.path.join(proj_path, "venv", "bin", "python")
            if os.path.exists(candidate):
                python_exec = candidate

    print(f"\n[Running with: {python_exec}]\n")

    subprocess.run([python_exec, full_path])


# -------------------------
# NOTES PAGE
# -------------------------
def notes_page():
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        header("NOTES SYSTEM")

        print("[green]1[/] Add Note")
        print("[green]2[/] View Notes")
        print("[green]3[/] Delete Note")
        print("[green]4[/] Search Notes")
        print("[green]5[/] Clear Notes")
        print("[red]6[/] Back")

        choice = input("\nSelect: ")

        if choice == "1":
            add_note()
        elif choice == "2":
            view_notes()
        elif choice == "3":
            delete_note()
        elif choice == "4":
            search_notes()
        elif choice == "5":
            clear_notes()
        elif choice == "6":
            break

        input("\nEnter to continue...")

def get_notes_file():
    project = get_project_path()
    if project:
        return os.path.join(project, "notes.txt")
    return "notes.txt"


@command("note-add", section="NOTES", description="Add a new note")
def add_note():
    note = input("Write note: ")
    file = get_notes_file()

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    with open(file, "a") as f:
        f.write(f"[{timestamp}] {note}\n")

    print("Saved ✔")


@command("note-view", section="NOTES", description="View all notes")
def view_notes():
    file = get_notes_file()

    if not os.path.exists(file):
        print("No notes yet")
        return

    with open(file, "r") as f:
        lines = f.readlines()

    output = []
    for i, line in enumerate(lines, 1):
        output.append(f"{i}. {line.strip()}")

    console.print(Panel.fit("\n".join(output), title="Notes"))


@command("note-del", section="NOTES", description="Delete a note by number")
def delete_note():
    file = get_notes_file()

    if not os.path.exists(file):
        print("No notes to delete")
        return

    with open(file, "r") as f:
        lines = f.readlines()

    for i, line in enumerate(lines, 1):
        print(f"{i}. {line.strip()}")

    try:
        num = int(input("Delete which number: "))
        if 1 <= num <= len(lines):
            lines.pop(num - 1)

            with open(file, "w") as f:
                f.writelines(lines)

            print("Deleted ✔")
        else:
            print("Invalid number")
    except:
        print("Invalid input")


@command("note-search", section="NOTES", description="Search notes")
def search_notes():
    file = get_notes_file()

    if not os.path.exists(file):
        print("No notes")
        return

    query = input("Search: ").lower()

    with open(file, "r") as f:
        lines = f.readlines()

    results = [l.strip() for l in lines if query in l.lower()]

    if results:
        console.print(Panel.fit("\n".join(results), title="Search Results"))
    else:
        print("No matches")


@command("note-clear", section="NOTES", description="Clear all notes")
def clear_notes():
    file = get_notes_file()

    confirm = input("Delete ALL notes? (y/n): ")

    if confirm.lower() == "y":
        open(file, "w").close()
        print("All notes cleared ✔")
    else:
        print("Cancelled")


# ----------------------------
# WEB PAGE
# ----------------------------


def extract_page_content(soup):
    # 1. Remove junk first
    for tag in soup(["script", "style", "nav", "footer", "header", "form"]):
        tag.decompose()

    # 2. Try “main content first”
    main = soup.find("main")
    if main:
        text = main.get_text(separator="\n", strip=True)
    else:
        # fallback to body
        text = soup.body.get_text(separator="\n", strip=True) if soup.body else ""

    # 3. Clean empty lines
    lines = [l.strip() for l in text.split("\n") if len(l.strip()) > 30]

    return lines


@command("web-text", section="WEB TOOLS", description="Extract readable text from a webpage")
def get_page_text(url=None):
    if not url:
        url = input("Enter URL: ")
    try:
        response = requests.get(url, headers=HEADERS)
        soup = BeautifulSoup(response.text, "html.parser")

        lines = extract_page_content(soup)
        text = "\n".join(lines)

        if not text:
            text = "No readable text found."

        console.print(
            Panel.fit(text[:2000], title="PAGE TEXT", style="yellow")
        )

    except Exception as e:
        console.print(f"[red]Error:[/] {e}")


@command("web-title", section="WEB TOOLS", description="Get webpage title")
def get_title(url=None):
    if not url:
        url = input("Enter URL: ")
    try:
        headers = HEADERS
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, "html.parser")

        title = soup.title.string if soup.title else "No title found"

        console.print(Panel.fit(title, title="PAGE TITLE", style="magenta"))

    except Exception as e:
        console.print(f"[red]Error:[/] {e}")


@command("web-links", section="WEB TOOLS", description="Extract links from a webpage")
def get_links(url=None):
    if not url:
        url = input("Enter URL: ")
    try:
        headers = HEADERS
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, "html.parser")

        links = soup.find_all("a")

        output = []
        for link in links[:20]:
            href = link.get("href")
            if href and href.startswith("http"):
                output.append(href)

        console.print(
            Panel.fit("\n".join(output), title="LINKS (first 20)", style="cyan")
        )

    except Exception as e:
        console.print(f"[red]Error:[/] {e}")


def summarize_text(text, sentence_count=5):
    sentences = re.split(r"(?<=[.!?])\s+", text)

    # clean
    sentences = [s.strip() for s in sentences if len(s.strip()) > 40]

    # remove duplicates
    seen = set()
    unique = []
    for s in sentences:
        if s not in seen:
            unique.append(s)
            seen.add(s)

    # take evenly spaced sentences instead of “scoring”
    if len(unique) <= sentence_count:
        return "\n".join(unique)

    step = len(unique) // sentence_count
    summary = unique[::step][:sentence_count]

    return "\n".join(summary)


@command("web-summary", section="WEB TOOLS", description="Summarise a webpage")
def get_page_summary(url=None):
    if not url:
        url = input("Enter URL: ")
    try:
        response = requests.get(url, headers=HEADERS)
        soup = BeautifulSoup(response.text, "html.parser")

        lines = extract_page_content(soup)
        text = "\n".join(lines)

        if not text:
            console.print("[red]No readable text found[/]")
            return

        summary = summarize_text(text)

        console.print(
            Panel.fit(summary, title="PAGE SUMMARY", style="magenta")
        )

    except Exception as e:
        console.print(f"[red]Error:[/] {e}")


def web_page():
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        header("WEB TOOLS")

        print("[green]1[/] Get page title")
        print("[green]2[/] Extract all links")
        print("[green]3[/] Extract page text")
        print("[green]4[/] Summarise page")
        print("[red]5[/] Back")

        choice = input("\nSelect: ")

        if choice == "1":
            url = input("Enter URL (https://...): ")
            get_title(url)
            input("\nEnter to continue...")

        elif choice == "2":
            url = input("Enter URL (https://...): ")
            get_links(url)
            input("\nEnter to continue...")

        elif choice == "3":
            url = input("Enter URL (https://...): ")
            get_page_text(url)
            input("\nEnter to continue...")

        elif choice == "4":
            url = input("Enter URL (https://...): ")
            get_page_summary(url)
            input("\nPress Enter to continue...")

        elif choice == "5":
            break

# -------------------------
# PROJECT PAGE
# -------------------------


def project_page():
    ensure_projects_dir()

    while True:
        os.system("clear")
        header("PROJECT SYSTEM")

        current = get_current_project()
        print(f"[cyan]Current Project:[/] {current}\n")

        print("[green]1[/] List Projects")
        print("[green]2[/] Create Project")
        print("[green]3[/] Switch Project")
        print("[red]4[/] Delete Project")
        print("[red]5[/] Back")

        choice = input("\nSelect: ")

        if choice == "1":
            projects = os.listdir(PROJECTS_DIR)
            console.print(Panel.fit("\n".join(projects), title="Projects"))
            input("\nEnter...")

        elif choice == "2":
            name = input("New project name: ").strip()

            path = project_path(name)
            os.makedirs(path, exist_ok=True)

            # create notes file
            open(os.path.join(path, "notes.txt"), "a").close()

            # create venv inside project
            venv_path = os.path.join(path, name)

            print("Creating virtual environment...")

            subprocess.run(["python3", "-m", "venv", venv_path])

            print(f"Project '{name}' created with venv ✔")
            input("Enter...")

        elif choice == "3":
            name = input("Project name: ").strip()
            path = project_path(name)

            if os.path.exists(path):
                set_current_project(name)

                cmd = export_switch_command(name)

                print("\nSwitched to project ✔")
                print("\nTo enter this project, run:")
                print(f"toolkit-switch {name}")

            else:
                print("Not found")

            input("Enter...")

        elif choice == "4":
            name = input("Delete project name: ").strip()

            path = project_path(name)

            if os.path.exists(path):
                confirm = input("Are you sure? (y/n): ")

                if confirm.lower() == "y":
                    shutil.rmtree(path)

                    # clear current project if deleted
                    if get_current_project() == name:
                        set_current_project("")

                    print("Project deleted ✔")
                else:
                    print("Cancelled")
            else:
                print("Project not found")

            input("Enter...")

        elif choice == "5":
            break


def export_switch_command(name):
    return project_path(name)


if len(sys.argv) > 1:
    if sys.argv[1] == "switch_cmd":
        name = sys.argv[2]
        print(export_switch_command(name))
        exit()

# -------------------------
# CLI ENTRY
# -------------------------
if len(sys.argv) > 1:
    cmd = sys.argv[1]
    if cmd in COMMANDS:
        args = sys.argv[2:]  # extra arguments
        if args:
            COMMANDS[cmd](*args)
        else:
            COMMANDS[cmd]()
    else:
        print("Unknown command")
    exit()

# -------------------------
# START APP
# -------------------------
def main():
    home()


if __name__ == "__main__":
    # command system still works
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd in COMMANDS:
            args = sys.argv[2:]
            COMMANDS[cmd](*args)
        else:
            print("Unknown command")
    else:
        main()