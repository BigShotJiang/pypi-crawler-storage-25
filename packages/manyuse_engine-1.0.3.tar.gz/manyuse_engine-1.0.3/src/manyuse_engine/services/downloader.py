import yt_dlp, uuid, asyncio
from pathlib import Path
from imageio_ffmpeg import get_ffmpeg_exe
from manyuse_engine.config import TEMP_DIR

async def download_url(url: str, job_id: str) -> str:
    output_dir = TEMP_DIR / job_id
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = str(output_dir / "source.%(ext)s")
    class YtLogger:
        def debug(self, msg): pass
        def warning(self, msg): pass
        def error(self, msg): pass

    ydl_opts = {
        "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "outtmpl": output_path,
        "noplaylist": True, "quiet": True,
        "merge_output_format": "mp4",
        "logger": YtLogger(),
        "ffmpeg_location": get_ffmpeg_exe(),
    }
    def _download():
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
    await asyncio.to_thread(_download)
    for f in output_dir.glob("source.*"):
        return str(f)
    raise ValueError("Download failed: no output file")
