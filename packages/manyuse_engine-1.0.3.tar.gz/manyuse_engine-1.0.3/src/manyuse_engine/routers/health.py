import platform, psutil, subprocess, json, urllib.request
from fastapi import APIRouter
from imageio_ffmpeg import get_ffmpeg_exe
import yt_dlp
from manyuse_engine import __version__

router = APIRouter(tags=["health"])

@router.get("/health")
def health_check():
    ffmpeg = get_ffmpeg_exe()
    try:
        result = subprocess.run([ffmpeg, "-version"], capture_output=True, text=True, timeout=1.0)
        ffmpeg_ver = result.stdout.split("\n")[0].split(" ")[2]
    except Exception:
        ffmpeg_ver = "unknown"

    latest_version = None
    try:
        req = urllib.request.Request(
            "https://pypi.org/pypi/manyuse-engine/json",
            headers={"User-Agent": "manyuse-engine-healthcheck"}
        )
        with urllib.request.urlopen(req, timeout=3.0) as response:
            if response.status == 200:
                data = json.loads(response.read().decode())
                latest_version = data["info"]["version"]
    except Exception:
        pass

    return {
        "status": "ok",
        "version": __version__,
        "latest_version": latest_version,
        "update_available": (
            latest_version is not None and
            latest_version != __version__
        ),
        "ffmpeg": ffmpeg_ver,
        "ytdlp": yt_dlp.version.__version__,
        "platform": platform.system(),
        "cpu_cores": psutil.cpu_count(logical=True),
        "ram_gb": round(psutil.virtual_memory().total / 1024**3, 1),
        "ram_free_gb": round(psutil.virtual_memory().available / 1024**3, 1),
    }
