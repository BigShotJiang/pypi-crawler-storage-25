"""
Chain configurations and contract addresses for Vaultfire Protocol.
"""

from dataclasses import dataclass
from typing import Dict


@dataclass
class ContractAddresses:
    identity: str
    partnership: str
    accountability: str
    reputation: str
    bridge: str


@dataclass
class ChainConfig:
    chain_id: int
    name: str
    rpc_url: str
    contracts: ContractAddresses
    native_currency: str = "ETH"


# ------------------------------------------------------------------
# Contract addresses per chain
# ------------------------------------------------------------------

# Production contract addresses (verified on-chain 2026-04-29)
# Source: https://theloopbreaker.com/api/contracts
# All addresses verified to have deployed bytecode on their respective chains.

BASE_CONTRACTS = ContractAddresses(
    identity="0xa7BD20bf5De63df949cA5Be2F20835978eCba81A",
    partnership="0x01C479F0c039fEC40c0Cf1c5C921bab457d57441",
    accountability="0x6750D28865434344e04e1D0a6044394b726C3dfE",
    reputation="0x98afd1440B2238D73c1394720277a6d031fCbbD0",
    bridge="0x62edf0cBc8Fa3d98B6A07197DFE9cb1c128a7eC7",
)

AVALANCHE_CONTRACTS = ContractAddresses(
    identity="0x7448057C95Fb8a8B974a566cdcc9Cd042166A3f8",
    partnership="0xDC8447c66fE9D9c7D54607A98346A15324b7985D",
    accountability="0x376831fB2457E34559891c32bEb61c442053C066",
    reputation="0x5DB1B4b412b80d03819395794fCcF5A73BF30656",
    bridge="0x1762e484A48558Ea5Cd056ac2CDf43FBbA52ba58",
)

ARBITRUM_CONTRACTS = ContractAddresses(
    identity="0x83dd216449B3F0574E39043ECFE275946fa492e9",
    partnership="0xdB54B8925664816187646174bdBb6Ac658A55a5F",
    accountability="0xef3A944f4d7bb376699C83A29d7Cb42C90D9B6F0",
    reputation="0x8B8Ba34F8AAB800F0Ba8391fb1388c6EFb911F92",
    bridge="0x7b9293B05Bd0fcb7458d06A364078761B8E8848e",
)

POLYGON_CONTRACTS = ContractAddresses(
    identity="0xD9bF6D92a1D9ee44a48c38481c046a819CBdf2ba",
    partnership="0x83dd216449B3F0574E39043ECFE275946fa492e9",
    accountability="0xdB54B8925664816187646174bdBb6Ac658A55a5F",
    reputation="0x54e00081978eE2C8d9Ada8e9975B0Bb543D06A55",
    bridge="0x7b9293B05Bd0fcb7458d06A364078761B8E8848e",
)

# ------------------------------------------------------------------
# Chain configs
# ------------------------------------------------------------------

CHAINS: Dict[str, ChainConfig] = {
    "base": ChainConfig(
        chain_id=8453,
        name="Base",
        rpc_url="https://mainnet.base.org",
        contracts=BASE_CONTRACTS,
        native_currency="ETH",
    ),
    "avalanche": ChainConfig(
        chain_id=43114,
        name="Avalanche",
        rpc_url="https://api.avax.network/ext/bc/C/rpc",
        contracts=AVALANCHE_CONTRACTS,
        native_currency="AVAX",
    ),
    "arbitrum": ChainConfig(
        chain_id=42161,
        name="Arbitrum One",
        rpc_url="https://arbitrum-one.publicnode.com",
        contracts=ARBITRUM_CONTRACTS,
        native_currency="ETH",
    ),
    "polygon": ChainConfig(
        chain_id=137,
        name="Polygon",
        rpc_url="https://polygon-bor-rpc.publicnode.com",
        contracts=POLYGON_CONTRACTS,
        native_currency="POL",
    ),
}

SUPPORTED_CHAINS = list(CHAINS.keys())
DEFAULT_CHAIN = "base"


def get_chain(chain: str) -> ChainConfig:
    """Return chain configuration by name (case-insensitive)."""
    key = chain.lower()
    if key not in CHAINS:
        raise ValueError(
            f"Unsupported chain '{chain}'. Supported: {SUPPORTED_CHAINS}"
        )
    return CHAINS[key]
