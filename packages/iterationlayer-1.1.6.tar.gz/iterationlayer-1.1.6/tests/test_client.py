from __future__ import annotations

import httpx
import pytest
import respx

from iterationlayer.client import IterationLayer, IterationLayerError

BASE_URL = "https://api.iterationlayer.com"
API_KEY = "test-api-key"


@pytest.fixture()
def client() -> IterationLayer:
    return IterationLayer(api_key=API_KEY)


class TestClientConstruction:
    def test_sets_authorization_header(self) -> None:
        client = IterationLayer(api_key="my-key")
        assert client._client.headers["authorization"] == "Bearer my-key"

    def test_sets_content_type_header(self) -> None:
        client = IterationLayer(api_key="my-key")
        assert client._client.headers["content-type"] == "application/json"

    def test_uses_default_base_url(self) -> None:
        client = IterationLayer(api_key="my-key")
        assert str(client._client.base_url) == "https://api.iterationlayer.com"

    def test_allows_custom_base_url(self) -> None:
        client = IterationLayer(api_key="my-key", base_url="https://custom.api.com")
        assert str(client._client.base_url) == "https://custom.api.com"

    def test_allows_custom_timeout(self) -> None:
        client = IterationLayer(api_key="my-key", timeout_in_s=60)
        assert client._client.timeout.read == 60


class TestExtract:
    @respx.mock
    def test_sends_correct_request(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/document-extraction/v1/extract").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "invoice_number": {
                            "value": "INV-001",
                            "confidence": 0.99,
                            "citations": ["page 1"],
                            "source": "file.pdf",
                            "type": "TEXT",
                        }
                    },
                },
            )
        )

        result = client.extract(
            files=[{"type": "url", "name": "file.pdf", "url": "https://example.com/file.pdf"}],
            schema={
                "fields": [
                    {"type": "TEXT", "name": "invoice_number", "description": "The invoice number"}
                ]
            },
        )

        assert route.called
        request_body = route.calls[0].request.content
        assert b'"files"' in request_body
        assert b'"schema"' in request_body
        assert result["invoice_number"]["value"] == "INV-001"
        assert result["invoice_number"]["confidence"] == 0.99

    @respx.mock
    def test_async_result_with_webhook_url(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/document-extraction/v1/extract").mock(
            return_value=httpx.Response(
                202,
                json={
                    "success": True,
                    "async": True,
                    "message": "Processing started",
                },
            )
        )

        result = client.extract_async(
            files=[{"type": "url", "name": "file.pdf", "url": "https://example.com/file.pdf"}],
            schema={"fields": []},
            webhook_url="https://example.com/webhook",
        )

        assert route.called
        assert b'"webhook_url"' in route.calls[0].request.content
        assert result == {"async": True, "message": "Processing started"}


class TestTransform:
    @respx.mock
    def test_sends_correct_request(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/image-transformation/v1/transform").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {"buffer": "base64data==", "mime_type": "image/png"},
                },
            )
        )

        result = client.transform(
            file={"type": "url", "name": "image.png", "url": "https://example.com/image.png"},
            operations=[
                {"type": "resize", "width_in_px": 100, "height_in_px": 100, "fit": "cover"}
            ],
        )

        assert route.called
        request_body = route.calls[0].request.content
        assert b'"file"' in request_body
        assert b'"operations"' in request_body
        assert result["buffer"] == "base64data=="
        assert result["mime_type"] == "image/png"

    @respx.mock
    def test_async_result_with_webhook_url(self, client: IterationLayer) -> None:
        respx.post(f"{BASE_URL}/image-transformation/v1/transform").mock(
            return_value=httpx.Response(
                202,
                json={"success": True, "async": True, "message": "Processing started"},
            )
        )

        result = client.transform_async(
            file={"type": "url", "name": "image.png", "url": "https://example.com/image.png"},
            operations=[{"type": "flip"}],
            webhook_url="https://example.com/webhook",
        )

        assert result == {"async": True, "message": "Processing started"}


class TestGenerateImage:
    @respx.mock
    def test_sends_correct_request(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/image-generation/v1/generate").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {"buffer": "imgdata==", "mime_type": "image/png"},
                },
            )
        )

        result = client.generate_image(
            dimensions={"width_in_px": 800, "height_in_px": 600},
            layers=[{"type": "solid-color", "index": 0, "hex_color": "#ffffff"}],
        )

        assert route.called
        request_body = route.calls[0].request.content
        assert b'"dimensions"' in request_body
        assert b'"layers"' in request_body
        assert result["buffer"] == "imgdata=="
        assert result["mime_type"] == "image/png"

    @respx.mock
    def test_includes_optional_params(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/image-generation/v1/generate").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {"buffer": "imgdata==", "mime_type": "image/jpeg"},
                },
            )
        )

        client.generate_image(
            dimensions={"width_in_px": 800, "height_in_px": 600},
            layers=[{"type": "solid-color", "index": 0, "hex_color": "#ffffff"}],
            output_format="jpeg",
            fonts=[
                {
                    "name": "Roboto",
                    "weight": "400",
                    "style": "normal",
                    "file": {
                        "type": "url",
                        "name": "roboto.ttf",
                        "url": "https://example.com/roboto.ttf",
                    },
                }
            ],
        )

        request_body = route.calls[0].request.content
        assert b'"output_format"' in request_body
        assert b'"fonts"' in request_body

    @respx.mock
    def test_async_result_with_webhook_url(self, client: IterationLayer) -> None:
        respx.post(f"{BASE_URL}/image-generation/v1/generate").mock(
            return_value=httpx.Response(
                202,
                json={"success": True, "async": True, "message": "Processing started"},
            )
        )

        result = client.generate_image_async(
            dimensions={"width_in_px": 800, "height_in_px": 600},
            layers=[{"type": "solid-color", "index": 0, "hex_color": "#ffffff"}],
            webhook_url="https://example.com/webhook",
        )

        assert result == {"async": True, "message": "Processing started"}


class TestGenerateDocument:
    @respx.mock
    def test_sends_correct_request(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/document-generation/v1/generate").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {"buffer": "pdfdata==", "mime_type": "application/pdf"},
                },
            )
        )

        document_definition = {
            "metadata": {"title": "Test Document"},
            "page": {
                "size": {"preset": "A4"},
                "margins": {
                    "top_in_pt": 72,
                    "right_in_pt": 72,
                    "bottom_in_pt": 72,
                    "left_in_pt": 72,
                },
            },
            "styles": {
                "text": {
                    "font_family": "Helvetica",
                    "font_size_in_pt": 12,
                    "line_height": 1.5,
                    "color": "#000000",
                },
                "headline": {
                    "font_family": "Helvetica",
                    "font_size_in_pt": 24,
                    "color": "#000000",
                    "spacing_before_in_pt": 12,
                    "spacing_after_in_pt": 6,
                },
                "link": {"color": "#0000ff"},
                "list": {"indent_in_pt": 20, "spacing_between_items_in_pt": 4},
                "table": {
                    "header": {
                        "background_color": "#f0f0f0",
                        "font_family": "Helvetica",
                        "font_size_in_pt": 12,
                        "color": "#000000",
                        "padding_in_pt": 4,
                    },
                    "body": {
                        "font_family": "Helvetica",
                        "font_size_in_pt": 12,
                        "color": "#000000",
                        "padding_in_pt": 4,
                    },
                },
                "grid": {"gap_in_pt": 10},
                "separator": {
                    "color": "#cccccc",
                    "thickness_in_pt": 1,
                    "margin_top_in_pt": 10,
                    "margin_bottom_in_pt": 10,
                },
                "image": {
                    "alignment": "center",
                    "margin_top_in_pt": 10,
                    "margin_bottom_in_pt": 10,
                },
            },
            "content": [{"type": "paragraph", "markdown": "Hello, world!"}],
        }

        result = client.generate_document(
            format="pdf",
            document=document_definition,  # type: ignore[arg-type]
        )

        assert route.called
        request_body = route.calls[0].request.content
        assert b'"format"' in request_body
        assert b'"document"' in request_body
        assert result["buffer"] == "pdfdata=="
        assert result["mime_type"] == "application/pdf"

    @respx.mock
    def test_async_result_with_webhook_url(self, client: IterationLayer) -> None:
        respx.post(f"{BASE_URL}/document-generation/v1/generate").mock(
            return_value=httpx.Response(
                202,
                json={"success": True, "async": True, "message": "Processing started"},
            )
        )

        result = client.generate_document_async(
            format="pdf",
            document={  # type: ignore[arg-type]
                "metadata": {"title": "Test"},
                "page": {
                    "size": {"preset": "A4"},
                    "margins": {
                        "top_in_pt": 72,
                        "right_in_pt": 72,
                        "bottom_in_pt": 72,
                        "left_in_pt": 72,
                    },
                },
                "styles": {
                    "text": {
                        "font_family": "Helvetica",
                        "font_size_in_pt": 12,
                        "line_height": 1.5,
                        "color": "#000000",
                    },
                    "headline": {
                        "font_family": "Helvetica",
                        "font_size_in_pt": 24,
                        "color": "#000000",
                        "spacing_before_in_pt": 12,
                        "spacing_after_in_pt": 6,
                    },
                    "link": {"color": "#0000ff"},
                    "list": {"indent_in_pt": 20, "spacing_between_items_in_pt": 4},
                    "table": {
                        "header": {
                            "background_color": "#f0f0f0",
                            "font_family": "Helvetica",
                            "font_size_in_pt": 12,
                            "color": "#000000",
                            "padding_in_pt": 4,
                        },
                        "body": {
                            "font_family": "Helvetica",
                            "font_size_in_pt": 12,
                            "color": "#000000",
                            "padding_in_pt": 4,
                        },
                    },
                    "grid": {"gap_in_pt": 10},
                    "separator": {
                        "color": "#cccccc",
                        "thickness_in_pt": 1,
                        "margin_top_in_pt": 10,
                        "margin_bottom_in_pt": 10,
                    },
                    "image": {
                        "alignment": "center",
                        "margin_top_in_pt": 10,
                        "margin_bottom_in_pt": 10,
                    },
                },
                "content": [],
            },
            webhook_url="https://example.com/webhook",
        )

        assert result == {"async": True, "message": "Processing started"}


class TestGenerateSheet:
    @respx.mock
    def test_sends_correct_request(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/sheet-generation/v1/generate").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "buffer": "c2hlZXRkYXRh",
                        "mime_type": (
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        ),
                    },
                },
            )
        )

        result = client.generate_sheet(
            format="xlsx",
            sheets=[
                {
                    "name": "Invoices",
                    "columns": [
                        {"name": "Company", "width": 20},
                        {"name": "Total", "width": 15},
                    ],
                    "rows": [
                        [
                            {"value": "Acme Corp"},
                            {"value": 1500.50, "format": "currency", "currency_code": "EUR"},
                        ],
                    ],
                },
            ],
        )

        assert route.called
        request_body = route.calls[0].request.content
        assert b'"format"' in request_body
        assert b'"sheets"' in request_body
        assert result["buffer"] == "c2hlZXRkYXRh"
        assert (
            result["mime_type"]
            == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

    @respx.mock
    def test_includes_optional_params(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/sheet-generation/v1/generate").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "buffer": "c2hlZXRkYXRh",
                        "mime_type": (
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        ),
                    },
                },
            )
        )

        client.generate_sheet(
            format="xlsx",
            sheets=[
                {
                    "columns": [{"name": "Name"}],
                    "rows": [[{"value": "Test"}]],
                },
            ],
            styles={"header_bold": True, "header_background_color": "#f0f0f0"},
            fonts=[{"name": "CustomFont", "buffer": "Zm9udGRhdGE="}],
        )

        request_body = route.calls[0].request.content
        assert b'"styles"' in request_body
        assert b'"fonts"' in request_body


class TestGenerateSheetAsync:
    @respx.mock
    def test_async_result_with_webhook_url(self, client: IterationLayer) -> None:
        respx.post(f"{BASE_URL}/sheet-generation/v1/generate").mock(
            return_value=httpx.Response(
                202,
                json={"success": True, "async": True, "message": "Processing started"},
            )
        )

        result = client.generate_sheet_async(
            format="xlsx",
            sheets=[
                {
                    "columns": [{"name": "Company"}],
                    "rows": [[{"value": "Acme Corp"}]],
                },
            ],
            webhook_url="https://example.com/webhook",
        )

        assert result == {"async": True, "message": "Processing started"}


class TestErrorHandling:
    @respx.mock
    def test_raises_iteration_layer_error_on_error_response(self, client: IterationLayer) -> None:
        respx.post(f"{BASE_URL}/document-extraction/v1/extract").mock(
            return_value=httpx.Response(
                400,
                json={"success": False, "error": "Invalid schema"},
            )
        )

        with pytest.raises(IterationLayerError) as exc_info:
            client.extract(
                files=[{"type": "url", "name": "file.pdf", "url": "https://example.com/file.pdf"}],
                schema={"fields": []},
            )

        assert exc_info.value.status_code == 400
        assert exc_info.value.error_message == "Invalid schema"

    @respx.mock
    def test_raises_with_unknown_error_when_no_error_field(self, client: IterationLayer) -> None:
        respx.post(f"{BASE_URL}/document-extraction/v1/extract").mock(
            return_value=httpx.Response(
                500,
                json={"success": False},
            )
        )

        with pytest.raises(IterationLayerError) as exc_info:
            client.extract(
                files=[{"type": "url", "name": "file.pdf", "url": "https://example.com/file.pdf"}],
                schema={"fields": []},
            )

        assert exc_info.value.status_code == 500
        assert exc_info.value.error_message == "Unknown error"


class TestConvertToMarkdown:
    @respx.mock
    def test_sends_correct_request(self, client: IterationLayer) -> None:
        route = respx.post(f"{BASE_URL}/document-to-markdown/v1/convert").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "name": "doc.pdf",
                        "mime_type": "application/pdf",
                        "markdown": "# Document\n\nSome content.",
                    },
                },
            )
        )

        result = client.convert_to_markdown(
            file={"type": "url", "name": "doc.pdf", "url": "https://example.com/doc.pdf"},
        )

        assert route.called
        request_body = route.calls[0].request.content
        assert b'"file"' in request_body
        assert result["name"] == "doc.pdf"
        assert result["mime_type"] == "application/pdf"
        assert result["markdown"] == "# Document\n\nSome content."


class TestContextManager:
    def test_close_is_called_on_exit(self) -> None:
        with IterationLayer(api_key=API_KEY) as client:
            assert client._client.is_closed is False

        assert client._client.is_closed is True

    def test_returns_self_on_enter(self) -> None:
        with IterationLayer(api_key=API_KEY) as client:
            assert isinstance(client, IterationLayer)
