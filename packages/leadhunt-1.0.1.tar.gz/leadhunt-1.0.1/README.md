<p align="center">
  <img src="https://leadhunt.tech/logo-white.png" alt="LeadHunt" width="50" />
</p>

<h1 align="center">LeadHunt</h1>
<h3 align="center">Find. Research. Qualify. On autopilot.</h3>

<p align="center">
  <strong>The autonomous revenue agent that finds businesses with digital gaps, qualifies them 0-100, and initiates multi-channel outreach — while you sleep.</strong>
</p>

<p align="center">
  <a href="https://leadhunt.tech">Website</a> · <a href="https://app.leadhunt.tech">Dashboard</a> · <a href="https://app.leadhunt.tech/register">Start Free</a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/status-live-brightgreen?style=flat-square" />
  <img src="https://img.shields.io/badge/countries-50+-orange?style=flat-square" />
  <img src="https://img.shields.io/badge/industries-38+-blue?style=flat-square" />
  <img src="https://img.shields.io/badge/accuracy-98%25-brightgreen?style=flat-square" />
  <img src="https://img.shields.io/badge/Python-3.10+-green?style=flat-square&logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/license-MIT-blue?style=flat-square" />
</p>

---

![LeadHunt — Autonomous Revenue Agent](docs/01-hero.png)

## Why LeadHunt?

Sales teams waste 70% of their time finding leads manually. Apollo and ZoomInfo have stale global data — but miss **local businesses** entirely.

LeadHunt scans Google Maps, local registries, and 12+ data sources to find businesses that **need your services right now** — then reaches out via Email, WhatsApp, Voice AI, and SMS simultaneously.

**One closed deal pays for a year of service.**

### Live Dashboard — Hunting Leads in Real-Time

![LeadHunt — Hunting Leads](docs/dashboard-hunting.png)

### Full CRM Pipeline with Outreach

![LeadHunt — Dashboard with Leads](docs/dashboard-leads.png)

---

## Quick Start

```bash
pip install leadhunt
leadhunt setup           # Configure API key
leadhunt find dentist London --country uk --no-website
```

That's it. Qualified leads with phone, email, owner name, and a 0-100 score — in seconds.

---

## What It Does

### 1. AI LeadResearcher — Find & Score

Scans businesses in any city, any country. Each lead gets a **0-100 qualification score** based on:

- No website → high score (they need one)
- Slow page speed → opportunity (speed optimization)
- Poor reviews (2.1★) → reputation repair
- No ad pixel → paid ads setup
- Inactive social media → management opportunity

![Lead Pipeline — AI Scanning](docs/02-section.png)

### 2. Omnichannel Outreach — Reach Everywhere

One pipeline. Zero gaps. Every channel, simultaneously:

| Channel | Performance |
|---------|------------|
| Email | 42% open rate |
| WhatsApp | 67% response rate |
| Voice AI (Retell) | 24/7 always calling |
| Qualified Meeting | 8x more closes |

![Omnichannel — Email, WhatsApp, Voice, CRM](docs/05-section.png)

### 3. Your Team Calls. AI Coaches Them to Close.

Give LeadHunt to your setters and closers. They make calls, log notes — **AI instantly analyzes the conversation, scrapes prospect data, and delivers closing opportunities in real time.**

- Live call scoring (0-100) while your closer is on the phone
- Notes logged automatically — no manual CRM entry
- **Detected signals:** pain point identified, budget mentioned ($2-3K range), timeline urgency, decision maker confirmed
- **Closing strategy generated:** "Propose Site + SEO bundle at $2,500 → Send audit within 1 hour → Schedule follow-up demo tomorrow AM"
- **Estimated close probability: 78% — HIGH CONFIDENCE**
- All notes, signals & strategies saved to lead profile permanently

![AI Sales Coach — Live Call Intelligence](docs/06-section.png)

### 4. Voice AI Agent — Retell-Powered, 24/7

LeadHunt calls prospects automatically within seconds of discovery. The AI agent:

- Qualifies the lead live on the call
- Books meetings directly into your calendar
- Handles objections with trained scripts
- Speaks naturally — prospects don't know it's AI
- 1,000 minutes/month on Scale plan

### 5. SEO Audit Lead Magnet — 22 Expert Points

Generate branded **22-point website audits** in 3 seconds. Each finding explains **business impact**, not just technical issues:

- Facebook Pixel detection, heading hierarchy, internal links, CTA detection
- AI Search visibility (ChatGPT, Perplexity, Google AI Overview)
- Competitive gap analysis with revenue loss estimation
- Each audit is your foot in the door — not a cold email, a gift

### 6. Voice-to-Text Recording

Record sales calls directly in the browser. Speech-to-text in English and Romanian. Transcripts saved to lead profile permanently.

### 7. Waterfall Enrichment — 98% Accuracy

12+ local sources layered: Maps, business registries, public filings, social profiles → phone, email, owner name, revenue estimates.

![SEO Audit + Enrichment](docs/04-section.png)

---

## Full Feature List

| Feature | Description |
|---------|------------|
| **Google Maps Scraping** | 38+ industries, 22 countries, real-time local language |
| **Lead Intelligence** | 0-100 score, owner name, revenue estimate |
| **Full CRM Pipeline** | New → Contacted → Meeting → Proposal → Won/Lost |
| **Manual Lead Entry** | Add leads manually + notes per lead |
| **Import CSV/XLSX/TXT** | Bulk import with duplicate detection |
| **Voice AI Agent** | Retell-powered, 24/7 automated prospect calling |
| **AI Sales Coach** | Live call analysis + closing scripts + objection handling |
| **Voice-to-Text** | Record calls in browser, EN + RO, transcripts saved |
| **22-Point Website Audit** | Expert SEO/performance/AI-readiness reports |
| **Email Automation** | Template-based, industry-specific outreach (25-unlimited/batch) |
| **WhatsApp Outreach** | Manual links + WATI API auto-send |
| **SMS via Twilio** | Automated text campaigns |
| **Stripe Payments** | Auto-activate plans via webhook, Payment Links |
| **Multi-tenant SaaS** | Each client gets isolated data + own API keys |
| **White-label Mode** | Run under your agency brand |
| **Device Lock** | One device per account, heartbeat monitoring |
| **Admin Panel** | User management, impersonate, DESTROY |
| **CLI + MCP** | Works in Claude Code, Cursor, any AI IDE |

---

## Architecture

```
CLI (pip install leadhunt)
  └── Google Maps API + local registries + 12 sources
  └── Lead scoring engine (0-100)
  └── CSV/JSON export

SaaS Dashboard (app.leadhunt.tech)
  ├── Flask + Gunicorn on Render.com
  ├── Supabase PostgreSQL (multi-tenant)
  ├── Email outreach (SMTP)
  ├── WhatsApp (WATI API)
  ├── SMS (Twilio)
  ├── Voice AI (Retell)
  └── Admin panel + device security

Landing Page (leadhunt.tech)
  └── Next.js 15 + TypeScript + Tailwind + Framer Motion on Vercel
```

---

## Pricing

| Plan | Price | Leads/mo | Email | Highlights |
|------|-------|----------|-------|-----------|
| **Free (CLI)** | $0 | Unlimited local | — | CLI + MCP server, local data, JSON/CSV export, lead scoring |
| **Starter** | $49/mo | 500 | 25/batch | SaaS dashboard, CRM, import CSV/XLSX, AI Coach, voice-to-text, 10 audits |
| **Pro** | $149/mo | 5,000 | 100/batch | + SMS, WhatsApp API, Closer AI scripts, AI voice calls, 3 seats |
| **Unlimited** | $419/mo | Unlimited | Unlimited | + White-label, 10 seats, priority support, everything unlocked |

> **Free CLI** = scraping + scoring locally on your machine. No outreach, no CRM, no team features.
>
> **Paid SaaS** = full dashboard with Email, WhatsApp, SMS, AI Voice Calls, CRM pipeline, website audits, AI Sales Coach, team seats.
>
> One closed deal ($2-5K website) pays for a full year of Starter.

![Pricing](docs/pricing-desktop.png)

---

## Works on Mobile

![Mobile View](docs/mobile-hero.png)

---

## Security

- DevTools detection → instant session kill
- Device lock — one device per account
- Heartbeat monitoring (30s)
- Rate limiting (120 req/min)
- CSV watermarking with user tracking
- Right-click + F12 + PrintScreen blocked
- Security headers: CSP, HSTS, X-Frame-Options

---

## Local Development

```bash
# CLI
pip install leadhunt
leadhunt setup

# SaaS Dashboard
cd lead-system-saas
pip install -r requirements.txt
python app.py            # localhost:5001

# Landing Page
cd leadhunt-landing
npm install && npm run dev  # localhost:3000
```

---

## Links

- **Website:** [leadhunt.tech](https://leadhunt.tech)
- **Dashboard:** [app.leadhunt.tech](https://app.leadhunt.tech)
- **PyPI:** [pypi.org/project/leadhunt](https://pypi.org/project/leadhunt/)

---

## License

MIT — see [LICENSE](LICENSE)

---

<p align="center">
  <sub>The autonomous revenue agent for modern sales teams.</sub>
</p>
