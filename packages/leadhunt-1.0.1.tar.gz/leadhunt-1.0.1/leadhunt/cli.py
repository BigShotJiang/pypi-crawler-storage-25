"""
LeadHunt CLI — find B2B leads from Google Maps in seconds.
"""
import os
import csv
import json
import sys
import time
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.panel import Panel
from rich import box
from rich.text import Text

from .scraper import find_leads, INDUSTRIES, COUNTRIES

console = Console()

CONFIG_FILE = Path.home() / ".leadhunt" / "config.json"


def load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            return {}
    return {}


def save_config(data: dict):
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, indent=2))


def get_api_key(key_arg: Optional[str] = None) -> Optional[str]:
    if key_arg:
        return key_arg
    cfg = load_config()
    if cfg.get("api_key"):
        return cfg["api_key"]
    return os.getenv("GOOGLE_MAPS_API_KEY")


@click.group()
@click.version_option("1.0.1", prog_name="leadhunt")
def cli():
    """
    \b
    LeadHunt -- Find B2B leads all over the world in seconds.

    \b
    Free: 5 industries, 1 country, 50 leads/day
    Pro:  38 industries, 4 countries, unlimited -- leadhunt.dev
    """
    pass


@cli.command()
def setup():
    """Configure your Google Maps API key."""
    console.print(Panel.fit(
        "[bold cyan]LeadHunt Setup[/bold cyan]\n\n"
        "You need a [bold]Google Maps API key[/bold] (free).\n\n"
        "Steps:\n"
        "1. Go to: [bold]https://console.cloud.google.com[/bold]\n"
        "2. Create project > Enable [bold]Places API[/bold]\n"
        "3. Create credentials > API Key\n"
        "4. Free tier: 10,000 requests/month (~5,000 leads)",
        title="[bold]Setup[/bold]"
    ))
    key = click.prompt("\nPaste your Google Maps API key", hide_input=True)
    save_config({"api_key": key.strip()})
    console.print("\n[bold green]✓ API key saved![/bold green] Run: [bold]leadhunt find dentist London[/bold]")


@cli.command()
@click.argument("industry")
@click.argument("city")
@click.option("--country", "-c", default="romania", help="Country key (e.g. uk, usa, japan, france, germany...) — run `leadhunt countries` for full list")
@click.option("--no-website", "-n", is_flag=True, help="Only show businesses WITHOUT a website")
@click.option("--limit", "-l", default=50, help="Max results (default: 50)")
@click.option("--output", "-o", default=None, help="Save to CSV file (e.g. leads.csv)")
@click.option("--no-emails", is_flag=True, help="Skip email extraction (faster)")
@click.option("--api-key", "-k", default=None, help="Google Maps API key (or set via leadhunt setup)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def find(industry, city, country, no_website, limit, output, no_emails, api_key, as_json):
    """Find B2B leads for INDUSTRY in CITY.

    \b
    Examples:
      leadhunt find dentist London --country uk
      leadhunt find restaurant "New York" --country usa --no-website
      leadhunt find salon Paris --country france --output leads.csv
      leadhunt find gym Amsterdam --country netherlands
    """
    api_key = get_api_key(api_key)
    if not api_key:
        console.print("[bold red]✗ No API key found.[/bold red] Run: [bold]leadhunt setup[/bold]")
        sys.exit(1)

    # Show available industries if invalid
    if industry.lower() not in INDUSTRIES:
        console.print(f"[yellow]Industry '[bold]{industry}[/bold]' not in presets — searching as free text.[/yellow]")
        console.print(f"[dim]Available presets: {', '.join(sorted(INDUSTRIES.keys()))}[/dim]\n")

    console.print(Panel.fit(
        f"[bold cyan]Searching for:[/bold cyan] [bold]{industry}[/bold] in [bold]{city}[/bold] ({country.upper()})"
        + (" [bold yellow]· NO WEBSITE ONLY[/bold yellow]" if no_website else ""),
        title="LeadHunt"
    ))

    found = []
    start = time.time()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[bold]{task.completed} leads found"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Scanning Google Maps...", total=limit)

        def on_lead(lead):
            found.append(lead)
            progress.update(task, completed=len(found), description=f"[cyan]{lead['name'][:40]}[/cyan]")

        results = find_leads(
            industry=industry,
            city=city,
            api_key=api_key,
            country=country,
            no_website_only=no_website,
            max_results=limit,
            extract_emails=not no_emails,
            progress_cb=on_lead,
        )

    elapsed = round(time.time() - start, 1)

    if not results:
        console.print("[yellow]No leads found. Try a different city or industry.[/yellow]")
        return

    if as_json:
        console.print_json(json.dumps(results, ensure_ascii=False, indent=2))
        return

    # Build results table
    table = Table(
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
        row_styles=["", "dim"],
    )
    table.add_column("#", style="dim", width=3)
    table.add_column("Business", min_width=25)
    table.add_column("Phone", min_width=14)
    table.add_column("Email", min_width=20)
    table.add_column("Website", min_width=8)
    table.add_column("Score", width=6)
    table.add_column("City")

    for i, lead in enumerate(results, 1):
        score = lead["score"]
        score_color = "green" if score >= 70 else "yellow" if score >= 40 else "red"
        website_badge = "[red]NO SITE[/red]" if not lead["website"] else "[dim]✓[/dim]"
        table.add_row(
            str(i),
            lead["name"][:35],
            lead.get("phone") or "[dim]—[/dim]",
            lead.get("email") or "[dim]—[/dim]",
            website_badge,
            f"[{score_color}]{score}[/{score_color}]",
            lead["city"],
        )

    console.print()
    console.print(table)

    # Stats
    no_site = sum(1 for l in results if not l["website"])
    with_email = sum(1 for l in results if l.get("email"))
    with_phone = sum(1 for l in results if l.get("phone"))
    avg_score = round(sum(l["score"] for l in results) / len(results))

    console.print(Panel(
        f"[bold green]{len(results)} leads[/bold green] found in [bold]{elapsed}s[/bold]  |  "
        f"[bold red]{no_site} without website[/bold red]  |  "
        f"[cyan]{with_email} emails[/cyan]  |  "
        f"[yellow]{with_phone} phones[/yellow]  |  "
        f"avg score [bold]{avg_score}[/bold]",
        title="[bold]Results[/bold]"
    ))

    # Save CSV
    if output:
        _save_csv(results, output)
        console.print(f"\n[bold green]✓ Saved to [bold]{output}[/bold green]")
    else:
        console.print(f"\n[dim]Tip: Add [bold]--output leads.csv[/bold] to save results.[/dim]")

    # SaaS upsell
    console.print()
    console.print(Panel(
        "[bold]Want to contact these leads?[/bold]\n\n"
        "The SaaS dashboard adds: Email, WhatsApp, SMS, AI voice calls,\n"
        "AI Sales Coach, CRM pipeline, and 22-point website audits.\n\n"
        "[bold green]→ https://app.leadhunt.tech/register[/bold green]  [dim](7-day free trial, 100 leads)[/dim]",
        title="[bold cyan]LeadHunt Dashboard[/bold cyan]",
        border_style="cyan",
    ))


@cli.command()
def industries():
    """List all available industries."""
    table = Table(title="Available Industries", box=box.ROUNDED, header_style="bold cyan")
    table.add_column("Key", style="bold")
    table.add_column("Search terms (RO · EN · NL)", style="dim")
    for key, data in sorted(INDUSTRIES.items()):
        terms = f"{', '.join(data.get('ro', [])[:1])}  ·  {', '.join(data.get('en', [])[:1])}  ·  {', '.join(data.get('nl', [])[:1])}"
        table.add_row(key, terms)
    console.print(table)


@cli.command()
def countries():
    """List supported countries."""
    table = Table(title="Supported Countries", box=box.ROUNDED, header_style="bold cyan")
    table.add_column("Flag")
    table.add_column("Key")
    table.add_column("Language")
    flags = {
        "romania": "🇷🇴", "uk": "🇬🇧", "usa": "🇺🇸", "canada": "🇨🇦",
        "netherlands": "🇳🇱", "japan": "🇯🇵", "france": "🇫🇷", "germany": "🇩🇪",
        "spain": "🇪🇸", "italy": "🇮🇹", "australia": "🇦🇺", "brazil": "🇧🇷",
        "mexico": "🇲🇽", "india": "🇮🇳", "uae": "🇦🇪", "singapore": "🇸🇬",
        "portugal": "🇵🇹", "poland": "🇵🇱", "turkey": "🇹🇷", "sweden": "🇸🇪",
        "norway": "🇳🇴", "denmark": "🇩🇰", "belgium": "🇧🇪", "switzerland": "🇨🇭",
        "austria": "🇦🇹", "greece": "🇬🇷", "hungary": "🇭🇺", "czechia": "🇨🇿",
        "southafrica": "🇿🇦", "newzealand": "🇳🇿", "ireland": "🇮🇪",
        "southkorea": "🇰🇷", "china": "🇨🇳",
    }
    for key, cfg in COUNTRIES.items():
        table.add_row(flags.get(key, "🌍"), key, cfg["suffix"])
    console.print(table)


def _save_csv(leads: list[dict], filepath: str):
    if not leads:
        return
    fields = ["name", "phone", "email", "website", "address", "city", "country", "industry", "rating", "reviews", "score"]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(leads)


def main():
    cli()
