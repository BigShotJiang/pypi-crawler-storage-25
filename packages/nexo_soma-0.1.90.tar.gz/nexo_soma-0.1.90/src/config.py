from pydantic import BaseModel
from typing import Generic, TypeVar
from nexo.client.config import OptClientConfigsT, ClientConfigsMixin
from nexo.database.config import (
    DatabaseConfigsT,
    DatabaseConfigsMixin,
)
from nexo.google.config import GoogleConfigMixin
from nexo.google.genai import OptGenAIConfigT
from nexo.google.pubsub.config.publisher import PublisherConfigT
from nexo.google.pubsub.config.subscription import SubscriptionsConfigT
from nexo.infra.config import InfraConfigMixin
from nexo.middlewares.config import MiddlewareConfigMixin


class ApplicationConfig(
    MiddlewareConfigMixin,
    InfraConfigMixin,
    GoogleConfigMixin[OptGenAIConfigT, PublisherConfigT, SubscriptionsConfigT],
    DatabaseConfigsMixin[DatabaseConfigsT],
    ClientConfigsMixin[OptClientConfigsT],
    BaseModel,
    Generic[
        OptClientConfigsT,
        DatabaseConfigsT,
        OptGenAIConfigT,
        PublisherConfigT,
        SubscriptionsConfigT,
    ],
):
    pass


ApplicationConfigT = TypeVar("ApplicationConfigT", bound=ApplicationConfig)
