# mas-automation-cli

AI-powered test automation CLI for **NetScaler Console (MAS/ADM)** functional test cases.

Connects to **StarWars** (Citrix internal test case database), **Claude AI** (script generation),
and a live **MAS + VPX** lab environment — automating the entire
discover → generate → execute → report cycle.

---

## Install

```bash
# With AI support (recommended)
pip install "mas-automation-cli[ai]"

# Standard (no AI generation)
pip install mas-automation-cli
```

Requires Python 3.8+. For AI features, also set one of:
- `ANTHROPIC_API_KEY` — Anthropic direct API
- `ANTHROPIC_VERTEX_PROJECT_ID` — Google Cloud Vertex AI (contact your team admin for project details)

---

## Quick start

```bash
# 1. First-time setup: MAS/VPX/SDK credentials + AI provider
mas-cli init

# 2. Verify everything is reachable (run every session)
mas-cli health-check

# 3. Preview what automate will do — safe, no files written
mas-cli automate 111.3 --dry-run

# 4. Generate + execute all missing test cases for a folder
mas-cli automate 111.3
```

---

## What mas-cli automate does

`mas-cli automate <folder>` runs a 7-step pipeline:

| Step | What happens |
|------|-------------|
| **Preflight** | Checks AI + StarWars MCP + Atlassian — blocks if any required service is down |
| **1. Infra config** | Interactive setup (skipped if already configured) |
| **2. Validate infra** | Pings MAS, VPX, SDK |
| **3. Agent + StarWars** | Fetches all TC IDs for the folder (automated + pending) |
| **3.5. Folder cleanup** | Moves stale legacy scripts to `BACKUP/` — runs even in dry-run |
| **4. Analyze** | Counts total / automated / broken / pending vs StarWars ground truth |
| **5. Generate** | Fetches procedures from StarWars → Claude generates Python test scripts |
| **6. Execute** | Runs all tests via `asterix.py` against live MAS lab |
| **7. Summary** | StarWars coverage breakdown + pass/fail counts |

Example summary output:

```
  --- StarWars (Source of Truth) ---
  Total TCs in folder:       899
    Automated in StarWars:   790  (have scripts in some system)
    Not automated anywhere:  109  (first-time automation targets)

  --- Coverage ---
  Before this run:           112/899  (12%)
  After  this run:           901/899  (100%)
  Added by mas-cli:          +789 script(s)
```

---

## Commands

| Command | Description |
|---------|-------------|
| `mas-cli init` | First-time setup: MAS/VPX/SDK + AI credentials |
| `mas-cli health-check` | 9-point tiered health check (5 core + 3 required + 1 advisory) |
| `mas-cli automate <prefix>` | Full AI pipeline: cleanup → StarWars → generate → execute → report |
| `mas-cli automate <prefix> --dry-run` | Preview only — cleanup runs, no files written |
| `mas-cli automate <prefix> --skip-generate` | Skip AI generation, run existing scripts + show coverage |
| `mas-cli automate <prefix> --skip-execute` | Generate scripts only, skip test execution |
| `mas-cli test <id>` | Run one test or all tests matching a prefix |
| `mas-cli suite <name>` | Run an entire STF suite |
| `mas-cli list-tests` | List all tests registered in the suite |
| `mas-cli config-show` | Show current config (passwords masked) |

---

## Health check tiers

```bash
mas-cli health-check
```

| Tier | Checks | Blocks if down |
|------|--------|----------------|
| **CORE** (5) | Framework, config, SDK, helper modules, OpenSSL | `mas-cli test` |
| **REQUIRED** (3) | AI (Claude API), StarWars MCP, Atlassian MCP | `mas-cli automate` |
| **ADVISORY** (1) | citrix-documentation MCP | Nothing — `[WARN]` only |

---

## Requirements

- Python 3.8+
- Access to a **NetScaler MAS** lab environment
- **Test case MCP server** reachable — requires Citrix internal network / VPN (contact your team for server details)
- **Claude AI**: Anthropic API key or Vertex AI credentials

---

## Links

- [GitHub repository](https://github.com/csg-netscaler/console_mas_automation)
- [Full setup and user guide](https://github.com/csg-netscaler/console_mas_automation#getting-started--setup-to-first-run)
- [Anthropic API keys](https://console.anthropic.com)

---

## License

Copyright 2026 NetScaler Team
