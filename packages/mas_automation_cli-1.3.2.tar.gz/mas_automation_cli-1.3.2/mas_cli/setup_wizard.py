"""Interactive setup wizard for MAS Automation CLI."""
import click
import os
import sys
from pathlib import Path
from getpass import getpass
from .config import ConfigManager
from .ai_generator import AIGenerator


class SetupWizard:
    """Interactive setup wizard for first-time configuration."""

    def __init__(self):
        self.config = ConfigManager()

    def run(self):
        """Run the interactive setup wizard."""
        click.clear()
        click.secho('=' * 60, fg='cyan', bold=True)
        click.secho('NetScaler MAS Automation - Setup Wizard', fg='cyan', bold=True)
        click.secho('=' * 60, fg='cyan', bold=True)
        click.echo()

        if self.config.is_initialized():
            if click.confirm('Configuration already exists. Do you want to reconfigure?'):
                pass
            else:
                click.secho('Keeping existing configuration.', fg='green')
                return

        # --- Deployment Type ---
        deploy_type = self._ask_deployment_type()

        mas_details = None
        adc1_details = None
        adc2_details = None
        agent_details = None
        extauth_details = None

        if deploy_type == '1':
            self._print_section_info(
                'On-Prem Standalone: 1 ADM  +  2 ADC devices  +  optional Agent'
            )
            mas_details = self._collect_mas_details()
            adc1_details = self._collect_adc_details('Primary ADC (vpx_1)', 1)
            adc2_details = self._collect_adc_details('Secondary ADC (vpx_2)', 2, optional=True)
            agent_details = self._collect_agent_details(required=False)

        elif deploy_type == '2':
            self._print_section_info(
                'On-Prem HA: 1 ADM  +  HA pair (Primary + Secondary ADC)  +  optional Agent'
            )
            mas_details = self._collect_mas_details()
            adc1_details = self._collect_ha_adc_details('HA Primary ADC', 'vpx_ha_pri')
            adc2_details = self._collect_ha_adc_details('HA Secondary ADC', 'vpx_ha_sec')
            agent_details = self._collect_agent_details(required=False)

        elif deploy_type == '3':
            self._print_section_info(
                'Cloud Service: No local ADM.  Agent is REQUIRED.  ADC(s) + optional external auth.'
            )
            agent_details = self._collect_agent_details(required=True)
            adc1_details = self._collect_adc_details('ADC Device (vpx_1)', 1)
            extauth_details = self._collect_extauth_details()

        # --- SDK ---
        click.secho('\n[SDK] SDK Configuration', fg='yellow', bold=True)
        default_sdk = 'C:/pysdk' if sys.platform == 'win32' else '/opt/pysdk'
        sdk_path = click.prompt('  SDK Installation Path', default=self.config.get('sdk_path', default_sdk))

        # --- AI ---
        ai_choice, vertex_project, vertex_region, anthropic_key, copilot_token = self._collect_ai_config()

        # --- Generate ssl.cfg ---
        click.secho('\n[SAVE] Generating ssl.cfg...', fg='cyan')
        self._generate_ssl_cfg(
            deploy_type, mas_details, adc1_details, adc2_details,
            agent_details, extauth_details
        )

        # --- Save config.json ---
        click.secho('[SAVE] Saving configuration...', fg='cyan')
        self.config.set('deploy_type', deploy_type)
        self.config.set('sdk_path', sdk_path)

        if mas_details:
            self.config.set('mas_ip', mas_details['ip'])
            self.config.set('mas_user', mas_details['user'])
            self.config.set('mas_pass', mas_details['pwd'])
        else:
            # Cloud mode — no ADM
            for k in ('mas_ip', 'mas_user', 'mas_pass'):
                self.config.delete(k)

        # Primary ADC (vpx_ip is used by executor + health-check)
        if adc1_details:
            self.config.set('vpx_ip', adc1_details['ip'])
            self.config.set('vpx_user', adc1_details['user'])
            self.config.set('vpx_pass', adc1_details['pwd'])

        if agent_details:
            self.config.set('agent_ip', agent_details['ip'])
            self.config.set('agent_id', agent_details['id'])
            self.config.set('agent_user', agent_details['user'])
            self.config.set('agent_pass', agent_details['pwd'])

        if vertex_project:
            self.config.set('vertex_project_id', vertex_project)
            self.config.set('vertex_region', vertex_region)
        if anthropic_key:
            self.config.set('anthropic_api_key', anthropic_key)
        if copilot_token:
            self.config.set('copilot_token', copilot_token)

        self.config.set('configured', True)

        # --- Test AI ---
        if ai_choice != '4':
            click.secho('\n[AI] Testing AI connectivity...', fg='cyan')
            ai = AIGenerator(self._detect_project_root(), self.config)
            ok, msg = ai.check_connectivity()
            if ok:
                click.secho(f'  [OK] {msg}', fg='green')
                click.echo('  mas-cli automate will use real AI to generate test cases!')
            else:
                click.secho(f'  [WARN] {msg}', fg='yellow')
                click.echo('  AI not reachable now — automate will use template mode until fixed.')
                if 'google' in msg.lower() or 'vertex' in msg.lower():
                    click.secho('\n  FIX: Run the following command and then re-run mas-cli init:', fg='cyan')
                    click.secho('    pip install "anthropic[vertex]"', fg='white', bold=True)
                elif 'copilot' in msg.lower() or 'openai' in msg.lower():
                    click.secho('\n  FIX: Run the following command and then re-run mas-cli init:', fg='cyan')
                    click.secho('    pip install openai', fg='white', bold=True)

        click.echo()
        click.secho('[OK] Setup completed successfully!', fg='green', bold=True)
        deploy_labels = {'1': 'On-Prem Standalone', '2': 'On-Prem HA', '3': 'Cloud Service'}
        click.secho(f'  Deployment type: {deploy_labels.get(deploy_type, deploy_type)}', fg='green')
        click.secho(f'  Config saved to: {self.config.config_file}', fg='green')
        click.secho(f'  SSL config saved to: {self.config.ssl_cfg_file}', fg='green')
        if ai_choice != '4':
            ai_label = {
                '1': 'Vertex AI (GCP)',
                '2': 'Anthropic API',
                '3': 'GitHub Copilot',
            }.get(ai_choice, ai_choice)
            click.secho(f'  AI provider:   {ai_label}', fg='green')
        click.echo()

    # -------------------------------------------------------------------------
    # Deployment type
    # -------------------------------------------------------------------------

    def _ask_deployment_type(self) -> str:
        click.secho('\n[DEPLOY] Deployment Type', fg='yellow', bold=True)
        click.echo('  What type of environment are you automating?\n')
        click.echo('    1. On-Prem Standalone  — 1 ADM + 1 or 2 ADCs  (most common)')
        click.echo('    2. On-Prem HA          — 1 ADM + HA pair (Primary + Secondary ADC)')
        click.echo('    3. Cloud Service       — ADM Service cloud + Agent (required) + ADC(s)')
        current = self.config.get('deploy_type', '1')
        return click.prompt(
            '\n  Select deployment type',
            type=click.Choice(['1', '2', '3']),
            default=current,
        )

    def _print_section_info(self, text: str):
        click.echo()
        click.secho(f'  INFO: {text}', fg='cyan')

    # -------------------------------------------------------------------------
    # ADM (MAS) details
    # -------------------------------------------------------------------------

    def _collect_mas_details(self) -> dict:
        click.secho('\n[ADM] NetScaler Console (ADM) Configuration', fg='yellow', bold=True)
        ip = click.prompt('  ADM IP Address', default=self.config.get('mas_ip', '10.106.150.56'))
        user = click.prompt('  ADM Username', default=self.config.get('mas_user', 'nsroot'))
        pwd = getpass('  ADM Password: ')
        return {'ip': ip, 'user': user, 'pwd': pwd}

    # -------------------------------------------------------------------------
    # ADC details (On-Prem Standalone)
    # -------------------------------------------------------------------------

    def _collect_adc_details(self, label: str, idx: int, optional: bool = False) -> dict | None:
        click.secho(f'\n[ADC-{idx}] {label}', fg='yellow', bold=True)
        if optional:
            if not click.confirm(f'  Configure {label}?', default=True):
                return None
        default_ip = self.config.get('vpx_ip', '') if idx == 1 else ''
        ip = click.prompt('  IP Address', default=default_ip)
        user = click.prompt('  Username', default='nsroot')
        pwd = getpass('  Password: ')
        adc_type = click.prompt(
            '  Device Type',
            type=click.Choice(['vpx', 'mpx', 'sdx', 'blx']),
            default='vpx',
        )
        profile = click.prompt('  Profile Name', default='customprofile')
        result = {'ip': ip, 'user': user, 'pwd': pwd, 'type': adc_type, 'profile': profile}

        # BLX needs extra host info
        if adc_type == 'blx':
            result.update(self._collect_blx_extras())

        return result

    def _collect_blx_extras(self) -> dict:
        click.secho('    [BLX] Linux host details required for BLX device', fg='cyan')
        host_ip = click.prompt('    Linux Host IP')
        host_user = click.prompt('    Linux Host Username', default='root')
        host_pwd = getpass('    Linux Host Password: ')
        profile_name = click.prompt('    BLX Profile Name', default='customblx')
        blx_type = click.prompt(
            '    BLX Type',
            type=click.Choice(['dedicated', 'shared']),
            default='dedicated',
        )
        result = {
            'device_host_ip': host_ip,
            'device_host_user': host_user,
            'device_host_pwd': host_pwd,
            'profile_name': profile_name,
        }
        if blx_type == 'shared':
            result['blx_type'] = 'shared'
        return result

    # -------------------------------------------------------------------------
    # ADC details (HA)
    # -------------------------------------------------------------------------

    def _collect_ha_adc_details(self, label: str, section: str) -> dict:
        click.secho(f'\n[ADC-HA] {label}', fg='yellow', bold=True)
        ip = click.prompt('  IP Address')
        user = click.prompt('  Username', default='nsroot')
        pwd = getpass('  Password: ')
        profile = click.prompt('  Profile Name', default='customprofile')
        return {'ip': ip, 'user': user, 'pwd': pwd, 'profile': profile, 'type': 'vpx', 'section': section}

    # -------------------------------------------------------------------------
    # Agent details
    # -------------------------------------------------------------------------

    def _collect_agent_details(self, required: bool = False) -> dict | None:
        if required:
            click.secho('\n[Agent] ADM Agent Configuration (Required for Cloud Service)', fg='yellow', bold=True)
        else:
            click.secho('\n[Agent] ADM Agent Configuration (optional)', fg='yellow', bold=True)
            if not click.confirm('  Configure an ADM Agent?', default=False):
                return None
        ip = click.prompt('  Agent IP Address', default=self.config.get('agent_ip', ''))
        agent_id = click.prompt('  Agent ID (UUID)', default=self.config.get('agent_id', ''))
        user = click.prompt('  Agent Username', default='nsrecover')
        pwd = getpass('  Agent Password: ')
        return {'ip': ip, 'id': agent_id, 'user': user, 'pwd': pwd}

    # -------------------------------------------------------------------------
    # External Auth details (Cloud)
    # -------------------------------------------------------------------------

    def _collect_extauth_details(self) -> dict | None:
        click.secho('\n[ExtAuth] External Authentication Server (optional)', fg='yellow', bold=True)
        if not click.confirm('  Configure external auth server?', default=False):
            return None
        ip = click.prompt('  Server IP Address')
        protocol = click.prompt('  Protocol', type=click.Choice(['HTTP', 'HTTPS']), default='HTTP')
        user = click.prompt('  Username')
        pwd = getpass('  Password: ')
        return {'ip': ip, 'protocol': protocol, 'user': user, 'pwd': pwd}

    # -------------------------------------------------------------------------
    # AI configuration
    # -------------------------------------------------------------------------

    def _collect_ai_config(self):
        """Prompt for AI provider selection and credentials. Returns 5-tuple."""
        click.secho('\n[AI] Claude AI Configuration (enables intelligent test generation)', fg='yellow', bold=True)
        click.echo('  The automate command uses AI to read StarWars test cases and')
        click.echo('  generate Python scripts from scratch — no AI means template-only mode.')
        click.echo()
        click.echo('  Options:')
        click.echo('    1. Vertex AI (GCP)       — recommended for Citrix employees')
        click.echo('    2. Anthropic API Key     — standalone/personal machines')
        click.echo('    3. GitHub Copilot        — GitHub PAT with Copilot access')
        click.echo('    4. Skip for now')

        current_ai = '4'
        if self.config.get('vertex_project_id'):
            current_ai = '1'
        elif self.config.get('anthropic_api_key'):
            current_ai = '2'
        elif self.config.get('copilot_token'):
            current_ai = '3'

        ai_choice = click.prompt(
            '  Select AI provider',
            type=click.Choice(['1', '2', '3', '4']),
            default=current_ai,
        )

        vertex_project = vertex_region = anthropic_key = copilot_token = None

        if ai_choice == '1':
            click.secho('\n  [Vertex AI] Using GCP project for Claude access', fg='cyan')
            vertex_project = click.prompt(
                '  GCP Project ID',
                default=os.environ.get('ANTHROPIC_VERTEX_PROJECT_ID', 'claude-code-citrix'),
            )
            vertex_region = click.prompt(
                '  GCP Region',
                default=os.environ.get('CLOUD_ML_REGION', 'us-east5'),
            )

        elif ai_choice == '2':
            click.secho('\n  [Anthropic API] Enter your API key from console.anthropic.com', fg='cyan')
            anthropic_key = getpass('  Anthropic API Key: ')

        elif ai_choice == '3':
            click.secho('\n  [GitHub Copilot] Enter a GitHub Personal Access Token', fg='cyan')
            click.echo('  The token needs the  copilot  scope (or a fine-grained token with Copilot access).')
            click.echo('  Generate one at: https://github.com/settings/tokens')
            copilot_token = getpass('  GitHub PAT: ')
            click.echo('  NOTE: requires  pip install openai  if not already installed.')

        return ai_choice, vertex_project, vertex_region, anthropic_key, copilot_token

    # -------------------------------------------------------------------------
    # ssl.cfg generation
    # -------------------------------------------------------------------------

    def _generate_ssl_cfg(
        self, deploy_type: str,
        mas: dict | None,
        adc1: dict | None,
        adc2: dict | None,
        agent: dict | None,
        extauth: dict | None,
    ):
        lines = [
            '[default]',
            'loglevel = INFO',
            '',
        ]

        # ADM section (On-Prem types only)
        if mas:
            lines += [
                '[mas]',
                f'ip = {mas["ip"]}',
                f'username = {mas["user"]}',
                f'password = {mas["pwd"]}',
                'protocol = http',
                '',
            ]

        # ADC sections
        if deploy_type == '2':
            # HA mode: use named ha sections
            for adc, section in [(adc1, 'vpx_ha_pri'), (adc2, 'vpx_ha_sec')]:
                if adc:
                    lines += self._adc_section(adc.get('section', section), adc)
        else:
            # Standalone / Cloud: numbered vpx sections
            if adc1:
                lines += self._adc_section('vpx_1', adc1)
            if adc2:
                lines += self._adc_section('vpx_2', adc2)

        # Agent section
        if agent:
            lines += [
                '[agent_1]',
                f'ip = {agent["ip"]}',
                f'id = {agent["id"]}',
                f'username = {agent["user"]}',
                f'password = {agent["pwd"]}',
                '',
            ]

        # External auth section
        if extauth:
            lines += [
                '[extauth]',
                f'ip = {extauth["ip"]}',
                f'protocol = {extauth["protocol"]}',
                f'username = {extauth["user"]}',
                f'password = {extauth["pwd"]}',
                '',
            ]

        ssl_cfg_path = self.config.get_ssl_cfg_path()
        with open(ssl_cfg_path, 'w') as f:
            f.write('\n'.join(lines))
        click.secho(f'  [OK] Generated {ssl_cfg_path}', fg='green')

    def _adc_section(self, section_name: str, adc: dict) -> list:
        """Return ssl.cfg lines for one ADC device."""
        lines = [
            f'[{section_name}]',
            f'ip = {adc["ip"]}',
            f'username = {adc["user"]}',
            f'password = {adc["pwd"]}',
            f'type = {adc.get("type", "vpx")}',
        ]
        if adc.get('profile'):
            lines.append(f'profile = {adc["profile"]}')
        # BLX extras
        if adc.get('device_host_ip'):
            lines.append(f'device_host_ip = {adc["device_host_ip"]}')
            lines.append(f'device_host_username = {adc["device_host_user"]}')
            lines.append(f'device_host_password = {adc["device_host_pwd"]}')
            lines.append(f'profile_name = {adc["profile_name"]}')
        if adc.get('blx_type'):
            lines.append(f'blx_type = {adc["blx_type"]}')
        lines.append('')
        return lines

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def _detect_project_root(self) -> Path:
        """Find project root for AI generator (same logic as executor)."""
        if 'MAS_AUTOMATION_ROOT' in os.environ:
            return Path(os.environ['MAS_AUTOMATION_ROOT'])
        for root in [Path.cwd(), Path.home() / 'mas-automation', Path('c:/console_mas_automation')]:
            if (root / 'scripts' / 'asterix.py').exists():
                return root
        return Path.cwd()
