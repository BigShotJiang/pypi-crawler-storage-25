"""Configuration management for MAS Automation CLI."""
import os
import json
import sys
from pathlib import Path
from typing import Dict, Optional


class ConfigManager:
    """Manages MAS Automation configuration and state."""

    CONFIG_DIR = Path.home() / '.mas-automation'
    CONFIG_FILE = CONFIG_DIR / 'config.json'
    SSL_CFG_FILE = CONFIG_DIR / 'ssl.cfg'

    def __init__(self):
        self.config_dir = self.CONFIG_DIR
        self.config_file = self.CONFIG_FILE
        self.ssl_cfg_file = self.SSL_CFG_FILE
        self._config: Dict = {}
        self._load()

    def _ensure_dir(self):
        """Ensure config directory exists."""
        self.config_dir.mkdir(parents=True, exist_ok=True)

    def _load(self):
        """Load configuration from file."""
        self._ensure_dir()
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    self._config = json.load(f)
            except Exception as e:
                self._config = {}
        else:
            self._config = {}

    def save(self):
        """Save configuration to file."""
        self._ensure_dir()
        with open(self.config_file, 'w') as f:
            json.dump(self._config, f, indent=2)

    def get(self, key: str, default=None):
        """Get configuration value."""
        return self._config.get(key, default)

    def set(self, key: str, value):
        """Set configuration value."""
        self._config[key] = value
        self.save()

    def delete(self, key: str):
        """Remove a configuration key (no-op if missing)."""
        if key in self._config:
            del self._config[key]
            self.save()

    def is_initialized(self) -> bool:
        """Check if MAS Automation is initialized.

        Cloud Service mode has no local ADM, so we accept either:
          - on-prem/HA: mas_ip + mas_user + vpx_ip
          - cloud:      agent_ip + agent_id + vpx_ip
        """
        cloud = self._config.get('deploy_type') == '3'
        if cloud:
            return all(k in self._config for k in ['agent_ip', 'agent_id', 'vpx_ip'])
        return all(k in self._config for k in ['mas_ip', 'mas_user', 'vpx_ip'])

    def get_ssl_cfg_path(self) -> str:
        """Get path to ssl.cfg file."""
        return str(self.ssl_cfg_file)

    def get_config_dict(self) -> Dict:
        """Get all configuration as dictionary."""
        return self._config.copy()
