"""Interactive infrastructure setup and validation for MAS Automation."""
import os
import sys
import socket
import requests
from pathlib import Path
from typing import Dict, Optional

try:
    import urllib3
    urllib3.disable_warnings()
except Exception:
    pass


class InfraSetup:
    """Interactive infrastructure configuration and validation."""

    def __init__(self, config_manager):
        self.config = config_manager

    def interactive_setup(self, folder_prefix: str) -> Dict:
        """Run interactive setup to collect all infra config.

        Returns dict with all config values.
        """
        print("\n" + "=" * 60)
        print("  MAS Automation Infrastructure Setup")
        print(f"  Target folder: {folder_prefix}")
        print("=" * 60)

        existing = self.config.get_config_dict()

        cfg = {}

        # --- MAS config ---
        print("\n[MAS] NetScaler Console (MAS) Settings")
        cfg['mas_ip'] = self._prompt(
            "  MAS IP address",
            existing.get('mas_ip', ''))
        cfg['mas_user'] = self._prompt(
            "  MAS username",
            existing.get('mas_user', 'nsroot'))
        cfg['mas_pass'] = self._prompt_password(
            "  MAS password",
            existing.get('mas_pass', ''))
        cfg['mas_protocol'] = self._prompt(
            "  MAS protocol (http/https)",
            existing.get('mas_protocol', 'http'))

        # --- VPX config ---
        print("\n[VPX] NetScaler ADC (VPX) Settings")
        cfg['vpx_ip'] = self._prompt(
            "  VPX IP address",
            existing.get('vpx_ip', ''))
        cfg['vpx_user'] = self._prompt(
            "  VPX username",
            existing.get('vpx_user', 'nsroot'))
        cfg['vpx_pass'] = self._prompt_password(
            "  VPX password",
            existing.get('vpx_pass', ''))

        # --- SDK / framework ---
        print("\n[SDK] Python SDK Settings")
        cfg['sdk_path'] = self._prompt(
            "  SDK path (PYTHONPATH)",
            existing.get('sdk_path', 'C:/pysdk'))

        print("\n[LOGS] Log Settings")
        cfg['log_folder'] = self._prompt(
            "  Log folder",
            existing.get('log_folder', '/tmp/mas_automation_logs'))

        return cfg

    def save_config(self, cfg: Dict, project_root: Path):
        """Save config to ConfigManager and to ssl.cfg for the framework."""
        for key, value in cfg.items():
            self.config.set(key, value)

        # Write ssl.cfg for the test framework
        ssl_cfg_path = project_root / 'config' / 'ssl.cfg'
        self._write_ssl_cfg(cfg, ssl_cfg_path)
        print(f"\n  Config saved to {self.config.config_file}")
        print(f"  SSL config written to {ssl_cfg_path}")

    def _write_ssl_cfg(self, cfg: Dict, ssl_cfg_path: Path):
        """Write ssl.cfg in INI format for the test framework."""
        content = (
            "[default]\n"
            "loglevel = INFO\n"
            "\n"
            "[mas]\n"
            f"ip = {cfg.get('mas_ip', '')}\n"
            f"username = {cfg.get('mas_user', 'nsroot')}\n"
            f"password = {cfg.get('mas_pass', '')}\n"
            f"protocol = {cfg.get('mas_protocol', 'http')}\n"
            "\n"
            "[vpx]\n"
            f"ip = {cfg.get('vpx_ip', '')}\n"
            f"username = {cfg.get('vpx_user', 'nsroot')}\n"
            f"password = {cfg.get('vpx_pass', '')}\n"
            "\n"
            "[logs]\n"
            f"log_folder = {cfg.get('log_folder', '/tmp/mas_automation_logs')}\n"
        )
        ssl_cfg_path.parent.mkdir(parents=True, exist_ok=True)
        with open(ssl_cfg_path, 'w') as f:
            f.write(content)

    def validate_all(self, cfg: Dict) -> bool:
        """Validate all infrastructure components.

        Returns True if all checks pass.
        """
        print("\n" + "=" * 60)
        print("  Infrastructure Validation")
        print("=" * 60 + "\n")

        results = []

        # MAS connectivity
        mas_ok = self._check_mas(cfg)
        results.append(('MAS connectivity', mas_ok))

        # VPX connectivity
        vpx_ok = self._check_host(cfg.get('vpx_ip', ''), 443, 'VPX')
        results.append(('VPX connectivity', vpx_ok))

        # SDK path
        sdk_ok = self._check_sdk(cfg.get('sdk_path', ''))
        results.append(('SDK path', sdk_ok))

        # Print summary
        print()
        all_ok = True
        for name, ok in results:
            status = '[OK]   ' if ok else '[FAIL] '
            print(f"  {status} {name}")
            if not ok:
                all_ok = False

        if all_ok:
            print("\n  All checks passed.\n")
        else:
            print("\n  Some checks failed. Tests may not run correctly.\n")

        return all_ok

    def _check_mas(self, cfg: Dict) -> bool:
        """Check MAS is reachable and credentials work."""
        ip = cfg.get('mas_ip', '')
        user = cfg.get('mas_user', 'nsroot')
        password = cfg.get('mas_pass', '')
        protocol = cfg.get('mas_protocol', 'http')

        if not ip:
            return False

        try:
            url = f"{protocol}://{ip}/nitro/v1/config/login"
            payload = f'object={{"login":{{"username":"{user}","password":"{password}"}}}}'
            r = requests.post(
                url, data=payload,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                verify=False, timeout=15)
            return r.status_code == 200
        except Exception:
            return False

    def _check_host(self, ip: str, port: int, label: str) -> bool:
        """TCP-connect check for a host:port."""
        if not ip:
            return False
        try:
            sock = socket.create_connection((ip, port), timeout=10)
            sock.close()
            return True
        except Exception:
            # Try port 80 as fallback
            try:
                sock = socket.create_connection((ip, 80), timeout=10)
                sock.close()
                return True
            except Exception:
                return False

    def _check_sdk(self, sdk_path: str) -> bool:
        """Check SDK path exists."""
        if not sdk_path:
            return False
        return Path(sdk_path).exists()

    @staticmethod
    def _prompt(label: str, default: str = '') -> str:
        """Prompt user for input with optional default."""
        if default:
            value = input(f"{label} [{default}]: ").strip()
            return value if value else default
        else:
            while True:
                value = input(f"{label}: ").strip()
                if value:
                    return value
                print("  (required)")

    @staticmethod
    def _prompt_password(label: str, default: str = '') -> str:
        """Prompt user for password (shown as asterisks in default)."""
        masked = '***' if default else ''
        value = input(f"{label} [{masked}]: ").strip()
        return value if value else default
