"""Execute test cases and suites."""
import subprocess
import sys
import os
from pathlib import Path
from typing import Optional, Dict
from .config import ConfigManager


class TestExecutor:
    """Executes test cases using the framework."""

    def __init__(self, project_root: Optional[str] = None):
        """Initialize executor.

        Args:
            project_root: Path to the MAS Automation project root.
                         If None, attempts to detect from installed package.
        """
        self.config = ConfigManager()
        self.project_root = Path(project_root) if project_root else self._detect_project_root()
        self.asterix_script = self.project_root / 'scripts' / 'asterix.py'
        self._ensure_setup_config()

    def _detect_project_root(self) -> Path:
        """Detect the project root from installed package or environment."""
        # Try environment variable first
        if 'MAS_AUTOMATION_ROOT' in os.environ:
            return Path(os.environ['MAS_AUTOMATION_ROOT'])

        # Try package installation directory
        try:
            import mas_automation_framework
            return Path(mas_automation_framework.__file__).parent.parent
        except ImportError:
            pass

        # Fallback: look for project root in common locations
        possible_roots = [
            Path.cwd(),
            Path.home() / 'mas-automation',
            Path('/opt/mas-automation'),
        ]

        for root in possible_roots:
            if (root / 'scripts' / 'asterix.py').exists():
                return root

        raise RuntimeError(
            'Could not find MAS Automation project root. '
            'Set MAS_AUTOMATION_ROOT environment variable or install framework package.'
        )

    def _ensure_setup_config(self):
        """Auto-create config/setup_config.cfg from template if it doesn't exist."""
        setup_cfg = self.project_root / 'config' / 'setup_config.cfg'
        if setup_cfg.exists():
            return

        sdk_path = self.config.get('sdk_path', '')
        # Use forward slashes — works on Windows and avoids escape issues in test scripts
        test_root = str(self.project_root).replace('\\', '/')
        content = (
            '[default]\n'
            f'test_root = {test_root}\n'
            'suite_path = suite\n'
            'testcases_path = testcases\n'
            'logfile = asterix.log\n'
            'result_file = results.txt\n'
            'loglevel = DEBUG\n'
            f'sdk_path = {sdk_path}\n'
        )

        setup_cfg.parent.mkdir(parents=True, exist_ok=True)
        setup_cfg.write_text(content)

    def validate_setup(self) -> bool:
        """Validate that all necessary files exist."""
        checks = [
            (self.asterix_script.exists(), f'asterix.py script at {self.asterix_script}'),
            ((self.project_root / 'config' / 'setup_config.cfg').exists(), 'setup_config.cfg'),
            (self.config.ssl_cfg_file.exists(), f'ssl.cfg at {self.config.ssl_cfg_file}'),
        ]

        all_ok = True
        for check, desc in checks:
            status = '[OK]' if check else '[!!]'
            print(f'  {status} {desc}')
            all_ok = all_ok and check

        return all_ok

    def run_test(self, test_id: str, suite_name: str = 'SANITY_RTM') -> int:
        """Run test cases matching the ID prefix.

        Args:
            test_id: Test case ID prefix (e.g., '111.3' finds all 111.3.x tests)
            suite_name: Suite name (default: SANITY_RTM)

        Returns:
            Return code from test execution (0 = success)
        """
        # Find matching test scripts directly from testcases/ — avoids running
        # the entire master STF when only a specific prefix is requested.
        matching_scripts = self._find_scripts_for_prefix(test_id)
        if not matching_scripts:
            print(f'Error: No test scripts found matching prefix {test_id}')
            return 1

        print(f'\nFound {len(matching_scripts)} test script(s) matching {test_id}:\n')
        for s in matching_scripts:
            print(f'  - {s}')

        # Write a temporary STF with exactly the matched scripts and run it.
        tmp_stf = self.project_root / 'suite' / suite_name / f'_tmp_{test_id.replace(".", "_")}.stf'
        try:
            tmp_stf.parent.mkdir(parents=True, exist_ok=True)
            tmp_stf.write_text('\n'.join(matching_scripts) + '\n')
            print(f'\n[TEST] Executing {len(matching_scripts)} script(s)...\n')
            return self._execute_framework(str(tmp_stf.relative_to(self.project_root)))
        finally:
            if tmp_stf.exists():
                tmp_stf.unlink()

    def _find_scripts_for_prefix(self, test_prefix: str) -> list:
        """Find test script files in testcases/ whose filename starts with the prefix.

        Returns relative paths (forward-slash) suitable for use in STF files.
        """
        testcases_root = self.project_root / 'testcases'
        if not testcases_root.exists():
            return []

        matches = []
        for py_file in sorted(testcases_root.rglob('*.py')):
            if py_file.stem.startswith(test_prefix):
                rel = str(py_file.relative_to(testcases_root)).replace('\\', '/')
                matches.append(rel)
        return matches

    def run_suite(self, suite_name: str) -> int:
        """Run an entire test suite.

        Args:
            suite_name: Suite name (e.g., 'SANITY_RTM')

        Returns:
            Return code from test execution (0 = success)
        """
        stf_file = self.project_root / 'suite' / suite_name / 'ssl.stf'
        if not stf_file.exists():
            print(f'Error: Suite file not found at {stf_file}')
            return 1

        return self._execute_framework(str(stf_file.relative_to(self.project_root)))

    def _find_stfs_for_test_prefix(self, test_prefix: str, suite_name: str) -> list:
        """Find all STF files containing tests matching the prefix.

        Args:
            test_prefix: Test case ID prefix (e.g., '111.3' finds all 111.3.x tests)
            suite_name: Suite name

        Returns:
            List of relative paths to STF files that contain matching tests
        """
        suite_dir = self.project_root / 'suite' / suite_name
        if not suite_dir.exists():
            return []

        matching_stfs = []
        # Look for STF files that contain tests matching this prefix
        for stf_file in sorted(suite_dir.glob('*.stf')):
            with open(stf_file, 'r') as f:
                content = f.read()
                # Check if file contains any test matching this prefix
                for line in content.split('\n'):
                    if test_prefix in line and not line.strip().startswith('#'):
                        relative_path = str(stf_file.relative_to(self.project_root))
                        if relative_path not in matching_stfs:
                            matching_stfs.append(relative_path)
                        break

        return matching_stfs

    def _find_stf_for_test(self, test_id: str, suite_name: str) -> Optional[str]:
        """Find STF file containing the test (deprecated - use _find_stfs_for_test_prefix).

        Args:
            test_id: Test case ID (e.g., '111.3.4.145')
            suite_name: Suite name

        Returns:
            Relative path to STF file or None if not found
        """
        stfs = self._find_stfs_for_test_prefix(test_id, suite_name)
        return stfs[0] if stfs else None

    def _execute_framework(self, stf_file: str) -> int:
        """Execute the framework with given STF file.

        Args:
            stf_file: Relative path to STF file from project root
                      (e.g. suite/SANITY_RTM/ssl_111_3_1_certstore_api.stf)

        Returns:
            Return code from subprocess (0 = success, 1 = failure)
        """
        # asterix.py prepends <test_root>/<suite_path>/ to the -s argument internally.
        # setup_config.cfg has suite_path = 'suite', so asterix builds:
        #   <test_root>/suite/<input>
        # Our discovery returns paths like 'suite\SANITY_RTM\file.stf' (relative to project root).
        # We must strip the leading 'suite/' so asterix gets 'SANITY_RTM/file.stf'
        # and builds the correct 'suite/SANITY_RTM/file.stf'.
        stf_normalized = stf_file.replace('\\', '/')
        if stf_normalized.startswith('suite/'):
            stf_arg = stf_normalized[len('suite/'):]   # 'SANITY_RTM/file.stf'
        else:
            stf_arg = stf_normalized

        # Verify the STF file actually exists before calling asterix.py.
        # asterix.py exits 0 even when the file is missing — false PASS without this check.
        full_stf = self.project_root / 'suite' / stf_arg
        if not full_stf.exists():
            print(f'[FAIL] STF file not found: {full_stf}')
            return 1

        # Build command
        cmd = [
            sys.executable,
            str(self.asterix_script),
            '-c', str(self.config.ssl_cfg_file),
            '-s', stf_arg,
        ]

        # Setup environment — inject sdk_path and modules/ into PYTHONPATH so
        # both asterix.py and every test subprocess it spawns can find modules.
        env = os.environ.copy()
        sdk_path = self.config.get('sdk_path', '')
        modules_path = str(self.project_root / 'modules').replace('\\', '/')
        extra = [p for p in [sdk_path, modules_path] if p]
        if extra:
            existing = env.get('PYTHONPATH', '')
            env['PYTHONPATH'] = os.pathsep.join(extra) + (os.pathsep + existing if existing else '')

        # Change to project root for execution
        original_cwd = os.getcwd()
        try:
            os.chdir(self.project_root)
            print(f'\n[EXEC] Running: {" ".join(cmd)}\n')
            result = subprocess.run(cmd, env=env, capture_output=False)
            # Detect false-positive PASS: asterix exits 0 even on missing suite file.
            # Check stdout/stderr for "does not exist" as a secondary signal.
            return result.returncode
        finally:
            os.chdir(original_cwd)

    def list_tests(self, suite_name: str = 'SANITY_RTM') -> Dict[str, str]:
        """List all available tests in a suite.

        Args:
            suite_name: Suite name

        Returns:
            Dictionary mapping test IDs to file paths
        """
        tests = {}
        suite_dir = self.project_root / 'suite' / suite_name

        if not suite_dir.exists():
            return tests

        for stf_file in suite_dir.glob('*.stf'):
            with open(stf_file, 'r') as f:
                for line in f:
                    # Parse STF format: relative path to test file
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # Extract test ID from filename
                        test_id = self._extract_test_id(line)
                        if test_id:
                            tests[test_id] = line

        return tests

    @staticmethod
    def _extract_test_id(filepath: str) -> Optional[str]:
        """Extract test ID from file path.

        Args:
            filepath: Test case file path

        Returns:
            Test ID or None
        """
        # Example: SSL/SSL_cert/111.3.4.145_verify_csr_aes256_encoding.py -> 111.3.4.145
        basename = Path(filepath).name
        parts = basename.split('_')
        if parts:
            # First part should be test ID
            potential_id = parts[0]
            if potential_id[0].isdigit():
                return potential_id
        return None
