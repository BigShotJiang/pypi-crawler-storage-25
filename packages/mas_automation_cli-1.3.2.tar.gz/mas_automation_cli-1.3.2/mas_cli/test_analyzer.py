"""Analyze existing test cases: count total, automated, pending."""
import re
from pathlib import Path
from typing import Dict, List, NamedTuple, Optional


class TCInfo(NamedTuple):
    tc_id: str
    filename: str
    filepath: Path
    in_stf: bool
    has_broken_imports: bool
    description: str


class AnalysisResult(NamedTuple):
    folder_prefix: str
    total: int
    automated: int
    pending: int
    broken: int
    tc_list: List[TCInfo]
    automated_list: List[TCInfo]
    pending_list: List[TCInfo]
    broken_list: List[TCInfo]
    stf_files: List[str]


BROKEN_IMPORTS = {
    'certificate_operations',
    'certificate_operations_generic',
    'ns_pb2',
}


class TestAnalyzer:
    """Scans testcases/ and suite/ to classify TCs for a folder prefix."""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.testcases_dir = project_root / 'testcases'
        self.suite_dir = project_root / 'suite'

    def analyze(self, folder_prefix: str, suite_name: str = 'SANITY_RTM') -> AnalysisResult:
        """Analyze a folder prefix (e.g. '111.3') and return full stats.

        Steps:
        1. Find all test script files matching folder_prefix in testcases/
        2. Find all STF files in suite_name
        3. Build set of TC filenames that appear in any STF
        4. Classify each existing TC as automated, broken, or pending
        5. Find STF entries matching the prefix that have NO script file (missing)
           — these go into pending_list for AI generation from StarWars
        """
        print(f"\n  Scanning test cases for folder {folder_prefix}...")

        # Step 1: Find all matching TC files that exist on disk
        tc_files = self._find_tc_files(folder_prefix)
        print(f"  Found {len(tc_files)} test script file(s) matching '{folder_prefix}'")

        # Step 2: Build set of files registered in STF files
        stf_registered, stf_files, stf_full_entries = self._load_stf_entries(suite_name)
        print(f"  Found {len(stf_files)} STF file(s) in suite '{suite_name}'")
        print(f"  Total STF entries across all suite files: {len(stf_full_entries)}")

        # Step 3: Classify existing scripts
        automated = []
        pending = []
        broken = []
        all_tcs = []

        for filepath in tc_files:
            tc_id = self._extract_tc_id(filepath.name)
            description = self._extract_description(filepath.name)
            has_broken = self._has_broken_imports(filepath)
            in_stf = self._is_in_stf(filepath, stf_registered)

            info = TCInfo(
                tc_id=tc_id,
                filename=filepath.name,
                filepath=filepath,
                in_stf=in_stf,
                has_broken_imports=has_broken,
                description=description,
            )
            all_tcs.append(info)

            if in_stf and not has_broken:
                automated.append(info)
            elif has_broken:
                broken.append(info)
            else:
                pending.append(info)

        # Step 4: Find STF entries matching prefix with NO script on disk
        #         These are deleted/never-created TCs — fetch from StarWars + generate.
        missing = self._find_missing_scripts(folder_prefix, stf_full_entries, tc_files)
        if missing:
            print(f"  Found {len(missing)} STF entry/entries with no script file (will generate from StarWars)")
        pending.extend(missing)
        all_tcs.extend(missing)

        result = AnalysisResult(
            folder_prefix=folder_prefix,
            total=len(all_tcs),
            automated=len(automated),
            pending=len(pending),
            broken=len(broken),
            tc_list=all_tcs,
            automated_list=automated,
            pending_list=pending,
            broken_list=broken,
            stf_files=stf_files,
        )

        self._print_analysis(result)
        return result

    def _find_tc_files(self, folder_prefix: str) -> List[Path]:
        """Find all .py files whose name starts with folder_prefix.

        BACKUP/ subdirectories are always excluded — stale files moved there
        by the folder-cleanup step should never be counted as test scripts.
        """
        results = []
        for search_dir in self.testcases_dir.rglob('*'):
            if search_dir.is_dir() and search_dir.name != 'BACKUP':
                for f in search_dir.glob(f'{folder_prefix}*.py'):
                    results.append(f)
        return sorted(results)

    def _load_stf_entries(self, suite_name: str):
        """Return (registered_set, stf_file_list, full_entry_list).

        registered_set   — basenames + full paths for _is_in_stf checks
        stf_file_list    — relative paths of .stf files found
        full_entry_list  — all raw STF lines (full relative paths from testcases/)
        """
        suite_path = self.suite_dir / suite_name
        registered = set()
        stf_files = []
        full_entries = []

        if not suite_path.exists():
            return registered, stf_files, full_entries

        for stf in sorted(suite_path.glob('*.stf')):
            stf_files.append(str(stf.relative_to(self.project_root)))
            with open(stf, 'r', errors='replace') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        normalized = line.replace('\\', '/')
                        registered.add(Path(line).name)
                        registered.add(normalized)
                        full_entries.append(normalized)

        return registered, stf_files, full_entries

    def _find_missing_scripts(self, folder_prefix: str, stf_full_entries: list,
                              existing_files: list) -> List['TCInfo']:
        """Return TCInfo for STF entries matching prefix that have no script on disk."""
        existing_names = {f.name for f in existing_files}
        seen = set()
        missing = []

        for entry in stf_full_entries:
            basename = Path(entry).name
            if not basename.startswith(folder_prefix):
                continue
            if basename in existing_names or basename in seen:
                continue
            seen.add(basename)

            tc_id = self._extract_tc_id(basename)
            description = self._extract_description(basename)
            # Expected output path: testcases/<entry>
            filepath = self.testcases_dir / entry

            missing.append(TCInfo(
                tc_id=tc_id,
                filename=basename,
                filepath=filepath,
                in_stf=True,
                has_broken_imports=False,
                description=description,
            ))

        return missing

    def _is_in_stf(self, filepath: Path, stf_registered: set) -> bool:
        """Check if this file appears in any STF entry."""
        return (filepath.name in stf_registered or
                any(filepath.name in entry for entry in stf_registered))

    def _has_broken_imports(self, filepath: Path) -> bool:
        """Check if the file imports modules known to be broken/unavailable."""
        try:
            content = filepath.read_text(encoding='utf-8', errors='replace')
            for broken in BROKEN_IMPORTS:
                # Match: import broken or from broken import ...
                if re.search(rf'\bimport\s+{re.escape(broken)}\b', content):
                    return True
                if re.search(rf'\bfrom\s+{re.escape(broken)}\b', content):
                    return True
        except Exception:
            pass
        return False

    def _extract_tc_id(self, filename: str) -> str:
        """Extract TC ID from filename like '111.3.1.526_name.py'."""
        match = re.match(r'^([\d.]+)', filename)
        return match.group(1) if match else filename

    def _extract_description(self, filename: str) -> str:
        """Extract description from filename after TC ID."""
        match = re.match(r'^[\d.]+_(.*?)\.py$', filename)
        if match:
            return match.group(1).replace('_', ' ')
        return ''

    def _print_analysis(self, r: AnalysisResult):
        """Print analysis summary table."""
        print("\n" + "=" * 60)
        print(f"  Test Case Analysis: folder {r.folder_prefix}")
        print("=" * 60)
        print(f"  Total TC scripts found:  {r.total}")
        print(f"  Automated (in STF):      {r.automated}")
        print(f"  Broken imports (fixable):{r.broken}")
        print(f"  Not registered (pending):{r.pending}")
        print()

        if r.broken_list:
            print(f"  Broken scripts (need rewrite):")
            for tc in r.broken_list[:10]:
                print(f"    {tc.tc_id:<20} {tc.description[:40]}")
            if len(r.broken_list) > 10:
                print(f"    ... and {len(r.broken_list) - 10} more")
            print()

        if r.pending_list:
            print(f"  Pending (will generate from StarWars):")
            for tc in r.pending_list[:10]:
                tag = '[MISSING]' if tc.in_stf else '[NO STF]'
                print(f"    {tag} {tc.tc_id:<20} {tc.description[:35]}")
            if len(r.pending_list) > 10:
                print(f"    ... and {len(r.pending_list) - 10} more")
            print()
