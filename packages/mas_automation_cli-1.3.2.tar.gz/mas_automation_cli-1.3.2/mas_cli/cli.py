"""Main CLI interface for MAS Automation."""
import click
import sys
from pathlib import Path
from . import __version__
from .config import ConfigManager
from .setup_wizard import SetupWizard
from .executor import TestExecutor
from .health_check import HealthChecker
from .orchestrator import MASOrchestrator


@click.group()
@click.version_option(version=__version__, prog_name='mas-automation-cli')
def main():
    """NetScaler MAS Automation CLI - Execute test cases with ease.

    Quick start:
      1. mas-cli init              (one-time setup)
      2. mas-cli test 111.3.4.145  (run a test)
      3. mas-cli suite SANITY_RTM  (run entire suite)
    """
    pass


@main.command()
def init():
    """Initialize MAS Automation configuration."""
    wizard = SetupWizard()
    wizard.run()


@main.command()
@click.argument('test_id')
@click.option('--suite', default='SANITY_RTM', help='Test suite name')
@click.option('--project-root', envvar='MAS_AUTOMATION_ROOT', help='Project root directory')
def test(test_id: str, suite: str, project_root: str):
    """Run a specific test case.

    Example: mas-cli test 111.3.4.145
    """
    config = ConfigManager()

    if not config.is_initialized():
        click.secho('Error: MAS Automation not initialized.', fg='red', bold=True)
        click.echo('Run: mas-cli init')
        sys.exit(1)

    try:
        executor = TestExecutor(project_root)

        click.secho(f'[TEST] Running test {test_id} from suite {suite}...', fg='cyan', bold=True)
        click.echo()

        # Validate setup
        if not executor.validate_setup():
            click.secho('Setup validation failed. Run: mas-cli health-check', fg='red')
            sys.exit(1)

        # Run test
        exit_code = executor.run_test(test_id, suite)

        click.echo()
        if exit_code == 0:
            click.secho('[PASS] Test passed!', fg='green', bold=True)
        else:
            click.secho(f'[FAIL] Test failed with exit code {exit_code}', fg='red', bold=True)

        sys.exit(exit_code)

    except Exception as e:
        click.secho(f'Error: {e}', fg='red', bold=True)
        sys.exit(1)


@main.command()
@click.argument('suite_name', default='SANITY_RTM')
@click.option('--project-root', envvar='MAS_AUTOMATION_ROOT', help='Project root directory')
def suite(suite_name: str, project_root: str):
    """Run an entire test suite.

    Example: mas-cli suite SANITY_RTM
    """
    config = ConfigManager()

    if not config.is_initialized():
        click.secho('Error: MAS Automation not initialized.', fg='red', bold=True)
        click.echo('Run: mas-cli init')
        sys.exit(1)

    try:
        executor = TestExecutor(project_root)

        click.secho(f'[SUITE] Running suite {suite_name}...', fg='cyan', bold=True)
        click.echo()

        # Validate setup
        if not executor.validate_setup():
            click.secho('Setup validation failed. Run: mas-cli health-check', fg='red')
            sys.exit(1)

        # Run suite
        exit_code = executor.run_suite(suite_name)

        click.echo()
        if exit_code == 0:
            click.secho('[PASS] Suite passed!', fg='green', bold=True)
        else:
            click.secho(f'[FAIL] Suite failed with exit code {exit_code}', fg='red', bold=True)

        sys.exit(exit_code)

    except Exception as e:
        click.secho(f'Error: {e}', fg='red', bold=True)
        sys.exit(1)


@main.command()
@click.option('--suite', default='SANITY_RTM', help='Test suite name')
@click.option('--project-root', envvar='MAS_AUTOMATION_ROOT', help='Project root directory')
def list_tests(suite: str, project_root: str):
    """List all available tests in a suite."""
    try:
        executor = TestExecutor(project_root)
        tests = executor.list_tests(suite)

        if not tests:
            click.echo(f'No tests found in suite {suite}')
            sys.exit(0)

        click.secho(f'\nAvailable tests in suite {suite}:\n', fg='cyan', bold=True)
        for test_id, filepath in sorted(tests.items()):
            click.echo(f'  {test_id:<20} {filepath}')
        click.echo()

    except Exception as e:
        click.secho(f'Error: {e}', fg='red', bold=True)
        sys.exit(1)


@main.command()
@click.option('--project-root', envvar='MAS_AUTOMATION_ROOT', help='Project root directory')
def health_check(project_root: str):
    """Check system health and setup validity."""
    config = ConfigManager()

    if not config.is_initialized():
        click.secho('Warning: MAS Automation not initialized.', fg='yellow', bold=True)
        click.echo('Run: mas-cli init\n')
        return

    try:
        executor = TestExecutor(project_root)
        checker = HealthChecker(executor, config)
        checker.run()

    except Exception as e:
        click.secho(f'Error: {e}', fg='red', bold=True)
        sys.exit(1)


@main.command()
def config_show():
    """Show current configuration."""
    config = ConfigManager()

    click.secho('\nCurrent Configuration:\n', fg='cyan', bold=True)

    cfg = config.get_config_dict()
    if not cfg:
        click.echo('  No configuration found. Run: mas-cli init\n')
        return

    for key, value in cfg.items():
        # Mask passwords
        display_value = '***' if 'pass' in key.lower() else value
        click.echo(f'  {key:<20} {display_value}')

    click.echo(f'\nConfig file: {config.config_file}')
    click.echo(f'SSL config: {config.ssl_cfg_file}\n')


@main.command()
@click.argument('folder_prefix')
@click.option('--suite', default='SANITY_RTM', help='Test suite name')
@click.option('--project-root', envvar='MAS_AUTOMATION_ROOT', help='Project root directory')
@click.option('--skip-generate', is_flag=True, default=False,
              help='Skip generating new test scripts')
@click.option('--skip-execute', is_flag=True, default=False,
              help='Analyze and generate only, skip execution')
@click.option('--dry-run', is_flag=True, default=False,
              help='Show what would happen without making changes')
def automate(folder_prefix: str, suite: str, project_root: str,
             skip_generate: bool, skip_execute: bool, dry_run: bool):
    """Full automation orchestration for a test folder.

    \b
    Steps:
      1. Interactive infra setup (MAS, VPX, SDK)
      2. Validate infrastructure connectivity
      3. Read agent files for knowledge
      4. Analyze test cases (count total/automated/pending)
      5. Generate/rewrite broken test scripts
      6. Execute all tests in real infrastructure
      7. Show comprehensive summary

    \b
    Example:
      mas-cli automate 111.3
      mas-cli automate 111.3 --dry-run
      mas-cli automate 111.3 --skip-execute
    """
    try:
        orchestrator = MASOrchestrator(project_root)
        orchestrator.run(
            folder_prefix=folder_prefix,
            suite_name=suite,
            skip_generate=skip_generate,
            dry_run=dry_run,
            skip_execute=skip_execute,
        )
    except KeyboardInterrupt:
        click.echo('\n\n  Orchestration cancelled by user.')
        sys.exit(1)
    except Exception as e:
        click.secho(f'Error: {e}', fg='red', bold=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
