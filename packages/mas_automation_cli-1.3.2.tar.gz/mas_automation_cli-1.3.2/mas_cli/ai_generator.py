"""AI-powered test generator using Claude API (Vertex AI, Anthropic, or GitHub Copilot)."""
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

from .config import ConfigManager

GENERATE_PROMPT = """\
You are a NetScaler MAS test automation expert. Write a Python 3 test body for the following test case.

Test Case ID: {tc_id}
Title: {title}

Procedures:
{procedures}

Expected Result:
{expected_result}

Reference example (existing passing test from same feature area):
```python
{example_code}
```

Write ONLY the indented Python code block that goes INSIDE run_test(), replacing the try/except block.
The function already has these variables in scope:
  - tcid (str): test case ID
  - title (str): TC title
  - result_set (dict): set result_set[tcid]['result'] = True to mark PASS
  - logger_object: .info(), .error(), .critical()
  - mas_ip, mas_username, mas_password, mas_protocol: MAS credentials
  - _mas_session(mas_ip, mas_username, mas_password, mas_protocol, logger_object): returns authenticated requests.Session

NITRO API patterns:
  GET:    s.get("%s://%s/nitro/v1/config/<resource>" % (mas_protocol, mas_ip), verify=False, timeout=30)
  POST:   s.post(url, json={"<resource>": {...}}, verify=False, timeout=30)
  DELETE: s.delete("%s://%s/nitro/v2/config/<resource>/<id>?<opts>" % (mas_protocol, mas_ip), verify=False, timeout=30)

Return Python code only. No markdown fences. Start with '    try:' (4-space indent).\
"""

FIX_PROMPT = """\
A NetScaler MAS automation test is failing. Fix the Python test body.

Test Case ID: {tc_id}

Current test body (inside run_test()):
```python
{current_code}
```

Error log from execution:
```
{error_log}
```

Return the corrected test body only. Python code only. No markdown fences. Start with '    try:' (4-space indent).\
"""


class AIGenerator:
    """Generates and fixes test bodies using Claude API (Vertex, Anthropic, or Copilot)."""

    # Provider constants
    PROVIDER_ANTHROPIC = 'anthropic'
    PROVIDER_OPENAI_COMPAT = 'openai_compat'   # covers Copilot + any OpenAI-compatible endpoint

    def __init__(self, project_root: Path, config: ConfigManager):
        self.project_root = project_root
        self.config = config
        self._cached_client: Optional[Tuple] = None

    def is_configured(self) -> bool:
        """Return True if AI credentials are available (env vars or config)."""
        return bool(
            os.environ.get('ANTHROPIC_API_KEY') or
            os.environ.get('ANTHROPIC_VERTEX_PROJECT_ID') or
            self.config.get('anthropic_api_key') or
            self.config.get('vertex_project_id') or
            self.config.get('copilot_token')
        )

    # -------------------------------------------------------------------------
    # Client factory
    # -------------------------------------------------------------------------

    def _get_client(self) -> Tuple:
        """Return (client, model_id, provider). Cached after first call."""
        if self._cached_client is not None:
            return self._cached_client

        vertex_project = (
            os.environ.get('ANTHROPIC_VERTEX_PROJECT_ID') or
            self.config.get('vertex_project_id')
        )
        vertex_region = (
            os.environ.get('CLOUD_ML_REGION') or
            self.config.get('vertex_region') or
            'us-east5'
        )
        api_key = (
            os.environ.get('ANTHROPIC_API_KEY') or
            self.config.get('anthropic_api_key')
        )
        copilot_token = self.config.get('copilot_token')
        model = os.environ.get('ANTHROPIC_MODEL', 'claude-sonnet-4-6')

        # --- GitHub Copilot (OpenAI-compatible) ---
        if copilot_token and not vertex_project and not api_key:
            client, provider = self._build_copilot_client(copilot_token)
            copilot_model = os.environ.get('COPILOT_MODEL', 'claude-sonnet-4-5-20250219')
            self._cached_client = (client, copilot_model, provider)
            return self._cached_client

        # --- Anthropic SDK (Vertex or direct) ---
        try:
            import anthropic
        except ImportError:
            raise RuntimeError(
                'anthropic package not installed.\n'
                'Run: pip install "mas-automation-cli[ai]"\n'
                'Or:  pip install anthropic'
            )

        if vertex_project:
            client = self._build_vertex_client(anthropic, vertex_project, vertex_region)
            self._cached_client = (client, model, self.PROVIDER_ANTHROPIC)
        elif api_key:
            client = anthropic.Anthropic(api_key=api_key)
            self._cached_client = (client, model, self.PROVIDER_ANTHROPIC)
        else:
            raise RuntimeError(
                'No AI credentials found.\n'
                'Run: mas-cli init  (to configure AI credentials)\n'
                'Or set: ANTHROPIC_API_KEY  or  ANTHROPIC_VERTEX_PROJECT_ID'
            )

        return self._cached_client

    def _build_vertex_client(self, anthropic_module, project: str, region: str):
        """Instantiate AnthropicVertex with a clear error if google-auth is missing."""
        try:
            return anthropic_module.AnthropicVertex(
                project_id=project,
                region=region,
            )
        except ImportError as exc:
            if 'google' in str(exc).lower():
                raise RuntimeError(
                    'google-auth not installed — required for Vertex AI.\n'
                    'Fix: pip install "anthropic[vertex]"\n'
                    'Then re-run: mas-cli init'
                ) from exc
            raise

    def _build_copilot_client(self, token: str) -> Tuple:
        """Build an OpenAI client pointed at the GitHub Copilot endpoint."""
        try:
            from openai import OpenAI
        except ImportError:
            raise RuntimeError(
                'openai package not installed — required for GitHub Copilot.\n'
                'Fix: pip install openai\n'
                'Then re-run: mas-cli init'
            )
        client = OpenAI(
            base_url='https://api.githubcopilot.com',
            api_key=token,
            default_headers={'Copilot-Integration-Id': 'vscode-chat'},
        )
        return client, self.PROVIDER_OPENAI_COMPAT

    # -------------------------------------------------------------------------
    # StarWars fetch
    # -------------------------------------------------------------------------

    def fetch_tc_from_starwars(
        self, tc_id: str,
        test_plan: str = 'CCLiveCertificateManagementTestPlan'
    ) -> Optional[str]:
        """Fetch TC procedures from StarWars via mcp_client.py. Returns raw output or None."""
        mcp_client = self.project_root / 'scripts' / 'mcp_client.py'
        if not mcp_client.exists():
            return None
        try:
            args = json.dumps({'test_plan': test_plan, 'case_id': tc_id})
            result = subprocess.run(
                [sys.executable, str(mcp_client),
                 '--tool', 'get_testcase_from_test_plan',
                 '--args', args,
                 '--timeout', '45'],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout
        except Exception:
            pass
        return None

    def fetch_folder_tc_list(self, folder_prefix: str, relid: str = '14.1') -> list:
        """Fetch all TC IDs for a folder from StarWars automation_server.

        Uses get_folder_automation_files MCP tool.
        Returns list of TC ID strings, empty list on failure.
        """
        mcp_client = self.project_root / 'scripts' / 'mcp_client.py'
        if not mcp_client.exists():
            return []
        try:
            args = json.dumps({'folder_id': folder_prefix, 'relid': relid})
            result = subprocess.run(
                [sys.executable, str(mcp_client),
                 '--tool', 'get_folder_automation_files',
                 '--args', args,
                 '--timeout', '30'],
                capture_output=True, text=True, timeout=45,
            )
            if result.returncode == 0 and result.stdout.strip():
                return self._parse_tc_id_list(result.stdout)
        except Exception:
            pass
        return []

    def _parse_tc_id_list(self, raw: str) -> list:
        """Parse TC data from get_folder_automation_files output.

        Returns list of dicts: [{'tc_id': str, 'description': str, 'is_automated': bool}]
        Reads BOTH test_cases (automated) AND pending_automation (not yet automated).
        """
        import re as _re
        try:
            data = json.loads(raw)
            result = []

            def _add(item, is_automated):
                if isinstance(item, dict):
                    tc_id = (item.get('testcase_id') or item.get('case_id') or
                             item.get('id') or item.get('tc_id') or '')
                    desc = item.get('description', '')
                else:
                    tc_id = str(item)
                    desc = ''
                if tc_id:
                    result.append({'tc_id': str(tc_id), 'description': str(desc),
                                   'is_automated': is_automated})

            for item in (data.get('test_cases') or []):
                _add(item, is_automated=True)

            for item in (data.get('pending_automation') or []):
                _add(item, is_automated=False)

            if result:
                return result

            # Fallback for non-standard response shapes
            items = data if isinstance(data, list) else (
                data.get('result') or data.get('files') or
                data.get('testcases') or data.get('data') or []
            )
            for item in (items if isinstance(items, list) else []):
                _add(item, is_automated=item.get('is_automated', True)
                     if isinstance(item, dict) else True)
            if result:
                return result
        except Exception:
            pass
        # Last resort: regex-extract IDs only
        return [{'tc_id': tc_id, 'description': '', 'is_automated': True}
                for tc_id in _re.findall(r'\b\d+\.\d+[\d.]*\b', raw)]

    # -------------------------------------------------------------------------
    # Generation
    # -------------------------------------------------------------------------

    def generate_test_body(
        self, tc_id: str, title: str,
        procedures: str, expected_result: str,
        example_code: str = ''
    ) -> Optional[str]:
        """Call AI to generate a test body. Returns Python code or None on error."""
        try:
            client, model, provider = self._get_client()
            prompt = GENERATE_PROMPT.format(
                tc_id=tc_id,
                title=title,
                procedures=procedures or '(not provided)',
                expected_result=expected_result or '(not provided)',
                example_code=example_code or '# No reference example available',
            )
            text = self._call_model(client, model, provider, prompt)
            return self._strip_fences(text)
        except Exception as e:
            print(f'    [AI] Generation failed: {e}')
            return None

    def fix_test_body(
        self, tc_id: str, current_code: str, error_log: str
    ) -> Optional[str]:
        """Call AI to fix a failing test body. Returns corrected code or None."""
        try:
            client, model, provider = self._get_client()
            prompt = FIX_PROMPT.format(
                tc_id=tc_id,
                current_code=current_code,
                error_log=error_log[-3000:],
            )
            text = self._call_model(client, model, provider, prompt)
            return self._strip_fences(text)
        except Exception as e:
            print(f'    [AI] Fix generation failed: {e}')
            return None

    def check_connectivity(self) -> Tuple[bool, str]:
        """Ping the AI API with a minimal message. Returns (ok, message)."""
        try:
            client, model, provider = self._get_client()
            self._call_model(client, model, provider, 'hi', max_tokens=5)
            if provider == self.PROVIDER_OPENAI_COMPAT:
                label = 'GitHub Copilot'
            elif self.config.get('vertex_project_id') or os.environ.get('ANTHROPIC_VERTEX_PROJECT_ID'):
                label = 'Vertex AI'
            else:
                label = 'Anthropic API'
            return True, f'AI connected ({label}, {model})'
        except RuntimeError as e:
            return False, str(e).split('\n')[0]
        except Exception as e:
            return False, f'AI not available: {e}'

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _call_model(
        self, client, model: str, provider: str,
        prompt: str, max_tokens: int = 2048
    ) -> str:
        """Unified model call — handles Anthropic SDK and OpenAI-compatible clients."""
        if provider == self.PROVIDER_ANTHROPIC:
            msg = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                messages=[{'role': 'user', 'content': prompt}],
            )
            return msg.content[0].text.strip()
        else:
            # OpenAI-compatible (Copilot, etc.)
            resp = client.chat.completions.create(
                model=model,
                max_tokens=max_tokens,
                messages=[{'role': 'user', 'content': prompt}],
            )
            return resp.choices[0].message.content.strip()

    @staticmethod
    def _strip_fences(text: str) -> str:
        """Remove markdown code fences if the model added them."""
        if text.startswith('```'):
            lines = text.split('\n')
            end = len(lines) - 1 if lines[-1].startswith('```') else len(lines)
            return '\n'.join(lines[1:end])
        return text
