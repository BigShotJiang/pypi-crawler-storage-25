"""Read and parse agent definition files from .github/agents/."""
import re
from pathlib import Path
from typing import Dict, List


class AgentReader:
    """Reads agent .md files and extracts capability knowledge."""

    AGENTS_DIR = '.github/agents'

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.agents_dir = project_root / self.AGENTS_DIR

    def load_all_agents(self) -> Dict:
        """Load all agent files and return combined knowledge.

        Returns:
            Dict with agent names, capabilities, and extracted patterns.
        """
        agents = {}

        if not self.agents_dir.exists():
            print(f"  [WARN] Agents directory not found: {self.agents_dir}")
            return agents

        agent_files = list(self.agents_dir.glob('*.agent.md'))
        if not agent_files:
            agent_files = list(self.agents_dir.glob('*.md'))

        print(f"\n  Found {len(agent_files)} agent file(s):")
        for agent_file in sorted(agent_files):
            print(f"    - {agent_file.name}")
            agent_data = self._parse_agent_file(agent_file)
            agents[agent_data['name']] = agent_data

        return agents

    def extract_knowledge(self, agents: Dict) -> Dict:
        """Extract key knowledge from loaded agents.

        Returns structured knowledge the orchestrator needs.
        """
        knowledge = {
            'test_plan_name': 'CCLiveCertificateManagementTestPlan',
            'mcp_tools': [],
            'api_patterns': [],
            'tc_naming_convention': '<tcid>_<description>.py',
            'broken_imports': ['certificate_operations', 'certificate_operations_generic'],
            'working_pattern': '526/527/570 style - direct NITRO REST',
            'folder_map': {
                '111.3': 'SSL Certificate Management',
                '111.3.1': 'Certstore API operations',
                '111.3.4': 'CSR/key generation',
                '111.3.33': 'PEM cert install via MAS',
            },
        }

        for name, agent in agents.items():
            # Extract MCP tool names
            tools = self._extract_mcp_tools(agent.get('raw', ''))
            knowledge['mcp_tools'].extend(tools)

            # Extract API patterns
            apis = self._extract_api_patterns(agent.get('raw', ''))
            knowledge['api_patterns'].extend(apis)

        # Deduplicate
        knowledge['mcp_tools'] = list(set(knowledge['mcp_tools']))
        knowledge['api_patterns'] = list(dict.fromkeys(knowledge['api_patterns']))

        return knowledge

    def _parse_agent_file(self, agent_file: Path) -> Dict:
        """Parse a single agent .md file."""
        try:
            content = agent_file.read_text(encoding='utf-8', errors='replace')
        except Exception:
            content = ''

        data = {
            'name': agent_file.stem,
            'file': str(agent_file),
            'raw': content,
            'description': '',
            'tools': [],
            'capabilities': [],
        }

        # Extract YAML frontmatter
        fm = self._parse_frontmatter(content)
        data['description'] = fm.get('description', '')
        tools_raw = fm.get('tools', '')
        if isinstance(tools_raw, list):
            data['tools'] = tools_raw
        elif isinstance(tools_raw, str):
            data['tools'] = re.findall(r"'([^']+)'|\"([^\"]+)\"", tools_raw)
            data['tools'] = [t[0] or t[1] for t in data['tools']]

        # Extract capability headers (## lines)
        data['capabilities'] = re.findall(r'^##\s+(.+)$', content, re.MULTILINE)

        return data

    def _parse_frontmatter(self, content: str) -> Dict:
        """Parse YAML frontmatter from markdown file."""
        fm = {}
        match = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if not match:
            return fm

        for line in match.group(1).splitlines():
            if ':' in line:
                key, _, value = line.partition(':')
                fm[key.strip()] = value.strip()

        return fm

    def _extract_mcp_tools(self, content: str) -> List[str]:
        """Extract MCP tool names from agent content."""
        tools = []
        # Pattern: automation_server/tool_name or similar
        matches = re.findall(r'automation_server/(\w+)', content)
        tools.extend(matches)
        # Pattern: --tool tool_name in mcp_client.py calls
        matches = re.findall(r'--tool\s+(\w+)', content)
        tools.extend(matches)
        return tools

    def _extract_api_patterns(self, content: str) -> List[str]:
        """Extract NITRO API endpoint patterns from agent content."""
        patterns = []
        # Find /nitro/v1/config/... or /nitro/v2/config/... patterns
        matches = re.findall(r'/nitro/v[12]/config/\S+', content)
        for m in matches:
            m = m.rstrip('`"\'')
            if m not in patterns:
                patterns.append(m)
        return patterns

    def get_test_plan(self, agents: Dict) -> str:
        """Extract test plan name for MAS 111.x from agents."""
        for name, agent in agents.items():
            content = agent.get('raw', '')
            match = re.search(r'CCLiveCertificate\w+TestPlan', content)
            if match:
                return match.group(0)
        return 'CCLiveCertificateManagementTestPlan'
