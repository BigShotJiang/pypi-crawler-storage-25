"""Health check system for MAS Automation."""
import json
import subprocess
import sys
from pathlib import Path
from typing import Tuple, Dict
import click
from .ai_generator import AIGenerator


class HealthChecker:
    """Performs health checks on MAS Automation setup.

    Tiers:
      CORE     (5) — must pass before running any test
      REQUIRED (3) — must pass before running automate (AI + automation_server + Atlassian)
      ADVISORY (1) — citrix-documentation: warning only, automate still proceeds
    """

    def __init__(self, executor, config):
        self.executor = executor
        self.config = config
        self._mcp_servers: Dict = {}
        self._load_mcp_config()

    def _load_mcp_config(self):
        """Read MCP server URLs from project .mcp.json."""
        mcp_json = self.executor.project_root / '.mcp.json'
        if mcp_json.exists():
            try:
                with open(mcp_json) as f:
                    data = json.load(f)
                self._mcp_servers = data.get('mcpServers', {})
            except Exception:
                self._mcp_servers = {}

    # -------------------------------------------------------------------------
    # Public entry point
    # -------------------------------------------------------------------------

    def run(self):
        """Run all health checks and print tiered summary."""
        click.secho('\nMAS Automation Health Check\n', fg='cyan', bold=True)

        # ---- CORE (5) -------------------------------------------------------
        click.secho('CORE checks (required for mas-cli test)', fg='white', bold=True)
        click.secho('-' * 50, fg='white')
        core_checks = [
            ('Framework Setup',    self._check_framework),
            ('Configuration Files', self._check_config_files),
            ('SDK Installation',   self._check_sdk),
            ('Helper Functions',   self._check_helper_funcs),
            ('External Tools',     self._check_external_tools),
        ]
        core_results = self._run_group(core_checks)

        # ---- REQUIRED for automate (3) ---------------------------------------
        click.secho('\nREQUIRED checks (must pass for mas-cli automate)', fg='white', bold=True)
        click.secho('-' * 50, fg='white')
        required_checks = [
            ('AI (Claude API)',    self._check_ai,               None),
            ('automation_server', self._check_automation_server, 'automation_server'),
            ('Atlassian MCP',     self._check_atlassian,         'Atlassian'),
        ]
        required_results = self._run_group(required_checks)

        # ---- ADVISORY (1) ---------------------------------------------------
        click.secho('\nADVISORY checks (warning only, automate still runs without)', fg='white', bold=True)
        click.secho('-' * 50, fg='white')
        advisory_checks = [
            ('citrix-documentation', self._check_citrix_docs, 'citrix-documentation'),
        ]
        advisory_results = self._run_group(advisory_checks, advisory=True)

        # ---- Summary --------------------------------------------------------
        self._print_summary(core_results, required_results, advisory_results)

    def _run_group(self, checks, advisory: bool = False):
        """Run a group of checks, print results, return list of (name, ok).

        Each entry is a 2-tuple (name, fn) or a 3-tuple (name, fn, server_key).
        server_key is accepted for forward-compatibility but not used here.
        """
        results = []
        for entry in checks:
            name, fn = entry[0], entry[1]
            click.secho(f'\n  >> {name}', fg='yellow')
            ok, message = fn()
            results.append((name, ok))
            if ok:
                click.echo(f'     {click.style("[PASS]", fg="green", bold=True)} {message}')
            elif advisory:
                click.echo(f'     {click.style("[WARN]", fg="yellow", bold=True)} {message}')
            else:
                click.echo(f'     {click.style("[FAIL]", fg="red", bold=True)} {message}')
        return results

    def _print_summary(self, core, required, advisory):
        click.echo()
        click.secho('=' * 55, fg='cyan')
        click.secho('  SUMMARY', fg='cyan', bold=True)
        click.secho('=' * 55, fg='cyan')

        core_pass = sum(1 for _, ok in core if ok)
        req_pass  = sum(1 for _, ok in required if ok)
        adv_pass  = sum(1 for _, ok in advisory if ok)

        core_ok = core_pass == len(core)
        req_ok  = req_pass == len(required)
        adv_ok  = adv_pass == len(advisory)

        def _bar(passed, total, color):
            s = click.style(f'{passed}/{total}', fg=color, bold=True)
            return s

        click.echo(f'\n  Core (test execution):  {_bar(core_pass, len(core), "green" if core_ok else "red")}')
        click.echo(f'  Required (automate):    {_bar(req_pass, len(required), "green" if req_ok else "red")}')
        click.echo(f'  Advisory (docs MCP):    {_bar(adv_pass, len(advisory), "green" if adv_ok else "yellow")}')
        click.echo()

        if core_ok and req_ok and adv_ok:
            click.secho('  [ALL OK] System fully ready — AI-powered automate enabled!', fg='green', bold=True)
            click.echo()
            click.secho('  mas-cli test 111.3.4.145       — run a specific test', fg='green')
            click.secho('  mas-cli automate 111.3         — AI generates + runs all TCs', fg='green')
            click.secho('  mas-cli automate 111.3 --dry-run  — preview only', fg='green')

        elif core_ok and req_ok:
            click.secho('  [OK] automate ready.', fg='green', bold=True)
            click.secho(f'  [WARN] citrix-documentation MCP offline — docs lookup unavailable.', fg='yellow')
            click.echo()
            click.secho('  mas-cli automate 111.3  (will run — docs lookup skipped)', fg='green')

        elif core_ok and not req_ok:
            click.secho('  [OK]     mas-cli test works.', fg='green', bold=True)
            click.secho('  [BLOCK]  mas-cli automate is BLOCKED — fix required checks:', fg='red', bold=True)
            for name, ok in required:
                if not ok:
                    icon = click.style('  x', fg='red', bold=True)
                    click.echo(f'{icon}  {name}')
            click.echo()
            click.secho('  Fix steps:', fg='yellow')
            for name, ok in required:
                if not ok:
                    if 'AI' in name:
                        click.echo('    mas-cli init  → configure Claude API credentials')
                    elif 'automation_server' in name:
                        click.echo('    Check VPN — automation_server at 10.146.91.151:8600 must be reachable')
                    elif 'Atlassian' in name:
                        click.echo('    Check network — Atlassian MCP at mcp.atlassian.com must be reachable')

        else:
            click.secho('  [FAIL] Core checks failed — fix before running any tests.', fg='red', bold=True)
            click.echo()
            click.echo('  Run: mas-cli init  (to reconfigure)')

        click.secho('\n' + '=' * 55 + '\n', fg='cyan')

    # -------------------------------------------------------------------------
    # CORE checks
    # -------------------------------------------------------------------------

    def _check_framework(self) -> Tuple[bool, str]:
        try:
            if not self.executor.asterix_script.exists():
                return False, f'asterix.py not found at {self.executor.asterix_script}'
            result = subprocess.run(
                [sys.executable, str(self.executor.asterix_script), '--help'],
                capture_output=True, timeout=5,
            )
            return result.returncode == 0, 'Framework accessible'
        except Exception as e:
            return False, f'Error: {e}'

    def _check_config_files(self) -> Tuple[bool, str]:
        try:
            setup_cfg = self.executor.project_root / 'config' / 'setup_config.cfg'
            ssl_cfg = self.config.ssl_cfg_file
            if not setup_cfg.exists():
                return False, f'setup_config.cfg missing at {setup_cfg}'
            if not ssl_cfg.exists():
                return False, f'ssl.cfg missing at {ssl_cfg}'
            return True, 'Config files present (setup_config.cfg, ssl.cfg)'
        except Exception as e:
            return False, f'Error: {e}'

    def _check_sdk(self) -> Tuple[bool, str]:
        try:
            sdk_path = self.config.get('sdk_path')
            if not sdk_path:
                return False, 'SDK path not configured'
            sys.path.insert(0, sdk_path)
            try:
                from massrc.com.citrix.mas.nitro.resource.config.ns.ns_ssl_key import ns_ssl_key
                return True, f'SDK installed at {sdk_path}'
            except ImportError as ie:
                return False, f'SDK import failed: {ie}'
        except Exception as e:
            return False, f'Error: {e}'

    def _check_helper_funcs(self) -> Tuple[bool, str]:
        try:
            import importlib.util
            modules_path = self.executor.project_root / 'modules'
            sys.path.insert(0, str(modules_path))
            issues = []

            try:
                import helperfuncs  # noqa: F401
            except ImportError as ie:
                issues.append(f'helperfuncs: {ie}')

            try:
                import logging_framework  # noqa: F401
            except ImportError as ie:
                issues.append(f'logging_framework: {ie}')

            if issues:
                return False, 'Module import failed: ' + '; '.join(issues)
            return True, 'helperfuncs and logging_framework accessible'
        except Exception as e:
            return False, f'Error: {e}'

    def _check_external_tools(self) -> Tuple[bool, str]:
        try:
            result = subprocess.run(['openssl', 'version'], capture_output=True, timeout=5)
            if result.returncode != 0:
                return False, 'openssl not found in PATH'
            return True, 'openssl available'
        except FileNotFoundError:
            return False, 'openssl not found in PATH'
        except Exception as e:
            return False, f'Error: {e}'

    # -------------------------------------------------------------------------
    # REQUIRED checks (block automate if any fail)
    # -------------------------------------------------------------------------

    def _check_ai(self) -> Tuple[bool, str]:
        """Check Claude AI connectivity (Vertex AI or Anthropic API key)."""
        ai = AIGenerator(self.executor.project_root, self.config)
        if not ai.is_configured():
            return False, 'Not configured — run: mas-cli init  to set Claude API credentials'
        return ai.check_connectivity()

    def _check_automation_server(self) -> Tuple[bool, str]:
        """Check automation_server (StarWars) MCP — required for TC discovery."""
        srv = self._mcp_servers.get('automation_server', {})
        url = srv.get('url', 'http://10.146.91.151:8600/sse')
        return self._ping_sse_with_retry('automation_server (StarWars)', url)

    def _check_atlassian(self) -> Tuple[bool, str]:
        """Check Atlassian MCP — required for test plan access."""
        srv = self._mcp_servers.get('Atlassian', {})
        url = srv.get('url', 'https://mcp.atlassian.com/v1/sse')
        return self._ping_sse_with_retry('Atlassian MCP', url)

    # -------------------------------------------------------------------------
    # ADVISORY check (citrix-documentation — warning only)
    # -------------------------------------------------------------------------

    def _check_citrix_docs(self) -> Tuple[bool, str]:
        """Check citrix-documentation MCP — advisory, automate proceeds without it."""
        srv = self._mcp_servers.get('citrix-documentation', {})
        url = srv.get('url', 'http://10.102.33.224:8000/sse')
        ok, msg = self._ping_sse_with_retry('citrix-documentation MCP', url)
        if not ok:
            return False, msg + ' (advisory — automate will skip doc lookups)'
        return True, msg

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _ping_sse_with_retry(label: str, url: str, retries: int = 3, delay: int = 2) -> Tuple[bool, str]:
        """Probe an SSE endpoint up to `retries` times, waiting `delay` seconds between attempts."""
        import requests as req_lib
        import time

        last_msg = ''
        for attempt in range(1, retries + 1):
            ok, last_msg = HealthChecker._ping_sse(label, url)
            if ok:
                return True, last_msg
            if attempt < retries:
                click.echo(f'     attempt {attempt}/{retries} failed — retrying in {delay}s...')
                time.sleep(delay)

        return False, f'{last_msg} (failed after {retries} attempts)'

    @staticmethod
    def _ping_sse(label: str, url: str) -> Tuple[bool, str]:
        """Single HTTP probe of an SSE endpoint — connect, check status, close immediately."""
        import requests as req_lib
        try:
            r = req_lib.get(url, timeout=6, stream=True,
                            headers={'Accept': 'text/event-stream'}, verify=False)
            r.close()
            # 200/202 — normal SSE response
            # 307/308 — redirect, server is up
            # 400/405 — server up, rejects plain GET (some SSE servers do this)
            # 401     — server up, requires OAuth (Atlassian cloud; Claude Code handles auth)
            if r.status_code in (200, 202, 307, 308, 400, 401, 405):
                note = ' (auth via Claude Code)' if r.status_code == 401 else ''
                return True, f'{label} reachable (HTTP {r.status_code}{note})'
            return False, f'{label} returned unexpected HTTP {r.status_code}'
        except req_lib.exceptions.ConnectionError:
            return False, f'{label} not reachable — connection refused (check VPN / network)'
        except req_lib.exceptions.Timeout:
            return False, f'{label} timed out — check VPN / network connectivity'
        except Exception as e:
            return False, f'{label}: {e}'
