"""Full automation orchestrator for mas-cli automate command."""
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .config import ConfigManager
from .infra_setup import InfraSetup
from .agent_reader import AgentReader
from .test_analyzer import TestAnalyzer, AnalysisResult, TCInfo
from .test_generator import TestGenerator
from .executor import TestExecutor
from .ai_generator import AIGenerator
from .health_check import HealthChecker


class MASOrchestrator:
    """
    Full automation orchestrator.

    mas-cli automate 111.3

    Steps:
      1. Interactive infra config + save to ssl.cfg
      2. Validate infra (MAS, VPX, SDK)
      3. Read agent files for knowledge
      4. Analyze test folder (count total / automated / pending)
      5. Generate/rewrite scripts for broken + pending TCs
      6. Execute all tests (existing + newly generated)
      7. Print comprehensive summary
    """

    GENERATED_STF = 'ssl_111_3_generated.stf'

    def __init__(self, project_root: Optional[str] = None):
        self.config = ConfigManager()
        self.project_root = Path(project_root) if project_root else self._detect_root()
        self.infra = InfraSetup(self.config)
        self.agent_reader = AgentReader(self.project_root)
        self.analyzer = TestAnalyzer(self.project_root)
        self.generator = TestGenerator(self.project_root, self.config)
        self.executor = TestExecutor(str(self.project_root))

    # -------------------------------------------------------------------------
    # Public entry point
    # -------------------------------------------------------------------------

    def run(self, folder_prefix: str, suite_name: str = 'SANITY_RTM',
            skip_generate: bool = False, dry_run: bool = False,
            skip_execute: bool = False):
        """Run full orchestration for a folder prefix."""
        start_time = time.time()

        print("\n" + "=" * 60)
        print(f"  MAS Automation Orchestrator")
        print(f"  Folder: {folder_prefix}")
        if dry_run:
            print("  Mode: DRY RUN (no changes will be made)")
        print("=" * 60)

        # ---- Preflight: verify required services (always — even dry-run) -----
        self._preflight_gate(advisory_only=dry_run)

        # ---- Step 1: Infrastructure Setup -----------------------------------
        cfg = self._step_infra_setup(folder_prefix, dry_run)

        # ---- Step 2: Validate Infrastructure --------------------------------
        infra_ok = self._step_validate_infra(cfg, dry_run)

        # ---- Step 3: Read Agents + Fetch StarWars TC list -------------------
        knowledge, starwars_tc_ids = self._step_read_agents_and_starwars(folder_prefix)

        # ---- Step 3.5: Folder Cleanup — move stale files to BACKUP -----------
        self._step_folder_cleanup(folder_prefix)

        # ---- Step 4: Analyze Existing Tests (disk + STF + StarWars) ---------
        analysis = self._step_analyze(folder_prefix, suite_name)

        # Extend pending with TCs that are in StarWars but have no local presence at all
        analysis = self._extend_pending_from_starwars(analysis, starwars_tc_ids)

        # ---- Step 5: Generate/Rewrite Tests ---------------------------------
        generated_tcs = []
        if not skip_generate:
            generated_tcs = self._step_generate(analysis, knowledge, suite_name, dry_run)
        else:
            print("\n[STEP 5] Skipping test generation (--skip-generate)")

        # ---- Step 6: Execute All Tests --------------------------------------
        exec_results = {}
        if not skip_execute and not dry_run:
            exec_results = self._step_execute(folder_prefix, suite_name)
        elif dry_run:
            print("\n[STEP 6] Skipping execution (dry run)")
        else:
            print("\n[STEP 6] Skipping execution (--skip-execute)")

        # ---- Step 7: Summary ------------------------------------------------
        elapsed = time.time() - start_time
        self._step_summary(
            folder_prefix, analysis, generated_tcs,
            exec_results, elapsed, infra_ok, dry_run,
            starwars_tc_ids)

    # -------------------------------------------------------------------------
    # Preflight gate — block automate if required services are down
    # -------------------------------------------------------------------------

    def _preflight_gate(self, advisory_only: bool = False):
        """Check AI + required MCP servers.

        advisory_only=True  — print warnings but never sys.exit (used in dry-run).
        advisory_only=False — exit immediately if any required service is down.
        """
        print("\n[PREFLIGHT] Checking required services...")

        issues = []
        warnings = []

        # Load MCP server URLs from .mcp.json
        mcp_servers = {}
        mcp_json = self.project_root / '.mcp.json'
        if mcp_json.exists():
            try:
                with open(mcp_json) as f:
                    mcp_servers = json.load(f).get('mcpServers', {})
            except Exception:
                pass

        # Check AI
        ai = AIGenerator(self.project_root, self.config)
        if not ai.is_configured():
            issues.append('AI not configured — run: mas-cli init  to set Claude API credentials')
        else:
            ok, msg = ai.check_connectivity()
            if not ok:
                issues.append(f'AI unreachable: {msg}')
            else:
                print(f'  [OK] AI: {msg}')

        # Check automation_server (required)
        srv = mcp_servers.get('automation_server', {})
        url = srv.get('url', 'http://10.146.91.151:8600/sse')
        ok, msg = HealthChecker._ping_sse_with_retry('automation_server (StarWars)', url)
        if ok:
            print(f'  [OK] {msg}')
        else:
            issues.append(msg + ' — check VPN / lab network')

        # Check Atlassian (required)
        srv = mcp_servers.get('Atlassian', {})
        url = srv.get('url', 'https://mcp.atlassian.com/v1/sse')
        ok, msg = HealthChecker._ping_sse_with_retry('Atlassian MCP', url)
        if ok:
            print(f'  [OK] {msg}')
        else:
            issues.append(msg + ' — check internet connectivity')

        # Check citrix-documentation (advisory)
        srv = mcp_servers.get('citrix-documentation', {})
        url = srv.get('url', 'http://10.102.33.224:8000/sse')
        ok, msg = HealthChecker._ping_sse_with_retry('citrix-documentation MCP', url)
        if ok:
            print(f'  [OK] {msg}')
        else:
            warnings.append(f'citrix-documentation offline — doc lookups will be skipped')

        # Print warnings
        for w in warnings:
            print(f'  [WARN] {w}')

        # Block if any required service is down (skip in advisory/dry-run mode)
        if issues:
            print('\n' + '=' * 60)
            if advisory_only:
                print('  [WARN] Some required services are not reachable (dry-run continues):')
                for issue in issues:
                    print(f'    !  {issue}')
            else:
                print('  [BLOCKED] mas-cli automate cannot start')
                print('  Required services are not available:')
                for issue in issues:
                    print(f'    x  {issue}')
                print()
                print('  Fix the above issues, then retry.')
                print('  Tip: run  mas-cli health-check  for detailed diagnostics.')
                print('=' * 60 + '\n')
                sys.exit(1)
            print('=' * 60 + '\n')
            return

        print('  [OK] All required services up — proceeding.\n')

    # -------------------------------------------------------------------------
    # Steps
    # -------------------------------------------------------------------------

    def _step_infra_setup(self, folder_prefix: str, dry_run: bool) -> Dict:
        """Step 1: Ask for infra config and save it."""
        print("\n[STEP 1] Infrastructure Configuration")
        print("-" * 40)

        existing = self.config.get_config_dict()
        has_config = self.config.is_initialized()

        if has_config:
            print(f"  Existing config found (MAS: {existing.get('mas_ip', 'unknown')})")
            if dry_run:
                print("  Using existing configuration (dry run).")
                return existing
            answer = input("  Use existing config? [Y/n]: ").strip().lower()
            if answer not in ('n', 'no'):
                print("  Using existing configuration.")
                return existing

        cfg = self.infra.interactive_setup(folder_prefix)
        if not dry_run:
            self.infra.save_config(cfg, self.project_root)
        return cfg

    def _step_validate_infra(self, cfg: Dict, dry_run: bool) -> bool:
        """Step 2: Validate all infra components are reachable."""
        print("\n[STEP 2] Infrastructure Validation")
        print("-" * 40)

        if dry_run:
            print("  Skipping validation (dry run)")
            return True

        return self.infra.validate_all(cfg)

    def _step_read_agents_and_starwars(self, folder_prefix: str) -> tuple:
        """Step 3: Read agent files, check AI, fetch full TC list from StarWars."""
        print("\n[STEP 3] Reading Agent Files + AI + StarWars TC Discovery")
        print("-" * 40)

        agents = self.agent_reader.load_all_agents()
        knowledge = self.agent_reader.extract_knowledge(agents)

        print(f"\n  Agent knowledge extracted:")
        print(f"    MCP tools available:  {len(knowledge['mcp_tools'])}")
        print(f"    API patterns found:   {len(knowledge['api_patterns'])}")
        print(f"    Test plan:            {knowledge['test_plan_name']}")
        if knowledge['mcp_tools']:
            print(f"    Tools: {', '.join(knowledge['mcp_tools'][:5])}"
                  + (" ..." if len(knowledge['mcp_tools']) > 5 else ""))

        # AI connectivity
        ai = AIGenerator(self.project_root, self.config)
        if ai.is_configured():
            ok, msg = ai.check_connectivity()
            print(f"\n  {'[OK]' if ok else '[WARN]'} AI: {msg}")
        else:
            print(f"\n  [WARN] AI not configured — template-based generation only")

        # Fetch complete TC list from StarWars automation_server
        print(f"\n  [StarWars] Fetching TC list for folder '{folder_prefix}'...")
        starwars_ids = []
        if ai.is_configured():
            starwars_ids = ai.fetch_folder_tc_list(folder_prefix)
            if starwars_ids:
                print(f"  [StarWars] Found {len(starwars_ids)} TC(s) in StarWars for '{folder_prefix}'")
            else:
                print(f"  [StarWars] No TCs returned — server may not have folder '{folder_prefix}'")
                print(f"             (analysis will fall back to local disk + STF)")
        else:
            print(f"  [StarWars] Skipped — AI not configured")
        # starwars_ids is list of dicts: [{'tc_id': str, 'description': str}]

        return knowledge, starwars_ids

    def _extend_pending_from_starwars(self, analysis: AnalysisResult,
                                       starwars_tc_ids: list) -> AnalysisResult:
        """Add TCs in StarWars that have no local MAS script (from both arrays).

        starwars_tc_ids: list of dicts with keys tc_id, description, is_automated
        """
        if not starwars_tc_ids:
            return analysis

        local_ids = {tc.tc_id for tc in analysis.tc_list}
        extra = []
        n_automated_missing = 0
        n_pending_missing = 0

        for item in starwars_tc_ids:
            tc_id = item['tc_id'] if isinstance(item, dict) else item
            description = item.get('description', '') if isinstance(item, dict) else ''
            is_automated = item.get('is_automated', True) if isinstance(item, dict) else True

            if tc_id in local_ids:
                continue

            filename = self._make_filename(tc_id, description)
            filepath = self.analyzer.testcases_dir / 'SSL' / 'SSL_cert' / filename
            extra.append(TCInfo(
                tc_id=tc_id,
                filename=filename,
                filepath=filepath,
                in_stf=False,
                has_broken_imports=False,
                description=description,
            ))
            if is_automated:
                n_automated_missing += 1
            else:
                n_pending_missing += 1

        if not extra:
            return analysis

        print(f"\n  [StarWars] {len(extra)} TC(s) have no local MAS script:")
        print(f"    {n_automated_missing} automated in StarWars — script exists elsewhere,"
              f" not yet in our MAS repo")
        print(f"    {n_pending_missing} not automated anywhere — first-time automation target")
        if len(extra) > 20:
            print(f"  [TIP] Large batch ({len(extra)} TCs). Use --skip-generate to"
                  f" analyse only, or --dry-run to preview without writing.")

        return AnalysisResult(
            folder_prefix=analysis.folder_prefix,
            total=analysis.total + len(extra),
            automated=analysis.automated,
            pending=analysis.pending + len(extra),
            broken=analysis.broken,
            tc_list=list(analysis.tc_list) + extra,
            automated_list=list(analysis.automated_list),
            pending_list=list(analysis.pending_list) + extra,
            broken_list=list(analysis.broken_list),
            stf_files=analysis.stf_files,
        )

    @staticmethod
    def _make_filename(tc_id: str, description: str) -> str:
        """Build a script filename from TC ID and StarWars description."""
        import re
        if description:
            slug = re.sub(r'[^a-z0-9]+', '_', description.lower())
            slug = slug.strip('_')[:55]
            return f'{tc_id}_{slug}.py'
        return f'{tc_id}.py'

    def _step_folder_cleanup(self, folder_prefix: str) -> int:
        """Move stale/legacy test files to a BACKUP/ subfolder.

        A file is stale if its name does not start with a numeric TC ID
        (e.g. 'add_cert_files.py', 'agent_*.py').  These are old paramiko /
        SSH-based scripts with no StarWars TC mapping — they cannot be run
        by the current asterix.py framework and block accurate coverage counts.

        Runs even in dry-run mode: cleanup is idempotent — once a file is in
        BACKUP/ it will never be touched again by subsequent runs.
        """
        import re as _re
        tc_id_prefix = _re.compile(r'^\d+\.\d+')
        testcases_root = self.analyzer.testcases_dir

        print("\n[STEP 3.5] Folder Cleanup — Moving Stale Files to BACKUP/")
        print("-" * 40)

        total_moved = 0
        checked_dirs = set()

        for search_dir in sorted(testcases_root.rglob('*')):
            if not search_dir.is_dir():
                continue
            if search_dir.name == 'BACKUP':
                continue
            if search_dir in checked_dirs:
                continue
            checked_dirs.add(search_dir)

            # Only clean dirs that actually contain files for this folder prefix
            has_relevant = any(
                f for f in search_dir.glob('*.py')
                if tc_id_prefix.match(f.name) and f.name.startswith(folder_prefix[:5])
            )
            if not has_relevant:
                continue

            stale = [
                f for f in sorted(search_dir.glob('*.py'))
                if not tc_id_prefix.match(f.name)
            ]
            if not stale:
                continue

            backup_dir = search_dir / 'BACKUP'
            backup_dir.mkdir(exist_ok=True)
            rel = search_dir.relative_to(self.project_root)
            print(f"\n  {rel}: {len(stale)} stale file(s) → BACKUP/")

            for f in stale:
                dest = backup_dir / f.name
                try:
                    f.rename(dest)
                    total_moved += 1
                    print(f"    moved: {f.name}")
                except Exception as e:
                    print(f"    [ERR] {f.name}: {e}")

        if total_moved == 0:
            print("  No stale files found — folder already clean.")
        else:
            print(f"\n  Total moved to BACKUP/: {total_moved} file(s)")
            print("  These files are preserved and can be restored from BACKUP/ if needed.")

        return total_moved

    def _step_analyze(self, folder_prefix: str, suite_name: str) -> AnalysisResult:
        """Step 4: Analyze test cases - count total/automated/broken/pending."""
        print("\n[STEP 4] Analyzing Test Cases")
        print("-" * 40)

        return self.analyzer.analyze(folder_prefix, suite_name)

    def _step_generate(self, analysis: AnalysisResult, knowledge: Dict,
                       suite_name: str, dry_run: bool) -> List[Tuple[str, bool]]:
        """Step 5: Generate/rewrite test scripts."""
        print("\n[STEP 5] Generating / Rewriting Test Scripts")
        print("-" * 40)

        all_results = []

        # Rewrite broken scripts first (they have files but broken imports)
        if analysis.broken_list:
            print(f"\n  Rewriting {len(analysis.broken_list)} broken script(s)...")
            broken_results = self.generator.generate_for_broken(
                analysis.broken_list, dry_run=dry_run)
            all_results.extend(broken_results)

            if not dry_run:
                # Register newly fixed scripts in STF
                fixed = [tc for tc in analysis.broken_list]
                if fixed:
                    self.generator.register_in_stf(fixed, suite_name, self.GENERATED_STF)

        # Generate for pending TCs (have files but not in any STF)
        if analysis.pending_list:
            print(f"\n  Processing {len(analysis.pending_list)} pending TC(s)...")
            pending_results = self.generator.generate_for_pending(
                analysis.pending_list, knowledge, dry_run=dry_run)
            all_results.extend(pending_results)

            if not dry_run:
                passed_pending = [tc for tc in analysis.pending_list]
                if passed_pending:
                    self.generator.register_in_stf(
                        passed_pending, suite_name, self.GENERATED_STF)

        success_count = sum(1 for _, ok in all_results if ok)
        print(f"\n  Generated/rewrote {success_count}/{len(all_results)} script(s)")

        return all_results

    def _step_execute(self, folder_prefix: str, suite_name: str) -> Dict:
        """Step 6: Execute all tests matching the folder prefix."""
        print("\n[STEP 6] Executing Tests")
        print("-" * 40)

        if not self.executor.validate_setup():
            print("  [WARN] Setup validation failed - attempting execution anyway")

        print(f"\n  Running tests for folder {folder_prefix}...")
        exit_code = self.executor.run_test(folder_prefix, suite_name)

        return {
            'exit_code': exit_code,
            'passed': exit_code == 0,
        }

    def _step_summary(self, folder_prefix: str, analysis: AnalysisResult,
                      generated: List[Tuple[str, bool]],
                      exec_results: Dict, elapsed: float,
                      infra_ok: bool, dry_run: bool,
                      starwars_tc_ids: List = None):
        """Step 7: Print comprehensive summary."""
        gen_count = len(generated)
        gen_ok = sum(1 for _, ok in generated if ok)
        starwars_tc_ids = starwars_tc_ids or []
        # starwars_tc_ids is list of dicts; len() gives total TC count from StarWars
        starwars_total = len(starwars_tc_ids)

        # Compute coverage numbers
        pre_run_automated = analysis.automated
        total_automated   = pre_run_automated + gen_ok
        local_total       = analysis.total
        # Use StarWars total as ground truth if available, else fall back to local
        ground_truth      = starwars_total if starwars_total else local_total

        print("\n")
        print("=" * 60)
        print("  AUTOMATION SUMMARY")
        print("=" * 60)
        print()
        print(f"  Folder:              {folder_prefix}")
        print(f"  Infrastructure:      {'OK' if infra_ok else 'PARTIAL (some checks failed)'}")
        print(f"  Mode:                {'DRY RUN' if dry_run else 'LIVE'}")
        print()

        # ---- StarWars TC count ----
        sw_automated = sum(1 for t in starwars_tc_ids
                           if isinstance(t, dict) and t.get('is_automated', True))
        sw_pending   = starwars_total - sw_automated

        print(f"  --- StarWars (Source of Truth) ---")
        if starwars_total:
            print(f"  Total TCs in folder:       {starwars_total}")
            print(f"    Automated in StarWars:   {sw_automated}"
                  f"  (have scripts in some system)")
            print(f"    Not automated anywhere:  {sw_pending}"
                  f"  (first-time automation targets)")
        else:
            print(f"  Total TCs in folder:       N/A (StarWars unreachable)")
        print()

        # ---- Local disk analysis ----
        print(f"  --- Local Analysis (disk + STF) ---")
        print(f"  Script files found:        {local_total}")
        print(f"  Automated (script + STF):  {pre_run_automated}")
        print(f"  Broken imports (fixable):  {analysis.broken}")
        print(f"  Missing scripts (pending): {analysis.pending}")
        print()

        # ---- This run ----
        if gen_count > 0:
            print(f"  --- This Run (mas-cli automate) ---")
            print(f"  Scripts generated:         {gen_ok}/{gen_count}")
            print(f"  Written to disk:           {'NO (dry run)' if dry_run else 'YES'}")
            print()

        # ---- Execution ----
        if exec_results:
            passed = exec_results.get('passed', False)
            print(f"  --- Execution Results ---")
            print(f"  Result:                    {'PASS' if passed else 'FAIL'}")
            print()

        # ---- Coverage ----
        print(f"  --- Coverage ---")
        if starwars_total == 0:
            print(f"  Coverage comparison skipped — StarWars unreachable or returned no TCs")
            print(f"  Local automated:           {pre_run_automated}/{local_total}")
        else:
            after_pct  = 100.0 * total_automated / ground_truth
            before_pct = 100.0 * pre_run_automated / ground_truth
            print(f"  Before this run:           {pre_run_automated}/{ground_truth} ({before_pct:.0f}%)")
            print(f"  After  this run:           {total_automated}/{ground_truth} ({after_pct:.0f}%)")
            print(f"  Added by mas-cli:          +{gen_ok} script(s)")
            remaining = ground_truth - total_automated
            print(f"  Still not automated:       {remaining}")
        print()

        mins = int(elapsed // 60)
        secs = int(elapsed % 60)
        print(f"  Total time:                {mins}m {secs}s")
        print()
        print("=" * 60)

        if not dry_run and gen_ok > 0:
            print(f"\n  Next: run 'mas-cli test {folder_prefix}' to execute all tests")

    def _detect_root(self) -> Path:
        """Detect project root same way executor does."""
        if 'MAS_AUTOMATION_ROOT' in os.environ:
            return Path(os.environ['MAS_AUTOMATION_ROOT'])

        for root in [Path.cwd(), Path.home() / 'mas-automation']:
            if (root / 'scripts' / 'asterix.py').exists():
                return root

        raise RuntimeError(
            'Cannot find project root. Set MAS_AUTOMATION_ROOT environment variable.')
