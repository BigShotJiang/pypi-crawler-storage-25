from pathlib import Path
from setuptools import setup, find_packages

long_description = (Path(__file__).parent / 'README.md').read_text(encoding='utf-8')

setup(
    name='mas-automation-cli',
    version='1.3.2',
    description='AI-powered test automation CLI for NetScaler Console (MAS/ADM)',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='NetScaler Team',
    packages=find_packages(),
    python_requires='>=3.8',
    install_requires=[
        'click>=8.0.0',
        'colorama>=0.4.4',
        'tabulate>=0.9.0',
        'requests>=2.20.0',
        'urllib3>=1.24.0',
        'paramiko>=2.7.0',
        'pexpect>=4.6.0',
        'ipaddr>=2.2.0',
        'setuptools>=40.0.0',
    ],
    extras_require={
        'ai': ['anthropic>=0.25.0'],
    },
    entry_points={
        'console_scripts': [
            'mas-cli=mas_cli.cli:main',
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Environment :: Console',
        'Intended Audience :: System Administrators',
        'Intended Audience :: Developers',
    ],
)
