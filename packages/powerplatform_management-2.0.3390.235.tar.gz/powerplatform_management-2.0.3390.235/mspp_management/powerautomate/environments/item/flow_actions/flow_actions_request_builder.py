from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from .....models.error_response import ErrorResponse
    from .flow_actions_get_response import FlowActionsGetResponse

class FlowActionsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /powerautomate/environments/{environmentId}/flowActions
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new FlowActionsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/powerautomate/environments/{environmentId}/flowActions?api-version={api%2Dversion}{&connector*,exact*,isTrigger*,parameterName*,parameterValue*,parentProcessStageId*,workflowId*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[FlowActionsRequestBuilderGetQueryParameters]] = None) -> Optional[FlowActionsGetResponse]:
        """
        Returns a list of flow actions.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[FlowActionsGetResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        from .....models.error_response import ErrorResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": ErrorResponse,
            "404": ErrorResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .flow_actions_get_response import FlowActionsGetResponse

        return await self.request_adapter.send_async(request_info, FlowActionsGetResponse, error_mapping)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[FlowActionsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Returns a list of flow actions.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> FlowActionsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: FlowActionsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return FlowActionsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class FlowActionsRequestBuilderGetQueryParameters():
        """
        Returns a list of flow actions.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            if original_name == "is_trigger":
                return "isTrigger"
            if original_name == "parameter_name":
                return "parameterName"
            if original_name == "parameter_value":
                return "parameterValue"
            if original_name == "parent_process_stage_id":
                return "parentProcessStageId"
            if original_name == "workflow_id":
                return "workflowId"
            if original_name == "connector":
                return "connector"
            if original_name == "exact":
                return "exact"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

        # The connector name.
        connector: Optional[str] = None

        # Use exact matching for parameterName and parameterValue.
        exact: Optional[bool] = None

        # Indicates if the action is a trigger. No filter if unset.
        is_trigger: Optional[bool] = None

        # A keyword to search within the parameter name field.
        parameter_name: Optional[str] = None

        # A keyword to search within the parameter value field.
        parameter_value: Optional[str] = None

        # The parent process stage ID.
        parent_process_stage_id: Optional[UUID] = None

        # The workflow ID.
        workflow_id: Optional[UUID] = None

    
    @dataclass
    class FlowActionsRequestBuilderGetRequestConfiguration(RequestConfiguration[FlowActionsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

