from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .tools_connections import ToolsConnections

@dataclass
class RunTestSetRequestBody(AdditionalDataHolder, Parsable):
    """
    Request body for triggering a maker evaluation test run.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The name of the evaluation run.
    evaluation_run_name: Optional[str] = None
    # The connection ID for the MCS connector that will be used to execute the evaluation run, or leave empty for anonymous run.
    mcs_connection_id: Optional[str] = None
    # Indicates whether the operation should run on a published bot instance. If set to false, the operation will run on a draft bot instance.
    run_on_published_bot: Optional[bool] = None
    # The tools connections that will be used to execute the evaluation run. This is a list of tools along with the corresponding user connections that should be used for each tool.
    tools_connections: Optional[list[ToolsConnections]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RunTestSetRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RunTestSetRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RunTestSetRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .tools_connections import ToolsConnections

        from .tools_connections import ToolsConnections

        fields: dict[str, Callable[[Any], None]] = {
            "evaluationRunName": lambda n : setattr(self, 'evaluation_run_name', n.get_str_value()),
            "mcsConnectionId": lambda n : setattr(self, 'mcs_connection_id', n.get_str_value()),
            "runOnPublishedBot": lambda n : setattr(self, 'run_on_published_bot', n.get_bool_value()),
            "toolsConnections": lambda n : setattr(self, 'tools_connections', n.get_collection_of_object_values(ToolsConnections)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("evaluationRunName", self.evaluation_run_name)
        writer.write_str_value("mcsConnectionId", self.mcs_connection_id)
        writer.write_bool_value("runOnPublishedBot", self.run_on_published_bot)
        writer.write_collection_of_object_values("toolsConnections", self.tools_connections)
        writer.write_additional_data_value(self.additional_data)
    

