"""Telemetry server for Autoboat at Virginia Tech."""

__all__ = ["HOME_DIR", "INSTANCE_DIR", "create_app", "shared_lock_manager"]

from pathlib import Path

from flask import Flask as _flask

from .lock_manager import LockManager
from .models import db

shared_lock_manager = LockManager()

home_directories: list[Path] = [d for d in Path("/home").iterdir() if d.is_dir()]
if len(home_directories) == 0:
    raise RuntimeError("No home directories found in /home. Expected at least one user directory.")

elif len(home_directories) == 1:
    HOME_DIR = home_directories[0]

else:
    HOME_DIR = Path.home()

INSTANCE_DIR = HOME_DIR / "telemetry_server" / "src" / "instance"

from autoboat_telemetry_server.routes import (  # noqa: E402
    AutopilotParametersEndpoint,
    BoatStatusEndpoint,
    InstanceManagerEndpoint,
    WaypointEndpoint,
)


def create_app() -> _flask:
    """
    Create and configure the Flask application instance.

    Returns
    -------
    Flask
        Configured Flask application instance.
    """

    app = _flask(__name__)

    config_path = INSTANCE_DIR / "config.py"
    app.config.from_pyfile(config_path)

    db.init_app(app)

    with app.app_context():
        db.create_all()

    app.register_blueprint(InstanceManagerEndpoint().blueprint)
    app.register_blueprint(AutopilotParametersEndpoint().blueprint)
    app.register_blueprint(BoatStatusEndpoint().blueprint)
    app.register_blueprint(WaypointEndpoint().blueprint)

    @app.route("/")
    def index() -> str:
        """
        Root route for the telemetry server.

        Returns
        -------
        str
            Confirmation message indicating which server is running.
        """

        return "This is the telemetry server. It is running!"

    return app
