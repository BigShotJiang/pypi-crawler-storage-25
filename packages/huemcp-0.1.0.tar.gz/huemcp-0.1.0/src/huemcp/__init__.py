"""MCP server for the Philips Hue CLIP v2 API."""
