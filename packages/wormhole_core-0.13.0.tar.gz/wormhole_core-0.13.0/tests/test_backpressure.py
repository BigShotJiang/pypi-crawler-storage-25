from __future__ import annotations

import pytest

from wormhole_core.backpressure import (
    BackpressureConfig,
    BackpressureMetrics,
    BackpressureStrategy,
)


def test_backpressure_config_validation() -> None:
    with pytest.raises(ValueError):
        BackpressureConfig(max_size=0)


def test_backpressure_metrics_utilization() -> None:
    metrics = BackpressureMetrics(current_size=5, max_size=10, drops_count=2)
    assert metrics.utilization == 0.5


def test_backpressure_strategy_values() -> None:
    assert BackpressureStrategy.BLOCK.value == "block"
    assert BackpressureStrategy.DROP_OLDEST.value == "drop_oldest"
    assert BackpressureStrategy.FAIL.value == "fail"
