from __future__ import annotations

import pytest

from wormhole_core.errors import NotFoundError, ValidationError
from wormhole_core.retry import RetryPolicy
from wormhole_core.schemas.tools import PermissionKind, ToolCapabilities, ToolDefinition
from wormhole_core.tools.registry import ToolRegistry
from wormhole_core.tools.schema import validate_tool_definition


def test_tool_registry_duplicate_registration() -> None:
    registry = ToolRegistry()
    tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
    registry.register(tool)
    with pytest.raises(ValidationError):
        registry.register(tool)


def test_tool_registry_missing_tool_errors() -> None:
    registry = ToolRegistry()
    with pytest.raises(NotFoundError):
        registry.get("missing")
    with pytest.raises(NotFoundError):
        registry.bind_handler("missing", "handler")
    with pytest.raises(NotFoundError):
        registry.get_handler_ref("missing")


def test_validate_tool_definition_requires_schema() -> None:
    tool = ToolDefinition.__new__(ToolDefinition)
    object.__setattr__(tool, "tool_id", "t1")
    object.__setattr__(tool, "name", "echo")
    object.__setattr__(tool, "schema", {})
    object.__setattr__(tool, "description", "")
    object.__setattr__(tool, "permission_kind", PermissionKind.USER_APPROVAL)
    object.__setattr__(tool, "enabled", True)
    object.__setattr__(tool, "capabilities", ToolCapabilities())
    object.__setattr__(tool, "default_retry_policy", None)
    with pytest.raises(ValidationError):
        validate_tool_definition(tool)


def test_tool_definition_requires_schema() -> None:
    with pytest.raises(ValidationError):
        ToolDefinition(tool_id="t1", name="echo", schema={})


def test_tool_definition_defaults_and_retry_policy() -> None:
    tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
    assert tool.capabilities.read_only is False
    assert tool.default_retry_policy is None

    with_retry = ToolDefinition(
        tool_id="t2",
        name="echo2",
        schema={"type": "object"},
        capabilities=ToolCapabilities(concurrency_safe=True),
        default_retry_policy=RetryPolicy(max_retries=1),
    )
    assert with_retry.default_retry_policy is not None
    assert with_retry.default_retry_policy.max_retries == 1
