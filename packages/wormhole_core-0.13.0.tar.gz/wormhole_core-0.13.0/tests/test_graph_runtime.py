"""Tests for graph runtime module."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, cast
from unittest.mock import AsyncMock, MagicMock

import pytest
from loopgraph.bus.eventbus import EventBus
from loopgraph.core.graph import Edge, Graph, Node
from loopgraph.core.types import NodeKind
from loopgraph.registry.function_registry import FunctionRegistry

from wormhole_core.errors import SchedulerError, WormholeError
from wormhole_core.graph.runtime import (
    SessionGraphRuntime,
    _find_cycle,
    _find_missing_handlers,
    _iter_edges,
    _iter_node_items,
)
from wormhole_core.storage.event_log_store import EventLogStore


def test_iter_node_items_with_dict() -> None:
    """Test _iter_node_items handles dict properly."""
    nodes = {"a": Node(id="a", kind=NodeKind.TASK, handler="h1")}
    result = list(_iter_node_items(nodes))
    assert result == [("a", nodes["a"])]


def test_iter_node_items_with_list() -> None:
    """Test _iter_node_items handles list of nodes."""

    @dataclass
    class MockNode:
        id: str
        kind: str
        handler: str

    nodes = [
        MockNode(id="n1", kind="task", handler="h1"),
        MockNode(id="n2", kind="task", handler="h2"),
    ]
    result = list(_iter_node_items(nodes))
    assert result == [("n1", nodes[0]), ("n2", nodes[1])]


def test_iter_node_items_with_list_no_id() -> None:
    """Test _iter_node_items handles list without id attribute."""
    nodes = [{"handler": "h1"}, {"handler": "h2"}]
    result = list(_iter_node_items(nodes))
    assert result == [("0", nodes[0]), ("1", nodes[1])]


def test_iter_node_items_with_none() -> None:
    """Test _iter_node_items handles None."""
    result = list(_iter_node_items(None))
    assert result == []


def test_iter_edges_with_dict() -> None:
    """Test _iter_edges handles dict properly."""
    edges = {"e1": Edge(id="e1", source="a", target="b")}
    result = list(_iter_edges(edges))
    assert result == [edges["e1"]]


def test_iter_edges_with_list() -> None:
    """Test _iter_edges handles list properly."""
    edges = [Edge(id="e1", source="a", target="b")]
    result = list(_iter_edges(edges))
    assert result == edges


def test_iter_edges_with_none() -> None:
    """Test _iter_edges handles None properly."""
    result = list(_iter_edges(None))
    assert result == []


def test_find_cycle_with_edge_missing_source_or_target() -> None:
    """Test _find_cycle handles edges with missing source/target."""

    @dataclass
    class MockGraph:
        nodes: dict[str, Node]
        edges: list[PartialEdge]

    @dataclass
    class PartialEdge:
        id: str
        source: str | None
        target: str | None

    graph = MockGraph(
        nodes={"a": Node(id="a", kind=NodeKind.TASK, handler="h")},
        edges=[
            PartialEdge(id="e1", source="a", target=None),
            PartialEdge(id="e2", source=None, target="a"),
        ],
    )
    result = _find_cycle(graph)
    assert result is None  # No cycle, edges are ignored


def test_find_cycle_normalizes_non_string_ids() -> None:
    """Test _find_cycle handles graphs with non-string node IDs."""

    @dataclass
    class MockGraph:
        nodes: dict[int, MockNode]
        edges: list[MockEdge]

    @dataclass
    class MockNode:
        id: int

    @dataclass
    class MockEdge:
        source: int
        target: int

    graph = MockGraph(
        nodes={
            1: MockNode(id=1),
            2: MockNode(id=2),
            3: MockNode(id=3),
        },
        edges=[
            MockEdge(source=1, target=2),
            MockEdge(source=2, target=3),
            MockEdge(source=3, target=1),
        ],
    )
    cycle = _find_cycle(graph)
    assert cycle is not None
    assert cycle[0] == cycle[-1]
    assert set(cycle[:-1]) == {"1", "2", "3"}


def test_find_missing_handlers_with_list_nodes() -> None:
    """Test _find_missing_handlers with non-dict nodes."""
    registry = FunctionRegistry()
    registry.register("h1", lambda x: x)

    @dataclass
    class MockNode:
        id: str
        handler: str

    @dataclass
    class MockGraph:
        nodes: list[MockNode]

    graph = MockGraph(
        nodes=[MockNode(id="n1", handler="h1"), MockNode(id="n2", handler="missing")]
    )
    result = _find_missing_handlers(graph, registry)
    assert result == ["missing"]


@pytest.mark.asyncio
async def test_runtime_event_log_append_failure(tmp_path: Any) -> None:
    """Test that event log append failure raises SchedulerError via on_error callback."""
    registry = FunctionRegistry()
    registry.register("start", lambda payload: payload)

    store = EventLogStore(tmp_path)

    # Make append fail by patching
    async def failing_append(entry: Any) -> Any:
        raise RuntimeError("disk full")

    store_any = cast(Any, store)
    store_any.append = failing_append

    runtime = SessionGraphRuntime(
        registry,
        event_log_store=store,
        session_id="s1",
    )

    graph = Graph(
        nodes={"start": Node(id="start", kind=NodeKind.TASK, handler="start")},
        edges={},
    )

    with pytest.raises(SchedulerError) as exc_info:
        await runtime.run(graph, graph_id="g1", payload={})
    assert "event listener failed" in str(exc_info.value)


@pytest.mark.asyncio
async def test_runtime_event_bus_subscribe_failure() -> None:
    """Test that event bus subscribe failure raises SchedulerError."""
    registry = FunctionRegistry()
    registry.register("start", lambda payload: payload)

    event_bus = MagicMock(spec=EventBus)
    event_bus.subscribe.side_effect = RuntimeError("bus error")

    store = MagicMock(spec=EventLogStore)

    runtime = SessionGraphRuntime(
        registry,
        event_bus=event_bus,
        event_log_store=store,
        session_id="s1",
    )

    graph = Graph(
        nodes={"start": Node(id="start", kind=NodeKind.TASK, handler="start")},
        edges={},
    )

    with pytest.raises(SchedulerError) as exc_info:
        await runtime.run(graph, graph_id="g1", payload={})
    assert "event bus subscription failed" in str(exc_info.value)


@pytest.mark.asyncio
async def test_runtime_scheduler_generic_exception() -> None:
    """Test that generic scheduler exception raises SchedulerError."""
    registry = FunctionRegistry()
    registry.register("start", lambda payload: payload)

    runtime = SessionGraphRuntime(registry)
    # Mock the scheduler to raise a generic exception
    runtime._scheduler = MagicMock()
    runtime._scheduler.run = AsyncMock(side_effect=ValueError("unexpected"))

    graph = Graph(
        nodes={"start": Node(id="start", kind=NodeKind.TASK, handler="start")},
        edges={},
    )

    with pytest.raises(SchedulerError) as exc_info:
        await runtime.run(graph, graph_id="g1", payload={})
    assert "scheduler execution failed" in str(exc_info.value)


@pytest.mark.asyncio
async def test_runtime_scheduler_wormhole_error() -> None:
    """Test that WormholeError from scheduler is re-raised."""
    registry = FunctionRegistry()
    registry.register("start", lambda payload: payload)

    runtime = SessionGraphRuntime(registry)
    # Mock the scheduler to raise WormholeError
    from wormhole_core.errors import ValidationError

    runtime._scheduler = MagicMock()
    runtime._scheduler.run = AsyncMock(side_effect=ValidationError("bad input", {}))

    graph = Graph(
        nodes={"start": Node(id="start", kind=NodeKind.TASK, handler="start")},
        edges={},
    )

    with pytest.raises(WormholeError):
        await runtime.run(graph, graph_id="g1", payload={})


@pytest.mark.asyncio
async def test_runtime_event_bus_unsubscribe_failure(tmp_path: Any) -> None:
    """Test that event bus unsubscribe failure raises SchedulerError when no run error."""
    registry = FunctionRegistry()
    registry.register("start", lambda payload: payload)

    event_bus = EventBus()
    store = EventLogStore(tmp_path)

    runtime = SessionGraphRuntime(
        registry,
        event_bus=event_bus,
        event_log_store=store,
        session_id="s1",
    )

    # Patch unsubscribe to fail
    def failing_unsubscribe(*args: Any, **kwargs: Any) -> Any:
        raise RuntimeError("unsubscribe failed")

    event_bus_any = cast(Any, event_bus)
    event_bus_any.unsubscribe = failing_unsubscribe

    graph = Graph(
        nodes={"start": Node(id="start", kind=NodeKind.TASK, handler="start")},
        edges={},
    )

    with pytest.raises(SchedulerError) as exc_info:
        await runtime.run(graph, graph_id="g1", payload={})
    assert "event bus unsubscribe failed" in str(exc_info.value)


@pytest.mark.asyncio
async def test_runtime_debug_fallback_listener_logs_node_events(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Test debug fallback listener logs node-level events when no store is configured."""
    registry = FunctionRegistry()
    registry.register("start", lambda payload: payload)
    runtime = SessionGraphRuntime(registry, event_log_store=None, session_id="s1")

    graph = Graph(
        nodes={"start": Node(id="start", kind=NodeKind.TASK, handler="start")},
        edges={},
    )

    with caplog.at_level(logging.DEBUG, logger="wormhole_core.graph.runtime"):
        await runtime.run(graph, graph_id="g1", payload={"ok": True})

    debug_records = [
        record for record in caplog.records if "loopgraph.node_event" in record.message
    ]
    assert debug_records
