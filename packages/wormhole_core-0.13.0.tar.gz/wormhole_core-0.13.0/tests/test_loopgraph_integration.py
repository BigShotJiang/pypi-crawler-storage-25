from __future__ import annotations

import asyncio
from typing import Any, cast

import pytest
from loopgraph.bus.eventbus import EventBus
from loopgraph.core.graph import Edge, Graph, Node
from loopgraph.core.types import NodeKind
from loopgraph.registry.function_registry import FunctionRegistry

from wormhole_core.errors import EngineError, GraphCycleError, HandlerNotFoundError
from wormhole_core.events.stream import CoreEventStream
from wormhole_core.events.types import EventType
from wormhole_core.graph.runtime import SessionGraphRuntime
from wormhole_core.loop.session_api import SessionManager
from wormhole_core.schemas.session import SessionConfig
from wormhole_core.schemas.tools import ToolDefinition
from wormhole_core.storage.event_log_store import EventLogStore


class _DemoAdapter:
    async def stream(self, payload: dict[str, Any]) -> dict[str, Any]:
        return {
            **payload,
            "text": "ok",
            "tool_calls": [],
            "finish_reason": "end_turn",
            "usage": {},
        }


@pytest.mark.asyncio
async def test_loopgraph_scheduler_emits_node_events() -> None:
    manager = SessionManager(model_adapter=_DemoAdapter())
    handle = await manager.start_session(SessionConfig())

    await manager.step_session(handle.session.session_id, input="hello")

    seen: list[EventType] = []

    async def collect() -> None:
        async for event in handle.stream:
            seen.append(event.type)
            if EventType.NODE_COMPLETED in seen:
                break

    await asyncio.wait_for(collect(), timeout=1)
    assert EventType.NODE_SCHEDULED in seen
    assert EventType.NODE_COMPLETED in seen


@pytest.mark.asyncio
async def test_loopgraph_event_log_store_captures_entries(tmp_path: Any) -> None:
    store = EventLogStore(tmp_path)
    manager = SessionManager(event_log_store=store, model_adapter=_DemoAdapter())
    handle = await manager.start_session(SessionConfig())

    await manager.step_session(handle.session.session_id, input="hello")

    entries = await store.load(handle.session.session_id)
    assert entries
    assert entries[0].session_id == handle.session.session_id


@pytest.mark.asyncio
async def test_runtime_rejects_graph_cycle() -> None:
    registry = FunctionRegistry()
    registry.register("a", lambda payload: payload)
    registry.register("b", lambda payload: payload)
    graph = Graph(
        nodes={
            "a": Node(id="a", kind=NodeKind.TASK, handler="a"),
            "b": Node(id="b", kind=NodeKind.TASK, handler="b"),
        },
        edges={
            "edge-a-b": Edge(id="edge-a-b", source="a", target="b"),
            "edge-b-a": Edge(id="edge-b-a", source="b", target="a"),
        },
    )
    runtime = SessionGraphRuntime(registry)
    with pytest.raises(GraphCycleError):
        await runtime.run(graph, graph_id="g-cycle", payload={})


@pytest.mark.asyncio
async def test_runtime_rejects_missing_handler() -> None:
    registry = FunctionRegistry()
    graph = Graph(
        nodes={
            "a": Node(id="a", kind=NodeKind.TASK, handler="missing"),
        },
        edges={},
    )
    runtime = SessionGraphRuntime(registry)
    with pytest.raises(HandlerNotFoundError):
        await runtime.run(graph, graph_id="g-missing", payload={})


def test_event_stream_bind_failure_raises_engine_error() -> None:
    class FailingBus:
        def subscribe(self: Any, *_args: Any, **_kwargs: Any) -> Any:
            raise RuntimeError("disconnect")

        def unsubscribe(self: Any, *_args: Any, **_kwargs: Any) -> Any:
            raise RuntimeError("disconnect")

    stream = CoreEventStream()
    with pytest.raises(EngineError):
        stream.bind_event_bus(cast(EventBus, FailingBus()), "s1")


@pytest.mark.asyncio
async def test_model_adapter_tool_flow() -> None:
    class DemoAdapter:
        def __init__(self: Any) -> None:
            self.calls: list[dict[str, Any]] = []

        async def stream(self: Any, payload: dict[str, Any]) -> dict[str, Any]:
            self.calls.append(payload)
            return {
                **payload,
                "tool_calls": [
                    {
                        "tool_call_id": "call-1",
                        "tool_name": "echo",
                        "arguments": {"text": "hello"},
                    }
                ],
                "finish_reason": "end_turn",
                "usage": {},
            }

    adapter = DemoAdapter()
    manager = SessionManager(model_adapter=adapter)
    handle = await manager.start_session(SessionConfig(allowlisted_tools=["echo"]))

    tool_called: list[dict[str, Any]] = []

    async def echo_handler(payload: dict[str, Any]) -> dict[str, Any]:
        tool_called.append(payload)
        return {"ok": True, "payload": payload}

    await manager.register_tool(
        handle.session.session_id,
        ToolDefinition(tool_id="echo", name="echo", schema={"type": "object"}),
        handler=echo_handler,
    )
    manager._sessions[handle.session.session_id].loop_context["continuation_mode"] = (
        "manual"
    )

    await manager.step_session(
        handle.session.session_id,
        input="hello",
    )

    # Model adapter should have been called once for the step
    assert len(adapter.calls) == 1
    assert adapter.calls[0]["input"] == "hello"
    assert adapter.calls[0]["input"] == "hello"
    assert tool_called
