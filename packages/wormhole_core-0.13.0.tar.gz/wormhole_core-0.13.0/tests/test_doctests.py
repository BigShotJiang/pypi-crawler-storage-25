"""Execute doctest suites for the wormhole_core package."""

from __future__ import annotations

import doctest

import wormhole_core
import wormhole_core.backpressure as backpressure_module
import wormhole_core.config as config_module
import wormhole_core.errors as errors_module
import wormhole_core.events.stream as stream_module
import wormhole_core.events.transform as transform_module
import wormhole_core.events.types as events_module
import wormhole_core.graph.builder as graph_builder_module
import wormhole_core.graph.function_registry as graph_registry_module
import wormhole_core.graph.requirements as graph_requirements_module
import wormhole_core.graph.runtime as graph_runtime_module
import wormhole_core.hooks as hooks_module
import wormhole_core.hooks.registry as hooks_registry_module
import wormhole_core.hooks.types as hooks_types_module
import wormhole_core.logging as logging_module
import wormhole_core.loop.compaction as compaction_module
import wormhole_core.loop.resume as resume_module
import wormhole_core.loop.session_api as session_api_module
import wormhole_core.retry as retry_module
import wormhole_core.schemas.messages as messages_module
import wormhole_core.schemas.session as session_module
import wormhole_core.schemas.tools as tools_module
import wormhole_core.storage.compaction_store as compaction_store_module
import wormhole_core.storage.execution_state_store as execution_state_store_module
import wormhole_core.storage.session_store as session_store_module
import wormhole_core.tools.permissions as permissions_module
import wormhole_core.tools.registry as registry_module
import wormhole_core.tools.schema as schema_module


def test_doctests() -> None:
    modules = [
        wormhole_core,
        backpressure_module,
        config_module,
        errors_module,
        stream_module,
        transform_module,
        events_module,
        graph_builder_module,
        graph_registry_module,
        graph_requirements_module,
        graph_runtime_module,
        hooks_module,
        hooks_registry_module,
        hooks_types_module,
        logging_module,
        compaction_module,
        resume_module,
        session_api_module,
        retry_module,
        messages_module,
        session_module,
        tools_module,
        compaction_store_module,
        execution_state_store_module,
        session_store_module,
        permissions_module,
        registry_module,
        schema_module,
    ]
    for module in modules:
        result = doctest.testmod(module, optionflags=doctest.ELLIPSIS)
        assert result.failed == 0
