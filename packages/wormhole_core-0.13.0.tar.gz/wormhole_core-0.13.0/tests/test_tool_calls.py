from __future__ import annotations

from typing import Any

import pytest

from wormhole_core.graph.function_registry import SessionFunctionRegistry
from wormhole_core.loop.session_api import SessionManager
from wormhole_core.schemas.session import SessionConfig
from wormhole_core.schemas.tools import ToolCallStatus, ToolDefinition
from wormhole_core.tools.registry import ToolRegistry


def test_tool_call_creation_sets_pending_status() -> None:
    registry = ToolRegistry()
    tool = ToolDefinition(
        tool_id="t1",
        name="echo",
        schema={"type": "object"},
    )
    registry.register(tool)
    call = registry.create_call(tool_id="t1", arguments={"value": 1})
    assert call.status == ToolCallStatus.PENDING


@pytest.mark.asyncio
async def test_register_tool_binds_function_registry() -> None:
    registry = ToolRegistry()
    manager = SessionManager(tool_registry=registry)
    handle = await manager.start_session(SessionConfig())
    tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})

    async def handler(payload: dict[str, Any]) -> dict[str, Any]:
        return {"ok": True, "payload": payload}

    await manager.register_tool(handle.session.session_id, tool, handler)
    runtime = manager._sessions[handle.session.session_id]
    result = await runtime.registry.execute("tool:t1", {"value": 1})
    assert result["ok"] is True


@pytest.mark.asyncio
async def test_session_function_registry_get_and_execute() -> None:
    registry = SessionFunctionRegistry()

    async def handler(payload: dict[str, Any]) -> dict[str, Any]:
        return {"echo": payload}

    registry.register("echo", handler)
    assert registry.get("echo") is handler
    result = await registry.execute("echo", {"value": 7})
    assert result["echo"]["value"] == 7
