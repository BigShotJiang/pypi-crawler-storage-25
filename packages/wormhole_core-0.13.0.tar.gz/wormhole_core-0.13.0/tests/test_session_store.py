from __future__ import annotations

import time
from typing import Any

import pytest

from wormhole_core.errors import NotFoundError, PersistenceError
from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
from wormhole_core.schemas.session import (
    ContinuationMode,
    ExecutionState,
    FinishReason,
    Session,
    SessionConfig,
    SessionStatus,
)
from wormhole_core.storage.session_store import SessionRecord, SessionStore, _file_lock


def test_session_store_roundtrip_with_state_and_messages(tmp_path: Any) -> None:
    store = SessionStore(tmp_path)
    now = time.time()
    session = Session(
        session_id="s1",
        status=SessionStatus.RUNNING,
        created_at=now,
        updated_at=now,
        retention_expires_at=None,
        graph_id="graph-1",
        execution_state_id="exec-1",
    )
    config = SessionConfig(
        retention_days=5, compaction_ratio=0.5, max_concurrent_tools=2
    )
    state = ExecutionState(
        session_id="s1",
        step_index=2,
        next_speaker="assistant",
        pending_tool_calls=["t1"],
        last_finish_reason=FinishReason.TOOL_USE,
        continuation_mode=ContinuationMode.FORCE_STOP,
        last_error="boom",
    )
    part = Part(id="p1", type=PartType.TEXT, payload="hi", metadata={"role": "system"})
    message = Message(id="m1", role=MessageRole.USER, parts=[part], created_at=now)
    record = SessionRecord(
        session=session,
        config=config,
        state=state,
        messages=[message],
        compaction_snapshot_id="snap-1",
    )

    store._sync_save(record)
    loaded = store._sync_load("s1")

    assert loaded.state is not None
    assert loaded.state.last_finish_reason is FinishReason.TOOL_USE
    assert loaded.state.continuation_mode is ContinuationMode.FORCE_STOP
    assert loaded.messages[0].parts[0].metadata["role"] == "system"


def test_session_store_missing_session_raises(tmp_path: Any) -> None:
    store = SessionStore(tmp_path)
    with pytest.raises(NotFoundError):
        store._sync_load("missing")


def test_file_lock_retries_and_fails(tmp_path: Any, monkeypatch: Any) -> None:
    lock_path = tmp_path / "session.lock"

    def _always_fail(*_args: Any, **_kwargs: Any) -> Any:
        raise FileExistsError

    monkeypatch.setattr("wormhole_core.storage.session_store.os.open", _always_fail)
    with pytest.raises(PersistenceError):
        with _file_lock(lock_path, timeout_s=0.0, retries=0, poll_interval_s=0.0):
            pass
