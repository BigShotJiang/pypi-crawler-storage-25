from __future__ import annotations

from typing import Any, cast

from loopgraph.bus.eventbus import Event
from loopgraph.core.types import EventType as LoopgraphEventType
from loopgraph.core.types import NodeStatus

from wormhole_core.events.transform import transform_event
from wormhole_core.events.types import EventType


def test_transform_event_maps_core_fields() -> None:
    evt = Event(
        id="evt-1",
        graph_id="g1",
        node_id="n1",
        type=LoopgraphEventType.NODE_COMPLETED,
        payload={"ok": True},
        status=NodeStatus.COMPLETED,
    )
    core_event = transform_event(evt, session_id="s1")
    assert core_event.type is EventType.NODE_COMPLETED
    assert core_event.event_id == "evt-1"
    assert core_event.node_id == "n1"
    assert core_event.payload["graph_id"] == "g1"


def test_transform_event_unknown_type_falls_back() -> None:
    class DummyEvent:
        def __init__(self: Any) -> None:
            self.id = "evt-2"
            self.graph_id = "g2"
            self.node_id = None
            self.type = object()
            self.payload = {"ok": False}
            self.status = None
            self.visit_count = 0
            self.replay = False

    core_event = transform_event(cast(Event, DummyEvent()), session_id="s2")
    assert core_event.type is EventType.SESSION_STEP
