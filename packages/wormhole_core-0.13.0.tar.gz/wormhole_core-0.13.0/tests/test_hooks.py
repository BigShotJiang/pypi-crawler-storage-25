from __future__ import annotations

from typing import cast

import pytest

from wormhole_core.hooks.registry import HookRegistry
from wormhole_core.hooks.types import HookCallback, HookContext, HookPoint, HookResult


@pytest.mark.asyncio
async def test_hook_registry_invokes_in_order() -> None:
    registry = HookRegistry()
    calls: list[str] = []

    def first(ctx: HookContext) -> HookResult:
        calls.append("first")
        return HookResult(proceed=True)

    def second(ctx: HookContext) -> HookResult:
        calls.append("second")
        return HookResult(proceed=True)

    registry.register(HookPoint.TOOL_GATE, cast(HookCallback, first), hook_id="h1")
    registry.register(HookPoint.TOOL_GATE, cast(HookCallback, second), hook_id="h2")

    await registry.invoke(
        HookPoint.TOOL_GATE,
        HookContext(
            session_id="s1", hook_point=HookPoint.TOOL_GATE, payload={}, timestamp=0.0
        ),
    )

    assert calls == ["first", "second"]


@pytest.mark.asyncio
async def test_hook_registry_disable_and_enable() -> None:
    registry = HookRegistry()
    calls: list[str] = []

    def hook(ctx: HookContext) -> HookResult:
        calls.append("hit")
        return HookResult(proceed=True)

    registry.register(
        HookPoint.PROMPT_TRANSFORM, cast(HookCallback, hook), hook_id="h1"
    )
    assert registry.disable("h1") is True

    await registry.invoke(
        HookPoint.PROMPT_TRANSFORM,
        HookContext(
            session_id="s1",
            hook_point=HookPoint.PROMPT_TRANSFORM,
            payload={},
            timestamp=0.0,
        ),
    )
    assert calls == []

    assert registry.enable("h1") is True
    await registry.invoke(
        HookPoint.PROMPT_TRANSFORM,
        HookContext(
            session_id="s1",
            hook_point=HookPoint.PROMPT_TRANSFORM,
            payload={},
            timestamp=0.0,
        ),
    )
    assert calls == ["hit"]


@pytest.mark.asyncio
async def test_hook_registry_supports_async_callbacks() -> None:
    registry = HookRegistry()
    calls: list[str] = []

    async def async_hook(ctx: HookContext) -> HookResult:
        calls.append("async")
        return HookResult(proceed=True)

    registry.register(HookPoint.TELEMETRY, cast(HookCallback, async_hook), hook_id="h1")
    await registry.invoke(
        HookPoint.TELEMETRY,
        HookContext(
            session_id="s1", hook_point=HookPoint.TELEMETRY, payload={}, timestamp=0.0
        ),
    )
    assert calls == ["async"]


@pytest.mark.asyncio
async def test_hook_registry_isolates_failures() -> None:
    registry = HookRegistry()
    calls: list[str] = []

    def fail(_ctx: HookContext) -> HookResult:
        raise ValueError("boom")

    def succeed(_ctx: HookContext) -> HookResult:
        calls.append("ok")
        return HookResult(proceed=True)

    registry.register(HookPoint.TOOL_GATE, cast(HookCallback, fail), hook_id="bad")
    registry.register(HookPoint.TOOL_GATE, cast(HookCallback, succeed), hook_id="good")

    await registry.invoke(
        HookPoint.TOOL_GATE,
        HookContext(
            session_id="s1", hook_point=HookPoint.TOOL_GATE, payload={}, timestamp=0.0
        ),
    )

    assert calls == ["ok"]
