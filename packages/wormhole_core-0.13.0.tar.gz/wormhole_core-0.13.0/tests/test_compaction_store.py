from __future__ import annotations

from typing import Any

from wormhole_core.schemas.session import CompactionSnapshot, CompactionStage
from wormhole_core.storage.compaction_store import (
    CompactionStore,
    _snapshot_from_dict,
)


def test_compaction_store_roundtrip(tmp_path: Any) -> None:
    snapshot = CompactionSnapshot(
        snapshot_id="snap-1",
        session_id="s1",
        created_at=123.0,
        kept_files=["a.txt"],
        source_message_range=(1, 2),
        stage=CompactionStage.COMPLETED,
        pruned_message_count=3,
        pruned_token_estimate=42,
        compaction_message_id="msg-1",
    )
    store = CompactionStore(tmp_path)
    store._sync_save(snapshot)
    loaded = store._sync_load("snap-1")
    assert loaded == snapshot


def test_snapshot_from_dict_coercion() -> None:
    data: dict[str, object] = {
        "snapshot_id": 123,
        "session_id": 456,
        "created_at": "125.5",
        "kept_files": ("a", 2),
        "source_message_range": ["1", "2"],
        "stage": "completed",
        "pruned_message_count": "5",
        "pruned_token_estimate": "10",
        "compaction_message_id": "msg-1",
    }
    snapshot = _snapshot_from_dict(data)
    assert snapshot.snapshot_id == "123"
    assert snapshot.session_id == "456"
    assert snapshot.created_at == 125.5
    assert snapshot.kept_files == ["a", "2"]
    assert snapshot.source_message_range == (1, 2)
    assert snapshot.stage is CompactionStage.COMPLETED
    assert snapshot.pruned_message_count == 5
    assert snapshot.pruned_token_estimate == 10
    assert snapshot.compaction_message_id == "msg-1"


def test_snapshot_from_dict_invalid_values() -> None:
    data: dict[str, object] = {
        "snapshot_id": "snap",
        "session_id": "s1",
        "created_at": "not-a-number",
        "kept_files": "not-a-list",
        "source_message_range": ["a", "b"],
        "stage": "unknown",
        "pruned_message_count": "oops",
        "pruned_token_estimate": -5,
        "compaction_message_id": "",
    }
    snapshot = _snapshot_from_dict(data)
    assert isinstance(snapshot.created_at, float)
    assert snapshot.kept_files == []
    assert snapshot.source_message_range is None
    assert snapshot.stage is CompactionStage.PENDING
    assert snapshot.pruned_message_count == 0
    assert snapshot.pruned_token_estimate == 0
    assert snapshot.compaction_message_id is None


def test_snapshot_from_dict_defaults_for_unknown_types() -> None:
    data: dict[str, object] = {
        "snapshot_id": "snap",
        "session_id": "s1",
        "created_at": None,
        "kept_files": 123,
        "source_message_range": [1],
        "stage": None,
        "pruned_message_count": None,
        "pruned_token_estimate": None,
        "compaction_message_id": None,
    }
    snapshot = _snapshot_from_dict(data)
    assert isinstance(snapshot.created_at, float)
    assert snapshot.kept_files == []
    assert snapshot.source_message_range is None
    assert snapshot.stage is CompactionStage.PENDING
    assert snapshot.pruned_message_count == 0
    assert snapshot.pruned_token_estimate == 0
    assert snapshot.compaction_message_id is None
