from __future__ import annotations

import pytest

from wormhole_core.errors import ValidationError
from wormhole_core.schemas.session import SessionConfig
from wormhole_core.schemas.tools import ToolDefinition
from wormhole_core.tools.permissions import is_tool_allowed
from wormhole_core.tools.schema import validate_tool_definition


def test_tool_schema_validation() -> None:
    tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
    validate_tool_definition(tool)
    with pytest.raises(ValidationError):
        ToolDefinition(tool_id="t2", name="", schema={})


def test_tool_allowlist_gating() -> None:
    tool = ToolDefinition(
        tool_id="t1",
        name="echo",
        schema={"type": "object"},
    )
    config = SessionConfig(allowlisted_tools=["echo"])
    assert is_tool_allowed(tool, config) is True
    assert is_tool_allowed(tool, SessionConfig(allowlisted_tools=["other"])) is False
