from __future__ import annotations

from wormhole_core.loop.compaction import should_compact
from wormhole_core.schemas.session import (
    CompactionConfig,
    Session,
    SessionStatus,
)
from wormhole_core.storage.session_store import (
    calculate_retention_expiry,
    is_retention_expired,
)


def test_retention_expiry() -> None:
    now = 1000.0
    expiry = calculate_retention_expiry(now, retention_days=1)
    assert expiry == now + 86400
    session = Session(
        session_id="s1",
        status=SessionStatus.RUNNING,
        created_at=now,
        updated_at=now,
        retention_expires_at=expiry,
    )
    assert is_retention_expired(session, now + 10) is False
    assert is_retention_expired(session, now + 86401) is True


def test_compaction_ratio() -> None:
    config = CompactionConfig(trigger_threshold=0.7)
    assert should_compact(0.5, config) is False
    assert should_compact(0.7, config) is True
    config = CompactionConfig(trigger_threshold=0.7, auto_enabled=False)
    assert should_compact(0.9, config) is False


def test_retention_expiry_none() -> None:
    session = Session(
        session_id="s1", status=SessionStatus.RUNNING, retention_expires_at=None
    )
    assert is_retention_expired(session, 100.0) is False
