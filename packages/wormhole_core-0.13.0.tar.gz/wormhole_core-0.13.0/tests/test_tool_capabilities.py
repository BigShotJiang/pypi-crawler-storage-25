from __future__ import annotations

import math

import pytest

from wormhole_core.errors import ValidationError
from wormhole_core.schemas.tools import ToolCapabilities, ToolDefinition
from wormhole_core.tools.schema import validate_tool_definition


def test_tool_capabilities_validation_accepts_defaults() -> None:
    tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
    validate_tool_definition(tool)


def test_tool_capabilities_validation_rejects_non_bool() -> None:
    tool = ToolDefinition(
        tool_id="t1",
        name="echo",
        schema={"type": "object"},
        capabilities=ToolCapabilities(read_only="yes"),  # type: ignore[arg-type]
    )
    with pytest.raises(ValidationError):
        validate_tool_definition(tool)


def test_tool_capabilities_accepts_positive_timeout() -> None:
    """Positive execution_timeout_seconds should be accepted."""
    tool = ToolDefinition(
        tool_id="t1",
        name="echo",
        schema={"type": "object"},
        capabilities=ToolCapabilities(execution_timeout_seconds=30.0),
    )
    validate_tool_definition(tool)


def test_tool_capabilities_accepts_none_timeout() -> None:
    """None execution_timeout_seconds should be accepted (inherit from session)."""
    tool = ToolDefinition(
        tool_id="t1",
        name="echo",
        schema={"type": "object"},
        capabilities=ToolCapabilities(execution_timeout_seconds=None),
    )
    validate_tool_definition(tool)


def test_tool_capabilities_accepts_inf_timeout() -> None:
    """math.inf execution_timeout_seconds should be accepted (explicit no-timeout)."""
    tool = ToolDefinition(
        tool_id="t1",
        name="echo",
        schema={"type": "object"},
        capabilities=ToolCapabilities(execution_timeout_seconds=math.inf),
    )
    validate_tool_definition(tool)


def test_tool_capabilities_rejects_zero_timeout() -> None:
    """Zero execution_timeout_seconds should be rejected."""
    tool = ToolDefinition(
        tool_id="t1",
        name="echo",
        schema={"type": "object"},
        capabilities=ToolCapabilities(execution_timeout_seconds=0),
    )
    with pytest.raises(ValidationError, match="execution_timeout_seconds must be > 0"):
        validate_tool_definition(tool)


def test_tool_capabilities_rejects_negative_timeout() -> None:
    """Negative execution_timeout_seconds should be rejected."""
    tool = ToolDefinition(
        tool_id="t1",
        name="echo",
        schema={"type": "object"},
        capabilities=ToolCapabilities(execution_timeout_seconds=-1.0),
    )
    with pytest.raises(ValidationError, match="execution_timeout_seconds must be > 0"):
        validate_tool_definition(tool)
