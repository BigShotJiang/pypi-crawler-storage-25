from __future__ import annotations

from wormhole_core.errors import (
    ApprovalDeniedError,
    ApprovalPersistenceError,
    ApprovalTimeoutError,
    BackpressureError,
    CapabilityViolationError,
    ConfigError,
    DuplicateToolError,
    EngineError,
    ErrorCode,
    GraphCycleError,
    HandlerNotFoundError,
    HookError,
    LoopgraphError,
    NotFoundError,
    PermissionDeniedError,
    PersistenceError,
    RetryExhaustedError,
    SchedulerError,
    SessionExpiredError,
    SnapshotError,
    SnapshotVersionError,
    ToolExecutionTimeoutError,
    ToolSchemaError,
    ValidationError,
    WormholeError,
)


def test_wormhole_error_string_and_dict() -> None:
    err = WormholeError(ErrorCode.NOT_FOUND, "missing", {"id": "s1"})
    assert str(err) == "WH-CORE-003: missing"
    payload = err.to_dict()
    assert payload["code"] == "WH-CORE-003"
    assert payload["context"] == {"id": "s1"}
    assert err.retryable is False
    assert err.is_retryable() is False


def test_error_subclasses_codes() -> None:
    assert ValidationError("bad").code is ErrorCode.VALIDATION_ERROR
    assert PermissionDeniedError("nope").code is ErrorCode.PERMISSION_DENIED
    assert NotFoundError("missing").code is ErrorCode.NOT_FOUND
    assert SessionExpiredError("expired").code is ErrorCode.SESSION_EXPIRED
    assert PersistenceError("persist").code is ErrorCode.PERSISTENCE_ERROR
    assert EngineError("engine").code is ErrorCode.ENGINE_ERROR
    assert ConfigError("config").code is ErrorCode.CONFIG_ERROR


def test_loopgraph_error_codes() -> None:
    assert LoopgraphError("missing").code is ErrorCode.LOOPGRAPH_UNAVAILABLE
    assert SchedulerError("scheduler").code is ErrorCode.SCHEDULER_ERROR
    assert SnapshotError("snapshot").code is ErrorCode.SNAPSHOT_ERROR
    assert HandlerNotFoundError("handler").code is ErrorCode.HANDLER_NOT_FOUND
    assert GraphCycleError("cycle").code is ErrorCode.GRAPH_CYCLE
    assert SnapshotVersionError("version").code is ErrorCode.SNAPSHOT_VERSION
    assert DuplicateToolError("tool").code is ErrorCode.DUPLICATE_TOOL
    assert ToolSchemaError("schema").code is ErrorCode.TOOL_SCHEMA_ERROR


def test_contract_error_codes() -> None:
    assert (
        HookError("hook failed", hook_id="h1", hook_point="tool_gate").code
        is ErrorCode.HOOK_ERROR
    )
    assert BackpressureError(
        "queue full", metrics={"current_size": 3, "max_size": 5, "drops_count": 1}
    ).code is (ErrorCode.BACKPRESSURE_ERROR)
    assert (
        CapabilityViolationError(
            "capability violated",
            tool_id="t1",
            capability="concurrency_safe",
            violation="exclusive",
        ).code
        is ErrorCode.CAPABILITY_VIOLATION
    )
    assert (
        ApprovalDeniedError("denied", approval_id="a1", tool_id="t1").code
        is ErrorCode.APPROVAL_DENIED
    )
    assert ApprovalTimeoutError(
        "timeout", approval_id="a1", tool_id="t1", timeout=30.0
    ).code is (ErrorCode.APPROVAL_TIMEOUT)
    assert ApprovalPersistenceError("persist", approval_id="a1", retries=3).code is (
        ErrorCode.APPROVAL_PERSISTENCE_ERROR
    )
    assert (
        RetryExhaustedError("retry", operation="tool_call", max_retries=2).code
        is ErrorCode.RETRY_EXHAUSTED
    )


def test_tool_execution_timeout_error() -> None:
    """Test ToolExecutionTimeoutError attributes and serialization."""
    err = ToolExecutionTimeoutError(
        "tool execution timed out after 30s",
        tool_id="bash",
        tool_call_id="tc123",
        timeout=30.0,
    )
    assert err.code is ErrorCode.TOOL_EXECUTION_TIMEOUT
    assert err.context["tool_id"] == "bash"
    assert err.context["tool_call_id"] == "tc123"
    assert err.context["timeout"] == 30.0
    assert err.retryable is True  # Timeout errors are retryable
    assert err.is_retryable() is True
    assert ErrorCode.TOOL_EXECUTION_TIMEOUT.value in str(err)


def test_tool_execution_timeout_error_without_call_id() -> None:
    """Test ToolExecutionTimeoutError with None tool_call_id."""
    err = ToolExecutionTimeoutError(
        "tool execution timed out",
        tool_id="read_file",
        tool_call_id=None,
        timeout=5.0,
    )
    assert err.context["tool_call_id"] is None
    assert err.context["tool_id"] == "read_file"
    assert err.context["timeout"] == 5.0
