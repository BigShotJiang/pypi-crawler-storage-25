from __future__ import annotations

from wormhole_core.events.types import EventType


def test_event_type_expansion() -> None:
    assert EventType.AWAITING_USER_INPUT.value == "awaiting_user_input"
    assert EventType.AWAITING_TOOL_RESULT.value == "awaiting_tool_result"
    assert EventType.COMPACTION_STARTED.value == "compaction_started"
    assert EventType.COMPACTION_COMPLETED.value == "compaction_completed"
    assert EventType.FORK_STARTED.value == "fork_started"
    assert EventType.FORK_COMPLETED.value == "fork_completed"
    assert EventType.NODE_SCHEDULED.value == "node_scheduled"
    assert EventType.NODE_COMPLETED.value == "node_completed"
    assert EventType.NODE_FAILED.value == "node_failed"
    assert EventType.SESSION_RESUMED.value == "session_resumed"
    assert EventType.SESSION_BUSY.value == "session_busy"
    assert EventType.QUEUE_FULL.value == "queue_full"
    assert EventType.TOOL_INVOKED.value == "tool_invoked"
    assert EventType.HOOK_FAILED.value == "hook_failed"
    assert EventType.BACKPRESSURE_ACTIVATED.value == "backpressure_activated"
    assert EventType.APPROVAL_REQUESTED.value == "approval_requested"
    assert EventType.APPROVAL_GRANTED.value == "approval_granted"
    assert EventType.APPROVAL_DENIED.value == "approval_denied"
    assert EventType.APPROVAL_PERSISTENCE_ERROR.value == "approval_persistence_error"
