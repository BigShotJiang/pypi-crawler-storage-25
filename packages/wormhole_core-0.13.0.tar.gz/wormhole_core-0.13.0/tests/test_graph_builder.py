from __future__ import annotations

from wormhole_core.graph.builder import SessionGraphBuilder


def test_graph_builder_builds_loop_graph() -> None:
    builder = SessionGraphBuilder()
    session_graph = builder.build("s1", payload={"max_consecutive_steps": 4})
    graph = session_graph.graph

    assert "prompt_transform" in graph.nodes
    assert "continuation_check" in graph.nodes
    assert graph.nodes["prompt_transform"].max_visits == 4

    routes = {
        edge.metadata.get("route")
        for edge in graph.edges.values()
        if edge.source == "continuation_check"
    }
    assert routes == {"continue", "done"}


def test_graph_builder_unbounded_main_session_omits_prompt_max_visits() -> None:
    builder = SessionGraphBuilder()
    session_graph = builder.build(
        "s1",
        payload={"main_loop_unbounded": True, "is_sub_agent": False},
    )

    assert session_graph.graph.nodes["prompt_transform"].max_visits is None
