from __future__ import annotations

from typing import Any

import pytest

from wormhole_core.errors import NotFoundError, PersistenceError
from wormhole_core.schemas.session import ExecutionStateSnapshot
from wormhole_core.storage.execution_state_store import (
    ExecutionStateStore,
    LoopgraphSnapshotStore,
)


def test_execution_state_store_roundtrip(tmp_path: Any) -> None:
    store = ExecutionStateStore(tmp_path, runtime_version="0.1.0")
    snapshot = ExecutionStateSnapshot(
        execution_state_id="exec-1",
        graph_id="graph-1",
        snapshot_version="0.1.0",
        data={"states": {"n1": {}}, "completed_nodes": []},
        captured_at=100.0,
    )
    store._sync_save(snapshot)
    loaded = store._sync_load("exec-1")
    assert loaded == snapshot


def test_loopgraph_snapshot_store_roundtrip(tmp_path: Any) -> None:
    store = ExecutionStateStore(tmp_path, runtime_version="0.1.0")
    adapter = LoopgraphSnapshotStore(store, snapshot_version="0.1.0")
    adapter.save("graph-1", {"completed_nodes": ["n1"]})
    loaded = adapter.load("graph-1")
    assert loaded["completed_nodes"] == ["n1"]


def test_execution_state_store_save_error(tmp_path: Any, monkeypatch: Any) -> None:
    store = ExecutionStateStore(tmp_path, runtime_version="0.1.0")

    def _bad_path(_execution_state_id: str) -> Any:
        return tmp_path

    monkeypatch.setattr(store, "_path", _bad_path)
    snapshot = ExecutionStateSnapshot(
        execution_state_id="exec-1",
        graph_id="graph-1",
        snapshot_version="0.1.0",
        data={},
        captured_at=0.0,
    )
    with pytest.raises(PersistenceError):
        store._sync_save(snapshot)


def test_execution_state_store_missing_snapshot(tmp_path: Any) -> None:
    store = ExecutionStateStore(tmp_path, runtime_version="0.1.0")
    with pytest.raises(NotFoundError):
        store._sync_load("missing")


def test_execution_state_store_read_error(tmp_path: Any, monkeypatch: Any) -> None:
    store = ExecutionStateStore(tmp_path, runtime_version="0.1.0")

    def _bad_path(_execution_state_id: str) -> Any:
        return tmp_path

    monkeypatch.setattr(store, "_path", _bad_path)
    with pytest.raises(PersistenceError):
        store._sync_load("exec-1")


def test_execution_state_store_version_mismatch(tmp_path: Any) -> None:
    store = ExecutionStateStore(tmp_path, runtime_version="0.1.0")
    snapshot = ExecutionStateSnapshot(
        execution_state_id="exec-2",
        graph_id="graph-2",
        snapshot_version="0.2.0",
        data={"states": {}},
        captured_at=0.0,
    )
    store._sync_save(snapshot)
    with pytest.raises(PersistenceError):
        store._sync_load("exec-2")
