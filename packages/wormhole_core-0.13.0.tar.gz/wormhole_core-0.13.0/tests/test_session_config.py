from __future__ import annotations

import pytest

from wormhole_core.backpressure import BackpressureConfig, BackpressureStrategy
from wormhole_core.errors import ValidationError
from wormhole_core.retry import RetryPolicy
from wormhole_core.schemas.session import SessionConfig


def test_session_config_defaults() -> None:
    cfg = SessionConfig()
    assert cfg.approval_timeout_seconds == 60.0
    assert cfg.backpressure is None
    assert cfg.model_retry_policy.max_retries == 3
    assert cfg.tool_retry_policy.max_retries == 2


def test_session_config_with_backpressure_and_retry() -> None:
    cfg = SessionConfig(
        backpressure=BackpressureConfig(
            max_size=10, strategy=BackpressureStrategy.FAIL
        ),
        model_retry_policy=RetryPolicy(max_retries=1),
        tool_retry_policy=RetryPolicy(max_retries=0),
    )
    assert cfg.backpressure is not None
    assert cfg.backpressure.max_size == 10
    assert cfg.model_retry_policy.max_retries == 1
    assert cfg.tool_retry_policy.max_retries == 0


def test_session_config_rejects_non_positive_timeout() -> None:
    with pytest.raises(ValidationError):
        SessionConfig(approval_timeout_seconds=0)
