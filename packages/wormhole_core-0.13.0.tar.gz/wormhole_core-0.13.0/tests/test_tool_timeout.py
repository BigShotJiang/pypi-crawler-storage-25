"""Tests for tool execution timeout resolution."""

from __future__ import annotations

import math
from typing import Any

import pytest

from wormhole_core.schemas.session import SessionConfig
from wormhole_core.schemas.tools import ToolCapabilities, ToolDefinition
from wormhole_core.tools.timeout import resolve_timeout


def _make_tool(timeout: float | None = None) -> ToolDefinition:
    """Create a tool definition with optional timeout."""
    return ToolDefinition(
        tool_id="test-tool",
        name="test",
        schema={"type": "object"},
        capabilities=ToolCapabilities(execution_timeout_seconds=timeout),
    )


class TestResolveTimeout:
    """Tests for resolve_timeout function."""

    def test_tool_timeout_takes_precedence_over_session(self: Any) -> None:
        """Tool-level timeout should override session-level default."""
        tool = _make_tool(timeout=5.0)
        config = SessionConfig(tool_execution_timeout_seconds=60.0)
        assert resolve_timeout(tool, config) == 5.0

    def test_none_inherits_from_session_config(self: Any) -> None:
        """None at tool level should inherit from session config."""
        tool = _make_tool(timeout=None)
        config = SessionConfig(tool_execution_timeout_seconds=60.0)
        assert resolve_timeout(tool, config) == 60.0

    def test_both_none_returns_none(self: Any) -> None:
        """Both tool and session None should return None (no timeout)."""
        tool = _make_tool(timeout=None)
        config = SessionConfig(tool_execution_timeout_seconds=None)
        assert resolve_timeout(tool, config) is None

    def test_math_inf_means_explicit_no_timeout(self: Any) -> None:
        """math.inf at tool level means explicitly no timeout."""
        tool = _make_tool(timeout=math.inf)
        config = SessionConfig(tool_execution_timeout_seconds=60.0)
        # math.inf should return None (no timeout), even if session has default
        assert resolve_timeout(tool, config) is None

    def test_positive_timeout_returned_as_is(self: Any) -> None:
        """Positive timeout values should be returned as-is."""
        tool = _make_tool(timeout=30.0)
        config = SessionConfig()
        assert resolve_timeout(tool, config) == 30.0

    def test_session_timeout_used_when_tool_is_none(self: Any) -> None:
        """Session timeout should be used when tool timeout is None."""
        tool = _make_tool(timeout=None)
        config = SessionConfig(tool_execution_timeout_seconds=120.0)
        assert resolve_timeout(tool, config) == 120.0

    def test_small_timeout_value(self: Any) -> None:
        """Small timeout values should work correctly."""
        tool = _make_tool(timeout=0.1)
        config = SessionConfig()
        assert resolve_timeout(tool, config) == 0.1

    def test_large_timeout_value(self: Any) -> None:
        """Large timeout values should work correctly."""
        tool = _make_tool(timeout=3600.0)  # 1 hour
        config = SessionConfig()
        assert resolve_timeout(tool, config) == 3600.0


class TestToolCapabilitiesTimeout:
    """Tests for execution_timeout_seconds in ToolCapabilities."""

    def test_default_is_none(self: Any) -> None:
        """Default execution_timeout_seconds should be None."""
        caps = ToolCapabilities()
        assert caps.execution_timeout_seconds is None

    def test_can_set_positive_timeout(self: Any) -> None:
        """Can set a positive timeout value."""
        caps = ToolCapabilities(execution_timeout_seconds=30.0)
        assert caps.execution_timeout_seconds == 30.0

    def test_can_set_math_inf(self: Any) -> None:
        """Can set math.inf for explicit no-timeout."""
        caps = ToolCapabilities(execution_timeout_seconds=math.inf)
        assert caps.execution_timeout_seconds is not None
        assert math.isinf(caps.execution_timeout_seconds)

    def test_none_is_valid(self: Any) -> None:
        """None is a valid value (inherit from session)."""
        caps = ToolCapabilities(execution_timeout_seconds=None)
        assert caps.execution_timeout_seconds is None


class TestSessionConfigTimeout:
    """Tests for tool_execution_timeout_seconds in SessionConfig."""

    def test_default_is_none(self: Any) -> None:
        """Default tool_execution_timeout_seconds should be None."""
        config = SessionConfig()
        assert config.tool_execution_timeout_seconds is None

    def test_can_set_positive_timeout(self: Any) -> None:
        """Can set a positive timeout value."""
        config = SessionConfig(tool_execution_timeout_seconds=60.0)
        assert config.tool_execution_timeout_seconds == 60.0

    def test_none_is_valid(self: Any) -> None:
        """None is a valid value (no default timeout)."""
        config = SessionConfig(tool_execution_timeout_seconds=None)
        assert config.tool_execution_timeout_seconds is None

    def test_zero_raises_validation_error(self: Any) -> None:
        """Zero timeout should raise ValidationError."""
        from wormhole_core.errors import ValidationError

        with pytest.raises(
            ValidationError, match="tool_execution_timeout_seconds must be > 0"
        ):
            SessionConfig(tool_execution_timeout_seconds=0)

    def test_negative_raises_validation_error(self: Any) -> None:
        """Negative timeout should raise ValidationError."""
        from wormhole_core.errors import ValidationError

        with pytest.raises(
            ValidationError, match="tool_execution_timeout_seconds must be > 0"
        ):
            SessionConfig(tool_execution_timeout_seconds=-1.0)

    def test_math_inf_is_valid(self: Any) -> None:
        """math.inf should be a valid value (explicit no timeout)."""
        config = SessionConfig(tool_execution_timeout_seconds=math.inf)
        assert config.tool_execution_timeout_seconds is not None
        assert math.isinf(config.tool_execution_timeout_seconds)
