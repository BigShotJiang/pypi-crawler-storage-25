from __future__ import annotations

import asyncio
import time
from typing import cast

import pytest
from loopgraph.concurrency import SemaphorePolicy
from loopgraph.core.graph import Edge, Graph, Node
from loopgraph.core.types import NodeKind

from wormhole_core.graph.function_registry import SessionFunctionRegistry
from wormhole_core.graph.runtime import SessionGraphRuntime
from wormhole_core.hooks.registry import HookRegistry
from wormhole_core.hooks.types import HookCallback, HookContext, HookPoint, HookResult
from wormhole_core.loop.session_api import SessionManager
from wormhole_core.schemas.session import SessionConfig, SessionStatus
from wormhole_core.schemas.tools import ToolCapabilities, ToolDefinition
from wormhole_core.tools.registry import ToolRegistry


class _Adapter:
    async def stream(self, payload: dict[str, object]) -> dict[str, object]:
        return payload


@pytest.mark.asyncio
async def test_session_lifecycle_async() -> None:
    manager = SessionManager(model_adapter=cast(object, _Adapter()))
    handle = await manager.start_session(SessionConfig())
    assert handle.session.status is SessionStatus.RUNNING

    step = await manager.step_session(handle.session.session_id, input="hello")
    assert step.session.status is SessionStatus.RUNNING
    assert step.events

    stopped = await manager.stop_session(handle.session.session_id)
    assert stopped.status is SessionStatus.COMPLETED


@pytest.mark.asyncio
async def test_session_loop_invokes_prompt_transform_hook() -> None:
    registry = HookRegistry()
    seen: list[str] = []

    def record_input(ctx: HookContext) -> HookResult:
        seen.append(str(ctx.payload.get("input")))
        return HookResult(proceed=True)

    registry.register(
        HookPoint.PROMPT_TRANSFORM, cast(HookCallback, record_input), hook_id="h1"
    )
    manager = SessionManager(
        hook_registry=registry, model_adapter=cast(object, _Adapter())
    )
    handle = await manager.start_session(SessionConfig())

    await manager.step_session(handle.session.session_id, input="hello")

    assert seen == ["hello"]


@pytest.mark.asyncio
async def test_concurrency_safe_enforcement_serializes_tools() -> None:
    registry = SessionFunctionRegistry()
    tool_registry = ToolRegistry()
    tool_registry.register(
        ToolDefinition(
            tool_id="t1",
            name="tool1",
            schema={"type": "object"},
            capabilities=ToolCapabilities(concurrency_safe=False),
        )
    )
    tool_registry.register(
        ToolDefinition(
            tool_id="t2",
            name="tool2",
            schema={"type": "object"},
            capabilities=ToolCapabilities(concurrency_safe=False),
        )
    )

    async def tool_handler(label: str) -> None:
        start = time.perf_counter()
        timeline.append((label, "start", start))
        await asyncio.sleep(0.05)
        end = time.perf_counter()
        timeline.append((label, "end", end))

    timeline: list[tuple[str, str, float]] = []
    registry.register("start", lambda payload: payload)
    registry.register("tool:t1", lambda payload: tool_handler("t1"))
    registry.register("tool:t2", lambda payload: tool_handler("t2"))

    graph = Graph(
        nodes={
            "start": Node(id="start", kind=NodeKind.TASK, handler="start"),
            "tool:t1": Node(id="tool:t1", kind=NodeKind.TASK, handler="tool:t1"),
            "tool:t2": Node(id="tool:t2", kind=NodeKind.TASK, handler="tool:t2"),
        },
        edges={
            "edge-start-t1": Edge(id="edge-start-t1", source="start", target="tool:t1"),
            "edge-start-t2": Edge(id="edge-start-t2", source="start", target="tool:t2"),
        },
    )

    runtime = SessionGraphRuntime(
        registry.registry,
        concurrency_manager=SemaphorePolicy(limit=2),
        session_id="s1",
        tool_registry=tool_registry,
    )
    await runtime.run(graph, graph_id="g1", payload={})

    times = {(label, phase): ts for label, phase, ts in timeline}
    t1_start = times[("t1", "start")]
    t1_end = times[("t1", "end")]
    t2_start = times[("t2", "start")]
    t2_end = times[("t2", "end")]
    assert t1_end <= t2_start or t2_end <= t1_start
