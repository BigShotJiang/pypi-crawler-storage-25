from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import pytest

from wormhole_core.errors import NotFoundError, PersistenceError
from wormhole_core.events.types import EventType
from wormhole_core.schemas.tools import ToolCall, ToolCallStatus
from wormhole_core.storage.event_log_store import (
    EVENT_LOG_SCHEMA_VERSION,
    EventLogEntry,
    EventLogStore,
    _coerce_bool,
    _coerce_float,
    _coerce_int,
    _coerce_optional_str,
    _entry_from_dict,
    _file_lock,
)


def test_event_log_store_roundtrip(tmp_path: Any) -> None:
    store = EventLogStore(tmp_path)
    entry = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-1",
        node_id="n1",
        event_type="node_completed",
        payload={"ok": True},
        status="completed",
        visit_count=2,
        replay=False,
        recorded_at=123.0,
        schema_version=EVENT_LOG_SCHEMA_VERSION,
    )
    store._sync_append(entry)

    loaded = store._sync_load("s1")

    assert loaded == [entry]


def test_event_log_store_missing_session(tmp_path: Any) -> None:
    store = EventLogStore(tmp_path)
    with pytest.raises(NotFoundError):
        store._sync_load("missing")


def test_event_log_store_multiple_entries(tmp_path: Any) -> None:
    store = EventLogStore(tmp_path)
    entry1 = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-1",
        node_id="n1",
        event_type="node_started",
        payload=None,
        status="pending",
        visit_count=1,
        replay=None,
        recorded_at=100.0,
    )
    entry2 = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-2",
        node_id="n1",
        event_type="node_completed",
        payload={"result": "done"},
        status="completed",
        visit_count=1,
        replay=False,
        recorded_at=101.0,
    )
    store._sync_append(entry1)
    store._sync_append(entry2)

    loaded = store._sync_load("s1")
    assert len(loaded) == 2
    assert loaded[0] == entry1
    assert loaded[1] == entry2


def test_event_log_store_normalizes_tool_calls(tmp_path: Any) -> None:
    store = EventLogStore(tmp_path)
    entry = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-1",
        node_id="n1",
        event_type="node_completed",
        payload={
            "tool_call_results": [
                ToolCall(
                    tool_call_id="call-1",
                    tool_id="echo",
                    arguments={"text": "hello"},
                    status=ToolCallStatus.COMPLETED,
                )
            ]
        },
        status="completed",
        visit_count=1,
        replay=False,
        recorded_at=123.0,
    )
    store._sync_append(entry)

    loaded = store._sync_load("s1")

    assert loaded
    payload = loaded[0].payload
    assert payload is not None
    tool_call = payload["tool_call_results"][0]
    assert tool_call["tool_call_id"] == "call-1"
    assert tool_call["tool_id"] == "echo"
    assert tool_call["arguments"] == {"text": "hello"}
    assert tool_call["status"] == ToolCallStatus.COMPLETED.value


def test_event_log_store_normalizes_datetime_payload(tmp_path: Any) -> None:
    store = EventLogStore(tmp_path)
    timestamp = datetime(2024, 1, 2, 3, 4, 5, tzinfo=timezone.utc)
    entry = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-2",
        node_id="n2",
        event_type="node_completed",
        payload={"when": timestamp},
        status="completed",
        visit_count=1,
        replay=False,
        recorded_at=123.0,
    )
    store._sync_append(entry)

    loaded = store._sync_load("s1")

    assert loaded
    payload = loaded[0].payload
    assert payload is not None
    assert payload["when"] == timestamp.isoformat()


def test_event_log_store_handles_empty_lines(tmp_path: Any) -> None:
    """Test that empty lines in the log file are skipped."""
    store = EventLogStore(tmp_path)
    entry = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-1",
        node_id=None,
        event_type="test",
        payload=None,
        status=None,
        visit_count=None,
        replay=None,
        recorded_at=123.0,
    )
    store._sync_append(entry)

    # Manually insert empty lines
    log_path = tmp_path / "s1.jsonl"
    content = log_path.read_text()
    log_path.write_text(content + "\n\n")

    loaded = store._sync_load("s1")
    assert len(loaded) == 1
    assert loaded[0] == entry


def test_event_log_store_filters_approval_events(tmp_path: Any) -> None:
    store = EventLogStore(tmp_path)
    store._sync_append(
        EventLogEntry(
            session_id="s1",
            graph_id=None,
            event_id=None,
            node_id=None,
            event_type=EventType.APPROVAL_REQUESTED.value,
            payload={"ok": True},
            status=None,
            visit_count=None,
            replay=None,
        )
    )
    store._sync_append(
        EventLogEntry(
            session_id="s1",
            graph_id=None,
            event_id=None,
            node_id=None,
            event_type="node_completed",
            payload=None,
            status=None,
            visit_count=None,
            replay=None,
        )
    )
    approvals = store.list_approval_events("s1")
    assert len(approvals) == 1
    assert approvals[0].event_type == EventType.APPROVAL_REQUESTED.value


def test_event_log_store_invalid_json(tmp_path: Any) -> None:
    """Test that invalid JSON raises PersistenceError."""
    store = EventLogStore(tmp_path)
    entry = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-1",
        node_id=None,
        event_type="test",
        payload=None,
        status=None,
        visit_count=None,
        replay=None,
        recorded_at=123.0,
    )
    store._sync_append(entry)

    # Corrupt the file with invalid JSON
    log_path = tmp_path / "s1.jsonl"
    content = log_path.read_text()
    log_path.write_text(content + "not valid json\n")

    with pytest.raises(PersistenceError) as exc_info:
        store._sync_load("s1")
    assert "failed to decode" in str(exc_info.value)


def test_event_log_store_append_os_error(tmp_path: Any) -> None:
    """Test that OSError during append raises PersistenceError."""
    store = EventLogStore(tmp_path)
    entry = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-1",
        node_id=None,
        event_type="test",
        payload=None,
        status=None,
        visit_count=None,
        replay=None,
    )

    # Make the directory read-only to cause write failure
    log_path = tmp_path / "s1.jsonl"
    log_path.touch()
    log_path.chmod(0o000)

    try:
        with pytest.raises(PersistenceError) as exc_info:
            store._sync_append(entry)
        assert "failed to append" in str(exc_info.value)
    finally:
        log_path.chmod(0o644)


def test_event_log_store_load_os_error(tmp_path: Any) -> None:
    """Test that OSError during load raises PersistenceError."""
    store = EventLogStore(tmp_path)
    entry = EventLogEntry(
        session_id="s1",
        graph_id="g1",
        event_id="evt-1",
        node_id=None,
        event_type="test",
        payload=None,
        status=None,
        visit_count=None,
        replay=None,
    )
    store._sync_append(entry)

    # Make file unreadable
    log_path = tmp_path / "s1.jsonl"
    log_path.chmod(0o000)

    try:
        with pytest.raises(PersistenceError) as exc_info:
            store._sync_load("s1")
        assert "failed to read" in str(exc_info.value)
    finally:
        log_path.chmod(0o644)


def test_file_lock_contention(tmp_path: Any) -> None:
    """Test that file lock handles contention with retries."""
    lock_path = tmp_path / "test.lock"

    # Create existing lock file to simulate contention
    lock_path.touch()

    # With 0 retries, should fail immediately
    with pytest.raises(PersistenceError) as exc_info:
        with _file_lock(lock_path, timeout_s=0.0, retries=0, poll_interval_s=0.0):
            pass
    assert "failed to acquire" in str(exc_info.value)


def test_file_lock_cleanup_on_success(tmp_path: Any) -> None:
    """Test that file lock is cleaned up after successful use."""
    lock_path = tmp_path / "test.lock"

    with _file_lock(lock_path):
        assert lock_path.exists()

    assert not lock_path.exists()


# Tests for coercion helper functions


def test_coerce_optional_str_none() -> None:
    assert _coerce_optional_str(None) is None


def test_coerce_optional_str_value() -> None:
    assert _coerce_optional_str("test") == "test"
    assert _coerce_optional_str(123) == "123"


def test_coerce_int_bool() -> None:
    assert _coerce_int(True) == 1
    assert _coerce_int(False) == 0


def test_coerce_int_int() -> None:
    assert _coerce_int(42) == 42
    assert _coerce_int(-5) == -5


def test_coerce_int_float() -> None:
    assert _coerce_int(3.7) == 3
    assert _coerce_int(2.0) == 2


def test_coerce_int_str() -> None:
    assert _coerce_int("42") == 42
    assert _coerce_int("invalid") is None
    assert _coerce_int("") is None


def test_coerce_int_none() -> None:
    assert _coerce_int(None) is None
    assert _coerce_int([]) is None


def test_coerce_float_int_float() -> None:
    assert _coerce_float(42, 0.0) == 42.0
    assert _coerce_float(3.14, 0.0) == 3.14


def test_coerce_float_str() -> None:
    assert _coerce_float("3.14", 0.0) == 3.14
    assert _coerce_float("invalid", 99.0) == 99.0


def test_coerce_float_default() -> None:
    assert _coerce_float(None, 1.5) == 1.5
    assert _coerce_float([], 2.5) == 2.5


def test_coerce_bool_bool() -> None:
    assert _coerce_bool(True) is True
    assert _coerce_bool(False) is False


def test_coerce_bool_str_true() -> None:
    assert _coerce_bool("true") is True
    assert _coerce_bool("TRUE") is True
    assert _coerce_bool("1") is True
    assert _coerce_bool("yes") is True
    assert _coerce_bool("YES") is True


def test_coerce_bool_str_false() -> None:
    assert _coerce_bool("false") is False
    assert _coerce_bool("FALSE") is False
    assert _coerce_bool("0") is False
    assert _coerce_bool("no") is False
    assert _coerce_bool("NO") is False


def test_coerce_bool_invalid() -> None:
    assert _coerce_bool("maybe") is None
    assert _coerce_bool(123) is None
    assert _coerce_bool(None) is None


def test_entry_from_dict_with_non_dict_payload() -> None:
    """Test that non-dict payload is normalized to None."""
    data = {
        "session_id": "s1",
        "event_type": "test",
        "payload": "not a dict",
    }
    entry = _entry_from_dict(data)
    assert entry.payload is None


def test_entry_from_dict_with_defaults() -> None:
    """Test entry from dict with minimal data uses defaults."""
    data = {
        "session_id": "s1",
        "event_type": "test",
    }
    entry = _entry_from_dict(data)
    assert entry.session_id == "s1"
    assert entry.event_type == "test"
    assert entry.graph_id is None
    assert entry.event_id is None
    assert entry.node_id is None
    assert entry.payload is None
    assert entry.status is None
    assert entry.visit_count is None
    assert entry.replay is None
    assert entry.schema_version == EVENT_LOG_SCHEMA_VERSION
