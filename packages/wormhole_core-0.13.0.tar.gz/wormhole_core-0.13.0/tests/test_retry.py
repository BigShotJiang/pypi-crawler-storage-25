from __future__ import annotations

import pytest

from wormhole_core.retry import IdempotencyStore, RetryPolicy


def test_retry_policy_validation() -> None:
    with pytest.raises(ValueError):
        RetryPolicy(max_retries=-1)
    with pytest.raises(ValueError):
        RetryPolicy(base_delay=-1)
    with pytest.raises(ValueError):
        RetryPolicy(base_delay=2.0, max_delay=1.0)
    with pytest.raises(ValueError):
        RetryPolicy(backoff_multiplier=0.5)


def test_retry_policy_delay_calculation() -> None:
    policy = RetryPolicy(
        max_retries=3, base_delay=1.0, max_delay=5.0, backoff_multiplier=2.0
    )
    assert policy.delay_for_attempt(0) == 1.0
    assert policy.delay_for_attempt(2) == 4.0


def test_idempotency_store_deduplicates() -> None:
    store = IdempotencyStore()
    record = store.get_or_create("key1", "tool_call")
    assert record.key == "key1"
    assert store.get("key1") is record

    store.complete("key1", "success", result={"ok": True})
    completed = store.get_or_create("key1", "tool_call")
    assert completed.is_completed
