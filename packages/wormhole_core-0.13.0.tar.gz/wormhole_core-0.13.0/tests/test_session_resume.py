from __future__ import annotations

from typing import Any

import pytest

from wormhole_core.errors import SessionExpiredError, SnapshotError
from wormhole_core.loop.resume import resume_session
from wormhole_core.schemas.session import (
    ExecutionStateSnapshot,
    Session,
    SessionConfig,
    SessionStatus,
)
from wormhole_core.storage.execution_state_store import ExecutionStateStore
from wormhole_core.storage.session_store import (
    SessionRecord,
    SessionStore,
    calculate_retention_expiry,
)


def test_resume_replay(tmp_path: Any) -> None:
    store = SessionStore(tmp_path / "sessions")
    snapshot_store = ExecutionStateStore(
        tmp_path / "snapshots", runtime_version="0.1.0"
    )
    now = 1000.0
    session = Session(
        session_id="s1",
        status=SessionStatus.RUNNING,
        created_at=now,
        updated_at=now,
        retention_expires_at=calculate_retention_expiry(now, retention_days=30),
        execution_state_id="exec-1",
        graph_id="graph-1",
    )
    record = SessionRecord(
        session=session,
        config=SessionConfig(),
        state=None,
        messages=[],
        compaction_snapshot_id=None,
    )
    store._sync_save(record)
    snapshot = ExecutionStateSnapshot(
        execution_state_id="exec-1",
        graph_id="graph-1",
        snapshot_version="0.1.0",
        data={"states": {}, "completed_nodes": []},
        captured_at=now,
    )
    snapshot_store._sync_save(snapshot)
    resumed_record, resumed_snapshot = resume_session(
        store,
        snapshot_store,
        session.session_id,
        now=now,
    )
    assert resumed_record.session.session_id == session.session_id
    assert resumed_snapshot.execution_state_id == "exec-1"


def test_resume_session_expired_raises(tmp_path: Any) -> None:
    store = SessionStore(tmp_path / "sessions")
    snapshot_store = ExecutionStateStore(
        tmp_path / "snapshots", runtime_version="0.1.0"
    )
    session = Session(
        session_id="s1",
        status=SessionStatus.RUNNING,
        retention_expires_at=1.0,
    )
    record = SessionRecord(
        session=session,
        config=SessionConfig(),
        state=None,
        messages=[],
        compaction_snapshot_id=None,
    )
    store._sync_save(record)
    with pytest.raises(SessionExpiredError):
        resume_session(store, snapshot_store, session.session_id, now=10.0)


def test_resume_session_missing_snapshot_raises(tmp_path: Any) -> None:
    store = SessionStore(tmp_path / "sessions")
    snapshot_store = ExecutionStateStore(
        tmp_path / "snapshots", runtime_version="0.1.0"
    )
    session = Session(
        session_id="s1",
        status=SessionStatus.RUNNING,
        retention_expires_at=calculate_retention_expiry(0.0, retention_days=30),
        execution_state_id=None,
    )
    record = SessionRecord(
        session=session,
        config=SessionConfig(),
        state=None,
        messages=[],
        compaction_snapshot_id=None,
    )
    store._sync_save(record)
    with pytest.raises(SnapshotError):
        resume_session(store, snapshot_store, session.session_id, now=0.0)


def test_resume_session_rejects_incompatible_snapshot(tmp_path: Any) -> None:
    store = SessionStore(tmp_path / "sessions")
    snapshot_store = ExecutionStateStore(
        tmp_path / "snapshots", runtime_version="0.1.0"
    )
    now = 1000.0
    session = Session(
        session_id="s1",
        status=SessionStatus.RUNNING,
        retention_expires_at=calculate_retention_expiry(now, retention_days=30),
        execution_state_id="exec-1",
        graph_id="graph-1",
    )
    record = SessionRecord(
        session=session,
        config=SessionConfig(),
        state=None,
        messages=[],
        compaction_snapshot_id=None,
    )
    store._sync_save(record)
    snapshot = ExecutionStateSnapshot(
        execution_state_id="exec-1",
        graph_id="graph-1",
        snapshot_version="0.2.0",
        data={"states": {}},
        captured_at=now,
    )
    snapshot_store._sync_save(snapshot)
    with pytest.raises(SnapshotError):
        resume_session(store, snapshot_store, session.session_id, now=now)


def test_resume_session_rejects_corrupted_snapshot(tmp_path: Any) -> None:
    store = SessionStore(tmp_path / "sessions")
    snapshot_store = ExecutionStateStore(
        tmp_path / "snapshots", runtime_version="0.1.0"
    )
    now = 1000.0
    session = Session(
        session_id="s1",
        status=SessionStatus.RUNNING,
        retention_expires_at=calculate_retention_expiry(now, retention_days=30),
        execution_state_id="exec-1",
        graph_id="graph-1",
    )
    record = SessionRecord(
        session=session,
        config=SessionConfig(),
        state=None,
        messages=[],
        compaction_snapshot_id=None,
    )
    store._sync_save(record)
    snapshot_path = tmp_path / "snapshots" / "exec-1.json"
    snapshot_path.write_text("{not json")
    with pytest.raises(SnapshotError):
        resume_session(store, snapshot_store, session.session_id, now=now)
