"""Tests for tool_call_results to message conversion."""

from __future__ import annotations

from typing import Any

from wormhole_core.loop.session_api import _build_tool_result_message
from wormhole_core.schemas.messages import MessageRole, PartType
from wormhole_core.schemas.tools import ToolCall, ToolCallStatus


class TestBuildToolResultMessage:
    """Tests for _build_tool_result_message function."""

    def test_single_result_creates_user_message(self: Any) -> None:
        """A single tool result creates a user message with one tool_output part."""
        results = [
            ToolCall(
                tool_call_id="tc1",
                tool_id="bash",
                status=ToolCallStatus.COMPLETED,
                result={"output": "hello world"},
            )
        ]
        msg = _build_tool_result_message(results)

        assert msg.role == MessageRole.USER
        assert len(msg.parts) == 1
        assert msg.parts[0].type == PartType.TOOL_OUTPUT

    def test_result_payload_contains_expected_fields(self: Any) -> None:
        """Tool output part payload should contain expected fields."""
        results = [
            ToolCall(
                tool_call_id="tc1",
                tool_id="read_file",
                status=ToolCallStatus.COMPLETED,
                result={"content": "file contents"},
                error=None,
            )
        ]
        msg = _build_tool_result_message(results)

        payload = msg.parts[0].payload
        assert payload["tool_call_id"] == "tc1"
        assert payload["tool_id"] == "read_file"
        assert payload["output"] == {"content": "file contents"}
        assert payload["status"] == "completed"
        assert payload["error"] is None

    def test_multiple_results_create_multiple_parts(self: Any) -> None:
        """Multiple tool results create multiple tool_output parts in one message."""
        results = [
            ToolCall(
                tool_call_id="tc1",
                tool_id="bash",
                status=ToolCallStatus.COMPLETED,
                result={"output": "result1"},
            ),
            ToolCall(
                tool_call_id="tc2",
                tool_id="read_file",
                status=ToolCallStatus.COMPLETED,
                result={"output": "result2"},
            ),
        ]
        msg = _build_tool_result_message(results)

        assert msg.role == MessageRole.USER
        assert len(msg.parts) == 2
        assert all(p.type == PartType.TOOL_OUTPUT for p in msg.parts)

        # Verify each part has correct tool_call_id
        assert msg.parts[0].payload["tool_call_id"] == "tc1"
        assert msg.parts[1].payload["tool_call_id"] == "tc2"

    def test_failed_result_includes_error(self: Any) -> None:
        """Failed tool result should include error information."""
        results = [
            ToolCall(
                tool_call_id="tc1",
                tool_id="bash",
                status=ToolCallStatus.FAILED,
                result=None,
                error="Command not found",
            )
        ]
        msg = _build_tool_result_message(results)

        payload = msg.parts[0].payload
        assert payload["status"] == "failed"
        assert payload["error"] == "Command not found"
        assert payload["output"] is None

    def test_message_id_is_unique(self: Any) -> None:
        """Each message should have a unique ID."""
        results = [
            ToolCall(
                tool_call_id="tc1",
                tool_id="bash",
                status=ToolCallStatus.COMPLETED,
                result={"output": "test"},
            )
        ]
        msg1 = _build_tool_result_message(results)
        msg2 = _build_tool_result_message(results)

        assert msg1.id != msg2.id
        assert msg1.id.startswith("msg-tool-results-")

    def test_part_id_derived_from_tool_call_id(self: Any) -> None:
        """Part ID should be derived from the tool_call_id."""
        results = [
            ToolCall(
                tool_call_id="my-tool-call-123",
                tool_id="bash",
                status=ToolCallStatus.COMPLETED,
                result={},
            )
        ]
        msg = _build_tool_result_message(results)

        assert msg.parts[0].id == "part-my-tool-call-123"

    def test_pending_status_is_preserved(self: Any) -> None:
        """Pending status should be preserved in the output."""
        results = [
            ToolCall(
                tool_call_id="tc1",
                tool_id="slow_tool",
                status=ToolCallStatus.PENDING,
                result=None,
            )
        ]
        msg = _build_tool_result_message(results)

        assert msg.parts[0].payload["status"] == "pending"

    def test_complex_result_object(self: Any) -> None:
        """Complex result objects should be preserved."""
        complex_result = {
            "files": ["a.txt", "b.txt"],
            "metadata": {"count": 2, "size": 1024},
            "nested": {"deep": {"value": 42}},
        }
        results = [
            ToolCall(
                tool_call_id="tc1",
                tool_id="list_files",
                status=ToolCallStatus.COMPLETED,
                result=complex_result,
            )
        ]
        msg = _build_tool_result_message(results)

        assert msg.parts[0].payload["output"] == complex_result


class TestToolCallWithResult:
    """Tests for ToolCall dataclass with result field."""

    def test_tool_call_default_result_is_none(self: Any) -> None:
        """Default result should be None."""
        call = ToolCall(tool_call_id="tc1", tool_id="bash")
        assert call.result is None
        assert call.error is None

    def test_tool_call_with_result(self: Any) -> None:
        """ToolCall can store a result."""
        call = ToolCall(
            tool_call_id="tc1",
            tool_id="bash",
            status=ToolCallStatus.COMPLETED,
            result={"output": "hello"},
        )
        assert call.result == {"output": "hello"}

    def test_tool_call_with_error(self: Any) -> None:
        """ToolCall can store an error."""
        call = ToolCall(
            tool_call_id="tc1",
            tool_id="bash",
            status=ToolCallStatus.FAILED,
            error="Command failed",
        )
        assert call.error == "Command failed"
