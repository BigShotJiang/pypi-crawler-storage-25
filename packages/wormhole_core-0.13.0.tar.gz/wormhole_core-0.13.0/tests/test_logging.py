from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

import pytest

from wormhole_core.logging import (
    REDACTED,
    _jsonify,
    _redact_value,
    log_parameter,
    log_variable_change,
)


@dataclass
class DemoData:
    value: int


class DemoEnum(Enum):
    ALPHA = "alpha"


class DemoObject:
    def __repr__(self: Any) -> str:
        return "demo"


def test_jsonify_handles_common_types() -> None:
    assert _jsonify(DemoData(1)) == {"value": 1}
    assert _jsonify(DemoEnum.ALPHA) == "alpha"
    assert _jsonify({"enum": DemoEnum.ALPHA}) == {"enum": "alpha"}
    assert _jsonify([1, DemoEnum.ALPHA]) == [1, "alpha"]
    assert _jsonify((1, 2)) == [1, 2]
    assert sorted(_jsonify({2, 1})) == [1, 2]
    assert _jsonify(b"hi") == "hi"
    assert _jsonify(b"\xff") == "ff"
    assert _jsonify(ValueError("boom")) == {"error": "ValueError", "message": "boom"}
    assert _jsonify(Path("demo")) == "demo"
    assert _jsonify(DemoObject()) == "demo"


def test_redact_value_nested_payload() -> None:
    payload = {
        "api_key": "secret",
        "nested": {"token": "value", "ok": 1},
        "items": [{"password": "oops"}],
    }
    redacted = _redact_value(payload)
    assert redacted["api_key"] == REDACTED
    assert redacted["nested"]["token"] == REDACTED
    assert redacted["nested"]["ok"] == 1
    assert redacted["items"][0]["password"] == REDACTED


def test_emit_debug_logs_when_enabled(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    monkeypatch.setenv("WORMHOLE_DEBUG", "1")
    monkeypatch.delenv("WORMHOLE_RELEASE", raising=False)
    caplog.set_level(logging.DEBUG, logger="wormhole_core")

    log_parameter("demo", token="secret", value=2, call_id="c1")

    records = [record for record in caplog.records if record.name == "wormhole_core"]
    assert records
    payload = json.loads(records[0].message)
    assert payload["function"] == "demo"
    assert payload["call_id"] == "c1"
    assert isinstance(payload["timestamp"], (int, float))
    assert "branch" in payload
    assert "loop_iter" in payload
    assert "elapsed_ms" in payload
    assert payload["event"] == "params"
    assert payload["payload"]["token"] == REDACTED
    assert payload["payload"]["value"] == 2


def test_log_variable_change_captures_before_after(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    monkeypatch.setenv("WORMHOLE_DEBUG", "1")
    monkeypatch.delenv("WORMHOLE_RELEASE", raising=False)
    caplog.set_level(logging.DEBUG, logger="wormhole_core")

    log_variable_change("demo", "counter", 1, 2, call_id="c2")

    records = [record for record in caplog.records if record.name == "wormhole_core"]
    assert records
    payload = json.loads(records[0].message)
    assert payload["event"] == "var_change"
    assert payload["payload"]["before"] == 1
    assert payload["payload"]["after"] == 2


def test_log_variable_change_allows_none_after(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    monkeypatch.setenv("WORMHOLE_DEBUG", "1")
    monkeypatch.delenv("WORMHOLE_RELEASE", raising=False)
    caplog.set_level(logging.DEBUG, logger="wormhole_core")

    log_variable_change("demo", "status", "ready", None, call_id="c4")

    records = [record for record in caplog.records if record.name == "wormhole_core"]
    assert records
    payload = json.loads(records[0].message)
    assert payload["payload"]["before"] == "ready"
    assert payload["payload"]["after"] is None


def test_release_mode_disables_debug_logging(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    monkeypatch.setenv("WORMHOLE_DEBUG", "1")
    monkeypatch.setenv("WORMHOLE_RELEASE", "1")
    caplog.set_level(logging.DEBUG, logger="wormhole_core")

    log_parameter("demo", value=3, call_id="c3")

    records = [record for record in caplog.records if record.name == "wormhole_core"]
    assert records == []
