from __future__ import annotations

import pytest

from wormhole_core.errors import ValidationError
from wormhole_core.schemas.session import (
    ContinuationMode,
    ExecutionState,
    FinishReason,
    SessionConfig,
    validate_execution_state,
)


def test_execution_state_defaults() -> None:
    state = ExecutionState(session_id="s1", step_index=0, next_speaker="assistant")
    assert state.last_finish_reason is None
    assert state.continuation_mode is ContinuationMode.AUTOMATIC


def test_execution_state_explicit_fields() -> None:
    state = ExecutionState(
        session_id="s1",
        step_index=1,
        next_speaker="assistant",
        pending_tool_calls=["tool-1"],
        last_finish_reason=FinishReason.TOOL_USE,
        continuation_mode=ContinuationMode.FORCE_STOP,
    )
    assert state.last_finish_reason is FinishReason.TOOL_USE
    assert state.continuation_mode is ContinuationMode.FORCE_STOP


def test_execution_state_validation_error() -> None:
    state = ExecutionState(session_id="s1", step_index=-1, next_speaker="assistant")
    with pytest.raises(ValidationError):
        validate_execution_state(state)


def test_session_config_validation_errors() -> None:
    with pytest.raises(ValidationError):
        SessionConfig(retention_days=0)
    with pytest.raises(ValidationError):
        SessionConfig(compaction_ratio=1.5)
    with pytest.raises(ValidationError):
        SessionConfig(max_concurrent_tools=0)


def test_session_config_default_max_concurrent_tools() -> None:
    config = SessionConfig()
    assert config.max_concurrent_tools == 1
