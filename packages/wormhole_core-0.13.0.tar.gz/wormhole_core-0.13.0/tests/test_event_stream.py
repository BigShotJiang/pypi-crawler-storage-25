from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest
from loopgraph.bus.eventbus import EventBus

from wormhole_core.backpressure import BackpressureConfig, BackpressureStrategy
from wormhole_core.errors import BackpressureError, EngineError
from wormhole_core.events.stream import CoreEventStream, EventStream
from wormhole_core.events.types import CoreEvent, EventType


@pytest.mark.asyncio
async def test_event_stream_async_iteration() -> None:
    stream: EventStream[CoreEvent] = EventStream()
    event = CoreEvent(session_id="s1", type=EventType.SESSION_STARTED)

    iterator = stream.__aiter__()
    await stream.publish(event)
    received = await iterator.__anext__()
    assert received == event


def test_event_stream_unbind_failure() -> None:
    """Test that unbind_event_bus raises EngineError on failure."""
    stream = CoreEventStream()
    bus = MagicMock(spec=EventBus)
    bus.unsubscribe.side_effect = RuntimeError("unsubscribe failed")

    async def dummy_listener(event: Any) -> None:
        pass

    with pytest.raises(EngineError) as exc_info:
        stream.unbind_event_bus(bus, dummy_listener)
    assert "unsubscribe failed" in str(exc_info.value)


@pytest.mark.asyncio
async def test_event_stream_backpressure_fail() -> None:
    stream: EventStream[CoreEvent] = EventStream(
        backpressure=BackpressureConfig(max_size=1, strategy=BackpressureStrategy.FAIL)
    )
    await stream.publish(CoreEvent(session_id="s1", type=EventType.SESSION_STARTED))
    with pytest.raises(BackpressureError):
        await stream.publish(CoreEvent(session_id="s1", type=EventType.SESSION_STEP))


@pytest.mark.asyncio
async def test_event_stream_backpressure_drop_oldest() -> None:
    stream: EventStream[CoreEvent] = EventStream(
        backpressure=BackpressureConfig(
            max_size=1, strategy=BackpressureStrategy.DROP_OLDEST
        )
    )
    await stream.publish(CoreEvent(session_id="s1", type=EventType.SESSION_STARTED))
    await stream.publish(CoreEvent(session_id="s1", type=EventType.SESSION_STEP))
    assert stream.metrics.current_size == 1
    assert stream.metrics.drops_count == 1
