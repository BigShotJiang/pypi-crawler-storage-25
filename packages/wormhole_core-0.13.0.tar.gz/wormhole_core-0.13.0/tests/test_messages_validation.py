from __future__ import annotations

import pytest

from wormhole_core.errors import ValidationError
from wormhole_core.schemas.messages import Message, MessageRole, validate_message


def test_validate_message_requires_parts() -> None:
    msg = Message(id="m1", role=MessageRole.USER, parts=[])
    with pytest.raises(ValidationError):
        validate_message(msg)
