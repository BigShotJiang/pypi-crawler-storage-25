from __future__ import annotations

import builtins
from pathlib import Path
from typing import Any, cast

import pytest

from wormhole_core.errors import LoopgraphError
from wormhole_core.graph import requirements as req


def test_parse_version_and_try_version() -> None:
    assert req._parse_version("1.2.3") == (1, 2, 3)
    assert req._parse_version("invalid") == (0, 0, 0)
    assert req._try_version("not-a-real-package-xyz") is None


def test_extract_version_from_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    with_version = tmp_path / "pyproject.toml"
    with_version.write_text('version = "9.9.9"\n')

    class DummyMatch:
        def group(self: Any, _index: int) -> str:
            return "9.9.9"

    req_module = cast(Any, req)
    monkeypatch.setattr(req_module.re, "search", lambda *_args, **_kwargs: DummyMatch())
    assert req._extract_version(with_version) == "9.9.9"


def test_extract_version_without_match(tmp_path: Path) -> None:
    without_version = tmp_path / "no-version.toml"
    without_version.write_text("[tool.example]\nname = 'demo'\n")
    assert req._extract_version(without_version) is None


def test_extract_version_read_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    target = tmp_path / "pyproject.toml"
    target.write_text('version = "1.0.0"\n')

    def _raise_read_text(self: Path) -> str:
        raise OSError("blocked")

    monkeypatch.setattr(Path, "read_text", _raise_read_text)
    assert req._extract_version(target) is None


def test_read_version_from_source_import_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    real_import = builtins.__import__

    def _blocked_import(name: str, *args: Any, **kwargs: Any) -> Any:
        if name.startswith("loopgraph"):
            raise ImportError("blocked")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _blocked_import)
    assert req._read_version_from_source() is None


def test_read_version_from_source_success() -> None:
    version = req._read_version_from_source()
    expected_path = Path(
        "/Users/borui/Devs/open-source-general-agents/wormhole/loopgraph/pyproject.toml"
    )
    if version is not None and expected_path.exists():
        expected = None
        for line in expected_path.read_text().splitlines():
            if line.strip().startswith("version") and "=" in line:
                expected = line.split("=", 1)[1].strip().strip('"')
                break
        if expected is not None:
            assert version == expected


def test_resolve_version_from_source(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(req, "_try_version", lambda _: None)
    monkeypatch.setattr(req, "_read_version_from_source", lambda: "0.1.0")
    assert req._resolve_version() == "0.1.0"


def test_resolve_version_missing_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(req, "_try_version", lambda _: None)
    monkeypatch.setattr(req, "_read_version_from_source", lambda: None)
    with pytest.raises(LoopgraphError):
        req._resolve_version()


def test_ensure_loopgraph_available_import_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    real_import = builtins.__import__

    def _blocked_import(name: str, *args: Any, **kwargs: Any) -> Any:
        if name.startswith("loopgraph"):
            raise ImportError("blocked")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _blocked_import)
    with pytest.raises(LoopgraphError):
        req.ensure_loopgraph_available()


def test_ensure_loopgraph_available_incompatible_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(req, "_resolve_version", lambda: "9.9.9")
    with pytest.raises(LoopgraphError):
        req.ensure_loopgraph_available()
