from __future__ import annotations

from typing import Any, cast

import pytest

from wormhole_core.config import ConfigSources
from wormhole_core.errors import NotFoundError, PermissionDeniedError, SchedulerError
from wormhole_core.events.types import EventType
from wormhole_core.graph.function_registry import SessionFunctionRegistry
from wormhole_core.loop.session_api import (
    SessionManager,
    _dispatch_tools,
    _ensure_tool_handlers,
)
from wormhole_core.schemas.session import ExecutionStateSnapshot, SessionConfig
from wormhole_core.schemas.tools import ToolCall, ToolDefinition
from wormhole_core.storage.execution_state_store import (
    ExecutionStateStore,
    LoopgraphSnapshotStore,
)
from wormhole_core.tools.registry import ToolRegistry


@pytest.mark.asyncio
async def test_session_manager_compaction_snapshot_and_stream() -> None:
    manager = SessionManager()
    handle = await manager.start_session(SessionConfig())
    manager.set_compaction_snapshot(handle.session.session_id, "snap-1")
    assert manager.get_prompt_snapshot(handle.session.session_id) == "snap-1"
    assert manager.get_stream(handle.session.session_id) is handle.stream


def test_get_stream_unknown_session_raises() -> None:
    manager = SessionManager()
    with pytest.raises(NotFoundError):
        manager.get_stream("missing")


@pytest.mark.asyncio
async def test_start_session_uses_config_sources() -> None:
    sources = ConfigSources(
        env={"retention_days": 2},
        user={"retention_days": 10},
        workspace={},
        sdk={},
    )
    manager = SessionManager()
    handle = await manager.start_session(config_sources=sources)
    assert handle.session.retention_expires_at is not None
    delta = handle.session.retention_expires_at - handle.session.created_at
    assert delta == 2 * 86400


@pytest.mark.asyncio
async def test_step_session_rejects_disallowed_tool_call() -> None:
    registry = ToolRegistry()
    registry.register(
        ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
    )
    manager = SessionManager(tool_registry=registry)
    handle = await manager.start_session(SessionConfig(allowlisted_tools=[]))
    call = ToolCall(tool_call_id="call-1", tool_id="t1")
    with pytest.raises(PermissionDeniedError):
        await manager.step_session(handle.session.session_id, tool_call_results=[call])


def test_dispatch_tools_helpers() -> None:
    assert _dispatch_tools({"tool_ids": ["t1"]}) == "t1"
    assert _dispatch_tools({"tool_ids": []}) == "done"
    assert _dispatch_tools("not-a-dict") == "done"


def test_ensure_tool_handlers_registers_missing() -> None:
    registry = SessionFunctionRegistry()
    _ensure_tool_handlers(registry, ["t1"])
    handler = registry.get("tool:t1")
    assert handler({"value": 1}) == {"tool_id": "t1", "payload": {"value": 1}}


@pytest.mark.asyncio
async def test_start_session_uses_execution_state_store(
    tmp_path: Any, monkeypatch: Any
) -> None:
    monkeypatch.setattr(
        "wormhole_core.storage.execution_state_store.metadata.version",
        lambda _name: "0.1.0",
    )
    store = ExecutionStateStore(tmp_path)
    manager = SessionManager(execution_state_store=store)
    handle = await manager.start_session(SessionConfig())
    runtime = manager._sessions[handle.session.session_id]
    snapshot_store = runtime.graph_runtime._scheduler._snapshot_store
    assert isinstance(snapshot_store, LoopgraphSnapshotStore)


@pytest.mark.asyncio
async def test_resume_session_emits_event() -> None:
    manager = SessionManager()
    handle = await manager.start_session(SessionConfig())
    snapshot = ExecutionStateSnapshot(
        execution_state_id="exec-1",
        graph_id="graph-1",
        snapshot_version="0.1.0",
        data={"states": {}},
        captured_at=100.0,
    )
    session = await manager.resume_session(handle.session.session_id, snapshot)
    assert session.execution_state_id == "exec-1"
    assert session.graph_id == "graph-1"
    iterator = handle.stream.__aiter__()
    await iterator.__anext__()
    event = await iterator.__anext__()
    assert event.type is EventType.SESSION_RESUMED


@pytest.mark.asyncio
async def test_step_session_scheduler_error_marks_session_failed() -> None:
    """Test that SchedulerError during step marks session as failed."""

    class _Adapter:
        async def stream(self: Any, payload: dict[str, Any]) -> dict[str, Any]:
            return payload

    manager = SessionManager(model_adapter=cast(Any, _Adapter()))
    handle = await manager.start_session(SessionConfig())

    # Patch the graph_runtime to raise SchedulerError
    runtime = manager._sessions[handle.session.session_id]

    async def failing_run(*args: Any, **kwargs: Any) -> Any:
        raise SchedulerError("test scheduler failure", {"test": True})

    runtime_any = cast(Any, runtime.graph_runtime)
    runtime_any.run = failing_run

    with pytest.raises(SchedulerError):
        await manager.step_session(handle.session.session_id, input="test")

    # Verify session is marked as failed
    from wormhole_core.schemas.session import SessionStatus

    assert runtime.session.status == SessionStatus.FAILED
