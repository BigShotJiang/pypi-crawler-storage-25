"""Configuration resolution helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class ConfigSources:
    """Configuration sources ordered by precedence."""

    env: Mapping[str, Any]
    user: Mapping[str, Any]
    workspace: Mapping[str, Any]
    sdk: Mapping[str, Any]


def resolve_config(sources: ConfigSources) -> dict[str, Any]:
    """Resolve configuration using env -> user -> workspace -> SDK precedence.

    >>> sources = ConfigSources(env={"a": 1}, user={"a": 2}, workspace={"b": 3}, sdk={"c": 4})
    >>> resolved = resolve_config(sources)
    >>> resolved["a"], resolved["b"], resolved["c"]
    (1, 3, 4)
    """
    resolved: dict[str, Any] = {}
    for layer in (sources.sdk, sources.workspace, sources.user, sources.env):
        resolved.update(layer)
    return resolved
