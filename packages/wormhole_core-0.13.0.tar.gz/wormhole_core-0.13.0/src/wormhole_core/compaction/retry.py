"""Async retry helpers for compaction."""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, TypeVar

_T = TypeVar("_T")


async def retry_async(
    func: Callable[[], Awaitable[_T]],
    *,
    max_retries: int,
    initial_backoff_s: float,
    multiplier: float = 2.0,
    max_backoff_s: float | None = None,
) -> _T:
    """Retry an async callable with exponential backoff.

    >>> import asyncio
    >>> calls = {"count": 0}
    >>> async def _flaky() -> int:
    ...     calls["count"] += 1
    ...     if calls["count"] < 2:
    ...         raise ValueError("boom")
    ...     return 7
    >>> asyncio.run(retry_async(_flaky, max_retries=2, initial_backoff_s=0.0))
    7
    """
    attempt = 0
    backoff = initial_backoff_s
    while True:
        try:
            return await func()
        except Exception:
            attempt += 1
            if attempt > max_retries:
                raise
            if backoff > 0:
                await asyncio.sleep(backoff)
            backoff *= multiplier
            if max_backoff_s is not None:
                backoff = min(backoff, max_backoff_s)
