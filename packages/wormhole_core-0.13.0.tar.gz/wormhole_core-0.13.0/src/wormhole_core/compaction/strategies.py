"""Built-in compaction strategies."""

from __future__ import annotations

from typing import Sequence

from wormhole_core.compaction.context import CompactionContext
from wormhole_core.compaction.protocols import SummarizationStrategy
from wormhole_core.schemas.messages import Message


class NoOpSummarizationStrategy(SummarizationStrategy):
    """No-op summarizer that returns an empty string.

    >>> import asyncio
    >>> from wormhole_core.compaction.context import CompactionContext
    >>> from wormhole_core.schemas.session import CompactionConfig, CompactionStage
    >>> strategy = NoOpSummarizationStrategy()
    >>> ctx = CompactionContext(
    ...     session_id="s1",
    ...     snapshot_id="snap-1",
    ...     config=CompactionConfig(),
    ...     stage=CompactionStage.PRUNING,
    ...     pruned_count=0,
    ...     remaining_token_estimate=0,
    ... )
    >>> asyncio.run(strategy.summarize([], ctx))
    ''
    """

    async def summarize(
        self, messages: Sequence[Message], context: CompactionContext
    ) -> str:
        return ""
