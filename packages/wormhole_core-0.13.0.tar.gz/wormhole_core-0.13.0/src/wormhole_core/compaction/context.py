"""Compaction context objects."""

from __future__ import annotations

from dataclasses import dataclass

from wormhole_core.schemas.session import CompactionConfig, CompactionStage


@dataclass(frozen=True)
class CompactionContext:
    """Context passed to compaction strategies and hooks.

    >>> ctx = CompactionContext(
    ...     session_id="s1",
    ...     snapshot_id="snap-1",
    ...     config=CompactionConfig(),
    ...     stage=CompactionStage.PRUNING,
    ...     pruned_count=2,
    ...     remaining_token_estimate=1000,
    ... )
    >>> ctx.stage
    <CompactionStage.PRUNING: 'pruning'>
    """

    session_id: str
    snapshot_id: str
    config: CompactionConfig
    stage: CompactionStage
    pruned_count: int
    remaining_token_estimate: int
