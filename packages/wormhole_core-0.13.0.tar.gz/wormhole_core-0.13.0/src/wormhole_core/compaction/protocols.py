"""Compaction protocol interfaces."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, Sequence, runtime_checkable

if TYPE_CHECKING:
    from wormhole_core.compaction.context import CompactionContext
    from wormhole_core.schemas.messages import Message


@runtime_checkable
class SummarizationStrategy(Protocol):
    """Protocol for pluggable summarization implementations.

    Implementations must be async and accept messages with context.

    >>> class DemoStrategy:
    ...     async def summarize(self, messages, context):
    ...         return "ok"
    >>> isinstance(DemoStrategy(), SummarizationStrategy)
    True
    """

    async def summarize(
        self,
        messages: Sequence[Message],
        context: CompactionContext,
    ) -> str:
        """Generate a summary of the given messages.

        Args:
            messages: Messages to summarize (already pruned).
            context: Compaction context with session info and config.

        Returns:
            Summary text to store in the compaction message for context reconstruction.
            May return empty string if no summary is needed.
        """
        ...
