"""Compaction result types."""

from __future__ import annotations

from dataclasses import dataclass

from wormhole_core.schemas.session import CompactionStage


@dataclass(frozen=True)
class CompactionResult:
    """Result of a compaction operation.

    >>> res = CompactionResult(
    ...     session_id="s1",
    ...     snapshot_id="snap-1",
    ...     stage=CompactionStage.COMPLETED,
    ...     pruned_message_count=0,
    ...     pruned_token_estimate=0,
    ...     summary_generated=False,
    ... )
    >>> res.summary_generated
    False
    """

    session_id: str
    snapshot_id: str
    stage: CompactionStage
    pruned_message_count: int
    pruned_token_estimate: int
    summary_generated: bool
    error_message: str | None = None
