"""Compaction helpers and types."""

from __future__ import annotations

from .context import CompactionContext
from .protocols import SummarizationStrategy
from .strategies import NoOpSummarizationStrategy
from .types import CompactionResult

__all__ = [
    "CompactionContext",
    "CompactionResult",
    "NoOpSummarizationStrategy",
    "SummarizationStrategy",
]
