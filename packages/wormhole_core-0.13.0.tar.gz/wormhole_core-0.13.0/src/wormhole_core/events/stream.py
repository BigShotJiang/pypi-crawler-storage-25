"""Event stream helpers for SDK consumption."""

from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator, Generic, TypeVar

from loopgraph.bus.eventbus import EventBus, EventListener

from ..backpressure import BackpressureConfig, BackpressureMetrics, BackpressureStrategy
from ..errors import BackpressureError, EngineError, ErrorCode
from ..logging import log_loop_iteration, log_parameter, log_variable_change
from .transform import transform_event
from .types import CoreEvent, EventType

_T = TypeVar("_T")


class EventStream(Generic[_T]):
    """Async iterator for events.

    Generic over event type to support both CoreEvent and custom envelope types.
    """

    def __init__(self, backpressure: BackpressureConfig | None = None) -> None:
        log_parameter("EventStream.__init__")
        self._backpressure = backpressure
        max_size = backpressure.max_size if backpressure else 0
        self._queue: asyncio.Queue[_T] = asyncio.Queue(maxsize=max_size)
        self._drops_count = 0
        log_variable_change("EventStream.__init__", "_queue", None, self._queue)

    async def publish(self, event: _T) -> None:
        """Publish an event into the stream."""
        session_id = getattr(event, "session_id", "unknown")
        log_parameter("EventStream.publish", event=event, call_id=session_id)
        before_size = self._queue.qsize()
        if self._backpressure is None:
            self._queue.put_nowait(event)
            after_size = self._queue.qsize()
            log_variable_change(
                "EventStream.publish",
                "queue_size",
                before_size,
                after_size,
                call_id=session_id,
            )
            return

        if (
            self._backpressure.strategy is BackpressureStrategy.FAIL
            and self._queue.full()
        ):
            self._on_backpressure()
            raise BackpressureError("event stream queue full", self.metrics)

        if (
            self._backpressure.strategy is BackpressureStrategy.DROP_OLDEST
            and self._queue.full()
        ):
            _ = self._queue.get_nowait()
            self._drops_count += 1
            self._queue.put_nowait(event)
            self._on_backpressure()
        elif (
            self._backpressure.strategy is BackpressureStrategy.BLOCK
            and self._queue.full()
        ):
            await self._queue.put(event)
            self._on_backpressure()
        else:
            self._queue.put_nowait(event)

        after_size = self._queue.qsize()
        log_variable_change(
            "EventStream.publish",
            "queue_size",
            before_size,
            after_size,
            call_id=session_id,
        )

    async def __aiter__(self) -> AsyncIterator[_T]:
        iteration = 0
        while True:
            iteration += 1
            log_loop_iteration("EventStream.__aiter__", "events", iteration)
            log_parameter("EventStream.__aiter__")
            event = await self._queue.get()
            session_id = getattr(event, "session_id", "unknown")
            log_variable_change(
                "EventStream.__aiter__", "event", None, event, call_id=session_id
            )
            yield event

    @property
    def metrics(self) -> BackpressureMetrics:
        max_size = self._queue.maxsize
        return BackpressureMetrics(
            current_size=self._queue.qsize(),
            max_size=max_size,
            drops_count=self._drops_count,
        )

    def is_bounded(self) -> bool:
        return self._queue.maxsize > 0

    def _on_backpressure(self) -> None:
        """Hook for subclasses to handle backpressure events."""
        pass


class CoreEventStream(EventStream[CoreEvent]):
    """Specialized EventStream for CoreEvent with event bus binding support."""

    def bind_event_bus(self, bus: EventBus, session_id: str) -> EventListener:
        """Subscribe to an EventBus and forward events into this stream."""
        log_parameter(
            "CoreEventStream.bind_event_bus", session_id=session_id, call_id=session_id
        )

        async def _listener(event: Any) -> None:
            try:
                await self.publish(transform_event(event, session_id))
            except Exception as exc:
                error_event = CoreEvent(
                    session_id=session_id,
                    type=EventType.SESSION_FAILED,
                    payload={"message": str(exc)},
                    error_code=ErrorCode.ENGINE_ERROR.value,
                )
                await self.publish(error_event)
                raise

        try:
            bus.subscribe(None, _listener)
        except Exception as exc:
            raise EngineError(
                "event bus subscription failed", {"session_id": session_id}
            ) from exc
        return _listener

    def unbind_event_bus(self, bus: EventBus, listener: EventListener) -> None:
        """Remove a previously bound EventBus listener."""
        log_parameter("CoreEventStream.unbind_event_bus")
        try:
            bus.unsubscribe(None, listener)
        except Exception as exc:
            raise EngineError("event bus unsubscribe failed", {}) from exc

    def _on_backpressure(self) -> None:
        """Emit a backpressure event into the stream."""
        event = CoreEvent(
            session_id="system",
            type=EventType.BACKPRESSURE_ACTIVATED,
            payload={
                "strategy": self._backpressure.strategy.value
                if self._backpressure
                else None,
                "queue_size": self._queue.qsize(),
                "max_size": self._queue.maxsize,
                "dropped_count": self._drops_count,
            },
        )
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            return
