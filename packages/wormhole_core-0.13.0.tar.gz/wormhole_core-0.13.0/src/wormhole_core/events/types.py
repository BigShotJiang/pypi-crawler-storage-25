"""Event types and payload schema."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class EventType(str, Enum):
    """Core event types emitted by the loop.

    >>> EventType.SESSION_BUSY.value
    'session_busy'
    >>> EventType.QUEUE_FULL.value
    'queue_full'
    """

    SESSION_STARTED = "session_started"
    SESSION_STEP = "session_step"
    SESSION_COMPLETED = "session_completed"
    SESSION_FAILED = "session_failed"
    SESSION_RESUMED = "session_resumed"
    SESSION_BUSY = "session_busy"
    QUEUE_FULL = "queue_full"
    AWAITING_USER_INPUT = "awaiting_user_input"
    AWAITING_TOOL_RESULT = "awaiting_tool_result"
    TOOL_CALL_CREATED = "tool_call_created"
    TOOL_CALL_COMPLETED = "tool_call_completed"
    TOOL_INVOKED = "tool_invoked"
    NODE_SCHEDULED = "node_scheduled"
    NODE_COMPLETED = "node_completed"
    NODE_FAILED = "node_failed"
    COMPACTION_STARTED = "compaction_started"
    COMPACTION_COMPLETED = "compaction_completed"
    FORK_STARTED = "fork_started"
    FORK_COMPLETED = "fork_completed"
    APPROVAL_REQUESTED = "approval_requested"
    APPROVAL_GRANTED = "approval_granted"
    APPROVAL_DENIED = "approval_denied"
    APPROVAL_PERSISTENCE_ERROR = "approval_persistence_error"
    HOOK_FAILED = "hook_failed"
    BACKPRESSURE_ACTIVATED = "backpressure_activated"


@dataclass(frozen=True)
class CoreEvent:
    """Core event record.

    >>> evt = CoreEvent(session_id="s1", type=EventType.SESSION_STARTED)
    >>> evt.type
    <EventType.SESSION_STARTED: 'session_started'>
    """

    session_id: str
    type: EventType
    payload: Any = None
    event_id: str | None = None
    node_id: str | None = None
    timestamp: float = field(default_factory=lambda: time.time())
    error_code: str | None = None
