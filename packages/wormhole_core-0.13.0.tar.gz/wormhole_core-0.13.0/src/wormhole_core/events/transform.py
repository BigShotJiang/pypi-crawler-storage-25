"""Transform loopgraph events into CoreEvent instances."""

from __future__ import annotations

import time
from typing import Any, Mapping

from loopgraph.bus.eventbus import Event as LoopgraphEvent
from loopgraph.core.types import EventType as LoopgraphEventType

from ..storage.event_log_store import EVENT_LOG_SCHEMA_VERSION, EventLogEntry
from .types import CoreEvent, EventType

_EVENT_TYPE_MAP = {
    LoopgraphEventType.NODE_SCHEDULED: EventType.NODE_SCHEDULED,
    LoopgraphEventType.NODE_COMPLETED: EventType.NODE_COMPLETED,
    LoopgraphEventType.NODE_FAILED: EventType.NODE_FAILED,
    LoopgraphEventType.WORKFLOW_COMPLETED: EventType.SESSION_COMPLETED,
}


def transform_event(event: LoopgraphEvent, session_id: str) -> CoreEvent:
    """Convert a loopgraph event into a CoreEvent."""
    mapped = _EVENT_TYPE_MAP.get(event.type)
    if mapped is None:
        mapped = EventType.SESSION_STEP
    payload: Mapping[str, Any] = {
        "graph_id": event.graph_id,
        "payload": event.payload,
        "status": event.status.value if event.status else None,
        "visit_count": event.visit_count,
        "replay": event.replay,
    }
    return CoreEvent(
        session_id=session_id,
        type=mapped,
        payload=payload,
        event_id=event.id,
        node_id=event.node_id,
    )


def event_to_log_entry(event: LoopgraphEvent, session_id: str) -> EventLogEntry:
    """Convert a loopgraph event into a persisted log entry."""
    status = event.status.value if event.status else None
    return EventLogEntry(
        session_id=session_id,
        graph_id=getattr(event, "graph_id", None),
        event_id=getattr(event, "id", None),
        node_id=getattr(event, "node_id", None),
        event_type=_event_type_value(event.type),
        payload=_normalize_payload(event.payload),
        status=status,
        visit_count=getattr(event, "visit_count", None),
        replay=getattr(event, "replay", None),
        recorded_at=time.time(),
        schema_version=EVENT_LOG_SCHEMA_VERSION,
    )


def _event_type_value(event_type: object) -> str:
    value = getattr(event_type, "value", None)
    if value is None:
        return str(event_type)
    return str(value)


def _normalize_payload(payload: object) -> dict[str, Any] | None:
    if payload is None:
        return None
    if isinstance(payload, dict):
        return payload
    return {"value": payload}
