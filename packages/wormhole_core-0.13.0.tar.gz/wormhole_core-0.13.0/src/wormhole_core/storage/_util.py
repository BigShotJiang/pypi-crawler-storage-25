"""Shared storage utilities for file-based persistence."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path


def _atomic_write(target_path: Path, content: str) -> None:
    """Write content to a file atomically using write-then-rename.

    >>> import tempfile
    >>> from pathlib import Path
    >>> root = Path(tempfile.mkdtemp())
    >>> target = root / "payload.json"
    >>> _atomic_write(target, '{"ok":true}')
    >>> target.read_text() == '{"ok":true}'
    True
    """
    target_dir = target_path.parent
    fd, tmp_path = tempfile.mkstemp(
        suffix=".tmp",
        prefix=".wormhole_",
        dir=str(target_dir),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content)
        os.replace(tmp_path, str(target_path))
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
