"""ExecutionState snapshot persistence."""

from __future__ import annotations

import asyncio
import json
import os
import time
from contextlib import contextmanager
from importlib import metadata
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

from loopgraph.persistence import SnapshotStore

from ..errors import NotFoundError, PersistenceError
from ..logging import log_branch, log_loop_iteration, log_parameter, log_timing
from ..schemas.session import ExecutionStateSnapshot
from ._util import _atomic_write


@contextmanager
def _file_lock(
    lock_path: Path,
    *,
    timeout_s: float = 5.0,
    retries: int = 3,
    backoff_s: Sequence[float] = (0.1, 0.2, 0.4),
    poll_interval_s: float = 0.01,
    call_id: str = "unknown",
) -> Iterator[None]:
    """Acquire an exclusive lock file for execution state.

    >>> import tempfile
    >>> from pathlib import Path
    >>> lock_root = Path(tempfile.mkdtemp())
    >>> lock = lock_root / "snapshot.lock"
    >>> with _file_lock(lock, timeout_s=0.1, retries=0):
    ...     lock.exists()
    True
    """
    log_parameter(
        "ExecutionStateStore._file_lock",
        lock_path=str(lock_path),
        timeout_s=timeout_s,
        retries=retries,
        call_id=call_id,
    )
    backoffs = list(backoff_s)
    total_backoff = sum(backoffs[:retries]) if retries > 0 else 0.0
    remaining = max(timeout_s - total_backoff, 0.0)
    attempt_timeout = remaining / (retries + 1)
    for attempt in range(retries + 1):
        log_loop_iteration(
            "ExecutionStateStore._file_lock", "attempt", attempt + 1, call_id=call_id
        )
        deadline = time.monotonic() + attempt_timeout
        while True:
            try:
                fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                if time.monotonic() >= deadline:
                    break
                time.sleep(poll_interval_s)
                continue
            try:
                log_branch(
                    "ExecutionStateStore._file_lock", "lock_acquired", call_id=call_id
                )
                yield
            finally:
                os.close(fd)
                lock_path.unlink(missing_ok=True)
            return
        if attempt < retries:
            backoff = backoffs[min(attempt, len(backoffs) - 1)] if backoffs else 0.0
            if backoff:
                log_branch(
                    "ExecutionStateStore._file_lock", "lock_backoff", call_id=call_id
                )
                time.sleep(backoff)
    log_branch("ExecutionStateStore._file_lock", "lock_timeout", call_id=call_id)
    raise PersistenceError(
        "failed to acquire execution state lock",
        {"lock": str(lock_path), "timeout_s": timeout_s, "retries": retries},
    )


class ExecutionStateStore:
    """Persist loopgraph ExecutionState snapshots."""

    def __init__(self, root: Path, runtime_version: str | None = None) -> None:
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)
        self._runtime_version = runtime_version or metadata.version("loopgraph")

    async def save(self, snapshot: ExecutionStateSnapshot) -> None:
        """Persist a snapshot asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> snapshot = ExecutionStateSnapshot(
        ...     execution_state_id="exec-1",
        ...     graph_id="graph-1",
        ...     snapshot_version="1.0.0",
        ...     data={"ok": True},
        ...     captured_at=1.0,
        ... )
        >>> store = ExecutionStateStore(Path(tempfile.mkdtemp()), runtime_version="1.0.0")
        >>> asyncio.run(store.save(snapshot))
        """
        await asyncio.to_thread(self._sync_save, snapshot)

    def _sync_save(self, snapshot: ExecutionStateSnapshot) -> None:
        """Persist a snapshot (sync path)."""
        snapshot_id = snapshot.execution_state_id
        log_parameter(
            "ExecutionStateStore._sync_save",
            execution_state_id=snapshot_id,
            call_id=snapshot_id,
        )
        started = time.monotonic()
        path = self._path(snapshot.execution_state_id)
        lock = path.with_suffix(".lock")
        payload = _snapshot_to_dict(snapshot)
        try:
            with _file_lock(lock, call_id=snapshot_id):
                _atomic_write(
                    path,
                    json.dumps(
                        _json_safe(payload), separators=(",", ":"), sort_keys=True
                    ),
                )
            log_branch("ExecutionStateStore._sync_save", "save_ok", call_id=snapshot_id)
        except PersistenceError:
            log_branch(
                "ExecutionStateStore._sync_save",
                "save_lock_timeout",
                call_id=snapshot_id,
            )
            raise
        except OSError as exc:
            log_branch(
                "ExecutionStateStore._sync_save", "save_os_error", call_id=snapshot_id
            )
            raise PersistenceError(
                "failed to persist execution snapshot",
                {"path": str(path), "execution_state_id": snapshot_id},
            ) from exc
        finally:
            log_timing(
                "ExecutionStateStore._sync_save",
                (time.monotonic() - started) * 1000,
                call_id=snapshot_id,
            )

    async def load(self, execution_state_id: str) -> ExecutionStateSnapshot:
        """Load a snapshot asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> snapshot = ExecutionStateSnapshot(
        ...     execution_state_id="exec-2",
        ...     graph_id="graph-2",
        ...     snapshot_version="1.0.0",
        ...     data={"ok": True},
        ...     captured_at=1.0,
        ... )
        >>> store = ExecutionStateStore(Path(tempfile.mkdtemp()), runtime_version="1.0.0")
        >>> asyncio.run(store.save(snapshot))
        >>> loaded = asyncio.run(store.load("exec-2"))
        >>> loaded.execution_state_id
        'exec-2'
        """
        return await asyncio.to_thread(self._sync_load, execution_state_id)

    def _sync_load(self, execution_state_id: str) -> ExecutionStateSnapshot:
        """Load a snapshot (sync path)."""
        log_parameter(
            "ExecutionStateStore._sync_load",
            execution_state_id=execution_state_id,
            call_id=execution_state_id,
        )
        started = time.monotonic()
        try:
            path = self._path(execution_state_id)
            if not path.exists():
                log_branch(
                    "ExecutionStateStore._sync_load",
                    "snapshot_missing",
                    call_id=execution_state_id,
                )
                raise NotFoundError(
                    "execution snapshot not found",
                    {"execution_state_id": execution_state_id},
                )
            lock = path.with_suffix(".lock")
            try:
                with _file_lock(lock, call_id=execution_state_id):
                    data = json.loads(path.read_text(encoding="utf-8"))
            except PersistenceError:
                log_branch(
                    "ExecutionStateStore._sync_load",
                    "load_lock_timeout",
                    call_id=execution_state_id,
                )
                raise
            except OSError as exc:
                log_branch(
                    "ExecutionStateStore._sync_load",
                    "load_os_error",
                    call_id=execution_state_id,
                )
                raise PersistenceError(
                    "failed to read execution snapshot",
                    {"path": str(path), "execution_state_id": execution_state_id},
                ) from exc
            except json.JSONDecodeError as exc:
                log_branch(
                    "ExecutionStateStore._sync_load",
                    "load_decode_error",
                    call_id=execution_state_id,
                )
                raise PersistenceError(
                    "failed to decode execution snapshot",
                    {"path": str(path), "execution_state_id": execution_state_id},
                ) from exc
            try:
                snapshot = _snapshot_from_dict(data)
            except (KeyError, TypeError, ValueError) as exc:
                log_branch(
                    "ExecutionStateStore._sync_load",
                    "load_parse_error",
                    call_id=execution_state_id,
                )
                raise PersistenceError(
                    "failed to parse execution snapshot",
                    {"path": str(path), "execution_state_id": execution_state_id},
                ) from exc
            if not _is_compatible_version(
                snapshot.snapshot_version, self._runtime_version
            ):
                log_branch(
                    "ExecutionStateStore._sync_load",
                    "version_mismatch",
                    call_id=execution_state_id,
                )
                raise PersistenceError(
                    "snapshot version mismatch",
                    {
                        "snapshot_version": snapshot.snapshot_version,
                        "runtime_version": self._runtime_version,
                        "execution_state_id": execution_state_id,
                    },
                )
            return snapshot
        finally:
            log_timing(
                "ExecutionStateStore._sync_load",
                (time.monotonic() - started) * 1000,
                call_id=execution_state_id,
            )

    def _path(self, execution_state_id: str) -> Path:
        return self._root / f"{execution_state_id}.json"


def _snapshot_to_dict(snapshot: ExecutionStateSnapshot) -> dict[str, Any]:
    return {
        "execution_state_id": snapshot.execution_state_id,
        "graph_id": snapshot.graph_id,
        "snapshot_version": snapshot.snapshot_version,
        "data": snapshot.data,
        "captured_at": snapshot.captured_at,
    }


def _snapshot_from_dict(data: dict[str, Any]) -> ExecutionStateSnapshot:
    return ExecutionStateSnapshot(
        execution_state_id=data["execution_state_id"],
        graph_id=data["graph_id"],
        snapshot_version=data["snapshot_version"],
        data=data.get("data", {}),
        captured_at=float(data["captured_at"]),
    )


def _json_safe(value: Any) -> Any:
    """Convert nested structures to JSON-serializable primitives."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(item) for item in value]
    enum_value = getattr(value, "value", None)
    if isinstance(enum_value, (str, int, float, bool)):
        return enum_value
    return repr(value)


class LoopgraphSnapshotStore(SnapshotStore):
    """Adapter that stores loopgraph snapshots in ExecutionStateStore."""

    def __init__(
        self, store: ExecutionStateStore, snapshot_version: str | None = None
    ) -> None:
        self._store = store
        self._snapshot_version = snapshot_version or metadata.version("loopgraph")

    def save(self, graph_id: str, snapshot: Mapping[str, object]) -> None:
        payload = ExecutionStateSnapshot(
            execution_state_id=graph_id,
            graph_id=graph_id,
            snapshot_version=self._snapshot_version,
            data=dict(snapshot),
            captured_at=time.time(),
        )
        self._store._sync_save(payload)

    def load(self, graph_id: str) -> Mapping[str, object]:
        try:
            snapshot = self._store._sync_load(graph_id)
        except NotFoundError as exc:
            raise KeyError(graph_id) from exc
        return snapshot.data


def _is_compatible_version(snapshot_version: str, runtime_version: str) -> bool:
    if snapshot_version == runtime_version:
        return True
    snapshot_parts = _parse_version(snapshot_version)
    runtime_parts = _parse_version(runtime_version)
    if snapshot_parts is None or runtime_parts is None:
        return False
    return snapshot_parts == runtime_parts


def _parse_version(version: str) -> tuple[int, int] | None:
    parts = version.split(".")
    if len(parts) < 2:
        return None
    try:
        return int(parts[0]), int(parts[1])
    except ValueError:
        return None
