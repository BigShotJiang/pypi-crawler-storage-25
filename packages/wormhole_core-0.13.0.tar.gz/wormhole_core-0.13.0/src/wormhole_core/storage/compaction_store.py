"""Compaction snapshot storage."""

from __future__ import annotations

import asyncio
import json
import os
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterable, Iterator, Sequence

from ..errors import NotFoundError, PersistenceError
from ..logging import log_branch, log_loop_iteration, log_parameter, log_timing
from ..schemas.session import CompactionSnapshot, CompactionStage
from ._util import _atomic_write


@contextmanager
def _file_lock(
    lock_path: Path,
    *,
    timeout_s: float = 5.0,
    retries: int = 3,
    backoff_s: Sequence[float] = (0.1, 0.2, 0.4),
    poll_interval_s: float = 0.01,
    call_id: str = "unknown",
) -> Iterator[None]:
    """Acquire an exclusive lock file for compaction snapshots.

    >>> import tempfile
    >>> from pathlib import Path
    >>> lock_root = Path(tempfile.mkdtemp())
    >>> lock = lock_root / "compaction.lock"
    >>> with _file_lock(lock, timeout_s=0.1, retries=0):
    ...     lock.exists()
    True
    """
    log_parameter(
        "CompactionStore._file_lock",
        lock_path=str(lock_path),
        timeout_s=timeout_s,
        retries=retries,
        call_id=call_id,
    )
    backoffs = list(backoff_s)
    total_backoff = sum(backoffs[:retries]) if retries > 0 else 0.0
    remaining = max(timeout_s - total_backoff, 0.0)
    attempt_timeout = remaining / (retries + 1)
    for attempt in range(retries + 1):
        log_loop_iteration(
            "CompactionStore._file_lock", "attempt", attempt + 1, call_id=call_id
        )
        deadline = time.monotonic() + attempt_timeout
        while True:
            try:
                fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                if time.monotonic() >= deadline:
                    break
                time.sleep(poll_interval_s)
                continue
            try:
                log_branch(
                    "CompactionStore._file_lock", "lock_acquired", call_id=call_id
                )
                yield
            finally:
                os.close(fd)
                lock_path.unlink(missing_ok=True)
            return
        if attempt < retries:
            backoff = backoffs[min(attempt, len(backoffs) - 1)] if backoffs else 0.0
            if backoff:
                log_branch(
                    "CompactionStore._file_lock", "lock_backoff", call_id=call_id
                )
                time.sleep(backoff)
    log_branch("CompactionStore._file_lock", "lock_timeout", call_id=call_id)
    raise PersistenceError(
        "failed to acquire compaction lock",
        {"lock": str(lock_path), "timeout_s": timeout_s, "retries": retries},
    )


class CompactionStore:
    """Persist compaction snapshots to JSON files."""

    def __init__(self, root: Path) -> None:
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)

    async def save(self, snapshot: CompactionSnapshot) -> None:
        """Persist a compaction snapshot asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> snapshot = CompactionSnapshot(
        ...     snapshot_id="snap-1",
        ...     session_id="s1",
        ...     created_at=1.0,
        ...     kept_files=[],
        ...     source_message_range=None,
        ...     stage=CompactionStage.COMPLETED,
        ...     pruned_message_count=0,
        ...     pruned_token_estimate=0,
        ...     compaction_message_id="msg-1",
        ... )
        >>> store = CompactionStore(Path(tempfile.mkdtemp()))
        >>> asyncio.run(store.save(snapshot))
        """
        await asyncio.to_thread(self._sync_save, snapshot)

    def _sync_save(self, snapshot: CompactionSnapshot) -> None:
        """Persist a compaction snapshot (sync path)."""
        snapshot_id = snapshot.snapshot_id
        log_parameter(
            "CompactionStore._sync_save", snapshot_id=snapshot_id, call_id=snapshot_id
        )
        started = time.monotonic()
        path = self._path(snapshot.snapshot_id)
        lock = path.with_suffix(".lock")
        payload = _snapshot_to_dict(snapshot)
        try:
            with _file_lock(lock, call_id=snapshot_id):
                _atomic_write(
                    path, json.dumps(payload, separators=(",", ":"), sort_keys=True)
                )
            log_branch("CompactionStore._sync_save", "save_ok", call_id=snapshot_id)
        except PersistenceError:
            log_branch(
                "CompactionStore._sync_save", "save_lock_timeout", call_id=snapshot_id
            )
            raise
        except OSError as exc:
            log_branch(
                "CompactionStore._sync_save", "save_os_error", call_id=snapshot_id
            )
            raise PersistenceError(
                "failed to persist compaction snapshot",
                {"path": str(path), "snapshot_id": snapshot_id},
            ) from exc
        finally:
            log_timing(
                "CompactionStore._sync_save",
                (time.monotonic() - started) * 1000,
                call_id=snapshot_id,
            )

    async def load(self, snapshot_id: str) -> CompactionSnapshot:
        """Load a compaction snapshot asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> snapshot = CompactionSnapshot(
        ...     snapshot_id="snap-2",
        ...     session_id="s1",
        ...     created_at=1.0,
        ...     kept_files=[],
        ...     source_message_range=None,
        ...     stage=CompactionStage.COMPLETED,
        ...     pruned_message_count=0,
        ...     pruned_token_estimate=0,
        ...     compaction_message_id="msg-2",
        ... )
        >>> store = CompactionStore(Path(tempfile.mkdtemp()))
        >>> asyncio.run(store.save(snapshot))
        >>> loaded = asyncio.run(store.load("snap-2"))
        >>> loaded.snapshot_id
        'snap-2'
        """
        return await asyncio.to_thread(self._sync_load, snapshot_id)

    def _sync_load(self, snapshot_id: str) -> CompactionSnapshot:
        """Load a compaction snapshot (sync path)."""
        log_parameter(
            "CompactionStore._sync_load", snapshot_id=snapshot_id, call_id=snapshot_id
        )
        started = time.monotonic()
        try:
            path = self._path(snapshot_id)
            if not path.exists():
                log_branch(
                    "CompactionStore._sync_load",
                    "snapshot_missing",
                    call_id=snapshot_id,
                )
                raise NotFoundError(
                    "compaction snapshot not found", {"snapshot_id": snapshot_id}
                )
            lock = path.with_suffix(".lock")
            try:
                with _file_lock(lock, call_id=snapshot_id):
                    data = json.loads(path.read_text(encoding="utf-8"))
            except PersistenceError:
                log_branch(
                    "CompactionStore._sync_load",
                    "load_lock_timeout",
                    call_id=snapshot_id,
                )
                raise
            except OSError as exc:
                log_branch(
                    "CompactionStore._sync_load", "load_os_error", call_id=snapshot_id
                )
                raise PersistenceError(
                    "failed to read compaction snapshot",
                    {"path": str(path), "snapshot_id": snapshot_id},
                ) from exc
            except json.JSONDecodeError as exc:
                log_branch(
                    "CompactionStore._sync_load",
                    "load_decode_error",
                    call_id=snapshot_id,
                )
                raise PersistenceError(
                    "failed to decode compaction snapshot",
                    {"path": str(path), "snapshot_id": snapshot_id},
                ) from exc
            return _snapshot_from_dict(data)
        finally:
            log_timing(
                "CompactionStore._sync_load",
                (time.monotonic() - started) * 1000,
                call_id=snapshot_id,
            )

    def _path(self, snapshot_id: str) -> Path:
        return self._root / f"{snapshot_id}.json"


def _snapshot_to_dict(snapshot: CompactionSnapshot) -> dict[str, object]:
    return {
        "snapshot_id": snapshot.snapshot_id,
        "session_id": snapshot.session_id,
        "created_at": snapshot.created_at,
        "kept_files": list(snapshot.kept_files),
        "source_message_range": snapshot.source_message_range,
        "stage": snapshot.stage.value,
        "pruned_message_count": snapshot.pruned_message_count,
        "pruned_token_estimate": snapshot.pruned_token_estimate,
        "compaction_message_id": snapshot.compaction_message_id,
    }


def _snapshot_from_dict(data: dict[str, object]) -> CompactionSnapshot:
    created_at = _coerce_float(data.get("created_at"), time.time())
    kept_files = _coerce_str_list(data.get("kept_files"))
    source_message_range = _coerce_range(data.get("source_message_range"))
    stage = _coerce_stage(data.get("stage"))
    pruned_message_count = _coerce_non_negative_int(data.get("pruned_message_count"))
    pruned_token_estimate = _coerce_non_negative_int(data.get("pruned_token_estimate"))
    compaction_message_id = _coerce_optional_str(data.get("compaction_message_id"))
    return CompactionSnapshot(
        snapshot_id=str(data["snapshot_id"]),
        session_id=str(data["session_id"]),
        created_at=created_at,
        kept_files=kept_files,
        source_message_range=source_message_range,
        stage=stage,
        pruned_message_count=pruned_message_count,
        pruned_token_estimate=pruned_token_estimate,
        compaction_message_id=compaction_message_id,
    )


def _coerce_float(value: object, default: float) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return default
    return default


def _coerce_str_list(value: object) -> list[str]:
    if isinstance(value, Iterable) and not isinstance(value, (str, bytes, dict)):
        return [str(item) for item in value]
    return []


def _coerce_range(value: object) -> tuple[int, int] | None:
    if isinstance(value, (list, tuple)) and len(value) == 2:
        try:
            return (int(value[0]), int(value[1]))
        except (TypeError, ValueError):
            return None
    return None


def _coerce_stage(value: object) -> CompactionStage:
    if isinstance(value, CompactionStage):
        return value
    if isinstance(value, str):
        try:
            return CompactionStage(value)
        except ValueError:
            return CompactionStage.PENDING
    return CompactionStage.PENDING


def _coerce_non_negative_int(value: object) -> int:
    if value is None:
        return 0
    if isinstance(value, bool):
        coerced = int(value)
    elif isinstance(value, (int, float)):
        coerced = int(value)
    elif isinstance(value, str):
        try:
            coerced = int(value)
        except ValueError:
            return 0
    else:
        return 0
    return coerced if coerced >= 0 else 0


def _coerce_optional_str(value: object) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None
