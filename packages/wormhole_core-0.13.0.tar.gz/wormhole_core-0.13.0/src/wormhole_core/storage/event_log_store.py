"""EventBus event log persistence."""

from __future__ import annotations

import asyncio
import datetime as dt
import json
import os
import time
from collections.abc import Mapping
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field, is_dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Iterator, Sequence

from ..errors import NotFoundError, PersistenceError
from ..events.types import EventType
from ..logging import log_branch, log_loop_iteration, log_parameter, log_timing

EVENT_LOG_SCHEMA_VERSION = "1"


@dataclass(frozen=True)
class EventLogEntry:
    """Persisted EventBus event record."""

    session_id: str
    graph_id: str | None
    event_id: str | None
    node_id: str | None
    event_type: str
    payload: dict[str, Any] | None
    status: str | None
    visit_count: int | None
    replay: bool | None
    recorded_at: float = field(default_factory=lambda: time.time())
    schema_version: str = EVENT_LOG_SCHEMA_VERSION


@contextmanager
def _file_lock(
    lock_path: Path,
    *,
    timeout_s: float = 5.0,
    retries: int = 3,
    backoff_s: Sequence[float] = (0.1, 0.2, 0.4),
    poll_interval_s: float = 0.01,
    call_id: str = "unknown",
) -> Iterator[None]:
    """Acquire an exclusive lock file for event logs.

    >>> import tempfile
    >>> from pathlib import Path
    >>> lock_root = Path(tempfile.mkdtemp())
    >>> lock = lock_root / "event.lock"
    >>> with _file_lock(lock, timeout_s=0.1, retries=0):
    ...     lock.exists()
    True
    """
    log_parameter(
        "EventLogStore._file_lock",
        lock_path=str(lock_path),
        timeout_s=timeout_s,
        retries=retries,
        call_id=call_id,
    )
    backoffs = list(backoff_s)
    total_backoff = sum(backoffs[:retries]) if retries > 0 else 0.0
    remaining = max(timeout_s - total_backoff, 0.0)
    attempt_timeout = remaining / (retries + 1)
    for attempt in range(retries + 1):
        log_loop_iteration(
            "EventLogStore._file_lock", "attempt", attempt + 1, call_id=call_id
        )
        deadline = time.monotonic() + attempt_timeout
        while True:
            try:
                fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                if time.monotonic() >= deadline:
                    break
                time.sleep(poll_interval_s)
                continue
            try:
                log_branch("EventLogStore._file_lock", "lock_acquired", call_id=call_id)
                yield
            finally:
                os.close(fd)
                lock_path.unlink(missing_ok=True)
            return
        if attempt < retries:
            backoff = backoffs[min(attempt, len(backoffs) - 1)] if backoffs else 0.0
            if backoff:
                log_branch("EventLogStore._file_lock", "lock_backoff", call_id=call_id)
                time.sleep(backoff)
    log_branch("EventLogStore._file_lock", "lock_timeout", call_id=call_id)
    raise PersistenceError(
        "failed to acquire event log lock",
        {"lock": str(lock_path), "timeout_s": timeout_s, "retries": retries},
    )


class EventLogStore:
    """Persist loopgraph EventBus logs as JSON lines."""

    def __init__(self, root: Path) -> None:
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)

    async def append(self, entry: EventLogEntry) -> None:
        """Append a new event log entry asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> store = EventLogStore(Path(tempfile.mkdtemp()))
        >>> entry = EventLogEntry(
        ...     session_id="s1",
        ...     graph_id=None,
        ...     event_id=None,
        ...     node_id=None,
        ...     event_type="demo",
        ...     payload={"ok": True},
        ...     status=None,
        ...     visit_count=None,
        ...     replay=None,
        ... )
        >>> asyncio.run(store.append(entry))
        """
        await asyncio.to_thread(self._sync_append, entry)

    def _sync_append(self, entry: EventLogEntry) -> None:
        """Append a new event log entry (sync path)."""
        session_id = entry.session_id
        log_parameter(
            "EventLogStore._sync_append", session_id=session_id, call_id=session_id
        )
        started = time.monotonic()
        path = self._path(session_id)
        lock = path.with_suffix(".lock")
        payload = _entry_to_dict(entry)
        try:
            with _file_lock(lock, call_id=session_id):
                with path.open("a", encoding="utf-8") as handle:
                    handle.write(
                        json.dumps(payload, separators=(",", ":"), sort_keys=True)
                    )
                    handle.write("\n")
            log_branch("EventLogStore._sync_append", "append_ok", call_id=session_id)
        except PersistenceError:
            log_branch(
                "EventLogStore._sync_append", "append_lock_timeout", call_id=session_id
            )
            raise
        except OSError as exc:
            log_branch(
                "EventLogStore._sync_append", "append_os_error", call_id=session_id
            )
            raise PersistenceError(
                "failed to append event log entry", {"path": str(path)}
            ) from exc
        finally:
            log_timing(
                "EventLogStore._sync_append",
                (time.monotonic() - started) * 1000,
                call_id=session_id,
            )

    async def load(self, session_id: str) -> list[EventLogEntry]:
        """Load event log entries asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> store = EventLogStore(Path(tempfile.mkdtemp()))
        >>> entry = EventLogEntry(
        ...     session_id="s1",
        ...     graph_id=None,
        ...     event_id=None,
        ...     node_id=None,
        ...     event_type="demo",
        ...     payload=None,
        ...     status=None,
        ...     visit_count=None,
        ...     replay=None,
        ... )
        >>> asyncio.run(store.append(entry))
        >>> entries = asyncio.run(store.load("s1"))
        >>> entries[0].session_id
        's1'
        """
        return await asyncio.to_thread(self._sync_load, session_id)

    def _sync_load(self, session_id: str) -> list[EventLogEntry]:
        """Load all event log entries for a session (sync path)."""
        log_parameter(
            "EventLogStore._sync_load", session_id=session_id, call_id=session_id
        )
        started = time.monotonic()
        try:
            path = self._path(session_id)
            if not path.exists():
                log_branch(
                    "EventLogStore._sync_load", "log_missing", call_id=session_id
                )
                raise NotFoundError("event log not found", {"session_id": session_id})
            lock = path.with_suffix(".lock")
            try:
                with _file_lock(lock, call_id=session_id):
                    lines = path.read_text(encoding="utf-8").splitlines()
            except PersistenceError:
                log_branch(
                    "EventLogStore._sync_load", "load_lock_timeout", call_id=session_id
                )
                raise
            except OSError as exc:
                log_branch(
                    "EventLogStore._sync_load", "load_os_error", call_id=session_id
                )
                raise PersistenceError(
                    "failed to read event log", {"path": str(path)}
                ) from exc
            entries: list[EventLogEntry] = []
            for index, line in enumerate(lines, start=1):
                log_loop_iteration(
                    "EventLogStore._sync_load", "lines", index, call_id=session_id
                )
                if not line:
                    log_branch(
                        "EventLogStore._sync_load",
                        "skip_empty_line",
                        call_id=session_id,
                    )
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError as exc:
                    log_branch(
                        "EventLogStore._sync_load",
                        "load_decode_error",
                        call_id=session_id,
                    )
                    raise PersistenceError(
                        "failed to decode event log entry", {"path": str(path)}
                    ) from exc
                entries.append(_entry_from_dict(data))
            return entries
        finally:
            log_timing(
                "EventLogStore._sync_load",
                (time.monotonic() - started) * 1000,
                call_id=session_id,
            )

    def list_approval_events(self, session_id: str) -> list[EventLogEntry]:
        """Filter approval-related events for a session.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> store = EventLogStore(Path(tempfile.mkdtemp()))
        >>> entry = EventLogEntry(
        ...     session_id="s1",
        ...     graph_id=None,
        ...     event_id=None,
        ...     node_id=None,
        ...     event_type=EventType.APPROVAL_GRANTED.value,
        ...     payload={"ok": True},
        ...     status=None,
        ...     visit_count=None,
        ...     replay=None,
        ... )
        >>> asyncio.run(store.append(entry))
        >>> len(store.list_approval_events("s1"))
        1
        """
        approval_events = {
            EventType.APPROVAL_REQUESTED.value,
            EventType.APPROVAL_GRANTED.value,
            EventType.APPROVAL_DENIED.value,
            EventType.APPROVAL_PERSISTENCE_ERROR.value,
        }
        return [
            entry
            for entry in self._sync_load(session_id)
            if entry.event_type in approval_events
        ]

    def _path(self, session_id: str) -> Path:
        return self._root / f"{session_id}.jsonl"


def _entry_to_dict(entry: EventLogEntry) -> dict[str, Any]:
    return {
        "schema_version": entry.schema_version,
        "recorded_at": entry.recorded_at,
        "session_id": entry.session_id,
        "graph_id": entry.graph_id,
        "event_id": entry.event_id,
        "node_id": entry.node_id,
        "event_type": entry.event_type,
        "payload": _normalize_payload(entry.payload),
        "status": entry.status,
        "visit_count": entry.visit_count,
        "replay": entry.replay,
    }


def _entry_from_dict(data: dict[str, Any]) -> EventLogEntry:
    recorded_at = _coerce_float(data.get("recorded_at"), time.time())
    visit_count = _coerce_int(data.get("visit_count"))
    replay = _coerce_bool(data.get("replay"))
    payload = data.get("payload")
    return EventLogEntry(
        session_id=str(data["session_id"]),
        graph_id=_coerce_optional_str(data.get("graph_id")),
        event_id=_coerce_optional_str(data.get("event_id")),
        node_id=_coerce_optional_str(data.get("node_id")),
        event_type=str(data["event_type"]),
        payload=payload if isinstance(payload, dict) else None,
        status=_coerce_optional_str(data.get("status")),
        visit_count=visit_count,
        replay=replay,
        recorded_at=recorded_at,
        schema_version=str(data.get("schema_version", EVENT_LOG_SCHEMA_VERSION)),
    )


def _normalize_payload(payload: object) -> dict[str, Any] | None:
    if payload is None:
        return None
    normalized = _normalize_value(payload)
    return normalized if isinstance(normalized, dict) else {"value": normalized}


def _normalize_value(value: object) -> object:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dt.datetime):
        return value.isoformat()
    if isinstance(value, (dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, Enum):
        return _normalize_value(value.value)
    if is_dataclass(value) and not isinstance(value, type):
        return _normalize_value(asdict(value))
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, Mapping):
        return {str(key): _normalize_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_normalize_value(item) for item in value]
    return str(value)


def _coerce_optional_str(value: object) -> str | None:
    if value is None:
        return None
    return str(value)


def _coerce_int(value: object) -> int | None:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            return None
    return None


def _coerce_float(value: object, default: float) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return default
    return default


def _coerce_bool(value: object) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.lower()
        if lowered in {"true", "1", "yes"}:
            return True
        if lowered in {"false", "0", "no"}:
            return False
    return None
