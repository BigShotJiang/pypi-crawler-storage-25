"""Async protocol interfaces for storage backends."""

from __future__ import annotations

from typing import Protocol, Sequence, runtime_checkable

from ..schemas.session import CompactionSnapshot, ExecutionStateSnapshot
from .event_log_store import EventLogEntry
from .session_store import SessionRecord, SessionSummary


@runtime_checkable
class SessionStoreProtocol(Protocol):
    """Async protocol for session record persistence."""

    async def save(self, record: SessionRecord) -> None:
        """Persist a session record (upsert semantics).

        >>> from typing import Protocol as _Protocol
        >>> isinstance(SessionStoreProtocol, type)
        True
        """
        ...

    async def load(self, session_id: str) -> SessionRecord:
        """Load a session record by ID.

        >>> isinstance(SessionStoreProtocol, type)
        True
        """
        ...

    async def delete(self, session_id: str) -> None:
        """Delete a session record by ID.

        >>> isinstance(SessionStoreProtocol, type)
        True
        """
        ...

    async def list(
        self, parent_session_id: str | None = None
    ) -> Sequence[SessionSummary]:
        """List persisted sessions, optionally filtered by parent_session_id.

        >>> isinstance(SessionStoreProtocol, type)
        True
        """
        ...


@runtime_checkable
class ExecutionStateStoreProtocol(Protocol):
    """Async protocol for execution state snapshots."""

    async def save(self, snapshot: ExecutionStateSnapshot) -> None:
        """Persist an execution state snapshot.

        >>> isinstance(ExecutionStateStoreProtocol, type)
        True
        """
        ...

    async def load(self, execution_state_id: str) -> ExecutionStateSnapshot:
        """Load an execution state snapshot by ID.

        >>> isinstance(ExecutionStateStoreProtocol, type)
        True
        """
        ...


@runtime_checkable
class EventLogStoreProtocol(Protocol):
    """Async protocol for append-only event logs."""

    async def append(self, entry: EventLogEntry) -> None:
        """Append a single event log entry.

        >>> isinstance(EventLogStoreProtocol, type)
        True
        """
        ...

    async def load(self, session_id: str) -> Sequence[EventLogEntry]:
        """Load all event log entries for a session.

        >>> isinstance(EventLogStoreProtocol, type)
        True
        """
        ...


@runtime_checkable
class CompactionStoreProtocol(Protocol):
    """Async protocol for compaction snapshot persistence."""

    async def save(self, snapshot: CompactionSnapshot) -> None:
        """Persist a compaction snapshot.

        >>> isinstance(CompactionStoreProtocol, type)
        True
        """
        ...

    async def load(self, snapshot_id: str) -> CompactionSnapshot:
        """Load a compaction snapshot by ID.

        >>> isinstance(CompactionStoreProtocol, type)
        True
        """
        ...
