"""File-based session persistence with locking."""

from __future__ import annotations

import asyncio
import json
import os
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Sequence

from ..errors import ErrorCode, NotFoundError, PersistenceError
from ..logging import log_branch, log_loop_iteration, log_parameter, log_timing
from ..schemas.messages import Message, MessageRole, Part, PartType
from ..schemas.session import (
    ContinuationMode,
    ExecutionState,
    FinishReason,
    Session,
    SessionConfig,
    SessionStatus,
)
from ._util import _atomic_write

SESSION_SCHEMA_VERSION = "1"


@dataclass
class SessionRecord:
    session: Session
    config: SessionConfig
    state: ExecutionState | None
    messages: Sequence[Message]
    compaction_snapshot_id: str | None


@dataclass(frozen=True)
class SessionSummary:
    """Lightweight session metadata returned by list().

    >>> summary = SessionSummary(session_id="s1", created_at=1.0, updated_at=2.0)
    >>> summary.session_id
    's1'
    """

    session_id: str
    created_at: float
    updated_at: float


def calculate_retention_expiry(now: float, retention_days: int) -> float:
    """Calculate retention expiry timestamp.

    >>> calculate_retention_expiry(0.0, 1)
    86400.0
    """
    return now + (retention_days * 86400)


def is_retention_expired(session: Session, now: float) -> bool:
    """Check whether a session is past its retention window.

    >>> s = Session(session_id=\"s1\", status=SessionStatus.RUNNING, retention_expires_at=10.0)
    >>> is_retention_expired(s, 11.0)
    True
    """
    if session.retention_expires_at is None:
        return False
    return now > session.retention_expires_at


@contextmanager
def _file_lock(
    lock_path: Path,
    *,
    timeout_s: float = 5.0,
    retries: int = 3,
    backoff_s: Sequence[float] = (0.1, 0.2, 0.4),
    poll_interval_s: float = 0.01,
    call_id: str = "unknown",
) -> Iterator[None]:
    """Acquire an exclusive lock file.

    >>> import tempfile
    >>> from pathlib import Path
    >>> lock_root = Path(tempfile.mkdtemp())
    >>> lock = lock_root / "session.lock"
    >>> with _file_lock(lock, timeout_s=0.1, retries=0):
    ...     lock.exists()
    True
    """
    log_parameter(
        "SessionStore._file_lock",
        lock_path=str(lock_path),
        timeout_s=timeout_s,
        retries=retries,
        call_id=call_id,
    )
    backoffs = list(backoff_s)
    total_backoff = sum(backoffs[:retries]) if retries > 0 else 0.0
    remaining = max(timeout_s - total_backoff, 0.0)
    attempt_timeout = remaining / (retries + 1)
    for attempt in range(retries + 1):
        log_loop_iteration(
            "SessionStore._file_lock", "attempt", attempt + 1, call_id=call_id
        )
        deadline = time.monotonic() + attempt_timeout
        while True:
            try:
                fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                if time.monotonic() >= deadline:
                    break
                time.sleep(poll_interval_s)
                continue
            try:
                log_branch("SessionStore._file_lock", "lock_acquired", call_id=call_id)
                yield
            finally:
                os.close(fd)
                lock_path.unlink(missing_ok=True)
            return
        if attempt < retries:
            backoff = backoffs[min(attempt, len(backoffs) - 1)] if backoffs else 0.0
            if backoff:
                log_branch("SessionStore._file_lock", "lock_backoff", call_id=call_id)
                time.sleep(backoff)
    log_branch("SessionStore._file_lock", "lock_timeout", call_id=call_id)
    raise PersistenceError(
        "failed to acquire session lock",
        {"lock": str(lock_path), "timeout_s": timeout_s, "retries": retries},
    )


class SessionStore:
    """Persist sessions to JSON files."""

    def __init__(self, root: Path) -> None:
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)

    async def save(self, record: SessionRecord) -> None:
        """Persist a session record asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> from wormhole_core.schemas.session import Session, SessionConfig, SessionStatus
        >>> store = SessionStore(Path(tempfile.mkdtemp()))
        >>> record = SessionRecord(
        ...     session=Session(session_id="s1", status=SessionStatus.RUNNING),
        ...     config=SessionConfig(),
        ...     state=None,
        ...     messages=[],
        ...     compaction_snapshot_id=None,
        ... )
        >>> asyncio.run(store.save(record))
        """
        await asyncio.to_thread(self._sync_save, record)

    def _sync_save(self, record: SessionRecord) -> None:
        """Persist a session record (sync path)."""
        session_id = record.session.session_id
        log_parameter(
            "SessionStore._sync_save", session_id=session_id, call_id=session_id
        )
        started = time.monotonic()
        path = self._path(session_id)
        lock = path.with_suffix(".lock")
        payload = _record_to_dict(record)
        try:
            with _file_lock(lock, call_id=session_id):
                _atomic_write(
                    path, json.dumps(payload, separators=(",", ":"), sort_keys=True)
                )
            log_branch("SessionStore._sync_save", "save_ok", call_id=session_id)
        except PersistenceError:
            log_branch(
                "SessionStore._sync_save", "save_lock_timeout", call_id=session_id
            )
            raise
        except OSError as exc:
            log_branch("SessionStore._sync_save", "save_os_error", call_id=session_id)
            raise PersistenceError(
                "failed to persist session",
                {"path": str(path), "session_id": session_id},
            ) from exc
        finally:
            log_timing(
                "SessionStore._sync_save",
                (time.monotonic() - started) * 1000,
                call_id=session_id,
            )

    async def load(self, session_id: str) -> SessionRecord:
        """Load a session record asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> from wormhole_core.schemas.session import Session, SessionConfig, SessionStatus
        >>> store = SessionStore(Path(tempfile.mkdtemp()))
        >>> record = SessionRecord(
        ...     session=Session(session_id="s1", status=SessionStatus.RUNNING),
        ...     config=SessionConfig(),
        ...     state=None,
        ...     messages=[],
        ...     compaction_snapshot_id=None,
        ... )
        >>> asyncio.run(store.save(record))
        >>> loaded = asyncio.run(store.load("s1"))
        >>> loaded.session.session_id
        's1'
        """
        return await asyncio.to_thread(self._sync_load, session_id)

    def _sync_load(self, session_id: str) -> SessionRecord:
        """Load a session record (sync path)."""
        log_parameter(
            "SessionStore._sync_load", session_id=session_id, call_id=session_id
        )
        started = time.monotonic()
        path = self._path(session_id)
        if not path.exists():
            log_branch("SessionStore._sync_load", "session_missing", call_id=session_id)
            raise NotFoundError("session not found", {"session_id": session_id})
        lock = path.with_suffix(".lock")
        try:
            with _file_lock(lock, call_id=session_id):
                data = json.loads(path.read_text(encoding="utf-8"))
        except PersistenceError:
            log_branch(
                "SessionStore._sync_load", "load_lock_timeout", call_id=session_id
            )
            raise
        except OSError as exc:
            log_branch("SessionStore._sync_load", "load_os_error", call_id=session_id)
            raise PersistenceError(
                "failed to read session",
                {"path": str(path), "session_id": session_id},
            ) from exc
        except json.JSONDecodeError as exc:
            log_branch(
                "SessionStore._sync_load", "load_decode_error", call_id=session_id
            )
            raise PersistenceError(
                "failed to decode session",
                {"path": str(path), "session_id": session_id},
            ) from exc
        schema_version = str(data.get("schema_version", SESSION_SCHEMA_VERSION))
        if schema_version != SESSION_SCHEMA_VERSION:
            log_branch("SessionStore._sync_load", "schema_mismatch", call_id=session_id)
            raise PersistenceError(
                "session schema version mismatch",
                {
                    "session_id": session_id,
                    "schema_version": schema_version,
                    "expected_version": SESSION_SCHEMA_VERSION,
                    "guidance": "Run migration tooling or delete the session file.",
                },
                code=ErrorCode.PERSISTENCE_SCHEMA_MISMATCH,
            )
        try:
            record = _record_from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            log_branch(
                "SessionStore._sync_load", "load_parse_error", call_id=session_id
            )
            raise PersistenceError(
                "failed to parse session",
                {"path": str(path), "session_id": session_id},
            ) from exc
        finally:
            log_timing(
                "SessionStore._sync_load",
                (time.monotonic() - started) * 1000,
                call_id=session_id,
            )
        return record

    async def delete(self, session_id: str) -> None:
        """Delete a session record asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> store = SessionStore(Path(tempfile.mkdtemp()))
        >>> record = SessionRecord(
        ...     session=Session(session_id="s1", status=SessionStatus.RUNNING),
        ...     config=SessionConfig(),
        ...     state=None,
        ...     messages=[],
        ...     compaction_snapshot_id=None,
        ... )
        >>> asyncio.run(store.save(record))
        >>> asyncio.run(store.delete("s1"))
        """
        await asyncio.to_thread(self._sync_delete, session_id)

    def _sync_delete(self, session_id: str) -> None:
        """Delete a session record (sync path)."""
        log_parameter(
            "SessionStore._sync_delete", session_id=session_id, call_id=session_id
        )
        started = time.monotonic()
        path = self._path(session_id)
        if not path.exists():
            log_branch(
                "SessionStore._sync_delete", "session_missing", call_id=session_id
            )
            raise NotFoundError("session not found", {"session_id": session_id})
        lock = path.with_suffix(".lock")
        try:
            with _file_lock(lock, call_id=session_id):
                try:
                    path.unlink()
                except FileNotFoundError as exc:
                    raise NotFoundError(
                        "session not found", {"session_id": session_id}
                    ) from exc
            log_branch("SessionStore._sync_delete", "delete_ok", call_id=session_id)
        except PersistenceError:
            log_branch(
                "SessionStore._sync_delete", "delete_lock_timeout", call_id=session_id
            )
            raise
        except OSError as exc:
            log_branch(
                "SessionStore._sync_delete", "delete_os_error", call_id=session_id
            )
            raise PersistenceError(
                "failed to delete session",
                {"path": str(path), "session_id": session_id},
            ) from exc
        finally:
            log_timing(
                "SessionStore._sync_delete",
                (time.monotonic() - started) * 1000,
                call_id=session_id,
            )

    async def list(
        self, parent_session_id: str | None = None
    ) -> Sequence[SessionSummary]:
        """List session summaries asynchronously.

        >>> import asyncio
        >>> import tempfile
        >>> from pathlib import Path
        >>> store = SessionStore(Path(tempfile.mkdtemp()))
        >>> summaries = asyncio.run(store.list())
        >>> summaries
        []
        """
        return await asyncio.to_thread(self._sync_list, parent_session_id)

    def _sync_list(
        self, parent_session_id: str | None = None
    ) -> Sequence[SessionSummary]:
        """List session summaries (sync path)."""
        call_id = "list"
        log_parameter(
            "SessionStore._sync_list",
            root=str(self._root),
            parent_session_id=parent_session_id,
            call_id=call_id,
        )
        started = time.monotonic()
        summaries: list[SessionSummary] = []
        paths = sorted(self._root.glob("*.json"))
        for index, path in enumerate(paths, start=1):
            log_loop_iteration(
                "SessionStore._sync_list", "sessions", index, call_id=call_id
            )
            try:
                if not path.is_file():
                    log_branch(
                        "SessionStore._sync_list", "skip_non_file", call_id=call_id
                    )
                    continue
            except OSError:
                log_branch(
                    "SessionStore._sync_list",
                    "session_missing_at_is_file",
                    call_id=call_id,
                )
                continue
            lock = path.with_suffix(".lock")
            try:
                with _file_lock(lock, call_id=call_id):
                    try:
                        stats = path.stat()
                    except FileNotFoundError:
                        log_branch(
                            "SessionStore._sync_list",
                            "session_missing",
                            call_id=call_id,
                        )
                        continue
                    if parent_session_id is not None:
                        try:
                            data = json.loads(path.read_text(encoding="utf-8"))
                        except (OSError, json.JSONDecodeError):
                            log_branch(
                                "SessionStore._sync_list",
                                "session_parse_failed",
                                call_id=call_id,
                            )
                            continue
                        session_payload = data.get("session") or {}
                        if (
                            session_payload.get("parent_session_id")
                            != parent_session_id
                        ):
                            continue
            except PersistenceError:
                log_branch(
                    "SessionStore._sync_list", "list_lock_timeout", call_id=call_id
                )
                raise
            created_at = getattr(stats, "st_birthtime", None)
            if created_at is None:
                created_at = stats.st_ctime
            summaries.append(
                SessionSummary(
                    session_id=path.stem,
                    created_at=float(created_at),
                    updated_at=float(stats.st_mtime),
                )
            )
        log_timing(
            "SessionStore._sync_list",
            (time.monotonic() - started) * 1000,
            call_id=call_id,
        )
        return summaries

    def _path(self, session_id: str) -> Path:
        return self._root / f"{session_id}.json"


def _record_to_dict(record: SessionRecord) -> dict[str, Any]:
    return {
        "schema_version": SESSION_SCHEMA_VERSION,
        "session": _session_to_dict(record.session),
        "config": _config_to_dict(record.config),
        "state": _state_to_dict(record.state) if record.state is not None else None,
        "messages": [_message_to_dict(message) for message in record.messages],
        "compaction_snapshot_id": record.compaction_snapshot_id,
    }


def _record_from_dict(data: dict[str, Any]) -> SessionRecord:
    state_payload = data.get("state")
    return SessionRecord(
        session=_session_from_dict(data["session"]),
        config=_config_from_dict(data["config"]),
        state=_state_from_dict(state_payload) if state_payload is not None else None,
        messages=[_message_from_dict(item) for item in data.get("messages", [])],
        compaction_snapshot_id=data.get("compaction_snapshot_id"),
    )


def _session_to_dict(session: Session) -> dict[str, Any]:
    return {
        "session_id": session.session_id,
        "status": session.status.value,
        "created_at": session.created_at,
        "updated_at": session.updated_at,
        "retention_expires_at": session.retention_expires_at,
        "latest_compaction_id": session.latest_compaction_id,
        "graph_id": session.graph_id,
        "execution_state_id": session.execution_state_id,
        "event_log_id": session.event_log_id,
        "parent_session_id": session.parent_session_id,
    }


def _session_from_dict(data: dict[str, Any]) -> Session:
    return Session(
        session_id=data["session_id"],
        status=SessionStatus(data["status"]),
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        retention_expires_at=data.get("retention_expires_at"),
        latest_compaction_id=data.get("latest_compaction_id"),
        graph_id=data.get("graph_id"),
        execution_state_id=data.get("execution_state_id"),
        event_log_id=data.get("event_log_id"),
        parent_session_id=data.get("parent_session_id"),
    )


def _config_to_dict(config: SessionConfig) -> dict[str, Any]:
    return {
        "retention_days": config.retention_days,
        "compaction_ratio": config.compaction_ratio,
        "auto_compaction_enabled": config.auto_compaction_enabled,
        "allowlisted_tools": list(config.allowlisted_tools),
        "max_concurrent_tools": config.max_concurrent_tools,
    }


def _config_from_dict(data: dict[str, Any]) -> SessionConfig:
    return SessionConfig(
        retention_days=int(data.get("retention_days", 30)),
        compaction_ratio=float(data.get("compaction_ratio", 0.7)),
        auto_compaction_enabled=bool(data.get("auto_compaction_enabled", True)),
        allowlisted_tools=list(data.get("allowlisted_tools", [])),
        max_concurrent_tools=int(data.get("max_concurrent_tools", 1)),
    )


def _state_to_dict(state: ExecutionState) -> dict[str, Any]:
    return {
        "session_id": state.session_id,
        "step_index": state.step_index,
        "next_speaker": state.next_speaker,
        "pending_tool_calls": list(state.pending_tool_calls),
        "last_finish_reason": state.last_finish_reason.value
        if state.last_finish_reason
        else None,
        "continuation_mode": state.continuation_mode.value,
        "last_error": state.last_error,
    }


def _state_from_dict(data: dict[str, Any]) -> ExecutionState:
    finish_reason = data.get("last_finish_reason")
    continuation_mode = data.get("continuation_mode", ContinuationMode.AUTOMATIC.value)
    return ExecutionState(
        session_id=data["session_id"],
        step_index=int(data["step_index"]),
        next_speaker=data["next_speaker"],
        pending_tool_calls=list(data.get("pending_tool_calls", [])),
        last_finish_reason=FinishReason(finish_reason) if finish_reason else None,
        continuation_mode=ContinuationMode(continuation_mode),
        last_error=data.get("last_error"),
    )


def _message_to_dict(message: Message) -> dict[str, Any]:
    return {
        "id": message.id,
        "role": message.role.value,
        "created_at": message.created_at,
        "metadata": dict(message.metadata),
        "parts": [_part_to_dict(part) for part in message.parts],
    }


def _message_from_dict(data: dict[str, Any]) -> Message:
    return Message(
        id=data["id"],
        role=MessageRole(data["role"]),
        parts=[_part_from_dict(item) for item in data.get("parts", [])],
        created_at=data.get("created_at", time.time()),
        metadata=dict(data.get("metadata", {})),
    )


def _part_to_dict(part: Part) -> dict[str, Any]:
    return {
        "id": part.id,
        "type": part.type.value,
        "payload": part.payload,
        "metadata": dict(part.metadata),
    }


def _part_from_dict(data: dict[str, Any]) -> Part:
    return Part(
        id=data["id"],
        type=PartType(data["type"]),
        payload=data.get("payload"),
        metadata=dict(data.get("metadata", {})),
    )
