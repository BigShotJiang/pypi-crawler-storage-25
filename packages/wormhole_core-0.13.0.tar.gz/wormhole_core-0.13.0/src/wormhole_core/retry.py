"""Retry and idempotency primitives for wormhole_core.

>>> policy = RetryPolicy(max_retries=3, base_delay=1.0)
>>> policy.delay_for_attempt(2)
4.0
>>> store = IdempotencyStore()
>>> record = store.get_or_create("op-1", "tool_call")
>>> record.key
'op-1'
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass
class RetryPolicy:
    """Retry policy configuration."""

    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 30.0
    backoff_multiplier: float = 2.0

    def __post_init__(self) -> None:
        if self.max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        if self.base_delay < 0:
            raise ValueError("base_delay must be >= 0")
        if self.max_delay < self.base_delay:
            raise ValueError("max_delay must be >= base_delay")
        if self.backoff_multiplier < 1.0:
            raise ValueError("backoff_multiplier must be >= 1.0")

    def delay_for_attempt(self, attempt: int) -> float:
        delay = self.base_delay * (self.backoff_multiplier**attempt)
        return min(delay, self.max_delay)


@dataclass
class IdempotencyRecord:
    """Tracks idempotency key and outcome for retry deduplication."""

    key: str
    operation: str
    outcome: Literal["pending", "success", "failure"] = "pending"
    result: Any = None
    created_at: float = field(default_factory=time.time)
    completed_at: float | None = None

    @property
    def is_completed(self) -> bool:
        return self.outcome in ("success", "failure")

    def complete(
        self, outcome: Literal["success", "failure"], result: Any = None
    ) -> None:
        self.outcome = outcome
        self.result = result
        self.completed_at = time.time()


class IdempotencyStore:
    """In-memory store for idempotency records."""

    def __init__(self) -> None:
        self._records: dict[str, IdempotencyRecord] = {}

    def get_or_create(self, key: str, operation: str) -> IdempotencyRecord:
        record = self._records.get(key)
        if record is None:
            record = IdempotencyRecord(key=key, operation=operation)
            self._records[key] = record
        return record

    def get(self, key: str) -> IdempotencyRecord | None:
        return self._records.get(key)

    def complete(
        self, key: str, outcome: Literal["success", "failure"], result: Any = None
    ) -> None:
        record = self._records.get(key)
        if record is None:
            record = IdempotencyRecord(key=key, operation="unknown")
            self._records[key] = record
        record.complete(outcome, result=result)

    def clear(self) -> None:
        self._records.clear()


@dataclass
class SessionRetryConfig:
    """Session-level retry configuration."""

    model_retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    tool_retry_policy: RetryPolicy = field(
        default_factory=lambda: RetryPolicy(max_retries=2)
    )
