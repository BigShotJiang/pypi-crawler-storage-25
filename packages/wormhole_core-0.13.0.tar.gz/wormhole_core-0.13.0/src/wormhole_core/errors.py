"""Core error taxonomy for wormhole_core."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping


class ErrorCode(str, Enum):
    """Stable error codes for core failures."""

    VALIDATION_ERROR = "WH-CORE-001"
    PERMISSION_DENIED = "WH-PERM-001"
    NOT_FOUND = "WH-CORE-003"
    SESSION_EXPIRED = "WH-CORE-004"
    PERSISTENCE_ERROR = "WH-CORE-005"
    PERSISTENCE_SCHEMA_MISMATCH = "WH-PERSIST-SCHEMA-001"
    TOOL_EXECUTION_ERROR = "WH-TOOL-001"
    INVALID_STATE_TRANSITION = "WH-CORE-007"
    COMPACTION_SESSION_NOT_FOUND = "WH-CORE-007-001"
    COMPACTION_IN_PROGRESS = "WH-CORE-007-002"
    COMPACTION_SUMMARIZATION_ERROR = "WH-CORE-007-003"
    FORK_PARENT_NOT_FOUND = "WH-CORE-007-004"
    FORK_PARENT_IN_PROGRESS = "WH-CORE-007-005"
    FORK_CHILD_ALREADY_EXISTS = "WH-CORE-007-006"
    ENGINE_ERROR = "WH-CORE-008"
    CONFIG_ERROR = "WH-CORE-009"
    TOOL_EXECUTION_TIMEOUT = "WH-TOOL-002"
    TOOL_SCHEMA_ERROR = "WH-TOOL-003"
    TOOL_VALIDATION_ERROR = "WH-TOOL-004"
    TOOL_NOT_FOUND = "WH-TOOL-005"
    TOOL_IO_ERROR = "WH-TOOL-006"
    TOOL_CONFLICT = "WH-TOOL-007"
    TOOL_UNSUPPORTED = "WH-TOOL-008"
    LOOPGRAPH_UNAVAILABLE = "WH-CORE-100"
    SCHEDULER_ERROR = "WH-CORE-101"
    SNAPSHOT_ERROR = "WH-CORE-102"
    HANDLER_NOT_FOUND = "WH-CORE-103"
    GRAPH_CYCLE = "WH-CORE-104"
    SNAPSHOT_VERSION = "WH-CORE-110"
    DUPLICATE_TOOL = "WH-CORE-120"
    HOOK_ERROR = "WH-CORE-130"
    BACKPRESSURE_ERROR = "WH-CORE-131"
    CAPABILITY_VIOLATION = "WH-CORE-132"
    RETRY_EXHAUSTED = "WH-CORE-133"
    APPROVAL_DENIED = "WH-PERM-002"
    APPROVAL_TIMEOUT = "WH-PERM-003"
    APPROVAL_PERSISTENCE_ERROR = "WH-PERM-004"
    PERMISSION_RULE_INVALID = "WH-PERM-005"


@dataclass(frozen=True)
class WormholeError(Exception):
    """Base error with stable code and optional context.

    >>> err = WormholeError(ErrorCode.NOT_FOUND, "missing session", {"id": "s1"})
    >>> err.code
    <ErrorCode.NOT_FOUND: 'WH-CORE-003'>
    >>> err.to_dict()["message"]
    'missing session'
    """

    code: ErrorCode
    message: str
    context: Mapping[str, Any] = field(default_factory=dict)
    retryable: bool = False

    def __str__(self) -> str:
        return f"{self.code.value}: {self.message}"

    def to_dict(self) -> dict[str, Any]:
        """Serialize the error for structured responses."""
        return {
            "code": self.code.value,
            "message": self.message,
            "context": dict(self.context),
            "retryable": self.retryable,
        }

    def is_retryable(self) -> bool:
        """Check if this error permits retry."""
        return self.retryable


class ValidationError(WormholeError):
    """Validation error for schema or input failures."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.VALIDATION_ERROR, message, context or {})


class PermissionDeniedError(WormholeError):
    """Permission error for tool or operation gating."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.PERMISSION_DENIED, message, context or {})


class NotFoundError(WormholeError):
    """Missing resource error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.NOT_FOUND, message, context or {})


class CompactionError(WormholeError):
    """Compaction operation error.

    >>> err = CompactionError(
    ...     ErrorCode.COMPACTION_SUMMARIZATION_ERROR,
    ...     "summarization failed",
    ...     {"snapshot_id": "snap-1"},
    ...     retryable=True,
    ... )
    >>> err.retryable
    True
    """

    def __init__(
        self,
        code: ErrorCode,
        message: str,
        context: Mapping[str, Any] | None = None,
        retryable: bool = False,
    ) -> None:
        super().__init__(code, message, context or {}, retryable=retryable)


class ForkError(WormholeError):
    """Session fork operation error.

    >>> err = ForkError(ErrorCode.FORK_PARENT_NOT_FOUND, "missing parent")
    >>> err.code
    <ErrorCode.FORK_PARENT_NOT_FOUND: 'WH-CORE-007-004'>
    """

    def __init__(
        self,
        code: ErrorCode,
        message: str,
        context: Mapping[str, Any] | None = None,
        retryable: bool = False,
    ) -> None:
        super().__init__(code, message, context or {}, retryable=retryable)


class SessionExpiredError(WormholeError):
    """Session retention expiry error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.SESSION_EXPIRED, message, context or {})


class PersistenceError(WormholeError):
    """Persistence layer error."""

    def __init__(
        self,
        message: str,
        context: Mapping[str, Any] | None = None,
        code: ErrorCode | None = None,
    ) -> None:
        super().__init__(code or ErrorCode.PERSISTENCE_ERROR, message, context or {})


class EngineError(WormholeError):
    """Loopgraph engine error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.ENGINE_ERROR, message, context or {})


class LoopgraphError(WormholeError):
    """Loopgraph import or availability error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.LOOPGRAPH_UNAVAILABLE, message, context or {})


class SchedulerError(WormholeError):
    """Scheduler execution error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.SCHEDULER_ERROR, message, context or {})


class SnapshotError(WormholeError):
    """Snapshot validation or restore error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.SNAPSHOT_ERROR, message, context or {})


class HandlerNotFoundError(WormholeError):
    """FunctionRegistry handler missing error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.HANDLER_NOT_FOUND, message, context or {})


class GraphCycleError(WormholeError):
    """Graph cycle detection error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.GRAPH_CYCLE, message, context or {})


class SnapshotVersionError(WormholeError):
    """Snapshot version compatibility error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.SNAPSHOT_VERSION, message, context or {})


class DuplicateToolError(WormholeError):
    """Tool registration conflict error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.DUPLICATE_TOOL, message, context or {})


class ToolSchemaError(WormholeError):
    """Tool schema validation error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.TOOL_SCHEMA_ERROR, message, context or {})


class ConfigError(WormholeError):
    """Configuration resolution error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ErrorCode.CONFIG_ERROR, message, context or {})


def _coerce_hook_point(hook_point: object) -> str:
    value = getattr(hook_point, "value", hook_point)
    return str(value)


def _coerce_metrics(metrics: Mapping[str, Any] | object) -> Mapping[str, Any]:
    if isinstance(metrics, Mapping):
        return {
            "current_size": metrics.get("current_size"),
            "max_size": metrics.get("max_size"),
            "drops_count": metrics.get("drops_count"),
        }
    return {
        "current_size": getattr(metrics, "current_size", None),
        "max_size": getattr(metrics, "max_size", None),
        "drops_count": getattr(metrics, "drops_count", None),
    }


class HookError(WormholeError):
    """Hook execution failed."""

    def __init__(
        self,
        message: str,
        hook_id: str,
        hook_point: object,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(
            ErrorCode.HOOK_ERROR,
            message,
            {
                "hook_id": hook_id,
                "hook_point": _coerce_hook_point(hook_point),
                "cause": str(cause) if cause else None,
            },
        )


class BackpressureError(WormholeError):
    """Queue capacity exceeded with fail strategy."""

    def __init__(self, message: str, metrics: Mapping[str, Any] | object) -> None:
        super().__init__(
            ErrorCode.BACKPRESSURE_ERROR, message, _coerce_metrics(metrics)
        )


class CapabilityViolationError(WormholeError):
    """Tool capability constraint violated."""

    def __init__(
        self, message: str, tool_id: str, capability: str, violation: str
    ) -> None:
        super().__init__(
            ErrorCode.CAPABILITY_VIOLATION,
            message,
            {"tool_id": tool_id, "capability": capability, "violation": violation},
        )


class ApprovalDeniedError(WormholeError):
    """Tool approval denied."""

    def __init__(
        self, message: str, approval_id: str, tool_id: str, reason: str | None = None
    ) -> None:
        super().__init__(
            ErrorCode.APPROVAL_DENIED,
            message,
            {"approval_id": approval_id, "tool_id": tool_id, "reason": reason},
        )


class ApprovalTimeoutError(WormholeError):
    """Tool approval wait timed out."""

    def __init__(
        self, message: str, approval_id: str, tool_id: str, timeout: float
    ) -> None:
        super().__init__(
            ErrorCode.APPROVAL_TIMEOUT,
            message,
            {"approval_id": approval_id, "tool_id": tool_id, "timeout": timeout},
        )


class ApprovalPersistenceError(WormholeError):
    """Failed to persist approval audit."""

    def __init__(self, message: str, approval_id: str, retries: int) -> None:
        super().__init__(
            ErrorCode.APPROVAL_PERSISTENCE_ERROR,
            message,
            {"approval_id": approval_id, "retries": retries},
        )


class RetryExhaustedError(WormholeError):
    """Maximum retries exceeded."""

    def __init__(
        self,
        message: str,
        operation: str,
        max_retries: int,
        last_error: Exception | None = None,
    ) -> None:
        super().__init__(
            ErrorCode.RETRY_EXHAUSTED,
            message,
            {
                "operation": operation,
                "max_retries": max_retries,
                "last_error": str(last_error) if last_error else None,
            },
            retryable=False,
        )


class ToolExecutionTimeoutError(WormholeError):
    """Tool execution timed out.

    >>> err = ToolExecutionTimeoutError("tool timed out", "bash", "tc1", 30.0)
    >>> err.code
    <ErrorCode.TOOL_EXECUTION_TIMEOUT: 'WH-TOOL-002'>
    >>> err.context["timeout"]
    30.0
    """

    def __init__(
        self,
        message: str,
        tool_id: str,
        tool_call_id: str | None,
        timeout: float,
    ) -> None:
        super().__init__(
            ErrorCode.TOOL_EXECUTION_TIMEOUT,
            message,
            {"tool_id": tool_id, "tool_call_id": tool_call_id, "timeout": timeout},
            retryable=True,  # Timeout may be transient; SDK can retry or move to background
        )


class TaskToolError(Exception):
    """Base class for TaskTool-specific errors.

    >>> err = TaskToolError("failed")
    >>> err.code
    'WH-SDK-009-000'
    >>> err.retryable
    False
    """

    def __init__(
        self,
        message: str,
        *,
        code: str = "WH-SDK-009-000",
        retryable: bool = False,
        context: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.retryable = retryable
        self.context: dict[str, Any] = dict(context or {})

    def to_dict(self) -> dict[str, Any]:
        """Serialize the error into a structured payload."""
        return {
            "code": self.code,
            "message": str(self),
            "context": dict(self.context),
            "retryable": self.retryable,
        }

    def is_retryable(self) -> bool:
        return self.retryable


class DelegationDepthExceededError(TaskToolError):
    """Raised when child delegation exceeds configured depth.

    >>> err = DelegationDepthExceededError(current_depth=3, max_depth=3)
    >>> err.code
    'WH-SDK-009-001'
    >>> err.context["max_depth"]
    3
    """

    def __init__(self, *, current_depth: int, max_depth: int) -> None:
        super().__init__(
            f"delegation depth {current_depth} exceeds max_depth {max_depth}",
            code="WH-SDK-009-001",
            retryable=False,
            context={"current_depth": current_depth, "max_depth": max_depth},
        )


class ChildSessionFailedError(TaskToolError):
    """Raised when delegated child execution fails.

    >>> err = ChildSessionFailedError(child_session_id="c1", cause="boom")
    >>> err.code
    'WH-SDK-009-002'
    """

    def __init__(self, *, child_session_id: str, cause: str) -> None:
        super().__init__(
            f"child session '{child_session_id}' failed: {cause}",
            code="WH-SDK-009-002",
            retryable=False,
            context={"child_session_id": child_session_id, "cause": cause},
        )


class PromptLayerLockViolationError(TaskToolError):
    """Raised when code attempts to mutate a locked prompt layer.

    >>> err = PromptLayerLockViolationError(
    ...     layer_name="safety",
    ...     operation="set_safety",
    ...     lock_source="policy",
    ... )
    >>> err.code
    'WH-SDK-009-003'
    """

    def __init__(
        self,
        *,
        layer_name: str,
        operation: str,
        lock_source: str,
    ) -> None:
        super().__init__(
            (
                f"cannot {operation} locked prompt layer '{layer_name}' "
                f"(locked by: {lock_source})"
            ),
            code="WH-SDK-009-003",
            retryable=False,
            context={
                "layer_name": layer_name,
                "operation": operation,
                "lock_source": lock_source,
            },
        )


class ChildSessionTimeoutError(TaskToolError):
    """Raised when delegated child execution exceeds timeout.

    >>> err = ChildSessionTimeoutError(child_session_id="c1", timeout_seconds=300.0)
    >>> err.code
    'WH-SDK-009-004'
    """

    def __init__(self, *, child_session_id: str, timeout_seconds: float) -> None:
        super().__init__(
            (f"child session '{child_session_id}' timed out after {timeout_seconds}s"),
            code="WH-SDK-009-004",
            retryable=False,
            context={
                "child_session_id": child_session_id,
                "timeout_seconds": timeout_seconds,
            },
        )
