"""Backpressure primitives for wormhole_core.

>>> cfg = BackpressureConfig(max_size=100, strategy=BackpressureStrategy.BLOCK)
>>> cfg.max_size
100
>>> metrics = BackpressureMetrics(current_size=5, max_size=10, drops_count=1)
>>> metrics.utilization
0.5
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class BackpressureStrategy(str, Enum):
    """Strategies for handling queue overflow."""

    BLOCK = "block"
    DROP_OLDEST = "drop_oldest"
    FAIL = "fail"


@dataclass
class BackpressureConfig:
    """Configuration for bounded event queues."""

    max_size: int = 1000
    strategy: BackpressureStrategy = BackpressureStrategy.BLOCK

    def __post_init__(self) -> None:
        if self.max_size < 1:
            raise ValueError("max_size must be >= 1")


@dataclass(frozen=True)
class BackpressureMetrics:
    """Observable metrics for queue state."""

    current_size: int
    max_size: int
    drops_count: int

    @property
    def utilization(self) -> float:
        return self.current_size / self.max_size if self.max_size > 0 else 0.0
