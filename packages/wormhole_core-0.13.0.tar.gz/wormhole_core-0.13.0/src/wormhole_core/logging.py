"""Structured debug logging helpers for wormhole_core."""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import asdict, is_dataclass
from enum import Enum
from typing import Any

from .errors import HookError

LOGGER = logging.getLogger("wormhole_core")
REDACTED = "REDACTED"
SENSITIVE_KEYS = {
    "password",
    "passphrase",
    "token",
    "api_key",
    "apikey",
    "secret",
    "credential",
    "email",
    "key",
}
_UNSET = object()


def _should_redact(key: str) -> bool:
    lowered = key.lower()
    return any(marker in lowered for marker in SENSITIVE_KEYS)


def _redact_value(value: Any) -> Any:
    normalized = _jsonify(value)
    if isinstance(normalized, dict):
        redacted = {}
        for key, val in normalized.items():
            next_value = REDACTED if _should_redact(str(key)) else val
            redacted[str(key)] = _redact_value(next_value)
        return redacted
    if isinstance(normalized, list):
        return [_redact_value(item) for item in normalized]
    return normalized


def _jsonify(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return _jsonify(asdict(value))
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {str(key): _jsonify(val) for key, val in value.items()}
    if isinstance(value, list):
        return [_jsonify(item) for item in value]
    if isinstance(value, tuple):
        return [_jsonify(item) for item in value]
    if isinstance(value, set):
        return [_jsonify(item) for item in value]
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.hex()
    if isinstance(value, Exception):
        return {"error": value.__class__.__name__, "message": str(value)}
    if hasattr(value, "__fspath__"):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)


def _emit_debug(
    *,
    event: str,
    function: str,
    call_id: str = "unknown",
    branch: str | None = None,
    loop_iter: int | None = None,
    elapsed_ms: float | None = None,
    payload: dict[str, Any] | None = None,
) -> None:
    if os.getenv("WORMHOLE_RELEASE") == "1":
        return
    if os.getenv("WORMHOLE_DEBUG") != "1":
        return
    record = {
        "event": event,
        "function": function,
        "call_id": call_id,
        "timestamp": time.time(),
        "branch": branch,
        "loop_iter": loop_iter,
        "elapsed_ms": elapsed_ms,
        "payload": _redact_value(payload or {}),
    }
    LOGGER.debug("%s", json.dumps(record, separators=(",", ":")))


def log_parameter(func_name: str, call_id: str = "unknown", **params: Any) -> None:
    """Log function parameters in a structured format.

    >>> log_parameter("demo", alpha=1, beta="two")
    """
    _emit_debug(event="params", function=func_name, call_id=call_id, payload=params)


def log_variable_change(
    func_name: str,
    name: str,
    before: Any,
    after: Any = _UNSET,
    call_id: str = "unknown",
) -> None:
    """Log variable updates for traceability.

    >>> log_variable_change("demo", "counter", 2, 3)
    """
    if after is _UNSET:
        before_value = None
        after_value = before
    else:
        before_value = before
        after_value = after
    _emit_debug(
        event="var_change",
        function=func_name,
        call_id=call_id,
        payload={"name": name, "before": before_value, "after": after_value},
    )


def log_branch(func_name: str, branch: str, call_id: str = "unknown") -> None:
    """Log conditional branch execution.

    >>> log_branch("demo", "if_ready")
    """
    _emit_debug(event="branch", function=func_name, call_id=call_id, branch=branch)


def log_loop_iteration(
    func_name: str,
    loop_name: str,
    iteration: int,
    call_id: str = "unknown",
) -> None:
    """Log loop iteration counts.

    >>> log_loop_iteration("demo", "items", 2)
    """
    _emit_debug(
        event="loop_iter",
        function=func_name,
        call_id=call_id,
        loop_iter=iteration,
        payload={"loop": loop_name},
    )


def log_timing(
    func_name: str,
    elapsed_ms: float,
    call_id: str = "unknown",
    branch: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Log timing measurements for a call span.

    >>> log_timing("demo", 12.5)
    """
    _emit_debug(
        event="timing",
        function=func_name,
        call_id=call_id,
        branch=branch,
        elapsed_ms=elapsed_ms,
        payload=metadata or {},
    )


def log_hook_invocation(hook_id: str, hook_point: object, session_id: str) -> None:
    """Log hook invocation attempts."""
    hook_value = getattr(hook_point, "value", hook_point)
    _emit_debug(
        event="hook_invoked",
        function="HookRegistry.invoke",
        call_id=session_id,
        payload={"hook_id": hook_id, "hook_point": str(hook_value)},
    )


def log_hook_failure(error: HookError) -> None:
    """Log hook execution failures."""
    _emit_debug(
        event="hook_failed",
        function="HookRegistry.invoke",
        call_id=str(error.context.get("session_id", "unknown")),
        payload=error.to_dict(),
    )
