"""Message and part schemas for wormhole_core."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Sequence

from ..errors import ValidationError


class PartType(str, Enum):
    """Supported part types."""

    TEXT = "text"
    TOOL_CALL = "tool_call"
    TOOL_OUTPUT = "tool_output"
    COST = "cost"
    METADATA = "metadata"


class MessageRole(str, Enum):
    """Message roles."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


@dataclass(frozen=True)
class Part:
    """A typed message part.

    >>> part = Part(id="p1", type=PartType.TEXT, payload={"text": "hi"})
    >>> part.type
    <PartType.TEXT: 'text'>
    """

    id: str
    type: PartType
    payload: Any
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Message:
    """Message containing one or more parts.

    >>> msg = Message(
    ...     id="m1",
    ...     role=MessageRole.USER,
    ...     parts=[Part(id="p1", type=PartType.TEXT, payload="hi")],
    ... )
    >>> msg.role
    <MessageRole.USER: 'user'>
    """

    id: str
    role: MessageRole
    parts: Sequence[Part]
    created_at: float = field(default_factory=lambda: time.time())
    metadata: dict[str, Any] = field(default_factory=dict)


def validate_message(message: Message) -> None:
    """Validate basic message invariants.

    >>> validate_message(Message(id="m1", role=MessageRole.SYSTEM, parts=[Part(id="p1", type=PartType.METADATA, payload={})]))
    >>> compaction_msg = Message(
    ...     id="m2",
    ...     role=MessageRole.SYSTEM,
    ...     parts=[Part(id="p2", type=PartType.TEXT, payload="summary")],
    ...     metadata={"compaction": True, "snapshot_id": "snap-1"},
    ... )
    >>> validate_message(compaction_msg)
    """
    if not message.parts:
        raise ValidationError(
            "message must include at least one part", {"message_id": message.id}
        )
    _validate_compaction_metadata(message)


def _validate_compaction_metadata(message: Message) -> None:
    metadata = message.metadata or {}
    if "compaction" not in metadata:
        return
    compaction_flag = metadata.get("compaction")
    if not isinstance(compaction_flag, bool):
        raise ValidationError(
            "compaction metadata must be a boolean",
            {"message_id": message.id},
        )
    if not compaction_flag:
        return
    if message.role is not MessageRole.SYSTEM:
        raise ValidationError(
            "compaction messages must have role=system",
            {"message_id": message.id},
        )
    snapshot_id = metadata.get("snapshot_id")
    if not isinstance(snapshot_id, str) or not snapshot_id:
        raise ValidationError(
            "compaction messages require snapshot_id",
            {"message_id": message.id},
        )
