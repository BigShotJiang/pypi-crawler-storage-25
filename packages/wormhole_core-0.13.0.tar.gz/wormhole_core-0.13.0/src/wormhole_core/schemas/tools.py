"""Tool schemas and permission kinds.

>>> caps = ToolCapabilities(read_only=True, concurrency_safe=True)
>>> caps.concurrency_safe
True
>>> caps_with_timeout = ToolCapabilities(execution_timeout_seconds=30.0)
>>> caps_with_timeout.execution_timeout_seconds
30.0
>>> caps_no_timeout = ToolCapabilities()
>>> caps_no_timeout.execution_timeout_seconds is None
True
>>> import math
>>> caps_infinite = ToolCapabilities(execution_timeout_seconds=math.inf)
>>> math.isinf(caps_infinite.execution_timeout_seconds)
True
>>> rec = ApprovalDecisionRecord(
...     approval_id="a1",
...     session_id="s1",
...     tool_id="bash",
...     tool_call_id="tc1",
...     decision="allow",
...     user_id="user@example.com",
...     scope="once",
...     timestamp=1705680000.0,
... )
>>> rec.decision
'allow'
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Literal, Mapping

from ..errors import ValidationError
from ..retry import RetryPolicy


class PermissionKind(str, Enum):
    """Permission modes for tool execution."""

    ALLOWLIST_ONLY = "allowlist_only"
    USER_APPROVAL = "user_approval"


class PermissionAction(str, Enum):
    """Actions for permission rules."""

    ALLOW = "allow"
    DENY = "deny"
    ASK = "ask"


class PermissionScope(str, Enum):
    """Scope for permission grants."""

    ONCE = "once"
    ALWAYS = "always"
    SESSION = "session"


class RiskLevel(str, Enum):
    """Risk assessment for approval requests."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ToolCallStatus(str, Enum):
    """Lifecycle states for a tool call."""

    PENDING = "pending"
    APPROVED = "approved"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ToolCapabilities:
    """Capability declarations for a tool.

    Attributes:
        read_only: Informational flag indicating the tool doesn't mutate state.
        concurrency_safe: When True, tool can run in parallel with other safe tools.
        approval_required: When True, SDKs should request approval before execution.
        execution_timeout_seconds: Maximum execution time in seconds.
            - None: Inherit from session config (or no timeout if session also None)
            - math.inf: Explicitly no timeout, even if session has default
            - > 0: Timeout after N seconds
            - <= 0: Invalid (rejected at validation)
    """

    read_only: bool = False
    concurrency_safe: bool = False
    approval_required: bool = False
    execution_timeout_seconds: float | None = None


@dataclass(frozen=True)
class ApprovalDecisionRecord:
    """Audit record for tool approval decisions."""

    approval_id: str
    session_id: str
    tool_id: str
    tool_call_id: str | None
    decision: Literal["allow", "deny", "pending"]
    user_id: str | None
    scope: Literal["once", "always"] | None
    timestamp: float
    reason: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PermissionRule:
    """Rule for permission matching."""

    rule_id: str
    tool_pattern: str
    target_pattern: str
    action: PermissionAction
    scope: PermissionScope
    created_at: float


@dataclass(frozen=True)
class ApprovalPayload:
    """Precomputed approval details for a tool invocation."""

    input_summary: str
    risk_assessment: RiskLevel
    preview: Mapping[str, Any] | None = None
    target_context: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class ApprovalRequest:
    """Request for tool execution approval."""

    approval_id: str
    session_id: str
    tool_id: str
    tool_call_id: str | None
    tool_input: dict[str, Any]
    input_summary: str | None = None
    risk_assessment: RiskLevel | None = None
    preview: Mapping[str, Any] | None = None
    target_context: Mapping[str, Any] | None = None
    timeout: float | None = 60.0


@dataclass(frozen=True)
class ToolDefinition:
    """Tool registration schema.

    >>> tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
    >>> tool.name
    'echo'
    """

    tool_id: str
    name: str
    schema: Mapping[str, Any]
    description: str = ""
    permission_kind: PermissionKind = PermissionKind.USER_APPROVAL
    enabled: bool = True
    capabilities: ToolCapabilities = field(default_factory=ToolCapabilities)
    default_retry_policy: RetryPolicy | None = None
    approval_payload: Callable[[Mapping[str, Any]], ApprovalPayload] | None = None

    def __post_init__(self) -> None:
        if not self.name:
            raise ValidationError("tool name is required", {"tool_id": self.tool_id})
        if not self.schema:
            raise ValidationError("tool schema is required", {"tool_id": self.tool_id})


@dataclass(frozen=True)
class ToolCall:
    """Tool invocation request and optional result.

    When used as a request: arguments contains the input, result is None.
    When used as a result: result contains the output, error contains any error message.

    >>> call = ToolCall(tool_call_id="tc1", tool_id="bash", arguments={"cmd": "ls"})
    >>> call.status
    <ToolCallStatus.PENDING: 'pending'>
    >>> result = ToolCall(
    ...     tool_call_id="tc1", tool_id="bash",
    ...     status=ToolCallStatus.COMPLETED, result={"output": "file.txt"}
    ... )
    >>> result.result
    {'output': 'file.txt'}
    """

    tool_call_id: str
    tool_id: str
    arguments: Mapping[str, Any] = field(default_factory=dict)
    status: ToolCallStatus = ToolCallStatus.PENDING
    result: Any = None
    error: str | None = None
