"""Delegation schema for task-tool child session lineage and depth control.

>>> ctx = DelegationContext(current_depth=0, max_depth=3, root_session_id="root-1")
>>> ctx.can_delegate()
True
>>> child = ctx.for_child(parent_session_id="parent-1")
>>> child.current_depth
1
>>> child.parent_session_id
'parent-1'
>>> child.root_session_id
'root-1'
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DelegationContext:
    """Tracks delegation depth and lineage for a delegation chain."""

    current_depth: int = 0
    max_depth: int = 3
    parent_session_id: str | None = None
    root_session_id: str | None = None

    def __post_init__(self) -> None:
        if self.current_depth < 0:
            raise ValueError(f"current_depth must be >= 0, got {self.current_depth}")
        if self.max_depth < 1:
            raise ValueError(f"max_depth must be >= 1, got {self.max_depth}")
        if self.current_depth > self.max_depth:
            raise ValueError(
                "current_depth must be <= max_depth, "
                f"got current_depth={self.current_depth}, max_depth={self.max_depth}"
            )

    def can_delegate(self) -> bool:
        """Return True when another delegation level is allowed.

        >>> DelegationContext(current_depth=2, max_depth=3).can_delegate()
        True
        >>> DelegationContext(current_depth=3, max_depth=3).can_delegate()
        False
        """
        return self.current_depth < self.max_depth

    def for_child(self, parent_session_id: str) -> "DelegationContext":
        """Return a child context with incremented depth.

        Raises:
            DelegationDepthExceededError: when ``current_depth`` already reached
                ``max_depth``.
        """
        if not parent_session_id.strip():
            raise ValueError("parent_session_id must be non-empty")
        if not self.can_delegate():
            from wormhole_core.errors import (
                DelegationDepthExceededError,
            )  # noqa: PLC0415

            raise DelegationDepthExceededError(
                current_depth=self.current_depth,
                max_depth=self.max_depth,
            )
        return DelegationContext(
            current_depth=self.current_depth + 1,
            max_depth=self.max_depth,
            parent_session_id=parent_session_id,
            root_session_id=self.root_session_id or parent_session_id,
        )


__all__ = ["DelegationContext"]
