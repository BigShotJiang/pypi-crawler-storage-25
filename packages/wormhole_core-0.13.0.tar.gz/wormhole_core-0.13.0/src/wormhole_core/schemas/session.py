"""Session schemas for wormhole_core."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Sequence

from ..backpressure import BackpressureConfig
from ..errors import ValidationError
from ..retry import RetryPolicy
from .tools import PermissionRule


class SessionStatus(str, Enum):
    """Session lifecycle states."""

    CREATED = "created"
    RUNNING = "running"
    AWAITING_INPUT = "awaiting_input"
    AWAITING_TOOL = "awaiting_tool"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"
    EXPIRED = "expired"


class CompactionStage(str, Enum):
    """Compaction lifecycle stages.

    >>> CompactionStage.PRUNING.value
    'pruning'
    """

    PENDING = "pending"
    PRUNING = "pruning"
    SUMMARIZING = "summarizing"
    COMPLETED = "completed"
    FAILED = "failed"


class FinishReason(str, Enum):
    """Model finish reasons for loop termination.

    >>> FinishReason.END_TURN.value
    'end_turn'
    >>> FinishReason.TOOL_USE
    <FinishReason.TOOL_USE: 'tool_use'>
    """

    END_TURN = "end_turn"
    TOOL_USE = "tool_use"
    MAX_TOKENS = "max_tokens"
    STOP = "stop"


class ContinuationMode(str, Enum):
    """Continuation overrides for session stepping.

    >>> ContinuationMode.AUTOMATIC.value
    'automatic'
    >>> ContinuationMode.FORCE_STOP
    <ContinuationMode.FORCE_STOP: 'force_stop'>
    """

    AUTOMATIC = "automatic"
    FORCE_CONTINUE = "force_continue"
    FORCE_STOP = "force_stop"


@dataclass(frozen=True)
class SessionConfig:
    """Runtime configuration for a session.

    >>> cfg = SessionConfig(retention_days=30, compaction_ratio=0.7)
    >>> cfg.compaction_ratio
    0.7
    >>> cfg_with_timeout = SessionConfig(tool_execution_timeout_seconds=30.0)
    >>> cfg_with_timeout.tool_execution_timeout_seconds
    30.0
    >>> cfg_no_timeout = SessionConfig()
    >>> cfg_no_timeout.tool_execution_timeout_seconds is None
    True
    """

    retention_days: int = 30
    compaction_ratio: float = 0.7
    auto_compaction_enabled: bool = True
    allowlisted_tools: Sequence[str] = field(default_factory=list)
    max_concurrent_tools: int = 1
    backpressure: BackpressureConfig | None = None
    model_retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    tool_retry_policy: RetryPolicy = field(
        default_factory=lambda: RetryPolicy(max_retries=2)
    )
    approval_timeout_seconds: float | None = 60.0
    tool_execution_timeout_seconds: float | None = None
    permission_rules: Sequence[PermissionRule] = field(default_factory=list)
    banned_command_patterns: Sequence[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.retention_days < 1:
            raise ValidationError("retention_days must be >= 1")
        if not 0.0 < self.compaction_ratio <= 1.0:
            raise ValidationError("compaction_ratio must be > 0 and <= 1")
        if self.max_concurrent_tools < 1:
            raise ValidationError("max_concurrent_tools must be >= 1")
        if (
            self.approval_timeout_seconds is not None
            and self.approval_timeout_seconds <= 0
        ):
            raise ValidationError("approval_timeout_seconds must be > 0 or None")
        if (
            self.tool_execution_timeout_seconds is not None
            and self.tool_execution_timeout_seconds <= 0
        ):
            import math

            if not math.isinf(self.tool_execution_timeout_seconds):
                raise ValidationError(
                    "tool_execution_timeout_seconds must be > 0 or inf when specified"
                )


@dataclass(frozen=True)
class CompactionConfig:
    """Configuration for compaction behavior.

    >>> cfg = CompactionConfig()
    >>> cfg.trigger_threshold
    0.9
    """

    trigger_threshold: float = 0.9
    prune_target_ratio: float = 0.5
    protected_rounds: int = 2
    auto_enabled: bool = True
    max_summary_tokens: int | None = None

    def __post_init__(self) -> None:
        if not 0.0 < self.trigger_threshold <= 1.0:
            raise ValidationError("trigger_threshold must be > 0 and <= 1")
        if not 0.0 < self.prune_target_ratio < self.trigger_threshold:
            raise ValidationError(
                "prune_target_ratio must be > 0 and < trigger_threshold"
            )
        if self.protected_rounds < 0:
            raise ValidationError("protected_rounds must be >= 0")
        if self.max_summary_tokens is not None and self.max_summary_tokens <= 0:
            raise ValidationError("max_summary_tokens must be > 0 or None")


@dataclass(frozen=True)
class ExecutionState:
    """Execution state for deterministic stepping."""

    session_id: str
    step_index: int
    next_speaker: str
    pending_tool_calls: Sequence[str] = field(default_factory=list)
    last_finish_reason: FinishReason | None = None
    continuation_mode: ContinuationMode = ContinuationMode.AUTOMATIC
    last_error: str | None = None


@dataclass(frozen=True)
class Session:
    """Persisted session record.

    >>> session = Session(session_id="s1", status=SessionStatus.RUNNING, parent_session_id="p1")
    >>> session.parent_session_id
    'p1'
    """

    session_id: str
    status: SessionStatus
    created_at: float = field(default_factory=lambda: time.time())
    updated_at: float = field(default_factory=lambda: time.time())
    retention_expires_at: float | None = None
    latest_compaction_id: str | None = None
    graph_id: str | None = None
    execution_state_id: str | None = None
    event_log_id: str | None = None
    parent_session_id: str | None = None


@dataclass(frozen=True)
class CompactionSnapshot:
    """Snapshot metadata for compaction operations.

    >>> snap = CompactionSnapshot(snapshot_id="snap-1", session_id="s1", compaction_message_id="msg-1")
    >>> snap.stage
    <CompactionStage.PENDING: 'pending'>
    """

    snapshot_id: str
    session_id: str
    created_at: float = field(default_factory=lambda: time.time())
    kept_files: Sequence[str] = field(default_factory=list)
    source_message_range: tuple[int, int] | None = None
    stage: CompactionStage = CompactionStage.PENDING
    pruned_message_count: int = 0
    pruned_token_estimate: int = 0
    compaction_message_id: str | None = None


@dataclass(frozen=True)
class ExecutionStateSnapshot:
    """Opaque loopgraph state snapshot for resume."""

    execution_state_id: str
    graph_id: str
    snapshot_version: str
    data: dict[str, Any]
    captured_at: float = field(default_factory=lambda: time.time())


def validate_execution_state(state: ExecutionState) -> None:
    """Validate execution state.

    >>> validate_execution_state(
    ...     ExecutionState(session_id="s1", step_index=0, next_speaker="assistant")
    ... )
    """
    if state.step_index < 0:
        raise ValidationError(
            "step_index must be >= 0", {"session_id": state.session_id}
        )
