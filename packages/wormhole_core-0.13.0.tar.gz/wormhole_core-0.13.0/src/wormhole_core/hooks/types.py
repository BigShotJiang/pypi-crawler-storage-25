"""Hook system types for wormhole_core.

>>> HOOK_API_VERSION
'1'
>>> HookPoint.PROMPT_TRANSFORM.value
'prompt_transform'
>>> HookResult(proceed=False, reason="blocked").reason
'blocked'
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Awaitable, Protocol

HOOK_API_VERSION = "1"


class HookPoint(str, Enum):
    """Lifecycle points for hook registration."""

    PROMPT_TRANSFORM = "prompt_transform"
    TOOL_GATE = "tool_gate"
    TELEMETRY = "telemetry"
    COMPACTION_TRIGGER = "compaction_trigger"
    POST_COMPACTION = "post_compaction"
    POST_FORK = "post_fork"


@dataclass(frozen=True)
class HookContext:
    """Context provided to hook callbacks.

    >>> ctx = HookContext(
    ...     session_id="s1",
    ...     hook_point=HookPoint.POST_FORK,
    ...     payload={},
    ...     timestamp=0.0,
    ... )
    >>> ctx.api_version
    '1'
    """

    session_id: str
    hook_point: HookPoint
    payload: dict[str, Any]
    timestamp: float
    api_version: str = HOOK_API_VERSION


@dataclass
class HookResult:
    """Result from a hook callback."""

    proceed: bool = True
    reason: str | None = None
    modified_payload: dict[str, Any] | None = None


class HookCallback(Protocol):
    """Protocol for hook callbacks."""

    def __call__(self, context: HookContext) -> HookResult | Awaitable[HookResult]: ...


@dataclass(frozen=True)
class HookRegistration:
    """A registered hook."""

    hook_id: str
    hook_point: HookPoint
    callback: HookCallback
    enabled: bool = True
    registration_order: int = 0
