"""Hook registry for wormhole_core.

>>> registry = HookRegistry()
>>> def allow(ctx):
...     return HookResult(proceed=True)
>>> registration = registry.register(HookPoint.TOOL_GATE, allow)
>>> registration.hook_id.startswith("hook_")
True
"""

from __future__ import annotations

import inspect
import threading
from dataclasses import replace
from typing import Callable, Iterable

from ..errors import HookError
from ..logging import log_hook_failure, log_hook_invocation
from .types import HookCallback, HookContext, HookPoint, HookRegistration, HookResult


class HookRegistry:
    """Registry for hook registration and invocation."""

    def __init__(self) -> None:
        self._hooks: list[HookRegistration] = []
        self._index: dict[str, HookRegistration] = {}
        self._counter = 0
        self._lock = threading.Lock()
        self._error_handler: Callable[[HookError], None] | None = None

    def register(
        self,
        hook_point: HookPoint,
        callback: HookCallback,
        hook_id: str | None = None,
        enabled: bool = True,
    ) -> HookRegistration:
        """Register a hook at a lifecycle point."""
        with self._lock:
            resolved_id = hook_id or f"hook_{self._counter}"
            if resolved_id in self._index:
                raise ValueError("hook_id already registered")
            registration = HookRegistration(
                hook_id=resolved_id,
                hook_point=hook_point,
                callback=callback,
                enabled=enabled,
                registration_order=self._counter,
            )
            self._counter += 1
            self._hooks.append(registration)
            self._index[resolved_id] = registration
            return registration

    def unregister(self, hook_id: str) -> bool:
        """Remove a hook by ID."""
        with self._lock:
            registration = self._index.pop(hook_id, None)
            if registration is None:
                return False
            self._hooks = [hook for hook in self._hooks if hook.hook_id != hook_id]
            return True

    def enable(self, hook_id: str) -> bool:
        """Enable a disabled hook."""
        return self._set_enabled(hook_id, True)

    def disable(self, hook_id: str) -> bool:
        """Disable an enabled hook (keeps registration)."""
        return self._set_enabled(hook_id, False)

    def list_hooks(self, hook_point: HookPoint | None = None) -> list[HookRegistration]:
        """List registered hooks, optionally filtered by hook point."""
        with self._lock:
            hooks = list(self._hooks)
        if hook_point is None:
            return hooks
        return [hook for hook in hooks if hook.hook_point == hook_point]

    def clear(self) -> None:
        """Remove all registered hooks."""
        with self._lock:
            self._hooks.clear()
            self._index.clear()

    def set_error_handler(self, handler: Callable[[HookError], None] | None) -> None:
        """Register an error handler for hook failures."""
        with self._lock:
            self._error_handler = handler

    async def invoke(
        self,
        hook_point: HookPoint,
        context: HookContext,
        error_handler: Callable[[HookError], None] | None = None,
    ) -> list[HookResult]:
        """Invoke all enabled hooks for a lifecycle point."""
        results: list[HookResult] = []
        hooks = [hook for hook in self.list_hooks(hook_point) if hook.enabled]
        for hook in _order_hooks(hooks):
            log_hook_invocation(hook.hook_id, hook.hook_point, context.session_id)
            try:
                result = hook.callback(context)
                if inspect.isawaitable(result):
                    result = await result
                results.append(result)
            except Exception as exc:  # pragma: no cover - exercised by tests
                error = HookError(
                    "hook execution failed",
                    hook_id=hook.hook_id,
                    hook_point=hook.hook_point,
                    cause=exc,
                )
                log_hook_failure(error)
                handler = error_handler or self._error_handler
                if handler is not None:
                    handler(error)
                results.append(HookResult(proceed=True, reason=str(exc)))
        return results

    def _set_enabled(self, hook_id: str, enabled: bool) -> bool:
        with self._lock:
            registration = self._index.get(hook_id)
            if registration is None:
                return False
            if registration.enabled == enabled:
                return True
            updated = replace(registration, enabled=enabled)
            self._index[hook_id] = updated
            self._hooks = [
                updated if hook.hook_id == hook_id else hook for hook in self._hooks
            ]
            return True


def _order_hooks(hooks: Iterable[HookRegistration]) -> list[HookRegistration]:
    return sorted(hooks, key=lambda hook: hook.registration_order)
