"""Hook system for wormhole_core."""

from __future__ import annotations

from .registry import HookRegistry
from .types import (
    HOOK_API_VERSION,
    HookCallback,
    HookContext,
    HookPoint,
    HookRegistration,
    HookResult,
)

__all__ = [
    "HOOK_API_VERSION",
    "HookCallback",
    "HookContext",
    "HookPoint",
    "HookRegistration",
    "HookRegistry",
    "HookResult",
]
