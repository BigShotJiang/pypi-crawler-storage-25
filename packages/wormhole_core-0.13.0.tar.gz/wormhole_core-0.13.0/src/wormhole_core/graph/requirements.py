"""loopgraph availability checks."""

from __future__ import annotations

import re
from importlib import metadata
from pathlib import Path

from ..errors import LoopgraphError

_MIN_VERSION = (0, 3, 0)
_MAX_VERSION = (0, 4, 0)


def _parse_version(version: str) -> tuple[int, int, int]:
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)", version)
    if not match:
        return (0, 0, 0)
    major, minor, patch = match.groups()
    return (int(major), int(minor), int(patch))


def _try_version(package: str) -> str | None:
    try:
        return metadata.version(package)
    except metadata.PackageNotFoundError:
        return None


def _read_version_from_source() -> str | None:
    try:
        import loopgraph
    except Exception:
        return None
    path = Path(loopgraph.__file__).resolve()
    for parent in path.parents:
        candidate = parent / "pyproject.toml"
        if candidate.exists():
            version = _extract_version(candidate)
            if version:
                return version
    return None


def _extract_version(path: Path) -> str | None:
    try:
        content = path.read_text()
    except OSError:
        return None
    match = re.search(r"^version\\s*=\\s*[\"']([^\"']+)[\"']\\s*$", content, re.M)
    if match:
        return match.group(1)
    return None


def _resolve_version() -> str:
    version = _try_version("loopgraph")
    if version:
        return version
    version = _read_version_from_source()
    if version:
        return version
    raise LoopgraphError("loopgraph package not installed")


def ensure_loopgraph_available() -> None:
    """Ensure loopgraph can be imported before using graph helpers."""
    try:
        import loopgraph  # noqa: F401
        from loopgraph.bus.eventbus import EventBus  # noqa: F401
        from loopgraph.core.graph import Graph  # noqa: F401
        from loopgraph.core.state import ExecutionState  # noqa: F401
        from loopgraph.registry.function_registry import FunctionRegistry  # noqa: F401
        from loopgraph.scheduler.scheduler import Scheduler  # noqa: F401
    except Exception as exc:  # noqa: BLE001 - surfaced as typed error
        raise LoopgraphError("loopgraph import failed", {"error": str(exc)}) from exc
    version = _resolve_version()
    parsed = _parse_version(version)
    if not (_MIN_VERSION <= parsed < _MAX_VERSION):
        raise LoopgraphError(
            "loopgraph version incompatible",
            {"version": version, "required": f">={_MIN_VERSION},<{_MAX_VERSION}"},
        )
