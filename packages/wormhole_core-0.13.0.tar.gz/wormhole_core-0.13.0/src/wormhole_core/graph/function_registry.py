"""Session-scoped function registry wrappers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, cast

from loopgraph.registry.function_registry import FunctionRegistry

Handler = Callable[[dict[str, Any]], Any]


@dataclass
class SessionFunctionRegistry:
    """Wrapper for per-session loopgraph FunctionRegistry."""

    _registry: FunctionRegistry = field(default_factory=FunctionRegistry)

    def register(self, name: str, handler: Handler) -> None:
        """Register a handler for a function name."""
        self._registry.register(name, handler)

    def get(self, name: str) -> Handler:
        return cast(Handler, self._registry.get(name))

    async def execute(self, name: str, payload: dict[str, Any]) -> Any:
        return await self._registry.execute(name, payload)

    @property
    def registry(self) -> FunctionRegistry:
        return self._registry
