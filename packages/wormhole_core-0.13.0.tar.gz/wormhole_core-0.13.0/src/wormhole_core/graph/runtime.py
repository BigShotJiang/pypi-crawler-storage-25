"""Session graph runtime helpers."""

from __future__ import annotations

import asyncio
import inspect
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Iterable, cast

from loopgraph.bus.eventbus import Event, EventBus, EventListener
from loopgraph.concurrency import ConcurrencyManager, SemaphorePolicy
from loopgraph.persistence import SnapshotStore
from loopgraph.registry.function_registry import FunctionRegistry
from loopgraph.scheduler.scheduler import Scheduler

from ..errors import (
    GraphCycleError,
    HandlerNotFoundError,
    SchedulerError,
    ToolExecutionTimeoutError,
    WormholeError,
)
from ..events.transform import event_to_log_entry
from ..logging import log_branch, log_loop_iteration, log_parameter
from ..storage.protocols import EventLogStoreProtocol
from ..tools.registry import ToolRegistry
from ..tools.timeout import resolve_timeout

if TYPE_CHECKING:
    from ..schemas.session import SessionConfig


_LOGGER = logging.getLogger(__name__)
_NODE_LEVEL_EVENT_TYPES = frozenset({"node_scheduled", "node_completed", "node_failed"})


@dataclass
class SessionRunResult:
    """Placeholder run result container until loopgraph integration lands."""

    graph_id: str
    result: dict[str, Any]


@dataclass(frozen=True)
class _CyclePolicy:
    main_loop_unbounded: bool = False
    is_sub_agent: bool = False


class SessionGraphRuntime:
    """Execute loopgraph graphs and manage EventBus subscriptions."""

    def __init__(
        self,
        registry: FunctionRegistry,
        event_bus: EventBus | None = None,
        concurrency_manager: ConcurrencyManager | None = None,
        snapshot_store: SnapshotStore | None = None,
        event_log_store: EventLogStoreProtocol | None = None,
        session_id: str | None = None,
        tool_registry: ToolRegistry | None = None,
        session_config: SessionConfig | None = None,
    ) -> None:
        self._registry = registry
        self._event_log_store = event_log_store
        self._event_log_session_id = session_id
        self._listener_error: Exception | None = None
        self._tool_registry = tool_registry
        self._session_config = session_config
        self._tool_lock = asyncio.Lock()
        self._wrapped_tools: set[str] = set()

        # Create error handler for event bus listeners
        async def _on_listener_error(exc: Exception, event: Event) -> None:
            log_branch("SessionGraphRuntime._on_listener_error", "listener_error")
            # Store the first listener error to be raised after scheduler completes
            if self._listener_error is None:
                self._listener_error = exc

        self._event_bus = event_bus or EventBus(on_error=_on_listener_error)
        self._concurrency_manager = concurrency_manager or SemaphorePolicy(limit=1)
        self._scheduler = Scheduler(
            self._registry,
            self._event_bus,
            self._concurrency_manager,
            snapshot_store=snapshot_store,
        )

    @property
    def event_bus(self) -> EventBus:
        return self._event_bus

    def subscribe(self, event_type: Any, listener: EventListener) -> None:
        log_parameter("SessionGraphRuntime.subscribe", event_type=event_type)
        self._event_bus.subscribe(event_type, listener)

    def unsubscribe(self, event_type: Any, listener: EventListener) -> None:
        log_parameter("SessionGraphRuntime.unsubscribe", event_type=event_type)
        self._event_bus.unsubscribe(event_type, listener)

    async def run(
        self,
        graph: Any,
        graph_id: str,
        payload: dict[str, Any] | None = None,
        session_id: str | None = None,
    ) -> SessionRunResult:
        """Run a graph with the configured Scheduler.

        >>> import asyncio
        >>> from loopgraph.core.graph import Edge, Graph, Node
        >>> from loopgraph.core.types import NodeKind
        >>> from loopgraph.registry.function_registry import FunctionRegistry
        >>> registry = FunctionRegistry()
        >>> registry.register("start", lambda payload: payload)
        >>> graph = Graph(
        ...     nodes={
        ...         "start": Node(id="start", kind=NodeKind.TASK, handler="start"),
        ...     },
        ...     edges={},
        ... )
        >>> runtime = SessionGraphRuntime(registry)
        >>> result = asyncio.run(runtime.run(graph=graph, graph_id="g1", payload={"ok": True}))
        >>> result.graph_id == "g1"
        True
        """
        log_parameter(
            "SessionGraphRuntime.run",
            graph_id=graph_id,
            payload=payload,
            call_id=graph_id,
        )
        cycle_policy = _resolve_cycle_policy(payload)
        detected_cycle = _find_cycle(
            graph,
            main_loop_unbounded=cycle_policy.main_loop_unbounded,
            is_sub_agent=cycle_policy.is_sub_agent,
        )
        if detected_cycle:
            log_branch("SessionGraphRuntime.run", "cycle_detected", call_id=graph_id)
            raise GraphCycleError(
                "graph cycle detected",
                {
                    "graph_id": graph_id,
                    "cycle": detected_cycle,
                    "main_loop_unbounded": cycle_policy.main_loop_unbounded,
                    "is_sub_agent": cycle_policy.is_sub_agent,
                },
            )
        missing_handlers = _find_missing_handlers(graph, self._registry)
        if missing_handlers:
            log_branch("SessionGraphRuntime.run", "missing_handlers", call_id=graph_id)
            raise HandlerNotFoundError(
                "graph handler missing",
                {"graph_id": graph_id, "handlers": missing_handlers},
            )
        self._wrap_tool_handlers(graph)
        listener: EventListener | None = None
        log_session_id = session_id or self._event_log_session_id
        loop_context = (
            payload.get("loop_context")
            if isinstance(payload, dict)
            and isinstance(payload.get("loop_context"), dict)
            else None
        )
        # Reset listener error state for this run
        self._listener_error = None

        if self._event_log_store is not None and log_session_id is not None:
            log_branch("SessionGraphRuntime.run", "event_log_enabled", call_id=graph_id)
            event_log_store = self._event_log_store  # capture for closure

            async def _log_listener(event: Event) -> None:
                if not _is_node_level_event(event):
                    return
                event_for_log = event
                if (
                    getattr(event, "node_id", None) == "continuation_check"
                    and _event_type_value(getattr(event, "type", None))
                    == "node_completed"
                    and not isinstance(getattr(event, "payload", None), dict)
                    and isinstance(loop_context, dict)
                ):
                    continuation_payload = loop_context.get("last_continuation_payload")
                    if isinstance(continuation_payload, dict):
                        event_for_log = Event(
                            id=event.id,
                            graph_id=event.graph_id,
                            node_id=event.node_id,
                            type=event.type,
                            payload=dict(continuation_payload),
                            timestamp=event.timestamp,
                            replay=event.replay,
                            visit_count=event.visit_count,
                            status=event.status,
                        )
                entry = event_to_log_entry(event_for_log, log_session_id)
                await event_log_store.append(entry)

            try:
                self._event_bus.subscribe(None, _log_listener)
            except Exception as exc:
                raise SchedulerError(
                    "event bus subscription failed",
                    {"graph_id": graph_id, "session_id": log_session_id},
                ) from exc
            listener = _log_listener
        else:
            log_branch(
                "SessionGraphRuntime.run", "event_log_disabled", call_id=graph_id
            )
            log_branch(
                "SessionGraphRuntime.run",
                "event_log_debug_fallback_enabled",
                call_id=graph_id,
            )

            async def _debug_listener(event: Event) -> None:
                if not _is_node_level_event(event):
                    return
                _LOGGER.debug(
                    "loopgraph.node_event %s",
                    {
                        "session_id": log_session_id,
                        "graph_id": getattr(event, "graph_id", None),
                        "node_id": getattr(event, "node_id", None),
                        "event_type": _event_type_value(getattr(event, "type", None)),
                        "status": _status_value(getattr(event, "status", None)),
                        "visit_count": getattr(event, "visit_count", None),
                        "payload": getattr(event, "payload", None),
                    },
                )

            try:
                self._event_bus.subscribe(None, _debug_listener)
            except Exception as exc:
                raise SchedulerError(
                    "event bus subscription failed",
                    {"graph_id": graph_id, "session_id": log_session_id},
                ) from exc
            listener = _debug_listener

        run_error: Exception | None = None
        try:
            result = await self._scheduler.run(
                graph,
                graph_id=graph_id,
                initial_payload=payload,
            )
        except WormholeError as exc:
            run_error = exc
            raise
        except Exception as exc:
            run_error = exc
            raise SchedulerError(
                "scheduler execution failed",
                {"graph_id": graph_id, "session_id": log_session_id},
            ) from exc
        finally:
            if listener is not None:
                try:
                    self._event_bus.unsubscribe(None, listener)
                except Exception as exc:
                    if run_error is None:
                        raise SchedulerError(
                            "event bus unsubscribe failed",
                            {"graph_id": graph_id, "session_id": log_session_id},
                        ) from exc

        # Check for listener errors that occurred during execution
        if self._listener_error is not None:
            raise SchedulerError(
                "event listener failed during execution",
                {"graph_id": graph_id, "session_id": log_session_id},
            ) from self._listener_error

        return SessionRunResult(graph_id=graph_id, result=result)

    def _wrap_tool_handlers(self, graph: Any) -> None:
        """Wrap tool handlers with concurrency control and timeout enforcement.

        For each tool handler:
        1. If not concurrency_safe, wrap with asyncio.Lock for serialization
        2. If timeout is configured (tool or session level), wrap with asyncio.wait_for
        3. On timeout, raise ToolExecutionTimeoutError
        """
        if self._tool_registry is None:
            return

        # Import here to avoid circular imports
        from ..schemas.session import SessionConfig

        # Use default config if none provided
        config = self._session_config or SessionConfig()

        for node_id, node in _iter_node_items(getattr(graph, "nodes", {})):
            handler_name = getattr(node, "handler", None)
            if not handler_name:
                continue
            handler_str = str(handler_name)
            if not handler_str.startswith("tool:"):
                continue
            if handler_str in self._wrapped_tools:
                continue
            tool_id = handler_str.split("tool:", 1)[1]
            try:
                tool = self._tool_registry.get(tool_id)
            except Exception:
                continue

            capabilities = getattr(tool, "capabilities", None)
            is_concurrency_safe = capabilities is not None and getattr(
                capabilities, "concurrency_safe", False
            )

            # Resolve effective timeout for this tool
            timeout = resolve_timeout(tool, config)

            handler = self._registry.get(handler_name)

            # Create wrapped handler with concurrency control and timeout
            async def guarded(
                payload: dict[str, Any],
                handler: Callable[[dict[str, Any]], Any] = handler,
                timeout: float | None = timeout,
                tool_id: str = tool_id,
                use_lock: bool = not is_concurrency_safe,
            ) -> Any:
                async def _execute() -> Any:
                    result = handler(payload)
                    if inspect.isawaitable(result):
                        return await result
                    return result

                async def _execute_with_timeout() -> Any:
                    if timeout is not None:
                        try:
                            return await asyncio.wait_for(_execute(), timeout=timeout)
                        except asyncio.TimeoutError:
                            # Extract tool_call_id from payload if available
                            tool_call_id = None
                            if isinstance(payload, dict):
                                tool_call_id = payload.get("tool_call_id")
                            raise ToolExecutionTimeoutError(
                                f"tool execution timed out after {timeout}s",
                                tool_id=tool_id,
                                tool_call_id=tool_call_id,
                                timeout=timeout,
                            )
                    return await _execute()

                if use_lock:
                    async with self._tool_lock:
                        return await _execute_with_timeout()
                return await _execute_with_timeout()

            self._registry.register(handler_name, guarded)
            self._wrapped_tools.add(handler_str)


def _iter_node_items(nodes: object) -> Iterable[tuple[str, Any]]:
    if isinstance(nodes, dict):
        return list(nodes.items())
    if nodes is None:
        return []
    # Cast to Iterable after runtime check
    if not hasattr(nodes, "__iter__"):
        return []
    node_list = list(cast(Iterable[Any], nodes))
    return [
        (getattr(node, "id", str(index)), node) for index, node in enumerate(node_list)
    ]


def _iter_edges(edges: object) -> Iterable[Any]:
    if isinstance(edges, dict):
        return list(edges.values())
    if edges is None:
        return []
    # Cast to Iterable after runtime check
    if not hasattr(edges, "__iter__"):
        return []
    return list(cast(Iterable[Any], edges))


def _find_cycle(
    graph: Any, *, main_loop_unbounded: bool = False, is_sub_agent: bool = False
) -> list[str] | None:
    """Return the first invalid cycle under the current session loop policy.

    Bounded cycles are valid when the cycle has at least one `max_visits` guard.
    Unbounded main-session cycles are valid only when `main_loop_unbounded=True`.
    Sub-agent sessions always use bounded-cycle rules.

    >>> from loopgraph.core.graph import Edge, Graph, Node
    >>> from loopgraph.core.types import NodeKind
    >>> guarded = Graph(
    ...     nodes={
    ...         "prompt_transform": Node(
    ...             id="prompt_transform",
    ...             kind=NodeKind.TASK,
    ...             handler="prompt_transform",
    ...             max_visits=2,
    ...         ),
    ...         "continuation_check": Node(
    ...             id="continuation_check",
    ...             kind=NodeKind.SWITCH,
    ...             handler="continuation_check",
    ...         ),
    ...     },
    ...     edges={
    ...         "e1": Edge(
    ...             id="e1", source="prompt_transform", target="continuation_check"
    ...         ),
    ...         "e2": Edge(
    ...             id="e2",
    ...             source="continuation_check",
    ...             target="prompt_transform",
    ...             metadata={"route": "continue"},
    ...         ),
    ...     },
    ... )
    >>> _find_cycle(guarded)
    >>> unbounded = Graph(
    ...     nodes={
    ...         "a": Node(id="a", kind=NodeKind.TASK, handler="a"),
    ...         "b": Node(id="b", kind=NodeKind.SWITCH, handler="b"),
    ...     },
    ...     edges={
    ...         "e1": Edge(id="e1", source="a", target="b"),
    ...         "e2": Edge(
    ...             id="e2", source="b", target="a", metadata={"route": "continue"}
    ...         ),
    ...     },
    ... )
    >>> _find_cycle(unbounded) is not None
    True
    >>> _find_cycle(unbounded, main_loop_unbounded=True, is_sub_agent=False)
    >>> _find_cycle(unbounded, main_loop_unbounded=True, is_sub_agent=True) is not None
    True
    """
    cycles = _collect_cycles(graph)
    if not cycles:
        return None
    if main_loop_unbounded and not is_sub_agent:
        return None
    for cycle in cycles:
        if _cycle_has_visit_guard(graph, cycle):
            continue
        return cycle
    return None


def _collect_cycles(graph: Any) -> list[list[str]]:
    finder = getattr(graph, "_find_cycles", None)
    if callable(finder):
        raw_cycles = finder()
        normalized: list[list[str]] = []
        for raw_cycle in raw_cycles:
            cycle = [str(node_id) for node_id in raw_cycle]
            if not cycle:
                continue
            if cycle[0] != cycle[-1]:
                cycle = cycle + [cycle[0]]
            normalized.append(cycle)
        return normalized
    fallback = _find_first_cycle(graph)
    if fallback is None:
        return []
    return [fallback]


def _find_first_cycle(graph: Any) -> list[str] | None:
    nodes = getattr(graph, "nodes", {})
    adjacency: dict[str, list[str]] = {}
    for node_id, _node in _iter_node_items(nodes):
        adjacency.setdefault(str(node_id), [])
    for edge in _iter_edges(getattr(graph, "edges", {})):
        source = getattr(edge, "source", None)
        target = getattr(edge, "target", None)
        if source is None or target is None:
            continue
        adjacency.setdefault(str(source), []).append(str(target))

    visited: set[str] = set()
    stack: set[str] = set()
    path: list[str] = []

    def _dfs(node_id: str, depth: int) -> list[str] | None:
        log_loop_iteration("_find_cycle", "dfs", depth)
        visited.add(node_id)
        stack.add(node_id)
        path.append(node_id)
        for neighbor in adjacency.get(node_id, []):
            if neighbor not in visited:
                cycle = _dfs(neighbor, depth + 1)
                if cycle:
                    return cycle
            elif neighbor in stack:
                try:
                    start_index = path.index(neighbor)
                except ValueError:
                    start_index = 0
                return path[start_index:] + [neighbor]
        stack.remove(node_id)
        path.pop()
        return None

    for index, node_id in enumerate(adjacency.keys(), start=1):
        log_loop_iteration("_find_first_cycle", "nodes", index)
        if node_id not in visited:
            cycle = _dfs(node_id, 1)
            if cycle:
                return cycle
    return None


def _cycle_has_visit_guard(graph: Any, cycle: list[str]) -> bool:
    node_map = {
        str(node_id): node
        for node_id, node in _iter_node_items(getattr(graph, "nodes", {}))
    }
    for node_id in cycle[:-1]:
        node = node_map.get(node_id)
        max_visits = getattr(node, "max_visits", None)
        if isinstance(max_visits, int):
            if max_visits > 0:
                return True
            continue
        if max_visits is not None:
            return True
    return False


def _resolve_cycle_policy(payload: dict[str, Any] | None) -> _CyclePolicy:
    if not isinstance(payload, dict):
        return _CyclePolicy()
    session_type = str(payload.get("session_type", "")).strip().lower()
    inferred_sub_agent = session_type in {"sub_agent", "subagent", "child"}
    explicit_sub_agent = bool(
        payload.get("is_sub_agent", payload.get("is_subagent", False))
    )
    return _CyclePolicy(
        main_loop_unbounded=bool(payload.get("main_loop_unbounded", False)),
        is_sub_agent=bool(explicit_sub_agent or inferred_sub_agent),
    )


def _event_type_value(value: object) -> str:
    return str(getattr(value, "value", value))


def _status_value(value: object) -> str | None:
    if value is None:
        return None
    return str(getattr(value, "value", value))


def _is_node_level_event(event: Event) -> bool:
    """Return True when event type is node-level and should be logged/persisted.

    >>> from loopgraph.core.types import EventType as LoopgraphEventType
    >>> evt = Event(
    ...     id="evt-1",
    ...     graph_id="g1",
    ...     node_id="n1",
    ...     type=LoopgraphEventType.NODE_COMPLETED,
    ... )
    >>> _is_node_level_event(evt)
    True
    """
    return _event_type_value(getattr(event, "type", None)) in _NODE_LEVEL_EVENT_TYPES


def _find_missing_handlers(graph: Any, registry: FunctionRegistry) -> list[str]:
    missing: list[str] = []
    nodes = getattr(graph, "nodes", {})
    for _node_id, node in _iter_node_items(nodes):
        handler_name = getattr(node, "handler", None)
        if handler_name:
            try:
                registry.get(handler_name)
            except KeyError:
                missing.append(str(handler_name))
    return missing
