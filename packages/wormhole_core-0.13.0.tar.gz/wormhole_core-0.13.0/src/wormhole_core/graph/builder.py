"""Session graph construction helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from uuid import uuid4

from loopgraph.core.graph import Edge, Graph, Node
from loopgraph.core.types import NodeKind


@dataclass
class SessionGraph:
    """Placeholder session graph container until loopgraph integration lands."""

    graph_id: str
    graph: Any


class SessionGraphBuilder:
    """Build loopgraph graphs for session execution."""

    def build(
        self, session_id: str, payload: dict[str, Any] | None = None
    ) -> SessionGraph:
        """Construct a graph for the given session.

        >>> builder = SessionGraphBuilder()
        >>> graph = builder.build("s1", payload={"max_consecutive_steps": 3})
        >>> graph.graph_id.startswith("s1-")
        True
        >>> graph.graph.nodes["prompt_transform"].max_visits
        3
        >>> len(graph.graph.nodes), len(graph.graph.edges)
        (8, 8)
        >>> any(
        ...     edge.source == "continuation_check"
        ...     and edge.target == "prompt_transform"
        ...     and edge.metadata.get("route") == "continue"
        ...     for edge in graph.graph.edges.values()
        ... )
        True
        """
        payload = payload or {}
        graph_id = str(payload.get("graph_id") or f"{session_id}-{uuid4()}")
        prompt_max_visits = _resolve_prompt_max_visits(payload)

        nodes: dict[str, Node] = {
            "input": Node(id="input", kind=NodeKind.TASK, handler="input_processor"),
            "prompt_transform": Node(
                id="prompt_transform",
                kind=NodeKind.TASK,
                handler="prompt_transform",
                max_visits=prompt_max_visits,
                allow_partial_upstream=True,
            ),
            "model": Node(id="model", kind=NodeKind.TASK, handler="model_adapter"),
            "tool_gate": Node(id="tool_gate", kind=NodeKind.TASK, handler="tool_gate"),
            "tool_executor": Node(
                id="tool_executor", kind=NodeKind.TASK, handler="tool_executor"
            ),
            "compaction_check": Node(
                id="compaction_check", kind=NodeKind.TASK, handler="compaction_check"
            ),
            "continuation_check": Node(
                id="continuation_check",
                kind=NodeKind.SWITCH,
                handler="continuation_check",
            ),
            "output": Node(
                id="output", kind=NodeKind.TERMINAL, handler="output_handler"
            ),
        }
        edges: dict[str, Edge] = {
            "edge-input-pt": Edge(
                id="edge-input-pt", source="input", target="prompt_transform"
            ),
            "edge-pt-model": Edge(
                id="edge-pt-model", source="prompt_transform", target="model"
            ),
            "edge-model-gate": Edge(
                id="edge-model-gate", source="model", target="tool_gate"
            ),
            "edge-gate-exec": Edge(
                id="edge-gate-exec", source="tool_gate", target="tool_executor"
            ),
            "edge-exec-cc": Edge(
                id="edge-exec-cc", source="tool_executor", target="compaction_check"
            ),
            "edge-cc-cont": Edge(
                id="edge-cc-cont",
                source="compaction_check",
                target="continuation_check",
            ),
            "edge-cont-pt": Edge(
                id="edge-cont-pt",
                source="continuation_check",
                target="prompt_transform",
                metadata={"route": "continue"},
            ),
            "edge-cont-out": Edge(
                id="edge-cont-out",
                source="continuation_check",
                target="output",
                metadata={"route": "done"},
            ),
        }

        graph = Graph(nodes=nodes, edges=edges)
        graph.validate()
        return SessionGraph(graph_id=graph_id, graph=graph)


def _resolve_prompt_max_visits(payload: dict[str, Any]) -> int | None:
    max_consecutive_steps = _normalize_max_consecutive_steps(
        payload.get("max_consecutive_steps", 25)
    )
    main_loop_unbounded = bool(payload.get("main_loop_unbounded", False))
    is_sub_agent = bool(payload.get("is_sub_agent", payload.get("is_subagent", False)))
    if main_loop_unbounded and not is_sub_agent:
        return None
    return max_consecutive_steps


def _normalize_max_consecutive_steps(raw_value: Any) -> int:
    if isinstance(raw_value, bool):
        return 25
    try:
        value = int(raw_value)
    except (TypeError, ValueError):
        return 25
    if value <= 0:
        return 25
    return value
