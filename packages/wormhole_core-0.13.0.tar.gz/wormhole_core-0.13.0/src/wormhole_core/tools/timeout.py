"""Tool execution timeout resolution helpers.

>>> from wormhole_core.schemas.tools import ToolCapabilities, ToolDefinition
>>> from wormhole_core.schemas.session import SessionConfig
>>> import math

# Tool timeout takes precedence over session
>>> tool = ToolDefinition(
...     tool_id="t1", name="fast", schema={"type": "object"},
...     capabilities=ToolCapabilities(execution_timeout_seconds=5.0)
... )
>>> config = SessionConfig(tool_execution_timeout_seconds=60.0)
>>> resolve_timeout(tool, config)
5.0

# None inherits from session config
>>> tool_inherit = ToolDefinition(
...     tool_id="t2", name="inherit", schema={"type": "object"},
...     capabilities=ToolCapabilities(execution_timeout_seconds=None)
... )
>>> resolve_timeout(tool_inherit, config)
60.0

# math.inf explicitly means no timeout even if session has default
>>> tool_infinite = ToolDefinition(
...     tool_id="t3", name="slow", schema={"type": "object"},
...     capabilities=ToolCapabilities(execution_timeout_seconds=math.inf)
... )
>>> resolve_timeout(tool_infinite, config) is None
True

# Both None means no timeout
>>> config_no_timeout = SessionConfig()
>>> resolve_timeout(tool_inherit, config_no_timeout) is None
True
"""

from __future__ import annotations

import math

from ..schemas.session import SessionConfig
from ..schemas.tools import ToolDefinition


def resolve_timeout(tool: ToolDefinition, config: SessionConfig) -> float | None:
    """Resolve effective timeout for a tool execution.

    Resolution order:
    1. tool.capabilities.execution_timeout_seconds if not None
       - If math.inf, return None (explicitly no timeout)
       - Otherwise return the tool timeout
    2. config.tool_execution_timeout_seconds if not None
    3. None (no timeout, block indefinitely)

    Args:
        tool: The tool definition with capabilities.
        config: The session configuration with default timeout.

    Returns:
        The effective timeout in seconds, or None for no timeout.
    """
    tool_timeout = tool.capabilities.execution_timeout_seconds

    if tool_timeout is not None:
        # Tool explicitly declares a timeout
        if math.isinf(tool_timeout):
            # math.inf means "explicitly no timeout"
            return None
        return tool_timeout

    # Inherit from session config
    return config.tool_execution_timeout_seconds
