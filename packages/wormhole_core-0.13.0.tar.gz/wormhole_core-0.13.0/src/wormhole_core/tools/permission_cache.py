"""Session-scoped permission cache for tool approvals.

>>> from wormhole_core.schemas.tools import PermissionAction, PermissionRule, PermissionScope
>>> cache = PermissionCache()
>>> cache.check("bash", "git status @ /project/*")
<PermissionAction.ASK: 'ask'>
>>> cache.add_rule(PermissionRule(
...     rule_id="r1",
...     tool_pattern="bash",
...     target_pattern="git * @ /project/*",
...     action=PermissionAction.ALLOW,
...     scope=PermissionScope.SESSION,
...     created_at=1706000000.0,
... ))
>>> cache.check("bash", "git status @ /project/*")
<PermissionAction.ALLOW: 'allow'>
>>> cache.add_rule(PermissionRule(
...     rule_id="r2",
...     tool_pattern="bash",
...     target_pattern="git * @ /project/*",
...     action=PermissionAction.DENY,
...     scope=PermissionScope.SESSION,
...     created_at=1706000001.0,
... ))
>>> cache.check("bash", "git status @ /project/*")
<PermissionAction.DENY: 'deny'>
>>> cache = PermissionCache()
>>> cache.add_rule(PermissionRule(
...     rule_id="once",
...     tool_pattern="bash",
...     target_pattern="git * @ /project/*",
...     action=PermissionAction.ALLOW,
...     scope=PermissionScope.ONCE,
...     created_at=1706000002.0,
... ))
>>> cache.check("bash", "git status @ /project/*")
<PermissionAction.ALLOW: 'allow'>
>>> cache.check("bash", "git status @ /project/*")
<PermissionAction.ASK: 'ask'>
>>> build_bash_permission_target("git status", Path("/project"))
'git * @ /project/*'
"""

from __future__ import annotations

from fnmatch import fnmatchcase
from pathlib import Path
from typing import Iterable, Sequence

from ..schemas.tools import PermissionAction, PermissionRule, PermissionScope
from .path_utils import normalize_path_pattern
from .shell_utils import extract_path_targets

_FILE_TOOL_PREFIX = "file_"


def _normalize_target(tool_id: str, target: str) -> str:
    if tool_id.startswith(_FILE_TOOL_PREFIX):
        return normalize_path_pattern(target)
    return target


def _matches_rule(rule: PermissionRule, tool_id: str, target: str) -> bool:
    if not fnmatchcase(tool_id, rule.tool_pattern):
        return False
    normalized_target = _normalize_target(tool_id, target)
    normalized_pattern = _normalize_target(tool_id, rule.target_pattern)
    return fnmatchcase(normalized_target, normalized_pattern)


def evaluate_rules(
    rules: Iterable[PermissionRule], tool_id: str, target: str
) -> PermissionAction:
    """Evaluate permission rules for a tool+target combination."""
    allow_match: PermissionRule | None = None
    deny_match: PermissionRule | None = None
    for rule in rules:
        if not _matches_rule(rule, tool_id, target):
            continue
        if rule.action == PermissionAction.DENY:
            deny_match = rule
        elif rule.action == PermissionAction.ALLOW:
            allow_match = rule
    if deny_match is not None:
        return PermissionAction.DENY
    if allow_match is not None:
        return PermissionAction.ALLOW
    return PermissionAction.ASK


def build_bash_permission_target(command: str, cwd: Path) -> str:
    """Build a permission target string for bash commands."""
    import shlex

    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = []
    if not tokens:
        prefix = "*"
    elif len(tokens) == 1:
        prefix = tokens[0]
    else:
        prefix = f"{tokens[0]} *"
    targets = extract_path_targets(command, cwd)
    if targets:
        base = targets[0].parent
    else:
        base = cwd
    path_pattern = f"{normalize_path_pattern(str(base))}/*"
    return f"{prefix} @ {path_pattern}"


class PermissionCache:
    """In-memory cache for permission rules."""

    def __init__(self, rules: Sequence[PermissionRule] | None = None) -> None:
        self._rules: list[PermissionRule] = list(rules or [])

    def add_rule(self, rule: PermissionRule) -> None:
        self._rules.append(rule)

    def clear(self) -> None:
        self._rules.clear()

    def clear_session(self) -> None:
        self.clear()

    def get_rules(self) -> list[PermissionRule]:
        return list(self._rules)

    def check(self, tool_id: str, target: str) -> PermissionAction:
        allow_match: PermissionRule | None = None
        deny_match: PermissionRule | None = None
        for rule in self._rules:
            if not _matches_rule(rule, tool_id, target):
                continue
            if rule.action == PermissionAction.DENY:
                deny_match = rule
            elif rule.action == PermissionAction.ALLOW:
                allow_match = rule
        if deny_match is not None:
            return PermissionAction.DENY
        if allow_match is not None:
            if allow_match.scope == PermissionScope.ONCE:
                self._rules = [
                    rule for rule in self._rules if rule.rule_id != allow_match.rule_id
                ]
            return PermissionAction.ALLOW
        return PermissionAction.ASK
