"""Tool registry for schema-first tool definitions.

>>> registry = ToolRegistry()
>>> tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
>>> registry.register(tool)
>>> registry.list_tools()[0].name
'echo'
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..errors import NotFoundError, ValidationError
from ..schemas.tools import ToolCall, ToolDefinition
from .schema import validate_tool_definition


@dataclass
class ToolRegistry:
    """Store tool definitions and create tool calls."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolDefinition] = {}
        self._handler_refs: dict[str, str] = {}

    def register(self, tool: ToolDefinition) -> None:
        validate_tool_definition(tool)
        if tool.tool_id in self._tools:
            raise ValidationError("tool already registered", {"tool_id": tool.tool_id})
        self._tools[tool.tool_id] = tool
        self._handler_refs.pop(tool.tool_id, None)

    def list_tools(self) -> list[ToolDefinition]:
        return list(self._tools.values())

    def get(self, tool_id: str) -> ToolDefinition:
        tool = self._tools.get(tool_id)
        if tool is None:
            raise NotFoundError("tool not found", {"tool_id": tool_id})
        return tool

    def bind_handler(self, tool_id: str, handler_ref: str) -> None:
        if tool_id not in self._tools:
            raise NotFoundError("tool not found", {"tool_id": tool_id})
        self._handler_refs[tool_id] = handler_ref

    def get_handler_ref(self, tool_id: str) -> str | None:
        if tool_id not in self._tools:
            raise NotFoundError("tool not found", {"tool_id": tool_id})
        return self._handler_refs.get(tool_id)

    def create_call(self, tool_id: str, arguments: dict[str, Any]) -> ToolCall:
        tool = self.get(tool_id)
        return ToolCall(
            tool_call_id=f"call-{tool.tool_id}",
            tool_id=tool.tool_id,
            arguments=arguments,
        )
