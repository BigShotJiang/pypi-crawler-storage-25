"""Tool schema validation helpers.

>>> from wormhole_core.schemas.tools import ToolCapabilities, ToolDefinition
>>> import math

# Valid tool with timeout
>>> tool = ToolDefinition(
...     tool_id="t1", name="echo", schema={"type": "object"},
...     capabilities=ToolCapabilities(execution_timeout_seconds=30.0)
... )
>>> validate_tool_definition(tool)

# Valid tool with infinite timeout (explicit no-timeout)
>>> tool_inf = ToolDefinition(
...     tool_id="t2", name="slow", schema={"type": "object"},
...     capabilities=ToolCapabilities(execution_timeout_seconds=math.inf)
... )
>>> validate_tool_definition(tool_inf)

# Invalid timeout (zero)
>>> tool_zero = ToolDefinition(
...     tool_id="t3", name="bad", schema={"type": "object"},
...     capabilities=ToolCapabilities(execution_timeout_seconds=0)
... )
>>> validate_tool_definition(tool_zero)
Traceback (most recent call last):
    ...
wormhole_core.errors.ValidationError: WH-CORE-001: capabilities.execution_timeout_seconds must be > 0 or inf when specified

# Invalid timeout (negative)
>>> tool_neg = ToolDefinition(
...     tool_id="t4", name="bad", schema={"type": "object"},
...     capabilities=ToolCapabilities(execution_timeout_seconds=-1.0)
... )
>>> validate_tool_definition(tool_neg)
Traceback (most recent call last):
    ...
wormhole_core.errors.ValidationError: WH-CORE-001: capabilities.execution_timeout_seconds must be > 0 or inf when specified
"""

from __future__ import annotations

import math

from ..errors import ValidationError
from ..schemas.tools import ToolCapabilities, ToolDefinition


def validate_tool_definition(tool: ToolDefinition) -> None:
    """Validate a tool definition.

    >>> tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
    >>> validate_tool_definition(tool)
    """
    if not tool.schema:
        raise ValidationError("tool schema is required", {"tool_id": tool.tool_id})
    _validate_capabilities(tool.capabilities, tool.tool_id)
    if (
        tool.default_retry_policy is not None
        and tool.default_retry_policy.max_retries < 0
    ):
        raise ValidationError(
            "default_retry_policy.max_retries must be >= 0", {"tool_id": tool.tool_id}
        )


def _validate_capabilities(capabilities: ToolCapabilities, tool_id: str) -> None:
    if not isinstance(capabilities.read_only, bool):
        raise ValidationError(
            "capabilities.read_only must be bool", {"tool_id": tool_id}
        )
    if not isinstance(capabilities.concurrency_safe, bool):
        raise ValidationError(
            "capabilities.concurrency_safe must be bool", {"tool_id": tool_id}
        )
    if not isinstance(capabilities.approval_required, bool):
        raise ValidationError(
            "capabilities.approval_required must be bool", {"tool_id": tool_id}
        )
    # Validate execution_timeout_seconds: None is allowed, math.inf is allowed, >0 is allowed
    timeout = capabilities.execution_timeout_seconds
    if timeout is not None:
        if not math.isinf(timeout) and timeout <= 0:
            raise ValidationError(
                "capabilities.execution_timeout_seconds must be > 0 or inf when specified",
                {"tool_id": tool_id},
            )
