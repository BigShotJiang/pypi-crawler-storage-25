"""Path normalization and boundary validation helpers.

>>> from pathlib import Path
>>> base = Path("/project")
>>> normalize_path_pattern("/project/src/../README.md")
'/project/README.md'
>>> is_within_boundary(Path("/project/src/main.py"), base)
True
>>> is_within_boundary(Path("/etc/passwd"), base)
False
"""

from __future__ import annotations

import posixpath
from pathlib import Path

from ..errors import ValidationError


def normalize_path_pattern(path: str) -> str:
    """Normalize a path or path pattern for matching."""
    cleaned = path.replace("\\", "/")
    return posixpath.normpath(cleaned)


def resolve_path(path: Path) -> Path:
    return path.expanduser().resolve()


def is_within_boundary(path: Path, boundary: Path) -> bool:
    """Check whether a path is within a boundary after resolution."""
    try:
        return resolve_path(path).is_relative_to(resolve_path(boundary))
    except AttributeError:
        resolved_path = resolve_path(path)
        resolved_boundary = resolve_path(boundary)
        return str(resolved_path).startswith(str(resolved_boundary))


def ensure_within_boundary(path: Path, boundary: Path) -> None:
    if not is_within_boundary(path, boundary):
        raise ValidationError(
            "path escapes boundary",
            {"path": str(path), "boundary": str(boundary)},
        )
