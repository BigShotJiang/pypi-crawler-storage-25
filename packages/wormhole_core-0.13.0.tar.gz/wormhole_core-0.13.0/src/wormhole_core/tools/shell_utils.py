"""Shell detection and command parsing helpers.

>>> needs_shell("ls -la")
False
>>> needs_shell("cat file.txt | grep foo")
True
>>> from pathlib import Path
>>> extract_path_targets("git status", Path("/project"))
[]
>>> [p.as_posix() for p in extract_path_targets("cat README.md", Path("/project"))]
['/project/README.md']
"""

from __future__ import annotations

import shlex
from pathlib import Path

_SHELL_META = set("|&;<>()$`\\\"'{}*?[]")
_REDIRECT_TOKENS = {">", ">>", "<", "2>", "2>>", "&>", "1>", "1>>"}


def needs_shell(command: str) -> bool:
    """Detect if a command requires a shell."""
    return any(char in command for char in _SHELL_META)


def _is_path_token(token: str) -> bool:
    if token.startswith("-"):
        return False
    if token in _REDIRECT_TOKENS:
        return False
    if "/" in token or token.startswith((".", "~")):
        return True
    return "." in token


def extract_path_targets(command: str, cwd: Path) -> list[Path]:
    """Extract path-like arguments from a command."""
    try:
        tokens = shlex.split(command)
    except ValueError:
        return []
    if len(tokens) <= 1:
        return []
    paths: list[Path] = []
    for token in tokens[1:]:
        if not _is_path_token(token):
            continue
        path = Path(token).expanduser()
        if not path.is_absolute():
            path = (cwd / path).resolve()
        else:
            path = path.resolve()
        paths.append(path)
    return paths
