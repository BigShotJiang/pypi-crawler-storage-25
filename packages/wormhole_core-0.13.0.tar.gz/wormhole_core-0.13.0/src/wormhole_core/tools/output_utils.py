"""Output truncation helpers.

>>> truncate_output("hello", 10)
('hello', 1, False)
>>> truncate_output("a\\nb\\nc", 2)
('a\\n', 3, True)
"""

from __future__ import annotations

from ..errors import ValidationError


def truncate_output(text: str, limit: int) -> tuple[str, int, bool]:
    """Truncate output to a character limit while preserving total line count."""
    if limit <= 0:
        raise ValidationError("output limit must be > 0", {"limit": limit})
    total_lines = text.count("\n") + (1 if text else 0)
    if len(text) <= limit:
        return text, total_lines, False
    truncated = text[:limit]
    return truncated, total_lines, True
