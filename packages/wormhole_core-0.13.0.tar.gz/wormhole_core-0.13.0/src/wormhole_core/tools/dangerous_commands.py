"""Dangerous command detection helpers.

>>> detect_dangerous_patterns("rm -rf /tmp/test")
['rm -rf *']
>>> detect_shell_injection("cat file.txt | grep foo")
True
"""

from __future__ import annotations

from fnmatch import fnmatchcase
from pathlib import Path

from ..schemas.tools import RiskLevel
from .path_utils import is_within_boundary
from .shell_utils import extract_path_targets

DANGEROUS_PATTERNS = [
    "rm -rf *",
    "rm -fr *",
    "dd *",
    "chmod 777 *",
    "chown -R *",
    "mkfs *",
    "shutdown *",
    "reboot *",
]

INJECTION_TOKENS = ["|", "&&", "||", ";", "`", "$(", ">", "<"]


def detect_dangerous_patterns(command: str) -> list[str]:
    return [pattern for pattern in DANGEROUS_PATTERNS if fnmatchcase(command, pattern)]


def detect_shell_injection(command: str) -> bool:
    return any(token in command for token in INJECTION_TOKENS)


def detect_directory_escape(command: str, cwd: Path, boundary: Path) -> bool:
    for target in extract_path_targets(command, cwd):
        if not is_within_boundary(target, boundary):
            return True
    return False


def assess_risk_level(
    command: str,
    *,
    dangerous_patterns: list[str],
    shell_injection: bool,
    directory_escape: bool,
) -> RiskLevel:
    if dangerous_patterns or directory_escape:
        return RiskLevel.HIGH
    if shell_injection:
        return RiskLevel.MEDIUM
    return RiskLevel.LOW
