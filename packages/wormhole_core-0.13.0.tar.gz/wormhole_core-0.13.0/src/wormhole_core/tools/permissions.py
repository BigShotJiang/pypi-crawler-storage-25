"""Permission checks for tool execution.

>>> from wormhole_core.schemas.tools import PermissionAction, PermissionRule, PermissionScope
>>> from wormhole_core.tools.permission_cache import PermissionCache
>>> cache = PermissionCache()
>>> cache.add_rule(PermissionRule(
...     rule_id="r1",
...     tool_pattern="bash",
...     target_pattern="git * @ /project/*",
...     action=PermissionAction.ALLOW,
...     scope=PermissionScope.SESSION,
...     created_at=1706000000.0,
... ))
>>> evaluate_permission(cache, "bash", "git status @ /project/*")
<PermissionAction.ALLOW: 'allow'>
"""

from __future__ import annotations

from ..schemas.session import SessionConfig
from ..schemas.tools import PermissionAction, ToolDefinition
from .permission_cache import PermissionCache


def is_tool_allowed(tool: ToolDefinition, config: SessionConfig) -> bool:
    """Check whether a tool is allowed for the session config.

    >>> tool = ToolDefinition(tool_id="t1", name="echo", schema={"type": "object"})
    >>> is_tool_allowed(tool, SessionConfig(allowlisted_tools=["echo"]))
    True
    """
    allowlisted = set(config.allowlisted_tools)
    return tool.tool_id in allowlisted or tool.name in allowlisted


def evaluate_permission(
    cache: PermissionCache, tool_id: str, target: str
) -> PermissionAction:
    """Evaluate a permission cache decision for a tool+target."""
    return cache.check(tool_id, target)


def is_permission_allowed(cache: PermissionCache, tool_id: str, target: str) -> bool:
    """Return True when permission cache allows the request."""
    return evaluate_permission(cache, tool_id, target) == PermissionAction.ALLOW
