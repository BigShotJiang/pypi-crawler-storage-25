"""Session-related request/response types."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ForkRequest:
    """Request to fork a session.

    >>> req = ForkRequest(parent_session_id="s1")
    >>> req.parent_session_id
    's1'
    """

    parent_session_id: str
    new_session_id: str | None = None


@dataclass(frozen=True)
class ForkResult:
    """Result of a fork operation.

    >>> res = ForkResult(
    ...     child_session_id="s2",
    ...     parent_session_id="s1",
    ...     compaction_triggered=False,
    ... )
    >>> res.child_session_id
    's2'
    """

    child_session_id: str
    parent_session_id: str
    compaction_triggered: bool
