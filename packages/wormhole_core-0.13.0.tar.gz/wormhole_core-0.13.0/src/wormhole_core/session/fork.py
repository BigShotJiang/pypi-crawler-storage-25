"""Session forking helpers."""

from __future__ import annotations

import time
from dataclasses import replace
from uuid import uuid4

from wormhole_core.compaction.protocols import SummarizationStrategy
from wormhole_core.compaction.strategies import NoOpSummarizationStrategy
from wormhole_core.errors import ErrorCode, ForkError, NotFoundError
from wormhole_core.events.stream import EventStream
from wormhole_core.events.types import CoreEvent, EventType
from wormhole_core.hooks.registry import HookRegistry
from wormhole_core.hooks.types import HookContext, HookPoint
from wormhole_core.logging import log_branch, log_parameter, log_variable_change
from wormhole_core.loop.compaction import (
    _estimate_token_count,
    build_reconstructed_context,
    compact_session,
)
from wormhole_core.schemas.session import (
    CompactionConfig,
    CompactionStage,
    Session,
    SessionStatus,
)
from wormhole_core.session.types import ForkRequest, ForkResult
from wormhole_core.storage.protocols import (
    CompactionStoreProtocol,
    SessionStoreProtocol,
)
from wormhole_core.storage.session_store import SessionRecord


async def fork_session(
    request: ForkRequest,
    *,
    session_store: SessionStoreProtocol,
    compaction_store: CompactionStoreProtocol,
    context_limit: int | None = None,
    summarization_strategy: SummarizationStrategy | None = None,
    compaction_config: CompactionConfig | None = None,
    hooks: HookRegistry | None = None,
    event_stream: EventStream[CoreEvent] | None = None,
) -> ForkResult:
    """Create a forked session with full history copy.

    >>> import asyncio
    >>> import tempfile
    >>> from pathlib import Path
    >>> from wormhole_core.schemas.session import Session, SessionConfig, SessionStatus
    >>> from wormhole_core.session.types import ForkRequest
    >>> from wormhole_core.storage.compaction_store import CompactionStore
    >>> from wormhole_core.storage.session_store import SessionRecord, SessionStore
    >>> root = Path(tempfile.mkdtemp())
    >>> session_store = SessionStore(root / "sessions")
    >>> compaction_store = CompactionStore(root / "compactions")
    >>> parent = Session(session_id="parent", status=SessionStatus.RUNNING)
    >>> record = SessionRecord(
    ...     session=parent,
    ...     config=SessionConfig(),
    ...     state=None,
    ...     messages=[],
    ...     compaction_snapshot_id=None,
    ... )
    >>> asyncio.run(session_store.save(record))
    >>> result = asyncio.run(
    ...     fork_session(
    ...         ForkRequest(parent_session_id="parent", new_session_id="child"),
    ...         session_store=session_store,
    ...         compaction_store=compaction_store,
    ...     )
    ... )
    >>> result.child_session_id
    'child'
    """
    parent_session_id = request.parent_session_id
    child_session_id = request.new_session_id or f"sess-{uuid4().hex[:8]}"
    call_id = parent_session_id
    log_parameter(
        "fork_session",
        parent_session_id=parent_session_id,
        child_session_id=child_session_id,
        call_id=call_id,
    )

    if request.new_session_id is not None:
        try:
            await session_store.load(child_session_id)
        except NotFoundError:
            pass
        else:
            raise ForkError(
                ErrorCode.FORK_CHILD_ALREADY_EXISTS,
                "child session already exists",
                {"child_session_id": child_session_id},
            )

    try:
        parent_record = await session_store.load(parent_session_id)
    except NotFoundError as exc:
        raise ForkError(
            ErrorCode.FORK_PARENT_NOT_FOUND,
            "parent session not found",
            {"parent_session_id": parent_session_id},
        ) from exc

    latest_snapshot_id = (
        parent_record.session.latest_compaction_id
        or parent_record.compaction_snapshot_id
    )
    if latest_snapshot_id:
        snapshot = await compaction_store.load(latest_snapshot_id)
        if snapshot.stage in {CompactionStage.PRUNING, CompactionStage.SUMMARIZING}:
            raise ForkError(
                ErrorCode.FORK_PARENT_IN_PROGRESS,
                "compaction in progress",
                {
                    "parent_session_id": parent_session_id,
                    "snapshot_id": latest_snapshot_id,
                },
                retryable=True,
            )

    if event_stream is not None:
        await event_stream.publish(
            CoreEvent(
                session_id=parent_session_id,
                type=EventType.FORK_STARTED,
                payload={
                    "parent_session_id": parent_session_id,
                    "child_session_id": child_session_id,
                },
            )
        )

    now = time.time()
    child_session = Session(
        session_id=child_session_id,
        status=SessionStatus.RUNNING,
        created_at=now,
        updated_at=now,
        retention_expires_at=parent_record.session.retention_expires_at,
        latest_compaction_id=None,
        graph_id=None,
        execution_state_id=None,
        event_log_id=parent_record.session.event_log_id,
        parent_session_id=parent_session_id,
    )

    child_messages = list(parent_record.messages)
    child_record = SessionRecord(
        session=child_session,
        config=parent_record.config,
        state=None,
        messages=child_messages,
        compaction_snapshot_id=parent_record.compaction_snapshot_id,
    )

    await session_store.save(child_record)

    compaction_triggered = False
    if context_limit is not None and context_limit > 0:
        reconstructed, _, _ = build_reconstructed_context(
            child_messages, protected_rounds=2
        )
        remaining_tokens = _estimate_token_count(reconstructed)
        log_variable_change(
            "fork_session",
            "remaining_token_estimate",
            None,
            remaining_tokens,
            call_id=call_id,
        )
        if remaining_tokens > context_limit:
            compaction_triggered = True
            strategy = summarization_strategy or NoOpSummarizationStrategy()
            result = await compact_session(
                session_id=child_session_id,
                messages=child_messages,
                compaction_store=compaction_store,
                summarization_strategy=strategy,
                config=compaction_config or CompactionConfig(),
                context_limit=context_limit,
                hooks=hooks,
                event_stream=event_stream,
                correlation_id=child_session_id,
            )
            child_session = replace(
                child_session,
                latest_compaction_id=result.snapshot_id,
                updated_at=time.time(),
            )
            child_record = replace(
                child_record,
                session=child_session,
                compaction_snapshot_id=result.snapshot_id,
            )
            await session_store.save(child_record)
            log_branch("fork_session", "auto_compacted", call_id=call_id)

    if hooks is not None:
        await hooks.invoke(
            HookPoint.POST_FORK,
            HookContext(
                session_id=parent_session_id,
                hook_point=HookPoint.POST_FORK,
                payload={
                    "parent_session_id": parent_session_id,
                    "child_session_id": child_session_id,
                    "compaction_triggered": compaction_triggered,
                    "correlation_id": call_id,
                },
                timestamp=time.time(),
            ),
        )

    if event_stream is not None:
        await event_stream.publish(
            CoreEvent(
                session_id=parent_session_id,
                type=EventType.FORK_COMPLETED,
                payload={
                    "parent_session_id": parent_session_id,
                    "child_session_id": child_session_id,
                    "compaction_triggered": compaction_triggered,
                },
            )
        )

    return ForkResult(
        child_session_id=child_session_id,
        parent_session_id=parent_session_id,
        compaction_triggered=compaction_triggered,
    )
