"""Resume and replay helpers."""

from __future__ import annotations

import time

from ..errors import NotFoundError, PersistenceError, SessionExpiredError, SnapshotError
from ..schemas.session import ExecutionStateSnapshot
from ..storage.execution_state_store import ExecutionStateStore
from ..storage.session_store import SessionRecord, SessionStore, is_retention_expired


def resume_session(
    store: SessionStore,
    snapshot_store: ExecutionStateStore,
    session_id: str,
    now: float | None = None,
) -> tuple[SessionRecord, ExecutionStateSnapshot]:
    """Resume a session from persistence."""
    record = store._sync_load(session_id)
    current_time = time.time() if now is None else now
    if is_retention_expired(record.session, current_time):
        raise SessionExpiredError("session expired", {"session_id": session_id})
    execution_state_id = record.session.execution_state_id
    if execution_state_id is None:
        raise SnapshotError(
            "missing execution state snapshot", {"session_id": session_id}
        )
    try:
        snapshot = snapshot_store._sync_load(execution_state_id)
    except (NotFoundError, PersistenceError) as exc:
        raise SnapshotError(
            "invalid execution state snapshot",
            {"session_id": session_id, "execution_state_id": execution_state_id},
        ) from exc
    return record, snapshot
