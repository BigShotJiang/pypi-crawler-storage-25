"""Compaction helpers for large sessions."""

from __future__ import annotations

import json
import time
from typing import Sequence
from uuid import uuid4

from ..compaction.context import CompactionContext
from ..compaction.protocols import SummarizationStrategy
from ..compaction.retry import retry_async
from ..compaction.types import CompactionResult
from ..errors import CompactionError, ErrorCode
from ..events.stream import EventStream
from ..events.types import CoreEvent, EventType
from ..hooks.registry import HookRegistry
from ..hooks.types import HookContext, HookPoint
from ..logging import log_branch, log_parameter, log_timing, log_variable_change
from ..schemas.messages import Message, MessageRole, Part, PartType
from ..schemas.session import CompactionConfig, CompactionSnapshot, CompactionStage
from ..storage.protocols import CompactionStoreProtocol


def should_compact(context_ratio: float, config: CompactionConfig) -> bool:
    """Determine if compaction should run.

    >>> should_compact(0.95, CompactionConfig(trigger_threshold=0.9))
    True
    >>> should_compact(0.6, CompactionConfig(trigger_threshold=0.9))
    False
    """
    if not config.auto_enabled:
        return False
    return context_ratio >= config.trigger_threshold


def _estimate_token_count(messages: Sequence[Message]) -> int:
    """Estimate token usage for a list of messages.

    >>> from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
    >>> msg = Message(
    ...     id="m1",
    ...     role=MessageRole.USER,
    ...     parts=[Part(id="p1", type=PartType.TEXT, payload="abcd")],
    ... )
    >>> _estimate_token_count([msg])
    1
    """
    total = 0
    for msg in messages:
        for part in msg.parts:
            total += _estimate_payload_tokens(part.payload)
    return total


def _estimate_payload_tokens(payload: object) -> int:
    """Estimate token usage for a payload.

    >>> _estimate_payload_tokens("abcd")
    1
    >>> _estimate_payload_tokens("")
    0
    """
    text = str(payload)
    if not text:
        return 0
    return max(1, len(text) // 4)


def _part_tool_call_id(part: Part) -> str | None:
    payload = part.payload
    if not isinstance(payload, dict):
        return None
    value = payload.get("tool_call_id")
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def _part_tool_name(part: Part) -> str:
    payload = part.payload
    if not isinstance(payload, dict):
        return "unknown_tool"
    value = payload.get("tool_name")
    if isinstance(value, str) and value.strip():
        return value.strip()
    fallback = payload.get("tool_id")
    if isinstance(fallback, str) and fallback.strip():
        return fallback.strip()
    return "unknown_tool"


def _make_pruned_tool_output_part(
    *, part_id: str, tool_call_id: str, tool_id: str
) -> Part:
    return Part(
        id=part_id,
        type=PartType.TOOL_OUTPUT,
        payload={
            "tool_call_id": tool_call_id,
            "tool_id": tool_id,
            "output": "[pruned by compaction]",
            "status": "pruned",
            "error": None,
            "pruned": True,
        },
    )


def _prune_tool_output_part(part: Part) -> Part:
    tool_call_id = _part_tool_call_id(part)
    if tool_call_id is None:
        return Part(
            id=part.id,
            type=PartType.TEXT,
            payload={"text": "[invalid tool_output pruned: missing tool_call_id]"},
            metadata=dict(part.metadata),
        )
    payload = part.payload if isinstance(part.payload, dict) else {}
    tool_id = payload.get("tool_id")
    resolved_tool_id = (
        tool_id.strip()
        if isinstance(tool_id, str) and tool_id.strip()
        else "unknown_tool"
    )
    pruned = _make_pruned_tool_output_part(
        part_id=part.id,
        tool_call_id=tool_call_id,
        tool_id=resolved_tool_id,
    )
    return Part(
        id=pruned.id,
        type=pruned.type,
        payload=pruned.payload,
        metadata=dict(part.metadata),
    )


def _build_repair_tool_output_message(calls: Sequence[tuple[str, str]]) -> Message:
    parts = [
        _make_pruned_tool_output_part(
            part_id=f"part-compaction-repair-{uuid4().hex[:8]}",
            tool_call_id=tool_call_id,
            tool_id=tool_id,
        )
        for tool_call_id, tool_id in calls
    ]
    return Message(
        id=f"msg-compaction-repair-{uuid4().hex[:8]}",
        role=MessageRole.USER,
        parts=parts,
        metadata={"compaction_repair": True},
    )


def _ensure_tool_result_pairs(messages: Sequence[Message]) -> list[Message]:
    """Repair missing tool outputs by inserting pruned placeholders.

    >>> from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
    >>> messages = [
    ...     Message(
    ...         id="m1",
    ...         role=MessageRole.ASSISTANT,
    ...         parts=[Part(id="p1", type=PartType.TOOL_CALL, payload={"tool_call_id": "tc1"})],
    ...     )
    ... ]
    >>> repaired = _ensure_tool_result_pairs(messages)
    >>> repaired[1].role
    <MessageRole.USER: 'user'>
    """
    normalized: list[Message] = []
    for message in messages:
        changed = False
        normalized_parts: list[Part] = []
        for part in message.parts:
            if part.type is PartType.TOOL_OUTPUT and _part_tool_call_id(part) is None:
                changed = True
                normalized_parts.append(
                    Part(
                        id=part.id,
                        type=PartType.TEXT,
                        payload={
                            "text": "[invalid tool_output ignored: missing tool_call_id]"
                        },
                        metadata=dict(part.metadata),
                    )
                )
                continue
            normalized_parts.append(part)
        if changed:
            normalized.append(
                Message(
                    id=message.id,
                    role=message.role,
                    parts=normalized_parts,
                    created_at=message.created_at,
                    metadata=dict(message.metadata),
                )
            )
        else:
            normalized.append(message)

    repaired = list(normalized)
    index = 0
    while index < len(repaired):
        message = repaired[index]
        if message.role is not MessageRole.ASSISTANT:
            index += 1
            continue
        call_pairs: list[tuple[str, str]] = []
        for part in message.parts:
            if part.type is not PartType.TOOL_CALL:
                continue
            tool_call_id = _part_tool_call_id(part)
            if tool_call_id is None:
                continue
            call_pairs.append((tool_call_id, _part_tool_name(part)))
        if not call_pairs:
            index += 1
            continue

        if (
            index + 1 >= len(repaired)
            or repaired[index + 1].role is not MessageRole.USER
        ):
            repaired.insert(index + 1, _build_repair_tool_output_message(call_pairs))
            index += 2
            continue

        next_message = repaired[index + 1]
        next_output_ids = {
            tool_call_id
            for part in next_message.parts
            if part.type is PartType.TOOL_OUTPUT
            for tool_call_id in [(_part_tool_call_id(part))]
            if tool_call_id is not None
        }
        if not next_output_ids:
            repaired.insert(index + 1, _build_repair_tool_output_message(call_pairs))
            index += 2
            continue

        missing_pairs = [
            (tool_call_id, tool_id)
            for tool_call_id, tool_id in call_pairs
            if tool_call_id not in next_output_ids
        ]
        if missing_pairs:
            appended = list(next_message.parts) + [
                _make_pruned_tool_output_part(
                    part_id=f"part-compaction-repair-{uuid4().hex[:8]}",
                    tool_call_id=tool_call_id,
                    tool_id=tool_id,
                )
                for tool_call_id, tool_id in missing_pairs
            ]
            repaired[index + 1] = Message(
                id=next_message.id,
                role=next_message.role,
                parts=appended,
                created_at=next_message.created_at,
                metadata=dict(next_message.metadata),
            )
        index += 1
    return repaired


def _part_text_content(part: Part) -> str:
    payload = part.payload
    if part.type is PartType.TEXT:
        if isinstance(payload, dict):
            return str(payload.get("text", ""))
        return str(payload)
    if part.type is PartType.TOOL_CALL:
        if isinstance(payload, dict):
            tool_name = payload.get("tool_name", "tool")
            arguments = payload.get("arguments", {})
            return f"[tool_call] {tool_name} {json.dumps(arguments, ensure_ascii=True, default=str)}"
        return f"[tool_call] {payload}"
    if part.type is PartType.TOOL_OUTPUT:
        if isinstance(payload, dict):
            error = payload.get("error")
            if error:
                return f"[tool_output_error] {error}"
            return f"[tool_output] {payload.get('output', '')}"
        return f"[tool_output] {payload}"
    return str(payload)


def _prepare_summarization_messages(messages: Sequence[Message]) -> list[Message]:
    """Normalize messages to text-only parts for summarization providers.

    >>> from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
    >>> normalized = _prepare_summarization_messages([
    ...     Message(
    ...         id="m1",
    ...         role=MessageRole.ASSISTANT,
    ...         parts=[Part(id="p1", type=PartType.TOOL_CALL, payload={"tool_name": "calc", "arguments": {"a": 1}})],
    ...     )
    ... ])
    >>> normalized[0].parts[0].type is PartType.TEXT
    True
    """
    normalized: list[Message] = []
    for message in messages:
        lines: list[str] = []
        for part in message.parts:
            text = _part_text_content(part).strip()
            if text:
                lines.append(text)
        if not lines:
            continue
        normalized.append(
            Message(
                id=message.id,
                role=message.role,
                parts=[
                    Part(
                        id=f"part-sum-{message.id}",
                        type=PartType.TEXT,
                        payload={"text": "\n".join(lines)},
                    )
                ],
                created_at=message.created_at,
                metadata=dict(message.metadata),
            )
        )
    return normalized


def _render_pruned_history(messages: Sequence[Message]) -> str:
    """Render pruned context into a structured text payload.

    >>> from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
    >>> rendered = _render_pruned_history([
    ...     Message(
    ...         id="m1",
    ...         role=MessageRole.USER,
    ...         parts=[Part(id="p1", type=PartType.TEXT, payload={"text": "hi"})],
    ...     )
    ... ])
    >>> "hi" in rendered
    True
    """
    rendered = [
        {
            "id": message.id,
            "role": message.role.value,
            "parts": [
                {"type": part.type.value, "payload": part.payload}
                for part in message.parts
            ],
            "metadata": dict(message.metadata),
        }
        for message in messages
    ]
    return json.dumps(rendered, ensure_ascii=True, default=str, separators=(",", ":"))


def find_last_compaction_message(messages: Sequence[Message]) -> int | None:
    """Find the index of the last compaction-tagged message.

    >>> from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
    >>> msg1 = Message(id="m1", role=MessageRole.USER, parts=[Part(id="p1", type=PartType.TEXT, payload="hi")])
    >>> msg2 = Message(
    ...     id="m2",
    ...     role=MessageRole.SYSTEM,
    ...     parts=[Part(id="p2", type=PartType.TEXT, payload="summary")],
    ...     metadata={"compaction": True, "snapshot_id": "snap-1"},
    ... )
    >>> find_last_compaction_message([msg1, msg2])
    1
    """
    for index in range(len(messages) - 1, -1, -1):
        metadata = messages[index].metadata or {}
        if metadata.get("compaction") is True:
            return index
    return None


def prune_messages(
    messages: Sequence[Message],
    protected_rounds: int,
) -> tuple[list[Message], int, int]:
    """Prune tool_output payloads while protecting recent rounds.

    Returns reconstructed messages, count of pruned parts, and estimated tokens freed.

    >>> from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
    >>> msg = Message(
    ...     id="m1",
    ...     role=MessageRole.ASSISTANT,
    ...     parts=[
    ...         Part(id="p1", type=PartType.TOOL_OUTPUT, payload="abcd"),
    ...         Part(id="p2", type=PartType.TEXT, payload="ok"),
    ...     ],
    ... )
    >>> pruned, count, tokens = prune_messages([msg], protected_rounds=0)
    >>> count
    1
    >>> tokens >= 0
    True
    >>> [part.type for part in pruned[0].parts]
    [<PartType.TEXT: 'text'>, <PartType.TEXT: 'text'>]
    """
    if not messages:
        return [], 0, 0
    protected_count = max(protected_rounds, 0) * 2
    protected_start = max(len(messages) - protected_count, 0)
    pruned: list[Message] = []
    pruned_count = 0
    pruned_tokens = 0
    for index, message in enumerate(messages):
        if index >= protected_start:
            pruned.append(message)
            continue
        kept_parts: list[Part] = []
        for part in message.parts:
            if part.type is PartType.TOOL_OUTPUT:
                pruned_count += 1
                original_tokens = _estimate_payload_tokens(part.payload)
                pruned_part = _prune_tool_output_part(part)
                reduced_tokens = _estimate_payload_tokens(pruned_part.payload)
                pruned_tokens += max(original_tokens - reduced_tokens, 0)
                kept_parts.append(pruned_part)
                continue
            kept_parts.append(part)
        if kept_parts != list(message.parts):
            pruned.append(
                Message(
                    id=message.id,
                    role=message.role,
                    parts=kept_parts,
                    created_at=message.created_at,
                    metadata=dict(message.metadata),
                )
            )
            continue
        pruned.append(message)
    repaired = _ensure_tool_result_pairs(pruned)
    return repaired, pruned_count, pruned_tokens


def inject_compaction_message(
    messages: list[Message],
    *,
    snapshot_id: str,
    summary: str,
) -> Message:
    """Append a compaction-tagged SYSTEM message and return it.

    >>> from wormhole_core.schemas.messages import MessageRole
    >>> messages: list[Message] = []
    >>> compaction = inject_compaction_message(messages, snapshot_id="snap-1", summary="done")
    >>> compaction.role
    <MessageRole.SYSTEM: 'system'>
    >>> compaction.metadata["snapshot_id"]
    'snap-1'
    >>> compaction.metadata["compaction"]
    True
    >>> len(messages)
    1
    """
    summary_text = summary.strip()
    if not summary_text:
        # Some providers reject empty SYSTEM messages; keep a minimal marker text.
        summary_text = "Compaction checkpoint (prune-only)."
    compaction_message = Message(
        id=f"msg-compaction-{uuid4().hex[:8]}",
        role=MessageRole.SYSTEM,
        parts=[
            Part(
                id=f"part-{uuid4().hex[:8]}",
                type=PartType.TEXT,
                payload={"text": summary_text},
            )
        ],
        metadata={"compaction": True, "snapshot_id": snapshot_id},
    )
    messages.append(compaction_message)
    return compaction_message


def build_reconstructed_context(
    messages: Sequence[Message],
    *,
    protected_rounds: int,
) -> tuple[list[Message], int, int]:
    """Reconstruct context from the last compaction tag and prune tool outputs.

    >>> from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
    >>> msg1 = Message(id="m1", role=MessageRole.USER, parts=[Part(id="p1", type=PartType.TEXT, payload="hi")])
    >>> compaction = Message(
    ...     id="c1",
    ...     role=MessageRole.SYSTEM,
    ...     parts=[Part(id="p2", type=PartType.TEXT, payload="summary")],
    ...     metadata={"compaction": True, "snapshot_id": "snap-1"},
    ... )
    >>> msg2 = Message(
    ...     id="m2",
    ...     role=MessageRole.ASSISTANT,
    ...     parts=[
    ...         Part(id="p3", type=PartType.TOOL_OUTPUT, payload="abcd"),
    ...         Part(id="p4", type=PartType.TEXT, payload="ok"),
    ...     ],
    ... )
    >>> reconstructed, count, _ = build_reconstructed_context([msg1, compaction, msg2], protected_rounds=0)
    >>> [m.id for m in reconstructed]
    ['c1', 'm2']
    >>> count
    1
    """
    last_index = find_last_compaction_message(messages)
    if last_index is None:
        source = list(messages)
    else:
        source = list(messages[last_index:])
    return prune_messages(source, protected_rounds)


async def compact_session(
    *,
    session_id: str,
    messages: list[Message],
    compaction_store: CompactionStoreProtocol,
    summarization_strategy: SummarizationStrategy,
    config: CompactionConfig,
    context_limit: int,
    hooks: HookRegistry | None = None,
    event_stream: EventStream[CoreEvent] | None = None,
    correlation_id: str | None = None,
) -> CompactionResult:
    """Run two-stage compaction over a session's message history.

    >>> import asyncio
    >>> import tempfile
    >>> from pathlib import Path
    >>> from wormhole_core.compaction.strategies import NoOpSummarizationStrategy
    >>> from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
    >>> from wormhole_core.schemas.session import CompactionConfig, CompactionStage
    >>> from wormhole_core.storage.compaction_store import CompactionStore
    >>> store = CompactionStore(Path(tempfile.mkdtemp()))
    >>> messages = [
    ...     Message(id="m1", role=MessageRole.USER, parts=[Part(id="p1", type=PartType.TEXT, payload="hi")])
    ... ]
    >>> result = asyncio.run(
    ...     compact_session(
    ...         session_id="s1",
    ...         messages=messages,
    ...         compaction_store=store,
    ...         summarization_strategy=NoOpSummarizationStrategy(),
    ...         config=CompactionConfig(),
    ...         context_limit=100,
    ...     )
    ... )
    >>> result.stage
    <CompactionStage.COMPLETED: 'completed'>
    >>> result.summary_generated
    False
    """
    call_id = correlation_id or session_id
    log_parameter("compact_session", session_id=session_id, call_id=call_id)
    started = time.monotonic()
    snapshot_id = f"snap-{uuid4().hex[:8]}"
    compaction_message_id: str | None = None
    stage = CompactionStage.PRUNING
    error_message: str | None = None
    summary_generated = False

    if event_stream is not None:
        await event_stream.publish(
            CoreEvent(
                session_id=session_id,
                type=EventType.COMPACTION_STARTED,
                payload={"snapshot_id": snapshot_id, "correlation_id": call_id},
            )
        )

    if hooks is not None:
        await hooks.invoke(
            HookPoint.COMPACTION_TRIGGER,
            HookContext(
                session_id=session_id,
                hook_point=HookPoint.COMPACTION_TRIGGER,
                payload={"snapshot_id": snapshot_id, "correlation_id": call_id},
                timestamp=time.time(),
            ),
        )

    last_index = find_last_compaction_message(messages)
    context_source = messages[last_index:] if last_index is not None else messages
    pruned_context, pruned_count, pruned_tokens = prune_messages(
        context_source,
        protected_rounds=config.protected_rounds,
    )
    log_branch("compact_session", "stage_pruning", call_id=call_id)
    log_variable_change(
        "compact_session",
        "pruned_message_count",
        None,
        pruned_count,
        call_id=call_id,
    )
    log_variable_change(
        "compact_session",
        "pruned_token_estimate",
        None,
        pruned_tokens,
        call_id=call_id,
    )

    remaining_tokens = _estimate_token_count(pruned_context)
    context_ratio = remaining_tokens / context_limit if context_limit > 0 else 0.0
    log_variable_change(
        "compact_session",
        "remaining_token_estimate",
        None,
        remaining_tokens,
        call_id=call_id,
    )

    summary_text = ""
    should_summarize = pruned_count == 0 or (
        context_limit > 0 and context_ratio >= config.prune_target_ratio
    )
    if should_summarize:
        stage = CompactionStage.SUMMARIZING
        log_branch("compact_session", "stage_summarizing", call_id=call_id)
        context = CompactionContext(
            session_id=session_id,
            snapshot_id=snapshot_id,
            config=config,
            stage=stage,
            pruned_count=pruned_count,
            remaining_token_estimate=remaining_tokens,
        )
        summarize_source = (
            pruned_context[1:] if last_index is not None else pruned_context
        )
        summarize_messages = _prepare_summarization_messages(summarize_source)
        try:
            summary_text = await retry_async(
                lambda: summarization_strategy.summarize(summarize_messages, context),
                max_retries=3,
                initial_backoff_s=0.1,
            )
            summary_generated = True
        except Exception as exc:
            stage = CompactionStage.FAILED
            error_message = str(exc)
            log_branch("compact_session", "summarization_failed", call_id=call_id)

    if stage is CompactionStage.FAILED:
        snapshot = CompactionSnapshot(
            snapshot_id=snapshot_id,
            session_id=session_id,
            created_at=time.time(),
            kept_files=[],
            source_message_range=None,
            stage=stage,
            pruned_message_count=pruned_count,
            pruned_token_estimate=pruned_tokens,
            compaction_message_id=None,
        )
        await compaction_store.save(snapshot)
        if hooks is not None:
            await hooks.invoke(
                HookPoint.POST_COMPACTION,
                HookContext(
                    session_id=session_id,
                    hook_point=HookPoint.POST_COMPACTION,
                    payload={
                        "snapshot_id": snapshot_id,
                        "correlation_id": call_id,
                        "stage": stage.value,
                        "summary_length": 0,
                        "summary_generated": False,
                        "pruned_message_count": pruned_count,
                        "pruned_token_estimate": pruned_tokens,
                        "compaction_message_id": None,
                        "error_message": error_message,
                        "success": False,
                    },
                    timestamp=time.time(),
                ),
            )
        if event_stream is not None:
            await event_stream.publish(
                CoreEvent(
                    session_id=session_id,
                    type=EventType.COMPACTION_COMPLETED,
                    payload={
                        "snapshot_id": snapshot_id,
                        "correlation_id": call_id,
                        "stage": stage.value,
                        "success": False,
                    },
                )
            )
        raise CompactionError(
            ErrorCode.COMPACTION_SUMMARIZATION_ERROR,
            "compaction summarization failed",
            {
                "session_id": session_id,
                "snapshot_id": snapshot_id,
                "error": error_message,
            },
            retryable=True,
        )

    stage = CompactionStage.COMPLETED
    if not summary_text.strip():
        summary_text = _render_pruned_history(pruned_context)
        summary_generated = False
    compaction_message = inject_compaction_message(
        messages,
        snapshot_id=snapshot_id,
        summary=summary_text,
    )
    compaction_message_id = compaction_message.id
    log_variable_change(
        "compact_session",
        "compaction_message_id",
        None,
        compaction_message_id,
        call_id=call_id,
    )
    snapshot = CompactionSnapshot(
        snapshot_id=snapshot_id,
        session_id=session_id,
        created_at=time.time(),
        kept_files=[],
        source_message_range=None,
        stage=stage,
        pruned_message_count=pruned_count,
        pruned_token_estimate=pruned_tokens,
        compaction_message_id=compaction_message_id,
    )
    await compaction_store.save(snapshot)

    if hooks is not None:
        await hooks.invoke(
            HookPoint.POST_COMPACTION,
            HookContext(
                session_id=session_id,
                hook_point=HookPoint.POST_COMPACTION,
                payload={
                    "snapshot_id": snapshot_id,
                    "correlation_id": call_id,
                    "stage": stage.value,
                    "summary_length": len(summary_text),
                    "summary_generated": summary_generated,
                    "pruned_message_count": pruned_count,
                    "pruned_token_estimate": pruned_tokens,
                    "compaction_message_id": compaction_message_id,
                    "error_message": None,
                    "success": True,
                },
                timestamp=time.time(),
            ),
        )

    if event_stream is not None:
        await event_stream.publish(
            CoreEvent(
                session_id=session_id,
                type=EventType.COMPACTION_COMPLETED,
                payload={
                    "snapshot_id": snapshot_id,
                    "correlation_id": call_id,
                    "stage": stage.value,
                    "success": True,
                },
            )
        )

    log_timing(
        "compact_session",
        (time.monotonic() - started) * 1000,
        call_id=call_id,
    )
    return CompactionResult(
        session_id=session_id,
        snapshot_id=snapshot_id,
        stage=stage,
        pruned_message_count=pruned_count,
        pruned_token_estimate=pruned_tokens,
        summary_generated=summary_generated,
        error_message=None,
    )
