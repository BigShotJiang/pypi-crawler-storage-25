"""Session API for SDK-facing interactions."""

from __future__ import annotations

import asyncio
import inspect
import json
import time
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Callable, Sequence, cast
from uuid import uuid4

from loopgraph.bus.eventbus import Event, EventListener
from loopgraph.concurrency import SemaphorePolicy
from loopgraph.persistence import InMemorySnapshotStore, SnapshotStore

from ..config import ConfigSources, resolve_config
from ..errors import (
    EngineError,
    GraphCycleError,
    HandlerNotFoundError,
    HookError,
    NotFoundError,
    PermissionDeniedError,
    SchedulerError,
    WormholeError,
)
from ..events.stream import CoreEventStream, EventStream
from ..events.transform import transform_event
from ..events.types import CoreEvent, EventType
from ..graph.builder import SessionGraphBuilder
from ..graph.function_registry import SessionFunctionRegistry
from ..graph.runtime import SessionGraphRuntime
from ..hooks.registry import HookRegistry
from ..hooks.types import HookContext, HookPoint, HookResult
from ..logging import log_branch, log_loop_iteration, log_parameter, log_variable_change
from ..retry import RetryPolicy
from ..schemas.messages import Message, MessageRole, Part, PartType
from ..schemas.session import (
    ExecutionStateSnapshot,
    Session,
    SessionConfig,
    SessionStatus,
)
from ..schemas.tools import ToolCall, ToolCallStatus, ToolDefinition
from ..storage.execution_state_store import ExecutionStateStore, LoopgraphSnapshotStore
from ..storage.protocols import EventLogStoreProtocol, ExecutionStateStoreProtocol
from ..tools.permissions import is_tool_allowed
from ..tools.registry import ToolRegistry
from .compaction import _estimate_token_count, build_reconstructed_context


def _build_tool_result_message(tool_call_results: Sequence[ToolCall]) -> Message:
    """Convert tool call results to a user message with tool output parts.

    This follows the pattern used by other agent frameworks where tool results
    are appended to the conversation history as user messages containing
    tool_output parts. This enables:
    - Model to see tool outputs in context
    - Consistent conversation history
    - Background results to be naturally integrated when they complete

    >>> from wormhole_core.schemas.tools import ToolCall, ToolCallStatus
    >>> results = [
    ...     ToolCall(
    ...         tool_call_id="tc1",
    ...         tool_id="bash",
    ...         status=ToolCallStatus.COMPLETED,
    ...         result={"output": "hello world"},
    ...     )
    ... ]
    >>> msg = _build_tool_result_message(results)
    >>> msg.role
    <MessageRole.USER: 'user'>
    >>> len(msg.parts)
    1
    >>> msg.parts[0].type
    <PartType.TOOL_OUTPUT: 'tool_output'>
    """
    parts: list[Part] = []
    for call in tool_call_results:
        part = Part(
            id=f"part-{call.tool_call_id}",
            type=PartType.TOOL_OUTPUT,
            payload={
                "tool_call_id": call.tool_call_id,
                "tool_id": call.tool_id,
                "output": call.result,
                "status": call.status.value
                if hasattr(call.status, "value")
                else str(call.status),
                "error": call.error,
            },
        )
        parts.append(part)

    return Message(
        id=f"msg-tool-results-{uuid4().hex[:8]}",
        role=MessageRole.USER,
        parts=parts,
    )


def _dispatch_tools(payload: object) -> str:
    if isinstance(payload, dict):
        tool_ids = payload.get("tool_ids") or []
        if tool_ids:
            return str(tool_ids[0])
    return "done"


def _build_user_text_message(text: str) -> Message:
    return Message(
        id=f"msg-user-{uuid4().hex[:8]}",
        role=MessageRole.USER,
        parts=[Part(id=f"part-{uuid4().hex[:8]}", type=PartType.TEXT, payload=text)],
    )


def _build_assistant_message(
    text: str | None, tool_calls: Sequence[dict[str, Any]]
) -> Message | None:
    """Build an assistant message from model text and tool calls.

    >>> msg = _build_assistant_message("hi", [])
    >>> msg is not None and msg.role is MessageRole.ASSISTANT
    True
    >>> len(msg.parts)  # type: ignore[union-attr]
    1
    """
    parts: list[Part] = []
    if text:
        parts.append(
            Part(
                id=f"part-{uuid4().hex[:8]}",
                type=PartType.TEXT,
                payload={"text": text},
            )
        )
    for call in tool_calls:
        if not isinstance(call, dict):
            continue
        parts.append(
            Part(
                id=f"part-tc-{call.get('tool_call_id') or uuid4().hex[:8]}",
                type=PartType.TOOL_CALL,
                payload={
                    "tool_call_id": str(call.get("tool_call_id") or ""),
                    "tool_name": str(call.get("tool_name") or ""),
                    "arguments": dict(call.get("arguments") or {}),
                },
            )
        )
    if not parts:
        return None
    return Message(
        id=f"msg-assistant-{uuid4().hex[:8]}",
        role=MessageRole.ASSISTANT,
        parts=parts,
    )


def _register_core_handlers(
    registry: SessionFunctionRegistry, model_adapter: Any | None
) -> None:
    state: dict[str, Any] = {
        "reentry_payload": None,
        "done_payload": None,
    }

    def _coerce_dict(value: object) -> dict[str, Any]:
        if isinstance(value, dict):
            return dict(value)
        return {}

    def _event_type_name(event: object) -> str:
        event_type = getattr(event, "type", None)
        return str(getattr(event_type, "value", event_type)).lower()

    def _event_payload(event: object) -> dict[str, Any]:
        payload = getattr(event, "payload", None)
        if isinstance(payload, dict):
            return dict(payload)
        return {}

    def _adapter_stream_source(adapter: Any, payload: dict[str, Any]) -> Any:
        messages = payload.get("messages", [])
        tools = payload.get("tools")
        system_prompt = payload.get("system_prompt")
        max_tokens = payload.get("max_tokens")
        try:
            return adapter.stream(
                messages,
                tools=tools,
                system_prompt=system_prompt,
                max_tokens=max_tokens,
            )
        except TypeError:
            try:
                return adapter.stream(
                    messages, tools=tools, system_prompt=system_prompt
                )
            except TypeError:
                return adapter.stream(payload)

    def _normalize_tool_call(call: object) -> dict[str, Any]:
        if isinstance(call, ToolCall):
            return {
                "tool_call_id": call.tool_call_id,
                "tool_name": call.tool_id,
                "arguments": dict(call.arguments),
                "decision": "approved",
                "reason": None,
            }
        if not isinstance(call, dict):
            return {}
        return {
            "tool_call_id": str(
                call.get("tool_call_id") or call.get("id") or uuid4().hex[:8]
            ),
            "tool_name": str(
                call.get("tool_name") or call.get("tool_id") or call.get("name") or ""
            ),
            "arguments": dict(call.get("arguments") or {}),
            "decision": str(call.get("decision", "approved")),
            "reason": call.get("reason"),
        }

    def _resolve_root_dir(value: object) -> Path:
        """Return a resolved Path from a string, Path, or fall back to cwd.

        Example::

            >>> _resolve_root_dir(Path("/tmp")).is_absolute()
            True
            >>> _resolve_root_dir("/tmp").is_absolute()
            True
            >>> isinstance(_resolve_root_dir(None), Path)
            True
        """
        if isinstance(value, Path):
            return value.expanduser().resolve()
        if isinstance(value, str) and value.strip():
            return Path(value).expanduser().resolve()
        return Path.cwd().resolve()

    def _normalize_path_arg(value: object, *, root_dir: Path) -> str | None:
        """Resolve a path string against *root_dir*, returning an absolute path.

        Returns ``None`` for non-string or blank inputs.

        Example::

            >>> _normalize_path_arg("hello.py", root_dir=Path("/project"))
            '/project/hello.py'
            >>> _normalize_path_arg("/abs/path.py", root_dir=Path("/project"))
            '/abs/path.py'
            >>> _normalize_path_arg(None, root_dir=Path("/project")) is None
            True
            >>> _normalize_path_arg("", root_dir=Path("/project")) is None
            True
        """
        if not isinstance(value, str):
            return None
        stripped = value.strip()
        if not stripped:
            return None
        path = Path(stripped).expanduser()
        if not path.is_absolute():
            path = root_dir / path
        return str(path.resolve())

    def _normalize_tool_arguments_for_hooks(
        tool_name: str,
        arguments: dict[str, Any],
        *,
        root_dir: Path,
    ) -> dict[str, Any]:
        """Resolve path-like arguments so hooks see absolute paths.

        For file tools, resolves ``file_path``. For bash, resolves
        ``working_directory`` (defaults to *root_dir* when absent).

        Example::

            >>> _normalize_tool_arguments_for_hooks(
            ...     "file_read", {"file_path": "src/main.py"},
            ...     root_dir=Path("/project"),
            ... )
            {'file_path': '/project/src/main.py'}
            >>> result = _normalize_tool_arguments_for_hooks(
            ...     "bash", {"command": "ls"},
            ...     root_dir=Path("/project"),
            ... )
            >>> result["working_directory"]
            '/project'
            >>> _normalize_tool_arguments_for_hooks(
            ...     "unknown_tool", {"x": 1},
            ...     root_dir=Path("/project"),
            ... )
            {'x': 1}
        """
        normalized = dict(arguments)
        if tool_name in {"file_read", "file_edit", "file_write"}:
            normalized_path = _normalize_path_arg(
                normalized.get("file_path"), root_dir=root_dir
            )
            if normalized_path is not None:
                normalized["file_path"] = normalized_path
            return normalized

        if tool_name == "bash":
            normalized_wd = _normalize_path_arg(
                normalized.get("working_directory"), root_dir=root_dir
            )
            normalized["working_directory"] = normalized_wd or str(root_dir)
            return normalized

        return normalized

    def _merge_tool_call_deltas(
        tool_calls: list[dict[str, Any]],
        argument_deltas: dict[str, str],
    ) -> list[dict[str, Any]]:
        """Merge streamed tool_call_delta JSON back into tool call arguments.

        Example::

            >>> calls = [{"tool_call_id": "tc1", "arguments": {}}]
            >>> _merge_tool_call_deltas(calls, {"tc1": '{"text":"hi"}'})
            [{'tool_call_id': 'tc1', 'arguments': {'text': 'hi'}}]
            >>> _merge_tool_call_deltas(calls, {})
            [{'tool_call_id': 'tc1', 'arguments': {}}]
            >>> _merge_tool_call_deltas(calls, {"tc1": "not-json{"})
            [{'tool_call_id': 'tc1', 'arguments': {}}]
        """
        if not argument_deltas:
            return tool_calls
        merged: list[dict[str, Any]] = []
        for raw_call in tool_calls:
            call = dict(raw_call)
            call_id = str(call.get("tool_call_id") or "")
            delta = argument_deltas.get(call_id)
            if not delta:
                merged.append(call)
                continue
            try:
                parsed = json.loads(delta)
            except json.JSONDecodeError:
                merged.append(call)
                continue
            if isinstance(parsed, dict):
                call["arguments"] = parsed
            merged.append(call)
        return merged

    def _to_tool_status(value: str) -> ToolCallStatus:
        lowered = value.lower()
        if lowered == "completed":
            return ToolCallStatus.COMPLETED
        if lowered == "failed":
            return ToolCallStatus.FAILED
        if lowered == "skipped":
            return ToolCallStatus.SKIPPED
        return ToolCallStatus.PENDING

    def _coerce_max_steps(raw_value: object, default: int = 25) -> int:
        try:
            value = int(cast(Any, raw_value))
        except (TypeError, ValueError):
            return default
        if value < 1:
            return default
        return int(value)

    async def _emit_stream_event(
        working: dict[str, Any],
        event_type: str,
        payload: dict[str, Any],
        *,
        raw_event: object | None = None,
    ) -> None:
        stream_queue = working.get("stream_queue")
        if stream_queue is None:
            # Backward-compatible fallback during transition.
            stream_queue = working.get("model_event_queue")
        if stream_queue is None or not hasattr(stream_queue, "put"):
            return
        if raw_event is not None:
            await stream_queue.put(raw_event)
            return
        await stream_queue.put({"type": event_type, "payload": dict(payload)})

    registry.register(
        "input_processor",
        lambda payload: payload if isinstance(payload, dict) else {"input": payload},
    )

    async def _prompt_transform_handler(payload: object) -> dict[str, Any]:
        log_parameter("SessionManager.prompt_transform_handler")
        if isinstance(state.get("reentry_payload"), dict):
            working = dict(state["reentry_payload"])
        elif isinstance(payload, dict):
            working = dict(payload)
        else:
            working = {"route": str(payload)}

        session_id = str(working.get("session_id", "unknown"))
        prompt_modified = False
        prompt_hooks_applied: list[str] = []

        hook_registry = working.get("hook_registry")
        if isinstance(hook_registry, HookRegistry):
            context = HookContext(
                session_id=session_id,
                hook_point=HookPoint.PROMPT_TRANSFORM,
                payload=dict(working),
                timestamp=time.time(),
            )
            results = await hook_registry.invoke(HookPoint.PROMPT_TRANSFORM, context)
            for result in results:
                if result.modified_payload:
                    working.update(result.modified_payload)
                    prompt_modified = True
                if result.reason:
                    prompt_hooks_applied.append(str(result.reason))
                if not result.proceed:
                    break

        session_hooks = working.get("session_hooks")
        if session_hooks is not None and hasattr(
            session_hooks, "run_transform_system_prompt"
        ):
            layers = []
            system_prompt = working.get("system_prompt")
            if system_prompt:
                layers.append(str(system_prompt))
            transformed = session_hooks.run_transform_system_prompt(
                layers, {"session_id": session_id}
            )
            if inspect.isawaitable(transformed):
                transformed = await transformed
            if isinstance(transformed, list):
                updated_prompt = "\n".join(
                    str(layer) for layer in transformed if layer is not None
                ).strip()
                if updated_prompt != str(system_prompt or ""):
                    prompt_modified = True
                working["system_prompt"] = updated_prompt or None

        working["prompt_modified"] = prompt_modified
        working["prompt_hooks_applied"] = prompt_hooks_applied
        working["visit_count"] = int(working.get("visit_count", 0)) + 1
        return working

    async def _model_handler(payload: object) -> dict[str, Any]:
        log_parameter("SessionManager.model_adapter_handler")
        working = _coerce_dict(payload)
        adapter = working.get("model_adapter") or model_adapter
        if adapter is None:
            return {
                **working,
                "text": None,
                "tool_calls": [],
                "finish_reason": "error",
                "usage": {},
                "error": {
                    "code": "no_model_adapter",
                    "message": "model adapter is not configured",
                    "session_id": working.get("session_id"),
                },
            }

        source = _adapter_stream_source(adapter, working)
        if hasattr(source, "__aiter__"):
            text_chunks: list[str] = []
            tool_calls: list[dict[str, Any]] = []
            tool_call_argument_deltas: dict[str, str] = {}
            finish_reason: str | None = None
            usage: dict[str, Any] = {}
            model_error: dict[str, Any] | None = None
            try:
                async for event in source:
                    name = _event_type_name(event)
                    event_payload = _event_payload(event)
                    await _emit_stream_event(
                        working, name, event_payload, raw_event=event
                    )
                    if name == "text_delta":
                        text_chunks.append(str(event_payload.get("text", "")))
                    elif name == "tool_call":
                        tool_calls.append(
                            {
                                "tool_call_id": str(
                                    event_payload.get("tool_call_id")
                                    or event_payload.get("id")
                                    or uuid4().hex[:8]
                                ),
                                "tool_name": str(
                                    event_payload.get("tool_name")
                                    or event_payload.get("tool_id")
                                    or event_payload.get("name")
                                    or ""
                                ),
                                "arguments": dict(event_payload.get("arguments") or {}),
                            }
                        )
                    elif name == "tool_call_delta":
                        tool_call_id = str(event_payload.get("tool_call_id") or "")
                        arguments_delta = event_payload.get("arguments_delta")
                        if (
                            tool_call_id
                            and isinstance(arguments_delta, str)
                            and arguments_delta
                        ):
                            tool_call_argument_deltas[tool_call_id] = (
                                tool_call_argument_deltas.get(tool_call_id, "")
                                + arguments_delta
                            )
                    elif name == "stop":
                        finish_reason = str(
                            event_payload.get("finish_reason", "end_turn")
                        )
                    elif name == "usage":
                        usage.update(event_payload)
                    elif name == "error":
                        model_error = {
                            "code": str(
                                event_payload.get("code") or "model_adapter_error"
                            ),
                            "message": str(
                                event_payload.get("message")
                                or "model adapter returned an error event"
                            ),
                            "retryable": bool(event_payload.get("retryable", False)),
                            "session_id": working.get("session_id"),
                        }
                        finish_reason = "model_error"
            except Exception as exc:
                model_error = {
                    "code": "model_adapter_error",
                    "message": str(exc),
                    "retryable": False,
                    "session_id": working.get("session_id"),
                }
                finish_reason = "model_error"
                await _emit_stream_event(
                    working,
                    "error",
                    {
                        "code": "model_adapter_error",
                        "message": str(exc),
                        "retryable": False,
                    },
                )
            tool_calls = _merge_tool_call_deltas(tool_calls, tool_call_argument_deltas)
            messages = list(working.get("messages") or [])
            assistant_message = _build_assistant_message(
                "".join(text_chunks) or None, tool_calls
            )
            if assistant_message is not None:
                messages.append(assistant_message)
            return {
                **working,
                "messages": messages,
                "text": "".join(text_chunks) or None,
                "tool_calls": tool_calls,
                "finish_reason": finish_reason or "end_turn",
                "usage": usage,
                "error": model_error,
            }

        if inspect.isawaitable(source):
            source = await source
        if isinstance(source, dict):
            merged = {**working, **source}
            if merged.get("error") and not merged.get("finish_reason"):
                merged["finish_reason"] = "model_error"
            messages = list(merged.get("messages") or [])
            assistant_message = _build_assistant_message(
                merged.get("text") if isinstance(merged.get("text"), str) else None,
                list(merged.get("tool_calls") or []),
            )
            if assistant_message is not None:
                messages.append(assistant_message)
            merged["messages"] = messages
            return merged
        return {
            **working,
            "text": None,
            "tool_calls": [],
            "finish_reason": "end_turn",
            "usage": {},
            "error": None,
        }

    async def _tool_gate_handler(payload: object) -> dict[str, Any]:
        log_parameter("SessionManager.tool_gate_handler")
        working = _coerce_dict(payload)
        root_dir = _resolve_root_dir(working.get("root_dir"))
        raw_tool_calls = working.get("tool_calls") or []
        gated_calls: list[dict[str, Any]] = []
        tool_registry = working.get("tool_registry")
        session_config = working.get("session_config")
        session_hooks = working.get("session_hooks")
        allowlist_override = working.get("allowlist")
        effective_allowlist: set[str] | None = None
        if isinstance(allowlist_override, list):
            normalized_allowlist = {
                str(item).strip() for item in allowlist_override if str(item).strip()
            }
            if normalized_allowlist:
                effective_allowlist = normalized_allowlist

        for index, raw_call in enumerate(raw_tool_calls, start=1):
            log_loop_iteration("SessionManager.tool_gate_handler", "tool_calls", index)
            normalized = _normalize_tool_call(raw_call)
            if not normalized:
                continue
            normalized["arguments"] = _normalize_tool_arguments_for_hooks(
                normalized["tool_name"],
                dict(normalized.get("arguments") or {}),
                root_dir=root_dir,
            )
            decision = "approved"
            reason: str | None = None
            tool_name = normalized["tool_name"]

            if isinstance(tool_registry, ToolRegistry) and tool_name:
                try:
                    tool = tool_registry.get(tool_name)
                except NotFoundError:
                    decision = "denied"
                    reason = "tool_not_found"
                else:
                    if effective_allowlist is not None:
                        if (
                            tool.tool_id not in effective_allowlist
                            and tool.name not in effective_allowlist
                        ):
                            raise PermissionDeniedError(
                                "tool not allowlisted",
                                {"tool_id": tool.tool_id, "tool_name": tool.name},
                            )
                    elif (
                        isinstance(session_config, SessionConfig)
                        and bool(session_config.allowlisted_tools)
                        and not is_tool_allowed(tool, session_config)
                    ):
                        decision = "denied"
                        reason = "tool_not_allowlisted"

            if (
                decision == "approved"
                and session_hooks is not None
                and hasattr(session_hooks, "run_before_tool_execute")
                and tool_name
                and isinstance(tool_registry, ToolRegistry)
            ):
                try:
                    tool = tool_registry.get(tool_name)
                    call_obj = ToolCall(
                        tool_call_id=normalized["tool_call_id"],
                        tool_id=tool_name,
                        arguments=normalized["arguments"],
                    )
                    prepared = session_hooks.run_before_tool_execute(call_obj, tool)
                    if inspect.isawaitable(prepared):
                        prepared = await prepared
                    if prepared is None:
                        decision = "skipped"
                        reason = "skipped_by_hook"
                    elif isinstance(prepared, ToolCall):
                        if prepared.status is ToolCallStatus.SKIPPED:
                            decision = "skipped"
                            reason = str(prepared.error or "skipped_by_hook")
                            normalized["hook_result"] = prepared.result
                        else:
                            normalized["arguments"] = dict(prepared.arguments)
                except Exception as exc:
                    decision = "skipped"
                    reason = str(exc)

            gated_calls.append(
                {
                    **normalized,
                    "decision": decision,
                    "reason": reason,
                }
            )

        return {**working, "tool_calls": gated_calls}

    async def _tool_executor_handler(payload: object) -> dict[str, Any]:
        log_parameter("SessionManager.tool_executor_handler")
        working = _coerce_dict(payload)
        calls = list(working.get("tool_calls") or [])
        session_hooks = working.get("session_hooks")
        stream = working.get("core_event_stream")
        session_id = str(working.get("session_id", "unknown"))
        sdk_tool_handlers = (
            working.get("tool_handlers")
            if isinstance(working.get("tool_handlers"), dict)
            else {}
        )
        results: list[dict[str, Any]] = []

        for index, call in enumerate(calls, start=1):
            log_loop_iteration(
                "SessionManager.tool_executor_handler", "tool_calls", index
            )
            raw_call = call if isinstance(call, dict) else {}
            normalized = _normalize_tool_call(call)
            if not normalized:
                continue
            decision = str(
                raw_call.get("decision", normalized.get("decision", "approved"))
            )
            reason = raw_call.get("reason")
            tool_name = normalized["tool_name"]
            tool_call_id = normalized["tool_call_id"]
            arguments = dict(normalized["arguments"])

            if decision != "approved":
                result_item = {
                    "tool_call_id": tool_call_id,
                    "tool_name": tool_name,
                    "status": "skipped",
                    "result": raw_call.get("hook_result"),
                    "error": reason,
                }
                results.append(result_item)
                await _emit_stream_event(
                    working,
                    "tool_result",
                    {
                        "tool_call_id": tool_call_id,
                        "tool_name": tool_name,
                        "arguments": arguments,
                        "result": raw_call.get("hook_result"),
                        "status": "skipped",
                        "error": reason,
                    },
                )
                continue

            if isinstance(stream, CoreEventStream):
                await stream.publish(
                    CoreEvent(
                        session_id=session_id,
                        type=EventType.TOOL_CALL_CREATED,
                        payload={
                            "tool_call_id": tool_call_id,
                            "tool_name": tool_name,
                            "arguments": arguments,
                        },
                    )
                )

            handler_name = f"tool:{tool_name}"
            handler: Callable[[dict[str, Any]], Any] | None = None
            if isinstance(sdk_tool_handlers, dict):
                candidate = sdk_tool_handlers.get(tool_name)
                if callable(candidate):
                    handler = candidate
            if handler is None:
                try:
                    handler = registry.get(handler_name)
                except KeyError:
                    handler = None
            if handler is None:
                result_item = {
                    "tool_call_id": tool_call_id,
                    "tool_name": tool_name,
                    "status": "failed",
                    "result": None,
                    "error": "tool handler not registered",
                }
                results.append(result_item)
                await _emit_stream_event(
                    working,
                    "tool_result",
                    {
                        "tool_call_id": tool_call_id,
                        "tool_name": tool_name,
                        "arguments": arguments,
                        "result": None,
                        "status": "failed",
                        "error": "tool handler not registered",
                    },
                )
                continue

            try:
                execution_result = handler(arguments)
                if inspect.isawaitable(execution_result):
                    execution_result = await execution_result
                if session_hooks is not None and hasattr(
                    session_hooks, "run_after_tool_execute"
                ):
                    hook_result = session_hooks.run_after_tool_execute(
                        ToolCall(
                            tool_call_id=tool_call_id,
                            tool_id=tool_name,
                            arguments=arguments,
                        ),
                        execution_result,
                        None,
                    )
                    if inspect.isawaitable(hook_result):
                        execution_result = await hook_result
                    else:
                        execution_result = hook_result
                result_item = {
                    "tool_call_id": tool_call_id,
                    "tool_name": tool_name,
                    "status": "completed",
                    "result": execution_result,
                    "error": None,
                }
            except Exception as exc:
                hook_output: Any = None
                if session_hooks is not None and hasattr(
                    session_hooks, "run_after_tool_execute"
                ):
                    hook_output = session_hooks.run_after_tool_execute(
                        ToolCall(
                            tool_call_id=tool_call_id,
                            tool_id=tool_name,
                            arguments=arguments,
                        ),
                        None,
                        exc,
                    )
                    if inspect.isawaitable(hook_output):
                        hook_output = await hook_output
                result_item = {
                    "tool_call_id": tool_call_id,
                    "tool_name": tool_name,
                    "status": "failed",
                    "result": hook_output,
                    "error": str(exc),
                }

            results.append(result_item)
            if isinstance(stream, CoreEventStream):
                await stream.publish(
                    CoreEvent(
                        session_id=session_id,
                        type=EventType.TOOL_CALL_COMPLETED,
                        payload=result_item,
                    )
                )
            await _emit_stream_event(
                working,
                "tool_result",
                {
                    "tool_call_id": tool_call_id,
                    "tool_name": tool_name,
                    "arguments": arguments,
                    "result": result_item.get("result"),
                    "status": result_item.get("status", "completed"),
                    "error": result_item.get("error"),
                },
            )

        messages = list(working.get("messages") or [])
        tool_result_calls: list[ToolCall] = []
        for item in results:
            tool_result_calls.append(
                ToolCall(
                    tool_call_id=str(item["tool_call_id"]),
                    tool_id=str(item["tool_name"]),
                    status=_to_tool_status(str(item.get("status", "pending"))),
                    result=item.get("result"),
                    error=item.get("error"),
                )
            )
        if tool_result_calls:
            messages.append(_build_tool_result_message(tool_result_calls))

        return {
            **working,
            "messages": messages,
            "tool_results": results,
        }

    async def _compaction_check_handler(payload: object) -> dict[str, Any]:
        log_parameter("SessionManager.compaction_check_handler")
        working = _coerce_dict(payload)
        messages = working.get("messages") or []
        token_count = _estimate_token_count(
            messages if isinstance(messages, list) else []
        )
        threshold = float(working.get("compaction_threshold", 0.9))
        compaction = {
            "triggered": False,
            "token_count": token_count,
            "threshold": threshold,
        }
        return {
            **working,
            "step_result": dict(working),
            "compaction": compaction,
        }

    async def _continuation_check_handler(payload: object) -> str:
        log_parameter("SessionManager.continuation_check_handler")
        working = _coerce_dict(payload)
        loop_context = working.get("loop_context")
        if not isinstance(loop_context, dict):
            loop_context = {}
            working["loop_context"] = loop_context

        step_index = int(working.get("step_index", 0)) + 1
        max_steps = _coerce_max_steps(working.get("max_consecutive_steps", 25))
        main_loop_unbounded = bool(working.get("main_loop_unbounded", False))
        session_type = str(working.get("session_type", "")).strip().lower()
        is_sub_agent = bool(
            working.get("is_sub_agent", working.get("is_subagent", False))
        ) or session_type in {"sub_agent", "subagent", "child"}
        bounded_session = is_sub_agent or not main_loop_unbounded

        staged_messages: list[str] = []
        staged_queue = loop_context.get("staged_queue")
        if staged_queue is not None and hasattr(staged_queue, "qsize"):
            snapshot_size = int(staged_queue.qsize())
            for _ in range(snapshot_size):
                try:
                    staged_messages.append(str(staged_queue.get_nowait()))
                except asyncio.QueueEmpty:
                    break

        messages = list(working.get("messages") or [])
        for message_text in staged_messages:
            messages.append(_build_user_text_message(message_text))

        decision = "done"
        reason = "end_turn"
        finish_reason = str(working.get("finish_reason", "")).lower()
        continuation_mode = str(working.get("continuation_mode", "automatic")).lower()
        has_model_error = isinstance(working.get("error"), dict)
        approved_tool_calls = [
            call
            for call in (working.get("tool_calls") or [])
            if isinstance(call, dict)
            and str(call.get("decision", "approved")) == "approved"
        ]

        if bounded_session and step_index >= max_steps:
            decision = "done"
            reason = "max_steps_reached"
        elif has_model_error:
            decision = "done"
            reason = "model_error"
        elif staged_messages:
            decision = "continue"
            reason = "staged_messages"
        elif continuation_mode in {"force_stop", "manual"}:
            decision = "done"
            reason = "manual_mode"
        elif continuation_mode == "force_continue":
            decision = "continue"
            reason = "force_continue"
        elif approved_tool_calls:
            decision = "continue"
            reason = "pending_tool_calls"
        elif finish_reason in {"tool_use", "max_tokens"}:
            decision = "continue"
            reason = finish_reason
        elif finish_reason:
            decision = "done"
            reason = finish_reason

        next_payload = {
            **working,
            "messages": messages,
            "staged_messages": staged_messages,
            "staged_messages_drained_count": len(staged_messages),
            "decision": decision,
            "reason": reason,
            "step_index": step_index,
        }
        loop_context["last_continuation_payload"] = {
            "decision": decision,
            "reason": reason,
            "staged_messages_drained_count": len(staged_messages),
            "step_index": step_index,
        }
        state["reentry_payload"] = next_payload
        state["done_payload"] = {
            **next_payload,
            "staged_messages_remaining": staged_queue.qsize()
            if staged_queue is not None and hasattr(staged_queue, "qsize")
            else 0,
        }
        return decision

    def _output_handler(payload: object) -> dict[str, Any]:
        log_parameter("SessionManager.output_handler")
        if isinstance(payload, dict):
            maybe_loop_context = payload.get("loop_context")
            if isinstance(maybe_loop_context, dict):
                maybe_loop_context.pop("last_continuation_payload", None)
        done_payload = state.get("done_payload")
        if isinstance(payload, dict):
            result = {
                "outcome": payload.get("reason", payload.get("outcome", "done")),
                "iteration_count": int(payload.get("step_index", 0)),
                "error_details": payload.get("error"),
                "messages": payload.get("messages", []),
            }
            state["reentry_payload"] = None
            state["done_payload"] = None
            return result
        if isinstance(done_payload, dict):
            result = {
                "outcome": done_payload.get("reason", str(payload)),
                "iteration_count": int(done_payload.get("step_index", 0)),
                "error_details": done_payload.get("error"),
                "messages": done_payload.get("messages", []),
            }
            state["reentry_payload"] = None
            state["done_payload"] = None
            return result
        state["reentry_payload"] = None
        state["done_payload"] = None
        return {
            "outcome": str(payload),
            "iteration_count": 0,
            "error_details": None,
            "messages": [],
        }

    registry.register("prompt_transform", _prompt_transform_handler)
    registry.register("model_adapter", _model_handler)
    registry.register("tool_gate", _tool_gate_handler)
    registry.register("tool_executor", _tool_executor_handler)
    registry.register("compaction_check", _compaction_check_handler)
    registry.register("continuation_check", _continuation_check_handler)
    registry.register("output_handler", _output_handler)


def _ensure_tool_handlers(
    registry: SessionFunctionRegistry, tool_ids: Sequence[str]
) -> None:
    for index, tool_id in enumerate(tool_ids, start=1):
        log_loop_iteration("_ensure_tool_handlers", "tool_ids", index)
        handler_name = f"tool:{tool_id}"
        try:
            registry.get(handler_name)
        except KeyError:

            def _make_handler(tid: str) -> Callable[[Any], dict[str, Any]]:
                return lambda payload: {"tool_id": tid, "payload": payload}

            registry.register(handler_name, _make_handler(tool_id))


def _emit_hook_failed(runtime: "SessionRuntime", error: HookError) -> None:
    asyncio.create_task(
        runtime.stream.publish(
            CoreEvent(
                session_id=runtime.session.session_id,
                type=EventType.HOOK_FAILED,
                payload=error.to_dict(),
                error_code=error.code.value,
            )
        )
    )


def _apply_hook_results(
    payload: dict[str, Any], results: Sequence[HookResult]
) -> dict[str, Any]:
    updated = dict(payload)
    for result in results:
        if result.modified_payload:
            updated.update(result.modified_payload)
        if not result.proceed:
            break
    return updated


async def _invoke_prompt_transform(
    runtime: "SessionRuntime", payload: dict[str, Any]
) -> dict[str, Any]:
    context = HookContext(
        session_id=runtime.session.session_id,
        hook_point=HookPoint.PROMPT_TRANSFORM,
        payload=dict(payload),
        timestamp=time.time(),
    )
    results = await runtime.hooks.invoke(
        HookPoint.PROMPT_TRANSFORM,
        context,
        error_handler=lambda error: _emit_hook_failed(runtime, error),
    )
    return _apply_hook_results(payload, results)


async def _emit_telemetry(runtime: "SessionRuntime", event: CoreEvent) -> None:
    context = HookContext(
        session_id=runtime.session.session_id,
        hook_point=HookPoint.TELEMETRY,
        payload={"event_type": event.type.value, "event_payload": event.payload},
        timestamp=time.time(),
    )
    await runtime.hooks.invoke(
        HookPoint.TELEMETRY,
        context,
        error_handler=lambda error: _emit_hook_failed(runtime, error),
    )


async def _invoke_compaction_trigger(
    runtime: "SessionRuntime", message_count: int
) -> None:
    context = HookContext(
        session_id=runtime.session.session_id,
        hook_point=HookPoint.COMPACTION_TRIGGER,
        payload={"token_count": 0, "message_count": message_count, "high_watermark": 0},
        timestamp=time.time(),
    )
    await runtime.hooks.invoke(
        HookPoint.COMPACTION_TRIGGER,
        context,
        error_handler=lambda error: _emit_hook_failed(runtime, error),
    )


@dataclass
class SessionHandle:
    session: Session
    stream: CoreEventStream


@dataclass
class SessionStep:
    session: Session
    events: list[CoreEvent]


@dataclass
class SessionRuntime:
    session: Session
    config: SessionConfig
    stream: CoreEventStream
    graph_builder: SessionGraphBuilder
    graph_runtime: SessionGraphRuntime
    registry: SessionFunctionRegistry
    event_listener: EventListener | None
    initial_messages: Sequence[Message]
    hooks: HookRegistry
    messages: list[Message]  # Mutable message history including tool results
    loop_context: dict[str, Any]


class SessionManager:
    """Manage sessions for SDK consumption.

    >>> import asyncio
    >>> class DemoAdapter:
    ...     async def stream(self, payload: dict[str, Any]) -> dict[str, Any]:
    ...         return payload
    >>> async def demo() -> SessionStatus:
    ...     manager = SessionManager(model_adapter=DemoAdapter())
    ...     handle = await manager.start_session(SessionConfig())
    ...     await manager.step_session(handle.session.session_id, input="hello")
    ...     session = await manager.stop_session(handle.session.session_id)
    ...     return session.status
    >>> asyncio.run(demo())
    <SessionStatus.COMPLETED: 'completed'>
    """

    def __init__(
        self,
        tool_registry: ToolRegistry | None = None,
        execution_state_store: ExecutionStateStoreProtocol | None = None,
        event_log_store: EventLogStoreProtocol | None = None,
        model_adapter: Any | None = None,
        hook_registry: HookRegistry | None = None,
    ) -> None:
        self._sessions: dict[str, SessionRuntime] = {}
        self._tool_registry = tool_registry or ToolRegistry()
        self._execution_state_store = execution_state_store
        self._event_log_store = event_log_store
        self._model_adapter = model_adapter
        self._hook_registry = hook_registry or HookRegistry()

    async def start_session(
        self,
        config: SessionConfig | None = None,
        config_sources: ConfigSources | None = None,
        initial_messages: Sequence[Message] | None = None,
    ) -> SessionHandle:
        session_id = str(uuid4())
        log_parameter(
            "SessionManager.start_session",
            config=config,
            config_sources=config_sources,
            call_id=session_id,
        )
        resolved_config = self._resolve_session_config(config, config_sources)
        now = time.time()
        expires = now + (resolved_config.retention_days * 86400)
        event_log_id = session_id if self._event_log_store is not None else None
        log_branch(
            "SessionManager.start_session",
            "event_log_enabled"
            if self._event_log_store is not None
            else "event_log_disabled",
            call_id=session_id,
        )
        session = Session(
            session_id=session_id,
            status=SessionStatus.RUNNING,
            created_at=now,
            updated_at=now,
            retention_expires_at=expires,
            event_log_id=event_log_id,
        )
        stream: CoreEventStream = CoreEventStream(
            backpressure=resolved_config.backpressure
        )
        registry = SessionFunctionRegistry()
        _register_core_handlers(registry, self._model_adapter)
        concurrency = SemaphorePolicy(limit=resolved_config.max_concurrent_tools)
        snapshot_store: SnapshotStore
        if isinstance(self._execution_state_store, ExecutionStateStore):
            log_branch(
                "SessionManager.start_session",
                "snapshot_store_persistent",
                call_id=session_id,
            )
            snapshot_store = LoopgraphSnapshotStore(self._execution_state_store)
        else:
            if self._execution_state_store is not None:
                log_branch(
                    "SessionManager.start_session",
                    "snapshot_store_memory_unadapted",
                    call_id=session_id,
                )
            else:
                log_branch(
                    "SessionManager.start_session",
                    "snapshot_store_memory",
                    call_id=session_id,
                )
            snapshot_store = InMemorySnapshotStore()
        graph_runtime = SessionGraphRuntime(
            registry.registry,
            concurrency_manager=concurrency,
            snapshot_store=snapshot_store,
            event_log_store=self._event_log_store,
            session_id=session_id,
            tool_registry=self._tool_registry,
            session_config=resolved_config,
        )
        try:
            listener = stream.bind_event_bus(graph_runtime.event_bus, session_id)
        except EngineError as exc:
            error_event = CoreEvent(
                session_id=session_id,
                type=EventType.SESSION_FAILED,
                payload=exc.to_dict(),
                error_code=exc.code.value,
            )
            await stream.publish(error_event)
            raise
        runtime = SessionRuntime(
            session=session,
            config=resolved_config,
            stream=stream,
            graph_builder=SessionGraphBuilder(),
            graph_runtime=graph_runtime,
            registry=registry,
            event_listener=listener,
            initial_messages=initial_messages or [],
            hooks=self._hook_registry,
            messages=list(initial_messages or []),  # Start with initial messages
            loop_context={"staged_queue": None},
        )
        self._sessions[session_id] = runtime
        event = CoreEvent(
            session_id=session_id,
            type=EventType.SESSION_STARTED,
            payload={"initial_messages": len(runtime.initial_messages)},
        )
        await stream.publish(event)
        return SessionHandle(session=session, stream=stream)

    async def step_session(
        self,
        session_id: str,
        input: str | None = None,
        tool_call_results: Sequence[ToolCall] | None = None,
    ) -> SessionStep:
        log_parameter(
            "SessionManager.step_session",
            session_id=session_id,
            input=input,
            call_id=session_id,
        )
        runtime = self._require_session(session_id)
        call_id = session_id
        await self._validate_tool_calls(runtime, tool_call_results)
        tool_ids = [call.tool_id for call in (tool_call_results or [])]
        _ensure_tool_handlers(runtime.registry, tool_ids)

        if input is not None:
            runtime.messages.append(_build_user_text_message(input))
            log_branch(
                "SessionManager.step_session", "user_input_appended", call_id=call_id
            )

        # Convert tool_call_results to a message and append to history
        # This follows the pattern used by other agent frameworks (Kode CLI, OpenCode, Gemini CLI)
        # where tool results are appended as user messages containing tool_output parts
        if tool_call_results:
            tool_result_message = _build_tool_result_message(tool_call_results)
            runtime.messages.append(tool_result_message)
            log_branch(
                "SessionManager.step_session", "tool_results_appended", call_id=call_id
            )

        reconstructed_messages, pruned_count, pruned_tokens = (
            build_reconstructed_context(
                runtime.messages,
                protected_rounds=2,
            )
        )
        context_token_estimate = _estimate_token_count(reconstructed_messages)
        log_variable_change(
            "SessionManager.step_session",
            "context_pruned_count",
            None,
            pruned_count,
            call_id=call_id,
        )
        log_variable_change(
            "SessionManager.step_session",
            "context_token_estimate",
            None,
            context_token_estimate,
            call_id=call_id,
        )

        effective_model_adapter = runtime.loop_context.get(
            "model_adapter", self._model_adapter
        )
        if effective_model_adapter is None:
            error_payload = {
                "code": "no_model_adapter",
                "message": "model adapter is not configured",
                "session_id": session_id,
            }
            await runtime.stream.publish(
                CoreEvent(
                    session_id=session_id,
                    type=EventType.SESSION_FAILED,
                    payload=error_payload,
                    error_code="no_model_adapter",
                )
            )
            raise SchedulerError("no model adapter configured", error_payload)

        runtime_tools = runtime.loop_context.get("tools")
        if isinstance(runtime_tools, list):
            tools_payload = list(runtime_tools)
        else:
            tools_payload = self._tool_registry.list_tools()

        payload = {
            "input": input,
            "tool_ids": tool_ids,
            "tool_call_results": tool_call_results or [],
            "graph_id": None,
            "messages": reconstructed_messages,  # Use reconstructed context for model adapter
            "context_token_estimate": context_token_estimate,
            "model_adapter": effective_model_adapter,
            "hook_registry": runtime.hooks,
            "session_hooks": runtime.loop_context.get("session_hooks"),
            "tool_registry": self._tool_registry,
            "tool_handlers": runtime.loop_context.get("tool_handlers"),
            "session_config": runtime.config,
            "core_event_stream": runtime.stream,
            "stream_queue": runtime.loop_context.get("stream_queue"),
            "session_id": session_id,
            "continuation_mode": runtime.loop_context.get(
                "continuation_mode", "automatic"
            ),
            "max_consecutive_steps": int(
                runtime.loop_context.get("max_consecutive_steps", 25)
            ),
            "main_loop_unbounded": bool(
                runtime.loop_context.get("main_loop_unbounded", False)
            ),
            "is_sub_agent": bool(runtime.loop_context.get("is_sub_agent", False)),
            "session_type": str(runtime.loop_context.get("session_type", "main")),
            "step_index": 0,
            "tools": tools_payload,
            "system_prompt": runtime.loop_context.get("system_prompt"),
            "allowlist": runtime.loop_context.get("allowlist"),
            "root_dir": runtime.loop_context.get("root_dir"),
            "loop_context": runtime.loop_context,
        }
        graph = runtime.graph_builder.build(session_id, payload=payload)
        session = replace(
            runtime.session,
            status=SessionStatus.RUNNING,
            updated_at=time.time(),
            graph_id=graph.graph_id,
            execution_state_id=graph.graph_id,
        )
        log_variable_change(
            "SessionManager.step_session",
            "session",
            runtime.session,
            session,
            call_id=call_id,
        )
        runtime.session = session
        captured: list[CoreEvent] = []

        async def collector(event: Event) -> None:
            core_event = transform_event(event, session_id)
            captured.append(core_event)
            await _emit_telemetry(runtime, core_event)

        runtime.graph_runtime.subscribe(None, collector)
        run_result: dict[str, Any] | None = None
        try:
            graph_result = await runtime.graph_runtime.run(
                graph.graph, graph.graph_id, payload=payload, session_id=session_id
            )
            run_result = graph_result.result
        except (GraphCycleError, HandlerNotFoundError, SchedulerError) as exc:
            failed_session = replace(
                runtime.session, status=SessionStatus.FAILED, updated_at=time.time()
            )
            runtime.session = failed_session
            error_event = CoreEvent(
                session_id=session_id,
                type=EventType.SESSION_FAILED,
                payload=exc.to_dict(),
                error_code=exc.code.value,
            )
            await runtime.stream.publish(error_event)
            captured.append(error_event)
            log_variable_change(
                "SessionManager.step_session",
                "session",
                session,
                failed_session,
                call_id=call_id,
            )
            raise
        except WormholeError as exc:
            failed_session = replace(
                runtime.session, status=SessionStatus.FAILED, updated_at=time.time()
            )
            runtime.session = failed_session
            error_event = CoreEvent(
                session_id=session_id,
                type=EventType.SESSION_FAILED,
                payload=exc.to_dict(),
                error_code=exc.code.value,
            )
            await runtime.stream.publish(error_event)
            captured.append(error_event)
            log_variable_change(
                "SessionManager.step_session",
                "session",
                session,
                failed_session,
                call_id=call_id,
            )
            raise
        finally:
            runtime.graph_runtime.unsubscribe(None, collector)

        if run_result is not None:
            output_payload = run_result.get("output")
            if isinstance(output_payload, dict):
                runtime.loop_context["last_output"] = dict(output_payload)
                output_messages = output_payload.get("messages")
                if isinstance(output_messages, list):
                    runtime.messages = output_messages
            else:
                runtime.loop_context["last_output"] = None

        step_event = CoreEvent(
            session_id=session_id,
            type=EventType.SESSION_STEP,
            payload={
                "graph_id": graph.graph_id,
                "input": input,
                "tool_call_results": tool_call_results or [],
            },
        )
        await runtime.stream.publish(step_event)
        captured.append(step_event)
        log_variable_change(
            "SessionManager.step_session", "events", None, captured, call_id=call_id
        )
        return SessionStep(session=session, events=captured)

    async def resume_session(
        self,
        session_id: str,
        snapshot: ExecutionStateSnapshot,
    ) -> Session:
        log_parameter(
            "SessionManager.resume_session", session_id=session_id, call_id=session_id
        )
        runtime = self._require_session(session_id)
        snapshot_store = InMemorySnapshotStore()
        snapshot_store.save(snapshot.graph_id, snapshot.data)
        if runtime.event_listener is not None:
            runtime.stream.unbind_event_bus(
                runtime.graph_runtime.event_bus, runtime.event_listener
            )
        concurrency = SemaphorePolicy(limit=runtime.config.max_concurrent_tools)
        runtime.graph_runtime = SessionGraphRuntime(
            runtime.registry.registry,
            concurrency_manager=concurrency,
            snapshot_store=snapshot_store,
            event_log_store=self._event_log_store,
            session_id=session_id,
            tool_registry=self._tool_registry,
            session_config=runtime.config,
        )
        runtime.event_listener = runtime.stream.bind_event_bus(
            runtime.graph_runtime.event_bus, session_id
        )
        session = replace(
            runtime.session,
            status=SessionStatus.RUNNING,
            updated_at=time.time(),
            execution_state_id=snapshot.execution_state_id,
            graph_id=snapshot.graph_id,
        )
        runtime.session = session
        event = CoreEvent(
            session_id=session_id,
            type=EventType.SESSION_RESUMED,
            payload={
                "execution_state_id": snapshot.execution_state_id,
                "graph_id": snapshot.graph_id,
            },
        )
        await runtime.stream.publish(event)
        return session

    async def register_tool(
        self,
        session_id: str,
        tool: ToolDefinition,
        handler: Callable[[dict[str, Any]], Any],
    ) -> None:
        log_parameter(
            "SessionManager.register_tool",
            session_id=session_id,
            tool=tool,
            call_id=session_id,
        )
        runtime = self._require_session(session_id)
        self._tool_registry.register(tool)
        handler_ref = f"tool:{tool.tool_id}"
        self._tool_registry.bind_handler(tool.tool_id, handler_ref)
        runtime.registry.register(handler_ref, handler)

    async def stop_session(self, session_id: str) -> Session:
        log_parameter(
            "SessionManager.stop_session", session_id=session_id, call_id=session_id
        )
        runtime = self._require_session(session_id)
        if runtime.event_listener is not None:
            try:
                runtime.stream.unbind_event_bus(
                    runtime.graph_runtime.event_bus, runtime.event_listener
                )
            except EngineError as exc:
                error_event = CoreEvent(
                    session_id=session_id,
                    type=EventType.SESSION_FAILED,
                    payload=exc.to_dict(),
                    error_code=exc.code.value,
                )
                await runtime.stream.publish(error_event)
                raise
            finally:
                runtime.event_listener = None
        session = replace(
            runtime.session, status=SessionStatus.COMPLETED, updated_at=time.time()
        )
        runtime.session = session
        event = CoreEvent(session_id=session_id, type=EventType.SESSION_COMPLETED)
        await runtime.stream.publish(event)
        log_variable_change(
            "SessionManager.stop_session", "event", None, event, call_id=session_id
        )
        return session

    def set_compaction_snapshot(self, session_id: str, snapshot_id: str | None) -> None:
        log_parameter(
            "SessionManager.set_compaction_snapshot",
            session_id=session_id,
            snapshot_id=snapshot_id,
            call_id=session_id,
        )
        runtime = self._require_session(session_id)
        runtime.session = replace(
            runtime.session,
            latest_compaction_id=snapshot_id,
            updated_at=time.time(),
        )

    def get_prompt_snapshot(self, session_id: str) -> str | None:
        log_parameter(
            "SessionManager.get_prompt_snapshot",
            session_id=session_id,
            call_id=session_id,
        )
        runtime = self._require_session(session_id)
        return runtime.session.latest_compaction_id

    def get_stream(self, session_id: str) -> EventStream[CoreEvent]:
        log_parameter(
            "SessionManager.get_stream", session_id=session_id, call_id=session_id
        )
        runtime = self._require_session(session_id)
        return runtime.stream

    def _require_session(self, session_id: str) -> SessionRuntime:
        runtime = self._sessions.get(session_id)
        if runtime is None:
            raise NotFoundError("session not found", {"session_id": session_id})
        return runtime

    def _resolve_session_config(
        self,
        config: SessionConfig | None,
        config_sources: ConfigSources | None,
    ) -> SessionConfig:
        log_parameter(
            "SessionManager._resolve_session_config",
            config=config,
            config_sources=config_sources,
        )
        if config_sources is None:
            log_branch("SessionManager._resolve_session_config", "no_config_sources")
            return config or SessionConfig()
        log_branch("SessionManager._resolve_session_config", "config_sources")
        resolved = resolve_config(config_sources)
        approval_timeout_value = resolved.get("approval_timeout_seconds", 60.0)
        approval_timeout_seconds = (
            None if approval_timeout_value is None else float(approval_timeout_value)
        )
        return SessionConfig(
            retention_days=int(resolved.get("retention_days", 30)),
            compaction_ratio=float(resolved.get("compaction_ratio", 0.7)),
            auto_compaction_enabled=bool(resolved.get("auto_compaction_enabled", True)),
            allowlisted_tools=resolved.get("allowlisted_tools", []),
            max_concurrent_tools=int(resolved.get("max_concurrent_tools", 1)),
            backpressure=resolved.get("backpressure"),
            model_retry_policy=resolved.get("model_retry_policy", RetryPolicy()),
            tool_retry_policy=resolved.get(
                "tool_retry_policy", RetryPolicy(max_retries=2)
            ),
            approval_timeout_seconds=approval_timeout_seconds,
            permission_rules=resolved.get("permission_rules", []),
            banned_command_patterns=resolved.get("banned_command_patterns", []),
        )

    async def _validate_tool_calls(
        self,
        runtime: SessionRuntime,
        tool_call_results: Sequence[ToolCall] | None,
    ) -> None:
        log_parameter("SessionManager._validate_tool_calls")
        if not tool_call_results or self._tool_registry is None:
            return
        for index, call in enumerate(tool_call_results, start=1):
            log_loop_iteration(
                "SessionManager._validate_tool_calls", "tool_call_results", index
            )
            tool = self._tool_registry.get(call.tool_id)
            if not is_tool_allowed(tool, runtime.config):
                raise PermissionDeniedError(
                    "tool call not permitted",
                    {
                        "tool_id": call.tool_id,
                        "tool_call_id": call.tool_call_id,
                        "session_id": runtime.session.session_id,
                    },
                )
