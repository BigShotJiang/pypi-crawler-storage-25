import{l as o,a as r}from"../chunks/BlXJn3KT.js";export{o as load_css,r as start};
