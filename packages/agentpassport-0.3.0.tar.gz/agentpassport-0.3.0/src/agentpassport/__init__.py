from agentpassport.agent import Agent
from agentpassport.identity import (
    Binding,
    BindingDocument,
    Revocation,
    bind_domain,
    bind_wallet,
    did_from_public_key,
    generate_keypair,
    parse_did,
    revoke_wallet,
    sign_agent_card,
    sign_delegation,
    validate_address,
    verify_agent_card,
    verify_auth_chain,
    verify_binding_attestation,
    verify_domain_binding,
    verify_domain_binding_attestation,
    verify_revocation_attestation,
    verify_wallet_binding,
)
from agentpassport.observability import EventEmitter, FileSink, MemorySink, OtelSink, StdoutSink
from agentpassport.registry_client import RegistryClient
from agentpassport.revocation import (
    InMemoryRevocationRegistry,
    RevocationRegistry,
    SqliteRevocationRegistry,
)
from agentpassport.task import (
    BudgetExceededError,
    BudgetTracker,
    TaskLifecycle,
    create_subtask,
)
from agentpassport.transport import HttpTransport, StdioTransport
from agentpassport.trust import ScopeError, TrustMiddleware
from agentpassport.types import (
    AgentCard,
    Constraints,
    CostInfo,
    Intent,
    ObservabilityEvent,
    TaskEnvelope,
    TaskState,
)

__all__ = [
    # Agent
    "Agent",
    # Identity
    "did_from_public_key",
    "generate_keypair",
    "parse_did",
    "sign_agent_card",
    "sign_delegation",
    "verify_agent_card",
    "verify_auth_chain",
    # Binding
    "Binding",
    "BindingDocument",
    "Revocation",
    "bind_domain",
    "bind_wallet",
    "revoke_wallet",
    "validate_address",
    "verify_binding_attestation",
    "verify_revocation_attestation",
    "verify_domain_binding",
    "verify_domain_binding_attestation",
    "verify_wallet_binding",
    # Observability
    "EventEmitter",
    "FileSink",
    "MemorySink",
    "OtelSink",
    "StdoutSink",
    # Registry
    "RegistryClient",
    # Revocation
    "InMemoryRevocationRegistry",
    "RevocationRegistry",
    "SqliteRevocationRegistry",
    # Task
    "BudgetExceededError",
    "BudgetTracker",
    "TaskLifecycle",
    "create_subtask",
    # Transport
    "HttpTransport",
    "StdioTransport",
    # Trust
    "ScopeError",
    "TrustMiddleware",
    # Types
    "AgentCard",
    "Constraints",
    "CostInfo",
    "Intent",
    "ObservabilityEvent",
    "TaskEnvelope",
    "TaskState",
]
