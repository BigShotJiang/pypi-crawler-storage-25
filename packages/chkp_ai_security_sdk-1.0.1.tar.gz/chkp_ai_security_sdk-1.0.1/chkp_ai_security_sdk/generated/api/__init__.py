# flake8: noqa

# import apis into api package
from chkp_ai_security_sdk.generated.api.ai_access_policy_api import AIAccessPolicyApi
from chkp_ai_security_sdk.generated.api.agents_policy_api import AgentsPolicyApi
from chkp_ai_security_sdk.generated.api.apps_catalog_api import AppsCatalogApi
from chkp_ai_security_sdk.generated.api.chats_policy_api import ChatsPolicyApi
from chkp_ai_security_sdk.generated.api.dlp_datatypes_api import DLPDatatypesApi
from chkp_ai_security_sdk.generated.api.deployment_status_api import DeploymentStatusApi
from chkp_ai_security_sdk.generated.api.rulebase_api import RulebaseApi
from chkp_ai_security_sdk.generated.api.users_api import UsersApi


# TEMPLATE EDIT: Generate API mixin class (replaces post-build api_mixin.py hack)
class _ApiMixin:
    """Auto-generated API mixin — provides property accessors for all generated API classes."""

    def _get_api_client(self):
        raise NotImplementedError


    @property
    def ai_access_policy_api(self):
        return AIAccessPolicyApi(self._get_api_client())


    @property
    def agents_policy_api(self):
        return AgentsPolicyApi(self._get_api_client())


    @property
    def apps_catalog_api(self):
        return AppsCatalogApi(self._get_api_client())


    @property
    def chats_policy_api(self):
        return ChatsPolicyApi(self._get_api_client())


    @property
    def dlp_datatypes_api(self):
        return DLPDatatypesApi(self._get_api_client())


    @property
    def deployment_status_api(self):
        return DeploymentStatusApi(self._get_api_client())


    @property
    def rulebase_api(self):
        return RulebaseApi(self._get_api_client())


    @property
    def users_api(self):
        return UsersApi(self._get_api_client())


