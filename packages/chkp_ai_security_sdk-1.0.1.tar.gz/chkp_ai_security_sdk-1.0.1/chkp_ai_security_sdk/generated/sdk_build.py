import json
import os
from chkp_ai_security_sdk.classes.workforceai_sdk_info import WorkforceAISDKInfo

def sdk_build_info() -> WorkforceAISDKInfo:
    data_path = os.path.join(os.path.dirname(__file__), 'sdk_build_data.json')
    with open(data_path, 'r') as f:
        data = json.load(f)
    return WorkforceAISDKInfo(**data)
