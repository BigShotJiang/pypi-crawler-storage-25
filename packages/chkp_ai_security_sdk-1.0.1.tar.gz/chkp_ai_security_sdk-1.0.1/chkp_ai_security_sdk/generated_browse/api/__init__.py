# flake8: noqa

# import apis into api package
from chkp_ai_security_sdk.generated_browse.api.apps_catalog_api import AppsCatalogApi
from chkp_ai_security_sdk.generated_browse.api.dlp_datatypes_api import DLPDatatypesApi
from chkp_ai_security_sdk.generated_browse.api.dlp_policy_api import DLPPolicyApi
from chkp_ai_security_sdk.generated_browse.api.deployment_status_api import DeploymentStatusApi
from chkp_ai_security_sdk.generated_browse.api.objects_api import ObjectsApi
from chkp_ai_security_sdk.generated_browse.api.rulebase_api import RulebaseApi
from chkp_ai_security_sdk.generated_browse.api.secure_browsing_policy_api import SecureBrowsingPolicyApi
from chkp_ai_security_sdk.generated_browse.api.users_api import UsersApi
from chkp_ai_security_sdk.generated_browse.api.web_access_policy_api import WebAccessPolicyApi


# TEMPLATE EDIT: Generate API mixin class (replaces post-build api_mixin.py hack)
class _ApiMixin:
    """Auto-generated API mixin — provides property accessors for all generated API classes."""

    def _get_api_client(self):
        raise NotImplementedError


    @property
    def apps_catalog_api(self):
        return AppsCatalogApi(self._get_api_client())


    @property
    def dlp_datatypes_api(self):
        return DLPDatatypesApi(self._get_api_client())


    @property
    def dlp_policy_api(self):
        return DLPPolicyApi(self._get_api_client())


    @property
    def deployment_status_api(self):
        return DeploymentStatusApi(self._get_api_client())


    @property
    def objects_api(self):
        return ObjectsApi(self._get_api_client())


    @property
    def rulebase_api(self):
        return RulebaseApi(self._get_api_client())


    @property
    def secure_browsing_policy_api(self):
        return SecureBrowsingPolicyApi(self._get_api_client())


    @property
    def users_api(self):
        return UsersApi(self._get_api_client())


    @property
    def web_access_policy_api(self):
        return WebAccessPolicyApi(self._get_api_client())


