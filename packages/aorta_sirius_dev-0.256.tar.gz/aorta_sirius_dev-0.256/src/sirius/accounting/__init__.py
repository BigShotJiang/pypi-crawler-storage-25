import datetime
import re
from abc import ABC, abstractmethod
from decimal import Decimal
from typing import List, Any, Dict

from sirius import common
from sirius.common import DataClass, Currency
from sirius.constants import SiriusEnvironmentSecretKey
from sirius.http_requests import AsyncHTTPSession, HTTPResponse


class Transaction(DataClass):
    description: str
    amount: Decimal
    from_account_running_balance: Decimal
    from_account: "Account"
    to_account: "Account"

    @property
    def id(self) -> str:
        return f"{self.from_account.__class__.__name__}-{self.to_account.__class__.__name__}-{self.id}"


class Account(DataClass, ABC):
    balance: Decimal
    currency: Currency

    @staticmethod
    @abstractmethod
    async def get_raw_transaction_data(from_date: datetime.date, to_date: datetime.date) -> List[Dict[str, Any]]:
        ...


class WiseAccount(Account):
    id: int

    @staticmethod
    async def get_raw_transaction_data(from_date: datetime.date, to_date: datetime.date) -> List[Dict[str, Any]]:
        pass


class IBKRAccount(Account):

    @staticmethod
    async def get_raw_transaction_data(from_date: datetime.date, to_date: datetime.date) -> List[Dict[str, Any]]:
        raw_transaction_data: List[Dict[str, Any]] = []
        session: AsyncHTTPSession = AsyncHTTPSession("https://ndcdyn.interactivebrokers.com")
        flex_query_token: str = await common.get_environmental_secret(SiriusEnvironmentSecretKey.IBKR_FLEX_QUERY_TOKEN)
        flex_query_id: str = await common.get_environmental_secret(SiriusEnvironmentSecretKey.IBKR_FLEX_QUERY_ID)
        reference_code_response: HTTPResponse = await session.get(f"https://ndcdyn.interactivebrokers.com/AccountManagement/FlexWebService/SendRequest?t={flex_query_token}&q={flex_query_id}&v=3")
        reference_code: str = re.search(r"<ReferenceCode>(.*?)</ReferenceCode>", reference_code_response.data).group(1)  # type: ignore[call-overload]

        transaction_response: HTTPResponse = await session.get(f"https://ndcdyn.interactivebrokers.com/AccountManagement/FlexWebService/GetStatement?t={flex_query_token}&q={reference_code}&v=3")
        for transaction_response_data in transaction_response.data.split("\n")[1:-1]:  # type: ignore[attr-defined]
            transaction_response_str_list: List[str] = [s.replace("\"", "").replace("'", "") for s in transaction_response_data.split(",")]
            description: str = transaction_response_str_list[31]
            date: datetime.date = datetime.datetime.strptime(transaction_response_str_list[28], "%Y-%m-%d").date()
            total_amount: Decimal = Decimal(transaction_response_str_list[43])
            activity_code: str = transaction_response_str_list[30]
            id: str = transaction_response_str_list[47]

            if activity_code == "" or from_date >= date or date >= to_date:
                continue

            if activity_code == "BUY":
                cost_of_trade: Decimal = Decimal(transaction_response_str_list[38])
                commission: Decimal = total_amount - cost_of_trade

                raw_transaction_data.append({
                    "description": description,
                    "amount": cost_of_trade,
                    "date": date,
                    "id": f"{id}-Trade"
                })

                raw_transaction_data.append({
                    "description": f"IBKR Commission: {description}",
                    "amount": commission,
                    "date": date,
                    "id": f"{id}-Commission"
                })

            else:
                raw_transaction_data.append({
                    "description": description,
                    "amount": total_amount,
                    "date": date,
                    "id": id
                })

        raw_transaction_data.sort(key=lambda x: x["id"])
        return raw_transaction_data
