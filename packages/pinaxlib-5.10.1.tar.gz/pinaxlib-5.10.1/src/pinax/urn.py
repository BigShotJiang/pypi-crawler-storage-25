"""Convenience URN builders for SDMX artefact references.

Instead of hand-typing long URN strings, use these helpers::

    import pinax as pk

    store.codelist(pk.urn.codelist("SDMX", "CL_GEO", "1.0"))
    store.codelist(pk.urn.codelist("ESTAT", "CL_GEO"))  # version defaults to "1.0"

    # Parse a URN back into components
    parsed = pk.urn.parse("urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_GEO(1.0)")
    parsed.agency  # "SDMX"
    parsed.id  # "CL_GEO"
    parsed.version  # "1.0"
"""

from __future__ import annotations

from typing import Any

from sdmxlib.model.urn import SdmxUrn

__all__ = [
    "codelist",
    "concept_scheme",
    "data_structure",
    "dataflow",
    "parse",
]

# SDMX info model package/class mappings
_CODELIST = ("codelist", "Codelist")
_DATAFLOW = ("datastructure", "Dataflow")
_DATA_STRUCTURE = ("datastructure", "DataStructure")
_CONCEPT_SCHEME = ("conceptscheme", "ConceptScheme")


def _build(package: str, artefact_class: str, agency: str, artefact_id: str, version: str) -> str:
    return str(
        SdmxUrn(
            package=package,
            artefact_class=artefact_class,
            agency=agency,
            id=artefact_id,
            version=version,
        )
    )


def codelist(agency: str, id: str, version: str = "1.0") -> str:  # noqa: A002
    """Build a codelist URN string.

    Example::

        pk.urn.codelist("SDMX", "CL_GEO", "1.0")
        # → "urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_GEO(1.0)"
    """
    return _build(*_CODELIST, agency, id, version)


def dataflow(agency: str, id: str, version: str = "1.0") -> str:  # noqa: A002
    """Build a dataflow URN string.

    Example::

        pk.urn.dataflow("ESTAT", "NAMA_10_GDP", "1.0")
        # → "urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=ESTAT:NAMA_10_GDP(1.0)"
    """
    return _build(*_DATAFLOW, agency, id, version)


def data_structure(agency: str, id: str, version: str = "1.0") -> str:  # noqa: A002
    """Build a data structure definition URN string.

    Example::

        pk.urn.data_structure("ESTAT", "DSD_NAMA_10_GDP", "1.0")
        # → "urn:sdmx:org.sdmx.infomodel.datastructure.DataStructure=ESTAT:DSD_NAMA_10_GDP(1.0)"
    """
    return _build(*_DATA_STRUCTURE, agency, id, version)


def concept_scheme(agency: str, id: str, version: str = "1.0") -> str:  # noqa: A002
    """Build a concept scheme URN string.

    Example::

        pk.urn.concept_scheme("SDMX", "CS_FREQ", "1.0")
        # → "urn:sdmx:org.sdmx.infomodel.conceptscheme.ConceptScheme=SDMX:CS_FREQ(1.0)"
    """
    return _build(*_CONCEPT_SCHEME, agency, id, version)


def parse(urn: str) -> SdmxUrn[Any]:
    """Parse a URN string into its components.

    Returns an ``SdmxUrn`` object with ``.agency``, ``.id``, ``.version``,
    ``.package``, and ``.artefact_class`` attributes.

    Example::

        parsed = pk.urn.parse("urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_GEO(1.0)")
        parsed.agency  # "SDMX"
        parsed.id  # "CL_GEO"
        parsed.version  # "1.0"
        str(parsed)  # round-trips to original URN string

    Raises ``ValueError`` if the string is not a valid SDMX URN.
    """
    return SdmxUrn.parse(urn)
