"""pinax command-line interface.

Top-level entry point installed as the ``pinax`` console script. Today's
single command is :func:`build_index`, which rebuilds a bundle's
``search/`` LanceDB index. The CLI is intentionally thin — all real work
lives in :meth:`pinax.Catalog.build_index`.

Requires the ``[search]`` extra (typer + sentence-transformers + lancedb).
"""

from __future__ import annotations

import logging
import os
import sys
import time
import warnings
from pathlib import Path

import typer
from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)

import pinax as pk

__all__ = ["app", "main"]


# E5-family models are asymmetric: documents must be encoded with
# ``passage: `` and queries with ``query: ``. Other families default to
# no prefix, which is correct for symmetric models (BGE-M3, jina-v3).
_E5_PREFIXES: dict[str, tuple[str, str]] = {
    "intfloat/multilingual-e5-small": ("passage: ", "query: "),
    "intfloat/multilingual-e5-base": ("passage: ", "query: "),
    "intfloat/multilingual-e5-large": ("passage: ", "query: "),
    "intfloat/e5-small-v2": ("passage: ", "query: "),
    "intfloat/e5-base-v2": ("passage: ", "query: "),
    "intfloat/e5-large-v2": ("passage: ", "query: "),
}

_DEFAULT_MODEL = "intfloat/multilingual-e5-base"

app = typer.Typer(
    name="pinax",
    help="Operational tools for pinax Catalog bundles.",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()
log = logging.getLogger("pinax.cli")


@app.callback()
def _main() -> None:
    """Force multi-command mode.

    Without an explicit callback, Typer treats a single-command app as
    that command and the command name becomes implicit — so
    ``pinax build-index <bundle>`` would parse ``build-index`` as the
    BUNDLE argument. This empty callback keeps the subcommand seam in
    place even while ``build-index`` is the only command.
    """


def _resolve_prefixes(
    model: str,
    document_prefix: str | None,
    query_prefix: str | None,
) -> tuple[str, str]:
    """Decide which document/query prefixes to use.

    Explicit CLI overrides win. When omitted, look up the model in
    :data:`_E5_PREFIXES`; an unrecognized model gets empty prefixes
    (correct for symmetric encoders, harmless for ones that don't care).
    """
    default_doc, default_q = _E5_PREFIXES.get(model, ("", ""))
    doc = default_doc if document_prefix is None else document_prefix
    qry = default_q if query_prefix is None else query_prefix
    return doc, qry


def _hush_encoder_logs() -> None:
    """Silence the noisy encoder/runtime libraries before they emit anything."""
    for noisy in ("httpx", "huggingface_hub", "transformers", "sentence_transformers"):
        logging.getLogger(noisy).setLevel(logging.CRITICAL)
    warnings.filterwarnings("ignore", message=".*unauthenticated.*")
    try:
        import transformers  # noqa: PLC0415

        transformers.logging.set_verbosity_error()
        transformers.logging.disable_progress_bar()
    except ImportError:
        return


def _load_encoder(model_name: str, device: str | None) -> object:
    """Load a SentenceTransformer encoder, preferring offline files.

    Tries ``local_files_only=True`` first so cached models avoid hitting
    the network on every invocation; falls back to a normal load (which
    will download if needed). ``device`` may be ``None`` / ``"auto"`` to
    let SentenceTransformers pick.
    """
    try:
        from sentence_transformers import SentenceTransformer  # noqa: PLC0415
    except ImportError as exc:
        console.print(
            f"[red]Missing dependency:[/] {exc}.\nInstall the search extra: [bold]uv pip install 'pinaxlib[search]'[/]"
        )
        raise typer.Exit(code=1) from exc

    resolved_device = None if device in (None, "auto") else device

    try:
        return SentenceTransformer(model_name, device=resolved_device, local_files_only=True)
    except OSError:
        # Cache miss — fall back to a network-allowed load.
        return SentenceTransformer(model_name, device=resolved_device)


@app.command("build-index")
def build_index(
    bundle: Path = typer.Argument(
        ...,
        help="Path to a pinax Catalog bundle (the folder containing meta.duckdb).",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    model: str = typer.Option(
        _DEFAULT_MODEL,
        "--model",
        help="SentenceTransformers / Hugging Face model id.",
    ),
    document_prefix: str | None = typer.Option(
        None,
        "--document-prefix",
        help="Prefix to prepend to documents at index time. Auto-derived for known model families.",
    ),
    query_prefix: str | None = typer.Option(
        None,
        "--query-prefix",
        help="Prefix to prepend to queries at search time. Auto-derived for known model families.",
    ),
    batch_size: int = typer.Option(
        256,
        "--batch-size",
        help="Encoder batch size. Sets PINAX_EMBED_BATCH_SIZE for this run.",
        min=1,
    ),
    device: str = typer.Option(
        "auto",
        "--device",
        help="Encoder device: auto | cpu | cuda | mps.",
    ),
    include_codes: bool = typer.Option(
        True,
        "--include-codes/--no-include-codes",
        help="Index SDMX code rows for BM25 search.",
    ),
    embed_codes: bool = typer.Option(
        False,
        "--embed-codes/--no-embed-codes",
        help="Also compute vector embeddings for code rows (slow; hours on large catalogs).",
    ),
    max_codes_per_codelist: int = typer.Option(
        500,
        "--max-codes-per-codelist",
        help="Skip codelists with more entries than this to avoid index bloat.",
        min=1,
    ),
) -> None:
    """Build or rebuild the LanceDB vector index for a Catalog bundle.

    The bundle's ``search/embeddings.json`` sidecar is updated with the
    chosen model, prefixes, embedding dimensionality, and row counts so
    that a query-side client can call
    :meth:`pinax.Catalog.check_index_compatible` to validate its encoder.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S",
    )

    if not (bundle / "meta.duckdb").is_file():
        console.print(
            f"[red]Not a pinax Catalog bundle:[/] {bundle}\nExpected to find [bold]meta.duckdb[/] at the top level."
        )
        raise typer.Exit(code=1)

    if embed_codes and not include_codes:
        console.print("[yellow]--embed-codes implies --include-codes; enabling.[/]")
        include_codes = True

    os.environ["PINAX_EMBED_BATCH_SIZE"] = str(batch_size)
    _hush_encoder_logs()

    doc_pref, qry_pref = _resolve_prefixes(model, document_prefix, query_prefix)

    console.print(
        f"[dim]bundle:[/] {bundle}\n"
        f"[dim]model:[/]  {model}  ([dim]device={device}, batch_size={batch_size}[/])\n"
        f"[dim]prefixes:[/] document={doc_pref!r}  query={qry_pref!r}"
    )

    with console.status(f"[dim]Loading encoder {model!r}…[/]"):
        encoder = _load_encoder(model, device)

    with console.status("[dim]Opening catalog…[/]"):
        store = pk.Catalog(str(bundle)).open()

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Embedding[/]"),
        BarColumn(bar_width=40),
        MofNCompleteColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        console=console,
    )

    task_id: TaskID | None = None

    def _on_progress(current: int, total: int) -> None:
        nonlocal task_id
        if task_id is None:
            task_id = progress.add_task("embed", total=total)
        else:
            progress.update(task_id, total=total)
        progress.update(task_id, completed=current)

    start = time.monotonic()
    with progress:
        n = store.build_index(
            embedding_model=encoder,
            progress=_on_progress,
            include_codes=include_codes,
            embed_codes=embed_codes,
            max_codes_per_codelist=max_codes_per_codelist,
            document_prefix=doc_pref,
            query_prefix=qry_pref,
            model_name=model,
        )

    elapsed = time.monotonic() - start
    meta = store.embedding_metadata
    dim = meta.embedding_dim if meta is not None else None
    dim_str = f"dim={dim}" if dim is not None else "dim=?"
    console.print(
        f"[bold green]Done[/] — [green]{n:,}[/] datasets indexed ([{dim_str}], {elapsed:.1f}s) → {bundle / 'search'}"
    )


def main() -> None:
    """Console-script entry point for ``pinax``."""
    app()


if __name__ == "__main__":
    sys.exit(app() or 0)
