"""Shared supporting types for the pinax domain model."""

from sdmxlib import InternationalString

__all__ = ["InternationalString"]
