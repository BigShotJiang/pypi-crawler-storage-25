"""CatalogDescription and CatalogRecord types for the pinax domain model.

DCAT-AP describes a catalog as a top-level container of datasets. In the
pinax runtime, a *catalog* is the DuckDB-backed :class:`pinax.Catalog`
store. The DCAT-style metadata record that describes such a catalog (its
title, publisher, list of datasets…) is :class:`CatalogDescription` here.
This split avoids the name collision between "DCAT Catalog the model
record" and "Catalog the store".
"""

from datetime import datetime

from attrs import Factory, define
from sdmxlib import InternationalString

from pinax.model.agents import Agent
from pinax.model.classification import Standard
from pinax.model.dataset import BaseDataset
from pinax.model.distribution import DataService
from pinax.model.licence import LicenceDocument
from pinax.model.skos import ConceptSchemeRef
from pinax.model.spatial import SpatialCoverage
from pinax.model.temporal import TemporalCoverage

__all__ = ["CatalogDescription", "CatalogRecord"]


@define
class CatalogRecord:
    """Metadata about a dataset's entry in the catalog.

    Maps to dcat:CatalogRecord in DCAT-AP. This is metadata about
    the catalog entry itself — when it was listed, where it was
    harvested from, etc. Optional — not all catalogs use this.
    """

    identifier: str
    primary_topic: BaseDataset
    listing_date: datetime | None = None
    modified: datetime | None = None
    source_catalog: str | None = None
    conforms_to: Standard | None = None


@define
class CatalogDescription:
    """A DCAT-style description record for a catalog of datasets.

    Maps to dcat:Catalog in DCAT-AP. This is metadata describing the
    catalog as a published artefact — title, publisher, list of datasets
    and services, licence, etc. The runtime store with the same
    DCAT-shaped role is :class:`pinax.Catalog`; the two are separate
    concerns. Use this when serialising to / from DCAT-AP RDF or when
    a catalog needs a self-describing manifest record.
    """

    identifier: str
    title: InternationalString
    description: InternationalString
    publisher: Agent
    datasets: list[BaseDataset] = Factory(list)
    services: list[DataService] = Factory(list)
    records: list[CatalogRecord] = Factory(list)
    homepage: str | None = None
    language: list[str] = Factory(list)
    licence: LicenceDocument | None = None
    spatial_coverage: list[SpatialCoverage] = Factory(list)
    temporal_coverage: TemporalCoverage | None = None
    theme_taxonomy: list[ConceptSchemeRef] = Factory(list)
    issued: datetime | None = None
    modified: datetime | None = None
