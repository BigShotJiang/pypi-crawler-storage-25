"""Core dataset types for the pinax domain model."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, TypeVar

from attrs import Factory, define
from sdmxlib import InternationalString

from pinax.model.agents import Agent, ContactPoint
from pinax.model.classification import Standard
from pinax.model.distribution import Distribution
from pinax.model.licence import LicenceDocument
from pinax.model.quality import ProvenanceStatement, QualityAnnotation
from pinax.model.skos import ConceptRef
from pinax.model.spatial import SpatialCoverage
from pinax.model.temporal import Frequency, TemporalCoverage

__all__ = [
    "AggregateDataset",
    "BaseDataset",
    "Dataset",
    "DatasetT",
    "GeospatialDataset",
    "MicrodataDataset",
    "OpenDataset",
    "PublicationDataset",
    "StatisticalDataset",
    "Variable",
]


@define
class BaseDataset:
    """Common fields for all dataset variants. Maps to DCAT-AP 3.0.

    Not intended for direct construction — use one of the five concrete
    variants: OpenDataset, AggregateDataset, MicrodataDataset,
    GeospatialDataset, PublicationDataset.
    """

    # --- Identity (always required) ---
    identifier: str
    title: InternationalString
    description: InternationalString
    kind: str  # discriminator — each variant narrows to Literal and provides a default

    # --- Core catalog metadata ---
    publisher: Agent | None = None
    contact_point: ContactPoint | None = None
    keywords: list[InternationalString] = Factory(list)
    themes: list[ConceptRef] = Factory(list)  # dcat:theme — URI refs, not owned
    subject: list[ConceptRef] = Factory(list)  # dcterms:subject — URI refs
    dataset_type: ConceptRef | None = None  # dcterms:type — URI ref
    issued: datetime | None = None
    modified: datetime | None = None
    frequency: Frequency | None = None
    spatial_coverage: list[SpatialCoverage] = Factory(list)
    temporal_coverage: TemporalCoverage | None = None
    distributions: list[Distribution] = Factory(list)
    licence: LicenceDocument | None = None
    language: list[str] = Factory(list)

    # --- Extended metadata ---
    landing_page: str | None = None
    version: str | None = None
    version_notes: InternationalString | None = None
    conforms_to: list[Standard] = Factory(list)
    creator: Agent | None = None
    access_rights: str | None = None
    status: str | None = None
    provenance: list[ProvenanceStatement] = Factory(list)
    quality_annotations: list[QualityAnnotation] = Factory(list)

    # --- Extensibility ---
    extras: dict[str, Any] = Factory(dict)


@define
class OpenDataset(BaseDataset):
    """Generic open dataset — the default bucket for non-specialized data."""

    kind: Literal["open"] = "open"  # pyright: ignore[reportIncompatibleVariableOverride]


@define
class AggregateDataset(BaseDataset):
    """A statistical aggregate dataset (tabular, with dimensions and measures).

    Extends BaseDataset with StatDCAT-AP discovery fields and an optional link
    to the full SDMX structural record in sdmxlib's shared DuckDB tables.
    dimension_names carries enough info for catalog search without a JOIN.
    """

    kind: Literal["aggregate"] = "aggregate"  # pyright: ignore[reportIncompatibleVariableOverride]
    dimension_names: list[InternationalString] = Factory(list)
    num_series: int | None = None
    # SDMX link: FK into sdmxlib's dataflows.urn in the shared DuckDB
    sdmx_dataflow_urn: str | None = None
    # Pivot axis dimension for ingest_data(). None = auto-detect from DSD.
    measure_dim: str | None = None


@define
class Variable:
    """A variable in a microdata dataset."""

    id: str
    label: InternationalString
    description: InternationalString | None = None
    value_type: str | None = None
    classification_id: str | None = None
    universe: str | None = None
    question_text: str | None = None
    valid_range: str | None = None
    derivation: str | None = None


@define
class MicrodataDataset(BaseDataset):
    """A microdata (survey/record-level) dataset."""

    kind: Literal["microdata"] = "microdata"  # pyright: ignore[reportIncompatibleVariableOverride]
    variables: list[Variable] = Factory(list)
    sample_size: int | None = None
    universe: str | None = None
    collection_method: str | None = None
    anonymization: str | None = None
    survey_id: str | None = None


@define
class GeospatialDataset(BaseDataset):
    """A geospatial dataset."""

    kind: Literal["geospatial"] = "geospatial"  # pyright: ignore[reportIncompatibleVariableOverride]
    crs: str | None = None
    spatial_resolution: str | None = None
    feature_types: list[str] = Factory(list)
    scale: str | None = None


@define
class PublicationDataset(BaseDataset):
    """A publication (article, report, monograph)."""

    kind: Literal["publication"] = "publication"  # pyright: ignore[reportIncompatibleVariableOverride]
    authors: list[str] = Factory(list)
    doi: str | None = None
    isbn: str | None = None
    publication_type: str | None = None
    pages: int | None = None
    series_title: InternationalString | None = None


# Public union type alias — the type you work with day-to-day.
# Use BaseDataset as the generic bound in query() and other generic contexts.
type Dataset = OpenDataset | AggregateDataset | MicrodataDataset | GeospatialDataset | PublicationDataset

# TypeVar for pre-PEP-695 generic code
DatasetT = TypeVar("DatasetT", bound=BaseDataset)

# Backward compatibility alias — AggregateDataset is the successor
StatisticalDataset = AggregateDataset
