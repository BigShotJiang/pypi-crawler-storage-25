"""LanceDB vector + full-text index for pinax search.

Isolated from the core store so that lancedb is never imported unless an
``embedding_model`` is passed to ``Catalog``, or ``search()`` is called
on a folder-mode catalog.  Core pinax has no dependency on lancedb.

The table stores one row per (dataset, language) with both a text column
(for BM25 full-text search via Tantivy) and an optional embedding column
(for semantic nearest-neighbour search).

Search modes
------------
- **BM25 only** — no embedding model required; ``search()`` uses Tantivy FTS
- **Semantic** — requires ``embedding_model``; pure vector nearest-neighbour
- **Hybrid** — requires ``embedding_model``; RRF merge of BM25 + vector
"""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

__all__: list[str] = ["LanceIndex"]

_TABLE = "search"

# Combined English + French stopwords — used at query time to strip noise
# before joining terms with AND/OR.  Merged into one set because pinax
# catalogs are bilingual and queries can arrive in either language.
_STOPWORDS: frozenset[str] = frozenset(
    {
        # English (standard Lucene/Tantivy set)
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "but",
        "by",
        "for",
        "if",
        "in",
        "into",
        "is",
        "it",
        "no",
        "not",
        "of",
        "on",
        "or",
        "such",
        "that",
        "the",
        "their",
        "then",
        "there",
        "these",
        "they",
        "this",
        "to",
        "was",
        "will",
        "with",
        # French
        "au",
        "aux",
        "avec",
        "ce",
        "ces",
        "dans",
        "de",
        "des",
        "du",
        "elle",
        "en",
        "et",
        "eux",
        "il",
        "je",
        "la",
        "le",
        "les",
        "leur",
        "lui",
        "ma",
        "mais",
        "me",
        "même",
        "mes",
        "mon",
        "ne",
        "nos",
        "notre",
        "nous",
        "ou",
        "par",
        "pas",
        "pour",
        "qu",
        "que",
        "qui",
        "sa",
        "se",
        "ses",
        "son",
        "sur",
        "ta",
        "te",
        "tes",
        "toi",
        "ton",
        "tu",
        "un",
        "une",
        "vos",
        "votre",
        "vous",
    }
)


def _strip_stopwords(text: str) -> str:
    """Strip English + French stopwords from *text*.

    Returns the original text unchanged for single-term queries or when
    all terms are stopwords.  Tantivy's built-in stopword list only covers
    English; this function also strips French stopwords so bilingual
    catalogs get consistent noise reduction.
    """
    terms = [t for t in text.split() if t.lower() not in _STOPWORDS]
    if not terms:
        return text
    return " ".join(terms)


def _dedupe_by_id(
    hits: Any,
    *,
    keep: str,
) -> list[tuple[str, float]]:
    """Collapse repeated ``id`` rows, keeping the best score per id.

    Preserves the order of *first* occurrence of each id, since LanceDB
    returns rows in rank order; ``keep`` controls which score replaces a
    later duplicate (``"max"`` for BM25 relevance, ``"min"`` for vector
    distance).
    """
    best: dict[str, float] = {}
    order: list[str] = []
    for ident, score in hits:
        if ident in best:
            if (keep == "max" and score > best[ident]) or (keep == "min" and score < best[ident]):
                best[ident] = score
        else:
            best[ident] = score
            order.append(ident)
    return [(ident, best[ident]) for ident in order]


def _entity_type_clause(entity_type: str | Sequence[str] | None) -> str:
    """Build a SQL fragment constraining ``entity_type``, or empty string."""
    if entity_type is None:
        return ""
    if isinstance(entity_type, str):
        return f"entity_type = '{entity_type}'"
    values = ", ".join(f"'{v}'" for v in entity_type)
    return f"entity_type IN ({values})"


def _prepare_query(text: str, operator: str) -> str:
    """Strip stopwords and join remaining terms with the given operator.

    Returns the original text unchanged for single-term queries or when
    all terms are stopwords.  Used internally and exposed for testing.
    """
    terms = [t for t in text.split() if t.lower() not in _STOPWORDS]
    if len(terms) <= 1:
        return text
    if operator == "and":
        return " AND ".join(terms)
    return " ".join(terms)


class LanceIndex:
    """Wraps a LanceDB table of dataset text + embeddings.

    Schema
    ------
    id           str               FK to ``dataset.identifier``
    entity_type  str               dataset kind (``"open"``, ``"aggregate"``, …)
    lang         str               BCP-47 language code (``"en"``, ``"fr"``, …)
    text         str               concatenated title + description + keywords
    embedding    list[float]|None  vector (None when no embedding model)
    """

    def __init__(self, path: str | Path) -> None:
        import lancedb  # noqa: PLC0415

        self._db: lancedb.DBConnection = lancedb.connect(str(path))
        self._tbl: Any | None = None
        self._has_fts: bool = False
        if _TABLE in self._db.list_tables().tables:
            self._tbl = self._db.open_table(_TABLE)

    def add(self, rows: list[dict[str, Any]]) -> None:
        """Upsert text/embedding rows.  Creates the table on the first call."""
        if not rows:
            return
        if self._tbl is None:
            self._tbl = self._db.create_table(_TABLE, data=rows)
        else:
            for row in rows:
                with contextlib.suppress(Exception):
                    self._tbl.delete(f"id = '{row['id']}' AND lang = '{row['lang']}'")
            self._tbl.add(rows)
        # Invalidate FTS index — will be rebuilt on next bm25_search or build_fts_index
        self._has_fts = False

    def add_bulk(self, rows: list[dict[str, Any]]) -> None:
        """Bulk-load rows, replacing the entire table.

        More efficient than per-row ``add()`` for full rebuilds — avoids
        O(n) deletes and LanceDB fragment accumulation.
        """
        if not rows:
            return
        if self._tbl is not None:
            self._db.drop_table(_TABLE)
        self._tbl = self._db.create_table(_TABLE, data=rows)
        self._has_fts = False

    # ------------------------------------------------------------------
    # Full-text (BM25) search via Tantivy
    # ------------------------------------------------------------------

    def build_fts_index(self) -> None:
        """Create or replace the Tantivy FTS index on the ``text`` column."""
        if self._tbl is None:
            return
        with contextlib.suppress(Exception):
            self._tbl.create_fts_index("text", replace=True)
            self._has_fts = True

    @staticmethod
    def _build_match_query(text: str, *, operator: str, fuzziness: int) -> Any:
        """Construct an FTS query that always includes exact matches.

        Tantivy's fuzzy query (used by LanceDB's :class:`MatchQuery`) has
        a quirk: when ``fuzziness > 0`` is set on a query term of length
        ≥ 8 chars, the underlying Levenshtein automaton excludes the
        exact term itself from the result set. So a user typing
        ``search("inflation", fuzzy=1)`` would silently get zero hits
        even though "inflation" is in the index.

        Workaround: when ``fuzziness > 0``, wrap an exact ``MatchQuery``
        and the fuzzy ``MatchQuery`` in a ``BooleanQuery`` joined with
        ``SHOULD`` — both paths contribute, so exact hits always come
        back regardless of how Tantivy's fuzzy automaton behaves.
        """
        from lancedb.query import (  # noqa: PLC0415
            BooleanQuery,
            FullTextOperator,
            MatchQuery,
            Occur,
        )

        fts_op = FullTextOperator.AND if operator == "and" else FullTextOperator.OR
        cleaned = _strip_stopwords(text)
        exact = MatchQuery(
            query=cleaned,
            column="text",
            operator=fts_op,
            boost=1.0,
            fuzziness=0,
            max_expansions=50,
            prefix_length=0,
        )
        if fuzziness == 0:
            return exact
        fuzzy = MatchQuery(
            query=cleaned,
            column="text",
            operator=fts_op,
            boost=1.0,
            fuzziness=fuzziness,
            max_expansions=50,
            prefix_length=0,
        )
        return BooleanQuery([(Occur.SHOULD, exact), (Occur.SHOULD, fuzzy)])

    def bm25_search(
        self,
        text: str,
        *,
        lang: str = "en",
        limit: int = 100,
        operator: str = "or",
        fuzziness: int = 0,
        entity_type: str | Sequence[str] | None = None,
    ) -> list[tuple[str, float]]:
        """Return ``[(identifier, bm25_score), …]`` ordered by BM25 relevance.

        Parameters
        ----------
        operator:
            How to join multi-term queries after stopword removal.
            ``"or"`` (default) matches any term; ``"and"`` requires all terms.
        fuzziness:
            Levenshtein edit distance for fuzzy matching (0, 1, or 2).
            ``0`` (default) requires exact term matches.
        entity_type:
            Restrict matches to one or more ``entity_type`` values
            (e.g. ``"open"`` or ``("open", "aggregate")``). When ``None``
            (default), all row kinds are eligible — including code rows.

        Builds the FTS index lazily on first call if not already present.
        Returns an empty list if the table has not been populated.

        Results are deduplicated by ``id`` (best score per id wins) so a
        single dataset never appears more than once in the ranked output.
        """
        if self._tbl is None:
            return []
        if not self._has_fts:
            self.build_fts_index()

        query = self._build_match_query(text, operator=operator, fuzziness=fuzziness)
        where_parts = [f"lang = '{lang}'"]
        type_clause = _entity_type_clause(entity_type)
        if type_clause:
            where_parts.append(type_clause)
        where_clause = " AND ".join(where_parts)
        # Oversample to leave headroom for dedup; cap to keep the query bounded.
        oversample = min(limit * 4, 1000) if entity_type is None else limit * 2
        try:
            results = (
                self._tbl.search(query, query_type="fts")
                .where(where_clause, prefilter=True)
                .limit(oversample)
                .select(["id", "_score"])
                .to_list()
            )
        except Exception:  # noqa: BLE001
            return []
        return _dedupe_by_id(((r["id"], float(r["_score"])) for r in results), keep="max")[:limit]

    def bm25_search_rows(
        self,
        text: str,
        *,
        columns: Sequence[str],
        lang: str = "en",
        limit: int = 100,
        operator: str = "or",
        fuzziness: int = 0,
        entity_type: str | Sequence[str] | None = None,
        id_filter: Sequence[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Return full BM25 result rows ordered by relevance.

        Like :meth:`bm25_search` but yields the requested *columns*
        alongside the score (``_score`` is always included).  Used by
        ``Catalog.search_codes`` to return structured code-row data
        without a second SQL round-trip.

        Parameters
        ----------
        columns:
            Lance columns to project into each result row, in addition to
            the score.  Always includes ``"_score"``.
        id_filter:
            Optional whitelist of ``id`` values to restrict matches to —
            used to scope code-level search to a specific dataset set.
        """
        if self._tbl is None:
            return []
        if not self._has_fts:
            self.build_fts_index()

        query = self._build_match_query(text, operator=operator, fuzziness=fuzziness)
        where_parts = [f"lang = '{lang}'"]
        type_clause = _entity_type_clause(entity_type)
        if type_clause:
            where_parts.append(type_clause)
        if id_filter:
            id_values = ", ".join(f"'{i}'" for i in id_filter)
            where_parts.append(f"id IN ({id_values})")
        where_clause = " AND ".join(where_parts)
        select_cols = list(dict.fromkeys([*columns, "_score"]))
        try:
            results = (
                self._tbl.search(query, query_type="fts")
                .where(where_clause, prefilter=True)
                .limit(limit)
                .select(select_cols)
                .to_list()
            )
        except Exception:  # noqa: BLE001
            return []
        return results

    # ------------------------------------------------------------------
    # Semantic (vector) search
    # ------------------------------------------------------------------

    def search(
        self,
        embedding: list[float],
        *,
        lang: str = "en",
        limit: int = 100,
        entity_type: str | Sequence[str] | None = None,
    ) -> list[tuple[str, float]]:
        """Return ``[(identifier, distance), …]`` ordered by vector distance.

        Parameters
        ----------
        entity_type:
            Restrict matches to one or more ``entity_type`` values
            (e.g. ``"open"`` or ``("open", "aggregate")``). When ``None``
            (default), all row kinds are eligible — including code rows.

        Returns an empty list if the table has not been populated yet.

        Results are deduplicated by ``id`` (best — i.e. lowest — distance
        per id wins) so a single dataset never appears more than once in
        the ranked output.
        """
        if self._tbl is None:
            return []
        where_parts = [f"lang = '{lang}'"]
        type_clause = _entity_type_clause(entity_type)
        if type_clause:
            where_parts.append(type_clause)
        where_clause = " AND ".join(where_parts)
        # Oversample to leave headroom for dedup; cap to keep the query bounded.
        oversample = min(limit * 4, 1000) if entity_type is None else limit * 2
        try:
            results = (
                self._tbl.search(embedding)
                .where(where_clause, prefilter=True)
                .limit(oversample)
                .select(["id", "_distance"])
                .to_list()
            )
        except Exception:  # noqa: BLE001
            return []
        return _dedupe_by_id(((r["id"], float(r["_distance"])) for r in results), keep="min")[:limit]

    # ------------------------------------------------------------------
    # Index management
    # ------------------------------------------------------------------

    def build_index(self) -> None:
        """Build ANN vector index + FTS index after a bulk load.

        The ANN index requires >= 256 rows for IVF-PQ training.
        The FTS index is always built when rows exist.
        """
        if self._tbl is None:
            return
        # FTS index
        self.build_fts_index()
        # ANN vector index
        with contextlib.suppress(Exception):
            n = self._tbl.count_rows()
            if n >= 256:  # minimum for IVF-PQ training
                self._tbl.create_index(metric="cosine")
