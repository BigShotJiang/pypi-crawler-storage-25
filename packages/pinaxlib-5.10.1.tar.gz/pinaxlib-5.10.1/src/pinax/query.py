"""Composable filter objects for Catalog queries.

Usage::

    import pinax.query as q

    results = (
        store.query(pk.AggregateDataset)
        .filter(q.has_code("GEO", "ON"))
        .filter(q.has_dimensions(["GEO", "SEX", "AGE"]))
        .execute()
    )

    results = store.query(pk.BaseDataset).filter(q.distribution(format="CSV")).execute()

Filter objects are passed as positional arguments to ``QueryBuilder.filter()``.
Multiple positional filters are ANDed together.  Within a single
``distribution()`` call, all keyword arguments must match the *same*
distribution row (AND semantics).  Two separate ``distribution()`` calls
require *two* matching distribution rows.

Predicate compilation
---------------------

Each filter implements ``to_sql(ctx)`` returning ``(fragment, params)``.
The ``ctx`` is a :class:`sdmxlib.CompileContext` (extended pinax-side as
``_QueryContext`` with a ``next_alias()`` counter and a WHERE accumulator).
This mirrors the predicate-compiler shape used by sdmxlib's CodeQuery, so
a future cross-library compiler can walk both pinax and sdmxlib predicates
through the same context. See
``docs/design/predicate-and-sqlrelation.md`` in the statcan-catalog-builder
repo for the full design.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from attrs import define, field

if TYPE_CHECKING:
    from sdmxlib import CompileContext

__all__ = [
    "ExistsFilter",
    "FieldFilter",
    "MapCondition",
    "MapFilter",
    "PositionalFilter",
    "SdmxCodeFilter",
    "SdmxCodelistFilter",
    "SdmxDimensionFilter",
    "description_contains",
    "distribution",
    "has_code",
    "has_dimensions",
    "has_keyword",
    "has_service",
    "has_spatial",
    "publishes",
    "serves",
    "title_contains",
]


@define(frozen=True)
class MapCondition:
    """A condition on a MAP(VARCHAR, VARCHAR) column.

    Used inside ``ExistsFilter.conditions`` when the bridge-table column
    is a DuckDB MAP rather than a scalar.  ``element_at(col, key)`` is
    emitted in the SQL instead of a plain ``col = ?``.
    """

    key: str  # language key, e.g. "en"
    value: str  # value to match


@define(frozen=True)
class MapFilter:
    """Filter on a MAP column of the main ``dataset`` table.

    Unlike ``ExistsFilter`` (which targets bridge tables via a subquery),
    ``MapFilter`` adds a direct WHERE clause against ``d.<column>``.
    """

    column: str  # "title", "description"
    key: str  # language key, e.g. "en"
    value: str  # value or LIKE pattern
    op: str = "eq"  # "eq" | "ilike"

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        """Return ``(sql_fragment, params)`` for a WHERE clause."""
        del ctx  # MapFilter targets the main row directly; no subquery alias needed
        if self.op == "ilike":
            return f"d.{self.column}[?] ILIKE ?", [self.key, self.value]
        return f"d.{self.column}[?] = ?", [self.key, self.value]


@define
class FieldFilter:
    """A simple equality/containment filter on a flat column."""

    field: str
    op: str  # "eq" | "in" | "like"
    value: Any


@define
class ExistsFilter:
    """A correlated EXISTS subquery filter.

    Instances are created by the helper functions below, not directly.

    Attributes:
    ----------
    table:
        The table to run the EXISTS subquery against.
    conditions:
        Column → value pairs that must all be satisfied (AND).
    join:
        Optional extra JOIN clause inside the subquery (e.g. to reach
        data_service through distributions).
    group_count:
        When set, appends a ``GROUP BY / HAVING COUNT(DISTINCT ...) = n``
        clause for "all-of" semantics (used by ``has_dimensions``).
    """

    table: str
    conditions: dict[str, Any] = field(factory=dict)
    join: str | None = None
    group_count: tuple[str, int] | None = None  # (column, expected_count)

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        """Return (sql_fragment, params) for a correlated EXISTS clause.

        ``alias_prefix`` is used to avoid table-alias collisions when
        multiple ExistsFilters are combined in one query.
        """
        alias_prefix = ctx.next_alias("ef")
        table_alias = f"{alias_prefix}_t"
        join_sql = f" {self.join}" if self.join else ""

        col_clauses: list[str] = [f"{table_alias}.dataset_id = d.identifier"]
        params: list[Any] = []

        for col, val in self.conditions.items():
            if isinstance(val, MapCondition):
                col_clauses.append(f"{table_alias}.{col}[?] = ?")
                params.extend([val.key, val.value])
            elif val is None:
                col_clauses.append(f"{table_alias}.{col} IS NULL")
            elif isinstance(val, (list, tuple)):
                placeholders = ", ".join("?" * len(val))
                col_clauses.append(f"{table_alias}.{col} IN ({placeholders})")
                params.extend(val)
            else:
                col_clauses.append(f"{table_alias}.{col} = ?")
                params.append(val)

        where_sql = " AND ".join(col_clauses)

        if self.group_count is not None:
            group_col, expected = self.group_count
            group_sql = f" GROUP BY {table_alias}.dataset_id HAVING COUNT(DISTINCT {table_alias}.{group_col}) = ?"
            params.append(expected)
        else:
            group_sql = ""

        sql = f"EXISTS (SELECT 1 FROM {self.table} {table_alias}{join_sql} WHERE {where_sql}{group_sql})"
        return sql, params


# ---------------------------------------------------------------------------
# Internal: no-op filter (matches everything — used for empty dimension lists)
# ---------------------------------------------------------------------------


@define
class _NoOpFilter(ExistsFilter):
    """A filter that never restricts results."""

    table: str = ""

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        del ctx
        return "1=1", []


# ---------------------------------------------------------------------------
# Public filter constructors
# ---------------------------------------------------------------------------


@define(frozen=True)
class SdmxCodelistFilter:
    """Filter datasets whose SDMX DSD uses *codelist_urn* in any dimension.

    JOINs through ``sdmx.dataflow → sdmx.dsd_component``.
    """

    codelist_urn: str

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        """Return (sql_fragment, params) for a correlated EXISTS clause."""
        alias_prefix = ctx.next_alias("ef")
        df = f"{alias_prefix}_df"
        comp = f"{alias_prefix}_comp"
        return (
            f"EXISTS ("
            f"SELECT 1 FROM sdmx.dataflow {df}"
            f" JOIN sdmx.dsd_component {comp} ON {comp}.dsd_urn = {df}.dsd_urn"
            f"   AND {comp}.codelist_urn = ?"
            f" WHERE {df}.urn = d.sdmx_dataflow_urn"
            f")"
        ), [self.codelist_urn]


@define(frozen=True)
class SdmxCodeFilter:
    """Filter datasets whose SDMX DSD has *dimension* with *code* in its codelist.

    JOINs through ``sdmx.dataflow → sdmx.dsd_component → sdmx.code``.
    Only matches ``AggregateDataset`` records with ``sdmx_dataflow_urn`` set.
    """

    dimension: str
    code: str
    codelist_urn: str | None = None

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        """Return (sql_fragment, params) for a correlated EXISTS clause."""
        alias_prefix = ctx.next_alias("ef")
        df = f"{alias_prefix}_df"
        comp = f"{alias_prefix}_comp"
        c = f"{alias_prefix}_c"
        params: list[Any] = [self.dimension]
        urn_clause = ""
        if self.codelist_urn is not None:
            urn_clause = f" AND {comp}.codelist_urn = ?"
            params.append(self.codelist_urn)
        params.append(self.code)
        return (
            f"EXISTS ("
            f"SELECT 1 FROM sdmx.dataflow {df}"
            f" JOIN sdmx.dsd_component {comp} ON {comp}.dsd_urn = {df}.dsd_urn"
            f"   AND {comp}.component_id = ?"
            f"{urn_clause}"
            f" JOIN sdmx.code {c} ON {c}.codelist_urn = {comp}.codelist_urn"
            f"   AND {c}.code_id = ?"
            f" WHERE {df}.urn = d.sdmx_dataflow_urn"
            f")"
        ), params


@define(frozen=True)
class SdmxDimensionFilter:
    """Filter datasets whose SDMX DSD has ALL of the listed dimensions.

    JOINs through ``sdmx.dataflow → sdmx.dsd_component``.
    Only matches ``AggregateDataset`` records with ``sdmx_dataflow_urn`` set.
    """

    dimensions: tuple[str, ...]

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        """Return (sql_fragment, params) for a correlated EXISTS clause."""
        alias_prefix = ctx.next_alias("ef")
        df = f"{alias_prefix}_df"
        comp = f"{alias_prefix}_comp"
        placeholders = ", ".join("?" * len(self.dimensions))
        params: list[Any] = [*self.dimensions, len(self.dimensions)]
        return (
            f"EXISTS ("
            f"SELECT 1 FROM sdmx.dataflow {df}"
            f" JOIN sdmx.dsd_component {comp} ON {comp}.dsd_urn = {df}.dsd_urn"
            f"   AND {comp}.component_id IN ({placeholders})"
            f" WHERE {df}.urn = d.sdmx_dataflow_urn"
            f" GROUP BY {df}.urn"
            f" HAVING COUNT(DISTINCT {comp}.component_id) = ?"
            f")"
        ), params


# Union of all filter types accepted as positional arguments to QueryBuilder.filter().
# All members implement to_sql(alias_prefix: str) -> tuple[str, list[Any]].
PositionalFilter = ExistsFilter | SdmxCodeFilter | SdmxCodelistFilter | SdmxDimensionFilter


def has_code(dimension: str, code: str, *, codelist_urn: str | None = None) -> SdmxCodeFilter:
    """Filter datasets whose SDMX DSD has *dimension* with *code* in its codelist.

    JOINs through ``sdmx.dataflow → sdmx.dsd_component → sdmx.code``.
    Only applies to ``AggregateDataset`` records ingested via SDMX.

    Parameters
    ----------
    dimension:
        The dimension ID to match (e.g. ``"GEO"``).
    code:
        The code value to match (e.g. ``"ON"``).
    codelist_urn:
        Optional codelist URN to disambiguate dimensions that share the same
        ID across different DSDs.  When omitted, matches any codelist.

    Example::

        store.query(pk.AggregateDataset).filter(q.has_code("GEO", "ON")).execute()
    """
    return SdmxCodeFilter(dimension=dimension, code=code, codelist_urn=codelist_urn)


def has_dimensions(dims: list[str]) -> SdmxDimensionFilter | _NoOpFilter:
    """Filter datasets whose SDMX DSD has ALL of the listed dimensions.

    JOINs through ``sdmx.dataflow → sdmx.dsd_component``.
    An empty list matches all datasets.

    Example::

        store.query(pk.AggregateDataset).filter(q.has_dimensions(["GEO", "SEX"])).execute()
    """
    if not dims:
        return _NoOpFilter()
    return SdmxDimensionFilter(dimensions=tuple(dims))


def distribution(**kwargs: Any) -> ExistsFilter:
    """Filter datasets that have a distribution matching *all* kwargs.

    Supported keys: ``format``, ``media_type``.  For service-level
    filtering pass ``service_type`` or ``endpoint_url`` — these are
    resolved via a LEFT JOIN to ``data_service``.

    All kwargs within one call must match the *same* distribution row.
    For "at least two separate distributions" semantics, call this
    function twice::

        .filter(q.distribution(format="CSV"))
        .filter(q.distribution(format="JSON"))

    Example::

        store.query(pk.BaseDataset).filter(q.distribution(media_type="text/csv")).execute()
    """
    service_keys = {"service_type", "endpoint_url"}
    dist_conditions: dict[str, Any] = {}
    svc_conditions: dict[str, Any] = {}
    needs_service_join = False

    for k, v in kwargs.items():
        if k in service_keys:
            svc_conditions[f"svc.{k}"] = v
            needs_service_join = True
        else:
            dist_conditions[k] = v

    conditions = dict(dist_conditions)
    join: str | None = None

    if needs_service_join:
        join = "LEFT JOIN data_service svc ON dist_t.access_service_id = svc.id"
        # Merge service conditions — they reference the svc alias so keep as-is
        # We'll handle this specially in to_sql by passing raw conditions
        conditions.update(svc_conditions)

    return _DistributionFilter(conditions=conditions, join=join)


def has_service(**kwargs: Any) -> ExistsFilter:
    """Filter datasets served by a data service matching *all* kwargs.

    Supported keys: ``service_type``, ``endpoint_url``.

    Example::

        store.query(pk.BaseDataset).filter(
            q.has_service(endpoint_url="https://example.com/sdmx")
        ).execute()
    """
    conditions = {f"svc.{k}": v for k, v in kwargs.items()}
    join = "LEFT JOIN data_service svc ON dist_t.access_service_id = svc.id"
    return _DistributionFilter(conditions=conditions, join=join)


# ---------------------------------------------------------------------------
# Internal: distribution filter with correct alias handling
# ---------------------------------------------------------------------------


@define
class _DistributionFilter(ExistsFilter):
    """EXISTS filter against distributions, with optional service JOIN.

    Overrides ``to_sql`` to use the ``dist`` alias so that svc.* conditions
    reference the correct alias.
    """

    table: str = "distribution"

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        alias_prefix = ctx.next_alias("ef")
        _ = alias_prefix
        join_sql = f" {self.join}" if self.join else ""
        col_clauses: list[str] = ["dist_t.dataset_id = d.identifier"]
        params: list[Any] = []

        for col, val in self.conditions.items():
            # col may already have a table prefix (e.g. "svc.service_type")
            fq_col = col if "." in col else f"dist_t.{col}"
            if val is None:
                col_clauses.append(f"{fq_col} IS NULL")
            elif isinstance(val, (list, tuple)):
                placeholders = ", ".join("?" * len(val))
                col_clauses.append(f"{fq_col} IN ({placeholders})")
                params.extend(val)
            else:
                col_clauses.append(f"{fq_col} = ?")
                params.append(val)

        where_sql = " AND ".join(col_clauses)
        sql = f"EXISTS (SELECT 1 FROM distribution dist_t{join_sql} WHERE {where_sql})"
        return sql, params


# ---------------------------------------------------------------------------
# Cross-entity filter constructors
# ---------------------------------------------------------------------------


# Supported kwargs for dataset-level conditions inside publishes/serves
_DATASET_KWARG_COLS: dict[str, str] = {
    "kind": "kind",
    "status": "status",
}


@define
class _PublishesFilter(ExistsFilter):
    """EXISTS filter for Agent queries — datasets the agent publishes.

    Correlates ``datasets.publisher_id = id`` where ``id`` is the ``agents``
    primary key from the outer query.  Inner ExistsFilter objects (e.g.
    ``has_code``) are applied inside the ``datasets d`` subquery where they
    can reference ``d.identifier`` normally.
    """

    table: str = "dataset"
    inner: list[PositionalFilter] = field(factory=list)
    dataset_kwargs: dict[str, Any] = field(factory=dict)

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        wheres: list[str] = ["d.publisher_id = id"]
        params: list[Any] = []

        for key, val in self.dataset_kwargs.items():
            col = _DATASET_KWARG_COLS.get(key)
            if col:
                wheres.append(f"d.{col} = ?")
                params.append(val)

        for ef in self.inner:
            ef_sql, ef_params = ef.to_sql(ctx)
            wheres.append(ef_sql)
            params.extend(ef_params)

        where_sql = " AND ".join(wheres)
        sql = f"EXISTS (SELECT 1 FROM dataset d WHERE {where_sql})"
        return sql, params


@define
class _ServesFilter(ExistsFilter):
    """EXISTS filter for DataService queries — datasets the service serves.

    Correlates via ``service_dataset`` bridge table.  Inner ExistsFilter
    objects are applied against the ``dataset d`` alias inside the subquery,
    where they can reference ``d.identifier`` normally.
    """

    table: str = "dataset"
    inner: list[PositionalFilter] = field(factory=list)
    dataset_kwargs: dict[str, Any] = field(factory=dict)

    def to_sql(self, ctx: CompileContext) -> tuple[str, list[Any]]:
        wheres: list[str] = ["d.identifier IN (SELECT dataset_id FROM service_dataset WHERE service_id = id)"]
        params: list[Any] = []

        for key, val in self.dataset_kwargs.items():
            col = _DATASET_KWARG_COLS.get(key)
            if col:
                wheres.append(f"d.{col} = ?")
                params.append(val)

        for ef in self.inner:
            ef_sql, ef_params = ef.to_sql(ctx)
            wheres.append(ef_sql)
            params.extend(ef_params)

        where_sql = " AND ".join(wheres)
        sql = f"EXISTS (SELECT 1 FROM dataset d WHERE {where_sql})"
        return sql, params


def publishes(*inner_filters: PositionalFilter, **kwargs: Any) -> ExistsFilter:
    """Filter Agents that publish datasets matching the given criteria.

    Pass ``ExistsFilter`` objects (e.g. ``has_code``, ``has_dimensions``) as
    positional arguments, and/or dataset-level conditions as keyword arguments
    (``kind``, ``status``).

    Example::

        # Agents that publish aggregate datasets about Ontario
        store.query(pk.Agent).filter(
            q.publishes(q.has_code("GEO", "ON"), kind="aggregate")
        ).all()
    """
    return _PublishesFilter(inner=list(inner_filters), dataset_kwargs=dict(kwargs))


def serves(*inner_filters: PositionalFilter, **kwargs: Any) -> ExistsFilter:
    """Filter DataServices that serve datasets matching the given criteria.

    Pass ``ExistsFilter`` objects as positional arguments and/or dataset-level
    conditions as keyword arguments (``kind``, ``status``).

    Example::

        # DataServices that serve datasets with a GEO dimension
        store.query(pk.DataService).filter(q.serves(q.has_dimensions(["GEO"]))).all()
    """
    return _ServesFilter(inner=list(inner_filters), dataset_kwargs=dict(kwargs))


# ---------------------------------------------------------------------------
# MAP column filter helpers
# ---------------------------------------------------------------------------


def has_spatial(label: str, *, lang: str = "en") -> ExistsFilter:
    """Filter datasets that have a spatial coverage matching *label*.

    Example::

        store.query(pk.BaseDataset).filter(q.has_spatial("Canada")).execute()
    """
    return ExistsFilter(
        table="dataset_spatial",
        conditions={"label": MapCondition(key=lang, value=label)},
    )


def has_keyword(keyword: str, *, lang: str = "en") -> ExistsFilter:
    """Filter datasets that have a keyword matching *keyword*.

    Example::

        store.query(pk.BaseDataset).filter(q.has_keyword("employment")).execute()
    """
    return ExistsFilter(
        table="dataset_keyword",
        conditions={"keyword": MapCondition(key=lang, value=keyword)},
    )


def title_contains(text: str, *, lang: str = "en") -> MapFilter:
    """Filter datasets whose title contains *text* (case-insensitive).

    Example::

        store.query(pk.BaseDataset).filter(q.title_contains("GDP")).execute()
    """
    return MapFilter(column="title", key=lang, value=f"%{text}%", op="ilike")


def description_contains(text: str, *, lang: str = "en") -> MapFilter:
    """Filter datasets whose description contains *text* (case-insensitive).

    Example::

        store.query(pk.BaseDataset).filter(q.description_contains("exchange")).execute()
    """
    return MapFilter(column="description", key=lang, value=f"%{text}%", op="ilike")
