"""snakeoil-web: Selector-free, self-healing web test automation."""

from snakeoil_web.agent import WebAgent

__version__ = "0.1.45"
__all__ = ["WebAgent"]
