"""
ARGOS — Test Suite: API Config
==================================
Tests for api/config.py

Covers:
  - Settings loads with defaults
  - All required fields have valid defaults
  - get_settings() returns cached singleton

Requirement refs: FR-17
"""

import pytest

from api.config import Settings, get_settings


class TestSettings:
    """Tests for the Settings class."""

    def test_default_database_path(self):
        """Default DATABASE_PATH should be ./data/argos.db."""
        s = Settings()
        assert s.DATABASE_PATH == "./data/argos.db"

    def test_default_host(self):
        """Default API_HOST should be 0.0.0.0."""
        s = Settings()
        assert s.API_HOST == "0.0.0.0"

    def test_default_port(self):
        """Default API_PORT should be 8000."""
        s = Settings()
        assert s.API_PORT == 8000

    def test_default_base_url(self):
        """Default API_BASE_URL should point to the DNS hostname."""
        s = Settings()
        assert "argos.news.ydns.eu" in s.API_BASE_URL

    def test_default_log_level(self):
        """Default LOG_LEVEL should be INFO."""
        s = Settings()
        assert s.LOG_LEVEL == "INFO"

    def test_secret_key_default_empty(self):
        """API_SECRET_KEY should default to empty string."""
        s = Settings()
        assert s.API_SECRET_KEY == ""


class TestGetSettings:
    """Tests for the get_settings() cached function."""

    def test_returns_settings_instance(self):
        """get_settings() should return a Settings instance."""
        s = get_settings()
        assert isinstance(s, Settings)

    def test_cached_singleton(self):
        """Multiple calls should return the same object."""
        s1 = get_settings()
        s2 = get_settings()
        assert s1 is s2
