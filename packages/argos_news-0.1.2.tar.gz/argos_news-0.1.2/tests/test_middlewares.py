"""
ARGOS — Test Suite: Middlewares
==================================
Tests for scraper/argos/middlewares.py

Covers:
  - UserAgentRotatorMiddleware sets User-Agent header
  - UA is randomly selected from pool
  - Proxy is applied when configured
  - Proxy is not applied when empty
  - from_crawler factory method works
  - User-Agent pool has sufficient variety

Requirement refs: L-04, L-08
"""

import pytest
from unittest.mock import MagicMock

from scraper.argos.middlewares import (
    USER_AGENT_POOL,
    UserAgentRotatorMiddleware,
)


class FakeRequest:
    """Mock Scrapy request."""
    def __init__(self):
        self.headers = {}
        self.meta = {}


class FakeSpider:
    """Mock spider."""
    name = "test_spider"


class TestUserAgentPool:
    """Tests for the UA pool constant."""

    def test_pool_not_empty(self):
        """UA pool must have at least one entry."""
        assert len(USER_AGENT_POOL) > 0

    def test_pool_has_variety(self):
        """Pool should have at least 5 different UAs."""
        assert len(USER_AGENT_POOL) >= 5

    def test_all_uas_are_strings(self):
        """Every UA must be a non-empty string."""
        for ua in USER_AGENT_POOL:
            assert isinstance(ua, str)
            assert len(ua) > 10  # Real UAs are long

    def test_uas_contain_mozilla(self):
        """Real browser UAs always contain 'Mozilla'."""
        for ua in USER_AGENT_POOL:
            assert "Mozilla" in ua, f"UA doesn't look real: {ua[:50]}"


class TestUserAgentRotatorMiddleware:
    """Tests for the UserAgentRotatorMiddleware."""

    def test_sets_user_agent_header(self):
        """process_request should set a User-Agent header."""
        mw = UserAgentRotatorMiddleware()
        request = FakeRequest()
        spider = FakeSpider()

        mw.process_request(request, spider)

        assert "User-Agent" in request.headers
        assert request.headers["User-Agent"] in USER_AGENT_POOL

    def test_random_rotation(self):
        """Different calls should produce different UAs (probabilistic)."""
        mw = UserAgentRotatorMiddleware()
        spider = FakeSpider()

        uas = set()
        for _ in range(50):
            request = FakeRequest()
            mw.process_request(request, spider)
            uas.add(request.headers["User-Agent"])

        # With 7 UAs and 50 calls, we should see at least 3 different ones
        assert len(uas) >= 3

    def test_proxy_applied_when_set(self):
        """If proxy_url is set, it should be applied to request.meta."""
        mw = UserAgentRotatorMiddleware(proxy_url="http://proxy.example.com:8080")
        request = FakeRequest()
        spider = FakeSpider()

        mw.process_request(request, spider)

        assert request.meta["proxy"] == "http://proxy.example.com:8080"

    def test_no_proxy_when_empty(self):
        """If proxy_url is empty, no proxy should be set."""
        mw = UserAgentRotatorMiddleware(proxy_url="")
        request = FakeRequest()
        spider = FakeSpider()

        mw.process_request(request, spider)

        assert "proxy" not in request.meta

    def test_returns_none(self):
        """process_request should return None (Scrapy convention)."""
        mw = UserAgentRotatorMiddleware()
        request = FakeRequest()
        spider = FakeSpider()

        result = mw.process_request(request, spider)
        assert result is None

    def test_spider_opened_no_crash(self):
        """spider_opened should complete without error."""
        mw = UserAgentRotatorMiddleware()
        mw.spider_opened(FakeSpider())
