"""
ARGOS — Test Suite: API Routes (Integration)
================================================
Tests for api/routes/health.py, sources.py, articles.py

Uses FastAPI's TestClient for HTTP-level integration testing.
Each test hits the actual route handler with a test database.

Covers:
  - GET /v1/health returns correct status
  - GET /v1/sources returns 4 sources
  - GET /v1/articles returns paginated results
  - GET /v1/articles/latest returns latest articles
  - GET /v1/articles/{id} returns single article
  - GET /v1/articles/{id} with invalid ID returns 404
  - GET /v1/articles with all filter parameters
  - GET / returns welcome message

Requirement refs: FR-17, FR-18, FR-20, FR-21
"""

import json
import os
import sqlite3
import tempfile

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(autouse=True)
def setup_test_db(tmp_path):
    """Create a test database with seed data."""
    db_path = str(tmp_path / "test_api.db")
    os.environ["DATABASE_PATH"] = db_path

    # Clear settings cache
    from api.config import get_settings
    get_settings.cache_clear()

    # Create and seed the database
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL DEFAULT '',
            summary TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL,
            tags TEXT NOT NULL DEFAULT '[]',
            source_name TEXT NOT NULL,
            source_url TEXT NOT NULL UNIQUE,
            published_at TEXT NOT NULL,
            scraped_at TEXT NOT NULL,
            country TEXT NOT NULL,
            orientation TEXT NOT NULL,
            trust_score REAL NOT NULL,
            is_israeli_influenced INTEGER NOT NULL DEFAULT 0
        )
    """)

    # Insert test articles
    articles = [
        ("Peace Talks Resume", "Body 1", "Summary 1", "politics",
         '["ceasefire"]', "Al Jazeera", "https://aj.com/1",
         "2024-03-12T09:00:00Z", "2024-03-12T09:15:00Z",
         "Qatar", "center-left", 0.55, 0),
        ("Oil Prices Surge", "Body 2", "Summary 2", "economy",
         '["oil"]', "Al Arabiya", "https://aa.net/2",
         "2024-03-11T10:00:00Z", "2024-03-11T10:15:00Z",
         "Saudi Arabia", "right", 0.40, 1),
    ]

    conn.executemany("""
        INSERT INTO articles (
            title, content, summary, category, tags,
            source_name, source_url, published_at, scraped_at,
            country, orientation, trust_score, is_israeli_influenced
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, articles)

    # Create indexes
    for sql in [
        "CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles (published_at)",
        "CREATE INDEX IF NOT EXISTS idx_articles_source_name ON articles (source_name)",
        "CREATE INDEX IF NOT EXISTS idx_articles_country ON articles (country)",
        "CREATE INDEX IF NOT EXISTS idx_articles_category ON articles (category)",
        "CREATE INDEX IF NOT EXISTS idx_articles_orientation ON articles (orientation)",
    ]:
        conn.execute(sql)

    conn.commit()
    conn.close()

    yield db_path

    if os.path.exists(db_path):
        os.remove(db_path)


@pytest.fixture
def client():
    """FastAPI test client."""
    from api.main import app
    return TestClient(app)


class TestRootEndpoint:
    """Tests for GET /."""

    def test_root_returns_welcome(self, client):
        """Root endpoint should return welcome JSON."""
        resp = client.get("/")
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "ARGOS API"
        assert data["version"] == "0.1.0"
        assert "docs" in data


class TestHealthEndpoint:
    """Tests for GET /v1/health."""

    def test_health_check(self, client):
        """Health endpoint should return ok status."""
        resp = client.get("/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["db_connected"] is True
        assert data["version"] == "0.1.0"
        assert isinstance(data["uptime_seconds"], int)
        assert isinstance(data["article_count"], int)


class TestSourcesEndpoint:
    """Tests for GET /v1/sources."""

    def test_list_sources(self, client):
        """Should return all 4 registered sources."""
        resp = client.get("/v1/sources")
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert len(data["data"]) == 4

    def test_source_fields(self, client):
        """Each source should have all required fields."""
        resp = client.get("/v1/sources")
        source = resp.json()["data"][0]
        required = {"domain", "source_name", "country",
                     "orientation", "trust_score", "is_israeli_influenced"}
        assert required.issubset(set(source.keys()))


class TestArticlesEndpoint:
    """Tests for GET /v1/articles."""

    def test_list_articles_no_filters(self, client):
        """Should return all articles with pagination."""
        resp = client.get("/v1/articles")
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert len(data["data"]) == 2
        assert "pagination" in data

    def test_pagination_structure(self, client):
        """Pagination should have all required fields."""
        resp = client.get("/v1/articles")
        p = resp.json()["pagination"]
        assert "page" in p
        assert "page_size" in p
        assert "total_results" in p
        assert "total_pages" in p
        assert "has_next" in p
        assert "has_prev" in p

    def test_filter_source_name(self, client):
        """source_name filter should work."""
        resp = client.get("/v1/articles?source_name=Al+Jazeera")
        data = resp.json()
        assert data["pagination"]["total_results"] == 1
        assert data["data"][0]["source_name"] == "Al Jazeera"

    def test_filter_category(self, client):
        """category filter should work."""
        resp = client.get("/v1/articles?category=economy")
        data = resp.json()
        assert data["pagination"]["total_results"] == 1

    def test_filter_country(self, client):
        """country filter should work."""
        resp = client.get("/v1/articles?country=Qatar")
        data = resp.json()
        assert data["pagination"]["total_results"] == 1

    def test_filter_title_search(self, client):
        """title search should do partial matching."""
        resp = client.get("/v1/articles?title=Peace")
        data = resp.json()
        assert data["pagination"]["total_results"] == 1

    def test_filter_israeli_influenced(self, client):
        """is_israeli_influenced filter should work."""
        resp = client.get("/v1/articles?is_israeli_influenced=true")
        data = resp.json()
        assert data["pagination"]["total_results"] == 1

    def test_topic_alias(self, client):
        """topic parameter should alias category."""
        resp = client.get("/v1/articles?topic=politics")
        data = resp.json()
        assert data["pagination"]["total_results"] == 1

    def test_pagination_params(self, client):
        """page and page_size should work."""
        resp = client.get("/v1/articles?page=1&page_size=1")
        data = resp.json()
        assert len(data["data"]) == 1
        assert data["pagination"]["has_next"] is True

    def test_sort_order(self, client):
        """sort_by and order should work."""
        resp = client.get("/v1/articles?sort_by=published_at&order=asc")
        data = resp.json()
        dates = [a["published_at"] for a in data["data"]]
        assert dates == sorted(dates)


class TestLatestEndpoint:
    """Tests for GET /v1/articles/latest."""

    def test_latest_articles(self, client):
        """Should return articles sorted by published_at DESC."""
        resp = client.get("/v1/articles/latest?count=5")
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        # First article should be the newest
        if len(data["data"]) >= 2:
            assert data["data"][0]["published_at"] >= data["data"][1]["published_at"]


class TestArticleByIdEndpoint:
    """Tests for GET /v1/articles/{id}."""

    def test_get_existing_article(self, client):
        """Should return the article with matching ID."""
        resp = client.get("/v1/articles/1")
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["data"]["id"] == 1

    def test_get_nonexistent_article(self, client):
        """Should return 404 for non-existing ID."""
        resp = client.get("/v1/articles/99999")
        assert resp.status_code == 404

    def test_article_has_all_fields(self, client):
        """Returned article should have all 14 fields (13 + id)."""
        resp = client.get("/v1/articles/1")
        article = resp.json()["data"]
        required_fields = {
            "id", "title", "content", "summary", "category", "tags",
            "source_name", "source_url", "published_at", "scraped_at",
            "country", "orientation", "trust_score", "is_israeli_influenced"
        }
        assert required_fields.issubset(set(article.keys()))
