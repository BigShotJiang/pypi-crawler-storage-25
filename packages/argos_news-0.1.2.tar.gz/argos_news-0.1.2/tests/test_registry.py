"""
ARGOS — Test Suite: Registry Module
=====================================
Tests for scraper/argos/registry.py

Covers:
  - SOURCE_REGISTRY has exactly 4 entries
  - All registry entries have the required 5 fields
  - apply_registry() correctly applies metadata to items
  - apply_registry() handles domain prefix stripping (www., english.)
  - apply_registry() handles unknown domains gracefully
  - get_registry_for_domain() returns correct entries

Requirement refs: FR-10, C-05
"""

import pytest

from scraper.argos.registry import (
    SOURCE_REGISTRY,
    apply_registry,
    get_registry_for_domain,
)


# ============================================================================
# SOURCE_REGISTRY Structure Tests
# ============================================================================

class TestSourceRegistry:
    """Tests for the frozen SOURCE_REGISTRY dictionary."""

    def test_registry_has_4_sources(self):
        """C-05: All 4 source networks must be present."""
        assert len(SOURCE_REGISTRY) == 4

    def test_registry_contains_aljazeera(self):
        """Al Jazeera must be in the registry."""
        assert "aljazeera.com" in SOURCE_REGISTRY

    def test_registry_contains_alarabiya(self):
        """Al Arabiya must be in the registry."""
        assert "alarabiya.net" in SOURCE_REGISTRY

    def test_registry_contains_skynewsarabia(self):
        """Sky News Arabia must be in the registry."""
        assert "skynewsarabia.com" in SOURCE_REGISTRY

    def test_registry_contains_middleeasteye(self):
        """Middle East Eye must be in the registry."""
        assert "middleeasteye.net" in SOURCE_REGISTRY

    def test_all_entries_have_required_fields(self):
        """Every registry entry must have all 5 metadata fields."""
        required_fields = {
            "source_name", "country", "orientation",
            "trust_score", "is_israeli_influenced"
        }
        for domain, entry in SOURCE_REGISTRY.items():
            for field in required_fields:
                assert field in entry, (
                    f"Missing field '{field}' in registry entry for {domain}"
                )

    def test_trust_scores_in_valid_range(self):
        """All trust scores must be in [0.0, 1.0]."""
        for domain, entry in SOURCE_REGISTRY.items():
            assert 0.0 <= entry["trust_score"] <= 1.0, (
                f"Invalid trust_score {entry['trust_score']} for {domain}"
            )

    def test_orientations_are_valid_enum(self):
        """All orientations must be valid enum values."""
        valid = {
            "left", "center-left", "center", "center-right",
            "right", "far-right", "state", "zionist", "unknown"
        }
        for domain, entry in SOURCE_REGISTRY.items():
            assert entry["orientation"] in valid, (
                f"Invalid orientation '{entry['orientation']}' for {domain}"
            )

    def test_is_israeli_influenced_is_bool(self):
        """is_israeli_influenced must be boolean."""
        for domain, entry in SOURCE_REGISTRY.items():
            assert isinstance(entry["is_israeli_influenced"], bool), (
                f"is_israeli_influenced is not bool for {domain}"
            )

    def test_specific_values_frozen(self):
        """Verify specific frozen registry values haven't changed."""
        aj = SOURCE_REGISTRY["aljazeera.com"]
        assert aj["source_name"] == "Al Jazeera"
        assert aj["country"] == "Qatar"
        assert aj["orientation"] == "center-left"
        assert aj["trust_score"] == 0.55
        assert aj["is_israeli_influenced"] is False

        aa = SOURCE_REGISTRY["alarabiya.net"]
        assert aa["source_name"] == "Al Arabiya"
        assert aa["country"] == "Saudi Arabia"
        assert aa["trust_score"] == 0.40
        assert aa["is_israeli_influenced"] is True


# ============================================================================
# apply_registry() Tests
# ============================================================================

class TestApplyRegistry:
    """Tests for the apply_registry() function."""

    def test_applies_aljazeera_metadata(self):
        """Verifies correct metadata applied for Al Jazeera domain."""
        item = {}
        result = apply_registry(item, "aljazeera.com")
        assert result["source_name"] == "Al Jazeera"
        assert result["country"] == "Qatar"
        assert result["orientation"] == "center-left"
        assert result["trust_score"] == 0.55
        assert result["is_israeli_influenced"] is False

    def test_applies_alarabiya_metadata(self):
        """Verifies correct metadata applied for Al Arabiya domain."""
        item = {}
        result = apply_registry(item, "alarabiya.net")
        assert result["source_name"] == "Al Arabiya"
        assert result["country"] == "Saudi Arabia"
        assert result["is_israeli_influenced"] is True

    def test_strips_www_prefix(self):
        """www. prefix should be stripped before lookup."""
        item = {}
        result = apply_registry(item, "www.aljazeera.com")
        assert result["source_name"] == "Al Jazeera"

    def test_strips_english_prefix(self):
        """english. prefix should be stripped before lookup."""
        item = {}
        result = apply_registry(item, "english.alarabiya.net")
        assert result["source_name"] == "Al Arabiya"

    def test_case_insensitive(self):
        """Domain lookup should be case-insensitive."""
        item = {}
        result = apply_registry(item, "ALJAZEERA.COM")
        assert result["source_name"] == "Al Jazeera"

    def test_unknown_domain_uses_defaults(self):
        """Unknown domains should get safe defaults, not crash."""
        item = {}
        result = apply_registry(item, "unknownnews.com")
        assert "Unknown" in result["source_name"]
        assert result["orientation"] == "unknown"
        assert result["trust_score"] == 0.0
        assert result["is_israeli_influenced"] is False

    def test_preserves_existing_item_fields(self):
        """apply_registry should not overwrite existing content fields."""
        item = {"title": "Test Article", "content": "Body text"}
        result = apply_registry(item, "aljazeera.com")
        assert result["title"] == "Test Article"
        assert result["content"] == "Body text"
        assert result["source_name"] == "Al Jazeera"

    def test_returns_same_item(self):
        """apply_registry should return the same item object (mutated)."""
        item = {}
        result = apply_registry(item, "aljazeera.com")
        assert result is item


# ============================================================================
# get_registry_for_domain() Tests
# ============================================================================

class TestGetRegistryForDomain:
    """Tests for the get_registry_for_domain() utility."""

    def test_returns_entry_for_known_domain(self):
        """Should return the registry entry for a known domain."""
        entry = get_registry_for_domain("middleeasteye.net")
        assert entry is not None
        assert entry["source_name"] == "Middle East Eye"

    def test_returns_none_for_unknown_domain(self):
        """Should return None for an unregistered domain."""
        entry = get_registry_for_domain("example.com")
        assert entry is None

    def test_strips_prefix(self):
        """Should strip www. and english. prefixes."""
        entry = get_registry_for_domain("www.skynewsarabia.com")
        assert entry is not None
        assert entry["source_name"] == "Sky News Arabia"
