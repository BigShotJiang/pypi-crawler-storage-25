"""
ARGOS — Test Suite: Deduplication Pipeline
=============================================
Tests for scraper/argos/pipelines/dedup.py

Covers:
  - First occurrence of URL passes through
  - Second occurrence of same URL is dropped
  - Different URLs both pass through
  - Statistics are tracked correctly
  - open_spider resets state
  - close_spider logs stats

Requirement refs: FR-06
"""

import pytest
from scrapy.exceptions import DropItem

from scraper.argos.pipelines.dedup import DeduplicationPipeline


class FakeSpider:
    """Minimal spider mock."""
    name = "test_spider"


class TestDeduplicationPipeline:
    """Tests for the DeduplicationPipeline."""

    def setup_method(self):
        """Fresh pipeline for each test."""
        self.pipeline = DeduplicationPipeline()
        self.spider = FakeSpider()
        self.pipeline.open_spider(self.spider)

    def test_first_url_passes(self):
        """First occurrence of a URL should pass through."""
        item = {"source_url": "https://example.com/article-1"}
        result = self.pipeline.process_item(item, self.spider)
        assert result["source_url"] == "https://example.com/article-1"

    def test_duplicate_url_drops(self):
        """Second occurrence of same URL should be dropped."""
        item1 = {"source_url": "https://example.com/article-1"}
        self.pipeline.process_item(item1, self.spider)

        item2 = {"source_url": "https://example.com/article-1"}
        with pytest.raises(DropItem, match="Duplicate"):
            self.pipeline.process_item(item2, self.spider)

    def test_different_urls_pass(self):
        """Different URLs should all pass through."""
        item1 = {"source_url": "https://example.com/article-1"}
        item2 = {"source_url": "https://example.com/article-2"}

        result1 = self.pipeline.process_item(item1, self.spider)
        result2 = self.pipeline.process_item(item2, self.spider)

        assert result1["source_url"] != result2["source_url"]

    def test_duplicate_count_tracked(self):
        """Duplicate counter should track drops."""
        self.pipeline.process_item(
            {"source_url": "https://example.com/1"}, self.spider
        )
        with pytest.raises(DropItem):
            self.pipeline.process_item(
                {"source_url": "https://example.com/1"}, self.spider
            )
        assert self.pipeline.duplicate_count == 1

    def test_seen_set_grows(self):
        """seen_urls set should grow with unique items."""
        for i in range(10):
            self.pipeline.process_item(
                {"source_url": f"https://example.com/{i}"}, self.spider
            )
        assert len(self.pipeline.seen_urls) == 10

    def test_open_spider_resets_state(self):
        """open_spider should reset the dedup state."""
        self.pipeline.process_item(
            {"source_url": "https://example.com/1"}, self.spider
        )
        self.pipeline.duplicate_count = 5

        self.pipeline.open_spider(self.spider)

        assert len(self.pipeline.seen_urls) == 0
        assert self.pipeline.duplicate_count == 0

    def test_close_spider_no_crash(self):
        """close_spider should complete without error."""
        self.pipeline.process_item(
            {"source_url": "https://example.com/1"}, self.spider
        )
        self.pipeline.close_spider(self.spider)  # Should not raise

    def test_empty_url_handled(self):
        """Empty source_url should be treated as any other URL."""
        item = {"source_url": ""}
        result = self.pipeline.process_item(item, self.spider)
        assert result["source_url"] == ""
