"""
ARGOS — Test Suite: Items Module
===================================
Tests for scraper/argos/items.py

Covers:
  - ArticleItem has exactly 13 fields
  - All field names match the ARGOS data model
  - Fields can be set and read correctly
  - Items work with dict-like access

Requirement refs: FR-05
"""

import pytest
import scrapy

from scraper.argos.items import ArticleItem


# All 13 required field names from the ARGOS data model.
REQUIRED_FIELDS = [
    "title", "content", "summary", "category", "tags",
    "source_name", "source_url", "published_at", "scraped_at",
    "country", "orientation", "trust_score", "is_israeli_influenced"
]


class TestArticleItem:
    """Tests for the ArticleItem Scrapy Item class."""

    def test_is_scrapy_item(self):
        """ArticleItem must be a Scrapy Item subclass."""
        assert issubclass(ArticleItem, scrapy.Item)

    def test_has_13_fields(self):
        """ArticleItem must define exactly 13 fields."""
        item = ArticleItem()
        assert len(item.fields) == 13

    def test_all_required_fields_present(self):
        """Every field in the ARGOS data model must be defined."""
        item = ArticleItem()
        for field in REQUIRED_FIELDS:
            assert field in item.fields, (
                f"Missing field '{field}' in ArticleItem"
            )

    def test_no_extra_fields(self):
        """No extra undocumented fields should exist."""
        item = ArticleItem()
        for field in item.fields:
            assert field in REQUIRED_FIELDS, (
                f"Unexpected field '{field}' in ArticleItem"
            )

    def test_can_set_and_get_string_fields(self):
        """String fields should accept and return strings."""
        item = ArticleItem()
        item["title"] = "Test Headline"
        assert item["title"] == "Test Headline"

    def test_can_set_and_get_list_field(self):
        """tags field should accept and return lists."""
        item = ArticleItem()
        item["tags"] = ["war", "diplomacy"]
        assert item["tags"] == ["war", "diplomacy"]

    def test_can_set_and_get_float_field(self):
        """trust_score should accept and return floats."""
        item = ArticleItem()
        item["trust_score"] = 0.55
        assert item["trust_score"] == 0.55

    def test_can_set_and_get_bool_field(self):
        """is_israeli_influenced should accept and return booleans."""
        item = ArticleItem()
        item["is_israeli_influenced"] = True
        assert item["is_israeli_influenced"] is True

    def test_can_convert_to_dict(self):
        """Item should be convertible to a plain dict."""
        item = ArticleItem()
        item["title"] = "Test"
        item["content"] = "Body"
        d = dict(item)
        assert d["title"] == "Test"
        assert d["content"] == "Body"

    def test_empty_tags_list(self):
        """tags should accept an empty list []."""
        item = ArticleItem()
        item["tags"] = []
        assert item["tags"] == []

    def test_empty_content_string(self):
        """content should accept empty string '' for paywalled articles."""
        item = ArticleItem()
        item["content"] = ""
        assert item["content"] == ""
