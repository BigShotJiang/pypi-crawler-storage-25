"""
ARGOS — Test Suite: Validation Pipeline
==========================================
Tests for scraper/argos/pipelines/validation.py

Covers:
  - Valid items pass through unchanged
  - Missing fields cause DropItem
  - Empty title causes DropItem
  - Empty summary causes DropItem
  - Empty content is ALLOWED (paywall, L-05)
  - Invalid category enum causes DropItem
  - Invalid orientation enum causes DropItem
  - Out-of-range trust_score causes DropItem
  - Non-boolean is_israeli_influenced causes DropItem
  - Non-list tags causes DropItem
  - Empty list tags is ALLOWED
  - Invalid source_url causes DropItem
  - Empty timestamps cause DropItem

Requirement refs: FR-05
"""

import pytest
from scrapy.exceptions import DropItem

from scraper.argos.pipelines.validation import (
    CATEGORY_VALUES,
    ORIENTATION_VALUES,
    ValidationPipeline,
)


def _make_valid_item():
    """Helper: creates a fully valid article item dict for testing."""
    return {
        "title": "Test Article Title",
        "content": "Full article body text here.",
        "summary": "Brief summary of the article.",
        "category": "politics",
        "tags": ["test", "article"],
        "source_name": "Al Jazeera",
        "source_url": "https://www.aljazeera.com/news/2024/1/1/test",
        "published_at": "2024-01-01T09:00:00Z",
        "scraped_at": "2024-01-01T09:15:00Z",
        "country": "Qatar",
        "orientation": "center-left",
        "trust_score": 0.55,
        "is_israeli_influenced": False,
    }


class FakeSpider:
    """Minimal spider mock for pipeline testing."""
    name = "test_spider"


class TestValidationPipeline:
    """Tests for the ValidationPipeline."""

    def setup_method(self):
        """Initialize a fresh pipeline for each test."""
        self.pipeline = ValidationPipeline()
        self.spider = FakeSpider()

    # --- Happy Path ---

    def test_valid_item_passes(self):
        """A fully valid item should pass through unchanged."""
        item = _make_valid_item()
        result = self.pipeline.process_item(item, self.spider)
        assert result == item

    def test_valid_item_with_empty_content(self):
        """Empty content is valid — indicates paywall/deleted (L-05)."""
        item = _make_valid_item()
        item["content"] = ""
        result = self.pipeline.process_item(item, self.spider)
        assert result["content"] == ""

    def test_valid_item_with_empty_tags(self):
        """Empty tags list [] is valid."""
        item = _make_valid_item()
        item["tags"] = []
        result = self.pipeline.process_item(item, self.spider)
        assert result["tags"] == []

    # --- Missing Fields ---

    def test_missing_title_drops(self):
        """Missing title field should drop the item."""
        item = _make_valid_item()
        del item["title"]
        with pytest.raises(DropItem, match="title"):
            self.pipeline.process_item(item, self.spider)

    def test_missing_source_url_drops(self):
        """Missing source_url field should drop the item."""
        item = _make_valid_item()
        del item["source_url"]
        with pytest.raises(DropItem, match="source_url"):
            self.pipeline.process_item(item, self.spider)

    def test_missing_category_drops(self):
        """Missing category should drop the item."""
        item = _make_valid_item()
        del item["category"]
        with pytest.raises(DropItem, match="category"):
            self.pipeline.process_item(item, self.spider)

    def test_none_field_drops(self):
        """A field set to None should drop the item."""
        item = _make_valid_item()
        item["title"] = None
        with pytest.raises(DropItem, match="title"):
            self.pipeline.process_item(item, self.spider)

    # --- Empty String Validations ---

    def test_empty_title_drops(self):
        """Empty string title should drop (not just missing)."""
        item = _make_valid_item()
        item["title"] = ""
        with pytest.raises(DropItem, match="Empty title"):
            self.pipeline.process_item(item, self.spider)

    def test_whitespace_title_drops(self):
        """Whitespace-only title should drop."""
        item = _make_valid_item()
        item["title"] = "   "
        with pytest.raises(DropItem, match="Empty title"):
            self.pipeline.process_item(item, self.spider)

    def test_empty_summary_drops(self):
        """Empty summary should drop."""
        item = _make_valid_item()
        item["summary"] = ""
        with pytest.raises(DropItem, match="Empty summary"):
            self.pipeline.process_item(item, self.spider)

    # --- Enum Validations ---

    def test_all_valid_categories_pass(self):
        """Every value in CATEGORY_VALUES should pass."""
        for cat in CATEGORY_VALUES:
            item = _make_valid_item()
            item["category"] = cat
            result = self.pipeline.process_item(item, self.spider)
            assert result["category"] == cat

    def test_invalid_category_drops(self):
        """An invalid category value should drop."""
        item = _make_valid_item()
        item["category"] = "entertainment"  # not in enum
        with pytest.raises(DropItem, match="Invalid category"):
            self.pipeline.process_item(item, self.spider)

    def test_all_valid_orientations_pass(self):
        """Every value in ORIENTATION_VALUES should pass."""
        for ori in ORIENTATION_VALUES:
            item = _make_valid_item()
            item["orientation"] = ori
            result = self.pipeline.process_item(item, self.spider)
            assert result["orientation"] == ori

    def test_invalid_orientation_drops(self):
        """An invalid orientation value should drop."""
        item = _make_valid_item()
        item["orientation"] = "neutral"  # not in enum
        with pytest.raises(DropItem, match="Invalid orientation"):
            self.pipeline.process_item(item, self.spider)

    # --- Trust Score Validations ---

    def test_trust_score_zero_passes(self):
        """Trust score 0.0 is valid (minimum)."""
        item = _make_valid_item()
        item["trust_score"] = 0.0
        result = self.pipeline.process_item(item, self.spider)
        assert result["trust_score"] == 0.0

    def test_trust_score_one_passes(self):
        """Trust score 1.0 is valid (maximum)."""
        item = _make_valid_item()
        item["trust_score"] = 1.0
        result = self.pipeline.process_item(item, self.spider)
        assert result["trust_score"] == 1.0

    def test_trust_score_negative_drops(self):
        """Negative trust score should drop."""
        item = _make_valid_item()
        item["trust_score"] = -0.1
        with pytest.raises(DropItem, match="trust_score"):
            self.pipeline.process_item(item, self.spider)

    def test_trust_score_above_one_drops(self):
        """Trust score > 1.0 should drop."""
        item = _make_valid_item()
        item["trust_score"] = 1.01
        with pytest.raises(DropItem, match="trust_score"):
            self.pipeline.process_item(item, self.spider)

    def test_trust_score_string_drops(self):
        """Non-numeric trust score should drop."""
        item = _make_valid_item()
        item["trust_score"] = "high"
        with pytest.raises(DropItem, match="trust_score"):
            self.pipeline.process_item(item, self.spider)

    # --- Type Validations ---

    def test_non_bool_israeli_drops(self):
        """Non-boolean is_israeli_influenced should drop."""
        item = _make_valid_item()
        item["is_israeli_influenced"] = "yes"
        with pytest.raises(DropItem, match="is_israeli_influenced"):
            self.pipeline.process_item(item, self.spider)

    def test_non_list_tags_drops(self):
        """tags must be a list, not a string."""
        item = _make_valid_item()
        item["tags"] = "tag1,tag2"
        with pytest.raises(DropItem, match="tags must be a list"):
            self.pipeline.process_item(item, self.spider)

    # --- URL Validation ---

    def test_invalid_source_url_drops(self):
        """source_url must start with http:// or https://."""
        item = _make_valid_item()
        item["source_url"] = "ftp://example.com/article"
        with pytest.raises(DropItem, match="Invalid source_url"):
            self.pipeline.process_item(item, self.spider)

    def test_http_url_passes(self):
        """http:// URLs should pass."""
        item = _make_valid_item()
        item["source_url"] = "http://example.com/article"
        result = self.pipeline.process_item(item, self.spider)
        assert result["source_url"] == "http://example.com/article"

    # --- Timestamp Validations ---

    def test_empty_published_at_drops(self):
        """Empty published_at should drop."""
        item = _make_valid_item()
        item["published_at"] = ""
        with pytest.raises(DropItem, match="published_at"):
            self.pipeline.process_item(item, self.spider)

    def test_empty_scraped_at_drops(self):
        """Empty scraped_at should drop."""
        item = _make_valid_item()
        item["scraped_at"] = ""
        with pytest.raises(DropItem, match="scraped_at"):
            self.pipeline.process_item(item, self.spider)
