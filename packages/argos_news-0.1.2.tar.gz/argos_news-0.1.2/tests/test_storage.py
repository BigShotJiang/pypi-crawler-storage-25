"""
ARGOS — Test Suite: Storage Pipeline
========================================
Tests for scraper/argos/pipelines/storage.py

Covers:
  - Table creation (with all columns and indexes)
  - Single item storage and retrieval
  - Batch flushing at BATCH_SIZE
  - Final flush on close_spider
  - INSERT OR IGNORE dedup
  - tags serialized as JSON
  - is_israeli_influenced stored as integer
  - Database file auto-creation

Requirement refs: FR-05, FR-06, FR-11
"""

import json
import os
import sqlite3
import tempfile

import pytest

from scraper.argos.pipelines.storage import StoragePipeline


def _make_valid_article(url_suffix="1"):
    """Helper: creates a valid article dict for storage."""
    return {
        "title": f"Article {url_suffix}",
        "content": "Full body text.",
        "summary": "Brief summary.",
        "category": "politics",
        "tags": ["test", "article"],
        "source_name": "Al Jazeera",
        "source_url": f"https://aljazeera.com/news/{url_suffix}",
        "published_at": "2024-01-01T09:00:00Z",
        "scraped_at": "2024-01-01T09:15:00Z",
        "country": "Qatar",
        "orientation": "center-left",
        "trust_score": 0.55,
        "is_israeli_influenced": False,
    }


class FakeSpider:
    """Minimal spider mock."""
    name = "test_spider"


class TestStoragePipeline:
    """Tests for the StoragePipeline."""

    def setup_method(self):
        """Create a temp DB for each test."""
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test_argos.db")
        os.environ["DATABASE_PATH"] = self.db_path

        self.pipeline = StoragePipeline()
        self.spider = FakeSpider()
        self.pipeline.open_spider(self.spider)

    def teardown_method(self):
        """Clean up temp DB."""
        self.pipeline.close_spider(self.spider)
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.tmpdir)

    def test_table_created(self):
        """articles table should exist after open_spider."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='articles'"
        )
        assert cursor.fetchone() is not None
        conn.close()

    def test_indexes_created(self):
        """All indexes should exist after open_spider."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index'"
        )
        indexes = {row[0] for row in cursor.fetchall()}
        conn.close()

        expected = {
            "idx_articles_published_at",
            "idx_articles_source_name",
            "idx_articles_country",
            "idx_articles_category",
            "idx_articles_orientation",
            "idx_articles_source_category",
        }
        assert expected.issubset(indexes)

    def test_single_item_stored(self):
        """A single item should be stored after flush."""
        article = _make_valid_article("1")
        self.pipeline.process_item(article, self.spider)
        self.pipeline._flush_batch()

        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute("SELECT COUNT(*) FROM articles")
        count = cursor.fetchone()[0]
        conn.close()

        assert count == 1

    def test_item_fields_correct(self):
        """Stored item fields should match input."""
        article = _make_valid_article("1")
        self.pipeline.process_item(article, self.spider)
        self.pipeline._flush_batch()

        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.execute("SELECT * FROM articles WHERE id=1")
        row = cursor.fetchone()
        conn.close()

        assert row["title"] == "Article 1"
        assert row["source_name"] == "Al Jazeera"
        assert row["category"] == "politics"
        assert row["trust_score"] == 0.55

    def test_tags_stored_as_json(self):
        """tags should be serialized as a JSON string."""
        article = _make_valid_article("1")
        article["tags"] = ["war", "diplomacy"]
        self.pipeline.process_item(article, self.spider)
        self.pipeline._flush_batch()

        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute("SELECT tags FROM articles WHERE id=1")
        tags_json = cursor.fetchone()[0]
        conn.close()

        assert json.loads(tags_json) == ["war", "diplomacy"]

    def test_israeli_influenced_stored_as_int(self):
        """is_israeli_influenced should be stored as 0 or 1."""
        article = _make_valid_article("1")
        article["is_israeli_influenced"] = True
        self.pipeline.process_item(article, self.spider)
        self.pipeline._flush_batch()

        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            "SELECT is_israeli_influenced FROM articles WHERE id=1"
        )
        val = cursor.fetchone()[0]
        conn.close()

        assert val == 1

    def test_duplicate_url_ignored(self):
        """INSERT OR IGNORE should skip duplicates silently."""
        a1 = _make_valid_article("same")
        a2 = _make_valid_article("same")  # same URL
        a2["title"] = "Different Title"

        self.pipeline.process_item(a1, self.spider)
        self.pipeline.process_item(a2, self.spider)
        self.pipeline._flush_batch()

        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute("SELECT COUNT(*) FROM articles")
        count = cursor.fetchone()[0]
        conn.close()

        assert count == 1  # Only first insert kept

    def test_batch_auto_flush(self):
        """Batch should auto-flush at BATCH_SIZE."""
        original_batch_size = self.pipeline.BATCH_SIZE
        self.pipeline.BATCH_SIZE = 5  # Lower for testing

        for i in range(5):
            self.pipeline.process_item(
                _make_valid_article(str(i)), self.spider
            )

        # After 5 items, batch should have auto-flushed
        assert len(self.pipeline.batch) == 0

        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute("SELECT COUNT(*) FROM articles")
        count = cursor.fetchone()[0]
        conn.close()

        assert count == 5
        self.pipeline.BATCH_SIZE = original_batch_size

    def test_close_flushes_remaining(self):
        """close_spider should flush remaining items in buffer."""
        article = _make_valid_article("final")
        self.pipeline.process_item(article, self.spider)

        # Item is in buffer, not yet flushed
        assert len(self.pipeline.batch) == 1

        self.pipeline.close_spider(self.spider)

        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute("SELECT COUNT(*) FROM articles")
        count = cursor.fetchone()[0]
        conn.close()

        assert count == 1

    def test_db_file_created(self):
        """Database file should be created on open_spider."""
        assert os.path.exists(self.db_path)

    def test_items_stored_counter(self):
        """items_stored counter should increment correctly."""
        for i in range(3):
            self.pipeline.process_item(
                _make_valid_article(str(i)), self.spider
            )
        self.pipeline._flush_batch()
        assert self.pipeline.items_stored == 3
