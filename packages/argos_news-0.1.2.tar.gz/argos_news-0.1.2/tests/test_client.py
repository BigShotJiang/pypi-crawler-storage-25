"""
ARGOS — Test Suite: Client Library
======================================
Tests for client/argos_client.py and client/exceptions.py

Covers:
  - ArgosAPIError construction and string representation
  - ArgosAPIError.from_response factory
  - ArgosClient initialization with defaults
  - ArgosClient context manager
  - ArgosClient methods (integration with test server)

Requirement refs: FR-19, C-06
"""

import pytest

from client.exceptions import ArgosAPIError


class TestArgosAPIError:
    """Tests for the ArgosAPIError exception class."""

    def test_basic_construction(self):
        """Error should store code, message, field, status_code."""
        err = ArgosAPIError(
            code="NOT_FOUND",
            message="Article not found",
            field="article_id",
            status_code=404,
        )
        assert err.code == "NOT_FOUND"
        assert err.message == "Article not found"
        assert err.field == "article_id"
        assert err.status_code == 404

    def test_str_contains_code(self):
        """String representation should contain the error code."""
        err = ArgosAPIError(code="TEST_ERROR", message="test msg")
        assert "TEST_ERROR" in str(err)
        assert "test msg" in str(err)

    def test_str_contains_field(self):
        """String representation should contain the field name."""
        err = ArgosAPIError(code="ERR", message="msg", field="name")
        assert "name" in str(err)

    def test_str_contains_status(self):
        """String representation should contain the HTTP status."""
        err = ArgosAPIError(code="ERR", message="msg", status_code=404)
        assert "404" in str(err)

    def test_defaults(self):
        """Default values should be set."""
        err = ArgosAPIError()
        assert err.code == "UNKNOWN_ERROR"
        assert err.field is None
        assert err.status_code is None

    def test_from_response(self):
        """from_response should parse API error envelope."""
        response_data = {
            "success": False,
            "error": {
                "code": "ARTICLE_NOT_FOUND",
                "message": "No article with ID 999",
                "field": "id"
            }
        }
        err = ArgosAPIError.from_response(response_data, status_code=404)
        assert err.code == "ARTICLE_NOT_FOUND"
        assert err.message == "No article with ID 999"
        assert err.field == "id"
        assert err.status_code == 404

    def test_from_response_missing_fields(self):
        """from_response should handle missing error fields gracefully."""
        response_data = {"success": False, "error": {}}
        err = ArgosAPIError.from_response(response_data)
        assert err.code == "API_ERROR"

    def test_is_exception(self):
        """ArgosAPIError should be an Exception subclass."""
        assert issubclass(ArgosAPIError, Exception)

    def test_can_be_raised_and_caught(self):
        """Should work with try/except."""
        with pytest.raises(ArgosAPIError) as exc_info:
            raise ArgosAPIError(code="TEST", message="test")
        assert exc_info.value.code == "TEST"


class TestArgosClientInit:
    """Tests for ArgosClient initialization."""

    def test_default_base_url(self):
        """Default base_url should point to DNS hostname."""
        from client.argos_client import ArgosClient
        client = ArgosClient()
        assert "argos.news.ydns.eu" in client.base_url
        client.close()

    def test_custom_base_url(self):
        """Custom base_url should be accepted."""
        from client.argos_client import ArgosClient
        client = ArgosClient(base_url="http://localhost:9000")
        assert client.base_url == "http://localhost:9000"
        client.close()

    def test_trailing_slash_stripped(self):
        """Trailing slash should be stripped from base_url."""
        from client.argos_client import ArgosClient
        client = ArgosClient(base_url="http://localhost:9000/")
        assert client.base_url == "http://localhost:9000"
        client.close()

    def test_context_manager(self):
        """Should work as a context manager."""
        from client.argos_client import ArgosClient
        with ArgosClient() as client:
            assert client.base_url is not None

    def test_timeout_setting(self):
        """Custom timeout should be stored."""
        from client.argos_client import ArgosClient
        client = ArgosClient(timeout=60)
        assert client.timeout == 60
        client.close()

    def test_connection_error_on_bad_host(self):
        """Should raise ArgosAPIError on connection failure."""
        from client.argos_client import ArgosClient
        client = ArgosClient(base_url="http://localhost:59999", timeout=1)
        with pytest.raises(ArgosAPIError) as exc_info:
            client.health_check()
        assert exc_info.value.code == "CONNECTION_ERROR"
        client.close()
