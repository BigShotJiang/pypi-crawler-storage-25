"""
ARGOS — Test Suite: Database Layer
======================================
Tests for api/database.py

Covers:
  - init_db creates table and indexes
  - _row_to_article converts rows correctly
  - query_articles with no filters
  - query_articles with each individual filter
  - query_articles pagination
  - get_article_by_id found/not-found
  - get_article_count

Requirement refs: FR-14, FR-18, FR-21
"""

import json
import os
import sqlite3
import tempfile

import pytest

from api.database import (
    _row_to_article,
    get_article_by_id,
    get_article_count,
    init_db,
    query_articles,
)


def _seed_db(db_path, articles):
    """Seed the test database with articles."""
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")

    conn.execute("""
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL DEFAULT '',
            summary TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL,
            tags TEXT NOT NULL DEFAULT '[]',
            source_name TEXT NOT NULL,
            source_url TEXT NOT NULL UNIQUE,
            published_at TEXT NOT NULL,
            scraped_at TEXT NOT NULL,
            country TEXT NOT NULL,
            orientation TEXT NOT NULL,
            trust_score REAL NOT NULL,
            is_israeli_influenced INTEGER NOT NULL DEFAULT 0
        )
    """)

    for idx, a in enumerate(articles):
        keys = [
            "idx_articles_published_at",
            "idx_articles_source_name",
            "idx_articles_country",
            "idx_articles_category",
            "idx_articles_orientation",
            "idx_articles_source_category",
        ]
        conn.execute("""
            INSERT INTO articles (
                title, content, summary, category, tags,
                source_name, source_url, published_at, scraped_at,
                country, orientation, trust_score, is_israeli_influenced
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            a.get("title", f"Article {idx}"),
            a.get("content", "Body"),
            a.get("summary", "Summary"),
            a.get("category", "politics"),
            json.dumps(a.get("tags", [])),
            a.get("source_name", "Al Jazeera"),
            a.get("source_url", f"https://example.com/{idx}"),
            a.get("published_at", "2024-01-01T00:00:00Z"),
            a.get("scraped_at", "2024-01-01T00:00:00Z"),
            a.get("country", "Qatar"),
            a.get("orientation", "center-left"),
            a.get("trust_score", 0.55),
            1 if a.get("is_israeli_influenced", False) else 0,
        ))

    conn.commit()

    # Create indexes
    for sql in [
        "CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles (published_at)",
        "CREATE INDEX IF NOT EXISTS idx_articles_source_name ON articles (source_name)",
        "CREATE INDEX IF NOT EXISTS idx_articles_country ON articles (country)",
        "CREATE INDEX IF NOT EXISTS idx_articles_category ON articles (category)",
        "CREATE INDEX IF NOT EXISTS idx_articles_orientation ON articles (orientation)",
        "CREATE INDEX IF NOT EXISTS idx_articles_source_category ON articles (source_name, category)",
    ]:
        conn.execute(sql)
    conn.commit()
    conn.close()


@pytest.fixture(autouse=True)
def setup_test_db(tmp_path):
    """Create a temp DB and point settings to it for each test."""
    db_path = str(tmp_path / "test_argos.db")
    os.environ["DATABASE_PATH"] = db_path

    # Clear the cached settings so each test gets fresh config
    from api.config import get_settings
    get_settings.cache_clear()

    # Seed with test data: 3 articles from different sources
    articles = [
        {
            "title": "Peace Talks Resume in Cairo",
            "source_name": "Al Jazeera",
            "source_url": "https://aljazeera.com/news/1",
            "category": "politics",
            "country": "Qatar",
            "orientation": "center-left",
            "trust_score": 0.55,
            "is_israeli_influenced": False,
            "published_at": "2024-03-12T09:00:00Z",
            "tags": ["ceasefire", "Egypt"],
        },
        {
            "title": "Oil Prices Surge",
            "source_name": "Al Arabiya",
            "source_url": "https://alarabiya.net/economy/2",
            "category": "economy",
            "country": "Saudi Arabia",
            "orientation": "right",
            "trust_score": 0.40,
            "is_israeli_influenced": True,
            "published_at": "2024-03-11T10:00:00Z",
            "tags": ["oil", "economy"],
        },
        {
            "title": "Tech Innovation Summit",
            "source_name": "Middle East Eye",
            "source_url": "https://middleeasteye.net/news/3",
            "category": "tech",
            "country": "UK (ME Focus)",
            "orientation": "left",
            "trust_score": 0.48,
            "is_israeli_influenced": False,
            "published_at": "2024-03-10T08:00:00Z",
            "tags": ["technology"],
        },
    ]
    _seed_db(db_path, articles)

    yield db_path

    # Cleanup
    if os.path.exists(db_path):
        os.remove(db_path)


@pytest.mark.asyncio
class TestInitDb:
    """Tests for init_db()."""

    async def test_creates_table(self, setup_test_db):
        """init_db should create the articles table."""
        await init_db()
        # Table should exist (it was already seeded, but init_db is idempotent)
        conn = sqlite3.connect(setup_test_db)
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='articles'"
        )
        assert cursor.fetchone() is not None
        conn.close()


@pytest.mark.asyncio
class TestQueryArticles:
    """Tests for query_articles()."""

    async def test_no_filters_returns_all(self):
        """No filters should return all articles."""
        result = await query_articles()
        assert result["pagination"]["total_results"] == 3

    async def test_filter_by_source_name(self):
        """source_name filter should narrow results."""
        result = await query_articles(source_name="Al Jazeera")
        assert result["pagination"]["total_results"] == 1
        assert result["articles"][0]["source_name"] == "Al Jazeera"

    async def test_filter_by_country(self):
        """country filter should narrow results."""
        result = await query_articles(country="Qatar")
        assert result["pagination"]["total_results"] == 1

    async def test_filter_by_category(self):
        """category filter should narrow results."""
        result = await query_articles(category="economy")
        assert result["pagination"]["total_results"] == 1
        assert result["articles"][0]["category"] == "economy"

    async def test_filter_by_orientation(self):
        """orientation filter should narrow results."""
        result = await query_articles(orientation="right")
        assert result["pagination"]["total_results"] == 1

    async def test_filter_by_israeli_influenced(self):
        """is_israeli_influenced filter should work."""
        result = await query_articles(is_israeli_influenced=True)
        assert result["pagination"]["total_results"] == 1
        assert result["articles"][0]["is_israeli_influenced"] is True

    async def test_filter_by_date_range(self):
        """Date range filter should narrow results."""
        result = await query_articles(
            date_from="2024-03-11T00:00:00Z",
            date_to="2024-03-12T23:59:59Z"
        )
        assert result["pagination"]["total_results"] == 2

    async def test_filter_by_title(self):
        """Title search should do partial matching."""
        result = await query_articles(title="Peace")
        assert result["pagination"]["total_results"] == 1
        assert "Peace" in result["articles"][0]["title"]

    async def test_filter_by_tags(self):
        """Tag filter should match articles containing the tag."""
        result = await query_articles(tags=["oil"])
        assert result["pagination"]["total_results"] == 1

    async def test_pagination(self):
        """Pagination should respect page and page_size."""
        result = await query_articles(page=1, page_size=2)
        assert len(result["articles"]) == 2
        assert result["pagination"]["has_next"] is True

        result2 = await query_articles(page=2, page_size=2)
        assert len(result2["articles"]) == 1
        assert result2["pagination"]["has_next"] is False

    async def test_sort_order_desc(self):
        """Default sort should be published_at DESC."""
        result = await query_articles(sort_by="published_at", order="desc")
        dates = [a["published_at"] for a in result["articles"]]
        assert dates == sorted(dates, reverse=True)

    async def test_sort_order_asc(self):
        """Ascending sort should work."""
        result = await query_articles(sort_by="published_at", order="asc")
        dates = [a["published_at"] for a in result["articles"]]
        assert dates == sorted(dates)

    async def test_page_size_capped(self):
        """page_size > 100 should be capped to 100."""
        result = await query_articles(page_size=500)
        assert result["pagination"]["page_size"] == 100

    async def test_invalid_sort_column_defaults(self):
        """Invalid sort_by should default to published_at."""
        result = await query_articles(sort_by="DROP TABLE articles")
        assert result["pagination"]["total_results"] == 3  # Still works


@pytest.mark.asyncio
class TestGetArticleById:
    """Tests for get_article_by_id()."""

    async def test_found(self):
        """Existing ID should return an article."""
        article = await get_article_by_id(1)
        assert article is not None
        assert article["id"] == 1
        assert "title" in article

    async def test_not_found(self):
        """Non-existing ID should return None."""
        article = await get_article_by_id(99999)
        assert article is None

    async def test_tags_deserialized(self):
        """Tags should be deserialized from JSON to list."""
        article = await get_article_by_id(1)
        assert isinstance(article["tags"], list)

    async def test_bool_converted(self):
        """is_israeli_influenced should be a Python bool."""
        article = await get_article_by_id(1)
        assert isinstance(article["is_israeli_influenced"], bool)


@pytest.mark.asyncio
class TestGetArticleCount:
    """Tests for get_article_count()."""

    async def test_count_matches(self):
        """Count should match the number of seeded articles."""
        count = await get_article_count()
        assert count == 3
