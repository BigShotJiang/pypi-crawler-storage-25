"""
ARGOS — Test Suite: API Models
==================================
Tests for api/models.py

Covers:
  - ArticleOut serialization with all 13 fields
  - PaginationMeta fields and navigation flags
  - ArticleListResponse envelope structure
  - SingleArticleResponse envelope
  - SourceOut fields
  - HealthResponse fields
  - ErrorDetail and ErrorResponse

Requirement refs: FR-20, FR-21
"""

import pytest

from api.models import (
    ArticleListResponse,
    ArticleOut,
    ErrorDetail,
    ErrorResponse,
    HealthResponse,
    PaginationMeta,
    SingleArticleResponse,
    SourceListResponse,
    SourceOut,
)


def _make_article_data():
    """Helper: article data dict matching ArticleOut."""
    return {
        "id": 1,
        "title": "Test Article",
        "content": "Full body text.",
        "summary": "Brief summary.",
        "category": "politics",
        "tags": ["test", "article"],
        "source_name": "Al Jazeera",
        "source_url": "https://aljazeera.com/test",
        "published_at": "2024-01-01T09:00:00Z",
        "scraped_at": "2024-01-01T09:15:00Z",
        "country": "Qatar",
        "orientation": "center-left",
        "trust_score": 0.55,
        "is_israeli_influenced": False,
    }


class TestArticleOut:
    """Tests for ArticleOut Pydantic model."""

    def test_valid_article_serializes(self):
        """A fully valid article should serialize correctly."""
        article = ArticleOut(**_make_article_data())
        assert article.title == "Test Article"
        assert article.trust_score == 0.55
        assert article.is_israeli_influenced is False

    def test_tags_default_empty_list(self):
        """Tags should default to empty list if not provided."""
        data = _make_article_data()
        data.pop("tags")
        article = ArticleOut(**data)
        assert article.tags == []

    def test_to_dict(self):
        """model_dump() should produce a dict with all fields."""
        article = ArticleOut(**_make_article_data())
        d = article.model_dump()
        assert len(d) == 14  # 13 data fields + id
        assert "title" in d
        assert "is_israeli_influenced" in d

    def test_json_serialization(self):
        """model_dump_json() should produce valid JSON."""
        article = ArticleOut(**_make_article_data())
        json_str = article.model_dump_json()
        assert "Test Article" in json_str
        assert "0.55" in json_str


class TestPaginationMeta:
    """Tests for PaginationMeta model."""

    def test_basic_pagination(self):
        """Should serialize basic pagination fields."""
        p = PaginationMeta(
            page=1, page_size=20, total_results=100,
            total_pages=5, has_next=True, has_prev=False
        )
        assert p.page == 1
        assert p.total_pages == 5
        assert p.has_next is True
        assert p.has_prev is False

    def test_first_page_flags(self):
        """First page should have has_prev=False."""
        p = PaginationMeta(
            page=1, page_size=20, total_results=50,
            total_pages=3, has_next=True, has_prev=False
        )
        assert p.has_prev is False

    def test_last_page_flags(self):
        """Last page should have has_next=False."""
        p = PaginationMeta(
            page=3, page_size=20, total_results=50,
            total_pages=3, has_next=False, has_prev=True
        )
        assert p.has_next is False


class TestResponseEnvelopes:
    """Tests for response envelope models."""

    def test_article_list_response(self):
        """ArticleListResponse should wrap articles and pagination."""
        articles = [ArticleOut(**_make_article_data())]
        pagination = PaginationMeta(
            page=1, page_size=20, total_results=1,
            total_pages=1, has_next=False, has_prev=False
        )
        resp = ArticleListResponse(
            success=True, data=articles, pagination=pagination
        )
        assert resp.success is True
        assert len(resp.data) == 1
        assert resp.pagination.total_results == 1

    def test_single_article_response(self):
        """SingleArticleResponse should wrap one article."""
        article = ArticleOut(**_make_article_data())
        resp = SingleArticleResponse(success=True, data=article)
        assert resp.success is True
        assert resp.data.title == "Test Article"

    def test_error_response(self):
        """ErrorResponse should contain error details."""
        error = ErrorDetail(
            code="NOT_FOUND", message="Article not found", field="id"
        )
        resp = ErrorResponse(success=False, error=error)
        assert resp.success is False
        assert resp.error.code == "NOT_FOUND"
        assert resp.error.field == "id"


class TestSourceOut:
    """Tests for SourceOut model."""

    def test_source_serialization(self):
        """SourceOut should serialize all registry fields."""
        source = SourceOut(
            domain="aljazeera.com",
            source_name="Al Jazeera",
            country="Qatar",
            orientation="center-left",
            trust_score=0.55,
            is_israeli_influenced=False,
        )
        assert source.domain == "aljazeera.com"
        assert source.trust_score == 0.55


class TestHealthResponse:
    """Tests for HealthResponse model."""

    def test_health_serialization(self):
        """HealthResponse should include all status fields."""
        h = HealthResponse(
            status="ok", db_connected=True,
            uptime_seconds=120, article_count=42, version="0.1.0"
        )
        assert h.status == "ok"
        assert h.db_connected is True
        assert h.article_count == 42
