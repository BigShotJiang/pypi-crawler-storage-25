# ============================================================================
# ARGOS Client Package
# ============================================================================
# Python client library for interacting with the ARGOS API.
#
# Usage:
#   from client import ArgosClient
#   client = ArgosClient()  # connects to argos.news.ydns.eu by default
#   articles = client.get_latest(count=10)
#
# The client hides all HTTP/serialization details (C-06).
# Users call functions with named parameters and get back Python dicts.
#
# Modules:
#   - argos_client.py — ArgosClient class with all query methods
#   - exceptions.py   — ArgosAPIError for structured error handling
#
# Requirement refs: FR-19, C-06
# ============================================================================

from client.argos_client import ArgosClient
from client.exceptions import ArgosAPIError

__all__ = ["ArgosClient", "ArgosAPIError"]
