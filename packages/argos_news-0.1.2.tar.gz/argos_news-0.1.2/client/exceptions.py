"""
ARGOS — Client Exceptions
============================
Custom exception classes for the ARGOS Python client.

ArgosAPIError is raised when:
  1. The API returns a non-2xx HTTP status code
  2. The response body contains {"success": false, "error": {...}}
  3. The request itself fails (network error, timeout)

The exception carries structured information from the API's error
envelope, making it easy for callers to handle specific error types.

Usage:
    from client import ArgosClient, ArgosAPIError

    client = ArgosClient()
    try:
        article = client.get_article(article_id=99999)
    except ArgosAPIError as e:
        print(f"Error {e.code}: {e.message}")
        if e.field:
            print(f"  Related field: {e.field}")

Requirement refs: C-06
"""


class ArgosAPIError(Exception):
    """
    Raised when an ARGOS API request fails.

    Carries structured error information from the API's error envelope.
    If the error doesn't come from the API (e.g., network failure),
    code defaults to "CONNECTION_ERROR" and field is None.

    Attributes:
        code (str): Machine-readable error code.
            Examples: "ARTICLE_NOT_FOUND", "VALIDATION_ERROR",
                     "INTERNAL_ERROR", "CONNECTION_ERROR"
        message (str): Human-readable error description.
        field (str | None): Optional field name related to the error.
            Set for validation errors (e.g., "article_id").
        status_code (int | None): HTTP status code if available.
    """

    def __init__(
        self,
        code: str = "UNKNOWN_ERROR",
        message: str = "An unknown error occurred",
        field: str | None = None,
        status_code: int | None = None,
    ):
        # Store structured error info as instance attributes.
        # These are the primary way callers inspect the error.
        self.code = code
        self.message = message
        self.field = field
        self.status_code = status_code

        # Build a human-readable string for str(error) and logging.
        # Format: "[CODE] message (field: field_name, HTTP 404)"
        parts = [f"[{code}] {message}"]
        if field:
            parts.append(f"(field: {field})")
        if status_code:
            parts.append(f"(HTTP {status_code})")

        super().__init__(" ".join(parts))

    @classmethod
    def from_response(cls, response_data: dict, status_code: int = None):
        """
        Creates an ArgosAPIError from an API error response body.

        Parses the standard error envelope:
            {"success": false, "error": {"code": "...", "message": "...", "field": "..."}}

        Args:
            response_data: The parsed JSON response body.
            status_code: The HTTP status code of the response.

        Returns:
            ArgosAPIError: With code, message, and field extracted.
        """
        error = response_data.get("error", {})
        return cls(
            code=error.get("code", "API_ERROR"),
            message=error.get("message", "API returned an error"),
            field=error.get("field"),
            status_code=status_code,
        )
