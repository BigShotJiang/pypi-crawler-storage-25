"""
ARGOS — Python Client Library
================================
ArgosClient provides a clean, Pythonic interface to the ARGOS API.

The client hides all HTTP/serialization details (C-06). Users call
functions with named parameters and get back Python dicts — no raw
HTTP, no URL construction, no JSON parsing.

The default base_url points to argos.news.ydns.eu:8000 — the DNS
hostname for the ARGOS home server. Users don't need to know or
configure this — they just import and use.

Usage:
    from client import ArgosClient

    # Default: connects to argos.news.ydns.eu automatically
    client = ArgosClient()

    # Get latest 10 articles
    latest = client.get_latest(count=10)
    for article in latest:
        print(article["title"])

    # Search with filters
    results = client.get_articles(
        source_name="Al Jazeera",
        category="war",
        date_from="2024-01-01",
    )
    for article in results["articles"]:
        print(f"{article['published_at']}: {article['title']}")

    # Get a single article by ID
    article = client.get_article(article_id=42)

    # List available sources
    sources = client.get_sources()

Requirement refs: FR-19, C-06
"""

import httpx

from client.exceptions import ArgosAPIError


# Default API base URL — hardcoded to the ARGOS DNS hostname.
# Users never need to configure this unless they're running a
# local development server.
_DEFAULT_BASE_URL = "http://argos.news.ydns.eu"


class ArgosClient:
    """
    Python client for the ARGOS news API.

    Provides named-parameter function calls that return structured data.
    All HTTP details are hidden — callers never see URLs, headers, or JSON.

    The client uses httpx for HTTP requests, which supports both
    sync and async patterns. This implementation is synchronous
    for simplicity — most downstream use cases are scripts and agents.

    Attributes:
        base_url: The API base URL (default: argos.news.ydns.eu).
        timeout: Request timeout in seconds (default: 30).
    """

    def __init__(
        self,
        base_url: str = _DEFAULT_BASE_URL,
        api_key: str | None = None,
        timeout: int = 30,
    ):
        """
        Initialize the ARGOS client.

        Args:
            base_url: API base URL. Defaults to the ARGOS DNS hostname.
                Override with "http://localhost:8000" for local development.
            api_key: Optional API key for future authentication.
                Not required in v0.1.0.
            timeout: Request timeout in seconds. 30s is generous enough
                for paginated queries over slow connections.
        """
        # Strip trailing slash to avoid double-slash in URL construction.
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        # Build default headers. API key is included if provided.
        self._headers = {
            "Accept": "application/json",
            "User-Agent": "ArgosClient/0.1.0",
        }
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"

        # Create an httpx client for connection pooling and reuse.
        # This is more efficient than creating a new connection per request.
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self._headers,
            timeout=timeout,
        )

    def __del__(self):
        """Close the HTTP client when the ArgosClient is garbage collected."""
        try:
            self._client.close()
        except Exception:
            pass

    def close(self):
        """
        Explicitly close the HTTP client.

        Call this when you're done using the client to free resources.
        Also supports context manager usage:
            with ArgosClient() as client:
                articles = client.get_latest()
        """
        self._client.close()

    def __enter__(self):
        """Context manager entry — returns self."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit — closes the client."""
        self.close()
        return False

    # ====================================================================
    # Public API Methods
    # ====================================================================

    def get_articles(
        self,
        *,
        source_name: str | None = None,
        country: str | None = None,
        category: str | None = None,
        orientation: str | None = None,
        is_israeli_influenced: bool | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        title: str | None = None,
        tags: list[str] | None = None,
        page: int = 1,
        page_size: int = 20,
        sort_by: str = "published_at",
        order: str = "desc",
    ) -> dict:
        """
        Search articles with optional filters.

        All parameters are optional and keyword-only (C-06).
        Filters combine with AND logic — more filters = narrower results.
        Tags combine with AND — article must have ALL specified tags.

        Args:
            source_name: Filter by news network (e.g., "Al Jazeera").
            country: Filter by source country (e.g., "Qatar").
            category: Filter by topic (e.g., "politics", "war").
            orientation: Filter by editorial leaning (e.g., "left").
            is_israeli_influenced: Filter by Israeli influence flag.
            date_from: Minimum published date (ISO 8601).
            date_to: Maximum published date (ISO 8601).
            title: Search title text (partial match).
            tags: List of tags (AND logic).
            page: Page number (default 1).
            page_size: Items per page (default 20, max 100).
            sort_by: Sort column (default "published_at").
            order: Sort direction "asc" or "desc" (default "desc").

        Returns:
            dict: {
                "articles": [list of article dicts with 13 fields],
                "pagination": {
                    "page": int, "page_size": int,
                    "total_results": int, "total_pages": int,
                    "has_next": bool, "has_prev": bool
                }
            }

        Raises:
            ArgosAPIError: On API errors or network failures.

        Requirement refs: FR-18, FR-19, C-06
        """
        # Build query parameters — only include non-None values.
        params = {}
        if source_name is not None:
            params["source_name"] = source_name
        if country is not None:
            params["country"] = country
        if category is not None:
            params["category"] = category
        if orientation is not None:
            params["orientation"] = orientation
        if is_israeli_influenced is not None:
            params["is_israeli_influenced"] = str(is_israeli_influenced).lower()
        if date_from is not None:
            params["date_from"] = date_from
        if date_to is not None:
            params["date_to"] = date_to
        if title is not None:
            params["title"] = title
        if tags is not None:
            # Join tags into comma-separated string for the API.
            params["tags"] = ",".join(tags)
        params["page"] = page
        params["page_size"] = page_size
        params["sort_by"] = sort_by
        params["order"] = order

        response_data = self._request("GET", "/v1/articles", params=params)

        return {
            "articles": response_data.get("data", []),
            "pagination": response_data.get("pagination", {}),
        }

    def get_latest(self, count: int = 20) -> list[dict]:
        """
        Get the N most recently published articles.

        Convenience method — no filters required. Returns a simple
        list of article dicts, not the full envelope.

        Args:
            count: Number of articles to return (default 20, max 100).

        Returns:
            list[dict]: List of article dicts, newest first.

        Raises:
            ArgosAPIError: On API errors or network failures.
        """
        response_data = self._request(
            "GET", "/v1/articles/latest",
            params={"count": count}
        )
        return response_data.get("data", [])

    def get_article(self, article_id: int) -> dict:
        """
        Get a single article by its database ID.

        Args:
            article_id: Integer primary key of the article.

        Returns:
            dict: Article data with all 13 fields.

        Raises:
            ArgosAPIError: If the article doesn't exist (code: ARTICLE_NOT_FOUND)
                          or on other API errors.
        """
        response_data = self._request(
            "GET", f"/v1/articles/{article_id}"
        )
        return response_data.get("data", {})

    def get_sources(self) -> list[dict]:
        """
        Get all registered source networks.

        Returns the full SOURCE_REGISTRY — useful for discovering
        available filter values (source names, countries, orientations).

        Returns:
            list[dict]: List of source dicts with domain, source_name,
                       country, orientation, trust_score, is_israeli_influenced.

        Raises:
            ArgosAPIError: On API errors or network failures.
        """
        response_data = self._request("GET", "/v1/sources")
        return response_data.get("data", [])

    def health_check(self) -> dict:
        """
        Check if the ARGOS API is running and the database is connected.

        Returns:
            dict: {
                "status": "ok",
                "db_connected": bool,
                "uptime_seconds": int,
                "article_count": int,
                "version": str
            }

        Raises:
            ArgosAPIError: If the API is unreachable.
        """
        return self._request("GET", "/v1/health")

    # ====================================================================
    # Internal Methods
    # ====================================================================

    def _request(self, method: str, path: str, params: dict = None) -> dict:
        """
        Makes an HTTP request to the ARGOS API.

        Handles:
          - Sending the request with proper headers and params
          - Parsing the JSON response
          - Detecting error responses (success=false or non-2xx status)
          - Raising ArgosAPIError on any failure

        This method is internal — callers should use the public methods
        (get_articles, get_latest, get_article, get_sources).

        Args:
            method: HTTP method (GET, POST, etc.)
            path: API path (e.g., "/v1/articles")
            params: Optional query parameters dict.

        Returns:
            dict: The parsed JSON response body.

        Raises:
            ArgosAPIError: On any error (network, HTTP, API).
        """
        try:
            response = self._client.request(
                method=method,
                url=path,
                params=params,
            )
        except httpx.ConnectError as e:
            raise ArgosAPIError(
                code="CONNECTION_ERROR",
                message=f"Failed to connect to ARGOS API at {self.base_url}: {e}",
            )
        except httpx.TimeoutException as e:
            raise ArgosAPIError(
                code="TIMEOUT_ERROR",
                message=f"Request to {path} timed out after {self.timeout}s",
            )
        except httpx.HTTPError as e:
            raise ArgosAPIError(
                code="HTTP_ERROR",
                message=f"HTTP error during request to {path}: {e}",
            )

        return self._handle_response(response)

    def _handle_response(self, response) -> dict:
        """
        Processes an HTTP response from the API.

        Checks for:
          1. Non-2xx status codes → raise ArgosAPIError
          2. Response body with success=false → raise ArgosAPIError
          3. Non-JSON responses → raise ArgosAPIError

        On success, returns the parsed JSON body.

        Args:
            response: httpx.Response object.

        Returns:
            dict: Parsed JSON response body.

        Raises:
            ArgosAPIError: If the response indicates an error.
        """
        # Try to parse JSON regardless of status code.
        # The API always returns JSON, even for errors.
        try:
            data = response.json()
        except Exception:
            raise ArgosAPIError(
                code="PARSE_ERROR",
                message=f"Could not parse API response as JSON (HTTP {response.status_code})",
                status_code=response.status_code,
            )

        # Check for HTTP errors (4xx, 5xx).
        if response.status_code >= 400:
            raise ArgosAPIError.from_response(data, response.status_code)

        # Check for API-level errors (success=false in body).
        if isinstance(data, dict) and data.get("success") is False:
            raise ArgosAPIError.from_response(data, response.status_code)

        return data
