# ============================================================================
# ARGOS API Package
# ============================================================================
# FastAPI REST layer — Layer 3 of the ARGOS architecture.
# Provides queryable endpoints for articles stored in the local SQLite DB.
#
# The API is served via uvicorn and exposed on the home server at
# argos.news.ydns.eu:8000 (configurable via .env).
#
# Modules:
#   - main.py      — App entry point, route registration, CORS, error handling
#   - config.py    — Pydantic settings from environment variables
#   - database.py  — Async SQLite connection + query helpers
#   - models.py    — Pydantic response models (ArticleOut, pagination, errors)
#
# Sub-package:
#   - routes/      — Endpoint definitions (articles, sources, health)
#
# Requirement refs: FR-17, FR-18, FR-20, FR-21
# ============================================================================
