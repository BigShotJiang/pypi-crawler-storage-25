"""
ARGOS — API Configuration
===========================
Pydantic Settings for type-safe environment variable loading.

Uses pydantic-settings to read from .env file and environment variables.
Every field has a description and sensible default.

The Settings class is a singleton — created once at startup and
shared across all API modules via get_settings().

Fields:
  - DATABASE_PATH: Path to SQLite database file
  - API_HOST: Network interface to bind to (default 0.0.0.0)
  - API_PORT: Port number (default 8000)
  - API_BASE_URL: Public URL for the API (used by client)
  - API_SECRET_KEY: Optional auth key (reserved for future use)
  - LOG_LEVEL: Logging verbosity
"""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.

    Reads from .env file automatically. Environment variables
    override .env values (standard 12-factor app behavior).
    """

    # --- Database ---

    # Path to the SQLite database file.
    # Can be absolute or relative to the working directory.
    # The file and parent directories are created automatically
    # by the storage pipeline on first spider run.
    DATABASE_PATH: str = "./data/argos.db"

    # --- Server ---

    # Network interface to bind to.
    # "0.0.0.0" = listen on all interfaces (required for external access).
    # "127.0.0.1" = local only (use behind a reverse proxy like nginx).
    API_HOST: str = "0.0.0.0"

    # Port number.
    # Default 8000 is the uvicorn/FastAPI convention.
    API_PORT: int = 8000

    # Public URL where the API is accessible.
    # Hardcoded in the client library as the default connection target.
    # Should match the DNS hostname pointing to the home server.
    API_BASE_URL: str = "http://argos.news.ydns.eu:8000"

    # --- Security ---

    # Optional API key for future authentication features.
    # Not enforced in v0.1.0 — placeholder for forward compatibility.
    API_SECRET_KEY: str = ""

    # --- Logging ---

    # Verbosity: DEBUG, INFO, WARNING, ERROR, CRITICAL
    LOG_LEVEL: str = "INFO"

    # --- Pydantic Settings Config ---
    # Tells pydantic-settings to read from .env file and use
    # case-insensitive matching for env variable names.
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        # Allow extra env vars (JOBDIR, PROXY_URL, etc.) that are used
        # by Scrapy settings but not by the API config. Without this,
        # pydantic-settings raises a ValidationError for unknown keys.
        extra="ignore",
    )


@lru_cache()
def get_settings() -> Settings:
    """
    Returns a cached Settings instance.

    Uses @lru_cache so the settings are only loaded once from disk,
    regardless of how many times this function is called.
    This is the standard FastAPI pattern for dependency injection.

    Usage in routes:
        from api.config import get_settings
        settings = get_settings()
        db_path = settings.DATABASE_PATH
    """
    return Settings()
