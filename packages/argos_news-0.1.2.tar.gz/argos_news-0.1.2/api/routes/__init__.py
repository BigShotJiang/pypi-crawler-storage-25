# ============================================================================
# ARGOS API Routes Package
# ============================================================================
# Contains all FastAPI route modules:
#   - health.py    — GET /v1/health (system status, no auth)
#   - sources.py   — GET /v1/sources (registry data)
#   - articles.py  — GET /v1/articles, /latest, /{id} (core query endpoints)
#
# All routes return consistent envelope responses:
#   Success: {"success": true, "data": ..., "pagination": ...}
#   Error:   {"success": false, "error": {"code": ..., "message": ...}}
#
# Requirement refs: FR-17, FR-18, FR-20, FR-21
# ============================================================================
