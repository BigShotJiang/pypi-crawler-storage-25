"""
ARGOS — Client Documentation Route
================================
GET /client-docs — Detailed Python client usage HTML guide.

Serves a fully styled documentation page explaining how to install,
configure, and use the ArgosClient with zero configuration.
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from api.routes.ui import _SHARED_CSS, _SHARED_SIDEBAR

router = APIRouter()

@router.get(
    "/client-docs",
    response_class=HTMLResponse,
    summary="Client documentation UI",
    include_in_schema=False,
)
async def client_docs():
    """Serves the themed Python client guide HTML page."""
    return _CLIENT_DOCS_HTML


_CLIENT_DOCS_HTML = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Client Guide — ARGOS</title>
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
    <style>
        {_SHARED_CSS}

        .highlight-box {{
            background: rgba(99, 102, 241, 0.1);
            border-left: 4px solid var(--accent-primary);
            padding: 16px 20px;
            margin: 24px 0;
            border-radius: 0 8px 8px 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        .highlight-box p {{ margin: 0; font-size: 14px; line-height: 1.6; color: var(--text-main); }}

        h2 {{ margin-top: 48px; margin-bottom: 20px; font-size: 24px; color: var(--text-heading); font-weight: 600; padding-bottom: 8px; border-bottom: 1px solid var(--border-color); }}
        h3 {{ color: var(--accent-primary); font-family: 'Fira Code', monospace; font-size: 16px; margin-bottom: 12px; }}
        h4 {{ color: var(--text-heading); font-size: 14px; margin-top: 24px; margin-bottom: 12px; }}

        pre.code-block {{
            background: #0d1117;
            padding: 24px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            color: #c9d1d9;
            font-family: 'Fira Code', monospace;
            font-size: 13px;
            overflow-x: auto;
            margin-bottom: 24px;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.5);
            line-height: 1.5;
        }}
        .code-block .keyword {{ color: #ff7b72; }}
        .code-block .string {{ color: #a5d6ff; }}
        .code-block .comment {{ color: #8b949e; font-style: italic; }}
        .code-block .func {{ color: #d2a8ff; }}
        .code-block .class {{ color: #79c0ff; }}

        .method-card {{
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 32px;
            margin-bottom: 32px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }}
        .method-card p {{ font-size: 14px; color: var(--text-main); margin-bottom: 16px; line-height: 1.6; }}
        
        table.args-table {{ width: 100%; border-collapse: collapse; margin-top: 16px; }}
        table.args-table th {{ background: var(--surface-alt); padding: 10px 16px; border-bottom: 2px solid var(--border-color); text-align: left; font-size: 12px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }}
        table.args-table td {{ padding: 12px 16px; border-bottom: 1px solid var(--border-color); font-size: 13px; color: var(--text-main); }}
        table.args-table tr:last-child td {{ border-bottom: none; }}
        
        .badge-type {{ display: inline-block; background: var(--surface-alt); border: 1px solid var(--border-color); border-radius: 4px; padding: 2px 6px; font-family: 'Fira Code', monospace; font-size: 11px; color: var(--accent-2); }}
    </style>
</head>
<body>
    {_SHARED_SIDEBAR.replace('href="/client-docs" class="nav-link"', 'href="/client-docs" class="nav-link active"')}

    <main class="main-col">
        <header class="topbar">
            <div class="breadcrumb">
                ARGOS / Documentation / <span>Python Client</span>
            </div>
        </header>

        <div class="content">
            <h1 class="page-title"><i class="fa-brands fa-python" style="margin-right: 12px; color: var(--accent-primary);"></i>ArgosClient Operations Manual</h1>
            <p class="lead">
                The <code>argos-news</code> Python library entirely abstracts away HTTP orchestration, URL building, and automated pagination loop mechanisms. It provides pure Pydantic dataclasses for seamless, typed interaction with the ARGOS Middle Eastern dataset.
            </p>

            <div class="highlight-box">
                <p><strong><i class="fa-solid fa-server" style="margin-right: 8px;"></i>Zero Configuration Required!</strong> By default, <code>ArgosClient</code> automatically hooks into the production load balancer at <code>argos.news.ydns.eu</code> instantly. You do not need API environment variables to use this unless you are testing a local docker container.</p>
            </div>

            <h2>Installation</h2>
            <p style="margin-bottom: 12px; font-size: 14px;">The package is distributed officially via PyPI and is compatible with Python 3.9+.</p>
            <pre class="code-block" style="color: #a5d6ff;">pip install argos-news</pre>

            <h2>Authentication & Global Setup</h2>
            <pre class="code-block">
<span class="keyword">from</span> client.argos_client <span class="keyword">import</span> ArgosClient

<span class="comment"># Instantiating the client handles all reverse-proxying implicitly</span>
client = <span class="class">ArgosClient</span>()

<span class="comment"># Optional: Connect to your own internal instance if running locally</span>
local_client = <span class="class">ArgosClient</span>(base_url=<span class="string">"http://localhost:8000"</span>)
            </pre>

            <h2>Core Data Methods</h2>

            <!-- GET ARTICLES -->
            <div class="method-card">
                <h3>get_articles(**kwargs) -> List[ArticleResponse]</h3>
                <p>
                    The primary query engine. It executes a remote search query and <strong>automatically resolves cursor pagination</strong> behind the scenes, continually requesting chunks from the API until it has accumulated the exact `limit` you requested. 
                </p>
                
                <h4>Parameters</h4>
                <table class="args-table">
                    <thead><tr><th>Parameter</th><th>Type</th><th>Description</th></tr></thead>
                    <tbody>
                        <tr><td><span class="badge-type">limit</span></td><td>int</td><td>Target number of rows to accumulate and return. Default is <code>100</code>. Pass <code>None</code> to disable truncation (Warning: Memory heavy).</td></tr>
                        <tr><td><span class="badge-type">title</span></td><td>str</td><td>Fuzzy match on headline strings inside the SQLite DB. Case insensitive.</td></tr>
                        <tr><td><span class="badge-type">category</span></td><td>str</td><td>Restrict by topic. Valid enums: <code>war</code>, <code>politics</code>, <code>economy</code>, <code>tech</code>, <code>culture</code>, <code>sports</code>, <code>health</code>.</td></tr>
                        <tr><td><span class="badge-type">source_name</span></td><td>str</td><td>Network exact match (e.g. <code>"Al Jazeera"</code> or <code>"Sky News Arabia"</code>).</td></tr>
                        <tr><td><span class="badge-type">country</span></td><td>str</td><td>Filter by the sovereign host nation of the network (e.g. <code>"Qatar"</code>).</td></tr>
                        <tr><td><span class="badge-type">tag</span></td><td>str</td><td>Requires the string to exist inside the embedded JSON tags array.</td></tr>
                        <tr><td><span class="badge-type">start_date</span></td><td>str</td><td>Boundary string for historical crawls (format: <code>"YYYY-MM-DD"</code>). Extracts articles published entirely on or after this UTC window.</td></tr>
                        <tr><td><span class="badge-type">end_date</span></td><td>str</td><td>Boundary string for historical crawls (format: <code>"YYYY-MM-DD"</code>). Extracted published on or before this day.</td></tr>
                    </tbody>
                </table>

                <h4>Implementation Example</h4>
                <pre class="code-block" style="margin-top: 24px;">
<span class="keyword">for</span> article <span class="keyword">in</span> client.<span class="func">get_articles</span>(
    category=<span class="string">"war"</span>,
    source_name=<span class="string">"Sky News Arabia"</span>,
    start_date=<span class="string">"2023-10-01"</span>,
    limit=<span class="string">25</span>
):
    <span class="func">print</span>(<span class="string">f"Headline: {{article.title}}"</span>)
    <span class="func">print</span>(<span class="string">f"Bias: {{article.orientation}} | Trust Index: {{article.trust_score}}"</span>)
    <span class="func">print</span>(<span class="string">f"{{article.summary}} \n"</span>)
                </pre>
            </div>

            <!-- GET ARTICLE BY ID -->
            <div class="method-card">
                <h3>get_article_by_id(article_id: str) -> ArticleResponse</h3>
                <p>Fetches the absolute database schema for a single known UUID. Typically used when responding to a webhook pipeline where only ID keys are transported.</p>
                <pre class="code-block" style="margin-top: 16px;">
record = client.<span class="func">get_article_by_id</span>(<span class="string">"4f9c8d1-5e2b..."</span>)
<span class="func">print</span>(record.content)
                </pre>
            </div>

            <!-- GET SOURCES -->
            <div class="method-card">
                <h3>get_sources() -> List[SourceMetadata]</h3>
                <p>Retrieves the immutable authoritative registry defining tracking parameters, topological influence rules, and numeric trust index mappings configured in the ARGOS system.</p>
            </div>

            <h2>Error Handling Architecture</h2>
            <p style="margin-bottom: 24px; font-size: 14px; line-height: 1.6;">
                The client avoids silently failing. Every HTTP failure mode throws a dedicated Python exception subclass. Use <code>try/except</code> blocks to safely execute long-running historical scrape jobs without crashing mid-execution.
            </p>
            <pre class="code-block">
<span class="keyword">from</span> client.exceptions <span class="keyword">import</span> ArgosConnectionError, ArgosAPIError, ArgosNotFoundError

<span class="keyword">try</span>:
    res = client.<span class="func">get_article_by_id</span>(<span class="string">"invalid-hash"</span>)
<span class="keyword">except</span> <span class="class">ArgosNotFoundError</span>:
    <span class="func">print</span>(<span class="string">"Target article does not exist in local DB."</span>)
<span class="keyword">except</span> <span class="class">ArgosConnectionError</span>:
    <span class="func">print</span>(<span class="string">"Remote server is unreachable or DNS failed."</span>)
<span class="keyword">except</span> <span class="class">ArgosAPIError</span> <span class="keyword">as</span> e:
    <span class="func">print</span>(<span class="string">f"Server responded with syntax or query fault: {{e}}"</span>)
            </pre>

            <div style="margin-top: 60px; padding-top: 20px; border-top: 1px solid var(--border-color); color: var(--text-muted); font-size: 13px;">
                Documentation dynamically rendered for ArgosClient v0.1.2 — Maintained by EGen Labs
            </div>
        </div>
    </main>
</body>
</html>"""
