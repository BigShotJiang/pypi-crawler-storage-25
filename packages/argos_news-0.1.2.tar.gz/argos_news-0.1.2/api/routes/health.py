"""
ARGOS — Health Check Route
=============================
GET /v1/health — System status endpoint.

Returns:
  - status: "ok" if the system is running
  - db_connected: whether the database is reachable
  - uptime_seconds: how long the API has been running
  - article_count: total articles in the database
  - version: ARGOS API version

No authentication required. This endpoint is intended for:
  - Monitoring services (Uptime Robot, Grafana, etc.)
  - Client health checks before making queries
  - Quick sanity check that the system is operational

Requirement refs: FR-17
"""

import time

from fastapi import APIRouter

from api.database import get_article_count, get_db
from api.models import HealthResponse

# Router for health-related endpoints.
# Prefix and tags are set in main.py when including this router.
router = APIRouter()

# Startup time — recorded when the module is imported (at API startup).
# Used to calculate uptime_seconds in the health response.
_start_time = time.time()


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="System health check",
    description="Returns the current status of the ARGOS API and database.",
)
async def health_check():
    """
    Returns system health status.

    Checks:
      1. API is running (if you got a response, it's running)
      2. Database is reachable (attempts a simple query)
      3. Uptime in seconds since API startup
      4. Total article count in the database

    This endpoint never returns an error response — if the API is
    down, you won't get a response at all. If the DB is down, you'll
    get status="ok" but db_connected=False.
    """
    # Calculate uptime since API startup.
    uptime = int(time.time() - _start_time)

    # Check database connectivity with a simple query.
    db_connected = False
    article_count = 0
    try:
        article_count = await get_article_count()
        db_connected = True
    except Exception:
        # DB is unreachable — report it but don't crash the health endpoint.
        db_connected = False

    return HealthResponse(
        status="ok",
        db_connected=db_connected,
        uptime_seconds=uptime,
        article_count=article_count,
        version="0.1.0",
    )
