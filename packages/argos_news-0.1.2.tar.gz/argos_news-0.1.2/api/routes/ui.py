"""
ARGOS — Dedicated UI Routes
================================
GET /ui/sources — Visual Dashboard for Source Registry
GET /ui/feed — Visual Dashboard for JSON Live Feed

These routes provide themed viewer pages that match the VSDocs dark
layout of the main API portal, ensuring a cohesive UX without
breaking the raw API endpoints used by the Python client.
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

router = APIRouter()

# Both pages will fetch from the real endpoints (/v1/sources and /v1/articles/latest)
# via JavaScript and render the data cleanly.

@router.get(
    "/ui/sources",
    response_class=HTMLResponse,
    summary="Source Registry UI",
    include_in_schema=False,
)
async def sources_ui():
    """Serves the themed Source Registry page."""
    return _SOURCES_HTML


@router.get(
    "/ui/feed",
    response_class=HTMLResponse,
    summary="Live Feed UI",
    include_in_schema=False,
)
async def feed_ui():
    """Serves the themed Live Feed page."""
    return _FEED_HTML


_SHARED_CSS = """
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');

        :root {
            /* ARGOS Official Dark Theme + VSDocs Structure */
            --bg-body: #0a0a0f;
            --bg-sidebar: #12121a;
            --bg-topbar: #12121a;
            --bg-card: #12121a;
            --surface-alt: #1a1a2e;
            
            --text-main: #e0e0f0;
            --text-muted: #8888aa;
            --text-heading: #ffffff;
            
            --border-color: #2a2a3e;
            
            --accent-primary: #6366f1;
            --accent-hover: #4f46e5;
            --accent-light: rgba(99, 102, 241, 0.15);
            --accent-glow: rgba(99, 102, 241, 0.3);
            
            --success: #22c55e;
            --danger: #ef4444;
            --warning: #f59e0b;
            
            --sidebar-width: 280px;
            --topbar-height: 64px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Roboto', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
        }

        /* ----- SIDEBAR ----- */
        .sidebar {
            width: var(--sidebar-width);
            background-color: var(--bg-sidebar);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
        }

        .sidebar-header {
            height: var(--topbar-height);
            display: flex;
            align-items: center;
            padding: 0 24px;
            border-bottom: 1px solid var(--border-color);
            gap: 12px;
            background: linear-gradient(135deg, #12121a 0%, #1e1e3a 100%);
        }

        .sidebar-header img {
            width: 32px;
            height: 32px;
            border-radius: 6px;
        }

        .sidebar-header h1 {
            font-size: 18px;
            font-weight: 700;
            color: var(--accent-primary);
            letter-spacing: 0.5px;
        }

        .sidebar-nav {
            padding: 24px 0;
            flex: 1;
            overflow-y: auto;
        }

        .nav-group { margin-bottom: 24px; }

        .nav-title {
            font-size: 12px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 0 24px;
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 10px 24px;
            color: var(--text-muted);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
            position: relative;
        }

        .nav-link:hover {
            color: var(--text-main);
            background-color: var(--surface-alt);
        }

        .nav-link.active {
            color: var(--accent-primary);
            background-color: var(--accent-light);
            border-right: 3px solid var(--accent-primary);
        }

        /* ----- MAIN CONTENT ----- */
        .main-col {
            flex: 1;
            margin-left: var(--sidebar-width);
            display: flex;
            flex-direction: column;
        }

        .topbar {
            height: var(--topbar-height);
            background-color: var(--bg-topbar);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            padding: 0 40px;
            position: sticky;
            top: 0;
            z-index: 90;
        }
        
        .breadcrumb {
            color: var(--text-muted);
            font-size: 14px;
        }
        .breadcrumb span {
            color: var(--text-main);
            font-weight: 500;
        }

        .content {
            padding: 40px;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: var(--text-heading);
            margin-bottom: 12px;
        }

        .lead {
            font-size: 16px;
            color: var(--text-muted);
            line-height: 1.6;
            margin-bottom: 32px;
            max-width: 800px;
        }

        /* Table & Pre styles */
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
            background: var(--bg-card);
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid var(--border-color);
        }

        th, td {
            text-align: left;
            padding: 16px;
            border-bottom: 1px solid var(--border-color);
        }

        th {
            background-color: var(--surface-alt);
            color: var(--text-muted);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }

        tr:last-child td { border-bottom: none; }
        
        pre.json-viewer {
            background-color: #0d1117;
            padding: 24px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            color: #c9d1d9;
            font-family: 'Fira Code', monospace;
            font-size: 13px;
            overflow-x: auto;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.5);
            line-height: 1.5;
        }
"""

_SHARED_SIDEBAR = """
    <!-- SIDEBAR NAVIGATION -->
    <nav class="sidebar">
        <div class="sidebar-header">
            <img src="/static/logo.png" alt="ARGOS Logo">
            <h1>ARGOS API</h1>
        </div>
        
        <div class="sidebar-nav">
            <div class="nav-group">
                <div class="nav-title">System Hub</div>
                <a href="/" class="nav-link">Overview</a>
                <a href="/v1/health" class="nav-link">Health Status</a>
            </div>

            <div class="nav-group">
                <div class="nav-title">Documentation</div>
                <a href="/docs" class="nav-link">API Specification</a>
                <a href="/redoc" class="nav-link">ReDoc Layout</a>
                <a href="/client-docs" class="nav-link">Python Client Guide</a>
            </div>

            <div class="nav-group">
                <div class="nav-title">Data Insights</div>
                <a href="/v1/db" class="nav-link">Database Viewer</a>
                <a href="/ui/sources" class="nav-link" id="nav-sources">Source Registry</a>
                <a href="/ui/feed" class="nav-link" id="nav-feed">Live Feed (JSON)</a>
            </div>
        </div>
    </nav>
"""

_SOURCES_HTML = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Source Registry — ARGOS</title>
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
    <style>
        {_SHARED_CSS}
        
        .badge {{
            padding: 4px 10px;
            border-radius: 100px;
            font-size: 12px;
            font-weight: 600;
        }}
        .badge.true {{ background: rgba(34, 197, 94, 0.15); color: var(--success); }}
        .badge.false {{ background: rgba(239, 68, 68, 0.15); color: var(--danger); }}
        
        .badge-orient {{ background: var(--surface-alt); color: var(--accent-primary); }}
    </style>
</head>
<body>
    {_SHARED_SIDEBAR.replace('id="nav-sources" class="nav-link"', 'id="nav-sources" class="nav-link active"')}

    <main class="main-col">
        <header class="topbar">
            <div class="breadcrumb">
                ARGOS / Data Insights / <span>Source Registry</span>
            </div>
        </header>

        <div class="content">
            <h1 class="page-title">Source Network Registry</h1>
            <p class="lead">
                The authoritative state list of the 4 tracked Middle Eastern networks. 
                These trust parameters, ownership lines, and orientations are injected precisely into 
                every ingested article by the Scrapy ingestion pipeline.
            </p>

            <table id="sources-table">
                <thead>
                    <tr>
                        <th>Domain</th>
                        <th>Network Name</th>
                        <th>Host Country</th>
                        <th>Editorial Orientation</th>
                        <th>Trust Index</th>
                        <th>Israeli-Influenced</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td colspan="6" style="text-align: center; color: var(--text-muted);">Loading registry data...</td></tr>
                </tbody>
            </table>
        </div>
    </main>

    <script>
        async function fetchSources() {{
            try {{
                const resp = await fetch('/v1/sources');
                const data = await resp.json();
                
                let html = '';
                data.forEach(s => {{
                    // Add color coding to trust score
                    let trustColor = 'var(--warning)';
                    if (s.trust_score > 0.5) trustColor = 'var(--success)';
                    else if (s.trust_score < 0.45) trustColor = 'var(--danger)';

                    html += `<tr>
                        <td style="font-family: 'Fira Code', monospace; color: var(--text-heading);">${{s.domain}}</td>
                        <td style="font-weight: 500;">${{s.source_name}}</td>
                        <td>${{s.country}}</td>
                        <td><span class="badge badge-orient">${{s.orientation}}</span></td>
                        <td style="color: ${{trustColor}}; font-weight: 600;">${{s.trust_score.toFixed(2)}}</td>
                        <td><span class="badge ${{s.is_israeli_influenced}}">${{s.is_israeli_influenced ? 'YES' : 'NO'}}</span></td>
                    </tr>`;
                }});
                
                document.querySelector('#sources-table tbody').innerHTML = html;
            }} catch(e) {{
                document.querySelector('#sources-table tbody').innerHTML = '<tr><td colspan="6" style="color: var(--danger);">Failed to load API data.</td></tr>';
            }}
        }}
        fetchSources();
    </script>
</body>
</html>"""

_FEED_HTML = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live JSON Feed — ARGOS</title>
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
    <style>
        {_SHARED_CSS}
        
        /* Basic syntax highlighting */
        .string {{ color: #a5d6ff; }}
        .number {{ color: #79c0ff; }}
        .boolean {{ color: #ff7b72; }}
        .null {{ color: #ff7b72; }}
        .key {{ color: #d2a8ff; font-weight: 500; }}
    </style>
</head>
<body>
    {_SHARED_SIDEBAR.replace('id="nav-feed" class="nav-link"', 'id="nav-feed" class="nav-link active"')}

    <main class="main-col">
        <header class="topbar">
            <div class="breadcrumb">
                ARGOS / Data Insights / <span>Live Feed (JSON)</span>
            </div>
        </header>

        <div class="content">
            <h1 class="page-title">Live JSON Event Feed</h1>
            <p class="lead">
                Rendering the direct HTTP output returned by `GET /v1/articles/latest?count=10`. This perfectly matches exactly what an autonomous agent or `ArgosClient` receives in real-time.
            </p>

            <pre class="json-viewer" id="json-box">Loading Live Pipe...</pre>
        </div>
    </main>

    <script>
        // Syntax highlighting logic
        function syntaxHighlight(json) {{
            if (typeof json != 'string') {{ json = JSON.stringify(json, undefined, 4); }}
            json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return json.replace(/("(\\u[a-zA-Z0-9]{{4}}|\\[^u]|[^\\\\"])*"(\\s*:)?|\\b(true|false|null)\\b|-?\\d+(?:\\.\\d*)?(?:[eE][+\\-]?\\d+)?)/g, function (match) {{
                var cls = 'number';
                if (/^"/.test(match)) {{
                    if (/:$/.test(match)) {{ cls = 'key'; }}
                    else {{ cls = 'string'; }}
                }} else if (/true|false/.test(match)) {{
                    cls = 'boolean';
                }} else if (/null/.test(match)) {{
                    cls = 'null';
                }}
                return '<span class="' + cls + '">' + match + '</span>';
            }});
        }}

        async function fetchFeed() {{
            try {{
                const resp = await fetch('/v1/articles/latest?count=10');
                const data = await resp.json();
                document.getElementById('json-box').innerHTML = syntaxHighlight(data);
            }} catch(e) {{
                document.getElementById('json-box').innerHTML = '<span style="color: var(--danger);">Failed to connect. Is the API server running?</span>';
            }}
        }}
        fetchFeed();
        // Refresh every 15s to keep it "Live"
        setInterval(fetchFeed, 15000);
    </script>
</body>
</html>"""
