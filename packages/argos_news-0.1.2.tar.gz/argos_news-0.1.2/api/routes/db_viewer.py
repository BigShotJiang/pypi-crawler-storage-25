"""
ARGOS — Database Viewer Route
================================
GET /v1/db — Interactive database viewer page (HTML)
GET /v1/db/stats — Database statistics (JSON)

Provides a browser-based interface for inspecting the contents
of the ARGOS SQLite database without needing external tools.
"""

import os

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from api.config import get_settings
from api.database import get_db

from api.routes.ui import _SHARED_CSS, _SHARED_SIDEBAR

router = APIRouter()

@router.get(
    "/db/stats",
    summary="Database statistics",
    description="Returns aggregate statistics about the database contents.",
)
async def db_stats():
    """Returns database statistics for the dashboard."""
    settings = get_settings()

    async with get_db() as db:
        cursor = await db.execute("SELECT COUNT(*) as cnt FROM articles")
        row = await cursor.fetchone()
        total = row["cnt"]

        cursor = await db.execute("SELECT source_name, COUNT(*) as cnt FROM articles GROUP BY source_name ORDER BY cnt DESC")
        by_source = [{"source_name": r["source_name"], "count": r["cnt"]} for r in await cursor.fetchall()]

        cursor = await db.execute("SELECT category, COUNT(*) as cnt FROM articles GROUP BY category ORDER BY cnt DESC")
        by_category = [{"category": r["category"], "count": r["cnt"]} for r in await cursor.fetchall()]

        cursor = await db.execute("SELECT country, COUNT(*) as cnt FROM articles GROUP BY country ORDER BY cnt DESC")
        by_country = [{"country": r["country"], "count": r["cnt"]} for r in await cursor.fetchall()]

        cursor = await db.execute("SELECT MIN(published_at) as oldest, MAX(published_at) as newest FROM articles")
        date_row = await cursor.fetchone()

        cursor = await db.execute("SELECT orientation, COUNT(*) as cnt FROM articles GROUP BY orientation ORDER BY cnt DESC")
        by_orientation = [{"orientation": r["orientation"], "count": r["cnt"]} for r in await cursor.fetchall()]

    db_size_bytes = 0
    try:
        db_size_bytes = os.path.getsize(settings.DATABASE_PATH)
    except OSError:
        pass

    return {
        "total_articles": total,
        "db_size_bytes": db_size_bytes,
        "db_size_mb": round(db_size_bytes / (1024 * 1024), 2),
        "date_range": {
            "oldest": date_row["oldest"] if date_row else None,
            "newest": date_row["newest"] if date_row else None,
        },
        "by_source": by_source,
        "by_category": by_category,
        "by_country": by_country,
        "by_orientation": by_orientation,
    }


@router.get(
    "/db",
    response_class=HTMLResponse,
    summary="Database viewer UI",
    description="Interactive web UI for browsing the ARGOS database.",
    include_in_schema=False,
)
async def db_viewer():
    """Serves the themed interactive database viewer HTML page."""
    return _DB_VIEWER_HTML


_DB_VIEWER_HTML = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Viewer — ARGOS</title>
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
    <style>
        {_SHARED_CSS}

        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 32px; }}
        .stat-card {{ background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 8px; padding: 20px; text-align: center; }}
        .stat-card .value {{ font-size: 32px; font-weight: 700; color: var(--accent-primary); margin-bottom: 4px; }}
        .stat-card .label {{ font-size: 13px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }}

        .section {{ margin-bottom: 32px; }}
        .section h2 {{ font-size: 18px; font-weight: 600; margin-bottom: 16px; color: var(--text-heading); display: flex; align-items: center; gap: 8px; }}
        .section h2::before {{ content: ''; width: 4px; height: 20px; background: var(--accent-primary); border-radius: 2px; }}

        .breakdown-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; }}
        .breakdown-card {{ background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 8px; padding: 20px; }}
        .breakdown-card h3 {{ font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted); margin-bottom: 12px; }}

        .bar-row {{ display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }}
        .bar-label {{ width: 130px; font-size: 13px; color: var(--text-main); font-weight: 500; flex-shrink: 0; }}
        .bar-bg {{ flex: 1; height: 24px; background: var(--surface-alt); border-radius: 4px; overflow: hidden; }}
        .bar-fill {{ height: 100%; background: linear-gradient(90deg, var(--accent-hover), var(--accent-primary)); border-radius: 4px; display: flex; align-items: center; padding-left: 8px; font-size: 11px; font-weight: 600; color: white; min-width: 30px; }}

        .articles-table-wrap {{ background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden; }}
        .search-bar {{ padding: 16px 20px; display: flex; gap: 12px; flex-wrap: wrap; border-bottom: 1px solid var(--border-color); align-items: center; background: var(--bg-sidebar); }}
        .search-bar input, .search-bar select {{ background: var(--surface-alt); border: 1px solid var(--border-color); border-radius: 6px; color: var(--text-main); padding: 8px 14px; font-size: 13px; font-family: inherit; outline: none; }}
        .search-bar input:focus, .search-bar select:focus {{ border-color: var(--accent-primary); }}
        .search-bar input {{ flex: 1; min-width: 200px; }}
        .search-bar button {{ background: var(--accent-primary); color: white; border: none; border-radius: 6px; padding: 8px 20px; font-size: 13px; font-weight: 600; cursor: pointer; transition: opacity 0.2s; }}
        .search-bar button:hover {{ opacity: 0.8; }}

        .badge {{ display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }}
        .badge-topics {{ background: var(--surface-alt); color: var(--text-main); }}

        .pagination {{ display: flex; justify-content: center; gap: 8px; padding: 16px; background: var(--bg-sidebar); }}
        .pagination button {{ background: var(--surface-alt); color: var(--text-main); border: 1px solid var(--border-color); border-radius: 4px; padding: 6px 14px; font-size: 13px; cursor: pointer; }}
        .pagination button:hover {{ border-color: var(--accent-primary); }}
        .pagination button:disabled {{ opacity: 0.3; cursor: not-allowed; }}
        .pagination .current {{ background: var(--accent-primary); border-color: var(--accent-primary); font-weight: 600; }}

        .loading {{ text-align: center; padding: 40px; color: var(--text-muted); }}
        a {{ color: var(--accent-primary); text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
    </style>
</head>
<body>
    {_SHARED_SIDEBAR.replace('href="/v1/db" class="nav-link"', 'href="/v1/db" class="nav-link active"')}

    <main class="main-col">
        <header class="topbar">
            <div class="breadcrumb">
                ARGOS / Data Insights / <span>Database Viewer</span>
            </div>
        </header>

        <div class="content">
            <h1 class="page-title">Database Inspection Dashboard</h1>
            <p class="lead">Interactive visual analysis connecting directly to the local SQLite tables built by Scrapy.</p>

            <div class="stats-grid" id="stats-grid">
                <div class="loading">Loading DB statistics...</div>
            </div>

            <div class="section">
                <h2>Categorical Breakdowns</h2>
                <div class="breakdown-grid" id="breakdowns"></div>
            </div>

            <div class="section">
                <h2>Explore Pipeline Records</h2>
                <div class="articles-table-wrap">
                    <div class="search-bar">
                        <input type="text" id="search-title" placeholder="Search headline keywords...">
                        <select id="filter-source">
                            <option value="">All Tracking Sources</option>
                            <option value="Al Jazeera">Al Jazeera</option>
                            <option value="Al Arabiya">Al Arabiya</option>
                            <option value="Sky News Arabia">Sky News Arabia</option>
                            <option value="Middle East Eye">Middle East Eye</option>
                        </select>
                        <select id="filter-category">
                            <option value="">Everything</option>
                            <option value="politics">Politics</option>
                            <option value="economy">Economy</option>
                            <option value="war">War</option>
                            <option value="tech">Tech</option>
                            <option value="health">Health</option>
                            <option value="sports">Sports</option>
                            <option value="culture">Culture</option>
                        </select>
                        <button onclick="searchArticles()">Deep Search</button>
                    </div>
                    <div id="articles-table">
                        <div class="loading">Fetching rows...</div>
                    </div>
                    <div class="pagination" id="pagination"></div>
                </div>
            </div>
        </div>
    </main>

    <script>
        let currentPage = 1;
        const PAGE_SIZE = 15;

        async function loadStats() {{
            try {{
                const resp = await fetch('/v1/db/stats');
                const data = await resp.json();

                document.getElementById('stats-grid').innerHTML = `
                    <div class="stat-card"><div class="value">${{data.total_articles.toLocaleString()}}</div><div class="label">Rows Inserted</div></div>
                    <div class="stat-card"><div class="value">${{data.by_source.length}}</div><div class="label">Active Sources</div></div>
                    <div class="stat-card"><div class="value">${{data.db_size_mb}} MB</div><div class="label">Storage Footprint</div></div>
                    <div class="stat-card"><div class="value">${{data.date_range.oldest ? data.date_range.oldest.split('T')[0] : 'N/A'}}</div><div class="label">Earliest Snapshot</div></div>
                `;

                const total = data.total_articles || 1;
                let breakdownHTML = '';

                // Generate Breakdowns
                ['source', 'category', 'orientation'].forEach(type => {{
                    const arr = data[`by_${{type}}`];
                    if (arr && arr.length) {{
                        breakdownHTML += `<div class="breakdown-card"><h3>By ${{type}}</h3>`;
                        arr.forEach(i => {{
                            const name = i[`${{type}}_name`] || i[type];
                            const pct = Math.round(i.count / total * 100);
                            breakdownHTML += `<div class="bar-row"><span class="bar-label">${{name}}</span><div class="bar-bg"><div class="bar-fill" style="width:${{Math.max(pct, 3)}}%">${{i.count.toLocaleString()}}</div></div></div>`;
                        }});
                        breakdownHTML += '</div>';
                    }}
                }});
                document.getElementById('breakdowns').innerHTML = breakdownHTML;
            }} catch (e) {{
                document.getElementById('stats-grid').innerHTML = '<div class="loading">Failed to analyze local SQLite constraints.</div>';
            }}
        }}

        async function loadArticles(page = 1) {{
            currentPage = page;
            const title = document.getElementById('search-title').value;
            const source = document.getElementById('filter-source').value;
            const category = document.getElementById('filter-category').value;

            let url = `/v1/articles?page=${{page}}&page_size=${{PAGE_SIZE}}&sort_by=published_at&order=desc`;
            if (title) url += `&title=${{encodeURIComponent(title)}}`;
            if (source) url += `&source_name=${{encodeURIComponent(source)}}`;
            if (category) url += `&category=${{encodeURIComponent(category)}}`;

            try {{
                const resp = await fetch(url);
                const data = await resp.json();

                if (!data.data.length) {{
                    document.getElementById('articles-table').innerHTML = '<div class="loading">No records match parameters.</div>';
                    document.getElementById('pagination').innerHTML = '';
                    return;
                }}

                let html = '<table><thead><tr><th>UUID</th><th>Headline</th><th>Network</th><th>Topic</th><th>Ingested Time</th></tr></thead><tbody>';
                data.data.forEach(a => {{
                    const cat = a.category || 'other';
                    html += `<tr>
                        <td style="font-family: monospace; color: var(--text-muted);">${{a.id}}</td>
                        <td><a href="${{a.source_url}}" target="_blank">${{a.title}}</a></td>
                        <td style="font-weight: 500;">${{a.source_name}}</td>
                        <td><span class="badge badge-topics">${{cat.toUpperCase()}}</span></td>
                        <td style="color: var(--text-muted);">${{a.scraped_at ? a.scraped_at.replace('T', ' ').substring(0, 16) : 'N/A'}}</td>
                    </tr>`;
                }});
                html += '</tbody></table>';
                document.getElementById('articles-table').innerHTML = html;

                // Pagination logic
                const p = data.pagination;
                let pagHTML = '';
                pagHTML += `<button ${{p.has_prev ? `onclick="loadArticles(${{p.page-1}})"` : 'disabled'}}>← Previous</button>`;
                pagHTML += `<button class="current">Page ${{p.page}} of ${{p.total_pages}}</button>`;
                pagHTML += `<button ${{p.has_next ? `onclick="loadArticles(${{p.page+1}})"` : 'disabled'}}>Next →</button>`;
                document.getElementById('pagination').innerHTML = pagHTML;
            }} catch (e) {{
                document.getElementById('articles-table').innerHTML = '<div class="loading">DB Connectivity Issues</div>';
            }}
        }}

        function searchArticles() {{ loadArticles(1); }}
        document.getElementById('search-title').addEventListener('keypress', (e) => {{
            if (e.key === 'Enter') searchArticles();
        }});

        loadStats();
        loadArticles(1);
    </script>
</body>
</html>"""
