"""
ARGOS — Articles Routes
=========================
Core query endpoints for the ARGOS API.

Endpoints:
  - GET /v1/articles         — Filtered, paginated article search
  - GET /v1/articles/latest  — N most recent articles (no filters)
  - GET /v1/articles/{id}    — Single article by database ID

All responses use the standard envelope format:
  Success: {"success": true, "data": ..., "pagination": ...}
  Error:   {"success": false, "error": {...}}

Filter parameters combine with AND logic — adding more filters
narrows the results. Tags also combine with AND.

Default sort: published_at descending (newest first).

Requirement refs: FR-17, FR-18, FR-20, FR-21
"""

from typing import Optional

from fastapi import APIRouter, HTTPException, Query

from api.database import get_article_by_id, query_articles
from api.models import (
    ArticleListResponse,
    ArticleOut,
    ErrorResponse,
    PaginationMeta,
    SingleArticleResponse,
)

router = APIRouter()


@router.get(
    "/articles",
    response_model=ArticleListResponse,
    summary="Search articles with filters",
    description="Query articles with optional filters. All filters combine with AND.",
    responses={
        400: {"model": ErrorResponse, "description": "Invalid filter parameters"},
    },
)
async def list_articles(
    # --- Filter Parameters (all optional, combine with AND) ---
    source_name: Optional[str] = Query(
        None,
        description="Filter by news network name (e.g., 'Al Jazeera')"
    ),
    country: Optional[str] = Query(
        None,
        description="Filter by source network country (e.g., 'Qatar')"
    ),
    category: Optional[str] = Query(
        None,
        description="Filter by topic category (e.g., 'politics', 'war')"
    ),
    topic: Optional[str] = Query(
        None,
        description="Alias for category (for API convenience)"
    ),
    orientation: Optional[str] = Query(
        None,
        description="Filter by editorial orientation (e.g., 'left', 'center-right')"
    ),
    is_israeli_influenced: Optional[bool] = Query(
        None,
        description="Filter by Israeli influence flag (true/false)"
    ),
    date_from: Optional[str] = Query(
        None,
        description="Minimum published date (ISO 8601, e.g., '2024-01-01')"
    ),
    date_to: Optional[str] = Query(
        None,
        description="Maximum published date (ISO 8601, e.g., '2024-12-31')"
    ),
    title: Optional[str] = Query(
        None,
        description="Search title text (partial match, case-insensitive)"
    ),
    tags: Optional[str] = Query(
        None,
        description="Comma-separated tags to filter by (AND logic). "
                    "Example: 'ceasefire,diplomacy'"
    ),

    # --- Pagination Parameters ---
    page: int = Query(
        1,
        ge=1,
        description="Page number (1-indexed)"
    ),
    page_size: int = Query(
        20,
        ge=1,
        le=100,
        description="Items per page (max 100)"
    ),

    # --- Sort Parameters ---
    sort_by: str = Query(
        "published_at",
        description="Column to sort by (default: published_at)"
    ),
    order: str = Query(
        "desc",
        description="Sort order: 'asc' or 'desc' (default: desc)"
    ),
):
    """
    Searches articles with optional filtering, pagination, and sorting.

    All filter parameters are optional. When no filters are provided,
    returns all articles ordered by published_at DESC (newest first).

    The `topic` parameter is an alias for `category` — if both are
    provided, `category` takes precedence.

    Tags are provided as a comma-separated string. All specified tags
    must be present on the article (AND logic).

    Examples:
      - /v1/articles?source_name=Al+Jazeera&category=war
      - /v1/articles?country=Qatar&date_from=2024-01-01
      - /v1/articles?title=ceasefire&tags=Egypt,diplomacy
      - /v1/articles?page=5&page_size=50&sort_by=title&order=asc

    Args:
        All parameters are query params (see FastAPI Query definitions above).

    Returns:
        ArticleListResponse: Paginated list of matching articles.

    Requirement refs: FR-18, FR-21
    """
    # Handle topic/category alias.
    # topic is a convenience alias for category (FR-18 mentions both).
    effective_category = category or topic

    # Parse tags from comma-separated string to list.
    tag_list = None
    if tags:
        tag_list = [t.strip() for t in tags.split(",") if t.strip()]

    # Execute the query via the database layer.
    result = await query_articles(
        source_name=source_name,
        country=country,
        category=effective_category,
        orientation=orientation,
        is_israeli_influenced=is_israeli_influenced,
        date_from=date_from,
        date_to=date_to,
        title=title,
        tags=tag_list,
        page=page,
        page_size=page_size,
        sort_by=sort_by,
        order=order,
    )

    # Build the response using Pydantic models.
    articles = [ArticleOut(**article) for article in result["articles"]]
    pagination = PaginationMeta(**result["pagination"])

    return ArticleListResponse(
        success=True,
        data=articles,
        pagination=pagination,
    )


@router.get(
    "/articles/latest",
    response_model=ArticleListResponse,
    summary="Get latest articles",
    description="Returns the N most recently published articles with no filter requirement.",
)
async def latest_articles(
    count: int = Query(
        20,
        ge=1,
        le=100,
        description="Number of articles to return (max 100)"
    ),
):
    """
    Returns the N most recently published articles.

    Convenience endpoint — equivalent to /v1/articles with no filters,
    page_size=count, and order=desc.

    This is the "latest feed" — what you'd see on a news homepage.

    Args:
        count: Number of articles to return (default 20, max 100).

    Returns:
        ArticleListResponse: The latest articles, newest first.
    """
    result = await query_articles(
        page=1,
        page_size=count,
        sort_by="published_at",
        order="desc",
    )

    articles = [ArticleOut(**article) for article in result["articles"]]
    pagination = PaginationMeta(**result["pagination"])

    return ArticleListResponse(
        success=True,
        data=articles,
        pagination=pagination,
    )


@router.get(
    "/articles/{article_id}",
    response_model=SingleArticleResponse,
    summary="Get article by ID",
    description="Returns a single article by its database ID.",
    responses={
        404: {"model": ErrorResponse, "description": "Article not found"},
    },
)
async def get_article(article_id: int):
    """
    Returns a single article by its database ID.

    The ID is the auto-incremented primary key assigned when the
    article was first stored. It's stable — the same article always
    has the same ID.

    Args:
        article_id: Integer primary key of the article.

    Returns:
        SingleArticleResponse: The article data.

    Raises:
        HTTPException 404: If no article with that ID exists.
    """
    article = await get_article_by_id(article_id)

    if article is None:
        raise HTTPException(
            status_code=404,
            detail={
                "code": "ARTICLE_NOT_FOUND",
                "message": f"No article found with ID {article_id}",
                "field": "article_id",
            }
        )

    return SingleArticleResponse(
        success=True,
        data=ArticleOut(**article),
    )
