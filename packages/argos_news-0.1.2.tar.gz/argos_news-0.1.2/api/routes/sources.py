"""
ARGOS — Sources Route
=======================
GET /v1/sources — Returns the full source network registry.

Exposes the SOURCE_REGISTRY as a structured list so downstream
clients and agents can discover:
  - Which sources ARGOS tracks
  - Available filter values for country, source_name, orientation
  - Trust scores and Israeli-influence flags

This is a static endpoint — the data comes from the registry,
not the database. It always returns the same 4 sources.

Useful for:
  - Building filter UIs
  - Agent self-discovery ("what sources can I query?")
  - Documentation/"about" features

Requirement refs: FR-17
"""

from fastapi import APIRouter

from api.models import SourceListResponse, SourceOut
from scraper.argos.registry import SOURCE_REGISTRY

router = APIRouter()


@router.get(
    "/sources",
    response_model=SourceListResponse,
    summary="List all source networks",
    description="Returns the full ARGOS source network registry with metadata.",
)
async def list_sources():
    """
    Returns all source networks in the ARGOS registry.

    This is a static list — it doesn't depend on what's actually
    been scraped. All 4 sources are always returned.

    Returns:
        SourceListResponse: List of all registered sources with their
        metadata (country, orientation, trust_score, Israeli-influence flag).
    """
    sources = []

    for domain, meta in SOURCE_REGISTRY.items():
        sources.append(SourceOut(
            domain=domain,
            source_name=meta["source_name"],
            country=meta["country"],
            orientation=meta["orientation"],
            trust_score=meta["trust_score"],
            is_israeli_influenced=meta["is_israeli_influenced"],
        ))

    return SourceListResponse(
        success=True,
        data=sources,
    )
