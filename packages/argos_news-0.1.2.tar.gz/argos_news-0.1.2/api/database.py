"""
ARGOS — Database Layer
========================
Async SQLite access for the FastAPI API layer.

Uses aiosqlite to provide non-blocking database queries within
FastAPI's async request handlers. This is critical for performance —
SQLite queries block the event loop if done synchronously.

The database is the same SQLite file written by the Scrapy storage
pipeline. WAL mode (set by the storage pipeline) allows concurrent
reading by the API while spiders are writing.

Key functions:
  - get_db(): Context manager for async DB connections
  - query_articles(): Builds dynamic WHERE clause from filter params
  - get_article_by_id(): Single article lookup
  - get_article_count(): Total count for health checks
  - init_db(): Ensures table exists (called at API startup)

Requirement refs: FR-14, FR-18
"""

import json
import logging
import math
import os
from contextlib import asynccontextmanager

import aiosqlite

from api.config import get_settings

logger = logging.getLogger(__name__)


@asynccontextmanager
async def get_db():
    """
    Async context manager for database connections.

    Opens an aiosqlite connection, enables WAL mode for concurrent
    read/write, and yields the connection. Closes automatically
    when the context exits.

    Usage:
        async with get_db() as db:
            cursor = await db.execute("SELECT ...")
            rows = await cursor.fetchall()
    """
    settings = get_settings()
    db_path = settings.DATABASE_PATH

    # Ensure the database directory exists.
    db_dir = os.path.dirname(db_path)
    if db_dir:
        os.makedirs(db_dir, exist_ok=True)

    db = await aiosqlite.connect(db_path)

    # Enable WAL mode — allows the API to read while spiders write.
    # This is a no-op if already enabled (WAL is persistent).
    await db.execute("PRAGMA journal_mode=WAL")

    # Return rows as sqlite3.Row objects so we can access columns by name.
    db.row_factory = aiosqlite.Row

    try:
        yield db
    finally:
        await db.close()


async def init_db():
    """
    Ensures the articles table and indexes exist.

    Called once at API startup. The storage pipeline also creates
    the table, so this is a safety net in case the API starts
    before any spider has ever run.
    """
    async with get_db() as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS articles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                content TEXT NOT NULL DEFAULT '',
                summary TEXT NOT NULL DEFAULT '',
                category TEXT NOT NULL,
                tags TEXT NOT NULL DEFAULT '[]',
                source_name TEXT NOT NULL,
                source_url TEXT NOT NULL UNIQUE,
                published_at TEXT NOT NULL,
                scraped_at TEXT NOT NULL,
                country TEXT NOT NULL,
                orientation TEXT NOT NULL,
                trust_score REAL NOT NULL,
                is_israeli_influenced INTEGER NOT NULL DEFAULT 0
            )
        """)

        # Create indexes for query performance (FR-14).
        for idx_sql in [
            "CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles (published_at)",
            "CREATE INDEX IF NOT EXISTS idx_articles_source_name ON articles (source_name)",
            "CREATE INDEX IF NOT EXISTS idx_articles_country ON articles (country)",
            "CREATE INDEX IF NOT EXISTS idx_articles_category ON articles (category)",
            "CREATE INDEX IF NOT EXISTS idx_articles_orientation ON articles (orientation)",
            "CREATE INDEX IF NOT EXISTS idx_articles_source_category ON articles (source_name, category)",
        ]:
            await db.execute(idx_sql)

        await db.commit()
        logger.info("Database initialized: table 'articles' ready")


def _row_to_article(row) -> dict:
    """
    Converts a database row to an article dictionary.

    Handles:
      - Deserializing tags from JSON string to Python list
      - Converting is_israeli_influenced from integer (0/1) to boolean
      - Mapping all 13 fields plus the database id

    Args:
        row: An aiosqlite.Row from a SELECT query.

    Returns:
        dict: Article data matching the ArticleOut model shape.
    """
    return {
        "id": row["id"],
        "title": row["title"],
        "content": row["content"],
        "summary": row["summary"],
        "category": row["category"],
        # tags are stored as JSON string in SQLite — deserialize to list
        "tags": json.loads(row["tags"]) if row["tags"] else [],
        "source_name": row["source_name"],
        "source_url": row["source_url"],
        "published_at": row["published_at"],
        "scraped_at": row["scraped_at"],
        "country": row["country"],
        "orientation": row["orientation"],
        "trust_score": row["trust_score"],
        # SQLite has no native bool — stored as 0/1 integer
        "is_israeli_influenced": bool(row["is_israeli_influenced"]),
    }


async def query_articles(
    *,
    source_name: str | None = None,
    country: str | None = None,
    category: str | None = None,
    orientation: str | None = None,
    is_israeli_influenced: bool | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    title: str | None = None,
    tags: list[str] | None = None,
    page: int = 1,
    page_size: int = 20,
    sort_by: str = "published_at",
    order: str = "desc",
) -> dict:
    """
    Queries articles with dynamic filtering, sorting, and pagination.

    Builds a SQL WHERE clause from the provided filter parameters.
    All filters combine with AND logic — narrowing results.
    Tags combine with AND — article must have ALL specified tags.

    Args:
        source_name: Filter by news network name (exact match)
        country: Filter by source network's country (exact match)
        category: Filter by topic category (exact match)
        orientation: Filter by editorial orientation (exact match)
        is_israeli_influenced: Filter by Israeli influence flag
        date_from: Minimum published_at date (ISO 8601, inclusive)
        date_to: Maximum published_at date (ISO 8601, inclusive)
        title: Search title text (partial match, case-insensitive)
        tags: List of tags — article must contain ALL of them
        page: Page number (1-indexed)
        page_size: Items per page (capped at 100)
        sort_by: Column to sort by (default: published_at)
        order: Sort direction: "asc" or "desc" (default: desc)

    Returns:
        dict: {
            "articles": [list of article dicts],
            "pagination": {
                "page": int, "page_size": int,
                "total_results": int, "total_pages": int,
                "has_next": bool, "has_prev": bool
            }
        }

    Requirement refs: FR-14, FR-18, FR-21
    """
    # --- Build WHERE clause dynamically ---
    conditions = []
    params = []

    if source_name:
        conditions.append("source_name = ?")
        params.append(source_name)

    if country:
        conditions.append("country = ?")
        params.append(country)

    if category:
        conditions.append("category = ?")
        params.append(category)

    if orientation:
        conditions.append("orientation = ?")
        params.append(orientation)

    if is_israeli_influenced is not None:
        conditions.append("is_israeli_influenced = ?")
        params.append(1 if is_israeli_influenced else 0)

    if date_from:
        conditions.append("published_at >= ?")
        params.append(date_from)

    if date_to:
        conditions.append("published_at <= ?")
        params.append(date_to)

    if title:
        # LIKE with % wildcards for partial matching.
        # Case-insensitive in SQLite by default for ASCII characters.
        conditions.append("title LIKE ?")
        params.append(f"%{title}%")

    if tags:
        # Tags are stored as JSON arrays. For each tag, we check if
        # the JSON string contains the tag value.
        # This is not perfect (could match substrings) but is efficient
        # for SQLite without JSON1 extension guarantees.
        for tag in tags:
            conditions.append("tags LIKE ?")
            params.append(f'%"{tag}"%')

    # Combine conditions with AND
    where_clause = " AND ".join(conditions) if conditions else "1=1"

    # --- Validate sort parameters ---
    # Whitelist columns to prevent SQL injection.
    allowed_sort_columns = {
        "published_at", "scraped_at", "title", "source_name",
        "category", "country", "trust_score", "id"
    }
    if sort_by not in allowed_sort_columns:
        sort_by = "published_at"

    order = "DESC" if order.lower() == "desc" else "ASC"

    # --- Cap page_size to prevent abuse ---
    page_size = min(max(page_size, 1), 100)
    page = max(page, 1)
    offset = (page - 1) * page_size

    async with get_db() as db:
        # Count total matching results (for pagination metadata).
        count_sql = f"SELECT COUNT(*) as cnt FROM articles WHERE {where_clause}"
        cursor = await db.execute(count_sql, params)
        row = await cursor.fetchone()
        total_results = row["cnt"] if row else 0

        # Fetch the page of results.
        query_sql = (
            f"SELECT * FROM articles WHERE {where_clause} "
            f"ORDER BY {sort_by} {order} "
            f"LIMIT ? OFFSET ?"
        )
        cursor = await db.execute(query_sql, params + [page_size, offset])
        rows = await cursor.fetchall()

        articles = [_row_to_article(row) for row in rows]

    total_pages = max(1, math.ceil(total_results / page_size))

    return {
        "articles": articles,
        "pagination": {
            "page": page,
            "page_size": page_size,
            "total_results": total_results,
            "total_pages": total_pages,
            "has_next": page < total_pages,
            "has_prev": page > 1,
        }
    }


async def get_article_by_id(article_id: int) -> dict | None:
    """
    Fetches a single article by its database ID.

    Args:
        article_id: The integer primary key of the article.

    Returns:
        dict: Article data, or None if not found.
    """
    async with get_db() as db:
        cursor = await db.execute(
            "SELECT * FROM articles WHERE id = ?",
            (article_id,)
        )
        row = await cursor.fetchone()
        return _row_to_article(row) if row else None


async def get_article_count() -> int:
    """
    Returns the total number of articles in the database.

    Used by the health check endpoint.
    """
    async with get_db() as db:
        cursor = await db.execute("SELECT COUNT(*) as cnt FROM articles")
        row = await cursor.fetchone()
        return row["cnt"] if row else 0
