"""
ARGOS — API Response Models
==============================
Pydantic v2 models for all API responses.

These models define the exact shape of every response the API returns.
All responses use a consistent "envelope" pattern:
  - Success: {"success": true, "data": {...}, "pagination": {...}}
  - Error:   {"success": false, "error": {"code": ..., "message": ...}}

This predictability makes the API easy to consume — downstream clients
always know what shape the response will be in, regardless of the endpoint.

Models:
  - ArticleOut: A single article with all 13 fields
  - PaginationMeta: Page numbering and navigation metadata
  - ArticleListResponse: Paginated list of articles (success envelope)
  - SingleArticleResponse: Single article (success envelope)
  - SourceOut: One entry from the source registry
  - SourceListResponse: List of all sources
  - HealthResponse: System health status
  - ErrorDetail / ErrorResponse: Error envelope

Requirement refs: FR-20, FR-21
"""

from typing import Optional

from pydantic import BaseModel, Field


# ============================================================================
# Article Model — All 13 ARGOS data model fields
# ============================================================================

class ArticleOut(BaseModel):
    """
    Represents a single article in API responses.

    Mirrors the 13-field ARGOS data model exactly (context.md Section 3).
    The `id` field is added by the database (auto-incremented primary key).
    Tags are deserialized from JSON string to Python list by the database layer.
    """

    # Database-assigned unique identifier.
    # Auto-incremented integer — used for GET /v1/articles/{id}.
    id: int = Field(
        description="Unique article identifier (database primary key)"
    )

    # --- Content Fields ---
    title: str = Field(
        description="Article headline exactly as published"
    )
    content: str = Field(
        description="Full article body text. Empty string if paywalled/deleted"
    )
    summary: str = Field(
        description="Brief abstract — meta description or first paragraph"
    )

    # --- Classification ---
    category: str = Field(
        description="Topic category: politics, economy, tech, war, health, "
                    "science, culture, sports, environment, other"
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Keyword tags. May be empty list"
    )

    # --- Source Identity ---
    source_name: str = Field(
        description="Canonical name of the news network (e.g., 'Al Jazeera')"
    )
    source_url: str = Field(
        description="Direct URL to the article on the source website"
    )

    # --- Timestamps ---
    published_at: str = Field(
        description="When the source published it (ISO 8601 UTC)"
    )
    scraped_at: str = Field(
        description="When ARGOS collected it (ISO 8601 UTC)"
    )

    # --- Registry Metadata ---
    country: str = Field(
        description="Country of the news network (from registry)"
    )
    orientation: str = Field(
        description="Editorial orientation: left, center-left, center, "
                    "center-right, right, far-right, state, zionist, unknown"
    )
    trust_score: float = Field(
        description="Credibility score 0.0–1.0 (Media Intelligence Index ÷ 100)"
    )
    is_israeli_influenced: bool = Field(
        description="Whether the source has Israeli ownership/editorial influence"
    )


# ============================================================================
# Pagination Model
# ============================================================================

class PaginationMeta(BaseModel):
    """
    Pagination metadata included in list responses.

    Provides all the information a client needs to navigate through
    paginated results — current position, total counts, and
    has_next/has_prev flags for easy navigation.

    Requirement ref: FR-21
    """

    # Current page number (1-indexed for human readability).
    page: int = Field(description="Current page number (1-indexed)")

    # Number of items per page.
    page_size: int = Field(description="Items per page")

    # Total number of matching items across all pages.
    total_results: int = Field(description="Total matching articles")

    # Total number of pages.
    total_pages: int = Field(description="Total pages available")

    # Navigation flags — simplify client-side pagination logic.
    has_next: bool = Field(description="Whether a next page exists")
    has_prev: bool = Field(description="Whether a previous page exists")


# ============================================================================
# Success Response Envelopes
# ============================================================================

class ArticleListResponse(BaseModel):
    """
    Response envelope for paginated article lists.

    Returned by GET /v1/articles and GET /v1/articles/latest.
    """
    success: bool = Field(default=True, description="Always true for success")
    data: list[ArticleOut] = Field(description="List of articles")
    pagination: PaginationMeta = Field(description="Pagination metadata")


class SingleArticleResponse(BaseModel):
    """
    Response envelope for a single article.

    Returned by GET /v1/articles/{id}.
    """
    success: bool = Field(default=True, description="Always true for success")
    data: ArticleOut = Field(description="The requested article")


class SourceOut(BaseModel):
    """
    Represents a single entry from the source registry.

    Returned by GET /v1/sources. Contains the 5 registry fields
    plus the domain name for reference.
    """
    domain: str = Field(description="Source domain (e.g., 'aljazeera.com')")
    source_name: str = Field(description="Canonical source name")
    country: str = Field(description="Source network's country")
    orientation: str = Field(description="Editorial orientation")
    trust_score: float = Field(description="Trust score 0.0–1.0")
    is_israeli_influenced: bool = Field(description="Israeli influence flag")


class SourceListResponse(BaseModel):
    """Response envelope for the source registry list."""
    success: bool = Field(default=True)
    data: list[SourceOut] = Field(description="All registered sources")


class HealthResponse(BaseModel):
    """
    Response for GET /v1/health.

    Provides system status information. No authentication required.
    Useful for monitoring and uptime checks.
    """
    status: str = Field(description="'ok' if system is healthy")
    db_connected: bool = Field(description="Whether the DB is reachable")
    uptime_seconds: int = Field(description="Seconds since API started")
    article_count: int = Field(
        default=0,
        description="Total articles in database"
    )
    version: str = Field(default="0.1.0", description="ARGOS API version")


# ============================================================================
# Error Response Envelope
# ============================================================================

class ErrorDetail(BaseModel):
    """
    Structured error detail within an error response.

    Provides a machine-readable code, human-readable message,
    and optional field name for validation errors.
    """
    code: str = Field(description="Machine-readable error code")
    message: str = Field(description="Human-readable error description")
    field: Optional[str] = Field(
        default=None,
        description="Field name if error relates to a specific parameter"
    )


class ErrorResponse(BaseModel):
    """
    Error response envelope.

    Used for all error cases: 400, 404, 422, 500, etc.
    """
    success: bool = Field(default=False, description="Always false for errors")
    error: ErrorDetail = Field(description="Error details")
