"""
ARGOS — FastAPI Application Entry Point
==========================================
Main application module for the ARGOS REST API.

Responsibilities:
  - Creates the FastAPI app instance with metadata
  - Registers all route modules (/v1/health, /v1/sources, /v1/articles)
  - Mounts static files (favicon, logo)
  - Configures CORS for cross-origin access
  - Sets up the lifespan handler for DB initialization
  - Adds global exception handlers for consistent error responses
  - Serves a custom branded landing page

Run with:
  uvicorn api.main:app --host 0.0.0.0 --port 8000

Or via the launch.py script.

Requirement refs: FR-17, FR-20
"""

import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from api.config import get_settings
from api.database import init_db
from api.routes import articles, health, sources, ui
from api.routes import db_viewer, client_docs

# Configure logging for the API layer.
settings = get_settings()
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL, logging.INFO),
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)

logger = logging.getLogger(__name__)


# ============================================================================
# Lifespan — Startup and Shutdown Events
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan handler.

    Startup:
      - Initializes the database (creates table + indexes if missing)
      - Logs configuration summary

    Shutdown:
      - Logs graceful shutdown message
    """
    # --- Startup ---
    logger.info("ARGOS API starting up...")
    logger.info("Database: %s", settings.DATABASE_PATH)
    logger.info("Public URL: %s", settings.API_BASE_URL)

    # Ensure the database table exists.
    # This is a safety net — the Scrapy storage pipeline also creates it.
    await init_db()

    logger.info("ARGOS API ready — Argus Panoptes is watching.")

    yield  # Application runs here

    # --- Shutdown ---
    logger.info("ARGOS API shutting down gracefully.")


# ============================================================================
# FastAPI Application Instance
# ============================================================================

app = FastAPI(
    title="ARGOS API",
    description=(
        "Automated Realtime Global Observer System — "
        "A news aggregation API providing structured access to articles "
        "from 4 Middle East news networks, enriched with editorial metadata.\n\n"
        "Named after Argus Panoptes — the all-seeing guardian of Greek mythology."
    ),
    version="0.1.2",
    docs_url="/docs",         # Swagger UI at /docs
    redoc_url="/redoc",       # ReDoc at /redoc
    openapi_url="/openapi.json",
    lifespan=lifespan,
)


# ============================================================================
# Static Files — Serve logo.png and favicon.ico
# ============================================================================
# Mount the static/ directory so the custom UI pages can reference
# /static/logo.png and /static/favicon.ico.

STATIC_DIR = Path(__file__).parent.parent / "static"
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
    logger.info("Static files mounted from: %s", STATIC_DIR)


# ============================================================================
# CORS Middleware
# ============================================================================
# Allow all origins for v0.1.0 — the API is designed to be open.
# Tighten this in production if authentication is added.

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],              # Allow all origins
    allow_credentials=True,           # Allow cookies (for future auth)
    allow_methods=["*"],              # Allow all HTTP methods
    allow_headers=["*"],              # Allow all headers
)


# ============================================================================
# Route Registration
# ============================================================================
# All routes are versioned under /v1 for API stability.
# Future breaking changes go under /v2.

app.include_router(
    health.router,
    prefix="/v1",
    tags=["System"],
)

app.include_router(
    sources.router,
    prefix="/v1",
    tags=["Sources"],
)

app.include_router(
    articles.router,
    prefix="/v1",
    tags=["Articles"],
)

# Database viewer — operator tool for inspecting DB contents.
app.include_router(
    db_viewer.router,
    prefix="/v1",
    tags=["Database"],
)

# Client documentation page — detailed Python client usage guide.
app.include_router(
    client_docs.router,
    tags=["Documentation"],
)

# Shared UI dashboards for live feed and sources
app.include_router(
    ui.router,
    tags=["UI Dashboards"],
)


# ============================================================================
# Global Exception Handlers
# ============================================================================
# Catch unhandled exceptions and return consistent ErrorResponse format.
# Never let a raw 500 stack trace reach the client.

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """
    Catches any unhandled exception and returns a structured error response.

    This is the safety net — specific exceptions should be caught in routes
    using HTTPException. This handler catches everything else.

    The error is logged at ERROR level with full traceback for debugging.
    The client only sees a safe, generic message — never internal details.
    """
    logger.error(
        "Unhandled exception on %s %s: %s",
        request.method, request.url.path, exc,
        exc_info=True
    )

    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred. Please try again.",
                "field": None,
            }
        }
    )


@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    """Returns a structured 404 error instead of FastAPI's default."""
    return JSONResponse(
        status_code=404,
        content={
            "success": False,
            "error": {
                "code": "NOT_FOUND",
                "message": f"Resource not found: {request.url.path}",
                "field": None,
            }
        }
    )


@app.exception_handler(422)
async def validation_error_handler(request: Request, exc):
    """
    Returns a structured 422 error for request validation failures.

    FastAPI raises 422 when query parameters or path params fail
    Pydantic validation (e.g., page=-1 when ge=1 is required).
    """
    return JSONResponse(
        status_code=422,
        content={
            "success": False,
            "error": {
                "code": "VALIDATION_ERROR",
                "message": str(exc.detail) if hasattr(exc, "detail") else "Invalid request parameters",
                "field": None,
            }
        }
    )


# ============================================================================
# Root Endpoint — Custom Branded Landing Page
# ============================================================================

@app.get("/", response_class=HTMLResponse, tags=["System"], include_in_schema=False)
async def root():
    """
    Root endpoint — serves the ARGOS landing page.

    A branded HTML page with quick links to all API features.
    """
    return _LANDING_PAGE_HTML.replace("{VERSION}", app.version)


# Landing page HTML — self-contained with embedded CSS
_LANDING_PAGE_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARGOS — Automated Realtime Global Observer System</title>
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
    <style>
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
        :root {
            /* ARGOS Official Dark Theme + VSDocs Structure */
            --bg-body: #0a0a0f;
            --bg-sidebar: #12121a;
            --bg-topbar: #12121a;
            --bg-card: #12121a;
            --surface-alt: #1a1a2e;
            
            --text-main: #e0e0f0;
            --text-muted: #8888aa;
            --text-heading: #ffffff;
            
            --border-color: #2a2a3e;
            
            --accent-primary: #6366f1;
            --accent-hover: #4f46e5;
            --accent-light: rgba(99, 102, 241, 0.15);
            --accent-glow: rgba(99, 102, 241, 0.3);
            
            --success: #22c55e;
            --success-bg: rgba(34, 197, 94, 0.1);
            
            --sidebar-width: 280px;
            --topbar-height: 64px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Roboto', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
        }

        /* ----- SIDEBAR ----- */
        .sidebar {
            width: var(--sidebar-width);
            background-color: var(--bg-sidebar);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
        }

        .sidebar-header {
            height: var(--topbar-height);
            display: flex;
            align-items: center;
            padding: 0 24px;
            border-bottom: 1px solid var(--border-color);
            gap: 12px;
            background: linear-gradient(135deg, #12121a 0%, #1e1e3a 100%);
        }

        .sidebar-header img {
            width: 32px;
            height: 32px;
            border-radius: 6px;
        }

        .sidebar-header h1 {
            font-size: 18px;
            font-weight: 700;
            color: var(--accent-primary);
            letter-spacing: 0.5px;
        }

        .sidebar-nav {
            padding: 24px 0;
            flex: 1;
            overflow-y: auto;
        }

        .nav-group {
            margin-bottom: 24px;
        }

        .nav-title {
            font-size: 12px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 0 24px;
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 10px 24px;
            color: var(--text-muted);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
            position: relative;
        }

        .nav-link:hover {
            color: var(--text-main);
            background-color: var(--surface-alt);
        }

        .nav-link.active {
            color: var(--accent-primary);
            background-color: var(--accent-light);
            border-right: 3px solid var(--accent-primary);
        }

        /* ----- MAIN CONTENT ----- */
        .main-col {
            flex: 1;
            margin-left: var(--sidebar-width);
            display: flex;
            flex-direction: column;
        }

        .topbar {
            height: var(--topbar-height);
            background-color: var(--bg-topbar);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            padding: 0 40px;
            position: sticky;
            top: 0;
            z-index: 90;
        }
        
        .breadcrumb {
            color: var(--text-muted);
            font-size: 14px;
        }
        .breadcrumb span {
            color: var(--text-main);
            font-weight: 500;
        }

        .content {
            padding: 40px;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        /* ----- TYPOGRAPHY & HERO ----- */
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: var(--text-heading);
            margin-bottom: 12px;
        }

        .lead {
            font-size: 16px;
            color: var(--text-muted);
            line-height: 1.6;
            margin-bottom: 32px;
            max-width: 800px;
        }

        /* ----- STATUS BANNER ----- */
        .status-banner {
            background-color: var(--success-bg);
            border: 1px solid rgba(34, 197, 94, 0.3);
            border-radius: 6px;
            padding: 16px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 40px;
        }

        .status-dot {
            width: 10px;
            height: 10px;
            background-color: var(--success);
            border-radius: 50%;
            box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.2);
            animation: pulse-green 2s infinite;
        }

        @keyframes pulse-green {
            0% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.4); }
            70% { box-shadow: 0 0 0 8px rgba(34, 197, 94, 0); }
            100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
        }

        .status-text {
            font-size: 14px;
            font-weight: 500;
            color: var(--success);
        }

        /* ----- STATS ROW ----- */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 48px;
        }

        .stat-box {
            background-color: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 24px;
            transition: transform 0.2s, border-color 0.2s, box-shadow 0.2s;
        }

        .stat-box:hover {
            transform: translateY(-2px);
            border-color: var(--accent-primary);
            box-shadow: 0 0 15px var(--accent-glow);
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: var(--accent-primary);
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 13px;
            font-weight: 500;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* ----- FEATURE CARDS ----- */
        .section-heading {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-heading);
            margin-bottom: 24px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--border-color);
        }

        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 24px;
        }

        .feature-card {
            background-color: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 24px;
            text-decoration: none;
            color: inherit;
            display: block;
            transition: all 0.2s;
        }

        .feature-card:hover {
            border-color: var(--accent-primary);
            background-color: var(--surface-alt);
            box-shadow: 0 0 20px var(--accent-glow);
            transform: translateY(-2px);
        }

        .fc-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }

        .fc-icon {
            width: 40px;
            height: 40px;
            background-color: var(--surface-alt);
            color: var(--accent-primary);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .fc-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-heading);
        }

        .fc-desc {
            font-size: 13px;
            color: var(--text-muted);
            line-height: 1.5;
            margin-bottom: 16px;
        }

        .fc-badge {
            display: inline-block;
            background-color: var(--surface-alt);
            color: var(--accent-primary);
            font-size: 11px;
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 4px;
            letter-spacing: 0.5px;
        }

        /* Responsive */
        @media (max-width: 900px) {
            .sidebar { display: none; }
            .main-col { margin-left: 0; }
        }
    </style>
</head>
<body>

    <!-- SIDEBAR NAVIGATION -->
    <nav class="sidebar">
        <div class="sidebar-header">
            <img src="/static/logo.png" alt="ARGOS Logo">
            <h1>ARGOS API</h1>
        </div>
        
        <div class="sidebar-nav">
            <div class="nav-group">
                <div class="nav-title">System Hub</div>
                <a href="/" class="nav-link active">Overview</a>
                <a href="/v1/health" class="nav-link">Health Status</a>
            </div>

            <div class="nav-group">
                <div class="nav-title">Documentation</div>
                <a href="/docs" class="nav-link">API Specification</a>
                <a href="/redoc" class="nav-link">ReDoc Layout</a>
                <a href="/client-docs" class="nav-link">Python Client Guide</a>
            </div>

            <div class="nav-group">
                <div class="nav-title">Data Insights</div>
                <a href="/v1/db" class="nav-link">Database Viewer</a>
                <a href="/ui/sources" class="nav-link">Source Registry</a>
                <a href="/ui/feed" class="nav-link">Live Feed (JSON)</a>
            </div>
        </div>
    </nav>

    <!-- CONTENT AREA -->
    <main class="main-col">
        <!-- TOP NAVBAR -->
        <header class="topbar">
            <div class="breadcrumb">
                ARGOS / <span>Portal Overview</span>
            </div>
        </header>

        <!-- MAIN DOC CONTENT -->
        <div class="content">
            <h1 class="page-title">Automated Realtime Global Observer System</h1>
            <p class="lead">
                Welcome to the ARGOS operational portal. This system provides an all-seeing, structured data interface for exactly 4 Middle Eastern news networks, enriching raw HTML articles with persistent editorial metadata grids.
            </p>

            <div class="status-banner" id="status-banner">
                <div class="status-dot"></div>
                <div class="status-text" id="status-text">Synchronizing systems...</div>
            </div>

            <!-- STATISTICS WIDGETS -->
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-value" id="stat-articles">---</div>
                    <div class="stat-label">Total Articles Ingested</div>
                </div>
                <div class="stat-box">
                    <div class="stat-value">4</div>
                    <div class="stat-label">Monitored Networks</div>
                </div>
                <div class="stat-box">
                    <div class="stat-value" id="stat-uptime">---</div>
                    <div class="stat-label">Continuous Uptime</div>
                </div>
                <div class="stat-box">
                    <div class="stat-value">v{VERSION}</div>
                    <div class="stat-label">API Core Version</div>
                </div>
            </div>

            <!-- QUICK ACTIONS -->
            <h2 class="section-heading">Quick Actions & Workspaces</h2>
            
            <div class="cards-grid">
                <!-- API Docs -->
                <a href="/docs" class="feature-card">
                    <div class="fc-header">
                        <div class="fc-icon"><i class="fa-solid fa-gear"></i></div>
                        <div class="fc-title">API Endpoint Docs</div>
                    </div>
                    <p class="fc-desc">Vibrant, interactive Swagger UI allowing live execution against the FastAPI routing engine.</p>
                    <span class="fc-badge">OPENAPI 3.1 SCHEMA</span>
                </a>

                <!-- Python Client -->
                <a href="/client-docs" class="feature-card">
                    <div class="fc-header">
                        <div class="fc-icon"><i class="fa-solid fa-book-open"></i></div>
                        <div class="fc-title">Python Client Guide</div>
                    </div>
                    <p class="fc-desc">Installation and scripting reference for the argos-news zero-configuration Python interface.</p>
                    <span class="fc-badge">CODE MANUAL</span>
                </a>

                <!-- DB Viewer -->
                <a href="/v1/db" class="feature-card">
                    <div class="fc-header">
                        <div class="fc-icon"><i class="fa-solid fa-chart-simple"></i></div>
                        <div class="fc-title">Database Insight Viewer</div>
                    </div>
                    <p class="fc-desc">Visual HTML dashboard for inspecting raw database metrics, categorical distributions, and search arrays.</p>
                    <span class="fc-badge">ANALYTICS</span>
                </a>

                <!-- Live Feed -->
                <a href="/ui/feed" class="feature-card">
                    <div class="fc-header">
                        <div class="fc-icon"><i class="fa-solid fa-newspaper"></i></div>
                        <div class="fc-title">Live Feed (JSON)</div>
                    </div>
                    <p class="fc-desc">Quick endpoint — get the most recent articles across all sources rendered in a styled viewer.</p>
                    <span class="fc-badge">JSON VIEWER</span>
                </a>

                <!-- Source List -->
                <a href="/ui/sources" class="feature-card">
                    <div class="fc-header">
                        <div class="fc-icon"><i class="fa-solid fa-satellite-dish"></i></div>
                        <div class="fc-title">Verify Registry State</div>
                    </div>
                    <p class="fc-desc">Check the hardcoded network trust scores, origin metadata, and Israeli-influence booleans applied locally.</p>
                    <span class="fc-badge">SYSTEM STATE</span>
                </a>
            </div>
            
            <div style="margin-top: 60px; padding-top: 20px; border-top: 1px solid #e9ecef; color: #6c757d; font-size: 13px;">
                ARGOS Operational UI • Designed with VSDocs Inspiration • Built by EGen Labs
            </div>
        </div>
    </main>

    <script>
        async function fetchHealth() {
            try {
                const response = await fetch('/v1/health');
                const data = await response.json();
                
                const banner = document.getElementById('status-banner');
                const text = document.getElementById('status-text');

                if (data.status === 'ok' && data.db_connected) {
                    text.textContent = 'All Pipeline Systems Operational & Responsive';
                    document.getElementById('stat-articles').textContent = data.article_count.toLocaleString();
                    
                    const h = Math.floor(data.uptime_seconds / 3600);
                    const m = Math.floor((data.uptime_seconds % 3600) / 60);
                    document.getElementById('stat-uptime').textContent = h > 0 ? `${h}h ${m}m` : `${m}m`;
                } else {
                    throw new Error("DB Disconnected");
                }
            } catch (err) {
                const banner = document.getElementById('status-banner');
                banner.style.backgroundColor = '#f8d7da';
                banner.style.borderColor = '#f5c6cb';
                
                const dot = document.querySelector('.status-dot');
                dot.style.backgroundColor = '#dc3545';
                dot.style.boxShadow = 'none';
                dot.style.animation = 'none';

                const text = document.getElementById('status-text');
                text.textContent = 'System Outage: Unable to connect to backend processes.';
                text.style.color = '#721c24';
            }
        }
        
        fetchHealth();
    </script>
</body>
</html>"""
