"""
ARGOS — Scrapy Settings
=========================
Fully documented configuration for the ARGOS scraping engine.

Every setting has an inline comment explaining:
  1. What it controls
  2. Why it's set to this specific value
  3. What happens if it's wrong

Settings are grouped by function:
  - Project identity
  - Politeness & rate limiting (L-04)
  - Download behavior
  - Pipeline configuration
  - Middleware configuration
  - Logging
  - Job persistence (L-02)
  - Proxy support (L-08)

Requirement refs: C-01, FR-04, FR-07, FR-08
"""

import os

from dotenv import load_dotenv

# Load .env file for DATABASE_PATH, PROXY_URL, LOG_LEVEL, JOBDIR
load_dotenv()


# ============================================================================
# PROJECT IDENTITY
# ============================================================================

# BOT_NAME — identifies this Scrapy project.
# Used as the default User-Agent prefix if no middleware overrides it.
# We override UA via UserAgentRotatorMiddleware, but this is still needed
# for Scrapy's internal identification.
BOT_NAME = "argos"

# SPIDER_MODULES — where Scrapy looks for spider classes.
# Must point to the package containing all spider .py files.
SPIDER_MODULES = ["scraper.argos.spiders"]

# NEWSPIDER_MODULE — where `scrapy genspider` creates new spiders.
# Same as SPIDER_MODULES for simplicity.
NEWSPIDER_MODULE = "scraper.argos.spiders"


# ============================================================================
# POLITENESS & RATE LIMITING (L-04)
# ============================================================================
# These settings prevent ARGOS from being detected as a bot or getting
# IP-banned by source websites. They trade crawl speed for reliability.

# DOWNLOAD_DELAY — minimum pause between requests to the SAME domain, in seconds.
# 2 seconds is a safe, polite interval tested against all 4 sources.
# Going below 1s triggers rate limiting on Al Jazeera and Sky News Arabia.
# Set per-spider if a source tolerates faster crawling.
DOWNLOAD_DELAY = 2

# CONCURRENT_REQUESTS — max simultaneous requests across ALL domains.
# Kept low (8) to avoid overwhelming the home server's network and
# to reduce the chance of IP bans across multiple sources.
CONCURRENT_REQUESTS = 8

# CONCURRENT_REQUESTS_PER_DOMAIN — max simultaneous requests to ONE domain.
# Kept at 2 to ensure politeness. Even with 4 domains running concurrently,
# each individual source only sees 2 parallel requests at most.
CONCURRENT_REQUESTS_PER_DOMAIN = 2

# RANDOMIZE_DOWNLOAD_DELAY — adds ±50% randomness to DOWNLOAD_DELAY.
# Makes the crawl pattern look more human-like (not a perfect 2s rhythm).
# This significantly reduces detection by simple bot-detection systems.
RANDOMIZE_DOWNLOAD_DELAY = True

# AUTOTHROTTLE — Scrapy's adaptive throttling system.
# Automatically adjusts download delay based on server response times.
# If a server responds slowly (overloaded), Scrapy backs off automatically.
# This is the primary defense against accidentally DDoS-ing a source.
AUTOTHROTTLE_ENABLED = True

# AUTOTHROTTLE_START_DELAY — initial delay before AutoThrottle adjusts.
# Starts at the DOWNLOAD_DELAY value (2s). AutoThrottle will increase
# or decrease from here based on server response latency.
AUTOTHROTTLE_START_DELAY = 2

# AUTOTHROTTLE_MAX_DELAY — maximum delay AutoThrottle can impose.
# If a server is very slow, AutoThrottle won't wait more than 30s.
# Prevents the spider from stalling indefinitely on a slow server.
AUTOTHROTTLE_MAX_DELAY = 30

# AUTOTHROTTLE_TARGET_CONCURRENCY — desired parallel requests per server.
# 1.0 means AutoThrottle tries to keep exactly 1 request in-flight
# per domain at a time. This is the most polite setting.
AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0

# AUTOTHROTTLE_DEBUG — log AutoThrottle decisions at DEBUG level.
# Useful for tuning but very verbose. Disable in production.
AUTOTHROTTLE_DEBUG = False


# ============================================================================
# ROBOTS.TXT
# ============================================================================

# ROBOTSTXT_OBEY — whether to respect robots.txt directives.
# Set to True for ethical crawling. If a source blocks our bot in robots.txt,
# we respect that and skip those URLs.
# Set to False only if you have explicit permission from the source.
ROBOTSTXT_OBEY = True


# ============================================================================
# RETRY CONFIGURATION
# ============================================================================
# Handles transient failures (timeouts, 500 errors, rate limiting).

# RETRY_ENABLED — whether to retry failed requests.
# Must be True — news sites have intermittent failures, and skipping
# articles due to a single timeout is unacceptable for completeness.
RETRY_ENABLED = True

# RETRY_TIMES — how many times to retry a failed request.
# 5 retries with exponential backoff gives ~1 minute of total retry window.
# After 5 failures, the request is dropped and a warning is logged.
RETRY_TIMES = 5

# RETRY_HTTP_CODES — which HTTP status codes trigger a retry.
# 429: Rate limited (wait and retry)
# 500, 502, 503, 504: Server errors (usually transient)
# 408: Request timeout
RETRY_HTTP_CODES = [429, 500, 502, 503, 504, 408]


# ============================================================================
# DOWNLOAD SETTINGS
# ============================================================================

# DOWNLOAD_TIMEOUT — max seconds to wait for a response before timing out.
# 30s is generous but accounts for slow archive pages on older articles.
DOWNLOAD_TIMEOUT = 30

# COOKIES_ENABLED — whether to send/track cookies.
# Enabled because some news sites (especially Al Arabiya) use cookies
# for session management and may block requests without them.
COOKIES_ENABLED = True

# HTTPCACHE_ENABLED — whether to cache HTTP responses locally.
# Disabled in production — we want fresh data, not cached articles.
# Enable for development/testing to avoid re-downloading pages.
HTTPCACHE_ENABLED = False


# ============================================================================
# ITEM PIPELINES
# ============================================================================
# Processing chain for scraped items. Lower number = higher priority.
# Items flow through pipelines in ascending order: 100 → 200 → 800.

ITEM_PIPELINES = {
    # Priority 100: Validation — checks all 13 fields and enum values.
    # Must run first so invalid items never reach dedup or storage.
    "scraper.argos.pipelines.validation.ValidationPipeline": 100,

    # Priority 200: Deduplication — drops duplicate source_urls.
    # Runs after validation so we don't waste dedup effort on invalid items.
    "scraper.argos.pipelines.dedup.DeduplicationPipeline": 200,

    # Priority 800: Storage — writes to SQLite.
    # Runs last so only valid, unique items reach the database.
    "scraper.argos.pipelines.storage.StoragePipeline": 800,
}


# ============================================================================
# DOWNLOADER MIDDLEWARES
# ============================================================================
# Custom middlewares that intercept requests before they're sent.

DOWNLOADER_MIDDLEWARES = {
    # UserAgentRotatorMiddleware — rotates User-Agent headers on every request.
    # Prevents detection by sites that block requests from a single UA.
    # Priority 400: runs before Scrapy's default UA middleware (500).
    "scraper.argos.middlewares.UserAgentRotatorMiddleware": 400,

    # Disable Scrapy's built-in UserAgentMiddleware since we have our own.
    "scrapy.downloadermiddlewares.useragent.UserAgentMiddleware": None,
}


# ============================================================================
# LOGGING
# ============================================================================

# LOG_LEVEL — controls verbosity of Scrapy's internal logging.
# Read from environment so it can be changed without editing code.
# DEBUG: See everything (spider activity, SQL, AutoThrottle decisions)
# INFO: Normal operation (summaries, pipeline stats)
# WARNING: Only problems (validation failures, network errors)
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")

# LOG_FORMAT — standardized log format with timestamp and module name.
# Includes %(name)s so you can tell which pipeline/spider logged the message.
LOG_FORMAT = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"

# LOG_DATEFORMAT — ISO 8601 date format in logs for consistency.
LOG_DATEFORMAT = "%Y-%m-%dT%H:%M:%S"


# ============================================================================
# JOB PERSISTENCE — Resumable Crawls (L-02)
# ============================================================================
# JOBDIR enables Scrapy's built-in crawl state persistence.
# If the home server crashes or the spider is interrupted mid-crawl,
# you can resume from where it left off by running the same command again.
#
# Each spider should be run with its own JOBDIR subdirectory:
#   scrapy crawl aljazeera -s JOBDIR=./data/crawl_jobs/aljazeera
#
# Or set JOBDIR here as a base path — spiders will use it automatically.
# Read from environment for flexibility.

JOBDIR = os.environ.get("JOBDIR", "")


# ============================================================================
# PROXY CONFIGURATION (L-08: Geo-blocking from Tunisia)
# ============================================================================
# If the home server's IP is geo-blocked by any source website,
# set PROXY_URL in .env to route requests through a proxy.
#
# Example: PROXY_URL=http://user:pass@proxy.example.com:8080
# Leave empty to connect directly (no proxy).
#
# The proxy is applied in UserAgentRotatorMiddleware if set.

PROXY_URL = os.environ.get("PROXY_URL", "")


# ============================================================================
# FEED EXPORT (disabled — we use our own storage pipeline)
# ============================================================================
# Scrapy's built-in feed export is not used. All storage goes through
# StoragePipeline → SQLite. These settings are here for completeness.

FEEDS = {}

# ============================================================================
# REQUEST FINGERPRINTING
# ============================================================================
# Use Scrapy 2.7+ request fingerprinter for better dedup accuracy.
REQUEST_FINGERPRINTER_IMPLEMENTATION = "2.7"

# ============================================================================
# TWISTED REACTOR
# ============================================================================
# Use the asyncio reactor for compatibility with async libraries.
TWISTED_REACTOR = "twisted.internet.asyncioreactor.AsyncioSelectorReactor"
