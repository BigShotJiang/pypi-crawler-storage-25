# ============================================================================
# ARGOS Scrapy Project Package
# ============================================================================
# Core package for the ARGOS Scrapy project. This is the module referenced
# by scrapy.cfg's [settings] directive as 'scraper.argos.settings'.
#
# Sub-packages:
#   - spiders/   — One spider per source network (4 total)
#   - pipelines/ — Validation → Dedup → Storage processing chain
#
# Key modules:
#   - items.py      — ArticleItem definition (all 13 fields)
#   - registry.py   — SOURCE_REGISTRY + apply_registry()
#   - settings.py   — Fully documented Scrapy configuration
#   - middlewares.py — UA rotation + proxy support
# ============================================================================
