# ============================================================================
# ARGOS Pipelines Package
# ============================================================================
# Processing chain that every scraped article passes through:
#
#   Priority 100 → validation.py  — Checks all 13 fields, validates enums
#   Priority 200 → dedup.py       — Drops duplicate URLs within a session
#   Priority 800 → storage.py     — Writes to SQLite with upsert logic
#
# Items flow through pipelines in ascending priority order.
# If any pipeline raises DropItem, the article is discarded and logged
# but does NOT stop the spider — other articles continue processing.
#
# Requirement refs: FR-05, FR-06, FR-09, FR-10
# ============================================================================
