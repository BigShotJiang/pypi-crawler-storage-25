"""
ARGOS — Storage Pipeline
==========================
Priority: 800 (runs LAST — after validation and dedup)

Writes validated, unique ArticleItems to the local SQLite database.

Storage strategy:
  - Uses INSERT OR IGNORE with a UNIQUE constraint on source_url.
    This means if an article with the same URL already exists in the
    database (from a previous crawl session), the new insert is silently
    ignored — no error, no duplicate.
  - The database file is created automatically on first spider open.
  - The articles table and all indexes are created if they don't exist.

Performance considerations:
  - Items are batched: accumulated in memory and flushed to disk every
    BATCH_SIZE items (default 50). This reduces disk I/O dramatically
    compared to committing after every single insert.
  - The batch is also flushed when the spider closes, to ensure no items
    are lost at the end of a crawl.
  - WAL (Write-Ahead Logging) mode is enabled on the SQLite connection
    for better concurrent read/write performance — important when the
    API server reads while spiders are writing.

Database schema:
  - Primary key: auto-incrementing integer `id`
  - UNIQUE index on `source_url` for dedup
  - Indexes on: published_at, source_name, country, category, orientation
    (for fast API query filtering per FR-14, FR-18)
  - tags stored as JSON string (SQLite has no native array type)

Requirement refs: FR-05, FR-06, FR-11, FR-13, FR-14, FR-15
"""

import json
import logging
import os
import sqlite3

from dotenv import load_dotenv

# Load environment variables from .env file if it exists.
# This allows DATABASE_PATH to be configured via .env.
load_dotenv()


class StoragePipeline:
    """
    Writes ArticleItems to the local SQLite database.

    Creates the database and articles table on first use.
    Uses INSERT OR IGNORE for idempotent writes (cross-session dedup).
    Batches inserts for performance.
    """

    # Number of items to accumulate before committing to disk.
    # 50 is a balance between memory usage and I/O efficiency.
    # Higher values = fewer disk writes but more memory.
    # Lower values = more disk writes but less data at risk on crash.
    BATCH_SIZE = 50

    def __init__(self):
        self.connection = None
        self.cursor = None
        self.batch = []          # Accumulates items before flushing
        self.items_stored = 0    # Counter for successfully stored items
        self.items_skipped = 0   # Counter for dedup-skipped items
        self.logger = logging.getLogger(__name__)

    def open_spider(self, spider):
        """
        Called when the spider opens. Initializes the database connection
        and creates the articles table if it doesn't exist.

        The DATABASE_PATH is read from environment variables with a
        fallback to ./data/argos.db. The directory is created automatically.
        """
        # Read database path from environment.
        # Default: ./data/argos.db relative to the project root.
        db_path = os.environ.get("DATABASE_PATH", "./data/argos.db")

        # Ensure the directory exists — create it if not.
        db_dir = os.path.dirname(db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)

        self.logger.info(
            "StoragePipeline: Opening database at '%s' for spider '%s'",
            db_path, spider.name
        )

        # Open SQLite connection with WAL mode for concurrent read/write.
        # WAL mode allows the API server to read the database while
        # spiders are writing — without blocking either side.
        self.connection = sqlite3.connect(db_path)
        self.connection.execute("PRAGMA journal_mode=WAL")

        # Enable foreign keys (not used yet, but good practice).
        self.connection.execute("PRAGMA foreign_keys=ON")

        self.cursor = self.connection.cursor()

        # Create the articles table if it doesn't exist.
        # This makes the pipeline self-bootstrapping — no separate
        # migration step needed.
        self._create_table()

        self.logger.info(
            "StoragePipeline: Database ready for spider '%s'",
            spider.name
        )

    def close_spider(self, spider):
        """
        Called when the spider closes. Flushes any remaining items
        in the batch buffer and closes the database connection.
        """
        # Flush remaining items that haven't reached BATCH_SIZE.
        if self.batch:
            self._flush_batch()

        # Close the database connection cleanly.
        if self.connection:
            self.connection.close()

        self.logger.info(
            "StoragePipeline results for '%s': "
            "%d items stored, %d duplicates skipped",
            spider.name, self.items_stored, self.items_skipped
        )

    def process_item(self, item, spider):
        """
        Adds an item to the batch buffer. When the batch reaches
        BATCH_SIZE, all items are flushed to the database in one commit.

        Args:
            item: ArticleItem (already validated and dedup-checked).
            spider: The spider that produced the item.

        Returns:
            The item unchanged (items continue through the pipeline).
        """
        self.batch.append(dict(item))

        if len(self.batch) >= self.BATCH_SIZE:
            self._flush_batch()

        return item

    def _flush_batch(self):
        """
        Writes all items in the batch buffer to the database.

        Uses INSERT OR IGNORE — if an article with the same source_url
        already exists, the insert is silently skipped (no error).
        This handles cross-session deduplication.

        The entire batch is committed in a single transaction for
        atomicity and performance.
        """
        if not self.batch:
            return

        # INSERT OR IGNORE: If the UNIQUE constraint on source_url is
        # violated (article already in DB), the row is silently skipped.
        # This is the cross-session dedup mechanism — complements the
        # in-memory dedup in the DeduplicationPipeline.
        insert_sql = """
            INSERT OR IGNORE INTO articles (
                title, content, summary, category, tags,
                source_name, source_url, published_at, scraped_at,
                country, orientation, trust_score, is_israeli_influenced
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        try:
            for article in self.batch:
                # Convert tags list to JSON string for SQLite storage.
                # SQLite has no native array type, so we serialize as JSON.
                # The API layer deserializes back to a list when reading.
                tags_json = json.dumps(article.get("tags", []))

                self.cursor.execute(insert_sql, (
                    article["title"],
                    article["content"],
                    article["summary"],
                    article["category"],
                    tags_json,
                    article["source_name"],
                    article["source_url"],
                    article["published_at"],
                    article["scraped_at"],
                    article["country"],
                    article["orientation"],
                    article["trust_score"],
                    1 if article["is_israeli_influenced"] else 0,  # bool→int
                ))

                # Check if the row was actually inserted or skipped.
                if self.cursor.rowcount > 0:
                    self.items_stored += 1
                else:
                    self.items_skipped += 1

            # Commit the entire batch in one transaction.
            self.connection.commit()

        except sqlite3.Error as e:
            # Log the error but do NOT crash the spider.
            # The batch is lost but the spider continues with the next batch.
            # This aligns with FR-08: source unavailability doesn't halt pipeline.
            self.logger.error(
                "StoragePipeline: Database error during batch flush: %s", e
            )
            self.connection.rollback()

        finally:
            # Clear the batch buffer regardless of success or failure.
            self.batch = []

    def _create_table(self):
        """
        Creates the articles table and indexes if they don't exist.

        The schema mirrors the 13-field ARGOS data model exactly:
          - source_url has a UNIQUE constraint for cross-session dedup
          - is_israeli_influenced stored as INTEGER (0/1) since SQLite
            has no native boolean type
          - tags stored as TEXT (JSON serialized list)
          - published_at and scraped_at stored as TEXT (ISO 8601 strings)

        Indexes are created on fields commonly used in API query filters
        (FR-14, FR-18): published_at, source_name, country, category,
        orientation. These ensure fast WHERE clause execution even with
        2M+ rows.
        """
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS articles (
                -- Auto-incrementing primary key.
                -- Used as the article ID in API responses.
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                -- Content fields (from article HTML)
                title TEXT NOT NULL,
                content TEXT NOT NULL DEFAULT '',
                summary TEXT NOT NULL DEFAULT '',

                -- Classification (assigned at ingest)
                category TEXT NOT NULL,
                tags TEXT NOT NULL DEFAULT '[]',

                -- Source identity
                source_name TEXT NOT NULL,
                source_url TEXT NOT NULL UNIQUE,

                -- Timestamps (ISO 8601 UTC strings)
                published_at TEXT NOT NULL,
                scraped_at TEXT NOT NULL,

                -- Registry-derived metadata
                country TEXT NOT NULL,
                orientation TEXT NOT NULL,
                trust_score REAL NOT NULL,
                is_israeli_influenced INTEGER NOT NULL DEFAULT 0
            )
        """)

        # --- Indexes for API query performance ---
        # Each index accelerates specific filter queries from FR-18.

        # Index on published_at: Most common sort/filter field.
        # Used by: GET /v1/articles?date_from=...&date_to=...
        # Also used for default sort (published_at DESC).
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_articles_published_at
            ON articles (published_at)
        """)

        # Index on source_name: Filter by news network.
        # Used by: GET /v1/articles?source_name=Al+Jazeera
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_articles_source_name
            ON articles (source_name)
        """)

        # Index on country: Filter by network's country of origin.
        # Used by: GET /v1/articles?country=Qatar
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_articles_country
            ON articles (country)
        """)

        # Index on category: Filter by topic.
        # Used by: GET /v1/articles?category=politics
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_articles_category
            ON articles (category)
        """)

        # Index on orientation: Filter by editorial leaning.
        # Used by: GET /v1/articles?orientation=left
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_articles_orientation
            ON articles (orientation)
        """)

        # Composite index for common multi-filter queries.
        # Accelerates queries like: "politics articles from Al Jazeera"
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_articles_source_category
            ON articles (source_name, category)
        """)

        self.connection.commit()

        self.logger.info("StoragePipeline: Table 'articles' and indexes ready")
