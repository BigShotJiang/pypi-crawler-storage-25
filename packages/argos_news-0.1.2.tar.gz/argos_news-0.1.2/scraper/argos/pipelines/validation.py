"""
ARGOS — Validation Pipeline
=============================
Priority: 100 (runs FIRST in the pipeline chain)

Validates every ArticleItem against the ARGOS data model requirements:
  1. All 13 required fields must be present and non-null
  2. Content fields (title, summary) must be non-empty strings
  3. content is allowed to be empty ("") — indicates paywall/deleted (L-05)
  4. category must be in CATEGORY_VALUES enum
  5. orientation must be in ORIENTATION_VALUES enum
  6. trust_score must be a float in range 0.0–1.0
  7. is_israeli_influenced must be a boolean
  8. tags must be a list (empty [] is valid)
  9. source_url must start with http:// or https://
  10. published_at and scraped_at must be non-empty strings

If any validation fails, the item is DROPPED with a DropItem exception
that logs the specific field and article URL for debugging.

This pipeline is intentionally strict — it's better to reject bad data
at ingest than to pollute the database with invalid records.

Requirement refs: FR-05
"""

import logging

from scrapy.exceptions import DropItem


# ============================================================================
# Enum Allowed Values — from context.md Section 3
# ============================================================================
# These are the ONLY valid values for category and orientation fields.
# Any value not in these sets causes the item to be dropped.

CATEGORY_VALUES = {
    "politics", "economy", "tech", "war", "health",
    "science", "culture", "sports", "environment", "other"
}

ORIENTATION_VALUES = {
    "left", "center-left", "center", "center-right",
    "right", "far-right", "state", "zionist", "unknown"
}

# ============================================================================
# All 13 fields that MUST be present on every ArticleItem.
# This list is used for the presence check — every field must exist
# as a key in the item dict and must not be None.
# ============================================================================

REQUIRED_FIELDS = [
    "title", "content", "summary", "category", "tags",
    "source_name", "source_url", "published_at", "scraped_at",
    "country", "orientation", "trust_score", "is_israeli_influenced"
]


class ValidationPipeline:
    """
    Validates ArticleItems against the ARGOS data model.

    Runs at priority 100 — before deduplication and storage.
    Drops invalid items with descriptive error messages.

    Every item that passes this pipeline is guaranteed to have:
      - All 13 fields present and with correct types
      - Valid enum values for category and orientation
      - trust_score in the valid range
      - A valid URL for source_url
    """

    def __init__(self):
        # Logger for validation failures.
        # All drops are logged at WARNING level so they're visible in
        # production logs without needing DEBUG mode.
        self.logger = logging.getLogger(__name__)

    def process_item(self, item, spider):
        """
        Validates a single ArticleItem.

        Runs all validation checks in sequence. The first failure
        drops the item — there's no point continuing validation
        if a required field is missing.

        Args:
            item: The ArticleItem to validate.
            spider: The spider that produced the item (for logging context).

        Returns:
            The item unchanged if all validations pass.

        Raises:
            DropItem: If any validation check fails.

        Requirement refs: FR-05
        """
        source_url = item.get("source_url", "UNKNOWN_URL")

        # --- Check 1: All 13 required fields must be present ---
        for field in REQUIRED_FIELDS:
            if field not in item or item[field] is None:
                self.logger.warning(
                    "VALIDATION FAILED: Missing field '%s' in article: %s",
                    field, source_url
                )
                raise DropItem(
                    f"Missing required field '{field}' — URL: {source_url}"
                )

        # --- Check 2: title must be non-empty ---
        # An article without a headline is not a valid article.
        if not isinstance(item["title"], str) or not item["title"].strip():
            self.logger.warning(
                "VALIDATION FAILED: Empty title in article: %s", source_url
            )
            raise DropItem(f"Empty title — URL: {source_url}")

        # --- Check 3: summary must be non-empty ---
        if not isinstance(item["summary"], str) or not item["summary"].strip():
            self.logger.warning(
                "VALIDATION FAILED: Empty summary in article: %s", source_url
            )
            raise DropItem(f"Empty summary — URL: {source_url}")

        # --- Check 4: content must be a string (empty is OK per L-05) ---
        # Paywalled or deleted articles store content="" — this is valid.
        # The article is still kept for its title, URL, and metadata.
        if not isinstance(item["content"], str):
            self.logger.warning(
                "VALIDATION FAILED: content is not a string in article: %s",
                source_url
            )
            raise DropItem(f"content is not a string — URL: {source_url}")

        if not item["content"].strip():
            # Log empty content as a notice — it's valid but worth tracking.
            self.logger.info(
                "NOTICE: Empty content for article (paywall/deleted?): %s",
                source_url
            )

        # --- Check 5: category must be a valid enum value ---
        if item["category"] not in CATEGORY_VALUES:
            self.logger.warning(
                "VALIDATION FAILED: Invalid category '%s' in article: %s",
                item["category"], source_url
            )
            raise DropItem(
                f"Invalid category '{item['category']}' — "
                f"allowed: {CATEGORY_VALUES} — URL: {source_url}"
            )

        # --- Check 6: orientation must be a valid enum value ---
        if item["orientation"] not in ORIENTATION_VALUES:
            self.logger.warning(
                "VALIDATION FAILED: Invalid orientation '%s' in article: %s",
                item["orientation"], source_url
            )
            raise DropItem(
                f"Invalid orientation '{item['orientation']}' — "
                f"allowed: {ORIENTATION_VALUES} — URL: {source_url}"
            )

        # --- Check 7: trust_score must be float in [0.0, 1.0] ---
        try:
            score = float(item["trust_score"])
            if not (0.0 <= score <= 1.0):
                raise ValueError(f"out of range: {score}")
        except (TypeError, ValueError) as e:
            self.logger.warning(
                "VALIDATION FAILED: Invalid trust_score '%s' (%s) in: %s",
                item["trust_score"], e, source_url
            )
            raise DropItem(
                f"Invalid trust_score '{item['trust_score']}' — "
                f"must be float 0.0–1.0 — URL: {source_url}"
            )

        # --- Check 8: is_israeli_influenced must be boolean ---
        if not isinstance(item["is_israeli_influenced"], bool):
            self.logger.warning(
                "VALIDATION FAILED: is_israeli_influenced is not bool in: %s",
                source_url
            )
            raise DropItem(
                f"is_israeli_influenced must be bool — URL: {source_url}"
            )

        # --- Check 9: tags must be a list ---
        # Empty list [] is valid — some articles genuinely have no tags.
        if not isinstance(item["tags"], list):
            self.logger.warning(
                "VALIDATION FAILED: tags is not a list in article: %s",
                source_url
            )
            raise DropItem(f"tags must be a list — URL: {source_url}")

        # --- Check 10: source_url must be a valid HTTP(S) URL ---
        if not item["source_url"].startswith(("http://", "https://")):
            self.logger.warning(
                "VALIDATION FAILED: Invalid source_url '%s'",
                source_url
            )
            raise DropItem(
                f"Invalid source_url (must start with http/https) — "
                f"URL: {source_url}"
            )

        # --- Check 11: timestamps must be non-empty strings ---
        for ts_field in ("published_at", "scraped_at"):
            if not isinstance(item[ts_field], str) or not item[ts_field].strip():
                self.logger.warning(
                    "VALIDATION FAILED: Empty %s in article: %s",
                    ts_field, source_url
                )
                raise DropItem(
                    f"Empty {ts_field} — URL: {source_url}"
                )

        # All checks passed — item is valid.
        return item
