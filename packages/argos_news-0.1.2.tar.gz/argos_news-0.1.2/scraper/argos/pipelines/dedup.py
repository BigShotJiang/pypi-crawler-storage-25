"""
ARGOS — Deduplication Pipeline
================================
Priority: 200 (runs AFTER validation, BEFORE storage)

Prevents duplicate articles within a single crawl session by tracking
source_url values in an in-memory set.

How dedup works at each layer:
  - THIS pipeline: In-memory set catches duplicates within a single
    spider run (e.g., same article linked from multiple listing pages).
  - Storage pipeline: SQLite upsert (INSERT OR IGNORE on source_url)
    catches cross-session duplicates (e.g., re-crawling pages already
    scraped yesterday). See pipelines/storage.py.

Why in-memory only (not persistent)?
  - Scrapy sessions are ephemeral — when the spider finishes, memory is freed.
  - Persistent dedup across sessions is handled by the database's UNIQUE
    constraint on source_url, which is more reliable.
  - In-memory dedup is fast (O(1) lookup) and has zero disk overhead.

Note: The set grows unbounded during a session. For the historical backlog
(~2.2M articles), this could use significant memory (~200 MB for URLs).
This is acceptable for a home server with ≥4 GB RAM.

Requirement refs: FR-06
"""

import logging

from scrapy.exceptions import DropItem


class DeduplicationPipeline:
    """
    Drops duplicate articles within a single crawl session.

    Uses an in-memory set of source_url values for O(1) lookups.
    Cross-session deduplication is handled by the storage layer's
    UNIQUE constraint — this pipeline only catches intra-session dupes.
    """

    def __init__(self):
        # Set of already-seen source URLs in this crawl session.
        # Populated as items flow through the pipeline.
        self.seen_urls = set()

        # Counter for tracking how many duplicates were caught.
        # Logged at INFO level when the spider closes.
        self.duplicate_count = 0

        self.logger = logging.getLogger(__name__)

    def open_spider(self, spider):
        """
        Called when the spider opens. Resets the dedup state.

        Each spider gets its own pipeline instance, so the set is
        already empty — but we reset explicitly for clarity.
        """
        self.seen_urls = set()
        self.duplicate_count = 0
        self.logger.info(
            "DeduplicationPipeline initialized for spider '%s'",
            spider.name
        )

    def close_spider(self, spider):
        """
        Called when the spider closes. Logs dedup statistics.

        This helps operators understand how many duplicate URLs were
        encountered — useful for tuning spider pagination logic.
        """
        self.logger.info(
            "DeduplicationPipeline results for '%s': "
            "%d unique articles passed, %d duplicates dropped",
            spider.name, len(self.seen_urls), self.duplicate_count
        )

    def process_item(self, item, spider):
        """
        Checks if the article's source_url has already been seen.

        If the URL is new, it's added to the set and the item passes through.
        If the URL is a duplicate, the item is dropped with a DropItem exception.

        Args:
            item: The ArticleItem to check (already validated by priority 100).
            spider: The spider that produced the item.

        Returns:
            The item unchanged if the URL is new.

        Raises:
            DropItem: If the source_url was already seen in this session.

        Requirement refs: FR-06
        """
        source_url = item.get("source_url", "")

        if source_url in self.seen_urls:
            self.duplicate_count += 1
            self.logger.debug(
                "DEDUP: Dropping duplicate article: %s", source_url
            )
            raise DropItem(f"Duplicate source_url: {source_url}")

        # URL is new — add it to the seen set and let the item through.
        self.seen_urls.add(source_url)
        return item
