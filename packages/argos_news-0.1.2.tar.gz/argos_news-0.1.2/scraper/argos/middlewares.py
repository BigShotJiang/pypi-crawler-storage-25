"""
ARGOS — Scrapy Middlewares
============================
Custom downloader middlewares for the ARGOS scraping engine.

Contains:
  - UserAgentRotatorMiddleware: Rotates User-Agent headers on every request
    to avoid bot detection (L-04). Also handles optional proxy routing (L-08).

Why rotate User-Agents?
  News websites track User-Agent strings to detect bots. If every request
  comes with the same UA (e.g., "Scrapy/2.11"), the site will quickly
  block the IP. By rotating through real browser UAs, our requests look
  like normal human traffic.

The UA pool contains 7 real browser User-Agent strings from the 5 most
common browsers (Chrome, Firefox, Safari, Edge, Opera) on current OS
versions. These are updated periodically — if scraping starts failing,
check if the UA strings are outdated.

Requirement refs: L-04, L-08
"""

import logging
import random

from scrapy import signals


# ============================================================================
# User-Agent Pool
# ============================================================================
# Real browser User-Agent strings from common browsers on common OS versions.
# These make our requests indistinguishable from normal web browsing.
#
# Each UA is chosen because:
#   1. It represents a widely-used browser (high global market share)
#   2. It's a recent version (sites might block very old browsers)
#   3. It includes OS info (Windows/Mac/Linux) for variety
#
# Update these every 6-12 months or when spiders start getting blocked.
# Check https://www.whatismybrowser.com/guides/the-latest-user-agent/
# for current UA strings.

USER_AGENT_POOL = [
    # Chrome on Windows 10 — most common browser/OS combo globally (~65% share)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",

    # Chrome on macOS — second most common desktop combo
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",

    # Firefox on Windows 10 — significant market share (~8%)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) "
    "Gecko/20100101 Firefox/123.0",

    # Firefox on Linux — represents Linux desktop users
    "Mozilla/5.0 (X11; Linux x86_64; rv:123.0) "
    "Gecko/20100101 Firefox/123.0",

    # Safari on macOS — default Mac browser (~18% share)
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.3 Safari/605.1.15",

    # Edge on Windows 10 — Microsoft's Chromium-based browser (~5% share)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",

    # Chrome on Android — represents mobile traffic (useful for sites
    # that serve different content to mobile vs desktop, though we
    # generally want desktop content for full articles)
    "Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
]


class UserAgentRotatorMiddleware:
    """
    Rotates User-Agent headers on every outgoing request.

    Picks a random UA from the pool for each request, making our
    traffic pattern look like multiple different users browsing the site.

    Also applies proxy routing if PROXY_URL is set in the environment
    (L-08: Tunisian IP geo-blocking workaround).

    Priority 400 — runs before Scrapy's default UserAgentMiddleware (500),
    which is disabled in settings.py since this middleware replaces it.
    """

    def __init__(self, proxy_url=""):
        self.logger = logging.getLogger(__name__)
        # PROXY_URL from settings — if set, all requests go through this proxy.
        # This is the workaround for L-08 (Tunisian IP may be geo-blocked).
        self.proxy_url = proxy_url

    @classmethod
    def from_crawler(cls, crawler):
        """
        Factory method — Scrapy calls this to create the middleware instance.
        Reads PROXY_URL from settings (which reads from environment).
        """
        middleware = cls(
            proxy_url=crawler.settings.get("PROXY_URL", "")
        )
        # Connect to spider_opened signal for logging.
        crawler.signals.connect(
            middleware.spider_opened, signal=signals.spider_opened
        )
        return middleware

    def spider_opened(self, spider):
        """Log middleware configuration when spider starts."""
        self.logger.info(
            "UserAgentRotatorMiddleware active for '%s' — "
            "UA pool size: %d, Proxy: %s",
            spider.name,
            len(USER_AGENT_POOL),
            self.proxy_url if self.proxy_url else "disabled (direct connection)"
        )

    def process_request(self, request, spider):
        """
        Called for every outgoing request. Sets a random User-Agent
        and optional proxy.

        Args:
            request: The Scrapy Request object to modify.
            spider: The spider making the request.

        Returns:
            None — modifying the request in-place is the Scrapy convention
            for downloader middlewares.
        """
        # Pick a random User-Agent from the pool.
        # random.choice() is O(1) and cryptographically sufficient for this use.
        selected_ua = random.choice(USER_AGENT_POOL)
        request.headers["User-Agent"] = selected_ua

        # Apply proxy if configured.
        # Scrapy uses the 'proxy' meta key to route requests through a proxy.
        if self.proxy_url:
            request.meta["proxy"] = self.proxy_url

        return None
