"""
Spider: Sky News Arabia
Domain: skynewsarabia.com
Country: UAE | Orientation: center-right | Trust: 0.48 | Israeli-influenced: Yes

Scrapes: Arabic and English news articles from Sky News Arabia.
Historical range: March 29, 2011 → present (continuous)
Pagination: Section listing pages with numbered pagination.

URL structure:
  - Listing: https://www.skynewsarabia.com/middle-east
  - Article: https://www.skynewsarabia.com/middle-east/ARTICLE_ID-slug
  - Sections: /middle-east, /world, /business, /sport, /technology, /varieties

Selectors (as of March 2026):
  - Title: h1.article-title, h1 (main headline)
  - Content: .article-body p, .article__body p
  - Summary: meta[name="description"]
  - Date: meta[property="article:published_time"], time[datetime]
  - Tags: meta[name="keywords"], .tags a

Known quirks:
  - Uses Radware Captcha protection — may challenge automated requests.
    Scrapy's UA rotation and polite delays help avoid triggering it.
    If blocked, configure PROXY_URL in .env (L-08).
  - Site is primarily Arabic; article slugs and some metadata may be
    in Arabic script. Content is stored as-is (UTF-8).
  - Some sections use client-side rendering — article body text is
    typically in static HTML but may require fallback selectors.
  - Article IDs are numeric (e.g., /middle-east/1234567-slug)

Requirement refs: FR-01, FR-02, FR-03, FR-04, FR-05, FR-09, FR-10
"""

import logging
from datetime import datetime, timezone

import scrapy

from scraper.argos.items import ArticleItem
from scraper.argos.registry import apply_registry

logger = logging.getLogger(__name__)


class SkyNewsArabiaSpider(scrapy.Spider):
    """
    Spider for Sky News Arabia (skynewsarabia.com).

    Crawls section listings, follows article links, extracts all 13 fields.
    Uses conservative delays due to Radware bot protection.
    """

    name = "skynewsarabia"
    allowed_domains = ["skynewsarabia.com"]

    # Main section listing pages.
    start_urls = [
        "https://www.skynewsarabia.com/middle-east",
        "https://www.skynewsarabia.com/world",
        "https://www.skynewsarabia.com/business",
        "https://www.skynewsarabia.com/sport",
        "https://www.skynewsarabia.com/technology",
        "https://www.skynewsarabia.com/varieties",
    ]

    # Conservative 4s delay — Sky News Arabia has Radware protection
    # that triggers captchas on aggressive crawling.
    custom_settings = {
        "DOWNLOAD_DELAY": 4,
    }

    start_date = datetime(2011, 3, 29, tzinfo=timezone.utc)

    # Section-to-category mapping.
    SECTION_TO_CATEGORY = {
        "middle-east": "politics",
        "world": "politics",
        "business": "economy",
        "sport": "sports",
        "technology": "tech",
        "varieties": "culture",
        "health": "health",
        "environment": "environment",
        "science": "science",
    }

    def parse(self, response):
        """
        Parses section listing pages.

        Extracts article links and follows pagination.

        Args:
            response: Scrapy Response for the listing page.

        Yields:
            scrapy.Request: Requests for articles and next pages.
        """
        # Extract article links — Sky News Arabia article URLs contain
        # numeric IDs in their paths.
        article_links = response.css("a::attr(href)").getall()

        seen = set()
        for link in article_links:
            full_url = response.urljoin(link)
            if full_url in seen:
                continue
            seen.add(full_url)

            if self._is_article_url(full_url):
                yield scrapy.Request(
                    url=full_url,
                    callback=self.parse_article,
                    errback=self._handle_error,
                )

        # Follow pagination
        next_page = response.css(
            "a.next::attr(href), "
            "a[rel='next']::attr(href), "
            "li.next a::attr(href), "
            ".pagination__next a::attr(href)"
        ).get()

        if next_page:
            yield scrapy.Request(
                url=response.urljoin(next_page),
                callback=self.parse,
            )

    def parse_article(self, response):
        """
        Parses a single Sky News Arabia article page.

        Extracts all 13 ARGOS data model fields.

        Args:
            response: Scrapy Response for the article URL.

        Yields:
            ArticleItem: Fully populated article.

        Requirement refs: FR-05, FR-09, FR-10
        """
        item = ArticleItem()

        # --- Title ---
        item["title"] = (
            response.css("h1.article-title::text").get(default="").strip()
            or response.css("h1::text").get(default="").strip()
            or response.css("meta[property='og:title']::attr(content)").get(default="").strip()
        )

        # --- Content ---
        paragraphs = response.css(
            ".article-body p::text, "
            ".article-body p *::text, "
            ".article__body p::text, "
            ".article__body p *::text, "
            "article .body p::text, "
            "article .body p *::text"
        ).getall()

        item["content"] = "\n".join(p.strip() for p in paragraphs if p.strip())

        if not item["content"]:
            logger.warning(
                "Empty content for Sky News Arabia article: %s", response.url
            )
            item["content"] = ""

        # --- Summary ---
        item["summary"] = (
            response.css("meta[name='description']::attr(content)").get(default="").strip()
            or response.css("meta[property='og:description']::attr(content)").get(default="").strip()
            or (item["content"][:300] if item["content"] else "")
        )

        # --- Published At ---
        published_at = (
            response.css("meta[property='article:published_time']::attr(content)").get(default="")
            or response.css("time[datetime]::attr(datetime)").get(default="")
            or response.css(".article-date::text").get(default="")
        )
        item["published_at"] = published_at.strip() if published_at else ""

        if not item["published_at"]:
            logger.warning(
                "No published_at for Sky News Arabia: %s — using scraped_at",
                response.url
            )
            item["published_at"] = datetime.now(timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            )

        # --- Scraped At (FR-09) ---
        item["scraped_at"] = datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

        # --- Source URL ---
        item["source_url"] = response.url

        # --- Category ---
        item["category"] = self._classify_category(response.url)

        # --- Tags ---
        keywords = response.css(
            "meta[name='keywords']::attr(content)"
        ).get(default="")
        if keywords:
            item["tags"] = [
                tag.strip() for tag in keywords.split(",") if tag.strip()
            ]
        else:
            item["tags"] = response.css(
                ".tags a::text, "
                ".article-tags a::text"
            ).getall()
            item["tags"] = [t.strip() for t in item["tags"] if t.strip()]

        # --- Registry Metadata (FR-10) ---
        item = apply_registry(item, "skynewsarabia.com")

        yield item

    def _classify_category(self, url):
        """Maps Sky News Arabia URL sections to ARGOS categories."""
        from urllib.parse import urlparse
        path = urlparse(url).path.strip("/").lower()
        parts = path.split("/")

        for part in parts:
            if part in self.SECTION_TO_CATEGORY:
                return self.SECTION_TO_CATEGORY[part]

        logger.debug(
            "Category fallback to 'other' for Sky News Arabia: %s", url
        )
        return "other"

    def _is_article_url(self, url):
        """
        Checks if URL is an article.

        Sky News Arabia article URLs contain numeric article IDs.
        Pattern: /section/DIGITS-slug
        """
        import re
        return bool(re.search(r"/\d{5,}-", url))

    def _handle_error(self, failure):
        """Logs request failures (FR-08)."""
        logger.warning(
            "Sky News Arabia request failed: %s — %s",
            failure.request.url,
            failure.getErrorMessage()
        )
