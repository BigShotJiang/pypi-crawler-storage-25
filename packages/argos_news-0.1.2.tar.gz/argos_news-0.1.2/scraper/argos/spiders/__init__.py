# ============================================================================
# ARGOS Spiders Package
# ============================================================================
# Contains one Scrapy spider per source network in the registry:
#   - aljazeera.py      — Al Jazeera (aljazeera.com)
#   - alarabiya.py      — Al Arabiya (alarabiya.net)
#   - skynewsarabia.py  — Sky News Arabia (skynewsarabia.com)
#   - middleeasteye.py  — Middle East Eye (middleeasteye.net)
#
# Each spider follows the same pattern:
#   1. parse() — scrapes listing pages, follows article links
#   2. parse_article() — extracts all 13 fields from article pages
#   3. _classify_category() — maps URL section to category enum
#   4. Calls apply_registry() to attach source metadata
#
# Requirement refs: FR-01, FR-02, FR-03, FR-04, FR-05
# ============================================================================
