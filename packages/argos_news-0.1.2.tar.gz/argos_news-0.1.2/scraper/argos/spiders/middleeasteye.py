"""
Spider: Middle East Eye
Domain: middleeasteye.net
Country: UK (ME Focus) | Orientation: left | Trust: 0.48 | Israeli-influenced: No

Scrapes: English-language news articles from Middle East Eye.
Historical range: March 29, 2011 → present (continuous)
Pagination: Uses ?page=N query parameter on listing pages.
            Confirmed: last page is ~3226 (observed in HTML), indicating
            a large historical archive accessible via pagination.

URL structure:
  - Listing: https://www.middleeasteye.net/news?page=0
  - Article: https://www.middleeasteye.net/news/slug-slug-slug
  - Sections: /news, /opinion, /discover
  - Topics: /topics/war-on-iran, /topics/occupation, etc.
  - Countries: /countries/iran, /countries/egypt, etc.

Selectors (as of March 2026):
  - Title: h1.article-title, h1 (most reliable)
  - Content: .field-name-body p, article p
  - Summary: meta[name="description"], .field-name-field-summary
  - Date: meta[property="article:published_time"], time[datetime]
  - Tags: .field-name-field-topics a, meta[name="keywords"]

Known quirks:
  - Founded in 2014, so articles before that date won't exist.
    The spider handles this gracefully — empty pages = stop pagination.
  - Topic tags (e.g., "War on Iran") in the listing page are useful
    for category classification.
  - Some articles are "Big Story" features with different layout.
  - Pagination starts at ?page=0, not ?page=1.

Requirement refs: FR-01, FR-02, FR-03, FR-04, FR-05, FR-09, FR-10
"""

import logging
from datetime import datetime, timezone

import scrapy

from scraper.argos.items import ArticleItem
from scraper.argos.registry import apply_registry

logger = logging.getLogger(__name__)


class MiddleEastEyeSpider(scrapy.Spider):
    """
    Spider for Middle East Eye (middleeasteye.net).

    Crawls the /news listing pages using ?page=N pagination,
    follows links to articles, extracts all 13 ARGOS fields.

    MEE has a clean pagination system (page=0 to page=3226+)
    making historical archive crawling straightforward.
    """

    name = "middleeasteye"
    allowed_domains = ["middleeasteye.net"]

    # Start with the news listing page and topic pages.
    start_urls = [
        "https://www.middleeasteye.net/news",
        "https://www.middleeasteye.net/opinion",
        "https://www.middleeasteye.net/discover",
    ]

    # MEE is less aggressive about rate limiting.
    # 2s delay is safe here.
    custom_settings = {
        "DOWNLOAD_DELAY": 2,
    }

    start_date = datetime(2011, 3, 29, tzinfo=timezone.utc)

    # Topic-to-category mapping.
    # MEE uses topic labels (in URLs and article tags) rather than sections.
    TOPIC_TO_CATEGORY = {
        "war-on-iran": "war",
        "israel-genocide-gaza": "war",
        "occupation": "war",
        "international-law": "politics",
        "us-muslims": "politics",
        "politics": "politics",
        "diplomacy": "politics",
        "economy": "economy",
        "technology": "tech",
        "sports": "sports",
        "culture": "culture",
        "health": "health",
        "climate": "environment",
        "science": "science",
    }

    # Section path mapping (fallback if topic is not identified)
    SECTION_TO_CATEGORY = {
        "news": "politics",
        "opinion": "politics",
        "discover": "culture",
        "video": "other",
        "explainers": "politics",
    }

    def parse(self, response):
        """
        Parses listing pages with ?page=N pagination.

        Extracts article links and follows to the next page.
        Stops when a page has no article links (end of archive).

        Args:
            response: Scrapy Response for the listing page.

        Yields:
            scrapy.Request: Requests for articles and next page.
        """
        # Extract article links.
        # MEE article URLs follow /news/slug-slug pattern.
        article_links = response.css(
            "a[href*='/news/']::attr(href), "
            "a[href*='/opinion/']::attr(href), "
            "a[href*='/discover/']::attr(href)"
        ).getall()

        # Filter to actual article URLs (not section/topic pages)
        seen = set()
        article_found = False
        for link in article_links:
            full_url = response.urljoin(link)
            if full_url in seen:
                continue
            seen.add(full_url)

            if self._is_article_url(full_url):
                article_found = True
                yield scrapy.Request(
                    url=full_url,
                    callback=self.parse_article,
                    errback=self._handle_error,
                )

        # Follow pagination — MEE uses ?page=N (starting at 0).
        # Only paginate if we found articles on this page.
        if article_found:
            # Look for explicit next page link
            next_page = response.css(
                "li.pager-next a::attr(href), "
                "a[rel='next']::attr(href), "
                "a[title='Go to next page']::attr(href)"
            ).get()

            if next_page:
                yield scrapy.Request(
                    url=response.urljoin(next_page),
                    callback=self.parse,
                )
            else:
                # Fallback: calculate next page from current URL
                from urllib.parse import urlparse, parse_qs, urlencode
                parsed = urlparse(response.url)
                params = parse_qs(parsed.query)
                current_page = int(params.get("page", [0])[0])
                next_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?page={current_page + 1}"
                yield scrapy.Request(
                    url=next_url,
                    callback=self.parse,
                )

    def parse_article(self, response):
        """
        Parses a single Middle East Eye article page.

        Extracts all 13 ARGOS data model fields.
        Uses topic tags from the page for category classification.

        Args:
            response: Scrapy Response for the article URL.

        Yields:
            ArticleItem: Fully populated article.

        Requirement refs: FR-05, FR-09, FR-10
        """
        item = ArticleItem()

        # --- Title ---
        item["title"] = (
            response.css("h1.page-title::text").get(default="").strip()
            or response.css("h1::text").get(default="").strip()
            or response.css("meta[property='og:title']::attr(content)").get(default="").strip()
        )

        # --- Content ---
        # MEE uses .field-name-body for article content.
        paragraphs = response.css(
            ".field-name-body p::text, "
            ".field-name-body p *::text, "
            ".article-body p::text, "
            ".article-body p *::text, "
            "article .body p::text, "
            "article .body p *::text"
        ).getall()

        item["content"] = "\n".join(p.strip() for p in paragraphs if p.strip())

        if not item["content"]:
            logger.warning(
                "Empty content for MEE article: %s", response.url
            )
            item["content"] = ""

        # --- Summary ---
        item["summary"] = (
            response.css("meta[name='description']::attr(content)").get(default="").strip()
            or response.css("meta[property='og:description']::attr(content)").get(default="").strip()
            or response.css(".field-name-field-summary::text").get(default="").strip()
            or (item["content"][:300] if item["content"] else "")
        )

        # --- Published At ---
        published_at = (
            response.css("meta[property='article:published_time']::attr(content)").get(default="")
            or response.css("time[datetime]::attr(datetime)").get(default="")
            or response.css(".date-display-single::attr(content)").get(default="")
        )
        item["published_at"] = published_at.strip() if published_at else ""

        if not item["published_at"]:
            logger.warning(
                "No published_at for MEE article: %s — using scraped_at",
                response.url
            )
            item["published_at"] = datetime.now(timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            )

        # --- Scraped At (FR-09) ---
        item["scraped_at"] = datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

        # --- Source URL ---
        item["source_url"] = response.url

        # --- Category ---
        # Try topic-based classification first (from topic tags on the page),
        # then fall back to URL-based classification.
        item["category"] = self._classify_category(response)

        # --- Tags ---
        # MEE tags come from topic links on the article page.
        tag_texts = response.css(
            ".field-name-field-topics a::text, "
            "a[href*='/topics/']::text, "
            ".article-tags a::text"
        ).getall()
        item["tags"] = list(set(
            t.strip() for t in tag_texts if t.strip()
        ))

        # Also try meta keywords as fallback
        if not item["tags"]:
            keywords = response.css(
                "meta[name='keywords']::attr(content)"
            ).get(default="")
            if keywords:
                item["tags"] = [
                    tag.strip() for tag in keywords.split(",") if tag.strip()
                ]

        # --- Registry Metadata (FR-10) ---
        item = apply_registry(item, "middleeasteye.net")

        yield item

    def _classify_category(self, response):
        """
        Maps MEE article to an ARGOS category.

        First checks topic tags on the page against TOPIC_TO_CATEGORY.
        Falls back to URL path section against SECTION_TO_CATEGORY.

        Args:
            response: The Scrapy Response (for both URL and page content).

        Returns:
            str: Category enum value.
        """
        # Try topic-based classification from page content.
        # MEE articles often have topic links like "War on Iran" or "Occupation".
        topics = response.css(
            "a[href*='/topics/']::attr(href)"
        ).getall()

        for topic_url in topics:
            # Extract topic slug from URL: /topics/war-on-iran → war-on-iran
            slug = topic_url.strip("/").split("/")[-1].lower()
            if slug in self.TOPIC_TO_CATEGORY:
                return self.TOPIC_TO_CATEGORY[slug]

        # Fallback: URL path section
        from urllib.parse import urlparse
        path = urlparse(response.url).path.strip("/")
        section = path.split("/")[0].lower() if path else ""

        if section in self.SECTION_TO_CATEGORY:
            return self.SECTION_TO_CATEGORY[section]

        logger.debug(
            "Category fallback to 'other' for MEE article: %s",
            response.url
        )
        return "other"

    def _is_article_url(self, url):
        """
        Checks if URL is an article vs section/topic page.

        MEE articles have a slug in the path: /news/some-article-slug
        Section pages are just: /news or /news?page=3
        Topic pages are: /topics/war-on-iran or /countries/iran
        """
        from urllib.parse import urlparse
        path = urlparse(url).path.strip("/")
        parts = path.split("/")

        # Must have at least 2 path segments (section/slug)
        # and the slug should contain hyphens (article slugs always do)
        if len(parts) >= 2:
            slug = parts[-1]
            # Exclude non-article paths
            if parts[0] in ("topics", "countries", "video"):
                return False
            # Article slugs typically have multiple hyphen-separated words
            return "-" in slug and not slug.startswith("page")

        return False

    def _handle_error(self, failure):
        """Logs request failures (FR-08)."""
        logger.warning(
            "MEE request failed: %s — %s",
            failure.request.url,
            failure.getErrorMessage()
        )
