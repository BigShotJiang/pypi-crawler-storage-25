"""
Spider: Al Arabiya
Domain: english.alarabiya.net (English edition)
Country: Saudi Arabia | Orientation: right | Trust: 0.40 | Israeli-influenced: Yes

Scrapes: English news articles from Al Arabiya English.
Historical range: March 29, 2011 → present (continuous)
Pagination: Section listing pages at /News/, /Business/, /Sports/ etc.
            Historical access via date-based archive browsing.

URL structure:
  - Listing: https://english.alarabiya.net/News
  - Article: https://english.alarabiya.net/News/YYYY/MM/DD/slug
  - Sections: /News/, /Business/, /Sports/, /variety/, /life-style/

Selectors (as of March 2026):
  - Title: h1.article-title or h1 (main headline)
  - Content: .article-body p or .articleBody p
  - Summary: meta[name="description"] or .article-summary
  - Date: meta[property="article:published_time"] or .article-date
  - Tags: meta[name="keywords"] or .article-tags a

Known quirks:
  - Returns HTTP 403 to requests without proper User-Agent headers.
    The UserAgentRotatorMiddleware handles this automatically.
  - Cookies must be enabled (COOKIES_ENABLED=True in settings.py)
    as the site uses session cookies for content access.
  - Some older articles (pre-2015) may have different page templates.
  - The English site uses a different domain prefix (english.alarabiya.net)
    than the Arabic site (alarabiya.net).

Requirement refs: FR-01, FR-02, FR-03, FR-04, FR-05, FR-09, FR-10
"""

import logging
from datetime import datetime, timezone

import scrapy

from scraper.argos.items import ArticleItem
from scraper.argos.registry import apply_registry

logger = logging.getLogger(__name__)


class AlArabiyaSpider(scrapy.Spider):
    """
    Spider for Al Arabiya English (english.alarabiya.net).

    Crawls section listing pages, follows links to articles, and
    extracts all 13 ARGOS data model fields.

    Al Arabiya requires proper UA headers — handled by the
    UserAgentRotatorMiddleware in middlewares.py.
    """

    name = "alarabiya"
    allowed_domains = ["alarabiya.net"]

    # Start with major sections to discover articles.
    start_urls = [
        "https://english.alarabiya.net/News",
        "https://english.alarabiya.net/Business",
        "https://english.alarabiya.net/Sports",
        "https://english.alarabiya.net/variety",
        "https://english.alarabiya.net/life-style",
        "https://english.alarabiya.net/News/middle-east",
        "https://english.alarabiya.net/News/world",
        "https://english.alarabiya.net/News/gulf",
    ]

    # Al Arabiya is more aggressive with rate limiting than Al Jazeera.
    # Using 3s delay instead of the global 2s default.
    custom_settings = {
        "DOWNLOAD_DELAY": 3,
    }

    start_date = datetime(2011, 3, 29, tzinfo=timezone.utc)

    # Section-to-category mapping for Al Arabiya URL paths.
    SECTION_TO_CATEGORY = {
        "news": "politics",
        "middle-east": "politics",
        "world": "politics",
        "gulf": "politics",
        "business": "economy",
        "sports": "sports",
        "variety": "culture",
        "life-style": "culture",
        "technology": "tech",
        "webtv": "other",
        "coronavirus": "health",
    }

    def parse(self, response):
        """
        Parses listing pages to find article links.

        Al Arabiya listing pages contain article cards with links.
        We extract all article-like URLs and follow them.

        Args:
            response: Scrapy Response for the listing page.

        Yields:
            scrapy.Request: Requests for article pages and pagination.
        """
        # Extract article links from listing page.
        # Al Arabiya uses various article card components.
        article_links = response.css(
            "a[href*='/News/']::attr(href), "
            "a[href*='/Business/']::attr(href), "
            "a[href*='/Sports/']::attr(href), "
            "a[href*='/variety/']::attr(href), "
            "a[href*='/life-style/']::attr(href)"
        ).getall()

        seen = set()
        for link in article_links:
            full_url = response.urljoin(link)
            if full_url in seen:
                continue
            seen.add(full_url)

            # Only follow links that contain a date pattern (article pages)
            if self._is_article_url(full_url):
                yield scrapy.Request(
                    url=full_url,
                    callback=self.parse_article,
                    errback=self._handle_error,
                )

        # Follow pagination links
        next_page = response.css(
            "a.next::attr(href), "
            "a[class*='load-more']::attr(href), "
            "li.next a::attr(href), "
            ".pagination a.next::attr(href)"
        ).get()

        if next_page:
            yield scrapy.Request(
                url=response.urljoin(next_page),
                callback=self.parse,
            )

    def parse_article(self, response):
        """
        Parses a single Al Arabiya article page.

        Extracts all 13 ARGOS data model fields.
        Registry metadata comes from apply_registry().

        Args:
            response: Scrapy Response for the article URL.

        Yields:
            ArticleItem: Fully populated article.

        Requirement refs: FR-05, FR-09, FR-10
        """
        item = ArticleItem()

        # --- Title ---
        item["title"] = (
            response.css("h1.article-title::text").get(default="").strip()
            or response.css("h1::text").get(default="").strip()
            or response.css("meta[property='og:title']::attr(content)").get(default="").strip()
        )

        # --- Content ---
        paragraphs = response.css(
            ".article-body p::text, "
            ".article-body p *::text, "
            ".articleBody p::text, "
            ".articleBody p *::text, "
            "article p::text, "
            "article p *::text"
        ).getall()

        item["content"] = "\n".join(p.strip() for p in paragraphs if p.strip())

        if not item["content"]:
            logger.warning(
                "Empty content for Al Arabiya article: %s", response.url
            )
            item["content"] = ""

        # --- Summary ---
        item["summary"] = (
            response.css("meta[name='description']::attr(content)").get(default="").strip()
            or response.css("meta[property='og:description']::attr(content)").get(default="").strip()
            or response.css(".article-summary::text").get(default="").strip()
            or (item["content"][:300] if item["content"] else "")
        )

        # --- Published At ---
        published_at = (
            response.css("meta[property='article:published_time']::attr(content)").get(default="")
            or response.css(".article-date::text").get(default="")
            or response.css("time[datetime]::attr(datetime)").get(default="")
        )
        item["published_at"] = published_at.strip() if published_at else ""

        if not item["published_at"]:
            logger.warning(
                "No published_at for Al Arabiya article: %s — using scraped_at",
                response.url
            )
            item["published_at"] = datetime.now(timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            )

        # --- Scraped At (FR-09) ---
        item["scraped_at"] = datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

        # --- Source URL ---
        item["source_url"] = response.url

        # --- Category ---
        item["category"] = self._classify_category(response.url)

        # --- Tags ---
        keywords = response.css(
            "meta[name='keywords']::attr(content)"
        ).get(default="")
        if keywords:
            item["tags"] = [
                tag.strip() for tag in keywords.split(",") if tag.strip()
            ]
        else:
            item["tags"] = response.css(
                ".article-tags a::text, "
                ".topics a::text"
            ).getall()
            item["tags"] = [t.strip() for t in item["tags"] if t.strip()]

        # --- Registry Metadata (FR-10) ---
        item = apply_registry(item, "alarabiya.net")

        yield item

    def _classify_category(self, url):
        """
        Maps Al Arabiya URL sections to ARGOS category values.

        Args:
            url: The full article URL.

        Returns:
            str: Category enum value.
        """
        from urllib.parse import urlparse
        path = urlparse(url).path.strip("/").lower()
        parts = path.split("/")

        # Check each path segment against the mapping
        for part in parts:
            if part in self.SECTION_TO_CATEGORY:
                return self.SECTION_TO_CATEGORY[part]

        logger.debug(
            "Category fallback to 'other' for Al Arabiya URL: %s", url
        )
        return "other"

    def _is_article_url(self, url):
        """Checks if URL contains a date pattern indicating an article."""
        import re
        return bool(re.search(r"/\d{4}/\d{2}/\d{2}/", url))

    def _handle_error(self, failure):
        """Logs request failures without crashing the spider (FR-08)."""
        logger.warning(
            "Al Arabiya request failed: %s — %s",
            failure.request.url,
            failure.getErrorMessage()
        )
