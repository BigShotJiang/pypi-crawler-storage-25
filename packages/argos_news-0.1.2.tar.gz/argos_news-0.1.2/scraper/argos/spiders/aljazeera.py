"""
Spider: Al Jazeera
Domain: aljazeera.com
Country: Qatar | Orientation: center-left | Trust: 0.55 | Israeli-influenced: No

Scrapes: English news articles from the main news section.
Historical range: March 29, 2011 → present (continuous)
Pagination: Follows article links from listing pages. Historical crawl uses
            the sitemap at /sitemap.xml and archive pages by date.

URL structure:
  - Listing: https://www.aljazeera.com/news/
  - Article: https://www.aljazeera.com/news/YYYY/M/DD/slug
  - Sections: /news/, /economy/, /sports/, /features/, /opinion/

Selectors (as of March 2026):
  - Title: h1 (main headline)
  - Content: .wysiwyg--all-content p (article body paragraphs)
  - Summary: meta[name="description"] content attribute
  - Date: meta[property="article:published_time"] or time[datetime]
  - Tags: meta[name="keywords"] or .article-tags a

Known quirks:
  - Pre-2016 archive pages may use different article card classes — handled
    with fallback selectors in parse_article()
  - Content paywall on premium investigation pieces — stored as content=""
  - Rate limit kicks in at <1s delay; using 2s (L-04)
  - Al Jazeera uses a mix of static HTML and JavaScript-loaded content;
    article body text is in static HTML (no JS rendering needed)

Requirement refs: FR-01, FR-02, FR-03, FR-04, FR-05, FR-09, FR-10
"""

import logging
from datetime import datetime, timezone

import scrapy

from scraper.argos.items import ArticleItem
from scraper.argos.registry import apply_registry

# Logger for this spider — used for category classification fallbacks
# and content extraction warnings.
logger = logging.getLogger(__name__)


class AlJazeeraSpider(scrapy.Spider):
    """
    Spider for Al Jazeera English (aljazeera.com).

    Crawls the news section listing pages, follows links to individual
    articles, and extracts all 13 ARGOS data model fields.

    Registry metadata (country, orientation, trust_score, is_israeli_influenced)
    is applied via apply_registry() — never extracted from article HTML.
    """

    # Spider name — used in CLI: `scrapy crawl aljazeera`
    name = "aljazeera"

    # Domains this spider is allowed to crawl.
    # Prevents accidentally following links to external sites.
    allowed_domains = ["aljazeera.com"]

    # Starting URLs — the news listing page where we find article links.
    # The spider begins here and follows pagination + article links.
    start_urls = [
        "https://www.aljazeera.com/news/",
        "https://www.aljazeera.com/economy/",
        "https://www.aljazeera.com/sports/",
        "https://www.aljazeera.com/features/",
        "https://www.aljazeera.com/middle-east/",
        "https://www.aljazeera.com/europe/",
        "https://www.aljazeera.com/africa/",
        "https://www.aljazeera.com/asia/",
        "https://www.aljazeera.com/us-canada/",
    ]

    # Per-spider download delay — 2s is safe for Al Jazeera (L-04).
    # AutoThrottle may increase this if the server responds slowly.
    custom_settings = {
        "DOWNLOAD_DELAY": 2,
    }

    # Historical start date — March 29, 2011 (C-04).
    # Used to determine how far back the archive crawl should go.
    start_date = datetime(2011, 3, 29, tzinfo=timezone.utc)

    # ================================================================
    # Category Mapping
    # ================================================================
    # Maps Al Jazeera URL path sections to ARGOS category enum values.
    # Used by _classify_category() to determine what topic bucket
    # an article belongs to based on its URL.
    SECTION_TO_CATEGORY = {
        "news": "politics",        # General news defaults to politics
        "middle-east": "politics",  # Regional news
        "europe": "politics",
        "africa": "politics",
        "asia": "politics",
        "asia-pacific": "politics",
        "us-canada": "politics",
        "latin-america": "politics",
        "economy": "economy",
        "sports": "sports",
        "sport": "sports",
        "features": "culture",
        "opinion": "politics",
        "climate-crisis": "environment",
        "science-and-technology": "tech",
        "health": "health",
        "investigations": "politics",
    }

    def parse(self, response):
        """
        Parses listing pages to find article links.

        Extracts all article URLs from the listing page and yields
        requests to parse_article() for each one. Also follows
        pagination links to discover more articles.

        Args:
            response: Scrapy Response for the listing page.

        Yields:
            scrapy.Request: Requests for individual article pages.
        """
        # Extract article links from the listing page.
        # Al Jazeera article URLs follow the pattern: /section/YYYY/M/DD/slug
        # We use CSS selectors targeting article card links.
        article_links = response.css("article a::attr(href)").getall()

        # Fallback: if no article tags, try generic link patterns
        if not article_links:
            article_links = response.css(
                "a[href*='/news/']::attr(href), "
                "a[href*='/economy/']::attr(href), "
                "a[href*='/sports/']::attr(href), "
                "a[href*='/features/']::attr(href), "
                "a[href*='/middle-east/']::attr(href), "
                "a[href*='/europe/']::attr(href), "
                "a[href*='/africa/']::attr(href), "
                "a[href*='/asia/']::attr(href), "
                "a[href*='/us-canada/']::attr(href)"
            ).getall()

        # Deduplicate and filter — only follow URLs that look like articles
        # (contain a date pattern like /YYYY/M/DD/).
        seen = set()
        for link in article_links:
            full_url = response.urljoin(link)
            if full_url in seen:
                continue
            seen.add(full_url)

            # Filter: only follow URLs that contain a date path segment
            # (indicates an article, not a section index page).
            # Pattern: /YYYY/M/ — catches both /2024/3/ and /2024/12/
            if self._is_article_url(full_url):
                yield scrapy.Request(
                    url=full_url,
                    callback=self.parse_article,
                    errback=self._handle_error,
                )

        # Follow pagination — look for "Show More" or next page links.
        # Al Jazeera uses different pagination mechanisms across sections.
        next_page = response.css(
            "a.show-more-button::attr(href), "
            "a[class*='next']::attr(href), "
            "li.next a::attr(href)"
        ).get()

        if next_page:
            yield scrapy.Request(
                url=response.urljoin(next_page),
                callback=self.parse,
            )

    def parse_article(self, response):
        """
        Parses a single Al Jazeera article page into an ArticleItem.

        Extracts all 13 ARGOS data model fields. Registry-derived fields
        (country, orientation, trust_score, is_israeli_influenced) come from
        apply_registry() — never from article HTML.

        Logs a WARNING (does not drop) if content is empty — indicates
        a paywall or deleted article. Item is still stored with content="".

        Args:
            response: Scrapy Response for the article URL.

        Yields:
            ArticleItem: Fully populated with all 13 required fields.

        Requirement refs: FR-05, FR-09, FR-10
        """
        item = ArticleItem()

        # --- Title ---
        # Primary: <h1> tag (main headline).
        # Fallback: og:title meta tag.
        item["title"] = (
            response.css("h1::text").get(default="").strip()
            or response.css("meta[property='og:title']::attr(content)").get(default="").strip()
        )

        # --- Content ---
        # Extract all paragraphs from the article body.
        # Al Jazeera uses .wysiwyg--all-content as the body container.
        # Fallback selectors handle older article templates.
        paragraphs = response.css(
            ".wysiwyg--all-content p::text, "
            ".wysiwyg--all-content p *::text, "
            ".article-p-wrapper p::text, "
            ".article-p-wrapper p *::text, "
            "article .wysiwyg p::text, "
            "article .wysiwyg p *::text"
        ).getall()

        item["content"] = "\n".join(p.strip() for p in paragraphs if p.strip())

        if not item["content"]:
            # Empty content — likely paywalled or deleted (L-05).
            # Log but do NOT drop. Store with content="" for the metadata.
            logger.warning(
                "Empty content for Al Jazeera article (paywall/deleted?): %s",
                response.url
            )
            item["content"] = ""

        # --- Summary ---
        # Primary: meta description tag.
        # Fallback: og:description, or first paragraph of content.
        item["summary"] = (
            response.css("meta[name='description']::attr(content)").get(default="").strip()
            or response.css("meta[property='og:description']::attr(content)").get(default="").strip()
            or (item["content"][:300] if item["content"] else "")
        )

        # --- Published At ---
        # ISO 8601 timestamp from article:published_time meta tag.
        # Fallback: <time> element's datetime attribute.
        published_at = (
            response.css("meta[property='article:published_time']::attr(content)").get(default="")
            or response.css("time[datetime]::attr(datetime)").get(default="")
        )
        item["published_at"] = published_at.strip() if published_at else ""

        # If we still don't have a date, use scraped_at as fallback
        # and log a warning so it can be investigated.
        if not item["published_at"]:
            logger.warning(
                "Could not extract published_at for: %s — using scraped_at",
                response.url
            )
            item["published_at"] = datetime.now(timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            )

        # --- Scraped At ---
        # Auto-generated at scrape time. Never from the page.
        # FR-09: record the exact datetime of scraping.
        item["scraped_at"] = datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

        # --- Source URL ---
        # The canonical URL of this article.
        item["source_url"] = response.url

        # --- Category ---
        # Classify based on URL path section.
        item["category"] = self._classify_category(response.url)

        # --- Tags ---
        # Extract from meta keywords or article tags.
        keywords = response.css(
            "meta[name='keywords']::attr(content)"
        ).get(default="")
        if keywords:
            item["tags"] = [
                tag.strip() for tag in keywords.split(",") if tag.strip()
            ]
        else:
            # Fallback: look for tag links in the article
            item["tags"] = response.css(
                ".article-tags a::text, "
                "a[href*='/tag/']::text"
            ).getall()
            item["tags"] = [t.strip() for t in item["tags"] if t.strip()]

        # --- Registry Metadata ---
        # Apply source-level metadata from SOURCE_REGISTRY.
        # This sets: source_name, country, orientation, trust_score,
        # is_israeli_influenced — all from the registry, never from HTML.
        item = apply_registry(item, "aljazeera.com")

        yield item

    def _classify_category(self, url):
        """
        Maps a URL to an ARGOS category enum value.

        Extracts the section from the URL path and looks it up in
        SECTION_TO_CATEGORY. Falls back to "other" if the section
        doesn't match any known mapping.

        Args:
            url: The full article URL.

        Returns:
            str: One of the CATEGORY_VALUES enum values.
        """
        from urllib.parse import urlparse
        path = urlparse(url).path.strip("/")
        parts = path.split("/")

        if parts:
            section = parts[0].lower()
            category = self.SECTION_TO_CATEGORY.get(section, "other")
            if category == "other":
                # Log fallback for auditing (L-09).
                logger.debug(
                    "Category fallback to 'other' for section '%s' in: %s",
                    section, url
                )
            return category

        return "other"

    def _is_article_url(self, url):
        """
        Determines if a URL is likely an article (vs. a section index).

        Al Jazeera article URLs contain date segments: /YYYY/M/DD/
        Section index URLs don't have dates.

        Args:
            url: The URL to check.

        Returns:
            bool: True if the URL looks like an article.
        """
        import re
        # Match URLs containing /YYYY/M/ or /YYYY/MM/ date patterns
        return bool(re.search(r"/\d{4}/\d{1,2}/", url))

    def _handle_error(self, failure):
        """
        Error callback for failed requests.

        Logs the error but doesn't crash the spider — other articles
        continue processing (FR-08).

        Args:
            failure: The Twisted Failure object.
        """
        logger.warning(
            "Request failed for %s: %s",
            failure.request.url,
            failure.getErrorMessage()
        )
