"""
ARGOS — Article Item Definition
================================
Defines the ArticleItem class with all 13 required fields from the
ARGOS data model (context.md Section 3).

Every spider MUST yield ArticleItem instances with ALL 13 fields populated.
The ValidationPipeline (priority 100) enforces this — any missing field
causes the item to be dropped.

Field categories:
  - Content fields: title, content, summary (from article HTML)
  - Classification: category, tags (assigned at ingest by spider)
  - Source identity: source_name, source_url (from spider + registry)
  - Timestamps: published_at, scraped_at (from HTML + auto-generated)
  - Registry metadata: country, orientation, trust_score, is_israeli_influenced
    (from SOURCE_REGISTRY via apply_registry() — NEVER from article content)

Requirement refs: FR-05, FR-09, FR-10
"""

import scrapy


class ArticleItem(scrapy.Item):
    """
    Represents a single news article in the ARGOS system.

    All 13 fields are required for every article. The ValidationPipeline
    checks completeness before the article reaches storage.

    Usage in spiders:
        item = ArticleItem()
        item["title"] = response.css("h1::text").get(default="")
        # ... fill all fields ...
        item = apply_registry(item, "aljazeera.com")
        yield item
    """

    # ====================================================================
    # CONTENT FIELDS — Extracted from the article's HTML page
    # ====================================================================

    # title — The headline of the article, exactly as published.
    # Extracted from <h1> tags or og:title meta tags.
    # Must not be empty — an article without a title is invalid.
    title = scrapy.Field()

    # content — Full body text of the article.
    # Extracted from the article body container (<article>, .article-body, etc.)
    # May be empty string "" for paywalled/deleted articles (L-05) — this is
    # acceptable, the item is NOT dropped. Logged as a warning instead.
    content = scrapy.Field()

    # summary — Short abstract or excerpt of the article.
    # Extracted from meta[name=description], og:description, or first paragraph.
    # Provides a quick preview without reading the full content.
    summary = scrapy.Field()

    # ====================================================================
    # CLASSIFICATION FIELDS — Assigned at ingest time by the spider
    # ====================================================================

    # category — Topical classification of the article.
    # Assigned by _classify_category() based on URL path or section label.
    # MUST be one of the allowed enum values:
    #   politics, economy, tech, war, health, science, culture,
    #   sports, environment, other
    # Falls back to "other" if classification is uncertain (logged at DEBUG).
    category = scrapy.Field()

    # tags — List of keyword tags associated with the article.
    # Extracted from article metadata tags, topic labels, or <meta> keywords.
    # CAN be an empty list [] — this is valid, unlike other fields.
    # Example: ["ceasefire", "Egypt", "diplomacy"]
    tags = scrapy.Field()

    # ====================================================================
    # SOURCE IDENTITY — Where the article came from
    # ====================================================================

    # source_name — Canonical name of the news network.
    # Set by apply_registry() from SOURCE_REGISTRY, NOT manually.
    # Example: "Al Jazeera", "Middle East Eye"
    source_name = scrapy.Field()

    # source_url — Direct URL to the article on the source website.
    # This is the response.url from the spider — the canonical link to
    # the original article. Used as the unique key for deduplication.
    source_url = scrapy.Field()

    # ====================================================================
    # TIMESTAMP FIELDS — When and when scraped
    # ====================================================================

    # published_at — When the article was originally published.
    # Extracted from <time>, article:published_time, or datePublished schema.
    # Format: ISO 8601 UTC string (e.g., "2024-03-12T09:00:00Z")
    # If parsing fails, defaults to the scraped_at timestamp with a warning.
    published_at = scrapy.Field()

    # scraped_at — When ARGOS collected this article.
    # Auto-generated at scrape time using datetime.utcnow().
    # Never extracted from the page — always set by the spider.
    # Format: ISO 8601 UTC string
    # Requirement ref: FR-09
    scraped_at = scrapy.Field()

    # ====================================================================
    # REGISTRY-DERIVED METADATA
    # ====================================================================
    # These 4 fields are ALWAYS set by apply_registry() from SOURCE_REGISTRY.
    # They describe the NEWS NETWORK, not the individual article.
    # NEVER infer these from article text — this is a hard rule.
    # Requirement ref: FR-10

    # country — Country of origin of the news network.
    # Example: "Qatar" for Al Jazeera, "Saudi Arabia" for Al Arabiya.
    country = scrapy.Field()

    # orientation — Political/editorial leaning of the source.
    # MUST be one of: left, center-left, center, center-right, right,
    #   far-right, state, zionist, unknown
    orientation = scrapy.Field()

    # trust_score — Credibility score for the source (0.0–1.0).
    # Derived from Media Intelligence Index: raw score ÷ 100.
    # Example: Al Jazeera = 55/100 = 0.55
    trust_score = scrapy.Field()

    # is_israeli_influenced — Whether the source has Israeli ownership,
    # operation, or documented editorial influence.
    # Boolean: True or False. Applied from registry only.
    is_israeli_influenced = scrapy.Field()
