"""
ARGOS — Source Network Registry
================================
The single source of truth for all source-level metadata.

This module contains the SOURCE_REGISTRY dictionary and the apply_registry()
function. These are the ONLY places where source metadata (country, orientation,
trust_score, is_israeli_influenced) should ever be set.

CRITICAL RULE: Never infer these values from article content. They are always
copied from this registry, which reflects the editorial profile of the news
network as a whole — not any individual article.

The registry is "frozen" — values should not change without updating GEMINI.md
and bumping the project version. If a network's editorial stance changes
over time (L-06), this registry must be manually updated.

Requirement refs: FR-10, C-05
"""

# ============================================================================
# SOURCE_REGISTRY — Frozen metadata for all 4 ARGOS source networks
# ============================================================================
# Each key is the domain of the news source (used for lookup).
# Each value contains the 4 registry-derived fields that get applied to
# every article scraped from that domain.
#
# trust_score is the Media Intelligence Index raw score ÷ 100.
# orientation comes from editorial analysis, not article content.
# is_israeli_influenced indicates ownership, operation, or editorial influence.
#
# These 4 sources are the complete set required by C-05.
# ============================================================================

SOURCE_REGISTRY = {
    "aljazeera.com": {
        # Al Jazeera — Qatar-based pan-Arab news network.
        # Founded 1996, headquartered in Doha.
        # Known for independent editorial stance in the Arab world.
        "source_name":           "Al Jazeera",
        "country":               "Qatar",
        "orientation":           "center-left",
        "trust_score":           0.55,   # 55/100 on Media Intelligence Index
        "is_israeli_influenced": False,
    },
    "alarabiya.net": {
        # Al Arabiya — Saudi-owned news channel.
        # Launched 2003, headquartered in Dubai Media City.
        # Owned by MBC Group (Saudi Arabia).
        # Classified as Israeli-influenced due to documented editorial alignment.
        "source_name":           "Al Arabiya",
        "country":               "Saudi Arabia",
        "orientation":           "right",
        "trust_score":           0.40,   # 40/100 on Media Intelligence Index
        "is_israeli_influenced": True,
    },
    "skynewsarabia.com": {
        # Sky News Arabia — UAE-based Arabic news channel.
        # Joint venture between Abu Dhabi Media Investment Corp and Sky Group.
        # Operates from Abu Dhabi.
        "source_name":           "Sky News Arabia",
        "country":               "UAE",
        "orientation":           "center-right",
        "trust_score":           0.48,   # 48/100 on Media Intelligence Index
        "is_israeli_influenced": True,
    },
    "middleeasteye.net": {
        # Middle East Eye — UK-based Middle East-focused news outlet.
        # Founded 2014, headquartered in London.
        # Independent ownership, ME editorial focus.
        "source_name":           "Middle East Eye",
        "country":               "UK (ME Focus)",
        "orientation":           "left",
        "trust_score":           0.48,   # 48/100 on Media Intelligence Index
        "is_israeli_influenced": False,
    },
}


def apply_registry(item, domain):
    """
    Applies source-level metadata from the registry to a scraped article item.

    This function is the ONE AND ONLY place where registry metadata gets
    attached to articles. Spiders call this after extracting content fields
    but before yielding the item.

    The function looks up the domain in SOURCE_REGISTRY and copies:
      - source_name
      - country
      - orientation
      - trust_score
      - is_israeli_influenced

    If the domain is not found in the registry, all fields are set to
    safe defaults and a warning is logged. This should never happen in
    production since we only crawl registered domains (C-05).

    Args:
        item: An ArticleItem (or dict-like) to populate with registry fields.
        domain: The domain string to look up (e.g., "aljazeera.com").

    Returns:
        The same item with registry fields populated.

    Raises:
        Nothing — uses safe defaults on lookup failure to avoid dropping items.

    Requirement refs: FR-10
    """
    import logging

    logger = logging.getLogger(__name__)

    # Look up the source metadata by domain.
    # We strip "www." and "english." prefixes to handle domain variations
    # like "www.aljazeera.com" or "english.alarabiya.net".
    clean_domain = domain.lower()
    for prefix in ("www.", "english."):
        if clean_domain.startswith(prefix):
            clean_domain = clean_domain[len(prefix):]

    registry_entry = SOURCE_REGISTRY.get(clean_domain)

    if registry_entry is None:
        # This should never happen — we only crawl 4 registered domains.
        # If it does, log a loud warning and use safe defaults so the
        # article isn't dropped. It can be investigated later.
        logger.warning(
            "REGISTRY MISS: Domain '%s' not found in SOURCE_REGISTRY. "
            "Using safe defaults. This indicates a spider is crawling "
            "an unregistered domain — investigate immediately.",
            domain
        )
        item["source_name"] = f"Unknown ({domain})"
        item["country"] = "Unknown"
        item["orientation"] = "unknown"
        item["trust_score"] = 0.0
        item["is_israeli_influenced"] = False
    else:
        # Copy all 5 registry fields to the item.
        # These values are NEVER modified — they come straight from the
        # frozen registry as defined in GEMINI.md Section 3.
        item["source_name"] = registry_entry["source_name"]
        item["country"] = registry_entry["country"]
        item["orientation"] = registry_entry["orientation"]
        item["trust_score"] = registry_entry["trust_score"]
        item["is_israeli_influenced"] = registry_entry["is_israeli_influenced"]

    return item


def get_registry_for_domain(domain):
    """
    Returns the registry entry for a given domain, or None if not found.

    Utility function for spiders that need to inspect registry values
    without modifying an item (e.g., for logging or conditional logic).

    Args:
        domain: The domain string to look up.

    Returns:
        dict: The registry entry, or None if the domain isn't registered.
    """
    clean_domain = domain.lower()
    for prefix in ("www.", "english."):
        if clean_domain.startswith(prefix):
            clean_domain = clean_domain[len(prefix):]

    return SOURCE_REGISTRY.get(clean_domain)
