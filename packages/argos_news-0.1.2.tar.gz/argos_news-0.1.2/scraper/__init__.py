# ============================================================================
# ARGOS Scraper Package
# ============================================================================
# This is the top-level package for the Scrapy scraping engine.
# Contains: spiders, pipelines, middlewares, items, registry, and settings.
#
# Architecture role: Layer 1 — Collection
# Visits 4 Middle East news websites, extracts articles, and stores them
# in the local SQLite database via the storage pipeline.
# ============================================================================
