"""Adversarial functionalities."""
