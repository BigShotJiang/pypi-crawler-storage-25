"""Hugging Face model wrappers."""
