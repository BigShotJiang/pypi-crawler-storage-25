"""PyTorch model wrappers."""
