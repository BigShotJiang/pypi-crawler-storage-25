# public folder

This folder is dedicated to automatic generation of documentation from doc strings