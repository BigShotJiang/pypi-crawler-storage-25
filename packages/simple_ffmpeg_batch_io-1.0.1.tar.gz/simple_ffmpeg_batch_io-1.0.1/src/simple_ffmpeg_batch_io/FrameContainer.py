"""
Create a ``FrameContainer`` with data and associated timestamp(s)

Authors
-------
Dominique Vaufreydaz

"""

__authors__ = ("Dominique Vaufreydaz")

import numpy as np

# class to get audio or video frames with associated timestamp list
class FrameContainer:
    """
    Create a Container with audio or image data and associated timestamp(s).
    """

    class FrameContainerException(Exception):
        """
        Dedicated exception class for FrameContainer class.
        """
        def __init__(self, message="Error while setting FrameCounter parameters."):
            self.message = message
            super().__init__(self.message)

    nb_frames: int
    """ number of frames in the frame container. 1 for audio frame or images, n for a batch. """

    data: np.array
    """ Audio frame or image, or batch of images or audio frames. """

    timestamps: np.array
    """ an np.array of timestamp(s) associated to the data frame(s). """

    def __init__(self, nb_frames : int, frames : np.array, fps : float, start_time : float = 0.0 ):
        """
        Create a FrameContainer object with data and associated timestamps

        Parameters
        ----------
        nb_frames: int.
            Number of frame(s) in the frame container. Either 1, either number of element in the batch.

        frames:  np.array
            Data for image, audio frame or batch of them.

        fps : float.
            fps of the read stream.
            
        start_time: float (default = 0.0).
            Start time of the current FrameContainer, i.e. time of the (first) frame.
        """
        
        # check params
        if nb_frames <= 0:
            raise self.FrameContainerException("nb_frames must be > 0.")
        if nb_frames > 1 and frames.shape[0] != nb_frames:
            raise self.FrameContainerException("nb_frames and batch size (frames.shape[0]) differs.")
        if fps <= 0.0:
            raise self.FrameContainerException("fps must be > 0.0.")
        if start_time < 0.0:
            raise self.FrameContainerException("start_time must be >= 0.0.")

        self.nb_frames = nb_frames
        self.data = frames
        # first frame is at time start_time
        self.timestamps = np.linspace(start_time, start_time+(self.nb_frames-1)*fps, self.nb_frames).tolist()

    def totorch(self):
        """
        Convert the numy array into a pytorch tensor.

        Returns
        ----------
            pytorch tensor.
        """
        # import torch late as it is not in the standard requirements for simple-ffmpeg-batch-io
        import torch
        return torch.from_numpy(self.data)