"""
Create a ``FrameCounter`` to follow elapsed time in audio or video file in read/write mode. Static utility function allows to get/format elapsed time.

Authors
-------
Dominique Vaufreydaz

"""

__authors__ = ("Dominique Vaufreydaz")

from typing import Union

# class to count frame, thus time, in audio/video files
class FrameCounter:
    """
    Create a ``FrameCounter`` to follow elapsed time in audio/video file in read or write mode. Static utility functions allow to format elapsed time.
    """

    class FrameCounterException(Exception):
        """
        Dedicated exception class for FrameCounter class.
        """
        def __init__(self, message="Error while setting FrameCounter parameters."):
            self.message = message
            super().__init__(self.message)

    _fps: float # (private)
    """ Fps of current stream """

    _frame_count: int # (private)
    """ Frame count in the current stream """

    def __init__(self, fps: Union[int, float]):
        """
        Create a VideoIO object giving ffmpeg/ffrobe loglevel and defining debug mode

        Parameters
        ----------
        fps: int or float.
            Frames per second of the associated stream.
        """
        # check init fps value
        self._fps = float(fps)
        if self._fps <= 0.0:
            raise FrameCounterException("fps must be > 0.0.")

        # 2 modes
        self._frame_count = 0       # at 00:00:00.000

    # support +=
    def __iadd__(self, other: Union[int, float]):
        """
        Support += operator for FrameCounter. 

        Parameters
        ----------
        other: int or float.
            If other is a float, add the number of frame to add 'other' seconds (thus other * self._fps samples).
            If other is an int, add the value as a number of samples in the stream.
        """        
        if isinstance(other,float):
            # float means adding time
            self._frame_count += int(other * self._fps) # number of second * Nb of elements per seconds
        else:
            # for int, add number of element
            self._frame_count += other
        return self
    
    @property
    def frame_count(self):
        """
        Property to get underlying self._frame_count. Idea is to control setter to valid setting values.
        """   
        return self._frame_count

    @frame_count.setter
    def frame_count(self, value: int):
        """
        Setter for underlying self._frame_count controlling setting value.
        """   
        if value < 0:
            raise FrameCounterException("frame_count must be >= 0")
        self._frame_count = value

    @property
    def fps(self):
        """
        Property to get underlying self._fps.
        """
        return self._fps

    @staticmethod
    def format_time(nb_frames: int, fps: float, show_ms : bool = True, show_days : bool = False) -> str:
        """
        Static function to format time given by a number of frames and an fps. show_ms value defines if we show milliseconds,
        show_days to show days instead of cummulative hour count.

        Parameters
        ----------
        nb_frames: int.
            Number of samples already present in the stream.
            
        fps: float.
            Fps of the associated stream.
            
        show_ms: bool.
            Flag to say if we want to show milliseconds in the output str.
            
        show_days: bool.
            Flag to say if we want to show says instead of cumulative hours in the output str.

        Returns
        -------
            str representing corresponding time. Either 26:15:00 (show_ms=False, show_days=False), 26:15:00.500 (show_ms=True, show_days=False)
            or 1 day(s) 02:15:00.500 (show_ms=True, show_days=True)
        """  
        # exact time in seconds (float)
        exact_seconds = nb_frames / fps

        # integer part for days/hours/minutes/seconds
        total_seconds = int(exact_seconds)

        # milliseconds = decimal part * 1000
        millis = int(round((exact_seconds - total_seconds) * 1000))

        # handle the case where rounding results in 1000 ms
        if millis == 1000:
            millis = 0
            total_seconds += 1

        if show_days:
            # compute number of days, hours, minutes, seconds
            days, mod = divmod(total_seconds, 24 * 3600)
            hours, mod = divmod(mod, 3600)
            minutes, seconds = divmod(mod, 60)

            if days > 0:
                days = f"{days} days(s) "
            else:
                days = ""
        else:
            days = "" # no day as show_days = False
            hours, mod = divmod(total_seconds, 3600)
            minutes, seconds = divmod(mod, 60)

        if show_ms == True:
            millis = f".{millis:03d}"
        else:
            millis = ""

        return f"{days}{hours:02d}:{minutes:02d}:{seconds:02d}{millis}"

    def get_elapsed_time_as_str(self) -> str:
        """
        Get elapsed time as string representing a float value rounded to 3 decimals.

        Returns
        -------
            str representing corresponding time in float format rounded to 3 decimals.
        """
        return f"{float(self._frame_count)/self._fps:.3f}"

    def get_formated_elapsed_time_as_str(self, show_ms : bool = True, show_days : bool = False) -> str:
        """
        Get elapsed time as string representing time with different mode (see ``FrameCounter.format_time`` for parameter explanation).
        Returns
        -------
            str representing corresponding time in float format rounded to 3 decimals.
        """
        # frame count to time correction is done in format_time
        return FrameCounter.format_time(self._frame_count, self._fps, show_ms, show_days)

    def get_elapsed_time(self) -> float:
        """
        Get elapsed time as float value rounded to 3 decimals.

        Returns
        -------
            str representing corresponding time in float format rounded to 3 decimals.
        """
        return round(float(self._frame_count)/self._fps,3)
