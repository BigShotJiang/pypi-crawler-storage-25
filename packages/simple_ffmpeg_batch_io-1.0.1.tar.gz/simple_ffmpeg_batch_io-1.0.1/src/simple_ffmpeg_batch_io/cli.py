"""
Exposes ffmpeg and ffprobe as standard command line tools within the python environment.

Authors
-------
Dominique Vaufreydaz

"""

__authors__ = ("Dominique Vaufreydaz")

import os
import sys
import static_ffmpeg

# expose ffmpeg as a standard cli command
def ffmpeg_main():
    static_ffmpeg.add_paths()
    ffmpegProgram, _ = static_ffmpeg.run.get_or_fetch_platform_executables_else_raise()
    # À ce stade, 'ffmpeg' pointe sur la version de static_ffmpeg dans le PATH
    os.execvp("ffmpeg", [ffmpegProgram, *sys.argv[1:]])

# expose ffprobe as a standard cli command
def ffprobe_main():
    static_ffmpeg.add_paths()
    _, ffprobeProgram = static_ffmpeg.run.get_or_fetch_platform_executables_else_raise()
    os.execvp("ffprobe", [ffprobeProgram, *sys.argv[1:]])