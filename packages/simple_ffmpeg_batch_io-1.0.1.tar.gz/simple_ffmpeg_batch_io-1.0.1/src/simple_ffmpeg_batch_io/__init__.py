"""
.. include:: ../../README.md
 :start-after: # simple-ffmpeg-batch-io

# Submodules
"""

__authors__ = ("Dominique Vaufreydaz")

# __init__.py
from .VideoIO import VideoIO
from .AudioIO import AudioIO
from .PipeMode import PipeMode
from .FrameCounter import FrameCounter
from .FrameContainer import FrameContainer

__all__ = [
    "VideoIO",
    "AudioIO",
    "FrameCounter",
    "FrameContainer",
    "PipeMode",
]