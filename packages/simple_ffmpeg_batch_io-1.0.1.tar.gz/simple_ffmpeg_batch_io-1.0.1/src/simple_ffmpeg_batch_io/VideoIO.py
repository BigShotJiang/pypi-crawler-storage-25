"""
Read/write video images or batches of images from video file using FFmpeg backend.

This module defines the main `VideoIO` class used to open videos,
read images or batches of frames, and write processed outputs.

Authors
-------
Dominique Vaufreydaz (From original C++ code: https://github.com/Vaufreyd/ReadWriteVideosWithOpenCV)

"""

__authors__ = ("Dominique Vaufreydaz")

import sys
import subprocess as sp
import re
from enum import Enum
from typing import Union

import numpy as np

from .FrameCounter import FrameCounter
from .FrameContainer import FrameContainer
from .PipeMode import PipeMode

# init static_ffmpeg at import time, first time it will download ffmpeg executables
import static_ffmpeg
static_ffmpeg.add_paths()

class VideoIO:
    # "static" variables to ffmpeg, ffprobe executables
    videoProgram, paramProgram = static_ffmpeg.run.get_or_fetch_platform_executables_else_raise()

    class VideoIOException(Exception):
        """
        Dedicated exception class for VideoIO class.
        """
        def __init__(self, message="Error while reading/writing video occurs"):
            self.message = message
            super().__init__(self.message)

    class PixelFormat(Enum):
        """
        Enum class for supported input video type: GBR 24 bits or RGB 24 bis.
        """
        GBR24 = 'bgr24' # default format
        RGB24 = 'rgb24'

    @classmethod
    def reader(cls, filename, **kwargs):
        """
        Create and open a VideoIO object in reader mode (read a video file)

        See `VideoIO.open` for the full list
        of accepted parameters.
        """
        reader = cls()
        reader.open(filename,**kwargs)
        return reader

    @classmethod
    def writer(cls, filename, width, height, fps, **kwargs):
        """
        Create and open a VideoIO object in writer mode (write a video file)

        See `VideoIO.create` for the full list
        of accepted parameters.
        """
        writer = cls()
        writer.create(filename, width, height, fps, **kwargs)
        return writer

    # To use with context manager "with VideoIO.reader(...) as f:' for instance
    def __enter__(self):
        """
        Method call at initialisation of a context manager like "with VideoIO.reader(...) as f:' for instance
        """
        # simply return myself
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Method call when existing of a context manager like "with VideoIO.reader(...) as f:' for instance
        """
        # close VideoIO
        self.close()
        return False

    @staticmethod
    def get_time_in_sec(filename, *, debug=False, logLevel=16):
        """
        Static method to get length of a video file in seconds including milliseconds as decimal part.

        Parameters
        ----------
        filename : str or path
            Video file name.

        debug : bool (default False)
            Show debug info.

        log_level: int (default 16)
            Log level to pass to the underlying ffmpeg/ffprobe command.
        
        Returns
        ----------
        float
            Length in seconds of video file (including milliseconds as decimal part)
        """
        
        cmd = [VideoIO.paramProgram, # ffprobe
                    '-hide_banner',
                    '-loglevel', str(logLevel),
                    '-show_entries', 'format=duration',
                    '-of', 'default=noprint_wrappers=1:nokey=1',
                    filename
                    ]

        if debug == True:
            print(' '.join(cmd))

        # call ffprobe and get params in one single line
        lpipe = sp.Popen(cmd, stdout=sp.PIPE, stdin=sp.PIPE) # stdin=sp.PIPE to prevent manipulation of shell echo mode by ffmpeg/ffprobe
        output = lpipe.stdout.readlines()
        lpipe.terminate()
        # transform Bytes output to one single string
        output = ''.join( [element.decode('utf-8') for element in output])

        try:
            return float(output)
        except (ValueError, TypeError):
            return None

    @staticmethod
    def get_params(filename, *, debug=False, logLevel=16):
        """
        Static method to get params (width, height, fps) from a video file.

        Parameters
        ----------
        filename: str or path
            Video filename.

        debug: bool (default (False)
            Show debug info.

        log_level: int (default 16)
            Log level to pass to the underlying ffmpeg/ffprobe command.

        Returns
        ----------
        tuple
            Tuple containing (width, height, fps) of the video
        """
        cmd = [VideoIO.paramProgram, # ffprobe
                    '-hide_banner',
                    '-loglevel', str(logLevel),
                    '-show_entries', 'stream=width,height,r_frame_rate',
                    filename
                    ]

        if debug == True:
            print(' '.join(cmd))

        # call ffprobe and get params in one single line
        lpipe = sp.Popen(cmd, stdout=sp.PIPE, stdin=sp.PIPE) # stdin=sp.PIPE to prevent manipulation of shell echo mode by ffmpeg/ffprobe
        output = lpipe.stdout.readlines()
        lpipe.terminate()
        # transform Bytes output to one single string
        output = ''.join( [element.decode('utf-8') for element in output])

        pattern_width = r'width=(\d+)'
        pattern_height = r'height=(\d+)'
        pattern_fps = r'r_frame_rate=(\d+)/(\d+)'

        # Search for values in the ffprobe output
        match_width = re.search(pattern_width, output, flags=re.MULTILINE)
        match_height = re.search(pattern_height, output, flags=re.MULTILINE)
        match_fps = re.search(pattern_fps, output, flags=re.MULTILINE)

        # Extraction des valeurs
        if match_width:
            width = int(match_width.group(1))
        else:
            raise VideoIO.VideoIOException("Unable to get geometry of '" + filename + "'")

        if match_height:
            height = int(match_height.group(1))
        else:
            raise VideoIO.VideoIOException("Unable to get geometry of '" + filename + "'")

        if match_fps:
            numerator = float(match_fps.group(1))
            denominator = float(match_fps.group(2))
            fps = numerator / denominator
        else:
            raise VideoIO.VideoIOException("Unable to get frame rate (fps) of '" + filename + "'")

        return (width, height, fps)

    # Attributes
    mode: PipeMode
    """ Pipemode of the current object (default PipeMode.UNK_MODE)"""

    loglevel: int
    """ loglevel of the underlying ffmpeg backend for this object (default 16)"""

    debugModel: bool
    """ debutMode flag for this object (print debut info, default False)"""

    width: int
    """ width of images (default -1) """

    height: int
    """ height of images (default -1) """

    fps: float
    """ fps of video (default -1.0) """

    pipe: sp.Popen
    """ pipe object to ffmpeg/ffprobe (default None)"""

    shape: tuple
    """ Shape of images (default (None, None, None))"""

    imageSize: int
    """ Weight in bytes of one image (default -1)"""

    filename: str
    """ Filename of the video file (default None)"""

    frame_counter: FrameCounter
    """ `Framecounter` object to count ellapsed time (default None)"""

    def __init__(self, *, logLevel = 16, debugMode = False):
        """
        Create a VideoIO object giving ffmpeg/ffrobe loglevel and defining debug mode

        Parameters
        ----------
        log_level: int (default 16)
            Log level to pass to the underlying ffmpeg/ffprobe command.

        debugMode: bool (default (False)
            Show debug info. while processing video
        """

        self.mode = PipeMode.UNK_MODE
        self.logLevel = logLevel
        self.debugMode = debugMode

        # Call init() method
        self.init()

    def init(self):
        """
        Init or reinit a VideoIO object.
        """
        self.width  = -1
        self.height = -1
        self.fps = -1.0
        self.pipe = None
        self.shape = (None, None, None)
        self.imageSize = -1
        self.filename = None
        self.frame_counter = None

    _repr_exclude = {"pipe"}
    """ List of excluded attribute for string conversion. """

    # converting the object to a string representation
    def __repr__(self):
        """
        Convert object (excluding attributes in _repr_exclude) to string representation.
        """
        attrs = ", ".join(
            f"{k}={v!r}"
            for k, v in self.__dict__.items()
            if k not in self._repr_exclude
        )
        return f"{self.__class__.__name__}({attrs})"

    __str__ = __repr__
    """ String representation """

    def get_elapsed_time_as_str(self) -> str:
        """
        Method to get elapsed time (float value) as str from `frame_counter` attribute.

        Returns
        ----------
        str or None
            Elapsed time (float value) as str, "15.500" for instance for 15 secondes and 500 milliseconds
            None if no frame counter are available.
        """
        if self.frame_counter is None:
            return None
        return self.frame_counter.get_elapsed_time_as_str()

    def get_formated_elapsed_time_as_str(self,show_ms=True) -> str:
        """
        Method to get elapsed time (hour format) as str from `frame_counter` attribute.

        Returns
        ----------
        str or None
            Elapsed time (float value) as str, "00:00:15.500" for instance for 15 secondes and 500 milliseconds
            None if no frame counter are available.
        """
        if self.frame_counter is None:
            return None
        return self.frame_counter.get_formated_elapsed_time_as_str()

    def get_elapsed_time(self) -> float:
        """
        Method to get elapsed time as float value rounded to 3 decimals (millisecond) from `frame_counter` attribute.

        Returns
        ----------
        float or None
            Elapsed time (float value) as str, 15.500 for instance for 15 secondes and 500 milliseconds
            None if no frame counter are available.
        """
        if self.frame_counter is None:
            return None
        return self.frame_counter.get_elapsed_time()

    def is_opened(self) -> bool:
        """
        Method to get status of the underlying pipe to ffmpeg.

        Returns
        ----------
        bool
            True if pipe is opened (reading or writing mode), False if not.
        """
        # is the pipe opened?
        if self.pipe is not None and self.pipe.poll() is None:
            return True

        return False

    def close(self) -> None:
        """
        Method to close current pipe to ffmpeg (if any). Ffmpeg/ffprobe will be terminated. Object can be reused using open or create methods.
        """
        if self.pipe is not None:
            if self.mode == PipeMode.WRITE_MODE:
                # killing will make ffmpeg not finish properly the job, close the pipe
                # to let it know that no more data are comming
                self.pipe.stdin.close()
            else: # self.mode == PipeMode.READ_MODE
                # in read mode, no need to be nice, send SIGTERM on Linux,/Kill it on windows
                self.pipe.kill()

            # wait for subprocess to end
            self.pipe.wait()

        # reinit object for later use
        self.init()

    def create(self, width, height, fps, *, writeOverExistingFile = False,
                     inputEncoding = PixelFormat.GBR24, encodingParams = None ) -> bool:
        """
        Method to create a video using parametrized access through ffmpeg. Importante note: calling create
        on a VideoIO will close any former open video.

        Parameters
        ----------
        filename: str or path
            filename of path to the file (mp4, avi, ...)

        width: int
            If defined as a positive value, width of output images will be set to this value.

        height: int
            If defined as a positive value, height of output images will be set to this value.

        fps:
            If defined as a positive value, fps of output video will be set to this value.

        inputEncoding: PixelFormat optional (default PixelFormat.BGR24)
            Define order of channels for channels. Possible values are PixelFormat.BGR24 or PixelFormat.RGB24.

        encodingParams: str optional (default None)
            Parameter to pass to ffmpeg to encode video like video filters.

        Returns
        ----------
        bool
            Was the creation successfull
        """

        # Close if already opened
        self.close()

        # Set geometry/fps of the video stream from params
        self.width = int(width)
        self.height = int(height)
        self.fps = float(fps)

        # Check params
        if self.width <= 0 or self.height <= 0 or self.fps <= 0.0:
            raise self.VideoIOException("Bad parameters: width={}, height={}, fps={:3f}".format(self.width,self.height,self.fps))

        # Params are ok, set shape and image size
        self.shape     = (self.height,self.width,3)
        self.imageSize = self.height * self.width * 3

        # Video params are set, open the video
        cmd = [self.videoProgram] # ffmpeg

        if writeOverExistingFile == True:
            cmd.extend(['-y'])

        cmd.extend(['-hide_banner',
            '-nostats',
            '-loglevel', str(self.logLevel),
            '-f', 'rawvideo', '-vcodec', 'rawvideo', '-pix_fmt', inputEncoding.value,
            '-video_size', f"{self.width}x{self.height}",
            '-r', "{:.3f}".format(self.fps),
            '-i', '-'])

        if encodingParams is not None:
            cmd.extend(encodingParams.split())

        cmd.extend( ['-an', filename ] )

        if self.debugMode == True:
            print( ' '.join(cmd), file=sys.stderr )

        # store filename and set mode
        self.filename = filename
        self.mode = PipeMode.WRITE_MODE

        # Call ffmpeg in write mode
        try:
            self.pipe = sp.Popen(cmd, stdin=sp.PIPE)
            self.frame_counter = FrameCounter(self.fps)
        except Exception as e:
            # if pipe failed, reinit object and raise exception
            self.init()
            raise

        return True

    def open( self, filename, *, width = -1, height = -1, fps = -1.0, outputEncoding = PixelFormat.GBR24,
                    decodingParams = None, start_time = 0.0 ) -> bool:
        """
        Method to read video using parametrized access through ffmpeg. Importante note: calling open
        on a VideoIO will close any former open video.

        Parameters
        ----------
        filename: str or path
            filename of path to the file (mp4, avi, ...)

        width: int optional (default -1)
            If defined as a positive value, width of input images will be converted to this value.

        height: int optional (default -1)
            If defined as a positive value, height of input images will be converted to this value.

        fps: float optional (default -1.0)
            If defined as a positive value, fps of input video will be converted to this value.

        outputEncoding: PixelFormat optional (default PixelFormat.BGR24)
            Define order of channels for channels. Possible values are PixelFormat.BGR24 or PixelFormat.RGB24.

        decodingParams: str optional (default None)
            Parameter to pass to ffmpeg to decode video like filters.

        start_time: float optional (default 0.0)
            Define the reading start time. If not set, reading at beginning of the video.

        Returns
        ----------
        bool
            Was the opening successfull
        """

        # Close if already opened
        self.close()

        # Force conversion of parameters
        width = int(width)
        height = int(height)
        fps = float(fps)

        # get parameters from video
        self.width, self.height, self.fps = self.getVideoParams(filename)

        # check if parameters ask to overide video parameters
        # TODO: add support for negative value (automatic preservation of aspect ratio)
        if width > 0:
            self.width = width
        if height > 0:
            self.height = height
        if fps > 0.0:
            self.fps = fps

        # Params are ok, set shape and image size
        self.shape = (self.height,self.width,3)
        self.imageSize = self.height * self.width * 3

        # Video params are set, open the video
        cmd = [self.videoProgram, # ffmpeg
                    '-hide_banner',
                    '-nostats',
                    '-loglevel', str(self.logLevel)]

        if start_time < 0.0:
            pass
        elif start_time > 0.0:
            cmd.extend(["-ss", f"{start_time}"])    # set start time if any

        cmd.extend( ['-i', filename] )

        video_filters = '' # empty
        if decodingParams is not None:
            decodingParams = decodingParams.split()
            # walk over decodingParams for specific params
            i = 0
            while i < len(decodingParams):
                if decodingParams[i] == '-vf':
                    decodingParams.pop(i)  # remove '-vf'
                    if i < len(decodingParams):
                        video_filters += ','+decodingParams.pop(i)  # remove parameters from list too
                    # to do : add support to other option like -y
                else:
                    i += 1
        else:
            decodingParams = []

        cmd.extend( ['-vf', f'scale={self.width}:{self.height}{video_filters}', # rescale (or not if shape is original one), add specific video filters
                    *(decodingParams),
                    '-f', 'rawvideo', '-vcodec', 'rawvideo', '-pix_fmt', outputEncoding.value, # input expected coding
                    '-an', # no audio
                     '-r', f"{self.fps}",
                     '-' # output to stdout
                    ] )

        if self.debugMode == True:
            print( ' '.join(cmd) )

        # store filename and set mode to READ_MODE
        self.filename = filename
        self.mode = PipeMode.READ_MODE

        # call ffmpeg in read mode
        try:
            self.pipe = sp.Popen(cmd, stdout=sp.PIPE, stdin=sp.PIPE) # stdin=sp.PIPE to prevent manipulation of shell echo mode by ffmpeg/ffprobe
            self.frame_counter = FrameCounter(self.fps)
            if start_time > 0.0:
                self.frame_counter += start_time # adding with float means adding time
        except Exception as e:
            # if pipe failed, reinit object and raise exception
            self.init()
            raise

        return True

    def read_frame(self, with_timestamps = False):
        """
        Read next frame from the video

        Parameters
        ----------
        with_timestamps: bool optional (default False)
            If set to True, the method returns a FrameContainer with the image and an array containing the associated timestamp(s)

        Returns
        ----------
        nparray or FrameContainer
            An image of shape (3,width,height). if with_timestamps is True, the return object is a FrameContainer with the image in ``FrameContainer.data`` and
            the associated timestamp in ``FrameContainer.timestamps`` as an array (one element for one frame).
        """

        if self.pipe is None:
            raise self.VideoIOException("No pipe opened to {}. Call open(...) before reading a frame.".format(self.videoProgram))
        # - pipe is in write mode
        if self.mode != PipeMode.READ_MODE:
            raise self.VideoIOException("Pipe to {} for '{}' not opened in read mode.".format(self.videoProgram, self.filename))

        if with_timestamps:
            # get elapsed time in video, it is time of next frame(s)
            current_elapsed_time = self.get_elapsed_time()

        # read rgb image from pipe
        buffer = self.pipe.stdout.read(self.imageSize)
        if len(buffer) != self.imageSize:
            # not considered as an error, no more frame, no exception
            return None

        # get numpy UINT8 array from buffer
        rgbImage = np.frombuffer(buffer, dtype = np.uint8).reshape(self.shape)

        # increase frame_counter
        self.frame_counter.frame_count += 1

        # say to gc that this buffer is no longer needed
        del buffer

        if with_timestamps:
            return FrameContainer(1,rgbImage,self.fps,current_elapsed_time)

        return rgbImage

    def read_batch(self, number_of_frames, with_timestamps = False) ->  Union[np.array, FrameContainer]:
        """
        Read next batch of images from the video

        Parameters
        ----------
        number_of_frames: int
            Number of desired images within the batch. The last batch of the video may have less images.
            
        with_timestamps: bool optional (default False)
            If set to True, the method returns a FrameContainer with the batch and the an array containing the associated timestamps to frames

        Returns
        ----------
        nparray or FrameContainer
            A batch of images of shape (n,3,width,height). if with_timestamps is True, the return object is a FrameContainer with the batch in ``FrameContainer.data`` and
            the associated timestamps in ``FrameContainer.timestamps`` as an array (one element for each frame).
        """

        if self.pipe is None:
            raise self.VideoIOException("No pipe opened to {}. Call open(...) before reading frames.".format(self.videoProgram))
        # - pipe is in write mode
        if self.mode != PipeMode.READ_MODE:
            raise self.VideoIOException("Pipe to {} for '{}' not opened in read mode.".format(self.videoProgram, self.filename))

        if with_timestamps:
            # get elapsed time in video, it is time of next frame(s)
            current_elapsed_time = self.get_elapsed_time()

        # try to read complete batch
        buffer = self.pipe.stdout.read(self.imageSize*number_of_frames)

        # check if we have at least 1 Frame
        if len(buffer) < self.imageSize:
            # not considered as an error, no more frame, no exception
            return None

        # compute actual number of Frames
        actualNbFrames = len(buffer)//self.imageSize

        # get and reshape batch from buffer
        batch = np.frombuffer(buffer, dtype = np.uint8).reshape((actualNbFrames, self.height, self.width, 3))

        # increase frame_counter
        self.frame_counter.frame_count += actualNbFrames
        
        # say to gc that this buffer is no longer needed
        del buffer

        if with_timestamps:
            return FrameContainer(actualNbFrames, batch, self.fps, current_elapsed_time)

        return batch

    def write_frame(self, image) -> bool:
        """
        Write an image to the video

        Parameters
        ----------
        image: nparray
            The image of shape (3, width, height) to write to the video file in the PixelFormat provided when create was called.

        Returns
        ----------
        bool
            Writing was successful or not.
        """
        
        # Check params
        # - pipe exists
        if self.pipe is None:
            raise self.VideoIOException("No pipe opened to {}. Call create(...) before writing frames.".format(self.videoProgram))
        # - pipe is in write mode
        if self.mode != PipeMode.WRITE_MODE:
            raise self.VideoIOException("Pipe to {} for '{}' not opened in write mode.".format(self.videoProgram, self.filename))
        # - shape of image is fine, thus we have pixels for a full compatible frame
        if image.shape != self.shape:
            raise self.VideoIOException("Wong image shape: {} expected {}.".format(image.shape,self.shape))
        # - type of data is UINT8
        if image.dtype != np.uint8:
            raise self.VideoIOException("Wong pixel type: {} expected np.uint8.".format(image.dtype))

        # write frame
        buffer = image.tobytes()
        if self.pipe.stdin.write( buffer ) < self.imageSize:
            print( "Error writing frame to" )
            return False

        # increase frame_counter
        self.frame_counter.frame_count += 1

        # say to gc that this buffer is no longer needed 
        del buffer

        return True

    def write_batch(self, batch) -> bool:
        """
        Write a batch of images to the video

        Parameters
        ----------
        batch: nparray
            A batch of images to write to the video file in the PixelFormat provided when create was called.

        Returns
        ----------
        bool
            Writing was successful or not.
        """

        # Check params
        # - pipe exists
        if self.pipe is None:
            raise self.VideoIOException("No pipe opened to {}. Call create(...) before writing frames.".format(self.videoProgram))
        # - pipe is in write mode
        if self.mode != PipeMode.WRITE_MODE:
            raise self.VideoIOException("Pipe to {} for '{}' not opened in write mode.".format(self.videoProgram, self.filename))
        # - shape of images in batch is fine
        if batch.shape[-3:] != self.shape:
            raise self.VideoIOException("Wrong image shape in batch: {} expected {}.".format(batch.shape[-3:], self.shape))
        # - we have the right amount of pixels for the full batch
        if batch.size != (batch.shape[0]*self.imageSize):
            raise self.VideoIOException("Wrong number of pixels in batch: {} expected {}.".format(batch.shape[-3:], self.imageSize))

        # write frame
        buffer = batch.tobytes()
        if self.pipe.stdin.write( buffer ) < batch.size:
            # say to gc that this buffer is no longer needed
            del buffer
            raise self.VideoIOException("Error writing batch to '{}'.".format(self.filename))

        # increase frame_counter
        self.frame_counter.frame_count += batch.shape[0]       
            
        # say to gc that this buffer is no longer needed
        del buffer

        return True

    def iter_frames(self, with_timestamps = False):
        """
        Method to iterate on video frames using VideoIO obj.
        for frame in obj.iter_frames():
            ....

        Parameters
        ----------
        with_timestamps: bool optional (default False)
            If set to True, the method returns a FrameContainer with the batch and an array containing the associated timestamps to frames
        """

        try:
            if self.mode == PipeMode.READ_MODE:
                while self.isOpened():
                    frame = self.readFrame(with_timestamps)
                    if frame is not None:
                        yield frame
        finally:
            self.close()

    def iter_batches(self, batch_size : int, with_timestamps = False):
        """
        Method to iterate on batch of frames using VideoIO obj.
        for image_batch in obj.iter_batches():
            ....

        Parameters
        ----------
        with_timestamps: bool optional (default False)
            If set to True, the method returns a FrameContainer with the batch and the an array containing the associated timestamps to frames
        """
        try:
            if self.mode == PipeMode.READ_MODE:
                while self.isOpened():
                    batch = self.readBatch(batch_size, with_timestamps)
                    if batch is not None:
                        yield batch
        finally:
            self.close()

    # function aliases to be compliant with original C++ version
    getVideoTimeInSec = get_time_in_sec
    getVideoParams = get_params
    get_video_time_in_sec = get_time_in_sec
    get_video_params = get_params
    isOpened = is_opened
    readFrame = read_frame
    readBatch = read_batch
    writeFrame = write_frame
    writeBatch = write_batch


