"""
Definition of the PipeMode for ``AudioIO`` and ``VideoIO`` classes.

Authors
-------
Dominique Vaufreydaz (inspired from original C++ code: https://github.com/Vaufreyd/ReadWriteVideosWithOpenCV)

"""

__authors__ = ("Dominique Vaufreydaz")

from enum import Enum

class PipeMode(Enum):
    """
    Enum class for pipe opening type.
    """
    UNK_MODE = 0
    """ No pipe mode defined """

    READ_MODE = 1  
    """ Read mode (get data from pipe) """

    WRITE_MODE = 2 
    """ Write mode (write data to pipe) """

