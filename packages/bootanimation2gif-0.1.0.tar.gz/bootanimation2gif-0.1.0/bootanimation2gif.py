import os
import argparse
import zipfile
import tempfile
import numpy as np
from PIL import Image, ImageColor
import imageio
from tqdm import tqdm

def parse_desc(desc_content):
    lines = [l.strip() for l in desc_content.split('\n') if l.strip() and not l.startswith('#')]
    if not lines:
        raise ValueError("Empty or invalid desc.txt")
    
    header = lines[0].split()
    w, h, fps = int(header[0]), int(header[1]), int(header[2])
    
    parts = []
    for line in lines[1:]:
        tokens = line.split()
        if not tokens:
            continue
            
        t_type = tokens[0].lower()
        if t_type in ('p', 'c', 'f'):
            if len(tokens) < 4:
                print(f"Warning: malformed desc line ignored: {line}")
                continue
            
            count = int(tokens[1])
            pause = int(tokens[2])
            folder = tokens[3]
            
            bg_color = tokens[4] if len(tokens) > 4 else None
            
            parts.append({
                'type': t_type,
                'count': count,
                'pause': pause,
                'folder': folder,
                'bg_color': bg_color
            })
    return w, h, fps, parts

def print_human_readable_info(w, h, fps, parts, input_path):
    print(f"\n{'='*40}")
    print(f"Bootanimation Info: {os.path.basename(input_path)}")
    print(f"{'='*40}")
    print(f"Native Resolution: {w}x{h}")
    print(f"Native Framerate:  {fps} FPS")
    print(f"Total Parts:       {len(parts)}")
    print("-" * 40)
    for i, p in enumerate(parts, 1):
        print(f"Part {i}:")
        print(f"  Folder:    {p['folder']}")
        
        t_name = p['type']
        if p['type'] == 'c': t_name = 'Complete completely (c)'
        if p['type'] == 'p': t_name = 'Interruptible (p)'
        if p['type'] == 'f': t_name = 'Keep last frame (f)'
        print(f"  Type:      {t_name}")
        
        loop_str = "Infinite" if p['count'] == 0 else str(p['count'])
        print(f"  Loops:     {loop_str}")
        print(f"  Pause:     {p['pause']} frames (after loop)")
        
        if p['bg_color']:
            print(f"  Bg Color:  {p['bg_color']}")
        print("-" * 40)
    print()

def collect_frames(parts, base_dir, fps, infinite_time=10):
    frames = []
    
    for p in parts:
        folder = p['folder']
        count = p['count']
        pause = p['pause']
        folder_path = os.path.join(base_dir, folder)
        
        if not os.path.isdir(folder_path):
            print(f"Warning: folder '{folder}' not found, skipping.")
            continue
            
        files = sorted([f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg'))])
        if not files:
            print(f"Warning: no images in '{folder}', skipping.")
            continue
            
        if count == 0:
            # Infinite logic: loop enough times to fill the requested time for the GIF/MP4
            repeat = max(1, infinite_time * fps // len(files))
            print(f"[{folder}] Infinite loop detected. Repeating {repeat} times (~{infinite_time}s).")
            for _ in range(repeat):
                for f in files:
                    frames.append(os.path.join(folder_path, f))
        else:
            print(f"[{folder}] Adding {count} loop(s) of {len(files)} frames.")
            for _ in range(count):
                for f in files:
                    frames.append(os.path.join(folder_path, f))
        
        # Add pause frames
        if pause > 0 and files:
            print(f"[{folder}] Pausing on last frame for {pause} frames.")
            last_frame = os.path.join(folder_path, files[-1])
            for _ in range(pause):
                frames.append(last_frame)
                
    return frames

def main():
    parser = argparse.ArgumentParser(description="Convert Android bootanimation.zip or folder to GIF/MP4.")
    parser.add_argument("input", nargs="?", default=".", help="Input bootanimation.zip or directory containing desc.txt")
    parser.add_argument("-o", "--output", help="Output file (e.g., output.gif or output.mp4)", default="output.gif")
    parser.add_argument("--info", action="store_true", help="Only parse desc.txt and print human-readable info")
    parser.add_argument("-r", "--resolution", help="Target resolution WxH (e.g., 1280x800). Defaults to native resolution.")
    parser.add_argument("-b", "--bg-color", help="Background color hex or name (e.g., '#000000', 'white'). Default is black.", default="black")
    parser.add_argument("-f", "--fps", type=int, help="Override the framerate (FPS).")
    parser.add_argument("-t", "--infinite-time", type=int, help="Time in seconds for infinite loops (default: 10).", default=10)
    
    args = parser.parse_args()

    input_path = args.input
    is_zip = zipfile.is_zipfile(input_path) if os.path.isfile(input_path) else False
    
    temp_dir = None
    base_dir = input_path
    
    # Extract ZIP to a temporary directory if needed
    if is_zip:
        temp_dir = tempfile.TemporaryDirectory()
        base_dir = temp_dir.name
        with zipfile.ZipFile(input_path, 'r') as zip_ref:
            zip_ref.extractall(base_dir)
    elif not os.path.isdir(input_path):
        print(f"Error: Invalid input directory or zip file: {input_path}")
        return
        
    desc_path = os.path.join(base_dir, "desc.txt")
    if not os.path.exists(desc_path):
        print(f"Error: desc.txt not found in {input_path}!")
        if temp_dir: temp_dir.cleanup()
        return

    with open(desc_path, "r", encoding="utf-8", errors="ignore") as f:
        desc_content = f.read()

    try:
        w, h, native_fps, parts = parse_desc(desc_content)
    except Exception as e:
        print(f"Error parsing desc.txt: {e}")
        if temp_dir: temp_dir.cleanup()
        return
        
    # Apply FPS override
    fps = args.fps if args.fps else native_fps
    
    # Just print info if requested
    if args.info:
        print_human_readable_info(w, h, fps, parts, input_path)
        if temp_dir: temp_dir.cleanup()
        return
        
    # Apply Resolution override
    target_w, target_h = w, h
    if args.resolution:
        try:
            target_w, target_h = map(int, args.resolution.lower().split('x'))
        except ValueError:
            print("Error: Resolution must be formatted as WxH (e.g., 1280x800).")
            if temp_dir: temp_dir.cleanup()
            return
            
    # Apply Background Color
    try:
        bg_color_rgba = ImageColor.getcolor(args.bg_color, "RGBA")
    except ValueError:
        print(f"Warning: Invalid background color '{args.bg_color}'. Falling back to black.")
        bg_color_rgba = (0, 0, 0, 255)

    print(f"\nProcessing {os.path.basename(input_path)} -> {args.output}")
    print(f"Resolution: {target_w}x{target_h} | Framerate: {fps} | BgColor: {args.bg_color}")
    
    # Collect all frame paths from folders
    frames = collect_frames(parts, base_dir, fps, args.infinite_time)
    
    if not frames:
        print("No valid frames were found to process. Exiting.")
        if temp_dir: temp_dir.cleanup()
        return
    
    print(f"Assembling {len(frames)} total frames...")
    
    rendered_frames = []
    for frame_path in tqdm(frames, desc="Rendering"):
        img = Image.open(frame_path).convert("RGBA")
        
        # Create solid background
        bg = Image.new("RGBA", (target_w, target_h), bg_color_rgba)
        
        # Center image onto background
        x = (target_w - img.width) // 2
        y = (target_h - img.height) // 2
        bg.paste(img, (x, y), img)
        
        # Convert back to RGB and then to numpy array for imageio
        rendered_frames.append(np.array(bg.convert("RGB")))
        
    # Save the output
    out_format = args.output.lower()
    try:
        if out_format.endswith(".mp4"):
            imageio.mimsave(args.output, rendered_frames, fps=fps, codec="libx264")
            print(f"\nSuccessfully saved MP4 to {args.output}!")
        else: # Handle .gif as default
            duration_sec = 1.0 / fps
            imageio.mimsave(args.output, rendered_frames, duration=duration_sec, loop=0)
            print(f"\nSuccessfully saved GIF to {args.output}!")
    except Exception as e:
        print(f"\nError occurred while saving: {e}")

    # Cleanup temp directory if we created one
    if temp_dir:
        temp_dir.cleanup()

if __name__ == "__main__":
    main()