# bootanimation2gif
Convert Android bootanimation.zip files to GIF or MP4 with one command.

## Usage
```
positional arguments:
  input                 Input bootanimation.zip or directory containing desc.txt

options:
  -h, --help            show this help message and exit
  -o, --output OUTPUT   Output file (e.g., output.gif or output.mp4)
  --info                Only parse desc.txt and print human-readable info
  -r, --resolution RESOLUTION
                        Target resolution WxH (e.g., 1280x800). Defaults to native resolution.
  -b, --bg-color BG_COLOR
                        Background color hex or name (e.g., '#000000', 'white'). Default is black.
  -f, --fps FPS         Override the framerate (FPS).
  -t, --infinite-time INFINITE_TIME
                        Time in seconds for infinite loops (default: 10).
```