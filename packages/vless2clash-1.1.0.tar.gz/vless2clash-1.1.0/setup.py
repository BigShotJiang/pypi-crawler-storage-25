import os
from setuptools import setup, find_packages

from vless2clash import __version__


with open(os.path.join(os.path.dirname(__file__), 'README.md'), 'r', encoding='utf-8') as file:
    ldescription = file.read()

setup(
    name='vless2clash',
    version=__version__,
    author='spinepith',
    description='Convert VLESS links to CLASH config [proxies & proxy-groups]',
    long_description=ldescription,
    long_description_content_type='text/markdown',
    url='https://github.com/spinepith/vless2clash.git',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'vless2clash = vless2clash.__main__:execute',
        ],
    },
    python_requires='>=3.8'
)
