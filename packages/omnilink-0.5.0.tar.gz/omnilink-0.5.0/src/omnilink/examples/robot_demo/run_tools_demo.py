"""Robot Demo — unified tool-based architecture.

Replaces the dual Command/Tool system with a single set of tools.
Every robot action (movement, scanning, pickup) and every query
(position, pathfinding, map info) is a tool with inline JSON args.

Start the simulation first:
    python -m omnilink.examples.robot_demo.robot_sim

Then run this demo:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.run_tools_demo

Then open https://www.omnilink-agents.com/build and control the robot.
Press Ctrl+C to stop.
"""

from __future__ import annotations

import os
import pathlib
import signal
import sys
import threading
from typing import Any

LIB_PATH = pathlib.Path(__file__).resolve().parents[4] / "src"
if str(LIB_PATH) not in sys.path:
    sys.path.insert(0, str(LIB_PATH))

from omnilink.tool_runner import ToolRunner
from omnilink.client import OmniLinkClient

from .robot_tools import ALL_ROBOT_TOOLS
from .robot_api import get_state, SERVER_URL

# ── Configuration ────────────────────────────────────────────────────

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get(
    "OMNILINK_BASE_URL", "https://www.omnilink-agents.com"
)


# ── Runner ───────────────────────────────────────────────────────────


class RobotToolsRunner(ToolRunner):
    """Robot controller using the unified tool architecture."""

    agent_name = "robot-demo"
    display_name = "Robot Demo"
    engine = "g3-engine"
    tool_name = "control_robot"
    tool_description = "Control the robot using the available tools."
    commands = "stop_game, pause_game, resume_game"
    game_server_url = SERVER_URL

    default_tools = ALL_ROBOT_TOOLS

    def get_profile_settings(self) -> dict[str, Any]:
        settings = super().get_profile_settings()
        settings["mainTask"] = (
            "You control a mobile robot on a grid world. "
            "Use the available tools to move the robot, collect items, "
            "and explore the map. Do exactly what the user asks, then "
            "report the result.\n\n"
            "STRATEGY RULES:\n"
            "1. ALWAYS call pick_up immediately after go_to if there is an item at the destination.\n"
            "2. Prefer action tools (go_to, pick_up, collect_item, scan_and_list) over query tools (get_status, get_map_info).\n"
            "3. When you see items in results, go collect the nearest one immediately — do not waste a round on extra queries.\n"
            "4. Do NOT call get_status or get_map_info unless you specifically need that information for a decision.\n"
            "5. Ideal loop: scan_and_list → collect_item(nearest) → repeat. Use compound tools when possible.\n"
            "6. Battery is limited. Minimize unnecessary movement and queries."
        )
        settings["maxToolRounds"] = 15
        return settings

    def get_state(self) -> dict[str, Any]:
        return {}

    def execute_action(self, state: dict[str, Any]) -> None:
        pass

    def state_summary(self, state: dict[str, Any]) -> str:
        return "idle"

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return True


# ── Entry point ──────────────────────────────────────────────────────


def _start_headless_sim(port: int = 5050) -> None:
    """Start the robot sim headless if not already running."""
    import os as _os
    _os.environ["SDL_VIDEODRIVER"] = "dummy"
    _os.environ["SDL_AUDIODRIVER"] = "dummy"

    from . import robot_sim as sim_mod
    from .robot_sim import RobotSim, Handler
    import http.server as _hs

    sim = RobotSim()
    sim_mod._SIM = sim
    server = _hs.ThreadingHTTPServer(("0.0.0.0", port), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()


def main() -> None:
    if not OMNI_KEY:
        print("Set OMNI_KEY before running:  export OMNI_KEY=omk_...")
        sys.exit(1)

    # Connect to running sim, or start headless.
    import time as _time
    try:
        state = get_state()
        r = state["robot"]
        print(f"Sim connected: robot at ({r['x']},{r['y']}) facing {r['heading']}, battery={state['battery']}%")
    except Exception:
        print("No sim running — starting headless sim on port 5050...")
        _start_headless_sim()
        _time.sleep(0.5)
        state = get_state()
        r = state["robot"]
        print(f"Headless sim started: robot at ({r['x']},{r['y']}) facing {r['heading']}, battery={state['battery']}%")

    runner = RobotToolsRunner()
    runner.omni_key = OMNI_KEY
    runner.base_url = BASE_URL

    client = OmniLinkClient(omni_key=OMNI_KEY, base_url=BASE_URL, timeout=60)
    runner._client = client
    runner._conversation_history = []
    runner._activity_log = []

    port = runner._start_tool_server()
    scheme = "https" if runner._ssl_enabled else "http"
    runner.tool_callback_url = f"{scheme}://127.0.0.1:{port}/tool"

    runner._ensure_profile(client)

    try:
        client.set_memory(runner._memory_agent_key(), [])
    except Exception:
        pass

    print()
    print("=" * 60)
    print("  Robot Demo — Unified Tool Architecture")
    print("=" * 60)
    print()
    print(f"  Tool server:  {scheme}://127.0.0.1:{port}/tool")
    print(f"  Activity log: {scheme}://127.0.0.1:{port}/activity")
    print(f"  Robot sim:    {SERVER_URL}")
    print()
    print(f"  Open the UI:  {BASE_URL}/build")
    print()
    print("  18 tools (compound + actions + queries), all as Tool: name({args}):")
    print("    collect_item, scan_and_list,  (compound)")
    print("    move_forward, move_backward, turn_left, turn_right,")
    print("    go_to, scan_area, pick_up, drop_item, set_speed,")
    print("    get_status, get_items, get_obstacles, check_collision,")
    print("    find_path, get_map_info, analyze_surroundings")
    print()
    print("  Try:")
    print('    "Check your status and scan the area"')
    print('    "Find the nearest item and go pick it up"')
    print('    "Explore the map and collect all items"')
    print('    "Move forward 3 times then turn left"')
    print('    "Find a path to position 5,3"')
    print()
    print("  Make sure robot_sim is running:")
    print("    python -m omnilink.examples.robot_demo.robot_sim")
    print()
    print("  Press Ctrl+C to stop.")
    print("=" * 60)
    print()

    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    try:
        signal.signal(signal.SIGBREAK, lambda *_: stop.set())
    except AttributeError:
        pass

    stop.wait()

    print()
    print("  Shutting down.")


if __name__ == "__main__":
    main()
