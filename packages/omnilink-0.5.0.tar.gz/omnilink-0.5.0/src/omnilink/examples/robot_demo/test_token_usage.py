#!/usr/bin/env python3
"""Token usage benchmark — run the robot demo for a target duration and track costs.

Usage:
    OMNI_KEY="olink_..." python test_token_usage.py <minutes> [engine]

Examples:
    python test_token_usage.py 10 g3-engine
    python test_token_usage.py 30 g3-engine
    python test_token_usage.py 60 g3-engine
"""

from __future__ import annotations

import json
import os
import sys
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

import requests

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = "https://www.omnilink-agents.com"
AGENT_NAME = "robot-demo"

TOOL_DETAILS = [
    {"name": "move_forward", "description": "Move one tile forward.", "parameters": {"type": "object", "properties": {}}},
    {"name": "move_backward", "description": "Move one tile backward.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_left", "description": "Rotate 90 degrees left.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_right", "description": "Rotate 90 degrees right.", "parameters": {"type": "object", "properties": {}}},
    {"name": "go_to", "description": "Navigate to a grid position using A* pathfinding. Moves the full path in one call.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "scan_area", "description": "Scan area to reveal tiles and items.", "parameters": {"type": "object", "properties": {}}},
    {"name": "pick_up", "description": "Pick up item at current position.", "parameters": {"type": "object", "properties": {}}},
    {"name": "drop_item", "description": "Drop last inventory item.", "parameters": {"type": "object", "properties": {}}},
    {"name": "set_speed", "description": "Set movement speed (1-5).", "parameters": {"type": "object", "properties": {"speed": {"type": "integer"}}, "required": ["speed"]}},
    {"name": "get_status", "description": "Get full status: position, heading, battery, inventory, score, items remaining.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_items", "description": "Get visible items within 5 tiles.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_obstacles", "description": "Get obstacles within 5 tiles.", "parameters": {"type": "object", "properties": {}}},
    {"name": "check_collision", "description": "Check if forward move is safe.", "parameters": {"type": "object", "properties": {}}},
    {"name": "find_path", "description": "A* pathfinding to target.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "get_map_info", "description": "Map dimensions, obstacle/item counts, explored area.", "parameters": {"type": "object", "properties": {}}},
    {"name": "analyze_surroundings", "description": "What is in each adjacent tile (N/S/E/W) and current tile.", "parameters": {"type": "object", "properties": {}}},
    {"name": "collect_item", "description": "Navigate to a position and pick up the item there in one step.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "scan_and_list", "description": "Scan the area to reveal tiles, then return all visible items nearby.", "parameters": {"type": "object", "properties": {}}},
]

SI = {
    "mainTask": (
        "You control a mobile robot on a 20x15 grid world. "
        "Use the available tools to move the robot, collect items, "
        "and explore the map. For multi-step tasks, keep calling tools "
        "until the task is fully complete. Do not stop early."
    ),
    "agentName": AGENT_NAME,
    "allowToolUse": True,
    "availableTools": ", ".join(t["name"] for t in TOOL_DETAILS),
    "availableToolDetails": TOOL_DETAILS,
    "maxToolRounds": 50,
}

# Task prompts — cycled through during the benchmark
TASK_PROMPTS = [
    "Explore the map: navigate to position 10,7, scan the area, and report what you find.",
    "Find the nearest item, go pick it up, then check your status.",
    "Do a perimeter patrol: go to (0,0), then (19,0), scan at each stop.",
    "Check your surroundings, find obstacles nearby, then move to a safe open area.",
    "Navigate to (15,10), scan the area, look for items, and collect any you find.",
    "Go to the center of the map, analyze your surroundings in all directions, then report status.",
    "Move forward 3 times, turn right, move forward 2 times, then scan the area.",
    "Find a path to (5,12), navigate there, scan, and pick up any items.",
    "Check battery, check map info, then explore the bottom-right corner at (18,13).",
    "Go to (3,3), scan, go to (16,3), scan, report status at the end.",
]


@dataclass
class TokenStats:
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    total_tokens: int = 0
    total_cached_tokens: int = 0
    total_reasoning_tokens: int = 0
    total_cost_ticks: int = 0  # cost_in_usd_ticks
    api_calls: int = 0
    tool_calls: int = 0
    tasks_completed: int = 0
    rounds: int = 0
    errors: int = 0
    per_task: list = field(default_factory=list)

    def add(self, raw_usage: dict, tool_count: int = 0):
        pt = raw_usage.get("prompt_tokens", 0)
        ct = raw_usage.get("completion_tokens", 0)
        tt = raw_usage.get("total_tokens", 0)
        cached = raw_usage.get("prompt_tokens_details", {}).get("cached_tokens", 0)
        reasoning = raw_usage.get("completion_tokens_details", {}).get("reasoning_tokens", 0)
        cost = raw_usage.get("cost_in_usd_ticks", 0)

        self.total_prompt_tokens += pt
        self.total_completion_tokens += ct
        self.total_tokens += tt
        self.total_cached_tokens += cached
        self.total_reasoning_tokens += reasoning
        self.total_cost_ticks += cost
        self.api_calls += 1
        self.tool_calls += tool_count


def get_tool_server() -> str:
    from omnilink.client import OmniLinkClient
    c = OmniLinkClient(omni_key=OMNI_KEY)
    profiles = c.list_profiles()
    p = next((p for p in profiles if p["name"] == AGENT_NAME), None)
    if p:
        return p["settings"].get("toolCallbackUrl", "http://127.0.0.1:5050/tool")
    return "http://127.0.0.1:5050/tool"


def exec_tool(tool_server: str, name: str, args: dict) -> dict:
    body = {"tool": name, **args}
    r = requests.post(tool_server, json=body, timeout=10)
    d = r.json()
    return d.get("result", d)


def run_task(tool_server: str, engine: str, prompt: str, stats: TokenStats, max_rounds: int = 20) -> None:
    conversation: list[dict[str, str]] = [{"role": "user", "content": prompt}]
    task_tokens = 0
    task_tools = 0
    task_rounds = 0

    for rnd in range(1, max_rounds + 1):
        body = {
            "agentName": AGENT_NAME,
            "messages": conversation[-12:],
            "skipMemory": True,
            "requestId": str(uuid.uuid4()),
            "engine": engine,
            "temperature": 0.1,
            "systemInstructionRequest": SI,
        }
        try:
            resp = requests.post(
                f"{BASE_URL}/api/chat",
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {OMNI_KEY}"},
                json=body,
                timeout=90,
            )
        except Exception:
            stats.errors += 1
            break

        if not resp.ok:
            stats.errors += 1
            break

        data = resp.json()
        raw_usage = data.get("raw", {}).get("usage", {})
        text = data.get("text", "")
        tcs = data.get("toolCalls", [])

        stats.add(raw_usage, len(tcs))
        stats.rounds += 1
        task_rounds += 1
        task_tokens += raw_usage.get("total_tokens", 0)
        task_tools += len(tcs)

        conversation.append({"role": "assistant", "content": text})

        if not tcs:
            break

        for tc in tcs:
            tn = tc.get("name", "")
            ta = tc.get("arguments", {})
            try:
                result = exec_tool(tool_server, tn, ta)
            except Exception:
                result = {"error": "execution failed"}
            rs = json.dumps(result, default=str)
            conversation.append({"role": "user", "content": f"tool-output: {tn}\n{rs}"})

        time.sleep(2)

    stats.tasks_completed += 1
    stats.per_task.append({
        "prompt": prompt[:60],
        "rounds": task_rounds,
        "tools": task_tools,
        "tokens": task_tokens,
    })


def main():
    if not OMNI_KEY:
        print("Set OMNI_KEY.")
        sys.exit(1)

    target_minutes = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    engine = sys.argv[2] if len(sys.argv) > 2 else "g3-engine"
    target_seconds = target_minutes * 60

    try:
        tool_server = get_tool_server()
    except Exception:
        tool_server = "http://127.0.0.1:5050/tool"

    print("=" * 70)
    print(f"  TOKEN USAGE BENCHMARK")
    print(f"  Engine: {engine} | Target: {target_minutes} min | Tool server: {tool_server}")
    print("=" * 70)
    print()

    stats = TokenStats()
    start = time.time()
    task_idx = 0

    while (time.time() - start) < target_seconds:
        prompt = TASK_PROMPTS[task_idx % len(TASK_PROMPTS)]
        task_idx += 1
        elapsed = time.time() - start
        remaining = target_seconds - elapsed
        print(f"  [{elapsed/60:.1f}m / {target_minutes}m] Task {task_idx}: {prompt[:55]}...")

        # Reset sim before each task so battery is always fresh
        try:
            requests.post("http://127.0.0.1:5050/callback", json={"action": "RESET"}, timeout=5)
        except Exception:
            pass

        run_task(tool_server, engine, prompt, stats, max_rounds=20)

        pt = stats.per_task[-1]
        print(f"    -> {pt['rounds']} rounds, {pt['tools']} tools, {pt['tokens']} tokens")
        print()

        if remaining < 30:
            break
        time.sleep(3)

    elapsed = time.time() - start
    elapsed_min = elapsed / 60

    # Cost calculation (cost_in_usd_ticks is in millionths of a dollar)
    cost_usd = stats.total_cost_ticks / 1_000_000 if stats.total_cost_ticks else 0

    print()
    print("=" * 70)
    print(f"  RESULTS — {target_minutes} MINUTE BENCHMARK")
    print("=" * 70)
    print()
    print(f"  Duration:           {elapsed_min:.1f} minutes")
    print(f"  Engine:             {engine}")
    print(f"  Tasks completed:    {stats.tasks_completed}")
    print(f"  API calls:          {stats.api_calls}")
    print(f"  Tool calls:         {stats.tool_calls}")
    print(f"  Total rounds:       {stats.rounds}")
    print(f"  Errors:             {stats.errors}")
    print()
    print(f"  --- Token Usage ---")
    print(f"  Prompt tokens:      {stats.total_prompt_tokens:,}")
    print(f"  Completion tokens:  {stats.total_completion_tokens:,}")
    print(f"  Total tokens:       {stats.total_tokens:,}")
    print(f"  Cached tokens:      {stats.total_cached_tokens:,}")
    print(f"  Reasoning tokens:   {stats.total_reasoning_tokens:,}")
    print()
    print(f"  --- Rates ---")
    print(f"  Tokens/minute:      {stats.total_tokens / elapsed_min:,.0f}")
    print(f"  Tokens/task:        {stats.total_tokens / max(stats.tasks_completed, 1):,.0f}")
    print(f"  Tokens/API call:    {stats.total_tokens / max(stats.api_calls, 1):,.0f}")
    print(f"  Tools/minute:       {stats.tool_calls / elapsed_min:,.1f}")
    print(f"  API calls/minute:   {stats.api_calls / elapsed_min:,.1f}")
    if cost_usd > 0:
        print()
        print(f"  --- Estimated Cost ---")
        print(f"  Total cost:         ${cost_usd:.4f}")
        print(f"  Cost/minute:        ${cost_usd / elapsed_min:.4f}")
        print(f"  Cost/hour:          ${cost_usd / elapsed_min * 60:.4f}")
        print(f"  Cost/task:          ${cost_usd / max(stats.tasks_completed, 1):.4f}")
    print()
    print(f"  --- Per-Task Breakdown ---")
    print(f"  {'#':>3}  {'Rounds':>6}  {'Tools':>6}  {'Tokens':>8}  Prompt")
    print(f"  {'---':>3}  {'------':>6}  {'------':>6}  {'--------':>8}  {'---'}")
    for i, pt in enumerate(stats.per_task, 1):
        print(f"  {i:3d}  {pt['rounds']:6d}  {pt['tools']:6d}  {pt['tokens']:8,d}  {pt['prompt']}")
    print()
    print("=" * 70)

    # Write JSON results
    results = {
        "engine": engine,
        "target_minutes": target_minutes,
        "actual_minutes": round(elapsed_min, 1),
        "tasks_completed": stats.tasks_completed,
        "api_calls": stats.api_calls,
        "tool_calls": stats.tool_calls,
        "total_rounds": stats.rounds,
        "errors": stats.errors,
        "tokens": {
            "prompt": stats.total_prompt_tokens,
            "completion": stats.total_completion_tokens,
            "total": stats.total_tokens,
            "cached": stats.total_cached_tokens,
            "reasoning": stats.total_reasoning_tokens,
        },
        "rates": {
            "tokens_per_minute": round(stats.total_tokens / elapsed_min),
            "tokens_per_task": round(stats.total_tokens / max(stats.tasks_completed, 1)),
            "tokens_per_api_call": round(stats.total_tokens / max(stats.api_calls, 1)),
            "tools_per_minute": round(stats.tool_calls / elapsed_min, 1),
        },
        "cost": {
            "total_usd": round(cost_usd, 4),
            "per_minute_usd": round(cost_usd / elapsed_min, 4),
            "per_hour_usd": round(cost_usd / elapsed_min * 60, 4),
            "per_task_usd": round(cost_usd / max(stats.tasks_completed, 1), 4),
        },
        "per_task": stats.per_task,
    }

    out_path = f"token_usage_{target_minutes}min_{engine}.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"  Results saved to: {out_path}")


if __name__ == "__main__":
    main()
