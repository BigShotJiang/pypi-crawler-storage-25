#!/usr/bin/env python3
"""Test long-horizon tasks through the full tool execution loop.

Simulates the exact frontend tool chain: send prompt -> AI calls tool ->
execute tool on sim -> send result back -> AI calls next tool -> repeat.

Usage:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.test_long_horizon
"""

from __future__ import annotations

import json
import os
import sys
import time
import uuid
from typing import Any

import requests

from .robot_api import get_state, send_action, call_tool

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = "https://www.omnilink-agents.com"
AGENT_NAME = "robot-demo"

TOOL_DETAILS = [
    {"name": "move_forward", "description": "Move the robot one tile forward in its current heading direction.", "parameters": {"type": "object", "properties": {}}},
    {"name": "move_backward", "description": "Move the robot one tile backward (opposite of heading).", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_left", "description": "Rotate the robot 90 degrees to the left.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_right", "description": "Rotate the robot 90 degrees to the right.", "parameters": {"type": "object", "properties": {}}},
    {"name": "go_to", "description": "Navigate the robot to a specific grid position.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "scan_area", "description": "Scan the area around the robot to reveal hidden tiles and items.", "parameters": {"type": "object", "properties": {}}},
    {"name": "pick_up", "description": "Pick up an item at the robot's current position.", "parameters": {"type": "object", "properties": {}}},
    {"name": "drop_item", "description": "Drop the last item in the robot's inventory.", "parameters": {"type": "object", "properties": {}}},
    {"name": "set_speed", "description": "Set the robot's movement speed (1-5).", "parameters": {"type": "object", "properties": {"speed": {"type": "integer"}}, "required": ["speed"]}},
    {"name": "get_status", "description": "Get full status: position, heading, battery, inventory, score, items remaining.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_items", "description": "Get positions of visible items near the robot (within 5 tiles).", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_obstacles", "description": "Get positions of obstacles near the robot (within 5 tiles).", "parameters": {"type": "object", "properties": {}}},
    {"name": "check_collision", "description": "Check if moving forward is safe.", "parameters": {"type": "object", "properties": {}}},
    {"name": "find_path", "description": "A* pathfinding to target position.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "get_map_info", "description": "Get map dimensions, obstacle count, item count, explored area.", "parameters": {"type": "object", "properties": {}}},
    {"name": "analyze_surroundings", "description": "Check what is in each adjacent tile (N/S/E/W) and current tile.", "parameters": {"type": "object", "properties": {}}},
]

SYSTEM_INSTRUCTION = {
    "mainTask": (
        "You control a mobile robot on a 20x15 grid world. "
        "Use the available tools to move the robot, collect items, "
        "and explore the map. Do exactly what the user asks, then "
        "report the result. For multi-step tasks, keep calling tools "
        "until the task is fully complete."
    ),
    "agentName": AGENT_NAME,
    "allowToolUse": True,
    "availableTools": ", ".join(t["name"] for t in TOOL_DETAILS),
    "availableToolDetails": TOOL_DETAILS,
    "toolCallbackUrl": "http://127.0.0.1:5050/tool",
    "maxToolRounds": 20,
}


def execute_tool_on_sim(tool_name: str, args: dict) -> dict:
    """Execute a tool call on the local sim and return the result."""
    # Action tools — call via /callback
    action_tools = {
        "move_forward", "move_backward", "turn_left", "turn_right",
        "scan_area", "pick_up", "drop_item",
    }
    if tool_name in action_tools:
        msg = send_action(tool_name)
        state = get_state()
        r = state.get("robot", {})
        return {
            "message": msg,
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
        }
    elif tool_name == "go_to":
        msg = send_action("go_to", x=int(args.get("x", 0)), y=int(args.get("y", 0)))
        state = get_state()
        r = state.get("robot", {})
        return {"message": msg, "position": {"x": r.get("x"), "y": r.get("y")}, "battery": state.get("battery")}
    elif tool_name == "set_speed":
        msg = send_action("set_speed", speed=int(args.get("speed", 1)))
        return {"message": msg, "speed": int(args.get("speed", 1))}
    else:
        # Query tools — call via /tool on sim
        try:
            return call_tool(tool_name, **args)
        except Exception:
            # Fallback: compute locally
            state = get_state()
            from .robot_engine import execute_tool
            return execute_tool(tool_name, state, **args)


def send_chat(engine: str, messages: list[dict], max_rounds: int = 20) -> list[dict]:
    """Run the full tool execution loop through /api/chat.

    Returns the full list of tool executions: [{tool, args, result, round}]
    """
    conversation = list(messages)
    executions: list[dict] = []

    for round_num in range(1, max_rounds + 1):
        body = {
            "agentName": AGENT_NAME,
            "messages": conversation[-12:],  # keep last 12 turns
            "usePromptPipeline": True,
            "skipMemory": True,
            "requestId": str(uuid.uuid4()),
            "engine": engine,
            "temperature": 0.1,
            "systemInstructionRequest": SYSTEM_INSTRUCTION,
        }

        try:
            resp = requests.post(
                f"{BASE_URL}/api/chat",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {OMNI_KEY}",
                },
                json=body,
                timeout=60,
            )
            if not resp.ok:
                print(f"      [round {round_num}] HTTP {resp.status_code}")
                break
            data = resp.json()
        except Exception as e:
            print(f"      [round {round_num}] Error: {e}")
            break

        text = data.get("text", "")
        tool_calls = data.get("toolCalls", [])

        # Add AI response to conversation
        conversation.append({"role": "assistant", "content": text})

        if not tool_calls:
            # AI stopped calling tools — chain complete
            if text:
                safe_text = text[:100].encode("ascii", "replace").decode("ascii")
                print(f"      [round {round_num}] AI done: {safe_text}")
            break

        # Execute each tool call
        for tc in tool_calls:
            tool_name = tc.get("name", "")
            tool_args = tc.get("arguments", {})

            # Execute on sim
            try:
                result = execute_tool_on_sim(tool_name, tool_args)
            except Exception as e:
                result = {"error": str(e)}

            executions.append({
                "round": round_num,
                "tool": tool_name,
                "args": tool_args,
                "result": result,
            })

            result_text = json.dumps(result, default=str)
            safe_result = result_text[:80].encode("ascii", "replace").decode("ascii")
            print(f"      [round {round_num}] {tool_name}({json.dumps(tool_args)}) -> {safe_result}")

            # Feed result back to AI as next user message (like frontend does)
            conversation.append({
                "role": "user",
                "content": f"tool-output: {tool_name}\n{result_text}",
            })

        time.sleep(2)  # rate limit

    return executions


def get_sim_state_summary() -> str:
    state = get_state()
    r = state.get("robot", {})
    return (
        f"pos=({r.get('x')},{r.get('y')}) heading={r.get('heading')} "
        f"bat={state.get('battery')}% score={state.get('score')} "
        f"steps={state.get('steps_taken')} items_left={state.get('items_remaining')} "
        f"inv={state.get('inventory', [])}"
    )


def main():
    if not OMNI_KEY:
        print("Set OMNI_KEY environment variable.")
        sys.exit(1)

    # Verify sim is running
    try:
        state = get_state()
        r = state["robot"]
        print(f"Sim connected: ({r['x']},{r['y']}) {r['heading']} bat={state['battery']}%")
    except Exception:
        print("ERROR: Start the sim first.")
        sys.exit(1)

    engines = ["g3-engine"]  # Start with g3, add more if needed
    if len(sys.argv) > 1:
        engines = sys.argv[1].split(",")

    tasks = [
        (
            "Move forward 5 times",
            lambda execs: sum(1 for e in execs if e["tool"] == "move_forward") >= 3,
        ),
        (
            "Navigate to position 10, 7 and scan the area when you arrive",
            lambda execs: any(e["tool"] == "go_to" or e["tool"] == "find_path" for e in execs)
            and any(e["tool"] == "scan_area" for e in execs),
        ),
        (
            "Explore the map: go to each corner (0,0), (19,0), (19,14), (0,14) and scan at each one",
            lambda execs: sum(1 for e in execs if e["tool"] in ("go_to", "find_path")) >= 2
            and sum(1 for e in execs if e["tool"] == "scan_area") >= 2,
        ),
        (
            "Find the nearest item, navigate to it, and pick it up",
            lambda execs: any(e["tool"] == "get_items" for e in execs)
            and any(e["tool"] in ("go_to", "find_path", "move_forward") for e in execs),
        ),
        (
            "Check your status, then move forward 3 times, turn right, move forward 2 more times, then report status again",
            lambda execs: sum(1 for e in execs if e["tool"] == "get_status") >= 2
            and sum(1 for e in execs if e["tool"] == "move_forward") >= 3,
        ),
    ]

    for engine in engines:
        print()
        print("=" * 70)
        print(f"  ENGINE: {engine}")
        print("=" * 70)

        for i, (task_prompt, validator) in enumerate(tasks, 1):
            print()
            print(f"  Task {i}: \"{task_prompt}\"")
            print(f"  Before: {get_sim_state_summary()}")
            print()

            messages = [{"role": "user", "content": task_prompt}]
            executions = send_chat(engine, messages, max_rounds=20)

            after = get_sim_state_summary()
            total_tools = len(executions)
            tool_names = [e["tool"] for e in executions]
            passed = validator(executions)

            print()
            print(f"  After:  {after}")
            print(f"  Tools called ({total_tools}): {tool_names}")
            print(f"  Result: {'PASS' if passed else 'FAIL'}")
            print(f"  {'-' * 66}")

            time.sleep(3)

    print()
    print("=" * 70)
    print("  DONE")
    print("=" * 70)


if __name__ == "__main__":
    main()
