#!/usr/bin/env python3
"""Full map exploration test through the ToolRunner (exact UI pipeline)."""

from __future__ import annotations

import json
import os
import sys
import time
import uuid
from typing import Any

import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

LIB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
sys.path.insert(0, os.path.join(LIB_PATH, "src"))

from omnilink.examples.robot_demo.robot_api import get_state

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = "https://www.omnilink-agents.com"
AGENT_NAME = "robot-demo"
MAX_ROUNDS = 50

# Discover ToolRunner port from profile
def get_tool_server():
    from omnilink.client import OmniLinkClient
    c = OmniLinkClient(omni_key=OMNI_KEY)
    p = next(p for p in c.list_profiles() if p["name"] == AGENT_NAME)
    return p["settings"].get("toolCallbackUrl", "http://127.0.0.1:5050/tool")

TOOL_DETAILS = [
    {"name": "move_forward", "description": "Move one tile forward.", "parameters": {"type": "object", "properties": {}}},
    {"name": "move_backward", "description": "Move one tile backward.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_left", "description": "Rotate 90 degrees left.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_right", "description": "Rotate 90 degrees right.", "parameters": {"type": "object", "properties": {}}},
    {"name": "go_to", "description": "Navigate to a grid position.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "scan_area", "description": "Scan area to reveal tiles and items.", "parameters": {"type": "object", "properties": {}}},
    {"name": "pick_up", "description": "Pick up item at current position.", "parameters": {"type": "object", "properties": {}}},
    {"name": "drop_item", "description": "Drop last inventory item.", "parameters": {"type": "object", "properties": {}}},
    {"name": "set_speed", "description": "Set movement speed (1-5).", "parameters": {"type": "object", "properties": {"speed": {"type": "integer"}}, "required": ["speed"]}},
    {"name": "get_status", "description": "Get full status: position, heading, battery, inventory, score, items remaining.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_items", "description": "Get visible items within 5 tiles.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_obstacles", "description": "Get obstacles within 5 tiles.", "parameters": {"type": "object", "properties": {}}},
    {"name": "check_collision", "description": "Check if forward move is safe.", "parameters": {"type": "object", "properties": {}}},
    {"name": "find_path", "description": "A* pathfinding to target.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "get_map_info", "description": "Map dimensions, obstacle/item counts, explored area.", "parameters": {"type": "object", "properties": {}}},
    {"name": "analyze_surroundings", "description": "What is in each adjacent tile (N/S/E/W) and current tile.", "parameters": {"type": "object", "properties": {}}},
]

SI = {
    "mainTask": (
        "You control a mobile robot on a 20x15 grid world. "
        "Use the available tools to move the robot, collect items, "
        "and explore the map. For multi-step tasks, keep calling tools "
        "until the task is fully complete. Do not stop early."
    ),
    "agentName": AGENT_NAME,
    "allowToolUse": True,
    "availableTools": ", ".join(t["name"] for t in TOOL_DETAILS),
    "availableToolDetails": TOOL_DETAILS,
    "maxToolRounds": MAX_ROUNDS,
}


def safe(s: str, n: int = 100) -> str:
    return s[:n].encode("ascii", "replace").decode("ascii")


def exec_tool(tool_server: str, name: str, args: dict) -> dict:
    body = {"tool": name, **args}
    r = requests.post(tool_server, json=body, timeout=10, verify=False)
    d = r.json()
    return d.get("result", d)


def state_str() -> str:
    s = get_state()
    r = s["robot"]
    return (
        f"({r['x']},{r['y']}) {r['heading']} bat={s['battery']}% "
        f"score={s['score']} steps={s['steps_taken']} "
        f"inv={s['inventory']} items_left={s['items_remaining']}"
    )


def run_task(tool_server: str, engine: str, prompt: str, max_rounds: int = MAX_ROUNDS) -> list[str]:
    print(f"  Before: {state_str()}")
    print()

    conversation: list[dict[str, str]] = [{"role": "user", "content": prompt}]
    all_tools: list[str] = []
    start_time = time.time()

    for rnd in range(1, max_rounds + 1):
        body = {
            "agentName": AGENT_NAME,
            "messages": conversation[-14:],
            "skipMemory": True,
            "requestId": str(uuid.uuid4()),
            "engine": engine,
            "temperature": 0.1,
            "systemInstructionRequest": SI,
        }
        try:
            resp = requests.post(
                f"{BASE_URL}/api/chat",
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {OMNI_KEY}"},
                json=body,
                timeout=90,
            )
        except Exception as e:
            print(f"    [R{rnd}] Network error: {e}")
            break

        if not resp.ok:
            print(f"    [R{rnd}] HTTP {resp.status_code}")
            break

        data = resp.json()
        text = data.get("text", "")
        tcs = data.get("toolCalls", [])

        conversation.append({"role": "assistant", "content": text})

        if not tcs:
            print(f"    [R{rnd}] DONE: {safe(text, 120)}")
            break

        for tc in tcs:
            tn = tc.get("name", "")
            ta = tc.get("arguments", {})
            try:
                result = exec_tool(tool_server, tn, ta)
            except Exception as e:
                result = {"error": str(e)}
            all_tools.append(tn)
            rs = json.dumps(result, default=str)
            print(f"    [R{rnd}] {tn}({json.dumps(ta)}) -> {safe(rs, 90)}")
            conversation.append({"role": "user", "content": f"tool-output: {tn}\n{rs}"})

        time.sleep(2)

    elapsed = time.time() - start_time
    print()
    print(f"  After:  {state_str()}")
    print(f"  Total tool calls: {len(all_tools)}")
    counts = {t: all_tools.count(t) for t in sorted(set(all_tools))}
    print(f"  Breakdown: {json.dumps(counts)}")
    print(f"  Duration: {elapsed:.1f}s ({len(all_tools)} tools in {rnd} rounds)")
    return all_tools


def main():
    if not OMNI_KEY:
        print("Set OMNI_KEY.")
        sys.exit(1)

    try:
        state = get_state()
    except Exception:
        print("ERROR: Start sim first.")
        sys.exit(1)

    tool_server = get_tool_server()
    print(f"Tool server: {tool_server}")

    engine = sys.argv[1] if len(sys.argv) > 1 else "g3-engine"

    tasks = [
        (
            "Explore the entire map systematically. First check the map size, then navigate "
            "to each corner: (0,0), (19,0), (19,14), (0,14). Scan the area at each corner. "
            "If you find items along the way, pick them up. Keep going until you visit all 4 corners."
        ),
        (
            "Collect as many items as possible. Scan your area, find nearby items, navigate "
            "to the closest one, pick it up, then look for the next. Keep collecting until "
            "you have at least 3 items or you cannot find more."
        ),
        (
            "Full reconnaissance: check status, get map info, scan area, analyze surroundings, "
            "check obstacles, find items. Then navigate to the center of the map at (10,7), "
            "scan there, and give a final status report."
        ),
    ]

    print()
    print("=" * 70)
    print(f"  LONG-HORIZON EXPLORATION TEST | Engine: {engine} | Max rounds: {MAX_ROUNDS}")
    print(f"  Start: {state_str()}")
    print("=" * 70)

    task_results = []
    for i, task in enumerate(tasks, 1):
        print()
        print(f"  {'=' * 66}")
        print(f"  TASK {i}: {safe(task, 90)}")
        print(f"  {'=' * 66}")
        print()
        tools = run_task(tool_server, engine, task)
        task_results.append((i, tools))
        time.sleep(5)

    # Final summary
    print()
    print("=" * 70)
    print("  PERFORMANCE SUMMARY")
    print("=" * 70)
    print(f"  Final state: {state_str()}")
    print()
    total_tools = sum(len(t) for _, t in task_results)
    for i, tools in task_results:
        counts = {t: tools.count(t) for t in sorted(set(tools))}
        print(f"  Task {i}: {len(tools)} tool calls")
        print(f"    {json.dumps(counts)}")
    print()
    print(f"  Grand total: {total_tools} tool calls across {len(tasks)} tasks")
    print("=" * 70)


if __name__ == "__main__":
    main()
