# Robot Demo — Native Structured Tool Calling Architecture

This document describes the control architecture used by the robot demo.
The same pattern applies to all OmniLink examples.

---

## Overview

```
┌─────────────────────┐     HTTPS      ┌─────────────────────────────────┐
│   OmniLink Web UI   │ ◄────────────► │     OmniLink Platform           │
│  (browser, user)    │   /api/chat     │  (AI engines with native tools) │
└────────┬────────────┘                 └────────────┬────────────────────┘
         │                                           │
         │  The AI responds with structured          │ Engine sends tools via
         │  tool_use blocks (not text).              │ provider's native API:
         │                                           │  - OpenAI: tools[].function
         │  HTTP (toolCallbackUrl)                   │  - Anthropic: tools[].input_schema
         ▼                                           │  - Gemini: functionDeclarations
┌─────────────────────┐     HTTP        ┌────────────┘
│   ToolRunner        │ ◄────────────►
│  (Python process)   │  POST /tool
│                     │
│  - Tool server      │     HTTP        ┌─────────────────────┐
│  - Profile setup    │ ◄────────────► │   robot_sim.py       │
│  - Activity log     │  GET /data      │  (pygame + server)   │
│                     │  POST /callback │                      │
└─────────────────────┘                 └─────────────────────┘
```

### Single execution path: Native Tool Calls

Every interaction uses the same flow — there is no Command/Response
format. The AI calls tools using the provider's native structured tool
calling API, and the frontend dispatches them via HTTP.

```
1. User types "move forward" in the web UI
2. UI sends to /api/chat with systemInstructionRequest (includes tool definitions)
3. Engine converts tool definitions to the provider's native format:
   - g2 (OpenAI/GPT): requestPayload.tools[].function
   - g3 (Grok/xAI):   requestPayload.tools[].function  (OpenAI-compatible)
   - g4 (Claude):      requestPayload.tools[].input_schema
   - g1 (Gemini):      config.tools[].functionDeclarations
4. Provider responds with structured tool call (not text):
   - OpenAI/Grok: message.tool_calls[{id, function.name, function.arguments}]
   - Claude:      content[{type: "tool_use", id, name, input}]
   - Gemini:      parts[{functionCall: {name, args}}]
5. Engine normalizes to universal ToolCall format: {id, name, arguments}
6. Response JSON includes: {text: "...", toolCalls: [{id, name, arguments}]}
7. Frontend receives structured toolCalls — no regex parsing needed
8. Frontend POSTs to toolCallbackUrl: {"tool": "move_forward"}
9. ToolRunner's built-in HTTP server dispatches to the tool's execute() method
10. Tool calls robot_sim via HTTP, returns result JSON
11. Frontend sends tool result back to AI for follow-up
12. AI responds with summary or next tool call
13. Loop continues until no more tool calls (up to maxToolRounds)
```

**Text-based fallback**: If the provider doesn't return structured tool
calls (e.g. older models), the frontend falls back to regex-parsing
`Tool: name({"arg": "val"})` from the response text. This is automatic
and requires no configuration.

---

## Components

### 1. `robot_sim.py` — Simulation + HTTP Server

The simulation owns all game state and exposes it over HTTP.

**Key class: `RobotSim`**
- 20x15 grid with obstacles, items, fog of war
- Actions: `move_forward`, `move_backward`, `turn_left`, `turn_right`,
  `scan_area`, `pick_up`, `drop_item`, `report_status`, `set_speed`,
  `go_to`, `PAUSE`, `RESUME`
- State: robot position/heading, battery, inventory, score, steps

**HTTP endpoints (port 5050):**

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/data` | Full state as JSON |
| GET | `/context` | Compact state summary |
| POST | `/callback` | Execute an action (e.g. `{"action": "move_forward"}`) |
| POST | `/command` | Pause/resume game |
| POST | `/tool` | Execute a tool — called by the UI via toolCallbackUrl |

---

### 2. `run_tools_demo.py` — ToolRunner Entry Point

Sets up the agent and waits for UI interaction.

**Startup sequence:**
1. Connect to running sim (or start headless if none found)
2. Create `RobotToolsRunner` (ToolRunner subclass)
3. Start built-in tool HTTP server on a dynamic port
4. Create/update the OmniLink agent profile with:
   - 16 tool definitions (with JSON Schema `parameters`)
   - `toolCallbackUrl` pointing to the local tool server
   - `allowToolUse: true`
5. Clear memory for a fresh session
6. Wait for Ctrl+C

**No polling loop**: Unlike the old bridge architecture, the ToolRunner
doesn't poll for commands. The UI calls tools directly via HTTP.

---

### 3. `robot_tools.py` — Tool Definitions (DefaultTool subclasses)

All 16 tools are `DefaultTool` subclasses with:
- `name`: Tool identifier
- `description`: Human-readable description for the AI
- `parameters_schema`: JSON Schema for the tool's arguments (required for native tool calling)
- `execute(**kwargs)`: Implementation that calls the sim server

**Movement tools** (no parameters):
`move_forward`, `move_backward`, `turn_left`, `turn_right`

**Parameterized tools**:
- `go_to(x, y)` — Navigate to grid position
- `set_speed(speed)` — Set movement speed (1-5)
- `find_path(x, y)` — A* pathfinding to target

**Query tools** (no parameters):
`scan_area`, `pick_up`, `drop_item`, `get_status`, `get_items`,
`get_obstacles`, `check_collision`, `get_map_info`, `analyze_surroundings`

**Example tool definition:**
```python
class GoToTool(DefaultTool):
    name = "go_to"
    description = "Navigate the robot to a specific grid position."
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Target x coordinate."},
            "y": {"type": "integer", "description": "Target y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs):
        msg = send_action("go_to", x=int(kwargs["x"]), y=int(kwargs["y"]))
        state = get_state()
        return {"status": "navigating", "message": msg, ...}
```

---

### 4. `robot_api.py` — HTTP Client

Thin wrappers around the sim's HTTP API:

| Function | Endpoint | Purpose |
|----------|----------|---------|
| `get_state()` | GET `/data` | Fetch full simulation state |
| `send_action(action, **params)` | POST `/callback` | Execute action |
| `call_tool(tool_name, **kwargs)` | POST `/tool` | Execute tool on sim |

---

## Native Tool Calling Pipeline

### How tools flow through the system

```
┌─────────────────────────────────────────────────────────────────┐
│                     Tool Definition Flow                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Python (DefaultTool.to_dict())                                 │
│    {"name": "go_to", "description": "...",                      │
│     "parameters": {"type": "object", "properties": {...}}}      │
│         │                                                        │
│         ▼  Stored in agent profile on OmniLink platform          │
│                                                                  │
│  chat.ts (resolveSystemInstruction)                             │
│    Merges profile settings with frontend request                │
│    Passes availableToolDetails to engine handler                │
│         │                                                        │
│         ▼                                                        │
│                                                                  │
│  Engine handler (e.g. g3-engine.ts)                             │
│    extractToolDefinitions() → ToolDefinition[]                  │
│    Converts to provider format:                                 │
│      OpenAI: {type:"function", function:{name, description,     │
│               parameters}}                                       │
│      Claude: {name, description, input_schema}                  │
│      Gemini: {name, description, parameters}                    │
│         │                                                        │
│         ▼  Sent in API request to provider                       │
│                                                                  │
│  Provider responds with structured tool call                    │
│         │                                                        │
│         ▼                                                        │
│                                                                  │
│  Engine normalizes to universal format:                         │
│    ToolCall {id: string, name: string, arguments: Record}       │
│         │                                                        │
│         ▼  Returned in API response as toolCalls[]               │
│                                                                  │
│  Frontend (handleToolTagsFromResponseInternal)                  │
│    Prefers structured toolCalls, falls back to text parsing     │
│    POSTs {tool: name, ...args} to toolCallbackUrl               │
│         │                                                        │
│         ▼                                                        │
│                                                                  │
│  ToolRunner HTTP server (/tool)                                 │
│    Dispatches to DefaultTool.execute(**kwargs)                  │
│    Returns JSON result                                          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Shared types (`api/tool-types.ts`)

```typescript
interface ToolDefinition {
  name: string;
  description: string;
  parameters?: ToolParameterSchema;  // JSON Schema
}

interface ToolCall {
  id: string;                        // Provider-assigned or generated UUID
  name: string;
  arguments: Record<string, unknown>;
}
```

---

## Profile Configuration Reference

```python
{
    "mainTask": str,              # AI's role and behavior instructions
    "availableTools": str,        # Comma-separated tool names
    "availableToolDetails": [     # Tool definitions with JSON Schema
        {
            "name": "go_to",
            "description": "Navigate to a grid position.",
            "parameters": {
                "type": "object",
                "properties": {
                    "x": {"type": "integer", "description": "..."},
                    "y": {"type": "integer", "description": "..."},
                },
                "required": ["x", "y"],
            },
        },
        # Tools with no args still need an empty schema:
        {
            "name": "move_forward",
            "description": "Move one tile forward.",
            "parameters": {"type": "object", "properties": {}},
        },
    ],
    "allowToolUse": True,         # Enable native tool calling
    "toolCallbackUrl": str,       # URL the UI POSTs tool calls to
    "maxToolRounds": 5,           # Max tool calls per turn
}
```

---

## Replicating This Architecture

### Step 1: Define your tools as DefaultTool subclasses

```python
from omnilink.default_tools import DefaultTool

class MyTool(DefaultTool):
    name = "my_tool"
    description = "Does something useful."
    parameters_schema = {
        "type": "object",
        "properties": {
            "target": {"type": "string", "description": "The target."},
        },
        "required": ["target"],
    }

    def execute(self, **kwargs):
        target = kwargs["target"]
        # ... do work ...
        return {"status": "done", "target": target}
```

For tools with no arguments, use an empty schema:
```python
parameters_schema = {"type": "object", "properties": {}}
```

### Step 2: Create a ToolRunner subclass

```python
from omnilink.tool_runner import ToolRunner

class MyRunner(ToolRunner):
    agent_name = "my-agent"
    display_name = "My Agent"
    engine = "g3-engine"
    tool_name = "main_action"
    tool_description = "Perform the main action."
    default_tools = [MyTool(), ...]
```

### Step 3: Run

```bash
# Terminal 1: Start your simulation/target system
python -m my_package.my_sim

# Terminal 2: Start the agent
OMNI_KEY="olink_..." python -m my_package.my_runner
```

Open https://www.omnilink-agents.com/build, select your agent, and interact.

---

## File Structure

```
robot_demo/
├── __init__.py              # Module docstring
├── robot_sim.py             # Pygame simulation + HTTP server
├── robot_api.py             # HTTP client for sim server
├── robot_engine.py          # Legacy engine (commands + tools)
├── robot_tools.py           # 16 DefaultTool subclasses with JSON Schema
├── run_tools_demo.py        # ToolRunner entry point (current)
├── run_demo.py              # Legacy bridge entry point
├── robot_bridge.py          # Legacy bridge (calls AI in-process)
├── play_robot.py            # Autonomous player (no UI)
├── simulate_ui.py           # Test harness
├── test_robot.py            # Unit tests
└── ARCHITECTURE.md          # This document
```

---

## Key Design Decisions

1. **Native over text**: Tools are sent via each provider's native API
   (function calling / tool_use), not as text in the system prompt. This
   eliminates regex parsing errors and enables schema validation.

2. **Universal normalization**: All providers' tool call responses are
   normalized to a single `ToolCall` interface (`{id, name, arguments}`),
   keeping the frontend engine-agnostic.

3. **HTTP callback execution**: Tool execution is decoupled from
   invocation. The frontend POSTs to `toolCallbackUrl` regardless of
   whether the tool call came from native API or text fallback.

4. **Parameters required**: Every tool must have a `parameters_schema`
   (use `{"type": "object", "properties": {}}` for no-arg tools).
   OpenAI-compatible APIs require the `parameters` field to recognize
   function definitions.

5. **Profile as source of truth**: Tool definitions, `allowToolUse`, and
   `toolCallbackUrl` are stored in the agent profile on the platform.
   The `chat.ts` router merges profile settings with frontend requests,
   preferring profile values for tool configuration.
