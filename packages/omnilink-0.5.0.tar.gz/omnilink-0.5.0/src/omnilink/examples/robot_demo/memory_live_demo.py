#!/usr/bin/env python3
"""Live, visible, multi-session robot memory demo.

Unlike memory_demo.py (which verifies memory checks headlessly), this
script is designed to be *watched*. It runs three distinct agent
"sessions" with clear open/close boundaries and pauses in between, so
you can see the pygame sim window update in real time and confirm
that the robot picks up behavior across session boundaries purely
through long-term memory.

Prerequisite (run in a separate terminal so the sim window is visible):

    python -m omnilink.examples.robot_demo.robot_sim

The sim opens a 20x15 pygame grid on http://127.0.0.1:5050. Then, in
this terminal:

    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.memory_live_demo

What you'll see:

  SESSION 1  (agent OPEN)
    The robot explores the map, scans several regions, picks up any
    items it can reach, and saves memories about what it found and
    what it couldn't reach.
  AGENT CLOSED — pause so you can feel the session ending
  SESSION 2  (agent re-OPENED fresh)
    With no short-term history, the robot is asked to continue the
    job from where it left off. It calls list_memories to recover
    what it learned in session 1, picks the most promising next
    item, and collects it.
  AGENT CLOSED — pause
  SESSION 3  (agent re-OPENED fresh)
    The robot gives a full report of what it remembers and collected
    across all sessions, then proposes a plan for further work.

Every /api/chat call is stateless at the messages[] level — no short-
term carry-over, no conversation history across sessions. Everything
you see the robot remember comes from the long-term memory stack.
"""

from __future__ import annotations

import json
import os
import sys
import time
import uuid
from typing import Any

import requests

from .robot_api import get_state, send_action, call_tool
from .robot_engine import execute_tool as local_execute_tool

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get("OMNILINK_BASE_URL", "https://www.omnilink-agents.com")
AGENT_NAME = "robot-demo"
ENGINE = os.environ.get("MEMORY_DEMO_ENGINE", "g2-engine")
PAUSE_BETWEEN_SESSIONS = float(os.environ.get("MEMORY_LIVE_PAUSE", "6.0"))

TOOL_DETAILS = [
    {"name": "move_forward", "description": "Move one tile forward.", "parameters": {"type": "object", "properties": {}}},
    {"name": "move_backward", "description": "Move one tile backward.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_left", "description": "Rotate 90 degrees left.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_right", "description": "Rotate 90 degrees right.", "parameters": {"type": "object", "properties": {}}},
    {"name": "go_to", "description": "Navigate to a grid position using pathfinding.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "scan_area", "description": "Scan surroundings to reveal tiles and items.", "parameters": {"type": "object", "properties": {}}},
    {"name": "pick_up", "description": "Pick up an item at the current position.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_items", "description": "List visible items near the robot.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_obstacles", "description": "List visible obstacles near the robot.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_map_info", "description": "Map dimensions, obstacle count, item count.", "parameters": {"type": "object", "properties": {}}},
    {"name": "analyze_surroundings", "description": "What is in each adjacent tile (N/S/E/W).", "parameters": {"type": "object", "properties": {}}},
]

SYSTEM_INSTRUCTION = {
    "mainTask": (
        "You control a mobile robot on a 20x15 grid. Use robot tools to "
        "move, scan, and collect items. When you observe something durable "
        "about the map — item locations, obstacles, reachable or "
        "unreachable regions — use save_memory (importance 0.6-0.9) so "
        "future sessions benefit from what you learned. When starting a "
        "new session, check your memories before acting: your previous "
        "self has probably learned something useful. Be efficient and "
        "decisive."
    ),
    "agentName": AGENT_NAME,
    "allowToolUse": True,
    "availableTools": ", ".join(t["name"] for t in TOOL_DETAILS),
    "availableToolDetails": TOOL_DETAILS,
    "toolCallbackUrl": "http://127.0.0.1:5050/tool",
    "maxToolRounds": 15,
}

ACTION_TOOLS = {"move_forward", "move_backward", "turn_left", "turn_right", "scan_area", "pick_up", "drop_item"}
MEMORY_TOOLS = {"save_memory", "list_memories", "forget_memory", "list_episodes", "list_rollups"}


# ── Helpers ──────────────────────────────────────────────────────────

def _safe_print(prefix: str, text: str, limit: int = 260) -> None:
    truncated = text[:limit] + ("..." if len(text) > limit else "")
    safe = truncated.encode("ascii", "replace").decode("ascii")
    print(f"{prefix}{safe}")


def banner(title: str, char: str = "=") -> None:
    line = char * 70
    print(f"\n{line}\n  {title}\n{line}")


def wait(seconds: float, reason: str) -> None:
    print(f"\n>> {reason} (sleeping {seconds:.1f}s — watch the sim window)")
    for _ in range(int(seconds * 2)):
        time.sleep(0.5)


def wipe_memories() -> int:
    resp = requests.delete(
        f"{BASE_URL}/api/agent-memories",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {OMNI_KEY}"},
        json={"deleteAll": True, "agentName": AGENT_NAME},
        timeout=30,
    )
    return resp.json().get("deleted", 0) if resp.ok else -1


def list_memories() -> list[dict]:
    resp = requests.get(
        f"{BASE_URL}/api/agent-memories",
        headers={"Authorization": f"Bearer {OMNI_KEY}"},
        params={"agentName": AGENT_NAME, "limit": "100"},
        timeout=30,
    )
    return resp.json().get("memories", []) if resp.ok else []


# ── Robot tool execution ────────────────────────────────────────────

def execute_tool_on_sim(tool_name: str, args: dict) -> dict:
    if tool_name in ACTION_TOOLS:
        msg = send_action(tool_name)
        state = get_state()
        r = state.get("robot", {})
        return {
            "message": msg,
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
        }
    if tool_name == "go_to":
        msg = send_action("go_to", x=int(args.get("x", 0)), y=int(args.get("y", 0)))
        state = get_state()
        r = state.get("robot", {})
        return {"message": msg, "position": {"x": r.get("x"), "y": r.get("y")}, "battery": state.get("battery")}
    try:
        return call_tool(tool_name, **args)
    except Exception:
        state = get_state()
        return local_execute_tool(tool_name, state, **args)


def run_session(session_label: str, user_prompt: str, max_rounds: int = 12) -> dict:
    """Run one /api/chat session to completion. Each call is stateless:
    messages[] starts empty and grows only within this one session."""
    banner(f"SESSION — {session_label}  (agent OPEN)", "-")
    _safe_print("USER:   ", user_prompt)
    conversation: list[dict] = [{"role": "user", "content": user_prompt}]

    tools_fired: list[str] = []
    memory_events: list[dict] = []
    memory_summaries: list[dict] = []
    text_reply = ""

    for round_num in range(1, max_rounds + 1):
        body = {
            "agentName": AGENT_NAME,
            "messages": conversation[-16:],
            "engine": ENGINE,
            "temperature": 0.1,
            "requestId": str(uuid.uuid4()),
            "systemInstructionRequest": SYSTEM_INSTRUCTION,
            "skipMemory": True,
            "usePromptPipeline": True,
            "longTermMemoryEnabled": True,
            "suppressMessageSync": True,
        }
        try:
            resp = requests.post(
                f"{BASE_URL}/api/chat",
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {OMNI_KEY}"},
                json=body,
                timeout=120,
            )
            data = resp.json() if resp.content else {}
            if not resp.ok:
                print(f"  [round {round_num}] HTTP {resp.status_code}: {data.get('error')}")
                break
        except Exception as exc:
            print(f"  [round {round_num}] error: {exc}")
            break

        text = (data.get("text") or "").strip()
        tool_calls = data.get("toolCalls") or []
        mem_summary = data.get("memory")
        mem_tools = data.get("memoryTools") or []
        if mem_summary:
            memory_summaries.append(mem_summary)
        for mt in mem_tools:
            memory_events.append(mt)
            _safe_print(f"  [memory]", f" {mt.get('name')}: {mt.get('summary', '')}", limit=200)

        if text:
            _safe_print(f"  [round {round_num}] ROBOT: ", text)

        conversation.append({"role": "assistant", "content": text})
        if not tool_calls:
            text_reply = text
            break

        executed_any = False
        for tc in tool_calls:
            tool_name = tc.get("name", "")
            tool_args = tc.get("arguments") or {}
            if tool_name in MEMORY_TOOLS:
                # Already ran server-side.
                continue
            executed_any = True
            tools_fired.append(tool_name)
            try:
                result = execute_tool_on_sim(tool_name, tool_args)
            except Exception as exc:
                result = {"error": str(exc)}
            result_text = json.dumps(result, default=str)
            _safe_print("  [tool]  ", f" {tool_name}({json.dumps(tool_args)}) -> {result_text}", limit=140)
            conversation.append({
                "role": "user",
                "content": f"tool-output: {tool_name}\n{result_text}",
            })
            # Small pause so the sim has time to redraw between tool calls.
            time.sleep(0.25)
        if not executed_any:
            text_reply = text
            break

    if memory_summaries:
        last = memory_summaries[-1]
        print(f"  [recall] {last.get('recalled', 0)} recalled, {last.get('pinned', 0)} pinned this session")

    print(f"\n  [session closed — agent connection ended]")
    return {
        "text": text_reply,
        "tools": tools_fired,
        "memory_events": memory_events,
        "memory_summaries": memory_summaries,
    }


# ── Narrative ────────────────────────────────────────────────────────

def main() -> None:
    if not OMNI_KEY:
        print("Set OMNI_KEY environment variable.")
        sys.exit(1)

    # Confirm the sim is up before we start — this script deliberately
    # doesn't launch the sim headless, because the whole point is to
    # *watch* the robot move.
    try:
        state = get_state()
    except Exception as exc:
        print(f"Sim not reachable on http://127.0.0.1:5050 ({exc}).")
        print("In a separate terminal run:")
        print("  python -m omnilink.examples.robot_demo.robot_sim")
        sys.exit(1)

    robot = state.get("robot", {})
    banner("LIVE MEMORY ROBOT DEMO")
    print(f"  Engine:  {ENGINE}")
    print(f"  Agent:   {AGENT_NAME}")
    print(f"  Robot:   ({robot.get('x')},{robot.get('y')}) heading {robot.get('heading')} battery {state.get('battery')}%")
    print(f"  Items left: {state.get('items_remaining')}")
    print(f"  Pause between sessions: {PAUSE_BETWEEN_SESSIONS:.1f}s")

    if os.environ.get("MEMORY_LIVE_KEEP_STATE") != "1":
        deleted = wipe_memories()
        print(f"  Wiped {deleted} prior memories — starting fresh.")

    # ── Session 1: exploration ────────────────────────────────────
    s1 = run_session(
        "Session 1 — explore + learn the map",
        "Complete ALL of the following steps in this single session. Do "
        "NOT stop early — work through every step in order:\n"
        "STEP 1: call get_map_info.\n"
        "STEP 2: go_to(5, 5) and then scan_area there.\n"
        "STEP 3: get_items, then if any item is within 3 tiles, go_to it "
        "and pick_up.\n"
        "STEP 4: go_to(15, 10) and then scan_area there.\n"
        "STEP 5: get_items again, and if any is within 3 tiles, go_to + "
        "pick_up.\n"
        "STEP 6: go_to(10, 2) and scan_area there.\n"
        "STEP 7: call save_memory with importance 0.8 recording the "
        "three waypoints (5,5), (15,10), (10,2), which item types you "
        "saw at each, and which you managed to collect.\n"
        "STEP 8: call save_memory with importance 0.7 noting any "
        "clusters of obstacles you observed, including their coordinates.\n"
        "STEP 9: give a one-line status report — battery, score, items "
        "collected.",
        max_rounds=20,
    )

    mem_after_s1 = list_memories()
    print(f"\n  Memories written during session 1: {len(mem_after_s1)}")
    for m in mem_after_s1[:8]:
        _safe_print("    * ", f"[{m.get('memory_type')}, imp {m.get('importance'):.2f}] {m.get('content', '')}", limit=180)

    wait(PAUSE_BETWEEN_SESSIONS, "Agent CLOSED — simulating an offline period")

    # ── Session 2: continue from memory ──────────────────────────
    s2 = run_session(
        "Session 2 — continue from memory",
        "You are back online after a pause. You have no conversation "
        "history from your previous session, but your past self saved "
        "long-term memories. Execute ALL of the following:\n"
        "STEP 1: call list_memories with no query and read what you find.\n"
        "STEP 2: scan_area to see what is currently around you.\n"
        "STEP 3: get_items to see what is nearby.\n"
        "STEP 4: based on what you remember AND what you see now, pick "
        "ONE concrete target tile (explicit x,y) and go_to it.\n"
        "STEP 5: pick_up if there is an item at the destination. If the "
        "destination has no item, scan_area there and try once more.\n"
        "STEP 6: call save_memory with importance 0.7 noting what you "
        "did in this session and what changed (score, items collected).\n"
        "STEP 7: report battery, score, and items_remaining.",
        max_rounds=18,
    )

    mem_after_s2 = list_memories()
    print(f"\n  Total memories after session 2: {len(mem_after_s2)}")

    wait(PAUSE_BETWEEN_SESSIONS, "Agent CLOSED again")

    # ── Session 3: synthesis ─────────────────────────────────────
    s3 = run_session(
        "Session 3 — synthesis + plan",
        "You are back once more. Call list_memories and list_episodes "
        "to remind yourself what you have done across our prior sessions. "
        "Then: "
        "(a) Summarize what you currently know about this map (items "
        "collected, items remaining, notable obstacles). "
        "(b) Propose a concrete next-step plan: which item should future-"
        "you go for next and why. "
        "No need to move the robot this session — just reason and report.",
        max_rounds=8,
    )

    banner("DEMO COMPLETE")
    print("  Session 1 tools fired:", ", ".join(s1["tools"][:10]) + ("..." if len(s1["tools"]) > 10 else ""))
    print("  Session 2 tools fired:", ", ".join(s2["tools"][:10]) + ("..." if len(s2["tools"]) > 10 else ""))
    print("  Session 3 tools fired:", ", ".join(s3["tools"][:10]) if s3["tools"] else "(none — reasoning only, as instructed)")

    mem_final = list_memories()
    print(f"\n  Final memory count: {len(mem_final)}")
    print("\n  Key recall numbers:")
    for label, session in (("S1", s1), ("S2", s2), ("S3", s3)):
        last = session["memory_summaries"][-1] if session["memory_summaries"] else {}
        print(f"    {label}: recalled={last.get('recalled', 0)} pinned={last.get('pinned', 0)} memory-tool-calls={len(session['memory_events'])}")


if __name__ == "__main__":
    main()
