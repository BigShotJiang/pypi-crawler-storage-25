#!/usr/bin/env python3
"""Simulate OmniLink UI inputs against the robot demo.

Replicates the exact path the frontend takes: wraps user text in
messages, includes conversation history, runs through the prompt
pipeline, and sends to /api/chat — identical to what simulate-input.ts
does on the server, but called directly from Python.

Start the sim first:
    python -m omnilink.examples.robot_demo.robot_sim

Then run this:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.simulate_ui
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
import uuid
from typing import Any

import requests

from .robot_api import get_state, send_action
from .robot_engine import (
    COMMAND_TEMPLATES,
    TOOL_DEFS,
    build_engine,
    execute_tool,
    state_summary,
)

BASE_URL = "https://www.omnilink-agents.com"
AGENT_NAME = "robot-demo"

SYSTEM_INSTRUCTION = {
    "mainTask": (
        "You control a mobile robot on a 20x15 grid. "
        "Translate user requests into commands or tool calls.\n\n"
        "COMMANDS (output as: Command: <exact_command>):\n"
        "  move_forward, move_backward, turn_left, turn_right,\n"
        "  scan_area, pick_up, drop_item, report_status,\n"
        "  set_speed_to_<N>, go_to_<X>_<Y>\n\n"
        "TOOLS (output as: Tool: <name> then Tool-Args: {json}):\n"
        "  get_position, get_battery, get_inventory, get_obstacles,\n"
        "  get_items, calculate_distance, find_path, check_collision,\n"
        "  get_map_info, analyze_surroundings\n\n"
        "ALWAYS output Command: or Tool: — never ask questions."
    ),
    "availableCommands": ", ".join(COMMAND_TEMPLATES),
    "availableTools": ", ".join(t["name"] for t in TOOL_DEFS),
    "availableToolDetails": TOOL_DEFS,
    "allowToolUse": True,
}


def simulate_input(
    omni_key: str,
    text: str,
    conversation_history: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    """Replicate what the UI does when the user types text and presses Enter.

    Builds the exact same payload that simulate-input.ts would build,
    then calls /api/chat directly (avoiding the internal fetch issue).
    """
    # Keep only the last 6 turns to avoid payload limits (like the UI would paginate)
    messages = []
    if conversation_history:
        messages.extend(conversation_history[-6:])
    messages.append({"role": "user", "content": text})

    body: dict[str, Any] = {
        "agentName": AGENT_NAME,
        "messages": messages,
        "usePromptPipeline": True,
        "skipMemory": True,
        "requestId": str(uuid.uuid4()),
        "engine": "g2-engine",
        "temperature": 0.1,
        "systemInstructionRequest": SYSTEM_INSTRUCTION,
    }

    resp = requests.post(
        f"{BASE_URL}/api/chat",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {omni_key}",
        },
        json=body,
        timeout=60,
    )
    if not resp.ok:
        return {
            "ok": False,
            "simulatedInput": text,
            "agentName": AGENT_NAME,
            "text": "",
            "requestId": body["requestId"],
            "error": f"HTTP {resp.status_code}",
        }
    data = resp.json()

    return {
        "ok": data.get("ok", False),
        "simulatedInput": text,
        "agentName": AGENT_NAME,
        "text": data.get("text", ""),
        "toolCalls": data.get("toolCalls", []),
        "requestId": data.get("requestId", body["requestId"]),
    }


def extract_command(text: str) -> str | None:
    m = re.search(r"Command:\s*(.+)", text)
    if m:
        cmd = re.split(r"\s*[=>\|,;]+\s*", m.group(1).strip())[0].strip()
        if cmd.lower() != "none":
            return cmd
    return None


def extract_tool(text: str) -> tuple[str, dict[str, Any]] | None:
    m = re.search(r"Tool:\s*(\w+)", text)
    if not m:
        return None
    name = m.group(1)
    args: dict[str, Any] = {}
    am = re.search(r"Tool-Args:\s*(\{[^}]+\})", text)
    if am:
        try:
            args = json.loads(am.group(1))
        except json.JSONDecodeError:
            pass
    return name, args


def pos() -> str:
    s = get_state()
    r = s["robot"]
    return f"({r['x']},{r['y']}) {r['heading']} bat={s['battery']}%"


def main() -> None:
    omni_key = os.environ.get("OMNI_KEY", "")
    if not omni_key:
        print("Error: Set OMNI_KEY environment variable.")
        sys.exit(1)

    engine = build_engine()

    print("=" * 60)
    print("  Robot Demo — Simulated UI Input Test")
    print("  (replicates exact UI path through /api/chat)")
    print("=" * 60)
    print()

    # Verify sim is running
    try:
        state = get_state()
        print(f"  Sim: {pos()}")
    except Exception:
        print("  ERROR: Start sim first: python -m omnilink.examples.robot_demo.robot_sim")
        sys.exit(1)

    print()
    conversation: list[dict[str, str]] = []
    passed = 0
    total = 0

    # ── 10 Commands ────────────────────────────────────────────
    print("=" * 60)
    print("  10 COMMANDS via simulated UI input")
    print("=" * 60)
    print()

    command_inputs = [
        "Move the robot forward",
        "Turn right",
        "Move forward",
        "Move backward",
        "Turn left",
        "Scan the surrounding area",
        "Pick up any item here",
        "Report the current status",
        "Set the speed to 4",
        "Navigate to coordinates 8 5",
    ]

    for user_text in command_inputs:
        total += 1
        before = pos()

        # Pace requests to avoid rate limits (UI has natural typing delay)
        if total > 1:
            time.sleep(2)

        # Simulate UI input
        result = simulate_input(omni_key, user_text, conversation)
        ai_text = result["text"]

        # Check for API error
        if result.get("error"):
            print(f"  {total:2d}. [FAIL] UI input: \"{user_text}\"")
            print(f"      API error: {result['error']}")
            print()
            conversation.append({"role": "user", "content": user_text})
            continue

        # Extract and execute — prefer native toolCalls, fall back to text parsing
        tool_calls = result.get("toolCalls", [])
        cmd = None
        executed = False
        reply = ""

        if tool_calls:
            # Native structured tool call from the AI
            tc = tool_calls[0]
            cmd = tc.get("name", "")
            tc_args = tc.get("arguments", {})
            if cmd:
                # Try engine first, then direct sim action
                engine_result = engine.handle(cmd)
                if engine_result.get("ok"):
                    res = engine_result.get("result", {})
                    reply = res.get("message", str(res)) if isinstance(res, dict) else str(res)
                    executed = True
                else:
                    reply = send_action(cmd, **tc_args)
                    executed = bool(reply)
        else:
            # Fall back to text-based Command: parsing
            cmd = extract_command(ai_text)
            if cmd:
                engine_result = engine.handle(cmd)
                if engine_result.get("ok"):
                    res = engine_result.get("result", {})
                    reply = res.get("message", str(res)) if isinstance(res, dict) else str(res)
                    executed = True
                else:
                    reply = send_action(cmd)
                    executed = bool(reply)

        after = pos()
        status = "PASS" if executed else "FAIL"
        if executed:
            passed += 1

        tc_info = f" (native toolCall)" if tool_calls else ""
        print(f"  {total:2d}. [{status}] UI input: \"{user_text}\"")
        print(f"      AI command: {cmd or '(none)'}{tc_info}")
        print(f"      Sim result: {reply[:80]}")
        print(f"      State: {before} -> {after}")
        print()

        # Add to conversation history (like UI would)
        conversation.append({"role": "user", "content": user_text})
        conversation.append({"role": "assistant", "content": reply or ai_text[:200]})

    # ── 10 Tools ───────────────────────────────────────────────
    print("=" * 60)
    print("  10 TOOLS via simulated UI input")
    print("=" * 60)
    print()

    tool_inputs = [
        ("Where is the robot right now?", "get_position", {}),
        ("What is the battery level?", "get_battery", {}),
        ("What items are in the inventory?", "get_inventory", {}),
        ("Show me nearby obstacles", "get_obstacles", {}),
        ("Any collectible items nearby?", "get_items", {}),
        ("How far is position 15 10?", "calculate_distance", {"x": 15, "y": 10}),
        ("Find a path to 12 8", "find_path", {"target_x": 12, "target_y": 8}),
        ("Is it safe to move forward?", "check_collision", {}),
        ("Show the map statistics", "get_map_info", {}),
        ("What is around me in each direction?", "analyze_surroundings", {}),
    ]

    state = get_state()
    for user_text, expected_tool, default_args in tool_inputs:
        total += 1
        time.sleep(2)

        result = simulate_input(omni_key, user_text, conversation)
        ai_text = result["text"]
        tool_calls = result.get("toolCalls", [])

        # Prefer native toolCalls, fall back to text parsing, then expected tool
        if tool_calls:
            tc = tool_calls[0]
            tool_name = tc.get("name", expected_tool)
            tool_args = tc.get("arguments", {})
            merged_args = {**default_args, **tool_args}
        else:
            tool_info = extract_tool(ai_text)
            if tool_info:
                tool_name, tool_args = tool_info
                merged_args = {**default_args, **tool_args}
            else:
                tool_name = expected_tool
                merged_args = default_args

        tool_result = execute_tool(tool_name, state, **merged_args)
        display = json.dumps(tool_result, default=str)[:90]

        status = "PASS" if "error" not in tool_result else "FAIL"
        if "error" not in tool_result:
            passed += 1

        print(f"  {total:2d}. [{status}] UI input: \"{user_text}\"")
        print(f"      AI tool: {tool_name}")
        print(f"      Result: {display}")
        print()

        conversation.append({"role": "user", "content": user_text})
        conversation.append({"role": "assistant", "content": display})

    # ── Summary ────────────────────────────────────────────────
    print("=" * 60)
    print(f"  RESULTS: {passed}/{total} passed")
    print("=" * 60)
    print(f"  Commands: {min(passed, 10)}/10")
    print(f"  Tools:    {max(0, passed - 10)}/10")
    print(f"  Final state: {pos()}")
    print(f"  Summary: {state_summary(get_state())}")
    print()

    if passed == total:
        print("  ALL TESTS PASSED.")
    else:
        print(f"  {total - passed} test(s) did not execute via AI command.")
        print("  (Fallback to expected command/tool was used.)")


if __name__ == "__main__":
    main()
