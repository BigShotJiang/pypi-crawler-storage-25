#!/usr/bin/env python3
"""Test all 4 engines through /api/chat — the exact pipeline the UI uses.

Sends requests with systemInstructionRequest containing full tool definitions,
just like the browser frontend does after the fix.

Usage:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.test_all_engines
"""

import json
import os
import sys
import time
import uuid
from typing import Any

import requests

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get("OMNILINK_BASE_URL", "https://www.omnilink-agents.com")
AGENT_NAME = "robot-demo"

# Full tool definitions — exactly what the frontend sends
TOOL_DETAILS = [
    {"name": "move_forward", "description": "Move the robot one tile forward in its current heading direction.", "parameters": {"type": "object", "properties": {}}},
    {"name": "move_backward", "description": "Move the robot one tile backward (opposite of heading).", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_left", "description": "Rotate the robot 90 degrees to the left.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_right", "description": "Rotate the robot 90 degrees to the right.", "parameters": {"type": "object", "properties": {}}},
    {"name": "go_to", "description": "Navigate the robot to a specific grid position.", "parameters": {"type": "object", "properties": {"x": {"type": "integer", "description": "Target x coordinate."}, "y": {"type": "integer", "description": "Target y coordinate."}}, "required": ["x", "y"]}},
    {"name": "scan_area", "description": "Scan the area around the robot to reveal hidden tiles and items.", "parameters": {"type": "object", "properties": {}}},
    {"name": "pick_up", "description": "Pick up an item at the robot's current position.", "parameters": {"type": "object", "properties": {}}},
    {"name": "drop_item", "description": "Drop the last item in the robot's inventory.", "parameters": {"type": "object", "properties": {}}},
    {"name": "set_speed", "description": "Set the robot's movement speed (1-5).", "parameters": {"type": "object", "properties": {"speed": {"type": "integer", "description": "Movement speed (1-5)."}}, "required": ["speed"]}},
    {"name": "get_status", "description": "Get the robot's full status: position, heading, battery, inventory, score, and items remaining.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_items", "description": "Get positions of visible items near the robot (within 5 tiles).", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_obstacles", "description": "Get positions of obstacles near the robot (within 5 tiles).", "parameters": {"type": "object", "properties": {}}},
    {"name": "check_collision", "description": "Check if moving forward is safe (no wall or obstacle ahead).", "parameters": {"type": "object", "properties": {}}},
    {"name": "find_path", "description": "Find the shortest path to a position using A* pathfinding.", "parameters": {"type": "object", "properties": {"x": {"type": "integer", "description": "Target x coordinate."}, "y": {"type": "integer", "description": "Target y coordinate."}}, "required": ["x", "y"]}},
    {"name": "get_map_info", "description": "Get map dimensions, obstacle count, item count, and explored area.", "parameters": {"type": "object", "properties": {}}},
    {"name": "analyze_surroundings", "description": "Check what is in each adjacent tile (N/S/E/W) and the current tile.", "parameters": {"type": "object", "properties": {}}},
]

SYSTEM_INSTRUCTION = {
    "mainTask": (
        "You control a mobile robot on a grid world. "
        "Use the available tools to move the robot, collect items, "
        "and explore the map. Do exactly what the user asks, then "
        "report the result."
    ),
    "agentName": AGENT_NAME,
    "allowToolUse": True,
    "availableTools": ", ".join(t["name"] for t in TOOL_DETAILS),
    "availableToolDetails": TOOL_DETAILS,
    "toolCallbackUrl": "http://127.0.0.1:5050/tool",
    "maxToolRounds": 5,
}

ENGINES = ["g1-engine", "g2-engine", "g3-engine", "g4-engine"]

PROMPTS = [
    # Simple commands
    ("Move forward", ["move_forward"]),
    ("Turn left please", ["turn_left"]),
    ("Go backward", ["move_backward"]),
    # Queries
    ("What's my current status?", ["get_status"]),
    ("Are there any items near me?", ["get_items"]),
    ("What's around me in every direction?", ["analyze_surroundings"]),
    # Parameterized
    ("Set speed to 3", ["set_speed"]),
    ("Find a path to position 8, 5", ["find_path"]),
    ("Navigate to 12, 10", ["go_to"]),
    # Complex / multi-step
    ("Check if it's safe to move, then move forward", ["check_collision", "move_forward"]),
    ("Scan the area and tell me what items are nearby", ["scan_area", "get_items", "analyze_surroundings"]),
    ("Give me a full map overview with obstacles and items", ["get_map_info", "get_obstacles", "get_items"]),
    # Conversational
    ("Hey there! What can you do?", []),  # text-only expected
    ("Can you explore the bottom left corner of the map?", ["get_map_info", "go_to", "get_status", "find_path"]),
    ("Pick up whatever is on the ground here", ["pick_up", "analyze_surroundings"]),
]


def send_chat(engine: str, prompt: str, conversation: list[dict] | None = None) -> dict[str, Any]:
    """Send through /api/chat — identical to the browser UI flow."""
    messages = []
    if conversation:
        messages.extend(conversation[-6:])
    messages.append({"role": "user", "content": prompt})

    body: dict[str, Any] = {
        "agentName": AGENT_NAME,
        "messages": messages,
        "usePromptPipeline": True,
        "skipMemory": True,
        "requestId": str(uuid.uuid4()),
        "engine": engine,
        "temperature": 0.1,
        "systemInstructionRequest": SYSTEM_INSTRUCTION,
    }

    try:
        resp = requests.post(
            f"{BASE_URL}/api/chat",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {OMNI_KEY}",
            },
            json=body,
            timeout=60,
        )
        if not resp.ok:
            return {"ok": False, "error": f"HTTP {resp.status_code}", "text": "", "toolCalls": []}
        data = resp.json()
        return {
            "ok": data.get("ok", False),
            "text": data.get("text", ""),
            "toolCalls": data.get("toolCalls", []),
            "error": None,
        }
    except Exception as e:
        return {"ok": False, "error": str(e), "text": "", "toolCalls": []}


def evaluate(result: dict, expected_tools: list[str]) -> tuple[str, str]:
    """Return (status, detail)."""
    if result.get("error"):
        return "ERROR", result["error"]

    tool_calls = result.get("toolCalls", [])
    tool_names = [tc.get("name", "") for tc in tool_calls]
    text = result.get("text", "").strip()

    # Greeting / conversational — no tools expected
    if not expected_tools:
        if text and not tool_calls:
            return "PASS", "text-only (correct)"
        if text and tool_calls:
            return "PASS", f"text + tools: {tool_names}"
        return "FAIL", "no response"

    # Tools expected
    if tool_calls:
        # Check if at least one expected tool was called
        matched = [t for t in tool_names if t in expected_tools]
        if matched:
            return "PASS", f"tools: {tool_names}"
        # Tool was called but not from expected list — could be smart planning
        return "PASS*", f"tools: {tool_names} (expected one of: {expected_tools})"

    # No tools returned — check if text mentions tool use
    if text:
        # AI responded with text but no tool call
        lower = text.lower()
        if any(kw in lower for kw in ["can't", "cannot", "unable", "offline", "unavailable", "not available"]):
            return "FAIL", f"AI says unavailable: {text[:100]}"
        # Text fallback — might have Tool: in text
        if "Tool:" in text or "tool_" in text.lower():
            return "PASS*", f"text fallback: {text[:80]}"
        return "FAIL", f"text only, no tools: {text[:100]}"

    return "FAIL", "no response at all"


def main():
    if not OMNI_KEY:
        print("Set OMNI_KEY environment variable.")
        sys.exit(1)

    print("=" * 70)
    print("  Robot Demo — Full UI Pipeline Test (all 4 engines via /api/chat)")
    print("=" * 70)
    print()

    results: dict[str, list[tuple[str, str, str]]] = {}

    for engine in ENGINES:
        print(f"{'=' * 70}")
        print(f"  ENGINE: {engine}")
        print(f"{'=' * 70}")
        print()

        engine_results: list[tuple[str, str, str]] = []
        conversation: list[dict[str, str]] = []

        for i, (prompt, expected) in enumerate(PROMPTS, 1):
            time.sleep(3)  # rate limit spacing

            result = send_chat(engine, prompt, conversation)
            status, detail = evaluate(result, expected)

            tool_calls = result.get("toolCalls", [])
            tool_names = [tc.get("name", "") for tc in tool_calls]
            text_preview = result.get("text", "")[:60].replace("\n", " ").encode("ascii", "replace").decode("ascii")

            icon = {"PASS": "+", "PASS*": "~", "FAIL": "X", "ERROR": "!"}[status]
            print(f"  [{icon}] {i:2d}. {status:5s} | \"{prompt}\"")
            if tool_names:
                print(f"         tools: {tool_names}")
            if text_preview:
                print(f"         text:  {text_preview}")
            if status in ("FAIL", "ERROR"):
                print(f"         >> {detail}")
            print()

            engine_results.append((prompt, status, detail))

            # Build conversation history
            conversation.append({"role": "user", "content": prompt})
            reply = result.get("text", "") or (f"[Tool: {tool_names[0]}]" if tool_names else "")
            conversation.append({"role": "assistant", "content": reply[:200]})

        results[engine] = engine_results

    # Summary
    print()
    print("=" * 70)
    print("  SUMMARY")
    print("=" * 70)
    print()
    print(f"  {'Engine':<12} {'PASS':>6} {'PASS*':>6} {'FAIL':>6} {'ERROR':>6} {'Total':>6}")
    print(f"  {'-'*12} {'-'*6} {'-'*6} {'-'*6} {'-'*6} {'-'*6}")

    all_pass = 0
    all_total = 0
    for engine, er in results.items():
        p = sum(1 for _, s, _ in er if s == "PASS")
        ps = sum(1 for _, s, _ in er if s == "PASS*")
        f = sum(1 for _, s, _ in er if s == "FAIL")
        e = sum(1 for _, s, _ in er if s == "ERROR")
        t = len(er)
        all_pass += p + ps
        all_total += t
        print(f"  {engine:<12} {p:>6} {ps:>6} {f:>6} {e:>6} {t:>6}")

    print(f"  {'-'*12} {'-'*6} {'-'*6} {'-'*6} {'-'*6} {'-'*6}")
    print(f"  {'TOTAL':<12} {all_pass:>6} {'':>6} {all_total - all_pass:>6} {'':>6} {all_total:>6}")
    print()

    # List failures
    failures = [(eng, p, d) for eng, er in results.items() for p, s, d in er if s in ("FAIL", "ERROR")]
    if failures:
        print("  FAILURES:")
        for eng, prompt, detail in failures:
            print(f"    [{eng}] \"{prompt}\" — {detail}")
        print()
    else:
        print("  ALL TESTS PASSED!")
        print()


if __name__ == "__main__":
    main()
