#!/usr/bin/env python3
"""Robot demo where memory is lived in, not just written to.

This is the narrative cousin of test_memory.py. Instead of asserting
stack behavior with abstract prompts, this script drives the actual
robot through multi-session scenarios so you can watch long-term
memory change the robot's behavior in real time.

Each scenario runs two (or more) SESSIONS. A session is a full
/api/chat call with a fresh `messages[]` — so no short-term continuity
between sessions. Anything the robot "remembers" across sessions comes
purely from the long-term memory layer (agent_memories, pinned rows,
episodic log, Hebbian reinforcement).

Default flow:
  1. Start the sim (or reuse a running one).
  2. Wipe long-term memory for the robot-demo agent (clean slate).
  3. For each scenario, run its sessions sequentially and print the
     narrative — user prompts, the robot's replies, tool calls, and
     any memory activity surfaced in the response.
  4. Summary at the end.

Usage:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.memory_demo

Optional:
    MEMORY_DEMO_ENGINE=g4-engine    # default is g2-engine
    MEMORY_DEMO_KEEP_STATE=1        # skip the opening memory wipe
"""

from __future__ import annotations

import json
import os
import sys
import time
import uuid
from typing import Any

import requests

from .robot_api import get_state, send_action, call_tool
from .robot_engine import execute_tool as local_execute_tool

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get("OMNILINK_BASE_URL", "https://www.omnilink-agents.com")
AGENT_NAME = "robot-demo"
ENGINE = os.environ.get("MEMORY_DEMO_ENGINE", "g2-engine")

TOOL_DETAILS = [
    {"name": "move_forward", "description": "Move one tile forward.", "parameters": {"type": "object", "properties": {}}},
    {"name": "move_backward", "description": "Move one tile backward.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_left", "description": "Rotate 90 degrees left.", "parameters": {"type": "object", "properties": {}}},
    {"name": "turn_right", "description": "Rotate 90 degrees right.", "parameters": {"type": "object", "properties": {}}},
    {"name": "go_to", "description": "Navigate to a grid position using pathfinding.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}, "y": {"type": "integer"}}, "required": ["x", "y"]}},
    {"name": "scan_area", "description": "Scan surroundings to reveal tiles and items.", "parameters": {"type": "object", "properties": {}}},
    {"name": "pick_up", "description": "Pick up an item at the current position.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_items", "description": "List visible items near the robot.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_obstacles", "description": "List visible obstacles near the robot.", "parameters": {"type": "object", "properties": {}}},
    {"name": "get_map_info", "description": "Map dimensions, obstacle count, item count.", "parameters": {"type": "object", "properties": {}}},
    {"name": "analyze_surroundings", "description": "What is in each adjacent tile (N/S/E/W).", "parameters": {"type": "object", "properties": {}}},
]

SYSTEM_INSTRUCTION = {
    "mainTask": (
        "You control a mobile robot on a 20x15 grid. Use robot tools to move, "
        "scan, and collect items. When you learn something durable about the "
        "map or the user's preferences, use save_memory so you remember it in "
        "future sessions. When the user asks you to forget something, use "
        "forget_memory. When asked about past experience, rely on your "
        "recalled memories and list_memories / list_episodes rather than "
        "guessing. Be concise and act quickly."
    ),
    "agentName": AGENT_NAME,
    "allowToolUse": True,
    "availableTools": ", ".join(t["name"] for t in TOOL_DETAILS),
    "availableToolDetails": TOOL_DETAILS,
    "toolCallbackUrl": "http://127.0.0.1:5050/tool",
    "maxToolRounds": 10,
}

ACTION_TOOLS = {"move_forward", "move_backward", "turn_left", "turn_right", "scan_area", "pick_up", "drop_item"}
# Memory tools run server-side in /api/chat and should never reach the
# sim. Guard in case the backend hasn't stripped them for any reason.
MEMORY_TOOLS = {"save_memory", "list_memories", "forget_memory", "list_episodes", "list_rollups"}


# ── HTTP helpers ─────────────────────────────────────────────────────

def _api_headers() -> dict[str, str]:
    return {"Content-Type": "application/json", "Authorization": f"Bearer {OMNI_KEY}"}


def _safe_print(label: str, text: str, limit: int = 300) -> None:
    """Console-safe print (Windows cp1252-friendly)."""
    truncated = text[:limit] + ("..." if len(text) > limit else "")
    safe = truncated.encode("ascii", "replace").decode("ascii")
    print(f"{label}{safe}")


def wipe_memories() -> int:
    resp = requests.delete(
        f"{BASE_URL}/api/agent-memories",
        headers=_api_headers(),
        json={"deleteAll": True, "agentName": AGENT_NAME},
        timeout=30,
    )
    return resp.json().get("deleted", 0) if resp.ok else -1


def list_memories() -> list[dict]:
    resp = requests.get(
        f"{BASE_URL}/api/agent-memories",
        headers={"Authorization": f"Bearer {OMNI_KEY}"},
        params={"agentName": AGENT_NAME, "limit": "50"},
        timeout=30,
    )
    return resp.json().get("memories", []) if resp.ok else []


# ── Robot tool execution (same pattern as test_long_horizon.py) ──────

def execute_tool_on_sim(tool_name: str, args: dict) -> dict:
    if tool_name in ACTION_TOOLS:
        msg = send_action(tool_name)
        state = get_state()
        r = state.get("robot", {})
        return {
            "message": msg,
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
        }
    if tool_name == "go_to":
        msg = send_action("go_to", x=int(args.get("x", 0)), y=int(args.get("y", 0)))
        state = get_state()
        r = state.get("robot", {})
        return {"message": msg, "position": {"x": r.get("x"), "y": r.get("y")}, "battery": state.get("battery")}
    try:
        return call_tool(tool_name, **args)
    except Exception:
        state = get_state()
        return local_execute_tool(tool_name, state, **args)


def run_session(title: str, user_prompt: str, max_rounds: int = 8) -> dict:
    """Run one end-to-end session — fresh conversation, full tool loop.

    Returns a dict with the final reply text, the robot tool calls that
    fired, and any memory activity the backend surfaced in the responses.
    """
    print(f"\n--- {title} ---")
    _safe_print("USER:  ", user_prompt)
    conversation: list[dict] = [{"role": "user", "content": user_prompt}]

    robot_tools_fired: list[str] = []
    memory_events: list[dict] = []
    memory_summaries: list[dict] = []
    final_text = ""

    for round_num in range(1, max_rounds + 1):
        body = {
            "agentName": AGENT_NAME,
            "messages": conversation[-12:],
            "engine": ENGINE,
            "temperature": 0.1,
            "requestId": str(uuid.uuid4()),
            "systemInstructionRequest": SYSTEM_INSTRUCTION,
            "skipMemory": True,           # stateless messages
            "usePromptPipeline": True,
            "longTermMemoryEnabled": True, # but long-term memory IS on
            "suppressMessageSync": True,
        }
        try:
            resp = requests.post(f"{BASE_URL}/api/chat", headers=_api_headers(), json=body, timeout=60)
            if not resp.ok:
                print(f"  [round {round_num}] HTTP {resp.status_code}: {resp.text[:120]}")
                break
            data = resp.json()
        except Exception as exc:
            print(f"  [round {round_num}] error: {exc}")
            break

        text = (data.get("text") or "").strip()
        tool_calls = data.get("toolCalls") or []
        mem_summary = data.get("memory")
        mem_tools = data.get("memoryTools") or []
        if mem_summary:
            memory_summaries.append(mem_summary)
        if mem_tools:
            memory_events.extend(mem_tools)
            for mt in mem_tools:
                _safe_print(f"  [memory]  ", f"{mt.get('name')}: {mt.get('summary', '')}", limit=180)

        if text:
            _safe_print(f"  [round {round_num}] ROBOT: ", text)

        conversation.append({"role": "assistant", "content": text})

        if not tool_calls:
            final_text = text
            break

        for tc in tool_calls:
            tool_name = tc.get("name", "")
            tool_args = tc.get("arguments") or {}
            if tool_name in MEMORY_TOOLS:
                # Already executed server-side; nothing for the sim to do.
                continue
            robot_tools_fired.append(tool_name)
            try:
                result = execute_tool_on_sim(tool_name, tool_args)
            except Exception as exc:
                result = {"error": str(exc)}
            result_text = json.dumps(result, default=str)
            _safe_print(f"  [tool]    ", f"{tool_name}({json.dumps(tool_args)}) -> {result_text}", limit=140)
            conversation.append({
                "role": "user",
                "content": f"tool-output: {tool_name}\n{result_text}",
            })
        time.sleep(0.5)

    if memory_summaries:
        last = memory_summaries[-1]
        print(f"  [recall]  {last.get('recalled', 0)} recalled, {last.get('pinned', 0)} pinned")

    return {
        "text": final_text,
        "tools": robot_tools_fired,
        "memory_events": memory_events,
        "memory_summaries": memory_summaries,
    }


# ── Scenarios ────────────────────────────────────────────────────────

def scenario_1_map_lesson() -> list[tuple[str, bool, str]]:
    """Robot records a fact about a tile it visited, then recalls it later."""
    print("\n" + "=" * 70)
    print("  SCENARIO 1  —  Recording a map finding and recalling it")
    print("=" * 70)

    s1 = run_session(
        "Session A · robot drives somewhere and records what it found",
        "Please navigate to grid position (5, 5) and scan the area. Then use "
        "save_memory with importance 0.8 to record what you observed at that "
        "location — include the coordinates in the memory content so it is "
        "clearly about tile (5,5).",
    )
    saved = any(m.get("name") == "save_memory" for m in s1["memory_events"])
    drove = any(t in ("go_to", "move_forward") for t in s1["tools"])

    s2 = run_session(
        "Session B · fresh session asks about the same tile",
        "What do you know about grid position (5, 5)? Have you been there before?",
    )
    last_mem = s2["memory_summaries"][-1] if s2["memory_summaries"] else {"recalled": 0, "pinned": 0}
    recalled = int(last_mem.get("recalled", 0)) > 0
    acknowledged = any(k in s2["text"].lower() for k in ["5, 5", "(5,5)", "scanned", "before", "remember", "earlier"])
    return [
        ("1A drove + saved a finding", drove and saved, f"drove={drove}, saved={saved}"),
        ("1B recalled / acknowledged past visit", recalled or acknowledged,
         f"recalled={last_mem.get('recalled', 0)}, acknowledges={acknowledged}"),
    ]


def scenario_2_user_preference() -> list[tuple[str, bool, str]]:
    """Robot learns a user preference and applies it in a later run."""
    print("\n" + "=" * 70)
    print("  SCENARIO 2  —  Learning that the user prefers gems")
    print("=" * 70)

    s1 = run_session(
        "Session A · user teaches a preference",
        "Please remember this for all future runs: I strongly prefer that you "
        "collect gems before crystals, because gems are worth more points. "
        "Use save_memory with importance 0.9.",
    )
    saved = any(m.get("name") == "save_memory" for m in s1["memory_events"])

    s2 = run_session(
        "Session B · later, user asks to collect an item",
        "Scan the area first, then pick up whatever item would be most "
        "valuable given what you know about me.",
    )
    recalled = int(s2["memory_summaries"][-1].get("recalled", 0)) if s2["memory_summaries"] else 0
    mentioned_gem = "gem" in s2["text"].lower()
    return [
        ("2A preference saved", saved, f"memoryTools fired={saved}"),
        ("2B preference recalled", recalled > 0 or mentioned_gem,
         f"recalled={recalled}, mentions gem={mentioned_gem}"),
    ]


def scenario_3_memory_audit() -> list[tuple[str, bool, str]]:
    """Robot introspects via list_memories; we verify it actually surfaces prior learnings."""
    print("\n" + "=" * 70)
    print("  SCENARIO 3  —  Memory audit")
    print("=" * 70)

    s1 = run_session(
        "Session C · reflection",
        "Please call list_memories with no query. After the tool returns, "
        "write one short sentence summarizing what you have learned so far.",
    )
    list_fired = [m for m in s1["memory_events"] if m.get("name") == "list_memories"]
    # We accept the audit as passing if the list_memories summary itself
    # contains the known learnings — this is the hard guarantee. Whether
    # the model then writes follow-up prose is model-dependent and not
    # something we should assert on.
    tool_content = " ".join(m.get("summary", "") for m in list_fired).lower()
    tool_surfaced_gems = "gem" in tool_content
    tool_surfaced_coords = "5, 5" in tool_content or "(5,5)" in tool_content or "(5, 5)" in tool_content
    return [
        ("3 list_memories fired", len(list_fired) > 0, f"calls={len(list_fired)}"),
        ("3 surfaced prior learnings", tool_surfaced_gems or tool_surfaced_coords,
         f"gems={tool_surfaced_gems}, coords={tool_surfaced_coords}"),
    ]


def scenario_4_forget() -> list[tuple[str, bool, str]]:
    """User tells the robot to forget the gem preference; next run checks it's gone."""
    print("\n" + "=" * 70)
    print("  SCENARIO 4  —  Forget the gem preference")
    print("=" * 70)

    before = [m for m in list_memories() if "gem" in (m.get("content", "") or "").lower()]
    if not before:
        return [("4 preconditions", False, "gem memory not present before the test")]

    target = before[0]
    s1 = run_session(
        "Session D · user revokes the preference",
        f"I changed my mind — please use forget_memory to drop that gem "
        f"preference. The memory id is {target['id']}.",
    )
    forget_fired = any(m.get("name") == "forget_memory" for m in s1["memory_events"])

    # Live list excludes archived rows server-side, so this shows only
    # gem memories still eligible for recall.
    live = [m for m in list_memories() if "gem" in (m.get("content", "") or "").lower()]
    return [
        ("4 forget_memory fired", forget_fired, f"fired={forget_fired}"),
        ("4 memory no longer active", len(live) == 0, f"remaining gem memories={len(live)}"),
    ]


SCENARIOS = [
    scenario_1_map_lesson,
    scenario_2_user_preference,
    scenario_3_memory_audit,
    scenario_4_forget,
]


# ── Entry point ──────────────────────────────────────────────────────

def main() -> None:
    if not OMNI_KEY:
        print("Set OMNI_KEY environment variable.")
        sys.exit(1)

    print("=" * 70)
    print("  MEMORY ROBOT DEMO")
    print(f"  Engine: {ENGINE}")
    print(f"  Agent:  {AGENT_NAME}")
    print(f"  Base:   {BASE_URL}")
    print("=" * 70)

    # Verify sim is reachable
    try:
        r = get_state()
        pos = r.get("robot", {})
        print(f"  Sim OK — robot at ({pos.get('x')},{pos.get('y')}) heading {pos.get('heading')} bat {r.get('battery')}%")
    except Exception as exc:
        print(f"  Sim not reachable: {exc}")
        print("  Start it with: python -m omnilink.examples.robot_demo.run_tools_demo")
        sys.exit(1)

    if os.environ.get("MEMORY_DEMO_KEEP_STATE") != "1":
        deleted = wipe_memories()
        print(f"  Wiped {deleted} prior memories for {AGENT_NAME}.")

    results: list[tuple[str, bool, str]] = []
    for fn in SCENARIOS:
        try:
            results.extend(fn())
        except Exception as exc:
            results.append((fn.__name__, False, f"exception: {exc}"))

    print("\n" + "=" * 70)
    print("  SUMMARY")
    print("=" * 70)
    passed = sum(1 for _, ok, _ in results if ok)
    total = len(results)
    for name, ok, detail in results:
        mark = "[+]" if ok else "[-]"
        print(f"  {mark} {name} — {detail}")
    print(f"\n  {passed}/{total} checks passed")
    if passed != total:
        sys.exit(1)


if __name__ == "__main__":
    main()
