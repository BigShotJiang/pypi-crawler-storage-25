"""Robot tools — unified tool-based architecture for the grid-world robot.

Replaces the dual Command/Tool system with a single set of DefaultTool
subclasses.  Every robot action (movement, pickup, queries) is now a
tool with inline JSON arguments and structured return values.

The tools call the robot sim server at http://127.0.0.1:5050.
"""

from __future__ import annotations

import time
from typing import Any

from omnilink.default_tools import DefaultTool

from .robot_api import get_state, send_action, call_tool


# ── Movement tools ───────────────────────────────────────────────────

class MoveForwardTool(DefaultTool):
    name = "move_forward"
    description = "Move the robot one tile forward in its current heading direction."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        msg = send_action("move_forward")
        state = get_state()
        r = state.get("robot", {})
        return {
            "status": "moved",
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
            "message": msg,
        }


class MoveBackwardTool(DefaultTool):
    name = "move_backward"
    description = "Move the robot one tile backward (opposite of heading)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        msg = send_action("move_backward")
        state = get_state()
        r = state.get("robot", {})
        return {
            "status": "moved",
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
            "message": msg,
        }


class TurnLeftTool(DefaultTool):
    name = "turn_left"
    description = "Rotate the robot 90 degrees to the left."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        msg = send_action("turn_left")
        state = get_state()
        return {
            "status": "turned",
            "heading": state.get("robot", {}).get("heading"),
            "message": msg,
        }


class TurnRightTool(DefaultTool):
    name = "turn_right"
    description = "Rotate the robot 90 degrees to the right."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        msg = send_action("turn_right")
        state = get_state()
        return {
            "status": "turned",
            "heading": state.get("robot", {}).get("heading"),
            "message": msg,
        }


class GoToTool(DefaultTool):
    name = "go_to"
    description = (
        "Navigate the robot to a specific grid position using A* pathfinding. "
        "Moves the robot along the full path in one call. "
        "Args: x (required), y (required)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Target x coordinate."},
            "y": {"type": "integer", "description": "Target y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            x = self.get_arg(kwargs, "x", required=True, type_=int)
            y = self.get_arg(kwargs, "y", required=True, type_=int)
        except ValueError as exc:
            return {"error": str(exc)}
        time.sleep(1.0)
        msg = send_action("go_to", x=x, y=y)
        state = get_state()
        r = state.get("robot", {})
        return {
            "status": "navigating",
            "target": {"x": x, "y": y},
            "position": {"x": r.get("x"), "y": r.get("y")},
            "battery": state.get("battery"),
            "message": msg,
        }


# ── Action tools ─────────────────────────────────────────────────────

class ScanAreaTool(DefaultTool):
    name = "scan_area"
    description = "Scan the area around the robot to reveal hidden tiles and items."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        msg = send_action("scan_area")
        state = get_state()
        r = state.get("robot", {})
        items = state.get("items", [])
        rx, ry = r.get("x", 0), r.get("y", 0)
        nearby = [i for i in items if abs(i["x"] - rx) <= 3 and abs(i["y"] - ry) <= 3]
        return {
            "status": "scanned",
            "revealed_tiles": len(state.get("revealed", [])),
            "nearby_items": nearby,
            "message": msg,
        }


class PickUpTool(DefaultTool):
    name = "pick_up"
    description = "Pick up an item at the robot's current position."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        msg = send_action("pick_up")
        state = get_state()
        return {
            "status": "picked_up" if "Picked" in msg else "nothing_here",
            "inventory": state.get("inventory", []),
            "score": state.get("score"),
            "message": msg,
        }


class DropItemTool(DefaultTool):
    name = "drop_item"
    description = "Drop the last item in the robot's inventory at the current position."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        msg = send_action("drop_item")
        state = get_state()
        return {
            "status": "dropped",
            "inventory": state.get("inventory", []),
            "message": msg,
        }


class SetSpeedTool(DefaultTool):
    name = "set_speed"
    description = "Set the robot's movement speed. Args: speed (required, 1-5)."
    parameters_schema = {
        "type": "object",
        "properties": {
            "speed": {"type": "integer", "description": "Movement speed (1-5)."},
        },
        "required": ["speed"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            speed = self.get_arg(kwargs, "speed", required=True, type_=int)
        except ValueError as exc:
            return {"error": str(exc)}
        msg = send_action("set_speed", speed=speed)
        return {"status": "speed_set", "speed": speed, "message": msg}


# ── Query tools ──────────────────────────────────────────────────────

class GetStatusTool(DefaultTool):
    name = "get_status"
    description = (
        "Get the robot's full status: position, heading, battery, "
        "inventory, score, and items remaining."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        state = get_state()
        r = state.get("robot", {})
        return {
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
            "inventory": state.get("inventory", []),
            "score": state.get("score"),
            "steps_taken": state.get("steps_taken"),
            "items_remaining": state.get("items_remaining"),
            "game_state": state.get("game_state"),
        }


class GetItemsTool(DefaultTool):
    name = "get_items"
    description = "Get positions of visible items near the robot (within 5 tiles)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        r = state.get("robot", {})
        rx, ry = r.get("x", 0), r.get("y", 0)
        items = state.get("items", [])
        nearby = [i for i in items if abs(i["x"] - rx) <= 5 and abs(i["y"] - ry) <= 5]
        return {"items": nearby, "count": len(nearby)}


class GetObstaclesTool(DefaultTool):
    name = "get_obstacles"
    description = "Get positions of obstacles near the robot (within 5 tiles)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        r = state.get("robot", {})
        rx, ry = r.get("x", 0), r.get("y", 0)
        obstacles = state.get("obstacles", [])
        nearby = [o for o in obstacles if abs(o[0] - rx) <= 5 and abs(o[1] - ry) <= 5]
        return {"obstacles": nearby, "count": len(nearby)}


class CheckCollisionTool(DefaultTool):
    name = "check_collision"
    description = "Check if moving forward is safe (no wall or obstacle ahead)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            result = call_tool("check_collision")
            return result
        except Exception:
            state = get_state()
            from .robot_engine import check_collision
            return check_collision(state)


class FindPathTool(DefaultTool):
    name = "find_path"
    description = (
        "Find the shortest path to a position using A* pathfinding. "
        "Args: x (required), y (required)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Target x coordinate."},
            "y": {"type": "integer", "description": "Target y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            x = self.get_arg(kwargs, "x", required=True, type_=int)
            y = self.get_arg(kwargs, "y", required=True, type_=int)
        except ValueError as exc:
            return {"error": str(exc)}
        time.sleep(0.5)
        try:
            result = call_tool("find_path", target_x=x, target_y=y)
            return result
        except Exception:
            state = get_state()
            from .robot_engine import find_path
            return find_path(state, x, y)


class GetMapInfoTool(DefaultTool):
    name = "get_map_info"
    description = "Get map dimensions, obstacle count, item count, and explored area."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        return {
            "width": state.get("grid_width"),
            "height": state.get("grid_height"),
            "obstacle_count": len(state.get("obstacles", [])),
            "item_count": len(state.get("items", [])),
            "revealed_tiles": len(state.get("revealed", [])),
            "items_remaining": state.get("items_remaining"),
        }


class AnalyzeSurroundingsTool(DefaultTool):
    name = "analyze_surroundings"
    description = "Check what is in each adjacent tile (N/S/E/W) and the current tile."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            result = call_tool("analyze_surroundings")
            return result
        except Exception:
            state = get_state()
            from .robot_engine import analyze_surroundings
            return analyze_surroundings(state)


# ── Compound tools ──────────────────────────────────────────────────

class CollectItemTool(DefaultTool):
    name = "collect_item"
    description = (
        "Navigate to a position and pick up the item there in one step. "
        "Combines go_to + pick_up. Args: x (required), y (required)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Target x coordinate."},
            "y": {"type": "integer", "description": "Target y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        x = kwargs.get("x")
        y = kwargs.get("y")
        if x is None or y is None:
            return {"error": "Missing required arguments: x and y"}
        x, y = int(x), int(y)

        # Navigate
        time.sleep(1.0)
        nav_msg = send_action("go_to", x=x, y=y)
        state = get_state()
        r = state.get("robot", {})
        arrived = r.get("x") == x and r.get("y") == y

        # Pick up only if we arrived
        pickup_msg = ""
        if arrived:
            time.sleep(0.3)
            pickup_msg = send_action("pick_up")
            state = get_state()

        return {
            "status": "collected" if "Picked" in pickup_msg else (
                "arrived_nothing_here" if arrived else "navigation_failed"
            ),
            "position": {"x": r.get("x"), "y": r.get("y")},
            "battery": state.get("battery"),
            "inventory": state.get("inventory", []),
            "score": state.get("score"),
            "items_remaining": state.get("items_remaining"),
            "message": f"Navigation: {nav_msg}" + (
                f" | Pickup: {pickup_msg}" if pickup_msg else ""
            ),
        }


class ScanAndListTool(DefaultTool):
    name = "scan_and_list"
    description = (
        "Scan the area to reveal tiles, then return all visible items with positions. "
        "Combines scan_area + get_items in one call."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        send_action("scan_area")
        state = get_state()
        r = state.get("robot", {})
        rx, ry = r.get("x", 0), r.get("y", 0)
        items = state.get("items", [])
        nearby = [i for i in items if abs(i["x"] - rx) <= 5 and abs(i["y"] - ry) <= 5]

        # Sort by distance so nearest is first
        nearby.sort(key=lambda i: abs(i["x"] - rx) + abs(i["y"] - ry))

        return {
            "status": "scanned",
            "position": {"x": rx, "y": ry},
            "battery": state.get("battery"),
            "revealed_tiles": len(state.get("revealed", [])),
            "visible_items": nearby,
            "item_count": len(nearby),
            "items_remaining": state.get("items_remaining"),
        }


# ── All tools list ───────────────────────────────────────────────────

ALL_ROBOT_TOOLS = [
    # Compound (preferred)
    CollectItemTool(),
    ScanAndListTool(),
    # Actions
    MoveForwardTool(),
    MoveBackwardTool(),
    TurnLeftTool(),
    TurnRightTool(),
    GoToTool(),
    ScanAreaTool(),
    PickUpTool(),
    DropItemTool(),
    SetSpeedTool(),
    # Queries
    GetStatusTool(),
    GetItemsTool(),
    GetObstaclesTool(),
    CheckCollisionTool(),
    FindPathTool(),
    GetMapInfoTool(),
    AnalyzeSurroundingsTool(),
]
