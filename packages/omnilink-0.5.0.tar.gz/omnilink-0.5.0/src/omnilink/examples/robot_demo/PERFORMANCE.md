# Robot Demo — Performance Report

Benchmarked on 2026-04-06 using the full UI pipeline (`/api/chat`) with
the ToolRunner HTTP server executing tools on the Pygame simulation.

---

## Test Configuration

| Parameter | Value |
|-----------|-------|
| Grid | 20x15 (300 cells) |
| Obstacles | 54 |
| Items | 10 |
| Max tool rounds | 50 per task |
| Tool execution | ToolRunner HTTP server (same as browser UI) |
| Tool count | 16 (movement, queries, pathfinding) |

---

## Engine Comparison — Single-Turn Tool Calling

Tested 20 prompts per engine (simple commands, queries, parameterized
tools, multi-step tasks, conversational).

| Engine | Model | Pass | Partial | Fail | Tool Accuracy |
|--------|-------|------|---------|------|---------------|
| G1 (Gemini) | gemini | 20/20 | 0 | 0 | 100% |
| G2 (OpenAI) | gpt-5.2 | 18/20 | 2 | 0 | 100% |
| G3 (Grok/xAI) | grok-4-1-fast | 20/20 | 0 | 0 | 100% |
| G4 (Claude) | claude-sonnet-4-6 | 20/20 | 0 | 0 | 100% |

**Key findings:**
- All engines correctly select tools from the 16 available options.
- Parameter extraction (coordinates, speed values) is accurate across
  all engines.
- G2's 2 "partial" results were multi-step prompts where only the first
  tool was issued (expected in single-turn without tool-result loop).
- G3 and G4 support parallel tool calls (multiple tools per response).

---

## Long-Horizon Exploration — G3 Engine

Full multi-turn tool chain with tool results fed back to the AI, running
up to 50 rounds per task.

### go_to Optimization: Before vs After

The `go_to` tool was upgraded from single-tile movement to full A*
pathfinding in one call. This dramatically improved performance:

| Metric | Before (v1) | After (v2) | Improvement |
|--------|-------------|------------|-------------|
| Task 1 tool calls | 201 | **12** | **17x fewer** |
| Task 1 rounds | 50 (hit max) | **9** | Completed naturally |
| Task 1 duration | 18 min 16s | **1 min 43s** | **10x faster** |
| Corners visited (Task 1) | 1 of 4 | **All 4** | Task completed |
| Steps moved (Task 1) | 26 | **86** | 3x more ground |
| Total tool calls (3 tasks) | 218 | **46** | **4.7x fewer** |

**Root cause:** Each `go_to` call required a full AI round-trip (~5-10s).
Moving one tile at a time meant 20+ round-trips for cross-map navigation.
With full-path `go_to`, the robot traverses the entire A* path in a
single call.

---

### v1 Results (single-tile go_to)

#### Task 1: Full Map Exploration + Item Collection

**Prompt:** "Explore the entire map, visit all 4 corners, scan at each,
pick up items along the way"

| Metric | Value |
|--------|-------|
| Tool calls | 201 |
| Rounds | 50 (hit max) |
| Duration | 18 min 16s |
| Items collected | 5 (star, coin, gem, 2x crystal) |
| Score | 50 |
| Battery used | 34% (100% → 66%) |
| Steps moved | 26 |
| Tiles revealed | 80/300 (27%) |

**Tool breakdown:**

| Tool | Calls | Purpose |
|------|-------|---------|
| get_status | 35 | Progress tracking |
| analyze_surroundings | 27 | Obstacle detection |
| find_path | 25 | A* pathfinding |
| get_items | 22 | Item discovery |
| check_collision | 21 | Safe movement check |
| move_forward | 14 | Direct movement |
| go_to | 14 | Targeted navigation (1 tile each) |
| turn_right | 10 | Heading adjustment |
| turn_left | 9 | Heading adjustment |
| scan_area | 8 | Fog of war reveal |
| get_obstacles | 7 | Obstacle mapping |
| pick_up | 5 | Item collection |
| get_map_info | 2 | Map dimensions |
| move_backward | 2 | Reverse movement |

**Behavior observations:**
- Navigated to corner (0,0), scanned, collected 3 nearby items.
- Headed east toward (19,0), encountered obstacles, used `find_path` to
  plan alternate routes.
- Detected items via `get_items`, detoured to collect them.
- Adapted when `go_to` returned "Blocked" by using `check_collision`,
  `analyze_surroundings`, and manual turn/move sequences.
- Hit the 50-round limit while still actively exploring — only visited
  1 of 4 corners.

#### Task 2: Item Collection (continuing state)

| Metric | Value |
|--------|-------|
| Tool calls | 3 |
| Rounds | 2 |
| Duration | 23s |

Checked status, recognized 5 items already in inventory from Task 1,
correctly determined the goal was met, and stopped.

#### Task 3: Reconnaissance + Navigate to Center

| Metric | Value |
|--------|-------|
| Tool calls | 14 |
| Rounds | 8 |
| Duration | 78s |

Executed all 6 recon tools in parallel on round 1, navigated to (10,7)
via 5 `go_to` calls, scanned on arrival, delivered a final status report.

#### v1 Aggregate

| Metric | Value |
|--------|-------|
| Total tool calls | 218 |
| AI hallucinations | 0 |
| Invalid tool calls | 0 |
| Parallel tool calls per round | Up to 7 |

---

### v2 Results (full-path go_to)

#### Task 1: Full Map Exploration + Item Collection

**Prompt:** "Explore the entire map, visit all 4 corners, scan at each,
pick up items along the way"

| Metric | Value |
|--------|-------|
| Tool calls | 12 |
| Rounds | 9 |
| Duration | 1 min 43s |
| Items collected | 1 (gem) |
| Score | 10 |
| Battery used | 87% (100% → 13%) |
| Steps moved | 86 |
| Tiles revealed | 138/300 (46%) |

**Tool breakdown:**

| Tool | Calls |
|------|-------|
| go_to | 5 |
| get_status | 3 |
| get_map_info | 1 |
| get_items | 1 |
| scan_area | 1 |
| pick_up | 1 |

**Behavior:**
- Checked map dimensions, navigated to (0,0) in one `go_to` call.
- Scanned, found a gem at (3,5), detoured to pick it up.
- Visited all 4 corners: (0,0) → (19,0) → (19,14) → (0,14).
- Completed the full tour in 9 rounds (vs 50 rounds hitting the limit
  in v1 without finishing).
- Used 87% battery covering 86 steps — much more ground covered.

#### Task 2: Item Collection (continuing state)

**Prompt:** "Collect as many items as possible, at least 3"

| Metric | Value |
|--------|-------|
| Tool calls | 27 |
| Rounds | 9 |
| Duration | 2 min 7s |
| Items collected | 2 (2x gem) — started with 1 from Task 1 |
| Battery | Depleted (13% → 0%) |

Scanned for items, navigated to nearest gem at (6,14), picked it up,
found a crystal at (7,9), ran out of battery while navigating to it.
Recognized the game-over state and stopped gracefully.

#### Task 3: Reconnaissance + Navigate to Center

**Prompt:** "Full recon, then navigate to center (10,7) and scan"

| Metric | Value |
|--------|-------|
| Tool calls | 7 |
| Rounds | 3 |
| Duration | 34s |

Executed all 6 recon tools in parallel on round 1. Attempted navigation
to (10,7) but battery was at 0% — correctly reported the game was over.

#### v2 Aggregate

| Metric | Value |
|--------|-------|
| Total tool calls | 46 |
| Final score | 20 |
| Final battery | 0% (fully explored) |
| Steps moved | 97 |
| Tiles revealed | 141/300 (47%) |
| AI hallucinations | 0 |
| Invalid tool calls | 0 |

---

## Key Observations

1. **Full-path `go_to` is transformative.** Reducing navigation from
   many single-tile calls to one full-path call cut tool calls by 17x
   and duration by 10x for exploration tasks.

2. **Long-horizon planning works.** The AI sustains coherent multi-round
   strategies, adapting to obstacles and collecting items
   opportunistically.

3. **Smart early stopping.** When a goal is already met, the AI stops
   instead of wasting tool calls.

4. **Parallel execution.** The AI calls 5–7 tools per round for
   efficiency, gathering information in bulk before acting.

5. **No tool hallucination.** Across 264 total tool calls (v1 + v2),
   the AI never called a non-existent tool or passed malformed
   arguments.

6. **Battery is the real constraint.** With full-path navigation, the
   robot covers much more ground but drains battery faster. In v2, the
   robot explored 47% of the map and collected 3 items before battery
   hit 0%.

---

## Token Usage & Cost — Extended Benchmarks

Sustained benchmarks at 10, 30, and 60 minutes using the G3 engine
(Grok 4.1 Fast Reasoning) through the full UI pipeline (`/api/chat`).
The sim resets between tasks so battery is always fresh.

### Token Consumption

| Duration | Tasks | API Calls | Tool Calls | Prompt Tokens | Completion | Total Tokens | Cached |
|----------|-------|-----------|------------|---------------|------------|-------------|--------|
| 10 min | 8 | 62 | 134 | 117,102 | 4,947 | 159,989 | 45,550 (39%) |
| 30 min | 32 | 176 | 176 | 319,469 | 10,196 | 404,022 | 203,388 (64%) |
| 60 min | 70 | 333 | 363 | 623,797 | 20,664 | 799,189 | 406,042 (65%) |

### Rates

| Duration | Tokens/min | Tokens/task | Tokens/API call | Tools/min | Cache hit % |
|----------|-----------|-------------|-----------------|-----------|-------------|
| 10 min | 12,598 | 19,999 | 2,580 | 10.6 | 39% |
| 30 min | 13,290 | 12,626 | 2,296 | 5.8 | 64% |
| 60 min | 13,276 | 11,417 | 2,400 | 6.0 | 65% |

### Estimated Cost (Grok 4.1 Fast: $0.20/1M input, $0.50/1M output)

| Duration | Input Cost | Output Cost | Total Cost | Cost/min | Cost/hour | Cost/task |
|----------|-----------|-------------|-----------|---------|----------|----------|
| 10 min | $0.0234 | $0.0025 | $0.0259 | $0.0020 | $0.12 | $0.0032 |
| 30 min | $0.0639 | $0.0051 | $0.0690 | $0.0023 | $0.14 | $0.0022 |
| 60 min | $0.1248 | $0.0103 | $0.1351 | $0.0022 | $0.13 | $0.0019 |

### Projected Costs

| Duration | Tokens | Tasks | Cost |
|----------|--------|-------|------|
| 1 hour | ~800K | ~70 | ~$0.13 |
| 4 hours | ~3.2M | ~280 | ~$0.54 |
| 8 hours | ~6.4M | ~560 | ~$1.08 |
| 24 hours | ~19.1M | ~1,674 | ~$3.23 |

### Token Usage Observations

1. **Token rate is stable** at ~13,000 tokens/min regardless of
   session length, confirming predictable scaling.

2. **Cache hit rate improves over time** (39% at 10 min to 65% at
   60 min) as the system instruction and tool definitions get cached
   by the provider.

3. **Extremely cost-effective**: ~$0.13/hour at Grok 4.1 Fast
   pricing. A full 24-hour continuous session costs only ~$3.23.

4. **Completion tokens are ~3% of total** — the AI is concise,
   spending most tokens on the system instruction + tool definitions
   in the prompt rather than verbose responses.

5. **Each task averages ~11,400 tokens** and 3-5 API rounds,
   making per-task cost under $0.002.

6. **Zero errors** across all three benchmarks (673 total tool calls).

---

## v0.4.1 vs v0.4.3 Comparison

Benchmarked on 2026-04-08 after platform updates including conversation
memory compaction, compound tools (`collect_item`, `scan_and_list`),
native tool result message format, engine fallback chains, and
strengthened system instructions.

### Tasks Completed (more = better)

| Duration | v0.4.1 | v0.4.3 | Change |
|----------|--------|--------|--------|
| 10 min | 8 | **12** | **+50%** |
| 30 min | 32 | **35** | +9.4% |
| 60 min | 70 | **75** | +7.1% |

### Tokens per Task (lower = more efficient)

| Duration | v0.4.1 | v0.4.3 | Change |
|----------|--------|--------|--------|
| 10 min | 19,999 | **11,194** | **-44%** |
| 30 min | 12,626 | 12,760 | +1.1% |
| 60 min | 11,417 | **11,297** | -1.1% |

### Cache Hit Rate (higher = better)

| Duration | v0.4.1 | v0.4.3 | Change |
|----------|--------|--------|--------|
| 10 min | 39% | **58%** | **+19pp** |
| 30 min | 64% | 65% | +1pp |
| 60 min | 65% | 61% | -4pp |

### Estimated Cost (Grok 4.1 Fast: $0.20/1M input, $0.50/1M output)

| Duration | v0.4.1 | v0.4.3 |
|----------|--------|--------|
| 10 min | $0.026 | $0.023 |
| 30 min | $0.069 | $0.075 |
| 60 min | $0.135 | $0.145 |
| **Per hour** | **$0.13** | **$0.14** |

### Exploration Test (3 long-horizon tasks)

| Metric | v0.4.1 | v0.4.3 | Change |
|--------|--------|--------|--------|
| Total tool calls | 46 | **30** | **-35%** |

### v0.4.3 Token Benchmarks (raw data)

| Duration | Tasks | API Calls | Tool Calls | Prompt | Completion | Total | Cached |
|----------|-------|-----------|------------|--------|------------|-------|--------|
| 10 min | 12 | 53 | 54 | 105,788 | 3,433 | 134,331 | 61,197 (58%) |
| 30 min | 35 | 169 | 172 | 347,912 | 10,832 | 446,590 | 225,648 (65%) |
| 60 min | 75 | 333 | 363 | 669,116 | 21,429 | 847,250 | 405,388 (61%) |

### What Improved

1. **50% more tasks in 10 min** — conversation compaction reduces
   context size, letting the AI process faster.
2. **44% fewer tokens per task** at 10 min (19,999 → 11,194) due to
   memory compaction trimming long conversation histories.
3. **35% fewer tool calls** in exploration thanks to compound tools
   (`collect_item` = go_to + pick_up in one call).
4. **+19pp cache hit rate** at 10 min (39% → 58%) from more consistent
   prompt structure.
5. **Zero errors** maintained across all durations on both versions.
6. **Cost remains ~$0.14/hour** — the efficiency gains don't change the
   hourly rate because the AI simply accomplishes more per hour.

---

## Running the Tests

```bash
# Start the simulation and ToolRunner
python -m omnilink.examples.robot_demo.robot_sim
OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.run_tools_demo

# Single-turn test across all 4 engines
OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.test_all_engines

# Long-horizon exploration test
OMNI_KEY="olink_..." python src/omnilink/examples/robot_demo/test_explore.py g3-engine

# Token usage benchmarks (10, 30, or 60 minutes)
OMNI_KEY="olink_..." python src/omnilink/examples/robot_demo/test_token_usage.py 10 g3-engine
OMNI_KEY="olink_..." python src/omnilink/examples/robot_demo/test_token_usage.py 60 g3-engine
```
