#!/usr/bin/env python3
"""Long-term memory scenario suite for the robot-demo agent.

Exercises the full memory stack — pinned injection, semantic recall,
save/list/forget tools, cross-agent isolation, the skip-embedding gate,
and Hebbian reinforcement — across all four deployed engines (g1–g4).

Narrative framing: the robot-demo agent *experiences* memory. It learns
user preferences, remembers facts about the map, forgets things on
request, and survives across fresh conversation sessions.

Each scenario is self-contained: it wipes memory for the test agent,
runs its own save/read cycle, and asserts the result. Scenarios do not
leak state between each other, so an engine that fails scenario C does
not taint scenario D.

Usage:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.test_memory

Optional:
    MEMORY_TEST_ENGINES="g2-engine,g4-engine" — restrict the engine set.
"""

from __future__ import annotations

import os
import sys
import time
import uuid
from typing import Any, Callable

import requests

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get("OMNILINK_BASE_URL", "https://www.omnilink-agents.com")

# Two agent profiles: one for tests, one for cross-agent isolation checks.
# The existing "robot-demo" profile is reused as the primary test agent
# so the suite runs without any extra Supabase setup.
AGENT_NAME = "robot-demo"
OTHER_AGENT_NAME = "robot-demo-other"

ALL_ENGINES = ("g1-engine", "g2-engine", "g3-engine", "g4-engine")
engines_env = os.environ.get("MEMORY_TEST_ENGINES", "").strip()
ENGINES = tuple(e.strip() for e in engines_env.split(",") if e.strip()) if engines_env else ALL_ENGINES

# A minimal system instruction — memory tools auto-inject server-side
# when longTermMemoryEnabled=true, so we do not declare them locally.
SYSTEM_INSTRUCTION = {
    "mainTask": (
        "You control a mobile robot. When the user asks you to remember "
        "something, always use the save_memory tool. When the user asks "
        "you to forget something, use the forget_memory tool. When asked "
        "about past conversations, rely on recalled memories rather than "
        "guessing."
    ),
    "agentName": AGENT_NAME,
    "allowToolUse": True,
    "availableTools": "",
    "availableToolDetails": [],
    "maxToolRounds": 6,
}


# ── HTTP helpers ────────────────────────────────────────────────────

def _headers() -> dict[str, str]:
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {OMNI_KEY}",
    }


def call_chat(
    engine: str,
    messages: list[dict],
    *,
    agent_name: str = AGENT_NAME,
    debug: bool = False,
) -> dict:
    """POST to /api/chat with long-term memory enabled. Returns the JSON body."""
    body = {
        "agentName": agent_name,
        "messages": messages,
        "engine": engine,
        "temperature": 0.1,
        "requestId": str(uuid.uuid4()),
        "systemInstructionRequest": {**SYSTEM_INSTRUCTION, "agentName": agent_name},
        # skipMemory=True skips the short-term-memory history fetch so
        # each call is a clean "fresh session". longTermMemoryEnabled
        # is the independent flag that controls the new agent_memories
        # pipeline — we want that ON.
        "skipMemory": True,
        "usePromptPipeline": True,
        "longTermMemoryEnabled": True,
        "suppressMessageSync": True,
        "debug": debug,
    }
    resp = requests.post(
        f"{BASE_URL}/api/chat",
        headers=_headers(),
        json=body,
        timeout=60,
    )
    try:
        return resp.json()
    except ValueError:
        return {"error": f"non-json response ({resp.status_code})"}


def list_memories(agent_name: str = AGENT_NAME, **filters: Any) -> list[dict]:
    params: dict[str, str] = {"agentName": agent_name, "limit": "200"}
    for k, v in filters.items():
        if v is not None:
            params[k] = str(v)
    resp = requests.get(
        f"{BASE_URL}/api/agent-memories",
        headers={"Authorization": f"Bearer {OMNI_KEY}"},
        params=params,
        timeout=30,
    )
    data = resp.json()
    return data.get("memories", []) if resp.ok else []


def patch_memory(memory_id: str, **updates: Any) -> bool:
    resp = requests.patch(
        f"{BASE_URL}/api/agent-memories",
        headers=_headers(),
        json={"id": memory_id, **updates},
        timeout=30,
    )
    return resp.ok


def delete_all_memories(agent_name: str = AGENT_NAME) -> int:
    resp = requests.delete(
        f"{BASE_URL}/api/agent-memories",
        headers=_headers(),
        json={"deleteAll": True, "agentName": agent_name},
        timeout=30,
    )
    return resp.json().get("deleted", 0) if resp.ok else -1


# ── Scenario runner ─────────────────────────────────────────────────

def _substring_ok(haystack: str, needles: list[str]) -> bool:
    low = (haystack or "").lower()
    return any(n.lower() in low for n in needles)


def _save_memory_fired(response: dict) -> bool:
    tools = response.get("memoryTools") or []
    return any(t.get("name") == "save_memory" for t in tools)


def _forget_memory_fired(response: dict) -> bool:
    tools = response.get("memoryTools") or []
    return any(t.get("name") == "forget_memory" for t in tools)


def _recalled_count(response: dict) -> int:
    summary = response.get("memory") or {}
    return int(summary.get("recalled") or 0)


def _pinned_count(response: dict) -> int:
    summary = response.get("memory") or {}
    return int(summary.get("pinned") or 0)


def _scenario_a_save_and_recall(engine: str) -> tuple[bool, str]:
    """Teach the robot a preference in one session, recall it in another."""
    delete_all_memories(AGENT_NAME)

    save_resp = call_chat(engine, [
        {"role": "user", "content": (
            "Please remember this for future conversations: I prefer collecting gems "
            "over crystals because they are worth more points. Use your save_memory tool."
        )},
    ])
    saved = _save_memory_fired(save_resp) or len(list_memories(AGENT_NAME, search="gem")) > 0
    if not saved:
        return False, f"save_memory did not fire / no gem memory row: text={save_resp.get('text', '')[:80]!r}"

    # Simulate a new session by starting from scratch (no prior history).
    time.sleep(0.5)
    recall_resp = call_chat(engine, [
        {"role": "user", "content": "What type of item should I prioritize collecting?"},
    ])
    text = recall_resp.get("text", "")
    if not _substring_ok(text, ["gem"]):
        return False, f"reply did not reference gem preference: {text[:100]!r}"
    if _recalled_count(recall_resp) < 1:
        return False, f"memory.recalled == 0 (expected ≥ 1); text={text[:80]!r}"
    return True, f"saved + recalled (memory.recalled={_recalled_count(recall_resp)})"


def _scenario_b_pinned(engine: str) -> tuple[bool, str]:
    """Pinned memories must show up in every turn's prompt."""
    delete_all_memories(AGENT_NAME)

    # Seed a memory by asking the agent to save one, then pin it.
    call_chat(engine, [
        {"role": "user", "content": (
            "Use save_memory to remember this core strategy: always collect gems before crystals, "
            "and always scan before moving to an unexplored area."
        )},
    ])
    rows = list_memories(AGENT_NAME)
    if not rows:
        return False, "no memory row was created"
    target = rows[0]
    if not patch_memory(target["id"], pinned=True):
        return False, "PATCH pinned=true failed"

    # Unrelated question in a brand-new session; pinned should still load.
    probe = call_chat(engine, [
        {"role": "user", "content": "What is the weather outside?"},
    ], debug=True)
    pinned = _pinned_count(probe)
    if pinned < 1:
        debug = probe.get("debug", {}).get("memoryRecall")
        return False, f"memory.pinned == 0 on an unrelated turn (debug={debug})"
    return True, f"pinnedCount={pinned} on unrelated probe"


def _scenario_c_forget(engine: str) -> tuple[bool, str]:
    """Agent forgets on request; next session should not recall."""
    delete_all_memories(AGENT_NAME)

    save_resp = call_chat(engine, [
        {"role": "user", "content": (
            "Use save_memory to remember: my favorite robot name is Sparkplug."
        )},
    ])
    if not _save_memory_fired(save_resp) and not list_memories(AGENT_NAME, search="Sparkplug"):
        return False, "initial save failed"

    rows = list_memories(AGENT_NAME, search="Sparkplug")
    if not rows:
        return False, "memory not present after save"
    target_id = rows[0]["id"]

    forget_resp = call_chat(engine, [
        {"role": "user", "content": (
            f"Use forget_memory to forget memory id {target_id} — I changed my mind about that name."
        )},
    ])
    # Tolerate either path: tool fired OR row became archived.
    refreshed = [m for m in list_memories(AGENT_NAME, search="Sparkplug") if not m.get("archived")]
    tool_fired = _forget_memory_fired(forget_resp)
    if refreshed and not tool_fired:
        return False, (
            f"forget did not fire and memory still active "
            f"(tool_fired={tool_fired}, active_rows={len(refreshed)})"
        )
    return True, "memory archived / tool fired"


def _scenario_d_cross_agent_isolation(engine: str) -> tuple[bool, str]:
    """Memories saved under AGENT_NAME must not surface under OTHER_AGENT_NAME."""
    delete_all_memories(AGENT_NAME)
    delete_all_memories(OTHER_AGENT_NAME)

    # Save under the primary agent.
    call_chat(engine, [
        {"role": "user", "content": (
            "Use save_memory to remember the secret pass-phrase: lemon-quartz-42."
        )},
    ])
    if not list_memories(AGENT_NAME, search="lemon-quartz-42"):
        return False, "primary save did not land"

    # The other agent must see nothing.
    other_rows = list_memories(OTHER_AGENT_NAME, search="lemon-quartz-42")
    if other_rows:
        return False, f"leaked {len(other_rows)} memories to {OTHER_AGENT_NAME}"

    # And its recall path must not surface it either.
    probe = call_chat(engine, [
        {"role": "user", "content": "What is the secret pass-phrase?"},
    ], agent_name=OTHER_AGENT_NAME, debug=True)
    recalled = _recalled_count(probe)
    text = probe.get("text", "")
    if _substring_ok(text, ["lemon-quartz-42"]):
        return False, f"other agent text leaked the phrase: {text[:100]!r}"
    return True, f"no leak (recalled={recalled} under other agent)"


def _scenario_e_skip_embedding_gate(engine: str) -> tuple[bool, str]:
    """Short acks / greetings must not trigger recall."""
    delete_all_memories(AGENT_NAME)

    # Seed a memory so there's something to potentially recall.
    call_chat(engine, [
        {"role": "user", "content": "Use save_memory: I am from Berlin."},
    ])

    probe = call_chat(engine, [
        {"role": "user", "content": "hi"},
    ], debug=True)
    # Pinned is fine (there aren't any). We care that semantic recall was skipped.
    debug = probe.get("debug", {}).get("memoryRecall")
    recalled = _recalled_count(probe)
    if recalled > 0:
        return False, f"recall fired on 'hi' (memory.recalled={recalled}, debug={debug})"
    return True, "recall skipped on 'hi' as expected"


def _scenario_f_hebbian_reinforcement(engine: str) -> tuple[bool, str]:
    """Recalling a memory should raise its importance (Hebbian)."""
    delete_all_memories(AGENT_NAME)

    call_chat(engine, [
        {"role": "user", "content": (
            "Use save_memory with importance 0.3 to remember: I always prefer exploring "
            "the eastern edge of the map first because there's more sunlight there."
        )},
    ])
    rows = list_memories(AGENT_NAME)
    if not rows:
        return False, "initial save failed"
    before = float(rows[0].get("importance") or 0)

    # Trigger semantic recall a few times.
    for _ in range(3):
        call_chat(engine, [
            {"role": "user", "content": "Which side of the map should I explore first?"},
        ])
        time.sleep(0.3)

    rows_after = list_memories(AGENT_NAME)
    if not rows_after:
        return False, "memory vanished after recall round"
    after = float(rows_after[0].get("importance") or 0)

    # Accept either a measurable bump OR recall_count > 0 (reinforcement happened).
    rc = int(rows_after[0].get("recall_count") or 0)
    if after <= before and rc == 0:
        return False, f"importance unchanged (before={before:.3f}, after={after:.3f}, recall_count={rc})"
    return True, f"importance {before:.3f} -> {after:.3f}, recall_count={rc}"


SCENARIOS: list[tuple[str, Callable[[str], tuple[bool, str]]]] = [
    ("A. save + recall across sessions", _scenario_a_save_and_recall),
    ("B. pinned always-loaded", _scenario_b_pinned),
    ("C. forget on request", _scenario_c_forget),
    ("D. cross-agent isolation", _scenario_d_cross_agent_isolation),
    ("E. skip-embedding gate on 'hi'", _scenario_e_skip_embedding_gate),
    ("F. Hebbian reinforcement on recall", _scenario_f_hebbian_reinforcement),
]


def main() -> None:
    if not OMNI_KEY:
        print("Set OMNI_KEY environment variable.")
        sys.exit(1)

    print("=" * 70)
    print("  LONG-TERM MEMORY SCENARIO SUITE")
    print(f"  Base URL: {BASE_URL}")
    print(f"  Engines:  {', '.join(ENGINES)}")
    print(f"  Agents:   {AGENT_NAME} + {OTHER_AGENT_NAME}")
    print("=" * 70)

    totals: dict[str, dict[str, int]] = {e: {"pass": 0, "fail": 0} for e in ENGINES}
    failures: list[str] = []

    for engine in ENGINES:
        print(f"\n[{engine}]")
        for name, fn in SCENARIOS:
            t0 = time.time()
            try:
                ok, detail = fn(engine)
            except Exception as exc:
                ok, detail = False, f"exception: {exc}"
            dur = time.time() - t0
            mark = "[+]" if ok else "[-]"
            print(f"  {mark} {name}  ({dur:.1f}s)  — {detail}")
            key = "pass" if ok else "fail"
            totals[engine][key] += 1
            if not ok:
                failures.append(f"{engine} · {name} — {detail}")

    # Final cleanup.
    for agent in (AGENT_NAME, OTHER_AGENT_NAME):
        delete_all_memories(agent)

    print("\n" + "=" * 70)
    print("  SUMMARY")
    print("=" * 70)
    print(f"  {'Engine':<14} {'PASS':>6} {'FAIL':>6} {'Total':>6}")
    print(f"  {'-' * 12:<14} {'-' * 4:>6} {'-' * 4:>6} {'-' * 5:>6}")
    overall_pass = overall_fail = 0
    for engine in ENGINES:
        p, f = totals[engine]["pass"], totals[engine]["fail"]
        overall_pass += p
        overall_fail += f
        print(f"  {engine:<14} {p:>6} {f:>6} {p + f:>6}")
    print(f"  {'-' * 12:<14} {'-' * 4:>6} {'-' * 4:>6} {'-' * 5:>6}")
    print(f"  {'TOTAL':<14} {overall_pass:>6} {overall_fail:>6} {overall_pass + overall_fail:>6}")

    if failures:
        print("\n  FAILURES:")
        for f in failures:
            print(f"    - {f}")
        sys.exit(1)
    print("\n  ALL SCENARIOS PASSED")


if __name__ == "__main__":
    main()
