"""UI Control Demo — every way to control an OmniLink agent from the platform UI.

This example demonstrates the complete communication layer between the
OmniLink web UI (https://www.omnilink-agents.com) and a local Python
agent.  It covers **every** channel the platform provides:

Communication Channels
----------------------

1. **Agent Profiles** — create/update a profile so the UI knows about
   the agent, its available tools, and its commands.

2. **Short-Term Memory** — the shared state between UI and agent.
   The agent writes status updates; the UI writes user messages and
   commands (stop_game, pause_game, resume_game).

3. **Tool Callback Server** — a lightweight HTTP server the agent runs
   locally.  The platform POSTs tool calls here when the user (or AI)
   triggers a tool from the UI.  Also exposes a ``GET /activity``
   endpoint the UI polls for live activity logs.

4. **Chat API** — send a prompt to the cloud AI engine with structured
   system instructions, receive a response.  Used for kickoff, periodic
   reviews, and translating natural-language user messages into commands.

5. **Memory-Based Command Polling** — the agent periodically reads its
   own memory looking for ``Command: stop_game`` / ``pause_game`` /
   ``resume_game`` entries that the UI writes when the user clicks the
   corresponding buttons.

Architecture
------------
::

    +---------------------------+
    |   OmniLink Web UI         |  (browser)
    |   - Chat panel            |
    |   - Tool buttons          |
    |   - Stop/Pause/Resume     |
    +----------|----------------+
               | HTTPS  /api/chat, /api/short-term-memory,
               |        /api/agent-profiles
               v
    +---------------------------+
    |   OmniLink Platform       |  (cloud)
    |   - AI engines (g1-g4)    |
    |   - Profile store         |
    |   - Memory store          |
    +----------|----------------+
               | HTTP  POST /tool, GET /activity
               v
    +---------------------------+
    |   This Python Script      |  (local)
    |   - Tool callback server  |
    |   - Activity log          |
    |   - Simulated device      |
    +---------------------------+

The demo uses a **simulated smart-home controller** so no external
server is needed — you can run it standalone and interact from the UI.

Setup
-----
::

    export OMNI_KEY="omk_YOUR_KEY_HERE"
    python -m omnilink.examples.ui_control_demo

Then open https://www.omnilink-agents.com, select the **home-control**
agent, and try:

- "Turn on the living room lights"
- "What's the temperature?"
- "Set thermostat to 72"
- "Lock the front door"
- "Show device status"
- Click **Pause** / **Resume** / **Stop** in the UI
"""

from __future__ import annotations

import http.server
import json
import os
import re
import sys
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from omnilink.client import OmniLinkClient

# =====================================================================
# Configuration
# =====================================================================

AGENT_NAME = "home-control"
DISPLAY_NAME = "Smart Home Controller"
BASE_URL = "https://www.omnilink-agents.com"
ENGINE = "g3-engine"

POLL_INTERVAL = 3          # seconds — how often to check for UI commands
MEMORY_SYNC_EVERY = 15     # seconds — how often to push status to memory
REVIEW_EVERY = 120         # seconds — how often to ask the AI for a review

# =====================================================================
# 1. Simulated Smart Home (replaces an external device/server)
# =====================================================================

class SmartHome:
    """In-memory simulated smart-home state.

    In a real deployment this would be replaced by HTTP calls to actual
    IoT devices, a home-automation server, or a robot API.
    """

    def __init__(self) -> None:
        self.devices: Dict[str, Dict[str, Any]] = {
            "living_room_light": {"type": "light", "on": False, "brightness": 80},
            "bedroom_light":     {"type": "light", "on": False, "brightness": 60},
            "kitchen_light":     {"type": "light", "on": True,  "brightness": 100},
            "thermostat":        {"type": "thermostat", "temperature": 68, "target": 70, "mode": "auto"},
            "front_door_lock":   {"type": "lock", "locked": True},
            "garage_door":       {"type": "door", "open": False},
        }
        self.event_log: List[str] = []

    def get_state(self) -> Dict[str, Any]:
        return {
            "devices": dict(self.devices),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event_count": len(self.event_log),
        }

    def execute(self, command: str, **kwargs: Any) -> Dict[str, Any]:
        """Execute a command and return the result."""
        cmd = command.lower().strip()

        if cmd == "get_devices":
            return {"devices": self.devices, "count": len(self.devices)}

        if cmd == "get_temperature":
            t = self.devices["thermostat"]
            return {"current": t["temperature"], "target": t["target"], "mode": t["mode"]}

        if cmd.startswith("set_thermostat"):
            target = kwargs.get("target") or kwargs.get("temperature")
            if target is None:
                # Try to parse from command string: set_thermostat_72
                parts = cmd.split("_")
                for p in parts:
                    if p.isdigit():
                        target = int(p)
                        break
            if target is not None:
                self.devices["thermostat"]["target"] = int(target)
                self._log(f"Thermostat set to {target}")
                return {"status": "ok", "target": int(target)}
            return {"error": "No target temperature provided"}

        if cmd.startswith("turn_on_") or cmd.startswith("turnon_"):
            device = cmd.replace("turn_on_", "").replace("turnon_", "")
            return self._set_device(device, on=True)

        if cmd.startswith("turn_off_") or cmd.startswith("turnoff_"):
            device = cmd.replace("turn_off_", "").replace("turnoff_", "")
            return self._set_device(device, on=False)

        if cmd.startswith("lock_"):
            device = cmd.replace("lock_", "")
            return self._set_lock(device, locked=True)

        if cmd.startswith("unlock_"):
            device = cmd.replace("unlock_", "")
            return self._set_lock(device, locked=False)

        if cmd.startswith("open_"):
            device = cmd.replace("open_", "")
            return self._set_door(device, open_state=True)

        if cmd.startswith("close_"):
            device = cmd.replace("close_", "")
            return self._set_door(device, open_state=False)

        if cmd == "status":
            return self._status_summary()

        return {"error": f"Unknown command: {command}"}

    def _find_device(self, name: str) -> Optional[str]:
        """Fuzzy-match a device name."""
        name = name.strip().lower().replace(" ", "_")
        if name in self.devices:
            return name
        for key in self.devices:
            if name in key or key in name:
                return key
        return None

    def _set_device(self, name: str, on: bool) -> Dict[str, Any]:
        key = self._find_device(name)
        if not key:
            return {"error": f"Device not found: {name}"}
        self.devices[key]["on"] = on
        action = "on" if on else "off"
        self._log(f"{key} turned {action}")
        return {"status": "ok", "device": key, "on": on}

    def _set_lock(self, name: str, locked: bool) -> Dict[str, Any]:
        key = self._find_device(name)
        if not key:
            return {"error": f"Device not found: {name}"}
        self.devices[key]["locked"] = locked
        action = "locked" if locked else "unlocked"
        self._log(f"{key} {action}")
        return {"status": "ok", "device": key, "locked": locked}

    def _set_door(self, name: str, open_state: bool) -> Dict[str, Any]:
        key = self._find_device(name)
        if not key:
            return {"error": f"Device not found: {name}"}
        self.devices[key]["open"] = open_state
        action = "opened" if open_state else "closed"
        self._log(f"{key} {action}")
        return {"status": "ok", "device": key, "open": open_state}

    def _status_summary(self) -> Dict[str, Any]:
        lines = []
        for name, dev in self.devices.items():
            label = name.replace("_", " ").title()
            if dev["type"] == "light":
                state = f"{'ON' if dev['on'] else 'OFF'} (brightness {dev['brightness']}%)"
            elif dev["type"] == "thermostat":
                state = f"{dev['temperature']}F -> {dev['target']}F ({dev['mode']})"
            elif dev["type"] == "lock":
                state = "LOCKED" if dev["locked"] else "UNLOCKED"
            elif dev["type"] == "door":
                state = "OPEN" if dev["open"] else "CLOSED"
            else:
                state = str(dev)
            lines.append(f"  {label}: {state}")
        return {"summary": "\n".join(lines), "device_count": len(self.devices)}

    def _log(self, msg: str) -> None:
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        self.event_log.append(f"[{ts}] {msg}")


# =====================================================================
# 2. Tool Callback Server (Channel: HTTP POST /tool, GET /activity)
# =====================================================================

def start_tool_server(
    home: SmartHome,
    activity_log: List[Dict[str, Any]],
) -> int:
    """Start a local HTTP server for tool callbacks from the OmniLink UI.

    The platform sends ``POST /tool`` with ``{"tool": "<name>", ...args}``
    when the AI or user triggers a tool.  The server also exposes
    ``GET /activity`` for the UI to poll the activity feed.

    Returns the port number.
    """

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:
            pass  # suppress default access logs

        def _cors(self) -> None:
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")

        def do_OPTIONS(self) -> None:
            self.send_response(200)
            self._cors()
            self.end_headers()

        def do_GET(self) -> None:
            """GET /activity — return recent activity log entries."""
            if self.path != "/activity":
                self.send_error(404)
                return
            body = json.dumps({
                "status": "ok",
                "entries": activity_log[-100:],
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self) -> None:
            """POST /tool — execute a tool call from the UI."""
            if self.path != "/tool":
                self.send_error(404)
                return

            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length).decode("utf-8", errors="replace")
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                data = {}

            tool_name = data.pop("tool", "")
            print(f"  [TOOL] Received: {tool_name}({data})")

            # Execute the tool on our simulated home
            result = execute_tool(home, tool_name, **data)

            # Log the activity
            ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            activity_log.append({
                "action": "tool_call",
                "detail": f"{tool_name}({json.dumps(data)})",
                "kind": "info",
                "timestamp": ts,
                "data": {"tool": tool_name, "args": data, "result": result},
            })

            body = json.dumps({
                "status": "ok",
                "tool": tool_name,
                "result": result,
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            self.wfile.write(body)

    server = http.server.ThreadingHTTPServer(("0.0.0.0", 0), Handler)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return port


# =====================================================================
# 3. Query Tools — definitions and dispatch
# =====================================================================

# These tool definitions are sent to the platform so the UI and AI
# know what tools the agent supports.  Each has a JSON Schema for
# its parameters.

QUERY_TOOLS = [
    {
        "name": "get_devices",
        "description": "List all smart home devices and their current state.",
        "parameters": {"type": "object", "properties": {}},
    },
    {
        "name": "get_temperature",
        "description": "Get the current thermostat reading and target.",
        "parameters": {"type": "object", "properties": {}},
    },
    {
        "name": "set_thermostat",
        "description": "Set the target temperature for the thermostat.",
        "parameters": {
            "type": "object",
            "properties": {
                "target": {"type": "integer", "description": "Target temperature in Fahrenheit."},
            },
            "required": ["target"],
        },
    },
    {
        "name": "turn_on_device",
        "description": "Turn on a device (e.g. a light).",
        "parameters": {
            "type": "object",
            "properties": {
                "device": {"type": "string", "description": "Device name, e.g. living_room_light."},
            },
            "required": ["device"],
        },
    },
    {
        "name": "turn_off_device",
        "description": "Turn off a device (e.g. a light).",
        "parameters": {
            "type": "object",
            "properties": {
                "device": {"type": "string", "description": "Device name, e.g. living_room_light."},
            },
            "required": ["device"],
        },
    },
    {
        "name": "lock_device",
        "description": "Lock a lock (e.g. front_door_lock).",
        "parameters": {
            "type": "object",
            "properties": {
                "device": {"type": "string", "description": "Lock device name."},
            },
            "required": ["device"],
        },
    },
    {
        "name": "unlock_device",
        "description": "Unlock a lock.",
        "parameters": {
            "type": "object",
            "properties": {
                "device": {"type": "string", "description": "Lock device name."},
            },
            "required": ["device"],
        },
    },
    {
        "name": "get_status",
        "description": "Get a full summary of all devices.",
        "parameters": {"type": "object", "properties": {}},
    },
]


def execute_tool(home: SmartHome, tool_name: str, **kwargs: Any) -> Dict[str, Any]:
    """Dispatch a tool call to the simulated smart home."""
    if tool_name == "get_devices":
        return home.execute("get_devices")
    if tool_name == "get_temperature":
        return home.execute("get_temperature")
    if tool_name == "set_thermostat":
        return home.execute("set_thermostat", **kwargs)
    if tool_name == "turn_on_device":
        device = kwargs.get("device", "")
        return home.execute(f"turn_on_{device}")
    if tool_name == "turn_off_device":
        device = kwargs.get("device", "")
        return home.execute(f"turn_off_{device}")
    if tool_name == "lock_device":
        device = kwargs.get("device", "")
        return home.execute(f"lock_{device}")
    if tool_name == "unlock_device":
        device = kwargs.get("device", "")
        return home.execute(f"unlock_{device}")
    if tool_name == "get_status":
        return home.execute("status")
    return {"error": f"Unknown tool: {tool_name}"}


# =====================================================================
# 4. System Instructions — what the AI sees
# =====================================================================

def build_system_instruction(tool_callback_url: str) -> Dict[str, Any]:
    """Build the structured system instruction for the platform AI.

    This is sent with every ``client.chat()`` call and also stored in
    the agent profile so the UI can display tool buttons.
    """
    all_tool_names = ", ".join(t["name"] for t in QUERY_TOOLS)
    return {
        "mainTask": (
            f"{DISPLAY_NAME} — control smart home devices via natural language. "
            "Translate user requests into tool calls. "
            "For info queries use the appropriate get_* tool. "
            "For actions use the matching tool (turn_on_device, set_thermostat, etc.)."
        ),
        "availableTools": f"execute_action, {all_tool_names}",
        "availableToolDetails": [
            {
                "name": "execute_action",
                "description": "Execute the next smart home action.",
                "parameters": {"type": "object", "properties": {}},
            },
        ] + QUERY_TOOLS,
        "availableCommands": "stop_game, pause_game, resume_game",
        "toolCallbackUrl": tool_callback_url,
        "allowToolUse": True,
    }


# =====================================================================
# 5. Profile Management (Channel: /api/agent-profiles)
# =====================================================================

def ensure_profile(
    client: OmniLinkClient,
    system_instruction: Dict[str, Any],
) -> str:
    """Create or update the agent profile on the platform.

    The profile tells the UI:
    - What agent name to display
    - What tools are available (rendered as buttons)
    - What commands are available (stop/pause/resume)
    - Where to send tool callbacks (toolCallbackUrl)

    Returns the profile ID.
    """
    profiles = client.list_profiles()
    existing = next(
        (p for p in profiles if (p.get("name") or "").lower() == AGENT_NAME.lower()),
        None,
    )
    if existing:
        pid = existing["id"]
        client.update_profile(pid, name=AGENT_NAME, settings=system_instruction)
        print(f"  Profile updated: {AGENT_NAME} (id={pid})")
        return pid

    result = client.create_profile(AGENT_NAME, settings=system_instruction)
    pid = result.get("id", "")
    print(f"  Profile created: {AGENT_NAME} (id={pid})")
    return pid


# =====================================================================
# 6. Memory Helpers (Channel: /api/short-term-memory)
# =====================================================================

def save_status_to_memory(
    client: OmniLinkClient,
    agent_key: str,
    conversation: List[Dict[str, Any]],
    summary: str,
) -> List[Dict[str, Any]]:
    """Append a status update to the conversation and sync to platform memory.

    The UI's Memory page shows these entries in real time, so the user
    can see what the agent is doing without any explicit interaction.
    """
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    conversation.append({"role": "user", "parts": [{"text": "Report current state."}], "timestamp": ts})
    conversation.append({"role": "model", "parts": [{"text": f"Command: none\nResponse: {summary}"}], "timestamp": ts})
    try:
        client.set_memory(agent_key, conversation)
    except Exception:
        pass
    return conversation


def check_memory_commands(client: OmniLinkClient, agent_key: str) -> Optional[str]:
    """Poll memory for UI commands (stop_game, pause_game, resume_game).

    When the user clicks Stop/Pause/Resume in the web UI, the platform
    writes a ``Command: <cmd>`` entry into the agent's short-term
    memory.  This function scans for those entries.
    """
    try:
        memory = client.get_memory(agent_key)
        if not memory:
            return None
        for entry in memory:
            for part in entry.get("parts", []):
                text = part.get("text", "")
                if re.search(r"(?i)Command:\s*stop_game", text):
                    return "stop_game"
                if re.search(r"(?i)Command:\s*pause_game", text):
                    return "pause_game"
                if re.search(r"(?i)Command:\s*resume_game", text):
                    return "resume_game"
        return None
    except Exception:
        return None


def check_for_user_message(
    client: OmniLinkClient,
    agent_key: str,
    last_sig: Optional[str],
) -> tuple[Optional[str], Optional[str]]:
    """Check if a new user message appeared in memory (sent from the UI chat).

    Returns (message, new_signature) or (None, old_signature).
    """
    try:
        memory = client.get_memory(agent_key)
    except Exception:
        return None, last_sig

    if not memory:
        return None, last_sig

    sig = json.dumps(memory, sort_keys=True)
    if sig == last_sig:
        return None, last_sig

    # Find the latest user message
    for msg in reversed(memory):
        if isinstance(msg, dict) and msg.get("role") == "user":
            parts = msg.get("parts", [])
            if parts and isinstance(parts[0], dict):
                text = parts[0].get("text", "")
                # Skip internal status-check messages
                if text and not text.startswith("Report current state") and not text.startswith("["):
                    return text, sig
            break

    return None, sig


# =====================================================================
# 7. Chat / AI Integration (Channel: /api/chat)
# =====================================================================

def translate_user_message(
    client: OmniLinkClient,
    message: str,
    system_instruction: Dict[str, Any],
) -> Optional[str]:
    """Send a user message to the cloud AI and extract the command.

    The AI translates natural language like "turn on the bedroom light"
    into a structured command like "turn_on_device".
    """
    try:
        resp = client.chat(
            prompt=message,
            agent_name=AGENT_NAME,
            engine=ENGINE,
            system_instruction=system_instruction,
            temperature=0.1,
        )
        ai_text = resp.get("text", "")
        match = re.search(r"Command:\s*(.+)", ai_text)
        if match:
            cmd = match.group(1).strip()
            if cmd.lower() != "none":
                return cmd
        # Try to extract a Tool: line instead
        match = re.search(r"Tool:\s*(\S+)", ai_text)
        if match:
            return match.group(1).strip()
        return None
    except Exception as e:
        print(f"  [WARN] Chat API error: {e}")
        return None


def ask_agent_review(
    client: OmniLinkClient,
    home: SmartHome,
) -> str:
    """Ask the AI for a periodic review of the smart home state."""
    state = home.get_state()
    status = home.execute("status")
    try:
        resp = client.chat(
            prompt=f"Review the smart home state:\n{status.get('summary', '')}\n\nAny issues?",
            agent_name=AGENT_NAME,
            engine=ENGINE,
            temperature=0.3,
        )
        raw = resp.get("text", "")
        m = re.search(r"(?i)^Response:\s*(.+)", raw, re.MULTILINE | re.DOTALL)
        return m.group(1).strip() if m else raw.strip()[:200]
    except Exception as e:
        return f"(review unavailable: {e})"


# =====================================================================
# 8. Activity Logging
# =====================================================================

def log_activity(
    activity_log: List[Dict[str, Any]],
    conversation: List[Dict[str, Any]],
    client: OmniLinkClient,
    agent_key: str,
    action: str,
    detail: str,
    kind: str = "info",
    data: Optional[Dict[str, Any]] = None,
) -> None:
    """Log an activity entry and push to memory for UI visibility.

    Activities are stored in two places:
    - ``activity_log`` — served via ``GET /activity`` on the tool server
    - ``conversation`` — synced to platform memory so the UI chat shows it
    """
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    entry: Dict[str, Any] = {
        "action": action,
        "detail": detail,
        "kind": kind,
        "timestamp": ts,
    }
    if data is not None:
        entry["data"] = data
    activity_log.append(entry)

    # Also add to conversation for the UI Memory page
    conversation.append({"role": "user", "parts": [{"text": f"[{action}] {detail}"}], "timestamp": ts})
    response_text = detail
    if data:
        try:
            truncated = json.dumps(data, indent=2, default=str)
            if len(truncated) > 500:
                truncated = truncated[:500] + "\n..."
            response_text = truncated
        except (TypeError, ValueError):
            pass
    conversation.append({"role": "model", "parts": [{"text": response_text}], "timestamp": ts})

    try:
        client.set_memory(agent_key, conversation)
    except Exception:
        pass


# =====================================================================
# 9. Self-Test — validates all channels without the UI
# =====================================================================

def run_self_test(
    client: OmniLinkClient,
    home: SmartHome,
    system_instruction: Dict[str, Any],
    tool_port: int,
    agent_key: str,
) -> bool:
    """Run a self-test that exercises every communication channel.

    Returns True if all tests pass.
    """
    import requests as req

    print("  Running self-test...")
    print()
    all_ok = True

    # --- Test 1: Profile exists ---
    try:
        profiles = client.list_profiles()
        found = any(
            (p.get("name") or "").lower() == AGENT_NAME.lower() for p in profiles
        )
        status = "OK" if found else "FAIL"
        if not found:
            all_ok = False
        print(f"    [{status}] Profile '{AGENT_NAME}' exists")
    except Exception as e:
        print(f"    [FAIL] Profile check: {e}")
        all_ok = False

    # --- Test 2: Memory read/write ---
    try:
        client.set_memory(agent_key, [
            {"role": "user", "parts": [{"text": "test"}]},
            {"role": "model", "parts": [{"text": "ok"}]},
        ])
        mem = client.get_memory(agent_key)
        ok = mem is not None and len(mem) >= 2
        status = "OK" if ok else "FAIL"
        if not ok:
            all_ok = False
        print(f"    [{status}] Memory read/write ({len(mem or [])} entries)")
    except Exception as e:
        print(f"    [FAIL] Memory: {e}")
        all_ok = False

    # --- Test 3: Tool callback server ---
    try:
        r = req.post(
            f"http://127.0.0.1:{tool_port}/tool",
            json={"tool": "get_temperature"},
            timeout=5,
        )
        data = r.json()
        ok = data.get("status") == "ok" and "result" in data
        status = "OK" if ok else "FAIL"
        if not ok:
            all_ok = False
        temp = data.get("result", {}).get("current", "?")
        print(f"    [{status}] Tool callback POST /tool -> temperature={temp}F")
    except Exception as e:
        print(f"    [FAIL] Tool server: {e}")
        all_ok = False

    # --- Test 4: Activity endpoint ---
    try:
        r = req.get(f"http://127.0.0.1:{tool_port}/activity", timeout=5)
        data = r.json()
        ok = data.get("status") == "ok"
        status = "OK" if ok else "FAIL"
        if not ok:
            all_ok = False
        count = len(data.get("entries", []))
        print(f"    [{status}] Activity GET /activity -> {count} entries")
    except Exception as e:
        print(f"    [FAIL] Activity endpoint: {e}")
        all_ok = False

    # --- Test 5: Chat API ---
    try:
        resp = client.chat(
            prompt="Turn on the living room light",
            agent_name=AGENT_NAME,
            engine=ENGINE,
            system_instruction=system_instruction,
            temperature=0.0,
        )
        ai_text = resp.get("text", "")
        ok = len(ai_text) > 0
        status = "OK" if ok else "FAIL"
        if not ok:
            all_ok = False
        preview = ai_text.strip()[:80].replace("\n", " ")
        print(f"    [{status}] Chat API -> \"{preview}\"")
    except Exception as e:
        print(f"    [FAIL] Chat API: {e}")
        all_ok = False

    # --- Test 6: Command execution ---
    try:
        result = home.execute("turn_on_living_room_light")
        ok = result.get("status") == "ok" and result.get("on") is True
        status = "OK" if ok else "FAIL"
        if not ok:
            all_ok = False
        print(f"    [{status}] Command execution -> living_room_light ON")
        # Revert
        home.execute("turn_off_living_room_light")
    except Exception as e:
        print(f"    [FAIL] Command execution: {e}")
        all_ok = False

    # --- Test 7: Memory command detection ---
    try:
        client.set_memory(agent_key, [
            {"role": "model", "parts": [{"text": "Command: pause_game"}]},
        ])
        cmd = check_memory_commands(client, agent_key)
        ok = cmd == "pause_game"
        status = "OK" if ok else "FAIL"
        if not ok:
            all_ok = False
        print(f"    [{status}] Memory command polling -> detected '{cmd}'")
        # Clear
        client.set_memory(agent_key, [])
    except Exception as e:
        print(f"    [FAIL] Command polling: {e}")
        all_ok = False

    print()
    if all_ok:
        print("  All 7 tests passed!")
    else:
        print("  Some tests failed — check OMNI_KEY and network connectivity.")

    return all_ok


# =====================================================================
# 10. Main Loop — ties everything together
# =====================================================================

def main() -> None:
    omni_key = os.environ.get("OMNI_KEY", "")
    if not omni_key:
        print("Error: Set OMNI_KEY environment variable.")
        print("  export OMNI_KEY=\"omk_YOUR_KEY_HERE\"")
        sys.exit(1)

    # Initialize components
    client = OmniLinkClient(omni_key=omni_key, base_url=BASE_URL, timeout=60)
    home = SmartHome()
    activity_log: List[Dict[str, Any]] = []
    conversation: List[Dict[str, Any]] = []

    print()
    print("=" * 60)
    print(f"  OmniLink UI Control Demo — {DISPLAY_NAME}")
    print("=" * 60)
    print()

    # --- Channel 1: Start tool callback server ---
    tool_port = start_tool_server(home, activity_log)
    tool_callback_url = f"http://127.0.0.1:{tool_port}/tool"
    print(f"  Tool callback server: http://127.0.0.1:{tool_port}")
    print(f"    POST /tool     — tool execution endpoint")
    print(f"    GET  /activity — activity log endpoint")
    print()

    # --- Channel 2: Build system instructions ---
    system_instruction = build_system_instruction(tool_callback_url)

    # --- Channel 3: Create/update agent profile ---
    profile_id = ensure_profile(client, system_instruction)
    agent_key = profile_id or AGENT_NAME
    print()

    # --- Channel 4: Clear stale memory ---
    try:
        client.set_memory(agent_key, [])
        print("  Memory cleared (fresh session).")
    except Exception:
        pass

    # --- Channel 5: Initial kickoff via Chat API ---
    print("  Requesting initial tool call from AI...")
    try:
        result = client.chat(
            "Call execute_action to start monitoring the smart home.",
            agent_name=AGENT_NAME,
            engine=ENGINE,
            system_instruction=system_instruction,
            temperature=0.0,
        )
        raw = result.get("text", "").encode("ascii", errors="ignore").decode("ascii")
        preview = raw.strip()[:100].replace("\n", " ")
        print(f"  AI response: {preview}")
    except Exception as e:
        print(f"  AI kickoff failed (continuing): {e}")
    print()

    # --- Self-test ---
    run_self_test(client, home, system_instruction, tool_port, agent_key)
    print()

    # --- Clear memory again after tests ---
    conversation.clear()
    try:
        client.set_memory(agent_key, [])
    except Exception:
        pass

    # --- Inform user ---
    print("-" * 60)
    print(f"  Agent is live at: {BASE_URL}")
    print(f"  Select '{AGENT_NAME}' in the UI and start chatting.")
    print()
    print("  Try commands like:")
    print("    - 'Turn on the bedroom light'")
    print("    - 'What's the temperature?'")
    print("    - 'Set thermostat to 72'")
    print("    - 'Lock the front door'")
    print("    - 'Show device status'")
    print("    - Click Pause / Resume / Stop in the UI")
    print("-" * 60)
    print()
    print("  Entering main loop (Ctrl+C to stop)...")
    print()

    # --- Main loop ---
    last_memory_time = time.time()
    last_review_time = time.time()
    last_msg_sig: Optional[str] = None
    paused = False
    tick = 0

    try:
        while True:
            time.sleep(POLL_INTERVAL)
            tick += 1

            now = time.time()

            # --- Check for UI commands (stop/pause/resume) ---
            cmd = check_memory_commands(client, agent_key)
            if cmd == "stop_game":
                print("  >> Stop requested from UI.")
                log_activity(activity_log, conversation, client, agent_key,
                             "command", "Stop requested from UI", kind="warn")
                break
            elif cmd == "pause_game" and not paused:
                paused = True
                print("  >> Paused from UI.")
                log_activity(activity_log, conversation, client, agent_key,
                             "command", "Paused from UI", kind="warn")
            elif cmd == "resume_game" and paused:
                paused = False
                print("  >> Resumed from UI.")
                log_activity(activity_log, conversation, client, agent_key,
                             "command", "Resumed from UI", kind="success")

            # --- Check for new user messages from the UI chat ---
            user_msg, last_msg_sig = check_for_user_message(client, agent_key, last_msg_sig)
            if user_msg:
                print(f"  >> User: \"{user_msg}\"")

                # Translate via AI
                ai_cmd = translate_user_message(client, user_msg, system_instruction)
                if ai_cmd:
                    print(f"     AI command: {ai_cmd}")
                    # Execute the appropriate tool
                    result = execute_tool(home, ai_cmd)
                    if result.get("error") and ai_cmd.startswith(("turn_on", "turn_off", "lock", "unlock")):
                        # The AI may return a compound command; try direct execution
                        result = home.execute(ai_cmd)
                    reply = json.dumps(result, default=str)
                    print(f"     Result: {reply[:120]}")
                else:
                    reply = "I couldn't understand that command. Try 'turn on the light' or 'set thermostat to 72'."
                    print(f"     No command extracted from AI response.")

                # Write the reply back to memory so the UI shows it
                ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                conversation.append({"role": "user", "parts": [{"text": user_msg}], "timestamp": ts})
                conversation.append({"role": "model", "parts": [{"text": reply}], "timestamp": ts})
                try:
                    client.set_memory(agent_key, conversation)
                except Exception:
                    pass

                log_activity(activity_log, conversation, client, agent_key,
                             "user_message", f"User: {user_msg} -> {ai_cmd}",
                             data={"command": ai_cmd, "result": result if ai_cmd else None})
                # Update signature after writing
                last_msg_sig = json.dumps(conversation, sort_keys=True)
                print()

            # --- Periodic status sync to memory ---
            if not paused and now - last_memory_time >= MEMORY_SYNC_EVERY:
                status = home.execute("status")
                summary = status.get("summary", "No status available")
                conversation = save_status_to_memory(client, agent_key, conversation, summary)
                last_memory_time = now

            # --- Periodic AI review ---
            if not paused and now - last_review_time >= REVIEW_EVERY:
                print("  >> AI reviewing smart home...")
                review = ask_agent_review(client, home)
                review_clean = review.encode("ascii", errors="ignore").decode("ascii")
                print(f"  << AI: {review_clean[:200]}")
                print()
                log_activity(activity_log, conversation, client, agent_key,
                             "ai_review", review_clean[:200])
                last_review_time = now

            # --- Heartbeat ---
            if tick % 20 == 0:
                status = home.execute("status")
                print(f"  [heartbeat] {len(activity_log)} activities, {len(conversation)} memory entries")

    except KeyboardInterrupt:
        print("\n  Interrupted by user.")

    # --- Final summary ---
    print()
    print("=" * 60)
    status = home.execute("status")
    print(f"  Final state:\n{status.get('summary', '(unavailable)')}")
    print(f"  Events: {len(home.event_log)}")
    print(f"  Activities logged: {len(activity_log)}")
    print("=" * 60)

    # Save final state to memory
    try:
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        conversation.append({"role": "user", "parts": [{"text": "Session ended."}], "timestamp": ts})
        conversation.append({"role": "model", "parts": [{"text": f"Command: stop_game\nResponse: {status.get('summary', '')}"}], "timestamp": ts})
        client.set_memory(agent_key, conversation)
        print("  Session saved to OmniLink memory.")
    except Exception:
        pass

    print()
    print("  Done.")


if __name__ == "__main__":
    main()
