"""Run the Axis / OmniSim UR5e agent.

Before launching this runner, open the Webots world in OmniSim that uses
the ``ur5e_omnilink_bridge`` controller. The bridge listens on
127.0.0.1:6060. Then::

    export OMNI_KEY=olink_...
    python -m omnilink.examples.omnisim_ur5e.play_omnisim

The runner:

* Polls the bridge every ``poll_interval`` seconds for fresh telemetry.
* Acts as a local safety watchdog: if telemetry is stale or the bridge
  reports a fault, it immediately POSTs ``stop`` to the bridge. This is
  the Python-lib analogue of Haven's "safety_watchdog" standing order —
  the OmniLink platform has no standing-orders primitive in the lib, so
  we fold it into the ToolRunner main loop.
* Streams state summaries into the OmniLink platform's conversation
  memory every ``memory_every`` seconds so the LLM always has fresh
  pose context.
* Exposes 9 DefaultTools (read/write joints, TCP target, IK validation,
  stop, reset). The browser UI POSTs tool calls directly to the local
  HTTPS callback server that ``ToolRunner`` starts on a random port.
"""

from __future__ import annotations

import time
from typing import Any

from omnilink.tool_runner import ToolRunner

from .omnisim_api import get_state, send_action
from .omnisim_tools import ALL_OMNISIM_TOOLS

TELEMETRY_TIMEOUT_S = 2.0

MAIN_TASK = (
    "You are Axis, OmniLink's robot-control agent. You command a UR5e "
    "arm running in OmniSim through a bridge at 127.0.0.1:6060.\n\n"
    "Rules:\n"
    "1. Before any set_tcp_target or set_joint_positions, read the "
    "current state with get_robot_state or read_joints.\n"
    "2. Prefer small, incremental motions. Large target jumps will "
    "fail IK convergence (err_norm > 0.05).\n"
    "3. If set_tcp_target returns an error with err_norm, do NOT retry "
    "with the same target. Propose a smaller delta (e.g. halve it) and "
    "confirm with the operator before executing.\n"
    "4. Never bypass stop_robot. If any tool returns a non-null 'fault' "
    "field, call stop_robot immediately and report the fault.\n"
    "5. Never claim a target was reached without reading telemetry that "
    "confirms the realized TCP is within tolerance of the commanded TCP.\n"
    "6. On ambiguous operator input ('move left a bit'), propose a "
    "concrete delta in meters or radians and wait for confirmation."
)


class OmniSimRunner(ToolRunner):
    agent_name = "axis-ur5e"
    display_name = "Axis UR5e"
    tool_name = "control_ur5e"
    tool_description = "Control the UR5e robot arm running in OmniSim."
    engine = "g4-engine"  # Claude
    poll_interval = 0.1   # 10 Hz watchdog
    memory_every = 15
    ask_every = 600
    # Pin the tool-callback port so restarts don't invalidate open browser
    # tabs. 6061 is the natural neighbour to the bridge's 6060.
    tool_callback_port = 6061
    # No legacy text commands — stop_robot and reset_to_home are exposed
    # as native tools (see ALL_OMNISIM_TOOLS) so the AI calls them via
    # function-calling rather than text.
    commands = ""
    default_tools = ALL_OMNISIM_TOOLS

    _last_fault: str | None = None
    _stopped_for_stale = False

    def get_profile_settings(self) -> dict[str, Any]:
        settings = super().get_profile_settings()
        settings["mainTask"] = MAIN_TASK
        settings["temperature"] = 0.1
        return settings

    def get_state(self) -> dict[str, Any]:
        try:
            s = get_state()
            s["_fetched_at"] = time.time()
            return s
        except Exception as exc:
            return {"error": str(exc), "stale": True, "_fetched_at": time.time()}

    def execute_action(self, state: dict[str, Any]) -> None:
        """Safety watchdog — local, no LLM calls."""
        now = time.time()

        if state.get("stale") or "error" in state:
            if not self._stopped_for_stale:
                self._try_stop("telemetry unreachable")
                self._stopped_for_stale = True
            return

        self._stopped_for_stale = False

        last_tick = state.get("last_tick_at") or 0.0
        if last_tick and (now - last_tick) > TELEMETRY_TIMEOUT_S:
            self._try_stop(f"telemetry stale ({now - last_tick:.2f}s)")
            return

        fault = state.get("fault")
        if fault and fault != self._last_fault:
            self._try_stop(f"bridge fault: {fault}")
        self._last_fault = fault

    def _try_stop(self, reason: str) -> None:
        print(f"[axis] STOP — {reason}")
        try:
            send_action("stop")
        except Exception as exc:
            print(f"[axis] stop failed: {exc}")

    def state_summary(self, state: dict[str, Any]) -> str:
        if state.get("stale") or "error" in state:
            return f"TELEMETRY UNREACHABLE: {state.get('error', 'unknown')}"
        q = state.get("q") or []
        tcp = state.get("tcp") or []
        q_str = ", ".join(f"{v:+.2f}" for v in q)
        tcp_str = ", ".join(f"{v:+.3f}" for v in tcp) if tcp else "?"
        fault = state.get("fault")
        fault_str = f" fault={fault}" if fault else ""
        return (
            f"UR5e mode={state.get('mode')} sim_t={state.get('sim_time', 0.0):.1f}s "
            f"q=[{q_str}] tcp=[{tcp_str}]{fault_str}"
        )

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return False  # robot control is open-ended


def main() -> None:
    OmniSimRunner().run()


if __name__ == "__main__":
    main()
