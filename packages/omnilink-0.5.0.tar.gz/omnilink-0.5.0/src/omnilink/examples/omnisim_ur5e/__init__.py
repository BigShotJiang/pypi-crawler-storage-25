"""OmniLink agent that drives a UR5e in OmniSim through the
``ur5e_omnilink_bridge`` Webots controller.

Quick start::

    python -m omnilink.examples.omnisim_ur5e.mock_bridge   # or real bridge
    OMNI_KEY="olink_..." python -m omnilink.examples.omnisim_ur5e.play_omnisim
"""

from .omnisim_tools import (
    ALL_OMNISIM_TOOLS,
    GetCapabilitiesTool,
    GetRobotStateTool,
    ReadJointsTool,
    ReadTcpPoseTool,
    ResetToHomeTool,
    SetJointPositionsTool,
    SetTcpTargetTool,
    SolveIkTool,
    StopRobotTool,
)
from .play_omnisim import OmniSimRunner

__all__ = [
    "OmniSimRunner",
    "ALL_OMNISIM_TOOLS",
    "GetRobotStateTool",
    "ReadJointsTool",
    "ReadTcpPoseTool",
    "GetCapabilitiesTool",
    "SetJointPositionsTool",
    "SetTcpTargetTool",
    "SolveIkTool",
    "StopRobotTool",
    "ResetToHomeTool",
]
