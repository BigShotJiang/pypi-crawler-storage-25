"""DefaultTool definitions for the OmniSim UR5e agent.

Every tool is a thin wrapper around ``omnisim_api`` that translates
OmniLink's tool-call protocol into a single HTTP request to the bridge.
Tools must return JSON-serialisable dicts and should never raise.
"""

from __future__ import annotations

from typing import Any

from omnilink.default_tools import DefaultTool

from .omnisim_api import get_capabilities, get_state, send_action


def _safe_state() -> dict[str, Any]:
    try:
        return get_state()
    except Exception as exc:  # network / bridge down
        return {"error": f"bridge unreachable: {exc}"}


class GetRobotStateTool(DefaultTool):
    name = "get_robot_state"
    description = (
        "Full UR5e snapshot: joint angles q (6 radians), TCP world position "
        "(meters), control mode, target, fault flag, and simulation time."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        return _safe_state()


class ReadJointsTool(DefaultTool):
    name = "read_joints"
    description = "Read the UR5e's 6 joint angles in radians."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        s = _safe_state()
        if "error" in s:
            return s
        return {"q": s.get("q"), "mode": s.get("mode"), "fault": s.get("fault")}


class ReadTcpPoseTool(DefaultTool):
    name = "read_tcp_pose"
    description = "Read the UR5e tool-center-point position (x, y, z) in meters."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        s = _safe_state()
        if "error" in s:
            return s
        return {"tcp": s.get("tcp"), "fault": s.get("fault")}


class GetCapabilitiesTool(DefaultTool):
    name = "get_capabilities"
    description = (
        "Return the UR5e capability record: joint names, joint limits, "
        "home pose, TCP offset, and IK constants (tol, damping, max step)."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            return get_capabilities()
        except Exception as exc:
            return {"error": f"bridge unreachable: {exc}"}


class SetJointPositionsTool(DefaultTool):
    name = "set_joint_positions"
    description = (
        "Command the UR5e to a target joint configuration. Values are clamped "
        "to joint limits on the bridge. The robot ramps toward the target at "
        "IK_MAX_DQ rad per tick, so prefer small deltas from the current pose. "
        "Always read_joints first."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "q": {
                "type": "array",
                "items": {"type": "number"},
                "minItems": 6,
                "maxItems": 6,
                "description": "Six joint angles in radians, ordered: "
                               "shoulder_pan, shoulder_lift, elbow, "
                               "wrist_1, wrist_2, wrist_3.",
            }
        },
        "required": ["q"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            q = self.get_arg(kwargs, "q", required=True)
        except ValueError as exc:
            return {"error": str(exc)}
        if not isinstance(q, (list, tuple)) or len(q) != 6:
            return {"error": f"{self.name}: 'q' must be a list of exactly 6 numbers, got {type(q).__name__}"}
        try:
            q_floats = [float(v) for v in q]
        except (TypeError, ValueError) as exc:
            return {"error": f"{self.name}: 'q' entries must be numeric ({exc})"}
        try:
            return send_action("set_joint_positions", q=q_floats)
        except Exception as exc:
            return {"error": f"bridge unreachable: {exc}"}


class SetTcpTargetTool(DefaultTool):
    name = "set_tcp_target"
    description = (
        "Command the UR5e TCP to a world-frame position (x, y, z) in meters. "
        "The bridge solves damped-least-squares IK from the current pose and "
        "rejects the target if it does not converge within 0.05 m. Orientation "
        "is free. On rejection the response contains err_norm and solved_q — "
        "do NOT retry the same target; propose a smaller delta instead."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "number", "description": "World X in meters."},
            "y": {"type": "number", "description": "World Y in meters."},
            "z": {"type": "number", "description": "World Z in meters."},
        },
        "required": ["x", "y", "z"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            x = self.get_arg(kwargs, "x", required=True, type_=float)
            y = self.get_arg(kwargs, "y", required=True, type_=float)
            z = self.get_arg(kwargs, "z", required=True, type_=float)
        except ValueError as exc:
            return {"error": str(exc)}
        try:
            return send_action("set_tcp_target", xyz=[x, y, z])
        except Exception as exc:
            return {"error": f"bridge unreachable: {exc}"}


class SolveIkTool(DefaultTool):
    name = "solve_ik"
    description = (
        "Solve IK for a TCP target without issuing any motion. Use this to "
        "validate reachability before calling set_tcp_target. Returns q, "
        "err_norm, and a 'reachable' boolean."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "number"},
            "y": {"type": "number"},
            "z": {"type": "number"},
        },
        "required": ["x", "y", "z"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            x = self.get_arg(kwargs, "x", required=True, type_=float)
            y = self.get_arg(kwargs, "y", required=True, type_=float)
            z = self.get_arg(kwargs, "z", required=True, type_=float)
        except ValueError as exc:
            return {"error": str(exc)}
        try:
            return send_action("solve_ik", xyz=[x, y, z])
        except Exception as exc:
            return {"error": f"bridge unreachable: {exc}"}


class StopRobotTool(DefaultTool):
    name = "stop_robot"
    description = (
        "Emergency stop: freeze the UR5e at its current joint angles and "
        "clear any active target. Always allowed, always preferred over "
        "waiting out a bad command."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            return send_action("stop")
        except Exception as exc:
            return {"error": f"bridge unreachable: {exc}"}


class ResetToHomeTool(DefaultTool):
    name = "reset_to_home"
    description = (
        "Ramp the UR5e back to the home pose "
        "[0.0, -1.0, 1.4, -1.2, -1.57, 0.0]. Uses joint-space motion, "
        "bounded by IK_MAX_DQ per tick."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            return send_action("reset_home")
        except Exception as exc:
            return {"error": f"bridge unreachable: {exc}"}


ALL_OMNISIM_TOOLS = [
    GetRobotStateTool(),
    ReadJointsTool(),
    ReadTcpPoseTool(),
    GetCapabilitiesTool(),
    SetJointPositionsTool(),
    SetTcpTargetTool(),
    SolveIkTool(),
    StopRobotTool(),
    ResetToHomeTool(),
]
