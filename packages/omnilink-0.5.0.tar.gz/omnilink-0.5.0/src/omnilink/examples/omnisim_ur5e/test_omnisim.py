#!/usr/bin/env python3
"""Smoke tests for the omnisim_ur5e example.

These tests verify the tool schemas, the OmniSimRunner configuration,
and the argument validation path — all without needing Webots or a
running bridge. Tools that make network calls are tested only for
their schema correctness and arg-validation behavior; the actual
HTTP call is not exercised.

Run::

    python -m omnilink.examples.omnisim_ur5e.test_omnisim
"""

from __future__ import annotations

import json
import sys
import traceback
from typing import Any

from omnilink.examples.omnisim_ur5e import (
    ALL_OMNISIM_TOOLS,
    GetRobotStateTool,
    OmniSimRunner,
    SetJointPositionsTool,
    SetTcpTargetTool,
    SolveIkTool,
)
from omnilink.examples.omnisim_ur5e.omnisim_tools import (
    GetCapabilitiesTool,
    ReadJointsTool,
    ReadTcpPoseTool,
    ResetToHomeTool,
    StopRobotTool,
)


PASSED = 0
FAILED = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  [PASS] {label}")
    else:
        FAILED += 1
        print(f"  [FAIL] {label}{' -- ' + detail if detail else ''}")


def test_tool_count() -> None:
    check(
        "ALL_OMNISIM_TOOLS has 9 entries",
        len(ALL_OMNISIM_TOOLS) == 9,
        f"found {len(ALL_OMNISIM_TOOLS)}",
    )


def test_tool_schemas() -> None:
    """Every tool must produce a valid profile dict."""
    for tool in ALL_OMNISIM_TOOLS:
        try:
            d = tool.to_dict()
            has_name = bool(d.get("name"))
            has_desc = bool(d.get("description"))
            has_params = "parameters" in d
            valid_json = json.dumps(d) is not None
            check(
                f"{tool.name}: to_dict() valid",
                has_name and has_desc and has_params and valid_json,
                f"name={has_name} desc={has_desc} params={has_params}",
            )
        except Exception as exc:
            check(f"{tool.name}: to_dict()", False, str(exc))


def test_tool_names() -> None:
    names = {t.name for t in ALL_OMNISIM_TOOLS}
    expected = {
        "get_robot_state", "read_joints", "read_tcp_pose", "get_capabilities",
        "set_joint_positions", "set_tcp_target", "solve_ik", "stop_robot",
        "reset_to_home",
    }
    check(
        "expected tool names present",
        names == expected,
        f"missing={expected - names}, extra={names - expected}",
    )


def test_arg_validation_missing() -> None:
    """SetTcpTargetTool must return an error dict on missing args, not crash."""
    t = SetTcpTargetTool()
    result = t.execute()
    check(
        "set_tcp_target missing args returns error dict",
        isinstance(result, dict) and "error" in result,
        f"got {result}",
    )


def test_arg_validation_bad_type() -> None:
    """SetTcpTargetTool must return error on non-numeric args."""
    t = SetTcpTargetTool()
    result = t.execute(x="not-a-number", y=0.0, z=0.0)
    check(
        "set_tcp_target bad type returns error dict",
        isinstance(result, dict) and "error" in result,
        f"got {result}",
    )


def test_arg_validation_joint_shape() -> None:
    """SetJointPositionsTool must reject q lists of wrong length."""
    t = SetJointPositionsTool()
    result = t.execute(q=[0, 0, 0])  # only 3, needs 6
    check(
        "set_joint_positions wrong length returns error",
        isinstance(result, dict) and "error" in result,
        f"got {result}",
    )


def test_arg_validation_joint_type() -> None:
    """SetJointPositionsTool must reject non-list q."""
    t = SetJointPositionsTool()
    result = t.execute(q="not-a-list")
    check(
        "set_joint_positions non-list returns error",
        isinstance(result, dict) and "error" in result,
        f"got {result}",
    )


def test_no_network_on_import() -> None:
    """Importing the module must not touch the network."""
    # If we got this far (module imported at top), we're good.
    check("import does not require bridge", True)


def test_runner_configuration() -> None:
    """OmniSimRunner should have the expected class attributes."""
    runner = OmniSimRunner()
    check("runner.agent_name is 'axis-ur5e'", runner.agent_name == "axis-ur5e")
    check("runner.engine is 'g4-engine'", runner.engine == "g4-engine")
    check(
        "runner.default_tools matches ALL_OMNISIM_TOOLS",
        runner.default_tools is ALL_OMNISIM_TOOLS,
    )
    check(
        "runner.commands is empty (no legacy text commands)",
        runner.commands == "",
        f"got {runner.commands!r}",
    )
    check(
        "runner.poll_interval is 10 Hz",
        abs(runner.poll_interval - 0.1) < 1e-9,
    )


def test_state_summary_handles_stale() -> None:
    """state_summary must handle stale/error state without crashing."""
    runner = OmniSimRunner()
    s = runner.state_summary({"stale": True, "error": "boom"})
    check(
        "state_summary handles stale state",
        isinstance(s, str) and "UNREACHABLE" in s,
        f"got {s!r}",
    )

    good = runner.state_summary({
        "mode": "tcp", "sim_time": 1.0,
        "q": [0.0, -1.0, 1.4, -1.2, -1.57, 0.0],
        "tcp": [0.5, 0.0, 0.3],
    })
    check(
        "state_summary formats good state",
        isinstance(good, str) and "mode=tcp" in good,
        f"got {good!r}",
    )


def test_is_game_over() -> None:
    """Robot control is open-ended — never signal game over."""
    runner = OmniSimRunner()
    check(
        "is_game_over always False",
        runner.is_game_over({}) is False,
    )


TESTS = [
    test_tool_count,
    test_tool_schemas,
    test_tool_names,
    test_arg_validation_missing,
    test_arg_validation_bad_type,
    test_arg_validation_joint_shape,
    test_arg_validation_joint_type,
    test_no_network_on_import,
    test_runner_configuration,
    test_state_summary_handles_stale,
    test_is_game_over,
]


def main() -> int:
    print("=" * 60)
    print("  omnisim_ur5e smoke tests")
    print("=" * 60)
    for fn in TESTS:
        try:
            fn()
        except Exception:
            global FAILED
            FAILED += 1
            print(f"  [FAIL] {fn.__name__} -- unexpected exception")
            traceback.print_exc()
    print(f"\n  Results: {PASSED} passed, {FAILED} failed out of {PASSED + FAILED} tests")
    return 0 if FAILED == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
