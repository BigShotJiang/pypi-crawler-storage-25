"""Thin HTTP client for the OmniSim UR5e bridge.

The bridge is a Webots Python controller at
``O:/omnisim/projects/samples/demos/controllers/ur5e_omnilink_bridge``.
It listens on 127.0.0.1:6060 and exposes ``/state``, ``/capabilities``,
and ``/action``.
"""

from __future__ import annotations

from typing import Any

import requests

BRIDGE_URL = "http://127.0.0.1:6060"

_session = requests.Session()


def get_state(timeout: float = 2.0) -> dict[str, Any]:
    r = _session.get(f"{BRIDGE_URL}/state", timeout=timeout)
    r.raise_for_status()
    return r.json()


def get_capabilities(timeout: float = 2.0) -> dict[str, Any]:
    r = _session.get(f"{BRIDGE_URL}/capabilities", timeout=timeout)
    r.raise_for_status()
    return r.json()


def send_action(action: str, timeout: float = 5.0, **params: Any) -> dict[str, Any]:
    body = {"action": action}
    body.update(params)
    r = _session.post(f"{BRIDGE_URL}/action", json=body, timeout=timeout)
    if r.status_code >= 400:
        try:
            payload = r.json()
        except ValueError:
            return {"error": r.text or f"HTTP {r.status_code}"}
        if "error" not in payload:
            payload["error"] = f"HTTP {r.status_code}"
        return payload
    return r.json()
