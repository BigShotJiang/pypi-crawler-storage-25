# omnisim_ur5e — OmniLink agent for a UR5e in OmniSim

This is the Python implementation of **Axis**, OmniLink's robot-control
agent (see `agents/axis/` in the OmniLink repo). It drives a UR5e
running inside **OmniSim** — the OmniLink simulation environment built
on Webots.

## Architecture

```
OmniLink platform (browser UI)
        |
        |  chat + direct tool callbacks (HTTPS)
        v
  OmniSimRunner (this package)       [host Python process]
        |
        |  requests.Session → http://127.0.0.1:6060
        v
  ur5e_omnilink_bridge               [inside Webots]
        |-- Robot() / getDevice / setPosition
        |-- forward_kinematics + damped-least-squares IK
        |-- ThreadingHTTPServer on /state /capabilities /action
```

The bridge is the only component that imports `controller` from the
Webots Python API — the OmniLink-side runner never touches Webots. This
is the same separation used by every other robot demo in this library:
sim speaks HTTP, tools are plain `requests` wrappers, the `ToolRunner`
runs the main loop.

## Files

- [`omnisim_api.py`](omnisim_api.py) — `requests.Session` wrapper around the bridge.
- [`omnisim_tools.py`](omnisim_tools.py) — 9 `DefaultTool`s: `get_robot_state`, `read_joints`, `read_tcp_pose`, `get_capabilities`, `set_joint_positions`, `set_tcp_target`, `solve_ik`, `stop_robot`, `reset_to_home`.
- [`play_omnisim.py`](play_omnisim.py) — `OmniSimRunner(ToolRunner)` with the watchdog loop and profile settings.
- `ur5e_omnilink_bridge.py` lives in the OmniSim repo at
  `projects/samples/demos/controllers/ur5e_omnilink_bridge/`.

## Running

1. **Start OmniSim** and open a world that uses a UR5e with the
   `ur5e_omnilink_bridge` controller. The controller auto-binds a
   ThreadingHTTPServer on `127.0.0.1:6060` and loads the UR5e into its
   `HOME_POSE` (`[0.0, -1.0, 1.4, -1.2, -1.57, 0.0]`).

2. **Verify the bridge** from another shell:

   ```bash
   curl http://127.0.0.1:6060/capabilities
   curl http://127.0.0.1:6060/state
   ```

3. **Launch the agent**:

   ```bash
   export OMNI_KEY=olink_...
   python -m omnilink.examples.omnisim_ur5e.play_omnisim
   ```

   On first run, `ToolRunner` creates/updates the `axis-ur5e` profile on
   the OmniLink platform with the `mainTask`, tool schemas, and
   commands. A local HTTPS tool-callback server starts on a random
   port; the platform UI POSTs tool calls there directly.

4. **Drive from the OmniLink UI**: open the platform, pick the
   `axis-ur5e` agent, and prompt it — *"read the current TCP pose"*,
   *"move the tool 5 cm in +x"*, *"reset to home"*.

## Safety model

The runner's `execute_action` is a pure local watchdog — no LLM calls,
no tool dispatch. Every `poll_interval` seconds (default 0.1 s) it:

1. Fetches `/state` from the bridge.
2. If the request failed or `last_tick_at` is older than
   `TELEMETRY_TIMEOUT_S` (2 s), POSTs `stop` to the bridge.
3. If the bridge reports a `fault` field, POSTs `stop`.

This is the Python-lib analogue of Haven's `safety_watchdog` standing
order. OmniLink's standing-orders primitive is platform-side and is not
exposed in the Python library, so we fold the watchdog into
`ToolRunner.run()`'s main loop.

The bridge enforces hard safety on its side too: `clamp_joints` caps
every commanded joint to `limit ± LIMIT_MARGIN` (0.02 rad), and
`set_tcp_target` rejects any target whose IK err_norm exceeds 0.05 m.

## Tuning knobs

| Knob | Default | Where |
|---|---|---|
| `poll_interval` | 0.1 s | `play_omnisim.py:OmniSimRunner` |
| `memory_every` | 15 s | `play_omnisim.py:OmniSimRunner` |
| `TELEMETRY_TIMEOUT_S` | 2.0 s | `play_omnisim.py` |
| `BRIDGE_PORT` | 6060 | `omnisim_api.py` and bridge |
| `IK_ACCEPT_ERR` | 0.05 m | bridge |
| `IK_MAX_DQ` | 0.08 rad/tick | bridge |
| `LIMIT_MARGIN` | 0.02 rad | bridge |
| `MOTOR_VELOCITY` | 1.5 rad/s | bridge |

Change the bridge constants in
`projects/samples/demos/controllers/ur5e_omnilink_bridge/ur5e_omnilink_bridge.py`.
