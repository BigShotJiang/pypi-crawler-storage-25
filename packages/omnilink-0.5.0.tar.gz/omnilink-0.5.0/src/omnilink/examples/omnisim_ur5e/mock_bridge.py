"""Webots-free HTTP bridge for the OmniSim UR5e agent.

Runs the real ``ur5e_omnilink_bridge`` supervisor's HTTP server and
kinematic math in-process *without* needing Webots. Useful for:

* Developing the OmniLink agent locally
* Smoke-testing tools and the safety watchdog
* CI

The mock replaces the supervisor's scene-tree reads with a tiny fake
"physics" loop: on every 16 ms tick, ``real_q`` ramps toward
``commanded_q`` at ``IK_MAX_DQ`` per joint, and ``tcp_real`` is
recomputed via forward kinematics. The HTTP surface is the same one
the real bridge exposes, so the OmniLink tools cannot tell the
difference.

Run::

    python -m omnilink.examples.omnisim_ur5e.mock_bridge

Set ``OMNISIM_BRIDGE_PATH`` to point at the real bridge file if it
lives somewhere other than the default OmniSim checkout.
"""

from __future__ import annotations

import importlib.util
import os
import sys
import threading
import time
import types

# Stub the Webots 'controller' module so the real bridge file imports
# cleanly in a plain Python process.
if "controller" not in sys.modules:
    sys.modules["controller"] = types.SimpleNamespace(
        Supervisor=object, Keyboard=object, Robot=object,
    )

# Locate the real bridge source.  Precedence:
#   1. OMNISIM_BRIDGE_PATH env var (explicit user override)
#   2. Sibling OmniSim checkout next to olink (the common dev layout)
#   3. ~/omnisim/... (user home checkout)
#
# We defer the RuntimeError until ``_load_bridge()`` is actually called
# so that simply importing this module (e.g. from __init__.py) never
# crashes on machines without an OmniSim checkout.

_CANDIDATE_BRIDGE_PATHS: list[str] = []
if os.environ.get("OMNISIM_BRIDGE_PATH"):
    _CANDIDATE_BRIDGE_PATHS.append(os.environ["OMNISIM_BRIDGE_PATH"])
_CANDIDATE_BRIDGE_PATHS.extend(
    [
        os.path.abspath(os.path.join(
            os.path.dirname(__file__), "..", "..", "..", "..", "..",
            "omnisim", "projects", "samples", "demos", "controllers",
            "ur5e_omnilink_bridge", "ur5e_omnilink_bridge.py",
        )),
        os.path.expanduser(
            "~/omnisim/projects/samples/demos/controllers/"
            "ur5e_omnilink_bridge/ur5e_omnilink_bridge.py"
        ),
    ]
)

_br: Any = None


def _load_bridge() -> Any:
    """Load the real bridge module lazily so import never crashes."""
    global _br
    if _br is not None:
        return _br
    for path in _CANDIDATE_BRIDGE_PATHS:
        if not path or not os.path.exists(path):
            continue
        spec = importlib.util.spec_from_file_location(
            "ur5e_omnilink_bridge_real", path,
        )
        if spec is None or spec.loader is None:
            continue
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _br = module
        return _br
    raise RuntimeError(
        "Could not locate ur5e_omnilink_bridge.py. Set OMNISIM_BRIDGE_PATH "
        "to its absolute path, or check out OmniSim next to this repo.\n"
        f"  Tried: {_CANDIDATE_BRIDGE_PATHS}"
    )


def run_fake_physics(state, stop_event: threading.Event, pause_event: threading.Event) -> None:
    br = _load_bridge()
    tick = 0.016
    state.tick_period_s = tick
    while not stop_event.is_set():
        if pause_event.is_set():
            time.sleep(tick)
            continue

        with state.lock:
            mode = state.mode
            target_xyz = list(state.target_xyz)
            cur_real = list(state.real_q)
            cur_cmd = list(state.commanded_q)

        if mode == "tcp":
            cur_cmd, err = br.solve_ik(cur_cmd, target_xyz)
            cur_cmd = br.clamp_joints(cur_cmd)
            with state.lock:
                state.commanded_q = cur_cmd
                state.fault = (
                    f"ik_drift:{err:.3f}" if err > br.IK_FAULT_ERR else None
                )

        new_real = []
        for r, c in zip(cur_real, cur_cmd):
            d = c - r
            if d > br.IK_MAX_DQ:
                d = br.IK_MAX_DQ
            elif d < -br.IK_MAX_DQ:
                d = -br.IK_MAX_DQ
            new_real.append(r + d)
        tcp = br.forward_kinematics(new_real)

        with state.lock:
            state.real_q = new_real
            state.tcp_real = [tcp[0], tcp[1], tcp[2]]
            state.last_tick_at = time.time()
            state.sim_time += tick

        time.sleep(tick)


def start_mock(home_pose=None, home_target=None):
    br = _load_bridge()
    home_pose = home_pose or br.HOME_POSE
    home_target = home_target or br.HOME_TARGET
    state = br.BridgeState(list(home_pose), list(home_target))
    tcp = br.forward_kinematics(home_pose)
    state.tcp_real = [tcp[0], tcp[1], tcp[2]]

    stop_event = threading.Event()
    pause_event = threading.Event()
    phys = threading.Thread(
        target=run_fake_physics,
        args=(state, stop_event, pause_event),
        daemon=True,
    )
    phys.start()
    server = br.start_http(state)
    print(
        f"[mock_bridge] tick={state.tick_period_s*1000:.0f} ms "
        f"HOME_POSE loaded, TCP={tuple(round(v,3) for v in tcp)}"
    )
    return state, server, stop_event, pause_event


def main() -> None:
    state, server, stop_event, pause_event = start_mock()
    print("[mock_bridge] Ctrl+C to exit.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_event.set()
        server.shutdown()


if __name__ == "__main__":
    main()
