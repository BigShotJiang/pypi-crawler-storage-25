# File Search Agent — Default Tools Demo

An interactive demo that equips an OmniLink agent with file-system tools
so it can search, read, and browse a local knowledge base to answer user
questions — all driven from the OmniLink web UI.

---

## Overview

This example shows how to use the **default tools** system in the OmniLink
Python SDK.  A local Python script starts a tool callback server and
configures an agent profile.  The user then asks questions in the OmniLink
build page, and the cloud agent calls the local tools to find answers.

### Architecture

```
┌─────────────────────────────────────────────────────┐
│          OmniLink Build Page (browser)               │
│                                                      │
│  1. User types a question                            │
│  2. Agent responds with Tool: search_files(...)      │
│  3. UI calls local tool server, gets result          │
│  4. Result sent back to agent                        │
│  5. Agent calls more tools or gives final answer     │
│                                                      │
│  The tool-calling loop repeats up to "max tool       │
│  rounds" (configurable in Configuration page).       │
└──────────────┬──────────────────────────────────────┘
               │  HTTP POST to localhost
               ▼
┌──────────────────────────────────────────────────────┐
│      Local Tool Callback Server (Python)             │
│                                                      │
│  POST /tool  { "tool": "search_files",               │
│                "query": "pricing" }                   │
│                                                      │
│  → Executes SearchFilesTool against sample_data/     │
│  → Returns JSON result to UI                         │
│                                                      │
│  GET /activity  → returns activity log entries        │
└──────────────────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────┐
│      sample_data/ (local knowledge base)             │
│                                                      │
│  company/team.md       — engineering org chart        │
│  company/products.md   — product descriptions         │
│  projects/roadmap.md   — Q2 2026 roadmap              │
│  projects/bugs.csv     — bug tracker                  │
└──────────────────────────────────────────────────────┘
```

---

## Quick Start

### 1. Set your Omni Key

```bash
export OMNI_KEY=omk_your_key_here
```

### 2. Run the demo

```bash
python -m omnilink.examples.file_search.file_search_demo
```

You'll see:

```
============================================================
  File Search Agent — Interactive Demo
============================================================

  Tool server:     http://127.0.0.1:54321/tool
  Activity log:    http://127.0.0.1:54321/activity
  Knowledge base:  /path/to/sample_data

  Open the UI:     https://www.omnilink-agents.com/build

  Ask a question in the UI — the agent will use your
  local tools to search files and answer.

  Press Ctrl+C to stop.
============================================================
```

### 3. Open the UI and ask a question

Go to **https://www.omnilink-agents.com/build** and type a question.
The agent will call tools through your local server and respond with
an answer.

---

## Available Tools

The demo registers three default tools from `omnilink.default_tools`:

### `search_files`

Searches for text content within files.

| Argument | Type | Required | Description |
|----------|------|----------|-------------|
| `query` | string | yes | Text to search for (case-insensitive) |
| `path` | string | no | Subdirectory to search in |
| `file_pattern` | string | no | Glob pattern, e.g. `*.csv` |

Returns matching lines with file paths, line numbers, and surrounding
context.

### `read_file`

Reads the contents of a specific file.

| Argument | Type | Required | Description |
|----------|------|----------|-------------|
| `path` | string | yes | File path relative to root |
| `start_line` | int | no | Start line (1-based) |
| `end_line` | int | no | End line (1-based) |

Returns numbered lines of the file content.

### `list_files`

Lists files and directories.

| Argument | Type | Required | Description |
|----------|------|----------|-------------|
| `path` | string | no | Subdirectory to list (defaults to root) |
| `file_pattern` | string | no | Glob pattern to filter files |

Returns entries with name, path, type (file/directory), and size.

---

## Tool Call Format

The agent uses inline tool calls — a single line with the tool name and
a JSON argument object:

```
Tool: search_files({"query": "pricing"})
Tool: read_file({"path": "company/products.md"})
Tool: list_files({})
```

The UI parses this format, calls the local tool server, feeds the result
back to the agent, and repeats until the agent gives a final answer.  The
number of consecutive tool calls is controlled by the **Max tool rounds**
setting in the Configuration page.

---

## Example Prompts

These prompts work well with the included `sample_data/` knowledge base:

| Prompt | Tools used | What happens |
|--------|-----------|--------------|
| "Who is the CTO?" | `search_files` | Searches for "CTO", finds it in team.md |
| "What is the pricing?" | `search_files` → `read_file` | Searches for "pricing", reads products.md |
| "What bugs are open?" | `search_files` or `read_file` | Reads bugs.csv for open items |
| "What files do you have?" | `list_files` | Lists the root directory |
| "What positions are open and who manages engineering?" | `search_files` → `read_file` | Multi-tool chain across team.md |
| "Show me the roadmap" | `search_files` → `read_file` | Finds and reads roadmap.md |
| "Find anything about Kubernetes" | `search_files` | Searches all files for "Kubernetes" |

---

## How It Works

### 1. Agent Profile Setup

The demo creates (or updates) an agent profile named `file-search-agent`
with:

- **Tool definitions** registered via `default_tools` on the `ToolRunner`
  subclass — the tool names and descriptions are automatically included in
  the agent's `availableToolDetails`.
- **Tool callback URL** pointing to the local server so the UI knows where
  to send tool execution requests.
- **Main task** instructing the agent to search/read files before answering.

### 2. Tool Callback Server

`ToolRunner._start_tool_server()` launches a lightweight HTTP server on a
random port with two endpoints:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/tool` | POST | Executes a tool. Body: `{"tool": "name", "arg": "val"}` |
| `/activity` | GET | Returns recent activity log entries as JSON |

When the UI sends `POST /tool`, the server calls
`runner.execute_query_tool(name, **args)` which dispatches to the matching
`DefaultTool.execute()` method.

### 3. Multi-Round Tool Execution

When the agent's response contains a `Tool:` tag, the UI:

1. Parses the tool name and args from the inline format
2. Sends a POST to the tool callback URL
3. Receives the JSON result
4. Sends the result back to the agent as a follow-up message
5. If the agent responds with another `Tool:` tag, repeats from step 1

This loop continues up to **max tool rounds** (configurable in the
Configuration page, default 5).  The tool progress spinner in the UI
shows which tool is currently running.

### 4. Activity Tracking

All tool calls are visible in the UI through:

- **Activity page** (side menu → Activity) — shows all agent events
  from conversation memory
- **Toast notifications** — pop up in the bottom-right corner when
  tools are called, even if you're not on the Activity page
- **Badge on the Activity menu** — shows unseen event count

---

## Customizing the Knowledge Base

Replace the files in `sample_data/` with your own content. The tools
search any text files — `.md`, `.txt`, `.csv`, `.json`, `.py`, etc.

To point at a different directory:

```python
class MyRunner(ToolRunner):
    default_tools = [
        SearchFilesTool(root_dir="/path/to/your/docs"),
        ReadFileTool(root_dir="/path/to/your/docs"),
        ListFilesTool(root_dir="/path/to/your/docs"),
    ]
```

### Tool Options

Each tool accepts configuration:

```python
SearchFilesTool(
    root_dir="./data",
    allowed_extensions={".md", ".txt"},  # only search these types
    max_results=50,                       # max matching lines returned
    max_file_size=2_000_000,              # skip files larger than 2MB
    context_lines=2,                      # lines before/after each match
)

ReadFileTool(
    root_dir="./data",
    max_file_size=2_000_000,
    max_lines=500,                        # max lines returned per read
)

ListFilesTool(
    root_dir="./data",
    max_entries=200,                      # max directory entries returned
)
```

All tools enforce path traversal protection — requests for paths outside
`root_dir` are rejected.

---

## Creating Custom Tools

Extend `DefaultTool` to create your own:

```python
from omnilink.default_tools import DefaultTool

class DatabaseQueryTool(DefaultTool):
    name = "query_db"
    description = "Run a read-only SQL query. Args: sql (required)."

    def __init__(self, connection_string: str):
        self.conn_str = connection_string

    def execute(self, **kwargs):
        sql = kwargs.get("sql", "")
        if not sql:
            return {"error": "Missing required argument: sql"}
        # ... execute query and return results ...
        return {"rows": results, "count": len(results)}
```

Then add it to your runner:

```python
class MyRunner(ToolRunner):
    default_tools = [
        SearchFilesTool(root_dir="./docs"),
        DatabaseQueryTool(connection_string="sqlite:///app.db"),
    ]
```

The tool is automatically registered in the agent profile and dispatched
when the agent calls `Tool: query_db({"sql": "SELECT ..."})`.

---

## Files

```
file_search/
├── README.md                  ← this file
├── __init__.py
├── file_search_demo.py        ← demo entry point
└── sample_data/
    ├── company/
    │   ├── team.md            ← engineering org chart
    │   └── products.md        ← product descriptions and pricing
    └── projects/
        ├── roadmap.md         ← Q2 2026 roadmap
        └── bugs.csv           ← bug tracker (id, title, severity, status, assignee)
```
