# Engineering Team

## Leadership
- **CTO**: Sarah Chen — oversees platform architecture and AI strategy.
- **VP Engineering**: Marcus Rivera — manages all engineering squads.

## Backend Squad
- Aisha Patel — senior backend engineer, owns the ingestion pipeline.
- Tomás García — backend engineer, focuses on API performance.
- Yuki Tanaka — backend engineer, database specialist.

## Frontend Squad
- Liam O'Brien — senior frontend engineer, design-system lead.
- Priya Sharma — frontend engineer, accessibility champion.

## DevOps
- Jordan Lee — SRE, manages Kubernetes clusters and CI/CD.

## Hiring
We are currently hiring for:
- Staff Backend Engineer (remote, US/EU timezones)
- ML Engineer (hybrid, San Francisco)
