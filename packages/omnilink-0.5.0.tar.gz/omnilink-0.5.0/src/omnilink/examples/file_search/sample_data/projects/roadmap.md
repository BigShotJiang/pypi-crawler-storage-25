# Q2 2026 Roadmap

## In Progress
- **Multi-agent orchestration** — allow agents to delegate sub-tasks to
  other agents. Owner: Sarah Chen. ETA: April 15.
- **Streaming tool callbacks** — support chunked responses from tool servers.
  Owner: Tomás García. ETA: April 30.

## Planned
- **Plugin marketplace** — community-contributed tool packs.
  Target: May 2026.
- **Audit logging** — enterprise compliance feature, full request/response logs.
  Target: June 2026.

## Completed (Q1 2026)
- Default tools (search_files, read_file, list_files) shipped in SDK 0.4.
- Live audio latency reduced from 800ms to 320ms.
- Added Claude (g4-engine) support.
