# Products

## OmniLink Platform
Our flagship product. A cloud-based AI agent orchestration platform that
connects language models to local tool controllers for real-time task execution.

- **Pricing**: Free tier (100 calls/day), Pro ($49/mo), Enterprise (custom).
- **Launch date**: March 2024.
- **Key features**: multi-engine support (GPT, Gemini, Grok, Claude),
  tool callbacks, live audio, memory persistence.

## OmniLink Python SDK
Open-source library (`pip install omnilink`) for building local AI controllers.
Version 0.3.1. Supports Python 3.9+.

## OmniLink Web SDK
JavaScript/TypeScript client for browser-based integrations.
Published on npm as `@omnilink/sdk`.
