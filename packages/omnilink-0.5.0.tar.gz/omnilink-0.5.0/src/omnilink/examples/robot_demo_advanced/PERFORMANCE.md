# Advanced Robot Demo — Performance Report

Benchmarked on 2026-04-10 using the full UI pipeline (`/api/chat`) with
the ToolRunner HTTP server executing tools on the advanced Pygame simulation.

---

## Test Configuration

| Parameter | Standard Demo | Advanced Demo |
|-----------|--------------|---------------|
| Grid | 20x15 (300 cells) | **40x30 (1200 cells)** |
| Obstacles | 54 (18%) | **293 (24.4%)** |
| Items | 10 (1 type) | **24 (4 types: gem, crystal, artifact, key)** |
| Tools | 16 | **22** |
| Zones | None | **Safe, Danger (2x drain), Recharge (+10%)** |
| Doors | None | **6 locked (require keys)** |
| Teleporters | None | **3 bidirectional pairs** |
| Traps | None | **15 hidden** |
| Patrol Guards | None | **4 moving** |
| Inventory | Unlimited | **Weight-limited (max 5)** |
| Depot | None | **At (38,28) for item deposit** |
| Objectives | Collect items | **Multi-objective: artifacts + score + exploration + battery** |

---

## Standard Demo Benchmark (v0.4.3+, latest platform)

10-minute sustained benchmark through `/api/chat`:

| Metric | Value |
|--------|-------|
| Duration | 10.4 min |
| Tasks completed | 13 |
| API calls | 56 |
| Tool calls | 56 |
| Total tokens | 140,968 |
| Tokens/task | 10,844 |
| Cache hit | 57% |
| Errors | 0 |

---

## Advanced Demo — Agent Stress Test Results

6 tasks of increasing difficulty, each with sim reset, through `/api/chat`
with the G3 engine (Grok 4.1 Fast Reasoning).

### Task 1: EASY — Status check and scan

**Prompt:** "Check your status, scan the area, and tell me what's around you."

| Metric | Value |
|--------|-------|
| Tools | 3 |
| Rounds | 2 |
| Duration | 20s |
| Tools used | get_status, scan_area, analyze_surroundings |

Agent immediately gathered all info in one round. Correct behavior.

### Task 2: MEDIUM — Find and collect nearby item

**Prompt:** "Find the nearest item, navigate to it, pick it up, check objectives."

| Metric | Value |
|--------|-------|
| Tools | 2 |
| Rounds | 3 |
| Duration | 33s |
| Tools used | scan_and_list, get_objectives |

Agent used the compound `scan_and_list` tool efficiently.

### Task 3: HARD — Find key, unlock door

**Prompt:** "Find a key, unlock the nearest locked door, report what's on the other side."

| Metric | Value |
|--------|-------|
| Tools | 18 |
| Rounds | 5 |
| Duration | 183s |
| Key collected | Yes (key at position) |
| Tools used | get_status, scan_and_list(3x), get_obstacles, scan_area(2x), analyze_surroundings, check_zone(5x), go_to(2x), collect_item, get_map_info |

Agent navigated to find a key, checked zones for safety, collected
the key. Demonstrated multi-step planning with zone awareness.

### Task 4: MEDIUM — Navigate to recharge zone

**Prompt:** "Navigate to a recharge zone to top up battery, avoiding danger zones."

| Metric | Value |
|--------|-------|
| Tools | 3 |
| Rounds | 2 |
| Duration | 48s |
| Tools used | get_status, scan_area, analyze_surroundings |

Quick recon. Agent scanned but recharge zone was not in immediate vicinity.

### Task 5: EXPERT — Collect, deposit, maximize score

**Prompt:** "Collect as many items as possible, deposit at depot, maximize score.
Monitor weight limit."

| Metric | Value |
|--------|-------|
| Tools | **53** |
| Rounds | **30** (hit max) |
| Duration | **7 min 28s** |
| Items collected | **6** |
| Items deposited | **2 batches** |
| Final score | **125** |
| Battery remaining | 13% |
| Artifacts collected | 1/3 |

**Tool breakdown:**

| Tool | Calls |
|------|-------|
| check_zone | 10 |
| scan_and_list | 9 |
| collect_item | 6 |
| go_to | 6 |
| get_status | 5 |
| get_map_info | 4 |
| use_teleporter | 4 |
| get_objectives | 3 |
| deposit_items | 2 |
| analyze_surroundings | 2 |
| get_obstacles | 1 |
| find_path | 1 |

**Key behaviors observed:**
- Collected 6 items including 1 artifact, 2 crystals, 3 gems
- **Used depot**: Navigated to (38,28) and deposited items for 125 points
- **Used teleporters**: Teleported 4 times to save battery traversing the map
- **Zone awareness**: Checked zones 10 times before moving into unknown areas
- **Weight management**: Monitored inventory with 6 collect_item calls
- **Battery conservation**: Used teleporters to avoid long walks

### Task 6: EXTREME — Collect all artifacts mission

**Prompt:** "Plan and execute a mission to collect all 3 artifacts. Use keys
to unlock doors, teleporters to save battery, deposit at depot. Check
objectives after each major step."

| Metric | Value |
|--------|-------|
| Tools | **36** |
| Rounds | **30** (hit max) |
| Duration | **6 min 52s** |
| Items collected | 6 |
| Final score | 125 |
| Battery remaining | 19% |
| Artifacts collected | 1/3 (ran out of rounds) |

**Tool breakdown:**

| Tool | Calls |
|------|-------|
| scan_and_list | 9 |
| collect_item | 6 |
| go_to | 5 |
| use_teleporter | 3 |
| analyze_surroundings | 3 |
| get_status | 3 |
| get_objectives | 2 |
| get_map_info | 2 |
| deposit_items | 2 |
| scan_area | 1 |

**Key behaviors observed:**
- Immediately checked objectives and scanned for planning
- **Teleported early**: Used teleporter at (3,3)→(36,26) to reach far side
- Collected crystals and gems near teleporter destination
- **Deposited at depot** twice for 125 total points
- **Teleported back** to starting area to continue collecting
- Checked zones systematically before navigation
- Hit 30-round limit while still actively planning next steps

---

## Aggregate — Advanced Demo

| Metric | Value |
|--------|-------|
| Total tasks | 6 |
| Total tool calls | 115 |
| Total duration | ~19 min |
| Unique tools used | 15 of 22 (68%) |
| Max score achieved | 125 |
| Max artifacts in one run | 1/3 |
| Teleporter uses | 7 (across tasks 5+6) |
| Depot deposits | 4 |
| Errors | 0 |

### Tools Never Called

These 7 tools were available but never called:
- `move_backward` — Agent preferred go_to for navigation
- `turn_left`, `turn_right` — go_to handles heading automatically
- `move_forward` — go_to is more efficient
- `set_speed` — Not needed with go_to
- `drop_item` — Agent deposited instead
- `unlock_door` — Keys were collected but doors not reached in time
- `get_inventory_weight` — Agent tracked implicitly

---

## Standard vs Advanced — Comparison

| Metric | Standard (10 min) | Advanced (EXPERT task) |
|--------|-------------------|----------------------|
| Grid size | 300 cells | **1200 cells** |
| Tools available | 16 | **22** |
| Tools called | 56 | **53** |
| Unique tools | ~12 | **12** |
| Features used | Move, scan, collect | **Move, scan, collect, teleport, deposit, zone-check** |
| Score achieved | ~30 | **125** |
| Planning depth | Simple (scan→move→pick) | **Complex (scan→teleport→collect→deposit→teleport back)** |
| Battery management | Passive (just runs out) | **Active (uses teleporters, avoids danger zones)** |

### Key Observations

1. **The agent handles complexity well.** With 22 tools, 4 zone types,
   doors, teleporters, and traps, the agent still makes coherent
   multi-step plans and executes them correctly.

2. **Compound tools are essential.** `collect_item` and `scan_and_list`
   dramatically reduce round count — the agent used them heavily in
   all tasks.

3. **Teleporters are used strategically.** In Tasks 5 and 6, the agent
   figured out that teleporting saves battery vs walking, and used
   them to travel between the depot and collection areas.

4. **Zone awareness works.** The agent checked zones 10+ times in the
   expert task, demonstrating it understands danger/recharge/safe
   zone mechanics.

5. **30-round limit is the bottleneck.** Both EXPERT and EXTREME tasks
   hit the 30-round ceiling. With more rounds, the agent would likely
   collect all 3 artifacts and achieve a higher score.

6. **Zero errors** across all 6 tasks and 115 tool calls.

---

## G1 vs G3 Engine Comparison

Both engines tested on the same 6 tasks (sim reset between each).

### Per-Task Results

| Task | Difficulty | G3 Tools | G3 Rounds | G3 Score | G1 Tools | G1 Rounds | G1 Score |
|------|-----------|---------|----------|---------|---------|----------|---------|
| 1 | EASY | 3 | 2 | 0 | 2 | 3 | 0 |
| 2 | MEDIUM | 2 | 3 | 0 | 7 | 7 | 0 |
| 3 | HARD | 18 | 5 | 0 | **35** | **30** | **60** |
| 4 | HARD | 3 | 2 | 0 | **31** | **30** | **110** |
| 5 | EXPERT | **53** | **30** | **125** | 32 | 30 | 20 |
| 6 | EXTREME | **36** | **30** | **125** | 32 | 30 | **80** |
| **Total** | | **115** | | **125** | **139** | | **80–110** |

### Tool Usage Comparison

| Tool | G3 Calls | G1 Calls |
|------|---------|---------|
| scan_and_list | 9 | 29 |
| collect_item | 6 | 31 |
| go_to | 6 | 21 |
| get_status | 5 | 10 |
| check_zone | 10 | 4 |
| get_map_info | 4 | 14 |
| get_objectives | 3 | 5 |
| use_teleporter | 4 | 5 |
| deposit_items | 2 | 6 |
| analyze_surroundings | 2 | 8 |
| unlock_door | 0 | **3** |
| scan_area | 0 | 2 |
| get_items | 0 | 1 |
| get_obstacles | 1 | 0 |
| find_path | 1 | 0 |

### Key Differences

1. **G1 unlocked doors; G3 did not.** G1 called `unlock_door` 3 times
   across Tasks 3 and 5, demonstrating it understood the key-door
   mechanic. G3 never attempted to unlock a door.

2. **G1 was more aggressive at collecting.** G1 called `collect_item`
   31 times vs G3's 6 — it spent more rounds gathering items across
   tasks 3–6.

3. **G3 was more focused on EXPERT/EXTREME.** G3 scored 125 on both
   Tasks 5 and 6, while G1 scored 20 and 80 respectively. G3 used
   teleporters more strategically on those specific tasks.

4. **G1 deposited more often.** 6 deposits vs G3's 2 — it made
   frequent trips to the depot, especially in Tasks 3 and 4.

5. **G1 spent more rounds on HARD tasks.** Tasks 3 and 4 both hit the
   30-round limit on G1 (with scores of 60 and 110), while G3 resolved
   them in 2–5 rounds with score 0 (didn't attempt collection).

6. **Both engines achieved zero errors** across all 6 tasks.

### Interpretation

G3 (Grok) is more efficient — it focuses on the specific objective and
completes it with fewer tool calls. G1 (Gemini) is more exploratory —
it collects opportunistically, uses more tool types, and achieves higher
scores on HARD tasks but is less efficient on EXPERT/EXTREME tasks.

Both engines demonstrate coherent multi-step planning with 22 tools
across a complex environment. The choice between them depends on whether
you prioritize **efficiency** (G3) or **thoroughness** (G1).

---

## Running the Tests

```bash
# Start the advanced simulation and ToolRunner
python -m omnilink.examples.robot_demo_advanced.advanced_sim
OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo_advanced.run_advanced_demo

# Run unit tests (22 tests)
python -m omnilink.examples.robot_demo_advanced.test_advanced

# Run agent stress test (6 tasks, EASY to EXTREME)
OMNI_KEY="olink_..." python src/omnilink/examples/robot_demo_advanced/test_advanced_agent.py

# Run with a specific engine (g1-engine, g2-engine, g3-engine, g4-engine)
OMNI_KEY="olink_..." python src/omnilink/examples/robot_demo_advanced/test_advanced_agent.py g1-engine
```
