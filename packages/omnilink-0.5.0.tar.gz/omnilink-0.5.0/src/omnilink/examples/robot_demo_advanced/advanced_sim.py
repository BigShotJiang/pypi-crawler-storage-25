#!/usr/bin/env python3
"""Advanced Pygame mobile-robot simulation with HTTP server on port 5051.

40x30 grid with zones (safe/danger/recharge), doors, teleporters,
patrol guards, traps, multi-objective scoring, and inventory weight.

Run this first, then start run_advanced_demo.py in another terminal.

    python -m omnilink.examples.robot_demo_advanced.advanced_sim
"""

from __future__ import annotations

import heapq
import http.server
import json
import math
import random
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import pygame

# ── Grid constants ────────────────────────────────────────────
COLS, ROWS = 40, 30
CELL = 24
HUD_H = 80
WIDTH = COLS * CELL
HEIGHT = ROWS * CELL + HUD_H
FPS = 30
PORT = 5051
SEED = 42

# ── Colours ───────────────────────────────────────────────────
C_BG = (25, 25, 35)
C_GRID = (40, 40, 50)
C_FLOOR = (45, 45, 55)
C_WALL = (90, 60, 60)
C_FOG = (20, 20, 28)
C_ROBOT = (60, 200, 120)
C_HUD_BG = (18, 18, 26)
C_HUD_TXT = (200, 200, 210)
C_BATTERY = (100, 220, 100)
C_BATTERY_LOW = (220, 80, 80)
C_TRAIL = (40, 70, 50)

# Zone colours
C_SAFE = (40, 55, 45)
C_DANGER = (70, 35, 35)
C_RECHARGE = (35, 45, 70)

# Special tile colours
C_DOOR_LOCKED = (160, 120, 40)
C_DOOR_UNLOCKED = (80, 100, 60)
C_TELEPORTER = (140, 60, 180)
C_TRAP_HIDDEN = C_FLOOR  # looks like normal floor
C_TRAP_REVEALED = (180, 100, 40)
C_DEPOT = (220, 200, 60)
C_PATROL = (200, 60, 60)

# Item colours
C_ITEM_GEM = (80, 180, 255)
C_ITEM_CRYSTAL = (180, 100, 255)
C_ITEM_ARTIFACT = (255, 180, 60)
C_ITEM_KEY = (255, 255, 150)

# ── Headings ──────────────────────────────────────────────────
HEADINGS = ["N", "E", "S", "W"]
DX = {"N": 0, "E": 1, "S": 0, "W": -1}
DY = {"N": -1, "E": 0, "S": 1, "W": 0}

# ── Item values and weights ───────────────────────────────────
ITEM_VALUES = {"gem": 10, "crystal": 25, "artifact": 50, "key": 0}
ITEM_WEIGHTS = {"gem": 1, "crystal": 1, "artifact": 2, "key": 1}
MAX_CARRY = 5


# ── Simulation ────────────────────────────────────────────────

class AdvancedRobotSim:
    def __init__(self, seed: int = SEED) -> None:
        self.rng = random.Random(seed)
        self.robot_x = 1
        self.robot_y = 1
        self.heading = "E"
        self.battery = 100.0
        self.speed = 1
        self.inventory: List[Dict[str, Any]] = []
        self.score = 0
        self.deposit_score = 0
        self.steps = 0
        self.message = "Advanced robot ready."
        self.game_state = "PLAY"
        self.trail: List[Tuple[int, int]] = []
        self.tick_count = 0

        # Zones: map (x,y) -> zone type
        self.zones: Dict[Tuple[int, int], str] = {}

        # Doors: map (x,y) -> locked/unlocked
        self.doors: Dict[Tuple[int, int], str] = {}

        # Teleporters: map (x,y) -> destination (x,y)
        self.teleporters: Dict[Tuple[int, int], Tuple[int, int]] = {}

        # Traps: map (x,y) -> revealed bool
        self.traps: Dict[Tuple[int, int], bool] = {}

        # Depot location
        self.depot: Tuple[int, int] = (COLS - 2, ROWS - 2)

        # Patrol guards: list of {x, y, path: [(x,y),...], idx, direction}
        self.patrols: List[Dict[str, Any]] = []

        # Build world
        self.obstacles: set[Tuple[int, int]] = set()
        self._generate_world()

        # Place items
        self.items: List[Dict[str, Any]] = []
        self._place_items()

        # Fog of war
        self.revealed: set[Tuple[int, int]] = set()
        self._reveal_around(self.robot_x, self.robot_y, 2)

        # Objectives tracking
        self.artifacts_collected = 0
        self.total_artifacts = sum(1 for i in self.items if i["type"] == "artifact")
        self.exploration_target = int(COLS * ROWS * 0.8)

    def _is_safe_spawn(self, x: int, y: int) -> bool:
        """Check if position is in the spawn-safe zone."""
        return x <= 3 and y <= 3

    def _generate_world(self) -> None:
        """Generate obstacles, zones, doors, teleporters, traps, patrols."""
        rng = self.rng

        # --- Zones ---
        # Danger zone: a large rectangular region
        for y in range(8, 18):
            for x in range(12, 28):
                self.zones[(x, y)] = "danger"

        # Recharge zones: 3 stations
        recharge_centers = [(5, 14), (20, 25), (35, 5)]
        for cx, cy in recharge_centers:
            for dy in range(-1, 2):
                for dx in range(-1, 2):
                    nx, ny = cx + dx, cy + dy
                    if 0 <= nx < COLS and 0 <= ny < ROWS:
                        self.zones[(nx, ny)] = "recharge"

        # Everything else defaults to safe (no entry needed)

        # --- Obstacles (~25% coverage = ~300) ---
        target_obstacles = int(COLS * ROWS * 0.25)
        safe_positions = set()
        safe_positions.add((self.robot_x, self.robot_y))
        safe_positions.add(self.depot)
        # Keep spawn area clear
        for y in range(4):
            for x in range(4):
                safe_positions.add((x, y))
        # Keep recharge centers clear
        for cx, cy in recharge_centers:
            for dy in range(-1, 2):
                for dx in range(-1, 2):
                    safe_positions.add((cx + dx, cy + dy))

        while len(self.obstacles) < target_obstacles:
            x, y = rng.randint(0, COLS - 1), rng.randint(0, ROWS - 1)
            if (x, y) not in safe_positions:
                self.obstacles.add((x, y))

        # --- Doors (6 doors, placed at strategic chokepoints) ---
        door_positions = [
            (11, 12), (11, 14), (28, 12), (28, 14),
            (20, 7), (20, 18),
        ]
        for dx, dy in door_positions:
            if 0 <= dx < COLS and 0 <= dy < ROWS:
                self.obstacles.discard((dx, dy))
                self.doors[(dx, dy)] = "locked"

        # --- Teleporters (3 pairs) ---
        tp_pairs = [
            ((3, 3), (36, 26)),
            ((10, 25), (30, 3)),
            ((18, 22), (35, 15)),
        ]
        for a, b in tp_pairs:
            self.obstacles.discard(a)
            self.obstacles.discard(b)
            self.teleporters[a] = b
            self.teleporters[b] = a

        # --- Traps (15 hidden traps scattered in danger zone and paths) ---
        traps_placed = 0
        while traps_placed < 15:
            x = rng.randint(0, COLS - 1)
            y = rng.randint(0, ROWS - 1)
            pos = (x, y)
            if (pos not in self.obstacles and pos not in self.doors
                    and pos not in self.teleporters
                    and not self._is_safe_spawn(x, y)
                    and pos != self.depot
                    and pos not in self.traps):
                self.traps[pos] = False  # False = hidden
                traps_placed += 1

        # --- Patrol guards (4 patrols) ---
        patrol_defs = [
            {"path": [(15, 5), (15, 6), (15, 7), (15, 6)]},
            {"path": [(25, 20), (26, 20), (27, 20), (26, 20)]},
            {"path": [(8, 10), (8, 11), (8, 12), (8, 13), (8, 12), (8, 11)]},
            {"path": [(32, 10), (33, 10), (34, 10), (33, 10)]},
        ]
        for pd in patrol_defs:
            path = pd["path"]
            # Clear patrol path of obstacles
            for px, py in path:
                self.obstacles.discard((px, py))
            self.patrols.append({
                "x": path[0][0],
                "y": path[0][1],
                "path": path,
                "idx": 0,
                "direction": 1,
            })

        # Ensure depot is clear
        self.obstacles.discard(self.depot)
        # Ensure all door positions remain clear of obstacles
        for pos in self.doors:
            self.obstacles.discard(pos)

    def _place_items(self) -> None:
        """Place items: 3 artifacts, 6 keys, 10 gems, 5 crystals."""
        rng = self.rng

        placements = (
            [("artifact", 3), ("key", 6), ("gem", 10), ("crystal", 5)]
        )

        for item_type, count in placements:
            placed = 0
            while placed < count:
                x = rng.randint(0, COLS - 1)
                y = rng.randint(0, ROWS - 1)
                pos = (x, y)
                if (pos not in self.obstacles
                        and pos not in self.doors
                        and pos not in self.teleporters
                        and pos != self.depot
                        and pos != (self.robot_x, self.robot_y)
                        and not any(i["x"] == x and i["y"] == y for i in self.items)):
                    self.items.append({
                        "x": x, "y": y, "type": item_type,
                        "value": ITEM_VALUES[item_type],
                        "weight": ITEM_WEIGHTS[item_type],
                    })
                    placed += 1

    def _reveal_around(self, cx: int, cy: int, radius: int) -> None:
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                nx, ny = cx + dx, cy + dy
                if 0 <= nx < COLS and 0 <= ny < ROWS:
                    self.revealed.add((nx, ny))
                    # Reveal traps nearby
                    if (nx, ny) in self.traps:
                        self.traps[(nx, ny)] = True

    def _in_bounds(self, x: int, y: int) -> bool:
        return 0 <= x < COLS and 0 <= y < ROWS

    def _is_blocked(self, x: int, y: int) -> bool:
        """Check if a position is blocked (obstacle, locked door, or patrol)."""
        if not self._in_bounds(x, y):
            return True
        if (x, y) in self.obstacles:
            return True
        if (x, y) in self.doors and self.doors[(x, y)] == "locked":
            return True
        for p in self.patrols:
            if p["x"] == x and p["y"] == y:
                return True
        return False

    def _can_move(self, x: int, y: int) -> bool:
        return self._in_bounds(x, y) and not self._is_blocked(x, y)

    def _inventory_weight(self) -> int:
        return sum(i["weight"] for i in self.inventory)

    def _battery_drain(self, x: int, y: int) -> float:
        """Battery drain for moving to position (x, y)."""
        zone = self.zones.get((x, y), "safe")
        if zone == "danger":
            return 2.0
        return 1.0

    def _apply_tile_effects(self, x: int, y: int) -> str:
        """Apply effects when robot steps on a tile. Returns extra message."""
        msgs = []
        # Recharge zone
        zone = self.zones.get((x, y), "safe")
        if zone == "recharge":
            old = self.battery
            self.battery = min(100.0, self.battery + 10.0)
            if self.battery > old:
                msgs.append(f"Recharge zone! Battery +{self.battery - old:.0f}% -> {self.battery:.0f}%")

        # Trap
        if (x, y) in self.traps:
            self.traps[(x, y)] = True  # reveal it
            penalty = self.battery * 0.10
            self.battery = max(0, self.battery - penalty)
            msgs.append(f"TRAP! Battery -{penalty:.0f}% -> {self.battery:.0f}%")

        return " | ".join(msgs)

    def _update_patrols(self) -> None:
        """Move patrol guards along their paths."""
        for p in self.patrols:
            path = p["path"]
            p["idx"] = (p["idx"] + 1) % len(path)
            p["x"], p["y"] = path[p["idx"]]

    def reset(self) -> None:
        self.__init__(seed=SEED)

    def apply_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> str:
        if action == "RESET":
            self.reset()
            return "Simulation reset."
        if self.game_state != "PLAY":
            return "Game is not active."
        params = params or {}

        if action == "move_forward":
            return self._move(1)
        elif action == "move_backward":
            return self._move(-1)
        elif action == "turn_left":
            i = HEADINGS.index(self.heading)
            self.heading = HEADINGS[(i - 1) % 4]
            return f"Turned left, now facing {self.heading}."
        elif action == "turn_right":
            i = HEADINGS.index(self.heading)
            self.heading = HEADINGS[(i + 1) % 4]
            return f"Turned right, now facing {self.heading}."
        elif action == "scan_area":
            self._reveal_around(self.robot_x, self.robot_y, 3)
            self.battery = max(0, self.battery - 1)
            self._update_patrols()
            return "Area scanned (3-tile radius revealed)."
        elif action == "pick_up":
            return self._pick_up()
        elif action == "drop_item":
            return self._drop_item()
        elif action == "report_status":
            return (
                f"Position: ({self.robot_x},{self.robot_y}) heading {self.heading} | "
                f"Battery: {self.battery:.0f}% | Inventory: {[i['type'] for i in self.inventory]} | "
                f"Score: {self.score} | Steps: {self.steps} | "
                f"Carry weight: {self._inventory_weight()}/{MAX_CARRY}"
            )
        elif action == "set_speed":
            spd = int(params.get("speed", self.speed))
            self.speed = max(1, min(5, spd))
            return f"Speed set to {self.speed}."
        elif action == "go_to":
            tx = int(params.get("x", self.robot_x))
            ty = int(params.get("y", self.robot_y))
            return self._go_to(tx, ty)
        elif action == "unlock_door":
            return self._unlock_door(int(params.get("x", -1)), int(params.get("y", -1)))
        elif action == "deposit_items":
            return self._deposit_items()
        elif action == "use_teleporter":
            return self._use_teleporter()
        elif action == "START":
            self.game_state = "PLAY"
            return "Game started."
        elif action == "PAUSE":
            self.game_state = "PAUSE"
            return "Paused."
        elif action == "RESUME":
            self.game_state = "PLAY"
            return "Resumed."
        else:
            return f"Unknown action: {action}"

    def _move(self, direction: int) -> str:
        dx = DX[self.heading] * direction
        dy = DY[self.heading] * direction
        nx, ny = self.robot_x + dx, self.robot_y + dy

        if not self._in_bounds(nx, ny):
            return "Blocked! Out of bounds."
        if (nx, ny) in self.obstacles:
            return "Blocked! Obstacle in the way."
        if (nx, ny) in self.doors and self.doors[(nx, ny)] == "locked":
            return "Blocked! Door is locked. Use unlock_door first."
        for p in self.patrols:
            if p["x"] == nx and p["y"] == ny:
                return "Blocked! Patrol guard in the way. Wait or find another path."

        self.trail.append((self.robot_x, self.robot_y))
        self.robot_x, self.robot_y = nx, ny
        self.steps += 1
        drain = self._battery_drain(nx, ny)
        self.battery = max(0, self.battery - drain)
        self._reveal_around(nx, ny, 1)
        self._update_patrols()

        effects = self._apply_tile_effects(nx, ny)

        if self.battery <= 0:
            self.game_state = "GAMEOVER"
            return "Battery depleted! Game over."

        label = "forward" if direction == 1 else "backward"
        msg = f"Moved {label} to ({nx},{ny})."
        if effects:
            msg += f" {effects}"
        return msg

    def _pick_up(self) -> str:
        for i, item in enumerate(self.items):
            if item["x"] == self.robot_x and item["y"] == self.robot_y:
                if self._inventory_weight() + item["weight"] > MAX_CARRY:
                    return (
                        f"Cannot pick up {item['type']}! "
                        f"Carry weight would exceed limit ({self._inventory_weight()}/{MAX_CARRY}). "
                        f"Deposit items at the depot first."
                    )
                picked = self.items.pop(i)
                self.inventory.append(picked)
                if picked["type"] == "artifact":
                    self.artifacts_collected += 1
                return (
                    f"Picked up {picked['type']} (value={picked['value']}, weight={picked['weight']})! "
                    f"Carry: {self._inventory_weight()}/{MAX_CARRY}"
                )
        return "Nothing to pick up here."

    def _drop_item(self) -> str:
        if not self.inventory:
            return "Inventory is empty."
        item = self.inventory.pop()
        self.items.append({
            "x": self.robot_x, "y": self.robot_y,
            "type": item["type"], "value": item["value"], "weight": item["weight"],
        })
        return f"Dropped {item['type']}."

    def _unlock_door(self, x: int, y: int) -> str:
        if (x, y) not in self.doors:
            return f"No door at ({x},{y})."
        if self.doors[(x, y)] == "unlocked":
            return f"Door at ({x},{y}) is already unlocked."
        # Check adjacency
        dist = abs(x - self.robot_x) + abs(y - self.robot_y)
        if dist > 1:
            return f"Too far from door at ({x},{y}). Must be adjacent (distance={dist})."
        # Check for key in inventory
        key_idx = None
        for i, item in enumerate(self.inventory):
            if item["type"] == "key":
                key_idx = i
                break
        if key_idx is None:
            return "No key in inventory! Find a key first."
        self.inventory.pop(key_idx)
        self.doors[(x, y)] = "unlocked"
        return f"Door at ({x},{y}) unlocked! Key consumed."

    def _deposit_items(self) -> str:
        if self.robot_x != self.depot[0] or self.robot_y != self.depot[1]:
            return (
                f"Not at depot! Depot is at ({self.depot[0]},{self.depot[1]}). "
                f"You are at ({self.robot_x},{self.robot_y})."
            )
        if not self.inventory:
            return "Inventory is empty. Nothing to deposit."
        total_value = 0
        deposited = []
        for item in self.inventory:
            total_value += item["value"]
            deposited.append(item["type"])
        self.score += total_value
        self.deposit_score += total_value
        self.inventory.clear()
        return (
            f"Deposited {len(deposited)} items ({', '.join(deposited)}) "
            f"for {total_value} points! Total score: {self.score}"
        )

    def _use_teleporter(self) -> str:
        pos = (self.robot_x, self.robot_y)
        if pos not in self.teleporters:
            return f"No teleporter at ({pos[0]},{pos[1]})."
        dest = self.teleporters[pos]
        if self._is_blocked(dest[0], dest[1]):
            return f"Teleporter destination ({dest[0]},{dest[1]}) is blocked!"
        self.trail.append((self.robot_x, self.robot_y))
        self.robot_x, self.robot_y = dest
        self.battery = max(0, self.battery - 3)
        self._reveal_around(dest[0], dest[1], 2)
        self._update_patrols()
        effects = self._apply_tile_effects(dest[0], dest[1])
        if self.battery <= 0:
            self.game_state = "GAMEOVER"
            return "Battery depleted during teleport! Game over."
        msg = f"Teleported to ({dest[0]},{dest[1]})! Battery -{3}%."
        if effects:
            msg += f" {effects}"
        return msg

    def _go_to(self, tx: int, ty: int) -> str:
        if not self._in_bounds(tx, ty):
            return f"Target ({tx},{ty}) is out of bounds."
        if self._is_blocked(tx, ty):
            return f"Target ({tx},{ty}) is blocked."
        if self.robot_x == tx and self.robot_y == ty:
            return "Already at target."

        start = (self.robot_x, self.robot_y)
        goal = (tx, ty)
        open_set: list[tuple[float, tuple[int, int]]] = [(0, start)]
        came_from: dict[tuple[int, int], tuple[int, int]] = {}
        g_score: dict[tuple[int, int], float] = {start: 0}

        while open_set:
            _, current = heapq.heappop(open_set)
            if current == goal:
                path: list[tuple[int, int]] = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.reverse()

                move_steps = 0
                for nx, ny in path:
                    if self.battery <= 0:
                        self.game_state = "GAMEOVER"
                        return f"Battery depleted after {move_steps} steps at ({self.robot_x},{self.robot_y})."

                    # Check dynamic blockers
                    blocked = False
                    for p in self.patrols:
                        if p["x"] == nx and p["y"] == ny:
                            blocked = True
                            break
                    if blocked:
                        return (
                            f"Path blocked by patrol at ({nx},{ny}) after {move_steps} steps. "
                            f"Currently at ({self.robot_x},{self.robot_y})."
                        )

                    ddx, ddy = nx - self.robot_x, ny - self.robot_y
                    if ddx > 0:
                        self.heading = "E"
                    elif ddx < 0:
                        self.heading = "W"
                    elif ddy > 0:
                        self.heading = "S"
                    elif ddy < 0:
                        self.heading = "N"

                    self.trail.append((self.robot_x, self.robot_y))
                    self.robot_x, self.robot_y = nx, ny
                    self.steps += 1
                    drain = self._battery_drain(nx, ny)
                    self.battery = max(0, self.battery - drain)
                    self._reveal_around(nx, ny, 1)
                    self._apply_tile_effects(nx, ny)
                    self._update_patrols()
                    move_steps += 1

                if self.battery <= 0:
                    self.game_state = "GAMEOVER"
                    return f"Battery depleted at ({tx},{ty})! Game over."

                return f"Navigated to ({tx},{ty}) in {move_steps} steps. Battery: {self.battery:.0f}%."

            cx, cy = current
            for ddx, ddy in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
                nx, ny = cx + ddx, cy + ddy
                if not (0 <= nx < COLS and 0 <= ny < ROWS):
                    continue
                if (nx, ny) in self.obstacles:
                    continue
                if (nx, ny) in self.doors and self.doors[(nx, ny)] == "locked":
                    continue
                cost = self._battery_drain(nx, ny)
                tentative = g_score[current] + cost
                if tentative < g_score.get((nx, ny), float("inf")):
                    came_from[(nx, ny)] = current
                    g_score[(nx, ny)] = tentative
                    f = tentative + abs(nx - tx) + abs(ny - ty)
                    heapq.heappush(open_set, (f, (nx, ny)))

        return f"No path to ({tx},{ty})."

    def get_objectives(self) -> Dict[str, Any]:
        total_tiles = COLS * ROWS
        explored = len(self.revealed)
        return {
            "primary": {
                "description": "Collect all artifacts",
                "collected": self.artifacts_collected,
                "total": self.total_artifacts,
                "complete": self.artifacts_collected >= self.total_artifacts,
            },
            "secondary": {
                "description": "Maximize score by depositing items at depot",
                "deposit_score": self.deposit_score,
                "total_score": self.score,
            },
            "tertiary": {
                "description": "Explore >80% of the map",
                "explored": explored,
                "total": total_tiles,
                "percent": round(explored / total_tiles * 100, 1),
                "target_percent": 80,
                "complete": explored >= self.exploration_target,
            },
            "constraint": {
                "description": "Don't let battery hit 0",
                "battery": round(self.battery, 1),
                "alive": self.game_state == "PLAY",
            },
        }

    def get_state(self) -> Dict[str, Any]:
        return {
            "robot": {"x": self.robot_x, "y": self.robot_y, "heading": self.heading},
            "battery": round(self.battery, 1),
            "inventory": [{"type": i["type"], "value": i["value"], "weight": i["weight"]} for i in self.inventory],
            "inventory_weight": self._inventory_weight(),
            "max_carry": MAX_CARRY,
            "obstacles": [[x, y] for x, y in sorted(self.obstacles)],
            "items": [{"x": i["x"], "y": i["y"], "type": i["type"], "value": i["value"]} for i in self.items],
            "grid_width": COLS,
            "grid_height": ROWS,
            "revealed": [[x, y] for x, y in sorted(self.revealed)],
            "speed": self.speed,
            "game_state": self.game_state,
            "score": self.score,
            "deposit_score": self.deposit_score,
            "steps_taken": self.steps,
            "message": self.message,
            "items_remaining": len(self.items),
            "zones": {f"{x},{y}": z for (x, y), z in self.zones.items()},
            "doors": {f"{x},{y}": s for (x, y), s in self.doors.items()},
            "teleporters": {f"{x},{y}": [dx, dy] for (x, y), (dx, dy) in self.teleporters.items()},
            "traps": {f"{x},{y}": revealed for (x, y), revealed in self.traps.items() if revealed},
            "depot": [self.depot[0], self.depot[1]],
            "patrols": [{"x": p["x"], "y": p["y"]} for p in self.patrols],
            "objectives": self.get_objectives(),
        }


# ── HTTP Server ───────────────────────────────────────────────

_SIM: Optional[AdvancedRobotSim] = None
_VERSION = 0


def _execute_tool(name: str, state: Dict[str, Any], **kwargs: Any) -> Dict[str, Any]:
    """Execute a server-side tool by name."""
    from .advanced_engine import execute_tool
    return execute_tool(name, state, **kwargs)


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._cors()
        self.end_headers()

    def do_GET(self):
        global _VERSION
        if self.path == "/data":
            _VERSION += 1
            state = _SIM.get_state() if _SIM else {}
            body = json.dumps({
                "command": "ACTIVATE" if state.get("game_state") == "PLAY" else "IDLE",
                "payload": json.dumps(state),
                "version": _VERSION,
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/context":
            state = _SIM.get_state() if _SIM else {}
            r = state.get("robot", {})
            obj = state.get("objectives", {})
            body = json.dumps({
                "position": f"({r.get('x', 0)},{r.get('y', 0)})",
                "heading": r.get("heading", "?"),
                "battery": state.get("battery", 0),
                "score": state.get("score", 0),
                "items_remaining": state.get("items_remaining", 0),
                "objectives": obj,
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length).decode("utf-8", errors="replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {}

        if self.path == "/callback":
            action = data.get("action", "")
            params = {k: v for k, v in data.items() if k != "action"}
            msg = _SIM.apply_action(action, params) if _SIM else "No simulation."
            if _SIM:
                _SIM.message = msg
            resp = json.dumps({"status": "ok", "message": msg}).encode()
        elif self.path == "/command":
            cmd = data.get("command", "")
            msg = ""
            if _SIM and cmd.upper() in ("PAUSE", "RESUME"):
                msg = _SIM.apply_action(cmd.upper())
            resp = json.dumps({"status": "ok", "message": msg}).encode()
        elif self.path == "/tool":
            tool_name = data.get("tool", "")
            tool_args = {k: v for k, v in data.items() if k != "tool"}
            state = _SIM.get_state() if _SIM else {}
            tool_result = _execute_tool(tool_name, state, **tool_args)
            resp = json.dumps({"status": "ok", "tool": tool_name, "result": tool_result}).encode()
        else:
            self.send_error(404)
            return

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self._cors()
        self.end_headers()
        self.wfile.write(resp)


def _start_http(port: int) -> None:
    server = http.server.ThreadingHTTPServer(("0.0.0.0", port), Handler)
    server.serve_forever()


# ── Pygame rendering ──────────────────────────────────────────

def _draw_arrow(surface: pygame.Surface, cx: int, cy: int, heading: str, size: int, color: Tuple[int, ...]) -> None:
    half = size // 2
    if heading == "N":
        pts = [(cx, cy - half), (cx - half, cy + half), (cx + half, cy + half)]
    elif heading == "S":
        pts = [(cx, cy + half), (cx - half, cy - half), (cx + half, cy - half)]
    elif heading == "E":
        pts = [(cx + half, cy), (cx - half, cy - half), (cx - half, cy + half)]
    else:
        pts = [(cx - half, cy), (cx + half, cy - half), (cx + half, cy + half)]
    pygame.draw.polygon(surface, color, pts)
    pygame.draw.polygon(surface, (255, 255, 255), pts, 2)


def _draw_item(surface: pygame.Surface, cx: int, cy: int, item_type: str) -> None:
    r = CELL // 3
    if item_type == "gem":
        pts = [(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)]
        pygame.draw.polygon(surface, C_ITEM_GEM, pts)
    elif item_type == "crystal":
        pts = [(cx, cy - r), (cx + r // 2, cy), (cx, cy + r), (cx - r // 2, cy)]
        pygame.draw.polygon(surface, C_ITEM_CRYSTAL, pts)
    elif item_type == "artifact":
        pygame.draw.circle(surface, C_ITEM_ARTIFACT, (cx, cy), r)
        pygame.draw.circle(surface, (200, 140, 30), (cx, cy), r, 2)
    elif item_type == "key":
        pygame.draw.rect(surface, C_ITEM_KEY, (cx - r // 2, cy - r, r, r * 2))
        pygame.draw.circle(surface, C_ITEM_KEY, (cx, cy - r), r // 2 + 1)


def render(screen: pygame.Surface, sim: AdvancedRobotSim, font: pygame.font.Font) -> None:
    screen.fill(C_BG)

    obstacle_set = sim.obstacles
    revealed_set = sim.revealed

    # Draw grid
    for y in range(ROWS):
        for x in range(COLS):
            rect = pygame.Rect(x * CELL, y * CELL + HUD_H, CELL, CELL)
            if (x, y) not in revealed_set:
                pygame.draw.rect(screen, C_FOG, rect)
            elif (x, y) in obstacle_set:
                pygame.draw.rect(screen, C_WALL, rect)
            elif (x, y) in sim.doors:
                color = C_DOOR_UNLOCKED if sim.doors[(x, y)] == "unlocked" else C_DOOR_LOCKED
                pygame.draw.rect(screen, color, rect)
            elif (x, y) in sim.teleporters:
                pygame.draw.rect(screen, C_TELEPORTER, rect)
            elif (x, y) == sim.depot:
                pygame.draw.rect(screen, C_DEPOT, rect)
            elif (x, y) in sim.traps and sim.traps[(x, y)]:
                pygame.draw.rect(screen, C_TRAP_REVEALED, rect)
            else:
                zone = sim.zones.get((x, y), "safe")
                if zone == "danger":
                    pygame.draw.rect(screen, C_DANGER, rect)
                elif zone == "recharge":
                    pygame.draw.rect(screen, C_RECHARGE, rect)
                else:
                    pygame.draw.rect(screen, C_SAFE if zone == "safe" else C_FLOOR, rect)
            pygame.draw.rect(screen, C_GRID, rect, 1)

    # Draw trail
    for tx, ty in sim.trail[-80:]:
        cx, cy = tx * CELL + CELL // 2, ty * CELL + CELL // 2 + HUD_H
        pygame.draw.circle(screen, C_TRAIL, (cx, cy), 2)

    # Draw items
    for item in sim.items:
        if (item["x"], item["y"]) in revealed_set:
            cx = item["x"] * CELL + CELL // 2
            cy = item["y"] * CELL + CELL // 2 + HUD_H
            _draw_item(screen, cx, cy, item["type"])

    # Draw patrol guards
    for p in sim.patrols:
        if (p["x"], p["y"]) in revealed_set:
            px = p["x"] * CELL + CELL // 2
            py = p["y"] * CELL + CELL // 2 + HUD_H
            pygame.draw.circle(screen, C_PATROL, (px, py), CELL // 3)
            pygame.draw.circle(screen, (255, 100, 100), (px, py), CELL // 3, 2)

    # Draw robot
    rcx = sim.robot_x * CELL + CELL // 2
    rcy = sim.robot_y * CELL + CELL // 2 + HUD_H
    _draw_arrow(screen, rcx, rcy, sim.heading, CELL - 4, C_ROBOT)

    # HUD
    pygame.draw.rect(screen, C_HUD_BG, (0, 0, WIDTH, HUD_H))

    # Battery bar
    bw = 140
    bh = 14
    bx, by = 10, 6
    bat_pct = max(0, sim.battery) / 100
    pygame.draw.rect(screen, (60, 60, 70), (bx, by, bw, bh))
    bar_color = C_BATTERY if sim.battery > 20 else C_BATTERY_LOW
    pygame.draw.rect(screen, bar_color, (bx, by, int(bw * bat_pct), bh))
    pygame.draw.rect(screen, C_HUD_TXT, (bx, by, bw, bh), 1)
    bat_txt = font.render(f"Battery: {sim.battery:.0f}%", True, C_HUD_TXT)
    screen.blit(bat_txt, (bx + bw + 6, by - 1))

    # Score and info line 1
    info1 = font.render(
        f"Score: {sim.score}  |  Deposit: {sim.deposit_score}  |  "
        f"Steps: {sim.steps}  |  Items: {len(sim.items)}  |  "
        f"Inv: {len(sim.inventory)} ({sim._inventory_weight()}/{MAX_CARRY})",
        True, C_HUD_TXT,
    )
    screen.blit(info1, (10, 24))

    # Info line 2
    obj = sim.get_objectives()
    explored_pct = obj["tertiary"]["percent"]
    info2 = font.render(
        f"Pos: ({sim.robot_x},{sim.robot_y}) {sim.heading}  |  "
        f"Artifacts: {obj['primary']['collected']}/{obj['primary']['total']}  |  "
        f"Explored: {explored_pct}%  |  "
        f"Speed: {sim.speed}  |  Depot: ({sim.depot[0]},{sim.depot[1]})",
        True, C_HUD_TXT,
    )
    screen.blit(info2, (10, 42))

    # Message bar
    msg = font.render(sim.message[:120], True, (180, 180, 190))
    screen.blit(msg, (10, 60))


# ── Main ──────────────────────────────────────────────────────

def main() -> None:
    global _SIM

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT + 20))
    pygame.display.set_caption("OmniLink Advanced Robot Demo")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("consolas", 12)

    _SIM = AdvancedRobotSim(seed=SEED)

    http_thread = threading.Thread(target=_start_http, args=(PORT,), daemon=True)
    http_thread.start()
    print(f"[advanced-sim] HTTP server on http://127.0.0.1:{PORT}")
    print(f"[advanced-sim] Grid: {COLS}x{ROWS}, obstacles: {len(_SIM.obstacles)}, items: {len(_SIM.items)}")
    print(f"[advanced-sim] Doors: {len(_SIM.doors)}, teleporters: {len(_SIM.teleporters)}, "
          f"traps: {len(_SIM.traps)}, patrols: {len(_SIM.patrols)}")
    print(f"[advanced-sim] Depot at ({_SIM.depot[0]},{_SIM.depot[1]})")

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        render(screen, _SIM, font)
        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
