"""HTTP client for the Advanced Robot Demo simulation server (port 5051)."""

from __future__ import annotations

import json
import time
from typing import Any

import requests

SERVER_URL = "http://127.0.0.1:5051"

_session = requests.Session()


def get_state() -> dict[str, Any]:
    """Fetch the current simulation state from the server."""
    r = _session.get(f"{SERVER_URL}/data", timeout=5)
    data = r.json()
    payload = data.get("payload", "{}")
    if isinstance(payload, str):
        return json.loads(payload)
    return payload


def send_action(action: str, **params: Any) -> str:
    """Send an action to the simulation. Returns the result message."""
    body: dict[str, Any] = {"action": action}
    body.update(params)
    for attempt in range(3):
        try:
            r = _session.post(f"{SERVER_URL}/callback", json=body, timeout=5)
            return r.json().get("message", "")
        except Exception:
            if attempt == 2:
                raise
            time.sleep(0.5)


def call_tool(tool_name: str, **kwargs: Any) -> dict[str, Any]:
    """Execute a tool on the sim server. Returns the tool result dict."""
    body: dict[str, Any] = {"tool": tool_name}
    body.update(kwargs)
    r = _session.post(f"{SERVER_URL}/tool", json=body, timeout=5)
    data = r.json()
    return data.get("result", data)
