"""Advanced Robot tools -- 22 DefaultTool subclasses for the advanced grid-world.

16 original tools adapted for the advanced sim (port 5051) plus 6 new tools:
  unlock_door, deposit_items, check_zone, get_objectives, use_teleporter,
  get_inventory_weight.

The tools call the robot sim server at http://127.0.0.1:5051.
"""

from __future__ import annotations

import time
from typing import Any

from omnilink.default_tools import DefaultTool

from .advanced_api import get_state, send_action, call_tool


# ── Movement tools ───────────────────────────────────────────────────

class MoveForwardTool(DefaultTool):
    name = "move_forward"
    description = "Move the robot one tile forward in its current heading direction. Costs 1 battery (2 in danger zone)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        msg = send_action("move_forward")
        state = get_state()
        r = state.get("robot", {})
        return {
            "status": "moved",
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
            "message": msg,
        }


class MoveBackwardTool(DefaultTool):
    name = "move_backward"
    description = "Move the robot one tile backward (opposite of heading)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        msg = send_action("move_backward")
        state = get_state()
        r = state.get("robot", {})
        return {
            "status": "moved",
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
            "message": msg,
        }


class TurnLeftTool(DefaultTool):
    name = "turn_left"
    description = "Rotate the robot 90 degrees to the left."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        msg = send_action("turn_left")
        state = get_state()
        return {
            "status": "turned",
            "heading": state.get("robot", {}).get("heading"),
            "message": msg,
        }


class TurnRightTool(DefaultTool):
    name = "turn_right"
    description = "Rotate the robot 90 degrees to the right."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        msg = send_action("turn_right")
        state = get_state()
        return {
            "status": "turned",
            "heading": state.get("robot", {}).get("heading"),
            "message": msg,
        }


class GoToTool(DefaultTool):
    name = "go_to"
    description = (
        "Navigate the robot to a specific grid position using A* pathfinding. "
        "Moves the robot along the full path in one call. Avoids obstacles, "
        "locked doors, and prefers safe zones over danger zones. "
        "Args: x (required), y (required)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Target x coordinate."},
            "y": {"type": "integer", "description": "Target y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        x = kwargs.get("x")
        y = kwargs.get("y")
        if x is None or y is None:
            return {"error": "Missing required arguments: x and y"}
        time.sleep(1.0)
        msg = send_action("go_to", x=int(x), y=int(y))
        state = get_state()
        r = state.get("robot", {})
        return {
            "status": "navigating",
            "target": {"x": int(x), "y": int(y)},
            "position": {"x": r.get("x"), "y": r.get("y")},
            "battery": state.get("battery"),
            "message": msg,
        }


# ── Action tools ─────────────────────────────────────────────────────

class ScanAreaTool(DefaultTool):
    name = "scan_area"
    description = "Scan the area around the robot to reveal hidden tiles, items, traps, and teleporters (3-tile radius)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        msg = send_action("scan_area")
        state = get_state()
        r = state.get("robot", {})
        rx, ry = r.get("x", 0), r.get("y", 0)
        items = state.get("items", [])
        nearby = [i for i in items if abs(i["x"] - rx) <= 3 and abs(i["y"] - ry) <= 3]
        return {
            "status": "scanned",
            "revealed_tiles": len(state.get("revealed", [])),
            "nearby_items": nearby,
            "message": msg,
        }


class PickUpTool(DefaultTool):
    name = "pick_up"
    description = (
        "Pick up an item at the robot's current position. "
        "Robot can carry max 5 weight units. Items have weight: gem=1, crystal=1, artifact=2, key=1."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        msg = send_action("pick_up")
        state = get_state()
        return {
            "status": "picked_up" if "Picked" in msg else "failed",
            "inventory": state.get("inventory", []),
            "inventory_weight": state.get("inventory_weight", 0),
            "max_carry": state.get("max_carry", 5),
            "score": state.get("score"),
            "message": msg,
        }


class DropItemTool(DefaultTool):
    name = "drop_item"
    description = "Drop the last item in the robot's inventory at the current position."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        msg = send_action("drop_item")
        state = get_state()
        return {
            "status": "dropped",
            "inventory": state.get("inventory", []),
            "message": msg,
        }


class SetSpeedTool(DefaultTool):
    name = "set_speed"
    description = "Set the robot's movement speed. Args: speed (required, 1-5)."
    parameters_schema = {
        "type": "object",
        "properties": {
            "speed": {"type": "integer", "description": "Movement speed (1-5)."},
        },
        "required": ["speed"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        speed = kwargs.get("speed")
        if speed is None:
            return {"error": "Missing required argument: speed"}
        msg = send_action("set_speed", speed=int(speed))
        return {"status": "speed_set", "speed": int(speed), "message": msg}


# ── Query tools ──────────────────────────────────────────────────────

class GetStatusTool(DefaultTool):
    name = "get_status"
    description = (
        "Get the robot's full status: position, heading, battery, "
        "inventory (with weight), score, objectives, and items remaining."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.3)
        state = get_state()
        r = state.get("robot", {})
        return {
            "position": {"x": r.get("x"), "y": r.get("y")},
            "heading": r.get("heading"),
            "battery": state.get("battery"),
            "inventory": state.get("inventory", []),
            "inventory_weight": state.get("inventory_weight", 0),
            "max_carry": state.get("max_carry", 5),
            "score": state.get("score"),
            "deposit_score": state.get("deposit_score", 0),
            "steps_taken": state.get("steps_taken"),
            "items_remaining": state.get("items_remaining"),
            "game_state": state.get("game_state"),
            "depot": state.get("depot"),
            "objectives": state.get("objectives", {}),
        }


class GetItemsTool(DefaultTool):
    name = "get_items"
    description = "Get positions and types of visible items near the robot (within 5 tiles)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        r = state.get("robot", {})
        rx, ry = r.get("x", 0), r.get("y", 0)
        items = state.get("items", [])
        nearby = [i for i in items if abs(i["x"] - rx) <= 5 and abs(i["y"] - ry) <= 5]
        return {"items": nearby, "count": len(nearby)}


class GetObstaclesTool(DefaultTool):
    name = "get_obstacles"
    description = "Get positions of obstacles near the robot (within 5 tiles)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        r = state.get("robot", {})
        rx, ry = r.get("x", 0), r.get("y", 0)
        obstacles = state.get("obstacles", [])
        nearby = [o for o in obstacles if abs(o[0] - rx) <= 5 and abs(o[1] - ry) <= 5]
        return {"obstacles": nearby, "count": len(nearby)}


class CheckCollisionTool(DefaultTool):
    name = "check_collision"
    description = "Check if moving forward is safe (no wall, obstacle, locked door, or patrol guard ahead)."
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            result = call_tool("check_collision")
            return result
        except Exception:
            state = get_state()
            from .advanced_engine import check_collision
            return check_collision(state)


class FindPathTool(DefaultTool):
    name = "find_path"
    description = (
        "Find the shortest path to a position using A* pathfinding. "
        "Respects obstacles, locked doors, and zone costs (danger=2x). "
        "Args: x (required), y (required)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Target x coordinate."},
            "y": {"type": "integer", "description": "Target y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            x = self.get_arg(kwargs, "x", required=True, type_=int)
            y = self.get_arg(kwargs, "y", required=True, type_=int)
        except ValueError as exc:
            return {"error": str(exc)}
        time.sleep(0.5)
        try:
            result = call_tool("find_path", target_x=x, target_y=y)
            return result
        except Exception:
            state = get_state()
            from .advanced_engine import find_path
            return find_path(state, x, y)


class GetMapInfoTool(DefaultTool):
    name = "get_map_info"
    description = (
        "Get map dimensions, obstacle count, item count, explored area, "
        "door count, teleporter count, trap count, patrol count, and depot location."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        return {
            "width": state.get("grid_width"),
            "height": state.get("grid_height"),
            "obstacle_count": len(state.get("obstacles", [])),
            "item_count": len(state.get("items", [])),
            "revealed_tiles": len(state.get("revealed", [])),
            "items_remaining": state.get("items_remaining"),
            "doors": state.get("doors", {}),
            "teleporters": {k: v for k, v in state.get("teleporters", {}).items()},
            "depot": state.get("depot"),
        }


class AnalyzeSurroundingsTool(DefaultTool):
    name = "analyze_surroundings"
    description = (
        "Check what is in each adjacent tile (N/S/E/W), the current tile, "
        "and the current zone type (safe/danger/recharge)."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        try:
            result = call_tool("analyze_surroundings")
            return result
        except Exception:
            state = get_state()
            from .advanced_engine import analyze_surroundings
            return analyze_surroundings(state)


# ── Compound tools ──────────────────────────────────────────────────

class CollectItemTool(DefaultTool):
    name = "collect_item"
    description = (
        "Navigate to a position and pick up the item there in one step. "
        "Combines go_to + pick_up. Checks carry weight before pickup. "
        "Args: x (required), y (required)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Target x coordinate."},
            "y": {"type": "integer", "description": "Target y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        x = kwargs.get("x")
        y = kwargs.get("y")
        if x is None or y is None:
            return {"error": "Missing required arguments: x and y"}
        x, y = int(x), int(y)

        time.sleep(1.0)
        nav_msg = send_action("go_to", x=x, y=y)
        state = get_state()
        r = state.get("robot", {})
        arrived = r.get("x") == x and r.get("y") == y

        pickup_msg = ""
        if arrived:
            time.sleep(0.3)
            pickup_msg = send_action("pick_up")
            state = get_state()

        return {
            "status": "collected" if "Picked" in pickup_msg else (
                "arrived_nothing_here" if arrived else "navigation_failed"
            ),
            "position": {"x": r.get("x"), "y": r.get("y")},
            "battery": state.get("battery"),
            "inventory": state.get("inventory", []),
            "inventory_weight": state.get("inventory_weight", 0),
            "score": state.get("score"),
            "items_remaining": state.get("items_remaining"),
            "message": f"Navigation: {nav_msg}" + (
                f" | Pickup: {pickup_msg}" if pickup_msg else ""
            ),
        }


class ScanAndListTool(DefaultTool):
    name = "scan_and_list"
    description = (
        "Scan the area to reveal tiles, then return all visible items with "
        "positions, types, and values. Combines scan_area + get_items."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        send_action("scan_area")
        state = get_state()
        r = state.get("robot", {})
        rx, ry = r.get("x", 0), r.get("y", 0)
        items = state.get("items", [])
        nearby = [i for i in items if abs(i["x"] - rx) <= 5 and abs(i["y"] - ry) <= 5]
        nearby.sort(key=lambda i: abs(i["x"] - rx) + abs(i["y"] - ry))

        return {
            "status": "scanned",
            "position": {"x": rx, "y": ry},
            "battery": state.get("battery"),
            "revealed_tiles": len(state.get("revealed", [])),
            "visible_items": nearby,
            "item_count": len(nearby),
            "items_remaining": state.get("items_remaining"),
        }


# ── NEW: 6 Advanced tools ───────────────────────────────────────────

class UnlockDoorTool(DefaultTool):
    name = "unlock_door"
    description = (
        "Use a key from inventory to unlock a locked door. "
        "Robot must be adjacent to the door. Consumes one key. "
        "Args: x (required), y (required) -- the door position."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Door x coordinate."},
            "y": {"type": "integer", "description": "Door y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        x = kwargs.get("x")
        y = kwargs.get("y")
        if x is None or y is None:
            return {"error": "Missing required arguments: x and y"}
        time.sleep(0.5)
        msg = send_action("unlock_door", x=int(x), y=int(y))
        state = get_state()
        return {
            "status": "unlocked" if "unlocked" in msg.lower() else "failed",
            "inventory": state.get("inventory", []),
            "doors": state.get("doors", {}),
            "message": msg,
        }


class DepositItemsTool(DefaultTool):
    name = "deposit_items"
    description = (
        "Deposit all inventory items at the depot for score points. "
        "Robot must be standing on the depot tile. "
        "Item values: gem=10, crystal=25, artifact=50, key=0."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        msg = send_action("deposit_items")
        state = get_state()
        return {
            "status": "deposited" if "Deposited" in msg else "failed",
            "score": state.get("score"),
            "deposit_score": state.get("deposit_score", 0),
            "inventory": state.get("inventory", []),
            "inventory_weight": state.get("inventory_weight", 0),
            "depot": state.get("depot"),
            "message": msg,
        }


class CheckZoneTool(DefaultTool):
    name = "check_zone"
    description = (
        "Check what zone a tile is in: safe, danger (2x battery drain), "
        "or recharge (restores battery). Also reports doors, teleporters, traps. "
        "Args: x (required), y (required)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Tile x coordinate."},
            "y": {"type": "integer", "description": "Tile y coordinate."},
        },
        "required": ["x", "y"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        x = kwargs.get("x")
        y = kwargs.get("y")
        if x is None or y is None:
            return {"error": "Missing required arguments: x and y"}
        try:
            result = call_tool("check_zone", x=int(x), y=int(y))
            return result
        except Exception:
            state = get_state()
            from .advanced_engine import check_zone
            return check_zone(state, int(x), int(y))


class GetObjectivesTool(DefaultTool):
    name = "get_objectives"
    description = (
        "Check current objective progress: "
        "primary (collect all artifacts), secondary (maximize deposit score), "
        "tertiary (explore >80% of map), and constraint (battery > 0)."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        return state.get("objectives", {})


class UseTeleporterTool(DefaultTool):
    name = "use_teleporter"
    description = (
        "Activate a teleporter at the robot's current position. "
        "Instantly moves the robot to the linked teleporter destination. "
        "Costs 3 battery. Robot must be standing on a teleporter tile."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(0.5)
        msg = send_action("use_teleporter")
        state = get_state()
        r = state.get("robot", {})
        return {
            "status": "teleported" if "Teleported" in msg else "failed",
            "position": {"x": r.get("x"), "y": r.get("y")},
            "battery": state.get("battery"),
            "message": msg,
        }


class GetInventoryWeightTool(DefaultTool):
    name = "get_inventory_weight"
    description = (
        "Check current carry weight and remaining capacity. "
        "Max carry is 5 weight units. Weights: gem=1, crystal=1, artifact=2, key=1."
    )
    parameters_schema = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        return {
            "inventory": state.get("inventory", []),
            "current_weight": state.get("inventory_weight", 0),
            "max_carry": state.get("max_carry", 5),
            "remaining_capacity": state.get("max_carry", 5) - state.get("inventory_weight", 0),
        }


# ── All tools list ───────────────────────────────────────────────────

ALL_ADVANCED_TOOLS = [
    # Compound (preferred)
    CollectItemTool(),
    ScanAndListTool(),
    # Movement
    MoveForwardTool(),
    MoveBackwardTool(),
    TurnLeftTool(),
    TurnRightTool(),
    GoToTool(),
    # Actions
    ScanAreaTool(),
    PickUpTool(),
    DropItemTool(),
    SetSpeedTool(),
    # NEW advanced actions
    UnlockDoorTool(),
    DepositItemsTool(),
    UseTeleporterTool(),
    # Queries
    GetStatusTool(),
    GetItemsTool(),
    GetObstaclesTool(),
    CheckCollisionTool(),
    FindPathTool(),
    GetMapInfoTool(),
    AnalyzeSurroundingsTool(),
    # NEW advanced queries
    CheckZoneTool(),
    GetObjectivesTool(),
    GetInventoryWeightTool(),
]
