"""Advanced Robot Demo -- unified tool-based architecture (22 tools).

A harder version of the robot demo with zones, doors, teleporters,
patrol guards, traps, multi-objective scoring, and inventory weight.

Start the simulation first:
    python -m omnilink.examples.robot_demo_advanced.advanced_sim

Then run this demo:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo_advanced.run_advanced_demo

Then open https://www.omnilink-agents.com/build and control the robot.
Press Ctrl+C to stop.
"""

from __future__ import annotations

import os
import pathlib
import signal
import sys
import threading
from typing import Any

LIB_PATH = pathlib.Path(__file__).resolve().parents[4] / "src"
if str(LIB_PATH) not in sys.path:
    sys.path.insert(0, str(LIB_PATH))

from omnilink.tool_runner import ToolRunner
from omnilink.client import OmniLinkClient

from .advanced_tools import ALL_ADVANCED_TOOLS
from .advanced_api import get_state, SERVER_URL

# ── Configuration ────────────────────────────────────────────────────

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get(
    "OMNILINK_BASE_URL", "https://www.omnilink-agents.com"
)


# ── Runner ───────────────────────────────────────────────────────────


class AdvancedRobotToolsRunner(ToolRunner):
    """Advanced robot controller using the unified tool architecture."""

    agent_name = "robot-demo-advanced"
    display_name = "Advanced Robot Demo"
    engine = "g3-engine"
    tool_name = "control_advanced_robot"
    tool_description = "Control the advanced robot using 22 tools across a challenging 40x30 grid world."
    commands = "stop_game, pause_game, resume_game"
    game_server_url = SERVER_URL

    default_tools = ALL_ADVANCED_TOOLS

    def get_profile_settings(self) -> dict[str, Any]:
        settings = super().get_profile_settings()
        settings["mainTask"] = (
            "You control a mobile robot on a 40x30 grid world with advanced mechanics. "
            "The world has safe zones, danger zones (2x battery drain), and recharge zones. "
            "There are locked doors (need keys), teleporters, hidden traps, and patrol guards. "
            "Use the available tools to complete multi-objective missions.\n\n"
            "OBJECTIVES:\n"
            "1. PRIMARY: Collect all 3 artifacts (value=50 each)\n"
            "2. SECONDARY: Deposit items at the depot to maximize score\n"
            "3. TERTIARY: Explore >80% of the map\n"
            "4. CONSTRAINT: Don't let battery reach 0\n\n"
            "KEY MECHANICS:\n"
            "- Inventory has weight limit of 5. Gem=1, Crystal=1, Artifact=2, Key=1\n"
            "- Keys unlock doors. Doors block pathfinding until unlocked.\n"
            "- Teleporters instantly move you across the map (costs 3 battery)\n"
            "- Danger zones drain 2x battery per step\n"
            "- Recharge zones restore 10% battery when you step on them\n"
            "- Traps are hidden until revealed by scanning; they drain 10% battery\n"
            "- Patrol guards move along paths and block your movement\n"
            "- Deposit items at the depot to convert inventory into score\n\n"
            "STRATEGY RULES:\n"
            "1. ALWAYS call pick_up immediately after go_to if there is an item at the destination.\n"
            "2. Prefer action tools (go_to, collect_item, scan_and_list) over query tools.\n"
            "3. Plan routes to minimize danger zone traversal.\n"
            "4. Collect keys BEFORE approaching locked doors.\n"
            "5. Use teleporters to save battery on long trips.\n"
            "6. Deposit items at the depot regularly to lock in score.\n"
            "7. Monitor battery carefully -- head to a recharge zone if below 25%.\n"
            "8. Use scan_area to reveal traps before entering unknown areas.\n"
            "9. Check patrol guard positions before planning routes through their area.\n"
            "10. Prioritize artifacts (50pts) > crystals (25pts) > gems (10pts)."
        )
        settings["maxToolRounds"] = 25
        return settings

    def get_state(self) -> dict[str, Any]:
        return {}

    def execute_action(self, state: dict[str, Any]) -> None:
        pass

    def state_summary(self, state: dict[str, Any]) -> str:
        return "idle"

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return True


# ── Entry point ──────────────────────────────────────────────────────


def _start_headless_sim(port: int = 5051) -> None:
    """Start the advanced robot sim headless if not already running."""
    import os as _os
    _os.environ["SDL_VIDEODRIVER"] = "dummy"
    _os.environ["SDL_AUDIODRIVER"] = "dummy"

    from . import advanced_sim as sim_mod
    from .advanced_sim import AdvancedRobotSim, Handler, SEED
    import http.server as _hs

    sim = AdvancedRobotSim(seed=SEED)
    sim_mod._SIM = sim
    server = _hs.ThreadingHTTPServer(("0.0.0.0", port), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()


def main() -> None:
    if not OMNI_KEY:
        print("Set OMNI_KEY before running:  export OMNI_KEY=omk_...")
        sys.exit(1)

    # Connect to running sim, or start headless.
    import time as _time
    try:
        state = get_state()
        r = state["robot"]
        print(f"Sim connected: robot at ({r['x']},{r['y']}) facing {r['heading']}, battery={state['battery']}%")
    except Exception:
        print("No sim running -- starting headless sim on port 5051...")
        _start_headless_sim()
        _time.sleep(0.5)
        state = get_state()
        r = state["robot"]
        print(f"Headless sim started: robot at ({r['x']},{r['y']}) facing {r['heading']}, battery={state['battery']}%")

    runner = AdvancedRobotToolsRunner()
    runner.omni_key = OMNI_KEY
    runner.base_url = BASE_URL

    client = OmniLinkClient(omni_key=OMNI_KEY, base_url=BASE_URL, timeout=60)
    runner._client = client
    runner._conversation_history = []
    runner._activity_log = []

    port = runner._start_tool_server()
    runner.tool_callback_url = f"http://127.0.0.1:{port}/tool"

    runner._ensure_profile(client)

    try:
        client.set_memory(runner._memory_agent_key(), [])
    except Exception:
        pass

    print()
    print("=" * 70)
    print("  Advanced Robot Demo -- 22 Tools, Multi-Objective")
    print("=" * 70)
    print()
    print(f"  Tool server:  http://127.0.0.1:{port}/tool")
    print(f"  Activity log: http://127.0.0.1:{port}/activity")
    print(f"  Robot sim:    {SERVER_URL}")
    print()
    print(f"  Open the UI:  {BASE_URL}/build")
    print()
    print("  22 tools (compound + actions + queries + advanced):")
    print("    collect_item, scan_and_list,                          (compound)")
    print("    move_forward, move_backward, turn_left, turn_right,")
    print("    go_to, scan_area, pick_up, drop_item, set_speed,")
    print("    unlock_door, deposit_items, use_teleporter,           (NEW)")
    print("    get_status, get_items, get_obstacles, check_collision,")
    print("    find_path, get_map_info, analyze_surroundings,")
    print("    check_zone, get_objectives, get_inventory_weight      (NEW)")
    print()
    print("  World features:")
    print("    Grid: 40x30  |  Zones: safe/danger/recharge")
    print("    Doors (need keys)  |  Teleporters  |  Traps  |  Patrol guards")
    print("    Depot for item deposit  |  Weight-limited inventory (max 5)")
    print()
    print("  Objectives:")
    print("    1. Collect all 3 artifacts")
    print("    2. Maximize deposit score")
    print("    3. Explore >80% of map")
    print("    4. Keep battery > 0")
    print()
    print("  Try:")
    print('    "Find a key, unlock the nearest door, and collect the artifact behind it"')
    print('    "Navigate through the danger zone to reach the recharge station"')
    print('    "Collect all items, deposit them at the depot, maximize your score"')
    print('    "Explore the entire map, avoid traps, and report all teleporter locations"')
    print('    "Plan an optimal route to collect all 3 artifacts and return to depot"')
    print()
    print("  Make sure advanced_sim is running:")
    print("    python -m omnilink.examples.robot_demo_advanced.advanced_sim")
    print()
    print("  Press Ctrl+C to stop.")
    print("=" * 70)
    print()

    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    try:
        signal.signal(signal.SIGBREAK, lambda *_: stop.set())
    except AttributeError:
        pass

    stop.wait()

    print()
    print("  Shutting down.")


if __name__ == "__main__":
    main()
