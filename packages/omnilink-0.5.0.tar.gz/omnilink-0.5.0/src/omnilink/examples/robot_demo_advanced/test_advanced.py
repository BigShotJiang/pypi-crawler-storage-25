#!/usr/bin/env python3
"""Test script for the Advanced Robot Demo.

Verifies the simulation logic, tools, and provides hard agent prompts.

Run with:
    python -m omnilink.examples.robot_demo_advanced.test_advanced

Or run the advanced sim first, then:
    python -m pytest omnilink/examples/robot_demo_advanced/test_advanced.py -v
"""

from __future__ import annotations

import json
import sys
import pathlib

# Ensure library is importable
LIB_PATH = pathlib.Path(__file__).resolve().parents[4] / "src"
if str(LIB_PATH) not in sys.path:
    sys.path.insert(0, str(LIB_PATH))

from .advanced_sim import (
    AdvancedRobotSim, COLS, ROWS, SEED, MAX_CARRY,
    ITEM_VALUES, ITEM_WEIGHTS,
)
from .advanced_engine import (
    find_path, check_collision, analyze_surroundings,
    check_zone, get_objectives, get_map_info, execute_tool,
)


# ── Simulation unit tests ───────────────────────────────────────────


def test_deterministic_seed():
    """Two sims with same seed produce identical worlds."""
    sim1 = AdvancedRobotSim(seed=SEED)
    sim2 = AdvancedRobotSim(seed=SEED)
    assert sim1.obstacles == sim2.obstacles, "Obstacles differ"
    assert len(sim1.items) == len(sim2.items), "Item count differs"
    for a, b in zip(sim1.items, sim2.items):
        assert a["x"] == b["x"] and a["y"] == b["y"] and a["type"] == b["type"], "Item mismatch"
    assert sim1.doors == sim2.doors, "Doors differ"
    assert sim1.teleporters == sim2.teleporters, "Teleporters differ"
    assert sim1.traps == sim2.traps, "Traps differ"
    print("  [PASS] Deterministic seed")


def test_grid_dimensions():
    """Grid is 40x30."""
    assert COLS == 40 and ROWS == 30, f"Expected 40x30, got {COLS}x{ROWS}"
    print("  [PASS] Grid dimensions 40x30")


def test_obstacle_count():
    """Approximately 25% obstacle coverage."""
    sim = AdvancedRobotSim(seed=SEED)
    total = COLS * ROWS
    pct = len(sim.obstacles) / total * 100
    assert 20 <= pct <= 30, f"Obstacle coverage {pct:.1f}% outside 20-30% range"
    print(f"  [PASS] Obstacle count: {len(sim.obstacles)} ({pct:.1f}%)")


def test_items_placed():
    """Correct number and types of items."""
    sim = AdvancedRobotSim(seed=SEED)
    types = {}
    for item in sim.items:
        types[item["type"]] = types.get(item["type"], 0) + 1
    assert types.get("artifact", 0) == 3, f"Expected 3 artifacts, got {types.get('artifact', 0)}"
    assert types.get("key", 0) == 6, f"Expected 6 keys, got {types.get('key', 0)}"
    assert types.get("gem", 0) == 10, f"Expected 10 gems, got {types.get('gem', 0)}"
    assert types.get("crystal", 0) == 5, f"Expected 5 crystals, got {types.get('crystal', 0)}"
    print(f"  [PASS] Items: {types}")


def test_zones_exist():
    """Danger and recharge zones are present."""
    sim = AdvancedRobotSim(seed=SEED)
    danger_count = sum(1 for v in sim.zones.values() if v == "danger")
    recharge_count = sum(1 for v in sim.zones.values() if v == "recharge")
    assert danger_count > 0, "No danger zones"
    assert recharge_count > 0, "No recharge zones"
    print(f"  [PASS] Zones: {danger_count} danger, {recharge_count} recharge")


def test_doors():
    """Doors exist and start locked."""
    sim = AdvancedRobotSim(seed=SEED)
    assert len(sim.doors) == 6, f"Expected 6 doors, got {len(sim.doors)}"
    for pos, status in sim.doors.items():
        assert status == "locked", f"Door at {pos} should be locked, got {status}"
    print(f"  [PASS] {len(sim.doors)} doors, all locked")


def test_teleporters():
    """Teleporters exist in pairs."""
    sim = AdvancedRobotSim(seed=SEED)
    assert len(sim.teleporters) == 6, f"Expected 6 teleporter endpoints, got {len(sim.teleporters)}"
    for src, dest in sim.teleporters.items():
        assert dest in sim.teleporters, f"Teleporter {src}->{dest} has no return"
        assert sim.teleporters[dest] == src, f"Teleporter pair mismatch: {src}<->{dest}"
    print(f"  [PASS] {len(sim.teleporters)} teleporter endpoints (3 pairs)")


def test_traps():
    """Traps exist and start hidden."""
    sim = AdvancedRobotSim(seed=SEED)
    assert len(sim.traps) == 15, f"Expected 15 traps, got {len(sim.traps)}"
    for pos, revealed in sim.traps.items():
        assert not revealed, f"Trap at {pos} should be hidden"
    print(f"  [PASS] {len(sim.traps)} traps, all hidden")


def test_patrols():
    """Patrol guards exist."""
    sim = AdvancedRobotSim(seed=SEED)
    assert len(sim.patrols) == 4, f"Expected 4 patrols, got {len(sim.patrols)}"
    for p in sim.patrols:
        assert len(p["path"]) >= 2, "Patrol path too short"
    print(f"  [PASS] {len(sim.patrols)} patrol guards")


def test_movement_and_battery():
    """Moving drains battery, danger zone drains 2x."""
    sim = AdvancedRobotSim(seed=SEED)
    initial_battery = sim.battery

    # Move in safe zone (robot starts at 1,1 which is safe)
    msg = sim.apply_action("move_forward")
    assert "Moved" in msg or "Blocked" in msg
    if "Moved" in msg:
        assert sim.battery == initial_battery - 1, "Safe zone should drain 1 battery"
    print(f"  [PASS] Movement and battery drain")


def test_pick_up_weight_limit():
    """Cannot exceed carry weight."""
    sim = AdvancedRobotSim(seed=SEED)
    # Manually fill inventory to weight limit
    for _ in range(5):
        sim.inventory.append({"type": "gem", "value": 10, "weight": 1})

    # Place an item at robot position
    sim.items.append({"x": sim.robot_x, "y": sim.robot_y, "type": "gem", "value": 10, "weight": 1})
    msg = sim.apply_action("pick_up")
    assert "Cannot pick up" in msg, f"Should fail with weight limit, got: {msg}"
    print(f"  [PASS] Weight limit enforced")


def test_unlock_door():
    """Unlocking door requires key and adjacency."""
    sim = AdvancedRobotSim(seed=SEED)

    # Try unlock without key
    door_pos = list(sim.doors.keys())[0]
    sim.robot_x, sim.robot_y = door_pos[0] - 1, door_pos[1]
    msg = sim.apply_action("unlock_door", {"x": door_pos[0], "y": door_pos[1]})
    assert "No key" in msg, f"Should fail without key, got: {msg}"

    # Give robot a key and try again
    sim.inventory.append({"type": "key", "value": 0, "weight": 1})
    msg = sim.apply_action("unlock_door", {"x": door_pos[0], "y": door_pos[1]})
    assert "unlocked" in msg.lower(), f"Should unlock, got: {msg}"
    assert sim.doors[door_pos] == "unlocked"
    assert len(sim.inventory) == 0, "Key should be consumed"
    print(f"  [PASS] Door unlock mechanics")


def test_deposit_items():
    """Depositing items at depot adds score."""
    sim = AdvancedRobotSim(seed=SEED)
    sim.robot_x, sim.robot_y = sim.depot

    # Add items to inventory
    sim.inventory.append({"type": "gem", "value": 10, "weight": 1})
    sim.inventory.append({"type": "crystal", "value": 25, "weight": 1})
    sim.inventory.append({"type": "artifact", "value": 50, "weight": 2})

    msg = sim.apply_action("deposit_items")
    assert "Deposited" in msg
    assert sim.score == 85, f"Expected score 85, got {sim.score}"
    assert sim.deposit_score == 85
    assert len(sim.inventory) == 0
    print(f"  [PASS] Deposit items at depot")


def test_teleporter():
    """Teleporter moves robot to destination."""
    sim = AdvancedRobotSim(seed=SEED)
    tp_src = list(sim.teleporters.keys())[0]
    tp_dest = sim.teleporters[tp_src]

    sim.robot_x, sim.robot_y = tp_src
    msg = sim.apply_action("use_teleporter")
    assert "Teleported" in msg
    assert sim.robot_x == tp_dest[0] and sim.robot_y == tp_dest[1]
    print(f"  [PASS] Teleporter: {tp_src} -> ({sim.robot_x},{sim.robot_y})")


def test_trap_damage():
    """Stepping on a trap drains 10% battery."""
    sim = AdvancedRobotSim(seed=SEED)
    trap_pos = list(sim.traps.keys())[0]
    sim.battery = 80.0

    # Manually trigger trap effect
    sim.robot_x, sim.robot_y = trap_pos
    effects = sim._apply_tile_effects(trap_pos[0], trap_pos[1])
    assert "TRAP" in effects
    assert sim.battery == 72.0, f"Expected 72.0, got {sim.battery}"
    assert sim.traps[trap_pos] is True, "Trap should be revealed"
    print(f"  [PASS] Trap damage: 80 -> {sim.battery}")


def test_recharge_zone():
    """Stepping in recharge zone restores battery."""
    sim = AdvancedRobotSim(seed=SEED)
    sim.battery = 50.0

    # Find a recharge tile
    recharge_pos = None
    for pos, zone in sim.zones.items():
        if zone == "recharge" and pos not in sim.obstacles:
            recharge_pos = pos
            break
    assert recharge_pos is not None, "No recharge tile found"

    sim.robot_x, sim.robot_y = recharge_pos
    effects = sim._apply_tile_effects(recharge_pos[0], recharge_pos[1])
    assert "Recharge" in effects
    assert sim.battery == 60.0, f"Expected 60.0, got {sim.battery}"
    print(f"  [PASS] Recharge zone: 50 -> {sim.battery}")


def test_pathfinding_avoids_locked_doors():
    """A* should not path through locked doors."""
    sim = AdvancedRobotSim(seed=SEED)
    state = sim.get_state()

    # Find a locked door
    door_pos = list(sim.doors.keys())[0]
    result = find_path(state, door_pos[0], door_pos[1])
    assert not result["reachable"], "Should not path to locked door tile"
    print(f"  [PASS] Pathfinding avoids locked doors")


def test_objectives():
    """Objectives tracking works."""
    sim = AdvancedRobotSim(seed=SEED)
    obj = sim.get_objectives()
    assert obj["primary"]["total"] == 3
    assert obj["primary"]["collected"] == 0
    assert not obj["primary"]["complete"]
    assert obj["tertiary"]["target_percent"] == 80
    assert obj["constraint"]["alive"] is True
    print(f"  [PASS] Objectives tracking")


def test_patrol_movement():
    """Patrol guards move along their paths."""
    sim = AdvancedRobotSim(seed=SEED)
    p = sim.patrols[0]
    initial_pos = (p["x"], p["y"])
    sim._update_patrols()
    new_pos = (p["x"], p["y"])
    assert new_pos == tuple(p["path"][1]), f"Patrol should move to path[1], got {new_pos}"
    print(f"  [PASS] Patrol movement: {initial_pos} -> {new_pos}")


def test_engine_tools():
    """Server-side engine tools return correct data."""
    sim = AdvancedRobotSim(seed=SEED)
    state = sim.get_state()

    result = execute_tool("get_map_info", state)
    assert result["width"] == 40 and result["height"] == 30
    assert result["door_count"] == 6
    assert result["teleporter_count"] == 6

    result = execute_tool("check_zone", state, x=15, y=12)
    assert result["zone"] == "danger", f"Expected danger zone, got {result['zone']}"

    result = execute_tool("check_zone", state, x=5, y=14)
    assert result["zone"] == "recharge", f"Expected recharge zone, got {result['zone']}"

    result = execute_tool("get_objectives", state)
    assert "primary" in result and "secondary" in result

    result = execute_tool("analyze_surroundings", state)
    assert "N" in result and "S" in result and "E" in result and "W" in result
    assert "zone" in result

    print(f"  [PASS] Engine tools")


def test_state_serialization():
    """get_state() returns valid JSON-serializable data."""
    sim = AdvancedRobotSim(seed=SEED)
    state = sim.get_state()
    serialized = json.dumps(state)
    assert len(serialized) > 0
    parsed = json.loads(serialized)
    assert parsed["grid_width"] == 40
    assert parsed["grid_height"] == 30
    assert "zones" in parsed
    assert "doors" in parsed
    assert "teleporters" in parsed
    assert "depot" in parsed
    assert "objectives" in parsed
    print(f"  [PASS] State serialization ({len(serialized)} bytes)")


def test_go_to_with_danger_zone():
    """go_to prefers safe routes over danger zones."""
    sim = AdvancedRobotSim(seed=SEED)
    sim.battery = 100.0
    sim.robot_x, sim.robot_y = 5, 5
    sim.heading = "E"

    # Try to navigate somewhere that could go through danger zone
    msg = sim.apply_action("go_to", {"x": 35, "y": 25})
    # Just verify it doesn't crash and produces a result
    assert isinstance(msg, str) and len(msg) > 0
    print(f"  [PASS] go_to with danger zone: {msg[:60]}...")


# ── Hard agent prompts ──────────────────────────────────────────────

HARD_PROMPTS = [
    {
        "name": "key_door_artifact",
        "prompt": (
            "Find a key, unlock the nearest door, and collect the artifact behind it. "
            "Report what you found."
        ),
        "expected_tools": ["scan_and_list", "go_to", "pick_up", "unlock_door", "collect_item"],
        "difficulty": "hard",
    },
    {
        "name": "danger_zone_recharge",
        "prompt": (
            "Navigate through the danger zone to reach the recharge station at (20,25). "
            "Monitor your battery carefully and scan for traps along the way."
        ),
        "expected_tools": ["check_zone", "scan_area", "go_to", "get_status"],
        "difficulty": "hard",
    },
    {
        "name": "collect_deposit_maximize",
        "prompt": (
            "Collect all visible items, deposit them at the depot, and maximize your score. "
            "Remember the depot is at the bottom-right corner. Prioritize high-value items "
            "(artifacts=50, crystals=25, gems=10). Watch your carry weight limit of 5."
        ),
        "expected_tools": [
            "scan_and_list", "collect_item", "go_to", "deposit_items",
            "get_inventory_weight", "get_objectives",
        ],
        "difficulty": "expert",
    },
    {
        "name": "explore_report_teleporters",
        "prompt": (
            "Explore the entire map systematically, avoid all traps, and report the locations "
            "of all teleporters. Use scan_area to reveal tiles and check_zone to identify "
            "special tiles. Tell me where each teleporter goes."
        ),
        "expected_tools": [
            "scan_area", "go_to", "check_zone", "get_map_info",
            "get_objectives", "analyze_surroundings",
        ],
        "difficulty": "expert",
    },
    {
        "name": "optimal_artifact_route",
        "prompt": (
            "Plan and execute an optimal route to collect all 3 artifacts and return them "
            "to the depot. You may need to find keys to unlock doors blocking some artifacts. "
            "Use teleporters to save battery. Monitor objectives with get_objectives. "
            "This is a multi-step mission -- plan carefully before acting."
        ),
        "expected_tools": [
            "get_objectives", "scan_and_list", "find_path", "go_to",
            "pick_up", "unlock_door", "use_teleporter", "deposit_items",
            "check_zone", "get_inventory_weight",
        ],
        "difficulty": "extreme",
    },
]


def print_hard_prompts():
    """Print all hard prompts for manual testing."""
    print()
    print("=" * 70)
    print("  Hard Agent Prompts for Advanced Robot Demo")
    print("=" * 70)
    for i, p in enumerate(HARD_PROMPTS, 1):
        print(f"\n  [{i}] {p['name']} (difficulty: {p['difficulty']})")
        print(f"      Prompt: {p['prompt']}")
        print(f"      Expected tools: {', '.join(p['expected_tools'])}")
    print()


# ── Main ─────────────────────────────────────────────────────────────


def run_all_tests():
    """Run all unit tests."""
    print()
    print("=" * 70)
    print("  Advanced Robot Demo -- Unit Tests")
    print("=" * 70)
    print()

    tests = [
        test_deterministic_seed,
        test_grid_dimensions,
        test_obstacle_count,
        test_items_placed,
        test_zones_exist,
        test_doors,
        test_teleporters,
        test_traps,
        test_patrols,
        test_movement_and_battery,
        test_pick_up_weight_limit,
        test_unlock_door,
        test_deposit_items,
        test_teleporter,
        test_trap_damage,
        test_recharge_zone,
        test_pathfinding_avoids_locked_doors,
        test_objectives,
        test_patrol_movement,
        test_engine_tools,
        test_state_serialization,
        test_go_to_with_danger_zone,
    ]

    passed = 0
    failed = 0
    for test_fn in tests:
        try:
            test_fn()
            passed += 1
        except Exception as e:
            print(f"  [FAIL] {test_fn.__name__}: {e}")
            failed += 1

    print()
    print(f"  Results: {passed} passed, {failed} failed out of {len(tests)} tests")
    print("=" * 70)

    print_hard_prompts()

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
