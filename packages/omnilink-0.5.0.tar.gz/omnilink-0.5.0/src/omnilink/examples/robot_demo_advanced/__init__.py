"""Advanced Robot Demo -- 40x30 grid-world with zones, doors, teleporters,
patrol guards, traps, multi-objective scoring, and 22 tools.

A harder version of robot_demo that pushes OmniLink agents to their limits.
"""
