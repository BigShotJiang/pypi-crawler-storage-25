"""Advanced Robot AI engine -- server-side tool implementations.

Pure functions that operate on the state dict returned by AdvancedRobotSim.get_state().
"""

from __future__ import annotations

import heapq
import math
from typing import Any

# ── Headings ─────────────────────────────────────────────────
DX = {"N": 0, "E": 1, "S": 0, "W": -1}
DY = {"N": -1, "E": 0, "S": 1, "W": 0}
HEADINGS = ["N", "E", "S", "W"]


def get_position(state: dict[str, Any]) -> dict[str, Any]:
    r = state["robot"]
    return {"x": r["x"], "y": r["y"], "heading": r["heading"]}


def get_battery(state: dict[str, Any]) -> dict[str, Any]:
    return {"battery": state["battery"], "critical": state["battery"] < 15}


def get_inventory(state: dict[str, Any]) -> dict[str, Any]:
    return {
        "inventory": state["inventory"],
        "count": len(state["inventory"]),
        "weight": state["inventory_weight"],
        "max_carry": state["max_carry"],
    }


def get_obstacles(state: dict[str, Any]) -> dict[str, Any]:
    rx, ry = state["robot"]["x"], state["robot"]["y"]
    nearby = [
        o for o in state["obstacles"]
        if abs(o[0] - rx) <= 5 and abs(o[1] - ry) <= 5
    ]
    return {"obstacles": nearby, "count": len(nearby)}


def get_items(state: dict[str, Any]) -> dict[str, Any]:
    rx, ry = state["robot"]["x"], state["robot"]["y"]
    nearby = [
        item for item in state["items"]
        if abs(item["x"] - rx) <= 5 and abs(item["y"] - ry) <= 5
    ]
    return {"items": nearby, "count": len(nearby)}


def calculate_distance(state: dict[str, Any], x: int, y: int) -> dict[str, Any]:
    rx, ry = state["robot"]["x"], state["robot"]["y"]
    manhattan = abs(rx - x) + abs(ry - y)
    euclidean = math.sqrt((rx - x) ** 2 + (ry - y) ** 2)
    return {"manhattan": manhattan, "euclidean": round(euclidean, 2)}


def find_path(state: dict[str, Any], target_x: int, target_y: int) -> dict[str, Any]:
    """A* pathfinding from robot to target, respecting locked doors."""
    w, h = state["grid_width"], state["grid_height"]
    obstacles = {(o[0], o[1]) for o in state["obstacles"]}
    doors = state.get("doors", {})
    locked_doors = set()
    for k, v in doors.items():
        if v == "locked":
            parts = k.split(",")
            locked_doors.add((int(parts[0]), int(parts[1])))

    blocked = obstacles | locked_doors

    rx, ry = state["robot"]["x"], state["robot"]["y"]
    start = (rx, ry)
    goal = (target_x, target_y)

    if goal in blocked or not (0 <= target_x < w and 0 <= target_y < h):
        return {"path": [], "steps": 0, "reachable": False}

    open_set: list[tuple[float, tuple[int, int]]] = [(0, start)]
    came_from: dict[tuple[int, int], tuple[int, int]] = {}
    g_score: dict[tuple[int, int], float] = {start: 0}

    # Zone cost map
    zones = state.get("zones", {})

    while open_set:
        _, current = heapq.heappop(open_set)
        if current == goal:
            path = []
            while current in came_from:
                path.append(list(current))
                current = came_from[current]
            path.reverse()
            return {"path": path, "steps": len(path), "reachable": True}

        cx, cy = current
        for ddx, ddy in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            nx, ny = cx + ddx, cy + ddy
            if not (0 <= nx < w and 0 <= ny < h):
                continue
            if (nx, ny) in blocked:
                continue
            zone_key = f"{nx},{ny}"
            zone = zones.get(zone_key, "safe")
            cost = 2.0 if zone == "danger" else 1.0
            tentative = g_score[current] + cost
            if tentative < g_score.get((nx, ny), float("inf")):
                came_from[(nx, ny)] = current
                g_score[(nx, ny)] = tentative
                f = tentative + abs(nx - target_x) + abs(ny - target_y)
                heapq.heappush(open_set, (f, (nx, ny)))

    return {"path": [], "steps": 0, "reachable": False}


def check_collision(state: dict[str, Any]) -> dict[str, Any]:
    r = state["robot"]
    heading = r["heading"]
    nx = r["x"] + DX[heading]
    ny = r["y"] + DY[heading]
    w, h = state["grid_width"], state["grid_height"]
    obstacles = {(o[0], o[1]) for o in state["obstacles"]}

    if not (0 <= nx < w and 0 <= ny < h):
        return {"safe": False, "reason": "boundary", "target": [nx, ny]}
    if (nx, ny) in obstacles:
        return {"safe": False, "reason": "obstacle", "target": [nx, ny]}

    doors = state.get("doors", {})
    door_key = f"{nx},{ny}"
    if door_key in doors and doors[door_key] == "locked":
        return {"safe": False, "reason": "locked_door", "target": [nx, ny]}

    patrols = state.get("patrols", [])
    for p in patrols:
        if p["x"] == nx and p["y"] == ny:
            return {"safe": False, "reason": "patrol_guard", "target": [nx, ny]}

    return {"safe": True, "target": [nx, ny]}


def get_map_info(state: dict[str, Any]) -> dict[str, Any]:
    w, h = state["grid_width"], state["grid_height"]
    return {
        "width": w,
        "height": h,
        "total_cells": w * h,
        "obstacle_count": len(state["obstacles"]),
        "item_count": len(state["items"]),
        "revealed_count": len(state["revealed"]),
        "walkable": w * h - len(state["obstacles"]),
        "door_count": len(state.get("doors", {})),
        "teleporter_count": len(state.get("teleporters", {})),
        "trap_count": len(state.get("traps", {})),
        "patrol_count": len(state.get("patrols", [])),
        "depot": state.get("depot"),
    }


def analyze_surroundings(state: dict[str, Any]) -> dict[str, Any]:
    r = state["robot"]
    rx, ry = r["x"], r["y"]
    w, h = state["grid_width"], state["grid_height"]
    obstacles = {(o[0], o[1]) for o in state["obstacles"]}
    item_positions = {(it["x"], it["y"]): it["type"] for it in state["items"]}
    doors = state.get("doors", {})
    teleporters = state.get("teleporters", {})
    patrols = {(p["x"], p["y"]) for p in state.get("patrols", [])}

    result: dict[str, Any] = {}
    for heading in HEADINGS:
        nx, ny = rx + DX[heading], ry + DY[heading]
        if not (0 <= nx < w and 0 <= ny < h):
            result[heading] = "boundary"
        elif (nx, ny) in obstacles:
            result[heading] = "obstacle"
        elif f"{nx},{ny}" in doors:
            result[heading] = f"door:{doors[f'{nx},{ny}']}"
        elif (nx, ny) in patrols:
            result[heading] = "patrol_guard"
        elif f"{nx},{ny}" in teleporters:
            result[heading] = "teleporter"
        elif (nx, ny) in item_positions:
            result[heading] = f"item:{item_positions[(nx, ny)]}"
        else:
            result[heading] = "empty"

    standing_on = item_positions.get((rx, ry))
    if standing_on:
        result["here"] = f"item:{standing_on}"
    elif f"{rx},{ry}" in teleporters:
        result["here"] = "teleporter"
    elif (rx, ry) == tuple(state.get("depot", [])):
        result["here"] = "depot"
    else:
        result["here"] = "empty"

    zones = state.get("zones", {})
    result["zone"] = zones.get(f"{rx},{ry}", "safe")

    return result


def check_zone(state: dict[str, Any], x: int, y: int) -> dict[str, Any]:
    """Check what zone a tile is in."""
    zones = state.get("zones", {})
    zone = zones.get(f"{x},{y}", "safe")
    doors = state.get("doors", {})
    teleporters = state.get("teleporters", {})
    traps = state.get("traps", {})

    info: dict[str, Any] = {"x": x, "y": y, "zone": zone}
    dk = f"{x},{y}"
    if dk in doors:
        info["door"] = doors[dk]
    if dk in teleporters:
        info["teleporter_dest"] = teleporters[dk]
    if dk in traps:
        info["trap"] = True
    return info


def get_objectives(state: dict[str, Any]) -> dict[str, Any]:
    """Return current objective progress."""
    return state.get("objectives", {})


# ── Tool dispatch ─────────────────────────────────────────────

TOOLS = {
    "get_position": get_position,
    "get_battery": get_battery,
    "get_inventory": get_inventory,
    "get_obstacles": get_obstacles,
    "get_items": get_items,
    "calculate_distance": calculate_distance,
    "find_path": find_path,
    "check_collision": check_collision,
    "get_map_info": get_map_info,
    "analyze_surroundings": analyze_surroundings,
    "check_zone": check_zone,
    "get_objectives": get_objectives,
}


def execute_tool(name: str, state: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
    """Execute a tool by name. Returns the tool's result dict."""
    fn = TOOLS.get(name)
    if fn is None:
        return {"error": f"Unknown tool: {name}"}
    if kwargs:
        return fn(state, **kwargs)
    return fn(state)
