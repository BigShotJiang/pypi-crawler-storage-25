#!/usr/bin/env python3
"""Test advanced robot demo agent through /api/chat with hard prompts."""

import json, os, sys, time, uuid, requests

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = "https://www.omnilink-agents.com"
AGENT_NAME = "robot-demo-advanced"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "..", "src"))
from omnilink.examples.robot_demo_advanced.advanced_api import get_state
from omnilink.client import OmniLinkClient

def get_tool_server():
    c = OmniLinkClient(omni_key=OMNI_KEY)
    p = next(p for p in c.list_profiles() if p["name"] == AGENT_NAME)
    return p["settings"].get("toolCallbackUrl", "http://127.0.0.1:5051/tool")

def exec_tool(server, name, args):
    r = requests.post(server, json={"tool": name, **args}, timeout=10)
    d = r.json()
    return d.get("result", d)

def state_str():
    s = get_state()
    r = s["robot"]
    return (f"({r['x']},{r['y']}) {r['heading']} bat={s['battery']:.0f}% "
            f"score={s['score']} inv={s['inventory']} items={s['items_remaining']}")

def safe(s, n=100):
    return s[:n].encode("ascii", "replace").decode("ascii")

def run_task(server, engine, prompt, si, max_rounds=30):
    print(f"  Before: {state_str()}")
    conversation = [{"role": "user", "content": prompt}]
    tools = []
    start = time.time()

    for rnd in range(1, max_rounds + 1):
        body = {
            "agentName": AGENT_NAME, "messages": conversation[-14:],
            "skipMemory": True, "requestId": str(uuid.uuid4()),
            "engine": engine, "temperature": 0.1,
            "systemInstructionRequest": si,
        }
        try:
            resp = requests.post(f"{BASE_URL}/api/chat",
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {OMNI_KEY}"},
                json=body, timeout=90)
        except Exception as e:
            print(f"    [R{rnd}] Error: {e}")
            break
        if not resp.ok:
            print(f"    [R{rnd}] HTTP {resp.status_code}")
            break

        data = resp.json()
        text = data.get("text", "")
        tcs = data.get("toolCalls", [])
        conversation.append({"role": "assistant", "content": text})

        if not tcs:
            print(f"    [R{rnd}] DONE: {safe(text, 100)}")
            break

        for tc in tcs:
            tn, ta = tc.get("name", ""), tc.get("arguments", {})
            try:
                result = exec_tool(server, tn, ta)
            except Exception as e:
                result = {"error": str(e)}
            tools.append(tn)
            rs = json.dumps(result, default=str)
            print(f"    [R{rnd}] {tn}({json.dumps(ta)}) -> {safe(rs, 80)}")
            conversation.append({"role": "user", "content": f"tool-output: {tn}\n{rs}"})

        time.sleep(2)

    elapsed = time.time() - start
    print(f"\n  After:  {state_str()}")
    print(f"  Tools: {len(tools)} in {rnd} rounds ({elapsed:.1f}s)")
    counts = {t: tools.count(t) for t in sorted(set(tools))} if tools else {}
    print(f"  Breakdown: {json.dumps(counts)}")
    return tools

def main():
    if not OMNI_KEY:
        print("Set OMNI_KEY"); sys.exit(1)
    try:
        get_state()
    except:
        print("Start advanced_sim first"); sys.exit(1)

    server = get_tool_server()
    print(f"Tool server: {server}")

    # Build SI from profile
    c = OmniLinkClient(omni_key=OMNI_KEY)
    p = next(p for p in c.list_profiles() if p["name"] == AGENT_NAME)
    engine = sys.argv[1] if len(sys.argv) > 1 else "g3-engine"

    si = {k: v for k, v in p["settings"].items()
          if k in ("mainTask", "allowToolUse", "availableTools", "availableToolDetails",
                    "agentName", "maxToolRounds")}

    tasks = [
        ("EASY", "Check your status, scan the area, and tell me what's around you."),
        ("MEDIUM", "Find the nearest item, navigate to it, and pick it up. Then check your objectives."),
        ("HARD", "Find a key, then find and unlock the nearest locked door. Report what's on the other side."),
        ("HARD", "Navigate to a recharge zone to top up your battery, avoiding danger zones along the way."),
        ("EXPERT", "Collect as many items as possible, deposit them at the depot, and maximize your score. Monitor your weight limit."),
        ("EXTREME", "Plan and execute a mission to collect all 3 artifacts. Use keys to unlock doors, teleporters to save battery, and deposit everything at the depot. Check objectives after each major step."),
    ]

    print("\n" + "=" * 70)
    print("  ADVANCED ROBOT DEMO — AGENT STRESS TEST")
    print(f"  Engine: {engine} | Grid: 40x30 | Tools: 22 | Max rounds: 30")
    print(f"  Start: {state_str()}")
    print("=" * 70)

    for i, (diff, prompt) in enumerate(tasks, 1):
        # Reset sim between tasks
        try:
            requests.post("http://127.0.0.1:5051/callback", json={"action": "RESET"}, timeout=5)
        except:
            pass

        print(f"\n  {'='*66}")
        print(f"  TASK {i} [{diff}]: {safe(prompt, 80)}")
        print(f"  {'='*66}\n")
        tools = run_task(server, engine, prompt, si)
        time.sleep(5)

    print(f"\n{'='*70}")
    print("  DONE")
    print(f"{'='*70}")

if __name__ == "__main__":
    main()
