# Data Pipeline Agent — Long-Running Tools Demo

An interactive demo where an OmniLink agent analyzes a sales dataset
using tools that simulate real processing time (1.5–3 seconds each).
This demonstrates multi-round tool chaining, progress indicators,
toast notifications, and the Activity feed for long-running operations.

---

## Overview

The agent has access to a 200-row sales dataset (Q3–Q4 2025) and five
analysis tools.  When you ask a question, the agent chains multiple
tools — scanning the schema, computing stats, filtering rows, detecting
anomalies, and generating reports.  Each tool takes noticeable time to
execute, making the UI's progress spinner visible and showing how the
activity tracking system works for real workloads.

### Architecture

```
┌──────────────────────────────────────────────────────┐
│           OmniLink Build Page (browser)               │
│                                                       │
│  User: "Give me a full sales report"                  │
│                                                       │
│  Agent chains:                                        │
│    1. scan_dataset({})              ~2.5s             │
│    2. generate_report({})           ~3.0s             │
│    3. Final answer with insights                      │
│                                                       │
│  Progress spinner shows during each tool call.        │
│  Toast notifications pop up as tools complete.        │
└───────────────┬──────────────────────────────────────┘
                │  HTTP POST /tool
                ▼
┌──────────────────────────────────────────────────────┐
│       Local Tool Server (Python)                      │
│                                                       │
│  scan_dataset      →  2.5s  → schema + preview       │
│  analyze_column    →  2.0s  → stats + distributions  │
│  filter_data       →  1.5s  → matching rows          │
│  find_anomalies    →  3.0s  → outliers + z-scores    │
│  generate_report   →  3.0s  → full pipeline report   │
└───────────────┬──────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────────────────┐
│  sample_data/sales_q3_q4_2025.csv                     │
│                                                       │
│  200 deals: deal_id, close_date, region, product,     │
│  sales_rep, status (won/lost/pending), quantity,      │
│  amount — with a few injected anomalies               │
└──────────────────────────────────────────────────────┘
```

---

## Quick Start

### 1. Set your Omni Key

```bash
export OMNI_KEY=omk_your_key_here
```

### 2. Run the demo

```bash
python -m omnilink.examples.data_pipeline.data_pipeline_demo
```

### 3. Open the UI and ask a question

Go to **https://www.omnilink-agents.com/build** and try one of the
prompts below.

---

## Available Tools

| Tool | Time | Description |
|------|------|-------------|
| `scan_dataset` | ~2.5s | Scan schema, row count, column types, and preview |
| `analyze_column` | ~2.0s | Compute mean, median, min, max, std dev (with optional `group_by`) |
| `filter_data` | ~1.5s | Filter rows by column value with comparison operators |
| `find_anomalies` | ~3.0s | Detect outliers using IQR (interquartile range) method |
| `generate_report` | ~3.0s | Compile full summary: totals, win rates, breakdowns, top performers |

### Tool Arguments

**scan_dataset** — no arguments needed.

**analyze_column**:
| Arg | Required | Example |
|-----|----------|---------|
| `column` | yes | `"amount"` |
| `group_by` | no | `"region"` |

**filter_data**:
| Arg | Required | Example |
|-----|----------|---------|
| `column` | yes | `"amount"` |
| `value` | yes | `"10000"` |
| `operator` | no | `"gt"`, `"lt"`, `"eq"`, `"gte"`, `"lte"`, `"contains"` |

**find_anomalies**:
| Arg | Required | Example |
|-----|----------|---------|
| `column` | yes | `"amount"` |

**generate_report** — no arguments needed.

---

## Example Prompts

### Quick (1–2 tool calls)

| Prompt | Expected chain |
|--------|---------------|
| "What does the dataset look like?" | `scan_dataset` |
| "Show me all deals over $20,000" | `filter_data(column="amount", value="20000", operator="gt")` |
| "How is Alice Chen performing?" | `filter_data(column="sales_rep", value="Alice Chen")` |

### Medium (2–3 tool calls)

| Prompt | Expected chain |
|--------|---------------|
| "Which region has the highest revenue?" | `scan_dataset` → `analyze_column(column="amount", group_by="region")` |
| "What's the average deal size by product?" | `scan_dataset` → `analyze_column(column="amount", group_by="product")` |
| "Find any unusually large deals" | `scan_dataset` → `find_anomalies(column="amount")` |

### Long (3–5 tool calls)

| Prompt | Expected chain |
|--------|---------------|
| "Give me a full sales report" | `scan_dataset` → `generate_report` |
| "Analyze the pipeline: win rates, top reps, anomalies" | `generate_report` → `find_anomalies(column="amount")` |
| "Compare Europe vs Asia Pacific performance, find outliers, and list pending deals" | `analyze_column` → `find_anomalies` → `filter_data` |
| "Do a complete analysis: scan the data, check for anomalies, show top performers" | `scan_dataset` → `find_anomalies` → `generate_report` |

---

## What To Watch For

### Progress Spinner
When a tool is running (1.5–3 seconds), the **tool progress indicator**
appears on the build page showing which tool is executing.  It stays
visible until the tool returns.

### Toast Notifications
If you navigate away from the main build page (e.g. to Memory or
Configuration), **toast popups** in the bottom-right alert you when
tool calls and answers arrive.

### Activity Feed
Open **Activity** in the side menu to see a real-time log of every tool
call, result, and agent response.  Each entry shows the timestamp, level
(info/success/error), and expandable metadata.

### Badge Counter
When tools are executing and you're not on the Activity page, the
**Activity** menu item shows a golden badge with the count of unseen
events.

### Multi-Round Chaining
The agent can chain up to **max tool rounds** (configurable in
Configuration → Allow tool usage).  For the "full analysis" prompts,
you'll see the agent call 3–5 tools in sequence, with the progress
spinner appearing for each one.

---

## Dataset

The included `sales_q3_q4_2025.csv` contains 200 synthetic deals:

| Column | Type | Description |
|--------|------|-------------|
| `deal_id` | text | Unique identifier (DEAL-1000 to DEAL-1199) |
| `close_date` | date | Close date (2025-07-01 to 2026-03-28) |
| `region` | text | North America, Europe, Asia Pacific, Latin America, Middle East |
| `product` | text | OmniLink Pro, Enterprise, Starter, API Credits Pack, Support Plan |
| `sales_rep` | text | 10 sales representatives |
| `status` | text | won, lost, or pending |
| `quantity` | int | Units sold |
| `amount` | float | Deal value in USD |

A few deals have artificially inflated amounts (5–12x normal) to serve
as detectable anomalies for `find_anomalies`.

---

## Creating Your Own Pipeline Tools

Each tool extends `DefaultTool`:

```python
import time
from omnilink.default_tools import DefaultTool

class SlowProcessingTool(DefaultTool):
    name = "process_batch"
    description = "Process a batch of records. Args: batch_size (optional)."

    def execute(self, **kwargs):
        batch_size = int(kwargs.get("batch_size", 100))
        time.sleep(batch_size * 0.05)  # 50ms per record
        # ... do real work ...
        return {"processed": batch_size, "status": "complete"}
```

The `time.sleep()` is what makes the tool "long-running" in the UI.
In production, this would be real I/O — database queries, API calls,
file processing, etc.

---

## Files

```
data_pipeline/
├── README.md                           ← this file
├── __init__.py
├── data_pipeline_demo.py               ← demo entry point
├── pipeline_tools.py                   ← tool implementations
└── sample_data/
    └── sales_q3_q4_2025.csv            ← 200-row sales dataset
```
