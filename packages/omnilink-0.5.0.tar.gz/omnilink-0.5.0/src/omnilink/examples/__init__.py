"""OmniLink example use cases — grouped by complexity.

Where to start
--------------

If you have never used OmniLink before, try these in order:

1. ``hello_world.py``
   Smallest possible example.  A single OmniLinkEngine command handler.

2. ``chat_quickstart.py``
   Minimal OmniLinkClient usage — one chat request, one response.

3. ``robot_demo/run_tools_demo.py``
   Recommended first "real" demo.  Full ``ToolRunner`` with 16 tools,
   a Pygame simulation, and the OmniLink web UI.  This is the
   reference implementation for the native tool-calling architecture.

4. ``robot_demo_advanced/run_advanced_demo.py``
   Harder version of the robot demo with 22 tools, zones, doors,
   teleporters, and a weight-limited inventory.  Shows how to push
   the agent with multi-objective planning.

5. ``omnisim_ur5e/play_omnisim.py``
   Controls a real-world-style UR5e robot arm running in OmniSim
   (Webots) over an HTTP bridge.  Good example of a ``ToolRunner``
   wrapping a physical simulator with a safety watchdog and 9 tools
   for joint/TCP control and inverse kinematics.  Includes a
   ``mock_bridge.py`` so you can try the agent without Webots.

6. Classic games (``breakout/``, ``pacman/``, ``tetris/``, etc.)
   Autonomous game-playing demos built on ``ToolRunner``.  Good for
   seeing how the agent handles tight control loops.

Running an example
------------------

All examples assume you have an OMNI_KEY::

    export OMNI_KEY="olink_..."
    python -m omnilink.examples.robot_demo.robot_sim       # terminal 1
    python -m omnilink.examples.robot_demo.run_tools_demo  # terminal 2

Get an Omni Key at https://www.omnilink-agents.com/dashboard.
"""
