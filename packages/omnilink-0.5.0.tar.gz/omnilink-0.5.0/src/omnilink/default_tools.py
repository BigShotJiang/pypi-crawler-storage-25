"""OmniLink Default Tools — ready-made query tools for agents.

Provides a set of file-system tools that any ToolRunner subclass can use
out of the box. Each tool is a self-contained class that knows how to
describe itself (for the agent profile) and execute queries.

Quick start
-----------
::

    from omnilink.tool_runner import ToolRunner
    from omnilink.default_tools import SearchFilesTool, ReadFileTool, ListFilesTool

    class MyRunner(ToolRunner):
        agent_name = "my-agent"
        display_name = "My Agent"

        default_tools = [
            SearchFilesTool(root_dir="./data"),
            ReadFileTool(root_dir="./data"),
            ListFilesTool(root_dir="./data"),
        ]

        # ... other hooks ...
"""

from __future__ import annotations

import fnmatch
import os
from pathlib import Path
from typing import Any


# ── Base class ───────────────────────────────────────────────────────

class DefaultTool:
    """Base class for all default tools.

    Subclasses must set ``name`` and ``description`` and implement
    ``execute(**kwargs)``.  Optionally set ``parameters_schema`` to
    provide a JSON Schema that enables native structured tool calling.
    """

    name: str = ""
    description: str = ""
    parameters_schema: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return the tool definition dict used by the agent profile's
        ``availableToolDetails``.  Includes ``parameters`` when a schema
        is defined so that engines can use native tool calling.

        Raises
        ------
        ValueError
            If ``name`` or ``description`` is empty.  Both are required
            for the AI to discover and use the tool.
        """
        if not self.name or not isinstance(self.name, str):
            raise ValueError(
                f"{type(self).__name__}: class attribute 'name' must be a non-empty string. "
                f"Set it in your subclass, e.g. `name = \"move_forward\"`."
            )
        if not self.description or not isinstance(self.description, str):
            raise ValueError(
                f"{type(self).__name__}: class attribute 'description' must be a non-empty string. "
                f"Set it in your subclass — the AI uses this to decide when to call the tool."
            )
        d: dict[str, Any] = {"name": self.name, "description": self.description}
        if self.parameters_schema:
            d["parameters"] = self.parameters_schema
        return d

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        """Run the tool and return a JSON-serialisable result dict."""
        raise NotImplementedError

    # ── Argument helpers ────────────────────────────────────────────

    def get_arg(
        self,
        kwargs: dict[str, Any],
        name: str,
        *,
        default: Any = None,
        required: bool = False,
        type_: type | None = None,
    ) -> Any:
        """Extract a single tool argument with optional type coercion.

        Use this inside ``execute()`` to avoid the ``kwargs.get("x") or ...``
        anti-pattern, which silently swallows falsy values like ``0``.

        Parameters
        ----------
        kwargs:
            The kwargs dict passed to ``execute``.
        name:
            The argument name as declared in ``parameters_schema``.
        default:
            Value to return when ``name`` is missing and ``required=False``.
        required:
            If True and the arg is missing, raises ``ValueError``.
        type_:
            Optional Python type to coerce the value into (e.g. ``int``).

        Returns
        -------
        The (possibly coerced) argument value.

        Raises
        ------
        ValueError
            If ``required`` is True and the arg is missing, or type coercion
            fails.

        Examples
        --------
        >>> def execute(self, **kwargs):
        ...     x = self.get_arg(kwargs, "x", required=True, type_=int)
        ...     y = self.get_arg(kwargs, "y", required=True, type_=int)
        ...     speed = self.get_arg(kwargs, "speed", default=1, type_=int)
        """
        if name not in kwargs or kwargs[name] is None:
            if required:
                raise ValueError(f"{self.name}: missing required argument '{name}'")
            return default
        value = kwargs[name]
        if type_ is not None:
            try:
                return type_(value)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"{self.name}: argument '{name}' must be {type_.__name__}, got {value!r}"
                ) from exc
        return value


# ── Helpers ──────────────────────────────────────────────────────────

# Extensions that are safe to read as text.
_TEXT_EXTENSIONS: set[str] = {
    ".txt", ".md", ".csv", ".json", ".jsonl",
    ".xml", ".yaml", ".yml", ".toml", ".ini", ".cfg",
    ".py", ".js", ".ts", ".html", ".css", ".sql",
    ".sh", ".bat", ".ps1", ".log", ".env", ".conf",
    ".rst", ".tex", ".r", ".rb", ".go", ".java",
    ".c", ".cpp", ".h", ".hpp", ".cs", ".swift",
}


def _resolve_path(root_dir: str, relative: str) -> Path | None:
    """Resolve *relative* inside *root_dir* and guard against traversal."""
    root = Path(root_dir).resolve()
    target = (root / relative).resolve()
    if not str(target).startswith(str(root)):
        return None
    return target


def _is_text_file(path: Path, allowed_extensions: set[str] | None) -> bool:
    ext = path.suffix.lower()
    if allowed_extensions is not None:
        return ext in allowed_extensions
    return ext in _TEXT_EXTENSIONS


# ── SearchFilesTool ──────────────────────────────────────────────────

class SearchFilesTool(DefaultTool):
    """Search for text content within files under a root directory.

    The agent can call this tool with a ``query`` string and optionally
    a ``path`` (subdirectory) and ``file_pattern`` (glob like ``*.py``).
    Returns matching lines with file paths and line numbers.

    Parameters
    ----------
    root_dir:
        The base directory to search in.  All paths are confined to this
        directory (no traversal outside it).
    allowed_extensions:
        If provided, only files whose extension is in this set will be
        searched.  Defaults to a broad set of text file extensions.
    max_results:
        Maximum number of matching lines to return (default 30).
    max_file_size:
        Skip files larger than this many bytes (default 1 MB).
    context_lines:
        Number of lines to include before and after each match
        (default 1).
    """

    name: str = "search_files"
    description: str = (
        "Search for text inside files. "
        "Args: query (required), path (optional subdirectory), "
        "file_pattern (optional glob, e.g. '*.py')."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Text to search for."},
            "path": {"type": "string", "description": "Subdirectory to search in (relative to root)."},
            "file_pattern": {"type": "string", "description": "Glob pattern to filter files, e.g. '*.py'."},
        },
        "required": ["query"],
    }

    def __init__(
        self,
        root_dir: str = ".",
        *,
        allowed_extensions: set[str] | None = None,
        max_results: int = 30,
        max_file_size: int = 1_000_000,
        context_lines: int = 1,
    ) -> None:
        self.root_dir = root_dir
        self.allowed_extensions = allowed_extensions
        self.max_results = max_results
        self.max_file_size = max_file_size
        self.context_lines = context_lines

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        query: str = kwargs.get("query", "").strip()
        if not query:
            return {"error": "Missing required argument: query"}

        sub_path: str = kwargs.get("path", "")
        file_pattern: str = kwargs.get("file_pattern", "")

        root = Path(self.root_dir).resolve()
        search_dir = root
        if sub_path:
            resolved = _resolve_path(self.root_dir, sub_path)
            if resolved is None:
                return {"error": "Path is outside the allowed directory."}
            search_dir = resolved

        if not search_dir.is_dir():
            return {"error": f"Directory not found: {sub_path or self.root_dir}"}

        query_lower = query.lower()
        matches: list[dict[str, Any]] = []

        for dirpath, _dirnames, filenames in os.walk(search_dir):
            for fname in filenames:
                fpath = Path(dirpath) / fname
                if not _is_text_file(fpath, self.allowed_extensions):
                    continue
                if file_pattern and not fnmatch.fnmatch(fname, file_pattern):
                    continue
                try:
                    if fpath.stat().st_size > self.max_file_size:
                        continue
                except OSError:
                    continue

                try:
                    lines = fpath.read_text(encoding="utf-8", errors="replace").splitlines()
                except OSError:
                    continue

                for i, line in enumerate(lines):
                    if query_lower in line.lower():
                        rel = str(fpath.relative_to(root))
                        start = max(0, i - self.context_lines)
                        end = min(len(lines), i + self.context_lines + 1)
                        context = [
                            {"line": start + j + 1, "text": lines[start + j]}
                            for j in range(end - start)
                        ]
                        matches.append({
                            "file": rel,
                            "match_line": i + 1,
                            "context": context,
                        })
                        if len(matches) >= self.max_results:
                            return {
                                "query": query,
                                "matches": matches,
                                "truncated": True,
                            }

        return {
            "query": query,
            "matches": matches,
            "truncated": False,
        }


# ── ReadFileTool ─────────────────────────────────────────────────────

class ReadFileTool(DefaultTool):
    """Read the contents of a file (or a range of lines).

    Parameters
    ----------
    root_dir:
        The base directory.  Paths are resolved relative to this.
    max_file_size:
        Skip files larger than this many bytes (default 1 MB).
    max_lines:
        Maximum number of lines to return (default 200).
    """

    name: str = "read_file"
    description: str = (
        "Read a file's contents. "
        "Args: path (required, relative to root), "
        "start_line (optional, 1-based), end_line (optional, 1-based)."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File path relative to root."},
            "start_line": {"type": "integer", "description": "First line to read (1-based)."},
            "end_line": {"type": "integer", "description": "Last line to read (1-based)."},
        },
        "required": ["path"],
    }

    def __init__(
        self,
        root_dir: str = ".",
        *,
        max_file_size: int = 1_000_000,
        max_lines: int = 200,
    ) -> None:
        self.root_dir = root_dir
        self.max_file_size = max_file_size
        self.max_lines = max_lines

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        rel_path: str = kwargs.get("path", "").strip()
        if not rel_path:
            return {"error": "Missing required argument: path"}

        resolved = _resolve_path(self.root_dir, rel_path)
        if resolved is None:
            return {"error": "Path is outside the allowed directory."}
        if not resolved.is_file():
            return {"error": f"File not found: {rel_path}"}

        try:
            size = resolved.stat().st_size
        except OSError:
            return {"error": f"Cannot access file: {rel_path}"}
        if size > self.max_file_size:
            return {"error": f"File too large ({size:,} bytes, limit {self.max_file_size:,})."}

        try:
            lines = resolved.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError as exc:
            return {"error": f"Cannot read file: {exc}"}

        start = int(kwargs.get("start_line", 1)) - 1
        end = int(kwargs.get("end_line", 0)) or len(lines)
        start = max(0, start)
        end = min(len(lines), end)

        selected = lines[start:end]
        truncated = False
        if len(selected) > self.max_lines:
            selected = selected[: self.max_lines]
            truncated = True

        numbered = [
            {"line": start + i + 1, "text": t}
            for i, t in enumerate(selected)
        ]

        return {
            "path": rel_path,
            "total_lines": len(lines),
            "content": numbered,
            "truncated": truncated,
        }


# ── ListFilesTool ────────────────────────────────────────────────────

class ListFilesTool(DefaultTool):
    """List files and directories under a path.

    Parameters
    ----------
    root_dir:
        The base directory.  Paths are resolved relative to this.
    max_entries:
        Maximum number of entries to return (default 100).
    """

    name: str = "list_files"
    description: str = (
        "List files and subdirectories. "
        "Args: path (optional subdirectory, defaults to root), "
        "file_pattern (optional glob, e.g. '*.json')."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Subdirectory to list (relative to root)."},
            "file_pattern": {"type": "string", "description": "Glob pattern to filter entries, e.g. '*.json'."},
        },
    }

    def __init__(
        self,
        root_dir: str = ".",
        *,
        max_entries: int = 100,
    ) -> None:
        self.root_dir = root_dir
        self.max_entries = max_entries

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        sub_path: str = kwargs.get("path", "")
        file_pattern: str = kwargs.get("file_pattern", "")

        root = Path(self.root_dir).resolve()
        target = root
        if sub_path:
            resolved = _resolve_path(self.root_dir, sub_path)
            if resolved is None:
                return {"error": "Path is outside the allowed directory."}
            target = resolved

        if not target.is_dir():
            return {"error": f"Directory not found: {sub_path or self.root_dir}"}

        entries: list[dict[str, Any]] = []
        try:
            for item in sorted(target.iterdir()):
                if file_pattern and not item.is_dir():
                    if not fnmatch.fnmatch(item.name, file_pattern):
                        continue
                rel = str(item.relative_to(root))
                entry: dict[str, Any] = {
                    "name": item.name,
                    "path": rel,
                    "type": "directory" if item.is_dir() else "file",
                }
                if item.is_file():
                    try:
                        entry["size"] = item.stat().st_size
                    except OSError:
                        pass
                entries.append(entry)
                if len(entries) >= self.max_entries:
                    return {
                        "path": sub_path or ".",
                        "entries": entries,
                        "truncated": True,
                    }
        except OSError as exc:
            return {"error": f"Cannot list directory: {exc}"}

        return {
            "path": sub_path or ".",
            "entries": entries,
            "truncated": False,
        }
