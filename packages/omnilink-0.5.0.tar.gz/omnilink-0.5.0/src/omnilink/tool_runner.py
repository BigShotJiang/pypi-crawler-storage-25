"""OmniLink Tool Runner — base class for local tool controllers.

Provides a reusable game/task loop that handles:
- Agent profile setup
- Tool-call kickoff (one API call)
- Memory persistence and UI command polling
- Periodic agent reviews
- Final analysis

Subclasses supply game-specific behaviour by overriding hooks.

Quick start
-----------
::

    from omnilink.tool_runner import ToolRunner

    class BreakoutRunner(ToolRunner):
        agent_name = "breakout-agent"
        display_name = "Breakout"

        def get_state(self):
            return breakout_api.get_state()

        def execute_action(self, state):
            action = breakout_engine.decide_action(state)
            breakout_api.send_action(action)

        def state_summary(self, state):
            return breakout_engine.state_summary(state)

        def is_game_over(self, state):
            return state.get("game_state") == "GAMEOVER"

        def log_events(self, state):
            ...

    if __name__ == "__main__":
        BreakoutRunner().run()
"""

from __future__ import annotations

import concurrent.futures
import http.server
import json
import os
import re
import threading
import time
from typing import Any

import requests

from omnilink.client import OmniLinkAPIError, OmniLinkClient
from omnilink.default_tools import DefaultTool


class ToolRunner:
    """Base class for OmniLink local tool controllers.

    Override the hook methods to adapt this runner to any game or task.
    Call ``run()`` to start the tool-calling loop.
    """

    # ── Required overrides ────────────────────────────────────────────
    agent_name: str = "tool-agent"
    display_name: str = "Tool"

    # ── Configuration (override as needed) ────────────────────────────
    base_url: str = "https://www.omnilink-agents.com"
    omni_key: str = os.environ.get("OMNI_KEY", "")
    engine: str = "g3-engine"
    poll_interval: float = 0.0
    memory_every: int = 60
    ask_every: int = 2400
    max_kickoff_retries: int = 3
    tool_name: str = "make_move"
    tool_description: str = "Execute the next action."
    commands: str = "stop_game, pause_game, resume_game"
    game_server_url: str | None = None  # e.g. "http://127.0.0.1:5000"
    tool_callback_url: str | None = None  # e.g. "http://127.0.0.1:5000/tool"

    # Pinned port for the tool-callback server. Default 0 = OS picks a free
    # ephemeral port (stable nowhere, churns on every restart, causes open
    # browser tabs to break on restart with ERR_CONNECTION_REFUSED because
    # the stored toolCallbackUrl goes stale). Set this to a fixed port to
    # keep the URL stable across restarts — then the profile's
    # toolCallbackUrl never changes and tabs keep working. The port must
    # not already be in use; if it is, startup fails loudly rather than
    # silently falling back to a random port.
    tool_callback_port: int = 0

    # Tool callback server transport. HTTP on loopback is the default:
    # browsers treat http://127.0.0.1 as a "potentially trustworthy" origin
    # per the W3C Secure Contexts spec, so HTTPS pages can fetch it without
    # mixed-content blocks and without the self-signed-cert warning users
    # previously had to click through. Flip this to True only if you need
    # TLS on the loopback hop (e.g. a corporate policy that forbids any
    # plaintext traffic, even on lo).
    use_https: bool = False

    # ── Tool registration ─────────────────────────────────────────────
    #
    # Use ``default_tools`` for all new code.  Each entry must be a
    # ``DefaultTool`` subclass instance and is dispatched automatically
    # by ``execute_query_tool()``.
    #
    # ``query_tools`` is the legacy registration format (plain dicts) and
    # is kept for backwards compatibility with older examples.  When
    # using ``query_tools`` you must also override ``execute_query_tool``
    # to handle dispatch manually.  Prefer ``default_tools`` instead.

    default_tools: list[DefaultTool] = []
    """Tools registered as ``DefaultTool`` instances.  Auto-dispatched."""

    query_tools: list[dict[str, str]] = []
    """Legacy tool format (plain dicts).  Prefer ``default_tools``."""

    # ── Hooks (override in subclass) ──────────────────────────────────

    def get_state(self) -> dict[str, Any]:
        """Fetch the current state from the target system.

        Must return a dict. Called every tick.
        """
        raise NotImplementedError

    def execute_action(self, state: dict[str, Any]) -> None:
        """Decide and send the next action based on ``state``.

        Called every tick while the game is active and not paused.
        """
        raise NotImplementedError

    def state_summary(self, state: dict[str, Any]) -> str:
        """Return a concise text summary of the current state.

        Used for memory persistence and final reporting.
        """
        raise NotImplementedError

    def is_game_over(self, state: dict[str, Any]) -> bool:
        """Return True if the task/game has ended."""
        raise NotImplementedError

    def log_events(self, state: dict[str, Any]) -> None:
        """Print noteworthy events (score changes, lives lost, etc.).

        Called every tick. Override to add game-specific logging.
        """
        pass

    def on_start(self) -> None:
        """Called after the agent kicks off, before the main loop.

        Override to send a RESUME/START command to the game server.
        """
        pass

    def game_over_message(self, state: dict[str, Any]) -> str:
        """Return the game-over banner text."""
        return f"GAME OVER"

    # ── System instructions (override for custom prompts) ─────────────

    def _all_tool_details(self) -> list[dict[str, Any]]:
        """Combine the action tool with query tools and default tools."""
        tools: list[dict[str, Any]] = [{"name": self.tool_name, "description": self.tool_description, "parameters": {"type": "object", "properties": {}}}]
        tools.extend(self.query_tools)
        for dt in self.default_tools:
            tools.append(dt.to_dict())
        return tools

    def _all_tool_names(self) -> str:
        """Comma-separated list of all tool names."""
        return ", ".join(t["name"] for t in self._all_tool_details())

    def get_system_instruction(self) -> dict[str, Any]:
        """System instruction for the initial tool-call kickoff."""
        return {
            "mainTask": f"{self.display_name} coordinator. Call {self.tool_name} now.",
            "availableTools": self._all_tool_names(),
            "availableToolDetails": self._all_tool_details(),
            "availableCommands": self.commands,
            "allowToolUse": True,
        }

    def get_review_instruction(self) -> dict[str, Any]:
        """System instruction for periodic agent reviews."""
        return {
            "mainTask": (
                f"Monitor {self.display_name}. GAMEOVER or 0 lives: stop_game. "
                f"Otherwise: {self.tool_name}."
            ),
            "availableTools": self._all_tool_names(),
            "availableToolDetails": self._all_tool_details(),
            "availableCommands": self.commands,
            "allowToolUse": True,
        }

    def get_profile_settings(self) -> dict[str, Any]:
        """Settings dict for the agent profile."""
        settings: dict[str, Any] = {
            "agentName": self.agent_name,
            "mainTask": (
                f"{self.display_name} coordinator. "
                f"Use the available tools to perform actions and answer queries."
            ),
            "availableTools": self._all_tool_names(),
            "availableToolDetails": self._all_tool_details(),
            "availableCommands": self.commands,
            "allowToolUse": True,
        }
        if self.tool_callback_url:
            settings["toolCallbackUrl"] = self.tool_callback_url
        return settings

    # ── Query tool execution (override in subclass) ────────────────────

    def execute_query_tool(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        """Execute a query tool and return the result dict.

        Default tools are dispatched automatically.  Override in subclass
        to handle additional game-specific tool queries — call
        ``super().execute_query_tool(...)`` for unrecognised names so
        that default tools still work.
        """
        for dt in self.default_tools:
            if dt.name == tool_name:
                return dt.execute(**kwargs)
        return {"error": f"Unknown tool: {tool_name}"}

    # ── Built-in tool callback server ────────────────────────────────

    _tool_server_port: int = 0

    def _start_tool_server(self) -> int:
        """Start a lightweight HTTP server for tool callbacks from the UI.

        Returns the port the server is listening on.
        """
        runner = self

        class ToolHandler(http.server.BaseHTTPRequestHandler):
            def log_message(self, fmt: str, *args: Any) -> None:
                pass

            def _cors_headers(self) -> None:
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
                # Private Network Access (Chrome, eventually the other majors):
                # a page on a public origin (https://www.omnilink-agents.com)
                # that fetches a private-IP endpoint (http://127.0.0.1:PORT)
                # must receive this header on the preflight response, otherwise
                # the browser blocks the request. Always emitting it is safe —
                # it only matters when the preflight carries the matching
                # `Access-Control-Request-Private-Network: true` request header.
                self.send_header("Access-Control-Allow-Private-Network", "true")

            def do_OPTIONS(self) -> None:
                self.send_response(204)
                self._cors_headers()
                self.send_header("Access-Control-Max-Age", "86400")
                self.end_headers()

            def do_GET(self) -> None:
                if self.path != "/activity":
                    self.send_error(404)
                    return
                body = json.dumps({
                    "status": "ok",
                    "entries": runner._activity_log[-100:],
                }).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self._cors_headers()
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self) -> None:
                if self.path != "/tool":
                    self.send_error(404)
                    return
                length = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(length).decode("utf-8", errors="replace")
                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    data = {}
                tool_name = str(data.get("tool", "")).replace(" ", "_")
                tool_kwargs = {k: v for k, v in data.items() if k != "tool"}
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(runner.execute_query_tool, tool_name, **tool_kwargs)
                    try:
                        result = future.result(timeout=10)
                    except concurrent.futures.TimeoutError:
                        result = {"error": f"Tool '{tool_name}' timed out after 10s"}
                body = json.dumps({"status": "ok", "tool": tool_name, "result": result}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self._cors_headers()
                self.end_headers()
                self.wfile.write(body)

        # Bind to loopback only. The tool-callback server is reached by the
        # user's browser on the same machine; exposing it on 0.0.0.0 would
        # let anything on the LAN drive the agent's tools.
        server = http.server.ThreadingHTTPServer(
            ("127.0.0.1", self.tool_callback_port), ToolHandler,
        )

        # Default: plain HTTP on loopback. Browsers treat http://127.0.0.1
        # as a potentially trustworthy origin so an HTTPS page can fetch it
        # without mixed-content blocks. TLS on the loopback hop is opt-in
        # via `use_https = True`.
        self._ssl_enabled = False
        if self.use_https:
            ssl_ctx = self._create_ssl_context()
            if ssl_ctx:
                server.socket = ssl_ctx.wrap_socket(server.socket, server_side=True)
                self._ssl_enabled = True

        port = server.server_address[1]
        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()
        self._tool_server_port = port
        return port

    # ── SSL / HTTPS ──────────────────────────────────────────────────

    @staticmethod
    def _create_ssl_context():
        """Create an SSL context with a self-signed certificate.

        The cert is generated once and cached in ~/.omnilink/ssl/.
        Returns None if SSL setup fails (falls back to HTTP).
        """
        import ssl
        try:
            from pathlib import Path
            ssl_dir = Path.home() / ".omnilink" / "ssl"
            ssl_dir.mkdir(parents=True, exist_ok=True)
            cert_file = ssl_dir / "tool-server.pem"
            key_file = ssl_dir / "tool-server-key.pem"

            if not cert_file.exists() or not key_file.exists():
                ToolRunner._generate_self_signed_cert(cert_file, key_file)

            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(str(cert_file), str(key_file))
            return ctx
        except Exception as exc:
            print(f"  [warn] HTTPS setup failed ({exc}), falling back to HTTP")
            return None

    @staticmethod
    def _generate_self_signed_cert(cert_path, key_path):
        """Generate a self-signed certificate for localhost."""
        import subprocess
        import shutil

        openssl = shutil.which("openssl")
        if not openssl:
            raise FileNotFoundError("openssl not found in PATH")

        subprocess.run(
            [
                openssl, "req", "-x509", "-newkey", "rsa:2048",
                "-keyout", str(key_path),
                "-out", str(cert_path),
                "-days", "3650",
                "-nodes",
                "-subj", "/CN=localhost",
                "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1",
            ],
            check=True,
            capture_output=True,
        )

    # ── Internal helpers ──────────────────────────────────────────────

    _profile_id: str | None = None
    _conversation_history: list[dict[str, Any]] = []
    _game_session: requests.Session | None = None
    _client: OmniLinkClient | None = None
    _activity_log: list[dict[str, Any]] = []

    def _send_game_command(self, cmd: str) -> bool:
        """POST a command (PAUSE/RESUME) to the game server's /command endpoint.

        Returns True if the server acknowledged with status ok.
        """
        if not self.game_server_url:
            return False
        if self._game_session is None:
            self._game_session = requests.Session()
        try:
            r = self._game_session.post(
                f"{self.game_server_url}/command",
                json={"command": cmd},
                timeout=2,
            )
            return r.ok
        except Exception as e:
            print(
                f"  [WARN] Could not reach game server at {self.game_server_url}: {e}\n"
                f"         Is the simulation running? (Check the README for your demo's sim command.)"
            )
            return False

    def _memory_agent_key(self) -> str:
        """Return the key used for short-term memory storage.

        The UI resolves memory by profile UUID, so prefer that over the
        human-readable agent name.
        """
        return self._profile_id or self.agent_name

    def _append_turn(self, prompt: str, response: str) -> None:
        """Append a user/model turn to the conversation history."""
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self._conversation_history.append(
            {"role": "user", "parts": [{"text": prompt}], "timestamp": ts},
        )
        self._conversation_history.append(
            {"role": "model", "parts": [{"text": response}], "timestamp": ts},
        )

    # ── Activity tracking ────────────────────────────────────────────

    def log_activity(
        self,
        action: str,
        detail: str = "",
        *,
        kind: str = "info",
        data: dict[str, Any] | None = None,
        sync: bool = True,
    ) -> None:
        """Log an agent activity and optionally push it to the UI.

        Each call appends a conversation turn to memory so the UI's
        Memory page shows the activity in real time.  It also stores a
        structured entry in ``_activity_log`` that the tool callback
        server exposes via ``GET /activity``.

        Parameters
        ----------
        action:
            Short label, e.g. ``"tool_call"`` or ``"agent_response"``.
        detail:
            Human-readable description of what happened.
        kind:
            Severity — ``"info"``, ``"success"``, ``"warn"``, or ``"error"``.
        data:
            Optional structured payload (tool args, result, etc.).
        sync:
            If True (default) and a client is available, immediately
            save memory so the UI refreshes.
        """
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        # Structured entry for the /activity endpoint.
        entry: dict[str, Any] = {
            "action": action,
            "detail": detail,
            "kind": kind,
            "timestamp": ts,
        }
        if data is not None:
            entry["data"] = data
        self._activity_log.append(entry)

        # Conversation turn for the Memory page.
        self._conversation_history.append(
            {"role": "user", "parts": [{"text": f"[{action}] {detail}"}], "timestamp": ts},
        )
        response_text = detail
        if data:
            try:
                truncated = json.dumps(data, indent=2, default=str)
                if len(truncated) > 500:
                    truncated = truncated[:500] + "\n..."
                response_text = truncated
            except (TypeError, ValueError):
                pass
        self._conversation_history.append(
            {"role": "model", "parts": [{"text": response_text}], "timestamp": ts},
        )

        # Push to cloud memory so the UI updates immediately.
        if sync and self._client is not None:
            try:
                self._client.set_memory(
                    self._memory_agent_key(), self._conversation_history,
                )
            except Exception as exc:
                err = str(exc).encode("ascii", "ignore").decode("ascii")
                print(f"  [WARN] Could not sync activity to memory: {err}")

    def _ensure_profile(self, client: OmniLinkClient) -> None:
        try:
            profiles = client.list_profiles()
            # Match by name (case-insensitive) so we never overwrite an
            # unrelated profile that just happens to be the most recent.
            matched = next(
                (p for p in profiles if (p.get("name") or "").lower() == self.agent_name.lower()),
                None,
            )
            if matched:
                pid = matched.get("id")
                self._profile_id = pid
                client.update_profile(pid, name=self.agent_name, settings=self.get_profile_settings())
                print(f"  Profile updated to '{self.agent_name}' (id={pid}).")
            else:
                result = client.create_profile(self.agent_name, settings=self.get_profile_settings())
                self._profile_id = result.get("id")
                print(f"  Profile '{self.agent_name}' created (id={self._profile_id}).")
        except Exception as e:
            err = str(e).encode("ascii", errors="ignore").decode("ascii")
            print(f"  Could not set profile (continuing anyway): {err}")

    def _save_memory(self, client: OmniLinkClient, summary: str) -> None:
        self._append_turn(
            "Report current state.",
            f"Command: none\nResponse: {summary}",
        )
        try:
            client.set_memory(self._memory_agent_key(), self._conversation_history)
        except Exception:
            pass

    _max_none_retries: int = 2

    def _ask_for_tool_command(self, client: OmniLinkClient, prompt: str) -> str | None:
        """Ask the agent for the next command via a tool call.

        Sends *prompt* (typically the current state + result of the last
        command) and parses the ``Command:`` line from the agent's response.
        Returns the command string, or ``None`` only if the agent explicitly
        said ``stop_game``.  If the agent says ``Command: none``, retries
        with a stronger nudge up to ``_max_none_retries`` times.
        """
        suffix = (
            "\n\nCRITICAL: You are in tool-execution mode. "
            "You MUST reply with a valid robot command in the Command: field. "
            "Do NOT use Command: none unless the operator explicitly said stop. "
            "Always issue the next command to continue the operator's task."
        )
        current_prompt = prompt
        for attempt in range(1 + self._max_none_retries):
            try:
                result = client.chat(
                    current_prompt,
                    agent_name=self.agent_name,
                    engine=self.engine,
                    system_instruction=self.get_system_instruction(),
                    system_instruction_suffix=suffix,
                    temperature=0.3,
                )

                # Handle native tool calls from the AI.
                tool_calls = result.get("toolCalls", [])
                if tool_calls:
                    tc = tool_calls[0]
                    name = tc.get("name", "")
                    if name == "stop_game":
                        return None
                    args = tc.get("arguments", {})
                    if isinstance(args, str):
                        args = json.loads(args)
                    # Build command string: name(key=val, ...)
                    if args:
                        arg_str = ", ".join(f"{k}={v!r}" for k, v in args.items())
                        return f"{name}({arg_str})"
                    return name

                raw = result.get("text", "")
                raw_clean = raw.encode("ascii", errors="ignore").decode("ascii")

                # Check for explicit stop.
                if re.search(r"(?i)Command:\s*stop_game", raw_clean):
                    return None

                # Check for none — retry with a nudge.
                if re.search(r"(?i)Command:\s*none\b", raw_clean):
                    if attempt < self._max_none_retries:
                        print(f"  << Agent replied Command: none — retrying ({attempt + 1}/{self._max_none_retries})...")
                        current_prompt = (
                            f"{prompt}\n\n"
                            f"You replied Command: none but the operator's request is NOT fully completed yet. "
                            f"Review the request again and send the next robot_command. "
                            f"Only use stop_game when every single part is done."
                        )
                        continue
                    return None

                # Extract the command value.
                m = re.search(r"(?i)^Command:\s*(.+)", raw_clean, re.MULTILINE)
                if m:
                    cmd = m.group(1).strip()
                    # Strip trailing Tool: lines that may follow.
                    cmd = re.split(r"\n", cmd)[0].strip()
                    if cmd:
                        return cmd
                return None
            except Exception as e:
                err = str(e).encode("ascii", errors="ignore").decode("ascii")
                print(f"  [WARN] Agent tool call failed: {err}")
                return None
        return None

    def _ask_agent(self, client: OmniLinkClient, question: str) -> str:
        try:
            result = client.chat(
                question,
                agent_name=self.agent_name,
                engine=self.engine,
                temperature=0.3,
            )
            raw = result.get("text", "")
            m = re.search(r"(?i)^Response:\s*(.+)", raw, re.MULTILINE | re.DOTALL)
            text = m.group(1).strip() if m else raw.strip()
            return text.encode("ascii", errors="ignore").decode("ascii")
        except Exception as e:
            return f"(could not reach agent: {e})"

    def _check_memory_command(self, client: OmniLinkClient) -> str | None:
        try:
            memory = client.get_memory(self._memory_agent_key())
            if not memory:
                return None
            for entry in memory:
                for part in entry.get("parts", []):
                    text = part.get("text", "")
                    if re.search(r"(?i)Command:\s*stop_game", text):
                        return "stop_game"
                    if re.search(r"(?i)Command:\s*pause_game", text):
                        return "pause_game"
                    if re.search(r"(?i)Command:\s*resume_game", text):
                        return "resume_game"
            return None
        except Exception:
            return None

    def _agent_should_stop(self, client: OmniLinkClient) -> tuple[bool, str]:
        try:
            result = client.chat(
                f"Review state. {self.tool_name} or stop_game.",
                agent_name=self.agent_name,
                engine=self.engine,
                system_instruction=self.get_review_instruction(),
                temperature=0.0,
            )
            raw = result.get("text", "")
            raw_clean = raw.encode("ascii", errors="ignore").decode("ascii")

            stop_called = bool(re.search(r"(?im)^\s*Command:\s*stop_game", raw_clean))
            m = re.search(
                r"(?i)^Response:\s*(.+?)(?=\n(?:Tool|Stop-Tool|Command):|\Z)",
                raw_clean, re.MULTILINE | re.DOTALL,
            )
            reason = m.group(1).strip() if m else raw_clean.strip()[:200]
            return stop_called, reason
        except Exception as e:
            return False, f"(could not reach agent: {e})"

    # ── Main entry point ──────────────────────────────────────────────

    def run(self) -> None:
        """Execute the full tool-calling loop."""
        if not self.omni_key:
            raise ValueError(
                "ToolRunner.omni_key is not set. Either:\n"
                "  1. Set the OMNI_KEY environment variable, or\n"
                "  2. Assign runner.omni_key before calling runner.run().\n"
                "Get a key from https://www.omnilink-agents.com/dashboard"
            )
        if not self.agent_name:
            raise ValueError(
                f"{type(self).__name__}.agent_name is empty. Set it as a class attribute, "
                "e.g. `agent_name = \"my-agent\"`."
            )
        self._conversation_history = []
        client = OmniLinkClient(omni_key=self.omni_key, base_url=self.base_url, timeout=60)
        self._client = client

        # Start tool callback server if any tools are defined.
        if (self.query_tools or self.default_tools) and not self.tool_callback_url:
            port = self._start_tool_server()
            scheme = "https" if self._ssl_enabled else "http"
            self.tool_callback_url = f"{scheme}://127.0.0.1:{port}/tool"
            print(f"  Tool callback server on port {port} ({scheme.upper()})")

        self._ensure_profile(client)

        # Clear stale memory from previous sessions so old stop_game
        # commands don't immediately halt this run.
        try:
            client.set_memory(self._memory_agent_key(), [])
        except Exception:
            pass

        # Kick off with one API call (retry with backoff on rate-limit errors).
        print("  Requesting tool call from OmniLink agent...")
        kickoff_ok = False
        for _kickoff_attempt in range(1 + self.max_kickoff_retries):
            try:
                result = client.chat(
                    f"Call {self.tool_name}.",
                    agent_name=self.agent_name,
                    engine=self.engine,
                    system_instruction=self.get_system_instruction(),
                    temperature=0.0,
                )
                raw = result.get("text", "").encode("ascii", errors="ignore").decode("ascii")
                tool_called = bool(re.search(rf"(?i)^Tool:\s*{re.escape(self.tool_name)}", raw, re.MULTILINE))
                if tool_called:
                    print(f"  Agent called Tool: {self.tool_name}")
                else:
                    print(f"  Agent responded (proceeding anyway): {raw.strip()[:80]}")
                kickoff_ok = True
                break
            except OmniLinkAPIError as e:
                if e.status_code == 429 and _kickoff_attempt < self.max_kickoff_retries:
                    delay = min(2 ** _kickoff_attempt * 5, 60)
                    print(f"  Rate-limited — retrying kickoff in {delay}s ({_kickoff_attempt + 1}/{self.max_kickoff_retries})...")
                    time.sleep(delay)
                    continue
                err = str(e).encode("ascii", errors="ignore").decode("ascii")
                print(f"  API call failed (proceeding with local engine): {err}")
                break
            except Exception as e:
                err = str(e).encode("ascii", errors="ignore").decode("ascii")
                print(f"  API call failed (proceeding with local engine): {err}")
                break

        print()
        print("=" * 60)
        print(f"  OmniLink {self.display_name} — AI Controller via Tool Call")
        print("=" * 60)
        print()

        self.on_start()

        last_memory_time = time.time()
        last_ask_time = time.time()
        paused = False

        _state_pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        while True:
            try:
                future = _state_pool.submit(self.get_state)
                state = future.result(timeout=5)
            except concurrent.futures.TimeoutError:
                print("  [WARN] get_state() timed out (5s), skipping tick")
                continue
            except Exception as e:
                print(f"  [ERROR] Cannot reach server: {e}")
                time.sleep(1)
                continue

            if self.is_game_over(state):
                print()
                print(f"  {self.game_over_message(state)}")
                break

            if not paused:
                self.execute_action(state)
                self.log_events(state)

            now = time.time()

            # Check for UI commands before overwriting memory.
            check_interval = 3 if paused else self.memory_every
            if now - last_memory_time >= check_interval:
                cmd = self._check_memory_command(client)
                if cmd == "stop_game":
                    self._send_game_command("PAUSE")
                    print()
                    print("  >> Stop requested from OmniLink UI.")
                    break
                elif cmd == "pause_game" and not paused:
                    self._send_game_command("PAUSE")
                    paused = True
                    print()
                    print("  >> Pause requested from OmniLink UI. Game paused.")
                elif cmd == "resume_game" and paused:
                    self._send_game_command("RESUME")
                    paused = False
                    print()
                    print("  >> Resume requested from OmniLink UI. Game resumed.")

                if not paused:
                    summary = self.state_summary(state)
                    self._save_memory(client, summary)
                last_memory_time = now

            # Periodic agent review.
            if now - last_ask_time >= self.ask_every:
                print()
                print(f"  >> Agent reviewing {self.display_name}...")
                stop, reason = self._agent_should_stop(client)
                if stop:
                    print(f"  << Agent called stop_game: {reason}")
                    print()
                    break
                else:
                    print(f"  << Agent called {self.tool_name}: {reason}")
                    print()
                last_ask_time = now

            time.sleep(self.poll_interval)

        # Final summary.
        print()
        print("=" * 60)
        try:
            final_state = self.get_state()
            final_summary = self.state_summary(final_state)
        except Exception:
            final_summary = "(could not fetch final state)"

        print(f"  {final_summary}")
        print("=" * 60)

        try:
            self._append_turn(
                "Session ended.",
                f"Command: stop_game\nResponse: {final_summary}",
            )
            client.set_memory(self._memory_agent_key(), self._conversation_history)
            print("  Game saved to OmniLink memory.")
        except Exception:
            pass

        print()
        print("  >> Asking agent for final analysis...")
        answer = self._ask_agent(client, "Summarize the game.")
        print(f"  << Agent: {answer}")
        print()
