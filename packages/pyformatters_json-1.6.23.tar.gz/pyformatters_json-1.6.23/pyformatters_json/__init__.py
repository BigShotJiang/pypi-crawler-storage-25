"""Sherpa Json formatter"""

__version__ = "1.6.23"
