import json

from pydantic import BaseModel
from pymultirole_plugins.v1.formatter import FormatterBase, FormatterParameters
from pymultirole_plugins.v1.schema import Document
from starlette.responses import JSONResponse, Response


class JsonParameters(FormatterParameters):
    pass


class JsonFormatter(FormatterBase):
    """Json formatter."""

    def format(self, document: Document, parameters: FormatterParameters) -> Response:
        """Parse the altTexts of the document and return a json response.

        :param document: An annotated document.
        :param options: options of the parser.
        :returns: Response.
        """
        parameters: JsonParameters = parameters
        try:
            alts = []
            if document.altTexts:
                altTexts = document.altTexts
                alts = {altText.name: altText.text for altText in altTexts}
                anames = list(alts.keys())
                for aname in anames:
                    atext = alts[aname]
                    result = None
                    try:
                        result = json.loads(atext)
                        alts[aname] = result
                    except json.JSONDecodeError:
                        del alts[aname]
            return JSONResponse(alts)
        except BaseException as err:
            raise err

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return JsonParameters
