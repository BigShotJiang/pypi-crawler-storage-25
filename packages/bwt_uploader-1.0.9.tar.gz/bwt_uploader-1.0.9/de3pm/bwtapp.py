
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

################################################
# BWT-Uploader v1.0.9 - Created by -= DE3PM =- #
################################################

import os
import traceback
import asyncio
from .src import *
from .tracker import BWTUploader


class BWTApp:

    def __init__(self):
        self.meta = {}
        self.meta_args = {}
        self.metadb = {}
        self.movie_poster_url = None


    def cr_scr(self):
        os.system("cls" if os.name == "nt" else "clear")
        

    async def ck_up(self):
        try:
            checker = CheckUp()
            await checker.che_f_ups()
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            error_exit()


    async def load_arguments(self):
        args = Args()
        self.meta_args = args.metadata

        if not self.meta_args or not self.meta_args.get("filepath"):
            console.print("[bold red]Error: Filepath is required.[/bold red]")
            error_exit()


    async def process_file(self):
        self.file_info = FilePathInfo(self.meta_args)
        self.meta = await self.file_info.process()

        console.print(
            f"[bold cyan]File Name:[/bold cyan] {self.meta.get('filename')}\n"
        )


    async def fetch_metadata(self):

        dbmeta = MetaDB()

        if self.meta.get("type") == "video":
            self.metadb = await dbmeta.process(self.meta)

            printer = MediaPrinter(self.metadb)
            await printer.run()

        elif self.meta.get("audio_music"):

            printer = MediaPrinter(self.meta)
            await printer.run()


    async def gen_mi(self):

        if self.meta.get("raw_bluray"):
            bdinfo = BDInfo()
            await bdinfo.scan(self.meta)
            
        elif self.meta.get("raw_dvd") or self.meta.get("video_media"):
            mi = MediaInfoEx()
            await mi.init(self.meta)
            await mi.save_media_info()


    async def cr_tot(self):

        torrent = Torrent()
        await torrent.create(self.meta)


    async def handle_ss_and_ps(self):

        if self.meta.get("type") != "video": 
            return

        screens = Screens()
        await screens.init(self.meta)
        await screens.gen_scr()
        await screens.up_ims()


    async def gen_descr(self):

        descr = Descr()
        metadb = self.metadb if self.meta.get("type") == "video" else None
        await descr.generate(self.meta, metadb)


    async def upload(self):
        
        uploader = BWTUploader()
        
        if self.meta.get("type") == "video":
            await uploader.setup(self.metadb)
            await uploader.upload(self.metadb)
            
        elif self.meta.get("type") == "music": 
            await uploader.setup(self.meta)
            await uploader.upload(self.meta)


    # Run Application
    async def run(self):

        try:

            self.cr_scr()
            await header(app_version)
            
            await self.load_arguments()
            
            await self.ck_up()
            await self.process_file()

            await self.fetch_metadata()

            await self.gen_mi()

            await self.cr_tot()

            await self.handle_ss_and_ps()

            await self.gen_descr()

            await self.upload()

            console.print(
                "\n[bold green]✔ Upload completed successfully![/bold green]\n"
            )

        except KeyboardInterrupt:

            console.print("\n[red]Process cancelled by user.[/red]")
            error_exit()

        except Exception as e:

            console.print("\n[bold red]Unexpected Error Occurred![/bold red]\n")
            #traceback.print_exc()
            console.print(f"[ERROR] {e}")
            console.print("Please reach out to @DE3PM for help.")
            error_exit()


async def run_cli():

    app = BWTApp()

    await app.run()
    

def main():
    try:
        asyncio.run(run_cli())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
    
##############
# -= DE3PM=- #
##############
