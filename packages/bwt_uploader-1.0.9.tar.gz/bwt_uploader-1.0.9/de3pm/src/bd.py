############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################



import re
import subprocess
import shutil
from pathlib import Path
from typing import Union
from ..bin import BDInfoInstaller
from .ia import console


class BDInfo:

    def __init__(self, binary: str | None = None):
        self.bdinfo_binary = binary
        self._installer = BDInfoInstaller()

    async def _load_file_info(self, meta):
        self.upload_folder = meta.get('upload_folder')
        self.filepath = meta.get('filepath')
        self.report_path = Path(self.upload_folder) / "BDINFO_QUICK_SUMMARY.txt"
        
    async def _ensure_binary(self):

        if self.bdinfo_binary and Path(self.bdinfo_binary).exists():
            return
        
        path_binary = shutil.which("bdinfo")
        if path_binary:
            self.bdinfo_binary = path_binary
            return
        
        self.bdinfo_binary = await self._installer.install()
        
        if not self.bdinfo_binary or not Path(self.bdinfo_binary).exists():
            raise RuntimeError("BDInfo binary not found after installation")
            
    async def run(
        self,
        path: Union[str, Path],
        summary: bool = False,
        main: bool = False,
        stdout: bool = False,
        forum: bool = False,
        report_file: Union[str, Path, None] = None,
        progress: bool = False,
        extra_args: list[str] | None = None,
    ):
        path = Path(path).resolve()

        if not path.exists():
            raise FileNotFoundError(f"Path not found: {path}")

        await self._ensure_binary()

            
        cmd = [self.bdinfo_binary, str(path)]

        flags = {
            "--summaryonly": summary,
            "--main": main,
            "--stdout": stdout,
            "--forumsonly": forum,
            "--progress": progress,
        }

        cmd.extend(flag for flag, enabled in flags.items() if enabled)

        if report_file:
            if report_file == "-":
                cmd.extend(["--reportfilename", "-"])
            else:
                report_path = Path(report_file)
                report_path.parent.mkdir(parents=True, exist_ok=True)
                cmd.extend(["--reportfilename", str(report_path)])

        if extra_args:
            cmd.extend(extra_args)

        console.print()
        console.print("[bold yellow]➤ Scanning BDInfo Quick Summary...[/bold yellow]")       
        subprocess.run(cmd, check=True)
        
    async def scan(self, meta):
        """
        Generate BDInfo output for Blu-ray sources
        """

        await self._load_file_info(meta)
        bluray_path = self.filepath

        if not bluray_path or not Path(bluray_path).exists():
            console.print("[red]Invalid Blu-ray path.[/red]")
            return
            
        try:
            if self.report_path.exists():
                console.print()
                console.print("[bold yellow]➤ BDInfo Quick Summary already exists...[/bold yellow]")
                return
        
            
            else:
                await self.run(
                    path=bluray_path,
                    summary=True,
                    main=True,
                    report_file=self.report_path,
                    progress=True,
                )

                if self.report_path.exists():
                    console.print("[bold green]✔ BDInfo scan completed.[/bold green]")
                    console.print()
                    return 
            
        except Exception as e:
            console.print(f"[red]BDInfo failed: {e}[/red]")
            return

    async def parse_quick_summary(self, meta):
        if not hasattr(self, "report_path") or not self.report_path:
            await self._load_file_info(meta)
        
        if not self.report_path:
            raise RuntimeError("BDInfo report path not initialized")
        
        if not self.report_path.exists():
            return None

        text = self.report_path.read_text(encoding="utf-8", errors="ignore")
        
        data = {}

        # Resolution
        match = re.search(r'(\d{3,4})p', text)
        data["resolution"] = match.group(1) if match else None

        # Audio languages
        langs = re.findall(r'Audio:\s*([A-Za-z]+)\s*/', text)
        data["audio_languages"] = list(set(langs))

        # Hindi audio
        data["hindi_audio"] = any(lang.lower() == "hindi" for lang in langs)

        # Audio codec
        match = re.search(r'Audio:.*?/\s*([A-Za-z\- ]+Audio)', text)
        data["audio_codec"] = match.group(1).strip() if match else None

        # Channels
        match = re.search(r'/\s*(\d\.\d)\s*/', text)
        data["channels"] = match.group(1) if match else None

        return data


#####################################
#     Created by -= DE3PM =-        #
#####################################
