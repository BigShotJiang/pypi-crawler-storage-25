
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import asyncio
import json
import os
from pathlib import Path
from pymediainfo import MediaInfo
from .ia import console
from .ex import error_exit


class MediaInfoEx:

    def __init__(self):
        self.filepath = None
        self.video_path = None
        self.upload_folder = None
        self.video_file_name = None

        self.mi_text_path = None
        self.mi_json_path = None

        self.data = None


    async def init(self, meta):
        self.filepath = meta.get("filepath")
        self.video_path = meta.get("videopath")
        self.upload_folder = meta.get("upload_folder")
        self.video_file_name = meta.get("video_filename")

        self.mi_text_path = str(Path(self.upload_folder) / "Media_Info.txt")
        self.mi_json_path = str(Path(self.upload_folder) / "MediaInfo.json")

    async def save_mi_text(self, filepath, media_info: str):
        """
        Save formatted MediaInfo text.
        """
        def write_file():
            lines = media_info.splitlines()
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(f"{self.video_file_name}\n\n")
                for line in lines:
                    if line.startswith("Complete name"):
                        f.write(
                            f"Complete name                            : {self.video_file_name}\n"
                        )
                    else:
                        f.write(line + "\n")

        await asyncio.to_thread(write_file)


    async def save_media_info(self):
        """
        Export MediaInfo as Text + JSON
        """
        console.print()
        console.print("[bold yellow]➤ Exporting MediaInfo...[/bold yellow]")

        try:
            if not os.path.isfile(self.video_path):
                raise FileNotFoundError(f"Video file not found: {self.video_path}")

            try:
                media_info_text = await asyncio.to_thread(
                    MediaInfo.parse,
                    self.video_path,
                    output="STRING",
                    full=False,
                    mediainfo_options={
                        "inform_version": "1",
                        "inform_timestamp": "1",
                    },
                )
            except Exception as e:
                raise RuntimeError(f"[ERROR] MediaInfo parse failed: {e}")
                error_exit()
            
            try:
                await self.save_mi_text(self.mi_text_path, media_info_text)
            except Exception as e:
                raise IOError(f"[ERROR] Mediainfo Saving text file failed: {e}")

            try:
                media_info = await asyncio.to_thread(MediaInfo.parse, self.video_path)
            except Exception as e:
                raise RuntimeError(f"[ERROR] MediaInfo parse failed: {e}")
                error_exit()

            try:
                data = json.loads(media_info.to_json())
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON from MediaInfo: {e}")

            tracks = data.get("tracks") or data.get("media", {}).get("track")

            if not tracks:
                raise ValueError("No tracks found in MediaInfo output.")

            def write_json():
                with open(self.mi_json_path, "w", encoding="utf-8") as f:
                    json.dump({"tracks": tracks}, f, indent=2)

            try:
                await asyncio.to_thread(write_json)
            except Exception as e:
                raise IOError(f"Saving JSON file failed: {e}")

            console.print("[green]✔ MediaInfo exported successfully[/green]")

        except FileNotFoundError as e:
            console.print(f"[bold red]File Error:[/bold red] {e}")
            raise

        except ValueError as e:
            console.print(f"[bold red]Data Error:[/bold red] {e}")
            raise

        except IOError as e:
            console.print(f"[bold red]IO Error:[/bold red] {e}")
            raise

        except RuntimeError as e:
            console.print(f"[bold red]Runtime Error:[/bold red] {e}")
            raise

        except Exception as e:
            console.print(f"[bold red]Unexpected Error:[/bold red] {e}")
            raise

    async def load_mediainfo_json(self):
        """
        Loads mediainfo JSON safely
        """
        if not os.path.exists(self.mi_json_path):
            await self.save_media_info()

        if not os.path.exists(self.mi_json_path):
            raise FileNotFoundError(f"MediaInfo JSON not found: {self.mi_json_path}")

        def read_json():
            with open(self.mi_json_path, "r", encoding="utf-8") as f:
                return json.load(f)

        try:
            return await asyncio.to_thread(read_json)

        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in {self.mi_json_path}: {e}")

        except Exception as e:
            raise RuntimeError(f"Failed to read MediaInfo JSON: {e}")


    async def mi_tracks(self):
        """
        Returns normalized track list
        """
        self.data = await self.load_mediainfo_json()

        tracks = (
            self.data.get("tracks")
            or self.data.get("media", {}).get("track")
            or self.data.get("MediaInfo", {}).get("media", {}).get("track")
        )

        if not tracks:
            raise ValueError("No track data found in MediaInfo JSON.")

        return tracks


    async def get_track(self, track_type: str):
        tracks = await self.mi_tracks()

        return next(
            (
                t
                for t in tracks
                if t.get("track_type") == track_type
                or t.get("@type") == track_type
            ),
            {},
        )


    async def get_tracks(self, track_type: str):
        tracks = await self.mi_tracks()

        return [
            t
            for t in tracks
            if t.get("track_type") == track_type
            or t.get("@type") == track_type
        ]


    async def fast_lang_code(self, track_type: str = "Audio"):
        tracks = await self.get_tracks(track_type)

        if not tracks:
            return None

        t = tracks[0]

        lang = (
            t.get("language")
            or t.get("Language")
            or (t.get("other_language") or [None])[0]
        )

        if not lang:
            return None

        return str(lang).strip().lower()


    async def has_hindi_audio(self):
        hindi_codes = {"hi", "hin", "hindi"}

        lang = await self.fast_lang_code("Audio")

        if not lang:
            return False

        return lang in hindi_codes


    async def get_resolution(self):

        video = await self.get_track("Video")

        if not video:
            return "UNKNOWN"

        width = video.get("width") or video.get("sampled_width")

        if not width:
            return "UNKNOWN"

        try:
            width = int(str(width).split()[0])
        except (TypeError, ValueError):
            return "UNKNOWN"

        scan_type = video.get("scan_type") or video.get("ScanType") or "Progressive"

        scan_flag = "i" if str(scan_type).lower().startswith("inter") else "p"

        if width >= 7680:
            res = "4320"
        elif width >= 3840:
            res = "2160"
        elif width >= 2560:
            res = "1440"
        elif width >= 1920:
            res = "1080"
        elif width >= 1280:
            res = "720"
        elif width >= 1024:
            res = "576"
        elif width >= 720:
            res = "480"
        else:
            res = "SD"

        return f"{res}{scan_flag}"
        
###############
# -= DE3PM =- #
###############
