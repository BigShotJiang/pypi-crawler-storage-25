############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

import os
import asyncio
from pathlib import Path
from typing import Optional, Set, Dict, Any

from ..data import Config
from .vid import VideoDetector


VIDEO_EXTENSIONS: Set[str] = {
    ".mp4", ".mkv", ".avi", ".mov", ".wmv",
    ".flv", ".webm", ".m2ts", ".vob"
}

AUDIO_EXTENSIONS: Set[str] = {
    ".mp3", ".flac", ".aac", ".m4a",
    ".wav", ".ogg"
}


class FilePathInfo:

    def __init__(self, meta: Dict[str, Any]):

        cfg = Config()
        cfg.load()

        self.uploads_logs_directory = cfg.get("uploads_logs_directory")

        self.meta = meta
        self.file_path: Path = Path(self.meta.get("filepath", "")).resolve()

        self.file_name: Optional[str] = None
        self.file_name_no_ext: Optional[str] = None
        self.media_path: Optional[Path] = None
        self.media_file_name: Optional[str] = None
        self.upload_folder: Optional[Path] = None
        self.torrent_path: Optional[Path] = None


    async def _find_largest_file(self, start_path: Path, extensions: Set[str]) -> Optional[Path]:

        extensions = {e.lower() for e in extensions}

        def scan():
            largest_file = None
            largest_size = -1
            stack = [start_path]

            while stack:
                current = stack.pop()

                try:
                    with os.scandir(current) as entries:
                        for entry in entries:
                            try:
                                if entry.is_dir(follow_symlinks=False):
                                    stack.append(entry.path)
                                    continue

                                suffix = Path(entry.name).suffix.lower()
                                if suffix not in extensions:
                                    continue

                                stat = entry.stat()
                                size = stat.st_size

                                if size > largest_size:
                                    largest_size = size
                                    largest_file = entry.path

                            except OSError:
                                continue

                except PermissionError:
                    continue

            return largest_file

        result = await asyncio.to_thread(scan)
        return Path(result) if result else None


    async def process(self) -> Dict[str, Any]:

        raw_bluray = False
        raw_dvd = False
        video_media = False
        audio_music = False
        audio_format = None
        source_type = None

        if not self.file_path.exists():
            raise FileNotFoundError(f"Invalid path: {self.file_path}")

        if self.file_path.is_file():

            self.file_name = self.file_path.name
            self.file_name_no_ext = self.file_path.stem
            self.media_path = self.file_path

            ext = self.file_path.suffix.lower()

            if ext in VIDEO_EXTENSIONS:
                video_media = True

            elif ext in AUDIO_EXTENSIONS:
                audio_music = True
                audio_format = ext.lstrip(".")

        elif self.file_path.is_dir():

            self.file_name = self.file_path.name
            self.file_name_no_ext = self.file_path.name

            bdmv_stream = self.file_path / "BDMV" / "STREAM"
            video_ts = self.file_path / "VIDEO_TS"

            # ---- RAW BLURAY ----
            if bdmv_stream.is_dir():
                self.media_path = await self._find_largest_file(bdmv_stream, VIDEO_EXTENSIONS)
                raw_bluray = True

            # ---- RAW DVD ----
            elif video_ts.is_dir():
                self.media_path = await self._find_largest_file(video_ts, VIDEO_EXTENSIONS)
                raw_dvd = True

            # ---- FOLDER ----
            else:
                self.media_path = await self._find_largest_file(self.file_path, VIDEO_EXTENSIONS)

                if self.media_path:
                    video_media = True
                else:
                    self.media_path = await self._find_largest_file(self.file_path, AUDIO_EXTENSIONS)

                    if self.media_path:
                        audio_music = True
                        audio_format = self.media_path.suffix.lstrip(".")

        if self.media_path:
            self.media_file_name = self.media_path.name

            if video_media:
                vi = VideoDetector(self.media_path)
                source_type = await asyncio.to_thread(vi.get_type)

        self.upload_folder = Path(self.uploads_logs_directory) / (
            self.file_name_no_ext or "media"
        )

        await asyncio.to_thread(
            self.upload_folder.mkdir,
            parents=True,
            exist_ok=True
        )

        self.torrent_path = self.upload_folder / f"{self.file_name_no_ext}.torrent"

        self.meta.update({
            "filename": self.file_name,
            "filename_noext": self.file_name_no_ext,
            "filepath": str(self.file_path),
            "upload_folder": str(self.upload_folder),
            "torrent_path": str(self.torrent_path),
        })
        
        if self.media_path:

            # ---- VIDEO ----
            if raw_bluray or raw_dvd or video_media:
                self.meta.update({
                    "type": "video",
                    "videopath": str(self.media_path),
                    "video_filename": self.media_file_name,
                })

                if raw_bluray:
                    self.meta["raw_bluray"] = True
                    self.meta["source_type"] = "Bluray DISC"

                elif raw_dvd:
                    self.meta["raw_dvd"] = True
                    self.meta["source_type"] = "DVD DISC"

                elif video_media:
                    self.meta["video_media"] = True
                    self.meta["source_type"] = source_type

            # ---- AUDIO ----
            elif audio_music:
                self.meta.update({
                    "type": "music",
                    "audio_music": audio_music,
                    "audiopath": str(self.media_path),
                    "audio_filename": self.media_file_name,
                    "audio_format": audio_format,
                })

            else:
                self.meta["type"] = "unknown"

        else:
            self.meta["type"] = "unknown"

        return self.meta
        
################################################
#           Created by  -= DE3PM =-            #
################################################
