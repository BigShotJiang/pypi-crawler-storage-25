############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import os

class VideoDetector:
    def __init__(self, video_path):
        self.video_path = video_path

    def get_type(self):
        filename = os.path.basename(self.video_path).lower()

        if any(word in filename for word in ["music video", "music videos", "music.video"]):
            return "MUSIC_VIDEO"
            
        if "remux" in filename:
            return "REMUX"

        elif any(word in filename for word in ["web-dl", "web.dl", "webdl", " web ", ".web."]):
            return "WEBDL"

        elif "webrip" in filename:
            return "WEBRIP"

        elif "hdtv" in filename:
            return "HDTV"

        elif "dvd" in filename and "rip" not in filename:
            return "DISC"

        elif "dvdrip" in filename:
            return "DVDRIP"

        else:
            return "ENCODE"


#####################################
#     Created by -= DE3PM =-        #
#####################################
