############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import aiohttp
import asyncio


class TMDb:
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("[TMDb] API key is required")

        self.api_key = api_key
        self.base_url = "https://api.themoviedb.org/3"
        self.session = None

    async def _get_session(self):
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()

    async def _fetch(self, url, params=None):
        session = await self._get_session()

        try:
            async with session.get(url, params=params, timeout=10) as res:
                res.raise_for_status()
                return await res.json()

        except asyncio.TimeoutError:
            print("[TMDb] request timeout")

        except aiohttp.ClientResponseError as e:
            print(f"[TMDb] HTTP error: {e.status} {e.message}")

        except aiohttp.ClientError as e:
            print(f"[TMDb] request failed: {e}")

        except Exception as e:
            print(f"[TMDb] unexpected error: {e}")

        return None
    
    async def search(self, title: str, year=None, media_type="movie"):
        if media_type not in {"movie", "tv"}:
            raise ValueError("[TMDb] Invalid Media Type")

        if not title:
            return None

        url = f"{self.base_url}/search/{media_type}"

        async def do_search(use_year=False):
            params = {
                "api_key": self.api_key,
                "query": title,
                "language": "en-US",
                "include_adult": False,
            }

            if use_year and year:
                key = "year" if media_type == "movie" else "first_air_date_year"
                params[key] = year

            data = await self._fetch(url, params)
            return data.get("results", []) if data else []

        results = await do_search(True)

        if not results:
            results = await do_search(False)

        if not results:
            return None

        for item in results:
            result_year = (
                item.get("release_date")
                or item.get("first_air_date")
                or ""
            )[:4]

            if year and result_year == str(year):
                return item.get("id")

        return results[0].get("id")

    async def get_id(self, imdb_id: str):
        if not imdb_id:
            return None

        url = f"{self.base_url}/find/{imdb_id}"
        params = {
            "api_key": self.api_key,
            "external_source": "imdb_id"
        }

        data = await self._fetch(url, params)

        if not data:
            return None

        if data.get("movie_results"):
            return data["movie_results"][0].get("id")

        if data.get("tv_results"):
            return data["tv_results"][0].get("id")

        return None

    async def get_external_ids(self, tmdb_id: int, media_type: str):
    
        if not tmdb_id:
            return None

        if media_type not in {"movie", "tv"}:
            raise ValueError("[TMDb] Invalid Media Type")

        url = f"{self.base_url}/{media_type}/{tmdb_id}/external_ids"

        params = {
            "api_key": self.api_key
        }

        data = await self._fetch(url, params)
        
        if not data:
            return None

        return {
            "imdb_id": data.get("imdb_id"),
            "tvdb_id": data.get("tvdb_id") 
        }
        

    async def get_trailer(self, tmdb_id: int, media_type: str):
        """
        Fetch trailer from TMDb.
        """

        if not tmdb_id or not media_type or not self.api_key:
            return {"title": None, "url": None}

        url = f"{self.base_url}/{media_type}/{tmdb_id}/videos"

        params = {
            "api_key": self.api_key
        }
        
        data = await self._fetch(url, params)

        if not data:
            return {"title": None, "url": None}  
            
        videos = data.get("results", [])

        for video in videos:
            if (
                video.get("site") == "YouTube"
                and video.get("type") == "Trailer"
                and video.get("key")
            ):
                return {
                    "title": video.get("name"),
                    "url": f"https://www.youtube.com/watch?v={video.get('key')}"
                }

        return {"title": None, "url": None}

    async def get_details(self, tmdbID: int, media_type: str):
        if media_type not in {"movie", "tv"}:
            raise ValueError("[TMDb] Invalid Media Type")

        details_url = f"{self.base_url}/{media_type}/{tmdbID}"
        credits_url = f"{self.base_url}/{media_type}/{tmdbID}/credits"

        params = {
            "api_key": self.api_key,
            "language": "en-US"
        }

        content, credits = await asyncio.gather(
            self._fetch(details_url, params),
            self._fetch(credits_url, params)
        )

        if not content or not credits:
            return None

        if media_type == "movie":
            date = content.get("release_date") or ""
            year = date.split("-")[0]

        else:  # tv
            date = (
                content.get("first_air_date")
                or content.get("last_air_date")
                or (content.get("last_episode_to_air") or {}).get("air_date")
                or ""
            )
            year = date.split("-")[0] if date else ""

        def format_runtime(runtime_min):
            if not runtime_min or runtime_min == "N/A":
                return "N/A"
            hours = runtime_min // 60
            minutes = runtime_min % 60
            return f"{hours}h {minutes}min" if hours else f"{minutes}min"

        runtime = "N/A"

        if media_type == "movie":
            runtime_val = content.get("runtime")
            runtime = format_runtime(runtime_val)

        else:  # tv
            runtimes = content.get("episode_run_time") or []

            if runtimes:
                runtime_val = runtimes[0]
            else:
                runtime_val = None
                
            if runtime_val:
                runtime = format_runtime(runtime_val)
            else:
                runtime = "N/A"
                
        genres = [
            g.get("name")
            for g in content.get("genres", [])
            if g.get("name")
        ]

        
        vote_avg = content.get("vote_average")
        rating = round(vote_avg, 1) if vote_avg is not None else None
        
        countries = content.get("production_countries") or []
        country = countries[0].get("name") if countries else "N/A"

        language = content.get("original_language", "")

        poster_path = content.get("poster_path")
        backdrop_path = content.get("backdrop_path")

        poster = f"https://image.tmdb.org/t/p/w780{poster_path}" if poster_path else None
        backdrop = f"https://image.tmdb.org/t/p/w780{backdrop_path}" if backdrop_path else None

        cast_data = credits.get("cast") or []

        cast = [
            {
                "name": c.get("name"),
                "character": c.get("character") or "N/A",
                "profile": f"https://image.tmdb.org/t/p/w185{c.get('profile_path')}"
                if c.get("profile_path") else None
            }
            for c in cast_data[:10]
            if c.get("name")
        ]

        crew_data = credits.get("crew") or []

        directors = []
        writers = []
        producers = []
        creators = []

        for c in crew_data:
            job = c.get("job")
            name = c.get("name")

            if not name:
                continue

            if job == "Director":
                directors.append(name)

            elif job in {"Writer", "Screenplay", "Story"}:
                writers.append(name)

            elif job in {"Producer", "Executive Producer"}:
                producers.append(name)

            elif job in {"Creator", "Original Series Creator"}:
                creators.append(name)

        def unique_list(lst):
            return list(dict.fromkeys(lst))

        directors = unique_list(directors)
        writers = unique_list(writers)
        producers = unique_list(producers)
        creators = unique_list(creators)

        return {
            "id": tmdbID,
            "title": content.get("title") or content.get("name", "Unknown"),
            "original_title": content.get("original_title") or content.get("original_name", "N/A"),
            "year": year,
            "release_date": date,
            "runtime_hms": runtime,
            "genres": genres,
            "rating": rating,
            "votes": content.get("vote_count", "N/A"),
            "overview": content.get("overview") or "No overview available.",

            # enriched fields
            "language": language,
            "country": country,
            "directors": directors or [],
            "writers": writers or [],
            "producers": producers or [],
            "creators": creators or [],
            "stars": cast or [],

            # Images
            "poster": poster,
            "backdrop": backdrop,

            # Links
            "tmdb_link": f"https://www.themoviedb.org/{media_type}/{tmdbID}",
            "more_posters": f"https://www.themoviedb.org/{media_type}/{tmdbID}/images/posters",
            "more_backdrops": f"https://www.themoviedb.org/{media_type}/{tmdbID}/images/backdrops",
        }


#####################################
#     Created by -= DE3PM =-        #
#####################################
