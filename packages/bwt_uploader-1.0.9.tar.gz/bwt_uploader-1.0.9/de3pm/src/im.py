############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import httpx
import asyncio
from typing import Optional, List, Dict


class IMDb:
    def __init__(self):
        self.imdb_api = "https://api.graphql.imdb.com/"
        self.imdb_api2 = "https://api.imdbapi.dev"

        self.headers = {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0",
            "Origin": "https://www.imdb.com",
            "Referer": "https://www.imdb.com/",
        }
        self.client = httpx.AsyncClient(timeout=10)

    async def _fetch_imdb(self, title: str, year: Optional[int]):
        constraints = [f'titleTextConstraint: {{searchTerm: "{title}"}}']

        if year:
            constraints.append(
                f"""
                releaseDateConstraint: {{
                    releaseDateRange: {{
                        start: "{year-1}-01-01",
                        end: "{year+1}-12-31"
                    }}
                }}
                """
            )

        query = {
            "query": f"""
            {{
                advancedTitleSearch(
                    first: 10,
                    constraints: {{{", ".join(constraints)}}}
                ) {{
                    edges {{
                        node {{
                            title {{
                                id
                                titleText {{ text }}
                                titleType {{ text }}
                                releaseYear {{ year }}
                            }}
                        }}
                    }}
                }}
            }}
            """
        }

        for attempt in range(3):
            try:
                r = await self.client.post(
                    self.imdb_api,
                    json=query,
                    headers=self.headers
                )
                r.raise_for_status()
                data = r.json()

                if "errors" not in data:
                    return data

            except Exception:
                await asyncio.sleep(1)

        return None

    async def _fetch_imdb2(self, title: str, year: Optional[int]):
        query = title if not year else f"{title} {year}"

        apisr_url = f"{self.imdb_api2}/search/titles"
        try:
            r = await self.client.get(
                apisr_url,
                params={"query": query}
            )
            r.raise_for_status()
            return r.json()

        except Exception:
            return None

    def _parse_imdb(self, data) -> List[Dict]:
        edges = data.get("data", {}).get("advancedTitleSearch", {}).get("edges", [])
        results = []

        for item in edges:
            title = item.get("node", {}).get("title", {})

            results.append({
                "id": title.get("id"),
                "title": title.get("titleText", {}).get("text"),
                "year": title.get("releaseYear", {}).get("year"),
                "type": (title.get("titleType", {}).get("text") or "").lower(),
            })

        return results
        
    def _parse_imdb2(self, data) -> List[Dict]:
        results = data.get("titles") or []

        parsed = []
        for item in results:
            parsed.append({
                "id": item.get("id"),
                "title": item.get("primary_title"),
                "year": item.get("start_year"),
                "type": (item.get("type") or "").lower(),
            })

        return parsed

    def _filter(self, results, file_type: str, year: Optional[int]):
        filtered = []

        for r in results:
            t = r["type"]

            if file_type == "movie":
                if "movie" not in t:
                    continue

            elif file_type == "episode":
                if not any(x in t for x in ["tv", "series"]):
                    continue

            filtered.append(r)

        if year:
            exact = [r for r in filtered if r["year"] == year]
            if exact:
                return exact

        return filtered or results

    def _best_match(self, results, name: str, year: Optional[int]):
        if not results:
            return None

        name = name.lower()

        def score(r):
            s = 0

            if r["title"]:
                t = r["title"].lower()

                if t == name:
                    s += 100
                elif name in t:
                    s += 50

            if year and r["year"] == year:
                s += 30

            return s

        results.sort(key=score, reverse=True)
        return results[0]

    async def search(
        self,
        name: str,
        year: Optional[int | str],
        file_type: str
    ) -> Optional[str]:
        results = []

        try:
            year = int(year) if year else None
        except (TypeError, ValueError):
            year = None

        data = await self._fetch_imdb2(name, year)

        if data:
            results = self._parse_imdb2(data)
        else:
            data = await self._fetch_imdb(name, year)

            if data:
                results = self._parse_imdb(data)
            
        if not results:
            return None

        results = self._filter(results, file_type, year)
        best = self._best_match(results, name, year)

        return best.get("id") if best else None


    async def get_details(self, imdbID: str) -> dict | None:
        """
        Fetch IMDb details asynchronously using IMDb ID.
        """

        if not imdbID:
            return None

        url = f"{self.imdb_api2}/titles/{imdbID}"

        try:
            r = await self.client.get(url)
            r.raise_for_status()
            movie = r.json()

            if not isinstance(movie, dict):
                return None

        except httpx.TimeoutException:
            return None
        except httpx.RequestError:
            return None
        except ValueError:
            return None
            
        # Runtime
        runtime = movie.get("runtimeSeconds")
        if isinstance(runtime, int) and runtime > 0:
            hours = runtime // 3600
            minutes = (runtime % 3600) // 60
            seconds = runtime % 60
            if hours:
                runtime_hms = f"{hours}h {minutes}min" + (f" {seconds}s" if seconds else "")
            else:
                runtime_hms = f"{minutes}min" + (f" {seconds}s" if seconds else "")
        else:
            runtime_hms = ""

        # Rating
        rating_data = movie.get("rating") or {}
        rating = rating_data.get("aggregateRating", "")
        votes = rating_data.get("voteCount", "")

        # Lists
        origin = movie.get("originCountries") or []
        languages = movie.get("spokenLanguages") or []
        directors = movie.get("directors") or []
        writers_data = movie.get("writers") or []
        stars_data = movie.get("stars") or []

        # Extract helpers
        country = origin[0].get("name") if origin else ""
        language = languages[0].get("code") if languages else ""

        director_names = [
            d.get("displayName")
            for d in directors
            if isinstance(d, dict) and d.get("displayName")
        ]

        writers = [
            w.get("displayName")
            for w in writers_data
            if isinstance(w, dict) and w.get("displayName")
        ]

        stars = [
            s.get("displayName")
            for s in stars_data[:5]
            if isinstance(s, dict) and s.get("displayName")
        ]

        poster = (
            movie.get("primaryImage", {}).get("url")
            if isinstance(movie.get("primaryImage"), dict)
            else ""
        )

        return {
            "id": movie.get("id", imdbID),
            "title": movie.get("primaryTitle", ""),
            "year": movie.get("startYear", ""),
            "runtime_hms": runtime_hms,
            "genres": movie.get("genres") or [],
            "rating": rating,
            "votes": votes,
            "plot": movie.get("plot", ""),
            "poster": poster or "",
            "country": country,
            "language": language,
            "directors": director_names or "",
            "stars": stars or "",
            "writers": writers or "",
            "link": f"https://www.imdb.com/title/{imdbID}/",
            "type": (movie.get("type") or "").upper(),
        }

    async def close(self):
        if self.client:
            await self.client.aclose()


#####################################
#     Created by -= DE3PM =-        #
#####################################
