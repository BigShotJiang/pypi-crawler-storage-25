############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import os
import base64
import json
import requests
import ffmpeg
import random
import asyncio
from ..data import Config
from .ia import console
from .ex import error_exit


class Screens:
    def __init__(self):
        try:
            cfg = Config()
            cfg.load()

            # Screenshot settings
            self.screenshots_num = cfg.get("screenshots_number")
            self.threads = cfg.get("upload_threads")

            # Image hosts
            self.image_host = cfg.get("image_host")
            self.fallback_image_host = cfg.get("fallback_image_host")
            self.fallback_image_host_2 = cfg.get("fallback_image_host_2")

            # API key dictionary
            self.image_host_api_keys = cfg.get("image_host_api_key")

            self.video_path = None
            self.video_filename = None
            self.upload_folder = None

        except Exception as e:
            console.print(f"[bold red]✖ Initialization error: {e}")
            error_exit()

    async def init(self, meta):
        try:
            self.video_path = meta.get("videopath")
            self.video_filename = meta.get("video_filename")
            self.upload_folder = meta.get("upload_folder")

            if not self.video_path or not os.path.exists(self.video_path):
                console.print("[bold red]✖ Video file not found.")
                error_exit()

        except Exception as e:
            console.print(f"[bold red]✖ Metadata error: {e}")
            error_exit()

    async def _get_duration(self):
        """Safely get video duration."""
        try:
            probe = await asyncio.to_thread(ffmpeg.probe, self.video_path)
            duration = float(probe["format"]["duration"])

            if duration <= 0:
                raise ValueError("Invalid video duration")

            return duration

        except ffmpeg.Error as e:
            console.print("[bold red]✖ FFmpeg probe failed.")
            console.print(f"[dim]{e.stderr.decode() if e.stderr else e}")
            error_exit()

        except Exception as e:
            console.print(f"[bold red]✖ Unable to read video duration: {e}")
            error_exit()

    def _generate_timestamps(self, duration, count):
        """
        Generate random timestamps between 10% and 90% of video duration.
        """
        start = duration * 0.10
        end = duration * 0.90

        timestamps = sorted(
            random.uniform(start, end) for _ in range(count)
        )

        return [round(t, 2) for t in timestamps]

    def _screenshot_exists(self, directory):
        """Check if screenshots already exist."""
        if not os.path.exists(directory):
            return False

        return any(
            f.lower().endswith((".png", ".jpg"))
            for f in os.listdir(directory)
        )

    async def _capture_frame(self, timestamp, output_path, quality):
        """Run FFmpeg frame extraction in thread."""
        try:
            await asyncio.to_thread(
                lambda: (
                    ffmpeg
                    .input(self.video_path, ss=timestamp)
                    .output(output_path, vframes=1, q=quality)
                    .run(overwrite_output=True, quiet=True)
                )
            )
            return os.path.exists(output_path)

        except ffmpeg.Error as e:
            console.print(f"[red]✖ FFmpeg error at {timestamp}s")
            console.print(
                f"[dim]{e.stderr.decode() if e.stderr else e}"
            )
            return False

    async def gen_scr(self):
        num_screenshots = self.screenshots_num
        quality = 2

        output_directory = os.path.join(self.upload_folder, "screenshots")
        os.makedirs(output_directory, exist_ok=True)

        if self._screenshot_exists(output_directory):
            console.print(
                "[bold green]✔ Screenshots already exist — skipping generation."
            )
            return

        duration = await self._get_duration()

        console.print(
            f"[bold yellow]➤ Generating {num_screenshots} screenshots..."
        )

        timestamps = self._generate_timestamps(duration, num_screenshots)

        success = 0
        failed = 0

        tasks = []

        for index, timestamp in enumerate(timestamps, start=1):

            output_path = os.path.join(
                output_directory,
                f"{self.video_filename}_screenshot_{index:02d}.png"
            )

            tasks.append(
                self._capture_frame(timestamp, output_path, quality)
            )

        results = await asyncio.gather(*tasks)

        for r in results:
            if r:
                success += 1
            else:
                failed += 1

        if success > 0:
            console.print(
                f"[bold green]✔ Screenshots completed: {success}/{num_screenshots}"
            )

        if failed > 0:
            console.print(
                f"[bold yellow]⚠ Failed screenshots: {failed}"
            )

        if success == 0:
            console.print(
                "[bold red]✖ No screenshots were generated."
            )
            error_exit()

    async def up_ims(self):

        primary_host = self.image_host
        fallback_1 = self.fallback_image_host
        fallback_2 = self.fallback_image_host_2

        primary_key = self.image_host_api_keys.get(primary_host)
        fallback_1_key = self.image_host_api_keys.get(fallback_1)
        fallback_2_key = self.image_host_api_keys.get(fallback_2)

        API_URLS = {
            "Freeimage": "https://freeimage.host/api/1/upload",
            "Imgbb": "https://api.imgbb.com/1/upload",
            "Imageride": "https://www.imageride.net/api/1/upload",
            "Lookmyimg": "https://lookmyimg.com/api/1/upload",
            "Onlyimg": "https://imgoe.download/api/1/upload",
            "PTScreen": "https://ptscreens.com/api/1/upload"
        }

        hosts = [
            (primary_host, primary_key),
            (fallback_1, fallback_1_key),
            (fallback_2, fallback_2_key)
        ]

         # Filter valid hosts
        hosts = [(h, k) for h, k in hosts if h in API_URLS and k]

        if not hosts:
            console.print("[bold red] ✖ No valid image hosts configured.")
            error_exit()

        folder = os.path.join(self.upload_folder, "screenshots")
        output_folder = os.path.join(folder, "uploaddata")
        os.makedirs(output_folder, exist_ok=True)

        bbcode_medium_path = os.path.join(output_folder, "bbcode_medium.txt")

        files = sorted(
            f.strip() for f in os.listdir(folder)
            if f.lower().endswith((".png", ".jpg", ".jpeg"))
        )

        if os.path.exists(bbcode_medium_path):
            console.print("[bold green]✔ Screenshots already uploaded. Skipping upload.")
            return

        if not files:
            console.print("[bold red]✘ No screenshots found to upload.")
            error_exit()

        console.print("[bold yellow]➤ Uploading Screenshots...")
        
        semaphore = asyncio.Semaphore(self.threads or 3)

        upload_results = []
        bbc_full, bbc_medium, bbc_thumb = [], [], []

        def upload_blocking(img):

            img_path = os.path.join(folder, img)

            with open(img_path, "rb") as f:
                img_base64 = base64.b64encode(f.read()).decode()

            for host, api_key in hosts:
                api_url = API_URLS[host]

                payload = {
                    "key": api_key,
                    "image": img_base64
                }

                try:
                    response = requests.post(api_url, data=payload, timeout=60)
                    response.raise_for_status()

                    data = response.json()

                    if not data.get("success"):
                        raise Exception(data.get("error", {}).get("message", "Unknown error"))

                    return img, data

                except Exception as e:
                    console.print(f"[yellow]⚠ {img} failed on {host}: {e}")
                    continue

            console.print(f"[bold red]✖ Upload failed for {img} (all hosts).")
            return None

        async def upload_single(img):
            async with semaphore:
                return await asyncio.to_thread(upload_blocking, img)

        tasks = [upload_single(img) for img in files]
        results = await asyncio.gather(*tasks)

        # Process results
        for result in results:
            if not result:
                continue

            img, img_response = result
            upload_results.append({img: img_response})

            data = img_response.get("data", {})

            url_full = data.get("url", "")
            url_viewer = data.get("url_viewer", "")
            url_medium = data.get("medium", {}).get("url", "")
            url_thumb = data.get("thumb", {}).get("url", "")

            if url_full and url_viewer:
                bbc_full.append(f"[url={url_viewer}][img]{url_full}[/img][/url]")

            if url_medium and url_viewer:
                bbc_medium.append(f"[url={url_viewer}][img]{url_medium}[/img][/url]")

            if url_thumb and url_viewer:
                bbc_thumb.append(f"[url={url_viewer}][img]{url_thumb}[/img][/url]")

        # Save outputs
        with open(os.path.join(output_folder, "upload_responses.json"), "w") as f:
            json.dump(upload_results, f, indent=4)

        with open(os.path.join(output_folder, "bbcode_full.txt"), "w") as f:
            f.write("\n\n".join(bbc_full))

        with open(os.path.join(output_folder, "bbcode_medium.txt"), "w") as f:
            f.write("\n\n".join(bbc_medium))

        with open(os.path.join(output_folder, "bbcode_thumb.txt"), "w") as f:
            f.write("\n\n".join(bbc_thumb))

        console.print("[bold green]✔ Screenshots uploaded successfully.")
        

#####################################
#     Created by -= DE3PM =-        #
#####################################
