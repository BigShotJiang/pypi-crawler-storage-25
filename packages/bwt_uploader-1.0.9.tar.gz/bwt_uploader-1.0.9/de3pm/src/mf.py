############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import json
import os
import asyncio

class Meta:
    def __init__(self):
        self.metapath = None

    async def _get_metapath(self, meta: dict) -> str:
        if not isinstance(meta, dict):
            raise TypeError("[Error] meta must be a dict")

        upload_folder = meta.get("upload_folder")
        if not upload_folder:
            raise ValueError("[Error] upload folder is required")

        self.metapath = f"{upload_folder}/meta.json"
        return self.metapath

    async def save_meta(self, meta: dict) -> str:
        path = await self._get_metapath(meta)

        def write():
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(meta, f, indent=4, ensure_ascii=False)

        await asyncio.to_thread(write)

    async def get_meta(self, meta: dict) -> dict:
        path = await self._get_metapath(meta)

        if not os.path.exists(path):
            raise FileNotFoundError(f"[Error] meta file not found at {path}")

        def read():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)

        return await asyncio.to_thread(read)
        

#####################################
#     Created by -= DE3PM =-        #
#####################################
