
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import asyncio
import json
from guessit import guessit
from rich.prompt import Prompt

from ..data import Config
from .mf import Meta
from .im import IMDb
from .tm import TMDb
from .ia import console
from .ex import error_exit


class MetaDB:
    def __init__(self):
        self.imdb = IMDb()
        self.tmdb = None
        self.cfg = Config()
        self.tmdb_api_key = None

    async def load_config(self):
        await asyncio.to_thread(self.cfg.load)
        self.tmdb_api_key = self.cfg.get_nested("TMDb", "API_KEY")
        self.tmdb = TMDb(self.tmdb_api_key)

    async def process(self, meta: dict):
        await self.load_config()

        try:
            imdbID = self._extract_imdb_id(meta)
            tmdbID = meta.get("tmdbID")
            filename = meta.get("filename", "")

            skip_youtube = meta.get("skip_youtube", False)
            skip_tmdb = meta.get("skip_tmdb", False)
            skip_imdb_tmdb = meta.get("skip_imdb_tmdb", False)

            info = await asyncio.to_thread(guessit, filename)
            title = info.get("title")
            year = info.get("year")
            file_type = info.get("type")
            
            if file_type in ("movie",):
                media_type = "movie"
            elif file_type in ("episode", "tv", "series", "show"):
                media_type = "tv"
            else:
                media_type = "music"


            # IMDb ID
            if not imdbID and not skip_imdb_tmdb:
                imdbID = await self._fetch_imdb_id(title, year, file_type)

            # TMDb ID
            if not tmdbID and not skip_tmdb and not skip_imdb_tmdb:
                tmdbID = await self._fetch_tmdb_id(imdbID, title, year, media_type)

            # Get IDs from TMDb
            if not imdbID and tmdbID:
                fetched_imdb, fetched_tvdb = await self._get_ids_from_tmdb(tmdbID, media_type)
                imdbID = fetched_imdb
                
               # if media_type == "tv" and not tvdbID:
                   # tvdbID = fetched_tvdb

            imdb_details = await self._fetch_imdb_details(imdbID)
            tmdb_details = await self._fetch_tmdb_details(tmdbID, media_type)

            trailer_info = await self._fetch_trailer(
                tmdbID,
                media_type,
                skip_tmdb,
                skip_youtube,
                skip_imdb_tmdb
            )

            meta.update({
                "imdbID": imdbID,
                "tmdbID": tmdbID,
                "category_type": media_type,
                "imdb": imdb_details,
                "tmdb": tmdb_details,
                "trailer": trailer_info
            })

            await Meta().save_meta(meta)
            return meta

        finally:
            await self.close()

    async def close(self):
        try:
            if self.imdb:
                await self.imdb.close()
        except Exception:
            pass

        try:
            if self.tmdb:
                await self.tmdb.close()
        except Exception:
            pass

    def _extract_imdb_id(self, meta):
        imdb_id = meta.get("imdbID")
        if imdb_id:
            return imdb_id if imdb_id.startswith("tt") else f"tt{imdb_id}"
        return None

    async def _fetch_imdb_id(self, title, year, file_type):
        console.print("[bold yellow]Fetching IMDb ID from filename...[/bold yellow]")
        imdbID = await self.imdb.search(title, year, file_type)
        return imdbID or None

    async def ask_imdb_id(self):
        imdb_id = await asyncio.to_thread(
            Prompt.ask,
            "[bold red]IMDb ID not found.\nEnter the correct IMDb ID:[/bold red]"
        )
        return imdb_id if imdb_id.startswith("tt") else f"tt{imdb_id}"

    async def _fetch_imdb_details(self, imdbID):
        if not imdbID:
            return {}

        console.print("[bold yellow]Fetching IMDb Metadata...[/bold yellow]")
        return await self.imdb.get_details(imdbID)

    async def _get_ids_from_tmdb(self, tmdbID, media_type):
        if not tmdbID:
            return None, None

        external_ids = await self.tmdb.get_external_ids(tmdbID, media_type)

        if not external_ids:
            return None, None

        return (
            external_ids.get("imdb_id"),
            external_ids.get("tvdb_id")
        )

    async def _fetch_tmdb_id(self, imdbID, title, year, media_type):
        if not self.tmdb_api_key:
            console.print("[bold red]Error: TMDb API key is missing.[/bold red]")
            error_exit()

        tmdbID = None

        if imdbID:
            console.print("[bold green]Fetching TMDb ID from IMDb...[/bold green]")
            tmdbID = await self.tmdb.get_id(imdbID)

        if not tmdbID:
            console.print("[bold green]Fetching TMDb ID from filename...[/bold green]")
            tmdbID = await self.tmdb.search(title, year, media_type)

        if not tmdbID:
            tmdbID = await self.ask_tmdb_id()

        return tmdbID

    async def ask_tmdb_id(self):
        tmdbID = await asyncio.to_thread(
            Prompt.ask,
            "[bold red]TMDb ID not found.\nEnter the correct TMDb ID:[/bold red]"
        )
        return int(tmdbID)

    async def _fetch_tmdb_details(self, tmdbID, media_type):
        if not tmdbID:
            return {}

        console.print("[bold green]Fetching TMDb Metadata...[/bold green]")
        return await self.tmdb.get_details(tmdbID, media_type)

    async def _fetch_trailer(self, tmdbID, media_type,
                             skip_tmdb, skip_youtube, skip_imdb_tmdb):
        if skip_tmdb or skip_youtube or skip_imdb_tmdb or not tmdbID:
            return {"title": None, "url": None}

        console.print("[bold magenta]Fetching YouTube Trailer...[/bold magenta]")
        return await self.tmdb.get_trailer(tmdbID, media_type)

        
#####################################
#     Created by -= DE3PM =-        #
#####################################
