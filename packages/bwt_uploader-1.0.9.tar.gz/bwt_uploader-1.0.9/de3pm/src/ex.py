
##############################################
# BWT-Uploader v1.0.9 - Created by -=DE3PM=- #
##############################################

import sys
from .ia import console

def error_exit(code: int = 1):
    """
    Exits the program with an error message and a non-zero exit code.
    """
    
    console.print("[red]Exiting...[/red]")
    console.print("[red]We are not Uploading...[/red]")
    
    sys.exit(code)

##############
# -= DE3PM=- #
##############
