
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.0.9  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

from .ia import console
from rich.table import Table
from rich.prompt import IntPrompt
from langcodes import Language
from .mi import MediaInfoEx
from .bd import BDInfo


CATGROUPS = {
    1: ("Bollywood", [
        (119, "Bollywood-Untouched WEB-DLs"),
        (120, "Bollywood - 1080p WEB-Rips"),
        (188, "Bollywood - 720p WEB-Rips"),
        (115, "Bollywood-Untouched BluRay"),
        (118, "Bollywood-Remuxes BluRay"),
        (116, "Bollywood-1080p BluRay Rips"),
        (117, "Bollywood-720p BluRay Rips"),
        (124, "Bollywood-3D-Movies"),
        (121, "Bollywood-Untouched DVDs"),
        (122, "Bollywood-DVDRips 1080p/720p"),
        (189, "Bollywood-Encoded DVDs"),
        (123, "Bollywood - SDRips - WEB/DVD"),
        (114, "Bollywood-4K Ultra HD / Upscal"),
        (190, "Bollywood-Movie Packs"),
        (113, "Bollywood-Pre-Release"),
        (125, "Bollywood- Web Series"),
        (178, "Anime"),
    ]),
    2: ("Hollywood", [
        (131, "Hollywood-Untouched WEB-DLs"),
        (132, "Hollywood-1080p WEB-Rips"),
        (192, "Hollywood - 720p WEB-Rips"),
        (127, "Hollywood-Untouched BluRay"),
        (130, "Hollywood-BluRay Remuxes"),
        (128, "Hollywood-1080p BluRay Rips"),
        (129, "Hollywood-720p BluRay Rips"),
        (135, "Hollywood-3D-Movies"),
        (133, "Hollywood-Untouched DVDs"),
        (134, "Hollywood-DVDRips 1080p/720p"),
        (191, "Hollywood-Encoded DVDs"),
        (193, "Hollywood- SDRips - WEB/DVD"),
        (126, "Hollywood-4K Ultra HD / Upscal"),
        (194, "Hollywood - Movie Packs"),
        (136, "Hollywood-Pre-Release"),
        (178, "Anime"),
    ]),
    3: ("Tamil", [
        (210, "Tamil-Untouched WEB-DLs"),
        (211, "Tamil-1080p/720p WEBRips"),
        (212, "Tamil-Untouched BluRay"),
        (217, "Tamil-Remuxes BluRay"),
        (216, "Tamil-BluRay Rips"),
        (213, "Tamil-Untouched DVDs"),
        (214, "Tamil-SD-WEBRips / DVDRips"),
        (209, "Tamil-4K Ultra HD - Upscaled"),
        (215, "Tamil-Movie Packs"),
        (178, "Anime"),
    ]),
    4: ("Telugu", [
        (200, "Telugu-Untouched WEB-DLs"),
        (201, "Telugu-1080p/720p WEBRips"),
        (202, "Telugu-Untouched BluRay"),
        (208, "Telugu-Remuxes BluRay"),
        (207, "Telugu-BluRay Rips"),
        (203, "Telugu-Untouched DVDs"),
        (204, "Telugu-SD-WEBRips / DVDRips"),
        (199, "Telugu-4K Ultra HD - Upscaled"),
        (205, "Telugu-Movie Packs"),
        (178, "Anime"),
    ]),
    5: ("Hindi Dubbed", [
        (184, "South Hindi Dubbed"),
        (183, "English Movies Hindi Dubbed"),
        (197, "Turkish Hindi Dubbed"),
        (178, "Anime"),
    ]),
     6: ("Regional", [
        (145, "Bangla-Movies"),
        (143, "Bhoipuri-Movies"),
        (185, "Gujarati-Movies"),
        (141, "Kannada-Movies"),
        (142, "Lollywood-Movies"),
        (137, "Malayalam-Movies"),
        (144, "Marathi-Movies"),
        (140, "Punjabi-Movies"),
        (178, "Anime"),
    ]),
    7: ("TV Series", [
        (125, "Bollywood- Web Series"),
        (157, "TV-Hollywood"),
        (147, "TV - &Tv"),
        (146, "TV-Colors"),
        (221, "TV-JioTv"),
        (148, "TV-Life OK"),
        (198, "TV-MTV"),
        (158, "TV-Others"),
        (195, "TV-Packs"),
        (149, "TV-Pakistani Dramas"),
        (150, "TV-Sab TV"),
        (151, "TV-Sony"),
        (155, "TV-Sports"),
        (152, "TV-Star Bharat"),
        (153, "TV-Star Plus"),
        (154, "TV-Zee TV"),
        (156, "TV-Documentary"),
        (218, "TV-Ishara TV"),
        (219, "TV-Bengali"),
        (220, "TV-Shemaroo Umang"),
        (178, "Anime"),
    ]),
    8: ("Music", [
        (196, "Music Packs"),
        (160, "Music-Classical"),
        (161, "Music-Flacs"),
        (162, "Music-Ghazals"),
        (163, "Music-Hindi OSTs"),
        (164, "Music-Instrumental"),
        (165, "Music-Kannada Music"),
        (166, "Music-Lollywood Music"),
        (167, "Music-Malayalam Music"),
        (168, "Music-Marathi Music"),
        (170, "Music-Pop-Music"),
        (171, "Music-Punjabi-Music"),
        (172, "Music-Remix"),
        (173, "Music-Tamil Music"),
        (174, "Music-Telugu Music"),
        (169, "Music-Videos"),
    ])
}


MUSIC_CATGROUPS = {
    1: ("Music", [
        (196, "Music Packs"),
        (160, "Music-Classical"),
        (161, "Music-Flacs"),
        (162, "Music-Ghazals"),
        (163, "Music-Hindi OSTs"),
        (164, "Music-Instrumental"),
        (165, "Music-Kannada Music"),
        (166, "Music-Lollywood Music"),
        (167, "Music-Malayalam Music"),
        (168, "Music-Marathi Music"),
        (170, "Music-Pop-Music"),
        (171, "Music-Punjabi-Music"),
        (172, "Music-Remix"),
        (173, "Music-Tamil Music"),
        (174, "Music-Telugu Music"),
        (169, "Music-Videos"),
    ])
}

class GetCatCode:
    
    async def get_category(self, meta):

        if meta.get("audio_music"):
            fmt = (meta.get("audio_format") or "").lower()
            if fmt == "flac":
                return 161
            
            if fmt in ("m4a", "mp3"):
                return 163
            
        bdinfo_data = None
        if meta.get("raw_bluray"):
            bd = BDInfo()
            bdinfo_data = await bd.parse_quick_summary(meta)

        file_fast_lang = None
        hindi_audio = False
        resolution = None
        
        if bdinfo_data:
            resolution = bdinfo_data.get("resolution")
            hindi_audio = bdinfo_data.get("hindi_audio")
        
        elif meta.get("video_media"):          
            minfo = MediaInfoEx()
            await minfo.init(meta)
            resolution = str(await minfo.get_resolution()).replace("p", "")
            file_fast_lang = await minfo.fast_lang_code()
            hindi_audio = await minfo.has_hindi_audio()
            
        
        lang_code = (
            meta.get("imdb", {}).get("language", "") or
            meta.get("tmdb", {}).get("language", "")
        )
        source = meta.get("source_type", "").upper()
        filename = meta.get("filename", "").lower()
        type_cat = meta.get("imdb", {}).get("type", "").lower()
        fast_hindi = file_fast_lang in {"hi", "hin", "hindi"} if file_fast_lang else False
        is_tv = type_cat.startswith("tv")
 
        try:
            language = Language.get(lang_code).display_name("en").lower()
        except Exception:
            return None
            
        # Music Video 
        if source == "MUSIC_VIDEO":
            return 169
            
        if language == "hindi":

            # WEB Series 
            if is_tv:
                return 125

            # 4K
            if resolution == "2160":
                return 114
          
            # WEBDL
            if source == "WEBDL":
                return 119
        
            # WEBRIP
            if source == "WEBRIP":
                if resolution == "1080":
                    return 120
                if resolution == "720":
                    return 188
            
            # Raw Bluray
            if meta.get("raw_bluray") is True:
                return 115

            # REMUX Bluray
            if source == "REMUX" and "bluray" in filename:
                return 118

            # ENCODE Bluray 
            if source == "ENCODE" and "bluray" in filename:
                if resolution == "1080":
                    return 116                                 
                if resolution == "720":
                    return 117

            # Raw DVD
            if meta.get("raw_dvd"):
                return 121
                
            # DVDRips
            if source == "DVDRIPS":
                return 122            

            # 480p fallback
            if resolution == "480":
                return 123

        if meta.get("video_media"):
            if language != "hindi" and hindi_audio and fast_hindi:
                if language == "english":
                    return 183
                
                if language in {"tamil", "telugu", "malayalam", "kannada"}:
                    return 184
                
                if language in {"bangla", "bengali"} and is_tv:
                    return 125
                    
        if language == "english":

            # WEB Series 
            if is_tv:
                return 157

            # 4K 
            if resolution == "2160":
                return 126
                
            # WEBDL
            if source == "WEBDL":
                return 131

            # WEBRIP
            if source == "WEBRIP":
                if resolution == "1080":
                    return 132
                if resolution == "720":
                    return 192
            
            # Raw Bluray
            if meta.get("raw_bluray"):
                return 127

            # REMUX Bluray
            if source == "REMUX" and "bluray" in filename:
                return 130

            # ENCODE Bluray 
            if source == "ENCODE" and "bluray" in filename:
                if resolution == "1080":
                    return 128                                 
                if resolution == "720":
                    return 129

            # Raw DVD
            if meta.get("raw_dvd"):
                return 133
                
            # DVDRips
            if source == "DVDRIPS":
                return 134          

            # 480p fallback
            if resolution == "480":
                return 193
            
        if language == "tamil":

            # 4K
            if resolution == "2160":
                return 209
                
            # WEBDL
            if source == "WEBDL":
                return 210
                
            # WEBRIP
            if source == "WEBRIP":
                return 211
            
            # Raw Bluray
            if meta.get("raw_bluray"):
                return 212

            # REMUX Bluray
            if source == "REMUX" and "bluray" in filename:
                return 217

            # ENCODE Bluray 
            if source == "ENCODE" and "bluray" in filename:
                return 216

            # Raw DVD
            if meta.get("raw_dvd"):
                return 213
                
            # DVDRips
            if source == "DVDRIPS":
                return 214            

            # 480p fallback
            if resolution == "480":
                return 214
            
        if language == "telugu":

            # 4K
            if resolution == "2160":
                return 199
                
            # WEBDL
            if source == "WEBDL":
                return 200
                
            # WEBRIP
            if source == "WEBRIP":
                return 201
            
            # Raw Bluray
            if meta.get("raw_bluray"):
                return 202

            # REMUX Bluray
            if source == "REMUX" and "bluray" in filename:
                return 208

            # ENCODE Bluray 
            if source == "ENCODE" and "bluray" in filename:
                return 207

            # Raw DVD
            if meta.get("raw_dvd"):
                return 203
                
            # DVDRips
            if source == "DVDRIPS":
                return 204            

            # 480p fallback
            if resolution == "480":
                return 204
                    
        if language == "malayalam":
            return 137             
        if language == "kannada":
            return 141
        if language == "punjabi":
            return 140
        if language == "gujarati":
            return 185
        if language == "bhojpuri":
            return 143
        if language == "marathi":
            return 144

        if language == "bangla":
            if type_cat == "movie":
                return 145
            if is_tv:
                return 219

        if language:
            if is_tv:
                return 158

        return None
    
    async def select_category(self, audio_music):

        console.print("\n[bold cyan]Select a Main Category:[/bold cyan]")
        
        filtered_groups = MUSIC_CATGROUPS if audio_music else CATGROUPS
        
        for group_id, (name, _) in filtered_groups.items():
            console.print(f" [bold yellow]{group_id}[/bold yellow]. {name}")

        group_choice = IntPrompt.ask(
            "\nEnter category number",
            choices=[str(i) for i in filtered_groups]
        )

        group_name, subcats = filtered_groups[group_choice]

        console.print("\n")

        table = Table(title=f"{group_name} Categories", header_style="bold magenta")
        table.add_column("No.", width=4)
        table.add_column("Category Name", style="bold")
        table.add_column("Code", style="green", justify="right")

        for i, (code, name) in enumerate(subcats, 1):
            table.add_row(str(i), name, str(code))

        console.print(table)

        sub_choice = IntPrompt.ask(
            "\nEnter subcategory number",
            choices=[str(i) for i in range(1, len(subcats) + 1)]
        )

        selected_code, selected_name = subcats[sub_choice - 1]

        console.print(f"\n[bold green]Selected:[/bold green] {selected_name}")
        console.print(f"[bold blue]Category Code:[/bold blue] {selected_code}\n")

        return selected_code
    
    async def get_category_name(self, category_id):
        for group_id, (group_name, subcats) in CATGROUPS.items():
            for code, name in subcats:
                if code == category_id:
                    return name
        return "Unknown Category"


#####################################
#     Created by -= DE3PM =-        #
#####################################
