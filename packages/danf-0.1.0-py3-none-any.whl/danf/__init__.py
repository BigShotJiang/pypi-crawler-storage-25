"""DANF — Differential Algebra Normal Forms.

Nonlinear normal form analysis of symplectic maps using differential algebra.
Built on DACEyPy (DACE Python interface).

Inspired by COSY INFINITY (Berz, Makino, Michigan State University).
"""

from danf.normalform import NormalForm

__version__ = "0.1.0"
__all__ = ["NormalForm"]
