# neruva-langchain

Drop-in LangChain integration for [Neruva](https://neruva.io) agent memory.
Three wrappers cover the common LangChain plug points: chat history,
conversation memory, and document retriever.

```bash
pip install neruva-langchain
```

## What's new in the substrate (v0.5.7, May 2026)

The substrate this adapter wraps has gained a lot since the last release.
All of it is available via the same `agent_*` API the wrappers already
call, so existing code keeps working — new capabilities just become
available.

- **Deterministic replay** — every query is bit-identical across reruns
  from the same seed. Replay any past state for audit or debugging.
- **Typed-shape context** — pull structured JSON from records with
  per-field citations. `{question, shape: {field: type}}` → typed
  result without an LLM at query time. Natural fit for tool-calling
  chains that need a specific output schema.
- **Tenant-specific PII rules** — register your custom ID formats
  (employee codes, patient codes, order IDs) from 3-5 examples. The
  substrate redacts them automatically. Sub-microsecond per span.
- **Depth-unlimited nested-belief tracking** — store and retrieve
  chains like `Alice → Bob → Carol thinks X` at any depth, with
  inner-position-swap rejection.
- **Counterfactual rollouts** — "what if action k had been a' instead?"
  Replay an action sequence with one step substituted.
- **Active inference planning** — score candidate action sequences
  by KL distance to a goal-marginal. Caller-owned dynamics.
- **Continual K-gram learning** — provable no-forgetting via
  integer-add commutativity; repeated `train()` calls accumulate.

## NeruvaChatMessageHistory

Auto-records every turn into the Neruva Records substrate. Drop into any
LangChain primitive that accepts a `BaseChatMessageHistory`:

```python
from neruva_langchain import NeruvaChatMessageHistory

history = NeruvaChatMessageHistory(
    api_key="nv_...",          # or env NERUVA_API_KEY
    namespace="user_alice",    # one per user / session
)

history.add_user_message("My name is Alice and I live in Toronto.")
history.add_ai_message("Nice to meet you, Alice!")

# Later — even after process restart, substrate-backed:
print(history.messages)
```

## Use with RunnableWithMessageHistory (modern pattern)

```python
from langchain_anthropic import ChatAnthropic
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from neruva_langchain import NeruvaChatMessageHistory

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}"),
])
chain = prompt | ChatAnthropic(model="claude-opus-4-7")

chain_with_history = RunnableWithMessageHistory(
    chain,
    lambda session_id: NeruvaChatMessageHistory(namespace=session_id),
    input_messages_key="input",
    history_messages_key="history",
)
chain_with_history.invoke(
    {"input": "What did I tell you about my project last week?"},
    config={"configurable": {"session_id": "user_alice"}},
)
```

## NeruvaContextRetriever

`BaseRetriever` for `RetrievalQA` chains. Returns `Document` objects
sourced from federated `agent_recall`:

```python
from neruva_langchain import NeruvaContextRetriever
from langchain.chains import RetrievalQA
from langchain_anthropic import ChatAnthropic

retriever = NeruvaContextRetriever(
    api_key="nv_...",
    namespaces=["session_a", "session_b"],   # multi-session fan-out
)
qa = RetrievalQA.from_chain_type(
    llm=ChatAnthropic(model="claude-opus-4-7"),
    retriever=retriever,
)
qa.invoke("Where does Alice work?")
```

## Why use Neruva instead of LangChain's built-in memory?

| Feature | LangChain default | Neruva |
|---|---|---|
| Persists across process restart | Manual setup | Built-in (GCS-backed) |
| Cross-session recall | No | Yes via `namespaces=[...]` |
| Fact extraction (KG) | No | Auto (`hd_kg_extraction_prompt` + caller LLM) |
| GDPR forget by user | Manual | `user_id=` auto-folds, one-call forget |
| Determinism / replayability | No | Bit-identical from seed |
| Portability | Pickle | `.neruva` zip container |

[Get an API key](https://app.neruva.io) · [Docs](https://neruva.io/docs/) · [Status](https://status.neruva.io)
