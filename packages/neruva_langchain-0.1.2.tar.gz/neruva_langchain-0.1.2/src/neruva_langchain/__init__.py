"""LangChain integration for Neruva agent memory.

Two drop-in wrappers covering the modern LangChain plug points:

  NeruvaChatMessageHistory    -- auto-records every turn into Records
                                  substrate; works with the modern
                                  RunnableWithMessageHistory pattern,
                                  AgentExecutor, anything taking a
                                  BaseChatMessageHistory.

  NeruvaContextRetriever      -- pulls federated agent_recall (KG +
                                  Records) for a question. Plug into
                                  any chain that takes a BaseRetriever
                                  (RetrievalQA, create_retrieval_chain).

Install:
    pip install neruva-langchain

Usage (3 lines):
    from neruva_langchain import NeruvaChatMessageHistory
    history = NeruvaChatMessageHistory(api_key="nv_...", namespace="my_user")
    # pass `history` to RunnableWithMessageHistory or any chain that
    # takes a BaseChatMessageHistory
"""
from neruva_langchain.history import NeruvaChatMessageHistory
from neruva_langchain.retriever import NeruvaContextRetriever

__all__ = [
    "NeruvaChatMessageHistory",
    "NeruvaContextRetriever",
]

__version__ = "0.1.0"
