"""Adapters Module"""
