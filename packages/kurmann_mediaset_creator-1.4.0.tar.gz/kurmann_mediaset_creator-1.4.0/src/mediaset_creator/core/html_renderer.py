"""HTML-Rendering für Mediasets via Jinja2-Template."""

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

from jinja2 import Environment, PackageLoader, select_autoescape


@dataclass
class OgConfig:
    """Konfiguration für OpenGraph-Tags."""

    enabled: bool = True
    base_url: str = ""
    site_name: str = ""
    locale: str = "de_CH"
    ulid: str = ""


@dataclass
class VideoRenderData:
    """Aufbereitete Daten eines Videos für das Template."""

    video_filename: str
    landscape_filename: str
    zip_filename: str
    title: str | None = None
    description: str | None = None
    category: str | None = None
    recording_date: str | None = None
    quality_label: str | None = None
    duration_seconds: float = 0.0
    zip_size_bytes: int = 0


def _format_duration(seconds: float) -> str:
    """Formatiert Sekunden als 'Xm Ys'."""
    total = int(seconds)
    mins, secs = divmod(total, 60)
    if mins > 0:
        return f"{mins} Min. {secs} Sek."
    return f"{secs} Sek."


def _format_filesize_gb(size_bytes: int) -> str:
    """Formatiert Bytes als GB-Angabe."""
    gb = size_bytes / (1024 ** 3)
    if gb >= 1.0:
        return f"{gb:.1f} GB"
    mb = size_bytes / (1024 ** 2)
    return f"{mb:.0f} MB"


def render_html(
    items: list[VideoRenderData],
    mediaset_title: str | None = None,
    og_config: OgConfig | None = None,
    created_at: str | None = None,
) -> str:
    """Rendert das HTML für ein Mediaset.

    Args:
        items: Aufbereitete Daten pro Video.
        mediaset_title: Übergeordneter Titel (h1).
        og_config: OpenGraph-Konfiguration.

    Returns:
        Vollständiger HTML-String.
    """
    og_config = og_config or OgConfig()

    env = Environment(
        loader=PackageLoader("mediaset_creator", "templates"),
        autoescape=select_autoescape(["html"]),
    )
    env.filters["duration"] = _format_duration
    env.filters["filesize_gb"] = _format_filesize_gb
    template = env.get_template("index.html.j2")

    # OG-URL zusammensetzen
    og_url = ""
    og_image_url = ""
    if og_config.enabled and og_config.base_url and og_config.ulid and items:
        base = og_config.base_url.rstrip("/")
        og_url = f"{base}/{og_config.ulid}/"
        og_image_url = f"{og_url}{quote(items[0].landscape_filename)}"

    # Titel-Fallback: erster Video-Titel oder "Medienset"
    display_title = mediaset_title
    if not display_title and items:
        display_title = items[0].title
    if not display_title:
        display_title = "Medienset"

    return template.render(
        items=items,
        mediaset_title=display_title,
        og=og_config,
        og_url=og_url,
        og_image_url=og_image_url,
        first_item=items[0] if items else None,
        year=datetime.now().year,
        created_at=created_at or datetime.now().strftime("%d.%m.%Y, %H:%M Uhr"),
    )
