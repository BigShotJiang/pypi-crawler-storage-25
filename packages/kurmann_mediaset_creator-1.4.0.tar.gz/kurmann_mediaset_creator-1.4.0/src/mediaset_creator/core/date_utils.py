"""Hilfsfunktionen für die Datumsverarbeitung."""

import re
from datetime import date

_GERMAN_WEEKDAYS = [
    "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag",
]

_GERMAN_MONTHS = [
    "Januar", "Februar", "März", "April", "Mai", "Juni",
    "Juli", "August", "September", "Oktober", "November", "Dezember",
]

_ISO_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def parse_iso_date(value: str) -> date | None:
    """Parst ein ISO-Datum (YYYY-MM-DD). Gibt None zurück bei ungültigem Format."""
    if not _ISO_PATTERN.match(value):
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


def format_date_german(value: str) -> str:
    """Formatiert ein ISO-Datum als deutsches Long-Datum.

    Beispiel: '2026-03-22' → 'Sonntag, 22. März 2026'

    Gibt den Originalstring zurück wenn das Datum nicht parsebar ist.
    """
    d = parse_iso_date(value)
    if d is None:
        return value
    weekday = _GERMAN_WEEKDAYS[d.weekday()]
    month = _GERMAN_MONTHS[d.month - 1]
    return f"{weekday}, {d.day}. {month} {d.year}"
