"""Videoprobing und -komprimierung via ffprobe/ffmpeg."""

import json
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

INITIAL_CRF = 20
CRF_STEP = 2
MAX_CRF = 28
MAX_BITRATE_BPS = 40_000_000


@dataclass
class VideoInfo:
    """Technische Metadaten eines Videos."""

    width: int
    height: int
    bitrate_bps: int
    codec_name: str
    duration_seconds: float = 0.0

    @property
    def exceeds_4k(self) -> bool:
        """True wenn Auflösung grösser als 4K UHD (3840×2160)."""
        return self.width * self.height > 3840 * 2160

    def exceeds_bitrate_threshold(self, max_bitrate_bps: int = MAX_BITRATE_BPS) -> bool:
        """True wenn Bitrate über dem Schwellwert liegt."""
        return self.bitrate_bps > max_bitrate_bps

    def needs_compression(self, max_bitrate_bps: int = MAX_BITRATE_BPS) -> bool:
        """True wenn Kompression empfohlen wird (>4K oder Bitrate über Schwellwert)."""
        return self.exceeds_4k or self.exceeds_bitrate_threshold(max_bitrate_bps)

    def summary(self) -> str:
        """Lesbare Zusammenfassung für Log-Ausgaben."""
        megapixel = self.width * self.height / 1_000_000
        mbit = self.bitrate_bps / 1_000_000
        return f"{self.width}×{self.height} ({megapixel:.1f} MP) | {mbit:.0f} Mbit/s | {self.codec_name}"


@dataclass
class CompressionResult:
    """Ergebnis einer Videokomprimierung."""

    output_path: Path
    final_crf: int
    final_bitrate_bps: int | None
    iterations: int
    encoder: str = "libx265"


def probe_video(source_path: Path, ffprobe_path: str = "ffprobe") -> VideoInfo | None:
    """Analysiert Videoauflösung und Bitrate via ffprobe.

    Returns:
        VideoInfo mit Metadaten, oder None bei Fehler.
    """
    cmd = [
        ffprobe_path,
        "-v", "quiet",
        "-print_format", "json",
        "-show_streams",
        "-show_format",
        str(source_path),
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
    except (subprocess.CalledProcessError, FileNotFoundError, json.JSONDecodeError):
        return None

    # Ersten Video-Stream suchen
    video_stream = next(
        (s for s in data.get("streams", []) if s.get("codec_type") == "video"),
        None,
    )
    if not video_stream:
        return None

    try:
        width = int(video_stream["width"])
        height = int(video_stream["height"])
        codec_name = video_stream.get("codec_name", "unbekannt")
        bitrate_bps = int(data["format"]["bit_rate"])
        duration_seconds = float(data["format"].get("duration", 0))
    except (KeyError, ValueError, TypeError):
        return None

    return VideoInfo(
        width=width, height=height, bitrate_bps=bitrate_bps,
        codec_name=codec_name, duration_seconds=duration_seconds,
    )


def _run_ffmpeg(cmd: list[str], nice_level: int | None) -> None:
    """Führt ein ffmpeg-Kommando aus, optional mit nice."""
    if nice_level is not None:
        cmd = ["nice", "-n", str(nice_level)] + cmd
    subprocess.run(cmd, check=True)


def _build_libx265_cmd(
    ffmpeg_path: str, source_path: Path, output_path: Path,
    crf: int, preset: str,
) -> list[str]:
    """Baut das ffmpeg-Kommando für libx265 Software-Encoding."""
    return [
        ffmpeg_path,
        "-y",
        "-i", str(source_path),
        "-vf", "scale=2560:1440:flags=lanczos",
        "-c:v", "libx265",
        "-preset", preset,
        "-crf", str(crf),
        "-pix_fmt", "yuv420p10le",
        "-tag:v", "hvc1",
        "-x265-params", "open-gop=0",
        "-c:a", "aac",
        "-b:a", "192k",
        "-movflags", "+faststart",
        str(output_path),
    ]


def _build_videotoolbox_cmd(
    ffmpeg_path: str, source_path: Path, output_path: Path,
) -> list[str]:
    """Baut das ffmpeg-Kommando für VideoToolbox Hardware-Encoding (Fallback)."""
    return [
        ffmpeg_path,
        "-y",
        "-i", str(source_path),
        "-vf", "scale=2560:1440:flags=lanczos",
        "-c:v", "hevc_videotoolbox",
        "-profile:v", "main10",
        "-pix_fmt", "p010le",
        "-q:v", "65",
        "-tag:v", "hvc1",
        "-g", "30",
        "-c:a", "aac_at",
        "-b:a", "192k",
        "-movflags", "+faststart",
        str(output_path),
    ]


def compress_video(
    source_path: Path,
    output_path: Path,
    ffmpeg_path: str = "ffmpeg",
    ffprobe_path: str = "ffprobe",
    nice_level: int | None = None,
    on_recompress: Callable[[str], None] | None = None,
    initial_crf: int = INITIAL_CRF,
    max_bitrate_bps: int = MAX_BITRATE_BPS,
    preset: str = "slow",
) -> CompressionResult:
    """Komprimiert Video zu MP4 (HEVC, 2560×1440).

    Verwendet libx265 Software-Encoding mit CRF-Modus für bestmögliche Qualität.
    Falls libx265 nicht verfügbar ist, wird automatisch auf VideoToolbox (macOS)
    zurückgefallen. Nach der Komprimierung wird die Bitrate geprüft und bei Bedarf
    mit erhöhtem CRF erneut komprimiert.

    Returns:
        CompressionResult mit Pfad, finalem CRF, Bitrate, Iterationsanzahl und Encoder.

    Raises:
        subprocess.CalledProcessError: Wenn ffmpeg auch mit Fallback fehlschlägt.
    """
    crf = initial_crf
    iteration = 0

    while True:
        iteration += 1
        cmd = _build_libx265_cmd(ffmpeg_path, source_path, output_path, crf, preset)

        try:
            _run_ffmpeg(cmd, nice_level)
        except subprocess.CalledProcessError:
            if iteration == 1:
                # Fallback auf VideoToolbox (einmaliger Versuch, kein Loop)
                if on_recompress:
                    on_recompress("libx265 nicht verfügbar – Fallback auf VideoToolbox")
                fallback_cmd = _build_videotoolbox_cmd(ffmpeg_path, source_path, output_path)
                _run_ffmpeg(fallback_cmd, nice_level)
                result_info = probe_video(output_path, ffprobe_path=ffprobe_path)
                final_bps = result_info.bitrate_bps if result_info else None
                return CompressionResult(output_path, crf, final_bps, 1, encoder="videotoolbox")
            raise

        # Bitrate des Ergebnisses prüfen
        result_info = probe_video(output_path, ffprobe_path=ffprobe_path)
        final_bps = result_info.bitrate_bps if result_info else None

        if result_info is None or result_info.bitrate_bps <= max_bitrate_bps:
            if crf > initial_crf and on_recompress:
                mbit = result_info.bitrate_bps / 1_000_000 if result_info else 0
                on_recompress(f"Bitrate nach Nachkomprimierung: {mbit:.0f} Mbit/s (CRF={crf})")
            return CompressionResult(output_path, crf, final_bps, iteration)

        # CRF-Obergrenze erreicht
        next_crf = crf + CRF_STEP
        if next_crf > MAX_CRF:
            mbit = result_info.bitrate_bps / 1_000_000
            if on_recompress:
                on_recompress(f"CRF-Obergrenze erreicht (CRF={crf}, {mbit:.0f} Mbit/s)")
            return CompressionResult(output_path, crf, final_bps, iteration)

        mbit = result_info.bitrate_bps / 1_000_000
        if on_recompress:
            on_recompress(f"Bitrate zu hoch ({mbit:.0f} Mbit/s) – Nachkomprimierung mit CRF={next_crf}")

        crf = next_crf
