"""Orchestrierung der Mediaset-Erstellung: Dateien kopieren, Thumbnails erzeugen, HTML rendern."""

import re
import subprocess
import unicodedata
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

from ulid import ULID

from mediaset_creator.api.models import (
    CreateMediasetRequest,
    MediaItem,
    MediasetCreatorEvent,
    MediasetCreatorStage,
    MediasetResult,
    RuntimeOptions,
)
from mediaset_creator.core.asset_builder import copy_video, create_nfo, create_video_thumbnails, create_zip
from mediaset_creator.core.date_utils import format_date_german, parse_iso_date
from mediaset_creator.core.html_renderer import OgConfig, VideoRenderData, render_html
from mediaset_creator.core.video_processor import compress_video, probe_video


_TRANSLITERATION = str.maketrans({
    "ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss",
    "Ä": "Ae", "Ö": "Oe", "Ü": "Ue",
})


def _sanitize_stem(stem: str) -> str:
    """Erzeugt einen ASCII-sicheren Dateinamen-Stamm für Webserver-Kompatibilität.

    Transliteriert deutsche Umlaute, ersetzt Leerzeichen durch Bindestriche
    und entfernt alle nicht-ASCII-Zeichen.
    """
    stem = unicodedata.normalize("NFC", stem)
    stem = stem.translate(_TRANSLITERATION)
    stem = stem.replace(" ", "-")
    stem = re.sub(r"[^A-Za-z0-9\-_]", "", stem)
    stem = re.sub(r"-{2,}", "-", stem)
    return stem.strip("-")


def _emit(
    on_event: Callable[[MediasetCreatorEvent], None] | None,
    stage_id: str,
    message: str,
    current: int | None = None,
    total: int | None = None,
) -> None:
    if on_event:
        on_event(MediasetCreatorEvent(
            stage_id=stage_id,
            message=message,
            current=current,
            total=total,
        ))


def assemble_mediaset(
    request: CreateMediasetRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediasetCreatorEvent], None] | None = None,
) -> MediasetResult:
    """Erstellt ein komplettes Mediaset aus den angegebenen Medienelementen.

    Returns:
        MediasetResult mit Pfaden zu allen erzeugten Dateien.
    """
    runtime = runtime or RuntimeOptions()

    if not request.items:
        return MediasetResult(success=False, error_message="Keine Medienelemente angegeben.")

    # Ausgabeverzeichnis bestimmen
    base_dir = request.output_dir or request.items[0].source_path.parent
    if request.ulid:
        try:
            ULID.from_str(request.ulid)
        except ValueError:
            return MediasetResult(
                success=False,
                error_message=f"Ungültige ULID: '{request.ulid}'",
            )
        ulid = request.ulid
    else:
        ulid = str(ULID())
    output_dir = base_dir / ulid
    output_dir.mkdir(parents=True, exist_ok=True)

    _emit(on_event, MediasetCreatorStage.MEDIASET_GESTARTET,
          f"Mediaset wird erstellt in {output_dir}")

    total = len(request.items)
    zip_paths: list[Path] = []
    landscape_paths: list[Path] = []
    portrait_paths: list[Path] = []
    render_items: list[VideoRenderData] = []

    use_sidecar = _get_config_value("thumbnails.sidecar").lower() != "false"
    use_date_prefix = _get_config_value("filename.date_prefix").lower() != "false"
    use_auto_compress = _get_config_value("video.auto_compress").lower() != "false"
    portrait_suffix = _get_config_value("thumbnails.portrait_suffix") or "-poster"
    nice_raw = _get_config_value("tools.nice_level").strip()
    nice_level = int(nice_raw) if nice_raw.lstrip("-").isdigit() else None
    crf_raw = _get_config_value("video.crf").strip()
    initial_crf = int(crf_raw) if crf_raw.isdigit() else 20
    preset = _get_config_value("video.preset").strip() or "slow"
    max_bitrate_raw = _get_config_value("video.max_bitrate").strip()
    max_bitrate_bps = int(float(max_bitrate_raw) * 1_000_000) if max_bitrate_raw else 40_000_000

    for i, item in enumerate(request.items, 1):
        if item.media_type != "video":
            continue

        # Datum: ISO für Dateiname-Prefix, Long-Format für Anzeige
        iso_date = item.recording_date or ""
        display_date = format_date_german(iso_date) if iso_date else None

        # Dateiname-Stamm mit optionalem Datum-Prefix
        base_stem = item.source_path.stem
        if use_date_prefix and parse_iso_date(iso_date):
            original_stem = f"{iso_date} {base_stem}"
        else:
            original_stem = base_stem
        target_stem = _sanitize_stem(original_stem)

        # 1. Video analysieren (für Dauer und ggf. Kompression)
        video_info = probe_video(item.source_path, ffprobe_path=runtime.ffprobe_path)
        duration_seconds = video_info.duration_seconds if video_info else 0.0

        if use_auto_compress:
            if video_info:
                if video_info.needs_compression(max_bitrate_bps):
                    analyse_msg = f"Komprimierung nötig: {video_info.summary()}"
                else:
                    analyse_msg = f"Keine Komprimierung: {video_info.summary()}"
            else:
                analyse_msg = "Videoanalyse nicht möglich – Original wird verwendet"
            _emit(on_event, MediasetCreatorStage.VIDEO_ANALYSIERT,
                  analyse_msg, current=i, total=total)

        # 2. Thumbnails erstellen (vor Komprimierung – ermöglicht frühes Infuse-Deployment)
        landscape_path, portrait_path = create_video_thumbnails(
            item.source_path, output_dir, runtime, use_sidecar=use_sidecar,
            title=item.title, category=item.category,
            recording_date=display_date,
            portrait_suffix=portrait_suffix,
            frame_number=item.frame_number,
            timestamp_seconds=item.timestamp_seconds,
            crop_position=item.crop_position,
        )

        # Thumbnail-Dateien umbenennen (sanitisierter Stem)
        # Landscape: einfacher Name ohne Suffix (für Web)
        expected_landscape = output_dir / f"{target_stem}{landscape_path.suffix}"
        if landscape_path != expected_landscape:
            landscape_path = landscape_path.rename(expected_landscape)
        # Portrait: mit Suffix (temporär auf Disk, wird nach ZIP-Erstellung gelöscht)
        expected_portrait = output_dir / f"{target_stem}{portrait_suffix}{portrait_path.suffix}"
        if portrait_path != expected_portrait:
            portrait_path = portrait_path.rename(expected_portrait)

        landscape_paths.append(landscape_path)
        portrait_paths.append(portrait_path)
        _emit(on_event, MediasetCreatorStage.THUMBNAILS_ERSTELLT,
              f"Vorschaubilder erstellt für: {item.source_path.name}", current=i, total=total)

        # 3. NFO-Datei für Infuse erstellen (Firecore «Other»-Format)
        nfo_path = create_nfo(
            video_stem=target_stem,
            output_dir=output_dir,
            title=item.title,
            published=iso_date or None,
            category=item.category,
            description=item.description,
        )
        _emit(on_event, MediasetCreatorStage.NFO_ERSTELLT,
              f"NFO-Datei erstellt: {nfo_path.name}", current=i, total=total)

        # 4. Video komprimieren oder kopieren (mit Skip-Logik)
        zip_source: Path | None = None
        existing_video = _find_existing_video(output_dir, target_stem)
        source_mtime = item.source_path.stat().st_mtime

        if existing_video and not request.force and existing_video.stat().st_mtime >= source_mtime:
            # Video bereits vorhanden und Quelle nicht neuer → überspringen
            video_dest = existing_video
            if use_auto_compress and video_info and video_info.needs_compression(max_bitrate_bps):
                zip_source = item.source_path
            _emit(on_event, MediasetCreatorStage.VIDEO_UEBERSPRUNGEN,
                  f"Video unverändert, übersprungen: {video_dest.name}", current=i, total=total)
        elif use_auto_compress and video_info and video_info.needs_compression(max_bitrate_bps):
            output_path = output_dir / f"{target_stem}.mp4"

            def _on_recompress(message: str) -> None:
                _emit(on_event, MediasetCreatorStage.VIDEO_NACHKOMPRIMIERT,
                      message, current=i, total=total)

            try:
                comp = compress_video(
                    item.source_path, output_path,
                    ffmpeg_path=runtime.ffmpeg_path,
                    ffprobe_path=runtime.ffprobe_path,
                    nice_level=nice_level,
                    on_recompress=_on_recompress,
                    initial_crf=initial_crf,
                    max_bitrate_bps=max_bitrate_bps,
                    preset=preset,
                )
                video_dest = comp.output_path
                zip_source = item.source_path
                mbit = comp.final_bitrate_bps / 1_000_000 if comp.final_bitrate_bps else 0
                encoder_label = f" ({comp.encoder})" if comp.encoder != "libx265" else ""
                summary = f"Video komprimiert: {video_dest.name} | CRF={comp.final_crf} | {mbit:.0f} Mbit/s{encoder_label}"
                if comp.iterations > 1:
                    summary += f" | {comp.iterations} Durchläufe"
                _emit(on_event, MediasetCreatorStage.VIDEO_KOMPRIMIERT,
                      summary, current=i, total=total)
            except subprocess.CalledProcessError:
                video_dest = copy_video(item.source_path, output_dir, target_stem=target_stem)
                _emit(on_event, MediasetCreatorStage.VIDEO_KOPIERT,
                      f"Komprimierung fehlgeschlagen – Original kopiert: {item.source_path.name}",
                      current=i, total=total)
        else:
            video_dest = copy_video(item.source_path, output_dir, target_stem=target_stem)
            _emit(on_event, MediasetCreatorStage.VIDEO_KOPIERT,
                  f"Video kopiert: {item.source_path.name}", current=i, total=total)

        # 5. ZIP erstellen (bei Kompression: Original ins ZIP, sonst kopierte Datei)
        zip_path = create_zip(video_dest, landscape_path, portrait_path, output_dir,
                              zip_video_path=zip_source, nfo_path=nfo_path,
                              original_stem=original_stem,
                              portrait_suffix=portrait_suffix)
        zip_paths.append(zip_path)
        _emit(on_event, MediasetCreatorStage.ZIP_ERSTELLT,
              f"ZIP erstellt: {zip_path.name}", current=i, total=total)

        # Portrait und NFO nur im ZIP benötigt – von Disk entfernen
        if portrait_path.exists():
            portrait_path.unlink()
        if nfo_path and nfo_path.exists():
            nfo_path.unlink()

        # 6. Render-Daten sammeln
        render_items.append(VideoRenderData(
            video_filename=video_dest.name,
            landscape_filename=landscape_path.name,
            zip_filename=zip_path.name,
            title=item.title,
            description=item.description,
            category=item.category,
            recording_date=display_date,
            quality_label=item.quality_label,
            duration_seconds=duration_seconds,
            zip_size_bytes=zip_path.stat().st_size,
        ))

    # HTML rendern
    og_config = OgConfig(
        enabled=request.enable_og_tags,
        base_url=runtime.base_url,
        site_name=_get_config_value("og.site_name"),
        locale=_get_config_value("og.locale") or "de_CH",
        ulid=ulid,
    )

    created_at = datetime.now().strftime("%d.%m.%Y, %H:%M Uhr")

    html_content = render_html(
        items=render_items,
        mediaset_title=request.mediaset_title,
        og_config=og_config,
        created_at=created_at,
    )
    html_path = output_dir / "index.html"
    html_path.write_text(html_content, encoding="utf-8")
    _emit(on_event, MediasetCreatorStage.HTML_GENERIERT, "HTML-Seite generiert")

    _emit(on_event, MediasetCreatorStage.MEDIASET_ABGESCHLOSSEN,
          f"Mediaset abgeschlossen: {output_dir}")

    return MediasetResult(
        success=True,
        output_dir=output_dir,
        html_path=html_path,
        zip_paths=zip_paths,
        landscape_paths=landscape_paths,
        portrait_paths=portrait_paths,
    )


_VIDEO_EXTENSIONS = {".mp4", ".m4v", ".mov", ".mkv", ".avi"}


def _find_existing_video(output_dir: Path, target_stem: str) -> Path | None:
    """Sucht eine vorhandene Videodatei mit dem gegebenen Stem im Ausgabeverzeichnis."""
    for ext in _VIDEO_EXTENSIONS:
        candidate = output_dir / f"{target_stem}{ext}"
        if candidate.exists():
            return candidate
    return None


def _get_config_value(key: str) -> str:
    """Liest einen Config-Wert. Fängt ImportError ab falls Config nicht verfügbar."""
    try:
        from mediaset_creator.services import config_manager
        return config_manager.get_with_default(key)
    except Exception:
        return ""
