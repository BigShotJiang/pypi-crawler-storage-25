"""API-Fassade: Öffentliche Schnittstelle des Mediaset Creators."""

from collections.abc import Callable

from .models import (
    CreateMediasetRequest,
    MediasetCreatorEvent,
    MediasetResult,
    RuntimeOptions,
)


def create_mediaset(
    request: CreateMediasetRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediasetCreatorEvent], None] | None = None,
) -> MediasetResult:
    """Erstellt ein Mediaset aus den angegebenen Medienelementen.

    Args:
        request: Fachlicher Request mit Medienelementen und Optionen.
        runtime: Technische Laufzeitoptionen (Pfade, URLs). Optional.
        on_event: Optionaler Callback für strukturierte Fortschritts-Events.

    Returns:
        MediasetResult mit Erfolg/Fehler und Pfaden zu erzeugten Dateien.
    """
    from mediaset_creator.core.mediaset_assembler import assemble_mediaset

    try:
        return assemble_mediaset(request, runtime, on_event)
    except Exception as e:
        return MediasetResult(success=False, error_message=str(e))
