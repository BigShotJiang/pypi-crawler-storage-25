"""Mediaset Creator – Erstellt Mediensets (statisches HTML) aus Videodateien."""

__version__ = "1.1.0"
