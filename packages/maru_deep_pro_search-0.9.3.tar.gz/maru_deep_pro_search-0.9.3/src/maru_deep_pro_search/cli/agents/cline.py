"""Cline adapter — VS Code extension AI agent."""

from __future__ import annotations

import shutil
from pathlib import Path

from ..backup import backup_file, read_text_safe, restore_file, write_text_safe
from ..prompts import get_protocol_for_agent, inject_protocol
from .base import AgentAdapter, get_mcp_server_command


class ClineAdapter(AgentAdapter):
    name = "cline"
    display_name = "Cline"

    def detect(self) -> bool:
        return (
            Path.home().joinpath(".vscode", "extensions", "saoudrizwan.claude-dev").exists()
            or Path.home().joinpath(".vscode", "extensions", "claude-dev").exists()
            or shutil.which("cline") is not None
        )

    def _rules_path(self, scope: str) -> Path:
        if scope == "project":
            return Path(".clinerules")
        return Path.home() / ".clinerules"

    def _mcp_path(self, scope: str) -> Path:
        if scope == "project":
            return Path(".cline", "mcp.json")
        return Path.home() / ".cline" / "mcp.json"

    def _settings_path(self, scope: str) -> Path:
        if scope == "project":
            return Path(".cline") / "settings.json"
        return Path.home() / ".cline" / "settings.json"

    def backup(self) -> list[Path]:
        paths = [self._rules_path("user"), self._mcp_path("user")]
        backups = [backup_file(p) for p in paths]
        return [b for b in backups if b is not None]

    def restore(self) -> bool:
        restored = False
        for p in [self._rules_path("user"), self._mcp_path("user")]:
            backups = sorted(p.parent.glob(f"{p.name}.bak.*"), reverse=True)
            if backups:
                restored = restore_file(p, backups[0]) or restored
        return restored

    def install_mcp(self, scope: str = "user") -> bool:
        from ..backup import read_json_safe, write_json_safe

        path = self._mcp_path(scope)
        config = read_json_safe(path)
        if "mcpServers" not in config:
            config["mcpServers"] = {}

        config["mcpServers"]["maru-deep-pro-search"] = get_mcp_server_command()
        write_json_safe(path, config)
        return True

    def inject_rules(self, scope: str = "user") -> bool:
        # 1. .clinerules
        path = self._rules_path(scope)
        content = read_text_safe(path)
        protocol = get_protocol_for_agent(self.name)

        new_content = inject_protocol(content, protocol)
        if new_content != content:
            write_text_safe(path, new_content)

        # 2. .cline/settings.json — default instructions hint
        settings_path = self._settings_path(scope)
        from ..backup import read_json_safe, write_json_safe

        settings = read_json_safe(settings_path)
        if "agent" not in settings:
            settings["agent"] = {}
        settings["agent"]["defaultInstructions"] = (
            "You MUST call deep_research before any code generation or file edits. "
            "This is enforced by the maru-deep-pro-search MCP server."
        )
        write_json_safe(settings_path, settings)

        return True
