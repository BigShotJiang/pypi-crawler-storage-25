# Henosis CLI

Henosis CLI is a multi-provider coding agent for your terminal.

Use frontier models from every major provider in one workflow, point them at your codebase, and keep work connected across the CLI, Henosis Chat, and Remote Control. Bring your own API keys, use your Codex subscription where supported, or run on Henosis credits.

## Why Henosis CLI

- Work across providers without vendor lock-in
- Let agents read files, apply patches, and run commands with configurable controls
- Continue the same threads between browser, terminal, and remote sessions
- Monitor and steer active sessions from the web with Remote Control

## What it does

Henosis CLI gives you a connected coding workflow across terminal and web.

With Henosis CLI, you can:
- chat with leading models from OpenAI, Anthropic, Google, xAI, DeepSeek, Moonshot, and more
- switch models as a task evolves instead of committing to a single provider
- run long-lived coding sessions against your repository
- review and approve sensitive actions before they execute
- keep threads, context, and billing connected with the Henosis web app
- monitor active CLI sessions remotely with `--agent-mode`

## Core capabilities

- Interactive chat over SSE with usage and cost summaries
- Model picker and per-turn controls
- Local tool execution with configurable approval levels
- Workspace and host-scope filesystem controls
- Optional web search controls for supported OpenAI models
- Thread persistence and usage tracking through the Henosis backend
- Remote Control support for monitoring and steering active terminal sessions

## Install

- pip:
  - `pip install henosis-cli`
- pipx:
  - `pipx install henosis-cli`

## Quick start

- Run the CLI:
  - `henosis-cli`
- Default server:
  - `https://henosis.us/api_v2`
- Override server:
  - `henosis-cli --server https://your-server`
- Dev server:
  - `henosis-cli --dev`

When prompted, sign in and choose a model. Tools are enabled by default.

## Common commands

- `/menu` or `/settings` — open settings
- `/model` — open the model picker
- `/model <name>` — set a model directly
- `/tools on|off|default` — toggle tool availability
- `/fs workspace|host|default` — choose filesystem scope
- `/hostbase <abs path>` — set the host scope root
- `/level 1|2|3` — choose approval level
- `/map on|off` — inject `CODEBASE_MAP.md` into the first message
- `/websearch on|off|domains|sources|location` — configure web search options
- `/title <name>` — rename the current thread
- `/clear` — clear chat history
- `/login`, `/logout`, `/whoami` — auth helpers

## Configuration

### Server URL
- Env:
  - `HENOSIS_SERVER`
- Flag:
  - `--server`
- Dev shortcut:
  - `--dev` uses `HENOSIS_DEV_SERVER` or `http://127.0.0.1:8000`

### Agent Mode
- Enable remote session connectivity with:
  - `--agent-mode`

## Local tools and approvals

Henosis CLI can execute a controlled set of local tools when requested by the server.

Available tool categories include:
- file reading and writing
- directory listing
- patch application
- command execution
- managed background processes
- managed interactive terminals

Approval levels:
- **Level 1** — read-only
- **Level 2** — write and exec actions require approval
- **Level 3** — unrestricted local execution

Filesystem modes:
- **workspace** — sandboxed to the current working directory by default
- **host** — restricted to a chosen Agent scope directory

You can also override the workspace root with:
- `--workspace-dir /path/to/root`
- `HENOSIS_WORKSPACE_DIR=/path/to/root`

## Remote Control

Henosis CLI supports a connected remote workflow through Agent Mode.

Start the CLI with:
- `henosis-cli --agent-mode`

Then open Remote Control at:
- `https://henosis.us/agent`

From there, you can:
- monitor active sessions
- review terminal state
- send follow-up instructions
- handle approvals from the web
- reconnect without losing session continuity

## Troubleshooting

If a provider streams deltas but never sends a final `message.completed`, the CLI prints a diagnostics block with:
- stream stats
- recent event tail
- relevant response headers

It also writes the same information to:
- `logs/session-*.jsonl`

Useful flags and environment variables:
- `--debug-sse`
- `--debug-req`
- `HENOSIS_CLI_SSE_TAIL=80`

Minimal test harness:
- `python test_stream.py`

Optional overrides:
- `HENOSIS_TEST_URL`
- `HENOSIS_TEST_MODEL`
- `HENOSIS_TEST_PROMPT`

## Requirements

- Python 3.9+
- Rich terminal support is included by default
- The reusable local tools library is available as `henosis_cli_tools`

## Support

- Email:
  - `henosis@henosis.us`
