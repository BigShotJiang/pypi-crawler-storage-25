import asyncio

from fastapi.responses import StreamingResponse

import app.routers.chat as chat_router


def test_chat_stream_returns_streaming_response_for_anthropic_model():
    body = chat_router.ChatRequest(
        model="claude-opus-4-7",
        messages=[chat_router.Message(role="user", content="test")],
    )

    result = asyncio.run(chat_router.chat_stream(None, body))

    assert isinstance(result, StreamingResponse)
