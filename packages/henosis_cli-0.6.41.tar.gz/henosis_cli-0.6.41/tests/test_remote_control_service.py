import asyncio

import app.services.remote_control as remote_control_mod
from app.services.remote_control import RemoteControlService


async def _no_redis():
    return None


class _FakeWebSocket:
    def __init__(self):
        self.payloads = []
        self.closed = []

    async def send_json(self, payload):
        self.payloads.append(payload)

    async def close(self, code=1000, reason=""):
        self.closed.append({"code": code, "reason": reason})


def _make_snapshot(terminal_id: str, *, busy: bool = False, messages=None):
    return {
        "terminal": {
            "terminal_id": terminal_id,
            "label": "Alpha",
            "display_name": "Alpha",
        },
        "terminal_id": terminal_id,
        "busy": bool(busy),
        "model": "gpt-5.4",
        "messages": list(messages or []),
        "current_turn": {
            "active": bool(busy),
            "session_id": None,
            "model": "gpt-5.4",
            "level": 3,
            "assistant_so_far": "",
            "tool_events": [],
            "user_message": None,
            "thinking_insight": None,
        },
    }


def test_register_browser_no_longer_pushes_full_snapshot(monkeypatch):
    monkeypatch.setattr(remote_control_mod, "get_redis", _no_redis)
    service = RemoteControlService()

    terminal_ws = _FakeWebSocket()
    terminal_id = asyncio.run(service.register_terminal("user-1", "term-a", terminal_ws))
    asyncio.run(
        service.terminal_state(
            "user-1",
            terminal_id,
            _make_snapshot(
                terminal_id,
                messages=[
                    {"role": "user", "content": "hello"},
                    {"role": "assistant", "content": "world"},
                ],
            ),
        )
    )

    browser_ws = _FakeWebSocket()
    _browser_id = asyncio.run(service.register_browser("user-1", browser_ws))

    event_types = [payload.get("type") for payload in browser_ws.payloads]
    assert event_types == ["remote.connected", "remote.terminals", "remote.selected"]
    assert "remote.snapshot" not in event_types


def test_resume_browser_sends_patch_when_browser_has_matching_prefix(monkeypatch):
    monkeypatch.setattr(remote_control_mod, "get_redis", _no_redis)
    service = RemoteControlService()

    terminal_ws = _FakeWebSocket()
    terminal_id = asyncio.run(service.register_terminal("user-1", "term-a", terminal_ws))
    server_messages = [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "world"},
        {"role": "assistant", "content": "new tail"},
    ]
    asyncio.run(service.terminal_state("user-1", terminal_id, _make_snapshot(terminal_id, messages=server_messages)))

    browser_ws = _FakeWebSocket()
    browser_id = asyncio.run(service.register_browser("user-1", browser_ws))
    browser_ws.payloads.clear()

    ok, resolved_terminal_id = asyncio.run(
        service.resume_browser(
            "user-1",
            browser_id,
            {
                "terminal_id": terminal_id,
                "message_hashes": remote_control_mod._resume_message_hashes(server_messages[:2]),
            },
        )
    )

    assert ok is True
    assert resolved_terminal_id == terminal_id
    assert len(browser_ws.payloads) == 1
    payload = browser_ws.payloads[0]
    assert payload["type"] == "remote.snapshot.patch"
    assert payload["data"]["terminal_id"] == terminal_id
    assert payload["data"]["base_message_count"] == 2
    assert payload["data"]["append_messages"] == [{"role": "assistant", "content": "new tail"}]
    assert payload["data"]["snapshot"]["terminal_id"] == terminal_id
    assert payload["data"]["snapshot"]["model"] == "gpt-5.4"
    assert payload["data"]["snapshot"]["busy"] is False


def test_resume_browser_falls_back_to_full_snapshot_on_mismatch(monkeypatch):
    monkeypatch.setattr(remote_control_mod, "get_redis", _no_redis)
    service = RemoteControlService()

    terminal_ws = _FakeWebSocket()
    terminal_id = asyncio.run(service.register_terminal("user-1", "term-a", terminal_ws))
    server_messages = [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "world"},
    ]
    normalized_snapshot = remote_control_mod._normalize_snapshot(
        terminal_id,
        _make_snapshot(terminal_id, messages=server_messages),
    )
    asyncio.run(service.terminal_state("user-1", terminal_id, _make_snapshot(terminal_id, messages=server_messages)))

    browser_ws = _FakeWebSocket()
    browser_id = asyncio.run(service.register_browser("user-1", browser_ws))
    browser_ws.payloads.clear()

    ok, _resolved_terminal_id = asyncio.run(
        service.resume_browser(
            "user-1",
            browser_id,
            {
                "terminal_id": terminal_id,
                "message_hashes": ["deadbeef"],
            },
        )
    )

    assert ok is True
    assert len(browser_ws.payloads) == 1
    payload = browser_ws.payloads[0]
    assert payload["type"] == "remote.snapshot"
    assert payload["data"]["terminal_id"] == terminal_id
    assert payload["data"]["snapshot"]["terminal_id"] == terminal_id
    assert payload["data"]["snapshot"]["messages"] == normalized_snapshot["messages"]
    assert payload["data"]["snapshot"]["model"] == normalized_snapshot["model"]
    assert payload["data"]["snapshot"]["busy"] == normalized_snapshot["busy"]


def test_terminal_state_broadcasts_meta_without_full_snapshot(monkeypatch):
    monkeypatch.setattr(remote_control_mod, "get_redis", _no_redis)
    service = RemoteControlService()

    terminal_ws = _FakeWebSocket()
    terminal_id = asyncio.run(service.register_terminal("user-1", "term-a", terminal_ws))
    messages = [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "world"},
    ]
    asyncio.run(service.terminal_state("user-1", terminal_id, _make_snapshot(terminal_id, busy=False, messages=messages)))

    browser_ws = _FakeWebSocket()
    _browser_id = asyncio.run(service.register_browser("user-1", browser_ws))
    browser_ws.payloads.clear()

    asyncio.run(service.terminal_state("user-1", terminal_id, _make_snapshot(terminal_id, busy=True, messages=messages)))

    event_types = [payload.get("type") for payload in browser_ws.payloads]
    assert "remote.snapshot.meta" in event_types
    assert "remote.snapshot" not in event_types


def test_terminal_select_sends_fast_selected_ack_before_refresh(monkeypatch):
    monkeypatch.setattr(remote_control_mod, "get_redis", _no_redis)
    service = RemoteControlService()

    terminal_a_ws = _FakeWebSocket()
    terminal_a_id = asyncio.run(service.register_terminal("user-1", "term-a", terminal_a_ws))
    terminal_b_ws = _FakeWebSocket()
    asyncio.run(service.register_terminal("user-1", "term-b", terminal_b_ws))

    browser_ws = _FakeWebSocket()
    browser_id = asyncio.run(service.register_browser("user-1", browser_ws))
    browser_ws.payloads.clear()

    ok = asyncio.run(service.set_browser_terminal("user-1", browser_id, terminal_a_id))

    assert ok is True
    assert browser_ws.payloads
    assert browser_ws.payloads[0] == {
        "type": "remote.selected",
        "data": {"terminal_id": terminal_a_id},
    }
    assert any(payload.get("type") == "remote.terminals" for payload in browser_ws.payloads[1:])


def test_watch_all_terminals_fans_out_non_selected_live_events(monkeypatch):
    monkeypatch.setattr(remote_control_mod, "get_redis", _no_redis)
    service = RemoteControlService()

    terminal_a_ws = _FakeWebSocket()
    terminal_a_id = asyncio.run(service.register_terminal("user-1", "term-a", terminal_a_ws))
    terminal_b_ws = _FakeWebSocket()
    terminal_b_id = asyncio.run(service.register_terminal("user-1", "term-b", terminal_b_ws))

    browser_ws = _FakeWebSocket()
    browser_id = asyncio.run(service.register_browser("user-1", browser_ws))
    asyncio.run(service.set_browser_terminal("user-1", browser_id, terminal_b_id))
    browser_ws.payloads.clear()

    asyncio.run(service.ingest_terminal_event("user-1", terminal_a_id, "message.delta", {"text": "hidden"}))
    assert browser_ws.payloads == []

    ok = asyncio.run(service.set_browser_watch_mode("user-1", browser_id, "all"))
    assert ok is True
    browser_ws.payloads.clear()

    asyncio.run(service.ingest_terminal_event("user-1", terminal_a_id, "message.delta", {"text": "visible"}))

    assert browser_ws.payloads == [
        {
            "type": "message.delta",
            "data": {
                "text": "visible",
                "terminal_id": terminal_a_id,
            },
        }
    ]


def test_watch_all_does_not_change_browser_control_target(monkeypatch):
    monkeypatch.setattr(remote_control_mod, "get_redis", _no_redis)
    service = RemoteControlService()

    terminal_a_ws = _FakeWebSocket()
    terminal_a_id = asyncio.run(service.register_terminal("user-1", "term-a", terminal_a_ws))
    terminal_b_ws = _FakeWebSocket()
    terminal_b_id = asyncio.run(service.register_terminal("user-1", "term-b", terminal_b_ws))

    browser_ws = _FakeWebSocket()
    browser_id = asyncio.run(service.register_browser("user-1", browser_ws))
    asyncio.run(service.set_browser_terminal("user-1", browser_id, terminal_a_id))
    asyncio.run(service.set_browser_watch_mode("user-1", browser_id, "all"))

    ok, delivered_terminal_id = asyncio.run(
        service.forward_browser_message("user-1", browser_id, "user.send", {"text": "hello"})
    )

    assert ok is True
    assert delivered_terminal_id == terminal_a_id
    assert terminal_a_ws.payloads == [{"type": "user.send", "data": {"text": "hello"}}]
    assert terminal_b_ws.payloads == []


def test_resume_message_hashes_normalize_function_logs_shape(monkeypatch):
    monkeypatch.setattr(remote_control_mod, "get_redis", _no_redis)

    raw_message = {
        "role": "assistant",
        "content": "hello",
        "functionLogs": [
            {"type": "tool.call", "data": {"name": "read_file", "call_id": "abc"}},
            {"type": "tool.result", "data": {"name": "read_file", "call_id": "abc", "result": {"ok": True}}},
        ],
        "thinkingInsight": {"provider": "openai", "text": "summary"},
        "approvalRequest": {
            "tool": "write_file",
            "call_id": "call-123",
            "session_id": "sess-1",
            "timeout_sec": 60,
            "note": "Need approval",
            "args_preview": {"path": "notes.txt"},
        },
    }
    flattened_message = {
        "role": "assistant",
        "content": "hello",
        "functionLogs": [
            {"type": "call", "name": "read_file", "call_id": "abc"},
            {"type": "result", "name": "read_file", "call_id": "abc", "result": {"ok": True}},
        ],
        "thinkingInsight": {"provider": "openai", "text": "summary"},
        "approvalRequest": {
            "tool": "write_file",
            "call_id": "call-123",
            "session_id": "sess-1",
            "timeout_sec": 60,
            "note": "Need approval",
            "args_preview": {"path": "notes.txt"},
        },
    }

    raw_hash = remote_control_mod._resume_message_hashes([raw_message])
    flat_hash = remote_control_mod._resume_message_hashes([flattened_message])

    assert raw_hash == flat_hash
