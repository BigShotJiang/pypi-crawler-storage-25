import json
import sys
import types
from pathlib import Path
from typing import Any, Dict, List, Optional

from starlette.testclient import TestClient


_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.main import app
from app.settings import settings


def _ensure_v0_router():
    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass
    return chat_router


def _collect_completed_payload(client: TestClient, payload: Dict[str, Any]) -> Dict[str, Any]:
    response = client.post("/v0/chat/stream", json=payload)
    assert response.status_code == 200
    current_event: Optional[str] = None
    completed: Optional[Dict[str, Any]] = None
    for line in response.iter_lines():
        text = line.decode("utf-8") if isinstance(line, (bytes, bytearray)) else str(line)
        if text.startswith("event:"):
            current_event = text[len("event:") :].strip()
            continue
        if not text.startswith("data:"):
            continue
        try:
            data = json.loads(text[len("data:") :].strip())
        except Exception:
            data = None
        if current_event == "message.completed" and isinstance(data, dict):
            completed = data
    assert completed is not None, "Did not receive message.completed payload"
    return completed


class _FakeAnthropicUsage:
    def __init__(
        self,
        *,
        input_tokens: int,
        output_tokens: int,
        cache_read_input_tokens: int = 0,
        cache_creation_input_tokens: int = 0,
        thinking_tokens: int = 0,
    ) -> None:
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cache_read_input_tokens = cache_read_input_tokens
        self.cache_creation_input_tokens = cache_creation_input_tokens
        self.thinking_tokens = thinking_tokens


class _FakeAnthropicContentBlock:
    def __init__(self, *, typ: str, block_id: Optional[str] = None, name: Optional[str] = None, text: str = "", input_obj: Optional[Dict[str, Any]] = None) -> None:
        self.type = typ
        if block_id is not None:
            self.id = block_id
        if name is not None:
            self.name = name
        if text:
            self.text = text
        if input_obj is not None:
            self.input = input_obj


class _FakeAnthropicMessage:
    def __init__(self, *, usage: _FakeAnthropicUsage, content: List[Any]) -> None:
        self.usage = usage
        self.content = content


class _FakeAnthropicStreamEvent:
    def __init__(self, typ: str, **kwargs: Any) -> None:
        self.type = typ
        for key, value in kwargs.items():
            setattr(self, key, value)


class _FakeAnthropicStream:
    def __init__(self, final_message: _FakeAnthropicMessage, events: List[Any]) -> None:
        self._final_message = final_message
        self._events = list(events)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def __iter__(self):
        return iter(self._events)

    def get_final_message(self):
        return self._final_message


class _FakeAnthropicMessages:
    def __init__(self, stream_scripts: List[Dict[str, Any]]) -> None:
        self._stream_scripts = list(stream_scripts)
        self.stream_calls: List[Dict[str, Any]] = []
        self.create_calls: List[Dict[str, Any]] = []
        self._stream_idx = 0

    def stream(self, **kwargs: Any):
        self.stream_calls.append(dict(kwargs))
        script = self._stream_scripts[self._stream_idx]
        self._stream_idx += 1
        return _FakeAnthropicStream(script["final_message"], script.get("events") or [])

    def create(self, **kwargs: Any):
        self.create_calls.append(dict(kwargs))
        return _FakeAnthropicMessage(usage=_FakeAnthropicUsage(input_tokens=1, output_tokens=1), content=[])


class _FakeAnthropicClient:
    def __init__(self, api_key: Optional[str] = None, stream_scripts: Optional[List[Dict[str, Any]]] = None) -> None:
        self.api_key = api_key
        self.messages = _FakeAnthropicMessages(list(stream_scripts or []))


def test_anthropic_stream_aggregates_cache_across_tool_loop(monkeypatch):
    monkeypatch.setattr(settings, "ANTHROPIC_API_KEY", "anth-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    monkeypatch.setattr(settings, "TOOLS_EXECUTION_MODE", "server")
    monkeypatch.setattr(settings, "ANTHROPIC_INTERLEAVED_THINKING_BETA", None)
    monkeypatch.setattr(settings, "ANTHROPIC_CACHE_TTL", None)

    chat_router = _ensure_v0_router()

    scripts = [
        {
            "events": [
                _FakeAnthropicStreamEvent(
                    "content_block_start",
                    index=0,
                    content_block=_FakeAnthropicContentBlock(
                        typ="tool_use",
                        block_id="toolu_1",
                        name="read_file",
                        input_obj={},
                    ),
                ),
                _FakeAnthropicStreamEvent(
                    "content_block_delta",
                    index=0,
                    delta=type("Delta", (), {"type": "input_json_delta", "partial_json": '{"path":"alpha.txt"}'})(),
                ),
                _FakeAnthropicStreamEvent("content_block_stop", index=0),
            ],
            "final_message": _FakeAnthropicMessage(
                usage=_FakeAnthropicUsage(
                    input_tokens=500,
                    output_tokens=20,
                    cache_read_input_tokens=200,
                    cache_creation_input_tokens=100,
                    thinking_tokens=30,
                ),
                content=[_FakeAnthropicContentBlock(typ="tool_use", block_id="toolu_1", name="read_file", input_obj={"path": "alpha.txt"})],
            ),
        },
        {
            "events": [
                _FakeAnthropicStreamEvent(
                    "content_block_start",
                    index=0,
                    content_block=_FakeAnthropicContentBlock(typ="text", text=""),
                ),
                _FakeAnthropicStreamEvent(
                    "content_block_delta",
                    index=0,
                    delta=type("Delta", (), {"type": "text_delta", "text": "done"})(),
                ),
            ],
            "final_message": _FakeAnthropicMessage(
                usage=_FakeAnthropicUsage(
                    input_tokens=400,
                    output_tokens=10,
                    cache_read_input_tokens=50,
                    cache_creation_input_tokens=25,
                    thinking_tokens=5,
                ),
                content=[_FakeAnthropicContentBlock(typ="text", text="done")],
            ),
        },
    ]

    fake_holder: Dict[str, Any] = {}

    def _client_factory(api_key: Optional[str] = None):
        inst = _FakeAnthropicClient(api_key=api_key, stream_scripts=scripts)
        fake_holder["inst"] = inst
        return inst

    def _fake_execute_tool(name: str, args_obj: Any, policy: Any) -> Dict[str, Any]:
        return {"ok": True, "data": {"path": "alpha.txt", "content": "alpha"}}

    fake_module = types.SimpleNamespace(Anthropic=_client_factory)
    monkeypatch.setitem(sys.modules, "anthropic", fake_module)
    monkeypatch.setattr(chat_router, "execute_tool", _fake_execute_tool, raising=False)
    monkeypatch.setattr(
        chat_router,
        "available_tools_for",
        lambda level, enabled, browser_enabled=False: [
            {
                "type": "function",
                "name": "read_file",
                "description": "Read a file",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
            }
        ]
        if enabled
        else [],
        raising=False,
    )

    client = TestClient(app)
    completed = _collect_completed_payload(
        client,
        {
            "model": "claude-sonnet-4-6",
            "messages": [{"role": "user", "content": "read alpha then summarize"}],
            "enable_tools": True,
            "control_level": 3,
        },
    )

    usage = completed.get("usage") or {}
    assert int(usage.get("cache_read_input_tokens") or 0) == 250
    assert int(usage.get("cache_creation_input_tokens") or 0) == 125
    assert int(usage.get("thinking_tokens") or 0) == 35

    provider_steps = usage.get("provider_steps") or []
    assert len(provider_steps) == 2
    assert int(provider_steps[0].get("cache_read_input_tokens") or 0) == 200
    assert int(provider_steps[0].get("cache_creation_input_tokens") or 0) == 100
    assert int(provider_steps[1].get("cache_read_input_tokens") or 0) == 50
    assert int(provider_steps[1].get("cache_creation_input_tokens") or 0) == 25


def test_gemini_usage_details_capture_cached_content_tokens():
    import app.routers.chat as chat_router

    payload = {
        "usage": {
            "input_tokens": 240,
            "output_tokens": 40,
            "total_tokens": 280,
            "cached_input_tokens": 90,
            "output_tokens_details": {"reasoning_tokens": 12},
        }
    }
    usage = chat_router._responses_usage_details_from_data(payload)
    assert int(usage.get("cached_input_tokens") or 0) == 90
    assert int((usage.get("input_tokens_details") or {}).get("cached_tokens") or 0) == 90
    assert int(usage.get("thinking_tokens") or 0) == 12

    class _Usage:
        prompt_token_count = 600
        cached_content_token_count = 250

    assert chat_router._gemini_cached_input_tokens_from_usage_metadata(_Usage()) == 250


def test_xai_prompt_cache_conv_id_prefers_stable_terminal(monkeypatch):
    import app.routers.chat as chat_router

    body = type(
        "Body",
        (),
        {
            "prompt_cache_key": None,
            "terminal_id": "term-123",
            "xai_response_id_history": ["resp-old"],
            "xai_previous_response_id": "resp-prev",
        },
    )()

    conv_id_1 = chat_router._xai_prompt_cache_conv_id(body, "session-a")
    conv_id_2 = chat_router._xai_prompt_cache_conv_id(body, "session-b")
    assert isinstance(conv_id_1, str) and conv_id_1
    assert conv_id_1 == conv_id_2
