import json
import sys
import types
from pathlib import Path
from typing import Any, Dict, List, Optional

from starlette.testclient import TestClient


_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.main import app
from app.settings import settings


def _ensure_v0_router():
    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass
    return chat_router


class _FakeGeminiFunctionCall:
    def __init__(self, *, name: str, args: Dict[str, Any], call_id: str):
        self.name = name
        self.args = args
        self.id = call_id


class _FakeGeminiPart:
    def __init__(self, **kwargs: Any):
        self.__dict__.update(kwargs)


class _FakeGeminiContent:
    def __init__(self, *, role: str, parts: List[Any]):
        self.role = role
        self.parts = parts


class _FakeGeminiCandidate:
    def __init__(self, content: Any):
        self.content = content


class _FakeGeminiUsage:
    def __init__(self, *, prompt_token_count: int, candidates_token_count: int, total_token_count: int):
        self.prompt_token_count = prompt_token_count
        self.candidates_token_count = candidates_token_count
        self.total_token_count = total_token_count


class _FakeGeminiResponse:
    def __init__(self, *, candidates: List[Any], usage_metadata: Any):
        self.candidates = candidates
        self.usage_metadata = usage_metadata


class _FakeGenerateContentConfig:
    def __init__(self, **kwargs: Any):
        self.kwargs = kwargs


class _FakeTool:
    def __init__(self, function_declarations=None, google_search=None):
        self.function_declarations = function_declarations
        self.google_search = google_search


class _FakeFunctionDeclaration:
    model_fields = {"parameters_json_schema": object()}

    def __init__(self, **kwargs: Any):
        self.kwargs = kwargs

    def model_dump(self, mode: str = "json", by_alias: bool = True, exclude_none: bool = True):
        return dict(self.kwargs)


class _FakeFunctionCallingConfig:
    def __init__(self, mode: str):
        self.mode = mode


class _FakeToolConfig:
    model_fields = {}

    def __init__(self, **kwargs: Any):
        self.kwargs = kwargs


class _FakeFunctionResponse:
    def __init__(self, **kwargs: Any):
        self.__dict__.update(kwargs)


class _FakeGoogleSearch:
    pass


class _FakeTypes:
    Content = _FakeGeminiContent
    Part = _FakeGeminiPart
    Tool = _FakeTool
    ToolConfig = _FakeToolConfig
    FunctionCallingConfig = _FakeFunctionCallingConfig
    FunctionDeclaration = _FakeFunctionDeclaration
    FunctionResponse = _FakeFunctionResponse
    GenerateContentConfig = _FakeGenerateContentConfig
    GoogleSearch = _FakeGoogleSearch


class _FakeGeminiModels:
    def __init__(self, responses: List[Any]):
        self._responses = list(responses)
        self.calls: List[Dict[str, Any]] = []
        self.stream_calls: List[Dict[str, Any]] = []

    def generate_content(self, *, model: str, contents: List[Any], config: Any):
        self.calls.append({"model": model, "contents": contents, "config": config})
        if not self._responses:
            raise RuntimeError("fake Gemini responses exhausted")
        return self._responses.pop(0)

    def generate_content_stream(self, *, model: str, contents: List[Any], config: Any):
        self.stream_calls.append({"model": model, "contents": contents, "config": config})
        return []


class _FakeGenAIClient:
    def __init__(self, *, api_key: str, responses: List[Any]):
        self.api_key = api_key
        self.models = _FakeGeminiModels(responses)


def _collect_sse_events(client: TestClient, payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    response = client.post("/v0/chat/stream", json=payload)
    assert response.status_code == 200
    events: List[Dict[str, Any]] = []
    current_event = None
    for line in response.iter_lines():
        text = line.decode("utf-8") if isinstance(line, (bytes, bytearray)) else str(line)
        if text.startswith("event:"):
            current_event = text[len("event:") :].strip()
            continue
        if not text.startswith("data:"):
            continue
        raw = text[len("data:") :].strip()
        try:
            data = json.loads(raw)
        except Exception:
            data = raw
        events.append({"event": current_event, "data": data})
    return events


def test_gemini_client_dispatch_reuses_function_call_id(monkeypatch):
    monkeypatch.setattr(settings, "GEMINI_API_KEY", "gem-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    monkeypatch.setattr(settings, "TOOLS_EXECUTION_MODE", "client_required")
    monkeypatch.setattr(settings, "APPROVALS_SOURCE", "cli")

    chat_router = _ensure_v0_router()

    detect_response = _FakeGeminiResponse(
        candidates=[
            _FakeGeminiCandidate(
                _FakeGeminiContent(
                    role="model",
                    parts=[
                        _FakeGeminiPart(
                            function_call=_FakeGeminiFunctionCall(
                                name="read_file",
                                args={"path": "alpha.txt"},
                                call_id="gem-call-123",
                            )
                        )
                    ],
                )
            )
        ],
        usage_metadata=_FakeGeminiUsage(
            prompt_token_count=5,
            candidates_token_count=1,
            total_token_count=6,
        ),
    )
    final_response = _FakeGeminiResponse(
        candidates=[
            _FakeGeminiCandidate(
                _FakeGeminiContent(
                    role="model",
                    parts=[_FakeGeminiPart(text="alpha complete")],
                )
            )
        ],
        usage_metadata=_FakeGeminiUsage(
            prompt_token_count=7,
            candidates_token_count=2,
            total_token_count=9,
        ),
    )

    fake_client = _FakeGenAIClient(
        api_key="gem-test",
        responses=[detect_response, final_response, final_response],
    )

    fake_types_module = types.ModuleType("google.genai.types")
    for attr_name in dir(_FakeTypes):
        if attr_name.startswith("_"):
            continue
        setattr(fake_types_module, attr_name, getattr(_FakeTypes, attr_name))

    fake_genai_module = types.ModuleType("google.genai")
    fake_genai_module.Client = lambda api_key=None: fake_client  # type: ignore[attr-defined]
    fake_genai_module.types = fake_types_module  # type: ignore[attr-defined]

    fake_google_module = types.ModuleType("google")
    fake_google_module.genai = fake_genai_module  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "google", fake_google_module)
    monkeypatch.setitem(sys.modules, "google.genai", fake_genai_module)
    monkeypatch.setitem(sys.modules, "google.genai.types", fake_types_module)

    async def _fake_dispatch_tool_and_wait(req, session_id, name, args_obj, call_id, file_policy, extra_requested_policy=None):
        return call_id or "missing", {
            "session_id": session_id,
            "call_id": call_id or "missing",
            "name": name,
            "args": args_obj,
            "job_token": "job-token",
            "timeout_sec": 30,
            "requested_policy": {"scope": "workspace"},
        }

    async def _fake_wait_for_job_result(session_id, call_id, timeout_sec):
        return {"ok": True, "data": {"content": "alpha"}}

    monkeypatch.setattr(chat_router, "_dispatch_tool_and_wait", _fake_dispatch_tool_and_wait, raising=False)
    monkeypatch.setattr(chat_router, "wait_for_job_result", _fake_wait_for_job_result, raising=False)
    monkeypatch.setattr(
        chat_router,
        "available_tools_for",
        lambda level, enabled, browser_enabled=False: [
            {
                "type": "function",
                "name": "read_file",
                "description": "Read a file",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
            }
        ]
        if enabled
        else [],
        raising=False,
    )

    client = TestClient(app)
    events = _collect_sse_events(
        client,
        {
            "model": "gemini-3.1-pro-preview",
            "messages": [{"role": "user", "content": "read alpha"}],
            "enable_tools": True,
            "control_level": 3,
        },
    )

    tool_call = next(evt for evt in events if evt.get("event") == "tool.call")
    tool_dispatch = next(evt for evt in events if evt.get("event") == "tool.dispatch")
    tool_result = next(evt for evt in events if evt.get("event") == "tool.result")

    assert isinstance(tool_call["data"], dict)
    assert isinstance(tool_dispatch["data"], dict)
    assert isinstance(tool_result["data"], dict)
    assert tool_call["data"]["call_id"] == "gem-call-123"
    assert tool_dispatch["data"]["call_id"] == "gem-call-123"
    assert tool_result["data"]["call_id"] == "gem-call-123"
