from yta_editorial_decision.clip import Clip


class ClipAnalyzer:
    """
    Class to analyze clips and get `Clip` instances
    with the information extracted from them.
    """

    def __init__(
        self,
        # TODO: Add config or settings (?)
    ):
        pass

    def analyze(
        self,
        filename: str
    ) -> 'Clip':
        print(f'Reading the video "{filename}"')
        # TODO: Read the video
        print('Obtaining the subtitles')
        # TODO: Obtain subtitles from the video
        clip = Clip(

        )

        return clip