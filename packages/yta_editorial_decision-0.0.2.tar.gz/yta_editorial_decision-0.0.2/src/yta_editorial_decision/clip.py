


class Clip:
    """
    Class to represent a clip that has been analyzed
    by the system and includes the information that
    is useful to make decisions about the edition we
    need to apply.
    """

    def __init__(
        self
    ):
        self.subtitles: any = None
        """
        The subtitles of the clip.
        """