from different_wrapping.utils import (
    docker_port_string_get_external_port,
    get_docker_port_tuple,
)


def test_docker_port_string_get_external_port():
    assert docker_port_string_get_external_port(80) == 80
    assert docker_port_string_get_external_port("80") == "80"
    assert docker_port_string_get_external_port("80:8080") == "80"
    assert docker_port_string_get_external_port("127.0.0.1:80:8080") == "80"


def test_docker_port_tuple():
    assert get_docker_port_tuple(80) == (80, 80)
    assert get_docker_port_tuple("80") == (80, 80)
    assert get_docker_port_tuple("80/tcp") == (80, 80)
    assert get_docker_port_tuple("80/udp") == (80, 80)
    assert get_docker_port_tuple("80:8080") == (80, 8080)
    assert get_docker_port_tuple("80:8080/tcp") == (80, 8080)
    assert get_docker_port_tuple("127.0.0.1:80:8080") == (80, 8080)
    assert get_docker_port_tuple("127.0.0.1:80:8080/tcp") == (80, 8080)
