import json
import shutil
from argparse import Namespace

import pytest

from different_wrapping.cli import run_converter

requires_kompose = pytest.mark.skipif(
    shutil.which("kompose") is None,
    reason="kompose not installed",
)


@requires_kompose
def test_convert_basic_competitions(tmp_path):
    args = Namespace(
        folder="test_competitions/basic",
        destdir=str(tmp_path),
        dry=False,
        ingress_type="ingress",
        dns_host="example.com",
        regcred=None,
        docker_tag="latest",
        docker_image_repo="registry.example.com",
        tcp_xlistenerset_gateway_name=None,
        gateway_parent_name=None,
        gateway_parent_namespace=None,
    )

    run_converter(args)

    # Core output files exist
    assert (tmp_path / "image_buildlist.json").exists()
    assert (tmp_path / "challenge_container_metadata.json").exists()
    assert (tmp_path / "static" / "kustomization.yml").exists()

    # image_buildlist.json is valid JSON with entries
    with open(tmp_path / "image_buildlist.json") as f:
        buildlist = json.load(f)
    assert isinstance(buildlist, list)
    assert len(buildlist) > 0

    # metadata is valid JSON
    with open(tmp_path / "challenge_container_metadata.json") as f:
        metadata = json.load(f)
    assert isinstance(metadata, list)
    assert len(metadata) > 0

    # Static challenges produced per-challenge directories
    assert (tmp_path / "static" / "crypto" / "xor").is_dir()
    assert (tmp_path / "static" / "re" / "js").is_dir()

    # Dynamic challenge directory exists
    assert (tmp_path / "dynamic").is_dir()
