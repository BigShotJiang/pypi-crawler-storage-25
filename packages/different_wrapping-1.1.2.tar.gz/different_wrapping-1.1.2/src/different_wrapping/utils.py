def docker_port_string_get_external_port(port):
    # Extracts external ports from a docker port string
    # See https://docs.docker.com/compose/compose-file/compose-file-v3/#ports
    if isinstance(port, int):
        return port
    components = port.split(":")
    if len(components) == 1:
        return components[0]
    elif len(components) == 2:
        return components[0]
    elif len(components) == 3:
        return components[1]
    else:
        raise RuntimeError("Unable to parse external port")


def get_docker_port_tuple(port):
    # Extracts external ports from a docker port string
    # See https://docs.docker.com/compose/compose-file/compose-file-v3/#ports

    # first value is host port, second value is container-internal port
    if isinstance(port, int):
        return port, port

    # The protocol is alternatively specified after /, we ignore it
    components = port.split("/")[0].split(":")
    if len(components) == 1:
        return int(components[0]), int(components[0])
    elif len(components) == 2:
        return int(components[0]), int(components[1])
    elif len(components) == 3:
        return int(components[1]), int(components[2])
    else:
        raise RuntimeError("Unable to parse external port")
