"""Client-layer tests — JSON-repair + tool-call parsing without hitting any LLM."""
from __future__ import annotations

from johnalin.client import _clean_args_string, parse_tool_calls


def test_clean_args_plain_dict():
    parsed, reason = _clean_args_string('{"a": 1}')
    assert parsed == {"a": 1}
    assert reason == "ok"


def test_clean_args_strips_fences():
    parsed, reason = _clean_args_string('```json\n{"a": 1}\n```')
    assert parsed == {"a": 1}
    assert reason == "ok_after_fence_strip"


def test_clean_args_strips_trailing_comment():
    parsed, reason = _clean_args_string('{"a": 1} // comment')
    assert parsed == {"a": 1}
    assert reason == "ok_after_comment_strip"


def test_clean_args_unparseable():
    parsed, reason = _clean_args_string("not json at all {")
    assert parsed is None
    assert reason == "unparseable"


def test_parse_tool_calls_empty_message():
    assert parse_tool_calls({"role": "assistant", "content": "hi"}) == []


def test_parse_tool_calls_dict_args():
    msg = {
        "tool_calls": [
            {"id": "c1", "type": "function",
             "function": {"name": "bash", "arguments": {"command": "ls"}}},
        ],
    }
    out = parse_tool_calls(msg)
    assert len(out) == 1
    assert out[0]["name"] == "bash"
    assert out[0]["arguments"] == {"command": "ls"}
    assert out[0]["_parse_ok"] is True


def test_parse_tool_calls_string_args_fenced():
    msg = {
        "tool_calls": [
            {"id": "c2", "type": "function",
             "function": {"name": "grep",
                          "arguments": '```json\n{"pattern": "TODO"}\n```'}},
        ],
    }
    out = parse_tool_calls(msg)
    assert out[0]["arguments"] == {"pattern": "TODO"}
    assert out[0]["_parse_ok"] is True


def test_parse_tool_calls_unparseable():
    msg = {
        "tool_calls": [
            {"id": "c3", "type": "function",
             "function": {"name": "bash", "arguments": "not valid json {"}},
        ],
    }
    out = parse_tool_calls(msg)
    assert out[0]["_parse_ok"] is False
    assert out[0]["_parse_reason"] == "unparseable"
    assert "_raw_args" in out[0]
