"""Audit (artifact bundle) tests — uses an isolated tmp_path via env override."""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

import pytest


@pytest.fixture
def isolated_home(tmp_path, monkeypatch):
    monkeypatch.setenv("JOHNALIN_HOME", str(tmp_path / ".johnalin"))
    monkeypatch.setenv("JOHNALIN_ARTIFACTS", str(tmp_path / ".johnalin" / "artifacts"))
    yield tmp_path


def test_write_bundle_creates_four_files(isolated_home):
    from johnalin.audit import new_run_id, write_bundle

    started = datetime.now(timezone.utc)
    ended = started + timedelta(seconds=1)
    run_id = new_run_id("test")
    d = write_bundle(
        run_id=run_id,
        started=started,
        ended=ended,
        request={"message": "hi"},
        response={"text": "hello", "stopped": "stop", "status": "ok"},
        trace_events=[{"type": "test", "x": 1}],
        usage={"max_context": 16384, "peak_prompt_tokens": 100, "total": {"total_tokens": 102}},
    )
    assert (d / "metadata.json").is_file()
    assert (d / "request.json").is_file()
    assert (d / "response.json").is_file()
    assert (d / "trace.json").is_file()

    md = json.loads((d / "metadata.json").read_text())
    assert md["run_id"] == run_id
    assert md["context"]["fits"] is True
    assert md["context"]["risk"] is False  # 100/16384 ≪ 0.8

    tr = json.loads((d / "trace.json").read_text())
    assert tr["events"] == [{"type": "test", "x": 1}]


def test_context_fit_risk_threshold(isolated_home):
    from johnalin.audit import context_fit
    f = context_fit({"max_context": 100, "peak_prompt_tokens": 90,
                     "total": {"total_tokens": 95}})
    assert f["risk"] is True  # 0.9 >= 0.8
    f2 = context_fit({"max_context": 100, "peak_prompt_tokens": 50,
                      "total": {"total_tokens": 60}})
    assert f2["risk"] is False
