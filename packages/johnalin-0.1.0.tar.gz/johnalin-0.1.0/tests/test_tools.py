"""Tool-layer tests — pure-python, no LLM needed."""
from __future__ import annotations

from pathlib import Path

import pytest

from johnalin.tools import (
    ALL_TOOLS,
    TOOLS_BY_NAME,
    register,
    run_tool,
    tool_schemas,
    tool_summary_block,
    unknown_tool_names,
)
from johnalin.tools.base import Tool


def test_default_registry_size():
    """v0.1 ships exactly 5 tools."""
    assert len(ALL_TOOLS) == 5
    names = {t.name for t in ALL_TOOLS}
    assert names == {"bash", "file_read", "file_write", "glob", "grep"}


def test_tool_schemas_filter():
    full = tool_schemas()
    subset = tool_schemas(["file_read", "grep"])
    assert len(full) == 5
    assert len(subset) == 2
    assert {t["function"]["name"] for t in subset} == {"file_read", "grep"}


def test_tool_summary_block_filter():
    full = tool_summary_block()
    subset = tool_summary_block(["bash"])
    assert "bash" in full and "file_read" in full
    assert "bash" in subset and "file_read" not in subset


def test_unknown_tool_names():
    assert unknown_tool_names(["bash", "nonexistent"]) == ["nonexistent"]
    assert unknown_tool_names(["bash"]) == []


def test_bash_runs_and_caps_output():
    out = run_tool(TOOLS_BY_NAME["bash"], {"command": "echo hello"})
    assert "[exit 0]" in out
    assert "hello" in out


def test_bash_handles_missing_command():
    out = run_tool(TOOLS_BY_NAME["bash"], {})
    assert "[bash error]" in out


def test_bash_timeout():
    out = run_tool(TOOLS_BY_NAME["bash"], {"command": "sleep 5", "timeout": 1})
    assert "timeout" in out


def test_file_read_round_trip(tmp_path: Path):
    p = tmp_path / "hello.txt"
    p.write_text("line1\nline2\nline3\n")
    out = run_tool(TOOLS_BY_NAME["file_read"], {"path": str(p)})
    assert "line1" in out and "line2" in out and "line3" in out
    # numbered output
    assert "\t" in out


def test_file_read_offset_limit(tmp_path: Path):
    p = tmp_path / "many.txt"
    p.write_text("\n".join(f"line{i}" for i in range(10)) + "\n")
    out = run_tool(TOOLS_BY_NAME["file_read"], {"path": str(p), "offset": 5, "limit": 2})
    assert "line5" in out and "line6" in out
    assert "line0" not in out and "line9" not in out


def test_file_write_creates_parents(tmp_path: Path):
    p = tmp_path / "new" / "deep" / "out.txt"
    out = run_tool(TOOLS_BY_NAME["file_write"], {"path": str(p), "content": "hi"})
    assert "[ok]" in out
    assert p.read_text() == "hi"


def test_glob_finds_files(tmp_path: Path):
    (tmp_path / "a.py").write_text("")
    (tmp_path / "b.py").write_text("")
    (tmp_path / "c.txt").write_text("")
    out = run_tool(TOOLS_BY_NAME["glob"], {"pattern": "*.py", "root": str(tmp_path)})
    assert "a.py" in out and "b.py" in out and "c.txt" not in out


def test_grep_finds_pattern(tmp_path: Path):
    (tmp_path / "f.py").write_text("import os\nTODO: refactor\nprint('hi')\n")
    out = run_tool(TOOLS_BY_NAME["grep"], {"pattern": "TODO", "path": str(tmp_path)})
    assert "TODO: refactor" in out


def test_register_custom_tool():
    custom = Tool(
        name="echo_test",
        description="echoes args",
        parameters={"type": "object", "properties": {}},
        execute=lambda args: f"got {args}",
    )
    register(custom)
    assert "echo_test" in TOOLS_BY_NAME
    out = run_tool(TOOLS_BY_NAME["echo_test"], {"hello": "world"})
    assert "got" in out
    # Cleanup so the rest of the suite is unaffected
    ALL_TOOLS.remove(custom)
    del TOOLS_BY_NAME["echo_test"]


def test_register_rejects_duplicate():
    with pytest.raises(ValueError):
        register(TOOLS_BY_NAME["bash"])
