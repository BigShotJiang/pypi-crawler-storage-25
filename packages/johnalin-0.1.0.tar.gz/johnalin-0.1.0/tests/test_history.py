"""History (SQLite) tests — uses an isolated tmp_path via env override."""
from __future__ import annotations

from datetime import datetime, timezone

import pytest


@pytest.fixture
def isolated_home(tmp_path, monkeypatch):
    monkeypatch.setenv("JOHNALIN_HOME", str(tmp_path / ".johnalin"))
    monkeypatch.setenv("JOHNALIN_DB", str(tmp_path / ".johnalin" / "history.db"))
    yield tmp_path


def test_ensure_db_creates_file(isolated_home):
    from johnalin.config import db_path
    from johnalin.history import ensure_db
    ensure_db()
    assert db_path().exists()


def test_log_turn_round_trip(isolated_home):
    from johnalin.history import ensure_db, latest_n, log_turn
    ensure_db()
    row = {
        "run_id": "test_001",
        "ts": datetime.now(timezone.utc).isoformat(),
        "session_id": "sess",
        "model": "qwen2.5:7b",
        "tools_enabled": 1,
        "input_text": "say hi",
        "output_text": "hi",
        "in_tokens": 10,
        "out_tokens": 2,
        "total_tokens": 12,
        "turns": 1,
        "stopped": "stop",
        "duration_ms": 500,
        "context_util": 0.05,
        "fits": 1,
        "risk": 0,
        "artifact_dir": "",
        "request_json": "{}",
        "response_json": "{}",
        "trace_json": "[]",
    }
    log_turn(row)
    rows = latest_n(5)
    assert len(rows) == 1
    assert rows[0]["run_id"] == "test_001"
    assert rows[0]["model"] == "qwen2.5:7b"
