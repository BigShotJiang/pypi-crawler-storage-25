"""OpenAI-compatible client for local LLM backends (ollama / vLLM / LM Studio / etc.).

Single thin wrapper — same shape as OpenAI's `/v1/chat/completions`. Designed to
talk to ollama by default. JSON-repair logic handles models that emit tool-call
arguments with stray fences / trailing comments.
"""
from __future__ import annotations

import json
import re
from typing import Any

import httpx

from .config import Settings

_FENCE_RE = re.compile(r"^\s*```(?:json|JSON)?\s*\n?(.*?)\n?\s*```\s*$", re.DOTALL)
_TRAILING_COMMENT_RE = re.compile(r"(?://[^\n]*|#[^\n]*)$", re.MULTILINE)


class ProviderError(RuntimeError):
    """Raised when the upstream LLM backend returns a non-2xx response."""

    def __init__(self, status: int, body: Any, url: str) -> None:
        self.status = status
        self.body = body
        self.url = url
        super().__init__(f"upstream {status} from {url}: {body!r}"[:500])


class Provider:
    """OAI-compat HTTP client. Defaults read from env via `Settings.from_env()`."""

    def __init__(
        self,
        base_url: str | None = None,
        model: str | None = None,
        timeout: float | None = None,
        max_context: int | None = None,
    ) -> None:
        s = Settings.from_env()
        self.base_url = (base_url or s.base_url).rstrip("/")
        self.model = model or s.model
        self.timeout = timeout if timeout is not None else s.timeout_s
        self.max_context = max_context if max_context is not None else s.num_ctx

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
    ) -> dict[str, Any]:
        """Non-streaming chat completion. Returns the OpenAI-format response dict."""
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "stream": False,
            "options": {"num_ctx": self.max_context},
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        url = f"{self.base_url}/chat/completions"
        with httpx.Client(timeout=self.timeout) as c:
            r = c.post(url, json=payload)
        if r.status_code >= 400:
            try:
                body: Any = r.json()
            except ValueError:
                body = r.text
            raise ProviderError(r.status_code, body, url)
        return r.json()

    def health(self) -> dict[str, Any]:
        """Cheap probe — does the upstream answer at all? Returns {ok, model_loaded}."""
        url = self.base_url.rsplit("/v1", 1)[0]
        try:
            with httpx.Client(timeout=2.0) as c:
                r = c.get(f"{url}/api/tags")
            r.raise_for_status()
            tags = r.json().get("models", []) or []
            return {"ok": True, "models_count": len(tags), "configured_model": self.model}
        except httpx.HTTPError as e:
            return {"ok": False, "error": str(e), "configured_model": self.model}


def _clean_args_string(s: str) -> tuple[Any, str]:
    """Repair model-emitted tool-call args: strip fences/comments, retry parse."""
    if not isinstance(s, str):
        return s, "ok_passthrough"
    s_stripped = s.strip()
    if not s_stripped:
        return {}, "empty"

    try:
        return json.loads(s_stripped), "ok"
    except json.JSONDecodeError:
        pass

    m = _FENCE_RE.match(s_stripped)
    if m:
        try:
            return json.loads(m.group(1).strip()), "ok_after_fence_strip"
        except json.JSONDecodeError:
            pass

    cleaned = _TRAILING_COMMENT_RE.sub("", s_stripped).strip()
    if cleaned and cleaned != s_stripped:
        try:
            return json.loads(cleaned), "ok_after_comment_strip"
        except json.JSONDecodeError:
            pass

    return None, "unparseable"


def parse_tool_calls(message: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract + normalise tool_calls from an assistant message.

    Each entry: {id, name, arguments (dict), _parse_ok, _parse_reason, _raw_args?}.
    """
    calls = message.get("tool_calls") or []
    out: list[dict[str, Any]] = []
    for c in calls:
        fn = c.get("function") or {}
        raw = fn.get("arguments", {})
        if isinstance(raw, dict):
            args, parse_ok, reason, raw_str = raw, True, "ok_dict", None
        else:
            raw_string = raw if isinstance(raw, str) else json.dumps(raw)
            parsed, reason = _clean_args_string(raw_string)
            if parsed is None:
                args, parse_ok, raw_str = {}, False, raw_string
            elif isinstance(parsed, dict):
                args, parse_ok, raw_str = parsed, True, None
            else:
                args, parse_ok, raw_str = {"_value": parsed}, True, None

        entry: dict[str, Any] = {
            "id": c.get("id") or "",
            "name": fn.get("name", ""),
            "arguments": args,
            "_parse_ok": parse_ok,
            "_parse_reason": reason,
        }
        if raw_str is not None:
            entry["_raw_args"] = raw_str
        out.append(entry)
    return out
