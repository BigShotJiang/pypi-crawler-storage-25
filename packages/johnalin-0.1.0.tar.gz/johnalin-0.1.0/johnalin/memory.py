"""Memory directory — finds and reads CLAUDE.md / .claude.md files.

Walks up from cwd collecting project memory, then checks ~/.claude/ for global
user memory. Closest project memory first, user memory last.
"""
from __future__ import annotations

import os
from pathlib import Path

MEMORY_FILENAMES = ("CLAUDE.md", ".claude.md")


def _read_if_exists(path: Path) -> str | None:
    try:
        if path.is_file():
            return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    return None


def find_project_memory(start: Path | None = None) -> list[tuple[Path, str]]:
    """Walk up from `start` (or cwd). Collect every CLAUDE.md found, parent → root."""
    start = (start or Path.cwd()).resolve()
    hits: list[tuple[Path, str]] = []
    seen: set[Path] = set()
    cur = start
    while cur not in seen:
        seen.add(cur)
        for name in MEMORY_FILENAMES:
            p = cur / name
            content = _read_if_exists(p)
            if content is not None:
                hits.append((p, content))
        if cur.parent == cur:
            break
        cur = cur.parent
    return hits


def find_user_memory() -> list[tuple[Path, str]]:
    """Global user memory under ~/.claude/."""
    home = Path(os.environ.get("HOME", "~")).expanduser()
    hits: list[tuple[Path, str]] = []
    for name in MEMORY_FILENAMES:
        p = home / ".claude" / name
        content = _read_if_exists(p)
        if content is not None:
            hits.append((p, content))
    return hits


def collect_memory(start: Path | None = None) -> list[tuple[Path, str]]:
    """All memory files in priority order: closest project memory first."""
    return find_project_memory(start) + find_user_memory()
