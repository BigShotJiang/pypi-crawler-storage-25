"""johnalin — self-contained agentic CLI for local LLMs.

Two entry points:
- `johnalin`       : interactive REPL with SQLite history + per-turn debug panels.
- `johnalin-cli`   : one-shot CLI with --tools whitelist + exit-code discipline.

Backed by a local OpenAI-compatible LLM (default: ollama at 127.0.0.1:11434).
"""
__version__ = "0.1.0"

from .client import Provider, ProviderError  # noqa: F401
from .engine import run_turn  # noqa: F401  (public API)
