"""SQLite history — append-only per-turn log shared by the REPL and CLI.

DB file is `~/.johnalin/history.db` by default (`JOHNALIN_DB` env override).
Same schema written by both `johnalin` and `johnalin-cli` so you can grep
across modes.
"""
from __future__ import annotations

import sqlite3
from contextlib import closing
from typing import Any

from .config import db_path, home_dir

SCHEMA_DDL = """
CREATE TABLE IF NOT EXISTS turns (
    run_id        TEXT PRIMARY KEY,
    ts            TEXT NOT NULL,
    session_id    TEXT NOT NULL,
    model         TEXT NOT NULL,
    tools_enabled INTEGER NOT NULL,
    input_text    TEXT NOT NULL,
    output_text   TEXT NOT NULL,
    in_tokens     INTEGER,
    out_tokens    INTEGER,
    total_tokens  INTEGER,
    turns         INTEGER,
    stopped       TEXT,
    duration_ms   INTEGER,
    context_util  REAL,
    fits          INTEGER,
    risk          INTEGER,
    artifact_dir  TEXT,
    request_json  TEXT,
    response_json TEXT,
    trace_json    TEXT
);
CREATE INDEX IF NOT EXISTS idx_turns_ts ON turns(ts);
CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_id);
CREATE INDEX IF NOT EXISTS idx_turns_model ON turns(model);
"""


def ensure_db() -> None:
    home_dir().mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(str(db_path()))) as c:
        c.executescript(SCHEMA_DDL)
        c.commit()


def log_turn(row: dict[str, Any]) -> None:
    """Append (or replace by run_id) one turn record."""
    with closing(sqlite3.connect(str(db_path()))) as c:
        c.execute(
            """INSERT OR REPLACE INTO turns
            (run_id, ts, session_id, model, tools_enabled, input_text, output_text,
             in_tokens, out_tokens, total_tokens, turns, stopped, duration_ms,
             context_util, fits, risk, artifact_dir,
             request_json, response_json, trace_json)
            VALUES (:run_id, :ts, :session_id, :model, :tools_enabled, :input_text,
                    :output_text, :in_tokens, :out_tokens, :total_tokens, :turns,
                    :stopped, :duration_ms, :context_util, :fits, :risk, :artifact_dir,
                    :request_json, :response_json, :trace_json)""",
            row,
        )
        c.commit()


def latest_n(n: int = 10) -> list[dict[str, Any]]:
    """Most recent `n` turns (descending by ts)."""
    with closing(sqlite3.connect(str(db_path()))) as c:
        c.row_factory = sqlite3.Row
        rows = c.execute(
            "SELECT * FROM turns ORDER BY ts DESC LIMIT ?", (n,)
        ).fetchall()
    return [dict(r) for r in rows]
