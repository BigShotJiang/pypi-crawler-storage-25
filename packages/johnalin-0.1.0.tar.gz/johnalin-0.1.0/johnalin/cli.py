"""johnalin-cli — one-shot CLI surface for the embedded agent.

Forces the caller to declare exactly which tools the local agent gets per call.
Designed for shell pipelines + meta-agents (Claude, scripts) that need to
branch on exit codes:

    0  stop                     normal completion
    1  tool_calls_unparseable   model emitted broken JSON for tool args
    2  repeat_loop              same tool call twice in a row → killed loop
    3  max_turns                tool loop hit the cap without finishing
    4  http_or_network_error    couldn't reach ollama
    5  usage_error              bad CLI args
"""
from __future__ import annotations

import argparse
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

import httpx

from .audit import write_bundle
from .client import Provider, ProviderError
from .config import Settings
from .engine import run_turn
from .history import ensure_db, log_turn
from .tools import unknown_tool_names

EXIT_STOP = 0
EXIT_UNPARSEABLE = 1
EXIT_REPEAT_LOOP = 2
EXIT_MAX_TURNS = 3
EXIT_HTTP = 4
EXIT_USAGE = 5


def _stopped_to_exit(stopped: str) -> int:
    return {
        "stop": EXIT_STOP,
        "tool_calls_unparseable": EXIT_UNPARSEABLE,
        "repeat_loop": EXIT_REPEAT_LOOP,
        "max_turns": EXIT_MAX_TURNS,
    }.get(stopped or "", EXIT_STOP)


class _ArgParser(argparse.ArgumentParser):
    """argparse subclass that exits with EXIT_USAGE (5) instead of the hardcoded 2.
    Keeps exit-code 2 reserved for repeat_loop so callers can branch unambiguously."""

    def error(self, message: str) -> None:  # type: ignore[override]
        self.print_usage(sys.stderr)
        self.exit(EXIT_USAGE, f"{self.prog}: error: {message}\n")


def main() -> int:
    p = _ArgParser(
        prog="johnalin-cli",
        description="One-shot CLI for the local agent. Whitelist tools per call.",
    )
    p.add_argument(
        "--tools", required=True,
        help=(
            "Comma-separated whitelist of tool names (REQUIRED). "
            "Available: bash, file_read, file_write, glob, grep. "
            "Use --tools=NONE to advertise zero tools (chat-only)."
        ),
    )
    p.add_argument("--message", "-m", required=True, help="Prompt to send to the local agent.")
    p.add_argument("--max-turns", type=int, default=None, help="Tool-loop cap (default 10).")
    p.add_argument("--cwd", default=str(Path.cwd()), help="Working directory the agent's bash tool sees.")
    p.add_argument("--model", default=None, help="Override model id (default $OLLAMA_MODEL).")
    p.add_argument("--base-url", default=None, help="Override OAI-compat endpoint (default $OLLAMA_BASE_URL).")
    p.add_argument("--num-ctx", type=int, default=None, help="Override num_ctx (default $JOHNALIN_NUM_CTX).")
    p.add_argument("--no-audit", action="store_true", help="Skip writing per-call artifact bundle to disk.")
    p.add_argument("--quiet", action="store_true", help="Suppress stderr diagnostics (still logs to DB).")
    args = p.parse_args()

    raw = args.tools.strip()
    if raw.upper() == "NONE":
        tools_list: list[str] = []
    else:
        tools_list = [t.strip() for t in raw.split(",") if t.strip()]
        if not tools_list:
            print("error: --tools must be non-empty or 'NONE'", file=sys.stderr)
            return EXIT_USAGE
        unknown = unknown_tool_names(tools_list)
        if unknown:
            print(f"error: unknown tool name(s): {', '.join(unknown)}", file=sys.stderr)
            return EXIT_USAGE

    s = Settings.from_env()
    provider = Provider(
        base_url=args.base_url or s.base_url,
        model=args.model or s.model,
        max_context=args.num_ctx or s.num_ctx,
    )

    started = datetime.now(timezone.utc)
    run_id_local = f"cli_{uuid.uuid4().hex[:12]}"

    try:
        result = run_turn(
            user_message=args.message,
            provider=provider,
            cwd=Path(args.cwd),
            max_turns=args.max_turns or s.max_turns,
            tools_filter=tools_list if tools_list else [],
        )
    except (ProviderError, httpx.HTTPError) as e:
        if not args.quiet:
            print(f"johnalin-cli: upstream error: {e}", file=sys.stderr)
        return EXIT_HTTP

    ended = datetime.now(timezone.utc)
    duration_ms = int((ended - started).total_seconds() * 1000)
    text = result.get("text") or ""
    stopped = result.get("stopped") or ""
    usage = result.get("usage") or {}
    peak = int(usage.get("peak_prompt_tokens") or 0)
    total_tokens = int((usage.get("total") or {}).get("total_tokens") or 0)
    out_tokens = sum(int(t.get("completion_tokens") or 0) for t in usage.get("per_turn") or [])

    artifact_dir = ""
    if not args.no_audit:
        try:
            d = write_bundle(
                run_id=run_id_local,
                started=started,
                ended=ended,
                request={
                    "message": args.message,
                    "cwd": args.cwd,
                    "max_turns": args.max_turns or s.max_turns,
                    "tools": tools_list,
                    "model": provider.model,
                },
                response={
                    "text": text,
                    "turns": result.get("turns"),
                    "stopped": stopped,
                    "status": "ok",
                },
                trace_events=result.get("trace") or [],
                usage=usage,
            )
            artifact_dir = str(d)
        except OSError as e:
            if not args.quiet:
                print(f"johnalin-cli: audit write failed (non-fatal): {e}", file=sys.stderr)

    try:
        ensure_db()
        max_ctx = int(usage.get("max_context") or 0)
        util = (peak / max_ctx) if max_ctx > 0 else 0.0
        log_turn({
            "run_id": run_id_local,
            "ts": started.isoformat(),
            "session_id": f"cli-{started.strftime('%Y%m%d-%H%M%S')}",
            "model": provider.model,
            "tools_enabled": int(bool(tools_list)),
            "input_text": args.message,
            "output_text": text,
            "in_tokens": peak,
            "out_tokens": out_tokens,
            "total_tokens": total_tokens,
            "turns": int(result.get("turns") or 0),
            "stopped": stopped,
            "duration_ms": duration_ms,
            "context_util": util,
            "fits": int(bool(max_ctx) and peak <= max_ctx),
            "risk": int(bool(max_ctx) and util >= 0.8),
            "artifact_dir": artifact_dir,
            "request_json": json.dumps({"message": args.message, "tools": tools_list}, ensure_ascii=False),
            "response_json": json.dumps({"text": text, "stopped": stopped}, ensure_ascii=False),
            "trace_json": json.dumps(result.get("trace") or [], ensure_ascii=False),
        })
    except Exception as e:
        if not args.quiet:
            print(f"johnalin-cli: db log failed (non-fatal): {e}", file=sys.stderr)

    print(text)
    if not args.quiet:
        print(f"run_id={run_id_local} stopped={stopped} duration_ms={duration_ms}", file=sys.stderr)

    return _stopped_to_exit(stopped)


if __name__ == "__main__":
    raise SystemExit(main())
