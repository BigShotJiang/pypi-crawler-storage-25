"""System-prompt builder — assembles preamble + environment + memory + tools.

Returns a (prompt, report) pair when `with_report=True`. The report tracks char
counts at each section, useful for debugging "system-prompt bloat" (one of
johnalin's documented differentiators — see docs/architecture.md).
"""
from __future__ import annotations

import os
import platform
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, overload

from .memory import collect_memory

STATIC_PREAMBLE = """You are a local AI agent powered by an open-weight LLM. \
You have tools to read/write files, search, and run shell commands. \
Prefer calling a tool over guessing. Be concise. One tool at a time."""


def _git_brief(cwd: Path) -> str:
    try:
        branch = subprocess.run(
            ["git", "-C", str(cwd), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=2,
        )
        if branch.returncode != 0:
            return ""
        status = subprocess.run(
            ["git", "-C", str(cwd), "status", "--porcelain"],
            capture_output=True, text=True, timeout=2,
        )
        dirty = "dirty" if status.stdout.strip() else "clean"
        return f"Git: branch={branch.stdout.strip()} ({dirty})"
    except (OSError, subprocess.TimeoutExpired):
        return ""


@overload
def build_system_prompt(tools_block: str = ..., cwd: Path | None = ..., with_report: bool = False) -> str: ...
@overload
def build_system_prompt(tools_block: str, cwd: Path | None, with_report: bool) -> tuple[str, dict[str, Any]]: ...


def build_system_prompt(
    tools_block: str = "",
    cwd: Path | None = None,
    with_report: bool = False,
):
    """Return the full system prompt string, or (prompt, report) when with_report=True."""
    cwd = (cwd or Path.cwd()).resolve()

    parts: list[str] = [STATIC_PREAMBLE, ""]

    ctx_lines = [
        f"Date: {datetime.now().isoformat(timespec='seconds')}",
        f"OS: {platform.system()} {platform.release()}",
        f"User: {os.environ.get('USER', 'unknown')}",
        f"Working directory: {cwd}",
    ]
    git = _git_brief(cwd)
    if git:
        ctx_lines.append(git)
    env_block = "## Environment\n" + "\n".join(ctx_lines)
    parts.append(env_block)

    mem = collect_memory(cwd)
    injected_files: list[dict[str, Any]] = []
    if mem:
        parts.append("## Workspace memory (in priority order)")
        for path, content in mem:
            stripped = content.strip()
            block = f"### {path}\n{stripped}"
            parts.append(block)
            injected_files.append({
                "name": Path(path).name,
                "path": str(path),
                "rawChars": len(content),
                "injectedChars": len(stripped),
            })

    tools_block_chars = 0
    if tools_block:
        parts.append("## Tools available\n" + tools_block)
        tools_block_chars = len(tools_block)

    prompt = "\n\n".join(parts)

    if not with_report:
        return prompt

    report: dict[str, Any] = {
        "source": "johnalin.prompt",
        "generatedAt": datetime.utcnow().isoformat(timespec="milliseconds") + "Z",
        "workspaceDir": str(cwd),
        "systemPrompt": {
            "chars": len(prompt),
            "staticPreambleChars": len(STATIC_PREAMBLE),
            "environmentBlockChars": len(env_block),
            "toolsBlockChars": tools_block_chars,
        },
        "injectedWorkspaceFiles": injected_files,
        "memoryFileCount": len(injected_files),
        "memoryTotalRawChars": sum(f["rawChars"] for f in injected_files),
        "memoryTotalInjectedChars": sum(f["injectedChars"] for f in injected_files),
    }
    return prompt, report
