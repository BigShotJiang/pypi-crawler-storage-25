"""Tool loop — the agentic core.

`run_turn(user_message, ...)` runs one user turn through the tool loop:
sends messages, reads back text or tool_calls, executes tools, feeds results
back, repeats until the assistant returns a final text response (or the
max-turn cap or repeat-loop guard fires).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .client import Provider, parse_tool_calls
from .prompt import build_system_prompt
from .tools import TOOLS_BY_NAME, run_tool, tool_schemas, tool_summary_block

DEFAULT_MAX_TURNS = 10


def _preview(s: str, n: int = 200) -> str:
    return s if len(s) <= n else s[:n] + "..."


def run_turn(
    user_message: str,
    provider: Provider | None = None,
    cwd: Path | None = None,
    max_turns: int = DEFAULT_MAX_TURNS,
    prior_messages: list[dict[str, Any]] | None = None,
    verbose: bool = False,
    tools_filter: list[str] | None = None,
) -> dict[str, Any]:
    """Run one user turn through the tool loop.

    Returns:
        {
          "text": str, "messages": [...], "turns": int, "stopped": reason,
          "trace": [ {type, turn, ...}, ... ],
          "system_prompt_report": {...},
          "usage": {...},
        }

    `stopped` ∈ {"stop", "tool_calls_unparseable", "repeat_loop", "max_turns",
                 "no_tool_calls", "length", ...}
    """
    provider = provider or Provider()
    system_prompt, sp_report = build_system_prompt(
        tools_block=tool_summary_block(tools_filter),
        cwd=cwd,
        with_report=True,
    )
    tools = tool_schemas(tools_filter)
    sp_report["tools"] = {
        "count": len(tools),
        "schemaChars": sum(len(str(t)) for t in tools),
        "entries": [
            {"name": t.get("function", {}).get("name", ""),
             "schemaChars": len(str(t))}
            for t in tools
        ],
    }

    trace: list[dict[str, Any]] = [
        {"type": "system_prompt_built",
         "systemPromptChars": sp_report["systemPrompt"]["chars"],
         "injectedFiles": len(sp_report.get("injectedWorkspaceFiles", [])),
         "toolCount": sp_report["tools"]["count"]}
    ]

    messages: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]
    if prior_messages:
        messages.extend(m for m in prior_messages if m.get("role") != "system")
    messages.append({"role": "user", "content": user_message})

    usage_total = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    usage_peak_prompt = 0
    per_turn_usage: list[dict[str, Any]] = []
    last_call_signature: frozenset[tuple[str, str]] = frozenset()

    for turn in range(max_turns):
        trace.append({"type": "turn_start", "turn": turn})
        resp = provider.chat(messages, tools=tools)
        choice = (resp.get("choices") or [{}])[0]
        msg = choice.get("message") or {}
        finish = choice.get("finish_reason", "")
        all_calls = parse_tool_calls(msg)
        valid_calls = [c for c in all_calls if c.get("_parse_ok", True)]
        failed_calls = [c for c in all_calls if not c.get("_parse_ok", True)]
        for fc in failed_calls:
            trace.append({
                "type": "tool_call_unparseable",
                "turn": turn,
                "name": fc.get("name", ""),
                "raw_args_preview": (fc.get("_raw_args") or "")[:400],
                "reason": fc.get("_parse_reason"),
            })
        tool_calls = valid_calls

        u = resp.get("usage") or {}
        turn_prompt = int(u.get("prompt_tokens") or 0)
        turn_completion = int(u.get("completion_tokens") or 0)
        turn_total = int(u.get("total_tokens") or (turn_prompt + turn_completion))
        usage_total["prompt_tokens"] += turn_prompt
        usage_total["completion_tokens"] += turn_completion
        usage_total["total_tokens"] += turn_total
        if turn_prompt > usage_peak_prompt:
            usage_peak_prompt = turn_prompt
        per_turn_usage.append({
            "turn": turn,
            "prompt_tokens": turn_prompt,
            "completion_tokens": turn_completion,
            "total_tokens": turn_total,
        })
        trace.append({
            "type": "usage",
            "turn": turn,
            "prompt_tokens": turn_prompt,
            "completion_tokens": turn_completion,
            "total_tokens": turn_total,
        })

        if verbose:
            print(f"[turn {turn}] finish={finish} tool_calls={len(tool_calls)} "
                  f"content={msg.get('content', '')[:120]!r}")

        assistant_entry: dict[str, Any] = {"role": "assistant", "content": msg.get("content") or ""}
        if msg.get("tool_calls"):
            assistant_entry["tool_calls"] = msg["tool_calls"]
        messages.append(assistant_entry)

        trace.append({
            "type": "assistant_message",
            "turn": turn,
            "finish_reason": finish,
            "content_preview": _preview(msg.get("content") or "", 400),
            "tool_call_count": len(tool_calls),
        })

        if not tool_calls:
            stop_reason = (
                "tool_calls_unparseable" if failed_calls else (finish or "no_tool_calls")
            )
            trace.append({"type": "turn_end", "turn": turn, "stopped": stop_reason})
            return _final(messages, msg.get("content") or "", turn + 1, stop_reason,
                          trace, sp_report, usage_total, usage_peak_prompt,
                          per_turn_usage, provider.max_context)

        call_signature = frozenset(
            (c["name"], json.dumps(c["arguments"], sort_keys=True, ensure_ascii=False))
            for c in tool_calls
        )
        if call_signature and call_signature == last_call_signature:
            trace.append({"type": "turn_end", "turn": turn, "stopped": "repeat_loop"})
            return _final(messages,
                          "[stopped: repeated identical tool call detected — possible runaway loop]",
                          turn + 1, "repeat_loop",
                          trace, sp_report, usage_total, usage_peak_prompt,
                          per_turn_usage, provider.max_context)
        last_call_signature = call_signature

        for call in tool_calls:
            name = call["name"]
            args = call["arguments"] or {}
            tool = TOOLS_BY_NAME.get(name)
            if tool is None:
                result = f"[error] unknown tool: {name}"
                ok = False
            else:
                result = run_tool(tool, args)
                ok = not result.startswith("[error]")
            if verbose:
                print(f"    tool {name} -> {_preview(result)!r}")
            trace.append({
                "type": "tool_call",
                "turn": turn,
                "id": call["id"],
                "name": name,
                "args": args,
                "ok": ok,
                "result_preview": _preview(result, 400),
                "result_chars": len(result),
            })
            messages.append({
                "role": "tool",
                "tool_call_id": call["id"],
                "name": name,
                "content": result,
            })

        for fc in failed_calls:
            messages.append({
                "role": "tool",
                "tool_call_id": fc.get("id", ""),
                "name": fc.get("name", ""),
                "content": f"[error] tool args unparseable ({fc.get('_parse_reason')}); re-emit a single valid JSON object.",
            })

        trace.append({"type": "turn_end", "turn": turn, "stopped": "continued"})

    trace.append({"type": "max_turns_reached", "turns": max_turns})
    return _final(messages, "[max turns reached]", max_turns, "max_turns",
                  trace, sp_report, usage_total, usage_peak_prompt,
                  per_turn_usage, provider.max_context)


def _final(messages, text, turns, stopped, trace, sp_report,
           usage_total, usage_peak_prompt, per_turn_usage, max_context):
    return {
        "text": text,
        "messages": messages,
        "turns": turns,
        "stopped": stopped,
        "trace": trace,
        "system_prompt_report": sp_report,
        "usage": {
            "total": usage_total,
            "peak_prompt_tokens": usage_peak_prompt,
            "per_turn": per_turn_usage,
            "max_context": max_context,
        },
    }
