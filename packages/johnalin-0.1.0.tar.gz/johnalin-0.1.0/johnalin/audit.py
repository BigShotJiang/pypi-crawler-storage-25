"""Per-call artifact bundle writer.

Every turn writes a forensic bundle under
`<artifacts_root>/YYYYMMDD/iter_<utc>Z/<run_id>/` with four JSON files:

- metadata.json  — run_id, agent_tag, host, timings, status, context-fit verdict
- request.json   — what we sent
- response.json  — what we got back (text + stopped reason)
- trace.json     — every event the engine emitted (turn_start, usage, tool_call, etc.)

Mode B (default) = summary; Mode C (`JOHNALIN_CAPTURE_MODE=C`) also dumps raw
provider-facing JSON under `proxy/captures/` for deep debugging.
"""
from __future__ import annotations

import json
import socket
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import Settings, artifacts_root

SCHEMA_VERSION = "1.0"
ARTIFACTS_VERSION = "1.0"


def new_run_id(prefix: str = "turn") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _bundle_dir(run_id: str, started: datetime) -> Path:
    day = started.strftime("%Y%m%d")
    iter_stamp = started.strftime("iter_%Y%m%dT%H%M%SZ")
    d = artifacts_root() / day / iter_stamp / run_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


CONTEXT_WARN_THRESHOLD = 0.8


def context_fit(usage: dict[str, Any] | None) -> dict[str, Any] | None:
    """Derive context-fit fields from a usage dict.

    Returns None if usage is missing. Otherwise:
      { total_tokens, peak_prompt_tokens, max_context, utilization, fits, risk }
    `fits` = peak <= max_context. `risk` = utilization >= CONTEXT_WARN_THRESHOLD.
    """
    if not usage:
        return None
    max_ctx = int(usage.get("max_context") or 0)
    peak = int(usage.get("peak_prompt_tokens") or 0)
    total = int((usage.get("total") or {}).get("total_tokens") or 0)
    util = (peak / max_ctx) if max_ctx > 0 else 0.0
    return {
        "total_tokens": total,
        "peak_prompt_tokens": peak,
        "max_context": max_ctx,
        "utilization": round(util, 3),
        "fits": bool(max_ctx) and peak <= max_ctx,
        "risk": bool(max_ctx) and util >= CONTEXT_WARN_THRESHOLD,
        "per_turn": usage.get("per_turn") or [],
    }


def write_bundle(
    *,
    run_id: str,
    started: datetime,
    ended: datetime,
    request: dict[str, Any],
    response: dict[str, Any],
    trace_events: list[dict[str, Any]],
    usage: dict[str, Any] | None = None,
) -> Path:
    """Write the per-turn artifact bundle. Returns the bundle directory."""
    s = Settings.from_env()
    d = _bundle_dir(run_id, started)
    duration_ms = int((ended - started).total_seconds() * 1000)
    fit = context_fit(usage)

    metadata = {
        "schema_version": SCHEMA_VERSION,
        "artifacts_version": ARTIFACTS_VERSION,
        "run_id": run_id,
        "agent": s.agent_tag,
        "host": socket.gethostname(),
        "executor": "johnalin",
        "mode": s.capture_mode,
        "timestamp_start": _iso(started),
        "timestamp_end": _iso(ended),
        "duration_ms": duration_ms,
        "status": response.get("status", "ok"),
        "context": fit,
    }
    _write_json(d / "metadata.json", metadata)

    req_doc = {"schema_version": SCHEMA_VERSION, "run_id": run_id, "mode": s.capture_mode, **request}
    _write_json(d / "request.json", req_doc)

    resp_doc = {"schema_version": SCHEMA_VERSION, "run_id": run_id, **response}
    _write_json(d / "response.json", resp_doc)

    _write_json(d / "trace.json", {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "events": trace_events,
    })

    return d


__all__ = [
    "SCHEMA_VERSION", "ARTIFACTS_VERSION",
    "new_run_id", "context_fit", "write_bundle",
]
