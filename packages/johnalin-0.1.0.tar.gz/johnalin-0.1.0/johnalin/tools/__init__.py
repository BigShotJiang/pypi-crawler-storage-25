"""Tool registry — 5 generic tools shipped in v0.1.0.

Tool whitelisting (the `--tools` flag of `johnalin-cli`, or the `tools_filter`
arg of `run_turn()`) is the primary defence against system-prompt bloat. By
default all 5 tools are advertised; whitelisting drops the system-prompt size
for tasks that only need a subset (e.g. read-and-summarise needs `file_read`+`grep`,
not `bash`+`file_write`).
"""
from __future__ import annotations

from .base import Tool, run_tool
from .bash import BASH
from .file_read import FILE_READ
from .file_write import FILE_WRITE
from .glob_tool import GLOB
from .grep_tool import GREP

ALL_TOOLS: list[Tool] = [BASH, FILE_READ, FILE_WRITE, GLOB, GREP]
TOOLS_BY_NAME: dict[str, Tool] = {t.name: t for t in ALL_TOOLS}


def _select(filter_names: list[str] | None) -> list[Tool]:
    if filter_names is None:
        return ALL_TOOLS
    return [TOOLS_BY_NAME[n] for n in filter_names if n in TOOLS_BY_NAME]


def tool_schemas(filter_names: list[str] | None = None) -> list[dict]:
    return [t.to_openai_schema() for t in _select(filter_names)]


def tool_summary_block(filter_names: list[str] | None = None) -> str:
    return "\n".join(f"- `{t.name}`: {t.description}" for t in _select(filter_names))


def unknown_tool_names(filter_names: list[str]) -> list[str]:
    return [n for n in filter_names if n not in TOOLS_BY_NAME]


def register(tool: Tool) -> None:
    """Register a custom tool at runtime. See `examples/custom_tool.py`."""
    if tool.name in TOOLS_BY_NAME:
        raise ValueError(f"tool {tool.name!r} already registered")
    ALL_TOOLS.append(tool)
    TOOLS_BY_NAME[tool.name] = tool


__all__ = [
    "Tool", "run_tool",
    "ALL_TOOLS", "TOOLS_BY_NAME",
    "tool_schemas", "tool_summary_block", "unknown_tool_names",
    "register",
]
