"""grep tool — search file contents via ripgrep if available, else python fallback."""
from __future__ import annotations

import fnmatch
import os
import re
import subprocess
from typing import Any

from .base import Tool

MAX_OUTPUT = 16384


def _rg_available() -> bool:
    try:
        subprocess.run(["rg", "--version"], capture_output=True, timeout=2)
        return True
    except (OSError, subprocess.TimeoutExpired):
        return False


def _execute(args: dict[str, Any]) -> str:
    pattern = args.get("pattern")
    if not pattern:
        return "[grep error] missing 'pattern'"
    path = args.get("path") or "."
    glob_filter = args.get("glob")

    if _rg_available():
        cmd = ["rg", "--line-number", "--color=never", "-e", pattern]
        if glob_filter:
            cmd.extend(["-g", glob_filter])
        cmd.append(path)
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        except subprocess.TimeoutExpired:
            return "[grep timeout]"
        out = proc.stdout or f"[grep] no matches (rg exit {proc.returncode})"
        if len(out) > MAX_OUTPUT:
            out = out[:MAX_OUTPUT] + "\n... [truncated]"
        return out

    # Fallback: pure-python walk
    matches: list[str] = []
    rgx = re.compile(pattern)
    for root, _dirs, files in os.walk(path):
        for f in files:
            if glob_filter and not fnmatch.fnmatch(f, glob_filter):
                continue
            fp = os.path.join(root, f)
            try:
                with open(fp, encoding="utf-8", errors="ignore") as fh:
                    for lineno, line in enumerate(fh, 1):
                        if rgx.search(line):
                            matches.append(f"{fp}:{lineno}:{line.rstrip()}")
                            if len("\n".join(matches)) > MAX_OUTPUT:
                                matches.append("... [truncated]")
                                return "\n".join(matches)
            except OSError:
                continue
    return "\n".join(matches) if matches else f"[grep] no matches for {pattern}"


GREP = Tool(
    name="grep",
    description="Search file contents for a regex. Uses ripgrep when available. Returns path:line:text entries.",
    parameters={
        "type": "object",
        "properties": {
            "pattern": {"type": "string", "description": "Regex to search for."},
            "path": {"type": "string", "description": "Root dir to search (default cwd)."},
            "glob": {"type": "string", "description": "Filename glob filter, e.g. *.py"},
        },
        "required": ["pattern"],
    },
    execute=_execute,
)
