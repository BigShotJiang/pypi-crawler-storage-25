"""Tool interface — name, description, parameters (JSON schema), execute(args)."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]
    execute: Callable[[dict[str, Any]], str]

    def to_openai_schema(self) -> dict[str, Any]:
        """OpenAI-format `tools` entry for /v1/chat/completions."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


def run_tool(tool: Tool, arguments: dict[str, Any]) -> str:
    """Execute a tool; always return a string. Errors stringified."""
    try:
        out = tool.execute(arguments)
        if not isinstance(out, str):
            out = str(out)
        return out
    except Exception as exc:
        return f"[tool {tool.name} error] {type(exc).__name__}: {exc}"
