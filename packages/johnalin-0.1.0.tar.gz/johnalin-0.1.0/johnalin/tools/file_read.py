"""file_read tool — read a UTF-8 text file, line-numbered, with offset/limit."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import Tool

MAX_BYTES = 64 * 1024


def _execute(args: dict[str, Any]) -> str:
    path = args.get("path")
    if not path:
        return "[file_read error] missing 'path'"
    p = Path(path)
    if not p.is_file():
        return f"[file_read error] not a file: {path}"
    try:
        data = p.read_bytes()
    except OSError as exc:
        return f"[file_read error] {exc}"
    truncated_note = ""
    if len(data) > MAX_BYTES:
        data = data[:MAX_BYTES]
        truncated_note = f"\n... [truncated at {MAX_BYTES} bytes]"
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        text = data.decode("utf-8", errors="replace")
    lines = text.splitlines()
    offset = int(args.get("offset", 0))
    limit = int(args.get("limit", 0)) or len(lines)
    selected = lines[offset:offset + limit]
    numbered = [f"{i + offset + 1:>6}\t{ln}" for i, ln in enumerate(selected)]
    return "\n".join(numbered) + truncated_note


FILE_READ = Tool(
    name="file_read",
    description="Read a UTF-8 text file. Returns line-numbered content. Supports offset/limit for large files.",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute or relative file path."},
            "offset": {"type": "integer", "description": "Line offset (0-based)."},
            "limit": {"type": "integer", "description": "Max lines to return."},
        },
        "required": ["path"],
    },
    execute=_execute,
)
