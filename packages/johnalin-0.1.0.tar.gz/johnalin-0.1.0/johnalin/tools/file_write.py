"""file_write tool — overwrite a UTF-8 text file (parents auto-created)."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import Tool


def _execute(args: dict[str, Any]) -> str:
    path = args.get("path")
    content = args.get("content", "")
    if not path:
        return "[file_write error] missing 'path'"
    p = Path(path)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    except OSError as exc:
        return f"[file_write error] {exc}"
    return f"[ok] wrote {len(content)} chars to {p}"


FILE_WRITE = Tool(
    name="file_write",
    description="Write (overwrite) a UTF-8 text file. Creates parent directories if needed.",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Target file path."},
            "content": {"type": "string", "description": "Text content to write."},
        },
        "required": ["path", "content"],
    },
    execute=_execute,
)
