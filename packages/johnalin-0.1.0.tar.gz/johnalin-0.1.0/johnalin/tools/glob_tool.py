"""glob tool — find files by glob pattern."""
from __future__ import annotations

import glob as _glob
import os
from typing import Any

from .base import Tool

MAX_RESULTS = 200


def _execute(args: dict[str, Any]) -> str:
    pattern = args.get("pattern")
    if not pattern:
        return "[glob error] missing 'pattern'"
    root = args.get("root") or "."
    if not os.path.isdir(root):
        return f"[glob error] root is not a directory: {root}"
    matches = _glob.glob(os.path.join(root, pattern), recursive=True)
    matches = sorted(m for m in matches if os.path.isfile(m))
    if not matches:
        return f"[glob] 0 matches for {pattern} under {root}"
    truncated = ""
    if len(matches) > MAX_RESULTS:
        truncated = f"\n... [{len(matches) - MAX_RESULTS} more, truncated]"
        matches = matches[:MAX_RESULTS]
    return "\n".join(matches) + truncated


GLOB = Tool(
    name="glob",
    description="Find files matching a glob pattern. Supports ** for recursive. Returns up to 200 paths.",
    parameters={
        "type": "object",
        "properties": {
            "pattern": {"type": "string", "description": "Glob pattern e.g. **/*.py"},
            "root": {"type": "string", "description": "Directory to search (default current dir)."},
        },
        "required": ["pattern"],
    },
    execute=_execute,
)
