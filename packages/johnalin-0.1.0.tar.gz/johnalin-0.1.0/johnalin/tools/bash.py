"""bash tool — run a shell command, return stdout+stderr capped."""
from __future__ import annotations

import subprocess
from typing import Any

from .base import Tool

MAX_OUTPUT = 16384  # 16 KB
DEFAULT_TIMEOUT = 30


def _execute(args: dict[str, Any]) -> str:
    cmd = args.get("command") or ""
    if not cmd:
        return "[bash error] missing 'command' argument"
    timeout = int(args.get("timeout", DEFAULT_TIMEOUT))
    try:
        proc = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return f"[bash timeout after {timeout}s] command: {cmd}"
    out = proc.stdout + (f"\n[stderr]\n{proc.stderr}" if proc.stderr else "")
    if len(out) > MAX_OUTPUT:
        out = out[:MAX_OUTPUT] + f"\n... [truncated, {len(out) - MAX_OUTPUT} more bytes]"
    return f"[exit {proc.returncode}]\n{out}"


BASH = Tool(
    name="bash",
    description="Run a shell command in bash. Returns combined stdout+stderr with exit code. Use for quick inspection, git, ls, etc. Do not use for long-running or interactive commands.",
    parameters={
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "Shell command to run."},
            "timeout": {"type": "integer", "description": "Seconds (default 30)."},
        },
        "required": ["command"],
    },
    execute=_execute,
)
