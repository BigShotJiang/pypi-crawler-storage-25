"""johnalin REPL — interactive multi-turn agent with SQLite history + debug panels.

Each prompt runs against a FRESH context (no cross-prompt history accumulated
in memory) — the SQLite log is the durable record. Shell scrollback is your
visual history. Multi-line input: paste freely, press Esc-Enter (or Alt-Enter)
to submit.
"""
from __future__ import annotations

import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

import httpx
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import ANSI
from prompt_toolkit.history import FileHistory
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from .audit import write_bundle
from .client import Provider, ProviderError
from .config import Settings, db_path, home_dir, prompt_history_path
from .engine import run_turn
from .history import ensure_db, log_turn

console = Console()


SLASH_HELP = """[bold]Slash commands[/bold]
  /tools    enable tool use (bash / file_read / file_write / glob / grep)
  /notools  disable tools (chat-only)
  /stats    show session totals
  /model    show current model + how to swap
  /help     this screen
  /exit     quit (or Ctrl-D)

[dim]every prompt runs against a fresh context (no chat history). terminal scrollback is your history.[/dim]"""


def _fmt_tokens(n: int) -> str:
    if n < 1000:
        return str(n)
    return f"{n/1000:.1f}k"


def _print_input_panel(prompt: str) -> None:
    body = prompt if len(prompt) <= 2000 else prompt[:2000] + f"\n…[+{len(prompt)-2000} chars truncated]"
    console.print(Panel(body, title="[bold cyan]INPUT PROMPT[/bold cyan]",
                        border_style="cyan", padding=(0, 1)))


def _print_summary(stats: dict, prompt: str) -> None:
    util_pct = int(round(stats["util"] * 100))
    if not stats["fits"]:
        ctx_color = "red"
    elif stats["risk"]:
        ctx_color = "yellow"
    else:
        ctx_color = "green"
    duration_s = stats["duration_ms"] / 1000.0

    t = Table(show_header=False, show_edge=False, pad_edge=False, box=None)
    t.add_column(style="bold dim", no_wrap=True)
    t.add_column()
    t.add_row("model", stats["model"])
    t.add_row("run_id", stats["run_id"])
    t.add_row("turns", f"{stats['turns']}  (stopped={stats['stopped']})")
    t.add_row("input chars", str(len(prompt)))
    t.add_row("output chars", str(len(stats['text'] or '')))
    t.add_row("tokens", f"in={_fmt_tokens(stats['in_tokens'])} "
                       f"out={_fmt_tokens(stats['out_tokens'])} "
                       f"total={_fmt_tokens(stats['total_tokens'])}")
    t.add_row("context", f"[{ctx_color}]{util_pct}% used  fits={stats['fits']}  "
                        f"risk={stats['risk']}[/{ctx_color}]")
    t.add_row("duration", f"{duration_s:.2f}s")
    t.add_row("artifact_dir", stats["artifact_dir"] or "(none)")
    t.add_row("db", str(db_path()))
    console.print(Panel(t, title="[bold magenta]SUMMARY[/bold magenta]",
                        border_style="magenta", padding=(0, 1)))


def _render_turn(prompt: str, stats: dict) -> None:
    console.rule("[bold]── new turn ──[/bold]")
    _print_input_panel(prompt)

    if stats["text"]:
        console.print(Panel(Markdown(stats["text"]),
                            title="[bold green]ASSISTANT REPLY[/bold green]",
                            border_style="green", padding=(0, 1)))
    else:
        console.print(f"[dim](empty reply — stopped={stats['stopped']})[/dim]")

    _print_summary(stats, prompt)


def _stats_from_result(result: dict, model: str, duration_ms: int, run_id: str,
                       artifact_dir: str) -> dict:
    usage = result.get("usage") or {}
    max_ctx = int(usage.get("max_context") or 0)
    peak = int(usage.get("peak_prompt_tokens") or 0)
    total = int((usage.get("total") or {}).get("total_tokens") or 0)
    out_tokens = sum(int(t.get("completion_tokens") or 0) for t in usage.get("per_turn") or [])
    util = (peak / max_ctx) if max_ctx > 0 else 0.0
    return {
        "model": model,
        "turns": int(result.get("turns") or 0),
        "stopped": result.get("stopped") or "?",
        "in_tokens": peak,
        "out_tokens": out_tokens,
        "total_tokens": total,
        "util": util,
        "fits": bool(max_ctx) and peak <= max_ctx,
        "risk": bool(max_ctx) and util >= 0.8,
        "duration_ms": duration_ms,
        "artifact_dir": artifact_dir,
        "run_id": run_id,
        "text": result.get("text") or "",
        "trace": result.get("trace") or [],
    }


def _banner(model: str, num_ctx: int, base_url: str, tools_on: bool) -> None:
    line = f"johnalin · {model} · ctx {num_ctx} · tools {'on' if tools_on else 'off'} · fresh-ctx per prompt"
    console.print(Panel.fit(f"[bold green]{line}[/bold green]", border_style="cyan"))
    console.print(f"[dim]upstream: {base_url}   home: {home_dir()}   db: {db_path()}[/dim]")
    console.print(
        "[dim]/help · Ctrl-D to exit · multi-line: paste freely, [bold]Esc-Enter[/bold] (or Alt-Enter) submits[/dim]\n"
    )


def main() -> int:
    s = Settings.from_env()
    ensure_db()
    home_dir().mkdir(parents=True, exist_ok=True)
    provider = Provider()

    h = provider.health()
    if not h.get("ok"):
        console.print(
            f"[red]could not reach upstream LLM at {provider.base_url}[/red]\n"
            f"[dim]{h.get('error')}[/dim]\n"
            f"[yellow]start ollama (e.g. `ollama serve` in another terminal) and `ollama pull {provider.model}`[/yellow]"
        )
        return 4

    tools_on = True
    session_id = str(uuid.uuid4())
    session_turns = 0
    session_in = 0
    session_out = 0
    session_ms = 0

    _banner(provider.model, provider.max_context, provider.base_url, tools_on)

    pt_session: PromptSession[str] = PromptSession(
        history=FileHistory(str(prompt_history_path())),
        multiline=True,
    )

    while True:
        try:
            user = pt_session.prompt(ANSI("\x1b[1;36m> \x1b[0m")).strip()
        except (EOFError, KeyboardInterrupt):
            console.print()
            break

        if not user:
            continue

        if user.startswith("/"):
            cmd = user.split()[0].lower()
            if cmd in ("/exit", "/quit"):
                break
            if cmd == "/notools":
                tools_on = False
                console.print("[dim]tools off — chat-only[/dim]")
                continue
            if cmd == "/tools":
                tools_on = True
                console.print("[dim]tools on — bash / file_read / file_write / glob / grep[/dim]")
                continue
            if cmd == "/stats":
                console.print(
                    f"[bold]session[/bold]  turns={session_turns}  "
                    f"in={_fmt_tokens(session_in)}  out={_fmt_tokens(session_out)}  "
                    f"wall={session_ms/1000:.1f}s  id={session_id[:8]}…"
                )
                continue
            if cmd == "/model":
                console.print(
                    f"[dim]current: {provider.model}\n"
                    f"to swap: exit, then\n"
                    f"  OLLAMA_MODEL=qwen2.5:14b johnalin[/dim]"
                )
                continue
            if cmd == "/help":
                console.print(SLASH_HELP)
                continue
            console.print(f"[yellow]unknown command {cmd}[/yellow] — /help for list")
            continue

        started = datetime.now(timezone.utc)
        try:
            with console.status("[cyan]thinking…[/cyan]", spinner="dots"):
                result = run_turn(
                    user_message=user,
                    provider=provider,
                    cwd=Path.cwd(),
                    max_turns=s.max_turns if tools_on else 1,
                    tools_filter=None if tools_on else [],
                )
        except ProviderError as e:
            console.print(Panel(
                f"[red]upstream {e.status}[/red] from {e.url}\n{json.dumps(e.body, indent=2, ensure_ascii=False)[:1500]}",
                title="[bold red]PROVIDER ERROR[/bold red]", border_style="red",
            ))
            continue
        except httpx.HTTPError as e:
            console.print(f"[red]http error: {e}[/red]")
            continue

        ended = datetime.now(timezone.utc)
        duration_ms = int((ended - started).total_seconds() * 1000)
        run_id_local = f"repl_{uuid.uuid4().hex[:12]}"

        artifact_dir = ""
        try:
            d = write_bundle(
                run_id=run_id_local,
                started=started, ended=ended,
                request={"message": user, "cwd": str(Path.cwd()),
                         "max_turns": s.max_turns if tools_on else 1,
                         "tools_enabled": tools_on,
                         "model": provider.model},
                response={"text": result.get("text") or "",
                          "turns": result.get("turns"),
                          "stopped": result.get("stopped"),
                          "status": "ok"},
                trace_events=result.get("trace") or [],
                usage=result.get("usage") or {},
            )
            artifact_dir = str(d)
        except OSError:
            pass

        stats = _stats_from_result(result, provider.model, duration_ms, run_id_local, artifact_dir)
        _render_turn(user, stats)

        session_turns += 1
        session_in += stats["in_tokens"]
        session_out += stats["out_tokens"]
        session_ms += duration_ms

        try:
            log_turn({
                "run_id": run_id_local,
                "ts": started.isoformat(),
                "session_id": session_id,
                "model": provider.model,
                "tools_enabled": int(tools_on),
                "input_text": user,
                "output_text": stats["text"],
                "in_tokens": stats["in_tokens"],
                "out_tokens": stats["out_tokens"],
                "total_tokens": stats["total_tokens"],
                "turns": stats["turns"],
                "stopped": stats["stopped"],
                "duration_ms": duration_ms,
                "context_util": stats["util"],
                "fits": int(stats["fits"]),
                "risk": int(stats["risk"]),
                "artifact_dir": artifact_dir,
                "request_json": json.dumps({"message": user, "tools_on": tools_on}, ensure_ascii=False),
                "response_json": json.dumps({"text": stats["text"], "stopped": stats["stopped"]}, ensure_ascii=False),
                "trace_json": json.dumps(result.get("trace") or [], ensure_ascii=False),
            })
        except Exception:
            pass

    console.print(
        Panel.fit(
            f"session {session_id[:8]}… · {session_turns} turns · "
            f"in {_fmt_tokens(session_in)} · out {_fmt_tokens(session_out)} · "
            f"wall {session_ms/1000:.1f}s · db {db_path()}",
            border_style="dim",
        )
    )
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
