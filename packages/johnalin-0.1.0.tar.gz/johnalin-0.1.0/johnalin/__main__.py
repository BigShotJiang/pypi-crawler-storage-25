"""Allow `python -m johnalin` to launch the REPL."""
from .repl import main

if __name__ == "__main__":
    raise SystemExit(main())
