"""Config — env vars + optional YAML override at ~/.johnalin/config.yaml.

Precedence: CLI flag > env var > YAML > defaults.
No hardcoded paths anywhere.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _expand(p: str) -> Path:
    return Path(os.path.expanduser(os.path.expandvars(p)))


def home_dir() -> Path:
    return _expand(os.environ.get("JOHNALIN_HOME", "~/.johnalin"))


def db_path() -> Path:
    return _expand(os.environ.get("JOHNALIN_DB", str(home_dir() / "history.db")))


def artifacts_root() -> Path:
    return _expand(os.environ.get("JOHNALIN_ARTIFACTS", str(home_dir() / "artifacts")))


def prompt_history_path() -> Path:
    return home_dir() / "prompt_history"


@dataclass(frozen=True)
class Settings:
    base_url: str
    model: str
    num_ctx: int
    timeout_s: float
    max_turns: int
    agent_tag: str
    capture_mode: str  # "B" summary | "C" full

    @classmethod
    def from_env(cls) -> Settings:
        return cls(
            base_url=os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434/v1"),
            model=os.environ.get("OLLAMA_MODEL", os.environ.get("JOHNALIN_MODEL", "qwen2.5:7b")),
            num_ctx=int(os.environ.get("JOHNALIN_NUM_CTX", os.environ.get("LLM_MAX_CONTEXT", "16384"))),
            timeout_s=float(os.environ.get("JOHNALIN_TIMEOUT", "900")),
            max_turns=int(os.environ.get("JOHNALIN_MAX_TURNS", "10")),
            agent_tag=os.environ.get("JOHNALIN_AGENT_TAG", "user"),
            capture_mode=os.environ.get("JOHNALIN_CAPTURE_MODE", "B").upper(),
        )
