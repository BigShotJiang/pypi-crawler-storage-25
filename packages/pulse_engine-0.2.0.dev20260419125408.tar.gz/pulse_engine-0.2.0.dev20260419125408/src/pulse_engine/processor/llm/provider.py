from __future__ import annotations

from typing import Any

from pulse_engine.config import get_settings

_llm_instance: Any = None


def get_llm(
    provider: str | None = None,
    model: str | None = None,
    api_key: str | None = None,
    temperature: float | None = None,
) -> Any:
    """Return a LangChain chat model, using Settings as defaults.

    Constructor params override env-var defaults.  The instance is cached
    as a module singleton on first call.
    """
    global _llm_instance
    if _llm_instance is not None:
        return _llm_instance

    settings = get_settings()
    provider = provider or settings.pulse_llm_provider
    model = model or settings.pulse_llm_model
    api_key = api_key or settings.pulse_llm_api_key
    if temperature is None:
        temperature = settings.pulse_llm_temperature

    if provider == "openai":
        from langchain_openai import ChatOpenAI

        _llm_instance = ChatOpenAI(
            model=model,
            api_key=api_key,
            temperature=temperature,
        )
    elif provider == "anthropic":
        from langchain_anthropic import ChatAnthropic

        _llm_instance = ChatAnthropic(
            model=model,
            api_key=api_key,
            temperature=temperature,
        )
    else:
        msg = f"Unsupported LLM provider: {provider!r}. Use 'openai' or 'anthropic'."
        raise ValueError(msg)

    return _llm_instance


def reset_llm() -> None:
    """Reset the cached LLM instance (useful for testing)."""
    global _llm_instance
    _llm_instance = None
