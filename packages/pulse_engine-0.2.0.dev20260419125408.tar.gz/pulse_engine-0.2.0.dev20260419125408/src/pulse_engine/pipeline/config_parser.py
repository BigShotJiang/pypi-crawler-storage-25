from __future__ import annotations

import yaml  # type: ignore[import-untyped]
from pydantic import ValidationError

from pulse_engine.pipeline.schemas import PipelineConfig, StepConfig


class PipelineConfigError(Exception):
    """Raised when pipeline config is invalid."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__(f"Pipeline config validation failed: {'; '.join(errors)}")


def parse_pipeline_config(yaml_content: str) -> PipelineConfig:
    """Parse YAML string into validated PipelineConfig."""
    try:
        raw = yaml.safe_load(yaml_content)
    except yaml.YAMLError as e:
        raise PipelineConfigError([f"YAML parse error: {e}"]) from e

    if not isinstance(raw, dict):
        raise PipelineConfigError(["YAML content must be a mapping"])

    try:
        config = PipelineConfig(**raw)
    except ValidationError as e:
        errors = [f"{err['loc']}: {err['msg']}" for err in e.errors()]
        raise PipelineConfigError(errors) from e

    validate_dag(config)
    return config


def validate_dag(config: PipelineConfig) -> None:
    """Validate DAG structure: references, cycles, fan-out rules, input modes."""
    errors: list[str] = []
    module_names = {m.name for m in config.modules}
    step_names: set[str] = set()
    step_map: dict[str, StepConfig] = {}

    # Check for duplicate steps and unknown modules
    for s in config.dag:
        if s.step in step_names:
            errors.append(f"Duplicate step: '{s.step}'")
        step_names.add(s.step)
        step_map[s.step] = s

        if s.module not in module_names:
            errors.append(f"Unknown module: '{s.module}' in step '{s.step}'")

    # Check dependency references and fan-out rules
    for s in config.dag:
        dep_steps: set[str] = set()
        has_fanout_dep = False

        if s.depends_on:
            for dep in s.depends_on:
                if dep.step not in step_names:
                    errors.append(
                        f"Unknown step: '{dep.step}' in depends_on of step '{s.step}'"
                    )
                else:
                    dep_steps.add(dep.step)
                    dep_step = step_map.get(dep.step)
                    if dep_step and dep_step.fan_out is not None:
                        has_fanout_dep = True

                    # wait:any + input:collect is invalid
                    if dep.wait.value == "any" and s.input.value == "collect":
                        errors.append(
                            "Cannot collect with wait:any "
                            "— results arrive incrementally "
                            f"(step '{s.step}', dependency '{dep.step}')"
                        )

        # passthrough after fan-out is invalid
        if has_fanout_dep and s.input.value == "passthrough":
            errors.append(
                f"Cannot use passthrough — dependency of step '{s.step}' uses fan_out. "
                f"Use collect or merge"
            )

        # fan_out.from=output must reference a dependency
        if s.fan_out and s.fan_out.from_ == "output":
            if s.fan_out.of not in dep_steps:
                errors.append(
                    f"Fan-out source '{s.fan_out.of}' "
                    f"is not a dependency of step '{s.step}'"
                )

    # Cycle detection via topological sort (Kahn's algorithm)
    in_degree: dict[str, int] = {s.step: 0 for s in config.dag}
    adjacency: dict[str, list[str]] = {s.step: [] for s in config.dag}

    for s in config.dag:
        if s.depends_on:
            for dep in s.depends_on:
                if dep.step in step_names:
                    adjacency[dep.step].append(s.step)
                    in_degree[s.step] += 1

    queue = [name for name, deg in in_degree.items() if deg == 0]
    visited_count = 0

    while queue:
        node = queue.pop(0)
        visited_count += 1
        for neighbor in adjacency[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if visited_count != len(config.dag):
        errors.append("Circular dependency detected in DAG")

    if errors:
        raise PipelineConfigError(errors)
