from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class ComputeBackend(str, Enum):
    ecs = "ecs"
    lambda_ = "lambda"
    kubernetes = "kubernetes"


class WaitMode(str, Enum):
    all = "all"
    any = "any"


class InputMode(str, Enum):
    passthrough = "passthrough"
    collect = "collect"
    merge = "merge"


class ModuleConfig(BaseModel):
    name: str
    compute: ComputeBackend
    retries: int = Field(default=0, ge=0)
    retry_delay: int = Field(default=0, ge=0, description="Seconds between retries")
    timeout: int = Field(default=3600, gt=0, description="Seconds before kill")
    max_concurrency: int | None = Field(
        default=None, gt=0, description="Max parallel fan-out tasks (None = unlimited)"
    )


class FanOutConfig(BaseModel):
    from_: Literal["input", "output"] = Field(alias="from")
    of: str | None = None  # required when from="output"
    each_receives: str

    model_config = {"populate_by_name": True}

    @model_validator(mode="after")
    def of_required_for_output(self) -> FanOutConfig:
        if self.from_ == "output" and self.of is None:
            msg = "'of' is required when fan_out.from is 'output'"
            raise ValueError(msg)
        return self


class DependencyConfig(BaseModel):
    step: str
    wait: WaitMode = WaitMode.all


class StepConfig(BaseModel):
    step: str
    module: str
    fan_out: FanOutConfig | None = None
    depends_on: list[DependencyConfig] | None = None
    input: InputMode = InputMode.passthrough


class PipelineConfig(BaseModel):
    name: str
    version: str = "1.0"
    modules: list[ModuleConfig]
    dag: list[StepConfig]

    @field_validator("version")
    @classmethod
    def validate_version(cls, v: str) -> str:
        supported = {"1.0"}
        if v not in supported:
            msg = f"Unsupported pipeline config version: {v}. Supported: {supported}"
            raise ValueError(msg)
        return v


# --- API Request/Response Schemas ---


class ModuleImageDef(BaseModel):
    image: str


class TriggerPayload(BaseModel):
    product: str
    orchestrator: Literal["prefect", "airflow"]
    input: list[dict[str, Any]] = Field(default_factory=list)
    config: dict[str, Any] = Field(default_factory=dict)


class PipelineRunStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"
    submission_failed = "submission_failed"


class StepStatus(BaseModel):
    step: str
    module: str
    status: str
    fan_out_count: int | None = None
    completed_count: int | None = None
    failed_count: int | None = None
    started_at: datetime | None = None


class PipelineStatusResponse(BaseModel):
    run_id: str
    product: str
    orchestrator: str
    status: PipelineRunStatus
    started_at: datetime | None = None
    steps: list[StepStatus] = Field(default_factory=list)


class TriggerResponse(BaseModel):
    run_id: str


class RegisterModulesRequest(BaseModel):
    product: str
    modules: dict[str, ModuleImageDef]


class RegisterModulesResponse(BaseModel):
    product: str
    modules: dict[str, dict[str, str]]


class PipelineRunListResponse(BaseModel):
    items: list[PipelineStatusResponse]
    total: int
    limit: int
    offset: int
