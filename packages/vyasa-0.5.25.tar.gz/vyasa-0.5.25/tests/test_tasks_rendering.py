from fasthtml.common import to_xml

from vyasa.markdown_rendering import from_md


def test_tasks_block_renders_widget_payload_and_summary():
    md = """```tasks
title Hybrid Task Rendering
group foundation Foundation
  item t1 Define graph payload
```"""

    html = to_xml(from_md(md))

    assert 'class="tasks-container' in html
    assert 'data-tasks-widget="true"' in html
    assert '"graph_id": "hybrid-task-rendering-' in html
    assert '"label": "Foundation"' in html
    assert "1 groups, 1 items, 0 edges" in html


def test_tasks_block_invalid_body_falls_back_to_empty_payload():
    md = """```tasks
id: broken
groups: [oops
```"""

    html = to_xml(from_md(md))

    assert 'class="tasks-container' in html
    assert '"groups": []' in html
    assert '"tasks": []' in html


def test_tasks_block_reads_frontmatter_options():
    md = """```tasks
---
title: Gateway Policies
default_open_depth: 2
width: 70vw
height: 60vh
---
group foundation Foundation
```"""

    html = to_xml(from_md(md))

    assert 'data-tasks-title="Gateway Policies"' in html
    assert 'data-tasks-default-open-depth="2"' in html
    assert 'style="width: 70vw; min-height: 85vh;' in html
    assert 'height:60vh;min-height:420px' in html
