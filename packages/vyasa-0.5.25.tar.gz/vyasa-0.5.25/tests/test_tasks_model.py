from vyasa.tasks_model import parse_tasks_text


DEMO_TASKS = """```tasks
id hybrid-task-demo
title Hybrid Task Rendering
group foundation Foundation
  group model Model
    item t1 Define graph payload
    item t2 Validate parser
    item t3 Emit collapsed graph
  group api API
    item t4 Add save route
    item t5 Persist block edits
group ui UI
  group canvas Canvas
    item t6 Render cards
    item t7 Render edges
  group interactions Interactions
    item t8 Expand groups
      depends t7
    item t9 Drag cards
    item t10 Save edits
      depends t5
```"""


def test_grouped_tasks_demo_parses_into_stable_model():
    model = parse_tasks_text(DEMO_TASKS)

    assert model["graph_id"] == "hybrid-task-demo"
    assert model["title"] == "Hybrid Task Rendering"
    assert model["group_tree"][None] == ["foundation", "ui"]
    assert model["group_tree"]["foundation"] == ["model", "api"]
    assert model["group_tree"]["ui"] == ["canvas", "interactions"]
    assert model["task_children"]["model"] == ["t1", "t2", "t3"]
    assert model["task_children"]["api"] == ["t4", "t5"]
    assert model["task_children"]["canvas"] == ["t6", "t7"]
    assert model["task_children"]["interactions"] == ["t8", "t9", "t10"]
    assert {"source": "t7", "target": "t8"} in model["dependency_edges"]
    assert {"source": "t5", "target": "t10"} in model["dependency_edges"]
    assert model["document_order"][:3] == ["foundation", "model", "api"]
    assert model["document_order"][-3:] == ["t8", "t9", "t10"]


def test_tasks_parser_reads_real_tasks_fence():
    model = parse_tasks_text(DEMO_TASKS)

    assert model["groups"][0]["id"] == "foundation"
    assert model["tasks"][0]["id"] == "t1"


def test_tasks_parser_generates_graph_id_when_missing():
    model = parse_tasks_text("""```tasks
title Demo Graph
group foundation Foundation
```""")

    assert model["graph_id"].startswith("demo-graph-")
