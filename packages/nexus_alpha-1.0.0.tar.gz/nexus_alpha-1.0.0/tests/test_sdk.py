"""
NEXUS Alpha SDK — unit tests (no live API needed; uses mocked responses).
Run: pytest tests/ -v
"""

import json
import pytest
from datetime import date
from unittest.mock import patch, MagicMock

import sys
sys.path.insert(0, "..")

from nexus_alpha import NexusAlpha
from nexus_alpha.exceptions import AuthError, RateLimitError, TierError, APIError
from nexus_alpha.models import Signal, SignalCollection


# ── Fixtures ────────────────────────────────────────────────────────────────

SAMPLE_SIGNAL = {
    "ticker": "NVDA",
    "signal_date": "2024-11-15",
    "signal": "OVERWEIGHT",
    "confidence": 0.712,
    "rationale": "GPU demand accelerating; data center revenue beat by 18%",
    "freshness_days": 5,
    "freshness_status": "LIVE",
    "disclaimer": "Signals are informational only.",
}

SAMPLE_TOP_RESPONSE = [SAMPLE_SIGNAL, {**SAMPLE_SIGNAL, "ticker": "MSFT", "signal": "BUY", "confidence": 0.683}]

SAMPLE_HISTORY_RESPONSE = {
    "count": 2,
    "limit": 500,
    "filters": {"ticker": None, "signal": None},
    "signals": SAMPLE_TOP_RESPONSE,
    "disclaimer": "Signals are informational only.",
}

SAMPLE_USAGE = {
    "tier": 1,
    "client_name": "Test Client",
    "total_calls": 42,
    "requests_last_hour": 5,
    "requests_today": 12,
    "requests_7d": 80,
    "requests_30d": 200,
    "first_call": "2024-11-01T10:00:00Z",
    "last_call": "2024-11-15T14:22:00Z",
}

SAMPLE_PERF = {
    "methodology": {"model": "FinBERT", "backtest_period": "2022-2025"},
    "by_hold_period": {
        "60d": {
            "hold_days": 60, "n_signals": 34, "win_rate": 0.706,
            "avg_return_pct": 4.789, "avg_excess_vs_spy": 2.453,
            "sharpe_annualized": 1.201, "max_drawdown_pct": -15.2,
            "by_confidence_bucket": {"0.65-0.70": {"count": 10, "mean": 4.53, "win_rate": 0.9}},
            "by_signal": {"OVERWEIGHT": {"count": 30, "mean": 0.83, "win_rate": 0.633}},
        }
    },
    "equity_curve": {
        "quarters": ["2022 Q1", "2022 Q2"],
        "quarterly_return_pct": [3.8, -6.1],
        "quarterly_spy_pct": [-1.5, -7.2],
        "cumulative_port": [103.8, 97.4],
        "cumulative_spy": [98.5, 91.4],
        "total_return_pct": 9.5, "spy_total_return_pct": 26.2,
        "max_drawdown_pct": -16.2, "n_signals_evaluated": 120,
        "generated_at": "2024-11-15",
    },
    "live_signal_distribution": [],
    "top_current_signals": [],
    "disclaimer": "Signals are informational only.",
}


def make_mock_response(data, status=200):
    m = MagicMock()
    m.status_code = status
    m.json.return_value = data
    m.content = json.dumps(data).encode()
    return m


# ── Client construction ──────────────────────────────────────────────────────

def test_client_requires_api_key():
    with patch.dict("os.environ", {}, clear=True):
        # Clear env var if set
        import os
        os.environ.pop("NEXUS_ALPHA_API_KEY", None)
        with pytest.raises(AuthError):
            NexusAlpha()


def test_client_accepts_key_arg():
    client = NexusAlpha("test-key-123")
    assert client.api_key == "test-key-123"


def test_client_reads_env_var():
    with patch.dict("os.environ", {"NEXUS_ALPHA_API_KEY": "env-key"}):
        client = NexusAlpha()
        assert client.api_key == "env-key"


def test_client_repr():
    client = NexusAlpha("abcdefgh1234")
    assert "abcdefgh" in repr(client)
    assert "..." in repr(client)


# ── Signals API ─────────────────────────────────────────────────────────────

def test_signals_top():
    client = NexusAlpha("test-key")
    with patch.object(client._session, "get", return_value=make_mock_response(SAMPLE_TOP_RESPONSE)):
        result = client.signals.top(limit=2)
    assert isinstance(result, SignalCollection)
    assert len(result) == 2
    assert result.signals[0].ticker == "NVDA"
    assert result.signals[0].confidence == 0.712
    assert result.signals[0].signal_date == date(2024, 11, 15)


def test_signals_search_with_ticker():
    client = NexusAlpha("test-key")
    mock = make_mock_response([SAMPLE_SIGNAL])
    with patch.object(client._session, "get", return_value=mock) as m:
        result = client.signals.search(ticker="nvda", min_confidence=0.65)
    called_params = m.call_args[1]["params"]
    assert called_params["ticker"] == "NVDA"  # uppercased
    assert called_params["min_confidence"] == 0.65


def test_signals_history():
    client = NexusAlpha("test-key")
    with patch.object(client._session, "get", return_value=make_mock_response(SAMPLE_HISTORY_RESPONSE)):
        result = client.signals.history(date_from="2024-01-01")
    assert isinstance(result, SignalCollection)
    assert result.count == 2


def test_signal_collection_filter():
    sigs = [Signal.from_dict(SAMPLE_SIGNAL), Signal.from_dict({**SAMPLE_SIGNAL, "signal": "BUY"})]
    col = SignalCollection(signals=sigs)
    overweight = col.filter(signal="OVERWEIGHT")
    assert len(overweight) == 1
    assert overweight.signals[0].signal == "OVERWEIGHT"


def test_signal_collection_best():
    s1 = Signal.from_dict(SAMPLE_SIGNAL)
    s2 = Signal.from_dict({**SAMPLE_SIGNAL, "ticker": "MSFT", "confidence": 0.65})
    col = SignalCollection(signals=[s1, s2])
    best = col.best(1)
    assert best[0].ticker == "NVDA"  # higher confidence


# ── Analytics API ─────────────────────────────────────────────────────────────

def test_analytics_performance():
    client = NexusAlpha("test-key")
    with patch.object(client._session, "get", return_value=make_mock_response(SAMPLE_PERF)):
        perf = client.analytics.performance()
    assert perf.best_hold_period.hold_days == 60
    assert perf.best_hold_period.sharpe_annualized == 1.201
    assert perf.equity_curve is not None
    assert len(perf.equity_curve.quarters) == 2


def test_equity_curve_to_dataframe():
    pytest.importorskip("pandas")
    client = NexusAlpha("test-key")
    with patch.object(client._session, "get", return_value=make_mock_response(SAMPLE_PERF)):
        perf = client.analytics.performance()
    df = perf.equity_curve.to_dataframe()
    assert "excess_return" in df.columns
    assert len(df) == 2


# ── Account API ─────────────────────────────────────────────────────────────

def test_account_usage():
    client = NexusAlpha("test-key")
    with patch.object(client._session, "get", return_value=make_mock_response(SAMPLE_USAGE)):
        usage = client.account.usage()
    assert usage.tier == 1
    assert usage.tier_name == "Insight"
    assert usage.requests_today == 12
    assert usage.remaining_this_hour() == 95  # 100 - 5


# ── Error handling ───────────────────────────────────────────────────────────

def test_raises_auth_error_on_403():
    client = NexusAlpha("bad-key")
    with patch.object(client._session, "get", return_value=make_mock_response({"detail": "Invalid or inactive API key"}, 403)):
        with pytest.raises(AuthError):
            client.signals.top()


def test_raises_rate_limit_on_429():
    client = NexusAlpha("test-key")
    with patch.object(client._session, "get", return_value=make_mock_response({}, 429)):
        with pytest.raises(RateLimitError):
            client.signals.top()


def test_raises_tier_error_on_tier_403():
    client = NexusAlpha("test-key")
    with patch.object(client._session, "get", return_value=make_mock_response({"detail": "Tier 2+ required for this endpoint"}, 403)):
        with pytest.raises(TierError) as exc_info:
            client.data.export()
    assert exc_info.value.required_tier == 2


def test_raises_api_error_on_500():
    client = NexusAlpha("test-key")
    with patch.object(client._session, "get", return_value=make_mock_response({"detail": "Internal error"}, 500)):
        with pytest.raises(APIError) as exc_info:
            client.signals.top()
    assert exc_info.value.status_code == 500
