"""
NEXUS Alpha API client — main entry point.

Usage:
    from nexus_alpha import NexusAlpha
    client = NexusAlpha("nx_live_your_key_here")
"""

from __future__ import annotations

import os
import threading
from typing import Callable, Optional
from datetime import date

import requests

from .exceptions import AuthError, RateLimitError, TierError, APIError
from .models import (
    Signal, SignalCollection, PerformanceReport, EquityCurve,
    HoldPeriodStats, UsageStats,
)

DEFAULT_BASE_URL = "https://api.nexusalpha.io"
TIER_NAMES = {1: "Insight", 2: "Intelligence", 3: "Institutional"}
RATE_LIMITS = {1: {"requests": 100, "window_seconds": 3600},
               2: {"requests": 500, "window_seconds": 3600},
               3: {"requests": 5000, "window_seconds": 3600}}


def _raise_for_status(resp: requests.Response):
    if resp.status_code == 200:
        return
    if resp.status_code == 403:
        try:
            detail = resp.json().get("detail", "")
        except Exception:
            detail = ""
        if "Tier" in detail:
            tier = int(detail.split("Tier ")[1].split("+")[0])
            raise TierError(tier, detail)
        raise AuthError(detail or "Invalid or inactive API key")
    if resp.status_code == 429:
        raise RateLimitError()
    try:
        detail = resp.json().get("detail", "")
    except Exception:
        detail = ""
    raise APIError(resp.status_code, detail or f"HTTP {resp.status_code}")


class _SignalsAPI:
    """Signals namespace — client.signals.*"""

    def __init__(self, client: NexusAlpha):
        self._c = client

    def top(self, limit: int = 20) -> SignalCollection:
        """
        Highest-confidence BUY and OVERWEIGHT signals right now.

        Returns: SignalCollection
        Example::
            top = client.signals.top(limit=5)
            for s in top:
                print(s.ticker, s.confidence)
        """
        resp = self._c._get("/signals/top", params={"limit": limit})
        return SignalCollection(
            signals=[Signal.from_dict(r) for r in resp],
            count=len(resp),
        )

    def search(
        self,
        ticker: Optional[str] = None,
        signal: Optional[str] = None,
        min_confidence: float = 0.60,
        limit: int = 50,
    ) -> SignalCollection:
        """
        Search signals with filters.

        Args:
            ticker:         Filter by ticker symbol (e.g. "NVDA")
            signal:         Filter by signal type ("BUY", "OVERWEIGHT", "NEUTRAL")
            min_confidence: Minimum confidence score (default 0.60)
            limit:          Max results (default 50)

        Returns: SignalCollection
        """
        params = {"min_confidence": min_confidence, "limit": limit}
        if ticker:
            params["ticker"] = ticker.upper()
        if signal:
            params["signal"] = signal.upper()
        resp = self._c._get("/signals", params=params)
        return SignalCollection(
            signals=[Signal.from_dict(r) for r in resp],
            count=len(resp),
        )

    def history(
        self,
        ticker: Optional[str] = None,
        signal: Optional[str] = None,
        form_type: Optional[str] = None,
        min_confidence: float = 0.60,
        max_confidence: float = 0.75,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        limit: int = 500,
    ) -> SignalCollection:
        """
        Full filterable signal history (Tier 1+, up to 500 rows; Tier 2+ up to 5000).

        Args:
            ticker:         Filter by ticker symbol
            signal:         Filter by signal type
            form_type:      Filter by filing type ("10-K", "10-Q", "8-K")
            min_confidence: Minimum confidence (default 0.60)
            max_confidence: Maximum confidence (default 0.75, the cap)
            date_from:      Start date "YYYY-MM-DD"
            date_to:        End date "YYYY-MM-DD"
            limit:          Max results

        Returns: SignalCollection

        Example::
            # All NVDA signals from 2024
            nvda = client.signals.history(ticker="NVDA", date_from="2024-01-01")
            df = nvda.to_dataframe()  # requires pandas
        """
        params = {
            "min_confidence": min_confidence,
            "max_confidence": max_confidence,
            "limit": limit,
        }
        if ticker:     params["ticker"]     = ticker.upper()
        if signal:     params["signal"]     = signal.upper()
        if form_type:  params["form_type"]  = form_type.upper()
        if date_from:  params["date_from"]  = date_from
        if date_to:    params["date_to"]    = date_to

        resp = self._c._get("/signals/history", params=params)
        sigs = [Signal.from_dict(r) for r in resp.get("signals", [])]
        return SignalCollection(
            signals=sigs,
            count=resp.get("count", len(sigs)),
            filters=resp.get("filters", {}),
            disclaimer=resp.get("disclaimer", ""),
        )


class _DataAPI:
    """Data namespace — client.data.*"""

    def __init__(self, client: NexusAlpha):
        self._c = client

    def export(
        self,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        min_confidence: float = 0.60,
    ):
        """
        Download full signal history as a pandas DataFrame (Tier 2+, up to 10k rows).

        Args:
            date_from:      Start date "YYYY-MM-DD"
            date_to:        End date "YYYY-MM-DD"
            min_confidence: Minimum confidence (default 0.60)

        Returns: pandas.DataFrame (requires pip install pandas)

        Example::
            df = client.data.export(date_from="2023-01-01")
            df.to_csv("nexus_signals.csv", index=False)
        """
        try:
            import pandas as pd
            import io
        except ImportError:
            raise ImportError("pandas is required for data.export(): pip install pandas")

        params = {"min_confidence": min_confidence}
        if date_from: params["date_from"] = date_from
        if date_to:   params["date_to"]   = date_to

        resp = self._c._session.get(
            f"{self._c.base_url}/data/export",
            headers=self._c._headers(),
            params=params,
            stream=True,
        )
        _raise_for_status(resp)
        csv_content = resp.content.decode("utf-8")
        return pd.read_csv(io.StringIO(csv_content), parse_dates=["signal_date"])


class _AnalyticsAPI:
    """Analytics namespace — client.analytics.*"""

    def __init__(self, client: NexusAlpha):
        self._c = client

    def performance(self) -> PerformanceReport:
        """
        Full walk-forward backtest results (Tier 1+).

        Returns: PerformanceReport with by_hold_period stats and equity curve.

        Example::
            perf = client.analytics.performance()
            print(perf.best_hold_period.sharpe_annualized)   # 1.20
            df = perf.equity_curve.to_dataframe()
        """
        resp = self._c._get("/analytics/performance")

        hold_periods = {}
        for key, val in resp.get("by_hold_period", {}).items():
            hold_periods[key] = HoldPeriodStats(
                hold_days=val["hold_days"],
                n_signals=val["n_signals"],
                win_rate=val["win_rate"],
                avg_return_pct=val["avg_return_pct"],
                avg_excess_vs_spy=val["avg_excess_vs_spy"],
                sharpe_annualized=val["sharpe_annualized"],
                max_drawdown_pct=val["max_drawdown_pct"],
                by_confidence_bucket=val.get("by_confidence_bucket", {}),
                by_signal=val.get("by_signal", {}),
            )

        eq_raw = resp.get("equity_curve")
        equity_curve = None
        if eq_raw:
            equity_curve = EquityCurve(
                quarters=eq_raw["quarters"],
                quarterly_return_pct=eq_raw["quarterly_return_pct"],
                quarterly_spy_pct=eq_raw["quarterly_spy_pct"],
                cumulative_port=eq_raw["cumulative_port"],
                cumulative_spy=eq_raw["cumulative_spy"],
                total_return_pct=eq_raw["total_return_pct"],
                spy_total_return_pct=eq_raw["spy_total_return_pct"],
                max_drawdown_pct=eq_raw["max_drawdown_pct"],
                n_signals_evaluated=eq_raw["n_signals_evaluated"],
                generated_at=eq_raw["generated_at"],
            )

        return PerformanceReport(
            methodology=resp.get("methodology", {}),
            by_hold_period=hold_periods,
            equity_curve=equity_curve,
            live_signal_distribution=resp.get("live_signal_distribution", []),
            top_current_signals=resp.get("top_current_signals", []),
            disclaimer=resp.get("disclaimer", ""),
        )


class _AccountAPI:
    """Account namespace — client.account.*"""

    def __init__(self, client: NexusAlpha):
        self._c = client

    def usage(self) -> UsageStats:
        """
        Your API usage statistics and remaining quota.

        Returns: UsageStats

        Example::
            usage = client.account.usage()
            print(f"Requests today: {usage.requests_today}")
            print(f"Remaining this hour: {usage.remaining_this_hour()}")
        """
        resp = self._c._get("/usage")
        tier = resp.get("tier", 1)
        return UsageStats(
            total_calls=resp.get("total_calls", 0),
            requests_last_hour=resp.get("requests_last_hour", 0),
            requests_today=resp.get("requests_today", 0),
            requests_7d=resp.get("requests_7d", 0),
            requests_30d=resp.get("requests_30d", 0),
            first_call=resp.get("first_call"),
            last_call=resp.get("last_call"),
            tier=tier,
            tier_name=TIER_NAMES.get(tier, "Unknown"),
            rate_limit=RATE_LIMITS.get(tier, RATE_LIMITS[1]),
        )


class NexusAlpha:
    """
    NEXUS Alpha API client.

    Args:
        api_key:  Your API key (from welcome email or nexusalpha.io/dashboard)
        base_url: API base URL (default: https://api.nexusalpha.io)
        timeout:  Request timeout in seconds (default: 30)

    Namespaces:
        client.signals    — Signal retrieval and filtering
        client.data       — Bulk export (Tier 2+)
        client.analytics  — Backtest performance (Tier 1+)
        client.account    — Usage stats and quota

    Example::
        from nexus_alpha import NexusAlpha

        client = NexusAlpha("your-api-key")

        # Top signals
        for s in client.signals.top(5):
            print(s.ticker, s.signal, s.confidence)

        # Full history as DataFrame
        df = client.signals.history(date_from="2024-01-01").to_dataframe()

        # Performance report
        perf = client.analytics.performance()
        print(perf.best_hold_period.sharpe_annualized)

        # Real-time stream
        client.stream(lambda s: print(s))
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = 30,
    ):
        self.api_key  = api_key or os.getenv("NEXUS_ALPHA_API_KEY")
        if not self.api_key:
            raise AuthError(
                "No API key provided. Pass api_key= or set NEXUS_ALPHA_API_KEY env var. "
                "Get a key at nexusalpha.io."
            )
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout
        self._session = requests.Session()

        # Namespaced resource objects
        self.signals   = _SignalsAPI(self)
        self.data      = _DataAPI(self)
        self.analytics = _AnalyticsAPI(self)
        self.account   = _AccountAPI(self)

    def _headers(self) -> dict:
        return {"X-API-Key": self.api_key, "Accept": "application/json"}

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self._session.get(
            f"{self.base_url}{path}",
            headers=self._headers(),
            params=params or {},
            timeout=self.timeout,
        )
        _raise_for_status(resp)
        return resp.json()

    def ping(self) -> bool:
        """
        Verify the API key is valid and the service is reachable.

        Returns: True if authenticated successfully.

        Raises: AuthError if the key is invalid.
        """
        try:
            self._get("/usage")
            return True
        except (AuthError, TierError):
            raise
        except Exception:
            return False

    def stream(
        self,
        on_signal: Callable[[dict], None],
        on_error: Optional[Callable[[Exception], None]] = None,
        reconnect: bool = True,
    ) -> None:
        """
        Connect to the real-time WebSocket signal stream. Blocks until disconnected.

        Args:
            on_signal:  Callback called with each new signal dict
            on_error:   Optional callback called on connection errors
            reconnect:  Auto-reconnect on disconnect (default True)

        Example::
            def handle(signal):
                print(f"{signal['ticker']} → {signal['signal']} ({signal['confidence']:.3f})")
                print(f"  Rationale: {signal.get('rationale', '')}")

            client.stream(handle)  # blocks; Ctrl-C to stop
        """
        try:
            import websocket
        except ImportError:
            raise ImportError(
                "websocket-client is required for streaming: pip install websocket-client\n"
                "Or install all extras: pip install nexus-alpha[stream]"
            )

        import time

        ws_url = self.base_url.replace("https://", "wss://").replace("http://", "ws://")
        ws_url = f"{ws_url}/ws/signals?api_key={self.api_key}"

        def _on_message(ws, message):
            import json
            try:
                data = json.loads(message)
                if data.get("type") == "heartbeat":
                    return
                on_signal(data)
            except Exception as e:
                if on_error:
                    on_error(e)

        def _on_error(ws, error):
            if on_error:
                on_error(error)

        def _on_close(ws, code, msg):
            pass

        while True:
            ws = websocket.WebSocketApp(
                ws_url,
                on_message=_on_message,
                on_error=_on_error,
                on_close=_on_close,
            )
            ws.run_forever(ping_interval=25, ping_timeout=10)
            if not reconnect:
                break
            time.sleep(5)

    def stream_async(
        self,
        on_signal: Callable[[dict], None],
        on_error: Optional[Callable[[Exception], None]] = None,
    ) -> threading.Thread:
        """
        Connect to the WebSocket stream in a background thread. Non-blocking.

        Returns: threading.Thread (daemon=True, already started)

        Example::
            t = client.stream_async(lambda s: print(s))
            # ... do other work ...
            # Thread auto-stops when main program exits
        """
        t = threading.Thread(
            target=self.stream,
            kwargs={"on_signal": on_signal, "on_error": on_error, "reconnect": True},
            daemon=True,
        )
        t.start()
        return t

    def __repr__(self) -> str:
        masked = self.api_key[:8] + "..." if self.api_key else "None"
        return f"<NexusAlpha key={masked} base_url={self.base_url}>"
