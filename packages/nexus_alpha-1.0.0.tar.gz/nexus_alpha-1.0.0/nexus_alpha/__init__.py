"""
NEXUS Alpha Python SDK
======================
Institutional-grade alternative data signals from SEC EDGAR filings.

Quick start::

    from nexus_alpha import NexusAlpha

    client = NexusAlpha("your-api-key")

    # Top signals right now
    signals = client.signals.top(limit=10)
    for s in signals:
        print(s.ticker, s.signal, s.confidence, s.rationale)

    # Full history as a DataFrame
    df = client.signals.history(min_confidence=0.65).to_dataframe()

    # Live WebSocket stream
    def on_signal(signal):
        print(f"NEW SIGNAL: {signal['ticker']} → {signal['signal']}")

    client.stream(on_signal)  # blocks; Ctrl-C to stop

Docs: https://nexusalpha.io/docs
"""

from .client import NexusAlpha
from .exceptions import NexusAlphaError, AuthError, RateLimitError, APIError
from .models import Signal, SignalCollection, PerformanceReport

__version__ = "1.0.0"
__all__ = [
    "NexusAlpha",
    "NexusAlphaError", "AuthError", "RateLimitError", "APIError",
    "Signal", "SignalCollection", "PerformanceReport",
]
