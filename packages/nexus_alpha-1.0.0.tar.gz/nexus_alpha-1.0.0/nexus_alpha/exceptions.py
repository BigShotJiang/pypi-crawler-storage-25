"""Custom exceptions for the NEXUS Alpha SDK."""


class NexusAlphaError(Exception):
    """Base exception for all NEXUS Alpha SDK errors."""
    pass


class AuthError(NexusAlphaError):
    """Raised when the API key is invalid, inactive, or has insufficient tier."""
    def __init__(self, message: str = "Invalid or inactive API key. Check your key at nexusalpha.io/dashboard."):
        super().__init__(message)


class RateLimitError(NexusAlphaError):
    """Raised when the per-hour request limit is exceeded."""
    def __init__(self, message: str = "Rate limit exceeded. Upgrade your tier or wait for the next hour window."):
        super().__init__(message)


class TierError(NexusAlphaError):
    """Raised when the endpoint requires a higher subscription tier."""
    def __init__(self, required_tier: int, message: str = ""):
        self.required_tier = required_tier
        msg = message or f"Tier {required_tier}+ required for this endpoint. Upgrade at nexusalpha.io."
        super().__init__(msg)


class APIError(NexusAlphaError):
    """Raised for unexpected API errors (5xx, malformed response, etc.)."""
    def __init__(self, status_code: int, message: str = ""):
        self.status_code = status_code
        super().__init__(message or f"API error {status_code}. Check nexusalpha.io/status for incidents.")
