"""
Data models returned by the NEXUS Alpha SDK.
All models are dataclasses — easy to serialize, introspect, and convert to DataFrames.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import date
from typing import Optional, List, Dict, Any


@dataclass
class Signal:
    """A single investment signal generated from an SEC filing."""
    ticker: str
    signal_date: date
    signal: str                         # BUY | OVERWEIGHT | NEUTRAL
    confidence: float                   # 0.65–0.75 (capped; IC negative above 0.75)
    rationale: Optional[str] = None
    freshness_days: Optional[int] = None
    freshness_status: Optional[str] = None  # LIVE | AGING | STALE
    disclaimer: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "Signal":
        return cls(
            ticker=d["ticker"],
            signal_date=date.fromisoformat(d["signal_date"]) if isinstance(d["signal_date"], str) else d["signal_date"],
            signal=d["signal"],
            confidence=float(d["confidence"]),
            rationale=d.get("rationale"),
            freshness_days=d.get("freshness_days"),
            freshness_status=d.get("freshness_status"),
            disclaimer=d.get("disclaimer", ""),
        )

    def to_dict(self) -> dict:
        d = asdict(self)
        d["signal_date"] = str(self.signal_date)
        return d

    def __repr__(self) -> str:
        fs = f" [{self.freshness_status}]" if self.freshness_status else ""
        return f"<Signal {self.ticker} {self.signal} conf={self.confidence:.3f}{fs}>"


@dataclass
class SignalCollection:
    """A list of signals with helper methods for analysis."""
    signals: List[Signal]
    count: int = 0
    filters: Dict[str, Any] = field(default_factory=dict)
    disclaimer: str = ""

    def __post_init__(self):
        if not self.count:
            self.count = len(self.signals)

    def __iter__(self):
        return iter(self.signals)

    def __len__(self):
        return len(self.signals)

    def __repr__(self) -> str:
        return f"<SignalCollection count={self.count}>"

    def to_dataframe(self):
        """Convert to pandas DataFrame. Requires: pip install pandas"""
        try:
            import pandas as pd
        except ImportError:
            raise ImportError("pandas is required: pip install pandas")
        if not self.signals:
            return pd.DataFrame()
        records = [s.to_dict() for s in self.signals]
        df = pd.DataFrame(records)
        df["signal_date"] = pd.to_datetime(df["signal_date"])
        return df

    def filter(
        self,
        signal: Optional[str] = None,
        min_confidence: Optional[float] = None,
        freshness: Optional[str] = None,
    ) -> "SignalCollection":
        """Filter signals client-side. Returns new SignalCollection."""
        result = self.signals
        if signal:
            result = [s for s in result if s.signal == signal.upper()]
        if min_confidence is not None:
            result = [s for s in result if s.confidence >= min_confidence]
        if freshness:
            result = [s for s in result if s.freshness_status == freshness.upper()]
        return SignalCollection(signals=result, filters=self.filters)

    def best(self, n: int = 5) -> List[Signal]:
        """Top N signals by confidence."""
        return sorted(self.signals, key=lambda s: s.confidence, reverse=True)[:n]


@dataclass
class HoldPeriodStats:
    """Backtest statistics for a specific hold period."""
    hold_days: int
    n_signals: int
    win_rate: float
    avg_return_pct: float
    avg_excess_vs_spy: float
    sharpe_annualized: float
    max_drawdown_pct: float
    by_confidence_bucket: Dict[str, Any] = field(default_factory=dict)
    by_signal: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EquityCurve:
    """Quarterly equity curve data (60-day hold, 2022–2025)."""
    quarters: List[str]
    quarterly_return_pct: List[float]
    quarterly_spy_pct: List[float]
    cumulative_port: List[float]
    cumulative_spy: List[float]
    total_return_pct: float
    spy_total_return_pct: float
    max_drawdown_pct: float
    n_signals_evaluated: int
    generated_at: str

    def to_dataframe(self):
        """Convert to pandas DataFrame."""
        try:
            import pandas as pd
        except ImportError:
            raise ImportError("pandas is required: pip install pandas")
        return pd.DataFrame({
            "quarter":            self.quarters,
            "portfolio_return":   self.quarterly_return_pct,
            "spy_return":         self.quarterly_spy_pct,
            "excess_return":      [p - s for p, s in zip(self.quarterly_return_pct, self.quarterly_spy_pct)],
            "cumulative_port":    self.cumulative_port,
            "cumulative_spy":     self.cumulative_spy,
        })


@dataclass
class PerformanceReport:
    """Full analytics/performance response."""
    methodology: Dict[str, str]
    by_hold_period: Dict[str, HoldPeriodStats]
    equity_curve: Optional[EquityCurve]
    live_signal_distribution: List[Dict]
    top_current_signals: List[Dict]
    disclaimer: str = ""

    @property
    def best_hold_period(self) -> HoldPeriodStats:
        """Returns the hold period with the highest Sharpe ratio."""
        return max(self.by_hold_period.values(), key=lambda s: s.sharpe_annualized)


@dataclass
class UsageStats:
    """API usage statistics for the authenticated client."""
    total_calls: int
    requests_last_hour: int
    requests_today: int
    requests_7d: int
    requests_30d: int
    first_call: Optional[str]
    last_call: Optional[str]
    tier: int
    tier_name: str
    rate_limit: Dict[str, int]  # {"requests": 100, "window_seconds": 3600}

    def remaining_this_hour(self) -> int:
        return max(0, self.rate_limit.get("requests", 100) - self.requests_last_hour)
