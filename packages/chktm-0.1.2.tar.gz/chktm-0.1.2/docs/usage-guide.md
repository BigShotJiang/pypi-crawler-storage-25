# Usage Guide and Search Best Practices

**chktm is a research aid, not legal clearance.** Trademark conflicts require a
likelihood-of-confusion analysis that only a qualified attorney can perform.
Do not rely on this tool for any legal decision. Always consult an attorney
before adopting a mark.

---

## Table of Contents

- [How chktm searches work](#how-chktm-searches-work)
- [Constructing effective searches](#constructing-effective-searches)
- [Understanding risk tiers](#understanding-risk-tiers)
- [Choosing international classes](#choosing-international-classes)
- [Interpreting results](#interpreting-results)
- [Common search patterns by use case](#common-search-patterns-by-use-case)
- [Working with the web UI](#working-with-the-web-ui)
- [Working with the JSON API](#working-with-the-json-api)
- [Using chktm via MCP (AI agents)](#using-chktm-via-mcp-ai-agents)
- [What chktm does NOT catch](#what-chktm-does-not-catch)
- [Recommended workflow](#recommended-workflow)

---

## How chktm searches work

chktm performs **normalized substring matching** against the full USPTO trademark
corpus. When you search for a term:

1. Your term is **normalized**: lowercased, whitespace removed, hyphens removed.
   - `"Thunder Corp"` → `thundercorp`
   - `"thunder-corp"` → `thundercorp`
   - `"THUNDERCORP"` → `thundercorp`

2. Every registered and pending trademark in the corpus has a pre-computed
   normalized version of its wordmark.

3. chktm finds all marks whose normalized wordmark **contains** your normalized
   term as a substring.
   - Searching `widget` matches `THUNDERCORP`, `WIDGET WORLD`, `SUPER WIDGET`, etc.
   - Searching `thundercorp` matches `THUNDERCORP` but NOT `THUNDER` or `WIDGETS` alone.

4. Each match is classified into a **risk tier** based on whether the mark is
   live and whether it shares international classes with your query.

## Constructing effective searches

### Search multiple variants of your proposed mark

Trademarks can be written in many forms. Always search for:

- **Concatenated**: `thundercorp`
- **Spaced**: `"thunder corp"` (quote it so your shell treats it as one term)
- **Hyphenated**: `thunder-corp`
- **Common misspellings/variants**: `thundercrop`, `thundrcorp`

**Example (all platforms):**

```bash
chktm search thundercorp "thunder corp" thunder-corp thundercrop --classes 9,41,42
```

Each term is searched independently. The report groups results by term so you
can see which variant triggered which matches.

### Search for the individual components too

If your mark is a compound word, search for the components separately:

```bash
chktm search thundercorp thunder corp --classes 9,41,42
```

This catches marks like `THUNDER` or `WIDGETS` that could still create confusion
even though they don't match the full compound. A mark called `THUNDER` in
class 9 (software) would be highly relevant to `THUNDERCORP` even though
it's not a substring match on the compound.

### Keep terms short and meaningful

chktm does substring matching, so shorter terms cast a wider net:

- `thunder` matches `THUNDERCORP`, `THUNDER GOOD`, `THUNDER FRESH`, etc.
- `thundercorp` only matches marks containing that exact sequence.

Start broad, then narrow down. A search for `thunder` with 50 results is more
useful than a search for `thundercorpgamesinc` with zero results.

### Use quotes for multi-word terms

Your shell splits arguments on spaces. To search for a phrase as a single term,
wrap it in quotes:

**Linux / macOS:**

```bash
chktm search "thunder corp" "super thunder"
```

**Windows (PowerShell):**

```powershell
chktm search "thunder corp" "super thunder"
```

**Windows (Command Prompt):**

```cmd
chktm search "thunder corp" "super thunder"
```

Without quotes, `chktm search thunder corp` searches for two separate terms:
`thunder` and `widgets`.

## Understanding risk tiers

| Tier | Meaning | When it applies |
|------|---------|-----------------|
| **HIGH** | Likely conflict | Mark is **live** (active/pending), the name matches, AND at least one international class overlaps with your `--classes` filter. |
| **MEDIUM** | Possible conflict | Mark is **live**, the name matches, but it's in **different classes** from your filter. Still worth reviewing — class boundaries are not absolute in trademark law. |
| **LOW** | Informational | Mark is **dead** (abandoned, cancelled, expired). Only shown with `--include-dead`. Low risk but useful context — it tells you the name has been claimed before. |

### Why MEDIUM still matters

Trademark law uses a "likelihood of confusion" standard that considers more
than just class overlap. A famous mark in an unrelated class can still block
your registration. For example, `APPLE` in class 9 (computers) would likely
block an `APPLE` in class 41 (entertainment services) even without class overlap.

**Rule of thumb:** investigate all HIGH and MEDIUM results. Only dismiss MEDIUM
results after understanding the mark's scope and fame.

### Why LOW can be useful

Dead marks tell you:

- **The name has been tried before.** If it was abandoned, there may be a reason
  (opposition, inability to demonstrate use, etc.).
- **The name might be revived.** A cancelled registration can sometimes be
  re-filed by the original owner.
- **Prior art exists.** An attorney may want to know about prior registrations
  even if they're currently dead.

To include dead marks:

```bash
chktm search thundercorp --include-dead --classes 9,41,42
```

## Choosing international classes

The `--classes` flag determines which international classes trigger HIGH risk
(vs MEDIUM). Choose classes that match your intended use of the mark.

### Default classes: 9, 41, 42

chktm defaults to classes most relevant to software and gaming:

| Class | Covers | Examples |
|-------|--------|----------|
| 9 | Software, electronics, downloadable goods | Video games, mobile apps, SaaS platforms |
| 41 | Entertainment, education, training | Game publishing, streaming, esports |
| 42 | Software development, SaaS, tech services | Cloud hosting, IT consulting, API services |

### Common class selections by industry

**Game studio / indie games:**

```bash
--classes 9,41,42
```

**Clothing brand:**

```bash
--classes 25,35
```

- 25: Clothing, footwear, headgear
- 35: Advertising, retail services

**Food & beverage:**

```bash
--classes 29,30,32,33,43
```

- 29: Processed foods, dairy, meat
- 30: Coffee, tea, bakery, confections
- 32: Non-alcoholic beverages
- 33: Alcoholic beverages
- 43: Restaurant and bar services

**Consulting / professional services:**

```bash
--classes 35,36,42,45
```

- 35: Business consulting, advertising
- 36: Financial services, insurance
- 42: Technology consulting
- 45: Legal services, security

**Healthcare:**

```bash
--classes 5,10,44
```

- 5: Pharmaceuticals, medical supplies
- 10: Medical devices
- 44: Medical and health services

### When in doubt, cast a wide net

You can specify many classes:

```bash
chktm search mymark --classes 9,25,35,41,42
```

More classes means more HIGH results to review, but fewer potential conflicts
hiding in the MEDIUM tier.

### Finding the right class

The full list of 45 Nice Classification classes is maintained by WIPO:
https://www.wipo.int/classifications/nice/nclpub/en/fr/

If you're unsure which class your goods/services fall into, check the WIPO
class lookup before running your search.

## Interpreting results

### Reading the Markdown report

A typical result entry looks like:

```
#### SOLARFLARE FRESH
- Serial: 88123456  | Registration: 5678901
- Status: 700 (live)
- Filed: 2020-03-15  | Registered: 2021-06-01
- Owner: Fresh Corp.
- Classes: 9, 41
- Goods/services: [Class 009] Computer software for...
- USPTO link: https://tsdr.uspto.gov/#caseNumber=88123456&caseType=SERIAL_NO
```

Key fields to check:

- **Status (live)**: This mark is currently active. It's a real obstacle.
- **Classes**: Overlapping classes with your search = HIGH risk.
- **Goods/services**: Read the actual description. Two marks in class 9 might
  not conflict if one is "computer hardware" and the other is "downloadable
  video games."
- **Owner**: A large company is more likely to enforce aggressively than a
  small sole proprietor.
- **USPTO link**: Click through to see the full case file on TSDR, including
  the mark's image (if any), full prosecution history, and current status.

### Reading the JSON output

JSON output (`--json`) has the same information in a structured format suitable
for scripting and AI agent consumption:

```bash
chktm search thundercorp --json | python3 -c "
import json, sys
data = json.load(sys.stdin)
print(f'HIGH: {data[\"summary\"][\"high\"]}')
print(f'MEDIUM: {data[\"summary\"][\"medium\"]}')
for tr in data['results']:
    for m in tr['matches']:
        if m['risk'] == 'HIGH':
            print(f'  {m[\"wordmark\"]} — {m[\"owner_name\"]} — classes {m[\"classes\"]}')
"
```

**Windows (PowerShell):**

```powershell
chktm search thundercorp --json | python -c @"
import json, sys
data = json.load(sys.stdin)
print(f'HIGH: {data[chr(34)+chr(115)+chr(117)+chr(109)+chr(109)+chr(97)+chr(114)+chr(121)+chr(34)][chr(34)+chr(104)+chr(105)+chr(103)+chr(104)+chr(34)]}')
"@
```

Or more practically on Windows, write to a file and process it:

```powershell
chktm search thundercorp --json --out results.json
```

## Common search patterns by use case

### LLC / company formation

You're forming `Thundercorp Games LLC` and want to check for conflicts:

```bash
chktm search thundercorp "thunder corp" thunder thundercorpgames --classes 9,41,42
```

Search for the core mark (`thundercorp`), variations, and the individual
component (`thunder`). Don't include `LLC`, `Inc`, `Studios`, etc. in the
search — those are generic terms that don't form part of the protectable mark.

### Product / app naming

You're launching a product called "ThunderBolt Pro":

```bash
chktm search thunderbolt "thunder bolt" thunderboltpro --classes 9,42
```

Pay special attention to existing marks in your exact class. `THUNDERBOLT` is
famously owned by Intel in class 9 — that would show up as HIGH.

### Domain name purchase

Before buying `thundercorp.com`, check if the name conflicts with existing marks:

```bash
chktm search thundercorp "thunder corp" --classes 9,35,42 --include-dead
```

Including dead marks is useful here — a previously registered mark might still
have common-law rights even if the registration lapsed.

### Brand refresh / rename

You're renaming from `OldBrand` to `NewBrand`. Search for the new name, and
also search the old name to understand your own registration landscape:

```bash
chktm search newbrand "new brand" --classes 9,41,42
chktm search oldbrand --classes 9,41,42
```

## Working with the web UI

Start the server:

```bash
chktm serve
```

Then open `http://localhost:8000/` in your browser.

- **Search box**: Enter one or more terms separated by spaces.
- **Classes field**: Comma-separated class numbers (default: 9,41,42).
- **Include dead marks**: Check this box to show abandoned/expired marks.
- Results are color-coded: red border = HIGH, amber = MEDIUM, gray = LOW.
- Click "View on USPTO TSDR" to see the full case file.

The web UI calls the same API as the CLI, so results are identical.

## Using chktm via MCP (AI agents)

AI agents connected via MCP can use three tools:

### `search_trademarks`

```
Search the US trademark corpus for potential conflicts.

Parameters:
  terms: ["thundercorp", "thunder corp"]   # required
  classes: [9, 41, 42]                      # optional, defaults to [9,41,42]
  include_dead: false                       # optional, defaults to false

Returns: JSON with matches grouped by term and risk tier.
```

### `generate_legal_report`

```
Generate an attorney-ready trademark screening report.

Parameters:
  terms: ["thundercorp", "thunder corp", "thunder-corp"]  # required
  classes: [9, 41, 42]                                     # optional

Returns: JSON legal report with exact search results, automatic component
word analysis (splits compound terms and searches each part), matches
grouped by owner, limitations, and recommended next steps.
```

Use this instead of `search_trademarks` when the user needs a report for a
legal professional or is making a trademark filing decision.

### `corpus_status`

```
Check the status of the trademark database.

Parameters: none

Returns: JSON with total marks, live/dead counts, last update, coverage dates.
```

### Best practices for agents

1. **Always call `corpus_status` first** to verify the database is initialized
   and reasonably current. If `last_updated` is more than a week old, suggest
   running `chktm update`.

2. **Search multiple variants** of the proposed mark, just like a human would.
   Include the concatenated form, spaced form, and individual components.

3. **Parse the risk tiers** and present HIGH results prominently with the TSDR
   link for human review.

4. **Always include the disclaimer** when presenting results to users. The
   JSON response includes a `disclaimer` field for this purpose.

5. **Don't over-interpret results.** A zero-result search does NOT mean the
   name is safe — it means no existing registered marks match via substring.
   Phonetic conflicts, common-law marks, and foreign registrations are not
   checked.

## Agent efficiency: minimizing tokens and round-trips

When AI agents interact with chktm via MCP, each tool call has a cost in tokens
(for the request/response) and latency (for the round-trip). Here's how to get
the best results with the least overhead.

### 1. Batch terms in a single call

**Inefficient** (4 round-trips):

```
call search_trademarks(terms=["thundercorp"])
call search_trademarks(terms=["thunder corp"])
call search_trademarks(terms=["thunder-corp"])
call search_trademarks(terms=["thunder"])
```

**Efficient** (1 round-trip):

```
call search_trademarks(terms=["thundercorp", "thunder corp", "thunder-corp", "thunder"])
```

The tool accepts a list of terms and returns all results in a single response.
There is no per-term overhead on the server side — each term is an independent
SQL query, but they share the same database connection and response envelope.

### 2. Only call `corpus_status` once per session

The corpus doesn't change between calls within a single conversation.
Call `corpus_status` once at the start to verify the database is initialized,
then proceed directly to searches. Don't re-check between each search.

### 3. Use targeted classes, not all 45

Each class adds a join check per result row. The default `[9, 41, 42]` is fast.
Passing all 45 classes doesn't slow the query much, but it inflates the response
by classifying everything as HIGH instead of MEDIUM — more tokens for the agent
to parse with less signal.

**Best practice:** pass only the classes relevant to the user's industry.

### 4. Leave `include_dead` off unless asked

Dead marks roughly double the result count (the corpus is ~60% dead marks).
This means ~2x the response tokens. Only enable it when the user specifically
asks about abandoned marks or wants the full picture.

### 5. Parse the summary first, details on demand

The response includes a `summary` object:

```json
{
  "summary": { "high": 3, "medium": 12, "low": 0 }
}
```

An agent can report these counts to the user immediately without reading every
match object. Only parse the full `matches` array when the user wants details
or when the HIGH count is non-zero and warrants investigation.

### 6. Truncate goods/services in summaries

The `goods_services` field can be hundreds of characters per match. When
summarizing results for a user, truncate to ~100 characters or omit entirely
— the wordmark, owner, classes, and TSDR link are usually sufficient for a
first-pass summary.

### 7. Use the TSDR link as a hand-off

Rather than trying to extract and relay every field from the chktm response,
give the user the `tsdr_url` for HIGH-risk matches. The USPTO TSDR page has
the complete case file, images, prosecution history — information that chktm
intentionally doesn't replicate.

### Example: efficient agent flow

```
1. corpus_status()
   → Verify database_exists=true, note last_updated for the user
   → 1 round-trip, ~200 tokens response

2. search_trademarks(
     terms=["thundercorp", "thunder corp", "thunder-corp", "thunder"],
     classes=[9, 41, 42]
   )
   → 1 round-trip, response size depends on match count
   → Parse summary first: "Found 2 HIGH, 5 MEDIUM"
   → Only relay HIGH match details to user

Total: 2 MCP calls for a complete trademark screening.
```

### Response size estimates

| Scenario | Approximate response size |
|----------|--------------------------|
| 0 matches | ~300 tokens |
| 5 matches (typical targeted search) | ~1,500 tokens |
| 50 matches (broad single-word search) | ~12,000 tokens |
| 200+ matches (very common word) | ~40,000+ tokens |

If a broad search returns many results, the agent should advise the user to
narrow the search with more specific terms or fewer classes rather than
processing all matches.

## What chktm does NOT catch

Understanding the limitations is as important as understanding the features.

### 1. Phonetic / sound-alike conflicts

chktm matches on text, not sound. These would NOT be caught:

- `THUNDER` vs `ACMEE` (different spelling, same sound)
- `ENERGEE` vs `ENERGY` (phonetic variant)
- `KOOL` vs `COOL` (common substitution)

**Workaround:** manually search for phonetic variants as separate terms.

### 2. Visual / design mark conflicts

chktm only searches wordmarks (text). It cannot analyze:

- Logo similarities
- Stylized text
- Color schemes
- Trade dress

### 3. Common-law (unregistered) marks

The USPTO database only contains federal trademark registrations and
applications. It does NOT include:

- State-level trademark registrations
- Common-law marks (established through use, not registration)
- Business names that aren't trademarked
- Domain names, social media handles, app store listings

### 4. Foreign marks

chktm only searches US (USPTO) data. It does not cover:

- EU trademarks (EUIPO)
- UK trademarks (IPO)
- International registrations (WIPO Madrid)
- Any other jurisdiction

### 5. Very recent filings

USPTO bulk data is updated daily, but there is a lag of 1–3 days between a
filing and its appearance in the bulk data. For marks filed in the last few
days, also check [tmsearch.uspto.gov](https://tmsearch.uspto.gov) directly.

### 6. Broad confusion analysis

Real trademark clearance considers many factors beyond name and class:

- Channels of trade
- Sophistication of purchasers
- Strength of the existing mark
- Evidence of actual confusion
- Meaning and commercial impression
- Geographic overlap

chktm cannot assess any of these. It is a first-pass screening tool.

## Recommended workflow

### For a serious trademark decision (LLC formation, product launch):

1. **Generate a legal report:**
   ```bash
   chktm search yourmark "your mark" your-mark --classes <your-classes> --report legal --out legal-report.md
   ```
   This automatically runs component-word analysis, groups results by owner,
   and includes limitations and next steps — formatted for an attorney.

2. **Review the report.** Focus on the component analysis section — it
   identifies marks that an examiner could cite even if the exact compound
   isn't registered.

3. **Search tmsearch.uspto.gov** for the most recent few days of filings that
   may not be in the bulk data yet.

4. **Search common-law sources** (Google, industry directories, app stores,
   domain registrars) for unregistered usage.

5. **Hand the report to a trademark attorney.** The legal report is designed
   as a starting point for the conversation — it shows you've done preliminary
   research and highlights the specific marks they should evaluate.

### For a quick informal check:

```bash
chktm search myidea --classes 9,41,42
```

If you see zero HIGH results, that's encouraging but not conclusive. If you
see multiple HIGH results from well-known companies, that's a strong signal
to reconsider.
