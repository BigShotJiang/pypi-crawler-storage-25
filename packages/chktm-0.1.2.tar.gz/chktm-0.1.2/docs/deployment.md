# Deployment Guide

This guide covers running chktm locally (all platforms), building the container
image, pushing to quay.io, and deploying to OpenShift.

## Local Development (Linux, macOS, Windows)

For local use without containers, see the [README](../README.md) quickstart.
The key platform-specific steps:

### Set environment variables

**Linux / macOS (bash/zsh):**

```bash
export CHKTM_USPTO_API_KEY="your-key-here"
export CHKTM_DATA_DIR="$HOME/chktm-data"    # optional, defaults to ./data
```

**Windows (PowerShell):**

```powershell
$env:CHKTM_USPTO_API_KEY = "your-key-here"
$env:CHKTM_DATA_DIR = "$HOME\chktm-data"    # optional, defaults to .\data
```

**Windows (Command Prompt):**

```cmd
set CHKTM_USPTO_API_KEY=your-key-here
set CHKTM_DATA_DIR=%USERPROFILE%\chktm-data
```

### Run locally

```bash
chktm init                   # one-time download (~22 GB, 2-4 hours)
chktm init --off-peak        # 3x faster during 10pm-5am EST
chktm serve                  # start web UI + MCP server on port 8000
```

These commands work identically on all platforms. The init handles Ctrl+C
gracefully — it finishes the current file, commits to the database, and exits.
Re-run `chktm init` to resume where you left off.

The `--data-dir` is saved to your config file during init, so `chktm update`,
`chktm search`, and `chktm serve` find it automatically — no need to pass
`--data-dir` on every command.

---

## Container Deployment (OpenShift)

### Prerequisites

- `podman` (or `docker`) for building images — available on Linux, macOS, and
  Windows. On Windows, [Podman Desktop](https://podman-desktop.io/) is recommended.
- `oc` CLI authenticated to your OpenShift cluster
- A [USPTO ODP API key](https://data.uspto.gov/apis/getting-started) (free)
- A [quay.io](https://quay.io) account for the image registry

## 1. Build and Push the Image

```bash
# Build the image
podman build -t quay.io/<your-namespace>/chktm:latest -f Containerfile .

# Push to quay.io
podman login quay.io
podman push quay.io/<your-namespace>/chktm:latest
```

Replace `<your-namespace>` with your quay.io username or organization.

## 2. Create the OpenShift Project

```bash
# Create namespace
oc apply -f deploy/openshift/namespace.yaml

# Or use an existing project
oc project chktm
```

## 3. Configure the API Key

```bash
# Create the secret with your USPTO API key
oc create secret generic chktm-api-key \
  --from-literal=CHKTM_USPTO_API_KEY=<your-key> \
  -n chktm
```

Or edit `deploy/openshift/secret.yaml` and apply it:

```bash
oc apply -f deploy/openshift/secret.yaml
```

## 4. Create the Persistent Volume

```bash
oc apply -f deploy/openshift/pvc.yaml
```

The PVC requests 10 Gi — enough for the ~5 GB database plus room for
WAL files and temporary downloads during updates.

## 5. Initialize the Corpus

This is the longest step. The init job downloads the full USPTO trademark
corpus (~22 GB compressed) and ingests it into SQLite. Expect **2–4 hours**
depending on download speed and USPTO rate limits.

**Performance tips:**
- Schedule the init job during **off-peak hours** (10pm–5am EST) for ~3x
  faster downloads. Edit the job command to add `--off-peak`.
- Add `--stream-ingest` to skip writing extracted XML to disk (lower I/O).
- The job handles interrupts gracefully — if the pod is evicted, re-create
  the job and it resumes from where it left off.
- ZIPs are deleted after ingestion by default. Add `--keep-zips` if you
  need them for debugging.

```bash
oc apply -f deploy/openshift/init-job.yaml

# Monitor progress
oc logs -f job/chktm-init -n chktm
```

Wait for the job to complete before proceeding:

```bash
oc wait --for=condition=complete job/chktm-init -n chktm --timeout=12h
```

## 6. Deploy the Server

```bash
oc apply -f deploy/openshift/service.yaml
oc apply -f deploy/openshift/deployment.yaml
oc apply -f deploy/openshift/route.yaml
```

Get the route URL:

```bash
oc get route chktm -n chktm -o jsonpath='{.spec.host}'
```

Verify it's running:

```bash
curl https://<route-host>/api/status
```

## 7. (Optional) Set Up Automatic Updates

Deploy the CronJob to pull new daily files Mon–Fri at 6 AM EST:

```bash
oc apply -f deploy/openshift/update-cronjob.yaml
```

## Endpoints

Once deployed, the following endpoints are available:

| Endpoint | Purpose |
|----------|---------|
| `GET /` | Web search UI |
| `GET /api/status` | Corpus status (JSON) |
| `GET /api/search?q=<terms>&classes=9,41,42` | Search API (JSON) |
| `GET /docs` | Interactive API reference (Swagger UI) |
| `GET /redoc` | API reference (ReDoc) |
| `GET /openapi.json` | OpenAPI 3.x specification |
| `POST /mcp/` | MCP Streamable HTTP transport |
| `GET /mcp/sse/sse` | MCP SSE transport |

## Connecting MCP Clients

### MCP Desktop Clients

Add to your MCP client settings:

```json
{
  "mcpServers": {
    "chktm": {
      "type": "url",
      "url": "https://<route-host>/mcp/sse/sse"
    }
  }
}
```

Or for the newer Streamable HTTP transport:

```json
{
  "mcpServers": {
    "chktm": {
      "type": "url",
      "url": "https://<route-host>/mcp/"
    }
  }
}
```

### Local stdio transport

If running chktm locally (not in OpenShift), you can use stdio:

**Linux / macOS:**

```json
{
  "mcpServers": {
    "chktm": {
      "command": "python3",
      "args": ["-m", "chktm.mcp_server"],
      "env": {
        "CHKTM_DATA_DIR": "/home/youruser/chktm-data"
      }
    }
  }
}
```

**Windows:**

```json
{
  "mcpServers": {
    "chktm": {
      "command": "python",
      "args": ["-m", "chktm.mcp_server"],
      "env": {
        "CHKTM_DATA_DIR": "C:\\Users\\youruser\\chktm-data"
      }
    }
  }
}
```

### Available MCP Tools

| Tool | Description |
|------|-------------|
| `search_trademarks` | Search for potential trademark conflicts. Args: `terms` (list of strings), `classes` (optional list of ints), `include_dead` (optional bool). |
| `corpus_status` | Check database status: record counts, last update date, coverage range. |

### Example Agent Interaction

An AI agent connected via MCP can:

1. Call `corpus_status` to verify the database is initialized and fresh
2. Call `search_trademarks` with proposed mark names
3. Parse the structured JSON response to assess risk
4. Provide a summary to the user with TSDR links for further investigation

## Updating the Image

```bash
# Build new version
podman build -t quay.io/<your-namespace>/chktm:latest -f Containerfile .
podman push quay.io/<your-namespace>/chktm:latest

# Roll out in OpenShift
oc rollout restart deployment/chktm -n chktm
```

## Troubleshooting

### Init job fails or times out

Check the logs:
```bash
oc logs job/chktm-init -n chktm
```

Common issues:
- **Missing API key**: Verify the secret exists: `oc get secret chktm-api-key -n chktm`
- **Rate limited**: The job handles 429 errors, but persistent rate limiting
  may require waiting. Delete and re-create the job — it's resumable.
- **Disk full**: Increase the PVC size.

### Pod won't start

Check the database exists on the PVC:
```bash
oc exec deployment/chktm -n chktm -- ls -lh /data/chktm.db
```

If the database doesn't exist, the init job hasn't completed yet.

### SQLite locking errors

SQLite uses WAL mode which supports concurrent readers. However, only one
writer is allowed at a time. Don't run `chktm update` while the server is
writing. The CronJob uses `concurrencyPolicy: Forbid` to prevent overlap.

If you see locking errors, check for stuck update jobs:
```bash
oc get jobs -n chktm
```
