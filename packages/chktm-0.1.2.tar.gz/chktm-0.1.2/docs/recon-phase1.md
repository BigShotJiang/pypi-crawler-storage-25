# Phase 1 Recon Report

**Date:** 2026-04-10
**Author:** Nick Schuetz
**Status:** Complete

---

## 1. Data Source Clarification

SPEC.md refers to the "Trademark Case Files Dataset" from `data.uspto.gov`. There are
actually **two distinct datasets** that match this description:

| Dataset | Format | Source | Update cadence | Size |
|---------|--------|--------|---------------|------|
| Trademark Case Files Dataset (Research) | CSV / DTA (Stata) | www.uspto.gov/ip-policy/economic-research/research-datasets | Annual | ~4.3 GB |
| Trademark Full Text XML Data (No Images) | XML (V2.0 DTD) | data.uspto.gov (ODP) | Daily + annual backfile | Multi-GB (ZIP files, each ~80k records) |

**Recommendation:** Use the **XML bulk data** via the ODP. Reasons:

1. It is updated **daily**, not annually — critical for `chktm update`.
2. It lives on `data.uspto.gov` as SPEC.md specifies.
3. It contains all the fields we need (wordmark, classes, status, dates, owner, goods/services).
4. The research CSV dataset is designed for econometrics, not application-level screening.

## 2. ODP API Access Pattern

The legacy Bulk Data Storage System (`bulkdata.uspto.gov`) is **already dead** — DNS no
longer resolves. All access goes through the new Open Data Portal API.

### Base URL and Authentication

- **API base:** `https://api.uspto.gov`
- **Auth header:** `X-API-Key` (free registration)
- **Key registration:** https://data.uspto.gov/apis/getting-started → sign up at
  https://account.uspto.gov, then visit the API key manager
- **No cost.** The API is free, but a key is mandatory for all endpoints.

### Endpoints (from OpenAPI spec)

| Operation | Method | Path |
|-----------|--------|------|
| Search products | GET | `/api/v1/datasets/products/search?q=Trademark` |
| List files for a product | GET | `/api/v1/datasets/products/{productIdentifier}?includeFiles=true` |
| Download a file | GET | `/api/v1/datasets/products/files/{productIdentifier}/{fileName}` |

The download endpoint returns a **302 redirect** to the actual file location (likely S3).

### Product Identifiers

- **TRTDXFAP** — Trademark Full Text XML Data (No Images) – Daily Applications
- Annual backfile product identifier: **not yet confirmed** (could not query the API
  without a key). Search results reference "TRTAXMLA" but this needs live verification
  in Phase 2 after obtaining an API key.

### Rate Limits

Source: USPTO TSDR API User Guide (September 2020). The ODP may have different limits —
need to verify at https://data.uspto.gov/apis/api-rate-limits after getting a key.

| Window | All requests | ZIP downloads |
|--------|-------------|---------------|
| Normal hours | 60 req/key/min | 4 req/key/min |
| Off-peak (10pm–5am EST) | 120 req/key/min | 12 req/key/min |

**Implication for `chktm init`:** Bulk download of the full annual backfile (many ZIPs)
must respect the 4 req/min ZIP limit. A naive parallel download will get throttled.

## 3. XML Schema for a Single Mark Record

Source: "Trademark Applications Daily XML DTD Element Documentation (V2.0)"
— https://www.uspto.gov/sites/default/files/products/applications-documentation.pdf

### Document structure

```
<trademark-applications-daily>
  <version>
    <version-no>2.0</version-no>
    <version-date>YYYYMMDD</version-date>
  </version>
  <application-information>
    <file-segments>
      <file-segment>TRMK</file-segment>
      <action-keys>
        <action-key>NA</action-key>      <!-- NA=new app, TX=modified, etc. -->
        <case-file>
          ...one mark record...
        </case-file>
      </action-keys>
    </file-segments>
  </application-information>
</trademark-applications-daily>
```

### Key elements inside `<case-file>`

| chktm field | XML element | Location | Format |
|-------------|------------|----------|--------|
| serial_number | `<serial-number>` | `case-file` | 8-digit numeric string |
| registration_number | `<registration-number>` | `case-file` | 7-digit numeric (zeros if none) |
| wordmark | `<mark-identification>` | `case-file-header` | Variable-length text |
| status_code | `<status-code>` | `case-file-header` | 3-digit numeric string |
| filing_date | `<filing-date>` | `case-file-header` | YYYYMMDD |
| registration_date | `<registration-date>` | `case-file-header` | YYYYMMDD |
| owner_name | `<party-name>` | `case-file-owners > case-file-owner` | Text |
| intl_class | `<international-code>` | `classifications > classification` | 3-digit with leading zeros (e.g., "009") |
| goods_services | `<text>` | `case-file-statements > case-file-statement` | 40-char text lines (see below) |

### Goods/Services encoding (important gotcha)

Goods/services descriptions are **not a dedicated element**. They live in
`<case-file-statement>` entries where the `<type-code>` starts with `"GS"`.

The type-code format is: `GS` + 3-digit international class + 1-digit qualifier:
- Position 6 = `1`: normal goods/services text
- Position 6 = `2`: "less goods" text only
- Position 6 = `3`: embedded "less goods" within the text

The `<text>` child contains the actual description, in 40-character segments that must be
concatenated.

### Owner encoding

Multiple owners may exist (original applicant, post-publication assignees, etc.).
`<party-type>` codes distinguish them:
- `10` = Original Applicant
- `20` = Owner at Publication
- `30`+ = Post-registration assignees
- `70` = Last-listed owner (post-November 2003 records)

For chktm, we should use the **last owner** in the list (highest party-type), or
party-type `70` if present.

### Mark drawing code (wordmark filter)

`<mark-drawing-code>` position 1 tells us the mark type:
- `1` = Typeset word mark (pre-2003)
- `4` = Standard character mark (post-2003) — **this is the "pure wordmark"**
- `2`, `3`, `5` = Design/illustration marks (may have text, but are styled)
- `6` = Non-visual (e.g., sound marks)

chktm searches `<mark-identification>` regardless of drawing code, but this field is
useful context for the report.

## 4. Status Codes and Live/Dead Determination

The `<status-code>` in `<case-file-header>` is a 3-digit numeric. The DTD references
"Table 1 Trademark Status Codes" (a separate document). Based on research:

| Range | Meaning | is_live |
|-------|---------|---------|
| 100–199 | Pre-examination (pending) | 1 (live) |
| 200–299 | Under examination (pending) | 1 (live) |
| 300–399 | Awaiting various actions | 1 (live) |
| 400–499 | Publication / opposition | 1 (live) |
| 500–599 | Registration-related | 1 (live) |
| 600–699 | Abandoned | 0 (dead) |
| 700–799 | Registered / renewed | 1 (live) |
| 800–899 | Active (various) | 1 (live) |
| 900+ | Expired / cancelled | 0 (dead) |

**Caveat:** This range-based heuristic is derived from secondary sources, not from the
official Table 1 document. The exact mapping should be loaded from the official status
codes table at:
https://data.uspto.gov/ui/datasets/products/files/TRTDXFAP/Table1TrademarkStatusCodes_20250813.doc

This `.doc` file is available as a product file alongside the XML data. We should download
it in Phase 2 and build the definitive mapping.

## 5. File Format and Size

- **Annual backfile:** Series of ZIP files, each containing a single large XML file.
  Unzipped XML ranges from ~400 MB to ~3 GB per file, with ~80,000 trademark records each.
  Total corpus: approximately **12.7 million records**.
- **Daily files:** One ZIP per day containing that day's new and modified records.
- **File naming:** Confirmed pattern for daily: `apcYYMMDD.zip` (e.g., `apc260410.zip`).
  Annual backfile naming not yet confirmed — needs API query.

Estimated total download for initial backfile: **several GB compressed**, likely 10–20 GB
uncompressed across all files. This is consistent with SPEC.md's "multi-GB across many
XML files" description.

## 6. Update Cadence

- **Daily:** New/modified records published each business day as daily XML files (TRTDXFAP).
- **Annual:** Full backfile refreshed once per year covering all records through Dec 31 of
  the previous year.
- **`chktm update` strategy:** Download daily files since the last ingested date. The
  daily files contain both new applications (action-key `NA`) and modifications to existing
  records (action-key `TX`), so updates are upserts, not appends.

## 7. Gotchas and Risks

### 7.1 API Key Required (blocking for Phase 3)

Every API call to `api.uspto.gov` requires a free API key. **You need to register at
https://account.uspto.gov and generate an ODP API key before Phase 3 can run.** This is a
manual step — the user must do it themselves.

chktm should store the API key in a config file or environment variable
(`CHKTM_USPTO_API_KEY` or similar). The `chktm init` command should check for this and
give clear instructions if it's missing.

### 7.2 April 20, 2026 ODP Cutover (10 days away)

The legacy developer portal (`developer.uspto.gov`) is scheduled for shutdown on
**April 20, 2026**. We are targeting the new ODP at `data.uspto.gov` / `api.uspto.gov`
exclusively, so this is a non-issue for us — but it means:

- Any documentation or examples referencing `developer.uspto.gov` or `bulkdata.uspto.gov`
  are stale.
- The ODP is relatively new, so documentation may be incomplete or URLs may change.
- The `bulkdata.uspto.gov` domain already does not resolve as of today (April 10, 2026).

### 7.3 Two Separate API Key Systems

- **ODP API** (`api.uspto.gov`): header `X-API-Key`, for bulk data download
- **TSDR API** (`tsdrapi.uspto.gov`): header `USPTO-API-KEY`, for individual case lookup

chktm uses bulk data only (ODP), so we only need the ODP key. But this is worth
documenting so users don't get confused.

### 7.4 Rate Limits on ZIP Downloads

4 ZIP downloads per minute during business hours. For a full backfile init with potentially
dozens of ZIP files, this means:
- Naive approach: ~1 file every 15 seconds = several minutes minimum
- Must implement rate limiting and retry-on-429 in `fetch.py`
- Consider off-peak downloads (12/min) — mention in `chktm init --help`

### 7.5 Goods/Services Text Encoding

The goods/services description is split into 40-character `<text>` segments inside
`<case-file-statement>` elements. These must be:
1. Filtered to type-codes starting with `"GS"`
2. Concatenated in order
3. Associated with the correct international class (encoded in positions 3-5 of type-code)

This is the least intuitive part of the schema and the most likely place for a parsing bug.

### 7.6 Owner Name Complexity

The owner structure is complex (multiple party types, multiple name entries per type).
For chktm v0.1, we should take a pragmatic approach: use party-type `70` ("Last Listed
Owner") if present, otherwise take the last `<case-file-owner>` entry.

### 7.7 Empty/Zero Values

The DTD documentation states that empty elements use self-closing tags (e.g.,
`<foreign-applications/>`), and date fields contain zeros when no date is available.
Registration numbers are `0000000` when no registration exists. The parser must handle
these as null/None, not as actual values.

### 7.8 Annual Backfile vs. Daily for Initial Load

The optimal init strategy is:
1. Download the annual backfile (all records through Dec 31 of previous year)
2. Then download all daily files from Jan 1 of current year to today
3. This gives complete coverage without redundant processing

### 7.9 SPA Frontend Blocks Direct API Discovery

The `data.uspto.gov` web UI is an Angular SPA — all pages return the same HTML shell.
API documentation pages cannot be fetched programmatically without JavaScript execution.
This is an annoyance for tooling but doesn't affect the actual API which lives on
`api.uspto.gov`.

## 8. URLs Actually Hit During Recon

| URL | Result |
|-----|--------|
| https://data.uspto.gov | SPA shell (no useful content without JS) |
| https://data.uspto.gov/bulkdata/datasets/TRTDXFAP | SPA shell |
| https://data.uspto.gov/apis/bulk-data/download | SPA shell |
| https://api.uspto.gov/api/v1/datasets/products/TRTDXFAP | `{"message":"Missing Authentication Token"}` |
| https://api.uspto.gov/api/v1/bulk-data/product/TRTDXFAP | `{"message":"Please use the api.uspto.gov endpoint"}` |
| https://api.uspto.gov/api/v1/datasets/products/search?q=Trademark | `{"message":"Forbidden"}` (needs API key) |
| https://bulkdata.uspto.gov | DNS resolution failure (decommissioned) |
| https://www.uspto.gov/ip-policy/economic-research/research-datasets/trademark-case-files-dataset | Fetched successfully — describes CSV/DTA research dataset |
| https://www.uspto.gov/sites/default/files/products/applications-documentation.pdf | Fetched successfully — V2.0 DTD documentation (20 pages) |
| https://www.uspto.gov/sites/default/files/documents/tm-enterprise-api-user-guide-v2.pdf | Fetched successfully — TSDR API key guide with rate limits |
| https://catalog.data.gov/dataset/open-data-portal-odp-bulk-datasets-api-search-product-data-and-download | ODP API overview (endpoints, license, update frequency) |
| https://github.com/patent-dev/uspto-odp (Go client) | OpenAPI spec extracted; confirmed API patterns |
| https://raw.githubusercontent.com/patent-dev/uspto-odp/main/swagger_fixed.yaml | Full OpenAPI spec for ODP API |

## 9. Open Questions for Phase 2

1. **Annual backfile product identifier.** Is it `TRTAXMLA` or something else? Needs live
   API query with a real key.
2. **Exact file count and total size** of the annual backfile. Needs live query.
3. **Status code table.** Need to download and parse
   `Table1TrademarkStatusCodes_20250813.doc` for the definitive live/dead mapping.
4. **Actual rate limits on the new ODP.** The limits documented are from the 2020 TSDR
   guide — the ODP may differ. Check https://data.uspto.gov/apis/api-rate-limits.

## 10. Recommended Next Steps (Phase 2)

1. **User action required:** Register for an ODP API key at https://data.uspto.gov/apis/getting-started
2. Query `GET /api/v1/datasets/products/search?q=Trademark` to confirm product identifiers
3. Download one daily XML file and one annual backfile XML file as test fixtures
4. Parse them, validate the schema assumptions above
5. Build `schema.py` and `ingest.py` against real data
