# Testing the MCP Server with MCP Inspector

[MCP Inspector](https://github.com/modelcontextprotocol/inspector) is an
interactive testing tool for MCP servers. It lets you browse available tools,
call them with arguments, and inspect responses — useful for verifying chktm's
MCP integration before connecting a real AI agent.

## Prerequisites

- Node.js 22.7+ (`node --version` to check)
- chktm installed with a populated database (`chktm status` should show records)

### Installing Node.js

**Linux (Fedora/RHEL):**

```bash
dnf install nodejs
```

**Linux (Ubuntu/Debian):**

```bash
apt install nodejs npm
```

**macOS (Homebrew):**

```bash
brew install node
```

**Windows:**

Download from [nodejs.org](https://nodejs.org/) or use winget:

```powershell
winget install OpenJS.NodeJS.LTS
```

---

## Option 1: Test via Streamable HTTP (remote transport)

This is the recommended approach for testing the deployed server.

### Step 1: Start the chktm server

**Linux / macOS:**

```bash
export CHKTM_DATA_DIR="./data"
chktm serve --port 8000
```

**Windows (PowerShell):**

```powershell
$env:CHKTM_DATA_DIR = ".\data"
chktm serve --port 8000
```

You should see:

```
Starting chktm server
  Web UI:          http://0.0.0.0:8000/
  REST API:        http://0.0.0.0:8000/api/
  MCP (HTTP):      http://0.0.0.0:8000/mcp/
  MCP (SSE):       http://0.0.0.0:8000/mcp/sse/
```

### Step 2: Launch MCP Inspector

In a separate terminal:

```bash
npx @modelcontextprotocol/inspector
```

This opens the Inspector UI in your browser at `http://localhost:6274`.

### Step 3: Connect to chktm

In the Inspector UI:

1. Select transport type: **Streamable HTTP**
2. Enter the URL: `http://localhost:8000/mcp/`
3. Click **Connect**

You should see the chktm server info with version `0.1.0` and the three
available tools.

### Step 4: Test the tools

#### Test `corpus_status`

1. Click on `corpus_status` in the tools list
2. Click **Run** (no arguments needed)
3. Verify the response shows `database_exists: true` with record counts

#### Test `search_trademarks`

1. Click on `search_trademarks`
2. Enter arguments:
   - `terms`: `["test", "example"]`
   - `classes`: `[9, 41, 42]`
   - `include_dead`: `false`
3. Click **Run**
4. Verify the response includes results grouped by term with risk tiers

#### Test `generate_legal_report`

1. Click on `generate_legal_report`
2. Enter arguments:
   - `terms`: `["thundercorp", "thunder corp", "thunder-corp"]`
   - `classes`: `[9, 41, 42]`
3. Click **Run**
4. Verify the response includes `exact_search`, `component_searches` (should
   include "thunder" and "corp" as separate analyses), and `disclaimer`
5. Note: this takes longer than `search_trademarks` because it runs multiple
   queries (one per component word)

---

## Option 2: Test via SSE transport

Same as above, but use the SSE endpoint:

1. Select transport type: **SSE**
2. Enter the URL: `http://localhost:8000/mcp/sse/sse`
3. Click **Connect**

---

## Option 3: Test via stdio (local, no server needed)

This tests chktm's MCP server as a local subprocess — the way an MCP desktop
client would use it in stdio mode.

**Linux / macOS:**

```bash
npx @modelcontextprotocol/inspector \
  -e CHKTM_DATA_DIR=./data \
  python3 -m chktm.mcp_server
```

**Windows (PowerShell):**

```powershell
npx @modelcontextprotocol/inspector `
  -e CHKTM_DATA_DIR=.\data `
  python -m chktm.mcp_server
```

The Inspector spawns chktm as a child process and communicates via stdio.
The UI opens the same way — you can browse tools and run them interactively.

---

## Option 4: CLI mode (headless, for automation)

MCP Inspector can run without the web UI, useful for CI or scripting.

### List available tools

```bash
npx @modelcontextprotocol/inspector --cli \
  -e CHKTM_DATA_DIR=./data \
  python3 -m chktm.mcp_server \
  --method tools/list
```

### Call corpus_status

```bash
npx @modelcontextprotocol/inspector --cli \
  -e CHKTM_DATA_DIR=./data \
  python3 -m chktm.mcp_server \
  --method tools/call \
  --tool-name corpus_status
```

### Call search_trademarks

```bash
npx @modelcontextprotocol/inspector --cli \
  -e CHKTM_DATA_DIR=./data \
  python3 -m chktm.mcp_server \
  --method tools/call \
  --tool-name search_trademarks \
  --tool-arg 'terms=["thundercorp", "thunder corp"]' \
  --tool-arg 'classes=[9, 41, 42]'
```

---

## What to verify

When testing with MCP Inspector, check that:

| Check | Expected |
|-------|----------|
| Server connects successfully | Name: `chktm`, version: matches `chktm version` output |
| `corpus_status` returns data | `database_exists: true`, non-zero `total_marks` |
| `search_trademarks` returns results | JSON with `results`, `summary`, `disclaimer` fields |
| `generate_legal_report` returns report | JSON with `exact_search`, `component_searches`, `disclaimer` |
| Version in responses matches | `"version"` field in JSON matches the project version |
| Tool descriptions are visible | All three tools show descriptions with efficiency guidance |
| Server instructions are visible | The instructions text includes the workflow guidance |

## Exporting configuration

Once you've verified the connection works, you can export the configuration
from MCP Inspector's UI for use in other MCP clients (Cursor, VS Code, desktop
apps, etc.). Click the export button in the Inspector to get the
`mcp.json` format.

## Troubleshooting

### "Connection refused" when connecting

Make sure `chktm serve` is running and the port matches. Check that another
process isn't using port 8000:

**Linux / macOS:**

```bash
lsof -i :8000
```

**Windows (PowerShell):**

```powershell
Get-NetTCPConnection -LocalPort 8000
```

### "Database not found" in tool responses

The `CHKTM_DATA_DIR` environment variable must point to the directory containing
`chktm.db`. For the web server, set it before running `chktm serve`. For stdio
mode, pass it via `-e` to the Inspector.

### Inspector can't find Node.js

Ensure Node.js 22.7+ is installed and on your PATH. Run `node --version` to
verify.

### Tools return empty results

This is normal if your search term doesn't match any marks in the corpus. Try
a common word like `"apple"` or `"google"` to verify the search works, then
use your actual terms.
