# chktm Architecture

**Version:** 0.1.1
**Last updated:** 2026-04-12

## Overview

chktm is a Python tool that screens proposed marks against the full US trademark
corpus (USPTO bulk data). It downloads XML bulk data, ingests it into a local
SQLite database, and runs substring-match searches with risk-tier classification.

It runs as a CLI, a web application, and an MCP (Model Context Protocol) server,
deployable to OpenShift with a PVC-mounted database.

```
  Humans                    AI Agents                  AI Agents
    │                          │                          │
    ▼                          ▼                          ▼
┌────────┐          ┌──────────────────┐       ┌──────────────────┐
│  CLI   │          │   Web UI + API   │       │   MCP Server     │
│cli.py  │          │   web.py         │       │   mcp_server.py  │
│--json  │          │  GET /api/search │       │  search_trademarks│
└───┬────┘          │  GET /api/status │       │  corpus_status   │
    │               └────────┬─────────┘       └────────┬─────────┘
    │                        │                          │
    ▼                        ▼                          ▼
┌──────────────────────────────────────────────────────────────┐
│                    Core Library                               │
│  search.py (query) → report.py (render) ← schema.py (DB)    │
│  pipeline.py (threaded download+ingest orchestration)        │
│    └─ fetch.py (download) → ingest.py (parse)                │
└──────────────────────────┬───────────────────────────────────┘
                           ▼
                   data/chktm.db (SQLite + WAL)
                   (PVC in OpenShift)
```

## Module Responsibilities

### `cli.py` — Command routing and output control
- Typer application with commands: `init`, `update`, `search`, `status`, `version`, `serve`
- `--json` flag on all commands for machine-readable output (see Agent Interface)
- `--data-dir` option (default: `./data`) for database and download location
- Exit codes: 0 = success, 1 = error, 2 = no database (needs init)
- **Resumable init**: detects incomplete init (DB exists, `init_completed` not set)
  and resumes by reading already-ingested files from the `meta` table
- **Persistent config**: `init` saves data directory to `~/.config/chktm/config.toml`
  (Linux/macOS) or `%APPDATA%\chktm\config.toml` (Windows) so subsequent commands
  find the database automatically

### `config.py` — Persistent configuration
- Reads/writes `~/.config/chktm/config.toml` (XDG) or `%APPDATA%\chktm\` (Windows)
- `resolve_data_dir(flag)` — resolution order: CLI flag > env var > config > `./data`
- Written during `chktm init` with the resolved data directory path
- Minimal TOML format (key = "value" pairs, no external dependency)
- JSON progress events emitted during init/update in `--json` mode:
  ```json
  {"event":"progress","file":"apc260410.zip","records_this_file":29005,
   "total_records":14000000,"files_processed":50,"elapsed_seconds":600,
   "eta_seconds":1200}
  ```

### `fetch.py` — Data acquisition
- Downloads ZIP files from `api.uspto.gov` (ODP API)
- Handles two product types:
  - `TRTYRAP` — Annual backfile (177 files, ~22 GB, Apr 1884 – Dec 2025)
  - `TRTDXFAP` — Daily applications (one ZIP per business day)
- Filters non-ZIP files (`.doc`, `.pdf`) from product listings automatically
- Rate limiting: respects USPTO's 4 ZIP downloads/min during business hours
- Per-file retry with exponential backoff (2s, 4s, 8s) on network/server errors
- Download integrity check: file size verified against API metadata
- Resumability: tracks which files have been downloaded via the `meta` table
- Auth: reads `CHKTM_USPTO_API_KEY` from environment

### `ingest.py` — XML parsing and database loading
- Streaming parser using `defusedxml.ElementTree.iterparse`
- Memory-bounded: stack-based parent tracking with element clearing
- Batched writes (5,000 records per commit) with SQLite bulk-ingest pragmas
- Upsert semantics: `INSERT OR REPLACE` on marks, delete-then-reinsert on classes
- Extracts: serial number, registration number, wordmark, status, dates, owner,
  international classes, goods/services text

### `schema.py` — Database schema and utilities
- SQLite DDL with two main tables (`marks`, `mark_classes`) plus `meta` for state
- `normalize()` — lowercase + strip whitespace/hyphens for search matching
- `is_live()` — status code → live/dead determination (range-based heuristic)
- `bulk_ingest_mode()` — context manager for tuned SQLite writes
  (`synchronous=NORMAL`, 64 MB cache). Commits any open transaction before
  changing PRAGMAs to avoid "Safety level may not be changed inside a transaction"
- `busy_timeout` set on all connections: 30s for writes (init/update), 5s for
  reads (web/MCP). Waits for locks instead of failing immediately.
- Date and registration number parsing with null handling for zero-filled values

### `pipeline.py` — Pipelined download + ingest with resilience
- Producer/consumer pattern using `threading.Thread` and `queue.Queue`
- Download thread (producer): fetches ZIPs respecting USPTO rate limits
- Main thread (consumer): extracts XML and ingests into SQLite concurrently
- Overlaps ~8s ingest time with ~16s rate-limit wait (~20-25% faster)
- **Off-peak mode** (`--off-peak`): 5.5s rate limit vs 16s (~3x faster)
- **Streaming ingest** (`--stream-ingest`): pipes ZIP → XML parser without disk I/O
- **Retry**: per-file retry with exponential backoff on network/server errors
- **Integrity check**: downloaded file size verified against API metadata
- **Corrupt ZIP handling**: `BadZipFile` caught, file deleted, pipeline continues
- **Graceful shutdown**: SIGINT/SIGTERM finishes current file, commits, exits
- **WAL checkpoint**: consolidates SQLite WAL file after completion
- **Disk space check**: verifies free space before starting init
- ZIP files deleted after successful ingestion by default (`--keep-zips` to retain)
- JSON progress events in `--json` mode; ETA in Rich progress bar
- Used by both `chktm init` and `chktm update`

### `search.py` — Query engine
- Normalized substring matching against `wordmark_normalized`
- Phonetic matching via Soundex (`wordmark_soundex`) using `jellyfish` library
  — catches sound-alike marks that substring matching misses
- Combined query: substring OR soundex match in a single SQL statement
- Class filtering via `mark_classes` join (batch-fetched, no N+1)
- Risk tier assignment: HIGH (live + match + class overlap), MEDIUM (live + match),
  LOW (dead + match)

### `report.py` — Output rendering
- **Standard report:** Markdown or JSON grouped by risk tier
- **Legal report** (`--report legal`): attorney-ready format with:
  - Executive summary with clear pass/fail indicator
  - Exact search results table
  - Component analysis (auto-searches individual words from compound terms)
  - HIGH-risk matches grouped by owner (identifies concentrated ownership)
  - Limitations section (what the tool doesn't cover)
  - Recommended next steps (professional search, filing strategy, costs)
- **PDF output** via `fpdf2`: professional layout with tables, color-coded risk
  tiers, and section headings. Auto-detected from `.pdf` file extension on `--out`
- Disclaimer appended to every report

### `web.py` — FastAPI web application
- `GET /` — Lightweight search form (inline HTML, no static file dependencies)
- `GET /api/status` — Corpus status as JSON
- `GET /api/search?q=<terms>&classes=<list>&include_dead=<bool>` — Search API
- `GET /docs` — Interactive API reference (Swagger UI, auto-generated)
- `GET /redoc` — API reference (ReDoc, auto-generated)
- `GET /openapi.json` — OpenAPI 3.x specification
- XSS-safe: all dynamic content escaped via DOM `textContent`
- Security headers: CSP, HSTS, X-Frame-Options, Cache-Control, Referrer-Policy
- Input validation: class range (1-45), query length, term count

### `mcp_server.py` — MCP (Model Context Protocol) server
- `search_trademarks` tool — search with terms, classes, include_dead parameters
- `generate_legal_report` tool — attorney-ready report with automatic component analysis
- `compare_searches` tool — diff two search runs for monitoring changes over time
- `corpus_status` tool — check database state and freshness
- Transports: stdio (local), SSE (`/mcp/sse/`), Streamable HTTP (`/mcp/`)
- `create_app()` mounts MCP transports onto the FastAPI app for combined serving
- Rich tool descriptions with parameter documentation for agent comprehension

### `disclaimer.py` — Legal disclaimer text
- Single source of truth imported by CLI help, reports, MCP instructions, and README

## Data Flow

### `chktm init` / `chktm update` (pipelined)
```
┌─ Download thread ────────────────┐   ┌─ Main thread ──────────────────┐
│                                  │   │                                │
│  USPTO API → fetch.py → ZIP N   │──▶│  extract ZIP N-1 → ingest.py  │
│  (rate-limited: 16s between)     │   │  → SQLite DB → delete ZIP N-1 │
│                                  │   │                                │
│  While ingesting N-1,            │   │  (overlapped execution saves   │
│  downloads N in parallel         │   │   ~8s per file)                │
└──────────────────────────────────┘   └────────────────────────────────┘
                    │
                    ▼
        queue.Queue (max 2 items)
```

- `init`: downloads annual backfile (TRTYRAP, 177 files) + daily files (TRTDXFAP)
- `update`: downloads only daily files since `last_update_date` in meta table
- ZIPs deleted after ingestion by default; `--keep-zips` retains them
- Resumable: skips files already on disk or tracked in the meta table

### `chktm search`
```
user query → normalize() → SQL LIKE on wordmark_normalized
           → join mark_classes for class filter
           → risk tier assignment
           → report.py (Markdown or JSON)
```

## Database Schema

```sql
marks (
    serial_number       TEXT PRIMARY KEY,
    registration_number TEXT,           -- NULL if unregistered
    wordmark            TEXT NOT NULL,
    wordmark_normalized TEXT NOT NULL,   -- lowercase, no spaces/hyphens
    status_code         TEXT,
    is_live             INTEGER NOT NULL, -- 0 or 1
    filing_date         TEXT,            -- YYYY-MM-DD or NULL
    registration_date   TEXT,            -- YYYY-MM-DD or NULL
    mark_drawing_code   TEXT,            -- 1=typeset, 4=standard char, etc.
    owner_name          TEXT,
    goods_services      TEXT             -- concatenated GS statements
)

mark_classes (
    serial_number TEXT NOT NULL,
    intl_class    INTEGER NOT NULL,
    PRIMARY KEY (serial_number, intl_class)
)

meta (key TEXT PRIMARY KEY, value TEXT)  -- schema_version, last_update_date, etc.
```

**Indexes:** `wordmark_normalized`, `is_live`, `intl_class`

## Security Model

- **XML parsing:** `defusedxml` blocks entity expansion, external entities, and DTD
  retrieval. The trust boundary is the USPTO API over HTTPS — we don't parse
  user-supplied XML.
- **SQL:** All queries use parameterized statements (`?` placeholders). The only
  dynamic SQL is the batched `DELETE ... WHERE serial_number IN (?)` in ingest,
  which uses parameter binding per chunk.
- **API key:** Read from `CHKTM_USPTO_API_KEY` env var. Never logged or included
  in output. Never committed to the repository.
- **Network:** Outbound HTTPS only, to `api.uspto.gov`. No listening sockets.

## AI Agent Interface

chktm is designed to be consumable by AI agents and automation tools:

### Structured output (`--json`)
Every command supports `--json` for machine-readable output. The JSON schema is
stable within a major version.

### Exit codes
| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (details in stderr or JSON `error` field) |
| 2 | Database not initialized (run `chktm init` first) |

### JSON output schemas

**`chktm search --json`**
```json
{
  "version": "0.1.0",
  "timestamp": "2026-04-11T12:00:00Z",
  "query": {
    "terms": ["thundercorp"],
    "classes": [9, 41, 42],
    "include_dead": false
  },
  "corpus": {
    "total_marks": 12700000,
    "last_updated": "2026-04-10"
  },
  "results": [
    {
      "term": "thundercorp",
      "risk": "HIGH",
      "matches": [
        {
          "serial_number": "...",
          "registration_number": "...",
          "wordmark": "...",
          "status_code": "...",
          "is_live": true,
          "filing_date": "...",
          "registration_date": "...",
          "owner_name": "...",
          "classes": [9, 41],
          "goods_services": "...",
          "tsdr_url": "https://tsdr.uspto.gov/#caseNumber=...&caseType=SERIAL_NO"
        }
      ]
    }
  ],
  "summary": {
    "high": 0,
    "medium": 0,
    "low": 0
  }
}
```

**`chktm status --json`**
```json
{
  "version": "0.1.0",
  "database_exists": true,
  "total_marks": 12700000,
  "live_marks": 5000000,
  "dead_marks": 7700000,
  "last_updated": "2026-04-10",
  "coverage": {
    "from": "1884-04-07",
    "to": "2026-04-10"
  },
  "db_size_bytes": 4500000000
}
```

### Composability

Agents can:
1. Check readiness: `chktm status --json` → parse `database_exists`
2. Initialize if needed: `chktm init --data-dir /path`
3. Search programmatically: `chktm search term --json --classes 9,41`
4. Parse results: structured JSON with stable field names
5. Update corpus: `chktm update --json` → monitor progress

### Environment

| Variable | Required | Purpose |
|----------|----------|---------|
| `CHKTM_USPTO_API_KEY` | Yes (for init/update) | USPTO Open Data Portal API key |
| `CHKTM_DATA_DIR` | No | Override data directory (also saved to config file during init) |

## Deployment Architecture (OpenShift)

```
┌─────────────────────────────────────────────────────────┐
│                    OpenShift Cluster                      │
│                                                          │
│  ┌──────────────┐   ┌──────────────┐   ┌─────────────┐ │
│  │  Route (TLS) │──▶│   Service    │──▶│ Deployment  │ │
│  │  /           │   │  :8000       │   │ chktm serve │ │
│  │  /api/*      │   │              │   │ (web + MCP) │ │
│  │  /mcp/*      │   └──────────────┘   └──────┬──────┘ │
│  └──────────────┘                             │        │
│                                               ▼        │
│                                     ┌─────────────────┐ │
│  ┌──────────────┐                   │   PVC (10 Gi)   │ │
│  │  CronJob     │──────────────────▶│   /data/        │ │
│  │chktm update  │                   │   chktm.db      │ │
│  │ M-F 6am EST  │                   │   zips/         │ │
│  └──────────────┘                   └─────────────────┘ │
│                                                          │
│  ┌──────────────┐                                       │
│  │  Job (init)  │──────────────────▶ (same PVC)         │
│  │ chktm init   │                                       │
│  └──────────────┘                                       │
│                                                          │
│  ┌──────────────┐                                       │
│  │   Secret     │  CHKTM_USPTO_API_KEY                  │
│  │chktm-api-key │  (used by init + update only)         │
│  └──────────────┘                                       │
└─────────────────────────────────────────────────────────┘
```

**Container image:** `quay.io/<namespace>/chktm:latest`
**Base image:** `python:3.12-slim` (multi-stage build)
**User:** Arbitrary UID, GID 0 (OpenShift `restricted` SCC compatible)
**Security:** `readOnlyRootFilesystem`, `drop: ALL` capabilities,
`runAsNonRoot`, `seccompProfile: RuntimeDefault`, no SA token mount

## Testing

128 tests across 10 test modules, all running without network access:

| Module | Tests | Coverage |
|--------|-------|----------|
| `test_schema.py` | 16 | Normalization, phonetic codes, status codes, date parsing |
| `test_ingest.py` | 10 | XML parsing edge cases, owner logic, class extraction, upsert |
| `test_search.py` | 12 | Risk tiers, filtering, normalization, phonetic, corpus stats |
| `test_report.py` | 15 | Markdown/JSON rendering, disclaimer, version |
| `test_config.py` | 7 | Config read/write, resolve precedence (flag > env > config > default) |
| `test_diff.py` | 9 | New/removed/changed marks, legal format, Markdown/JSON rendering |
| `test_fetch.py` | 7 | ZIP extraction, streaming, corrupt handling, disk space checks |
| `test_web.py` | 11 | API endpoints, input validation, all 5 security headers |
| `test_cli.py` | 15 | All CLI commands (version, status, search, init, diff) |
| `test_mcp.py` | 10 | All 4 MCP tools, server metadata, missing DB handling |

CI runs the test suite on Ubuntu, Windows, macOS (Python 3.11–3.13) and
Fedora 42/43 containers — 11 configurations total.

## Extension Points

- **New matching strategies:** Add to `search.py` (e.g., phonetic matching,
  Levenshtein distance). The normalized column provides the baseline; additional
  columns or virtual tables can support richer matching.
- **Additional data sources:** The `ingest.py` parser is specific to USPTO XML V2.x.
  New jurisdiction parsers would implement the same `ingest_xml(source, conn)`
  interface.
- **Output formats:** `report.py` can be extended with new renderers (HTML, CSV)
  alongside Markdown and JSON.
- **Database backend:** The schema is simple enough to port to DuckDB or PostgreSQL
  if SQLite becomes a bottleneck at scale. The `schema.py` module isolates all DDL.
