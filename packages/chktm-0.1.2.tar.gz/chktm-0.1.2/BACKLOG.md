# Backlog

Items explicitly deferred from v0.1. These are not bugs — they are conscious
scope boundaries. PRs for these items should open an issue for discussion first.

## Search improvements

- **N-gram similarity** — Character n-gram matching for broader fuzzy recall
  beyond the current Levenshtein + Soundex approach
- **Advanced phonetic matching** — Double Metaphone or phonetic n-grams for
  higher recall than the current Soundex (which covers most cases)
- **Weighting/scoring** — More nuanced risk scoring beyond the current three-tier
  system (exact match weight, prefix match, class distance)

## Data sources

- **Multi-jurisdiction** — EU (EUIPO), UK (IPO), WIPO Madrid Protocol, Canada
  (CIPO). Each has its own bulk data format.
- **Common-law usage checks** — Search Steam, itch.io, GitHub, app stores for
  unregistered marks in the same space
- **TSDR real-time lookup** — Query `tsdrapi.uspto.gov` for individual case
  details and most recent filings (different API, different key)

## Distribution

- **Homebrew formula** — For macOS users
- **Container image signing** — Sign images with cosign/sigstore before pushing

## Web UI

- **Saved searches** — Persist search queries for monitoring over time
- **Authentication** — OAuth proxy or basic auth for the web UI and MCP endpoints

## Infrastructure

- **Helm chart** — Parameterized OpenShift/Kubernetes deployment
- **SBOM in release artifacts** — CycloneDX JSON is generated in CI; consider
  attaching to GitHub releases automatically (partially done)
- **Database backend alternatives** — PostgreSQL or DuckDB for multi-replica
  deployments where SQLite's single-writer limitation is a problem

## Agent integration

- **MCP authentication** — Token-based auth for the MCP endpoints
- **Batch monitoring** — MCP tool to search a large watchlist of terms on a
  schedule and report only new/changed results since last check
- **Monitoring tool** — MCP tool to set up alerts when new marks are filed that
  match a watched term

## Documentation

No outstanding documentation items. Man page at `docs/chktm.1`, API reference
at `/docs` (Swagger UI) and `/redoc` (ReDoc) are included in v0.1.
