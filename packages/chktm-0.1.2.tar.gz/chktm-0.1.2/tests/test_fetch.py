# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import zipfile
from pathlib import Path

import pytest

from chktm.fetch import RemoteFile, check_disk_space, extract_zip, stream_extract_zip


@pytest.fixture()
def sample_zip(tmp_path: Path) -> Path:
    """Create a test ZIP with an XML file inside."""
    zip_path = tmp_path / "test.zip"
    xml_content = '<?xml version="1.0"?><root><item>test</item></root>'
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("test.xml", xml_content)
        zf.writestr("readme.txt", "not xml")
    return zip_path


@pytest.fixture()
def corrupt_zip(tmp_path: Path) -> Path:
    """Create a corrupt ZIP file."""
    path = tmp_path / "corrupt.zip"
    path.write_bytes(b"this is not a zip file")
    return path


class TestExtractZip:
    def test_extracts_xml_only(self, sample_zip: Path, tmp_path: Path):
        dest = tmp_path / "extracted"
        files = extract_zip(sample_zip, dest)
        assert len(files) == 1
        assert files[0].name == "test.xml"
        assert files[0].exists()

    def test_skips_non_xml(self, sample_zip: Path, tmp_path: Path):
        dest = tmp_path / "extracted"
        files = extract_zip(sample_zip, dest)
        names = [f.name for f in files]
        assert "readme.txt" not in names

    def test_corrupt_zip_returns_empty(self, corrupt_zip: Path, tmp_path: Path):
        dest = tmp_path / "extracted"
        files = extract_zip(corrupt_zip, dest)
        assert files == []
        # Corrupt file should be deleted
        assert not corrupt_zip.exists()


class TestStreamExtractZip:
    def test_streams_xml(self, sample_zip: Path):
        count = 0
        for name, fobj in stream_extract_zip(sample_zip):
            assert name == "test.xml"
            content = fobj.read()
            assert b"<root>" in content
            count += 1
        assert count == 1

    def test_corrupt_zip_yields_nothing(self, corrupt_zip: Path):
        entries = list(stream_extract_zip(corrupt_zip))
        assert entries == []


class TestCheckDiskSpace:
    def test_sufficient_space(self, tmp_path: Path):
        # Should not raise — tmp always has some space
        check_disk_space(tmp_path, 1024)

    def test_insufficient_space(self, tmp_path: Path):
        with pytest.raises(RuntimeError, match="Insufficient disk space"):
            check_disk_space(tmp_path, 10**18)  # 1 exabyte

    def test_creates_directory(self, tmp_path: Path):
        new_dir = tmp_path / "new" / "nested"
        check_disk_space(new_dir, 1024)
        assert new_dir.exists()


class TestRemoteFile:
    def test_dataclass(self):
        rf = RemoteFile(
            file_name="test.zip",
            file_size=1000,
            download_uri="https://example.com/test.zip",
            from_date="2026-01-01",
            to_date="2026-01-01",
        )
        assert rf.file_name == "test.zip"
        assert rf.file_size == 1000
