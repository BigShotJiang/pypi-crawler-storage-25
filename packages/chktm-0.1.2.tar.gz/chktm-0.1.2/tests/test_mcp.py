# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest

from chktm.ingest import ingest_file

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture()
def mcp_db(tmp_path: Path, monkeypatch):
    """Set up a database and point the MCP server at it."""
    db_path = tmp_path / "chktm.db"
    ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
    conn = sqlite3.connect(str(db_path))
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('last_update_date', '2026-04-10')")
    conn.commit()
    conn.close()

    monkeypatch.setattr("chktm.mcp_server._DATA_DIR", tmp_path)
    return tmp_path


class TestSearchTrademarks:
    def test_basic_search(self, mcp_db):
        from chktm.mcp_server import search_trademarks

        result = json.loads(search_trademarks(terms=["testmark"], classes=[9]))
        assert result["summary"]["high"] >= 1

    def test_no_results(self, mcp_db):
        from chktm.mcp_server import search_trademarks

        result = json.loads(search_trademarks(terms=["xyznonexistent"]))
        assert result["summary"]["high"] == 0
        assert result["summary"]["medium"] == 0

    def test_multiple_terms(self, mcp_db):
        from chktm.mcp_server import search_trademarks

        result = json.loads(search_trademarks(terms=["testmark", "deadmark"], include_dead=True))
        assert len(result["results"]) == 2

    def test_includes_disclaimer(self, mcp_db):
        from chktm.mcp_server import search_trademarks

        result = json.loads(search_trademarks(terms=["testmark"]))
        assert "disclaimer" in result
        assert "research aid" in result["disclaimer"]


class TestCorpusStatus:
    def test_returns_status(self, mcp_db):
        from chktm.mcp_server import corpus_status

        result = json.loads(corpus_status())
        assert result["database_exists"] is True
        assert result["total_marks"] == 4
        assert result["last_updated"] == "2026-04-10"

    def test_missing_db(self, tmp_path: Path, monkeypatch):
        monkeypatch.setattr("chktm.mcp_server._DATA_DIR", tmp_path / "empty")
        from chktm.mcp_server import corpus_status

        result = json.loads(corpus_status())
        assert result["database_exists"] is False


class TestGenerateLegalReport:
    def test_returns_legal_report(self, mcp_db):
        from chktm.mcp_server import generate_legal_report

        result = json.loads(generate_legal_report(terms=["testmark"], classes=[9]))
        assert result["report_type"] == "legal"
        assert "exact_search" in result
        assert "component_searches" in result
        assert "disclaimer" in result

    def test_component_analysis(self, mcp_db):
        from chktm.mcp_server import generate_legal_report

        # "testmark" should decompose into components
        result = json.loads(generate_legal_report(terms=["testmark alpha"]))
        # Components extracted from multi-word input
        assert "component_searches" in result


class TestCompareSearches:
    def test_diff_no_changes(self, mcp_db):
        from chktm.mcp_server import compare_searches, search_trademarks

        old = search_trademarks(terms=["testmark"], classes=[9])
        result = json.loads(compare_searches(old_report_json=old, terms=["testmark"], classes=[9]))
        assert result["report_type"] == "diff"
        # Same search against same DB — no changes expected
        for d in result["diffs"]:
            assert len(d["new_marks"]) == 0
            assert len(d["removed_marks"]) == 0


class TestMCPServerMetadata:
    def test_version_set(self, mcp_db):
        from chktm import __version__
        from chktm.mcp_server import mcp

        assert mcp._mcp_server.version == __version__

    def test_server_name(self, mcp_db):
        from chktm.mcp_server import mcp

        assert mcp.name == "chktm"
