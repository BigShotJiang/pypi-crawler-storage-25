# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json

from chktm.diff import diff_reports, render_diff_json, render_diff_markdown


def _make_report(term: str, matches: list[dict]) -> dict:
    return {
        "timestamp": "2026-04-12T00:00:00+00:00",
        "results": [{"term": term, "matches": matches}],
    }


def _make_match(serial: str, wordmark: str, risk: str = "HIGH") -> dict:
    return {
        "serial_number": serial,
        "wordmark": wordmark,
        "risk": risk,
        "is_live": True,
        "owner_name": "Test Owner",
        "classes": [9],
        "tsdr_url": f"https://tsdr.uspto.gov/#caseNumber={serial}&caseType=SERIAL_NO",
    }


class TestDiffReports:
    def test_no_changes(self):
        old = _make_report("test", [_make_match("001", "TESTMARK")])
        new = _make_report("test", [_make_match("001", "TESTMARK")])
        diffs = diff_reports(old, new)
        assert len(diffs) == 1
        assert not diffs[0].has_changes

    def test_new_mark(self):
        old = _make_report("test", [_make_match("001", "TESTMARK")])
        new = _make_report("test", [_make_match("001", "TESTMARK"), _make_match("002", "NEWMARK")])
        diffs = diff_reports(old, new)
        assert len(diffs[0].new_marks) == 1
        assert diffs[0].new_marks[0].serial_number == "002"

    def test_removed_mark(self):
        old = _make_report("test", [_make_match("001", "TESTMARK"), _make_match("002", "GONE")])
        new = _make_report("test", [_make_match("001", "TESTMARK")])
        diffs = diff_reports(old, new)
        assert len(diffs[0].removed_marks) == 1
        assert diffs[0].removed_marks[0].serial_number == "002"

    def test_risk_changed(self):
        old = _make_report("test", [_make_match("001", "TESTMARK", "MEDIUM")])
        new = _make_report("test", [_make_match("001", "TESTMARK", "HIGH")])
        diffs = diff_reports(old, new)
        assert len(diffs[0].risk_changed) == 1
        assert diffs[0].risk_changed[0].old_risk == "MEDIUM"
        assert diffs[0].risk_changed[0].new_risk == "HIGH"

    def test_empty_reports(self):
        old = _make_report("test", [])
        new = _make_report("test", [])
        diffs = diff_reports(old, new)
        assert not diffs[0].has_changes

    def test_handles_legal_report_format(self):
        old = {
            "timestamp": "2026-04-12T00:00:00+00:00",
            "exact_search": {"results": [{"term": "test", "matches": [_make_match("001", "MARK")]}]},
        }
        new = {
            "timestamp": "2026-04-12T01:00:00+00:00",
            "exact_search": {"results": [{"term": "test", "matches": []}]},
        }
        diffs = diff_reports(old, new)
        assert len(diffs[0].removed_marks) == 1


class TestDiffRendering:
    def test_markdown_no_changes(self):
        old = _make_report("test", [_make_match("001", "SAME")])
        new = _make_report("test", [_make_match("001", "SAME")])
        diffs = diff_reports(old, new)
        md = render_diff_markdown(diffs)
        assert "No changes detected" in md

    def test_markdown_with_changes(self):
        old = _make_report("test", [])
        new = _make_report("test", [_make_match("001", "NEWMARK")])
        diffs = diff_reports(old, new)
        md = render_diff_markdown(diffs)
        assert "New marks" in md
        assert "NEWMARK" in md

    def test_json_valid(self):
        old = _make_report("test", [_make_match("001", "A")])
        new = _make_report("test", [_make_match("002", "B")])
        diffs = diff_reports(old, new)
        raw = render_diff_json(diffs)
        data = json.loads(raw)
        assert data["report_type"] == "diff"
        assert len(data["diffs"]) == 1
        assert len(data["diffs"][0]["new_marks"]) == 1
        assert len(data["diffs"][0]["removed_marks"]) == 1
