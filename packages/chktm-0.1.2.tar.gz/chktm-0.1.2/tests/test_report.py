# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest

from chktm.disclaimer import DISCLAIMER
from chktm.ingest import ingest_file
from chktm.report import render_json, render_markdown
from chktm.search import search

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture()
def db(tmp_path: Path) -> sqlite3.Connection:
    db_path = tmp_path / "test.db"
    ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
    conn = sqlite3.connect(str(db_path))
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('last_update_date', '2026-04-10')")
    conn.commit()
    yield conn
    conn.close()


class TestMarkdownReport:
    def test_contains_header(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        md = render_markdown(result)
        assert "# chktm report" in md

    def test_contains_disclaimer(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        md = render_markdown(result)
        assert DISCLAIMER in md

    def test_contains_term_section(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        md = render_markdown(result)
        assert "## Term: testmark" in md

    def test_high_risk_section(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        md = render_markdown(result)
        assert "### HIGH risk (1)" in md
        assert "TESTMARK ALPHA" in md

    def test_medium_section_when_no_class_overlap(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[35])
        md = render_markdown(result)
        assert "### HIGH risk (0)" in md
        assert "### MEDIUM risk (1)" in md

    def test_dead_suppressed_by_default(self, db: sqlite3.Connection):
        result = search(db, ["deadmark"], classes=[42])
        md = render_markdown(result)
        assert "LOW" not in md or "suppressed" in md

    def test_dead_shown_with_include_dead(self, db: sqlite3.Connection):
        result = search(db, ["deadmark"], classes=[42], include_dead=True)
        md = render_markdown(result)
        assert "### LOW risk (1)" in md
        assert "DEADMARK BETA" in md

    def test_contains_tsdr_link(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        md = render_markdown(result)
        assert "tsdr.uspto.gov" in md

    def test_contains_summary(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        md = render_markdown(result)
        assert "Found: 1 HIGH" in md


class TestJsonReport:
    def test_valid_json(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        raw = render_json(result)
        data = json.loads(raw)
        assert isinstance(data, dict)

    def test_json_structure(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        data = json.loads(render_json(result))
        from chktm import __version__

        assert data["version"] == __version__
        assert "timestamp" in data
        assert data["query"]["terms"] == ["testmark"]
        assert data["query"]["classes"] == [9]
        assert "corpus" in data
        assert "results" in data
        assert "summary" in data
        assert "disclaimer" in data

    def test_json_matches(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        data = json.loads(render_json(result))
        matches = data["results"][0]["matches"]
        assert len(matches) == 1
        m = matches[0]
        assert m["wordmark"] == "TESTMARK ALPHA"
        assert m["risk"] == "HIGH"
        assert m["is_live"] is True
        assert m["serial_number"] == "99000001"
        assert "tsdr_url" in m

    def test_json_summary_counts(self, db: sqlite3.Connection):
        result = search(db, ["testmark", "deadmark"], classes=[9], include_dead=True)
        data = json.loads(render_json(result))
        assert data["summary"]["high"] == 1
        assert data["summary"]["low"] == 1

    def test_json_dead_excluded_by_default(self, db: sqlite3.Connection):
        result = search(db, ["deadmark"], classes=[42])
        data = json.loads(render_json(result))
        assert data["results"][0]["matches"] == []

    def test_json_disclaimer_present(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        data = json.loads(render_json(result))
        assert "research aid" in data["disclaimer"]
