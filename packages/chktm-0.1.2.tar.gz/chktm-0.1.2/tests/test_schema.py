# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from chktm.schema import (
    is_live,
    normalize,
    parse_date,
    parse_registration_number,
    phonetic_code,
)


class TestNormalize:
    def test_lowercase(self):
        assert normalize("HELLO") == "hello"

    def test_strip_whitespace(self):
        assert normalize("Hella Energy") == "hellaenergy"

    def test_strip_hyphens(self):
        assert normalize("hella-energy") == "hellaenergy"

    def test_combined(self):
        assert normalize("HELLA - ENERGY") == "hellaenergy"

    def test_empty(self):
        assert normalize("") == ""


class TestPhoneticCode:
    def test_basic(self):
        assert phonetic_code("thundercorp") == phonetic_code("thundrcorp")

    def test_case_insensitive(self):
        assert phonetic_code("THUNDER") == phonetic_code("thunder")

    def test_hyphens_stripped(self):
        assert phonetic_code("thunder-corp") == phonetic_code("thundercorp")

    def test_empty(self):
        assert phonetic_code("") == ""

    def test_different_words_differ(self):
        assert phonetic_code("apple") != phonetic_code("thunder")


class TestIsLive:
    def test_live_status_codes(self):
        # Codes from official Table 1 that are Live
        for code in ("630", "700", "800", "650", "680", "686", "688"):
            assert is_live(code) is True, f"Expected {code} to be live"

    def test_dead_abandoned(self):
        for code in ("600", "602", "606", "618"):
            assert is_live(code) is False, f"Expected {code} to be dead"

    def test_dead_cancelled(self):
        for code in ("400", "710", "711", "781"):
            assert is_live(code) is False, f"Expected {code} to be dead"

    def test_dead_expired(self):
        for code in ("900", "901"):
            assert is_live(code) is False, f"Expected {code} to be dead"

    def test_unknown_code_defaults_live(self):
        # Codes not in the table default to live (conservative)
        assert is_live("999") is True
        assert is_live("100") is True

    def test_none_defaults_live(self):
        assert is_live(None) is True

    def test_empty_defaults_live(self):
        assert is_live("") is True


class TestParseDate:
    def test_normal_date(self):
        assert parse_date("20200115") == "2020-01-15"

    def test_zeros(self):
        assert parse_date("00000000") is None

    def test_none(self):
        assert parse_date(None) is None

    def test_empty(self):
        assert parse_date("") is None


class TestParseRegistrationNumber:
    def test_normal(self):
        assert parse_registration_number("1234567") == "1234567"

    def test_zeros(self):
        assert parse_registration_number("0000000") is None

    def test_none(self):
        assert parse_registration_number(None) is None
