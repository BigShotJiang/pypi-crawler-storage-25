# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest
from typer.testing import CliRunner

from chktm.cli import app
from chktm.ingest import ingest_file

FIXTURES = Path(__file__).parent / "fixtures"
runner = CliRunner()


@pytest.fixture()
def db_dir(tmp_path: Path) -> Path:
    """Create a data dir with a populated database."""
    db_path = tmp_path / "chktm.db"
    ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
    conn = sqlite3.connect(str(db_path))
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('last_update_date', '2026-04-10')")
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('init_completed', 'true')")
    conn.commit()
    conn.close()
    return tmp_path


class TestVersion:
    def test_version_text(self):
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert "chktm" in result.stdout

    def test_version_json(self):
        result = runner.invoke(app, ["version", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        from chktm import __version__

        assert data["version"] == __version__


class TestStatus:
    def test_status_no_db(self, tmp_path: Path):
        result = runner.invoke(app, ["status", "--data-dir", str(tmp_path), "--json"])
        assert result.exit_code == 2
        data = json.loads(result.stdout)
        assert data["database_exists"] is False

    def test_status_with_db(self, db_dir: Path):
        result = runner.invoke(app, ["status", "--data-dir", str(db_dir), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["database_exists"] is True
        assert data["total_marks"] == 4


class TestSearch:
    def test_search_no_db(self, tmp_path: Path):
        result = runner.invoke(app, ["search", "test", "--data-dir", str(tmp_path), "--json"])
        assert result.exit_code == 2

    def test_search_basic(self, db_dir: Path):
        result = runner.invoke(app, ["search", "testmark", "--data-dir", str(db_dir)])
        assert result.exit_code == 0
        assert "TESTMARK ALPHA" in result.stdout

    def test_search_json(self, db_dir: Path):
        result = runner.invoke(app, ["search", "testmark", "--data-dir", str(db_dir), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["summary"]["high"] >= 1

    def test_search_no_results(self, db_dir: Path):
        result = runner.invoke(app, ["search", "xyznonexistent", "--data-dir", str(db_dir), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["summary"]["high"] == 0

    def test_search_legal_report(self, db_dir: Path):
        result = runner.invoke(app, ["search", "testmark", "--data-dir", str(db_dir), "--report", "legal"])
        assert result.exit_code == 0
        assert "Executive Summary" in result.stdout

    def test_search_out_file(self, db_dir: Path, tmp_path: Path):
        out = tmp_path / "report.md"
        result = runner.invoke(app, ["search", "testmark", "--data-dir", str(db_dir), "--out", str(out)])
        assert result.exit_code == 0
        assert out.exists()
        assert "TESTMARK" in out.read_text()

    def test_search_invalid_classes(self, db_dir: Path):
        result = runner.invoke(app, ["search", "test", "--data-dir", str(db_dir), "--classes", "abc", "--json"])
        assert result.exit_code == 1


class TestInit:
    def test_init_refuses_existing_db(self, db_dir: Path):
        result = runner.invoke(app, ["init", "--data-dir", str(db_dir), "--json"])
        assert result.exit_code == 1
        data = json.loads(result.stdout)
        assert "already exists" in data["error"].lower()

    def test_init_detects_incomplete(self, db_dir: Path):
        """Verify that an incomplete DB (no init_completed flag) is detected.

        We test the detection logic directly rather than running init (which
        would try to contact the USPTO API).
        """
        conn = sqlite3.connect(str(db_dir / "chktm.db"))
        conn.execute("DELETE FROM meta WHERE key = 'init_completed'")
        conn.commit()

        # Verify the flag is gone
        row = conn.execute("SELECT value FROM meta WHERE key = 'init_completed'").fetchone()
        assert row is None

        # Verify the DB still has data (incomplete, not empty)
        count = conn.execute("SELECT COUNT(*) FROM marks").fetchone()[0]
        assert count > 0
        conn.close()


class TestDiff:
    def test_diff_missing_file(self, db_dir: Path):
        result = runner.invoke(app, ["diff", "/nonexistent.json", "test", "--data-dir", str(db_dir), "--json"])
        assert result.exit_code == 1

    def test_diff_basic(self, db_dir: Path, tmp_path: Path):
        # First search to get a baseline
        search_result = runner.invoke(app, ["search", "testmark", "--data-dir", str(db_dir), "--json"])
        old_report = tmp_path / "old.json"
        old_report.write_text(search_result.stdout)

        # Run diff
        result = runner.invoke(app, ["diff", str(old_report), "testmark", "--data-dir", str(db_dir), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["report_type"] == "diff"
