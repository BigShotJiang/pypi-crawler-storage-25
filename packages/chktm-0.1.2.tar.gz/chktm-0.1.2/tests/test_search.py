# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from chktm.ingest import ingest_file
from chktm.search import Risk, search

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture()
def db(tmp_path: Path) -> sqlite3.Connection:
    """Ingest edge-case fixture and return an open connection."""
    db_path = tmp_path / "test.db"
    ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
    conn = sqlite3.connect(str(db_path))
    # Set a fake last_update_date for corpus metadata.
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('last_update_date', '2026-04-10')")
    conn.commit()
    yield conn
    conn.close()


class TestSearch:
    def test_exact_match_high_risk(self, db: sqlite3.Connection):
        """TESTMARK ALPHA is live, in classes 9 and 41 — should be HIGH."""
        result = search(db, ["testmark"], classes=[9, 41, 42])
        assert len(result.term_results) == 1
        tr = result.term_results[0]
        high = tr.high
        assert len(high) == 1
        assert high[0].wordmark == "TESTMARK ALPHA"
        assert high[0].risk == Risk.HIGH
        assert high[0].is_live is True
        assert 9 in high[0].classes

    def test_match_medium_risk_no_class_overlap(self, db: sqlite3.Connection):
        """TESTMARK ALPHA in classes 9,41 — searching with class 35 should be MEDIUM."""
        result = search(db, ["testmark"], classes=[35])
        tr = result.term_results[0]
        assert len(tr.high) == 0
        assert len(tr.medium) == 1
        assert tr.medium[0].wordmark == "TESTMARK ALPHA"
        assert tr.medium[0].risk == Risk.MEDIUM

    def test_dead_marks_excluded_by_default(self, db: sqlite3.Connection):
        """DEADMARK BETA (status 602) should not appear without --include-dead."""
        result = search(db, ["deadmark"], classes=[42])
        tr = result.term_results[0]
        assert len(tr.matches) == 0

    def test_dead_marks_included(self, db: sqlite3.Connection):
        """DEADMARK BETA appears as LOW when include_dead=True."""
        result = search(db, ["deadmark"], classes=[42], include_dead=True)
        tr = result.term_results[0]
        assert len(tr.low) == 1
        assert tr.low[0].risk == Risk.LOW
        assert tr.low[0].is_live is False

    def test_expired_marks_are_dead(self, db: sqlite3.Connection):
        """EXPIREDMARK GAMMA (status 900) should be LOW."""
        result = search(db, ["expiredmark"], classes=[35], include_dead=True)
        tr = result.term_results[0]
        assert len(tr.low) == 1
        assert tr.low[0].status_code == "900"

    def test_no_match(self, db: sqlite3.Connection):
        """A term that matches nothing returns zero results."""
        result = search(db, ["xyznonexistent"], classes=[9])
        tr = result.term_results[0]
        assert len(tr.matches) == 0

    def test_multiple_terms(self, db: sqlite3.Connection):
        """Multiple terms each get their own TermResult."""
        result = search(db, ["testmark", "deadmark"], classes=[9], include_dead=True)
        assert len(result.term_results) == 2
        assert result.term_results[0].term == "testmark"
        assert result.term_results[1].term == "deadmark"

    def test_normalization_case_insensitive(self, db: sqlite3.Connection):
        """Search is case-insensitive via normalization."""
        result = search(db, ["TESTMARK"], classes=[9])
        assert len(result.term_results[0].high) == 1

    def test_normalization_strips_hyphens(self, db: sqlite3.Connection):
        """Search normalizes hyphens: 'test-mark' matches 'TESTMARK ALPHA'."""
        result = search(db, ["test-mark"], classes=[9])
        assert len(result.term_results[0].high) == 1

    def test_summary_counts(self, db: sqlite3.Connection):
        result = search(db, ["testmark", "deadmark"], classes=[9], include_dead=True)
        assert result.total_high == 1
        assert result.total_medium == 0
        assert result.total_low == 1

    def test_tsdr_url(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        match = result.term_results[0].high[0]
        assert "99000001" in match.tsdr_url
        assert "SERIAL_NO" in match.tsdr_url

    def test_corpus_stats(self, db: sqlite3.Connection):
        result = search(db, ["testmark"], classes=[9])
        # 2 live marks in fixture: TESTMARK ALPHA (700) and empty wordmark (200)
        assert result.total_active_marks == 2
        assert result.corpus_last_updated == "2026-04-10"
