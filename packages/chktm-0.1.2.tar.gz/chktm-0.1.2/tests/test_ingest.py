# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from chktm.ingest import ingest_file

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture()
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "test.db"


class TestIngestEdgeCases:
    def test_record_count(self, db_path: Path):
        count = ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        assert count == 4

    def test_live_mark(self, db_path: Path):
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM marks WHERE serial_number = '99000001'").fetchone()
        assert row is not None
        assert row["wordmark"] == "TESTMARK ALPHA"
        assert row["wordmark_normalized"] == "testmarkalpha"
        assert row["is_live"] == 1
        assert row["status_code"] == "700"
        assert row["filing_date"] == "2020-01-15"
        assert row["registration_date"] == "2021-06-01"
        assert row["registration_number"] == "1234567"
        assert row["mark_drawing_code"] == "4"
        conn.close()

    def test_owner_highest_party_type(self, db_path: Path):
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        conn = sqlite3.connect(str(db_path))
        row = conn.execute("SELECT owner_name FROM marks WHERE serial_number = '99000001'").fetchone()
        # party-type 30 > 10, so "Current Owner LLC" should be selected
        assert row[0] == "Current Owner LLC"
        conn.close()

    def test_classes_extracted(self, db_path: Path):
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        conn = sqlite3.connect(str(db_path))
        classes = conn.execute(
            "SELECT intl_class FROM mark_classes WHERE serial_number = '99000001' ORDER BY intl_class"
        ).fetchall()
        assert [r[0] for r in classes] == [9, 41]
        conn.close()

    def test_goods_services_filter(self, db_path: Path):
        """GS qualifier '2' (less-goods) should be skipped."""
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        conn = sqlite3.connect(str(db_path))
        row = conn.execute("SELECT goods_services FROM marks WHERE serial_number = '99000001'").fetchone()
        gs = row[0]
        assert "Computer software for gaming" in gs
        assert "Entertainment services" in gs
        assert "Less goods text" not in gs
        conn.close()

    def test_dead_mark(self, db_path: Path):
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        conn = sqlite3.connect(str(db_path))
        row = conn.execute(
            "SELECT is_live, registration_number, registration_date FROM marks WHERE serial_number = '99000002'"
        ).fetchone()
        assert row[0] == 0  # is_live
        assert row[1] is None  # registration_number (was 0000000)
        assert row[2] is None  # registration_date (was 00000000)
        conn.close()

    def test_expired_mark(self, db_path: Path):
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        conn = sqlite3.connect(str(db_path))
        row = conn.execute("SELECT is_live, status_code FROM marks WHERE serial_number = '99000004'").fetchone()
        assert row[0] == 0  # is_live (status 900)
        assert row[1] == "900"
        conn.close()

    def test_empty_wordmark_still_ingested(self, db_path: Path):
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        conn = sqlite3.connect(str(db_path))
        row = conn.execute("SELECT wordmark FROM marks WHERE serial_number = '99000003'").fetchone()
        assert row is not None
        assert row[0] == ""
        conn.close()

    def test_upsert_replaces_existing(self, db_path: Path):
        """Ingesting the same file twice should not duplicate records."""
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)
        conn = sqlite3.connect(str(db_path))
        count = conn.execute("SELECT COUNT(*) FROM marks").fetchone()[0]
        assert count == 4
        conn.close()


class TestIngestRealData:
    """Tests against the fixture extracted from a real daily file."""

    def test_ingest_sample_daily(self, db_path: Path):
        fixture = FIXTURES / "sample_daily.xml"
        if not fixture.exists():
            pytest.skip("sample_daily.xml fixture not available")
        count = ingest_file(fixture, db_path)
        assert count == 5

        conn = sqlite3.connect(str(db_path))
        # Every record should have a serial number and at least one class
        serials = conn.execute("SELECT serial_number FROM marks").fetchall()
        assert len(serials) == 5
        class_count = conn.execute("SELECT COUNT(DISTINCT serial_number) FROM mark_classes").fetchone()[0]
        assert class_count >= 1
        conn.close()
