# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from pathlib import Path

from chktm.config import read_config, resolve_data_dir, write_config


class TestConfig:
    def test_write_and_read(self, tmp_path: Path, monkeypatch):
        config_dir = tmp_path / "config"
        monkeypatch.setattr("chktm.config._config_dir", lambda: config_dir)
        write_config({"data_dir": "/some/path"})
        config = read_config()
        assert config["data_dir"] == "/some/path"

    def test_read_missing_file(self, tmp_path: Path, monkeypatch):
        config_dir = tmp_path / "nonexistent"
        monkeypatch.setattr("chktm.config._config_dir", lambda: config_dir)
        config = read_config()
        assert config == {}

    def test_write_preserves_existing(self, tmp_path: Path, monkeypatch):
        config_dir = tmp_path / "config"
        monkeypatch.setattr("chktm.config._config_dir", lambda: config_dir)
        write_config({"key1": "val1"})
        write_config({"key2": "val2"})
        config = read_config()
        assert config["key1"] == "val1"
        assert config["key2"] == "val2"

    def test_resolve_flag_wins(self):
        result = resolve_data_dir(Path("/explicit"))
        assert result == Path("/explicit")

    def test_resolve_env_var(self, monkeypatch):
        monkeypatch.setenv("CHKTM_DATA_DIR", "/from/env")
        result = resolve_data_dir(None)
        assert result == Path("/from/env")

    def test_resolve_config_file(self, tmp_path: Path, monkeypatch):
        config_dir = tmp_path / "config"
        monkeypatch.setattr("chktm.config._config_dir", lambda: config_dir)
        monkeypatch.delenv("CHKTM_DATA_DIR", raising=False)
        write_config({"data_dir": "/from/config"})
        result = resolve_data_dir(None)
        assert result == Path("/from/config")

    def test_resolve_default(self, monkeypatch):
        monkeypatch.delenv("CHKTM_DATA_DIR", raising=False)
        monkeypatch.setattr("chktm.config._config_dir", lambda: Path("/nonexistent"))
        result = resolve_data_dir(None)
        assert result == Path("./data")
