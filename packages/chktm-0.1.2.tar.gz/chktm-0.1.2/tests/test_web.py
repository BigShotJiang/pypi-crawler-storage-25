# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from chktm.ingest import ingest_file

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture()
def app_client(tmp_path: Path, monkeypatch):
    """Create a test client with a real database."""
    db_path = tmp_path / "chktm.db"
    ingest_file(FIXTURES / "sample_edge_cases.xml", db_path)

    # Set last_update_date in meta
    conn = sqlite3.connect(str(db_path))
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('last_update_date', '2026-04-10')")
    conn.commit()
    conn.close()

    monkeypatch.setattr("chktm.web._DATA_DIR", tmp_path)

    from chktm.web import app

    return TestClient(app)


class TestWebIndex:
    def test_returns_html(self, app_client):
        resp = app_client.get("/")
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
        assert "chktm" in resp.text

    def test_has_search_form(self, app_client):
        resp = app_client.get("/")
        assert '<input type="text" id="q"' in resp.text

    def test_has_disclaimer(self, app_client):
        resp = app_client.get("/")
        assert "research aid" in resp.text


class TestWebStatus:
    def test_returns_json(self, app_client):
        resp = app_client.get("/api/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["database_exists"] is True
        assert data["total_marks"] == 4

    def test_includes_version(self, app_client):
        from chktm import __version__

        resp = app_client.get("/api/status")
        assert resp.json()["version"] == __version__


class TestWebSearch:
    def test_basic_search(self, app_client):
        resp = app_client.get("/api/search?q=testmark")
        assert resp.status_code == 200
        data = resp.json()
        assert "results" in data
        assert "summary" in data

    def test_no_query(self, app_client):
        resp = app_client.get("/api/search?q=")
        assert resp.status_code == 400

    def test_query_too_long(self, app_client):
        resp = app_client.get(f"/api/search?q={'x' * 501}")
        assert resp.status_code == 400
        assert "too long" in resp.json()["error"].lower()

    def test_invalid_classes(self, app_client):
        resp = app_client.get("/api/search?q=test&classes=abc")
        assert resp.status_code == 400

    def test_class_range_validation(self, app_client):
        resp = app_client.get("/api/search?q=test&classes=99")
        assert resp.status_code == 400
        assert "1 and 45" in resp.json()["error"]

    def test_too_many_terms(self, app_client):
        terms = " ".join(f"term{i}" for i in range(21))
        resp = app_client.get(f"/api/search?q={terms}")
        assert resp.status_code == 400


class TestSecurityHeaders:
    def test_csp(self, app_client):
        resp = app_client.get("/")
        assert "Content-Security-Policy" in resp.headers

    def test_hsts(self, app_client):
        resp = app_client.get("/")
        assert "Strict-Transport-Security" in resp.headers

    def test_x_frame_options(self, app_client):
        resp = app_client.get("/")
        assert resp.headers["X-Frame-Options"] == "DENY"

    def test_cache_control(self, app_client):
        resp = app_client.get("/api/status")
        assert "no-store" in resp.headers.get("Cache-Control", "")

    def test_content_type_nosniff(self, app_client):
        resp = app_client.get("/")
        assert resp.headers["X-Content-Type-Options"] == "nosniff"
