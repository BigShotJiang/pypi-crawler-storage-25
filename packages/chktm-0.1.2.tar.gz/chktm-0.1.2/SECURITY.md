# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in chktm, please report it responsibly
by opening a [GitHub Security Advisory](https://github.com/nickschuetz/chktm/security/advisories/new)
or emailing the maintainer directly. Do not open a public issue for security
vulnerabilities.

We aim to acknowledge reports within 48 hours and provide a fix or mitigation
within 7 days for critical issues.

## Threat Model

### What chktm does

chktm downloads public trademark data from the USPTO, stores it in a local
SQLite database, and provides search access via CLI, web API, and MCP protocol.

### Trust boundaries

```
Internet (USPTO API)  ──HTTPS──▶  chktm fetch  ──▶  Local SQLite DB
                                                            │
User (CLI / Browser / AI Agent)  ──────────────────────────▶│
```

| Boundary | Trust level | Controls |
|----------|-------------|----------|
| USPTO API → chktm | Trusted data source | HTTPS, defusedxml for XML parsing |
| User → CLI | Local user, trusted | Standard OS permissions |
| User → Web API | Untrusted input | Input validation, parameterized SQL, security headers |
| AI Agent → MCP | Untrusted input | Same validation as web API |

### What is NOT in scope

- chktm does not process user-uploaded files
- chktm does not execute user-supplied code
- chktm does not store user credentials (only the USPTO API key in env vars)
- chktm does not authenticate users (deploy behind an OAuth proxy if needed)

## OWASP Compliance

Controls mapped to [OWASP Top 10 (2021)](https://owasp.org/Top10/):

### A01:2021 — Broken Access Control

- **Status:** Not applicable for v0.1.
- chktm serves public USPTO data with no per-user access control.
- The web UI and MCP endpoints have no authentication. Deploy behind a network
  policy or OAuth proxy (e.g., OpenShift OAuth Proxy) if access restriction is
  needed.
- The `X-Frame-Options: DENY` header prevents clickjacking.

### A02:2021 — Cryptographic Failures

- **Status:** Not applicable.
- chktm does not store passwords, tokens, or sensitive personal data.
- The USPTO API key is read from an environment variable and never logged,
  committed, or included in responses.
- TLS is enforced at the OpenShift Route level (edge termination with redirect).

### A03:2021 — Injection

- **Status:** Mitigated.
- **SQL injection:** All queries use parameterized statements (`?` placeholders).
  No string interpolation in SQL. The one dynamic SQL pattern (batched `DELETE
  ... WHERE IN`) uses parameter binding per chunk.
- **SQL LIKE wildcards:** User search terms are escaped (`%` → `\%`, `_` → `\_`)
  with `ESCAPE '\'` to prevent unintended pattern matching.
- **XML injection:** `defusedxml` blocks entity expansion (billion laughs),
  external entity injection (XXE), and DTD retrieval. The trust boundary is
  USPTO over HTTPS — no user-supplied XML is ever parsed.
- **Command injection:** Not applicable — chktm does not execute shell commands
  with user input.

### A04:2021 — Insecure Design

- **Status:** Mitigated.
- Search query length capped at 500 characters.
- Maximum 20 terms per search, 45 classes per query.
- Individual search terms truncated at 200 characters after normalization.
- SQL result sets capped at 1,000 rows per term via `LIMIT`.
- The MCP server inherits the same validation via the shared `search()` function.

### A05:2021 — Security Misconfiguration

- **Status:** Mitigated.
- Security headers on all responses:
  - `Content-Security-Policy`: `default-src 'self'`, inline scripts/styles
    allowed (needed for the single-page search UI), no external resources.
  - `X-Content-Type-Options: nosniff`
  - `X-Frame-Options: DENY`
  - `Referrer-Policy: strict-origin-when-cross-origin`
  - `Permissions-Policy`: camera, microphone, geolocation disabled.
- Container compatible with OpenShift `restricted` SCC:
  - Runs as non-root with arbitrary UID (GID 0 / root group)
  - `allowPrivilegeEscalation: false` on all containers
  - `readOnlyRootFilesystem: true` — writable dirs via emptyDir (`/tmp`)
  - `capabilities.drop: [ALL]` — no Linux capabilities
  - `seccompProfile: RuntimeDefault` at pod level
  - `automountServiceAccountToken: false` — no SA token exposure
  - Service account token not mounted (minimizes attack surface)
- Database PVC mounted read-only in the server deployment (read-write
  only for init/update jobs).

### A06:2021 — Vulnerable and Outdated Components

- **Status:** Tracked.
- All dependencies listed in `SBOM.md` with versions and licenses.
- All dependencies use permissive licenses compatible with Apache-2.0.
- Dependency updates should be monitored via Dependabot or similar.

### A07:2021 — Identification and Authentication Failures

- **Status:** Not applicable for v0.1.
- chktm has no user accounts or authentication. All data served is public.
- For restricted deployments, use an external auth proxy.

### A08:2021 — Software and Data Integrity Failures

- **Status:** Mitigated.
- No external CDN scripts (no SRI needed) — all JavaScript is inline.
- Container images should be signed and scanned before deployment (recommended
  but not enforced by chktm itself).
- Data integrity relies on USPTO as the authoritative source over HTTPS.
- **Download integrity:** file sizes verified after download against API metadata.
  Mismatches trigger delete and automatic retry.
- **Corrupt data handling:** `BadZipFile` exceptions caught during extraction;
  corrupt files are deleted and skipped without crashing the pipeline.
- **Graceful shutdown:** SIGINT/SIGTERM handlers finish the current file and
  commit to the database before exiting, preventing partial-write corruption.
- **WAL checkpoint:** consolidates the write-ahead log after bulk operations,
  ensuring the database file is self-contained.

### A09:2021 — Security Logging and Monitoring Failures

- **Status:** Partially mitigated.
- uvicorn logs all HTTP requests to stdout (captured by OpenShift logging).
- `fetch.py` and `pipeline.py` use Python `logging` for download retries,
  corrupt file warnings, and shutdown events.
- JSON progress events emitted in `--json` mode for container/CI monitoring.
- No application-level audit logging in v0.1. Backlog item for v0.2.

### A10:2021 — Server-Side Request Forgery (SSRF)

- **Status:** Not applicable.
- chktm makes outbound requests only to `api.uspto.gov` (hardcoded base URL).
- No user input is used to construct outbound request URLs.

## Dependencies

See [SBOM.md](SBOM.md) for the full dependency inventory with versions and
licenses.
