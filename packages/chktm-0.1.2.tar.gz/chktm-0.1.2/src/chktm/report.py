# SPDX-License-Identifier: Apache-2.0
"""Report rendering: Markdown, JSON, and PDF output for search results."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from chktm import __version__
from chktm.disclaimer import DISCLAIMER
from chktm.search import LegalReport, Match, Risk, SearchResult


def _truncate(text: str | None, max_len: int = 200) -> str:
    """Truncate text with ellipsis if needed."""
    if not text:
        return ""
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


def _match_to_md(match: Match) -> str:
    """Render a single match as Markdown."""
    reg = match.registration_number or "none"
    reg_date = match.registration_date or "none"
    classes = ", ".join(str(c) for c in match.classes) or "none"
    gs = _truncate(match.goods_services)

    lines = [
        f"#### {match.wordmark or '(no wordmark)'}",
        f"- Serial: {match.serial_number}  | Registration: {reg}",
        f"- Status: {match.status_code} — {match.status_label} ({'live' if match.is_live else 'dead'})",
        f"- Filed: {match.filing_date or 'unknown'}  | Registered: {reg_date}",
        f"- Owner: {match.owner_name or 'unknown'}",
        f"- Classes: {classes}",
        f"- Goods/services: {gs}",
        f"- USPTO link: {match.tsdr_url}",
    ]
    return "\n".join(lines)


def _match_to_dict(match: Match) -> dict[str, Any]:
    """Convert a match to a JSON-serializable dict."""
    return {
        "serial_number": match.serial_number,
        "registration_number": match.registration_number,
        "wordmark": match.wordmark,
        "status_code": match.status_code,
        "status_label": match.status_label,
        "is_live": match.is_live,
        "filing_date": match.filing_date,
        "registration_date": match.registration_date,
        "mark_drawing_code": match.mark_drawing_code,
        "owner_name": match.owner_name,
        "classes": match.classes,
        "goods_services": match.goods_services,
        "risk": match.risk.value,
        "tsdr_url": match.tsdr_url,
    }


def render_markdown(result: SearchResult) -> str:
    """Render search results as a Markdown report."""
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    classes_str = ", ".join(str(c) for c in result.filter_classes)
    terms_str = ", ".join(result.terms)

    lines = [
        "# chktm report",
        "",
        f"Generated: {now}",
        f"Corpus last updated: {result.corpus_last_updated or 'unknown'}",
        f"Search terms: {terms_str}",
        f"Class filter: {classes_str}",
        f"Total active marks in corpus: {result.total_active_marks:,}",
        "",
        "## Summary",
        "",
        f"Searched {len(result.terms)} term(s) against {result.total_active_marks:,} active marks.",
    ]

    if result.include_dead:
        lines.append(f"Found: {result.total_high} HIGH, {result.total_medium} MEDIUM, {result.total_low} LOW")
    else:
        lines.append(
            f"Found: {result.total_high} HIGH, {result.total_medium} MEDIUM, "
            f"{result.total_low} LOW (suppressed — pass --include-dead to show)"
        )

    for tr in result.term_results:
        lines.append("")
        lines.append(f"## Term: {tr.term}")

        for tier, label in [
            (Risk.HIGH, "HIGH"),
            (Risk.MEDIUM, "MEDIUM"),
            (Risk.LOW, "LOW"),
        ]:
            matches = [m for m in tr.matches if m.risk == tier]
            if tier == Risk.LOW and not result.include_dead:
                continue
            lines.append("")
            lines.append(f"### {label} risk ({len(matches)})")
            if not matches:
                lines.append("")
                lines.append("No matches.")
            else:
                for match in matches:
                    lines.append("")
                    lines.append(_match_to_md(match))

    lines.extend(
        [
            "",
            "## Disclaimer",
            "",
            DISCLAIMER,
            "",
        ]
    )

    return "\n".join(lines)


def render_json(result: SearchResult) -> str:
    """Render search results as JSON."""
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")

    data = {
        "version": __version__,
        "timestamp": now,
        "query": {
            "terms": result.terms,
            "classes": result.filter_classes,
            "include_dead": result.include_dead,
        },
        "corpus": {
            "total_marks": result.total_active_marks,
            "last_updated": result.corpus_last_updated,
        },
        "results": [],
        "summary": {
            "high": result.total_high,
            "medium": result.total_medium,
            "low": result.total_low,
        },
        "disclaimer": DISCLAIMER,
    }

    for tr in result.term_results:
        term_data: dict[str, Any] = {"term": tr.term, "matches": []}
        for match in tr.matches:
            if match.risk == Risk.LOW and not result.include_dead:
                continue
            term_data["matches"].append(_match_to_dict(match))
        data["results"].append(term_data)

    return json.dumps(data, indent=2, default=str)


# --- Legal report rendering ---


def _group_by_owner(matches: list[Match]) -> dict[str, list[Match]]:
    """Group matches by owner name for the legal report."""
    groups: dict[str, list[Match]] = {}
    for m in matches:
        key = m.owner_name or "Unknown"
        groups.setdefault(key, []).append(m)
    return dict(sorted(groups.items()))


def render_legal_markdown(report: LegalReport) -> str:
    """Render a legal-ready trademark screening report as Markdown."""
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    classes_str = ", ".join(str(c) for c in report.intended_classes)

    lines = [
        f"# Trademark Screening Report: {report.proposed_mark.upper()}",
        "",
        f"**Date:** {now}",
        f"**Tool:** chktm v{__version__} (USPTO bulk data screening)",
        f"**Corpus:** {report.corpus_total:,} marks ({report.corpus_live:,} live)"
        f" as of {report.corpus_date or 'unknown'}",
        "",
        "---",
        "",
        f"**{DISCLAIMER}**",
        "",
        "---",
        "",
        "## 1. Executive Summary",
        "",
        f"**Proposed mark:** {report.proposed_mark.upper()}",
        f"**Intended classes:** {classes_str}",
        "",
    ]

    exact = report.exact_search
    total_exact = exact.total_high + exact.total_medium + exact.total_low

    if total_exact == 0:
        lines.append("### Result: No exact matches found.")
        lines.append("")
        lines.append(
            "No existing US trademark registrations or pending applications "
            "match any variant of the proposed mark as a substring in the full "
            "USPTO corpus."
        )
    else:
        lines.append(
            f"### Result: {exact.total_high} HIGH, {exact.total_medium} MEDIUM, {exact.total_low} LOW matches found."
        )
        lines.append("")
        if exact.total_high > 0:
            lines.append(
                "**Potential conflicts identified.** Review the HIGH-risk matches below carefully with your attorney."
            )
        else:
            lines.append(
                "No marks in the same classes match exactly, but MEDIUM-risk matches in other classes were found."
            )

    if report.component_searches:
        total_component = sum(sr.total_high + sr.total_medium for sr in report.component_searches.values())
        if total_component > 0:
            lines.append("")
            lines.append(
                f"**Component analysis:** Broader searches on individual word "
                f"components identified {total_component} live matches that "
                f"a trademark examiner could potentially cite. See Section 3."
            )

    # Section 2: Exact search results
    lines.extend(
        [
            "",
            "## 2. Exact Search Results",
            "",
            "| Search Term | HIGH | MEDIUM | LOW | Total |",
            "|-------------|------|--------|-----|-------|",
        ]
    )
    for tr in exact.term_results:
        h = len(tr.high)
        m = len(tr.medium)
        lo = len(tr.low)
        lines.append(f"| {tr.term} | {h} | {m} | {lo} | {h + m + lo} |")

    if total_exact > 0:
        lines.append("")
        for tr in exact.term_results:
            if not tr.matches:
                continue
            lines.append(f"### Term: {tr.term}")
            lines.append("")
            for match in tr.matches:
                lines.append(_match_to_md(match))
                lines.append("")
    else:
        lines.append("")
        lines.append(
            "**Interpretation:** No identical or substantially similar marks "
            "exist in the USPTO database for any variant of the proposed mark."
        )

    # Section 3: Component analysis
    if report.component_searches:
        lines.extend(
            [
                "",
                "## 3. Component Analysis",
                "",
                "The following broader searches were run on individual word "
                "components of the proposed mark to identify marks that a trademark "
                "examiner or opposer could potentially cite.",
                "",
            ]
        )
        for component, sr in report.component_searches.items():
            total_c = sr.total_high + sr.total_medium + sr.total_low
            lines.append(f'### Component: "{component}" ({total_c} total matches, {sr.total_high} HIGH)')
            lines.append("")

            if sr.total_high == 0 and sr.total_medium == 0:
                lines.append("No live matches in the target classes.")
                lines.append("")
                continue

            # Group HIGH matches by owner to identify concentrated ownership
            high_matches = []
            for tr in sr.term_results:
                high_matches.extend(tr.high)

            if high_matches:
                owner_groups = _group_by_owner(high_matches)

                # Show owners with multiple registrations first (more significant)
                for owner, marks in sorted(owner_groups.items(), key=lambda x: -len(x[1])):
                    if len(marks) >= 2:
                        lines.append(f"**{owner}** ({len(marks)} registrations):")
                        lines.append("")
                        lines.append("| Serial | Mark | Classes | Goods/Services |")
                        lines.append("|--------|------|---------|----------------|")
                        for m in marks:
                            gs = _truncate(m.goods_services, 80)
                            cls = ", ".join(str(c) for c in m.classes)
                            lines.append(f"| {m.serial_number} | {m.wordmark} | {cls} | {gs} |")
                        lines.append("")

                # Show single-registration owners as a summary table
                singles = [m for owner, marks in owner_groups.items() if len(marks) == 1 for m in marks]
                if singles:
                    lines.append(f"**Other HIGH-risk marks** ({len(singles)}):")
                    lines.append("")
                    lines.append("| Serial | Mark | Owner | Classes |")
                    lines.append("|--------|------|-------|---------|")
                    for m in singles[:25]:  # Cap at 25 to keep report readable
                        cls = ", ".join(str(c) for c in m.classes)
                        lines.append(f"| {m.serial_number} | {m.wordmark} | {m.owner_name or 'Unknown'} | {cls} |")
                    if len(singles) > 25:
                        lines.append(f"| ... | *{len(singles) - 25} more* | | |")
                    lines.append("")

    # Section 4: Limitations
    lines.extend(
        [
            "",
            "## 4. Limitations",
            "",
            "1. **Substring matching only.** No phonetic, visual, or conceptual similarity analysis.",
            "2. **US federal only.** State registrations, common-law marks, and "
            "international registrations not covered.",
            "3. **Bulk data lag.** Data may trail the live USPTO TSDR system by 1-3 days.",
            "4. **No design mark analysis.** Image/logo marks are not searched.",
            "5. **No likelihood-of-confusion analysis.** Risk tiers are based on "
            "text matching and class overlap only, not the multi-factor DuPont test.",
            "",
        ]
    )

    # Section 5: Recommended next steps
    lines.extend(
        [
            "## 5. Recommended Next Steps",
            "",
            "1. **Review high-risk matches** with a trademark attorney, focusing "
            "on goods/services overlap and the strength of existing marks.",
            "2. **Run a comprehensive professional search** (e.g., Thomson CompuMark, "
            "Corsearch) covering phonetic matching, design marks, common-law sources, "
            "and international databases.",
            "3. **Check tmsearch.uspto.gov** for filings in the last 1-3 days not yet in the bulk data.",
            "4. **Consider filing strategy** if clearance is given:",
            f"   - Classes: {classes_str}",
            "   - Filing basis: Section 1(b) Intent to Use or Section 1(a) Use in Commerce",
            "   - Filing method: TEAS Plus ($250/class) or TEAS Standard ($350/class)",
            "   - An attorney can draft goods/services descriptions with appropriate scope.",
            "",
        ]
    )

    # Disclaimer
    lines.extend(
        [
            "---",
            "",
            f"*Generated by chktm v{__version__}. {DISCLAIMER}*",
            "",
        ]
    )

    return "\n".join(lines)


def render_legal_json(report: LegalReport) -> str:
    """Render a legal report as JSON."""
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")

    data: dict[str, Any] = {
        "version": __version__,
        "report_type": "legal",
        "timestamp": now,
        "proposed_mark": report.proposed_mark,
        "intended_classes": report.intended_classes,
        "corpus": {
            "total_marks": report.corpus_total,
            "live_marks": report.corpus_live,
            "last_updated": report.corpus_date,
        },
        "exact_search": {
            "terms": report.exact_search.terms,
            "summary": {
                "high": report.exact_search.total_high,
                "medium": report.exact_search.total_medium,
                "low": report.exact_search.total_low,
            },
            "results": [],
        },
        "component_searches": {},
        "disclaimer": DISCLAIMER,
    }

    for tr in report.exact_search.term_results:
        term_data = {
            "term": tr.term,
            "matches": [_match_to_dict(m) for m in tr.matches],
        }
        data["exact_search"]["results"].append(term_data)

    for component, sr in report.component_searches.items():
        comp_data: dict[str, Any] = {
            "summary": {
                "high": sr.total_high,
                "medium": sr.total_medium,
                "low": sr.total_low,
            },
            "high_matches": [],
        }
        for tr in sr.term_results:
            for m in tr.high:
                d = _match_to_dict(m)
                # Truncate goods_services to reduce token usage in MCP responses.
                d["goods_services"] = _truncate(d.get("goods_services"), 100)
                comp_data["high_matches"].append(d)
        data["component_searches"][component] = comp_data

    return json.dumps(data, indent=2, default=str)


# --- PDF rendering ---


def render_legal_pdf(report: LegalReport, output_path: str) -> None:
    """Render a legal report as a professional PDF document.

    Args:
        report: The legal report data.
        output_path: File path to write the PDF to.
    """
    from fpdf import FPDF

    now = datetime.now(timezone.utc).strftime("%B %d, %Y")
    classes_str = ", ".join(str(c) for c in report.intended_classes)

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=20)

    # --- Page 1: Title and Executive Summary ---
    pdf.add_page()

    # Title
    pdf.set_font("Helvetica", "B", 20)
    pdf.cell(0, 12, "Trademark Screening Report", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 14)
    pdf.cell(0, 8, report.proposed_mark.upper(), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    # Metadata
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(0, 5, f"Date: {now}", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(
        0,
        5,
        f"Corpus: {report.corpus_total:,} marks ({report.corpus_live:,} live) as of {report.corpus_date or 'unknown'}",
        new_x="LMARGIN",
        new_y="NEXT",
    )
    pdf.cell(0, 5, f"Tool: chktm v{__version__}", new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(0, 0, 0)
    pdf.ln(4)

    # Disclaimer box
    pdf.set_fill_color(255, 243, 205)
    pdf.set_font("Helvetica", "I", 8)
    pdf.multi_cell(0, 4, DISCLAIMER, fill=True)
    pdf.ln(6)

    # Executive Summary
    _pdf_heading(pdf, "1. Executive Summary")

    pdf.set_font("Helvetica", "B", 10)
    pdf.cell(35, 6, "Proposed mark:")
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 6, report.proposed_mark.upper(), new_x="LMARGIN", new_y="NEXT")

    pdf.set_font("Helvetica", "B", 10)
    pdf.cell(35, 6, "Intended classes:")
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 6, classes_str, new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    exact = report.exact_search
    total_exact = exact.total_high + exact.total_medium + exact.total_low

    if total_exact == 0:
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_text_color(0, 128, 0)
        pdf.cell(0, 7, "Result: No exact matches found.", new_x="LMARGIN", new_y="NEXT")
        pdf.set_text_color(0, 0, 0)
        pdf.set_font("Helvetica", "", 10)
        pdf.multi_cell(
            0,
            5,
            "No existing US trademark registrations or pending applications "
            "match any variant of the proposed mark in the full USPTO corpus.",
        )
    else:
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_text_color(200, 0, 0)
        pdf.cell(
            0,
            7,
            f"Result: {exact.total_high} HIGH, {exact.total_medium} MEDIUM, {exact.total_low} LOW matches found.",
            new_x="LMARGIN",
            new_y="NEXT",
        )
        pdf.set_text_color(0, 0, 0)

    if report.component_searches:
        total_comp = sum(sr.total_high + sr.total_medium for sr in report.component_searches.values())
        if total_comp > 0:
            pdf.ln(3)
            pdf.set_font("Helvetica", "", 10)
            pdf.multi_cell(
                0,
                5,
                f"Component analysis: Broader searches on individual word "
                f"components identified {total_comp} live matches that a "
                f"trademark examiner could potentially cite. See Section 3.",
            )
    pdf.ln(4)

    # --- Section 2: Exact Search Results ---
    _pdf_heading(pdf, "2. Exact Search Results")

    col_widths = [50, 20, 25, 20, 20]
    headers = ["Search Term", "HIGH", "MEDIUM", "LOW", "Total"]
    _pdf_table_header(pdf, headers, col_widths)

    for tr in exact.term_results:
        h, m, lo = len(tr.high), len(tr.medium), len(tr.low)
        _pdf_table_row(pdf, [tr.term, str(h), str(m), str(lo), str(h + m + lo)], col_widths)
    pdf.ln(4)

    if total_exact > 0:
        for tr in exact.term_results:
            for match in tr.matches:
                _pdf_match(pdf, match)
    else:
        pdf.set_font("Helvetica", "", 10)
        pdf.multi_cell(
            0,
            5,
            "No identical or substantially similar marks exist in the USPTO "
            "database for any variant of the proposed mark.",
        )
    pdf.ln(4)

    # --- Section 3: Component Analysis ---
    if report.component_searches:
        _pdf_heading(pdf, "3. Component Analysis")
        pdf.set_font("Helvetica", "", 10)
        pdf.multi_cell(
            0,
            5,
            "Broader searches on individual word components to identify marks "
            "a trademark examiner or opposer could potentially cite.",
        )
        pdf.ln(4)

        for component, sr in report.component_searches.items():
            total_c = sr.total_high + sr.total_medium + sr.total_low
            pdf.set_font("Helvetica", "B", 11)
            pdf.cell(
                0,
                7,
                f'Component: "{component}" ({total_c} total, {sr.total_high} HIGH)',
                new_x="LMARGIN",
                new_y="NEXT",
            )

            high_matches: list[Match] = []
            for tr in sr.term_results:
                high_matches.extend(tr.high)

            if not high_matches:
                pdf.set_font("Helvetica", "I", 9)
                pdf.cell(0, 5, "No HIGH-risk matches.", new_x="LMARGIN", new_y="NEXT")
                pdf.ln(4)
                continue

            owner_groups = _group_by_owner(high_matches)

            for owner, marks in sorted(owner_groups.items(), key=lambda x: -len(x[1])):
                if len(marks) < 2:
                    continue
                pdf.set_font("Helvetica", "B", 9)
                pdf.cell(
                    0,
                    6,
                    f"{owner} ({len(marks)} registrations):",
                    new_x="LMARGIN",
                    new_y="NEXT",
                )
                cw = [25, 45, 25, 75]
                _pdf_table_header(pdf, ["Serial", "Mark", "Classes", "Goods/Services"], cw)
                for m_ in marks:
                    gs = _truncate(m_.goods_services, 60)
                    cls = ", ".join(str(c) for c in m_.classes)
                    _pdf_table_row(pdf, [m_.serial_number, m_.wordmark, cls, gs], cw)
                pdf.ln(3)

            singles = [m_ for owner, marks in owner_groups.items() if len(marks) == 1 for m_ in marks]
            if singles:
                pdf.set_font("Helvetica", "B", 9)
                pdf.cell(
                    0,
                    6,
                    f"Other HIGH-risk marks ({len(singles)}):",
                    new_x="LMARGIN",
                    new_y="NEXT",
                )
                cw = [25, 40, 55, 25]
                _pdf_table_header(pdf, ["Serial", "Mark", "Owner", "Classes"], cw)
                for m_ in singles[:30]:
                    cls = ", ".join(str(c) for c in m_.classes)
                    _pdf_table_row(
                        pdf,
                        [m_.serial_number, m_.wordmark, m_.owner_name or "?", cls],
                        cw,
                    )
                if len(singles) > 30:
                    pdf.set_font("Helvetica", "I", 8)
                    pdf.cell(
                        0,
                        5,
                        f"... and {len(singles) - 30} more",
                        new_x="LMARGIN",
                        new_y="NEXT",
                    )
                pdf.ln(4)

    # --- Section 4: Limitations ---
    _pdf_heading(pdf, "4. Limitations")
    limitations = [
        "Substring matching only. No phonetic, visual, or conceptual similarity analysis.",
        "US federal only. State registrations, common-law marks, and international registrations not covered.",
        "Bulk data lag. Data may trail the live USPTO TSDR system by 1-3 days.",
        "No design mark analysis. Image/logo marks are not searched.",
        "No likelihood-of-confusion analysis. Risk tiers are based on text matching and class overlap only.",
    ]
    pdf.set_font("Helvetica", "", 9)
    for i, lim in enumerate(limitations, 1):
        pdf.multi_cell(0, 4, f"{i}. {lim}")
        pdf.ln(1)
    pdf.ln(4)

    # --- Section 5: Recommended Next Steps ---
    _pdf_heading(pdf, "5. Recommended Next Steps")
    steps = [
        "Review high-risk matches with a trademark attorney, focusing on "
        "goods/services overlap and the strength of existing marks.",
        "Run a comprehensive professional search (e.g., Thomson CompuMark, "
        "Corsearch) covering phonetic matching, design marks, common-law "
        "sources, and international databases.",
        "Check tmsearch.uspto.gov for filings in the last 1-3 days not yet in the bulk data.",
        f"Consider filing strategy if clearance is given: Classes "
        f"{classes_str}; Filing basis: Section 1(b) Intent to Use or "
        f"Section 1(a) Use in Commerce; Filing method: TEAS Plus "
        f"($250/class) or TEAS Standard ($350/class).",
    ]
    pdf.set_font("Helvetica", "", 9)
    for i, step in enumerate(steps, 1):
        pdf.multi_cell(0, 4, f"{i}. {step}")
        pdf.ln(1)
    pdf.ln(6)

    # Footer disclaimer
    pdf.set_font("Helvetica", "I", 7)
    pdf.set_text_color(100, 100, 100)
    pdf.multi_cell(0, 3, f"Generated by chktm v{__version__}. {DISCLAIMER}")

    pdf.output(output_path)


def _pdf_heading(pdf: Any, text: str) -> None:
    """Render a section heading in the PDF."""
    pdf.set_font("Helvetica", "B", 13)
    pdf.cell(0, 8, text, new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(200, 200, 200)
    pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
    pdf.ln(3)


def _pdf_table_header(pdf: Any, headers: list[str], widths: list[int]) -> None:
    """Render a table header row."""
    pdf.set_font("Helvetica", "B", 8)
    pdf.set_fill_color(240, 240, 240)
    for h, w in zip(headers, widths):
        pdf.cell(w, 5, h, border=1, fill=True)
    pdf.ln()


def _pdf_table_row(pdf: Any, cells: list[str], widths: list[int]) -> None:
    """Render a table data row."""
    pdf.set_font("Helvetica", "", 8)
    for cell, w in zip(cells, widths):
        pdf.cell(w, 5, cell[: int(w * 0.45)], border=1)
    pdf.ln()


def _pdf_match(pdf: Any, match: Match) -> None:
    """Render a single match entry in the PDF."""
    if match.risk == Risk.HIGH:
        pdf.set_fill_color(255, 220, 220)
    elif match.risk == Risk.MEDIUM:
        pdf.set_fill_color(255, 243, 205)
    else:
        pdf.set_fill_color(230, 230, 230)

    pdf.set_font("Helvetica", "B", 10)
    pdf.cell(
        0,
        6,
        f"{match.wordmark or '(no wordmark)'}  [{match.risk.value}]",
        fill=True,
        new_x="LMARGIN",
        new_y="NEXT",
    )

    pdf.set_font("Helvetica", "", 8)
    reg = match.registration_number or "none"
    reg_date = match.registration_date or "none"
    cls = ", ".join(str(c) for c in match.classes)

    details = [
        f"Serial: {match.serial_number}  |  Registration: {reg}",
        f"Status: {match.status_code} ({'live' if match.is_live else 'dead'})"
        f"  |  Filed: {match.filing_date or '?'}  |  Registered: {reg_date}",
        f"Owner: {match.owner_name or 'unknown'}",
        f"Classes: {cls}",
        f"TSDR: {match.tsdr_url}",
    ]
    for d in details:
        pdf.cell(0, 4, d, new_x="LMARGIN", new_y="NEXT")

    if match.goods_services:
        pdf.set_font("Helvetica", "I", 7)
        pdf.multi_cell(0, 3, f"G/S: {_truncate(match.goods_services, 200)}")
    pdf.ln(3)
