# SPDX-License-Identifier: Apache-2.0
"""Persistent configuration for chktm (data dir, etc.)."""

from __future__ import annotations

import os
from pathlib import Path

# Config lives at ~/.config/chktm/config.toml on Linux/macOS,
# %APPDATA%/chktm/config.toml on Windows.
_APP_NAME = "chktm"


def _config_dir() -> Path:
    """Platform-appropriate config directory."""
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / _APP_NAME


def _config_path() -> Path:
    return _config_dir() / "config.toml"


def read_config() -> dict[str, str]:
    """Read the config file. Returns an empty dict if it doesn't exist."""
    path = _config_path()
    if not path.exists():
        return {}
    # Minimal TOML parser — we only store key = "value" pairs, no nesting.
    config: dict[str, str] = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            config[key] = value
    return config


def write_config(updates: dict[str, str]) -> None:
    """Write or update config values. Preserves existing keys not in updates."""
    config = read_config()
    config.update(updates)

    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    lines = [f"# chktm configuration\n# {path}\n"]
    for key, value in sorted(config.items()):
        lines.append(f'{key} = "{value}"')
    path.write_text("\n".join(lines) + "\n")


def resolve_data_dir(flag: Path | None = None) -> Path:
    """Resolve data directory from flag, env var, config file, or default.

    Resolution order (first wins):
    1. --data-dir CLI flag
    2. CHKTM_DATA_DIR environment variable
    3. data_dir in ~/.config/chktm/config.toml
    4. ./data (default)
    """
    if flag is not None:
        return flag

    env = os.environ.get("CHKTM_DATA_DIR")
    if env:
        return Path(env)

    config = read_config()
    if "data_dir" in config:
        return Path(config["data_dir"])

    return Path("./data")
