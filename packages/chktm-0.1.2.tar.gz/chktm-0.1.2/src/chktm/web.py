# SPDX-License-Identifier: Apache-2.0
"""FastAPI web application for chktm — lightweight search UI and JSON API."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, Query, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from starlette.middleware.base import BaseHTTPMiddleware

from chktm import __version__
from chktm.config import resolve_data_dir
from chktm.disclaimer import DISCLAIMER
from chktm.report import render_json
from chktm.search import search as run_search

_DATA_DIR = resolve_data_dir()

# Input constraints (OWASP A04:2021 — Insecure Design).
_MAX_QUERY_LENGTH = 500  # Max characters in the q= parameter.
_MAX_TERMS = 20  # Max number of space-separated terms.
_MAX_CLASSES = 45  # There are 45 Nice classification classes.


def _db_path() -> Path:
    return _DATA_DIR / "chktm.db"


def _get_conn() -> sqlite3.Connection:
    db = _db_path()
    if not db.exists():
        raise FileNotFoundError("Database not initialized. Run 'chktm init' first.")
    conn = sqlite3.connect(str(db))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


limiter = Limiter(key_func=get_remote_address)

app = FastAPI(
    title="chktm",
    description="Screen proposed marks against the full US trademark corpus.",
    version=__version__,
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add OWASP-recommended security headers to all responses.

    References:
    - OWASP Secure Headers Project
    - A05:2021 — Security Misconfiguration
    """

    async def dispatch(self, request: Request, call_next):
        response: Response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        # CSP: inline styles needed for the search UI; no external scripts.
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self'; "
            "connect-src 'self'; "
            "frame-ancestors 'none'"
        )
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Cache-Control"] = "no-store"
        return response


app.add_middleware(SecurityHeadersMiddleware)


@app.get("/", response_class=HTMLResponse)
async def index(request: Request) -> HTMLResponse:
    """Lightweight search form."""
    return HTMLResponse(_INDEX_HTML)


@app.get("/api/status")
async def api_status() -> JSONResponse:
    """Corpus status."""
    try:
        conn = _get_conn()
    except FileNotFoundError as e:
        return JSONResponse(
            {"version": __version__, "database_exists": False, "error": str(e)},
            status_code=503,
        )
    try:
        total = conn.execute("SELECT COUNT(*) FROM marks").fetchone()[0]
        live = conn.execute("SELECT COUNT(*) FROM marks WHERE is_live = 1").fetchone()[0]
        last_updated = conn.execute("SELECT value FROM meta WHERE key = 'last_update_date'").fetchone()
        min_date = conn.execute("SELECT MIN(filing_date) FROM marks WHERE filing_date IS NOT NULL").fetchone()[0]
        max_date = conn.execute("SELECT MAX(filing_date) FROM marks WHERE filing_date IS NOT NULL").fetchone()[0]
        db_size = _db_path().stat().st_size
    finally:
        conn.close()

    return JSONResponse(
        {
            "version": __version__,
            "database_exists": True,
            "total_marks": total,
            "live_marks": live,
            "dead_marks": total - live,
            "last_updated": last_updated[0] if last_updated else None,
            "coverage": {"from": min_date, "to": max_date},
            "db_size_bytes": db_size,
        }
    )


@app.get("/api/search")
@limiter.limit("30/minute")
async def api_search(
    request: Request,
    q: Annotated[str, Query(description="Search terms, space-separated")],
    classes: Annotated[str, Query(description="Comma-separated international class codes")] = "9,41,42",
    include_dead: Annotated[bool, Query(description="Include dead/abandoned marks")] = False,
) -> JSONResponse:
    """Search trademarks and return JSON results."""
    # Input validation (OWASP A04:2021).
    if len(q) > _MAX_QUERY_LENGTH:
        return JSONResponse(
            {"error": f"Query too long (max {_MAX_QUERY_LENGTH} characters)"},
            status_code=400,
        )

    terms = q.split()
    if not terms:
        return JSONResponse({"error": "No search terms provided"}, status_code=400)
    if len(terms) > _MAX_TERMS:
        return JSONResponse(
            {"error": f"Too many terms (max {_MAX_TERMS})"},
            status_code=400,
        )

    try:
        class_list = [int(c.strip()) for c in classes.split(",") if c.strip()]
    except ValueError:
        return JSONResponse({"error": f"Invalid classes: {classes!r}"}, status_code=400)
    if not all(1 <= c <= 45 for c in class_list):
        return JSONResponse({"error": "Classes must be between 1 and 45"}, status_code=400)
    if len(class_list) > _MAX_CLASSES:
        return JSONResponse(
            {"error": f"Too many classes (max {_MAX_CLASSES})"},
            status_code=400,
        )

    try:
        conn = _get_conn()
    except FileNotFoundError as e:
        return JSONResponse({"error": str(e)}, status_code=503)

    try:
        result = run_search(conn, terms, classes=class_list, include_dead=include_dead)
    finally:
        conn.close()

    import json

    return JSONResponse(json.loads(render_json(result)))


# Inline HTML template — keeps the deployment simple with zero static file deps.
_INDEX_HTML = (
    """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>chktm — Trademark Screening</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: system-ui, -apple-system, sans-serif; max-width: 900px;
         margin: 2rem auto; padding: 0 1rem; color: #1a1a1a; }
  h1 { margin-bottom: 0.25rem; }
  .subtitle { color: #666; margin-bottom: 1.5rem; font-size: 0.9rem; }
  form { display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 1rem; }
  input[type=text] { flex: 1; min-width: 200px; padding: 0.5rem; border: 1px solid #ccc;
                     border-radius: 4px; font-size: 1rem; }
  button { padding: 0.5rem 1.5rem; background: #2563eb; color: white; border: none;
           border-radius: 4px; font-size: 1rem; cursor: pointer; }
  button:hover { background: #1d4ed8; }
  .options { display: flex; gap: 1rem; align-items: center; margin-bottom: 1.5rem;
             font-size: 0.9rem; color: #555; }
  .options label { display: flex; align-items: center; gap: 0.25rem; }
  #results { white-space: pre-wrap; }
  .disclaimer { margin-top: 2rem; padding: 1rem; background: #fef3cd; border-radius: 4px;
                font-size: 0.85rem; color: #664d03; }
  .summary { padding: 0.75rem; background: #f0f7ff; border-radius: 4px;
             margin-bottom: 1rem; font-weight: 500; }
  .match { border: 1px solid #e0e0e0; border-radius: 4px; padding: 0.75rem;
           margin-bottom: 0.5rem; }
  .match.high { border-left: 4px solid #dc2626; }
  .match.medium { border-left: 4px solid #f59e0b; }
  .match.low { border-left: 4px solid #9ca3af; }
  .match h3 { font-size: 1rem; margin-bottom: 0.25rem; }
  .match .meta { font-size: 0.85rem; color: #555; }
  .match .meta a { color: #2563eb; }
  .risk-badge { display: inline-block; padding: 0.1rem 0.4rem; border-radius: 3px;
                font-size: 0.75rem; font-weight: 600; color: white; }
  .risk-badge.high { background: #dc2626; }
  .risk-badge.medium { background: #f59e0b; }
  .risk-badge.low { background: #9ca3af; }
  .loading { color: #666; font-style: italic; }
  .status { font-size: 0.85rem; color: #666; margin-bottom: 1rem; }
</style>
</head>
<body>
<h1>chktm</h1>
<p class="subtitle">Screen proposed marks against the US trademark corpus</p>

<form id="searchForm">
  <input type="text" id="q" name="q" placeholder="Enter mark(s) to search..."
         required autocomplete="off" maxlength="500">
  <button type="submit">Search</button>
</form>
<div class="options">
  <label>Classes: <input type="text" id="classes" value="9,41,42"
         style="width:120px;padding:0.3rem"></label>
  <label><input type="checkbox" id="includeDead"> Include dead marks</label>
</div>
<div id="status" class="status"></div>
<div id="results"></div>
<div class="disclaimer">"""
    + DISCLAIMER
    + """</div>

<script>
const statusEl = document.getElementById('status');
const resultsEl = document.getElementById('results');

fetch('/api/status').then(r => r.json()).then(d => {
  if (d.database_exists) {
    statusEl.textContent = `Corpus: ${d.total_marks.toLocaleString()} marks `
      + `(${d.live_marks.toLocaleString()} live) — last updated ${d.last_updated || 'unknown'}`;
  } else {
    statusEl.textContent = 'Database not initialized.';
  }
}).catch(() => { statusEl.textContent = 'Could not connect to API.'; });

document.getElementById('searchForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const q = document.getElementById('q').value.trim();
  const classes = document.getElementById('classes').value.trim();
  const dead = document.getElementById('includeDead').checked;
  if (!q) return;

  resultsEl.innerHTML = '<p class="loading">Searching...</p>';
  try {
    const params = new URLSearchParams({q, classes, include_dead: dead});
    const resp = await fetch('/api/search?' + params);
    const data = await resp.json();
    if (data.error) { resultsEl.textContent = 'Error: ' + data.error; return; }
    renderResults(data);
  } catch (err) {
    resultsEl.textContent = 'Search failed: ' + err.message;
  }
});

function renderResults(data) {
  const s = data.summary;
  let html = `<div class="summary">Found: ${s.high} HIGH, ${s.medium} MEDIUM, ${s.low} LOW</div>`;
  for (const tr of data.results) {
    html += `<h2>Term: ${esc(tr.term)}</h2>`;
    if (tr.matches.length === 0) {
      html += '<p style="color:#666;margin:0.5rem 0">No matches.</p>';
      continue;
    }
    for (const m of tr.matches) {
      const r = m.risk.toLowerCase();
      html += `<div class="match ${r}">
        <h3>${esc(m.wordmark || '(no wordmark)')}
          <span class="risk-badge ${r}">${m.risk}</span></h3>
        <div class="meta">
          Serial: ${esc(m.serial_number)} | Reg: ${esc(m.registration_number || 'none')}<br>
          Status: ${esc(m.status_code)} (${m.is_live ? 'live' : 'dead'}) |
          Filed: ${esc(m.filing_date || '?')} | Registered: ${esc(m.registration_date || 'none')}<br>
          Owner: ${esc(m.owner_name || 'unknown')}<br>
          Classes: ${m.classes.join(', ')}<br>
          Goods/services: ${esc((m.goods_services || '').substring(0, 200))}<br>
          <a href="${esc(m.tsdr_url)}" target="_blank">View on USPTO TSDR</a>
        </div>
      </div>`;
    }
  }
  resultsEl.innerHTML = html;
}

function esc(s) {
  const d = document.createElement('div');
  d.textContent = s || '';
  return d.innerHTML;
}
</script>
</body>
</html>
"""
)
