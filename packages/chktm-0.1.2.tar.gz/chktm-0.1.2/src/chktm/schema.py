# SPDX-License-Identifier: Apache-2.0
"""SQLite schema definition, initialization, and text normalization."""

from __future__ import annotations

import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

SCHEMA_VERSION = 3

# Official USPTO status code → is_live mapping.
# Source: Table1TrademarkStatusCodes_20250813.doc from the ODP API.
# Dead = Dead/Abandoned, Dead/Cancelled, Dead/Expired, Dead.
# Live = Live/Pending, Live/Registered, Live, Indifferent.
_DEAD_CODES: frozenset[str] = frozenset(
    {
        "400",
        "401",
        "402",
        "403",
        "404",
        "405",
        "406",
        "411",
        "412",
        "414",
        "415",
        "416",
        "417",
        "600",
        "601",
        "602",
        "603",
        "604",
        "605",
        "606",
        "607",
        "608",
        "609",
        "610",
        "612",
        "614",
        "618",
        "626",
        "632",
        "709",
        "710",
        "711",
        "712",
        "713",
        "714",
        "781",
        "782",
        "783",
        "900",
        "901",
        "968",
    }
)


def is_live(status_code: str | None) -> bool:
    """Return True if the status code indicates a live (non-dead) mark.

    Uses the official USPTO Table 1 Trademark Status Codes mapping.
    Unknown codes default to live (conservative).
    """
    if not status_code or not status_code.strip():
        return True
    return status_code.strip() not in _DEAD_CODES


# Official status code descriptions from USPTO Table 1.
_STATUS_DESCRIPTIONS: dict[str, str] = {
    "000": "UNKNOWN",
    "400": "IR CANCELLED; APPLICATION PENDING TRANSFORMATION",
    "401": "IR CANCELLED - NO TRANSFORMATION FILED",
    "402": "IR CANCELLED; US APPLICATION ABANDONED",
    "403": "IR CANCELLED; REGISTRATION PENDING TRANSFORMATION",
    "404": "IR CANCELLED; US REGISTRATION CANCELLED",
    "405": "IR CANCELED; APPLICATION TRANSFORMED",
    "406": "IR CANCELLED; REGISTRATION TRANSFORMED",
    "410": "IR RESTRICTED; US APP. ABANDONED, PENDING TRANSFORMATION",
    "411": "IR RESTRICTED; US APP. ABANDONED; NO TRANSFORMATION FILED",
    "412": "IR RESTRICTED; US APPLICATION ABANDONED",
    "413": "IR RESTRICTED; US REG. CANCELLED PEND TRANSFORMATION",
    "414": "IR RESTRICTED; US REG. CANCELLED; NO TRANSFORMATION FILED",
    "415": "IR RESTRICTED; US REGISTRATION CANCELLED",
    "416": "IR RESTRICTED; US APP ABANDONED; US APP TRANSFORMED",
    "417": "IR RESTRICTED; US REG CANCELLED; US REG TRANSFORMED",
    "600": "ABANDONED - INCOMPLETE RESPONSE",
    "601": "ABANDONED - EXPRESS",
    "602": "ABANDONED - FAILURE TO RESPOND OR LATE RESPONSE",
    "603": "ABANDONED - AFTER EX PARTE APPEAL",
    "604": "ABANDONED - AFTER INTER-PARTES DECISION",
    "605": "ABANDONED - EXPRESS AFTER PUB",
    "606": "ABANDONED - NO STATEMENT OF USE FILED",
    "607": "ABANDONED - DEFECTIVE STATEMENT OF USE",
    "608": "ABANDONED - AFTER PETITION DECISION",
    "609": "ABANDONED - DEFECTIVE DIVIDED APPLICATION",
    "610": "TERMINATED AFTER SANCTIONS",
    "612": "PETITION TO REVIVE - RECEIVED",
    "614": "ABANDONED PETITION TO REVIVE - DENIED",
    "616": "REVIVED - AWAITING FURTHER ACTION",
    "618": "ABANDONED FILE - BACKFILE",
    "620": "BACKFILE APPLICATION - STATUS NOT RECORDED",
    "622": "MISASSIGNED SERIAL NUMBER",
    "624": "REGISTERED - BACKFILE",
    "625": "REGISTRATION ADDED - STATUS UNCLEAR",
    "626": "REGISTERED - BACKFILE CANCELLED OR EXPIRED",
    "630": "NEW APPLICATION - NOT ASSIGNED TO EXAMINER",
    "631": "NEW APPLICATION - DIVIDED - INITIAL PROCESSING",
    "632": "INFORMAL APPLICATION",
    "638": "NEW APPLICATION - ASSIGNED TO EXAMINER",
    "640": "NON-FINAL ACTION - NOT MAILED",
    "641": "NON-FINAL ACTION - MAILED",
    "642": "INVENTORIED AS REJECTED",
    "643": "PREVIOUS ACTION/ALLOWANCE COUNT WITHDRAWN",
    "644": "FINAL REFUSAL - NOT MAILED",
    "645": "FINAL REFUSAL - MAILED",
    "646": "EXAMINER'S AMENDMENT - NOT MAILED",
    "647": "EXAMINER'S AMENDMENT - MAILED",
    "648": "ACTION CONTINUING FINAL - NOT MAILED",
    "649": "ACTION CONTINUING FINAL - MAILED",
    "650": "SUSPENSION INQUIRY - NOT MAILED",
    "651": "SUSPENSION INQUIRY - MAILED",
    "652": "SUSPENSION LETTER - NOT MAILED",
    "653": "SUSPENSION LETTER - MAILED",
    "654": "SUSPENSION CHECK - CASE STILL SUSPENDED",
    "655": "EXAMINER'S AMENDMENT/PRIORITY ACTION - NOT MAILED",
    "656": "EXAMINER'S AMENDMENT/PRIORITY ACTION - MAILED",
    "657": "PRIORITY ACTION - NOT MAILED",
    "658": "PRIORITY ACTION - MAILED",
    "659": "SUBSEQUENT FINAL REFUSAL - NOT MAILED",
    "660": "SUBSEQUENT FINAL - MAILED",
    "661": "RESPONSE AFTER NON-FINAL ACTION - ENTERED",
    "663": "RESPONSE AFTER FINAL REJECTION - ENTERED",
    "664": "INVENTORIED AS AMENDED",
    "665": "NOTICE OF UNRESPONSIVE AMENDMENT - COUNTED",
    "666": "NOTICE OF UNRESPONSIVE AMENDMENT - MAILED",
    "667": "REFUSAL WITHDRAWAL LETTER - COUNTED",
    "668": "REFUSAL WITHDRAWAL LETTER - MAILED",
    "672": "REINSTATED - AWAITING FURTHER ACTION",
    "680": "APPROVED FOR PUBLICATION",
    "681": "PUBLICATION/ISSUE REVIEW COMPLETE",
    "682": "ADDITIONAL REVIEW - RETURNED TO PUB CYCLE",
    "686": "PUBLISHED FOR OPPOSITION",
    "688": "NOTICE OF ALLOWANCE - ISSUED",
    "689": "NOTICE OF ALLOWANCE - WITHDRAWN",
    "690": "NOTICE OF ALLOWANCE - CANCELLED",
    "692": "WITHDRAWN BEFORE PUBLICATION",
    "693": "WITHDRAWN FROM ISSUE - JURISDICTION RESTORED",
    "694": "WITHDRAWN BEFORE ISSUE",
    "700": "REGISTERED",
    "701": "SECTION 8 - ACCEPTED",
    "702": "SECTION 8 & 15 - ACCEPTED AND ACKNOWLEDGED",
    "703": "SECTION 15 - ACKNOWLEDGED",
    "704": "PARTIAL SECTION 8 ACCEPTED",
    "705": "PARTIAL SECTION 8 & 15 ACCEPTED AND ACKNOWLEDGED",
    "706": "SECTION 71 ACCEPTED",
    "707": "PARTIAL SECTION 71 ACCEPTED",
    "708": "PARTIAL SECTION 71 & 15 ACCEPTED AND ACKNOWLEDGED",
    "709": "CANCELLED - SECTION 71",
    "710": "CANCELLED - SECTION 8",
    "711": "CANCELLED - SECTION 7",
    "712": "CANCELLED BY COURT ORDER (SECTION 37)",
    "713": "CANCELLED - SECTION 18",
    "714": "CANCELLED - SECTION 24",
    "715": "CANCELLED - RESTORED TO PENDENCY",
    "717": "REGISTERED - AWAITING DIVISIONAL FEE",
    "718": "FIRST EXTENSION - FILED",
    "719": "SECOND EXTENSION - FILED",
    "720": "THIRD EXTENSION - FILED",
    "721": "FOURTH EXTENSION - FILED",
    "722": "FIFTH EXTENSION - FILED",
    "724": "EXTENSION REQUEST REFUSAL - COUNTED",
    "725": "EXTENSION REQUEST REFUSAL - MAILED",
    "730": "FIRST EXTENSION - GRANTED",
    "731": "SECOND EXTENSION - GRANTED",
    "732": "THIRD EXTENSION - GRANTED",
    "733": "FOURTH EXTENSION - GRANTED",
    "734": "FIFTH EXTENSION - GRANTED",
    "739": "SECTION 71 & 15 - ACCEPTED AND ACKNOWLEDGED",
    "740": "POST REGISTRATION - ASSIGNED TO PARALEGAL",
    "744": "STATEMENT OF USE - FILED",
    "745": "STATEMENT OF USE - INFORMAL LETTER MAILED",
    "746": "STATEMENT OF USE - INFORMAL RESPONSE ENTERED",
    "748": "STATEMENT OF USE - TO EXAMINER",
    "752": "SU - EXAMINER STATEMENT - NOT MAILED",
    "753": "SU - EXAMINER STATEMENT - MAILED",
    "756": "EXAMINER STATEMENT - NOT MAILED",
    "757": "EXAMINER STATEMENT - MAILED",
    "760": "EX PARTE APPEAL PENDING",
    "762": "EX PARTE APPEAL TERMINATED",
    "763": "EX PARTE APPEAL - REFUSAL AFFIRMED",
    "764": "EX PARTE APPEAL DISMISSED AS MOOT",
    "765": "CONCURRENT USE PROCEEDING - GRANTED",
    "766": "CONCURRENT USE PROCEEDING - DENIED",
    "771": "CONCURRENT USE PROCEEDING PENDING",
    "772": "INTERFERENCE PROCEEDING PENDING",
    "773": "EXTENSION OF TIME TO OPPOSE - TERMINATED",
    "774": "OPPOSITION PENDING",
    "775": "OPPOSITION DISMISSED",
    "777": "OPPOSITION TERMINATED",
    "778": "CANCELLATION DISMISSED",
    "779": "OPPOSITION SUSTAINED",
    "780": "CANCELLATION TERMINATED",
    "781": "CANCELLED - SECTION 16A",
    "782": "CANCELLED - SECTION 16B",
    "783": "CANCELLED RECONSIDERED",
    "790": "CANCELLATION PENDING",
    "794": "JURISDICTION RESTORED TO EXAMINING ATTORNEY",
    "800": "REGISTERED AND RENEWED",
    "801": "OPPOSITION PAPERS FILED",
    "802": "REQUEST FOR EXTENSION OF TIME TO FILE OPPOSITION",
    "803": "AMENDMENT AFTER PUBLICATION",
    "804": "APPEAL RECEIVED AT TTAB",
    "806": "SU - NON-FINAL ACTION - NOT MAILED",
    "807": "SU - NON-FINAL ACTION - MAILED",
    "808": "SU - FINAL REFUSAL - NOT MAILED",
    "809": "SU - FINAL REFUSAL - MAILED",
    "810": "SU - EXAMINER'S AMENDMENT - NOT MAILED",
    "811": "SU - EXAMINER'S AMENDMENT - MAILED",
    "812": "SU - ACTION CONTINUING FINAL - NOT MAILED",
    "813": "SU - ACTION CONTINUING FINAL - MAILED",
    "814": "SU - RESPONSE AFTER NON-FINAL ACTION - ENTERED",
    "815": "SU - RESPONSE AFTER FINAL REJECTION - ENTERED",
    "816": "SU - NOTICE OF UNRESPONSIVE AMENDMENT - COUNTED",
    "817": "SU - NOTICE OF UNRESPONSIVE AMENDMENT - MAILED",
    "818": "SU - STATEMENT OF USE ACCEPTED - APPROVED",
    "819": "SU - REGISTRATION REVIEW COMPLETE",
    "820": "SU - EXAMINER'S AMENDMENT/PRIORITY ACTION - NOT MAILED",
    "821": "SU - EXAMINER'S AMENDMENT/PRIORITY ACTION - MAILED",
    "822": "SU - PRIORITY ACTION - NOT MAILED",
    "823": "SU - PRIORITY ACTION - MAILED",
    "824": "SU - SUBSEQUENT FINAL REFUSAL WRITTEN",
    "825": "SU - SUBSEQUENT FINAL MAILED",
    "900": "EXPIRED",
    "901": "DEAD INVENTORIED AS REJECTED",
    "968": "NON REGISTRATION DATA WITHDRAWN",
    "969": "NON REGISTRATION DATA",
    "970": "RECORD CREATED DUE TO ASSIGNMENT REQUEST",
    "973": "SUSPENDED PENDING ADMINISTRATIVE REVIEW",
}


def status_description(status_code: str | None) -> str:
    """Return the human-readable description for a USPTO status code."""
    if not status_code:
        return ""
    return _STATUS_DESCRIPTIONS.get(status_code.strip(), "")


_NORMALIZE_RE = re.compile(r"[\s\-]+")


def normalize(text: str) -> str:
    """Lowercase, strip whitespace/hyphens for search matching."""
    return _NORMALIZE_RE.sub("", text).lower()


def phonetic_code(text: str) -> str:
    """Generate a Soundex phonetic code for a wordmark.

    Returns a 4-character Soundex code, or empty string for empty input.
    Soundex groups similar-sounding words together (e.g., "thundercorp"
    and "thundrcorp" both produce "T536").
    """
    import jellyfish

    normalized = normalize(text)
    if not normalized:
        return ""
    return jellyfish.soundex(normalized)


_CREATE_SQL = """\
CREATE TABLE IF NOT EXISTS marks (
    serial_number       TEXT PRIMARY KEY,
    registration_number TEXT,
    wordmark            TEXT NOT NULL,
    wordmark_normalized TEXT NOT NULL,
    wordmark_soundex    TEXT NOT NULL DEFAULT '',
    status_code         TEXT,
    is_live             INTEGER NOT NULL,
    filing_date         TEXT,
    registration_date   TEXT,
    mark_drawing_code   TEXT,
    owner_name          TEXT,
    goods_services      TEXT
);

CREATE TABLE IF NOT EXISTS mark_classes (
    serial_number TEXT NOT NULL,
    intl_class    INTEGER NOT NULL,
    PRIMARY KEY (serial_number, intl_class),
    FOREIGN KEY (serial_number) REFERENCES marks(serial_number)
);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE INDEX IF NOT EXISTS idx_marks_normalized      ON marks(wordmark_normalized);
CREATE INDEX IF NOT EXISTS idx_marks_soundex         ON marks(wordmark_soundex);
CREATE INDEX IF NOT EXISTS idx_marks_live             ON marks(is_live);
CREATE INDEX IF NOT EXISTS idx_marks_live_normalized  ON marks(is_live, wordmark_normalized);
CREATE INDEX IF NOT EXISTS idx_classes_class          ON mark_classes(intl_class);
"""


def init_db(db_path: Path) -> sqlite3.Connection:
    """Create (or open) the SQLite database and ensure the schema exists."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    # Wait up to 30 seconds for locks to clear instead of failing immediately.
    conn.execute("PRAGMA busy_timeout=30000")
    conn.executescript(_CREATE_SQL)
    # Store schema version for future migrations
    conn.execute(
        "INSERT OR IGNORE INTO meta(key, value) VALUES (?, ?)",
        ("schema_version", str(SCHEMA_VERSION)),
    )
    conn.commit()
    return conn


@contextmanager
def bulk_ingest_mode(conn: sqlite3.Connection) -> Iterator[None]:
    """Temporarily tune SQLite for high-throughput bulk writes.

    Sets synchronous=NORMAL (safe with WAL) and increases the page cache.
    Restores defaults on exit.
    """
    # Commit any open transaction — PRAGMAs cannot be changed mid-transaction.
    conn.commit()
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA cache_size=-64000")  # 64 MB
    try:
        yield
    finally:
        conn.execute("PRAGMA synchronous=FULL")
        conn.execute("PRAGMA cache_size=-2000")  # default ~2 MB


def parse_date(raw: str | None) -> str | None:
    """Convert YYYYMMDD to YYYY-MM-DD, or return None for empty/zero values."""
    if not raw or raw.strip("0") == "":
        return None
    raw = raw.strip()
    if len(raw) == 8:
        return f"{raw[:4]}-{raw[4:6]}-{raw[6:8]}"
    return raw


def parse_registration_number(raw: str | None) -> str | None:
    """Return None for zero-filled or empty registration numbers."""
    if not raw or raw.strip("0") == "":
        return None
    return raw
