# SPDX-License-Identifier: Apache-2.0
"""Streaming XML parser for USPTO trademark bulk data files."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import IO, Iterator

import defusedxml.ElementTree as ET

from chktm.schema import (
    bulk_ingest_mode,
    init_db,
    is_live,
    normalize,
    parse_date,
    parse_registration_number,
    phonetic_code,
)

# Batch size for commit intervals during ingestion.
_BATCH_SIZE = 5000


def _extract_owner(case_file: ET.Element) -> str | None:
    """Extract the best owner name from the case-file-owners block.

    Strategy: use the owner with the highest party-type code (most recent
    assignee). Party-type 70 ("Last Listed Owner") is preferred when present.
    Falls back to the last <case-file-owner> entry.
    """
    owners_block = case_file.find("case-file-owners")
    if owners_block is None:
        return None
    owners = owners_block.findall("case-file-owner")
    if not owners:
        return None

    best = owners[-1]  # default: last entry
    best_type = 0
    for owner in owners:
        pt = owner.findtext("party-type", "0")
        try:
            pt_int = int(pt)
        except ValueError:
            continue
        if pt_int >= best_type:
            best_type = pt_int
            best = owner
    return best.findtext("party-name")


def _extract_classes(case_file: ET.Element) -> list[int]:
    """Extract international class codes from the classifications block."""
    classes_block = case_file.find("classifications")
    if classes_block is None:
        return []
    codes: list[int] = []
    for classification in classes_block.findall("classification"):
        for ic in classification.findall("international-code"):
            if ic.text and ic.text.strip().isdigit():
                codes.append(int(ic.text.strip()))
    return sorted(set(codes))


def _extract_goods_services(case_file: ET.Element) -> str | None:
    """Extract and concatenate goods/services text from case-file-statements.

    Filters to statements where the type-code starts with "GS" and the 6th
    character (qualifier) is "1" (normal text). Concatenates texts separated
    by semicolons, with the class number prepended.
    """
    stmts_block = case_file.find("case-file-statements")
    if stmts_block is None:
        return None
    parts: list[str] = []
    for stmt in stmts_block.findall("case-file-statement"):
        type_code = stmt.findtext("type-code", "")
        if not type_code.startswith("GS"):
            continue
        # Accept qualifier "1" (normal) and "3" (embedded less-goods).
        # Skip qualifier "2" (less-goods only).
        if len(type_code) >= 6 and type_code[5] == "2":
            continue
        text = stmt.findtext("text", "").strip()
        if text:
            # Extract class from type-code positions 2-4
            class_str = type_code[2:5] if len(type_code) >= 5 else ""
            if class_str.isdigit():
                parts.append(f"[Class {int(class_str):03d}] {text}")
            else:
                parts.append(text)
    return "; ".join(parts) if parts else None


def iter_case_files(source: Path | IO[bytes]) -> Iterator[ET.Element]:
    """Yield <case-file> elements from a USPTO XML file, streaming.

    Clears each element after yielding. Uses a lightweight element stack to
    find the parent of each <case-file> and remove it, preventing the classic
    iterparse memory leak where ancestors accumulate dead references.
    """
    context = ET.iterparse(source, events=("start", "end"))
    stack: list[ET.Element] = []
    for event, elem in context:
        if event == "start":
            stack.append(elem)
        elif event == "end":
            if stack:
                stack.pop()
            if elem.tag == "case-file":
                yield elem
                # Parent is now the top of the stack (action-keys or similar).
                if stack:
                    try:
                        stack[-1].remove(elem)
                    except ValueError:
                        pass
                elem.clear()


def ingest_xml(source: Path | IO[bytes], conn: sqlite3.Connection) -> int:
    """Parse a USPTO XML file and upsert records into the database.

    Returns the number of records processed.
    """
    count = 0
    mark_rows: list[tuple] = []
    class_rows: list[tuple[str, int]] = []

    with bulk_ingest_mode(conn):
        for case_file in iter_case_files(source):
            serial = case_file.findtext("serial-number", "").strip()
            if not serial:
                continue

            header = case_file.find("case-file-header")
            if header is None:
                continue

            wordmark = header.findtext("mark-identification", "")
            status_code = header.findtext("status-code")
            filing_date = parse_date(header.findtext("filing-date"))
            registration_date = parse_date(header.findtext("registration-date"))
            mark_drawing_code = header.findtext("mark-drawing-code")
            reg_number = parse_registration_number(case_file.findtext("registration-number"))

            owner_name = _extract_owner(case_file)
            classes = _extract_classes(case_file)
            goods_services = _extract_goods_services(case_file)

            live = 1 if is_live(status_code) else 0

            mark_rows.append(
                (
                    serial,
                    reg_number,
                    wordmark,
                    normalize(wordmark),
                    phonetic_code(wordmark),
                    status_code,
                    live,
                    filing_date,
                    registration_date,
                    mark_drawing_code,
                    owner_name,
                    goods_services,
                )
            )

            for cls in classes:
                class_rows.append((serial, cls))

            count += 1

            if count % _BATCH_SIZE == 0:
                _flush(conn, mark_rows, class_rows)
                mark_rows.clear()
                class_rows.clear()

        # Flush remaining
        if mark_rows:
            _flush(conn, mark_rows, class_rows)

    return count


def _flush(
    conn: sqlite3.Connection,
    mark_rows: list[tuple],
    class_rows: list[tuple[str, int]],
) -> None:
    """Write a batch of rows to the database."""
    conn.executemany(
        """INSERT OR REPLACE INTO marks
           (serial_number, registration_number, wordmark, wordmark_normalized,
            wordmark_soundex, status_code, is_live, filing_date,
            registration_date, mark_drawing_code, owner_name, goods_services)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        mark_rows,
    )
    # Delete old class associations for upserted marks, then re-insert.
    # Batch the DELETE using a single statement per chunk to avoid O(n) calls.
    serials = list({row[0] for row in mark_rows})
    _CHUNK = 999  # SQLite variable limit
    for i in range(0, len(serials), _CHUNK):
        chunk = serials[i : i + _CHUNK]
        placeholders = ",".join("?" * len(chunk))
        conn.execute(
            f"DELETE FROM mark_classes WHERE serial_number IN ({placeholders})",
            chunk,
        )
    conn.executemany(
        "INSERT OR IGNORE INTO mark_classes (serial_number, intl_class) VALUES (?, ?)",
        class_rows,
    )
    conn.commit()


def ingest_file(xml_path: Path, db_path: Path) -> int:
    """Convenience: open the database and ingest a single XML file."""
    conn = init_db(db_path)
    try:
        return ingest_xml(xml_path, conn)
    finally:
        conn.close()
