# SPDX-License-Identifier: Apache-2.0
"""Download USPTO trademark bulk data from the Open Data Portal API."""

from __future__ import annotations

import logging
import os
import shutil
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Iterator
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

logger = logging.getLogger(__name__)

# Product identifiers on the ODP.
PRODUCT_ANNUAL = "TRTYRAP"  # Annual backfile (Apr 1884 – Dec 2025)
PRODUCT_DAILY = "TRTDXFAP"  # Daily applications (current year)

API_BASE = "https://api.uspto.gov/api/v1/datasets/products"

# Rate limiting: 4 ZIP downloads per minute during business hours,
# 12/min off-peak (10pm–5am EST).
RATE_NORMAL = 16.0  # seconds between downloads (3.75 req/min)
RATE_OFF_PEAK = 5.5  # seconds between downloads (~11 req/min)

# Retry configuration for transient errors.
_MAX_RETRIES = 3
_RETRY_BACKOFF = [2, 4, 8]  # seconds


@dataclass
class RemoteFile:
    """Metadata for a single file in a product listing."""

    file_name: str
    file_size: int
    download_uri: str
    from_date: str
    to_date: str


def _api_key() -> str:
    """Read the USPTO API key from the environment."""
    key = os.environ.get("CHKTM_USPTO_API_KEY", "").strip()
    if not key:
        raise RuntimeError(
            "CHKTM_USPTO_API_KEY environment variable is not set.\n"
            "Register for a free key at https://data.uspto.gov/apis/getting-started"
        )
    return key


def _api_get(url: str) -> bytes:
    """Make an authenticated GET request to the ODP API."""
    req = Request(url)
    req.add_header("X-API-Key", _api_key())
    try:
        with urlopen(req, timeout=60) as resp:
            return resp.read()
    except HTTPError as e:
        if e.code == 429:
            raise RuntimeError("Rate limited by USPTO API (HTTP 429). Wait a minute and retry.") from e
        raise RuntimeError(f"USPTO API error: HTTP {e.code} for {url}") from e
    except URLError as e:
        raise RuntimeError(f"Network error reaching USPTO API: {e}") from e


def check_disk_space(dest_dir: Path, required_bytes: int) -> None:
    """Raise RuntimeError if insufficient disk space is available.

    Args:
        dest_dir: Directory where files will be written.
        required_bytes: Minimum free space needed in bytes.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(str(dest_dir))
    if usage.free < required_bytes:
        free_gb = usage.free / 1e9
        need_gb = required_bytes / 1e9
        raise RuntimeError(
            f"Insufficient disk space: {free_gb:.1f} GB free, "
            f"need at least {need_gb:.1f} GB. "
            f"Free up space or use --data-dir to point to a larger volume."
        )


def estimate_download_size(product_id: str) -> int:
    """Query the API for the total download size of a product in bytes."""
    import json

    url = f"{API_BASE}/{product_id}?includeFiles=true"
    data = json.loads(_api_get(url))
    products = data.get("bulkDataProductBag", [])
    if not products:
        return 0
    return products[0].get("productTotalFileSize", 0)


def list_product_files(product_id: str) -> list[RemoteFile]:
    """List all files available for a given product identifier."""
    import json

    url = f"{API_BASE}/{product_id}?includeFiles=true"
    data = json.loads(_api_get(url))

    products = data.get("bulkDataProductBag", [])
    if not products:
        raise RuntimeError(f"No product found for identifier: {product_id}")

    file_bag = products[0].get("productFileBag", {})
    files = file_bag.get("fileDataBag", [])

    result = []
    for f in files:
        result.append(
            RemoteFile(
                file_name=f["fileName"],
                file_size=f.get("fileSize", 0),
                download_uri=f["fileDownloadURI"],
                from_date=f.get("fileDataFromDate", ""),
                to_date=f.get("fileDataToDate", ""),
            )
        )
    return result


def download_file(
    remote: RemoteFile,
    dest_dir: Path,
    *,
    chunk_size: int = 256 * 1024,
    on_progress: callable | None = None,
    retries: int = _MAX_RETRIES,
) -> Path:
    """Download a single file to dest_dir with retry and integrity check.

    Skips download if the file already exists and matches the expected size.
    Follows 302 redirects (the ODP returns these for actual file storage).
    Retries transient errors with exponential backoff.

    Args:
        remote: The remote file metadata.
        dest_dir: Directory to save the file into.
        chunk_size: Read chunk size in bytes.
        on_progress: Optional callback(bytes_downloaded, total_bytes).
        retries: Number of retries on transient errors.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    # Sanitize filename to prevent path traversal (OWASP A04).
    safe_name = Path(remote.file_name).name
    if not safe_name or ".." in safe_name:
        raise RuntimeError(f"Invalid filename from API: {remote.file_name!r}")
    dest = dest_dir / safe_name

    # Resume: skip if already downloaded with correct size.
    if dest.exists() and remote.file_size > 0:
        if dest.stat().st_size == remote.file_size:
            return dest

    last_error = None
    for attempt in range(retries + 1):
        if attempt > 0:
            wait = _RETRY_BACKOFF[min(attempt - 1, len(_RETRY_BACKOFF) - 1)]
            logger.warning(
                "Retry %d/%d for %s after %ds",
                attempt,
                retries,
                remote.file_name,
                wait,
            )
            time.sleep(wait)

        try:
            req = Request(remote.download_uri)
            req.add_header("X-API-Key", _api_key())

            with urlopen(req, timeout=300) as resp:
                total = int(resp.headers.get("Content-Length", 0)) or remote.file_size
                downloaded = 0
                with open(dest, "wb") as f:
                    while True:
                        chunk = resp.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        if on_progress:
                            on_progress(downloaded, total)

            # Integrity check: verify downloaded size matches expected.
            if remote.file_size > 0:
                actual = dest.stat().st_size
                if actual != remote.file_size:
                    dest.unlink(missing_ok=True)
                    last_error = RuntimeError(
                        f"Size mismatch for {remote.file_name}: expected {remote.file_size}, got {actual}"
                    )
                    continue  # retry

            return dest

        except HTTPError as e:
            dest.unlink(missing_ok=True)
            if e.code == 429:
                # Rate limited — wait longer and retry.
                retry_after = int(e.headers.get("Retry-After", 60))
                logger.warning("HTTP 429 — waiting %ds", retry_after)
                time.sleep(retry_after)
                last_error = e
                continue
            if e.code >= 500:
                # Server error — transient, retry.
                last_error = e
                continue
            # Client error (4xx except 429) — don't retry.
            raise RuntimeError(f"Failed to download {remote.file_name}: HTTP {e.code}") from e

        except (URLError, OSError, TimeoutError) as e:
            dest.unlink(missing_ok=True)
            last_error = e
            continue

    raise RuntimeError(f"Failed to download {remote.file_name} after {retries + 1} attempts: {last_error}")


def extract_zip(zip_path: Path, dest_dir: Path) -> list[Path]:
    """Extract a ZIP file and return paths to extracted XML files.

    Handles corrupt ZIPs gracefully by logging and returning an empty list.
    """
    try:
        extracted = []
        with zipfile.ZipFile(zip_path, "r") as zf:
            for name in zf.namelist():
                if name.lower().endswith(".xml"):
                    zf.extract(name, dest_dir)
                    extracted.append(dest_dir / name)
        return extracted
    except zipfile.BadZipFile:
        logger.error("Corrupt ZIP file: %s — deleting and skipping", zip_path)
        zip_path.unlink(missing_ok=True)
        return []


def stream_extract_zip(zip_path: Path) -> Iterator[tuple[str, IO[bytes]]]:
    """Yield (filename, file_object) pairs for XML files inside a ZIP.

    Streams directly from the ZIP without extracting to disk. The caller
    must consume the file object before the next iteration.
    """
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            for name in zf.namelist():
                if name.lower().endswith(".xml"):
                    with zf.open(name) as f:
                        yield name, f
    except zipfile.BadZipFile:
        logger.error("Corrupt ZIP file: %s — deleting and skipping", zip_path)
        zip_path.unlink(missing_ok=True)


def download_product_files(
    product_id: str,
    dest_dir: Path,
    *,
    already_downloaded: set[str] | None = None,
    since_date: str | None = None,
    on_file_start: callable | None = None,
    on_file_progress: callable | None = None,
    on_file_done: callable | None = None,
    rate_limit: float = RATE_NORMAL,
) -> Iterator[tuple[RemoteFile, Path]]:
    """Download all files for a product, yielding (remote, local_path) pairs.

    Args:
        product_id: ODP product identifier (TRTYRAP or TRTDXFAP).
        dest_dir: Directory to save ZIP files into.
        already_downloaded: Set of file names to skip (for resumability).
        since_date: Only download files with from_date >= this (YYYY-MM-DD).
        on_file_start: Callback(remote_file, index, total) before each download.
        on_file_progress: Callback(bytes_downloaded, total_bytes) during download.
        on_file_done: Callback(remote_file, local_path) after each download.
        rate_limit: Minimum seconds between download starts.

    Yields:
        (RemoteFile, Path) tuples for each successfully downloaded file.
    """
    files = list_product_files(product_id)

    # Only process ZIP files — the product listing may include .doc, .pdf, etc.
    files = [f for f in files if f.file_name.lower().endswith(".zip")]

    # Filter by date if requested.
    if since_date:
        files = [f for f in files if f.from_date >= since_date]

    # Sort by date ascending for chronological ingestion.
    files.sort(key=lambda f: f.from_date)

    # Filter out already-downloaded files.
    skip = already_downloaded or set()
    to_download = [f for f in files if f.file_name not in skip]

    total = len(to_download)
    last_download_time = 0.0

    for idx, remote in enumerate(to_download):
        if on_file_start:
            on_file_start(remote, idx, total)

        # Rate limiting.
        elapsed = time.monotonic() - last_download_time
        if elapsed < rate_limit and last_download_time > 0:
            time.sleep(rate_limit - elapsed)

        last_download_time = time.monotonic()
        local_path = download_file(remote, dest_dir, on_progress=on_file_progress)

        if on_file_done:
            on_file_done(remote, local_path)

        yield remote, local_path
