# SPDX-License-Identifier: Apache-2.0
"""Single source of truth for the chktm legal disclaimer."""

from __future__ import annotations

DISCLAIMER = (
    "chktm is a research aid, not legal clearance. Trademark conflicts require a "
    "likelihood-of-confusion analysis that only a qualified attorney can perform. "
    "Do not rely on this tool for any legal decision. Always consult an attorney "
    "before adopting a mark."
)
