# SPDX-License-Identifier: Apache-2.0
"""chktm CLI — screen proposed marks against the US trademark corpus."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

from chktm import __version__
from chktm.config import resolve_data_dir, write_config
from chktm.disclaimer import DISCLAIMER

app = typer.Typer(
    help=f"Screen proposed marks against the full US trademark corpus.\n\n{DISCLAIMER}",
    no_args_is_help=True,
)

console = Console(stderr=True)

# Exit codes — stable contract for agent consumption.
EXIT_OK = 0
EXIT_ERROR = 1
EXIT_NO_DB = 2


def _data_dir(data_dir: Path | None) -> Path:
    """Resolve the data directory from flag, env var, config file, or default."""
    return resolve_data_dir(data_dir)


def _db_path(data_dir: Path) -> Path:
    return data_dir / "chktm.db"


def _output(data: dict, as_json: bool) -> None:
    """Write structured output to stdout."""
    if as_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        # Human-readable fallback — subcommands override this with rich output.
        typer.echo(json.dumps(data, indent=2, default=str))


def _error(message: str, as_json: bool, code: int = EXIT_ERROR) -> None:
    """Report an error and exit."""
    if as_json:
        typer.echo(json.dumps({"error": message}, indent=2))
    else:
        console.print(f"[red]Error:[/red] {message}")
    raise typer.Exit(code)


@app.command()
def version(
    json_output: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output")] = False,
) -> None:
    """Show chktm version."""
    if json_output:
        typer.echo(json.dumps({"version": __version__}))
    else:
        typer.echo(f"chktm {__version__}")


@app.command()
def status(
    data_dir: Annotated[
        Optional[Path],
        typer.Option("--data-dir", help="Path to data directory"),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output")] = False,
) -> None:
    """Show corpus stats: record count, last update, coverage dates."""
    import sqlite3

    resolved = _data_dir(data_dir)
    db = _db_path(resolved)

    if not db.exists():
        data = {
            "version": __version__,
            "database_exists": False,
            "message": ("No database found. Run 'chktm init' to download and ingest the trademark corpus."),
        }
        _output(data, json_output)
        raise typer.Exit(EXIT_NO_DB)

    conn = sqlite3.connect(str(db))
    conn.execute("PRAGMA busy_timeout=5000")
    try:
        total = conn.execute("SELECT COUNT(*) FROM marks").fetchone()[0]
        live = conn.execute("SELECT COUNT(*) FROM marks WHERE is_live = 1").fetchone()[0]
        dead = total - live
        last_updated = conn.execute("SELECT value FROM meta WHERE key = 'last_update_date'").fetchone()
        min_date = conn.execute("SELECT MIN(filing_date) FROM marks WHERE filing_date IS NOT NULL").fetchone()[0]
        max_date = conn.execute("SELECT MAX(filing_date) FROM marks WHERE filing_date IS NOT NULL").fetchone()[0]
        db_size = db.stat().st_size
    finally:
        conn.close()

    data = {
        "version": __version__,
        "database_exists": True,
        "total_marks": total,
        "live_marks": live,
        "dead_marks": dead,
        "last_updated": last_updated[0] if last_updated else None,
        "coverage": {"from": min_date, "to": max_date},
        "db_size_bytes": db_size,
    }

    if json_output:
        _output(data, True)
    else:
        console.print("[bold]chktm corpus status[/bold]")
        console.print(f"  Database:     {db}")
        console.print(f"  Total marks:  {total:,}")
        console.print(f"  Live:         {live:,}")
        console.print(f"  Dead:         {dead:,}")
        console.print(f"  Last updated: {last_updated[0] if last_updated else 'unknown'}")
        console.print(f"  Coverage:     {min_date} to {max_date}")
        console.print(f"  DB size:      {db_size / 1e6:.1f} MB")


@app.command()
def init(
    data_dir: Annotated[
        Optional[Path],
        typer.Option("--data-dir", help="Path to data directory"),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output")] = False,
    keep_zips: Annotated[
        bool,
        typer.Option(
            "--keep-zips",
            help="Keep ZIP files after ingestion (default: delete to save disk)",
        ),
    ] = False,
    off_peak: Annotated[
        bool,
        typer.Option(
            "--off-peak",
            help="Use off-peak rate limits (12 req/min vs 4; best between 10pm-5am EST)",
        ),
    ] = False,
    stream_ingest: Annotated[
        bool,
        typer.Option(
            "--stream-ingest",
            help="Stream XML from ZIP to parser without writing to disk",
        ),
    ] = False,
) -> None:
    """One-time: download and ingest the full trademark corpus.

    Downloads the annual backfile (~22 GB) plus daily files for the current
    year. This is a long-running operation — expect several hours depending on
    your connection speed and USPTO rate limits.

    Downloads and ingestion are pipelined: the next file downloads while the
    current file is being ingested. Use --off-peak for 3x faster downloads
    during USPTO off-peak hours (10pm-5am EST).

    Handles interrupts gracefully (Ctrl+C): finishes the current file, commits
    to the database, and exits. Re-run to resume where you left off.
    """
    import time as _time

    from rich.progress import (
        BarColumn,
        DownloadColumn,
        Progress,
        SpinnerColumn,
        TextColumn,
        TimeElapsedColumn,
        TransferSpeedColumn,
    )

    from chktm.fetch import (
        PRODUCT_ANNUAL,
        PRODUCT_DAILY,
        RATE_NORMAL,
        RATE_OFF_PEAK,
        check_disk_space,
    )
    from chktm.pipeline import run_pipeline, wal_checkpoint
    from chktm.schema import init_db

    resolved = _data_dir(data_dir)
    db = _db_path(resolved)
    zip_dir = resolved / "zips"
    xml_dir = resolved / "xml"
    rate = RATE_OFF_PEAK if off_peak else RATE_NORMAL

    resuming = False
    if db.exists():
        # Check if a previous init was interrupted (DB exists but not completed).
        import sqlite3 as _sqlite3

        _conn = _sqlite3.connect(str(db))
        _conn.execute("PRAGMA busy_timeout=5000")
        try:
            init_done = _conn.execute("SELECT value FROM meta WHERE key = 'init_completed'").fetchone()
        except _sqlite3.OperationalError:
            init_done = None
        _conn.close()

        if init_done:
            # Fully initialized — don't re-init.
            if not json_output:
                console.print(
                    "[yellow]Database already exists.[/yellow] "
                    "Use [bold]chktm update[/bold] to pull new daily files, "
                    "or delete the database to re-init."
                )
            else:
                typer.echo(
                    json.dumps(
                        {
                            "error": "Database already exists. Use 'chktm update' or delete the database.",
                        }
                    )
                )
            raise typer.Exit(EXIT_ERROR)
        else:
            # Incomplete init — resume.
            resuming = True
            if not json_output:
                console.print(
                    "[yellow]Resuming interrupted init...[/yellow] Previously ingested files will be skipped."
                )
            elif json_output:
                typer.echo(json.dumps({"event": "resuming"}))

    # Check disk space before starting (~30 GB needed for download + DB).
    if not resuming:
        try:
            check_disk_space(resolved, 30 * 1024 * 1024 * 1024)
        except RuntimeError as e:
            _error(str(e), json_output)

    if not json_output:
        console.print(f"[bold]Rate limit:[/bold] {'off-peak (12 req/min)' if off_peak else 'normal (4 req/min)'}")

    conn = init_db(db)
    start_time = _time.monotonic()
    total_records = 0
    files_processed = 0
    pipeline_start = _time.monotonic()

    try:
        for product_id, label in [
            (PRODUCT_ANNUAL, "Annual backfile"),
            (PRODUCT_DAILY, "Daily files (current year)"),
        ]:
            if not json_output:
                console.print(f"\n[bold]Downloading {label}...[/bold]")

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TransferSpeedColumn(),
                TimeElapsedColumn(),
                console=console,
                disable=json_output,
            ) as progress:
                file_task = None
                dl_task = None
                current_total_files = 0

                def on_file_start(remote, idx, total):
                    nonlocal file_task, dl_task, current_total_files
                    current_total_files = total
                    desc = f"[{idx + 1}/{total}] {remote.file_name}"
                    if file_task is None:
                        file_task = progress.add_task(desc, total=None)
                    else:
                        progress.update(file_task, description=desc)
                    dl_task = progress.add_task("  downloading", total=remote.file_size or None)

                def on_file_progress(downloaded, total_bytes):
                    if dl_task is not None:
                        progress.update(dl_task, completed=downloaded, total=total_bytes)

                def on_file_done(remote, local_path):
                    if dl_task is not None:
                        progress.remove_task(dl_task)

                def on_ingest_done(remote, count, running_total):
                    nonlocal total_records, files_processed
                    total_records = running_total
                    files_processed += 1

                    if json_output:
                        # JSON progress event for headless/container monitoring.
                        elapsed = _time.monotonic() - pipeline_start
                        avg_per_file = elapsed / files_processed if files_processed else 0
                        remaining = current_total_files - files_processed
                        eta_seconds = avg_per_file * remaining
                        typer.echo(
                            json.dumps(
                                {
                                    "event": "progress",
                                    "file": remote.file_name,
                                    "records_this_file": count,
                                    "total_records": running_total,
                                    "files_processed": files_processed,
                                    "elapsed_seconds": round(elapsed, 1),
                                    "eta_seconds": round(eta_seconds, 0),
                                }
                            )
                        )
                    elif file_task is not None:
                        # Rich progress with ETA.
                        elapsed = _time.monotonic() - pipeline_start
                        avg_per_file = elapsed / files_processed if files_processed else 0
                        remaining = current_total_files - files_processed
                        eta_min = (avg_per_file * remaining) / 60
                        progress.update(
                            file_task,
                            description=(
                                f"[{files_processed}] {remote.file_name} "
                                f"— {count:,} records ({running_total:,} total) "
                                f"~{eta_min:.0f}m remaining"
                            ),
                        )

                # Build skip set from both meta table (ingested) and ZIPs on disk.
                already = set()
                rows = conn.execute("SELECT key FROM meta WHERE key LIKE 'ingested:%'").fetchall()
                for r in rows:
                    already.add(r[0].removeprefix("ingested:"))
                if zip_dir.exists():
                    already.update(p.name for p in zip_dir.iterdir() if p.suffix == ".zip")
                # Commit to close any implicit transaction before pipeline
                # changes PRAGMA settings.
                conn.commit()

                records, files = run_pipeline(
                    product_id,
                    zip_dir,
                    xml_dir,
                    conn,
                    already_downloaded=already,
                    on_file_start=on_file_start,
                    on_file_progress=on_file_progress,
                    on_file_done=on_file_done,
                    on_ingest_done=on_ingest_done,
                    keep_zips=keep_zips,
                    rate_limit=rate,
                    stream_ingest=stream_ingest,
                )
                total_records = records if records > total_records else total_records

        # Record completion metadata.
        from datetime import date

        conn.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
            ("last_update_date", date.today().isoformat()),
        )
        conn.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
            ("init_completed", "true"),
        )
        conn.commit()

        # Save the data directory to config so future commands find it.
        write_config({"data_dir": str(resolved.resolve())})

        # Consolidate WAL file into main DB.
        wal_checkpoint(conn)

    except Exception as e:
        _error(f"Init failed: {e}", json_output)
    finally:
        conn.close()

    elapsed = _time.monotonic() - start_time
    db_size = db.stat().st_size

    result = {
        "version": __version__,
        "status": "complete",
        "total_records": total_records,
        "files_processed": files_processed,
        "elapsed_seconds": round(elapsed, 1),
        "db_size_bytes": db_size,
    }

    if json_output:
        typer.echo(json.dumps(result, indent=2))
    else:
        console.print("\n[bold green]Init complete.[/bold green]")
        console.print(f"  Records:  {total_records:,}")
        console.print(f"  Files:    {files_processed}")
        console.print(f"  Time:     {elapsed / 60:.1f} minutes")
        console.print(f"  DB size:  {db_size / 1e9:.2f} GB")


@app.command()
def update(
    data_dir: Annotated[
        Optional[Path],
        typer.Option("--data-dir", help="Path to data directory"),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output")] = False,
    keep_zips: Annotated[
        bool,
        typer.Option(
            "--keep-zips",
            help="Keep ZIP files after ingestion (default: delete to save disk)",
        ),
    ] = False,
    off_peak: Annotated[
        bool,
        typer.Option("--off-peak", help="Use off-peak rate limits (12 req/min vs 4)"),
    ] = False,
    stream_ingest: Annotated[
        bool,
        typer.Option(
            "--stream-ingest",
            help="Stream XML from ZIP to parser without writing to disk",
        ),
    ] = False,
) -> None:
    """Pull and ingest new daily files since last update.

    Downloads and ingestion are pipelined for faster throughput.
    Handles Ctrl+C gracefully: finishes the current file and exits.
    """
    import sqlite3
    import time as _time

    from rich.progress import (
        BarColumn,
        DownloadColumn,
        Progress,
        SpinnerColumn,
        TextColumn,
        TimeElapsedColumn,
        TransferSpeedColumn,
    )

    from chktm.fetch import PRODUCT_DAILY, RATE_NORMAL, RATE_OFF_PEAK
    from chktm.pipeline import run_pipeline, wal_checkpoint

    resolved = _data_dir(data_dir)
    db = _db_path(resolved)
    zip_dir = resolved / "zips"
    xml_dir = resolved / "xml"

    if not db.exists():
        _error(
            "No database found. Run 'chktm init' first.",
            json_output,
            EXIT_NO_DB,
        )

    conn = sqlite3.connect(str(db))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")

    # Find the most recent ingested date.
    row = conn.execute("SELECT value FROM meta WHERE key = 'last_update_date'").fetchone()
    if not row:
        _error(
            "Cannot determine last update date. Re-run 'chktm init'.",
            json_output,
        )
    last_date = row[0]

    # Find already-ingested files to skip.
    already = set()
    rows = conn.execute("SELECT key FROM meta WHERE key LIKE 'ingested:%'").fetchall()
    for r in rows:
        already.add(r[0].removeprefix("ingested:"))
    if zip_dir.exists():
        already.update(p.name for p in zip_dir.iterdir() if p.suffix == ".zip")
    # Commit to close any implicit transaction before pipeline changes PRAGMAs.
    conn.commit()

    start_time = _time.monotonic()
    total_records = 0
    files_processed = 0

    if not json_output:
        console.print(f"[bold]Updating from {last_date}...[/bold]")

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeElapsedColumn(),
            console=console,
            disable=json_output,
        ) as progress:
            file_task = None
            dl_task = None

            def on_file_start(remote, idx, total):
                nonlocal file_task, dl_task
                desc = f"[{idx + 1}/{total}] {remote.file_name}"
                if file_task is None:
                    file_task = progress.add_task(desc, total=None)
                else:
                    progress.update(file_task, description=desc)
                dl_task = progress.add_task("  downloading", total=remote.file_size or None)

            def on_file_progress(downloaded, total_bytes):
                if dl_task is not None:
                    progress.update(dl_task, completed=downloaded, total=total_bytes)

            def on_file_done(remote, local_path):
                if dl_task is not None:
                    progress.remove_task(dl_task)

            def on_ingest_done(remote, count, running_total):
                nonlocal total_records, files_processed
                total_records = running_total
                files_processed += 1

            rate = RATE_OFF_PEAK if off_peak else RATE_NORMAL

            records, files = run_pipeline(
                PRODUCT_DAILY,
                zip_dir,
                xml_dir,
                conn,
                already_downloaded=already,
                since_date=last_date,
                on_file_start=on_file_start,
                on_file_progress=on_file_progress,
                on_file_done=on_file_done,
                on_ingest_done=on_ingest_done,
                keep_zips=keep_zips,
                rate_limit=rate,
                stream_ingest=stream_ingest,
            )
            total_records = records if records > total_records else total_records
            files_processed = files if files > files_processed else files_processed

        from datetime import date

        conn.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
            ("last_update_date", date.today().isoformat()),
        )
        conn.commit()

        # Consolidate WAL file.
        wal_checkpoint(conn)

    except Exception as e:
        _error(f"Update failed: {e}", json_output)
    finally:
        conn.close()

    elapsed = _time.monotonic() - start_time

    result = {
        "version": __version__,
        "status": "complete",
        "new_records": total_records,
        "files_processed": files_processed,
        "elapsed_seconds": round(elapsed, 1),
    }

    if json_output:
        typer.echo(json.dumps(result, indent=2))
    else:
        if files_processed == 0:
            console.print("[green]Already up to date.[/green]")
        else:
            console.print("\n[bold green]Update complete.[/bold green]")
            console.print(f"  New records: {total_records:,}")
            console.print(f"  Files:       {files_processed}")
            console.print(f"  Time:        {elapsed / 60:.1f} minutes")


@app.command()
def search(
    terms: Annotated[list[str], typer.Argument(help="One or more search terms")],
    classes: Annotated[
        str,
        typer.Option("--classes", help="Comma-separated international class codes"),
    ] = "9,41,42",
    out: Annotated[
        Optional[Path],
        typer.Option("--out", help="Write report to file instead of stdout"),
    ] = None,
    data_dir: Annotated[
        Optional[Path],
        typer.Option("--data-dir", help="Path to data directory"),
    ] = None,
    include_dead: Annotated[
        bool,
        typer.Option("--include-dead", help="Include dead/abandoned marks"),
    ] = False,
    json_output: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output")] = False,
    report: Annotated[
        str,
        typer.Option(
            "--report",
            help="Report type: 'standard' (default) or 'legal' (attorney-ready)",
        ),
    ] = "standard",
) -> None:
    """Screen one or more terms against the trademark corpus.

    Use --report legal to generate an attorney-ready report that includes
    executive summary, component word analysis, risk assessment, limitations,
    and recommended next steps.

    Output format is auto-detected from --out file extension:
    .pdf for PDF, .json for JSON, .md or anything else for Markdown.
    Use --json to force JSON output to stdout.
    """
    import sqlite3

    from chktm.report import (
        render_json,
        render_legal_json,
        render_legal_markdown,
        render_legal_pdf,
        render_markdown,
    )
    from chktm.search import (
        LegalReport,
        extract_components,
    )
    from chktm.search import (
        search as run_search,
    )

    resolved = _data_dir(data_dir)
    db = _db_path(resolved)

    if not db.exists():
        _error(
            "No database found. Run 'chktm init' to download and ingest the trademark corpus.",
            json_output,
            EXIT_NO_DB,
        )

    if report not in ("standard", "legal"):
        _error(
            f"Invalid --report value: {report!r}. Use 'standard' or 'legal'.",
            json_output,
        )

    # Parse class list.
    try:
        class_list = [int(c.strip()) for c in classes.split(",") if c.strip()]
    except ValueError:
        _error(
            f"Invalid --classes value: {classes!r}. Use comma-separated integers.",
            json_output,
        )

    conn = sqlite3.connect(str(db))
    conn.execute("PRAGMA busy_timeout=5000")
    try:
        # Run the main search.
        result = run_search(conn, terms, classes=class_list, include_dead=include_dead)

        if report == "legal":
            # Also run component searches for the legal report.
            components = extract_components(terms)
            component_results: dict[str, object] = {}
            for comp in components:
                if not json_output:
                    console.print(f"  Analyzing component: [bold]{comp}[/bold]...")
                component_results[comp] = run_search(conn, [comp], classes=class_list, include_dead=include_dead)

            corpus_total = conn.execute("SELECT COUNT(*) FROM marks").fetchone()[0]
            corpus_live = conn.execute("SELECT COUNT(*) FROM marks WHERE is_live = 1").fetchone()[0]

            legal = LegalReport(
                proposed_mark=terms[0],
                intended_classes=class_list,
                exact_search=result,
                component_searches=component_results,
                corpus_total=corpus_total,
                corpus_live=corpus_live,
                corpus_date=result.corpus_last_updated,
            )

            # Detect output format from file extension.
            is_pdf = out and str(out).lower().endswith(".pdf")

            if is_pdf:
                render_legal_pdf(legal, str(out))
                console.print(f"PDF report written to [bold]{out}[/bold]")
                return
            elif json_output or (out and str(out).lower().endswith(".json")):
                report_text = render_legal_json(legal)
            else:
                report_text = render_legal_markdown(legal)
        else:
            if json_output or (out and str(out).lower().endswith(".json")):
                report_text = render_json(result)
            else:
                report_text = render_markdown(result)
    finally:
        conn.close()

    if out:
        out.write_text(report_text)
        if not json_output:
            console.print(f"Report written to [bold]{out}[/bold]")
    else:
        typer.echo(report_text)


@app.command()
def diff(
    old_report: Annotated[Path, typer.Argument(help="Path to previous JSON report file")],
    terms: Annotated[list[str], typer.Argument(help="One or more search terms to re-run")],
    classes: Annotated[
        str,
        typer.Option("--classes", help="Comma-separated international class codes"),
    ] = "9,41,42",
    data_dir: Annotated[
        Optional[Path],
        typer.Option("--data-dir", help="Path to data directory"),
    ] = None,
    include_dead: Annotated[
        bool,
        typer.Option("--include-dead", help="Include dead/abandoned marks"),
    ] = False,
    json_output: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output")] = False,
    out: Annotated[
        Optional[Path],
        typer.Option("--out", help="Write diff report to file"),
    ] = None,
) -> None:
    """Compare a previous report with current search results.

    Shows new marks, removed marks, and risk tier changes since the last
    search. Useful for trademark monitoring over time.
    """
    import sqlite3

    from chktm.diff import diff_reports, render_diff_json, render_diff_markdown
    from chktm.report import render_json
    from chktm.search import search as run_search

    if not old_report.exists():
        _error(f"Report file not found: {old_report}", json_output)

    resolved = _data_dir(data_dir)
    db = _db_path(resolved)
    if not db.exists():
        _error("No database found. Run 'chktm init' first.", json_output, EXIT_NO_DB)

    try:
        class_list = [int(c.strip()) for c in classes.split(",") if c.strip()]
    except ValueError:
        _error(f"Invalid --classes value: {classes!r}", json_output)

    # Load old report.
    import json as _json

    old_data = _json.loads(old_report.read_text())

    # Run new search.
    conn = sqlite3.connect(str(db))
    conn.execute("PRAGMA busy_timeout=5000")
    try:
        new_result = run_search(conn, terms, classes=class_list, include_dead=include_dead)
    finally:
        conn.close()

    new_data = _json.loads(render_json(new_result))

    # Compute diff.
    diffs = diff_reports(old_data, new_data)

    if json_output:
        report_text = render_diff_json(diffs)
    else:
        report_text = render_diff_markdown(diffs)

    if out:
        out.write_text(report_text)
        if not json_output:
            console.print(f"Diff report written to [bold]{out}[/bold]")
    else:
        typer.echo(report_text)


@app.command()
def serve(
    data_dir: Annotated[
        Optional[Path],
        typer.Option("--data-dir", help="Path to data directory"),
    ] = None,
    host: Annotated[str, typer.Option("--host", help="Bind address")] = "0.0.0.0",
    port: Annotated[int, typer.Option("--port", help="Port number")] = 8000,
) -> None:
    """Start the web UI and MCP server."""
    import os

    import uvicorn

    resolved = _data_dir(data_dir)
    db = _db_path(resolved)

    if not db.exists():
        console.print("[red]Error:[/red] No database found. Run 'chktm init' first.")
        raise typer.Exit(EXIT_NO_DB)

    # Set the data dir for the web and MCP modules to pick up.
    os.environ["CHKTM_DATA_DIR"] = str(resolved)

    console.print("[bold]Starting chktm server[/bold]")
    console.print(f"  Web UI:          http://{host}:{port}/")
    console.print(f"  REST API:        http://{host}:{port}/api/")
    console.print(f"  MCP (HTTP):      http://{host}:{port}/mcp/")
    console.print(f"  MCP (SSE):       http://{host}:{port}/mcp/sse/")
    console.print(f"  Database:        {db}")

    from chktm.mcp_server import create_app

    uvicorn_app = create_app()
    uvicorn.run(uvicorn_app, host=host, port=port)
