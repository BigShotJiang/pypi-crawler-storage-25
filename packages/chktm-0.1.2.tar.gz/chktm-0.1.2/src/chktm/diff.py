# SPDX-License-Identifier: Apache-2.0
"""Compare two search results to surface new, removed, and changed marks."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from chktm import __version__
from chktm.disclaimer import DISCLAIMER


@dataclass
class DiffEntry:
    """A single mark that changed between two search runs."""

    serial_number: str
    wordmark: str
    change: str  # "new", "removed", "risk_changed"
    old_risk: str | None = None
    new_risk: str | None = None
    owner_name: str | None = None
    classes: list[int] = field(default_factory=list)
    tsdr_url: str = ""


@dataclass
class DiffResult:
    """Comparison between two search runs."""

    term: str
    old_date: str
    new_date: str
    new_marks: list[DiffEntry] = field(default_factory=list)
    removed_marks: list[DiffEntry] = field(default_factory=list)
    risk_changed: list[DiffEntry] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return bool(self.new_marks or self.removed_marks or self.risk_changed)


def diff_reports(old_json: dict, new_json: dict) -> list[DiffResult]:
    """Compare two chktm JSON search results and return differences.

    Args:
        old_json: Parsed JSON from a previous search (standard or legal).
        new_json: Parsed JSON from a new search.

    Returns:
        List of DiffResult, one per term.
    """
    old_date = old_json.get("timestamp", "unknown")
    new_date = new_json.get("timestamp", "unknown")

    # Build lookup of old results by term.
    old_by_term: dict[str, dict[str, dict]] = {}
    old_results = old_json.get("results", [])
    # Handle legal report format (nested under exact_search).
    if not old_results and "exact_search" in old_json:
        old_results = old_json["exact_search"].get("results", [])
    for tr in old_results:
        matches_by_serial = {}
        for m in tr.get("matches", []):
            matches_by_serial[m["serial_number"]] = m
        old_by_term[tr["term"]] = matches_by_serial

    # Build new results by term.
    new_results = new_json.get("results", [])
    if not new_results and "exact_search" in new_json:
        new_results = new_json["exact_search"].get("results", [])

    diffs: list[DiffResult] = []

    for tr in new_results:
        term = tr["term"]
        new_matches = {m["serial_number"]: m for m in tr.get("matches", [])}
        old_matches = old_by_term.get(term, {})

        result = DiffResult(term=term, old_date=old_date, new_date=new_date)

        # New marks (in new but not old).
        for serial, m in new_matches.items():
            if serial not in old_matches:
                result.new_marks.append(
                    DiffEntry(
                        serial_number=serial,
                        wordmark=m.get("wordmark", ""),
                        change="new",
                        new_risk=m.get("risk"),
                        owner_name=m.get("owner_name"),
                        classes=m.get("classes", []),
                        tsdr_url=m.get("tsdr_url", ""),
                    )
                )

        # Removed marks (in old but not new).
        for serial, m in old_matches.items():
            if serial not in new_matches:
                result.removed_marks.append(
                    DiffEntry(
                        serial_number=serial,
                        wordmark=m.get("wordmark", ""),
                        change="removed",
                        old_risk=m.get("risk"),
                        owner_name=m.get("owner_name"),
                        classes=m.get("classes", []),
                        tsdr_url=m.get("tsdr_url", ""),
                    )
                )

        # Risk changed (in both, but risk tier changed).
        for serial in new_matches:
            if serial in old_matches:
                old_risk = old_matches[serial].get("risk")
                new_risk = new_matches[serial].get("risk")
                if old_risk != new_risk:
                    m = new_matches[serial]
                    result.risk_changed.append(
                        DiffEntry(
                            serial_number=serial,
                            wordmark=m.get("wordmark", ""),
                            change="risk_changed",
                            old_risk=old_risk,
                            new_risk=new_risk,
                            owner_name=m.get("owner_name"),
                            classes=m.get("classes", []),
                            tsdr_url=m.get("tsdr_url", ""),
                        )
                    )

        diffs.append(result)

    return diffs


def render_diff_markdown(diffs: list[DiffResult]) -> str:
    """Render diff results as Markdown."""
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    lines = [
        "# chktm Diff Report",
        "",
        f"Generated: {now}",
        "",
    ]

    any_changes = any(d.has_changes for d in diffs)
    if not any_changes:
        lines.append("**No changes detected.** All search results are identical.")
        return "\n".join(lines)

    for d in diffs:
        lines.append(f"## Term: {d.term}")
        lines.append(f"Compared: {d.old_date} → {d.new_date}")
        lines.append("")

        if not d.has_changes:
            lines.append("No changes.")
            lines.append("")
            continue

        if d.new_marks:
            lines.append(f"### New marks ({len(d.new_marks)})")
            lines.append("")
            for e in d.new_marks:
                cls = ", ".join(str(c) for c in e.classes)
                lines.append(
                    f"- **{e.wordmark}** [{e.new_risk}] — "
                    f"Serial: {e.serial_number}, Owner: {e.owner_name or '?'}, "
                    f"Classes: {cls}"
                )
            lines.append("")

        if d.removed_marks:
            lines.append(f"### Removed marks ({len(d.removed_marks)})")
            lines.append("")
            for e in d.removed_marks:
                lines.append(f"- ~~{e.wordmark}~~ [{e.old_risk}] — Serial: {e.serial_number}")
            lines.append("")

        if d.risk_changed:
            lines.append(f"### Risk changed ({len(d.risk_changed)})")
            lines.append("")
            for e in d.risk_changed:
                lines.append(f"- **{e.wordmark}** {e.old_risk} → {e.new_risk} — Serial: {e.serial_number}")
            lines.append("")

    lines.extend(["---", "", f"*{DISCLAIMER}*", ""])
    return "\n".join(lines)


def render_diff_json(diffs: list[DiffResult]) -> str:
    """Render diff results as JSON."""
    data: dict[str, Any] = {
        "version": __version__,
        "report_type": "diff",
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "diffs": [],
    }

    for d in diffs:
        diff_data: dict[str, Any] = {
            "term": d.term,
            "old_date": d.old_date,
            "new_date": d.new_date,
            "new_marks": [
                {
                    "serial": e.serial_number,
                    "wordmark": e.wordmark,
                    "risk": e.new_risk,
                    "owner": e.owner_name,
                    "classes": e.classes,
                }
                for e in d.new_marks
            ],
            "removed_marks": [
                {"serial": e.serial_number, "wordmark": e.wordmark, "risk": e.old_risk} for e in d.removed_marks
            ],
            "risk_changed": [
                {
                    "serial": e.serial_number,
                    "wordmark": e.wordmark,
                    "old_risk": e.old_risk,
                    "new_risk": e.new_risk,
                }
                for e in d.risk_changed
            ],
        }
        data["diffs"].append(diff_data)

    return json.dumps(data, indent=2, default=str)
