# SPDX-License-Identifier: Apache-2.0
"""Pipelined download + ingest with resilience features."""

from __future__ import annotations

import logging
import signal
import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from queue import Queue
from typing import Callable

from chktm.fetch import (
    RemoteFile,
    download_product_files,
    extract_zip,
    stream_extract_zip,
)
from chktm.ingest import ingest_xml

logger = logging.getLogger(__name__)

# Sentinel value to signal the ingest thread to stop.
_DONE = None


@dataclass
class IngestResult:
    """Result of ingesting one file."""

    remote: RemoteFile
    record_count: int


def run_pipeline(
    product_id: str,
    zip_dir: Path,
    xml_dir: Path,
    conn: sqlite3.Connection,
    *,
    already_downloaded: set[str] | None = None,
    since_date: str | None = None,
    on_file_start: Callable | None = None,
    on_file_progress: Callable | None = None,
    on_file_done: Callable | None = None,
    on_ingest_done: Callable | None = None,
    rate_limit: float = 16.0,
    keep_zips: bool = False,
    stream_ingest: bool = False,
) -> tuple[int, int]:
    """Download and ingest files with overlapped execution.

    The download thread fetches ZIP files respecting the rate limit while the
    main thread extracts and ingests the previous file into SQLite. This
    overlaps the ~8s ingest time with the ~16s rate-limit wait.

    Args:
        product_id: ODP product identifier.
        zip_dir: Directory for downloaded ZIPs.
        xml_dir: Directory for extracted XML (temporary, unused if stream_ingest).
        conn: Open SQLite connection.
        already_downloaded: File names to skip.
        since_date: Only download files with from_date >= this.
        on_file_start: Callback(remote, idx, total) before each download.
        on_file_progress: Callback(bytes_downloaded, total_bytes) during download.
        on_file_done: Callback(remote, local_path) after download completes.
        on_ingest_done: Callback(remote, record_count, total_records) after ingest.
        rate_limit: Seconds between download starts.
        keep_zips: If False (default), delete ZIP files after successful ingestion.
        stream_ingest: If True, stream XML directly from ZIP to parser without
                       writing to disk (lower disk I/O, same memory usage).

    Returns:
        (total_records, files_processed) tuple.
    """
    # Queue holds (RemoteFile, Path) pairs; max 2 items to bound memory.
    queue: Queue[tuple[RemoteFile, Path] | None] = Queue(maxsize=2)
    download_error: list[Exception] = []

    # Graceful shutdown: set this flag on SIGINT/SIGTERM to finish the
    # current file and exit cleanly.
    shutdown_requested = threading.Event()

    def _signal_handler(signum, frame):
        logger.warning("Shutdown requested (signal %d) — finishing current file", signum)
        shutdown_requested.set()

    # Install signal handlers (main thread only).
    old_sigint = signal.signal(signal.SIGINT, _signal_handler)
    old_sigterm = None
    try:
        old_sigterm = signal.signal(signal.SIGTERM, _signal_handler)
    except (OSError, ValueError):
        pass  # SIGTERM not available on Windows in some contexts

    def _download_thread():
        """Producer: download files and put them on the queue."""
        try:
            for remote, zip_path in download_product_files(
                product_id,
                zip_dir,
                already_downloaded=already_downloaded,
                since_date=since_date,
                on_file_start=on_file_start,
                on_file_progress=on_file_progress,
                on_file_done=on_file_done,
                rate_limit=rate_limit,
            ):
                queue.put((remote, zip_path))
                if shutdown_requested.is_set():
                    break
        except Exception as e:
            download_error.append(e)
        finally:
            queue.put(_DONE)

    # Start the download thread.
    dl_thread = threading.Thread(target=_download_thread, daemon=True)
    dl_thread.start()

    # Consumer: extract and ingest from the queue on the main thread.
    # Start the counter from the current DB total so progress events
    # reflect the real corpus size, not just this session's additions.
    total_records = conn.execute("SELECT COUNT(*) FROM marks").fetchone()[0]
    conn.commit()  # Close implicit transaction from the SELECT.
    files_processed = 0

    try:
        while True:
            item = queue.get()
            if item is _DONE:
                break

            remote, zip_path = item

            if stream_ingest:
                # Stream directly from ZIP → iterparse without writing XML to disk.
                for _name, xml_stream in stream_extract_zip(zip_path):
                    count = ingest_xml(xml_stream, conn)
                    total_records += count
                    files_processed += 1
            else:
                # Extract to disk, then ingest.
                xml_files = extract_zip(zip_path, xml_dir)
                for xml_path in xml_files:
                    count = ingest_xml(xml_path, conn)
                    total_records += count
                    files_processed += 1
                    xml_path.unlink(missing_ok=True)

            # Record this file as ingested.
            conn.execute(
                "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
                (f"ingested:{remote.file_name}", remote.to_date),
            )
            conn.commit()

            # Clean up the ZIP to save disk space.
            if not keep_zips:
                zip_path.unlink(missing_ok=True)

            if on_ingest_done:
                on_ingest_done(remote, count, total_records)

            # Check for graceful shutdown after completing current file.
            if shutdown_requested.is_set():
                logger.info("Shutdown: finished current file, exiting pipeline")
                # Drain the queue so the download thread can exit.
                while not queue.empty():
                    queue.get()
                break
    finally:
        # Restore original signal handlers.
        signal.signal(signal.SIGINT, old_sigint)
        if old_sigterm is not None:
            signal.signal(signal.SIGTERM, old_sigterm)

    dl_thread.join(timeout=10)

    # Re-raise any download error (unless we're shutting down).
    if download_error and not shutdown_requested.is_set():
        raise download_error[0]

    return total_records, files_processed


def wal_checkpoint(conn: sqlite3.Connection) -> None:
    """Run a WAL checkpoint to consolidate the WAL file into the main database.

    Call after large bulk operations (init, update) to prevent the WAL file
    from growing unbounded. Uses TRUNCATE mode which resets the WAL to zero size.
    """
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    logger.info("WAL checkpoint complete")
