# SPDX-License-Identifier: Apache-2.0
"""Query engine: normalized substring matching with risk-tier classification."""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass, field
from enum import Enum

from chktm.schema import normalize, phonetic_code, status_description

# Cap results per term to prevent unbounded memory/response size.
_MAX_RESULTS = 1000
# Maximum length for a single search term (bytes after normalization).
_MAX_TERM_LENGTH = 200


class Risk(str, Enum):
    """Risk tier for a trademark match."""

    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


@dataclass
class Match:
    """A single trademark match result."""

    serial_number: str
    registration_number: str | None
    wordmark: str
    status_code: str | None
    status_label: str
    is_live: bool
    filing_date: str | None
    registration_date: str | None
    mark_drawing_code: str | None
    owner_name: str | None
    classes: list[int]
    goods_services: str | None
    risk: Risk

    @property
    def tsdr_url(self) -> str:
        return f"https://tsdr.uspto.gov/#caseNumber={self.serial_number}&caseType=SERIAL_NO"


@dataclass
class TermResult:
    """All matches for a single search term."""

    term: str
    matches: list[Match] = field(default_factory=list)

    @property
    def high(self) -> list[Match]:
        return [m for m in self.matches if m.risk == Risk.HIGH]

    @property
    def medium(self) -> list[Match]:
        return [m for m in self.matches if m.risk == Risk.MEDIUM]

    @property
    def low(self) -> list[Match]:
        return [m for m in self.matches if m.risk == Risk.LOW]


@dataclass
class SearchResult:
    """Aggregate results across all search terms."""

    terms: list[str]
    filter_classes: list[int]
    include_dead: bool
    total_active_marks: int
    corpus_last_updated: str | None
    term_results: list[TermResult] = field(default_factory=list)

    @property
    def total_high(self) -> int:
        return sum(len(tr.high) for tr in self.term_results)

    @property
    def total_medium(self) -> int:
        return sum(len(tr.medium) for tr in self.term_results)

    @property
    def total_low(self) -> int:
        return sum(len(tr.low) for tr in self.term_results)


def search(
    conn: sqlite3.Connection,
    terms: list[str],
    *,
    classes: list[int] | None = None,
    include_dead: bool = False,
) -> SearchResult:
    """Search the trademark corpus for potential conflicts.

    Args:
        conn: Open SQLite connection to the chktm database.
        terms: One or more search terms.
        classes: International class codes to filter for HIGH risk.
                 Defaults to [9, 41, 42].
        include_dead: If True, include dead/abandoned marks as LOW risk.

    Returns:
        SearchResult with matches grouped by term and risk tier.
    """
    if classes is None:
        classes = [9, 41, 42]

    # Corpus stats.
    total_active = conn.execute("SELECT COUNT(*) FROM marks WHERE is_live = 1").fetchone()[0]
    last_updated_row = conn.execute("SELECT value FROM meta WHERE key = 'last_update_date'").fetchone()
    last_updated = last_updated_row[0] if last_updated_row else None

    result = SearchResult(
        terms=terms,
        filter_classes=classes,
        include_dead=include_dead,
        total_active_marks=total_active,
        corpus_last_updated=last_updated,
    )

    class_set = set(classes)

    for term in terms:
        norm_term = normalize(term)
        if not norm_term:
            continue
        # Reject excessively long terms to prevent expensive LIKE scans.
        if len(norm_term) > _MAX_TERM_LENGTH:
            norm_term = norm_term[:_MAX_TERM_LENGTH]

        term_result = TermResult(term=term)

        # Query: find marks by normalized substring, phonetic (Soundex), and
        # fuzzy (Levenshtein distance) matching.
        # Escape SQL LIKE wildcards (OWASP A03:2021).
        escaped = norm_term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        pattern = f"%{escaped}%"
        soundex = phonetic_code(term)

        _COLS = """serial_number, registration_number, wordmark,
                   status_code, is_live, filing_date, registration_date,
                   mark_drawing_code, owner_name, goods_services"""
        live_filter = "" if include_dead else " AND is_live = 1"

        # Substring + phonetic matches (indexed, fast).
        rows = conn.execute(
            f"""SELECT {_COLS} FROM marks
                WHERE (wordmark_normalized LIKE ? ESCAPE '\\'
                       OR wordmark_soundex = ?)
                {live_filter}
                LIMIT ?""",
            (pattern, soundex, _MAX_RESULTS),
        ).fetchall()

        # Fuzzy matching: find near-misses via Levenshtein distance.
        # Only practical for short terms (long terms have too many candidates).
        # We search soundex candidates and filter by edit distance.
        if len(norm_term) >= 3 and len(rows) < _MAX_RESULTS:
            import jellyfish

            max_dist = max(1, len(norm_term) // 4)  # ~25% edit distance
            seen = {r[0] for r in rows}  # serials already matched

            fuzzy_candidates = conn.execute(
                f"""SELECT {_COLS}, wordmark_normalized FROM marks
                    WHERE wordmark_soundex = ?
                    {live_filter}
                    LIMIT ?""",
                (soundex, _MAX_RESULTS * 2),
            ).fetchall()

            for candidate in fuzzy_candidates:
                if candidate[0] in seen:
                    continue
                cand_norm = candidate[10]  # wordmark_normalized
                if abs(len(cand_norm) - len(norm_term)) > max_dist:
                    continue
                dist = jellyfish.levenshtein_distance(norm_term, cand_norm)
                if dist <= max_dist:
                    rows.append(candidate[:10])
                    seen.add(candidate[0])

        # Batch-fetch class associations for all matched serials to avoid
        # N+1 queries (one per match). Uses chunked IN clauses.
        serials = [row[0] for row in rows]
        classes_map: dict[str, list[int]] = {s: [] for s in serials}
        _CHUNK = 999
        for i in range(0, len(serials), _CHUNK):
            chunk = serials[i : i + _CHUNK]
            placeholders = ",".join("?" * len(chunk))
            for r in conn.execute(
                f"SELECT serial_number, intl_class FROM mark_classes WHERE serial_number IN ({placeholders})",
                chunk,
            ).fetchall():
                classes_map[r[0]].append(r[1])

        for row in rows:
            serial = row[0]
            mark_classes = classes_map.get(serial, [])
            is_live = bool(row[4])

            # Determine risk tier.
            if not is_live:
                risk = Risk.LOW
            elif class_set & set(mark_classes):
                risk = Risk.HIGH
            else:
                risk = Risk.MEDIUM

            term_result.matches.append(
                Match(
                    serial_number=serial,
                    registration_number=row[1],
                    wordmark=row[2],
                    status_code=row[3],
                    status_label=status_description(row[3]),
                    is_live=is_live,
                    filing_date=row[5],
                    registration_date=row[6],
                    mark_drawing_code=row[7],
                    owner_name=row[8],
                    classes=mark_classes,
                    goods_services=row[9],
                    risk=risk,
                )
            )

        # Sort: HIGH first, then MEDIUM, then LOW. Within each tier, by wordmark.
        tier_order = {Risk.HIGH: 0, Risk.MEDIUM: 1, Risk.LOW: 2}
        term_result.matches.sort(key=lambda m: (tier_order[m.risk], m.wordmark.lower()))

        result.term_results.append(term_result)

    return result


def extract_components(terms: list[str]) -> list[str]:
    """Extract unique component words from compound terms.

    Splits on whitespace, hyphens, and camelCase boundaries. Returns
    components that are at least 3 characters and not already in the
    original terms list (normalized).

    Example: ["hellaenergy", "hella energy"] → ["hella", "energy"]
    """
    norm_originals = {normalize(t) for t in terms}
    components: set[str] = set()

    for term in terms:
        # Split on whitespace and hyphens.
        parts = re.split(r"[\s\-]+", term)
        for part in parts:
            p = part.strip().lower()
            if len(p) >= 3 and p not in norm_originals:
                components.add(p)

    return sorted(components)


@dataclass
class LegalReport:
    """Data for an attorney-ready trademark screening report."""

    proposed_mark: str
    intended_classes: list[int]
    exact_search: SearchResult
    component_searches: dict[str, SearchResult]
    corpus_total: int
    corpus_live: int
    corpus_date: str | None
