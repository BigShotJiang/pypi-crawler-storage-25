# SPDX-License-Identifier: Apache-2.0
"""MCP (Model Context Protocol) server for chktm.

Exposes trademark search as tools that AI agents can call.
Supports stdio transport (local) and SSE/Streamable HTTP (remote).
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from mcp.server import FastMCP

from chktm import __version__
from chktm.config import resolve_data_dir
from chktm.diff import diff_reports, render_diff_json
from chktm.report import render_json, render_legal_json
from chktm.search import LegalReport, extract_components
from chktm.search import search as run_search

_DATA_DIR = resolve_data_dir()

mcp = FastMCP(
    "chktm",
    instructions=(
        "US trademark corpus screening. Call corpus_status once, then "
        "search_trademarks with all term variants in one call. Use "
        "generate_legal_report for attorney-ready output. Zero results "
        "does NOT mean safe — always advise consulting an attorney. "
        "Research aid, not legal clearance."
    ),
)

# Set the version reported in the MCP protocol initialize handshake.
# FastMCP doesn't expose this in its constructor, so we set it on the
# underlying Server instance directly.
mcp._mcp_server.version = __version__


def _db_path() -> Path:
    return _DATA_DIR / "chktm.db"


def _get_conn() -> sqlite3.Connection:
    db = _db_path()
    if not db.exists():
        raise FileNotFoundError(
            "Database not initialized. Run 'chktm init' to download and ingest the trademark corpus."
        )
    conn = sqlite3.connect(str(db))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


@mcp.tool()
def search_trademarks(
    terms: list[str],
    classes: list[int] | None = None,
    include_dead: bool = False,
) -> str:
    """Search the US trademark corpus for potential conflicts with proposed marks.

    EFFICIENCY: Pass ALL term variants in a single call rather than making
    separate calls per variant. This tool accepts a list and returns results
    for all terms in one response.

    Args:
        terms: One or more proposed mark names to screen (e.g., ["thundercorp",
               "thunder corp", "thunder-corp", "thunder"]). Each term is checked
               independently. The search is case-insensitive and ignores
               whitespace/hyphens. Include the concatenated form, spaced form,
               hyphenated form, and individual components for thorough screening.
        classes: International class codes to check for overlap (determines HIGH
                 vs MEDIUM risk). Defaults to [9, 41, 42] (software, entertainment,
                 SaaS). Common classes: 9=software, 25=clothing, 35=advertising,
                 41=entertainment, 42=SaaS/tech services. Only pass classes
                 relevant to the user's industry — passing all 45 inflates the
                 response with less signal.
        include_dead: If True, include dead/abandoned/expired marks as LOW risk
                      matches. Default False — leave off unless specifically asked,
                      as dead marks roughly double the response size.

    Returns:
        JSON string with search results grouped by term and risk tier:
        - HIGH: Live mark, name matches, AND shares at least one class.
        - MEDIUM: Live mark, name matches, but no class overlap.
        - LOW: Dead/abandoned mark (only if include_dead=True).

        The response includes a "summary" object with counts (high/medium/low)
        that can be reported to the user without parsing every match. For HIGH
        matches, relay the wordmark, owner, classes, and tsdr_url to the user.

        IMPORTANT: Zero results does NOT mean the name is safe. This tool only
        checks registered/pending US trademarks via substring matching. Phonetic
        conflicts, design marks, common-law usage, and foreign marks are not
        checked. Always advise the user to consult an attorney.
    """
    if classes is None:
        classes = [9, 41, 42]

    conn = _get_conn()
    try:
        result = run_search(conn, terms, classes=classes, include_dead=include_dead)
    finally:
        conn.close()

    return render_json(result)


@mcp.tool()
def corpus_status() -> str:
    """Check the status of the local trademark corpus database.

    Returns JSON with: total marks, live/dead counts, last update date,
    date coverage range, and database size. Use this to verify the corpus
    is initialized and up to date before searching.

    EFFICIENCY: Call this once at the start of a session, not before every
    search. The corpus does not change between calls within a conversation.
    """
    try:
        conn = _get_conn()
    except FileNotFoundError as e:
        return json.dumps(
            {
                "database_exists": False,
                "error": str(e),
            }
        )

    try:
        total = conn.execute("SELECT COUNT(*) FROM marks").fetchone()[0]
        live = conn.execute("SELECT COUNT(*) FROM marks WHERE is_live = 1").fetchone()[0]
        last_updated = conn.execute("SELECT value FROM meta WHERE key = 'last_update_date'").fetchone()
        min_date = conn.execute("SELECT MIN(filing_date) FROM marks WHERE filing_date IS NOT NULL").fetchone()[0]
        max_date = conn.execute("SELECT MAX(filing_date) FROM marks WHERE filing_date IS NOT NULL").fetchone()[0]
        db_size = _db_path().stat().st_size
    finally:
        conn.close()

    return json.dumps(
        {
            "database_exists": True,
            "total_marks": total,
            "live_marks": live,
            "dead_marks": total - live,
            "last_updated": last_updated[0] if last_updated else None,
            "coverage": {"from": min_date, "to": max_date},
            "db_size_bytes": db_size,
        }
    )


@mcp.tool()
def generate_legal_report(
    terms: list[str],
    classes: list[int] | None = None,
) -> str:
    """Generate an attorney-ready trademark screening report.

    This performs a comprehensive search: exact matches on all term variants,
    plus broader component-word searches to identify marks a trademark examiner
    could cite. Returns a structured JSON report with executive summary, exact
    results, component analysis, limitations, and recommended next steps.

    Use this instead of search_trademarks when the user needs a report for a
    legal professional or is making a filing decision.

    Args:
        terms: Proposed mark variants (e.g., ["thundercorp", "thunder corp",
               "thunder-corp"]). The first term is used as the report title.
        classes: International class codes for the intended use. Defaults to
                 [9, 41, 42].

    Returns:
        JSON legal report with exact_search results, component_searches
        (automatic broader analysis), corpus stats, and disclaimer.
    """
    if classes is None:
        classes = [9, 41, 42]

    conn = _get_conn()
    try:
        # Exact search on all variants.
        exact = run_search(conn, terms, classes=classes, include_dead=True)

        # Component word searches.
        components = extract_components(terms)
        component_results: dict[str, object] = {}
        for comp in components:
            component_results[comp] = run_search(conn, [comp], classes=classes, include_dead=False)

        corpus_total = conn.execute("SELECT COUNT(*) FROM marks").fetchone()[0]
        corpus_live = conn.execute("SELECT COUNT(*) FROM marks WHERE is_live = 1").fetchone()[0]

        report = LegalReport(
            proposed_mark=terms[0],
            intended_classes=classes,
            exact_search=exact,
            component_searches=component_results,
            corpus_total=corpus_total,
            corpus_live=corpus_live,
            corpus_date=exact.corpus_last_updated,
        )
    finally:
        conn.close()

    return render_legal_json(report)


@mcp.tool()
def compare_searches(
    old_report_json: str,
    terms: list[str],
    classes: list[int] | None = None,
    include_dead: bool = False,
) -> str:
    """Compare a previous search result with a new search to find changes.

    Shows new marks, removed marks, and risk tier changes since the last
    search. Useful for trademark monitoring over time.

    Args:
        old_report_json: JSON string from a previous search_trademarks or
                         generate_legal_report call.
        terms: The same search terms to re-run for comparison.
        classes: International class codes (default: [9, 41, 42]).
        include_dead: Include dead marks in the comparison.

    Returns:
        JSON diff report with new_marks, removed_marks, and risk_changed
        arrays for each search term.
    """
    if classes is None:
        classes = [9, 41, 42]

    old_data = json.loads(old_report_json)

    conn = _get_conn()
    try:
        new_result = run_search(conn, terms, classes=classes, include_dead=include_dead)
    finally:
        conn.close()

    new_data = json.loads(render_json(new_result))
    diffs = diff_reports(old_data, new_data)
    return render_diff_json(diffs)


def create_app():
    """Create the combined FastAPI + MCP application.

    Mounts the MCP SSE transport at /mcp and the streamable HTTP transport
    at /mcp/http alongside the web UI.
    """
    from chktm.web import app as web_app

    # Mount MCP transports on the FastAPI app.
    mcp_sse = mcp.sse_app()
    mcp_http = mcp.streamable_http_app()
    web_app.mount("/mcp/sse", mcp_sse)
    web_app.mount("/mcp", mcp_http)

    return web_app


# Entry point for `python -m chktm.mcp_server` (stdio transport for local use).
if __name__ == "__main__":
    mcp.run(transport="stdio")
