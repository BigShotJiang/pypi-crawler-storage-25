# AGENTS.md

Instructions for AI coding agents working in this repo.

## Source of truth

`SPEC.md` is the authoritative scope for v0.1. If this file and SPEC.md disagree
about *what* to build, SPEC.md wins. This file governs *how* to build it.

Anything not in SPEC.md's v0.1 scope goes in `BACKLOG.md`, not in the code.

## Build in phases, stop between them

SPEC.md defines five phases. Treat the stops between phases as hard stops:
finish the phase, report results to the human, and wait for a go-ahead before
starting the next one. Do not chain phases together unprompted.

Phase 1 in particular is a **recon-only** phase. Do not write application code
during Phase 1. Verify the live USPTO Open Data Portal (data.uspto.gov) details
firsthand — URL patterns, file formats, schema, update cadence — and produce a
short written recon report. The rest of the build depends on this being right.

## Time budget

Target: 8–12 hours total across all phases.
Hard stop: 16 hours. If you hit 16 hours and v0.1 is not shipped, stop and
surface the problem. Do not silently keep going.

## Scope discipline

- If a change feels like it's growing the scope, stop and ask.
- "While I'm here" refactors are not free. Skip them unless they're load-bearing
  for the current phase.
- New dependencies need a one-line justification in the commit message.
- DuckDB vs SQLite is an open call per SPEC.md — if you pick DuckDB, document
  why in the commit and in `README.md`.

## Commits

- Sign off every commit: `git commit -s` (DCO, no CLA — see SPEC.md).
- Conventional-ish messages are fine but not required. Clarity beats format.
- One logical change per commit. Recon notes, schema, ingest, fetch, search,
  report, docs — these should not all land in one commit.
- Never commit downloaded USPTO data, the SQLite database, or anything under
  `data/`. Add to `.gitignore` early.

## Code conventions

- Python 3.11+.
- `pyproject.toml` with `hatchling` or `setuptools` — your call, document it.
- Formatter: `ruff format`. Linter: `ruff check`. No black, no flake8, no isort.
- Type hints on all public functions. `from __future__ import annotations` at
  the top of every module.
- Apache-2.0 SPDX header at the top of every source file:
  `# SPDX-License-Identifier: Apache-2.0`
- CLI framework: Typer (per SPEC.md). Don't substitute Click or argparse.

## Testing

- `pytest`. Fixtures live under `tests/fixtures/`.
- Every module in `src/chktm/` should have a corresponding `test_*.py`.
- Tests must not hit the network. If a test needs USPTO data, it uses a
  checked-in fixture XML file under `tests/fixtures/`.
- `pytest` with no arguments must pass before any phase is considered done.

## The disclaimer is load-bearing

chktm is a research aid, not legal clearance. That sentence (or a close
variant) must appear in: `README.md`, `--help` output, every generated report,
and the top of `src/chktm/disclaimer.py` as the single source of truth that
the other surfaces import from. Do not paraphrase it into something softer.

## When in doubt

Stop and ask the human. A two-line clarifying question is cheaper than an
hour of work in the wrong direction.
