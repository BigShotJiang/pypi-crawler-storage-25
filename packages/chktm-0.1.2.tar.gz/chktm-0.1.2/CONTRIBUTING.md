# Contributing to chktm

Thanks for your interest in contributing. chktm is deliberately small — it does
one thing (trademark screening) and tries to do it well.

## Scope philosophy

We are deliberately small. Features outside the v0.1 scope are tracked in
[BACKLOG.md](BACKLOG.md) and considered case-by-case. PRs that add scope without
discussion will be asked to open an issue first.

## Getting started

### Prerequisites

- Python 3.11+ (Linux, macOS, or Windows — CI tests on Ubuntu, Windows, macOS, and Fedora 42/43)
- Git
- A free [USPTO ODP API key](https://data.uspto.gov/apis/getting-started)
  (only needed for `chktm init` / `chktm update`, not for development)

### Setup

**Linux / macOS:**

```bash
git clone https://github.com/nickschuetz/chktm.git
cd chktm
pip install -e .
```

**Windows (PowerShell):**

```powershell
git clone https://github.com/nickschuetz/chktm.git
cd chktm
pip install -e .
```

The install command is identical across platforms. If your system uses `pip3`
instead of `pip`, substitute accordingly.

### Run tests

**All platforms:**

```bash
pytest
```

The test suite has 128 tests covering all modules: schema, ingest, search,
report, config, diff, fetch, web API, CLI commands, and MCP server tools.

Tests must not hit the network. They use checked-in fixture XML files under
`tests/fixtures/` and temp databases. All tests must pass before any PR is
merged.

### Code style

- Formatter: `ruff format`
- Linter: `ruff check`
- Type hints on all public functions
- `from __future__ import annotations` at the top of every module
- Apache-2.0 SPDX header at the top of every source file:
  `# SPDX-License-Identifier: Apache-2.0`

**All platforms:**

```bash
ruff format src/ tests/
ruff check src/ tests/
```

### Platform notes for contributors

- **Paths:** Always use `pathlib.Path`, never hardcoded `/` or `\` separators.
- **Environment variables:** Document both `export` (Linux/macOS) and
  `$env:` (Windows PowerShell) forms when referencing env vars in docs.
- **Line endings:** The repo uses LF line endings. Git's `core.autocrlf`
  handles conversion on Windows.
- **Shell commands:** If a command differs between platforms, show all variants.
  Commands that work identically everywhere need only be shown once.

## Commits

### DCO sign-off

All commits must be signed off under the
[Developer Certificate of Origin](https://developercertificate.org/):

```bash
git commit -s -m "your commit message"
```

This adds a `Signed-off-by:` line to your commit message, certifying that you
wrote the code or have the right to submit it under the project's license.

### Commit messages

- Clarity beats format. Conventional commits are fine but not required.
- One logical change per commit.
- Never commit downloaded USPTO data, the SQLite database, or anything under
  `data/`.

## Pull requests

1. Open an issue first for anything beyond a trivial bug fix.
2. Keep PRs focused — one logical change per PR.
3. All tests must pass.
4. `ruff format` and `ruff check` must pass with no errors.
5. Update `CHANGELOG.md` under `[Unreleased]` with a brief description.

## What not to contribute (yet)

These are tracked in BACKLOG.md and not ready for PRs:

- Fuzzy/phonetic matching
- Web UI beyond the current lightweight search form
- Multi-jurisdiction support
- PyPI publishing
- Common-law usage checks

If you want to work on any of these, open an issue to discuss approach first.

## The disclaimer is load-bearing

chktm is a research aid, not legal clearance. That sentence must appear in:
the README, `--help` output, every generated report, and `src/chktm/disclaimer.py`
as the single source of truth. Do not paraphrase it into something softer.

## Questions?

Open an issue. A two-line clarifying question is cheaper than an hour of work
in the wrong direction.
