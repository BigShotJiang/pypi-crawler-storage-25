# chktm — Specification (v0.1)

## What it is

A small open-source Python CLI that screens the full US trademark corpus for potential conflicts with a proposed mark. Apache-2.0 licensed. General-purpose community tool, lives under personal GitHub account (`github.com/nickschuetz/chktm`), not under Hellaenergy Studios.

**This is a research aid, not legal clearance.** That disclaimer must appear prominently in the README, the report output, and the `--help` text. Trademark conflicts are a likelihood-of-confusion analysis that requires a human attorney for any real decision. chktm exists to surface obvious problems quickly and to make first-pass screening cheap.

## Goal of v0.1

Given one or more search terms, screen them against the full active US trademark corpus (USPTO bulk data), and produce a Markdown report ranking matches by likelihood-of-confusion risk against a configurable set of international classes.

Out-of-the-box experience: a user runs `chktm search hellaenergy` on a fresh install, the tool handles everything (download, ingest, index, search, report) without requiring them to understand USPTO data formats.

## Non-goals for v0.1

- Fuzzy or phonetic matching beyond simple substring + normalized variants (lowercase, whitespace-stripped, hyphen-stripped, common-substitution variants like "z"↔"s")
- Web UI
- PyPI publishing (install via `pipx install git+...` for now)
- Common-law usage checks (Steam, itch.io, GitHub) — backlog
- Multi-jurisdiction (US only)
- Trademark assignment / chain-of-title analysis
- Image/design mark search (wordmark only)
- Real-time API queries against tmsearch.uspto.gov (we use bulk data)

All deferred items go in `BACKLOG.md`.

## Data source

USPTO **Trademark Case Files Dataset** (full historical bulk data) from the Open Data Portal at `data.uspto.gov`. The new ODP replaces the legacy Open Data Portal Beta on April 20, 2026 — chktm targets the new ODP exclusively.

The full dataset is large (multi-GB across many XML files). chktm handles:
- Initial bulk download (one-time, hours)
- Incremental updates from daily/weekly application files
- Local ingestion into SQLite (or DuckDB if it proves materially better for this workload — that's a decision Claude Code can make during build, with rationale documented)

**The exact URL pattern, file format, and schema must be verified live during build.** Do not hardcode anything from this spec — verify against the actual ODP first. This is the highest-uncertainty step.

## CLI surface (Typer)

```
chktm init [--data-dir ./data]                    # one-time: download + ingest full corpus
chktm update [--data-dir ./data]                  # pull and ingest new daily/weekly files
chktm search <term> [<term> ...]                  # screen one or more terms
              [--classes 9,41,42]
              [--out report.md]
              [--data-dir ./data]
              [--include-dead]                    # default: live marks only
chktm status [--data-dir ./data]                  # show corpus stats: record count, last update, coverage dates
chktm version
```

Default behavior of `chktm search foo` on a fresh install: detect that no local database exists, print a clear message explaining the one-time `init` step is required (with estimated download size and time), and exit. Do *not* silently kick off a multi-hour download.

Default `--classes` value: `9,41,42` (software, entertainment services, software development services — most relevant to indie game studios).

## Module layout

```
chktm/
├── pyproject.toml
├── README.md
├── LICENSE                # Apache-2.0
├── CONTRIBUTING.md        # DCO sign-off, scope philosophy, how to run tests
├── CODE_OF_CONDUCT.md     # Contributor Covenant
├── AGENTS.md              # for Claude Code
├── BACKLOG.md             # things explicitly deferred
├── SPEC.md                # this file
├── src/chktm/
│   ├── __init__.py
│   ├── cli.py             # Typer app, top-level commands
│   ├── fetch.py           # download bulk + incremental files from data.uspto.gov
│   ├── ingest.py          # streaming XML parse → SQLite ingestion
│   ├── schema.py          # SQLite schema, indexes, migrations
│   ├── search.py          # term matching, normalization, class filtering, risk scoring
│   ├── report.py          # Markdown rendering grouped by risk tier
│   └── disclaimer.py      # the legal disclaimer text, single source of truth
└── tests/
    ├── fixtures/
    │   ├── sample_application.xml
    │   └── sample_registration.xml
    ├── test_ingest.py
    ├── test_search.py
    └── test_report.py
```

## Database schema (initial sketch — refine during build)

```sql
CREATE TABLE marks (
    serial_number      TEXT PRIMARY KEY,
    registration_number TEXT,
    wordmark           TEXT NOT NULL,
    wordmark_normalized TEXT NOT NULL,    -- lowercase, whitespace/hyphen stripped
    status_code        TEXT,
    status_label       TEXT,
    is_live            INTEGER NOT NULL,  -- 0/1, derived from status
    filing_date        TEXT,
    registration_date  TEXT,
    owner_name         TEXT,
    goods_services     TEXT
);

CREATE TABLE mark_classes (
    serial_number TEXT NOT NULL,
    intl_class    INTEGER NOT NULL,
    PRIMARY KEY (serial_number, intl_class),
    FOREIGN KEY (serial_number) REFERENCES marks(serial_number)
);

CREATE INDEX idx_marks_normalized ON marks(wordmark_normalized);
CREATE INDEX idx_marks_live       ON marks(is_live);
CREATE INDEX idx_classes_class    ON mark_classes(intl_class);
```

The `wordmark_normalized` column is the primary search target — it makes "Hella Energy", "hella-energy", and "HELLAENERGY" all match the same query.

## Risk tiers

- **HIGH** — Live status, normalized wordmark contains the normalized search term, and ≥1 international class overlaps `--classes`
- **MEDIUM** — Live, wordmark matches, no class overlap with `--classes`
- **LOW** — Dead/abandoned/cancelled, regardless of class (only included if `--include-dead` is passed; otherwise omitted from the report but counted in summary)

Risk scoring is deliberately simple. Real likelihood-of-confusion analysis weighs many more factors (sound, meaning, channels of trade, sophistication of purchasers, evidence of actual confusion, etc.). chktm is a screening tool, not a substitute for that analysis. The README must say so.

## Report format

```
# chktm report

Generated: <ISO timestamp>
Corpus last updated: <date>
Search terms: <list>
Class filter: <list>
Total active marks in corpus: <N>

## Summary
Searched <N> terms against <M> active marks.
Found: X HIGH, Y MEDIUM, Z LOW (suppressed — pass --include-dead to show)

## Term: <term>

### HIGH risk (X)

#### <WORDMARK>
- Serial: <number>  | Registration: <number or "none">
- Status: <label>
- Filed: <date>     | Registered: <date or "none">
- Owner: <name>
- Classes: <list>
- Goods/services: <truncated excerpt, ~200 chars>
- USPTO link: https://tsdr.uspto.gov/#caseNumber=<serial>&caseType=SERIAL_NO

...

### MEDIUM risk (Y)
...

## Disclaimer
chktm is a research aid, not legal clearance. ...
```

## Known limitations to surface prominently in README

1. **Wordmark only.** Design marks, stylized marks, and image components are not searched.
2. **Substring matching is narrow.** "Hellaenergy" will not match "Hella" or "Energy" alone, nor phonetic variants like "Helaenergee". Sophisticated trademark searches catch these. v0.2+ work.
3. **US only.** No EU, UK, WIPO, or other jurisdictions.
4. **Bulk data lag.** USPTO bulk data trails the live tmsearch UI by some interval (verify during build — likely a few days). For very recent filings, also check tmsearch.uspto.gov manually.
5. **Not legal advice.** Consult an attorney for any real decision. Repeated for emphasis because users will skim.

## License & contribution model

- Code: **Apache-2.0** (matches o3de-mcp, o3de-ai-companion-gem, and O3DE itself)
- Contributions: **DCO** (Developer Certificate of Origin sign-off), no CLA — lighter weight, matches Linux kernel and many OSS norms
- `CONTRIBUTING.md` should explicitly state the v0.1 scope philosophy: "We are deliberately small. Features outside the v0.1 scope are tracked in BACKLOG.md and considered case-by-case. PRs that add scope without discussion will be asked to open an issue first."

## Build sequence (handoff to Claude Code)

The work has clear phases. Each phase ends with a checkpoint where Claude Code stops and shows results before continuing. This is critical because the highest-uncertainty steps are early, and if the URL pattern or schema assumption is wrong, the rest cascades.

**Phase 1 — Recon (stop and report)**
> Verify against the live USPTO Open Data Portal at data.uspto.gov: (a) the exact URL pattern for the Trademark Case Files Dataset bulk download, (b) the file format and approximate total size, (c) the XML schema for a single mark record, including how international classes, status, and goods/services are represented, (d) the update cadence and incremental file pattern. Do not write any code yet. Produce a short recon report and stop.

**Phase 2 — Schema & ingest skeleton (stop and report)**
> Based on the recon, finalize `schema.py` and write `ingest.py` to stream-parse a single XML file into the SQLite database. Test against one small file. Show me the resulting row count and three sample rows. Stop.

**Phase 3 — Bulk download & full ingest**
> Implement `fetch.py` for the full bulk download with progress reporting and resumability. Run a real `chktm init` end-to-end. Report total records ingested, time taken, and disk usage.

**Phase 4 — Search, report, CLI polish**
> Implement `search.py`, `report.py`, and wire up the Typer commands. Add tests against the fixture XML files.

**Phase 5 — Documentation & ship**
> Write README, CONTRIBUTING, BACKLOG, AGENTS.md. Tag v0.1.0. Run `chktm search hellaenergy` and produce the first real report.

## Time budget

Realistic estimate: **8–12 hours total**, likely across two sittings. Most of that is phases 1–3 (data wrangling). Phases 4–5 are fast once the data is solid.

**Hard stop:** if you're past 16 hours and not at v0.1, stop and reassess. Either the scope grew, the data source is harder than expected, or the tool is being gold-plated. All three are recoverable; ignoring the budget is not.

## First real use

The whole point: once v0.1 is shipped, run

```
chktm search hellaenergy "hella energy" hella-energy hellaenergi --classes 9,41,42
```

and use the report (plus a quick manual tmsearch.uspto.gov sanity check for the most recent few weeks of filings) as the trademark-clearance evidence for the LLC formation decision.
