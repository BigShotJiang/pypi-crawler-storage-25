####################
# --- BY PUDIM --- #
####################

'''
Este modúlo ajuda nas manipulações
de banco de dados.
'''
import subprocess
import phfi
from phfi import datajson
import random
import json

def version():
	'''Mostra a versão da manipulação do banco de dados'''
	return "Manipulação do banco de dados v0.1.0 © All rights reserved."

def obj_random():
	'''Escolhe uma frase aleatoria do banco'''
	data = datajson.exportjson()
	phrase = random.choice(data)
	return phrase

def search(query):
	'''Procura uma frase no banco de dados'''
	global data
	results = []
	for n, i in enumerate(data):
		if query.lower() in i.lower():
			results.append((n, i))

	return results
