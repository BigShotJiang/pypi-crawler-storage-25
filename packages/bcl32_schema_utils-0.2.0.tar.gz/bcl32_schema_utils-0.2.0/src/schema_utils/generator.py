"""SchemaGenerator — core orchestrator for Pydantic-to-ModelData conversion."""

from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path
from typing import TYPE_CHECKING

from .filters import define_filtering
from .forms import define_form_properties
from .types import convert_types, get_title, resolve_refs
from .urls import build_api_urls, prepend_prefix

if TYPE_CHECKING:
    from sqlalchemy.orm import DeclarativeBase

# Fields managed by the database (not user-editable).
DEFAULT_DB_FIELDS = ["id", "time_created", "time_updated"]


class SchemaGenerator:
    """Generates ModelData JSON from Pydantic schemas for React frontends.

    Two construction patterns:
        # JSON registry + optional FK references (Print-Tracker style)
        generator = SchemaGenerator.from_registry("./schema_registry.json", db_base=Base)

        # Inline dict, no FK references (Base-POC style)
        generator = SchemaGenerator.from_dict({...})
    """

    def __init__(
        self,
        registry: dict[str, dict],
        fk_reference_map: dict[tuple[str, str], dict[str, str]] | None = None,
        db_fields: list[str] | None = None,
    ):
        self._registry = registry
        self._fk_reference_map = fk_reference_map or {}
        self._db_fields = db_fields or DEFAULT_DB_FIELDS

    @classmethod
    def from_registry(
        cls,
        path: str | Path,
        db_base: type[DeclarativeBase] | None = None,
        db_fields: list[str] | None = None,
    ) -> SchemaGenerator:
        """Create a generator from a schema_registry.json file.

        If db_base is provided, FK references are resolved from SQLAlchemy models.
        """
        from .registry import load_registry

        registry = load_registry(path)
        fk_map = None
        if db_base is not None:
            from .fk_references import build_fk_reference_map

            fk_map = build_fk_reference_map(db_base, registry)
        return cls(registry, fk_map, db_fields)

    @classmethod
    def from_dict(
        cls,
        registry_dict: dict[str, dict],
        db_fields: list[str] | None = None,
    ) -> SchemaGenerator:
        """Create a generator from an inline registry dict.

        Each entry must have at minimum 'model' and 'route_prefix'.
        Other keys default to sensible values.
        """
        registry: dict[str, dict] = {}
        for name, entry in registry_dict.items():
            registry[name] = {
                "model": entry["model"],
                "route_prefix": entry["route_prefix"],
                "table_name": entry.get("table_name", ""),
                "set_name": entry.get("set_name", name),
                "display_field": entry.get("display_field", "name"),
                "chart_filters": entry.get("chart_filters", []),
                "children": entry.get("children", []),
                "field_overrides": entry.get("field_overrides", {}),
            }
        return cls(registry, None, db_fields)

    # -- Public API ----------------------------------------------------------

    def model_names(self) -> list[str]:
        """Return all registered model names."""
        return list(self._registry.keys())

    def generate_model_data(self, model_name: str) -> dict:
        """Generate the full ModelData dict for one registered model."""
        entry = self._registry[model_name]
        raw_schema = entry["model"].model_json_schema()
        schema = resolve_refs(raw_schema)
        properties = schema["properties"]

        # Look up FK references for this model's table
        fk_references: dict[str, dict[str, str]] | None = None
        table_name = entry.get("table_name", "")
        if self._fk_reference_map and table_name:
            fk_references = {
                col_name: ref
                for (tbl, col_name), ref in self._fk_reference_map.items()
                if tbl == table_name
            }

        # Auto-discover Update schema for editability
        update_fields = self._discover_update_fields(model_name, entry)

        return {
            "model_name": model_name,
            "set_name": entry["set_name"],
            "chart_filters": entry["chart_filters"],
            "children": entry["children"],
            **build_api_urls(entry["route_prefix"]),
            "model_attributes": self._make_model_attributes(
                properties, fk_references, update_fields,
                entry.get("field_overrides", {}),
            ),
        }

    def generate_all(self) -> list[dict]:
        """Generate ModelData for all registered models."""
        return [self.generate_model_data(name) for name in self._registry]

    # -- Internal helpers ----------------------------------------------------

    def _add_pydantic_data(self, schema_attr: dict, entry: dict) -> None:
        """Extract UI metadata from a resolved Pydantic schema property."""
        entry["source"] = "db" if entry["name"] in self._db_fields else "main"

        if "stats" in schema_attr:
            entry["stats"] = schema_attr["stats"]

        entry["type"] = convert_types(schema_attr)
        entry["title"] = get_title(schema_attr)

        if entry["type"] == "select":
            if "allOf" in schema_attr and "enum" in schema_attr["allOf"][0]:
                enum_values = schema_attr["allOf"][0]["enum"]
            else:
                enum_values = schema_attr.get("enum", [])
            entry["options"] = [{"value": v, "label": v} for v in enum_values]

        if entry["type"] in ("list", "colour_array"):
            entry["options"] = []

        if "description" in schema_attr:
            entry["help_text"] = schema_attr["description"]

        if "colour_presets_url" in schema_attr:
            entry["colour_presets"] = {"get_api_url": schema_attr["colour_presets_url"]}
            if "colour_presets_group_by" in schema_attr:
                entry["colour_presets"]["group_by"] = schema_attr["colour_presets_group_by"]

    def _discover_update_fields(
        self, model_name: str, entry: dict
    ) -> set[str] | None:
        """Try to import ``{ModelName}Update`` from the schema module.

        Returns the set of field names if found, ``set()`` if the module
        exists but has no Update class (read-only entity), or ``None`` if
        ``schema_module`` is not available (``from_dict`` path).
        """
        schema_module = entry.get("schema_module")
        if not schema_module:
            return None
        try:
            mod = importlib.import_module(schema_module)
        except ImportError:
            return None
        update_cls = getattr(mod, f"{model_name}Update", None)
        if update_cls is None:
            return set()
        return set(update_cls.model_fields.keys())

    def _make_model_attributes(
        self,
        properties: dict,
        fk_references: dict[str, dict[str, str]] | None = None,
        update_fields: set[str] | None = None,
        field_overrides: dict[str, dict] | None = None,
    ) -> list[dict]:
        """Build the model_attributes array from resolved schema properties."""
        model_array = []
        for attr_name, schema_attr in properties.items():
            entry: dict = {"name": attr_name}
            self._add_pydantic_data(schema_attr, entry)
            overrides = (field_overrides or {}).get(attr_name)
            define_form_properties(schema_attr, entry, update_fields, overrides)
            define_filtering(entry, overrides)
            if fk_references and entry["type"] == "id" and attr_name in fk_references:
                entry["reference"] = fk_references[attr_name]
            model_array.append(entry)
        return model_array


# ---------------------------------------------------------------------------
# CLI mode
# ---------------------------------------------------------------------------

def cli_main() -> None:
    """Generate ModelData JSON files from Pydantic schemas (CLI entry point)."""
    parser = argparse.ArgumentParser(
        description="Generate ModelData JSON files from Pydantic schemas"
    )
    parser.add_argument("--registry", required=True, help="Path to schema_registry.json")
    parser.add_argument("--output", required=True, help="Output directory for JSON files")
    parser.add_argument(
        "--url-prefix", default="/fastapi", help="URL prefix prepended to API routes"
    )
    args = parser.parse_args()

    generator = SchemaGenerator.from_registry(args.registry)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    for schema_data in generator.generate_all():
        prepend_prefix(schema_data, args.url_prefix)
        filename = f"{schema_data['model_name']}ModelData.json"
        path = output_dir / filename
        with open(path, "w") as f:
            json.dump(schema_data, f, indent=2)
        print(f"Wrote {path}")
