"""API URL builder utilities."""

URL_KEYS = ("api_url_base", "get_api_url", "add_api_url", "delete_api_url", "update_api_url")


def build_api_urls(route_prefix: str) -> dict[str, str]:
    """Generate the top-level API URL fields from a route prefix.

    Returns bare paths (no host) for all CRUD operations. The code generator
    later wraps these with apiUrl() to resolve the full URL at runtime.
    """
    return {
        "api_url_base": f"{route_prefix}/",
        "get_api_url": f"{route_prefix}/",
        "add_api_url": f"{route_prefix}/",
        "delete_api_url": f"{route_prefix}/delete",
        "update_api_url": f"{route_prefix}",
    }


def prepend_prefix(data: dict, url_prefix: str) -> dict:
    """Prepend url_prefix (e.g. "/fastapi") to all top-level URL fields.

    Only used in CLI mode where the JSON output needs fully-qualified paths.
    """
    for key in URL_KEYS:
        if key in data:
            data[key] = url_prefix + data[key]
    return data
