"""Filter configuration helpers for ModelData attributes."""


def _define_empty_filter(ui_type: str):
    """Return the empty/default filter value for a given UI type."""
    if ui_type in ("string", "boolean"):
        return ""
    if ui_type == "list":
        return []
    if ui_type == "select":
        return ""
    if ui_type == "datetime":
        return {"timespan_begin": "", "timespan_end": ""}
    if ui_type == "number":
        return {"min": "", "max": ""}
    return ""


def _define_filter_rule(ui_type: str):
    """Return the default filter comparison operator for a given UI type."""
    if ui_type == "string":
        return "equals"
    if ui_type == "number":
        return ">"
    if ui_type == "list":
        return "any"
    if ui_type == "select":
        return "equals"
    if ui_type == "datetime":
        return None
    return None


def define_filtering(entry: dict, overrides: dict | None = None) -> None:
    """Set filter, filter_empty, and filter_rule on an attribute entry.

    When *overrides* contains a ``filterable`` key, that value takes
    precedence — but only to *disable* filtering.  Inherently
    non-filterable types (id, object, children) cannot be forced on.
    """
    if overrides and "filterable" in overrides and not overrides["filterable"]:
        entry["filter"] = False
        return

    if entry["type"] in ("id", "object", "children"):
        entry["filter"] = False
    else:
        entry["filter"] = True
        entry["filter_empty"] = _define_empty_filter(entry["type"])
        entry["filter_rule"] = _define_filter_rule(entry["type"])
