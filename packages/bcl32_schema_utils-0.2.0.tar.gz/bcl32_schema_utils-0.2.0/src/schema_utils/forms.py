"""Form/edit property helpers for ModelData attributes."""

from __future__ import annotations


def define_form_properties(
    schema_attr: dict,
    entry: dict,
    update_fields: set[str] | None = None,
    overrides: dict | None = None,
) -> None:
    """Set editability and default value on an attribute entry.

    Fields sourced from the database (source="db") are read-only in forms.
    When *update_fields* is provided (derived from the Update schema), only
    fields present in that set are editable.  When *update_fields* is ``None``
    (e.g. ``from_dict`` path), all non-DB fields are editable as before.

    When *overrides* contains an ``editable`` key set to ``False``, the field
    is hidden from UI edit forms regardless of the Update schema.
    """
    if overrides and "editable" in overrides and not overrides["editable"]:
        entry["editable"] = False
    elif entry["source"] == "db":
        entry["editable"] = False
    elif update_fields is not None:
        entry["editable"] = entry["name"] in update_fields
    else:
        entry["editable"] = True

    if "default" in schema_attr:
        entry["default"] = schema_attr["default"]
