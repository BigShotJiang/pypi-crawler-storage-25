"""Foreign key reference map builder using SQLAlchemy model inspection."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy.orm import DeclarativeBase


def build_fk_reference_map(
    db_base: type[DeclarativeBase],
    registry: dict[str, dict],
) -> dict[tuple[str, str], dict[str, str]]:
    """Build a mapping of (tablename, column_name) -> {get_api_url, display_field}.

    Inspects all SQLAlchemy models registered with db_base to find ForeignKey
    columns, then cross-references with the schema registry to attach the
    target model's route_prefix (as get_api_url) and display_field so the
    frontend can fetch and display the related record.
    """
    # Build tablename -> registry entry lookup
    table_to_registry: dict[str, dict] = {}
    for reg_entry in registry.values():
        table_name = reg_entry.get("table_name", "")
        if table_name:
            table_to_registry[table_name] = reg_entry

    fk_map: dict[tuple[str, str], dict[str, str]] = {}
    for mapper in db_base.registry.mappers:
        table = mapper.persist_selectable
        for col in table.columns:
            for fk in col.foreign_keys:
                target_table = fk.column.table.name
                if target_table in table_to_registry:
                    ref_entry = table_to_registry[target_table]
                    fk_map[(table.name, col.name)] = {
                        "get_api_url": ref_entry["route_prefix"],
                        "display_field": ref_entry.get("display_field", "name"),
                    }
    return fk_map
