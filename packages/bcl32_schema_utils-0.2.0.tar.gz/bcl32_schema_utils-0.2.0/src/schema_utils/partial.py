"""Utility for creating partial Pydantic models from a base class."""

from __future__ import annotations

from typing import Any

from pydantic import create_model


def partial_model(
    base_cls: type,
    *,
    exclude: set[str] | None = None,
    include: set[str] | None = None,
) -> type:
    """Create a partial Pydantic model for Update schemas.

    All included fields become Optional with ``None`` default.

    Parameters
    ----------
    base_cls:
        The Pydantic base model whose fields to copy.
    exclude:
        Field names to remove.  Mutually exclusive with *include*.
    include:
        Field names to keep.  Mutually exclusive with *exclude*.
    """
    if exclude and include:
        raise ValueError("Cannot specify both exclude and include")

    fields: dict[str, Any] = {}
    for name, field_info in base_cls.model_fields.items():
        if exclude and name in exclude:
            continue
        if include and name not in include:
            continue
        # Make every field Optional with None default
        annotation = field_info.annotation
        fields[name] = (annotation | None, None)

    return create_model(
        f"{base_cls.__name__}Partial",
        **fields,
    )
