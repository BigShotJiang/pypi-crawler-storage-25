"""JSON-based schema registry loader."""

import importlib
import json
from pathlib import Path
from typing import TypedDict


class RegistryEntry(TypedDict, total=False):
    model: type  # Pydantic model class (populated after import)
    schema_module: str  # dotted module path for schema discovery
    route_prefix: str
    table_name: str
    set_name: str
    display_field: str
    chart_filters: list
    children: list
    field_overrides: dict[str, dict]


def load_registry(path: str | Path) -> dict[str, RegistryEntry]:
    """Read a schema_registry.json and dynamically import each Pydantic schema class.

    Each registry entry maps a model_name to its Pydantic class, route prefix,
    table name, and UI metadata (set_name, display_field, chart_filters, etc.).
    """
    path = Path(path)

    with open(path) as f:
        entries = json.load(f)

    registry: dict[str, RegistryEntry] = {}
    for entry in entries:
        module = importlib.import_module(entry["schema_module"])
        model_cls = getattr(module, entry["schema_class"])
        registry[entry["model_name"]] = {
            "model": model_cls,
            "schema_module": entry["schema_module"],
            "route_prefix": entry["route_prefix"],
            "table_name": entry["table_name"],
            "set_name": entry["set_name"],
            "display_field": entry.get("display_field", "name"),
            "chart_filters": entry.get("chart_filters", []),
            "children": entry.get("children", []),
            "field_overrides": entry.get("field_overrides", {}),
        }
    return registry
