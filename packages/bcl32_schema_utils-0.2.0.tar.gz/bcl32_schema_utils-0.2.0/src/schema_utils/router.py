"""FastAPI router factory for schema endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .generator import SchemaGenerator


def create_schema_router(generator: SchemaGenerator):
    """Create a FastAPI APIRouter with schema endpoints.

    Returns a router with:
        GET /models  — list of registered model names
        GET /all     — full ModelData for all models
        GET /{model_name} — ModelData for a single model
    """
    from fastapi import APIRouter, HTTPException

    router = APIRouter()

    @router.get("/models")
    def get_models() -> list[str]:
        return generator.model_names()

    @router.get("/all")
    def get_all_schemas() -> list[dict]:
        return generator.generate_all()

    @router.get("/{model_name}")
    def get_schema(model_name: str) -> dict:
        if model_name not in generator.model_names():
            raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")
        return generator.generate_model_data(model_name)

    return router
