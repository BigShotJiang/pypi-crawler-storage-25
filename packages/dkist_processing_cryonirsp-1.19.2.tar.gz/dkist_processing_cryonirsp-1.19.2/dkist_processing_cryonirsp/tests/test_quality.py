from pathlib import Path

import numpy as np
import pytest
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.codecs.basemodel import basemodel_decoder
from dkist_processing_common.codecs.fits import fits_array_encoder
from dkist_processing_common.models.quality import QualityMetric
from dkist_processing_common.models.tags import Tag
from dkist_processing_common.models.task_name import TaskName

from dkist_processing_cryonirsp.models.tags import CryonirspTag
from dkist_processing_cryonirsp.tasks.quality_metrics import CryonirspL0QualityMetrics
from dkist_processing_cryonirsp.tests.conftest import CryonirspConstantsDb
from dkist_processing_cryonirsp.tests.header_models import CryonirspHeaders


@pytest.fixture()
def l0_quality_task_types() -> list[str]:
    # The task types we want to build l0 metrics for
    return [TaskName.lamp_gain.value, TaskName.dark.value]


@pytest.fixture()
def dataset_task_types(l0_quality_task_types: list[str]) -> list[str]:
    # The task types that exist in the dataset. I.e., a larger set than we want to build metrics for.
    return l0_quality_task_types + [TaskName.solar_gain.value, TaskName.observe.value]


@pytest.fixture
def cryonirsp_l0_quality_task(
    recipe_run_id: int,
    num_modstates: int,
    init_cryonirsp_constants_db,
    tmp_path: Path,
    l0_quality_task_types: list[str],
) -> CryonirspL0QualityMetrics:
    constants = CryonirspConstantsDb(
        NUM_MODSTATES=num_modstates,
        MODULATOR_SPIN_MODE="Stepped" if num_modstates > 1 else "Off",
    )
    init_cryonirsp_constants_db(recipe_run_id, constants)

    class TestCryonirspL0QualityMetrics(CryonirspL0QualityMetrics):
        """Only process l0_quality_task_types"""

        @property
        def quality_task_types(self) -> list[str]:
            return l0_quality_task_types

    with TestCryonirspL0QualityMetrics(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        task.scratch = WorkflowFileSystem(scratch_base_path=tmp_path, recipe_run_id=recipe_run_id)

        yield task
        task._purge()


@pytest.fixture
def write_l0_task_frames_to_task(num_modstates, dataset_task_types):
    array_shape = (1, 4, 4)
    data = np.ones(array_shape)

    def writer(task):
        for task_type in dataset_task_types:
            ds = CryonirspHeaders(
                dataset_shape=(num_modstates,) + array_shape[-2:],
                array_shape=array_shape,
                time_delta=1.0,
                file_schema="level0_spec214",
            )
            for modstate, frame in enumerate(ds, start=1):
                header = frame.header()
                tags = [CryonirspTag.linearized_frame(), CryonirspTag.task(task_type)]
                if num_modstates > 1:
                    tags.append(CryonirspTag.modstate(modstate))
                task.write(
                    data=data,
                    header=header,
                    tags=tags,
                    encoder=fits_array_encoder,
                )

    return writer


@pytest.mark.parametrize(
    "num_modstates", [pytest.param(4, id="polarimetric"), pytest.param(1, id="intensity")]
)
def test_l0_quality_task(
    cryonirsp_l0_quality_task: CryonirspL0QualityMetrics,
    num_modstates: int,
    write_l0_task_frames_to_task,
    l0_quality_task_types: list[str],
):
    """
    Given: A `CryonirspL0QualityMetrics` task and some INPUT frames tagged with their task type and modstate
    When: Running the task
    Then: The expected L0 quality metric files exist
    """
    # NOTE: We rely on the unit tests in `*-common` to verify the correct format/data of the metric files
    # Given
    task = cryonirsp_l0_quality_task
    write_l0_task_frames_to_task(task)

    # When
    task()

    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    dataset_metric_codes = ["DATASET_AVERAGE", "DATASET_RMS"]
    frame_metric_codes = ["FRAME_AVERAGE", "FRAME_RMS"]
    dataset_metrics = [metric for metric in metrics if metric.metric_code in dataset_metric_codes]
    frame_metrics = [metric for metric in metrics if metric.metric_code in frame_metric_codes]
    # 2 metrics, no segregation by task
    assert len(dataset_metrics) == 2
    for metric_code in dataset_metric_codes:
        # make sure one metric code of each type
        assert len([metric for metric in dataset_metrics if metric.metric_code == metric_code]) == 1
    # 2 metrics, 2 task types (LAMP_GAIN and DARK)
    assert len(frame_metrics) == 2 * 2
    for metric_code in frame_metric_codes:
        # make sure two metric codes of each type
        assert len([metric for metric in frame_metrics if metric.metric_code == metric_code]) == 2
    for facet in l0_quality_task_types:
        # make sure two facets of each type
        assert len([metric for metric in frame_metrics if metric.facet == facet]) == 2
