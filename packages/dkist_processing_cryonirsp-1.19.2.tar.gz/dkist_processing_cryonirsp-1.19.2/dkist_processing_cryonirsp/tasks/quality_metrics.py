"""Cryonirsp quality metrics task."""

from dataclasses import dataclass
from dataclasses import field
from typing import Iterable

from dkist_processing_common.tasks import QualityL0Metrics

from dkist_processing_cryonirsp.models.constants import CryonirspConstants
from dkist_processing_cryonirsp.models.tags import CryonirspTag

__all__ = ["CryonirspL0QualityMetrics"]


@dataclass
class _QualityDataPoint:
    """Class for storage of a single Cryonirsp quality data point in a time series."""

    datetime: str | int  # isot | mjd
    value: float


@dataclass
class _QualityData:
    """Class for storage of Cryonirsp time series quality data."""

    data_points: list[_QualityDataPoint] = field(default_factory=list)

    @property
    def datetimes(self) -> list[str | int]:
        """Parse datetimes from list of data points."""
        return [dp.datetime for dp in self.data_points]

    @property
    def values(self) -> list[float]:
        """Parse values from list of data points."""
        return [dp.value for dp in self.data_points]

    def __len__(self):
        return len(self.data_points)


class CryonirspL0QualityMetrics(QualityL0Metrics):
    """
    Task class for collection of Cryonirsp L0 specific quality metrics.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs

    """

    @property
    def constants_model_class(self):
        """Class for Cryonirsp constants."""
        return CryonirspConstants

    @property
    def raw_frame_tag(self) -> str:
        """
        Define tag corresponding to L0 data.

        For Cryo it's LINEARIZED.
        """
        return CryonirspTag.linearized()

    @property
    def modstate_list(self) -> Iterable[int] | None:
        """
        Define the list of modstates over which to compute L0 quality metrics.

        If the dataset is non-polarimetric then we just compute all metrics over all modstates at once.
        """
        if self.constants.correct_for_polarization:
            return range(1, self.constants.num_modstates + 1)

        return None
