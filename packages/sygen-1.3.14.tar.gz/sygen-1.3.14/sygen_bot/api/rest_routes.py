"""REST API endpoints for Sygen system management.

Provides CRUD endpoints for agents, cron jobs, webhooks, tasks, sessions,
memory, and system status. Auth is handled by the JWT middleware in auth.py.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import secrets
import signal
import sqlite3
import time
import uuid
from collections import deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

from aiohttp import web

from sygen_bot.api.auth import (
    ROLE_LEVELS,
    _load_or_create_secret,
    _read_users,
    _validate_password_policy,
    _write_users,
    hash_password,
    read_audit,
    require_role,
    sign_file_url,
    write_audit,
)
from sygen_bot.api.notifications import (
    UNREAD_SEVERITIES,
    VALID_SEVERITIES,
    create_notification,
    get_notifications,
    get_unread_count,
    mark_all_read,
    mark_read,
)
import hashlib as _hashlib
import hmac as _hmac

logger = logging.getLogger(__name__)

_START_TIME = time.monotonic()

# Cache sygen home at import time (#18)
_SYGEN_HOME = Path(os.environ.get("SYGEN_HOME", Path.home() / ".sygen"))

# Per-file async locks for JSON R/W (#4)
_file_locks: dict[str, asyncio.Lock] = {}

# Valid agent name pattern (#1)
_AGENT_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]+$")

# Fields to strip from agent data before returning to API clients (#11)
_AGENT_SECRET_KEYS = {"telegram_token", "bot_token", "token", "api_key", "secret"}

# Allowed fields for cron job and webhook creation (#10)
_CRON_ALLOWED_FIELDS = {
    "id", "title", "schedule", "agent", "enabled", "description",
    "task_folder", "agent_instruction",
}
_WEBHOOK_ALLOWED_FIELDS = {"id", "url", "method", "headers", "agent", "enabled", "description", "secret"}
_CRON_SCHEDULE_RE = re.compile(
    r"^(\*|[0-9,/\-]+)\s+(\*|[0-9,/\-]+)\s+(\*|[0-9,/\-]+)\s+(\*|[0-9,/\-]+)\s+(\*|[0-9,/\-]+)$"
)

# Sensitive webhook fields that must be hidden from non-admin callers.
_WEBHOOK_SECRET_KEYS = {"secret", "headers"}


def _is_admin_request(request: web.Request) -> bool:
    user = request.get("jwt_user") or {}
    return user.get("role") == "admin"


def _sanitize_webhook(webhook: dict[str, Any], is_admin: bool) -> dict[str, Any]:
    """Strip secret fields from webhook for non-admin callers."""
    if is_admin:
        return webhook
    sanitized: dict[str, Any] = {}
    for k, v in webhook.items():
        if k == "secret":
            sanitized[k] = "***" if v else v
        elif k == "headers":
            sanitized[k] = {}
        else:
            sanitized[k] = v
    return sanitized


def _sygen_home() -> Path:
    return _SYGEN_HOME


def _agents_registry_path(home: Path | None = None) -> Path:
    """Canonical ``agents.json`` path with legacy top-level fallback.

    Reads fall back to ``<home>/agents.json`` only when the canonical
    ``<home>/_secrets/agents.json`` does not yet exist (pre-migration boot).
    """
    root = home if home is not None else _SYGEN_HOME
    canonical = root / "_secrets" / "agents.json"
    legacy = root / "agents.json"
    if not canonical.exists() and legacy.is_file():
        return legacy
    return canonical


async def _with_file_lock(path: Path) -> asyncio.Lock:
    """Get or create an asyncio.Lock for the given file path."""
    key = str(path)
    if key not in _file_locks:
        _file_locks[key] = asyncio.Lock()
    return _file_locks[key]


def _ok(data: Any) -> web.Response:
    return web.json_response({"ok": True, "data": data})


def _err(message: str, status: int = 400) -> web.Response:
    return web.json_response({"ok": False, "error": message}, status=status)


def _read_json(path: Path) -> Any:
    """Read a JSON file, return None if missing or invalid."""
    try:
        return json.loads(path.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def _atomic_write_text(path: Path, text: str, *, mode: int = 0o600) -> None:
    """Write ``text`` to ``path`` without following symlinks.

    Path.write_text and ``open(..., "w")`` both follow symlinks, so an
    attacker who can plant a symlink at the temp or target location could
    redirect the write to an arbitrary file. This helper:

      1. Pre-removes any temp file (including symlinks) at the temp path.
      2. Opens the temp file with ``O_NOFOLLOW`` so a race that replants
         a symlink between unlink and open fails with ELOOP.
      3. fsyncs and then ``os.replace`` onto the target (atomic rename).
    """
    parent = path.parent
    parent.mkdir(parents=True, exist_ok=True)
    tmp = parent / (path.name + ".tmp")
    try:
        tmp.unlink()
    except FileNotFoundError:
        pass
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW
    fd = os.open(tmp, flags, mode)
    try:
        data = text.encode("utf-8")
        while data:
            written = os.write(fd, data)
            data = data[written:]
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, path)


def _write_json(path: Path, data: Any) -> None:
    """Write data to a JSON file atomically (symlink-safe)."""
    _atomic_write_text(
        path,
        json.dumps(data, indent=2, ensure_ascii=False, default=str),
    )


def _filter_fields(body: dict[str, Any], allowed: set[str]) -> dict[str, Any]:
    """Return only allowed fields from the body."""
    return {k: v for k, v in body.items() if k in allowed}


def _read_last_lines(path: Path, n: int) -> list[str]:
    """Read the last N lines of a file efficiently without loading the whole file."""
    try:
        with path.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            if size == 0:
                return []

            chunk_size = 8192
            collected: list[str] = []
            remainder = b""
            pos = size

            while pos > 0:
                read_size = min(chunk_size, pos)
                pos -= read_size
                f.seek(pos)
                chunk = f.read(read_size)
                chunk = chunk + remainder
                remainder = b""
                parts = chunk.split(b"\n")
                if pos > 0:
                    remainder = parts[0]
                    parts = parts[1:]
                for part in reversed(parts):
                    decoded = part.decode("utf-8", errors="replace")
                    if decoded:
                        collected.append(decoded)
                    if len(collected) >= n:
                        break
                if len(collected) >= n:
                    break

            if remainder and len(collected) < n:
                decoded = remainder.decode("utf-8", errors="replace")
                if decoded:
                    collected.append(decoded)

            collected.reverse()
            return collected[-n:]
    except OSError:
        return []


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

def _get_allowed_agents(request: web.Request) -> list[str]:
    """Get allowed_agents from JWT payload (empty = all agents allowed)."""
    user = request.get("jwt_user", {})
    return user.get("allowed_agents", [])


def _filter_by_allowed_agents(
    items: list[dict[str, Any]], allowed: list[str], key: str = "name",
) -> list[dict[str, Any]]:
    """Filter items to only those the user has access to."""
    if not allowed:
        return items
    return [item for item in items if item.get(key) in allowed]


def _sanitize_agent(agent: dict[str, Any]) -> dict[str, Any]:
    """Strip secret fields from agent data before returning to clients."""
    return {k: v for k, v in agent.items() if k not in _AGENT_SECRET_KEYS}


async def get_agents(request: web.Request) -> web.Response:
    home = _sygen_home()
    data = _read_json(_agents_registry_path(home))
    if data is None:
        return _ok([])

    agents = data if isinstance(data, list) else data.get("agents", [])

    # Read default model from config
    config = _read_json(home / "config" / "config.json") or {}
    default_model = config.get("model", "opus")

    # Include the main agent (not listed in agents.json)
    resolve_agent = request.app.get("resolve_agent")
    agent_names = {a.get("name") for a in agents}
    if "main" not in agent_names:
        main_entry: dict[str, object] = {"name": "main", "model": default_model}
        agents = [main_entry, *agents]

    from sygen_bot.config import ModelRegistry

    for agent in agents:
        name = agent.get("name", "")
        # Online status: check if AgentStack is running in Supervisor
        agent["online"] = bool(resolve_agent and resolve_agent(name))
        # Fill missing model with default from config
        if not agent.get("model"):
            agent["model"] = default_model
        # Derive provider from model when not explicitly set in agents.json
        if not agent.get("provider"):
            agent["provider"] = ModelRegistry.provider_for(str(agent["model"]))
        # Compute last_active and active_sessions from per-agent sessions.json
        agent_sessions_path = home / "agents" / str(name) / "sessions.json"
        if name == "main":
            agent_sessions_path = home / "sessions.json"
        agent_sessions = _read_json(agent_sessions_path) or {}
        agent["active_sessions"] = sum(
            1 for v in agent_sessions.values() if isinstance(v, dict)
        )
        dates = [
            v.get("last_active", "")
            for v in agent_sessions.values()
            if isinstance(v, dict) and v.get("last_active")
        ]
        agent["last_active"] = max(dates) if dates else None
        agent["has_avatar"] = _agent_has_avatar(str(name))

    # Per-agent access filtering
    allowed = _get_allowed_agents(request)
    if allowed:
        agents = _filter_by_allowed_agents(agents, allowed)

    # Strip secrets (tokens, api keys) from agent data
    return _ok([_sanitize_agent(a) for a in agents])


async def get_agent(request: web.Request) -> web.Response:
    name = request.match_info["name"]

    # Validate agent name to prevent unexpected input
    if not _AGENT_NAME_RE.match(name):
        return _err("invalid agent name", 400)

    # Enforce per-agent access
    allowed = _get_allowed_agents(request)
    if allowed and name not in allowed:
        return _err(f"agent '{name}' not found", 404)

    home = _sygen_home()
    data = _read_json(_agents_registry_path(home))
    if data is None:
        return _err("agents.json not found", 404)

    agents = data if isinstance(data, list) else data.get("agents", [])
    resolve_agent = request.app.get("resolve_agent")
    config = _read_json(home / "config" / "config.json") or {}
    default_model = config.get("model", "opus")
    from sygen_bot.config import ModelRegistry

    for agent in agents:
        if agent.get("name") == name:
            agent["online"] = bool(resolve_agent and resolve_agent(name))
            if not agent.get("model"):
                agent["model"] = default_model
            if not agent.get("provider"):
                agent["provider"] = ModelRegistry.provider_for(str(agent["model"]))
            agent["has_avatar"] = _agent_has_avatar(name)
            return _ok(_sanitize_agent(agent))

    return _err(f"agent '{name}' not found", 404)


_AVATAR_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"}
_AVATAR_MAX_SIZE = 2 * 1024 * 1024  # 2 MB


def _agent_has_avatar(name: str) -> bool:
    avatars_dir = _sygen_home() / "avatars" / "agents"
    return any((avatars_dir / f"{name}{ext}").is_file() for ext in _AVATAR_EXTENSIONS)


async def get_agent_avatar(request: web.Request) -> web.StreamResponse:
    """Serve agent avatar image (public, no auth required)."""
    name = request.match_info["name"]
    if not _AGENT_NAME_RE.match(name):
        return _err("invalid agent name", 400)

    avatars_dir = _sygen_home() / "avatars" / "agents"
    for ext in _AVATAR_EXTENSIONS:
        avatar_path = avatars_dir / f"{name}{ext}"
        if avatar_path.is_file():
            ct = {
                ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".gif": "image/gif", ".webp": "image/webp", ".svg": "image/svg+xml",
            }.get(ext, "application/octet-stream")
            return web.FileResponse(avatar_path, headers={
                "Content-Type": ct,
                "Cache-Control": "public, max-age=3600",
            })
    return web.json_response({"error": "no avatar"}, status=404)


@require_role("admin")
async def upload_agent_avatar(request: web.Request) -> web.Response:
    """Upload/replace agent avatar image (admin only)."""
    name = request.match_info["name"]
    if not _AGENT_NAME_RE.match(name):
        return _err("invalid agent name", 400)

    reader = await request.multipart()
    field = await reader.next()
    if field is None or field.name != "avatar":
        return _err("expected 'avatar' field in multipart form", 400)

    filename = field.filename or "avatar.png"
    ext = Path(filename).suffix.lower()
    if ext not in _AVATAR_EXTENSIONS:
        return _err(f"unsupported format: {ext}", 400)

    data = await field.read(decode=True)
    if len(data) > _AVATAR_MAX_SIZE:
        return _err("file too large (max 2 MB)", 413)

    avatars_dir = _sygen_home() / "avatars" / "agents"
    avatars_dir.mkdir(parents=True, exist_ok=True)

    # Remove old avatar (any extension)
    for old_ext in _AVATAR_EXTENSIONS:
        old = avatars_dir / f"{name}{old_ext}"
        if old.is_file():
            old.unlink()

    avatar_path = avatars_dir / f"{name}{ext}"
    await asyncio.to_thread(avatar_path.write_bytes, data)

    write_audit(user=request.get("jwt_user", {}).get("sub", "unknown"), action="agent.avatar.upload", target=name)
    return _ok({"agent": name, "avatar": str(avatar_path)})


@require_role("admin")
async def delete_agent_avatar(request: web.Request) -> web.Response:
    """Delete agent avatar."""
    name = request.match_info["name"]
    if not _AGENT_NAME_RE.match(name):
        return _err("invalid agent name", 400)

    avatars_dir = _sygen_home() / "avatars" / "agents"
    deleted = False
    for ext in _AVATAR_EXTENSIONS:
        p = avatars_dir / f"{name}{ext}"
        if p.is_file():
            p.unlink()
            deleted = True

    if not deleted:
        return _err("no avatar to delete", 404)

    write_audit(user=request.get("jwt_user", {}).get("sub", "unknown"), action="agent.avatar.delete", target=name)
    return _ok({"agent": name})


# ---------------------------------------------------------------------------
# Cron Jobs
# ---------------------------------------------------------------------------

async def get_cron_jobs(request: web.Request) -> web.Response:
    data = _read_json(_sygen_home() / "cron_jobs.json")
    if data is None:
        return _ok([])
    jobs = data.get("jobs", []) if isinstance(data, dict) else data

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed:
        jobs = _filter_by_allowed_agents(jobs, allowed, key="agent")

    return _ok(jobs)


@require_role("admin")
async def create_cron_job(request: web.Request) -> web.Response:
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    path = _sygen_home() / "cron_jobs.json"

    for field in ("id", "title", "schedule"):
        if field not in body:
            return _err(f"missing required field: {field}")

    # Defense in depth: reject ids that don't match the agent-name charset
    if not _AGENT_NAME_RE.match(str(body.get("id", ""))):
        return _err("invalid id format (allowed: a-z, A-Z, 0-9, _, -)")

    # Validate schedule format (#10)
    schedule = str(body.get("schedule", ""))
    if not _CRON_SCHEDULE_RE.match(schedule):
        return _err("invalid cron schedule format (expected: '* * * * *')")

    # Filter to allowed fields only (#10)
    filtered = _filter_fields(body, _CRON_ALLOWED_FIELDS)

    # CronJob dataclass requires task_folder and agent_instruction; derive
    # sensible defaults when the client omits them so the job loads on
    # the observer without a second UI round-trip.
    if not filtered.get("task_folder"):
        filtered["task_folder"] = filtered["id"]
    if not filtered.get("agent_instruction"):
        filtered["agent_instruction"] = filtered.get("description", "") or filtered.get("title", "")

    # Enforce per-agent access on the job's agent
    allowed = _get_allowed_agents(request)
    job_agent = filtered.get("agent", "")
    # ACL-constrained callers must name an agent (no silent admin-wide cron).
    if allowed and not job_agent:
        return _err("agent is required")
    if allowed and job_agent and job_agent not in allowed:
        return _err(f"agent '{job_agent}' is not in your allowed agents", 403)

    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"jobs": []}
        jobs = data.get("jobs", []) if isinstance(data, dict) else data

        if any(j.get("id") == filtered["id"] for j in jobs):
            return _err(f"cron job '{filtered['id']}' already exists", 409)

        jobs.append(filtered)
        if isinstance(data, dict):
            data["jobs"] = jobs
        else:
            data = {"jobs": jobs}
        _write_json(path, data)

    return _ok(filtered)


@require_role("admin")
async def update_cron_job(request: web.Request) -> web.Response:
    job_id = request.match_info["id"]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    # Validate schedule if provided (#10)
    if "schedule" in body:
        schedule = str(body["schedule"])
        if not _CRON_SCHEDULE_RE.match(schedule):
            return _err("invalid cron schedule format (expected: '* * * * *')")

    # Filter to allowed fields (#10)
    filtered = _filter_fields(body, _CRON_ALLOWED_FIELDS)

    path = _sygen_home() / "cron_jobs.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("cron_jobs.json not found", 404)

        jobs = data.get("jobs", []) if isinstance(data, dict) else data
        allowed = _get_allowed_agents(request)
        for i, job in enumerate(jobs):
            if job.get("id") == job_id:
                # Enforce per-agent access on existing job
                if allowed and job.get("agent") and job["agent"] not in allowed:
                    return _err(f"cron job '{job_id}' not found", 404)
                # Enforce per-agent access on the NEW agent if it's being changed
                if allowed and "agent" in filtered:
                    new_agent = filtered.get("agent", "")
                    if not new_agent:
                        return _err("agent is required")
                    if new_agent not in allowed:
                        return _err(
                            f"agent '{new_agent}' is not in your allowed agents", 403,
                        )
                jobs[i] = {**job, **filtered, "id": job_id}
                if isinstance(data, dict):
                    data["jobs"] = jobs
                _write_json(path, data)
                return _ok(jobs[i])

    return _err(f"cron job '{job_id}' not found", 404)


@require_role("admin")
async def delete_cron_job(request: web.Request) -> web.Response:
    job_id = request.match_info["id"]
    path = _sygen_home() / "cron_jobs.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("cron_jobs.json not found", 404)

        jobs = data.get("jobs", []) if isinstance(data, dict) else data

        # Enforce per-agent access: find the job first to check its agent
        allowed = _get_allowed_agents(request)
        if allowed:
            target_job = next((j for j in jobs if j.get("id") == job_id), None)
            if target_job is None:
                return _err(f"cron job '{job_id}' not found", 404)
            if target_job.get("agent") and target_job["agent"] not in allowed:
                return _err(f"cron job '{job_id}' not found", 404)

        original_len = len(jobs)
        jobs = [j for j in jobs if j.get("id") != job_id]

        if len(jobs) == original_len:
            return _err(f"cron job '{job_id}' not found", 404)

        if isinstance(data, dict):
            data["jobs"] = jobs
        else:
            data = {"jobs": jobs}
        _write_json(path, data)

    return _ok({"deleted": job_id})


@require_role("operator")
async def run_cron_job(request: web.Request) -> web.Response:
    job_id = request.match_info["id"]
    path = _sygen_home() / "cron_jobs.json"
    data = _read_json(path)
    if data is None:
        return _err("cron_jobs.json not found", 404)

    jobs = data.get("jobs", []) if isinstance(data, dict) else data
    for job in jobs:
        if job.get("id") == job_id:
            # Check allowed_agents before running
            allowed = _get_allowed_agents(request)
            if allowed and job.get("agent") not in allowed:
                return _err(f"cron job '{job_id}' not found", 404)

            if not _AGENT_NAME_RE.match(job_id):
                return _err("invalid job id format", 400)
            marker = _sygen_home() / "workspace" / "cron_tasks" / job_id / ".run_now"
            marker.parent.mkdir(parents=True, exist_ok=True)
            marker.write_text(str(time.time()))
            return _ok({"triggered": job_id})

    return _err(f"cron job '{job_id}' not found", 404)


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------

async def get_webhooks(request: web.Request) -> web.Response:
    data = _read_json(_sygen_home() / "webhooks.json")
    if data is None:
        return _ok([])
    hooks = data.get("webhooks", []) if isinstance(data, dict) else data

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed:
        hooks = _filter_by_allowed_agents(hooks, allowed, key="agent")

    # Strip secret/headers for non-admin callers.
    is_admin = _is_admin_request(request)
    hooks = [_sanitize_webhook(h, is_admin) for h in hooks]

    return _ok(hooks)


@require_role("admin")
async def create_webhook(request: web.Request) -> web.Response:
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    if "id" not in body:
        return _err("missing required field: id")

    # Defense in depth: reject ids that don't match the agent-name charset
    if not _AGENT_NAME_RE.match(str(body.get("id", ""))):
        return _err("invalid id format (allowed: a-z, A-Z, 0-9, _, -)")

    # Filter to allowed fields only (#10)
    filtered = _filter_fields(body, _WEBHOOK_ALLOWED_FIELDS)

    # Enforce per-agent access on the webhook's agent
    allowed = _get_allowed_agents(request)
    wh_agent = filtered.get("agent", "")
    # ACL-constrained callers must name an agent (no silent admin-wide webhook).
    if allowed and not wh_agent:
        return _err("agent is required")
    if allowed and wh_agent and wh_agent not in allowed:
        return _err(f"agent '{wh_agent}' is not in your allowed agents", 403)

    path = _sygen_home() / "webhooks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"webhooks": []}
        hooks = data.get("webhooks", []) if isinstance(data, dict) else data

        if any(h.get("id") == filtered["id"] for h in hooks):
            return _err(f"webhook '{filtered['id']}' already exists", 409)

        hooks.append(filtered)
        if isinstance(data, dict):
            data["webhooks"] = hooks
        else:
            data = {"webhooks": hooks}
        _write_json(path, data)

    return _ok(filtered)


@require_role("admin")
async def update_webhook(request: web.Request) -> web.Response:
    hook_id = request.match_info["id"]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    # Filter to allowed fields (#10)
    filtered = _filter_fields(body, _WEBHOOK_ALLOWED_FIELDS)

    path = _sygen_home() / "webhooks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("webhooks.json not found", 404)

        hooks = data.get("webhooks", []) if isinstance(data, dict) else data
        allowed = _get_allowed_agents(request)
        for i, hook in enumerate(hooks):
            if hook.get("id") == hook_id:
                # Enforce per-agent access on existing webhook
                if allowed and hook.get("agent") and hook["agent"] not in allowed:
                    return _err(f"webhook '{hook_id}' not found", 404)
                # Enforce per-agent access on the NEW agent if it's being changed
                if allowed and "agent" in filtered:
                    new_agent = filtered.get("agent", "")
                    if not new_agent:
                        return _err("agent is required")
                    if new_agent not in allowed:
                        return _err(
                            f"agent '{new_agent}' is not in your allowed agents", 403,
                        )
                hooks[i] = {**hook, **filtered, "id": hook_id}
                if isinstance(data, dict):
                    data["webhooks"] = hooks
                _write_json(path, data)
                return _ok(hooks[i])

    return _err(f"webhook '{hook_id}' not found", 404)


@require_role("admin")
async def delete_webhook(request: web.Request) -> web.Response:
    hook_id = request.match_info["id"]
    path = _sygen_home() / "webhooks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("webhooks.json not found", 404)

        hooks = data.get("webhooks", []) if isinstance(data, dict) else data

        # Enforce per-agent access: find the hook first to check its agent
        allowed = _get_allowed_agents(request)
        if allowed:
            target_hook = next((h for h in hooks if h.get("id") == hook_id), None)
            if target_hook is None:
                return _err(f"webhook '{hook_id}' not found", 404)
            if target_hook.get("agent") and target_hook["agent"] not in allowed:
                return _err(f"webhook '{hook_id}' not found", 404)

        original_len = len(hooks)
        hooks = [h for h in hooks if h.get("id") != hook_id]

        if len(hooks) == original_len:
            return _err(f"webhook '{hook_id}' not found", 404)

        if isinstance(data, dict):
            data["webhooks"] = hooks
        else:
            data = {"webhooks": hooks}
        _write_json(path, data)

    return _ok({"deleted": hook_id})


@require_role("operator")
async def verify_webhook_signature(request: web.Request) -> web.Response:
    """``POST /api/webhooks/{id}/verify`` — verify HMAC-SHA256 signature for a webhook payload."""
    hook_id = request.match_info["id"]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    payload = body.get("payload", "")
    signature = body.get("signature", "")
    if not payload or not signature:
        return _err("payload and signature are required")

    # Find webhook and its secret
    data = _read_json(_sygen_home() / "webhooks.json")
    if data is None:
        return _err("webhooks.json not found", 404)

    hooks = data.get("webhooks", []) if isinstance(data, dict) else data
    hook = None
    for h in hooks:
        if h.get("id") == hook_id:
            hook = h
            break
    if hook is None:
        return _err(f"webhook '{hook_id}' not found", 404)

    # Enforce per-agent access
    allowed = _get_allowed_agents(request)
    if allowed and hook.get("agent") not in allowed:
        return _err(f"webhook '{hook_id}' not found", 404)

    secret = hook.get("secret", "")
    if not secret:
        return _err("webhook has no secret configured", 400)

    # Compute HMAC-SHA256
    payload_bytes = payload.encode("utf-8") if isinstance(payload, str) else payload
    expected = _hmac.new(
        secret.encode("utf-8"), payload_bytes, _hashlib.sha256,
    ).hexdigest()

    valid = _hmac.compare_digest(expected, str(signature))
    return _ok({"valid": valid})


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

async def get_tasks(request: web.Request) -> web.Response:
    data = _read_json(_sygen_home() / "tasks.json")
    if data is None:
        return _ok([])

    tasks = data.get("tasks", []) if isinstance(data, dict) else data

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed:
        tasks = [t for t in tasks if t.get("parent_agent", t.get("agent", "")) in allowed]

    status_filter = request.query.get("status")
    if status_filter:
        tasks = [t for t in tasks if t.get("status") == status_filter]

    limit = request.query.get("limit")
    if limit and limit.isdigit():
        tasks = tasks[-int(limit):]

    return _ok(tasks)


async def get_task(request: web.Request) -> web.Response:
    task_id = request.match_info["id"]
    data = _read_json(_sygen_home() / "tasks.json")
    if data is None:
        return _err("tasks.json not found", 404)

    tasks = data.get("tasks", []) if isinstance(data, dict) else data
    allowed = _get_allowed_agents(request)
    for task in tasks:
        if task.get("task_id") == task_id:
            # Enforce per-agent access
            if allowed:
                task_agent = task.get("parent_agent", task.get("agent", ""))
                if task_agent and task_agent not in allowed:
                    return _err(f"task '{task_id}' not found", 404)
            return _ok(task)

    return _err(f"task '{task_id}' not found", 404)


@require_role("operator")
async def cancel_task(request: web.Request) -> web.Response:
    task_id = request.match_info["id"]
    path = _sygen_home() / "tasks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("tasks.json not found", 404)

        tasks = data.get("tasks", []) if isinstance(data, dict) else data
        allowed = _get_allowed_agents(request)
        for task in tasks:
            if task.get("task_id") == task_id:
                # Enforce per-agent access
                if allowed:
                    task_agent = task.get("parent_agent", task.get("agent", ""))
                    if task_agent and task_agent not in allowed:
                        return _err(f"task '{task_id}' not found", 404)
                if task.get("status") in ("done", "cancelled", "failed"):
                    return _err(f"task already {task['status']}", 400)
                task["status"] = "cancelled"
                if isinstance(data, dict):
                    data["tasks"] = tasks
                _write_json(path, data)

                # Attempt to signal the task process if pid is available (#13)
                pid = task.get("pid")
                signal_sent = False
                if pid and isinstance(pid, int):
                    try:
                        os.kill(pid, signal.SIGTERM)
                        signal_sent = True
                    except (ProcessLookupError, PermissionError, OSError):
                        pass

                return _ok({
                    "cancelled": task_id,
                    "note": "cancel is advisory (soft)" + ("; SIGTERM sent" if signal_sent else "; no process to signal"),
                })

    return _err(f"task '{task_id}' not found", 404)


@require_role("admin")
async def create_task(request: web.Request) -> web.Response:
    """Create a new task entry with status 'pending'.

    Accepts JSON with: name (required), agent, prompt, provider, model.
    The task is saved to tasks.json. An external runner or the internal
    task hub picks it up for execution.
    """
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    name = body.get("name")
    if not name or not isinstance(name, str) or not name.strip():
        return _err("missing or empty required field: name")

    prompt = body.get("prompt", "")
    agent = body.get("agent", "main")
    provider = body.get("provider", "claude")
    model = body.get("model", "")

    # Validate agent name
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name (only alphanumeric, hyphens, and underscores allowed)", 400)

    # Enforce per-agent access
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _err(f"agent '{agent}' is not in your allowed agents", 403)

    task_id = secrets.token_hex(6)

    entry = {
        "task_id": task_id,
        "name": name.strip(),
        "status": "pending",
        "parent_agent": agent,
        "prompt_preview": (prompt[:80] + "...") if len(prompt) > 80 else prompt,
        "prompt": prompt,
        "provider": provider,
        "model": model,
        "created_at": time.time(),
        "completed_at": None,
        "elapsed_seconds": 0,
        "error": "",
        "result_preview": "",
    }

    path = _sygen_home() / "tasks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"tasks": []}
        tasks = data.get("tasks", []) if isinstance(data, dict) else data
        tasks.append(entry)
        if isinstance(data, dict):
            data["tasks"] = tasks
        else:
            data = {"tasks": tasks}
        _write_json(path, data)

    return _ok(entry)


# ---------------------------------------------------------------------------
# Review
# ---------------------------------------------------------------------------

_REVIEW_PROMPT_TEMPLATE = (
    "Use the ultra_review skill (read workspace/skills/ultra_review/SKILL.md "
    "in full first, then follow it). Target to review: {target}"
)


@require_role("admin")
async def create_review(request: web.Request) -> web.Response:
    """Queue an ultra-review task for *agent*.

    Accepts JSON: ``{"agent": "main", "target": "..."}``. The target text is
    wrapped with the ultra_review skill instruction and stored as a pending
    task. The TaskHub picks it up (when configured) and delivers the result
    back to the originating agent.
    """
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    target = (body.get("target") or "").strip()
    if not target:
        return _err("missing or empty required field: target")

    agent = body.get("agent", "main")
    if not _AGENT_NAME_RE.match(agent):
        return _err(
            "invalid agent name (only alphanumeric, hyphens, and underscores allowed)",
            400,
        )

    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _err(f"agent '{agent}' is not in your allowed agents", 403)

    prompt = _REVIEW_PROMPT_TEMPLATE.format(target=target)
    name = f"Ultra Review: {target[:40]}"
    task_id = secrets.token_hex(6)

    entry = {
        "task_id": task_id,
        "name": name,
        "status": "pending",
        "parent_agent": agent,
        "prompt_preview": (prompt[:80] + "...") if len(prompt) > 80 else prompt,
        "prompt": prompt,
        "provider": body.get("provider", "claude"),
        "model": body.get("model", ""),
        "kind": "ultra_review",
        "created_at": time.time(),
        "completed_at": None,
        "elapsed_seconds": 0,
        "error": "",
        "result_preview": "",
    }

    path = _sygen_home() / "tasks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"tasks": []}
        tasks = data.get("tasks", []) if isinstance(data, dict) else data
        tasks.append(entry)
        if isinstance(data, dict):
            data["tasks"] = tasks
        else:
            data = {"tasks": tasks}
        _write_json(path, data)

    return _ok(entry)


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------

async def get_sessions(request: web.Request) -> web.Response:
    data = _read_json(_sygen_home() / "sessions.json")
    if data is None:
        return _ok({})

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed and isinstance(data, dict):
        data = {
            k: v for k, v in data.items()
            if isinstance(v, dict) and v.get("agent", k) in allowed
        }

    return _ok(data)


@require_role("admin")
async def delete_session(request: web.Request) -> web.Response:
    session_id = request.match_info["id"]
    path = _sygen_home() / "sessions.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("sessions.json not found", 404)

        if session_id not in data:
            return _err(f"session '{session_id}' not found", 404)

        # Enforce per-agent access
        allowed = _get_allowed_agents(request)
        session = data[session_id]
        if allowed and isinstance(session, dict):
            session_agent = session.get("agent", session_id)
            if session_agent not in allowed:
                return _err(f"session '{session_id}' not found", 404)

        del data[session_id]
        _write_json(path, data)

    return _ok({"deleted": session_id})


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------

async def get_memory(request: web.Request) -> web.Response:
    mem_path = _sygen_home() / "workspace" / "memory_system" / "MAINMEMORY.md"
    try:
        content = mem_path.read_text("utf-8")
    except FileNotFoundError:
        return _err("MAINMEMORY.md not found", 404)
    return _ok({"content": content})


@require_role("admin")
async def update_memory(request: web.Request) -> web.Response:
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    content = body.get("content")
    if content is None:
        return _err("missing 'content' field")
    if not isinstance(content, str):
        return _err("'content' must be a string")

    mem_path = _sygen_home() / "workspace" / "memory_system" / "MAINMEMORY.md"
    _atomic_write_text(mem_path, content)
    return _ok({"updated": True})


def _resolve_memory_dir(request: web.Request) -> Path:
    """Resolve memory_system dir: main agent or sub-agent via ?agent= param."""
    home = _sygen_home()
    agent = request.query.get("agent", "")
    if agent and agent != "main":
        if not _AGENT_NAME_RE.match(agent):
            raise ValueError("invalid agent name")
        agent_dir = home / "agents" / agent / "workspace" / "memory_system"
        if agent_dir.is_dir():
            return agent_dir
        raise FileNotFoundError(f"agent '{agent}' memory not found")
    return home / "workspace" / "memory_system"


# Per-file mtime-cached line counts for memory module listing.
# Keyed by absolute path: {path_str: (mtime, lines)}.
_memory_line_cache: dict[str, tuple[float, int]] = {}

# Skip line-counting for files larger than this (bytes). Returns the
# sentinel ``-1`` so the admin can render "—" instead of churning through
# a huge file on every listing.
_MEMORY_LINE_COUNT_SIZE_LIMIT = 1_000_000


def _memory_line_count_cached(path: Path) -> int:
    """Count lines in a file, using an mtime-based cache.

    Returns ``-1`` for files larger than 1 MB (no read performed) so a
    pathological large module can't DoS the listing endpoint.
    """
    try:
        stat = path.stat()
    except OSError:
        return 0
    mtime = stat.st_mtime
    key = str(path)
    cached = _memory_line_cache.get(key)
    if cached is not None and cached[0] == mtime:
        return cached[1]
    if stat.st_size > _MEMORY_LINE_COUNT_SIZE_LIMIT:
        _memory_line_cache[key] = (mtime, -1)
        return -1
    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            lines = sum(1 for _ in fh)
    except OSError:
        return 0
    _memory_line_cache[key] = (mtime, lines)
    # Small cap: drop oldest entries if cache grows unreasonably.
    if len(_memory_line_cache) > 500:
        for stale_key in list(_memory_line_cache.keys())[:100]:
            _memory_line_cache.pop(stale_key, None)
    return lines


def _invalidate_memory_line_cache() -> None:
    """Bust the memory line-count cache (on write/delete)."""
    _memory_line_cache.clear()


async def get_memory_modules(request: web.Request) -> web.Response:
    agent = request.query.get("agent", "") or "main"
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)
    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    try:
        mem_dir = _resolve_memory_dir(request)
    except ValueError as exc:
        return _err(str(exc), 400)
    except FileNotFoundError as exc:
        return _err(str(exc), 404)

    if not mem_dir.is_dir():
        return _ok([])

    modules = []
    # Top-level .md files
    for f in sorted(mem_dir.iterdir()):
        if f.is_file() and f.suffix == ".md":
            modules.append({
                "name": f.stem,
                "filename": f.name,
                "size": f.stat().st_size,
                "lines": _memory_line_count_cached(f),
            })
    # Nested modules/ directory
    modules_dir = mem_dir / "modules"
    if modules_dir.is_dir():
        for f in sorted(modules_dir.iterdir()):
            if f.is_file() and f.suffix == ".md":
                modules.append({
                    "name": f.stem,
                    "filename": f"modules/{f.name}",
                    "size": f.stat().st_size,
                    "lines": _memory_line_count_cached(f),
                })

    # Include SHAREDMEMORY.md for main agent
    if agent == "main":
        shared = _sygen_home() / "SHAREDMEMORY.md"
        if shared.is_file():
            modules.append({
                "name": "SHAREDMEMORY",
                "filename": "SHAREDMEMORY.md",
                "size": shared.stat().st_size,
                "lines": _memory_line_count_cached(shared),
            })
    return _ok(modules)


async def get_memory_module(request: web.Request) -> web.Response:
    """Read content of a specific memory module by filename."""
    filename = request.match_info["filename"]
    # NUL byte can truncate paths at the C layer — reject before any path ops.
    if "\x00" in filename:
        return _err("invalid filename", 400)
    # Only allow: "name.md" or "modules/name.md". Traversal is blocked by
    # the resolve()/is_relative_to() check below, so we don't reject on
    # substrings like ".." — that would falsely reject names like "v..1.md".
    parts = filename.split("/")
    if len(parts) > 2:
        return _err("invalid filename", 400)
    if not filename.endswith(".md"):
        return _err("only .md files are supported", 400)

    agent = request.query.get("agent", "") or "main"
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)
    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    # Special case: SHAREDMEMORY.md lives at sygen_home root
    if filename == "SHAREDMEMORY.md":
        shared = _sygen_home() / "SHAREDMEMORY.md"
        if not shared.is_file():
            return _err("SHAREDMEMORY.md not found", 404)
        try:
            content = shared.read_text("utf-8")
        except OSError:
            return _err("failed to read module", 500)
        return _ok({"filename": filename, "content": content})

    try:
        mem_dir = _resolve_memory_dir(request)
    except ValueError as exc:
        return _err(str(exc), 400)
    except FileNotFoundError as exc:
        return _err(str(exc), 404)

    mem_path = mem_dir / filename
    # Resolve symlinks and verify the path stays within the memory directory
    try:
        if not mem_path.resolve().is_relative_to(mem_dir.resolve()):
            return _err("invalid filename", 400)
    except (ValueError, OSError):
        return _err("invalid filename", 400)
    if not mem_path.is_file():
        return _err(f"module '{filename}' not found", 404)

    try:
        content = mem_path.read_text("utf-8")
    except OSError:
        return _err("failed to read module", 500)

    return _ok({"filename": filename, "content": content})


@require_role("admin")
async def update_memory_module(request: web.Request) -> web.Response:
    """Update content of a specific memory module by filename."""
    filename = request.match_info["filename"]
    if "\x00" in filename:
        return _err("invalid filename", 400)
    parts = filename.split("/")
    if len(parts) > 2:
        return _err("invalid filename", 400)
    if not filename.endswith(".md"):
        return _err("only .md files are supported", 400)

    agent = request.query.get("agent", "") or "main"
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)
    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    content = body.get("content")
    if content is None:
        return _err("missing 'content' field")
    if not isinstance(content, str):
        return _err("'content' must be a string")

    # Special case: SHAREDMEMORY.md lives at sygen_home root
    if filename == "SHAREDMEMORY.md":
        shared = _sygen_home() / "SHAREDMEMORY.md"
        _atomic_write_text(shared, content)
        _invalidate_memory_line_cache()
        return _ok({"updated": True})

    try:
        mem_dir = _resolve_memory_dir(request)
    except ValueError as exc:
        return _err(str(exc), 400)
    except FileNotFoundError as exc:
        return _err(str(exc), 404)

    mem_path = mem_dir / filename
    mem_dir.mkdir(parents=True, exist_ok=True)
    # Resolve symlinks and verify the path stays within the memory directory
    try:
        if not mem_path.resolve().is_relative_to(mem_dir.resolve()):
            return _err("invalid filename", 400)
    except (ValueError, OSError):
        return _err("invalid filename", 400)
    _atomic_write_text(mem_path, content)
    _invalidate_memory_line_cache()
    return _ok({"updated": True})


# ---------------------------------------------------------------------------
# Skills (per-agent workspace skills)
# ---------------------------------------------------------------------------

# Valid skill name pattern: same charset as agent names (no dots, slashes)
_SKILL_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]+$")
_SKILL_DESCRIPTION_PREVIEW_LINES = 40


def _resolve_skills_dir(request: web.Request) -> Path:
    """Resolve skills dir for the agent given via path param ``agent``."""
    home = _sygen_home()
    agent = request.match_info.get("agent", "")
    if not _AGENT_NAME_RE.match(agent or ""):
        raise ValueError("invalid agent name")
    if agent == "main":
        return home / "workspace" / "skills"
    skills_dir = home / "agents" / agent / "workspace" / "skills"
    if not skills_dir.is_dir() and not (home / "agents" / agent).is_dir():
        raise FileNotFoundError(f"agent '{agent}' not found")
    return skills_dir


def _resolve_global_skills_dir() -> Path:
    """Return path of the shared (cross-agent) skills directory."""
    return _sygen_home() / "skills"


def _check_agent_access(request: web.Request, agent: str) -> web.Response | None:
    """Return a 404 response if the requester has no access to the given agent."""
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _err(f"agent '{agent}' not found", 404)
    return None


def _skill_doc_path(skill_dir: Path) -> Path | None:
    """Return SKILL.md if it exists, else README.md, else None."""
    for name in ("SKILL.md", "README.md"):
        p = skill_dir / name
        if p.is_file():
            return p
    return None


def _skill_dir_is_in(skill_dir: Path, skills_dir: Path) -> bool:
    """True if `skill_dir` is a direct child of `skills_dir` without resolving
    the target. This intentionally permits symlinks whose target lives outside
    the skills directory (common for shared skills like ~/.claude/skills/*),
    while `_SKILL_NAME_RE` already blocks `..` and path separators in the name.
    """
    try:
        return skill_dir.parent.samefile(skills_dir)
    except OSError:
        return False


def _skill_description(skill_dir: Path) -> str:
    """Extract a short description from SKILL.md/README.md frontmatter or first lines."""
    doc = _skill_doc_path(skill_dir)
    if doc is None:
        return ""
    try:
        with doc.open("r", encoding="utf-8", errors="replace") as fh:
            head = [next(fh, "") for _ in range(_SKILL_DESCRIPTION_PREVIEW_LINES)]
    except OSError:
        return ""
    text = "".join(head)

    # Try YAML-style frontmatter "description: ..."
    fm_match = re.search(r"^---\s*$(.*?)^---\s*$", text, re.MULTILINE | re.DOTALL)
    if fm_match:
        for line in fm_match.group(1).splitlines():
            m = re.match(r"\s*description\s*:\s*(.+?)\s*$", line)
            if m:
                return m.group(1).strip().strip('"').strip("'")

    # Fall back to first non-heading, non-empty line
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("---"):
            continue
        return line[:200]
    return ""


def _collect_skills(skills_dir: Path, scope: str) -> list[dict[str, Any]]:
    """Enumerate skills in ``skills_dir`` and return API dicts tagged with ``scope``."""
    items: list[dict[str, Any]] = []
    if not skills_dir.is_dir():
        return items
    for entry in sorted(skills_dir.iterdir()):
        if not entry.is_dir() or entry.name.startswith("."):
            continue
        if not _SKILL_NAME_RE.match(entry.name):
            continue
        doc = _skill_doc_path(entry)
        try:
            stat = (doc or entry).stat()
        except OSError:
            continue
        items.append({
            "name": entry.name,
            "description": _skill_description(entry),
            "path": str(entry),
            "mtime": stat.st_mtime,
            "size": stat.st_size if doc else 0,
            "has_doc": doc is not None,
            "doc_filename": doc.name if doc else None,
            "scope": scope,
        })
    return items


def _read_skill_doc(skill_dir: Path, name: str, scope: str) -> dict[str, Any] | None:
    """Return the dict payload for a single skill's doc, or None on read error."""
    doc = _skill_doc_path(skill_dir)
    if doc is None:
        return {"name": name, "filename": None, "content": "", "scope": scope}
    try:
        content = doc.read_text("utf-8")
    except OSError:
        return None
    return {"name": name, "filename": doc.name, "content": content, "scope": scope}


async def list_agent_skills(request: web.Request) -> web.Response:
    """List skills visible to an agent.

    Query param ``scope`` selects the view:
      - omitted / "merged": global skills + per-agent skills (agent entries
        tagged with ``overrides: True`` when a same-named global exists).
      - "own" / "agent": only per-agent skills.
      - "global": only global skills (same payload as ``GET /api/skills``).
    """
    agent = request.match_info["agent"]
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    try:
        agent_dir = _resolve_skills_dir(request)
    except ValueError as exc:
        return _err(str(exc), 400)
    except FileNotFoundError as exc:
        return _err(str(exc), 404)

    scope_raw = request.query.get("scope", "").lower()
    if scope_raw in ("", "merged", "merge"):
        scope = "merged"
    elif scope_raw in ("own", "agent"):
        scope = "own"
    elif scope_raw == "global":
        scope = "global"
    else:
        return _err("invalid 'scope' (allowed: own, global, merged)", 400)

    global_dir = _resolve_global_skills_dir()

    if scope == "own":
        return _ok(_collect_skills(agent_dir, "agent"))
    if scope == "global":
        return _ok(_collect_skills(global_dir, "global"))

    # merged view
    agent_items = _collect_skills(agent_dir, "agent")
    global_items = _collect_skills(global_dir, "global")
    agent_names = {item["name"] for item in agent_items}
    global_names = {item["name"] for item in global_items}
    for item in agent_items:
        if item["name"] in global_names:
            item["overrides"] = True
    merged = [g for g in global_items if g["name"] not in agent_names] + agent_items
    merged.sort(key=lambda x: x["name"])
    return _ok(merged)


async def get_agent_skill(request: web.Request) -> web.Response:
    """Return SKILL.md/README.md content for a specific skill.

    Resolution order: per-agent skill first, then fall back to the global
    skill with the same name. Response includes ``scope`` so callers can
    tell which location served the content.
    """
    agent = request.match_info["agent"]
    skill = request.match_info["skill"]
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)
    if not _SKILL_NAME_RE.match(skill):
        return _err("invalid skill name", 400)

    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    try:
        agent_dir = _resolve_skills_dir(request)
    except ValueError as exc:
        return _err(str(exc), 400)
    except FileNotFoundError as exc:
        return _err(str(exc), 404)

    agent_skill_dir = agent_dir / skill
    if (
        _skill_dir_is_in(agent_skill_dir, agent_dir)
        and agent_skill_dir.is_dir()
    ):
        payload = _read_skill_doc(agent_skill_dir, skill, "agent")
        if payload is None:
            return _err("failed to read skill", 500)
        return _ok(payload)

    # Fall back to the global skill with the same name
    global_dir = _resolve_global_skills_dir()
    global_skill_dir = global_dir / skill
    if (
        global_dir.is_dir()
        and _skill_dir_is_in(global_skill_dir, global_dir)
        and global_skill_dir.is_dir()
    ):
        payload = _read_skill_doc(global_skill_dir, skill, "global")
        if payload is None:
            return _err("failed to read skill", 500)
        return _ok(payload)

    return _err(f"skill '{skill}' not found", 404)


@require_role("admin")
async def update_agent_skill(request: web.Request) -> web.Response:
    """Update SKILL.md (or README.md if SKILL.md does not exist) for a skill."""
    agent = request.match_info["agent"]
    skill = request.match_info["skill"]
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)
    if not _SKILL_NAME_RE.match(skill):
        return _err("invalid skill name", 400)

    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    content = body.get("content")
    if content is None:
        return _err("missing 'content' field")
    if not isinstance(content, str):
        return _err("'content' must be a string")

    try:
        skills_dir = _resolve_skills_dir(request)
    except ValueError as exc:
        return _err(str(exc), 400)
    except FileNotFoundError as exc:
        return _err(str(exc), 404)

    skill_dir = skills_dir / skill
    if not _skill_dir_is_in(skill_dir, skills_dir):
        return _err("invalid skill name", 400)
    if not skill_dir.is_dir():
        return _err(f"skill '{skill}' not found", 404)

    existing = _skill_doc_path(skill_dir)
    target = existing if existing is not None else (skill_dir / "SKILL.md")
    _atomic_write_text(target, content)
    return _ok({"updated": True, "filename": target.name})


@require_role("admin")
async def create_agent_skill(request: web.Request) -> web.Response:
    """Create a new skill folder with a SKILL.md."""
    agent = request.match_info["agent"]
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    name = body.get("name")
    content = body.get("content", "")
    if not name or not isinstance(name, str):
        return _err("missing or invalid 'name'")
    if not _SKILL_NAME_RE.match(name):
        return _err("invalid skill name (allowed: a-z, A-Z, 0-9, _, -)")
    if not isinstance(content, str):
        return _err("'content' must be a string")

    try:
        skills_dir = _resolve_skills_dir(request)
    except ValueError as exc:
        return _err(str(exc), 400)
    except FileNotFoundError as exc:
        return _err(str(exc), 404)

    skills_dir.mkdir(parents=True, exist_ok=True)
    skill_dir = skills_dir / name
    if not _skill_dir_is_in(skill_dir, skills_dir):
        return _err("invalid skill name", 400)
    if skill_dir.exists():
        return _err(f"skill '{name}' already exists", 409)

    skill_dir.mkdir(parents=True)
    target = skill_dir / "SKILL.md"
    target.write_text(content, "utf-8")

    stat = target.stat()
    return _ok({
        "name": name,
        "description": _skill_description(skill_dir),
        "path": str(skill_dir),
        "mtime": stat.st_mtime,
        "size": stat.st_size,
        "has_doc": True,
        "doc_filename": "SKILL.md",
    })


@require_role("admin")
async def delete_agent_skill(request: web.Request) -> web.Response:
    """Delete a skill directory (recursive)."""
    import shutil

    agent = request.match_info["agent"]
    skill = request.match_info["skill"]
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)
    if not _SKILL_NAME_RE.match(skill):
        return _err("invalid skill name", 400)

    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    try:
        skills_dir = _resolve_skills_dir(request)
    except ValueError as exc:
        return _err(str(exc), 400)
    except FileNotFoundError as exc:
        return _err(str(exc), 404)

    skill_dir = skills_dir / skill
    if not _skill_dir_is_in(skill_dir, skills_dir):
        return _err("invalid skill name", 400)
    if not skill_dir.exists():
        return _err(f"skill '{skill}' not found", 404)

    # Symlink: just remove the link, not the target
    if skill_dir.is_symlink():
        skill_dir.unlink()
    else:
        shutil.rmtree(skill_dir)
    return _ok({"deleted": True})


# ---------------------------------------------------------------------------
# Global (shared) skills
# ---------------------------------------------------------------------------


async def list_global_skills(request: web.Request) -> web.Response:
    """List skills in the shared ``~/.sygen/skills/`` directory."""
    return _ok(_collect_skills(_resolve_global_skills_dir(), "global"))


async def get_global_skill(request: web.Request) -> web.Response:
    """Return SKILL.md/README.md content for a global skill."""
    skill = request.match_info["skill"]
    if not _SKILL_NAME_RE.match(skill):
        return _err("invalid skill name", 400)

    global_dir = _resolve_global_skills_dir()
    skill_dir = global_dir / skill
    if not global_dir.is_dir() or not _skill_dir_is_in(skill_dir, global_dir):
        return _err(f"skill '{skill}' not found", 404)
    if not skill_dir.is_dir():
        return _err(f"skill '{skill}' not found", 404)

    payload = _read_skill_doc(skill_dir, skill, "global")
    if payload is None:
        return _err("failed to read skill", 500)
    return _ok(payload)


@require_role("admin")
async def create_global_skill(request: web.Request) -> web.Response:
    """Create a new global skill folder with a SKILL.md."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    name = body.get("name")
    content = body.get("content", "")
    if not name or not isinstance(name, str):
        return _err("missing or invalid 'name'")
    if not _SKILL_NAME_RE.match(name):
        return _err("invalid skill name (allowed: a-z, A-Z, 0-9, _, -)")
    if not isinstance(content, str):
        return _err("'content' must be a string")

    global_dir = _resolve_global_skills_dir()
    global_dir.mkdir(parents=True, exist_ok=True)
    skill_dir = global_dir / name
    if not _skill_dir_is_in(skill_dir, global_dir):
        return _err("invalid skill name", 400)
    if skill_dir.exists():
        return _err(f"skill '{name}' already exists", 409)

    skill_dir.mkdir(parents=True)
    target = skill_dir / "SKILL.md"
    target.write_text(content, "utf-8")

    stat = target.stat()
    return _ok({
        "name": name,
        "description": _skill_description(skill_dir),
        "path": str(skill_dir),
        "mtime": stat.st_mtime,
        "size": stat.st_size,
        "has_doc": True,
        "doc_filename": "SKILL.md",
        "scope": "global",
    })


@require_role("admin")
async def update_global_skill(request: web.Request) -> web.Response:
    """Update SKILL.md (or README.md if SKILL.md does not exist) for a global skill."""
    skill = request.match_info["skill"]
    if not _SKILL_NAME_RE.match(skill):
        return _err("invalid skill name", 400)

    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    content = body.get("content")
    if content is None:
        return _err("missing 'content' field")
    if not isinstance(content, str):
        return _err("'content' must be a string")

    global_dir = _resolve_global_skills_dir()
    skill_dir = global_dir / skill
    if not global_dir.is_dir() or not _skill_dir_is_in(skill_dir, global_dir):
        return _err(f"skill '{skill}' not found", 404)
    if not skill_dir.is_dir():
        return _err(f"skill '{skill}' not found", 404)

    existing = _skill_doc_path(skill_dir)
    target = existing if existing is not None else (skill_dir / "SKILL.md")
    _atomic_write_text(target, content)
    return _ok({"updated": True, "filename": target.name, "scope": "global"})


@require_role("admin")
async def delete_global_skill(request: web.Request) -> web.Response:
    """Delete a global skill directory (recursive)."""
    import shutil

    skill = request.match_info["skill"]
    if not _SKILL_NAME_RE.match(skill):
        return _err("invalid skill name", 400)

    global_dir = _resolve_global_skills_dir()
    skill_dir = global_dir / skill
    if not _skill_dir_is_in(skill_dir, global_dir):
        return _err("invalid skill name", 400)
    if not skill_dir.exists():
        return _err(f"skill '{skill}' not found", 404)

    if skill_dir.is_symlink():
        skill_dir.unlink()
    else:
        shutil.rmtree(skill_dir)
    return _ok({"deleted": True})


# ---------------------------------------------------------------------------
# RAG management
# ---------------------------------------------------------------------------

def _vector_db_path() -> Path:
    return _sygen_home() / "workspace" / "memory_system" / "vector_db"


def _dir_size_bytes(path: Path) -> int:
    total = 0
    if not path.is_dir():
        return 0
    for p in path.rglob("*"):
        if p.is_file():
            try:
                total += p.stat().st_size
            except OSError:
                continue
    return total


@require_role("operator")
async def get_rag_status(request: web.Request) -> web.Response:
    """Return RAG enable state, effective embedding model, and vector DB stats."""
    config_path = _sygen_home() / "config" / "config.json"
    data = _read_json(config_path) or {}
    rag_cfg: dict[str, Any] = data.get("rag") or {}
    mem_cfg: dict[str, Any] = data.get("memory") or {}

    embedding_model = (
        rag_cfg.get("embedding_model")
        or mem_cfg.get("vector_model")
        or "paraphrase-multilingual-MiniLM-L12-v2"
    )

    vdb = _vector_db_path()
    chunk_count = 0
    if vdb.is_dir():
        # ChromaDB stores a single SQLite file; count its data segments as a
        # cheap proxy for indexed rows without importing the client.
        try:
            import sqlite3
            sqlite_file = vdb / "chroma.sqlite3"
            if sqlite_file.is_file():
                with sqlite3.connect(f"file:{sqlite_file}?mode=ro", uri=True) as conn:
                    row = conn.execute("SELECT COUNT(*) FROM embeddings").fetchone()
                    chunk_count = int(row[0]) if row else 0
        except (ImportError, sqlite3.Error, OSError):
            chunk_count = 0

    # Memory facts: non-empty, non-comment lines across memory_system/*.md.
    # Recommendation thresholds (200/500) are expressed in facts, not chunks —
    # one fact can produce several chunks, and workspace indexing adds more.
    memory_fact_count = 0
    try:
        memory_dir = _resolve_memory_dir(request)
    except (ValueError, FileNotFoundError):
        memory_dir = _sygen_home() / "workspace" / "memory_system"
    if memory_dir.is_dir():
        for f in memory_dir.glob("*.md"):
            try:
                text = f.read_text("utf-8", errors="ignore")
            except OSError:
                continue
            for line in text.splitlines():
                stripped = line.strip()
                if stripped and not stripped.startswith("#") and not stripped.startswith("<!--"):
                    memory_fact_count += 1

    return _ok({
        "enabled": bool(rag_cfg.get("enabled", False)),
        "embedding_model": embedding_model,
        "reranker_enabled": bool(rag_cfg.get("reranker_enabled", False)),
        "reranker_model": rag_cfg.get("reranker_model", "antoinelouis/colbert-xm"),
        "index_workspace": bool(rag_cfg.get("index_workspace", True)),
        "index_memory": bool(rag_cfg.get("index_memory", True)),
        "top_k_retrieval": int(rag_cfg.get("top_k_retrieval", 20)),
        "top_k_final": int(rag_cfg.get("top_k_final", 5)),
        "vector_db_path": str(vdb),
        "vector_db_exists": vdb.is_dir(),
        "vector_db_size_bytes": _dir_size_bytes(vdb),
        "chunk_count": chunk_count,
        "memory_fact_count": memory_fact_count,
    })


@require_role("admin")
async def update_rag_config(request: web.Request) -> web.Response:
    """Update rag.* fields in config.json. Restart required to take effect."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    if not isinstance(body, dict):
        return _err("body must be an object")

    allowed = {
        "enabled": bool,
        "reranker_enabled": bool,
        "index_workspace": bool,
        "index_memory": bool,
        "top_k_retrieval": int,
        "top_k_final": int,
    }

    updates: dict[str, Any] = {}
    for key, value in body.items():
        if key not in allowed:
            return _err(f"unknown field '{key}'")
        expected = allowed[key]
        if expected is bool:
            if not isinstance(value, bool):
                return _err(f"'{key}' must be boolean")
        elif expected is int:
            if not isinstance(value, int) or isinstance(value, bool):
                return _err(f"'{key}' must be integer")
            if value < 1 or value > 100:
                return _err(f"'{key}' out of range (1..100)")
        updates[key] = value

    if not updates:
        return _err("no fields to update")

    config_path = _sygen_home() / "config" / "config.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    lock = await _with_file_lock(config_path)
    async with lock:
        data = _read_json(config_path) or {}
        rag_cfg = dict(data.get("rag") or {})
        rag_cfg.update(updates)
        data["rag"] = rag_cfg
        _write_json(config_path, data)

    return _ok({"updated": updates, "restart_required": True})


# ---------------------------------------------------------------------------
# Commands (slash command menu)
# ---------------------------------------------------------------------------

async def get_commands(request: web.Request) -> web.Response:
    """Return available bot commands for the command menu."""
    from sygen_bot.commands import get_bot_commands, get_multiagent_sub_commands

    commands = [
        {"command": f"/{cmd}", "description": desc}
        for cmd, desc in get_bot_commands()
    ]
    multiagent = [
        {"command": f"/{cmd}", "description": desc}
        for cmd, desc in get_multiagent_sub_commands()
    ]
    return _ok({"commands": commands, "multiagent": multiagent})


# ---------------------------------------------------------------------------
# System
# ---------------------------------------------------------------------------

def _get_cpu_percent() -> float:
    """Read CPU usage. Tries /proc/stat (Linux), falls back to psutil."""
    try:
        with open("/proc/stat") as f:
            line = f.readline()
        parts = line.split()
        idle = int(parts[4])
        total = sum(int(p) for p in parts[1:])
        if not hasattr(_get_cpu_percent, "_prev"):
            _get_cpu_percent._prev = (idle, total)  # type: ignore[attr-defined]
            return 0.0
        prev_idle, prev_total = _get_cpu_percent._prev  # type: ignore[attr-defined]
        _get_cpu_percent._prev = (idle, total)  # type: ignore[attr-defined]
        d_total = total - prev_total
        d_idle = idle - prev_idle
        if d_total == 0:
            return 0.0
        return round((1 - d_idle / d_total) * 100, 1)
    except Exception:
        try:
            import psutil
            return round(psutil.cpu_percent(interval=None), 1)
        except Exception:
            return 0.0


def _get_memory_percent() -> float:
    """Read RAM usage. Tries /proc/meminfo (Linux), falls back to psutil."""
    try:
        info: dict[str, int] = {}
        with open("/proc/meminfo") as f:
            for line in f:
                parts = line.split()
                if parts[0].rstrip(":") in ("MemTotal", "MemAvailable"):
                    info[parts[0].rstrip(":")] = int(parts[1])
        total = info.get("MemTotal", 0)
        avail = info.get("MemAvailable", 0)
        if total == 0:
            return 0.0
        return round((1 - avail / total) * 100, 1)
    except Exception:
        try:
            import psutil
            return round(psutil.virtual_memory().percent, 1)
        except Exception:
            return 0.0


def _get_disk_percent() -> float:
    """Get disk usage for the root partition. Returns 0 on failure."""
    try:
        import shutil
        usage = shutil.disk_usage("/")
        return round(usage.used / usage.total * 100, 1)
    except Exception:
        return 0.0


async def get_system_status(request: web.Request) -> web.Response:
    home = _sygen_home()
    uptime_seconds = time.monotonic() - _START_TIME

    agents_data = _read_json(_agents_registry_path(home))
    agent_count = 0
    if agents_data:
        agents = agents_data if isinstance(agents_data, list) else agents_data.get("agents", [])
        agent_count = len(agents)

    tasks_data = _read_json(home / "tasks.json")
    active_tasks = 0
    total_tasks = 0
    if tasks_data:
        tasks_list = tasks_data.get("tasks", []) if isinstance(tasks_data, dict) else tasks_data
        total_tasks = len(tasks_list)
        active_tasks = sum(1 for t in tasks_list if t.get("status") in ("running", "pending"))

    cron_data = _read_json(home / "cron_jobs.json")
    cron_count = 0
    if cron_data:
        jobs = cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data
        cron_count = len(jobs)

    sessions_data = _read_json(home / "sessions.json")
    session_count = len(sessions_data) if sessions_data else 0

    config = _read_json(home / "config" / "config.json") or {}
    instance_name = config.get("instance_name", "")

    return _ok({
        "instance_name": instance_name,
        "uptime_seconds": round(uptime_seconds),
        "agents": agent_count,
        "sessions": session_count,
        "cron_jobs": cron_count,
        "tasks_total": total_tasks,
        "tasks_active": active_tasks,
        "cpu_percent": _get_cpu_percent(),
        "ram_percent": _get_memory_percent(),
        "disk_percent": _get_disk_percent(),
    })


@require_role("admin")
async def update_instance_name(request: web.Request) -> web.Response:
    """Update the server instance name in config.json."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    name = body.get("instance_name")
    if name is None or not isinstance(name, str):
        return _err("missing or invalid 'instance_name' field")

    name = name.strip()[:100]

    config_path = _sygen_home() / "config" / "config.json"
    lock = await _with_file_lock(config_path)
    async with lock:
        data = _read_json(config_path) or {}
        data["instance_name"] = name
        _write_json(config_path, data)

    return _ok({"instance_name": name})


_SECRET_KEY_RE = re.compile(r"(?i)(password|token|secret|api[_-]?key|bearer)")


def _sanitize_config_tree(obj: Any) -> Any:
    """Recursively redact values whose keys look like secrets.

    Walks dicts and lists. Any key matching ``_SECRET_KEY_RE`` has its
    value replaced with ``"***"`` (or an empty/None placeholder preserving
    scalar type shape). Non-secret structures are traversed so nested
    secrets are caught regardless of depth.
    """
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            if isinstance(k, str) and _SECRET_KEY_RE.search(k):
                if v is None:
                    out[k] = None
                elif isinstance(v, bool):
                    # Leave booleans alone — they don't carry secret material.
                    out[k] = v
                elif isinstance(v, str):
                    out[k] = "***" if v else ""
                elif isinstance(v, (list, dict)):
                    out[k] = "***"
                else:
                    out[k] = "***"
            else:
                out[k] = _sanitize_config_tree(v)
        return out
    if isinstance(obj, list):
        return [_sanitize_config_tree(item) for item in obj]
    return obj


@require_role("admin")
async def get_config(request: web.Request) -> web.Response:
    """Read the server config with secrets redacted at every depth.

    Secrets are stripped for all callers (including admins) — the admin
    UI does not need cleartext secrets from this endpoint; operators who
    truly need them can read ``config.json`` on the host.
    """
    config_path = _sygen_home() / "config" / "config.json"
    data = _read_json(config_path)
    if data is None:
        return _ok({})
    return _ok(_sanitize_config_tree(data))


def _resolve_agent_log(agent: str) -> tuple[Path, str | None]:
    """Find the log file for an agent.

    Returns (log_path, filter_tag).  If a dedicated ``{agent}.log`` exists,
    return it with no filter.  Otherwise fall back to the shared
    ``agent.log`` and filter by ``[{agent}]`` tag prefix.
    """
    home = _sygen_home()
    dedicated = home / "logs" / f"{agent}.log"
    if dedicated.is_file():
        return dedicated, None
    shared = home / "logs" / "agent.log"
    if shared.is_file():
        return shared, f"[{agent}]"
    return dedicated, None  # will trigger 404


def _filter_by_agent_tag(lines: list[str], tag: str) -> list[str]:
    """Keep only lines whose log context contains *tag* (e.g. ``[sonic]``)."""
    return [ln for ln in lines if tag in ln]


@require_role("operator")
async def get_logs(request: web.Request) -> web.Response:
    # Safe int parsing (#17)
    try:
        lines = int(request.query.get("lines", "100"))
    except (ValueError, TypeError):
        lines = 100
    lines = min(max(lines, 1), 5000)

    agent = request.query.get("agent", "main")

    # Validate agent name to prevent path traversal (#1)
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name (only alphanumeric, hyphens, and underscores allowed)", 400)

    # Validate agent against allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _err(f"log file for agent '{agent}' not found", 404)

    log_path, tag = _resolve_agent_log(agent)
    if not log_path.is_file():
        return _err(f"log file for agent '{agent}' not found", 404)

    # When filtering a shared log, read the maximum allowed since the target
    # agent may be a small fraction of total entries.
    read_lines = 5000 if tag else lines
    result = _read_last_lines(log_path, read_lines)
    if tag:
        result = _filter_by_agent_tag(result, tag)[-lines:]

    return _ok({"agent": agent, "lines": result})


# ---------------------------------------------------------------------------
# Users (RBAC management)
# ---------------------------------------------------------------------------

_USERNAME_RE = re.compile(r"^[a-zA-Z0-9_.-]{2,50}$")

# Lock for users.json operations
_users_lock: asyncio.Lock | None = None


async def _get_users_lock() -> asyncio.Lock:
    global _users_lock
    if _users_lock is None:
        _users_lock = asyncio.Lock()
    return _users_lock


def _validate_allowed_agents(allowed_agents: list[Any]) -> str | None:
    """Validate allowed_agents items. Returns error message or None."""
    for item in allowed_agents:
        if not isinstance(item, str):
            return "allowed_agents items must be strings"
        if not _AGENT_NAME_RE.match(item):
            return f"invalid agent name in allowed_agents: '{item}'"
    return None


@require_role("admin")
async def get_users(request: web.Request) -> web.Response:
    """List all users (passwords excluded)."""
    users = _read_users()
    safe = []
    for u in users:
        safe.append({
            "username": u.get("username"),
            "role": u.get("role", "viewer"),
            "display_name": u.get("display_name", ""),
            "allowed_agents": u.get("allowed_agents", []),
            "active": u.get("active", True),
            "created_at": u.get("created_at"),
        })
    return _ok(safe)


@require_role("admin")
async def create_user(request: web.Request) -> web.Response:
    """Create a new user."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    username = str(body.get("username", "")).strip()
    password = str(body.get("password", ""))
    role = str(body.get("role", "viewer"))
    display_name = str(body.get("display_name", username))
    allowed_agents = body.get("allowed_agents", [])

    if not username or not _USERNAME_RE.match(username):
        return _err("invalid username (2-50 chars, alphanumeric/._-)")
    pw_err = _validate_password_policy(password)
    if pw_err:
        return _err(pw_err)
    if role not in ROLE_LEVELS:
        return _err(f"invalid role, must be one of: {', '.join(ROLE_LEVELS)}")
    if not isinstance(allowed_agents, list):
        return _err("allowed_agents must be a list")
    agents_err = _validate_allowed_agents(allowed_agents)
    if agents_err:
        return _err(agents_err)

    lock = await _get_users_lock()
    async with lock:
        users = _read_users()
        if any(u.get("username") == username for u in users):
            return _err(f"user '{username}' already exists", 409)

        user_entry = {
            "username": username,
            "password_hash": hash_password(password),
            "role": role,
            "display_name": display_name,
            "allowed_agents": allowed_agents,
            "active": True,
            "created_at": time.time(),
            "token_version": 0,
        }
        users.append(user_entry)
        _write_users(users)

    actor = request.get("jwt_user", {}).get("sub", "unknown")
    write_audit(user=actor, action="user_created", target=username, details=f"role={role}")

    return _ok({
        "username": username,
        "role": role,
        "display_name": display_name,
        "allowed_agents": allowed_agents,
        "active": True,
    })


@require_role("admin")
async def update_user(request: web.Request) -> web.Response:
    """Update user fields (role, display_name, allowed_agents, active, password)."""
    username = request.match_info["username"]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    actor = request.get("jwt_user", {}).get("sub", "unknown")

    # Prevent admin from demoting or disabling themselves
    if username == actor:
        if "role" in body and str(body["role"]) != "admin":
            return _err("cannot demote yourself", 400)
        if "active" in body and not body["active"]:
            return _err("cannot disable yourself", 400)

    if "role" in body:
        role = str(body["role"])
        if role not in ROLE_LEVELS:
            return _err(f"invalid role, must be one of: {', '.join(ROLE_LEVELS)}")

    if "allowed_agents" in body:
        if not isinstance(body["allowed_agents"], list):
            return _err("allowed_agents must be a list")
        agents_err = _validate_allowed_agents(body["allowed_agents"])
        if agents_err:
            return _err(agents_err)

    if "password" in body:
        password = str(body["password"])
        pw_err = _validate_password_policy(password)
        if pw_err:
            return _err(pw_err)

    lock = await _get_users_lock()
    async with lock:
        users = _read_users()
        target = None
        for u in users:
            if u.get("username") == username:
                target = u
                break

        if target is None:
            return _err(f"user '{username}' not found", 404)

        if "role" in body:
            target["role"] = str(body["role"])

        if "display_name" in body:
            target["display_name"] = str(body["display_name"])

        if "allowed_agents" in body:
            target["allowed_agents"] = body["allowed_agents"]

        if "active" in body:
            target["active"] = bool(body["active"])

        if "password" in body:
            target["password_hash"] = hash_password(str(body["password"]))
            # Revoke all existing tokens for this user
            target["token_version"] = int(target.get("token_version", 0)) + 1

        _write_users(users)

    changes = [k for k in ("role", "display_name", "allowed_agents", "active", "password") if k in body]
    write_audit(user=actor, action="user_updated", target=username, details=f"changed={','.join(changes)}")

    return _ok({
        "username": target.get("username"),
        "role": target.get("role"),
        "display_name": target.get("display_name", ""),
        "allowed_agents": target.get("allowed_agents", []),
        "active": target.get("active", True),
    })


@require_role("admin")
async def delete_user(request: web.Request) -> web.Response:
    """Delete a user."""
    username = request.match_info["username"]
    actor = request.get("jwt_user", {}).get("sub", "unknown")

    if username == actor:
        return _err("cannot delete yourself", 400)

    lock = await _get_users_lock()
    async with lock:
        users = _read_users()
        original_len = len(users)
        users = [u for u in users if u.get("username") != username]

        if len(users) == original_len:
            return _err(f"user '{username}' not found", 404)

        _write_users(users)

    write_audit(user=actor, action="user_deleted", target=username)
    return _ok({"deleted": username})


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------

@require_role("admin")
async def get_audit_log(request: web.Request) -> web.Response:
    """Return recent audit log entries."""
    try:
        limit = int(request.query.get("limit", "200"))
    except (ValueError, TypeError):
        limit = 200
    limit = min(max(limit, 1), 2000)
    entries = read_audit(limit)
    return _ok(entries)


# ---------------------------------------------------------------------------
# Providers (authenticated CLI providers + their models)
# ---------------------------------------------------------------------------


def _provider_manager_for_main(request: web.Request) -> Any | None:
    """Return the ProviderManager from the main agent's orchestrator, or None."""
    resolve_agent = request.app.get("resolve_agent")
    if not resolve_agent:
        return None
    stack = resolve_agent("main")
    if stack is None:
        return None
    bot = getattr(stack, "bot", None)
    orch = getattr(bot, "orchestrator", None) if bot is not None else None
    if orch is None:
        return None
    return orch


@require_role("operator")
async def get_available_providers(request: web.Request) -> web.Response:
    """List CLI providers (authenticated and unauthenticated) with their models."""
    orch = _provider_manager_for_main(request)
    if orch is None:
        return _err("main agent orchestrator is not ready", 503)

    pm = orch._providers
    codex_obs = getattr(getattr(orch, "_observers", None), "codex_cache_obs", None)

    known_pids = ("claude", "gemini", "codex")
    authenticated_info = {p["id"]: p for p in pm.build_provider_info(codex_obs)}

    providers: list[dict[str, object]] = []
    for pid in known_pids:
        meta = authenticated_info.get(pid)
        if meta is not None:
            models = list(meta.get("models") or [])
            default = pm.default_model_for_provider(pid) or (models[0] if models else None)
            providers.append(
                {
                    "name": pid,
                    "authenticated": True,
                    "models": models,
                    "default_model": default,
                    "display_name": meta.get("name"),
                    "color": meta.get("color"),
                }
            )
        else:
            providers.append(
                {
                    "name": pid,
                    "authenticated": False,
                    "models": [],
                    "default_model": None,
                    "display_name": pid.capitalize(),
                    "color": None,
                }
            )

    agent_model = getattr(orch._config, "model", "") or ""
    agent_provider = pm.models.provider_for(agent_model) if agent_model else None
    return _ok(
        {
            "providers": providers,
            "agent_default_model": agent_model or None,
            "agent_default_provider": agent_provider,
        }
    )


# ---------------------------------------------------------------------------
# Chat Sessions
# ---------------------------------------------------------------------------

_CHAT_SESSIONS_ALLOWED_FIELDS = {"title"}
_KNOWN_PROVIDER_IDS = frozenset({"claude", "gemini", "codex"})

# Valid session ID: UUID or safe alphanumeric (no path separators)
_SESSION_ID_RE = re.compile(r"^[a-zA-Z0-9_-]+$")


def _chat_sessions_path() -> Path:
    return _sygen_home() / "chat_sessions.json"


def _chat_history_dir() -> Path:
    return _sygen_home() / "chat_history"


def _validate_session_id(session_id: str) -> web.Response | None:
    """Return an error response if session_id is invalid, else None."""
    if not session_id or not _SESSION_ID_RE.match(session_id):
        return _err("invalid session id", 400)
    return None


async def get_chat_sessions(request: web.Request) -> web.Response:
    """List chat sessions, optionally filtered by agent."""
    agent = request.query.get("agent")
    if agent and not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    # Validate agent param against allowed_agents
    allowed = _get_allowed_agents(request)
    if agent and allowed and agent not in allowed:
        return _ok([])

    data = _read_json(_chat_sessions_path())
    sessions = (data or {}).get("sessions", [])

    if agent:
        sessions = [s for s in sessions if s.get("agent") == agent]

    # Filter by allowed_agents if no specific agent was requested
    if not agent and allowed:
        sessions = _filter_by_allowed_agents(sessions, allowed, key="agent")

    sessions.sort(key=lambda s: s.get("updated_at", 0), reverse=True)
    return _ok(sessions)


@require_role("operator")
async def create_chat_session(request: web.Request) -> web.Response:
    """Create a new chat session."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    agent = str(body.get("agent", "main"))
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    # Enforce per-agent access
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _err(f"agent '{agent}' is not in your allowed agents", 403)

    title = str(body.get("title", "")).strip()
    now = time.time()

    session = {
        "id": str(uuid.uuid4()),
        "agent": agent,
        "title": title or f"Chat {time.strftime('%Y-%m-%d %H:%M')}",
        "created_at": now,
        "updated_at": now,
    }

    path = _chat_sessions_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"sessions": []}
        sessions = data.get("sessions", [])
        sessions.append(session)
        data["sessions"] = sessions
        _write_json(path, data)

    return _ok(session)


@require_role("operator")
async def delete_chat_session(request: web.Request) -> web.Response:
    """Delete a chat session and its message history."""
    session_id = request.match_info["id"]
    if err := _validate_session_id(session_id):
        return err

    path = _chat_sessions_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("no chat sessions found", 404)

        sessions = data.get("sessions", [])

        # Find the session and enforce per-agent access
        target_session = None
        for s in sessions:
            if s.get("id") == session_id:
                target_session = s
                break
        if target_session is None:
            return _err(f"chat session '{session_id}' not found", 404)

        allowed = _get_allowed_agents(request)
        if allowed and target_session.get("agent") not in allowed:
            return _err(f"chat session '{session_id}' not found", 404)

        sessions = [s for s in sessions if s.get("id") != session_id]
        data["sessions"] = sessions
        _write_json(path, data)

    # Remove message history file if it exists
    history_file = _chat_history_dir() / f"{session_id}.json"
    if history_file.is_file():
        try:
            history_file.unlink()
        except OSError:
            pass

    return _ok({"deleted": session_id})


@require_role("operator")
async def update_chat_session(request: web.Request) -> web.Response:
    """Update a chat session (e.g. rename)."""
    session_id = request.match_info["id"]
    if err := _validate_session_id(session_id):
        return err

    try:
        body = await request.json()
    except Exception:
        return _err("invalid JSON body", 400)

    updates = {k: body[k] for k in _CHAT_SESSIONS_ALLOWED_FIELDS if k in body}
    if not updates:
        return _err("no valid fields to update", 400)

    path = _chat_sessions_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("no chat sessions found", 404)

        sessions = data.get("sessions", [])
        target = None
        for s in sessions:
            if s.get("id") == session_id:
                target = s
                break
        if target is None:
            return _err(f"chat session '{session_id}' not found", 404)

        allowed = _get_allowed_agents(request)
        if allowed and target.get("agent") not in allowed:
            return _err(f"chat session '{session_id}' not found", 404)

        import time
        target.update(updates)
        target["updated_at"] = time.time()
        data["sessions"] = sessions
        _write_json(path, data)

    return _ok(target)


@require_role("operator")
async def set_session_provider(request: web.Request) -> web.Response:
    """Set or clear a per-session provider/model override.

    Body: ``{"provider": "claude", "model": "opus"}`` to set, or
    ``{"provider": null, "model": null}`` to reset to the agent default.
    """
    session_id = request.match_info["id"]
    if err := _validate_session_id(session_id):
        return err

    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body", 400)

    raw_provider = body.get("provider", None)
    raw_model = body.get("model", None)

    provider: str | None
    model: str | None
    if raw_provider is None and raw_model is None:
        provider, model = None, None
    else:
        if not isinstance(raw_provider, str) or not raw_provider:
            return _err("'provider' must be a non-empty string", 400)
        provider = raw_provider.strip().lower()
        if provider not in _KNOWN_PROVIDER_IDS:
            return _err(f"unknown provider '{provider}'", 400)

        # Consult the live ProviderManager to validate auth + model
        orch = _provider_manager_for_main(request)
        if orch is None:
            return _err("main agent orchestrator is not ready", 503)
        pm = orch._providers
        if provider not in pm.available_providers:
            return _err(f"provider '{provider}' is not authenticated", 400)

        codex_obs = getattr(getattr(orch, "_observers", None), "codex_cache_obs", None)
        pinfo = next(
            (p for p in pm.build_provider_info(codex_obs) if p["id"] == provider),
            None,
        )
        allowed_models = list(pinfo.get("models") or []) if pinfo else []

        if raw_model is None or raw_model == "":
            model = pm.default_model_for_provider(provider) or (
                allowed_models[0] if allowed_models else None
            )
        else:
            if not isinstance(raw_model, str):
                return _err("'model' must be a string or null", 400)
            model = raw_model.strip()
            if allowed_models and model not in allowed_models:
                return _err(
                    f"model '{model}' is not available for provider '{provider}'",
                    400,
                )

    path = _chat_sessions_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("no chat sessions found", 404)

        sessions = data.get("sessions", [])
        target = next((s for s in sessions if s.get("id") == session_id), None)
        if target is None:
            return _err(f"chat session '{session_id}' not found", 404)

        allowed = _get_allowed_agents(request)
        if allowed and target.get("agent") not in allowed:
            return _err(f"chat session '{session_id}' not found", 404)

        if provider is None:
            target.pop("provider_override", None)
            target.pop("model_override", None)
        else:
            target["provider_override"] = provider
            target["model_override"] = model
        target["updated_at"] = time.time()
        data["sessions"] = sessions
        _write_json(path, data)

    return _ok(
        {
            "session_id": session_id,
            "provider": target.get("provider_override"),
            "model": target.get("model_override"),
        }
    )


async def get_chat_messages(request: web.Request) -> web.Response:
    """Get message history for a chat session."""
    session_id = request.match_info["id"]
    if err := _validate_session_id(session_id):
        return err

    # Verify session exists and enforce per-agent access
    data = _read_json(_chat_sessions_path())
    sessions = (data or {}).get("sessions", [])
    target_session = next((s for s in sessions if s.get("id") == session_id), None)
    if target_session is None:
        return _err(f"chat session '{session_id}' not found", 404)

    allowed = _get_allowed_agents(request)
    if allowed and target_session.get("agent") not in allowed:
        return _err(f"chat session '{session_id}' not found", 404)

    history_file = _chat_history_dir() / f"{session_id}.json"
    messages = _read_json(history_file)
    if messages is None:
        return _ok([])

    msg_list = messages.get("messages", []) if isinstance(messages, dict) else messages
    return _ok(msg_list)


@require_role("operator")
async def save_chat_message(request: web.Request) -> web.Response:
    """Save a message to a chat session's history."""
    session_id = request.match_info["id"]
    if err := _validate_session_id(session_id):
        return err

    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    # Verify session exists and enforce per-agent access
    sessions_data = _read_json(_chat_sessions_path())
    sessions = (sessions_data or {}).get("sessions", [])
    target_session = next((s for s in sessions if s.get("id") == session_id), None)
    if target_session is None:
        return _err(f"chat session '{session_id}' not found", 404)

    allowed = _get_allowed_agents(request)
    if allowed and target_session.get("agent") not in allowed:
        return _err(f"chat session '{session_id}' not found", 404)

    messages = body.get("messages")
    if not isinstance(messages, list):
        return _err("'messages' must be a list")

    history_dir = _chat_history_dir()
    history_dir.mkdir(parents=True, exist_ok=True)
    history_file = history_dir / f"{session_id}.json"

    lock = await _with_file_lock(history_file)
    async with lock:
        _write_json(history_file, {"messages": messages})

    # Update session's updated_at timestamp
    sessions_path = _chat_sessions_path()
    sessions_lock = await _with_file_lock(sessions_path)
    async with sessions_lock:
        data = _read_json(sessions_path) or {"sessions": []}
        for s in data.get("sessions", []):
            if s.get("id") == session_id:
                s["updated_at"] = time.time()
                break
        _write_json(sessions_path, data)

    return _ok({"saved": len(messages)})


# ---------------------------------------------------------------------------
# Activity Feed (unified)
# ---------------------------------------------------------------------------


@require_role("admin")
async def get_activity(request: web.Request) -> web.Response:
    """Return a unified activity feed from audit log, tasks, and sessions."""
    try:
        limit = int(request.query.get("limit", "50"))
    except (ValueError, TypeError):
        limit = 50
    limit = min(max(limit, 1), 200)

    events: list[dict[str, Any]] = []

    # 1. Audit log events (login, user CRUD)
    try:
        audit_entries = read_audit(100)
        for entry in audit_entries:
            action = entry.get("action", "")
            user = entry.get("user", "")
            target = entry.get("target", "")
            details = entry.get("details", "")

            if action == "login":
                message = f"User '{user}' logged in"
                event_type = "login"
            elif action == "user_created":
                message = f"User '{target}' created by {user}"
                event_type = "user"
            elif action == "user_updated":
                message = f"User '{target}' updated by {user}"
                event_type = "user"
            elif action == "user_deleted":
                message = f"User '{target}' deleted by {user}"
                event_type = "user"
            else:
                message = f"{action}: {target}" if target else action
                event_type = "system"

            events.append({
                "type": event_type,
                "message": message,
                "agent": "",
                "timestamp": entry.get("ts", ""),
                "details": details,
            })
    except Exception:
        pass

    # 2. Task events (completions/failures)
    try:
        tasks_data = _read_json(_sygen_home() / "tasks.json")
        if tasks_data:
            tasks_list = tasks_data.get("tasks", []) if isinstance(tasks_data, dict) else tasks_data
            for task in tasks_list:
                status = task.get("status", "")
                name = task.get("name", task.get("task_id", "unknown"))
                agent = task.get("parent_agent", task.get("agent", ""))

                if status in ("done", "completed"):
                    message = f"Task '{name}' completed"
                    event_type = "task"
                elif status == "failed":
                    message = f"Task '{name}' failed"
                    event_type = "task"
                elif status == "running":
                    message = f"Task '{name}' started"
                    event_type = "task"
                elif status == "cancelled":
                    message = f"Task '{name}' cancelled"
                    event_type = "task"
                else:
                    continue

                ts = task.get("completed_at") or task.get("created_at", 0)
                if isinstance(ts, (int, float)) and ts > 0:
                    ts_str = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts))
                else:
                    ts_str = str(ts)

                events.append({
                    "type": event_type,
                    "message": message,
                    "agent": agent,
                    "timestamp": ts_str,
                    "details": task.get("error", ""),
                })
    except Exception:
        pass

    # 3. Cron job events
    try:
        cron_data = _read_json(_sygen_home() / "cron_jobs.json")
        if cron_data:
            jobs = cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data
            for job in jobs:
                last_run = job.get("last_run", "")
                if last_run and last_run != "-":
                    job_name = job.get("title", job.get("id", "unknown"))
                    agent = job.get("agent", "")
                    events.append({
                        "type": "cron",
                        "message": f"Cron '{job_name}' executed",
                        "agent": agent,
                        "timestamp": last_run,
                        "details": "",
                    })
    except Exception:
        pass

    # 4. Agent session events
    try:
        sessions_data = _read_json(_sygen_home() / "sessions.json")
        if sessions_data and isinstance(sessions_data, dict):
            for session_id, session in sessions_data.items():
                if isinstance(session, dict):
                    agent = session.get("agent", session_id)
                    started = session.get("started_at", session.get("created_at", ""))
                    if started:
                        if isinstance(started, (int, float)) and started > 0:
                            ts_str = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(started))
                        else:
                            ts_str = str(started)
                        events.append({
                            "type": "agent",
                            "message": f"Agent session '{session_id}' active",
                            "agent": agent,
                            "timestamp": ts_str,
                            "details": "",
                        })
    except Exception:
        pass

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed:
        events = [e for e in events if not e.get("agent") or e["agent"] in allowed]

    # Sort by timestamp descending
    events.sort(key=lambda e: e.get("timestamp", ""), reverse=True)

    return _ok(events[:limit])


# ---------------------------------------------------------------------------
# Export / Import configuration
# ---------------------------------------------------------------------------


@require_role("admin")
async def export_config(request: web.Request) -> web.Response:
    """Export cron_jobs, webhooks, and users (without password_hash) as a single JSON."""
    home = _sygen_home()

    cron_data = _read_json(home / "cron_jobs.json")
    cron_jobs = (cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data) if cron_data else []

    wh_data = _read_json(home / "webhooks.json")
    webhooks = (wh_data.get("webhooks", []) if isinstance(wh_data, dict) else wh_data) if wh_data else []

    users_raw = _read_users()
    _user_secret_fields = {"password_hash", "totp_secret", "totp_enabled"}
    users_safe = []
    for u in users_raw:
        users_safe.append({
            k: v for k, v in u.items() if k not in _user_secret_fields
        })

    export_payload = {
        "version": 1,
        "exported_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "cron_jobs": cron_jobs,
        "webhooks": webhooks,
        "users": users_safe,
    }
    return _ok(export_payload)


@require_role("admin")
async def import_config(request: web.Request) -> web.Response:
    """Import configuration (merge mode: add new items, skip existing)."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    if not isinstance(body, dict):
        return _err("expected a JSON object")
    if body.get("version") != 1:
        return _err("unsupported export version (expected 1)")
    for key in ("cron_jobs", "webhooks", "users"):
        if key in body and not isinstance(body[key], list):
            return _err(f"'{key}' must be a list")

    import_cron = body.get("cron_jobs", [])
    import_webhooks = body.get("webhooks", [])
    import_users = body.get("users", [])

    home = _sygen_home()
    summary = {"cron_jobs_added": 0, "webhooks_added": 0, "users_added": 0, "skipped": 0}

    # --- Cron jobs (merge) ---
    if import_cron:
        cron_path = home / "cron_jobs.json"
        lock = await _with_file_lock(cron_path)
        async with lock:
            cron_data = _read_json(cron_path) or {"jobs": []}
            jobs = cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data
            existing_ids = {j.get("id") for j in jobs}
            for cj in import_cron:
                if not isinstance(cj, dict) or not cj.get("id"):
                    summary["skipped"] += 1
                    continue
                if cj["id"] in existing_ids:
                    summary["skipped"] += 1
                    continue
                # Validate schedule if present
                schedule = str(cj.get("schedule", ""))
                if schedule and not _CRON_SCHEDULE_RE.match(schedule):
                    summary["skipped"] += 1
                    continue
                # Filter to allowed fields only
                filtered_cj = _filter_fields(cj, _CRON_ALLOWED_FIELDS)
                jobs.append(filtered_cj)
                summary["cron_jobs_added"] += 1
            if isinstance(cron_data, dict):
                cron_data["jobs"] = jobs
            else:
                cron_data = {"jobs": jobs}
            _write_json(cron_path, cron_data)

    # --- Webhooks (merge) ---
    if import_webhooks:
        wh_path = home / "webhooks.json"
        lock = await _with_file_lock(wh_path)
        async with lock:
            wh_data = _read_json(wh_path) or {"webhooks": []}
            whs = wh_data.get("webhooks", []) if isinstance(wh_data, dict) else wh_data
            existing_ids = {w.get("id") for w in whs}
            for wh in import_webhooks:
                if not isinstance(wh, dict) or not wh.get("id"):
                    summary["skipped"] += 1
                    continue
                if wh["id"] in existing_ids:
                    summary["skipped"] += 1
                    continue
                # Filter to allowed fields only
                filtered_wh = _filter_fields(wh, _WEBHOOK_ALLOWED_FIELDS)
                whs.append(filtered_wh)
                summary["webhooks_added"] += 1
            if isinstance(wh_data, dict):
                wh_data["webhooks"] = whs
            else:
                wh_data = {"webhooks": whs}
            _write_json(wh_path, wh_data)

    # --- Users (merge, skip existing usernames) ---
    if import_users:
        # Allowed user fields during import (strip secrets and sensitive fields)
        _import_user_allowed = {"username", "role", "display_name", "allowed_agents"}
        lock = await _get_users_lock()
        async with lock:
            users = _read_users()
            existing_usernames = {u.get("username") for u in users}
            for u in import_users:
                if not isinstance(u, dict) or not u.get("username"):
                    summary["skipped"] += 1
                    continue
                username = str(u["username"]).strip()
                if not _USERNAME_RE.match(username):
                    summary["skipped"] += 1
                    continue
                if username in existing_usernames:
                    summary["skipped"] += 1
                    continue
                # Only allow safe fields
                entry = {k: v for k, v in u.items() if k in _import_user_allowed}
                entry["username"] = username
                # Validate and constrain role
                role = str(entry.get("role", "viewer"))
                if role not in ROLE_LEVELS:
                    role = "viewer"
                entry["role"] = role
                # Imported users are always inactive (admin must activate manually)
                entry["active"] = False
                entry.setdefault("created_at", time.time())
                # Validate allowed_agents if present
                if "allowed_agents" in entry:
                    if not isinstance(entry["allowed_agents"], list):
                        entry["allowed_agents"] = []
                    else:
                        err = _validate_allowed_agents(entry["allowed_agents"])
                        if err:
                            entry["allowed_agents"] = []
                users.append(entry)
                summary["users_added"] += 1
            _write_users(users)

    jwt_user = request.get("jwt_user", {})
    username = jwt_user.get("sub", "unknown")
    write_audit(
        user=username,
        action="import_config",
        target="system",
        details=json.dumps(summary),
    )

    return _ok(summary)


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------


def _parse_severities(raw: str | None) -> tuple[str, ...] | None:
    """Parse a comma-separated severity filter from a query string.

    Returns None when no filter is requested. Unknown values are dropped
    silently.
    """
    if not raw:
        return None
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    valid = tuple(p for p in parts if p in VALID_SEVERITIES)
    return valid or None


@require_role("operator")
async def get_notifications_handler(request: web.Request) -> web.Response:
    try:
        limit = int(request.query.get("limit", "50"))
    except (ValueError, TypeError):
        limit = 50
    limit = min(max(limit, 1), 500)
    unread_only = request.query.get("unread_only", "").lower() in ("true", "1", "yes")
    severities = _parse_severities(request.query.get("severity"))
    allowed = _get_allowed_agents(request)
    # When ACL is set, fetch the full backlog and filter; otherwise paginate directly.
    if allowed:
        items = await get_notifications(limit=500, unread_only=unread_only, severities=severities)
        items = [n for n in items if not n.get("agent") or n.get("agent") in allowed]
        items = items[:limit]
    else:
        items = await get_notifications(limit=limit, unread_only=unread_only, severities=severities)
    return _ok(items)


@require_role("operator")
async def get_unread_count_handler(request: web.Request) -> web.Response:
    allowed = _get_allowed_agents(request)
    if allowed:
        # Fetch only severities that count toward unread; filter by ACL.
        items = await get_notifications(
            limit=500, unread_only=True, severities=tuple(UNREAD_SEVERITIES)
        )
        count = sum(1 for n in items if not n.get("agent") or n.get("agent") in allowed)
    else:
        count = await get_unread_count()
    return web.json_response({"ok": True, "data": {"count": count}})


@require_role("operator")
async def mark_read_handler(request: web.Request) -> web.Response:
    notif_id = request.match_info["id"]
    found = await mark_read(notif_id)
    if not found:
        return _err(f"notification '{notif_id}' not found", 404)
    return _ok({"marked": notif_id})


@require_role("operator")
async def mark_all_read_handler(request: web.Request) -> web.Response:
    count = await mark_all_read()
    return _ok({"marked": count})


# ---------------------------------------------------------------------------
# Live log polling
# ---------------------------------------------------------------------------


@require_role("operator")
async def get_logs_poll(request: web.Request) -> web.Response:
    """Return log lines after a given timestamp for live tail polling."""
    agent = request.query.get("agent", "main")

    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    # Validate agent against allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _ok({"agent": agent, "lines": [], "timestamp": time.time()})

    try:
        after = float(request.query.get("after", "0"))
    except (ValueError, TypeError):
        after = 0

    try:
        lines_limit = int(request.query.get("lines", "200"))
    except (ValueError, TypeError):
        lines_limit = 200
    lines_limit = min(max(lines_limit, 1), 5000)

    log_path, tag = _resolve_agent_log(agent)
    if not log_path.is_file():
        return _ok({"agent": agent, "lines": [], "timestamp": time.time()})

    try:
        mtime = log_path.stat().st_mtime
    except OSError:
        return _ok({"agent": agent, "lines": [], "timestamp": time.time()})

    now = time.time()

    if after > 0 and mtime <= after:
        return _ok({"agent": agent, "lines": [], "timestamp": now})

    read_lines = 5000 if tag else lines_limit
    result = _read_last_lines(log_path, read_lines)
    if tag:
        result = _filter_by_agent_tag(result, tag)[-lines_limit:]
    return _ok({"agent": agent, "lines": result, "timestamp": now})


# ---------------------------------------------------------------------------
# Agent Metrics
# ---------------------------------------------------------------------------


def _get_traces_db_path() -> Path:
    return _sygen_home() / "logs" / "traces.db"


def _query_agent_metrics(db_path: Path, agent_name: str, since_iso: str) -> dict[str, Any]:
    """Query aggregated metrics for an agent from traces.db."""
    empty: dict[str, Any] = {
        "total_executions": 0,
        "avg_duration_seconds": 0.0,
        "error_count": 0,
        "success_rate": 100.0,
        "last_active": None,
        "tokens_used": None,
    }
    if not db_path.is_file():
        return empty

    try:
        conn = sqlite3.connect(str(db_path), timeout=5)
        conn.execute("PRAGMA journal_mode=WAL")
    except sqlite3.Error:
        return empty

    try:
        row = conn.execute(
            "SELECT COUNT(*), COALESCE(AVG(duration_sec), 0), "
            "SUM(CASE WHEN status != 'ok' THEN 1 ELSE 0 END), "
            "MAX(finished) "
            "FROM traces WHERE agent_name = ? AND started >= ?",
            (agent_name, since_iso),
        ).fetchone()

        if not row or row[0] == 0:
            return empty

        total = row[0]
        avg_dur = round(row[1], 2)
        errors = row[2] or 0
        last_active = row[3]
        success_rate = round(((total - errors) / total) * 100, 1) if total > 0 else 100.0

        return {
            "total_executions": total,
            "avg_duration_seconds": avg_dur,
            "error_count": errors,
            "success_rate": success_rate,
            "last_active": last_active,
            "tokens_used": None,
        }
    except sqlite3.Error:
        return empty
    finally:
        conn.close()


async def get_agent_metrics(request: web.Request) -> web.Response:
    """Return aggregated metrics for an agent over a time period."""
    name = request.match_info["name"]

    allowed = _get_allowed_agents(request)
    if allowed and name not in allowed:
        return _err(f"agent '{name}' not found", 404)

    period = request.query.get("period", "24h")
    now = datetime.now(timezone.utc)
    if period == "7d":
        since = now - timedelta(days=7)
    else:
        since = now - timedelta(hours=24)

    db_path = _get_traces_db_path()
    metrics = await asyncio.to_thread(
        _query_agent_metrics, db_path, name, since.isoformat(),
    )
    metrics["period"] = period
    return _ok(metrics)


def _query_agent_metrics_history(
    db_path: Path, agent_name: str, since_iso: str, group_format: str,
) -> list[dict[str, Any]]:
    """Query time-bucketed metrics history for charts."""
    if not db_path.is_file():
        return []

    try:
        conn = sqlite3.connect(str(db_path), timeout=5)
        conn.execute("PRAGMA journal_mode=WAL")
    except sqlite3.Error:
        return []

    try:
        rows = conn.execute(
            "SELECT strftime(?, started) AS bucket, "
            "COUNT(*) AS executions, "
            "SUM(CASE WHEN status != 'ok' THEN 1 ELSE 0 END) AS errors, "
            "ROUND(AVG(duration_sec), 2) AS avg_duration "
            "FROM traces WHERE agent_name = ? AND started >= ? "
            "GROUP BY bucket ORDER BY bucket",
            (group_format, agent_name, since_iso),
        ).fetchall()

        return [
            {
                "timestamp": r[0],
                "executions": r[1],
                "errors": r[2] or 0,
                "avg_duration": r[3] or 0.0,
            }
            for r in rows
        ]
    except sqlite3.Error:
        return []
    finally:
        conn.close()


async def get_agent_metrics_history(request: web.Request) -> web.Response:
    """Return time-bucketed metrics for chart rendering."""
    name = request.match_info["name"]

    allowed = _get_allowed_agents(request)
    if allowed and name not in allowed:
        return _err(f"agent '{name}' not found", 404)

    period = request.query.get("period", "24h")
    now = datetime.now(timezone.utc)
    if period == "7d":
        since = now - timedelta(days=7)
        group_format = "%Y-%m-%d"
    else:
        since = now - timedelta(hours=24)
        group_format = "%Y-%m-%dT%H:00"

    db_path = _get_traces_db_path()
    history = await asyncio.to_thread(
        _query_agent_metrics_history, db_path, name, since.isoformat(), group_format,
    )
    return _ok(history)


# ---------------------------------------------------------------------------
# Transcription
# ---------------------------------------------------------------------------

@require_role("operator")
async def transcribe_audio(request: web.Request) -> web.Response:
    """Transcribe an audio file using the configured whisper backend."""
    try:
        body = await request.json()
    except Exception:
        return _err("invalid JSON body", 400)

    file_path_str = body.get("path", "")
    if not file_path_str or not isinstance(file_path_str, str):
        return _err("missing 'path' field", 400)

    file_path = Path(file_path_str)

    # Security: only allow files under sygen home (api_files/, workspace/, etc.)
    sygen_home = _sygen_home()
    try:
        file_path.resolve().relative_to(sygen_home.resolve())
    except ValueError:
        return _err("path outside allowed directory", 403)

    if not file_path.is_file():
        return _err("file not found", 404)

    from sygen_bot.transcription import transcribe_file

    transcript = await transcribe_file(file_path, timeout=120)
    if transcript is None:
        return _err("transcription failed — no backend available or all strategies failed", 500)

    return _ok({"transcript": transcript})


# ---------------------------------------------------------------------------
# File Manager
# ---------------------------------------------------------------------------

# Directories/files that should never appear in file listings
_FM_HIDDEN_NAMES: set[str] = {
    "__pycache__", ".git", "node_modules", ".DS_Store",
    "sessions.json", "config.json", "agents.json",
    "CLAUDE.md", "GEMINI.md", "AGENTS.md",
    "MAINMEMORY.md", "SHAREDMEMORY.md", "TASK_DESCRIPTION.md",
    "AGENT_ACTIVITY.md",
}

_FM_HIDDEN_DIRS: set[str] = {
    "memory_system", "tools", "skills", "cron_tasks",
    # Defensive: the current file-manager scope is agents/workspace, so
    # "~/.sygen/_secrets" is already out of reach.  This guard protects
    # against a future widening of the root — e.g. exposing ~/.sygen — from
    # accidentally making the secrets directory traversable.
    "_secrets",
}

_FM_HIDDEN_SUFFIXES: set[str] = {".pyc", ".pid"}

# MIME type filter groups
_FM_TYPE_MAP: dict[str, set[str]] = {
    "image": {"image"},
    "video": {"video"},
    "audio": {"audio"},
    "document": {"application/pdf", "application/msword", "text",
                 "application/vnd.openxmlformats", "application/json",
                 "application/xml"},
    "archive": {"application/zip", "application/gzip", "application/x-tar",
                "application/x-rar", "application/x-7z-compressed",
                "application/x-bzip2"},
}


def _fm_guess_mime(path: Path) -> str:
    """Guess MIME type for a file."""
    import mimetypes
    mime, _ = mimetypes.guess_type(str(path))
    return mime or "application/octet-stream"


def _fm_is_hidden(entry: Path) -> bool:
    """Check if a filesystem entry should be hidden from listings."""
    name = entry.name
    if name in _FM_HIDDEN_NAMES:
        return True
    if name.startswith("."):
        return True
    if entry.is_dir() and name in _FM_HIDDEN_DIRS:
        return True
    if entry.is_file():
        suffix = entry.suffix.lower()
        if suffix in _FM_HIDDEN_SUFFIXES:
            return True
    return False


def _fm_matches_type(mime: str, type_filter: str) -> bool:
    """Check if a MIME type matches a type filter."""
    allowed = _FM_TYPE_MAP.get(type_filter)
    if not allowed:
        return True
    for prefix in allowed:
        if mime.startswith(prefix):
            return True
    return False


def _fm_resolve_workspace(agent: str) -> Path | None:
    """Resolve the workspace directory for an agent."""
    home = _sygen_home()
    if agent == "main":
        return home / "workspace"
    if not _AGENT_NAME_RE.match(agent):
        return None
    agent_ws = home / "agents" / agent / "workspace"
    if agent_ws.is_dir():
        return agent_ws
    return None


async def list_files(request: web.Request) -> web.Response:
    """List user-visible files in an agent's workspace."""
    agent = request.query.get("agent", "main")
    sub_path = request.query.get("path", "") or request.query.get("relative_path", "")
    type_filter = request.query.get("type", "")
    sort_by = request.query.get("sort", "name")

    if agent and not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    # Enforce per-agent access
    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    workspace = _fm_resolve_workspace(agent)
    if workspace is None or not workspace.is_dir():
        return _ok([])

    # Resolve sub-path within workspace
    if sub_path:
        # Block path traversal
        if ".." in sub_path or sub_path.startswith("/"):
            return _err("invalid path", 400)
        target = workspace / sub_path
    else:
        target = workspace

    # Validate resolved path is within workspace
    try:
        if not target.resolve().is_relative_to(workspace.resolve()):
            return _err("path outside workspace", 400)
    except (ValueError, OSError):
        return _err("invalid path", 400)

    if not target.is_dir():
        return _ok([])

    entries = []
    try:
        for entry in target.iterdir():
            if _fm_is_hidden(entry):
                continue

            try:
                stat = entry.stat()
            except OSError:
                continue

            is_dir = entry.is_dir()
            mime = "" if is_dir else _fm_guess_mime(entry)

            if type_filter and not is_dir and not _fm_matches_type(mime, type_filter):
                continue

            # Relative path from workspace root
            try:
                rel_path = str(entry.relative_to(workspace))
            except ValueError:
                rel_path = entry.name

            entries.append({
                "name": entry.name,
                "path": rel_path,
                "size": 0 if is_dir else stat.st_size,
                "mime": mime,
                "modified": stat.st_mtime,
                "isDir": is_dir,
            })
    except OSError:
        return _ok([])

    # Sort
    if sort_by == "size":
        entries.sort(key=lambda e: (not e["isDir"], -e["size"]))
    elif sort_by == "date":
        entries.sort(key=lambda e: (not e["isDir"], -e["modified"]))
    else:
        entries.sort(key=lambda e: (not e["isDir"], e["name"].lower()))

    return _ok(entries)


def _fm_rel_is_hidden(rel_path: str) -> bool:
    """Return True if any segment of a relative path is hidden.

    Applies _FM_HIDDEN_NAMES, _FM_HIDDEN_DIRS, dotfiles, and suffix rules as
    an ACL on writes (delete, mkdir), not just listings.
    """
    parts = [p for p in Path(rel_path).parts if p not in ("", ".")]
    if not parts:
        return True
    for p in parts:
        if p in _FM_HIDDEN_NAMES:
            return True
        if p in _FM_HIDDEN_DIRS:
            return True
        if p.startswith("."):
            return True
    last = parts[-1]
    suffix = Path(last).suffix.lower()
    if suffix in _FM_HIDDEN_SUFFIXES:
        return True
    return False


@require_role("admin")
async def delete_file(request: web.Request) -> web.Response:
    """Delete a file within an agent's workspace.

    Accepts two body shapes:
      - ``{agent, relative_path}`` — preferred, resolved via ``_fm_resolve_workspace``.
      - ``{path}`` — legacy absolute path under ``~/.sygen/``.
    """
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    agent = body.get("agent")
    rel_path = body.get("relative_path")

    home = _sygen_home()

    if isinstance(agent, str) and isinstance(rel_path, str):
        # New contract: {agent, relative_path}
        if not _AGENT_NAME_RE.match(agent):
            return _err("invalid agent name", 400)
        err = _check_agent_access(request, agent)
        if err is not None:
            return err
        workspace = _fm_resolve_workspace(agent)
        if workspace is None:
            return _err(f"workspace for agent '{agent}' not found", 404)
        if not rel_path or ".." in rel_path or rel_path.startswith("/"):
            return _err("invalid path", 400)
        if _fm_rel_is_hidden(rel_path):
            return _err("path is not accessible", 403)
        target = workspace / rel_path
        try:
            resolved = target.resolve()
            if not resolved.is_relative_to(workspace.resolve()):
                return _err("path outside workspace", 403)
        except (ValueError, OSError):
            return _err("invalid path", 400)
        file_path = target
        audit_target = f"{agent}:{rel_path}"
    else:
        # Legacy contract: {path}
        file_path_str = body.get("path", "")
        if not file_path_str or not isinstance(file_path_str, str):
            return _err("missing 'path' field")

        file_path = Path(file_path_str)

        try:
            resolved = file_path.resolve()
            if not resolved.is_relative_to(home.resolve()):
                return _err("path outside allowed directory", 403)
        except (ValueError, OSError):
            return _err("invalid path", 400)

        try:
            legacy_rel = str(resolved.relative_to(home.resolve()))
        except ValueError:
            legacy_rel = resolved.name
        if _fm_rel_is_hidden(legacy_rel):
            return _err("path is not accessible", 403)
        audit_target = file_path_str

    if not file_path.exists():
        return _err("file not found", 404)

    if file_path.is_dir():
        import shutil
        shutil.rmtree(file_path)
    else:
        file_path.unlink()

    actor = request.get("jwt_user", {}).get("sub", "unknown")
    write_audit(user=actor, action="file_deleted", target=audit_target)

    return _ok({"deleted": audit_target})


async def sign_file_url_handler(request: web.Request) -> web.Response:
    """``POST /api/files/sign-url`` — short-lived signed URL for a file.

    Body: ``{"agent": "...", "relative_path": "...", "ttl": 60}``.
    Response: ``{"url": "/api/files/download?..."}`` with a 60-second default TTL.

    Signatures are HMAC-SHA256 over ``{agent}|{relative_path}|{exp}`` keyed
    on the server's JWT secret. Serves as a cheap way for ``<img src>`` tags
    to fetch many thumbnails without spamming per-request Authorization flows.
    """
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    agent = body.get("agent", "")
    rel_path = body.get("relative_path", "")
    ttl_raw = body.get("ttl", 60)

    if not isinstance(agent, str) or not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)
    if not isinstance(rel_path, str) or not rel_path:
        return _err("invalid relative_path", 400)
    if ".." in rel_path or rel_path.startswith("/"):
        return _err("invalid relative_path", 400)

    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    try:
        ttl = int(ttl_raw)
    except (TypeError, ValueError):
        ttl = 60
    ttl = max(1, min(ttl, 300))  # cap at 5 minutes

    secret = request.app.get("jwt_secret") or _load_or_create_secret("")
    params = sign_file_url(secret, agent=agent, relative_path=rel_path, ttl=ttl)
    qs = urlencode(params, doseq=False)
    return _ok({"url": f"/api/files/download?{qs}", "exp": params["exp"]})


@require_role("admin")
async def mkdir_files(request: web.Request) -> web.Response:
    """Create a directory inside an agent's workspace.

    Body accepts ``{agent, name}`` (new folder at workspace root) or
    ``{agent, relative_path}`` (new folder at an arbitrary depth).
    """
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    agent = body.get("agent", "main")
    name = body.get("name", "")
    rel_path = body.get("relative_path", "")

    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    err = _check_agent_access(request, agent)
    if err is not None:
        return err

    workspace = _fm_resolve_workspace(agent)
    if workspace is None:
        return _err(f"workspace for agent '{agent}' not found", 404)

    if isinstance(rel_path, str) and rel_path:
        if ".." in rel_path or rel_path.startswith("/"):
            return _err("invalid path", 400)
        if _fm_rel_is_hidden(rel_path):
            return _err("path is not accessible", 403)
        new_dir = workspace / rel_path
        display_name = rel_path
    else:
        if not name or not isinstance(name, str):
            return _err("missing 'name' field")
        if ".." in name or "/" in name or "\\" in name:
            return _err("invalid folder name", 400)
        if _fm_rel_is_hidden(name):
            return _err("path is not accessible", 403)
        new_dir = workspace / name
        display_name = name

    try:
        if not new_dir.resolve().is_relative_to(workspace.resolve()):
            return _err("path outside workspace", 403)
    except (ValueError, OSError):
        return _err("invalid path", 400)

    if new_dir.exists():
        return _err(f"'{display_name}' already exists", 409)

    new_dir.mkdir(parents=True, exist_ok=False)

    actor = request.get("jwt_user", {}).get("sub", "unknown")
    write_audit(user=actor, action="dir_created", target=str(new_dir))

    return _ok({"created": display_name, "agent": agent})


# ---------------------------------------------------------------------------
# Route registration
# ---------------------------------------------------------------------------

def setup_rest_routes(app: web.Application) -> None:
    """Register all REST API routes on the given aiohttp app.

    Auth is handled by the JWTAuth middleware already on the app.
    """
    # Agents
    app.router.add_get("/api/agents", get_agents)
    app.router.add_get("/api/agents/{name}/avatar", get_agent_avatar)
    app.router.add_post("/api/agents/{name}/avatar", upload_agent_avatar)
    app.router.add_delete("/api/agents/{name}/avatar", delete_agent_avatar)
    app.router.add_get("/api/agents/{name}/metrics", get_agent_metrics)
    app.router.add_get("/api/agents/{name}/metrics/history", get_agent_metrics_history)
    app.router.add_get("/api/agents/{name}", get_agent)

    # Cron
    app.router.add_get("/api/cron", get_cron_jobs)
    app.router.add_post("/api/cron", create_cron_job)
    app.router.add_put("/api/cron/{id}", update_cron_job)
    app.router.add_delete("/api/cron/{id}", delete_cron_job)
    app.router.add_post("/api/cron/{id}/run", run_cron_job)

    # Webhooks
    app.router.add_get("/api/webhooks", get_webhooks)
    app.router.add_post("/api/webhooks", create_webhook)
    app.router.add_put("/api/webhooks/{id}", update_webhook)
    app.router.add_delete("/api/webhooks/{id}", delete_webhook)
    app.router.add_post("/api/webhooks/{id}/verify", verify_webhook_signature)

    # Tasks
    app.router.add_get("/api/tasks", get_tasks)
    app.router.add_get("/api/tasks/{id}", get_task)
    app.router.add_post("/api/tasks", create_task)
    app.router.add_post("/api/tasks/{id}/cancel", cancel_task)

    # Review (ultra_review skill trigger)
    app.router.add_post("/api/review", create_review)

    # Sessions
    app.router.add_get("/api/sessions", get_sessions)
    app.router.add_delete("/api/sessions/{id}", delete_session)

    # Memory
    app.router.add_get("/api/memory", get_memory)
    app.router.add_put("/api/memory", update_memory)
    app.router.add_get("/api/memory/modules", get_memory_modules)
    app.router.add_get("/api/memory/modules/{filename:.+}", get_memory_module)
    app.router.add_put("/api/memory/modules/{filename:.+}", update_memory_module)

    # Skills (global, shared across agents)
    app.router.add_get("/api/skills", list_global_skills)
    app.router.add_post("/api/skills", create_global_skill)
    app.router.add_get("/api/skills/{skill}", get_global_skill)
    app.router.add_put("/api/skills/{skill}", update_global_skill)
    app.router.add_delete("/api/skills/{skill}", delete_global_skill)

    # Skills (per-agent)
    app.router.add_get("/api/agents/{agent}/skills", list_agent_skills)
    app.router.add_post("/api/agents/{agent}/skills", create_agent_skill)
    app.router.add_get("/api/agents/{agent}/skills/{skill}", get_agent_skill)
    app.router.add_put("/api/agents/{agent}/skills/{skill}", update_agent_skill)
    app.router.add_delete("/api/agents/{agent}/skills/{skill}", delete_agent_skill)

    # RAG
    app.router.add_get("/api/rag/status", get_rag_status)
    app.router.add_put("/api/rag/config", update_rag_config)

    # System
    app.router.add_get("/api/system/status", get_system_status)
    app.router.add_put("/api/system/instance-name", update_instance_name)
    app.router.add_get("/api/config", get_config)
    app.router.add_get("/api/logs", get_logs)

    # Users (RBAC)
    app.router.add_get("/api/users", get_users)
    app.router.add_post("/api/users", create_user)
    app.router.add_put("/api/users/{username}", update_user)
    app.router.add_delete("/api/users/{username}", delete_user)

    # Chat sessions
    app.router.add_get("/api/chat/sessions", get_chat_sessions)
    app.router.add_post("/api/chat/sessions", create_chat_session)
    app.router.add_put("/api/chat/sessions/{id}", update_chat_session)
    app.router.add_delete("/api/chat/sessions/{id}", delete_chat_session)
    app.router.add_post("/api/chat/sessions/{id}/provider", set_session_provider)
    app.router.add_get("/api/chat/sessions/{id}/messages", get_chat_messages)
    app.router.add_put("/api/chat/sessions/{id}/messages", save_chat_message)

    # Providers
    app.router.add_get("/api/providers/available", get_available_providers)

    # Audit log
    app.router.add_get("/api/audit", get_audit_log)

    # Activity feed (unified)
    app.router.add_get("/api/activity", get_activity)

    # Export / Import
    app.router.add_get("/api/export", export_config)
    app.router.add_post("/api/import", import_config)

    # Commands (slash menu)
    app.router.add_get("/api/commands", get_commands)

    # Transcription
    app.router.add_post("/api/transcribe", transcribe_audio)

    # Notifications
    app.router.add_get("/api/notifications", get_notifications_handler)
    app.router.add_get("/api/notifications/unread-count", get_unread_count_handler)
    app.router.add_put("/api/notifications/{id}/read", mark_read_handler)
    app.router.add_post("/api/notifications/read-all", mark_all_read_handler)

    # Live log polling
    app.router.add_get("/api/logs/poll", get_logs_poll)

    # File manager
    app.router.add_get("/api/files/list", list_files)
    app.router.add_delete("/api/files", delete_file)
    app.router.add_post("/api/files/mkdir", mkdir_files)
    app.router.add_post("/api/files/sign-url", sign_file_url_handler)
