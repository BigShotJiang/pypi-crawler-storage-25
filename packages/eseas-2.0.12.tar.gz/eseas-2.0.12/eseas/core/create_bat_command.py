# This file is part of the eseas project
# Copyright (C) 2024 Sermet Pekin
#
# This source code is free software; you can redistribute it and/or
# modify it under the terms of the European Union Public License
# (EUPL), Version 1.2, as published by the European Commission.
#
# You should have received a copy of the EUPL version 1.2 along with this
# program. If not, you can obtain it at:
# <https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12>.
#
# This source code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# European Union Public License for more details.
#
# Alternatively, if agreed upon, you may use this code under any later
# version of the EUPL published by the European Commission.

import subprocess
from pathlib import Path
import shutil
from typing import Iterable
import logging

logger = logging.getLogger(__name__)

class CruncherExecutionError(Exception):
    """Raised when Jwsacruncher fails to execute correctly"""
    pass

from evdspy.EVDSlocal.common.file_classes import FileItem
from ._options import middle_folder
from .utils_general2 import get_os

if __name__ != "__main__":
    from ._general_params import _create_general_params
    from .cruncher_classes import get_cruncher
    from .demetra_caller import (
        DemetraCallerLinux,
        DemetraCallerMac,
        DemetraCallerWindows,
    )

NEW_LINE = chr(10)


os_str = get_os()


def get_demetra_type():
    if get_os() == "windows":
        return DemetraCallerWindows()
    if get_os() == "linux":
        return DemetraCallerLinux()
    if get_os() == "darwin":
        return DemetraCallerMac()
    # from .seasonal_adv_utils import this_is_pytest
    raise NotImplementedError("Computer OS not found.")


def general_params():
    from .seasonal_options import SingleOptions

    opts = SingleOptions().options
    if getattr(opts, "general_params_path", None):
        return str(opts.general_params_path)
    return str(Path.cwd() / "general.params")


def create_general_params():
    from .seasonal_options import SingleOptions

    opts = SingleOptions().options

    if getattr(opts, "general_params_path", None):
        full_path = Path(opts.general_params_path)
        folder = str(full_path.parent)
        file_name = full_path.name
    else:
        folder = str(Path.cwd())
        file_name = "general.params"

    replace = False
    auto_approve = False
    csvlayout = "list"
    if opts is not None:
        replace = getattr(opts, "replace_general_params", False)
        auto_approve = getattr(opts, "auto_approve", False)
        csvlayout = getattr(opts, "csvlayout", "list")

    return _create_general_params(
        folder,
        file_name,
        replace=replace,
        auto_approve=auto_approve,
        csvlayout=csvlayout,
    )


def copy_folder_demetra(files: Iterable[FileItem]):
    """
    this will copy demetra files from source
    directory to workspace
    :param files:
    :return:
    """

    def copy_all_files(file_item: FileItem):
        src = str(file_item.full_name).split(".xml")[0]
        trg = Path() / get_cruncher().local_work_space / file_item.encoded_name
        try:
            shutil.copytree(
                src,
                trg,
                symlinks=False,
                ignore=None,
                copy_function=shutil.copy2,
                ignore_dangling_symlinks=False,
                dirs_exist_ok=True,
            )
        except Exception as exc:
            print(exc)

    return list(map(copy_all_files, files))


def copy_xml_files_local(files: list[FileItem]):
    def copy_xml_file(file_item: FileItem):
        shutil.copy(
            file_item.full_name,
            Path(get_cruncher().local_work_space)
            / str(file_item.encoded_name + ".xml"),
        )

    return list(map(copy_xml_file, files))

def demetra_command_general(file_item: FileItem):
    fname = str(file_item.encoded_name + ".xml")
    ws = Path(get_cruncher().local_work_space)
    dest = ws / fname
    cmd1 = rf'{get_demetra_type().cruncher_command()} "{dest}"'
    cmd2 = rf'-x "{general_params()}"'
    d_path = ws / middle_folder / file_item.encoded_name
    cmd3 = rf'-d "{d_path}"'
    command = f"{cmd1} {cmd2} {cmd3}"
    return command

def get_line_win(file_item: FileItem):
    fname = str(file_item.encoded_name + ".xml")
    ws = Path(get_cruncher().local_work_space)
    dest = ws / fname
    line_info = f"rem {file_item.short_name}\nrem " + "-" * 50 + "\n"
    cmd1 = rf'call {line_info}{get_demetra_type().cruncher_command()} "{dest}"'
    cmd2 = rf'-x "{general_params()}"'
    d_path = ws / middle_folder / file_item.encoded_name
    cmd3 = rf'-d "{d_path}"{NEW_LINE}'
    command = f"{cmd1} {cmd2} {cmd3}"
    return command

def get_line_MAC(file_item: FileItem):
    ws = Path(get_cruncher().local_work_space)
    dest = ws / str(file_item.encoded_name + ".xml")
    line_info = f"# {file_item.short_name}\n# " + "-" * 50 + "\n"
    cmd1 = f'{line_info}\n{get_demetra_type().cruncher_command()} "{dest}"'
    cmd2 = f'-x "{general_params()}"'
    d_path = ws / middle_folder / file_item.encoded_name
    cmd3 = f'-d "{d_path}"{NEW_LINE}'
    command = f"{cmd1} {cmd2} {cmd3}"
    # print(command)
    return command


def create_command(files):
    return map(get_line, files)

def create_command_clean(files):
    return map(demetra_command_general, files)

def patch_template_for_os(template):
    if get_os() != "windows":
        template = "\n".join(tuple(f"#{x}" for x in template.splitlines()))
    return template


def begin_content_win():
    from datetime import date

    today = date.today()
    template = f"""@chcp 65001>nul
rem ==============================================================
rem         evdspy
rem         @2022 evdspy ==> JDemetra caller
rem         searched space  : {get_cruncher().demetra_folder}
rem         date created : {today}
rem ==============================================================
echo on
"""
    return patch_template_for_os(template)


def begin_content_MAC():
    # from datetime import date
    # today = date.today()
    template = """#!/bin/bash
echo "Starting the script..."
"""
    return template


def end_content_win() -> str:
    template = """
rem pause
    """
    return template


def end_content_MAC() -> str:
    return "\n"


if os_str != "windows":
    get_line = get_line_MAC
    begin_content = begin_content_MAC
    end_content = end_content_MAC
else:
    get_line = get_line_win
    begin_content = begin_content_win
    end_content = end_content_win


def write_bat_file(content, file_name):
    content = begin_content() + content + end_content()
    logger.debug(f"WRITING content to {file_name}: {content}")
    fname = get_demetra_type().exec_file_name(file_name)
    with open(fname, mode="w+", encoding="utf-8") as file_:
        file_.write(content)


def _handle_execution(result: subprocess.CompletedProcess):
    if result.returncode != 0:
        logger.error(f"Jwsacruncher execution failed with return code {result.returncode}")
        if result.stderr:
            logger.error(f"stderr: {result.stderr}")
        raise CruncherExecutionError(f"JDemetra+ run failed: {result.stderr or result.stdout}")
    logger.info("Jwsacruncher executed successfully.")
    logger.debug(result.stdout)


def run_bat_commands_from_file():
    import os

    create_general_params()
    script_path = get_demetra_type().demetra_command_file_name()
    if os_str != "windows":
        os.chmod(script_path, 0o755)
    result = subprocess.run([script_path], capture_output=True, text=True , encoding='utf-8')
    _handle_execution(result)
    

def get_commands_from_file(script_path:str |Path ):
    raise NotImplementedError() 
    content = None 
    if not Path(script_path).exists() :
        raise FileExistsError(f" file : {script_path}")
    
    with open(script_path, encoding="utf-8") as file:
        content =  file.read()
    if content is None :
        raise ValueError(f"could not read [{script_path}]")
    def should_escape(string :str ):
        string = string.strip()
        comment_char = "rem" if os_str == "windows" else "#"
        if len(string)== 0  :  return True 
        if string.lower().startswith(comment_char ) : return True 
        return False 
    commands = []
    for line in content.splitlines():
        if should_escape(line) :
            continue 
        commands.append(line)        
    return commands 

def run_bat_commands_direct(commands):
    from eseas.core._subprocess import Subprocess
    create_general_params()
    s = Subprocess( commands , convert=False)   
    s.run(verbose = True )
