"""
Config loading for lao.

Priority order (highest wins):
1. Project config: <repo>/.lao/config.yaml
2. User global config: ~/.lao/config.yaml
3. Pydantic defaults in ProjectConfig

Deep-merges dicts so users can override just one field without
specifying the entire section.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import ValidationError

from lao.constants import CONFIG_FILE, LAO_DIR
from lao.exceptions import ConfigError, ConfigNotFoundError
from lao.models import ProjectConfig

logger = logging.getLogger(__name__)


def find_project_root(start: Optional[Path] = None) -> Path:
    """
    Walk upward from start, looking for .lao/ or .git/.

    Resolution order:
    1. If start is explicitly provided AND exists as a directory → use it directly.
       This prevents walking up into a parent repo when the user passes --repo.
    2. Directory with .lao/ → lao project root
    3. Directory with .git/ → treat as project root
    4. If neither found, return start (or cwd if start is None)

    Edge cases:
    - start doesn't exist → raises ConfigNotFoundError
    - Filesystem root reached without finding markers → return start
    - .lao/ is a file not a dir → skip it, keep searching
    """
    begin = (start or Path.cwd()).resolve()

    if not begin.exists():
        raise ConfigNotFoundError(str(begin))

    # If start is a file, begin from its parent
    current = begin if begin.is_dir() else begin.parent

    # If an explicit path was given (not just cwd fallback), use it directly
    # as long as it looks like a valid project dir (has package.json, pyproject.toml,
    # go.mod, Cargo.toml, or .lao/) — prevents walking up into parent git repos.
    if start is not None:
        project_markers = {
            "package.json", "pyproject.toml", "go.mod", "Cargo.toml",
            "setup.py", "setup.cfg", ".lao",
        }
        if any((current / m).exists() for m in project_markers):
            logger.debug(f"Explicit repo path given with project markers: {current}")
            return current

    for candidate in [current, *current.parents]:
        lao_dir = candidate / LAO_DIR
        git_dir = candidate / ".git"

        if lao_dir.exists() and lao_dir.is_dir():
            return candidate
        if git_dir.exists():
            return candidate

    # No marker found: use the start directory
    logger.debug(f"No .lao/ or .git/ found above {begin}. Using {begin}.")
    return current


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """
    Recursively merge override into base.

    - Dict values are merged recursively
    - List values are replaced (not appended)
    - Scalar values from override win

    Returns a new dict; neither input is modified.
    """
    result = base.copy()
    for key, value in override.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, dict)
        ):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _load_yaml_file(path: Path) -> dict[str, Any]:
    """
    Load a YAML file and return its content as a dict.

    Returns empty dict if file doesn't exist.
    Raises ConfigError with line info on YAML parse failure.
    """
    if not path.exists():
        return {}

    try:
        with open(path, encoding="utf-8") as f:
            content = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ConfigError(
            f"Invalid YAML in {path}: {e}\n"
            "Tip: Validate your config at https://yaml-online-parser.appspot.com/"
        ) from e
    except OSError as e:
        raise ConfigError(f"Cannot read config file {path}: {e}") from e

    if content is None:
        return {}  # Empty file is valid, treat as no overrides
    if not isinstance(content, dict):
        raise ConfigError(
            f"Config file {path} must contain a YAML mapping (dict), "
            f"got {type(content).__name__}"
        )
    return content


def load_config(repo_path: Optional[Path] = None) -> ProjectConfig:
    """
    Load and validate the full project config.

    Args:
        repo_path: Explicit repo path. If None, auto-detected.

    Returns:
        Validated ProjectConfig instance.

    Raises:
        ConfigError: YAML parse failure or Pydantic validation failure.
        ConfigNotFoundError: No project root found.
    """
    root = find_project_root(repo_path)

    # Load in priority order: user global (base), project (override)
    user_config_path = Path.home() / LAO_DIR / CONFIG_FILE
    project_config_path = root / LAO_DIR / CONFIG_FILE

    raw: dict[str, Any] = {}

    user_raw = _load_yaml_file(user_config_path)
    if user_raw:
        logger.debug(f"Loaded user config from {user_config_path}")
        raw = _deep_merge(raw, user_raw)

    project_raw = _load_yaml_file(project_config_path)
    if project_raw:
        logger.debug(f"Loaded project config from {project_config_path}")
        raw = _deep_merge(raw, project_raw)

    # Always set root to the detected project root
    raw["root"] = str(root)

    try:
        return ProjectConfig(**raw)
    except ValidationError as e:
        # Extract field names for a concise error message
        bad_fields = [".".join(str(loc) for loc in err["loc"]) for err in e.errors()]
        raise ConfigError(
            f"Config validation failed on field(s): {', '.join(bad_fields)}.\n"
            f"Run 'lao config validate' for details.\n"
            f"Full error:\n{e}"
        ) from e


def init_project(repo_path: Path) -> tuple[Path, bool]:
    """
    Initialize a lao project in repo_path.

    Creates:
    - <repo_path>/.lao/
    - <repo_path>/.lao/config.yaml  (only if it doesn't exist)
    - <repo_path>/.lao/runs/

    Returns:
        (config_path, created) where created=False if config already existed.

    Raises:
        ConfigError: Cannot create directories or write config.
    """
    from lao.utils.fs import ensure_lao_dir

    lao_dir = ensure_lao_dir(repo_path)
    config_path = lao_dir / CONFIG_FILE

    if config_path.exists():
        logger.debug(f"Config already exists at {config_path}")
        return config_path, False

    # Build a clean default config and serialize it
    default = ProjectConfig(root=repo_path)
    config_data = default.model_dump(mode="json", exclude={"root"})

    # Write as YAML with helpful comments
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            f.write("# lao configuration\n")
            f.write("# See docs/config-reference.md for all options\n\n")
            yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)
    except OSError as e:
        raise ConfigError(f"Cannot write config to {config_path}: {e}") from e

    return config_path, True