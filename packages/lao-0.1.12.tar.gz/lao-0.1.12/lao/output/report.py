"""
Run report writer.

Writes .lao/runs/<run_id>/report.json with full run statistics.
This file is machine-readable and used for:
- `lao stats` command
- Future dashboard/telemetry
- Debugging failed runs
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from lao.models import ContextPack, RunReport
from lao.utils.fs import safe_write_text

logger = logging.getLogger(__name__)


def write_report(
    report: RunReport,
    pack: ContextPack,
    output_dir: Path,
) -> Path:
    """
    Write report.json to output_dir.
    Returns the path of the written file.
    """
    # Populate fields from pack
    report.repo_files_scanned = pack.repo_profile.total_files_scanned
    report.files_selected = len(pack.selected_files)
    report.raw_token_estimate = pack.raw_token_estimate
    report.optimized_token_estimate = pack.optimized_token_estimate
    report.secrets_redacted = len(pack.security_report.secrets_found)
    report.files_blocked = len(pack.security_report.files_blocked)

    # Compute risk level
    report.risk_level = _compute_risk(pack)

    # Serialize to JSON (Pydantic handles datetime → ISO string)
    data = report.model_dump(mode="json")

    output_path = output_dir / "report.json"
    safe_write_text(output_path, json.dumps(data, indent=2, default=str))
    logger.debug(f"Wrote report to {output_path}")
    return output_path


def _compute_risk(pack: ContextPack) -> str:
    """
    Compute a simple risk level based on security findings and file types.

    low:    No secrets, no sensitive paths
    medium: Sensitive paths included with warning
    high:   Secrets found or blocked files suggest attempted leak
    """
    sr = pack.security_report

    if sr.secrets_found:
        return "high"
    if sr.files_blocked:
        return "medium"
    if sr.files_warned:
        return "medium"
    return "low"
