"""
Terminal display using Rich.

All user-visible output goes through here – no print() in business logic.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.text import Text
from rich.rule import Rule

from lao.models import ContextPack, RunReport
from lao.utils.tokens import format_token_count

console = Console()
err_console = Console(stderr=True)


def print_prep_result(
    pack: ContextPack,
    report: RunReport,
    pack_path: Path,
    report_path: Path,
) -> None:
    """Print the full prep result to terminal."""
    console.print()
    console.print(Rule("[bold green]LAO Preflight Complete[/bold green]"))
    console.print()

    # Task
    console.print(f"[bold]Task:[/bold] {pack.task}")
    console.print()

    # Local work summary
    _print_local_work(pack, report)
    console.print()

    # Context stats
    _print_context_stats(pack, report)
    console.print()

    # Security
    _print_security(pack)
    console.print()

    # Uncertainty
    if pack.uncertainty_notes:
        _print_uncertainty(pack)
        console.print()

    # Recommendation
    _print_recommendation(pack, report)
    console.print()

    # Output files
    console.print("[dim]Output files:[/dim]")
    console.print(f"  [cyan]{pack_path}[/cyan]")
    console.print(f"  [cyan]{report_path}[/cyan]")
    console.print()

    # Copy hint
    console.print(
        "[dim]Copy to clipboard:[/dim] "
        f"[yellow]cat {pack_path} | pbcopy[/yellow]  "
        "[dim](macOS)[/dim]"
    )
    console.print()


def _print_local_work(pack: ContextPack, report: RunReport) -> None:
    console.print("[bold]Local work:[/bold]")

    p = pack.repo_profile
    console.print(f"  ✓ Scanned [cyan]{p.total_files_scanned:,}[/cyan] files")

    if p.framework:
        console.print(f"  ✓ Detected [cyan]{p.framework}[/cyan] + [cyan]{p.primary_language or 'unknown'}[/cyan]")

    # Show .ai/ usage if available
    from lao.scanner.ai_context import load_ai_context
    try:
        ai_ctx = load_ai_context(p.root)
        if ai_ctx.available:
            console.print(f"  ✓ [cyan].ai/[/cyan] context: {', '.join(ai_ctx.used_files)}")
    except Exception:
        pass

    if p.test_runner:
        console.print(f"  ✓ Test runner: [cyan]{p.test_runner}[/cyan]")

    console.print(f"  ✓ Selected [cyan]{len(pack.selected_files)}[/cyan] relevant files")

    sr = pack.security_report
    if sr.secrets_found:
        console.print(f"  ✓ Redacted [yellow]{len(sr.secrets_found)}[/yellow] secret(s)")
    if sr.files_blocked:
        console.print(f"  ✓ Blocked [yellow]{len(sr.files_blocked)}[/yellow] sensitive file(s)")
    else:
        console.print(f"  ✓ No secrets detected")

    if pack.uncertainty_notes:
        note_count = len(pack.uncertainty_notes)
        console.print(f"  ⚠ [yellow]{note_count}[/yellow] uncertainty note(s)")


def _print_context_stats(pack: ContextPack, report: RunReport) -> None:
    raw = format_token_count(pack.raw_token_estimate)
    opt = format_token_count(pack.optimized_token_estimate)
    pct = report.savings_pct

    # Get repo total tokens from index if available
    repo_total_tokens = 0
    try:
        from lao.core.index import LaoIndex
        idx = LaoIndex(pack.repo_profile.root)
        if idx.exists():
            s = idx.stats()
            repo_total_tokens = s.get("total_tokens_indexed", 0)
    except Exception:
        pass

    total_files = pack.repo_profile.total_files_scanned
    selected_files = len(pack.selected_files)

    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    table.add_column("Metric", style="dim")
    table.add_column("Value")

    # Files filtered
    if total_files > 0:
        pct_filtered = ((total_files - selected_files) / total_files) * 100
        table.add_row(
            "Files sent",
            f"[bold cyan]{selected_files}[/bold cyan] of {total_files:,} "
            f"[dim]({pct_filtered:.0f}% filtered)[/dim]"
        )

    # Token savings — use repo total if available, else raw estimate
    if repo_total_tokens > 0:
        token_savings_pct = ((repo_total_tokens - pack.optimized_token_estimate) / repo_total_tokens) * 100
        table.add_row(
            "Tokens sent",
            f"[bold cyan]{opt}[/bold cyan] of ~{format_token_count(repo_total_tokens)} repo "
            f"[dim]({token_savings_pct:.0f}% filtered)[/dim]"
        )
    else:
        table.add_row("Tokens sent", f"[bold cyan]{opt}[/bold cyan]")
        if pct > 0:
            if pct >= 70:
                savings_str = f"[bold green]{pct:.0f}%[/bold green] compressed"
            else:
                savings_str = f"[dim]{pct:.0f}%[/dim] compressed"
            table.add_row("Compression", savings_str)

    if pack.compression_level > 0:
        table.add_row(
            "Compression",
            f"[yellow]Level {pack.compression_level.value} ({pack.compression_level.name})[/yellow]"
        )

    console.print("[bold]Context:[/bold]")
    console.print(table)


def _print_security(pack: ContextPack) -> None:
    sr = pack.security_report
    console.print("[bold]Security:[/bold]")
    console.print(f"  Scanner: [dim]{sr.scanner_used}[/dim]")

    if sr.clean:
        console.print("  ✓ [green]No secrets detected[/green]")
    else:
        console.print(
            f"  [red]⛔ {len(sr.secrets_found)} secret(s) detected and redacted[/red]"
        )

    if sr.files_warned:
        console.print(
            f"  [yellow]⚠ {len(sr.files_warned)} sensitive file(s) included[/yellow]"
        )
        for f in sr.files_warned[:3]:
            console.print(f"    [dim]{f}[/dim]")


def _print_uncertainty(pack: ContextPack) -> None:
    console.print("[bold]Uncertainty:[/bold]")
    for note in pack.uncertainty_notes[:5]:
        icon = "⚠" if note.note_type != "tool_fallback" else "ℹ"
        console.print(f"  {icon} [yellow]{note.message[:120]}[/yellow]")
    if len(pack.uncertainty_notes) > 5:
        console.print(f"  [dim]... and {len(pack.uncertainty_notes) - 5} more (see context-pack.md)[/dim]")


def _print_recommendation(pack: ContextPack, report: RunReport) -> None:
    from lao.constants import MODEL_RECOMMENDATIONS

    console.print("[bold]Recommendation:[/bold]")

    c = pack.task_classification
    model = report.recommended_model or MODEL_RECOMMENDATIONS.get(
        c.difficulty.value, "claude-sonnet"
    )
    console.print(f"  → Send to: [bold cyan]{model}[/bold cyan]")

    if report.risk_level == "high":
        console.print("  [red]⛔ HIGH RISK: Review security findings before sending[/red]")
    elif report.risk_level == "medium":
        console.print("  [yellow]⚠ MEDIUM RISK: Sensitive code included – review before sharing[/yellow]")


def print_error(message: str, hint: Optional[str] = None) -> None:
    """Print a formatted error message."""
    err_console.print(f"[bold red]Error:[/bold red] {message}")
    if hint:
        err_console.print(f"[dim]Hint: {hint}[/dim]")


def print_warning(message: str) -> None:
    """Print a formatted warning."""
    console.print(f"[yellow]Warning:[/yellow] {message}")


def print_info(message: str) -> None:
    """Print a formatted info message."""
    console.print(f"[dim]{message}[/dim]")


def print_success(message: str) -> None:
    """Print a formatted success message."""
    console.print(f"[green]✓[/green] {message}")