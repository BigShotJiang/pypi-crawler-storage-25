"""
Compact output renderer.

Produces a token-efficient agent briefing for Codex, Claude API, or
any agent that receives context via stdin/prompt.

Design goals:
- Maximum information density
- No markdown headers or decorative elements
- No repetition
- Structured but human-readable
- Target: ~30% fewer tokens than full Markdown pack
"""

from __future__ import annotations

from lao.models import CompressionLevel, ContextPack, RunReport
from lao.utils.tokens import format_token_count

LANG_FENCE: dict[str, str] = {
    "typescript": "ts", "javascript": "js", "python": "py",
    "rust": "rs", "go": "go", "java": "java", "css": "css",
    "yaml": "yaml", "json": "json", "bash": "sh", "markdown": "md",
}


def render_compact(pack: ContextPack, report: RunReport) -> str:
    """Render a compact agent briefing."""
    lines: list[str] = []

    # ── Header ────────────────────────────────────────────────────────────
    c = pack.task_classification
    p = pack.repo_profile
    lines.append(f"TASK: {pack.task}")
    lines.append(
        f"TYPE:{c.task_type.value} DIFFICULTY:{c.difficulty.value} "
        f"CONFIDENCE:{c.confidence:.0%}"
    )
    lines.append(
        f"REPO:{p.framework or 'unknown'}/{p.primary_language or 'unknown'} "
        f"FILES:{p.total_files_scanned} SELECTED:{len(pack.selected_files)}"
    )
    # Show file filtering instead of "0% saved" for small repos
    total_files = pack.repo_profile.total_files_scanned if pack.repo_profile else 0
    selected_files = len(pack.selected_files)
    if total_files > selected_files and total_files > 0:
        pct_filtered = int(((total_files - selected_files) / total_files) * 100)
        lines.append(
            f"TOKENS:{format_token_count(pack.optimized_token_estimate)} "
            f"(raw:{format_token_count(pack.raw_token_estimate)} "
            f"files:{selected_files}/{total_files} filtered:{pct_filtered}%)"
        )
    else:
        lines.append(
            f"TOKENS:{format_token_count(pack.optimized_token_estimate)} "
            f"(raw:{format_token_count(pack.raw_token_estimate)} "
            f"saved:{report.savings_pct:.0f}%)"
        )

    # ── Security ──────────────────────────────────────────────────────────
    sr = pack.security_report
    if not sr.clean:
        lines.append(f"SECURITY:REDACTED secrets={len(sr.secrets_found)} blocked={len(sr.files_blocked)}")
    if sr.files_blocked:
        lines.append(f"BLOCKED:{','.join(sr.files_blocked[:3])}")

    # ── Uncertainty ───────────────────────────────────────────────────────
    if pack.uncertainty_notes:
        critical = [n for n in pack.uncertainty_notes if n.note_type not in ("tool_fallback",)]
        if critical:
            lines.append(f"UNCERTAIN:{len(critical)} notes — see below")

    lines.append("")

    # ── Evidence ──────────────────────────────────────────────────────────
    lines.append("=== EVIDENCE ===")

    chunks_by_file: dict[str, list] = {}
    for chunk in pack.chunks:
        chunks_by_file.setdefault(chunk.file_path, []).append(chunk)

    for sf in pack.selected_files:
        rel = sf.file.relative_path
        chunks = chunks_by_file.get(rel, [])
        if not chunks:
            continue

        lang = sf.file.language or "text"
        fence = LANG_FENCE.get(lang, lang)

        # Compact score summary
        score_parts = []
        for k, v in sf.score_breakdown.items():
            if v > 0:
                score_parts.append(f"{k[0]}:{v:.0f}")
        score_str = " ".join(score_parts[:4])

        lines.append(f"--- {rel} [{score_str}] ---")
        for chunk in chunks:
            lines.append(f"# L{chunk.start_line}-{chunk.end_line}")
            lines.append(f"```{fence}")
            lines.append(chunk.content)
            lines.append("```")

    # ── Uncertainty detail ────────────────────────────────────────────────
    critical_notes = [n for n in pack.uncertainty_notes if n.note_type not in ("tool_fallback",)]
    if critical_notes:
        lines.append("")
        lines.append("=== GAPS ===")
        for note in critical_notes[:5]:
            lines.append(f"[{note.note_type}] {note.message[:120]}")
            for f in note.related_files[:2]:
                lines.append(f"  -> {f}")

    # ── Recommendation ────────────────────────────────────────────────────
    lines.append("")
    lines.append(f"SEND_TO:{report.recommended_model or 'claude-sonnet'}")
    if report.risk_level != "low":
        lines.append(f"RISK:{report.risk_level.upper()} — review before sending")

    return "\n".join(lines)


def render_json(pack: ContextPack, report: RunReport) -> str:
    """Render structured JSON for tooling."""
    import json
    from datetime import datetime

    chunks_by_file: dict[str, list[dict]] = {}
    for chunk in pack.chunks:
        chunks_by_file.setdefault(chunk.file_path, []).append({
            "start_line": chunk.start_line,
            "end_line": chunk.end_line,
            "content": chunk.content,
            "reason": chunk.reason,
            "tokens": chunk.token_estimate,
        })

    data = {
        "run_id": report.run_id,
        "task": pack.task,
        "classification": {
            "type": pack.task_classification.task_type.value,
            "difficulty": pack.task_classification.difficulty.value,
            "privacy": pack.task_classification.privacy.value,
            "confidence": pack.task_classification.confidence,
            "keywords": pack.task_classification.keywords_extracted,
        },
        "repo": {
            "root": str(pack.repo_profile.root),
            "framework": pack.repo_profile.framework,
            "language": pack.repo_profile.primary_language,
            "test_runner": pack.repo_profile.test_runner,
            "files_scanned": pack.repo_profile.total_files_scanned,
        },
        "tokens": {
            "raw": pack.raw_token_estimate,
            "optimized": pack.optimized_token_estimate,
            "savings_pct": report.savings_pct,
            "compression": pack.compression_level.name,
        },
        "security": {
            "clean": pack.security_report.clean,
            "scanner": pack.security_report.scanner_used,
            "secrets_found": len(pack.security_report.secrets_found),
            "files_blocked": pack.security_report.files_blocked,
            "files_warned": pack.security_report.files_warned,
        },
        "selected_files": [
            {
                "path": sf.file.relative_path,
                "score": sf.score,
                "score_breakdown": sf.score_breakdown,
                "language": sf.file.language,
                "is_test": sf.file.is_test,
                "chunks": chunks_by_file.get(sf.file.relative_path, []),
            }
            for sf in pack.selected_files
        ],
        "uncertainty_notes": [
            {
                "type": n.note_type,
                "message": n.message,
                "related_files": n.related_files,
            }
            for n in pack.uncertainty_notes
        ],
        "recommendation": {
            "model": report.recommended_model,
            "target": report.recommended_target.value,
            "risk_level": report.risk_level,
        },
    }

    return json.dumps(data, indent=2, default=str)