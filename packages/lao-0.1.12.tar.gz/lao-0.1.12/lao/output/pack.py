"""
Context pack Markdown writer.

Produces the .lao/runs/<run_id>/context-pack.md file
that the user pastes into Claude/Codex.

Format is designed to:
- Be immediately readable by a human
- Provide Claude with structured, unambiguous context
- Clearly mark what is uncertain or excluded
- Include actionable routing recommendation
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path

from lao.models import (
    CloudTarget,
    CompressionLevel,
    ContextPack,
    RunReport,
)
from lao.utils.fs import safe_write_text
from lao.utils.tokens import format_token_count

logger = logging.getLogger(__name__)

# Language → Markdown code fence identifier
LANG_TO_FENCE: dict[str, str] = {
    "typescript": "typescript",
    "javascript": "javascript",
    "python": "python",
    "rust": "rust",
    "go": "go",
    "java": "java",
    "kotlin": "kotlin",
    "swift": "swift",
    "ruby": "ruby",
    "php": "php",
    "csharp": "csharp",
    "cpp": "cpp",
    "c": "c",
    "yaml": "yaml",
    "json": "json",
    "toml": "toml",
    "bash": "bash",
    "markdown": "markdown",
    "sql": "sql",
    "html": "html",
    "css": "css",
    "scss": "scss",
}


def write_context_pack(
    pack: ContextPack,
    report: RunReport,
    output_dir: Path,
) -> Path:
    """
    Write context-pack.md to output_dir.

    Returns the path of the written file.
    Raises OutputError on write failure.
    """
    content = _render_pack(pack, report)
    output_path = output_dir / "context-pack.md"
    safe_write_text(output_path, content)
    logger.debug(f"Wrote context pack to {output_path}")
    return output_path


def _render_pack(pack: ContextPack, report: RunReport) -> str:
    """Render the full Markdown context pack."""
    sections: list[str] = []

    sections.append(_header(pack, report))
    sections.append(_task_section(pack))
    sections.append(_repo_section(pack))
    sections.append(_security_section(pack))
    sections.append(_evidence_section(pack))
    sections.append(_uncertainty_section(pack))
    sections.append(_token_report_section(pack, report))
    sections.append(_recommendation_section(pack, report))

    return "\n\n".join(s for s in sections if s.strip())


def _header(pack: ContextPack, report: RunReport) -> str:
    ts = pack.created_at.strftime("%Y-%m-%dT%H:%M:%SZ")
    return (
        f"# LAO Evidence Pack\n"
        f"Generated: {ts}  \n"
        f"Run ID: `{report.run_id}`"
    )


def _task_section(pack: ContextPack) -> str:
    c = pack.task_classification
    lines = [
        "## Task",
        f"> {pack.task}",
        "",
        f"**Type:** {c.task_type.value}  "
        f"**Difficulty:** {c.difficulty.value}  "
        f"**Privacy:** {c.privacy.value}  "
        f"**Classifier confidence:** {c.confidence:.0%}",
    ]
    if c.keywords_extracted:
        lines.append(f"**Keywords:** `{'`, `'.join(c.keywords_extracted)}`")
    return "\n".join(lines)


def _repo_section(pack: ContextPack) -> str:
    p = pack.repo_profile
    parts = []
    if p.framework:
        parts.append(f"Framework: **{p.framework}**")
    if p.primary_language:
        parts.append(f"Language: **{p.primary_language}**")
    if p.package_manager:
        parts.append(f"Package manager: **{p.package_manager}**")
    if p.test_runner:
        parts.append(f"Test runner: **{p.test_runner}**")

    lines = ["## Repo Profile"]
    lines.append("  ".join(parts) if parts else "_Unknown stack_")
    lines.append(
        f"Scanned **{p.total_files_scanned:,}** files "
        f"in `{p.root}`"
    )
    if p.important_dirs:
        lines.append(f"Key directories: `{'`, `'.join(p.important_dirs)}`")
    return "\n".join(lines)


def _security_section(pack: ContextPack) -> str:
    sr = pack.security_report
    lines = ["## Security"]

    lines.append(f"Scanner: `{sr.scanner_used}`")

    if sr.clean:
        lines.append("✓ No secrets detected")
    else:
        lines.append(f"⛔ **{len(sr.secrets_found)} secret(s) detected and redacted**")
        for finding in sr.secrets_found[:5]:  # Show max 5
            loc = f" (line {finding.line})" if finding.line else ""
            lines.append(f"  - `{finding.file}`{loc}: {finding.secret_type}")
        if len(sr.secrets_found) > 5:
            lines.append(f"  - ... and {len(sr.secrets_found) - 5} more")

    if sr.files_blocked:
        lines.append(f"⛔ **{len(sr.files_blocked)} file(s) blocked:**")
        for f in sr.files_blocked[:5]:
            lines.append(f"  - `{f}`")

    if sr.files_warned:
        lines.append(f"⚠ {len(sr.files_warned)} sensitive file(s) included with warning:")
        for f in sr.files_warned[:5]:
            lines.append(f"  - `{f}`")

    return "\n".join(lines)


def _evidence_section(pack: ContextPack) -> str:
    if not pack.chunks:
        return "## Evidence\n_No files selected._"

    lines = [
        f"## Evidence Files",
        f"_{len(pack.selected_files)} file(s) selected from "
        f"{pack.repo_profile.total_files_scanned:,} scanned_",
    ]

    if pack.compression_level > CompressionLevel.RAW:
        lines.append(
            f"⚠ Compression level: **{pack.compression_level.name}** "
            f"(content was reduced to fit token budget)"
        )

    # Group chunks by file
    chunks_by_file: dict[str, list] = {}
    for chunk in pack.chunks:
        chunks_by_file.setdefault(chunk.file_path, []).append(chunk)

    for sf in pack.selected_files:
        rel = sf.file.relative_path
        file_chunks = chunks_by_file.get(rel, [])
        if not file_chunks:
            continue

        lines.append(f"\n### `{rel}`")

        # Score and reason
        score_parts = []
        for k, v in sf.score_breakdown.items():
            if v != 0:
                sign = "+" if v > 0 else ""
                score_parts.append(f"{k}: {sign}{v:.1f}")
        if score_parts:
            lines.append(f"_Score: {sf.score:.1f} ({', '.join(score_parts)})_")

        # Chunks
        lang = sf.file.language or "text"
        fence = LANG_TO_FENCE.get(lang, lang)

        for chunk in file_chunks:
            lines.append(
                f"\n_Lines {chunk.start_line}–{chunk.end_line} "
                f"· {format_token_count(chunk.token_estimate)} tokens "
                f"· {chunk.reason}_"
            )
            lines.append(f"```{fence}")
            lines.append(chunk.content)
            lines.append("```")

    return "\n".join(lines)


def _uncertainty_section(pack: ContextPack) -> str:
    if not pack.uncertainty_notes:
        return ""

    lines = ["## Uncertainty Notes"]
    lines.append(
        "_These items may be relevant but were not included in the evidence pack:_"
    )
    for note in pack.uncertainty_notes:
        icon = "⚠" if note.note_type != "tool_fallback" else "ℹ"
        lines.append(f"\n{icon} **{note.note_type.replace('_', ' ').title()}**")
        lines.append(f"  {note.message}")
        if note.related_files:
            for f in note.related_files[:3]:
                lines.append(f"  → `{f}`")

    return "\n".join(lines)


def _token_report_section(pack: ContextPack, report: RunReport) -> str:
    raw = format_token_count(pack.raw_token_estimate)
    opt = format_token_count(pack.optimized_token_estimate)
    saved = format_token_count(report.tokens_saved_estimate)

    lines = [
        "## Token Report",
        f"| Metric | Value |",
        f"|--------|-------|",
        f"| Raw estimate | {raw} tokens |",
        f"| Optimized | {opt} tokens |",
        f"| Reduction | {report.savings_pct:.1f}% ({saved} tokens saved) |",
        f"| Compression | Level {pack.compression_level.value} ({pack.compression_level.name}) |",
    ]
    return "\n".join(lines)


def _recommendation_section(pack: ContextPack, report: RunReport) -> str:
    lines = ["## Recommended Action"]

    c = pack.task_classification
    if report.recommended_model:
        lines.append(f"**Send to:** `{report.recommended_model}`")
    else:
        from lao.constants import MODEL_RECOMMENDATIONS
        model_hint = MODEL_RECOMMENDATIONS.get(c.difficulty.value, "claude-sonnet")
        lines.append(f"**Suggested model:** {model_hint}")

    # Suggested prompt prefix based on task type
    prompt_hint = _get_prompt_hint(pack)
    if prompt_hint:
        lines.append(f"\n**Suggested prompt prefix:**")
        lines.append(f"```")
        lines.append(prompt_hint)
        lines.append(f"```")

    lines.append(
        "\n_To copy this pack: `cat .lao/runs/*/context-pack.md | pbcopy`_"
    )

    return "\n".join(lines)


def _get_prompt_hint(pack: ContextPack) -> str:
    """Generate a suggested prompt prefix based on task type."""
    from lao.models import TaskType

    task_type = pack.task_classification.task_type

    hints: dict[TaskType, str] = {
        TaskType.BUG_DIAGNOSIS: (
            "Using the evidence pack below, diagnose the root cause first. "
            "Do not write a patch until you've explained the bug. "
            "Keep the fix minimal. Do not change the architecture."
        ),
        TaskType.PATCH_GENERATION: (
            "Using the evidence pack below, implement the requested change. "
            "Keep the patch minimal. Do not add unnecessary dependencies. "
            "Follow the existing code patterns."
        ),
        TaskType.TEST_GENERATION: (
            "Using the evidence pack below, write the requested tests. "
            "Follow the existing test patterns in the codebase."
        ),
        TaskType.CODE_EXPLANATION: (
            "Using the evidence pack below, explain the code clearly. "
            "Focus on the specific question asked."
        ),
        TaskType.REPO_SEARCH: (
            "Using the evidence pack below, answer the search query. "
            "Reference specific files and line numbers."
        ),
    }

    return hints.get(task_type, "")
