"""File relevance scorer v3."""
from __future__ import annotations
import logging, re
from pathlib import Path
from lao.models import FileEntry, LimitsConfig, RepoProfile, ScoredFile, SearchMatch

logger = logging.getLogger(__name__)

KEYWORD_WEIGHT    = 3.0
ERROR_WEIGHT      = 10.0
TEST_WEIGHT       = 4.0
SEMANTIC_WEIGHT   = 5.0
SIZE_PENALTY_MAX  = 5.0
GENERATED_PENALTY = 8.0
KEYWORD_CAP       = 15.0
DOC_PENALTY       = 12.0
PATH_MATCH_BONUS  = 6.0
TEST_PENALTY      = 6.0
SYMBOL_BOOST      = 8.0   # keyword appears as function/class definition in file

ENTRY_POINT_FILES: frozenset[str] = frozenset({
    "__init__.py", "__main__.py", "main.py", "main.ts",
    "index.ts", "index.js", "index.tsx", "app.py", "app.ts",
    "server.py", "server.ts", "cli.py", "cmd.py",
})
DOC_EXTENSIONS: frozenset[str] = frozenset({".md", ".mdx", ".rst", ".txt"})
DOC_FILENAMES: frozenset[str] = frozenset({
    "readme.md", "changelog.md", "changelog.rst", "history.md",
    "contributing.md", "license", "license.txt", "license.md",
    "authors.md", "todo.md", "pkg-info", "sources.txt",
})
EXAMPLE_DIRS: frozenset[str] = frozenset({
    "docs_src", "examples", "example", "samples", "sample",
    "demo", "demos", "tutorials", "tutorial",
    "locale", "locales", "i18n", "l10n", "translations", "translation",
})
CI_CONFIG_DIRS: frozenset[str] = frozenset({
    ".github", ".gitlab", ".circleci", ".travis",
    ".buildkite", ".drone", ".jenkins",
})

STATIC_DIRS: frozenset[str] = frozenset({
    "static", "staticfiles", "media", "assets",
    "templates", "template", "public", "dist", "build",
})
PRIVATE_DIRS: frozenset[str] = frozenset({
    "_compat", "_internal", "_private", "_vendor", "vendor",
    "_deprecated", "_legacy",
})
# Tasks that actually want __init__.py
ARCHITECTURE_KEYWORDS: frozenset[str] = frozenset({
    "architecture", "export", "exports", "api", "public", "interface",
    "overview", "structure", "module", "package", "entrypoint", "entry",
})


def _stem(w: str) -> str:
    return w[:-3] if len(w) > 6 else w


def _has_symbol(content: str, keyword: str) -> bool:
    """Check if keyword appears as a def/class symbol in source."""
    pattern = re.compile(
        rf'(?:^|\s)(?:def|class|async def)\s+{re.escape(keyword)}\s*[:(]',
        re.MULTILINE | re.IGNORECASE,
    )
    return bool(pattern.search(content))


def score_files(
    files: list[FileEntry],
    matches: list[SearchMatch],
    task_keywords: list[str],
    error_paths: list[str],
    semantic_scores: dict[str, float],
    repo_profile: RepoProfile,
    config: LimitsConfig,
    import_scores: dict[str, float] | None = None,
    ai_boosts: dict[str, float] | None = None,
    symbol_scores: dict[str, float] | None = None,
) -> list[ScoredFile]:
    import_scores = import_scores or {}
    ai_boosts = ai_boosts or {}
    symbol_scores = symbol_scores or {}

    match_counts: dict[str, int] = {}
    match_lines: dict[str, list[int]] = {}
    for m in matches:
        match_counts[m.file] = match_counts.get(m.file, 0) + 1
        match_lines.setdefault(m.file, []).append(m.line)

    normalized_errors = {_normalize_path(p) for p in error_paths}

    # Check if task is architecture-type (wants __init__.py)
    task_wants_init = any(kw.lower() in ARCHITECTURE_KEYWORDS for kw in task_keywords)

    scored: list[ScoredFile] = []

    for file_entry in files:
        rel = file_entry.relative_path
        breakdown: dict[str, float] = {}
        total = 0.0

        # 1. Keyword match (capped)
        kw_count = match_counts.get(rel, 0)
        if kw_count > 0:
            kw_score = min(kw_count * KEYWORD_WEIGHT, KEYWORD_CAP)
            breakdown["keyword_match"] = kw_score
            total += kw_score

        # 2. Path match — stem of keyword in file path
        rel_lower = rel.lower()
        path_hits = sum(1 for kw in task_keywords if len(kw) >= 3 and _stem(kw.lower()) in rel_lower)
        if path_hits > 0:
            path_bonus = min(path_hits * PATH_MATCH_BONUS, PATH_MATCH_BONUS * 2)
            breakdown["path_match"] = path_bonus
            total += path_bonus

        # 3. Doc file penalty
        filename_lower = file_entry.path.name.lower()
        if file_entry.path.suffix.lower() in DOC_EXTENSIONS or filename_lower in DOC_FILENAMES:
            breakdown["doc_penalty"] = -DOC_PENALTY
            total -= DOC_PENALTY

        # 4. Directory penalties
        parts = rel_lower.replace("\\", "/").split("/")
        top = parts[0] if parts else ""
        second = parts[1] if len(parts) > 1 else ""

        if top in EXAMPLE_DIRS or second in EXAMPLE_DIRS or any(p in EXAMPLE_DIRS for p in parts):
            breakdown["example_penalty"] = -4.0
            total -= 4.0

        if top in CI_CONFIG_DIRS:
            breakdown["ci_penalty"] = -6.0
            total -= 6.0

        # Static/template dirs penalty — CSS, JS, HTML templates rarely answer code questions
        if any(p in STATIC_DIRS for p in parts):
            # Only penalize non-Python/TS files in these dirs
            if file_entry.path.suffix.lower() not in {".py", ".ts", ".tsx", ".js", ".jsx"}:
                breakdown["static_penalty"] = -6.0
                total -= 6.0

        # Private/compat dirs penalty
        if any(p in PRIVATE_DIRS for p in parts):
            breakdown["private_penalty"] = -3.0
            total -= 3.0

        # 5. Error path
        if _normalize_path(rel) in normalized_errors:
            breakdown["error_path"] = ERROR_WEIGHT
            total += ERROR_WEIGHT

        # 6. Import reference
        imp_score = import_scores.get(rel, 0.0)
        if imp_score > 0.0:
            breakdown["import_reference"] = imp_score
            total += imp_score

        # 6b. Symbol boost — keyword matches function/class name in file
        sym_boost = min(symbol_scores.get(rel, 0.0), 8.0)  # Cap at 8
        if sym_boost > 0.0:
            breakdown["symbol_boost"] = sym_boost
            total += sym_boost

        # 7. .ai/ repo-map boost
        ai_boost = ai_boosts.get(rel, 0.0)
        if ai_boost > 0.0:
            breakdown["repo_map_boost"] = ai_boost
            total += ai_boost

        # 8. Test file handling
        if file_entry.is_test:
            has_error_signal = _normalize_path(rel) in normalized_errors
            if has_error_signal:
                source_rel = _guess_source_for_test(rel)
                if source_rel and _normalize_path(source_rel) in {
                    _normalize_path(f.relative_path) for f in files
                    if match_counts.get(f.relative_path, 0) > 0
                    or _normalize_path(f.relative_path) in normalized_errors
                }:
                    breakdown["test_for_source"] = TEST_WEIGHT
                    total += TEST_WEIGHT
            else:
                breakdown["test_penalty"] = -TEST_PENALTY
                total -= TEST_PENALTY

        # 9. __init__.py penalty unless task wants API/architecture overview
        if file_entry.path.name == "__init__.py" and not task_wants_init:
            # Small penalty so source files rank higher
            breakdown["init_penalty"] = -3.0
            total -= 3.0

        # 10. Semantic (phase 2)
        sem_score = semantic_scores.get(rel, 0.0)
        if sem_score > 0.0:
            weighted = sem_score * SEMANTIC_WEIGHT
            breakdown["semantic"] = round(weighted, 2)
            total += weighted

        # 11. Size penalty
        if file_entry.size_tokens == 0 and file_entry.size_bytes > 0:
            file_entry.size_tokens = max(1, file_entry.size_bytes // 4)
        size_penalty = _compute_size_penalty(file_entry.size_tokens, config.max_file_tokens)
        if size_penalty > 0:
            breakdown["size_penalty"] = -size_penalty
            total -= size_penalty

        # 12. Entry-point bonus
        if file_entry.path.name in ENTRY_POINT_FILES:
            depth = rel.count("/")
            bonus = 8.0 if depth <= 1 else 4.0
            breakdown["entry_point"] = bonus
            total += bonus

        # 13. Generated penalty
        if file_entry.is_generated:
            if _normalize_path(rel) not in normalized_errors:
                breakdown["generated_penalty"] = -GENERATED_PENALTY
                total -= GENERATED_PENALTY

        scored.append(ScoredFile(
            file=file_entry, score=round(total, 2),
            score_breakdown=breakdown, matched_lines=match_lines.get(rel, []),
        ))

    scored.sort(key=lambda s: (-s.score, s.file.relative_path))

    # Module init boost: pull __init__.py of high-scoring non-test modules
    # Only when task is architecture-type
    if task_wants_init:
        module_max_score: dict[str, float] = {}
        for sf in scored:
            parts = sf.file.relative_path.replace("\\", "/").split("/")
            if len(parts) >= 2:
                module_dir = "/".join(parts[:-1])
                module_max_score[module_dir] = max(module_max_score.get(module_dir, 0), sf.score)

        for sf in scored:
            if sf.file.path.name == "__init__.py" and not sf.file.is_test:
                parts = sf.file.relative_path.replace("\\", "/").split("/")
                if len(parts) >= 2:
                    module_dir = "/".join(parts[:-1])
                    parent_max = module_max_score.get(module_dir, 0)
                    if parent_max >= 10.0 and sf.score < parent_max * 0.5:
                        boost = min(parent_max * 0.4, 8.0)
                        sf.score = round(sf.score + boost, 2)
                        sf.score_breakdown["module_init_boost"] = boost

        scored.sort(key=lambda s: (-s.score, s.file.relative_path))

    if all(s.score <= 0 for s in scored):
        scored.sort(key=lambda s: s.file.size_bytes)
    return scored


def select_top_files(scored, config):
    max_files = config.max_files_in_context
    selected: list[ScoredFile] = []
    selected_paths: set[str] = set()
    token_total = 0

    # Pass 1: critical files always in
    for sf in scored:
        if (sf.score_breakdown.get("error_path", 0) > 0
                or sf.score_breakdown.get("entry_point", 0) >= 8.0):
            selected.append(sf)
            selected_paths.add(sf.file.relative_path)
            token_total += sf.file.size_tokens or max(1, sf.file.size_bytes // 4)

    # Pass 2: fill by score
    for sf in scored:
        if len(selected) >= max_files:
            break
        if sf.file.relative_path in selected_paths:
            continue
        file_tokens = sf.file.size_tokens or max(1, sf.file.size_bytes // 4)
        if token_total + file_tokens <= config.max_total_context_tokens or not selected:
            selected.append(sf)
            selected_paths.add(sf.file.relative_path)
            token_total += file_tokens

    selected.sort(key=lambda s: -s.score)
    return selected


def extract_chunks(scored_file, context_lines=80, merge_gap=20):
    if not scored_file.matched_lines:
        return [(1, 100)]
    ranges = [(max(1, l - context_lines), l + context_lines) for l in scored_file.matched_lines]
    ranges.sort(key=lambda r: r[0])
    merged = [ranges[0]]
    for start, end in ranges[1:]:
        ps, pe = merged[-1]
        if start <= pe + merge_gap:
            merged[-1] = (ps, max(pe, end))
        else:
            merged.append((start, end))
    return merged


def _compute_size_penalty(size_tokens, max_tokens):
    if size_tokens <= max_tokens * 0.5: return 0.0
    if size_tokens >= max_tokens * 2.0: return SIZE_PENALTY_MAX
    return round((size_tokens - max_tokens * 0.5) / (max_tokens * 1.5) * SIZE_PENALTY_MAX, 2)


def _normalize_path(path):
    n = path.replace("\\", "/").lower()
    return n[2:] if n.startswith("./") else n


def _guess_source_for_test(test_path):
    lower = test_path.lower().replace("\\", "/")
    for prefix in ["tests/", "test/", "__tests__/", "spec/"]:
        if lower.startswith(prefix):
            remainder = re.sub(r'\.(test|spec)\.', '.', test_path[len(prefix):])
            remainder = re.sub(r'^test_', '', remainder)
            return f"src/{remainder}"
    cleaned = re.sub(r'\.(test|spec)\.', '.', test_path)
    return cleaned if cleaned != test_path else None