"""
Context pack builder.

Takes scored, selected files and constructs the ContextPack:
- Reads file content
- Extracts relevant chunks
- Estimates tokens
- Triggers compression if over budget
- Adds uncertainty annotations
"""

from __future__ import annotations

import logging
import time
from pathlib import Path

from lao.constants import CHUNK_CONTEXT_LINES, CHUNK_MERGE_GAP_LINES
from lao.models import (
    CompressionLevel,
    ContextChunk,
    ContextPack,
    LimitsConfig,
    RepoProfile,
    ScoredFile,
    SecurityReport,
    TaskClassification,
    UncertaintyNote,
)
from lao.context.scorer import extract_chunks
from lao.utils.fs import read_text_safe
from lao.utils.tokens import estimate_tokens

logger = logging.getLogger(__name__)


def build_context_pack(
    task: str,
    classification: TaskClassification,
    repo_profile: RepoProfile,
    selected_files: list[ScoredFile],
    security_report: SecurityReport,
    config: LimitsConfig,
    all_file_paths: list[str],
) -> ContextPack:
    """
    Build the full ContextPack from selected files.

    Args:
        task: Original task string.
        classification: Task classification result.
        repo_profile: Repo metadata.
        selected_files: Scored, policy-filtered files to include.
        security_report: Security scan results.
        config: Limits for token budgeting.
        all_file_paths: All file paths in repo (for uncertainty detection).

    Returns:
        Fully populated ContextPack.
    """
    # Step 1: Read and chunk files
    chunks = _extract_all_chunks(selected_files, config)

    # Step 2: Estimate raw tokens (all chunks concatenated)
    raw_tokens = sum(c.token_estimate for c in chunks)

    # Step 3: Compress if needed
    compression_level = CompressionLevel.RAW
    if raw_tokens > config.max_total_context_tokens:
        chunks, compression_level = _compress_to_budget(
            chunks, config.max_total_context_tokens
        )

    optimized_tokens = sum(c.token_estimate for c in chunks)

    # Step 4: Generate uncertainty notes
    uncertainty_notes = _build_uncertainty_notes(
        selected_files=selected_files,
        security_report=security_report,
        all_file_paths=all_file_paths,
        config=config,
        compression_level=compression_level,
    )

    return ContextPack(
        task=task,
        task_classification=classification,
        repo_profile=repo_profile,
        selected_files=selected_files,
        chunks=chunks,
        security_report=security_report,
        uncertainty_notes=uncertainty_notes,
        compression_level=compression_level,
        raw_token_estimate=raw_tokens,
        optimized_token_estimate=optimized_tokens,
    )


def _extract_all_chunks(
    selected_files: list[ScoredFile],
    config: LimitsConfig,
) -> list[ContextChunk]:
    """
    For each selected file, extract relevant chunks.
    Populates token_estimate per chunk.
    """
    all_chunks: list[ContextChunk] = []

    for sf in selected_files:
        file_path = sf.file.path
        rel_path = sf.file.relative_path

        content = read_text_safe(file_path)
        if content is None:
            logger.debug(f"Could not read {rel_path} (binary or too large), skipping")
            continue
        # Skip binary content that slipped through
        if '\x00' in content[:1000]:
            logger.debug(f"Skipping binary content: {rel_path}")
            continue

        lines = content.splitlines()
        total_lines = len(lines)

        # Get relevant line ranges
        chunk_ranges = extract_chunks(
            sf,
            context_lines=CHUNK_CONTEXT_LINES,
            merge_gap=CHUNK_MERGE_GAP_LINES,
        )

        for start, end in chunk_ranges:
            # Clamp to actual file size
            start = max(1, min(start, total_lines))
            end = min(end, total_lines)

            if start > end:
                continue

            # Extract lines (0-indexed internally, 1-indexed in model)
            chunk_lines = lines[start - 1:end]
            chunk_content = "\n".join(chunk_lines)

            if not chunk_content.strip():
                continue

            # Cap chunk at max_file_tokens
            token_count = estimate_tokens(chunk_content)
            if token_count > config.max_file_tokens:
                # Truncate from the middle, keeping start and end
                chunk_content, token_count = _truncate_chunk_middle(
                    chunk_lines, config.max_file_tokens
                )

            # Build reason string
            reason = _build_chunk_reason(sf, start, end)

            all_chunks.append(ContextChunk(
                file_path=rel_path,
                start_line=start,
                end_line=end,
                content=chunk_content,
                reason=reason,
                token_estimate=token_count,
            ))

    return all_chunks


def _truncate_chunk_middle(lines: list[str], max_tokens: int) -> tuple[str, int]:
    """
    Truncate a chunk by removing lines from the middle.
    Keeps the first 1/3 and last 1/3 of lines.
    Returns (content, token_estimate).
    """
    if not lines:
        return "", 0

    n = len(lines)
    keep_start = n // 3
    keep_end = n // 3

    kept = (
        lines[:keep_start]
        + [f"... [{n - keep_start - keep_end} lines omitted] ..."]
        + lines[n - keep_end:]
    )
    content = "\n".join(kept)
    return content, estimate_tokens(content)


def _compress_to_budget(
    chunks: list[ContextChunk],
    budget: int,
) -> tuple[list[ContextChunk], CompressionLevel]:
    """
    Reduce total tokens to fit within budget.

    Tries progressively more aggressive compression:
    Level 1: Drop chunks from lowest-relevance files (by position in list)
    Level 2: Truncate large chunks to 50% of max_file_tokens
    Level 3: Keep only first 30 lines per chunk

    Returns (compressed_chunks, final_compression_level).
    Does NOT raise TokenBudgetExceededError here – caller handles that.
    """
    current_total = sum(c.token_estimate for c in chunks)

    if current_total <= budget:
        return chunks, CompressionLevel.RAW

    # Level 1: Drop tail chunks (lowest relevance, since files are score-sorted)
    level1_chunks = _drop_tail_chunks(chunks, budget)
    if sum(c.token_estimate for c in level1_chunks) <= budget:
        return level1_chunks, CompressionLevel.SUMMARIZED

    # Level 2: Truncate large individual chunks
    level2_chunks = _truncate_large_chunks(level1_chunks, budget)
    if sum(c.token_estimate for c in level2_chunks) <= budget:
        return level2_chunks, CompressionLevel.COMPACT

    # Level 3: Hard truncate everything to 30 lines
    level3_chunks = _hard_truncate(level2_chunks, max_lines=30)
    return level3_chunks, CompressionLevel.MINIMAL


def _drop_tail_chunks(chunks: list[ContextChunk], budget: int) -> list[ContextChunk]:
    """Remove chunks from the end until under budget."""
    result = list(chunks)
    while result and sum(c.token_estimate for c in result) > budget:
        result.pop()
    return result if result else chunks[:1]  # Keep at least one


def _truncate_large_chunks(chunks: list[ContextChunk], budget: int) -> list[ContextChunk]:
    """Halve tokens for chunks above median size."""
    if not chunks:
        return chunks

    median_tokens = sorted(c.token_estimate for c in chunks)[len(chunks) // 2]
    result = []
    running_total = 0

    for chunk in chunks:
        if chunk.token_estimate > median_tokens:
            lines = chunk.content.splitlines()
            half = len(lines) // 2
            new_content = "\n".join(lines[:half]) + "\n... [truncated] ..."
            new_tokens = estimate_tokens(new_content)
            result.append(ContextChunk(
                file_path=chunk.file_path,
                start_line=chunk.start_line,
                end_line=chunk.start_line + half,
                content=new_content,
                reason=chunk.reason + " [truncated]",
                token_estimate=new_tokens,
            ))
            running_total += new_tokens
        else:
            result.append(chunk)
            running_total += chunk.token_estimate

        if running_total >= budget:
            break

    return result


def _hard_truncate(chunks: list[ContextChunk], max_lines: int = 30) -> list[ContextChunk]:
    """Hard-truncate every chunk to max_lines."""
    result = []
    for chunk in chunks:
        lines = chunk.content.splitlines()
        if len(lines) > max_lines:
            new_content = "\n".join(lines[:max_lines]) + f"\n... [{len(lines) - max_lines} more lines] ..."
            new_tokens = estimate_tokens(new_content)
            result.append(ContextChunk(
                file_path=chunk.file_path,
                start_line=chunk.start_line,
                end_line=chunk.start_line + max_lines,
                content=new_content,
                reason=chunk.reason + " [hard truncated]",
                token_estimate=new_tokens,
            ))
        else:
            result.append(chunk)
    return result


def _build_chunk_reason(sf: ScoredFile, start: int, end: int) -> str:
    """Human-readable reason why this chunk is included."""
    reasons = []

    if sf.score_breakdown.get("error_path", 0) > 0:
        reasons.append("error path reference")
    if sf.score_breakdown.get("keyword_match", 0) > 0:
        kw_score = sf.score_breakdown["keyword_match"]
        reasons.append(f"keyword match (score: {kw_score:.1f})")
    if sf.score_breakdown.get("test_for_source", 0) > 0:
        reasons.append("test file for source")
    if sf.score_breakdown.get("semantic", 0) > 0:
        reasons.append("semantic similarity")

    if not reasons:
        reasons.append(f"score: {sf.score:.1f}")

    return ", ".join(reasons)


def _build_uncertainty_notes(
    selected_files: list[ScoredFile],
    security_report: SecurityReport,
    all_file_paths: list[str],
    config: LimitsConfig,
    compression_level: CompressionLevel,
) -> list[UncertaintyNote]:
    """
    Generate uncertainty notes for the pack.

    Notes are critical for helping Claude understand what it might be missing.
    """
    from lao.scanner.search import ripgrep_available
    from lao.security.scanner import gitleaks_available

    notes: list[UncertaintyNote] = []
    selected_paths = {sf.file.relative_path for sf in selected_files}

    # Tool fallback warnings
    if not ripgrep_available():
        notes.append(UncertaintyNote(
            note_type="tool_fallback",
            message=(
                "ripgrep not available. Search used slower Python fallback. "
                "Some matches may be missed. Install ripgrep for better results."
            ),
        ))

    if not gitleaks_available():
        notes.append(UncertaintyNote(
            note_type="tool_fallback",
            message=(
                "gitleaks not available. Secret scanning used basic regex patterns. "
                "Complex secrets may not be detected."
            ),
        ))

    # Security exclusions
    for blocked_file in security_report.files_blocked:
        notes.append(UncertaintyNote(
            note_type="security_excluded",
            message=(
                f"'{blocked_file}' was excluded (security: blocked). "
                "May contain relevant context."
            ),
            related_files=[blocked_file],
        ))

    for warned_file in security_report.files_warned:
        if warned_file not in selected_paths:
            notes.append(UncertaintyNote(
                note_type="security_excluded",
                message=(
                    f"'{warned_file}' was excluded (security: sensitive path). "
                    "May be relevant."
                ),
                related_files=[warned_file],
            ))

    # Compression warning
    if compression_level > CompressionLevel.RAW:
        notes.append(UncertaintyNote(
            note_type="truncated",
            message=(
                f"Context was compressed to compression level {compression_level.value} "
                f"to fit within {config.max_total_context_tokens:,} token budget. "
                "Some file content was truncated or dropped."
            ),
        ))

    # Large file truncations
    for sf in selected_files:
        if sf.file.size_tokens > config.max_file_tokens:
            notes.append(UncertaintyNote(
                note_type="truncated",
                message=(
                    f"'{sf.file.relative_path}' was truncated "
                    f"(file: ~{sf.file.size_tokens:,} tokens, "
                    f"limit: {config.max_file_tokens:,} tokens)."
                ),
                related_files=[sf.file.relative_path],
            ))

    return notes


def _build_chunk_reason(sf: ScoredFile, start: int, end: int) -> str:
    """Human-readable reason why this chunk is included."""
    reasons = []

    if sf.score_breakdown.get("error_path", 0) > 0:
        reasons.append("error path reference")
    if sf.score_breakdown.get("keyword_match", 0) > 0:
        kw_score = sf.score_breakdown["keyword_match"]
        reasons.append(f"keyword match (score: {kw_score:.1f})")
    if sf.score_breakdown.get("test_for_source", 0) > 0:
        reasons.append("test file for source")
    if sf.score_breakdown.get("semantic", 0) > 0:
        reasons.append("semantic similarity")

    if not reasons:
        reasons.append(f"score: {sf.score:.1f}")

    return ", ".join(reasons)
