"""
Secret scanner.

Two-layer approach:
1. Gitleaks (preferred): comprehensive, fast Go binary, 150+ patterns
2. Regex fallback: ~18 patterns for common secrets when gitleaks absent

Never raises on "found secrets" — that's a normal result reported in
SecurityReport. Only raises SecurityError when the scanning itself breaks.
"""

from __future__ import annotations

import json
import logging
import math
import re
import tempfile
import time
from functools import lru_cache
from pathlib import Path
from typing import Optional

from lao.constants import (
    ENTROPY_HIGH_THRESHOLD,
    ENTROPY_MIN_LENGTH,
    FALLBACK_SECRET_PATTERNS,
    GITLEAKS_TIMEOUT_SECONDS,
)
from lao.exceptions import SecurityError
from lao.models import SecretFinding, SecurityReport
from lao.utils.process import is_available, run

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def gitleaks_available() -> bool:
    """Check once per process if gitleaks is on PATH."""
    available = is_available("gitleaks")
    if not available:
        logger.warning(
            "gitleaks not found. Using basic regex secret scanner. "
            "Install gitleaks: brew install gitleaks | "
            "https://github.com/gitleaks/gitleaks/releases"
        )
    return available


def scan_content(
    content: str,
    file_path: str,
) -> list[SecretFinding]:
    """
    Scan a single file's content for secrets.

    Dispatches to gitleaks (via temp file) or regex fallback.
    Returns list of SecretFinding. Empty list = clean.
    """
    if gitleaks_available():
        return _scan_with_gitleaks(content, file_path)
    return _scan_with_regex_fallback(content, file_path)


def scan_files(
    files: list[tuple[str, str]],  # (relative_path, content)
    timeout: float = GITLEAKS_TIMEOUT_SECONDS,
) -> SecurityReport:
    """
    Scan multiple files and produce a SecurityReport.

    Args:
        files: List of (relative_path, content) tuples.
        timeout: Total timeout for scanning.

    Returns:
        SecurityReport with all findings.
    """
    start_ms = time.monotonic() * 1000
    all_findings: list[SecretFinding] = []
    scanner_used = "gitleaks" if gitleaks_available() else "regex_fallback"

    for rel_path, content in files:
        if not content:
            continue
        findings = scan_content(content, rel_path)
        all_findings.extend(findings)

    elapsed_ms = (time.monotonic() * 1000) - start_ms

    return SecurityReport(
        secrets_found=all_findings,
        scanner_used=scanner_used,
        scan_duration_ms=round(elapsed_ms, 1),
    )


def _scan_with_gitleaks(content: str, file_path: str) -> list[SecretFinding]:
    """
    Write content to a temp file and run gitleaks detect on it.

    gitleaks exit codes:
    - 0: no secrets found
    - 1: secrets found (NOT an error for us)
    - 2: actual gitleaks error

    We use `gitleaks detect --source` on a temp directory
    with the file in place, using --report-format json.
    """
    findings: list[SecretFinding] = []

    with tempfile.TemporaryDirectory() as tmpdir:
        # Write content to temp file preserving the original filename
        # so gitleaks rule matching by filename works correctly
        tmp_file = Path(tmpdir) / Path(file_path).name
        try:
            tmp_file.write_text(content, encoding="utf-8")
        except OSError as e:
            logger.debug(f"Could not write temp file for gitleaks scan: {e}")
            return _scan_with_regex_fallback(content, file_path)

        report_file = Path(tmpdir) / "gitleaks-report.json"

        result = run(
            [
                "gitleaks",
                "detect",
                "--source", tmpdir,
                "--report-format", "json",
                "--report-path", str(report_file),
                "--no-git",        # Scan files directly, no git history
                "--exit-code", "0",  # Don't exit 1 on findings (we check report)
            ],
            timeout=GITLEAKS_TIMEOUT_SECONDS,
        )

        if result.timed_out:
            logger.warning(f"gitleaks timed out scanning {file_path}")
            return []

        if result.returncode not in (0, 1):
            logger.warning(
                f"gitleaks exited with code {result.returncode} "
                f"for {file_path}: {result.stderr[:200]}"
            )
            # Fall back to regex
            return _scan_with_regex_fallback(content, file_path)

        # Parse JSON report
        if not report_file.exists():
            return findings

        try:
            report_text = report_file.read_text(encoding="utf-8")
            if not report_text.strip():
                return findings
            report_data = json.loads(report_text)
        except (json.JSONDecodeError, OSError) as e:
            logger.debug(f"Could not parse gitleaks report: {e}")
            return findings

        if not isinstance(report_data, list):
            return findings

        for item in report_data:
            if not isinstance(item, dict):
                continue
            findings.append(SecretFinding(
                file=file_path,
                line=item.get("StartLine"),
                secret_type=item.get("RuleID", "unknown"),
                pattern_matched=item.get("Match", "")[:100],  # Truncate for safety
                action_taken="redacted",
            ))

    return findings


def _scan_with_regex_fallback(content: str, file_path: str) -> list[SecretFinding]:
    """
    Fallback secret scanner using regex + entropy analysis.

    Less comprehensive than gitleaks but covers common patterns.
    Includes Shannon entropy check for high-entropy strings.
    """
    findings: list[SecretFinding] = []
    lines = content.splitlines()

    for pattern_name, pattern_str in FALLBACK_SECRET_PATTERNS.items():
        if pattern_str is None:
            continue  # Entropy-only patterns handled below
        try:
            compiled = re.compile(pattern_str, re.MULTILINE)
        except re.error:
            continue

        for line_no, line in enumerate(lines, start=1):
            if compiled.search(line):
                findings.append(SecretFinding(
                    file=file_path,
                    line=line_no,
                    secret_type=pattern_name,
                    pattern_matched=pattern_name,
                    action_taken="redacted",
                ))
                break  # One finding per pattern per file is enough

    # Entropy check: find suspiciously random strings
    entropy_findings = _check_entropy(lines, file_path)
    findings.extend(entropy_findings)

    return findings


def _check_entropy(lines: list[str], file_path: str) -> list[SecretFinding]:
    """
    Find high-entropy strings that might be secrets.

    Logic:
    - Extract token-like strings (alphanumeric + special chars, no spaces)
    - Skip strings shorter than ENTROPY_MIN_LENGTH
    - Skip strings that look like UUIDs (common false positive)
    - Skip base64-looking strings in obvious non-secret contexts
    - Flag strings with entropy > ENTROPY_HIGH_THRESHOLD

    This generates false positives, so it's a "warn" signal only.
    """
    findings: list[SecretFinding] = []
    # Match long token-like strings (potential secrets)
    token_pattern = re.compile(r'["\']([A-Za-z0-9+/=_\-]{20,})["\']')
    uuid_pattern = re.compile(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
        re.IGNORECASE
    )

    for line_no, line in enumerate(lines, start=1):
        # Skip obvious comment lines
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith("//"):
            continue

        for match in token_pattern.finditer(line):
            token = match.group(1)
            if len(token) < ENTROPY_MIN_LENGTH:
                continue
            if uuid_pattern.match(token):
                continue  # UUIDs are not secrets

            entropy = _shannon_entropy(token)
            if entropy > ENTROPY_HIGH_THRESHOLD:
                findings.append(SecretFinding(
                    file=file_path,
                    line=line_no,
                    secret_type="high_entropy_string",
                    pattern_matched=f"entropy={entropy:.2f}",
                    action_taken="warned",
                ))
                break  # One entropy finding per line

    return findings


def _shannon_entropy(s: str) -> float:
    """
    Calculate Shannon entropy of a string.

    Returns a float between 0 (all same chars) and log2(len(charset)).
    Typical values:
    - Random base64: ~6.0
    - English text: ~3.5-4.5
    - Repeated chars: <1.0
    """
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    n = len(s)
    return -sum((count / n) * math.log2(count / n) for count in freq.values())
