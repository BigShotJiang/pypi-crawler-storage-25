"""
File policy engine.

Determines whether a file is allowed, warned, or blocked
from inclusion in the cloud context pack.

Policy resolution order (first match wins):
  1. cloud_deny  → BLOCK
  2. cloud_warn  → WARN
  3. cloud_allow → ALLOW
  4. default     → WARN (unknown files are warned, not silently allowed)
"""

from __future__ import annotations

import logging
from pathlib import Path

from lao.models import PolicyDecision, SecurityConfig
from lao.utils.fs import matches_any_pattern

logger = logging.getLogger(__name__)


def check_file_policy(
    relative_path: str,
    config: SecurityConfig,
) -> PolicyDecision:
    """
    Check a single file against the security policy.

    Args:
        relative_path: Path relative to repo root, forward-slash separated.
        config: SecurityConfig with deny/warn/allow lists.

    Returns:
        PolicyDecision enum value.

    Edge cases:
    - File matches both deny AND allow → BLOCK (deny always wins)
    - Empty allow list → all non-denied files are WARN not ALLOW
    - .env files: caught by deny patterns (block_env_files adds them)
    - Case sensitivity: matching is always lowercase (Unix standard)
    """
    # Always check .env* files explicitly when block_env_files is set
    if config.block_env_files:
        env_patterns = [".env", ".env.*", ".env*"]
        if matches_any_pattern(relative_path, env_patterns):
            logger.debug(f"BLOCK (env file): {relative_path}")
            return PolicyDecision.BLOCK

    # 1. Deny check (highest priority)
    if matches_any_pattern(relative_path, config.cloud_deny):
        logger.debug(f"BLOCK (deny pattern): {relative_path}")
        return PolicyDecision.BLOCK

    # 2. Warn check
    if matches_any_pattern(relative_path, config.cloud_warn):
        logger.debug(f"WARN (warn pattern): {relative_path}")
        return PolicyDecision.WARN

    # 3. Allow check
    if config.cloud_allow and matches_any_pattern(relative_path, config.cloud_allow):
        logger.debug(f"ALLOW (allow pattern): {relative_path}")
        return PolicyDecision.ALLOW

    # 4. Default: ALLOW unknown files
    # Deny-first model: if not explicitly denied or warned, it is allowed.
    # This avoids false-positive MEDIUM RISK on every non-standard file.
    logger.debug(f"ALLOW (default, no pattern matched): {relative_path}")
    return PolicyDecision.ALLOW


def filter_files_by_policy(
    relative_paths: list[str],
    config: SecurityConfig,
    interactive: bool = False,
) -> tuple[list[str], list[str], list[str]]:
    """
    Apply policy to a list of file paths.

    Args:
        relative_paths: Files to check.
        config: SecurityConfig.
        interactive: If True, WARN files can be confirmed by user.
                     If False, WARN files are included with a warning note.

    Returns:
        (allowed, warned, blocked) – three lists of relative paths.
        In non-interactive mode, 'warned' files are included in allowed
        but also returned in warned for annotation purposes.
    """
    allowed: list[str] = []
    warned: list[str] = []
    blocked: list[str] = []

    for path in relative_paths:
        decision = check_file_policy(path, config)

        if decision == PolicyDecision.BLOCK:
            blocked.append(path)
        elif decision == PolicyDecision.WARN:
            warned.append(path)
            # In non-interactive mode: include with warning annotation
            if not interactive:
                allowed.append(path)
        else:  # ALLOW
            allowed.append(path)

    return allowed, warned, blocked