"""
All custom exceptions for lao.

Design principles:
- Every exception carries enough context to produce a useful error message.
- No bare `Exception` raises anywhere in the codebase.
- Exceptions are grouped by subsystem.
- All public exceptions inherit from LaoError so callers can catch broadly.
"""

from __future__ import annotations


class LaoError(Exception):
    """Base exception for all lao errors."""
    pass


# ─── Config ───────────────────────────────────────────────────────────────────

class ConfigError(LaoError):
    """
    Raised when config file is invalid, missing required fields,
    or fails Pydantic validation.
    """
    pass


class ConfigNotFoundError(ConfigError):
    """
    Raised when no config or project root can be found.
    Guides the user to run `lao init`.
    """
    def __init__(self, searched_path: str) -> None:
        super().__init__(
            f"No lao project found at or above '{searched_path}'. "
            "Run `lao init` to initialize a project."
        )


# ─── Repo Scanner ─────────────────────────────────────────────────────────────

class RepoScanError(LaoError):
    """Raised when repo scanning fails (e.g. permission errors, too deep)."""
    pass


class RepoTooLargeError(RepoScanError):
    """
    Raised when repo exceeds MAX_FILES_HARD_LIMIT.
    User should configure ignore patterns.
    """
    def __init__(self, count: int, limit: int) -> None:
        super().__init__(
            f"Repo contains {count:,} files, exceeding hard limit of {limit:,}. "
            "Add more paths to 'cloud_deny' or ignore patterns in .lao/config.yaml."
        )


# ─── Search ───────────────────────────────────────────────────────────────────

class SearchError(LaoError):
    """Raised when a search operation fails."""
    pass


class ExternalToolError(LaoError):
    """
    Raised when an external binary (ripgrep, gitleaks) is not found
    or exits with an unexpected non-zero code.

    Exit code semantics vary:
    - ripgrep: 0 = matches found, 1 = no matches, 2 = error
    - gitleaks: 0 = no secrets, 1 = secrets found, 2 = error
    Callers must interpret exit codes before raising this.
    """
    def __init__(self, tool: str, returncode: int, stderr: str) -> None:
        self.tool = tool
        self.returncode = returncode
        self.stderr = stderr.strip()
        super().__init__(
            f"External tool '{tool}' failed with exit code {returncode}. "
            f"stderr: {self.stderr or '(empty)'}"
        )


class ToolNotFoundError(ExternalToolError):
    """
    Raised when a required/optional binary is not on PATH.
    Includes install instructions.
    """
    INSTALL_HINTS: dict[str, str] = {
        "rg": "brew install ripgrep  |  apt install ripgrep  |  cargo install ripgrep",
        "gitleaks": "brew install gitleaks  |  https://github.com/gitleaks/gitleaks/releases",
    }

    def __init__(self, tool: str) -> None:
        hint = self.INSTALL_HINTS.get(tool, f"See documentation for '{tool}'")
        self.tool = tool
        self.returncode = -1
        self.stderr = ""
        # Bypass ExternalToolError.__init__ to set a cleaner message
        LaoError.__init__(
            self,
            f"Tool '{tool}' not found on PATH. To install: {hint}"
        )


# ─── Security ─────────────────────────────────────────────────────────────────

class SecurityError(LaoError):
    """
    Raised when the security scanning infrastructure itself fails
    (not when a secret is found – that is reported in SecurityReport).
    """
    pass


class SecurityBlockedError(LaoError):
    """
    Raised when an operation is blocked by security policy.
    E.g. attempting to send a local_only task to cloud.
    """
    def __init__(self, reason: str) -> None:
        super().__init__(f"Operation blocked by security policy: {reason}")


# ─── Context / Token Budget ───────────────────────────────────────────────────

class ContextBuildError(LaoError):
    """Raised when context pack cannot be constructed."""
    pass


class TokenBudgetExceededError(LaoError):
    """
    Raised when context exceeds budget even after maximum compression.
    Carries both values so the CLI can show a useful diff.
    """
    def __init__(self, budget: int, actual: int) -> None:
        self.budget = budget
        self.actual = actual
        pct_over = ((actual - budget) / budget) * 100
        super().__init__(
            f"Context is {actual:,} tokens — {pct_over:.0f}% over budget of {budget:,}. "
            "Try: splitting the task, reducing max_files_in_context, "
            "or increasing max_total_context_tokens in config."
        )


# ─── Embeddings ───────────────────────────────────────────────────────────────

class EmbeddingError(LaoError):
    """
    Raised when embedding model cannot be loaded or inference fails.
    System should gracefully fall back to keyword-only search.
    """
    pass


class IndexCorruptError(EmbeddingError):
    """
    Raised when the LanceDB index is corrupted or incompatible.
    User should run `lao index --rebuild`.
    """
    def __init__(self, path: str) -> None:
        super().__init__(
            f"Vector index at '{path}' is corrupted or incompatible. "
            "Run `lao index --rebuild` to recreate it."
        )


# ─── Output ───────────────────────────────────────────────────────────────────

class OutputError(LaoError):
    """Raised when writing output files fails (disk full, permissions, etc.)."""
    pass
