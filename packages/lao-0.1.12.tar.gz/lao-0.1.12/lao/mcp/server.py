"""
LAO MCP Server.

Exposes lao functionality as MCP tools so Claude Code, Cursor,
and any other MCP-compatible agent can call lao directly.

Tools:
  lao_prep(task, repo_path?, extra_context?, output_format?)
    → Prepare an evidence pack for a task

  lao_map(repo_path?)
    → Generate or refresh .ai/ repo infrastructure

  lao_status(repo_path?)
    → Show current lao status and last run stats

Usage:
  lao mcp start              # Start MCP server (stdio transport)
  lao mcp start --http 8765  # Start with HTTP/SSE transport

Claude Code config (.claude/settings.json):
  {
    "mcpServers": {
      "lao": {
        "command": "uv",
        "args": ["run", "--project", "/path/to/lao", "lao", "mcp", "start"],
        "cwd": "/your/repo"
      }
    }
  }
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def create_mcp_server():
    """Create and configure the FastMCP server."""
    try:
        from fastmcp import FastMCP
    except ImportError:
        raise ImportError(
            "fastmcp is required for MCP server. "
            "Install with: pip install fastmcp"
        )

    mcp = FastMCP("lao")

    @mcp.tool()
    def lao_prep(
        task: str,
        repo_path: Optional[str] = None,
        extra_context: Optional[str] = None,
        output_format: str = "compact",
    ) -> str:
        """
        Prepare an evidence pack for a coding task.

        Scans the repo, finds relevant files, checks for secrets,
        and returns a token-efficient context pack.

        Args:
            task: The coding task description (e.g. "fix failing auth test")
            repo_path: Path to the repo. Defaults to current directory.
            extra_context: Additional context like error output or stacktraces.
            output_format: "compact" (default), "json", or "markdown"

        Returns:
            Evidence pack as a string in the requested format.
        """
        from lao.config import load_config
        from lao.core.runner import run_prep
        from lao.models import TaskInput
        from lao.output.compact import render_compact, render_json

        repo = Path(repo_path or ".").resolve()

        try:
            config = load_config(repo)
            task_input = TaskInput(
                task=task,
                repo_path=repo,
                extra_context=extra_context,
            )
            pack, report, pack_path, _ = run_prep(task_input, config, silent=True)

            if output_format == "json":
                return render_json(pack, report)
            elif output_format == "compact":
                return render_compact(pack, report)
            else:
                return pack_path.read_text(encoding="utf-8")

        except Exception as e:
            logger.exception(f"lao_prep failed: {e}")
            return json.dumps({
                "error": str(e),
                "task": task,
                "repo": str(repo),
            })

    @mcp.tool()
    def lao_map(
        repo_path: Optional[str] = None,
        force: bool = False,
    ) -> str:
        """
        Generate or refresh .ai/ repo infrastructure.

        Creates manifest.yaml, repo-map.yaml, test-map.yaml,
        risk-zones.yaml, and agent-rules.md in .ai/ directory.

        Args:
            repo_path: Path to the repo. Defaults to current directory.
            force: Regenerate even if .ai/ already exists.

        Returns:
            Summary of generated files.
        """
        from lao.config import load_config
        from lao.scanner.repo import scan_repo
        from lao.core.mapper import generate_ai_dir

        repo = Path(repo_path or ".").resolve()

        ai_dir = repo / ".ai"
        if ai_dir.exists() and not force:
            existing = list(ai_dir.glob("*.yaml")) + list(ai_dir.glob("*.md"))
            return json.dumps({
                "status": "exists",
                "message": f".ai/ already exists with {len(existing)} files. Use force=true to regenerate.",
                "files": [f.name for f in existing],
            })

        try:
            config = load_config(repo)
            profile, files = scan_repo(repo, config)
            written = generate_ai_dir(repo, profile, files, config)

            return json.dumps({
                "status": "generated",
                "files": {name: str(path) for name, path in written.items()},
                "repo": {
                    "framework": profile.framework,
                    "language": profile.primary_language,
                    "files_scanned": profile.total_files_scanned,
                },
            })

        except Exception as e:
            logger.exception(f"lao_map failed: {e}")
            return json.dumps({"error": str(e), "repo": str(repo)})

    @mcp.tool()
    def lao_status(
        repo_path: Optional[str] = None,
    ) -> str:
        """
        Show current lao status and last run statistics.

        Args:
            repo_path: Path to the repo. Defaults to current directory.

        Returns:
            Status summary as JSON.
        """
        repo = Path(repo_path or ".").resolve()

        try:
            from lao.config import find_project_root
            root = find_project_root(repo)
            lao_dir = root / ".lao"
            report_path = lao_dir / "report.json"
            ai_dir = root / ".ai"

            status: dict = {
                "repo": str(root),
                "lao_initialized": lao_dir.exists(),
                "ai_dir_exists": ai_dir.exists(),
                "last_run": None,
            }

            if report_path.exists():
                report_data = json.loads(report_path.read_text())
                status["last_run"] = {
                    "run_id": report_data.get("run_id"),
                    "task": report_data.get("task", "")[:80],
                    "recall_files": report_data.get("files_selected"),
                    "tokens_optimized": report_data.get("optimized_token_estimate"),
                    "savings_pct": report_data.get("savings_pct"),
                    "risk_level": report_data.get("risk_level"),
                    "recommended_model": report_data.get("recommended_model"),
                }

            if ai_dir.exists():
                ai_files = [f.name for f in ai_dir.iterdir() if f.is_file()]
                status["ai_files"] = ai_files

            return json.dumps(status, indent=2)

        except Exception as e:
            return json.dumps({"error": str(e), "repo": str(repo)})

    return mcp


def run_stdio() -> None:
    """Run MCP server with stdio transport (for Claude Code)."""
    mcp = create_mcp_server()
    mcp.run(transport="stdio")


def run_http(port: int = 8765) -> None:
    """Run MCP server with HTTP/SSE transport."""
    mcp = create_mcp_server()
    mcp.run(transport="sse", port=port)