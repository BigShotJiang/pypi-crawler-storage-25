"""
LAO Benchmark.

Compares what a cloud agent would consume without LAO
vs. what LAO actually sends.

Shows concrete dollar savings to make the ROI tangible.

Usage:
    lao bench
    lao bench --repo ./my-repo
    lao bench --model gpt-4o
    lao bench --tasks 20
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# ─── Model pricing (USD per 1M input tokens, April 2026) ─────────────────────
# Update periodically — not meant to be exact, meant to be illustrative.

MODEL_PRICING: dict[str, float] = {
    "claude-sonnet":    3.00,
    "claude-haiku":     0.25,
    "claude-opus":     15.00,
    "gpt-4o":           2.50,
    "gpt-4o-mini":      0.15,
    "gemini-1.5-pro":   1.25,
    "gemini-1.5-flash": 0.075,
}

DEFAULT_MODEL = "claude-sonnet"


@dataclass
class BenchResult:
    repo_name: str
    repo_total_tokens: int
    pack_tokens: int
    files_total: int
    files_selected: int
    model: str
    tasks_per_day: int

    @property
    def tokens_saved(self) -> int:
        return max(0, self.repo_total_tokens - self.pack_tokens)

    @property
    def pct_filtered(self) -> float:
        if self.repo_total_tokens == 0:
            return 0.0
        return (self.tokens_saved / self.repo_total_tokens) * 100

    @property
    def files_pct_filtered(self) -> float:
        if self.files_total == 0:
            return 0.0
        return ((self.files_total - self.files_selected) / self.files_total) * 100

    @property
    def cost_per_1m(self) -> float:
        return MODEL_PRICING.get(self.model, MODEL_PRICING[DEFAULT_MODEL])

    @property
    def cost_full_per_task(self) -> float:
        return (self.repo_total_tokens / 1_000_000) * self.cost_per_1m

    @property
    def cost_lao_per_task(self) -> float:
        return (self.pack_tokens / 1_000_000) * self.cost_per_1m

    @property
    def savings_per_task(self) -> float:
        return self.cost_full_per_task - self.cost_lao_per_task

    @property
    def savings_per_day(self) -> float:
        return self.savings_per_task * self.tasks_per_day

    @property
    def savings_per_month(self) -> float:
        return self.savings_per_day * 22  # working days

    def one_liner(self) -> str:
        """Shareable one-liner for Twitter/Slack."""
        return (
            f"LAO filtered {self.pct_filtered:.0f}% of {self.repo_name} "
            f"before sending to {self.model}. "
            f"Saving ~${self.savings_per_month:.0f}/month at {self.tasks_per_day} tasks/day. "
            f"#LocalComputeFirst"
        )


def run_bench(
    repo_root: Path,
    model: str = DEFAULT_MODEL,
    tasks_per_day: int = 20,
    sample_task: str = "explain the architecture",
    silent: bool = False,
) -> BenchResult:
    """
    Run a benchmark for a repo.

    Builds or loads index to get repo total tokens.
    Runs a sample lao prep to get pack size.
    Returns BenchResult with cost calculations.
    """
    from lao.config import load_config
    from lao.core.index import LaoIndex
    from lao.core.runner import run_prep
    from lao.models import TaskInput

    config = load_config(repo_root)

    # Get or build index for repo total tokens
    idx = LaoIndex(repo_root)
    if not idx.exists():
        if not silent:
            print("Building index to measure repo size...")
        idx.build(config=config, silent=True)

    stats = idx.stats()
    repo_total_tokens = stats.get("total_tokens_indexed", 0)
    files_total = stats.get("files", 0)

    # Run sample prep
    task_input = TaskInput(
        task=sample_task,
        repo_path=repo_root,
    )
    pack, report, _, _ = run_prep(task_input, config, silent=True)

    return BenchResult(
        repo_name=repo_root.name,
        repo_total_tokens=repo_total_tokens,
        pack_tokens=pack.optimized_token_estimate,
        files_total=files_total,
        files_selected=len(pack.selected_files),
        model=model,
        tasks_per_day=tasks_per_day,
    )