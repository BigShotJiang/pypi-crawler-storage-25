"""
Task classifier.

Rule-based in MVP (no local LLM required).
Classifies task type, difficulty, and privacy level
from free-text task descriptions.

Design: explicit, testable rules. No magic. Every rule has a comment.
"""

from __future__ import annotations

import re
from typing import NamedTuple

from lao.models import Difficulty, PrivacyLevel, TaskClassification, TaskType


class _Rule(NamedTuple):
    keywords: list[str]
    task_type: TaskType
    difficulty: Difficulty


# ─── Classification rules ─────────────────────────────────────────────────────
# Order matters: first matching rule wins for task_type.
# Multiple rules can contribute to difficulty escalation.

_TASK_TYPE_RULES: list[_Rule] = [
    # Search / navigation tasks → usually local
    _Rule(
        keywords=["find", "where", "which file", "grep", "list", "show me", "locate",
                  "search for", "what files", "where is"],
        task_type=TaskType.REPO_SEARCH,
        difficulty=Difficulty.LOCAL_OK,
    ),
    # Explain / understand → depends on complexity
    _Rule(
        keywords=["explain", "what does", "how does", "understand", "describe",
                  "what is", "tell me about"],
        task_type=TaskType.CODE_EXPLANATION,
        difficulty=Difficulty.CLOUD_RECOMMENDED,
    ),
    # Bug / failing test → cloud recommended
    _Rule(
        keywords=["fix", "bug", "broken", "failing", "error", "crash", "exception",
                  "not working", "doesn't work", "fail", "debug", "diagnose",
                  "why is", "why does", "broken test", "failing test"],
        task_type=TaskType.BUG_DIAGNOSIS,
        difficulty=Difficulty.CLOUD_RECOMMENDED,
    ),
    # Tests — must come before PATCH so "write tests" hits TEST not PATCH
    _Rule(
        keywords=["write test", "add test", "generate test", "write spec",
                  "unit test", "integration test", "test coverage",
                  "write tests", "add tests", "generate tests"],
        task_type=TaskType.TEST_GENERATION,
        difficulty=Difficulty.CLOUD_RECOMMENDED,
    ),
    # Patch / implement → cloud recommended
    _Rule(
        keywords=["implement", "add", "create", "build", "write", "patch",
                  "change", "update", "modify", "refactor"],
        task_type=TaskType.PATCH_GENERATION,
        difficulty=Difficulty.CLOUD_RECOMMENDED,
    ),
    # Tests (generic — after PATCH so "write" doesn't steal from PATCH)
    _Rule(
        keywords=["test", "tests", "spec", "coverage"],
        task_type=TaskType.TEST_GENERATION,
        difficulty=Difficulty.CLOUD_RECOMMENDED,
    ),
    # Log analysis → local possible but cloud if complex
    _Rule(
        keywords=["log", "logs", "stacktrace", "stack trace", "traceback",
                  "error log", "analyze log", "parse log"],
        task_type=TaskType.LOG_ANALYSIS,
        difficulty=Difficulty.LOCAL_OK,
    ),
    # Architecture → always cloud
    _Rule(
        keywords=["architecture", "design", "structure", "scalab", "refactor",
                  "system design", "pattern", "best practice", "approach"],
        task_type=TaskType.ARCHITECTURE,
        difficulty=Difficulty.CLOUD_REQUIRED,
    ),
]

# ─── Difficulty escalation keywords ───────────────────────────────────────────
# These escalate difficulty regardless of task type.

_ESCALATION_KEYWORDS: list[tuple[list[str], Difficulty]] = [
    (
        ["architecture", "scalable", "scalability", "distributed", "system design",
         "security model", "auth system", "complete rewrite"],
        Difficulty.CLOUD_REQUIRED,
    ),
    (
        ["performance", "optimize", "refactor", "complex", "across multiple",
         "entire codebase", "all files"],
        Difficulty.CLOUD_RECOMMENDED,
    ),
]

# ─── Privacy escalation keywords ──────────────────────────────────────────────

_PRIVACY_KEYWORDS: list[tuple[list[str], PrivacyLevel]] = [
    (
        ["secret", "token", ".env", "api key", "apikey", "wallet", "private key",
         "credential", "password", "auth token", "jwt secret", "signing key"],
        PrivacyLevel.SECRET_RISK,
    ),
    (
        ["billing", "payment", "stripe", "credit card", "customer data",
         "personal data", "pii", "gdpr"],
        PrivacyLevel.INTERNAL_CODE,
    ),
]


def classify_task(task: str) -> TaskClassification:
    """
    Classify a free-text task description.

    Returns TaskClassification with:
    - task_type: Primary category
    - difficulty: Routing recommendation
    - privacy: Data sensitivity level
    - confidence: 0.0–1.0 estimate
    - keywords_extracted: Terms that drove the classification
    - reasoning: Human-readable explanation

    Edge cases:
    - Empty task: handled by TaskInput validation before reaching here
    - All caps task: lowercased for matching
    - Very short task (3-10 chars): returns UNKNOWN with low confidence
    - Contradictory signals: highest difficulty wins
    """
    lowered = task.lower()
    extracted_keywords: list[str] = []
    reasoning_parts: list[str] = []

    # ── Task type + base difficulty ──────────────────────────────────────
    task_type = TaskType.UNKNOWN
    difficulty = Difficulty.LOCAL_OK  # Default: optimistic
    type_confidence = 0.3

    for rule in _TASK_TYPE_RULES:
        matched = [kw for kw in rule.keywords if kw in lowered]
        if matched:
            task_type = rule.task_type
            difficulty = rule.difficulty
            extracted_keywords.extend(matched[:3])  # Top 3 matched keywords
            type_confidence = min(0.4 + 0.1 * len(matched), 0.85)
            reasoning_parts.append(
                f"Matched {rule.task_type.value} keywords: {matched[:3]}"
            )
            break

    # ── Difficulty escalation ────────────────────────────────────────────
    for escalation_keywords, escalated_difficulty in _ESCALATION_KEYWORDS:
        matched = [kw for kw in escalation_keywords if kw in lowered]
        if matched:
            if _difficulty_level(escalated_difficulty) > _difficulty_level(difficulty):
                difficulty = escalated_difficulty
                extracted_keywords.extend(matched[:2])
                reasoning_parts.append(
                    f"Escalated to {escalated_difficulty.value} due to: {matched[:2]}"
                )

    # ── Privacy level ────────────────────────────────────────────────────
    privacy = PrivacyLevel.INTERNAL_CODE  # Default: all code is internal
    for privacy_keywords, privacy_level in _PRIVACY_KEYWORDS:
        matched = [kw for kw in privacy_keywords if kw in lowered]
        if matched:
            privacy = privacy_level
            reasoning_parts.append(
                f"Privacy elevated to {privacy_level.value} due to: {matched[:2]}"
            )
            break

    # ── Confidence adjustment ────────────────────────────────────────────
    # Short tasks have less signal
    if len(task.split()) < 4:
        type_confidence *= 0.7
        reasoning_parts.append("Short task, lower confidence")

    # Very long tasks might have more signal but also more noise
    if len(task.split()) > 30:
        type_confidence = min(type_confidence, 0.8)

    # Deduplicate keywords
    seen: set[str] = set()
    unique_keywords = []
    for kw in extracted_keywords:
        if kw not in seen:
            seen.add(kw)
            unique_keywords.append(kw)

    reasoning = "; ".join(reasoning_parts) if reasoning_parts else "No specific patterns matched"

    return TaskClassification(
        task_type=task_type,
        difficulty=difficulty,
        privacy=privacy,
        confidence=round(type_confidence, 2),
        keywords_extracted=unique_keywords[:8],  # Cap at 8 keywords
        reasoning=reasoning,
    )


def _difficulty_level(d: Difficulty) -> int:
    """Numeric level for comparison. Higher = more cloud needed."""
    return {
        Difficulty.TRIVIAL: 0,
        Difficulty.LOCAL_OK: 1,
        Difficulty.CLOUD_RECOMMENDED: 2,
        Difficulty.CLOUD_REQUIRED: 3,
    }[d]


def extract_keywords_for_search(task: str) -> list[str]:
    """
    Extract search terms from a task description for ripgrep.

    Different from classify_task – this focuses on technical terms
    that are likely to appear in source code.

    Strategy:
    1. Remove common stop words
    2. Extract CamelCase and snake_case identifiers
    3. Keep technical nouns
    4. Deduplicate and sort by length (longer = more specific)
    """
    # Remove common English stop words
    stop_words = {
        "a", "an", "the", "is", "are", "was", "were", "be", "been",
        "have", "has", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "can", "it", "its", "this", "that",
        "these", "those", "in", "on", "at", "to", "for", "of", "and",
        "or", "but", "not", "with", "my", "our", "your", "their",
        "why", "how", "what", "when", "where", "which", "who",
        "me", "us", "them", "him", "her", "i", "we", "you", "they",
        "fix", "find", "show", "get", "make", "add", "help", "need",
        "want", "please", "using", "use", "from", "into", "about",
    }

    lowered = task.lower()

    # Split on non-alphanumeric characters
    raw_words = re.split(r'[^a-zA-Z0-9_\-]+', task)

    # Also extract camelCase parts
    camel_words = []
    for word in raw_words:
        # Split camelCase: "sessionExpiry" → ["session", "Expiry"]
        parts = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)', word)
        camel_words.extend(parts)

    all_words = raw_words + camel_words

    # Filter: not a stop word, not too short, not purely numeric
    keywords = []
    seen: set[str] = set()
    for word in all_words:
        clean = word.lower().strip("_-")
        if (
            clean
            and clean not in stop_words
            and len(clean) >= 3
            and not clean.isdigit()
            and clean not in seen
        ):
            seen.add(clean)
            keywords.append(clean)

    # Sort: longer keywords first (more specific), then alphabetically
    keywords.sort(key=lambda w: (-len(w), w))

    return keywords[:10]  # Cap at 10 search terms
