"""
LAO Repo Mapper.

Generates .ai/ infrastructure from static analysis:
  .ai/manifest.yaml    - stack, entry points, package manager
  .ai/repo-map.yaml    - module/feature → files mapping
  .ai/test-map.yaml    - source file → test file mapping
  .ai/risk-zones.yaml  - sensitive paths and why
  .ai/agent-rules.md   - rules for AI agents working in this repo

Generated files are:
- Human-readable and editable
- Machine-readable by lao prep (speeds up context building)
- Committable to git (other agents benefit immediately)

Design: purely deterministic, no LLM required.
All analysis is static: imports, file structure, naming conventions.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Optional

import yaml

from lao.constants import EXTENSION_TO_LANGUAGE, FRAMEWORK_MARKERS, TEST_RUNNER_MARKERS
from lao.models import FileEntry, ProjectConfig, RepoProfile
from lao.scanner.imports import build_import_scores
from lao.utils.fs import read_text_safe, walk_repo

logger = logging.getLogger(__name__)

AI_DIR = ".ai"


def generate_ai_dir(
    repo_root: Path,
    profile: RepoProfile,
    files: list[FileEntry],
    config: ProjectConfig,
) -> dict[str, Path]:
    """
    Generate .ai/ directory with all mapping files.

    Returns dict of {filename: path} for all written files.
    """
    ai_dir = repo_root / AI_DIR
    ai_dir.mkdir(exist_ok=True)

    written: dict[str, Path] = {}

    # 1. manifest.yaml
    manifest_path = _write_manifest(ai_dir, repo_root, profile, files, config)
    written["manifest.yaml"] = manifest_path

    # 2. repo-map.yaml
    repo_map_path = _write_repo_map(ai_dir, repo_root, files, profile)
    written["repo-map.yaml"] = repo_map_path

    # 3. test-map.yaml
    test_map_path = _write_test_map(ai_dir, files)
    written["test-map.yaml"] = test_map_path

    # 4. risk-zones.yaml
    risk_path = _write_risk_zones(ai_dir, files, config)
    written["risk-zones.yaml"] = risk_path

    # 5. agent-rules.md
    rules_path = _write_agent_rules(ai_dir, profile, config)
    written["agent-rules.md"] = rules_path

    logger.info(f"Generated .ai/ with {len(written)} files at {ai_dir}")
    return written


def _write_manifest(
    ai_dir: Path,
    repo_root: Path,
    profile: RepoProfile,
    files: list[FileEntry],
    config: ProjectConfig,
) -> Path:
    """Generate .ai/manifest.yaml"""

    # Find entry points
    entry_points = _find_entry_points(files, profile)

    # Count files by language
    lang_counts: dict[str, int] = {}
    for f in files:
        if f.language:
            lang_counts[f.language] = lang_counts.get(f.language, 0) + 1

    manifest = {
        "version": "1.0",
        "generated_by": "lao",
        "repo": {
            "name": repo_root.name,
            "framework": profile.framework,
            "primary_language": profile.primary_language,
            "languages": profile.languages[:5],
            "package_manager": profile.package_manager,
            "test_runner": profile.test_runner,
        },
        "entry_points": entry_points,
        "structure": {
            "total_files": profile.total_files_scanned,
            "important_dirs": profile.important_dirs,
            "language_breakdown": lang_counts,
        },
        "ai_hints": {
            "context_strategy": _get_context_strategy(profile),
            "test_command": _get_test_command(profile),
            "install_command": _get_install_command(profile),
        },
    }

    path = ai_dir / "manifest.yaml"
    path.write_text(
        "# LAO Repo Manifest — auto-generated, safe to edit\n"
        + yaml.dump(manifest, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    return path


def _write_repo_map(
    ai_dir: Path,
    repo_root: Path,
    files: list[FileEntry],
    profile: RepoProfile,
) -> Path:
    """
    Generate .ai/repo-map.yaml

    Groups files by top-level module/feature.
    For each module, lists its files and inferred purpose.
    """
    # Group by top-level directory
    modules: dict[str, list[str]] = {}
    root_files: list[str] = []

    for f in files:
        parts = f.relative_path.replace("\\", "/").split("/")
        if len(parts) == 1:
            root_files.append(f.relative_path)
        else:
            module = parts[0]
            modules.setdefault(module, []).append(f.relative_path)

    # Build module descriptions
    module_map: dict[str, dict] = {}
    for module, mod_files in sorted(modules.items()):
        if module in {".lao", ".ai", ".git", "node_modules"}:
            continue

        purpose = _infer_module_purpose(module, mod_files, profile)
        entry = _find_module_entry(module, mod_files)

        module_map[module] = {
            "purpose": purpose,
            "entry": entry,
            "files": sorted(mod_files),
            "file_count": len(mod_files),
        }

    repo_map = {
        "version": "1.0",
        "generated_by": "lao",
        "modules": module_map,
        "root_files": sorted(root_files),
    }

    path = ai_dir / "repo-map.yaml"
    path.write_text(
        "# LAO Repo Map — module/feature to file mapping\n"
        "# Edit 'purpose' fields to improve AI context quality\n"
        + yaml.dump(repo_map, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    return path


def _write_test_map(ai_dir: Path, files: list[FileEntry]) -> Path:
    """
    Generate .ai/test-map.yaml

    Maps source files to their test files.
    """
    test_files = [f for f in files if f.is_test]
    source_files = {f.relative_path for f in files if not f.is_test}

    test_map: dict[str, dict] = {}

    for test_file in test_files:
        source = _find_source_for_test(test_file.relative_path, source_files)
        test_map[test_file.relative_path] = {
            "tests": test_file.relative_path,
            "source": source,
            "language": test_file.language,
        }

    # Reverse: source → tests
    source_to_tests: dict[str, list[str]] = {}
    for test_rel, info in test_map.items():
        if info["source"]:
            source_to_tests.setdefault(info["source"], []).append(test_rel)

    result = {
        "version": "1.0",
        "generated_by": "lao",
        "source_to_tests": source_to_tests,
        "test_files": list(test_map.keys()),
        "untested_sources": [
            f.relative_path for f in files
            if not f.is_test and f.relative_path not in source_to_tests
            and f.language in {"python", "typescript", "javascript"}
            and not f.relative_path.endswith("__init__.py")
        ][:20],  # Cap at 20 to avoid noise
    }

    path = ai_dir / "test-map.yaml"
    path.write_text(
        "# LAO Test Map — source to test file mapping\n"
        + yaml.dump(result, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    return path


def _write_risk_zones(
    ai_dir: Path,
    files: list[FileEntry],
    config: ProjectConfig,
) -> Path:
    """
    Generate .ai/risk-zones.yaml

    Identifies sensitive paths and explains why they're risky.
    """
    from lao.security.policy import check_file_policy
    from lao.models import PolicyDecision

    blocked: list[dict] = []
    warned: list[dict] = []

    for f in files:
        decision = check_file_policy(f.relative_path, config.security)
        reason = _infer_risk_reason(f.relative_path)

        if decision == PolicyDecision.BLOCK:
            blocked.append({
                "path": f.relative_path,
                "reason": reason,
                "action": "never_send_to_cloud",
            })
        elif decision == PolicyDecision.WARN:
            warned.append({
                "path": f.relative_path,
                "reason": reason,
                "action": "review_before_sending",
            })

    risk_zones = {
        "version": "1.0",
        "generated_by": "lao",
        "policy": {
            "blocked": blocked[:20],
            "sensitive": warned[:20],
        },
        "rules": {
            "env_files": "Never send .env* files to cloud agents",
            "private_keys": "Never send *.pem, *.key files to cloud agents",
            "credentials": "Files matching *credential*, *secret* are blocked by default",
            "auth_code": "Auth/billing/payment code is flagged for review",
        },
    }

    path = ai_dir / "risk-zones.yaml"
    path.write_text(
        "# LAO Risk Zones — sensitive paths for AI agents\n"
        "# Blocked files are never sent to cloud agents\n"
        + yaml.dump(risk_zones, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    return path


def _write_agent_rules(
    ai_dir: Path,
    profile: RepoProfile,
    config: ProjectConfig,
) -> Path:
    """
    Generate .ai/agent-rules.md

    Rules for AI agents working in this repo.
    Human-editable, agent-readable.
    """
    framework = profile.framework or "unknown"
    language = profile.primary_language or "unknown"
    test_runner = profile.test_runner or "unknown"
    install_cmd = _get_install_command(profile)
    test_cmd = _get_test_command(profile)

    rules = f"""# Agent Rules for {profile.root.name}

> Auto-generated by LAO. Edit this file to add project-specific rules.
> AI agents should read this file before making changes.

## Stack
- Framework: {framework}
- Language: {language}
- Test runner: {test_runner}
- Package manager: {profile.package_manager or 'unknown'}

## Setup
```bash
{install_cmd}
```

## Running Tests
```bash
{test_cmd}
```

## Rules

### Always
- Run tests before declaring a fix complete
- Keep changes minimal — do not refactor unless asked
- Follow existing code patterns in the file you're editing
- Check `.ai/risk-zones.yaml` before reading sensitive files

### Never
- Send `.env*` files or private keys to cloud context
- Add new dependencies without asking
- Change public API signatures without asking
- Delete files without explicit instruction

### Code Style
- Follow existing patterns in the file you're editing
- Do not add comments unless the code is genuinely complex
- Keep functions small and single-purpose

### Testing
- Every bug fix should have a test that would have caught it
- Test files live in `{_get_test_dir(profile)}`
- Use `{test_runner}` to run tests

## Uncertainty
If you are unsure about:
- Architecture decisions → ask before implementing
- Security implications → flag and ask
- Performance impact → measure, don't guess
"""

    path = ai_dir / "agent-rules.md"
    path.write_text(rules, encoding="utf-8")
    return path


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _find_entry_points(files: list[FileEntry], profile: RepoProfile) -> list[dict]:
    """Find likely entry points based on filename and position."""
    entry_names = {
        "__init__.py", "__main__.py", "main.py", "app.py", "cli.py",
        "index.ts", "index.js", "server.ts", "server.py", "cmd.py",
    }
    entries = []
    for f in files:
        if f.path.name in entry_names:
            depth = f.relative_path.count("/")
            if depth <= 2:
                entries.append({
                    "path": f.relative_path,
                    "type": _infer_entry_type(f.path.name),
                })
    return sorted(entries, key=lambda e: e["path"])


def _infer_entry_type(filename: str) -> str:
    mapping = {
        "__init__.py": "package",
        "__main__.py": "runnable",
        "main.py": "main",
        "app.py": "application",
        "cli.py": "cli",
        "index.ts": "package",
        "index.js": "package",
        "server.ts": "server",
        "server.py": "server",
    }
    return mapping.get(filename, "entry")


def _infer_module_purpose(module: str, files: list[str], profile: RepoProfile) -> str:
    """Infer module purpose from name and contents."""
    name = module.lower()
    purpose_map = {
        "auth": "Authentication and authorization",
        "api": "API endpoints and handlers",
        "cli": "Command-line interface",
        "models": "Data models and schemas",
        "storage": "Data persistence and storage",
        "sync": "Synchronization and merging",
        "security": "Security utilities",
        "tests": "Test suite",
        "utils": "Shared utilities",
        "config": "Configuration",
        "core": "Core business logic",
        "mcp": "MCP server integration",
        "ingest": "Data ingestion",
        "recall": "Memory recall and search",
        "graph": "Graph data structures",
        "render": "Rendering and output",
        "integrations": "Third-party integrations",
        "migration": "Database/format migrations",
        "benchmark": "Performance benchmarks",
        "docs": "Documentation",
        "scripts": "Build and utility scripts",
        "src": "Source code",
        "app": "Application code",
        "lib": "Library code",
        "pkg": "Package code",
        "cmd": "Commands",
        "internal": "Internal packages",
        "components": "UI components",
        "pages": "Page components",
        "hooks": "React hooks",
        "services": "Business services",
        "middleware": "Request middleware",
    }
    return purpose_map.get(name, f"Module: {module}")


def _find_module_entry(module: str, files: list[str]) -> Optional[str]:
    """Find the entry file for a module."""
    priorities = [
        f"{module}/__init__.py",
        f"{module}/index.ts",
        f"{module}/index.js",
        f"{module}/main.py",
        f"{module}/mod.rs",
    ]
    file_set = set(files)
    for p in priorities:
        if p in file_set:
            return p
    return files[0] if files else None


def _find_source_for_test(test_path: str, source_files: set[str]) -> Optional[str]:
    """Map a test file to its source file."""
    import re
    lower = test_path.lower().replace("\\", "/")

    for prefix in ["tests/", "test/", "__tests__/", "spec/"]:
        if lower.startswith(prefix):
            remainder = re.sub(r'\.(test|spec)\.', '.', test_path[len(prefix):])
            remainder = re.sub(r'^test_', '', remainder)
            # Try several source locations
            candidates = [
                remainder,
                f"src/{remainder}",
                f"lib/{remainder}",
                f"app/{remainder}",
            ]
            for c in candidates:
                if c in source_files:
                    return c
    return None


def _infer_risk_reason(path: str) -> str:
    lower = path.lower()
    if ".env" in lower:
        return "Environment variables and secrets"
    if any(x in lower for x in [".pem", ".key", ".p12", "id_rsa", "id_ed25519"]):
        return "Private key or certificate"
    if "credential" in lower or "secret" in lower:
        return "Likely contains credentials"
    if "auth" in lower:
        return "Authentication code — review carefully"
    if any(x in lower for x in ["billing", "payment", "stripe"]):
        return "Payment/billing code"
    if "wallet" in lower:
        return "Wallet or key storage"
    return "Sensitive path"


def _get_context_strategy(profile: RepoProfile) -> str:
    if profile.framework == "nextjs":
        return "Focus on src/app/, src/pages/, src/components/ for feature work"
    if profile.framework in ("django", "fastapi"):
        return "Focus on views, models, urls for feature work"
    if profile.primary_language == "python":
        return "Follow import graph from entry points"
    return "Follow import graph from entry points"


def _get_test_command(profile: RepoProfile) -> str:
    cmds = {
        "vitest": "npx vitest run",
        "jest": "npx jest",
        "pytest": "pytest",
        "cargo-test": "cargo test",
        "go-test": "go test ./...",
    }
    return cmds.get(profile.test_runner or "", "# add test command here")


def _get_install_command(profile: RepoProfile) -> str:
    cmds = {
        "pnpm": "pnpm install",
        "yarn": "yarn install",
        "npm": "npm install",
        "bun": "bun install",
        "poetry": "poetry install",
        "uv": "uv sync",
        "pip": "pip install -e .",
        "cargo": "cargo build",
    }
    return cmds.get(profile.package_manager or "", "# add install command here")


def _get_test_dir(profile: RepoProfile) -> str:
    if profile.test_runner in ("pytest",):
        return "tests/"
    if profile.test_runner in ("vitest", "jest"):
        return "tests/ or __tests__/"
    return "tests/"