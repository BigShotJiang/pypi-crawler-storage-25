"""
Persistent file index for lao.

Stores file metadata, token estimates, and import edges in SQLite.
Eliminates full repo scans on repeated lao prep calls.

Usage:
    index = LaoIndex(repo_root)
    index.build()                    # Full scan
    index.update()                   # Update changed files only
    files = index.load_files()       # Load FileEntry list
    fresh = index.is_fresh()         # Check staleness
"""

from __future__ import annotations

import hashlib
import logging
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Generator, Optional

from lao.constants import (
    EXTENSION_TO_LANGUAGE,
    LAO_DIR,
    MAX_FILE_SIZE_BYTES,
)
from lao.models import FileEntry

logger = logging.getLogger(__name__)

INDEX_FILE = "index.sqlite"
SCHEMA_VERSION = 1
STALENESS_SAMPLE_RATE = 0.10   # Check 10% of files for staleness
STALENESS_THRESHOLD   = 0.20   # If >20% changed → rebuild
MAX_INDEX_AGE_HOURS   = 48     # Warn if index older than this


class LaoIndex:
    """
    SQLite-backed file index for a single repo.

    Thread-safety: not thread-safe. One process at a time.
    """

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root.resolve()
        self.db_path = repo_root / LAO_DIR / INDEX_FILE
        self._conn: Optional[sqlite3.Connection] = None

    # ── Public API ────────────────────────────────────────────────────────

    def exists(self) -> bool:
        return self.db_path.exists()

    def migrate(self) -> None:
        """Run schema migrations on existing DB."""
        if not self.exists():
            return
        try:
            with self._transaction() as conn:
                try:
                    conn.execute("ALTER TABLE runs ADD COLUMN tokens_repo_total INTEGER DEFAULT 0")
                except Exception:
                    pass  # Column already exists
        except Exception:
            pass

    def build(
        self,
        config=None,
        force: bool = False,
        silent: bool = False,
    ) -> dict:
        """
        Build or rebuild the full index.

        Returns stats dict with files_indexed, duration_ms etc.
        """
        from lao.scanner.repo import scan_repo
        from lao.utils.tokens import estimate_tokens
        from lao.utils.fs import read_text_safe
        from lao.scanner.imports import build_import_scores

        if config is None:
            from lao.config import load_config
            config = load_config(self.repo_root)

        start = time.monotonic()
        if not silent:
            logger.info(f"Building index for {self.repo_root}")

        self._ensure_schema()

        # Full repo scan
        profile, files = scan_repo(self.repo_root, config)

        # Index all files
        files_indexed = 0
        with self._transaction() as conn:
            # Clear existing data
            if force:
                conn.execute("DELETE FROM files")
                conn.execute("DELETE FROM import_edges")

            for file_entry in files:
                content = read_text_safe(file_entry.path)
                content_hash = _hash_file(file_entry.path)
                tokens = estimate_tokens(content) if content else 0
                file_entry.size_tokens = tokens
                file_entry.content_hash = content_hash

                conn.execute("""
                    INSERT OR REPLACE INTO files
                    (relative_path, content_hash, size_bytes, size_tokens,
                     language, is_test, is_generated, last_indexed)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    file_entry.relative_path,
                    content_hash,
                    file_entry.size_bytes,
                    tokens,
                    file_entry.language,
                    file_entry.is_test,
                    file_entry.is_generated,
                    _now(),
                ))
                files_indexed += 1

        # Build import edges
        self._index_imports(files, config)
        self._index_symbols(files)

        # Record build time
        elapsed_ms = (time.monotonic() - start) * 1000
        self._set_meta("last_built", _now())
        self._set_meta("schema_version", str(SCHEMA_VERSION))
        self._set_meta("files_count", str(files_indexed))

        if not silent:
            logger.info(f"Index built: {files_indexed} files in {elapsed_ms:.0f}ms")

        return {
            "files_indexed": files_indexed,
            "duration_ms": round(elapsed_ms, 1),
            "db_path": str(self.db_path),
        }

    def update(self, config=None, silent: bool = False) -> dict:
        """
        Update only changed files.

        Detects changes via content hash comparison.
        Removes deleted files from index.
        Returns stats dict.
        """
        from lao.utils.fs import walk_repo
        from lao.utils.tokens import estimate_tokens
        from lao.utils.fs import read_text_safe, should_ignore_dir, should_ignore_file

        if not self.exists():
            return self.build(config=config, silent=silent)

        if config is None:
            from lao.config import load_config
            config = load_config(self.repo_root)

        start = time.monotonic()
        updated = 0
        removed = 0

        # Get all currently indexed paths
        with self._connection() as conn:
            indexed = {
                row[0]: row[1]
                for row in conn.execute("SELECT relative_path, content_hash FROM files")
            }

        # Walk repo and find changes
        current_paths: set[str] = set()
        to_update: list[Path] = []

        for file_path in walk_repo(self.repo_root):
            try:
                rel = str(file_path.relative_to(self.repo_root)).replace("\\", "/")
            except ValueError:
                continue
            current_paths.add(rel)

            new_hash = _hash_file(file_path)
            if indexed.get(rel) != new_hash:
                to_update.append(file_path)

        # Remove deleted files
        deleted = set(indexed.keys()) - current_paths
        if deleted:
            with self._transaction() as conn:
                for rel in deleted:
                    conn.execute("DELETE FROM files WHERE relative_path = ?", (rel,))
                    conn.execute(
                        "DELETE FROM import_edges WHERE source_path = ? OR target_path = ?",
                        (rel, rel)
                    )
            removed = len(deleted)

        # Update changed files
        if to_update:
            from lao.scanner.repo import _is_test_file, _is_generated_file
            with self._transaction() as conn:
                for file_path in to_update:
                    rel = str(file_path.relative_to(self.repo_root)).replace("\\", "/")
                    content = read_text_safe(file_path)
                    content_hash = _hash_file(file_path)
                    tokens = estimate_tokens(content) if content else 0
                    lang = EXTENSION_TO_LANGUAGE.get(file_path.suffix.lower())

                    conn.execute("""
                        INSERT OR REPLACE INTO files
                        (relative_path, content_hash, size_bytes, size_tokens,
                         language, is_test, is_generated, last_indexed)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        rel,
                        content_hash,
                        file_path.stat().st_size if file_path.exists() else 0,
                        tokens,
                        lang,
                        _is_test_file(rel),
                        _is_generated_file(rel),
                        _now(),
                    ))
                    updated += 1

        elapsed_ms = (time.monotonic() - start) * 1000
        self._set_meta("last_updated", _now())

        if not silent:
            logger.info(
                f"Index updated: {updated} changed, {removed} removed "
                f"in {elapsed_ms:.0f}ms"
            )

        return {
            "files_updated": updated,
            "files_removed": removed,
            "duration_ms": round(elapsed_ms, 1),
        }

    def load_files(self) -> list[FileEntry]:
        """Load all FileEntry objects from index."""
        if not self.exists():
            return []

        files: list[FileEntry] = []
        with self._connection() as conn:
            rows = conn.execute("""
                SELECT relative_path, size_bytes, size_tokens,
                       language, is_test, is_generated, content_hash
                FROM files
                ORDER BY relative_path
            """).fetchall()

        for row in rows:
            rel, size_bytes, size_tokens, lang, is_test, is_generated, content_hash = row
            abs_path = self.repo_root / rel
            files.append(FileEntry(
                path=abs_path,
                relative_path=rel,
                size_bytes=size_bytes or 0,
                size_tokens=size_tokens or 0,
                language=lang,
                is_test=bool(is_test),
                is_generated=bool(is_generated),
                content_hash=content_hash or "",
            ))

        return files

    def load_import_edges(self) -> dict[str, list[str]]:
        """Load import graph edges: source → [targets]."""
        if not self.exists():
            return {}

        edges: dict[str, list[str]] = {}
        with self._connection() as conn:
            rows = conn.execute(
                "SELECT source_path, target_path FROM import_edges"
            ).fetchall()

        for source, target in rows:
            edges.setdefault(source, []).append(target)

        return edges

    def is_fresh(self, sample_size: int = 20) -> tuple[bool, str]:
        """
        Check if index is fresh via sampling.

        Returns (is_fresh, reason_string).
        Samples up to sample_size random files and checks hashes.
        """
        if not self.exists():
            return False, "no index"

        # Check age
        last_built = self._get_meta("last_built")
        if last_built:
            try:
                built_ts = datetime.fromisoformat(last_built)
                age_hours = (
                    datetime.now(timezone.utc) - built_ts
                ).total_seconds() / 3600
                if age_hours > MAX_INDEX_AGE_HOURS:
                    return False, f"index is {age_hours:.0f}h old (limit: {MAX_INDEX_AGE_HOURS}h)"
            except ValueError:
                pass

        # Sample files
        with self._connection() as conn:
            rows = conn.execute("""
                SELECT relative_path, content_hash
                FROM files
                ORDER BY RANDOM()
                LIMIT ?
            """, (sample_size,)).fetchall()

        if not rows:
            return False, "empty index"

        changed = 0
        for rel, stored_hash in rows:
            abs_path = self.repo_root / rel
            if not abs_path.exists():
                changed += 1
                continue
            current_hash = _hash_file(abs_path)
            if current_hash != stored_hash:
                changed += 1

        change_rate = changed / len(rows)
        if change_rate > STALENESS_THRESHOLD:
            return False, f"{changed}/{len(rows)} sampled files changed ({change_rate:.0%})"

        return True, f"fresh ({changed}/{len(rows)} changed in sample)"

    def stats(self) -> dict:
        """Return index statistics."""
        if not self.exists():
            return {"exists": False}

        with self._connection() as conn:
            file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
            edge_count = conn.execute("SELECT COUNT(*) FROM import_edges").fetchone()[0]
            lang_rows = conn.execute("""
                SELECT language, COUNT(*) as n
                FROM files
                WHERE language IS NOT NULL
                GROUP BY language
                ORDER BY n DESC
                LIMIT 10
            """).fetchall()
            total_tokens = conn.execute(
                "SELECT SUM(size_tokens) FROM files"
            ).fetchone()[0] or 0

        return {
            "exists": True,
            "files": file_count,
            "import_edges": edge_count,
            "total_tokens_indexed": total_tokens,
            "languages": {lang: count for lang, count in lang_rows},
            "last_built": self._get_meta("last_built"),
            "last_updated": self._get_meta("last_updated"),
            "db_path": str(self.db_path),
            "db_size_kb": round(self.db_path.stat().st_size / 1024, 1),
        }

    # ── Schema ────────────────────────────────────────────────────────────

    def _ensure_schema(self) -> None:
        """Create tables if they don't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._transaction() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS files (
                    relative_path TEXT PRIMARY KEY,
                    content_hash  TEXT NOT NULL,
                    size_bytes    INTEGER DEFAULT 0,
                    size_tokens   INTEGER DEFAULT 0,
                    language      TEXT,
                    is_test       INTEGER DEFAULT 0,
                    is_generated  INTEGER DEFAULT 0,
                    last_indexed  TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS import_edges (
                    source_path TEXT NOT NULL,
                    target_path TEXT NOT NULL,
                    PRIMARY KEY (source_path, target_path)
                );

                CREATE TABLE IF NOT EXISTS runs (
                    run_id       TEXT PRIMARY KEY,
                    task         TEXT NOT NULL,
                    created_at   TEXT NOT NULL,
                    pack_path    TEXT,
                    files_scanned INTEGER DEFAULT 0,
                    files_selected INTEGER DEFAULT 0,
                    tokens_raw   INTEGER DEFAULT 0,
                    tokens_opt   INTEGER DEFAULT 0,
                    tokens_repo_total INTEGER DEFAULT 0,
                    savings_pct  REAL DEFAULT 0,
                    duration_ms  REAL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS symbols (
                    file_path  TEXT NOT NULL,
                    symbol     TEXT NOT NULL,
                    kind       TEXT NOT NULL,
                    line       INTEGER DEFAULT 0,
                    PRIMARY KEY (file_path, symbol)
                );
                CREATE INDEX IF NOT EXISTS idx_symbols_file ON symbols(file_path);
                CREATE INDEX IF NOT EXISTS idx_symbols_symbol ON symbols(symbol);

                CREATE TABLE IF NOT EXISTS meta (
                    key   TEXT PRIMARY KEY,
                    value TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_files_language
                    ON files(language);
                CREATE INDEX IF NOT EXISTS idx_import_source
                    ON import_edges(source_path);
                CREATE INDEX IF NOT EXISTS idx_import_target
                    ON import_edges(target_path);
            """)

    def _index_imports(self, files: list[FileEntry], config) -> None:
        """Build import edges for all files."""
        from lao.scanner.imports import _parse_python_imports, _parse_ts_imports
        from lao.utils.fs import read_text_safe

        all_paths = {f.relative_path for f in files}
        edges: list[tuple[str, str]] = []

        for file_entry in files:
            content = read_text_safe(file_entry.path)
            if not content:
                continue

            suffix = file_entry.path.suffix.lower()
            if suffix == ".py":
                imported = _parse_python_imports(
                    content, file_entry.relative_path, all_paths, self.repo_root
                )
            elif suffix in {".ts", ".tsx", ".js", ".jsx", ".mjs"}:
                imported = _parse_ts_imports(
                    content, file_entry.relative_path, all_paths, self.repo_root
                )
            else:
                continue

            for target in imported:
                if target != file_entry.relative_path:
                    edges.append((file_entry.relative_path, target))

        if edges:
            with self._transaction() as conn:
                conn.execute("DELETE FROM import_edges")
                conn.executemany(
                    "INSERT OR IGNORE INTO import_edges (source_path, target_path) VALUES (?, ?)",
                    edges,
                )
            logger.debug(f"Indexed {len(edges)} import edges")

    def _index_symbols(self, files: list[FileEntry]) -> None:
        """Extract def/class symbols from Python and TypeScript files."""
        import re
        from lao.utils.fs import read_text_safe

        PY_SYM = re.compile(r'^[ \t]*(async[ \t]+)?def[ \t]+(\w+)|^[ \t]*class[ \t]+(\w+)', re.MULTILINE)
        TS_SYM = re.compile(
            r'(?:export[ \t]+)?(?:async[ \t]+)?(?:function[ \t]+(\w+)|class[ \t]+(\w+))',
            re.MULTILINE
        )

        rows: list[tuple[str, str, str, int]] = []

        for file_entry in files:
            suffix = file_entry.path.suffix.lower()
            if suffix not in {".py", ".ts", ".tsx", ".js", ".jsx"}:
                continue

            content = read_text_safe(file_entry.path)
            if not content:
                continue

            pattern = PY_SYM if suffix == ".py" else TS_SYM
            for i, line in enumerate(content.splitlines(), 1):
                for m in pattern.finditer(line):
                    groups = [g for g in m.groups() if g and g not in ("async",)]
                    if not groups:
                        continue
                    symbol = groups[-1]
                    if len(symbol) < 3 or symbol.startswith("_"):
                        continue
                    kind = "class" if "class" in line.lstrip()[:10] else "def"
                    rows.append((file_entry.relative_path, symbol, kind, i))

        if rows:
            with self._transaction() as conn:
                conn.execute("DELETE FROM symbols")
                conn.executemany(
                    "INSERT OR IGNORE INTO symbols (file_path, symbol, kind, line) VALUES (?,?,?,?)",
                    rows,
                )
            logger.debug(f"Indexed {len(rows)} symbols")

    def load_symbols_for_keywords(
        self,
        keywords: list[str],
        min_keyword_len: int = 4,
    ) -> dict[str, float]:
        """
        Find files that contain symbols matching task keywords.
        Returns {file_path: score} where score = number of matching symbols * SYMBOL_BOOST.
        """
        if not self.exists() or not keywords:
            return {}

        scores: dict[str, float] = {}

        try:
            with self._connection() as conn:
                # Check symbols table exists
                tables = {r[0] for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()}
                if "symbols" not in tables:
                    return {}

                rows = conn.execute(
                    "SELECT file_path, symbol FROM symbols"
                ).fetchall()
        except Exception as e:
            logger.debug(f"Symbol lookup failed: {e}")
            return {}

        def _stem(w: str) -> str:
            return w[:-3] if len(w) > 6 else w

        for file_path, symbol in rows:
            sym_lower = symbol.lower()
            for kw in keywords:
                if len(kw) < min_keyword_len:
                    continue
                kw_stem = _stem(kw.lower())
                sym_stem = _stem(sym_lower)
                if kw_stem in sym_lower or sym_stem in kw.lower():
                    scores[file_path] = min(scores.get(file_path, 0.0) + 8.0, 16.0)
                    break

        return scores

    def record_run(self, report) -> None:
        """Store run statistics in index."""
        self.migrate()  # ensure schema up to date
        try:
            with self._transaction() as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO runs
                    (run_id, task, created_at, files_scanned, files_selected,
                     tokens_raw, tokens_opt, tokens_repo_total, savings_pct, duration_ms)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    report.run_id,
                    report.task[:200],
                    _now(),
                    getattr(report, 'repo_files_scanned', 0),
                    getattr(report, 'files_selected', 0),
                    getattr(report, 'raw_token_estimate', 0),
                    getattr(report, 'optimized_token_estimate', 0),
                    getattr(report, 'repo_total_tokens', 0),
                    getattr(report, 'savings_pct', 0),
                    getattr(report, 'duration_ms', 0),
                ))
        except Exception as e:
            logger.debug(f"Could not record run: {e}")

    # ── DB helpers ────────────────────────────────────────────────────────

    @contextmanager
    def _connection(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(str(self.db_path), timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    @contextmanager
    def _transaction(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(str(self.db_path), timeout=10)
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _set_meta(self, key: str, value: str) -> None:
        try:
            with self._transaction() as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                    (key, value)
                )
        except Exception as e:
            logger.debug(f"Could not set meta {key}: {e}")

    def _get_meta(self, key: str) -> Optional[str]:
        try:
            with self._connection() as conn:
                row = conn.execute(
                    "SELECT value FROM meta WHERE key = ?", (key,)
                ).fetchone()
                return row[0] if row else None
        except Exception:
            return None


# ── Helpers ───────────────────────────────────────────────────────────────────

def _hash_file(path: Path) -> str:
    """Fast SHA256 of file content. Returns empty string on error."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()[:16]  # 16 chars is enough for change detection
    except OSError:
        return ""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()