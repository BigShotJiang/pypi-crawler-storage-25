"""
Main orchestrator for `lao prep`.

Coordinates all subsystems in the correct order:
1. Load config
2. Scan repo
3. Classify task + extract keywords
4. Search repo
5. Score files
6. Apply security policy
7. Scan content for secrets
8. Build context pack
9. Write outputs
10. Return report
"""

from __future__ import annotations

import logging
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from lao.config import load_config
from lao.constants import LAO_DIR, RUNS_DIR
from lao.context.builder import build_context_pack
from lao.context.scorer import score_files, select_top_files
from lao.core.classifier import classify_task, extract_keywords_for_search
from lao.exceptions import LaoError
from lao.models import (
    CloudTarget,
    ContextPack,
    Difficulty,
    ProjectConfig,
    RunReport,
    SecurityReport,
    TaskInput,
)
from lao.output.display import print_error, print_info
from lao.output.pack import write_context_pack
from lao.output.report import write_report
from lao.scanner.repo import scan_repo
from lao.scanner.search import search
from lao.scanner.stacktrace import extract_error_paths as parse_stacktrace
from lao.scanner.ai_context import load_ai_context
from lao.core.index import LaoIndex
from lao.security.policy import filter_files_by_policy
from lao.security.scanner import scan_files as scan_for_secrets
from lao.utils.fs import ensure_lao_dir, read_text_safe
from lao.utils.tokens import estimate_tokens

logger = logging.getLogger(__name__)


def run_prep(
    task_input: TaskInput,
    config: Optional[ProjectConfig] = None,
    silent: bool = False,
) -> tuple[ContextPack, RunReport, Path, Path]:
    """
    Run the full prep pipeline.

    Args:
        task_input: The task to prepare context for.
        config: Optional pre-loaded config. If None, loaded from disk.

    Returns:
        (context_pack, run_report, pack_path, report_path)

    Raises:
        LaoError subclasses on recoverable errors.
        Unexpected exceptions propagate to CLI for crash reporting.
    """
    started_at = datetime.now(timezone.utc)
    run_id = str(uuid.uuid4())[:8]
    warnings: list[str] = []

    # ── 1. Config ─────────────────────────────────────────────────────────
    if config is None:
        config = load_config(task_input.repo_path)

    repo_root = config.root
    logger.info(f"[{run_id}] Starting prep: {task_input.task!r}")
    logger.info(f"[{run_id}] Repo root: {repo_root}")

    # ── 2. Scan repo (index-aware) ────────────────────────────────────────
    index = LaoIndex(repo_root)

    if not index.exists():
        # First run: build index silently in background
        if not silent:
            print_info("Building index (first run)...")
        try:
            index.build(config=config, silent=True)
            logger.info(f"[{run_id}] Index built on first run")
        except Exception as e:
            logger.warning(f"[{run_id}] Could not build index: {e}")

    # Check freshness and update if stale
    is_fresh, freshness_reason = index.is_fresh()
    if index.exists() and not is_fresh:
        logger.info(f"[{run_id}] Index stale ({freshness_reason}), updating...")
        try:
            index.update(config=config, silent=True)
        except Exception as e:
            logger.warning(f"[{run_id}] Index update failed: {e}")

    # Load from index if available, else full scan
    if index.exists():
        if not silent:
            print_info("Loading from index...")
        all_files = index.load_files()
        # Still need profile for framework/language detection
        if not silent:
            print_info("Detecting repo profile...")
        repo_profile, _ = scan_repo(repo_root, config)
        # Use indexed file count for accuracy
        repo_profile = repo_profile.model_copy(update={
            "total_files_scanned": len(all_files),
            "total_files_found": len(all_files),
        })
        logger.info(f"[{run_id}] Loaded {len(all_files)} files from index")
    else:
        if not silent:
            print_info("Scanning repository...")
        repo_profile, all_files = scan_repo(repo_root, config)
        logger.info(
            f"[{run_id}] Scanned {repo_profile.total_files_scanned} files "
            f"({repo_profile.scan_duration_ms:.0f}ms)"
        )

    # ── 2b. Load .ai/ context if available ──────────────────────────────
    ai_ctx = load_ai_context(repo_root)
    if ai_ctx.available:
        logger.info(f"[{run_id}] .ai/ context loaded: {ai_ctx.used_files}")
        print_info(f"Using .ai/ context ({', '.join(ai_ctx.used_files)})")

    # ── 3. Classify task + keywords ───────────────────────────────────────
    classification = classify_task(task_input.task)
    search_keywords = extract_keywords_for_search(task_input.task)
    logger.info(
        f"[{run_id}] Classification: {classification.task_type.value}, "
        f"{classification.difficulty.value}, keywords={search_keywords[:5]}"
    )

    # ── 4. Search ─────────────────────────────────────────────────────────
    print_info(f"Searching for: {', '.join(search_keywords[:5])}...")
    matches = []
    if search_keywords:
        try:
            matches = search(
                terms=search_keywords,
                root=repo_root,
                ignored_dirs=list(config.security.cloud_deny),
            )
            logger.info(f"[{run_id}] Search: {len(matches)} matches")
        except Exception as e:
            warnings.append(f"Search failed: {e}")
            logger.warning(f"[{run_id}] Search failed: {e}")

    # ── 5. Extract error paths from extra_context ─────────────────────────
    raw_error_text = task_input.extra_context or ""
    # Also scan task itself for inline stacktrace clues
    if "\n" in task_input.task and "at " in task_input.task:
        raw_error_text = task_input.task + "\n" + raw_error_text
    error_paths = parse_stacktrace(raw_error_text, repo_root=repo_root)
    if error_paths:
        logger.info(f"[{run_id}] Stacktrace: {len(error_paths)} paths: {error_paths[:3]}")

    # ── 5b. Build import graph ────────────────────────────────────────────
    print_info("Building import graph...")
    import_scores: dict[str, float] = {}
    try:
        from lao.scanner.imports import build_import_scores
        all_relative = [f.relative_path for f in all_files]
        matched_paths = {m.file for m in matches}
        seed_files = list(matched_paths | set(error_paths))
        if seed_files:
            import_scores = build_import_scores(
                seed_files=seed_files,
                all_files=all_relative,
                repo_root=repo_root,
                depth=1,
            )
            logger.info(f"[{run_id}] Import graph: {len(import_scores)} files boosted")
    except Exception as e:
        warnings.append(f"Import graph failed: {e}")
        logger.warning(f"[{run_id}] Import graph failed: {e}")

    # ── 6. Score files ────────────────────────────────────────────────────
    print_info("Scoring file relevance...")
    # Build symbol-based boosts from index
    symbol_boosts: dict[str, float] = {}
    try:
        symbol_boosts = index.load_symbols_for_keywords(search_keywords)
        if symbol_boosts:
            logger.info(f"[{run_id}] Symbol boosts: {len(symbol_boosts)} files")
    except Exception as e:
        logger.debug(f"[{run_id}] Symbol lookup failed: {e}")

    # Build .ai/ module boosts
    ai_boosts: dict[str, float] = {}
    if ai_ctx.available:
        ai_boosts = ai_ctx.get_module_boosts(search_keywords)
        if ai_boosts:
            logger.info(f"[{run_id}] .ai/ boosts: {len(ai_boosts)} files boosted")

    scored = score_files(
        files=all_files,
        matches=matches,
        task_keywords=search_keywords,
        error_paths=error_paths,
        semantic_scores={},  # Phase 2: embeddings
        repo_profile=repo_profile,
        config=config.limits,
        import_scores=import_scores,
        ai_boosts=ai_boosts,
        symbol_scores={},  # disabled until specificity filter works
    )

    # ── 7. Apply security policy ──────────────────────────────────────────
    all_relative_paths = [sf.file.relative_path for sf in scored]
    allowed_paths, warned_paths, blocked_paths = filter_files_by_policy(
        relative_paths=all_relative_paths,
        config=config.security,
        interactive=False,
    )

    # Filter scored list to only allowed paths
    allowed_set = set(allowed_paths)
    scored_allowed = [sf for sf in scored if sf.file.relative_path in allowed_set]

    # Select top files within budget
    selected = select_top_files(scored_allowed, config.limits)
    logger.info(f"[{run_id}] Selected {len(selected)} files for context")

    # ── 8. Scan selected files for secrets ────────────────────────────────
    print_info("Scanning for secrets...")
    file_contents: list[tuple[str, str]] = []
    for sf in selected:
        content = read_text_safe(sf.file.path)
        if content:
            file_contents.append((sf.file.relative_path, content))

    security_report = scan_for_secrets(file_contents)
    security_report.files_blocked = blocked_paths
    security_report.files_warned = warned_paths
    logger.info(
        f"[{run_id}] Security: {len(security_report.secrets_found)} secrets, "
        f"{len(blocked_paths)} blocked"
    )

    # ── 9. Build context pack ─────────────────────────────────────────────
    print_info("Building context pack...")
    context_pack = build_context_pack(
        task=task_input.task,
        classification=classification,
        repo_profile=repo_profile,
        selected_files=selected,
        security_report=security_report,
        config=config.limits,
        all_file_paths=[f.relative_path for f in all_files],
    )

    # ── 10. Routing recommendation ────────────────────────────────────────
    recommended_target, recommended_model = _compute_routing(
        classification, context_pack, config
    )

    # ── 11. Build run report ──────────────────────────────────────────────
    finished_at = datetime.now(timezone.utc)
    duration_ms = (
        (finished_at - started_at).total_seconds() * 1000
    )

    run_report = RunReport(
        run_id=run_id,
        task=task_input.task,
        started_at=started_at,
        finished_at=finished_at,
        duration_ms=round(duration_ms, 1),
        cloud_recommended=recommended_target != CloudTarget.NONE,
        recommended_target=recommended_target,
        recommended_model=recommended_model,
        warnings=warnings,
    )

    # ── 12. Write outputs ─────────────────────────────────────────────────
    lao_dir = ensure_lao_dir(repo_root)
    run_dir = lao_dir / RUNS_DIR / _run_dir_name(run_id, task_input.task)
    run_dir.mkdir(parents=True, exist_ok=True)

    pack_path = write_context_pack(context_pack, run_report, run_dir)
    report_path = write_report(run_report, context_pack, run_dir)

    # Also write to .lao/ root for easy access
    latest_pack = lao_dir / "context-pack.md"
    latest_report = lao_dir / "report.json"
    import shutil
    shutil.copy2(pack_path, latest_pack)
    shutil.copy2(report_path, latest_report)

    logger.info(
        f"[{run_id}] Done in {duration_ms:.0f}ms. "
        f"Pack: {context_pack.optimized_token_estimate} tokens "
        f"({run_report.savings_pct:.0f}% reduction)"
    )

    # Record run in index — include repo total for accurate savings calc
    try:
        idx_stats = index.stats()
        run_report.repo_total_tokens = idx_stats.get("total_tokens_indexed", 0)
        index.record_run(run_report)
    except Exception:
        pass

    return context_pack, run_report, pack_path, report_path


def _extract_error_paths(extra_context: str) -> list[str]:
    """
    Extract file paths from stacktraces/error output in extra_context.

    Looks for patterns like:
    - "at src/auth/session.ts:42"
    - "File 'src/auth/session.ts', line 42"
    - "in src/auth/session.ts"
    """
    import re

    paths: list[str] = []
    if not extra_context:
        return paths

    # TypeScript/JS stacktrace
    ts_pattern = re.compile(r'(?:at\s+\S+\s+\()?([a-zA-Z0-9_\-./]+\.[a-z]{1,6}):\d+')
    # Python traceback
    py_pattern = re.compile(r'File ["\']([^"\']+)["\']')
    # Generic
    generic_pattern = re.compile(r'([a-zA-Z0-9_\-./]+\.[a-z]{1,6}):\d+')

    seen: set[str] = set()
    for pattern in [ts_pattern, py_pattern, generic_pattern]:
        for match in pattern.finditer(extra_context):
            path = match.group(1).strip()
            # Filter noise: must look like a source file
            if (
                path not in seen
                and len(path) > 3
                and "/" in path
                and not path.startswith("node_modules")
                and not path.startswith("http")
            ):
                seen.add(path)
                paths.append(path)

    return paths[:20]  # Cap at 20 error paths


def _compute_routing(
    classification,
    pack: ContextPack,
    config: ProjectConfig,
) -> tuple[CloudTarget, Optional[str]]:
    """Determine routing recommendation."""
    from lao.models import Difficulty, PrivacyLevel

    # Security override: local only
    if classification.privacy == PrivacyLevel.LOCAL_ONLY:
        return CloudTarget.NONE, None

    # Blocked by policy
    if not config.cloud.enabled:
        return CloudTarget.NONE, None

    diff = classification.difficulty
    if diff == Difficulty.TRIVIAL:
        return CloudTarget.LOCAL_MODEL, "local-model"
    elif diff == Difficulty.LOCAL_OK:
        if classification.confidence >= config.routing.confidence_threshold:
            return CloudTarget.LOCAL_MODEL, "local-model"
        return CloudTarget.CLOUD_CHEAP, "claude-haiku"
    elif diff == Difficulty.CLOUD_RECOMMENDED:
        return CloudTarget.CLOUD_STANDARD, "claude-sonnet"
    else:  # CLOUD_REQUIRED
        return CloudTarget.CLOUD_STRONG, "claude-sonnet"


def _run_dir_name(run_id: str, task: str) -> str:
    """Generate a filesystem-safe run directory name."""
    import re
    from datetime import datetime

    date = datetime.now().strftime("%Y%m%d-%H%M%S")
    # Take first 4 words of task, sanitize
    words = re.sub(r'[^a-zA-Z0-9\s]', '', task).split()[:4]
    slug = "-".join(w.lower() for w in words if w)
    slug = slug[:40] or "task"
    return f"{date}-{run_id}-{slug}"