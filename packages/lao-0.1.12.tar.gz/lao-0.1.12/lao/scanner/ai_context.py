"""
.ai/ context reader.

Reads .ai/manifest.yaml and .ai/repo-map.yaml to provide
pre-computed signals that boost file scoring in lao prep.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

AI_DIR = ".ai"


class AiContext:
    def __init__(self) -> None:
        self.available = False
        self.entry_points: list[str] = []
        self.module_map: dict[str, dict] = {}
        self.used_files: list[str] = []

    def get_module_boosts(
        self,
        task_keywords: list[str],
        boost_per_file: float = 5.0,
        max_boost: float = 10.0,
    ) -> dict[str, float]:
        if not self.module_map or not task_keywords:
            return {}

        def _stem(w: str) -> str:
            return w[:-3] if len(w) > 6 else w

        # Score each module against keywords
        module_scores: list[tuple[str, int, list[str]]] = []

        for module_name, module_info in self.module_map.items():
            purpose = str(module_info.get("purpose", "")).lower()
            module_lower = module_name.lower()
            files = module_info.get("files", [])
            if not files:
                continue

            match_count = 0
            for kw in task_keywords:
                if len(kw) < 3:
                    continue
                kw_lower = kw.lower()
                kw_stem = _stem(kw_lower)

                if kw_stem in module_lower or kw_lower in module_lower:
                    match_count += 1
                    continue
                if kw_stem in purpose or kw_lower in purpose:
                    match_count += 1
                    continue
                for f in files:
                    fname = Path(f).stem.lower()
                    if kw_stem in fname or kw_lower in fname:
                        match_count += 1
                        break

            if match_count > 0:
                module_scores.append((module_name, match_count, files))

        if not module_scores:
            return {}

        # Specificity filter: if more than half of all modules match,
        # the keywords are too generic for this repo — skip boosting
        total_modules = len(self.module_map)
        if len(module_scores) > max(2, total_modules * 0.3):
            logger.debug(
                f"ai_context: {len(module_scores)}/{total_modules} modules matched "
                f"— too generic, skipping boosts"
            )
            return {}

        # Apply boosts to matched modules only
        boosts: dict[str, float] = {}
        for module_name, match_count, files in module_scores:
            file_boost = min(match_count * boost_per_file, max_boost)
            for f in files:
                boosts[f] = min(boosts.get(f, 0.0) + file_boost, max_boost)
            logger.debug(
                f"repo-map boost: '{module_name}' +{file_boost:.1f} "
                f"→ {len(files)} files"
            )

        return boosts


def load_ai_context(repo_root: Path) -> AiContext:
    ctx = AiContext()
    ai_dir = repo_root / AI_DIR

    if not ai_dir.exists() or not ai_dir.is_dir():
        return ctx

    manifest_path = ai_dir / "manifest.yaml"
    if manifest_path.exists():
        try:
            import yaml
            data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                entry_points = data.get("entry_points", [])
                if isinstance(entry_points, list):
                    ctx.entry_points = [
                        ep["path"] for ep in entry_points
                        if isinstance(ep, dict) and "path" in ep
                    ]
                ctx.used_files.append("manifest.yaml")
        except Exception as e:
            logger.debug(f"Could not load .ai/manifest.yaml: {e}")

    repo_map_path = ai_dir / "repo-map.yaml"
    if repo_map_path.exists():
        try:
            import yaml
            data = yaml.safe_load(repo_map_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                modules = data.get("modules", {})
                if isinstance(modules, dict):
                    ctx.module_map = modules
                ctx.used_files.append("repo-map.yaml")
        except Exception as e:
            logger.debug(f"Could not load .ai/repo-map.yaml: {e}")

    ctx.available = len(ctx.used_files) > 0

    if ctx.available:
        logger.debug(
            f"Loaded .ai/ context: {len(ctx.entry_points)} entry points, "
            f"{len(ctx.module_map)} modules"
        )

    return ctx
