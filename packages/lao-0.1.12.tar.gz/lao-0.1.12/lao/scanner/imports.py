"""
Static import graph analyzer.

For each seed file (already scored > 0), parse its imports and
give referenced files an import_reference bonus.

Supports:
  - Python:     from x.y import z  /  import x.y  /  from .relative import z
  - TypeScript: import { X } from './path'  /  import type { Y } from '../path'
  - JavaScript: same as TypeScript

No AST required — regex is sufficient and 10-100x faster to install.

Design:
  - Depth 1 by default (direct imports only)
  - Depth 2 optional via config
  - Precision over recall: only count imports that resolve to actual files
  - Returns dict[relative_path -> score_contribution]
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ─── Regex patterns ───────────────────────────────────────────────────────────

# Python: from package.module import X
# Python: from .relative import X
# Python: import package.module
_PY_FROM_IMPORT = re.compile(
    r'^\s*from\s+(\.{0,3}[\w.]*)\s+import\s+', re.MULTILINE
)
_PY_IMPORT = re.compile(
    r'^\s*import\s+([\w.]+)', re.MULTILINE
)

# TypeScript/JavaScript:
# import { X } from './path'
# import X from '../path'
# import type { X } from './path'
# export { X } from './path'
_TS_IMPORT = re.compile(
    r'''(?:import|export)(?:\s+type)?\s+(?:{[^}]*}|\*\s+as\s+\w+|\w+)?\s*'''
    r'''(?:,\s*(?:{[^}]*}|\w+))?\s*from\s+['"]([^'"]+)['"]''',
    re.MULTILINE,
)
# Also catch: import './side-effect'
_TS_SIDE_EFFECT = re.compile(
    r'''import\s+['"]([^'"]+)['"]''',
    re.MULTILINE,
)


def build_import_scores(
    seed_files: list[str],          # relative paths with score > 0
    all_files: list[str],           # all relative paths in repo
    repo_root: Path,
    depth: int = 1,
    bonus_per_reference: float = 3.0,
    max_bonus: float = 15.0,
) -> dict[str, float]:
    """
    Build import reference scores.

    Args:
        seed_files: Files already considered relevant (score > 0).
        all_files:  Full file inventory for resolution.
        repo_root:  Absolute path to repo root.
        depth:      How many hops to follow (1 = direct, 2 = transitive).
        bonus_per_reference: Score added per reference.
        max_bonus:  Cap per file.

    Returns:
        dict mapping relative_path → import_bonus score.
        Only contains files that were actually imported.
    """
    # Build lookup sets for fast resolution
    all_files_set = set(all_files)
    # Index by filename for ambiguous resolution
    by_filename: dict[str, list[str]] = {}
    for f in all_files:
        name = Path(f).name
        by_filename.setdefault(name, []).append(f)

    scores: dict[str, float] = {}
    visited: set[str] = set()

    # BFS over depth levels
    current_level = set(seed_files)

    for _ in range(depth):
        next_level: set[str] = set()

        for rel_path in current_level:
            if rel_path in visited:
                continue
            visited.add(rel_path)

            abs_path = repo_root / rel_path
            if not abs_path.exists():
                continue

            # Read content
            try:
                content = abs_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            # Parse imports based on language
            suffix = abs_path.suffix.lower()
            if suffix == ".py":
                imported = _parse_python_imports(content, rel_path, all_files_set, repo_root)
            elif suffix in {".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"}:
                imported = _parse_ts_imports(content, rel_path, all_files_set, repo_root)
            else:
                continue

            for imp_rel in imported:
                if imp_rel == rel_path:
                    continue  # No self-references
                if imp_rel in seed_files:
                    continue  # Already in seed, no need to boost

                scores[imp_rel] = min(
                    scores.get(imp_rel, 0.0) + bonus_per_reference,
                    max_bonus,
                )
                next_level.add(imp_rel)

        current_level = next_level - visited

    logger.debug(f"Import graph: {len(scores)} files got import bonus from {len(seed_files)} seeds")
    return scores


def _parse_python_imports(
    content: str,
    source_rel: str,
    all_files: set[str],
    repo_root: Path,
) -> list[str]:
    """
    Parse Python import statements and resolve to relative file paths.

    Handles:
    - `from package.submodule import X` → package/submodule.py or package/submodule/__init__.py
    - `from .relative import X` → relative to source file's package
    - `import package.submodule` → package/submodule.py
    """
    resolved: list[str] = []
    source_dir = Path(source_rel).parent

    # Collect all module paths from imports
    module_refs: list[tuple[str, bool]] = []  # (module_path, is_relative)

    for m in _PY_FROM_IMPORT.finditer(content):
        module = m.group(1)
        is_relative = module.startswith(".")
        module_refs.append((module, is_relative))

    for m in _PY_IMPORT.finditer(content):
        module_refs.append((m.group(1), False))

    for module, is_relative in module_refs:
        resolved_path = _resolve_python_module(
            module, is_relative, source_dir, all_files
        )
        if resolved_path:
            resolved.append(resolved_path)

    return resolved


def _resolve_python_module(
    module: str,
    is_relative: bool,
    source_dir: Path,
    all_files: set[str],
) -> Optional[str]:
    """
    Resolve a Python module string to a relative file path.

    Returns None if the module can't be resolved to a file in the repo
    (e.g. stdlib, third-party packages).
    """
    if is_relative:
        # Count leading dots for relative level
        dots = len(module) - len(module.lstrip("."))
        module_part = module.lstrip(".")

        # Navigate up by (dots - 1) levels from source_dir
        base = source_dir
        for _ in range(max(0, dots - 1)):
            base = base.parent

        if module_part:
            candidate_base = base / Path(module_part.replace(".", "/"))
        else:
            candidate_base = base
    else:
        # Absolute import: try as top-level package
        candidate_base = Path(module.replace(".", "/"))

    # Try: module.py, module/__init__.py
    candidates = [
        str(candidate_base) + ".py",
        str(candidate_base / "__init__.py"),
    ]

    for c in candidates:
        normalized = c.replace("\\", "/")
        if normalized in all_files:
            return normalized

    return None


def _parse_ts_imports(
    content: str,
    source_rel: str,
    all_files: set[str],
    repo_root: Path,
) -> list[str]:
    """
    Parse TypeScript/JavaScript import statements and resolve to file paths.

    Handles:
    - Relative: './session', '../auth/session', './models/index'
    - Skips: node_modules, absolute non-relative paths

    Does NOT handle:
    - Path aliases (@ aliases require tsconfig.json parsing — Phase 2)
    - Dynamic imports: import('./path') — regex would be too noisy
    """
    resolved: list[str] = []
    source_dir = Path(source_rel).parent

    import_paths: set[str] = set()
    for m in _TS_IMPORT.finditer(content):
        import_paths.add(m.group(1))
    for m in _TS_SIDE_EFFECT.finditer(content):
        import_paths.add(m.group(1))

    for imp_path in import_paths:
        # Only follow relative imports (start with . or ..)
        if not imp_path.startswith("."):
            continue

        resolved_path = _resolve_ts_import(imp_path, source_dir, all_files)
        if resolved_path:
            resolved.append(resolved_path)

    return resolved


def _resolve_ts_import(
    import_path: str,
    source_dir: Path,
    all_files: set[str],
) -> Optional[str]:
    """
    Resolve a relative TypeScript import to a file in the repo.

    TypeScript resolution order:
    1. Exact path (if has extension)
    2. path.ts
    3. path.tsx
    4. path.js
    5. path/index.ts
    6. path/index.tsx
    7. path/index.js
    """
    base = source_dir / import_path
    # Normalize: resolve .. and . components
    try:
        import os
        base_str = os.path.normpath(str(base)).replace("\\", "/").lstrip("/")
    except Exception:
        return None

    # If already has a recognized extension, try directly
    if any(base_str.endswith(ext) for ext in [".ts", ".tsx", ".js", ".jsx"]):
        if base_str in all_files:
            return base_str
        return None

    # Try extensions in order
    for ext in [".ts", ".tsx", ".js", ".jsx"]:
        candidate = base_str + ext
        if candidate in all_files:
            return candidate

    # Try index files
    for ext in [".ts", ".tsx", ".js", ".jsx"]:
        candidate = base_str + "/index" + ext
        if candidate in all_files:
            return candidate

    return None