"""
Repo scanner: builds a RepoProfile by walking the filesystem.

Detects language, framework, package manager, test runner,
and produces a list of FileEntry objects for downstream processing.
"""

from __future__ import annotations

import logging
import time
from collections import Counter
from pathlib import Path
from typing import Optional

from lao.constants import (
    ALWAYS_IGNORE_DIRS,
    DEPENDENCY_FRAMEWORK_MARKERS,
    EXTENSION_TO_LANGUAGE,
    FRAMEWORK_MARKERS,
    MAX_FILES_HARD_LIMIT,
    PACKAGE_MANAGER_MARKERS,
    TEST_RUNNER_MARKERS,
)
from lao.exceptions import RepoScanError, RepoTooLargeError
from lao.models import FileEntry, ProjectConfig, RepoProfile
from lao.utils.fs import is_binary_path, walk_repo

logger = logging.getLogger(__name__)

# Directories likely to contain important source code
IMPORTANT_DIR_NAMES: frozenset[str] = frozenset({
    "src", "app", "lib", "core", "server", "client",
    "api", "pages", "routes", "components", "hooks",
    "utils", "helpers", "services", "models", "store",
    "tests", "test", "__tests__", "spec",
})


def scan_repo(
    root: Path,
    config: ProjectConfig,
) -> tuple[RepoProfile, list[FileEntry]]:
    """
    Scan a repo and return (RepoProfile, list[FileEntry]).

    The FileEntry list is the full inventory of scannable files.
    Downstream modules (scorer, search) work from this list.

    Raises:
        RepoScanError: Root doesn't exist or isn't a directory.
        RepoTooLargeError: File count exceeds hard limit.
    """
    if not root.exists():
        raise RepoScanError(f"Repo root does not exist: {root}")
    if not root.is_dir():
        raise RepoScanError(f"Repo root is not a directory: {root}")

    start_ms = time.monotonic() * 1000

    # First pass: find marker files for framework/tooling detection
    # We do a shallow walk (depth 2) just for markers
    markers_found = _find_markers(root)
    framework = _detect_framework(markers_found)
    if not framework:
        framework = _detect_framework_from_deps(root)
    package_manager = _detect_package_manager(markers_found)
    test_runner = _detect_test_runner(markers_found)

    # Second pass: full file inventory
    files: list[FileEntry] = []
    lang_counter: Counter[str] = Counter()
    important_dirs: set[str] = set()
    total_found = 0

    try:
        for file_path in walk_repo(root, max_depth=config.limits.max_file_tokens):
            total_found += 1

            if total_found > MAX_FILES_HARD_LIMIT:
                raise RepoTooLargeError(total_found, MAX_FILES_HARD_LIMIT)

            try:
                relative = file_path.relative_to(root)
            except ValueError:
                continue  # Symlink escaped root — skip

            relative_str = str(relative).replace("\\", "/")

            # Track important dirs from top-level
            top_level_dir = relative.parts[0] if len(relative.parts) > 1 else None
            if top_level_dir and top_level_dir in IMPORTANT_DIR_NAMES:
                important_dirs.add(top_level_dir)

            # Language detection — exclude doc/test dirs from primary language count
            # so repos like FastAPI (mostly docs) get correct primary language
            lang = EXTENSION_TO_LANGUAGE.get(file_path.suffix.lower())
            if lang:
                top = relative.parts[0] if relative.parts else ""
                if top not in {"docs", "doc", "documentation", "docs_src",
                               "tests", "test", "__tests__", "spec", ".github"}:
                    lang_counter[lang] += 1

            # File metadata
            try:
                size_bytes = file_path.stat().st_size
            except OSError:
                size_bytes = 0

            is_test = _is_test_file(relative_str)
            is_generated = _is_generated_file(relative_str)

            entry = FileEntry(
                path=file_path,
                relative_path=relative_str,
                size_bytes=size_bytes,
                language=lang,
                is_test=is_test,
                is_generated=is_generated,
            )
            files.append(entry)

    except RepoTooLargeError:
        raise
    except Exception as e:
        raise RepoScanError(f"Error scanning repo at {root}: {e}") from e

    # Build language list sorted by frequency
    languages = [lang for lang, _ in lang_counter.most_common()]
    primary_language = languages[0] if languages else None

    elapsed_ms = (time.monotonic() * 1000) - start_ms

    profile = RepoProfile(
        root=root,
        languages=languages,
        primary_language=primary_language,
        framework=framework,
        package_manager=package_manager,
        test_runner=test_runner,
        important_dirs=sorted(important_dirs),
        ignored_dirs=sorted(ALWAYS_IGNORE_DIRS),
        total_files_found=total_found,
        total_files_scanned=len(files),
        scan_duration_ms=round(elapsed_ms, 1),
    )

    logger.debug(
        f"Scanned {len(files)} files in {elapsed_ms:.0f}ms. "
        f"Framework: {framework}, Lang: {primary_language}"
    )

    return profile, files


def _find_markers(root: Path) -> set[str]:
    """
    Find framework/tooling marker filenames in the repo root (depth 0-1 only).
    Returns a set of found filenames.
    """
    found: set[str] = set()

    # Check root
    try:
        for entry in root.iterdir():
            if entry.is_file():
                found.add(entry.name)
    except OSError:
        pass

    # Check one level deep
    try:
        for entry in root.iterdir():
            if entry.is_dir() and entry.name not in ALWAYS_IGNORE_DIRS:
                try:
                    for sub in entry.iterdir():
                        if sub.is_file():
                            found.add(sub.name)
                except OSError:
                    pass
    except OSError:
        pass

    return found


def _detect_framework_from_deps(root: Path) -> Optional[str]:
    """Detect framework or package name from config files."""
    import re as _re
    candidates = [
        root / "pyproject.toml",
        root / "requirements.txt",
        root / "requirements-base.txt",
        root / "setup.cfg",
        root / "package.json",
    ]

    package_name = None

    for dep_file in candidates:
        if not dep_file.exists():
            continue
        try:
            text = dep_file.read_text(encoding="utf-8", errors="ignore")
            text_lower = text.lower()

            # Pass 1: known frameworks
            for dep_name, framework in DEPENDENCY_FRAMEWORK_MARKERS:
                dep_lower = dep_name.lower()
                if (
                    f'"{dep_lower}"' in text_lower
                    or f"name = \"{dep_lower}\"" in text_lower
                    or f"{dep_lower}>=" in text_lower
                    or f"{dep_lower}==" in text_lower
                    or f"import {dep_lower}" in text_lower
                ):
                    return framework

            # Pass 2: extract package name
            if package_name is None:
                m = _re.search(r'^name\s*=\s*["\']([ \w-]+)["\'\s]', text, _re.MULTILINE)
                if m:
                    package_name = m.group(1).strip().lower()
                elif dep_file.name == "package.json":
                    m = _re.search(r'"name"\s*:\s*"([^"]+)"', text)
                    if m:
                        package_name = m.group(1).strip().lower()

        except OSError:
            continue

    if package_name and len(package_name) > 1:
        return package_name

    # Fallback: directory name without test/demo suffixes
    dir_name = root.name.lower()
    for suffix in ["-test", "-demo", "-example", "-sample", "-dev", "-local"]:
        if dir_name.endswith(suffix):
            dir_name = dir_name[: -len(suffix)]
    return dir_name if dir_name and dir_name != "." else None

def _detect_framework(markers: set[str]) -> Optional[str]:
    """Return first matching framework, or None."""
    for marker_file, framework in FRAMEWORK_MARKERS:
        if marker_file in markers:
            return framework
    return None


def _detect_package_manager(markers: set[str]) -> Optional[str]:
    """Return first matching package manager, or None."""
    for marker_file, pm in PACKAGE_MANAGER_MARKERS:
        if marker_file in markers:
            return pm
    return None


def _detect_test_runner(markers: set[str]) -> Optional[str]:
    """Return first matching test runner, or None."""
    for marker_file, runner in TEST_RUNNER_MARKERS:
        if marker_file in markers:
            return runner
    return None


def _is_test_file(relative_path: str) -> bool:
    """
    Heuristic: is this file a test file?

    Patterns:
    - Path contains /tests/, /test/, /__tests__/, /spec/
    - Filename contains .test., .spec.
    - Filename starts with test_
    """
    lower = relative_path.lower()
    parts = lower.replace("\\", "/").split("/")

    # Directory indicators
    for part in parts[:-1]:  # All but the filename
        if part in {"tests", "test", "__tests__", "spec", "specs"}:
            return True

    # Filename indicators
    filename = parts[-1]
    if ".test." in filename or ".spec." in filename:
        return True
    if filename.startswith("test_") or filename.startswith("spec_"):
        return True
    if filename.endswith(".test.ts") or filename.endswith(".test.tsx"):
        return True
    if filename.endswith(".spec.ts") or filename.endswith(".spec.tsx"):
        return True

    return False


def _is_generated_file(relative_path: str) -> bool:
    """
    Heuristic: is this file auto-generated?

    Generated files are lower priority in scoring.
    """
    lower = relative_path.lower()

    generated_indicators = [
        ".generated.",
        ".gen.",
        "_generated.",
        "generated/",
        ".d.ts",          # TypeScript declarations
        "_pb2.py",        # Protobuf Python
        ".pb.go",         # Protobuf Go
        ".pb.ts",         # Protobuf TypeScript
        "graphql.ts",     # Often generated
        "schema.prisma",  # Config not generated but low value
    ]

    return any(ind in lower for ind in generated_indicators)