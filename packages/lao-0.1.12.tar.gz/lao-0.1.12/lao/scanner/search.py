"""
Code search: ripgrep wrapper with Python regex fallback.

ripgrep is preferred (10-100x faster). If not installed, falls back
to Python's re module with a warning. Both produce identical SearchMatch output.
"""

from __future__ import annotations

import json
import logging
import re
from functools import lru_cache
from pathlib import Path
from typing import Optional

from lao.constants import (
    ALWAYS_IGNORE_DIRS,
    BINARY_EXTENSIONS,
    MAX_FILE_SIZE_BYTES,
    MAX_SEARCH_OUTPUT_BYTES,
    RIPGREP_TIMEOUT_SECONDS,
)
from lao.exceptions import ExternalToolError, SearchError, ToolNotFoundError
from lao.models import SearchMatch
from lao.utils.process import ProcessResult, find_binary, is_available, run

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def ripgrep_available() -> bool:
    """Check once per process if ripgrep is on PATH."""
    available = is_available("rg")
    if not available:
        logger.warning(
            "ripgrep (rg) not found on PATH. Using slower Python fallback. "
            "Install ripgrep: brew install ripgrep | apt install ripgrep"
        )
    return available


def search(
    terms: list[str],
    root: Path,
    ignored_dirs: Optional[list[str]] = None,
    max_results_per_term: int = 200,
    case_insensitive: bool = True,
    file_glob: Optional[str] = None,
    timeout: float = RIPGREP_TIMEOUT_SECONDS,
) -> list[SearchMatch]:
    """
    Search for terms in a repo. Returns deduplicated SearchMatch list.

    Args:
        terms: Keywords/phrases to search for. Multiple terms are OR'd.
        root: Directory to search in.
        ignored_dirs: Extra directories to exclude.
        max_results_per_term: Cap per search term (not total).
        case_insensitive: If True, search is case-insensitive.
        file_glob: Optional glob pattern to restrict files (e.g. "*.ts").
        timeout: Seconds before search is killed.

    Returns:
        List of SearchMatch, sorted by file then line, deduplicated.

    Raises:
        SearchError: On unexpected failure (not on "no results").
        ValueError: If terms list is empty.
    """
    if not terms:
        raise ValueError("search() requires at least one term")

    clean_terms = [t.strip() for t in terms if t.strip()]
    if not clean_terms:
        raise ValueError("All search terms were empty after stripping")

    all_matches: list[SearchMatch] = []
    seen: set[tuple[str, int]] = set()  # (file, line) deduplication

    for term in clean_terms:
        if ripgrep_available():
            matches = _search_ripgrep(
                term=term,
                root=root,
                ignored_dirs=ignored_dirs or [],
                max_results=max_results_per_term,
                case_insensitive=case_insensitive,
                file_glob=file_glob,
                timeout=timeout,
            )
        else:
            matches = _search_python_fallback(
                term=term,
                root=root,
                ignored_dirs=ignored_dirs or [],
                max_results=max_results_per_term,
                case_insensitive=case_insensitive,
                file_glob=file_glob,
            )

        for m in matches:
            key = (m.file, m.line)
            if key not in seen:
                seen.add(key)
                all_matches.append(m)

    # Sort by file, then line number
    all_matches.sort(key=lambda m: (m.file, m.line))
    return all_matches


def _search_ripgrep(
    term: str,
    root: Path,
    ignored_dirs: list[str],
    max_results: int,
    case_insensitive: bool,
    file_glob: Optional[str],
    timeout: float,
) -> list[SearchMatch]:
    """
    Run ripgrep and parse its JSON output.

    ripgrep exit codes:
    - 0: matches found
    - 1: no matches (not an error)
    - 2: actual error
    """
    args = [
        "rg",
        "--json",                         # Structured output
        "--max-count", str(max_results),  # Per-file limit
        "--max-filesize", "1M",           # Skip huge files
        "--multiline",                    # Handle multiline patterns safely
    ]

    if case_insensitive:
        args.append("--ignore-case")

    # Exclude always-ignored directories
    all_ignored = list(ALWAYS_IGNORE_DIRS) + ignored_dirs
    for d in all_ignored:
        args.extend(["--glob", f"!{d}"])
        args.extend(["--glob", f"!{d}/**"])

    # Exclude binary file extensions
    for ext in BINARY_EXTENSIONS:
        args.extend(["--glob", f"!*{ext}"])

    if file_glob:
        args.extend(["--glob", file_glob])

    args.append(term)
    args.append(str(root))

    result = run(
        args,
        timeout=timeout,
        max_output_bytes=MAX_SEARCH_OUTPUT_BYTES,
    )

    if result.timed_out:
        logger.warning(f"ripgrep timed out after {timeout}s for term '{term}'")
        return []

    if result.returncode == 1:
        return []  # No matches — not an error

    if result.returncode == 2:
        raise ExternalToolError("rg", result.returncode, result.stderr)

    return _parse_ripgrep_json(result.stdout, root)


def _parse_ripgrep_json(output: str, root: Path) -> list[SearchMatch]:
    """
    Parse ripgrep --json output.

    ripgrep emits one JSON object per line. Types include:
    - "begin": file start
    - "match": actual match
    - "end": file end
    - "summary": overall summary

    We only care about "match" lines.
    """
    matches: list[SearchMatch] = []

    for line in output.splitlines():
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        if obj.get("type") != "match":
            continue

        data = obj.get("data", {})

        # File path
        path_obj = data.get("path", {})
        file_path = path_obj.get("text", "")
        if not file_path:
            continue

        # Make relative to root
        try:
            rel = str(Path(file_path).relative_to(root)).replace("\\", "/")
        except ValueError:
            rel = file_path

        # Line number
        line_number = data.get("line_number", 0)

        # Match text (first submatche or full line)
        lines_obj = data.get("lines", {})
        text = lines_obj.get("text", "").rstrip("\n")

        # Column
        submatches = data.get("submatches", [])
        column = submatches[0].get("start", 0) if submatches else 0

        matches.append(SearchMatch(
            file=rel,
            line=line_number,
            column=column,
            text=text,
        ))

    return matches


def _search_python_fallback(
    term: str,
    root: Path,
    ignored_dirs: list[str],
    max_results: int,
    case_insensitive: bool,
    file_glob: Optional[str],
) -> list[SearchMatch]:
    """
    Pure Python fallback search.

    Significantly slower than ripgrep for large repos.
    Used when ripgrep is not installed.
    Emits a debug warning per call (not per term to avoid spam).
    """
    from lao.utils.fs import read_text_safe, walk_repo

    flags = re.IGNORECASE if case_insensitive else 0
    try:
        pattern = re.compile(re.escape(term), flags)
    except re.error as e:
        raise SearchError(f"Invalid search term '{term}': {e}") from e

    matches: list[SearchMatch] = []
    match_count = 0

    for file_path in walk_repo(root, extra_ignore_dirs=ignored_dirs):
        if match_count >= max_results * 10:  # Global cap for fallback
            break

        # Apply file glob filter if specified
        if file_glob:
            import fnmatch
            if not fnmatch.fnmatch(file_path.name, file_glob):
                continue

        content = read_text_safe(file_path, max_bytes=MAX_FILE_SIZE_BYTES)
        if content is None:
            continue

        try:
            rel = str(file_path.relative_to(root)).replace("\\", "/")
        except ValueError:
            rel = str(file_path)

        file_matches = 0
        for line_no, line in enumerate(content.splitlines(), start=1):
            m = pattern.search(line)
            if m:
                matches.append(SearchMatch(
                    file=rel,
                    line=line_no,
                    column=m.start(),
                    text=line.rstrip(),
                ))
                file_matches += 1
                match_count += 1
                if file_matches >= max_results:
                    break

    return matches
