"""
Stacktrace and test output parser v2.

Extracts file paths and line numbers from:
- TypeScript/JavaScript stacktraces
- Python tracebacks
- Vitest/Jest test output
- pytest output
- Go panic output
- Rust panic output

Returns list of (file_path, line_number) sorted by relevance.
Most-specific paths first (deepest in call stack = closest to bug).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional


# ─── Pattern definitions ──────────────────────────────────────────────────────

# TypeScript/JS: "at functionName (src/auth/session.ts:42:5)"
_TS_AT_PATTERN = re.compile(
    r'at\s+(?:[\w.<>$]+\s+)?\(?([a-zA-Z0-9_\-./]+\.[a-z]{1,6}):(\d+)(?::\d+)?\)?'
)

# Python: 'File "src/auth/session.py", line 42'
_PY_FILE_PATTERN = re.compile(
    r'File ["\']([^"\']+)["\'],\s*line\s+(\d+)'
)

# Vitest: "FAIL src/auth/session.test.ts > describe > test name"
_VITEST_FAIL = re.compile(
    r'(?:FAIL|×|✗)\s+([a-zA-Z0-9_\-./]+\.[a-z]{1,6})'
)

# Jest: "● describe › test name" + "at Object.<anonymous> (src/auth.test.ts:42:5)"
_JEST_FAIL = re.compile(
    r'●\s+(.+?)(?:\n|$)'
)

# pytest: "FAILED tests/test_core.py::TestClass::test_method"
_PYTEST_FAIL = re.compile(
    r'FAILED\s+([a-zA-Z0-9_\-./]+\.py)(?:::[^\s]+)?'
)

# pytest: "E  AssertionError" with file context from traceback above
_PYTEST_ERROR_LINE = re.compile(
    r'([a-zA-Z0-9_\-./]+\.py):(\d+):\s+\w+'
)

# Go: "goroutine 1 [running]:\nmain.handler(...)\n\t/path/to/file.go:42"
_GO_PATTERN = re.compile(
    r'\t([a-zA-Z0-9_\-./]+\.go):(\d+)'
)

# Rust: "thread 'main' panicked at 'msg', src/main.rs:42:5"
_RUST_PATTERN = re.compile(
    r"'[^']*',\s*([a-zA-Z0-9_\-./]+\.rs):(\d+)"
)

# Generic: any "path/to/file.ext:linenum" that looks like source
_GENERIC_PATH_LINE = re.compile(
    r'([a-zA-Z0-9_][a-zA-Z0-9_\-./]*/[a-zA-Z0-9_\-./]+\.[a-z]{1,6}):(\d+)'
)

# Node error: "SyntaxError: ... (src/auth.ts:42)"
_NODE_PAREN = re.compile(
    r'\(([a-zA-Z0-9_\-./]+\.[a-z]{1,6}):(\d+)(?::\d+)?\)'
)


def extract_error_paths(
    text: str,
    repo_root: Optional[Path] = None,
) -> list[str]:
    """
    Extract file paths from error output / stacktraces.

    Args:
        text: Raw error text (stacktrace, test output, log).
        repo_root: If given, filter to only paths that exist in repo.

    Returns:
        List of relative file paths, most relevant first.
        Deduped. Noise-filtered (no node_modules, no absolute /usr paths).
    """
    if not text or not text.strip():
        return []

    findings: list[tuple[str, int, int]] = []  # (path, line, relevance_score)

    # Run all parsers, collect (path, line, score)
    _run_parser(_TS_AT_PATTERN, text, findings, score=10)
    _run_parser(_PY_FILE_PATTERN, text, findings, score=10)
    _run_parser(_PYTEST_FAIL, text, findings, score=9, no_line=True)
    _run_parser(_VITEST_FAIL, text, findings, score=9, no_line=True)
    _run_parser(_GO_PATTERN, text, findings, score=10)
    _run_parser(_RUST_PATTERN, text, findings, score=10)
    _run_parser(_NODE_PAREN, text, findings, score=8)
    _run_parser(_PYTEST_ERROR_LINE, text, findings, score=7)
    _run_parser(_GENERIC_PATH_LINE, text, findings, score=5)

    # Dedupe by path, keep highest score
    best: dict[str, tuple[int, int]] = {}  # path → (score, line)
    for path, line, score in findings:
        path = _normalize_error_path(path)
        if not path:
            continue
        existing = best.get(path)
        if existing is None or score > existing[0]:
            best[path] = (score, line)

    # Filter: must look like a real source file
    filtered = {
        path: data for path, data in best.items()
        if _is_valid_source_path(path)
    }

    # If repo_root given, prefer paths that exist
    if repo_root:
        existing = {p for p in filtered if (repo_root / p).exists()}
        if existing:
            filtered = {p: d for p, d in filtered.items() if p in existing}

    # Sort by score desc, then path length asc (shorter = more specific)
    sorted_paths = sorted(
        filtered.keys(),
        key=lambda p: (-filtered[p][0], len(p))
    )

    return sorted_paths[:20]


def _run_parser(
    pattern: re.Pattern,
    text: str,
    findings: list,
    score: int,
    no_line: bool = False,
) -> None:
    """Run a regex pattern and append findings."""
    for m in pattern.finditer(text):
        path = m.group(1).strip()
        line = 0
        if not no_line and m.lastindex and m.lastindex >= 2:
            try:
                line = int(m.group(2))
            except (ValueError, IndexError):
                line = 0
        findings.append((path, line, score))


def _normalize_error_path(path: str) -> str:
    """
    Normalize a path from a stacktrace to a relative repo path.

    Handles:
    - Absolute paths: strip everything up to common source roots
    - Leading ./
    - Windows backslashes
    """
    path = path.replace("\\", "/").strip()

    # Strip leading ./
    if path.startswith("./"):
        path = path[2:]

    # Strip absolute path prefix — find first source-like segment
    if path.startswith("/"):
        # Find common source roots
        for marker in ["/src/", "/app/", "/lib/", "/tests/", "/test/"]:
            idx = path.find(marker)
            if idx >= 0:
                path = path[idx + 1:]
                break
        else:
            # Try to strip up to a recognizable project directory
            parts = path.split("/")
            # Find first part that looks like a source dir
            source_dirs = {"src", "app", "lib", "tests", "test", "cmd", "pkg"}
            for i, part in enumerate(parts):
                if part in source_dirs:
                    path = "/".join(parts[i:])
                    break
            else:
                return ""  # Can't normalize absolute path

    return path


def _is_valid_source_path(path: str) -> bool:
    """Filter out noise from extracted paths."""
    lower = path.lower()

    # Must have an extension
    if "." not in Path(path).name:
        return False

    # Ignore noise
    noise_patterns = [
        "node_modules/",
        ".venv/",
        "venv/",
        "__pycache__/",
        ".git/",
        "/usr/",
        "/home/",
        "site-packages/",
        "dist-packages/",
        ".cache/",
        "webpack",
        "babel",
    ]
    if any(n in lower for n in noise_patterns):
        return False

    # Must look like source code
    source_extensions = {
        ".ts", ".tsx", ".js", ".jsx", ".mjs",
        ".py", ".go", ".rs", ".java", ".kt",
        ".rb", ".php", ".cs", ".cpp", ".c",
        ".swift", ".dart", ".ex", ".exs",
    }
    suffix = Path(path).suffix.lower()
    if suffix not in source_extensions:
        return False

    return True