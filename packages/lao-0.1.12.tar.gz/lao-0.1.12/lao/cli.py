"""
LAO CLI entry point.

Commands:
  lao init           Initialize a lao project
  lao prep <task>    Prepare an evidence pack
  lao show           Show the latest context pack
  lao stats          Show stats from the latest run
  lao check          Check tool availability (ripgrep, gitleaks)
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from lao.constants import VERSION

app = typer.Typer(
    name="lao",
    help="Local preflight for cloud AI coding agents.",
    add_completion=False,
    rich_markup_mode="rich",
)

console = Console()
err_console = Console(stderr=True)


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(levelname)s %(name)s: %(message)s",
    )


# ─── init ─────────────────────────────────────────────────────────────────────

@app.command()
def init(
    path: Annotated[
        Optional[Path],
        typer.Argument(help="Path to initialize. Defaults to current directory."),
    ] = None,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Auto-install missing tools without prompting")] = False,
    no_install: Annotated[bool, typer.Option("--no-install", help="Skip tool installation prompts")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Initialize a lao project and install required tools (ripgrep, gitleaks)."""
    _setup_logging(verbose)
    from lao.config import init_project
    from lao.exceptions import LaoError
    from lao.output.display import print_error, print_success, print_info
    from lao.utils.process import is_available
    from lao.utils.install import install_ripgrep, install_gitleaks, verify_tool

    target = (path or Path.cwd()).resolve()

    try:
        config_path, created = init_project(target)
    except LaoError as e:
        print_error(str(e))
        raise typer.Exit(1)

    if created:
        print_success(f"Initialized lao project at {target}")
    else:
        print_info(f"Project already initialized at {target}")

    console.print()

    # Tool availability check + auto-install
    console.print("[bold]Tool availability:[/bold]")

    # ripgrep
    if is_available("rg"):
        console.print("  ✓ [green]ripgrep[/green]")
    elif no_install:
        console.print("  ✗ [yellow]ripgrep[/yellow] — brew install ripgrep | apt install ripgrep")
    else:
        console.print("  ✗ [yellow]ripgrep[/yellow] — faster search (10-100x)")
        installed = install_ripgrep(interactive=not yes, yes=yes, console=console)
        if not installed:
            console.print("    [dim]Skipped — Python fallback will be used[/dim]")

    # gitleaks
    if is_available("gitleaks") or verify_tool("gitleaks"):
        console.print("  ✓ [green]gitleaks[/green]")
    elif no_install:
        console.print("  ✗ [yellow]gitleaks[/yellow] — https://github.com/gitleaks/gitleaks/releases")
    else:
        console.print("  ✗ [yellow]gitleaks[/yellow] — comprehensive secret scanning")
        installed = install_gitleaks(interactive=not yes, yes=yes, console=console)
        if not installed:
            console.print("    [dim]Skipped — regex fallback will be used[/dim]")

    console.print()
    console.print("Run [bold cyan]lao prep \"your task here\"[/bold cyan] to get started.")
    console.print("Run [bold cyan]lao bench[/bold cyan] to see how much you\'ll save.")


# ─── prep ─────────────────────────────────────────────────────────────────────

@app.command()
def prep(
    task: Annotated[str, typer.Argument(help="Task description to prepare context for.")],
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Repo path. Defaults to current directory."),
    ] = None,
    context: Annotated[
        Optional[str],
        typer.Option("--context", "-c", help="Extra context (e.g. pasted error output)."),
    ] = None,
    output: Annotated[
        Optional[str],
        typer.Option("--output", "-o", help="Output format: markdown (default), json, compact"),
    ] = None,
    no_cloud: Annotated[
        bool,
        typer.Option("--no-cloud", help="Disable cloud context packing."),
    ] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """
    Prepare an evidence pack for a task.

    Examples:

      lao prep "fix failing auth test"

      lao prep "why is my session expiring early" --context "$(cat error.log)"

      lao prep "find where subscription status is set"
    """
    _setup_logging(verbose)

    from lao.core.runner import run_prep
    from lao.exceptions import LaoError, TokenBudgetExceededError
    from lao.models import TaskInput
    from lao.output.display import print_error, print_prep_result, print_warning

    repo_path = (repo or Path.cwd()).resolve()

    try:
        task_input = TaskInput(
            task=task,
            repo_path=repo_path,
            allow_cloud=not no_cloud,
            extra_context=context,
        )
    except Exception as e:
        print_error(f"Invalid task input: {e}")
        raise typer.Exit(1)

    try:
        pack, report, pack_path, report_path = run_prep(task_input)
        # Handle --output flag
        if output in ("json", "compact"):
            from lao.output.compact import render_compact, render_json
            import sys
            if output == "json":
                sys.stdout.write(render_json(pack, report))
            else:
                sys.stdout.write(render_compact(pack, report))
            sys.stdout.write("\n")
        else:
            print_prep_result(pack, report, pack_path, report_path)

        if report.warnings:
            for w in report.warnings:
                print_warning(w)

    except TokenBudgetExceededError as e:
        print_error(
            str(e),
            hint="Try: lao prep ... with a simpler sub-task, or increase "
                 "max_total_context_tokens in .lao/config.yaml",
        )
        raise typer.Exit(1)

    except LaoError as e:
        print_error(str(e))
        if verbose:
            import traceback
            traceback.print_exc()
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n[dim]Interrupted.[/dim]")
        raise typer.Exit(130)


# ─── show ─────────────────────────────────────────────────────────────────────

@app.command()
def show(
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r"),
    ] = None,
) -> None:
    """Show the latest context pack."""
    from lao.config import find_project_root
    from lao.exceptions import LaoError
    from lao.output.display import print_error

    try:
        root = find_project_root(repo or Path.cwd())
        pack_path = root / ".lao" / "context-pack.md"
        if not pack_path.exists():
            print_error(
                "No context pack found.",
                hint="Run 'lao prep \"your task\"' first.",
            )
            raise typer.Exit(1)
        console.print(pack_path.read_text(encoding="utf-8"))
    except LaoError as e:
        print_error(str(e))
        raise typer.Exit(1)


# ─── stats ────────────────────────────────────────────────────────────────────

@app.command()
def stats(
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r"),
    ] = None,
    week: Annotated[bool, typer.Option("--week", "-w", help="Show weekly summary")] = False,
) -> None:
    """Show stats from the latest run, or weekly summary with --week."""
    import json

    from lao.config import find_project_root
    from lao.exceptions import LaoError
    from lao.output.display import print_error
    from lao.utils.tokens import format_token_count

    try:
        root = find_project_root(repo or Path.cwd())
        report_path = root / ".lao" / "report.json"
        if not report_path.exists():
            print_error(
                "No report found.",
                hint="Run 'lao prep \"your task\"' first.",
            )
            raise typer.Exit(1)

        data = json.loads(report_path.read_text(encoding="utf-8"))
    except LaoError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except json.JSONDecodeError as e:
        print_error(f"Could not parse report: {e}")
        raise typer.Exit(1)

    if week:
        from lao.core.index import LaoIndex
        from datetime import datetime, timezone, timedelta
        from lao.core.bench import MODEL_PRICING
        try:
            root = find_project_root(repo or Path.cwd())
            idx = LaoIndex(root)
            if not idx.exists():
                console.print("[dim]No index found. Run 'lao prep' first.[/dim]")
                return
            week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
            with idx._connection() as conn:
                rows = conn.execute("""
                    SELECT COUNT(*) as tasks,
                           SUM(CASE WHEN tokens_repo_total > 0 THEN tokens_repo_total ELSE 0 END) as repo_total,
                           SUM(CASE WHEN tokens_repo_total > 0 THEN tokens_opt ELSE 0 END) as opt_tracked,
                           SUM(files_selected) as files,
                           MAX(created_at) as last_run,
                           COUNT(CASE WHEN tokens_repo_total > 0 THEN 1 END) as tracked_runs
                    FROM runs WHERE created_at > ?
                """, (week_ago,)).fetchone()
            if rows and rows[0]:
                tasks = rows[0] or 0
                repo_total = rows[1] or 0
                opt_tracked = rows[2] or 0
                files = rows[3] or 0
                last_run = rows[4] or "never"
                tracked = rows[5] or 0
                saved = max(0, repo_total - opt_tracked)
                cost_saved = (saved / 1_000_000) * MODEL_PRICING["claude-sonnet"]
                console.print()
                console.rule("[bold]Weekly Summary[/bold]")
                console.print(f"  Tasks prepared:   [cyan]{tasks}[/cyan]")
                console.print(f"  Files selected:   [cyan]{files:,}[/cyan] total")
                console.print(f"  Tokens sent:      [cyan]{format_token_count(opt_tracked)}[/cyan] [dim](tracked runs: {tracked})[/dim]")
                if saved > 0:
                    console.print(f"  Tokens saved:     [cyan]{format_token_count(saved)}[/cyan]")
                    console.print(f"  Est. cost saved:  [bold green]${cost_saved:.2f}[/bold green] [dim](claude-sonnet)[/dim]")
                else:
                    console.print(f"  Tokens saved:     [dim]tracking from next run[/dim]")
                console.print(f"  Last run:         [dim]{str(last_run)[:19]}[/dim]")
                console.print()
            else:
                console.print("[dim]No runs this week. Run 'lao prep' first.[/dim]")
        except Exception as e:
            console.print(f"[yellow]Could not load weekly stats: {e}[/yellow]")
        return

    table = Table(title="Last Run Stats", box=box.ROUNDED)
    table.add_column("Metric", style="cyan")
    table.add_column("Value")

    table.add_row("Run ID", data.get("run_id", "?"))
    table.add_row("Task", (data.get("task", "?"))[:60])
    table.add_row("Files scanned", f"{data.get('repo_files_scanned', 0):,}")
    table.add_row("Files selected", str(data.get("files_selected", 0)))
    table.add_row(
        "Raw tokens",
        format_token_count(data.get("raw_token_estimate", 0)),
    )
    table.add_row(
        "Optimized tokens",
        format_token_count(data.get("optimized_token_estimate", 0)),
    )
    table.add_row("Reduction", f"{data.get('savings_pct', 0):.1f}%")
    table.add_row("Secrets redacted", str(data.get("secrets_redacted", 0)))
    table.add_row("Risk level", data.get("risk_level", "?"))
    table.add_row("Recommended model", data.get("recommended_model") or "none")
    table.add_row("Duration", f"{data.get('duration_ms', 0):.0f}ms")

    console.print(table)


# ─── check ────────────────────────────────────────────────────────────────────

@app.command()
def check() -> None:
    """Check tool availability and configuration."""
    from lao.utils.process import is_available, run

    console.print(f"[bold]lao v{VERSION}[/bold]")
    console.print()

    # Tools
    console.print("[bold]External tools:[/bold]")
    checks = [
        ("rg", "ripgrep", "10-100x faster search"),
        ("gitleaks", "gitleaks", "Comprehensive secret scanning"),
    ]
    for binary, name, desc in checks:
        if is_available(binary):
            try:
                result = run([binary, "--version"], timeout=5)
                version = result.stdout.split("\n")[0].strip()
                console.print(f"  ✓ [green]{name}[/green] ({version})")
            except Exception:
                console.print(f"  ✓ [green]{name}[/green]")
        else:
            console.print(f"  ✗ [yellow]{name}[/yellow] — {desc}")

    console.print()

    # Python packages
    console.print("[bold]Python packages:[/bold]")
    pkg_checks = [
        ("tiktoken", "Token estimation"),
        ("lancedb", "Vector embeddings (optional)"),
        ("sentence_transformers", "Local embeddings (optional)"),
    ]
    for pkg, desc in pkg_checks:
        try:
            __import__(pkg)
            console.print(f"  ✓ [green]{pkg}[/green]")
        except ImportError:
            console.print(f"  ✗ [dim]{pkg}[/dim] — {desc}")


# ─── version ──────────────────────────────────────────────────────────────────

@app.command()
def bench(
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    model: Annotated[str, typer.Option("--model", "-m", help="Model for cost calculation")] = "claude-sonnet",
    tasks: Annotated[int, typer.Option("--tasks", "-t", help="Tasks per day estimate")] = 20,
    share: Annotated[bool, typer.Option("--share", help="Copy shareable one-liner to clipboard")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Benchmark token savings vs. sending full repo to cloud AI."""
    _setup_logging(verbose)
    from lao.core.bench import run_bench, MODEL_PRICING
    from lao.exceptions import LaoError
    from lao.output.display import print_error
    from lao.utils.tokens import format_token_count

    repo_path = (repo or Path.cwd()).resolve()

    if model not in MODEL_PRICING:
        models = ", ".join(MODEL_PRICING.keys())
        print_error(f"Unknown model '{model}'. Available: {models}")
        raise typer.Exit(1)

    console.print()
    console.print(f"[dim]Benchmarking {repo_path.name} against {model}...[/dim]")

    try:
        result = run_bench(repo_path, model=model, tasks_per_day=tasks)
    except LaoError as e:
        print_error(str(e))
        raise typer.Exit(1)

    # ── Display ──────────────────────────────────────────────────────────
    console.print()
    console.rule(f"[bold]LAO Benchmark — {result.repo_name}[/bold]")
    console.print()

    # Repo size
    console.print(f"  [bold]Repo:[/bold]")
    console.print(f"    Files:   {result.files_total:,}")
    console.print(f"    Tokens:  ~{format_token_count(result.repo_total_tokens)}")
    console.print(
        f"    Cost if sent raw:  "
        f"[red]${result.cost_full_per_task:.3f}[/red] per task "
        f"[dim]({model})[/dim]"
    )
    console.print()

    # LAO pack
    console.print(f"  [bold]LAO pack:[/bold]")
    console.print(
        f"    Files sent:    [cyan]{result.files_selected}[/cyan] of {result.files_total:,} "
        f"[dim]({result.files_pct_filtered:.0f}% filtered)[/dim]"
    )
    console.print(
        f"    Tokens sent:   [cyan]{format_token_count(result.pack_tokens)}[/cyan] of "
        f"~{format_token_count(result.repo_total_tokens)} "
        f"[dim]({result.pct_filtered:.0f}% filtered)[/dim]"
    )
    console.print(
        f"    Cost with LAO: [green]${result.cost_lao_per_task:.4f}[/green] per task"
    )
    console.print()

    # Savings
    console.rule("[bold green]Savings[/bold green]")
    console.print()
    console.print(
        f"    Per task:   [bold green]${result.savings_per_task:.3f}[/bold green] saved"
    )
    console.print(
        f"    Per day:    [bold green]${result.savings_per_day:.2f}[/bold green] "
        f"[dim](at {result.tasks_per_day} tasks/day)[/dim]"
    )
    console.print(
        f"    Per month:  [bold green]${result.savings_per_month:.0f}[/bold green] "
        f"[dim](22 working days)[/dim]"
    )
    console.print()

    # One-liner
    one_liner = result.one_liner()
    console.print(f"  [dim]Share:[/dim]")
    console.print(f"  [dim]{one_liner}[/dim]")

    if share:
        try:
            import subprocess
            # Try pbcopy (macOS) then xclip (Linux)
            for cmd in [["pbcopy"], ["xclip", "-selection", "clipboard"], ["xsel", "--clipboard"]]:
                try:
                    proc = subprocess.run(cmd, input=one_liner.encode(), timeout=3)
                    if proc.returncode == 0:
                        console.print(f"  [green]✓ Copied to clipboard[/green]")
                        break
                except (FileNotFoundError, subprocess.TimeoutExpired):
                    continue
        except Exception:
            console.print(f"  [yellow]Could not copy to clipboard[/yellow]")

    console.print()
    console.print(
        f"  [italic dim]Stop paying cloud agents to grep your repo.[/italic dim]"
    )
    console.print()


@app.command(name="index")
def index_cmd(
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    rebuild: Annotated[bool, typer.Option("--rebuild", help="Force full rebuild")] = False,
    update: Annotated[bool, typer.Option("--update", help="Update changed files only")] = False,
    stats: Annotated[bool, typer.Option("--stats", help="Show index statistics")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Build or update the persistent file index for faster lao prep."""
    _setup_logging(verbose)
    from lao.config import load_config
    from lao.core.index import LaoIndex
    from lao.exceptions import LaoError
    from lao.output.display import print_error, print_info, print_success
    from lao.utils.tokens import format_token_count

    repo_path = (repo or Path.cwd()).resolve()

    try:
        config = load_config(repo_path)
    except LaoError as e:
        print_error(str(e))
        raise typer.Exit(1)

    idx = LaoIndex(repo_path)

    if stats:
        s = idx.stats()
        if not s.get("exists"):
            print_error("No index found.", hint="Run 'lao index' to build one.")
            raise typer.Exit(1)
        console.print()
        console.print("[bold]Index stats:[/bold]")
        console.print(f"  Files indexed:    [cyan]{s['files']:,}[/cyan]")
        console.print(f"  Import edges:     [cyan]{s['import_edges']:,}[/cyan]")
        console.print(f"  Total tokens:     [cyan]{format_token_count(s['total_tokens_indexed'])}[/cyan]")
        console.print(f"  Languages:        {', '.join(f'{k}:{v}' for k,v in list(s['languages'].items())[:5])}")
        console.print(f"  Last built:       [dim]{s.get('last_built','unknown')}[/dim]")
        console.print(f"  DB size:          [dim]{s['db_size_kb']:.1f} KB[/dim]")
        console.print(f"  DB path:          [dim]{s['db_path']}[/dim]")
        return

    if update and idx.exists():
        print_info("Updating index (changed files only)...")
        try:
            result = idx.update(config=config)
            print_success(
                f"Index updated: {result['files_updated']} changed, "
                f"{result['files_removed']} removed "
                f"({result['duration_ms']:.0f}ms)"
            )
        except LaoError as e:
            print_error(str(e))
            raise typer.Exit(1)
        return

    print_info("Building index...")
    try:
        result = idx.build(config=config, force=rebuild)
        print_success(
            f"Index built: {result['files_indexed']:,} files "
            f"in {result['duration_ms']:.0f}ms"
        )
        console.print(f"  [dim]{result['db_path']}[/dim]")
    except LaoError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command()
def map(
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r"),
    ] = None,
    force: Annotated[bool, typer.Option("--force", help="Regenerate even if .ai/ exists.")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Generate .ai/ repo infrastructure (manifest, repo-map, test-map, risk-zones, agent-rules)."""
    _setup_logging(verbose)
    from lao.config import load_config
    from lao.scanner.repo import scan_repo
    from lao.core.mapper import generate_ai_dir, AI_DIR
    from lao.exceptions import LaoError
    from lao.output.display import print_error, print_success, print_info

    repo_path = (repo or Path.cwd()).resolve()
    ai_dir = repo_path / AI_DIR

    if ai_dir.exists() and not force:
        existing = list(ai_dir.glob("*"))
        print_info(f".ai/ already exists with {len(existing)} files.")
        print_info("Use --force to regenerate.")
        raise typer.Exit(0)

    try:
        config = load_config(repo_path)
        print_info("Scanning repository...")
        profile, files = scan_repo(repo_path, config)
        print_info("Generating .ai/ infrastructure...")
        written = generate_ai_dir(repo_path, profile, files, config)
    except LaoError as e:
        print_error(str(e))
        raise typer.Exit(1)

    console.print()
    console.print(f"[bold green]✓ Generated .ai/ with {len(written)} files[/bold green]")
    for name, path in written.items():
        console.print(f"  [cyan]{path}[/cyan]")
    console.print()
    console.print("[dim]Commit .ai/ to git so all agents benefit.[/dim]")


# MCP sub-app
mcp_app = typer.Typer(name="mcp", help="MCP server commands.")
app.add_typer(mcp_app)


@mcp_app.command("start")
def mcp_start(
    http: Annotated[
        Optional[int],
        typer.Option("--http", help="Start HTTP/SSE server on this port instead of stdio."),
    ] = None,
) -> None:
    """Start the LAO MCP server.

    Default: stdio transport (for Claude Code).
    With --http PORT: HTTP/SSE transport (for other agents).

    Claude Code config (.claude/settings.json):
    \\{
      "mcpServers": {
        "lao": {
          "command": "uv",
          "args": ["run", "lao", "mcp", "start"]
        }
      }
    \\}
    """
    try:
        from lao.mcp.server import run_stdio, run_http
    except ImportError as e:
        from lao.output.display import print_error
        print_error(f"MCP dependencies missing: {e}", hint="pip install fastmcp")
        raise typer.Exit(1)

    if http:
        console.print(f"[dim]Starting LAO MCP server on HTTP port {http}...[/dim]")
        run_http(port=http)
    else:
        run_stdio()


@mcp_app.command("config")
def mcp_config() -> None:
    """Show MCP configuration for Claude Code and other agents."""
    import json, shutil
    uv_path = shutil.which("uv") or "uv"

    claude_config = {
        "mcpServers": {
            "lao": {
                "command": uv_path,
                "args": ["run", "lao", "mcp", "start"],
                "cwd": str(Path.cwd()),
            }
        }
    }

    console.print()
    console.print("[bold]Claude Code (.claude/settings.json):[/bold]")
    console.print(json.dumps(claude_config, indent=2))
    console.print()
    console.print("[bold]Cursor (.cursor/mcp.json):[/bold]")
    console.print(json.dumps(claude_config, indent=2))
    console.print()
    console.print("[bold]Any MCP client — stdio command:[/bold]")
    console.print(f"  {uv_path} run lao mcp start")
    console.print()
    console.print("[bold]HTTP/SSE (port 8765):[/bold]")
    console.print(f"  {uv_path} run lao mcp start --http 8765")


@app.command()
def version() -> None:
    """Show lao version."""
    console.print(f"lao {VERSION}")


# ─── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app()