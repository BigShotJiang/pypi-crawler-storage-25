"""
Tool auto-installer for lao.

Detects OS and package manager, installs ripgrep and gitleaks
with user confirmation. Never runs silently without consent.

Design principles:
- Always show what command will be run before running it
- Always ask before sudo
- Graceful fallback if installation fails
- Non-interactive mode via --yes flag
- Never fail hard: worst case = tool not installed, use fallback
"""

from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Optional

# ─── GitHub Release URLs ──────────────────────────────────────────────────────

GITLEAKS_VERSION = "8.18.4"
GITLEAKS_RELEASES = {
    "linux_amd64":  f"https://github.com/gitleaks/gitleaks/releases/download/v{GITLEAKS_VERSION}/gitleaks_{GITLEAKS_VERSION}_linux_x64.tar.gz",
    "linux_arm64":  f"https://github.com/gitleaks/gitleaks/releases/download/v{GITLEAKS_VERSION}/gitleaks_{GITLEAKS_VERSION}_linux_arm64.tar.gz",
    "darwin_amd64": f"https://github.com/gitleaks/gitleaks/releases/download/v{GITLEAKS_VERSION}/gitleaks_{GITLEAKS_VERSION}_darwin_x64.tar.gz",
    "darwin_arm64": f"https://github.com/gitleaks/gitleaks/releases/download/v{GITLEAKS_VERSION}/gitleaks_{GITLEAKS_VERSION}_darwin_arm64.tar.gz",
}

RIPGREP_VERSION = "14.1.1"
RIPGREP_DEB_URL = f"https://github.com/BurntSushi/ripgrep/releases/download/{RIPGREP_VERSION}/ripgrep_{RIPGREP_VERSION}-1_amd64.deb"


def detect_os() -> str:
    """Detect operating system. Returns 'macos', 'debian', 'arch', 'fedora', 'unknown'."""
    system = platform.system().lower()
    if system == "darwin":
        return "macos"
    if system == "linux":
        if Path("/etc/debian_version").exists():
            return "debian"
        if Path("/etc/arch-release").exists():
            return "arch"
        if Path("/etc/fedora-release").exists() or Path("/etc/redhat-release").exists():
            return "fedora"
        return "linux"
    return "unknown"


def detect_package_manager() -> str:
    """Detect available package manager."""
    import shutil
    os_type = detect_os()
    if os_type == "macos" and shutil.which("brew"):
        return "brew"
    if os_type == "debian" and shutil.which("apt-get"):
        return "apt"
    if os_type == "arch" and shutil.which("pacman"):
        return "pacman"
    if os_type in ("fedora",) and shutil.which("dnf"):
        return "dnf"
    return "none"


def verify_tool(binary: str) -> bool:
    """Check if a binary is available after installation."""
    import shutil
    # Also check ~/.local/bin which we use for gitleaks
    local_bin = Path.home() / ".local" / "bin" / binary
    return bool(shutil.which(binary)) or local_bin.exists()


def _run_cmd(
    args: list[str],
    description: str,
    console=None,
) -> bool:
    """Run a command, return True on success."""
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            return True
        if console:
            console.print(f"  [red]Failed:[/red] {result.stderr.strip()[:200]}")
        return False
    except subprocess.TimeoutExpired:
        if console:
            console.print("  [red]Timed out[/red]")
        return False
    except FileNotFoundError:
        if console:
            console.print(f"  [red]Command not found:[/red] {args[0]}")
        return False


def install_ripgrep(
    interactive: bool = True,
    yes: bool = False,
    console=None,
) -> bool:
    """
    Install ripgrep. Returns True if successful.

    Args:
        interactive: If True, ask user before running
        yes: If True, skip confirmation (--yes flag)
        console: Rich console for output
    """
    pm = detect_package_manager()
    os_type = detect_os()

    def _print(msg):
        if console:
            console.print(msg)
        else:
            print(msg)

    # Build install command
    if pm == "brew":
        cmd = ["brew", "install", "ripgrep"]
        cmd_str = "brew install ripgrep"
        needs_sudo = False
    elif pm == "apt":
        cmd = ["sudo", "apt-get", "install", "-y", "ripgrep"]
        cmd_str = "sudo apt-get install -y ripgrep"
        needs_sudo = True
    elif pm == "pacman":
        cmd = ["sudo", "pacman", "-S", "--noconfirm", "ripgrep"]
        cmd_str = "sudo pacman -S ripgrep"
        needs_sudo = True
    elif pm == "dnf":
        cmd = ["sudo", "dnf", "install", "-y", "ripgrep"]
        cmd_str = "sudo dnf install -y ripgrep"
        needs_sudo = True
    elif os_type == "debian":
        # Fallback: download .deb directly
        cmd = None
        cmd_str = f"wget {RIPGREP_DEB_URL} && sudo dpkg -i ripgrep_*.deb"
        needs_sudo = True
    else:
        _print(f"  [yellow]Install manually:[/yellow] https://github.com/BurntSushi/ripgrep#installation")
        return False

    # Ask user
    if interactive and not yes:
        _print(f"  [dim]Will run:[/dim] [cyan]{cmd_str}[/cyan]")
        answer = input("  Install ripgrep now? [Y/n] ").strip().lower()
        if answer not in ("", "y", "yes"):
            return False

    # Special case: deb download
    if cmd is None and os_type == "debian":
        return _install_ripgrep_deb(console=console)

    _print("  Installing ripgrep...")
    success = _run_cmd(cmd, "ripgrep install", console)
    if success:
        _print("  [green]✓ ripgrep installed[/green]")
    return success


def _install_ripgrep_deb(console=None) -> bool:
    """Download and install ripgrep .deb on Debian/Ubuntu without apt package."""
    import tempfile
    import urllib.request

    def _print(msg):
        if console:
            console.print(msg)
        else:
            print(msg)

    try:
        _print("  Downloading ripgrep .deb...")
        with tempfile.TemporaryDirectory() as tmpdir:
            deb_path = Path(tmpdir) / "ripgrep.deb"
            urllib.request.urlretrieve(RIPGREP_DEB_URL, deb_path)
            result = subprocess.run(
                ["sudo", "dpkg", "-i", str(deb_path)],
                capture_output=True, text=True, timeout=60
            )
            if result.returncode == 0:
                _print("  [green]✓ ripgrep installed[/green]")
                return True
            _print(f"  [red]Failed:[/red] {result.stderr.strip()[:200]}")
            return False
    except Exception as e:
        _print(f"  [red]Download failed:[/red] {e}")
        return False


def install_gitleaks(
    interactive: bool = True,
    yes: bool = False,
    console=None,
) -> bool:
    """
    Install gitleaks. Returns True if successful.

    On macOS: uses brew.
    On Linux: downloads binary to ~/.local/bin/ (no sudo needed).
    """
    pm = detect_package_manager()
    os_type = detect_os()
    machine = platform.machine().lower()

    def _print(msg):
        if console:
            console.print(msg)
        else:
            print(msg)

    if pm == "brew":
        cmd = ["brew", "install", "gitleaks"]
        cmd_str = "brew install gitleaks"

        if interactive and not yes:
            _print(f"  [dim]Will run:[/dim] [cyan]{cmd_str}[/cyan]")
            answer = input("  Install gitleaks now? [Y/n] ").strip().lower()
            if answer not in ("", "y", "yes"):
                return False

        _print("  Installing gitleaks...")
        success = _run_cmd(cmd, "gitleaks install", console)
        if success:
            _print("  [green]✓ gitleaks installed[/green]")
        return success

    # Linux: download binary to ~/.local/bin
    arch_key = "arm64" if "arm" in machine or "aarch" in machine else "amd64"
    os_key = "darwin" if os_type == "macos" else "linux"
    url_key = f"{os_key}_{arch_key}"
    url = GITLEAKS_RELEASES.get(url_key)

    if not url:
        _print(f"  [yellow]Install manually:[/yellow] https://github.com/gitleaks/gitleaks/releases")
        return False

    cmd_str = f"download gitleaks binary → ~/.local/bin/gitleaks (no sudo needed)"

    if interactive and not yes:
        _print(f"  [dim]Will:[/dim] [cyan]{cmd_str}[/cyan]")
        answer = input("  Install gitleaks now? [Y/n] ").strip().lower()
        if answer not in ("", "y", "yes"):
            return False

    return _install_gitleaks_binary(url, console=console)


def _install_gitleaks_binary(url: str, console=None) -> bool:
    """Download gitleaks binary to ~/.local/bin/."""
    import tarfile
    import tempfile
    import urllib.request

    def _print(msg):
        if console:
            console.print(msg)
        else:
            print(msg)

    local_bin = Path.home() / ".local" / "bin"
    local_bin.mkdir(parents=True, exist_ok=True)
    gitleaks_path = local_bin / "gitleaks"

    try:
        _print("  Downloading gitleaks binary...")
        with tempfile.TemporaryDirectory() as tmpdir:
            archive_path = Path(tmpdir) / "gitleaks.tar.gz"
            urllib.request.urlretrieve(url, archive_path)

            with tarfile.open(archive_path, "r:gz") as tar:
                # Find gitleaks binary in archive
                for member in tar.getmembers():
                    if member.name == "gitleaks" or member.name.endswith("/gitleaks"):
                        member.name = "gitleaks"
                        tar.extract(member, tmpdir)
                        break

            extracted = Path(tmpdir) / "gitleaks"
            if not extracted.exists():
                _print("  [red]gitleaks binary not found in archive[/red]")
                return False

            # Copy to ~/.local/bin
            import shutil
            shutil.copy2(extracted, gitleaks_path)
            gitleaks_path.chmod(0o755)

        _print(f"  [green]✓ gitleaks installed → {gitleaks_path}[/green]")
        _print(f"  [dim]Note: ensure ~/.local/bin is in your PATH[/dim]")
        return True

    except Exception as e:
        _print(f"  [red]Download failed:[/red] {e}")
        _print(f"  [dim]Manual install: https://github.com/gitleaks/gitleaks/releases[/dim]")
        return False