"""
Token estimation utilities.

Uses tiktoken (cl100k_base) when available.
Falls back to character-count approximation when tiktoken is unavailable
or fails. Callers get a consistent interface regardless.

Note: cl100k_base is not identical to Claude's tokenizer, but is
within ~10% for English/code content – sufficient for budget decisions.
"""

from __future__ import annotations

import logging
from functools import lru_cache
from typing import Optional

from lao.constants import CHARS_PER_TOKEN_FALLBACK, TIKTOKEN_ENCODING

logger = logging.getLogger(__name__)

# Cached flag so we only warn once per process
_tiktoken_warned = False


@lru_cache(maxsize=1)
def _get_encoder() -> Optional[object]:
    """
    Load tiktoken encoder once and cache it.
    Returns None if tiktoken is not installed.
    """
    global _tiktoken_warned
    try:
        import tiktoken  # type: ignore[import]
        return tiktoken.get_encoding(TIKTOKEN_ENCODING)
    except ImportError:
        if not _tiktoken_warned:
            logger.debug(
                "tiktoken not installed. Using character-count fallback "
                "for token estimation (±20% accuracy). "
                "Install with: pip install tiktoken"
            )
            _tiktoken_warned = True
        return None
    except Exception as e:
        if not _tiktoken_warned:
            logger.debug(f"tiktoken failed to load: {e}. Using fallback.")
            _tiktoken_warned = True
        return None


def estimate_tokens(text: str) -> int:
    """
    Estimate token count for a string.

    Returns an integer estimate. Uses tiktoken if available,
    otherwise falls back to len(text) / CHARS_PER_TOKEN_FALLBACK.

    Edge cases:
    - Empty string → 0
    - Very long string → tiktoken handles it in chunks internally
    - Non-UTF8 content that slipped through → replace errors silently
    """
    if not text:
        return 0

    encoder = _get_encoder()
    if encoder is not None:
        try:
            # encode() returns a list of token IDs
            return len(encoder.encode(text))  # type: ignore[union-attr]
        except Exception:
            pass  # Fall through to approximation

    # Fallback: character count approximation
    return max(1, len(text) // CHARS_PER_TOKEN_FALLBACK)


def estimate_tokens_for_lines(lines: list[str]) -> int:
    """Estimate tokens for a list of lines (joined with newlines)."""
    return estimate_tokens("\n".join(lines))


def format_token_count(n: int) -> str:
    """Human-readable token count. E.g. 142000 → '142k'."""
    if n >= 1000:
        return f"{n / 1000:.1f}k"
    return str(n)


def tokens_to_budget_pct(tokens: int, budget: int) -> float:
    """Return what percentage of budget this token count uses."""
    if budget <= 0:
        return 0.0
    return round((tokens / budget) * 100, 1)
