"""
Filesystem utilities for lao.

All file I/O goes through here – no raw open() calls scattered in business logic.
Handles: encoding, binary detection, symlink safety, size limits.
"""

from __future__ import annotations

import fnmatch
import hashlib
import os
from pathlib import Path
from typing import Iterator, Optional

from lao.constants import (
    ALWAYS_IGNORE_DIRS,
    ALWAYS_IGNORE_FILES,
    BINARY_EXTENSIONS,
    MAX_FILE_SIZE_BYTES,
    MAX_REPO_DEPTH,
)


def is_binary_path(path: Path) -> bool:
    """Return True if the file extension indicates binary content."""
    return path.suffix.lower() in BINARY_EXTENSIONS


def is_binary_content(path: Path, sample_bytes: int = 8192) -> bool:
    """
    Sniff file content to detect binary.
    Reads up to sample_bytes. Returns True if null bytes found.
    Falls back to extension check on read error.
    """
    if is_binary_path(path):
        return True
    try:
        with open(path, "rb") as f:
            chunk = f.read(sample_bytes)
        return b"\x00" in chunk
    except OSError:
        return False


def read_text_safe(
    path: Path,
    max_bytes: int = MAX_FILE_SIZE_BYTES,
) -> Optional[str]:
    """
    Read a text file safely.

    Returns:
        File content as string, or None if:
        - File is binary
        - File exceeds max_bytes
        - File cannot be read (permissions, etc.)

    Always decodes as UTF-8 with replacement chars for invalid bytes.
    """
    if is_binary_path(path):
        return None

    try:
        size = path.stat().st_size
    except OSError:
        return None

    if size > max_bytes:
        return None

    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return None


def file_hash(path: Path) -> str:
    """
    SHA256 of file content. Used for embedding cache invalidation.
    Returns empty string on read error.
    """
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return ""


def matches_any_pattern(path_str: str, patterns: list[str]) -> bool:
    """
    Check if a path string matches any of the given glob patterns.

    Patterns are matched against:
    1. The full path string as-is
    2. Just the filename
    3. With forward slashes normalized

    Edge cases:
    - Case is preserved (Unix-style, case-sensitive)
    - Patterns like ".env*" match ".env", ".env.local", etc.
    - Patterns like "**/*.pem" match any depth
    - Empty patterns list → always False
    """
    normalized = path_str.replace("\\", "/").lower()
    filename = Path(path_str).name.lower()

    for pattern in patterns:
        p = pattern.replace("\\", "/").lower()
        # Match against full path
        if fnmatch.fnmatch(normalized, p):
            return True
        # Match against filename only (for patterns without path sep)
        if "/" not in p and fnmatch.fnmatch(filename, p):
            return True
        # Handle ** prefix patterns like "**/foo.pem"
        if p.startswith("**/"):
            suffix = p[3:]
            if fnmatch.fnmatch(filename, suffix):
                return True
            # Also try matching path segments
            if fnmatch.fnmatch(normalized, p):
                return True
    return False


def should_ignore_dir(dir_name: str, extra_ignore: list[str] | None = None) -> bool:
    """
    Check if a directory should be completely skipped during traversal.
    """
    import fnmatch
    if dir_name in ALWAYS_IGNORE_DIRS:
        return True
    # Glob-pattern match (e.g. *.egg-info)
    for pattern in ALWAYS_IGNORE_DIRS:
        if "*" in pattern and fnmatch.fnmatch(dir_name, pattern):
            return True
    if dir_name.startswith(".") and dir_name not in {".github", ".husky"}:
        return True
    if extra_ignore:
        return dir_name in extra_ignore
    return False


def should_ignore_file(filename: str) -> bool:
    """Check if a file should be skipped based on name patterns."""
    for pattern in ALWAYS_IGNORE_FILES:
        if fnmatch.fnmatch(filename.lower(), pattern.lower()):
            return True
    return False


def walk_repo(
    root: Path,
    max_depth: int = MAX_REPO_DEPTH,
    extra_ignore_dirs: list[str] | None = None,
) -> Iterator[Path]:
    """
    Walk a repo directory, yielding file paths.

    Safety guarantees:
    - Depth limit enforced (avoids infinite loops in weird setups)
    - Symlinks resolved once; circular symlinks skipped
    - Binary files still yielded (caller decides what to do)
    - Very large directories (>MAX_FILES_HARD_LIMIT) trigger StopIteration
      with a warning – caller should handle

    Yields: absolute Path objects for each file
    """
    seen_inodes: set[int] = set()
    file_count = 0

    def _walk(current: Path, depth: int) -> Iterator[Path]:
        nonlocal file_count

        if depth > max_depth:
            return

        try:
            entries = sorted(current.iterdir())
        except PermissionError:
            return
        except OSError:
            return

        for entry in entries:
            # Resolve symlinks once to detect loops
            try:
                real = entry.resolve()
                inode = real.stat().st_ino
            except OSError:
                continue

            if entry.is_symlink():
                if inode in seen_inodes:
                    continue  # Circular symlink
                seen_inodes.add(inode)

            if entry.is_dir() and not entry.is_symlink():
                if should_ignore_dir(entry.name, extra_ignore_dirs):
                    continue
                yield from _walk(entry, depth + 1)

            elif entry.is_file():
                if should_ignore_file(entry.name):
                    continue
                file_count += 1
                yield entry

    yield from _walk(root, depth=0)


def ensure_lao_dir(repo_root: Path) -> Path:
    """
    Create .lao/ and subdirectories if they don't exist.
    Returns the .lao/ path.
    Raises OutputError on permission failure.
    """
    from lao.constants import LAO_DIR, RUNS_DIR
    from lao.exceptions import OutputError

    lao_dir = repo_root / LAO_DIR
    runs_dir = lao_dir / RUNS_DIR

    try:
        lao_dir.mkdir(parents=True, exist_ok=True)
        runs_dir.mkdir(parents=True, exist_ok=True)
    except PermissionError as e:
        raise OutputError(
            f"Cannot create {lao_dir}: permission denied. "
            f"Check directory permissions. Detail: {e}"
        ) from e
    except OSError as e:
        raise OutputError(
            f"Cannot create {lao_dir}: {e}"
        ) from e

    return lao_dir


def safe_write_text(path: Path, content: str) -> None:
    """
    Write text to a file, creating parent directories as needed.
    Uses atomic write (write to temp, then rename) to avoid partial writes.
    """
    from lao.exceptions import OutputError

    tmp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(content)
        tmp_path.rename(path)
    except OSError as e:
        # Clean up temp file if it exists
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise OutputError(f"Cannot write to {path}: {e}") from e