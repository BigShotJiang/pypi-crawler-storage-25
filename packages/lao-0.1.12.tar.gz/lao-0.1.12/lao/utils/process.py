"""
Subprocess utilities for lao.

All external process calls go through here.
Provides:
- Consistent timeout handling
- Output size limiting
- Structured return type
- Proper encoding handling
"""

from __future__ import annotations

import shutil
import subprocess
import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class ProcessResult:
    """Result of a subprocess call."""
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool = False
    truncated: bool = False  # True if stdout was cut at max_output_bytes


def find_binary(name: str) -> Optional[str]:
    """
    Return full path to binary if found on PATH, else None.
    Uses shutil.which – works on all platforms.
    """
    return shutil.which(name)


def is_available(binary: str) -> bool:
    """Check if a binary is available on PATH."""
    return find_binary(binary) is not None


def run(
    args: list[str],
    *,
    timeout: float = 30.0,
    cwd: Optional[str] = None,
    max_output_bytes: int = 10 * 1024 * 1024,  # 10MB
    input_text: Optional[str] = None,
    env: Optional[dict[str, str]] = None,
) -> ProcessResult:
    """
    Run a subprocess and return a ProcessResult.

    Never raises on non-zero exit codes – callers check returncode.
    Only raises on:
    - FileNotFoundError: binary not found (caller should check is_available first)
    - PermissionError: binary not executable

    Edge cases handled:
    - Timeout: returns ProcessResult with timed_out=True
    - Huge output: truncated at max_output_bytes, truncated=True
    - Encoding errors in output: replaced with U+FFFD
    - Binary output when text expected: decoded with errors='replace'
    """
    try:
        proc = subprocess.run(
            args,
            capture_output=True,
            timeout=timeout,
            cwd=cwd,
            input=input_text.encode("utf-8") if input_text else None,
            env=env,
        )
    except subprocess.TimeoutExpired as e:
        stdout = ""
        stderr = ""
        if e.stdout:
            raw = e.stdout if isinstance(e.stdout, bytes) else e.stdout.encode()
            stdout = raw[:max_output_bytes].decode("utf-8", errors="replace")
        if e.stderr:
            raw = e.stderr if isinstance(e.stderr, bytes) else e.stderr.encode()
            stderr = raw[:max_output_bytes].decode("utf-8", errors="replace")
        logger.debug(f"Process timed out after {timeout}s: {args[0]}")
        return ProcessResult(
            returncode=-1,
            stdout=stdout,
            stderr=stderr,
            timed_out=True,
        )
    except FileNotFoundError:
        raise  # Caller should have checked is_available first
    except PermissionError:
        raise

    # Decode output
    truncated = False
    raw_stdout = proc.stdout or b""
    raw_stderr = proc.stderr or b""

    if len(raw_stdout) > max_output_bytes:
        raw_stdout = raw_stdout[:max_output_bytes]
        truncated = True
        logger.debug(
            f"stdout from {args[0]} truncated at {max_output_bytes} bytes"
        )

    stdout = raw_stdout.decode("utf-8", errors="replace")
    stderr = raw_stderr.decode("utf-8", errors="replace")

    return ProcessResult(
        returncode=proc.returncode,
        stdout=stdout,
        stderr=stderr,
        truncated=truncated,
    )
