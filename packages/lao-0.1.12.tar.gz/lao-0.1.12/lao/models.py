"""
All Pydantic data models for lao.

Single source of truth for every data structure.
Nothing is typed as `dict` or `Any` when a model can be used.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# ─── Enums ────────────────────────────────────────────────────────────────────

class TaskType(str, Enum):
    REPO_SEARCH      = "repo_search"
    CODE_EXPLANATION = "code_explanation"
    BUG_DIAGNOSIS    = "bug_diagnosis"
    PATCH_GENERATION = "patch_generation"
    TEST_GENERATION  = "test_generation"
    LOG_ANALYSIS     = "log_analysis"
    ARCHITECTURE     = "architecture"
    UNKNOWN          = "unknown"


class Difficulty(str, Enum):
    TRIVIAL           = "trivial"
    LOCAL_OK          = "local_ok"
    CLOUD_RECOMMENDED = "cloud_recommended"
    CLOUD_REQUIRED    = "cloud_required"


class PrivacyLevel(str, Enum):
    PUBLIC_SAFE   = "public_safe"
    INTERNAL_CODE = "internal_code"
    SECRET_RISK   = "secret_risk"
    LOCAL_ONLY    = "local_only"


class CompressionLevel(int, Enum):
    RAW        = 0  # Raw snippets, no modification
    SUMMARIZED = 1  # Snippets + 2-sentence file summaries
    COMPACT    = 2  # Summaries only, no raw code
    MINIMAL    = 3  # Facts/constraints only


class CloudTarget(str, Enum):
    NONE           = "none"
    LOCAL_MODEL    = "local_model"
    CLOUD_CHEAP    = "cloud_cheap"    # Haiku, GPT-4o-mini
    CLOUD_STANDARD = "cloud_standard" # Sonnet
    CLOUD_STRONG   = "cloud_strong"   # Opus


class PolicyDecision(str, Enum):
    ALLOW = "allow"
    WARN  = "warn"
    BLOCK = "block"


# ─── Config ───────────────────────────────────────────────────────────────────

class CloudConfig(BaseModel):
    enabled: bool = True
    max_tokens_per_task: int = Field(default=25000, ge=1000, le=200000)
    max_cost_eur: float = Field(default=0.30, ge=0.0)
    preferred_model: str = "claude-sonnet"


class LocalConfig(BaseModel):
    embeddings_enabled: bool = False  # Off by default until `lao index` run
    embedding_model: str = "BAAI/bge-small-en-v1.5"
    local_llm_enabled: bool = False
    local_llm_provider: str = "ollama"
    local_llm_model: str = "qwen2.5-coder:7b"


class SecurityConfig(BaseModel):
    redact_secrets: bool = True
    block_env_files: bool = True
    gitleaks_enabled: bool = True
    trufflehog_enabled: bool = False  # Slower, opt-in
    cloud_deny: list[str] = Field(default_factory=lambda: [
        ".env*",
        ".env",
        ".env.local",
        ".env.production",
        ".env.staging",
        "**/*.pem",
        "**/*.key",
        "**/*.p12",
        "**/*.pfx",
        "**/wallet*",
        "**/credentials*",
        "**/*.secret",
        "**/*secrets.env",
        "**/secret_key*",
        "**/.aws/credentials",
        "**/id_rsa",
        "**/id_ed25519",
    ])
    cloud_warn: list[str] = Field(default_factory=lambda: [
        # Only flag paths very likely to contain raw secrets
        "**/auth/secrets*",
        "**/auth/keys*",
    ])
    cloud_allow: list[str] = Field(default_factory=lambda: [
        "src/**", "app/**", "lib/**", "libs/**", "pkg/**",
        "cmd/**", "internal/**", "tests/**", "test/**",
        "__tests__/**", "spec/**", "benchmark/**",
        "examples/**", "scripts/**",
        "package.json", "pyproject.toml", "tsconfig.json",
        "Cargo.toml", "go.mod", "setup.py", "setup.cfg",
        "**/*.py", "**/*.ts", "**/*.tsx", "**/*.js", "**/*.jsx",
        "**/*.go", "**/*.rs", "**/*.md", "**/*.toml",
        "**/*.yaml", "**/*.yml", "**/*.json",
    ])


class LimitsConfig(BaseModel):
    max_files_in_context: int = Field(default=10, ge=1, le=50)
    max_file_tokens: int = Field(default=6000, ge=500, le=50000)
    max_log_lines: int = Field(default=120, ge=10, le=5000)
    test_timeout_seconds: int = Field(default=60, ge=5, le=300)
    max_total_context_tokens: int = Field(default=30000, ge=5000, le=200000)


class RoutingConfig(BaseModel):
    local_first: bool = True
    cloud_on_low_confidence: bool = True
    confidence_threshold: float = Field(default=0.75, ge=0.0, le=1.0)


class ProjectConfig(BaseModel):
    name: str = "unknown"
    root: Path = Field(default_factory=Path.cwd)
    cloud: CloudConfig = Field(default_factory=CloudConfig)
    local: LocalConfig = Field(default_factory=LocalConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    limits: LimitsConfig = Field(default_factory=LimitsConfig)
    routing: RoutingConfig = Field(default_factory=RoutingConfig)

    @field_validator("root", mode="before")
    @classmethod
    def coerce_root_to_path(cls, v: object) -> Path:
        return Path(str(v))

    @field_validator("root")
    @classmethod
    def root_must_exist(cls, v: Path) -> Path:
        resolved = v.resolve()
        if not resolved.exists():
            raise ValueError(f"Project root does not exist: {resolved}")
        return resolved


# ─── Task ─────────────────────────────────────────────────────────────────────

class TaskInput(BaseModel):
    task: str = Field(min_length=3, max_length=500)
    repo_path: Path = Field(default_factory=Path.cwd)
    allow_cloud: bool = True
    allow_write: bool = False
    max_cloud_tokens: Optional[int] = None
    extra_context: Optional[str] = None  # e.g. pasted error output

    @field_validator("task")
    @classmethod
    def task_not_empty(cls, v: str) -> str:
        stripped = v.strip()
        if not stripped:
            raise ValueError("Task cannot be empty or whitespace only")
        return stripped

    @field_validator("repo_path", mode="before")
    @classmethod
    def coerce_repo_path(cls, v: object) -> Path:
        return Path(str(v))


class TaskClassification(BaseModel):
    task_type: TaskType = TaskType.UNKNOWN
    difficulty: Difficulty = Difficulty.CLOUD_RECOMMENDED
    privacy: PrivacyLevel = PrivacyLevel.INTERNAL_CODE
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    reasoning: str = ""
    keywords_extracted: list[str] = Field(default_factory=list)


# ─── Repo Profile ─────────────────────────────────────────────────────────────

class RepoProfile(BaseModel):
    root: Path
    languages: list[str] = Field(default_factory=list)
    primary_language: Optional[str] = None
    framework: Optional[str] = None
    package_manager: Optional[str] = None
    test_runner: Optional[str] = None
    important_dirs: list[str] = Field(default_factory=list)
    ignored_dirs: list[str] = Field(default_factory=list)
    total_files_found: int = 0
    total_files_scanned: int = 0
    scan_duration_ms: float = 0.0

    @field_validator("root", mode="before")
    @classmethod
    def coerce_root(cls, v: object) -> Path:
        return Path(str(v))


# ─── Files ────────────────────────────────────────────────────────────────────

class FileEntry(BaseModel):
    """Represents a single file in the repo with metadata."""
    path: Path
    relative_path: str
    size_bytes: int = 0
    size_tokens: int = 0      # Estimated, populated lazily
    language: Optional[str] = None
    is_test: bool = False
    is_generated: bool = False
    content_hash: str = ""    # SHA256, used for embedding cache invalidation

    @field_validator("path", mode="before")
    @classmethod
    def coerce_path(cls, v: object) -> Path:
        return Path(str(v))


class ScoredFile(BaseModel):
    """A FileEntry with a relevance score and breakdown."""
    file: FileEntry
    score: float = 0.0
    score_breakdown: dict[str, float] = Field(default_factory=dict)
    matched_lines: list[int] = Field(default_factory=list)
    # Each tuple is (start_line, end_line) 1-indexed, inclusive
    relevant_chunks: list[tuple[int, int]] = Field(default_factory=list)


# ─── Search ───────────────────────────────────────────────────────────────────

class SearchMatch(BaseModel):
    """A single ripgrep (or fallback) match."""
    file: str
    line: int
    column: int = 0
    text: str = ""


# ─── Security ─────────────────────────────────────────────────────────────────

class SecretFinding(BaseModel):
    file: str
    line: Optional[int] = None
    secret_type: str
    pattern_matched: str = ""
    action_taken: str  # "blocked_file" | "redacted" | "warned"


class SecurityReport(BaseModel):
    secrets_found: list[SecretFinding] = Field(default_factory=list)
    files_blocked: list[str] = Field(default_factory=list)
    files_warned: list[str] = Field(default_factory=list)
    scanner_used: str = "none"   # "gitleaks" | "regex_fallback" | "none"
    clean: bool = True
    scan_duration_ms: float = 0.0

    @model_validator(mode="after")
    def compute_clean(self) -> SecurityReport:
        self.clean = (
            len(self.secrets_found) == 0
            and len(self.files_blocked) == 0
        )
        return self


# ─── Context Pack ─────────────────────────────────────────────────────────────

class ContextChunk(BaseModel):
    """A slice of a file included in the context pack."""
    file_path: str
    start_line: int
    end_line: int
    content: str
    reason: str      # Human-readable: why this chunk is included
    token_estimate: int = 0


class UncertaintyNote(BaseModel):
    """
    A note about what the evidence pack does NOT cover.
    Critical for helping Claude know what it might be missing.
    """
    note_type: str   # "possible_dependency" | "not_checked" | "truncated"
                     # | "security_excluded" | "index_stale" | "tool_fallback"
    message: str
    related_files: list[str] = Field(default_factory=list)


class ContextPack(BaseModel):
    """The complete prepared evidence pack, ready for output."""
    task: str
    task_classification: TaskClassification
    repo_profile: RepoProfile
    selected_files: list[ScoredFile] = Field(default_factory=list)
    chunks: list[ContextChunk] = Field(default_factory=list)
    security_report: SecurityReport = Field(default_factory=SecurityReport)
    uncertainty_notes: list[UncertaintyNote] = Field(default_factory=list)
    compression_level: CompressionLevel = CompressionLevel.RAW
    raw_token_estimate: int = 0
    optimized_token_estimate: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ─── Run Report ───────────────────────────────────────────────────────────────

class RunReport(BaseModel):
    """Persisted JSON report for every `lao prep` run."""
    run_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    task: str
    started_at: datetime = Field(default_factory=datetime.utcnow)
    finished_at: Optional[datetime] = None
    duration_ms: float = 0.0

    # Counts
    repo_files_scanned: int = 0
    files_selected: int = 0
    tests_run: int = 0

    # Token stats
    raw_token_estimate: int = 0
    optimized_token_estimate: int = 0
    tokens_saved_estimate: int = 0
    savings_pct: float = 0.0
    repo_total_tokens: int = 0

    # Security stats
    secrets_redacted: int = 0
    files_blocked: int = 0

    # Routing
    cloud_recommended: bool = False
    recommended_target: CloudTarget = CloudTarget.NONE
    recommended_model: Optional[str] = None
    risk_level: str = "low"  # "low" | "medium" | "high"

    # Status
    success: bool = True
    error: Optional[str] = None
    warnings: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def compute_savings(self) -> RunReport:
        if self.raw_token_estimate > 0:
            saved = self.raw_token_estimate - self.optimized_token_estimate
            self.tokens_saved_estimate = max(0, saved)
            self.savings_pct = round(
                (saved / self.raw_token_estimate) * 100, 1
            )
        return self