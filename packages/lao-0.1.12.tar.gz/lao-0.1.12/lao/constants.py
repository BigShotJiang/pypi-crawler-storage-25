"""
Global constants for lao.
All magic numbers and strings live here – never hardcoded elsewhere.
"""

from pathlib import Path

# ─── Directories ──────────────────────────────────────────────────────────────

LAO_DIR = ".lao"
CONFIG_FILE = "config.yaml"
INDEX_FILE = "index.sqlite"
RUNS_DIR = "runs"
EMBEDDINGS_DIR = "embeddings"

# ─── Limits ───────────────────────────────────────────────────────────────────

MAX_REPO_DEPTH = 15
MAX_FILES_HARD_LIMIT = 500_000     # Abort above this
MAX_FILE_SIZE_BYTES = 2 * 1024 * 1024  # 2MB – skip larger files
MAX_SEARCH_OUTPUT_BYTES = 10 * 1024 * 1024  # 10MB ripgrep output cap
RIPGREP_TIMEOUT_SECONDS = 30
GITLEAKS_TIMEOUT_SECONDS = 30
TEST_RUNNER_TIMEOUT_SECONDS = 60
CHUNK_CONTEXT_LINES = 80           # Lines around a match to include
CHUNK_MERGE_GAP_LINES = 20         # Merge chunks closer than this
ENTROPY_MIN_LENGTH = 20            # Don't entropy-check short strings
ENTROPY_HIGH_THRESHOLD = 4.5       # Shannon entropy → flag as suspicious

# ─── Tokens ───────────────────────────────────────────────────────────────────

# tiktoken encoding to use for estimation (cl100k_base ≈ Claude)
TIKTOKEN_ENCODING = "cl100k_base"
CHARS_PER_TOKEN_FALLBACK = 4       # Used when tiktoken unavailable

# ─── Ignore patterns (always skip these) ──────────────────────────────────────

ALWAYS_IGNORE_DIRS: frozenset[str] = frozenset({
    "node_modules",
    ".git",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "target",           # Rust/Maven
    "venv",
    ".venv",
    "env",
    "__pycache__",
    "coverage",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".tox",
    ".eggs",
    "*.egg-info",
    ".DS_Store",
    "Thumbs.db",
    ".turbo",
    ".vercel",
    ".netlify",
    "out",              # Next.js static export
    "storybook-static",
    ".storybook",
    "playwright-report",
    ".nyc_output",
})

ALWAYS_IGNORE_FILES: frozenset[str] = frozenset({
    "*.lock",
    "*.log",
    "*.min.js",
    "*.min.css",
    "*.map",            # source maps
    "*.d.ts",           # TypeScript declaration files (generated)
    "*.generated.*",
    "*.pb.go",          # protobuf generated
    "*_pb2.py",         # protobuf generated Python
    "*.pb.ts",
})

# ─── Binary file extensions (skip content scan) ───────────────────────────────

BINARY_EXTENSIONS: frozenset[str] = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp", ".svg",
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".tar", ".gz", ".bz2", ".xz", ".7z", ".rar",
    ".exe", ".dll", ".so", ".dylib", ".a", ".o",
    ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".mp3", ".mp4", ".wav", ".ogg", ".avi", ".mov",
    ".db", ".sqlite", ".sqlite3",
    ".pyc", ".pyo", ".class",
    ".bin", ".dat",
})

# ─── Language detection ───────────────────────────────────────────────────────

EXTENSION_TO_LANGUAGE: dict[str, str] = {
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".py": "python",
    ".rs": "rust",
    ".go": "go",
    ".java": "java",
    ".kt": "kotlin",
    ".swift": "swift",
    ".rb": "ruby",
    ".php": "php",
    ".cs": "csharp",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".c": "c",
    ".h": "c",
    ".hpp": "cpp",
    ".dart": "dart",
    ".ex": "elixir",
    ".exs": "elixir",
    ".hs": "haskell",
    ".ml": "ocaml",
    ".scala": "scala",
    ".vue": "vue",
    ".svelte": "svelte",
    ".astro": "astro",
    ".sql": "sql",
    ".sh": "bash",
    ".bash": "bash",
    ".zsh": "bash",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".json": "json",
    ".toml": "toml",
    ".md": "markdown",
    ".mdx": "markdown",
    ".html": "html",
    ".css": "css",
    ".scss": "scss",
    ".sass": "scss",
    ".less": "less",
}

# ─── Framework detection markers ─────────────────────────────────────────────

FRAMEWORK_MARKERS: list[tuple[str, str]] = [
    # (marker_filename_glob, framework_name)
    # Order matters: more specific first
    ("next.config.ts",       "nextjs"),
    ("next.config.js",       "nextjs"),
    ("next.config.mjs",      "nextjs"),
    ("nuxt.config.ts",       "nuxt"),
    ("nuxt.config.js",       "nuxt"),
    ("astro.config.ts",      "astro"),
    ("astro.config.mjs",     "astro"),
    ("svelte.config.js",     "sveltekit"),
    ("svelte.config.ts",     "sveltekit"),
    ("remix.config.js",      "remix"),
    ("vite.config.ts",       "vite"),
    ("vite.config.js",       "vite"),
    ("angular.json",         "angular"),
    ("manage.py",            "django"),
    # Python package-based detection (checked via pyproject.toml/requirements.txt content)
    # These are handled in _detect_framework_from_deps()
    ("Cargo.toml",           "rust"),
    ("go.mod",               "go"),
    ("pubspec.yaml",         "flutter"),
    ("pom.xml",              "maven"),
    ("build.gradle",         "gradle"),
]

# Dependencies that indicate a framework (checked in pyproject.toml / requirements.txt)
DEPENDENCY_FRAMEWORK_MARKERS: list[tuple[str, str]] = [
    ("fastapi",          "fastapi"),
    ("flask",            "flask"),
    ("django",           "django"),
    ("starlette",        "starlette"),
    ("litestar",         "litestar"),
    ("tornado",          "tornado"),
    ("aiohttp",          "aiohttp"),
    ("sanic",            "sanic"),
    ("express",          "express"),
    ("nestjs",           "nestjs"),
    ("hono",             "hono"),
    ("spring",           "spring"),
    ("rails",            "rails"),
    ("laravel",          "laravel"),
]

TEST_RUNNER_MARKERS: list[tuple[str, str]] = [
    ("vitest.config.ts",     "vitest"),
    ("vitest.config.js",     "vitest"),
    ("jest.config.ts",       "jest"),
    ("jest.config.js",       "jest"),
    ("pytest.ini",           "pytest"),
    ("conftest.py",          "pytest"),
    ("Cargo.toml",           "cargo-test"),
    ("go.mod",               "go-test"),
]

PACKAGE_MANAGER_MARKERS: list[tuple[str, str]] = [
    ("pnpm-lock.yaml",       "pnpm"),
    ("yarn.lock",            "yarn"),
    ("bun.lockb",            "bun"),
    ("package-lock.json",    "npm"),
    ("Pipfile",              "pipenv"),
    ("poetry.lock",          "poetry"),
    ("uv.lock",              "uv"),
    ("Cargo.lock",           "cargo"),
]

# ─── Secret patterns (fallback when gitleaks not available) ───────────────────

FALLBACK_SECRET_PATTERNS: dict[str, str] = {
    "aws_access_key":     r"AKIA[0-9A-Z]{16}",
    "aws_secret_key":     r"(?i)aws.{0,20}secret.{0,20}['\"][0-9a-zA-Z/+]{40}['\"]",
    "stripe_secret":      r"sk_(live|test)_[A-Za-z0-9]{24,}",
    "stripe_restricted":  r"rk_(live|test)_[A-Za-z0-9]{24,}",
    "github_pat":         r"ghp_[A-Za-z0-9]{36}",
    "github_oauth":       r"gho_[A-Za-z0-9]{36}",
    "github_app":         r"(ghu|ghs)_[A-Za-z0-9]{36}",
    "openai_key":         r"sk-[A-Za-z0-9]{48}",
    "anthropic_key":      r"sk-ant-[A-Za-z0-9\-_]{90,}",
    "slack_token":        r"xox[baprs]-[A-Za-z0-9\-]{10,}",
    "slack_webhook":      r"https://hooks\.slack\.com/services/[A-Z0-9/]+",
    "jwt_token":          r"eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+",
    "private_key":        r"-----BEGIN (RSA |EC |OPENSSH |DSA )?PRIVATE KEY",
    "generic_api_key":    r"(?i)(api[_\-\s]?key|apikey)['\"\s:=]+['\"][A-Za-z0-9\-_]{20,}['\"]",
    "generic_password":   r"(?i)(password|passwd|pwd)['\"\s:=]+['\"][^'\"]{8,}['\"]",
    "database_url":       r"(?i)(postgres|mysql|mongodb|redis)://[^\s'\"]+",
    "sendgrid_key":       r"SG\.[A-Za-z0-9\-_]{22}\.[A-Za-z0-9\-_]{43}",
    "twilio_key":         r"SK[0-9a-fA-F]{32}",
    "google_api_key":     r"AIza[0-9A-Za-z\-_]{35}",
    "firebase_key":       r"AAAA[A-Za-z0-9_\-]{7}:[A-Za-z0-9_\-]{140}",
}

# ─── Cloud model recommendations ─────────────────────────────────────────────

MODEL_RECOMMENDATIONS: dict[str, str] = {
    "trivial":           "none (answer locally)",
    "local_ok":          "local model or claude-haiku",
    "cloud_recommended": "claude-sonnet",
    "cloud_required":    "claude-sonnet or claude-opus",
}

# ─── Version ─────────────────────────────────────────────────────────────────

VERSION = "0.1.0"