# 掘金公开内容 MCP Server

## 概述

`Astron-juejin-mcp` 是一个基于 MCP 协议的掘金工具服务，直接调用掘金公开 API，并通过纯 Python 解掘金页面 WAF 后读取公开页面内容，无需额外部署后端服务。

当前工程形态：
- 使用 `MCP Python SDK`
- 使用单文件 `server.py` 承载工具定义、WAF 解锁和 HTTP 调用
- 通过独立 `pyproject` 打包
- 支持 `uvx` 一键启动
- 通过环境变量配置超时和 User-Agent

当前提供 6 个原子工具：
- `get_hot_list`
- `get_feed_list`
- `search_content`
- `get_content_detail`
- `get_author_profile`
- `get_author_content_list`


## 工具列表

### 1. 获取热门文章榜 `get_hot_list`
- 描述：读取掘金热门文章榜。
- 参数：
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 2. 获取分类推荐流 `get_feed_list`
- 描述：读取掘金分类推荐流。
- 参数：
  - `channel`：可选 `frontend`、`backend`、`android`、`ios`、`ai`、`career`、`freebie`
  - `cursor`：分页游标
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 3. 搜索内容 `search_content`
- 描述：搜索掘金公开文章。
- 参数：
  - `query`：搜索词，必填
  - `cursor`：分页游标
  - `limit`：返回条数，默认 `20`

### 4. 获取内容详情 `get_content_detail`
- 描述：读取掘金文章详情。
- 参数：
  - `content_id`：文章 ID
  - `url`：内容完整 URL

### 5. 获取作者主页 `get_author_profile`
- 描述：读取掘金作者公开主页。
- 参数：
  - `author_id`：作者 user ID
  - `url`：作者主页 URL

### 6. 获取作者文章列表 `get_author_content_list`
- 描述：读取掘金作者公开文章列表。
- 参数：
  - `author_id`：作者 user ID
  - `url`：作者主页或文章列表 URL
  - `cursor`：兼容保留参数，当前未启用
  - `limit`：返回条数，默认 `20`


## 环境变量

这个包默认不需要认证信息。

可选环境变量：

```bash
export JUEJIN_MCP_TIMEOUT_SECONDS="30"
export JUEJIN_MCP_USER_AGENT="Mozilla/5.0 ..."
```

说明：
- `JUEJIN_MCP_TIMEOUT_SECONDS` 控制 API 和页面请求超时。
- `JUEJIN_MCP_USER_AGENT` 用于覆盖默认请求头。


## 安装与启动

### 推荐方式：使用 uvx 一键启动

```bash
uvx --from astron-juejin-mcp astron-juejin-mcp
```

如果你还没有安装 `uv` / `uvx`，可先执行：

```bash
curl -fsSL https://install.astral.sh/uv | bash
```

### 使用 pip 安装

```bash
pip install astron-juejin-mcp
juejin-mcp
```

### 本地源码运行

```bash
cd MCP/juejin-mcp
PYTHONPATH=src python3 -m juejin_mcp.server
```


## 客户端配置

### 使用 uvx

```json
{
  "mcpServers": {
    "juejin-mcp": {
      "command": "uvx",
      "args": ["--from", "astron-juejin-mcp", "astron-juejin-mcp"],
      "env": {
        "JUEJIN_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```

### 使用本地源码

```json
{
  "mcpServers": {
    "juejin-mcp": {
      "command": "python3",
      "args": ["-m", "juejin_mcp.server"],
      "env": {
        "PYTHONPATH": "/path/to/MCP/juejin-mcp/src",
        "JUEJIN_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```


## 平台差异说明

1. 这个 MCP 直接请求掘金公开 API 和公开页面，不依赖额外的 Astron 后端服务。
2. 当前仅面向公开内容能力，不包含登录态、私有内容或用户专属数据。
3. 首页类能力优先走公开 API；文章详情和作者页能力通过纯 Python 解掘金 WAF 后抓取公开页面。
4. `get_author_content_list` 当前未启用分页游标，默认返回作者文章页首屏可见内容。
5. 如果掘金的 WAF 机制或页面结构发生变化，详情和作者相关能力可能需要同步调整。


## 发布说明

```bash
cd MCP/juejin-mcp
rm -rf build dist src/*.egg-info
python3 -m build --no-isolation
python3 -m twine check dist/*
python3 -m twine upload dist/*
```


## License

Apache License 2.0. See `LICENSE`.
