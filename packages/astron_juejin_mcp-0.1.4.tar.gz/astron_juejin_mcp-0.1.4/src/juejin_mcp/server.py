"""Astron Juejin MCP server."""

from __future__ import annotations

import base64
import hashlib
import html as html_lib
import json
import os
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from typing import Any
from urllib.parse import quote, urlencode, urljoin, urlparse

import requests
from mcp.server.fastmcp import Context, FastMCP

from juejin_mcp import __version__


JUEJIN_BASE_URL = "https://juejin.cn"
JUEJIN_HOME_URL = "https://juejin.cn/"
JUEJIN_POST_URL_PREFIX = "https://juejin.cn/post/"
JUEJIN_USER_URL_PREFIX = "https://juejin.cn/user/"
JUEJIN_ARTICLE_RANK_API = "https://api.juejin.cn/content_api/v1/content/article_rank"
JUEJIN_FEED_API = "https://api.juejin.cn/recommend_api/v1/article/recommend_cate_feed"
JUEJIN_SEARCH_API = "https://api.juejin.cn/search_api/v1/search"
POST_PATH_RE = re.compile(r"/post/(?P<content_id>\d+)")
AUTHOR_POSTS_PATH_RE = re.compile(r"/user/(?P<author_id>\d+)(?:/posts)?")
AUTHOR_ROOT_PATH_RE = re.compile(r"/user/(?P<author_id>\d+)")
JUEJIN_CHANNEL_CATEGORY_MAP = {
    "frontend": "6809637767543259144",
    "backend": "6809637769959178254",
    "android": "6809635626879549454",
    "ios": "6809635626661445640",
    "ai": "6809637773935378440",
    "career": "6809637776263217160",
    "freebie": "6809637771511070734",
}
JUEJIN_FEED_ROUTE_ALIASES = {
    "": "frontend",
    "feed": "frontend",
    "home": "frontend",
    "recommend": "frontend",
    "recommended": "frontend",
}


class _ScriptCollector(HTMLParser):
    """Collect inline script contents for SSR payload extraction."""

    def __init__(self) -> None:
        super().__init__()
        self.scripts: list[tuple[dict[str, str], str]] = []
        self._current_attrs: dict[str, str] | None = None
        self._current_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "script":
            self._current_attrs = {key: value or "" for key, value in attrs}
            self._current_parts = []

    def handle_data(self, data: str) -> None:
        if self._current_attrs is not None:
            self._current_parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "script" and self._current_attrs is not None:
            self.scripts.append((self._current_attrs, "".join(self._current_parts).strip()))
            self._current_attrs = None
            self._current_parts = []


def _current_iso() -> str:
    return datetime.now(tz=timezone.utc).astimezone().isoformat()


def get_timeout_seconds() -> float:
    raw = os.getenv("JUEJIN_MCP_TIMEOUT_SECONDS", "30").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("JUEJIN_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("JUEJIN_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_user_agent() -> str:
    value = os.getenv("JUEJIN_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36 "
        f"Astron-Juejin-MCP/{__version__}"
    )


def clean_text(value: Any) -> str:
    return " ".join(str(value or "").replace("\xa0", " ").split())


def _first_text(*values: Any) -> str:
    for value in values:
        if value is None:
            continue
        text = clean_text(str(value))
        if text:
            return text
    return ""


def _to_int(value: Any) -> int | None:
    if value in (None, "") or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    digits = re.sub(r"[^\d]", "", str(value))
    return int(digits) if digits else None


def _normalize_limit(limit: int, *, maximum: int = 50) -> int:
    value = _to_int(limit)
    if value is None:
        return 20
    return max(1, min(value, maximum))


def _normalize_cursor(cursor: str) -> str:
    normalized = clean_text(cursor)
    if not normalized:
        return "0"
    return normalized if normalized.isdigit() else "0"


def _contains_keyword(item: dict[str, Any], keyword: str) -> bool:
    normalized_keyword = clean_text(keyword).lower()
    if not normalized_keyword:
        return False
    haystack = " ".join(
        [
            clean_text(item.get("title", "")),
            clean_text(item.get("summary", "")),
            clean_text(item.get("content", "")),
            clean_text(item.get("author_name", "")),
        ]
    ).lower()
    return normalized_keyword in haystack


def _normalize_url(url: str) -> str:
    text = clean_text(url)
    if not text:
        return ""
    if text.startswith("//"):
        return f"https:{text}"
    if text.startswith("/"):
        return urljoin(JUEJIN_BASE_URL, text)
    return text


def _normalize_count(text: str) -> int | None:
    value = clean_text(text)
    if not value:
        return None
    if value.endswith("k") and value[:-1].replace(".", "", 1).isdigit():
        return int(float(value[:-1]) * 1000)
    if value.endswith("w") and value[:-1].replace(".", "", 1).isdigit():
        return int(float(value[:-1]) * 10_000)
    return _to_int(value)


def _normalize_time(value: Any) -> str:
    if value in (None, ""):
        return ""
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return ""
        if re.fullmatch(r"\d{10,13}", stripped):
            return _unix_to_iso(stripped)
        try:
            return datetime.fromisoformat(stripped.replace("Z", "+00:00")).astimezone().isoformat()
        except ValueError:
            return stripped
    if isinstance(value, (int, float)):
        return _unix_to_iso(int(value))
    return str(value)


def _unix_to_iso(value: int | str | None) -> str:
    if value in (None, ""):
        return ""
    try:
        timestamp = int(value)
    except (TypeError, ValueError):
        return ""
    if timestamp > 1_000_000_000_000:
        timestamp = int(timestamp / 1000)
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone().isoformat()


def _strip_html(fragment: str) -> str:
    text = re.sub(r"<script.*?</script>", " ", fragment, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    return clean_text(html_lib.unescape(text))


def _resolve_feed_channel(channel: str = "") -> str:
    value = (channel or "").strip().lower()
    if value.startswith(("http://", "https://")):
        path = urlparse(value).path.strip("/")
        value = path.split("/", 1)[0] if path else ""
    elif value.startswith("/"):
        value = value.strip("/").split("/", 1)[0]
    resolved = JUEJIN_FEED_ROUTE_ALIASES.get(value, value)
    return resolved if resolved in JUEJIN_CHANNEL_CATEGORY_MAP else JUEJIN_FEED_ROUTE_ALIASES[""]


def _is_valid_feed_channel(channel: str = "") -> bool:
    value = (channel or "").strip().lower()
    if not value:
        return True
    if value.startswith(("http://", "https://")):
        path = urlparse(value).path.strip("/")
        value = path.split("/", 1)[0] if path else ""
    elif value.startswith("/"):
        value = value.strip("/").split("/", 1)[0]
    resolved = JUEJIN_FEED_ROUTE_ALIASES.get(value, value)
    return resolved in JUEJIN_CHANNEL_CATEGORY_MAP


def _resolve_feed_category_id(channel: str = "") -> str:
    return JUEJIN_CHANNEL_CATEGORY_MAP[_resolve_feed_channel(channel)]


def _build_feed_url(channel: str = "") -> str:
    return f"{JUEJIN_HOME_URL}{_resolve_feed_channel(channel)}"


def _build_content_url(url: str, content_id: str) -> str:
    if clean_text(url):
        return clean_text(url)
    if clean_text(content_id):
        return f"{JUEJIN_POST_URL_PREFIX}{clean_text(content_id)}"
    return JUEJIN_HOME_URL


def _build_author_url(url: str, author_id: str) -> str:
    if clean_text(url):
        return clean_text(url)
    if clean_text(author_id):
        return f"{JUEJIN_USER_URL_PREFIX}{clean_text(author_id)}"
    return JUEJIN_HOME_URL


def _build_author_posts_url(url: str, author_id: str) -> str:
    normalized = clean_text(url)
    if normalized.endswith("/posts"):
        return normalized
    if normalized:
        match = re.search(r"(https://juejin\.cn/user/\d+)", normalized)
        if match:
            return f"{match.group(1)}/posts"
    if clean_text(author_id):
        return f"{JUEJIN_USER_URL_PREFIX}{clean_text(author_id)}/posts"
    return JUEJIN_HOME_URL


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    if capability == "search":
        items = [
            item
            for item in items
            if (clean_text(str(item.get("result_type", ""))) or "real") == "real"
            and bool(clean_text(str(item.get("content", ""))))
        ]
    item_types = [clean_text(str(item.get("result_type", ""))) or "real" for item in items]
    status = "empty" if not items else ("ok" if any(item_type == "real" for item_type in item_types) else "degraded")
    result_type = ""
    if item_types:
        if any(item_type == "real" for item_type in item_types):
            result_type = "real"
        else:
            result_type = item_types[0] if len(set(item_types)) == 1 else "mixed"
    result = {
        "platform": "juejin",
        "capability": capability,
        "status": status,
        "update_time": _current_iso(),
        "items": items,
        "paging": {
            "has_more": bool(has_more),
            "next_cursor": next_cursor if has_more else "",
        },
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(item.get("result_type", ""))) or "real" if item else ""
    result = {
        "platform": "juejin",
        "status": "empty" if not item else ("degraded" if result_type != "real" else "ok"),
        "item": item,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(author.get("result_type", ""))) or "real" if author else ""
    result = {
        "platform": "juejin",
        "status": "empty" if not author else ("degraded" if result_type != "real" else "ok"),
        "author": author,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def create_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": get_user_agent(),
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        }
    )
    return session


def _request_json_get(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any],
    referer: str,
) -> dict[str, Any]:
    try:
        response = session.get(
            url,
            params=params,
            headers={
                "Referer": referer,
                "Accept": "application/json, text/plain, */*",
            },
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc
    if response.status_code != 200:
        raise RuntimeError(f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}")
    payload = response.json()
    if not isinstance(payload, dict):
        raise RuntimeError(f"调用失败: 响应不是对象; url={response.url}")
    if payload.get("err_no") not in (0, None):
        raise RuntimeError(f"调用失败: {payload.get('err_msg') or payload.get('err_no')}")
    return payload


def _request_json_post(
    session: requests.Session,
    url: str,
    *,
    payload: dict[str, Any],
    referer: str,
) -> dict[str, Any]:
    try:
        response = session.post(
            url,
            json=payload,
            headers={
                "Referer": referer,
                "Origin": JUEJIN_BASE_URL,
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json",
            },
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc
    if response.status_code != 200:
        raise RuntimeError(f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}")
    payload_obj = response.json()
    if not isinstance(payload_obj, dict):
        raise RuntimeError(f"调用失败: 响应不是对象; url={response.url}")
    if payload_obj.get("err_no") not in (0, None):
        raise RuntimeError(f"调用失败: {payload_obj.get('err_msg') or payload_obj.get('err_no')}")
    return payload_obj


def _b64pad(value: str) -> str:
    return value + "=" * (-len(value) % 4)


def _solve_waf_challenge(html: str) -> str:
    match = re.search(r'cs="([^"]+)"', html)
    if not match:
        raise RuntimeError("掘金 WAF challenge 页面缺少 cs 参数")
    challenge = json.loads(base64.b64decode(_b64pad(match.group(1))))
    prefix = base64.b64decode(_b64pad(challenge["v"]["a"]))
    expect = base64.b64decode(_b64pad(challenge["v"]["c"])).hex()
    answer: int | None = None
    for index in range(1_000_001):
        if hashlib.sha256(prefix + str(index).encode()).hexdigest() == expect:
            answer = index
            break
    if answer is None:
        raise RuntimeError("掘金 WAF challenge 求解失败")
    challenge["d"] = base64.b64encode(str(answer).encode()).decode()
    return base64.b64encode(json.dumps(challenge, separators=(",", ":")).encode()).decode()


def _request_html(session: requests.Session, url: str) -> str:
    headers = {
        "Referer": JUEJIN_HOME_URL,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }
    try:
        response = session.get(url, headers=headers, timeout=get_timeout_seconds())
    except requests.RequestException as exc:
        raise RuntimeError(f"掘金页面抓取失败: {exc}") from exc

    if response.status_code != 200:
        raise RuntimeError(f"掘金页面抓取失败: HTTP {response.status_code}; url={response.url}")

    html = response.text
    if "Please wait..." in html and "_wafchallengeid" not in session.cookies:
        cookie_value = _solve_waf_challenge(html)
        session.cookies.set("_wafchallengeid", cookie_value, domain="juejin.cn", path="/")
        try:
            response = session.get(url, headers=headers, timeout=get_timeout_seconds())
        except requests.RequestException as exc:
            raise RuntimeError(f"掘金页面二次抓取失败: {exc}") from exc
        if response.status_code != 200:
            raise RuntimeError(f"掘金页面二次抓取失败: HTTP {response.status_code}; url={response.url}")
        html = response.text
    return html


def extract_json_block(html: str, marker: str) -> dict[str, Any] | None:
    index = html.find(marker)
    if index < 0 and marker.endswith("="):
        index = html.find(marker[:-1])
    if index < 0:
        return None
    start = html.find("{", index)
    if start < 0:
        return None
    depth = 0
    in_string = False
    escaped = False
    for pos in range(start, len(html)):
        char = html[pos]
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                block = html[start : pos + 1]
                try:
                    return json.loads(block)
                except json.JSONDecodeError:
                    return None
    return None


def extract_payloads(html: str) -> list[Any]:
    collector = _ScriptCollector()
    collector.feed(html)
    payloads: list[Any] = []
    for attrs, content in collector.scripts:
        if not content:
            continue
        script_type = attrs.get("type", "").lower()
        script_id = attrs.get("id", "")
        if script_type in {"application/json", "application/ld+json"} or script_id == "__NEXT_DATA__":
            try:
                payloads.append(json.loads(content))
            except json.JSONDecodeError:
                pass
        for marker in (
            "window.__INITIAL_STATE__",
            "window.__NEXT_DATA__",
            "window.__NUXT__",
            "__INITIAL_STATE__",
            "__NEXT_DATA__",
            "__NUXT__",
        ):
            extracted = extract_json_block(content, marker)
            if extracted is not None:
                payloads.append(extracted)
        if content.startswith("{") and content.endswith("}"):
            try:
                payloads.append(json.loads(content))
            except json.JSONDecodeError:
                pass
    return payloads


def _meta_value(html: str, *, attr_name: str, attr_value: str, key: str = "content") -> str:
    pattern = re.compile(
        rf'<meta[^>]*{attr_name}="{re.escape(attr_value)}"[^>]*{key}="(?P<value>[^"]*)"',
        re.I | re.S,
    )
    match = pattern.search(html)
    return clean_text(html_lib.unescape(match.group("value"))) if match else ""


def _extract_block(html: str, class_name: str) -> str:
    pattern = re.compile(
        rf'<(?P<tag>\w+)[^>]*class="[^"]*\b{re.escape(class_name)}\b[^"]*"[^>]*>(?P<body>.*?)</(?P=tag)>',
        re.S | re.I,
    )
    match = pattern.search(html)
    return match.group("body") if match else ""


def _extract_first_img_src(html: str, class_name: str) -> str:
    pattern = re.compile(
        rf'<img[^>]*class="[^"]*\b{re.escape(class_name)}\b[^"]*"[^>]*src="(?P<src>[^"]+)"',
        re.S | re.I,
    )
    match = pattern.search(html)
    return clean_text(html_lib.unescape(match.group("src"))) if match else ""


def _extract_href_id(href: str | None, pattern: re.Pattern[str]) -> str:
    if not href:
        return ""
    match = pattern.search(href)
    return match.group(match.lastgroup or 1) if match else ""


def _extract_relative_time(html: str) -> str:
    for match in re.finditer(r'<li[^>]*class="item"[^>]*>\s*(?P<text>[^<]+?)\s*</li>', html, re.S | re.I):
        text = clean_text(match.group("text"))
        if re.search(r"\d+(?:\.\d+)?(?:k|K|w|W)|\d+年前|\d+月前|\d+天前|刚刚", text):
            return text
    return ""


def _extract_follow_count(html: str, label: str) -> int | None:
    pattern = re.compile(
        rf'<a[^>]*class="[^"]*\bfollow-item\b[^"]*"[^>]*>.*?<div[^>]*class="item-title"[^>]*>\s*{re.escape(label)}\s*</div>.*?<div[^>]*class="item-count"[^>]*>\s*(?P<count>[^<]+?)\s*</div>',
        re.S | re.I,
    )
    match = pattern.search(html)
    return _normalize_count(match.group("count")) if match else None


def _extract_profile_stat_count(html: str, label: str) -> int | None:
    pattern = re.compile(
        rf'<a[^>]*class="[^"]*\bstat-item\b[^"]*"[^>]*>.*?<div[^>]*>\s*{re.escape(label)}\s*</div>.*?<span[^>]*class="count"[^>]*>\s*(?P<count>[^<]+?)\s*</span>',
        re.S | re.I,
    )
    match = pattern.search(html)
    return _normalize_count(match.group("count")) if match else None


def _extract_post_cards(html: str, *, author_name: str = "", author_id: str = "") -> list[dict[str, Any]]:
    cards: list[dict[str, Any]] = []
    pattern = re.compile(
        r'<a[^>]*href="(?P<href>/post/\d+(?:\?[^"]*)?)"[^>]*class="[^"]*\bjj-link\b[^"]*\btitle\b[^"]*"[^>]*>'
        r'(?P<body>.*?)</a>',
        re.S | re.I,
    )
    for rank, match in enumerate(pattern.finditer(html), start=1):
        href = match.group("href")
        card_start = max(0, match.start() - 900)
        card_end = min(len(html), match.end() + 2600)
        snippet = html[card_start:card_end]
        title = _strip_html(match.group("body"))
        if not title:
            continue
        content_id = href.rsplit("/", 1)[-1].split("?", 1)[0]
        summary_match = re.search(
            r'<div[^>]*class="[^"]*\b(?:abstract|abstract-row)\b[^"]*"[^>]*>(?P<body>.*?)</div>',
            snippet,
            re.S | re.I,
        )
        view_match = re.search(
            r'<li[^>]*class="[^"]*\bview\b[^"]*"[^>]*>.*?<span[^>]*>\s*(?P<count>[^<]+?)\s*</span>',
            snippet,
            re.S | re.I,
        )
        like_match = re.search(
            r'<li[^>]*class="[^"]*\blike\b[^"]*"[^>]*>.*?<span[^>]*>\s*(?P<count>[^<]+?)\s*</span>',
            snippet,
            re.S | re.I,
        )
        tags = [
            clean_text(tag)
            for tag in re.findall(r'<a[^>]*href="/tag/[^"]+"[^>]*>(?P<tag>.*?)</a>', snippet, re.S | re.I)
            if clean_text(tag)
        ]
        cards.append(
            {
                "id": content_id,
                "title": title,
                "summary": _strip_html(summary_match.group("body")) if summary_match else "",
                "content": _strip_html(summary_match.group("body")) if summary_match else "",
                "url": _normalize_url(href),
                "author_name": author_name,
                "author_id": author_id,
                "publish_time": _extract_relative_time(snippet),
                "rank": rank,
                "view_count": _normalize_count(view_match.group("count")) if view_match else None,
                "like_count": _normalize_count(like_match.group("count")) if like_match else None,
                "source_type": "post",
                "tags": tags,
            }
        )
    return cards


def _extract_author_profile_dom(html: str, *, url: str, author_id: str) -> dict[str, Any]:
    name = _first_text(
        _meta_value(html, attr_name="itemprop", attr_value="name"),
        _strip_html(_extract_block(html, "user-name")),
        _strip_html(_extract_block(html, "username")),
    )
    avatar = _first_text(
        _meta_value(html, attr_name="itemprop", attr_value="image"),
        _extract_first_img_src(html, "avatar-img"),
    )
    bio = _strip_html(_extract_block(html, "introduction"))
    following_count = _extract_follow_count(html, "关注了")
    follower_count = _extract_follow_count(html, "关注者")
    content_count = _extract_profile_stat_count(html, "文章")
    if content_count is None:
        content_count = _extract_profile_stat_count(html, "文章被阅读")
    return {
        "id": author_id,
        "name": name,
        "url": url,
        "avatar": _normalize_url(avatar),
        "bio": bio,
        "follower_count": follower_count,
        "following_count": following_count,
        "content_count": content_count,
    }


def _iter_dicts(value: Any) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    if isinstance(value, dict):
        result.append(value)
        for nested in value.values():
            result.extend(_iter_dicts(nested))
    elif isinstance(value, list):
        for item in value:
            result.extend(_iter_dicts(item))
    return result


def _find_best_mapping(payloads: list[Any], required_keys: set[str]) -> dict[str, Any] | None:
    best: dict[str, Any] | None = None
    best_score = 0
    for payload in payloads:
        for mapping in _iter_dicts(payload):
            score = sum(1 for key in required_keys if key in mapping)
            if score > best_score:
                best = mapping
                best_score = score
    return best


def _find_best_content_payload(payloads: list[Any]) -> dict[str, Any] | None:
    return _find_best_mapping(
        payloads,
        {"title", "content", "brief", "description", "summary", "author", "author_name", "author_id"},
    )


def _find_best_author_payload(payloads: list[Any]) -> dict[str, Any] | None:
    return _find_best_mapping(
        payloads,
        {"author", "user", "username", "name", "avatar", "bio", "followers", "following", "articles", "article_list"},
    )


def _find_author_articles(payloads: list[Any]) -> list[dict[str, Any]]:
    for payload in payloads:
        for mapping in _iter_dicts(payload):
            for key in ("article_list", "articles", "content_list", "list", "posts"):
                value = mapping.get(key)
                if isinstance(value, list):
                    return [item for item in value if isinstance(item, dict)]
    return []


def _extract_author(data: dict[str, Any]) -> dict[str, Any]:
    for key in ("author", "user", "creator"):
        value = data.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _extract_author_id_from_url(url: str) -> str:
    match = AUTHOR_POSTS_PATH_RE.search(url) or AUTHOR_ROOT_PATH_RE.search(url)
    return match.group("author_id") if match else ""


def _build_content_item(data: dict[str, Any], *, url: str, content_id: str) -> dict[str, Any]:
    author = _extract_author(data)
    item_id = _first_text(data.get("id"), data.get("article_id"), data.get("uuid"), content_id)
    title = _first_text(data.get("headline"), data.get("title"), data.get("brief"), data.get("summary"), data.get("seo_title"))
    summary = _first_text(data.get("brief"), data.get("summary"), data.get("description"))
    content = _first_text(data.get("content"), data.get("html"), summary)
    publish_time = data.get("publish_time") or data.get("created_at") or data.get("created_time") or data.get("datePublished") or data.get("dateModified")
    image = data.get("image")
    cover = ""
    if isinstance(image, list) and image:
        cover = _first_text(image[0])
    elif isinstance(image, str):
        cover = _first_text(image)
    return {
        "id": item_id or url.rsplit("/", 1)[-1],
        "title": title,
        "summary": summary,
        "content": content,
        "url": _first_text(data.get("url"), data.get("share_url"), url) or url,
        "cover": _first_text(cover, data.get("cover"), data.get("screenshot"), data.get("thumbnail")),
        "author_name": _first_text(author.get("username"), author.get("name"), data.get("author_name")),
        "author_id": _first_text(author.get("user_id"), author.get("id"), data.get("author_id")),
        "publish_time": _normalize_time(publish_time),
        "rank": _to_int(data.get("rank")) or 0,
        "hot_value": _to_int(data.get("hot_value") or data.get("hot_index")),
        "hot_text": _first_text(data.get("hot_text"), data.get("hot_index")),
        "comment_count": _to_int(data.get("comment_count") or data.get("comments_count")),
        "like_count": _to_int(data.get("digg_count") or data.get("like_count") or data.get("likes") or data.get("praise_count")),
        "share_count": _to_int(data.get("share_count") or data.get("share")),
        "collect_count": _to_int(data.get("collect_count") or data.get("favorite_count")),
        "view_count": _to_int(data.get("view_count") or data.get("read_count") or data.get("views")),
        "source_type": _first_text(data.get("type"), data.get("source_type")) or "post",
        "tags": [clean_text(tag) for tag in data.get("tags", []) if clean_text(tag)] if isinstance(data.get("tags"), list) else [],
    }


def _parse_content_detail_dom(html: str, *, url: str, content_id: str) -> dict[str, Any]:
    title = _strip_html(_extract_block(html, "article-title"))
    author_name = _strip_html(_extract_block(html, "author-name"))
    author_href_match = re.search(r'<a[^>]*class="[^"]*\busername\b[^"]*"[^>]*href="(?P<href>[^"]+)"', html, re.S | re.I)
    author_href = author_href_match.group("href") if author_href_match else ""
    author_id = _extract_author_id_from_url(author_href) if author_href else ""
    time_match = re.search(r'<time[^>]*datetime="(?P<dt>[^"]+)"', html, re.S | re.I)
    read_count_match = re.search(r'<span[^>]*class="views-count"[^>]*>\s*(?P<count>[^<]+)\s*</span>', html, re.S | re.I)
    article_match = re.search(r'<article[^>]*>(?P<body>.*?)</article>', html, re.S | re.I)
    article_text = _strip_html(article_match.group("body")) if article_match else ""
    content = article_text or _meta_value(html, attr_name="name", attr_value="description")
    return {
        "id": content_id or url.rsplit("/", 1)[-1],
        "title": title,
        "summary": content,
        "content": content,
        "url": url,
        "cover": "",
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": _first_text(time_match.group("dt") if time_match else ""),
        "rank": 1,
        "hot_value": None,
        "hot_text": "",
        "comment_count": None,
        "like_count": None,
        "share_count": None,
        "collect_count": None,
        "view_count": _normalize_count(read_count_match.group("count")) if read_count_match else None,
        "source_type": "post",
        "tags": [],
    }


def _merge_content_items(dom_item: dict[str, Any], payload_item: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": payload_item.get("id") or dom_item.get("id", ""),
        "title": payload_item.get("title") or dom_item.get("title", ""),
        "summary": payload_item.get("summary") or dom_item.get("summary", ""),
        "content": payload_item.get("content") or dom_item.get("content", ""),
        "url": payload_item.get("url") or dom_item.get("url", ""),
        "cover": payload_item.get("cover") or dom_item.get("cover", ""),
        "author_name": payload_item.get("author_name") or dom_item.get("author_name", ""),
        "author_id": payload_item.get("author_id") or dom_item.get("author_id", ""),
        "publish_time": payload_item.get("publish_time") or dom_item.get("publish_time", ""),
        "rank": payload_item.get("rank") or dom_item.get("rank", 1),
        "hot_value": payload_item.get("hot_value") or dom_item.get("hot_value"),
        "hot_text": payload_item.get("hot_text") or dom_item.get("hot_text", ""),
        "comment_count": payload_item.get("comment_count") or dom_item.get("comment_count"),
        "like_count": payload_item.get("like_count") or dom_item.get("like_count"),
        "share_count": payload_item.get("share_count") or dom_item.get("share_count"),
        "collect_count": payload_item.get("collect_count") or dom_item.get("collect_count"),
        "view_count": payload_item.get("view_count") or dom_item.get("view_count"),
        "source_type": payload_item.get("source_type") or dom_item.get("source_type", "post"),
        "tags": payload_item.get("tags") or dom_item.get("tags", []),
    }


def _build_author_profile(data: dict[str, Any], *, url: str, author_id: str) -> dict[str, Any]:
    author = _extract_author(data) or data
    return {
        "id": _first_text(author.get("user_id"), author.get("id"), author_id) or url.rsplit("/", 1)[-1],
        "name": _first_text(author.get("username"), author.get("name"), author.get("nickname")),
        "url": url,
        "avatar": _first_text(author.get("avatar"), author.get("avatar_large"), author.get("picture")),
        "bio": _first_text(author.get("bio"), author.get("description"), author.get("brief")),
        "follower_count": _to_int(author.get("followers") or author.get("follower_count")),
        "following_count": _to_int(author.get("following") or author.get("following_count")),
        "content_count": _to_int(author.get("article_count") or author.get("post_count") or author.get("content_count") or data.get("article_count")),
    }


def _merge_author_profiles(dom_profile: dict[str, Any], payload_profile: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": payload_profile.get("id") or dom_profile.get("id", ""),
        "name": payload_profile.get("name") or dom_profile.get("name", ""),
        "url": payload_profile.get("url") or dom_profile.get("url", ""),
        "avatar": payload_profile.get("avatar") or dom_profile.get("avatar", ""),
        "bio": payload_profile.get("bio") or dom_profile.get("bio", ""),
        "follower_count": payload_profile.get("follower_count") or dom_profile.get("follower_count"),
        "following_count": payload_profile.get("following_count") or dom_profile.get("following_count"),
        "content_count": payload_profile.get("content_count") or dom_profile.get("content_count"),
    }


def _build_author_content_items(payloads: list[Any], *, author_url: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    author_id = _extract_author_id_from_url(author_url)
    for index, raw in enumerate(_find_author_articles(payloads), start=1):
        author = _extract_author(raw)
        item_id = _first_text(raw.get("id"), raw.get("article_id"), raw.get("uuid"), index)
        item = {
            "id": item_id,
            "title": _first_text(raw.get("title"), raw.get("brief"), raw.get("summary")),
            "summary": _first_text(raw.get("brief"), raw.get("summary"), raw.get("description")),
            "content": _first_text(raw.get("content"), raw.get("brief"), raw.get("summary")),
            "url": _first_text(raw.get("url"), raw.get("share_url")) or f"{JUEJIN_POST_URL_PREFIX}{item_id}",
            "cover": _first_text(raw.get("cover"), raw.get("thumbnail")),
            "author_name": _first_text(author.get("username"), author.get("name"), raw.get("author_name")),
            "author_id": _first_text(author.get("user_id"), author.get("id"), raw.get("author_id"), author_id),
            "publish_time": _normalize_time(raw.get("publish_time") or raw.get("created_at") or raw.get("created_time")),
            "rank": index,
            "hot_value": None,
            "hot_text": "",
            "comment_count": _to_int(raw.get("comment_count")),
            "like_count": _to_int(raw.get("digg_count") or raw.get("like_count")),
            "share_count": None,
            "collect_count": _to_int(raw.get("collect_count") or raw.get("favorite_count")),
            "view_count": _to_int(raw.get("view_count") or raw.get("read_count")),
            "source_type": _first_text(raw.get("type"), raw.get("source_type")) or "post",
            "tags": [],
        }
        items.append(item)
    return items


def _build_author_content_item(raw: dict[str, Any], *, fallback_author_name: str, fallback_author_id: str) -> dict[str, Any]:
    item_id = _first_text(raw.get("id"), raw.get("article_id"), raw.get("uuid"))
    href = _first_text(raw.get("url")) or (f"{JUEJIN_POST_URL_PREFIX}{item_id}" if item_id else JUEJIN_BASE_URL)
    return {
        "id": item_id or href.rsplit("/", 1)[-1],
        "title": _first_text(raw.get("title"), raw.get("summary")),
        "summary": _first_text(raw.get("summary"), raw.get("title")),
        "content": _first_text(raw.get("content"), raw.get("summary"), raw.get("title")),
        "url": href,
        "cover": _first_text(raw.get("cover")),
        "author_name": _first_text(raw.get("author_name"), fallback_author_name),
        "author_id": _first_text(raw.get("author_id"), fallback_author_id),
        "publish_time": _first_text(raw.get("publish_time")),
        "rank": _to_int(raw.get("rank")) or 0,
        "hot_value": None,
        "hot_text": "",
        "comment_count": _to_int(raw.get("comment_count")),
        "like_count": _to_int(raw.get("like_count")),
        "share_count": None,
        "collect_count": _to_int(raw.get("collect_count")),
        "view_count": _to_int(raw.get("view_count")),
        "source_type": _first_text(raw.get("source_type")) or "post",
        "tags": raw.get("tags", []) if isinstance(raw.get("tags"), list) else [],
    }


def parse_content_detail_html(html: str, *, url: str, content_id: str) -> tuple[dict[str, Any], list[Any]]:
    payloads = extract_payloads(html)
    data = _find_best_content_payload(payloads)
    dom_item = _parse_content_detail_dom(html, url=url, content_id=content_id)
    if data is None:
        return dom_item, payloads
    item = _build_content_item(data, url=url, content_id=content_id)
    item["rank"] = 1
    return _merge_content_items(dom_item, item), payloads


def parse_author_profile_html(html: str, *, url: str, author_id: str) -> tuple[dict[str, Any], list[Any]]:
    payloads = extract_payloads(html)
    data = _find_best_author_payload(payloads)
    dom_profile = _extract_author_profile_dom(html, url=url, author_id=author_id)
    if data is None:
        return dom_profile, payloads
    return _merge_author_profiles(dom_profile, _build_author_profile(data, url=url, author_id=author_id)), payloads


def parse_author_content_list_html(html: str, *, url: str, limit: int) -> tuple[list[dict[str, Any]], dict[str, Any], list[Any]]:
    payloads = extract_payloads(html)
    author_id = _extract_author_id_from_url(url)
    author_profile = _extract_author_profile_dom(html, url=url, author_id=author_id)
    items = [
        _build_author_content_item(card, fallback_author_name=author_profile.get("name", ""), fallback_author_id=author_id)
        for card in _extract_post_cards(html, author_name=author_profile.get("name", ""), author_id=author_id)
    ]
    if not items:
        items = _build_author_content_items(payloads, author_url=url)
    has_more = len(items) > limit
    return items[:limit], {"has_more": has_more, "next_cursor": ""}, payloads


def parse_hot_list_json(payload: dict[str, Any], *, limit: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    raw_items = payload.get("data") or []
    items: list[dict[str, Any]] = []
    for rank, entry in enumerate(raw_items, start=1):
        if not isinstance(entry, dict):
            continue
        content = entry.get("content") if isinstance(entry.get("content"), dict) else {}
        counter = entry.get("content_counter") if isinstance(entry.get("content_counter"), dict) else {}
        author = entry.get("author") if isinstance(entry.get("author"), dict) else {}
        content_id = _first_text(content.get("content_id"), content.get("article_id"), content.get("id"))
        if not content_id:
            continue
        item = _build_content_item(
            {
                "id": content_id,
                "article_id": content_id,
                "title": _first_text(content.get("title"), content.get("brief")),
                "brief": _first_text(content.get("brief")),
                "content": _first_text(content.get("brief")),
                "url": f"{JUEJIN_POST_URL_PREFIX}{content_id}",
                "author": {
                    "user_id": _first_text(author.get("user_id"), content.get("author_id")),
                    "username": _first_text(author.get("name")),
                    "avatar": _first_text(author.get("avatar")),
                },
                "publish_time": _first_text(content.get("ctime"), content.get("mtime")),
                "comment_count": _to_int(counter.get("comment_count")),
                "like_count": _to_int(counter.get("like")),
                "collect_count": _to_int(counter.get("collect")),
                "view_count": _to_int(counter.get("view")),
                "source_type": "article",
                "tags": [clean_text(tag) for tag in (content.get("tag_ids") or []) if clean_text(tag)],
                "rank": rank,
                "hot_value": _to_int(counter.get("hot_rank")),
                "hot_text": _first_text(counter.get("hot_rank")),
                "raw": entry,
            },
            url=f"{JUEJIN_POST_URL_PREFIX}{content_id}",
            content_id=content_id,
        )
        item["rank"] = rank
        items.append(item)
        if len(items) >= limit:
            break
    return items, {"has_more": len(raw_items) > len(items), "next_cursor": ""}


def parse_feed_json(payload: dict[str, Any], *, channel: str, limit: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    raw_items = payload.get("data") or []
    items: list[dict[str, Any]] = []
    for rank, entry in enumerate(raw_items, start=1):
        if not isinstance(entry, dict):
            continue
        article = entry.get("article_info") if isinstance(entry.get("article_info"), dict) else {}
        author = entry.get("author_user_info") if isinstance(entry.get("author_user_info"), dict) else {}
        tags = entry.get("tags") if isinstance(entry.get("tags"), list) else []
        category = entry.get("category") if isinstance(entry.get("category"), dict) else {}
        article_id = _first_text(article.get("article_id"), article.get("id"))
        if not article_id:
            continue
        item = _build_content_item(
            {
                "id": article_id,
                "article_id": article_id,
                "title": _first_text(article.get("title")),
                "brief": _first_text(article.get("brief_content")),
                "content": _first_text(article.get("web_html_content"), article.get("brief_content"), article.get("mark_content")),
                "url": f"{JUEJIN_POST_URL_PREFIX}{article_id}",
                "author": {
                    "user_id": _first_text(author.get("user_id")),
                    "username": _first_text(author.get("user_name")),
                    "avatar": _first_text(author.get("avatar_large")),
                    "description": _first_text(author.get("description")),
                },
                "publish_time": _first_text(article.get("rtime"), article.get("ctime")),
                "comment_count": _to_int(article.get("comment_count")),
                "like_count": _to_int(article.get("digg_count")),
                "collect_count": _to_int(article.get("collect_count")),
                "view_count": _to_int(article.get("view_count")),
                "source_type": _first_text(category.get("category_name"), channel) or "article",
                "tags": [clean_text(tag.get("tag_name")) for tag in tags if isinstance(tag, dict) and clean_text(tag.get("tag_name"))],
                "rank": rank,
                "raw": entry,
            },
            url=f"{JUEJIN_POST_URL_PREFIX}{article_id}",
            content_id=article_id,
        )
        item["rank"] = rank
        items.append(item)
        if len(items) >= limit:
            break
    return items, {"has_more": bool(payload.get("has_more")), "next_cursor": _first_text(payload.get("cursor"))}


def parse_search_json(payload: dict[str, Any], *, limit: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    raw_items = payload.get("data") or []
    items: list[dict[str, Any]] = []
    for rank, entry in enumerate(raw_items, start=1):
        if not isinstance(entry, dict) or entry.get("result_type") != 2:
            continue
        model = entry.get("result_model") if isinstance(entry.get("result_model"), dict) else {}
        article = model.get("article_info") if isinstance(model.get("article_info"), dict) else {}
        author = model.get("author_user_info") if isinstance(model.get("author_user_info"), dict) else {}
        tags = model.get("tags") if isinstance(model.get("tags"), list) else []
        article_id = _first_text(article.get("article_id"), article.get("id"))
        if not article_id:
            continue
        item = _build_content_item(
            {
                "id": article_id,
                "article_id": article_id,
                "title": _first_text(article.get("title")),
                "brief": _first_text(article.get("brief_content")),
                "content": _first_text(article.get("web_html_content"), article.get("mark_content"), article.get("brief_content")),
                "url": f"{JUEJIN_POST_URL_PREFIX}{article_id}",
                "author": {
                    "user_id": _first_text(author.get("user_id")),
                    "username": _first_text(author.get("user_name")),
                    "avatar": _first_text(author.get("avatar_large")),
                    "description": _first_text(author.get("description")),
                },
                "publish_time": _first_text(article.get("rtime"), article.get("ctime")),
                "comment_count": _to_int(article.get("comment_count")),
                "like_count": _to_int(article.get("digg_count")),
                "collect_count": _to_int(article.get("collect_count")),
                "view_count": _to_int(article.get("view_count")),
                "source_type": "article",
                "tags": [clean_text(tag.get("tag_name")) for tag in tags if isinstance(tag, dict) and clean_text(tag.get("tag_name"))],
                "rank": rank,
                "hot_value": _to_int(article.get("hot_index")),
                "hot_text": _first_text(article.get("hot_index")),
                "raw": entry,
            },
            url=f"{JUEJIN_POST_URL_PREFIX}{article_id}",
            content_id=article_id,
        )
        item["rank"] = rank
        items.append(item)
        if len(items) >= limit:
            break
    return items, {"has_more": bool(payload.get("has_more")), "next_cursor": _first_text(payload.get("cursor"))}


def fetch_hot_list_data(*, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    safe_limit = _normalize_limit(limit)
    session = create_session()
    payload = _request_json_get(
        session,
        JUEJIN_ARTICLE_RANK_API,
        params={
            "category_id": "1",
            "type": "hot",
            "count": str(safe_limit),
            "from": "0",
            "aid": "2608",
            "uuid": "",
            "spider": "0",
        },
        referer=JUEJIN_HOME_URL,
    )
    items, paging = parse_hot_list_json(payload, limit=safe_limit)
    return _build_list_result("hot_list", items, {"payload": payload}, has_more=paging["has_more"], next_cursor=paging["next_cursor"])


def fetch_feed_list_data(*, channel: str, cursor: str, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    if not _is_valid_feed_channel(channel):
        return _build_list_result(
            "feed_list",
            [],
            {"reason": "invalid_channel", "channel": clean_text(channel)},
            has_more=False,
            next_cursor="",
        )
    safe_limit = _normalize_limit(limit)
    resolved_channel = _resolve_feed_channel(channel)
    session = create_session()
    payload = _request_json_post(
        session,
        JUEJIN_FEED_API,
        payload={
            "aid": "2608",
            "uuid": "",
            "spider": "0",
            "limit": safe_limit,
            "cursor": _normalize_cursor(cursor),
            "id_type": 2,
            "sort_type": 200,
            "cate_id": _resolve_feed_category_id(resolved_channel),
        },
        referer=_build_feed_url(resolved_channel),
    )
    items, paging = parse_feed_json(payload, channel=resolved_channel, limit=safe_limit)
    return _build_list_result("feed_list", items, {"channel": resolved_channel, "payload": payload}, has_more=paging["has_more"], next_cursor=paging["next_cursor"])


def fetch_search_content_data(*, query: str, cursor: str, limit: int) -> dict[str, Any]:
    keyword = clean_text(query)
    if not keyword:
        return _build_list_result(
            "search",
            [],
            {"query": "", "reason": "empty_query"},
            has_more=False,
            next_cursor="",
        )
    safe_limit = _normalize_limit(limit)
    session = create_session()
    payload = _request_json_get(
        session,
        JUEJIN_SEARCH_API,
        params={
            "aid": "2608",
            "uuid": "",
            "spider": "0",
            "query": keyword,
            "id_type": "0",
            "cursor": _normalize_cursor(cursor),
            "limit": str(safe_limit),
            "search_type": "0",
            "sort_type": "0",
            "version": "1",
        },
        referer=JUEJIN_HOME_URL,
    )
    items, paging = parse_search_json(payload, limit=safe_limit)
    if items and not any(_contains_keyword(item, keyword) for item in items):
        items = []
        paging = {"has_more": False, "next_cursor": ""}
    return _build_list_result("search", items, {"query": keyword, "payload": payload}, has_more=paging["has_more"], next_cursor=paging["next_cursor"])


def fetch_content_detail_data(*, content_id: str, url: str) -> dict[str, Any]:
    resolved_content_id = clean_text(content_id)
    if not resolved_content_id and clean_text(url):
        match = POST_PATH_RE.search(clean_text(url))
        resolved_content_id = match.group("content_id") if match else ""
    target_url = _build_content_url(url, resolved_content_id)
    if target_url == JUEJIN_HOME_URL:
        return _build_detail_result({}, {"reason": "empty_input"})
    session = create_session()
    try:
        html = _request_html(session, target_url)
    except RuntimeError:
        return _build_detail_result({}, {"reason": "content_not_found", "url": target_url})
    item, payloads = parse_content_detail_html(html, url=target_url, content_id=resolved_content_id)
    if not item.get("id") and not item.get("title"):
        return _build_detail_result({}, {"payloads": payloads, "url": target_url})
    return _build_detail_result(item, {"payloads": payloads, "url": target_url})


def fetch_author_profile_data(*, author_id: str, url: str) -> dict[str, Any]:
    resolved_author_id = clean_text(author_id)
    if not resolved_author_id and clean_text(url):
        match = AUTHOR_ROOT_PATH_RE.search(clean_text(url))
        resolved_author_id = match.group("author_id") if match else ""
    author_url = _build_author_url(url, resolved_author_id)
    posts_url = _build_author_posts_url(author_url, resolved_author_id)
    if posts_url == JUEJIN_HOME_URL:
        return _build_author_result({}, {"reason": "empty_input"})
    session = create_session()
    try:
        html = _request_html(session, posts_url)
    except RuntimeError:
        return _build_author_result({}, {"reason": "author_not_found", "url": author_url, "posts_url": posts_url})
    author, payloads = parse_author_profile_html(html, url=author_url, author_id=resolved_author_id)
    if not author.get("id") and not author.get("name"):
        return _build_author_result({}, {"payloads": payloads, "url": author_url, "posts_url": posts_url})
    return _build_author_result(author, {"payloads": payloads, "url": author_url, "posts_url": posts_url})


def fetch_author_content_list_data(*, author_id: str, url: str, cursor: str, limit: int) -> dict[str, Any]:
    del cursor
    resolved_author_id = clean_text(author_id)
    if not resolved_author_id and clean_text(url):
        match = AUTHOR_ROOT_PATH_RE.search(clean_text(url))
        resolved_author_id = match.group("author_id") if match else ""
    posts_url = _build_author_posts_url(url, resolved_author_id)
    if posts_url == JUEJIN_HOME_URL:
        return _build_list_result("author_content_list", [], {"reason": "empty_input"}, has_more=False, next_cursor="")
    safe_limit = _normalize_limit(limit)
    session = create_session()
    try:
        html = _request_html(session, posts_url)
    except RuntimeError:
        return _build_list_result("author_content_list", [], {"reason": "author_not_found", "url": posts_url}, has_more=False, next_cursor="")
    items, paging, payloads = parse_author_content_list_html(html, url=posts_url, limit=safe_limit)
    if not items:
        return _build_list_result("author_content_list", [], {"payloads": payloads, "url": posts_url}, has_more=False, next_cursor="")
    return _build_list_result("author_content_list", items, {"payloads": payloads, "url": posts_url}, has_more=paging["has_more"], next_cursor=paging["next_cursor"])


mcp = FastMCP(
    "JUEJIN_MCP",
    instructions=(
        "Astron Juejin MCP server，基于掘金公开 API 和公开页面提供公开内容工具能力，"
        "无需额外部署后端服务。"
    ),
)


@mcp.tool()
def get_hot_list(ctx: Context, limit: int = 20, refresh: bool = False) -> dict[str, Any]:
    """
    获取掘金热门文章榜。

    参数：
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_hot_list_data(limit=limit, refresh=refresh)


@mcp.tool()
def get_feed_list(
    ctx: Context,
    channel: str = "",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取掘金分类推荐流。

    参数：
    - channel: 分类频道，可选 `frontend`、`backend`、`android`、`ios`、`ai`、`career`、`freebie`。
    - cursor: 分页游标。
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_feed_list_data(channel=channel, cursor=cursor, limit=limit, refresh=refresh)


@mcp.tool()
def search_content(
    ctx: Context,
    query: str,
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    搜索掘金公开文章。

    参数：
    - query: 搜索关键词。
    - cursor: 分页游标。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_search_content_data(query=query, cursor=cursor, limit=limit)


@mcp.tool()
def get_content_detail(
    ctx: Context,
    content_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取掘金文章详情。

    参数：
    - content_id: 文章 ID。
    - url: 文章完整 URL。
    """
    del ctx
    return fetch_content_detail_data(content_id=content_id, url=url)


@mcp.tool()
def get_author_profile(
    ctx: Context,
    author_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取掘金作者主页。

    参数：
    - author_id: 作者 user ID。
    - url: 作者主页 URL。
    """
    del ctx
    return fetch_author_profile_data(author_id=author_id, url=url)


@mcp.tool()
def get_author_content_list(
    ctx: Context,
    author_id: str = "",
    url: str = "",
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    获取掘金作者文章列表。

    参数：
    - author_id: 作者 user ID。
    - url: 作者主页或文章列表 URL。
    - cursor: 兼容保留参数，当前未启用。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_author_content_list_data(author_id=author_id, url=url, cursor=cursor, limit=limit)


def main() -> None:
    """Run the MCP server over stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
