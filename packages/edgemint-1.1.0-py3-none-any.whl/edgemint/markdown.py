"""Minimal Markdown parser for the supported edgemint subset."""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass(slots=True)
class Inline:
    """One inline text segment with optional formatting or custom style."""

    text: str
    bold: bool = False
    italic: bool = False
    code: bool = False
    custom_style: str | None = None


@dataclass(slots=True)
class Block:
    """One block-level Markdown construct after parsing."""

    kind: str
    text: str = ""
    style: str | None = None
    level: int | None = None
    ordered: bool = False
    items: list[list[Inline]] = field(default_factory=list)
    rows: list[list[str]] = field(default_factory=list)
    inlines: list[Inline] = field(default_factory=list)


@dataclass(slots=True)
class MarkdownDocument:
    """Parsed Markdown document with metadata and ordered content blocks."""

    metadata: dict[str, str]
    blocks: list[Block]


INLINE_CUSTOM_STYLE_RE = re.compile(r"\[(?P<text>[^\]]+)\]\{custom-style=\"(?P<style>[^\"]+)\"\}")
INLINE_RE = re.compile(r"(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)")
LIST_RE = re.compile(r"^(?P<indent>\s*)(?P<marker>(?:-|\*|\+|\d+\.))\s+(?P<text>.+)$")
CUSTOM_STYLE_START_RE = re.compile(r"^:::\s+\{custom-style=\"(?P<style>[^\"]+)\"\}\s*$")
YAML_DELIM = "---"


def parse_markdown(text: str) -> MarkdownDocument:
    """Parse the supported edgemint Markdown subset into block structures."""
    lines = text.splitlines()
    metadata, index = _parse_metadata(lines)
    blocks: list[Block] = []
    while index < len(lines):
        line = lines[index]
        if not line.strip():
            index += 1
            continue
        custom_match = CUSTOM_STYLE_START_RE.match(line)
        if custom_match:
            style = custom_match.group("style")
            index += 1
            block_lines: list[str] = []
            while index < len(lines) and lines[index].strip() != ":::":
                block_lines.append(lines[index])
                index += 1
            index += 1
            block_text = "\n".join(block_lines).strip()
            if _is_table_block(block_lines):
                rows = [
                    _split_table_row(item) for item in block_lines if item.strip().startswith("|")
                ]
                if len(rows) >= 2:
                    blocks.append(Block(kind="table", style=style, rows=[rows[0], *rows[2:]]))
            else:
                # WHY: edgemint's authoring contract treats fenced custom-style
                # blocks as the explicit escape hatch for Word-native styles.
                blocks.append(_paragraph_or_heading(block_text, style=style))
            continue
        if line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            blocks.append(
                Block(
                    kind="heading",
                    text=line[level:].strip(),
                    level=level,
                    inlines=parse_inlines(line[level:].strip()),
                )
            )
            index += 1
            continue
        if LIST_RE.match(line):
            ordered = "." in LIST_RE.match(line).group("marker")
            items: list[list[Inline]] = []
            while index < len(lines):
                match = LIST_RE.match(lines[index])
                if not match:
                    break
                items.append(parse_inlines(match.group("text")))
                index += 1
            blocks.append(Block(kind="list", ordered=ordered, items=items))
            continue
        if line.strip().startswith("|") and _is_table_block(lines[index : index + 3]):
            table_lines: list[str] = []
            while index < len(lines) and lines[index].strip().startswith("|"):
                table_lines.append(lines[index])
                index += 1
            rows = [_split_table_row(item) for item in table_lines]
            blocks.append(Block(kind="table", rows=[rows[0], *rows[2:]]))
            continue
        paragraph_lines = [line]
        index += 1
        while index < len(lines) and lines[index].strip():
            paragraph_lines.append(lines[index])
            index += 1
        blocks.append(_paragraph_or_heading(" ".join(item.strip() for item in paragraph_lines)))
    return MarkdownDocument(metadata=metadata, blocks=blocks)


def parse_inlines(text: str) -> list[Inline]:
    """Parse inline formatting and custom-style spans from text."""
    segments: list[Inline] = []
    position = 0
    for match in INLINE_CUSTOM_STYLE_RE.finditer(text):
        if match.start() > position:
            segments.extend(_parse_basic_inlines(text[position : match.start()]))
        segments.append(Inline(text=match.group("text"), custom_style=match.group("style")))
        position = match.end()
    if position < len(text):
        segments.extend(_parse_basic_inlines(text[position:]))
    return [segment for segment in segments if segment.text]


def _parse_basic_inlines(text: str) -> list[Inline]:
    """Parse bold, italic, and code spans from plain text."""
    chunks: list[Inline] = []
    position = 0
    for match in INLINE_RE.finditer(text):
        if match.start() > position:
            chunks.append(Inline(text=text[position : match.start()]))
        token = match.group(0)
        if token.startswith("**"):
            chunks.append(Inline(text=token[2:-2], bold=True))
        elif token.startswith("*"):
            chunks.append(Inline(text=token[1:-1], italic=True))
        else:
            chunks.append(Inline(text=token[1:-1], code=True))
        position = match.end()
    if position < len(text):
        chunks.append(Inline(text=text[position:]))
    return chunks


def _parse_metadata(lines: list[str]) -> tuple[dict[str, str], int]:
    """Parse a leading YAML metadata block when present."""
    if not lines or lines[0].strip() != YAML_DELIM:
        return {}, 0
    metadata: dict[str, str] = {}
    index = 1
    while index < len(lines) and lines[index].strip() != YAML_DELIM:
        line = lines[index]
        if ":" in line:
            key, value = line.split(":", 1)
            metadata[key.strip()] = value.strip().strip('"')
        index += 1
    return metadata, min(index + 1, len(lines))


def _paragraph_or_heading(text: str, style: str | None = None) -> Block:
    """Create a paragraph block with inline content already parsed."""
    return Block(kind="paragraph", text=text, style=style, inlines=parse_inlines(text))


def _is_table_block(lines: list[str]) -> bool:
    """Return whether a line slice matches a simple pipe-table structure."""
    if len(lines) < 2:
        return False
    return (
        lines[0].strip().startswith("|")
        and re.match(r"^\|(?:\s*:?-+:?\s*\|)+$", lines[1].strip()) is not None
    )


def _split_table_row(line: str) -> list[str]:
    """Split a pipe-table row into individual cell strings."""
    return [cell.strip() for cell in line.strip().strip("|").split("|")]
