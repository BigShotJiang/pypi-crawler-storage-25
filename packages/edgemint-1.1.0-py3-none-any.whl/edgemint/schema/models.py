"""Core Pydantic models for edgemint."""

from __future__ import annotations

from enum import StrEnum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr


class StyleType(StrEnum):
    """The DOCX style families supported by edgemint."""

    PARAGRAPH = "paragraph"
    CHARACTER = "character"
    TABLE = "table"
    NUMBERING = "numbering"


class Alignment(StrEnum):
    """Paragraph alignment values normalized for JSON serialization."""

    LEFT = "LEFT"
    CENTER = "CENTER"
    RIGHT = "RIGHT"
    JUSTIFY = "JUSTIFY"
    DISTRIBUTE = "DISTRIBUTE"


class LineSpacingRule(StrEnum):
    """Line spacing rules normalized from OOXML values."""

    SINGLE = "SINGLE"
    ONE_POINT_FIVE = "ONE_POINT_FIVE"
    DOUBLE = "DOUBLE"
    AT_LEAST = "AT_LEAST"
    EXACTLY = "EXACTLY"
    MULTIPLE = "MULTIPLE"


class UnderlineType(StrEnum):
    """Underline variants supported by Word run properties."""

    NONE = "NONE"
    SINGLE = "SINGLE"
    DOUBLE = "DOUBLE"
    DOTTED = "DOTTED"
    DASH = "DASH"
    WAVE = "WAVE"
    THICK = "THICK"
    WORDS = "WORDS"


class BorderStyle(StrEnum):
    """Paragraph border styles supported by the current schema."""

    NONE = "none"
    SINGLE = "single"
    DOUBLE = "double"
    DOTTED = "dotted"
    DASHED = "dashed"
    THICK = "thick"
    TRIPLE = "triple"


class BorderProperties(BaseModel):
    """A single border edge definition normalized into points and hex colors."""

    model_config = ConfigDict(frozen=True)
    style: BorderStyle = BorderStyle.NONE
    width_pt: Optional[float] = None
    color: Optional[str] = None
    space_pt: Optional[float] = None


class Borders(BaseModel):
    """Paragraph border collection keyed by edge position."""

    model_config = ConfigDict(frozen=True)
    top: Optional[BorderProperties] = None
    bottom: Optional[BorderProperties] = None
    left: Optional[BorderProperties] = None
    right: Optional[BorderProperties] = None
    between: Optional[BorderProperties] = None


class TabStop(BaseModel):
    """A paragraph tab stop with position, alignment, and leader."""

    model_config = ConfigDict(frozen=True)
    position_pt: float
    alignment: str = "LEFT"
    leader: str = "NONE"


class FontSpec(BaseModel):
    """Theme font slot definition from `theme1.xml`."""

    model_config = ConfigDict(frozen=True)
    latin: Optional[str] = None
    ea: Optional[str] = None
    cs: Optional[str] = None
    ascii_theme: Optional[str] = None


class FontProperties(BaseModel):
    """Character-level style properties decompressed from OOXML."""

    model_config = ConfigDict(frozen=True)
    name: Optional[str] = None
    size_pt: Optional[float] = None
    bold: Optional[bool] = None
    italic: Optional[bool] = None
    underline: Optional[UnderlineType] = None
    strike: Optional[bool] = None
    double_strike: Optional[bool] = None
    color: Optional[str] = None
    highlight: Optional[str] = None
    superscript: Optional[bool] = None
    subscript: Optional[bool] = None
    small_caps: Optional[bool] = None
    all_caps: Optional[bool] = None
    spacing_pt: Optional[float] = None
    kern_pt: Optional[float] = None
    ascii_theme: Optional[str] = None
    cs_font: Optional[str] = None
    ea_font: Optional[str] = None


class ParagraphFormat(BaseModel):
    """Paragraph-level style properties decompressed from OOXML."""

    model_config = ConfigDict(frozen=True)
    alignment: Optional[Alignment] = None
    space_before_pt: Optional[float] = None
    space_after_pt: Optional[float] = None
    line_spacing: Optional[float] = None
    line_spacing_rule: Optional[LineSpacingRule] = None
    keep_with_next: Optional[bool] = None
    keep_together: Optional[bool] = None
    page_break_before: Optional[bool] = None
    widow_control: Optional[bool] = None
    indent_left_pt: Optional[float] = None
    indent_right_pt: Optional[float] = None
    indent_first_line_pt: Optional[float] = None
    indent_hanging_pt: Optional[float] = None
    tab_stops: Optional[list[TabStop]] = None
    borders: Optional[Borders] = None
    shading_color: Optional[str] = None
    bidi: Optional[bool] = None
    outline_level: Optional[int] = None


class ResolvedProperties(BaseModel):
    """Style properties after merging defaults, inheritance, and local values."""

    model_config = ConfigDict(frozen=True)
    paragraph_format: ParagraphFormat = Field(default_factory=ParagraphFormat)
    font: FontProperties = Field(default_factory=FontProperties)


class Style(BaseModel):
    """A single named DOCX style definition."""

    model_config = ConfigDict(frozen=True)
    style_id: str
    name: str
    name_locale: Optional[str] = None
    type: StyleType
    based_on: Optional[str] = None
    next_style: Optional[str] = None
    linked_style_id: Optional[str] = None
    is_builtin: bool = False
    is_quick_style: bool = False
    is_default: bool = False
    priority: Optional[int] = None
    paragraph_format: Optional[ParagraphFormat] = None
    font: Optional[FontProperties] = None
    resolved: Optional[ResolvedProperties] = None


class NumberingLevel(BaseModel):
    """One numbering level inside an abstract numbering definition."""

    model_config = ConfigDict(frozen=True)
    level: int
    num_fmt: str
    lvl_text: str
    start: int = 1
    indent_left_pt: Optional[float] = None
    hanging_pt: Optional[float] = None
    font: Optional[FontProperties] = None
    paragraph_style_id: Optional[str] = None


class NumberingDef(BaseModel):
    """A concrete numbering instance mapped to its abstract definition."""

    model_config = ConfigDict(frozen=True)
    num_id: int
    abstract_num_id: int
    levels: list[NumberingLevel]


class SectionProperties(BaseModel):
    """First-section layout properties projected into JSON."""

    model_config = ConfigDict(frozen=True)
    section_index: int = 0
    page_width_pt: Optional[float] = None
    page_height_pt: Optional[float] = None
    margin_top_pt: Optional[float] = None
    margin_bottom_pt: Optional[float] = None
    margin_left_pt: Optional[float] = None
    margin_right_pt: Optional[float] = None
    orientation: str = "portrait"
    columns: int = 1
    header_distance_pt: Optional[float] = None
    footer_distance_pt: Optional[float] = None
    start_type: Optional[str] = None


class HeaderFooter(BaseModel):
    """Raw header or footer XML plus its logical scope."""

    model_config = ConfigDict(frozen=True)
    type: str
    scope: str
    section_index: int = 0
    content_xml: str


class ThemeInfo(BaseModel):
    """Theme fonts and colors extracted from the document theme part."""

    model_config = ConfigDict(frozen=True)
    major_font: FontSpec = Field(default_factory=FontSpec)
    minor_font: FontSpec = Field(default_factory=FontSpec)
    colors: dict[str, str] = Field(default_factory=dict)


class DocDefaults(BaseModel):
    """Document-wide paragraph and run defaults from `w:docDefaults`."""

    model_config = ConfigDict(frozen=True)
    paragraph_format: ParagraphFormat = Field(default_factory=ParagraphFormat)
    font: FontProperties = Field(default_factory=FontProperties)


class CoreProperties(BaseModel):
    """Document metadata from `docProps/core.xml`."""

    model_config = ConfigDict(frozen=True)
    title: Optional[str] = None
    author: Optional[str] = None
    subject: Optional[str] = None
    keywords: Optional[str] = None
    description: Optional[str] = None
    last_modified_by: Optional[str] = None
    created: Optional[str] = None
    modified: Optional[str] = None


class MetaInfo(BaseModel):
    """Extraction metadata describing source, tool version, and defaults."""

    model_config = ConfigDict(frozen=True)
    source_file: str
    extracted_at: str
    tool_version: str = "0.1.0"
    default_styles: dict[str, str] = Field(default_factory=dict)
    pandoc_version: Optional[str] = None


class StyleSheet(BaseModel):
    """Root JSON payload for extracted document style state."""

    model_config = ConfigDict(frozen=True)
    schema_version: str = "edgemint/v1"
    meta: MetaInfo
    core_properties: Optional[CoreProperties] = None
    doc_defaults: Optional[DocDefaults] = None
    theme: ThemeInfo = Field(default_factory=ThemeInfo)
    styles: list[Style] = Field(default_factory=list)
    numbering_defs: list[NumberingDef] = Field(default_factory=list)
    section_properties: Optional[SectionProperties] = None
    sections: list[SectionProperties] = Field(default_factory=list)
    headers_footers: list[HeaderFooter] = Field(default_factory=list)
    raw_parts: dict[str, str] = Field(default_factory=dict)
    raw_binary_parts: dict[str, str] = Field(default_factory=dict)
    content_types_xml: Optional[str] = None
    _style_map: dict[str, Style] = PrivateAttr(default_factory=dict)

    def get_style(self, style_id: str) -> Style | None:
        """Return a style by identifier using a cached lookup map."""
        if not self._style_map:
            self._style_map.update({style.style_id: style for style in self.styles})
        return self._style_map.get(style_id)
