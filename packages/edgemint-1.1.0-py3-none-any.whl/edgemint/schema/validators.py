"""Single source of truth for unit conversions."""

from __future__ import annotations

EMU_PER_PT = 12700
TWIPS_PER_PT = 20
HALF_POINTS_PER_PT = 2
EMU_PER_INCH = 914400
PT_PER_INCH = 72
PT_PER_CM = 28.3465


def emu_to_pt(emu: int | None) -> float | None:
    return round(emu / EMU_PER_PT, 2) if emu is not None else None


def pt_to_emu(pt: float | None) -> int | None:
    return round(pt * EMU_PER_PT) if pt is not None else None


def twips_to_pt(twips: int | None) -> float | None:
    return round(twips / TWIPS_PER_PT, 2) if twips is not None else None


def pt_to_twips(pt: float | None) -> int | None:
    return round(pt * TWIPS_PER_PT) if pt is not None else None


def half_pt_to_pt(hp: int | None) -> float | None:
    return hp / HALF_POINTS_PER_PT if hp is not None else None


def pt_to_half_pt(pt: float | None) -> int | None:
    return round(pt * HALF_POINTS_PER_PT) if pt is not None else None


def eighth_pt_to_pt(ep: int | None) -> float | None:
    return ep / 8.0 if ep is not None else None
