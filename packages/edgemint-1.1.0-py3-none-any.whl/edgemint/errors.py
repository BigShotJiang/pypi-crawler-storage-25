"""Typed exceptions and exit codes for CLI control flow."""

from __future__ import annotations

from dataclasses import dataclass


class ExitCode:
    """Process exit codes exposed by the CLI contract."""

    SUCCESS = 0
    VALIDATION = 1
    FILE = 2
    SCHEMA = 3
    PANDOC = 4
    SECURITY = 5


@dataclass(slots=True)
class EdgemintError(Exception):
    """Base exception carrying a user-facing message and CLI exit code."""

    message: str
    exit_code: int = ExitCode.VALIDATION

    def __str__(self) -> str:
        """Return the user-facing error message."""
        return self.message


class FileError(EdgemintError):
    """Raised for missing, unreadable, or unwritable filesystem inputs."""

    def __init__(self, message: str) -> None:
        super().__init__(message, ExitCode.FILE)


class SecurityError(EdgemintError):
    """Raised when a DOCX archive violates edgemint safety rules."""

    def __init__(self, message: str) -> None:
        super().__init__(message, ExitCode.SECURITY)


class PandocError(EdgemintError):
    """Raised when Pandoc is required but unavailable or when it fails."""

    def __init__(self, message: str) -> None:
        super().__init__(message, ExitCode.PANDOC)


class SchemaError(EdgemintError):
    """Raised when a style sheet JSON file fails validation."""

    def __init__(self, message: str) -> None:
        super().__init__(message, ExitCode.SCHEMA)
