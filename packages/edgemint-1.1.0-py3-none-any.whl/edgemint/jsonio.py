"""JSON IO helpers."""

from __future__ import annotations

import json
from pathlib import Path

from pydantic import ValidationError

from edgemint.errors import FileError, SchemaError
from edgemint.schema.models import StyleSheet


def load_stylesheet(path: Path) -> StyleSheet:
    """Load and validate a style sheet JSON file."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise FileError(f"JSON file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SchemaError(f"Invalid JSON in {path}: {exc}") from exc
    try:
        return StyleSheet.model_validate(data)
    except ValidationError as exc:
        raise SchemaError(str(exc)) from exc


def dump_stylesheet(path: Path, stylesheet: StyleSheet) -> None:
    """Write a validated style sheet model to disk as formatted JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        stylesheet.model_dump_json(indent=2, exclude_none=True),
        encoding="utf-8",
    )
