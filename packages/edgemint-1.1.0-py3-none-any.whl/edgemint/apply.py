"""Markdown to DOCX rendering from a StyleSheet.

Flow:
    Markdown -> reference.docx -> Pandoc docx writer -> post-process
                  |                                   |
                  `-> exact style/theme parts         `-> section/meta/header sync

Fallback:
    If Pandoc is unavailable, render a reduced-fidelity document directly with
    python-docx so the CLI still functions in lightweight environments.
"""

from __future__ import annotations

import base64
import os
from enum import StrEnum
from pathlib import Path
from tempfile import NamedTemporaryFile, TemporaryDirectory
from zipfile import ZipFile

from docx import Document
from docx.enum.section import WD_ORIENTATION, WD_SECTION_START
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import (
    WD_ALIGN_PARAGRAPH,
    WD_LINE_SPACING,
    WD_TAB_ALIGNMENT,
    WD_TAB_LEADER,
    WD_UNDERLINE,
)
from docx.shared import Pt, RGBColor
from lxml import etree

from edgemint.errors import FileError, PandocError
from edgemint.markdown import Block, Inline, MarkdownDocument, parse_markdown
from edgemint.ooxml import NS, parse_xml, qn
from edgemint.pandoc import has_pandoc, run_pandoc
from edgemint.schema.models import (
    Alignment,
    FontProperties,
    HeaderFooter,
    LineSpacingRule,
    ParagraphFormat,
    StyleSheet,
    StyleType,
    UnderlineType,
)

STYLE_KIND_TO_DOCX = {
    StyleType.PARAGRAPH: WD_STYLE_TYPE.PARAGRAPH,
    StyleType.CHARACTER: WD_STYLE_TYPE.CHARACTER,
    StyleType.TABLE: WD_STYLE_TYPE.TABLE,
}

MARKDOWN_PANDOC_FORMAT = (
    "markdown"
    "+citations"
    "+tex_math_dollars"
    "+tex_math_single_backslash"
    "+tex_math_double_backslash"
    "+fenced_divs"
    "+bracketed_spans"
    "+yaml_metadata_block"
    "+raw_attribute"
)
PANDOC_PASSTHROUGH_PARTS = (
    "word/footnotes.xml",
    "word/_rels/footnotes.xml.rels",
    "word/endnotes.xml",
    "word/_rels/endnotes.xml.rels",
    "word/comments.xml",
    "word/_rels/comments.xml.rels",
)
PANDOC_PARAGRAPH_STYLE_ALIASES = {
    "FirstParagraph": "P0-Paragraph",
    "SourceCode": "C0-CodeBlock",
    "ImageCaption": "F0-FigureCaption",
    "CaptionedFigure": "F0-Figure",
    "Compact": "TS-Table",
}
PANDOC_RUN_STYLE_ALIASES = {
    "VerbatimChar": "CS-InlineCode",
}


class SourceFormat(StrEnum):
    """Supported content dialects accepted by `apply-styles`."""

    AUTO = "auto"
    MARKDOWN = "markdown"
    ASCIIDOC = "asciidoc"


def apply_stylesheet(
    markdown_path: Path,
    stylesheet: StyleSheet,
    output_path: Path,
    media_dir: Path | None = None,
    input_format: SourceFormat = SourceFormat.AUTO,
) -> None:
    """Apply a style sheet to Markdown and write the resulting DOCX."""
    if not markdown_path.exists():
        raise FileError(f"Markdown file not found: {markdown_path}")

    source_text = markdown_path.read_text(encoding="utf-8")
    resolved_format = _resolve_source_format(markdown_path, input_format)
    source = _load_source_document(source_text, resolved_format)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if has_pandoc():
        _apply_with_pandoc(
            markdown_path,
            stylesheet,
            source,
            output_path,
            media_dir,
            input_format=resolved_format,
        )
        return

    if resolved_format != SourceFormat.MARKDOWN:
        raise PandocError(
            "Pandoc is required for AsciiDoc input. Install `pandoc` or `edgemint[pandoc]`."
        )
    _apply_direct(markdown_path, stylesheet, source, output_path, media_dir)


def _apply_with_pandoc(
    markdown_path: Path,
    stylesheet: StyleSheet,
    source: MarkdownDocument,
    output_path: Path,
    media_dir: Path | None,
    input_format: SourceFormat,
) -> None:
    """Use Pandoc with a generated reference DOCX, then post-process the result."""
    with TemporaryDirectory(prefix="edgemint-") as temp_dir:
        temp_path = Path(temp_dir)
        reference_path = temp_path / "reference.docx"
        source_path = _prepare_pandoc_source(markdown_path, source, temp_path, input_format)
        raw_output_path = temp_path / "raw_output.docx"

        reference = _create_base_document(stylesheet, source)
        reference.save(reference_path)
        _inject_raw_parts(reference_path, stylesheet)

        pandoc_args = [
            str(source_path),
            "-f",
            _pandoc_input_format(input_format),
            "-t",
            "docx",
            "--citeproc",
            f"--reference-doc={reference_path}",
            f"--lua-filter={_filters_dir() / 'fix-lists.lua'}",
            f"--lua-filter={_filters_dir() / 'fix-styles.lua'}",
            "-o",
            str(raw_output_path),
        ]
        resource_path = _pandoc_resource_path(markdown_path, media_dir)
        if resource_path is not None:
            pandoc_args.extend(["--resource-path", resource_path])
        run_pandoc(pandoc_args)

        postprocessed = Document(raw_output_path)
        _configure_core_properties(postprocessed, source.metadata, stylesheet)
        _configure_section(postprocessed, stylesheet)
        _build_styles(postprocessed, stylesheet)
        _apply_headers_and_footers(postprocessed, stylesheet.headers_footers)
        postprocessed.save(output_path)
        _inject_raw_parts(output_path, stylesheet)
        _relink_pandoc_styles(output_path, stylesheet)
        _relink_list_paragraph_styles(raw_output_path, output_path, stylesheet)
        _preserve_generated_parts(raw_output_path, output_path)
        _inject_header_footer_parts(output_path, stylesheet.headers_footers)


def _apply_direct(
    markdown_path: Path,
    stylesheet: StyleSheet,
    source: MarkdownDocument,
    output_path: Path,
    media_dir: Path | None,
) -> None:
    """Render Markdown directly with python-docx when Pandoc is unavailable."""
    document = _create_base_document(stylesheet, source)
    for block in source.blocks:
        _render_block(document, block, media_dir)
    document.save(output_path)
    _inject_raw_parts(output_path, stylesheet)
    _inject_header_footer_parts(output_path, stylesheet.headers_footers)


def _create_base_document(stylesheet: StyleSheet, source: MarkdownDocument) -> Document:
    """Create an empty DOCX preloaded with metadata, section config, and styles."""
    document = Document()
    _configure_core_properties(document, source.metadata, stylesheet)
    _configure_sections(document, stylesheet)
    _build_styles(document, stylesheet)
    _prepare_header_footer_scopes(document, stylesheet.headers_footers)
    _apply_headers_and_footers(document, stylesheet.headers_footers)
    return document


def _filters_dir() -> Path:
    """Return the repository-local Lua filter directory used by Pandoc."""
    return Path(__file__).resolve().parents[2] / "filters"


def _resolve_source_format(path: Path, requested: SourceFormat) -> SourceFormat:
    """Resolve `auto` into a concrete source dialect using the file suffix."""
    if requested != SourceFormat.AUTO:
        return requested
    suffix = path.suffix.lower()
    if suffix in {".adoc", ".asciidoc", ".asc"}:
        return SourceFormat.ASCIIDOC
    return SourceFormat.MARKDOWN


def _pandoc_input_format(source_format: SourceFormat) -> str:
    """Return the Pandoc reader string for the selected source dialect."""
    if source_format == SourceFormat.ASCIIDOC:
        return "asciidoc"
    return MARKDOWN_PANDOC_FORMAT


def _load_source_document(source_text: str, source_format: SourceFormat) -> MarkdownDocument:
    """Load source metadata into the document model used by the apply pipeline.

    WHY: the reference DOCX and post-processing steps need metadata even before
    Pandoc runs. For Markdown we reuse the native parser; for AsciiDoc we load a
    narrow document-header view and leave body rendering to Pandoc.
    """
    if source_format == SourceFormat.ASCIIDOC:
        return MarkdownDocument(metadata=_parse_asciidoc_metadata(source_text), blocks=[])
    return parse_markdown(source_text)


def _prepare_pandoc_source(
    source_path: Path,
    source: MarkdownDocument,
    temp_dir: Path,
    source_format: SourceFormat,
) -> Path:
    """Write a Pandoc input file whose visible body excludes metadata boilerplate.

    WHY: edgemint already projects document metadata into DOCX core properties.
    Leaving YAML front matter or AsciiDoc document headers in the Pandoc input
    causes Pandoc to emit visible `Title`/`Author` paragraphs. Those style ids do
    not exist in many branded templates, including the Packt fixture, so Word
    falls back to default fonts and colors. Stripping metadata here makes the
    rendered body deterministic and keeps style ownership with the template.
    """
    body = _pandoc_body_source(source_path.read_text(encoding="utf-8"), source, source_format)
    prepared_path = temp_dir / f"source{source_path.suffix}"
    prepared_path.write_text(body, encoding="utf-8")
    return prepared_path


def _pandoc_body_source(
    source_text: str,
    source: MarkdownDocument,
    source_format: SourceFormat,
) -> str:
    """Return the source body that should be rendered by Pandoc.

    WHY: metadata is a package concern in edgemint, not an implicit visible page.
    The body writer should therefore receive only author-authored content blocks.
    """
    if not source.metadata:
        return source_text
    if source_format == SourceFormat.ASCIIDOC:
        return _strip_asciidoc_header(source_text)
    return _strip_markdown_metadata_block(source_text)


def _pandoc_resource_path(markdown_path: Path, media_dir: Path | None) -> str | None:
    """Return a stable Pandoc resource search path for rewritten temp inputs."""
    # WHY: the Pandoc input is materialized into a temp directory so metadata can
    # be stripped safely. We must therefore restore the original source directory
    # to the resource search path or relative images stop resolving.
    candidates: list[str] = [str(markdown_path.parent.resolve())]
    if media_dir is not None:
        media_candidate = str(media_dir.resolve())
        if media_candidate not in candidates:
            candidates.append(media_candidate)
    return os.pathsep.join(candidates) if candidates else None


def _parse_asciidoc_metadata(source_text: str) -> dict[str, str]:
    """Extract title/author metadata from a simple AsciiDoc document header."""
    metadata: dict[str, str] = {}
    lines = source_text.splitlines()
    index = 0
    while index < len(lines) and not lines[index].strip():
        index += 1
    if index < len(lines) and lines[index].startswith("= "):
        metadata["title"] = lines[index][2:].strip()
        index += 1
    while index < len(lines):
        line = lines[index].strip()
        if not line:
            break
        if line.startswith(":"):
            key, _, value = line[1:].partition(":")
            if key.strip() in {"author", "authors"} and value.strip():
                metadata["author"] = value.strip()
        elif "title" in metadata and "author" not in metadata:
            metadata["author"] = line
        else:
            break
        index += 1
    return metadata


def _strip_markdown_metadata_block(source_text: str) -> str:
    """Remove only display metadata fields from a leading YAML front matter block.

    WHY: Pandoc needs non-visual metadata such as `bibliography` for citeproc, but
    visible title-block fields like `title` and `author` cause fallback paragraphs
    that branded templates often do not define. Keep the machine metadata, drop
    the visible metadata.
    """
    lines = source_text.splitlines()
    if not lines or lines[0].strip() != "---":
        return source_text

    index = 1
    while index < len(lines) and lines[index].strip() != "---":
        index += 1
    if index >= len(lines):
        return source_text

    kept_metadata_lines = [
        line
        for line in lines[1:index]
        if line.partition(":")[0].strip() not in {"title", "author", "authors", "date"}
    ]
    body_start = index + 1
    while body_start < len(lines) and not lines[body_start].strip():
        body_start += 1
    body = "\n".join(lines[body_start:])
    metadata_block = ""
    if any(line.strip() for line in kept_metadata_lines):
        metadata_block = "---\n" + "\n".join(kept_metadata_lines) + "\n---\n\n"
    return f"{metadata_block}{body}\n" if body or metadata_block else ""


def _strip_asciidoc_header(source_text: str) -> str:
    """Remove only visible AsciiDoc header fields while preserving attributes."""
    lines = source_text.splitlines()
    index = 0
    while index < len(lines) and not lines[index].strip():
        index += 1
    if index >= len(lines) or not lines[index].startswith("= "):
        return source_text

    index += 1
    preserved_attributes: list[str] = []
    while index < len(lines):
        line = lines[index].strip()
        if not line:
            index += 1
            break
        if line.startswith(":"):
            preserved_attributes.append(lines[index])
            index += 1
            continue
        index += 1
        break
    while index < len(lines) and not lines[index].strip():
        index += 1
    body = "\n".join(lines[index:])
    attributes_block = ""
    if preserved_attributes:
        attributes_block = "\n".join(preserved_attributes) + "\n\n"
    return f"{attributes_block}{body}\n" if body or attributes_block else ""


def _inject_raw_parts(docx_path: Path, stylesheet: StyleSheet) -> None:
    """Replace extracted package parts needed for high-fidelity style reuse."""
    # WHY: Word stores style fidelity in a handful of XML parts. Replacing these
    # parts preserves the extracted source of truth more faithfully than
    # reconstructing everything through python-docx objects.
    raw_binary_parts = {
        name: base64.b64decode(content) for name, content in stylesheet.raw_binary_parts.items()
    }
    if not stylesheet.raw_parts and not raw_binary_parts and not stylesheet.content_types_xml:
        return
    with NamedTemporaryFile(suffix=".docx", delete=False) as handle:
        temp_path = Path(handle.name)
    with ZipFile(docx_path, "r") as source, ZipFile(temp_path, "w") as target:
        for info in source.infolist():
            if info.filename in stylesheet.raw_parts or info.filename in raw_binary_parts:
                continue
            target.writestr(info, source.read(info.filename))
        for part_name, content in stylesheet.raw_parts.items():
            target.writestr(part_name, content.encode("utf-8"))
        for part_name, content in raw_binary_parts.items():
            target.writestr(part_name, content)
    temp_path.replace(docx_path)
    if stylesheet.content_types_xml:
        _merge_content_types_part(
            docx_path,
            stylesheet.content_types_xml,
            set(stylesheet.raw_parts) | set(raw_binary_parts),
        )


def _merge_content_types_part(
    docx_path: Path,
    template_content_types_xml: str,
    preserved_part_names: set[str],
) -> None:
    """Merge template content-type declarations for preserved package parts.

    WHY: embedded fonts are binary package assets. Copying the `.odttf` payloads
    without also copying their `[Content_Types].xml` declarations yields a DOCX
    package that still contains the files but does not advertise them correctly
    to Word. Merging only the relevant defaults and overrides preserves font
    fidelity without clobbering newly generated media entries.
    """
    if not preserved_part_names:
        return

    with ZipFile(docx_path, "r") as archive:
        target_xml = archive.read("[Content_Types].xml")
    target_root = parse_xml(target_xml)
    template_root = parse_xml(template_content_types_xml.encode("utf-8"))

    part_overrides = {
        f"/{name}" if not name.startswith("/") else name for name in preserved_part_names
    }
    extensions = {name.rsplit(".", 1)[1] for name in preserved_part_names if "." in Path(name).name}
    existing_defaults = {
        node.get("Extension")
        for node in target_root.findall(
            "{http://schemas.openxmlformats.org/package/2006/content-types}Default"
        )
    }
    existing_overrides = {
        node.get("PartName")
        for node in target_root.findall(
            "{http://schemas.openxmlformats.org/package/2006/content-types}Override"
        )
    }
    changed = False

    for node in template_root.findall(
        "{http://schemas.openxmlformats.org/package/2006/content-types}Default"
    ):
        extension = node.get("Extension")
        if extension in extensions and extension not in existing_defaults:
            target_root.append(etree.fromstring(etree.tostring(node)))
            existing_defaults.add(extension)
            changed = True
    for node in template_root.findall(
        "{http://schemas.openxmlformats.org/package/2006/content-types}Override"
    ):
        part_name = node.get("PartName")
        if part_name in part_overrides and part_name not in existing_overrides:
            target_root.append(etree.fromstring(etree.tostring(node)))
            existing_overrides.add(part_name)
            changed = True

    if not changed:
        return
    _replace_docx_part(
        docx_path,
        "[Content_Types].xml",
        etree.tostring(target_root, encoding="UTF-8", xml_declaration=True),
    )


def _inject_header_footer_parts(docx_path: Path, items: list[HeaderFooter]) -> None:
    """Overwrite generated header/footer parts with extracted raw OOXML content."""
    if not items:
        return
    replacements = {
        (item.type, item.scope, item.section_index): _normalize_header_footer_xml(item.content_xml)
        for item in items
    }
    with NamedTemporaryFile(suffix=".docx", delete=False) as handle:
        temp_path = Path(handle.name)
    with ZipFile(docx_path, "r") as source:
        document_xml = source.read("word/document.xml")
        rels_xml = source.read("word/_rels/document.xml.rels")
        mapping = _resolve_header_footer_targets(document_xml, rels_xml)
        with ZipFile(temp_path, "w") as target:
            for info in source.infolist():
                content = source.read(info.filename)
                reverse_key = mapping.get(info.filename)
                if reverse_key in replacements:
                    content = replacements[reverse_key]
                target.writestr(info, content)
    temp_path.replace(docx_path)


def _preserve_generated_parts(
    source_docx: Path,
    target_docx: Path,
    part_names: tuple[str, ...] = PANDOC_PASSTHROUGH_PARTS,
) -> None:
    """Copy Pandoc-generated ancillary parts back after python-docx saves.

    WHY: `python-docx` rewrites package parts it understands and may truncate
    richer Pandoc-generated parts such as footnotes. Re-injecting the original
    OOXML keeps supported writer output intact while still allowing style and
    section post-processing on the main document.
    """
    with ZipFile(source_docx, "r") as source:
        source_parts = {name: source.read(name) for name in part_names if name in source.namelist()}
    if not source_parts:
        return

    with NamedTemporaryFile(suffix=".docx", delete=False) as handle:
        temp_path = Path(handle.name)
    with ZipFile(target_docx, "r") as target, ZipFile(temp_path, "w") as rewritten:
        copied_names: set[str] = set()
        for info in target.infolist():
            content = source_parts.get(info.filename, target.read(info.filename))
            if info.filename in source_parts:
                copied_names.add(info.filename)
            rewritten.writestr(info, content)
        for part_name, content in source_parts.items():
            if part_name not in copied_names:
                rewritten.writestr(part_name, content)
    temp_path.replace(target_docx)


def _relink_list_paragraph_styles(
    source_docx: Path,
    target_docx: Path,
    stylesheet: StyleSheet,
) -> None:
    """Map generated list paragraphs onto extracted Word list styles.

    WHY: Pandoc can emit list paragraphs that carry numbering but no paragraph
    style, and it synthesizes transient `numId` values. Once edgemint restores
    the template's original numbering part, those transient ids no longer exist.
    Rebinding each list paragraph to the closest extracted Packt list style keeps
    numbering valid and restores the template-owned fonts and colors.
    """
    numbering_map = _source_numbering_formats(source_docx)
    template_targets = _template_list_targets(stylesheet)
    if not numbering_map or not template_targets:
        return

    with ZipFile(target_docx, "r") as archive:
        document_xml = archive.read("word/document.xml")
    root = parse_xml(document_xml)
    changed = False
    for paragraph in root.findall(".//w:body//w:p", NS):
        p_pr = paragraph.find("w:pPr", NS)
        if p_pr is None:
            continue
        num_pr = p_pr.find("w:numPr", NS)
        if num_pr is None:
            continue
        ilvl_element = num_pr.find("w:ilvl", NS)
        num_id_element = num_pr.find("w:numId", NS)
        if num_id_element is None:
            continue

        ilvl = int(ilvl_element.get(qn("w:val"), "0")) if ilvl_element is not None else 0
        num_id = int(num_id_element.get(qn("w:val"), "0"))
        num_fmt = numbering_map.get((num_id, ilvl)) or numbering_map.get((num_id, 0))
        if num_fmt is None:
            continue

        target = template_targets.get((num_fmt, ilvl)) or template_targets.get((num_fmt, 0))
        if target is None:
            continue
        style_id, target_num_id = target
        p_style = p_pr.find("w:pStyle", NS)
        if p_style is None:
            p_style = etree.Element(qn("w:pStyle"))
            p_pr.insert(0, p_style)
        p_style.set(qn("w:val"), style_id)
        num_id_element.set(qn("w:val"), str(target_num_id))
        changed = True

    if not changed:
        return
    _replace_docx_part(
        target_docx,
        "word/document.xml",
        etree.tostring(root, encoding="UTF-8", xml_declaration=True),
    )


def _source_numbering_formats(source_docx: Path) -> dict[tuple[int, int], str]:
    """Return `(num_id, level) -> num_fmt` from a generated DOCX numbering part."""
    with ZipFile(source_docx, "r") as archive:
        if "word/numbering.xml" not in archive.namelist():
            return {}
        root = parse_xml(archive.read("word/numbering.xml"))

    abstract_formats: dict[tuple[int, int], str] = {}
    for abstract in root.findall("w:abstractNum", NS):
        abstract_id = abstract.get(qn("w:abstractNumId"))
        if abstract_id is None:
            continue
        for level in abstract.findall("w:lvl", NS):
            level_id = level.get(qn("w:ilvl"))
            num_fmt = level.find("w:numFmt", NS)
            if level_id is None or num_fmt is None:
                continue
            abstract_formats[(int(abstract_id), int(level_id))] = num_fmt.get(qn("w:val"), "")

    numbering_formats: dict[tuple[int, int], str] = {}
    for number in root.findall("w:num", NS):
        num_id = number.get(qn("w:numId"))
        abstract_ref = number.find("w:abstractNumId", NS)
        if num_id is None or abstract_ref is None:
            continue
        abstract_id = abstract_ref.get(qn("w:val"))
        if abstract_id is None:
            continue
        for (candidate_abstract_id, level), num_fmt in abstract_formats.items():
            if candidate_abstract_id == int(abstract_id):
                numbering_formats[(int(num_id), level)] = num_fmt
    return numbering_formats


def _template_list_targets(stylesheet: StyleSheet) -> dict[tuple[str, int], tuple[str, int]]:
    """Return the extracted list-style target for each `(num_fmt, level)` pair."""
    targets: dict[tuple[str, int], tuple[str, int]] = {}
    for numbering in stylesheet.numbering_defs:
        for level in numbering.levels:
            if level.paragraph_style_id is None:
                continue
            targets.setdefault(
                (level.num_fmt, level.level),
                (level.paragraph_style_id, numbering.num_id),
            )
    return targets


def _replace_docx_part(docx_path: Path, part_name: str, content: bytes) -> None:
    """Replace one ZIP part inside a DOCX package."""
    with NamedTemporaryFile(suffix=".docx", delete=False) as handle:
        temp_path = Path(handle.name)
    with ZipFile(docx_path, "r") as source, ZipFile(temp_path, "w") as target:
        for info in source.infolist():
            target.writestr(
                info, content if info.filename == part_name else source.read(info.filename)
            )
    temp_path.replace(docx_path)


def _relink_pandoc_styles(docx_path: Path, stylesheet: StyleSheet) -> None:
    """Remap Pandoc writer styles onto extracted template-native styles.

    WHY: once the original template `styles.xml` is restored, Pandoc-specific
    helper styles such as `SourceCode` and `VerbatimChar` are no longer part of
    the package. Rebinding those references to equivalent extracted Packt styles
    preserves the intended visual result instead of falling back to defaults.
    """
    available = {style.style_id for style in stylesheet.styles}
    paragraph_aliases = {
        source: target
        for source, target in PANDOC_PARAGRAPH_STYLE_ALIASES.items()
        if target in available
    }
    run_aliases = {
        source: target for source, target in PANDOC_RUN_STYLE_ALIASES.items() if target in available
    }
    if not paragraph_aliases and not run_aliases:
        return

    with ZipFile(docx_path, "r") as archive:
        document_xml = archive.read("word/document.xml")
    root = parse_xml(document_xml)
    changed = False

    for p_style in root.findall(".//w:pPr/w:pStyle", NS):
        style_id = p_style.get(qn("w:val"))
        if style_id in paragraph_aliases:
            p_style.set(qn("w:val"), paragraph_aliases[style_id])
            changed = True
    for r_style in root.findall(".//w:rPr/w:rStyle", NS):
        style_id = r_style.get(qn("w:val"))
        if style_id in run_aliases:
            r_style.set(qn("w:val"), run_aliases[style_id])
            changed = True

    if not changed:
        return
    _replace_docx_part(
        docx_path,
        "word/document.xml",
        etree.tostring(root, encoding="UTF-8", xml_declaration=True),
    )


def _configure_core_properties(
    document: Document,
    metadata: dict[str, str],
    stylesheet: StyleSheet,
) -> None:
    """Project source metadata and extracted core properties onto a DOCX."""
    props = document.core_properties
    source_props = stylesheet.core_properties
    props.title = metadata.get("title") or (source_props.title if source_props else "")
    props.author = metadata.get("author") or (source_props.author if source_props else "")
    props.subject = source_props.subject if source_props else ""
    props.keywords = source_props.keywords if source_props else ""
    props.comments = source_props.description if source_props else ""


def _configure_section(document: Document, stylesheet: StyleSheet) -> None:
    """Apply extracted section layout settings to the first document section."""
    _configure_sections(document, stylesheet)


def _configure_sections(document: Document, stylesheet: StyleSheet) -> None:
    """Apply extracted section layout settings across all target sections."""
    configs = stylesheet.sections or (
        [stylesheet.section_properties] if stylesheet.section_properties is not None else []
    )
    if not configs:
        return
    _ensure_section_count(document, len(configs))
    for section, config in zip(document.sections, configs, strict=True):
        _apply_section_properties(section, config)


def _ensure_section_count(document: Document, count: int) -> None:
    """Grow the document to the requested number of sections."""
    while len(document.sections) < count:
        document.add_section(WD_SECTION_START.NEW_PAGE)


def _apply_section_properties(section, config) -> None:
    """Project one extracted section configuration onto a DOCX section."""
    if config.page_width_pt:
        section.page_width = Pt(config.page_width_pt)
    if config.page_height_pt:
        section.page_height = Pt(config.page_height_pt)
    if config.margin_top_pt:
        section.top_margin = Pt(config.margin_top_pt)
    if config.margin_bottom_pt:
        section.bottom_margin = Pt(config.margin_bottom_pt)
    if config.margin_left_pt:
        section.left_margin = Pt(config.margin_left_pt)
    if config.margin_right_pt:
        section.right_margin = Pt(config.margin_right_pt)
    if config.header_distance_pt:
        section.header_distance = Pt(config.header_distance_pt)
    if config.footer_distance_pt:
        section.footer_distance = Pt(config.footer_distance_pt)
    if config.orientation == "landscape":
        section.orientation = WD_ORIENTATION.LANDSCAPE
    if config.start_type:
        section.start_type = WD_SECTION_START[config.start_type]


def _prepare_header_footer_scopes(document: Document, items: list[HeaderFooter]) -> None:
    """Enable first/even page header-footer modes before placeholder creation."""
    if not items:
        return
    if any(item.scope == "even" for item in items):
        document.settings.odd_and_even_pages_header_footer = True
    _ensure_section_count(document, max(item.section_index for item in items) + 1)
    for index, section in enumerate(document.sections):
        if any(item.scope == "first" and item.section_index == index for item in items):
            section.different_first_page_header_footer = True


def _build_styles(document: Document, stylesheet: StyleSheet) -> None:
    """Create or update DOCX styles from the extracted style sheet."""
    style_registry = {item.style_id: item for item in document.styles}
    for style in stylesheet.styles:
        if style.type not in STYLE_KIND_TO_DOCX:
            continue
        if style.style_id in style_registry:
            target = style_registry[style.style_id]
        else:
            target = document.styles.add_style(style.style_id, STYLE_KIND_TO_DOCX[style.type])
            style_registry[style.style_id] = target
        target.name = style.name
        if style.based_on and style.based_on in style_registry:
            target.base_style = style_registry[style.based_on]
        resolved = style.resolved
        if resolved:
            # WHY: the stylesheet already carries a fully merged view. Applying
            # that snapshot makes generation deterministic even if python-docx
            # or Word interpret inheritance slightly differently.
            if style.type == StyleType.PARAGRAPH:
                _apply_paragraph_format(target.paragraph_format, resolved.paragraph_format)
            _apply_font_properties(target.font, resolved.font)
        else:
            if style.type == StyleType.PARAGRAPH and style.paragraph_format:
                _apply_paragraph_format(target.paragraph_format, style.paragraph_format)
            if style.font:
                _apply_font_properties(target.font, style.font)


def _apply_headers_and_footers(document: Document, items: list[HeaderFooter]) -> None:
    """Project extracted header and footer content into the target document."""
    if not items:
        return
    _prepare_header_footer_scopes(document, items)
    for item in items:
        section = document.sections[item.section_index]
        target = _header_footer_target(document, section, item)
        # WHY: python-docx cannot import raw header/footer OOXML directly. Keep a
        # readable fallback instead of silently dropping the region entirely.
        target.is_linked_to_previous = False
        target.paragraphs[0].text = _extract_plain_text(item.content_xml)


def _render_block(document: Document, block: Block, media_dir: Path | None) -> None:
    """Render one parsed Markdown block into the target document."""
    if block.kind == "heading":
        paragraph = document.add_paragraph(style=f"Heading {block.level}")
        _append_inlines(paragraph, block.inlines)
        return
    if block.kind == "paragraph":
        paragraph = document.add_paragraph(style=block.style or None)
        _append_inlines(paragraph, block.inlines)
        return
    if block.kind == "list":
        style = "List Number" if block.ordered else "List Bullet"
        for item in block.items:
            paragraph = document.add_paragraph(style=style)
            _append_inlines(paragraph, item)
        return
    if block.kind == "table":
        if not block.rows:
            return
        table = document.add_table(rows=1, cols=len(block.rows[0]))
        table.alignment = WD_TABLE_ALIGNMENT.LEFT
        for index, cell in enumerate(block.rows[0]):
            table.rows[0].cells[index].text = cell
        for row in block.rows[1:]:
            cells = table.add_row().cells
            for index, cell in enumerate(row):
                cells[index].text = cell
        style_registry = {
            style.style_id: style
            for style in document.styles
            if getattr(style, "type", None) == WD_STYLE_TYPE.TABLE
        }
        if block.style and block.style in style_registry:
            table.style = style_registry[block.style]
        return
    if block.kind == "image" and media_dir is not None:
        path = media_dir / block.text
        if path.exists():
            document.add_picture(str(path))


def _append_inlines(paragraph, inlines: list[Inline]) -> None:
    """Append parsed inline segments to a paragraph as DOCX runs."""
    for segment in inlines:
        run = paragraph.add_run(segment.text)
        if segment.custom_style:
            try:
                run.style = segment.custom_style
            except KeyError:
                pass
        if segment.bold:
            run.bold = True
        if segment.italic:
            run.italic = True
        if segment.code:
            run.font.name = "Courier New"


def _apply_paragraph_format(target, paragraph_format: ParagraphFormat) -> None:
    """Copy paragraph formatting properties onto a python-docx paragraph format."""
    if paragraph_format.alignment:
        target.alignment = _map_alignment(paragraph_format.alignment)
    if paragraph_format.space_before_pt is not None:
        target.space_before = Pt(paragraph_format.space_before_pt)
    if paragraph_format.space_after_pt is not None:
        target.space_after = Pt(paragraph_format.space_after_pt)
    if paragraph_format.line_spacing is not None:
        target.line_spacing = paragraph_format.line_spacing
    if paragraph_format.line_spacing_rule is not None:
        target.line_spacing_rule = _map_line_spacing(paragraph_format.line_spacing_rule)
    if paragraph_format.keep_with_next is not None:
        target.keep_with_next = paragraph_format.keep_with_next
    if paragraph_format.keep_together is not None:
        target.keep_together = paragraph_format.keep_together
    if paragraph_format.page_break_before is not None:
        target.page_break_before = paragraph_format.page_break_before
    if paragraph_format.widow_control is not None:
        target.widow_control = paragraph_format.widow_control
    if paragraph_format.indent_left_pt is not None:
        target.left_indent = Pt(paragraph_format.indent_left_pt)
    if paragraph_format.indent_right_pt is not None:
        target.right_indent = Pt(paragraph_format.indent_right_pt)
    if paragraph_format.indent_first_line_pt is not None:
        target.first_line_indent = Pt(paragraph_format.indent_first_line_pt)
    if paragraph_format.tab_stops:
        for stop in paragraph_format.tab_stops:
            target.tab_stops.add_tab_stop(
                Pt(stop.position_pt),
                alignment=_map_tab_alignment(stop.alignment),
                leader=_map_tab_leader(stop.leader),
            )


def _apply_font_properties(target, font: FontProperties) -> None:
    """Copy font properties onto a python-docx font object."""
    if font.name is not None:
        target.name = font.name
    if font.size_pt is not None:
        target.size = Pt(font.size_pt)
    if font.bold is not None:
        target.bold = font.bold
    if font.italic is not None:
        target.italic = font.italic
    if font.underline is not None:
        target.underline = _map_underline(font.underline)
    if font.strike is not None:
        target.strike = font.strike
    if font.double_strike is not None:
        target.double_strike = font.double_strike
    if font.color is not None:
        target.color.rgb = RGBColor.from_string(font.color.replace("#", ""))
    if font.superscript is not None:
        target.superscript = font.superscript
    if font.subscript is not None:
        target.subscript = font.subscript
    if font.small_caps is not None:
        target.small_caps = font.small_caps
    if font.all_caps is not None:
        target.all_caps = font.all_caps


def _map_alignment(value: Alignment) -> WD_ALIGN_PARAGRAPH:
    """Map schema alignment values to python-docx constants."""
    mapping = {
        Alignment.LEFT: WD_ALIGN_PARAGRAPH.LEFT,
        Alignment.CENTER: WD_ALIGN_PARAGRAPH.CENTER,
        Alignment.RIGHT: WD_ALIGN_PARAGRAPH.RIGHT,
        Alignment.JUSTIFY: WD_ALIGN_PARAGRAPH.JUSTIFY,
        Alignment.DISTRIBUTE: WD_ALIGN_PARAGRAPH.DISTRIBUTE,
    }
    return mapping[value]


def _map_line_spacing(value: LineSpacingRule) -> WD_LINE_SPACING:
    """Map schema line-spacing rules to python-docx constants."""
    mapping = {
        LineSpacingRule.SINGLE: WD_LINE_SPACING.SINGLE,
        LineSpacingRule.ONE_POINT_FIVE: WD_LINE_SPACING.ONE_POINT_FIVE,
        LineSpacingRule.DOUBLE: WD_LINE_SPACING.DOUBLE,
        LineSpacingRule.AT_LEAST: WD_LINE_SPACING.AT_LEAST,
        LineSpacingRule.EXACTLY: WD_LINE_SPACING.EXACTLY,
        LineSpacingRule.MULTIPLE: WD_LINE_SPACING.MULTIPLE,
    }
    return mapping[value]


def _map_tab_alignment(value: str) -> WD_TAB_ALIGNMENT:
    """Map tab-stop alignment labels to python-docx constants."""
    mapping = {
        "LEFT": WD_TAB_ALIGNMENT.LEFT,
        "CENTER": WD_TAB_ALIGNMENT.CENTER,
        "RIGHT": WD_TAB_ALIGNMENT.RIGHT,
        "DECIMAL": WD_TAB_ALIGNMENT.DECIMAL,
        "BAR": WD_TAB_ALIGNMENT.BAR,
    }
    return mapping.get(value, WD_TAB_ALIGNMENT.LEFT)


def _map_tab_leader(value: str) -> WD_TAB_LEADER:
    """Map tab leader labels to python-docx constants."""
    mapping = {
        "NONE": WD_TAB_LEADER.SPACES,
        "DOTS": WD_TAB_LEADER.DOTS,
        "DASHES": WD_TAB_LEADER.DASHES,
        "UNDERSCORE": WD_TAB_LEADER.LINES,
    }
    return mapping.get(value, WD_TAB_LEADER.SPACES)


def _map_underline(value: UnderlineType):
    """Map underline enum values to python-docx underline representations."""
    mapping = {
        UnderlineType.NONE: False,
        UnderlineType.SINGLE: True,
        UnderlineType.DOUBLE: WD_UNDERLINE.DOUBLE,
        UnderlineType.DOTTED: WD_UNDERLINE.DOTTED,
        UnderlineType.DASH: WD_UNDERLINE.DASH,
        UnderlineType.WAVE: WD_UNDERLINE.WAVY,
        UnderlineType.THICK: WD_UNDERLINE.THICK,
        UnderlineType.WORDS: WD_UNDERLINE.WORDS,
    }
    return mapping[value]


def _extract_plain_text(xml: str) -> str:
    """Extract plain visible text from a header/footer OOXML fragment."""
    import re

    matches = re.findall(r"<w:t[^>]*>(.*?)</w:t>", xml)
    return " ".join(item for item in matches if item).strip()


def _normalize_header_footer_xml(content_xml: str) -> bytes:
    """Serialize header/footer OOXML as a standalone, namespace-complete part.

    WHY: extracted XML may be stored as a fragment in tests or future adapters.
    DOCX package parts must be self-contained XML documents, otherwise Word and
    `python-docx` will reject the archive during parsing.
    """
    xml = content_xml.strip()
    if not xml:
        return b""
    if xml.startswith("<w:hdr") and "xmlns:w=" not in xml:
        xml = xml.replace(
            "<w:hdr",
            f'<w:hdr xmlns:w="{NS["w"]}" xmlns:r="{NS["r"]}"',
            1,
        )
    if xml.startswith("<w:ftr") and "xmlns:w=" not in xml:
        xml = xml.replace(
            "<w:ftr",
            f'<w:ftr xmlns:w="{NS["w"]}" xmlns:r="{NS["r"]}"',
            1,
        )
    root = parse_xml(xml.encode("utf-8"))
    return etree.tostring(root, encoding="UTF-8", xml_declaration=True, standalone=True)


def _header_footer_target(document: Document, section, item: HeaderFooter):
    """Return the python-docx header/footer object matching kind and scope."""
    if item.type == "header":
        if item.scope == "first":
            return section.first_page_header
        if item.scope == "even":
            document.settings.odd_and_even_pages_header_footer = True
            return section.even_page_header
        return section.header
    if item.scope == "first":
        return section.first_page_footer
    if item.scope == "even":
        document.settings.odd_and_even_pages_header_footer = True
        return section.even_page_footer
    return section.footer


def _resolve_header_footer_targets(
    document_xml: bytes,
    rels_xml: bytes,
) -> dict[str, tuple[str, str, int]]:
    """Map generated ZIP part names to logical `(type, scope, section_index)` keys."""
    document_root = parse_xml(document_xml)
    rels_root = parse_xml(rels_xml)
    rel_id_to_target = {
        rel.get("Id"): f"word/{rel.get('Target')}"
        for rel in rels_root.findall("rel:Relationship", NS)
        if rel.get("Id") and rel.get("Target")
    }
    mapping: dict[str, tuple[str, str, int]] = {}
    for section_index, sect in enumerate(document_root.findall(".//w:sectPr", NS)):
        for tag_name, kind in [("headerReference", "header"), ("footerReference", "footer")]:
            for reference in sect.findall(f"w:{tag_name}", NS):
                rel_id = reference.get(qn("r:id"))
                if rel_id is None or rel_id not in rel_id_to_target:
                    continue
                mapping[rel_id_to_target[rel_id]] = (
                    kind,
                    reference.get(qn("w:type"), "default"),
                    section_index,
                )
    return mapping
