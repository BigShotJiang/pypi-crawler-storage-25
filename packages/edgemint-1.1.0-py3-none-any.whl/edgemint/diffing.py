"""Semantic style-sheet diffing."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from edgemint.schema.models import Style, StyleSheet


@dataclass(slots=True)
class Change:
    """One leaf-level semantic change between two style-sheet structures."""

    path: str
    before: Any
    after: Any


@dataclass(slots=True)
class StyleDiffResult:
    """Collection of added, removed, and modified styles."""

    added: list[Style] = field(default_factory=list)
    removed: list[Style] = field(default_factory=list)
    modified: dict[str, list[Change]] = field(default_factory=dict)

    def has_changes(self) -> bool:
        """Return whether the diff contains any additions, removals, or edits."""
        return bool(self.added or self.removed or self.modified)


def diff_stylesheets(before: StyleSheet, after: StyleSheet) -> StyleDiffResult:
    """Compute semantic style differences between two style sheets."""
    result = StyleDiffResult()
    before_map = {style.style_id: style for style in before.styles}
    after_map = {style.style_id: style for style in after.styles}

    for style_id in sorted(set(after_map) - set(before_map)):
        result.added.append(after_map[style_id])
    for style_id in sorted(set(before_map) - set(after_map)):
        result.removed.append(before_map[style_id])
    for style_id in sorted(set(before_map) & set(after_map)):
        changes = _diff_dicts(
            "", before_map[style_id].model_dump(), after_map[style_id].model_dump()
        )
        if changes:
            result.modified[style_id] = changes
    return result


def _diff_dicts(path: str, before: Any, after: Any) -> list[Change]:
    """Recursively diff nested dictionaries and lists into flat path changes."""
    if before == after:
        return []
    if isinstance(before, dict) and isinstance(after, dict):
        changes: list[Change] = []
        keys = set(before) | set(after)
        for key in sorted(keys):
            child = f"{path}.{key}" if path else key
            changes.extend(_diff_dicts(child, before.get(key), after.get(key)))
        return changes
    if isinstance(before, list) and isinstance(after, list):
        return [Change(path, before, after)]
    return [Change(path, before, after)]
