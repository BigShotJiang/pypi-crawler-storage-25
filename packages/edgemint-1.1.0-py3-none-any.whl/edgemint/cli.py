"""CLI entrypoint."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer

from edgemint import __version__
from edgemint.apply import SourceFormat, apply_stylesheet
from edgemint.diffing import diff_stylesheets
from edgemint.errors import EdgemintError
from edgemint.extract.document import (
    extract_document_bundle,
    extract_stylesheet,
    summarize_stylesheet,
)
from edgemint.jsonio import dump_stylesheet, load_stylesheet
from edgemint.schema.models import StyleSheet, StyleType

app = typer.Typer(add_completion=False, no_args_is_help=True)


def _fail_on_warnings(warnings: list[str], strict: bool) -> None:
    """Raise a validation exit when strict mode forbids partial extraction."""
    if strict and warnings:
        raise EdgemintError(
            "Strict mode aborted extraction because unsupported constructs were detected:\n"
            + "\n".join(f"- {warning}" for warning in warnings)
        )


@app.callback()
def main() -> None:
    """edgemint CLI."""


@app.command("version")
def version() -> None:
    """Print the installed edgemint version."""
    typer.echo(__version__)


@app.command("extract-styles")
def extract_styles_command(
    input_docx: Path = typer.Argument(..., exists=True, readable=True),
    output: Path = typer.Option(..., "--output", "-o"),
    resolved: bool = typer.Option(True, "--resolved/--no-resolved"),
    filter_type: StyleType | None = typer.Option(None, "--filter"),
    strict: bool = typer.Option(False, "--strict/--lenient"),
) -> None:
    """Extract DOCX style data into a JSON style sheet."""
    try:
        stylesheet, warnings = extract_stylesheet(input_docx, include_resolved=resolved)
        _fail_on_warnings(warnings, strict)
        if filter_type is not None:
            stylesheet = stylesheet.model_copy(
                update={
                    "styles": [style for style in stylesheet.styles if style.type == filter_type]
                }
            )
        dump_stylesheet(output, stylesheet)
        for warning in warnings:
            typer.echo(f"WARNING: {warning}", err=True)
        typer.echo(f"Extracted {len(stylesheet.styles)} styles to {output}")
    except EdgemintError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(exc.exit_code) from exc


@app.command("extract")
def extract_command(
    input_docx: Path = typer.Argument(..., exists=True, readable=True),
    output_dir: Path = typer.Option(..., "--output", "-o"),
    strict: bool = typer.Option(False, "--strict/--lenient"),
) -> None:
    """Extract content, styles, and media from a DOCX into a project bundle."""
    try:
        stylesheet, warnings = extract_document_bundle(input_docx, output_dir)
        _fail_on_warnings(warnings, strict)
        dump_stylesheet(output_dir / "styles.json", stylesheet)
        for warning in warnings:
            typer.echo(f"WARNING: {warning}", err=True)
        typer.echo(f"Extracted document bundle to {output_dir}")
    except EdgemintError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(exc.exit_code) from exc


@app.command("apply-styles")
def apply_styles_command(
    markdown_file: Path = typer.Argument(..., exists=True, readable=True),
    styles_json: Path = typer.Argument(..., exists=True, readable=True),
    output: Path = typer.Option(..., "--output", "-o"),
    media: Path | None = typer.Option(None, "--media"),
    input_format: SourceFormat = typer.Option(SourceFormat.AUTO, "--input-format"),
) -> None:
    """Generate a styled DOCX from Markdown and a style sheet."""
    try:
        stylesheet = load_stylesheet(styles_json)
        apply_stylesheet(
            markdown_file,
            stylesheet,
            output,
            media_dir=media,
            input_format=input_format,
        )
        typer.echo(f"Generated {output}")
    except EdgemintError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(exc.exit_code) from exc


@app.command("diff")
def diff_command(
    before_json: Path = typer.Argument(..., exists=True, readable=True),
    after_json: Path = typer.Argument(..., exists=True, readable=True),
) -> None:
    """Compare two extracted style sheets and print semantic differences."""
    try:
        before = load_stylesheet(before_json)
        after = load_stylesheet(after_json)
        result = diff_stylesheets(before, after)
        if not result.has_changes():
            typer.echo("No changes")
            return
        for style in result.added:
            typer.echo(f"ADDED {style.style_id} ({style.name})")
        for style in result.removed:
            typer.echo(f"REMOVED {style.style_id} ({style.name})")
        for style_id, changes in result.modified.items():
            typer.echo(f"CHANGED {style_id}")
            for change in changes:
                typer.echo(f"  {change.path}: {change.before!r} -> {change.after!r}")
    except EdgemintError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(exc.exit_code) from exc


@app.command("validate")
def validate_command(styles_json: Path = typer.Argument(..., exists=True, readable=True)) -> None:
    """Validate a style sheet JSON file against the Pydantic schema."""
    try:
        load_stylesheet(styles_json)
        typer.echo("Valid")
    except EdgemintError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(exc.exit_code) from exc


@app.command("info")
def info_command(
    input_docx: Path = typer.Argument(..., exists=True, readable=True),
    strict: bool = typer.Option(False, "--strict/--lenient"),
) -> None:
    """Print a concise summary of the styles present in a DOCX."""
    try:
        stylesheet, warnings = extract_stylesheet(input_docx)
        _fail_on_warnings(warnings, strict)
        summary = summarize_stylesheet(stylesheet)
        counts = summary["counts"]
        typer.echo(f"Styles: {sum(counts.values())}")
        typer.echo(f"Paragraph: {counts.get('paragraph', 0)}")
        typer.echo(f"Character: {counts.get('character', 0)}")
        typer.echo(f"Table: {counts.get('table', 0)}")
        typer.echo(f"Theme heading font: {summary['theme_major'] or 'n/a'}")
        typer.echo(f"Theme body font: {summary['theme_minor'] or 'n/a'}")
        typer.echo(f"Sections: {summary['sections']}")
        typer.echo(f"Max inheritance depth: {summary['max_inheritance_depth']}")
        for warning in warnings:
            typer.echo(f"WARNING: {warning}", err=True)
    except EdgemintError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(exc.exit_code) from exc


@app.command("schema")
def schema_command() -> None:
    """Print the JSON schema for styles.json."""
    typer.echo(json.dumps(StyleSheet.model_json_schema(), indent=2))


def run() -> int:
    """Execute the CLI and translate Typer exits into integer exit codes."""
    try:
        app(standalone_mode=False)
        return 0
    except typer.Exit as exc:
        return exc.exit_code


if __name__ == "__main__":  # pragma: no cover
    sys.exit(run())
