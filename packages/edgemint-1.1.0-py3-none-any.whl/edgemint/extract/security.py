"""DOCX archive validation."""

from __future__ import annotations

from zipfile import ZipFile

from edgemint.errors import SecurityError

MAX_ARCHIVE_SIZE = 150 * 1024 * 1024


def validate_docx_archive(archive: ZipFile) -> None:
    """Validate archive paths and aggregate size before XML parsing begins."""
    total = 0
    for info in archive.infolist():
        name = info.filename
        if name.startswith("/") or ".." in name.split("/"):
            raise SecurityError(f"Unsafe archive entry detected: {name}")
        total += info.file_size
        if total > MAX_ARCHIVE_SIZE:
            raise SecurityError("DOCX archive exceeds allowed size limit")
