"""DOCX extraction pipeline.

Flow:
    .docx ZIP
       |
       +--> styles.xml   -> style models
       +--> numbering.xml -> numbering models
       +--> theme1.xml    -> theme models
       +--> document.xml  -> sections + warnings + header/footer links
       |
       `--> resolved StyleSheet JSON
"""

from __future__ import annotations

import base64
import shutil
from collections import Counter
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile

from docx import Document
from docx.enum.section import WD_SECTION_START
from lxml import etree

from edgemint import __version__
from edgemint.errors import FileError
from edgemint.extract.resolver import resolve_styles
from edgemint.extract.security import validate_docx_archive
from edgemint.ooxml import NS, parse_xml, qn
from edgemint.pandoc import get_pandoc_version, has_pandoc, run_pandoc
from edgemint.schema.models import (
    Alignment,
    BorderProperties,
    Borders,
    BorderStyle,
    CoreProperties,
    DocDefaults,
    FontProperties,
    FontSpec,
    HeaderFooter,
    LineSpacingRule,
    MetaInfo,
    NumberingDef,
    NumberingLevel,
    ParagraphFormat,
    SectionProperties,
    Style,
    StyleSheet,
    StyleType,
    TabStop,
    ThemeInfo,
    UnderlineType,
)
from edgemint.schema.validators import eighth_pt_to_pt, half_pt_to_pt, twips_to_pt

UNSUPPORTED_XPATHS = {
    "merged table cells": ".//w:gridSpan | .//w:vMerge",
    "nested tables": ".//w:tbl//w:tbl",
    "text boxes / shapes": ".//w:txbxContent",
    "content controls": ".//w:sdt",
    "comments / annotations": ".//w:commentRangeStart | .//w:commentReference",
    "custom XML": ".//w:customXml",
    "form fields": ".//w:ffData",
    "tracked changes": ".//w:ins | .//w:del",
    "ruby text": ".//w:ruby",
    "OLE objects": ".//o:OLEObject",
    "non-image drawing objects": ".//w:drawing[not(.//pic:pic)]",
}

TEMPLATE_XML_PARTS = {
    "word/styles.xml",
    "word/numbering.xml",
    "word/theme/theme1.xml",
    "word/fontTable.xml",
    "word/_rels/fontTable.xml.rels",
}


def extract_stylesheet(
    docx_path: Path, include_resolved: bool = True
) -> tuple[StyleSheet, list[str]]:
    """Extract a style sheet and unsupported-construct warnings from a DOCX."""
    _ensure_exists(docx_path)
    warnings: list[str] = []
    with ZipFile(docx_path) as archive:
        # WHY: DOCX is a ZIP container. Validate before parsing so malformed
        # archives fail closed rather than leaking into XML parsing behavior.
        validate_docx_archive(archive)
        parts = _read_parts(archive)
        warnings.extend(_detect_unsupported(parts))
    stylesheet = _build_stylesheet(docx_path, parts)
    if include_resolved:
        stylesheet = resolve_styles(stylesheet)
    return stylesheet, warnings


def extract_document_bundle(docx_path: Path, output_dir: Path) -> tuple[StyleSheet, list[str]]:
    """Extract `content.md`, `styles.json`, and `media/` from a DOCX."""
    stylesheet, warnings = extract_stylesheet(docx_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    media_dir = output_dir / "media"
    media_dir.mkdir(exist_ok=True)

    with ZipFile(docx_path) as archive:
        for info in archive.infolist():
            if info.filename.startswith("word/media/"):
                target = media_dir / Path(info.filename).name
                with archive.open(info) as src, target.open("wb") as dst:
                    shutil.copyfileobj(src, dst)

    if has_pandoc():
        _pandoc_extract_content(
            docx_path,
            output_dir / "content.md",
            media_dir,
            "markdown+fenced_divs+bracketed_spans+yaml_metadata_block",
        )
        _normalize_extracted_markdown(output_dir / "content.md", media_dir)
        _pandoc_extract_content(docx_path, output_dir / "content.adoc", media_dir, "asciidoc")
        _normalize_extracted_asciidoc(output_dir / "content.adoc", media_dir)
    else:
        (output_dir / "content.md").write_text(
            _fallback_extract_markdown(docx_path), encoding="utf-8"
        )
        (output_dir / "content.adoc").write_text(
            _fallback_extract_asciidoc(docx_path), encoding="utf-8"
        )

    return stylesheet, warnings


def _ensure_exists(path: Path) -> None:
    """Fail fast when a required input path does not exist."""
    if not path.exists():
        raise FileError(f"File not found: {path}")


def _read_parts(archive: ZipFile) -> dict[str, bytes]:
    """Read the OOXML parts edgemint needs from a DOCX archive."""
    parts: dict[str, bytes] = {}
    for name in [
        "[Content_Types].xml",
        "word/styles.xml",
        "word/theme/theme1.xml",
        "word/numbering.xml",
        "word/fontTable.xml",
        "word/_rels/fontTable.xml.rels",
        "word/document.xml",
        "word/_rels/document.xml.rels",
        "docProps/core.xml",
    ]:
        try:
            parts[name] = archive.read(name)
        except KeyError:
            continue
    for info in archive.infolist():
        if info.filename.startswith("word/fonts/"):
            parts[info.filename] = archive.read(info.filename)
        if info.filename.startswith("word/header") and info.filename.endswith(".xml"):
            parts[info.filename] = archive.read(info.filename)
        if info.filename.startswith("word/footer") and info.filename.endswith(".xml"):
            parts[info.filename] = archive.read(info.filename)
    return parts


def _build_stylesheet(docx_path: Path, parts: dict[str, bytes]) -> StyleSheet:
    """Construct the root style-sheet model from extracted OOXML parts."""
    styles_root = parse_xml(parts["word/styles.xml"])
    theme_root = (
        parse_xml(parts["word/theme/theme1.xml"]) if "word/theme/theme1.xml" in parts else None
    )
    numbering_root = (
        parse_xml(parts["word/numbering.xml"]) if "word/numbering.xml" in parts else None
    )
    document_root = parse_xml(parts["word/document.xml"]) if "word/document.xml" in parts else None
    rels_root = (
        parse_xml(parts["word/_rels/document.xml.rels"])
        if "word/_rels/document.xml.rels" in parts
        else None
    )
    core_root = parse_xml(parts["docProps/core.xml"]) if "docProps/core.xml" in parts else None

    doc = Document(docx_path)
    default_styles = {
        "paragraph": next(
            (style.style_id for style in doc.styles if style.type == 1 and style.builtin), "Normal"
        ),
        "character": "DefaultParagraphFont",
        "table": "TableNormal",
    }

    sections = _parse_sections(document_root)
    stylesheet = StyleSheet(
        meta=MetaInfo(
            source_file=docx_path.name,
            extracted_at=datetime.now().astimezone().isoformat(timespec="seconds"),
            tool_version=__version__,
            default_styles=default_styles,
            pandoc_version=get_pandoc_version(),
        ),
        core_properties=_parse_core_properties(core_root),
        doc_defaults=_parse_doc_defaults(styles_root),
        theme=_parse_theme(theme_root),
        styles=_parse_styles(styles_root),
        numbering_defs=_parse_numbering(numbering_root),
        section_properties=sections[0] if sections else None,
        sections=sections,
        headers_footers=_parse_headers_footers(parts, document_root, rels_root),
        raw_parts={
            name: data.decode("utf-8", errors="ignore")
            for name, data in parts.items()
            if name in TEMPLATE_XML_PARTS
        },
        raw_binary_parts={
            name: base64.b64encode(data).decode("ascii")
            for name, data in parts.items()
            if name.startswith("word/fonts/")
        },
        content_types_xml=(
            parts["[Content_Types].xml"].decode("utf-8", errors="ignore")
            if "[Content_Types].xml" in parts
            else None
        ),
    )
    return stylesheet


def _parse_core_properties(root: etree._Element | None) -> CoreProperties | None:
    """Parse `docProps/core.xml` into the core-properties model."""
    if root is None:
        return None
    return CoreProperties(
        title=_find_text(root, "dc:title"),
        author=_find_text(root, "dc:creator"),
        subject=_find_text(root, "dc:subject"),
        keywords=_find_text(root, "cp:keywords"),
        description=_find_text(root, "dc:description"),
        last_modified_by=_find_text(root, "cp:lastModifiedBy"),
        created=_find_text(root, "dcterms:created"),
        modified=_find_text(root, "dcterms:modified"),
    )


def _parse_doc_defaults(root: etree._Element) -> DocDefaults | None:
    """Parse document default paragraph and run properties."""
    doc_defaults = root.find("w:docDefaults", NS)
    if doc_defaults is None:
        return None
    ppr = doc_defaults.find(".//w:pPrDefault/w:pPr", NS)
    rpr = doc_defaults.find(".//w:rPrDefault/w:rPr", NS)
    return DocDefaults(
        paragraph_format=_parse_paragraph_properties(ppr),
        font=_parse_font_properties(rpr),
    )


def _parse_theme(root: etree._Element | None) -> ThemeInfo:
    """Parse theme fonts and colors from `theme1.xml`."""
    if root is None:
        return ThemeInfo()
    major = root.find(".//a:fontScheme/a:majorFont", NS)
    minor = root.find(".//a:fontScheme/a:minorFont", NS)
    colors: dict[str, str] = {}
    for color in root.findall(".//a:clrScheme/*", NS):
        srgb = color.find(".//a:srgbClr", NS)
        scheme_color = srgb.get("val") if srgb is not None else None
        if scheme_color:
            colors[color.tag.split("}", 1)[1]] = f"#{scheme_color.upper()}"
    return ThemeInfo(
        major_font=_parse_theme_font(major),
        minor_font=_parse_theme_font(minor),
        colors=colors,
    )


def _parse_theme_font(node: etree._Element | None) -> FontSpec:
    """Parse one theme font bucket, such as major or minor fonts."""
    if node is None:
        return FontSpec()
    latin = node.find("a:latin", NS)
    ea = node.find("a:ea", NS)
    cs = node.find("a:cs", NS)
    return FontSpec(
        latin=latin.get("typeface") if latin is not None else None,
        ea=ea.get("typeface") if ea is not None else None,
        cs=cs.get("typeface") if cs is not None else None,
        ascii_theme=latin.get("typeface") if latin is not None else None,
    )


def _parse_styles(root: etree._Element) -> list[Style]:
    """Parse all style definitions from `word/styles.xml`."""
    styles: list[Style] = []
    for style in root.findall("w:style", NS):
        style_type = style.get(qn("w:type"), "paragraph")
        style_id = style.get(qn("w:styleId"))
        if not style_id:
            continue
        name = style.find("w:name", NS)
        style_model = Style(
            style_id=style_id,
            name=name.get(qn("w:val")) if name is not None else style_id,
            name_locale=None,
            type=StyleType(
                style_type if style_type in {item.value for item in StyleType} else "paragraph"
            ),
            based_on=_get_val(style.find("w:basedOn", NS)),
            next_style=_get_val(style.find("w:next", NS)),
            linked_style_id=_get_val(style.find("w:link", NS)),
            is_builtin=style.get(qn("w:customStyle")) != "1",
            is_quick_style=style.find("w:qFormat", NS) is not None,
            is_default=style.get(qn("w:default")) == "1",
            priority=_int_val(style.find("w:uiPriority", NS)),
            paragraph_format=_parse_paragraph_properties(style.find("w:pPr", NS)),
            font=_parse_font_properties(style.find("w:rPr", NS)),
        )
        styles.append(style_model)
    return styles


def _parse_numbering(root: etree._Element | None) -> list[NumberingDef]:
    """Parse numbering and abstract numbering definitions."""
    if root is None:
        return []
    abstracts = {
        int(node.get(qn("w:abstractNumId"))): node
        for node in root.findall("w:abstractNum", NS)
        if node.get(qn("w:abstractNumId")) is not None
    }
    numbering: list[NumberingDef] = []
    for node in root.findall("w:num", NS):
        num_id = int(node.get(qn("w:numId")))
        abstract_num_id = int(node.find("w:abstractNumId", NS).get(qn("w:val")))
        abstract = abstracts.get(abstract_num_id)
        levels: list[NumberingLevel] = []
        if abstract is not None:
            for lvl in abstract.findall("w:lvl", NS):
                ppr = lvl.find("w:pPr", NS)
                levels.append(
                    NumberingLevel(
                        level=int(lvl.get(qn("w:ilvl"), "0")),
                        num_fmt=_get_val(lvl.find("w:numFmt", NS)) or "decimal",
                        lvl_text=_get_val(lvl.find("w:lvlText", NS)) or "",
                        start=_int_val(lvl.find("w:start", NS)) or 1,
                        indent_left_pt=twips_to_pt(_int_attr(ppr.find("w:ind", NS), "left"))
                        if ppr is not None
                        else None,
                        hanging_pt=twips_to_pt(_int_attr(ppr.find("w:ind", NS), "hanging"))
                        if ppr is not None
                        else None,
                        font=_parse_font_properties(lvl.find("w:rPr", NS)),
                        paragraph_style_id=_get_val(lvl.find("w:pStyle", NS)),
                    )
                )
        numbering.append(
            NumberingDef(num_id=num_id, abstract_num_id=abstract_num_id, levels=levels)
        )
    return numbering


def _parse_section_properties(root: etree._Element | None) -> SectionProperties | None:
    """Parse the first section layout block from `word/document.xml`."""
    sections = _parse_sections(root)
    return sections[0] if sections else None


def _parse_sections(root: etree._Element | None) -> list[SectionProperties]:
    """Parse all section layout blocks from `word/document.xml` in document order."""
    if root is None:
        return []
    sections: list[SectionProperties] = []
    for index, sect in enumerate(root.findall(".//w:sectPr", NS)):
        pg_sz = sect.find("w:pgSz", NS)
        pg_mar = sect.find("w:pgMar", NS)
        cols = sect.find("w:cols", NS)
        section_type = sect.find("w:type", NS)
        sections.append(
            SectionProperties(
                section_index=index,
                page_width_pt=twips_to_pt(_int_attr(pg_sz, "w")) if pg_sz is not None else None,
                page_height_pt=twips_to_pt(_int_attr(pg_sz, "h")) if pg_sz is not None else None,
                margin_top_pt=twips_to_pt(_int_attr(pg_mar, "top")) if pg_mar is not None else None,
                margin_bottom_pt=twips_to_pt(_int_attr(pg_mar, "bottom"))
                if pg_mar is not None
                else None,
                margin_left_pt=twips_to_pt(_int_attr(pg_mar, "left"))
                if pg_mar is not None
                else None,
                margin_right_pt=twips_to_pt(_int_attr(pg_mar, "right"))
                if pg_mar is not None
                else None,
                orientation=pg_sz.get(qn("w:orient"), "portrait")
                if pg_sz is not None
                else "portrait",
                columns=int(cols.get(qn("w:num"), "1")) if cols is not None else 1,
                header_distance_pt=twips_to_pt(_int_attr(pg_mar, "header"))
                if pg_mar is not None
                else None,
                footer_distance_pt=twips_to_pt(_int_attr(pg_mar, "footer"))
                if pg_mar is not None
                else None,
                start_type=_map_section_start_type(_get_val(section_type)),
            )
        )
    return sections


def _parse_headers_footers(
    parts: dict[str, bytes],
    document_root: etree._Element | None,
    rels_root: etree._Element | None,
) -> list[HeaderFooter]:
    """Parse header/footer XML parts and recover their section scopes."""
    items: list[HeaderFooter] = []
    rels: dict[str, str] = {}
    if rels_root is not None:
        for rel in rels_root.findall("rel:Relationship", NS):
            rels[rel.get("Id")] = rel.get("Target", "")
    scope_map: dict[tuple[int, str], str] = {}
    if document_root is not None:
        for section_index, sect in enumerate(document_root.findall(".//w:sectPr", NS)):
            # WHY: the raw header/footer XML files do not encode whether they are
            # default / first / even. That scope lives on the section references.
            for item in sect.findall("w:headerReference", NS):
                rel_id = item.get(qn("r:id"))
                if rel_id:
                    scope_map[(section_index, rels.get(rel_id, ""))] = item.get(
                        qn("w:type"), "default"
                    )
            for item in sect.findall("w:footerReference", NS):
                rel_id = item.get(qn("r:id"))
                if rel_id:
                    scope_map[(section_index, rels.get(rel_id, ""))] = item.get(
                        qn("w:type"), "default"
                    )
    for (section_index, target), scope in sorted(scope_map.items()):
        name = f"word/{target}"
        data = parts.get(name)
        if data is None:
            continue
        kind = "header" if "header" in target else "footer"
        items.append(
            HeaderFooter(
                type=kind,
                scope=scope,
                section_index=section_index,
                content_xml=data.decode("utf-8", errors="ignore"),
            )
        )
    return items


def _parse_paragraph_properties(node: etree._Element | None) -> ParagraphFormat:
    """Parse paragraph-level formatting from a `w:pPr` element."""
    if node is None:
        return ParagraphFormat()
    spacing = node.find("w:spacing", NS)
    ind = node.find("w:ind", NS)
    jc = node.find("w:jc", NS)
    tabs = node.find("w:tabs", NS)
    borders = node.find("w:pBdr", NS)
    shading = node.find("w:shd", NS)
    line_rule = spacing.get(qn("w:lineRule")) if spacing is not None else None
    return ParagraphFormat(
        alignment=_parse_alignment(_get_val(jc)),
        space_before_pt=twips_to_pt(_int_attr(spacing, "before")) if spacing is not None else None,
        space_after_pt=twips_to_pt(_int_attr(spacing, "after")) if spacing is not None else None,
        line_spacing=_parse_line_spacing(spacing) if spacing is not None else None,
        line_spacing_rule=_parse_line_rule(line_rule),
        keep_with_next=node.find("w:keepNext", NS) is not None or None,
        keep_together=node.find("w:keepLines", NS) is not None or None,
        page_break_before=node.find("w:pageBreakBefore", NS) is not None or None,
        widow_control=node.find("w:widowControl", NS) is not None or None,
        indent_left_pt=twips_to_pt(_int_attr(ind, "left")) if ind is not None else None,
        indent_right_pt=twips_to_pt(_int_attr(ind, "right")) if ind is not None else None,
        indent_first_line_pt=twips_to_pt(_int_attr(ind, "firstLine")) if ind is not None else None,
        indent_hanging_pt=twips_to_pt(_int_attr(ind, "hanging")) if ind is not None else None,
        tab_stops=_parse_tab_stops(tabs),
        borders=_parse_borders(borders),
        shading_color=_hex(_get_attr(shading, "fill")),
        bidi=node.find("w:bidi", NS) is not None or None,
        outline_level=_int_val(node.find("w:outlineLvl", NS)),
    )


def _parse_font_properties(node: etree._Element | None) -> FontProperties:
    """Parse character-level formatting from a `w:rPr` element."""
    if node is None:
        return FontProperties()
    fonts = node.find("w:rFonts", NS)
    color = node.find("w:color", NS)
    underline = node.find("w:u", NS)
    highlight = node.find("w:highlight", NS)
    vert = node.find("w:vertAlign", NS)
    return FontProperties(
        name=_get_attr(fonts, "ascii"),
        size_pt=half_pt_to_pt(_int_attr(node.find("w:sz", NS), "val")),
        bold=node.find("w:b", NS) is not None or None,
        italic=node.find("w:i", NS) is not None or None,
        underline=_parse_underline(_get_attr(underline, "val")),
        strike=node.find("w:strike", NS) is not None or None,
        double_strike=node.find("w:dstrike", NS) is not None or None,
        color=_hex(_get_attr(color, "val")),
        highlight=_get_attr(highlight, "val"),
        superscript=_is_vert_align(vert, "superscript"),
        subscript=_is_vert_align(vert, "subscript"),
        small_caps=node.find("w:smallCaps", NS) is not None or None,
        all_caps=node.find("w:caps", NS) is not None or None,
        spacing_pt=twips_to_pt(_int_attr(node.find("w:spacing", NS), "val")),
        kern_pt=half_pt_to_pt(_int_attr(node.find("w:kern", NS), "val")),
        ascii_theme=_get_attr(fonts, "asciiTheme"),
        cs_font=_get_attr(fonts, "cs"),
        ea_font=_get_attr(fonts, "eastAsia"),
    )


def _parse_alignment(value: str | None) -> Alignment | None:
    """Map OOXML justification values to schema alignment enums."""
    if value is None:
        return None
    mapping = {
        "left": Alignment.LEFT,
        "center": Alignment.CENTER,
        "right": Alignment.RIGHT,
        "both": Alignment.JUSTIFY,
        "distribute": Alignment.DISTRIBUTE,
    }
    return mapping.get(value)


def _parse_line_rule(value: str | None) -> LineSpacingRule | None:
    """Map OOXML line rule values to schema line-spacing enums."""
    mapping = {
        "auto": LineSpacingRule.MULTIPLE,
        "atLeast": LineSpacingRule.AT_LEAST,
        "exact": LineSpacingRule.EXACTLY,
    }
    return mapping.get(value)


def _parse_line_spacing(spacing: etree._Element) -> float | None:
    """Parse line spacing into points or multiples, depending on line rule."""
    line = _int_attr(spacing, "line")
    if line is None:
        return None
    line_rule = spacing.get(qn("w:lineRule"))
    if line_rule == "auto":
        return round(line / 240.0, 2)
    return twips_to_pt(line)


def _parse_underline(value: str | None) -> UnderlineType | None:
    """Map OOXML underline values to the schema underline enum."""
    mapping = {
        None: None,
        "none": UnderlineType.NONE,
        "single": UnderlineType.SINGLE,
        "double": UnderlineType.DOUBLE,
        "dotted": UnderlineType.DOTTED,
        "dash": UnderlineType.DASH,
        "wave": UnderlineType.WAVE,
        "thick": UnderlineType.THICK,
        "words": UnderlineType.WORDS,
    }
    return mapping.get(value, UnderlineType.SINGLE if value else None)


def _parse_tab_stops(node: etree._Element | None) -> list[TabStop] | None:
    """Parse tab stop definitions from a paragraph property block."""
    if node is None:
        return None
    stops = [
        TabStop(
            position_pt=twips_to_pt(_int_attr(tab, "pos")) or 0.0,
            alignment=(_get_attr(tab, "val") or "left").upper(),
            leader=(_get_attr(tab, "leader") or "none").upper(),
        )
        for tab in node.findall("w:tab", NS)
    ]
    return stops or None


def _parse_borders(node: etree._Element | None) -> Borders | None:
    """Parse paragraph border definitions."""
    if node is None:
        return None
    data = {
        side: _parse_border(node.find(f"w:{side}", NS))
        for side in ["top", "bottom", "left", "right", "between"]
    }
    if not any(data.values()):
        return None
    return Borders(**data)


def _parse_border(node: etree._Element | None) -> BorderProperties | None:
    """Parse one border edge definition."""
    if node is None:
        return None
    style = _get_attr(node, "val") or "none"
    return BorderProperties(
        style=BorderStyle(style)
        if style in {item.value for item in BorderStyle}
        else BorderStyle.NONE,
        width_pt=eighth_pt_to_pt(_int_attr(node, "sz")),
        color=_hex(_get_attr(node, "color")),
        space_pt=twips_to_pt(_int_attr(node, "space")),
    )


def _detect_unsupported(parts: dict[str, bytes]) -> list[str]:
    """Detect explicitly unsupported OOXML constructs and return warnings."""
    warnings: list[str] = []
    if "word/document.xml" not in parts:
        return warnings
    root = parse_xml(parts["word/document.xml"])
    for label, xpath in UNSUPPORTED_XPATHS.items():
        if root.xpath(xpath, namespaces=NS):
            warnings.append(f"Unsupported construct detected: {label}")
    return warnings


def _fallback_extract_markdown(docx_path: Path) -> str:
    """Extract a reduced-fidelity Markdown view without Pandoc."""
    document = Document(docx_path)
    lines: list[str] = []
    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if not text:
            lines.append("")
            continue
        style_name = paragraph.style.name if paragraph.style is not None else ""
        if style_name.startswith("Heading "):
            try:
                level = int(style_name.split()[-1])
                lines.append(f"{'#' * level} {text}")
            except ValueError:
                lines.append(_wrap_custom_style(style_name, text))
        elif style_name in {"Normal", "Body Text"}:
            lines.append(text)
        else:
            # WHY: custom Word styles have no native Markdown representation.
            # Preserve intent by emitting Pandoc-style custom-style fences.
            lines.append(_wrap_custom_style(style_name, text))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _fallback_extract_asciidoc(docx_path: Path) -> str:
    """Extract a reduced-fidelity AsciiDoc view without Pandoc."""
    document = Document(docx_path)
    lines: list[str] = []
    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if not text:
            lines.append("")
            continue
        style_name = paragraph.style.name if paragraph.style is not None else ""
        if style_name.startswith("Heading "):
            try:
                level = int(style_name.split()[-1])
                lines.append(f"{'=' * (level + 1)} {text}")
            except ValueError:
                lines.append(_wrap_custom_style_asciidoc(style_name, text))
        elif style_name in {"Normal", "Body Text"}:
            lines.append(text)
        else:
            lines.append(_wrap_custom_style_asciidoc(style_name, text))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _normalize_extracted_markdown(content_path: Path, media_dir: Path) -> None:
    """Rewrite Pandoc-extracted absolute media paths into portable relative paths."""
    content = content_path.read_text(encoding="utf-8")
    content = content.replace(str(media_dir.resolve()) + "/", "media/")
    content = content.replace(str(media_dir.resolve()), "media")
    content_path.write_text(content, encoding="utf-8")


def _normalize_extracted_asciidoc(content_path: Path, media_dir: Path) -> None:
    """Rewrite Pandoc-extracted AsciiDoc media paths into portable relative paths."""
    content = content_path.read_text(encoding="utf-8")
    media_prefixes = {
        str(media_dir),
        str(media_dir.resolve()),
        _escape_asciidoc_path(str(media_dir)),
        _escape_asciidoc_path(str(media_dir.resolve())),
    }
    for prefix in media_prefixes:
        content = content.replace(prefix + "/", "media/")
        content = content.replace(prefix, "media")
    for asset in sorted(media_dir.rglob("*")):
        if not asset.is_file():
            continue
        relative = asset.relative_to(media_dir).as_posix()
        stem_relative = str(Path(relative).with_suffix("")).replace("\\", "/")
        asset_strings = {
            str(asset),
            str(asset.resolve()),
            str(asset.with_suffix("")),
            str(asset.with_suffix("").resolve()),
        }
        for asset_string in asset_strings:
            variants = {asset_string, _escape_asciidoc_path(asset_string)}
            replacement = (
                f"media/{relative}"
                if asset_string.endswith(asset.suffix)
                else f"media/{stem_relative}"
            )
            for variant in variants:
                content = content.replace(variant, replacement)
    content_path.write_text(content, encoding="utf-8")


def _escape_asciidoc_path(value: str) -> str:
    """Escape underscores the way Pandoc's AsciiDoc writer does inside attributes."""
    return value.replace("_", "++_++")


def _wrap_custom_style(style_name: str, text: str) -> str:
    """Encode a paragraph in Pandoc custom-style fenced-div syntax."""
    return f'::: {{custom-style="{style_name}"}}\n{text}\n:::'


def _wrap_custom_style_asciidoc(style_name: str, text: str) -> str:
    """Encode a paragraph in a simple AsciiDoc role block with style metadata."""
    return f'[custom-style="{style_name}"]\n====\n{text}\n===='


def _pandoc_extract_content(
    docx_path: Path,
    output_path: Path,
    media_dir: Path,
    target_format: str,
) -> None:
    """Extract one text representation from DOCX through Pandoc."""
    run_pandoc(
        [
            str(docx_path),
            "-f",
            "docx+styles",
            "-t",
            target_format,
            "--wrap=none",
            f"--extract-media={media_dir}",
            "-o",
            str(output_path),
        ]
    )


def summarize_stylesheet(stylesheet: StyleSheet) -> dict[str, object]:
    """Produce a compact summary used by the `info` command."""
    counts = Counter(style.type.value for style in stylesheet.styles)
    max_depth = max((_style_depth(style, stylesheet) for style in stylesheet.styles), default=0)
    return {
        "counts": counts,
        "theme_major": stylesheet.theme.major_font.latin,
        "theme_minor": stylesheet.theme.minor_font.latin,
        "max_inheritance_depth": max_depth,
        "sections": len(stylesheet.sections) or (1 if stylesheet.section_properties else 0),
    }


def _style_depth(style: Style, stylesheet: StyleSheet) -> int:
    """Compute the inheritance depth of one style definition."""
    depth = 1
    current = style
    seen: set[str] = set()
    while current.based_on and current.based_on not in seen:
        seen.add(current.style_id)
        parent = stylesheet.get_style(current.based_on)
        if parent is None:
            break
        depth += 1
        current = parent
    return depth


def _map_section_start_type(value: str | None) -> str | None:
    """Normalize OOXML section-start values to python-docx enum names."""
    mapping = {
        None: None,
        "nextPage": WD_SECTION_START.NEW_PAGE.name,
        "continuous": WD_SECTION_START.CONTINUOUS.name,
        "evenPage": WD_SECTION_START.EVEN_PAGE.name,
        "oddPage": WD_SECTION_START.ODD_PAGE.name,
    }
    return mapping.get(value, WD_SECTION_START.NEW_PAGE.name if value else None)


def _find_text(root: etree._Element, path: str) -> str | None:
    """Return the text content of the first matching XML node."""
    node = root.find(path, NS)
    return node.text if node is not None and node.text else None


def _get_val(node: etree._Element | None) -> str | None:
    """Return `w:val` from an OOXML node when present."""
    return node.get(qn("w:val")) if node is not None else None


def _int_val(node: etree._Element | None) -> int | None:
    """Return `w:val` parsed as an integer."""
    value = _get_val(node)
    return int(value) if value is not None else None


def _get_attr(node: etree._Element | None, attr: str) -> str | None:
    """Return a named OOXML attribute from a namespaced element."""
    return node.get(qn(f"w:{attr}")) if node is not None else None


def _int_attr(node: etree._Element | None, attr: str) -> int | None:
    """Return a named OOXML attribute parsed as an integer."""
    value = _get_attr(node, attr)
    return int(value) if value is not None else None


def _hex(value: str | None) -> str | None:
    """Normalize an OOXML color token into `#RRGGBB` form."""
    if value is None or value in {"auto", "none"}:
        return None
    return f"#{value.upper()}"


def _is_vert_align(node: etree._Element | None, expected: str) -> bool | None:
    """Check whether a vertical-alignment node matches the requested variant."""
    value = _get_attr(node, "val")
    return (value == expected) or None
