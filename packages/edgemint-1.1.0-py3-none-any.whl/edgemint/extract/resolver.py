"""Style inheritance resolution."""

from __future__ import annotations

from typing import TypeVar

from pydantic import BaseModel

from edgemint.schema.models import (
    DocDefaults,
    FontProperties,
    ParagraphFormat,
    ResolvedProperties,
    Style,
    StyleSheet,
)

ModelT = TypeVar("ModelT", bound=BaseModel)


def resolve_styles(stylesheet: StyleSheet) -> StyleSheet:
    """Resolve all styles against defaults and their `based_on` chains."""
    defaults = stylesheet.doc_defaults or DocDefaults()
    styles_by_id = {style.style_id: style for style in stylesheet.styles}
    resolved_styles = [resolve_style(style, styles_by_id, defaults) for style in stylesheet.styles]
    return stylesheet.model_copy(update={"styles": resolved_styles})


def resolve_style(style: Style, styles_by_id: dict[str, Style], defaults: DocDefaults) -> Style:
    """Resolve a single style against document defaults and parent styles."""
    paragraph = _merge_model(defaults.paragraph_format, ParagraphFormat())
    font = _merge_model(defaults.font, FontProperties())
    chain = _style_chain(style, styles_by_id)
    for item in chain:
        if item.paragraph_format is not None:
            paragraph = _merge_model(paragraph, item.paragraph_format)
        if item.font is not None:
            font = _merge_model(font, item.font)
    return style.model_copy(
        update={"resolved": ResolvedProperties(paragraph_format=paragraph, font=font)}
    )


def _style_chain(style: Style, styles_by_id: dict[str, Style]) -> list[Style]:
    """Return the inheritance chain for a style ordered from root to leaf."""
    ordered: list[Style] = []
    seen: set[str] = set()
    current = style
    while current.style_id not in seen:
        # WHY: merge root -> leaf so the child can override inherited properties
        # without special-case logic later.
        ordered.insert(0, current)
        seen.add(current.style_id)
        if current.based_on is None or current.based_on not in styles_by_id:
            break
        current = styles_by_id[current.based_on]
    return ordered


def _merge_model(base: ModelT, override: ModelT) -> ModelT:
    """Overlay one Pydantic model onto another using non-null override fields."""
    data = base.model_dump()
    for key, value in override.model_dump(exclude_none=True).items():
        if isinstance(value, dict) and isinstance(data.get(key), dict):
            merged = dict(data[key])
            merged.update(value)
            data[key] = merged
        else:
            data[key] = value
    return type(base).model_validate(data)
