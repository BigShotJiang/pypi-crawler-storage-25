from edgemint.cli import app


def main() -> None:
    """Run the CLI module entry point."""
    app()


if __name__ == "__main__":
    main()
