"""Pandoc discovery and invocation."""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from edgemint.errors import PandocError


def get_pandoc_version() -> str | None:
    """Return the detected Pandoc version string, if Pandoc is available."""
    command = _discover_pandoc()
    if command is None:
        return None
    result = subprocess.run([command, "--version"], capture_output=True, text=True, check=False)
    if result.returncode != 0:
        return None
    return result.stdout.splitlines()[0].strip()


def has_pandoc() -> bool:
    """Report whether a runnable Pandoc executable is available."""
    return _discover_pandoc() is not None


def run_pandoc(args: list[str], workdir: Path | None = None) -> None:
    """Run Pandoc and raise a typed error when the command fails."""
    command = _discover_pandoc()
    if command is None:
        raise PandocError(
            "Pandoc is required for this command. Install `pandoc` or `edgemint[pandoc]`."
        )
    result = subprocess.run(
        [command, *args], cwd=workdir, capture_output=True, text=True, check=False
    )
    if result.returncode != 0:
        message = result.stderr.strip() or result.stdout.strip() or "Pandoc command failed"
        raise PandocError(message)


def _discover_pandoc() -> str | None:
    """Find Pandoc either on PATH or via `pypandoc-binary`."""
    command = shutil.which("pandoc")
    if command:
        return command
    try:
        import pypandoc  # type: ignore
    except ImportError:
        return None
    try:
        return pypandoc.get_pandoc_path()
    except OSError:
        return None
