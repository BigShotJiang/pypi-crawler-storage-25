from .base import Weighting


__all__ = ["Weighting"]
