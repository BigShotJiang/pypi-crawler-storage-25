# src/svy/weighting/poststratification.py
"""
Post-stratification weight adjustment.

The poststratify() function takes a Sample and returns a Sample (for chaining).
The Weighting class in base.py delegates to this function directly.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl

try:
    from svy_rs._internal import poststratify as rust_poststratify  # type: ignore[import-untyped]
except ImportError:  # pragma: no cover
    rust_poststratify = None

from svy.core.constants import SVY_PS_PREFIX
from svy.core.terms import Feature
from svy.core.types import DomainScalarMap, Number
from svy.errors import DimensionError, MethodError
from svy.weighting._helpers import _normalize_by_term, _unique_name

from svy.weighting.types import TrimConfig, resolve_threshold
from svy.weighting.raking import _trim_constraints_satisfied

try:
    from svy_rs._internal import trim_weights as rust_trim_weights  # type: ignore[import-untyped]
except ImportError:  # pragma: no cover
    rust_trim_weights = None

if TYPE_CHECKING:
    from svy.core.sample import Sample


def _to_hashable(v) -> object:
    """Convert a value to a hashable Python object.

    _normalize_by_term returns Cross-term elements as numpy arrays
    (e.g. array(['A','M'])). Convert those to plain tuples.
    """
    if isinstance(v, (list, np.ndarray)):
        return tuple(v)
    return v


def _encode_strata(by_arr: np.ndarray) -> tuple[np.ndarray, list, list]:
    """Encode stratum labels to contiguous int64 indices for Rust.

    Uses FIRST-SEEN order to match Rust's create_group_mapping which uses
    HashMap insertion order. Since we assign 0,1,2,...,n-1, Rust's BTreeSet
    validation sees [0,1,...,n-1] which matches our control_arr order.

    Returns
    -------
    by_indices  : int64 array, shape (n,)  — contiguous 0..n_strata-1
    unique_vals : list of stratum labels in first-seen order
    normed      : list of hashable values (same length as by_arr)
    """
    normed = [_to_hashable(v) for v in by_arr.tolist()]
    seen: dict = {}
    next_id = 0
    for v in normed:
        if v not in seen:
            seen[v] = next_id
            next_id += 1
    unique_vals = [v for v, _ in sorted(seen.items(), key=lambda x: x[1])]
    by_indices = np.array([seen[v] for v in normed], dtype=np.int64)
    return by_indices, unique_vals, normed


def _stratum_sum(wgt_arr: np.ndarray, normed: list, val) -> float:
    """Sum weights for units belonging to a given stratum."""
    mask = np.array([v == val for v in normed])
    return float(wgt_arr[mask].sum())


def _resolve_to_controls(
    controls: DomainScalarMap | Number | None,
    factors: DomainScalarMap | Number | None,
    by_arr: np.ndarray | None,
    wgt_arr: np.ndarray,
    unique_vals: list | None,
    normed: list | None,
) -> np.ndarray:
    """Convert controls or factors to an absolute control array for Rust.

    Rust takes absolute totals only. Factors are arbitrary multipliers
    (not required to sum to 1) converted as: control[s] = factor[s] * sum(w[s]).

    Returns float64 array with one value per stratum (sorted order).
    """
    if by_arr is None:
        # Single stratum
        if controls is not None:
            val = (
                float(next(iter(controls.values())))
                if isinstance(controls, dict)
                else float(controls)  # type: ignore[arg-type]
            )
        else:
            fval = (
                float(next(iter(factors.values())))  # type: ignore[union-attr]
                if isinstance(factors, dict)
                else float(factors)  # type: ignore[arg-type]
            )
            # factor × grand_total → target
            val = fval * float(wgt_arr.sum())
        return np.array([val], dtype=np.float64)

    assert unique_vals is not None and normed is not None

    if controls is not None:
        if isinstance(controls, dict):
            data_keys = set(unique_vals)
            ctrl_keys = set(controls.keys())
            extra = ctrl_keys - data_keys
            missing = data_keys - ctrl_keys
            if extra or missing:
                raise MethodError.invalid_mapping_keys(
                    where="Sample.weighting.poststratify",
                    param="controls",
                    missing=sorted(str(k) for k in missing),
                    extra=sorted(str(k) for k in extra),
                )
            return np.array([float(controls[v]) for v in unique_vals], dtype=np.float64)
        else:
            # Scalar: proportional split by current stratum weight sums
            total = float(wgt_arr.sum())
            return np.array(
                [
                    float(controls) * _stratum_sum(wgt_arr, normed, v) / total  # type: ignore[arg-type]
                    for v in unique_vals
                ],
                dtype=np.float64,
            )
    else:
        grand_total = float(wgt_arr.sum())
        if isinstance(factors, dict):
            data_keys = set(unique_vals)
            fact_keys = set(factors.keys())  # type: ignore[union-attr]
            extra = fact_keys - data_keys
            missing = data_keys - fact_keys
            if extra or missing:
                raise MethodError.invalid_mapping_keys(
                    where="Sample.weighting.poststratify",
                    param="factors",
                    missing=sorted(str(k) for k in missing),
                    extra=sorted(str(k) for k in extra),
                )
            # factor × grand_total → target for each stratum
            return np.array(
                [
                    float(factors[v]) * grand_total  # type: ignore[index]
                    for v in unique_vals
                ],
                dtype=np.float64,
            )
        else:
            # Scalar factor: same proportion of grand total for every stratum
            return np.array(
                [
                    float(factors) * grand_total  # type: ignore[arg-type]
                    for v in unique_vals
                ],
                dtype=np.float64,
            )


def poststratify(
    sample: Sample,
    controls: DomainScalarMap | Number | None = None,
    *,
    factors: DomainScalarMap | Number | None = None,
    by: Feature | None = None,
    wgt_name: str | None = None,
    replace: bool = False,
    rep_wgts_prefix: str | None = None,
    ignore_reps: bool = False,
    update_design_wgts: bool = True,
    trimming: TrimConfig | None = None,
) -> Sample:
    if controls is None and factors is None:
        raise MethodError.not_applicable(
            where="Sample.weighting.poststratify",
            method="poststratify",
            reason="Either controls= or factors= must be specified.",
        )

    where = "Sample.weighting.poststratify"
    df = sample._data
    design = sample._design

    if design.wgt is None:
        raise MethodError.not_applicable(
            where=where,
            method="poststratify",
            reason="Sample weight is None. Set design.wgt before calling poststratify().",
        )
    wgt = design.wgt
    if wgt not in df.columns:
        raise MethodError.invalid_choice(
            where=where,
            param="design.wgt",
            got=wgt,
            allowed=list(df.columns),
            hint="Check that the weight column exists in the data.",
        )
    if replace and wgt_name is not None:
        raise MethodError.not_applicable(
            where=where,
            method="poststratify",
            reason="Pass either replace=True or wgt_name=..., not both.",
        )

    _, by_arr = _normalize_by_term(df, by, param_name="by", where="Sample.weighting.poststratify")

    wgt_arr = df.get_column(wgt).to_numpy().astype(np.float64)
    existing_cols = set(df.columns)

    # Encode strata and resolve controls/factors to absolute totals once
    if by_arr is not None:
        by_indices, unique_vals, normed = _encode_strata(by_arr)
    else:
        by_indices = np.zeros(len(wgt_arr), dtype=np.int64)
        unique_vals = None
        normed = None

    control_arr = _resolve_to_controls(controls, factors, by_arr, wgt_arr, unique_vals, normed)

    # Main weight: reshape to (n, 1), call Rust, extract column 0
    assert rust_poststratify is not None  # noqa: S101
    ps_wgt = rust_poststratify(wgt_arr.reshape(-1, 1), by_indices, control_arr)[:, 0]

    if replace:
        target_wgt = wgt
        df = df.with_columns(pl.Series(name=target_wgt, values=ps_wgt))
    else:
        target_wgt = _unique_name(wgt_name or f"{SVY_PS_PREFIX}{wgt}", existing_cols)
        df = df.with_columns(pl.Series(name=target_wgt, values=ps_wgt))
        existing_cols.add(target_wgt)

    if update_design_wgts:
        sample._design = sample._design.update(wgt=target_wgt)

    if not ignore_reps and design.rep_wgts is not None:
        rep_cols = design.rep_wgts.columns
        if rep_cols:
            wgts_arr = df.select(rep_cols).to_numpy()

            if rep_wgts_prefix is None:
                final_prefix = f"{SVY_PS_PREFIX}{design.rep_wgts.prefix}"
            else:
                final_prefix = rep_wgts_prefix

            adj_wgts_arr = rust_poststratify(wgts_arr, by_indices, control_arr)

            n_reps = len(rep_cols)
            new_rep_names = [f"{final_prefix}{i}" for i in range(1, n_reps + 1)]
            wgts_df = pl.DataFrame(adj_wgts_arr, schema=new_rep_names)

            sample._data = df.hstack(wgts_df)
            df = sample._data

            if update_design_wgts:
                sample._design = sample._design.update_rep_weights(
                    method=design.rep_wgts.method,
                    prefix=final_prefix,
                    n_reps=n_reps,
                    fay_coef=design.rep_wgts.fay_coef,
                    df=design.rep_wgts.df,
                )

    sample._data = df

    # ── Trim-poststratify cycle ───────────────────────────────────────────
    if trimming is not None:
        _w_pos = ps_wgt[ps_wgt > 0].astype(np.float64)
        _upper_val = (
            resolve_threshold(trimming.upper, _w_pos) if trimming.upper is not None else None
        )
        _lower_val = (
            resolve_threshold(trimming.lower, _w_pos) if trimming.lower is not None else None
        )

        assert rust_trim_weights is not None  # noqa: S101
        assert rust_poststratify is not None  # noqa: S101

        _current_w = ps_wgt.copy()
        _ps_converged = True
        _trim_ok = False

        for _cycle in range(trimming.max_iter):
            # Poststratify step — restore margins
            _ps_result = rust_poststratify(_current_w.reshape(-1, 1), by_indices, control_arr)
            _current_w = _ps_result[:, 0]

            # Trim step
            (_trimmed_w, *_) = rust_trim_weights(
                _current_w,
                _upper_val,
                _lower_val,
                trimming.redistribute,
                trimming.max_iter,
                trimming.tol,
            )
            _current_w = _trimmed_w
            _trim_ok = _trim_constraints_satisfied(_current_w, _upper_val, _lower_val, 1e-4)

            if _trim_ok:
                # Final poststratify to restore margins after last trim
                _final = rust_poststratify(_current_w.reshape(-1, 1), by_indices, control_arr)
                _current_w = _final[:, 0]
                # Re-check trim after final poststratify
                _trim_ok = _trim_constraints_satisfied(_current_w, _upper_val, _lower_val, 1e-4)
                break

        if strict and not _trim_ok:
            raise MethodError.not_applicable(
                where=where,
                method="poststratify",
                reason=(
                    f"Trim-poststratify cycle did not converge after {trimming.max_iter} cycles. "
                    "The design has NOT been modified. "
                    "Pass strict=False to store partial results."
                ),
                hint="Increase TrimConfig.max_iter or use a less restrictive trim threshold.",
            )

        # Update stored weight with final cycled result
        df = df.with_columns(pl.Series(name=target_wgt, values=_current_w))
        sample._data = df

    return sample
