# src/svy/weighting/types.py
"""
Weighting-namespace type definitions.

Types live here — not in the engine — so that:
  - svy/engine/weighting/adj_trimming.py can import them without a cycle
  - svy/weighting/trim.py imports from the same place as the public API
  - Users can do: from svy.weighting import Threshold, TrimConfig

Relationship to svy/core/types.py and svy/core/containers.py
-------------------------------------------------------------
svy/core/types.py    — generic primitives and type aliases (Number, Category, …)
svy/core/containers.py — generic statistical output containers (ChiSquare, FDist, …)
svy/weighting/types.py — weighting-specific domain objects (Threshold, TrimConfig, …)
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal

import numpy as np

from numpy.typing import NDArray


FloatArr = NDArray[np.float64]

# ---------------------------------------------------------------------------
# Threshold
# ---------------------------------------------------------------------------

_SUPPORTED_STATS = frozenset({"median", "mean", "sd", "iqr"})


@dataclass(frozen=True)
class Threshold:
    """
    Stat-based threshold: threshold = k * stat(weights).

    Parameters
    ----------
    stat : {"median", "mean", "sd", "iqr"}
        Statistic to compute from the (positive) weight distribution.
    k : float
        Multiplier.  Must be > 0.

    Examples
    --------
    >>> Threshold("median", 6.0)   # upper = 6 * median(w)
    >>> Threshold("iqr", 3.0)      # upper = 3 * IQR(w)
    """

    stat: Literal["median", "mean", "sd", "iqr"]
    k: float

    def __post_init__(self) -> None:
        if self.stat not in _SUPPORTED_STATS:
            raise ValueError(
                f"Unsupported stat {self.stat!r}. Must be one of: {sorted(_SUPPORTED_STATS)}"
            )
        if self.k <= 0:
            raise ValueError(f"k must be > 0, got {self.k}")

    def compute(self, weights: FloatArr) -> float:
        """Compute the threshold scalar from a weight array."""
        w = weights[weights > 0]
        if w.size == 0:
            return 0.0
        if self.stat == "median":
            return self.k * float(np.median(w))
        if self.stat == "mean":
            return self.k * float(np.mean(w))
        if self.stat == "sd":
            return self.k * float(np.std(w, ddof=1))
        if self.stat == "iqr":
            q75, q25 = np.percentile(w, [75.0, 25.0])
            return self.k * float(q75 - q25)
        raise AssertionError(f"Unhandled stat: {self.stat}")  # pragma: no cover


# Three ways to specify one bound
ThresholdSpec = float | Threshold | Callable[[FloatArr], float]


# ---------------------------------------------------------------------------
# TrimConfig
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TrimConfig:
    """
    Full trimming specification — single source of truth for trim() parameters.

    trim() constructs one of these as its first action and delegates all logic
    to run_trim().  Other weighting methods (rake, calibrate) can accept a
    TrimConfig via their trimming= parameter.

    Parameters
    ----------
    upper : ThresholdSpec | None
        Upper bound spec.
        float > 1       → absolute cap
        float in (0, 1] → quantile of weight distribution
        Threshold       → k * stat(w)
        callable        → f(w: FloatArr) -> float
    lower : ThresholdSpec | None
        Lower bound spec, same type rules as upper.
    by : str | list[str] | None
        Domain variable(s).  Thresholds computed per domain;
        redistribution also within each domain.
    redistribute : bool
        Redistribute trimmed mass proportionally to non-trimmed units.
        Default True.
    min_cell_size : int
        Skip (and warn) domains with fewer positive-weight units than this.
        Default 10.
    max_iter : int
        Maximum iterations.  Default 10.
    tol : float
        Convergence tolerance: fraction of weights changed between iterations.
        Default 1e-6.
    """

    upper: ThresholdSpec | None = None
    lower: ThresholdSpec | None = None
    by: str | list[str] | None = None
    redistribute: bool = True
    min_cell_size: int = 10
    max_iter: int = 10
    tol: float = 1e-6

    def __post_init__(self) -> None:
        if self.upper is None and self.lower is None:
            raise ValueError("At least one of `upper` or `lower` must be specified.")
        if self.min_cell_size < 1:
            raise ValueError(f"min_cell_size must be >= 1, got {self.min_cell_size}")
        if self.max_iter < 1:
            raise ValueError(f"max_iter must be >= 1, got {self.max_iter}")
        if not (0 < self.tol < 1):
            raise ValueError(f"tol must be in (0, 1), got {self.tol}")


# ---------------------------------------------------------------------------
# TrimResult
# ---------------------------------------------------------------------------


@dataclass
class TrimResult:
    """
    Output of run_trim() for a single weight array (one domain group).

    Attributes
    ----------
    weights : FloatArr
        Trimmed weight array (same length as input).
    upper_threshold : float | None
        Resolved upper cutoff value (None if not requested).
    lower_threshold : float | None
        Resolved lower cutoff value (None if not requested).
    n_trimmed_upper : int
        Number of units trimmed at the upper bound.
    n_trimmed_lower : int
        Number of units trimmed at the lower bound.
    weight_sum_before : float
    weight_sum_after : float
    ess_before : float
        Effective sample size = (Σw)² / Σw² before trimming.
    ess_after : float
    iterations : int
        Number of iterations actually run.
    converged : bool
    """

    weights: FloatArr
    upper_threshold: float | None
    lower_threshold: float | None
    n_trimmed_upper: int
    n_trimmed_lower: int
    weight_sum_before: float
    weight_sum_after: float
    ess_before: float
    ess_after: float
    iterations: int
    converged: bool


# ---------------------------------------------------------------------------
# resolve_threshold — lives here because it operates on ThresholdSpec
# ---------------------------------------------------------------------------


def resolve_threshold(spec: ThresholdSpec, weights: FloatArr) -> float:
    """
    Convert any ThresholdSpec to a resolved scalar cutoff value.

    Rules
    -----
    float > 1          → absolute cap (returned as-is)
    float in (0, 1]    → quantile of positive weights
    Threshold          → k * stat(positive weights)
    callable           → f(positive weights) -> float
    """
    if isinstance(spec, Threshold):
        return spec.compute(weights)

    if callable(spec):
        w_pos = weights[weights > 0]
        return float(spec(w_pos))

    if isinstance(spec, (int, float)):
        v = float(spec)
        if v <= 0:
            raise ValueError(f"Threshold value must be > 0, got {v}")
        if v <= 1.0:
            w_pos = weights[weights > 0]
            if w_pos.size == 0:
                return 0.0
            return float(np.quantile(w_pos, v))
        return v

    raise TypeError(f"Unsupported ThresholdSpec type: {type(spec)}")
