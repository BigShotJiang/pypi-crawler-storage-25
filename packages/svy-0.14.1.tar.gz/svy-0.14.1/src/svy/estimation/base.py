# src/svy/estimation/base.py
from __future__ import annotations

import logging
import math
import re

from typing import TYPE_CHECKING, Any, Literal, Mapping, Sequence, cast

import numpy as np
import polars as pl
import svy_rs as rs

from scipy import stats

from svy.core.constants import _BY_SEP, _INTERNAL_CONCAT_SUFFIX
from svy.core.data_prep import PreparedData, prepare_data
from svy.core.design import PopSize
from svy.core.enumerations import EstimationMethod, PopParam, QuantileMethod
from svy.core.types import ExprLike, WhereArg
from svy.errors import DimensionError, MethodError
from svy.estimation.estimate import Estimate, ParamEst
from svy.ui.printing import format_where_clause
from svy.utils.helpers import _colspec_to_list


log = logging.getLogger(__name__)

if TYPE_CHECKING:
    from svy.core.sample import Sample


class Estimation:
    def __init__(self, sample: Sample) -> None:
        self._sample = sample
        self._design_cache: dict[str, Any] | None = None
        self._polars_cache: dict[str, Any] | None = None

    def _get_factorized_design(self) -> dict[str, Any]:
        if self._design_cache is not None:
            _d = self._sample._data
            _h = (
                cast(pl.DataFrame, _d.collect()).height
                if isinstance(_d, pl.LazyFrame)
                else cast(pl.DataFrame, _d).height
            )
            if self._design_cache["n_rows"] == _h:
                return self._design_cache
            else:
                self._design_cache = None

        _raw_data = self._sample._data
        local_data: pl.DataFrame = (
            cast(pl.DataFrame, _raw_data.collect())
            if isinstance(_raw_data, pl.LazyFrame)
            else cast(pl.DataFrame, _raw_data)
        )
        design = self._sample._design

        cache: dict[str, Any] = {
            "n_rows": local_data.height,
            "stratum": None,
            "psu": None,
            "ssu": None,
            "wgt": None,
        }

        def _process_component(spec: str | list[str] | tuple[str, ...] | None, name: str):
            if not spec:
                return None, None
            if isinstance(spec, str):
                target_col = spec
            elif isinstance(spec, (list, tuple)) and len(spec) == 1:
                target_col = spec[0]
            else:
                cols = list(spec)
                target_col = f"{name}{_INTERNAL_CONCAT_SUFFIX}"
                if target_col not in local_data.columns:
                    expr = pl.concat_str(
                        [pl.col(c).cast(pl.Utf8).fill_null("__Null__") for c in cols],
                        separator=_BY_SEP,
                    )
                    s_temp = local_data.select(expr.alias(target_col))[target_col]
                else:
                    s_temp = local_data[target_col]

                if s_temp.dtype in (
                    pl.Int8,
                    pl.Int16,
                    pl.Int32,
                    pl.Int64,
                    pl.UInt8,
                    pl.UInt32,
                    pl.UInt64,
                ):
                    return s_temp.to_numpy(), None
                return (
                    s_temp.cast(pl.Categorical).to_physical().to_numpy(),
                    s_temp.unique().to_list(),
                )

            s = local_data[target_col]
            if s.dtype in (pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt32, pl.UInt64):
                return s.to_numpy(), None
            return (s.cast(pl.Categorical).to_physical().to_numpy(), s.unique().to_list())

        cache["stratum"] = _process_component(design.stratum, "stratum")
        cache["psu"] = _process_component(design.psu, "psu")

        if design.ssu:
            ssu_cols = _colspec_to_list(design.ssu)
            if len(ssu_cols) == 1:
                cache["ssu"] = local_data[ssu_cols[0]].to_numpy()
            else:
                cache["ssu"] = None

        cache["wgt"] = (
            local_data[design.wgt].to_numpy()
            if design.wgt
            else np.ones(local_data.height, dtype=float)
        )

        self._design_cache = cache
        return cache

    def _get_polars_design_info(self) -> dict[str, Any]:
        if self._polars_cache is not None:
            _d2 = self._sample._data
            _h2 = (
                cast(pl.DataFrame, _d2.collect()).height
                if isinstance(_d2, pl.LazyFrame)
                else cast(pl.DataFrame, _d2).height
            )
            if self._polars_cache["n_rows"] == _h2:
                return self._polars_cache
            else:
                self._polars_cache = None

        design = self._sample._design
        _data_raw = self._sample._data
        data: pl.DataFrame = (
            cast(pl.DataFrame, _data_raw.collect())
            if isinstance(_data_raw, pl.LazyFrame)
            else cast(pl.DataFrame, _data_raw)
        )

        singleton_result = getattr(self._sample, "_singleton_result", None)
        config = singleton_result.config if singleton_result else None

        strata_col = None
        psu_col = None
        weight_col = design.wgt

        if config and config.var_stratum_col:
            strata_col = config.var_stratum_col
            psu_col = config.var_psu_col
        else:
            if design.stratum:
                if isinstance(design.stratum, str):
                    strata_col = design.stratum
                elif isinstance(design.stratum, (list, tuple)):
                    if len(design.stratum) == 1:
                        strata_col = design.stratum[0]
                    else:
                        strata_col = f"_strata_{_INTERNAL_CONCAT_SUFFIX}"
                        if strata_col not in data.columns:
                            expr = pl.concat_str(
                                [
                                    pl.col(c).cast(pl.String).fill_null("__Null__")
                                    for c in design.stratum
                                ],
                                separator=_BY_SEP,
                            )
                            data = data.with_columns(expr.alias(strata_col))

            if design.psu:
                if isinstance(design.psu, str):
                    psu_col = design.psu
                elif isinstance(design.psu, (list, tuple)):
                    if len(design.psu) == 1:
                        psu_col = design.psu[0]
                    else:
                        psu_col = f"_psu_{_INTERNAL_CONCAT_SUFFIX}"
                        if psu_col not in data.columns:
                            expr = pl.concat_str(
                                [
                                    pl.col(c).cast(pl.String).fill_null("__Null__")
                                    for c in design.psu
                                ],
                                separator=_BY_SEP,
                            )
                            data = data.with_columns(expr.alias(psu_col))

        casts = []
        if strata_col and data[strata_col].dtype != pl.String:
            casts.append(pl.col(strata_col).cast(pl.String))
        if psu_col and data[psu_col].dtype != pl.String:
            casts.append(pl.col(psu_col).cast(pl.String))

        # Resolve SSU column
        ssu_col = None
        ssu_spec = getattr(design, "ssu", None)
        if ssu_spec:
            if isinstance(ssu_spec, str):
                ssu_col = ssu_spec
            elif isinstance(ssu_spec, (list, tuple)) and len(ssu_spec) == 1:
                ssu_col = ssu_spec[0]
        if ssu_col and ssu_col in data.columns and data[ssu_col].dtype != pl.String:
            casts.append(pl.col(ssu_col).cast(pl.String))

        if casts:
            data = data.with_columns(casts)

        if not weight_col:
            weight_col = "__unit_wgt__"
            if weight_col not in data.columns:
                data = data.with_columns(pl.lit(1.0).alias(weight_col))
        else:
            if data[weight_col].dtype != pl.Float64:
                data = data.with_columns(pl.col(weight_col).cast(pl.Float64))

        # --- FPC column computation ---
        fpc_col = None
        fpc_ssu_col = None
        pop_size = getattr(design, "pop_size", None)

        if pop_size is not None:
            data, fpc_col, fpc_ssu_col = self._compute_fpc_columns(
                data=data,
                pop_size=pop_size,
                strata_col=strata_col,
                psu_col=psu_col,
                ssu_col=ssu_col,
            )

        _fin = self._sample._data
        _fin_h = (
            cast(pl.DataFrame, _fin.collect()).height
            if isinstance(_fin, pl.LazyFrame)
            else cast(pl.DataFrame, _fin).height
        )
        self._polars_cache = {
            "n_rows": _fin_h,
            "data": data,
            "strata_col": strata_col,
            "psu_col": psu_col,
            "ssu_col": ssu_col,
            "weight_col": weight_col,
            "fpc_col": fpc_col,
            "fpc_ssu_col": fpc_ssu_col,
            "singleton_config": config,
        }
        return self._polars_cache

    def _compute_fpc_columns(
        self,
        data: pl.DataFrame,
        pop_size: str | PopSize,
        strata_col: str | None,
        psu_col: str | None,
        ssu_col: str | None = None,
    ) -> tuple[pl.DataFrame, str | None, str | None]:
        """
        Compute per-row FPC columns from population size specification.

        For single-stage FPC (pop_size is str):
            fpc_psu = (N_h - n_h) / N_h per stratum, where n_h = number of PSUs in stratum h.
            If no strata, uses a single global FPC.

        For two-stage FPC (pop_size is PopSize):
            fpc_psu = (N_h - n_h) / N_h per stratum (PSU level)
            fpc_ssu = (M_hi - m_hi) / M_hi per PSU (SSU level)

        Parameters
        ----------
        data : pl.DataFrame
            The working data (may be modified with new columns).
        pop_size : str | PopSize
            Column name(s) for population sizes.
        strata_col : str | None
            Resolved stratum column name.
        psu_col : str | None
            Resolved PSU column name.
        ssu_col : str | None
            Resolved SSU column name (used for counting distinct SSUs per PSU).

        Returns
        -------
        tuple[pl.DataFrame, str | None, str | None]
            (data_with_fpc_cols, fpc_col_name, fpc_ssu_col_name)
        """
        _FPC_PSU_COL = "__svy_fpc_psu__"
        _FPC_SSU_COL = "__svy_fpc_ssu__"

        fpc_col_name: str | None = None
        fpc_ssu_col_name: str | None = None

        if isinstance(pop_size, str):
            # Single-stage FPC: pop_size column contains N (population size at PSU level)
            pop_col = pop_size
            if pop_col not in data.columns:
                log.warning("FPC column '%s' not found in data; skipping FPC.", pop_col)
                return data, None, None

            data, fpc_col_name = self._build_fpc_psu_column(
                data, pop_col, strata_col, psu_col, _FPC_PSU_COL
            )

        elif isinstance(pop_size, PopSize):
            # Two-stage FPC
            psu_pop_col = pop_size.psu
            ssu_pop_col = pop_size.ssu

            if psu_pop_col not in data.columns:
                log.warning("FPC PSU column '%s' not found in data; skipping FPC.", psu_pop_col)
                return data, None, None

            # Stage 1: PSU-level FPC
            data, fpc_col_name = self._build_fpc_psu_column(
                data, psu_pop_col, strata_col, psu_col, _FPC_PSU_COL
            )

            # Stage 2: SSU-level FPC
            if ssu_pop_col in data.columns and psu_col is not None:
                data, fpc_ssu_col_name = self._build_fpc_ssu_column(
                    data, ssu_pop_col, psu_col, ssu_col, _FPC_SSU_COL
                )
            elif ssu_pop_col not in data.columns:
                log.warning(
                    "FPC SSU column '%s' not found in data; skipping SSU FPC.", ssu_pop_col
                )

        return data, fpc_col_name, fpc_ssu_col_name

    def _build_fpc_psu_column(
        self,
        data: pl.DataFrame,
        pop_col: str,
        strata_col: str | None,
        psu_col: str | None,
        out_col: str,
    ) -> tuple[pl.DataFrame, str]:
        """
        Build per-row FPC column for PSU level: (N_h - n_h) / N_h.

        N_h is the population size (from pop_col, constant within stratum).
        n_h is the number of distinct PSUs in stratum h (counted from data).
        If no PSU column, n_h = number of rows in the stratum.
        """
        _WHERE = "estimation.fpc"

        # Validate: all values must be >= 1 (population counts, not fractions)
        min_val = data[pop_col].cast(pl.Float64).min()
        if min_val is not None and min_val < 1:
            raise MethodError(
                title="Invalid FPC values",
                detail=f"FPC column '{pop_col}' contains values < 1 ({min_val}). "
                f"Population sizes must be counts (N >= 1), not sampling fractions.",
                code="FPC_INVALID_VALUES",
                where=_WHERE,
                param="pop_size",
                expected="N >= 1 (population counts)",
                got=min_val,
                hint="Use population counts (e.g., 500), not sampling fractions (e.g., 0.2).",
            )

        if strata_col is not None:
            # Validate: pop_col must be constant within each stratum
            n_unique_per_stratum = data.group_by(strata_col).agg(
                pl.col(pop_col).n_unique().alias("__nuniq__")
            )
            non_constant = n_unique_per_stratum.filter(pl.col("__nuniq__") > 1)
            if non_constant.height > 0:
                bad_strata = non_constant[strata_col].to_list()
                raise DimensionError(
                    title="FPC not constant within strata",
                    detail=f"FPC column '{pop_col}' varies within strata: {bad_strata}. "
                    f"Population size must be the same for all observations in a stratum.",
                    code="FPC_NOT_CONSTANT",
                    where=_WHERE,
                    param="pop_size",
                    expected="constant N within each stratum",
                    got=f"varying values in strata {bad_strata}",
                    hint="Ensure each row in a stratum has the same population size value.",
                )

            # Count distinct PSUs per stratum
            if psu_col is not None:
                n_per_stratum = data.group_by(strata_col).agg(
                    pl.col(psu_col).n_unique().alias("__n_h__")
                )
            else:
                n_per_stratum = data.group_by(strata_col).agg(pl.len().alias("__n_h__"))

            # Get N_h per stratum
            pop_per_stratum = data.group_by(strata_col).agg(
                pl.col(pop_col).first().cast(pl.Float64).alias("__N_h__")
            )

            # Validate: N_h >= n_h for every stratum
            check = n_per_stratum.join(pop_per_stratum, on=strata_col)
            bad = check.filter(pl.col("__N_h__") < pl.col("__n_h__").cast(pl.Float64))
            if bad.height > 0:
                bad_strata = bad[strata_col].to_list()
                raise DimensionError(
                    title="FPC population size < sample size",
                    detail=f"FPC column '{pop_col}' has population size < sample size "
                    f"in strata: {bad_strata}.",
                    code="FPC_POP_LT_SAMPLE",
                    where=_WHERE,
                    param="pop_size",
                    expected="N >= n (population >= sampled PSUs)",
                    got=f"N < n in strata {bad_strata}",
                    hint="Population size N must be >= the number of sampled PSUs n in every stratum.",
                )

            # Compute FPC
            stratum_fpc = (
                n_per_stratum.join(pop_per_stratum, on=strata_col)
                .with_columns(
                    ((pl.col("__N_h__") - pl.col("__n_h__").cast(pl.Float64)) / pl.col("__N_h__"))
                    .clip(0.0, 1.0)
                    .alias(out_col)
                )
                .select([strata_col, out_col])
            )

            data = data.join(stratum_fpc, on=strata_col, how="left")
        else:
            # Unstratified: pop_col must be constant across all rows
            n_unique = data[pop_col].n_unique()
            if n_unique > 1:
                raise DimensionError(
                    title="FPC not constant in unstratified design",
                    detail=f"FPC column '{pop_col}' has {n_unique} distinct values, "
                    f"but must be constant for unstratified designs.",
                    code="FPC_NOT_CONSTANT",
                    where=_WHERE,
                    param="pop_size",
                    expected="constant N across all observations",
                    got=f"{n_unique} distinct values",
                    hint="If different groups have different population sizes, "
                    "specify strata in the Design.",
                )

            n_h = data[psu_col].n_unique() if psu_col is not None else data.height
            n_pop = data[pop_col].cast(pl.Float64).first()

            if n_pop is not None and n_pop < n_h:
                raise DimensionError(
                    title="FPC population size < sample size",
                    detail=f"FPC column '{pop_col}' has population size ({n_pop}) < "
                    f"sample size ({n_h}).",
                    code="FPC_POP_LT_SAMPLE",
                    where=_WHERE,
                    param="pop_size",
                    expected=f"N >= {n_h}",
                    got=n_pop,
                    hint="Population size N must be >= the number of sampled PSUs n.",
                )

            if n_pop is not None and n_pop > 0:
                fpc_val = max(0.0, min(1.0, (n_pop - n_h) / n_pop))
            else:
                fpc_val = 1.0
            data = data.with_columns(pl.lit(fpc_val).alias(out_col))

        return data, out_col

    def _build_fpc_ssu_column(
        self,
        data: pl.DataFrame,
        pop_col: str,
        psu_col: str,
        ssu_col: str | None,
        out_col: str,
    ) -> tuple[pl.DataFrame, str]:
        """
        Build per-row FPC column for SSU level: (M_hi - m_hi) / M_hi.

        M_hi is the SSU population size within PSU i (from pop_col, constant within PSU).
        m_hi is the number of distinct SSUs sampled in PSU i.
        If ssu_col is None, falls back to counting rows per PSU.
        """
        _WHERE = "estimation.fpc"

        # Validate: all values must be >= 1 (population counts)
        min_val = data[pop_col].cast(pl.Float64).min()
        if min_val is not None and min_val < 1:
            raise MethodError(
                title="Invalid FPC values",
                detail=f"FPC column '{pop_col}' contains values < 1 ({min_val}). "
                f"Population sizes must be counts (N >= 1), not sampling fractions.",
                code="FPC_INVALID_VALUES",
                where=_WHERE,
                param="pop_size.ssu",
                expected="M >= 1 (population counts)",
                got=min_val,
                hint="Use population counts (e.g., 50), not sampling fractions (e.g., 0.3).",
            )

        # Validate: pop_col must be constant within each PSU
        n_unique_per_psu = data.group_by(psu_col).agg(
            pl.col(pop_col).n_unique().alias("__nuniq__")
        )
        non_constant = n_unique_per_psu.filter(pl.col("__nuniq__") > 1)
        if non_constant.height > 0:
            bad_psus = non_constant[psu_col].to_list()
            raise DimensionError(
                title="FPC not constant within PSUs",
                detail=f"FPC column '{pop_col}' varies within PSUs: {bad_psus}. "
                f"SSU population size must be the same for all observations in a PSU.",
                code="FPC_NOT_CONSTANT",
                where=_WHERE,
                param="pop_size.ssu",
                expected="constant M within each PSU",
                got=f"varying values in PSUs {bad_psus}",
                hint="Ensure each row in a PSU has the same SSU population size value.",
            )

        # Count distinct SSUs per PSU (or rows if no SSU column)
        if ssu_col is not None and ssu_col in data.columns:
            n_per_psu = data.group_by(psu_col).agg(pl.col(ssu_col).n_unique().alias("__m_hi__"))
        else:
            n_per_psu = data.group_by(psu_col).agg(pl.len().alias("__m_hi__"))

        # Get M_hi per PSU
        pop_per_psu = data.group_by(psu_col).agg(
            pl.col(pop_col).first().cast(pl.Float64).alias("__M_hi__")
        )

        # Validate: M_hi >= m_hi for every PSU
        check = n_per_psu.join(pop_per_psu, on=psu_col)
        bad = check.filter(pl.col("__M_hi__") < pl.col("__m_hi__").cast(pl.Float64))
        if bad.height > 0:
            bad_psus = bad[psu_col].to_list()
            raise DimensionError(
                title="FPC population size < sample size",
                detail=f"FPC column '{pop_col}' has population size < sample size "
                f"in PSUs: {bad_psus}.",
                code="FPC_POP_LT_SAMPLE",
                where=_WHERE,
                param="pop_size.ssu",
                expected="M >= m (population >= sampled SSUs)",
                got=f"M < m in PSUs {bad_psus}",
                hint="SSU population size M must be >= the number of sampled SSUs m in every PSU.",
            )

        # Compute FPC
        psu_fpc = (
            n_per_psu.join(pop_per_psu, on=psu_col)
            .with_columns(
                ((pl.col("__M_hi__") - pl.col("__m_hi__").cast(pl.Float64)) / pl.col("__M_hi__"))
                .clip(0.0, 1.0)
                .alias(out_col)
            )
            .select([psu_col, out_col])
        )

        data = data.join(psu_fpc, on=psu_col, how="left")
        return data, out_col

    def _ensure_float64(self, data: pl.DataFrame, cols: list[str]) -> pl.DataFrame:
        casts = [
            pl.col(c).cast(pl.Float64)
            for c in cols
            if c in data.columns and data[c].dtype != pl.Float64
        ]
        return data.with_columns(casts) if casts else data

    def _coerce_y_for_prop(self, data: pl.DataFrame, y: str) -> pl.DataFrame:
        """Cast y to Int64 for integer types before passing to Rust prop functions.
        Raises for float columns. String/Categorical/Enum/Boolean pass through unchanged.
        Only the local copy passed to Rust is modified — the sample data is never touched.
        """
        if y not in data.columns:
            return data
        dtype = data[y].dtype
        if dtype in (pl.Float32, pl.Float64):
            raise TypeError(
                f"prop() does not support float column '{y}'. "
                f"Use a String, Categorical, Enum, Boolean, or integer column."
            )
        if dtype.is_integer() and dtype != pl.Int64:
            return data.with_columns(pl.col(y).cast(pl.Int64))
        return data

    def _get_enum_value(self, config, attr="method") -> str:
        if not hasattr(config, attr):
            return ""
        val = getattr(config, attr)
        return str(val.value) if hasattr(val, "value") else str(val)

    def _adjust_variance_for_singletons(
        self, result_df: pl.DataFrame, param: PopParam = PopParam.TOTAL
    ) -> pl.DataFrame:
        """Legacy helper for tests. New code uses _apply_scale_adjustment."""
        return self._apply_scale_adjustment(result_df, result_df, param=param)

    def _get_center_method(self) -> str | None:
        cache = self._get_polars_design_info()
        config = cache.get("singleton_config")
        if config:
            method_str = self._get_enum_value(config, "method").lower()
            if method_str in ("center", "adjust"):
                return "center"
        return None

    def _should_run_double_pass(self) -> bool:
        cache = self._get_polars_design_info()
        config = cache.get("singleton_config")
        if config:
            return self._get_enum_value(config, "method").lower() == "scale"
        return False

    def _apply_scale_adjustment(
        self, full_df: pl.DataFrame, filtered_df: pl.DataFrame, param: PopParam = PopParam.TOTAL
    ) -> pl.DataFrame:
        """
        Merge Point Estimate (from full_df) and Variance (from filtered_df)
        and apply inflation factor for SCALE method.
        """
        cache = self._get_polars_design_info()
        config = cache.get("singleton_config")

        if not config:
            return filtered_df

        method_str = self._get_enum_value(config, "method").lower()
        if method_str != "scale":
            return filtered_df

        f = config.singleton_fraction
        if f is None or f >= 1.0:
            return filtered_df

        if param == PopParam.TOTAL:
            inflation_factor = 1.0 / (1.0 - f)
        else:
            inflation_factor = 1.0 - f

        sqrt_factor = math.sqrt(inflation_factor)

        if full_df is filtered_df:
            merged = filtered_df
        else:
            std_cols = {"y", "est", "se", "var", "df", "n", "deff", "level"}
            extra_cols = [c for c in filtered_df.columns if c not in std_cols]
            by_col_name = extra_cols[0] if extra_cols else None

            join_on = ["y"]
            if by_col_name:
                join_on.append(by_col_name)
            if "level" in filtered_df.columns:
                join_on.append("level")

            full_subset = full_df.select(join_on + ["est"])

            if "est" in filtered_df.columns:
                merged = filtered_df.drop("est").join(full_subset, on=join_on, how="left")
            else:
                merged = filtered_df.join(full_subset, on=join_on, how="left")

        return merged.with_columns(
            (pl.col("var") * inflation_factor).alias("var"),
            (pl.col("se") * sqrt_factor).alias("se"),
        )

    def _compute_prop_ci(
        self,
        p: float,
        se: float,
        t_crit: float,
        method: str,
    ) -> tuple[float, float]:
        """Compute confidence interval for a proportion."""
        if method == "logit":
            if p <= 0 or p >= 1:
                return (p, p)
            scale = se / (p * (1.0 - p)) if se > 0 else 0
            logit = math.log(p / (1 - p))
            lci = 1.0 / (1.0 + math.exp(-(logit - t_crit * scale)))
            uci = 1.0 / (1.0 + math.exp(-(logit + t_crit * scale)))
            return (lci, uci)

        elif method == "beta":
            from scipy.stats import beta as beta_dist
            from scipy.stats import norm

            if p <= 0 or p >= 1 or se <= 0:
                return (p, p)

            n_eff = (p * (1 - p)) / (se**2)
            alpha_param = max(0.5, p * n_eff)
            beta_param = max(0.5, (1 - p) * n_eff)
            prob_lower = norm.cdf(-t_crit)
            prob_upper = norm.cdf(t_crit)
            lci = beta_dist.ppf(prob_lower, alpha_param, beta_param)
            uci = beta_dist.ppf(prob_upper, alpha_param, beta_param)
            return (lci, uci)

        else:
            raise ValueError(f"Unknown CI method: {method}")

    def _polars_result_to_param_est(
        self,
        result_df: pl.DataFrame,
        y_name: str,
        param: PopParam,
        alpha: float,
        deff: bool,
        by_col: str | None,
        as_factor: bool,
        x_name: str | None = None,
        ci_method: str = "logit",
    ) -> list[ParamEst]:
        est_list = []

        for row in result_df.iter_rows(named=True):
            est = row["est"]
            se = row["se"]
            df_val = row["df"]

            cv = se / est if est != 0 else float("inf")
            t_crit = stats.t.ppf(1 - alpha / 2, df_val) if df_val > 0 else 1.96

            is_prop = (param == PopParam.PROP) or as_factor
            if is_prop:
                lci, uci = self._compute_prop_ci(p=est, se=se, t_crit=t_crit, method=ci_method)
            else:
                lci = est - t_crit * se
                uci = est + t_crit * se

            deff_val = row.get("deff") if deff else None

            by_level = None
            if by_col and by_col in row:
                by_level = (row[by_col],)

            y_level = None
            if as_factor and "level" in row:
                level_val = row["level"]
                try:
                    y_level = int(level_val)
                except (ValueError, TypeError):
                    y_level = level_val

            p = ParamEst(
                y=y_name,
                est=est,
                se=se,
                cv=cv,
                lci=lci,
                uci=uci,
                deff=deff_val,
                by=(by_col,) if by_col else None,
                by_level=by_level,
                y_level=y_level,
                x=x_name,
            )
            est_list.append(p)

        return est_list

    def _median_result_to_param_est(
        self,
        result_df: pl.DataFrame,
        y_name: str,
        alpha: float,
        by_col: str | None,
        data: pl.DataFrame,
        weight_col: str,
    ) -> list[ParamEst]:
        """
        Convert Rust median result to ParamEst list.
        Uses Woodruff method to compute CI by inverting the CDF.
        """
        est_list = []

        for row in result_df.iter_rows(named=True):
            est = row["est"]
            se_p = row["se"]
            df_val = row["df"]

            t_crit = stats.t.ppf(1 - alpha / 2, df_val) if df_val > 0 else 1.96

            # Woodruff CI: invert CDF at p ± t*se_p
            p_lower = max(0.0, 0.5 - t_crit * se_p)
            p_upper = min(1.0, 0.5 + t_crit * se_p)

            # Get domain filter if applicable
            if by_col and by_col in row:
                domain_val = row[by_col]
                domain_data = data.filter(pl.col(by_col) == domain_val)
            else:
                domain_data = data

            # Invert CDF to get quantile CI
            lci = self._invert_cdf(domain_data, y_name, weight_col, p_lower)
            uci = self._invert_cdf(domain_data, y_name, weight_col, p_upper)

            # SE on quantile scale (approximate)
            se_q = (uci - lci) / (2 * t_crit) if t_crit > 0 else se_p
            cv = se_q / est if est != 0 else float("inf")

            by_level = None
            if by_col and by_col in row:
                by_level = (row[by_col],)

            p = ParamEst(
                y=y_name,
                est=est,
                se=se_q,
                cv=cv,
                lci=lci,
                uci=uci,
                deff=None,
                by=(by_col,) if by_col else None,
                by_level=by_level,
                y_level=None,
                x=None,
            )
            est_list.append(p)

        return est_list

    def _invert_cdf(
        self,
        data: pl.DataFrame,
        y_col: str,
        weight_col: str,
        p: float,
    ) -> float:
        """Invert the weighted CDF to find the quantile at probability p."""
        df = data.select([y_col, weight_col]).drop_nulls()
        if df.height == 0:
            return float("nan")

        df = df.sort(y_col)
        y_vals = df[y_col].to_numpy()
        w_vals = df[weight_col].to_numpy()

        cumsum = np.cumsum(w_vals)
        total = cumsum[-1]
        if total <= 0:
            return float("nan")

        cdf = cumsum / total

        if p <= 0:
            return float(y_vals[0])
        if p >= 1:
            return float(y_vals[-1])

        idx = np.searchsorted(cdf, p)

        if idx == 0:
            return float(y_vals[0])
        if idx >= len(y_vals):
            return float(y_vals[-1])

        p_low = cdf[idx - 1]
        p_high = cdf[idx]
        y_low = y_vals[idx - 1]
        y_high = y_vals[idx]

        if p_high == p_low:
            return float(y_high)

        frac = (p - p_low) / (p_high - p_low)
        return float(y_low + frac * (y_high - y_low))

    def _replicate_median_result_to_param_est(
        self,
        result_df: pl.DataFrame,
        y_name: str,
        alpha: float,
        by_col: str | None,
    ) -> list[ParamEst]:
        """Convert Rust replicate median result to ParamEst list."""
        est_list = []

        for row in result_df.iter_rows(named=True):
            est = row["est"]
            se = row["se"]
            df_val = row["df"]

            cv = se / est if est != 0 else float("inf")
            t_crit = stats.t.ppf(1 - alpha / 2, df_val) if df_val > 0 else 1.96

            lci = est - t_crit * se
            uci = est + t_crit * se

            by_level = None
            if by_col and by_col in row:
                by_level = (row[by_col],)

            p = ParamEst(
                y=y_name,
                est=est,
                se=se,
                cv=cv,
                lci=lci,
                uci=uci,
                deff=None,
                by=(by_col,) if by_col else None,
                by_level=by_level,
                y_level=None,
                x=None,
            )
            est_list.append(p)

        return est_list

    def _build_estimate_result_light(
        self,
        est_list: list[ParamEst],
        est_cov: np.ndarray,
        param: PopParam,
        alpha: float,
        by_cols: list[str],
        as_factor: bool,
        method: EstimationMethod = EstimationMethod.TAYLOR,
        rust_df: int | None = None,
    ) -> Estimate:
        metadata = getattr(self._sample, "_metadata", None)
        estimate = Estimate(param, alpha=alpha, metadata=metadata)
        estimate.method = method
        estimate.covariance = est_cov
        estimate.as_factor = as_factor

        if by_cols and len(by_cols) > 0:
            by_tuple = tuple(by_cols)
            final_ests = []
            for p in est_list:
                # When multiple by cols were concatenated, split back into a tuple
                by_level = p.by_level
                if by_level and len(by_cols) > 1 and len(by_level) == 1:
                    parts = str(by_level[0]).split("__by__", maxsplit=len(by_cols) - 1)
                    by_level = tuple(parts) if len(parts) == len(by_cols) else by_level

                new_p = ParamEst(
                    y=p.y,
                    est=p.est,
                    se=p.se,
                    cv=p.cv,
                    lci=p.lci,
                    uci=p.uci,
                    deff=p.deff,
                    by=by_tuple,
                    by_level=by_level,
                    y_level=p.y_level,
                    x=p.x,
                    x_level=p.x_level,
                )
                final_ests.append(new_p)
            estimate.estimates = final_ests
        else:
            estimate.estimates = est_list

        d_cache = self._get_factorized_design()

        if d_cache["stratum"] is not None:
            strata_info = d_cache["stratum"]
            if isinstance(strata_info, tuple) and strata_info[1] is not None:
                estimate.strata = strata_info[1]
                estimate.n_strata = len(strata_info[1])
            else:
                arr = strata_info[0] if isinstance(strata_info, tuple) else strata_info
                estimate.strata = np.unique(arr).tolist()
                estimate.n_strata = len(estimate.strata)

        if d_cache["psu"] is not None:
            psu_info = d_cache["psu"]
            if isinstance(psu_info, tuple) and psu_info[1] is not None:
                estimate.n_psus = len(psu_info[1])
            else:
                arr = psu_info[0] if isinstance(psu_info, tuple) else psu_info
                estimate.n_psus = len(np.unique(arr))
        elif d_cache["wgt"] is not None:
            estimate.n_psus = len(d_cache["wgt"])

        estimate.degrees_freedom = (
            rust_df
            if rust_df is not None
            else max(0, (estimate.n_psus or 0) - (estimate.n_strata or 0))
        )

        return estimate

    def _resolve_method(self, user_method: EstimationMethod | None) -> EstimationMethod:
        if user_method is not None:
            return user_method
        design_rw = self._sample._design.rep_wgts
        if design_rw is not None:
            return design_rw.method
        return EstimationMethod.TAYLOR

    # ----------------------------------------------------------------
    # Domain Estimation Helpers
    # ----------------------------------------------------------------
    def _compile_where_expr(self, where: WhereArg) -> pl.Expr:
        """Compile where clause to Polars expression using wrangling helper."""
        result = self._sample.wrangling._compile_where_to_pl_expr(where)
        return cast(pl.Expr, result)

    # ----------------------------------------------------------------
    # Unified Public APIs
    # ----------------------------------------------------------------

    def _empty_estimate(
        self, param: PopParam, alpha: float, by_cols: list[str], method: EstimationMethod
    ) -> Estimate:
        """Return an empty Estimate for cases like zero-weight domains."""
        metadata = getattr(self._sample, "_metadata", None)
        est = Estimate(param, alpha=alpha, metadata=metadata)
        est.method = method
        est.estimates = []
        est.covariance = np.array([])
        return est

    def mean(
        self,
        y: str,
        *,
        by: str | Sequence[str] | None = None,
        where: WhereArg = None,
        method: EstimationMethod | None = None,
        deff: bool = False,
        fay_coef: float = 0.0,
        as_factor: bool = False,
        variance_center: Literal["rep_mean", "estimate"] = "rep_mean",
        alpha: float = 0.05,
        drop_nulls: bool = False,
    ) -> Estimate:
        """Estimate population mean with standard errors."""
        target_method = self._resolve_method(method)
        prep = prepare_data(
            self._sample,
            y=y,
            by=by,
            where=where,
            drop_nulls=drop_nulls,
            cast_y_float=True,
            apply_singleton_filter=True,
            select_columns=True,
        )

        try:
            if target_method == EstimationMethod.TAYLOR:
                result = self._taylor_mean_polars(
                    prep=prep,
                    y=y,
                    deff=deff,
                    alpha=alpha,
                    as_factor=as_factor,
                    param=PopParam.MEAN,
                )
            else:
                result = self._replicate_estimate(
                    prep=prep,
                    method=target_method,
                    param=PopParam.MEAN,
                    y=y,
                    fay_coef=fay_coef,
                    as_factor=as_factor,
                    variance_center=variance_center,
                    alpha=alpha,
                )
        except RuntimeError as e:
            if "weights is zero" in str(e).lower() or "sum of weights" in str(e).lower():
                result = self._empty_estimate(
                    PopParam.MEAN, alpha, _colspec_to_list(by), target_method
                )
            else:
                raise

        if where is not None:
            result.where_clause = format_where_clause(where)
        return result

    def total(
        self,
        y: str,
        *,
        by: str | Sequence[str] | None = None,
        where: WhereArg = None,
        method: EstimationMethod | None = None,
        deff: bool = False,
        fay_coef: float = 0.0,
        as_factor: bool = False,
        variance_center: Literal["rep_mean", "estimate"] = "rep_mean",
        alpha: float = 0.05,
        drop_nulls: bool = False,
    ) -> Estimate:
        """Estimate population total with standard errors."""
        target_method = self._resolve_method(method)
        prep = prepare_data(
            self._sample,
            y=y,
            by=by,
            where=where,
            drop_nulls=drop_nulls,
            cast_y_float=True,
            apply_singleton_filter=True,
            select_columns=True,
        )

        try:
            if target_method == EstimationMethod.TAYLOR:
                result = self._taylor_total_polars(
                    prep=prep,
                    y=y,
                    deff=deff,
                    alpha=alpha,
                    as_factor=as_factor,
                )
            else:
                result = self._replicate_estimate(
                    prep=prep,
                    method=target_method,
                    param=PopParam.TOTAL,
                    y=y,
                    fay_coef=fay_coef,
                    as_factor=as_factor,
                    variance_center=variance_center,
                    alpha=alpha,
                )
        except RuntimeError as e:
            if "weights is zero" in str(e).lower() or "sum of weights" in str(e).lower():
                result = self._empty_estimate(
                    PopParam.TOTAL, alpha, _colspec_to_list(by), target_method
                )
            else:
                raise

        if where is not None:
            result.where_clause = format_where_clause(where)
        return result

    def prop(
        self,
        y: str,
        *,
        by: str | Sequence[str] | None = None,
        where: WhereArg = None,
        method: EstimationMethod | None = None,
        ci_method: Literal["logit", "beta"] = "logit",
        deff: bool = False,
        fay_coef: float = 0.0,
        variance_center: Literal["rep_mean", "estimate"] = "rep_mean",
        alpha: float = 0.05,
        drop_nulls: bool = False,
    ) -> Estimate:
        """Estimate population proportion with standard errors."""
        target_method = self._resolve_method(method)
        prep = prepare_data(
            self._sample,
            y=y,
            by=by,
            where=where,
            drop_nulls=drop_nulls,
            cast_y_float=False,
            apply_singleton_filter=True,
            select_columns=True,
        )

        try:
            if target_method == EstimationMethod.TAYLOR:
                result = self._taylor_prop_polars(
                    prep=prep,
                    y=y,
                    deff=deff,
                    alpha=alpha,
                    ci_method=ci_method,
                )
            else:
                result = self._replicate_estimate(
                    prep=prep,
                    method=target_method,
                    param=PopParam.PROP,
                    y=y,
                    fay_coef=fay_coef,
                    as_factor=True,
                    variance_center=variance_center,
                    alpha=alpha,
                    ci_method=ci_method,
                )
        except RuntimeError as e:
            if "weights is zero" in str(e).lower() or "sum of weights" in str(e).lower():
                result = self._empty_estimate(
                    PopParam.PROP, alpha, _colspec_to_list(by), target_method
                )
            else:
                raise

        if where is not None:
            result.where_clause = format_where_clause(where)
        return result

    def ratio(
        self,
        y: str,
        x: str,
        *,
        by: str | Sequence[str] | None = None,
        where: WhereArg = None,
        method: EstimationMethod | None = None,
        deff: bool = False,
        fay_coef: float = 0.0,
        variance_center: Literal["rep_mean", "estimate"] = "rep_mean",
        alpha: float = 0.05,
        drop_nulls: bool = False,
    ) -> Estimate:
        """Estimate population ratio (y/x) with standard errors."""
        target_method = self._resolve_method(method)
        prep = prepare_data(
            self._sample,
            y=y,
            x=x,
            by=by,
            where=where,
            drop_nulls=drop_nulls,
            cast_y_float=True,
            apply_singleton_filter=True,
            select_columns=True,
        )

        try:
            if target_method == EstimationMethod.TAYLOR:
                result = self._taylor_ratio_polars(
                    prep=prep,
                    y=y,
                    x=x,
                    deff=deff,
                    alpha=alpha,
                )
            else:
                result = self._replicate_estimate(
                    prep=prep,
                    method=target_method,
                    param=PopParam.RATIO,
                    y=y,
                    x=x,
                    fay_coef=fay_coef,
                    variance_center=variance_center,
                    alpha=alpha,
                )
        except RuntimeError as e:
            if "weights is zero" in str(e).lower() or "sum of weights" in str(e).lower():
                result = self._empty_estimate(
                    PopParam.RATIO, alpha, _colspec_to_list(by), target_method
                )
            else:
                raise

        if where is not None:
            result.where_clause = format_where_clause(where)
        return result

    def median(
        self,
        y: str,
        *,
        by: str | Sequence[str] | None = None,
        where: WhereArg = None,
        method: EstimationMethod | None = None,
        fay_coef: float = 0.0,
        q_method: QuantileMethod = QuantileMethod.HIGHER,
        variance_center: Literal["rep_mean", "estimate"] = "rep_mean",
        alpha: float = 0.05,
        drop_nulls: bool = False,
    ) -> Estimate:
        """Estimate population median with standard errors."""
        target_method = self._resolve_method(method)
        prep = prepare_data(
            self._sample,
            y=y,
            by=by,
            where=where,
            drop_nulls=drop_nulls,
            cast_y_float=True,
            apply_singleton_filter=True,
            select_columns=True,
        )

        try:
            if target_method == EstimationMethod.TAYLOR:
                result = self._taylor_median_polars(
                    prep=prep,
                    y=y,
                    q_method=q_method,
                    alpha=alpha,
                )
            else:
                result = self._replicate_median_polars(
                    prep=prep,
                    y=y,
                    method=target_method,
                    fay_coef=fay_coef,
                    q_method=q_method,
                    variance_center=variance_center,
                    alpha=alpha,
                )
        except RuntimeError as e:
            if "weights is zero" in str(e).lower() or "sum of weights" in str(e).lower():
                result = self._empty_estimate(
                    PopParam.MEDIAN, alpha, _colspec_to_list(by), target_method
                )
            else:
                raise

        if where is not None:
            result.where_clause = format_where_clause(where)
        return result

    # ----------------------------------------------------------------
    # Internal Taylor Helpers - Polars Backend
    # ----------------------------------------------------------------

    def _taylor_mean_polars(
        self,
        prep: PreparedData,
        y: str,
        *,
        param: PopParam = PopParam.MEAN,
        deff: bool = False,
        as_factor: bool = False,
        alpha: float = 0.05,
    ) -> Estimate:
        pop_size = getattr(self._sample._design, "pop_size", None)
        df, fpc_col, fpc_ssu_col = (
            self._compute_fpc_columns(
                prep.df, pop_size, prep.strata_col, prep.psu_col, prep.ssu_col
            )
            if pop_size is not None
            else (prep.df, None, None)
        )

        center_arg = self._get_center_method()
        fn = rs.taylor_prop if as_factor else rs.taylor_mean

        result_df = fn(
            df,
            value_col=y,
            weight_col=prep.weight_col,
            strata_col=prep.strata_col,
            psu_col=prep.psu_col,
            ssu_col=prep.ssu_col,
            fpc_col=fpc_col,
            fpc_ssu_col=fpc_ssu_col,
            by_col=prep.by_col,
            singleton_method=center_arg,
        )

        if self._should_run_double_pass():
            cache = self._get_polars_design_info()
            df_full = cache["data"]
            if y in df_full.columns and df_full[y].dtype != pl.Float64:
                df_full = df_full.with_columns(pl.col(y).cast(pl.Float64))
            result_full = fn(
                df_full,
                value_col=y,
                weight_col=cache["weight_col"],
                strata_col=cache["strata_col"],
                psu_col=cache["psu_col"],
                ssu_col=cache.get("ssu_col"),
                fpc_col=cache.get("fpc_col"),
                fpc_ssu_col=cache.get("fpc_ssu_col"),
                by_col=prep.by_col,
                singleton_method=center_arg,
            )
            result_df = self._apply_scale_adjustment(result_full, result_df, param=param)

        est_list = self._polars_result_to_param_est(
            result_df, y, param, alpha, deff, prep.by_col, as_factor
        )
        est_cov = np.diag(result_df["var"].to_numpy())
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            param,
            alpha,
            prep.by_cols,
            as_factor,
            method=EstimationMethod.TAYLOR,
            rust_df=int(result_df["df"].min()),
        )

    def _taylor_total_polars(
        self,
        prep: PreparedData,
        y: str,
        *,
        deff: bool = False,
        as_factor: bool = False,
        alpha: float = 0.05,
    ) -> Estimate:
        pop_size = getattr(self._sample._design, "pop_size", None)
        df, fpc_col, fpc_ssu_col = (
            self._compute_fpc_columns(
                prep.df, pop_size, prep.strata_col, prep.psu_col, prep.ssu_col
            )
            if pop_size is not None
            else (prep.df, None, None)
        )
        center_arg = self._get_center_method()

        result_df = rs.taylor_total(
            df,
            value_col=y,
            weight_col=prep.weight_col,
            strata_col=prep.strata_col,
            psu_col=prep.psu_col,
            ssu_col=prep.ssu_col,
            fpc_col=fpc_col,
            fpc_ssu_col=fpc_ssu_col,
            by_col=prep.by_col,
            singleton_method=center_arg,
        )

        if self._should_run_double_pass():
            cache = self._get_polars_design_info()
            df_full = cache["data"]
            if y in df_full.columns and df_full[y].dtype != pl.Float64:
                df_full = df_full.with_columns(pl.col(y).cast(pl.Float64))
            result_full = rs.taylor_total(
                df_full,
                value_col=y,
                weight_col=cache["weight_col"],
                strata_col=cache["strata_col"],
                psu_col=cache["psu_col"],
                ssu_col=cache.get("ssu_col"),
                fpc_col=cache.get("fpc_col"),
                fpc_ssu_col=cache.get("fpc_ssu_col"),
                by_col=prep.by_col,
                singleton_method=center_arg,
            )
            result_df = self._apply_scale_adjustment(result_full, result_df, param=PopParam.TOTAL)

        est_list = self._polars_result_to_param_est(
            result_df, y, PopParam.TOTAL, alpha, deff, prep.by_col, as_factor=False
        )
        est_cov = np.diag(result_df["var"].to_numpy())
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.TOTAL,
            alpha,
            prep.by_cols,
            as_factor=False,
            method=EstimationMethod.TAYLOR,
            rust_df=int(result_df["df"].min()),
        )

    def _taylor_ratio_polars(
        self,
        prep: PreparedData,
        y: str,
        x: str,
        *,
        deff: bool = False,
        alpha: float = 0.05,
    ) -> Estimate:
        pop_size = getattr(self._sample._design, "pop_size", None)
        df, fpc_col, fpc_ssu_col = (
            self._compute_fpc_columns(
                prep.df, pop_size, prep.strata_col, prep.psu_col, prep.ssu_col
            )
            if pop_size is not None
            else (prep.df, None, None)
        )
        center_arg = self._get_center_method()

        result_df = rs.taylor_ratio(
            df,
            numerator_col=y,
            denominator_col=x,
            weight_col=prep.weight_col,
            strata_col=prep.strata_col,
            psu_col=prep.psu_col,
            ssu_col=prep.ssu_col,
            fpc_col=fpc_col,
            fpc_ssu_col=fpc_ssu_col,
            by_col=prep.by_col,
            singleton_method=center_arg,
        )

        if self._should_run_double_pass():
            cache = self._get_polars_design_info()
            df_full = cache["data"]
            if y in df_full.columns and df_full[y].dtype != pl.Float64:
                df_full = df_full.with_columns(pl.col(y).cast(pl.Float64))
            result_full = rs.taylor_ratio(
                df_full,
                numerator_col=y,
                denominator_col=x,
                weight_col=cache["weight_col"],
                strata_col=cache["strata_col"],
                psu_col=cache["psu_col"],
                ssu_col=cache.get("ssu_col"),
                fpc_col=cache.get("fpc_col"),
                fpc_ssu_col=cache.get("fpc_ssu_col"),
                by_col=prep.by_col,
                singleton_method=center_arg,
            )
            result_df = self._apply_scale_adjustment(result_full, result_df, param=PopParam.RATIO)

        est_list = self._polars_result_to_param_est(
            result_df, y, PopParam.RATIO, alpha, deff, prep.by_col, as_factor=False, x_name=x
        )
        est_cov = np.diag(result_df["var"].to_numpy())
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.RATIO,
            alpha,
            prep.by_cols,
            as_factor=False,
            method=EstimationMethod.TAYLOR,
            rust_df=int(result_df["df"].min()),
        )

    def _taylor_prop_polars(
        self,
        prep: PreparedData,
        y: str,
        *,
        deff: bool = False,
        alpha: float = 0.05,
        ci_method: str = "logit",
    ) -> Estimate:
        pop_size = getattr(self._sample._design, "pop_size", None)
        df, fpc_col, fpc_ssu_col = (
            self._compute_fpc_columns(
                prep.df, pop_size, prep.strata_col, prep.psu_col, prep.ssu_col
            )
            if pop_size is not None
            else (prep.df, None, None)
        )
        center_arg = self._get_center_method()

        df = self._coerce_y_for_prop(df, y)
        result_df = rs.taylor_prop(
            df,
            value_col=y,
            weight_col=prep.weight_col,
            strata_col=prep.strata_col,
            psu_col=prep.psu_col,
            ssu_col=prep.ssu_col,
            fpc_col=fpc_col,
            fpc_ssu_col=fpc_ssu_col,
            by_col=prep.by_col,
            singleton_method=center_arg,
        )

        if self._should_run_double_pass():
            cache = self._get_polars_design_info()
            df_full = cache["data"]
            result_full = rs.taylor_prop(
                df_full,
                value_col=y,
                weight_col=cache["weight_col"],
                strata_col=cache["strata_col"],
                psu_col=cache["psu_col"],
                ssu_col=cache.get("ssu_col"),
                fpc_col=cache.get("fpc_col"),
                fpc_ssu_col=cache.get("fpc_ssu_col"),
                by_col=prep.by_col,
                singleton_method=center_arg,
            )
            result_df = self._apply_scale_adjustment(result_full, result_df, param=PopParam.PROP)

        est_list = self._polars_result_to_param_est(
            result_df,
            y,
            PopParam.PROP,
            alpha,
            deff,
            prep.by_col,
            as_factor=True,
            ci_method=ci_method,
        )
        est_cov = np.diag(result_df["var"].to_numpy())
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.PROP,
            alpha,
            prep.by_cols,
            as_factor=True,
            method=EstimationMethod.TAYLOR,
            rust_df=int(result_df["df"].min()),
        )

    def _taylor_median_polars(
        self,
        prep: PreparedData,
        y: str,
        *,
        q_method: QuantileMethod = QuantileMethod.HIGHER,
        alpha: float = 0.05,
    ) -> Estimate:
        """Taylor linearization median using Rust backend."""
        if prep.df[y].null_count() > 0:
            raise ValueError(f"Missing values found in '{y}'. Use drop_nulls=True to ignore.")

        pop_size = getattr(self._sample._design, "pop_size", None)
        df, fpc_col, fpc_ssu_col = (
            self._compute_fpc_columns(
                prep.df, pop_size, prep.strata_col, prep.psu_col, prep.ssu_col
            )
            if pop_size is not None
            else (prep.df, None, None)
        )
        center_arg = self._get_center_method()
        q_method_str = q_method.value if hasattr(q_method, "value") else str(q_method).lower()

        result_df = rs.taylor_median(
            df,
            value_col=y,
            weight_col=prep.weight_col,
            strata_col=prep.strata_col,
            psu_col=prep.psu_col,
            ssu_col=prep.ssu_col,
            fpc_col=fpc_col,
            fpc_ssu_col=fpc_ssu_col,
            by_col=prep.by_col,
            singleton_method=center_arg,
            quantile_method=q_method_str,
        )

        est_list = self._median_result_to_param_est(
            result_df, y, alpha, prep.by_col, df, prep.weight_col
        )
        est_cov = np.diag(result_df["var"].to_numpy())
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.MEDIAN,
            alpha,
            prep.by_cols,
            as_factor=False,
            method=EstimationMethod.TAYLOR,
            rust_df=int(result_df["df"].min()),
        )

    def _replicate_estimate(
        self,
        prep: PreparedData,
        method,
        param,
        y,
        *,
        x=None,
        fay_coef=0.0,
        as_factor=False,
        variance_center="rep_mean",
        alpha=0.05,
        ci_method="logit",
    ):
        if method not in (
            EstimationMethod.BRR,
            EstimationMethod.BOOTSTRAP,
            EstimationMethod.JACKKNIFE,
            EstimationMethod.SDR,
        ):
            raise ValueError(f"Method {method} is not a valid replication method.")
        if param == PopParam.MEAN:
            return self._replicate_mean_polars(
                prep=prep,
                y=y,
                method=method,
                fay_coef=fay_coef,
                variance_center=variance_center,
                alpha=alpha,
            )
        elif param == PopParam.TOTAL:
            return self._replicate_total_polars(
                prep=prep,
                y=y,
                method=method,
                fay_coef=fay_coef,
                variance_center=variance_center,
                alpha=alpha,
            )
        elif param == PopParam.RATIO:
            if x is None:
                raise ValueError("x must be provided for ratio estimation.")
            return self._replicate_ratio_polars(
                prep=prep,
                y=y,
                x=x,
                method=method,
                fay_coef=fay_coef,
                variance_center=variance_center,
                alpha=alpha,
            )
        elif param == PopParam.PROP:
            return self._replicate_prop_polars(
                prep=prep,
                y=y,
                method=method,
                fay_coef=fay_coef,
                variance_center=variance_center,
                alpha=alpha,
                ci_method=ci_method,
            )
        else:
            raise ValueError(f"Unsupported parameter {param} for replication estimation.")

    def _get_rep_weight_cols(self) -> list[str]:
        rw = self._sample._design.rep_wgts
        if rw is None:
            return []
        _lraw = self._sample._data
        local_data: pl.DataFrame = (
            cast(pl.DataFrame, _lraw.collect())
            if isinstance(_lraw, pl.LazyFrame)
            else cast(pl.DataFrame, _lraw)
        )
        if rw.prefix:

            def natural_keys(text):
                return [int(c) if c.isdigit() else c for c in re.split(r"(\d+)", text)]

            return sorted(
                [c for c in local_data.columns if c.startswith(rw.prefix) and c != rw.prefix],
                key=natural_keys,
            )
        elif hasattr(rw, "wgts") and rw.wgts:
            return list(cast(list[str], rw.wgts))
        return []

    def _get_rep_method_str(self, method: EstimationMethod) -> str:
        method_map = {
            EstimationMethod.BRR: "BRR",
            EstimationMethod.BOOTSTRAP: "Bootstrap",
            EstimationMethod.JACKKNIFE: "Jackknife",
            EstimationMethod.SDR: "SDR",
        }
        return method_map.get(method, "jackknife")

    def _replicate_mean_polars(
        self,
        prep: PreparedData,
        y,
        *,
        method,
        fay_coef=0.0,
        variance_center="rep_mean",
        alpha=0.05,
    ):
        design = self._sample._design
        rw = design.rep_wgts
        if rw is None:
            raise ValueError("Replication weights required for replication-based estimation.")
        rep_weight_cols = self._get_rep_weight_cols()
        if not rep_weight_cols:
            raise ValueError("No replicate weight columns found.")
        n_reps = len(rep_weight_cols)
        df_val = int(rw.df) if rw.df and rw.df > 0 else max(1, n_reps - 1)
        final_fay = float(fay_coef) if fay_coef != 0.0 else float(rw.fay_coef)

        data = self._ensure_float64(prep.df, rep_weight_cols)
        method_str = self._get_rep_method_str(method)
        result_df = rs.replicate_mean(
            data,
            value_col=y,
            weight_col=prep.weight_col,
            rep_weight_cols=rep_weight_cols,
            method=method_str,
            fay_coef=final_fay,
            center=variance_center,
            degrees_of_freedom=df_val,
            by_col=prep.by_col,
        )
        est_list = self._polars_result_to_param_est(
            result_df, y, PopParam.MEAN, alpha, deff=False, by_col=prep.by_col, as_factor=False
        )
        variances = result_df["var"].to_numpy()
        est_cov = np.diag(variances)
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.MEAN,
            alpha,
            prep.by_cols,
            as_factor=False,
            method=method,
            rust_df=int(result_df["df"].min()),
        )

    def _replicate_total_polars(
        self,
        prep: PreparedData,
        y,
        *,
        method,
        fay_coef=0.0,
        variance_center="rep_mean",
        alpha=0.05,
    ):
        design = self._sample._design
        rw = design.rep_wgts
        if rw is None:
            raise ValueError("Replication weights required.")
        rep_weight_cols = self._get_rep_weight_cols()
        if not rep_weight_cols:
            raise ValueError("No replicate weight columns found.")
        n_reps = len(rep_weight_cols)
        df_val = int(rw.df) if rw.df and rw.df > 0 else max(1, n_reps - 1)
        final_fay = float(fay_coef) if fay_coef != 0.0 else float(rw.fay_coef)

        data = self._ensure_float64(prep.df, rep_weight_cols)
        method_str = self._get_rep_method_str(method)
        result_df = rs.replicate_total(
            data,
            value_col=y,
            weight_col=prep.weight_col,
            rep_weight_cols=rep_weight_cols,
            method=method_str,
            fay_coef=final_fay,
            center=variance_center,
            degrees_of_freedom=df_val,
            by_col=prep.by_col,
        )
        est_list = self._polars_result_to_param_est(
            result_df, y, PopParam.TOTAL, alpha, deff=False, by_col=prep.by_col, as_factor=False
        )
        variances = result_df["var"].to_numpy()
        est_cov = np.diag(variances)
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.TOTAL,
            alpha,
            prep.by_cols,
            as_factor=False,
            method=method,
            rust_df=int(result_df["df"].min()),
        )

    def _replicate_ratio_polars(
        self,
        prep: PreparedData,
        y,
        x,
        *,
        method,
        fay_coef=0.0,
        variance_center="rep_mean",
        alpha=0.05,
    ):
        design = self._sample._design
        rw = design.rep_wgts
        if rw is None:
            raise ValueError("Replication weights required.")
        rep_weight_cols = self._get_rep_weight_cols()
        if not rep_weight_cols:
            raise ValueError("No replicate weight columns found.")
        n_reps = len(rep_weight_cols)
        df_val = int(rw.df) if rw.df and rw.df > 0 else max(1, n_reps - 1)
        final_fay = float(fay_coef) if fay_coef != 0.0 else float(rw.fay_coef)

        data = self._ensure_float64(prep.df, rep_weight_cols)
        method_str = self._get_rep_method_str(method)
        result_df = rs.replicate_ratio(
            data,
            numerator_col=y,
            denominator_col=x,
            weight_col=prep.weight_col,
            rep_weight_cols=rep_weight_cols,
            method=method_str,
            fay_coef=final_fay,
            center=variance_center,
            degrees_of_freedom=df_val,
            by_col=prep.by_col,
        )
        est_list = self._polars_result_to_param_est(
            result_df,
            y,
            PopParam.RATIO,
            alpha,
            deff=False,
            by_col=prep.by_col,
            as_factor=False,
            x_name=x,
        )
        variances = result_df["var"].to_numpy()
        est_cov = np.diag(variances)
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.RATIO,
            alpha,
            prep.by_cols,
            as_factor=False,
            method=method,
            rust_df=int(result_df["df"].min()),
        )

    def _replicate_prop_polars(
        self,
        prep: PreparedData,
        y,
        *,
        method,
        fay_coef=0.0,
        variance_center="rep_mean",
        alpha=0.05,
        ci_method="logit",
    ):
        design = self._sample._design
        rw = design.rep_wgts
        if rw is None:
            raise ValueError("Replication weights required.")
        rep_weight_cols = self._get_rep_weight_cols()
        if not rep_weight_cols:
            raise ValueError("No replicate weight columns found.")
        n_reps = len(rep_weight_cols)
        df_val = int(rw.df) if rw.df and rw.df > 0 else max(1, n_reps - 1)
        final_fay = float(fay_coef) if fay_coef != 0.0 else float(rw.fay_coef)

        data = self._ensure_float64(prep.df, rep_weight_cols)
        data = self._coerce_y_for_prop(data, y)
        method_str = self._get_rep_method_str(method)
        result_df = rs.replicate_prop(
            data,
            value_col=y,
            weight_col=prep.weight_col,
            rep_weight_cols=rep_weight_cols,
            method=method_str,
            fay_coef=final_fay,
            center=variance_center,
            degrees_of_freedom=df_val,
            by_col=prep.by_col,
        )
        est_list = self._polars_result_to_param_est(
            result_df,
            y,
            PopParam.PROP,
            alpha,
            deff=False,
            by_col=prep.by_col,
            as_factor=True,
            ci_method=ci_method,
        )
        variances = result_df["var"].to_numpy()
        est_cov = np.diag(variances)
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.PROP,
            alpha,
            prep.by_cols,
            as_factor=True,
            method=method,
            rust_df=int(result_df["df"].min()),
        )

    def _replicate_median_polars(
        self,
        prep: PreparedData,
        y,
        *,
        method,
        fay_coef=0.0,
        q_method: QuantileMethod = QuantileMethod.HIGHER,
        variance_center="rep_mean",
        alpha=0.05,
    ):
        """Replication-based median estimation using Rust backend."""
        design = self._sample._design
        rw = design.rep_wgts
        if rw is None:
            raise ValueError("Replication weights required for replication-based estimation.")
        rep_weight_cols = self._get_rep_weight_cols()
        if not rep_weight_cols:
            raise ValueError("No replicate weight columns found.")
        n_reps = len(rep_weight_cols)
        df_val = int(rw.df) if rw.df and rw.df > 0 else max(1, n_reps - 1)
        final_fay = float(fay_coef) if fay_coef != 0.0 else float(rw.fay_coef)

        data = self._ensure_float64(prep.df, rep_weight_cols)
        method_str = self._get_rep_method_str(method)
        q_method_str = q_method.value if hasattr(q_method, "value") else str(q_method).lower()

        result_df = rs.replicate_median(
            data,
            value_col=y,
            weight_col=prep.weight_col,
            rep_weight_cols=rep_weight_cols,
            method=method_str,
            fay_coef=final_fay,
            center=variance_center,
            degrees_of_freedom=df_val,
            by_col=prep.by_col,
            quantile_method=q_method_str,
        )

        est_list = self._replicate_median_result_to_param_est(result_df, y, alpha, prep.by_col)
        variances = result_df["var"].to_numpy()
        est_cov = np.diag(variances)
        return self._build_estimate_result_light(
            est_list,
            est_cov,
            PopParam.MEDIAN,
            alpha,
            prep.by_cols,
            as_factor=False,
            method=method,
            rust_df=int(result_df["df"].min()),
        )
