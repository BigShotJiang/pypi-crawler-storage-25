from __future__ import annotations

import html
import random
import re
import time
import unicodedata as ud
from datetime import datetime, timezone
from urllib.parse import urljoin

from loguru import logger
from patchright.sync_api import Page as PatchrightPage, ElementHandle as PatchrightElementHandle
from playwright.sync_api import Page as PlaywrightPage, ElementHandle as PlaywrightElementHandle
from selectolax.lexbor import LexborHTMLParser, LexborNode


Page = PatchrightPage | PlaywrightPage
ElementHandle = PatchrightElementHandle | PlaywrightElementHandle


def wrap_page(page: Page) -> _WrappedPage:
    return _WrappedPage(page)

class _PageScoped:
    _page: Page

    def wrap_element(self, elem: ElementHandle | None) -> _WrappedElement:
        return _WrappedElement(self._page, elem)

    def wrap_element_group(self, elems: list[_WrappedElement]) -> _WrappedElementGroup:
        return _WrappedElementGroup(self._page, elems)


def wrap_parser(parser: LexborHTMLParser) -> _WrappedParser:
    return _WrappedParser(parser)

def wrap_node(node: LexborNode | None) -> _WrappedNode:
    return _WrappedNode(node)

def wrap_node_group(nodes: list[_WrappedNode]) -> _WrappedNodeGroup:
    return _WrappedNodeGroup(nodes)


class _WrappedPage(_PageScoped):
    def __init__(self, page: Page) -> None:
        self._page = page

    @property
    def raw(self) -> Page:
        return self._page
    
    def css_first(self, selector: str) -> _WrappedElement:
        elem = self._page.query_selector(selector)
        return self.wrap_element(elem)

    def css(self, selector: str) -> _WrappedElementGroup:
        elems = self._page.query_selector_all(selector)
        return self.wrap_element_group([self.wrap_element(e) for e in elems])

    def goto(
        self,
        url: str | None,
        try_cnt: int = 3,
        wait_range: tuple[float, float] = (3, 5),
        sleep_after: tuple[float, float] | None = (1, 2),
    ) -> bool:
        if not url:
            return False
        for i in range(try_cnt):
            try:
                if self._page.goto(url) is not None:
                    if sleep_after is not None:
                        time.sleep(random.uniform(*sleep_after))
                    return True
                else:
                    reason = "response is None"
            except Exception as e:
                reason = f"{type(e).__name__}: {e}"
            logger.warning(f"[goto] {url} ({i+1}/{try_cnt}) {reason}")
            if i + 1 < try_cnt:
                time.sleep(random.uniform(*wait_range))
        logger.error(f"[goto] giving up: {url}")
        return False

    def wait(self, selector: str, state: str = "attached", timeout: int = 15000) -> _WrappedElement:
        try:
            elem = self._page.wait_for_selector(selector, state=state, timeout=timeout)
            return self.wrap_element(elem)
        except Exception as e:
            logger.warning(f"[wait] {type(e).__name__}: {e} | selector={selector!r} | url={self._page.url}")
            return self.wrap_element(None)
    
    def html(self, with_url: bool = False, with_saved_at: bool = False) -> str:
        content = self._page.content()
        metas: list[str] = []
        if with_url:
            metas.append(f'<meta name="scwrap:url" content="{html.escape(self._page.url)}">')
        if with_saved_at:
            ts = datetime.now(timezone.utc).isoformat()
            metas.append(f'<meta name="scwrap:saved_at" content="{ts}">')
        return ''.join(metas) + content


class _WrappedElement(_PageScoped):
    def __init__(self, page: Page, elem: ElementHandle | None) -> None:
        self._page = page
        self._elem = elem

    @property
    def raw(self) -> ElementHandle | None:
        return self._elem
    
    def css_first(self, selector: str) -> _WrappedElement:
        elem = self._elem.query_selector(selector) if self._elem else None
        return self.wrap_element(elem)
    
    def css(self, selector: str) -> _WrappedElementGroup:
        elems = self._elem.query_selector_all(selector) if self._elem else []
        return self.wrap_element_group([self.wrap_element(e) for e in elems])

    def next(self, selector: str) -> _WrappedElement:
        if self._elem is None:
            return self.wrap_element(None)
        try:
            elem = self._elem.evaluate_handle(
                """(el, sel) => {
                    let cur = el.nextElementSibling;
                    while (cur) {
                        if (cur.matches(sel)) return cur;
                        cur = cur.nextElementSibling;
                    }
                    return null;
                }""",
                selector,
            ).as_element()
            return self.wrap_element(elem)
        except Exception as e:
            logger.error(f"[next] {self._elem} {type(e).__name__}: {e}")
            return self.wrap_element(None)

    @property
    def text(self) -> str | None:
        if self._elem is None:
            return None
        return text if (text := self._elem.text_content()) else None

    def attr(self, attr_name: str) -> str | None:
        if self._elem is None:
            return None
        return attr if (attr := self._elem.get_attribute(attr_name)) else None

    @property
    def url(self) -> str | None:
        if self._elem is None:
            return None
        if not (href := self._elem.get_attribute('href')):
            return None
        if not (h := href.strip()):
            return None
        if re.search(r'(?i)^(?:#|javascript:|mailto:|tel:|data:)', h):
            return None
        return urljoin(self._page.url, h)

class _WrappedElementGroup(_PageScoped):
    def __init__(self, page: Page, elems: list[_WrappedElement]) -> None:
        self._page = page
        self._elems = elems

    @property
    def raw(self) -> list[_WrappedElement]:
        return self._elems

    @property
    def one(self) -> _WrappedElement:
        return self._elems[0] if self._elems else self.wrap_element(None)

    def grep(self, pattern: str) -> _WrappedElementGroup:
        prog = re.compile(pattern)
        filtered = [
            e for e in self._elems
            if (t := e.text) and prog.search(ud.normalize('NFKC', t))
        ]
        return self.wrap_element_group(filtered)

    def grep_first(self, pattern: str) -> _WrappedElement:
        prog = re.compile(pattern)
        for e in self._elems:
            if (t := e.text) and prog.search(ud.normalize('NFKC', t)):
                return e
        return self.wrap_element(None)

    def indexed(self) -> _ElementTextIndex:
        pairs: list[tuple[str, _WrappedElement]] = []
        for e in self._elems:
            if (t := e.text):
                pairs.append((ud.normalize('NFKC', t), e))
        return _ElementTextIndex(self._page, pairs)

    @property
    def texts(self) -> list[str | None]:
        return [e.text for e in self._elems]

    def attrs(self, attr_name: str) -> list[str | None]:
        return [e.attr(attr_name) for e in self._elems]

    @property
    def urls(self) -> list[str | None]:
        return [e.url for e in self._elems]


class _WrappedParser:
    def __init__(self, parser: LexborHTMLParser) -> None:
        self._parser = parser

    @property
    def raw(self) -> LexborHTMLParser:
        return self._parser
    
    def css_first(self, selector: str) -> _WrappedNode:
        node = self._parser.css_first(selector)
        return wrap_node(node)

    def css(self, selector: str) -> _WrappedNodeGroup:
        nodes = self._parser.css(selector)
        return wrap_node_group([wrap_node(n) for n in nodes])

    @property
    def url(self) -> str | None:
        node = self._parser.css_first('meta[name="scwrap:url"]')
        if node is None:
            return None
        return node.attributes.get('content') or None

    @property
    def saved_at(self) -> str | None:
        node = self._parser.css_first('meta[name="scwrap:saved_at"]')
        if node is None:
            return None
        return node.attributes.get('content') or None

class _WrappedNode:
    def __init__(self, node: LexborNode | None) -> None:
        self._node = node

    @property
    def raw(self) -> LexborNode | None:
        return self._node
    
    def css_first(self, selector: str) -> _WrappedNode:
        node = self._node.css_first(selector) if self._node else None
        return wrap_node(node)

    def css(self, selector: str) -> _WrappedNodeGroup:
        nodes = self._node.css(selector) if self._node else []
        return wrap_node_group([wrap_node(n) for n in nodes])

    def next(self, selector: str) -> _WrappedNode:
        if self._node is None:
            return wrap_node(None)
        cur = self._node.next
        while cur is not None:
            if cur.is_element_node and cur.css_matches(selector):
                return wrap_node(cur)
            cur = cur.next
        return wrap_node(None)

    @property
    def text(self) -> str | None:
        if self._node is None:
            return None
        return text if (text := self._node.text()) else None

    def attr(self, attr_name: str) -> str | None:
        if self._node is None:
            return None
        return attr if (attr := self._node.attributes.get(attr_name)) else None

class _WrappedNodeGroup:
    def __init__(self, nodes: list[_WrappedNode]) -> None:
        self._nodes = nodes
    
    @property
    def raw(self) -> list[_WrappedNode]:
        return self._nodes

    @property
    def one(self) -> _WrappedNode:
        return self._nodes[0] if self._nodes else wrap_node(None)

    def grep(self, pattern: str) -> _WrappedNodeGroup:
        prog = re.compile(pattern)
        filtered = [
            n for n in self._nodes
            if (t := n.text) and prog.search(ud.normalize('NFKC', t))
        ]
        return wrap_node_group(filtered)

    def grep_first(self, pattern: str) -> _WrappedNode:
        prog = re.compile(pattern)
        for n in self._nodes:
            if (t := n.text) and prog.search(ud.normalize('NFKC', t)):
                return n
        return wrap_node(None)

    def indexed(self) -> _NodeTextIndex:
        pairs: list[tuple[str, _WrappedNode]] = []
        for n in self._nodes:
            if (t := n.text):
                pairs.append((ud.normalize('NFKC', t), n))
        return _NodeTextIndex(pairs)

    @property
    def texts(self) -> list[str | None]:
        return [n.text for n in self._nodes]

    def attrs(self, attr_name: str) -> list[str | None]:
        return [n.attr(attr_name) for n in self._nodes]


class _ElementTextIndex:
    def __init__(self, page: Page, pairs: list[tuple[str, _WrappedElement]]) -> None:
        self._page = page
        self._pairs = pairs

    def grep(self, pattern: str) -> _WrappedElementGroup:
        prog = re.compile(pattern)
        filtered = [e for text, e in self._pairs if prog.search(text)]
        return _WrappedElementGroup(self._page, filtered)

    def grep_first(self, pattern: str) -> _WrappedElement:
        prog = re.compile(pattern)
        for text, e in self._pairs:
            if prog.search(text):
                return e
        return _WrappedElement(self._page, None)


class _NodeTextIndex:
    def __init__(self, pairs: list[tuple[str, _WrappedNode]]) -> None:
        self._pairs = pairs

    def grep(self, pattern: str) -> _WrappedNodeGroup:
        prog = re.compile(pattern)
        filtered = [n for text, n in self._pairs if prog.search(text)]
        return wrap_node_group(filtered)

    def grep_first(self, pattern: str) -> _WrappedNode:
        prog = re.compile(pattern)
        for text, n in self._pairs:
            if prog.search(text):
                return n
        return wrap_node(None)
