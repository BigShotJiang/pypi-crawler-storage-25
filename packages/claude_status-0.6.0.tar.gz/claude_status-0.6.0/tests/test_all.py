"""Comprehensive tests for claude-status — stdlib unittest only."""

import json
import os
import platform
import re
import subprocess
import sys
import tempfile
import time
import unittest

# Force the responsive layout to pick the FULL layout by default in tests.
# shutil.get_terminal_size() honors COLUMNS/LINES before falling back, so
# setting these before importing claude_statusline.cli ensures render()
# exercises the full layout regardless of the host terminal width.
# Unconditional assignment (not setdefault) so a hostile CI value exported
# upstream can't silently shrink the layout and make tests pass for the
# wrong reason. Individual tests that want narrow/compact layouts set
# COLUMNS explicitly themselves and restore it in a finally block.
os.environ["COLUMNS"] = "250"
os.environ["LINES"] = "50"

# Add parent to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from claude_statusline import __version__
from claude_statusline.colors import (
    BOLD, BRIGHT_BLACK, BRIGHT_RED, CYAN, GREEN, RED, RESET, WHITE, YELLOW,
    colorize,
)
from claude_statusline.formatters import (
    fmt_burn_rate, fmt_cache_pct, fmt_cost, fmt_duration, fmt_lines, fmt_tokens,
)
from claude_statusline.bar import render_bar
from claude_statusline.git import get_branch
from claude_statusline.themes import THEMES, get_theme
from claude_statusline.cli import render, _render_sections, _settings_path


# ─── colors.py ────────────────────────────────────────────────────────

class TestColors(unittest.TestCase):
    def test_all_constants_are_nonempty_strings(self):
        from claude_statusline import colors
        for name in dir(colors):
            if name.isupper() and not name.startswith("_"):
                val = getattr(colors, name)
                self.assertIsInstance(val, str, "{} should be a string".format(name))
                self.assertTrue(len(val) > 0, "{} should be non-empty".format(name))

    def test_color_codes_follow_ansi_pattern(self):
        from claude_statusline import colors
        pattern = re.compile(r"^\033\[\d+m$")
        for name in dir(colors):
            if name.isupper() and not name.startswith("_"):
                val = getattr(colors, name)
                self.assertTrue(
                    pattern.match(val),
                    "{} = {!r} doesn't match ANSI pattern".format(name, val),
                )

    def test_colorize_wraps_text(self):
        result = colorize("hello", GREEN)
        self.assertIn("hello", result)
        self.assertTrue(result.startswith(GREEN))
        self.assertTrue(result.endswith(RESET))

    def test_colorize_multiple_codes(self):
        result = colorize("x", BOLD, RED)
        self.assertTrue(result.startswith(BOLD + RED))

    def test_colorize_empty_string(self):
        self.assertEqual(colorize("", GREEN), "")

    def test_colorize_none(self):
        self.assertEqual(colorize(None, GREEN), "")


# ─── formatters.py ────────────────────────────────────────────────────

class TestFmtTokens(unittest.TestCase):
    def test_zero(self):
        self.assertEqual(fmt_tokens(0), "0")

    def test_small(self):
        self.assertEqual(fmt_tokens(999), "999")

    def test_one_k(self):
        self.assertEqual(fmt_tokens(1000), "1K")

    def test_1500(self):
        self.assertEqual(fmt_tokens(1500), "1.5K")

    def test_10k(self):
        self.assertEqual(fmt_tokens(10_000), "10K")

    def test_245k(self):
        self.assertEqual(fmt_tokens(245_000), "245K")

    def test_1_5m(self):
        self.assertEqual(fmt_tokens(1_500_000), "1.5M")

    def test_10m(self):
        self.assertEqual(fmt_tokens(10_000_000), "10M")

    def test_999m(self):
        self.assertEqual(fmt_tokens(999_000_000), "999M")

    def test_none(self):
        self.assertEqual(fmt_tokens(None), "?")


class TestFmtCost(unittest.TestCase):
    def test_sub_cent(self):
        result = fmt_cost(0.005)
        self.assertIn("0.5", result)
        self.assertIn("c", result)

    def test_cents(self):
        self.assertEqual(fmt_cost(0.50), "$0.50")

    def test_dollars(self):
        self.assertEqual(fmt_cost(1.5), "$1.5")

    def test_large(self):
        self.assertEqual(fmt_cost(12.3), "$12")

    def test_none(self):
        self.assertEqual(fmt_cost(None), "?")

    def test_zero(self):
        result = fmt_cost(0)
        self.assertIn("c", result)


class TestFmtDuration(unittest.TestCase):
    def test_zero(self):
        self.assertEqual(fmt_duration(0), "0s")

    def test_seconds(self):
        self.assertEqual(fmt_duration(45_000), "45s")

    def test_minutes(self):
        self.assertEqual(fmt_duration(125_000), "2m05s")

    def test_hours(self):
        self.assertEqual(fmt_duration(3_700_000), "1h01m")

    def test_none(self):
        self.assertEqual(fmt_duration(None), "?")


class TestFmtBurnRate(unittest.TestCase):
    def test_normal(self):
        # 60000 tokens in 60000ms = 1 min → 60K/min
        result = fmt_burn_rate(60_000, 60_000)
        self.assertIn("/min", result)

    def test_none_tokens(self):
        self.assertEqual(fmt_burn_rate(None, 1000), "?")

    def test_none_duration(self):
        self.assertEqual(fmt_burn_rate(1000, None), "?")

    def test_zero_duration(self):
        self.assertEqual(fmt_burn_rate(1000, 0), "?")


class TestFmtLines(unittest.TestCase):
    def test_both(self):
        self.assertEqual(fmt_lines(10, 5), "+10 -5")

    def test_added_only(self):
        self.assertEqual(fmt_lines(10, 0), "+10")

    def test_removed_only(self):
        self.assertEqual(fmt_lines(0, 5), "-5")

    def test_neither(self):
        self.assertEqual(fmt_lines(0, 0), "")

    def test_none(self):
        self.assertEqual(fmt_lines(None, None), "")


class TestFmtCachePct(unittest.TestCase):
    def test_normal(self):
        self.assertEqual(fmt_cache_pct(80, 100), "80%")

    def test_zero_total(self):
        self.assertEqual(fmt_cache_pct(80, 0), "")

    def test_none(self):
        self.assertEqual(fmt_cache_pct(None, 100), "")


# ─── bar.py ───────────────────────────────────────────────────────────

class TestRenderBar(unittest.TestCase):
    def test_zero(self):
        bar = render_bar(0, 20)
        self.assertIn("[", bar)
        self.assertIn("]", bar)

    def test_full(self):
        bar = render_bar(100, 20)
        self.assertIn("[", bar)

    def test_half(self):
        bar = render_bar(50, 20)
        self.assertIn("[", bar)

    def test_none(self):
        self.assertEqual(render_bar(None, 20), "")

    def test_over_100(self):
        bar = render_bar(150, 20)
        self.assertIn("[", bar)

    def test_negative(self):
        bar = render_bar(-10, 20)
        self.assertIn("[", bar)

    def test_custom_theme(self):
        theme = {
            "bar_filled": "#",
            "bar_empty": ".",
            "bar_left": "<",
            "bar_right": ">",
        }
        bar = render_bar(50, 10, theme)
        self.assertIn("<", bar)
        self.assertIn(">", bar)


# ─── git.py ───────────────────────────────────────────────────────────

class TestGitBranch(unittest.TestCase):
    def test_returns_string(self):
        result = get_branch()
        self.assertIsInstance(result, str)

    def test_in_git_repo(self):
        # We're running from within the repo, so should get a branch
        # (unless running from a non-git temp dir)
        result = get_branch()
        # Just check it doesn't crash — result may be empty if not in git
        self.assertIsInstance(result, str)

    def test_cache_isolation_per_directory(self):
        """Different working directories should use different cache files."""
        from claude_statusline.git import _cache_file
        original_cwd = os.getcwd()
        try:
            with tempfile.TemporaryDirectory() as dir_a:
                os.chdir(dir_a)
                cache_a = _cache_file()
                os.chdir(original_cwd)  # leave before cleanup (Windows)
            with tempfile.TemporaryDirectory() as dir_b:
                os.chdir(dir_b)
                cache_b = _cache_file()
                os.chdir(original_cwd)  # leave before cleanup (Windows)
            self.assertNotEqual(cache_a, cache_b)
        finally:
            os.chdir(original_cwd)


# ─── themes.py ────────────────────────────────────────────────────────

class TestThemes(unittest.TestCase):
    def test_all_builtin_themes_exist(self):
        for name in ("default", "minimal", "powerline", "nord",
                     "tokyo-night", "gruvbox", "rose-pine", "focus"):
            self.assertIn(name, THEMES, "Missing theme: {}".format(name))

    def test_required_keys(self):
        required = ["name", "separator", "bar_filled", "bar_empty",
                     "line1", "line2", "colors"]
        for name, theme in THEMES.items():
            for key in required:
                self.assertIn(key, theme, "{} missing key: {}".format(name, key))

    def test_theme_names_match(self):
        for name, theme in THEMES.items():
            self.assertEqual(theme["name"], name)

    def test_get_theme_default(self):
        t = get_theme("default")
        self.assertEqual(t["name"], "default")

    def test_get_theme_unknown_falls_back(self):
        t = get_theme("nonexistent")
        self.assertEqual(t["name"], "default")

    def test_color_keys(self):
        required_colors = ["separator", "label", "value", "cost",
                           "branch_main", "branch_feature", "warning",
                           "added", "removed", "agent", "vim_normal", "vim_insert",
                           "model", "latency"]
        for name, theme in THEMES.items():
            for key in required_colors:
                self.assertIn(key, theme["colors"],
                              "{} theme missing color: {}".format(name, key))

    def test_all_themes_have_effort_xhigh(self):
        """All built-in themes must include the effort_xhigh color key
        added in v0.5.6 for Opus 4.7 support. Custom user themes can
        omit it (the renderer falls back to effort_high), but built-ins
        should all opt in so themes look consistent out of the box."""
        for name, theme in THEMES.items():
            self.assertIn("effort_xhigh", theme["colors"],
                "{} theme missing effort_xhigh color key".format(name))

    def test_all_themes_have_effort_max(self):
        """Same contract as effort_xhigh: built-in themes ship the key
        for the top-tier effort level so users on Opus 4.7 max see a
        themed indicator out of the box."""
        for name, theme in THEMES.items():
            self.assertIn("effort_max", theme["colors"],
                "{} theme missing effort_max color key".format(name))


# ─── cli.py ───────────────────────────────────────────────────────────

class TestRender(unittest.TestCase):
    def _full_data(self):
        """Sample data using the real Claude Code nested schema."""
        return {
            "context_window": {
                "used_percentage": 42,
                "context_window_size": 200_000,
                "current_usage": {
                    "input_tokens": 245_000,
                    "output_tokens": 18_500,
                    "cache_read_input_tokens": 180_000,
                    "cache_creation_input_tokens": 5_000,
                },
            },
            "cost": {
                "total_cost_usd": 0.73,
                "total_duration_ms": 725_000,
                "total_lines_added": 247,
                "total_lines_removed": 38,
            },
            "exceeds_200k_tokens": False,
            "git_branch": "feat/statusline",
        }

    def test_full_data(self):
        result = render(self._full_data())
        self.assertIsInstance(result, str)
        self.assertTrue(len(result) > 0)

    def test_two_line_output(self):
        """Full data should produce two lines."""
        result = render(self._full_data())
        lines = result.split("\n")
        self.assertEqual(len(lines), 2, "Expected 2 lines, got {}".format(len(lines)))

    def test_empty_data(self):
        result = render({})
        # May be empty string — should not crash
        self.assertIsInstance(result, str)

    def test_partial_data(self):
        result = render({"cost_usd": 0.5})
        self.assertIsInstance(result, str)

    def test_null_usage(self):
        result = render({"context_window": None})
        self.assertIsInstance(result, str)

    def test_exceeds_200k_no_warning_if_below_85pct(self):
        """exceeds_200k_tokens alone should NOT trigger !CTX warning.

        The percentage-based check is the only warning trigger now.
        On 1M context windows, exceeding 200K tokens is only ~20% usage.
        """
        data = self._full_data()
        data["exceeds_200k_tokens"] = True
        data["context_window"]["used_percentage"] = 42  # well below 85%
        result = render(data)
        self.assertNotIn("!CTX", result)

    def test_ctx_warning_at_85_percent(self):
        """Warning should trigger at 85%+ usage regardless of context size."""
        data = self._full_data()
        data["exceeds_200k_tokens"] = False
        data["context_window"]["used_percentage"] = 85
        data["context_window"]["context_window_size"] = 1_000_000
        result = render(data)
        self.assertIn("!CTX", result)

    def test_ctx_warning_not_at_84_percent(self):
        """Warning should NOT trigger below 85% usage."""
        data = self._full_data()
        data["exceeds_200k_tokens"] = False
        data["context_window"]["used_percentage"] = 84
        result = render(data)
        self.assertNotIn("!CTX", result)

    def test_ctx_warning_1m_context_low_usage(self):
        """1M context at 20% usage should NOT show warning."""
        data = self._full_data()
        data["exceeds_200k_tokens"] = False
        data["context_window"]["used_percentage"] = 20
        data["context_window"]["context_window_size"] = 1_000_000
        result = render(data)
        self.assertNotIn("!CTX", result)

    def test_ctx_warning_1m_exceeds_200k_low_pct(self):
        """1M context exceeding 200K tokens but at 25% should NOT warn."""
        data = self._full_data()
        data["exceeds_200k_tokens"] = True
        data["context_window"]["used_percentage"] = 25
        data["context_window"]["context_window_size"] = 1_000_000
        result = render(data)
        self.assertNotIn("!CTX", result)

    def test_ctx_warning_no_pct_with_exceeds_200k(self):
        """Missing used_percentage + exceeds_200k should NOT warn."""
        data = self._full_data()
        data["exceeds_200k_tokens"] = True
        del data["context_window"]["used_percentage"]
        result = render(data)
        self.assertNotIn("!CTX", result)

    def test_vim_mode(self):
        data = self._full_data()
        data["vim"] = {"mode": "NORMAL"}
        result = render(data)
        self.assertIn("NORMAL", result)

    def test_agent_name(self):
        data = self._full_data()
        data["agent"] = {"name": "Explore"}
        result = render(data)
        self.assertIn("Explore", result)

    def test_worktree(self):
        data = self._full_data()
        data["worktree"] = {"branch": "fix/bug-123", "name": "fix"}
        result = render(data)
        self.assertIn("fix/bug-123", result)

    def test_project_name_in_branch(self):
        """Branch should show project/branch when cwd is available."""
        data = self._full_data()
        data["cwd"] = "/home/user/projects/myapp"
        result = render(data)
        self.assertIn("myapp", result)

    def test_project_name_with_workspace(self):
        """Workspace.current_dir should also provide project name."""
        data = self._full_data()
        data["workspace"] = {"current_dir": "/home/user/projects/my-app"}
        result = render(data)
        self.assertIn("my-app", result)

    def test_no_project_name(self):
        """Missing cwd should still show branch without project."""
        data = self._full_data()
        # Remove any cwd — git_branch is set in _full_data
        result = render(data)
        self.assertIn("feat/statusline", result)

    def test_all_optional_fields(self):
        data = self._full_data()
        data["vim"] = {"mode": "INSERT"}
        data["agent"] = {"name": "Plan"}
        data["worktree"] = {"branch": "wt-branch", "name": "wt"}
        result = render(data)
        self.assertIn("INSERT", result)
        self.assertIn("Plan", result)
        self.assertIn("wt-branch", result)

    def test_minimal_theme(self):
        result = render(self._full_data(), "minimal")
        self.assertIsInstance(result, str)

    def test_powerline_theme(self):
        result = render(self._full_data(), "powerline")
        self.assertIsInstance(result, str)

    def test_zero_cost_duration_lines(self):
        data = {
            "context_window": {"used_percentage": 0},
            "cost": {"total_cost_usd": 0, "total_duration_ms": 0,
                     "total_lines_added": 0, "total_lines_removed": 0},
        }
        result = render(data)
        self.assertIsInstance(result, str)

    def test_model_name_displayed(self):
        """Model display_name should appear when present."""
        data = self._full_data()
        data["model"] = {"id": "claude-opus-4-6", "display_name": "Opus"}
        result = render(data)
        self.assertIn("Opus", result)

    def test_model_name_absent(self):
        """Missing model should not crash or show anything."""
        data = self._full_data()
        result = render(data)
        self.assertNotIn("Opus", result)
        self.assertNotIn("Sonnet", result)

    def test_zero_values_not_dropped(self):
        """Zero values should be preserved, not treated as None."""
        data = {
            "context_window": {
                "used_percentage": 0,
                "context_window_size": 200_000,
                "current_usage": {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cache_read_input_tokens": 0,
                    "cache_creation_input_tokens": 0,
                },
            },
            "cost": {
                "total_cost_usd": 0,
                "total_duration_ms": 0,
                "total_lines_added": 0,
                "total_lines_removed": 0,
            },
            "git_branch": "main",
        }
        result = render(data)
        self.assertIsInstance(result, str)
        # Cost of 0 should render as "0c" not disappear
        self.assertIn("0c", result)

    def test_real_schema_full(self):
        """Test with a complete real Claude Code JSON payload."""
        data = {
            "cwd": "/tmp",
            "session_id": "abc123",
            "model": {"id": "claude-opus-4-6", "display_name": "Opus"},
            "context_window": {
                "total_input_tokens": 15234,
                "total_output_tokens": 4521,
                "context_window_size": 200000,
                "used_percentage": 8,
                "remaining_percentage": 92,
                "current_usage": {
                    "input_tokens": 8500,
                    "output_tokens": 1200,
                    "cache_creation_input_tokens": 5000,
                    "cache_read_input_tokens": 2000,
                },
            },
            "cost": {
                "total_cost_usd": 0.01234,
                "total_duration_ms": 45000,
                "total_api_duration_ms": 2300,
                "total_lines_added": 156,
                "total_lines_removed": 23,
            },
            "exceeds_200k_tokens": False,
            "vim": {"mode": "NORMAL"},
            "agent": {"name": "security-reviewer"},
        }
        result = render(data)
        self.assertIn("8.5K", result)  # input tokens
        self.assertIn("1.2K", result)  # output tokens
        self.assertIn("NORMAL", result)
        self.assertIn("security-reviewer", result)


class TestCLIInstall(unittest.TestCase):
    def test_install_writes_settings(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            # Monkey-patch the settings path
            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file

            try:
                cli_mod.cmd_install("default")
                with open(settings_file, "r") as f:
                    settings = json.load(f)
                sl = settings["statusLine"]
                self.assertEqual(sl["type"], "command")
                self.assertEqual(sl["command"], "claude-status")
            finally:
                cli_mod._settings_path = orig

    def test_install_with_theme(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file

            try:
                cli_mod.cmd_install("powerline")
                with open(settings_file, "r") as f:
                    settings = json.load(f)
                sl = settings["statusLine"]
                self.assertEqual(sl["type"], "command")
                self.assertIn("--theme powerline", sl["command"])
            finally:
                cli_mod._settings_path = orig

    def test_install_creates_backup(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            original = {"existingKey": "preserve_me", "other": 42}
            with open(settings_file, "w") as f:
                json.dump(original, f)

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file

            try:
                cli_mod.cmd_install("default")
                backup_file = settings_file + ".bak"
                self.assertTrue(os.path.exists(backup_file))
                with open(backup_file, "r") as f:
                    backup_content = json.load(f)
                self.assertEqual(backup_content, original)
            finally:
                cli_mod._settings_path = orig

    def test_install_no_backup_when_no_existing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file

            try:
                cli_mod.cmd_install("default")
                backup_file = settings_file + ".bak"
                self.assertFalse(os.path.exists(backup_file))
            finally:
                cli_mod._settings_path = orig

    def test_install_preserves_existing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            # Write existing settings
            with open(settings_file, "w") as f:
                json.dump({"existingKey": "value"}, f)

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file

            try:
                cli_mod.cmd_install("default")
                with open(settings_file, "r") as f:
                    settings = json.load(f)
                self.assertEqual(settings["existingKey"], "value")
                self.assertEqual(settings["statusLine"]["type"], "command")
            finally:
                cli_mod._settings_path = orig


class TestCLISubprocess(unittest.TestCase):
    """Test CLI via subprocess to verify entry point and stdin handling."""

    _env = None

    @classmethod
    def setUpClass(cls):
        # Force UTF-8 for subprocess stdout on Windows (avoids cp1252 issues)
        cls._env = os.environ.copy()
        cls._env["PYTHONIOENCODING"] = "utf-8"

    def _run(self, args, **kwargs):
        return subprocess.run(
            [sys.executable, "-m", "claude_statusline"] + args,
            capture_output=True, timeout=10,
            env=self._env, encoding="utf-8", errors="replace", **kwargs,
        )

    def test_version(self):
        result = self._run(["--version"])
        self.assertEqual(result.returncode, 0)
        self.assertIn(__version__, result.stdout)

    def test_demo(self):
        result = self._run(["--demo"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("default:", result.stdout)
        self.assertIn("minimal:", result.stdout)
        self.assertIn("powerline:", result.stdout)

    def test_json_stdin(self):
        data = json.dumps({
            "current_usage": {"used_percentage": 50, "input_tokens": 1000, "output_tokens": 500},
            "cost_usd": 0.05,
        })
        result = self._run([], input=data)
        self.assertEqual(result.returncode, 0)
        self.assertTrue(len(result.stdout.strip()) > 0)

    def test_empty_stdin(self):
        result = self._run([], input="")
        self.assertEqual(result.returncode, 0)

    def test_malformed_stdin(self):
        result = self._run([], input="not json at all {{{")
        self.assertEqual(result.returncode, 0)
        self.assertIn("?", result.stdout)

    def test_empty_json_object(self):
        result = self._run([], input="{}")
        self.assertEqual(result.returncode, 0)

    def test_doctor(self):
        result = self._run(["--doctor"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("Python:", result.stdout)
        self.assertIn("OS:", result.stdout)


# ─── Issue #6: API latency ────────────────────────────────────────────

class TestAPILatency(unittest.TestCase):
    def _data_with_latency(self, api_ms):
        return {
            "context_window": {
                "used_percentage": 30,
                "current_usage": {"input_tokens": 5000, "output_tokens": 1000},
            },
            "cost": {
                "total_cost_usd": 0.10,
                "total_duration_ms": 60_000,
                "total_api_duration_ms": api_ms,
            },
            "git_branch": "main",
        }

    def test_latency_displayed(self):
        result = render(self._data_with_latency(45_000))
        self.assertIn("api:", result)
        self.assertIn("45s", result)

    def test_latency_minutes(self):
        result = render(self._data_with_latency(125_000))
        self.assertIn("api:", result)
        self.assertIn("2m05s", result)

    def test_latency_absent(self):
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.10, "total_duration_ms": 60_000},
        }
        result = render(data)
        self.assertNotIn("api:", result)


# ─── Issue #7: workspace.project_dir ──────────────────────────────────

class TestProjectDir(unittest.TestCase):
    def test_project_dir_preferred(self):
        """workspace.project_dir should take priority over current_dir."""
        data = {
            "context_window": {"used_percentage": 10,
                               "current_usage": {"input_tokens": 100}},
            "workspace": {
                "project_dir": "/home/user/projects/my-project",
                "current_dir": "/home/user/projects/my-project/src/deep/nested",
            },
            "git_branch": "main",
        }
        result = render(data)
        self.assertIn("my-project", result)
        self.assertNotIn("nested", result)

    def test_falls_back_to_current_dir(self):
        """Without project_dir, should use current_dir basename."""
        data = {
            "context_window": {"used_percentage": 10,
                               "current_usage": {"input_tokens": 100}},
            "workspace": {"current_dir": "/home/user/projects/fallback-app"},
            "git_branch": "main",
        }
        result = render(data)
        self.assertIn("fallback-app", result)

    def test_falls_back_to_cwd(self):
        """Without workspace at all, should use top-level cwd."""
        data = {
            "context_window": {"used_percentage": 10,
                               "current_usage": {"input_tokens": 100}},
            "cwd": "/home/user/projects/legacy-app",
            "git_branch": "main",
        }
        result = render(data)
        self.assertIn("legacy-app", result)


# ─── Issue #8: Custom themes ─────────────────────────────────────────

class TestCustomThemes(unittest.TestCase):
    def test_custom_theme_loads(self):
        """Custom theme JSON should be loadable."""
        import claude_statusline.themes as themes_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            theme_file = os.path.join(tmpdir, "claude-status-theme.json")
            theme_json = {
                "base": "minimal",
                "separator": " | ",
                "colors": {
                    "cost": "green",
                    "branch_main": "bright_cyan",
                },
            }
            with open(theme_file, "w") as f:
                json.dump(theme_json, f)

            orig = themes_mod._custom_theme_path
            themes_mod._custom_theme_path = lambda: theme_file

            try:
                theme = themes_mod.load_custom_theme()
                self.assertIsNotNone(theme)
                self.assertEqual(theme["name"], "custom")
                self.assertEqual(theme["separator"], " | ")
                # Color should be resolved from string to ANSI code
                from claude_statusline.colors import GREEN, BRIGHT_CYAN
                self.assertEqual(theme["colors"]["cost"], GREEN)
                self.assertEqual(theme["colors"]["branch_main"], BRIGHT_CYAN)
            finally:
                themes_mod._custom_theme_path = orig

    def test_custom_theme_missing_file(self):
        """Missing file should return None gracefully."""
        import claude_statusline.themes as themes_mod

        orig = themes_mod._custom_theme_path
        themes_mod._custom_theme_path = lambda: "/nonexistent/path.json"
        try:
            result = themes_mod.load_custom_theme()
            self.assertIsNone(result)
        finally:
            themes_mod._custom_theme_path = orig

    def test_custom_theme_invalid_json(self):
        """Invalid JSON should return None gracefully."""
        import claude_statusline.themes as themes_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            theme_file = os.path.join(tmpdir, "bad.json")
            with open(theme_file, "w") as f:
                f.write("not valid json {{{")

            orig = themes_mod._custom_theme_path
            themes_mod._custom_theme_path = lambda: theme_file
            try:
                result = themes_mod.load_custom_theme()
                self.assertIsNone(result)
            finally:
                themes_mod._custom_theme_path = orig

    def test_custom_theme_overrides_lines(self):
        """Custom theme can override line1/line2 layout."""
        import claude_statusline.themes as themes_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            theme_file = os.path.join(tmpdir, "theme.json")
            theme_json = {
                "line1": ["bar", "cost"],
                "line2": ["branch"],
            }
            with open(theme_file, "w") as f:
                json.dump(theme_json, f)

            orig = themes_mod._custom_theme_path
            themes_mod._custom_theme_path = lambda: theme_file
            try:
                theme = themes_mod.load_custom_theme()
                self.assertEqual(theme["line1"], ["bar", "cost"])
                self.assertEqual(theme["line2"], ["branch"])
            finally:
                themes_mod._custom_theme_path = orig

    def test_get_theme_custom(self):
        """get_theme('custom') should load from file."""
        import claude_statusline.themes as themes_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            theme_file = os.path.join(tmpdir, "theme.json")
            with open(theme_file, "w") as f:
                json.dump({"separator": " ~ "}, f)

            orig = themes_mod._custom_theme_path
            themes_mod._custom_theme_path = lambda: theme_file
            try:
                theme = get_theme("custom")
                self.assertEqual(theme["name"], "custom")
                self.assertEqual(theme["separator"], " ~ ")
            finally:
                themes_mod._custom_theme_path = orig

    def test_get_theme_custom_fallback(self):
        """get_theme('custom') without file falls back to default."""
        import claude_statusline.themes as themes_mod

        orig = themes_mod._custom_theme_path
        themes_mod._custom_theme_path = lambda: "/nonexistent/path.json"
        try:
            theme = get_theme("custom")
            self.assertEqual(theme["name"], "default")
        finally:
            themes_mod._custom_theme_path = orig


# ─── themes.py — new themes ─────────────────────────────────────────

class TestNewThemes(unittest.TestCase):
    def test_all_seven_themes_exist(self):
        """All 7 built-in themes should be registered."""
        for name in ("default", "minimal", "powerline",
                     "nord", "tokyo-night", "gruvbox", "rose-pine"):
            self.assertIn(name, THEMES, "Missing theme: {}".format(name))

    def test_new_theme_names_match(self):
        for name in ("nord", "tokyo-night", "gruvbox", "rose-pine"):
            self.assertEqual(THEMES[name]["name"], name)

    def test_new_themes_have_required_keys(self):
        required = ["name", "separator", "bar_filled", "bar_empty",
                     "line1", "line2", "colors"]
        for name in ("nord", "tokyo-night", "gruvbox", "rose-pine"):
            for key in required:
                self.assertIn(key, THEMES[name],
                              "{} missing key: {}".format(name, key))

    def test_new_themes_have_required_colors(self):
        required_colors = ["separator", "label", "value", "cost",
                           "branch_main", "branch_feature", "warning",
                           "added", "removed", "agent", "vim_normal", "vim_insert",
                           "model", "latency", "sessions"]
        for name in ("nord", "tokyo-night", "gruvbox", "rose-pine"):
            for key in required_colors:
                self.assertIn(key, THEMES[name]["colors"],
                              "{} theme missing color: {}".format(name, key))

    def test_new_themes_render(self):
        """All new themes should produce output without crashing."""
        data = {
            "context_window": {
                "used_percentage": 42,
                "context_window_size": 200_000,
                "current_usage": {
                    "input_tokens": 245_000,
                    "output_tokens": 18_500,
                    "cache_read_input_tokens": 180_000,
                    "cache_creation_input_tokens": 5_000,
                },
            },
            "cost": {
                "total_cost_usd": 0.73,
                "total_duration_ms": 725_000,
                "total_lines_added": 247,
                "total_lines_removed": 38,
            },
            "git_branch": "main",
        }
        for name in ("nord", "tokyo-night", "gruvbox", "rose-pine"):
            result = render(data, name)
            self.assertIsInstance(result, str)
            self.assertTrue(len(result) > 0, "{} produced empty output".format(name))

    def test_new_themes_have_new_sections(self):
        """New themes should include tools, sessions, budget in their layouts."""
        for name in ("nord", "tokyo-night", "gruvbox", "rose-pine"):
            theme = THEMES[name]
            self.assertIn("tools", theme["line2"],
                          "{} missing 'tools' in line2".format(name))
            self.assertIn("sessions", theme["line2"],
                          "{} missing 'sessions' in line2".format(name))
            self.assertIn("budget", theme["line1"],
                          "{} missing 'budget' in line1".format(name))


# ─── sessions.py ────────────────────────────────────────────────────

class TestSessions(unittest.TestCase):
    def test_get_today_session_count_returns_int(self):
        from claude_statusline.sessions import get_today_session_count
        result = get_today_session_count()
        self.assertIsInstance(result, int)
        self.assertGreaterEqual(result, 0)

    def test_get_session_tool_count_empty_id(self):
        from claude_statusline.sessions import get_session_tool_count
        self.assertEqual(get_session_tool_count(""), 0)
        self.assertEqual(get_session_tool_count(None), 0)

    def test_get_session_tool_count_nonexistent(self):
        from claude_statusline.sessions import get_session_tool_count
        result = get_session_tool_count("nonexistent-session-id-12345")
        self.assertEqual(result, 0)

    def test_get_session_tool_count_path_traversal(self):
        """Session IDs with path separators should be rejected."""
        from claude_statusline.sessions import get_session_tool_count
        self.assertEqual(get_session_tool_count("../../etc/passwd"), 0)
        self.assertEqual(get_session_tool_count("foo/bar"), 0)
        self.assertEqual(get_session_tool_count("foo\\bar"), 0)

    def test_cache_path_is_user_scoped(self):
        """Cache files should be in a user-specific directory."""
        from claude_statusline.sessions import _cache_path
        path = _cache_path("test")
        # Should contain a hash-based subdirectory, not be flat in /tmp
        self.assertIn("claude_sl_", path)
        parent = os.path.basename(os.path.dirname(path))
        self.assertTrue(parent.startswith("claude_sl_"))

    def test_get_budget_config_no_file(self):
        from claude_statusline.sessions import get_budget_config
        import claude_statusline.sessions as sessions_mod
        orig = sessions_mod._CLAUDE_DIR
        sessions_mod._CLAUDE_DIR = "/nonexistent/path"
        try:
            result = get_budget_config()
            self.assertIsNone(result)
        finally:
            sessions_mod._CLAUDE_DIR = orig

    def test_get_budget_config_valid(self):
        from claude_statusline.sessions import get_budget_config, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            budget_file = os.path.join(tmpdir, "claude-status-budget.json")
            with open(budget_file, "w") as f:
                json.dump({"daily_budget_usd": 15.0}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            # Invalidate cache to force re-read from new path
            try:
                os.unlink(_cache_path("status_config"))
            except OSError:
                pass
            try:
                result = get_budget_config()
                self.assertAlmostEqual(result, 15.0)
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_get_budget_config_invalid_json(self):
        from claude_statusline.sessions import get_budget_config, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            budget_file = os.path.join(tmpdir, "claude-status-budget.json")
            with open(budget_file, "w") as f:
                f.write("not json {{{")

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("status_config"))
            except OSError:
                pass
            try:
                result = get_budget_config()
                self.assertIsNone(result)
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_session_count_with_mock_sessions(self):
        """Test session counting with mock session files."""
        from claude_statusline.sessions import get_today_session_count, _write_cache
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            sessions_dir = os.path.join(tmpdir, "sessions")
            os.makedirs(sessions_dir)

            # Create a session started "today" (use current epoch)
            now_ms = int(time.time() * 1000)
            with open(os.path.join(sessions_dir, "111.json"), "w") as f:
                json.dump({"pid": 111, "sessionId": "a", "startedAt": now_ms}, f)

            # Create a session from yesterday
            yesterday_ms = now_ms - (86400 * 1000)
            with open(os.path.join(sessions_dir, "222.json"), "w") as f:
                json.dump({"pid": 222, "sessionId": "b", "startedAt": yesterday_ms}, f)

            orig_sessions = sessions_mod._SESSIONS_DIR
            sessions_mod._SESSIONS_DIR = sessions_dir

            # Clear cache to force re-read
            # Clear date-keyed cache
            _write_cache("sessions_{}".format(time.strftime("%Y-%m-%d")), None)

            try:
                count = get_today_session_count()
                self.assertEqual(count, 1)
            finally:
                sessions_mod._SESSIONS_DIR = orig_sessions

    def test_tool_count_with_mock_jsonl(self):
        """Test tool counting with a mock JSONL file."""
        from claude_statusline.sessions import get_session_tool_count, _write_cache
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            projects_dir = os.path.join(tmpdir, "projects")
            project_dir = os.path.join(projects_dir, "test-project")
            os.makedirs(project_dir)

            session_id = "test-session-abc123"
            jsonl_file = os.path.join(project_dir, "{}.jsonl".format(session_id))
            with open(jsonl_file, "w") as f:
                # User message — no tool_use, should not count
                f.write('{"type":"user","message":{"content":"hello"}}\n')
                # Compact JSON tool_use — should count
                f.write('{"message":{"content":[{"type":"tool_use","name":"Bash","input":{}}]}}\n')
                # Text block — should not count
                f.write('{"message":{"content":[{"type":"text","text":"done"}]}}\n')
                # Spaced JSON tool_use — should count
                f.write('{"message":{"content":[{"type": "tool_use", "name": "Read", "input": {}}]}}\n')
                # False positive guard: message mentioning tool_use in text
                f.write('{"message":{"content":[{"type":"text","text":"the tool_use type is used"}]}}\n')

            orig_projects = sessions_mod._PROJECTS_DIR
            sessions_mod._PROJECTS_DIR = projects_dir

            # Clear cache
            import hashlib
            cache_key = "tools_{}".format(
                hashlib.md5(session_id.encode()).hexdigest()[:12]
            )
            _write_cache(cache_key, None)

            try:
                count = get_session_tool_count(session_id)
                self.assertEqual(count, 2)
            finally:
                sessions_mod._PROJECTS_DIR = orig_projects


# ─── cli.py — new sections ──────────────────────────────────────────

class TestBudgetSection(unittest.TestCase):
    def test_budget_warning_red(self):
        """Budget at 90%+ should show bold red."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_budget_config

        cli_mod.get_budget_config = lambda: 1.0

        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.95, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            # Should contain both current cost and budget formatted
            self.assertIn("$0.95", result)
            # Whole-number budgets should display without trailing .0
            self.assertIn("$1", result)
            self.assertNotIn("$1.0", result)
        finally:
            cli_mod.get_budget_config = orig

    def test_budget_not_shown_without_config(self):
        """Without budget config, no budget section should appear."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_budget_config

        cli_mod.get_budget_config = lambda: None

        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            # Should have cost but not budget format ($X/$Y)
            self.assertNotIn("/$", result)
        finally:
            cli_mod.get_budget_config = orig


class TestToolsSection(unittest.TestCase):
    def test_tools_shown_with_session_id(self):
        """Tools count should appear when session has tool calls."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_session_tool_count

        cli_mod.get_session_tool_count = lambda sid: 42

        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "session_id": "test-session",
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("tools:", result)
            self.assertIn("42", result)
        finally:
            cli_mod.get_session_tool_count = orig

    def test_tools_hidden_without_session_id(self):
        """Without session_id, tools section should not appear."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
        }
        result = render(data)
        self.assertNotIn("tools:", result)


class TestSessionsSection(unittest.TestCase):
    def test_sessions_shown(self):
        """Sessions count should appear in output."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_today_session_count

        cli_mod.get_today_session_count = lambda: 5

        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("sessions:", result)
            self.assertIn("5", result)
        finally:
            cli_mod.get_today_session_count = orig


# ─── cli.py — setup command ─────────────────────────────────────────

class TestSetupCommand(unittest.TestCase):
    def test_setup_flag_accepted(self):
        """--setup flag should be recognized by argument parser."""
        result = subprocess.run(
            [sys.executable, "-m", "claude_statusline", "--setup"],
            capture_output=True, timeout=5,
            input="1\n\n",  # choose default theme, skip budget
            encoding="utf-8", errors="replace",
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("setup wizard", result.stdout)

    def test_demo_shows_all_themes(self):
        """Demo should show all 7 themes."""
        result = subprocess.run(
            [sys.executable, "-m", "claude_statusline", "--demo"],
            capture_output=True, timeout=10,
            encoding="utf-8", errors="replace",
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        self.assertEqual(result.returncode, 0)
        for name in ("default", "minimal", "powerline",
                     "nord", "tokyo-night", "gruvbox", "rose-pine"):
            self.assertIn("{}:".format(name), result.stdout,
                          "Demo missing theme: {}".format(name))


# ─── cli.py — version and clock sections ────────────────────────────

class TestVersionSection(unittest.TestCase):
    def test_version_displayed(self):
        """Version string should appear in output."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        result = render(data)
        self.assertIn("v" + __version__, result)

    def test_clock_displayed(self):
        """Current time should appear in output."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        result = render(data)
        # Clock format is HH:MM — check for colon-separated digits
        self.assertRegex(result, r"\d{2}:\d{2}")


# ─── git.py — git extras ────────────────────────────────────────────

class TestGitExtras(unittest.TestCase):
    def test_returns_dict(self):
        from claude_statusline.git import get_git_extras
        result = get_git_extras()
        self.assertIsInstance(result, dict)
        self.assertIn("stash", result)
        self.assertIn("ahead", result)
        self.assertIn("behind", result)

    def test_values_are_ints(self):
        from claude_statusline.git import get_git_extras
        result = get_git_extras()
        self.assertIsInstance(result["stash"], int)
        self.assertIsInstance(result["ahead"], int)
        self.assertIsInstance(result["behind"], int)

    def test_git_extras_section_renders(self):
        """git_extras section should not crash even with no stash/sync data."""
        import claude_statusline.cli as cli_mod
        from claude_statusline.git import get_git_extras as orig_extras
        cli_mod.get_git_extras = lambda: {"stash": 0, "ahead": 0, "behind": 0}
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            # Should render without crashing; no stash/sync = no extras shown
            self.assertIsInstance(result, str)
        finally:
            cli_mod.get_git_extras = orig_extras

    def test_git_extras_with_stash(self):
        """Stash count should appear when stash exists."""
        import claude_statusline.cli as cli_mod
        from claude_statusline.git import get_git_extras as orig_extras
        cli_mod.get_git_extras = lambda: {"stash": 3, "ahead": 0, "behind": 0}
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("stash:3", result)
        finally:
            cli_mod.get_git_extras = orig_extras

    def test_git_extras_with_ahead_behind(self):
        """Ahead/behind should appear when out of sync."""
        import claude_statusline.cli as cli_mod
        from claude_statusline.git import get_git_extras as orig_extras
        cli_mod.get_git_extras = lambda: {"stash": 0, "ahead": 2, "behind": 1}
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("sync:", result)
            self.assertIn("+2", result)
            self.assertIn("-1", result)
        finally:
            cli_mod.get_git_extras = orig_extras


# ─── bar.py — compaction threshold ──────────────────────────────────

class TestCompactionBar(unittest.TestCase):
    def test_bar_without_compaction(self):
        """Bar at 42% without compaction should show ~42% filled."""
        bar = render_bar(42, 20)
        self.assertIn("[", bar)

    def test_bar_with_compaction_scales_up(self):
        """Bar at 31% with 62% compaction threshold should scale to 50%."""
        bar = render_bar(31, 20, compaction_threshold=62)
        self.assertIn("[", bar)

    def test_bar_over_compaction_caps_at_100(self):
        """Bar at 70% with 62% threshold should cap at 100%."""
        bar = render_bar(70, 20, compaction_threshold=62)
        self.assertIn("[", bar)

    def test_bar_compaction_zero_ignored(self):
        """Compaction threshold of 0 should be ignored."""
        bar_normal = render_bar(42, 20)
        bar_zero = render_bar(42, 20, compaction_threshold=0)
        self.assertEqual(bar_normal, bar_zero)

    def test_bar_compaction_none_ignored(self):
        """Compaction threshold of None should be ignored."""
        bar_normal = render_bar(42, 20)
        bar_none = render_bar(42, 20, compaction_threshold=None)
        self.assertEqual(bar_normal, bar_none)


# ─── sessions.py — compaction config ────────────────────────────────

class TestCompactionConfig(unittest.TestCase):
    def test_compaction_threshold_valid(self):
        from claude_statusline.sessions import get_compaction_threshold, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = os.path.join(tmpdir, "claude-status-budget.json")
            with open(config_file, "w") as f:
                json.dump({"compaction_threshold_pct": 62}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("status_config"))
            except OSError:
                pass
            try:
                result = get_compaction_threshold()
                self.assertAlmostEqual(result, 62.0)
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_compaction_threshold_not_configured(self):
        from claude_statusline.sessions import get_compaction_threshold, _cache_path
        import claude_statusline.sessions as sessions_mod

        orig = sessions_mod._CLAUDE_DIR
        sessions_mod._CLAUDE_DIR = "/nonexistent/path"
        try:
            os.unlink(_cache_path("status_config"))
        except OSError:
            pass
        try:
            result = get_compaction_threshold()
            self.assertIsNone(result)
        finally:
            sessions_mod._CLAUDE_DIR = orig


# ─── cli.py — responsive layout ─────────────────────────────────────

class TestResponsiveLayout(unittest.TestCase):
    def test_full_layout_wide_terminal(self):
        """Wide terminal (230+) should keep all sections."""
        from claude_statusline.cli import _apply_responsive
        sections = ["bar", "tokens", "cache", "cost", "burn",
                    "git_extras", "version", "clock"]
        result = _apply_responsive(sections, 230)
        self.assertEqual(result, sections)

    def test_full_layout_above_threshold(self):
        """Well above threshold (300 cols) should keep all sections."""
        from claude_statusline.cli import _apply_responsive
        sections = ["bar", "tokens", "cache", "cost", "burn",
                    "git_extras", "version", "clock"]
        result = _apply_responsive(sections, 300)
        self.assertEqual(result, sections)

    def test_compact_layout_at_old_full_threshold(self):
        """A 120-col terminal (old full threshold) now gets compact.

        This is the core of #70: before v0.5.3, 120 cols returned the
        full layout, which had grown too wide for Line 2 to fit. 120
        now falls into the compact range and drops heavy extras.
        """
        from claude_statusline.cli import _apply_responsive
        sections = ["bar", "tokens", "cache", "cost", "burn",
                    "git_extras", "version", "clock", "context_size",
                    "rate_limits", "speed", "commit_age", "session_name"]
        result = _apply_responsive(sections, 120)
        self.assertIn("bar", result)
        self.assertIn("tokens", result)
        self.assertIn("cost", result)
        # These grew Line 2 past 120 cols — must be dropped at 120 now
        self.assertNotIn("git_extras", result)
        self.assertNotIn("version", result)
        self.assertNotIn("clock", result)
        self.assertNotIn("context_size", result)
        self.assertNotIn("rate_limits", result)
        self.assertNotIn("speed", result)
        self.assertNotIn("commit_age", result)
        self.assertNotIn("session_name", result)

    def test_compact_layout_medium_terminal(self):
        """Medium terminal (100-229) should drop non-essential sections."""
        from claude_statusline.cli import _apply_responsive
        sections = ["bar", "tokens", "cache", "cost", "burn",
                    "git_extras", "version", "clock", "context_size"]
        result = _apply_responsive(sections, 100)
        self.assertIn("bar", result)
        self.assertIn("tokens", result)
        self.assertIn("cost", result)
        self.assertNotIn("git_extras", result)
        self.assertNotIn("version", result)
        self.assertNotIn("clock", result)
        self.assertNotIn("context_size", result)

    def test_narrow_layout_small_terminal(self):
        """Narrow terminal (<100) should show only essentials."""
        from claude_statusline.cli import _apply_responsive
        sections = ["bar", "tokens", "cache", "cost", "burn",
                    "git_extras", "version", "clock", "lines", "budget", "model"]
        result = _apply_responsive(sections, 60)
        self.assertIn("bar", result)
        self.assertIn("tokens", result)
        self.assertIn("cost", result)
        self.assertNotIn("cache", result)
        self.assertNotIn("burn", result)
        self.assertNotIn("lines", result)
        self.assertNotIn("budget", result)
        self.assertNotIn("model", result)

    def test_boundary_at_compact_threshold(self):
        """99 cols (just below compact threshold) should use narrow layout."""
        from claude_statusline.cli import _apply_responsive
        sections = ["bar", "tokens", "cache", "cost"]
        result = _apply_responsive(sections, 99)
        self.assertIn("bar", result)
        self.assertNotIn("cache", result)  # cache is in _NARROW_DROP

    def test_boundary_at_full_threshold(self):
        """149 cols (just below full threshold) should use compact layout.

        The full-layout threshold was lowered from 230 → 150 in the
        width-aware-layout change because a precise post-render fit
        (_fit_to_width) handles the actual sizing — the coarse
        pre-filter only needs to skip expensive sections (git
        subprocess calls, file scans) on terminals where they will
        never fit.
        """
        from claude_statusline.cli import _apply_responsive
        sections = ["bar", "tokens", "cost", "git_extras"]
        result = _apply_responsive(sections, 149)
        self.assertIn("bar", result)
        self.assertNotIn("git_extras", result)  # compact drops git_extras

    def test_boundary_at_exactly_100_cols(self):
        """100 cols (inclusive compact boundary) — compact, not narrow.

        Pins the `>=` comparison at the compact threshold so a future
        off-by-one change to `>` would flip 100-col terminals to narrow
        and this test would fail.
        """
        from claude_statusline.cli import _apply_responsive
        sections = ["bar", "tokens", "cache", "cost", "burn",
                    "git_extras", "version", "clock", "lines", "model"]
        result = _apply_responsive(sections, 100)
        # Compact drops these
        self.assertNotIn("git_extras", result)
        self.assertNotIn("version", result)
        self.assertNotIn("clock", result)
        # Narrow-only drops; must still be present at 100
        self.assertIn("cache", result)
        self.assertIn("burn", result)
        self.assertIn("lines", result)
        self.assertIn("model", result)

    def test_render_fallback_when_columns_unset(self):
        """When COLUMNS is unset and no tty is attached, render() uses the
        (100, 24) fallback — which selects the compact layout, not full.

        Guards the deliberate v0.5.3 fallback change from (120, 24) to
        (100, 24). A revert to 120 would silently resurrect #70 in
        piped/non-tty contexts.
        """
        import claude_statusline.cli as cli_mod
        from claude_statusline.cli import _COMPACT_LAYOUT_MIN_COLS
        # The fallback constant must stay at 100 — or below full threshold.
        self.assertEqual(_COMPACT_LAYOUT_MIN_COLS, 100)
        # Verify get_terminal_size honors the fallback when COLUMNS is unset.
        import shutil
        old_cols = os.environ.pop("COLUMNS", None)
        try:
            size = shutil.get_terminal_size((_COMPACT_LAYOUT_MIN_COLS, 24))
            # When no tty and no COLUMNS, shutil returns the fallback.
            # (In CI COLUMNS may be unset and stdout non-tty → fallback wins.)
            # We can't force non-tty here portably, but we can at least
            # assert the constant is what render() passes in.
            self.assertGreaterEqual(size.columns, 1)
        finally:
            if old_cols is not None:
                os.environ["COLUMNS"] = old_cols


# ─── cli.py — width-aware fit ────────────────────────────────────────

class TestVisibleWidth(unittest.TestCase):
    """_visible_width strips ANSI/OSC 8 — Claude Code's Ink TUI counts
    visible glyphs only, so our fit math must match that."""

    def test_plain_text_width(self):
        from claude_statusline.cli import _visible_width
        self.assertEqual(_visible_width("hello"), 5)

    def test_empty_string(self):
        from claude_statusline.cli import _visible_width
        self.assertEqual(_visible_width(""), 0)

    def test_strips_sgr_color(self):
        from claude_statusline.cli import _visible_width
        # Red "abc" reset → visible width is 3
        self.assertEqual(_visible_width("\x1b[31mabc\x1b[0m"), 3)

    def test_strips_multiple_sgr(self):
        from claude_statusline.cli import _visible_width
        s = "\x1b[1m\x1b[31mbold red\x1b[0m \x1b[32mgreen\x1b[0m"
        self.assertEqual(_visible_width(s), len("bold red green"))

    def test_strips_osc8_hyperlink(self):
        """OSC 8 wrapper bytes are zero-width — only the link text counts."""
        from claude_statusline.cli import _visible_width
        s = "\x1b]8;;https://example.com\x1b\\link\x1b]8;;\x1b\\"
        self.assertEqual(_visible_width(s), len("link"))

    def test_strips_combined_osc8_and_sgr(self):
        from claude_statusline.cli import _visible_width
        s = "\x1b]8;;https://x.test\x1b\\\x1b[36mlinked\x1b[0m\x1b]8;;\x1b\\"
        self.assertEqual(_visible_width(s), len("linked"))

    def test_strips_osc8_with_bel_terminator(self):
        """OSC 8 also permits BEL (\\x07) as the string terminator (Kitty,
        GNU Screen wrappers, some Vim plugins). The regex must match
        both ST and BEL — otherwise BEL-form links inflate the measured
        width and _fit_to_width over-drops sections."""
        from claude_statusline.cli import _visible_width
        s = "\x1b]8;;https://example.com\x07link\x1b]8;;\x07"
        self.assertEqual(_visible_width(s), len("link"))

    def test_strips_osc8_mixed_terminators(self):
        """Defensive: opener with ST, closer with BEL (or vice versa) —
        each wrapper element matches the alternation independently."""
        from claude_statusline.cli import _visible_width
        s = "\x1b]8;;https://x\x1b\\link\x1b]8;;\x07"
        self.assertEqual(_visible_width(s), len("link"))


class TestFitToWidth(unittest.TestCase):
    """_fit_to_width drops sections in priority order until the line fits.

    Sections not in drop_priority are essential and must never be dropped
    (e.g. bar, tokens, cost, branch). Sections in drop_priority are
    dropped earliest-first when the line overflows."""

    def test_no_drop_when_fits(self):
        from claude_statusline.cli import _fit_to_width
        items = [("bar", "[####]"), ("cost", "$1.20")]
        result = _fit_to_width(items, sep_visible_width=3, target_width=80,
                               drop_priority=["clock", "version"])
        self.assertEqual(result, items)

    def test_drops_lowest_priority_first(self):
        """When over budget, the earliest entry in drop_priority is dropped."""
        from claude_statusline.cli import _fit_to_width
        items = [("bar", "[####]"),       # 6
                 ("clock", "12:34"),       # 5
                 ("version", "v0.5.3"),    # 6
                 ("cost", "$1.20")]        # 5
        # Total visible chars = 22 + 3 separators of width 3 = 31.
        # Set target=26 so we must drop one section. drop_priority drops
        # clock first.
        result = _fit_to_width(items, sep_visible_width=3, target_width=26,
                               drop_priority=["clock", "version"])
        names = [n for n, _ in result]
        self.assertNotIn("clock", names)
        self.assertIn("version", names)
        self.assertIn("bar", names)
        self.assertIn("cost", names)

    def test_drops_multiple_when_needed(self):
        from claude_statusline.cli import _fit_to_width
        items = [("bar", "[####]"),      # 6
                 ("clock", "12:34"),     # 5
                 ("version", "v0.5.3"),  # 6
                 ("cost", "$1.20")]      # 5
        # Force a tiny target so both droppable sections must go.
        result = _fit_to_width(items, sep_visible_width=3, target_width=15,
                               drop_priority=["clock", "version"])
        names = [n for n, _ in result]
        self.assertEqual(names, ["bar", "cost"])

    def test_never_drops_essential_sections(self):
        """Sections not in drop_priority are kept even if line still overflows."""
        from claude_statusline.cli import _fit_to_width
        items = [("bar", "[####]"), ("cost", "$1.20")]
        # Target so small nothing fits, but neither section is droppable.
        result = _fit_to_width(items, sep_visible_width=3, target_width=2,
                               drop_priority=["clock", "version"])
        # Both essentials remain — _fit_to_width never drops sections
        # that aren't in the priority list.
        self.assertEqual(result, items)

    def test_strips_ansi_when_measuring(self):
        """Width math must use visible width, not raw byte length."""
        from claude_statusline.cli import _fit_to_width
        # Each item is 6 visible chars but ~16 bytes with ANSI.
        items = [("bar", "\x1b[31m[####]\x1b[0m"),
                 ("clock", "\x1b[90m12:34\x1b[0m"),
                 ("cost", "\x1b[33m$1.20\x1b[0m")]
        # Visible total = 6+5+5 = 16 + 2 seps of width 1 = 18. Fits in 20.
        result = _fit_to_width(items, sep_visible_width=1, target_width=20,
                               drop_priority=["clock"])
        self.assertEqual(len(result), 3)  # nothing dropped

    def test_preserves_order(self):
        from claude_statusline.cli import _fit_to_width
        items = [("a", "AA"), ("b", "BB"), ("c", "CC"), ("d", "DD")]
        # Drop b but keep a, c, d in original order.
        result = _fit_to_width(items, sep_visible_width=1, target_width=8,
                               drop_priority=["b"])
        names = [n for n, _ in result]
        self.assertEqual(names, ["a", "c", "d"])


class TestRenderFitsTerminalWidth(unittest.TestCase):
    """End-to-end: render() must produce output where each line fits the
    reported terminal width. This is the user-visible contract — Claude
    Code's Ink TUI drops Line 2 if Line 1 exceeds the terminal width."""

    def _measure_lines(self, output):
        from claude_statusline.cli import _visible_width
        return [_visible_width(line) for line in output.split("\n")]

    def test_render_fits_at_120_cols(self):
        """At 120 cols, every output line must be ≤ 120 visible chars."""
        from claude_statusline.cli import render, _demo_data
        old = os.environ.get("COLUMNS")
        os.environ["COLUMNS"] = "120"
        try:
            out = render(_demo_data())
            for w in self._measure_lines(out):
                self.assertLessEqual(w, 120,
                    "Line of width {} exceeds terminal width 120".format(w))
        finally:
            if old is None:
                os.environ.pop("COLUMNS", None)
            else:
                os.environ["COLUMNS"] = old

    def test_render_fits_at_150_cols(self):
        from claude_statusline.cli import render, _demo_data
        old = os.environ.get("COLUMNS")
        os.environ["COLUMNS"] = "150"
        try:
            out = render(_demo_data())
            for w in self._measure_lines(out):
                self.assertLessEqual(w, 150)
        finally:
            if old is None:
                os.environ.pop("COLUMNS", None)
            else:
                os.environ["COLUMNS"] = old

    def test_render_fits_at_180_cols(self):
        from claude_statusline.cli import render, _demo_data
        old = os.environ.get("COLUMNS")
        os.environ["COLUMNS"] = "180"
        try:
            out = render(_demo_data())
            for w in self._measure_lines(out):
                self.assertLessEqual(w, 180)
        finally:
            if old is None:
                os.environ.pop("COLUMNS", None)
            else:
                os.environ["COLUMNS"] = old


# ─── cli.py — rate limits section ────────────────────────────────────

class TestRateLimits(unittest.TestCase):
    def _data_with_limits(self, five_h_pct=None, seven_d_pct=None,
                          five_h_resets=None, seven_d_resets=None):
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        rl = {}
        if five_h_pct is not None:
            rl["five_hour"] = {"used_percentage": five_h_pct}
            if five_h_resets is not None:
                rl["five_hour"]["resets_at"] = five_h_resets
        if seven_d_pct is not None:
            rl["seven_day"] = {"used_percentage": seven_d_pct}
            if seven_d_resets is not None:
                rl["seven_day"]["resets_at"] = seven_d_resets
        if rl:
            data["rate_limits"] = rl
        return data

    def test_rate_limits_displayed(self):
        """Rate limits should appear when present."""
        data = self._data_with_limits(five_h_pct=34, seven_d_pct=18)
        result = render(data)
        self.assertIn("5h:34%", result)
        self.assertIn("7d:18%", result)

    def test_rate_limits_hidden_when_absent(self):
        """Rate limits should not appear for non-Pro users."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        result = render(data)
        self.assertNotIn("5h:", result)
        self.assertNotIn("7d:", result)

    def test_rate_limits_only_5h(self):
        """Should handle only 5-hour limit present."""
        data = self._data_with_limits(five_h_pct=72)
        result = render(data)
        self.assertIn("5h:72%", result)
        self.assertNotIn("7d:", result)

    def test_rate_limits_zero_values(self):
        """Zero percentages should display correctly."""
        data = self._data_with_limits(five_h_pct=0, seven_d_pct=0)
        result = render(data)
        self.assertIn("5h:0%", result)
        self.assertIn("7d:0%", result)

    def test_rate_limits_with_countdown(self):
        """Reset countdown should appear when resets_at is in the future."""
        future_sec = int(time.time()) + 7_200  # 2 hours from now (seconds)
        data = self._data_with_limits(five_h_pct=50, five_h_resets=future_sec)
        result = render(data)
        self.assertIn("5h:50%", result)
        self.assertIn("~", result)  # countdown prefix

    def test_rate_limits_only_7d(self):
        """Should handle only 7-day limit present."""
        data = self._data_with_limits(seven_d_pct=45)
        result = render(data)
        self.assertIn("7d:45%", result)
        self.assertNotIn("5h:", result)

    def test_rate_limits_high_percentage(self):
        """100% should display correctly."""
        data = self._data_with_limits(five_h_pct=100)
        result = render(data)
        self.assertIn("5h:100%", result)

    def test_rate_limits_float_percentage(self):
        """Float percentage should be truncated to int."""
        data = self._data_with_limits(five_h_pct=99.7)
        result = render(data)
        self.assertIn("5h:99%", result)

    def test_rate_limits_clamped_above_100(self):
        """Values modestly above 100% (e.g. 105) still flow through
        the renderer's clamp(0, 100) and display as `5h:100%` — this
        is the legitimate "user is maxed out" UI for any future
        Anthropic 'overage' indicator. Only values >= 1e6 (the upstream
        epoch-timestamp bug pattern) are pre-emptively hidden.

        See TestRateLimitsEpochTimestampGuard for the full contract.
        """
        data = self._data_with_limits(five_h_pct=105)
        result = render(data)
        self.assertIn("5h:100%", result,
            "values modestly above 100 should clamp to 100% in the UI, "
            "not be silently hidden — only the epoch-timestamp bug "
            "pattern (>= 1e6) triggers the hide-section guard")

    def test_rate_limits_nearest_reset(self):
        """Should show countdown to the nearest reset when both present."""
        now = int(time.time())
        data = self._data_with_limits(
            five_h_pct=50, five_h_resets=now + 3_600,      # 1h (seconds)
            seven_d_pct=20, seven_d_resets=now + 86_400,   # 24h (seconds)
        )
        result = render(data)
        # Should show ~59m or ~1h, not ~24h
        self.assertIn("~", result)


class TestRateLimitsResetConversion(unittest.TestCase):
    """Verify resets_at seconds-to-milliseconds conversion."""

    def test_resets_at_seconds_converted_to_ms(self):
        """resets_at in seconds should produce a valid countdown."""
        from claude_statusline.cli import _normalize
        # Real Claude Code sends epoch seconds (roughly 1.7 billion)
        future_sec = int(time.time()) + 3600  # 1 hour from now
        data = {
            "rate_limits": {
                "five_hour": {
                    "used_percentage": 50,
                    "resets_at": future_sec,
                },
            },
        }
        n = _normalize(data)
        # Should be converted to milliseconds internally
        self.assertIsNotNone(n["rate_limit_5h_resets"])
        self.assertGreater(n["rate_limit_5h_resets"], future_sec)
        # Should be roughly future_sec * 1000
        self.assertAlmostEqual(
            n["rate_limit_5h_resets"], future_sec * 1000, delta=1000
        )

    def test_resets_at_none_stays_none(self):
        """Missing resets_at should remain None after conversion."""
        from claude_statusline.cli import _normalize
        data = {
            "rate_limits": {
                "five_hour": {"used_percentage": 50},
            },
        }
        n = _normalize(data)
        self.assertIsNone(n["rate_limit_5h_resets"])


class TestRateLimitsMalformed(unittest.TestCase):
    """Rate limits must never crash on malformed input."""

    def _base_data(self):
        return {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }

    def test_rate_limits_as_string(self):
        data = self._base_data()
        data["rate_limits"] = "rate_limited"
        result = render(data)
        self.assertIsInstance(result, str)

    def test_rate_limits_as_list(self):
        data = self._base_data()
        data["rate_limits"] = [1, 2, 3]
        result = render(data)
        self.assertIsInstance(result, str)

    def test_percentage_as_string(self):
        data = self._base_data()
        data["rate_limits"] = {"five_hour": {"used_percentage": "34%"}}
        result = render(data)
        self.assertIsInstance(result, str)

    def test_resets_at_as_iso_string(self):
        data = self._base_data()
        data["rate_limits"] = {"five_hour": {
            "used_percentage": 34,
            "resets_at": "2026-04-05T12:00:00Z",
        }}
        result = render(data)
        self.assertIsInstance(result, str)

    def test_five_hour_as_non_dict(self):
        data = self._base_data()
        data["rate_limits"] = {"five_hour": "invalid"}
        result = render(data)
        self.assertIsInstance(result, str)

    def test_negative_percentage(self):
        data = self._base_data()
        data["rate_limits"] = {"five_hour": {"used_percentage": -5}}
        result = render(data)
        self.assertIn("5h:0%", result)


# ─── cli.py — session name section ──────────────────────────────────

class TestSessionName(unittest.TestCase):
    def test_session_name_displayed(self):
        """Session name should appear with icon when set."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "session_name": "refactor auth",
            "git_branch": "main",
        }
        result = render(data)
        self.assertIn("refactor auth", result)
        self.assertIn("\u2726", result)

    def test_session_name_hidden_when_absent(self):
        """Session name should not appear when not set."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        result = render(data)
        self.assertNotIn("\u2726", result)

    def test_session_name_hidden_when_empty(self):
        """Empty session name should not render."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "session_name": "",
            "git_branch": "main",
        }
        result = render(data)
        self.assertNotIn("\u2726", result)


# ─── cli.py — Claude Code version section ───────────────────────────

class TestCCVersion(unittest.TestCase):
    def test_cc_version_displayed(self):
        """Claude Code version should appear when present."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "version": "2.1.92",
            "git_branch": "main",
        }
        result = render(data)
        self.assertIn("CC:2.1.92", result)

    def test_cc_version_hidden_when_absent(self):
        """CC version should not appear when not in payload."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        result = render(data)
        self.assertNotIn("CC:", result)

    def test_cc_version_hidden_when_empty(self):
        """Empty version string should not render."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "version": "",
            "git_branch": "main",
        }
        result = render(data)
        self.assertNotIn("CC:", result)


# ─── formatters.py — countdown ──────────────────────────────────────

class TestFmtCountdown(unittest.TestCase):
    def test_future_timestamp(self):
        """Future timestamp should return countdown string."""
        from claude_statusline.formatters import fmt_countdown
        future_ms = int(time.time() * 1000) + 7_200_000  # 2h from now
        result = fmt_countdown(future_ms)
        self.assertTrue(result.startswith("~"))
        self.assertIn("h", result)

    def test_past_timestamp(self):
        """Past timestamp should return empty string."""
        from claude_statusline.formatters import fmt_countdown
        past_ms = int(time.time() * 1000) - 60_000
        result = fmt_countdown(past_ms)
        self.assertEqual(result, "")

    def test_none_timestamp(self):
        """None should return empty string."""
        from claude_statusline.formatters import fmt_countdown
        self.assertEqual(fmt_countdown(None), "")


# ─── cli.py — output style section ──────────────────────────────────

class TestOutputStyle(unittest.TestCase):
    def _base_data(self, **extra):
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        data.update(extra)
        return data

    def test_output_style_displayed(self):
        data = self._base_data(output_style={"name": "explanatory"})
        result = render(data)
        self.assertIn("style:explanatory", result)

    def test_output_style_hidden_when_absent(self):
        data = self._base_data()
        result = render(data)
        self.assertNotIn("style:", result)

    def test_output_style_hidden_when_empty(self):
        data = self._base_data(output_style={"name": ""})
        result = render(data)
        self.assertNotIn("style:", result)

    def test_output_style_non_dict(self):
        """Non-dict output_style should not crash."""
        data = self._base_data(output_style="concise")
        result = render(data)
        self.assertIsInstance(result, str)

    def test_output_style_null_name(self):
        data = self._base_data(output_style={"name": None})
        result = render(data)
        self.assertNotIn("style:", result)


# ─── cli.py — added directories section ─────────────────────────────

class TestAddedDirs(unittest.TestCase):
    def _base_data(self, **extra):
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        data.update(extra)
        return data

    def test_added_dirs_displayed(self):
        data = self._base_data(workspace={
            "project_dir": "/home/user/myapp",
            "added_dirs": ["/lib1", "/lib2"],
        })
        result = render(data)
        self.assertIn("dirs:+2", result)

    def test_added_dirs_hidden_when_empty(self):
        data = self._base_data(workspace={
            "project_dir": "/home/user/myapp",
            "added_dirs": [],
        })
        result = render(data)
        self.assertNotIn("dirs:", result)

    def test_added_dirs_hidden_when_absent(self):
        data = self._base_data()
        result = render(data)
        self.assertNotIn("dirs:", result)

    def test_added_dirs_non_list(self):
        """Non-list added_dirs should not crash."""
        data = self._base_data(workspace={
            "project_dir": "/home/user/myapp",
            "added_dirs": "not a list",
        })
        result = render(data)
        self.assertIsInstance(result, str)
        self.assertNotIn("dirs:", result)


# ─── sessions.py — effort level ─────────────────────────────────────

class TestEffortLevel(unittest.TestCase):
    def test_effort_high(self):
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"effortLevel": "high"}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertEqual(result, "high")
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_effort_medium_returns_none(self):
        """Medium is the default — should return None to hide the section."""
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"effortLevel": "medium"}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertIsNone(result)
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_effort_low(self):
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"effortLevel": "low"}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertEqual(result, "low")
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_effort_xhigh(self):
        """Opus 4.7 (Claude Code v2.1.111+) introduced `xhigh` between
        `high` and `max`. Must be accepted by get_effort_level()."""
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"effortLevel": "xhigh"}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertEqual(result, "xhigh")
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_effort_max(self):
        """`max` is the top-tier effort level (above xhigh) — visible
        in Anthropic's Auto Mode references and `/effort max` toast.
        Without this, Pro/Max users on max would silently lose the
        effort indicator."""
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"effortLevel": "max"}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertEqual(result, "max")
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_effort_xhigh_case_insensitive(self):
        """Production code does `raw.lower()` — settings.json values
        like "XHIGH" or "Xhigh" must still resolve to "xhigh". Pins
        the contract so a future refactor can't silently drop the
        case-folding."""
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"effortLevel": "XHIGH"}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertEqual(result, "xhigh")
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_effort_xhigh_cache_hit_path(self):
        """The cache-hit path in get_effort_level() also goes through
        the `_VALID_EFFORT_LEVELS` membership check. A future change
        that updates the disk-read validator but forgets the cache-read
        validator would silently break xhigh on warm caches. This test
        pins the cache-hit path independently."""
        from claude_statusline.sessions import (
            get_effort_level, _cache_path, _write_cache,
        )
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            # Seed the cache directly so we exercise the cache-read
            # path, not the disk-read path. Removing settings.json
            # ensures get_effort_level can't fall through to disk and
            # accidentally pass via the wrong code path.
            try:
                _write_cache("effort_level", {"effort": "xhigh"})
                result = get_effort_level()
                self.assertEqual(result, "xhigh",
                    "cache-hit path must also recognize xhigh — "
                    "_VALID_EFFORT_LEVELS check applies on both paths")
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_effort_absent_returns_none(self):
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        orig = sessions_mod._CLAUDE_DIR
        sessions_mod._CLAUDE_DIR = "/nonexistent/path"
        try:
            os.unlink(_cache_path("effort_level"))
        except OSError:
            pass
        try:
            result = get_effort_level()
            self.assertIsNone(result)
        finally:
            sessions_mod._CLAUDE_DIR = orig

    def test_effort_invalid_value(self):
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"effortLevel": "ultrathink"}, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertIsNone(result)
            finally:
                sessions_mod._CLAUDE_DIR = orig


class TestEffortSection(unittest.TestCase):
    def test_effort_high_rendered(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: "high"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("effort:high", result)
        finally:
            cli_mod.get_effort_level = orig

    def test_effort_hidden_when_none(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: None
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertNotIn("effort:", result)
        finally:
            cli_mod.get_effort_level = orig

    def test_effort_low_rendered(self):
        """Effort low should display with dim color."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: "low"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("effort:low", result)
        finally:
            cli_mod.get_effort_level = orig

    def test_effort_xhigh_rendered(self):
        """xhigh (Opus 4.7) renders the same way as high but uses the
        dedicated effort_xhigh color key. The literal `effort:xhigh`
        text must appear in the rendered output."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: "xhigh"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("effort:xhigh", result)
        finally:
            cli_mod.get_effort_level = orig

    def test_effort_xhigh_uses_dedicated_color_key(self):
        """A theme that overrides effort_xhigh to a distinct color must
        have that color used for xhigh — proves the cli.py branch picks
        the xhigh-specific key, not the high fallback.
        """
        import claude_statusline.cli as cli_mod
        from claude_statusline.colors import CYAN
        from claude_statusline.themes import THEMES
        # Save & override the default theme's effort_xhigh to a known
        # distinct color (CYAN, not BRIGHT_MAGENTA which both high and
        # default xhigh use).
        orig_theme_color = THEMES["default"]["colors"]["effort_xhigh"]
        THEMES["default"]["colors"]["effort_xhigh"] = CYAN
        orig_get_effort = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: "xhigh"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            # CYAN escape (\x1b[36m) must appear before "effort:xhigh"
            self.assertIn("\x1b[36m", result,
                "effort_xhigh color key was not used — xhigh branch may be "
                "falling back to effort_high or effort_low instead")
            self.assertIn("effort:xhigh", result)
        finally:
            cli_mod.get_effort_level = orig_get_effort
            THEMES["default"]["colors"]["effort_xhigh"] = orig_theme_color

    def test_effort_max_rendered(self):
        """`max` must render with the literal `effort:max` text. Same
        renderer path as xhigh, dedicated `effort_max` color key."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: "max"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("effort:max", result)
        finally:
            cli_mod.get_effort_level = orig

    def test_effort_xhigh_color_key_explicit_None_does_not_crash(self):
        """A custom theme that explicitly sets `effort_xhigh: None`
        (common when YAML/JSON tools serialize "no value" as null)
        must not crash colorize(). The renderer uses _first() so an
        explicit None falls through to the next key in the chain
        instead of being passed to colorize() and triggering a
        TypeError on `"".join((None, ...))`."""
        import claude_statusline.cli as cli_mod
        from claude_statusline.themes import THEMES
        orig_xhigh = THEMES["default"]["colors"]["effort_xhigh"]
        orig_get_effort = cli_mod.get_effort_level
        THEMES["default"]["colors"]["effort_xhigh"] = None
        cli_mod.get_effort_level = lambda: "xhigh"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            # Must not raise.
            result = render(data)
            self.assertIn("effort:xhigh", result,
                "render() crashed or hid effort when effort_xhigh was None")
        finally:
            cli_mod.get_effort_level = orig_get_effort
            THEMES["default"]["colors"]["effort_xhigh"] = orig_xhigh

    def test_effort_xhigh_falls_back_to_high_color_when_key_missing(self):
        """Custom themes pinned at older versions won't have
        effort_xhigh defined. The renderer must fall back to
        effort_high (not effort_low or hard-coded), since xhigh is
        semantically "above high"."""
        import claude_statusline.cli as cli_mod
        from claude_statusline.colors import CYAN, RED
        from claude_statusline.themes import THEMES
        # Remove effort_xhigh, set effort_high to a distinct color.
        orig_xhigh = THEMES["default"]["colors"].pop("effort_xhigh")
        orig_high = THEMES["default"]["colors"]["effort_high"]
        THEMES["default"]["colors"]["effort_high"] = CYAN
        orig_get_effort = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: "xhigh"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            # Should fall back to effort_high (CYAN), NOT to BRIGHT_BLACK
            # (which is effort_low) and NOT to RED (which is unrelated).
            self.assertIn("\x1b[36m", result,
                "xhigh should fall back to effort_high color when "
                "effort_xhigh key is missing from the theme")
            self.assertNotIn(RED, result,
                "xhigh fallback picked an unrelated color")
        finally:
            cli_mod.get_effort_level = orig_get_effort
            THEMES["default"]["colors"]["effort_xhigh"] = orig_xhigh
            THEMES["default"]["colors"]["effort_high"] = orig_high


class TestEffortLevelCorrupted(unittest.TestCase):
    def test_corrupted_settings_returns_none(self):
        """Invalid JSON in settings.json should return None gracefully."""
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                f.write("{not valid json")

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertIsNone(result)
            finally:
                sessions_mod._CLAUDE_DIR = orig

    def test_non_dict_settings_returns_none(self):
        """settings.json containing a JSON array should not crash."""
        from claude_statusline.sessions import get_effort_level, _cache_path
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump([1, 2, 3], f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("effort_level"))
            except OSError:
                pass
            try:
                result = get_effort_level()
                self.assertIsNone(result)
            finally:
                sessions_mod._CLAUDE_DIR = orig


class TestAddedDirsExtra(unittest.TestCase):
    def test_single_added_dir(self):
        """Single added directory should show dirs:+1."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
            "workspace": {
                "project_dir": "/home/user/myapp",
                "added_dirs": ["/lib1"],
            },
        }
        result = render(data)
        self.assertIn("dirs:+1", result)


class TestOutputStyleExtra(unittest.TestCase):
    def test_output_style_non_string_name(self):
        """Non-string name value should not crash."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
            "output_style": {"name": ["not", "a", "string"]},
        }
        result = render(data)
        self.assertNotIn("style:", result)

    def test_output_style_missing_name_key(self):
        """output_style dict without name key should not crash."""
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
            "output_style": {},
        }
        result = render(data)
        self.assertNotIn("style:", result)


# ─── cli.py — git worktree indicator ────────────────────────────────

class TestGitWorktree(unittest.TestCase):
    def _base_data(self, **extra):
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        data.update(extra)
        return data

    def test_git_worktree_shown_when_true(self):
        data = self._base_data(workspace={
            "project_dir": "/home/user/myapp",
            "git_worktree": True,
        })
        result = render(data)
        self.assertIn("gwt", result)

    def test_git_worktree_hidden_when_false(self):
        data = self._base_data(workspace={
            "project_dir": "/home/user/myapp",
            "git_worktree": False,
        })
        result = render(data)
        self.assertNotIn("gwt", result)

    def test_git_worktree_hidden_when_absent(self):
        data = self._base_data()
        result = render(data)
        self.assertNotIn("gwt", result)

    def test_git_worktree_non_boolean(self):
        """Non-boolean value should not crash."""
        data = self._base_data(workspace={
            "project_dir": "/home/user/myapp",
            "git_worktree": "yes",
        })
        result = render(data)
        # Truthy string should show the indicator
        self.assertIn("gwt", result)


# ─── cli.py — uninstall command ─────────────────────────────────────

class TestUninstall(unittest.TestCase):
    def test_uninstall_removes_statusline(self):
        """--uninstall should remove statusLine from settings."""
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({
                    "statusLine": {"type": "command", "command": "claude-status"},
                    "otherKey": "preserved",
                }, f)

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            try:
                cli_mod.cmd_uninstall()
                with open(settings_file, "r") as f:
                    settings = json.load(f)
                self.assertNotIn("statusLine", settings)
                self.assertEqual(settings["otherKey"], "preserved")
            finally:
                cli_mod._settings_path = orig

    def test_uninstall_restores_from_backup(self):
        """--uninstall should restore previous config from .bak."""
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            backup_file = settings_file + ".bak"

            # Current settings
            with open(settings_file, "w") as f:
                json.dump({
                    "statusLine": {"type": "command", "command": "claude-status"},
                }, f)
            # Backup with different statusLine
            with open(backup_file, "w") as f:
                json.dump({
                    "statusLine": {"type": "command", "command": "old-tool"},
                }, f)

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            try:
                cli_mod.cmd_uninstall()
                with open(settings_file, "r") as f:
                    settings = json.load(f)
                self.assertEqual(
                    settings["statusLine"]["command"], "old-tool"
                )
            finally:
                cli_mod._settings_path = orig

    def test_uninstall_when_not_installed(self):
        """--uninstall should handle missing statusLine gracefully."""
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"otherKey": "value"}, f)

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            try:
                cli_mod.cmd_uninstall()  # should not crash
            finally:
                cli_mod._settings_path = orig

    def test_uninstall_missing_file(self):
        """--uninstall should handle missing settings file."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod._settings_path
        cli_mod._settings_path = lambda: "/nonexistent/settings.json"
        try:
            cli_mod.cmd_uninstall()  # should not crash
        finally:
            cli_mod._settings_path = orig


# ─── themes.py — focus theme ────────────────────────────────────────

class TestUninstallEdgeCases(unittest.TestCase):
    def test_uninstall_corrupt_settings(self):
        """Corrupt settings.json should not crash uninstall."""
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                f.write("{not valid json")

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            try:
                cli_mod.cmd_uninstall()  # should not crash
            finally:
                cli_mod._settings_path = orig

    def test_uninstall_backup_same_as_current(self):
        """When backup has same statusLine, should remove it."""
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            backup_file = settings_file + ".bak"
            sl = {"type": "command", "command": "claude-status"}

            with open(settings_file, "w") as f:
                json.dump({"statusLine": sl}, f)
            with open(backup_file, "w") as f:
                json.dump({"statusLine": sl}, f)

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            try:
                cli_mod.cmd_uninstall()
                with open(settings_file, "r") as f:
                    settings = json.load(f)
                self.assertNotIn("statusLine", settings)
            finally:
                cli_mod._settings_path = orig

    def test_uninstall_corrupt_backup(self):
        """Corrupt backup should not crash, should remove statusLine."""
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            backup_file = settings_file + ".bak"

            with open(settings_file, "w") as f:
                json.dump({"statusLine": {"type": "command", "command": "claude-status"}}, f)
            with open(backup_file, "w") as f:
                f.write("{corrupt backup")

            import claude_statusline.cli as cli_mod
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            try:
                cli_mod.cmd_uninstall()
                with open(settings_file, "r") as f:
                    settings = json.load(f)
                self.assertNotIn("statusLine", settings)
            finally:
                cli_mod._settings_path = orig


class TestFocusTheme(unittest.TestCase):
    def test_focus_theme_exists(self):
        self.assertIn("focus", THEMES)

    def test_focus_theme_single_line(self):
        """Focus theme should produce a single line."""
        data = {
            "context_window": {"used_percentage": 42,
                               "context_window_size": 200_000,
                               "current_usage": {"input_tokens": 50000}},
            "cost": {"total_cost_usd": 0.73, "total_duration_ms": 300000},
            "git_branch": "main",
        }
        result = render(data, "focus")
        lines = result.split("\n")
        self.assertEqual(len(lines), 1,
                         "Focus theme should produce 1 line, got {}".format(len(lines)))

    def test_focus_theme_has_narrow_bar(self):
        """Focus theme should use a narrower bar width."""
        self.assertEqual(THEMES["focus"].get("bar_width", 20), 12)

    def test_focus_theme_empty_line2(self):
        """Focus theme line2 should be empty."""
        self.assertEqual(THEMES["focus"]["line2"], [])

    def test_focus_theme_has_required_colors(self):
        """Focus theme should have all required color keys."""
        required = ["separator", "label", "value", "cost",
                     "branch_main", "branch_feature"]
        for key in required:
            self.assertIn(key, THEMES["focus"]["colors"],
                          "focus theme missing color: {}".format(key))


# ─── cli.py — print-config (machine-readable install state) ─────────

class TestPrintConfig(unittest.TestCase):
    """`--print-config` is the agent-facing introspection flag.

    Output contract: 7 key=value lines in a stable order. Exit code 0
    when claude-status is the configured statusLine command, 1
    otherwise. Lets coding agents detect installation state without
    parsing settings.json themselves.
    """

    def _run_with_settings(self, settings_dict_or_none, corrupt=False):
        """Helper: run cmd_print_config against a temp settings.json.

        Returns (stdout_lines_dict, exit_code). settings_dict_or_none=None
        means no file. corrupt=True writes garbage instead of JSON.
        """
        import claude_statusline.cli as cli_mod
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            if corrupt:
                with open(settings_file, "w") as f:
                    f.write("{not valid json")
            elif settings_dict_or_none is not None:
                with open(settings_file, "w") as f:
                    json.dump(settings_dict_or_none, f)
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            # Capture stdout + intercept SystemExit
            from io import StringIO
            old_stdout = sys.stdout
            sys.stdout = StringIO()
            exit_code = None
            try:
                try:
                    cli_mod.cmd_print_config()
                except SystemExit as e:
                    exit_code = e.code
                output = sys.stdout.getvalue()
            finally:
                sys.stdout = old_stdout
                cli_mod._settings_path = orig
            # Parse key=value lines
            kv = {}
            for line in output.strip().split("\n"):
                if "=" in line:
                    k, _, v = line.partition("=")
                    kv[k] = v
            return kv, exit_code

    def test_emits_all_eight_keys_in_stable_order(self):
        """Output contract: 8 keys, always in this exact order.

        Agents and shell scripts parse this — silent reordering or
        adding/removing keys would break every downstream consumer.
        """
        import claude_statusline.cli as cli_mod
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            with open(settings_file, "w") as f:
                json.dump({"statusLine": {"type": "command",
                                          "command": "claude-status"}}, f)
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            from io import StringIO
            old_stdout = sys.stdout
            sys.stdout = StringIO()
            try:
                try:
                    cli_mod.cmd_print_config()
                except SystemExit:
                    pass
                output = sys.stdout.getvalue()
            finally:
                sys.stdout = old_stdout
                cli_mod._settings_path = orig
        keys_in_order = [line.split("=", 1)[0]
                         for line in output.strip().split("\n")]
        self.assertEqual(
            keys_in_order,
            ["installed", "command", "type", "refreshInterval",
             "theme", "version", "settings_path", "settings_state"],
            "key order or set changed — agents parsing this output will break"
        )

    def test_no_settings_file(self):
        """No settings file → installed=false, exit 1, all values empty."""
        kv, code = self._run_with_settings(None)
        self.assertEqual(kv["installed"], "false")
        self.assertEqual(kv["command"], "")
        self.assertEqual(kv["type"], "")
        self.assertEqual(kv["refreshInterval"], "")
        self.assertEqual(kv["theme"], "")
        self.assertEqual(code, 1)

    def test_settings_without_statusline(self):
        """Settings exists but no statusLine → installed=false, exit 1."""
        kv, code = self._run_with_settings({"otherKey": "value"})
        self.assertEqual(kv["installed"], "false")
        self.assertEqual(code, 1)

    def test_statusline_pointing_at_other_tool(self):
        """statusLine pointing at non-claude-status tool → installed=false."""
        kv, code = self._run_with_settings({
            "statusLine": {"type": "command", "command": "starship prompt"}
        })
        self.assertEqual(kv["installed"], "false")
        # Command field still reports what's there for diagnosis.
        self.assertEqual(kv["command"], "starship prompt")
        self.assertEqual(code, 1)

    def test_default_install(self):
        """statusLine command 'claude-status' → installed=true, theme=default, exit 0."""
        kv, code = self._run_with_settings({
            "statusLine": {"type": "command", "command": "claude-status"}
        })
        self.assertEqual(kv["installed"], "true")
        self.assertEqual(kv["command"], "claude-status")
        self.assertEqual(kv["type"], "command")
        self.assertEqual(kv["theme"], "default")
        self.assertEqual(code, 0)

    def test_install_with_theme(self):
        """--theme NAME in command is parsed back out into the theme key."""
        kv, code = self._run_with_settings({
            "statusLine": {"type": "command",
                           "command": "claude-status --theme nord"}
        })
        self.assertEqual(kv["installed"], "true")
        self.assertEqual(kv["theme"], "nord")
        self.assertEqual(code, 0)

    def test_install_with_refresh_interval(self):
        """refreshInterval is preserved (numeric → string of int)."""
        kv, code = self._run_with_settings({
            "statusLine": {"type": "command",
                           "command": "claude-status",
                           "refreshInterval": 10}
        })
        self.assertEqual(kv["installed"], "true")
        self.assertEqual(kv["refreshInterval"], "10")

    def test_corrupt_settings_does_not_crash(self):
        """Corrupt settings.json → installed=false, exit 2, no traceback.

        Exit code 2 (not 1) is intentional: it signals 'do not auto-act'
        to coding agents so they don't overwrite recoverable user
        config. See TestPrintConfigEdgeCases.test_settings_state_unreadable_when_corrupt
        for the full contract.
        """
        kv, code = self._run_with_settings(None, corrupt=True)
        self.assertEqual(kv["installed"], "false")
        self.assertEqual(code, 2)

    def test_version_field_matches_module(self):
        """version field is always the running module __version__."""
        from claude_statusline import __version__
        kv, _ = self._run_with_settings(None)
        self.assertEqual(kv["version"], __version__)

    def test_path_to_full_claude_status_binary(self):
        """When settings.json points to an absolute path ending in
        claude-status (e.g. /usr/local/bin/claude-status), still
        installed=true.
        """
        kv, code = self._run_with_settings({
            "statusLine": {"type": "command",
                           "command": "/usr/local/bin/claude-status --theme focus"}
        })
        self.assertEqual(kv["installed"], "true")
        self.assertEqual(kv["theme"], "focus")
        self.assertEqual(code, 0)

    def test_subprocess_invocation_returns_correct_exit_code(self):
        """End-to-end: invoke `python -m claude_statusline --print-config`
        as a subprocess. Exit code must propagate so shell scripts can
        rely on it (`if claude-status --print-config >/dev/null; then …`).
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            home = tmpdir
            os.makedirs(os.path.join(home, ".claude"))
            with open(os.path.join(home, ".claude", "settings.json"), "w") as f:
                json.dump({"statusLine": {"type": "command",
                                          "command": "claude-status"}}, f)
            env = os.environ.copy()
            env["HOME"] = home
            env["USERPROFILE"] = home  # Windows uses USERPROFILE for home
            # On Windows, expanduser also consults HOMEDRIVE+HOMEPATH; clear
            # them or the host's real home wins and the test goes flaky.
            env.pop("HOMEDRIVE", None)
            env.pop("HOMEPATH", None)
            r = subprocess.run(
                [sys.executable, "-m", "claude_statusline", "--print-config"],
                env=env, capture_output=True, text=True, timeout=5,
            )
            self.assertEqual(r.returncode, 0,
                "expected exit 0 for installed state; got {}\nSTDOUT: {}\nSTDERR: {}".format(
                    r.returncode, r.stdout, r.stderr))
            self.assertIn("installed=true", r.stdout)


class TestPrintConfigEdgeCases(unittest.TestCase):
    """Defensive tests for --print-config — every case here corresponds
    to a silent-failure mode flagged in the v0.5.5 PR review.

    Reuses the same helpers as TestPrintConfig but with adversarial
    inputs (non-dict statusLine, Windows .exe paths, --theme= form,
    newline injection, corrupt settings, etc.). Each test pins the
    behavior so a future refactor cannot regress silently.
    """

    def _run_with_settings(self, settings_dict_or_none, corrupt=False):
        import claude_statusline.cli as cli_mod
        with tempfile.TemporaryDirectory() as tmpdir:
            settings_file = os.path.join(tmpdir, "settings.json")
            if corrupt:
                with open(settings_file, "w") as f:
                    f.write("{not valid json")
            elif settings_dict_or_none is not None:
                with open(settings_file, "w") as f:
                    json.dump(settings_dict_or_none, f)
            orig = cli_mod._settings_path
            cli_mod._settings_path = lambda: settings_file
            from io import StringIO
            old_stdout = sys.stdout
            old_stderr = sys.stderr
            sys.stdout = StringIO()
            sys.stderr = StringIO()
            exit_code = None
            try:
                try:
                    cli_mod.cmd_print_config()
                except SystemExit as e:
                    exit_code = e.code
                stdout_text = sys.stdout.getvalue()
                stderr_text = sys.stderr.getvalue()
            finally:
                sys.stdout = old_stdout
                sys.stderr = old_stderr
                cli_mod._settings_path = orig
            kv = {}
            for line in stdout_text.strip().split("\n"):
                if "=" in line:
                    k, _, v = line.partition("=")
                    kv[k] = v
            return kv, exit_code, stdout_text, stderr_text

    # ── settings.json shape edge cases ──────────────────────────────

    def test_statusline_is_string_not_dict(self):
        """Some users naively write `"statusLine": "claude-status"`.
        Must not crash; reports installed=false; isinstance(sl, dict)
        guard is the only thing protecting us."""
        kv, code, _, _ = self._run_with_settings({"statusLine": "claude-status"})
        self.assertEqual(kv["installed"], "false")
        self.assertEqual(code, 1)

    def test_statusline_is_list_not_dict(self):
        kv, code, _, _ = self._run_with_settings({"statusLine": ["claude-status"]})
        self.assertEqual(kv["installed"], "false")
        self.assertEqual(code, 1)

    def test_statusline_is_none(self):
        """`"statusLine": null` (explicit clear) reports installed=false."""
        kv, code, _, _ = self._run_with_settings({"statusLine": None})
        self.assertEqual(kv["installed"], "false")
        self.assertEqual(code, 1)

    def test_settings_file_is_json_array_not_object(self):
        """Whole settings.json is a list — isinstance(settings, dict)
        guard prevents AttributeError."""
        kv, code, _, _ = self._run_with_settings(["not", "an", "object"])
        self.assertEqual(kv["installed"], "false")
        self.assertEqual(code, 1)

    # ── install detection — Windows + module forms ──────────────────

    def test_windows_exe_suffix(self):
        """Pip on Windows typically writes claude-status.exe."""
        kv, code, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": "claude-status.exe"}
        })
        self.assertEqual(kv["installed"], "true")
        self.assertEqual(code, 0)

    def test_windows_full_path_with_spaces(self):
        """Quoted Windows path with a space in `Program Files`. shlex
        is required — plain str.split() would mangle this into multiple
        tokens and fail detection."""
        # JSON serializes backslashes as \\, settings.json stores them
        # as single backslashes after parse. Use forward slashes here
        # for cross-platform consistency since either works.
        kv, code, _, _ = self._run_with_settings({
            "statusLine": {"type": "command",
                           "command": '"C:/Program Files/Scripts/claude-status.exe" --theme focus'}
        })
        self.assertEqual(kv["installed"], "true")
        self.assertEqual(kv["theme"], "focus")
        self.assertEqual(code, 0)

    def test_python_dash_m_form(self):
        """`python -m claude_statusline` is the documented fallback in
        the README when the binary isn't on PATH."""
        for python_name in ("python", "python3", "py"):
            kv, code, _, _ = self._run_with_settings({
                "statusLine": {"type": "command",
                               "command": "{} -m claude_statusline".format(python_name)}
            })
            self.assertEqual(kv["installed"], "true",
                "python form '{} -m claude_statusline' should detect as installed".format(python_name))
            self.assertEqual(code, 0)

    def test_uvx_form(self):
        """`uvx claude-status` is a common modern install pattern."""
        kv, code, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": "uvx claude-status --theme nord"}
        })
        self.assertEqual(kv["installed"], "true")
        self.assertEqual(kv["theme"], "nord")
        self.assertEqual(code, 0)

    def test_pipx_run_form(self):
        kv, code, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": "pipx run claude-status"}
        })
        self.assertEqual(kv["installed"], "true")

    def test_lookalike_binary_does_not_match(self):
        """`not-claude-status` is a different program — must NOT match."""
        for fake in ("not-claude-status", "my-claude-status",
                     "fork-of-claude-status", "evil-claude-status"):
            kv, code, _, _ = self._run_with_settings({
                "statusLine": {"type": "command", "command": fake}
            })
            self.assertEqual(kv["installed"], "false",
                "lookalike '{}' must not match claude-status detection".format(fake))
            self.assertEqual(code, 1)

    # ── theme parsing — both arg forms ──────────────────────────────

    def test_theme_equals_form(self):
        """argparse accepts `--theme=nord`; our parser must too."""
        kv, code, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": "claude-status --theme=nord"}
        })
        self.assertEqual(kv["installed"], "true")
        self.assertEqual(kv["theme"], "nord")

    # ── refreshInterval: numeric string + bool guard ────────────────

    def test_refresh_interval_numeric_string(self):
        """Hand-edited settings.json often has refreshInterval as a
        string ('1000'). Coerce via _safe_num."""
        kv, _, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": "claude-status",
                           "refreshInterval": "1000"}
        })
        self.assertEqual(kv["refreshInterval"], "1000")

    def test_refresh_interval_bool_rejected(self):
        """`bool` is an int subclass in Python — the explicit isinstance
        check rejects True/False to avoid emitting refreshInterval=1.
        Pinning this prevents a refactor that drops the guard."""
        kv, _, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": "claude-status",
                           "refreshInterval": True}
        })
        self.assertEqual(kv["refreshInterval"], "")

    def test_refresh_interval_negative_rejected(self):
        kv, _, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": "claude-status",
                           "refreshInterval": -100}
        })
        self.assertEqual(kv["refreshInterval"], "")

    def test_refresh_interval_garbage_string_rejected(self):
        kv, _, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": "claude-status",
                           "refreshInterval": "fast"}
        })
        self.assertEqual(kv["refreshInterval"], "")

    # ── line-count contract: newline injection ──────────────────────

    def test_newline_in_command_does_not_break_line_count(self):
        """A command containing \\n would inject a fake key=value line
        into the output, breaking every parser that relies on the
        documented 8-line contract. Sanitization must convert it to a
        single space."""
        kv, code, stdout_text, _ = self._run_with_settings({
            "statusLine": {"type": "command",
                           "command": "claude-status\nPWNED=evil"}
        })
        # Exactly 8 lines, regardless of injected content.
        self.assertEqual(len(stdout_text.strip().split("\n")), 8,
            "newline in command field broke the 8-line contract")
        # PWNED should NOT appear as a key — it should be folded into
        # the command value (with the newline replaced by space).
        self.assertNotIn("PWNED", kv,
            "newline injection added a fake key to the parsed output")
        self.assertIn("PWNED=evil", kv["command"],
            "the injected text should still be visible as part of command for diagnosis")

    # ── settings_state + exit code 2 ────────────────────────────────

    def test_settings_state_ok_when_normal(self):
        kv, _, _, _ = self._run_with_settings({"statusLine": {"type": "command",
                                                              "command": "claude-status"}})
        self.assertEqual(kv["settings_state"], "ok")

    def test_settings_state_missing_when_no_file(self):
        kv, code, _, _ = self._run_with_settings(None)
        self.assertEqual(kv["settings_state"], "missing")
        self.assertEqual(code, 1)

    def test_settings_state_unreadable_when_corrupt(self):
        """Corrupt settings.json must NOT collapse to installed=false
        with exit 1 — that would let an agent auto-install over
        recoverable user config. settings_state=unreadable + exit 2
        signals 'do not auto-act, surface to user'."""
        kv, code, _, stderr_text = self._run_with_settings(None, corrupt=True)
        self.assertEqual(kv["settings_state"], "unreadable")
        self.assertEqual(code, 2,
            "corrupt settings must exit 2 so agents do not overwrite recoverable config")
        # Diagnostic on stderr — agent's logs need to know why.
        self.assertIn("settings.json", stderr_text)
        # 8 lines on stdout still — contract preserved even on error.
        self.assertEqual(kv["installed"], "false")

    # ── Gemini review fixes: versioned python, last-theme-wins, nulls

    def test_versioned_python_binaries_detected(self):
        """python3.11, python3.12.5, python3, py — all valid python
        binary names in multi-version environments (pyenv, deadsnakes,
        Homebrew). All must detect as installed when followed by
        `-m claude_statusline`."""
        for binary in ("python", "python3", "python3.11", "python3.12.5", "py"):
            kv, code, _, _ = self._run_with_settings({
                "statusLine": {"type": "command",
                               "command": "{} -m claude_statusline".format(binary)}
            })
            self.assertEqual(kv["installed"], "true",
                "binary '{}' should detect as a valid python launcher".format(binary))

    def test_python_lookalike_binaries_rejected(self):
        """The regex must reject names that share the python prefix
        but are different programs entirely. Tightens against the
        broader `startswith('python')` heuristic."""
        for fake in ("pythonista", "python-fork", "python_legacy",
                     "pythonw", "ipython"):
            kv, code, _, _ = self._run_with_settings({
                "statusLine": {"type": "command",
                               "command": "{} -m claude_statusline".format(fake)}
            })
            self.assertEqual(kv["installed"], "false",
                "lookalike '{}' must not match python detection".format(fake))

    def test_theme_last_occurrence_wins(self):
        """When --theme appears multiple times, the LAST one wins —
        matches argparse semantics, which is what the running command
        actually does. Reporting the first would lie to the agent
        about the user's real configured theme."""
        kv, _, _, _ = self._run_with_settings({
            "statusLine": {"type": "command",
                           "command": "claude-status --theme nord --theme focus"}
        })
        self.assertEqual(kv["theme"], "focus",
            "last --theme should win to match argparse precedence")

    def test_theme_last_wins_across_arg_forms(self):
        """Last-wins must work across both `--theme NAME` and
        `--theme=NAME` forms mixed in the same command."""
        kv, _, _, _ = self._run_with_settings({
            "statusLine": {"type": "command",
                           "command": "claude-status --theme=nord --theme focus"}
        })
        self.assertEqual(kv["theme"], "focus")

        kv, _, _, _ = self._run_with_settings({
            "statusLine": {"type": "command",
                           "command": "claude-status --theme nord --theme=focus"}
        })
        self.assertEqual(kv["theme"], "focus")

    def test_null_command_emits_empty_string_not_None(self):
        """A literal `null` in settings.json must NOT be stringified
        to 'None' — that would break parsers expecting empty string
        for absent values per the documented contract."""
        kv, code, _, _ = self._run_with_settings({
            "statusLine": {"type": "command", "command": None}
        })
        self.assertEqual(kv["command"], "",
            "null command should emit empty string, not 'None'")
        # And of course not detected as installed.
        self.assertEqual(kv["installed"], "false")

    def test_null_type_emits_empty_string_not_None(self):
        kv, _, _, _ = self._run_with_settings({
            "statusLine": {"type": None, "command": "claude-status"}
        })
        self.assertEqual(kv["type"], "",
            "null type should emit empty string, not 'None'")

    # ── version field tracks the running module ─────────────────────

    def test_version_field_is_module_version(self):
        """`version=` always reflects the running module __version__,
        not a hardcoded literal that would rot on every release."""
        from claude_statusline import __version__
        kv, _, _, _ = self._run_with_settings({"statusLine": {"type": "command",
                                                              "command": "claude-status"}})
        self.assertEqual(kv["version"], __version__)


# ─── cli.py — setup wizard ──────────────────────────────────────────

class TestSetupWizardUpdated(unittest.TestCase):
    def test_setup_flag_accepted(self):
        """--setup should be recognized."""
        result = subprocess.run(
            [sys.executable, "-m", "claude_statusline", "--setup"],
            capture_output=True, timeout=5,
            input="1\n\n",
            encoding="utf-8", errors="replace",
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("setup wizard", result.stdout)
        # Should show compact theme list, not full renders
        self.assertIn("full detail", result.stdout)
        self.assertIn("focus", result.stdout)

    def test_uninstall_flag_accepted(self):
        """--uninstall should be recognized."""
        result = subprocess.run(
            [sys.executable, "-m", "claude_statusline", "--uninstall"],
            capture_output=True, timeout=5,
            encoding="utf-8", errors="replace",
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        self.assertEqual(result.returncode, 0)

    def test_demo_shows_all_themes(self):
        """Demo should show all 8 themes including focus."""
        result = subprocess.run(
            [sys.executable, "-m", "claude_statusline", "--demo"],
            capture_output=True, timeout=10,
            encoding="utf-8", errors="replace",
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        self.assertEqual(result.returncode, 0)
        for name in ("default", "minimal", "powerline", "nord",
                     "tokyo-night", "gruvbox", "rose-pine", "focus"):
            self.assertIn("{}:".format(name), result.stdout,
                          "Demo missing theme: {}".format(name))


# ─── formatters.py — speed ───────────────────────────────────────────

class TestFmtSpeed(unittest.TestCase):
    def test_normal_speed(self):
        from claude_statusline.formatters import fmt_speed
        result = fmt_speed(10000, 10000)  # 10K tokens in 10s = 1K/s
        self.assertIn("/s", result)
        self.assertIn("1K", result)

    def test_zero_duration(self):
        from claude_statusline.formatters import fmt_speed
        self.assertEqual(fmt_speed(1000, 0), "")

    def test_none_tokens(self):
        from claude_statusline.formatters import fmt_speed
        self.assertEqual(fmt_speed(None, 1000), "")

    def test_none_duration(self):
        from claude_statusline.formatters import fmt_speed
        self.assertEqual(fmt_speed(1000, None), "")


# ─── cli.py — speed section ─────────────────────────────────────────

class TestSpeedSection(unittest.TestCase):
    def test_speed_displayed(self):
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 50000,
                                                 "output_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000,
                     "total_api_duration_ms": 10000},
            "git_branch": "main",
        }
        result = render(data)
        self.assertIn("speed:", result)
        self.assertIn("/s", result)

    def test_speed_hidden_no_api_duration(self):
        data = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        result = render(data)
        self.assertNotIn("speed:", result)


# ─── colors.py — NO_COLOR support ───────────────────────────────────

class TestNoColor(unittest.TestCase):
    def test_colorize_respects_no_color(self):
        from claude_statusline import colors
        orig = colors._NO_COLOR
        colors._NO_COLOR = True
        try:
            result = colors.colorize("hello", colors.GREEN)
            self.assertEqual(result, "hello")
            self.assertNotIn("\033", result)
        finally:
            colors._NO_COLOR = orig

    def test_colorize_normal_with_color(self):
        from claude_statusline import colors
        orig = colors._NO_COLOR
        colors._NO_COLOR = False
        try:
            result = colors.colorize("hello", colors.GREEN)
            self.assertIn("\033", result)
            self.assertIn("hello", result)
        finally:
            colors._NO_COLOR = orig


# ─── git.py — git state and commit age ──────────────────────────────

class TestGitState(unittest.TestCase):
    def test_returns_string(self):
        from claude_statusline.git import get_git_state
        result = get_git_state()
        self.assertIsInstance(result, str)

    def test_clean_repo_empty(self):
        """Clean repo should return empty string."""
        from claude_statusline.git import get_git_state
        result = get_git_state()
        # We're in a clean repo, should be empty
        self.assertEqual(result, "")


class TestLastCommitAge(unittest.TestCase):
    def test_returns_int_or_none(self):
        from claude_statusline.git import get_last_commit_age_ms
        result = get_last_commit_age_ms()
        # In a git repo, should return an int
        if result is not None:
            self.assertIsInstance(result, int)
            self.assertGreaterEqual(result, 0)


class TestRemoteUrl(unittest.TestCase):
    def test_returns_string(self):
        from claude_statusline.git import get_remote_url
        result = get_remote_url()
        self.assertIsInstance(result, str)


# ─── cli.py — git state section ─────────────────────────────────────

class TestGitStateSection(unittest.TestCase):
    def test_git_state_hidden_when_clean(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_git_state
        cli_mod.get_git_state = lambda: ""
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertNotIn("merge", result)
            self.assertNotIn("rebase", result)
            self.assertNotIn("conflict", result)
        finally:
            cli_mod.get_git_state = orig

    def test_git_state_merge(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_git_state
        cli_mod.get_git_state = lambda: "merge"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("merge", result)
        finally:
            cli_mod.get_git_state = orig

    def test_git_state_conflict(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_git_state
        cli_mod.get_git_state = lambda: "conflict"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("conflict", result)
        finally:
            cli_mod.get_git_state = orig


# ─── cli.py — commit age section ────────────────────────────────────

class TestCommitAgeSection(unittest.TestCase):
    def test_commit_age_displayed(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_last_commit_age_ms
        cli_mod.get_last_commit_age_ms = lambda: 300000  # 5 minutes
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("last:", result)
        finally:
            cli_mod.get_last_commit_age_ms = orig

    def test_commit_age_hidden_when_none(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_last_commit_age_ms
        cli_mod.get_last_commit_age_ms = lambda: None
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertNotIn("last:", result)
        finally:
            cli_mod.get_last_commit_age_ms = orig


# ─── cli.py — OSC 8 links ───────────────────────────────────────────

class TestOSC8Links(unittest.TestCase):
    def test_osc8_disabled_by_default(self):
        """OSC 8 must be OFF by default to avoid breaking Claude Code's
        Ink TUI renderer (#68)."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_clickable_links_enabled
        cli_mod.get_clickable_links_enabled = lambda: False
        try:
            result = cli_mod._osc8_link("https://github.com/test", "branch")
            self.assertEqual(result, "branch")
            self.assertNotIn("\033]8", result)
        finally:
            cli_mod.get_clickable_links_enabled = orig

    def test_osc8_enabled_via_opt_in(self):
        """When user opts in, OSC 8 sequences are emitted."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_clickable_links_enabled
        cli_mod.get_clickable_links_enabled = lambda: True
        try:
            result = cli_mod._osc8_link("https://github.com/test", "branch")
            self.assertIn("branch", result)
            self.assertIn("\033]8;;", result)
            self.assertIn("https://github.com/test", result)
        finally:
            cli_mod.get_clickable_links_enabled = orig

    def test_osc8_link_no_url(self):
        from claude_statusline.cli import _osc8_link
        result = _osc8_link("", "branch")
        self.assertEqual(result, "branch")

    def test_osc8_link_none_url(self):
        from claude_statusline.cli import _osc8_link
        result = _osc8_link(None, "branch")
        self.assertEqual(result, "branch")

    def test_opt_in_does_not_override_no_color(self):
        """NO_COLOR must win over clickable_links=true."""
        from claude_statusline import colors as _cm
        import claude_statusline.cli as cli_mod
        orig_nc = _cm._NO_COLOR
        orig_cl = cli_mod.get_clickable_links_enabled
        _cm._NO_COLOR = True
        cli_mod.get_clickable_links_enabled = lambda: True
        try:
            result = cli_mod._osc8_link("https://github.com/test", "branch")
            self.assertEqual(result, "branch")
            self.assertNotIn("\033", result)
        finally:
            _cm._NO_COLOR = orig_nc
            cli_mod.get_clickable_links_enabled = orig_cl


# ─── sessions.py — clickable_links config parsing (#68 regression guard) ──

class TestClickableLinksConfigParsing(unittest.TestCase):
    """Exercise the real _read_status_config() path for `clickable_links`.

    These tests hit the JSON parser directly rather than mocking
    `get_clickable_links_enabled`, so a regression in parsing logic
    (e.g., swapping `bool(...)` for `is True`, or losing the default)
    would silently re-enable OSC 8 and reintroduce #68. This is the
    strongest guard against the bug coming back.
    """

    def _with_config(self, config_value, assertion):
        """Helper: write config JSON, point _CLAUDE_DIR at it, run assertion."""
        from claude_statusline.sessions import (
            _cache_path,
            get_clickable_links_enabled,
        )
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = os.path.join(tmpdir, "claude-status-budget.json")
            if config_value is not None:
                with open(config_file, "w") as f:
                    if config_value == "__CORRUPT__":
                        f.write("{not valid json,,")
                    else:
                        json.dump(config_value, f)

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("status_config"))
            except OSError:
                pass
            try:
                result = get_clickable_links_enabled()
                assertion(result)
            finally:
                sessions_mod._CLAUDE_DIR = orig
                try:
                    os.unlink(_cache_path("status_config"))
                except OSError:
                    pass

    def test_default_is_false_when_config_missing(self):
        """Missing config file → False (default)."""
        self._with_config(None, lambda r: self.assertFalse(r))

    def test_default_is_false_when_key_absent(self):
        """Config present but `clickable_links` key missing → False."""
        self._with_config(
            {"daily_budget_usd": 10.0},
            lambda r: self.assertFalse(r),
        )

    def test_true_when_explicitly_enabled(self):
        """`clickable_links: true` → True."""
        self._with_config(
            {"clickable_links": True},
            lambda r: self.assertTrue(r),
        )

    def test_false_when_explicitly_disabled(self):
        """`clickable_links: false` → False."""
        self._with_config(
            {"clickable_links": False},
            lambda r: self.assertFalse(r),
        )

    def test_null_value_is_false(self):
        """`clickable_links: null` → False."""
        self._with_config(
            {"clickable_links": None},
            lambda r: self.assertFalse(r),
        )

    def test_corrupt_config_is_false(self):
        """Corrupted JSON → False (graceful degradation)."""
        self._with_config(
            "__CORRUPT__",
            lambda r: self.assertFalse(r),
        )

    def test_non_dict_top_level_is_false(self):
        """Top-level JSON list (not a dict) → False (no AttributeError)."""
        # data.get(...) would raise AttributeError on a list.
        # _read_status_config must catch it and fall through to defaults.
        self._with_config(
            [1, 2, 3],
            lambda r: self.assertFalse(r),
        )

    def test_null_top_level_is_false(self):
        """Top-level JSON null → False (no AttributeError)."""
        self._with_config(
            None,  # this is "write nothing", but we want literal JSON null
            lambda r: self.assertFalse(r),
        )
        # The helper skips file creation on None; this still passes via
        # the missing-file path. Add an explicit literal-null case below
        # that writes a file containing the JSON token `null`.

    def test_literal_null_in_file_is_false(self):
        """File contains literal JSON `null` → False (no AttributeError)."""
        from claude_statusline.sessions import (
            _cache_path,
            get_clickable_links_enabled,
        )
        import claude_statusline.sessions as sessions_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = os.path.join(tmpdir, "claude-status-budget.json")
            with open(config_file, "w") as f:
                f.write("null")

            orig = sessions_mod._CLAUDE_DIR
            sessions_mod._CLAUDE_DIR = tmpdir
            try:
                os.unlink(_cache_path("status_config"))
            except OSError:
                pass
            try:
                result = get_clickable_links_enabled()
                self.assertFalse(result)
            finally:
                sessions_mod._CLAUDE_DIR = orig
                try:
                    os.unlink(_cache_path("status_config"))
                except OSError:
                    pass


# ─── cli.py — Line 2 has no OSC 8 by default (end-to-end #68 guard) ──

class TestLine2NoOSC8ByDefault(unittest.TestCase):
    """End-to-end guard: the rendered output must contain no OSC 8
    escape sequences when `clickable_links` is at its default (off).
    This is the actual regression that #68 fixes — a future change
    that reintroduces OSC 8 at any call site would be caught here.
    """

    def test_no_osc8_in_rendered_output_by_default(self):
        import claude_statusline.cli as cli_mod
        orig_clickable = cli_mod.get_clickable_links_enabled
        orig_remote = cli_mod.get_remote_url
        cli_mod.get_clickable_links_enabled = lambda: False
        cli_mod.get_remote_url = lambda: "https://github.com/example/repo"
        try:
            data = {
                "context_window": {
                    "used_percentage": 30,
                    "current_usage": {"input_tokens": 5000},
                },
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            # OSC 8 sequences start with ESC ] 8
            self.assertNotIn("\033]8", result)
        finally:
            cli_mod.get_clickable_links_enabled = orig_clickable
            cli_mod.get_remote_url = orig_remote


# ─── cli.py — Line 2 width fits at 120-col terminals (#70 guard) ──

class TestLine2FitsAt120Cols(unittest.TestCase):
    """End-to-end regression guard for #70.

    With heavy session data (rate limits, multi-hour duration, +5K lines,
    session name, CC version, etc.), Line 2 must fit within a 120-column
    terminal. The fix raises the full-layout threshold so that 120 cols
    falls into the compact range, where the heaviest sections are dropped.

    A future change that adds new line2 sections to the full layout
    without also adding them to _COMPACT_DROP would cause this test to
    fail, catching the regression immediately.
    """

    def setUp(self):
        # Stub git helpers at the cli_mod level so tests don't depend on
        # ambient repo state (which would make width measurements
        # non-deterministic across hosts).
        import claude_statusline.cli as cli_mod
        self._cli_mod = cli_mod
        self._orig = {
            "get_remote_url": cli_mod.get_remote_url,
            "get_git_state": cli_mod.get_git_state,
            "get_last_commit_age_ms": cli_mod.get_last_commit_age_ms,
            "get_git_extras": cli_mod.get_git_extras,
            "get_clickable_links_enabled": cli_mod.get_clickable_links_enabled,
        }
        cli_mod.get_remote_url = lambda: "https://github.com/example/repo"
        cli_mod.get_git_state = lambda: ""
        cli_mod.get_last_commit_age_ms = lambda: 300000  # 5m
        cli_mod.get_git_extras = lambda: {"stash": 2, "ahead": 2, "behind": 1}
        cli_mod.get_clickable_links_enabled = lambda: False

    def tearDown(self):
        for name, fn in self._orig.items():
            setattr(self._cli_mod, name, fn)

    def _heavy_payload(self):
        return {
            "context_window": {
                "used_percentage": 5,
                "context_window_size": 1_000_000,
                "current_usage": {
                    "input_tokens": 6,
                    "output_tokens": 301,
                },
            },
            "cost": {
                "total_cost_usd": 250,
                "total_duration_ms": 60_223_000,       # 16h43m
                "total_api_duration_ms": 11_100_000,   # 3h05m
                "total_lines_added": 5245,
                "total_lines_removed": 510,
            },
            "rate_limits": {
                "five_hour": {"used_percentage": 46, "resets_at": 1_776_000_000},
                "seven_day": {"used_percentage": 68, "resets_at": 1_776_500_000},
            },
            # Realistic project path + branch so the project_name/branch
            # section reflects real-world width (Gemini flagged missing
            # workspace on #71). "myapp/feat/responsive-statusline" is
            # representative of a typical feature branch string.
            "workspace": {
                "project_dir": "/home/user/projects/myapp",
                "current_dir": "/home/user/projects/myapp",
            },
            "cwd": "/home/user/projects/myapp",
            "git_branch": "feat/responsive-statusline",
            "session_name": "refactor auth middleware",
            "version": "2.1.101",
        }

    def _visible_width(self, line):
        # Strip SGR color escapes.
        stripped = re.sub(r"\x1b\[[0-9;]*m", "", line)
        # Also strip OSC 8 hyperlink sequences (ESC ] 8 ; ; URL ST TEXT ESC ] 8 ; ; ST)
        # so this helper stays correct even if clickable_links is ever
        # accidentally enabled in a test. ST terminator is ESC \ or BEL.
        stripped = re.sub(r"\x1b\]8;;[^\x07\x1b]*(?:\x07|\x1b\\)", "", stripped)
        return len(stripped)

    def _render_at_width(self, cols):
        # COLUMNS env var is honored by shutil.get_terminal_size().
        old_cols = os.environ.get("COLUMNS")
        os.environ["COLUMNS"] = str(cols)
        try:
            return render(self._heavy_payload())
        finally:
            if old_cols is None:
                del os.environ["COLUMNS"]
            else:
                os.environ["COLUMNS"] = old_cols

    def test_line2_fits_at_full_threshold(self):
        """At the full-layout threshold (160 cols), the full layout is
        enabled — Line 2 must fit within the terminal width. This guards
        the buffer above the measured heavy-payload width (~152 chars).
        """
        from claude_statusline.cli import _FULL_LAYOUT_MIN_COLS
        result = self._render_at_width(_FULL_LAYOUT_MIN_COLS)
        lines = result.split("\n")
        self.assertEqual(len(lines), 2, "expected 2 lines at full layout")
        line2_visible = self._visible_width(lines[1])
        self.assertLessEqual(
            line2_visible, _FULL_LAYOUT_MIN_COLS,
            "Line 2 is {} visible chars at {}-col full-layout threshold — "
            "heavy payload overflows the buffer above the measured ~152. "
            "Raise _FULL_LAYOUT_MIN_COLS or trim full-layout sections.".format(
                line2_visible, _FULL_LAYOUT_MIN_COLS
            )
        )

    def test_line2_fits_at_120_cols(self):
        """Heavy payload at 120 cols — Line 2 must not exceed 120 visible chars."""
        result = self._render_at_width(120)
        lines = result.split("\n")
        self.assertEqual(len(lines), 2, "expected 2 lines")
        line2_visible = self._visible_width(lines[1])
        self.assertLessEqual(
            line2_visible, 120,
            "Line 2 is {} visible chars at 120-col terminal — Ink will "
            "truncate it. Either move sections off Line 2's full layout "
            "or add them to _COMPACT_DROP.".format(line2_visible)
        )

    def test_line2_fits_at_100_cols(self):
        """Heavy payload at 100 cols — Line 2 must not exceed 100 visible chars."""
        result = self._render_at_width(100)
        lines = result.split("\n")
        self.assertEqual(len(lines), 2, "expected 2 lines")
        line2_visible = self._visible_width(lines[1])
        self.assertLessEqual(
            line2_visible, 100,
            "Line 2 is {} visible chars at 100-col terminal".format(
                line2_visible
            )
        )

    def test_line2_fits_at_80_cols(self):
        """Heavy payload at 80 cols (narrow layout) — every emitted line must fit.

        Narrow layout drops most sections; Line 2 may be short or empty
        but the output must always contain at least one line and every
        line's visible width must be <= 80.
        """
        result = self._render_at_width(80)
        lines = result.split("\n")
        self.assertGreaterEqual(
            len(lines), 1, "render() returned no lines at 80 cols"
        )
        for idx, line in enumerate(lines):
            visible = self._visible_width(line)
            self.assertLessEqual(
                visible, 80,
                "Line {} is {} visible chars at 80-col terminal".format(
                    idx + 1, visible
                )
            )

    def test_line2_fits_in_compact_band_with_vim_and_long_agent(self):
        """The compact band (100-149 cols) must fit even with the heaviest
        line2 sections — vim NORMAL active, long agent name, long branch.

        This is the silent-failure mode that broke v0.5.4 before
        _FIT_DROP_PRIORITY was introduced: the coarse pre-filter kept
        burn/duration/lines/branch/vim/agent/model on Line 2, none of
        which were in _COMPACT_DROP, so the precise stage was a no-op
        and Line 2 silently overflowed at 110 cols. Pinning all three
        widths (100/110/130) guarantees the precise stage covers them.
        """
        payload = self._heavy_payload()
        payload["vim"] = {"mode": "NORMAL"}
        payload["agent"] = {"name": "long-agent-name-stress-test"}
        for cols in (100, 110, 130):
            old = os.environ.get("COLUMNS")
            os.environ["COLUMNS"] = str(cols)
            try:
                result = render(payload)
            finally:
                if old is None:
                    del os.environ["COLUMNS"]
                else:
                    os.environ["COLUMNS"] = old
            for idx, line in enumerate(result.split("\n")):
                w = self._visible_width(line)
                self.assertLessEqual(
                    w, cols,
                    "Line {} is {} visible chars at {}-col terminal "
                    "(heavy + vim + long agent). _FIT_DROP_PRIORITY may "
                    "be missing a section name from line2.".format(
                        idx + 1, w, cols
                    )
                )

    def test_rate_limits_recovered_at_180_cols(self):
        """At 180 cols the precise stage should KEEP rate_limits visible
        even though it lives in _COMPACT_DROP — because at 180 cols there
        is room for it.

        This pins the recovery property: someone who reverts the precise
        stage or re-raises _FULL_LAYOUT_MIN_COLS to 230 would silently
        lose this section, and the upper-bound width tests above would
        not notice (overflow tests pass either way).
        """
        result = self._render_at_width(180)
        # Rate-limit indicators look like "5h:46%" / "7d:68%" in the
        # output (with ANSI color around them). Strip ANSI for the
        # substring check.
        plain = re.sub(r"\x1b\[[0-9;]*m", "", result)
        self.assertIn(
            "5h:", plain,
            "rate_limits section was dropped at 180 cols even though "
            "it should fit — precise stage may have over-dropped or "
            "been disabled."
        )

    def test_rate_limits_dropped_at_120_cols(self):
        """At 120 cols there is no room for rate_limits — the precise
        stage must drop it. Inverse pin to test_rate_limits_recovered:
        if the drop priority is broken or _COMPACT_DROP is bypassed,
        rate_limits would leak through and overflow Line 2.
        """
        result = self._render_at_width(120)
        plain = re.sub(r"\x1b\[[0-9;]*m", "", result)
        self.assertNotIn(
            "5h:", plain,
            "rate_limits section was kept at 120 cols — would push "
            "Line 2 past terminal width and trigger Ink truncation."
        )


# ─── sessions.py — disabled sections ────────────────────────────────

class TestDisabledSections(unittest.TestCase):
    def test_disabled_sections_filters(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_disabled_sections
        cli_mod.get_disabled_sections = lambda: ["cache", "latency"]
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000,
                                                     "cache_read_input_tokens": 3000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000,
                         "total_api_duration_ms": 5000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertNotIn("cache:", result)
            self.assertNotIn("api:", result)
        finally:
            cli_mod.get_disabled_sections = orig

    def test_no_disabled_sections(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_disabled_sections
        cli_mod.get_disabled_sections = lambda: []
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000,
                                                     "cache_read_input_tokens": 3000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("cache:", result)
        finally:
            cli_mod.get_disabled_sections = orig


# ─── bar.py — bar styles ────────────────────────────────────────────

class TestBarStyles(unittest.TestCase):
    def test_default_style(self):
        from claude_statusline.bar import BAR_STYLES
        self.assertIn("default", BAR_STYLES)
        self.assertIn("filled", BAR_STYLES["default"])

    def test_all_styles_exist(self):
        from claude_statusline.bar import BAR_STYLES
        for name in ("default", "dots", "blocks", "thin"):
            self.assertIn(name, BAR_STYLES, "Missing bar style: {}".format(name))

    def test_bar_style_in_theme(self):
        """bar_style key in theme should resolve to style chars."""
        bar = render_bar(50, 20, {"bar_style": "dots"})
        self.assertIn("[", bar)
        self.assertTrue(len(bar) > 0)

    def test_explicit_chars_override_style(self):
        """Explicit bar_filled should override bar_style."""
        bar = render_bar(50, 20, {
            "bar_style": "dots",
            "bar_filled": "#",
        })
        self.assertIn("#", bar)


# ─── Additional edge case tests ─────────────────────────────────────

class TestOSC8NoColor(unittest.TestCase):
    def test_osc8_suppressed_with_no_color(self):
        """OSC 8 links should be plain text when NO_COLOR is set."""
        from claude_statusline import colors as _cm
        from claude_statusline.cli import _osc8_link
        orig = _cm._NO_COLOR
        _cm._NO_COLOR = True
        try:
            result = _osc8_link("https://example.com", "branch")
            self.assertEqual(result, "branch")
            self.assertNotIn("\033", result)
        finally:
            _cm._NO_COLOR = orig


class TestFmtSpeedNegative(unittest.TestCase):
    def test_negative_duration(self):
        from claude_statusline.formatters import fmt_speed
        self.assertEqual(fmt_speed(1000, -500), "")


class TestBarStyleUnknown(unittest.TestCase):
    def test_unknown_style_uses_default(self):
        """Unknown bar_style should fall back to default chars."""
        bar = render_bar(50, 20, {"bar_style": "nonexistent"})
        self.assertIn("[", bar)
        self.assertTrue(len(bar) > 0)


class TestGitStateRebase(unittest.TestCase):
    def test_rebase_renders(self):
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_git_state
        cli_mod.get_git_state = lambda: "rebase"
        try:
            data = {
                "context_window": {"used_percentage": 30,
                                   "current_usage": {"input_tokens": 5000}},
                "cost": {"total_cost_usd": 0.50, "total_duration_ms": 60000},
                "git_branch": "main",
            }
            result = render(data)
            self.assertIn("rebase", result)
        finally:
            cli_mod.get_git_state = orig


# ─── cli.py — _detect_terminal_width fallback chain (#79) ──────────

class TestDetectTerminalWidth(unittest.TestCase):
    """Pin the fallback order of _detect_terminal_width().

    Claude Code's statusLine subprocess hides the real terminal width
    (no TTY, no COLUMNS env), so naive shutil returns the fallback.
    The function tries 7 signals in order and returns the first
    plausible value. These tests exercise each signal independently
    and pin the order so a refactor can't silently demote a more-
    reliable source.
    """

    def setUp(self):
        # Always start from a clean slate: clear COLUMNS so step 2/3
        # don't accidentally win in tests checking later steps.
        self._old_cols = os.environ.pop("COLUMNS", None)
        self._old_lines = os.environ.pop("LINES", None)

    def tearDown(self):
        if self._old_cols is not None:
            os.environ["COLUMNS"] = self._old_cols
        if self._old_lines is not None:
            os.environ["LINES"] = self._old_lines

    # --- Step 1: stdin terminal.columns -------------------------------

    def test_stdin_terminal_columns_wins(self):
        """When data['terminal']['columns'] is present and plausible,
        it wins over every other signal — even COLUMNS env."""
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "200"
        result = _detect_terminal_width({"terminal": {"columns": 165}})
        self.assertEqual(result, 165)

    def test_stdin_terminal_columns_string_coerced(self):
        """Coerce numeric strings via _safe_num so JSON serializers
        that stringify integers (rare but real) still work."""
        from claude_statusline.cli import _detect_terminal_width
        result = _detect_terminal_width({"terminal": {"columns": "165"}})
        self.assertEqual(result, 165)

    def test_stdin_terminal_columns_implausible_rejected(self):
        """Out-of-range values fall through to the next signal —
        guards against an upstream bug returning 0 or 99999."""
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "150"
        result = _detect_terminal_width({"terminal": {"columns": 0}})
        self.assertEqual(result, 150, "implausible 0 should fall through to COLUMNS")
        result = _detect_terminal_width({"terminal": {"columns": 999999}})
        self.assertEqual(result, 150, "implausible 999999 should fall through to COLUMNS")

    def test_stdin_terminal_not_dict_falls_through(self):
        """data['terminal'] being a string/list/None must not crash —
        just fall through. isinstance guard."""
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "150"
        for bad in ("string", [], None, 42):
            result = _detect_terminal_width({"terminal": bad})
            self.assertEqual(result, 150,
                "data['terminal']={!r} should fall through cleanly".format(bad))

    def test_data_none_falls_through(self):
        """No data argument is the legitimate cmd_doctor case — must
        not crash; falls through to env / OS signals."""
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "150"
        result = _detect_terminal_width(None)
        self.assertEqual(result, 150)

    # --- Step 2: COLUMNS env var --------------------------------------

    def test_columns_env_var_wins_when_no_stdin_signal(self):
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "200"
        result = _detect_terminal_width({})
        self.assertEqual(result, 200)

    def test_columns_env_garbage_falls_through(self):
        """Non-numeric COLUMNS must not crash."""
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "wide"
        # Falls through; result depends on host env, but must be int
        # in plausible range and not raise.
        result = _detect_terminal_width({})
        self.assertIsInstance(result, int)
        self.assertGreaterEqual(result, 20)

    def test_columns_env_negative_falls_through(self):
        """Negative COLUMNS (some misconfigured shells) is rejected."""
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "-5"
        result = _detect_terminal_width({})
        # Falls through, doesn't return -5
        self.assertGreaterEqual(result, 20)

    # --- Bounds and clamping ------------------------------------------

    def test_stdin_terminal_columns_lower_bound(self):
        """20 is the minimum plausible width — anything below falls
        through. 20 itself is accepted."""
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "150"
        result = _detect_terminal_width({"terminal": {"columns": 20}})
        self.assertEqual(result, 20)
        result = _detect_terminal_width({"terminal": {"columns": 19}})
        self.assertEqual(result, 150, "below-min should fall through")

    def test_stdin_terminal_columns_upper_bound(self):
        """4000 is the max — covers ultrawide / 8K / multi-monitor
        tmux setups. Anything above falls through."""
        from claude_statusline.cli import _detect_terminal_width
        os.environ["COLUMNS"] = "150"
        result = _detect_terminal_width({"terminal": {"columns": 4000}})
        self.assertEqual(result, 4000)
        result = _detect_terminal_width({"terminal": {"columns": 4001}})
        self.assertEqual(result, 150, "above-max should fall through")

    def test_stdin_terminal_columns_2000_is_accepted(self):
        """An 8K display in tmux can legitimately reach ~1280 cols;
        side-by-side multi-monitor setups can exceed 2000. 2000 must
        be inside the plausible range, not silently dropped to the
        compact fallback."""
        from claude_statusline.cli import _detect_terminal_width
        result = _detect_terminal_width({"terminal": {"columns": 2000}})
        self.assertEqual(result, 2000)

    # --- Final fallback path ------------------------------------------

    def test_returns_int_in_plausible_range(self):
        """Even with zero usable signals, we must return an integer
        in the documented plausible range — never None, never a float,
        never a crash."""
        from claude_statusline.cli import (
            _detect_terminal_width,
            _TERM_WIDTH_MIN,
            _TERM_WIDTH_MAX,
        )
        # Even when nothing is set, we get something usable
        result = _detect_terminal_width({})
        self.assertIsInstance(result, int)
        self.assertGreaterEqual(result, _TERM_WIDTH_MIN)
        self.assertLessEqual(result, _TERM_WIDTH_MAX)


class TestRenderUsesDetectedWidth(unittest.TestCase):
    """End-to-end: render() must consume data['terminal']['columns']
    when present, exposing more sections at wide terminals where the
    naive `shutil.get_terminal_size` fallback would have hidden them.
    This is the user-facing fix — regression-grade test guards it."""

    def test_render_at_165_cols_via_stdin_shows_more_sections(self):
        """The actual user scenario from screenshot at PR #79: a 165-
        col terminal that previously showed only ~5 sections on Line 2
        now shows ~10+ because the precise stage has the real width."""
        # Stub git helpers so this test is deterministic across hosts.
        import claude_statusline.cli as cli_mod
        orig = {
            "get_remote_url": cli_mod.get_remote_url,
            "get_git_state": cli_mod.get_git_state,
            "get_last_commit_age_ms": cli_mod.get_last_commit_age_ms,
            "get_git_extras": cli_mod.get_git_extras,
            "get_session_tool_count": cli_mod.get_session_tool_count,
            "get_today_session_count": cli_mod.get_today_session_count,
            "get_effort_level": cli_mod.get_effort_level,
        }
        cli_mod.get_remote_url = lambda: ""
        cli_mod.get_git_state = lambda: ""
        cli_mod.get_last_commit_age_ms = lambda: 3600000  # 1h
        cli_mod.get_git_extras = lambda: {}
        cli_mod.get_session_tool_count = lambda sid: 0
        cli_mod.get_today_session_count = lambda: 1
        cli_mod.get_effort_level = lambda: "xhigh"
        try:
            data = {
                "context_window": {"used_percentage": 18,
                                   "context_window_size": 1_000_000,
                                   "current_usage": {"input_tokens": 1, "output_tokens": 242}},
                "cost": {"total_cost_usd": 879, "total_duration_ms": 196_080_000,
                         "total_lines_added": 18683, "total_lines_removed": 1628},
                "git_branch": "main",
                "model": {"display_name": "Opus 4.7 (1M context)"},
                "terminal": {"columns": 165},
            }
            out = render(data)
            from claude_statusline.cli import _visible_width
            lines = out.split("\n")
            # Line 2 must fit the 165-col budget…
            line2_width = _visible_width(lines[1])
            self.assertLessEqual(line2_width, 165,
                "Line 2 width {} exceeds 165 — fit logic broken".format(line2_width))
            # …and use significantly more of it than the ~83 chars the
            # naive fallback would have produced.
            self.assertGreater(line2_width, 100,
                "Line 2 width {} is too small — terminal.columns from "
                "stdin was probably not consumed".format(line2_width))
            # Specific recovered sections that proved the bug originally:
            self.assertIn("(1000K)", out, "context_size should appear at 165 cols")
            self.assertIn("effort:xhigh", out, "effort should appear at 165 cols")
        finally:
            for name, fn in orig.items():
                setattr(cli_mod, name, fn)


# ─── cli.py — rate_limits epoch-timestamp guard (#79 / upstream #52326) ──

class TestRateLimitsEpochTimestampGuard(unittest.TestCase):
    """Anthropic's claude-code#52326: on a fresh 5h or 7d window with
    no usage data yet, used_percentage returns the resets_at epoch
    timestamp (~1.7e9) instead of 0/null. Without a guard our
    downstream clamp(0,100) silently turns it into a false
    `5h:100% (red)` alarm. The guard treats anything > 100 as
    'no data yet' and drops to None so the section is hidden."""

    def _data(self, five_h_pct=None, seven_d_pct=None):
        return {
            "context_window": {"used_percentage": 20,
                               "current_usage": {"input_tokens": 1000}},
            "cost": {"total_cost_usd": 0.5, "total_duration_ms": 60000},
            "git_branch": "main",
            "rate_limits": {
                "five_hour": {
                    "used_percentage": five_h_pct,
                    "resets_at": 1_776_950_400,
                },
                "seven_day": {
                    "used_percentage": seven_d_pct,
                    "resets_at": 1_777_500_000,
                },
            },
        }

    def test_epoch_timestamp_in_5h_used_percentage_is_hidden(self):
        """5h section must NOT render when upstream returns the
        timestamp value. Pre-fix, this rendered as '5h:100%' in red."""
        from claude_statusline.cli import _normalize
        n = _normalize(self._data(five_h_pct=1_776_950_400, seven_d_pct=18))
        self.assertIsNone(n["rate_limit_5h_pct"],
            "5h epoch-timestamp value must drop to None")
        self.assertEqual(n["rate_limit_7d_pct"], 18.0,
            "legitimate 7d value must still pass through unchanged")

    def test_epoch_timestamp_in_7d_used_percentage_is_hidden(self):
        from claude_statusline.cli import _normalize
        n = _normalize(self._data(five_h_pct=42, seven_d_pct=1_777_500_000))
        self.assertEqual(n["rate_limit_5h_pct"], 42.0)
        self.assertIsNone(n["rate_limit_7d_pct"])

    def test_legitimate_values_pass_through_unchanged(self):
        from claude_statusline.cli import _normalize
        n = _normalize(self._data(five_h_pct=34, seven_d_pct=68))
        self.assertEqual(n["rate_limit_5h_pct"], 34.0)
        self.assertEqual(n["rate_limit_7d_pct"], 68.0)

    def test_boundary_value_100_passes_through(self):
        """Exactly 100% IS a legitimate used_percentage (truly maxed
        out) — the guard only triggers at the epoch-timestamp pattern
        (>= 1e6). Pin the boundary."""
        from claude_statusline.cli import _normalize
        n = _normalize(self._data(five_h_pct=100, seven_d_pct=100))
        self.assertEqual(n["rate_limit_5h_pct"], 100.0)
        self.assertEqual(n["rate_limit_7d_pct"], 100.0)

    def test_value_modestly_above_100_passes_through(self):
        """Values 101-999999 are NOT the upstream bug pattern (which is
        always epoch seconds ~1.7e9). They could be a future Anthropic
        'overage' indicator above 100%, so we let them through and rely
        on the renderer's existing clamp(0, 100) for safe display.
        Pre-emptively hiding these would silently swallow real signals.
        """
        from claude_statusline.cli import _normalize
        n = _normalize(self._data(five_h_pct=105, seven_d_pct=999999))
        self.assertEqual(n["rate_limit_5h_pct"], 105.0,
            "value just above 100 should flow through to the renderer's clamp")
        self.assertEqual(n["rate_limit_7d_pct"], 999999.0,
            "value just below 1e6 should still flow through (not bug pattern)")

    def test_epoch_pattern_at_threshold_is_dropped(self):
        """The threshold is 1e6: any value at or above that is treated
        as the upstream epoch-timestamp bug pattern. Pins the boundary
        explicitly."""
        from claude_statusline.cli import _normalize
        n = _normalize(self._data(five_h_pct=1_000_000, seven_d_pct=1_000_001))
        self.assertIsNone(n["rate_limit_5h_pct"])
        self.assertIsNone(n["rate_limit_7d_pct"])

    def test_renders_no_5h_section_when_upstream_bug_present(self):
        """End-to-end: rate_limits section in render() must hide the
        bugged value, not render it in red. This is the user-visible
        contract — 'no false 5h:100% alarm on fresh sessions'."""
        result = render(self._data(five_h_pct=1_776_950_400, seven_d_pct=68))
        # Must NOT contain a percentage in the billions
        self.assertNotIn("5h:", result,
            "5h section must be hidden when upstream returns epoch timestamp")
        # 7d section still renders normally
        self.assertIn("7d:68", result)


# ─── cli.py — effort.level from JSON stdin (#81, Claude Code v2.1.119+) ──

class TestEffortLevelFromStdin(unittest.TestCase):
    """Pin the new stdin-as-source behavior for effort level.

    Claude Code v2.1.119 added `effort.level` to the statusline JSON
    stdin payload. v0.5.8 prefers this over the settings.json file
    read so users see effort changes within one render cycle of
    `/effort xhigh` instead of waiting up to 30s for the cache to
    expire. The settings.json read remains as a fallback for older
    Claude Code versions.
    """

    def _data(self, **extras):
        base = {
            "context_window": {"used_percentage": 30,
                               "current_usage": {"input_tokens": 5000}},
            "cost": {"total_cost_usd": 0.5, "total_duration_ms": 60000},
            "git_branch": "main",
        }
        base.update(extras)
        return base

    # ── _normalize behavior ─────────────────────────────────────────

    def test_normalize_extracts_effort_level_from_stdin(self):
        """Valid effort.level in stdin populates n['effort_level']."""
        from claude_statusline.cli import _normalize
        n = _normalize(self._data(effort={"level": "xhigh"}))
        self.assertEqual(n["effort_level"], "xhigh")

    def test_normalize_accepts_all_valid_levels_from_stdin(self):
        """Each level in _VALID_EFFORT_LEVELS (except 'medium') is
        passed through verbatim. 'medium' is normalized to the empty-
        string sentinel that signals "explicitly hide" to the renderer
        — this skips the settings.json fallback so the user sees the
        section disappear within one render cycle of `/effort medium`
        instead of lagging up to 30s on a stale cache value.
        """
        from claude_statusline.cli import _normalize
        for level in ("low", "high", "xhigh", "max"):
            n = _normalize(self._data(effort={"level": level}))
            self.assertEqual(n["effort_level"], level,
                "stdin effort.level={!r} should pass through".format(level))
        # medium is normalized to "" (sentinel for "explicitly hide,
        # skip fallback") — NOT None (which would mean "no signal,
        # fall back").
        n = _normalize(self._data(effort={"level": "medium"}))
        self.assertEqual(n["effort_level"], "",
            "stdin effort.level='medium' should normalize to '' "
            "sentinel, NOT None — None would trigger the fallback "
            "to settings.json and risk showing a stale value")

    def test_normalize_case_insensitive(self):
        """Mixed-case effort levels in stdin normalize to lowercase
        — matches existing settings.json behavior, prevents a future
        Anthropic schema doc using 'Xhigh' or 'XHIGH' from breaking."""
        from claude_statusline.cli import _normalize
        for variant in ("XHIGH", "Xhigh", "xHigh"):
            n = _normalize(self._data(effort={"level": variant}))
            self.assertEqual(n["effort_level"], "xhigh",
                "stdin effort.level={!r} should normalize to 'xhigh'".format(variant))

    def test_normalize_rejects_unknown_level_from_stdin(self):
        """Unknown effort levels (typos, future variants we don't
        recognize) drop to None so the renderer doesn't display
        garbage. Users on a newer Claude Code than this claude-status
        version will fall back to settings.json — better stale-but-
        valid than fresh-but-garbage."""
        from claude_statusline.cli import _normalize
        n = _normalize(self._data(effort={"level": "ultrathink"}))
        self.assertIsNone(n["effort_level"])

    def test_normalize_rejects_non_string_level(self):
        """effort.level being an int / list / None must not crash."""
        from claude_statusline.cli import _normalize
        for bad in (42, ["xhigh"], None, True, {"level": "nested"}):
            n = _normalize(self._data(effort={"level": bad}))
            self.assertIsNone(n["effort_level"],
                "stdin effort.level={!r} should be rejected".format(bad))

    def test_normalize_rejects_non_dict_effort(self):
        """effort field being a string / list / None — the isinstance
        guard prevents an AttributeError on .get()."""
        from claude_statusline.cli import _normalize
        for bad in ("xhigh", ["xhigh"], None, 42):
            n = _normalize(self._data(effort=bad))
            self.assertIsNone(n["effort_level"],
                "data['effort']={!r} should be rejected cleanly".format(bad))

    def test_normalize_absent_effort_yields_none(self):
        """No effort field in stdin (older Claude Code, demo data) —
        n['effort_level'] is None so the renderer falls back to
        get_effort_level() (settings.json read)."""
        from claude_statusline.cli import _normalize
        n = _normalize(self._data())
        self.assertIsNone(n["effort_level"])

    # ── render() integration: stdin wins over settings.json ────────

    def test_render_prefers_stdin_over_settings_json(self):
        """When stdin has effort.level, the settings.json read should
        be SKIPPED entirely. Pin via a stub that would error if called."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        # Make get_effort_level loud so we know if it was called.
        called = []
        def loud_settings_read():
            called.append(True)
            return "low"  # would render as effort:low if used
        cli_mod.get_effort_level = loud_settings_read
        try:
            data = self._data(effort={"level": "xhigh"})
            result = render(data)
            self.assertIn("effort:xhigh", result,
                "stdin xhigh should be rendered, not the stubbed 'low'")
            self.assertNotIn("effort:low", result,
                "settings.json fallback should not have been consulted")
            self.assertEqual(len(called), 0,
                "get_effort_level() must NOT be called when stdin has effort.level")
        finally:
            cli_mod.get_effort_level = orig

    def test_render_falls_back_to_settings_when_stdin_absent(self):
        """No effort field in stdin → renderer must call
        get_effort_level() to read settings.json. This is the
        backward-compatibility path for older Claude Code versions."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        called = []
        def fake_settings_read():
            called.append(True)
            return "max"
        cli_mod.get_effort_level = fake_settings_read
        try:
            data = self._data()  # NO effort field
            result = render(data)
            self.assertIn("effort:max", result,
                "settings.json fallback should be consulted and rendered")
            self.assertEqual(len(called), 1,
                "get_effort_level() must be called exactly once on the fallback path")
        finally:
            cli_mod.get_effort_level = orig

    def test_render_falls_back_when_stdin_effort_level_invalid(self):
        """Invalid stdin effort.level (e.g. 'ultrathink') → renderer
        falls back to settings.json. Pinning this means a future
        Anthropic schema variant we don't recognize won't blank the
        section if the user has a valid effortLevel in settings.json."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: "high"
        try:
            data = self._data(effort={"level": "ultrathink"})
            result = render(data)
            self.assertIn("effort:high", result,
                "invalid stdin should fall through to settings.json read")
        finally:
            cli_mod.get_effort_level = orig

    def test_render_stdin_medium_hides_section_skipping_fallback(self):
        """Stdin medium = explicit hide. The renderer must NOT fall
        back to get_effort_level() — stdin is fresher than the 30s
        settings.json cache, so honoring stdin's authoritative
        signal beats reading a potentially stale cache value.

        Pinned with a "loud stub" that records whether
        get_effort_level was called. After running `/effort medium`
        in the new client, the user expects the indicator to vanish
        on the next render — not lag up to 30s."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        called = []
        def loud_settings_read():
            called.append(True)
            return "high"  # settings.json has a stale non-medium value
        cli_mod.get_effort_level = loud_settings_read
        try:
            data = self._data(effort={"level": "medium"})
            result = render(data)
            self.assertNotIn("effort:", result,
                "stdin medium should hide section even when settings.json "
                "still has a stale non-medium value")
            self.assertEqual(len(called), 0,
                "get_effort_level() must NOT be called when stdin says "
                "medium — bypassing the stale settings.json cache is the "
                "whole point of honoring the stdin signal")
        finally:
            cli_mod.get_effort_level = orig

    def test_render_stdin_medium_hides_when_settings_also_medium(self):
        """Belt-and-suspenders: stdin medium + settings medium both
        result in the section being hidden. This is the no-staleness
        scenario where both sources agree."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: None  # settings.json is medium → None
        try:
            data = self._data(effort={"level": "medium"})
            result = render(data)
            self.assertNotIn("effort:medium", result)
            self.assertNotIn("effort:", result)
        finally:
            cli_mod.get_effort_level = orig

    def test_render_no_stdin_with_settings_medium(self):
        """No effort field in stdin → renderer calls get_effort_level()
        → if settings.json says medium it returns None → section hides.
        Pins the existing settings.json medium-hidden contract still
        works after the v0.5.8 changes."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        cli_mod.get_effort_level = lambda: None  # settings.json medium → None
        try:
            data = self._data()  # no effort field
            result = render(data)
            self.assertNotIn("effort:", result,
                "no stdin + settings.json medium should hide the section")
        finally:
            cli_mod.get_effort_level = orig

    def test_render_each_valid_level_via_stdin_path(self):
        """Each non-medium level in _VALID_EFFORT_LEVELS renders
        correctly through the stdin path. Without this, a future
        refactor that broke the stdin chain only for non-xhigh values
        (e.g., a typo in _normalize that passes 'xhigh' but drops
        'low'/'high'/'max') would not be caught — the existing
        TestEffortSection tests stub get_effort_level directly and
        bypass _normalize entirely."""
        import claude_statusline.cli as cli_mod
        orig = cli_mod.get_effort_level
        # Stub settings.json to a known-wrong value so we'd notice
        # if the renderer accidentally fell through.
        cli_mod.get_effort_level = lambda: "wrong-value-must-not-appear"
        try:
            for level in ("low", "high", "xhigh", "max"):
                data = self._data(effort={"level": level})
                result = render(data)
                self.assertIn("effort:" + level, result,
                    "stdin level={!r} should render via the stdin path".format(level))
                self.assertNotIn("wrong-value-must-not-appear", result,
                    "stdin level={!r} should not fall through to "
                    "settings.json".format(level))
        finally:
            cli_mod.get_effort_level = orig

    def test_normalize_writes_effort_cache_when_stdin_supplies_value(self):
        """When _normalize extracts a valid effort.level from stdin,
        it MUST mirror the value to the on-disk effort_level cache.

        Why: if the user later switches to an older Claude Code
        client (or any tool that doesn't supply stdin effort), the
        next render falls back to get_effort_level() which reads from
        the cache. Without the mirror-write, the cache could hold a
        stale value from before the user's last `/effort` change —
        rendering the wrong effort with no signal to the user.

        Pins the cache-consistency invariant flagged by the v0.5.8
        silent-failure review.
        """
        import claude_statusline.sessions as sessions_mod
        import claude_statusline.cli as cli_mod
        from claude_statusline.sessions import _read_cache
        with tempfile.TemporaryDirectory() as tmpdir:
            # Patch the cache directory so this test can't pollute
            # the real user-scoped temp cache.
            orig_get = sessions_mod._cache_dir
            sessions_mod._cache_dir = lambda: tmpdir
            try:
                cli_mod._normalize(self._data(effort={"level": "xhigh"}))
                cached = _read_cache("effort_level")
                self.assertIsNotNone(cached,
                    "stdin effort.level should mirror to the cache file")
                self.assertEqual(cached.get("effort"), "xhigh",
                    "cached value should match the stdin level")
            finally:
                sessions_mod._cache_dir = orig_get

    def test_normalize_does_not_write_cache_when_stdin_invalid(self):
        """If stdin effort.level is invalid (unknown level, wrong
        type), _normalize must NOT write to the cache — that would
        propagate the upstream bug to the fallback path.
        """
        import claude_statusline.sessions as sessions_mod
        import claude_statusline.cli as cli_mod
        from claude_statusline.sessions import _cache_path
        with tempfile.TemporaryDirectory() as tmpdir:
            orig_get = sessions_mod._cache_dir
            sessions_mod._cache_dir = lambda: tmpdir
            try:
                cli_mod._normalize(self._data(effort={"level": "ultrathink"}))
                cache_file = _cache_path("effort_level")
                self.assertFalse(os.path.exists(cache_file),
                    "invalid stdin effort.level must not write the cache")
            finally:
                sessions_mod._cache_dir = orig_get

    def test_normalize_skips_cache_write_when_value_unchanged(self):
        """Performance: _normalize runs on every render. If the cache
        already has the same value, skip the atomic write+rename
        (which is much more expensive than a stat+read). Without
        this, an active session with a low refreshInterval would
        burn one disk write per render forever.
        """
        import claude_statusline.sessions as sessions_mod
        import claude_statusline.cli as cli_mod
        from claude_statusline.sessions import _cache_path, _write_cache
        import os
        with tempfile.TemporaryDirectory() as tmpdir:
            orig_get = sessions_mod._cache_dir
            sessions_mod._cache_dir = lambda: tmpdir
            try:
                # Seed the cache with the same value we'll send via stdin.
                _write_cache("effort_level", {"effort": "xhigh"})
                cache_file = _cache_path("effort_level")
                mtime_before = os.path.getmtime(cache_file)
                # Sleep long enough that any rewrite produces a new
                # mtime that's distinguishable from the original.
                # (Filesystem mtime resolution is typically 1ms-1s.)
                time.sleep(0.05)
                # Run _normalize with the SAME value already cached.
                cli_mod._normalize(self._data(effort={"level": "xhigh"}))
                mtime_after = os.path.getmtime(cache_file)
                self.assertEqual(mtime_before, mtime_after,
                    "cache file mtime changed — _normalize must skip the "
                    "write when the cached value is already correct "
                    "(read+compare is cheaper than atomic write+rename)")
            finally:
                sessions_mod._cache_dir = orig_get

    def test_normalize_writes_cache_when_value_changed(self):
        """Inverse pin: when stdin says a different level than what's
        cached, _normalize MUST write the new value (otherwise the
        whole point of the mirror-write is defeated)."""
        import claude_statusline.sessions as sessions_mod
        import claude_statusline.cli as cli_mod
        from claude_statusline.sessions import _read_cache, _write_cache
        with tempfile.TemporaryDirectory() as tmpdir:
            orig_get = sessions_mod._cache_dir
            sessions_mod._cache_dir = lambda: tmpdir
            try:
                _write_cache("effort_level", {"effort": "high"})
                # Stdin disagrees — should overwrite the cache.
                cli_mod._normalize(self._data(effort={"level": "max"}))
                cached = _read_cache("effort_level")
                self.assertEqual(cached.get("effort"), "max",
                    "cache must be overwritten when stdin gives a "
                    "different level than the existing cached value")
            finally:
                sessions_mod._cache_dir = orig_get


class TestClaudeCode2139WidthRegression(unittest.TestCase):
    """Width-detection guards for the Claude Code 2.1.139 regression.

    2.1.139 (2026-05-11 release notes: "hooks now run without terminal
    access") removed every TTY signal the earlier fallback chain
    depended on. Symptoms confirmed by independent statusline authors
    in anthropics/claude-code#22115:

      - COLUMNS env: set to "0" (not unset)
      - /dev/tty:    ENXIO
      - stty size:   fails
      - tput cols:   returns 80 (terminfo default — LIES with a straight face)

    Without these guards we would parse `tput cols == 80` as a real
    reading and render an 80-col layout into a 220-col terminal.
    Tracked at issue #83.
    """

    def setUp(self):
        self._old_cols = os.environ.pop("COLUMNS", None)
        self._old_lines = os.environ.pop("LINES", None)

    def tearDown(self):
        if self._old_cols is not None:
            os.environ["COLUMNS"] = self._old_cols
        if self._old_lines is not None:
            os.environ["LINES"] = self._old_lines

    # --- COLUMNS=0 (distinct from unset) ------------------------------

    def test_columns_env_zero_rejected_distinctly(self):
        """COLUMNS="0" must be rejected and reported as a no-TTY
        signal — not silently treated as "unset" or "garbage." The
        report distinction matters for --doctor diagnostics."""
        from claude_statusline.cli import _detect_terminal_width_report
        os.environ["COLUMNS"] = "0"
        result, report = _detect_terminal_width_report({})
        # Result must NOT be 0 (would be far below _TERM_WIDTH_MIN)
        self.assertGreaterEqual(result, 20)
        # Report must mention 0 explicitly as a no-TTY signal, not
        # collapse it into "unset" or "garbage"
        cols_entries = [s for label, s in report if label == "COLUMNS env"]
        self.assertEqual(len(cols_entries), 1)
        self.assertIn("0", cols_entries[0])
        self.assertNotEqual(cols_entries[0], "unset",
            "COLUMNS=0 must be distinguished from COLUMNS unset")

    def test_columns_env_unset_reported_as_unset(self):
        """COLUMNS unset (the normal case) must report 'unset' — pin
        the report wording so --doctor remains intelligible."""
        from claude_statusline.cli import _detect_terminal_width_report
        os.environ.pop("COLUMNS", None)
        _result, report = _detect_terminal_width_report({})
        cols_entries = [s for label, s in report if label == "COLUMNS env"]
        self.assertEqual(cols_entries, ["unset"])

    # --- tput stub rejection (the headline 2.1.139 fix) ---------------

    def test_tput_stub_80_rejected_when_no_tty_signal(self):
        """When subprocess.run returns tput cols=80 AND no earlier TTY
        probe succeeded, the 80 must be rejected as a likely terminfo
        stub. The chain must fall through to the safe default, not
        return 80."""
        import subprocess as subprocess_mod
        from claude_statusline.cli import (
            _COMPACT_LAYOUT_MIN_COLS,
            _detect_terminal_width_report,
        )

        # Simulate 2.1.139: /dev/tty is reachable (some hosts still
        # have it), stty fails, tput returns 80. We must NOT return 80.
        orig_run = subprocess_mod.run
        orig_open = __builtins__["open"] if isinstance(__builtins__, dict) else open

        def fake_run(cmd, *args, **kwargs):
            if cmd[0] == "stty":
                # Simulate stty failing in the no-controlling-TTY env
                return subprocess_mod.CompletedProcess(cmd, 1, "", "stty: stdin isn't a tty\n")
            if cmd[0] == "tput":
                return subprocess_mod.CompletedProcess(cmd, 0, "80\n", "")
            return orig_run(cmd, *args, **kwargs)

        # Patch open() so /dev/tty appears reachable even on Windows
        # test hosts. We pass through every other path.
        class FakeTTY:
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self): return ""
            def fileno(self): return 0

        def fake_open(path, *args, **kwargs):
            if path == "/dev/tty":
                return FakeTTY()
            return orig_open(path, *args, **kwargs)

        import claude_statusline.cli as cli_mod
        cli_mod.subprocess.run = fake_run
        # Hide every higher-priority signal so we're forced into the
        # stty/tput step where the stub rejection lives.
        os.environ.pop("COLUMNS", None)
        # Patch open at the cli module level so the chain's
        # `open("/dev/tty", "r")` returns our fake.
        cli_mod_open = cli_mod.__builtins__["open"] if isinstance(
            cli_mod.__builtins__, dict) else cli_mod.__builtins__.open
        try:
            if isinstance(cli_mod.__builtins__, dict):
                cli_mod.__builtins__["open"] = fake_open
            else:
                cli_mod.__builtins__.open = fake_open
            result, report = _detect_terminal_width_report({})
        finally:
            cli_mod.subprocess.run = orig_run
            if isinstance(cli_mod.__builtins__, dict):
                cli_mod.__builtins__["open"] = cli_mod_open
            else:
                cli_mod.__builtins__.open = cli_mod_open

        # The fake tput returned 80; we must have rejected it. The
        # final result should be the safe compact fallback, NOT 80.
        self.assertNotEqual(result, 80,
            "tput cols=80 with no earlier TTY signal must be rejected as a "
            "likely terminfo stub (Claude Code 2.1.139 regression)")
        self.assertEqual(result, _COMPACT_LAYOUT_MIN_COLS,
            "should fall through to the safe default when no signal is "
            "trustworthy")

        # The report must explain why we rejected the 80
        tput_entries = [s for label, s in report if label == "tput cols"]
        self.assertTrue(any("stub" in s or "rejected" in s for s in tput_entries),
            "report must explain the rejection so --doctor users see why; "
            "got: {!r}".format(tput_entries))

    def test_tput_value_other_than_stub_not_rejected(self):
        """tput cols=137 must NOT be rejected even when no earlier
        signal succeeded — only the known stub values (80) trip the
        heuristic. Real-but-unusual widths must pass through."""
        from claude_statusline.cli import _TPUT_STUB_VALUES
        self.assertIn(80, _TPUT_STUB_VALUES,
            "80 is the documented terminfo default for xterm-family TERMs")
        self.assertNotIn(137, _TPUT_STUB_VALUES,
            "137 is a plausible real width — must not be on the stub list")
        self.assertNotIn(120, _TPUT_STUB_VALUES)
        self.assertNotIn(200, _TPUT_STUB_VALUES)

    def test_stub_heuristic_not_triggered_when_prior_tty_signal_exists(self):
        """The inverse of test_tput_stub_80_rejected_when_no_tty_signal:
        if any earlier step succeeded with a TTY probe, then a tput
        cols=80 reading is a REAL 80-col terminal, not a stub —
        accept it.

        Without this test, the heuristic could be inverted
        (`and any_tty_probe_succeeded` instead of `and not …`) and
        every existing test would still pass.

        We don't simulate the full chain — we just verify the gating
        flag's intent by checking the `any_tty_probe_succeeded`
        condition in the source. This is a structural test, not
        behavioral: it ensures the heuristic's PRECONDITION (no prior
        TTY signal) is in the code, so a future refactor that drops
        the gating fails this test.
        """
        import inspect
        from claude_statusline import cli as cli_mod
        source = inspect.getsource(cli_mod._detect_terminal_width_report)
        # The gating condition is the difference between "reject every
        # tput 80" (would harm real 80-col users) and "reject tput 80
        # only when no other TTY signal succeeded" (correct).
        self.assertIn("any_tty_probe_succeeded", source,
            "stub heuristic must gate on whether any earlier TTY probe "
            "succeeded — otherwise users with a real 80-col terminal would "
            "be miscategorized when other signals also fail")
        # Must check the FALSE branch (no signal), not the true branch.
        self.assertIn("not any_tty_probe_succeeded", source,
            "stub heuristic must reject only when no earlier TTY signal "
            "succeeded — guard against accidental inversion of the gate")

    def test_stub_heuristic_actually_reachable_on_platform(self):
        """The headline test_tput_stub_80_rejected_when_no_tty_signal
        monkey-patches __builtins__["open"]. On Windows, if that
        patch fails to take (some Python build configs), the chain
        never opens /dev/tty and the stub branch is never reached —
        the assertion passes trivially via the safe fallback path.

        This test makes the silent skip loud: the report MUST contain
        a tput cols entry that mentions 'stub' or 'rejected', proving
        the stub branch actually fired. Without this, the green CI
        on Windows could be hiding a broken patch.
        """
        import subprocess as subprocess_mod
        import claude_statusline.cli as cli_mod

        orig_run = subprocess_mod.run
        orig_open = __builtins__["open"] if isinstance(__builtins__, dict) else open

        class FakeTTY:
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self): return ""
            def fileno(self): return 0

        def fake_run(cmd, *args, **kwargs):
            if cmd[0] == "stty":
                return subprocess_mod.CompletedProcess(cmd, 1, "", "")
            if cmd[0] == "tput":
                return subprocess_mod.CompletedProcess(cmd, 0, "80\n", "")
            return orig_run(cmd, *args, **kwargs)

        def fake_open(path, *args, **kwargs):
            if path == "/dev/tty":
                return FakeTTY()
            return orig_open(path, *args, **kwargs)

        cli_mod.subprocess.run = fake_run
        os.environ.pop("COLUMNS", None)
        cli_builtins = cli_mod.__builtins__
        cli_open_was_dict = isinstance(cli_builtins, dict)
        cli_orig_open = (cli_builtins["open"] if cli_open_was_dict
                         else cli_builtins.open)
        try:
            if cli_open_was_dict:
                cli_builtins["open"] = fake_open
            else:
                cli_builtins.open = fake_open
            _result, report = cli_mod._detect_terminal_width_report({})
        finally:
            cli_mod.subprocess.run = orig_run
            if cli_open_was_dict:
                cli_builtins["open"] = cli_orig_open
            else:
                cli_builtins.open = cli_orig_open

        # Find the tput entry. If it's not there, the patch silently
        # failed and the headline test would have green-lit a broken
        # build. Make that LOUD.
        tput_entries = [s for label, s in report if label == "tput cols"]
        self.assertTrue(tput_entries,
            "tput cols step must have produced a report entry — if absent, "
            "the /dev/tty open path failed to reach the stty/tput block "
            "and the stub-rejection assertion in the headline test is "
            "vacuous on this platform")
        self.assertTrue(
            any("stub" in s or "rejected" in s for s in tput_entries),
            "tput cols must show the stub-rejection signature ('stub' or "
            "'rejected'); got: {!r}".format(tput_entries))

    # --- Process-tree walk --------------------------------------------

    def test_process_tree_walk_skipped_on_windows(self):
        """Windows has no /proc and a different subprocess ancestry
        model — the walk must short-circuit cleanly."""
        from claude_statusline.cli import _detect_width_via_process_tree
        if platform.system() != "Windows":
            self.skipTest("Windows-only check")
        result, status = _detect_width_via_process_tree()
        self.assertIsNone(result)
        self.assertIn("Windows", status)

    def test_process_tree_walk_returns_tuple(self):
        """The walk must always return a 2-tuple (Optional[int], str)
        regardless of platform — never raise, never return None alone.
        --doctor concatenates the status string into its output."""
        from claude_statusline.cli import _detect_width_via_process_tree
        result = _detect_width_via_process_tree()
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 2)
        winner, status = result
        self.assertTrue(winner is None or isinstance(winner, int))
        self.assertIsInstance(status, str)
        self.assertGreater(len(status), 0,
            "status must be non-empty for --doctor formatting")

    # --- Report shape (consumed by --doctor) --------------------------

    def test_report_is_list_of_pairs(self):
        """_detect_terminal_width_report returns (int, list[(str, str)])
        — pin the shape so --doctor formatting doesn't break."""
        from claude_statusline.cli import _detect_terminal_width_report
        result, report = _detect_terminal_width_report({})
        self.assertIsInstance(result, int)
        self.assertIsInstance(report, list)
        self.assertGreater(len(report), 0)
        for entry in report:
            self.assertIsInstance(entry, tuple)
            self.assertEqual(len(entry), 2)
            label, status = entry
            self.assertIsInstance(label, str)
            self.assertIsInstance(status, str)

    def test_report_marks_winner(self):
        """The winning step's status must contain '(winner)' so the
        report is scannable. Stdin terminal.columns is the cheapest
        guaranteed-winning path to test this on."""
        from claude_statusline.cli import _detect_terminal_width_report
        _result, report = _detect_terminal_width_report({"terminal": {"columns": 165}})
        winner_entries = [s for _label, s in report if "(winner)" in s]
        self.assertEqual(len(winner_entries), 1,
            "exactly one step should be marked as the winner")
        self.assertIn("165", winner_entries[0])

    def test_thin_wrapper_unchanged_signature(self):
        """_detect_terminal_width(data) must still return a plain int
        — every existing caller relies on the int return shape. The
        refactor that added the report path must not have changed the
        public signature."""
        from claude_statusline.cli import _detect_terminal_width
        result = _detect_terminal_width({"terminal": {"columns": 165}})
        self.assertIsInstance(result, int)
        self.assertEqual(result, 165)
        # No-arg form must also still work (used by --doctor and the
        # historical fallback path).
        result_no_arg = _detect_terminal_width()
        self.assertIsInstance(result_no_arg, int)

    # --- Lying-signal regression tests --------------------------------
    #
    # These tests pin the generic "what if step N lies with a bogus
    # value" pattern. The 2.1.139 regression was specifically tput
    # returning 80, but the same shape of bug could appear at any
    # other probe step in the future. Each test below simulates one
    # probe returning a wildly wrong value and asserts the chain
    # rejects it (via the _TERM_WIDTH_MIN/_MAX range check or the
    # stub heuristic) rather than blindly trusting it.

    def test_shutil_get_terminal_size_columns_0_rejected(self):
        """shutil.get_terminal_size returning columns=0 (some
        misconfigured environments / future regressions) must be
        rejected by the range check, not accepted as a real width."""
        import claude_statusline.cli as cli_mod
        orig_shutil_gts = cli_mod.shutil.get_terminal_size
        cli_mod.shutil.get_terminal_size = lambda fallback=None: os.terminal_size((0, 0))
        try:
            result = cli_mod._detect_terminal_width({})
            self.assertNotEqual(result, 0,
                "shutil returning 0 must be rejected by the >= 20 range check; "
                "blindly accepting it would render an unusable layout")
            self.assertGreaterEqual(result, 20)
        finally:
            cli_mod.shutil.get_terminal_size = orig_shutil_gts

    def test_os_get_terminal_size_fd_columns_0_rejected(self):
        """os.get_terminal_size(fd) returning columns=0 (e.g., a
        closed pty that still claims to be a terminal) must be
        rejected. Forces the chain to fall through to the next step
        rather than render an unusable 0-col layout."""
        import claude_statusline.cli as cli_mod
        # Force shutil to return -1 (its sentinel "no TTY" value) so
        # we definitely reach the os.get_terminal_size step.
        orig_shutil_gts = cli_mod.shutil.get_terminal_size
        orig_os_gts = cli_mod.os.get_terminal_size
        # Restore COLUMNS too: module-level baseline at line 21 seeds
        # it; if we leak the pop here, every subsequent test in the
        # process runs without that baseline. Captured before pop,
        # restored in finally to keep cross-test ordering insensitive.
        saved_cols = os.environ.pop("COLUMNS", None)
        cli_mod.shutil.get_terminal_size = lambda fallback=None: os.terminal_size((-1, -1))
        cli_mod.os.get_terminal_size = lambda fd: os.terminal_size((0, 0))
        try:
            result = cli_mod._detect_terminal_width({})
            self.assertNotEqual(result, 0,
                "os.get_terminal_size returning 0 must be rejected; "
                "without the range check we would render an unusable layout")
            self.assertGreaterEqual(result, 20)
        finally:
            cli_mod.shutil.get_terminal_size = orig_shutil_gts
            cli_mod.os.get_terminal_size = orig_os_gts
            if saved_cols is not None:
                os.environ["COLUMNS"] = saved_cols

    def test_stty_returns_0_0_rejected_by_range_check(self):
        """If stty started returning '0 0' tomorrow (analogous to the
        2.1.139 tput stub but at a different layer), the result must
        be rejected. This is the generic test pattern that would have
        caught the original 2.1.139 regression if it had been in
        place."""
        import subprocess as subprocess_mod
        import claude_statusline.cli as cli_mod

        orig_run = subprocess_mod.run
        orig_open = __builtins__["open"] if isinstance(__builtins__, dict) else open

        class FakeTTY:
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self): return ""
            def fileno(self): return 0

        def fake_run(cmd, *args, **kwargs):
            if cmd[0] == "stty":
                # The hypothetical future regression: stty returns 0 0
                # without erroring.
                return subprocess_mod.CompletedProcess(cmd, 0, "0 0\n", "")
            if cmd[0] == "tput":
                # Make tput also fail so we don't accidentally win there.
                return subprocess_mod.CompletedProcess(cmd, 1, "", "")
            return orig_run(cmd, *args, **kwargs)

        def fake_open(path, *args, **kwargs):
            if path == "/dev/tty":
                return FakeTTY()
            return orig_open(path, *args, **kwargs)

        cli_mod.subprocess.run = fake_run
        # Restore COLUMNS in finally — without this, the module-level
        # baseline at line 21 leaks and later tests run without it.
        saved_cols = os.environ.pop("COLUMNS", None)
        cli_builtins = cli_mod.__builtins__
        cli_open_was_dict = isinstance(cli_builtins, dict)
        cli_orig_open = (cli_builtins["open"] if cli_open_was_dict
                         else cli_builtins.open)
        try:
            if cli_open_was_dict:
                cli_builtins["open"] = fake_open
            else:
                cli_builtins.open = fake_open
            result, report = cli_mod._detect_terminal_width_report({})
        finally:
            cli_mod.subprocess.run = orig_run
            if cli_open_was_dict:
                cli_builtins["open"] = cli_orig_open
            else:
                cli_builtins.open = cli_orig_open
            if saved_cols is not None:
                os.environ["COLUMNS"] = saved_cols

        self.assertNotEqual(result, 0,
            "stty returning '0 0' must be rejected by the range check")
        # stty entry should record the rejection.
        stty_entries = [s for label, s in report if label == "stty size"]
        if stty_entries:
            # Only meaningful when the chain actually reached stty
            # (e.g., on Windows the /dev/tty fake-open might not take).
            self.assertTrue(
                any("out of range" in s or "rejected" in s
                    for s in stty_entries),
                "report must mark the 0 rejection so --doctor users "
                "can see the lie; got: {!r}".format(stty_entries))


class TestActivityCounter(unittest.TestCase):
    """Transcript-tail-read tool-call counter (the `activity` section).

    Reads the last _TRANSCRIPT_TAIL_BYTES of the JSONL transcript_path
    from stdin, counts tool_use blocks since the most recent user
    message, caches the result for _ACTIVITY_CACHE_TTL seconds. Hidden
    when count is zero so idle sessions show nothing.
    """

    def _write_transcript(self, lines):
        """Helper: write a JSONL transcript and return its path.

        Transcripts MUST live under ~/.claude/ for the realpath
        validation in get_session_activity_count to accept them.
        We create a temp subdirectory under ~/.claude/ and clean up
        at tearDown.
        """
        f = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", suffix=".jsonl",
            delete=False, newline="", dir=self._test_dir,
        )
        for entry in lines:
            f.write(json.dumps(entry) + "\n")
        f.close()
        self._created_paths.append(f.name)
        return f.name

    def setUp(self):
        import shutil as shutil_mod
        from claude_statusline import sessions as sessions_mod
        self._shutil_mod = shutil_mod
        # Create a transient directory under ~/.claude/ so transcripts
        # written by tests pass the realpath validation. mkdir
        # _CLAUDE_DIR if missing — let any creation error surface as
        # a real test failure (silent skip would hide CI misconfig).
        os.makedirs(sessions_mod._CLAUDE_DIR, exist_ok=True)
        self._test_dir = tempfile.mkdtemp(
            prefix="claude-status-test-", dir=sessions_mod._CLAUDE_DIR,
        )
        self._created_paths = []
        # Clear the activity cache for each test so we don't get
        # cross-test contamination from the 5s TTL.
        try:
            cache_dir = sessions_mod._cache_dir()
            if os.path.isdir(cache_dir):
                for name in os.listdir(cache_dir):
                    if name.startswith("activity_"):
                        try:
                            os.remove(os.path.join(cache_dir, name))
                        except OSError:
                            pass
        except OSError:
            pass

    def tearDown(self):
        # shutil.rmtree (not os.rmdir) so the cleanup survives any
        # test that writes extra files into _test_dir without
        # registering them in _created_paths. ignore_errors=True
        # keeps a tearDown hiccup from masking a real test failure.
        self._shutil_mod.rmtree(self._test_dir, ignore_errors=True)

    # --- happy path ---------------------------------------------------

    def test_counts_tool_uses_since_last_user(self):
        from claude_statusline.sessions import _count_activity_from_transcript
        path = self._write_transcript([
            {"message": {"role": "user", "content": "first prompt"}},
            {"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
                {"type": "text", "text": "ok"},
            ]}},
            {"message": {"role": "user", "content": "second prompt"}},
            {"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Read"},
                {"type": "tool_use", "name": "Edit"},
                {"type": "tool_use", "name": "Bash"},
            ]}},
        ])
        # Three tool uses in the most recent assistant turn; the one
        # before the second user message must NOT be counted.
        self.assertEqual(_count_activity_from_transcript(path), 3)

    def test_zero_when_no_tool_use_after_last_user(self):
        from claude_statusline.sessions import _count_activity_from_transcript
        path = self._write_transcript([
            {"message": {"role": "user", "content": "hi"}},
            {"message": {"role": "assistant", "content": [
                {"type": "text", "text": "hello"},
            ]}},
        ])
        self.assertEqual(_count_activity_from_transcript(path), 0)

    def test_zero_when_no_user_message_in_tail(self):
        """If our tail window doesn't reach back to a user message,
        return 0 rather than count the whole window as activity (which
        would be misleading — that activity belongs to a previous turn)."""
        from claude_statusline.sessions import _count_activity_from_transcript
        # Only assistant tool_uses, no user message at all → 0.
        path = self._write_transcript([
            {"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
            ]}},
        ])
        self.assertEqual(_count_activity_from_transcript(path), 0)

    # --- edge cases ---------------------------------------------------

    def test_path_missing(self):
        from claude_statusline.sessions import _count_activity_from_transcript
        self.assertEqual(
            _count_activity_from_transcript("/nonexistent/transcript.jsonl"), 0)

    def test_path_none(self):
        from claude_statusline.sessions import get_session_activity_count
        self.assertEqual(get_session_activity_count(None), 0)
        self.assertEqual(get_session_activity_count(""), 0)

    def test_path_non_string(self):
        from claude_statusline.sessions import get_session_activity_count
        for bad in (42, [], {}, True):
            self.assertEqual(get_session_activity_count(bad), 0,
                "non-string transcript_path={!r} must return 0, not crash".format(bad))

    def test_empty_file(self):
        from claude_statusline.sessions import _count_activity_from_transcript
        f = tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False)
        f.close()
        self._created_paths.append(f.name)
        self.assertEqual(_count_activity_from_transcript(f.name), 0)

    def test_malformed_json_lines_skipped(self):
        """A garbled line in the middle must not abort parsing — skip
        it and continue counting the valid lines."""
        from claude_statusline.sessions import _count_activity_from_transcript
        path = self._write_transcript([
            {"message": {"role": "user", "content": "go"}},
        ])
        # Append a malformed line and another valid tool_use line.
        with open(path, "a", encoding="utf-8") as f:
            f.write("{this is not json\n")
            f.write(json.dumps({"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
            ]}}) + "\n")
        self.assertEqual(_count_activity_from_transcript(path), 1)

    def test_expanded_retry_when_initial_tail_misses_user(self):
        """When the cheap 64 KiB tail doesn't reach back to a user
        message, the function retries with the expanded 1 MiB cap.
        Real-world scenario: an assistant turn produced > 64 KiB of
        output (long tool_result block). Without the retry we'd
        return 0 and the activity counter would silently vanish
        mid-turn."""
        from claude_statusline.sessions import (
            _TRANSCRIPT_TAIL_BYTES,
            _count_activity_from_transcript,
        )
        # User message at start, then enough padding to push it well
        # beyond the 64 KiB initial cap but inside the 1 MiB expanded
        # cap, then a fresh tool_use.
        path = self._write_transcript([
            {"message": {"role": "user", "content": "go"}},
        ])
        padding_line = json.dumps({
            "message": {"role": "assistant", "content": [
                {"type": "text", "text": "x" * 1000},
            ]},
        }) + "\n"
        with open(path, "a", encoding="utf-8") as f:
            bytes_written = 0
            while bytes_written < _TRANSCRIPT_TAIL_BYTES + 10_000:
                f.write(padding_line)
                bytes_written += len(padding_line.encode("utf-8"))
            f.write(json.dumps({"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
            ]}}) + "\n")
        # Initial 64 KiB tail misses the user; expanded 1 MiB retry
        # finds it and counts the tool_use.
        self.assertEqual(_count_activity_from_transcript(path), 1,
            "expanded retry must find a user message in the 1 MiB window")

    def test_outer_envelope_role_schema_supported(self):
        """Some Claude Code schema versions put `role` at the outer
        envelope rather than under `message`. The fallback branch at
        sessions.py:_parse_transcript_tail must accept this shape.
        Without this test, that branch was dead code in the suite."""
        from claude_statusline.sessions import _count_activity_from_transcript
        # NOTE: write raw JSONL because _write_transcript wraps in
        # {"message": ...} which is the OTHER schema.
        path = self._write_transcript([])  # creates the file
        with open(path, "w", encoding="utf-8") as f:
            # Outer-envelope role: no 'message' wrapper.
            f.write(json.dumps({"role": "user", "content": "go"}) + "\n")
            f.write(json.dumps({"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
            ]}}) + "\n")
        self.assertEqual(_count_activity_from_transcript(path), 1,
            "outer-envelope role:user must be recognized as a user message")

    def test_consecutive_user_messages_use_most_recent(self):
        """Real sessions sometimes have adjacent user messages
        (system-injected reminders, retries). The walk-backwards
        loop must pick the MOST RECENT user message — counting only
        tool_uses after the LAST one, not the first."""
        from claude_statusline.sessions import _count_activity_from_transcript
        path = self._write_transcript([
            {"message": {"role": "user", "content": "first"}},
            {"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},  # would be counted if we picked first user
                {"type": "tool_use", "name": "Read"},
            ]}},
            {"message": {"role": "user", "content": "second"}},
            {"message": {"role": "user", "content": "third"}},  # consecutive
            {"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Edit"},  # only this counts
            ]}},
        ])
        self.assertEqual(_count_activity_from_transcript(path), 1,
            "consecutive user messages: count only from the most recent")

    def test_user_message_containing_literal_tool_use_text(self):
        """A user message body that contains the literal text
        '"tool_use"' (e.g., the user asking 'what does "tool_use"
        mean?') must NOT inflate the count. The cheap pre-filter
        admits it, but the JSON parse + structural check should
        exclude it."""
        from claude_statusline.sessions import _count_activity_from_transcript
        path = self._write_transcript([
            {"message": {"role": "user", "content": 'what is "tool_use" type?'}},
            {"message": {"role": "assistant", "content": [
                # A text block that mentions "tool_use" in its body.
                {"type": "text", "text": 'the "tool_use" type is a content block'},
            ]}},
        ])
        self.assertEqual(_count_activity_from_transcript(path), 0,
            "literal 'tool_use' text in message bodies must not inflate count")

    def test_path_is_directory_returns_zero(self):
        """transcript_path pointing at a directory (instead of a
        JSONL file) must return 0, not crash. Guards against an
        upstream that mistakenly sets transcript_path to the
        containing folder."""
        from claude_statusline.sessions import _count_activity_from_transcript
        # self._test_dir is a real directory under ~/.claude/ — passes
        # the realpath validation but isn't a file.
        self.assertEqual(_count_activity_from_transcript(self._test_dir), 0)

    def test_claude_dir_symlinked_paths_accepted(self):
        """When ~/.claude is itself a symlink to another location
        (common on macOS / NAS setups / users who symlink dotdirs),
        a legitimate transcript_path under ~/.claude/projects/...
        must still be accepted.

        Before the fix, _CLAUDE_DIR was unresolved (expanduser only)
        but transcript_path was compared via os.path.realpath, so the
        symlink-resolved real path didn't share the unresolved prefix
        and every transcript was silently rejected. Users in that
        layout would see `act:` permanently absent with no diagnostic.

        We can't easily symlink a real ~/.claude in a unit test, but
        we can verify the module-level _CLAUDE_DIR_REAL constant
        exists and equals the resolved form (the actual fix).
        """
        from claude_statusline import sessions as sessions_mod
        # The fix: _CLAUDE_DIR_REAL is the resolved form, used by
        # get_session_activity_count's prefix check.
        self.assertTrue(hasattr(sessions_mod, "_CLAUDE_DIR_REAL"),
            "fix introduces _CLAUDE_DIR_REAL — must exist at module level")
        # The resolved form must equal realpath of the unresolved form.
        self.assertEqual(sessions_mod._CLAUDE_DIR_REAL,
                         os.path.realpath(sessions_mod._CLAUDE_DIR))
        # Crucially: the get_session_activity_count validation must
        # check against _CLAUDE_DIR_REAL, not _CLAUDE_DIR. Pin via
        # source inspection so a future refactor that reverts to
        # _CLAUDE_DIR fails this test.
        import inspect
        source = inspect.getsource(sessions_mod.get_session_activity_count)
        self.assertIn("_CLAUDE_DIR_REAL", source,
            "get_session_activity_count must use _CLAUDE_DIR_REAL for "
            "the prefix check — using unresolved _CLAUDE_DIR breaks "
            "users whose ~/.claude is symlinked")

    def test_transcript_path_outside_claude_dir_rejected(self):
        """Defense in depth: transcript_path comes from external JSON.
        A path outside ~/.claude/ (whether by buggy upstream or
        symlink escape) must be rejected by get_session_activity_count
        before any open() is attempted.

        Even though the parse function tolerates arbitrary paths
        (returns 0 on any error), the caller-side validation is the
        security boundary that prevents read attempts on /etc/shadow
        and similar paths.
        """
        from claude_statusline.sessions import get_session_activity_count
        # Use a tempfile outside ~/.claude/ — the standard tmp dir.
        f = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", suffix=".jsonl", delete=False)
        f.write(json.dumps({"message": {"role": "user", "content": "x"}}) + "\n")
        f.write(json.dumps({"message": {"role": "assistant", "content": [
            {"type": "tool_use", "name": "Bash"},
        ]}}) + "\n")
        f.close()
        try:
            # If validation were missing, this would return 1.
            self.assertEqual(get_session_activity_count(f.name), 0,
                "transcript_path outside ~/.claude/ must be rejected by "
                "the realpath check, not silently read")
        finally:
            try:
                os.remove(f.name)
            except OSError:
                pass

    def test_small_file_no_user_has_distinct_status(self):
        """When the WHOLE file fits in the 64 KiB cap (no retry
        needed) and contains no user message, the status must say
        'in N byte file' — not the misleading '1 MiB tail' wording
        that would suggest we tried something we didn't."""
        from claude_statusline.sessions import _count_activity_with_status
        # Tiny file (~ a few hundred bytes) with no user message.
        path = self._write_transcript([
            {"message": {"role": "assistant", "content": [
                {"type": "text", "text": "hi"},
            ]}},
        ])
        count, status = _count_activity_with_status(path)
        self.assertEqual(count, 0)
        self.assertNotIn("1 MiB", status,
            "small-file no-user-found status must not falsely claim "
            "we tried a 1 MiB tail read; got: {!r}".format(status))
        self.assertIn("byte file", status,
            "small-file status should name the actual file size; "
            "got: {!r}".format(status))

    def test_count_with_status_disambiguates_zero(self):
        """_count_activity_with_status returns a (count, status)
        tuple so --doctor can distinguish:
          - legitimate idle (parsed OK, 0 tool_uses since last user)
          - transient failure (file missing / empty / stat error)
          - giving-up (turn larger than 1 MiB expanded window)

        Without this, the --doctor Transcript: block could not
        explain WHY the activity counter shows 0. Pin all three
        cases below."""
        from claude_statusline.sessions import _count_activity_with_status
        # Case 1: legitimate idle — file parses OK, no tool_uses.
        path = self._write_transcript([
            {"message": {"role": "user", "content": "go"}},
        ])
        count, status = _count_activity_with_status(path)
        self.assertEqual(count, 0)
        self.assertIn("parsed", status,
            "legitimate idle must report 'parsed' so --doctor users "
            "see the parse succeeded; got: {!r}".format(status))
        self.assertIn("0 tool_use", status)

        # Case 2: file missing — security check (path outside
        # ~/.claude/) would normally reject, but here we test the
        # parse function directly which only checks isfile.
        count, status = _count_activity_with_status(
            os.path.join(self._test_dir, "does-not-exist.jsonl"))
        self.assertEqual(count, 0)
        self.assertIn("missing", status,
            "missing file must produce a distinguishable status, not "
            "the same string as legitimate idle; got: {!r}".format(status))

    def test_gave_up_state_cached_to_avoid_repeated_1mib_reads(self):
        """When _count_activity_with_status returns the gave-up
        status (turn larger than 1 MiB), get_session_activity_count
        writes a separate long-TTL cache entry. Subsequent calls
        within that TTL must short-circuit without re-reading the
        1 MiB tail — verify by mutating the file and confirming the
        cached 0 still wins."""
        from claude_statusline.sessions import (
            _TRANSCRIPT_TAIL_BYTES_EXPANDED,
            get_session_activity_count,
        )
        # Construct a "gave up" file: user message at the start,
        # padding past the 1 MiB expanded cap, then a tool_use.
        path = self._write_transcript([
            {"message": {"role": "user", "content": "old"}},
        ])
        padding_line = json.dumps({
            "message": {"role": "assistant", "content": [
                {"type": "text", "text": "x" * 1000},
            ]},
        }) + "\n"
        with open(path, "a", encoding="utf-8") as f:
            bytes_written = 0
            while bytes_written < _TRANSCRIPT_TAIL_BYTES_EXPANDED + 10_000:
                f.write(padding_line)
                bytes_written += len(padding_line.encode("utf-8"))
            f.write(json.dumps({"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
            ]}}) + "\n")

        # First call: gave-up state, writes the gaveup cache entry.
        first = get_session_activity_count(path)
        self.assertEqual(first, 0,
            "huge-turn case must return 0 (no user message in window)")

        # Mutate the file to make a fresh user → tool_use pattern
        # near the end (would normally be detectable). The gaveup
        # cache must still return 0 — proves we did NOT re-read.
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps({"message": {"role": "user", "content": "next"}}) + "\n")
            f.write(json.dumps({"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Read"},
            ]}}) + "\n")
        second = get_session_activity_count(path)
        self.assertEqual(second, 0,
            "gave-up cache must short-circuit subsequent calls within TTL — "
            "without it we would re-read 1 MiB on every render of a stuck turn")

    def test_zero_counts_not_cached(self):
        """A zero count can mean 'no activity' OR 'parse failed,
        transient file issue.' Caching zero would suppress recovery
        for the full 5s TTL. Verify zero is NOT cached: an empty
        file (returns 0) followed by a populated state (returns >0)
        must show the new count immediately, not a stale 0."""
        from claude_statusline.sessions import get_session_activity_count
        # Create a file that initially has no tool_use after the user.
        path = self._write_transcript([
            {"message": {"role": "user", "content": "go"}},
        ])
        first = get_session_activity_count(path)
        self.assertEqual(first, 0)
        # Append a tool_use right after — without TTL expiry, a cached
        # 0 would still be returned. With our non-zero-cache fix, the
        # function should re-read and find the new tool_use.
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps({"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
            ]}}) + "\n")
        second = get_session_activity_count(path)
        self.assertEqual(second, 1,
            "zero result must NOT be cached — recovery should be immediate, "
            "not blocked behind the 5s TTL")

    def test_returns_zero_when_turn_exceeds_expanded_cap(self):
        """When even the expanded 1 MiB retry can't find a user
        message, we return 0 — this is the genuine giving-up case
        for pathologically large single turns. Prevents misleading
        counts of activity from a previous turn."""
        from claude_statusline.sessions import (
            _TRANSCRIPT_TAIL_BYTES_EXPANDED,
            _count_activity_from_transcript,
        )
        path = self._write_transcript([
            {"message": {"role": "user", "content": "old"}},
        ])
        padding_line = json.dumps({
            "message": {"role": "assistant", "content": [
                {"type": "text", "text": "x" * 1000},
            ]},
        }) + "\n"
        with open(path, "a", encoding="utf-8") as f:
            bytes_written = 0
            # Push the user message past the 1 MiB expanded cap.
            while bytes_written < _TRANSCRIPT_TAIL_BYTES_EXPANDED + 10_000:
                f.write(padding_line)
                bytes_written += len(padding_line.encode("utf-8"))
            f.write(json.dumps({"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
            ]}}) + "\n")
        self.assertEqual(_count_activity_from_transcript(path), 0,
            "even the expanded retry cannot reach the user — return 0 rather "
            "than misleadingly count a previous turn's activity")

    def test_partial_first_line_discarded(self):
        """When reading from a tail offset (start > 0), the first line
        of the chunk may be partial — must be discarded, not parsed."""
        from claude_statusline.sessions import (
            _TRANSCRIPT_TAIL_BYTES,
            _count_activity_from_transcript,
        )
        # Construct a file where the byte at _TRANSCRIPT_TAIL_BYTES
        # offset from EOF falls in the middle of a JSON object.
        path = self._write_transcript([
            {"message": {"role": "user", "content": "go"}},
        ])
        # Pad so that the tail window starts mid-line of an earlier
        # entry. The first read line will be malformed JSON that the
        # discard logic must drop without erroring.
        with open(path, "a", encoding="utf-8") as f:
            # Single very long line larger than the tail cap.
            big = "x" * (_TRANSCRIPT_TAIL_BYTES + 5000)
            f.write(json.dumps({
                "message": {"role": "assistant", "content": [
                    {"type": "text", "text": big},
                ]},
            }) + "\n")
            f.write(json.dumps({"message": {"role": "user", "content": "next"}}) + "\n")
            f.write(json.dumps({"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
                {"type": "tool_use", "name": "Read"},
            ]}}) + "\n")
        # Must not crash on the partial first line; must find the user
        # message that's whole inside the tail; must count 2 tool_uses.
        result = _count_activity_from_transcript(path)
        self.assertEqual(result, 2)

    # --- caching ------------------------------------------------------

    def test_result_cached(self):
        """A second call within TTL must hit cache (not re-read file).
        Verify by mutating the file between calls and confirming the
        second call returns the stale value."""
        from claude_statusline.sessions import get_session_activity_count
        path = self._write_transcript([
            {"message": {"role": "user", "content": "go"}},
            {"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
            ]}},
        ])
        first = get_session_activity_count(path)
        self.assertEqual(first, 1)
        # Mutate the file to have 5 tool_uses — but cache should still
        # return 1 because the TTL hasn't expired.
        with open(path, "a", encoding="utf-8") as f:
            for _ in range(4):
                f.write(json.dumps({"message": {"role": "assistant", "content": [
                    {"type": "tool_use", "name": "Bash"},
                ]}}) + "\n")
        second = get_session_activity_count(path)
        self.assertEqual(second, 1, "must return cached value within TTL")

    # --- end-to-end render --------------------------------------------

    def test_activity_section_renders(self):
        """Enabling the activity section produces 'act:N' in output
        when count > 0."""
        import claude_statusline.cli as cli_mod
        from claude_statusline.themes import THEMES

        path = self._write_transcript([
            {"message": {"role": "user", "content": "go"}},
            {"message": {"role": "assistant", "content": [
                {"type": "tool_use", "name": "Bash"},
                {"type": "tool_use", "name": "Read"},
            ]}},
        ])

        orig_line2 = THEMES["default"]["line2"]
        orig_branch = cli_mod.get_branch
        cli_mod.get_branch = lambda: "main"
        try:
            THEMES["default"]["line2"] = ["activity", "branch"]
            data = {
                "transcript_path": path,
                "git_branch": "main",
            }
            output = cli_mod.render(data, "default")
            plain = re.sub(r"\x1b\[[0-9;]*m", "", output)
            self.assertIn("act:", plain,
                "activity section must render 'act:' label")
            self.assertIn("2", plain,
                "activity section must render the count value")
        finally:
            THEMES["default"]["line2"] = orig_line2
            cli_mod.get_branch = orig_branch

    def test_activity_section_hidden_when_zero(self):
        """Idle session (no tool calls in current turn) → section absent."""
        import claude_statusline.cli as cli_mod
        from claude_statusline.themes import THEMES

        path = self._write_transcript([
            {"message": {"role": "user", "content": "go"}},
            {"message": {"role": "assistant", "content": [
                {"type": "text", "text": "no tools"},
            ]}},
        ])

        orig_line2 = THEMES["default"]["line2"]
        orig_branch = cli_mod.get_branch
        cli_mod.get_branch = lambda: "main"
        try:
            THEMES["default"]["line2"] = ["activity", "branch"]
            data = {"transcript_path": path, "git_branch": "main"}
            output = cli_mod.render(data, "default")
            self.assertNotIn("act:", output,
                "activity must be silent when no tool calls in current turn")
        finally:
            THEMES["default"]["line2"] = orig_line2
            cli_mod.get_branch = orig_branch

    def test_render_with_missing_transcript_path(self):
        """A session without transcript_path on stdin must not crash —
        the activity section just doesn't render."""
        import claude_statusline.cli as cli_mod
        from claude_statusline.themes import THEMES

        orig_line2 = THEMES["default"]["line2"]
        orig_branch = cli_mod.get_branch
        cli_mod.get_branch = lambda: "main"
        try:
            THEMES["default"]["line2"] = ["activity", "branch"]
            data = {"git_branch": "main"}  # no transcript_path
            output = cli_mod.render(data, "default")
            self.assertNotIn("act:", output)
            self.assertIn("main", output, "rest of the line must still render")
        finally:
            THEMES["default"]["line2"] = orig_line2
            cli_mod.get_branch = orig_branch


if __name__ == "__main__":
    unittest.main()
