"""Command primitives for nisane."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable


CommandCallback = Callable[..., Awaitable[Any]]


@dataclass(slots=True)
class Command:
    """Represents an executable bot command."""

    name: str
    callback: CommandCallback
    help: str | None = None

    async def invoke(self, ctx: Any, *args: str) -> Any:
        """Run the command callback with context and parsed args."""
        return await self.callback(ctx, *args)
