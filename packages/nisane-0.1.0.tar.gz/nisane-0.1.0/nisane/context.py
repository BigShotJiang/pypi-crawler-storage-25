"""Invocation context object for commands."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class Context:
    """Context passed to command callbacks."""

    bot: Any
    message: Any
    args: tuple[str, ...]

    @property
    def author(self) -> Any:
        return self.message.author

    @property
    def channel(self) -> Any:
        return self.message.channel

    async def send(self, content: str) -> Any:
        """Send a message to the current channel."""
        channel_id = self.channel.id
        return await self.bot.http.send_message(channel_id=channel_id, content=content)
