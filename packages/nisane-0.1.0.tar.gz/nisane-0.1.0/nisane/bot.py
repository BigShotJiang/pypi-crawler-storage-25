"""Core Bot implementation for nisane."""

from __future__ import annotations

import asyncio
import contextlib
import inspect
import shlex
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, Awaitable, Callable

import aiohttp

from .command import Command
from .context import Context
from .http import HTTPClient

DISPATCH = 0
HEARTBEAT = 1
IDENTIFY = 2
RECONNECT = 7
INVALID_SESSION = 9
HELLO = 10

DEFAULT_INTENTS = (1 << 0) | (1 << 9) | (1 << 15)

EventCallback = Callable[..., Awaitable[Any]]


@dataclass(slots=True)
class GatewayState:
    """Keeps mutable gateway state in one place."""

    seq: int | None = None
    session_id: str | None = None


class Bot:
    """Minimal Discord bot framework."""

    def __init__(self, prefix: str = "!", intents: int = DEFAULT_INTENTS) -> None:
        self.prefix = prefix
        self.intents = intents
        self._events: dict[str, EventCallback] = {}
        self._commands: dict[str, Command] = {}
        self._token: str | None = None
        self._state = GatewayState()
        self.http: HTTPClient | None = None

    def event(self, callback: EventCallback) -> EventCallback:
        """Register an event handler by its function name."""
        self._events[callback.__name__] = callback
        return callback

    def command(self, name: str | None = None, help: str | None = None) -> Callable[[EventCallback], EventCallback]:
        """Register a command callback in internal registry."""

        def decorator(callback: EventCallback) -> EventCallback:
            command_name = name or callback.__name__
            self._commands[command_name] = Command(
                name=command_name,
                callback=callback,
                help=help,
            )
            return callback

        return decorator

    def run(self, token: str) -> None:
        """Start bot event loop."""
        asyncio.run(self.start(token))

    async def start(self, token: str) -> None:
        """Connect to Discord and process incoming gateway events."""
        self._token = token
        async with aiohttp.ClientSession() as session:
            self.http = HTTPClient(token=token, session=session)
            gateway_url = await self.http.get_gateway_url()

            async with session.ws_connect(gateway_url, heartbeat=0) as ws:
                hello_payload = await ws.receive_json()
                heartbeat_interval_ms = hello_payload["d"]["heartbeat_interval"]
                heartbeat_interval = heartbeat_interval_ms / 1000

                await self._identify(ws)

                heartbeat_task = asyncio.create_task(self._heartbeat_loop(ws, heartbeat_interval))
                try:
                    async for message in ws:
                        if message.type != aiohttp.WSMsgType.TEXT:
                            continue
                        payload = message.json()
                        await self._handle_payload(payload)
                finally:
                    heartbeat_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await heartbeat_task

    async def _identify(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        if self._token is None:
            raise RuntimeError("Bot token is not set.")

        payload = {
            "op": IDENTIFY,
            "d": {
                "token": self._token,
                "intents": self.intents,
                "properties": {
                    "os": "linux",
                    "browser": "nisane",
                    "device": "nisane",
                },
            },
        }
        await ws.send_json(payload)

    async def _heartbeat_loop(self, ws: aiohttp.ClientWebSocketResponse, interval: float) -> None:
        while True:
            await asyncio.sleep(interval)
            await ws.send_json({"op": HEARTBEAT, "d": self._state.seq})

    async def _handle_payload(self, payload: dict[str, Any]) -> None:
        op = payload.get("op")
        sequence = payload.get("s")
        if sequence is not None:
            self._state.seq = sequence

        if op == DISPATCH:
            event_name = payload.get("t")
            data = payload.get("d", {})
            await self._dispatch(event_name, data)
            return

        if op in {RECONNECT, INVALID_SESSION}:
            raise ConnectionError("Discord requested reconnect.")

    async def _dispatch(self, event_name: str | None, data: dict[str, Any]) -> None:
        if event_name == "READY":
            self._state.session_id = data.get("session_id")
            await self._invoke_event("on_ready")
            return

        if event_name == "MESSAGE_CREATE":
            message = self._build_message(data)
            await self._invoke_event("on_message", message)
            await self._process_commands(message)

    async def _invoke_event(self, name: str, *args: Any) -> None:
        callback = self._events.get(name)
        if callback is None:
            return
        if inspect.iscoroutinefunction(callback):
            await callback(*args)
            return
        callback(*args)

    async def _process_commands(self, message: SimpleNamespace) -> None:
        content = message.content or ""
        if not content.startswith(self.prefix):
            return

        if getattr(message.author, "bot", False):
            return

        command_line = content[len(self.prefix) :].strip()
        if not command_line:
            return

        parts = shlex.split(command_line)
        command_name, *args = parts
        command = self._commands.get(command_name)
        if command is None:
            return

        ctx = Context(bot=self, message=message, args=tuple(args))
        await command.invoke(ctx, *args)

    @staticmethod
    def _build_message(payload: dict[str, Any]) -> SimpleNamespace:
        author = payload.get("author", {})
        channel_id = payload.get("channel_id")
        channel = {"id": channel_id}
        return SimpleNamespace(
            id=payload.get("id"),
            content=payload.get("content", ""),
            author=SimpleNamespace(**author),
            channel=SimpleNamespace(**channel),
            raw=payload,
        )
