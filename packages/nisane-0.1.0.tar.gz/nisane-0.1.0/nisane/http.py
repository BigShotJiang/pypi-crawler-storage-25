"""HTTP client used by nisane for Discord REST API."""

from __future__ import annotations

from typing import Any

import aiohttp

API_BASE = "https://discord.com/api/v10"


class HTTPClient:
    """Thin wrapper over aiohttp for Discord endpoints."""

    def __init__(self, token: str, session: aiohttp.ClientSession) -> None:
        self.token = token
        self.session = session

    @property
    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bot {self.token}",
            "Content-Type": "application/json",
            "User-Agent": "nisane (https://pypi.org/project/nisane, 0.1.0)",
        }

    async def get_gateway_url(self) -> str:
        """Fetch gateway URL from Discord and append version/encoding params."""
        async with self.session.get(
            f"{API_BASE}/gateway/bot",
            headers=self._headers,
            timeout=30,
        ) as response:
            response.raise_for_status()
            data: dict[str, Any] = await response.json()
            raw_url: str = data["url"]
            return f"{raw_url}?v=10&encoding=json"

    async def send_message(self, channel_id: str, content: str) -> dict[str, Any]:
        """Send plain text message to the channel."""
        payload = {"content": content}
        async with self.session.post(
            f"{API_BASE}/channels/{channel_id}/messages",
            headers=self._headers,
            json=payload,
            timeout=30,
        ) as response:
            response.raise_for_status()
            return await response.json()
