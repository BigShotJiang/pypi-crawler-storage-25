"""Event names supported by nisane."""

ON_READY = "on_ready"
ON_MESSAGE = "on_message"

DEFAULT_EVENTS = {ON_READY, ON_MESSAGE}
