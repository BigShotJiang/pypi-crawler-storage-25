# nisane

`nisane` is a minimalist Discord bot framework for Python that does **not** depend on `discord.py`, `disnake`, `nextcord`, or `pycord`.

It provides an MVP-style API inspired by classic decorator-based Discord frameworks:

```python
from nisane import Bot

bot = Bot(prefix="!")

@bot.event
async def on_ready():
    print("Bot is ready")

@bot.event
async def on_message(message):
    print(message.content)

@bot.command()
async def ping(ctx):
    await ctx.send("Pong!")

bot.run("YOUR_TOKEN")
```

## Features

- Event registration through `@bot.event`
- Command registration through `@bot.command()`
- Prefix-based command parsing
- Minimal `Context` object with `ctx.send()`
- Direct Discord Gateway + REST usage through `aiohttp`

## Installation

```bash
pip install nisane
```

## Local development

```bash
python -m venv .venv
. .venv/Scripts/activate
pip install -U pip build twine
pip install -e .
```

Run tests:

```bash
python -m unittest discover -s tests -p "test_*.py"
```

## Build and publish

Build distributions:

```bash
python -m build
```

Upload with Twine:

```bash
twine upload dist/*
```

## Example

See `examples/basic_bot.py`.

## Notes

This is an MVP framework. For production bots, add robust reconnection logic, rate-limit handling, and richer object models.
