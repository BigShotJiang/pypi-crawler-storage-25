import unittest
from types import SimpleNamespace

from nisane import Bot


class TestBasic(unittest.IsolatedAsyncioTestCase):
    async def test_command_registration(self) -> None:
        bot = Bot(prefix="!")

        @bot.command()
        async def ping(ctx):
            return None

        self.assertIn("ping", bot._commands)

    async def test_prefix_command_parsing(self) -> None:
        bot = Bot(prefix="!")
        called = {"value": False}

        @bot.command()
        async def ping(ctx, *args):
            called["value"] = True
            self.assertEqual(("one", "two"), args)
            self.assertEqual(("one", "two"), ctx.args)

        message = SimpleNamespace(
            content="!ping one two",
            author=SimpleNamespace(bot=False),
            channel=SimpleNamespace(id="123"),
        )
        await bot._process_commands(message)
        self.assertTrue(called["value"])


if __name__ == "__main__":
    unittest.main()
