"""Basic usage example for nisane."""

from nisane import Bot

bot = Bot(prefix="!")


@bot.event
async def on_ready() -> None:
    print("Bot is ready")


@bot.event
async def on_message(message) -> None:
    print(message.content)


@bot.command()
async def ping(ctx) -> None:
    await ctx.send("Pong!")


if __name__ == "__main__":
    bot.run("YOUR_TOKEN")
