from __future__ import annotations

import httpx

from roote_ekispert.exceptions import RooteHttpError
from roote_ekispert.models import LineOperationInfo
from roote_ekispert.parser import parse_operation_html
from roote_ekispert.presets import SENDAI_ROUTE_URLS

_DEFAULT_UA = (
    "roote-ekispert/1.0 (+https://github.com/tikipiya/roote-ekispert) "
    "Python-httpx"
)


def fetch_line_operation_info(
    url: str,
    *,
    timeout: float = 30.0,
    user_agent: str | None = None,
) -> LineOperationInfo:
    """指定 URL の運行情報ページを取得して解析する。"""
    headers = {"User-Agent": user_agent or _DEFAULT_UA}
    try:
        with httpx.Client(timeout=timeout, headers=headers, follow_redirects=True) as client:
            r = client.get(url)
            r.raise_for_status()
            html = r.text
    except httpx.HTTPError as e:
        raise RooteHttpError(str(e)) from e

    return parse_operation_html(html, url=url)


def fetch_sendai_lines(
    *,
    timeout: float = 30.0,
    user_agent: str | None = None,
) -> dict[str, LineOperationInfo]:
    """プリセットの仙台周辺5路線を順に取得し、キーは SENDAI_ROUTE_URLS と同じ。"""
    out: dict[str, LineOperationInfo] = {}
    for key, u in SENDAI_ROUTE_URLS.items():
        out[key] = fetch_line_operation_info(u, timeout=timeout, user_agent=user_agent)
    return out
