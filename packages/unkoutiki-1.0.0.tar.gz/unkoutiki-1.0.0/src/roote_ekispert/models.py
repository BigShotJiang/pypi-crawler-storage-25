from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class ServiceMessage:
    """1件の運行に関する本文と更新時刻（表示文字列）。"""

    text: str
    """運行情報の本文。"""

    update_label: str | None = None
    """ページ上の「更新時間:…」行。無い場合は None。"""


@dataclass(frozen=True, slots=True)
class LineOperationInfo:
    """路線ページから取り出した運行情報のまとまり。"""

    url: str
    line_name: str
    region_operator: str
    messages: tuple[ServiceMessage, ...] = field(default_factory=tuple)
    """運行情報がない場合は空。`現在、運行情報はありません。` のときも空。"""

    @property
    def has_messages(self) -> bool:
        return len(self.messages) > 0
