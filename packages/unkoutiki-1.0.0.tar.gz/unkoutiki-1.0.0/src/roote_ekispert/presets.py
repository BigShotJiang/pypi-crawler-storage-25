"""仙台周辺で指定された路線の Roote URL（そのまま GET 可能）。"""

from __future__ import annotations

from typing import Final

# 路線キーは安定した識別子（コード向け）。表示名は line_name で取得する。
SENDAI_ROUTE_URLS: Final[dict[str, str]] = {
    "jr_senzan": "https://roote.ekispert.net/service/2/ＪＲ/ＪＲ仙山線",
    "jr_tohoku_honsen_kuroiso_sendai": (
        "https://roote.ekispert.net/service/2/ＪＲ/ＪＲ東北本線(黒磯－仙台)"
    ),
    "jr_senseki": "https://roote.ekispert.net/service/2/ＪＲ/ＪＲ仙石線",
    "sendai_subway_namboku": (
        "https://roote.ekispert.net/service/2/仙台市交通局/仙台市地下鉄南北線"
    ),
    "sendai_subway_tozai": (
        "https://roote.ekispert.net/service/2/仙台市交通局/仙台市地下鉄東西線"
    ),
}
