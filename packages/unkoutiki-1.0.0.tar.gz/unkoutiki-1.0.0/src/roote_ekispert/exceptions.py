class RooteError(Exception):
    """ライブラリ共通の基底例外。"""


class RooteHttpError(RooteError):
    """HTTP 取得に失敗したとき。"""


class RooteParseError(RooteError):
    """HTML の解析に失敗したとき。"""
