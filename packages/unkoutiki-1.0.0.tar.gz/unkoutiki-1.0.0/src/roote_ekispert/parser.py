from __future__ import annotations

from bs4 import BeautifulSoup

from roote_ekispert.exceptions import RooteParseError
from roote_ekispert.models import LineOperationInfo, ServiceMessage

_LINE_NAME = "service-info-operation-line-name"
_REGION = "service-info-region-corp-name"
_NO_INFO = "service-info-no-information"
_INFO = "service-info-information"
_INFO_DT = "service-info-information-datetime"


def _text(el) -> str:
    if el is None:
        return ""
    return el.get_text(strip=True)


def parse_operation_html(html: str, url: str) -> LineOperationInfo:
    soup = BeautifulSoup(html, "html.parser")

    line_el = soup.select_one(f'[data-testid="{_LINE_NAME}"]')
    region_el = soup.select_one(f'[data-testid="{_REGION}"]')

    if line_el is None:
        raise RooteParseError("路線名要素が見つかりません (data-testid=service-info-operation-line-name)")

    line_name = _text(line_el)
    region_operator = _text(region_el)

    no_info_el = soup.select_one(f'[data-testid="{_NO_INFO}"]')
    if no_info_el is not None:
        return LineOperationInfo(
            url=url,
            line_name=line_name,
            region_operator=region_operator,
            messages=(),
        )

    info_els = soup.select(f'[data-testid="{_INFO}"]')
    dt_els = soup.select(f'[data-testid="{_INFO_DT}"]')

    messages: list[ServiceMessage] = []
    for i, p in enumerate(info_els):
        body = _text(p)
        if not body:
            continue
        dt = _text(dt_els[i]) if i < len(dt_els) else None
        if dt == "":
            dt = None
        messages.append(ServiceMessage(text=body, update_label=dt))

    return LineOperationInfo(
        url=url,
        line_name=line_name,
        region_operator=region_operator,
        messages=tuple(messages),
    )
