"""parser のユニットテスト（ネットワーク不要）。"""

import pytest

from roote_ekispert.exceptions import RooteParseError
from roote_ekispert.parser import parse_operation_html

HTML_NO = """
<html><body>
<p data-testid="service-info-operation-line-name">ＪＲ仙山線</p>
<p data-testid="service-info-region-corp-name">東北　ＪＲ</p>
<p data-testid="service-info-no-information">現在、運行情報はありません。</p>
</body></html>
"""

HTML_MSG = """
<html><body>
<p data-testid="service-info-operation-line-name">ＪＲ山手線</p>
<p data-testid="service-info-region-corp-name">東北</p>
<p data-testid="service-info-information">遅延が発生しています。</p>
<p data-testid="service-info-information-datetime">更新時間:04/09 05:00</p>
</body></html>
"""


def test_no_information():
    r = parse_operation_html(HTML_NO, url="https://example.com/x")
    assert r.line_name == "ＪＲ仙山線"
    assert r.region_operator == "東北　ＪＲ"
    assert r.messages == ()


def test_with_messages():
    r = parse_operation_html(HTML_MSG, url="https://example.com/y")
    assert r.line_name == "ＪＲ山手線"
    assert len(r.messages) == 1
    assert r.messages[0].text == "遅延が発生しています。"
    assert r.messages[0].update_label == "更新時間:04/09 05:00"


def test_missing_line_raises():
    with pytest.raises(RooteParseError):
        parse_operation_html("<html></html>", url="https://example.com/z")
