"""Support classes used to create a quality report."""

from datetime import datetime
from typing import Annotated
from typing import Any

from pydantic import BaseModel
from pydantic import BeforeValidator
from pydantic import ConfigDict
from pydantic import Field
from pydantic import FiniteFloat
from pydantic import PlainSerializer
from pydantic import field_validator
from pydantic import model_serializer
from pydantic import model_validator
from pydantic.alias_generators import to_camel
from pydantic_core.core_schema import SerializationInfo
from pydantic_core.core_schema import ValidationInfo

###########################################################
# Old Quality Models                                      #
#                                                         #
# These will gradually be replaced by                    #
# New Quality Models (below)                              #
###########################################################


class Plot2D(BaseModel):
    """Support class use to hold the data for creating a 2D plot in the quality report."""

    xlabel: str
    ylabel: str
    series_data: dict[str, list[list[Any]]]
    series_name: str | None = None
    ylabel_horizontal: bool = False
    ylim: tuple[float, float] | None = None
    plot_kwargs: dict[str, dict[str, Any]] = Field(default_factory=dict)
    sort_series: bool = True


class VerticalMultiPanePlot2D(BaseModel):
    """
    Support class to hold a multi-pane plot with plots stacked vertically.

    This type of metric is really geared towards plots that share an X axis and have no gap between them. If you just
    want two separate plots it's probably better to use a list of `Plot2D` objects.
    """

    top_to_bottom_plot_list: list[Plot2D]
    match_x_axes: bool = True
    no_gap: bool = True
    top_to_bottom_height_ratios: list[float] | None = None

    @field_validator("top_to_bottom_height_ratios")
    @classmethod
    def ensure_same_number_of_height_ratios_and_plots(
        cls, height_ratios: list[float] | None, info: ValidationInfo
    ) -> list[float]:
        """
        Make sure that the number of height ratios is the same as the number of plots.

        Also populates default, same-size ratios if no ratios were given.
        """
        try:
            plot_list = info.data["top_to_bottom_plot_list"]
        except KeyError:
            # The plot list didn't validate for some reason. We're about to error anyway.
            return [1.0]

        num_plots = len(plot_list)
        if height_ratios is None:
            return [1.0] * num_plots

        if len(height_ratios) != num_plots:
            raise ValueError(
                f"The number of items in `top_to_bottom_height_ratios` list ({len(height_ratios)}) is not "
                f"the same as the number of plots ({num_plots})"
            )

        return height_ratios


class SimpleTable(BaseModel):
    """Support class to hold a simple table to be inserted into the quality report."""

    rows: list[list[Any]]
    header_row: bool = True
    header_column: bool = False


class ModulationMatrixHistograms(BaseModel):
    """Support class for holding the big ol' grid of histograms that represent the modulation matrix fits."""

    modmat_list: list[list[list[float]]]


class EfficiencyHistograms(BaseModel):
    """Support class for holding 4 histograms that correspond to efficiencies of the 4 stokes components."""

    efficiency_list: list[list[float]]


class PlotHistogram(BaseModel):
    """Support class to hold 1D data for plotting a histogram."""

    xlabel: str
    series_data: dict[str, list[float]]
    series_name: str | None = None
    vertical_lines: dict[str, float] | None


class PlotRaincloud(BaseModel):
    """Support class to hold data series for fancy-ass violin plots."""

    xlabel: str
    ylabel: str
    categorical_column_name: str
    distribution_column_name: str
    dataframe_json: str
    hue_column_name: str | None
    ylabel_horizontal: bool | None


class ReportMetric(BaseModel):
    """A Quality Report is made up of a list of metrics with the schema defined by this class."""

    name: str
    description: str
    metric_code: str
    facet: str | None = None
    statement: str | list[str] | None = None
    plot_data: Plot2D | list[Plot2D] | None = None
    multi_plot_data: VerticalMultiPanePlot2D | None = None
    histogram_data: PlotHistogram | list[PlotHistogram] | None = None
    table_data: SimpleTable | list[SimpleTable] | None = None
    modmat_data: ModulationMatrixHistograms | None = None
    efficiency_data: EfficiencyHistograms | None = None
    raincloud_data: PlotRaincloud | None = None
    warnings: list[str] | None = None


###########################################################
# New Quality Models                                      #
#                                                         #
# These define the interface with dkist-quality           #
# These will eventually get moved to dkist-quality        #
###########################################################


class QualityModel(BaseModel):
    """BaseModel for quality data."""

    model_config = ConfigDict(
        # only accept snake_case field names
        validate_by_name=True,
        # re-validate the field if its value gets changed after creation
        validate_assignment=True,
    )


def datetime_or_iso_dict_input(v: Any) -> Any:
    """
    Extend pydantic `datetime` capability.

    Adds the ability to accept an 'iso dict' of the {"iso_date": <value>} form
    """
    # If appropriate, extract value from {"iso_date": <value>} before passing to the normal datetime handler
    if isinstance(v, dict) and "iso_date" in v:
        return v["iso_date"]
    return v


# NOTE:  This is a temporary data type that can be eliminated once all metric conversion is complete
DatetimeIsoDict = Annotated[
    # this is a datetime within the pydantic BaseModel
    datetime,
    # accept 'iso dict' input in addition to normal datetime inputs
    BeforeValidator(datetime_or_iso_dict_input),
    # always output the datetime as an 'iso dict'
    PlainSerializer(lambda dt: {"iso_date": dt.isoformat()}, return_type=dict[str, str]),
]


class TimeSeriesData(QualityModel):
    """
    Time Series Data.

    The context, e.g. task_type or modstate, is maintained outside of this structure.
    """

    # by default, a tuple accepts a list as input
    # the use of tuples is intentional because list mutations do not trigger validation
    # the impact is that TimeSeriesData should not be instantiated until
    # after the tuple input has been fully accumulated
    # when `mode="json"`, the output of a tuple results in a list
    # when `mode="python"`, the output of a tuple results in a tuple
    x_values: tuple[DatetimeIsoDict, ...]
    # NOTE:  FiniteFloat will fail fast for `nan` and `inf`
    y_values: tuple[FiniteFloat, ...]

    @model_validator(mode="after")
    def tuple_validation(self):
        """Validate tuple lengths."""
        axes_are_different_lengths = len(self.x_values) != len(self.y_values)
        if axes_are_different_lengths:
            raise ValueError(
                f"Cannot store TimeSeriesData with different length axes. "
                f"{len(self.x_values)=}, {len(self.y_values)=}"
            )
        # Can't have this AND default to empty tuple
        axes_are_zero_length = not self.x_values or not self.y_values
        if axes_are_zero_length:
            raise ValueError(
                f"Cannot store TimeSeriesData with 0 length axes. "
                f"{len(self.x_values)=}, {len(self.y_values)=}"
            )
        return self

    @model_serializer(mode="wrap")
    def custom_dump(self, handler, info: SerializationInfo):
        """Serialize output for QRM compatibility."""
        data = handler(self)
        # change structure if mode="json" for QRM compatibility
        if info.mode == "json":
            # dump as list[list[Any]] with DatetimeIsoDict format for x_values
            return [list(data["x_values"]), list(data["y_values"])]
        return data

    @model_validator(mode="before")
    @classmethod
    def handle_json(cls, input_value: Any):
        """
        Transform json input from list[list[Any]] to dict[Any, Any].

        the dict is expected to be dict[str, tuple[Any, ...]], which gets validated by normal BaseModel configurations.
        """
        if isinstance(input_value, dict):
            return input_value

        if (
            isinstance(input_value, (list, tuple))
            and len(input_value) == 2
            and isinstance(input_value[0], (list, tuple))
            and isinstance(input_value[1], (list, tuple))
        ):
            return {"x_values": input_value[0], "y_values": input_value[1]}

        return input_value


class XYData(QualityModel):
    """One or more time series for a single x-y plot."""

    xlabel: str
    ylabel: str
    # the key is the name assigned to the series, e.g. within the legend
    # the key cannot be None, because `null` is not a valid json key
    series_data: dict[str, TimeSeriesData] = Field(default_factory=dict)
    # TODO FUTURE - convert `series_name` to `legend_title` to better align with matplotlib terminology
    series_name: str | None = None
    ylabel_horizontal: bool | None = None
    ylim: tuple[float | None, float | None] | None = None
    plot_kwargs: dict[str, dict[str, Any]] = Field(default_factory=dict)
    sort_series: bool | None = True


class TableData(QualityModel):
    """Tabular Data."""

    # by default, a tuple accepts a list as input
    # the use of tuples is intentional because list mutations do not trigger validation
    # the impact is that TableData should not be instantiated until
    # after the tuple input has been fully accumulated
    # when `mode="json"`, the output of a tuple results in a list
    # when `mode="python"`, the output of a tuple results in a tuple
    # Note: numeric values are represented as strings for table data
    rows: tuple[tuple[str, ...], ...]
    header_row: bool | None = True
    header_col: bool | None = False

    @model_validator(mode="after")
    def tuple_validation(self):
        """Validate tuple lengths."""
        row_count = len(self.rows)
        if row_count == 0:
            raise ValueError(f"Invalid table. No rows.")
        header_column_count = len(self.rows[0])
        if header_column_count == 0:
            raise ValueError(f"Invalid table. No columns.")
        row_column_counts = [len(row) for row in self.rows[1:]]
        column_count_mismatch = any(
            col_count != header_column_count for col_count in row_column_counts
        )
        if column_count_mismatch:
            raise ValueError(
                f"Mismatch in column count. {header_column_count=}, {row_column_counts=}"
            )
        return self


class MultiPlotData(QualityModel):
    """Multiple Plot Data."""

    # TBD
    pass


class HistogramData(QualityModel):
    """Histogram Data."""

    # TBD
    pass


class ModMatData(QualityModel):
    """Modulation Matrix Data."""

    # TBD
    pass


class RaincloudData(QualityModel):
    """Raincloud Data."""

    # TBD
    pass


class EfficiencyData(QualityModel):
    """Efficiency Data."""

    # TBD
    pass


class QualityMetric(QualityModel):
    """Quality Metric."""

    name: str
    description: str
    metric_code: str
    facet: str | None = None
    statement: list[str] | None = None
    plot_data: list[XYData] | None = None
    multi_plot_data: list[MultiPlotData] | None = None
    histogram_data: list[HistogramData] | None = None
    table_data: list[TableData] | None = None
    modmad_data: list[ModMatData] | None = None
    raincloud_data: list[RaincloudData] | None = None
    efficiency_data: list[EfficiencyData] | None = None
    warnings: list[str] | None = None
