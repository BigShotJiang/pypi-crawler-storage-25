"""Classes to support the generation of quality metrics for the calibrated data."""

import logging
from collections import defaultdict
from datetime import datetime
from inspect import signature
from itertools import chain
from pathlib import Path
from typing import Callable
from typing import Generator
from typing import Iterable
from typing import Type

import numpy as np
from pydantic import FiniteFloat

from dkist_processing_common.codecs.basemodel import basemodel_encoder
from dkist_processing_common.models.fits_access import FitsAccessBase
from dkist_processing_common.models.metric_code import MetricCode
from dkist_processing_common.models.quality import QualityMetric
from dkist_processing_common.models.quality import QualityModel
from dkist_processing_common.models.quality import TableData
from dkist_processing_common.models.quality import TimeSeriesData
from dkist_processing_common.models.quality import XYData
from dkist_processing_common.models.tags import Tag
from dkist_processing_common.parsers.l0_fits_access import L0FitsAccess
from dkist_processing_common.parsers.quality import L1QualityFitsAccess
from dkist_processing_common.tasks.base import WorkflowTaskBase
from dkist_processing_common.tasks.mixin.quality import QualityMixin

__all__ = ["QualityL1Metrics", "QualityL0Metrics"]


logger = logging.getLogger(__name__)


class L0QualityData(QualityModel):
    """
    Intermediate L0 Quality Data.

    The relationship of this structure to task type and modstate is maintained outside of this structure.
    One usage is to combine all modstate for a single task type,
     resulting in one instance per task type.
    Another usage is to segregate by modstate and task type,
     resulting in many instances per task type.
    """

    # by default, a tuple accepts a list as input
    # the use of tuples is intentional because list mutations do not trigger validation
    # the impact is that L0QualityData should not be instantiated until
    # after the tuple input has been fully accumulated
    # when `mode="json"`, the output of a tuple results in a list
    # when `mode="python"`, the output of a tuple results in a tuple
    datetimes: tuple[datetime, ...]
    # NOTE:  FiniteFloat will fail fast for `nan` and `inf`
    average_values: tuple[FiniteFloat, ...]
    rms_values: tuple[FiniteFloat, ...]

    @property
    def has_values(self) -> bool:
        return bool(self.average_values)


class QualityL0Metrics(WorkflowTaskBase, QualityMixin):
    """
    Task class supporting the generation of quality metrics for the L0 data.

    Subclassing guide
    -----------------

    There are three important properties that an instrument subclass may want to change to make sure that the L0 metrics
    are computed for the correct files and organized in a meaningful way:

    `raw_frame_tag` (``str``)
        The top-level tag used to identify "raw" frames that will be considered when computing metrics. For visible
        instruments this can be left as the default `Tag.input()`, but IR cameras will probably want to set this to
        `Tag.linearized()` or similar.

    `~dkist_processing_common.tasks.mixin.quality.QualityMixin.quality_task_types` (`list[str]`)
        A list of IPTASK types. A separate set of L0 metrics will be reported for each task type listed here.
        See the definition of `~dkist_processing_common.tasks.mixin.quality.QualityMixin.quality_task_types` for the
        sensible defaults. If overloading, please use controlled `~dkist_processing_common.models.task_name.TaskName`
        values, if possible.

    `modstate_list` (`list[int] | None`)
        A list of modstates over which to separate each metric. Adding modstates does not create new metric entries, but
        does sub-divide each TASK's metric into modstate bins. If you want *all* files of a single TASK to be considered
        together return ``None`` here.

    **NOTE:** The `~dkist_processing_common.tasks.mixin.quality.QualityMixin.quality_task_types` on an instrument
    subclass of `~dkist_processing_common.tasks.l1_output_data.AssembleQualityData` should match whatever is set here
    (although in both cases the default is probably fine).
    """

    @property
    def modstate_list(self) -> Iterable[int] | None:
        """
        Define the list of modstates over which to compute quality metrics.

        If you want to compute metrics over *all* modstates at the same time return `None`.
        """
        return None

    @property
    def raw_frame_tag(self) -> str:
        """
        Define the tag that indicates L0 data.

        Usually this is `Tag.input()`, but for IR instruments it may be `Tag.linearized()`.
        """
        return Tag.input()

    @property
    def fits_access_class(self) -> Type[FitsAccessBase]:
        """Define the `FitsAccess`-type class used to parse the headers of L0 frames."""
        return L0FitsAccess

    def run(self) -> None:
        """
        Calculate L0 quality metrics for all TASK/MODSTATE combinations.

        Which (if any) modstates and task types to loop over can be set with the `modstate_list` and
        `quality_task_types` properties, respectively.
        """
        with self.telemetry_span("Collecting L0 Quality Data"):
            segmented_quality_data = self.collect_l0_quality_data()

        with self.telemetry_span("Writing L0 Quality Metrics to disk"):
            self.compute_and_write_l0_quality_metrics(segmented_quality_data)

    # TODO FUTURE - this method should ultimately go away
    def get_paths_for_modstate_and_task(
        self, modstate: int | None, task_type: str
    ) -> Generator[Path, None, None]:
        """
        Return Paths for all raw files that tagged with the given modstate and task type.

        The tag that defines "raw" can be changed in the `raw_frame_tag` property.
        """
        tags = [self.raw_frame_tag, Tag.task(task_type)]
        if modstate is not None:
            tags.append(Tag.modstate(modstate))

        return self.read(tags)

    def collect_l0_quality_data(self) -> dict[str, dict[str, L0QualityData]]:
        """Calculate L0 quality metrics for each task type and modstate combo."""
        intermediate_l0_quality_data_segmented_first_by_ip_task_and_then_by_modstate: dict[
            str, dict[str, L0QualityData]
        ] = defaultdict(dict)
        modstate_list = self.modstate_list if self.modstate_list is not None else [None]
        for task_type in self.quality_task_types:
            with self.telemetry_span(f"Collecting {task_type = }"):
                for modstate in modstate_list:
                    # TODO FUTURE - this should do something like this: self.read(decoder=l0_fits_access_decoder)
                    paths = self.get_paths_for_modstate_and_task(modstate, task_type)

                    # establish empty lists for this task type AND modstate
                    datetimes = []
                    average_values = []
                    rms_values = []

                    for path in paths:
                        frame = L0FitsAccess.from_path(path)
                        data = frame.data.astype(float)
                        exposure_time_sec = frame.fpa_exposure_time_ms / 1000

                        # Mean and RMS for Frame
                        normalized_mean = self.compute_normalized_mean(data, exposure_time_sec)
                        normalized_rms = self.compute_normalized_rms(data, exposure_time_sec)

                        # accumulate each value into its list
                        datetimes.append(datetime.fromisoformat(frame.time_obs))
                        average_values.append(normalized_mean)
                        rms_values.append(normalized_rms)

                    # now sort the lists by datetime
                    order = sorted(range(len(datetimes)), key=datetimes.__getitem__)
                    datetimes = [datetimes[i] for i in order]
                    average_values = [average_values[i] for i in order]
                    rms_values = [rms_values[i] for i in order]

                    # create the L0QualityData for this task type AND modstate
                    l0_quality_data = L0QualityData(
                        datetimes=tuple(datetimes),
                        average_values=tuple(average_values),
                        rms_values=tuple(rms_values),
                    )

                    # modstate is int or None
                    # eventually this will be the key of a json object - `null` cannot be a json object key
                    modstate_key = "" if modstate is None else str(modstate)
                    intermediate_l0_quality_data_segmented_first_by_ip_task_and_then_by_modstate[
                        task_type
                    ][modstate_key] = l0_quality_data

        return intermediate_l0_quality_data_segmented_first_by_ip_task_and_then_by_modstate

    @staticmethod
    def compute_normalized_rms(data: np.ndarray, exposure_time_sec: float) -> float:
        r"""
        Compute the normalized rms of a single frame.

        Defined as

        .. math::

            RMS = \frac{\sqrt{\left<D^2\right>}}{t}

        where :math:`D` is the data array, :math:`t` is the exposure time, in seconds, and :math:`\left< \right>`
        denotes the average.
        """
        squared_mean = np.nanmean(data**2)
        return np.sqrt(squared_mean) / exposure_time_sec

    @staticmethod
    def compute_normalized_mean(data: np.ndarray, exposure_time_sec: float) -> float:
        r"""
        Compute the normalized mean of a single frame.

        Defined as

        .. math::

            \mathrm{M} = \left<D\right>/t

        where :math:`D` is the data array, :math:`t` is the exposure time, in seconds, and :math:`\left< \right>`
        denotes the average.
        """
        return np.nanmean(data) / exposure_time_sec

    def compute_and_write_l0_quality_metrics(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write L0 metrics to disk."""
        self.compute_and_write_dataset_average(segmented_quality_data)
        self.compute_and_write_dataset_rms(segmented_quality_data)
        self.compute_and_write_frame_average(segmented_quality_data)
        self.compute_and_write_frame_rms(segmented_quality_data)

    def compute_and_write_dataset_average(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write DATASET_AVERAGE quality metric."""
        header = ("Task Type", "Dataset Average (adu / sec)")
        rows = [header]
        for task_type, l0_data_by_mod in segmented_quality_data.items():
            # combine all of the average value lists for each modstate into a single list for the task
            average_values = list(
                chain.from_iterable(l0_data.average_values for l0_data in l0_data_by_mod.values())
            )
            if average_values:
                row = (task_type, str(round(np.mean(average_values), 2)))
                rows.append(row)
        table_data = TableData(rows=tuple(rows))
        metric = QualityMetric(
            name="Average Across Dataset",
            description="This metric is the calculated mean intensity value across data from an "
            "instrument program task type used in the creation of an entire L1 "
            "dataset.",
            metric_code=MetricCode.dataset_average,
            table_data=[table_data],
        )
        # NOTE 1: QualityValueEncoder
        # NOTE 1: a BaseModel float field automatically converts np.float32 to python float
        # NOTE 2: QualityDataEncoder
        # NOTE 2: a BaseModel datetime field automatically converts to iso 8601 str with mode="json"
        # NOTE 2: a BaseModel FiniteFloat field inherently rejects `nan` and `inf` values
        self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_dataset_rms(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write DATASET_RMS quality metric."""
        header = ("Task Type", "Dataset RMS (adu / sec)")
        rows = [header]
        for task_type, l0_data_by_mod in segmented_quality_data.items():
            # combine all of the rms value lists for each modstate into a single list for the task
            rms_values = list(
                chain.from_iterable(l0_data.rms_values for l0_data in l0_data_by_mod.values())
            )
            if rms_values:
                row = (task_type, str(round(np.mean(rms_values), 2)))
                rows.append(row)
        table_data = TableData(rows=tuple(rows))
        metric = QualityMetric(
            name="Dataset RMS",
            description="This metric is the calculated root mean square intensity value across data"
            " from an instrument program task type used in the creation of an entire "
            "L1 dataset.",
            metric_code=MetricCode.dataset_rms,
            table_data=[table_data],
        )
        # NOTE 1: QualityValueEncoder
        # NOTE 1: a BaseModel float field automatically converts np.float32 to python float
        # NOTE 2: QualityDataEncoder
        # NOTE 2: a BaseModel datetime field automatically converts to iso 8601 str with mode="json"
        # NOTE 2: a BaseModel FiniteFloat field inherently rejects `nan` and `inf` values
        self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_frame_average(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write FRAME_AVERAGE quality metric."""
        for task_type, l0_data_by_mod in segmented_quality_data.items():
            warnings_computed = False
            warnings = None
            series_data = {}
            for modstate, l0_data in l0_data_by_mod.items():
                if l0_data.has_values:
                    # only compute warnings for the first modstate encountered
                    if not warnings_computed:
                        warnings = self._format_warnings(
                            self._find_iqr_outliers(
                                datetimes=l0_data.datetimes, values=l0_data.average_values
                            )
                        )
                        warnings_computed = True
                    time_series = TimeSeriesData(
                        x_values=l0_data.datetimes,
                        y_values=l0_data.average_values,
                    )
                    # for this task type AND modstate
                    series_data[modstate] = time_series

            # don't write anything if there is no data for the task type
            if not series_data:
                continue

            xy_data = XYData(
                xlabel="Time",
                ylabel="Average Value (adu / sec)",
                series_data=series_data,
                series_name="Modstate",
            )
            metric = QualityMetric(
                name=f"Average Across Frame - {task_type.upper()}",
                description=f"Average intensity value across frames of task type {task_type}. One measurement is taken per frame in each task type.",
                metric_code=MetricCode.frame_average,
                facet=task_type.upper(),
                plot_data=[xy_data],
                warnings=warnings,
            )
            # NOTE 1: QualityValueEncoder
            # NOTE 1: a BaseModel float field automatically converts np.float32 to python float
            # NOTE 2: QualityDataEncoder
            # NOTE 2: a BaseModel datetime field automatically converts to iso 8601 str with mode="json"
            # NOTE 2: a BaseModel FiniteFloat field inherently rejects `nan` and `inf` values
            # write one file per task type
            self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_frame_rms(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write FRAME_RMS quality metric."""
        for task_type, l0_data_by_mod in segmented_quality_data.items():
            warnings_computed = False
            warnings = None
            series_data = {}
            for modstate, l0_data in l0_data_by_mod.items():
                if l0_data.has_values:
                    # only compute warnings for the first modstate encountered
                    if not warnings_computed:
                        warnings = self._format_warnings(
                            self._find_iqr_outliers(
                                datetimes=l0_data.datetimes, values=l0_data.rms_values
                            )
                        )
                        warnings_computed = True
                    time_series = TimeSeriesData(
                        x_values=l0_data.datetimes,
                        y_values=l0_data.rms_values,
                    )
                    # for this task type AND modstate
                    series_data[modstate] = time_series

            # don't write anything if there is no data for the task type
            if not series_data:
                continue

            xy_data = XYData(
                xlabel="Time",
                ylabel="RMS (adu / sec)",
                series_data=series_data,
                series_name="Modstate",
            )
            metric = QualityMetric(
                name=f"Root Mean Square (RMS) Across Frame - {task_type.upper()}",
                description=f"RMS value across frames of task type {task_type}. One measurement is taken per frame in each task type.",
                metric_code=MetricCode.frame_rms,
                facet=task_type.upper(),
                plot_data=[xy_data],
                warnings=warnings,
            )
            # NOTE 1: QualityValueEncoder
            # NOTE 1: a BaseModel float field automatically converts np.float32 to python float
            # NOTE 2: QualityDataEncoder
            # NOTE 2: a BaseModel datetime field automatically converts to iso 8601 str with mode="json"
            # NOTE 2: a BaseModel FiniteFloat field inherently rejects `nan` and `inf` values
            # write one file per task type
            self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)


class L1Metric:
    """
    Class for collecting L1 quality metric data while frames are being opened before storing on disk.

    Parameters
    ----------
    storage_method
        The callable used to execute the storage
    value_source
        The source of the value being stored
    value_function
        The function to return the values
    """

    def __init__(
        self,
        storage_method: Callable,
        value_source: list[str] | str,
        value_function: Callable | None = None,
    ):
        self.storage_method = storage_method
        self.value_source = value_source
        self.values = []
        self.datetimes = []
        self.value_function = value_function

    def append_value(self, frame: L1QualityFitsAccess) -> None:
        """
        Append datetime from the frame to the list of datetimes.

        If a value_function was provided, apply it to the given source attribute and append to
        self.values. Otherwise, append the attribute value itself to self.values.  If multiple
        sources provided, append a list of the source attributes to self.values.

        Parameters
        ----------
        frame
            The input frame

        Returns
        -------
        None
        """
        self.datetimes.append(frame.time_obs)
        if self.value_function:
            self.values.append(self.value_function(getattr(frame, self.value_source)))
            return
        if isinstance(self.value_source, list):
            multiple_values = [getattr(frame, source, None) for source in self.value_source]
            self.values.append(multiple_values)
            return
        self.values.append(getattr(frame, self.value_source))

    @property
    def has_values(self):
        return len(self.values) > 0

    def store_metric(self):
        """Remove None values from a single-value values list (and also remove corresponding indices from datetimes) then send to the provided storage method."""
        # Get indices of non-None values and only use those.
        # Use multi-valued lists as is to be handled in the applicable storage_method.
        indices = [i for i, val in enumerate(self.values) if val is not None]
        d = [self.datetimes[i] for i in indices]
        v = [self.values[i] for i in indices]
        # Get signature of storage method and call with applicable args
        storage_method_sig = signature(self.storage_method)
        if storage_method_sig.parameters.get("datetimes", False):
            self.storage_method(datetimes=d, values=v)
            return
        self.storage_method(values=v)


class QualityL1Metrics(WorkflowTaskBase, QualityMixin):
    """Task class supporting the generation of quality metrics for the L0 data."""

    def run(self) -> None:
        """Run method for this task."""
        metrics = [
            L1Metric(storage_method=self.quality_store_light_level, value_source="light_level"),
            L1Metric(storage_method=self.quality_store_health_status, value_source="health_status"),
            L1Metric(
                storage_method=self.quality_store_ao_status_and_fried_parameter,
                value_source=["ao_status", "fried_parameter", "num_out_of_bounds_ao_values"],
            ),
        ]

        with self.telemetry_span("Reading L1 frames"):
            paths = list(self.read(tags=[Tag.calibrated(), Tag.frame()]))

        with self.telemetry_span("Calculating L1 quality metrics"):
            for metric in metrics:
                with self.telemetry_span(f"Calculating L1 metric {metric.value_source}"):
                    for path in paths:
                        frame = L1QualityFitsAccess.from_path(path)
                        metric.append_value(frame=frame)

        with self.telemetry_span("Sending lists for storage"):
            for metric in metrics:
                if metric.has_values:
                    metric.store_metric()
