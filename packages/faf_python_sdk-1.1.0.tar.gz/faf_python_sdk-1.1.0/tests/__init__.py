"""FAF SDK tests"""
