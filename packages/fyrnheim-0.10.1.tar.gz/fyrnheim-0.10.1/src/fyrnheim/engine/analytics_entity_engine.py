"""Projection engine for AnalyticsEntity: state fields + activity-derived measures.

M060 — Ibis push-down rewrite. The heart of this module,
:func:`project_analytics_entity`, returns an Ibis expression composed of
``filter`` -> ``group_by`` -> ``aggregate`` over JSON payload extracts.
The backend (DuckDB or BigQuery) executes the projection server-side; only
the small per-group aggregation result is ever materialised on the client.

## JSON-extract portability

The JSON payload arrives as a string column. We use Ibis's JSON primitives
to extract scalar fields portably:

* ``col.cast("json")["key"].unwrap_as("string")`` — extracts the *unquoted*
  string value of a JSON string scalar, returning NULL for non-string JSON
  scalars (numbers, booleans, JSON null). Compiles to a typed projection on
  both DuckDB and BigQuery.
* ``col.cast("json")["key"].try_cast("string")`` — returns the raw JSON
  text of the scalar (``"hello"`` with quotes, ``30``, ``true``, ``null``).
  Portable: compiles to ``TRY_CAST(... AS TEXT)`` on DuckDB and
  ``SAFE_CAST(... AS STRING)`` on BigQuery. Used for **type-preserving**
  extraction — the text is parsed with ``json.loads`` client-side to
  restore the original Python scalar type (str / int / float / bool).
* ``col.cast("json")["key"].unwrap_as("float64")`` — numeric coercion;
  returns NULL for string or boolean JSON scalars. For ``sum`` parity with
  the legacy pandas ``float(val)`` behaviour, numeric-strings (e.g.
  ``{"amount": "250"}``) are recovered via a ``coalesce`` with
  ``unwrap_as("string").try_cast("float64")``, and boolean JSON scalars
  are coerced to 1.0/0.0 via ``unwrap_as("bool").cast("float64")`` to
  mirror Python's ``float(True) == 1.0`` / ``float(False) == 0.0``.

## Type preservation for state fields and the ``latest`` measure

Legacy pandas returned the raw JSON-decoded Python value for state fields
(``latest``/``first``/``coalesce``) and the ``latest`` measure. SQL columns
are fixed-type, so we push down the aggregation producing **JSON text**
(via ``try_cast("string")``) and parse each value back to its original
Python type on the client after ``.execute()``. This preserves the
mixed-type contract (e.g. ``{"age": 30}`` → Python ``int`` 30,
``{"is_active": true}`` → Python ``bool`` True, ``{"plan": "pro"}`` →
Python ``str`` "pro"). The heavy grouping work still pushes down to the
backend — only the one-row-per-group result is post-processed.

## ``field_changed`` event shape

``_extract_field_value`` in the legacy pandas implementation branched on
``event_type``:

* ``row_appeared`` -> ``payload[field_name]``
* ``field_changed`` -> ``payload.new_value`` iff ``payload.field_name == field_name``,
  else ``None`` (never falls back to ``payload[field_name]``)
* anything else -> ``payload[field_name]`` (flat lookup fallback)

In Ibis this is a per-event ``CASE WHEN`` producing a ``resolved_value``
sub-expression consumed by the aggregation — see ``_resolved_value_for_field``.
The ordering of the WHEN arms is load-bearing: the field-name match
(``new_value``) must be checked before the general ``field_changed`` NULL
arm, or a matching event would be dropped.

## ``computed_fields``

Still evaluated in Python (``eval``). After the aggregation expression is
built, if any computed fields exist we ``.execute()`` the (now small)
result, apply the computed fields in pandas, and wrap the frame back in
``ibis.memtable``. The heavy grouping work still pushes down.
"""

from __future__ import annotations

import json
from typing import Any

import ibis
import numpy as np
import pandas as pd
from ibis.expr.types import BooleanValue, StringValue, Table

from fyrnheim.core.analytics_entity import AnalyticsEntity, Measure, StateField


class _RowProxy:
    """Proxy object that allows ``t.field_name`` access on a dict row.

    Supports expressions like ``t.email.split('@')[1].lower()`` by returning
    the actual value from the row dict on attribute access. Retained for
    the Python-evaluated ``computed_fields`` path.
    """

    def __init__(self, row_dict: dict[str, Any]) -> None:
        self._data = row_dict

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            return super().__getattribute__(name)
        try:
            return self._data[name]
        except KeyError:
            raise AttributeError(f"No field '{name}' in row") from None


# ---------------------------------------------------------------------------
# Ibis expression helpers
# ---------------------------------------------------------------------------


def _payload_json(events: Table) -> Any:
    """Cast the raw payload string column to Ibis JSON."""
    return events.payload.cast("json")


def _extract_as_string(events: Table, field: str) -> StringValue:
    """Extract ``payload[field]`` as a string scalar, NULL on type mismatch."""
    return _payload_json(events)[field].unwrap_as("string")


def _extract_as_float(events: Table, field: str) -> Any:
    """Extract ``payload[field]`` as a float scalar, NULL on non-numeric.

    For parity with the legacy pandas ``sum`` aggregation (which accepted
    numeric strings via ``float(val)``), numeric-string values are recovered
    by coalescing with ``unwrap_as("string").try_cast("float64")``. Boolean
    JSON scalars are also recovered as 1.0 / 0.0 to mirror Python's
    ``float(True) == 1.0`` / ``float(False) == 0.0`` coercion used by the
    legacy ``_compute_measure`` sum branch; ``unwrap_as("bool")`` returns
    SQL NULL for non-boolean JSON values on both DuckDB and BigQuery, so
    the coalesce fallback chain remains correct.
    """
    pj = _payload_json(events)[field]
    direct = pj.unwrap_as("float64")
    from_string = pj.unwrap_as("string").try_cast("float64")
    from_bool = pj.unwrap_as("bool").cast("float64")
    return ibis.coalesce(direct, from_string, from_bool)


def _extract_as_json_text(events: Table, field: str) -> StringValue:
    """Extract ``payload[field]`` as raw JSON text, preserving scalar type.

    Uses ``try_cast("string")`` on the JSON value: produces quoted string
    text (``"hello"``), numeric text (``30``), boolean text (``true``), or
    (on DuckDB) the text ``"null"`` for JSON null values. Missing keys
    produce SQL NULL. The caller parses the text back with ``json.loads``
    to recover the original Python scalar type.
    """
    return _payload_json(events)[field].try_cast("string")


def _is_non_null_json_text(json_text: StringValue) -> BooleanValue:
    """Predicate: the JSON-text value is neither SQL NULL nor JSON ``null``.

    On DuckDB, ``TRY_CAST(JSON 'null' AS TEXT)`` returns the string
    ``'null'``; on BigQuery, ``SAFE_CAST(JSON 'null' AS STRING)`` returns
    SQL NULL. This predicate handles both cases uniformly so downstream
    aggregations skip JSON null values (matching legacy behaviour of
    ignoring ``None`` values in the pandas loop).
    """
    return json_text.notnull() & (json_text != "null")


def _resolved_value_for_field(events: Table, field: str) -> StringValue:
    """Per-event ``resolved_value`` CASE WHEN matching ``_extract_field_value``.

    Returns the JSON-text representation of the resolved value, to be parsed
    back to the original Python scalar type on the client.

    * ``event_type == 'field_changed' AND payload.field_name == <field>`` ->
      ``payload.new_value`` as JSON text
    * ``event_type == 'field_changed' AND payload.field_name != <field>`` ->
      NULL (matching the legacy ``_extract_field_value`` early return; a
      ``field_changed`` event targeting a *different* field must not leak a
      sibling key from the same payload).
    * otherwise -> ``payload[<field>]`` as JSON text

    Both the ``row_appeared`` branch and the "anything else" fallback in the
    legacy code use the flat payload lookup, so they collapse into the ELSE
    branch here. The ordering of the WHEN arms matters: the field-name match
    must be evaluated before the general ``field_changed`` NULL arm.
    """
    pj = _payload_json(events)
    is_field_changed = events.event_type == "field_changed"
    field_name_match = is_field_changed & (
        pj["field_name"].unwrap_as("string") == field
    )
    new_value = pj["new_value"].try_cast("string")
    fallback = pj[field].try_cast("string")
    return ibis.cases(
        (field_name_match, new_value),
        (is_field_changed, ibis.null().cast("string")),
        else_=fallback,
    )


def _latest_non_null(
    events: Table, resolved: StringValue, where: BooleanValue | None = None
) -> StringValue:
    """Latest non-null ``resolved`` value by ``events.ts``.

    ``resolved`` is assumed to be the JSON-text representation, so
    "non-null" means both SQL-NOT-NULL and JSON-value-not-null (see
    :func:`_is_non_null_json_text`).
    """
    cond = _is_non_null_json_text(resolved)
    if where is not None:
        cond = cond & where
    return resolved.argmax(events.ts, where=cond)


def _first_non_null(
    events: Table, resolved: StringValue, where: BooleanValue | None = None
) -> StringValue:
    """Earliest non-null ``resolved`` value by ``events.ts`` (argmin)."""
    cond = _is_non_null_json_text(resolved)
    if where is not None:
        cond = cond & where
    return resolved.argmin(events.ts, where=cond)


def _state_field_expr(events: Table, sf: StateField) -> Any:
    """Build the aggregation expression for a single state field.

    Produces a JSON-text column — the caller parses it back to a Python
    scalar (see :func:`_parse_json_text_column`).
    """
    if sf.strategy == "latest":
        resolved = _resolved_value_for_field(events, sf.field)
        return _latest_non_null(events, resolved, where=events.source == sf.source)
    if sf.strategy == "first":
        resolved = _resolved_value_for_field(events, sf.field)
        return _first_non_null(events, resolved, where=events.source == sf.source)
    if sf.strategy == "coalesce":
        # Nested coalesce(latest_from(source[0]), latest_from(source[1]), ...).
        # Each arm is a per-source latest aggregation. Because each arm
        # filters on source=X, argmax ignores rows from other sources.
        resolved = _resolved_value_for_field(events, sf.field)
        per_source = [
            _latest_non_null(events, resolved, where=events.source == src)
            for src in (sf.priority or [])
        ]
        if not per_source:
            return ibis.null().cast("string")
        if len(per_source) == 1:
            return per_source[0]
        return ibis.coalesce(*per_source)
    # pragma: no cover — StateField.strategy is a Literal of the three above
    return ibis.null().cast("string")


def _measure_expr(events: Table, measure: Measure) -> Any:
    """Build the aggregation expression for a single measure."""
    is_activity = events.event_type == measure.activity

    if measure.aggregation == "count":
        # Count rows matching the activity. Groups with no match emit 0.
        return events.count(where=is_activity)

    if measure.aggregation == "sum":
        # Sum payload[field] as float, filtered to activity rows. Uses
        # ``_extract_as_float`` which coalesces a direct float unwrap with a
        # string-to-float try_cast — so numeric-strings (e.g.
        # ``{"amount": "250"}``) are included for parity with the legacy
        # pandas ``float(val)`` behaviour. Truly non-numeric values still
        # coerce to NULL and are ignored by SUM. Empty groups emit 0.0.
        field = measure.field  # Pydantic guarantees this for sum
        assert field is not None
        amount = _extract_as_float(events, field)
        return ibis.coalesce(amount.sum(where=is_activity), 0.0)

    if measure.aggregation == "latest":
        # Latest non-null payload[field] among activity rows, returned as
        # JSON text. The caller parses it back to its original Python type
        # (int/float/str/bool) to match the legacy pandas semantics of
        # returning the raw JSON-decoded value.
        field = measure.field
        assert field is not None
        resolved = _extract_as_json_text(events, field)
        return _latest_non_null(events, resolved, where=is_activity)

    # pragma: no cover — Measure.aggregation is a Literal
    return ibis.null()


def _relevance_filter(
    events: Table, analytics_entity: AnalyticsEntity
) -> Table:
    """Apply the M057 relevance filter as an Ibis ``.filter()``.

    An event is relevant if its ``source`` is referenced by any state field
    (including every source in a coalesce priority list) OR its
    ``event_type`` matches any measure activity. When both sets are empty
    (defensive; Pydantic requires at least one state_field or measure)
    no filter is applied.
    """
    relevant_sources: set[str] = set()
    for sf in analytics_entity.state_fields:
        if sf.strategy == "coalesce":
            relevant_sources.update(sf.priority or [])
        else:
            relevant_sources.add(sf.source)
    relevant_activities = {m.activity for m in analytics_entity.measures}

    if not relevant_sources and not relevant_activities:
        return events

    # Build the predicate as source.isin(...) | event_type.isin(...).
    # ``isin`` over an empty collection evaluates to false, so an entity with
    # no referenced sources still correctly reduces to event_type matching.
    sources_list = sorted(relevant_sources)
    activities_list = sorted(relevant_activities)

    if sources_list and activities_list:
        pred = events.source.isin(sources_list) | events.event_type.isin(
            activities_list
        )
    elif sources_list:
        pred = events.source.isin(sources_list)
    else:
        pred = events.event_type.isin(activities_list)

    return events.filter(pred)


def _build_aggregation_expression(
    enriched_events: Table, analytics_entity: AnalyticsEntity
) -> Table:
    """Build the full filter -> group_by -> aggregate Ibis expression.

    The returned expression produces one row per group with columns
    [group_key, *state_field.name, *measure.name]. ``computed_fields`` are
    NOT applied here.
    """
    filtered = _relevance_filter(enriched_events, analytics_entity)

    group_key = (
        "canonical_id" if "canonical_id" in filtered.schema().names else "entity_id"
    )

    agg_kwargs: dict[str, Any] = {}
    for sf in analytics_entity.state_fields:
        agg_kwargs[sf.name] = _state_field_expr(filtered, sf)
    for m in analytics_entity.measures:
        agg_kwargs[m.name] = _measure_expr(filtered, m)

    return filtered.group_by(group_key).aggregate(**agg_kwargs)


def _parse_json_text_cell(value: Any) -> Any:
    """Parse a JSON-text scalar back to its Python type.

    ``None`` / ``NaN`` pass through unchanged. A malformed value (should
    not occur for data that originated as a valid JSON payload scalar) is
    returned as-is to keep the engine forgiving.
    """
    if value is None:
        return None
    if isinstance(value, float) and pd.isna(value):
        return None
    if not isinstance(value, str):
        # Some backends may already return a typed value — pass through.
        return value
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return value


# Module-level type sets — the source of truth for what
# :func:`_coerce_to_arrow_friendly_dtype` recognises as an
# Arrow-friendly scalar. Kept as exact ``type`` sets (not ``isinstance``
# hierarchies) so that ``bool`` — a subclass of ``int`` — never leaks
# into the int branch; see the helper docstring for the invariant.
_BOOL_TYPES: set[type] = {bool, np.bool_}
_INT_TYPES: set[type] = {
    int,
    np.int8,
    np.int16,
    np.int32,
    np.int64,
    np.uint8,
    np.uint16,
    np.uint32,
    np.uint64,
}
_FLOAT_TYPES: set[type] = {float, np.float16, np.float32, np.float64}


def _try_coerce_strings_to_numeric(
    non_null: list,
) -> tuple[list, bool] | None:
    """Attempt ``json.loads`` on string values, keeping numeric ones in place.

    Used by :func:`_coerce_to_arrow_friendly_dtype` for the tolerant-
    coercion branch that handles payloads storing a single logical
    numeric value inconsistently — as a JSON number in some rows and a
    JSON-quoted number in others (e.g. ``{"score": 11}`` in one row,
    ``{"score": "-5"}`` in another). After M060's push-down extraction
    and :func:`_parse_json_text_cell` normalisation the resulting
    column is a mix of Python ``int`` / ``float`` and ``str`` values,
    which the pure-type branches do not recognise.

    Iterates the non-null values; for each ``str`` it calls
    ``json.loads`` (catching ``ValueError`` / ``TypeError``) and keeps
    the parsed value only when its *strict* ``type(...)`` is ``int`` or
    ``float``. ``isinstance`` is deliberately avoided: ``json.loads`` of
    ``"true"`` / ``"false"`` returns a Python ``bool``, and
    ``isinstance(True, int)`` is ``True``; the strict check rejects
    bools and defers to the object-dtype fallback so PyArrow can still
    fail loudly on genuinely inconsistent data.

    Returns ``(coerced_values, saw_float)`` if every string parses
    cleanly to ``int`` or ``float``. Returns ``None`` if any string
    parses to a non-numeric type (``str``, ``bool``, ``None``, ``list``,
    ``dict``) or is unparseable — signalling "fall back to object
    dtype". ``saw_float`` is tracked across *all* values (both Python/
    numpy floats and strings that parse to float) so the caller knows
    whether to target ``Int64`` or ``Float64``.
    """
    out: list = []
    saw_float = False
    for v in non_null:
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
            except (ValueError, TypeError):
                return None
            if type(parsed) is int:
                out.append(parsed)
            elif type(parsed) is float:
                out.append(parsed)
                saw_float = True
            else:
                return None  # parsed to str/bool/None/list/dict — give up
        else:
            out.append(v)
            if type(v) in _FLOAT_TYPES:
                saw_float = True
    return out, saw_float


def _coerce_to_arrow_friendly_dtype(s: pd.Series) -> pd.Series:
    """Infer a pandas nullable dtype for an object series of Python or numpy scalars.

    After :func:`_parse_json_text_cell` we hold an object-dtype column of
    mixed Python or numpy scalars (``int`` + ``None``, ``float`` + ``None``,
    ``bool`` + ``None``, ``str`` + ``None``, or the numpy-scalar
    equivalents ``np.int64`` / ``np.float64`` / ``np.bool_`` etc. that
    BigQuery's Python client returns). PyArrow cannot infer a stable
    Arrow type across an object column that contains Python-scalar
    values interleaved with ``None`` — and
    ``ibis.memtable(df).to_pyarrow()`` (the BigQuery memtable-registration
    path) fails as a result. DuckDB silently tolerates the object dtype.

    To keep the projection Arrow-compatible without breaking the
    mixed-type contract for legitimately heterogeneous payloads, we
    inspect the *non-null* values and pick a clean nullable pandas
    dtype per column. The recognised type sets are the module-level
    :data:`_BOOL_TYPES`, :data:`_INT_TYPES`, and :data:`_FLOAT_TYPES`
    — the source of truth for which Python and numpy scalar types
    collapse to each Arrow-friendly pandas dtype:

    * all types ``<= _BOOL_TYPES``  -> ``"boolean"``
      (pandas nullable BooleanDtype)
    * all types ``<= _INT_TYPES``   -> ``pd.Int64Dtype()``
      (pandas nullable Int64)
    * all types ``<= _INT_TYPES | _FLOAT_TYPES`` -> ``"Float64"``
      (nullable Float64; covers all-float and int+float mixes including
      Python+numpy combinations)
    * all types ``== {str}``        -> ``object`` (Arrow handles object-str)
    * all types ``<= _INT_TYPES | _FLOAT_TYPES | {str}`` and every
      string parses to a Python ``int`` / ``float`` via ``json.loads``
      -> ``pd.Int64Dtype()`` (if no float was seen) or ``"Float64"``
      (otherwise). This is the M065 tolerant-coercion branch for
      payloads that store a numeric value inconsistently as a JSON
      number in some rows and a JSON-quoted number in others. Columns
      whose strings do not all parse cleanly to numeric fall through
      to the object dtype below — PyArrow still fails loudly for
      genuinely inconsistent data, which is the correct signal.
    * mixed / all-null / empty      -> ``object`` (caller's data model choice)

    Strict ``type(v) is int`` matching via ``{type(v) for v in non_null}``
    is used (not ``isinstance``) so a ``bool`` value — which is a
    subclass of ``int`` in Python — is not silently coerced to ``Int64``.
    Equivalently, ``np.bool_`` is a distinct type (not a subclass of
    the numpy integer scalars) and lives only in :data:`_BOOL_TYPES`.
    This is the guardrail that keeps the ``bool``-branch correct
    end-to-end.

    Subset matching (``types <= _INT_TYPES``) instead of equality lets
    Python+numpy mixes (e.g. ``{int, np.int64}``) land in the right
    branch without an explosion of per-combination checks.
    """
    non_null = s.dropna()
    if len(non_null) == 0:
        return s.astype(object)
    types = {type(v) for v in non_null}  # strict type(), NOT isinstance
    if types <= _BOOL_TYPES:
        return s.astype("boolean")
    if types <= _INT_TYPES:
        return s.astype(pd.Int64Dtype())
    if types <= _INT_TYPES | _FLOAT_TYPES:
        return s.astype("Float64")
    if types == {str}:
        return s.astype(object)
    # M065 tolerant-coercion branch: mixed numeric + numeric-string.
    if types <= _INT_TYPES | _FLOAT_TYPES | {str}:
        result = _try_coerce_strings_to_numeric(list(non_null))
        if result is not None:
            coerced, saw_float = result
            it = iter(coerced)
            rebuilt = [
                next(it)
                if not (v is None or (isinstance(v, float) and pd.isna(v)))
                else None
                for v in s
            ]
            target: Any = "Float64" if saw_float else pd.Int64Dtype()
            return pd.Series(rebuilt, index=s.index, dtype=object).astype(target)
    return s.astype(object)  # mixed / other — user's data model choice


def _parse_json_text_columns(
    df: pd.DataFrame, columns: list[str]
) -> pd.DataFrame:
    """Apply :func:`_parse_json_text_cell` to the given JSON-text columns.

    Operates in place on a copy and returns the updated frame. Columns
    missing from ``df`` (e.g. on an empty aggregation result) are ignored.
    Each parsed column is passed through
    :func:`_coerce_to_arrow_friendly_dtype` so the resulting frame is
    safe to register as an ``ibis.memtable`` and convert to PyArrow on
    backends (BigQuery) that require a stable Arrow schema.
    """
    out = df.copy()
    for col in columns:
        if col in out.columns:
            # Build the parsed column via a list comprehension rather than
            # ``.map`` so pandas does not auto-infer a dtype. ``.map`` would
            # helpfully promote ``[int, None]`` to ``float64`` with NaN,
            # hiding the real Python scalar types from
            # :func:`_coerce_to_arrow_friendly_dtype`. Constructing the
            # series with ``dtype=object`` preserves the exact Python
            # values the helper needs to branch on.
            parsed = pd.Series(
                [_parse_json_text_cell(v) for v in out[col]],
                index=out[col].index,
                dtype=object,
            )
            out[col] = _coerce_to_arrow_friendly_dtype(parsed)
    return out


def project_analytics_entity(
    enriched_events: Table,
    analytics_entity: AnalyticsEntity,
) -> Table:
    """Project one row per entity from enriched events using an AnalyticsEntity.

    Returns an Ibis expression composed of ``filter`` -> ``group_by`` ->
    ``aggregate`` over JSON payload extraction. State fields and the
    ``latest`` measure are pushed down as JSON-text extracts and parsed
    back to Python scalars on the client (preserving mixed int/float/str/
    bool types). When the entity declares ``computed_fields``, the
    post-processed frame is additionally passed through ``eval`` for each
    computed column. In all cases the heavy grouping work pushes down to
    the backend — only the one-row-per-group result is materialised.

    Args:
        enriched_events: Ibis table with columns ``source``, ``entity_id``,
            ``ts``, ``event_type``, ``payload``, and optionally
            ``canonical_id``.
        analytics_entity: :class:`AnalyticsEntity` defining state fields,
            measures, and computed fields.

    Returns:
        Ibis ``Table`` (an ``ibis.memtable``) with one row per entity plus
        all state, measure, and computed field columns. State and
        ``latest``-measure columns carry Python-scalar values (object
        dtype) to match the legacy pandas contract.
    """
    agg_expr = _build_aggregation_expression(enriched_events, analytics_entity)

    # Columns that were pushed down as JSON text and need client-side parsing.
    json_text_columns = [sf.name for sf in analytics_entity.state_fields] + [
        m.name for m in analytics_entity.measures if m.aggregation == "latest"
    ]

    group_key = (
        "canonical_id"
        if "canonical_id" in enriched_events.schema().names
        else "entity_id"
    )
    ordered_cols = (
        [group_key]
        + [sf.name for sf in analytics_entity.state_fields]
        + [m.name for m in analytics_entity.measures]
    )

    df = agg_expr.execute()
    if not df.empty:
        df = df[ordered_cols]
        df = _parse_json_text_columns(df, json_text_columns)
    else:
        # Preserve column set even when the aggregation yielded zero rows.
        df = df.reindex(columns=ordered_cols)

    if not analytics_entity.computed_fields:
        return ibis.memtable(df)

    if df.empty:
        # Pre-allocate computed-field columns so the empty frame has the
        # right shape even when there are no rows to apply over.
        for cf in analytics_entity.computed_fields:
            df[cf.name] = pd.Series([], dtype=object)
        return ibis.memtable(df)

    for cf in analytics_entity.computed_fields:
        df[cf.name] = df.apply(
            lambda r, expr=cf.expression: eval(  # noqa: S307
                expr,
                {"__builtins__": {}},
                {**r.to_dict(), "t": _RowProxy(r.to_dict())},
            ),
            axis=1,
        )

    return ibis.memtable(df)
