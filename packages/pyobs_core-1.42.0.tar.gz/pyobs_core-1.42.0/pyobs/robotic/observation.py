from __future__ import annotations
from collections import UserList
from enum import StrEnum
from typing import Any, TYPE_CHECKING
from astropydantic import AstroPydanticTime  # type: ignore

from pyobs.object import Object
from pyobs.utils.time import Time
from pyobs.robotic.task import Task
from pyobs.utils.serialization import BaseModel

if TYPE_CHECKING:
    from pyobs.robotic import TaskArchive


class ObservationState(StrEnum):
    PENDING = "pending"
    COMPLETED = "completed"
    IN_PROGRESS = "in_progress"
    ABORTED = "aborted"
    CANCELED = "canceled"
    FAILED = "failed"


class Observation(BaseModel):
    """A scheduled task."""

    id: Any | None = None
    task: Task | Any | None = None
    start: AstroPydanticTime
    end: AstroPydanticTime
    state: ObservationState = ObservationState.PENDING

    def __str__(self) -> str:
        return (
            f"Observation {self.id} of {self.task.name} (#{self.task.id}) "
            f"from {self.start} to {self.end} [{self.state.value}]"
        )

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Observation):
            return bool(self.task.id == other.task.id and self.start == other.start and self.end == other.end)
        return super().__eq__(other)

    def __ne__(self, other: object) -> bool:
        if isinstance(other, Observation):
            return bool(self.task.id != other.task.id or self.start != other.start or self.end != other.end)
        return super().__ne__(other)

    def __lt__(self, other: object) -> bool:
        if isinstance(other, Observation):
            return bool(self.start < other.start)
        raise NotImplementedError

    def __gt__(self, other: object) -> bool:
        if isinstance(other, Observation):
            return bool(self.start > other.start)
        raise NotImplementedError

    def __le__(self, other: object) -> bool:
        if isinstance(other, Observation):
            return bool(self.start <= other.start)
        raise NotImplementedError

    def __ge__(self, other: object) -> bool:
        if isinstance(other, Observation):
            return bool(self.start >= other.start)
        raise NotImplementedError

    def model_dump(self, use_task_id: bool = False, **kwargs: Any) -> dict[str, Any]:
        if use_task_id and isinstance(self.task, Task):
            data = self.model_copy()
            data.task = self.task.id
            return data.model_dump(**kwargs)
        else:
            return super().model_dump(**kwargs)

    async def fetch_task(self, task_archive: TaskArchive) -> None:
        """Fetch a task from the task archive."""
        if not isinstance(self.task, Task):
            self.task = await task_archive.get_task(self.task)


class ObservationList(UserList[Observation], Object):  # noqa: F821
    def __init__(self, observations: list[Observation] | None = None):
        UserList.__init__(self, observations)

    def filter(
        self, state: ObservationState | None = None, task_id: int | None = None, after: Time | None = None
    ) -> ObservationList:
        new_list = self.data
        if state is not None:
            new_list = [obs for obs in new_list if obs.state == state]
        if task_id is not None:
            new_list = [obs for obs in new_list if obs.task.id == task_id]
        if after is not None:
            new_list = [obs for obs in new_list if obs.start >= after]
        return ObservationList(new_list)

    def model_dump(self, **kwargs: Any) -> list[dict[str, Any]]:
        return [obs.model_dump(**kwargs) for obs in self.data]

    def model_validate(self, data: list[dict[str, Any]], **kwargs: Any) -> ObservationList:
        return ObservationList([self.pyobs_model_validate(Observation, obs, **kwargs) for obs in data])


__all__ = ["Observation", "ObservationState", "ObservationList"]
