# heru

Unified CLI for AI coding agents. One command, any engine.

```bash
heru "implement auth" --engine claude --model claude-opus-4-6
heru "fix the bug" --engine codex --model gpt-5.4-high
heru --continue abc-123 "add tests"
heru "write docs"
```

Supports: codex, claude, copilot, gemini, opencode, goz.

All engines output the same normalized JSONL event format, regardless of which engine runs underneath.

## Install

```bash
pip install heru
```

## Usage

```bash
heru "your prompt here"                          # uses default engine
heru "your prompt" --engine claude                # specify engine
heru "your prompt" --engine codex --model o3      # specify engine and model
heru --continue <session-id> "continue working"   # resume a session
```

## Part of litehive

heru is the engine layer for [litehive](https://github.com/alexeygrigorev/litehive), an autonomous task execution system for software projects.
