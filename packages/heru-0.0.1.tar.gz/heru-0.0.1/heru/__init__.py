"""heru - Unified CLI for AI coding agents. One command, any engine."""

from heru.__version__ import __version__

__all__ = ["__version__"]
