"""heru CLI - Unified interface for AI coding agents."""

import argparse

from heru.__version__ import __version__


def main():
    parser = argparse.ArgumentParser(
        description="Unified CLI for AI coding agents. One command, any engine.",
    )
    parser.add_argument("prompt", nargs="?", help="The prompt to send to the agent")
    parser.add_argument("--engine", help="Engine to use (codex, claude, copilot, gemini, opencode, goz)")
    parser.add_argument("--model", help="Model override for the engine")
    parser.add_argument("--continue", dest="continue_session", metavar="SESSION_ID", help="Resume a previous session")
    parser.add_argument("--version", "-v", action="version", version=f"heru {__version__}")
    args = parser.parse_args()

    if not args.prompt and not args.continue_session:
        parser.print_help()
        return 1

    print(f"heru v{__version__} - coming soon")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
