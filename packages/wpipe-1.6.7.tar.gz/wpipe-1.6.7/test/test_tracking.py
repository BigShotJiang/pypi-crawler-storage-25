import os
import pytest
import sqlite3
import threading
from wpipe import Pipeline, PipelineTracker, CheckpointManager, step

# --- RE-PARCHE DE EMERGENCIA PARA ARREGLAR BUG DE WPIPE ---
from wsqlite import WSQLite
_db_connections = {}
_db_lock = threading.Lock()

def better_get_connection(self):
    db_path = getattr(self, "db_path", getattr(self, "db_name", "register.db"))
    with _db_lock:
        if db_path not in _db_connections:
            conn = sqlite3.connect(db_path, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            _db_connections[db_path] = conn
        return _db_connections[db_path]

WSQLite._get_connection = better_get_connection

DB_PATH = "test_tracking.db"
CP_PATH = "test_checkpoints"

@step()
def step_one(data):
    return {"step1": True}

@step()
def step_two(data):
    return {"step2": True}

@pytest.fixture
def cleanup():
    """Limpia los archivos de prueba antes y después."""
    files = [DB_PATH, DB_PATH + "-shm", DB_PATH + "-wal"]
    for f in files:
        if os.path.exists(f): os.remove(f)
    if os.path.exists(CP_PATH):
        import shutil
        shutil.rmtree(CP_PATH)
    yield
    for f in files:
        if os.path.exists(f): 
            try: os.remove(f)
            except: pass
    if os.path.exists(CP_PATH):
        import shutil
        try: shutil.rmtree(CP_PATH)
        except: pass

def test_pipeline_tracking(cleanup):
    """Prueba que el tracker registre la ejecución en la DB."""
    p = Pipeline(tracking_db=DB_PATH)
    p.set_steps([step_one, step_two])
    
    p.run({"input": 123})
    
    # Verificar persistencia
    tracker = PipelineTracker(DB_PATH)
    stats = tracker.get_stats()
    assert stats["total_pipelines"] >= 1

def test_checkpoint_manager(cleanup):
    """Prueba el guardado y recuperación de checkpoints."""
    mgr = CheckpointManager(CP_PATH)
    cp_id = "test_run"
    
    # Guardar estado
    mgr.save_checkpoint(cp_id, 0, "step_one", "success", {"val": 10})
    
    assert mgr.can_resume(cp_id) is True
    last = mgr.get_last_checkpoint(cp_id)
    assert last["step_order"] == 0
    assert last["data"]["val"] == 10
    
    # Limpiar
    mgr.clear_checkpoints(cp_id)
    assert mgr.can_resume(cp_id) is False

def test_pipeline_resume(cleanup):
    """Prueba que el pipeline pueda reanudar desde un checkpoint."""
    mgr = CheckpointManager(CP_PATH)
    cp_id = "resume_test"
    
    # Simular que el paso 0 ya terminó
    mgr.save_checkpoint(cp_id, 0, "step_one", "success", {"step1": True, "init": 5})
    
    p = Pipeline(verbose=True)
    p.set_steps([step_one, step_two])
    
    # Ejecutar con el manager y el ID de checkpoint
    result = p.run({"init": 5}, checkpoint_mgr=mgr, checkpoint_id=cp_id)
    
    assert result.get("step1") is True 
    assert result.get("step2") is True
