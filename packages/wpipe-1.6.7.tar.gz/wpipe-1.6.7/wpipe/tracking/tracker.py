"""
wpipe Pipeline Tracker - Professional Execution Tracking System using WSQLite.
"""

import json
import os
import uuid
from datetime import datetime
from typing import Any, Optional

from wsqlite import WSQLite

from wpipe.sqlite.tables_dto.tracker_models import (
    AlertConfigModel,
    AlertFiredModel,
    ComparisonModel,
    EventModel,
    PerformanceStatsModel,
    PipelineModel,
    PipelineRelationModel,
    StepHistoryModel,
    StepModel,
    SystemMetricsModel,
)

from .alerts import AlertManager
from .analysis import AnalysisManager
from .queries import QueryManager


def _safe_json_dumps(data: Any) -> str:
    """Safe JSON dump that handles non-serializable objects."""
    try:
        return json.dumps(data)
    except (TypeError, OverflowError):
        return json.dumps(str(data))


class Metric:
    """Constants for alert metrics."""

    PIPELINE_DURATION = "pipeline_duration_ms"
    STEP_DURATION = "step_duration_ms"
    ERROR_RATE = "error_rate"


class Severity:
    """Constants for alert severity levels."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


# --- PROFESSIONAL TABLE NAMING FOR LTS ---
class pipelines(PipelineModel):
    pass


class steps(StepModel):
    pass


class step_history(StepHistoryModel):
    pass


class performance_stats(PerformanceStatsModel):
    pass


class alerts_config(AlertConfigModel):
    pass


class alerts_fired(AlertFiredModel):
    pass


class events(EventModel):
    pass


class pipeline_relations(PipelineRelationModel):
    pass


class system_metrics(SystemMetricsModel):
    pass


class comparisons(ComparisonModel):
    pass


class PipelineTracker:
    """
    Unified Pipeline Tracker.

    Orchestrates registration, step tracking, alerts, and dashboard queries.
    """

    def __init__(self, db_path: str, config_dir: Optional[str] = None):
        self.db_path = db_path
        self.config_dir = os.path.abspath(config_dir or "pipeline_configs")

        # Table instances with professional names
        self.db_pipelines = WSQLite(pipelines, db_path)
        self.db_steps = WSQLite(steps, db_path)
        self.db_step_history = WSQLite(step_history, db_path)
        self.db_performance_stats = WSQLite(performance_stats, db_path)
        self.db_alerts_config = WSQLite(alerts_config, db_path)
        self.db_alerts_fired = WSQLite(alerts_fired, db_path)
        self.db_events = WSQLite(events, db_path)
        self.db_pipeline_relations = WSQLite(pipeline_relations, db_path)
        self.db_system_metrics = WSQLite(system_metrics, db_path)
        self.db_comparisons = WSQLite(comparisons, db_path)

        self._ensure_schema_up_to_date()

        self._alert_hooks = {}

        # Specialized Managers
        self.alerts = AlertManager(
            self.db_alerts_config, self.db_alerts_fired, self._alert_hooks
        )
        self.queries = QueryManager(
            self.db_pipelines,
            self.db_steps,
            self.db_alerts_config,
            self.db_alerts_fired,
            self.db_events,
        )
        self.analysis = AnalysisManager(
            self.db_pipelines, self.db_steps, self.db_step_history, self.db_alerts_fired
        )

    # ========================================
    # DELEGATED METHODS (Backward Compatibility)
    # ========================================

    def add_alert_threshold(self, *args, **kwargs):
        return self.alerts.add_alert_threshold(*args, **kwargs)

    def get_pipelines(self, *args, **kwargs):
        return self.queries.get_pipelines(*args, **kwargs)

    def get_pipeline(self, *args, **kwargs):
        return self.queries.get_pipeline(*args, **kwargs)

    def get_stats(self, *args, **kwargs):
        return self.analysis.get_stats(*args, **kwargs)

    def get_trend_data(self, *args, **kwargs):
        return self.analysis.get_trend_data(*args, **kwargs)

    def get_top_slow_steps(self, *args, **kwargs):
        return self.analysis.get_top_slow_steps(*args, **kwargs)

    def get_events(self, *args, **kwargs):
        return self.queries.get_events(*args, **kwargs)

    def get_fired_alerts(self, *args, **kwargs):
        return self.queries.get_fired_alerts(*args, **kwargs)

    def get_alert_thresholds(self, *args, **kwargs):
        return self.queries.get_alert_thresholds(*args, **kwargs)

    def get_states_analysis(self, *args, **kwargs):
        return self.analysis.get_states_analysis(*args, **kwargs)

    def get_pipelines_analysis(self, *args, **kwargs):
        return self.analysis.get_pipelines_analysis(*args, **kwargs)

    def get_table_data(self, *args, **kwargs):
        return self.analysis.get_table_data(*args, **kwargs)

    def get_pipeline_executions(self, *args, **kwargs):
        return self.queries.get_pipeline_executions(*args, **kwargs)

    # ========================================
    # CORE TRACKING LOGIC
    # ========================================

    def register_pipeline(self, name: str, steps: list, **kwargs) -> dict:
        pipeline_id = f"PIPE-{uuid.uuid4().hex[:8].upper()}"
        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir)
        safe_name = os.path.basename(os.path.normpath(name))
        yaml_path = os.path.join(self.config_dir, f"{safe_name}.yaml")
        if not os.path.exists(yaml_path):
            import yaml

            def _serialize_step(s):
                if hasattr(s, "to_dict"):
                    return s.to_dict()
                if isinstance(s, tuple):
                    return {
                        "type": "task",
                        "name": s[1] if len(s) > 1 else "unknown",
                        "version": s[2] if len(s) > 2 else "v1.0",
                        "func": str(s[0])
                    }
                return str(s)

            config = {
                "name": name,
                "registered_at": datetime.now().isoformat(),
                "step_count": len(steps),
                "steps": [_serialize_step(s) for s in steps],
            }
            with open(yaml_path, "w") as f:
                yaml.dump(config, f)

        model = PipelineModel(
            id=pipeline_id,
            name=name,
            worker_id=kwargs.get("worker_id"),
            worker_name=kwargs.get("worker_name"),
            input_data=(
                _safe_json_dumps(kwargs.get("input_data"))
                if kwargs.get("input_data")
                else None
            ),
            parent_pipeline_id=kwargs.get("parent_pipeline_id"),
            yaml_path=yaml_path,
        )
        self.db_pipelines.insert(model)
        if kwargs.get("parent_pipeline_id"):
            self.link_pipelines(kwargs.get("parent_pipeline_id"), pipeline_id)
        return {"pipeline_id": pipeline_id, "yaml_path": yaml_path}

    def complete_pipeline(
        self,
        pipeline_id: str,
        output_data: Optional[dict] = None,
        error_message: Optional[str] = None,
        error_step: Optional[str] = None,
    ) -> list:
        pipelines = self.db_pipelines.get_by_field(id=pipeline_id)
        if not pipelines:
            return []
        model = pipelines[0]
        started = datetime.fromisoformat(model.started_at)
        duration_ms = (datetime.now() - started).total_seconds() * 1000
        model.status = "error" if error_message else "completed"
        model.completed_at = datetime.now().isoformat()
        model.total_duration_ms = duration_ms
        model.output_data = _safe_json_dumps(output_data) if output_data else None
        model.error_message = error_message
        model.error_step = error_step
        self.db_pipelines.update(pipeline_id, model)
        return self.alerts.check_pipeline_alerts(
            pipeline_id, model.name, model.status, duration_ms, self.db_pipelines
        )

    def start_step(
        self, pipeline_id: str, step_order: int, step_name: str, **kwargs
    ) -> int:
        model = StepModel(
            pipeline_id=pipeline_id,
            step_order=step_order,
            step_name=step_name,
            step_version=kwargs.get("step_version"),
            step_type=kwargs.get("step_type", "task"),
            parent_step_id=kwargs.get("parent_step_id"),
            parallel_group=kwargs.get("parallel_group"),
            input_data=(
                _safe_json_dumps(kwargs.get("input_data"))
                if kwargs.get("input_data")
                else None
            ),
        )
        return self.db_steps.insert(model)

    def complete_step(
        self,
        step_id: int,
        output_data: Optional[dict] = None,
        error_message: Optional[str] = None,
        error_traceback: Optional[str] = None,
        pipeline_id: Optional[str] = None,
    ) -> list:
        steps = self.db_steps.get_by_field(id=step_id)
        if not steps:
            return []
        model = steps[0]
        started = datetime.fromisoformat(model.started_at)
        duration_ms = (datetime.now() - started).total_seconds() * 1000
        model.status = "error" if error_message else "completed"
        model.completed_at = datetime.now().isoformat()
        model.duration_ms = duration_ms
        model.output_data = _safe_json_dumps(output_data) if output_data else None
        model.error_message = error_message
        model.error_traceback = error_traceback
        self.db_steps.update(step_id, model)

        history = StepHistoryModel(
            pipeline_id=pipeline_id or model.pipeline_id,
            step_name=model.step_name,
            duration_ms=duration_ms,
            status=model.status,
        )
        self.db_step_history.insert(history)
        return self.alerts.check_step_alerts(
            pipeline_id or model.pipeline_id, model.step_name, duration_ms
        )

    def link_pipelines(
        self, parent_id: str, child_id: str, relation_type: str = "triggered"
    ):
        model = PipelineRelationModel(
            parent_pipeline_id=parent_id,
            child_pipeline_id=child_id,
            relation_type=relation_type,
        )
        self.db_pipeline_relations.insert(model)

    def add_event(self, pipeline_id: str, event_type: str, event_name: str, **kwargs):
        model = EventModel(
            pipeline_id=pipeline_id,
            step_id=kwargs.get("step_id"),
            event_type=event_type,
            event_name=event_name,
            message=kwargs.get("message"),
            data=json.dumps(kwargs.get("data")) if kwargs.get("data") else None,
            tags=json.dumps(kwargs.get("tags")) if kwargs.get("tags") else None,
        )
        self.db_events.insert(model)

    def record_system_metrics(self, pipeline_id: str, metrics: dict):
        model = SystemMetricsModel(
            pipeline_id=pipeline_id,
            cpu_percent=metrics.get("cpu_percent"),
            memory_percent=metrics.get("memory_percent"),
            memory_used_mb=metrics.get("memory_used_mb"),
            memory_available_mb=metrics.get("memory_available_mb"),
            disk_io_read_mb=metrics.get("disk_io_read_mb"),
            disk_io_write_mb=metrics.get("disk_io_write_mb"),
        )
        self.db_system_metrics.insert(model)

    def acknowledge_alert(self, alert_id: int):
        alerts = self.db_alerts_fired.get_by_field(id=alert_id)
        if alerts:
            self.db_alerts_fired.update(alert_id, alerts[0])
        return {"status": "success"}

    def get_pipeline_graph(self, pipeline_id: str) -> dict:
        """Get pipeline data formatted for graph visualization with full metadata."""
        pipeline = self.get_pipeline(pipeline_id)
        if not pipeline:
            return {"nodes": [], "edges": []}

        nodes = []
        edges = []
        steps_list = pipeline.get("steps", [])

        for i, step in enumerate(steps_list):
            # Parseamos datos de entrada/salida para extraer info de bifurcación
            output_data = step.get("output_data") or {}
            input_data = step.get("input_data") or {}

            node = {
                "id": f"step_{step['id']}",
                "name": step["step_name"],
                "type": step["step_type"],
                "status": step["status"],
                "duration_ms": step.get("duration_ms"),
                "version": step.get("step_version"),
                "error": step.get("error_message"),
                "order": step["step_order"],
                "parent_step_id": step.get("parent_step_id"),
                "parallel_group": step.get("parallel_group"),
                "branch_taken": (
                    output_data.get("branch_taken")
                    if isinstance(output_data, dict)
                    else None
                ),
                "expression": (
                    output_data.get("expression")
                    if isinstance(output_data, dict)
                    else None
                ),
                "has_input": step.get("input_data") is not None,
                "has_output": step.get("output_data") is not None,
            }
            nodes.append(node)

            # --- Lógica de conexión de bordes ---
            parent_id = step.get("parent_step_id")
            
            if parent_id:
                # Conexión desde el bloque padre al sub-paso
                edges.append({
                    "from": f"step_{parent_id}",
                    "to": f"step_{step['id']}",
                    "label": "parallel",
                    "style": "dashed" if step["status"] == "skipped" else "solid"
                })
            elif i > 0:
                # Conexión secuencial normal, buscando el último paso real que NO tenga un padre
                # (para no conectar un paso secuencial con un sub-paso de un paralelo)
                j = i - 1
                found_prev = None
                while j >= 0:
                    cand = steps_list[j]
                    if not cand.get("parent_step_id"):
                        found_prev = cand
                        break
                    j -= 1
                
                if found_prev:
                    is_skipped = step["status"] == "skipped" or step["step_type"] == "skipped"
                    edges.append({
                        "from": f"step_{found_prev['id']}",
                        "to": f"step_{step['id']}",
                        "label": "next" if found_prev["step_type"] != "condition" else ("taken" if not is_skipped else "skipped"),
                        "style": "solid" if not is_skipped else "dashed",
                        "color": "#10b981" if (found_prev["step_type"] == "condition" and not is_skipped) else None
                    })

        return {
            "pipeline_id": pipeline_id,
            "pipeline_name": pipeline["name"],
            "status": pipeline["status"],
            "total_duration_ms": pipeline.get("total_duration_ms"),
            "nodes": nodes,
            "edges": edges,
        }

    def delete_pipeline(self, pipeline_id: str):
        self.db_pipelines.delete(pipeline_id)
        for s in self.db_steps.get_by_field(pipeline_id=pipeline_id):
            self.db_steps.delete(s.id)
        for e in self.db_events.get_by_field(pipeline_id=pipeline_id):
            self.db_events.delete(e.id)

    def _ensure_schema_up_to_date(self):
        """Ensure the database schema is up to date with the latest models."""
        try:
            import sqlite3
            import os
            
            # Si el archivo no existe, WSQLite lo creará en la primera operación,
            # pero necesitamos asegurarnos de que las columnas de paralelismo estén ahí
            # si WSQLite crea una tabla basada en un modelo antiguo o simplificado.
            # Forzamos una pequeña operación para asegurar que las tablas existan
            try:
                self.db_steps.get_all()
            except Exception:
                pass

            if not os.path.exists(self.db_path):
                return
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check for parent_step_id and parallel_group in common table names
            for table in ["steps", "stepmodel"]:
                cursor.execute(f"PRAGMA table_info({table})")
                columns = [info[1] for info in cursor.fetchall()]
                
                if columns: # If table exists
                    modified = False
                    if "parent_step_id" not in columns:
                        cursor.execute(f"ALTER TABLE {table} ADD COLUMN parent_step_id INTEGER")
                        modified = True
                    if "parallel_group" not in columns:
                        cursor.execute(f"ALTER TABLE {table} ADD COLUMN parallel_group TEXT")
                        modified = True
                        
                    if modified:
                        conn.commit()
            conn.close()
        except Exception:
            # We don't want to crash the whole app if migration fails
            pass
