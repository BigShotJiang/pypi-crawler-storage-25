"""AI Beacon — agent session dashboard for monitoring, managing, and attaching to coding agent sessions from any browser."""
