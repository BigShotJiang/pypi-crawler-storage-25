"""
Exception types raised by the Cyberian Systems client.

Catch hierarchy (most-to-least specific):

    CyberianError                 base
    ├── AuthError                 401, 403
    ├── TrialExpiredError         402 trial_expired / quota_exceeded
    ├── QuotaError                402 quota / 413 request_too_large
    ├── RateLimitError            429 (any flavor) — has .retry_after_sec
    ├── ServiceBusyError          503 — has .retry_after_sec
    ├── JobFailedError            job reached FAILED status during wait
    ├── VerificationFailedError   /verify returned valid=False
    ├── NetworkError              transport-level error (no HTTP response)
    └── ApiError                  any other 4xx/5xx
"""
from __future__ import annotations

from typing import Any


class CyberianError(Exception):
    """Base class for all Cyberian client errors."""

    def __init__(self, message: str, *, status_code: int | None = None, body: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class AuthError(CyberianError):
    """The Bearer key was missing, malformed, invalid, or revoked."""


class TrialExpiredError(CyberianError):
    """The account's trial has ended without an upgrade. Email upgrade@cyberiansystems.ai."""


class QuotaError(CyberianError):
    """A period or per-request quota was exceeded."""


class RateLimitError(CyberianError):
    """The per-minute or daily rate limit was hit. Retry after `retry_after_sec`."""

    def __init__(
        self,
        message: str,
        *,
        retry_after_sec: int = 60,
        status_code: int | None = None,
        body: Any = None,
    ):
        super().__init__(message, status_code=status_code, body=body)
        self.retry_after_sec = retry_after_sec


class ServiceBusyError(CyberianError):
    """The platform is at capacity. Retry after `retry_after_sec`."""

    def __init__(
        self,
        message: str,
        *,
        retry_after_sec: int = 30,
        status_code: int | None = None,
        body: Any = None,
    ):
        super().__init__(message, status_code=status_code, body=body)
        self.retry_after_sec = retry_after_sec


class JobFailedError(CyberianError):
    """A job reached FAILED status during wait_for_completion."""

    def __init__(self, job_id: str, body: Any = None):
        super().__init__(f"Job {job_id} ended in FAILED state", body=body)
        self.job_id = job_id


class VerificationFailedError(CyberianError):
    """The receipt's /verify call returned valid=False."""

    def __init__(self, receipt_id: str, checks: dict[str, bool], errors: list[str]):
        super().__init__(f"Receipt {receipt_id} failed verification: {errors}")
        self.receipt_id = receipt_id
        self.checks = checks
        self.errors = errors


class NetworkError(CyberianError):
    """Transport-level error talking to the API — DNS failure, connect
    refused, TLS handshake error, idle-proxy drop on a long-wait
    request, etc. No HTTP response was received. The SDK retries
    these transparently inside wait_for_completion(); callers
    elsewhere should retry with backoff if appropriate.
    """


class ApiError(CyberianError):
    """Any other unexpected HTTP error from the API."""
