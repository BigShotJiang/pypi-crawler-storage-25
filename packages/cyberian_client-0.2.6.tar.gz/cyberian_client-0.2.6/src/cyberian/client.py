"""
Cyberian Systems client — Phase 2 SDK.

The Bearer key is the credential. There's no separate login; the key
is granted by /auth/register (use the /signup page on the website) or
issued by an operator.

Quick start:

    from cyberian import Client

    c = Client(api_key="cyb_trial_…")

    # One-shot: submit, wait, fetch receipt + outputs
    result = c.submit_and_wait(
        model="bge-large-v1.5",
        inputs=["sentence one", "sentence two"],
    )
    print(result.receipt["receipt_hash"])
    print(result.embeddings.shape)  # (2, 1024) for bge-large-v1.5

    # Or step-by-step
    job = c.submit_job(model="bge-large-v1.5", inputs=[…])
    final = c.wait_for_completion(job["id"])
    receipt = c.get_receipt(final["receipt_id"])
    verification = c.verify_receipt(final["receipt_id"])
    embeddings = c.get_job_output(final["id"])  # numpy ndarray

    # VaaS — verify a commitment for inference you ran yourself
    receipt = c.verify_outputs(
        model="bge-large-v1.5",
        inputs=[…],
        claimed_output_commitment="sha256-hex-of-your-output",
    )

    # Account info, key management
    info = c.get_account()
    new_key = c.rotate_key()
    c.revoke_key(key_id="abc123def456")
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any

import httpx
import numpy as np

from .exceptions import (
    ApiError,
    AuthError,
    CyberianError,
    JobFailedError,
    NetworkError,
    QuotaError,
    RateLimitError,
    ServiceBusyError,
    TrialExpiredError,
    VerificationFailedError,
)

DEFAULT_API_URL = "https://api.cyberiansystems.ai"


@dataclass
class JobResult:
    """Returned by submit_and_wait. Bundles the three things customers
    most often need at the end of a job: the final job state, the full
    receipt, and the decoded output embeddings."""

    job: dict[str, Any]
    receipt: dict[str, Any]
    embeddings: np.ndarray
    verification: dict[str, Any] | None = None


class Client:
    """Synchronous Cyberian Systems API client."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        _http_client: httpx.Client | None = None,
    ):
        # Allow CYBERIAN_API_KEY in the environment as a fallback so
        # customers can avoid hard-coding keys in source. The explicit
        # kwarg always wins if both are present.
        if api_key is None:
            api_key = os.environ.get("CYBERIAN_API_KEY")
        if not api_key or not api_key.startswith("cyb_"):
            raise AuthError(
                "api_key must be a Cyberian Bearer key (starts with cyb_). "
                "Pass it to Client(api_key=...) or set CYBERIAN_API_KEY in "
                "the environment. Mint one via the /signup page or via "
                "/auth/register."
            )
        # The API endpoint is fixed for customers. The CYBERIAN_API_BASE
        # env var is honored for internal dev and test rigs (local
        # coordinator on a different port, future on-prem deployments)
        # but isn't part of the public constructor — there's only one
        # production endpoint customers should ever talk to.
        self._base_url = os.environ.get("CYBERIAN_API_BASE", DEFAULT_API_URL).rstrip("/")
        # Stash the api_key in a single private attribute (with leading
        # underscore + dunder-style mangling) so users who serialize or
        # log the Client don't leak it. The header is added per-request
        # in _request() rather than once on the shared httpx.Client —
        # otherwise httpx's default repr / pickle / deepcopy paths emit
        # the headers dict including the Bearer token, which has burned
        # customers via Sentry breadcrumbs and exception-traceback
        # reporters in the past.
        self.__api_key = api_key  # double-underscore: name-mangled
        self._owns_http = _http_client is None
        # Connect timeout 10s so dead networks fail fast; no read /
        # write / pool timeout so very large batch downloads and
        # uploads (multi-GB embeddings, slow corporate networks)
        # don't get cut off mid-stream, and so long-wait endpoints
        # like /jobs/:id/wait can park on the server side. Users who
        # want a hard wall clock should use
        # wait_for_completion(timeout_sec=...) which has its own
        # logical deadline.
        self._http = _http_client or httpx.Client(
            base_url=self._base_url,
            timeout=httpx.Timeout(None, connect=10.0),
            headers={"Content-Type": "application/json"},
        )

    # ─── safe repr ─────────────────────────────────────────────────────────
    # Override default repr so logging/printing the client doesn't
    # leak the Bearer key. Same for the str representation.

    def __repr__(self) -> str:
        # Show only the public-namespace prefix of the key (cyb_<label>_)
        # so the user can distinguish multiple clients without exposing
        # the secret tail. Base URL is intentionally NOT included — it's
        # always the same in production and showing it in tracebacks /
        # logs adds noise without adding information.
        prefix = self.__api_key.rsplit("_", 1)[0] + "_…" if "_" in self.__api_key else "cyb_…"
        return f"Client(api_key={prefix!r})"

    def __str__(self) -> str:  # pragma: no cover
        return self.__repr__()

    # ─── core HTTP wrapper ────────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        expect_json: bool = True,
    ) -> Any:
        # Pass the Authorization header per-request rather than baking it
        # into self._http.headers — keeps the Bearer key out of httpx's
        # default repr and out of any third-party tracebacks/breadcrumbs
        # that capture the Client object.
        try:
            resp = self._http.request(
                method,
                path,
                json=json,
                headers={"Authorization": f"Bearer {self.__api_key}"},
            )
        except httpx.RequestError as exc:
            # Transport-level: DNS / connect / TLS / idle-proxy drop.
            # No HTTP response was received. wait_for_completion()
            # catches NetworkError specifically and retries with
            # backoff; other call sites bubble it to the caller.
            raise NetworkError(f"network error talking to {path}: {exc}") from exc

        if resp.status_code < 400:
            if not expect_json:
                return resp
            if resp.status_code == 204 or not resp.content:
                return None
            return resp.json()

        # 4xx/5xx — translate to typed exceptions.
        try:
            body = resp.json()
        except Exception:
            body = {"raw": resp.text}

        msg = body.get("message") or body.get("error") or f"HTTP {resp.status_code}"
        retry_after = int(resp.headers.get("retry-after", 0) or 0) or body.get("retry_after_sec", 0)

        if resp.status_code == 401 or resp.status_code == 403:
            raise AuthError(msg, status_code=resp.status_code, body=body)
        if resp.status_code == 402:
            err = (body.get("error") or "").lower()
            if "trial" in err:
                raise TrialExpiredError(msg, status_code=402, body=body)
            raise QuotaError(msg, status_code=402, body=body)
        if resp.status_code == 413:
            raise QuotaError(msg, status_code=413, body=body)
        if resp.status_code == 429:
            raise RateLimitError(msg, retry_after_sec=retry_after or 60, status_code=429, body=body)
        if resp.status_code == 503:
            raise ServiceBusyError(msg, retry_after_sec=retry_after or 30, status_code=503, body=body)
        raise ApiError(msg, status_code=resp.status_code, body=body)

    # ─── public surface ──────────────────────────────────────────────────

    def health(self) -> dict[str, Any]:
        """GET /health — connectivity probe; doesn't require auth."""
        return self._request("GET", "/health")

    def get_account(self) -> dict[str, Any]:
        """GET /account — tier, trial status, usage, key list."""
        return self._request("GET", "/account")

    def rotate_key(self) -> str:
        """POST /auth/keys/rotate — returns the NEW plaintext key. Old key
        remains valid until you call revoke_key with its key_id."""
        body = self._request("POST", "/auth/keys/rotate")
        return body["api_key"]

    def revoke_key(self, *, key_id: str) -> None:
        """POST /auth/keys/revoke — invalidate the key with the given 12-
        char key_id prefix. Idempotent."""
        self._request("POST", "/auth/keys/revoke", json={"key_id": key_id})

    def submit_job(
        self,
        *,
        model: str,
        inputs: list[str],
    ) -> dict[str, Any]:
        """POST /jobs — submit a verified inference batch.

        Args:
            model: Model ID enabled for your account
                   (see :meth:`list_models` or your account dashboard).
            inputs: List of input strings (e.g. texts to embed).
        """
        return self._request("POST", "/jobs", json={"model": model, "inputs": inputs})

    def list_models(self) -> list[dict[str, Any]]:
        """GET /models — list of models enabled for your account.

        Each entry is a descriptor with at least ``id`` and ``name``.
        """
        resp = self._request("GET", "/models")
        models = resp.get("models", []) if isinstance(resp, dict) else []
        return models if isinstance(models, list) else []

    def get_job(self, job_id: str) -> dict[str, Any]:
        """GET /jobs/:id — current job status."""
        return self._request("GET", f"/jobs/{job_id}")

    def get_job_results(self, job_id: str) -> dict[str, Any]:
        """GET /jobs/:id/results — per-chunk progress (status, commitments)."""
        return self._request("GET", f"/jobs/{job_id}/results")

    def get_job_output(self, job_id: str) -> np.ndarray:
        """GET /jobs/:id/output — decoded float32 embeddings as a 2D ndarray.

        Shape is (total_input_texts, output_dimensions). Only available
        after the job reaches SETTLED.
        """
        resp = self._request("GET", f"/jobs/{job_id}/output", expect_json=False)
        shape_h = resp.headers.get("x-cyberian-shape", "")
        try:
            rows, cols = (int(p.strip()) for p in shape_h.split(","))
        except Exception as exc:
            raise ApiError(f"unexpected x-cyberian-shape header: {shape_h!r}") from exc
        return np.frombuffer(resp.content, dtype=np.float32).reshape(rows, cols)

    def get_receipt(self, receipt_id: str) -> dict[str, Any]:
        """GET /receipts/:id — full Merkle receipt JSON."""
        return self._request("GET", f"/receipts/{receipt_id}")

    def verify_receipt(self, receipt_id: str) -> dict[str, Any]:
        """GET /receipts/:id/verify — validate the receipt. Returns
        {valid, checks: {...}, errors}.
        """
        return self._request("GET", f"/receipts/{receipt_id}/verify")

    def wait_for_completion(
        self,
        job_id: str,
        *,
        check_every_sec: float = 0.0,
        timeout_sec: float = 600.0,
    ) -> dict[str, Any]:
        """Wait for the job to reach a terminal state and return it.

        Blocks until the job is SETTLED, FAILED, or REFUNDED, or
        ``timeout_sec`` has elapsed. The platform releases the wait as
        soon as the job's state changes — your process doesn't have to
        guess an interval.

        Args:
            job_id: Job UUID.
            check_every_sec: Optional cooldown between successive long
                wait requests (the platform may return early without a
                state change after its own per-request cap). Defaults
                to 0 — re-issue immediately.
            timeout_sec: Overall deadline for this call. Defaults to
                10 minutes.

        Raises:
            JobFailedError: The job ended in FAILED.
            CyberianError: ``timeout_sec`` elapsed before terminal.
        """
        deadline = time.monotonic() + timeout_sec
        terminal = {"SETTLED", "FAILED", "REFUNDED"}
        last_status: str | None = None
        # Exponential backoff between network-error retries — handles
        # corporate-proxy idle drops, brief DNS / NAT blips, transient
        # 5xx-from-the-edge events. Resets after each successful wait
        # request so a flapping link doesn't accumulate a long sleep.
        backoff_sec = 1.0
        while True:
            # Server-side long wait: the request blocks on the platform
            # for up to its own per-request cap (currently 30s) or
            # until the job's state changes, whichever comes first.
            # We pass max_wait so the platform sizes the wait against
            # our remaining deadline and doesn't block past it.
            remaining = max(1, int(deadline - time.monotonic()))
            try:
                job = self._request("GET", f"/jobs/{job_id}/wait?max_wait={remaining}")
            except NetworkError:
                if time.monotonic() > deadline:
                    raise
                # Sleep ≤ remaining time so we don't overshoot the
                # caller's overall deadline.
                sleep_for = min(backoff_sec, max(0.0, deadline - time.monotonic()))
                if sleep_for > 0:
                    time.sleep(sleep_for)
                backoff_sec = min(backoff_sec * 2, 8.0)
                continue
            backoff_sec = 1.0
            last_status = job["status"]
            if last_status in terminal:
                if last_status == "FAILED":
                    raise JobFailedError(job_id, body=job)
                return job
            if time.monotonic() > deadline:
                raise CyberianError(
                    f"Job {job_id} did not reach a terminal state in {timeout_sec}s "
                    f"(last status: {last_status})"
                )
            if check_every_sec > 0:
                time.sleep(check_every_sec)

    def submit_and_wait(
        self,
        *,
        model: str,
        inputs: list[str],
        check_every_sec: float = 0.0,
        timeout_sec: float = 600.0,
        verify_receipt: bool = True,
    ) -> JobResult:
        """One-shot helper: submit_job → wait_for_completion → get_receipt
        → get_job_output → optionally verify_receipt. Most customers will
        only ever call this method.
        """
        job = self.submit_job(model=model, inputs=inputs)
        final = self.wait_for_completion(
            job["id"],
            check_every_sec=check_every_sec,
            timeout_sec=timeout_sec,
        )
        receipt = self.get_receipt(final["receipt_id"])
        embeddings = self.get_job_output(final["id"])
        verification = self.verify_receipt(final["receipt_id"]) if verify_receipt else None
        if verification and not verification.get("valid", False):
            raise VerificationFailedError(
                receipt_id=final["receipt_id"],
                checks=verification.get("checks", {}),
                errors=verification.get("errors", []),
            )
        return JobResult(
            job=final,
            receipt=receipt,
            embeddings=embeddings,
            verification=verification,
        )

    # ─── VaaS ────────────────────────────────────────────────────────────

    def verify_outputs(
        self,
        *,
        model: str,
        inputs: list[str],
        claimed_output_commitment: str,
    ) -> dict[str, Any]:
        """POST /verify — Verification as a Service. You ran inference on
        your own infrastructure; the platform independently verifies and
        issues a receipt.

        Phase 2 single-call only — up to 1000 inputs per request.

        Returns the receipt on success (HTTP 200). Raises
        VerificationFailedError if the independent verification disagrees
        with the commitment you claimed (HTTP 422).
        """
        body: dict[str, Any] = {
            "model": model,
            "inputs": inputs,
            "claimed_output_commitment": claimed_output_commitment,
        }
        try:
            return self._request("POST", "/verify", json=body)
        except ApiError as exc:
            if exc.status_code == 422:
                raise VerificationFailedError(
                    receipt_id="(no receipt issued)",
                    checks={"output_match": False},
                    errors=[exc.body.get("reason") if isinstance(exc.body, dict) else str(exc.body)],
                ) from exc
            raise

    # ─── lifecycle ───────────────────────────────────────────────────────

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


# _read_spec helper removed — the SDK no longer accepts CES specs from
# customers. The model + verification level pick the spec server-side.
