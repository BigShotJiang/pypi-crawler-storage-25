"""
FeatureEngineeringClient 单元测试

覆盖范围：
- __init__ 初始化及时区设置
- _translate_spark_timezone 时区转换
- _build_full_database_name 数据库名构建
- create_database / drop_database / list_databases / database_exists
- create_table / read_table / get_table / drop_table / write_table
- create_training_set（含 feature_spec 和 feature_lookups 场景）
- _generate_feature_lookups_from_feature_spec
- log_model / score_batch
- set_feature_table_tag / delete_feature_table_tag
- publish_table / drop_online_table
- create_feature_spec
- spark 属性
"""

import datetime
import pytest
from unittest.mock import MagicMock, patch, PropertyMock, call

from pyspark.errors import IllegalArgumentException

from wedata.common.entities.feature_lookup import FeatureLookup
from wedata.common.entities.feature_function import FeatureFunction
from wedata.common.entities.feature_table import FeatureTable
from wedata.common.constants.engine_types import EngineTypes


# ─────────────────────────────────────────────
# 辅助：构造不经过 __init__ 的 client mock
# ─────────────────────────────────────────────

def _make_client():
    """构造一个不依赖 Spark 和真实环境变量的 FeatureEngineeringClient Mock。

    通过 __new__ 跳过 __init__，然后手动挂载 mock 属性。
    """
    from wedata.feature_engineering.client import FeatureEngineeringClient
    client = FeatureEngineeringClient.__new__(FeatureEngineeringClient)
    client._spark = MagicMock()
    client._spark_client = MagicMock()
    client._training_set_client = MagicMock()
    client._feature_table_client = MagicMock()
    return client


# ═════════════════════════════════════════════
# 1. __init__ 初始化测试
# ═════════════════════════════════════════════

class TestInit:
    """FeatureEngineeringClient.__init__ 初始化测试"""

    @patch("wedata.feature_engineering.client.MLTrainingClient")
    @patch("wedata.feature_engineering.client.FeatureEngineeringTableClient")
    @patch("wedata.feature_engineering.client.SparkClient")
    @patch("wedata.feature_engineering.client.env_utils")
    def test_init_with_spark(self, mock_env, mock_spark_client_cls, mock_table_client_cls, mock_ml_client_cls):
        """传入 spark 时不调用 getOrCreate"""
        from wedata.feature_engineering.client import FeatureEngineeringClient

        mock_env.get_temporary_secret.return_value = ("id", "key", "token")
        mock_spark = MagicMock()
        mock_spark.conf.get.return_value = ""

        client = FeatureEngineeringClient(spark=mock_spark)

        assert client._spark is mock_spark
        mock_spark_client_cls.assert_called_once_with(mock_spark)
        mock_env.get_temporary_secret.assert_called_once()

    @patch("wedata.feature_engineering.client.MLTrainingClient")
    @patch("wedata.feature_engineering.client.FeatureEngineeringTableClient")
    @patch("wedata.feature_engineering.client.SparkClient")
    @patch("wedata.feature_engineering.client.env_utils")
    def test_init_without_spark_calls_get_or_create(self, mock_env, mock_spark_client_cls,
                                                     mock_table_client_cls, mock_ml_client_cls):
        """不传 spark 时应调用 SparkSession.builder.getOrCreate()"""
        from wedata.feature_engineering.client import FeatureEngineeringClient

        mock_env.get_temporary_secret.return_value = ("id", "key", "token")

        mock_session = MagicMock()
        mock_session.conf.get.return_value = ""
        with patch("wedata.feature_engineering.client.SparkSession") as mock_ss:
            mock_ss.builder.getOrCreate.return_value = mock_session
            client = FeatureEngineeringClient(spark=None)

        assert client._spark is mock_session
        mock_ss.builder.getOrCreate.assert_called_once()

    @patch("wedata.feature_engineering.client.MLTrainingClient")
    @patch("wedata.feature_engineering.client.FeatureEngineeringTableClient")
    @patch("wedata.feature_engineering.client.SparkClient")
    @patch("wedata.feature_engineering.client.env_utils")
    def test_init_timezone_pytz_compatible(self, mock_env, mock_spark_client_cls,
                                           mock_table_client_cls, mock_ml_client_cls):
        """Spark 时区为 pytz 可识别格式时，_translate_spark_timezone 正常转换并设置"""
        from wedata.feature_engineering.client import FeatureEngineeringClient

        mock_env.get_temporary_secret.return_value = ("id", "key", "token")
        mock_spark = MagicMock()
        mock_spark.conf.get.return_value = "UTC"

        client = FeatureEngineeringClient(spark=mock_spark)
        # _translate_spark_timezone("UTC") 应返回 "UTC"，然后 conf.set 设置该值
        mock_spark.conf.set.assert_called_with("spark.sql.session.timeZone", "UTC")

    @patch("wedata.feature_engineering.client.MLTrainingClient")
    @patch("wedata.feature_engineering.client.FeatureEngineeringTableClient")
    @patch("wedata.feature_engineering.client.SparkClient")
    @patch("wedata.feature_engineering.client.env_utils")
    def test_init_timezone_empty_sets_default(self, mock_env, mock_spark_client_cls,
                                              mock_table_client_cls, mock_ml_client_cls):
        """Spark 时区为空时，设置默认 Etc/GMT+8"""
        from wedata.feature_engineering.client import FeatureEngineeringClient

        mock_env.get_temporary_secret.return_value = ("id", "key", "token")
        mock_spark = MagicMock()
        mock_spark.conf.get.return_value = ""

        client = FeatureEngineeringClient(spark=mock_spark)
        mock_spark.conf.set.assert_called_with("spark.sql.session.timeZone", "Etc/GMT+8")

    @patch("wedata.feature_engineering.client.MLTrainingClient")
    @patch("wedata.feature_engineering.client.FeatureEngineeringTableClient")
    @patch("wedata.feature_engineering.client.SparkClient")
    @patch("wedata.feature_engineering.client.env_utils")
    def test_init_timezone_illegal_argument_falls_back(self, mock_env, mock_spark_client_cls,
                                                       mock_table_client_cls, mock_ml_client_cls):
        """Spark conf.get 抛出 IllegalArgumentException 时，回退到默认时区"""
        from wedata.feature_engineering.client import FeatureEngineeringClient

        mock_env.get_temporary_secret.return_value = ("id", "key", "token")
        mock_spark = MagicMock()
        # IllegalArgumentException 需要 message 参数
        mock_spark.conf.get.side_effect = IllegalArgumentException(message="test error")

        client = FeatureEngineeringClient(spark=mock_spark)
        mock_spark.conf.set.assert_called_with("spark.sql.session.timeZone", "Etc/GMT+8")


# ═════════════════════════════════════════════
# 2. _translate_spark_timezone 测试
# ═════════════════════════════════════════════

class TestTranslateSparkTimezone:
    """_translate_spark_timezone 静态方法测试"""

    def test_pytz_recognized_timezone(self):
        """pytz 可识别的时区字符串直接返回"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        result = FeatureEngineeringClient._translate_spark_timezone("UTC")
        assert result == "UTC"

    def test_pytz_recognized_asia_shanghai(self):
        """Asia/Shanghai 应被 pytz 正确识别"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        result = FeatureEngineeringClient._translate_spark_timezone("Asia/Shanghai")
        assert result == "Asia/Shanghai"

    def test_gmt_plus_08(self):
        """GMT+08:00 应转换为 Etc/GMT+8"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        result = FeatureEngineeringClient._translate_spark_timezone("GMT+08:00")
        assert result == "Etc/GMT+8"

    def test_gmt_minus_05(self):
        """GMT-05:00 应转换为 Etc/GMT-5"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        result = FeatureEngineeringClient._translate_spark_timezone("GMT-05:00")
        assert result == "Etc/GMT-5"

    def test_invalid_timezone_raises_value_error(self):
        """无法识别且不匹配 GMT 格式的字符串应抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="Invalid timezone string"):
            FeatureEngineeringClient._translate_spark_timezone("INVALID_TZ")


# ═════════════════════════════════════════════
# 3. _build_full_database_name 测试
# ═════════════════════════════════════════════

class TestBuildFullDatabaseName:
    """_build_full_database_name 方法测试"""

    def test_with_explicit_catalog(self):
        """显式传入 catalog_name 时，返回 catalog.database"""
        client = _make_client()
        result = client._build_full_database_name("my_db", catalog_name="my_catalog")
        assert result == "my_catalog.my_db"

    def test_with_current_catalog(self):
        """未传 catalog_name 时，使用 spark_client 的当前 catalog"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "spark_catalog"
        result = client._build_full_database_name("my_db")
        assert result == "spark_catalog.my_db"

    def test_no_catalog_available(self):
        """无法获取 catalog 时，仅返回 database_name"""
        client = _make_client()
        client._spark_client.get_current_catalog.side_effect = Exception("no catalog")
        result = client._build_full_database_name("my_db")
        assert result == "my_db"

    def test_empty_database_name_raises(self):
        """空 database_name 抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="database_name must be a non-empty string"):
            client._build_full_database_name("")

    def test_none_database_name_raises(self):
        """None database_name 抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="database_name must be a non-empty string"):
            client._build_full_database_name(None)

    def test_database_name_with_dot_two_level_parses(self):
        """database_name 包含一个点号时解析为二段式（改动后行为）"""
        client = _make_client()
        result = client._build_full_database_name("catalog.database")
        assert result == "catalog.database"

    def test_non_string_database_name_raises(self):
        """非字符串类型 database_name 抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError):
            client._build_full_database_name(123)

    # ── 二段式解析测试（新增）──

    def test_two_level_database_name_parses_correctly(self):
        """二段式 'catalog.schema' 正常解析，返回 'catalog.schema'"""
        client = _make_client()
        result = client._build_full_database_name("my_catalog.my_db")
        assert result == "my_catalog.my_db"

    def test_two_level_with_consistent_catalog_name(self):
        """二段式 + 一致的 catalog_name 正常返回"""
        client = _make_client()
        result = client._build_full_database_name(
            "my_catalog.my_db", catalog_name="my_catalog"
        )
        assert result == "my_catalog.my_db"

    def test_two_level_with_conflicting_catalog_name_raises(self):
        """二段式 + 冲突的 catalog_name 抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="catalog_a.*catalog_b|catalog_b.*catalog_a"):
            client._build_full_database_name(
                "catalog_a.my_db", catalog_name="catalog_b"
            )

    def test_three_or_more_segments_database_name_raises(self):
        """三段及以上 'a.b.c' 抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError):
            client._build_full_database_name("a.b.c")

    # ── GAP-F: _build_full_database_name 正则拒绝测试（补充）──

    def test_database_name_with_space_raises(self):
        """database_name 含空格 'my db' → 段含空格不合法，抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="invalid segment"):
            client._build_full_database_name("my db")

    def test_database_name_with_slash_raises(self):
        """database_name 含斜杠 'my/db' → 段含斜杠不合法，抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="invalid segment"):
            client._build_full_database_name("my/db")

    def test_database_name_two_level_with_space_raises(self):
        """二段式 database_name 含空格 'cat. db' → 段含空格不合法，抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="invalid segment"):
            client._build_full_database_name("cat. db")

    def test_database_name_with_control_char_raises(self):
        """database_name 含控制字符 'my\\x00db' → 不合法，抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="invalid segment"):
            client._build_full_database_name("my\x00db")


# ═════════════════════════════════════════════
# 3.5 _check_database_exists 测试（M2 辅助方法）
# ═════════════════════════════════════════════

class TestCheckDatabaseExists:
    """_check_database_exists 辅助方法测试"""

    def test_exists_by_full_name(self):
        """list_databases 返回完整名时匹配 full_db_name"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "cat.my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        assert client._check_database_exists("cat.my_db", "my_db", "cat") is True

    def test_exists_by_simple_name(self):
        """list_databases 返回简单名时匹配 simple_db_name"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        assert client._check_database_exists("cat.my_db", "my_db", "cat") is True

    def test_exists_by_original_database_name(self):
        """list_databases 返回与原始 database_name 一致时匹配"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "cat.my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        assert client._check_database_exists("cat.my_db", "cat.my_db", None) is True

    def test_not_exists(self):
        """数据库不存在时返回 False"""
        client = _make_client()
        client._spark.sql.return_value.collect.return_value = []

        assert client._check_database_exists("cat.my_db", "my_db", "cat") is False

    def test_no_catalog_in_full_name(self):
        """full_db_name 不含点号时，使用传入的 catalog_name"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        assert client._check_database_exists("my_db", "my_db", None) is True

    def test_list_databases_exception_propagates(self):
        """list_databases 失败时异常向上传播"""
        client = _make_client()
        client._spark.sql.side_effect = Exception("sql error")

        with pytest.raises(Exception, match="sql error"):
            client._check_database_exists("cat.my_db", "my_db", "cat")


# ═════════════════════════════════════════════
# 4. create_database 测试
# ═════════════════════════════════════════════

class TestCreateDatabase:
    """create_database 方法测试"""

    def test_create_database_success(self):
        """成功创建数据库"""
        client = _make_client()
        mock_row = MagicMock()
        mock_row.namespace = "other_db"
        client._spark.sql.return_value.collect.return_value = [mock_row]
        client._spark_client.get_current_catalog.return_value = "cat"

        result = client.create_database("my_db")
        assert result == "cat.my_db"
        # 应调用 CREATE DATABASE DDL
        calls = client._spark.sql.call_args_list
        assert any("CREATE DATABASE" in str(c) for c in calls)

    def test_create_database_already_exists_skips(self):
        """数据库已存在时跳过创建"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        mock_row = MagicMock()
        mock_row.namespace = "cat.my_db"
        client._spark.sql.return_value.collect.return_value = [mock_row]

        result = client.create_database("my_db")
        assert result == "cat.my_db"
        # 仅调用 SHOW DATABASES，不调用 CREATE
        assert client._spark.sql.call_count == 1

    def test_create_database_with_comment(self):
        """带 comment 的数据库创建"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        client._spark.sql.return_value.collect.return_value = []

        client.create_database("my_db", comment="test comment")
        # 检查包含 COMMENT 的 DDL
        sql_calls = [str(c) for c in client._spark.sql.call_args_list]
        assert any("COMMENT" in s for s in sql_calls)

    def test_create_database_comment_escapes_single_quote(self):
        """M1: comment 中的单引号应被转义，防止 SQL 注入"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        client._spark.sql.return_value.collect.return_value = []

        client.create_database("my_db", comment="it's a test'; DROP DATABASE x; --")
        # 获取 CREATE DATABASE 的 DDL 调用（排除 SHOW DATABASES 调用）
        create_ddl = None
        for c in client._spark.sql.call_args_list:
            sql = c[0][0] if c[0] else c[1].get("sqlText", "")
            if "CREATE DATABASE" in sql:
                create_ddl = sql
                break
        assert create_ddl is not None, "未找到 CREATE DATABASE DDL 调用"
        # 确保 DDL 中 COMMENT 值内的注入内容已被转义，不会导致引号闭合逃逸
        # 转义后 DDL 应包含 \' 而非裸单引号作为值分隔符
        # 提取 COMMENT '...' 之间的内容
        comment_start = create_ddl.index("COMMENT '") + len("COMMENT '")
        # 从 COMMENT 后找到闭合引号（未被转义的 '）
        # 如果转义正确，注入的 DROP DATABASE 应在 COMMENT 值内部
        assert "DROP DATABASE x" in create_ddl[comment_start:], "DDL 应包含被转义后的原始文本"
        assert "\\'" in create_ddl, "DDL 应包含转义后的单引号"

    def test_create_database_location_escapes_single_quote(self):
        """M1: location 中的单引号应被转义，防止 SQL 注入"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        client._spark.sql.return_value.collect.return_value = []

        client.create_database("my_db", location="/path/to/it's/db")
        sql_calls = [str(c) for c in client._spark.sql.call_args_list]
        create_calls = [s for s in sql_calls if "CREATE DATABASE" in s]
        assert len(create_calls) > 0

    def test_create_database_with_location(self):
        """带 location 的数据库创建"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        client._spark.sql.return_value.collect.return_value = []

        client.create_database("my_db", location="/path/to/db")
        sql_calls = [str(c) for c in client._spark.sql.call_args_list]
        assert any("LOCATION" in s for s in sql_calls)

    def test_create_database_with_explicit_catalog(self):
        """使用显式 catalog_name"""
        client = _make_client()
        client._spark.sql.return_value.collect.return_value = []

        result = client.create_database("my_db", catalog_name="DataLakeCatalog")
        assert result == "DataLakeCatalog.my_db"

    def test_create_database_spark_error_propagates(self):
        """创建数据库时 Spark 执行失败应传播异常"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        # SHOW DATABASES 正常
        client._spark.sql.return_value.collect.return_value = []
        # CREATE DATABASE 失败
        client._spark.sql.side_effect = [MagicMock(collect=MagicMock(return_value=[])), Exception("Spark error")]

        with pytest.raises(Exception, match="Spark error"):
            client.create_database("my_db")

    def test_create_database_show_databases_fails_proceeds(self):
        """list_databases 失败时仍继续创建"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        # list_databases 内部调用 SHOW DATABASES IN cat 失败后会尝试切换 catalog，
        # 全部失败后 create_database 应继续尝试 CREATE
        client._spark.sql.side_effect = [
            Exception("show failed"),  # SHOW DATABASES IN cat
            Exception("show failed"),  # fallback SHOW DATABASES
            MagicMock(),               # CREATE DATABASE
        ]

        result = client.create_database("my_db")
        assert result == "cat.my_db"

    # ── 二段式数据库名称测试（新增）──

    def test_create_database_two_level_name(self):
        """create_database('my_catalog.my_db') → 在 my_catalog 下检查并创建"""
        client = _make_client()
        # list_databases 模拟：SHOW DATABASES IN my_catalog 返回空
        row = MagicMock()
        row.namespace = "other_db"
        client._spark.sql.return_value.collect.return_value = [row]

        result = client.create_database("my_catalog.my_db")
        assert result == "my_catalog.my_db"
        # 应使用 SHOW DATABASES IN my_catalog 或等效方式查询
        sql_calls = [str(c) for c in client._spark.sql.call_args_list]
        assert any("my_catalog" in s for s in sql_calls)

    def test_create_database_two_level_already_exists(self):
        """create_database('my_catalog.my_db') 数据库已存在时跳过"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        result = client.create_database("my_catalog.my_db")
        assert result == "my_catalog.my_db"


# ═════════════════════════════════════════════
# 5. drop_database 测试
# ═════════════════════════════════════════════

class TestDropDatabase:
    """drop_database 方法测试"""

    def test_drop_existing_database(self):
        """删除已存在的数据库"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        mock_row = MagicMock()
        mock_row.namespace = "cat.my_db"
        client._spark.sql.return_value.collect.return_value = [mock_row]

        result = client.drop_database("my_db")
        assert result is True

    def test_drop_nonexistent_database_returns_false(self):
        """删除不存在的数据库返回 False"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        client._spark.sql.return_value.collect.return_value = []

        result = client.drop_database("nonexistent_db")
        assert result is False

    def test_drop_database_cascade(self):
        """CASCADE 模式删除"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        mock_row = MagicMock()
        mock_row.namespace = "cat.my_db"
        client._spark.sql.return_value.collect.return_value = [mock_row]

        result = client.drop_database("my_db", cascade=True)
        assert result is True
        sql_calls = [str(c) for c in client._spark.sql.call_args_list]
        assert any("CASCADE" in s for s in sql_calls)

    def test_drop_database_without_if_exists(self):
        """if_exists=False 不使用 IF EXISTS"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        mock_row = MagicMock()
        mock_row.namespace = "cat.my_db"
        client._spark.sql.return_value.collect.return_value = [mock_row]

        client.drop_database("my_db", if_exists=False)
        sql_calls = [str(c) for c in client._spark.sql.call_args_list]
        # 应有不含 IF EXISTS 的 DROP DATABASE
        drop_calls = [s for s in sql_calls if "DROP DATABASE" in s]
        assert any("IF EXISTS" not in s for s in drop_calls) or len(drop_calls) > 0

    def test_drop_database_spark_error_propagates(self):
        """删除失败时异常传播"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        mock_row = MagicMock()
        mock_row.namespace = "cat.my_db"
        # SHOW DATABASES 成功
        client._spark.sql.side_effect = [
            MagicMock(collect=MagicMock(return_value=[mock_row])),
            Exception("drop failed"),
        ]

        with pytest.raises(Exception, match="drop failed"):
            client.drop_database("my_db")

    # ── 二段式数据库名称测试（新增）──

    def test_drop_database_two_level_name(self):
        """drop_database('my_catalog.my_db') → 在 my_catalog 下检查并删除"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        result = client.drop_database("my_catalog.my_db")
        assert result is True
        sql_calls = [str(c) for c in client._spark.sql.call_args_list]
        # 应使用 SHOW DATABASES IN my_catalog 或等效方式查询
        assert any("my_catalog" in s for s in sql_calls)

    def test_drop_database_two_level_not_exists(self):
        """drop_database('my_catalog.my_db') 数据库不存在时返回 False"""
        client = _make_client()
        client._spark.sql.return_value.collect.return_value = []

        result = client.drop_database("my_catalog.my_db")
        assert result is False


# ═════════════════════════════════════════════
# 6. list_databases 测试
# ═════════════════════════════════════════════

class TestListDatabases:
    """list_databases 方法测试"""

    def test_list_databases_default_catalog(self):
        """列出当前 catalog 下数据库"""
        client = _make_client()
        row1 = MagicMock()
        row1.namespace = "default"
        row2 = MagicMock()
        row2.namespace = "my_db"
        client._spark.sql.return_value.collect.return_value = [row1, row2]

        result = client.list_databases()
        assert result == ["default", "my_db"]

    def test_list_databases_specific_catalog(self):
        """列出指定 catalog 下数据库"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "feature_db"
        client._spark.sql.return_value.collect.return_value = [row]

        result = client.list_databases(catalog_name="DataLakeCatalog")
        assert result == ["feature_db"]

    def test_list_databases_catalog_fallback(self):
        """SHOW DATABASES IN catalog 不支持时，切换 catalog 再查"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "original_cat"

        # 第一次 sql 调用（SHOW DATABASES IN ...）失败
        row = MagicMock()
        row.namespace = "test_db"
        first_call_mock = MagicMock()
        first_call_mock.collect.side_effect = Exception("not supported")
        second_call_mock = MagicMock()
        second_call_mock.collect.return_value = [row]
        client._spark.sql.side_effect = [Exception("not supported"), second_call_mock]

        result = client.list_databases(catalog_name="OtherCatalog")
        assert result == ["test_db"]

    def test_list_databases_error_propagates(self):
        """列出数据库失败时异常传播"""
        client = _make_client()
        client._spark.sql.side_effect = Exception("sql error")

        with pytest.raises(Exception, match="sql error"):
            client.list_databases()


# ═════════════════════════════════════════════
# 7. database_exists 测试
# ═════════════════════════════════════════════

class TestDatabaseExists:
    """database_exists 方法测试"""

    def test_database_exists_true(self):
        """数据库存在时返回 True"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        row = MagicMock()
        row.namespace = "cat.my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        assert client.database_exists("my_db") is True

    def test_database_exists_false(self):
        """数据库不存在时返回 False"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        client._spark.sql.return_value.collect.return_value = []

        assert client.database_exists("nonexistent") is False

    def test_database_exists_exception_returns_false(self):
        """检查过程中异常时返回 False"""
        client = _make_client()
        client._spark_client.get_current_catalog.return_value = "cat"
        client._spark.sql.side_effect = Exception("error")

        assert client.database_exists("my_db") is False

    # ── 二段式数据库名称测试（新增）──

    def test_database_exists_two_level_true(self):
        """database_exists('my_catalog.my_db') → 在 my_catalog 下查找并返回 True"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        assert client.database_exists("my_catalog.my_db") is True
        # 验证 list_databases 使用了正确的 catalog
        sql_calls = [str(c) for c in client._spark.sql.call_args_list]
        assert any("my_catalog" in s for s in sql_calls)

    def test_database_exists_two_level_false(self):
        """database_exists('my_catalog.my_db') → 在 my_catalog 下查找，不存在返回 False"""
        client = _make_client()
        client._spark.sql.return_value.collect.return_value = []

        assert client.database_exists("my_catalog.my_db") is False

    def test_database_exists_two_level_with_consistent_catalog(self):
        """database_exists('my_catalog.my_db', catalog_name='my_catalog') → 正常检查"""
        client = _make_client()
        row = MagicMock()
        row.namespace = "my_catalog.my_db"
        client._spark.sql.return_value.collect.return_value = [row]

        assert client.database_exists("my_catalog.my_db", catalog_name="my_catalog") is True

    def test_database_exists_two_level_with_conflicting_catalog(self):
        """database_exists('cat_a.my_db', catalog_name='cat_b') → ValueError 被捕获返回 False"""
        client = _make_client()
        # _build_full_database_name 会抛出 ValueError，被 except 捕获
        assert client.database_exists("cat_a.my_db", catalog_name="cat_b") is False


# ═════════════════════════════════════════════
# 7.5 _parse_table_name 测试
# ═════════════════════════════════════════════

class TestParseTableName:
    """_parse_table_name 静态方法测试"""

    def test_single_level_with_explicit_params(self):
        """单级名 'tbl' + 显式参数 → 返回 ('tbl', db, cat)"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        table, db, cat = FeatureEngineeringClient._parse_table_name(
            "tbl", "my_db", "my_cat"
        )
        assert table == "tbl"
        assert db == "my_db"
        assert cat == "my_cat"

    def test_single_level_without_params(self):
        """单级名 'tbl' 无显式参数 → 返回 ('tbl', None, None)"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        table, db, cat = FeatureEngineeringClient._parse_table_name(
            "tbl", None, None
        )
        assert table == "tbl"
        assert db is None
        assert cat is None

    def test_two_level_parses_schema_table(self):
        """二段式 'schema.tbl' → 返回 ('tbl', 'schema', None)"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        table, db, cat = FeatureEngineeringClient._parse_table_name(
            "schema.tbl", None, None
        )
        assert table == "tbl"
        assert db == "schema"
        assert cat is None

    def test_two_level_with_consistent_database_name(self):
        """二段式 + 一致的 database_name → 返回 ('tbl', 'schema', cat)"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        table, db, cat = FeatureEngineeringClient._parse_table_name(
            "schema.tbl", "schema", "my_cat"
        )
        assert table == "tbl"
        assert db == "schema"
        assert cat == "my_cat"

    def test_two_level_with_conflicting_database_name_raises(self):
        """二段式 + 冲突的 database_name → 抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="db_a.*db_b|db_b.*db_a"):
            FeatureEngineeringClient._parse_table_name(
                "db_a.tbl", "db_b", None
            )

    def test_three_level_parses_catalog_schema_table(self):
        """三段式 'cat.schema.tbl' → 返回 ('tbl', 'schema', 'cat')"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        table, db, cat = FeatureEngineeringClient._parse_table_name(
            "cat.schema.tbl", None, None
        )
        assert table == "tbl"
        assert db == "schema"
        assert cat == "cat"

    def test_three_level_with_consistent_params(self):
        """三段式 + 一致的显式参数 → 正常返回"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        table, db, cat = FeatureEngineeringClient._parse_table_name(
            "cat.schema.tbl", "schema", "cat"
        )
        assert table == "tbl"
        assert db == "schema"
        assert cat == "cat"

    def test_three_level_with_conflicting_catalog_name_raises(self):
        """三段式 + 冲突的 catalog_name → 抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="catalog_a.*catalog_b|catalog_b.*catalog_a"):
            FeatureEngineeringClient._parse_table_name(
                "catalog_a.schema.tbl", None, "catalog_b"
            )

    def test_three_level_with_conflicting_database_name_raises(self):
        """三段式 + 冲突的 database_name → 抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="db_a.*db_b|db_b.*db_a"):
            FeatureEngineeringClient._parse_table_name(
                "cat.db_a.tbl", "db_b", None
            )

    def test_four_level_raises(self):
        """四段式 'a.b.c.d' → 抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError):
            FeatureEngineeringClient._parse_table_name(
                "a.b.c.d", None, None
            )

    def test_empty_string_raises(self):
        """空字符串 → 抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError):
            FeatureEngineeringClient._parse_table_name("", None, None)

    # ── GAP-9: None 和非字符串类型测试（补充）──

    def test_none_raises(self):
        """None → 抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="non-empty string"):
            FeatureEngineeringClient._parse_table_name(None, None, None)

    def test_non_string_raises(self):
        """非字符串类型（如 int） → 抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="non-empty string"):
            FeatureEngineeringClient._parse_table_name(123, None, None)

    # ── GAP-10: 含非法字符段的边界测试（补充）──

    def test_three_level_with_whitespace_segment_raises(self):
        """三段式含空格 ' cat .schema.tbl' → 段含空格不合法，抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="invalid segment"):
            FeatureEngineeringClient._parse_table_name(
                " cat .schema.tbl", None, None
            )

    def test_middle_segment_only_spaces_raises(self):
        """三段式中间段为纯空格 'cat. .tbl' → 抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="invalid segment"):
            FeatureEngineeringClient._parse_table_name("cat. .tbl", None, None)

    def test_two_level_with_whitespace_segment_raises(self):
        """二段式含空格 ' schema . tbl ' → 段含空格不合法，抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="invalid segment"):
            FeatureEngineeringClient._parse_table_name(
                " schema . tbl ", None, None
            )

    def test_segment_with_slash_raises(self):
        """段含斜杠 'cat/log.schema.tbl' → 不合法，抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="invalid segment"):
            FeatureEngineeringClient._parse_table_name(
                "cat/log.schema.tbl", None, None
            )

    def test_segment_with_control_char_raises(self):
        """段含控制字符 'cat\\x00.schema.tbl' → 不合法，抛出 ValueError"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        with pytest.raises(ValueError, match="invalid segment"):
            FeatureEngineeringClient._parse_table_name(
                "cat\x00.schema.tbl", None, None
            )

    # ── GAP-11: 二段式表名 + 显式 catalog_name 的透传测试（补充）──

    def test_two_level_with_explicit_catalog_name(self):
        """二段式 'schema.table' + 显式 catalog_name='my_cat' → 返回 ('table', 'schema', 'my_cat')"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        table, db, cat = FeatureEngineeringClient._parse_table_name(
            "schema.table", None, "my_cat"
        )
        assert table == "table"
        assert db == "schema"
        assert cat == "my_cat"


# ═════════════════════════════════════════════
# 8. 表操作委托测试
# ═════════════════════════════════════════════

class TestTableOperations:
    """表操作方法（create_table / read_table / get_table / drop_table / write_table）委托测试"""

    def test_create_table_delegates(self):
        """create_table 应委托给 _feature_table_client.create_table"""
        client = _make_client()
        mock_ft = MagicMock(spec=FeatureTable)
        client._feature_table_client.create_table.return_value = mock_ft

        result = client.create_table(
            name="test_table",
            primary_keys=["id"],
            timestamp_key="ts",
            engine_type=EngineTypes.ICEBERG_ENGINE,
            database_name="test_db",
            catalog_name="cat",
        )

        assert result is mock_ft
        client._feature_table_client.create_table.assert_called_once_with(
            name="test_table",
            primary_keys=["id"],
            engine_type=EngineTypes.ICEBERG_ENGINE,
            database_name="test_db",
            catalog_name="cat",
            df=None,
            timestamp_key="ts",
            partition_columns=None,
            schema=None,
            description=None,
            tags=None,
        )

    def test_read_table_delegates(self):
        """read_table 应委托给 _feature_table_client.read_table"""
        client = _make_client()
        mock_df = MagicMock()
        client._feature_table_client.read_table.return_value = mock_df

        result = client.read_table("test_table", database_name="db", catalog_name="cat")
        assert result is mock_df
        client._feature_table_client.read_table.assert_called_once_with(
            name="test_table", database_name="db", catalog_name="cat"
        )

    def test_get_table_delegates(self):
        """get_table 应委托给 _feature_table_client.get_table"""
        client = _make_client()
        mock_ft = MagicMock(spec=FeatureTable)
        client._feature_table_client.get_table.return_value = mock_ft

        result = client.get_table("test_table", database_name="db", catalog_name="cat")
        assert result is mock_ft
        client._feature_table_client.get_table.assert_called_once_with(
            "test_table", client._spark_client, "db", "cat"
        )

    def test_drop_table_delegates(self):
        """drop_table 应委托给 _feature_table_client.drop_table"""
        client = _make_client()
        client.drop_table("test_table", database_name="db", catalog_name="cat")
        client._feature_table_client.drop_table.assert_called_once_with(
            "test_table", "db", "cat"
        )

    def test_write_table_delegates(self):
        """write_table 应委托给 _feature_table_client.write_table"""
        client = _make_client()
        mock_df = MagicMock()
        client.write_table("test_table", df=mock_df, mode="overwrite")
        client._feature_table_client.write_table.assert_called_once()
        call_kwargs = client._feature_table_client.write_table.call_args
        assert call_kwargs.kwargs["name"] == "test_table" or call_kwargs[1]["name"] == "test_table"

    # ── 多段式名称集成测试（新增）──

    def test_create_table_three_level_name(self):
        """create_table('cat.db.tbl', ...) → 底层收到拆分参数"""
        client = _make_client()
        mock_ft = MagicMock(spec=FeatureTable)
        client._feature_table_client.create_table.return_value = mock_ft

        result = client.create_table(
            name="cat.db.tbl",
            primary_keys=["id"],
            timestamp_key="ts",
            engine_type=EngineTypes.ICEBERG_ENGINE,
        )

        assert result is mock_ft
        client._feature_table_client.create_table.assert_called_once_with(
            name="tbl",
            primary_keys=["id"],
            engine_type=EngineTypes.ICEBERG_ENGINE,
            database_name="db",
            catalog_name="cat",
            df=None,
            timestamp_key="ts",
            partition_columns=None,
            schema=None,
            description=None,
            tags=None,
        )

    def test_read_table_two_level_name(self):
        """read_table('db.tbl') → 底层收到 name='tbl', database_name='db'"""
        client = _make_client()
        mock_df = MagicMock()
        client._feature_table_client.read_table.return_value = mock_df

        result = client.read_table("db.tbl")
        assert result is mock_df
        client._feature_table_client.read_table.assert_called_once_with(
            name="tbl", database_name="db", catalog_name=None
        )

    def test_write_table_three_level_name(self):
        """write_table('cat.db.tbl', df) → 底层收到拆分参数"""
        client = _make_client()
        mock_df = MagicMock()
        client.write_table("cat.db.tbl", df=mock_df)
        call_kwargs = client._feature_table_client.write_table.call_args.kwargs
        assert call_kwargs["name"] == "tbl"
        assert call_kwargs["database_name"] == "db"
        assert call_kwargs["catalog_name"] == "cat"

    def test_drop_table_three_level_name(self):
        """drop_table('cat.db.tbl') → 底层收到拆分参数"""
        client = _make_client()
        client.drop_table("cat.db.tbl")
        client._feature_table_client.drop_table.assert_called_once_with(
            "tbl", "db", "cat"
        )

    def test_get_table_three_level_name(self):
        """get_table('cat.db.tbl') → 底层收到拆分参数"""
        client = _make_client()
        mock_ft = MagicMock(spec=FeatureTable)
        client._feature_table_client.get_table.return_value = mock_ft

        result = client.get_table("cat.db.tbl")
        assert result is mock_ft
        client._feature_table_client.get_table.assert_called_once_with(
            "tbl", client._spark_client, "db", "cat"
        )


# ═════════════════════════════════════════════
# 9. create_training_set 测试
# ═════════════════════════════════════════════

class TestCreateTrainingSet:
    """create_training_set 方法测试"""

    def test_both_none_raises_value_error(self):
        """feature_lookups 和 feature_spec 都为 None 时抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="Either"):
            client.create_training_set(df=MagicMock(), label="y")

    def test_both_provided_raises_value_error(self):
        """feature_lookups 和 feature_spec 同时提供时抛出 ValueError"""
        client = _make_client()
        lookup = FeatureLookup(
            table_name="cat.schema.tbl",
            feature_names=["f1"],
            lookup_key="id",
        )
        with pytest.raises(ValueError, match="Either"):
            client.create_training_set(
                df=MagicMock(),
                feature_lookups=[lookup],
                label="y",
                feature_spec="cat.schema.tbl",
            )

    @patch("wedata.feature_engineering.client.format_feature_lookups_and_functions", side_effect=lambda sc, f: f)
    def test_feature_lookups_single_level_without_catalog_raises(self, mock_format):
        """单级表名但未提供 catalog_name 和 database_name 时抛出 ValueError"""
        client = _make_client()
        lookup = FeatureLookup(
            table_name="tbl",
            feature_names=["f1"],
            lookup_key="id",
        )
        with pytest.raises(ValueError, match="single-level name"):
            client.create_training_set(
                df=MagicMock(),
                feature_lookups=[lookup],
                label="y",
            )

    @patch("wedata.feature_engineering.client.format_feature_lookups_and_functions", side_effect=lambda sc, f: f)
    def test_feature_lookups_two_level_without_catalog_raises(self, mock_format):
        """两级表名但未提供 catalog_name 时抛出 ValueError"""
        client = _make_client()
        lookup = FeatureLookup(
            table_name="schema.tbl",
            feature_names=["f1"],
            lookup_key="id",
        )
        with pytest.raises(ValueError, match="two-level name"):
            client.create_training_set(
                df=MagicMock(),
                feature_lookups=[lookup],
                label="y",
            )

    @patch("wedata.feature_engineering.client.uc_utils")
    @patch("wedata.feature_engineering.client.format_feature_lookups_and_functions", side_effect=lambda sc, f: f)
    def test_feature_lookups_three_level_succeeds(self, mock_format, mock_uc):
        """三级表名直接成功"""
        client = _make_client()
        mock_uc._is_single_level_name.return_value = False
        mock_uc._is_two_level_name.return_value = False
        mock_uc.get_full_table_name.return_value = "cat.schema.tbl"

        lookup = FeatureLookup(
            table_name="cat.schema.tbl",
            feature_names=["f1"],
            lookup_key="id",
        )

        mock_ts = MagicMock()
        client._training_set_client.create_training_set_from_feature_lookups.return_value = mock_ts

        result = client.create_training_set(
            df=MagicMock(),
            feature_lookups=[lookup],
            label="y",
        )
        assert result is mock_ts
        client._training_set_client.create_training_set_from_feature_lookups.assert_called_once()

    @patch("wedata.feature_engineering.client.uc_utils")
    @patch("wedata.feature_engineering.client.format_feature_lookups_and_functions", side_effect=lambda sc, f: f)
    def test_feature_lookups_single_level_with_params_succeeds(self, mock_format, mock_uc):
        """单级表名且提供 catalog_name 和 database_name 时成功"""
        client = _make_client()
        mock_uc._is_single_level_name.return_value = True
        mock_uc._is_two_level_name.return_value = False
        mock_uc.get_full_table_name.return_value = "cat.db.tbl"

        lookup = FeatureLookup(
            table_name="tbl",
            feature_names=["f1"],
            lookup_key="id",
        )
        mock_ts = MagicMock()
        client._training_set_client.create_training_set_from_feature_lookups.return_value = mock_ts

        result = client.create_training_set(
            df=MagicMock(),
            feature_lookups=[lookup],
            label="y",
            catalog_name="cat",
            database_name="db",
        )
        assert result is mock_ts

    def test_feature_lookups_empty_table_name_raises(self):
        """FeatureLookup.table_name 为空时抛出 ValueError"""
        client = _make_client()
        lookup = FeatureLookup(
            table_name="",
            feature_names=["f1"],
            lookup_key="id",
        )
        with pytest.raises(ValueError, match="must specify a table_name"):
            client.create_training_set(
                df=MagicMock(),
                feature_lookups=[lookup],
                label="y",
            )

    @patch("wedata.feature_engineering.client.uc_utils")
    @patch("wedata.feature_engineering.client.format_feature_lookups_and_functions", side_effect=lambda sc, f: f)
    def test_exclude_columns_default_empty(self, mock_format, mock_uc):
        """不传 exclude_columns 时默认为空列表"""
        client = _make_client()
        mock_uc._is_single_level_name.return_value = False
        mock_uc._is_two_level_name.return_value = False
        mock_uc.get_full_table_name.return_value = "cat.schema.tbl"

        lookup = FeatureLookup(
            table_name="cat.schema.tbl",
            feature_names=["f1"],
            lookup_key="id",
        )
        client._training_set_client.create_training_set_from_feature_lookups.return_value = MagicMock()

        client.create_training_set(
            df=MagicMock(),
            feature_lookups=[lookup],
            label="y",
        )
        call_kwargs = client._training_set_client.create_training_set_from_feature_lookups.call_args
        assert call_kwargs.kwargs.get("exclude_columns") == []

    @patch("wedata.feature_engineering.client.uc_utils")
    @patch("wedata.feature_engineering.client.format_feature_lookups_and_functions", side_effect=lambda sc, f: f)
    def test_feature_function_in_features_list(self, mock_format, mock_uc):
        """FeatureFunction 不需要 table_name 校验"""
        client = _make_client()
        mock_uc._is_single_level_name.return_value = False
        mock_uc._is_two_level_name.return_value = False
        mock_uc.get_full_table_name.return_value = "cat.schema.tbl"

        lookup = FeatureLookup(
            table_name="cat.schema.tbl",
            feature_names=["f1"],
            lookup_key="id",
        )
        func = FeatureFunction(udf_name="my_udf", output_name="derived_feat")
        client._training_set_client.create_training_set_from_feature_lookups.return_value = MagicMock()

        # 不应抛出异常
        client.create_training_set(
            df=MagicMock(),
            feature_lookups=[lookup, func],
            label="y",
        )
        client._training_set_client.create_training_set_from_feature_lookups.assert_called_once()


# ═════════════════════════════════════════════
# 10. _generate_feature_lookups_from_feature_spec 测试
# ═════════════════════════════════════════════

class TestGenerateFeatureLookupsFromFeatureSpec:
    """_generate_feature_lookups_from_feature_spec 私有方法测试"""

    def test_invalid_format_one_part(self):
        """单段字符串抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="Invalid feature_spec format"):
            client._generate_feature_lookups_from_feature_spec("invalid")

    def test_invalid_format_two_parts(self):
        """两段字符串抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="Invalid feature_spec format"):
            client._generate_feature_lookups_from_feature_spec("cat.schema")

    def test_invalid_format_four_parts(self):
        """四段字符串抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="Invalid feature_spec format"):
            client._generate_feature_lookups_from_feature_spec("a.b.c.d")

    def test_empty_segment_raises(self):
        """包含空段的字符串抛出 ValueError"""
        client = _make_client()
        with pytest.raises(ValueError, match="Invalid feature_spec format"):
            client._generate_feature_lookups_from_feature_spec("cat..table")

    def test_invalid_yaml_raises(self):
        """GetFeatureSpec 返回无效 YAML 时抛出 ValueError"""
        import yaml as _yaml

        client = _make_client()
        client._feature_table_client._feature_service_client.GetFeatureSpec.return_value = ":"

        with patch("wedata.feature_engineering.client.yaml") as mock_yaml:
            mock_yaml.safe_load.side_effect = _yaml.YAMLError("invalid yaml")
            mock_yaml.YAMLError = _yaml.YAMLError
            with pytest.raises(ValueError, match="Failed to parse YAML"):
                client._generate_feature_lookups_from_feature_spec("cat.schema.table")

    def test_valid_spec_returns_feature_lookups(self):
        """有效 spec 应返回 FeatureLookup 列表"""
        client = _make_client()
        client._feature_table_client._feature_service_client.GetFeatureSpec.return_value = "yaml_content"

        # 构造 mock FeatureSpec
        mock_fci = MagicMock()
        mock_fci.table_name = "cat.schema.feat_tbl"
        mock_fci.feature_name = "feat1"
        mock_fci.lookup_key = ["id"]
        mock_fci.output_name = "feat1"
        mock_fci.timestamp_lookup_key = None

        mock_table_info = MagicMock()
        mock_table_info.table_name = "cat.schema.feat_tbl"
        mock_table_info.lookback_window = None

        mock_spec = MagicMock()
        mock_spec.feature_column_infos = [mock_fci]
        mock_spec.on_demand_column_infos = []
        mock_spec.table_infos = [mock_table_info]

        with patch("yaml.safe_load", return_value={}), \
             patch("wedata.common.entities.feature_spec.FeatureSpec._from_dict", return_value=mock_spec):
            result = client._generate_feature_lookups_from_feature_spec("cat.schema.table")

        assert len(result) == 1
        assert isinstance(result[0], FeatureLookup)
        assert result[0].table_name == "cat.schema.feat_tbl"
        assert "feat1" in result[0].feature_names

    def test_valid_spec_with_on_demand_returns_feature_functions(self):
        """spec 中包含 on_demand_column_infos 时应返回 FeatureFunction"""
        client = _make_client()
        client._feature_table_client._feature_service_client.GetFeatureSpec.return_value = "yaml"

        mock_odci = MagicMock()
        mock_odci.udf_name = "my_udf"
        mock_odci.input_bindings = {"x": "feat1"}
        mock_odci.output_name = "derived"

        mock_spec = MagicMock()
        mock_spec.feature_column_infos = []
        mock_spec.on_demand_column_infos = [mock_odci]
        mock_spec.table_infos = []

        with patch("yaml.safe_load", return_value={}), \
             patch("wedata.common.entities.feature_spec.FeatureSpec._from_dict", return_value=mock_spec):
            result = client._generate_feature_lookups_from_feature_spec("cat.schema.table")

        assert len(result) == 1
        assert isinstance(result[0], FeatureFunction)
        assert result[0].udf_name == "my_udf"
        assert result[0].output_name == "derived"

    def test_grouping_same_table_and_key(self):
        """同一 table + lookup_key 的多个特征应合并为一个 FeatureLookup"""
        client = _make_client()
        client._feature_table_client._feature_service_client.GetFeatureSpec.return_value = "yaml"

        fci1 = MagicMock()
        fci1.table_name = "cat.schema.tbl"
        fci1.feature_name = "feat1"
        fci1.lookup_key = ["id"]
        fci1.output_name = "feat1"
        fci1.timestamp_lookup_key = ["ts_col"]

        fci2 = MagicMock()
        fci2.table_name = "cat.schema.tbl"
        fci2.feature_name = "feat2"
        fci2.lookup_key = ["id"]
        fci2.output_name = "feat2_renamed"
        fci2.timestamp_lookup_key = ["ts_col"]

        mock_table_info = MagicMock()
        mock_table_info.table_name = "cat.schema.tbl"
        mock_table_info.lookback_window = 3600

        mock_spec = MagicMock()
        mock_spec.feature_column_infos = [fci1, fci2]
        mock_spec.on_demand_column_infos = []
        mock_spec.table_infos = [mock_table_info]

        with patch("yaml.safe_load", return_value={}), \
             patch("wedata.common.entities.feature_spec.FeatureSpec._from_dict", return_value=mock_spec):
            result = client._generate_feature_lookups_from_feature_spec("cat.schema.table")

        assert len(result) == 1
        assert set(result[0].feature_names) == {"feat1", "feat2"}
        assert result[0].lookback_window == datetime.timedelta(seconds=3600)
        # feat2 有重命名（_rename_outputs 是私有属性）
        assert result[0]._rename_outputs.get("feat2") == "feat2_renamed"

    def test_different_tables_create_separate_lookups(self):
        """不同表应生成不同 FeatureLookup"""
        client = _make_client()
        client._feature_table_client._feature_service_client.GetFeatureSpec.return_value = "yaml"

        fci1 = MagicMock()
        fci1.table_name = "cat.schema.tbl1"
        fci1.feature_name = "feat1"
        fci1.lookup_key = ["id"]
        fci1.output_name = "feat1"
        fci1.timestamp_lookup_key = None

        fci2 = MagicMock()
        fci2.table_name = "cat.schema.tbl2"
        fci2.feature_name = "feat2"
        fci2.lookup_key = ["id"]
        fci2.output_name = "feat2"
        fci2.timestamp_lookup_key = None

        ti1 = MagicMock()
        ti1.table_name = "cat.schema.tbl1"
        ti1.lookback_window = None

        ti2 = MagicMock()
        ti2.table_name = "cat.schema.tbl2"
        ti2.lookback_window = None

        mock_spec = MagicMock()
        mock_spec.feature_column_infos = [fci1, fci2]
        mock_spec.on_demand_column_infos = []
        mock_spec.table_infos = [ti1, ti2]

        with patch("yaml.safe_load", return_value={}), \
             patch("wedata.common.entities.feature_spec.FeatureSpec._from_dict", return_value=mock_spec):
            result = client._generate_feature_lookups_from_feature_spec("cat.schema.table")

        lookups = [r for r in result if isinstance(r, FeatureLookup)]
        assert len(lookups) == 2
        table_names = {l.table_name for l in lookups}
        assert table_names == {"cat.schema.tbl1", "cat.schema.tbl2"}

    def test_request_fields_set_correctly(self):
        """GetFeatureSpecRequest 字段应正确设置"""
        client = _make_client()
        client._feature_table_client._feature_service_client.GetFeatureSpec.return_value = "yaml"

        mock_spec = MagicMock()
        mock_spec.feature_column_infos = []
        mock_spec.on_demand_column_infos = []
        mock_spec.table_infos = []

        with patch("yaml.safe_load", return_value={}), \
             patch("wedata.common.entities.feature_spec.FeatureSpec._from_dict", return_value=mock_spec):
            client._generate_feature_lookups_from_feature_spec("my_cat.my_schema.my_table")

        call_args = client._feature_table_client._feature_service_client.GetFeatureSpec.call_args
        req = call_args[0][0]
        assert req.CatalogName == "my_cat"
        assert req.SchemaName == "my_schema"
        assert req.TableName == "my_table"


# ═════════════════════════════════════════════
# 11. log_model 测试
# ═════════════════════════════════════════════

class TestLogModel:
    """log_model 方法测试"""

    def test_log_model_delegates(self):
        """log_model 应委托给 _training_set_client.log_model"""
        client = _make_client()
        mock_model = MagicMock()
        mock_flavor = MagicMock()
        mock_ts = MagicMock()

        client.log_model(
            model=mock_model,
            artifact_path="model_path",
            flavor=mock_flavor,
            training_set=mock_ts,
            registered_model_name="my_model",
        )

        client._training_set_client.log_model.assert_called_once()
        call_kwargs = client._training_set_client.log_model.call_args.kwargs
        assert call_kwargs["model"] is mock_model
        assert call_kwargs["artifact_path"] == "model_path"
        assert call_kwargs["flavor"] is mock_flavor
        assert call_kwargs["training_set"] is mock_ts
        assert call_kwargs["registered_model_name"] == "my_model"

    def test_log_model_default_params(self):
        """log_model 默认参数传递正确"""
        client = _make_client()
        client.log_model(
            model=MagicMock(),
            artifact_path="path",
            flavor=MagicMock(),
        )

        call_kwargs = client._training_set_client.log_model.call_args.kwargs
        assert call_kwargs["training_set"] is None
        assert call_kwargs["registered_model_name"] is None
        assert call_kwargs["model_registry_uri"] is None
        assert call_kwargs["infer_input_example"] is False


# ═════════════════════════════════════════════
# 12. score_batch 测试
# ═════════════════════════════════════════════

class TestScoreBatch:
    """score_batch 方法测试"""

    def test_score_batch_delegates(self):
        """score_batch 应委托给 _training_set_client.score_batch"""
        client = _make_client()
        mock_df = MagicMock()
        mock_result = MagicMock()
        client._training_set_client.score_batch.return_value = mock_result

        result = client.score_batch(
            model_uri="models:/my_model/1",
            df=mock_df,
            result_type="float",
            timestamp_key="ts",
        )

        assert result is mock_result
        client._training_set_client.score_batch.assert_called_once_with(
            model_uri="models:/my_model/1",
            df=mock_df,
            result_type="float",
            client_name="FeatureStoreClient",
            timestamp_key="ts",
        )

    def test_score_batch_default_params(self):
        """score_batch 默认参数"""
        client = _make_client()
        mock_df = MagicMock()

        client.score_batch(model_uri="runs:/abc/model", df=mock_df)

        call_kwargs = client._training_set_client.score_batch.call_args.kwargs
        assert call_kwargs["result_type"] == "double"
        assert call_kwargs["timestamp_key"] is None


# ═════════════════════════════════════════════
# 13. 标签管理测试
# ═════════════════════════════════════════════

class TestTagOperations:
    """set_feature_table_tag / delete_feature_table_tag 测试"""

    def test_set_tag_delegates(self):
        """set_feature_table_tag 应委托给 alter_table_tag(mode='add')"""
        client = _make_client()
        client.set_feature_table_tag(
            name="tbl", database_name="db", key="env", value="prod"
        )
        client._feature_table_client.alter_table_tag.assert_called_once_with(
            name="tbl",
            database_name="db",
            catalog_name=None,
            properties={"env": "prod"},
            mode="add",
        )

    def test_set_tag_with_catalog(self):
        """set_feature_table_tag 传入 catalog_name"""
        client = _make_client()
        client.set_feature_table_tag(
            name="tbl", database_name="db", key="env", value="prod", catalog_name="cat"
        )
        call_kwargs = client._feature_table_client.alter_table_tag.call_args.kwargs
        assert call_kwargs["catalog_name"] == "cat"

    def test_delete_tag_delegates(self):
        """delete_feature_table_tag 应委托给 alter_table_tag(mode='delete')"""
        client = _make_client()
        client.delete_feature_table_tag(
            name="tbl", database_name="db", key="env"
        )
        client._feature_table_client.alter_table_tag.assert_called_once_with(
            name="tbl",
            database_name="db",
            catalog_name=None,
            properties={"env": ""},
            mode="delete",
        )

    # ── 多段式名称标签测试（新增）──

    def test_set_tag_three_level_name(self):
        """set_feature_table_tag('cat.db.tbl', ...) → 底层收到拆分参数"""
        client = _make_client()
        client.set_feature_table_tag(
            name="cat.db.tbl", database_name=None, key="k", value="v"
        )
        client._feature_table_client.alter_table_tag.assert_called_once_with(
            name="tbl",
            database_name="db",
            catalog_name="cat",
            properties={"k": "v"},
            mode="add",
        )

    def test_delete_tag_two_level_name(self):
        """delete_feature_table_tag('db.tbl', ...) → 底层收到拆分参数"""
        client = _make_client()
        client.delete_feature_table_tag(
            name="db.tbl", database_name=None, key="k"
        )
        client._feature_table_client.alter_table_tag.assert_called_once_with(
            name="tbl",
            database_name="db",
            catalog_name=None,
            properties={"k": ""},
            mode="delete",
        )


# ═════════════════════════════════════════════
# 14. 在线表管理测试
# ═════════════════════════════════════════════

class TestOnlineTableOperations:
    """publish_table / drop_online_table 测试"""

    def test_publish_table_delegates(self):
        """publish_table 应委托给 _feature_table_client.publish_table"""
        client = _make_client()
        client.publish_table(
            catalog_name="cat",
            schema_name="schema",
            table_name="tbl",
            online_db_name="online_db",
            online_table_name="online_tbl",
        )
        client._feature_table_client.publish_table.assert_called_once_with(
            catalog_name="cat",
            schema_name="schema",
            table_name="tbl",
            online_db_name="online_db",
            online_table_name="online_tbl",
            trigger=None,
        )

    def test_publish_table_with_trigger(self):
        """publish_table 传入 trigger"""
        client = _make_client()
        mock_trigger = MagicMock()
        client.publish_table(
            catalog_name="cat",
            schema_name="schema",
            table_name="tbl",
            online_db_name="online_db",
            online_table_name="online_tbl",
            trigger=mock_trigger,
        )
        call_kwargs = client._feature_table_client.publish_table.call_args.kwargs
        assert call_kwargs["trigger"] is mock_trigger

    def test_drop_online_table_delegates(self):
        """drop_online_table 应委托给 _feature_table_client.drop_online_table"""
        client = _make_client()
        client.drop_online_table(
            catalog_name="cat", schema_name="schema", table_name="tbl"
        )
        client._feature_table_client.drop_online_table.assert_called_once_with(
            catalog_name="cat",
            schema_name="schema",
            table_name="tbl",
        )


# ═════════════════════════════════════════════
# 15. create_feature_spec 测试
# ═════════════════════════════════════════════

class TestCreateFeatureSpec:
    """create_feature_spec 方法测试"""

    def test_create_feature_spec_delegates(self):
        """create_feature_spec 应委托给 _training_set_client.create_feature_spec"""
        client = _make_client()
        lookup = FeatureLookup(
            table_name="cat.schema.tbl",
            feature_names=["f1"],
            lookup_key="id",
        )
        func = FeatureFunction(udf_name="my_udf")

        client.create_feature_spec(
            name="my_spec",
            features=[lookup, func],
            exclude_columns=["col_to_exclude"],
        )
        client._training_set_client.create_feature_spec.assert_called_once_with(
            "my_spec",
            [lookup, func],
            client._spark_client,
            ["col_to_exclude"],
        )


# ═════════════════════════════════════════════
# 16. spark 属性测试
# ═════════════════════════════════════════════

class TestSparkProperty:
    """spark 属性访问测试"""

    def test_spark_property_returns_spark_session(self):
        """spark 属性应返回内部 _spark"""
        client = _make_client()
        assert client.spark is client._spark
