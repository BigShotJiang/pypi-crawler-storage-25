"""
FeatureEngineeringTableClient.create_table 单元测试

覆盖场景：
- timestamp_key=None 时抛出异常（负向）
- timestamp_key="" 时抛出异常（负向）
- 有效 timestamp_key 时 timestampKeys 无条件写入 TBLPROPERTIES（正向）
- 单主键时属性值为单列名（正向）
- 复合主键时属性值为逗号拼接字符串（正向）
"""
import pytest
from unittest.mock import MagicMock, patch
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

from wedata.feature_engineering.table_client.table_client import FeatureEngineeringTableClient
from wedata.common.constants.engine_types import EngineTypes


# ──────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────

@pytest.fixture
def mock_spark():
    """返回一个最小化的 SparkSession mock。"""
    return MagicMock()


@pytest.fixture
def client(mock_spark):
    """构造 FeatureEngineeringTableClient，跳过云凭证和环境变量依赖。"""
    with patch("wedata.feature_engineering.table_client.table_client.env_utils") as mock_env, \
         patch("wedata.feature_engineering.table_client.table_client.FeatureServiceClient"):
        mock_env.get_temporary_secret.return_value = ("fake_id", "fake_key", "fake_token")
        mock_env.get_workspace_id.return_value = "ws_test"
        mock_env.get_region.return_value = "ap-guangzhou"
        c = FeatureEngineeringTableClient(mock_spark)
    return c


def _make_schema():
    """构造一个最小 StructType，包含主键列和时间列。"""
    return StructType([
        StructField("user_id", IntegerType(), False),
        StructField("item_id", IntegerType(), False),
        StructField("event_time", StringType(), True),
    ])


def _run_create_table(client, primary_keys, timestamp_key):
    """
    执行 create_table 并捕获传给 spark.sql 的 DDL 字符串。
    返回 DDL 字符串（TBLPROPERTIES 部分）。
    """
    spark = client._spark
    with patch.object(client, "_check_table_exists", return_value=False), \
         patch("wedata.feature_engineering.table_client.table_client.common_utils") as mock_utils, \
         patch("wedata.feature_engineering.table_client.table_client.SparkClient"), \
         patch("os.getenv", return_value=""):
        mock_utils.validate_table_name.return_value = None
        mock_utils.validate_database.return_value = None
        mock_utils.build_full_table_name.return_value = "default.test_table"
        mock_utils.get_duplicates.return_value = []

        client.create_table(
            name="test_table",
            primary_keys=primary_keys,
            timestamp_key=timestamp_key,
            engine_type=EngineTypes.ICEBERG_ENGINE,
            schema=_make_schema(),
        )

    # 取所有 spark.sql 调用中包含 TBLPROPERTIES 的 DDL
    ddl_calls = [str(c.args[0]) for c in spark.sql.call_args_list if c.args]
    ddl = next((s for s in ddl_calls if "TBLPROPERTIES" in s), "")
    return ddl


# ──────────────────────────────────────────────
# 负向测试：timestamp_key 不合法时应抛出异常
# ──────────────────────────────────────────────

class TestTimestampKeyValidation:
    """1.1 / 1.2：timestamp_key 为 None 或空字符串时应抛出异常。"""

    def test_timestamp_key_none_raises(self, client):
        """1.1 传入 timestamp_key=None 时应抛出 AssertionError 或 ValueError。"""
        with pytest.raises((AssertionError, ValueError)):
            _run_create_table(client, ["user_id"], None)

    def test_timestamp_key_empty_string_raises(self, client):
        """1.2 传入 timestamp_key="" 时应抛出 AssertionError 或 ValueError。"""
        with pytest.raises((AssertionError, ValueError)):
            _run_create_table(client, ["user_id"], "")


# ──────────────────────────────────────────────
# 正向测试：有效参数时 TBLPROPERTIES 写入正确
# ──────────────────────────────────────────────

class TestTblPropertiesWritten:
    """1.3 / 1.4 / 1.5：有效参数时 timestampKeys 和 primaryKeys 无条件写入。"""

    def test_timestamp_key_written_unconditionally(self, client):
        """1.3 有效 timestamp_key 时 timestampKeys 属性无条件写入 TBLPROPERTIES。"""
        ddl = _run_create_table(client, ["user_id"], "event_time")
        assert "timestampKeys" in ddl
        assert "event_time" in ddl

    def test_single_primary_key_written(self, client):
        """1.4 单主键时 primary-key 和 primaryKeys 属性值为单列名。"""
        ddl = _run_create_table(client, ["user_id"], "event_time")
        assert "user_id" in ddl

    def test_composite_primary_keys_joined_by_comma(self, client):
        """1.5 复合主键时 primary-key 和 primaryKeys 属性值为逗号拼接字符串。"""
        ddl = _run_create_table(client, ["user_id", "item_id"], "event_time")
        assert "user_id,item_id" in ddl
