"""
feature spec 训练集支持相关单元测试

覆盖范围：
- GetFeatureSpecRequest 序列化
- GetFeatureSpecResponse 反序列化
- FeatureServiceClient.GetFeatureSpec（Mock 环境）
- FeatureServiceClient.GetFeatureSpec（集成测试）
- create_training_set feature_spec 参数的各种场景
"""
import os
import pytest
from unittest.mock import MagicMock, patch

from wedata.common.cloud_sdk_client.models import (
    GetFeatureSpecRequest,
    GetFeatureSpecResponse,
)


# ─────────────────────────────────────────────
# 1.3  GetFeatureSpecRequest 单元测试
# ─────────────────────────────────────────────

class TestGetFeatureSpecRequest:
    """任务 1.3：GetFeatureSpecRequest 序列化测试"""

    def test_instantiate(self):
        req = GetFeatureSpecRequest()
        assert req.CatalogName is None
        assert req.SchemaName is None
        assert req.TableName is None

    def test_serialize_all_fields(self):
        req = GetFeatureSpecRequest()
        req.CatalogName = "my_catalog"
        req.SchemaName = "my_schema"
        req.TableName = "my_table"
        result = req._serialize()
        assert result == {
            "CatalogName": "my_catalog",
            "SchemaName": "my_schema",
            "TableName": "my_table",
        }

    def test_serialize_partial_fields(self):
        req = GetFeatureSpecRequest()
        req.CatalogName = "cat"
        result = req._serialize()
        assert "CatalogName" in result
        assert "SchemaName" not in result
        assert "TableName" not in result

    def test_serialize_empty(self):
        req = GetFeatureSpecRequest()
        result = req._serialize()
        assert result == {}

    def test_deserialize(self):
        req = GetFeatureSpecRequest()
        req._deserialize({"CatalogName": "c", "SchemaName": "s", "TableName": "t"})
        assert req.CatalogName == "c"
        assert req.SchemaName == "s"
        assert req.TableName == "t"


# ─────────────────────────────────────────────
# 1.4  GetFeatureSpecResponse 单元测试
# ─────────────────────────────────────────────

class TestGetFeatureSpecResponse:
    """任务 1.4：GetFeatureSpecResponse 反序列化测试"""

    def test_instantiate(self):
        resp = GetFeatureSpecResponse()
        assert resp.FeatureSpecContent is None
        assert resp.RequestId is None

    def test_deserialize(self):
        resp = GetFeatureSpecResponse()
        resp._deserialize({"FeatureSpecContent": "yaml_content", "RequestId": "req-123"})
        assert resp.FeatureSpecContent == "yaml_content"
        assert resp.RequestId == "req-123"

    def test_deserialize_missing_fields(self):
        resp = GetFeatureSpecResponse()
        resp._deserialize({})
        assert resp.FeatureSpecContent is None
        assert resp.RequestId is None

    def test_setter(self):
        resp = GetFeatureSpecResponse()
        resp.FeatureSpecContent = "some_yaml"
        resp.RequestId = "rid"
        assert resp.FeatureSpecContent == "some_yaml"
        assert resp.RequestId == "rid"


# ─────────────────────────────────────────────
# 2.2  GetFeatureSpec Mock 环境单元测试
# ─────────────────────────────────────────────

class TestGetFeatureSpecMock:
    """任务 2.2：FeatureServiceClient.GetFeatureSpec Mock 环境测试"""

    def test_mock_env_returns_empty_string(self):
        """Mock 环境下 GetFeatureSpec 应返回空字符串，不发起真实 API 请求"""
        from wedata.common.cloud_sdk_client.client import FeatureServiceClient

        with patch("wedata.common.cloud_sdk_client.client.is_mock", return_value=True):
            client = FeatureServiceClient.__new__(FeatureServiceClient)
            req = GetFeatureSpecRequest()
            req.CatalogName = "cat"
            req.SchemaName = "schema"
            req.TableName = "tbl"
            result = client.GetFeatureSpec(req)
            assert result == ""

    def test_mock_env_does_not_call_api(self):
        """Mock 环境下不应调用 self.call"""
        from wedata.common.cloud_sdk_client.client import FeatureServiceClient

        with patch("wedata.common.cloud_sdk_client.client.is_mock", return_value=True):
            client = FeatureServiceClient.__new__(FeatureServiceClient)
            client.call = MagicMock()
            req = GetFeatureSpecRequest()
            client.GetFeatureSpec(req)
            client.call.assert_not_called()


# ─────────────────────────────────────────────
# 2.3  GetFeatureSpec 集成测试（需要真实环境变量）
# ─────────────────────────────────────────────

@pytest.mark.integration
class TestGetFeatureSpecIntegration:
    """任务 2.3：GetFeatureSpec 集成测试（需要 TENCENTCLOUD_* 环境变量）"""

    def test_get_feature_spec_returns_yaml(self):
        """真实 API 调用应返回有效 YAML 字符串"""
        secret_id = os.environ.get("TENCENTCLOUD_SECRET_ID")
        secret_key = os.environ.get("TENCENTCLOUD_SECRET_KEY")
        region = os.environ.get("TENCENTCLOUD_REGION")
        catalog = os.environ.get("TEST_FEATURE_SPEC_CATALOG")
        schema = os.environ.get("TEST_FEATURE_SPEC_SCHEMA")
        table = os.environ.get("TEST_FEATURE_SPEC_TABLE")

        if not all([secret_id, secret_key, region, catalog, schema, table]):
            pytest.skip("缺少集成测试所需的环境变量")

        from wedata.common.cloud_sdk_client.client import FeatureServiceClient
        client = FeatureServiceClient(secret_id, secret_key, None, region)
        req = GetFeatureSpecRequest()
        req.CatalogName = catalog
        req.SchemaName = schema
        req.TableName = table
        result = client.GetFeatureSpec(req)
        assert isinstance(result, str)
        assert len(result) > 0


# ─────────────────────────────────────────────
# 4.x  create_training_set feature_spec 参数测试
# ─────────────────────────────────────────────

class TestCreateTrainingSetFeatureSpec:
    """任务 4.1-4.4：create_training_set feature_spec 参数的单元测试"""

    def _make_client(self):
        """构造一个不依赖 Spark 的 FeatureEngineeringClient Mock"""
        from wedata.feature_engineering.client import FeatureEngineeringClient
        client = FeatureEngineeringClient.__new__(FeatureEngineeringClient)
        # Mock 内部依赖
        client._spark = MagicMock()
        client._spark_client = MagicMock()
        client._training_set_client = MagicMock()
        client._feature_table_client = MagicMock()
        return client

    def test_feature_spec_none_does_not_call_get_feature_spec(self):
        """任务 4.1：feature_spec=None 时不调用 GetFeatureSpec，行为与原有逻辑一致"""
        from wedata.common.entities.feature_lookup import FeatureLookup
        from wedata.common.utils import common_utils

        client = self._make_client()
        mock_get_spec = MagicMock()
        client._feature_table_client._feature_service_client.GetFeatureSpec = mock_get_spec

        lookup = FeatureLookup(
            table_name="cat.schema.tbl",
            feature_names=["f1"],
            lookup_key="id",
        )

        with patch.object(common_utils, "validate_table_name"), \
             patch.object(common_utils, "build_full_table_name", return_value="cat.schema.tbl"), \
             patch("wedata.feature_engineering.client.format_feature_lookups_and_functions", return_value=[lookup]):
            client.create_training_set(
                df=MagicMock(),
                feature_lookups=[lookup],
                label="y",
            )

        mock_get_spec.assert_not_called()

    def test_feature_spec_invalid_format_raises_value_error(self):
        """任务 4.2：feature_spec 格式非法时抛出 ValueError"""
        client = self._make_client()

        with pytest.raises(ValueError, match="Invalid feature_spec format"):
            client.create_training_set(
                df=MagicMock(),
                label="y",
                feature_spec="invalid_string",
            )

    def test_feature_spec_invalid_format_two_parts_raises_value_error(self):
        """feature_spec 只有两段时也应抛出 ValueError"""
        client = self._make_client()

        with pytest.raises(ValueError, match="Invalid feature_spec format"):
            client.create_training_set(
                df=MagicMock(),
                label="y",
                feature_spec="catalog.schema",
            )

    def test_feature_spec_and_feature_lookups_mutual_exclusion(self):
        """任务 4.3：feature_spec 与非空 feature_lookups 同时传入时抛出 ValueError"""
        from wedata.common.entities.feature_lookup import FeatureLookup

        client = self._make_client()
        lookup = FeatureLookup(
            table_name="cat.schema.tbl",
            feature_names=["f1"],
            lookup_key="id",
        )

        with pytest.raises(ValueError, match="Either"):
            client.create_training_set(
                df=MagicMock(),
                feature_lookups=[lookup],
                label="y",
                feature_spec="cat.schema.tbl",
            )

    def test_feature_spec_valid_calls_get_feature_spec_and_uses_spec_lookups(self):
        """任务 4.4：feature_spec 有效时正确调用 GetFeatureSpec 并使用 spec 中的 lookups"""
        from wedata.common.entities.feature_spec import FeatureSpec as _FeatureSpec
        from wedata.common.entities.feature_column_info import FeatureColumnInfo
        from wedata.common.entities.column_info import ColumnInfo
        from wedata.common.entities.feature_table_info import FeatureTableInfo
        from wedata.common.utils import common_utils

        client = self._make_client()

        # 构造预设 FeatureSpec 对象（包含一个 FeatureColumnInfo）
        fci = FeatureColumnInfo(
            table_name="cat.schema.feature_tbl",
            feature_name="feat1",
            lookup_key=["id"],
            output_name="feat1",
        )
        col_info = ColumnInfo(info=fci, include=True)
        mock_spec = _FeatureSpec(
            column_infos=[col_info],
            table_infos=[FeatureTableInfo(table_name="cat.schema.feature_tbl", table_id="tid")],
            function_infos=[],
            serialization_version=9,
        )

        # Mock GetFeatureSpec 返回预设 YAML 字符串
        mock_yaml_str = "input_columns: []"
        client._feature_table_client._feature_service_client.GetFeatureSpec = MagicMock(
            return_value=mock_yaml_str
        )

        captured_lookups = []

        def mock_create_training_set(**kwargs):
            captured_lookups.extend(kwargs.get("feature_lookups", []))
            return MagicMock()

        client._training_set_client.create_training_set_from_feature_lookups = MagicMock(
            side_effect=mock_create_training_set
        )

        with patch("yaml.safe_load", return_value={}), \
             patch.object(common_utils, "validate_table_name"), \
             patch.object(common_utils, "build_full_table_name", side_effect=lambda t, *a, **kw: t), \
             patch("wedata.feature_engineering.client.format_feature_lookups_and_functions",
                   side_effect=lambda sc, f: f), \
             patch(
                 "wedata.common.entities.feature_spec.FeatureSpec._from_dict",
                 return_value=mock_spec,
             ):
            client.create_training_set(
                df=MagicMock(),
                label="y",
                feature_spec="cat.schema.tbl",
            )

        # 验证 GetFeatureSpec 被调用
        client._feature_table_client._feature_service_client.GetFeatureSpec.assert_called_once()
        # 验证最终 feature_lookups 来自 spec（包含 feat1）
        assert len(captured_lookups) == 1
        assert captured_lookups[0].table_name == "cat.schema.feature_tbl"
        assert "feat1" in captured_lookups[0].feature_names
        assert captured_lookups[0].catalog_name == "cat"
        assert captured_lookups[0].schema_name == "schema"
