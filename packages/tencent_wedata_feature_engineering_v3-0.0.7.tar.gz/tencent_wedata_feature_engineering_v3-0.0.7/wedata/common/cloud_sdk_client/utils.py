import os
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.profile.client_profile import ClientProfile


def _is_test_environment():
    """判断是否是测试环境"""
    return os.environ.get("IS_WEDATA_TEST", "").lower() in ["true", "1"]


def get_client_profile() -> 'ClientProfile':
    """
    获取网络客户端配置，从环境变量 TENCENTCLOUD_ENDPOINT 读取 endpoint，默认值为 wedata.internal.tencentcloudapi.com
    """
    endpoint = os.getenv("TENCENTCLOUD_ENDPOINT", "wedata.internal.tencentcloudapi.com")

    http_profile = HttpProfile()
    http_profile.protocol = "https"
    http_profile.endpoint = endpoint

    client_profile = ClientProfile()
    client_profile.httpProfile = http_profile
    return client_profile


def set_request_header(headers):
    """
    获取腾讯云API请求头, 如果是测试环境:
      1. 必须设置环境变量TEST_USER_ID, 否则报错
      2. 添加X-Qcloud-User-Id；否则不添加
    """
    if headers is None:
        headers = {}
    if _is_test_environment():
        test_user_id = os.environ.get("TEST_USER_ID")
        if not test_user_id:
            raise ValueError("TEST_USER_ID environment variable is required in test environment")
        headers["X-Qcloud-User-Id"] = test_user_id
    return headers


def is_mock() -> bool:
    """
    是否为模拟环境
    """
    return os.getenv("IS_MOCK_API") == "true"


def is_warning() -> bool:
    """
    是否展示警告环境
    """
    return os.getenv("IS_CLOUD_API_WARNING") == "true"

