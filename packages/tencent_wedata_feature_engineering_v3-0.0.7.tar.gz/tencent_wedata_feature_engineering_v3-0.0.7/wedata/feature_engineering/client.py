from __future__ import annotations

__doc__ = """
WeData3.0 特征工程客户端

"""

import re
import pytz
from collections import defaultdict
from types import ModuleType
from typing import Any, Dict, List, Optional, Union

import mlflow
import yaml
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.streaming import StreamingQuery
from pyspark.sql.types import StructType
from pyspark.errors import IllegalArgumentException

from wedata.common.cloud_sdk_client.models import GetFeatureSpecRequest, SchedulerConfiguration
from wedata.common.constants.constants import (
    APPEND,
    DEFAULT_WRITE_STREAM_TRIGGER,
    FEATURE_LOOKUP_CLIENT_PIP_PACKAGE,
    FEATURE_STORE_CLIENT,
)
from wedata.common.entities.feature_function import FeatureFunction
from wedata.common.entities.feature_lookup import FeatureLookup
from wedata.common.entities.feature_spec import FeatureSpec
from wedata.common.entities.feature_table import FeatureTable
from wedata.common.entities.training_set import TrainingSet
from wedata.common.spark_client import SparkClient
from wedata.common.utils import common_utils, env_utils, uc_utils
from wedata.common.utils.uc_utils import SINGLE_LEVEL_NAMESPACE_REGEX
from wedata.common.utils.feature_utils import format_feature_lookups_and_functions
from wedata.feature_engineering.ml_training_client.ml_training_client import MLTrainingClient
from wedata.feature_engineering.table_client.table_client import FeatureEngineeringTableClient
from wedata.common.constants.engine_types import EngineTypes


_i, _v, _ = common_utils.check_package_version("mlflow", "3.0.0", ">=")
if not _v:
    raise ImportError(f"mlflow version must be greater than or equal to 3.0.0. "
                      f"current version is {mlflow.__version__}. "
                      f"you can install please install {FEATURE_LOOKUP_CLIENT_PIP_PACKAGE}[mlflow3]")


class FeatureEngineeringClient:
    def __init__(self, spark: Optional[SparkSession] = None, ):
        if spark is None:
            spark = SparkSession.builder.getOrCreate()
        self._spark = spark
        self._spark_client = SparkClient(spark)
        cloud_secret_id, cloud_secret_key, token = env_utils.get_temporary_secret()
        self._feature_table_client = FeatureEngineeringTableClient(
            spark, cloud_secret_id=cloud_secret_id, cloud_secret_key=cloud_secret_key, cloud_secret_token=token)
        self._training_set_client = MLTrainingClient(self._spark_client)

        try:
            spark_timezone = self._spark.conf.get("spark.sql.session.timeZone", "")  # noqa
            if spark_timezone:
                pytz_timezone = self._translate_spark_timezone(spark_timezone)
                self._spark.conf.set("spark.sql.session.timeZone", pytz_timezone)
            else:
                self._spark.conf.set("spark.sql.session.timeZone", "Etc/GMT+8")
        except (IllegalArgumentException, ValueError):
            self._spark.conf.set("spark.sql.session.timeZone", "Etc/GMT+8")

    @staticmethod
    def _translate_spark_timezone(timezone: str) -> str:
        """
        将Spark时区字符串转换为pytz时区字符串
        Args:
            timezone: Spark时区字符串
        Returns:
            Feast时区字符串
        """
        try:
            py_timezone = pytz.timezone(timezone)
        except pytz.exceptions.UnknownTimeZoneError:
            # GMT+08:00 转换为 'Etc/GMT+8'
            result = re.compile(r"GMT([+-])(\d{2}):(\d{2})").match(timezone)
            if result:
                groups = result.groups()
                if len(groups) == 3:
                    return f"Etc/GMT{groups[0]}{int(groups[1])}"
            else:
                raise ValueError(f"Invalid timezone string: {timezone}")
        else:
            return str(py_timezone)

    def _generate_feature_lookups_from_feature_spec(
            self,
            feature_spec: str,
    ) -> List[Union[FeatureLookup, FeatureFunction]]:
        """
        通过三段式 feature spec 字符串从云端获取 spec 内容，并转换为 FeatureLookup / FeatureFunction 列表。

        Args:
            feature_spec: 三段式字符串 catalog.schema.table，指定已注册的 feature spec

        Returns:
            List[Union[FeatureLookup, FeatureFunction]]：从 spec 中提取的特征查询列表，
            包含 FeatureLookup（来自 feature_column_infos）和 FeatureFunction（来自 on_demand_column_infos）

        Raises:
            ValueError: feature_spec 格式非法时抛出
        """
        import datetime

        # 解析三段式字符串 catalog.schema.table
        parts = feature_spec.split(".")
        if len(parts) != 3 or not all(parts):
            raise ValueError(
                f"Invalid feature_spec format: '{feature_spec}'. "
                "Expected format: catalog.schema.table (three dot-separated segments)."
            )
        spec_catalog, spec_schema, spec_table = parts

        # 构造请求并调用云端 API 获取 YAML 字符串
        request = GetFeatureSpecRequest()
        request.CatalogName = spec_catalog
        request.SchemaName = spec_schema
        request.TableName = spec_table
        yaml_str = self._feature_table_client._feature_service_client.GetFeatureSpec(request)

        # 通过 yaml.safe_load + FeatureSpec._from_dict 加载 FeatureSpec 对象
        try:
            spec_dict = yaml.safe_load(yaml_str)
        except yaml.YAMLError as e:
            raise ValueError(f"Failed to parse YAML string: {e}")
        loaded_spec = FeatureSpec._from_dict(spec_dict)

        # 构建 table_name -> lookback_window 映射（单位：秒，转为 timedelta）
        table_lookback: dict = {
            ti.table_name: (
                datetime.timedelta(seconds=ti.lookback_window)
                if ti.lookback_window is not None
                else None
            )
            for ti in loaded_spec.table_infos
        }

        # 从 feature_column_infos 中提取 FeatureLookup 列表
        # 按 (table_name, lookup_key, timestamp_lookup_key) 分组，聚合 feature_names 和 rename_outputs
        groups: dict = defaultdict(lambda: {"feature_names": [], "rename_outputs": {}})
        for fci in loaded_spec.feature_column_infos:
            key = (fci.table_name, tuple(fci.lookup_key), tuple(fci.timestamp_lookup_key) if fci.timestamp_lookup_key is not None else ())
            groups[key]["feature_names"].append(fci.feature_name)
            # 若 output_name 与 feature_name 不同，则记录重命名映射
            if fci.output_name != fci.feature_name:
                groups[key]["rename_outputs"][fci.feature_name] = fci.output_name

        result: List[Union[FeatureLookup, FeatureFunction]] = []
        for key, info in groups.items():
            table_name, lookup_key, timestamp_lookup_key = key
            lookup = FeatureLookup(
                table_name=table_name,
                feature_names=info["feature_names"],
                lookup_key=list(lookup_key),
                timestamp_lookup_key=list(timestamp_lookup_key) if timestamp_lookup_key else None,
                lookback_window=table_lookback.get(table_name),
                rename_outputs=info["rename_outputs"] if info["rename_outputs"] else None,
            )
            result.append(lookup)

        # 从 on_demand_column_infos 中提取 FeatureFunction 列表
        for odci in loaded_spec.on_demand_column_infos:
            feature_function = FeatureFunction(
                udf_name=odci.udf_name,
                input_bindings=odci.input_bindings if odci.input_bindings else None,
                output_name=odci.output_name,
            )
            result.append(feature_function)

        return result

    @staticmethod
    def _parse_table_name(
        name: str,
        database_name: Optional[str],
        catalog_name: Optional[str],
    ) -> tuple[str, Optional[str], Optional[str]]:
        """解析表名，支持单级、二段式、三段式格式。

        解析规则：
        - 单级 `table`：原样返回，使用传入的 database_name 和 catalog_name
        - 二段式 `schema.table`：从 name 中提取 schema 和 table
        - 三段式 `catalog.schema.table`：从 name 中提取 catalog、schema 和 table

        多段式解析结果与显式参数冲突时抛出 ValueError。
        各段通过 SINGLE_LEVEL_NAMESPACE_REGEX 校验，不允许包含空格、斜杠和控制字符。

        Args:
            name: 表名。支持 `table`、`schema.table`、`catalog.schema.table`
            database_name: 数据库名称（可选）
            catalog_name: catalog 名称（可选）

        Returns:
            (table_name, database_name, catalog_name) 三元组

        Raises:
            ValueError: name 为空、段数不合法（超过 3 段）、段格式非法、或与显式参数冲突
        """
        if not name or not isinstance(name, str):
            raise ValueError("name must be a non-empty string")

        parts = name.split(".")
        if len(parts) > 3:
            raise ValueError(
                f"name '{name}' contains too many segments "
                f"(expected at most 3: 'catalog.schema.table')"
            )

        # 使用 SINGLE_LEVEL_NAMESPACE_REGEX 校验各段合法性
        # 该正则不允许空格、点号、斜杠和控制字符
        for part in parts:
            if not re.match(SINGLE_LEVEL_NAMESPACE_REGEX, part):
                raise ValueError(
                    f"name '{name}' contains invalid segment '{part}': "
                    f"each segment must be non-empty and cannot include "
                    f"space, dot, forward-slash or control characters"
                )

        if len(parts) == 3:
            parsed_catalog, parsed_schema, parsed_table = parts
            if catalog_name and catalog_name != parsed_catalog:
                raise ValueError(
                    f"catalog_name '{catalog_name}' conflicts with catalog "
                    f"'{parsed_catalog}' parsed from name '{name}'"
                )
            if database_name and database_name != parsed_schema:
                raise ValueError(
                    f"database_name '{database_name}' conflicts with schema "
                    f"'{parsed_schema}' parsed from name '{name}'"
                )
            return parsed_table, parsed_schema, parsed_catalog

        if len(parts) == 2:
            parsed_schema, parsed_table = parts
            if database_name and database_name != parsed_schema:
                raise ValueError(
                    f"database_name '{database_name}' conflicts with schema "
                    f"'{parsed_schema}' parsed from name '{name}'"
                )
            return parsed_table, parsed_schema, catalog_name

        # 单级名：原样返回
        return name, database_name, catalog_name

    def _build_full_database_name(
            self,
            database_name: str,
            catalog_name: Optional[str] = None,
    ) -> str:
        """构建完整的数据库名 `<catalog>.<database>` 或 `<database>`。

        支持 database_name 传入二段式 `catalog.schema`，自动拆分。

        Args:
            database_name: 数据库名称。支持单级名 `schema` 或二段式 `catalog.schema`。
            catalog_name: catalog 名称（可选）。当 database_name 为二段式时，
                          若同时传入 catalog_name 且与二段式中的 catalog 不一致，抛出 ValueError。
                          当 database_name 为单级名且未传入 catalog_name 时，从 Spark 会话自动获取当前 catalog；
                          若无法获取，则仅返回数据库名本身。

        Returns:
            完整数据库名 `<catalog>.<database>` 或 `<database>`

        Raises:
            ValueError: database_name 为空、包含两个以上点号、或与 catalog_name 冲突
        """
        if not database_name or not isinstance(database_name, str):
            raise ValueError("database_name must be a non-empty string")

        parts = database_name.split(".")
        if len(parts) > 2:
            raise ValueError(
                f"database_name '{database_name}' contains too many segments "
                f"(expected at most 2: 'catalog.schema')"
            )

        # 使用 SINGLE_LEVEL_NAMESPACE_REGEX 校验各段合法性
        for part in parts:
            if not re.match(SINGLE_LEVEL_NAMESPACE_REGEX, part):
                raise ValueError(
                    f"database_name '{database_name}' contains invalid segment "
                    f"'{part}': each segment must be non-empty and cannot "
                    f"include space, dot, forward-slash or control characters"
                )

        if len(parts) == 2:
            # 二段式：catalog.schema
            parsed_catalog, parsed_schema = parts
            if catalog_name and catalog_name != parsed_catalog:
                raise ValueError(
                    f"catalog_name '{catalog_name}' conflicts with catalog "
                    f"'{parsed_catalog}' parsed from database_name '{database_name}'"
                )
            return f"{parsed_catalog}.{parsed_schema}"

        # 单级名：保持原有逻辑
        target_catalog = catalog_name
        if not target_catalog:
            try:
                target_catalog = self._spark_client.get_current_catalog()
            except Exception:
                target_catalog = None

        if target_catalog:
            return f"{target_catalog}.{database_name}"
        return database_name

    def _check_database_exists(
        self,
        full_db_name: str,
        database_name: str,
        catalog_name: Optional[str] = None,
    ) -> bool:
        """检查数据库是否存在（内部辅助方法）。

        从 full_db_name 中提取 effective_catalog，通过 list_databases 在正确的
        catalog 范围内查询数据库列表，兼容返回简单名或完整名的两种情况。

        Args:
            full_db_name: _build_full_database_name 返回的完整数据库名
            database_name: 用户原始传入的 database_name 参数
            catalog_name: 用户原始传入的 catalog_name 参数（可选）

        Returns:
            bool: 数据库存在返回 True，否则返回 False

        Raises:
            Exception: list_databases 调用失败时向上传播
        """
        effective_catalog = (
            full_db_name.split(".")[0] if "." in full_db_name else catalog_name
        )
        db_list = self.list_databases(catalog_name=effective_catalog)
        simple_db_name = (
            full_db_name.split(".")[-1] if "." in full_db_name else full_db_name
        )
        return (
            full_db_name in db_list
            # 兼容单级名场景：当 database_name 为单级名时，其值可能与
            # full_db_name（含 catalog 前缀）和 simple_db_name（从 full_db_name
            # 提取的纯数据库名）不同。例如用户传入 database_name="my_db"，
            # full_db_name="cat.my_db"，simple_db_name="my_db"，此时
            # database_name == simple_db_name；但当 database_name 本身就是
            # 二段式（如 "cat.my_db"）时，database_name == full_db_name，
            # 这里做冗余比对不影响正确性。
            or database_name in db_list
            or simple_db_name in db_list
        )

    def create_database(
        self,
        database_name: str,
        catalog_name: Optional[str] = None,
        comment: Optional[str] = None,
        location: Optional[str] = None
    ) -> str:
        """创建数据库（如果不存在则创建），支持指定 catalog。

        支持 database_name 传入二段式 ``catalog.schema`` 格式，自动拆分为 catalog 和 schema。

        Args:
            database_name: 数据库名称。支持单级名 ``schema`` 或二段式 ``catalog.schema``。
            catalog_name: catalog 名称（可选）。如果不提供，将使用当前 Spark 会话的 catalog。
                当 database_name 为二段式时，若同时传入 catalog_name 且与二段式中的 catalog 不一致，
                抛出 ValueError。
            comment: 数据库描述（可选）
            location: 数据库存储位置（可选）

        Returns:
            str: 创建的完整数据库名称（包含 catalog）

        Raises:
            ValueError: 如果 database_name 为空、包含两个以上点号、或与 catalog_name 冲突

        Examples:
            >>> # 使用当前 catalog 创建数据库
            >>> client.create_database("my_db")
            'spark_catalog.my_db'

            >>> # 在指定 catalog 下创建数据库
            >>> client.create_database("my_db", catalog_name="DataLakeCatalog")
            'DataLakeCatalog.my_db'

            >>> # 使用二段式名称创建数据库
            >>> client.create_database("DataLakeCatalog.my_db")
            'DataLakeCatalog.my_db'

            >>> # 创建带描述的数据库
            >>> client.create_database("my_db", comment="我的特征数据库")
            'spark_catalog.my_db'

        说明:
            使用 ``CREATE DATABASE IF NOT EXISTS`` 实现幂等创建：

            * 如果数据库不存在，则创建；
            * 如果数据库已存在，则不报错。
        """
        from wedata.common.log import get_logger
        logger = get_logger()

        # 构建完整数据库名
        full_db_name = self._build_full_database_name(database_name, catalog_name)

        # 检查数据库是否已存在
        try:
            if self._check_database_exists(full_db_name, database_name, catalog_name):
                logger.info(f"Database '{full_db_name}' already exists, skipping creation")
                return full_db_name
        except Exception as e:
            logger.warning(f"Failed to check database existence: {e}, proceeding with creation")

        # 构建 DDL
        ddl = f"CREATE DATABASE IF NOT EXISTS {full_db_name}"

        if comment:
            # 转义单引号，防止 SQL 注入
            safe_comment = comment.replace("\\", "\\\\").replace("'", "\\'")
            ddl += f" COMMENT '{safe_comment}'"

        if location:
            # 转义单引号，防止 SQL 注入
            safe_location = location.replace("\\", "\\\\").replace("'", "\\'")
            ddl += f" LOCATION '{safe_location}'"

        logger.info(f"Creating database: {full_db_name}")
        logger.debug(f"DDL: {ddl}")

        try:
            self._spark.sql(ddl)
            logger.info(f"Database '{full_db_name}' created successfully")
        except Exception as e:
            logger.error(f"Failed to create database '{full_db_name}': {e}")
            raise

        return full_db_name

    def drop_database(
        self,
        database_name: str,
        catalog_name: Optional[str] = None,
        cascade: bool = False,
        if_exists: bool = True
    ) -> bool:
        """删除数据库（如果存在则删除），支持指定 catalog。

        支持 database_name 传入二段式 ``catalog.schema`` 格式，自动拆分为 catalog 和 schema。

        Args:
            database_name: 数据库名称。支持单级名 ``schema`` 或二段式 ``catalog.schema``。
            catalog_name: catalog 名称（可选）。如果不提供，将使用当前 Spark 会话的 catalog。
                当 database_name 为二段式时，若同时传入 catalog_name 且与二段式中的 catalog 不一致，
                抛出 ValueError。
            cascade: 是否级联删除数据库中的所有表（默认 False，避免误删）
            if_exists: 是否使用 IF EXISTS（默认 True，数据库不存在时不报错）

        Returns:
            bool: 如果数据库被删除返回 True，如果数据库不存在返回 False

        Raises:
            ValueError: 如果 database_name 为空、包含两个以上点号、或与 catalog_name 冲突
            Exception: 如果数据库非空且 cascade=False，或其他删除失败的情况

        Examples:
            >>> # 删除空数据库
            >>> client.drop_database("my_db")
            True

            >>> # 删除指定 catalog 下的数据库
            >>> client.drop_database("my_db", catalog_name="DataLakeCatalog")
            True

            >>> # 使用二段式名称删除数据库
            >>> client.drop_database("DataLakeCatalog.my_db")
            True

            >>> # 级联删除数据库及其所有表（危险操作！）
            >>> client.drop_database("my_db", cascade=True)
            True

        说明:
            * 默认使用 ``DROP DATABASE IF EXISTS``，数据库不存在时不报错
            * 默认不使用 CASCADE，如果数据库非空会抛出异常，避免误删数据
            * 设置 cascade=True 会删除数据库中的所有表，请谨慎使用
        """
        from wedata.common.log import get_logger
        logger = get_logger()

        # 构建完整数据库名
        full_db_name = self._build_full_database_name(database_name, catalog_name)

        # 检查数据库是否存在
        exists = False
        try:
            exists = self._check_database_exists(full_db_name, database_name, catalog_name)
            if not exists:
                logger.info(f"Database '{full_db_name}' does not exist, skipping deletion")
                return False
        except Exception as e:
            logger.warning(f"Failed to check database existence: {e}, proceeding with deletion")

        # 构建 DDL
        if if_exists:
            ddl = f"DROP DATABASE IF EXISTS {full_db_name}"
        else:
            ddl = f"DROP DATABASE {full_db_name}"

        if cascade:
            ddl += " CASCADE"
            logger.warning(f"Dropping database '{full_db_name}' with CASCADE - all tables will be deleted!")

        logger.info(f"Dropping database: {full_db_name}")
        logger.debug(f"DDL: {ddl}")

        try:
            self._spark.sql(ddl)
            logger.info(f"Database '{full_db_name}' dropped successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to drop database '{full_db_name}': {e}")
            raise

    def list_databases(self, catalog_name: Optional[str] = None) -> List[str]:
        """列出指定 catalog 下的所有数据库。

        Args:
            catalog_name: catalog 名称（可选）。如果不提供，将列出当前 catalog 下的所有数据库。

        Returns:
            List[str]: 数据库名称列表

        Examples:
            >>> # 列出当前 catalog 下的所有数据库
            >>> client.list_databases()
            ['default', 'my_db', 'test_db']

            >>> # 列出指定 catalog 下的所有数据库
            >>> client.list_databases(catalog_name="DataLakeCatalog")
            ['default', 'feature_db']
        """
        from wedata.common.log import get_logger
        logger = get_logger()

        try:
            if catalog_name:
                # 尝试使用 SHOW DATABASES IN catalog 语法
                try:
                    databases = self._spark.sql(f"SHOW DATABASES IN {catalog_name}").collect()
                except Exception:
                    # 如果不支持，尝试切换 catalog
                    original_catalog = self._spark_client.get_current_catalog()
                    try:
                        self._spark.catalog.setCurrentCatalog(catalog_name)
                        databases = self._spark.sql("SHOW DATABASES").collect()
                    finally:
                        # 恢复原 catalog
                        if original_catalog:
                            try:
                                self._spark.catalog.setCurrentCatalog(original_catalog)
                            except Exception:
                                pass
            else:
                databases = self._spark.sql("SHOW DATABASES").collect()

            db_list = [row.namespace for row in databases]
            logger.debug(f"Found {len(db_list)} databases: {db_list}")
            return db_list

        except Exception as e:
            logger.error(f"Failed to list databases: {e}")
            raise

    def database_exists(self, database_name: str, catalog_name: Optional[str] = None) -> bool:
        """检查数据库是否存在。

        支持 database_name 传入二段式 ``catalog.schema`` 格式，自动拆分为 catalog 和 schema。

        Args:
            database_name: 数据库名称。支持单级名 ``schema`` 或二段式 ``catalog.schema``。
            catalog_name: catalog 名称（可选）。如果不提供，将在当前 catalog 下检查。
                当 database_name 为二段式时，若同时传入 catalog_name 且与二段式中的 catalog 不一致，
                抛出 ValueError。

        Returns:
            bool: 数据库存在返回 True，否则返回 False

        Examples:
            >>> # 检查当前 catalog 下的数据库
            >>> client.database_exists("my_db")
            True

            >>> # 检查指定 catalog 下的数据库
            >>> client.database_exists("my_db", catalog_name="DataLakeCatalog")
            False

            >>> # 使用二段式名称检查
            >>> client.database_exists("DataLakeCatalog.my_db")
            True
        """
        try:
            full_db_name = self._build_full_database_name(database_name, catalog_name)
            return self._check_database_exists(full_db_name, database_name, catalog_name)
        except Exception:
            return False


    def create_table(
            self,
            name: str,
            primary_keys: Union[str, List[str]],
            timestamp_key: str,
            engine_type: EngineTypes,
            database_name: Optional[str] = None,
            catalog_name: Optional[str] = None,
            df: Optional[DataFrame] = None,
            *,
            partition_columns: Union[str, List[str], None] = None,
            schema: Optional[StructType] = None,
            description: Optional[str] = None,
            tags: Optional[Dict[str, str]] = None
    ) -> FeatureTable:
        """
        创建特征表（支持批流数据写入）

        Args:
            name: 特征表全称（格式：<table>）
            primary_keys: 主键列名（支持复合主键）
            timestamp_key: 时间戳键（用于时态特征）
            engine_type: 引擎类型  wedata.common.constants.engine_types.EngineTypes
            database_name: 数据库名
            catalog_name: catalog名称（可选）。如果不提供，将使用当前Spark会话的catalog
            df: 初始数据（可选，用于推断schema）
            partition_columns: 分区列（优化存储查询）
            schema: 表结构定义（可选，当不提供df时必需）
            description: 业务描述
            tags: 业务标签

        Returns:
            FeatureTable实例

        Raises:
            ValueError: 当schema与数据不匹配时
        """
        name, database_name, catalog_name = self._parse_table_name(
            name, database_name, catalog_name
        )

        return self._feature_table_client.create_table(
            name=name,
            primary_keys=primary_keys,
            engine_type=engine_type,
            database_name=database_name,
            catalog_name=catalog_name,
            df=df,
            timestamp_key=timestamp_key,
            partition_columns=partition_columns,
            schema=schema,
            description=description,
            tags=tags
        )

    def read_table(self, name: str, database_name: Optional[str] = None, catalog_name: Optional[str] = None) -> DataFrame:
        """
        读取特征表数据

        Args:
            name: 特征表名称
            database_name: 特征库名称
            catalog_name: catalog名称（可选）。如果不提供，将使用当前Spark会话的catalog
        Returns:
            DataFrame: 包含特征表数据的DataFrame对象
        """
        name, database_name, catalog_name = self._parse_table_name(
            name, database_name, catalog_name
        )

        return self._feature_table_client.read_table(name=name, database_name=database_name, catalog_name=catalog_name)

    def get_table(self, name: str, database_name: Optional[str] = None, catalog_name: Optional[str] = None) -> FeatureTable:
        """
        获取特征表元数据
        Args:
            name: 特征表名称
            database_name: 特征库名称
            catalog_name: catalog名称（可选）。如果不提供，将使用当前Spark会话的catalog

        Returns:
            FeatureTable: 包含特征表元数据的FeatureTable对象
        """
        name, database_name, catalog_name = self._parse_table_name(
            name, database_name, catalog_name
        )

        return self._feature_table_client.get_table(name, self._spark_client, database_name, catalog_name)

    def drop_table(self, name: str, database_name: Optional[str] = None, catalog_name: Optional[str] = None) -> None:
        """
        删除特征表

        Args:
            name: 要删除的特征表名称
            database_name: database name
            catalog_name: catalog名称（可选）。如果不提供，将使用当前Spark会话的catalog
        Returns:
            None
        """
        name, database_name, catalog_name = self._parse_table_name(
            name, database_name, catalog_name
        )

        return self._feature_table_client.drop_table(name, database_name, catalog_name)

    def write_table(
            self,
            name: str,
            df: DataFrame,
            database_name: Optional[str] = None,
            catalog_name: Optional[str] = None,
            mode: Optional[str] = APPEND,
            checkpoint_location: Optional[str] = None,
            trigger: Dict[str, Any] = DEFAULT_WRITE_STREAM_TRIGGER,
    ) -> Optional[StreamingQuery]:
        """
        写入数据到特征表（支持批处理和流式处理）

        Args:
            name: 特征表名称
            df: 要写入的数据DataFrame
            database_name: 特征库名称
            catalog_name: catalog名称（可选）。如果不提供，将使用当前Spark会话的catalog
            mode: 写入模式（默认追加）
            checkpoint_location: 流式处理的检查点位置（可选）
            trigger: 流式处理触发器配置（默认使用系统预设）

        Returns:
            如果是流式写入返回StreamingQuery对象，否则返回None
        """
        name, database_name, catalog_name = self._parse_table_name(
            name, database_name, catalog_name
        )

        return self._feature_table_client.write_table(
            name=name,
            df=df,
            database_name=database_name,
            catalog_name=catalog_name,
            mode=mode,
            checkpoint_location=checkpoint_location,
            trigger=trigger,
        )

    def create_training_set(
            self,
            df: DataFrame,
            feature_lookups: Optional[List[Union[FeatureLookup, FeatureFunction]]] = None,
            label: Optional[Union[str, List[str]]] = None,
            exclude_columns: Optional[List[str]] = None,
            database_name: Optional[str] = None,
            catalog_name: Optional[str] = None,
            feature_spec: Optional[str] = None,
            **kwargs,
    ) -> TrainingSet:
        """
        创建训练集

        Args:
            df: 基础数据
            feature_lookups: 特征查询列表，与 feature_spec 互斥，二者只能选其一（可选）
            label: 标签列名
            exclude_columns: 排除列名
            database_name: database name
            catalog_name: catalog名称（可选）。如果不提供，将使用当前Spark会话的catalog
            feature_spec: 三段式字符串 catalog.schema.table，指定已注册的 feature spec。
                与 feature_lookups 互斥，同时传入时抛出 ValueError。
                当传入时，系统将通过云端 API 获取 spec 内容，并从中提取 FeatureLookup 列表。

        Returns:
            TrainingSet实例
        """
        if (feature_spec is None) == (feature_lookups is None):
            raise ValueError(
                "Either 'feature_spec' or 'feature_lookups' must be provided, but not both."
            )

        if feature_spec is not None:
            feature_lookups = self._generate_feature_lookups_from_feature_spec(
                feature_spec=feature_spec,
            )

        if exclude_columns is None:
            exclude_columns = []

        # 如果为FeatureLookup，则将需要校验FeatureLookup的table_name，并构建完整表名
        for feature in feature_lookups:
            if isinstance(feature, FeatureLookup):
                if not feature.table_name:
                    raise ValueError("FeatureLookup must specify a table_name")
                # 根据表名层级校验必需参数
                if uc_utils._is_single_level_name(feature.table_name):
                    if not catalog_name or not database_name:
                        raise ValueError(
                            f"When table_name '{feature.table_name}' is a single-level name, "
                            f"both 'catalog_name' and 'database_name' must be provided."
                        )
                elif uc_utils._is_two_level_name(feature.table_name):
                    if not catalog_name:
                        raise ValueError(
                            f"When table_name '{feature.table_name}' is a two-level name (schema.table), "
                            f"'catalog_name' must be provided."
                        )
                # 构建完整的三级限定表名（catalog.schema.table），并赋值给FeatureLookup对象
                feature.table_name = uc_utils.get_full_table_name(
                    feature.table_name,
                    current_catalog=catalog_name,
                    current_schema=database_name,
                )

        features = feature_lookups
        del feature_lookups

        features = format_feature_lookups_and_functions(self._spark_client, features)

        return self._training_set_client.create_training_set_from_feature_lookups(
            df=df,
            feature_lookups=features,
            label=label,
            exclude_columns=exclude_columns,
            **kwargs
        )

    def log_model(
            self,
            model: Any,
            artifact_path: str,
            *,
            flavor: ModuleType,
            training_set: Optional[TrainingSet] = None,
            registered_model_name: Optional[str] = None,
            model_registry_uri: Optional[str] = None,
            await_registration_for: int = mlflow.tracking._model_registry.DEFAULT_AWAIT_MAX_SLEEP_SECONDS,
            infer_input_example: bool = False,
            **kwargs,
    ):
        """
         记录MLflow模型并关联特征查找信息

         注意：必须使用TrainingSet.load_df返回的DataFrame训练模型，
         任何对DataFrame的修改(如标准化、添加列等)都不会在推理时应用

         Args:
             model: 要记录的模型对象
             artifact_path: 模型存储路径
             flavor: MLflow模型类型模块(如mlflow.sklearn)
             training_set: 训练模型使用的TrainingSet对象(可选)
             registered_model_name: 要注册的模型名称(可选)
             model_registry_uri: 模型注册中心地址(可选)
             await_registration_for: 等待模型注册完成的秒数(默认300秒)
             infer_input_example: 是否自动记录输入示例(默认False)

         Returns:
             None
         """

        self._training_set_client.log_model(
            model=model,
            artifact_path=artifact_path,
            flavor=flavor,
            training_set=training_set,
            registered_model_name=registered_model_name,
            model_registry_uri=model_registry_uri,
            await_registration_for=await_registration_for,
            infer_input_example=infer_input_example,
            **kwargs
        )

    def score_batch(
            self, model_uri: str, df: DataFrame, result_type: str = "double", timestamp_key: str = None
    ) -> DataFrame:
        """
        Evaluate the model on the provided :class:`DataFrame <pyspark.sql.DataFrame>`.

        Additional features required for
        model evaluation will be automatically retrieved from :mod:`Feature Store <databricks.feature_store.client>`.

        .. todo::

           [ML-15539]: Replace the bitly URL in doc string

        The model must have been logged with :meth:`.FeatureStoreClient.log_model`,
        which packages the model with feature metadata. Unless present in ``df``,
        these features will be looked up from :mod:`Feature Store <databricks.feature_store.client>` and joined with ``df``
        prior to scoring the model.

        If a feature is included in ``df``, the provided feature values will be used rather
        than those stored in :mod:`Feature Store <databricks.feature_store.client>`.

        For example, if a model is trained on two features ``account_creation_date`` and
        ``num_lifetime_purchases``, as in:

        .. code-block:: python

            feature_lookups = [
                FeatureLookup(
                    table_name = 'trust_and_safety.customer_features',
                    feature_name = 'account_creation_date',
                    lookup_key = 'customer_id',
                ),
                FeatureLookup(
                    table_name = 'trust_and_safety.customer_features',
                    feature_name = 'num_lifetime_purchases',
                    lookup_key = 'customer_id'
                ),
            ]

            with mlflow.start_run():
                training_set = fs.create_training_set(
                    df,
                    feature_lookups = feature_lookups,
                    label = 'is_banned',
                    exclude_columns = ['customer_id']
                )
                ...
                  fs.log_model(
                    model,
                    "model",
                    flavor=mlflow.sklearn,
                    training_set=training_set,
                    registered_model_name="example_model"
                  )

        Then at inference time, the caller of :meth:`FeatureStoreClient.score_batch` must pass
        a :class:`DataFrame <pyspark.sql.DataFrame>` that includes ``customer_id``, the ``lookup_key`` specified in the
        ``FeatureLookups`` of the :mod:`training_set <databricks.feature_engineering.training_set>`.
        If the :class:`DataFrame <pyspark.sql.DataFrame>` contains a column
        ``account_creation_date``, the values of this column will be used
        in lieu of those in :mod:`Feature Store <databricks.feature_store.client>`. As in:

        .. code-block:: python

            # batch_df has columns ['customer_id', 'account_creation_date']
            predictions = fs.score_batch(
                'models:/example_model/1',
                batch_df
            )

        :param model_uri: The location, in URI format, of the MLflow model logged using
          :meth:`FeatureStoreClient.log_model`. One of:

            * ``runs:/<mlflow_run_id>/run-relative/path/to/model``

            * ``models:/<model_name>/<model_version>``

            * ``models:/<model_name>/<stage>``

          For more information about URI schemes, see
          `Referencing Artifacts <https://bit.ly/3wnrseE>`_.
        :param df: The :class:`DataFrame <pyspark.sql.DataFrame>` to score the model on. :mod:`Feature Store <databricks.feature_store.client>` features will be joined with
          ``df`` prior to scoring the model. ``df`` must:

              1. Contain columns for lookup keys required to join feature data from Feature
              Store, as specified in the ``feature_spec.yaml`` artifact.

              2. Contain columns for all source keys required to score the model, as specified in
              the ``feature_spec.yaml`` artifact.

              3. Not contain a column ``prediction``, which is reserved for the model's predictions.
              ``df`` may contain additional columns.

          Streaming DataFrames are not supported.

        :param result_type: The return type of the model.
           See :func:`mlflow.pyfunc.spark_udf` result_type.
        :return: A :class:`DataFrame <pyspark.sql.DataFrame>`
           containing:

            1. All columns of ``df``.

            2. All feature values retrieved from Feature Store.

            3. A column ``prediction`` containing the output of the model.

        """
        return self._training_set_client.score_batch(
            model_uri=model_uri,
            df=df,
            result_type=result_type,
            client_name=FEATURE_STORE_CLIENT,
            timestamp_key=timestamp_key,
        )

    def set_feature_table_tag(self, name: str, database_name: Optional[str] = None,
                              key: str = "", value: str = "",
                              catalog_name: Optional[str] = None):
        """
        设置特征表标签
        Args:
            name: 特征表名称。支持 `table`、`schema.table`、`catalog.schema.table`
            database_name: 数据库名称（可选，多段式名称时可从 name 中解析）
            key: 标签键
            value: 标签值
            catalog_name: catalog名称（可选）。如果不提供，将使用当前Spark会话的catalog
        Returns:
            None
        """
        name, database_name, catalog_name = self._parse_table_name(
            name, database_name, catalog_name
        )
        self._feature_table_client.alter_table_tag(
            name=name,
            database_name=database_name,
            catalog_name=catalog_name,
            properties={key: value},
            mode="add",
        )

    def delete_feature_table_tag(self, name: str, database_name: Optional[str] = None,
                                 key: str = "",
                                 catalog_name: Optional[str] = None):
        """
        删除特征表标签
        Args:
            name: 特征表名称。支持 `table`、`schema.table`、`catalog.schema.table`
            database_name: 数据库名称（可选，多段式名称时可从 name 中解析）
            key: 标签键
            catalog_name: catalog名称（可选）。如果不提供，将使用当前Spark会话的catalog
        Returns:
            None
        """
        name, database_name, catalog_name = self._parse_table_name(
            name, database_name, catalog_name
        )
        self._feature_table_client.alter_table_tag(
            name=name,
            database_name=database_name,
            catalog_name=catalog_name,
            properties={key: ""},
            mode="delete"
        )

    def publish_table(self, catalog_name: str, schema_name: str, table_name: str,
                      online_db_name: str, online_table_name: str,
                      trigger: Optional[SchedulerConfiguration] = None):
        """
        将离线特征表发布为在线特征表
        Args:
            catalog_name: 源数据目录名称
            schema_name: 源数据库名称
            table_name: 源表名称
            online_db_name: 在线数据库名称
            online_table_name: 在线表名称
            trigger: [可选]周期性任务的调度配置
        """
        self._feature_table_client.publish_table(
            catalog_name=catalog_name,
            schema_name=schema_name,
            table_name=table_name,
            online_db_name=online_db_name,
            online_table_name=online_table_name,
            trigger=trigger
        )

    def drop_online_table(self, catalog_name: str, schema_name: str, table_name: str):
        """
        删除在线特征表
        Args:
            catalog_name: 数据目录名称
            schema_name: 数据库名称
            table_name: 表名
        """
        self._feature_table_client.drop_online_table(
            catalog_name=catalog_name,
            schema_name=schema_name,
            table_name=table_name
        )

    def create_feature_spec(
        self, name: str,
        features: List[Union[FeatureLookup, FeatureFunction]],
        exclude_columns: Optional[List[str]]
    ) -> FeatureSpec:

        """
        创建特征配置文件
        :arg name: 特征配置文件名称
        :arg features: 特征列表，可以是FeatureLookup(特征查找)或FeatureFunction(特征函数)
        :arg exclude_columns: 需要从最终特征集中排除的列名列表
        """
        return self._training_set_client.create_feature_spec(name, features, self._spark_client, exclude_columns)

    @property
    def spark(self):
        return self._spark
