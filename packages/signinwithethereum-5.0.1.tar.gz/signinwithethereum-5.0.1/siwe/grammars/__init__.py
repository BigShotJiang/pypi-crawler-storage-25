"""ABNF definitions."""
