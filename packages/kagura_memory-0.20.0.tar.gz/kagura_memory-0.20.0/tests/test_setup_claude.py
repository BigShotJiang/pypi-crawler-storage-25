"""Tests for kagura setup claude command."""

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import click
import pytest
from click.testing import CliRunner

from kagura_memory.cli import main
from kagura_memory.setup_claude import (
    KAGURA_HOOK_MARKER,
    _auto_match_context,
    _check_gitignore,
    _install_hooks,
    _install_skills,
    _prompt_api_key,
    _prompt_mcp_url,
    _select_or_create_context,
    _write_kagura_config,
    _write_mcp_json,
)


@pytest.fixture()
def project_dir(tmp_path: Path) -> Path:
    """Create a temporary project directory."""
    return tmp_path


@pytest.fixture()
def runner() -> CliRunner:
    return CliRunner()


def _has_kagura_hook(entries: list[dict]) -> bool:
    """Check if any hook entry contains a Kagura-managed hook."""
    return any(
        KAGURA_HOOK_MARKER in h.get("command", "")
        for entry in entries
        for h in entry.get("hooks", [])
    )


# =============================================================================
# Prompt Unit Tests
# =============================================================================


class TestPromptApiKey:
    def test_interactive_with_existing(self) -> None:
        """Interactive mode with existing key should show masked info."""
        with patch("kagura_memory.setup_claude.click") as mock_click:
            mock_click.prompt.return_value = "kagura_new_key"
            mock_click.ClickException = click.ClickException
            mock_click.UsageError = click.UsageError
            result = _prompt_api_key("kagura_12345678abcdef", non_interactive=False)
            assert result == "kagura_new_key"
            mock_click.echo.assert_called_once()
            echo_arg = mock_click.echo.call_args[0][0]
            assert "kagura_1...cdef" in echo_arg

    def test_interactive_without_existing(self) -> None:
        """Interactive mode without existing key should prompt with empty default."""
        with patch("kagura_memory.setup_claude.click") as mock_click:
            mock_click.prompt.return_value = "kagura_entered"
            mock_click.ClickException = click.ClickException
            mock_click.UsageError = click.UsageError
            result = _prompt_api_key(None, non_interactive=False)
            assert result == "kagura_entered"


class TestPromptMcpUrl:
    def test_interactive(self) -> None:
        """Interactive mode should prompt."""
        with patch("kagura_memory.setup_claude.click") as mock_click:
            mock_click.prompt.return_value = "http://custom:8080/mcp"
            mock_click.UsageError = click.UsageError
            result = _prompt_mcp_url(None, non_interactive=False)
            assert result == "http://custom:8080/mcp"


class TestSelectOrCreateContext:
    @patch("kagura_memory.setup_claude._create_context")
    def test_interactive_select_existing(self, mock_create: AsyncMock) -> None:
        """Interactive: user selects an existing context (manual list path)."""
        with patch("kagura_memory.setup_claude.click") as mock_click:
            mock_click.prompt.return_value = 1
            mock_click.echo = MagicMock()
            result = _select_or_create_context(
                {"contexts": [{"id": "ctx-abc", "name": "my-proj"}]},
                "key",
                "url",
                None,
                Path("/tmp/test"),
                non_interactive=False,
                no_auto_context=True,
            )
            assert result == "ctx-abc"

    @patch("kagura_memory.setup_claude.asyncio")
    @patch("kagura_memory.setup_claude._create_context")
    def test_interactive_create_new(self, mock_create: AsyncMock, mock_asyncio: MagicMock) -> None:
        """Interactive: no contexts, user creates a new one."""
        mock_asyncio.run.return_value = {"context_id": "ctx-new", "name": "test"}
        with patch("kagura_memory.setup_claude.click") as mock_click:
            mock_click.prompt.side_effect = ["my-project", "A summary"]
            mock_click.echo = MagicMock()
            result = _select_or_create_context(
                {"contexts": []},
                "key",
                "url",
                None,
                Path("/tmp/test"),
                non_interactive=False,
                no_auto_context=True,
            )
            assert result == "ctx-new"

    @patch("kagura_memory.setup_claude.asyncio")
    @patch("kagura_memory.setup_claude._create_context")
    def test_interactive_create_new_from_list(
        self, mock_create: AsyncMock, mock_asyncio: MagicMock
    ) -> None:
        """Interactive: contexts exist, user chooses 'create new'."""
        mock_asyncio.run.return_value = {"context_id": "ctx-brand-new", "name": "new-proj"}
        with patch("kagura_memory.setup_claude.click") as mock_click:
            mock_click.prompt.side_effect = [2, "new-proj", ""]
            mock_click.echo = MagicMock()
            mock_click.IntRange = click.IntRange
            result = _select_or_create_context(
                {"contexts": [{"id": "ctx-1", "name": "existing"}]},
                "key",
                "url",
                None,
                Path("/tmp/test"),
                non_interactive=False,
                no_auto_context=True,
            )
            assert result == "ctx-brand-new"

    def test_auto_match_confirm_true_returns_matched_id(self) -> None:
        """Interactive: auto-match suggests a context, user confirms → matched id is returned."""
        with patch("kagura_memory.setup_claude.click") as mock_click:
            mock_click.confirm.return_value = True
            mock_click.echo = MagicMock()
            # Dir name 'kagura-memory' exactly matches context name → ratio == 1.0
            result = _select_or_create_context(
                {"contexts": [{"id": "ctx-match", "name": "kagura-memory"}]},
                "key",
                "url",
                None,
                Path("/tmp/kagura-memory"),
                non_interactive=False,
            )
            assert result == "ctx-match"
            mock_click.confirm.assert_called_once()

    def test_auto_match_confirm_false_falls_through_to_manual(self) -> None:
        """Interactive: auto-match suggests, user declines → manual list prompt is shown."""
        with patch("kagura_memory.setup_claude.click") as mock_click:
            mock_click.confirm.return_value = False
            mock_click.prompt.return_value = 1  # pick first item from manual list
            mock_click.echo = MagicMock()
            mock_click.IntRange = click.IntRange
            result = _select_or_create_context(
                {"contexts": [{"id": "ctx-match", "name": "kagura-memory"}]},
                "key",
                "url",
                None,
                Path("/tmp/kagura-memory"),
                non_interactive=False,
            )
            # Same id, but via the manual prompt path — verify confirm was asked and prompt followed
            assert result == "ctx-match"
            mock_click.confirm.assert_called_once()
            mock_click.prompt.assert_called_once()

    def test_no_auto_context_skips_auto_match(self) -> None:
        """Interactive: no_auto_context=True bypasses _auto_match_context entirely."""
        with (
            patch("kagura_memory.setup_claude.click") as mock_click,
            patch("kagura_memory.setup_claude._auto_match_context") as mock_auto_match,
        ):
            mock_click.prompt.return_value = 1
            mock_click.echo = MagicMock()
            mock_click.IntRange = click.IntRange
            result = _select_or_create_context(
                {"contexts": [{"id": "ctx-match", "name": "kagura-memory"}]},
                "key",
                "url",
                None,
                Path("/tmp/kagura-memory"),
                non_interactive=False,
                no_auto_context=True,
            )
            assert result == "ctx-match"
            mock_auto_match.assert_not_called()
            mock_click.confirm.assert_not_called()


# =============================================================================
# File Writer Unit Tests
# =============================================================================


class TestWriteKaguraConfig:
    def test_creates_new(self, project_dir: Path) -> None:
        path = _write_kagura_config(project_dir, "kagura_key", "http://localhost:8080/mcp", "ctx-1")
        data = json.loads(path.read_text())
        assert data["api_key"] == "kagura_key"
        assert data["mcp_url"] == "http://localhost:8080/mcp"
        assert data["context_id"] == "ctx-1"

    def test_merges_existing(self, project_dir: Path) -> None:
        existing = {"api_key": "old", "model": "gpt-5.4-nano", "llm_api_key": "sk-xxx"}
        (project_dir / ".kagura.json").write_text(json.dumps(existing))

        _write_kagura_config(project_dir, "new_key", "http://new/mcp", "ctx-2")
        data = json.loads((project_dir / ".kagura.json").read_text())
        assert data["api_key"] == "new_key"
        assert data["model"] == "gpt-5.4-nano"  # preserved
        assert data["llm_api_key"] == "sk-xxx"  # preserved


class TestWriteMcpJson:
    def test_creates_new(self, project_dir: Path) -> None:
        path = _write_mcp_json(project_dir, "kagura_key", "http://localhost:8080/mcp")
        data = json.loads(path.read_text())
        server = data["mcpServers"]["kagura-memory"]
        assert server["type"] == "url"
        assert server["url"] == "http://localhost:8080/mcp"
        assert server["headers"]["Authorization"] == "Bearer kagura_key"

    def test_preserves_other_servers(self, project_dir: Path) -> None:
        existing = {"mcpServers": {"other-server": {"type": "stdio", "command": "npx other"}}}
        (project_dir / ".mcp.json").write_text(json.dumps(existing))

        _write_mcp_json(project_dir, "key", "http://mcp")
        data = json.loads((project_dir / ".mcp.json").read_text())
        assert "other-server" in data["mcpServers"]
        assert "kagura-memory" in data["mcpServers"]


class TestInstallHooks:
    def test_creates_new_settings(self, project_dir: Path) -> None:
        path = _install_hooks(project_dir, "ctx-1")
        data = json.loads(path.read_text())
        assert "SessionStart" in data["hooks"]
        assert "PostToolUse" in data["hooks"]
        session_cmd = data["hooks"]["SessionStart"][0]["hooks"][0]["command"]
        assert "ctx-1" in session_cmd

    def test_preserves_existing_hooks(self, project_dir: Path) -> None:
        claude_dir = project_dir / ".claude"
        claude_dir.mkdir()
        existing = {
            "permissions": {"allow": ["Bash(git *)"]},
            "hooks": {
                "PostToolUse": [
                    {
                        "matcher": "Write|Edit",
                        "hooks": [
                            {
                                "type": "command",
                                "command": 'uv run ruff format --quiet "$file_path"',
                            }
                        ],
                    }
                ]
            },
        }
        (claude_dir / "settings.json").write_text(json.dumps(existing))

        _install_hooks(project_dir, "ctx-1")
        data = json.loads((claude_dir / "settings.json").read_text())

        # Permissions preserved
        assert data["permissions"]["allow"] == ["Bash(git *)"]

        # Existing ruff hook preserved
        post_hooks = data["hooks"]["PostToolUse"]
        assert any(
            "ruff" in h.get("command", "") for entry in post_hooks for h in entry.get("hooks", [])
        )

        # Kagura hook added
        assert _has_kagura_hook(post_hooks)

    def test_idempotent(self, project_dir: Path) -> None:
        _install_hooks(project_dir, "ctx-1")
        _install_hooks(project_dir, "ctx-2")  # Run again with different context

        data = json.loads((project_dir / ".claude" / "settings.json").read_text())

        # Should have exactly 1 kagura hook per event, not duplicates
        for event in ["SessionStart", "PostToolUse"]:
            kagura_count = sum(
                1
                for entry in data["hooks"][event]
                for h in entry.get("hooks", [])
                if KAGURA_HOOK_MARKER in h.get("command", "")
            )
            assert kagura_count == 1, f"Expected 1 kagura hook for {event}, got {kagura_count}"

        # Both hooks should have updated to ctx-2
        session_cmd = data["hooks"]["SessionStart"][0]["hooks"][0]["command"]
        assert "ctx-2" in session_cmd

        post_cmds = [
            h.get("command", "")
            for entry in data["hooks"]["PostToolUse"]
            for h in entry.get("hooks", [])
            if KAGURA_HOOK_MARKER in h.get("command", "")
        ]
        assert post_cmds and "ctx-2" in post_cmds[0]

    def test_updates_matcher_on_existing_hook(self, project_dir: Path) -> None:
        """Updating an existing Kagura hook should also update the matcher."""
        claude_dir = project_dir / ".claude"
        claude_dir.mkdir()
        # Start with a kagura hook that has no matcher
        existing = {
            "hooks": {
                "PostToolUse": [
                    {"hooks": [{"type": "command", "command": "kagura remember -s test"}]}
                ]
            }
        }
        (claude_dir / "settings.json").write_text(json.dumps(existing))

        _install_hooks(project_dir, "ctx-1")
        data = json.loads((claude_dir / "settings.json").read_text())

        # The matcher should now be set
        post_entry = data["hooks"]["PostToolUse"][0]
        assert post_entry.get("matcher") == "Write|Edit"


class TestInstallSkills:
    def test_installs_skills(self, project_dir: Path) -> None:
        paths = _install_skills(project_dir, "ctx-1")
        assert len(paths) == 2
        for p in paths:
            assert p.exists()
            content = p.read_text()
            assert "ctx-1" in content

    def test_skill_filenames(self, project_dir: Path) -> None:
        _install_skills(project_dir, "ctx-1")
        assert (project_dir / ".claude" / "commands" / "kagura-recall.md").exists()
        assert (project_dir / ".claude" / "commands" / "kagura-remember.md").exists()


class TestCheckGitignore:
    def test_not_in_gitignore(self, project_dir: Path) -> None:
        (project_dir / ".gitignore").write_text("node_modules/\n")
        assert _check_gitignore(project_dir) == [".kagura.json", ".mcp.json"]

    def test_both_in_gitignore(self, project_dir: Path) -> None:
        (project_dir / ".gitignore").write_text(".kagura.json\n.mcp.json\n")
        assert _check_gitignore(project_dir) == []

    def test_partial_gitignore(self, project_dir: Path) -> None:
        (project_dir / ".gitignore").write_text(".kagura.json\n")
        assert _check_gitignore(project_dir) == [".mcp.json"]

    def test_no_gitignore(self, project_dir: Path) -> None:
        assert _check_gitignore(project_dir) == [".kagura.json", ".mcp.json"]


# =============================================================================
# CLI Integration Tests
# =============================================================================


def _setup_args(tmp_path: Path, **overrides: str) -> list[str]:
    """Build common setup claude CLI args."""
    args = [
        "setup",
        "claude",
        "--api-key",
        overrides.get("api_key", "kagura_test123"),
        "--mcp-url",
        overrides.get("mcp_url", "http://localhost:8080/mcp"),
        "--project-dir",
        str(tmp_path),
        "-y",
    ]
    if "context_id" in overrides:
        args.extend(["--context-id", overrides["context_id"]])
    return args


@patch("kagura_memory.setup_claude._create_context")
@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_non_interactive(
    mock_conn: AsyncMock,
    mock_create_ctx: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Non-interactive mode with all flags should succeed without prompts."""
    mock_conn.return_value = {"count": 0, "contexts": []}
    mock_create_ctx.return_value = {"context_id": "ctx-new-uuid", "name": "test-project"}

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code == 0, result.output
    assert "Setup complete!" in result.output

    assert (tmp_path / ".kagura.json").exists()
    assert (tmp_path / ".mcp.json").exists()
    assert (tmp_path / ".claude" / "settings.json").exists()
    assert (tmp_path / ".claude" / "commands" / "kagura-recall.md").exists()


@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_with_existing_context(
    mock_conn: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """With --context-id, should use existing context without prompts."""
    mock_conn.return_value = {
        "count": 1,
        "contexts": [{"id": "ctx-existing", "name": "my-project"}],
    }

    result = runner.invoke(main, _setup_args(tmp_path, context_id="ctx-existing"))

    assert result.exit_code == 0, result.output
    data = json.loads((tmp_path / ".kagura.json").read_text())
    assert data["context_id"] == "ctx-existing"


@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_connection_failure(
    mock_conn: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Connection failure should show helpful error and not write files."""
    from kagura_memory.exceptions import KaguraAuthError

    mock_conn.side_effect = KaguraAuthError("Invalid API key")

    result = runner.invoke(main, _setup_args(tmp_path, api_key="kagura_bad"))

    assert result.exit_code != 0
    assert "Authentication failed" in result.output
    assert not (tmp_path / ".kagura.json").exists()


def test_setup_claude_non_interactive_missing_key(
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Non-interactive without API key should fail."""
    result = runner.invoke(
        main,
        ["setup", "claude", "--project-dir", str(tmp_path), "-y"],
    )

    assert result.exit_code != 0
    assert "API key required" in result.output


@patch("kagura_memory.setup_claude._create_context")
@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_preserves_existing_mcp_servers(
    mock_conn: AsyncMock,
    mock_create_ctx: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Should preserve existing MCP servers in .mcp.json."""
    mock_conn.return_value = {"count": 0, "contexts": []}
    mock_create_ctx.return_value = {"context_id": "ctx-uuid", "name": "test"}

    existing_mcp = {"mcpServers": {"github": {"type": "stdio", "command": "npx github-mcp"}}}
    (tmp_path / ".mcp.json").write_text(json.dumps(existing_mcp))

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code == 0, result.output
    data = json.loads((tmp_path / ".mcp.json").read_text())
    assert "github" in data["mcpServers"]
    assert "kagura-memory" in data["mcpServers"]


@patch("kagura_memory.setup_claude._create_context")
@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_gitignore_warning(
    mock_conn: AsyncMock,
    mock_create_ctx: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Should warn about .gitignore when secret files not listed."""
    mock_conn.return_value = {"count": 0, "contexts": []}
    mock_create_ctx.return_value = {"context_id": "ctx-uuid", "name": "test"}

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code == 0
    assert ".kagura.json" in result.output
    assert ".mcp.json" in result.output


@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_connection_error(
    mock_conn: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """KaguraConnectionError should show server-not-running hint."""
    from kagura_memory.exceptions import KaguraConnectionError

    mock_conn.side_effect = KaguraConnectionError("ECONNREFUSED")

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code != 0
    assert "Cannot connect" in result.output
    assert "docker compose up" in result.output


@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_generic_connection_error(
    mock_conn: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Generic exception during connection should show error."""
    mock_conn.side_effect = RuntimeError("unexpected")

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code != 0
    assert "Connection failed" in result.output


@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_connection_failed_unmessaged_exception(
    mock_conn: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Unmessaged exception in _test_connection must surface the class name (#127)."""
    mock_conn.side_effect = RuntimeError()

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code != 0
    assert "Connection failed: RuntimeError" in result.output
    assert "Connection failed: \n" not in result.output
    assert "Connection failed:\n" not in result.output


@patch("kagura_memory.cli.run_setup_claude")
def test_setup_claude_setup_failed_unmessaged_exception(
    mock_run: MagicMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Unmessaged exception escaping run_setup_claude must surface the class name (#127)."""
    mock_run.side_effect = RuntimeError()

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code != 0
    assert "Setup failed: RuntimeError" in result.output
    assert "Setup failed: \n" not in result.output
    assert "Setup failed:\n" not in result.output


@patch("kagura_memory.cli.run_setup_claude")
def test_setup_claude_user_abort_propagates_as_aborted(
    mock_run: MagicMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """click.Abort (Ctrl+D) must yield Click's default 'Aborted!' UX, not 'Setup failed: Abort'."""
    mock_run.side_effect = click.Abort()

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code != 0
    assert "Setup failed" not in result.output
    assert "Aborted" in result.output


@patch("kagura_memory.setup_claude._create_context")
@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_config_load_error(
    mock_conn: AsyncMock,
    mock_create_ctx: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Should gracefully handle broken .kagura.json in project dir."""
    (tmp_path / ".kagura.json").write_text("{invalid json")
    mock_conn.return_value = {"count": 0, "contexts": []}
    mock_create_ctx.return_value = {"context_id": "ctx-uuid", "name": "test"}

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code == 0, result.output
    assert "Setup complete!" in result.output


@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_rejects_malicious_context_id(
    mock_conn: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Should reject context_id with shell-special characters."""
    mock_conn.return_value = {"count": 0, "contexts": []}

    result = runner.invoke(
        main,
        _setup_args(tmp_path, context_id="; rm -rf /"),
    )

    assert result.exit_code != 0
    assert "Invalid context_id" in result.output
    assert not (tmp_path / ".kagura.json").exists()


@patch("kagura_memory.setup_claude._test_connection")
def test_setup_claude_reuses_existing_context_id(
    mock_conn: AsyncMock,
    runner: CliRunner,
    tmp_path: Path,
) -> None:
    """Rerunning setup should reuse context_id from existing .kagura.json."""
    existing = {
        "api_key": "kagura_old",
        "mcp_url": "http://localhost:8080/mcp",
        "context_id": "ctx-from-config",
    }
    (tmp_path / ".kagura.json").write_text(json.dumps(existing))

    mock_conn.return_value = {
        "count": 1,
        "contexts": [{"id": "ctx-from-config", "name": "my-proj"}],
    }

    result = runner.invoke(main, _setup_args(tmp_path))

    assert result.exit_code == 0, result.output
    data = json.loads((tmp_path / ".kagura.json").read_text())
    assert data["context_id"] == "ctx-from-config"


# =============================================================================
# Auto-Match Context Tests
# =============================================================================


class TestAutoMatchContext:
    """Tests for _auto_match_context fuzzy matching logic."""

    def test_exact_match(self) -> None:
        """Exact directory-name match should return high score."""
        contexts = [{"id": "ctx-1", "name": "kagura-memory-python-sdk"}]
        result = _auto_match_context(contexts, Path("/tmp/kagura-memory-python-sdk"))
        assert result is not None
        assert result["id"] == "ctx-1"

    def test_exact_match_with_underscore_normalization(self) -> None:
        """Underscores should be normalized to dashes."""
        contexts = [{"id": "ctx-1", "name": "kagura_memory_python_sdk"}]
        result = _auto_match_context(contexts, Path("/tmp/kagura-memory-python-sdk"))
        assert result is not None
        assert result["id"] == "ctx-1"

    def test_substring_match_gets_bonus(self) -> None:
        """Substring containment should boost score to >= 0.85."""
        # Dir name is a substring of context name
        contexts = [{"id": "ctx-1", "name": "kagura-memory-python-sdk-dev"}]
        result = _auto_match_context(contexts, Path("/tmp/kagura-memory-python-sdk"))
        assert result is not None
        assert result["id"] == "ctx-1"

    def test_context_name_is_substring_of_dir(self) -> None:
        """Context name as substring of dir name should also get bonus."""
        contexts = [{"id": "ctx-1", "name": "ai-worker"}]
        result = _auto_match_context(contexts, Path("/tmp/kagura-ai-worker-dev"))
        assert result is not None
        assert result["id"] == "ctx-1"

    def test_no_match_below_threshold(self) -> None:
        """No match should return None."""
        contexts = [{"id": "ctx-1", "name": "completely-unrelated-project"}]
        result = _auto_match_context(contexts, Path("/tmp/kagura-memory-python-sdk"))
        assert result is None

    def test_empty_context_list(self) -> None:
        """Empty context list should return None."""
        result = _auto_match_context([], Path("/tmp/kagura-memory-python-sdk"))
        assert result is None

    def test_context_with_empty_name(self) -> None:
        """Context with empty name should be skipped."""
        contexts = [{"id": "ctx-1", "name": ""}, {"id": "ctx-2", "name": "kagura-memory"}]
        result = _auto_match_context(contexts, Path("/tmp/kagura-memory"))
        assert result is not None
        assert result["id"] == "ctx-2"

    def test_multiple_candidates_picks_best(self) -> None:
        """Should pick the best match among multiple candidates."""
        contexts = [
            {"id": "ctx-1", "name": "other-project"},
            {"id": "ctx-2", "name": "kagura-memory-python-sdk"},
            {"id": "ctx-3", "name": "kagura-something-else"},
        ]
        result = _auto_match_context(contexts, Path("/tmp/kagura-memory-python-sdk"))
        assert result is not None
        assert result["id"] == "ctx-2"

    def test_tie_at_top_score_returns_none(self) -> None:
        """Ambiguous tie at top score should fall back to manual selection (None)."""
        # Both names are substrings of the dir name → both forced to 0.85 → tie.
        # Per issue #129 spec ("Reject ambiguous matches"), tie must return None.
        contexts = [
            {"id": "ctx-1", "name": "alpha"},
            {"id": "ctx-2", "name": "beta"},
        ]
        result = _auto_match_context(contexts, Path("/tmp/alpha-beta-mix"))
        assert result is None

    def test_exact_match_passes_default_threshold(self) -> None:
        """Exact name match should clear the default 0.65 threshold."""
        contexts = [{"id": "ctx-1", "name": "kagura-mem"}]
        result = _auto_match_context(contexts, Path("/tmp/kagura-mem"), threshold=0.65)
        assert result is not None

    def test_custom_threshold(self) -> None:
        """Higher threshold should reject marginal matches."""
        contexts = [{"id": "ctx-1", "name": "kagura-mem"}]
        # With very high threshold, even close matches fail
        result = _auto_match_context(contexts, Path("/tmp/kagura-memory"), threshold=0.95)
        assert result is None

    def test_empty_project_dir_name_returns_none(self) -> None:
        """An empty project_dir.name must not trigger the substring bonus for every candidate."""
        # Path("/") has .name == "". Without the guard, `"" in name` would be True
        # for every context, boosting every candidate to 0.85 and producing arbitrary matches.
        contexts = [
            {"id": "ctx-1", "name": "alpha"},
            {"id": "ctx-2", "name": "beta"},
        ]
        result = _auto_match_context(contexts, Path("/"))
        assert result is None
