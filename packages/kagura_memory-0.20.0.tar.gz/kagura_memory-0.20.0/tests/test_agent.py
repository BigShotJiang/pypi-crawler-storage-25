"""Tests for KaguraAgent enhanced context and caching."""

import json
import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from kagura_memory import KaguraAgent, KaguraAuthError
from kagura_memory.exceptions import KaguraLLMError
from kagura_memory.models import AnalysisResult, MemoryToStore, Message, RecallQuery, Session


@pytest.mark.asyncio
async def test_agent_caching_tools():
    """Test that tool definitions are cached and reused."""
    agent = KaguraAgent(api_key="test-key", model="gpt-5.4-nano")

    # Mock tool definitions
    mock_tools = [
        {"name": "remember", "description": "Store info"},
        {"name": "recall", "description": "Search info"},
    ]

    with patch.object(
        agent.client, "get_tool_definitions", new_callable=AsyncMock
    ) as mock_get_tools:
        mock_get_tools.return_value = mock_tools

        # First call - should fetch
        tools1 = await agent._get_tools_with_cache()
        assert tools1 == mock_tools
        assert mock_get_tools.call_count == 1

        # Second call - should use cache
        tools2 = await agent._get_tools_with_cache()
        assert tools2 == mock_tools
        assert mock_get_tools.call_count == 1  # Not called again

        # Verify cache entry exists with timestamp
        assert "tools" in agent._cache
        cached_data, cached_timestamp = agent._cache["tools"]
        assert cached_data == mock_tools
        assert cached_timestamp > 0

        # Verify deepcopy: modifying returned data doesn't corrupt cache
        tools2.append({"name": "mutated"})
        tools3 = await agent._get_tools_with_cache()
        assert len(tools3) == 2  # Cache still has original 2 items

    await agent.close()


@pytest.mark.asyncio
async def test_agent_cache_expiration():
    """Test that cache expires after TTL."""
    agent = KaguraAgent(api_key="test-key", model="gpt-5.4-nano")
    agent._cache_ttl = 0.1  # 100ms TTL for testing

    mock_tools = [{"name": "remember", "description": "Store info"}]

    with patch.object(
        agent.client, "get_tool_definitions", new_callable=AsyncMock
    ) as mock_get_tools:
        mock_get_tools.return_value = mock_tools

        # First call
        await agent._get_tools_with_cache()
        assert mock_get_tools.call_count == 1

        # Verify cache entry exists
        assert "tools" in agent._cache

        # Wait for cache to expire
        time.sleep(0.15)

        # Second call - should fetch again (cache expired)
        await agent._get_tools_with_cache()
        assert mock_get_tools.call_count == 2

    await agent.close()


@pytest.mark.asyncio
async def test_build_enhanced_context():
    """Test building enhanced context with tools and contexts."""
    agent = KaguraAgent(api_key="test-key", model="gpt-5.4-nano")

    mock_tools = [{"name": "remember"}]
    mock_contexts = [{"id": "ctx-1", "name": "test"}]

    with (
        patch.object(
            agent.client, "get_tool_definitions", new_callable=AsyncMock
        ) as mock_get_tools,
        patch.object(agent.client, "list_contexts", new_callable=AsyncMock) as mock_list_contexts,
    ):
        mock_get_tools.return_value = mock_tools
        mock_list_contexts.return_value = {"contexts": mock_contexts}

        # Build enhanced context
        enhanced_ctx = await agent._build_enhanced_context()

        assert enhanced_ctx["tools"] == mock_tools
        assert enhanced_ctx["contexts"] == mock_contexts

    await agent.close()


@pytest.mark.asyncio
async def test_null_contexts_handled():
    """_get_contexts_with_cache should handle null contexts from server."""
    agent = KaguraAgent(api_key="test-key", model="gpt-5.4-nano")

    with patch.object(agent.client, "list_contexts", new_callable=AsyncMock) as mock:
        mock.return_value = {"contexts": None}

        contexts = await agent._get_contexts_with_cache()
        assert contexts == []

    await agent.close()


@pytest.mark.asyncio
async def test_analyze_session_with_enhanced_context():
    """Test that _analyze_session uses enhanced context by default."""
    agent = KaguraAgent(api_key="test-key", model="gpt-5.4-nano", context_id="ctx-1")

    session = Session(messages=[Message(role="user", content="Test message")])

    mock_tools = [{"name": "remember"}]
    mock_contexts = [{"id": "ctx-1", "name": "test"}]

    with (
        patch.object(
            agent.client, "get_tool_definitions", new_callable=AsyncMock
        ) as mock_get_tools,
        patch.object(agent.client, "list_contexts", new_callable=AsyncMock) as mock_list_contexts,
        patch.object(agent, "_call_llm", new_callable=AsyncMock) as mock_llm,
    ):
        mock_get_tools.return_value = mock_tools
        mock_list_contexts.return_value = {"contexts": mock_contexts}
        mock_llm.return_value = (
            {"should_remember": False, "should_recall": False},
            MagicMock(),
        )

        # Analyze with enhanced context (default)
        await agent._analyze_session(session, use_enhanced_context=True)

        # Verify enhanced context was built
        assert mock_get_tools.called
        assert mock_list_contexts.called

        # Verify LLM was called with enhanced prompt
        assert mock_llm.called
        call_args = mock_llm.call_args
        user_content = call_args[0][0][1]["content"]
        assert "<available_tools>" in user_content

    await agent.close()


@pytest.mark.asyncio
async def test_independent_cache_timestamps():
    """Test that tools and contexts have independent cache timestamps (bug fix)."""
    agent = KaguraAgent(api_key="test-key", model="gpt-5.4-nano")

    mock_tools = [{"name": "remember"}]
    mock_contexts = [{"id": "ctx-1", "name": "test"}]

    with (
        patch.object(
            agent.client, "get_tool_definitions", new_callable=AsyncMock
        ) as mock_get_tools,
        patch.object(agent.client, "list_contexts", new_callable=AsyncMock) as mock_list_contexts,
    ):
        mock_get_tools.return_value = mock_tools
        mock_list_contexts.return_value = {"contexts": mock_contexts}

        # Fetch tools at t=0
        await agent._get_tools_with_cache()
        tools_entry_1 = agent._cache["tools"]
        tools_timestamp_1 = tools_entry_1[1]

        # Wait a bit
        time.sleep(0.05)

        # Fetch contexts at t=50ms
        await agent._get_contexts_with_cache()
        contexts_entry = agent._cache["contexts"]
        contexts_timestamp = contexts_entry[1]

        # Fetch tools again (should use cache)
        await agent._get_tools_with_cache()
        tools_entry_2 = agent._cache["tools"]
        tools_timestamp_2 = tools_entry_2[1]

        # CRITICAL: tools timestamp should NOT be affected by contexts fetch
        assert tools_timestamp_1 == tools_timestamp_2, (
            "Tools cache timestamp should not change when contexts are fetched"
        )
        assert contexts_timestamp > tools_timestamp_1, (
            "Contexts should have newer timestamp than tools"
        )

        # Verify each cache entry has its own data
        assert agent._cache["tools"][0] == mock_tools
        assert agent._cache["contexts"][0] == mock_contexts

    await agent.close()


# ============================================================================
# _call_llm tests
# ============================================================================


@pytest.mark.asyncio
async def test_call_llm_success():
    """_call_llm should parse JSON from LLM response."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = json.dumps({"should_remember": True})

    with patch("kagura_memory.agent.litellm") as mock_litellm:
        mock_litellm.acompletion = AsyncMock(return_value=mock_response)
        data, resp = await agent._call_llm([{"role": "user", "content": "test"}])

    assert data["should_remember"] is True
    assert resp == mock_response
    await agent.close()


@pytest.mark.asyncio
async def test_call_llm_auth_error():
    """_call_llm should raise KaguraAuthError on auth failure (no retry)."""
    import litellm

    agent = KaguraAgent(api_key="test", model="gpt-test")

    with patch("kagura_memory.agent.litellm.acompletion", new_callable=AsyncMock) as mock:
        mock.side_effect = litellm.AuthenticationError(
            message="bad key", llm_provider="openai", model="gpt-test"
        )

        with pytest.raises(KaguraAuthError, match="authentication failed"):
            await agent._call_llm([{"role": "user", "content": "test"}])

        assert mock.call_count == 1  # no retry on auth error

    await agent.close()


@pytest.mark.asyncio
async def test_call_llm_json_decode_error():
    """_call_llm should raise KaguraLLMError on invalid JSON."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = "not json {"

    with patch("kagura_memory.agent.litellm.acompletion", new_callable=AsyncMock) as mock:
        mock.return_value = mock_response

        with pytest.raises(KaguraLLMError, match="Invalid JSON"):
            await agent._call_llm([{"role": "user", "content": "test"}])

    await agent.close()


@pytest.mark.asyncio
async def test_call_llm_unexpected_error_retries():
    """_call_llm should retry on unexpected errors and raise after max retries."""
    agent = KaguraAgent(api_key="test", model="gpt-test", max_retries=2)

    with patch("kagura_memory.agent.litellm.acompletion", new_callable=AsyncMock) as mock:
        mock.side_effect = RuntimeError("unexpected")

        with patch("kagura_memory.agent.asyncio.sleep", new_callable=AsyncMock):
            with pytest.raises(KaguraLLMError, match="Unexpected LLM error"):
                await agent._call_llm([{"role": "user", "content": "test"}])

        assert mock.call_count == 2  # retried once before failing

    await agent.close()


@pytest.mark.asyncio
async def test_call_llm_rate_limit_retries():
    """_call_llm should retry on rate limit errors with backoff."""
    import litellm

    agent = KaguraAgent(api_key="test", model="gpt-test", max_retries=3)

    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = '{"ok": true}'

    with patch("kagura_memory.agent.litellm.acompletion", new_callable=AsyncMock) as mock:
        mock.side_effect = [
            litellm.RateLimitError(
                message="rate limited",
                llm_provider="openai",
                model="gpt-test",
            ),
            mock_response,
        ]

        with patch("kagura_memory.agent.asyncio.sleep", new_callable=AsyncMock):
            data, _ = await agent._call_llm([{"role": "user", "content": "test"}])

        assert data["ok"] is True
        assert mock.call_count == 2

    await agent.close()


@pytest.mark.asyncio
async def test_call_litellm_api_error():
    """_call_litellm should raise KaguraLLMError on APIError."""
    import litellm

    agent = KaguraAgent(api_key="test", model="gpt-test")

    with patch("kagura_memory.agent.litellm.acompletion", new_callable=AsyncMock) as mock:
        mock.side_effect = litellm.APIError(
            message="server error",
            llm_provider="openai",
            model="gpt-test",
            status_code=500,
        )

        with pytest.raises(KaguraLLMError, match="LLM API error"):
            await agent._call_llm([{"role": "user", "content": "test"}])

    await agent.close()


@pytest.mark.asyncio
async def test_call_litellm_passes_api_key():
    """_call_litellm should pass llm_api_key explicitly."""
    agent = KaguraAgent(api_key="test", model="gpt-test", llm_api_key="sk-123")

    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = '{"ok": true}'

    with patch("kagura_memory.agent.litellm.acompletion", new_callable=AsyncMock) as mock:
        mock.return_value = mock_response
        await agent._call_llm([{"role": "user", "content": "test"}])

        call_kwargs = mock.call_args[1]
        assert call_kwargs["api_key"] == "sk-123"

    await agent.close()


@pytest.mark.asyncio
async def test_ollama_model_detection(monkeypatch):
    """Agent should detect ollama/ prefix and set _is_ollama flag."""
    # KaguraAgent.__init__ now reads OLLAMA_HOST as a fallback for
    # ollama_base_url, so dev/CI machines with that env var set would
    # break the default-URL assertion below. Clear it for this test.
    monkeypatch.delenv("OLLAMA_HOST", raising=False)
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")
    assert agent._is_ollama is True
    assert agent._ollama_base_url == "http://localhost:11434"
    await agent.close()

    agent2 = KaguraAgent(api_key="test", model="gpt-5.4-nano")
    assert agent2._is_ollama is False
    await agent2.close()


@pytest.mark.asyncio
async def test_ollama_base_url_configurable():
    """Agent should accept custom ollama_base_url."""
    agent = KaguraAgent(
        api_key="test",
        model="ollama/qwen3:30b",
        ollama_base_url="http://gpu-server:11434",
    )
    assert agent._ollama_base_url == "http://gpu-server:11434"
    await agent.close()


@pytest.mark.asyncio
async def test_ollama_base_url_strips_trailing_slash():
    """Agent should strip trailing slash from ollama_base_url."""
    agent = KaguraAgent(
        api_key="test",
        model="ollama/qwen3:30b",
        ollama_base_url="http://localhost:11434/",
    )
    assert agent._ollama_base_url == "http://localhost:11434"
    await agent.close()


@pytest.mark.asyncio
async def test_call_ollama_success():
    """_call_ollama should parse JSON from Ollama API response."""
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")

    ollama_response = {
        "message": {
            "role": "assistant",
            "content": '{"should_remember": true}',
            "thinking": "Let me analyze this...",
        },
        "prompt_eval_count": 100,
        "eval_count": 50,
    }

    mock_client = AsyncMock()
    mock_resp = MagicMock()
    mock_resp.json.return_value = ollama_response
    mock_resp.raise_for_status = MagicMock()
    mock_client.post.return_value = mock_resp
    agent._ollama_client = mock_client

    data, resp = await agent._call_llm([{"role": "user", "content": "test"}])

    assert data["should_remember"] is True
    assert resp == ollama_response
    await agent.close()


@pytest.mark.asyncio
async def test_ollama_usage_extraction():
    """_extract_usage should handle Ollama response dict format."""
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")

    ollama_resp = {
        "prompt_eval_count": 200,
        "eval_count": 80,
    }
    usage = agent._extract_usage(ollama_resp)

    assert usage is not None
    assert usage.prompt_tokens == 200
    assert usage.completion_tokens == 80
    assert usage.total_tokens == 280
    assert usage.model == "ollama/qwen3:30b"
    await agent.close()


@pytest.mark.asyncio
async def test_ollama_usage_returns_none_when_missing():
    """_extract_usage should return None when Ollama omits token counts."""
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")
    assert agent._extract_usage({}) is None
    assert agent._extract_usage({"prompt_eval_count": 0}) is None
    await agent.close()


@pytest.mark.asyncio
async def test_call_ollama_429_raises_rate_limit():
    """_call_ollama should raise KaguraRateLimitError on HTTP 429."""
    import httpx

    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")

    mock_client = AsyncMock()
    mock_response = MagicMock()
    mock_response.status_code = 429
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "429", request=MagicMock(), response=mock_response
    )
    mock_client.post.return_value = mock_response
    agent._ollama_client = mock_client

    from kagura_memory.exceptions import KaguraRateLimitError

    with pytest.raises(KaguraRateLimitError, match="rate limit"):
        await agent._call_ollama([{"role": "user", "content": "test"}], 0.3)

    await agent.close()


@pytest.mark.asyncio
async def test_call_ollama_connection_error():
    """_call_ollama should raise KaguraLLMError on connection failure."""
    import httpx

    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")

    mock_client = AsyncMock()
    mock_client.post.side_effect = httpx.ConnectError("Connection refused")
    agent._ollama_client = mock_client

    with pytest.raises(KaguraLLMError, match="Ollama connection failed"):
        await agent._call_llm([{"role": "user", "content": "test"}])

    await agent.close()


# =============================================================================
# Ollama Cloud auth tests (issue #124)
# =============================================================================


def _build_ollama_mock_client() -> AsyncMock:
    """Helper: build an AsyncMock client returning a benign Ollama-shaped response."""
    mock_client = AsyncMock()
    mock_resp = MagicMock()
    mock_resp.json.return_value = {
        "message": {"role": "assistant", "content": '{"should_remember": false}'},
        "prompt_eval_count": 10,
        "eval_count": 5,
    }
    mock_resp.raise_for_status = MagicMock()
    mock_client.post.return_value = mock_resp
    return mock_client


@pytest.mark.asyncio
async def test_call_ollama_sends_bearer_header_when_api_key_kwarg(monkeypatch):
    """Explicit ollama_api_key kwarg should produce Authorization: Bearer header."""
    monkeypatch.delenv("OLLAMA_API_KEY", raising=False)
    monkeypatch.delenv("OLLAMA_HOST", raising=False)
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b", ollama_api_key="cloud-key-kwarg")
    mock_client = _build_ollama_mock_client()
    agent._ollama_client = mock_client

    await agent._call_ollama([{"role": "user", "content": "test"}], 0.3)

    headers = mock_client.post.call_args.kwargs["headers"]
    assert headers == {"Authorization": "Bearer cloud-key-kwarg"}
    await agent.close()


@pytest.mark.asyncio
async def test_call_ollama_sends_bearer_header_from_env(monkeypatch):
    """OLLAMA_API_KEY env var should be picked up when no kwarg is provided."""
    monkeypatch.setenv("OLLAMA_API_KEY", "cloud-key-env")
    monkeypatch.delenv("OLLAMA_HOST", raising=False)
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")
    mock_client = _build_ollama_mock_client()
    agent._ollama_client = mock_client

    await agent._call_ollama([{"role": "user", "content": "test"}], 0.3)

    headers = mock_client.post.call_args.kwargs["headers"]
    assert headers == {"Authorization": "Bearer cloud-key-env"}
    await agent.close()


@pytest.mark.asyncio
async def test_call_ollama_no_auth_header_when_no_key(monkeypatch):
    """Local Ollama path (no kwarg, no env) sends no Authorization header."""
    monkeypatch.delenv("OLLAMA_API_KEY", raising=False)
    monkeypatch.delenv("OLLAMA_HOST", raising=False)
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")
    mock_client = _build_ollama_mock_client()
    agent._ollama_client = mock_client

    await agent._call_ollama([{"role": "user", "content": "test"}], 0.3)

    # When no key is available, headers=None is passed (httpx treats it as no extra headers).
    assert mock_client.post.call_args.kwargs["headers"] is None
    await agent.close()


@pytest.mark.asyncio
async def test_call_ollama_kwarg_overrides_env(monkeypatch):
    """Explicit ollama_api_key kwarg must win over OLLAMA_API_KEY env var."""
    monkeypatch.setenv("OLLAMA_API_KEY", "env-key-should-lose")
    monkeypatch.delenv("OLLAMA_HOST", raising=False)
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b", ollama_api_key="kwarg-key-wins")
    mock_client = _build_ollama_mock_client()
    agent._ollama_client = mock_client

    await agent._call_ollama([{"role": "user", "content": "test"}], 0.3)

    assert mock_client.post.call_args.kwargs["headers"]["Authorization"] == "Bearer kwarg-key-wins"
    await agent.close()


@pytest.mark.asyncio
@pytest.mark.parametrize("status_code", [401, 403])
async def test_call_ollama_auth_status_raises_auth_error(monkeypatch, status_code):
    """HTTP 401/403 from Ollama Cloud must raise KaguraAuthError (not generic LLMError)."""
    import httpx

    monkeypatch.setenv("OLLAMA_API_KEY", "rejected-key")
    monkeypatch.delenv("OLLAMA_HOST", raising=False)
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")
    mock_client = AsyncMock()
    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        f"{status_code} auth", request=MagicMock(), response=mock_response
    )
    mock_client.post.return_value = mock_response
    agent._ollama_client = mock_client

    try:
        with pytest.raises(KaguraAuthError, match="Ollama auth failed"):
            await agent._call_ollama([{"role": "user", "content": "test"}], 0.3)
    finally:
        await agent.close()


@pytest.mark.asyncio
async def test_ollama_base_url_falls_back_to_ollama_host_env(monkeypatch):
    """OLLAMA_HOST env should be used when ollama_base_url kwarg is unset."""
    monkeypatch.setenv("OLLAMA_HOST", "https://my-ollama.example.com")
    agent = KaguraAgent(api_key="test", model="ollama/qwen3:30b")
    assert agent._ollama_base_url == "https://my-ollama.example.com"
    await agent.close()


@pytest.mark.asyncio
async def test_ollama_base_url_kwarg_overrides_ollama_host_env(monkeypatch):
    """Explicit ollama_base_url kwarg must win over OLLAMA_HOST env."""
    monkeypatch.setenv("OLLAMA_HOST", "https://env-host.example.com")
    agent = KaguraAgent(
        api_key="test",
        model="ollama/qwen3:30b",
        ollama_base_url="https://kwarg-host.example.com",
    )
    assert agent._ollama_base_url == "https://kwarg-host.example.com"
    await agent.close()


def test_ollama_base_url_empty_string_raises_value_error(monkeypatch):
    """Explicit ollama_base_url='' must raise ValueError, not silently degrade
    to a relative '/api/chat' URL that surfaces as a cryptic connection error."""
    monkeypatch.delenv("OLLAMA_HOST", raising=False)
    with pytest.raises(ValueError, match="ollama_base_url must be a non-empty"):
        KaguraAgent(api_key="test", model="ollama/qwen3:30b", ollama_base_url="")


@pytest.mark.asyncio
async def test_execute_recalls_explore_auth_error():
    """_execute_recalls should propagate KaguraAuthError from explore."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    with (
        patch.object(agent.client, "recall", new_callable=AsyncMock) as mock_recall,
        patch.object(agent.client, "explore", new_callable=AsyncMock) as mock_explore,
    ):
        mock_recall.return_value = {"results": [{"memory_id": "m1", "summary": "s", "score": 0.9}]}
        mock_explore.side_effect = KaguraAuthError("bad key")

        with pytest.raises(KaguraAuthError):
            await agent._execute_recalls("ctx", [RecallQuery(query="test")], deep=True)

    await agent.close()


# ============================================================================
# _analyze_session tests
# ============================================================================


@pytest.mark.asyncio
async def test_analyze_basic_prompt_fallback():
    """_analyze_session should fall back to basic prompt on connection error."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    from kagura_memory.exceptions import KaguraConnectionError

    with (
        patch.object(agent, "_build_enhanced_context", new_callable=AsyncMock) as mock_ctx,
        patch.object(agent, "_call_llm", new_callable=AsyncMock) as mock_llm,
    ):
        mock_ctx.side_effect = KaguraConnectionError("server down")
        mock_llm.return_value = (
            {"should_remember": False, "should_recall": True, "recall_queries": []},
            MagicMock(),
        )

        result = await agent._analyze_session(
            Session(messages=[Message(role="user", content="test")])
        )

        assert result.should_recall is True
        assert mock_llm.called

    await agent.close()


# ============================================================================
# _execute_remembers tests
# ============================================================================


@pytest.mark.asyncio
async def test_execute_remembers_success():
    """_execute_remembers should call client.remember for each memory."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    with patch.object(agent.client, "remember", new_callable=AsyncMock) as mock_rem:
        mock_rem.return_value = {"memory_id": "mem-1"}

        memories = [MemoryToStore(summary="Test memory", content="Full content")]
        remembered, actions = await agent._execute_remembers("ctx", memories)

        assert len(remembered) == 1
        assert remembered[0].memory_id == "mem-1"
        assert len(actions) == 1

    await agent.close()


@pytest.mark.asyncio
async def test_execute_remembers_auth_error():
    """_execute_remembers should propagate KaguraAuthError."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    with patch.object(agent.client, "remember", new_callable=AsyncMock) as mock_rem:
        mock_rem.side_effect = KaguraAuthError("bad key")

        with pytest.raises(KaguraAuthError):
            await agent._execute_remembers(
                "ctx", [MemoryToStore(summary="test summary", content="c")]
            )

    await agent.close()


# ============================================================================
# _select_context tests
# ============================================================================


@pytest.mark.asyncio
async def test_select_context_single():
    """_select_context should return the only context immediately."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    with patch.object(agent.client, "list_contexts", new_callable=AsyncMock) as mock:
        mock.return_value = {"contexts": [{"id": "ctx-1", "name": "only"}]}

        result = await agent._select_context(
            Session(messages=[Message(role="user", content="test")])
        )

    assert result == "ctx-1"
    await agent.close()


# ============================================================================
# process tests
# ============================================================================


@pytest.mark.asyncio
async def test_process_full_flow():
    """process() should run analyze -> recall -> remember."""
    agent = KaguraAgent(api_key="test", model="gpt-test", context_id="ctx")

    with (
        patch.object(agent, "_analyze_session", new_callable=AsyncMock) as mock_analyze,
        patch.object(agent, "_execute_recalls", new_callable=AsyncMock) as mock_recalls,
        patch.object(agent, "_execute_remembers", new_callable=AsyncMock) as mock_remembers,
    ):
        mock_analyze.return_value = AnalysisResult(
            should_remember=True,
            memories_to_store=[MemoryToStore(summary="test summary", content="c")],
            should_recall=True,
            recall_queries=[RecallQuery(query="test")],
        )
        mock_recalls.return_value = ([], [], ["recall: test"])
        mock_remembers.return_value = ([], ["remember: s"])

        session = Session(messages=[Message(role="user", content="hello")])
        result = await agent.process(session)

        assert result.context_used == "ctx"
        assert mock_recalls.called
        assert mock_remembers.called

    await agent.close()


@pytest.mark.asyncio
async def test_process_llm_failure_graceful():
    """process() should return empty result on LLM failure."""
    agent = KaguraAgent(api_key="test", model="gpt-test", context_id="ctx")

    with patch.object(agent, "_analyze_session", new_callable=AsyncMock) as mock:
        mock.side_effect = KaguraLLMError("LLM down")

        session = Session(messages=[Message(role="user", content="hello")])
        result = await agent.process(session)

        assert result.context_used == "ctx"
        assert len(result.remembered) == 0
        assert "error" in result.actions[0]

    await agent.close()


@pytest.mark.asyncio
async def test_process_context_required():
    """process() should raise ValueError if no context provided."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    with pytest.raises(ValueError, match="context_id is required"):
        await agent.process(Session(messages=[Message(role="user", content="hi")]))

    await agent.close()


# ============================================================================
# Hooks API
# ============================================================================


@pytest.mark.asyncio
async def test_hook_registration_and_execution():
    """Hooks should be called during process()."""
    agent = KaguraAgent(api_key="test", model="gpt-test", context_id="ctx")
    called = []

    @agent.hook("before_process")
    async def on_before(session, context_id):
        called.append(("before", context_id))

    @agent.hook("after_process")
    async def on_after(session, result):
        called.append(("after", result.context_used))

    with (
        patch.object(agent, "_analyze_session", new_callable=AsyncMock) as mock_analyze,
        patch.object(agent, "_execute_recalls", new_callable=AsyncMock) as mock_recalls,
        patch.object(agent, "_execute_remembers", new_callable=AsyncMock) as mock_remembers,
    ):
        mock_analyze.return_value = AnalysisResult(should_remember=False, should_recall=False)
        mock_recalls.return_value = ([], [], [])
        mock_remembers.return_value = ([], [])

        await agent.process(Session(messages=[Message(role="user", content="hi")]))

    assert ("before", "ctx") in called
    assert ("after", "ctx") in called
    await agent.close()


@pytest.mark.asyncio
async def test_on_remember_hook():
    """on_remember hook should receive remembered memories."""
    agent = KaguraAgent(api_key="test", model="gpt-test", context_id="ctx")
    hook_data = {}

    @agent.hook("on_remember")
    async def capture(remembered):
        hook_data["remembered"] = remembered

    with (
        patch.object(agent, "_analyze_session", new_callable=AsyncMock) as mock_analyze,
        patch.object(agent.client, "remember", new_callable=AsyncMock) as mock_rem,
    ):
        mock_analyze.return_value = AnalysisResult(
            should_remember=True,
            memories_to_store=[MemoryToStore(summary="test hook mem", content="c")],
            should_recall=False,
        )
        mock_rem.return_value = {"memory_id": "hook-mem-1"}

        await agent.process(Session(messages=[Message(role="user", content="hi")]))

    assert len(hook_data["remembered"]) == 1
    assert hook_data["remembered"][0].memory_id == "hook-mem-1"
    await agent.close()


@pytest.mark.asyncio
async def test_on_recall_hook():
    """on_recall hook should receive recalled and explored memories."""
    agent = KaguraAgent(api_key="test", model="gpt-test", context_id="ctx")
    hook_data = {}

    @agent.hook("on_recall")
    async def capture(recalled, explored):
        hook_data["recalled"] = recalled
        hook_data["explored"] = explored

    with (
        patch.object(agent, "_analyze_session", new_callable=AsyncMock) as mock_analyze,
        patch.object(agent.client, "recall", new_callable=AsyncMock) as mock_recall,
    ):
        mock_analyze.return_value = AnalysisResult(
            should_remember=False,
            should_recall=True,
            recall_queries=[RecallQuery(query="test")],
        )
        mock_recall.return_value = {
            "results": [{"memory_id": "m1", "summary": "found", "score": 0.9}]
        }

        await agent.process(Session(messages=[Message(role="user", content="hi")]))

    assert len(hook_data["recalled"]) == 1
    await agent.close()


@pytest.mark.asyncio
async def test_hook_invalid_event():
    """Registering a hook for unknown event should raise ValueError."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    try:
        with pytest.raises(ValueError, match="Unknown hook event"):

            @agent.hook("bad_event")
            async def noop():
                pass
    finally:
        await agent.close()


@pytest.mark.asyncio
async def test_hook_failure_does_not_crash():
    """A failing hook should log warning but not crash process()."""
    agent = KaguraAgent(api_key="test", model="gpt-test", context_id="ctx")

    @agent.hook("before_process")
    async def broken_hook(**kwargs):
        raise RuntimeError("hook broke")

    with patch.object(agent, "_analyze_session", new_callable=AsyncMock) as mock:
        mock.return_value = AnalysisResult(should_remember=False, should_recall=False)

        result = await agent.process(Session(messages=[Message(role="user", content="hi")]))
        assert result.context_used == "ctx"

    await agent.close()


# ============================================================================
# Skills API
# ============================================================================


@pytest.mark.asyncio
async def test_skill_registration_and_execution():
    """Skills should be callable via run_skill()."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    @agent.skill("greet")
    async def greet(who: str) -> str:
        return f"Hello {who}"

    result = await agent.run_skill(skill_name="greet", who="World")
    assert result == "Hello World"
    await agent.close()


@pytest.mark.asyncio
async def test_list_skills():
    """list_skills() should return registered skill names."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    @agent.skill("beta")
    async def b():
        pass

    @agent.skill("alpha")
    async def a():
        pass

    assert agent.list_skills() == ["alpha", "beta"]
    await agent.close()


@pytest.mark.asyncio
async def test_run_skill_not_found():
    """run_skill() should raise KeyError for unknown skill."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    with pytest.raises(KeyError, match="not found"):
        await agent.run_skill(skill_name="nonexistent")

    await agent.close()


@pytest.mark.asyncio
async def test_skill_duplicate_name():
    """Registering duplicate skill name should raise ValueError."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    @agent.skill("dup")
    async def first():
        pass

    try:
        with pytest.raises(ValueError, match="already registered"):

            @agent.skill("dup")
            async def second():
                pass
    finally:
        await agent.close()


# ============================================================================
# Sync callable support
# ============================================================================


@pytest.mark.asyncio
async def test_sync_hook():
    """Sync callables should work as hooks."""
    agent = KaguraAgent(api_key="test", model="gpt-test", context_id="ctx")
    called = []

    @agent.hook("before_process")
    def sync_hook(session, context_id):
        called.append("sync_before")

    with patch.object(agent, "_analyze_session", new_callable=AsyncMock) as mock:
        mock.return_value = AnalysisResult(should_remember=False, should_recall=False)
        await agent.process(Session(messages=[Message(role="user", content="hi")]))

    assert "sync_before" in called
    await agent.close()


@pytest.mark.asyncio
async def test_sync_skill():
    """Sync callables should work as skills."""
    agent = KaguraAgent(api_key="test", model="gpt-test")

    @agent.skill("sync_greet")
    def greet(who: str) -> str:
        return f"Hello {who}"

    result = await agent.run_skill(skill_name="sync_greet", who="World")
    assert result == "Hello World"
    await agent.close()


# ============================================================================
# Prompt formatting
# ============================================================================


def test_format_tool_for_prompt_full():
    """_format_tool_for_prompt should include full description and required params."""
    from kagura_memory.prompts import _format_tool_for_prompt

    tool = {
        "name": "remember",
        "description": "Store important information.\nLine 2 detail.",
        "inputSchema": {
            "properties": {
                "summary": {"type": "string", "description": "Memory summary"},
                "content": {"type": "string", "description": "Full content"},
                "tags": {"type": "array", "description": "Tags"},
            },
            "required": ["summary", "content"],
        },
    }
    result = _format_tool_for_prompt(tool)
    assert "### remember" in result
    assert "Store important information." in result
    assert "Line 2 detail." in result  # full description, not truncated
    assert "summary (string): Memory summary" in result
    assert "content (string): Full content" in result


def test_format_tool_for_prompt_no_required():
    """_format_tool_for_prompt with no required params omits Required section."""
    from kagura_memory.prompts import _format_tool_for_prompt

    tool = {
        "name": "list_contexts",
        "description": "List contexts.",
        "inputSchema": {"properties": {}, "required": []},
    }
    result = _format_tool_for_prompt(tool)
    assert "### list_contexts" in result
    assert "Required:" not in result
