"""Ed25519 sign / verify for Chain-Receipt v1.0.0.

Uses the `cryptography` library (already in repo deps).
"""
from __future__ import annotations

import base64
from typing import Tuple

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization

from chain_receipt_core.hash import receipt_hash_bytes
from chain_receipt_core.schema import Receipt, Signature


def _b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def generate_keypair() -> Tuple[Ed25519PrivateKey, str]:
    """Return (private_key, base64url public key string)."""
    sk = Ed25519PrivateKey.generate()
    pub = sk.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return sk, _b64url(pub)


def sign_receipt(receipt: Receipt, private_key: Ed25519PrivateKey) -> Receipt:
    """Sign a Receipt in-place semantics; returns a new Receipt with signature filled."""
    # Public key bytes (for embedding into the Signature struct)
    pub_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    pub_b64 = _b64url(pub_bytes)

    # Pre-condition: client.emitter_pubkey MUST agree with the signing key
    expected = f"ed25519:{pub_b64}"
    if receipt.client.emitter_pubkey != expected:
        raise ValueError(
            f"client.emitter_pubkey ({receipt.client.emitter_pubkey!r}) "
            f"does not match signing key ({expected!r})"
        )

    # Compute receipt_hash bytes with signature := null
    cleared = receipt.model_copy(update={"signature": None})
    digest = receipt_hash_bytes(cleared)
    sig_bytes = private_key.sign(digest)

    return receipt.model_copy(
        update={
            "signature": Signature(
                algorithm="ed25519",
                public_key=pub_b64,
                signature=_b64url(sig_bytes),
            )
        }
    )


def verify_signature(receipt: Receipt) -> bool:
    """Return True iff the embedded Ed25519 signature is valid."""
    if receipt.signature is None:
        return False
    if receipt.signature.algorithm != "ed25519":
        return False

    pub_bytes = _b64url_decode(receipt.signature.public_key)
    sig_bytes = _b64url_decode(receipt.signature.signature)

    expected_emitter = f"ed25519:{receipt.signature.public_key}"
    if receipt.client.emitter_pubkey != expected_emitter:
        return False

    cleared = receipt.model_copy(update={"signature": None})
    digest = receipt_hash_bytes(cleared)

    try:
        Ed25519PublicKey.from_public_bytes(pub_bytes).verify(sig_bytes, digest)
        return True
    except InvalidSignature:
        return False


__all__ = [
    "generate_keypair",
    "sign_receipt",
    "verify_signature",
]
