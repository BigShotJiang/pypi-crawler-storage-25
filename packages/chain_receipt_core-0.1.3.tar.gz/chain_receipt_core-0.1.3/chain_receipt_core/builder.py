"""ReceiptBuilder — emit Receipts from interaction data.

Usage:

    builder = ReceiptBuilder(
        client=ClientInfo(name="...", version="...", platform="...",
                          emitter_pubkey="ed25519:..."),
        private_key=sk,                      # optional; if None, Receipts are unsigned
        verifier_url="https://chain-determinism.org",
        chain_seed=b"my-emitter-seed",       # initializes the chain root hash
    )
    r0 = builder.build(interaction=Interaction(...))
    r1 = builder.build(interaction=Interaction(...))
    assert r1.chain.prev_receipt_hash == receipt_hash(r0)
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import uuid
from typing import Any, Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from chain_receipt_core.hash import receipt_hash
from chain_receipt_core.schema import (
    RECEIPT_VERSION,
    Chain,
    ClientInfo,
    Interaction,
    Receipt,
    Stability,
)
from chain_receipt_core.sign import sign_receipt


def _now_rfc3339() -> str:
    """Current UTC time in RFC 3339 form ending in 'Z' (no fractional seconds)."""
    now = _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def _new_receipt_id() -> str:
    """Lowercase canonical hyphenated UUID (uuid4 — uuid7 not in stdlib).

    UUIDv7 is preferred per SCHEMA.md §1; we use uuid4 here because
    Python 3.12 lacks stdlib uuid7. A uuid7 implementation can be
    swapped in by callers that supply their own `receipt_id`.
    """
    return str(uuid.uuid4())


class ReceiptBuilder:
    """Stateful per-emitter Receipt emitter.

    Keeps track of the running chain so callers do not have to plumb
    `prev_receipt_hash` through their own state.
    """

    def __init__(
        self,
        *,
        client: ClientInfo,
        private_key: Optional[Ed25519PrivateKey] = None,
        verifier_url: Optional[str] = None,
        chain_seed: bytes = b"",
    ):
        self.client = client
        self.private_key = private_key
        self.verifier_url = verifier_url

        seed_hex = hashlib.sha256(chain_seed).hexdigest()
        self._chain_root = "sha256:" + seed_hex
        self._prev_hash: str = self._chain_root  # genesis: prev == root
        self._sequence = 0

    @property
    def chain_root_hash(self) -> str:
        return self._chain_root

    @property
    def next_sequence_number(self) -> int:
        return self._sequence

    def build(
        self,
        *,
        interaction: Interaction,
        stability: Optional[Stability] = None,
        optional_payload: Optional[dict[str, Any]] = None,
        receipt_id: Optional[str] = None,
        created_at: Optional[str] = None,
    ) -> Receipt:
        chain = Chain(
            prev_receipt_hash=self._prev_hash,
            chain_root_hash=self._chain_root,
            sequence_number=self._sequence,
        )
        r = Receipt(
            receipt_version=RECEIPT_VERSION,
            receipt_id=receipt_id or _new_receipt_id(),
            created_at=created_at or _now_rfc3339(),
            client=self.client,
            interaction=interaction,
            chain=chain,
            stability=stability,
            optional_payload=optional_payload,
            signature=None,
            verifier_url=self.verifier_url,
        )
        if self.private_key is not None:
            r = sign_receipt(r, self.private_key)

        # advance chain
        self._prev_hash = receipt_hash(r)
        self._sequence += 1
        return r


__all__ = ["ReceiptBuilder"]
