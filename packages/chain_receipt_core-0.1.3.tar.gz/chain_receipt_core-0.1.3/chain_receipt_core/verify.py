"""verify_receipt / verify_chain — validation entry points."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional

from chain_receipt_core.hash import receipt_hash
from chain_receipt_core.schema import RECEIPT_VERSION, Receipt
from chain_receipt_core.sign import verify_signature


@dataclass
class VerifyResult:
    ok: bool
    errors: List[str]

    def __bool__(self) -> bool:  # pragma: no cover - convenience
        return self.ok


def _check_hash_prefix(h: str, field: str, errs: list[str]) -> None:
    if not h.startswith("sha256:"):
        errs.append(f"{field}: unrecognized hash prefix (expected sha256:)")
    elif len(h) != len("sha256:") + 64:
        errs.append(f"{field}: malformed sha256 hash length")


def verify_receipt(
    receipt: Receipt,
    *,
    prev_receipt: Optional[Receipt] = None,
    require_signature: bool = True,
) -> VerifyResult:
    """Validate a single Receipt.

    If `prev_receipt` is supplied, also validates the chain link.
    `require_signature=True` (the default) means an unsigned Receipt
    fails verification.
    """
    errs: list[str] = []

    if receipt.receipt_version != RECEIPT_VERSION:
        errs.append(
            f"receipt_version: unknown ({receipt.receipt_version!r}, "
            f"this library implements {RECEIPT_VERSION!r})"
        )

    for fld, val in (
        ("interaction.system_prompt_hash", receipt.interaction.system_prompt_hash),
        ("interaction.prompt_hash",        receipt.interaction.prompt_hash),
        ("interaction.response_hash",      receipt.interaction.response_hash),
        ("interaction.tool_calls_hash",    receipt.interaction.tool_calls_hash),
        ("chain.prev_receipt_hash",        receipt.chain.prev_receipt_hash),
        ("chain.chain_root_hash",          receipt.chain.chain_root_hash),
    ):
        _check_hash_prefix(val, fld, errs)

    if receipt.chain.sequence_number == 0:
        if receipt.chain.prev_receipt_hash != receipt.chain.chain_root_hash:
            errs.append(
                "chain: sequence_number == 0 implies prev_receipt_hash == chain_root_hash"
            )

    if require_signature and receipt.signature is None:
        errs.append("signature: required but missing")
    elif receipt.signature is not None and not verify_signature(receipt):
        errs.append("signature: invalid")

    if prev_receipt is not None:
        if receipt.chain.prev_receipt_hash != receipt_hash(prev_receipt):
            errs.append("chain: prev_receipt_hash does not match hash(prev_receipt)")
        if receipt.chain.chain_root_hash != prev_receipt.chain.chain_root_hash:
            errs.append("chain: chain_root_hash diverges from prev_receipt")
        if receipt.chain.sequence_number != prev_receipt.chain.sequence_number + 1:
            errs.append("chain: sequence_number not strictly incremented")

    return VerifyResult(ok=not errs, errors=errs)


def verify_chain(receipts: Iterable[Receipt], *, require_signature: bool = True) -> VerifyResult:
    """Validate an ordered iterable of Receipts as a single chain."""
    errs: list[str] = []
    prev: Optional[Receipt] = None
    for i, r in enumerate(receipts):
        single = verify_receipt(r, prev_receipt=prev, require_signature=require_signature)
        if not single.ok:
            errs.extend(f"receipt[{i}]: {e}" for e in single.errors)
        prev = r
    return VerifyResult(ok=not errs, errors=errs)


__all__ = ["verify_receipt", "verify_chain", "VerifyResult"]
