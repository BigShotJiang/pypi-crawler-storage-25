"""Chain-Receipt — reference Python implementation of v1.0.0.

Public surface:

    from chain_receipt_core import (
        Receipt, Interaction, Chain, Stability, Signature, ClientInfo,
        canonical_json, receipt_hash,
        ReceiptBuilder, sign_receipt, verify_receipt, verify_chain,
        compute_tool_calls_hash, compute_text_hash,
    )

The schema is frozen at v1.0.0 (see ../SCHEMA.md).
"""
from chain_receipt_core.schema import (
    Receipt,
    Interaction,
    Chain,
    Stability,
    Signature,
    ClientInfo,
    RECEIPT_VERSION,
)
from chain_receipt_core.canonical import canonical_json
from chain_receipt_core.hash import (
    receipt_hash,
    compute_tool_calls_hash,
    compute_text_hash,
    sha256_hex,
)
from chain_receipt_core.sign import sign_receipt, generate_keypair
from chain_receipt_core.builder import ReceiptBuilder
from chain_receipt_core.verify import (
    verify_receipt,
    verify_chain,
    VerifyResult,
)

__version__ = "0.1.0"

__all__ = [
    "Receipt",
    "Interaction",
    "Chain",
    "Stability",
    "Signature",
    "ClientInfo",
    "RECEIPT_VERSION",
    "canonical_json",
    "receipt_hash",
    "compute_tool_calls_hash",
    "compute_text_hash",
    "sha256_hex",
    "sign_receipt",
    "generate_keypair",
    "ReceiptBuilder",
    "verify_receipt",
    "verify_chain",
    "VerifyResult",
    "__version__",
]
