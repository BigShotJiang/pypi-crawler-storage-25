"""Pydantic v2 models for Chain-Receipt v1.0.0.

Field order matches SCHEMA.md but is not load-bearing — canonical
serialization (canonical.py) sorts keys lexicographically.
"""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field

RECEIPT_VERSION = "1.0.0"


class ClientInfo(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)

    name: str
    version: str
    platform: str
    emitter_pubkey: str  # "ed25519:<base64url>"


class Interaction(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)

    vendor: str
    model: str
    temperature: float
    system_prompt_hash: str
    prompt_hash: str
    response_hash: str
    tool_calls_hash: str
    n_tool_calls: int = Field(ge=0)
    latency_ms: Optional[int] = None


class Chain(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)

    prev_receipt_hash: str
    chain_root_hash: str
    sequence_number: int = Field(ge=0)


class Stability(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)

    n_replays: int = Field(ge=0)
    divergence_rate: float = Field(ge=0.0, le=1.0)
    wilson_ci_lo: float = Field(ge=0.0, le=1.0)
    wilson_ci_hi: float = Field(ge=0.0, le=1.0)
    method: str
    computed_at: str  # RFC 3339 UTC


class Signature(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)

    algorithm: str  # MUST be "ed25519" in v1.0.0
    public_key: str  # base64url-encoded 32-byte raw key
    signature: str   # base64url-encoded 64-byte raw signature


class Receipt(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)

    receipt_version: str
    receipt_id: str  # UUIDv7 (or v4) lowercase canonical hyphenated form
    created_at: str  # RFC 3339 UTC, ends in 'Z'
    client: ClientInfo
    interaction: Interaction
    chain: Chain
    stability: Optional[Stability] = None
    optional_payload: Optional[dict[str, Any]] = None
    signature: Optional[Signature] = None
    verifier_url: Optional[str] = None
