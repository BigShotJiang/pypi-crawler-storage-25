# chain-receipt-core (Python)

Reference implementation of the **Chain-Receipt v1.0.0** spec
(`../SCHEMA.md`). Provides:

- Pydantic v2 models (`Receipt`, `Interaction`, `Chain`, `Stability`, `Signature`)
- RFC 8785–compatible canonical JSON
- SHA-256 hash helpers (`receipt_hash`, `compute_tool_calls_hash`, `compute_text_hash`)
- Ed25519 sign / verify
- `ReceiptBuilder` for emitter-side use
- `verify_receipt`, `verify_chain`

```python
from chain_receipt_core import (
    ClientInfo, Interaction, ReceiptBuilder, generate_keypair, verify_chain,
    compute_text_hash, compute_tool_calls_hash,
)

sk, pub_b64 = generate_keypair()
client = ClientInfo(
    name="chain-receipt-langchain-sdk",
    version="0.1.0",
    platform="python-3.12",
    emitter_pubkey=f"ed25519:{pub_b64}",
)
b = ReceiptBuilder(client=client, private_key=sk,
                   verifier_url="https://chain-determinism.org",
                   chain_seed=pub_b64.encode())

inter = Interaction(
    vendor="anthropic", model="claude-sonnet-4-5", temperature=0.0,
    system_prompt_hash=compute_text_hash("you are helpful"),
    prompt_hash=compute_text_hash("hello"),
    response_hash=compute_text_hash("hi"),
    tool_calls_hash=compute_tool_calls_hash([]),
    n_tool_calls=0, latency_ms=120,
)
r = b.build(interaction=inter)
assert verify_chain([r]).ok
```

Cross-language conformance vectors live in `../conformance/vectors/`.
