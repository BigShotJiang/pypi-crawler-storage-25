"""Canonical JSON byte-equality tests."""
from chain_receipt_core.canonical import canonical_json


def test_empty_object():
    assert canonical_json({}) == b"{}"


def test_empty_array():
    assert canonical_json([]) == b"[]"


def test_null():
    assert canonical_json(None) == b"null"


def test_bool():
    assert canonical_json(True) == b"true"
    assert canonical_json(False) == b"false"


def test_string_escaping_basic():
    assert canonical_json("hello") == b'"hello"'
    assert canonical_json('he said "hi"') == b'"he said \\"hi\\""'
    assert canonical_json("a\\b") == b'"a\\\\b"'
    assert canonical_json("a\nb") == b'"a\\nb"'


def test_string_escaping_unicode_bmp():
    # U+00E9 (é) must be é (lowercase hex)
    assert canonical_json("café") == b'"caf\\u00e9"'
    # U+4E2D (中)
    assert canonical_json("中") == b'"\\u4e2d"'


def test_string_escaping_supplementary_plane():
    # U+1F680 ROCKET — surrogate pair 🚀
    assert canonical_json("🚀") == b'"\\ud83d\\ude80"'


def test_nfc_normalization():
    # Composed (NFC) é vs decomposed (NFD) e + combining acute
    nfc = "é"
    nfd = "é"
    assert canonical_json(nfc) == canonical_json(nfd)


def test_object_keys_sorted():
    obj = {"b": 1, "a": 2, "c": 3}
    assert canonical_json(obj) == b'{"a":2,"b":1,"c":3}'


def test_object_keys_sorted_recursively():
    obj = {"b": {"y": 1, "x": 2}, "a": 1}
    assert canonical_json(obj) == b'{"a":1,"b":{"x":2,"y":1}}'


def test_no_whitespace():
    obj = {"a": [1, 2, {"b": 3}]}
    assert canonical_json(obj) == b'{"a":[1,2,{"b":3}]}'


def test_integer_vs_float():
    assert canonical_json(42) == b"42"
    assert canonical_json(-7) == b"-7"
    # integer-valued float emits as integer
    assert canonical_json(1.0) == b"1"
    assert canonical_json(0.0) == b"0"
    assert canonical_json(-0.0) == b"0"


def test_float_shortest_roundtrip():
    assert canonical_json(3.14) == b"3.14"
    assert canonical_json(0.1) == b"0.1"


def test_nan_inf_rejected():
    import math

    import pytest

    with pytest.raises(ValueError):
        canonical_json(float("nan"))
    with pytest.raises(ValueError):
        canonical_json(math.inf)


def test_unicode_key_sort_utf16_order():
    # Keys "ä" (U+00E4) vs "z" (U+007A): in UTF-16 code-unit order, "z" < "ä"
    # because 0x7A < 0xE4. Pure lex on Unicode codepoints would give the same
    # result here (BMP only). The test ensures we sort by code unit, not by
    # locale-aware collation.
    obj = {"ä": 1, "z": 2}
    out = canonical_json(obj)
    # "z" must appear first
    z_idx = out.index(b'"z"')
    a_idx = out.index(b'"\\u00e4"')
    assert z_idx < a_idx


def test_deterministic_repeated_serialization():
    obj = {"a": [1, 2, 3], "b": {"nested": True}}
    a = canonical_json(obj)
    b = canonical_json(obj)
    assert a == b
