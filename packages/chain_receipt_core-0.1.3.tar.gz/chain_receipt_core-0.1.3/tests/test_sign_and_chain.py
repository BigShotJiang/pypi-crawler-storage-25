"""Ed25519 signature + chain-link tests."""
import pytest

from chain_receipt_core import (
    ClientInfo,
    Interaction,
    ReceiptBuilder,
    compute_text_hash,
    compute_tool_calls_hash,
    generate_keypair,
    receipt_hash,
    verify_chain,
    verify_receipt,
)
from chain_receipt_core.sign import sign_receipt, verify_signature


def _emitter_client(pub_b64: str) -> ClientInfo:
    return ClientInfo(
        name="t", version="0.1", platform="test",
        emitter_pubkey=f"ed25519:{pub_b64}",
    )


def _inter(seed: int) -> Interaction:
    return Interaction(
        vendor="anthropic", model="claude-sonnet-4-5", temperature=0.0,
        system_prompt_hash=compute_text_hash(f"s{seed}"),
        prompt_hash=compute_text_hash(f"p{seed}"),
        response_hash=compute_text_hash(f"r{seed}"),
        tool_calls_hash=compute_tool_calls_hash([]),
        n_tool_calls=0, latency_ms=10,
    )


def test_sign_verify_roundtrip():
    sk, pub_b64 = generate_keypair()
    b = ReceiptBuilder(client=_emitter_client(pub_b64), private_key=sk,
                       chain_seed=pub_b64.encode())
    r = b.build(interaction=_inter(0))
    assert r.signature is not None
    assert verify_signature(r)
    assert verify_receipt(r).ok


def test_signature_fails_on_tamper():
    sk, pub_b64 = generate_keypair()
    b = ReceiptBuilder(client=_emitter_client(pub_b64), private_key=sk)
    r = b.build(interaction=_inter(0))
    tampered = r.model_copy(update={
        "interaction": r.interaction.model_copy(update={"temperature": 0.5}),
    })
    assert not verify_signature(tampered)


def test_emitter_pubkey_must_match_signing_key():
    sk, _ = generate_keypair()
    sk2, pub2 = generate_keypair()
    # client claims a different emitter pubkey than the signer
    bad_client = _emitter_client(pub2)
    b = ReceiptBuilder(client=bad_client, private_key=sk)  # mismatched
    with pytest.raises(ValueError):
        b.build(interaction=_inter(0))


def test_chain_link_integrity():
    sk, pub_b64 = generate_keypair()
    b = ReceiptBuilder(client=_emitter_client(pub_b64), private_key=sk,
                       chain_seed=pub_b64.encode())
    r0 = b.build(interaction=_inter(0))
    r1 = b.build(interaction=_inter(1))
    r2 = b.build(interaction=_inter(2))

    assert r0.chain.sequence_number == 0
    assert r0.chain.prev_receipt_hash == r0.chain.chain_root_hash  # genesis
    assert r1.chain.sequence_number == 1
    assert r1.chain.prev_receipt_hash == receipt_hash(r0)
    assert r2.chain.prev_receipt_hash == receipt_hash(r1)
    assert r0.chain.chain_root_hash == r1.chain.chain_root_hash == r2.chain.chain_root_hash

    res = verify_chain([r0, r1, r2])
    assert res.ok, res.errors


def test_chain_break_is_detected():
    sk, pub_b64 = generate_keypair()
    b = ReceiptBuilder(client=_emitter_client(pub_b64), private_key=sk,
                       chain_seed=pub_b64.encode())
    r0 = b.build(interaction=_inter(0))
    r1 = b.build(interaction=_inter(1))
    # Forge r1' that claims a wrong prev_receipt_hash
    bad_chain = r1.chain.model_copy(update={"prev_receipt_hash": "sha256:" + "f" * 64})
    forged = r1.model_copy(update={"chain": bad_chain})
    res = verify_chain([r0, forged], require_signature=False)
    assert not res.ok


def test_unsigned_receipt_is_valid_when_not_required():
    sk, pub_b64 = generate_keypair()
    b = ReceiptBuilder(client=_emitter_client(pub_b64), private_key=None,
                       chain_seed=pub_b64.encode())
    r = b.build(interaction=_inter(0))
    assert r.signature is None
    assert verify_receipt(r, require_signature=False).ok
    assert not verify_receipt(r, require_signature=True).ok
