"""Hash helpers + payload-strip stability tests."""
import hashlib

from chain_receipt_core import (
    Chain,
    ClientInfo,
    Interaction,
    Receipt,
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
)


def _client():
    return ClientInfo(
        name="t",
        version="0.1",
        platform="test",
        emitter_pubkey="ed25519:AAAA",
    )


def _inter():
    return Interaction(
        vendor="anthropic", model="claude-sonnet-4-5", temperature=0.0,
        system_prompt_hash=compute_text_hash("sys"),
        prompt_hash=compute_text_hash("p"),
        response_hash=compute_text_hash("r"),
        tool_calls_hash=compute_tool_calls_hash([]),
        n_tool_calls=0, latency_ms=10,
    )


def _chain():
    return Chain(
        prev_receipt_hash="sha256:" + "0" * 64,
        chain_root_hash="sha256:" + "0" * 64,
        sequence_number=0,
    )


def _receipt(**kw):
    base = dict(
        receipt_version="1.0.0",
        receipt_id="00000000-0000-0000-0000-000000000000",
        created_at="2026-04-26T00:00:00Z",
        client=_client(),
        interaction=_inter(),
        chain=_chain(),
        stability=None,
        optional_payload=None,
        signature=None,
        verifier_url=None,
    )
    base.update(kw)
    return Receipt(**base)


def test_text_hash_nfc_invariant():
    a = compute_text_hash("café")     # NFC
    b = compute_text_hash("café")     # NFD
    assert a == b


def test_text_hash_known_vector():
    # SHA-256("hello world") = b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9
    assert compute_text_hash("hello world").endswith(
        ":b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
    )


def test_tool_calls_hash_empty():
    h = compute_tool_calls_hash([])
    assert h == "sha256:" + hashlib.sha256(b"").hexdigest()


def test_tool_calls_hash_matches_paper4_format():
    # Mirror the reference implementation::_seq_full byte-for-byte
    seq = [
        {"name": "filter_beliefs", "args": {"term": "x"}, "bound_to": "v1"},
        {"name": "final_answer", "args": {"answer": "42"}},
    ]
    expected_inner = (
        'filter_beliefs:{"args": {"term": "x"}, "bound_to": "v1", "name": "filter_beliefs"}'
    )
    # NOTE: paper4 only serializes args (not full record). Our compute_tool_calls_hash
    # mirrors paper4 precisely: name + ":" + json.dumps(args, sort_keys=True).
    expected = (
        'filter_beliefs:{"term": "x"}'
        '||'
        'final_answer:{"answer": "42"}'
    )
    h = compute_tool_calls_hash(seq)
    assert h == "sha256:" + hashlib.sha256(expected.encode("utf-8")).hexdigest()
    # Sanity: ignore the misleading expected_inner above
    assert expected_inner != expected


def test_receipt_hash_excludes_signature():
    r1 = _receipt()
    r1_signed = r1.model_copy(update={
        "signature": {
            "algorithm": "ed25519",
            "public_key": "AAAA",
            "signature": "BBBB",
        }
    })
    # signature is excluded from the hash, so signed and unsigned hashes match
    assert receipt_hash(r1) == receipt_hash(r1_signed)


def test_receipt_hash_includes_optional_payload():
    r1 = _receipt(optional_payload=None)
    r2 = _receipt(optional_payload={"prompt": "hi"})
    assert receipt_hash(r1) != receipt_hash(r2)
    # Stripping the payload would let an attacker change Receipt identity;
    # we explicitly want the hash to differ.


def test_receipt_hash_deterministic_repeated():
    r = _receipt()
    a = receipt_hash(r)
    b = receipt_hash(r)
    assert a == b
