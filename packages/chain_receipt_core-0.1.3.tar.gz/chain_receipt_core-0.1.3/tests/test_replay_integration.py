"""Integration test: ReceiptBuilder vs the reference replay harness.

Picks 5 rows from a published cross-vendor replay JSONL (real per-run
records that the reference harness emitted), builds Receipts via
ReceiptBuilder, and asserts that compute_tool_calls_hash matches the
byte-for-byte serialization the harness uses internally (_seq_full).

Skips gracefully if the JSONL file is not present in this checkout.
"""
import hashlib
import json
from pathlib import Path

import pytest

from chain_receipt_core import (
    ClientInfo,
    Interaction,
    ReceiptBuilder,
    compute_text_hash,
    compute_tool_calls_hash,
    generate_keypair,
    receipt_hash,
    verify_chain,
)

JSONL = (
    Path(__file__).resolve().parents[3]
    / "results/benchmarks/replay/multivendor_anthropic.jsonl"
)


def _seq_full_python_harness(seq):
    """Reproduce the reference `_seq_full` algorithm byte-for-byte."""
    parts = []
    for s in seq:
        args = s.get("args") or {}
        parts.append(s.get("name") + ":" + json.dumps(args, sort_keys=True, default=str))
    return "||".join(parts)


@pytest.mark.skipif(not JSONL.exists(), reason="replay jsonl not in checkout")
def test_tool_calls_hash_matches_harness():
    rows: list[dict] = []
    with JSONL.open() as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
            if len(rows) >= 5:
                break

    assert len(rows) == 5, "expected 5 rows from jsonl"

    for row in rows:
        seq = row.get("tool_call_sequence", [])
        # 1. Our computed tool_calls_hash
        ours = compute_tool_calls_hash(seq)
        # 2. Harness-style hash recomputed locally
        harness_str = _seq_full_python_harness(seq)
        harness_hash = "sha256:" + hashlib.sha256(harness_str.encode("utf-8")).hexdigest()

        assert ours == harness_hash, (
            f"divergence on {row.get('query_id')}: "
            f"ours={ours} harness={harness_hash}\n"
            f"harness_str={harness_str!r}"
        )


@pytest.mark.skipif(not JSONL.exists(), reason="replay jsonl not in checkout")
def test_build_receipts_from_replay_rows():
    rows: list[dict] = []
    with JSONL.open() as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
            if len(rows) >= 5:
                break

    sk, pub_b64 = generate_keypair()
    client = ClientInfo(
        name="chain-receipt-replay-integration",
        version="0.1.0",
        platform="pytest",
        emitter_pubkey=f"ed25519:{pub_b64}",
    )
    builder = ReceiptBuilder(
        client=client,
        private_key=sk,
        verifier_url="https://chain-determinism.org",
        chain_seed=pub_b64.encode(),
    )

    receipts = []
    for row in rows:
        seq = row.get("tool_call_sequence", [])
        rationale = row.get("rationale", "")
        final_answer = row.get("final_answer_norm", "")
        latency_ms = int(row.get("latency_s", 0) * 1000)

        inter = Interaction(
            vendor="anthropic",
            model=row["model"],
            temperature=float(row.get("temperature", 0.0)),
            system_prompt_hash=compute_text_hash(""),
            prompt_hash=compute_text_hash(row.get("query_id", "")),
            response_hash=compute_text_hash(rationale + "\n" + final_answer),
            tool_calls_hash=compute_tool_calls_hash(seq),
            n_tool_calls=row.get("n_tool_calls", len(seq)),
            latency_ms=latency_ms,
        )
        receipts.append(builder.build(interaction=inter))

    # Chain links must hold
    res = verify_chain(receipts)
    assert res.ok, res.errors

    # Every Receipt's tool_calls_hash matches the harness output
    for r, row in zip(receipts, rows):
        seq = row.get("tool_call_sequence", [])
        harness_str = _seq_full_python_harness(seq)
        harness_hash = "sha256:" + hashlib.sha256(harness_str.encode("utf-8")).hexdigest()
        assert r.interaction.tool_calls_hash == harness_hash

    # Receipt hashes are stable
    for r in receipts:
        assert receipt_hash(r) == receipt_hash(r)
