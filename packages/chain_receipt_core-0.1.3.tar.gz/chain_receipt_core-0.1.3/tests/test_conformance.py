"""Conformance vectors — Python side.

Reads conformance/vectors/*.json and conformance/expected/*.json and
asserts that re-canonicalizing the Receipt produces the same byte
length and the same receipt_hash. The TypeScript test suite asserts
the same against the same files.
"""
import json
from pathlib import Path

import pytest

from chain_receipt_core import Receipt, canonical_json, receipt_hash

ROOT = Path(__file__).resolve().parents[2] / "conformance"
VECTORS = ROOT / "vectors"
EXPECTED = ROOT / "expected"


def _vector_pairs():
    if not VECTORS.exists() or not EXPECTED.exists():
        return []
    pairs = []
    for vp in sorted(VECTORS.glob("*.json")):
        ep = EXPECTED / vp.name
        if ep.exists():
            pairs.append((vp.stem, vp, ep))
    return pairs


_PAIRS = _vector_pairs()
if not _PAIRS:
    pytest.skip(
        "conformance vectors not generated — run conformance/generate_vectors.py",
        allow_module_level=True,
    )


@pytest.mark.parametrize("name,vp,ep", _PAIRS)
def test_vector_hash(name, vp, ep):
    receipt_dict = json.loads(vp.read_text(encoding="utf-8"))
    expected = json.loads(ep.read_text(encoding="utf-8"))

    # Round-trip through Pydantic to ensure the model accepts the vector
    r = Receipt(**receipt_dict)

    canon = canonical_json(r)
    assert len(canon) == expected["canonical_len"], (
        f"{name}: canonical_len mismatch: "
        f"got {len(canon)}, expected {expected['canonical_len']}"
    )

    rh = receipt_hash(r)
    assert rh == expected["receipt_hash"], (
        f"{name}: receipt_hash mismatch: got {rh}, expected {expected['receipt_hash']}"
    )
