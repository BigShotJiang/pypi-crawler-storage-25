"""GET /opportunities — list every active Opportunity in the local cache.
GET /opportunities/{id} — drill-down detail page.

Read-only mirror of governor-web's `/opportunities` UX, scoped to
audit's single (project, region). The list page vendors the cloud's
templates 1:1 (summary cards, filter controls, table, pagination) and
this route hydrates the data shape those templates expect:
``opportunities`` (per-row dict), ``signals`` (filter state), ``summary``
(aggregate stats), ``available_types``,
``pagination`` (with ``query_string_without_page`` /
``query_string_without_sort_or_page``), and ``local_runtime_mode=True``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Iterable
from urllib.parse import urlencode

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import desc

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.session import (
    build_engine,
    create_all,
    make_session_factory,
)
from governor_core.opportunities.catalog import get_detection_rule_catalog
from governor_core.opportunities.models import Opportunity
from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("governor_audit.web.opportunities")
router = APIRouter()

_PAGE_SIZE = 10
# Default sort flipped from "savings" to "cost" in v0.0.16. Audit no
# longer displays a savings column at all (the existing governor-core
# rules emit hardcoded-percentage savings figures we refuse to surface;
# audit's own rules persist 0; only a real dry-run could justify a
# number, and audit doesn't run dry-runs).
_DEFAULT_SORT = "cost"
_DEFAULT_DIRECTION = "desc"
_VALID_SORTS = (
    "project",
    "dataset",
    "table",
    "author",
    "type",
    "workload",
    "cost",
    "age",
    "state",
    "layout",
    "suggestions",
)


# ── Pagination wrapper — adds the query_string_without_* properties the
# cloud templates use to preserve filter state across page links ────────


@dataclass
class AuditPaginationContext:
    page: int
    page_size: int
    total_items: int
    base_query_pairs: list[tuple[str, str]] = field(default_factory=list)
    sort: str | None = None
    direction: str | None = None

    @property
    def total_pages(self) -> int:
        if self.total_items == 0:
            return 1
        return (self.total_items + self.page_size - 1) // self.page_size

    @property
    def has_prev(self) -> bool:
        return self.page > 1

    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages

    @property
    def start_index(self) -> int:
        if self.total_items == 0:
            return 0
        return (self.page - 1) * self.page_size + 1

    @property
    def end_index(self) -> int:
        return min(self.page * self.page_size, self.total_items)

    def page_range(self, window: int = 2) -> list[int]:
        start = max(1, self.page - window)
        end = min(self.total_pages, self.page + window)
        return list(range(start, end + 1))

    @property
    def query_string_without_page(self) -> str:
        pairs = list(self.base_query_pairs)
        if self.sort:
            pairs.append(("sort", self.sort))
        if self.direction:
            pairs.append(("direction", self.direction))
        return urlencode(pairs)

    @property
    def query_string_without_sort_or_page(self) -> str:
        return urlencode(self.base_query_pairs)


# ── Severity bucket helper ─────────────────────────────────────────────


def _severity_bucket(score: int) -> str:
    if score >= 80:
        return "critical"
    if score >= 50:
        return "high"
    if score >= 20:
        return "medium"
    return "low"


_BUCKET_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


# ── Workload classification ─────────────────────────────────────────────
# Reuse audit's existing manifest-free build/consumption classifier so the
# Workload column doesn't render every row as "Unclassified". The helper
# inspects the job's SQL + statement_type to decide build vs consumption.


def _workload_kind_from_job(job: BigQueryJob | None) -> str | None:
    if job is None:
        return None
    if job.workload_kind:
        return job.workload_kind
    # Fall back to live classification when the column wasn't populated
    # at scan time (rows from earlier audit versions).
    from governor_audit.web.routes.findings import _classify_workload

    kind = _classify_workload(job.query, job.statement_type)
    # Map "other" → None so the template's local_runtime_mode branch
    # renders "Unclassified" only when classification really failed.
    return kind if kind in ("build", "consumption") else None


# ── Per-row view dict — matches the cloud template's expected shape ─────


def _split_table_identifier(table: str | None) -> tuple[str, str]:
    """Return ``(dataset, object)`` from a BigQuery table identifier."""
    if not table:
        return "—", "—"
    parts = [p for p in table.split(".") if p]
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return "—", parts[0]


def _to_row(
    opp: Opportunity,
    *,
    project_name: str,
    job: BigQueryJob | None,
) -> dict[str, Any]:
    from governor_audit.scan.categorization import (
        ISSUE_RULE_TYPES,
    )

    severity = int(opp.severity_score or 0)
    affected_dataset, affected_object = _split_table_identifier(opp.affected_table)
    # Improvements were attached at scan time under
    # ``evidence_snapshot["_improvements"]`` (deduped by rule_type
    # downstream of detection.py). Surface a count + a "has-template"
    # count so the table can show "N suggestions, K with diffs".
    improvements = (opp.evidence_snapshot or {}).get("_improvements") or []
    improvements_with_diff = sum(
        1 for imp in improvements if imp.get("template_id")
    )
    # ``is_issue`` distinguishes the five real cost / performance issue
    # rules (slot_contention, join_explosion, partition_pruning,
    # shuffle_spill, storage_billing_optimization) from the SQL-rewrite
    # suggestion rules. Improvement-only opportunities have no issue to
    # show in the listing's "Issue" column and present their own
    # template_result as a single suggestion card on the detail page.
    is_issue = opp.opportunity_type in ISSUE_RULE_TYPES
    template_result = (opp.evidence_snapshot or {}).get("_template_result") or None
    has_self_template = bool(
        template_result
        and template_result.get("before_content")
        and template_result.get("after_content")
        and template_result.get("before_content") != template_result.get("after_content")
    )
    return {
        "id": opp.id,
        "config_id": opp.config_id,
        "project_name": project_name,
        "affected_table": opp.affected_table,
        "affected_dataset": affected_dataset,
        "affected_object": opp.dbt_model_name or affected_object,
        "dbt_model_name": opp.dbt_model_name,
        "opportunity_type": opp.opportunity_type,
        "is_issue": is_issue,
        "has_self_template": has_self_template,
        "query_workload_kind": _workload_kind_from_job(job),
        "query_cost_value": float(opp.current_cost_estimate or 0),
        # Author = ``user_email`` of the first cached related job —
        # who actually ran the query that produced the row. Surfaces
        # in the listing's Author column + filter and on the detail
        # page header. ``None`` when no cached job remains for this
        # opportunity (rare: cache wipe + scan replace edge cases).
        "author_email": (job.user_email if job is not None else None),
        "improvements_count": len(improvements),
        "improvements_with_diff_count": improvements_with_diff,
        # Audit refuses to surface a savings number — see _DEFAULT_SORT
        # comment above. The cloud rules in governor-core emit
        # hardcoded-percentage figures (slot_contention = 20 %,
        # join_explosion etc.) we don't trust enough to display, and
        # audit has no dry-run pipeline that could justify a real
        # number. Always None → table cell renders "—".
        "possible_savings_value": None,
        "occurrence_count": len(list(opp.related_job_ids or [])) or 1,
        "last_detected_at": opp.updated_at,
        "created_at": opp.created_at,
        "severity_score": severity,
        "severity_bucket": _severity_bucket(severity),
        "evidence_snapshot": opp.evidence_snapshot or {},
        "explanation": opp.explanation or "",
        "related_job_ids": list(opp.related_job_ids or []),
        # Cloud-only fields the audit templates reference but never set:
        "solution_job_status": None,
        "solution_risk_level": None,
        "recommendation_state": None,
        "optimized_cost_value": None,
        "optimized_delta_direction": None,
        "possible_savings_source_label": "detection heuristic",
    }


# ── Summary aggregator ─────────────────────────────────────────────────


def _summary_from_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Build the aggregate stats the summary cards consume. All
    savings-related fields are zeroed — the cards rendering them have
    been removed from the local-mode template (audit always uses local
    mode), but we keep the keys here so a stale partial doesn't crash."""
    total_cost = sum(r["query_cost_value"] or 0 for r in rows)

    def _kind_total(field: str, kind: str) -> float:
        return sum((r[field] or 0) for r in rows if r["query_workload_kind"] == kind)

    def _other_total(field: str) -> float:
        return sum(
            (r[field] or 0)
            for r in rows
            if r["query_workload_kind"] not in ("build", "consumption")
        )

    return {
        "active_count": len(rows),
        "with_solutions_count": 0,
        "clearing_count": 0,
        "verified_count": 0,
        "collecting_count": 0,
        "total_query_cost": total_cost,
        "build_query_cost": _kind_total("query_cost_value", "build"),
        "consumption_query_cost": _kind_total("query_cost_value", "consumption"),
        "other_query_cost": _other_total("query_cost_value"),
        # All savings keys — kept for template-shape compatibility, all 0.
        "total_savings": 0,
        "total_possible_savings": 0,
        "build_possible_savings": 0,
        "consumption_possible_savings": 0,
        "other_possible_savings": 0,
        "verified_post_merge_savings": 0,
        "clearing_savings": 0,
    }


# ── Per-table aggregation ──────────────────────────────────────────────


def _aggregate_rows_by_table(
    per_opp_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Collapse a list of one-row-per-Opportunity dicts into one row
    per ``affected_table``. Each table's representative row carries
    summary counts (``table_issue_count``, ``table_suggestion_count``,
    ``table_issue_types``) so the listing template can render
    aggregated cells without reaching back into the underlying opps.

    The representative is picked by priority: issue rows outrank
    suggestion-only rows; within a tier, higher ``query_cost_value``
    wins. The representative's metadata (author, workload, opportunity
    detail link) becomes the row's. Aggregate counts always reflect
    the full set of opps for that table regardless of which one
    became representative.
    """

    by_table: dict[str, dict[str, Any]] = {}
    issue_types_by_table: dict[str, list[str]] = {}

    def _priority(r: dict[str, Any]) -> tuple[int, float]:
        is_issue_rank = 1 if r.get("is_issue") else 0
        cost = float(r.get("query_cost_value") or 0)
        return (is_issue_rank, cost)

    for r in per_opp_rows:
        key = r.get("affected_table") or ""
        if not key:
            # No destination table → fall back to per-opp display so we
            # don't merge unrelated rows under a "" key.
            by_table[r["id"]] = {
                **r,
                "table_issue_count": 1 if r.get("is_issue") else 0,
                "table_suggestion_count": 0 if r.get("is_issue") else 1,
                "table_issue_types": [r["opportunity_type"]] if r.get("is_issue") else [],
            }
            continue

        if key not in by_table:
            by_table[key] = {**r}
            issue_types_by_table[key] = []

        rep = by_table[key]
        if _priority(r) > _priority(rep):
            # New row outranks current rep — adopt its metadata.
            by_table[key] = {**r}

        if r.get("is_issue"):
            t = r["opportunity_type"]
            if t not in issue_types_by_table[key]:
                issue_types_by_table[key].append(t)

    # Second pass: count opps per table and attach the aggregates.
    issue_count_by_table: dict[str, int] = {}
    suggestion_count_by_table: dict[str, int] = {}
    for r in per_opp_rows:
        key = r.get("affected_table") or ""
        if not key:
            continue
        if r.get("is_issue"):
            issue_count_by_table[key] = issue_count_by_table.get(key, 0) + 1
        else:
            suggestion_count_by_table[key] = suggestion_count_by_table.get(key, 0) + 1

    aggregated: list[dict[str, Any]] = []
    for key, rep in by_table.items():
        if not rep.get("affected_table"):
            aggregated.append(rep)
            continue
        rep["table_issue_count"] = issue_count_by_table.get(key, 0)
        rep["table_suggestion_count"] = suggestion_count_by_table.get(key, 0)
        rep["table_issue_types"] = issue_types_by_table.get(key, [])
        aggregated.append(rep)
    return aggregated


# ── Filtering ──────────────────────────────────────────────────────────


def _apply_filters(
    rows: list[dict[str, Any]],
    *,
    search: str,
    projects: str,
    types: str,
    dataset: str = "",
    workload: str = "",
    suggestions: str = "",
    author: str = "",
    layout: str = "",
) -> list[dict[str, Any]]:
    """Filter the workspace's row set.

    Audit-specific simplifications vs the cloud's filter set:
    - No ``status`` — audit is read-only; every row is ``active``.
      The cloud uses status to track "PR open / merged / clearing"
      lifecycle that doesn't exist here.
    - No ``smart_view`` — severity buckets aren't well-calibrated in
      audit and there's no resolved state, so Quick Wins / Chronic /
      Unaddressed don't add signal.
    - Workload and Suggestions are binary (Build/Consumption,
      With/Without) — no Unclassified or None states. Audit's data
      classifies every job into build or consumption deterministically
      (anything that writes is build, everything else is consumption);
      a row with no Suggestions is just one we don't show as a
      separate bucket.
    """
    out = rows
    if search:
        needle = search.lower()
        out = [
            r
            for r in out
            if needle in (r["affected_table"] or "").lower()
            or needle in (r["affected_dataset"] or "").lower()
            or needle in (r["affected_object"] or "").lower()
            or needle in (r["dbt_model_name"] or "").lower()
            or needle in r["opportunity_type"].lower()
        ]
    if projects:
        out = [r for r in out if r["config_id"] == projects]
    if types:
        # Match if the requested issue type appears in this table's
        # aggregated issue list. ``table_issue_types`` is populated by
        # ``_aggregate_rows_by_table``; the per-opp ``opportunity_type``
        # only reflects the representative row, which would miss
        # tables where the requested issue exists but a higher-cost
        # rule became the representative.
        out = [
            r for r in out
            if types in (r.get("table_issue_types") or [])
            or r.get("opportunity_type") == types
        ]
    if dataset:
        out = [r for r in out if (r["affected_dataset"] or "") == dataset]
    if author:
        out = [r for r in out if (r.get("author_email") or "") == author]
    if workload in ("build", "consumption"):
        out = [r for r in out if r["query_workload_kind"] == workload]
    if suggestions:
        # Use table-level aggregate counts — a table "has suggestions"
        # if any of its opportunities is suggestion-typed.
        if suggestions == "with":
            out = [r for r in out if (r.get("table_suggestion_count") or 0) > 0]
        elif suggestions == "without":
            out = [r for r in out if (r.get("table_suggestion_count") or 0) == 0]
    if layout:
        # Spec 148 — yes/no on whether a partition / cluster
        # recommendation card would render on the row's detail page.
        # The flag is set in ``_annotate_rows_with_layout_signal``
        # which runs AFTER pagination — so layout filtering happens
        # after sort + paginate. To make the filter effective, we
        # must run the annotation BEFORE filtering. The handler
        # short-circuits and skips this branch when the annotation
        # hasn't run yet (e.g. on rows that fell outside the page).
        if layout == "with":
            out = [r for r in out if r.get("has_layout_recommendation")]
        elif layout == "without":
            out = [r for r in out if not r.get("has_layout_recommendation")]
    return out


# ── Sorting ────────────────────────────────────────────────────────────


def _sort_rows(
    rows: list[dict[str, Any]], sort_by: str, direction: str
) -> list[dict[str, Any]]:
    reverse = direction == "desc"
    if sort_by == "project":

        def key(r: dict[str, Any]) -> str:
            return r["project_name"] or ""

    elif sort_by == "dataset":

        def key(r: dict[str, Any]) -> str:
            return (r["affected_dataset"] or "").lower()

    elif sort_by == "table":

        def key(r: dict[str, Any]) -> str:
            return (r["affected_object"] or r["affected_table"] or "").lower()

    elif sort_by == "author":

        def key(r: dict[str, Any]) -> str:
            return (r.get("author_email") or "").lower()

    elif sort_by == "type":

        def key(r: dict[str, Any]) -> str:
            return r["opportunity_type"]

    elif sort_by == "workload":

        def key(r: dict[str, Any]) -> str:
            return r["query_workload_kind"] or "zzz"

    elif sort_by == "cost":

        def key(r: dict[str, Any]) -> float:
            return r["query_cost_value"] or 0

    elif sort_by == "age":

        def key(r: dict[str, Any]) -> datetime:
            return r["last_detected_at"] or datetime.min

    elif sort_by == "state":
        # Cloud sorts state asc=Safe→High→Awaiting; audit's analogue
        # is severity bucket order (critical → low) — we treat
        # asc=low_severity_first, desc=critical_first.
        def key(r: dict[str, Any]) -> int:
            return _BUCKET_ORDER.get(r["severity_bucket"], 99)

        reverse = not reverse  # asc on bucket order = critical first feels wrong; flip

    elif sort_by == "layout":
        # Boolean sort: True > False. ``desc`` puts Yes rows first
        # (the recommendation-having tables — usually what you want
        # to see when sorting by this column). ``asc`` puts None
        # first.
        def key(r: dict[str, Any]) -> int:
            return 1 if r.get("has_layout_recommendation") else 0

    elif sort_by == "suggestions":
        # Numeric sort by the table's aggregated suggestion count.
        def key(r: dict[str, Any]) -> int:
            return int(r.get("table_suggestion_count") or 0)

    else:
        # Default fallback: sort by current cost.
        def key(r: dict[str, Any]) -> float:
            return r["query_cost_value"] or 0

    return sorted(rows, key=key, reverse=reverse)


# ── Routes ─────────────────────────────────────────────────────────────


@router.get("/opportunities", response_class=HTMLResponse)
def opportunities_index(
    request: Request,
    page: int = 1,
    sort: str | None = None,
    direction: str | None = None,
    search: str = "",
    projects: str = "",
    types: str = "",
    dataset: str = "",
    workload: str = "",
    suggestions: str = "",
    author: str = "",
    layout: str = "",
) -> HTMLResponse:
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    sort_by = sort if sort in _VALID_SORTS else _DEFAULT_SORT
    sort_dir = direction if direction in ("asc", "desc") else _DEFAULT_DIRECTION

    # Scope to the active (project, region). The SQLite cache is shared
    # across every project ever audited; without this filter, switching
    # projects shows the previous project's findings.
    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        # Storage-billing rows live in the dashboard's Storage Optimization
        # panel and are dataset-level (not per-job), so they don't belong
        # in this query-cost-driven workspace. Every other rule type
        # (issues + improvements) is listed — improvements still ride
        # along on issue rows under ``evidence_snapshot["_improvements"]``
        # for the inline diff stack on the detail page, AND they now also
        # surface as their own rows so models with only suggestions (no
        # underlying issue) still show up in /opportunities.
        _excluded_types = ["storage_billing_optimization"]
        active_rows = (
            session.query(Opportunity)
            .filter(Opportunity.status == "active")
            .filter(Opportunity.config_id == active_config_id)
            .filter(~Opportunity.opportunity_type.in_(_excluded_types))
            .order_by(desc(Opportunity.current_cost_estimate))
            .all()
        )
        if not active_rows:
            return RedirectResponse(url="/admin/configurations", status_code=303)

        # Hydrate first related job per opportunity for workload classification.
        all_job_ids: set[str] = set()
        for opp in active_rows:
            for jid in opp.related_job_ids or []:
                all_job_ids.add(jid)
        jobs_by_id: dict[str, BigQueryJob] = {}
        if all_job_ids:
            # Chunk the IN clause so SQLite's 999-variable cap doesn't
            # bite when the workspace has thousands of opportunities
            # spanning many distinct jobs. Same reasoning as
            # ``scan/persistence.py:_chunked`` — keep the path working
            # on default SQLite builds without depending on the
            # version's exact ``SQLITE_MAX_VARIABLE_NUMBER``.
            from governor_audit.scan.persistence import (
                _SQLITE_MAX_IN_PARAMS,
                _chunked,
            )

            for batch in _chunked(list(all_job_ids), _SQLITE_MAX_IN_PARAMS):
                jobs = (
                    session.query(BigQueryJob)
                    .filter(
                        BigQueryJob.job_id.in_(batch),
                        BigQueryJob.config_id == active_config_id,
                    )
                    .all()
                )
                for j in jobs:
                    jobs_by_id[j.job_id] = j

        per_opp_rows = [
            _to_row(
                opp,
                project_name=config.gcp_project_id,
                job=next(
                    (
                        jobs_by_id[j]
                        for j in (opp.related_job_ids or [])
                        if j in jobs_by_id
                    ),
                    None,
                ),
            )
            for opp in active_rows
        ]

    # Build available filter values from the full per-opp row set.
    # Issue dropdown shows ONLY ISSUE rule types — the cost/perf signals
    # BigQuery's optimizer attaches to ``performance_insights``
    # (slot_contention, shuffle_spill, partition_pruning,
    # join_explosion). Suggestion-typed rules (select_star, dead_cte,
    # etc.) are SQL-rewrite improvements, not issues, and shouldn't
    # appear under a dropdown labelled "Issue".
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES

    _present_types = {r["opportunity_type"] for r in per_opp_rows}
    available_types = sorted(
        ISSUE_RULE_TYPES & _present_types - {"storage_billing_optimization"}
    )
    available_datasets = sorted(
        {r["affected_dataset"] for r in per_opp_rows if r["affected_dataset"] and r["affected_dataset"] != "—"}
    )
    available_authors = sorted(
        {r.get("author_email") for r in per_opp_rows if r.get("author_email")}
    )

    # Aggregate per-opp rows into one row per ``affected_table``. A
    # single object can fire multiple rules (one issue + several
    # suggestions are common for dbt model rebuilds), and the listing
    # was previously emitting one row per Opportunity — so a model
    # with 4 findings showed up 4 times. Users expect one row per
    # object with summary counts; the row click goes to the cohort
    # view at /jobs/{table} for the full per-rule detail.
    rows = _aggregate_rows_by_table(per_opp_rows)

    # Summary BEFORE filters — covers the visible workspace (audit has
    # only one project so this matches the cloud's "all rows in scope").
    summary = _summary_from_rows(per_opp_rows)

    # Spec 148 — annotate every row with ``has_layout_recommendation``
    # so the Layout column, the Layout filter, and the layout sort
    # all see the same boolean. Annotation has aggressive cross-row
    # caching (one DB query for consumer-candidate jobs; per-target
    # schema/storage caches; short-circuit on first qualifying
    # target) so the cost stays bounded even on large row sets.
    _annotate_rows_with_layout_signal(rows, config_id=active_config_id)

    # Apply filters + sort + paginate. Filters operate on the
    # aggregated rows: the per-table representative carries
    # ``table_issue_types`` / ``table_issue_count`` /
    # ``table_suggestion_count`` so issue/suggestion filters still
    # match correctly even though we collapsed multiple opps into one
    # row.
    filtered = _apply_filters(
        rows,
        search=search,
        projects=projects,
        types=types,
        dataset=dataset,
        workload=workload,
        suggestions=suggestions,
        author=author,
        layout=layout,
    )
    filtered = _sort_rows(filtered, sort_by, sort_dir)

    page = max(1, page)
    base_pairs: list[tuple[str, str]] = []
    if search:
        base_pairs.append(("search", search))
    if types:
        base_pairs.append(("types", types))
    if dataset:
        base_pairs.append(("dataset", dataset))
    if workload:
        base_pairs.append(("workload", workload))
    if suggestions:
        base_pairs.append(("suggestions", suggestions))
    if author:
        base_pairs.append(("author", author))
    if layout:
        base_pairs.append(("layout", layout))

    pagination = AuditPaginationContext(
        page=page,
        page_size=_PAGE_SIZE,
        total_items=len(filtered),
        base_query_pairs=base_pairs,
        sort=sort_by if sort_by != _DEFAULT_SORT else None,
        direction=sort_dir if sort_dir != _DEFAULT_DIRECTION else None,
    )
    if page > pagination.total_pages:
        page = pagination.total_pages
        pagination = AuditPaginationContext(
            page=page,
            page_size=_PAGE_SIZE,
            total_items=len(filtered),
            base_query_pairs=base_pairs,
            sort=sort_by if sort_by != _DEFAULT_SORT else None,
            direction=sort_dir if sort_dir != _DEFAULT_DIRECTION else None,
        )
    start = (page - 1) * _PAGE_SIZE
    paged = filtered[start : start + _PAGE_SIZE]

    signals = {
        "search": search,
        "projects": projects,
        "types": types,
        "dataset": dataset,
        "workload": workload,
        "suggestions": suggestions,
        "author": author,
        "layout": layout,
        "sort": sort_by,
        "direction": sort_dir,
        "page": page,
    }

    return request.app.state.templates.TemplateResponse(
        request,
        "opportunities/index.html",
        {
            "title": "Opportunities — Governor Audit",
            "opportunities": paged,
            "summary": summary,
            "signals": signals,
            "available_types": available_types,
            "available_datasets": available_datasets,
            "available_authors": available_authors,
            "pagination": pagination,
            "local_runtime_mode": True,
            "config": config,
        },
    )


@router.get("/opportunities/{opportunity_id}", response_class=HTMLResponse)
def opportunities_detail(request: Request, opportunity_id: str) -> HTMLResponse:
    """Object-overview detail page.

    The URL keeps the per-opportunity_id shape for backward
    compatibility with bookmarks, but the page now lists EVERY active
    finding for the requested opportunity's ``affected_table``. Users
    naturally think in terms of "what's wrong with my model" — one
    page per (rule, table) was forcing them to bounce between pages
    that mostly described the same object.
    """
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    from governor_audit.scan.sentinels import config_id_for
    from governor_core.utils.diff import generate_code_diff

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        # 1. Resolve the requested opp → its affected_table.
        anchor = session.get(Opportunity, opportunity_id)
        if anchor is None or anchor.config_id != active_config_id:
            raise HTTPException(status_code=404, detail="Opportunity not found")

        affected_table = anchor.affected_table

        # 2. Fetch every active opportunity on the same table.
        #    storage_billing rows live on the dashboard panel and are
        #    dataset-level (not table-level) so they don't belong here.
        all_opps_for_table = (
            session.query(Opportunity)
            .filter(
                Opportunity.config_id == active_config_id,
                Opportunity.affected_table == affected_table,
                Opportunity.status == "active",
                Opportunity.opportunity_type != "storage_billing_optimization",
            )
            .order_by(desc(Opportunity.severity_score), desc(Opportunity.current_cost_estimate))
            .all()
        )

        # 3. Hydrate every related job for stat-strip / per-issue
        #    job-lookup SQL. Chunk the IN clause to dodge SQLite's
        #    999-variable cap.
        all_job_ids: set[str] = set()
        for o in all_opps_for_table:
            for jid in o.related_job_ids or []:
                all_job_ids.add(jid)
        jobs_by_id: dict[str, BigQueryJob] = {}
        if all_job_ids:
            from governor_audit.scan.persistence import (
                _SQLITE_MAX_IN_PARAMS,
                _chunked,
            )

            for batch in _chunked(list(all_job_ids), _SQLITE_MAX_IN_PARAMS):
                jobs = (
                    session.query(BigQueryJob)
                    .filter(
                        BigQueryJob.job_id.in_(batch),
                        BigQueryJob.config_id == active_config_id,
                    )
                    .all()
                )
                for j in jobs:
                    jobs_by_id[j.job_id] = j

        def _first_job_for(opp: Opportunity) -> BigQueryJob | None:
            for jid in opp.related_job_ids or []:
                if jid in jobs_by_id:
                    return jobs_by_id[jid]
            return None

        # 4. Build per-opp views (full row dict).
        per_opp_views = [
            (o, _first_job_for(o), _to_row(o, project_name=config.gcp_project_id, job=_first_job_for(o)))
            for o in all_opps_for_table
        ]

        # 5. Cost-trend chart payload for the table.
        from governor_audit.jobs.cohort_view import build_chart_points_payload

        chart_points_payload = (
            build_chart_points_payload(
                session,
                config_id=active_config_id,
                destination_table=affected_table,
            )
            if affected_table
            else []
        )

    # ── Header / stat-strip representative ─────────────────────────
    # Use the highest-priority opp for the title pill + stat strip
    # (issues outrank suggestions; within tier, severity wins; the
    # ORDER BY above did the work). Fall back to the first per_opp_views
    # entry if filtering somehow produced empty.
    if not per_opp_views:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    representative_opp, representative_job, representative_row = per_opp_views[0]

    # ── Per-issue cards ────────────────────────────────────────────
    issue_cards: list[dict[str, Any]] = []
    for o, job, row in per_opp_views:
        if not row["is_issue"]:
            continue
        rule_meta = next(
            (e for e in get_detection_rule_catalog() if e.rule_type == row["opportunity_type"]),
            None,
        )
        evidence_snapshot = row["evidence_snapshot"] or {}
        # ``_template_result`` for issues like storage_billing — most
        # issue rules don't carry their own diff. Suggestion-typed
        # rules go through the unified suggestion list below.
        tr = evidence_snapshot.get("_template_result")
        diff_lines = None
        if tr and tr.get("before_content") and tr.get("after_content") and tr["before_content"] != tr["after_content"]:
            diff_lines = generate_code_diff(tr["before_content"], tr["after_content"])
        visible_evidence = {
            k: v for k, v in evidence_snapshot.items() if not str(k).startswith("_")
        }
        job_lookup_sql = _build_job_lookup_sql(
            job, config.gcp_project_id, config.bigquery_region
        )
        issue_cards.append({
            "row": row,
            "rule_meta": rule_meta,
            "job": job,
            "job_lookup_sql": job_lookup_sql,
            "template_result": tr,
            "diff_lines": diff_lines,
            "visible_evidence": visible_evidence,
        })

    # ── Unified suggestion list ────────────────────────────────────
    # Three sources contribute to the table's full suggestion catalogue:
    #   a. Each issue opp's ``_improvements`` list (improvement
    #      candidates the detection runner attached to issues fired on
    #      the same destination table).
    #   b. Each suggestion-only opp's own ``_template_result``
    #      (suggestion rules surface as their own opp rows since
    #      v0.3.0; their template is what powers the diff card).
    #
    # We dedupe by ``rule_type`` so the user sees one card per
    # SQL-rewrite suggestion no matter how many opps surfaced it. The
    # FIRST occurrence wins so the explanation/text from the
    # representative source is what renders.
    improvement_views: list[dict[str, Any]] = []
    seen_rule_types: set[str] = set()

    def _try_add_card(card: dict[str, Any]) -> None:
        rt = card.get("rule_type")
        if not rt or rt in seen_rule_types:
            return
        seen_rule_types.add(rt)
        before = card.get("before_content")
        after = card.get("after_content")
        if before and after and before != after:
            card["diff_lines"] = generate_code_diff(before, after)
        else:
            card["diff_lines"] = None
        meta = next(
            (e for e in get_detection_rule_catalog() if e.rule_type == rt),
            None,
        )
        card["display_name"] = meta.display_name if meta else rt.replace("_", " ").title()
        improvement_views.append(card)

    for o, _, row in per_opp_views:
        evidence = row["evidence_snapshot"] or {}
        # (a) attached improvements on issue rows.
        for imp in evidence.get("_improvements") or []:
            _try_add_card(dict(imp))
        # (b) suggestion-only opp's own template promoted to a card.
        if not row["is_issue"]:
            tr = evidence.get("_template_result")
            if tr:
                _try_add_card({
                    "rule_type": row["opportunity_type"],
                    "explanation": tr.get("explanation") or row.get("explanation") or "",
                    "template_id": tr.get("template_id"),
                    "before_content": tr.get("before_content"),
                    "after_content": tr.get("after_content"),
                    "rollback": tr.get("rollback"),
                    "occurrences": 1,
                })

    # Top-level Evidence + BigQuery-query-lookup cards. These render
    # for every detail page (issue rows + suggestion-only rows) so
    # the user always has the raw evidence + a paste-able BQ console
    # query without expanding any nested collapsible. ``visible_evidence``
    # is the representative's evidence_snapshot with internal scratch
    # keys stripped (Jinja has no startswith test).
    visible_evidence = {
        k: v
        for k, v in (representative_row.get("evidence_snapshot") or {}).items()
        if not str(k).startswith("_")
    }
    job_lookup_sql = _build_job_lookup_sql(
        representative_job, config.gcp_project_id, config.bigquery_region
    )

    # ── Spec 148 — Layout recommendation card(s) ──────────────────
    # Joins three signals (lineage → column-usage → schema/storage)
    # into per-target "recommend partition by X / cluster on (Y, Z)"
    # suggestions. Read-only; never modifies SQL.
    #
    # Targets: ``affected_table`` itself + every distinct upstream
    # referenced by jobs that triggered an opportunity on the table.
    # The producer-of-affected_table jobs (in ``related_jobs``) read
    # the upstreams, so their ``referenced_tables`` is where the
    # upstream candidates come from. For ``partition_pruning`` this
    # is the right surface: the rule fires on the downstream that
    # did the bad scan, but the partition fix belongs on the
    # upstream it was reading.
    layout_recommendations = _build_layout_recommendations(
        affected_table=affected_table,
        config_id=active_config_id,
        related_jobs=list(jobs_by_id.values()),
    )

    return request.app.state.templates.TemplateResponse(
        request,
        "opportunities/detail.html",
        {
            "title": "Opportunity — Governor Audit",
            # Header / stat-strip representative.
            "row": representative_row,
            "job": representative_job,
            # Per-issue cards (one per issue rule that fired on this table).
            "issue_cards": issue_cards,
            # Unified suggestions list across every opp on this table.
            "improvements": improvement_views,
            # Cost-trend chart for the table.
            "chart_points_payload": chart_points_payload,
            # Top-level evidence + BigQuery query lookup (representative).
            "visible_evidence": visible_evidence,
            "job_lookup_sql": job_lookup_sql,
            # Spec 148 layout recommendations — list of zero or more.
            # Template loops over the list; empty list = no card chrome.
            "layout_recommendations": layout_recommendations,
        },
    )


def _annotate_rows_with_layout_signal(
    rows: "list[dict[str, Any]]", *, config_id: str
) -> None:
    """In-place annotate ``rows`` with ``has_layout_recommendation:
    bool`` so the listing's Layout column can render Yes / None.

    Computed at listing render time but with aggressive sharing
    across rows: one DB query per page (not per row), pre-resolved
    referenced_tables lookup, schema/storage caches keyed on the
    target table identifier (multiple rows often share an upstream
    target — a partition_pruning row's upstream is also the upstream
    of any other downstream that reads the same source).

    Bounded by ``len(rows)`` (the visible page, default 10) so the
    listing's wall-time impact is small even on large audit caches.
    Wrapped in a try/except so any failure leaves the flag unset
    (template renders "—") rather than 500-ing the listing.
    """
    if not rows:
        return

    try:
        from governor_audit.lineage.column_usage import analyse_column_usage
        from governor_audit.lineage.recommendations import build_recommendation
        from governor_core.sync.models import (
            BigQueryJob,
            TableColumnMetadata,
            TableStorageMetric,
        )

        # Default every row to False so the template always has a
        # value to read; flip to True below as we find recommendations.
        for row in rows:
            row.setdefault("has_layout_recommendation", False)

        engine = build_engine()
        create_all(engine)
        factory = make_session_factory(engine)
        with factory() as session:
            # Single load of all jobs in this config that have any
            # referenced_tables — these are the candidate consumers
            # for every target table.
            all_consumer_candidates = (
                session.query(BigQueryJob)
                .filter(
                    BigQueryJob.config_id == config_id,
                    BigQueryJob.referenced_tables.isnot(None),
                )
                .all()
            )

            # Pre-resolve referenced_tables once so per-target lookups
            # are O(1). Also build destination → producer map so we
            # can find the upstream candidates per row.
            jobs_by_referenced_table: dict[str, list[BigQueryJob]] = {}
            jobs_by_destination: dict[str, list[BigQueryJob]] = {}
            for j in all_consumer_candidates:
                if j.destination_table:
                    jobs_by_destination.setdefault(
                        j.destination_table, []
                    ).append(j)
                seen: set[str] = set()
                for ref in (j.referenced_tables or []):
                    fq = _ref_to_fq(ref)
                    if fq is not None and fq not in seen:
                        seen.add(fq)
                        jobs_by_referenced_table.setdefault(fq, []).append(j)

            # Per-target caches reused across rows — multiple rows
            # often share an upstream target.
            schema_cache: dict[str, list] = {}
            storage_cache: dict[str, object] = {}
            target_has_rec_cache: dict[str, bool] = {}

            def _schema_storage(target: str):
                if target in schema_cache:
                    return schema_cache[target], storage_cache[target]
                parts = target.split(".")
                if len(parts) != 3:
                    schema_cache[target] = []
                    storage_cache[target] = None
                    return [], None
                _proj, dataset, table = parts
                schema = (
                    session.query(TableColumnMetadata)
                    .filter(
                        TableColumnMetadata.config_id == config_id,
                        TableColumnMetadata.dataset_name == dataset,
                        TableColumnMetadata.table_name == table,
                    )
                    .all()
                )
                storage = (
                    session.query(TableStorageMetric)
                    .filter(
                        TableStorageMetric.config_id == config_id,
                        TableStorageMetric.dataset_name == dataset,
                        TableStorageMetric.table_name == table,
                    )
                    .first()
                )
                schema_cache[target] = schema
                storage_cache[target] = storage
                return schema, storage

            def _target_qualifies(target: str) -> bool:
                if target in target_has_rec_cache:
                    return target_has_rec_cache[target]
                consumers = jobs_by_referenced_table.get(target, [])
                if not consumers:
                    target_has_rec_cache[target] = False
                    return False
                usage = analyse_column_usage(consumers).get(target)
                if usage is None:
                    target_has_rec_cache[target] = False
                    return False
                schema, storage = _schema_storage(target)
                rec = build_recommendation(
                    target,
                    column_usage=usage,
                    schema=schema,
                    storage=storage,
                )
                qualifies = rec is not None
                target_has_rec_cache[target] = qualifies
                return qualifies

            for row in rows:
                affected = row.get("affected_table") or ""
                if not affected:
                    continue

                # Targets: affected_table itself + every distinct
                # upstream referenced by jobs whose destination is
                # affected_table. Mirrors the detail-page handler so
                # the listing flag is consistent with the card that
                # would actually render.
                targets: set[str] = {affected}
                for producer in jobs_by_destination.get(affected, []):
                    for ref in (producer.referenced_tables or []):
                        fq = _ref_to_fq(ref)
                        if fq and fq != affected:
                            targets.add(fq)

                # Short-circuit on the first qualifying target — the
                # flag is yes/no, we don't need to enumerate all.
                for target in sorted(targets):
                    if _target_qualifies(target):
                        row["has_layout_recommendation"] = True
                        break
    except Exception:  # noqa: BLE001
        logger.exception(
            "layout-signal annotation failed — listing renders "
            "without the Layout column populated"
        )


def _select_recommendation_targets(
    affected_table: str, related_jobs: "Iterable[BigQueryJob]"
) -> list[str]:
    """Pick the table(s) we should run the layout recommender against.

    The opportunity points at ``affected_table`` (the destination of
    whatever job triggered it). For most issue rules the actual
    layout fix belongs on an upstream — ``partition_pruning`` fires
    on the downstream that did a full scan, but the partition_by
    you'd add lives on the upstream that should have been
    partitioned.

    So the candidate target set is ``{affected_table}`` ∪
    ``{every fully-qualified upstream referenced by a producer job
    of affected_table}``. Each candidate is then handed to the
    recommender; the recommender abstains when consumer-side signal
    is weak, so over-broad targeting is harmless.
    """
    targets: set[str] = {affected_table}
    for job in related_jobs:
        # Only producer jobs of affected_table contribute upstreams.
        # Other jobs in the related set might be unrelated reads.
        if getattr(job, "destination_table", None) != affected_table:
            continue
        refs = getattr(job, "referenced_tables", None) or []
        for ref in refs:
            fq = _ref_to_fq(ref)
            if fq and fq != affected_table:
                targets.add(fq)
    return sorted(targets)


def _build_layout_recommendations(
    *,
    affected_table: str,
    config_id: str,
    related_jobs: "list[BigQueryJob]",
) -> list:
    """Return zero or more ``LayoutRecommendation`` objects, one per
    qualifying target table.

    For each target:

    1. Find consumer jobs — every cached job whose ``referenced_tables``
       contains the target. This is the input to L2's column-usage
       analyser.
    2. Look up the target's schema (``TableColumnMetadata``) and
       storage (``TableStorageMetric``) for L3's gates.
    3. Call the recommender. Skip targets that produce ``None``.

    Wrapped in a try/except so any unexpected failure (rogue query,
    schema row mishap) returns an empty list rather than 500-ing the
    detail page. The card is opportunistic; the rest of the page
    must always render.
    """
    try:
        from governor_audit.lineage.column_usage import analyse_column_usage
        from governor_audit.lineage.recommendations import build_recommendation
        from governor_core.sync.models import (
            BigQueryJob,
            TableColumnMetadata,
            TableStorageMetric,
        )

        targets = _select_recommendation_targets(affected_table, related_jobs)
        if not targets:
            return []

        # Load every cached job for this config that has a non-empty
        # referenced_tables list. We then filter Python-side per
        # target — SQLite's JSONB containment story is brittle and
        # the bounded-N audit cache (single-project) makes the
        # in-memory filter cheap. If this becomes a hot path on
        # multi-million-row caches, push the filter down via a
        # SQLite ``json_each`` LATERAL.
        engine = build_engine()
        create_all(engine)
        factory = make_session_factory(engine)
        with factory() as session:
            all_consumer_candidates = (
                session.query(BigQueryJob)
                .filter(
                    BigQueryJob.config_id == config_id,
                    BigQueryJob.referenced_tables.isnot(None),
                )
                .all()
            )

            # Pre-resolve referenced_tables for each candidate to a
            # set of FQ table names so the per-target filter is O(N)
            # instead of O(N × refs_per_job).
            jobs_by_referenced_table: dict[str, list[BigQueryJob]] = {}
            for j in all_consumer_candidates:
                seen: set[str] = set()
                for ref in (j.referenced_tables or []):
                    fq = _ref_to_fq(ref)
                    if fq is not None and fq not in seen:
                        seen.add(fq)
                        jobs_by_referenced_table.setdefault(fq, []).append(j)

            recs: list = []
            for target in targets:
                consumers = jobs_by_referenced_table.get(target, [])
                if not consumers:
                    continue

                usage_by_table = analyse_column_usage(consumers)
                usage = usage_by_table.get(target)
                if usage is None:
                    continue

                parts = target.split(".")
                if len(parts) != 3:
                    continue
                _project, dataset, table = parts

                schema = (
                    session.query(TableColumnMetadata)
                    .filter(
                        TableColumnMetadata.config_id == config_id,
                        TableColumnMetadata.dataset_name == dataset,
                        TableColumnMetadata.table_name == table,
                    )
                    .all()
                )
                storage = (
                    session.query(TableStorageMetric)
                    .filter(
                        TableStorageMetric.config_id == config_id,
                        TableStorageMetric.dataset_name == dataset,
                        TableStorageMetric.table_name == table,
                    )
                    .first()
                )

                rec = build_recommendation(
                    target,
                    column_usage=usage,
                    schema=schema,
                    storage=storage,
                )
                if rec is not None:
                    recs.append(rec)
            return recs
    except Exception:  # noqa: BLE001
        logger.exception(
            "layout recommendations failed for %s — rendering detail "
            "without the card",
            affected_table,
        )
        return []


def _ref_to_fq(ref: object) -> str | None:
    """Normalise a single ``referenced_tables`` entry to ``project.dataset.table``."""
    if isinstance(ref, str):
        return ref
    if isinstance(ref, dict):
        proj = ref.get("project_id") or ref.get("projectId") or ""
        ds = ref.get("dataset_id") or ref.get("datasetId") or ""
        tbl = ref.get("table_id") or ref.get("tableId") or ""
        parts = [p for p in (proj, ds, tbl) if p]
        if len(parts) == 3:
            return ".".join(parts)
    return None


def _build_job_lookup_sql(
    job: BigQueryJob | None, project_id: str, region: str
) -> str | None:
    """Render an ``INFORMATION_SCHEMA.JOBS_BY_PROJECT`` query that
    returns exactly the row corresponding to ``job``.

    Includes a tight ``creation_time`` predicate when we know it,
    because BigQuery requires a partition filter on that view's
    underlying table to keep scan cost bounded.
    """
    if job is None or not job.job_id:
        return None
    region_clean = (region or "us").strip().lower()
    project_clean = (project_id or "").strip()
    if not project_clean:
        return None

    if job.creation_time is not None:
        ts_iso = job.creation_time.replace(microsecond=0).isoformat()
        # Add a 1-hour buffer either side so timezone or rounding skew
        # doesn't drop the row from the scan.
        time_clause = (
            f"  AND creation_time BETWEEN "
            f"TIMESTAMP_SUB(TIMESTAMP(\"{ts_iso}\"), INTERVAL 1 HOUR)\n"
            f"      AND TIMESTAMP_ADD(TIMESTAMP(\"{ts_iso}\"), INTERVAL 1 HOUR)\n"
        )
    else:
        time_clause = (
            "  AND creation_time >= "
            "TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 180 DAY)\n"
        )

    safe_job_id = job.job_id.replace("'", "\\'")
    # Curated column list — the fields useful for diagnosing a single
    # job. Mirrors the scan-time SELECT in
    # ``governor_audit.scan.information_schema.build_information_schema_query``
    # so what the user inspects matches what audit consumed.
    select_clause = (
        "SELECT\n"
        "    job_id,\n"
        "    user_email,\n"
        "    creation_time,\n"
        "    start_time,\n"
        "    end_time,\n"
        "    statement_type,\n"
        "    state,\n"
        "    cache_hit,\n"
        "    error_result,\n"
        "    total_slot_ms,\n"
        "    total_bytes_processed,\n"
        "    total_bytes_billed,\n"
        "    destination_table,\n"
        "    referenced_tables,\n"
        "    labels,\n"
        "    query_info.performance_insights AS performance_insights,\n"
        "    query_info.query_hashes AS query_hashes,\n"
        "    timeline,\n"
        "    query\n"
    )
    return (
        select_clause
        + f"FROM `{project_clean}.region-{region_clean}`."
        "INFORMATION_SCHEMA.JOBS_BY_PROJECT\n"
        f"WHERE job_id = '{safe_job_id}'\n"
        + time_clause
    )


__all__ = ["router"]
