"""Audit-specific classification of detection rules into ``issues`` vs
``improvements``.

The ``governor_core.opportunities.rules`` catalog treats every rule
identically — they all return ``OpportunityCandidate`` objects.
Audit's UX is more focused: only **issues** (real cost / performance
problems) get listed in ``/opportunities``. The remaining rules are
**improvements** — code-quality SQL rewrites that get *attached* to
the issues they could improve, never standing on their own.

Rationale:

  * Issues like ``slot_contention`` or ``shuffle_spill`` are what the
    user is actually paying for. They want a list.
  * Improvements like ``dead_cte`` or ``select_star`` are how to fix
    those issues — listing them as their own table rows clutters the
    workspace and confuses the user about what's actionable.

This split is **audit-only**. The cloud product still treats all
rules uniformly because it has a different workflow (LLM solution
generation per-opportunity).
"""

from __future__ import annotations

from typing import Any


def is_failed_job(job: Any) -> bool:
    """Whether a ``BigQueryJob`` row represents a failed execution.

    Spec 149 ingests failed jobs alongside successful ones. BigQuery's
    INFORMATION_SCHEMA may surface the ``error_result`` STRUCT either as
    NULL (typical) or as an all-fields-NULL struct (some dialects /
    proxies). Both cases mean "the query succeeded". A real failure has
    at least ``error_result.reason`` set.

    The check tolerates whatever shape the persistence layer happened to
    write — ORM dict, raw dict, or None — so callers don't need to know.
    """
    err = getattr(job, "error_result", None) if not isinstance(job, dict) else job.get("error_result")
    if err is None:
        return False
    if isinstance(err, dict):
        # All-None or empty dict → not a real failure.
        if not any(v not in (None, "", {}, []) for v in err.values()):
            return False
        return True
    # Anything else truthy is treated as a failure (defensive).
    return bool(err)


# Real cost / performance problems. Each one persists as an
# ``Opportunity`` row and shows up in ``/opportunities``.
ISSUE_RULE_TYPES: frozenset[str] = frozenset(
    {
        "slot_contention",
        "join_explosion",
        "partition_pruning",
        "shuffle_spill",
        "storage_billing_optimization",
    }
)

# Code-quality SQL rewrites. These detection rules still run, but
# their candidates are **not** persisted as standalone opportunities.
# Instead, each issue collects every improvement firing on the same
# ``destination_table`` and attaches it under
# ``Opportunity.evidence_snapshot["_improvements"]`` for the detail
# page to render as a stack of diffs.
IMPROVEMENT_RULE_TYPES: frozenset[str] = frozenset(
    {
        "dead_cte",
        "dead_column",
        "dead_window_expression",
        "unused_aggregation_output",
        "redundant_order_by",
        "unused_join",
        "select_star",
        "cross_join_unaggregated",
        "self_join_anti_pattern",
    }
)


def is_issue(rule_type: str) -> bool:
    return rule_type in ISSUE_RULE_TYPES


def is_improvement(rule_type: str) -> bool:
    return rule_type in IMPROVEMENT_RULE_TYPES


__all__ = [
    "ISSUE_RULE_TYPES",
    "IMPROVEMENT_RULE_TYPES",
    "is_failed_job",
    "is_issue",
    "is_improvement",
]
