"""End-to-end scan orchestrator.

Flow:
    load config → resolve effective dbt_only flag → compute window
        → BigQuery dry-run (logged for visibility, no cap enforced)
        → submit query (unless --dry-run)
        → persist BigQueryJob rows
        → invoke governor-core detection rules
        → persist Opportunity + AuditOpportunityMetadata rows
        → mark ScanRun status

The BigQuery client is injected so tests can substitute a fake. In
production the client is built from the user's gcloud ADC credentials.

**v2 change**: no manifest loading; no attribution step. Each
opportunity's ``AuditOpportunityMetadata.is_dbt_originated`` is
derived from the underlying job's query prefix.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Iterable

from sqlalchemy.orm import Session

from governor_audit.config.schema import AuditConfig
from governor_audit.db.models import ScanRun
from governor_audit.scan.information_schema import (
    BigQueryClientProtocol,
    DryRunEstimate,
    build_information_schema_query,
    clamp_lookback_days,
    estimated_cost_usd,
    extract_dbt_invocation_id,
    extract_dbt_node_id,
    extract_query_hash,
    is_dbt_originated,
)

logger = logging.getLogger("governor_audit.scan")


def _human_bytes(n: int) -> str:
    """Render a byte count as 'X.XX GB' / 'X.XX MB' / 'N B' for log + UI."""
    n_f = float(n)
    if n_f >= 1024**3:
        return f"{n_f / 1024**3:.2f} GB"
    if n_f >= 1024**2:
        return f"{n_f / 1024**2:.2f} MB"
    if n_f >= 1024:
        return f"{n_f / 1024:.2f} KB"
    return f"{n} B"


class ScanCostCapExceeded(Exception):
    """Retained for backward compatibility — never raised since v0.0.11.

    The audit no longer enforces a client-side dry-run cap on the
    INFORMATION_SCHEMA scan; the previous default (10 GB) was paternalistic
    and surprised users with valid scans that legitimately needed more.
    The dry-run estimate is still logged at INFO so users see what
    they're about to spend, but the scan is no longer blocked.
    """


@dataclass
class ScanResult:
    scan_run: ScanRun
    fresh_job_count: int
    cached_job_count: int
    dbt_originated_job_count: int
    unique_query_hash_count: int
    opportunity_count: int
    cost_usd: float
    dbt_only_filter: bool
    lookback_clamp_warning: str | None


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def compute_window(
    *, lookback_days: int, now: datetime | None = None
) -> tuple[datetime, datetime]:
    """Return (window_start, window_end) for the requested lookback."""
    end = now or _now_utc()
    start = end - timedelta(days=lookback_days)
    return start, end


def resolve_dbt_only_flag(
    *, cli_value: bool | None, config: AuditConfig
) -> bool:
    """CLI flag wins over config default; config default is the fallback."""
    if cli_value is not None:
        return cli_value
    return config.scan_defaults.dbt_only


def create_running_scan_run(
    session: Session,
    *,
    config: AuditConfig,
    lookback_days: int,
    dbt_only: bool,
) -> ScanRun:
    """Persist a minimal ScanRun row in ``running`` state and commit it.

    Called from the request handler so the row appears in
    ``/admin/configurations`` scan history the instant the user clicks
    Run scan, before any BigQuery work happens. The orchestrator
    (``run_scan``) accepts the resulting ``scan_run`` and updates it as
    the scan progresses, instead of creating a new one.

    The row carries the project/region/lookback the user requested, so
    even a daemon that crashes before the dry-run still leaves a
    well-formed history entry. The outer worker is responsible for
    flipping it to ``failed`` on any unhandled exception.
    """
    effective_lookback, _ = clamp_lookback_days(lookback_days)
    window_start, window_end = compute_window(lookback_days=effective_lookback)
    scan_run = ScanRun(
        id=ScanRun.new_id(),
        started_at=_now_utc(),
        actual_window_start=window_start,
        actual_window_end=window_end,
        requested_lookback_days=effective_lookback,
        status="running",
        dry_run_estimated_bytes=0,
        estimated_cost_usd=Decimal("0"),
        gcp_project_id=config.gcp_project_id,
        bigquery_region=config.bigquery_region,
        dbt_only_filter=dbt_only,
    )
    session.add(scan_run)
    session.commit()
    return scan_run


def _wipe_previous_scan_state(session: Session, *, config_id: str) -> None:
    """Delete every row scoped to ``config_id`` from the scan-data tables.

    Each new scan replaces the previous scan's data inside the same
    (project, region) so the dashboard / opportunities surfaces only
    show what the latest scan saw — not the union of every scan ever
    run. ``ScanRun`` rows are intentionally NOT wiped (they're the
    history table); ``ManifestConfiguration`` and the sentinel
    SyncOperation/DetectionJob rows stay too — they're FK targets for
    the rows we're about to insert in this scan.

    ``AuditOpportunityMetadata.opportunity_id`` is FK
    ``ondelete=CASCADE``, so removing Opportunity rows cleans the
    metadata sidecar too.
    """
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import (
        BigQueryJob,
        TableColumnMetadata,
        TableStorageMetric,
    )

    deleted_opps = (
        session.query(Opportunity)
        .filter(Opportunity.config_id == config_id)
        .delete(synchronize_session=False)
    )
    deleted_jobs = (
        session.query(BigQueryJob)
        .filter(BigQueryJob.config_id == config_id)
        .delete(synchronize_session=False)
    )
    deleted_columns = (
        session.query(TableColumnMetadata)
        .filter(TableColumnMetadata.config_id == config_id)
        .delete(synchronize_session=False)
    )
    deleted_storage = (
        session.query(TableStorageMetric)
        .filter(TableStorageMetric.config_id == config_id)
        .delete(synchronize_session=False)
    )
    session.flush()
    logger.info(
        "scan: wiped previous state for config_id=%s — "
        "%d opportunities, %d jobs, %d columns, %d storage_metrics",
        config_id,
        deleted_opps,
        deleted_jobs,
        deleted_columns,
        deleted_storage,
    )


def run_scan(
    *,
    config: AuditConfig,
    session: Session,
    bq_client: BigQueryClientProtocol,
    lookback_days: int | None = None,
    max_scan_bytes: int | None = None,  # accepted for API stability; ignored.
    dbt_only: bool | None = None,
    scan_run: ScanRun | None = None,
) -> ScanResult:
    """Execute one scan end-to-end. The caller is responsible for holding
    the scan lock; this function commits the session itself.

    The legacy ``max_scan_bytes`` argument is kept for backward
    compatibility with callers (the CLI's ``--max-scan-bytes`` flag, the
    web routes) but is no longer enforced. The dry-run estimate is
    logged at INFO so users still see what they're about to spend.
    """
    del max_scan_bytes  # explicitly unused — see docstring.
    requested_lookback = lookback_days or config.scan_defaults.lookback_days
    # INFORMATION_SCHEMA.JOBS retains 180 days; clamp + warn if user
    # asked for more (the request would silently return empty for the
    # excess range otherwise).
    effective_lookback, clamp_warning = clamp_lookback_days(requested_lookback)
    if clamp_warning:
        logger.warning(clamp_warning)
    effective_dbt_only = resolve_dbt_only_flag(cli_value=dbt_only, config=config)
    window_start, window_end = compute_window(lookback_days=effective_lookback)

    sql, params = build_information_schema_query(
        project_id=config.gcp_project_id,
        region=config.bigquery_region,
        window_start=window_start,
        window_end=window_end,
        dbt_only=effective_dbt_only,
    )

    # Log the exact SQL + params we're about to dry-run. Helps users
    # debug a "cost cap exceeded" by seeing the predicates BigQuery is
    # being asked about — they can paste the rendered query into the
    # console and inspect dryRunStatistics directly.
    logger.info(
        "scan querying INFORMATION_SCHEMA.JOBS_BY_PROJECT — "
        "project=%s region=%s window=%s..%s lookback=%dd dbt_only=%s",
        config.gcp_project_id,
        config.bigquery_region,
        window_start.isoformat(),
        window_end.isoformat(),
        effective_lookback,
        effective_dbt_only,
    )
    logger.info("scan SQL:\n%s", sql)
    logger.info("scan params: %r", params)

    # Dry-run cost estimate — informational only. The audit no longer
    # blocks scans that exceed any client-side cap (removed in v0.0.11
    # — see ScanCostCapExceeded for the historical context). The
    # estimate is logged so users can see what they're about to spend.
    estimate: DryRunEstimate = bq_client.dry_run(sql, params)
    estimated_cost = estimated_cost_usd(estimate.bytes_billed)
    logger.info(
        "scan dry-run estimate: %s billed (%d bytes, ~$%.4f USD); dbt_only=%s",
        _human_bytes(estimate.bytes_billed),
        estimate.bytes_billed,
        estimated_cost,
        effective_dbt_only,
    )

    # ScanRun handling: re-attach the caller-supplied row (created early
    # by ``create_running_scan_run`` so the UI sees it immediately) or
    # fall back to creating one inline for callers that didn't.
    if scan_run is not None:
        # Caller's row was committed in a different session; merge it
        # into this one before mutating the dry-run / window fields.
        scan_run = session.merge(scan_run)
        scan_run.actual_window_start = window_start
        scan_run.actual_window_end = window_end
        scan_run.requested_lookback_days = effective_lookback
        scan_run.dry_run_estimated_bytes = estimate.bytes_billed
        scan_run.estimated_cost_usd = Decimal(str(round(estimated_cost, 4)))
        scan_run.dbt_only_filter = effective_dbt_only
    else:
        scan_run = ScanRun(
            id=ScanRun.new_id(),
            started_at=_now_utc(),
            actual_window_start=window_start,
            actual_window_end=window_end,
            requested_lookback_days=effective_lookback,
            status="running",
            dry_run_estimated_bytes=estimate.bytes_billed,
            estimated_cost_usd=Decimal(str(round(estimated_cost, 4))),
            gcp_project_id=config.gcp_project_id,
            bigquery_region=config.bigquery_region,
            dbt_only_filter=effective_dbt_only,
        )
        session.add(scan_run)
    session.flush()

    # Spec 147 — phase timer for the scan. Wraps each numbered step
    # in a ``with timer.phase(...):`` so the orchestrator can emit one
    # ``scan timing: …`` summary INFO line at the end (Story 3).
    from governor_audit.scan.parallel_fetch import is_failure, run_in_parallel
    from governor_audit.scan.persist_columns import fetch_columns, sync_table_columns
    from governor_audit.scan.persist_storage import fetch_storage, sync_table_storage
    from governor_audit.scan.timing import PhaseTimer

    timer = PhaseTimer()

    # Spec 147 Layer 1 — dispatch the three independent
    # INFORMATION_SCHEMA queries concurrently. They share the same
    # (project, region) but have no data dependencies between them, so
    # network wall-time becomes ``max(jobs, columns, storage)`` instead
    # of ``sum(...)``. Persistence stays sequential after all three
    # return because SQLite is single-writer.
    project_id = config.gcp_project_id
    region = config.bigquery_region

    def _fetch_jobs() -> list[dict]:
        return list(bq_client.query_rows(sql, params))

    with timer.phase("network_fetch"):
        results = run_in_parallel(
            {
                "jobs": _fetch_jobs,
                "columns": lambda: fetch_columns(
                    project_id=project_id, region=region
                ),
                "storage": lambda: fetch_storage(
                    project_id=project_id, region=region
                ),
            }
        )

    # JOBS_BY_PROJECT failure is fatal (matches today's behaviour —
    # the cost scan is the whole point). COLUMNS / STORAGE failures
    # are non-fatal: log + continue with empty data. v0.4.13's
    # belt-and-braces semantics preserved.
    jobs_result = results.get("jobs")
    if is_failure(jobs_result):
        raise jobs_result  # type: ignore[misc]
    jobs_raw: list[dict] = jobs_result  # type: ignore[assignment]
    scan_run.fetched_job_count = len(jobs_raw)

    columns_rows: list[dict] | None = (
        None if is_failure(results.get("columns")) else results.get("columns")
    )
    storage_pair = results.get("storage")
    if is_failure(storage_pair) or storage_pair is None:
        storage_rows: list[dict] | None = None
        billing_models: dict[str, str] = {}
    else:
        storage_rows, billing_models = storage_pair  # type: ignore[misc]

    # Step 4 — derive dbt-attribution and query-hash signals per job.
    # Pure CPU; small constant cost per job.
    with timer.phase("signals"):
        dbt_originated_count = 0
        unique_query_hashes: set[str] = set()
        for job in jobs_raw:
            if is_dbt_originated(job):
                dbt_originated_count += 1
            qh = extract_query_hash(job)
            if qh:
                unique_query_hashes.add(qh)
        # extract_dbt_* are consumed by detection.run_audit_detection —
        # not needed at this layer, just kept on the import surface for
        # callers.
        _ = (extract_dbt_node_id, extract_dbt_invocation_id)

    logger.info(
        "scan: %d jobs fetched, %d dbt-originated, %d unique query hashes",
        len(jobs_raw),
        dbt_originated_count,
        len(unique_query_hashes),
    )

    # Step 5 — persist BigQueryJob rows so the dashboard / detection
    # engine has something to read. Sentinel parent rows are
    # idempotent — they exist after the first scan and are reused.
    from governor_audit.scan.detection import run_audit_detection
    from governor_audit.scan.persistence import persist_jobs
    from governor_audit.scan.sentinels import (
        create_detection_job,
        create_sync_operation,
        ensure_sentinel_config,
        ensure_sentinel_user,
    )

    user_id = ensure_sentinel_user(session)
    config_id = ensure_sentinel_config(
        session,
        project_id=config.gcp_project_id,
        region=config.bigquery_region,
        user_id=user_id,
    )
    sync_id = create_sync_operation(
        session, config_id=config_id, scan_run_id=scan_run.id
    )
    detection_job_id = create_detection_job(
        session,
        config_id=config_id,
        sync_id=sync_id,
        scan_run_id=scan_run.id,
    )

    # Wipe the previous scan's data for this config_id so the dashboard
    # / opportunities surfaces show ONLY what the new scan sees, not the
    # union of every historical scan. ScanRun history is preserved.
    _wipe_previous_scan_state(session, config_id=config_id)

    with timer.phase("persist"):
        fresh_count = persist_jobs(
            session, jobs_raw, config_id=config_id, sync_id=sync_id
        )
        logger.info(
            "scan persistence: %d new bigquery_jobs rows (of %d fetched)",
            fresh_count,
            len(jobs_raw),
        )

        # Step 5b — persist INFORMATION_SCHEMA.COLUMNS rows already
        # fetched in parallel above. Belt-and-braces outer guard:
        # ``sync_table_columns`` catches Exception internally, but we
        # wrap the call again so any uncaught path (session flush,
        # stray ImportError) still can't tank the scan.
        try:
            sync_table_columns(
                session=session,
                config_id=config_id,
                sync_id=sync_id,
                project_id=project_id,
                region=region,
                rows=columns_rows,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Step 5b sync_table_columns raised %s — continuing scan with "
                "no columns metadata; SELECT * expansion will be unavailable",
                exc,
            )

        # Step 5c — persist INFORMATION_SCHEMA.TABLE_STORAGE +
        # SCHEMATA_OPTIONS rows already fetched in parallel above. Same
        # belt-and-braces outer guard as 5b.
        try:
            sync_table_storage(
                session=session,
                config_id=config_id,
                sync_id=sync_id,
                project_id=project_id,
                region=region,
                rows=storage_rows,
                billing_models=billing_models,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Step 5c sync_table_storage raised %s — continuing scan with "
                "no storage metrics; storage_billing_optimization rule will "
                "produce zero candidates and the dashboard storage panel "
                "will be empty",
                exc,
            )

    # Step 6 — run detection rules over every job in scope (including
    # earlier-cached rows so multi-scan windows aggregate properly).
    # Spec 147 Layer 2 — the rule loop runs inside
    # ``patch_sqlglot_during_detection`` so identical query bodies (the
    # common case for recurring dbt rebuilds) parse exactly once across
    # all sqlglot-using rules instead of once per (rule, job).
    from governor_audit.scan.ast_cache import patch_sqlglot_during_detection
    from governor_core.sync.models import BigQueryJob

    jobs_in_scope = (
        session.query(BigQueryJob)
        .filter(BigQueryJob.config_id == config_id)
        .filter(BigQueryJob.creation_time.between(window_start, window_end))
        .all()
    )

    # Detection top-N cap. Detection cost is
    # O(rules × unique_queries × ast_walk); a 30-day enterprise scan
    # easily produces tens of thousands of unique queries and
    # detection runs over an hour without a cap. Slicing to the
    # top-N by total_cost focuses detection on the jobs that
    # actually move the needle on cost, while keeping every cached
    # job persisted so the dashboard's spend KPIs and the
    # cost-drivers chart still cover the full window.
    detection_cap = (
        config.scan_defaults.detection_top_n_jobs
        if config.scan_defaults
        else None
    )
    detection_jobs = jobs_in_scope
    if detection_cap is not None and len(detection_jobs) > detection_cap:
        # Sort desc by total_cost; missing-cost rows sort last (treated
        # as 0). The cap is applied AFTER persistence so dropped jobs
        # are still in the cache — re-running with a higher cap
        # surfaces issues on the previously-skipped tail without
        # re-fetching from BigQuery.
        detection_jobs = sorted(
            jobs_in_scope,
            key=lambda j: float(j.total_cost or 0),
            reverse=True,
        )[:detection_cap]
        logger.info(
            "detection cap applied: %d / %d jobs sent to detection "
            "(top-N by total_cost; configurable via "
            "scan_defaults.detection_top_n_jobs)",
            len(detection_jobs),
            len(jobs_in_scope),
        )

    with timer.phase("detection"), patch_sqlglot_during_detection():
        opportunity_count = run_audit_detection(
            session=session,
            jobs=detection_jobs,
            config_id=config_id,
            detection_job_id=detection_job_id,
            scan_run_id=scan_run.id,
            rule_overrides=dict(config.detection_rule_overrides or {}),
        )

    scan_run.opportunity_count = opportunity_count
    scan_run.actual_bytes_billed = estimate.bytes_billed
    scan_run.actual_cost_usd = Decimal(str(round(estimated_cost, 4)))
    scan_run.status = "succeeded"
    scan_run.completed_at = _now_utc()
    session.commit()

    # Spec 147 Story 3 — single INFO summary line. The timer also
    # emits when run_scan raises mid-pipeline; orchestrator-level
    # callers wrap run_scan in their own try/except and emit there if
    # they prefer, but the success path always logs.
    timer.emit_summary()

    return ScanResult(
        scan_run=scan_run,
        fresh_job_count=fresh_count,
        cached_job_count=len(jobs_raw) - fresh_count,
        dbt_originated_job_count=dbt_originated_count,
        unique_query_hash_count=len(unique_query_hashes),
        opportunity_count=opportunity_count,
        cost_usd=estimated_cost,
        dbt_only_filter=effective_dbt_only,
        lookback_clamp_warning=clamp_warning,
    )


__all__ = [
    "ScanCostCapExceeded",
    "ScanResult",
    "compute_window",
    "create_running_scan_run",
    "resolve_dbt_only_flag",
    "run_scan",
]
