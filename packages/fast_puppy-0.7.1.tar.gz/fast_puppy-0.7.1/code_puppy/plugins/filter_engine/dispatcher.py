"""Filter dispatcher for the filter engine.

Orchestrates classification → strategy lookup → execution → compression.
"""

from __future__ import annotations

import logging
from typing import Any

from code_puppy.plugins.filter_engine.classifier import CommandClassifier
from code_puppy.plugins.filter_engine.registry import get_registry
from code_puppy.plugins.filter_engine.verbosity import get_verbosity
from code_puppy.tools.command_runner import _execute_shell_command

logger = logging.getLogger(__name__)


class FilterDispatcher:
    """Singleton dispatcher that handles the full filter pipeline."""

    _instance: FilterDispatcher | None = None

    def __init__(self) -> None:
        """Initialise the dispatcher with its classifier."""
        self.classifier = CommandClassifier()

    @classmethod
    def get_instance(cls) -> FilterDispatcher:
        """Return the module-level singleton."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    async def handle(
        self,
        context: Any,
        command: str,
        cwd: str | None,
        timeout: int,
    ) -> dict[str, Any] | None:
        """Run the full filter pipeline for a shell command.

        Steps:

        1. Classify the command.
        2. Look up the strategy for the category.
        3. If the strategy is ``None`` or the ``unknown`` passthrough,
           return ``None`` so normal execution proceeds.
        4. Execute the command via :func:`_execute_shell_command`.
        5. Apply the strategy to the resulting :class:`ShellCommandOutput`.
        6. Return ``{"pre_executed": True, "output": filtered_output}``.

        On any strategy exception the error is logged and ``None`` is returned
        so the raw output is preserved as a fallback.

        Args:
            context: pydantic-ai RunContext (unused).
            command: The shell command to execute.
            cwd: Working directory.
            timeout: Timeout in seconds.

        Returns:
            A pre-executed result dict or ``None`` for passthrough.
        """
        category = self.classifier.classify(command)
        registry = get_registry()
        strategy = registry.get_strategy(category)

        if strategy is None:
            return None

        # Passthrough strategies return None
        if category == "unknown":
            return None

        verbosity = get_verbosity()

        # If verbosity is RAW, skip filtering entirely
        if verbosity.value >= 4:
            return None

        try:
            # Execute the command (sub-agents run silently)
            from code_puppy.tools.subagent_context import is_subagent

            silent = is_subagent()
            group_id = f"filter_engine_{id(command)}"

            # _execute_shell_command is async, but we are already in async context
            output = await _execute_shell_command(
                command=command,
                cwd=cwd,
                timeout=timeout,
                group_id=group_id,
                silent=silent,
            )

            # Apply strategy
            filtered = strategy(
                command,
                output.stdout or "",
                output.stderr or "",
                output.exit_code or 0,
                verbosity,
            )

            if filtered is None:
                return None

            return {"pre_executed": True, "output": filtered}
        except Exception:
            logger.exception("FilterDispatcher: strategy failed for %r", command)
            return None
