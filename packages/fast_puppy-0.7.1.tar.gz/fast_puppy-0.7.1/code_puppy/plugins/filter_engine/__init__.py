"""Filter Engine plugin for Code Puppy.

Intercepts shell commands, classifies them, applies compression strategies,
and returns compact results to reduce token usage.
"""

from __future__ import annotations

from code_puppy.plugins.filter_engine.register_callbacks import (
    filter_engine_callback,
)
from code_puppy.plugins.filter_engine.classifier import CommandClassifier
from code_puppy.plugins.filter_engine.dispatcher import FilterDispatcher
from code_puppy.plugins.filter_engine.registry import StrategyRegistry
from code_puppy.plugins.filter_engine.verbosity import VerbosityLevel, get_verbosity

__all__ = [
    "CommandClassifier",
    "FilterDispatcher",
    "StrategyRegistry",
    "VerbosityLevel",
    "filter_engine_callback",
    "get_verbosity",
]
