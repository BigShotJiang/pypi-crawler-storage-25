"""Filter Engine plugin for Code Puppy — callback registration.

Registers a ``run_shell_command`` callback that intercepts shell commands,
classifies them, and applies compression strategies before returning compact
results to the agent.
"""

from __future__ import annotations

from typing import Any

from code_puppy.callbacks import register_callback


async def filter_engine_callback(
    context: Any,
    command: str,
    cwd: str | None = None,
    timeout: int = 60,
) -> dict[str, Any] | None:
    """Run-shell-command callback for the filter engine.

    Args:
        context: The pydantic-ai RunContext (unused).
        command: The shell command to potentially intercept.
        cwd: Working directory for the command.
        timeout: Timeout in seconds.

    Returns:
        ``{"pre_executed": True, "output": ShellCommandOutput(...)}`` when the
        filter engine handles the command, or ``None`` to let normal execution
        proceed.
    """
    from code_puppy.plugins.filter_engine.dispatcher import FilterDispatcher

    dispatcher = FilterDispatcher.get_instance()
    return await dispatcher.handle(context, command, cwd, timeout)


register_callback("run_shell_command", filter_engine_callback)
