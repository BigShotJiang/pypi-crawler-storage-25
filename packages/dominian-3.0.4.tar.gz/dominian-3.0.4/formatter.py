"""
AgentGraph Intelligence - Agent Output Formatter
Produces agent-optimized output for every supported AI agent.
"""

from typing import Dict, Any, List, Optional
from enum import Enum
import json
import re


class OutputFormat(str, Enum):
    """Output format enumeration for CLI commands."""
    JSON = "json"
    TEXT = "text"
    AGENT = "agent"


# ── Write-Back Command Parser ─────────────────────────────────────────────────

WRITEBACK_PATTERNS = [
    (re.compile(r'GRAPH_UPDATE::RENAME::(.+?)->(.+?)(?:\s|$)'),          "rename"),
    (re.compile(r'GRAPH_UPDATE::ADD_NODE::(\w+)\[([^\]]+)\]'),           "add_node"),
    (re.compile(r'GRAPH_UPDATE::DELETE_NODE::(\w+)'),                    "delete_node"),
    (re.compile(r'GRAPH_UPDATE::ADD_EDGE::(.+?)->(.+?)\[([^\]]+)\]'),    "add_edge"),
    (re.compile(r'GRAPH_UPDATE::DELETE_EDGE::(.+?)->(.+?)(?:\s|$)'),     "delete_edge"),
    (re.compile(r'GRAPH_UPDATE::UPDATE_METRIC::(\w+)\[([^\]]+)\]'),      "update_metric"),
    (re.compile(r'GRAPH_UPDATE::MOVE::(\w+)->(.+?)(?:\s|$)'),            "move_node"),
    (re.compile(r'GRAPH_UPDATE::ADD_RELATIONSHIP::(.+?)->(.+?)\[(\w+)\]'), "add_rel"),
]


def parse_writeback_commands(text: str) -> List[Dict]:
    commands = []
    for pattern, cmd_type in WRITEBACK_PATTERNS:
        for m in pattern.finditer(text):
            cmd = {"type": cmd_type, "raw": m.group(0)}
            groups = list(m.groups())

            if cmd_type == "rename":
                cmd.update({"old_name": groups[0].strip(), "new_name": groups[1].strip()})

            elif cmd_type == "add_node":
                parts = {k: v for k, v in
                         (p.split(":") for p in groups[1].split("|") if ":" in p)}
                cmd.update({
                    "name": groups[0], "type": parts.get("type", "function"),
                    "file": parts.get("file", "unknown"), "language": parts.get("lang", "unknown"),
                })

            elif cmd_type == "delete_node":
                cmd.update({"name": groups[0]})

            elif cmd_type in ("add_edge", "add_rel"):
                parts = {k: v for k, v in
                         (p.split(":") for p in groups[2].split("|") if ":" in p)} \
                    if "|" in groups[2] else {}
                cmd.update({
                    "from_name": groups[0].strip(), "to_name": groups[1].strip(),
                    "relationship": parts.get("rel", groups[2].strip()),
                    "weight": float(parts.get("w", 5.0)),
                })

            elif cmd_type == "delete_edge":
                cmd.update({"from_name": groups[0].strip(), "to_name": groups[1].strip()})

            elif cmd_type == "update_metric":
                parts = {k: v for k, v in
                         (p.split(":") for p in groups[1].split("|") if ":" in p)}
                cmd.update({
                    "name": groups[0],
                    "complexity": int(parts["complexity"]) if "complexity" in parts else None,
                    "quality":    float(parts["quality"])  if "quality"    in parts else None,
                })

            elif cmd_type == "move_node":
                cmd.update({"name": groups[0], "new_file": groups[1].strip()})

            commands.append(cmd)
    return commands


def apply_writeback_commands(db, commands: List[Dict]) -> List[Dict]:
    results = []
    for cmd in commands:
        try:
            t = cmd["type"]
            if t == "rename":
                node = db.get_node(cmd["old_name"])
                if node:
                    db.rename_node(cmd["old_name"], cmd["new_name"], node["file"])
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node not found"})

            elif t == "add_node":
                db.upsert_node(name=cmd["name"], type=cmd["type"],
                               file=cmd["file"], language=cmd["language"])
                results.append({"cmd": cmd["raw"], "status": "ok"})

            elif t == "delete_node":
                node = db.get_node(cmd["name"])
                if node:
                    db.delete_node(cmd["name"], node["file"])
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node not found"})

            elif t in ("add_edge", "add_rel"):
                fn = db.get_node(cmd["from_name"])
                tn = db.get_node(cmd["to_name"])
                if fn and tn:
                    db.upsert_edge(from_name=cmd["from_name"], from_file=fn["file"],
                                   to_name=cmd["to_name"], to_file=tn["file"],
                                   relationship=cmd["relationship"], weight=cmd.get("weight", 5.0))
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node(s) not found"})

            elif t == "delete_edge":
                fn = db.get_node(cmd["from_name"])
                tn = db.get_node(cmd["to_name"])
                if fn and tn:
                    db.delete_edge(cmd["from_name"], fn["file"], cmd["to_name"], tn["file"])
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node(s) not found"})

            elif t == "update_metric":
                node = db.get_node(cmd["name"])
                if node:
                    db.update_node_metrics(cmd["name"], node["file"],
                                           complexity=cmd.get("complexity"),
                                           quality=cmd.get("quality"))
                    results.append({"cmd": cmd["raw"], "status": "ok"})
                else:
                    results.append({"cmd": cmd["raw"], "status": "error", "reason": "node not found"})

        except Exception as e:
            results.append({"cmd": cmd.get("raw", "?"), "status": "error", "reason": str(e)})

    return results


# ── Risk / Quality Helpers ────────────────────────────────────────────────────

def _risk_level(node: Dict) -> str:
    cx = node.get("complexity", 0)
    q  = node.get("quality", 100)
    if cx >= 10 or q < 50: return "CRITICAL"
    if cx >= 7  or q < 70: return "HIGH"
    if cx >= 5  or q < 85: return "MEDIUM"
    return "LOW"


def _confidence_tag(node: Dict) -> str:
    return node.get("confidence", "EXTRACTED")


def _node_tag(node: Dict, extended: bool = False) -> str:
    risk  = _risk_level(node)
    conf  = _confidence_tag(node)
    prov  = node.get("provenance", "")
    
    # Add line numbers if available
    line_info = ""
    if node.get("line_start") and node.get("line_end"):
        if node["line_start"] == node["line_end"]:
            line_info = f"|line:{node['line_start']}"
        else:
            line_info = f"|lines:{node['line_start']}-{node['line_end']}"
    
    base  = (
        f"NODE::{node['name']}"
        f"[{node['type']}|{node['file']}"
        f"|risk:{risk}|cx:{node.get('complexity',0)}|q:{node.get('quality',100):.0f}%"
        f"|conf:{conf}{line_info}]"
    )
    if prov:
        base += f"\nPROV::{prov}"
    if extended and node.get("signature"):
        base += f"\nSIG::{node['signature'][:120]}"
    return base


# ── Claude Format ─────────────────────────────────────────────────────────────

def format_for_claude(data: Dict[str, Any], command_type: str = "general") -> str:
    """
    Centralized formatter for all --format agent outputs.
    Handles: impact, deps, stats, communities, search, node, hotspots, cycles, refactor.
    """
    if not data:
        return "NO_RESULTS"

    lines = []

    # --- 1. IMPACT ANALYSIS ---
    if command_type == "impact" or "affected_count" in data:
        risk = data.get("risk_level", "UNKNOWN")
        count = data.get("affected_count", 0)
        lines.append(f"IMPACT: Risk={risk} | Affected={count} nodes")
        lines.append("-" * 40)
        
        nodes = data.get("affected_nodes", [])
        if not nodes:
            lines.append("No direct dependencies found.")
        else:
            for i, node in enumerate(nodes, 1):
                clean_file = node.get("file", "unknown").split("/")[-1]
                name = node.get("name", "unknown")
                n_type = node.get("type", "node")[0].upper()
                line_num = node.get("line_start", "?")
                
                lines.append(f"{i}. [{n_type}] {name} @ {clean_file}:{line_num}")
        
        return "\n".join(lines)

    # --- 2. DEPENDENCIES (Direct/Reverse) ---
    if command_type in ["deps", "dependencies"] or "dependents" in data or "dependencies" in data:
        items = data.get("dependents", data.get("dependencies", []))
        focus = data.get("focus", {})
        
        if focus:
            clean_file = focus.get("file", "").split("/")[-1]
            lines.append(f"FOCUS: {focus.get('name')} [{focus.get('type')}] @ {clean_file}")
        
        lines.append(f"COUNT: {len(items)} items")
        lines.append("-" * 40)
        
        if not items:
            lines.append("None found.")
        else:
            for item in items:
                clean_file = item.get("file", "unknown").split("/")[-1]
                name = item.get("name", "unknown")
                n_type = item.get("type", "node")[0].upper()
                rel = item.get("relationship", "uses")
                
                lines.append(f"- [{n_type}] {name} @ {clean_file} ({rel})")
        
        return "\n".join(lines)

    # --- 3. GRAPH STATS ---
    if command_type == "stats" or ("nodes" in data and "edges" in data):
        lines.append("GRAPH STATS")
        lines.append("-" * 40)
        lines.append(f"Nodes: {data.get('nodes', 0)}")
        lines.append(f"Edges: {data.get('edges', 0)}")
        lines.append(f"Avg Quality: {data.get('avg_quality', 0)}%")
        lines.append(f"Avg Complexity: {data.get('avg_complexity', 0)}")
        
        langs = data.get("languages", {})
        if langs:
            lang_str = ", ".join([f"{k}({v})" for k, v in langs.items()])
            lines.append(f"Languages: {lang_str}")
            
        return "\n".join(lines)

    # --- 4. COMMUNITIES ---
    if command_type == "communities" or "communities" in data:
        comms = data.get("communities", [])
        lines.append(f"COMMUNITIES: {len(comms)} detected")
        lines.append("-" * 40)
        
        for i, comm in enumerate(comms[:15], 1):  # Show top 15 only
            if isinstance(comm, dict):
                cid = comm.get("id", i)
                size = comm.get("size", 0)
                nodes = comm.get("nodes", comm.get("members", []))
                
                lines.append(f"\n{i}. COMMUNITY::{cid} [Size: {size}]")
                
                # Show top 5 nodes in this community with names
                if nodes and isinstance(nodes[0], dict):
                    for node in nodes[:5]:
                        name = node.get("name", "unknown")
                        ntype = node.get("type", "?")
                        file = node.get("file", "").split("/")[-1].split("\\")[-1]
                        lines.append(f"   └─ {name} [{ntype}] @ {file}")
                elif nodes and isinstance(nodes[0], str):
                    # If just names
                    for name in nodes[:5]:
                        lines.append(f"   └─ {name}")
                
                if size > 5:
                    lines.append(f"   ... and {size-5} more")
            else:
                lines.append(f"{i}. Cluster_{i} (Size: {len(comm)})")
                
        if len(comms) > 15:
            lines.append(f"\n... and {len(comms)-15} more communities")
                
        return "\n".join(lines)

    # --- 5. CROSS-COMMUNITY ---
    if command_type == "cross_community" or "cross_community_edges" in data:
        edges = data.get("cross_community_edges", [])
        lines.append(f"CROSS-COMMUNITY: {len(edges)} edges")
        lines.append("-" * 40)
        
        for e in edges:
            lines.append(f"{e.get('from')} -> {e.get('to')}")
            lines.append(f"  Files: {e.get('from_file')} -> {e.get('to_file')}")
                
        return "\n".join(lines)

    # --- 6. SEARCH RESULTS ---
    if command_type == "search" or "results" in data:
        results = data.get("results", [])
        lines.append(f"SEARCH: {len(results)} matches")
        lines.append("-" * 40)
        for r in results:
            clean_file = r.get("file", "").split("/")[-1]
            lines.append(f"NODE::{r.get('name')} @ {clean_file}:{r.get('line_start', '?')}")
        return "\n".join(lines)

    # --- 7. NODE DETAILS ---
    if command_type == "node" or "name" in data:
        node = data.get("node", data)  # Handle both {node: {...}} and direct {...}
        clean_file = node.get("file", "").split("/")[-1]
        name = node.get("name", "Unknown")
        n_type = node.get("type", "unknown")
        line_start = node.get("line_start", "?")
        line_end = node.get("line_end", "?")
        
        lines.append(f"NODE: {name} [{n_type}]")
        lines.append("-" * 40)
        lines.append(f"File: {clean_file}")
        lines.append(f"Lines: {line_start}-{line_end}")
        
        if "complexity" in node:
            lines.append(f"Complexity: {node['complexity']}")
        if "quality" in node:
            lines.append(f"Quality: {node['quality']}%")
            
        return "\n".join(lines)

    # --- 8. HOTSPOTS ---
    if command_type == "hotspots" or "hotspots" in data:
        hotspots = data.get("hotspots", [])
        lines.append(f"HOTSPOTS: {len(hotspots)} found")
        lines.append("-" * 40)
        for i, h in enumerate(hotspots, 1):
            clean_file = h.get("file", "").split("/")[-1]
            name = h.get("name", "unknown")
            cx = h.get("complexity", 0)
            lines.append(f"{i}. {name} @ {clean_file} (complexity: {cx})")
        return "\n".join(lines)

    # --- 9. CYCLES ---
    if command_type == "cycles" or "cycles" in data:
        cycles = data.get("cycles", [])
        lines.append(f"CYCLES: {len(cycles)} found")
        lines.append("-" * 40)
        for i, cycle in enumerate(cycles, 1):
            if isinstance(cycle, list):
                cycle_str = " -> ".join(cycle)
            else:
                cycle_str = str(cycle)
            lines.append(f"{i}. {cycle_str}")
        return "\n".join(lines)

    # --- 10. REFACTOR ---
    if command_type == "refactor":
        lines.append(f"REFACTOR: {data.get('entity', 'Unknown')}")
        lines.append("-" * 40)
        lines.append(f"Safe: {data.get('safe', False)}")
        lines.append(f"Dependents: {data.get('dependents_count', 0)}")
        lines.append(f"Message: {data.get('message', 'N/A')}")
        return "\n".join(lines)

    # --- 11. FILE FUNCTIONS ---
    if command_type == "file_functions":
        file_path = data.get("file", "unknown")
        functions = data.get("functions", [])
        lines.append(f"FUNCTIONS in {file_path}")
        lines.append("-" * 40)
        lines.append(f"Count: {len(functions)}")
        for f in functions:
            lines.append(f"- {f.get('name', 'unknown')} (line {f.get('line_start', '?')})")
        return "\n".join(lines)

    # --- 12. FILE CLASSES ---
    if command_type == "file_classes":
        file_path = data.get("file", "unknown")
        classes = data.get("classes", [])
        lines.append(f"CLASSES in {file_path}")
        lines.append("-" * 40)
        lines.append(f"Count: {len(classes)}")
        for c in classes:
            lines.append(f"- {c.get('name', 'unknown')} (line {c.get('line_start', '?')})")
        return "\n".join(lines)

    # --- FALLBACK: Generic Dense Text ---
    lines.append("RESULT")
    lines.append("-" * 40)
    for key, value in data.items():
        if isinstance(value, list):
            lines.append(f"{key}: {len(value)} items")
            for item in value[:5]:
                if isinstance(item, dict):
                    name = item.get("name", "item")
                    lines.append(f"  - {name}")
                else:
                    lines.append(f"  - {item}")
            if len(value) > 5:
                lines.append(f"  ... and {len(value)-5} more")
        elif isinstance(value, dict):
            lines.append(f"{key}: (object)")
        else:
            lines.append(f"{key}: {value}")
    
    return "\n".join(lines)


# ── Universal Format ──────────────────────────────────────────────────────────

def format_universal(result: Dict) -> str:
    """Compressed format for Codex, Copilot, Cursor, etc. Text risk levels, no emojis."""
    import os
    
    lines  = []
    intent = result.get("intent", "")
    items  = result.get("items", [])
    focus  = result.get("focus")

    lines.append(f"AGRAPH::v1|intent:{intent}|q:{result.get('query','')[:60]}")

    if focus:
        risk = _risk_level(focus)
        conf = _confidence_tag(focus)
        lines.append(
            f"FOCUS::{focus['name']}[{focus['type']}|{focus['file']}"
            f":{focus.get('line_start',0)}-{focus.get('line_end',0)}"
            f"|cx:{focus.get('complexity',0)}|q:{focus.get('quality',100):.0f}"
            f"|risk:{risk}|conf:{conf}]"
        )

    if intent == "dependencies":
        deps_list = []
        for d in items[:20]:
            rel_path = os.path.relpath(d['file'], '.') if d.get('file') else 'unknown'
            line_start = d.get('line_start', '?')
            relationship = d.get('relationship', 'uses')
            deps_list.append(f"{d['name']}[{d.get('type','?')}|{rel_path}:{line_start}|{relationship}]")
        deps_str = ",".join(deps_list)
        lines.append(f"DEPS::{deps_str}" if deps_str else "DEPS::none")

    elif intent == "dependents":
        used_list = []
        for d in items[:20]:
            rel_path = os.path.relpath(d['file'], '.') if d.get('file') else 'unknown'
            line_start = d.get('line_start', '?')
            used_list.append(f"{d['name']}[{d.get('type','?')}|{rel_path}:{line_start}]")
        used_str = ",".join(used_list)
        lines.append(f"USED_BY::{used_str}" if used_str else "USED_BY::none")

    elif intent == "impact":
        risk = result.get("risk_level", "UNKNOWN")
        lines.append(f"IMPACT::risk:{risk}|count:{len(items)}")
        aff_str = ",".join(d["name"] for d in items[:15])
        if aff_str:
            lines.append(f"AFFECTED::{aff_str}")

    elif intent == "cycles":
        if isinstance(items, list) and items and isinstance(items[0], list):
            for cycle in items[:5]:
                lines.append(f"CYCLE::{'->'.join(cycle)}")
        else:
            lines.append("CYCLES::none")

    elif intent == "god_nodes":
        gn_list = []
        for n in items[:10]:
            deg = n.get('degree') or n.get('total_degree', '?')
            rel_path = os.path.relpath(n['file'], '.') if n.get('file') else 'unknown'
            line_start = n.get('line_start', '?')
            gn_list.append(f"{n['name']}[{n.get('type','?')}|{rel_path}:{line_start}|deg:{deg}]")
        gn_str = ",".join(gn_list)
        lines.append(f"GOD_NODES::{gn_str}")

    elif intent == "communities":
        c_str = ",".join(f"c{c['community_id']}:size{c['size']}" for c in items[:10])
        lines.append(f"COMMUNITIES::{c_str}")

    elif intent == "surprising":
        s_str = ",".join(
            f"{e.get('from') or e.get('from_name','?')}->{e.get('to') or e.get('to_name','?')}"
            for e in items[:10]
        )
        lines.append(f"SURPRISING::{s_str}")

    elif intent == "stats":
        stats = result.get("stats", {})
        lines.append(
            f"STATS::n:{stats.get('nodes',0)}|e:{stats.get('edges',0)}"
            f"|avgq:{stats.get('avg_quality',0)}|avgcx:{stats.get('avg_complexity',0)}"
        )

    elif items:
        node_strs = []
        for item in items[:20]:
            if isinstance(item, dict) and "name" in item:
                risk = _risk_level(item)
                conf = _confidence_tag(item)
                
                # Use relative path and line numbers
                rel_path = os.path.relpath(item['file'], '.') if item.get('file') else 'unknown'
                line_start = item.get('line_start', '?')
                line_end = item.get('line_end', '?')
                
                if line_start != '?' and line_end != '?' and line_start != line_end:
                    line_info = f"|{rel_path}:{line_start}-{line_end}"
                else:
                    line_info = f"|{rel_path}:{line_start}"
                
                node_strs.append(
                    f"{item['name']}[{item.get('type','?')}{line_info}|cx:{item.get('complexity',0)}"
                    f"|q:{item.get('quality',100):.0f}|risk:{risk}|conf:{conf}]"
                )
        lines.append(f"ITEMS::{','.join(node_strs)}")

    lines.append(f"META::count:{result.get('count', len(items))}|ms:{result.get('latency_ms',0):.1f}")
    return "\n".join(lines)


def format_json(result: Dict) -> Dict:
    return {
        "query":      result.get("query"),
        "intent":     result.get("intent"),
        "entity":     result.get("entity"),
        "message":    result.get("message"),
        "count":      result.get("count", len(result.get("items", []))),
        "latency_ms": result.get("latency_ms"),
        "focus":      result.get("focus"),
        "items":      result.get("items", []),
        "stats":      result.get("stats"),
        "risk_level": result.get("risk_level"),
    }


def format_for_agent(agent_type: str, result: Dict) -> Any:
    agent_lower = agent_type.lower()
    if "claude" in agent_lower:
        return format_for_claude(result)
    if agent_lower in ("json", "api", "sdk", "raw"):
        return format_json(result)
    return format_universal(result)


AGENT_SIGNATURES = {
    "claude":  ["anthropic", "claude", "claude-code", "claude-sonnet", "claude-opus"],
    "codex":   ["openai", "codex", "gpt-4", "gpt-3", "chatgpt"],
    "copilot": ["copilot", "github-copilot"],
    "cursor":  ["cursor"],
    "codeium": ["codeium"],
    "gemini":  ["gemini", "google", "bard"],
}


def detect_agent_type(user_agent: str = "", api_key_prefix: str = "") -> str:
    text = (user_agent + " " + api_key_prefix).lower()
    for agent, sigs in AGENT_SIGNATURES.items():
        if any(s in text for s in sigs):
            return agent
    return "universal"