"""
Adaptive Parallelization System for AgentGraph
Auto-detects optimal strategy, manages memory, maintains quality

FIXES applied:
  - db.merge_node()        → db.upsert_nodes_batch() / db.upsert_node()
  - db.add_edge()          → db.upsert_edges_batch() / db.upsert_edge()
  - db.remove_file_nodes() → db.clear_file()
  - registry.parse()       → registry.get_parser().parse()  (correct API)
"""
import os
import time
import threading
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
import queue

class Strategy(Enum):
    """Scanning strategies"""
    SEQUENTIAL = "sequential"
    THREADED = "threaded"   # For I/O bound
    PROCESS  = "process"    # For CPU bound (Tree-sitter)
    HYBRID   = "hybrid"     # Auto-detect per batch

@dataclass
class ScanConfig:
    """Configuration for adaptive scanning"""
    parallel_threshold:   int   = 50       # Min files for parallel
    memory_limit_mb:      int   = 512      # Max memory to use
    batch_window_ms:      float = 500.0    # Batch collection window
    max_workers:          int   = None     # Auto-detect if None
    worker_multiplier:    float = 1.5      # CPU count * multiplier
    stream_results:       bool  = True     # Don't buffer all in memory
    chunk_size:           int   = 100      # Process in chunks
    deterministic:        bool  = True     # Same results every time
    transaction_per_chunk: bool = True     # Chunked DB commits

@dataclass
class ScanMetrics:
    """Performance metrics"""
    files_scanned:    int   = 0
    nodes_created:    int   = 0
    edges_created:    int   = 0
    elapsed_ms:       float = 0.0
    strategy_used:    str   = ""
    workers_used:     int   = 0
    memory_peak_mb:   float = 0.0
    chunks_processed: int   = 0


# ── Helper: insert a list of node dicts into the DB ──────────────────────────

def _ingest_nodes(db, nodes: List[Dict]) -> int:
    """Use batch insert if available, fall back to individual upserts."""
    if not nodes:
        return 0
    try:
        return db.upsert_nodes_batch(nodes)
    except Exception:
        for node in nodes:
            try:
                db.upsert_node(
                    name       = node["name"],
                    type       = node["type"],
                    file       = node["file"],
                    language   = node["language"],
                    line_start = node.get("line_start", 0),
                    line_end   = node.get("line_end", 0),
                    complexity = node.get("complexity", 0),
                    quality    = node.get("quality", 100.0),
                    signature  = node.get("signature", ""),
                    docstring  = node.get("docstring", ""),
                    metadata   = node.get("metadata", {}),
                    confidence = node.get("confidence", "EXTRACTED"),
                    provenance = node.get("provenance", "regex_parser"),
                )
            except Exception:
                pass
    return len(nodes)


def _ingest_edges(db, edges: List[Dict]) -> int:
    """Use batch insert if available, fall back to individual upserts."""
    if not edges:
        return 0
    try:
        return db.upsert_edges_batch(edges)
    except Exception:
        for edge in edges:
            try:
                db.upsert_edge(
                    from_name    = edge["from_name"],
                    from_file    = edge["from_file"],
                    to_name      = edge["to_name"],
                    to_file      = edge["to_file"],
                    relationship = edge["relationship"],
                    weight       = edge.get("weight", 1.0),
                    metadata     = edge.get("metadata", {}),
                    confidence   = edge.get("confidence", 1.0),
                    provenance   = edge.get("provenance", "regex_parser"),
                )
            except Exception:
                pass
    return len(edges)


def _parse_one(file_path: str) -> Tuple[List[Dict], List[Dict]]:
    """
    Parse a single file using ParserRegistry.
    Works both in-process and as a picklable worker for ProcessPoolExecutor.
    """
    try:
        from __init__ import ParserRegistry
        registry = ParserRegistry()
        parser = registry.get_parser(file_path)
        if parser is None:
            return [], []
        result = parser.parse(file_path)
        return result.get("nodes", []), result.get("edges", [])
    except Exception as e:
        print(f"[Parse] Error in {file_path}: {e}")
        return [], []


class AdaptiveScanner:
    """
    Intelligent scanner that automatically chooses optimal strategy
    based on file count, system resources, and memory constraints.
    """

    def __init__(self, db, config: Optional[ScanConfig] = None):
        self.db      = db
        self.config  = config or ScanConfig()
        self.metrics = ScanMetrics()
        self._pending_changes = queue.Queue()
        self._batch_timer     = None
        self._lock            = threading.Lock()

    def scan(self, path: str, force_strategy: Optional[Strategy] = None) -> Dict[str, Any]:
        start_time = time.perf_counter()

        files = self._collect_files(path)
        if not files:
            return {"error": "No files found"}

        strategy = force_strategy or self._select_strategy(files)
        print(f"[AdaptiveScanner] {len(files)} files → Using {strategy.value}")

        if strategy == Strategy.SEQUENTIAL:
            result = self._scan_sequential(files)
        elif strategy == Strategy.THREADED:
            result = self._scan_threaded(files)
        elif strategy == Strategy.PROCESS:
            result = self._scan_process(files)
        else:
            result = self._scan_hybrid(files)

        elapsed = (time.perf_counter() - start_time) * 1000
        self.metrics.elapsed_ms    = elapsed
        self.metrics.strategy_used = strategy.value
        self.metrics.files_scanned = len(files)

        return {
            "success":      True,
            "files_scanned": len(files),
            "strategy":     strategy.value,
            "elapsed_ms":   elapsed,
            "metrics":      self.metrics,
            **result,
        }

    # ── Strategy selection ────────────────────────────────────────

    def _select_strategy(self, files: List[str]) -> Strategy:
        file_count = len(files)

        if file_count < self.config.parallel_threshold:
            return Strategy.SEQUENTIAL

        try:
            import psutil
            available_mb    = psutil.virtual_memory().available / 1024 / 1024
            estimated_memory = self._estimate_memory(file_count)
            if estimated_memory > available_mb * 0.5:
                print(f"[AdaptiveScanner] Memory constrained, using streaming")
                return Strategy.HYBRID
        except ImportError:
            pass

        cpu_bound_ratio = self._estimate_cpu_bound(files)

        if cpu_bound_ratio > 0.7:
            return Strategy.PROCESS
        elif file_count > 500:
            return Strategy.HYBRID
        else:
            return Strategy.THREADED

    def _estimate_memory(self, file_count: int) -> float:
        avg_file_size  = 50
        nodes_per_file = 20
        edge_per_file  = 30
        memory_per_file = (avg_file_size + nodes_per_file * 200 + edge_per_file * 150) / 1024
        workers = self._get_optimal_workers(file_count)
        return memory_per_file * workers * 2

    def _estimate_cpu_bound(self, files: List[str]) -> float:
        cpu_ext = {'.py', '.js', '.ts', '.java', '.go', '.rs', '.cpp', '.c'}
        cpu_files = sum(1 for f in files if any(f.endswith(ext) for ext in cpu_ext))
        return cpu_files / len(files) if files else 0

    def _get_optimal_workers(self, file_count: int) -> int:
        if self.config.max_workers:
            return self.config.max_workers
        cpu_count = multiprocessing.cpu_count()
        optimal   = int(cpu_count * self.config.worker_multiplier)
        return min(optimal, file_count, 32)

    # ── Scan strategies ───────────────────────────────────────────

    def _scan_sequential(self, files: List[str]) -> Dict[str, Any]:
        all_nodes, all_edges = [], []

        for i, file_path in enumerate(files):
            nodes, edges = _parse_one(file_path)
            all_nodes.extend(nodes)
            all_edges.extend(edges)
            if (i + 1) % 50 == 0:
                print(f"[Sequential] Processed {i+1}/{len(files)} files...")

        with self.db.transaction():
            _ingest_nodes(self.db, all_nodes)
            _ingest_edges(self.db, all_edges)

        return {"nodes_created": len(all_nodes), "edges_created": len(all_edges)}

    def _scan_threaded(self, files: List[str]) -> Dict[str, Any]:
        workers = self._get_optimal_workers(len(files))
        all_nodes, all_edges = [], []

        print(f"[Threaded] Using {workers} workers for {len(files)} files")

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(_parse_one, f): f for f in files}
            for i, future in enumerate(futures):
                try:
                    nodes, edges = future.result(timeout=30)
                    all_nodes.extend(nodes)
                    all_edges.extend(edges)
                    if (i + 1) % 50 == 0:
                        print(f"[Threaded] Completed {i+1}/{len(files)}...")
                except Exception as e:
                    print(f"[Threaded] Error: {e}")

        with self.db.transaction():
            _ingest_nodes(self.db, all_nodes)
            _ingest_edges(self.db, all_edges)

        self.metrics.workers_used = workers
        return {"nodes_created": len(all_nodes), "edges_created": len(all_edges)}

    def _scan_process(self, files: List[str]) -> Dict[str, Any]:
        workers = min(self._get_optimal_workers(len(files)), 8)
        print(f"[Process] Using {workers} processes for {len(files)} files")

        with ProcessPoolExecutor(max_workers=workers) as executor:
            results = list(executor.map(_parse_one, files))  # _parse_one is now module-level → picklable

        all_nodes, all_edges = [], []
        for nodes, edges in results:
            all_nodes.extend(nodes)
            all_edges.extend(edges)

        with self.db.transaction():
            _ingest_nodes(self.db, all_nodes)
            _ingest_edges(self.db, all_edges)

        self.metrics.workers_used = workers
        return {"nodes_created": len(all_nodes), "edges_created": len(all_edges)}

    def _scan_hybrid(self, files: List[str]) -> Dict[str, Any]:
        chunk_size  = self.config.chunk_size
        chunks      = [files[i:i+chunk_size] for i in range(0, len(files), chunk_size)]
        total_nodes = 0
        total_edges = 0
        workers     = self._get_optimal_workers(len(files))

        print(f"[Hybrid] {len(files)} files → {len(chunks)} chunks of {chunk_size}")

        for chunk_idx, chunk in enumerate(chunks):
            print(f"[Hybrid] Chunk {chunk_idx+1}/{len(chunks)} ({len(chunk)} files)...")

            with ThreadPoolExecutor(max_workers=min(workers, len(chunk))) as executor:
                futures     = [executor.submit(_parse_one, f) for f in chunk]
                chunk_nodes = []
                chunk_edges = []
                for future in futures:
                    try:
                        nodes, edges = future.result()
                        chunk_nodes.extend(nodes)
                        chunk_edges.extend(edges)
                    except Exception as e:
                        print(f"[Hybrid] Parse error: {e}")

            with self.db.transaction():
                _ingest_nodes(self.db, chunk_nodes)
                _ingest_edges(self.db, chunk_edges)

            total_nodes += len(chunk_nodes)
            total_edges += len(chunk_edges)
            self.metrics.chunks_processed += 1

            if self.config.stream_results:
                del chunk_nodes, chunk_edges

        return {"nodes_created": total_nodes, "edges_created": total_edges}

    # ── File collection ───────────────────────────────────────────

    def _collect_files(self, path: str) -> List[str]:
        files      = []
        extensions = {'.py', '.js', '.ts', '.java', '.go', '.rs', '.cpp', '.c', '.h', '.tsx', '.jsx'}
        skip_dirs  = {'__pycache__', '.git', 'node_modules', 'venv', '.venv', 'dist', 'build', '.tox', '.pytest_cache'}

        for root, dirs, filenames in os.walk(path):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for f in filenames:
                if any(f.endswith(ext) for ext in extensions):
                    files.append(os.path.join(root, f))
        return files

    # ── Live update (file watcher integration) ────────────────────

    def on_file_change(self, file_path: str):
        with self._lock:
            self._pending_changes.put(file_path)
            if self._batch_timer:
                self._batch_timer.cancel()
            self._batch_timer = threading.Timer(
                self.config.batch_window_ms / 1000,
                self._process_pending_changes,
            )
            self._batch_timer.start()

    def _process_pending_changes(self):
        with self._lock:
            files = []
            while not self._pending_changes.empty():
                try:
                    files.append(self._pending_changes.get_nowait())
                except queue.Empty:
                    break
            if not files:
                return
            files = list(set(files))

        print(f"[LiveUpdate] Processing {len(files)} changed files...")

        for file_path in files:
            if os.path.exists(file_path):
                nodes, edges = _parse_one(file_path)
                with self.db.transaction():
                    self.db.clear_file(file_path)   # ← was remove_file_nodes (fixed)
                    _ingest_nodes(self.db, nodes)
                    _ingest_edges(self.db, edges)

        print(f"[LiveUpdate] Updated {len(files)} files")