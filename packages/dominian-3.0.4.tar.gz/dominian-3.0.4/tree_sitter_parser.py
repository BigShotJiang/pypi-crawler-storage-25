"""
AgentGraph Intelligence - Tree-sitter Parser
Primary parser for all 7 supported languages.
Falls back transparently to regex parsers when tree-sitter is unavailable.

Architecture (Graphify-inspired two-pass):
  Pass 1 — ASTWalker.walk()          → structural nodes + edges (EXTRACTED)
  Pass 2 — extract_call_edges()      → call-graph edges (INFERRED, 0.7 confidence)
  Pass 3 — regex enrichment          → fills gaps tree-sitter misses
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Try to import tree-sitter. All errors are soft-caught so the system
# always works even when the packages are missing.
# ─────────────────────────────────────────────────────────────────────────────

_TS_AVAILABLE = False
_TS_VERSION   = None

try:
    import tree_sitter as _ts_mod
    _TS_VERSION   = getattr(_ts_mod, "__version__", "unknown")
    _TS_AVAILABLE = True
except ImportError:
    pass


def _load_ts_language(config):
    """
    Load a tree-sitter Language object for the given LanguageConfig.
    Returns (parser, language) or (None, None).

    Handles all known API variants:
      - tree-sitter >=0.21: module.language() -> capsule -> Language(capsule)
      - tree-sitter 0.20.x: module.Language() directly
      - tree-sitter-typescript: exposes language_typescript() and language_tsx()
        (not a generic language() function)
    """
    if not _TS_AVAILABLE:
        return None, None
    try:
        import importlib
        import tree_sitter

        mod = importlib.import_module(config.module)

        lang_capsule = None

        # ── tree-sitter-typescript special case ──────────────────
        # tree-sitter-typescript exposes language_typescript() and language_tsx()
        # instead of the standard language(). TSX grammar is a strict superset
        # of TypeScript, so we use language_tsx() for both .ts and .tsx files.
        if config.module == "tree_sitter_typescript":
            if hasattr(mod, "language_tsx"):
                lang_capsule = mod.language_tsx()
            elif hasattr(mod, "language_typescript"):
                lang_capsule = mod.language_typescript()
            elif hasattr(mod, "language"):
                lang_capsule = mod.language()

        # ── Standard API ≥0.21: module.language() -> capsule ────
        elif hasattr(mod, "language"):
            lang_capsule = mod.language()

        # ── Legacy 0.20.x: module.Language() ─────────────────────
        elif hasattr(mod, "Language"):
            language = mod.Language()
            parser = tree_sitter.Parser()
            # 0.20.x: parser.set_language(language)
            if hasattr(parser, "set_language"):
                parser.set_language(language)
            else:
                parser.language = language
            return parser, language

        else:
            logger.debug("No language() or Language() found in %s", config.module)
            return None, None

        if lang_capsule is None:
            return None, None

        language = tree_sitter.Language(lang_capsule)
        parser   = tree_sitter.Parser()
        # >=0.22: Parser() takes language as constructor arg or .language property
        if hasattr(parser, "set_language"):
            parser.set_language(language)
        else:
            try:
                parser.language = language
            except Exception:
                # >=0.22 API: Parser(language)
                parser = tree_sitter.Parser(language)

        return parser, language

    except Exception as e:
        logger.debug("tree-sitter language load failed for %s: %s", config.module, e)
        return None, None


# ─────────────────────────────────────────────────────────────────────────────
# Language-config + walker imports (always available — pure Python)
# ─────────────────────────────────────────────────────────────────────────────

from tree_sitter_configs import (
    LanguageConfig, get_config,
    PYTHON_CONFIG, JAVASCRIPT_CONFIG, TYPESCRIPT_CONFIG,
    JAVA_CONFIG, GO_CONFIG, RUST_CONFIG, CPP_CONFIG,
)
from ast_walker import ASTWalker, extract_call_edges


# ─────────────────────────────────────────────────────────────────────────────
# Regex fallback parsers (always available)
# ─────────────────────────────────────────────────────────────────────────────

def _get_regex_parser(file_path: str):
    """Return an appropriate regex parser instance for the file, or None."""
    suffix = Path(file_path).suffix.lower()
    try:
        from python_parser     import PythonParser
        from javascript_parser import JavaScriptParser
        from other_parsers     import JavaParser, GoParser, RustParser, CppParser

        REGEX_MAP: Dict[str, Any] = {}
        for cls in [PythonParser, JavaScriptParser, JavaParser, GoParser, RustParser, CppParser]:
            inst = cls()
            for ext in inst.EXTENSIONS:
                REGEX_MAP[ext] = inst

        return REGEX_MAP.get(suffix)
    except Exception as e:
        logger.debug("Regex parser import failed: %s", e)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Main parser
# ─────────────────────────────────────────────────────────────────────────────

class TreeSitterParser:
    """
    Unified parser for a single language.
    Instantiate one per language; ParserRegistry caches instances.

    parse(file_path) → {"nodes": [...], "edges": [...], "errors": [...]}
    """

    def __init__(self, config: LanguageConfig):
        self.config   = config
        self.LANGUAGE = config.name
        self.EXTENSIONS = config.extensions

        self._ts_parser   = None
        self._ts_language = None
        self._ts_ready    = False
        self._init_done   = False

    def _lazy_init(self):
        """Defer tree-sitter initialisation to first parse call."""
        if self._init_done:
            return
        self._init_done = True
        self._ts_parser, self._ts_language = _load_ts_language(self.config)
        self._ts_ready = self._ts_parser is not None
        if self._ts_ready:
            logger.info("tree-sitter ready for %s (v%s)", self.config.name, _TS_VERSION)
        else:
            logger.info("tree-sitter unavailable for %s — using regex fallback", self.config.name)

    # ── Public API (matches existing parser interface) ────────────

    def parse(self, file_path: str) -> Dict[str, Any]:
        self._lazy_init()

        if self._ts_ready:
            result = self._parse_ts(file_path)
            if len(result.get("nodes", [])) <= 1:
                result = self._parse_regex(file_path)
                result["_parser"] = "regex_fallback"
            else:
                result["_parser"] = "tree_sitter"
        else:
            result = self._parse_regex(file_path)
            result["_parser"] = "regex_fallback"

        # Guarantee confidence + provenance on every node/edge
        self._enrich_result(result)
        return result

    @staticmethod
    def _enrich_result(result: Dict[str, Any]) -> None:
        """Stamp confidence and provenance on every node/edge that lacks them.
        Regex parsers do not emit these fields; tree-sitter walker always does.
        """
        parser_tag = result.get("_parser", "regex_fallback")
        node_prov  = "tree_sitter" if parser_tag == "tree_sitter" else "regex_parser"

        for node in result.get("nodes", []):
            node.setdefault("confidence", "EXTRACTED")
            node.setdefault("provenance", node_prov)

        for edge in result.get("edges", []):
            inferred = edge.get("provenance") == "tree_sitter_inferred"
            edge.setdefault("confidence", 0.7 if inferred else 1.0)
            edge.setdefault("provenance", "tree_sitter_inferred" if inferred else node_prov)

    # ── Tree-sitter path ─────────────────────────────────────────

    def _parse_ts(self, file_path: str) -> Dict[str, Any]:
        path   = Path(file_path)
        errors = []

        try:
            source_bytes = path.read_bytes()
        except Exception as e:
            return {"nodes": [], "edges": [], "errors": [str(e)]}

        try:
            tree = self._ts_parser.parse(source_bytes)
        except Exception as e:
            errors.append(f"tree-sitter parse error: {e}")
            return {"nodes": [], "edges": [], "errors": errors}

        # Detect partial parse errors
        if hasattr(tree, "root_node") and tree.root_node.has_error:
            errors.append("tree-sitter: parse errors in file (partial tree used)")

        rel_file = str(path)
        walker   = ASTWalker(self.config, rel_file, source_bytes)

        try:
            nodes, edges = walker.walk(tree.root_node)
        except Exception as e:
            errors.append(f"AST walk error: {e}")
            logger.exception("ASTWalker failed on %s", file_path)
            return {"nodes": [], "edges": [], "errors": errors}

        # Pass 2: call-graph (only if Language object available)
        if self._ts_language is not None:
            nodes_by_name = {n["name"]: n for n in nodes}
            try:
                call_edges = extract_call_edges(
                    self._ts_language,
                    tree.root_node,
                    source_bytes,
                    self.config,
                    nodes_by_name,
                    rel_file,
                )
                edges.extend(call_edges)
            except Exception as e:
                logger.debug("Call-graph pass failed for %s: %s", file_path, e)

        return {"nodes": nodes, "edges": edges, "errors": errors}

    # ── Regex fallback path ───────────────────────────────────────

    def _parse_regex(self, file_path: str) -> Dict[str, Any]:
        parser = _get_regex_parser(file_path)
        if parser:
            try:
                return parser.parse(file_path)
            except Exception as e:
                return {"nodes": [], "edges": [], "errors": [str(e)]}
        return {"nodes": [], "edges": [], "errors": ["no parser available"]}

    # ── Diagnostics ───────────────────────────────────────────────

    @property
    def using_tree_sitter(self) -> bool:
        self._lazy_init()
        return self._ts_ready

    def status(self) -> Dict[str, Any]:
        self._lazy_init()
        return {
            "language":    self.config.name,
            "extensions":  sorted(self.config.extensions),
            "tree_sitter": self._ts_ready,
            "ts_version":  _TS_VERSION,
            "module":      self.config.module,
        }


# ─────────────────────────────────────────────────────────────────────────────
# One singleton per language — created lazily by TreeSitterRegistry
# ─────────────────────────────────────────────────────────────────────────────

class TreeSitterRegistry:
    """
    Drop-in replacement / enhancement for ParserRegistry.
    Prefers TreeSitterParser; falls back to regex parsers automatically.
    """

    def __init__(self):
        self._parsers: Dict[str, TreeSitterParser] = {}
        self._init_all()

    def _init_all(self):
        for cfg in [
            PYTHON_CONFIG, JAVASCRIPT_CONFIG, TYPESCRIPT_CONFIG,
            JAVA_CONFIG, GO_CONFIG, RUST_CONFIG, CPP_CONFIG,
        ]:
            parser = TreeSitterParser(cfg)
            for ext in cfg.extensions:
                self._parsers[ext] = parser

    def get_parser(self, file_path: str) -> Optional[TreeSitterParser]:
        return self._parsers.get(Path(file_path).suffix.lower())

    def supported_extensions(self) -> List[str]:
        return sorted(self._parsers.keys())

    def is_supported(self, file_path: str) -> bool:
        return self.get_parser(file_path) is not None

    def status_report(self) -> List[Dict]:
        seen = set()
        report = []
        for parser in self._parsers.values():
            if id(parser) in seen:
                continue
            seen.add(id(parser))
            report.append(parser.status())
        return report


# ─────────────────────────────────────────────────────────────────────────────
# Convenience — used in __init__.py ParserRegistry upgrade path
# ─────────────────────────────────────────────────────────────────────────────

_GLOBAL_REGISTRY: Optional[TreeSitterRegistry] = None


def get_global_registry() -> TreeSitterRegistry:
    global _GLOBAL_REGISTRY
    if _GLOBAL_REGISTRY is None:
        _GLOBAL_REGISTRY = TreeSitterRegistry()
    return _GLOBAL_REGISTRY