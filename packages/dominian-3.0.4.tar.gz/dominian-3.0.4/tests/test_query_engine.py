from pathlib import Path
from uuid import uuid4

from database import GraphDatabase
from engine import QueryEngine


def _build_test_db(db_path):
    db = GraphDatabase(str(db_path))

    db.upsert_node(
        name="UserService",
        type="class",
        file="services/user.py",
        language="python",
        complexity=9,
        quality=72.0,
    )
    db.upsert_node(
        name="UserRepository",
        type="class",
        file="repositories/user.py",
        language="python",
        complexity=5,
        quality=84.0,
    )
    db.upsert_node(
        name="Logger",
        type="class",
        file="core/log.py",
        language="python",
        complexity=2,
        quality=95.0,
    )

    db.upsert_edge(
        from_name="UserService",
        from_file="services/user.py",
        to_name="UserRepository",
        to_file="repositories/user.py",
        relationship="depends_on",
    )
    db.upsert_edge(
        from_name="UserService",
        from_file="services/user.py",
        to_name="Logger",
        to_file="core/log.py",
        relationship="depends_on",
    )

    return db


def _make_workspace_db_path():
    tests_dir = Path(__file__).resolve().parent
    return tests_dir / f"query-engine-{uuid4().hex}.db"


def test_hotspots_query_returns_structured_result():
    db_path = _make_workspace_db_path()
    try:
        db = _build_test_db(db_path)
        result = QueryEngine(db).query("show hotspots")

        assert result["intent"] == "hotspots"
        assert result["count"] >= 1
        assert result["items"][0]["name"] == "UserService"
        assert "message" in result
    finally:
        if "db" in locals():
            db.close()
        db_path.unlink(missing_ok=True)


def test_refactoring_safety_query_does_not_crash():
    db_path = _make_workspace_db_path()
    try:
        db = _build_test_db(db_path)
        result = QueryEngine(db).query("safe to refactor UserService")

        assert result["intent"] == "refactoring_safety"
        assert result["entity"] == "UserService"
        assert "message" in result
        assert "count" in result
    finally:
        if "db" in locals():
            db.close()
        db_path.unlink(missing_ok=True)


def test_specific_community_query_beats_generic_community_intent():
    db_path = _make_workspace_db_path()
    try:
        db = _build_test_db(db_path)
        result = QueryEngine(db).query("show nodes in community 0")

        assert result["intent"] == "community_nodes"
    finally:
        if "db" in locals():
            db.close()
        db_path.unlink(missing_ok=True)


def test_cross_community_query_matches_specific_intent():
    db_path = _make_workspace_db_path()
    try:
        db = _build_test_db(db_path)
        result = QueryEngine(db).query("find cross-community edges")

        assert result["intent"] == "cross_community_edges"
    finally:
        if "db" in locals():
            db.close()
        db_path.unlink(missing_ok=True)
