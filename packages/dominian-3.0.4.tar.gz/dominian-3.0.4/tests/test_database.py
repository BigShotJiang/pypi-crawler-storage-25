"""SUPERPOWERS: Database CRUD and Graph Operations Tests"""
import pytest
import tempfile
from pathlib import Path
from database import GraphDatabase


@pytest.fixture
def temp_db():
    """Create temporary database for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        db = GraphDatabase(str(db_path))
        yield db
        db.close()


class TestDatabaseCRUD:
    """SUPERPOWERS Requirement: Verify data persistence"""
    
    def test_upsert_node_and_retrieve(self, temp_db):
        """Test creating and getting a node."""
        temp_db.upsert_node(
            name="TestClass",
            type="class",
            file="test.py",
            language="python",
            complexity=5,
            quality=80.0
        )
        
        node = temp_db.get_node("TestClass")
        assert node is not None
        assert node["name"] == "TestClass"
        assert node["type"] == "class"
        assert node["complexity"] == 5
    
    def test_upsert_edge_and_traversal(self, temp_db):
        """Test creating edge and querying dependencies."""
        # Create nodes
        temp_db.upsert_node("UserService", "class", "services.py", "python")
        temp_db.upsert_node("UserRepo", "class", "repo.py", "python")
        
        # Create edge
        temp_db.upsert_edge(
            from_name="UserService",
            from_file="services.py",
            to_name="UserRepo",
            to_file="repo.py",
            relationship="depends_on"
        )
        
        # Verify edge exists (get_dependencies returns list of edge dicts)
        deps = temp_db.get_dependencies("UserService", "services.py")
        assert len(deps) >= 1
        # Check that UserRepo is in the dependencies
        dep_names = [d.get("to_name", d.get("name", "")) for d in deps]
        assert "UserRepo" in dep_names
    
    def test_delete_node_cascades(self, temp_db):
        """Test that deleting node removes its edges."""
        temp_db.upsert_node("A", "class", "a.py", "python")
        temp_db.upsert_node("B", "class", "b.py", "python")
        temp_db.upsert_edge("A", "a.py", "B", "b.py", "uses")
        
        # Delete A
        temp_db.delete_node("A", "a.py")
        
        # Verify A is gone
        assert temp_db.get_node("A") is None
        
        # Verify edge is gone (B should have no dependents)
        dependents = temp_db.get_dependents("B")
        assert len(dependents) == 0


class TestGraphAnalytics:
    """SUPERPOWERS Requirement: Verify graph analysis correctness"""
    
    def test_find_simple_cycle(self, temp_db):
        """Test cycle detection A -> B -> C -> A."""
        # Create cycle
        for name in ["A", "B", "C"]:
            temp_db.upsert_node(name, "class", f"{name.lower()}.py", "python")
        
        temp_db.upsert_edge("A", "a.py", "B", "b.py", "uses")
        temp_db.upsert_edge("B", "b.py", "C", "c.py", "uses")
        temp_db.upsert_edge("C", "c.py", "A", "a.py", "uses")
        
        cycles = temp_db.find_cycles()
        assert len(cycles) >= 1
    
    def test_get_impact_blast_radius(self, temp_db):
        """Test impact analysis returns correct affected nodes."""
        # Create chain: A -> B -> C -> D
        for name in ["A", "B", "C", "D"]:
            temp_db.upsert_node(name, "class", f"{name.lower()}.py", "python")
        
        temp_db.upsert_edge("A", "a.py", "B", "b.py", "uses")
        temp_db.upsert_edge("B", "b.py", "C", "c.py", "uses")
        temp_db.upsert_edge("C", "c.py", "D", "d.py", "uses")
        
        # Change B should affect A (dependent)
        # Note: get_impact returns affected dependents (things that depend on B)
        impact = temp_db.get_impact("B", "b.py")
        affected_nodes = impact.get("affected_nodes", [])
        affected_names = [n["name"] for n in affected_nodes]
        
        # A depends on B, so changing B affects A
        assert "A" in affected_names  # Dependent
    
    def test_stats_calculation(self, temp_db):
        """Test database stats are accurate."""
        # Add nodes with varying complexity
        temp_db.upsert_node("Simple", "function", "simple.py", "python", complexity=2, quality=90.0)
        temp_db.upsert_node("Complex", "function", "complex.py", "python", complexity=15, quality=50.0)
        
        stats = temp_db.get_stats()
        
        assert stats["nodes"] == 2
        assert stats["avg_complexity"] == 8.5
        assert stats["avg_quality"] == 70.0
