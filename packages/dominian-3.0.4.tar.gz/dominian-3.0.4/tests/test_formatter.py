"""SUPERPOWERS: Output Format Tests for Agent Consumption"""
import pytest
from formatter import format_for_claude, format_universal, format_json, _risk_level


class TestRiskLevelCalculation:
    """SUPERPOWERS Requirement: Verify risk assessment logic"""
    
    def test_critical_risk_high_complexity(self):
        """Complexity >= 10 should be CRITICAL."""
        node = {"complexity": 15, "quality": 100}
        assert _risk_level(node) == "CRITICAL"
    
    def test_critical_risk_low_quality(self):
        """Quality < 50 should be CRITICAL."""
        node = {"complexity": 5, "quality": 40}
        assert _risk_level(node) == "CRITICAL"
    
    def test_high_risk_complexity(self):
        """Complexity >= 7 should be HIGH."""
        node = {"complexity": 8, "quality": 80}
        assert _risk_level(node) == "HIGH"
    
    def test_low_risk_healthy(self):
        """Low complexity + high quality = LOW risk."""
        node = {"complexity": 3, "quality": 95}
        assert _risk_level(node) == "LOW"


class TestClaudeFormat:
    """SUPERPOWERS Requirement: Verify Claude-optimized output"""
    
    def test_format_for_claude_structure(self):
        """Claude format has required sections."""
        result = {
            "intent": "dependencies",
            "message": "Found 3 dependencies",
            "items": [
                {"name": "UserRepo", "type": "class", "weight": 5, "relationship": "uses", "confidence": 1.0}
            ],
            "focus": {"name": "UserService", "type": "class", "file": "service.py", "complexity": 5, "quality": 85.0},
            "latency_ms": 12.5
        }
        
        output = format_for_claude(result)
        
        assert "# SUMMARY" in output
        assert "# FOCUS NODE" in output
        assert "NODE::UserService" in output
        assert "# DEPENDENCIES" in output
        assert "DEPS::UserRepo" in output
        assert "LATENCY::12.5" in output  # Matches 12.50ms format
    
    def test_format_for_claude_impact(self):
        """Impact analysis shows risk level."""
        result = {
            "intent": "impact",
            "message": "Impact analysis complete",
            "items": [{"name": "AuthController", "type": "class", "file": "auth.py"}],
            "risk_level": "HIGH",
            "focus": {"name": "UserService", "type": "class", "file": "service.py", "complexity": 5, "quality": 85.0},
            "latency_ms": 25.0
        }
        
        output = format_for_claude(result)
        
        assert "RISK:HIGH" in output
        assert "AFFECTED::AuthController" in output
    
    def test_format_for_claude_with_stats(self):
        """Stats section when stats present."""
        result = {
            "intent": "stats",
            "message": "Stats retrieved",
            "stats": {
                "nodes": 100,
                "edges": 250,
                "avg_quality": 75.5,
                "avg_complexity": 6.2
            },
            "latency_ms": 5.0
        }
        
        output = format_for_claude(result)
        
        assert "STATS::nodes:100" in output
        assert "avg_quality:75.5%" in output


class TestUniversalFormat:
    """SUPERPOWERS Requirement: Verify compressed format for other agents"""
    
    def test_format_universal_compression(self):
        """Universal format is single-line compressed."""
        result = {
            "intent": "dependencies",
            "items": [
                {"name": "Repo", "type": "class", "weight": 5, "relationship": "uses", "confidence": 0.95}
            ],
            "focus": {"name": "Service", "type": "class", "file": "svc.py", "line_start": 10, "line_end": 50, "complexity": 5, "quality": 85.0},
            "latency_ms": 8.0
        }
        
        output = format_universal(result)
        
        assert output.startswith("AGRAPH::v1")
        assert "FOCUS::Service" in output
        assert "DEPS::" in output
        assert "META::" in output
    
    def test_format_universal_no_emojis(self):
        """Universal format uses text only."""
        result = {"intent": "stats", "items": [], "latency_ms": 5.0}
        output = format_universal(result)
        
        # Verify no markdown, no emojis
        assert "# " not in output  # No markdown headers
        assert output.count("::") >= 3  # Tag format used


class TestJSONFormat:
    """SUPERPOWERS Requirement: Verify API-compatible JSON"""
    
    def test_format_json_schema(self):
        """JSON format has all required fields."""
        result = {
            "query": "test query",
            "intent": "test",
            "entity": "TestClass",
            "message": "Test message",
            "items": [{"name": "Item1"}],
            "focus": {"name": "Focus"},
            "stats": {"nodes": 10},
            "risk_level": "LOW",
            "latency_ms": 5.0
        }
        
        output = format_json(result)
        
        assert "query" in output
        assert "intent" in output
        assert "items" in output
        assert "latency_ms" in output
        assert isinstance(output["count"], int)
