﻿# Dominian v3.0.4

> **Dominian is a local code-intelligence backend for agents: scan once, query dependencies and architecture cheaply.**

---

## 📋 Project Overview

**Dominian** is a local code graph and query layer for AI coding workflows. It gives agents structured answers for dependency, impact, hotspot, and architecture questions. It reduces repeated context stuffing by turning codebases into a queryable graph.

**Works as infrastructure:** CLI, Python API, HTTP API, and MCP. **Optimized for repeated repo questions** over the same codebase. **Local-first** and useful for private codebases.

**Current Version:** 3.0.4
**Primary Language:** Python 3.8+
**License:** MIT

### Core Architecture

```
Source Code (Python/JS/Go/Rust/Java/C/C++)
         ↓
Tree-sitter Parsers (per-language parsers)
         ↓
AST Walker (extracts entities and relationships)
         ↓
GraphDatabase (SQLite with networkx)
         ↓
QueryEngine (direct command mapping)
         ↓
CLI (strict structure) / MCP Server / Agent API
```

### Key Features
- **Strict CLI Structure**: `dominian <group> <action> [target] [options]`
- **Agent-Optimized Output**: `--format agent` for structured AI-friendly results
- **Multi-language support**: 7 languages fully supported: Python, JavaScript/TypeScript, Java, Go, Rust, C++, with more via Tree-sitter
- **Community detection**: Automatic module grouping and architectural analysis
- **Fast analysis**: Significantly faster than manual code review
- **Universal Access**: Works from any directory, no Python dependencies for agents

---

## 🎯 When to Use Dominian

### **For Developers**
- **Code Reviews**: "What depends on this function I'm changing?"
- **Refactoring**: "Is it safe to refactor this module?"
- **Onboarding**: "Show me the main components of this codebase"
- **Debugging**: "What could break if I modify this class?"

### **For AI Agents**  
- **Code Analysis**: Fast codebase queries via structured commands
- **Dependency Analysis**: Token-efficient dependency queries
- **Impact Assessment**: Before suggesting code changes
- **Architecture Understanding**: Community detection for code organization

### **For DevOps/CI**
- **Code Quality Gates**: "Show hotspots and technical debt"
- **Architecture Compliance**: "Find layer boundary violations"
- **Risk Assessment**: "Identify risky components before deployment"

---

## 🚀 Quick Start

### Installation

```bash
pip install dominian
```

**Note:** After installation, if `dominian` command is not found, add Python Scripts folder to PATH or restart your terminal.

### First Time Usage (Important!)

**Many users get stuck here. Follow this exact order:**

```bash
# 1. Initialize (creates empty database)
dominian init

# 2. Scan your codebase (POPULATES the database - REQUIRED!)
dominian scan . --no-watch

# 3. Use the new CLI structure (no NLP required)
dominian deps direct main.py --format agent
dominian graph cycles --format agent
dominian arch communities --format agent
```

### Basic Usage

```bash
# Core workflow
dominian init
dominian scan . --no-watch
dominian info --format agent

# Common analysis commands
dominian deps direct UserService --format agent
dominian deps reverse UserService --format agent
dominian graph cycles --format agent
dominian arch communities --format agent
```

**See [COMMAND_REFERENCE.md](COMMAND_REFERENCE.md) for complete command list.**

---

## 📚 Quick Reference

### Core Workflow
1. **Initialize**: `dominian init`
2. **Scan**: `dominian scan . --no-watch`
3. **Analyze**: Use commands below

### Essential Commands
```bash
# Dependencies
dominian deps direct UserService --format agent
dominian deps reverse UserService --format agent

# Architecture
dominian arch communities --format agent
dominian graph cycles --format agent

# Refactoring
dominian refactor safe UserService --format agent

# File analysis
dominian file functions main.py --format agent
```

**⚠️ IMPORTANT**: All commands require subcommands (e.g., `deps direct`, not just `deps`). See [COMMAND_REFERENCE.md](COMMAND_REFERENCE.md) for complete list.

### Troubleshooting

#### **"No results from queries"**
```bash
# Database might be empty - scan first
dominian scan . --no-watch
```

#### **"Command hangs forever"**
```bash
# Always use --no-watch for agents
dominian scan . --no-watch
```

#### **"Port already in use"**
```bash
# Use different port
python enhanced_dominian_server.py --port 8766
```

### FAQ

**Q: Do I need to scan every time?**
A: Only after code changes. Use `--no-watch` for one-time scans.

**Q: Can I use it on any programming language?**
A: Dominian is fully tested with Python and JavaScript/TypeScript. Additional languages (Go, Java, Rust, C++, etc.) have Tree-sitter configurations but require manual testing and grammar installation.

**Q: What's the difference between basic and enhanced server?**
A: Enhanced server includes community detection, architectural patterns, and advanced queries.

---
python enhanced_dominian_server.py --port 8765

# Step 4: Now enhanced endpoints work
curl "http://localhost:8765/communities"
```

| Step | Database State | Enhanced Features Available |
|------|----------------|----------------------------|
| After `init` | Empty (0 nodes) | ❌ No |
| After `scan` | Basic structure | ⚠️ Limited |
| After `enhanced server` | Full + Communities | ✅ Yes |

---

## 💻 CLI Commands - When & Where to Use

### **🏗️ Setup Commands** (Use once per project)

```bash
# WHERE: Project root directory
# WHEN: First time setting up Dominian
dominian init                    # Creates .dominian/ folder and database
dominian scan /path/to/project   # Analyzes code and builds knowledge graph
```

### **🔄 Development Commands** (Use during coding)

```bash
# WHERE: Any terminal in project directory  
# WHEN: Actively developing code
dominian refactor safe X --format agent  # Quick safety checks
```

### **🌐 API Access** (Note: No server commands available)

```bash
# CLI is the primary interface - no server commands exist
# Use CLI commands directly for all analysis
```

### **📊 Analysis Commands** (Use for insights)

```bash
# WHERE: Any terminal with database available
# WHEN: Code reviews, architecture analysis, planning
dominian info --format agent                        # Project statistics and health
dominian graph hotspots --limit 10 --format agent      # Find complex/risky code
dominian arch communities --format agent   # Architectural organization
```

### **🛠️ Management Commands** (Use for maintenance)

```bash
# WHERE: Any terminal
# WHEN: Managing projects or troubleshooting
dominian graph stats --format agent              # Database performance metrics
```

---

## 🎯 What is Dominian?

Dominian scans your codebase and builds a **knowledge graph** that AI agents can query quickly.

**For Developers:** Use CLI commands to analyze code, find dependencies, detect issues.  
**For AI Agents:** Query via HTTP API for fast, token-optimized codebase intelligence.

---

## 🆕 Enhanced Features (New!)

#### **Community Detection** 🏘️
```bash
# WHERE: Any terminal with scanned codebase
# WHEN: Understanding codebase architecture
dominian arch communities --format agent                    # All communities
dominian arch cross-community --format agent               # Cross-community connections
dominian graph stats --format agent                         # Graph statistics
```


### **Enhanced Analysis Types** (40+ patterns)

#### **Community Detection**
- `dominian arch communities --format agent`
- `dominian arch cross-community --format agent`
- CLI: `dominian arch communities --format agent`

#### **Architecture Analysis**
- `dominian graph cycles --format agent`
- `dominian graph hotspots --limit 10 --format agent`
- `dominian arch communities --format agent`

#### **Refactoring Support**
- `dominian refactor safe X --format agent`
- `dominian refactor impact X --format agent`
- `dominian deps direct X --format agent`
- `dominian deps reverse X --format agent`

#### **Performance Analysis**
- `dominian graph hotspots --limit 10 --format agent`
- `dominian graph stats --format agent`
- CLI: `dominian graph stats --format agent`

#### **Dependency Analysis**
- `dominian deps direct X --format agent`
- `dominian deps reverse X --format agent`
- `dominian arch impact X --format agent`

#### **Quality & Complexity**
- `dominian graph hotspots --limit 10 --format agent`
- `dominian graph stats --format agent`
- CLI: `dominian graph hotspots --format agent`

#### **Code Structure**
- `dominian search "class" --format agent` - List all classes
- `dominian search "function" --format agent` - List all functions
- `dominian file functions X.py --format agent` - Functions in specific file
- `dominian graph stats --format agent` - Complete project structure

#### **Advanced Analysis**
- `dominian graph cycles --format agent`
- `dominian arch cross-community --format agent`
- `dominian graph hotspots --limit 10 --format agent`

#### **Complexity Analysis**
- `dominian graph hotspots --limit 10 --format agent`
- `dominian graph stats --format agent`
- CLI: `dominian graph stats --format agent`

---

## 📚 Query Examples by Use Case

### **🔍 Code Reviews**
```bash
dominian deps reverse UserService --format agent
dominian deps direct UserService --format agent
dominian graph cycles --format agent
dominian graph hotspots --limit 10 --format agent
dominian graph stats --format agent
```

### **🏗️ Architecture Analysis**  
```bash
dominian arch communities --format agent
dominian arch cross-community --format agent
dominian graph cycles --format agent
dominian graph hotspots --limit 10 --format agent
```

### **🔧 Refactoring Support**
```bash
dominian refactor safe ClassName --format agent
dominian refactor impact FunctionName --format agent
dominian deps direct EntityName --format agent
dominian deps reverse EntityName --format agent
```

### **⚡ Performance Analysis**
```bash
dominian graph hotspots --limit 10 --format agent
dominian graph stats --format agent
dominian deps direct FunctionName --format agent
dominian arch communities --format agent
```

---

## Python API - For AI Agents

For Python applications and AI agents who need direct access:

```python
# Import and use directly
from database import GraphDatabase
from engine import QueryEngine
from formatter import format_for_claude

# Direct database access
db = GraphDatabase(".dominian/agentgraph.db")
engine = QueryEngine(db)

# Get dependencies
deps = db.get_dependencies("UserService")
print(format_for_claude(deps))

# Check refactoring safety
safe = engine.check_refactor_safety("AuthModule")
print(format_for_claude(safe))
```

### Performance Comparison

| Method | Speed | Use Case |
|--------|-------|---------|
| **Direct API** | 0.040s | AI agents, Python apps |
| CLI + --oneshot | 1.043s | Scripts, humans |
| CLI (default) | 2.5s | Interactive use |

### Why Direct API is Faster

- No subprocess startup overhead
- No Python module imports
- Direct database access
- Reuses existing connections

### For 100 Queries

| Method | Total Time | Time Saved |
|--------|------------|------------|
| **Direct API** | 4.0s | - |
| CLI --oneshot | 104.3s | **100.3s saved** |

---

## Complete Command Reference

## CLI Reference

### Commands

#### **Setup**

| Command | Purpose | Example |
|---------|---------|---------|
| `dominian init [db_path]` | Initialize project | `dominian init` |
| `dominian scan <path> [--no-watch]` | Scan codebase | `dominian scan . --no-watch` |
| `dominian rescan [--no-watch]` | Re-scan codebase | `dominian rescan --no-watch` |
| `dominian watch [--port]` | Watch for changes | `dominian watch --port 8001` |
| `dominian info [--db] [--format]` | Show project info | `dominian info --format agent` |
| `dominian doctor` | System health check | `dominian doctor` |
| `dominian status` | Show running servers | `dominian status` |
| `dominian stop [path] [--force]` | Stop processes | `dominian stop --force` |

#### **Entity Lookup**

| Command | Purpose | Example |
|---------|---------|---------|
| `dominian node get <entity> [--format]` | Get entity details | `dominian node get QueryEngine --format agent` |
| `dominian node search <query> [--format]` | Search entities | `dominian node search "query" --format agent` |

#### **Dependency Analysis**

| Command | Purpose | Example |
|---------|---------|---------|
| `dominian deps direct <entity> [--format]` | Direct dependencies | `dominian deps direct AuthService --format agent` |
| `dominian deps reverse <entity> [--format]` | Reverse dependencies | `dominian deps reverse DatabaseManager --format agent` |
| `dominian arch impact <entity> [--format]` | Impact analysis | `dominian arch impact UserService --format agent` |

#### **File Analysis**

| Command | Purpose | Example |
|---------|---------|---------|
| `dominian file functions <file> [--format]` | Functions in file | `dominian file functions main.py --format agent` |
| `dominian file classes <file> [--format]` | Classes in file | `dominian file classes engine.py --format agent` |

#### **Graph Analysis**

| Command | Purpose | Example |
|---------|---------|---------|
| `dominian graph cycles [--format]` | Find circular dependencies | `dominian graph cycles --format agent` |
| `dominian graph hotspots [--limit] [--format]` | Complexity hotspots | `dominian graph hotspots --limit 10 --format agent` |
| `dominian graph stats [--format]` | Graph statistics | `dominian graph stats --format agent` |

#### **Architecture Analysis**

| Command | Purpose | Example |
|---------|---------|---------|
| `dominian arch communities [--format]` | Community structure | `dominian arch communities --format agent` |
| `dominian arch cross-community [--format]` | Cross-community edges | `dominian arch cross-community --format agent` |

#### **Refactoring Safety**

| Command | Purpose | Example |
|---------|---------|---------|
| `dominian refactor safe <entity> [--format]` | Check refactor safety | `dominian refactor safe EntityName --format agent` |
| `dominian refactor impact <entity> [--format]` | Show refactor impact | `dominian refactor impact EntityName --format agent` |

---

### Output Formats

Use `--format` with any command to control output style:

| Flag | Best For |
|------|----------|
| `--format agent` | AI agents (Claude, Cursor, etc.) |
| `--format json` | Scripts and automation |
| `--format table` | Terminal/human reading |
| `--format text` | Simple plain text |

### Command Groups

```bash
# Setup workflow
dominian init
dominian scan . --no-watch
dominian info --format agent

# Dependency analysis workflow
dominian deps direct EntityName --format agent
dominian deps reverse EntityName --format agent
dominian arch impact EntityName --format agent

# Refactoring workflow
dominian refactor safe EntityName --format agent
dominian refactor impact EntityName --format agent

# Architecture analysis workflow
dominian arch communities --format agent
dominian arch cross-community --format agent

# File analysis workflow
dominian file functions filename.py --format agent
dominian file classes filename.py --format agent
```

---

## Command Reference

### **Setup Commands**

```bash
# Initialize project
dominian init

# Scan codebase
dominian scan . --no-watch

# Show project info
dominian info --format agent

# Check system health
dominian doctor
```

### **Dependency Analysis**

```bash
# Direct dependencies
dominian deps direct QueryEngine --format agent

# Reverse dependencies  
dominian deps reverse GraphDatabase --format agent

# Impact analysis
dominian arch impact format_for_claude --format agent
```

### **Graph Analysis**

```bash
# Find circular dependencies
dominian graph cycles --format agent

# Show complexity hotspots
dominian graph hotspots --limit 10 --format agent

# Graph statistics
dominian graph stats --format agent
```

### **File Analysis**

```bash
# Functions in file
dominian file functions main.py --format agent

# Classes in file
dominian file classes engine.py --format agent
```

### **Architecture Analysis**

```bash
# Community structure (requires enhanced server)
dominian arch communities --format agent

# Cross-community connections
dominian arch cross-community --format agent
```

### **Entity Lookup**

```bash
# Get entity details
dominian node get QueryEngine --format agent

# Search entities
dominian node search "query" --format agent

# Show with relationships
dominian node get format_for_claude --format agent
```

### **Refactoring Safety**

```bash
# Check refactoring safety
dominian refactor safe entity_name --format agent

# Show refactoring impact
dominian refactor impact entity_name --format agent
```

### Status Command

```bash
# Show all running Dominian servers
dominian status

# Output:
# ┌─────────┬──────┬─────┬─────────┬────────────────────────┐
# │ Project │ Port │ PID │ Status  │ Database               │
# ├─────────┼──────┼─────┼─────────┼────────────────────────┤
# │ flask   │ 8000 │ 123 │ running │ .dominian/agentgraph.db │
# │ django  │ 8001 │ 456 │ running │ .dominian/agentgraph.db │
# └─────────┴──────┴─────┴─────────┴────────────────────────┘
```

### Server Management

```bash
# Show project status
dominian status

# Stop any running processes
dominian stop

# Enhanced server (for community detection)
python enhanced_dominian_server.py
```

### Info Command

```bash
# Show project statistics
dominian info

# With specific database
dominian info --db /path/to/custom.db
```

---

## 🤖 Using with AI Agents (Claude Code, Codex, Cursor)

### Direct CLI Commands

AI agents can use Dominian directly through CLI commands:

```bash
# Get dependencies
dominian deps direct EntityName --format agent

# Check refactoring safety
dominian refactor safe EntityName --format agent

# Show architecture
dominian arch communities --format agent
```

### MCP Server Integration

```bash
# Start MCP server
dominian-mcp

# Available tools:
# - query_codebase
# - get_codebase_status  
# - initialize_project
```

**For AI Agents:**
Use direct CLI commands with `--format agent` for structured output.

### Python API

```python
from database import GraphDatabase
from engine import QueryEngine
from formatter import format_for_claude

# Direct database access
db = GraphDatabase("agentgraph.db")
deps = db.get_dependencies("EntityName")
```

### MCP Tools Available

Once configured, agents can use these tools:

| Tool | Purpose | Example |
|------|---------|---------|
| `initialize_project` | Setup project for analysis | Auto-runs when needed |
| `scan_codebase` | Build/update knowledge graph | Scans all code files |
| `query_codebase` | Structured code analysis | "dominian deps direct UserService" |
| `get_codebase_status` | Check server/stats | Shows nodes, edges, health |

---

## 🔌 MCP Server (Model Context Protocol)

Connect Dominian to any MCP-compatible AI agent (**Claude Desktop, Cursor, Windsurf**) for hands-free codebase analysis.


| `scan_codebase` | Build/update knowledge graph | Scans all code files |
| `query_codebase` | Structured code analysis | "dominian deps direct UserService" |
| `get_codebase_status` | Check server/stats | Shows nodes, edges, health |

### Installation with MCP Support

```bash
pip install "dominian[mcp]"
```

Or install MCP separately:
```bash
pip install dominian mcp
```

### Configure Claude Desktop

Add to `claude_desktop_config.json`:

**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`  
**Mac:** `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "dominian": {
      "command": "dominian-mcp"
    }
  }
}
```

### Configure Cursor

Add to Cursor MCP settings (Settings → MCP):

```json
{
  "mcpServers": {
    "dominian": {
      "command": "dominian-mcp"
    }
  }
}
```

| `scan_codebase` | Build/update knowledge graph | Scans all code files |
| `query_codebase` | Structured code analysis | "dominian deps direct UserService" |
| `get_codebase_status` | Check server/stats | Shows nodes, edges, health |

### MCP Usage Example

**User:** *"Analyze this codebase for me"*

**Claude:**
1. Calls `initialize_project(path=".")` → Creates `.dominian/`
2. Calls `scan_codebase(path=".")` → Parses all files
3. Calls `query_codebase(command="dominian node search class --format agent")` → Gets results
4. Responds: *"This project has 15 classes including UserService, OrderService..."*

### Token & Cost Efficiency with MCP

When agents need full codebase context:

| Scenario | Approach | Tokens | Typical Latency |
|----------|----------|--------|-----------------|
| **Baseline** | Reading 100 files directly | ~40,000-80,000 | 10-30s |
| **With Dominian** | Querying knowledge graph | ~500 | 0.1-0.5s |
| **Reduction** | Structured vs. raw access | **Significantly fewer tokens** | **Much faster** |

*Actual savings depend on project size, query type, and file complexity.*

---

### API Examples

```bash
# Enhanced server endpoints
curl "http://localhost:8765/communities"
curl "http://localhost:8765/stats"
curl "http://localhost:8765/hotspots"

# CLI commands for agents
dominian deps direct UserService --format agent
dominian deps reverse DatabaseManager --format agent
dominian graph cycles --format agent

# Find orphaned code
curl "http://localhost:8000/orphans"
```

### Response Format (Token-Optimized)

```
SUMMARY: UserService depends on 4 nodes

FOCUS: UserService[class|auth/service.py:15-89|complexity:7|quality:85%]

DEPENDENCIES:
- UserRepository[class|db/repo.py|uses]
- TokenManager[class|auth/token.py|manages]
- PasswordHasher[function|utils/crypto.py|calls]
- Logger[class|core/log.py|injects]

```

---

## 📊 Supported Languages

| Language | Parser | Status | Notes |
|----------|--------|--------|-------|
| Python | Regex-based | ✅ Verified | Full support (functions, classes, async, imports) |
| JavaScript | Regex-based | ✅ Verified | Functions, classes, async detection, ES6 modules |
| TypeScript | Regex-based | ✅ Verified | Same as JavaScript with type annotations |
| Go | Tree-sitter | ⚠️ Experimental | Configured but not tested |
| Java | Tree-sitter | ⚠️ Experimental | Configured but not tested |
| Rust | Tree-sitter | ⚠️ Experimental | Configured but not tested |
| C/C++ | Tree-sitter | ⚠️ Experimental | Configured but not tested |

*Tree-sitter support requires installing language grammars (`pip install tree-sitter-<language>`). Regex parsers work out-of-the-box.*

---

## ⚡ Performance

- **Scan Speed:** Depends on project size and file complexity
- **Query Latency:** Typically 1-2 seconds for most queries
- **Live Updates:** File watcher detects changes automatically
- **Memory:** Varies based on codebase size

---

## 🧪 Beta Status

**Why Beta?**

Dominian is classified as Beta (Development Status 4) because:

1. **Active Development:** Core features are stable, but API may evolve based on user feedback
2. **New Product:** Recently launched, gathering real-world usage data
3. **Future Features:** Planning advanced capabilities (cross-repo analysis, AI predictions)

**Production Ready?**
- ✅ Core functionality is stable and tested
- ✅ Used successfully on real codebases
- ⚠️ API contract may change in v2.0

**When will it be stable?**
- Target: v2.0 (stable release) after 3 months of production usage
- Your feedback helps shape the stable API!

---

## 📦 Installation & Setup

### From PyPI (Recommended)

```bash
pip install dominian
```

### From Source

```bash
git clone https://github.com/MaSH-Dominian/Dominian.git
cd Dominian
pip install -r requirements.txt
pip install -e .
```

### Verify Installation

```bash
dominian --version
dominian --help
```

---

## 🛠️ Development

### Testing on TestPyPI (for contributors)

```bash
# Build package
python -m build

# Upload to TestPyPI
python -m twine upload --repository testpypi dist/*

# Install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ dominian
```

### Running Tests

```bash
pytest tests/
```

---

## 🔧 Configuration

### Environment Variables

```bash
# Default port for server
DOMINIAN_PORT=8000

# Database location
# Set by `dominian serve` (from `.dominian/config.yaml`) or override manually.
# Typical per-project location: <project>/.dominian/agentgraph.db
DOMINIAN_DB=./.dominian/agentgraph.db

# Log level
DOMINIAN_LOG_LEVEL=INFO
```

If port 8000 is busy (e.g., HTML server running):

```bash
cd /project
dominian serve
# ⚠️ Port 8000 is busy (PID 1234). Finding next free port...
# ✓ Using port 8001.
# ✓ Server: http://localhost:8001
```

Port and DB path are automatically persisted in `.dominian/config.yaml`.

---

## 📝 Example Workflows

### Workflow 1: Understanding a New Codebase

```bash
# 1. Scan the project
dominian scan /path/to/project

# 2. Start server
dominian serve

# 3. Analyze code
dominian graph stats --format agent
dominian graph hotspots --limit 10 --format agent
dominian node search "database" --format agent
```

### Workflow 2: Refactoring with AI Agent

```bash
# 1. Start server in background
dominian serve &

# 2. Tell Claude/Codex:
# "Before refactoring UserService, use Dominian commands
#  to understand its dependencies"

# 3. Agent automatically runs:
# dominian deps direct UserService --format agent

# 4. After refactoring, graph updates automatically
# (file watcher detects changes)
```

### Workflow 3: Code Review

```bash
# Check for issues before committing
dominian graph cycles --format agent
dominian graph hotspots --limit 10 --format agent
dominian graph stats --format agent
```

---

## 🐛 Troubleshooting

### "command not found: dominian"

```bash
# Make sure pip bin directory is in PATH
# Or reinstall the package
```

### "Permission denied" on scan

```bash
# Check file permissions
# Skip restricted directories:
dominian scan . --exclude-dir=node_modules --exclude-dir=.git
```

### Server won't start (port in use)

```bash
# Use different port
dominian serve --port 9000
```

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes
4. Run tests
5. Submit PR

---

## 📄 License

MIT License - see LICENSE file

---

## 👤 Author

Created by **MaSh**

---

## 🔗 Links

- PyPI: https://pypi.org/project/dominian/
- Documentation: https://github.com/MaSH-Dominian/Dominian#readme
- Issues: https://github.com/MaSH-Dominian/Dominian/issues

---

**Happy Coding! 🚀**
