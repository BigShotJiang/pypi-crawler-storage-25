"""Auto-pilot integration for Goose (Block Inc).

Exposes:

  NeruvaAutoPilot       -- framework-agnostic core. Fetches substrate
                            prompts (route_intent, reflect, extract) and
                            runs them through a caller-supplied LLM.
                            Returns structured results.

  NeruvaAutoPilotHooks  -- Goose-shaped event hooks:
                            before_user_message  -> Layer 2 route_intent
                            after_tool_call      -> Layer 1 extract
                            after_session        -> Layer 3 reflect

Goose's primary extension surface is MCP, so the full Neruva tool
catalog is already available by adding @neruva/mcp to your Goose
config. This Python package handles the orthogonal pattern-C auto-pilot
loop -- the side-effect hooks that classify intents, extract facts,
and self-curate substrate, all gated on your own LLM call (not Goose's).

Pattern-C throughout: substrate emits the prompt, caller LLM runs it,
results pushed back via the existing client. Substrate stays $0/call.
"""
from __future__ import annotations

import json
import re
from typing import Any, Callable, Optional

from neruva_goose._client import NeruvaClient


_EXTRACTION_PROMPT = (
    "You are a precise triple extractor. Given input text, extract the "
    "factual (subject, predicate, object) triples it asserts. Use "
    "canonical lowercase tokens. Predicates are short verb phrases "
    "(e.g., 'lives_in', 'works_at', 'said', 'is_a').\n\n"
    "Output ONLY a JSON array. No prose. No commentary.\n\n"
    'Example input: "Alice told me she lives in Toronto and works at Acme."\n'
    'Example output: [["alice","lives_in","toronto"],["alice","works_at","acme"]]\n\n'
    "If the text contains no extractable facts, output []."
)


def _strip_json(s: str) -> str:
    s = s.strip()
    m = re.search(r"```(?:json)?\s*(.+?)```", s, re.DOTALL)
    if m:
        return m.group(1).strip()
    for opener, closer in (("{", "}"), ("[", "]")):
        i, j = s.find(opener), s.rfind(closer)
        if 0 <= i < j:
            return s[i:j + 1]
    return s


class NeruvaAutoPilot:
    """Framework-agnostic auto-pilot helper for Goose users."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        namespace: str = "default",
        llm_callable: Optional[Callable[[str], str]] = None,
    ) -> None:
        self.client = NeruvaClient(api_key=api_key)
        self.namespace = namespace
        self.llm_callable = llm_callable
        self._auto_kg = f"{namespace}-auto-kg"

    def _invoke(self, prompt: str) -> str:
        if self.llm_callable is None:
            raise RuntimeError(
                "NeruvaAutoPilot needs llm_callable=. Pass a callable "
                "that takes a prompt and returns the LLM's text response "
                "(e.g., lambda p: my_llm.complete(p))."
            )
        return self.llm_callable(prompt)

    # ---- Layer 2: intent routing ----
    def classify_intent(
        self,
        user_message: str,
        recent_context_summary: Optional[str] = None,
    ) -> dict[str, Any]:
        payload = self.client._post(
            "/v1/agent/route_intent_prompt",
            {
                "user_message": user_message,
                "recent_context_summary": recent_context_summary,
            },
        )
        raw = self._invoke(payload["prompt"])
        try:
            return json.loads(_strip_json(raw))
        except Exception:
            return {"primary_intent": "none", "confidence": 0.0}

    # ---- Layer 3: reflective auto-write ----
    def reflect(
        self,
        recent_turns: list[dict[str, Any]],
        auto_write: bool = True,
    ) -> dict[str, Any]:
        payload = self.client._post(
            "/v1/agent/reflect_prompt",
            {"recent_turns": recent_turns},
        )
        raw = self._invoke(payload["prompt"])
        try:
            parsed = json.loads(_strip_json(raw))
        except Exception:
            return {"decisions": [], "facts": [], "mistakes": [], "open_questions": []}
        if auto_write:
            self._write_reflected(parsed)
        return parsed

    def _write_reflected(self, parsed: dict[str, Any]) -> None:
        items = []
        for d in parsed.get("decisions", []) or []:
            items.append({
                "kind": "decision",
                "text": d.get("text", ""),
                "tags": (d.get("tags") or []) + ["auto-reflected"],
            })
        for m in parsed.get("mistakes", []) or []:
            items.append({
                "kind": "mistake",
                "text": m.get("text", "") + (
                    f"  ROOT CAUSE: {m.get('root_cause')}" if m.get("root_cause") else ""
                ),
                "tags": ["auto-reflected"],
            })
        for q in parsed.get("open_questions", []) or []:
            items.append({
                "kind": "open_question",
                "text": q if isinstance(q, str) else q.get("text", ""),
                "tags": ["auto-reflected"],
            })
        if items:
            try:
                self.client._post(f"/v1/records/{self.namespace}", {"items": items})
            except Exception:
                pass
        facts = parsed.get("facts", []) or []
        triples = [
            [f.get("subject", ""), f.get("relation", ""), f.get("object", "")]
            for f in facts
            if f.get("subject") and f.get("relation") and f.get("object")
        ]
        if triples:
            try:
                self.client._post(
                    f"/v1/hd/kg/{self._auto_kg}/facts",
                    {"facts": triples},
                )
            except Exception:
                pass

    # ---- Layer 1: extraction ----
    def extract_facts(self, text: str, auto_write: bool = True) -> list[list[str]]:
        prompt = _EXTRACTION_PROMPT + "\n\nINPUT:\n" + text
        raw = self._invoke(prompt)
        try:
            triples = json.loads(_strip_json(raw))
        except Exception:
            return []
        if not isinstance(triples, list):
            return []
        clean = [
            t for t in triples
            if isinstance(t, list) and len(t) == 3 and all(isinstance(x, str) for x in t)
        ]
        if auto_write and clean:
            try:
                self.client._post(
                    f"/v1/hd/kg/{self._auto_kg}/facts",
                    {"facts": clean},
                )
            except Exception:
                pass
        return clean


class NeruvaAutoPilotHooks:
    """Goose-shaped event hooks. Wire into your Goose extension's
    pre-message / post-tool / post-session handlers.

    The hooks buffer recent turns and fire reflection every
    `reflect_every` tool calls so you don't have to thread state through
    Goose yourself.

    Example (sketch -- Goose's extension API has been moving; consult
    the current docs at https://block.github.io/goose/ for the exact
    decorator names):

        from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks

        ap = NeruvaAutoPilot(api_key="nv_...",
                             namespace="my_session",
                             llm_callable=my_llm.complete)
        hooks = NeruvaAutoPilotHooks(ap, reflect_every=10)

        @extension.on_user_message
        def _pre(msg):
            intent = hooks.before_user_message(msg)
            # optionally inject intent.primary_intent into the system
            # prompt so the model picks the right Neruva MCP tool

        @extension.on_tool_result
        def _post(tool_name, output):
            hooks.after_tool_call(tool_name, str(output))
    """

    def __init__(
        self,
        auto_pilot: NeruvaAutoPilot,
        reflect_every: int = 10,
    ) -> None:
        self.ap = auto_pilot
        self.reflect_every = max(1, int(reflect_every))
        self._turns: list[dict[str, Any]] = []
        self._tool_calls_since_reflect = 0

    def before_user_message(self, user_text: str) -> dict[str, Any]:
        """Classify the user's intent. Returns the classification dict
        (primary_intent, confidence, suggested_tool, args_hint).

        Buffer the turn so subsequent reflect() has context. If the
        caller's LLM isn't reachable, returns a no-op classification
        rather than raising.
        """
        if not isinstance(user_text, str) or not user_text.strip():
            return {"primary_intent": "none", "confidence": 0.0}
        self._turns.append({"role": "user", "text": user_text[:4000]})
        try:
            return self.ap.classify_intent(user_text)
        except Exception:
            return {"primary_intent": "none", "confidence": 0.0}

    def after_tool_call(
        self,
        tool_name: str,
        output_text: str,
    ) -> None:
        """Auto-extract facts from tool output to the auto-KG. Also
        increments the reflect counter and fires reflection when it
        crosses `reflect_every`.
        """
        if not isinstance(output_text, str) or len(output_text.strip()) < 20:
            return
        # Buffer the tool turn so reflect() sees the conversation flow.
        self._turns.append({
            "role": "tool",
            "text": f"[{tool_name}] {output_text[:4000]}",
        })
        try:
            self.ap.extract_facts(output_text, auto_write=True)
        except Exception:
            pass
        self._tool_calls_since_reflect += 1
        if self._tool_calls_since_reflect >= self.reflect_every:
            self._tool_calls_since_reflect = 0
            try:
                self.ap.reflect(self._turns[-self.reflect_every * 2:], auto_write=True)
            except Exception:
                pass

    def after_assistant_message(self, assistant_text: str) -> None:
        """Optional: buffer assistant turns so reflect() sees both
        sides of the conversation. Not every Goose host emits these
        as a separate event -- skip if you don't have it."""
        if not isinstance(assistant_text, str) or not assistant_text.strip():
            return
        self._turns.append({"role": "assistant", "text": assistant_text[:4000]})

    def after_session(self, force: bool = True) -> dict[str, Any]:
        """Call when the Goose session ends. Reflects over all buffered
        turns and writes structured records. Returns the parsed
        reflection (or {} if buffer was empty or LLM unavailable).
        """
        if len(self._turns) < 3 and not force:
            return {}
        try:
            return self.ap.reflect(self._turns[-50:], auto_write=True)
        except Exception:
            return {}
