"""Thin HTTP client around api.neruva.io. No substrate internals here --
just the REST shapes the Goose extension needs. Mirrors the _client.py
in neruva-langchain / neruva-langgraph / neruva-crewai so the four
adapters stay structurally identical."""
from __future__ import annotations

import os
from typing import Any, Optional

import httpx


DEFAULT_BASE_URL = "https://api.neruva.io"


class NeruvaClient:
    """Tiny synchronous client for the substrate endpoints used by the
    Goose integration. Falls back to env vars NERUVA_API_KEY +
    NERUVA_URL so a chain can be constructed without explicit args."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout_s: float = 30.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("NERUVA_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "NERUVA_API_KEY not provided -- pass api_key= or set the "
                "NERUVA_API_KEY env var. Get a key at app.neruva.io."
            )
        self.base_url = (
            base_url
            or os.environ.get("NERUVA_URL")
            or DEFAULT_BASE_URL
        ).rstrip("/")
        self._http = httpx.Client(timeout=timeout_s)

    def _post(self, path: str, body: dict) -> Any:
        r = self._http.post(
            self.base_url + path,
            headers={"Api-Key": self.api_key, "Content-Type": "application/json"},
            json=body,
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST {path} -> {r.status_code}: {r.text}")
        return r.json()

    def _get(self, path: str) -> Any:
        r = self._http.get(
            self.base_url + path,
            headers={"Api-Key": self.api_key},
        )
        if r.status_code >= 400:
            raise RuntimeError(f"GET {path} -> {r.status_code}: {r.text}")
        return r.json()
