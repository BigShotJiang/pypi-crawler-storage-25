"""Goose extension for Neruva agent memory.

Wires Neruva's three auto-pilot layers into Goose's session lifecycle:

  Layer 2 (route intent)  -- fires on pre-message: classifies the user's
                              message into one of 18 cognitive intents
                              and surfaces the right substrate tool.
  Layer 3 (reflect)       -- fires every N tool calls (default 10):
                              self-curates substrate from recent turns
                              by writing decisions / facts / mistakes
                              / open_questions.
  Layer 1 (extract)       -- fires on post-tool: extracts factual
                              triples from tool output text into the
                              auto-KG.

Pattern-C throughout: substrate emits the prompt, your LLM runs it,
SDK pushes structured results back. Substrate stays $0/call.

For the full Neruva MCP tool surface in Goose, also configure
@neruva/mcp as a Goose MCP extension (see README).

Usage:

    from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks

    ap = NeruvaAutoPilot(
        api_key="nv_...",
        namespace="my_goose_session",
        llm_callable=lambda p: my_llm.complete(p),
    )
    hooks = NeruvaAutoPilotHooks(ap)

    # Wire into your Goose extension's event handlers:
    hooks.before_user_message(user_text)   # Layer 2: returns intent
    hooks.after_tool_call(tool_name, out)  # Layer 1: extracts facts
    hooks.after_session(turns)             # Layer 3: reflect + write
"""
from neruva_goose.auto_pilot import (
    NeruvaAutoPilot,
    NeruvaAutoPilotHooks,
)

__all__ = [
    "NeruvaAutoPilot",
    "NeruvaAutoPilotHooks",
]

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("neruva-goose")
except PackageNotFoundError:
    __version__ = "0.0.0+local"
