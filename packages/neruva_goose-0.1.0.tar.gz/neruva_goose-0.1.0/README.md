# neruva-goose

Goose (Block Inc) extension for the Neruva agent memory + reasoning substrate.

Two integration paths -- use one or both:

## Path 1: `@neruva/mcp` as a Goose MCP extension (zero Python)

Drop the Neruva MCP server straight into Goose's extension config. You
get every Neruva substrate tool (records, KG, causal, analogy, CBR,
ToM, EFE planning, code graph, replay) inside Goose with no glue code.

`~/.config/goose/config.yaml`:

```yaml
extensions:
  neruva:
    type: stdio
    cmd: npx
    args: ["-y", "@neruva/mcp@latest"]
    env:
      NERUVA_API_KEY: nv_your_key_here
```

Restart Goose. Run `goose mcp list` -- you should see ~80 Neruva tools.

## Path 2: `neruva-goose` Python package (auto-pilot)

For pattern-C auto-pilot (route intent / reflect / extract running
through *your* LLM, with substrate emitting only the prompts), install
this Python package and wire its hooks into your Goose extension.

```bash
pip install neruva-goose
```

```python
from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks

ap = NeruvaAutoPilot(
    api_key="nv_...",
    namespace="my_session",
    llm_callable=lambda prompt: my_llm.complete(prompt),
)
hooks = NeruvaAutoPilotHooks(ap, reflect_every=10)

# Pre-message: classify intent so you can pick the right Neruva tool
intent = hooks.before_user_message(user_text)
print(intent)
# -> {"primary_intent": "counterfactual", "confidence": 0.87,
#     "suggested_tool": "agent_counterfactual_rollout", ...}

# Post-tool: auto-extract facts to the auto-KG, fire reflection every 10
hooks.after_tool_call("agent_recall", str(tool_output))

# Optional: buffer assistant turns
hooks.after_assistant_message(assistant_text)

# End of session: force a final reflection
hooks.after_session(force=True)
```

The three layers:

| Layer | Hook                  | Substrate prompt                  | What happens                                                    |
|-------|-----------------------|-----------------------------------|-----------------------------------------------------------------|
| 1     | `after_tool_call`     | inline extraction prompt          | Triples extracted from tool output, pushed to `<ns>-auto-kg`.   |
| 2     | `before_user_message` | `/v1/agent/route_intent_prompt`   | Returns top intent + suggested Neruva tool.                     |
| 3     | `after_session` / every N tool calls | `/v1/agent/reflect_prompt` | Decisions / facts / mistakes / open_questions written to substrate. |

## Pattern-C, $0/call

The substrate never runs your LLM. It hands back canonical prompts;
your code runs them; structured results come back via the existing
client. That keeps the substrate deterministic and free at the call
boundary, and means your LLM provider, model choice, and rate limits
are entirely yours.

## License

MIT. Same as `neruva-mcp`, `neruva-record`, `neruva-langchain`,
`neruva-langgraph`, `neruva-crewai`.
