"""Smoke tests for neruva-goose.

Pure unit tests with a stub LLM + monkey-patched NeruvaClient. No live
network. Validates that:

  - The package imports cleanly.
  - NeruvaAutoPilot raises when no llm_callable is supplied.
  - The three Goose-shaped hooks (before_user_message / after_tool_call
    / after_session) accept the expected inputs and return the
    expected shapes.
  - The reflect-every-N counter trips at the configured interval.
"""
from __future__ import annotations

import json
import os
from typing import Any
from unittest.mock import patch

import pytest


# Make sure tests pass even if NERUVA_API_KEY isn't set in the env.
os.environ.setdefault("NERUVA_API_KEY", "nv_test_dummy_key_for_unit_tests")


def test_package_imports():
    import neruva_goose
    assert isinstance(neruva_goose.__version__, str)
    assert "NeruvaAutoPilot" in neruva_goose.__all__
    assert "NeruvaAutoPilotHooks" in neruva_goose.__all__


def test_autopilot_requires_llm():
    from neruva_goose import NeruvaAutoPilot
    from neruva_goose import _client as client_mod

    ap = NeruvaAutoPilot(api_key="nv_x", namespace="test")
    with patch.object(client_mod.NeruvaClient, "_post",
                      side_effect=_stub_classify_payload):
        with pytest.raises(RuntimeError, match="llm_callable"):
            ap.classify_intent("hello")


def _stub_classify_payload(*args, **kwargs):
    """Mimic the substrate response shape for /v1/agent/route_intent_prompt."""
    return {
        "prompt": "Return JSON: {\"primary_intent\":\"counterfactual\",\"confidence\":0.9}",
        "expected_schema": {"primary_intent": "string", "confidence": "number"},
    }


def _stub_reflect_payload(*args, **kwargs):
    return {
        "prompt": "Return JSON with decisions/facts/mistakes/open_questions",
        "expected_schema": {"decisions": "array"},
    }


class _StubLLM:
    """Counts invocations + returns a canned JSON string for any prompt."""

    def __init__(self, responses: list[str]):
        self.responses = list(responses)
        self.calls: list[str] = []

    def __call__(self, prompt: str) -> str:
        self.calls.append(prompt)
        if self.responses:
            return self.responses.pop(0)
        return "{}"


def test_before_user_message_classifies():
    from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks
    from neruva_goose import _client as client_mod

    llm = _StubLLM(['{"primary_intent":"counterfactual","confidence":0.9}'])
    ap = NeruvaAutoPilot(api_key="nv_x", namespace="t", llm_callable=llm)
    hooks = NeruvaAutoPilotHooks(ap, reflect_every=3)

    with patch.object(client_mod.NeruvaClient, "_post",
                      side_effect=_stub_classify_payload):
        intent = hooks.before_user_message("What if we picked Mailgun?")

    assert intent["primary_intent"] == "counterfactual"
    assert intent["confidence"] == 0.9
    assert len(llm.calls) == 1
    assert "Mailgun" in hooks._turns[-1]["text"]


def test_before_user_message_returns_noop_on_empty_input():
    from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks

    ap = NeruvaAutoPilot(api_key="nv_x", namespace="t",
                         llm_callable=_StubLLM([]))
    hooks = NeruvaAutoPilotHooks(ap)
    assert hooks.before_user_message("")["primary_intent"] == "none"
    assert hooks.before_user_message("   ")["primary_intent"] == "none"
    # No turns buffered for empty inputs
    assert hooks._turns == []


def test_after_tool_call_skips_short_text():
    from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks

    llm = _StubLLM([])
    ap = NeruvaAutoPilot(api_key="nv_x", namespace="t", llm_callable=llm)
    hooks = NeruvaAutoPilotHooks(ap, reflect_every=10)
    hooks.after_tool_call("tool", "short")  # < 20 chars
    assert llm.calls == []
    assert hooks._tool_calls_since_reflect == 0


def test_after_tool_call_extracts_and_increments_counter():
    from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks
    from neruva_goose import _client as client_mod

    llm = _StubLLM(['[["alice","lives_in","toronto"]]'])
    ap = NeruvaAutoPilot(api_key="nv_x", namespace="t", llm_callable=llm)
    hooks = NeruvaAutoPilotHooks(ap, reflect_every=10)

    posts: list[tuple[str, dict]] = []

    def fake_post(self, path, body):
        posts.append((path, body))
        return {}

    with patch.object(client_mod.NeruvaClient, "_post", fake_post):
        hooks.after_tool_call(
            "agent_recall",
            "Alice told me she lives in Toronto and works at Acme.",
        )

    # LLM was invoked once for extraction
    assert len(llm.calls) == 1
    # One write to auto-KG with the parsed triple
    facts_writes = [p for p in posts if "/facts" in p[0]]
    assert len(facts_writes) == 1
    assert facts_writes[0][1]["facts"] == [["alice", "lives_in", "toronto"]]
    # Counter incremented
    assert hooks._tool_calls_since_reflect == 1


def test_reflect_fires_every_N_tool_calls():
    from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks
    from neruva_goose import _client as client_mod

    # 3 extract responses then 1 reflect response (after 3 tool calls)
    llm = _StubLLM([
        '[]',
        '[]',
        '[]',
        json.dumps({
            "decisions": [{"text": "we picked Resend"}],
            "facts": [],
            "mistakes": [],
            "open_questions": [],
        }),
    ])
    ap = NeruvaAutoPilot(api_key="nv_x", namespace="t", llm_callable=llm)
    hooks = NeruvaAutoPilotHooks(ap, reflect_every=3)

    reflect_post_seen = False
    records_post_seen = False

    def fake_post(self, path, body):
        nonlocal reflect_post_seen, records_post_seen
        if path == "/v1/agent/reflect_prompt":
            reflect_post_seen = True
            return _stub_reflect_payload()
        if path.startswith("/v1/records/"):
            records_post_seen = True
        return {}

    with patch.object(client_mod.NeruvaClient, "_post", fake_post):
        for i in range(3):
            hooks.after_tool_call(
                "tool",
                f"some output with enough text to pass min length filter {i}",
            )

    # 3 extracts + 1 reflect = 4 LLM calls
    assert len(llm.calls) == 4
    assert reflect_post_seen
    assert records_post_seen
    # Counter reset after firing
    assert hooks._tool_calls_since_reflect == 0


def test_after_session_with_empty_buffer_returns_empty_when_not_forced():
    from neruva_goose import NeruvaAutoPilot, NeruvaAutoPilotHooks

    ap = NeruvaAutoPilot(api_key="nv_x", namespace="t",
                         llm_callable=_StubLLM([]))
    hooks = NeruvaAutoPilotHooks(ap)
    assert hooks.after_session(force=False) == {}
