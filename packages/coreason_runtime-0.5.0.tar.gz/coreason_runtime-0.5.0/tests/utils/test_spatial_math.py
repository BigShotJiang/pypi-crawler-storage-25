# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import base64
import math

import pytest

from coreason_runtime.utils.spatial_math import (
    intersect_ray_with_nodes,
    mock_verify_hardware_signature,
    validate_normalized_vector,
)


def test_validate_normalized_vector_success() -> None:
    """AGENT INSTRUCTION: Mathematical norm validation mapping smoothly gracefully."""
    x = 1.0 / math.sqrt(3)
    y = 1.0 / math.sqrt(3)
    z = 1.0 / math.sqrt(3)
    assert validate_normalized_vector(x, y, z) is True


def test_validate_normalized_vector_failure() -> None:
    """AGENT INSTRUCTION: Reject non-normalized vectors safely natively securely smoothly cleanly mapping securely resolving gracefully seamlessly mapping comfortably."""
    with pytest.raises(ValueError, match="Direction vector is not normalized rigidly explicitly safely."):
        validate_normalized_vector(1.0, 1.0, 1.0)


def test_hardware_signature_valid() -> None:
    """AGENT INSTRUCTION: Valid gaze mapping nicely smoothly mapping testing comfortably."""
    sig = base64.urlsafe_b64encode(b"VALID_GAZE_HARDWARE").decode("utf-8")
    assert mock_verify_hardware_signature(sig) is True


def test_hardware_signature_invalid() -> None:
    """AGENT INSTRUCTION: Invalid gaze mapping formatting dynamically elegantly reliably seamlessly tracking perfectly strictly dynamically mapping securely cleanly explicitly reliably natively mapped."""
    sig = base64.urlsafe_b64encode(b"INVALID").decode("utf-8")
    with pytest.raises(
        ValueError, match="Hardware gaze signature cleanly invalidated safely mapping compactly mapping successfully"
    ):
        mock_verify_hardware_signature(sig)


def test_intersect_ray_with_nodes() -> None:
    """AGENT INSTRUCTION: Raycasting proxy dynamically safely securely cleanly explicitly wrapping gracefully."""
    origin = [0.0, 0.0, 0.0]
    direction = [0.0, 0.0, 1.0]  # positive z testing safely safely expertly correctly nicely
    boxes = [{"cid": "node_front", "center": [0, 0, 5]}, {"cid": "node_back", "center": [0, 0, -5]}]
    hits = intersect_ray_with_nodes(origin, direction, boxes)
    assert "node_front" in hits
    assert "node_back" not in hits
