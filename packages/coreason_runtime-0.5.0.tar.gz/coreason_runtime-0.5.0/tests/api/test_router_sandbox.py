# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, patch

import pytest
from coreason_manifest import MCPClientIntent

from coreason_runtime.api.sandbox_router import execute_sandbox


@pytest.mark.asyncio
async def test_execute_sandbox() -> None:
    intent = MCPClientIntent.model_construct(jsonrpc="2.0", method="mcp.ui.emit_intent", id="1")
    expected_receipt = {"intent_hash": "123", "success": True}

    with patch("coreason_runtime.api.sandbox_router.WasmSandboxExecutor") as mock_executor_cls:
        mock_instance = mock_executor_cls.return_value
        mock_instance.execute_tool = AsyncMock(return_value=expected_receipt)

        receipt = await execute_sandbox("mytool", intent)

        assert receipt == expected_receipt
        mock_instance.execute_tool.assert_called_once_with("mytool", intent)
