# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException

from coreason_runtime.api.sandbox_router import sync_state


@pytest.mark.asyncio
async def test_sync_state_payload_too_large_by_header() -> None:
    mock_request = MagicMock()
    mock_request.headers = {"content-length": str(256 * 1024 + 1)}

    with pytest.raises(HTTPException) as exc:
        await sync_state("wf_1", {}, mock_request)
    assert exc.value.status_code == 413
    assert exc.value.detail == "Payload Too Large"


@pytest.mark.asyncio
async def test_sync_state_payload_too_large_by_bytes() -> None:
    mock_request = MagicMock()
    mock_request.headers = {}

    large_payload = {"data": "x" * (256 * 1024 + 1)}
    with pytest.raises(HTTPException) as exc:
        await sync_state("wf_1", large_payload, mock_request)
    assert exc.value.status_code == 413
    assert exc.value.detail == "Payload Too Large"
