// Copyright (c) 2026 CoReason, Inc
//
// This software is proprietary and dual-licensed
// Licensed under the Prosperity Public License 3.0 (the "License")
// A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
// For details, see the LICENSE file
// Commercial use beyond a 30-day trial requires a separate license
//
// Source Code: <https://github.com/CoReason-AI/coreason-runtime>

#[no_mangle]
pub extern "C" fn run() -> i32 {
    let mut leak = Vec::new();
    loop {
        // Allocate continuously to force memory.grow trapped by bounds
        leak.push(vec![0u8; 1024 * 1024 * 10]); // 10 MB per loop
        unsafe { core::ptr::read_volatile(leak.as_ptr()) };
    }
}
