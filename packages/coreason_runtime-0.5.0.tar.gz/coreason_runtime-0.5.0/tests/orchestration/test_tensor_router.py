# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os

import pytest
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    EscalationContract,
    ManifestViolationReceipt,
    NeuroSymbolicHandoffContract,
    System1ReflexPolicy,
)

from coreason_runtime.tensor.router.epistemic_yield_error import EpistemicYieldError
from coreason_runtime.tensor.router.tensor_router import TensorRouter


@pytest.mark.asyncio
async def test_epistemic_yield_escalation() -> None:
    """AGENTS.md: No Mocks. Physical API attempts to non-existent localhost will throw physical exceptions.
    We assert that the physical Error triggers the deterministic EpistemicYieldError."""

    # Intentionally point to closed ports
    router = TensorRouter("http://127.0.0.1:49999")
    router.oracle_client.base_url = "http://127.0.0.1:49999"
    router.MAX_TOKENS = 500000

    profile = CognitiveAgentNodeProfile(
        description="Analyst",
        reflex_policy=System1ReflexPolicy(confidence_threshold=0.9, allowed_passive_tools=["search"]),
        escalation_policy=EscalationContract(
            uncertainty_escalation_threshold=0.8, max_latent_tokens_budget=5000, max_test_time_compute_ms=1000
        ),
    )

    with pytest.raises(EpistemicYieldError) as exc_info:
        await router.route_inference(
            workflow_id="test_wf", prompt="Hello", schema_class=ManifestViolationReceipt, agent_profile=profile
        )

    assert "Tier 2 Yielded:" in str(exc_info.value) or "Autonomic Cascade Failed" in str(exc_info.value)


@pytest.mark.asyncio
async def test_symbolic_handoff_bypass() -> None:
    """AGENTS.md: Test symbolic handoff policy without mocks via connection error propagation."""
    os.environ["DETERMINISTIC_SOLVER_URL"] = "http://127.0.0.1:49999/solve"
    router = TensorRouter("http://127.0.0.1:49999")

    profile = CognitiveAgentNodeProfile(
        description="Analyst",
        symbolic_handoff_policy=NeuroSymbolicHandoffContract(
            handoff_cid="h-123", solver_protocol="z3", formal_grammar_payload="valid syntax", timeout_ms=1000
        ),
    )

    with pytest.raises(EpistemicYieldError) as exc_info:
        await router.route_inference(
            workflow_id="test_wf", prompt="Hello", schema_class=ManifestViolationReceipt, agent_profile=profile
        )

    assert "Symbolic Handoff Failed" in str(exc_info.value)
