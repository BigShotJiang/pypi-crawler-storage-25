# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for TaxonomicRestructureWorkflow."""

from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.taxonomic_restructure_workflow import TaxonomicRestructureWorkflow


@activity.defn(name="BroadcastStateEchoIOActivity")
async def mock_broadcast_echo(event_type: str, payload: dict[str, Any]) -> None:
    pass


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state(
    workflow_id: str, event_cid: str, success: bool, holographic_payload: dict[str, Any], event_dict: dict[str, Any]
) -> None:
    pass


@pytest.mark.asyncio
async def test_taxonomic_restructure_workflow_success() -> None:
    """Test the full progression of the taxonomic restructuring workflow."""
    payload = {
        "restructure_heuristic": "semantic_cluster",
        "target_taxonomy": {
            "manifest_cid": "tax_test_1",
            "root_node_cid": "node1",
            "nodes": {"node1": {"node_cid": "node1", "semantic_label": "concept"}},
        },
    }

    # Needs to match coreason_manifest.spec.ontology.WorkflowManifest
    manifest_payload = {
        "manifest_cid": "workflow_manifest_1",
        "manifest_version": "1.0.0",
        "genesis_provenance": {"author_principal_cid": "auth", "source_event_cid": "src", "derivation_mode": "prompt"},
        "topology": {
            "topology_class": "evolutionary",
            "generations": 1,
            "population_size": 1,
            "mutation": {"mutation_rate": 0.1, "temperature_shift_variance": 0.1, "verifiable_entropy": None},
            "crossover": {"strategy_profile": "uniform_blend", "blending_factor": 0.1, "verifiable_entropy": None},
            "fitness_objectives": [{"target_metric": "acc", "direction": "maximize", "weight": 1.0}],
            "epistemic_enforcement": {
                "decay_propagation_rate": 0.1,
                "epistemic_quarantine_threshold": 0.5,
                "enforce_cross_agent_quarantine": False,
                "max_cascade_depth": 1,
                "max_quarantine_blast_radius": 1,
                "retroactive_falsification_mode": "cap_validity",
            },
            "lifecycle_phase": "live",
            "architectural_intent": "test",
            "justification": None,
            "nodes": {
                "did:coreason:agent01": {
                    "architectural_intent": None,
                    "justification": None,
                    "intervention_policies": [],
                    "description": "test",
                    "topology_class": "agent",
                    "hardware": {
                        "compute_tier": "KINETIC",
                        "min_vram_gb": 8.0,
                        "accelerator_type": "BF16_TENSOR",
                        "provider_whitelist": ["aws"],
                    },
                    "security": {
                        "epistemic_security": "STANDARD",
                        "network_isolation": False,
                        "egress_obfuscation": False,
                    },
                    "action_space_cid": "act1",
                }
            },
        },
    }

    # Mock Manifest
    mock_manifest = MagicMock()
    mock_manifest.topology.nodes = {"did:coreason:agent01": {}}

    # Mock Intent
    mock_intent = MagicMock()
    mock_intent.restructure_heuristic = "semantic_cluster"
    mock_intent.target_taxonomy.nodes = {"node1": {}}
    mock_intent.target_taxonomy.manifest_cid = "tax_test_1"
    mock_intent.target_taxonomy.root_node_cid = "node1"

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="taxonomic-test-queue",
            workflows=[TaxonomicRestructureWorkflow],
            activities=[mock_broadcast_echo, mock_store_epistemic_state],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            with (
                patch(
                    "coreason_runtime.orchestration.workflows.taxonomic_restructure_workflow.TaxonomicRestructureIntent.model_validate",
                    return_value=mock_intent,
                ),
                patch(
                    "coreason_runtime.orchestration.workflows.taxonomic_restructure_workflow.WorkflowManifest.model_validate",
                    return_value=mock_manifest,
                ),
            ):
                result = await env.client.execute_workflow(
                    TaxonomicRestructureWorkflow.run,
                    args=[payload, manifest_payload],
                    id="test-val-wf-tax-1",
                    task_queue="taxonomic-test-queue",
                )
            assert result["status"] == "success"
            assert "event_id" in result
