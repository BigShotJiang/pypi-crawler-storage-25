# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    ExecutionEnvelopeState,
    ExecutionNodeReceipt,
    SMPCTopologyManifest,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.smpc_execution_workflow import SMPCExecutionWorkflow


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def execute_tensor_inference_mock(*args: Any) -> dict[str, Any]:
    receipt = ExecutionNodeReceipt(request_cid="mock-request", inputs={}, outputs={"result": True}, node_hash="a" * 64)
    payload = receipt.model_dump(mode="json")
    payload["intent_hash"] = "a" * 64
    return payload


@activity.defn(name="StoreEpistemicStateIOActivity")
async def store_epistemic_mock(*args: Any) -> None:
    pass


@pytest.mark.asyncio
async def test_smpc_segregated_workers() -> None:
    manifest = SMPCTopologyManifest(
        participant_node_cids=["did:coreason:agent-partyA", "did:coreason:agent-partyB"],
        smpc_protocol="secret_sharing",
        joint_function_uri="smpc://test-uri",
        nodes={
            "did:coreason:agent-partyA": CognitiveAgentNodeProfile(description="Party A", topology_class="agent"),
            "did:coreason:agent-partyB": CognitiveAgentNodeProfile(description="Party B", topology_class="agent"),
        },
    )

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1, trace_cid="01H0000000000000000000000A", span_cid="01H0000000000000000000000B"
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )

    payload = envelope.model_dump(mode="json")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        # Create segregated workers for the distinctly isolated network nodes
        worker_a = Worker(
            env.client,
            task_queue="did:coreason:agent-partyA",
            activities=[execute_tensor_inference_mock, store_epistemic_mock],
        )
        worker_b = Worker(
            env.client, task_queue="did:coreason:agent-partyB", activities=[execute_tensor_inference_mock]
        )

        # Core Orchestrator Worker running the topology
        worker_orchestrator = Worker(
            env.client,
            task_queue="orchestrator-queue",
            workflows=[SMPCExecutionWorkflow],
            activities=[store_epistemic_mock],  # To handle Epistemic IO
            workflow_runner=UnsandboxedWorkflowRunner(),
        )

        # Run all workers concurrently
        async with worker_a, worker_b, worker_orchestrator:
            result = await env.client.execute_workflow(
                SMPCExecutionWorkflow.run,
                payload,
                id="smpc-test-workflow",
                task_queue="orchestrator-queue",
            )

            assert result["status"] == "success"
            assert result["participants"] == 2
            assert result["smpc_protocol"] == "secret_sharing"

            # 2 shares + 1 aggregator step = 3 results
            assert len(result["results"]) == 3
            types = [r.get("type") for r in result["results"]]
            assert types.count("share") == 2
            assert types.count("aggregation") == 1
