# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for System2RemediationWorkflow."""

from unittest.mock import MagicMock, patch

import pytest
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.system_2_remediation_workflow import (
    System2RemediationWorkflow,
    execute_node_regeneration_activity,
)


@pytest.mark.asyncio
async def test_system_2_remediation_workflow_success() -> None:
    """Test successful remediation."""
    payload = {"dummy": "payload"}

    # Mock Intent
    mock_intent = MagicMock()
    mock_intent.target_node_cid = "node1"
    mock_intent.fault_cid = "fault1"

    mock_receipt = MagicMock()
    mock_receipt.failing_pointer = "/some/pointer"
    mock_intent.violation_receipts = [mock_receipt]

    mock_ast = MagicMock()
    mock_ast.model_dump.return_value = {"actual_type_geometry": "mismatch"}
    mock_intent.ast_gradient = mock_ast

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sys2-test-queue",
            workflows=[System2RemediationWorkflow],
            activities=[execute_node_regeneration_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            with patch(
                "coreason_runtime.orchestration.workflows.system_2_remediation_workflow.System2RemediationIntent.model_validate",
                return_value=mock_intent,
            ):
                result = await env.client.execute_workflow(
                    System2RemediationWorkflow.run,
                    payload,
                    id="test-val-wf-sys2-1",
                    task_queue="sys2-test-queue",
                )

            assert result["status"] == "remediation_successful"
            assert result["attempts"] == 1


@pytest.mark.asyncio
async def test_system_2_remediation_workflow_failure() -> None:
    """Test remediation exhaustion."""
    payload = {"dummy": "payload"}

    # Mock Intent
    mock_intent = MagicMock()
    mock_intent.target_node_cid = "node1"
    mock_intent.fault_cid = "fault1"

    mock_receipt = MagicMock()
    mock_receipt.failing_pointer = "/some/pointer"
    mock_intent.violation_receipts = [mock_receipt]

    mock_ast = MagicMock()
    mock_ast.model_dump.return_value = {
        "actual_type_geometry": "none"
    }  # This will trigger failure in the real activity
    mock_intent.ast_gradient = mock_ast

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sys2-test-queue",
            workflows=[System2RemediationWorkflow],
            activities=[execute_node_regeneration_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            with patch(
                "coreason_runtime.orchestration.workflows.system_2_remediation_workflow.System2RemediationIntent.model_validate",
                return_value=mock_intent,
            ):
                with pytest.raises(WorkflowFailureError) as exc_info:
                    await env.client.execute_workflow(
                        System2RemediationWorkflow.run,
                        payload,
                        id="test-val-wf-sys2-2",
                        task_queue="sys2-test-queue",
                    )

            # temporalio wraps errors, so we verify the underlying error was our ApplicationError
            assert hasattr(exc_info.value, "cause")
            assert "VRAM bounds exceeded" in str(exc_info.value.cause)
