# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for the continuous active inference engine."""

import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.active_inference_execution_workflow import (
    ActiveInferenceExecutionWorkflow,
    evaluate_surprise_compute_activity,
    update_latent_belief_activity,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.mark.asyncio
async def test_active_inference_execution_workflow_success() -> None:
    """Test full convergence over multiple active inference epochs."""
    payload = {
        "active_inference_epochs": 3,
        "epoch_state": {
            "epoch_cid": "epoch_1",
            "target_objective_cid": "obj_1",
            "rejection_history": [],
            "current_free_energy": 1.0,
            "epoch_status": "active_inference_loop",
        },
        "contract": {
            "task_cid": "task_1",
            "target_hypothesis_cid": "hyp_1",
            "target_condition_cid": "cond_1",
            "selected_tool_name": "tool_1",
            "expected_information_gain": 0.5,
            "execution_cost_budget_magnitude": 100,
        },
    }
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="active-inference-test-queue",
            workflows=[ActiveInferenceExecutionWorkflow],
            activities=[evaluate_surprise_compute_activity, update_latent_belief_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(  # type: ignore
                ActiveInferenceExecutionWorkflow.run,
                payload,
                id="test-val-wf-1",
                task_queue="active-inference-test-queue",
            )
            assert result["success"] is True
            assert result["final_free_energy"] == 0.5
            assert result["epochs_run"] == 3


@pytest.mark.asyncio
async def test_active_inference_execution_workflow_failures() -> None:
    """Test rigorous schema conformance enforcement."""
    payload_bad_eval = {
        "active_inference_epochs": 1,
        "epoch_state": {},  # Missing required schema tags
        "contract": {},
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="active-inference-err-queue",
            activities=[evaluate_surprise_compute_activity],
        ):
            with pytest.raises(ManifestConformanceError) as exc_info:
                await evaluate_surprise_compute_activity(payload_bad_eval)  # type: ignore
            assert "Invalid ActiveInferenceEpochState" in str(exc_info.value)

    payload_bad_update = {
        "active_inference_epochs": 1,
        "contract": {},  # Missing required schema tags
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="active-inference-err-queue-2",
            activities=[update_latent_belief_activity],
        ):
            with pytest.raises(ManifestConformanceError) as exc_info:
                await update_latent_belief_activity(payload_bad_update)  # type: ignore
            assert "Invalid ActiveInferenceContract" in str(exc_info.value)
