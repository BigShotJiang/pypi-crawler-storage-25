from typing import Any

# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime
import pytest
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.system_2_remediation_workflow import (
    System2RemediationWorkflow,
    execute_node_regeneration_activity,
)


@pytest.fixture
def remediable_payload() -> dict[str, Any]:
    """Structurally compliant System2RemediationIntent simulating a fixable gradient."""
    return {
        "topology_class": "system_2_remediation",
        "fault_cid": "fault-100",
        "target_node_cid": "did:test:node-generator-1",
        "violation_receipts": [
            {
                "failing_pointer": "/step_2/parameters/0",
                "violation_category": "type_error",
                "diagnostic_message": "Expected string, got int",
            }
        ],
        "ast_gradient": {
            "compilation_attempt_cid": "did:test:compilation-1",
            "ast_node_pointer": "/step_2",
            "expected_type_geometry": "string",
            "actual_type_geometry": "int",
        },
    }


@pytest.fixture
def unrecoverable_payload() -> dict[str, Any]:
    """Structurally compliant payload causing persistent failure bounds."""
    return {
        "topology_class": "system_2_remediation",
        "fault_cid": "fault-101",
        "target_node_cid": "did:test:node-generator-1",
        "violation_receipts": [
            {
                "failing_pointer": "/step_1",
                "violation_category": "missing_key",
                "diagnostic_message": "Key 'data' not found",
            }
        ],
        "ast_gradient": {
            "compilation_attempt_cid": "did:test:compilation-1",
            "ast_node_pointer": "/step_1",
            "expected_type_geometry": "dict",
            "actual_type_geometry": "none",
        },
    }


@pytest.mark.asyncio
async def test_system_2_remediation_success(remediable_payload: dict) -> None:  # type: ignore
    """Ensure the workflow triggers remediation targeting exact RFC pointers and recovers."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="remediation-queue",
            workflows=[System2RemediationWorkflow],
            activities=[execute_node_regeneration_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                System2RemediationWorkflow.run,
                args=[remediable_payload],
                id="test-remediation-1",
                task_queue="remediation-queue",
            )
            assert result["status"] == "remediation_successful"
            assert result["attempts"] == 1


@pytest.mark.asyncio
async def test_system_2_remediation_exhaustion(unrecoverable_payload: dict) -> None:  # type: ignore
    """Proves the workflow executes bounded recursive retries but ultimately halts causing SystemFaultEvent."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="remediation-queue",
            workflows=[System2RemediationWorkflow],
            activities=[execute_node_regeneration_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    System2RemediationWorkflow.run,
                    args=[unrecoverable_payload],
                    id="test-remediation-2",
                    task_queue="remediation-queue",
                )

            assert "SystemFaultError" in str(exc_info.value.cause)
            assert "after 3 attempts" in str(exc_info.value.cause)
