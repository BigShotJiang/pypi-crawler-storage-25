from typing import Any

# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime
import pytest
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.epistemic_sop_execution_workflow import (
    EpistemicSOPExecutionWorkflow,
    evaluate_prm_contract_activity,
)


@pytest.fixture
def valid_sop_payload() -> dict[str, Any]:
    """Structurally valid EpistemicSOPManifest for testing standard sequential execution."""
    from coreason_manifest.spec.ontology import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

    return ExecutionEnvelopeState[dict[str, Any]](
        trace_context=TraceContextState(
            trace_cid="01H00000000000000000000001", span_cid="01H00000000000000000000002", causal_clock=0
        ),
        state_vector=StateVectorProfile(
            immutable_matrix={"tenant_cid": "test", "session_cid": "test"},
            mutable_matrix={"accumulated_tokens": 0, "accumulated_cost": 0.0, "iterations": 0, "compute_budget": 100},
            is_delta=False,
        ),
        payload={
            "sop_cid": "sop-testing-1",
            "target_persona": "test_persona",
            "cognitive_steps": {
                "step_1": {"urgency_index": 0.5, "caution_index": 0.5, "divergence_tolerance": 0.5},
                "step_2": {"urgency_index": 0.5, "caution_index": 0.5, "divergence_tolerance": 0.5},
            },
            "structural_grammar_hashes": {},
            "chronological_flow_edges": [["step_1", "step_2"]],
            "prm_evaluations": [
                {"pruning_threshold": 0.8, "max_backtracks_allowed": 3, "evaluator_matrix_name": "math-prm-v2"}
            ],
        },
    ).model_dump(mode="json")


@pytest.fixture
def malicious_sop_payload() -> dict[str, Any]:
    """EpistemicSOPManifest explicitly designed to trip the PRM circuit breaker during step_2."""
    from coreason_manifest.spec.ontology import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

    return ExecutionEnvelopeState[dict[str, Any]](
        trace_context=TraceContextState(
            trace_cid="01H00000000000000000000003", span_cid="01H00000000000000000000004", causal_clock=0
        ),
        state_vector=StateVectorProfile(
            immutable_matrix={"tenant_cid": "test", "session_cid": "test"},
            mutable_matrix={"accumulated_tokens": 0, "accumulated_cost": 0.0, "iterations": 0, "compute_budget": 100},
            is_delta=False,
        ),
        payload={
            "sop_cid": "sop-testing-2",
            "target_persona": "test_persona",
            "cognitive_steps": {
                "step_1": {"urgency_index": 0.5, "caution_index": 0.5, "divergence_tolerance": 0.5},
                "malicious_step": {"urgency_index": 0.5, "caution_index": 0.5, "divergence_tolerance": 0.5},
            },
            "structural_grammar_hashes": {},
            "chronological_flow_edges": [["step_1", "malicious_step"]],
            "prm_evaluations": [{"pruning_threshold": 0.8, "max_backtracks_allowed": 3}],
        },
    ).model_dump(mode="json")


@pytest.mark.asyncio
async def test_epistemic_sop_execution_success(valid_sop_payload: dict) -> None:  # type: ignore
    """Ensure that completely valid sequences pass PRM evaluations entirely."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sop-queue",
            workflows=[EpistemicSOPExecutionWorkflow],
            activities=[evaluate_prm_contract_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                EpistemicSOPExecutionWorkflow.run,
                args=[valid_sop_payload],
                id="valid-sop-test",
                task_queue="sop-queue",
            )
            assert result["status"] == "sop_execution_completed"
            assert result["executed_nodes"] == ["step_1", "step_2"]


@pytest.mark.asyncio
async def test_epistemic_sop_execution_fails_prm(malicious_sop_payload: dict) -> None:  # type: ignore
    """Ensure that PRM violations explicitly trigger ManifestConformanceError and halt execution."""
    async with await WorkflowEnvironment.start_local() as env:
        async with Worker(
            env.client,
            task_queue="sop-queue",
            workflows=[EpistemicSOPExecutionWorkflow],
            activities=[evaluate_prm_contract_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    EpistemicSOPExecutionWorkflow.run,
                    args=[malicious_sop_payload],
                    id="malicious-sop-test",
                    task_queue="sop-queue",
                )
            assert "ManifestConformanceError" in str(exc_info.value.cause)
            assert "failed Process Reward Model (PRM) pruning bounds" in str(exc_info.value.cause)
