# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>


import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.active_inference_execution_workflow import (
    ActiveInferenceExecutionWorkflow,
    ActiveInferencePayload,
    evaluate_surprise_compute_activity,
    update_latent_belief_activity,
)


@pytest.mark.asyncio
async def test_continue_as_new_rehydration_merkle_dag() -> None:
    """AGENTS.md: O(1) Rehydration via ContinueAsNew
    Test that when a continuous loop respawns after reaching event history bounds,
    the precise SHA-256 hash of the serialized snapshot is injected."""

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="test-rehydration-queue",
            workflows=[ActiveInferenceExecutionWorkflow],
            activities=[evaluate_surprise_compute_activity, update_latent_belief_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            payload = ActiveInferencePayload(
                epoch_state={"belief_matrix": [0.1, 0.2]},
                contract={"threshold": 0.05},
                active_inference_epochs=20,  # 20 epochs will easily exceed 50 history events
                free_energy=1.0,
            )

            # Execute the workflow to completion. Temporal will natively chain the continue_as_new invocations.
            result = await env.client.execute_workflow(
                ActiveInferenceExecutionWorkflow.run,
                payload,
                id="rehydration-test-workflow",
                task_queue="test-rehydration-queue",
            )

            # Assert Merkle-DAG properties reached the end of the chain securely
            assert "rehydrated_hash" in result
            hash_val = result["rehydrated_hash"]
            assert isinstance(hash_val, str)
            assert len(hash_val) == 64  # SHA-256 length indicates successful O(1) Rehydration chain
            assert result["success"] is True
