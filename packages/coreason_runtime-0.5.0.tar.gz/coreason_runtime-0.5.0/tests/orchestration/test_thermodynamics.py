# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import math

import pytest
from pydantic import BaseModel


class _MockThermodynamicBounds(BaseModel):
    min_entropy_threshold: float = 0.5


class _MockFreeEnergyExhaustion(BaseModel):
    pass


# These models must be patched BEFORE thermodynamics.py is imported because
# FreeEnergyExhaustion does not exist in the current coreason_manifest version.
# This is an import-time dependency that cannot use pytest fixtures.
import coreason_manifest.spec.ontology as m_ontology

_original_thermodynamic_bounds = getattr(m_ontology, "ThermodynamicBounds", None)
_original_free_energy_exhaustion = getattr(m_ontology, "FreeEnergyExhaustion", None)

m_ontology.ThermodynamicBounds = _MockThermodynamicBounds  # type: ignore[attr-defined]
m_ontology.FreeEnergyExhaustion = _MockFreeEnergyExhaustion  # type: ignore[attr-defined]

from coreason_runtime.orchestration.thermodynamics import evaluate_thermodynamic_exhaustion_activity
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.fixture(autouse=True)
def _restore_ontology_after_test():  # type: ignore
    """Ensure mock models are set before each test and restore originals after the module finishes."""
    # Re-apply mocks in case a previous test restored them
    m_ontology.ThermodynamicBounds = _MockThermodynamicBounds  # type: ignore[attr-defined]
    m_ontology.FreeEnergyExhaustion = _MockFreeEnergyExhaustion  # type: ignore[attr-defined]
    yield
    # Restore originals to prevent bleed into other test modules
    if _original_thermodynamic_bounds is not None:
        m_ontology.ThermodynamicBounds = _original_thermodynamic_bounds  # type: ignore[attr-defined]
    elif hasattr(m_ontology, "ThermodynamicBounds"):
        delattr(m_ontology, "ThermodynamicBounds")
    if _original_free_energy_exhaustion is not None:
        m_ontology.FreeEnergyExhaustion = _original_free_energy_exhaustion  # type: ignore[attr-defined]
    elif hasattr(m_ontology, "FreeEnergyExhaustion"):
        delattr(m_ontology, "FreeEnergyExhaustion")


@pytest.mark.asyncio
async def test_evaluate_thermodynamic_exhaustion_high_entropy() -> None:
    """High entropy (4 distinct states) should pass without raising."""
    epistemic_history = ["state_a", "state_b", "state_c", "state_d"]
    bounds_payload = {"min_entropy_threshold": 0.5}

    entropy = await evaluate_thermodynamic_exhaustion_activity(epistemic_history, bounds_payload)

    # 4 distinct states -> uniformly distributed -> -4 * (0.25 * log2(0.25)) = 2.0
    assert math.isclose(entropy, 2.0)


@pytest.mark.asyncio
async def test_evaluate_thermodynamic_exhaustion_low_entropy_raises() -> None:
    """Repeated identical states should raise ManifestConformanceError."""
    epistemic_history = ["state_a", "state_a", "state_a", "state_a"]
    bounds_payload = {"min_entropy_threshold": 0.5}

    with pytest.raises(ManifestConformanceError, match="Free Energy Exhausted"):
        await evaluate_thermodynamic_exhaustion_activity(epistemic_history, bounds_payload)


@pytest.mark.asyncio
async def test_evaluate_thermodynamic_exhaustion_empty_history() -> None:
    """Empty history should return 0.0 entropy."""
    epistemic_history: list[str] = []
    bounds_payload = {"min_entropy_threshold": 0.5}

    entropy = await evaluate_thermodynamic_exhaustion_activity(epistemic_history, bounds_payload)
    assert entropy == 0.0
