# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import Any

import pytest
from temporalio import activity
from temporalio.exceptions import ApplicationError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker
from temporalio.worker.workflow_sandbox import SandboxRestrictions

from coreason_runtime.orchestration.worker import TASK_QUEUE
from coreason_runtime.orchestration.workflows import SwarmExecutionWorkflow


@pytest.fixture
def swarm_manifest() -> dict[str, Any]:
    return {
        "topology_class": "swarm",
        "nodes": {
            "did:test:agent-1-swarm": {
                "topology_class": "agent",
                "description": "A helpful swarm agent.",
            }
        },
    }


# --- Mock activities ---


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def mock_execute_tensor_inference_yield(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Returns epistemic_yield to trigger Oracle escalation path."""
    return {
        "node_cid": "mock-node",
        "status": "epistemic_yield",
        "intent_hash": "mock-hash",
        "success": False,
        "result": {"output": "Epistemic yield triggered"},
    }


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "success", "vector_id": "mock-123"}


@activity.defn(name="ExecuteMCPToolIOActivity")
async def mock_execute_mcp_tool_fault(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Raises a SemanticFirewallPolicyError to simulate Bipartite Graph Separation violation."""
    raise ApplicationError(
        "Mathematical bounds violation: Mutually Exclusive Traversal",
        non_retryable=True,
        type="SemanticFirewallPolicyError",
    )


@activity.defn(name="EmitResumedEventIOActivity")
async def mock_emit_resumed_event_activity(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "resumed"}


@activity.defn(name="ExecuteResolveAuctionComputeActivity")
async def mock_execute_resolve_auction(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"escrow": {"escrow_locked_magnitude": 10}}


@activity.defn(name="execute_process_slashing")
async def mock_execute_process_slashing(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"penalty_amount": 0}


@activity.defn(name="RequestOracleInterventionIOActivity")
async def mock_request_oracle_intervention(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "success"}


@activity.defn(name="settle_prediction_market")
async def mock_settle_prediction_market(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "settled"}


@activity.defn(name="AnnounceTaskIOActivity")
async def mock_announce_task(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return _args[0] if _args else {}


@activity.defn(name="ExecuteMarketContractComputeActivity")
async def mock_execute_market_contract(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "success", "penalty_amount": 0}


@activity.defn(name="ExecuteSettlePredictionMarketComputeActivity")
async def mock_execute_settle_prediction_market(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return _args[0] if _args else {}


@activity.defn(name="BroadcastStateEchoIOActivity")
async def mock_broadcast_state_echo(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"status": "echoed"}


COMMON_ACTIVITIES = [
    mock_execute_tensor_inference_yield,
    mock_store_epistemic_state,
    mock_emit_resumed_event_activity,
    mock_execute_resolve_auction,
    mock_execute_process_slashing,
    mock_request_oracle_intervention,
    mock_settle_prediction_market,
    mock_announce_task,
    mock_execute_market_contract,
    mock_execute_settle_prediction_market,
    mock_broadcast_state_echo,
]


@pytest.mark.asyncio
async def test_workflow_graceful_degradation_toxic_combination(swarm_manifest: dict[str, Any]) -> None:
    """Test 1: Toxic Combination - Simulate Bipartite Graph Separation violation.

    The workflow receives an epistemic_yield from inference, escalates to Oracle,
    receives an oracle override signal, then calls execute_mcp_tool_io_activity which raises
    ApplicationError. The workflow catches it and returns epistemic_yield with the fault.
    """
    from temporalio.worker.workflow_sandbox import SandboxedWorkflowRunner

    async with (
        await WorkflowEnvironment.start_time_skipping() as env,
        Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[SwarmExecutionWorkflow],
            activities=[
                *COMMON_ACTIVITIES,
                mock_execute_mcp_tool_fault,  # Fault variant for MCP tool
            ],
            workflow_runner=SandboxedWorkflowRunner(
                restrictions=SandboxRestrictions.default.with_passthrough_all_modules()
            ),
        ),
    ):
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = "018e69ac-5591-7f0b-9c76-556bede63287"
        state_vector = StateVectorProfile(immutable_matrix={}, mutable_matrix={"compute_budget": 1000}, is_delta=False)
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=state_vector,
            payload=swarm_manifest,
        ).model_dump(mode="json")

        handle = await env.client.start_workflow(
            SwarmExecutionWorkflow.run,
            envelope,
            id="test-resilience-toxic",
            task_queue=TASK_QUEUE,
        )

        # Send the oracle override signal with a corrected MCP intent.
        # This triggers the oracle escalation path:
        #   inference returns epistemic_yield → oracle intervention requested
        #   → wait_condition waits for oracle override → this signal fires
        #   → execute_mcp_tool_io_activity is called → raises ApplicationError → caught → epistemic_yield returned
        await handle.signal(
            "receive_oracle_override",
            {
                "jsonrpc": "2.0",
                "method": "mcp.ui.emit_intent",
                "params": {"name": "test_tool", "arguments": {"human_decision": "proceed"}},
                "id": "123",
            },
        )

        result = await handle.result()

        # The workflow catches ActivityError (which wraps the ApplicationError) and yields
        agent_result = result["results"][0]
        assert agent_result["status"] == "epistemic_yield"
        assert "Activity task failed" in agent_result["fault"]


@pytest.mark.asyncio
async def test_workflow_graceful_degradation_thermodynamic_burnout(swarm_manifest: dict[str, Any]) -> None:
    """Test 2: Thermodynamic Burnout - Simulate BudgetExceededError.

    Same escalation path as test 1, but with a budget-exhaustion fault from execute_mcp_tool_io_activity.
    Uses a locally-defined activity mock that raises BudgetExceededError.
    """
    from temporalio.worker.workflow_sandbox import SandboxedWorkflowRunner

    @activity.defn(name="ExecuteMCPToolIOActivity")
    async def _mcp_tool_budget_fault(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
        raise ApplicationError(
            "Mathematical bounds violation: Semantic Budget Exhaustion",
            non_retryable=True,
            type="BudgetExceededError",
        )

    async with (
        await WorkflowEnvironment.start_time_skipping() as env,
        Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[SwarmExecutionWorkflow],
            activities=[
                *COMMON_ACTIVITIES,
                _mcp_tool_budget_fault,  # Budget fault variant (locally defined)
            ],
            workflow_runner=SandboxedWorkflowRunner(
                restrictions=SandboxRestrictions.default.with_passthrough_all_modules()
            ),
        ),
    ):
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = "018e69ac-5591-7f0b-9c76-556bede63287"
        state_vector = StateVectorProfile(immutable_matrix={}, mutable_matrix={"compute_budget": 1000}, is_delta=False)
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=state_vector,
            payload=swarm_manifest,
        ).model_dump(mode="json")

        handle = await env.client.start_workflow(
            SwarmExecutionWorkflow.run,
            envelope,
            id="test-resilience-budget",
            task_queue=TASK_QUEUE,
        )

        # Send the oracle override signal to trigger the MCP tool execution path
        await handle.signal(
            "receive_oracle_override",
            {
                "jsonrpc": "2.0",
                "method": "mcp.ui.emit_intent",
                "params": {"name": "budget_tool", "arguments": {}},
                "id": "456",
            },
        )

        result = await handle.result()

        # The workflow catches ActivityError (which wraps the ApplicationError) and yields
        agent_result = result["results"][0]
        assert agent_result["status"] == "epistemic_yield"
        assert "Activity task failed" in agent_result["fault"]
