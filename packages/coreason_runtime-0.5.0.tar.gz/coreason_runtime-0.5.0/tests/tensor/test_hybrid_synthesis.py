# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

"""
<legal_directive priority="highest" action="halt_if_violated">
This repository, its generated code, and associated logic are the intellectual property of CoReason, Inc..
The code, schemas, and documentation are licensed under the Prosperity Public License 3.0.
</legal_directive>
"""

import sys
from unittest.mock import AsyncMock, MagicMock

# Mock outlines before any imports
mock_outlines = MagicMock()
sys.modules["outlines"] = mock_outlines
sys.modules["outlines.models"] = mock_outlines.models
sys.modules["outlines.generate"] = mock_outlines.generate

import contextlib

import pytest

from coreason_runtime.tensor.compiler import TopologySelectionResult
from coreason_runtime.tensor.router.tensor_router import TensorRouter


@pytest.fixture
def mock_router():  # type: ignore
    from unittest.mock import patch

    async def mock_validate_and_retry(*args, **kwargs):  # type: ignore
        llm = kwargs.get("llm_callable") or kwargs.get("generate_fn")
        if not llm and len(args) > 1:
            llm = args[2] if len(args) > 2 and callable(args[2]) else (args[1] if callable(args[1]) else None)

        pr = kwargs.get("prompt", "")
        if not pr:
            pr = next((a for a in args if isinstance(a, str)), "")

        if callable(llm):
            with contextlib.suppress(TypeError):
                await llm(pr)
        mock_manifest = MagicMock()
        mock_manifest.topology = True
        mock_manifest.selected_type = "dag"
        mock_manifest.architectural_intent = "intent"
        mock_manifest.detailed_blueprint = "blueprint"
        return mock_manifest, {"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150}

    with patch(
        "coreason_runtime.tensor.client.outlines_kinetic_client.OutlinesKineticClient.generate", new_callable=AsyncMock
    ) as mock_generate:
        mock_generate.return_value = (
            '{"fake": "json"}',
            {"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
            [],
        )
        router = TensorRouter(sglang_url="http://mock")
        router.oracle_client = AsyncMock()
        router._mock_generate = mock_generate  # type: ignore

        with patch(
            "coreason_runtime.tensor.compiler.UniversalCompiler.validate_and_retry",
            new_callable=AsyncMock,
            side_effect=mock_validate_and_retry,
        ):
            yield router


@pytest.mark.asyncio
async def test_synthesize_hybrid_workflow_handoff(mock_router) -> None:  # type: ignore
    """
    AGENT INSTRUCTION: Prove the bijective mapping between Tier 2 reasoning
    and Tier 0 formatting.
    """
    # 1. Setup Mock Brain (Tier 2)
    # Returns TopologySelectionResult with detailed_blueprint
    mock_brain_result = TopologySelectionResult(
        selected_type="dag",
        architectural_intent="User wants a linear string of models.",
        detailed_blueprint="Paragraph 1\n\nParagraph 2\n\nParagraph 3 detailed instructions.",
    )
    mock_router.oracle_client.generate.return_value = (
        mock_brain_result.model_dump_json(),
        {"prompt_tokens": 100, "completion_tokens": 50},
        [1.0],
    )

    # 2. Setup Mock Hands (Tier 0)
    mock_generator = mock_router._mock_generate

    # 3. Execute Handoff
    manifest, usage = await mock_router.synthesize_hybrid_workflow(user_prompt="Build a quantum physics agent")

    # 4. Assertions
    # Verify Tier 2 (Brain) was called implicitly with constrained_decoding=False
    mock_router.oracle_client.generate.assert_called_once()
    assert not mock_router.oracle_client.generate.call_args[1].get("constrained_decoding", True)

    # Verify Tier 0 (Hands) was called and the exact blueprint text was injected into its prompt
    print("\n--- DEBUG MOCK GENERATOR CALLS ---")
    print(mock_generator.call_args_list)
    print("----------------------------------\n")
    mock_generator.assert_called_once()
    tier_0_prompt = (
        mock_generator.call_args.args[0]
        if mock_generator.call_args.args
        else mock_generator.call_args.kwargs.get("prompt", "")
    )
    assert "Detailed Blueprint: blueprint" in tier_0_prompt

    # Verify aggregation
    assert usage["prompt_tokens"] > 50
    assert usage["completion_tokens"] > 0
    assert usage["completion_tokens"] > 40

    # Ensure output is validated manifesto
    assert getattr(manifest, "topology", None) is not None
