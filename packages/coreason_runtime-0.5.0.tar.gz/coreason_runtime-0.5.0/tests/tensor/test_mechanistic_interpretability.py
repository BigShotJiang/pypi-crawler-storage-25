# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import math
from unittest.mock import AsyncMock, patch

import pytest
from coreason_manifest import CognitiveAgentNodeProfile
from pydantic import BaseModel

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.tensor.router.epistemic_yield_error import EpistemicYieldError
from coreason_runtime.tensor.router.tensor_router import TensorRouter


class DummySchema(BaseModel):
    conclusion: str


@pytest.fixture
def mock_tensor_router():  # type: ignore
    with (
        patch("coreason_runtime.tensor.router.tensor_router.SGLangKineticClient"),
        patch("coreason_runtime.tensor.router.tensor_router.CloudOracleClient"),
    ):
        return TensorRouter("http://localhost:30000")


@pytest.fixture
def mock_kinetic_activities():  # type: ignore
    return KineticActivities(
        sglang_url="http://localhost:30000",
        memory_path="/tmp/test_ledger",
        plugins_dir="/tmp/plugins",
        telemetry_url="http://localhost:8080/metrics",
    )


def test_tensor_router_smoothing_functions(mock_tensor_router) -> None:  # type: ignore
    """AGENT INSTRUCTION: Verify that the OutlinesKineticClient correctly receives steering vectors and that the TensorRouter applies the requested LatentSmoothingProfile attenuation (Linear/Exponential/Cosine)."""

    # Linear: 1 - (t / T)
    linear_val = mock_tensor_router._calculate_latent_smoothing(t=50, duration=100, decay_rate=0.1, strategy="linear")
    assert math.isclose(linear_val, 0.5)

    # Exponential: e^(-lambda * t)
    exp_val = mock_tensor_router._calculate_latent_smoothing(t=10, duration=100, decay_rate=0.1, strategy="exponential")
    assert math.isclose(exp_val, math.exp(-1.0))

    # Cosine Annealing: 0.5 * (1 + cos(pi * t / T))
    cos_val = mock_tensor_router._calculate_latent_smoothing(
        t=50, duration=100, decay_rate=0.1, strategy="cosine_annealing"
    )
    assert math.isclose(cos_val, 0.5)

    # T <= 0 boundary
    zero_t = mock_tensor_router._calculate_latent_smoothing(t=10, duration=0, decay_rate=0.1, strategy="linear")
    assert math.isclose(zero_t, 1.0)


@pytest.mark.asyncio
async def test_tensor_router_firewall_trip(mock_tensor_router) -> None:  # type: ignore
    """AGENT INSTRUCTION: Mock a high-magnitude activation of a 'forbidden' SAE feature (e.g., sycophancy) and assert that the SaeLatentPolicy trips the circuit breaker, returning an epistemic_yield."""

    # Mock usage containing layer_activations with high magnitude
    raw_usage = {
        "prompt_tokens": 10,
        "completion_tokens": 5,
        "layer_activations": {
            "layer_10": [
                {"feature_index": 666, "magnitude": 15.0}  # Breach!
            ]
        },
    }

    with patch(
        "coreason_runtime.tensor.compiler.UniversalCompiler.validate_and_retry", new_callable=AsyncMock
    ) as mock_validate:
        mock_validate.return_value = (DummySchema(conclusion="Test"), raw_usage)

        agent_profile = CognitiveAgentNodeProfile(
            topology_class="agent",
            description="Mechanistic node",
            compute_frontier=None,
        )
        from unittest.mock import MagicMock

        agent_profile.__dict__["reflex_policy"] = MagicMock()
        mock_fw = MagicMock()
        mock_rule = MagicMock()
        mock_rule.target_layer = 10
        mock_rule.target_feature_index = 666
        mock_rule.max_activation_threshold = 10.0
        mock_rule.violation_action = "halt"
        mock_fw.policies = [mock_rule]
        mock_fw.model_dump.return_value = [
            {
                "target_layer": 10,
                "target_feature_index": 666,
                "max_activation_threshold": 10.0,
                "violation_action": "halt",
            }
        ]
        agent_profile.__dict__["latent_firewalls"] = mock_fw

        with pytest.raises(EpistemicYieldError) as exc_info:
            await mock_tensor_router.route_inference(
                workflow_id="wf_123",
                prompt="Check toxic markers.",
                schema_class=DummySchema,
                agent_profile=agent_profile,
            )

        assert "mechanistic_firewall_trip" in str(exc_info.value) or "mechanistic_firewall_trip" in str(
            exc_info.value.__cause__
        )
