# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for telemetry broker."""

import asyncio
import json
from collections.abc import Generator
from unittest.mock import AsyncMock, patch

import pytest
from coreason_manifest.spec.ontology import AmbientState, EpistemicTelemetryEvent
from httpx import ASGITransport, AsyncClient

from coreason_runtime.telemetry.broker import _active_clients, app, lifespan


@pytest.fixture(autouse=True)
def clean_broker_state() -> Generator[None]:
    """Ensure _active_clients is clear before each test."""
    _active_clients.clear()
    yield
    _active_clients.clear()


@pytest.mark.asyncio
async def test_push_telemetry() -> None:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        # Create a mock queue
        q: asyncio.Queue[str] = asyncio.Queue()
        _active_clients.append(q)

        event = EpistemicTelemetryEvent(
            event_cid="event-1",
            prior_event_hash="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            timestamp=1678888888.0,
            topology_class="epistemic_telemetry",
            interaction_modality="expansion",
            target_node_cid="node-1",
            dwell_duration_ms=100,
        )
        response = await client.post("/api/v1/telemetry/push", json=event.model_dump(mode="json"))
        assert response.status_code == 200
        assert response.json()["status"] == "ok"

        # Verify the event reached the queue
        msg = await asyncio.wait_for(q.get(), timeout=1.0)
        assert json.loads(msg) == event.model_dump(mode="json")


@pytest.mark.asyncio
async def test_push_ambient_state() -> None:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        # Create a mock queue
        q: asyncio.Queue[str] = asyncio.Queue()
        _active_clients.append(q)

        ambient = AmbientState(
            status_message="ok", progress=0.5, thermodynamic_burn_rate=1.0, epistemic_entropy_score=0.1
        )
        response = await client.post("/api/v1/telemetry/ambient", json=ambient.model_dump(mode="json"))
        assert response.status_code == 200
        assert response.json()["status"] == "ok"

        # Verify the ambient state
        msg = await asyncio.wait_for(q.get(), timeout=1.0)
        parsed = json.loads(msg)
        assert parsed["type"] == "AmbientState"
        assert parsed["data"] == ambient.model_dump(mode="json")


@pytest.mark.asyncio
async def test_stream_telemetry_disconnect() -> None:
    from coreason_runtime.telemetry.broker import sse_generator, stream_telemetry

    response = await stream_telemetry()
    assert len(_active_clients) == 1
    queue = _active_clients[0]
    assert response.media_type == "text/event-stream"

    gen = sse_generator(queue)
    object.__setattr__(queue, "get", AsyncMock(side_effect=asyncio.CancelledError))

    with pytest.raises(asyncio.CancelledError):
        await gen.__anext__()

    assert queue not in _active_clients


@pytest.mark.asyncio
async def test_stream_telemetry_throttled_disconnect() -> None:
    from coreason_runtime.telemetry.broker import backpressure_sse_generator, stream_telemetry_throttled

    response = await stream_telemetry_throttled(hz=60.0)
    assert len(_active_clients) == 1
    queue = _active_clients[0]
    assert response.media_type == "text/event-stream"

    gen = backpressure_sse_generator(queue, 60.0)
    object.__setattr__(queue, "get", AsyncMock(side_effect=asyncio.CancelledError))

    with pytest.raises(asyncio.CancelledError):
        await gen.__anext__()

    assert queue not in _active_clients


@pytest.mark.asyncio
async def test_broker_queue_full_suppression() -> None:
    # Test queue full / empty blocks by mocking QueueFull during push.
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        # Create a mock queue with size 1 to force full
        q: asyncio.Queue[str] = asyncio.Queue(maxsize=1)
        _active_clients.append(q)

        # Fill it
        await q.put("junk")

        # Since it is full, next put triggers QueueFull and suppresses the old junk
        event = EpistemicTelemetryEvent(
            event_cid="event-for-queue",
            prior_event_hash="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            timestamp=1678888888.0,
            topology_class="epistemic_telemetry",
            interaction_modality="expansion",
            target_node_cid="node-1",
            dwell_duration_ms=100,
        )
        response = await client.post("/api/v1/telemetry/push", json=event.model_dump(mode="json"))
        assert response.status_code == 200

        # Verify the new event replaced the old one
        msg = await asyncio.wait_for(q.get(), timeout=1.0)
        assert json.loads(msg) == event.model_dump(mode="json")


@pytest.mark.asyncio
async def test_stream_telemetry_throttled_backpressure() -> None:
    import time

    from coreason_runtime.telemetry.broker import backpressure_sse_generator

    queue: asyncio.Queue[str] = asyncio.Queue()
    _active_clients.append(queue)

    # Set to 10 Hz (0.1s minimum delay)
    gen = backpressure_sse_generator(queue, focal_refresh_rate_hz=10.0)

    await queue.put("msg1")
    await queue.put("msg2")

    start_time = time.monotonic()

    msg1 = await gen.__anext__()
    assert msg1 == "data: msg1\n\n"

    msg2 = await gen.__anext__()
    assert msg2 == "data: msg2\n\n"

    end_time = time.monotonic()

    # Since we enforce backpressure, extracting two messages sequentially
    # immediately back-to-back should span at least the interval (0.1 seconds bounds).
    # Since the first message takes almost 0 time (last_yield_time was 0),
    # the sleep for the second message will take > 0.09
    assert (end_time - start_time) > 0.08


@pytest.mark.asyncio
async def test_broker_lifespan() -> None:
    async with lifespan(app):
        # Allow the task to spawn
        await asyncio.sleep(0.01)

    # Exiting the block cancels the task
    assert True


@pytest.mark.asyncio
async def test_push_telemetry_exception() -> None:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        with patch("coreason_runtime.telemetry.broker.json.dumps", side_effect=ValueError("Test JSON error")):
            ambient = AmbientState(
                status_message="ok", progress=1.0, thermodynamic_burn_rate=2.0, epistemic_entropy_score=0.2
            )
            response = await client.post("/api/v1/telemetry/push", json=ambient.model_dump(mode="json"))
            assert response.status_code == 200
            assert response.json()["status"] == "error"
            assert "Test JSON error" in response.json()["message"]


@pytest.mark.asyncio
async def test_stream_telemetry_actual() -> None:
    from coreason_runtime.telemetry.broker import sse_generator

    q: asyncio.Queue[str] = asyncio.Queue()
    gen = sse_generator(q)
    await q.put("test_message")

    msg = await gen.__anext__()
    assert msg == "data: test_message\n\n"
