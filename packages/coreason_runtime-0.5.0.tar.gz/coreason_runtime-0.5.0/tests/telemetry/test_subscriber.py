# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for telemetry subscriber."""

import asyncio
import shutil
import tempfile
from collections.abc import Generator

import pytest
from coreason_manifest.spec.ontology import EpistemicTelemetryEvent

from coreason_runtime.telemetry.broker import _active_clients
from coreason_runtime.telemetry.subscriber import bronze_ingestion_loop


@pytest.fixture(autouse=True)
def clean_broker_state(monkeypatch: pytest.MonkeyPatch) -> Generator[None]:
    """Use a short temp directory to stay within Windows MAX_PATH (260 chars).

    pytest's ``tmp_path`` embeds the full test function name which, combined
    with dlt's ``_dlt_pipeline_state`` hash-based filenames, can exceed the
    limit and trigger ``FileNotFoundError`` on Windows.
    """
    _active_clients.clear()
    short_dir = tempfile.mkdtemp(prefix="cr_")
    monkeypatch.chdir(short_dir)
    monkeypatch.setenv("DLT_DATA_DIR", short_dir)
    yield
    _active_clients.clear()
    shutil.rmtree(short_dir, ignore_errors=True)


def _create_test_event(event_id: str) -> EpistemicTelemetryEvent:
    return EpistemicTelemetryEvent(
        event_cid=event_id,
        prior_event_hash="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        timestamp=1678888888.0,
        topology_class="epistemic_telemetry",
        interaction_modality="expansion",
        target_node_cid="node-abc",
        dwell_duration_ms=10,
    )


@pytest.mark.asyncio
async def test_bronze_ingestion_batch_boundary() -> None:
    # We start the loop as a task
    task = asyncio.create_task(bronze_ingestion_loop(batch_size=2))

    # Give the loop time to bind and append queue
    await asyncio.sleep(0.01)

    assert len(_active_clients) == 1
    queue = _active_clients[0]

    event1 = _create_test_event("msg1")
    event2 = _create_test_event("msg2")

    # Add 1 valid JSON
    await queue.put(event1.model_dump_json())
    # Not yet flushed
    await asyncio.sleep(0.01)

    # Verify no physical directories created yet (dlt only writes on run())
    # Note: dlt might create the pipeline folder but not the dataset tables yet if not run

    # Add 1 invalid JSON string (should be safely ignored)
    await queue.put("this is invalid json")
    await asyncio.sleep(0.01)

    # Add 1 valid JSON (triggers flush of batch of 2)
    await queue.put(event2.model_dump_json())

    # Give physical FFI enough time to write to parquet
    await asyncio.sleep(1.0)

    # Verify physical file was written to disk
    import dlt

    p = dlt.pipeline(pipeline_name="epistemic_exhaust")
    assert p.dataset_name == "telemetry"

    # Cancel task
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


@pytest.mark.asyncio
async def test_bronze_ingestion_cancellation_flush() -> None:
    # We start the loop as a task
    task = asyncio.create_task(bronze_ingestion_loop(batch_size=10))
    await asyncio.sleep(0.01)

    queue = _active_clients[0]
    event = _create_test_event("orphan")
    await queue.put(event.model_dump_json())
    await asyncio.sleep(0.01)

    # Cancel before reaching batch size 10
    task.cancel()

    try:
        await task
    except asyncio.CancelledError:
        pass

    # Give FFI time to close
    await asyncio.sleep(0.5)

    # Verify the leftover buffer was physically flushed when cancelled!
    import dlt

    p = dlt.pipeline(pipeline_name="epistemic_exhaust")
    assert p.dataset_name == "telemetry"
