# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from coreason_manifest.spec.ontology import ContinuousObservationState, StreamingDisfluencyContract

from coreason_runtime.telemetry.events.continuous_stream_buffer import StreamBufferManager


def test_continuous_stream_buffer_crdt_determinism() -> None:
    """Verifies that mathematical token decay is 100% deterministic (No divergent CRDT state forks)."""

    # Simulate 1000 noisy inputs containing disfluency "um"
    dirty_tokens = ["um", "wait", "um", "valid", "text", "um"] * 166 + ["um", "valid", "um", "um"]
    assert len(dirty_tokens) == 1000

    state1 = ContinuousObservationState(
        stream_cid="obs_1",
        temporal_decay_matrix={},
        latest_confidence_score=0.99,
        token_buffer=dirty_tokens,
    )

    state2 = ContinuousObservationState(
        stream_cid="obs_1",
        temporal_decay_matrix={},
        latest_confidence_score=0.99,
        token_buffer=dirty_tokens.copy(),
    )

    contract = StreamingDisfluencyContract(repair_marker_regex=r"^um$", decay_threshold=0.5, max_lookback_window=1000)

    # Apply the forget gate independently
    pruned1 = StreamBufferManager.apply_forget_gate(state1, contract)
    pruned2 = StreamBufferManager.apply_forget_gate(state2, contract)

    # Invariant: PRUNED STATE MUST MATCH 100% (Determinism)
    assert pruned1.token_buffer == pruned2.token_buffer

    # Invariant: Must have actually pruned elements (e.g. roughly ~50% of the 'um's)
    original_um_count = dirty_tokens.count("um")
    pruned_um_count = pruned1.token_buffer.count("um")

    assert pruned_um_count < original_um_count

    # Given SHA1 seed generation is deterministic over indexes,
    # the exact number of pruned tokens is fixed for this precise data arrangement.
    assert pruned_um_count == 244  # Found by hashing indexes locally, acts as a snapshot test
    assert len(pruned1.token_buffer) == 743

    assert len(pruned1.token_buffer) == 743


def test_continuous_stream_buffer_empty_buffer() -> None:
    contract = StreamingDisfluencyContract(repair_marker_regex=r"^um$", decay_threshold=0.5, max_lookback_window=100)
    state = ContinuousObservationState(
        stream_cid="obs", temporal_decay_matrix={}, latest_confidence_score=1.0, token_buffer=[]
    )
    result = StreamBufferManager.apply_forget_gate(state, contract)
    assert result.token_buffer == []


def test_continuous_stream_buffer_empty_regex() -> None:
    contract = StreamingDisfluencyContract(repair_marker_regex="", decay_threshold=0.5, max_lookback_window=100)
    state = ContinuousObservationState(
        stream_cid="obs", temporal_decay_matrix={}, latest_confidence_score=1.0, token_buffer=["um"]
    )
    result = StreamBufferManager.apply_forget_gate(state, contract)
    assert result.token_buffer == ["um"]


def test_continuous_stream_buffer_invalid_regex() -> None:
    contract = StreamingDisfluencyContract(repair_marker_regex="[invalid", decay_threshold=0.5, max_lookback_window=100)
    state = ContinuousObservationState(
        stream_cid="obs", temporal_decay_matrix={}, latest_confidence_score=1.0, token_buffer=["um"]
    )
    result = StreamBufferManager.apply_forget_gate(state, contract)
    assert result.token_buffer == ["um"]


def test_continuous_stream_buffer_lookback_start() -> None:
    # Only look back at the last 1 token
    contract = StreamingDisfluencyContract(repair_marker_regex=r"^um$", decay_threshold=1.0, max_lookback_window=1)
    state = ContinuousObservationState(
        stream_cid="obs", temporal_decay_matrix={}, latest_confidence_score=1.0, token_buffer=["um", "um", "um"]
    )
    result = StreamBufferManager.apply_forget_gate(state, contract)
    # The first two "um" should be left alone because they are before the lookback_start
    assert result.token_buffer[:2] == ["um", "um"]
    # The last "um" might be pruned (1.0 threshold means all matched tokens decay)
    assert len(result.token_buffer) == 2
