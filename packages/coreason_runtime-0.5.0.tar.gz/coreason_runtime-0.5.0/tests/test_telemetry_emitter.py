# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from coreason_runtime.telemetry.emitter import TelemetryEmitter


@pytest.mark.asyncio
async def test_telemetry_emitter_success() -> None:
    emitter = TelemetryEmitter("http://test-broker:8000")
    event = {
        "event_type": "NodeStartedEvent",
        "node_cid": "node_123",
        "agent_name": "agent",
        "timestamp": "now",
    }

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        await emitter.start()
        emitter._enqueue_payload(event)
        # Yield to event loop to allow _flush_task to run
        await asyncio.sleep(0.01)
        mock_post.assert_called_once_with(
            "http://test-broker:8000/api/v1/telemetry/push",
            json=event,
        )
        await emitter.close()


@pytest.mark.asyncio
async def test_telemetry_emitter_connect_error() -> None:
    emitter = TelemetryEmitter("")
    event = {
        "event_type": "NodeStartedEvent",
        "node_cid": "node_123",
        "agent_name": "agent",
        "timestamp": "now",
    }

    # Mock post to raise ConnectError
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.side_effect = httpx.ConnectError("Connection refused")
        await emitter.start()
        # Ensure it doesn't raise exception
        emitter._enqueue_payload(event)
        await asyncio.sleep(0.01)
        mock_post.assert_called_once()
        await emitter.close()


@pytest.mark.asyncio
async def test_emit_agent_suspended_success() -> None:
    emitter = TelemetryEmitter("http://localhost:8000")
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        await emitter.start()
        emitter.emit_suspension(
            workflow_id="wf_123",
            agent_name="YieldingAgent",
            reason="schema_violation",
            latent_state={"memory": "corrupted"},
            failed_intent={"invalid": "payload"},
        )

        await asyncio.sleep(0.01)
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        assert args[0] == "http://localhost:8000/api/v1/telemetry/push"
        payload = kwargs["json"]
        assert payload["type"] == "AgentSuspendedEvent"
        assert payload["workflow_id"] == "wf_123"
        assert payload["agent_name"] == "YieldingAgent"
        assert payload["suspension_reason"] == "schema_violation"
        assert payload["latent_state"] == {"memory": "corrupted"}
        assert payload["failed_intent"] == {"invalid": "payload"}
        await emitter.close()


@pytest.mark.asyncio
async def test_emit_agent_suspended_error() -> None:
    emitter = TelemetryEmitter("http://localhost:8000")

    with (
        patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post,
    ):
        mock_post.side_effect = Exception("Simulated connection error")

        await emitter.start()
        emitter.emit_suspension(
            workflow_id="wf_123",
            agent_name="YieldingAgent",
            reason="oracle_required",
            latent_state={"some": "state"},
        )

        await asyncio.sleep(0.01)
        mock_post.assert_called_once()
        await emitter.close()


@pytest.mark.asyncio
async def test_telemetry_emitter_generic_error() -> None:
    emitter = TelemetryEmitter("")
    event = {
        "event_type": "NodeStartedEvent",
        "node_cid": "node_123",
        "agent_name": "agent",
        "timestamp": "now",
    }

    # Mock post to raise Exception
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.side_effect = ValueError("Some weird error")
        await emitter.start()
        # Ensure it doesn't crash the execution
        emitter._enqueue_payload(event)
        await asyncio.sleep(0.01)
        mock_post.assert_called_once()
        await emitter.close()


@pytest.mark.asyncio
async def test_telemetry_emitter_queue_full() -> None:
    emitter = TelemetryEmitter("")
    emitter.queue = asyncio.Queue(maxsize=1)

    emitter._enqueue_payload({"event_type": "event1"})
    emitter._enqueue_payload({"event_type": "event2"})

    assert emitter.queue.qsize() == 1
    event = emitter.queue.get_nowait()
    assert event["event_type"] == "event2"


@pytest.mark.asyncio
async def test_telemetry_emitter_close_without_start() -> None:
    emitter = TelemetryEmitter("")
    await emitter.close()


@pytest.mark.asyncio
async def test_telemetry_emitter_flush_queue_exception() -> None:
    emitter = TelemetryEmitter("")
    await emitter.start()
    with patch.object(emitter.queue, "get", new_callable=AsyncMock) as mock_get:
        mock_get.side_effect = [Exception("Queue error"), asyncio.CancelledError()]
        await asyncio.sleep(0.01)
    await emitter.close()
