# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

"""
Tests for the unified CLI daemon.
"""

import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from coreason_runtime.cli import app

runner = CliRunner()


def test_cli_help() -> None:
    """
    Verify the main CLI help menu renders successfully without errors.
    """
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Coreason Runtime CLI daemon." in result.stdout
    assert "start" in result.stdout
    assert "execute" in result.stdout


@patch("coreason_runtime.cli.start_worker")
def test_cli_start_node(mock_start_worker: MagicMock) -> None:
    """
    Verify the start node command correctly prints its startup message
    and invokes the worker.
    """

    # Ensure start_worker returns an empty future to satisfy asyncio.run
    async def _mock_worker(*args, **kwargs) -> None:  # type: ignore
        pass

    mock_start_worker.side_effect = _mock_worker

    result = runner.invoke(app, ["start", "node"])
    assert result.exit_code == 0
    mock_start_worker.assert_called_once()


@patch("uvicorn.run")
@patch.dict("sys.modules", {"coreason_runtime.telemetry.broker": MagicMock()})
def test_cli_start_api(mock_uvicorn_run: MagicMock) -> None:
    """
    Verify the start api command correctly prints its startup message
    and runs uvicorn.
    """
    result = runner.invoke(app, ["start", "api"])
    assert result.exit_code == 0
    mock_uvicorn_run.assert_called_once()


@patch("coreason_runtime.cli.CoreasonRuntime")
def test_cli_execute(mock_coreason_runtime: MagicMock) -> None:
    """
    Verify the execute command properly rejects non-existent files,
    and accepts valid existent manifest files while delegating execution.
    """
    # Setup async mock for engine.execute and engine.connect
    mock_engine = MagicMock()

    async def _mock_connect() -> None:
        pass

    async def _mock_execute(*args, **kwargs) -> None:  # type: ignore
        pass

    mock_engine.connect.side_effect = _mock_connect
    mock_engine.execute.side_effect = _mock_execute
    mock_coreason_runtime.return_value = mock_engine

    # Test with non-existent file
    result_invalid = runner.invoke(app, ["execute", "non_existent_file.json"])
    assert result_invalid.exit_code != 0

    # Test with valid temporary file
    with tempfile.NamedTemporaryFile(suffix=".json", mode="w") as tmp:
        tmp.write("{}")
        tmp.flush()

        tmp_path = Path(tmp.name)
        result_valid = runner.invoke(app, ["execute", str(tmp_path)])
        assert result_valid.exit_code == 0
        mock_coreason_runtime.assert_called_once()
        mock_engine.connect.assert_called_once()
        mock_engine.execute.assert_called_once()
