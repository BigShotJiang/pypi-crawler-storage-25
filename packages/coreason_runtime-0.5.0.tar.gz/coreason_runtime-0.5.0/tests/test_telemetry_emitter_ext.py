# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
from unittest.mock import AsyncMock, patch

import httpx
import pytest
from coreason_manifest import EpistemicTelemetryEvent, ExecutionSpanReceipt, TraceContextState

from coreason_runtime.telemetry.emitter import TelemetryEmitter


@pytest.mark.asyncio
async def test_emit_agent_resumed_success() -> None:
    emitter = TelemetryEmitter("http://localhost:8000")
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = httpx.Response(200)
        await emitter.start()
        emitter.emit_resumption("wf_1", "agent_1")
        await asyncio.sleep(0.01)
        mock_post.assert_called_once()
        await emitter.close()


@pytest.mark.asyncio
async def test_emit_epistemic_telemetry() -> None:
    emitter = TelemetryEmitter("http://localhost:8000")
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = httpx.Response(200)
        await emitter.start()

        event = EpistemicTelemetryEvent(
            event_cid="evt-1", timestamp=1234567890.0, interaction_modality="expansion", target_node_cid="node-1"
        )
        emitter.emit_epistemic_telemetry(event)

        await asyncio.sleep(0.01)
        mock_post.assert_called_once()
        await emitter.close()


@pytest.mark.asyncio
async def test_export_traces() -> None:
    emitter = TelemetryEmitter("http://localhost:8000")
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = httpx.Response(200)
        await emitter.start()

        spans = [
            ExecutionSpanReceipt(
                trace_cid="trc-1", span_cid="spn-1", name="test_span", start_time_unix_nano=1000, status="ok"
            )
        ]
        emitter.export_traces("batch-1", spans)

        await asyncio.sleep(0.01)
        mock_post.assert_called_once()
        await emitter.close()


@pytest.mark.asyncio
async def test_wrap_execution_block_success() -> None:
    emitter = TelemetryEmitter("http://localhost:8000")

    async def dummy_block() -> str:
        return "success"

    t_id = "018e69ac-5591-7f0b-9c76-556bede63287"
    s_id = "018e69ac-5591-7f0b-9c76-556bede63287"
    trace_context = TraceContextState(trace_cid=t_id, span_cid=s_id)
    result = await emitter.wrap_execution_block("dummy", "internal", dummy_block, trace_context)
    assert result == "success"
    # Event should be enqueued
    assert emitter.queue.qsize() == 1

    payload = await emitter.queue.get()
    assert payload["type"] == "ExecutionSpanReceipt"
    assert payload["span"]["name"] == "dummy"
    assert payload["span"]["status"] == "ok"
    assert payload["span"]["trace_cid"] == t_id
    assert payload["span"]["parent_span_cid"] == s_id


@pytest.mark.asyncio
async def test_wrap_execution_block_failure() -> None:
    emitter = TelemetryEmitter("http://localhost:8000")

    async def dummy_block() -> None:
        raise ValueError("dummy error")

    with pytest.raises(ValueError, match="dummy error"):
        await emitter.wrap_execution_block("dummy", "internal", dummy_block)

    # Event should be enqueued even on failure
    assert emitter.queue.qsize() == 1

    payload = await emitter.queue.get()
    assert payload["type"] == "ExecutionSpanReceipt"
    assert payload["span"]["name"] == "dummy"
    assert payload["span"]["status"] == "error"
    assert len(payload["span"]["events"]) == 1
    assert payload["span"]["events"][0]["name"] == "exception"


@pytest.mark.asyncio
async def test_emit_agent_resumed_failure() -> None:
    emitter = TelemetryEmitter("http://localhost:8000")
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.side_effect = Exception("Test error")
        # Should catch exception and log it, not raise
        await emitter.start()
        emitter.emit_resumption("wf_1", "agent_1")
        await asyncio.sleep(0.01)
        mock_post.assert_called_once()
        await emitter.close()
