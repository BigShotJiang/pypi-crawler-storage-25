# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import functools
from pathlib import Path
from typing import TYPE_CHECKING, Any

from coreason_manifest import (
    DAGTopologyManifest,
    EpistemicEscalationContract,
    EpistemicQuarantineSnapshot,
    ExecutionNodeReceipt,
    SwarmTopologyManifest,
    WorkflowManifest,
)
from fastapi import APIRouter, HTTPException

from coreason_runtime.utils.settings import COREASON_PLUGINS_DIR

if TYPE_CHECKING:
    from pydantic import BaseModel

router = APIRouter(prefix="/api/v1/schema", tags=["Schema Projection"])


# SOTA 2026: Deterministic Memoization. Compile Rust ASTs exactly once per daemon lifecycle.
@functools.lru_cache(maxsize=16)
def _generate_cached_schema(model_name: str) -> dict[str, Any]:
    models: dict[str, type[BaseModel]] = {
        "dag": DAGTopologyManifest,
        "swarm": SwarmTopologyManifest,
        "workflow": WorkflowManifest,
        "receipt": ExecutionNodeReceipt,
        "epistemicquarantinesnapshot": EpistemicQuarantineSnapshot,
        "epistemicescalationcontract": EpistemicEscalationContract,
    }
    if model_name not in models:
        msg = f"Unknown topology or schema model: {model_name}"
        raise ValueError(msg)

    # Generates a Draft 2020-12 / OpenAPI compliant schema with $ref resolution
    return models[model_name].model_json_schema(mode="validation")


@router.get("/topology/{topology_type}")
async def get_topology_schema(topology_type: str) -> dict[str, Any]:
    """Returns the deeply nested JSON schema for a specific swarm topology."""
    try:
        return _generate_cached_schema(topology_type.lower())
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e


@router.get("/receipt")
async def get_receipt_schema() -> dict[str, Any]:
    """Returns the schema for an ExecutionNodeReceipt."""
    return _generate_cached_schema("receipt")


@router.get("/capabilities")
async def get_capabilities_schema() -> dict[str, Any]:
    """Dynamically introspects the host runtime to list executable WASM tools."""
    plugins_dir = Path(COREASON_PLUGINS_DIR)
    available_tools = []

    if plugins_dir.exists() and plugins_dir.is_dir():
        available_tools = [f.stem for f in plugins_dir.glob("*.wasm")]

    if not available_tools:
        available_tools = ["no_tools_available"]

    # Construct a valid JSON Schema enum dynamically
    return {
        "title": "ExecutableCapabilities",
        "description": "Dynamically discovered executable WASM tools on the host daemon.",
        "type": "string",
        "enum": available_tools,
    }
