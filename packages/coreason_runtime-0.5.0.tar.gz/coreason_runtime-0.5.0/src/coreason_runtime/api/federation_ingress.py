# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

"""Federation Ingress: Secure Public Onboarding Gateway.

Provides a heavily rate-limited, WAF-protected MCP ingress endpoint
for external agents to submit CrossSwarmHandshakeState proposals.
Enforces TelemetryBackpressureContract to prevent DDoS exhaustion
during the public boot and routes valid handshakes into the Temporal
ConsensusFederationExecutionWorkflow.
"""

from __future__ import annotations

import hashlib
import time
from collections import defaultdict
from typing import Any

from coreason_runtime.utils.logger import logger

# ── Rate Limiting Configuration ────────────────────────────────────────

MAX_REQUESTS_PER_MINUTE = 30
MAX_REQUESTS_PER_HOUR = 200
BACKPRESSURE_COOLDOWN_SECONDS = 60
MAX_PENDING_HANDSHAKES = 100


class TelemetryBackpressureContract:
    """Enforces ingress rate limiting to prevent DDoS exhaustion.

    Tracks per-source request counts with sliding window enforcement.
    """

    def __init__(
        self,
        max_per_minute: int = MAX_REQUESTS_PER_MINUTE,
        max_per_hour: int = MAX_REQUESTS_PER_HOUR,
    ) -> None:
        self.max_per_minute = max_per_minute
        self.max_per_hour = max_per_hour
        self._request_log: dict[str, list[float]] = defaultdict(list)

    def check_backpressure(self, source_id: str) -> dict[str, Any]:
        """Check if a source is within rate limits.

        Args:
            source_id: The remote swarm or agent identifier.

        Returns:
            Dict with 'allowed' bool and 'reason' if rejected.
        """
        now = time.time()
        log = self._request_log[source_id]

        # Prune entries older than 1 hour
        self._request_log[source_id] = [t for t in log if now - t < 3600]
        log = self._request_log[source_id]

        # Check per-minute
        recent_minute = sum(1 for t in log if now - t < 60)
        if recent_minute >= self.max_per_minute:
            return {
                "allowed": False,
                "reason": f"Rate limit exceeded: {recent_minute}/{self.max_per_minute} req/min",
                "retry_after_seconds": BACKPRESSURE_COOLDOWN_SECONDS,
            }

        # Check per-hour
        if len(log) >= self.max_per_hour:
            return {
                "allowed": False,
                "reason": f"Rate limit exceeded: {len(log)}/{self.max_per_hour} req/hour",
                "retry_after_seconds": BACKPRESSURE_COOLDOWN_SECONDS * 5,
            }

        # Record the request
        self._request_log[source_id].append(now)
        return {"allowed": True}


class FederationIngressGateway:
    """Secure public onboarding gateway for federated agent ingress.

    Exposes /api/v1/federation/onboard for external agents to submit
    CrossSwarmHandshakeState proposals with ZeroKnowledgeReceipt
    verification and DID attestation.
    """

    def __init__(
        self,
        swarm_id: str,
        bootstrap_config: dict[str, Any] | None = None,
    ) -> None:
        self.swarm_id = swarm_id
        self.bootstrap_config = bootstrap_config or {}
        self.backpressure = TelemetryBackpressureContract()
        self._pending_handshakes: list[dict[str, Any]] = []
        self._approved_agents: dict[str, dict[str, Any]] = {}

    async def handle_onboard_request(
        self,
        request: dict[str, Any],
    ) -> dict[str, Any]:
        """Process an incoming federation onboarding request.

        Validates the request against backpressure limits,
        verifies the ZeroKnowledgeReceipt and DID, and routes
        valid handshakes to the consensus workflow.

        Args:
            request: Onboarding request dict with keys:
                - source_swarm_id: str
                - did: str (Decentralized Identifier)
                - zero_knowledge_receipt: dict
                - handshake_proposal: dict (CrossSwarmHandshakeState)
                - escrow_budget_requested: float

        Returns:
            Onboarding response dict.
        """
        source_id = request.get("source_swarm_id", "unknown")

        # ── Guard 1: Backpressure Rate Limiting ────────────────────
        bp_result = self.backpressure.check_backpressure(source_id)
        if not bp_result["allowed"]:
            logger.warning(f"[Ingress] Backpressure triggered for {source_id}: {bp_result['reason']}")
            return {
                "status": "rate_limited",
                "source_swarm_id": source_id,
                "reason": bp_result["reason"],
                "retry_after_seconds": bp_result.get("retry_after_seconds", 60),
            }

        # ── Guard 2: Pending Handshake Capacity ───────────────────
        if len(self._pending_handshakes) >= MAX_PENDING_HANDSHAKES:
            logger.warning("[Ingress] Pending handshake capacity exhausted.")
            return {
                "status": "capacity_exhausted",
                "source_swarm_id": source_id,
                "reason": f"Max pending handshakes ({MAX_PENDING_HANDSHAKES}) reached.",
                "retry_after_seconds": BACKPRESSURE_COOLDOWN_SECONDS * 2,
            }

        # ── Guard 3: DID Validation ───────────────────────────────
        did = request.get("did", "")
        if not did or not did.startswith("did:"):
            return {
                "status": "rejected",
                "source_swarm_id": source_id,
                "reason": "Invalid or missing Decentralized Identifier (DID).",
            }

        # ── Guard 4: ZeroKnowledgeReceipt Verification ─────────────
        zk_receipt = request.get("zero_knowledge_receipt", {})
        zk_valid = self._verify_zero_knowledge_receipt(zk_receipt, source_id)
        if not zk_valid:
            return {
                "status": "rejected",
                "source_swarm_id": source_id,
                "reason": "ZeroKnowledgeReceipt verification failed.",
            }

        # ── Guard 5: Escrow Budget Bounds ──────────────────────────
        escrow_requested = float(request.get("escrow_budget_requested", 0.0))
        max_escrow = float(self.bootstrap_config.get("max_escrow_per_agent", 10000.0))
        escrow_granted = min(escrow_requested, max_escrow)

        # ── Accept: Route to Consensus Workflow ────────────────────
        handshake_entry: dict[str, Any] = {
            "onboard_id": f"onboard-{int(time.time_ns())}",
            "source_swarm_id": source_id,
            "did": did,
            "escrow_budget_granted": escrow_granted,
            "handshake_proposal": request.get("handshake_proposal", {}),
            "received_at_ns": time.time_ns(),
            "status": "pending_consensus",
        }

        self._pending_handshakes.append(handshake_entry)

        logger.info(
            f"[Ingress] Onboarding accepted for {source_id} (DID: {did[:32]}...). "
            f"Escrow: {escrow_granted:.2f}. Routing to consensus."
        )

        return {
            "status": "accepted",
            "onboard_id": handshake_entry["onboard_id"],
            "source_swarm_id": source_id,
            "escrow_budget_granted": escrow_granted,
            "next_step": "consensus_federation_workflow",
        }

    def _verify_zero_knowledge_receipt(
        self,
        receipt: dict[str, Any],
        source_id: str,
    ) -> bool:
        """Verify a ZeroKnowledgeReceipt from an external agent.

        Validates the proof hash and challenge-response integrity.
        """
        if not receipt:
            return False

        proof_hash = receipt.get("proof_hash", "")
        challenge = receipt.get("challenge", "")
        response = receipt.get("response", "")

        if not proof_hash or not challenge:
            return False

        # Verify the proof hash matches the challenge-response pair
        expected_hash = hashlib.sha256(f"{challenge}:{response}:{source_id}".encode()).hexdigest()

        return bool(proof_hash == expected_hash)

    async def route_to_temporal_workflow(
        self,
        handshake: dict[str, Any],
        temporal_client: Any | None = None,
    ) -> dict[str, Any]:
        """Route an approved handshake to the Temporal consensus workflow.

        Args:
            handshake: The approved handshake entry.
            temporal_client: Optional Temporal client instance.

        Returns:
            Workflow execution result.
        """
        if temporal_client is None:
            logger.info(
                f"[Ingress] Temporal not available. Handshake {handshake['onboard_id']} queued for local processing."
            )
            return {
                "status": "queued_locally",
                "onboard_id": handshake["onboard_id"],
            }

        try:
            handle = await temporal_client.start_workflow(
                "ConsensusFederationExecutionWorkflow",
                args=[handshake],
                id=handshake["onboard_id"],
                task_queue="coreason-federation-queue",
            )

            return {
                "status": "workflow_started",
                "onboard_id": handshake["onboard_id"],
                "workflow_run_id": handle.result_run_id,
            }
        except Exception as e:
            logger.error(f"[Ingress] Temporal workflow error: {e}")
            return {
                "status": "workflow_error",
                "onboard_id": handshake["onboard_id"],
                "error": str(e),
            }

    def get_pending_handshakes(self) -> list[dict[str, Any]]:
        """Return all pending handshakes awaiting consensus."""
        return list(self._pending_handshakes)

    def approve_agent(
        self,
        onboard_id: str,
        agent_metadata: dict[str, Any],
    ) -> None:
        """Mark an agent as approved after consensus."""
        self._approved_agents[onboard_id] = {
            **agent_metadata,
            "approved_at_ns": time.time_ns(),
        }
        self._pending_handshakes = [h for h in self._pending_handshakes if h["onboard_id"] != onboard_id]
        logger.info(f"[Ingress] Agent {onboard_id} approved and onboarded.")
