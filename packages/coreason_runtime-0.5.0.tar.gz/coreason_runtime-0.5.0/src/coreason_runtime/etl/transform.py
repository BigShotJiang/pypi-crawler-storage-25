# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import uuid

import polars as pl


class InvalidSchemaYieldError(Exception):
    """Exception raised when a row-level schema transformation fails the Silver gate."""


class PolarsSilverGate:
    """
    AGENT INSTRUCTION: Handles high-throughput deterministic Silver-layer data
    transformations using Polars, enforcing stable UUIDv5 identity mapping.
    """

    COREASON_NAMESPACE = uuid.uuid5(uuid.NAMESPACE_DNS, "coreason.local")

    @classmethod
    def generate_uuidv5(cls, s: pl.Series) -> pl.Series:
        """Vectorized generation of UUIDv5 hashes from natural composite keys.

        CRITICAL SOTA MANDATE: Enforces deterministic RFC 4122 UUIDv5 (SHA-1 hashing).
        """

        """
        AGENT INSTRUCTION: TEMPORARY SCALAR FALLBACK
        This Python-native for-loop invokes the GIL per row, violating the Arrow-native
        vectorization SLA. This must be replaced with a `pyo3-polars` Rust FFI extension
        executing SIMD SHA-1 hashing before 1.0 release.
        """
        res = []
        for val in s:
            if not val:
                res.append(str(uuid.uuid5(cls.COREASON_NAMESPACE, "NULL")))
            else:
                res.append(str(uuid.uuid5(cls.COREASON_NAMESPACE, str(val))))
        return pl.Series(res, dtype=pl.Utf8)

    @classmethod
    async def transform_async(cls, df: pl.DataFrame | pl.LazyFrame, natural_keys: list[str]) -> pl.LazyFrame:
        """Asynchronous wrapper to offload heavy Silver-Layer operations to a spawn_blocking ThreadPool."""
        import asyncio

        return await asyncio.to_thread(cls.transform, df, natural_keys)

    @classmethod
    def transform(cls, df: pl.DataFrame | pl.LazyFrame, natural_keys: list[str]) -> pl.LazyFrame:
        """
        Executes the Epistemic Silver Gate standardization logic.
        Validates columns, standardizes strings, and intrinsically casts hashes.
        """
        if isinstance(df, pl.DataFrame):
            df = df.lazy()

        missing = [key for key in natural_keys if key not in df.collect_schema().names()]
        if missing:
            msg = f"DataFrame missing required natural keys: {missing}"
            raise InvalidSchemaYieldError(msg)

        df = df.with_columns(pl.col(pl.Utf8).fill_null("").str.strip_chars().str.to_lowercase())

        df = df.with_columns(
            pl.concat_str([pl.col(k) for k in natural_keys], separator="|").alias("_natural_key_composite")
        )

        df = df.with_columns(pl.col("_natural_key_composite").map_batches(cls.generate_uuidv5).alias("entity_uuid"))

        return df.drop("_natural_key_composite")


def process_medallion_pipeline() -> dict[str, str]:
    """Orchestrates the Medallion pipeline logic for testing."""
    from pathlib import Path

    bronze_dir = Path("data/bronze/telemetry/raw_events")
    if not bronze_dir.exists() or not list(bronze_dir.glob("*.parquet")):
        return {"status": "skipped", "reason": "no_bronze_data"}

    # Mock success logic
    silver_dir = Path("data/silver")
    gold_dir = Path("data/gold")
    silver_dir.mkdir(parents=True, exist_ok=True)
    gold_dir.mkdir(parents=True, exist_ok=True)

    df_bronze = pl.scan_parquet(bronze_dir / "*.parquet")
    df_silver = df_bronze.drop_nulls(subset=["workflow_id"])
    df_silver = df_silver.unique(subset=["node_cid", "event_type", "timestamp"])
    df_silver.collect().write_parquet(silver_dir / "events.parquet")

    df_gold = df_silver.group_by("workflow_id").agg(
        [
            pl.len().alias("total_events"),
            pl.col("node_cid").n_unique().alias("unique_nodes_activated"),
        ]
    )
    df_gold.collect().write_parquet(gold_dir / "metrics.parquet")

    return {
        "status": "success",
        "silver_rows": str(df_silver.collect().shape[0]),
        "gold_rows": str(df_gold.collect().shape[0]),
    }
