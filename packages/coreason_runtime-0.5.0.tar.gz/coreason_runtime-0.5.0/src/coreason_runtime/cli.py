# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

"""
Unified CLI Daemon interface for the Coreason Runtime.

This module provides the Typer CLI application for starting workers,
running the API, and executing manifests.
"""

import asyncio
from pathlib import Path
from typing import Annotated, Any

import typer
from dotenv import find_dotenv, load_dotenv

from coreason_runtime.orchestration.engine import CoreasonRuntime
from coreason_runtime.orchestration.worker import start_worker
from coreason_runtime.utils.logger import logger

load_dotenv(find_dotenv())

app = typer.Typer(
    name="coreason",
    help="Coreason Runtime CLI daemon.",
    add_completion=False,
)

start_app = typer.Typer(help="Commands for starting runtime processes.")
app.add_typer(start_app, name="start")


@start_app.command(name="node")
def start_node() -> None:
    """
    Bootstraps the Temporal Worker and connects it to the cluster.
    """
    logger.info("Starting Temporal Worker node...")
    asyncio.run(start_worker("localhost:7233"))


def create_app() -> Any:
    from coreason_runtime.api.oracle import router as oracle_router
    from coreason_runtime.api.predict_router import predict_router
    from coreason_runtime.api.sandbox_router import sandbox_router, state_router
    from coreason_runtime.api.schema import router as schema_router
    from coreason_runtime.telemetry.broker import app as broker_app

    # Ensure dynamic reloads don't duplicate physical router paths natively
    router_tags = [getattr(r, "prefix", "") for r in broker_app.router.routes]
    if "/api/v1/sandbox" not in router_tags:
        broker_app.include_router(state_router)
        broker_app.include_router(schema_router)
        broker_app.include_router(oracle_router)
        broker_app.include_router(sandbox_router)
        broker_app.include_router(predict_router)
    return broker_app


@start_app.command(name="api")
def start_api(
    port: Annotated[
        int,
        typer.Option(
            help="Port to serve the FastAPI ingress on.",
        ),
    ] = 8000,
) -> None:
    """
    Boots the FastAPI ingress via uvicorn.
    """
    import uvicorn

    from coreason_runtime.utils.logger import logger

    logger.info("Starting FastAPI ingress API with Rebootless Patching (hot-reload) enabled...")
    uvicorn.run(
        "coreason_runtime.cli:create_app",
        host="0.0.0.0",  # noqa: S104
        port=port,
        factory=True,
        reload=True,
        log_config=None,
    )


@app.command(name="execute")
def execute(
    manifest_path: Annotated[
        Path,
        typer.Argument(
            help="Path to a local JSON manifest to parse and dispatch.",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
        ),
    ],
    query: Annotated[
        str | None,
        typer.Option(
            help="Inject a dynamic user query into the root agent node.",
        ),
    ] = None,
) -> None:
    """
    Reads a local JSON manifest, parses it into an ontology model,
    and dispatches it to the workflow engine.
    """
    logger.info(f"Executing manifest at {manifest_path}...")

    async def _run() -> None:
        engine = CoreasonRuntime()
        await engine.connect()
        await engine.execute(str(manifest_path), exogenous_perturbation_vector=query)

    asyncio.run(_run())


if __name__ == "__main__":
    app()  # pragma: no cover
