# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os
from typing import TYPE_CHECKING, Any, TypeVar

from pydantic import BaseModel

from coreason_runtime.tensor.client import CloudOracleClient, SGLangKineticClient
from coreason_runtime.tensor.compiler import EntropyEscalationError, UniversalCompiler
from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_COMPUTE_BUDGET, COREASON_SAMPLING_PROBABILITY

from .budget_exceeded_error import BudgetExceededError
from .epistemic_yield_error import EpistemicYieldError

if TYPE_CHECKING:
    from coreason_manifest import CognitiveAgentNodeProfile

T = TypeVar("T", bound=BaseModel)


class TensorRouter:
    """SOTA 2026 Dispatch Matrix. Balances Thermodynamics vs. Cognitive Depth."""

    def __init__(self, sglang_url: str):
        self.kinetic_client = SGLangKineticClient(sglang_url)
        self.oracle_client = CloudOracleClient(
            api_key=os.getenv("CLOUD_ORACLE_API_KEY"),
            base_url=os.getenv("CLOUD_ORACLE_BASE_URL"),
            model=os.getenv("CLOUD_ORACLE_MODEL"),
        )
        self.budgets: dict[str, int] = {}
        self.MAX_TOKENS = int(COREASON_COMPUTE_BUDGET)  # Thermodynamic ceiling per workflow
        self._pricing_cache: dict[str, Any] = {}
        self._sae_dictionary_cache: dict[str, Any] = {}

    def _deduct_budget(self, workflow_id: str, usage: dict[str, int], max_tokens: int) -> tuple[int, float]:
        active_model = os.getenv("CLOUD_ORACLE_MODEL") or ""
        in_cost = 0.000001
        out_cost = 0.000001

        if getattr(self, "_pricing_cache", None) is None:
            import json
            from pathlib import Path

            registry_path = Path(__file__).parent.parent.parent / "resources" / "pricing.json"
            if registry_path.exists():
                with open(registry_path, encoding="utf-8") as f:
                    self._pricing_cache = json.load(f)
            else:
                self._pricing_cache = {}

        if getattr(self, "_pricing_cache", None) and active_model in self._pricing_cache:
            data = getattr(self, "_pricing_cache", {})[active_model]
            in_cost = data.get("input_cost_per_token", 0.000001)
            out_cost = data.get("output_cost_per_token", in_cost)

        prompt_t = usage.get("prompt_tokens", 0)
        completion_t = usage.get("completion_tokens", 0)
        total_t = usage.get("total_tokens", prompt_t + completion_t)

        cost_delta = (prompt_t * in_cost) + (completion_t * out_cost)

        current = self.budgets.get(workflow_id, 0)
        new_total = current + total_t
        if new_total > max_tokens:
            msg = f"Workflow {workflow_id} exceeded thermodynamic budget ({new_total} > {max_tokens} tokens)."
            raise BudgetExceededError(msg)
        self.budgets[workflow_id] = new_total
        return new_total, cost_delta

    def _calculate_latent_smoothing(self, t: float, duration: float, decay_rate: float, strategy: str) -> float:
        import math

        """Mathematical limits for steering vectors."""
        if duration <= 0:
            return 1.0
        if strategy == "linear":
            return max(0.0, 1.0 - (t / duration))
        if strategy == "exponential":
            return math.exp(-decay_rate * t)
        if strategy == "cosine_annealing":
            return 0.5 * (1.0 + math.cos(math.pi * t / duration))
        return 1.0

    def _process_mechanistic_policies(
        self, agent_profile: CognitiveAgentNodeProfile, kwargs: dict[str, Any], is_cloud_oracle: bool = False
    ) -> None:
        """Evaluate Active Steering and set up the mechanistic dictionary load bounds securely."""
        act_steering = getattr(agent_profile, "activation_steering", None)
        if act_steering:
            from coreason_runtime.tensor.steering import MechanisticSteeringEngine

            payload = MechanisticSteeringEngine.construct_tensor_payload(
                contract=act_steering, hardware_supports_latent=not is_cloud_oracle
            )
            kwargs["activation_steering"] = payload

            dict_hash = getattr(act_steering, "sae_dictionary_hash", getattr(payload, "sae_dictionary_hash", "default"))
            if dict_hash and dict_hash not in self._sae_dictionary_cache:
                self._sae_dictionary_cache[dict_hash] = "loaded_projection_matrix"
                logger.info(f"Loaded ActivationSteering SAE matrix mapping bounds: {dict_hash}")

        latent_firewalls = getattr(agent_profile, "latent_firewalls", None)
        if latent_firewalls:
            kwargs["latent_firewalls"] = latent_firewalls.model_dump()

        mechanistic_audit = getattr(agent_profile, "mechanistic_audit", None)
        if mechanistic_audit:
            kwargs["mechanistic_audit"] = mechanistic_audit.model_dump()

    def _evaluate_mechanistic_firewalls(self, layer_activations: dict[str, Any], firewalls: Any) -> None:
        if not layer_activations or not firewalls:
            return

        for rule in getattr(firewalls, "policies", []):
            layer_key = f"layer_{rule.target_layer}"
            acts = layer_activations.get(layer_key, [])
            for feature in acts:
                if (
                    feature.get("feature_index") == rule.target_feature_index
                    and feature.get("magnitude", 0.0) > rule.max_activation_threshold
                ):
                    logger.error(
                        f"SaeLatentPolicy Breach: Feature {rule.target_feature_index} > {rule.max_activation_threshold}"
                    )
                    if rule.violation_action in ["halt", "quarantine"]:
                        msg = "mechanistic_firewall_trip"
                        raise EpistemicYieldError(msg)

    async def route_inference(
        self,
        workflow_id: str,
        prompt: str,
        schema_class: type[T],
        agent_profile: CognitiveAgentNodeProfile | None = None,
        max_attempts: int = 3,
    ) -> tuple[T, dict[str, int], float, int, str]:
        kwargs: dict[str, Any] = {"self_correction": True, "fallback_on_failure": True}
        max_tokens = self.MAX_TOKENS
        use_tier_0 = True
        use_tier_2_fallback = True

        if agent_profile:  # pragma: no cover
            if agent_profile.compute_frontier and agent_profile.compute_frontier.max_cost_magnitude_per_token:
                """Dynamic Token Budget Resolution"""
                active_model = os.getenv("CLOUD_ORACLE_MODEL") or ""

                """Fetch token pricing from locally vendored immutable registry"""
                token_price = 0.000001
                try:
                    if not getattr(self, "_pricing_cache", None):
                        import json
                        from pathlib import Path

                        registry_path = Path(__file__).parent.parent.parent / "resources" / "pricing.json"
                        if registry_path.exists():
                            with open(registry_path, encoding="utf-8") as f:
                                self._pricing_cache = json.load(f)
                        else:
                            self._pricing_cache = {}

                    if hasattr(self, "_pricing_cache") and self._pricing_cache and active_model in self._pricing_cache:
                        data = self._pricing_cache[active_model]
                        in_cost = data.get("input_cost_per_token", 0.000001)
                        out_cost = data.get("output_cost_per_token", in_cost)
                        token_price = (in_cost + out_cost) / 2.0
                except Exception as e:
                    logger.warning(f"[{workflow_id}] Failed to load vendored pricing registry: {e}")
                    self._pricing_cache = {}
                    self._pricing_cache = {}

                cost = agent_profile.compute_frontier.max_cost_magnitude_per_token
                max_tokens = int(cost / token_price) if cost > 0 else self.MAX_TOKENS

            if agent_profile.baseline_cognitive_state:
                kwargs["baseline_cognitive_state"] = agent_profile.baseline_cognitive_state.model_dump()
            if agent_profile.logit_steganography:
                kwargs["logit_steganography"] = agent_profile.logit_steganography.model_dump()
            if agent_profile.peft_adapters:
                """PHASE 13: Zero-downtime Kinetic Adapter Hot-Swapping"""
                total_vram_overhead_bytes: float = 0.0
                max_vram_buffer_bytes: float = float(os.getenv("MAX_LORA_VRAM_BUFFER_BYTES", 4 * 1024 * 1024 * 1024))

                mounted_adapters = []
                for adapter in agent_profile.peft_adapters:
                    adapter_dump = adapter.model_dump()
                    vram_footprint = float(adapter_dump.get("vram_footprint_bytes", 0.0))

                    if total_vram_overhead_bytes + vram_footprint > max_vram_buffer_bytes:
                        logger.error(
                            f"[{workflow_id}] ⚠️ Adapter VRAM Overflow: Mounting {adapter_dump.get('adapter_cid')} would exceed {max_vram_buffer_bytes / (1024**3):.1f}GB safe buffer."
                        )
                        msg = f"Catastrophic OOM Prevention: Cannot mount adapter {adapter_dump.get('adapter_cid')}"
                        raise EpistemicYieldError(msg)

                    total_vram_overhead_bytes += vram_footprint
                    mounted_adapters.append(adapter_dump)

                    logger.info(
                        f"[{workflow_id}] ⚡ Hot-Swapping PEFT Adapter: {adapter_dump.get('adapter_cid')} "
                        f"(Rank: {adapter_dump.get('lora_rank')}, Target: {adapter_dump.get('target_modules')}). "
                        f"VRAM Overhead: {vram_footprint / (1024**2):.2f}MB"
                    )

                    """Send dynamic RPC to SGLang via Multiplexing API"""
                    try:
                        import httpx

                        sglang_adapter_endpoint = f"{self.kinetic_client.base_url.rstrip('/')}/v1/adapters/mount"
                        async with httpx.AsyncClient(timeout=10.0) as sclient:
                            resp = await sclient.post(sglang_adapter_endpoint, json={"adapter_config": adapter_dump})
                            resp.raise_for_status()
                            logger.info(
                                f"[{workflow_id}] RPC -> Successfully multiplexed SGLang mount at {sglang_adapter_endpoint}"
                            )
                    except Exception as e:
                        logger.exception(f"[{workflow_id}] Failed to dispatch multi-LoRA mount RPC: {e}")

                kwargs["peft_adapters"] = mounted_adapters
                kwargs["total_lora_vram_bytes"] = total_vram_overhead_bytes

            if getattr(agent_profile, "prm_policy", None):
                logger.info(f"[{workflow_id}] Hook: PRM Policy active: {agent_profile.prm_policy}")
                if kwargs.get("top_p") is None:
                    kwargs["top_p"] = COREASON_SAMPLING_PROBABILITY

            if getattr(agent_profile, "analogical_policy", None):
                logger.info(f"[{workflow_id}] Hook: Analogical Policy active: {agent_profile.analogical_policy}")
                kwargs["analogical_mapping"] = True

            if getattr(agent_profile, "symbolic_handoff_policy", None):
                logger.info(
                    f"[{workflow_id}] Hook: Symbolic Handoff Policy active: {agent_profile.symbolic_handoff_policy}"
                )
                try:
                    import httpx

                    logger.info(
                        f"[{workflow_id}] Bypassing stochastic LLMs. Dispatching to deterministic solver queue."
                    )
                    solver_endpoint = os.getenv("DETERMINISTIC_SOLVER_URL", "http://localhost:8080/solve")
                    async with httpx.AsyncClient(timeout=60.0) as sclient:
                        resp = await sclient.post(solver_endpoint, json={"prompt": prompt})
                        resp.raise_for_status()
                        result_obj = schema_class.model_validate_json(resp.text)

                        """Securely nest string outputs in compliant receipts injecting canonical intent hashes."""
                        from coreason_runtime.utils.security import generate_canonical_hash

                        intent_hash = generate_canonical_hash(result_obj.model_dump(mode="json"))
                        if hasattr(result_obj, "intent_hash"):
                            result_obj.intent_hash = intent_hash

                        """Return early and bypass Tier 0 & Tier 2 entirely"""
                        usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
                        return result_obj, usage, 0.0, 0, "DETERMINISTIC_SOLVER_OMITS_PQC"
                except Exception as e:
                    logger.exception(f"[{workflow_id}] Symbolic Handoff solver failed: {e}")
                    msg = "Symbolic Handoff Failed. Total Collapse."
                    raise EpistemicYieldError(msg) from e

            if getattr(agent_profile, "audit_policy", None):
                logger.info(f"[{workflow_id}] Hook: Audit Policy active: {agent_profile.audit_policy}")
                kwargs["audit_logging"] = True

            if getattr(agent_profile, "anchoring_policy", None):
                logger.info(f"[{workflow_id}] Hook: Anchoring Policy active: {agent_profile.anchoring_policy}")

            if getattr(agent_profile, "grpo_reward_policy", None):
                logger.info(f"[{workflow_id}] Hook: GRPO Reward Policy active: {agent_profile.grpo_reward_policy}")

            if getattr(agent_profile, "correction_policy", None) and agent_profile.correction_policy is not None:
                logger.info(f"[{workflow_id}] Hook: Self Correction Policy active")
                kwargs["self_correction"] = agent_profile.correction_policy.model_dump()

            self._process_mechanistic_policies(agent_profile, kwargs, is_cloud_oracle=False)

            if getattr(agent_profile, "grpo_reward_policy", None) and agent_profile.grpo_reward_policy is not None:
                logger.info(f"[{workflow_id}] Hook: Epistemic Reward Model Policy active")
                kwargs["epistemic_reward_policy"] = agent_profile.grpo_reward_policy.model_dump()

                """Check for decoding policy within the reward policy format contract"""
                if agent_profile.grpo_reward_policy.format_contract is not None:
                    decoding_policy = getattr(agent_profile.grpo_reward_policy.format_contract, "decoding_policy", None)
                    if decoding_policy is not None:
                        logger.info(f"[{workflow_id}] Hook: Constrained Decoding Policy active")
                        kwargs["constrained_decoding"] = decoding_policy.model_dump()

            use_tier_0 = agent_profile.reflex_policy is not None
            use_tier_2_fallback = agent_profile.escalation_policy is not None

            if agent_profile.escalation_policy:
                entropy_threshold = getattr(agent_profile.escalation_policy, "baseline_entropy_threshold", None)
                if entropy_threshold is not None:
                    kwargs["baseline_entropy_threshold"] = entropy_threshold

        async def _call_kinetic(p: str, **kw: Any) -> tuple[str, dict[str, int], list[float]]:
            schema = kw.pop("schema_dict", schema_class.model_json_schema())
            kw["constrained_decoding"] = True
            return await self.kinetic_client.generate(p, schema, **kw)

        async def _call_outlines_kinetic(
            p: str, **kw: Any
        ) -> tuple[str, dict[str, int], list[float]]:  # pragma: no cover
            kw.pop("schema_dict", None)  # pragma: no cover
            kw["constrained_decoding"] = True  # pragma: no cover
            from coreason_runtime.tensor.client.outlines_kinetic_client import OutlinesKineticClient  # pragma: no cover

            if not getattr(self, "_outlines_client", None):  # pragma: no cover
                self._outlines_client = OutlinesKineticClient()  # pragma: no cover

            outlines_client: OutlinesKineticClient = self._outlines_client  # pragma: no cover
            return await outlines_client.generate(p, schema_class, **kw)  # pragma: no cover

        async def _call_oracle(p: str, **kw: Any) -> tuple[str, dict[str, int], list[float]]:
            schema = kw.pop("schema_dict", schema_class.model_json_schema())
            kw["constrained_decoding"] = True
            return await self.oracle_client.generate(p, schema, **kw)

        if use_tier_0:
            try:
                is_outlines = kwargs.get("constrained_decoding", {}).get("compiler_backend") == "outlines"
                kinetic_callable = _call_outlines_kinetic if is_outlines else _call_kinetic

                if is_outlines:  # pragma: no cover
                    kwargs["enable_outlines_fsm"] = True  # pragma: no cover
                    logger.info(f"[{workflow_id}] Routing to Tier 0 (Native Outlines FSM)")  # pragma: no cover
                else:
                    logger.info(f"[{workflow_id}] Routing to Tier 0 (Kinetic)")

                result, usage = await UniversalCompiler.validate_and_retry(
                    schema_class, kinetic_callable, prompt, max_attempts=max_attempts, **kwargs
                )

                latent_firewalls = getattr(agent_profile, "latent_firewalls", None)
                if agent_profile and latent_firewalls:
                    import typing

                    layer_acts = typing.cast("dict[str, Any]", usage).get("layer_activations", {})
                    self._evaluate_mechanistic_firewalls(layer_acts, latent_firewalls)

                acc_tokens, cost_delta = self._deduct_budget(workflow_id, usage, max_tokens)
                from typing import cast

                from coreason_runtime.utils.security import generate_canonical_hash

                sig_blob = generate_canonical_hash(
                    cast("dict[str, Any]", getattr(result, "model_dump", lambda **_kwargs: result)(mode="json"))
                )
                return result, usage, float(cost_delta), int(acc_tokens), sig_blob
            except EntropyEscalationError as entropy_err:  # pragma: no cover
                logger.warning(
                    f"[{workflow_id}] Tier 0 Epistemic Yield: {entropy_err}. Escalating directly to Oracle..."
                )
                msg = "Autonomic Cascade Failed due to High Entropy. Manual Oracle required."
                raise EpistemicYieldError(msg) from entropy_err
            except Exception as kinetic_err:
                if not use_tier_2_fallback:  # pragma: no cover
                    logger.exception(f"[{workflow_id}] Tier 0 Yielded: {kinetic_err}. No Escalation Policy present.")
                    msg = "Tier 0 Failed and no Escalation Policy present."
                    raise EpistemicYieldError(msg) from kinetic_err
                logger.warning(f"[{workflow_id}] Tier 0 Yielded: {kinetic_err}. Escalating to Tier 2 (Cloud Oracle)...")
                try:
                    if agent_profile:
                        self._process_mechanistic_policies(agent_profile, kwargs, is_cloud_oracle=True)
                    result, usage = await UniversalCompiler.validate_and_retry(
                        schema_class, _call_oracle, prompt, max_attempts=max_attempts, **kwargs
                    )
                    acc_tokens, cost_delta = self._deduct_budget(workflow_id, usage, max_tokens)
                    from typing import cast

                    from coreason_runtime.utils.security import generate_canonical_hash

                    sig_payload = getattr(result, "model_dump", lambda mode: result)(mode="json")  # noqa: ARG005
                    sig_blob = generate_canonical_hash(cast("dict[str, Any]", sig_payload))
                    return result, usage, float(cost_delta), int(acc_tokens), sig_blob
                except EntropyEscalationError as entropy_err:  # pragma: no cover
                    logger.warning(
                        f"[{workflow_id}] Tier 2 Epistemic Yield: {entropy_err}. Escalating directly to Oracle..."
                    )
                    msg = "Autonomic Cascade Failed due to High Entropy. Manual Oracle required."
                    raise EpistemicYieldError(msg) from entropy_err
                except Exception as oracle_err:
                    logger.exception(f"[{workflow_id}] Tier 2 Yielded: {oracle_err}. Total Epistemic Collapse.")
                    msg = "Autonomic Cascade Failed. Manual Oracle required."
                    raise EpistemicYieldError(msg) from oracle_err
        else:
            try:
                logger.info(f"[{workflow_id}] Direct Routing to Tier 2 (Cloud Oracle)")
                if agent_profile:
                    self._process_mechanistic_policies(agent_profile, kwargs, is_cloud_oracle=True)
                result, usage = await UniversalCompiler.validate_and_retry(
                    schema_class, _call_oracle, prompt, max_attempts=max_attempts, **kwargs
                )

                latent_firewalls = getattr(agent_profile, "latent_firewalls", None)
                if agent_profile and latent_firewalls:
                    import typing

                    layer_acts = typing.cast("dict[str, Any]", usage).get("layer_activations", {})
                    self._evaluate_mechanistic_firewalls(layer_acts, latent_firewalls)

                acc_tokens, cost_delta = self._deduct_budget(workflow_id, usage, max_tokens)
                from typing import cast

                from coreason_runtime.utils.security import generate_canonical_hash

                sig_payload = getattr(result, "model_dump", lambda mode: {"_fallback": "manual_bypass"})(mode="json")  # noqa: ARG005
                sig_blob = generate_canonical_hash(cast("dict[str, Any]", sig_payload))
                return result, usage, float(cost_delta), int(acc_tokens), sig_blob
            except EntropyEscalationError as entropy_err:
                logger.warning(
                    f"[{workflow_id}] Tier 2 Epistemic Yield: {entropy_err}. Escalating directly to Oracle..."
                )
                msg = "Direct Route Failed due to High Entropy. Manual Oracle required."
                raise EpistemicYieldError(msg) from entropy_err
            except Exception as oracle_err:
                logger.exception(f"[{workflow_id}] Tier 2 Yielded: {oracle_err}. Total Epistemic Collapse.")
                msg = "Direct Route Failed. Manual Oracle required."
                raise EpistemicYieldError(msg) from oracle_err

        raise NotImplementedError("Unreachable execution path in route_inference")

    async def synthesize_hybrid_workflow(
        self,
        user_prompt: str,
        topology_hint: str | None = None,
        max_agents: int | None = None,
        domain_context: str | None = None,
    ) -> tuple[Any, dict[str, int]]:
        """
        AGENT INSTRUCTION: High-level orchestration of the Brain/Hands hybrid flow.
        Binds the Oracle Client (Thinking) to the Outlines Client (Typing)
        through the Universal Compiler.
        """

        # 1. Define the Tier 2 thinking closure
        async def _thinking_callable(p: str, **kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
            # Force high-depth unconstrained text generation
            kwargs["constrained_decoding"] = False
            kwargs.pop("schema_dict", None)
            return await self.oracle_client.generate(p, schema_dict={}, **kwargs)

        # 2. Define the Tier 0 typing closure
        async def _typing_callable(p: str, **kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
            if not getattr(self, "_outlines_client", None):
                from coreason_runtime.tensor.client.outlines_kinetic_client import OutlinesKineticClient

                self._outlines_client = OutlinesKineticClient()
            outlines_client: OutlinesKineticClient = self._outlines_client
            return await outlines_client.generate(p, **kwargs)

        # 3. Execute via compiler
        return await UniversalCompiler.synthesize_manifest(
            user_prompt=user_prompt,
            thinking_callable=_thinking_callable,
            typing_callable=_typing_callable,
            topology_hint=topology_hint,
            max_agents=max_agents,
            domain_context=domain_context,
        )
