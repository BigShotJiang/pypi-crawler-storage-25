# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
from typing import Any

import httpx

from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_SAMPLING_PROBABILITY


class SGLangKineticClient:
    """Tier 0: Self-hosted, zero marginal cost, Logit FSM."""

    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
        self.client = httpx.AsyncClient(timeout=30.0)

    async def generate(
        self, prompt: str, schema_dict: dict[str, Any], **kwargs: Any
    ) -> tuple[str, dict[str, int], list[float]]:
        if "baseline_cognitive_state" in kwargs:  # pragma: no cover
            logger.debug(f"Passing cognitive steering vector: {kwargs['baseline_cognitive_state']}")
        if "logit_steganography" in kwargs:  # pragma: no cover
            logger.debug(f"Passing logit steganography flags: {kwargs['logit_steganography']}")
        if "peft_adapters" in kwargs:  # pragma: no cover
            logger.debug(f"Passing LoRA/PEFT adapters for hot-swapping: {kwargs['peft_adapters']}")
        if "constrained_decoding" in kwargs:  # pragma: no cover
            logger.debug(
                f"Applying Constrained Decoding Policy via API logit masking: {kwargs['constrained_decoding']}"
            )

        sampling_params: dict[str, Any] = {
            "temperature": kwargs.get("temperature", 0.1),
            "max_new_tokens": kwargs.get("max_tokens", 4096),
        }

        if kwargs.get("constrained_decoding"):
            sampling_params["json_schema"] = json.dumps(schema_dict)

        request_body = {
            "text": prompt,
            "sampling_params": sampling_params,
        }

        # Epic 3.1: Logit Steganography & Neural Watermarking
        if "logit_steganography" in kwargs:
            # Structurally inject Shannon entropy keys into the residual stream constraints
            steg = kwargs["logit_steganography"]
            request_body["experimental_steganography"] = {
                "watermark_key": steg.get("watermark_entropy_key"),
                "gumbel_temperature": steg.get("gumbel_temperature", 0.5),
                "residual_stream_layer": steg.get("residual_stream_layer_target", -1),
            }
            logger.info("Injecting Logit Steganography into residual stream tensor.")

        # Epic 3.2: Real-Time Mechanistic Interpretability Audits
        if "mechanistic_audit" in kwargs:
            audit = kwargs["mechanistic_audit"]
            request_body["experimental_sae_dump"] = {
                "target_layers": audit.get("target_layers", []),
                "top_k_features": audit.get("top_k_features", 64),
                "halt_on_anomaly": audit.get("halt_on_anomaly", False),
            }
            logger.info(f"Extracting SAE Mechanistic Audits for layers: {audit.get('target_layers')}")

        endpoint = f"{self.base_url}/generate"
        logger.info(f"Executing Tier 0 (SGLang) inference → {endpoint}")

        response = await self.client.post(endpoint, json=request_body)
        response.raise_for_status()

        data = response.json()
        raw_content = data.get("text", "")

        meta = data.get("meta_info", {})
        usage = {
            "prompt_tokens": meta.get("prompt_tokens", 0),
            "completion_tokens": meta.get("completion_tokens", 0),
            "total_tokens": meta.get("prompt_tokens", 0) + meta.get("completion_tokens", 0),
        }

        # Capture the extracted Sparse Autoencoder (SAE) feature activations
        if "layer_activations" in data:
            usage["layer_activations"] = data["layer_activations"]
            logger.info("Retrieved Neural Audit Attestation layer activations from forward-pass.")

        # Provide a high-confidence default if no logprobs returned
        probabilities = [COREASON_SAMPLING_PROBABILITY, 0.0]

        logger.info(
            f"Tier 0 inference complete — {usage['prompt_tokens']}p + {usage['completion_tokens']}c tokens consumed"
        )

        return raw_content, usage, probabilities
