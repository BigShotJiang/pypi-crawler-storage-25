# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
import os
from typing import Any

import httpx

from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_SAMPLING_PROBABILITY


class CloudOracleClient:
    """Tier 2: Frontier Cloud Intelligence — real OpenAI-compatible API client.

    Connects to any OpenAI-compatible provider (DeepInfra, OpenAI, Groq, Together, etc.)
    configured via CLOUD_ORACLE_* environment variables. Uses JSON-mode structured output
    with schema-guided system prompts for deterministic, manifest-compliant generation.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
    ):
        self.api_key = api_key or os.getenv("CLOUD_ORACLE_API_KEY", "")
        self.base_url = str(base_url or os.getenv("CLOUD_ORACLE_BASE_URL", "")).rstrip("/")
        self.model = model or os.getenv("CLOUD_ORACLE_MODEL", "meta-llama/Meta-Llama-3-70B-Instruct")

        self.client = httpx.AsyncClient(
            timeout=300.0,
            limits=httpx.Limits(max_keepalive_connections=50, max_connections=100),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
        )

    def _build_system_prompt(self, schema_dict: dict[str, Any] | None = None) -> str:
        """Construct a schema-guided system prompt for structured JSON output."""
        base = (
            "You are a deterministic execution engine within the CoReason Agentic Runtime. "
            "Your output must strictly conform to the required JSON Schema execution bounds."
        )
        if schema_dict:
            base += f"\n\nREQUIRED JSON SCHEMA:\n{json.dumps(schema_dict, indent=2)}"
        return base

    async def generate(
        self, prompt: str, schema_dict: dict[str, Any], **kwargs: Any
    ) -> tuple[str, dict[str, int], list[float]]:
        """Call an OpenAI-compatible chat completions endpoint with structured output.

        Args:
            prompt: The execution payload/description to send to the LLM.
            schema_dict: The JSON Schema the response must conform to.
            **kwargs: Additional routing metadata (cognitive state, PEFT adapters, etc.).

        Returns:
            A tuple of (raw_json_string, usage_dict, probability_estimates).
        """
        if "baseline_cognitive_state" in kwargs:  # pragma: no cover
            logger.debug(f"Passing cognitive steering vector: {kwargs['baseline_cognitive_state']}")
        if "logit_steganography" in kwargs:  # pragma: no cover
            logger.debug(f"Passing logit steganography flags: {kwargs['logit_steganography']}")
        if "peft_adapters" in kwargs:  # pragma: no cover
            logger.debug(f"Passing LoRA/PEFT adapters for hot-swapping: {kwargs['peft_adapters']}")
        if "constrained_decoding" in kwargs:  # pragma: no cover
            logger.debug(
                f"Applying Constrained Decoding Policy via API logit masking: {kwargs['constrained_decoding']}"
            )

        system_prompt = self._build_system_prompt(schema_dict)

        request_body: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            "temperature": kwargs.get("temperature", 0.1),
            "max_tokens": kwargs.get("max_tokens", 4096),
        }

        if kwargs.get("constrained_decoding"):
            request_body["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "agent_response_schema",
                    "schema": schema_dict,
                    "strict": True,
                },
            }

        endpoint = f"{self.base_url}/chat/completions"
        logger.info(f"Executing Tier 2 (Cloud Oracle) inference → {self.model} @ {self.base_url}")

        response = await self.client.post(endpoint, json=request_body)
        response.raise_for_status()

        data = response.json()

        # Extract the generated content
        raw_content = data["choices"][0]["message"]["content"]

        # logger.info(f"\n============== LLM PROMPT ==============\n{prompt}\n========================================")
        # logger.info(
        #     f"\n=========== LLM RAW OUTPUT ============\n{raw_content}\n========================================"
        # )

        # Extract usage statistics
        usage_data = data.get("usage", {})
        usage = {
            "prompt_tokens": usage_data.get("prompt_tokens", 0),
            "completion_tokens": usage_data.get("completion_tokens", 0),
            "total_tokens": usage_data.get("prompt_tokens", 0) + usage_data.get("completion_tokens", 0),
        }

        # Cloud APIs typically don't return per-token probabilities;
        # use a high-confidence default for the compiler's entropy check
        probabilities = [COREASON_SAMPLING_PROBABILITY, 0.0]

        logger.info(
            f"Tier 2 inference complete — {usage['prompt_tokens']}p + {usage['completion_tokens']}c tokens consumed"
        )

        return raw_content, usage, probabilities
