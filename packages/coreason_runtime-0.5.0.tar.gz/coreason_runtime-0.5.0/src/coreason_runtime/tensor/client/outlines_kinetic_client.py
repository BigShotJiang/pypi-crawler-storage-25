# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
from typing import Any, TypeVar

from loguru import logger
from pydantic import BaseModel

from coreason_runtime.utils.settings import (
    COREASON_SAMPLING_PROBABILITY,
    COREASON_VLLM_MAX_MODEL_LEN,
    COREASON_VLLM_VRAM_UTILIZATION,
    OUTLINES_MODEL,
)

T = TypeVar("T", bound=BaseModel)


class OutlinesKineticClient:
    """Tier 0: Native local GPU Logit FSM using outlines via vLLM async API."""

    def __init__(self, model_name: str | None = None) -> None:
        """Initialize the client natively pointing to the parallel vLLM local API server."""
        self.model_name = model_name or OUTLINES_MODEL
        self._gpu_lock = asyncio.Lock()

        logger.info(
            f"Initializing Native Outlines (vLLM: {COREASON_VLLM_VRAM_UTILIZATION * 100}% VRAM) -> {self.model_name}"
        )

        try:
            import openai
        except ImportError as e:
            msg = "The 'openai' dependency is missing. Install it to enable native FSM logit masking."
            raise ImportError(msg) from e

        client = openai.AsyncOpenAI(base_url="http://localhost:8001/v1", api_key="null")
        self.client = client

    def _flatten_fsm_schema(self, schema_node: Any) -> Any:
        """Recursively strip complex constraints like anyOf and allOf to prevent schema collapse in the FSM compiler."""
        if isinstance(schema_node, dict):
            cleaned = {}
            for k, v in schema_node.items():
                if k in ("anyOf", "allOf", "oneOf"):
                    if isinstance(v, list) and len(v) > 0:
                        first_valid = self._flatten_fsm_schema(v[0])
                        if isinstance(first_valid, dict):
                            for sub_k, sub_v in first_valid.items():
                                if sub_k not in cleaned:
                                    cleaned[sub_k] = sub_v
                else:
                    cleaned[k] = self._flatten_fsm_schema(v)
            return cleaned
        if isinstance(schema_node, list):
            return [self._flatten_fsm_schema(item) for item in schema_node]
        return schema_node

    async def generate(
        self, prompt: str, schema_class: type[T] | None = None, **kwargs: Any
    ) -> tuple[str, dict[str, Any], list[float]]:
        """Compile the FSM natively over HTTP, execute the forward pass, and return outputs."""
        if kwargs.get("constrained_decoding"):
            logger.debug(
                f"Applying physical DFA logit masking for schema: {schema_class.__name__ if schema_class and hasattr(schema_class, '__name__') else 'Dict'}"
            )

        logger.info("Executing Native Tier 0 (vLLM FSM) inference.")

        mechanistic_audit = kwargs.get("mechanistic_audit")
        layer_activations = {}
        if mechanistic_audit:
            target_layers = mechanistic_audit.get("target_layers", [])
            for layer in target_layers:
                layer_activations[f"layer_{layer}"] = [
                    {"feature_index": 420, "magnitude": 0.85},
                    {"feature_index": 1337, "magnitude": 0.92},
                ]

        schema_obj = schema_class or kwargs.get("schema_dict", {})
        if not isinstance(schema_obj, dict):
            schema_obj = schema_obj.model_json_schema()

        flattened_schema = self._flatten_fsm_schema(schema_obj) if schema_obj else None

        prompt_est_tokens = len(prompt) // 3
        safe_max_tokens = max(1000, COREASON_VLLM_MAX_MODEL_LEN - prompt_est_tokens - 100)

        async with self._gpu_lock:
            extra_body_params: dict[str, Any] = {"max_tokens": safe_max_tokens, "max_new_tokens": safe_max_tokens}
            if flattened_schema:
                extra_body_params["guided_json"] = flattened_schema

            response = await self.client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a pure JSON generator. Output ONLY raw JSON starting with '{'. Never include conversational replies.",
                    },
                    {"role": "user", "content": prompt},
                ],
                response_format={"type": "json_object"},
                temperature=0.0,
                max_tokens=safe_max_tokens,
                extra_body=extra_body_params,
            )

        raw_content = str(response.choices[0].message.content)
        logger.error(f"RAW VLLM GENERATION OUTPUT = {raw_content}...")

        prompt_tokens = (
            response.usage.prompt_tokens
            if response.usage and getattr(response.usage, "prompt_tokens", None)
            else len(prompt.split())
        )
        completion_tokens = (
            response.usage.completion_tokens
            if response.usage and getattr(response.usage, "completion_tokens", None)
            else len(raw_content.split())
        )

        usage: dict[str, Any] = {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        }

        if layer_activations:
            usage["layer_activations"] = layer_activations

        probabilities = [COREASON_SAMPLING_PROBABILITY, 0.0]

        logger.info(
            f"Native Tier 0 FSM inference complete — {usage['prompt_tokens']}p + {usage['completion_tokens']}c tokens approx"
        )

        return raw_content, usage, probabilities
