# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

"""Ontological Alignment & Vector Space Isometry Verification.

Verifies that two swarms' embedding matrices are mathematically compatible
before permitting cross-tenant graph execution. Computes Cosine Similarity
and Earth Mover's Distance between benchmark latent vectors. If alignment
falls below the policy threshold, attempts a DimensionalProjectionContract.
If projection fails, drops with "incommensurable" status.
"""

from __future__ import annotations

import hashlib
import time
from typing import Any

import numpy as np


def verify_ontological_isometry(
    local_vectors: list[list[float]],
    remote_vectors: list[list[float]],
    policy: dict[str, Any],
) -> dict[str, Any]:
    """Verify ontological isometry between two swarms' embedding spaces.

    Computes pairwise cosine similarity between benchmark latent vectors
    and evaluates against the OntologicalAlignmentPolicy thresholds.

    Args:
        local_vectors: List of local benchmark embedding vectors.
        remote_vectors: List of remote benchmark embedding vectors.
        policy: An OntologicalAlignmentPolicy dict with keys:
            - min_cosine_similarity: float (threshold, e.g. 0.85)
            - max_earth_mover_distance: float (optional EMD ceiling)
            - enable_dimensional_projection: bool
            - projection_tolerance: float

    Returns:
        An OntologicalHandshakeReceipt dict with alignment results.
    """
    min_cosine = float(policy.get("min_cosine_similarity", 0.85))
    max_emd = float(policy.get("max_earth_mover_distance", float("inf")))
    enable_projection = bool(policy.get("enable_dimensional_projection", True))
    projection_tolerance = float(policy.get("projection_tolerance", 0.7))

    receipt: dict[str, Any] = {
        "receipt_id": hashlib.sha256(f"{time.time_ns()}".encode()).hexdigest()[:16],
        "started_at_ns": time.time_ns(),
        "policy_min_cosine": min_cosine,
        "policy_max_emd": max_emd,
    }

    if not local_vectors or not remote_vectors:
        receipt["status"] = "incommensurable"
        receipt["reason"] = "Empty vector set(s) provided"
        receipt["completed_at_ns"] = time.time_ns()
        return receipt

    local_arr = np.array(local_vectors, dtype=np.float64)
    remote_arr = np.array(remote_vectors, dtype=np.float64)

    # ── Step 1: Compute pairwise cosine similarity ─────────────────
    try:
        cosine_similarities = _batch_cosine_similarity(local_arr, remote_arr)
        mean_cosine = float(np.mean(cosine_similarities))
        min_observed_cosine = float(np.min(cosine_similarities))
        max_observed_cosine = float(np.max(cosine_similarities))
    except ValueError:
        # Dimensional mismatch triggers immediate fallback
        mean_cosine = -1.0
        min_observed_cosine = -1.0
        max_observed_cosine = -1.0

    receipt["measured_cosine_similarity"] = round(mean_cosine, 6)
    receipt["min_observed_cosine"] = round(min_observed_cosine, 6)
    receipt["max_observed_cosine"] = round(max_observed_cosine, 6)

    # ── Step 2: Compute Earth Mover's Distance ─────────────────────
    try:
        emd = _compute_emd_approximation(local_arr, remote_arr)
    except ValueError:
        emd = float("inf")

    receipt["measured_emd"] = round(emd, 6) if emd != float("inf") else emd

    # ── Step 3: Primary alignment check ────────────────────────────
    if mean_cosine >= min_cosine and emd <= max_emd:
        receipt["status"] = "aligned"
        receipt["dimensional_projection_attempted"] = False
        receipt["completed_at_ns"] = time.time_ns()
        return receipt

    # ── Step 4: Dimensional Projection fallback ────────────────────
    if enable_projection and mean_cosine < min_cosine:
        projected_cosine = _attempt_dimensional_projection(local_arr, remote_arr)
        receipt["projected_cosine_similarity"] = round(projected_cosine, 6)
        receipt["dimensional_projection_attempted"] = True

        if projected_cosine >= projection_tolerance:
            receipt["status"] = "aligned_via_projection"
            receipt["completed_at_ns"] = time.time_ns()
            return receipt

    # ── Step 5: Incommensurable ────────────────────────────────────
    receipt["status"] = "incommensurable"
    receipt["reason"] = (
        f"Cosine similarity {mean_cosine:.4f} < {min_cosine:.4f} "
        f"and/or EMD {emd:.4f} > {max_emd:.4f}. "
        f"Dimensional projection {'failed' if enable_projection else 'disabled'}."
    )
    receipt["dimensional_projection_attempted"] = enable_projection
    receipt["completed_at_ns"] = time.time_ns()

    return receipt


def _batch_cosine_similarity(
    a: np.ndarray,
    b: np.ndarray,
) -> np.ndarray:
    """Compute pairwise cosine similarity between two sets of vectors.

    Uses matrix multiplication for efficiency.
    """
    # Normalize rows to unit vectors
    a_norms = np.linalg.norm(a, axis=1, keepdims=True)
    b_norms = np.linalg.norm(b, axis=1, keepdims=True)

    # Avoid division by zero
    a_norms = np.maximum(a_norms, 1e-10)
    b_norms = np.maximum(b_norms, 1e-10)

    a_normalized = a / a_norms
    b_normalized = b / b_norms

    # Cosine similarity matrix: (n_local, n_remote)
    similarity_matrix = a_normalized @ b_normalized.T

    # Return the diagonal if same number of vectors, otherwise flatten
    import typing

    if a.shape[0] == b.shape[0]:
        return typing.cast("np.ndarray", np.diag(similarity_matrix))
    return typing.cast("np.ndarray", similarity_matrix.flatten())


def _compute_emd_approximation(
    a: np.ndarray,
    b: np.ndarray,
) -> float:
    """Compute an approximation of the Earth Mover's Distance.

    Uses the mean L2 distance between centroids as a lightweight proxy
    for the full Wasserstein distance (avoids scipy dependency for CI).
    """
    centroid_a = np.mean(a, axis=0)
    centroid_b = np.mean(b, axis=0)

    # L2 distance between centroids
    centroid_distance = float(np.linalg.norm(centroid_a - centroid_b))

    # Approximate EMD using mean pairwise L2 distance (sampled)
    n_samples = min(a.shape[0], b.shape[0], 100)
    sampled_distances = []
    for i in range(n_samples):
        idx_a = i % a.shape[0]
        idx_b = i % b.shape[0]
        dist = float(np.linalg.norm(a[idx_a] - b[idx_b]))
        sampled_distances.append(dist)

    mean_pairwise = float(np.mean(sampled_distances)) if sampled_distances else 0.0

    # Weighted combination
    return 0.4 * centroid_distance + 0.6 * mean_pairwise


def _attempt_dimensional_projection(
    local_arr: np.ndarray,
    remote_arr: np.ndarray,
) -> float:
    """Attempt to project remote vectors into the local embedding space.

    Uses Procrustes analysis (orthogonal alignment) to find the best
    rotation matrix mapping remote space → local space, then re-evaluates
    cosine similarity.
    """
    # Align dimensions: use the minimum of the two
    min_rows = min(local_arr.shape[0], remote_arr.shape[0])
    local_sample = local_arr[:min_rows]
    remote_sample = remote_arr[:min_rows]

    # Handle dimension mismatch by zero-padding
    if local_sample.shape[1] != remote_sample.shape[1]:
        max_dim = max(local_sample.shape[1], remote_sample.shape[1])
        if local_sample.shape[1] < max_dim:
            pad = np.zeros((local_sample.shape[0], max_dim - local_sample.shape[1]))
            local_sample = np.hstack([local_sample, pad])
        if remote_sample.shape[1] < max_dim:
            pad = np.zeros((remote_sample.shape[0], max_dim - remote_sample.shape[1]))
            remote_sample = np.hstack([remote_sample, pad])

    # Procrustes: find optimal rotation R = V @ U^T from SVD of M = local^T @ remote
    m = local_sample.T @ remote_sample
    u, _, vt = np.linalg.svd(m)
    rotation = u @ vt

    # Apply rotation to remote vectors
    projected = remote_sample @ rotation.T

    # Re-evaluate cosine similarity
    similarities = _batch_cosine_similarity(local_sample, projected)
    return float(np.mean(similarities))
