# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
from typing import Any


def serialize_intent(intent: Any) -> bytes:
    """
    Safely pass deeply nested JSON-RPC payloads across the host/WASM memory boundary.

    Args:
        intent: The Pydantic model representing the client intent.

    Returns:
        UTF-8 encoded JSON bytes ready for WASM.
    """
    if hasattr(intent, "model_dump"):
        data = intent.model_dump()
    elif isinstance(intent, dict):
        data = intent
    else:
        data = {}

    payload_str = json.dumps(data, sort_keys=True, separators=(",", ":"))
    payload_bytes = payload_str.encode("utf-8")

    if len(payload_bytes) > 1048576:  # pragma: no cover
        from coreason_runtime.utils.exceptions import PayloadTooLargeError

        msg = "Payload size exceeds physical WebAssembly lattice cap."
        raise PayloadTooLargeError(msg)

    return payload_bytes


def decode_wasm_output(raw_output: bytes) -> str | dict[str, Any]:
    """
    Decode the bytes from WASM to UTF-8 and attempt JSON parsing.
    Safely fall back to raw string on failure.

    Args:
        raw_output: The bytes returned by the WASM module.

    Returns:
        A dict if parsed successfully, otherwise a string.
    """
    decoded = raw_output.decode("utf-8", errors="replace")
    try:
        parsed = json.loads(decoded)
        if isinstance(parsed, dict):
            return parsed
        return decoded
    except json.JSONDecodeError:
        return decoded
