# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
import json
import os
from typing import TYPE_CHECKING, Any

from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_MCP_PAYLOAD_LIMIT

from .mcp_transport_client import MCPTransportClient

if TYPE_CHECKING:
    from coreason_manifest import (
        MCPServerManifest,
        StdioTransportProfile,
    )


class StdioMCPClient(MCPTransportClient):
    def __init__(self, manifest: MCPServerManifest) -> None:  # pragma: no cover
        self.manifest = manifest
        # Ensure we type-narrow to StdioTransportProfile downstream
        self.profile: StdioTransportProfile = manifest.transport  # type: ignore[assignment]
        self.process: asyncio.subprocess.Process | None = None
        self._request_cid = 0
        self._pending_requests: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._read_task: asyncio.Task[None] | None = None

    async def _start_process(self) -> None:  # pragma: no cover
        if self.process is not None:
            if self.process.returncode is not None:
                self.process = None
                if self._read_task:
                    self._read_task.cancel()
                    self._read_task = None
                for fut in self._pending_requests.values():
                    if not fut.done():
                        fut.set_exception(RuntimeError("Process crashed"))
                self._pending_requests.clear()
            else:
                return

        env = os.environ.copy()
        if self.profile.env_vars:
            env.update(self.profile.env_vars)

        self.process = await asyncio.create_subprocess_exec(
            self.profile.command,
            *self.profile.args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
            limit=COREASON_MCP_PAYLOAD_LIMIT,  # Ensure limit is driven dynamically
        )
        self._read_task = asyncio.create_task(self._read_loop())

        if self.process.stdin is not None:
            init_req_id = -1
            init_fut: asyncio.Future[dict[str, Any]] = asyncio.Future()
            self._pending_requests[init_req_id] = init_fut
            init_req = {
                "jsonrpc": "2.0",
                "id": init_req_id,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "coreason", "version": "1.0"},
                },
            }
            self.process.stdin.write(json.dumps(init_req).encode("utf-8") + b"\n")
            await self.process.stdin.drain()

            await init_fut

            ack_req = {"jsonrpc": "2.0", "method": "notifications/initialized"}
            self.process.stdin.write(json.dumps(ack_req).encode("utf-8") + b"\n")
            await self.process.stdin.drain()

    async def _read_loop(self) -> None:  # pragma: no cover
        if not self.process or not self.process.stdout:
            return

        try:
            while True:
                line = await self.process.stdout.readline()
                if not line:
                    break

                try:
                    resp = json.loads(line)
                    if "id" in resp and isinstance(resp["id"], int):
                        req_id = resp["id"]
                        if req_id in self._pending_requests:
                            fut = self._pending_requests.pop(req_id)
                            if not fut.done():
                                if "error" in resp:
                                    fut.set_exception(RuntimeError(f"JSON-RPC Error: {resp['error']}"))
                                else:
                                    fut.set_result(resp.get("result", {}))
                    else:
                        pass
                except json.JSONDecodeError:
                    pass
        except Exception as e:
            logger.exception(f"Error in StdioMCPClient read loop: {e}")
        finally:
            for fut in self._pending_requests.values():
                if not fut.done():
                    fut.set_exception(RuntimeError("Read loop terminated"))
            self._pending_requests.clear()

    async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:  # pragma: no cover
        # OCap Whitelist Validation
        if self.manifest.capability_whitelist and method == "tools/call":
            whitelist = getattr(self.manifest.capability_whitelist, "allowed_tools", None)
            tool_name = params.get("name") if params else None
            # Only validate if the whitelist explicitly provides an allowed_tools boundary
            if whitelist is not None and tool_name not in whitelist:
                msg = f"OCap Violation: Tool '{tool_name}' is not inside the capability_whitelist.allowed_tools."
                raise RuntimeError(msg)

        await self._start_process()
        if self.process is None or self.process.stdin is None:
            msg = "Process not started correctly."
            raise RuntimeError(msg)

        self._request_cid += 1
        req_id = self._request_cid
        req = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
        }
        if params is not None:
            req["params"] = params

        fut: asyncio.Future[dict[str, Any]] = asyncio.Future()
        self._pending_requests[req_id] = fut

        req_bytes = json.dumps(req).encode("utf-8") + b"\n"
        try:
            self.process.stdin.write(req_bytes)
            await self.process.stdin.drain()
        except Exception as e:
            logger.exception(f"Failed to write to process in StdioMCPClient: {e}")
            self._pending_requests.pop(req_id, None)
            msg = f"Failed to write to process: {e}"
            raise RuntimeError(msg) from e

        return await fut
