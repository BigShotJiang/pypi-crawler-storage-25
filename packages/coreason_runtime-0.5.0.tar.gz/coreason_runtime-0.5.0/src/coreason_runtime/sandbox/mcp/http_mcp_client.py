# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import ipaddress
import socket
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

import httpx

from .mcp_transport_client import MCPTransportClient

if TYPE_CHECKING:
    from coreason_manifest import (
        HTTPTransportProfile,
        MCPServerManifest,
    )


class HttpMCPClient(MCPTransportClient):
    def __init__(self, manifest: MCPServerManifest) -> None:  # pragma: no cover
        self.manifest = manifest
        self.profile: HTTPTransportProfile = manifest.transport  # type: ignore[assignment]
        self._request_cid = 0

    async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:  # pragma: no cover
        # OCap Whitelist Validation
        if self.manifest.capability_whitelist and method == "tools/call":
            whitelist = getattr(self.manifest.capability_whitelist, "allowed_tools", None)
            tool_name = params.get("name") if params else None
            if whitelist is not None and tool_name not in whitelist:
                msg = f"OCap Violation: Tool '{tool_name}' is not inside the capability_whitelist.allowed_tools."
                raise RuntimeError(msg)

        self._request_cid += 1
        req = {
            "jsonrpc": "2.0",
            "id": self._request_cid,
            "method": method,
        }
        if params is not None:
            req["params"] = params

        headers = self.profile.headers or {}
        headers["Content-Type"] = "application/json"

        parsed_uri = urlparse(str(self.profile.uri))
        hostname = parsed_uri.hostname
        if hostname:
            try:
                ip = socket.gethostbyname(hostname)
                ip_obj = ipaddress.ip_address(ip)
                if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local:
                    msg = "SSRF Protection: Invalid target URI."
                    raise RuntimeError(msg)
            except socket.gaierror:
                pass  # Let httpx handle DNS failures normally

        async with httpx.AsyncClient() as client:
            response = await client.post(str(self.profile.uri), json=req, headers=headers)
            response.raise_for_status()
            resp = response.json()
            if "error" in resp:
                msg = f"JSON-RPC Error: {resp['error']}"
                raise RuntimeError(msg)
            return resp.get("result", {})  # type: ignore[no-any-return]
