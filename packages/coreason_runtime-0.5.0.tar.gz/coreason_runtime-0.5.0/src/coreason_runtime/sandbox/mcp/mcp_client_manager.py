# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
import os
from typing import TYPE_CHECKING, Any

from coreason_manifest import (
    HTTPTransportProfile,
    MCPPromptReferenceState,
    MCPResourceManifest,
    MCPServerManifest,
    SSETransportProfile,
    StdioTransportProfile,
)
from pydantic import TypeAdapter, ValidationError

from coreason_runtime.utils.exceptions import ManifestConformanceError
from coreason_runtime.utils.logger import logger

from .http_mcp_client import HttpMCPClient
from .retrying_mcp_client import RetryingMCPClient
from .sse_mcp_client import SSEMCPClient
from .stdio_mcp_client import StdioMCPClient

if TYPE_CHECKING:
    from .mcp_transport_client import MCPTransportClient


class MCPClientManager:
    def __init__(self, config_path: str | None = None) -> None:  # pragma: no cover
        self.config_path = config_path or os.environ.get("MCP_SERVERS_CONFIG_PATH")
        self.profiles: dict[str, MCPServerManifest] = {}
        self.clients: dict[str, MCPTransportClient] = {}
        self._load_config()

    def _load_config(self) -> None:  # pragma: no cover
        if not self.config_path or not os.path.exists(self.config_path):
            logger.warning(f"MCP_SERVERS_CONFIG_PATH ({self.config_path}) not found. No servers loaded.")
            return

        try:
            with open(self.config_path, encoding="utf-8") as f:
                data = json.load(f)

            ta: TypeAdapter[Any] = TypeAdapter(MCPServerManifest)
            for server_cid, profile_data in data.items():
                try:
                    profile = ta.validate_python(profile_data)
                    self.profiles[server_cid] = profile
                except ValidationError as e:
                    logger.exception(f"Failed to parse profile for server_cid '{server_cid}': {e}")
                    msg = f"Server config {server_cid} violates MCPServerManifest schema: {e}"
                    raise ManifestConformanceError(msg) from e
                except Exception as e:
                    logger.exception(f"Failed to parse profile for server_cid '{server_cid}': {e}")
                    raise
        except Exception as e:
            if not isinstance(e, ManifestConformanceError):
                logger.exception(f"Failed to load MCP servers config from {self.config_path}: {e}")
            raise

    def get_client(self, server_cid: str) -> MCPTransportClient:  # pragma: no cover
        if server_cid in self.clients:
            return self.clients[server_cid]

        if server_cid not in self.profiles:
            msg = f"Server ID '{server_cid}' not found in MCP server configuration."
            raise ValueError(msg)

        profile = self.profiles[server_cid]
        if isinstance(profile.transport, StdioTransportProfile):
            client = RetryingMCPClient(StdioMCPClient(profile))
        elif isinstance(profile.transport, HTTPTransportProfile):
            client = RetryingMCPClient(HttpMCPClient(profile))
        elif isinstance(profile.transport, SSETransportProfile):
            client = RetryingMCPClient(SSEMCPClient(profile))
        else:
            msg = f"Unknown TransportProfile type: {type(profile.transport)}"
            raise ValueError(msg)

        self.clients[server_cid] = client
        return client

    async def hydrate_prompt(self, prompt_state: MCPPromptReferenceState) -> dict[str, Any]:  # pragma: no cover
        """Fetch a remote prompt from an MCP server."""
        client = self.get_client(prompt_state.server_cid)
        params = {
            "name": prompt_state.prompt_name,
            "arguments": prompt_state.arguments,
        }
        return await client.request("prompts/get", params)

    async def read_resource(self, resource_manifest: MCPResourceManifest) -> dict[str, Any]:  # pragma: no cover
        """Read remote resources from an MCP server."""
        client = self.get_client(resource_manifest.server_cid)
        results = []
        for uri in resource_manifest.uris:
            params = {"uri": str(uri)}
            resp = await client.request("resources/read", params)
            results.append(resp)
        return {"resources": results}
