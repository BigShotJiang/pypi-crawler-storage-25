# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
import json
from typing import TYPE_CHECKING, Any

import httpx

from coreason_runtime.utils.logger import logger

from .mcp_transport_client import MCPTransportClient

if TYPE_CHECKING:
    from coreason_manifest import (
        MCPServerManifest,
        SSETransportProfile,
    )


class SSEMCPClient(MCPTransportClient):
    def __init__(self, manifest: MCPServerManifest) -> None:  # pragma: no cover
        self.manifest = manifest
        self.profile: SSETransportProfile = manifest.transport  # type: ignore[assignment]
        self._request_cid = 0
        self._pending_requests: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._client: httpx.AsyncClient | None = None
        self._read_task: asyncio.Task[None] | None = None
        self._post_endpoint: str | None = None
        self._connection_lock = asyncio.Lock()

    async def _connect_sse(self) -> None:  # pragma: no cover
        async with self._connection_lock:
            if self._client is not None and self._read_task is not None and not self._read_task.done():
                return

            if self._read_task:
                self._read_task.cancel()
            if self._client:
                await self._client.aclose()

            self._post_endpoint = None
            self._client = httpx.AsyncClient()
            self._read_task = asyncio.create_task(self._sse_read_loop())

            for _ in range(50):
                if self._post_endpoint is not None:
                    break
                await asyncio.sleep(0.1)

            if self._post_endpoint is None:
                msg = "Failed to receive POST endpoint from SSE stream."
                raise RuntimeError(msg)

    async def _sse_read_loop(self) -> None:  # pragma: no cover
        if not self._client:
            return

        headers = self.profile.headers or {}
        headers["Accept"] = "text/event-stream"

        try:
            async with self._client.stream("GET", str(self.profile.uri), headers=headers) as response:
                response.raise_for_status()

                current_event = "message"
                current_data = ""

                async for line in response.aiter_lines():
                    if not line:
                        if current_data:
                            self._handle_sse_event(current_event, current_data)
                            current_data = ""
                        current_event = "message"
                        continue

                    if line.startswith("event: "):
                        current_event = line[7:]
                    elif line.startswith("data: "):
                        current_data += line[6:]

        except Exception as e:
            logger.exception(f"Error in SSEMCPClient read loop: {e}")
        finally:
            for fut in self._pending_requests.values():
                if not fut.done():
                    fut.set_exception(RuntimeError("SSE connection closed"))
            self._pending_requests.clear()

    def _handle_sse_event(self, event: str, data: str) -> None:  # pragma: no cover
        if event == "endpoint":
            if data.startswith("http"):
                self._post_endpoint = data
            else:
                from urllib.parse import urljoin

                self._post_endpoint = urljoin(str(self.profile.uri), data)
            return

        try:
            resp = json.loads(data)
            if "id" in resp and isinstance(resp["id"], int):
                req_id = resp["id"]
                if req_id in self._pending_requests:
                    fut = self._pending_requests.pop(req_id)
                    if not fut.done():
                        if "error" in resp:
                            fut.set_exception(RuntimeError(f"JSON-RPC Error: {resp['error']}"))
                        else:
                            fut.set_result(resp.get("result", {}))
        except json.JSONDecodeError:
            pass

    async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:  # pragma: no cover
        # OCap Whitelist Validation
        if self.manifest.capability_whitelist and method == "tools/call":
            whitelist = getattr(self.manifest.capability_whitelist, "allowed_tools", None)
            tool_name = params.get("name") if params else None
            if whitelist is not None and tool_name not in whitelist:
                msg = f"OCap Violation: Tool '{tool_name}' is not inside the capability_whitelist.allowed_tools."
                raise RuntimeError(msg)

        await self._connect_sse()

        if not self._client or not self._post_endpoint:
            msg = "SSE Transport not connected properly"
            raise RuntimeError(msg)

        self._request_cid += 1
        req_id = self._request_cid
        req = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
        }
        if params is not None:
            req["params"] = params

        fut: asyncio.Future[dict[str, Any]] = asyncio.Future()
        self._pending_requests[req_id] = fut

        headers = self.profile.headers or {}
        headers["Content-Type"] = "application/json"

        try:
            response = await self._client.post(self._post_endpoint, json=req, headers=headers)
            response.raise_for_status()
        except Exception as e:
            logger.exception(f"Failed to post JSON-RPC request to SSE endpoint: {e}")
            self._pending_requests.pop(req_id, None)
            msg = f"Failed to post JSON-RPC request to SSE endpoint: {e}"
            raise RuntimeError(msg) from e

        return await fut
