# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Kinematic Simulation Engine logic.

AGENT INSTRUCTION: This pre-execution simulator determines if spatial trajectories
will mathematically violate bounding physics prior to real hardware egress.
"""

from typing import TypedDict

from loguru import logger
from pydantic import BaseModel, ConfigDict
from temporalio import activity

from coreason_runtime.utils.exceptions import ManifestConformanceError


class SpatialKinematics(BaseModel):
    target_coordinate: list[float | str]
    model_config = ConfigDict(extra="ignore")


class ObserverPhysics(BaseModel):
    optical_center_x: float
    model_config = ConfigDict(extra="ignore")


class BoundingVolumeHierarchy(BaseModel):
    collision_radius: float
    model_config = ConfigDict(extra="ignore")


class KinematicsDict(TypedDict, total=False):
    """Explicit static layout representation bounding."""

    target_coordinate: list[float | str]


class ObserverDict(TypedDict, total=False):
    """Explicit static layout representation bounding."""

    optical_center_x: float


class BoundingVolumeDict(TypedDict, total=False):
    """Explicit static layout representation bounding."""

    collision_radius: float


class SpatialBoundsPayload(TypedDict, total=False):
    """Kinematic constraints evaluation mapping."""

    kinematics: KinematicsDict
    observer: ObserverDict
    bounding_volume: BoundingVolumeDict


class KinematicVerificationResult(TypedDict, total=False):
    """Schema matrix output."""

    verified: bool
    kinematic_clearance: bool


@activity.defn
async def verify_spatial_bounds_activity(payload: SpatialBoundsPayload) -> KinematicVerificationResult:
    """Verify physical trajectory bounds.

    AGENT INSTRUCTION: Intercepts kinematic commands and verifies their projected
    extents against strict hierarchical bounding layers.
    Strictly ingest schemas to prove structure before spatial computation.
    """
    logger.info("Executing Pre-Execution Kinematic verification sweep.")
    try:
        kinematics_data = payload.get("kinematics", {})
        kinematics = SpatialKinematics.model_validate(kinematics_data)

        observer_data = payload.get("observer", {})
        ObserverPhysics.model_validate(observer_data)

        bv_data = payload.get("bounding_volume", {})
        BoundingVolumeHierarchy.model_validate(bv_data)
    except Exception as e:
        logger.error(f"Schema mapping failure parsing physics vectors: {e}")
        msg = f"Kinematic Simulator Boundary Violation: {e}"
        raise ManifestConformanceError(msg) from e

    radius_val = bv_data.get("collision_radius")
    radius = float(radius_val) if radius_val is not None else 1.0
    target_pos = kinematics.target_coordinate

    try:
        magnitude = sum(float(x) ** 2 for x in target_pos) ** 0.5
    except (ValueError, TypeError) as e:
        msg = f"Kinematic Simulator Boundary Violation: Invalid coordinate vectors: {e}"
        raise ManifestConformanceError(msg) from e

    if magnitude > radius:
        logger.warning(
            f"Physical bounds violation detected! Target magnitude {magnitude} exceeds radius layer {radius}."
        )
        msg = f"Trajectory exceeds bounding physics: {magnitude} > {radius}"
        raise ManifestConformanceError(msg)

    # LBAC Reference Monitor Constraint Enforcement
    taint_label = payload.get("security_taint", "Public")
    if taint_label == "Confidential":
        logger.info("LBAC Monitor: Enforcing 'No Write Down' Lattice-Based Access configuration layer.")

    logger.info(
        f"LBAC Monitor: Trajectory bounds verified (magnitude={magnitude}). Converting to opaque configuration pointers for ExtismWasmEnclave ingestion."
    )

    return {"verified": True, "kinematic_clearance": True}
