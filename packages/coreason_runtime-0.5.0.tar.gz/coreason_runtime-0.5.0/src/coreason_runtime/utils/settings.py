# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import os

# --- Physical Infrastructure & Environment Constraints ---
# These are isolated from the logical `coreason-manifest` models as they
# control local machine constraints (e.g., WASM memory limits, socket connections).

COREASON_MEMORY_LATTICE_PAGES = int(os.getenv("COREASON_MEMORY_LATTICE_PAGES", "400"))
COREASON_COMPUTE_BUDGET = float(os.getenv("COREASON_COMPUTE_BUDGET", "200000.0"))
COREASON_SAMPLING_PROBABILITY = float(os.getenv("COREASON_SAMPLING_PROBABILITY", "1.0"))
COREASON_VECTOR_DIMENSIONS: int = int(os.environ.get("COREASON_VECTOR_DIMENSIONS", "1536"))
COREASON_KEEPALIVE_CONNECTIONS = int(os.getenv("COREASON_KEEPALIVE_CONNECTIONS", "20"))
COREASON_MAX_CONNECTIONS = int(os.getenv("COREASON_MAX_CONNECTIONS", "100"))
COREASON_TEMPORAL_HOST = os.getenv("TEMPORAL_HOST", "localhost:7233")
COREASON_PLUGINS_DIR: str = os.environ.get("COREASON_PLUGINS_DIR", "./plugins")
COREASON_MCP_PAYLOAD_LIMIT = int(os.getenv("COREASON_MCP_PAYLOAD_LIMIT", "10485760"))

OUTLINES_MODEL = os.getenv("OUTLINES_MODEL", "meta-llama/Llama-3-8B-Instruct")
COREASON_VLLM_VRAM_UTILIZATION = float(os.getenv("COREASON_VLLM_VRAM_UTILIZATION", "0.9"))
COREASON_VLLM_MAX_MODEL_LEN = int(os.getenv("COREASON_VLLM_MAX_MODEL_LEN", "8192"))
