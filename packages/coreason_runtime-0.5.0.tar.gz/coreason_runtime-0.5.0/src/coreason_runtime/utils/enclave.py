# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import base64
from typing import Any

import cbor2
from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec


class SecurityError(Exception):
    """Exception raised for TEE hardware attestation failures."""


def _raise_security_error(msg: str) -> None:
    """Raise a SecurityError with the given message."""
    raise SecurityError(msg)


class TEEVerifier:
    """Implement cryptographic TEE attestation verification for hardware enclaves.

    Parses AWS Nitro Enclave COSE signatures, cryptographically verifies against
    the root CA, and extracts PCR bindings to assert zero-trust invariants.
    """

    def __init__(self, root_certificate_pem: bytes | None = None) -> None:
        """Initialize the TEE verifier.

        Args:
            root_certificate_pem: Optional Root CA certificate for AWS Nitro verification.
        """
        self.root_certificate_pem = root_certificate_pem
        self.supported_enclaves = ["aws_nitro"]

    def _verify_cose_signature(
        self, protected_header: bytes, payload: bytes, signature: bytes, public_key: Any
    ) -> None:
        """Verify the COSE Sign1 mathematical signature.

        Args:
            protected_header: The CBOR-encoded protected headers.
            payload: The CBOR-encoded payload document.
            signature: The raw signature bytes.
            public_key: The cryptography curve public key.

        Raises:
            SecurityError: Mathematically invalid signature.
        """
        # COSE Sign1 signature structure: ["Signature1", protected_header, external_aad, payload]
        sig_structure = cbor2.dumps(["Signature1", protected_header, b"", payload])

        try:
            # AWS Nitro typically uses ES384 (ECDSA with SHA-384)
            public_key.verify(signature, sig_structure, ec.ECDSA(hashes.SHA384()))
        except InvalidSignature as e:
            # Fallback to ES256 if needed
            try:
                public_key.verify(signature, sig_structure, ec.ECDSA(hashes.SHA256()))
            except InvalidSignature:
                msg = "Mathematical verification of the COSE signature failed."
                raise SecurityError(msg) from e

    def verify_hardware_quote(self, hardware_signature_blob: str, enclave_class: str, expected_pcr_hash: str) -> bool:
        """Mathematically verify AWS Nitro Enclave COSE attestation and PCR hashes.

        Args:
            hardware_signature_blob: Base64-encoded COSE Sign1 attestation document.
            enclave_class: Type of enclave architecture.
            expected_pcr_hash: The target cryptographic measurement hash to enforce.

        Returns:
            True if the attestation signature and PCRs are cryptographically valid.
        """
        if enclave_class not in self.supported_enclaves:
            msg = f"Unsupported enclave class: {enclave_class}"
            raise SecurityError(msg)

        try:
            raw_cbor = base64.urlsafe_b64decode(hardware_signature_blob)
            cose_sign1 = cbor2.loads(raw_cbor)

            if not isinstance(cose_sign1, list) or len(cose_sign1) != 4:
                _raise_security_error("Invalid COSE Sign1 cryptographic structure.")

            protected_header, unprotected_header, payload, signature = cose_sign1
        except SecurityError:
            raise
        except Exception as e:
            msg = f"Structural parsing of COSE document failed: {e}"
            raise SecurityError(msg) from e

        # Extract certificates to verify signature
        if unprotected_header.get(b"cab"):
            # AWS Nitro certs inside unprotected header
            cert_der = unprotected_header[b"cab"][0]
            try:
                cert = x509.load_der_x509_certificate(cert_der, default_backend())
                public_key = cert.public_key()
                self._verify_cose_signature(protected_header, payload, signature, public_key)
            except SecurityError:
                raise
            except Exception as e:
                msg = f"Certificate parsing or verification failed: {e}"
                raise SecurityError(msg) from e
        else:
            # We strictly enforce that a valid CAB is provided in Nitro quotes
            msg = "No x509 certificate found inside the COSE unprotected header."
            raise SecurityError(msg)

        # Extract PCRs
        try:
            payload_data = cbor2.loads(payload)
            pcrs = payload_data.get("pcrs", payload_data.get(b"pcrs", {}))

            # Allow expected_pcr_hash to match the exact hex of PCR0
            pcr_zero = pcrs.get(0, pcrs.get(b"0"))
            if not pcr_zero:
                _raise_security_error("PCR0 measurement completely missing from hardware quote.")

            if pcr_zero.hex() != expected_pcr_hash:
                msg = f"PCR measurement mismatch. Expected: {expected_pcr_hash}"
                _raise_security_error(msg)

        except SecurityError:
            raise
        except Exception as e:
            msg = f"Failed to extract platform configuration registers: {e}"
            raise SecurityError(msg) from e

        return True
