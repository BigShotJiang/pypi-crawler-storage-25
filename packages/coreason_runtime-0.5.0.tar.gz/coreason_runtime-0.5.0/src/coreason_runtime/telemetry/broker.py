# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
import json
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI
from fastapi.responses import StreamingResponse

from coreason_runtime.utils.logger import logger

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

# In-memory registry of active client connections.
_active_clients: list[asyncio.Queue[str]] = []


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    _ = app  # Explicitly mark `app` as used to avoid ARG001
    logger.info("Telemetry Broker started.")
    from coreason_runtime.telemetry.subscriber import bronze_ingestion_loop

    ingestion_task = asyncio.create_task(bronze_ingestion_loop())
    yield
    ingestion_task.cancel()
    import contextlib

    with contextlib.suppress(asyncio.CancelledError):
        await ingestion_task
    logger.info("Telemetry Broker stopped.")  # pragma: no cover


app = FastAPI(title="CoReason Telemetry Broker", version="1.0.0", lifespan=lifespan)


@app.post("/api/v1/telemetry/push")
async def push_telemetry(event: dict[str, Any]) -> dict[str, str]:
    """Ingest a TelemetryEvent and fan it out to all connected clients."""
    try:
        payload = json.dumps(event)

        for queue in _active_clients:
            try:
                queue.put_nowait(payload)
            except asyncio.QueueFull:  # pragma: no cover
                import contextlib

                with contextlib.suppress(asyncio.QueueEmpty):
                    queue.get_nowait()
                with contextlib.suppress(asyncio.QueueFull):
                    queue.put_nowait(payload)

        return {"status": "ok"}
    except Exception as e:
        logger.exception(f"Failed to push telemetry event: {e}")
        return {"status": "error", "message": str(e)}


async def sse_generator(client_queue: asyncio.Queue[str]) -> AsyncGenerator[str]:
    """Generator for Server-Sent Events."""
    try:
        while True:
            # Wait for an event to be placed in the queue
            payload = await client_queue.get()
            yield f"data: {payload}\n\n"
    except asyncio.CancelledError:
        logger.info("Client disconnected from telemetry stream.")
        if client_queue in _active_clients:
            _active_clients.remove(client_queue)
        raise


@app.get("/api/v1/telemetry/stream")
async def stream_telemetry() -> StreamingResponse:
    """Stream telemetry.events to connected clients via SSE."""
    client_queue: asyncio.Queue[str] = asyncio.Queue(maxsize=100)
    _active_clients.append(client_queue)
    logger.info("New client connected to telemetry stream.")
    return StreamingResponse(sse_generator(client_queue), media_type="text/event-stream")


async def backpressure_sse_generator(
    client_queue: asyncio.Queue[str],
    focal_refresh_rate_hz: float = 60.0,
) -> AsyncGenerator[str]:
    """SSE generator with TelemetryBackpressureContract enforcement.

    Throttles the stream yield rate to the specified Hz ceiling.
    If the client falls behind, frames are dropped via ring-buffer semantics.

    Args:
        client_queue: The asyncio.Queue feeding events for this client.
        focal_refresh_rate_hz: Maximum frames per second to yield (default 60Hz).
    """
    import time

    min_interval = 1.0 / max(focal_refresh_rate_hz, 1.0)
    last_yield_time = 0.0

    try:
        while True:
            payload = await client_queue.get()
            now = time.monotonic()
            elapsed = now - last_yield_time

            if elapsed < min_interval:
                await asyncio.sleep(min_interval - elapsed)

            last_yield_time = time.monotonic()
            yield f"data: {payload}\n\n"
    except asyncio.CancelledError:
        logger.info("Backpressure-controlled client disconnected from telemetry stream.")
        if client_queue in _active_clients:
            _active_clients.remove(client_queue)
        raise


@app.get("/api/v1/telemetry/stream/throttled")
async def stream_telemetry_throttled(hz: float = 60.0) -> StreamingResponse:
    """Stream telemetry with backpressure control at the specified Hz refresh rate."""
    client_queue: asyncio.Queue[str] = asyncio.Queue(maxsize=100)
    _active_clients.append(client_queue)
    logger.info(f"New throttled client connected at {hz}Hz.")
    return StreamingResponse(
        backpressure_sse_generator(client_queue, focal_refresh_rate_hz=hz),
        media_type="text/event-stream",
    )


@app.post("/api/v1/telemetry/ambient")
async def push_ambient_state(state: dict[str, Any]) -> dict[str, str]:
    """Ingest an AmbientState telemetry payload and fan it out via SSE.

    Expected fields: epistemic_entropy_score, thermodynamic_burn_rate.
    """
    payload = json.dumps({"type": "AmbientState", "data": state})
    for queue in _active_clients:
        try:
            queue.put_nowait(payload)
        except asyncio.QueueFull:  # pragma: no cover
            import contextlib

            with contextlib.suppress(asyncio.QueueEmpty):
                queue.get_nowait()
            with contextlib.suppress(asyncio.QueueFull):
                queue.put_nowait(payload)
    return {"status": "ok"}
