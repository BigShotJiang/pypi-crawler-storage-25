# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
from typing import Any

import dlt

from coreason_runtime.telemetry.broker import _active_clients


async def bronze_ingestion_loop(batch_size: int = 50) -> None:
    """Listens to the broker and flushes raw events to the Bronze filesystem layer."""
    pipeline = dlt.pipeline(
        pipeline_name="epistemic_exhaust",
        destination=dlt.destinations.filesystem("data/bronze"),
        dataset_name="telemetry",
    )

    buffer: list[dict[str, Any]] = []
    subscriber_queue: asyncio.Queue[str] = asyncio.Queue()
    _active_clients.append(subscriber_queue)

    import json

    try:
        while True:
            event_payload = await subscriber_queue.get()
            # Convert JSON payload string back to dict for dlt
            try:
                event_dict = json.loads(event_payload)
                buffer.append(event_dict)
            except json.JSONDecodeError:
                pass

            if len(buffer) >= batch_size:
                # Flush to parquet via dlt
                pipeline.run(buffer, table_name="raw_events")
                buffer.clear()
    except asyncio.CancelledError:
        if buffer:  # pragma: no cover
            pipeline.run(buffer, table_name="raw_events")
