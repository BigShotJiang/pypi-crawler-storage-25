# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import math

from coreason_manifest import (
    AuctionPolicy,
    AuctionState,
    EscrowPolicy,
    PredictionMarketState,
    TaskAwardReceipt,
)


def resolve_auction(state: AuctionState, policy: AuctionPolicy) -> TaskAwardReceipt:  # pragma: no cover
    """
    AGENT INSTRUCTION: This capability enforces the N-dimensional order book resolution constraint.
    It strictly filters bids against the max_budget_magnitude and deterministically bounds
    the winning agent to an EscrowPolicy tied to ExecutionSuccess.

        AGENT INSTRUCTION: VCG Auction Math: lowest bidder wins, but is awarded the second-lowest price
    """
    announcement = state.announcement
    bids = state.bids

    if not bids:
        msg = "Cannot resolve auction: No bids available."
        raise ValueError(msg)

    valid_bids = [bid for bid in bids if bid.estimated_cost_magnitude <= announcement.max_budget_magnitude]

    if not valid_bids:
        msg = "Cannot resolve auction: No bids satisfy the constraints."
        raise ValueError(msg)

    sorted_bids = sorted(valid_bids, key=lambda b: (-b.confidence_score, b.estimated_cost_magnitude, b.agent_cid))
    winning_bid = sorted_bids[0]

    tied_bids = [
        b
        for b in sorted_bids
        if b.confidence_score == winning_bid.confidence_score
        and b.estimated_cost_magnitude == winning_bid.estimated_cost_magnitude
    ]

    cleared_price = winning_bid.estimated_cost_magnitude
    if policy.auction_type == "vickrey" and len(sorted_bids) > len(tied_bids):
        cleared_price = sorted_bids[len(tied_bids)].estimated_cost_magnitude

    target_node_cid = tied_bids[0].agent_cid if len(tied_bids) == 1 else "syndicate"

    escrow = EscrowPolicy(
        escrow_locked_magnitude=cleared_price,
        release_condition_metric="ExecutionSuccess",
        refund_target_node_cid=target_node_cid,
    )

    split_price = int(cleared_price / len(tied_bids))
    remainder = cleared_price - (split_price * len(tied_bids))

    syndicate_awards = {}
    for i, b in enumerate(tied_bids):
        syndicate_awards[b.agent_cid] = split_price + (remainder if i == 0 else 0)

    return TaskAwardReceipt(
        task_cid=announcement.task_cid,
        awarded_syndicate=syndicate_awards,
        cleared_price_magnitude=cleared_price,
        escrow=escrow,
    )


def settle_prediction_market(state: PredictionMarketState) -> PredictionMarketState:  # pragma: no cover
    """
    AGENT INSTRUCTION: This implementation mathematically enforces Robin Hanson's LMSR.
    It evaluates the bounded order book and normalizes stakes against the liquidity parameter (b)
    to prevent probability overflow before yielding the updated PredictionMarketState.
    """
    try:
        b = float(state.lmsr_b_parameter)
    except ValueError:
        b = 100.0

    if b <= 0.0:
        b = 100.0

    q: dict[str, float] = {}

    for stake in state.order_book:
        target = stake.target_hypothesis_cid
        if target not in q:
            q[target] = 0.0
        q[target] += float(stake.staked_magnitude)

    if not q:
        if state.current_market_probabilities:
            n = len(state.current_market_probabilities)
            prob = 1.0 / n if n > 0 else 0.0
            no_stake_probs = {k: str(prob) for k in state.current_market_probabilities}
        else:
            no_stake_probs = {}

        return state.model_copy(update={"current_market_probabilities": no_stake_probs})

    max_q = max(q.values())

    exp_terms: dict[str, float] = {}
    sum_exp = 0.0

    for hypothesis_id, quantity in q.items():
        exp_val = math.exp((quantity - max_q) / b)
        exp_terms[hypothesis_id] = exp_val
        sum_exp += exp_val

    new_probs = {}
    for hypothesis_id, exp_val in exp_terms.items():
        hypothesis_prob = exp_val / sum_exp
        new_probs[hypothesis_id] = str(hypothesis_prob)

    for hypothesis_id in state.current_market_probabilities:
        if hypothesis_id not in new_probs:
            exp_val = math.exp((0.0 - max_q) / b)
            unstaked_prob = exp_val / sum_exp
            new_probs[hypothesis_id] = str(unstaked_prob)

    total_prob = sum(float(v) for v in new_probs.values())
    if total_prob > 0 and not math.isclose(total_prob, 1.0, abs_tol=1e-5):
        new_probs = {k: str(float(v) / total_prob) for k, v in new_probs.items()}

    return state.model_copy(update={"current_market_probabilities": new_probs})


def calculate_lmsr_price(
    b_parameter: float,
    hypothesis_shares: dict[str, int],
    target_hypothesis: str,
) -> float:
    """Calculate the LMSR price for a given hypothesis using Robin Hanson's formula.

    Formula: P(q_i) = exp(q_i / b) / sum_j(exp(q_j / b))

    Uses the log-sum-exp trick to prevent float overflow when b_parameter is small.

    Args:
        b_parameter: The liquidity parameter controlling market sensitivity.
        hypothesis_shares: A mapping of hypothesis CID to outstanding shares.
        target_hypothesis: The hypothesis CID to price.

    Returns:
        The LMSR probability price for the target hypothesis in [0, 1].
    """
    if b_parameter <= 0.0:
        b_parameter = 100.0

    if target_hypothesis not in hypothesis_shares:
        return 0.0

    shares = {k: float(v) for k, v in hypothesis_shares.items()}
    max_q = max(shares.values()) if shares else 0.0

    exp_terms: dict[str, float] = {}
    sum_exp = 0.0
    for h_cid, q in shares.items():
        exp_val = math.exp((q - max_q) / b_parameter)
        exp_terms[h_cid] = exp_val
        sum_exp += exp_val

    if sum_exp == 0.0:
        return 0.0

    return exp_terms[target_hypothesis] / sum_exp


def settle_market(
    market_state: PredictionMarketState,
    winning_hypothesis_cid: str,
) -> TaskAwardReceipt:
    """Settle a prediction market by computing Brier scores and distributing escrow.

    Brier Score for agent i: BS_i = (1 - p_i_win)^2 + sum_{j!=win}(p_i_j)^2
    Lower Brier score = better prediction. Escrow is distributed inversely proportional.

    Args:
        market_state: The current PredictionMarketState with order_book and escrow.
        winning_hypothesis_cid: The CID of the hypothesis that was validated as true.

    Returns:
        A TaskAwardReceipt distributing escrow to participants.
    """
    total_pool = sum(float(s.staked_magnitude) for s in market_state.order_book)

    agent_stakes: dict[str, dict[str, float]] = {}
    for stake in market_state.order_book:
        agent = stake.agent_cid
        target = stake.target_hypothesis_cid
        magnitude = float(stake.staked_magnitude)
        if agent not in agent_stakes:
            agent_stakes[agent] = {}
        agent_stakes[agent][target] = agent_stakes[agent].get(target, 0.0) + magnitude

    all_hypotheses: set[str] = set()
    for stakes in agent_stakes.values():
        all_hypotheses.update(stakes.keys())
    all_hypotheses.add(winning_hypothesis_cid)

    brier_scores: dict[str, float] = {}
    for agent, stakes in agent_stakes.items():
        total_stake = sum(stakes.values())
        if total_stake == 0:
            brier_scores[agent] = 2.0
            continue

        probabilities = {h: stakes.get(h, 0.0) / total_stake for h in all_hypotheses}

        brier = 0.0
        for h_cid, p in probabilities.items():
            outcome = 1.0 if h_cid == winning_hypothesis_cid else 0.0
            brier += (p - outcome) ** 2
        brier_scores[agent] = brier

    if not brier_scores:
        msg = "Cannot settle market: No participants in the order book."
        raise ValueError(msg)

    inverse_scores = {agent: 1.0 / (bs + 1e-9) for agent, bs in brier_scores.items()}
    total_inverse = sum(inverse_scores.values())

    syndicate_awards: dict[str, int] = {}
    for agent, inv in inverse_scores.items():
        share = (inv / total_inverse) * total_pool if total_inverse > 0 else 0.0
        syndicate_awards[agent] = int(share)

    return TaskAwardReceipt(
        task_cid=market_state.market_cid,
        awarded_syndicate=syndicate_awards,
        cleared_price_magnitude=int(total_pool),
        escrow=EscrowPolicy(
            escrow_locked_magnitude=int(total_pool),
            release_condition_metric="BrierScoreSettlement",
            refund_target_node_cid=winning_hypothesis_cid,
        ),
    )
