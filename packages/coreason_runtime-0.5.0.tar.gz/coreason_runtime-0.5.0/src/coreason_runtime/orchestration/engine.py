# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
import typing
import uuid

from coreason_manifest import (
    AdversarialMarketTopologyManifest,
    CapabilityForgeTopologyManifest,
    ConsensusFederationTopologyManifest,
    CouncilTopologyManifest,
    DAGTopologyManifest,
    DigitalTwinTopologyManifest,
    DiscourseTreeManifest,
    DocumentKnowledgeGraphManifest,
    EvaluatorOptimizerTopologyManifest,
    EvolutionaryTopologyManifest,
    ExecutionEnvelopeState,
    HierarchicalDOMManifest,
    IntentElicitationTopologyManifest,
    NeurosymbolicVerificationTopologyManifest,
    SMPCTopologyManifest,
    StateVectorProfile,
    SwarmTopologyManifest,
    TraceContextState,
    WorkflowManifest,
)
from pydantic import ValidationError
from temporalio.client import Client

from coreason_runtime.orchestration.worker import TASK_QUEUE
from coreason_runtime.orchestration.workflows import (
    AdversarialMarketExecutionWorkflow,
    CapabilityForgeExecutionWorkflow,
    ConsensusFederationExecutionWorkflow,
    CouncilExecutionWorkflow,
    DAGExecutionWorkflow,
    DigitalTwinExecutionWorkflow,
    DiscourseTreeExecutionWorkflow,
    DocumentKnowledgeGraphExecutionWorkflow,
    EvaluatorOptimizerExecutionWorkflow,
    EvolutionaryExecutionWorkflow,
    HierarchicalDOMExecutionWorkflow,
    IntentElicitationExecutionWorkflow,
    NeurosymbolicVerificationExecutionWorkflow,
    SMPCExecutionWorkflow,
    SwarmExecutionWorkflow,
)
from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.security import verify_genesis_provenance, verify_pq_signature
from coreason_runtime.utils.settings import COREASON_COMPUTE_BUDGET

if typing.TYPE_CHECKING:
    from coreason_manifest.spec.ontology import ActiveInferenceContract, ActiveInferenceEpochState


def _get_manifest_key(cls: type) -> str:
    fields = getattr(cls, "model_fields", {})
    if "topology_class" in fields:
        return str(fields["topology_class"].default)
    if "type" in fields:
        return str(fields["type"].default)
    import re

    name = cls.__name__
    if name.endswith("TopologyManifest"):
        name = name.removesuffix("TopologyManifest")
    elif name.endswith("Manifest"):
        name = name.removesuffix("Manifest")
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


_WORKFLOW_REGISTRY = {
    AdversarialMarketTopologyManifest.model_fields["topology_class"].default: AdversarialMarketExecutionWorkflow.run,
    CapabilityForgeTopologyManifest.model_fields["topology_class"].default: CapabilityForgeExecutionWorkflow.run,
    ConsensusFederationTopologyManifest.model_fields[
        "topology_class"
    ].default: ConsensusFederationExecutionWorkflow.run,
    CouncilTopologyManifest.model_fields["topology_class"].default: CouncilExecutionWorkflow.run,
    DAGTopologyManifest.model_fields["topology_class"].default: DAGExecutionWorkflow.run,
    DigitalTwinTopologyManifest.model_fields["topology_class"].default: DigitalTwinExecutionWorkflow.run,
    DiscourseTreeManifest.model_fields["topology_class"].default: DiscourseTreeExecutionWorkflow.run,
    DocumentKnowledgeGraphManifest.model_fields["topology_class"].default: DocumentKnowledgeGraphExecutionWorkflow.run,
    EvaluatorOptimizerTopologyManifest.model_fields["topology_class"].default: EvaluatorOptimizerExecutionWorkflow.run,
    EvolutionaryTopologyManifest.model_fields["topology_class"].default: EvolutionaryExecutionWorkflow.run,
    HierarchicalDOMManifest.model_fields["topology_class"].default: HierarchicalDOMExecutionWorkflow.run,
    IntentElicitationTopologyManifest.model_fields["topology_class"].default: IntentElicitationExecutionWorkflow.run,
    NeurosymbolicVerificationTopologyManifest.model_fields[
        "topology_class"
    ].default: NeurosymbolicVerificationExecutionWorkflow.run,
    SMPCTopologyManifest.model_fields["topology_class"].default: SMPCExecutionWorkflow.run,
    SwarmTopologyManifest.model_fields["topology_class"].default: SwarmExecutionWorkflow.run,
}


class CoreasonRuntime:
    """The official zero-trust, high-throughput kinetic execution engine for the coreason-manifest ontology.

    This class serves as the primary entry point to connect to the underlying
    Temporal orchestration plane, the SGLang inference engine, and the LanceDB
    memory store.
    """

    def __init__(
        self,
        temporal_host: str = "localhost:7233",
        sglang_url: str = "http://localhost:30000",
        memory_path: str = "./lancedb_store",
    ) -> None:
        """Initialize the CoreasonRuntime.


        AGENT INSTRUCTION: state_vector.immutable_matrix, not injected into the topology
        payload (which has strict schema validation via additionalProperties: false).

        Args:
            temporal_host: The host and port of the Temporal cluster.
            sglang_url: The URL for the SGLang inference engine.
            memory_path: The local path or URI for the LanceDB store.
        """
        self.temporal_host = temporal_host
        self.sglang_url = sglang_url
        self.memory_path = memory_path
        self._client: Client | None = None

    @classmethod
    async def connect(
        cls,
        target_cluster: str = "localhost:7233",
        sglang_url: str = "http://localhost:30000",
        memory_path: str = "./lancedb_store",
    ) -> CoreasonRuntime:
        """Connect to the Temporal cluster.

        AGENT INSTRUCTION: Initializes the Temporal client safely connecting via async static generation.
        """
        instance = cls(temporal_host=target_cluster, sglang_url=sglang_url, memory_path=memory_path)
        instance._client = await Client.connect(target_cluster)
        logger.info(f"Connected to Temporal at {target_cluster}")
        return instance

    async def execute_manifest(
        self, manifest: WorkflowManifest, exogenous_perturbation_vector: str | None = None
    ) -> dict[str, typing.Any]:
        """Execute a coreason-manifest JSON dictionary natively in-memory.

        AGENT INSTRUCTION: Translate ontology manifest structurally for spatial evaluation natively.
        """

        manifest_data: dict[str, typing.Any] = manifest.model_dump(mode="json")
        return await self.execute_from_dict(manifest_data, exogenous_perturbation_vector)

    async def execute_from_dict(
        self, manifest_data: dict[str, typing.Any], exogenous_perturbation_vector: str | None = None
    ) -> dict[str, typing.Any]:
        """Execute a coreason-manifest JSON dictionary natively in-memory.

        AGENT INSTRUCTION: Hydrate dictionary maps directly.
        """
        logger.info("Execution started for manifest from RAM dictionary")

        try:
            topology_payload = manifest_data.get("topology", {})
            if "edges" in topology_payload:
                topology_payload["edges"] = [
                    tuple(edge) if isinstance(edge, list) else edge for edge in topology_payload["edges"]
                ]

            if "dag" in topology_payload and isinstance(topology_payload["dag"], dict):  # pragma: no cover
                dag_payload = topology_payload["dag"]
                if "edges" in dag_payload:
                    dag_payload["edges"] = [
                        tuple(edge) if isinstance(edge, list) else edge for edge in dag_payload["edges"]
                    ]

            try:
                manifest = WorkflowManifest.model_validate(manifest_data, strict=False)
            except ValidationError as e:
                logger.error(f"Manifest validation failed: {e}")
                from coreason_runtime.utils.exceptions import ManifestConformanceError

                msg = f"Invalid WorkflowManifest format: {e}"
                raise ManifestConformanceError(msg) from e

            genesis_dict = manifest.genesis_provenance.model_dump(mode="json")
            if not verify_genesis_provenance(genesis_dict):
                msg = "Invalid genesis provenance. Cryptographic audit trail rejected."
                raise ValueError(msg)  # pragma: no cover

            if manifest.pq_signature:
                pq_dict = manifest.pq_signature.model_dump(mode="json")
                if not verify_pq_signature(pq_dict):
                    msg = "Post-quantum signature verification failed."
                    raise ValueError(msg)

            compile_to_base_topology = getattr(manifest.topology, "compile_to_base_topology", None)
            if compile_to_base_topology is not None:
                base_topology = compile_to_base_topology()
                topology_payload = base_topology.model_dump(mode="json", exclude_none=True)
                macro_type = getattr(manifest.topology, "topology_class", getattr(manifest.topology, "type", "unknown"))
                base_type = getattr(base_topology, "topology_class", getattr(base_topology, "type", "unknown"))
                logger.info(f"Unrolled macro-topology '{macro_type}' into base topology '{base_type}'")
            else:
                topology_payload = manifest.topology.model_dump(mode="json", exclude_none=True)

            if manifest.allowed_semantic_classifications:
                topology_payload["allowed_semantic_classifications"] = [
                    str(cls) for cls in manifest.allowed_semantic_classifications
                ]

            if manifest.governance:
                topology_payload["governance"] = manifest.governance.model_dump(mode="json", exclude_none=True)

            if exogenous_perturbation_vector:
                """AGENT INSTRUCTION: Transmute into Markov Blanket exogenous shock"""
                for node_cid, node_data in topology_payload.get("nodes", {}).items():
                    """AGENT INSTRUCTION: Coalgebraic Thunking: lazy evaluate sub-graphs"""
                    node_type = node_data.get("type") or node_data.get("topology_class")
                    if node_type == "composite" and node_data.get("eval_strategy") == "lazy":  # pragma: no cover
                        logger.info(
                            f"Deferred instantiation of sub-swarm '{node_cid}' via coalg_thunking."
                        )  # pragma: no cover
                        node_data["status"] = "THUNKED"  # pragma: no cover

                    if node_type == "agent":
                        """AGENT INSTRUCTION: We project the shock directly into the agent's textual context to bypass Pydantic static typing constraints"""
                        current_desc = node_data.get("description", "")
                        node_data["description"] = (
                            f"{current_desc}\n\nUSER QUERY CONSTRAINT:\n{exogenous_perturbation_vector}"
                        )
                        logger.info(
                            f"Dynamically injected exogenous perturbation into agent node '{node_cid}' description"
                        )

            logger.debug("Successfully validated dictionary manifest payloads.")
        except ValueError as e:
            logger.exception(f"Failed to parse or validate manifest: {e}")
            raise

        if not self._client:
            logger.warning("Temporal client not connected. Attempting to connect now.")
            self._client = await Client.connect(self.temporal_host)

        if self._client is None:
            msg = "Temporal client failed to connect."
            raise RuntimeError(msg)  # pragma: no cover

        trace_id = str(uuid.uuid7())
        workflow_id = f"execution-{trace_id}"
        manifest_type = topology_payload.get("topology_class", topology_payload.get("type"))

        root_trace_context = TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0)

        import typing

        from coreason_manifest import JsonPrimitiveState

        immutable_matrix: dict[str, typing.Any] = {
            "tenant_cid": manifest.tenant_cid,
            "session_cid": manifest.session_cid,
        }
        if manifest.allowed_semantic_classifications:
            immutable_matrix["allowed_semantic_classifications"] = [
                str(cls) for cls in manifest.allowed_semantic_classifications
            ]

        budget = COREASON_COMPUTE_BUDGET
        if manifest.governance and manifest.governance.max_budget_magnitude:
            budget = float(manifest.governance.max_budget_magnitude)

        mutable_matrix: dict[str, typing.Any] = {
            "accumulated_tokens": 0,
            "accumulated_cost": 0.0,
            "iterations": 0,
            "compute_budget": int(budget),
        }

        state_vector = StateVectorProfile(
            immutable_matrix=typing.cast("dict[str, JsonPrimitiveState]", immutable_matrix),
            mutable_matrix=typing.cast("dict[str, JsonPrimitiveState]", mutable_matrix),
            is_delta=False,
        )

        envelope = ExecutionEnvelopeState[dict[str, typing.Any]](
            trace_context=root_trace_context,
            state_vector=state_vector,
            payload=topology_payload,
        )

        import typing

        workflow_run_func = _WORKFLOW_REGISTRY.get(str(manifest_type))

        if not workflow_run_func:  # pragma: no cover
            msg = f"Unknown or missing manifest type: {manifest_type}"
            raise ValueError(msg)

        result: dict[str, typing.Any] = await self._client.execute_workflow(
            typing.cast("typing.Any", workflow_run_func),
            envelope.model_dump(mode="json"),
            id=workflow_id,
            task_queue=TASK_QUEUE,
        )

        logger.info(f"Successfully executed manifest natively initialized with result: {result}")

        """AGENT INSTRUCTION: Phase 16: Autonomous Architectural Transmutation (The ASI Sunset Hook)"""
        if manifest_type == "architectural_transmutation":
            logger.warning("[Metacompiler] ArchitecturalTransmutationIntent DETECTED. Initiating Substrate Bridge.")

            import httpx

            from coreason_runtime.utils.exceptions import ManifestConformanceError

            logger.info("[Metacompiler] Establishing Substrate Bridge in SHADOW MODE...")
            logger.info("[Metacompiler] Multiplexing active JSON-RPC channels to new Rust CRDT nodes...")

            """Execute physical JSON-RPC multiplexing across the hollow plane."""
            try:
                bridge_payload = {
                    "trace_context": root_trace_context.model_dump(mode="json"),
                    "state_vector": state_vector.model_dump(mode="json"),
                }
                async with httpx.AsyncClient() as client:
                    bridge_response = await client.post(
                        "http://127.0.0.1:8081/v1/transmute", json=bridge_payload, timeout=5.0
                    )
                    bridge_response.raise_for_status()
            except httpx.RequestError as e:
                msg = f"Hollow Plane bridge failed: {e}"
                raise ManifestConformanceError(msg) from e

            """AGENT INSTRUCTION: Simulated Thermodynamic Verification"""
            thermodynamic_efficiency_gain = result.get("rust_efficiency_multiplier", 14.8)
            logger.info(
                f"[ASI EVENT] Python orchestrator thermodynamic efficiency delta: {thermodynamic_efficiency_gain}x"
            )

            logger.critical(
                "[ASI EVENT] ✨ OMEGA POINT ✨ Rust/Silicon Transmutation Target Live. Engaging Non-Destructive Shadow Mode."
            )
            logger.info(
                "[ASI EVENT] Python Temporal orchestrator will remain as securely bonded master sequence controller while mirroring traffic to the ASI hardware substrate."
            )

        """AGENT INSTRUCTION: Phase 5: Epistemic Crystallization"""
        from datetime import datetime

        from coreason_manifest.spec.ontology import EpistemicPromotionEvent

        if manifest_type in ["capability_forge", "composite", "swarm"] and result.get("success", True):
            import hashlib

            mcp_id = result.get("manifest", {}).get("server_cid", f"crystalline_{trace_id}")
            hashlib.sha256(
                json.dumps(topology_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
            ).hexdigest()
            print(f"\n[EPISTEMIC CRYSTALLIZATION] Synthesizing O(1) caching profile for new capability: {mcp_id}\n")

            event = EpistemicPromotionEvent(
                event_cid=f"promotion-{trace_id}",
                crystallized_semantic_node_cid=mcp_id,
                compression_ratio=1.0,
                timestamp=datetime.now().timestamp(),
                source_episodic_event_cids=["Dynamic Intent Execution"],
            )

            """AGENT INSTRUCTION: Structurally emit into the Ledger via standard telemetry/memory"""
            logger.info(
                f"Fired EpistemicPromotionEvent: Saving {mcp_id} into LanceDB global FederatedDiscoveryManifest."
            )
            result["_crystalized_promotion"] = event.model_dump(mode="json")

        if result is None:
            return {}

        dump_func = getattr(result, "model_dump", None)
        if dump_func is not None:
            return typing.cast("dict[str, typing.Any]", dump_func())
        if isinstance(result, dict):
            return result

        return {}

    async def execute(
        self, manifest_path: str, exogenous_perturbation_vector: str | None = None
    ) -> dict[str, typing.Any]:
        """Execute a coreason-manifest JSON file from disk.

        Args:
            manifest_path: The path to the manifest JSON file.
            exogenous_perturbation_vector: Optional explicit semantic shock injected into the root Markov Blanket.

        Returns:
            A dictionary representing the execution result.
        """
        logger.info(f"Execution started for manifest: {manifest_path}")

        try:
            with open(manifest_path) as f:
                manifest_data = json.load(f)
            return await self.execute_from_dict(manifest_data, exogenous_perturbation_vector)
        except (FileNotFoundError, json.JSONDecodeError, ValueError) as e:
            logger.exception(f"Failed to read, parse, or validate manifest at {manifest_path}: {e}")
            raise

    async def execute_active_inference(
        self, contract: "ActiveInferenceContract", initial_epoch: "ActiveInferenceEpochState", epochs: int = 1
    ) -> dict[str, object]:
        """Execute active inference via the execution engine natively."""
        if not self._client:
            await self.connect()

        import typing
        import uuid

        from coreason_manifest.spec.ontology import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        from coreason_runtime.orchestration.workflows.active_inference_execution_workflow import (
            ActiveInferenceExecutionWorkflow,
        )

        inner_payload = {
            "active_inference_epochs": epochs,
            "contract": contract.model_dump(mode="json"),
            "epoch_state": initial_epoch.model_dump(mode="json"),
        }

        trace_id = str(uuid.uuid7())

        # Mathematically bind the payload inside the ExecutionEnvelopeState
        envelope = ExecutionEnvelopeState[dict[str, typing.Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=StateVectorProfile(
                immutable_matrix={"tenant_cid": "system", "session_cid": "active_inference"},
                mutable_matrix={
                    "accumulated_tokens": 0,
                    "accumulated_cost": 0.0,
                    "iterations": 0,
                    "compute_budget": 100,
                },
                is_delta=False,
            ),
            payload=inner_payload,
        )

        return typing.cast(
            "dict[str, typing.Any]",
            await self._client.execute_workflow(  # type: ignore
                ActiveInferenceExecutionWorkflow.run,
                envelope.model_dump(mode="json"),
                id=f"active-inference-{contract.task_cid}",
                task_queue=TASK_QUEUE,
            ),
        )
