# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

"""Cross-Swarm Federation Handshake & Bilateral SLA Enforcement.

Implements the deterministic state machine for CrossSwarmHandshakeState,
negotiating FederatedBilateralSLAs between independent enterprise swarms.
Enforces LBAC classification clearance, geographic data residency, and
ESG carbon intensity limits before permitting cross-tenant graph execution.

State Machine:
    proposed → negotiating → aligned | rejected
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Literal

from coreason_runtime.utils.logger import logger

# ── Type Aliases ───────────────────────────────────────────────────────

HandshakePhase = Literal["proposed", "negotiating", "aligned", "rejected"]


# ── LBAC Classification Hierarchy ──────────────────────────────────────

CLASSIFICATION_HIERARCHY: dict[str, int] = {
    "UNCLASSIFIED": 0,
    "CUI": 1,
    "CONFIDENTIAL": 2,
    "SECRET": 3,
    "TOP_SECRET": 4,
}


async def negotiate_bilateral_sla(
    remote_beacon: dict[str, Any],
    local_sla: dict[str, Any],
) -> dict[str, Any]:
    """Negotiate a bilateral SLA with a remote swarm.

    Implements the deterministic finite state machine:
        proposed → negotiating → aligned | rejected

    Args:
        remote_beacon: The remote swarm's FederatedDiscoveryManifest/beacon.
        local_sla: The local FederatedBilateralSLA dict with keys:
            - max_permitted_classification: str
            - permitted_geographic_regions: list[str]
            - max_permitted_grid_carbon_intensity: float
            - min_ontological_overlap: int
            - max_latency_ms: float

    Returns:
        A CrossSwarmHandshakeState dict with the negotiation result.
    """
    handshake_id = f"hs-{uuid.uuid4().hex[:12]}"
    remote_swarm_id = remote_beacon.get("swarm_id", "unknown")

    state: dict[str, Any] = {
        "handshake_id": handshake_id,
        "local_swarm_id": local_sla.get("local_swarm_id", "self"),
        "remote_swarm_id": remote_swarm_id,
        "phase": "proposed",
        "started_at_ns": time.time_ns(),
        "rejection_reasons": [],
    }

    logger.info(f"[Federation] Handshake {handshake_id}: proposed → negotiating with {remote_swarm_id}")

    # ── Transition: proposed → negotiating ─────────────────────────
    state["phase"] = "negotiating"

    rejection_reasons: list[str] = []

    # ── Guard 1: LBAC Classification Clearance ─────────────────────
    local_max_class = local_sla.get("max_permitted_classification", "UNCLASSIFIED")
    remote_class = remote_beacon.get("max_permitted_classification", "UNCLASSIFIED")

    local_level = CLASSIFICATION_HIERARCHY.get(local_max_class, 0)
    remote_level = CLASSIFICATION_HIERARCHY.get(remote_class, 0)

    if remote_level > local_level:
        rejection_reasons.append(
            f"LBAC clearance exceeded: remote={remote_class}({remote_level}) "
            f"> local_max={local_max_class}({local_level})"
        )

    # ── Guard 2: Geographic Data Residency ─────────────────────────
    permitted_regions: list[str] = local_sla.get("permitted_geographic_regions", [])
    remote_region = remote_beacon.get("geographic_region", "")

    if permitted_regions and remote_region and remote_region not in permitted_regions:
        rejection_reasons.append(
            f"Geographic residency violation: remote_region='{remote_region}' not in permitted={permitted_regions}"
        )

    # ── Guard 3: ESG Carbon Intensity ──────────────────────────────
    max_carbon = float(local_sla.get("max_permitted_grid_carbon_intensity", float("inf")))
    remote_carbon = float(remote_beacon.get("grid_carbon_intensity", 0.0))

    if remote_carbon > max_carbon:
        rejection_reasons.append(
            f"Carbon intensity exceeded: remote={remote_carbon:.2f} > max_permitted={max_carbon:.2f}"
        )

    # ── Guard 4: Minimum Ontological Overlap ───────────────────────
    min_overlap = int(local_sla.get("min_ontological_overlap", 1))
    # The overlap_count should be computed by the gossip layer and passed through
    remote_overlap = int(remote_beacon.get("overlap_count", 0))
    if remote_overlap < min_overlap:
        rejection_reasons.append(f"Insufficient ontological overlap: {remote_overlap} < {min_overlap}")

    # ── Transition: negotiating → aligned | rejected ───────────────
    if rejection_reasons:
        state["phase"] = "rejected"
        state["rejection_reasons"] = rejection_reasons
        state["completed_at_ns"] = time.time_ns()
        logger.warning(f"[Federation] Handshake {handshake_id}: REJECTED. Reasons: {rejection_reasons}")
    else:
        state["phase"] = "aligned"
        state["completed_at_ns"] = time.time_ns()
        state["bilateral_sla"] = {
            "effective_classification": min(
                local_max_class, remote_class, key=lambda c: CLASSIFICATION_HIERARCHY.get(c, 0)
            ),
            "geographic_region": remote_region,
            "carbon_intensity": remote_carbon,
            "negotiated_at_ns": time.time_ns(),
        }
        logger.info(f"[Federation] Handshake {handshake_id}: ALIGNED with {remote_swarm_id}. SLA effective.")

    elapsed_ms = (state["completed_at_ns"] - state["started_at_ns"]) / 1_000_000
    state["elapsed_ms"] = round(elapsed_ms, 2)

    return state


def validate_handshake_phase_transition(
    current: HandshakePhase,
    target: HandshakePhase,
) -> bool:
    """Validate that a state machine transition is permitted.

    Legal transitions:
        proposed → negotiating
        negotiating → aligned
        negotiating → rejected
    """
    legal_transitions: dict[HandshakePhase, set[HandshakePhase]] = {
        "proposed": {"negotiating"},
        "negotiating": {"aligned", "rejected"},
        "aligned": set(),
        "rejected": set(),
    }
    return target in legal_transitions.get(current, set())
