# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

import asyncio
from typing import Any, TypedDict

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import DynamicRoutingManifest

    from coreason_runtime.utils.logger import logger


class DynamicSubgraphExecutionResultDict(TypedDict):
    """Execution result for a natively wrapped bounded semantic modality subgraph."""

    status: str
    node_executed: str
    budget_consumed: int


class DynamicRoutingManifestDict(TypedDict, total=False):
    """Payload Definition bounding modality subgraph routing schemas."""

    manifest_cid: str
    artifact_profile: dict[str, Any]
    active_subgraphs: dict[str, list[str]]
    bypassed_steps: list[dict[str, Any]]
    branch_budgets_magnitude: dict[str, int]


class DynamicRoutingResultDict(TypedDict):
    """Aggregate execution metadata tracking the master routing subgraph span."""

    status: str
    total_subgraphs_spawned: int
    manifest_cid: str


@workflow.defn(sandboxed=False)
class DynamicSubgraphExecutionWorkflow:
    """Mock child workflow representing the execution of a semantic modality subgraph.

    Accepts budget allocations and processes the specific topological nodes.
    """

    @workflow.run
    async def run(self, node_cid: str, budget: int) -> DynamicSubgraphExecutionResultDict:
        """Simulate subgraph execution bounded by thermodynamic and financial constraints."""
        logger.info(f"Executing subgraph bounds natively with budget {budget} for node {node_cid}")
        return {
            "status": "subgraph_completed",
            "node_executed": node_cid,
            "budget_consumed": budget,
        }


@workflow.defn(sandboxed=False)
class DynamicRoutingExecutionWorkflow:
    """Master dispatch gate ingesting DynamicRoutingManifest to orchestrate specific semantic topologies.

    Actively enforces bypass receipts, branch magnitude budgets, and alignment against
    the structural indexing properties present in the GlobalSemanticProfile.
    """

    @workflow.run
    async def run(self, manifest_payload: DynamicRoutingManifestDict) -> DynamicRoutingResultDict:
        """Executes the concurrent routing strategy dynamically allocating subgraphs.

        Reads detected_modalities from the global semantic profile.
        Iterates over active_subgraphs matching the underlying modalities.
        Bypasses any execution mapped in bypassed_steps to enforce conservation of custody.
        Spawns parallel asynchronous child workflows adhering to branch_budgets_magnitude.
        Returns the aggregated execution results from the child manifolds.
        """
        logger.info("Initializing Master Dispatch Routing limits and branching factors.")
        manifest = DynamicRoutingManifest.model_validate(manifest_payload)

        artifact_profile = manifest.artifact_profile
        detected_modalities = artifact_profile.detected_modalities

        bypass_set = {bypass.bypassed_node_cid for bypass in manifest.bypassed_steps}

        pending_subgraphs = []
        target_nodes = set()

        for modality, nodes in manifest.active_subgraphs.items():
            if modality in detected_modalities:
                for target_node in nodes:
                    if target_node not in bypass_set:
                        target_nodes.add(target_node)

        for node_cid in target_nodes:
            allocated_budget = manifest.branch_budgets_magnitude.get(node_cid, 0)
            logger.debug(f"Spawning target sequence {node_cid} with thermal boundaries bounded at {allocated_budget}")

            child_execution = workflow.execute_child_workflow(
                DynamicSubgraphExecutionWorkflow.run,
                args=[node_cid, allocated_budget],
                id=f"subgraph-{manifest.manifest_cid}-{node_cid}",
                parent_close_policy=workflow.ParentClosePolicy.TERMINATE,
            )
            pending_subgraphs.append(child_execution)

        execution_results = await asyncio.gather(*pending_subgraphs)
        logger.info(f"Dynamic Dispatch synchronized successfully resolving {len(execution_results)} topologies.")

        return {
            "status": "routing_completed",
            "total_subgraphs_spawned": len(execution_results),
            "manifest_cid": manifest.manifest_cid,
        }
