# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

from datetime import timedelta
from typing import Any

from temporalio import activity, workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import System2RemediationIntent

    from coreason_runtime.utils.exceptions import CoreasonRuntimeError


class SystemFaultError(CoreasonRuntimeError):
    """Raised when System 2 Remediation exhausts the bounded retry limit."""


@activity.defn
async def execute_node_regeneration_activity(
    _target_node_cid: str, _failing_pointers: list[str], ast_gradient: dict[str, Any] | None
) -> bool:
    """Mock activity simulating an actual LLM regenerating the isolated subgraph.

    Accepts the failing JSON pointers and the structural loss vector defined by
    the ast_gradient. In tests, we will mock this to fail persistently unless bypassed.
    """
    return not (ast_gradient and ast_gradient.get("actual_type_geometry", "") == "none")


@workflow.defn
class System2RemediationWorkflow:
    """Orchestrates recursive backtracking search to repair an isolated structural subgraph.

    Catches a System2RemediationIntent and attempts to correct execution collapses by
    identifying exact RFC 6902 JSON pointers.
    """

    @workflow.run
    async def run(self, remediation_payload: dict[str, Any]) -> dict[str, Any]:
        """Runs the remediation loop, parsing violation receipts and prompting regeneration.

        Extracts the failing_pointer from the parsed ManifestViolationReceipt elements.
        Triggers explicit isolated generation targeting target_node_cid using the ast_gradient.
        Bounded to exactly three retry loops maximum to prevent OOM/runaway iteration.
        Throws a SystemFaultEvent if topological bounds are repeatedly violated.
        """

        from temporalio.exceptions import ApplicationError

        try:
            intent = System2RemediationIntent.model_validate(remediation_payload, strict=False)
        except Exception as e:
            raise ApplicationError(str(e), type="ManifestConformanceError", non_retryable=True) from e

        failing_pointers = [receipt.failing_pointer for receipt in intent.violation_receipts]
        ast_gradient_payload = intent.ast_gradient.model_dump() if intent.ast_gradient else None

        max_retries = 3
        current_attempt = 0

        while current_attempt < max_retries:
            current_attempt += 1

            success = await workflow.execute_activity(
                execute_node_regeneration_activity,
                args=[intent.target_node_cid, failing_pointers, ast_gradient_payload],
                start_to_close_timeout=timedelta(minutes=1),
            )

            if success:
                return {"status": "remediation_successful", "fault_cid": intent.fault_cid, "attempts": current_attempt}

        msg = f"VRAM bounds exceeded. Remediation failed for {intent.target_node_cid} after {max_retries} attempts."
        raise ApplicationError(msg, type="SystemFaultError", non_retryable=True)
