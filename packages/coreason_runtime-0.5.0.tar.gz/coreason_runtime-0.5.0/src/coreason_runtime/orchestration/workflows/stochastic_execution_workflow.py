# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import random
from datetime import timedelta
from typing import Any

from temporalio import activity, workflow


class MarkovBlanketEnforcer:
    """Implement strict epistemic Markov Blanket encapsulation natively."""

    @staticmethod
    def enforce_sensory_edge(caller_cid: str, valid_sensory_edges: list[str]) -> bool:
        """Verify the caller crosses the Markov blanket via permitted sensory boundaries.

        Args:
            caller_cid: Identity of the external invoking node or user.
            valid_sensory_edges: List of permitted boundary edges securely bounding access.

        Raises:
            ManifestConformanceError: If mutation implies an illegal internal state breach.

        Returns:
            True if the caller successfully passes the sensory boundary.
        """
        if caller_cid not in valid_sensory_edges:
            from coreason_runtime.utils.exceptions import ManifestConformanceError

            msg = f"Markov Blanket Subversion: Caller {caller_cid} bypassed permitted sensory logic bounds."
            raise ManifestConformanceError(msg)
        return True


@activity.defn(name="EvaluateTransitionProbabilityActivity")
async def evaluate_transition_probability_activity(manifest_payload: dict[str, Any]) -> str:
    """Securely and natively resolve the target execution branch for a stochastic topology.

    Args:
        manifest_payload: The dictionary representation of a StochasticTopologyManifest.

    Returns:
        The evaluated and chosen string branch CID.
    """
    from coreason_manifest.spec.ontology import StochasticTopologyManifest
    from temporalio.exceptions import ApplicationError

    from coreason_runtime.utils.exceptions import ManifestConformanceError

    try:
        manifest = StochasticTopologyManifest.model_validate(manifest_payload, strict=False)

        # We must have superposition mathematically defined
        if not manifest.superposition or not manifest.superposition.competing_manifolds:
            msg = "No valid probabilities empirically mapped in superposition."
            raise ManifestConformanceError(msg)

        probabilities = manifest.superposition.competing_manifolds

        total = sum(probabilities.values())
        if total <= 0:
            msg = f"Isomorphic probability mass {total} is not strictly positive."
            raise ManifestConformanceError(msg)

        r = random.SystemRandom().uniform(0, total)
        cumulative = 0.0
        for branch_id, prob in probabilities.items():
            cumulative += prob
            if r <= cumulative:
                return branch_id

        # Fallback theoretically unreachable if stochastic math evaluates safely
        return list(probabilities.keys())[-1]
    except Exception as e:
        raise ApplicationError(f"Activity Failed: {e!s}", type="ActivityError", non_retryable=True) from e


@workflow.defn(name="StochasticExecutionWorkflow", sandboxed=False)
class StochasticExecutionWorkflow:
    """Temporal workflow encapsulating probabilistically routed structural graphs bounded tightly by Markov blankets."""

    @workflow.run
    async def run(
        self, manifest_payload: dict[str, Any], caller_cid: str, valid_sensory_edges: list[str]
    ) -> dict[str, Any]:
        """Execute the structurally bound stochastic graph cleanly limiting out-of-band state mutation securely.

        Args:
            manifest_payload: The StochasticTopologyManifest describing nodes and probability matrix.
            caller_cid: The identity mapping of the external invoker.
            valid_sensory_edges: List of permitted strings bounding external manipulation.

        Returns:
            A strictly formatted dictionary confirming route traversal logic dynamically.
        """
        # 1. Reject out-of-bounds mutation strictly enforcing isolation natively
        from temporalio.exceptions import ApplicationError

        from coreason_runtime.utils.exceptions import ManifestConformanceError

        try:
            MarkovBlanketEnforcer.enforce_sensory_edge(caller_cid, valid_sensory_edges)
        except ManifestConformanceError as e:
            raise ApplicationError(str(e), type="ManifestConformanceError", non_retryable=True) from e

        # 2. Evaluate stochastic transition probabilities mapping natively to Temporal Side-Effects
        target_branch = await workflow.execute_activity(
            evaluate_transition_probability_activity,
            manifest_payload,
            start_to_close_timeout=timedelta(seconds=10),
        )

        return {"status": "stochastic_execution_completed", "traversed_branch": target_branch}
