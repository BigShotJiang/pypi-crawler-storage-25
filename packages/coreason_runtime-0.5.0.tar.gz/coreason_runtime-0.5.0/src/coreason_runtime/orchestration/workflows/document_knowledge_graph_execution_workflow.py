# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from datetime import timedelta
from typing import Any

from temporalio import activity, workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState

from .base_topology_workflow import BaseTopologyWorkflow


@activity.defn
def extract_causal_edges_activity(payload: dict[str, Any]) -> dict[str, Any]:
    """Deterministically extracts causal edges and computes isomorphism hashes."""
    import hashlib
    import json

    edges = payload.get("edges", [])

    causal_edges = []
    isomorphism_hashes = []

    for edge in edges:
        if isinstance(edge, dict):
            source = edge.get("source")
            target = edge.get("target")
            relation = edge.get("relation", "Predicate")
        else:
            source = edge[0]
            relation = edge[1] if len(edge) > 2 else "Predicate"
            target = edge[-1]

        edge_repr = {"subject": source, "predicate": relation, "object": target}
        causal_edges.append(edge_repr)

        edge_hash = hashlib.sha256(json.dumps(edge_repr, sort_keys=True).encode("utf-8")).hexdigest()
        isomorphism_hashes.append(edge_hash)

    return {"causal_edges": causal_edges, "isomorphism_hashes": isomorphism_hashes}


@workflow.defn
class DocumentKnowledgeGraphExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents a Document Knowledge Graph Topology manifest."""

    def __init__(self) -> None:
        """Initialize DocumentKnowledgeGraphExecutionWorkflow."""
        super().__init__()  # pragma: no cover

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Document Knowledge Graph workflow.

        Args:
            payload: The ExecutionEnvelopeState containing a DocumentKnowledgeGraphManifest.

        Returns:
            A dictionary containing the extracted causal edges and isomorphism hashes.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting DocumentKnowledgeGraphExecutionWorkflow")

        extraction_result = await workflow.execute_local_activity(
            extract_causal_edges_activity, manifest_payload, schedule_to_close_timeout=timedelta(seconds=120)
        )

        result = {
            "success": True,
            "causal_edges": extraction_result["causal_edges"],
            "isomorphism_hashes": extraction_result["isomorphism_hashes"],
            "manifest": {"server_cid": f"knowledge_graph_{workflow.info().workflow_id}"},
        }

        workflow.logger.info("Completed DocumentKnowledgeGraphExecutionWorkflow")

        return result
