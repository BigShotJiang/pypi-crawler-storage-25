# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Active inference execution logic.

AGENT INSTRUCTION: This workflow loops to update beliefs and minimize variational free energy.
"""

from datetime import timedelta
from typing import Any, TypedDict

from loguru import logger
from temporalio import activity, workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import EpistemicRewardGradientPolicy, ExecutionNodeReceipt

    from coreason_runtime.utils.exceptions import ManifestConformanceError


class EpochStateDict(TypedDict, total=False):
    belief_matrix: list[float]


class ContractDict(TypedDict, total=False):
    threshold: float


class ActiveInferencePayload(TypedDict, total=False):
    epoch_state: EpochStateDict
    contract: ContractDict
    active_inference_epochs: int
    free_energy: float
    epistemic_reward_policy: Any
    prior_event_hash: str


class SurpriseResult(TypedDict, total=False):
    free_energy: float
    novel_surprise_factor: float


class BeliefUpdateResult(TypedDict, total=False):
    belief_updated: bool
    variational_free_energy_reduction: float


class WorkflowResult(TypedDict, total=False):
    success: bool
    final_free_energy: float
    epochs_run: int
    rehydrated_hash: str


@activity.defn
async def evaluate_surprise_compute_activity(payload: ActiveInferencePayload) -> SurpriseResult:
    """Evaluate variational free energy delta against expected state in memory.

    AGENT INSTRUCTION: Interface with lancedb/latent logic.
    """
    logger.info("Evaluating active inference surprise compute phase")
    if not payload.get("epoch_state"):
        msg = "Invalid ActiveInferenceEpochState: Missing explicit payload boundaries."
        raise ManifestConformanceError(msg)

    return SurpriseResult(free_energy=0.5, novel_surprise_factor=0.8)


@activity.defn
async def update_latent_belief_activity(payload: ActiveInferencePayload) -> BeliefUpdateResult:
    """Update beliefs internally minimizing variational free energy."""
    logger.info("Executing active inference latent belief update loop")
    if not payload.get("contract"):
        msg = "Invalid ActiveInferenceContract: Missing explicit payload boundaries."
        raise ManifestConformanceError(msg)

    val = payload.get("free_energy")
    reduction = float(val) if val is not None else 0.0
    return BeliefUpdateResult(belief_updated=True, variational_free_energy_reduction=reduction)


@workflow.defn
class ActiveInferenceExecutionWorkflow:
    """Continuously updating engine optimizing target epistemic topologies."""

    def __init__(self) -> None:
        """Initialize ActiveInferenceExecutionWorkflow."""

    @workflow.run
    async def run(self, payload: ActiveInferencePayload) -> WorkflowResult:
        """Execute active inference looping mechanism.

        Args:
            payload: Payload dict containing the epoch_state and contract configurations.

        Returns:
            Dictionary representing convergence and final variation free energy state.
        """
        epochs_val = payload.get("active_inference_epochs")
        epochs = int(epochs_val) if epochs_val is not None else 1

        last_free_energy = 1.0

        for _ in range(epochs):
            logger.info("Transition: executing surprise compute loop")
            eval_result = await workflow.execute_activity(
                evaluate_surprise_compute_activity,
                payload,
                schedule_to_close_timeout=timedelta(seconds=60),
            )

            last_free_energy = eval_result["free_energy"]

            if "epistemic_reward_policy" in payload:
                policy = EpistemicRewardGradientPolicy.model_validate(payload["epistemic_reward_policy"])
                if (
                    hasattr(policy, "minimum_gradient_improvement")
                    and getattr(policy, "minimum_gradient_improvement", 0.0) > 0
                ):
                    logger.info("Evaluating MCTS topological pruning constraints.")
                    if last_free_energy > getattr(policy, "maximum_free_energy_tolerance", 1.0):
                        logger.warning(
                            f"Branch Pruned: Free energy {last_free_energy} exceeds "
                            f"epistemic gradient tolerance {getattr(policy, 'maximum_free_energy_tolerance', 1.0)}"
                        )
                        break

            update_payload = ActiveInferencePayload(**payload)
            update_payload["free_energy"] = last_free_energy
            update_payload["active_inference_epochs"] = epochs - 1

            logger.info("Transition: updating latent beliefs")
            await workflow.execute_activity(
                update_latent_belief_activity,
                update_payload,
                schedule_to_close_timeout=timedelta(seconds=60),
            )

            ExecutionNodeReceipt(
                request_cid=workflow.info().run_id,
                inputs={"epoch_state": payload.get("epoch_state", {})},  # type: ignore[dict-item]
                outputs={"free_energy": last_free_energy},
            )

            # The Temporal Axiom: O(1) Rehydration via ContinueAsNew
            if epochs > 1 and workflow.info().get_current_history_length() > 50:
                import hashlib
                import json

                # We inject the cryptographically secure SHA-256 hash of the serialized snapshot
                serialized_snapshot = json.dumps(update_payload, sort_keys=True)
                prior_event_hash = hashlib.sha256(serialized_snapshot.encode("utf-8")).hexdigest()

                logger.info(f"O(1) Rehydration required. Merkle-DAG injected prior_event_hash: {prior_event_hash}")

                # Emulate the respawn via ContinueAsNew
                update_payload["prior_event_hash"] = prior_event_hash
                workflow.continue_as_new(update_payload)
                return WorkflowResult(success=True, final_free_energy=last_free_energy, epochs_run=1)

        return WorkflowResult(
            success=True,
            final_free_energy=last_free_energy,
            epochs_run=epochs,
            rehydrated_hash=str(payload.get("prior_event_hash", "")),
        )
