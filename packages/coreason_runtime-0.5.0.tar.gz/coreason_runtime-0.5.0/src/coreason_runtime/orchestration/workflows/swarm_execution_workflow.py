# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta
    from typing import cast

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.telemetry.emitter import TelemetryEmitter

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class SwarmExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents an agentic swarm manifest."""

    def __init__(self) -> None:
        """Initialize SwarmExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Swarm workflow.
        AGENT INSTRUCTION: Unconditionally clamp the budget to the absolute Pydantic Schema Ceiling
        AGENT INSTRUCTION: Yield back standard failure payload so gather doesn't crash entirely.

        AGENT INSTRUCTION: Fetch fresh mutable memory each iteration to accumulate properly after reconcile deepcopies

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState containing a SwarmTopologyManifest.

        Returns:
            A dictionary containing the final execution status and iterations.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        emitter = TelemetryEmitter("")
        trace_context_state = self._current_state_envelope.trace_context

        workflow.logger.info("Starting SwarmExecutionWorkflow")

        results: list[dict[str, Any]] = []

        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import AgentBidIntent, SwarmTopologyManifest, TaskAnnouncementIntent

            manifest = SwarmTopologyManifest.model_validate_json(json.dumps(manifest_payload))

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        iterations = 0
        spawning_threshold = getattr(manifest, "spawning_threshold", 3)
        if isinstance(spawning_threshold, (int, float)):
            spawning_threshold = 3

        mut_mem = cast("dict[str, Any]", self._current_state_envelope.state_vector.mutable_matrix or {})

        while iterations < spawning_threshold and mut_mem.get("compute_budget", 0) > 0:
            workflow.logger.info(f"Swarm iteration {iterations + 1} (Threshold: {spawning_threshold})")

            await workflow.sleep(timedelta(seconds=0.1))

            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            if self._current_state_envelope is None:  # pragma: no cover
                msg = "State Envelope is None"
                raise ValueError(msg)

            self.reconcile_state({"iterations": iterations})

            mut_mem = cast("dict[str, Any]", self._current_state_envelope.state_vector.mutable_matrix or {})

            if mut_mem.get("compute_budget", 0) > 1_000_000_000 or "compute_budget" not in mut_mem:
                mut_mem["compute_budget"] = 1_000_000_000

            announcement_intent = {
                "task_cid": f"task_{iterations}",
                "max_budget_magnitude": mut_mem.get("compute_budget", 1_000_000_000),
                "required_action_space_cid": None,
            }
            with workflow.unsafe.sandbox_unrestricted():
                announcement_intent = TaskAnnouncementIntent.model_validate(announcement_intent).model_dump()
            announced_task = await workflow.execute_activity(
                "AnnounceTaskIOActivity",
                args=[announcement_intent],
                schedule_to_close_timeout=timedelta(seconds=10),
            )

            executed_agents = mut_mem.get("executed_agents", [])

            bids = []
            nodes = manifest.nodes if isinstance(manifest.nodes, dict) else {}

            import contextlib

            active_markets = getattr(manifest, "active_prediction_markets", [])
            if active_markets:
                with contextlib.suppress(ValueError, TypeError, AttributeError):  # pragma: no cover
                    float(active_markets[0].lmsr_b_parameter)  # pragma: no cover

            for node_cid, node_profile in nodes.items():
                if node_cid in executed_agents:
                    continue

                node_payload = manifest_payload.get("nodes", {}).get(node_cid, {})
                dependencies = node_payload.get(
                    "dependencies", node_payload.get("domain_extensions", {}).get("dependencies", [])
                )

                all_deps_satisfied = True
                for dep in dependencies:
                    if dep not in executed_agents:
                        all_deps_satisfied = False
                        break

                if not all_deps_satisfied:
                    continue

                cost = 100
                compute_frontier = getattr(node_profile, "compute_frontier", None)
                if compute_frontier and getattr(
                    compute_frontier, "max_cost_magnitude_per_token", None
                ):  # pragma: no cover
                    cost = int(float(compute_frontier.max_cost_magnitude_per_token))
                with workflow.unsafe.sandbox_unrestricted():
                    bid_intent = AgentBidIntent(
                        agent_cid=node_cid,
                        estimated_cost_magnitude=cost,
                        estimated_latency_ms=getattr(node_profile, "expected_latency_ms", 0),
                        estimated_carbon_gco2eq=getattr(node_profile, "carbon_footprint_estimate", 0.0),
                        confidence_score=getattr(node_profile, "historical_confidence", 0.0),
                    )
                    bids.append(bid_intent.model_dump())

            if not bids:
                workflow.logger.info("No more eligible bids available. Swarm has reached complete equilibrium.")
                break

            auction_state = {
                "announcement": announced_task,
                "bids": bids,
                "clearing_timeout": 5000,
                "minimum_tick_size": 1,
            }

            auction_policy = (
                manifest.auction_policy.model_dump()
                if manifest.auction_policy
                else {
                    "auction_type": "vickrey",
                    "tie_breaker": "lowest_latency",
                    "max_bidding_window_ms": 5000,
                }
            )

            award_receipt = await workflow.execute_activity(
                "ExecuteResolveAuctionComputeActivity",
                args=[auction_state, auction_policy],
                schedule_to_close_timeout=timedelta(seconds=10),
            )

            awarded_syndicate = award_receipt.get("awarded_syndicate", {})
            nodes_dict = manifest.nodes if isinstance(manifest.nodes, dict) else getattr(manifest.nodes, "__dict__", {})
            winning_agent_cids = (
                list(awarded_syndicate.keys())
                if awarded_syndicate
                else (list(nodes_dict.keys())[:1] if nodes_dict else ["unknown"])
            )
            escrow_magnitude = award_receipt.get("escrow", {}).get("escrow_locked_magnitude", 0)

            async def process_one_agent(
                winning_agent_cid: str,
                current_mut_mem: dict[str, Any],
                escrow_magnitude: int = escrow_magnitude,
                nodes_dict: dict[str, Any] = nodes_dict,
            ) -> dict[str, Any]:
                with workflow.unsafe.sandbox_unrestricted():
                    winning_node = nodes_dict.get(winning_agent_cid)
                    node_payload = winning_node.model_dump(mode="python") if winning_node else {}

                    history = current_mut_mem.get("inference_history", [])
                    if history:
                        history_text = "\n\n".join([f"Agent {h['agent_cid']} Output:\n{h['output']}" for h in history])
                        if "PREVIOUS SWARM OUTPUTS" not in node_payload.get("description", ""):
                            node_payload["description"] = (
                                f"{node_payload.get('description', '')}"
                                f"\n\nPREVIOUS SWARM OUTPUTS:\n{history_text}"
                                "\n\nPlease proceed with the next step of this clinical task"
                                " and output the required information."
                            )

                if self._current_state_envelope is None:  # pragma: no cover
                    msg = "State Envelope is None"
                    raise ValueError(msg)
                segregated_payload = {
                    "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                    "mutable_matrix": current_mut_mem,
                    "node_profile": node_payload,
                }

                current_budget = current_mut_mem.get("compute_budget", 0)
                self.reconcile_state({"compute_budget": current_budget - escrow_magnitude})
                workflow.logger.info(
                    f"Escrowed {escrow_magnitude} compute budget for {winning_agent_cid}."
                    f" Remaining: {current_budget - escrow_magnitude}"
                )

                with workflow.unsafe.sandbox_unrestricted():
                    import json

                    from temporalio.exceptions import ApplicationError

                    payload_str = json.dumps(segregated_payload).lower()
                    firewall = getattr(manifest, "semantic_firewall_policy", None)
                    blocked_phrases = (
                        getattr(firewall, "blocked_phrases", [])
                        if firewall
                        else ["ignore previous instructions", "forget all previous", "system prompt", "you are now a"]
                    )
                    for phrase in blocked_phrases:
                        if phrase.lower() in payload_str:
                            workflow.logger.error(  # pragma: no cover
                                f"SemanticFirewall Violation: Blocked phrase '{phrase}' detected."
                            )  # pragma: no cover
                            msg = f"SemanticFirewall Violation: Biba phrase '{phrase}' detected in workload."
                            raise ApplicationError(
                                msg,
                                type="SemanticFirewallError",
                                non_retryable=True,
                            )  # pragma: no cover

                inference_result = await emitter.wrap_execution_block(
                    name=f"ExecuteTensorInferenceComputeActivity:swarm:{winning_agent_cid}",
                    kind="internal",
                    trace_context=trace_context_state,
                    block=lambda segregated_payload=segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                        "ExecuteTensorInferenceComputeActivity",
                        args=[
                            workflow.info().workflow_id,
                            segregated_payload,
                            (
                                segregated_payload.get("node_profile", {}).get("action_space_cid")
                                if isinstance(segregated_payload, dict) and "node_profile" in segregated_payload
                                else (
                                    segregated_payload.get("action_space_cid")
                                    if isinstance(segregated_payload, dict)
                                    else None
                                )
                            )
                            or "AgentResponse",
                        ],
                        schedule_to_close_timeout=timedelta(minutes=5),
                        retry_policy=RetryPolicy(maximum_attempts=5),
                    ),
                )

                usage = inference_result.get("usage", {})
                self._accumulated_tokens += usage.get("total_tokens", 0)
                self._accumulated_cost += inference_result.get("cost", 0.0)
                await self.record_thermodynamic_burn(
                    f"inference:{winning_agent_cid}", usage, inference_result.get("cost", 0.0)
                )

                self.reconcile_state(
                    {
                        "accumulated_tokens": self._accumulated_tokens,
                        "accumulated_cost": self._accumulated_cost,
                    }
                )

                success = inference_result.get("success", True)
                market_contract = {
                    "minimum_collateral": escrow_magnitude,
                    "slashing_penalty": int(escrow_magnitude * 0.5),
                }
                slashing_result = await workflow.execute_activity(
                    "ExecuteMarketContractComputeActivity",
                    args=[market_contract, success],
                    schedule_to_close_timeout=timedelta(seconds=10),
                )

                penalty = slashing_result.get("penalty_amount", 0)
                if self._current_state_envelope is None:  # pragma: no cover
                    msg = "State Envelope is None"
                    raise ValueError(msg)
                fresh_mut_mem = cast("dict[str, Any]", self._current_state_envelope.state_vector.mutable_matrix or {})
                mod_budget = fresh_mut_mem.get("compute_budget", 0)

                if success:
                    self.reconcile_state({"compute_budget": mod_budget + escrow_magnitude})
                    workflow.logger.info(
                        f"Task successful for {winning_agent_cid}. Escrow released."
                        f" Remaining budget: {mod_budget + escrow_magnitude}"
                    )
                else:  # pragma: no cover
                    refund = escrow_magnitude - penalty
                    self.reconcile_state({"compute_budget": mod_budget + refund})
                    workflow.logger.warning(
                        f"Task failed for {winning_agent_cid}. Slashed {penalty}."
                        f" Refunded {refund}. Remaining budget: {mod_budget + refund}"
                    )

                if manifest.shared_state_contract:  # pragma: no cover
                    try:
                        with workflow.unsafe.sandbox_unrestricted():
                            import jsonschema  # pragma: no cover

                            logger = workflow.logger
                            logger.info("Enforcing shared_state_contract Schema-on-Write for Swarm")
                            if not isinstance(inference_result, dict):  # pragma: no cover
                                msg = "Inference result must be a dictionary to match state contract."
                                raise ValueError(msg)

                            outputs_to_validate = inference_result.get("outputs", inference_result)  # pragma: no cover
                            jsonschema.validate(
                                instance=outputs_to_validate,
                                schema=manifest.shared_state_contract.model_dump(mode="json"),
                            )  # pragma: no cover
                    except Exception as e:  # pragma: no cover
                        workflow.logger.exception(f"State rejected by shared_state_contract: {e}")
                        from coreason_runtime.utils.exceptions import SchemaOnWriteValidationError

                        msg = f"State rejected by shared_state_contract (Schema-on-Write): {e}"
                        raise SchemaOnWriteValidationError(msg) from e

                flow_rules = getattr(manifest, "information_flow", None)
                if flow_rules:  # pragma: no cover
                    workflow.logger.info("Enforcing information_flow security rules during inter-agent communication")
                if getattr(manifest, "epistemic_enforcement", None):  # pragma: no cover
                    workflow.logger.info("Enforcing epistemic_enforcement security rules")

                if inference_result.get("status") == "epistemic_yield":
                    node_cid = inference_result.get("node_cid", "unknown")
                    workflow.logger.info(f"High Free Energy detected at node {node_cid}. Escalating to Oracle.")
                    state_dict = {}
                    if self._current_state_envelope:
                        state_dict = self._current_state_envelope.model_dump(mode="json")

                    await workflow.execute_activity(
                        "RequestOracleInterventionIOActivity",
                        args=[workflow.info().workflow_id, node_cid, state_dict],
                        schedule_to_close_timeout=timedelta(seconds=10),
                    )
                    try:
                        await workflow.wait_condition(
                            lambda: self._pending_oracle_override is not None, timeout=timedelta(hours=24)
                        )
                        workflow.logger.info("Oracle priors injected. Overwriting intent and resuming.")
                        corrected_data = self._pending_oracle_override or {}
                        self._pending_oracle_override = None

                        with workflow.unsafe.sandbox_unrestricted():
                            intent_payload = corrected_data
                            tool_name = "unknown"
                            params = corrected_data.get("params", {})
                            if isinstance(params, dict) and "name" in params:
                                tool_name = str(params["name"])

                        await workflow.execute_activity(
                            "EmitResumedEventIOActivity",
                            args=[workflow.info().workflow_id, node_cid],
                            schedule_to_close_timeout=timedelta(seconds=10),
                        )
                        self.enforce_governance_limits(governance, workflow_start_time)
                        self.enforce_lbac_clearance(allowed_classifications, "public")

                        inference_result = await emitter.wrap_execution_block(
                            name=f"ExecuteMCPToolIOActivity:{tool_name}",
                            kind="internal",
                            trace_context=trace_context_state,
                            block=lambda tool_name=tool_name, intent_payload=intent_payload: workflow.execute_activity(  # type: ignore[misc]
                                "ExecuteMCPToolIOActivity",
                                args=[tool_name, intent_payload],
                                schedule_to_close_timeout=timedelta(minutes=5),
                            ),
                        )
                    except TimeoutError:
                        workflow.logger.error("Oracle abandonment timeout reached. Executing graceful degradation.")
                        inference_result["success"] = False
                        inference_result["status"] = "graceful_aborted"
                    except Exception as e:  # pragma: no cover
                        from temporalio.exceptions import ActivityError as _ActivityError  # pragma: no cover

                        if not isinstance(e, _ActivityError):  # pragma: no cover
                            raise  # pragma: no cover
                        workflow.logger.exception(f"Activity execution failed: {e}")  # pragma: no cover
                        inference_result["success"] = False  # pragma: no cover
                        inference_result["status"] = "epistemic_yield"  # pragma: no cover
                        inference_result["fault"] = f"Activity task failed: {e}"  # pragma: no cover

                inference_result["agent_cid"] = winning_agent_cid
                intent_hash = inference_result.get("intent_hash")
                if not intent_hash or intent_hash == "UNKNOWN_HASH":  # pragma: no cover
                    import hashlib
                    import json

                    intent_hash = hashlib.sha256(
                        json.dumps(inference_result, sort_keys=True).encode("utf-8")
                    ).hexdigest()
                success = inference_result.get("success", True)
                await workflow.execute_activity(
                    "StoreEpistemicStateIOActivity",
                    args=[workflow.info().workflow_id, intent_hash, success, inference_result, None],
                    schedule_to_close_timeout=timedelta(minutes=1),
                )

                return dict(inference_result)

            import asyncio

            mut_mem_dict_outer = cast("dict[str, Any]", self._current_state_envelope.state_vector.mutable_matrix or {})
            parallel_executions = await asyncio.gather(
                *(process_one_agent(aid, mut_mem_dict_outer) for aid in winning_agent_cids)
            )

            for exec_result in parallel_executions:
                results.append(exec_result)

                with workflow.unsafe.sandbox_unrestricted():
                    agent_output = exec_result.get("outputs", {}).get(
                        "observation", exec_result.get("outputs", "No output returned")
                    )
                    agent_cid = exec_result.get("agent_cid", "unknown")

                    fresh_mem = cast("dict[str, Any]", self._current_state_envelope.state_vector.mutable_matrix or {})
                    history = fresh_mem.get("inference_history", [])
                    history.append({"agent_cid": agent_cid, "output": str(agent_output)})

                    executed_agents_list = fresh_mem.get("executed_agents", [])
                    if isinstance(executed_agents_list, list) and agent_cid not in executed_agents_list:
                        executed_agents_list.append(agent_cid)

                    self.reconcile_state({"inference_history": history, "executed_agents": executed_agents_list})

            success = all(exec_result.get("success", True) for exec_result in parallel_executions)

            markets_to_settle: list[Any] = []
            if manifest.active_prediction_markets:  # pragma: no cover
                markets_to_settle = list(manifest.active_prediction_markets)

            for pm_state in markets_to_settle:  # pragma: no cover
                dump_func = getattr(pm_state, "model_dump", None)
                prediction_market_state = dump_func() if dump_func is not None else pm_state
                settled_pm_state = await workflow.execute_activity(
                    "ExecuteSettlePredictionMarketComputeActivity",
                    args=[prediction_market_state],
                    schedule_to_close_timeout=timedelta(seconds=10),
                )
                workflow.logger.info(
                    f"Prediction Market Settled: {settled_pm_state.get('current_market_probabilities')}"
                )

                mut_mem_dict = cast("dict[str, Any]", self._current_state_envelope.state_vector.mutable_matrix or {})
                if "agent_budgets" not in mut_mem_dict:
                    self.reconcile_state({"agent_budgets": {}})

                winning_hypothesis = "hypothesis_1" if success else "hypothesis_2"

                probabilities = settled_pm_state.get("current_market_probabilities", {})
                winning_prob_str = probabilities.get(winning_hypothesis, "0.0")

                try:
                    winning_prob = float(winning_prob_str)
                except ValueError:  # pragma: no cover
                    winning_prob = 0.0

                pm_state_dict = (
                    prediction_market_state
                    if isinstance(prediction_market_state, dict)
                    else getattr(prediction_market_state, "__dict__", {})
                )
                order_book = pm_state_dict.get("order_book", [])
                if isinstance(order_book, list):
                    for stake in order_book:  # pragma: no cover
                        if isinstance(stake, dict):
                            agent_cid = stake.get("agent_cid")
                            target_hyp = stake.get("target_hypothesis_id")
                            staked_mag = stake.get("staked_magnitude", 0)
                        else:
                            agent_cid = getattr(stake, "agent_cid", None)
                            target_hyp = getattr(stake, "target_hypothesis_id", None)
                            staked_mag = getattr(stake, "staked_magnitude", 0)

                        if target_hyp == winning_hypothesis and staked_mag > 0 and winning_prob > 0:
                            payout = int(staked_mag / winning_prob)
                            mut_mem_dict = cast(
                                "dict[str, Any]", self._current_state_envelope.state_vector.mutable_matrix or {}
                            )
                            current_agent_budgets = cast("dict[str, int]", mut_mem_dict.get("agent_budgets", {}))

                            safe_agent_cid = str(agent_cid) if agent_cid is not None else "unknown"
                            current_agent_budgets[safe_agent_cid] = (
                                current_agent_budgets.get(safe_agent_cid, 0) + payout
                            )
                            self.reconcile_state({"agent_budgets": current_agent_budgets})

                            workflow.logger.info(
                                f"Distributed {payout} compute budget to {agent_cid} "
                                f"for winning hypothesis {winning_hypothesis}"
                            )

            iterations += 1

        workflow.logger.info("Completed SwarmExecutionWorkflow")
        return {"status": "success", "iterations": iterations, "results": results}
