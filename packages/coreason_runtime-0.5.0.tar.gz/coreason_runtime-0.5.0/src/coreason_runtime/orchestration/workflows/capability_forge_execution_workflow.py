# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.telemetry.emitter import TelemetryEmitter

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class CapabilityForgeExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents the Zero-to-One capability generation loop."""

    def __init__(self) -> None:  # pragma: no cover
        """Initialize CapabilityForgeExecutionWorkflow."""
        super().__init__()
        self._human_approval_attestation: str | None = None

    @workflow.signal(name="approve_forge")
    def approve_forge(self, attestation: str) -> None:  # pragma: no cover
        """Signal handler to receive human approval attestation string."""
        self._human_approval_attestation = attestation  # pragma: no cover

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:  # pragma: no cover
        """Run the Capability Forge workflow.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing the CapabilityForgeTopologyManifest (or its unrolled base).

        Returns:
            A dictionary containing the final execution status and results.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        emitter = TelemetryEmitter("")
        trace_context_state = self._current_state_envelope.trace_context

        workflow.logger.info("Starting CapabilityForgeExecutionWorkflow")

        results: list[dict[str, Any]] = []

        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import CapabilityForgeTopologyManifest

            forge_macro = CapabilityForgeTopologyManifest.model_validate_json(json.dumps(manifest_payload))
            manifest = forge_macro.compile_to_base_topology()

            # Rehydrate the LLM-generated node intelligence that was wiped by the base compiler
            for n_id in manifest.nodes:
                if n_id in forge_macro.nodes:
                    manifest.nodes[n_id] = forge_macro.nodes[n_id]

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        generator_node = None
        verifier_node = None
        fuzzer_node = None
        human_node = None

        for node_cid, node_profile in manifest.nodes.items():
            if "generator" in node_cid or getattr(node_profile, "type", "") == "generator":
                generator_node = node_profile
                gen_id = node_cid
            elif "verifier" in node_cid or getattr(node_profile, "type", "") == "formal_verifier":
                verifier_node = node_profile
                ver_id = node_cid
            elif "fuzzing" in node_cid or getattr(node_profile, "type", "") == "fuzzing_engine":
                fuzzer_node = node_profile
                fuz_id = node_cid
            elif "human" in node_cid or getattr(node_profile, "type", "") == "human":
                human_node = node_profile

        if not generator_node:
            gen_id = next(iter(manifest.nodes.keys()))
            generator_node = manifest.nodes.get(gen_id)

        max_forge_iterations = 5
        iteration = 0
        success = False

        while iteration < max_forge_iterations and not success:
            workflow.logger.info(f"Forge Iteration {iteration + 1}")
            await workflow.sleep(timedelta(seconds=0.1))

            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            self.reconcile_state({"iterations": iteration})

            if self._current_state_envelope is None:
                msg = "State Envelope is None"
                raise ValueError(msg)

            with workflow.unsafe.sandbox_unrestricted():
                gen_payload = manifest_payload.get(
                    "generator", generator_node.model_dump(mode="json") if generator_node else {}
                )

            gen_segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": gen_payload,
            }

            gen_result = await emitter.wrap_execution_block(
                name="ExecuteTensorInferenceComputeActivity:generator",
                kind="internal",
                trace_context=trace_context_state,
                block=lambda gen_segregated_payload=gen_segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                    "ExecuteTensorInferenceComputeActivity",
                    args=[
                        workflow.info().workflow_id,
                        gen_segregated_payload,
                        (
                            gen_segregated_payload.get("node_profile", {}).get("action_space_cid")
                            if isinstance(gen_segregated_payload, dict) and "node_profile" in gen_segregated_payload
                            else (
                                gen_segregated_payload.get("action_space_cid")
                                if isinstance(gen_segregated_payload, dict)
                                else None
                            )
                        )
                        or "AgentResponse",
                    ],  # pragma: no cover
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                ),
            )
            usage = gen_result.get("usage", {})
            self._accumulated_tokens += usage.get("total_tokens", 0)
            self._accumulated_cost += gen_result.get("cost", 0.0)
            await self.record_thermodynamic_burn("gen", usage, gen_result.get("cost", 0.0))

            self.reconcile_state(
                {
                    "accumulated_tokens": self._accumulated_tokens,
                    "accumulated_cost": self._accumulated_cost,
                }
            )

            results.append({"node": gen_id, "type": "generation", "result": gen_result})

            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            ver_result = {}
            if verifier_node:
                with workflow.unsafe.sandbox_unrestricted():
                    ver_payload = manifest_payload.get("verifier", verifier_node.model_dump(mode="json"))
                    ver_payload["artifact"] = gen_result

                ver_segregated_payload = {
                    "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                    "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                    "node_profile": ver_payload,
                }

                ver_result = await emitter.wrap_execution_block(
                    name="ExecuteTensorInferenceComputeActivity:verifier",
                    kind="internal",
                    trace_context=trace_context_state,
                    block=lambda ver_segregated_payload=ver_segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                        "ExecuteTensorInferenceComputeActivity",
                        args=[
                            workflow.info().workflow_id,
                            ver_segregated_payload,
                            (
                                ver_segregated_payload.get("node_profile", {}).get("action_space_cid")
                                if isinstance(ver_segregated_payload, dict) and "node_profile" in ver_segregated_payload
                                else (
                                    ver_segregated_payload.get("action_space_cid")
                                    if isinstance(ver_segregated_payload, dict)
                                    else None
                                )
                            )
                            or "VerificationYield",
                        ],  # pragma: no cover
                        schedule_to_close_timeout=timedelta(minutes=5),
                        retry_policy=RetryPolicy(maximum_attempts=5),
                    ),
                )
                ver_usage = ver_result.get("usage", {})
                self._accumulated_tokens += ver_usage.get("total_tokens", 0)
                self._accumulated_cost += ver_result.get("cost", 0.0)
                await self.record_thermodynamic_burn("verifier", ver_usage, ver_result.get("cost", 0.0))

                self.reconcile_state(
                    {
                        "accumulated_tokens": self._accumulated_tokens,
                        "accumulated_cost": self._accumulated_cost,
                    }
                )

                results.append({"node": ver_id, "type": "verification", "result": ver_result})
                ver_success = ver_result.get("success", False)
            else:
                ver_success = True

            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            fuz_result = {}
            if fuzzer_node and ver_success:
                with workflow.unsafe.sandbox_unrestricted():
                    fuz_payload = manifest_payload.get("fuzzer", fuzzer_node.model_dump(mode="json"))
                    fuz_payload["artifact"] = gen_result

                fuz_segregated_payload = {
                    "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                    "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                    "node_profile": fuz_payload,
                }

                fuz_result = await emitter.wrap_execution_block(
                    name="ExecuteTensorInferenceComputeActivity:fuzzer",
                    kind="internal",
                    trace_context=trace_context_state,
                    block=lambda fuz_segregated_payload=fuz_segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                        "ExecuteTensorInferenceComputeActivity",
                        args=[
                            workflow.info().workflow_id,
                            fuz_segregated_payload,
                            (
                                fuz_segregated_payload.get("node_profile", {}).get("action_space_cid")
                                if isinstance(fuz_segregated_payload, dict) and "node_profile" in fuz_segregated_payload
                                else (
                                    fuz_segregated_payload.get("action_space_cid")
                                    if isinstance(fuz_segregated_payload, dict)
                                    else None
                                )
                            )
                            or "AgentResponse",
                        ],  # pragma: no cover
                        schedule_to_close_timeout=timedelta(minutes=5),
                        retry_policy=RetryPolicy(maximum_attempts=5),
                    ),
                )
                fuz_usage = fuz_result.get("usage", {})
                self._accumulated_tokens += fuz_usage.get("total_tokens", 0)
                self._accumulated_cost += fuz_result.get("cost", 0.0)
                await self.record_thermodynamic_burn("fuzzer", fuz_usage, fuz_result.get("cost", 0.0))

                self.reconcile_state(
                    {
                        "accumulated_tokens": self._accumulated_tokens,
                        "accumulated_cost": self._accumulated_cost,
                    }
                )

                results.append({"node": fuz_id, "type": "fuzzing", "result": fuz_result})
                fuz_success = fuz_result.get("success", False)
            else:
                fuz_success = bool(ver_success)

            if ver_success and fuz_success:
                if human_node:
                    workflow.logger.info("Pausing for Human approval. Awaiting 'approve_forge' signal.")
                    with workflow.unsafe.sandbox_unrestricted():
                        required_att = getattr(human_node, "required_attestation", "fido2_webauthn")
                    await workflow.wait_condition(lambda: self._human_approval_attestation is not None)

                    if self._human_approval_attestation == required_att:
                        workflow.logger.info("Human specifically approved the topology execution!")
                        success = True
                    else:
                        workflow.logger.warning("Human rejected or provided invalid signature.")
                        success = False
                else:
                    success = True

            final_receipt = fuz_result if fuzzer_node and ver_success else (ver_result if verifier_node else gen_result)
            intent_hash = final_receipt.get("intent_hash")
            if not intent_hash or intent_hash == "UNKNOWN_HASH":  # pragma: no cover
                import hashlib
                import json

                intent_hash = hashlib.sha256(json.dumps(final_receipt, sort_keys=True).encode("utf-8")).hexdigest()

            await workflow.execute_activity(
                "StoreEpistemicStateIOActivity",
                args=[workflow.info().workflow_id, intent_hash, success, final_receipt, None],
                schedule_to_close_timeout=timedelta(minutes=1),
            )

            iteration += 1

        workflow.logger.info("Completed CapabilityForgeExecutionWorkflow")
        return {"status": "success" if success else "failed", "results": results}
