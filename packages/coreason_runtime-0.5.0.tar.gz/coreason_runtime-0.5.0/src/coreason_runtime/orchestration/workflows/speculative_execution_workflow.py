# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class SpeculativeExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow managing conditional state branches utilizing Jon Doyle's Truth Maintenance System logic."""

    def __init__(self) -> None:
        """AGENT INSTRUCTION: Initialize the speculative parallel graph runner to prevent logic path contagion."""
        super().__init__()
        self._interruption_event: dict[str, Any] | None = None
        self._rollback_intent: dict[str, Any] | None = None

    @workflow.signal(name="receive_barge_in")
    async def receive_barge_in(self, event_payload: dict[str, Any]) -> None:
        """Process BargeInInterruptEvent dynamically mid-execution."""
        workflow.logger.warning("Barge-In Interruption structurally triggered closing logic path.")
        self._interruption_event = event_payload

    @workflow.signal(name="receive_rollback_intent")
    async def receive_rollback_intent(self, intent_payload: dict[str, Any]) -> None:
        """Process RollbackIntent signaling deterministic structural failures in isolated geometries."""
        workflow.logger.warning("Rollback Intent triggered. Falsification logic actively unwinding timeline.")
        self._rollback_intent = intent_payload

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Speculative Execution Context Context workflow mapping parallel branch pathways natively.

        AGENT INSTRUCTION: Fork execution pathways probabilistically preventing Epistemic Contagion using safe sandbox borders.

        Args:
            payload: Dict representing ExecutionEnvelopeState containing the SpeculativeExecutionPolicy geometries.
        """
        import copy

        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        # Decode contextual extraction variables mapped explicitly against the SpeculativeExecutionPolicy schemas
        policy_dict = manifest_payload.get("payload", {}) if isinstance(manifest_payload, dict) else {}

        # Safely enforce logical pointer defaults avoiding null referencing panics.
        speculative_cid = policy_dict.get("speculative_cid", f"anon_branch_{workflow.info().workflow_id}")
        _target_node_cid = policy_dict.get("target_node_cid")
        commit_prob = float(policy_dict.get("commit_probability", 0.0))
        rollback_pointers = policy_dict.get("rollback_pointers", [])

        workflow.logger.info(
            f"Initiating Context Fork for logic '{speculative_cid}' safely bound inside a Shadow State."
        )

        # In a real environment we duplicate the node graph payload natively binding local causal edges.
        shadow_payload = copy.deepcopy(payload)

        # Execute temporal forks spawning a strict physical logic block using DAG hierarchies
        child_future = workflow.execute_child_workflow(
            "DAGExecutionWorkflow",
            args=[shadow_payload],
            id=f"{workflow.info().workflow_id}-shadow-{speculative_cid}",
        )

        try:
            # We concurrently await either nominal pipeline completion or external interruption signaling causal collapse.
            async def await_interrupts() -> None:
                await workflow.wait_condition(
                    lambda: self._interruption_event is not None or self._rollback_intent is not None
                )

            interrupt_task = asyncio.create_task(await_interrupts())
            child_task = asyncio.create_task(child_future)

            done, _pending = await asyncio.wait(
                [child_task, interrupt_task],
                return_when=asyncio.FIRST_COMPLETED,
            )

            # Causal Graph Falsification Logic Execution Maps
            if interrupt_task in done:
                child_task.cancel()
                if self._rollback_intent:
                    workflow.logger.warning(
                        f"Target Branch Falsified. Executing Causal Rollback restoring timeline to {rollback_pointers}"
                    )
                    return {
                        "status": "rolled_back",
                        "falsified_subgraph": speculative_cid,
                        "rewind_anchors": rollback_pointers,
                        "rollback_intent": self._rollback_intent,
                    }
                if self._interruption_event:
                    workflow.logger.info("Executing Barge-In extraction halt yielding back up the chain.")
                    return {
                        "status": "barge_in_halted",
                        "event": self._interruption_event,
                    }

            # Normal Speculative Completion
            result = child_task.result()

            # Probability-Weighted Commitment mappings
            threshold_target = 0.8  # Dynamic integration targets threshold mapping natively limits.

            if commit_prob >= threshold_target:
                workflow.logger.info(
                    "Probabilistic Metric threshold validation complete. Merging active logic branches safely."
                )
                return {"status": "success", "result": result, "committed": True}
            workflow.logger.warning(
                f"Probabilistic threshold insufficient (P={commit_prob}). Remaining structurally isolated in Shadow Map."
            )
            return {"status": "success", "result": result, "committed": False}

        except asyncio.CancelledError:
            workflow.logger.info("Shadow context violently unlinked.")
            raise
