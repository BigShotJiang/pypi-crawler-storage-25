# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.telemetry.emitter import TelemetryEmitter

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class SMPCExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents an SMPC Topology manifest.

    AGENT INSTRUCTION: Establishes a Secure Multi-Party Computation ring where
    each participant produces a private share and shares are aggregated via the
    designated cryptographic protocol.
    """

    def __init__(self) -> None:
        """Initialize SMPCExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the SMPC workflow.

        AGENT INSTRUCTION: Each participant node receives the joint_function_uri and
        independently computes its private share. All shares are then aggregated per the
        smpc_protocol (garbled_circuits / secret_sharing / oblivious_transfer).

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing an SMPCTopologyManifest.

        Returns:
            A dictionary containing the participant shares and aggregated result.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        emitter = TelemetryEmitter("")
        trace_context_state = self._current_state_envelope.trace_context

        workflow.logger.info("Starting SMPCExecutionWorkflow")

        results: list[dict[str, Any]] = []
        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import SMPCTopologyManifest

            manifest = SMPCTopologyManifest.model_validate_json(json.dumps(manifest_payload))

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        participant_ids = manifest.participant_node_cids
        smpc_protocol = manifest.smpc_protocol
        joint_function_uri = manifest.joint_function_uri

        if self._current_state_envelope is None:  # pragma: no cover
            msg = "State Envelope is None"
            raise ValueError(msg)

        workflow.logger.info(f"SMPC share generation: {len(participant_ids)} participants, protocol: {smpc_protocol}")

        participant_shares: dict[str, dict[str, Any]] = {}

        for participant_id in participant_ids:
            await workflow.sleep(timedelta(seconds=0.1))
            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            node_profile = manifest.nodes.get(participant_id)
            with workflow.unsafe.sandbox_unrestricted():
                node_payload = manifest_payload.get("nodes", {}).get(participant_id)
                if not node_payload:  # pragma: no cover
                    node_payload = node_profile.model_dump(mode="json") if node_profile else {}
                node_payload = dict(node_payload)
                node_payload["joint_function_uri"] = joint_function_uri
                node_payload["smpc_protocol"] = smpc_protocol

            segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": node_payload,
            }

            result = await emitter.wrap_execution_block(
                name=f"ExecuteTensorInferenceComputeActivity:smpc:share:{participant_id}",
                kind="internal",
                trace_context=trace_context_state,
                block=lambda sp=segregated_payload, tq=participant_id: workflow.execute_activity(  # type: ignore[misc]
                    "ExecuteTensorInferenceComputeActivity",
                    args=[
                        workflow.info().workflow_id,
                        sp,
                        (
                            sp.get("node_profile", {}).get("action_space_cid")
                            if isinstance(sp, dict) and "node_profile" in sp
                            else None
                        )
                        or "AgentResponse",
                    ],  # pragma: no cover
                    task_queue=tq,  # Segregated cross-boundary routing
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                ),
            )

            usage = result.get("usage", {})
            self._accumulated_tokens += usage.get("total_tokens", 0)
            self._accumulated_cost += result.get("cost", 0.0)
            await self.record_thermodynamic_burn("result", usage, result.get("cost", 0.0))

            participant_shares[participant_id] = result
            results.append(
                {
                    "participant_id": participant_id,
                    "type": "share",
                    "result": result,
                }
            )

        workflow.logger.info(f"SMPC aggregating shares via {smpc_protocol}")

        await workflow.sleep(timedelta(seconds=0.1))
        self.enforce_governance_limits(governance, workflow_start_time)
        self.enforce_lbac_clearance(allowed_classifications, "public")

        first_participant_id = participant_ids[0]
        aggregation_node = manifest.nodes.get(first_participant_id)
        with workflow.unsafe.sandbox_unrestricted():
            agg_payload = aggregation_node.model_dump(mode="json") if aggregation_node else {}
            agg_payload = dict(agg_payload)
            agg_payload["shares"] = list(participant_shares.values())
            agg_payload["smpc_protocol"] = smpc_protocol
            agg_payload["joint_function_uri"] = joint_function_uri
            agg_payload["aggregation_phase"] = True

        agg_segregated_payload = {
            "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
            "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
            "node_profile": agg_payload,
        }

        agg_result = await emitter.wrap_execution_block(
            name="ExecuteTensorInferenceComputeActivity:smpc:aggregate",
            kind="internal",
            trace_context=trace_context_state,
            block=lambda sp=agg_segregated_payload, tq=first_participant_id: workflow.execute_activity(  # type: ignore[misc]
                "ExecuteTensorInferenceComputeActivity",
                args=[
                    workflow.info().workflow_id,
                    sp,
                    (
                        sp.get("node_profile", {}).get("action_space_cid")
                        if isinstance(sp, dict) and "node_profile" in sp
                        else None
                    )
                    or "AgentResponse",
                ],  # pragma: no cover
                task_queue=tq,  # Route to aggregator node
                schedule_to_close_timeout=timedelta(minutes=5),
                retry_policy=RetryPolicy(maximum_attempts=5),
            ),
        )

        agg_usage = agg_result.get("usage", {})
        self._accumulated_tokens += agg_usage.get("total_tokens", 0)
        self._accumulated_cost += agg_result.get("cost", 0.0)
        await self.record_thermodynamic_burn("aggregator", agg_usage, agg_result.get("cost", 0.0))

        self.reconcile_state(
            {
                "accumulated_tokens": self._accumulated_tokens,
                "accumulated_cost": self._accumulated_cost,
            }
        )

        results.append(
            {
                "type": "aggregation",
                "smpc_protocol": smpc_protocol,
                "result": agg_result,
            }
        )

        intent_hash = agg_result.get("intent_hash")
        if not intent_hash or intent_hash == "UNKNOWN_HASH":  # pragma: no cover
            import hashlib
            import json

            intent_hash = hashlib.sha256(json.dumps(agg_result, sort_keys=True).encode("utf-8")).hexdigest()
        success = agg_result.get("success", True)

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, intent_hash, success, agg_result, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed SMPCExecutionWorkflow")
        return {
            "status": "success",
            "smpc_protocol": smpc_protocol,
            "participants": len(participant_ids),
            "results": results,
        }
