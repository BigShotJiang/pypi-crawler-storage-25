# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.telemetry.emitter import TelemetryEmitter

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class IntentElicitationExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow representing an Intent Elicitation Topology.

    AGENT INSTRUCTION: Handles VLM extraction mapping cyclical bounds. Yields to human
    oracles when epistemic entropy breaches the specified maximum.
    """

    def __init__(self) -> None:
        """Initialize IntentElicitationExecutionWorkflow."""
        super().__init__()  # pragma: no cover

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:  # pragma: no cover
        """Run the Intent Elicitation workflow."""

        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload
        trace_context_state = self._current_state_envelope.trace_context
        emitter = TelemetryEmitter("")
        workflow_start_time = workflow.now()

        workflow.logger.info("Starting IntentElicitationExecutionWorkflow")

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import IntentElicitationTopologyManifest

            manifest = IntentElicitationTopologyManifest.model_validate_json(json.dumps(manifest_payload))

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        entropy_threshold = 0.5  # Default heuristic threshold
        interrogation_rounds = manifest.max_clarification_loops
        current_round = 0

        final_intent = {}

        while current_round < interrogation_rounds:
            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            extractor_id = (
                str(manifest.scanner_node_cid)
                if getattr(manifest, "scanner_node_cid", None) is not None
                else next(iter(manifest.nodes.keys()))
            )

            with workflow.unsafe.sandbox_unrestricted():
                node_payload = manifest_payload.get("nodes", {}).get(extractor_id)
                if not node_payload:
                    node_profile = manifest.nodes.get(extractor_id)
                    dump_func = getattr(node_profile, "model_dump", None)
                    node_payload = (
                        dump_func(mode="json")
                        if node_profile is not None and dump_func is not None
                        else {"type": "agent", "description": "VLM Extractor"}
                    )

            segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": node_payload,
                "round": current_round,
            }

            result = await emitter.wrap_execution_block(
                name=f"ExecuteTensorInferenceComputeActivity:intent_elicitation:round_{current_round}",
                kind="internal",
                trace_context=trace_context_state,
                block=lambda sp=segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                    "ExecuteTensorInferenceComputeActivity",
                    args=[
                        workflow.info().workflow_id,
                        sp,
                        (
                            sp.get("node_profile", {}).get("action_space_cid")
                            if isinstance(sp, dict) and "node_profile" in sp
                            else None
                        )
                        or "AgentResponse",
                    ],  # pragma: no cover
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                ),
            )

            usage = result.get("usage", {})
            self._accumulated_tokens += usage.get("total_tokens", 0)
            self._accumulated_cost += result.get("cost", 0.0)
            await self.record_thermodynamic_burn("result", usage, result.get("cost", 0.0))

            self.reconcile_state(
                {
                    "accumulated_tokens": self._accumulated_tokens,
                    "accumulated_cost": self._accumulated_cost,
                }
            )

            measured_entropy = result.get("outputs", {}).get("entropy", 0.0)
            if measured_entropy > entropy_threshold:
                workflow.logger.info(
                    f"Epistemic Entropy '{measured_entropy}' > threshold '{entropy_threshold}'. "
                    "Awaiting oracle override."
                )
                await workflow.wait_condition(
                    lambda: self._pending_oracle_override is not None or self._current_oracle_resolution is not None
                )

                if self._pending_oracle_override is not None:
                    final_intent = self._pending_oracle_override
                    self._pending_oracle_override = None
                    break
                self._current_oracle_resolution = None
            else:
                final_intent = result
                break

            current_round += 1

        intent_hash = final_intent.get("intent_hash") if isinstance(final_intent, dict) else None
        if not intent_hash or intent_hash == "UNKNOWN_HASH":  # pragma: no cover
            import hashlib
            import json

            intent_hash = hashlib.sha256(json.dumps(final_intent, sort_keys=True).encode("utf-8")).hexdigest()
        success = final_intent.get("success", True) if final_intent else False

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, intent_hash, success, final_intent, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed IntentElicitationExecutionWorkflow")
        return {"status": "success", "rounds": current_round, "intent": final_intent}
