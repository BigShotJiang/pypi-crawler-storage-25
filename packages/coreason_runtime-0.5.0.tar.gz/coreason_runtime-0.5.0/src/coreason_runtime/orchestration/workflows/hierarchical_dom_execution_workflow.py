# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from datetime import timedelta
from typing import Any

from temporalio import activity, workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState

from .base_topology_workflow import BaseTopologyWorkflow


@activity.defn
def parse_spatial_blocks_activity(payload: dict[str, Any]) -> dict[str, Any]:
    """Deterministically parses nested spatial blocks representing visual/logical containment."""
    nodes = payload.get("nodes", {})

    parsed_blocks = []

    def traverse(node_cid: str, current_depth: int) -> None:
        node_data = nodes.get(node_cid)
        if not node_data:
            return

        block_info = {
            "node_cid": node_cid,
            "depth": current_depth,
            "spatial_bounds": node_data.get("spatial_bounds", {}),
            "node_type": node_data.get("type", "dom_node"),
        }
        parsed_blocks.append(block_info)

        children = node_data.get("children", [])
        for child_cid in children:
            traverse(child_cid, current_depth + 1)

    # Find root nodes (nodes without parents, or designated as root)
    # Simple heuristic to process all nodes if no explicit structure given
    # Or start by finding all children, then nodes not in any children list are roots
    all_children = set()
    for n_data in nodes.values():
        all_children.update(n_data.get("children", []))

    root_nodes = [cid for cid in nodes if cid not in all_children]

    for root_cid in root_nodes:
        traverse(root_cid, 0)

    return {"parsed_spatial_blocks": parsed_blocks, "total_nodes_parsed": len(parsed_blocks)}


@workflow.defn
class HierarchicalDOMExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents a Hierarchical DOM Topology manifest."""

    def __init__(self) -> None:
        """Initialize HierarchicalDOMExecutionWorkflow."""
        super().__init__()  # pragma: no cover

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Hierarchical DOM workflow.

        Args:
            payload: The ExecutionEnvelopeState containing a HierarchicalDOMManifest.

        Returns:
            A dictionary containing the parsed spatial blocks.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting HierarchicalDOMExecutionWorkflow")

        parsing_result = await workflow.execute_local_activity(
            parse_spatial_blocks_activity, manifest_payload, schedule_to_close_timeout=timedelta(seconds=120)
        )

        result = {
            "success": True,
            "parsed_blocks": parsing_result["parsed_spatial_blocks"],
            "total_nodes": parsing_result["total_nodes_parsed"],
            "manifest": {"server_cid": f"hierarchical_dom_{workflow.info().workflow_id}"},
        }

        workflow.logger.info("Completed HierarchicalDOMExecutionWorkflow")

        return result
