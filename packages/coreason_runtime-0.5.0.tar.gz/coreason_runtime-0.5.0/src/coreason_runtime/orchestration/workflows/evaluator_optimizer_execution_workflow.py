# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.telemetry.emitter import TelemetryEmitter

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class EvaluatorOptimizerExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that executes the Evaluator-Optimizer loop."""

    def __init__(self) -> None:  # pragma: no cover
        """Initialize EvaluatorOptimizerExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:  # pragma: no cover
        """Run the Evaluator-Optimizer loop.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing an EvaluatorOptimizerTopologyManifest.

        Returns:
            A dictionary containing the final execution status and results.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        emitter = TelemetryEmitter("")
        trace_context_state = self._current_state_envelope.trace_context

        workflow.logger.info("Starting EvaluatorOptimizerExecutionWorkflow")

        results: list[dict[str, Any]] = []

        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import EvaluatorOptimizerTopologyManifest

            manifest = EvaluatorOptimizerTopologyManifest.model_validate_json(json.dumps(manifest_payload))

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        iterations = 0
        max_iterations = getattr(manifest, "max_revision_loops", 3)

        gen_id = getattr(manifest, "generator_node_cid", None)
        generator_node = manifest.nodes.get(str(gen_id)) if gen_id is not None else None

        eval_id = getattr(manifest, "evaluator_node_cid", None)
        evaluator_node = manifest.nodes.get(str(eval_id)) if eval_id is not None else None
        evaluator_node = manifest.nodes.get(str(eval_id)) if eval_id is not None else None

        if not generator_node or not evaluator_node:
            workflow.logger.error("Missing generator or evaluator node.")
            return {"status": "error", "reason": "Missing required nodes"}

        eval_result: dict[str, Any] = {}

        while iterations < max_iterations:
            workflow.logger.info(f"Evaluator-Optimizer iteration {iterations + 1}")

            await workflow.sleep(timedelta(seconds=0.1))

            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            self.reconcile_state({"iterations": iterations})

            if self._current_state_envelope is None:
                msg = "State Envelope is None"
                raise ValueError(msg)

            with workflow.unsafe.sandbox_unrestricted():
                gen_payload = manifest_payload.get("generator", generator_node.model_dump(mode="json"))
                if iterations > 0 and eval_result:
                    gen_payload["input_data"] = eval_result.get("outputs", {})

            gen_segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": gen_payload,
            }

            gen_result = await emitter.wrap_execution_block(
                name="ExecuteTensorInferenceComputeActivity:generator",
                kind="internal",
                trace_context=trace_context_state,
                block=lambda gen_segregated_payload=gen_segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                    "ExecuteTensorInferenceComputeActivity",
                    args=[
                        workflow.info().workflow_id,
                        gen_segregated_payload,
                        (
                            gen_segregated_payload.get("node_profile", {}).get("action_space_cid")
                            if isinstance(gen_segregated_payload, dict) and "node_profile" in gen_segregated_payload
                            else (
                                gen_segregated_payload.get("action_space_cid")
                                if isinstance(gen_segregated_payload, dict)
                                else None
                            )
                        )
                        or "AgentResponse",
                    ],  # pragma: no cover
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                ),
            )

            usage = gen_result.get("usage", {})
            self._accumulated_tokens += usage.get("total_tokens", 0)
            self._accumulated_cost += gen_result.get("cost", 0.0)
            await self.record_thermodynamic_burn("gen", usage, gen_result.get("cost", 0.0))

            self.reconcile_state(
                {
                    "accumulated_tokens": self._accumulated_tokens,
                    "accumulated_cost": self._accumulated_cost,
                }
            )

            results.append({"type": "generation", "iteration": iterations, "result": gen_result})

            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            with workflow.unsafe.sandbox_unrestricted():
                eval_payload = manifest_payload.get("evaluator", evaluator_node.model_dump(mode="json"))
                eval_payload["input_data"] = gen_result

            eval_segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": eval_payload,
            }

            eval_result = await emitter.wrap_execution_block(
                name="ExecuteTensorInferenceComputeActivity:evaluator",
                kind="internal",
                trace_context=trace_context_state,
                block=lambda eval_segregated_payload=eval_segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                    "ExecuteTensorInferenceComputeActivity",
                    args=[
                        workflow.info().workflow_id,
                        eval_segregated_payload,
                        (
                            eval_segregated_payload.get("node_profile", {}).get("action_space_cid")
                            if isinstance(eval_segregated_payload, dict) and "node_profile" in eval_segregated_payload
                            else (
                                eval_segregated_payload.get("action_space_cid")
                                if isinstance(eval_segregated_payload, dict)
                                else None
                            )
                        )
                        or "AgentResponse",
                    ],  # pragma: no cover
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                ),
            )

            eval_usage = eval_result.get("usage", {})
            self._accumulated_tokens += eval_usage.get("total_tokens", 0)
            self._accumulated_cost += eval_result.get("cost", 0.0)
            await self.record_thermodynamic_burn("evaluator", eval_usage, eval_result.get("cost", 0.0))

            self.reconcile_state(
                {
                    "accumulated_tokens": self._accumulated_tokens,
                    "accumulated_cost": self._accumulated_cost,
                }
            )

            results.append({"type": "evaluation", "iteration": iterations, "result": eval_result})

            success_val = eval_result.get("success")
            if success_val is None:
                outputs = eval_result.get("outputs", {})
                success_val = outputs.get("success", False) if isinstance(outputs, dict) else False

            success = success_val.lower() == "true" if isinstance(success_val, str) else bool(success_val)

            intent_hash = eval_result.get("intent_hash")
            if not intent_hash or intent_hash == "UNKNOWN_HASH":  # pragma: no cover
                import hashlib
                import json

                intent_hash = hashlib.sha256(json.dumps(eval_result, sort_keys=True).encode("utf-8")).hexdigest()
            await workflow.execute_activity(
                "StoreEpistemicStateIOActivity",
                args=[workflow.info().workflow_id, intent_hash, success, eval_result, None],
                schedule_to_close_timeout=timedelta(minutes=1),
            )

            if success:
                workflow.logger.info("Optimizer reached success criteria.")
                break

            iterations += 1

        workflow.logger.info("Completed EvaluatorOptimizerExecutionWorkflow")
        return {"status": "success", "iterations": iterations, "results": results}
