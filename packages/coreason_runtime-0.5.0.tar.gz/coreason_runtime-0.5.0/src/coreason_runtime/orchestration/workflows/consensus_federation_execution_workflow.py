# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class ConsensusFederationExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents a Consensus Federation Topology manifest.

    AGENT INSTRUCTION: Zero-Cost Macro that unrolls into a CouncilTopologyManifest
    via compile_to_base_topology(), then delegates execution to CouncilExecutionWorkflow
    as a child workflow.
    """

    def __init__(self) -> None:
        """Initialize ConsensusFederationExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Consensus Federation workflow.

        AGENT INSTRUCTION: This macro topology deterministically compiles into a
        CouncilTopologyManifest and delegates to CouncilExecutionWorkflow. The pBFT
        quorum rules from the federation are preserved through the compilation.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing a ConsensusFederationTopologyManifest.

        Returns:
            A dictionary containing the results from the delegated Council workflow.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting ConsensusFederationExecutionWorkflow")

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import ConsensusFederationTopologyManifest

            federation_manifest = ConsensusFederationTopologyManifest.model_validate_json(json.dumps(manifest_payload))
            council_manifest = federation_manifest.compile_to_base_topology()
            council_payload = council_manifest.model_dump(mode="json", exclude_none=True)

        workflow.logger.info(
            f"Federation macro unrolled into Council with "
            f"{len(council_manifest.nodes)} nodes and adjudicator "
            f"'{federation_manifest.adjudicator_cid}'"
        )

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        if governance:  # pragma: no cover
            council_payload["governance"] = governance
        if allowed_classifications:  # pragma: no cover
            council_payload["allowed_information_classifications"] = allowed_classifications

        import copy

        child_envelope_data = copy.deepcopy(payload)
        child_envelope_data["payload"] = council_payload

        result = await workflow.execute_child_workflow(
            "CouncilExecutionWorkflow",
            args=[child_envelope_data],
            id=f"{workflow.info().workflow_id}-council-delegate",
        )

        workflow.logger.info("Completed ConsensusFederationExecutionWorkflow")
        import typing

        return typing.cast("dict[str, Any]", result)
