# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class DiscoveryDiscoveryWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that autonomously expands the swarm's semantic bounds.

    AGENT INSTRUCTION: Enables Action Space Elasticity by out-of-band querying verified registries,
    evaluating isometry via TensorRouter embeddings mapping, and commuting them into Medallion memory.
    """

    def __init__(self) -> None:
        """Initialize DiscoveryDiscoveryWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Execute the discovery logic for semantic growth."""
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting DiscoveryDiscoveryWorkflow tracking limits globally.")

        # Governed semantic growth bounds limits mathematically evaluating bounds cleanly
        discovery_threshold = manifest_payload.get("governance", {}).get("discovery_threshold", 0.90)

        nodes = manifest_payload.get("nodes", {})

        discovered_concepts = []
        for node_data in nodes.values():
            if node_data.get("topology_class") == "ontology_discovery":
                # Interrogation Stage structurally validating targets natively
                discovery_results = await workflow.execute_activity(
                    "ExecuteOntologyDiscoveryComputeActivity",
                    args=[node_data],
                    schedule_to_close_timeout=timedelta(minutes=2),
                    retry_policy=RetryPolicy(maximum_attempts=3),
                )

                # Concept Reification projecting bounds tracking offline parameters natively
                for result in discovery_results:
                    if result.get("isometry_score", 0.0) >= discovery_threshold:
                        workflow.logger.info(
                            f"Isometry threshold exceeded for {result.get('concept_cid')}, minting concept."
                        )

                        # Temporal Durability - Commit to Ledger ensuring idempotent logic dynamically
                        concept_payload = {
                            "node_cid": result.get("concept_cid"),
                            "topology_class": "synthetic_concept",
                            "registry_uri": result.get("registry_uri_verified"),
                            "parsed_schema": result.get("parsed_schema"),
                            "isometry_score": result.get("isometry_score"),
                        }

                        await workflow.execute_activity(
                            "StoreEpistemicStateIOActivity",
                            args=[
                                workflow.info().workflow_id,
                                result.get("concept_cid"),
                                True,
                                concept_payload,
                                None,
                            ],
                            schedule_to_close_timeout=timedelta(minutes=1),
                            retry_policy=RetryPolicy(maximum_attempts=5),
                        )

                        # Telemetry emission physically pushing DiscoveryReificationEvent logic accurately
                        telemetry_event = {
                            "event_type": "DiscoveryReificationEvent",
                            "concept_built": result.get("concept_cid"),
                            "isometry_bounds": result.get("isometry_score"),
                        }
                        await workflow.execute_activity(
                            "BroadcastStateEchoIOActivity",
                            args=[workflow.info().workflow_id, telemetry_event],
                            schedule_to_close_timeout=timedelta(minutes=1),
                        )

                        discovered_concepts.append(concept_payload)
                        self.reconcile_state({f"discovered_{result.get('concept_cid')}": concept_payload})
                    else:
                        workflow.logger.info(f"Concept rejected, isometry bounded beneath {discovery_threshold}.")

        workflow.logger.info("Completed DiscoveryDiscoveryWorkflow Semantic Mutation checks.")
        return {
            "status": "success",
            "concepts_minted": len(discovered_concepts),
            "concepts_geometry": discovered_concepts,
        }
