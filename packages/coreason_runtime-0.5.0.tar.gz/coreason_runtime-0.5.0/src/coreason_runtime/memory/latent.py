# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
import math
import time
from typing import TYPE_CHECKING

import pyarrow as pa  # type: ignore

from coreason_runtime.utils.logger import logger

if TYPE_CHECKING:
    from coreason_manifest import LatentProjectionIntent

    from coreason_runtime.memory.store import MedallionStateEngine


class LatentMemoryManager:
    """Idempotent Vector Space Manager with Autonomic Compaction."""

    def __init__(self, engine: MedallionStateEngine) -> None:
        self.engine = engine
        self.db = engine.db
        self.table_name = "latent_space"

    async def bootstrap(self) -> None:
        def _bootstrap() -> None:
            if self.table_name not in self.db.table_names():
                schema = pa.schema(
                    [
                        pa.field("intent_hash", pa.string()),  # Vector-Relational Isomorphic Key
                        pa.field("vector", pa.list_(pa.float32(), 1536)),
                        pa.field("context", pa.string()),
                        pa.field("timestamp", pa.float64()),
                        pa.field("access_frequency", pa.int64()),
                    ]
                )
                self.db.create_table(self.table_name, schema=schema)

        await asyncio.to_thread(_bootstrap)

        # Ignite Autonomic Compaction Daemon on boot
        await self.optimize_and_compact()

    async def optimize_and_compact(self) -> None:
        """Mathematically bounds RAG latency by resolving Arrow fragmentation."""

        def _optimize() -> None:
            try:
                table = self.db.open_table(self.table_name)
                table.optimize()
                logger.info("Autonomic Compaction: Latent space optimization nominal. Thermodynamic entropy reduced.")
            except Exception as e:
                logger.warning(f"Autonomic Compaction yielded: {e}")

        await asyncio.to_thread(_optimize)

    async def upsert_projection(self, intent_hash: str, intent: LatentProjectionIntent, vector: list[float]) -> None:
        """Idempotent vector commit anchoring onto the Isomorphic Key."""

        def _upsert() -> None:
            table = self.db.open_table(self.table_name)
            data = [
                {
                    "intent_hash": intent_hash,
                    "vector": vector,
                    "context": intent.model_dump_json(),
                    "timestamp": time.time(),
                    "access_frequency": 1,
                }
            ]

            table.merge_insert("intent_hash").when_matched_update_all().when_not_matched_insert_all().execute(data)
            logger.debug(f"Latent Projection Aligned. Isomorphic Key: {intent_hash}")

        await asyncio.to_thread(_upsert)

    async def prune_stale_vectors(self, decay_rate: float, threshold: float, protected_cids: list[str]) -> int:
        """Mathematically evaluate exact thermodynamic exhaustion across the bounding matrix."""

        def _prune() -> int:
            try:
                import polars as pl

                table = self.db.open_table(self.table_name)
                df = table.to_polars()
                if df.is_empty():
                    return 0

                now = time.time()
                df = df.with_columns((now - pl.col("timestamp")).alias("age")).with_columns(
                    (pl.col("access_frequency") * (math.e ** (-decay_rate * pl.col("age")))).alias("utility")
                )

                stale_hashes = df.filter(pl.col("utility") < threshold)["intent_hash"].to_list()
                stale_hashes = [h for h in stale_hashes if h not in protected_cids]

                if stale_hashes:
                    for i in range(0, len(stale_hashes), 50):
                        chunk = stale_hashes[i : i + 50]
                        hash_list = ", ".join(f"'{h}'" for h in chunk)
                        table.delete(f"intent_hash IN ({hash_list})")

                    pruned_dims = len(stale_hashes) * 1536
                    logger.info(
                        f"Epistemic Pruning complete: Purged {len(stale_hashes)} vectors ({pruned_dims} dimensions)."
                    )
                    table.optimize()
                    return len(stale_hashes)
                return 0
            except Exception as e:
                logger.warning(f"Epistemic pruning bounds generated failure natively securely: {e}")
                return 0

        return await asyncio.to_thread(_prune)
