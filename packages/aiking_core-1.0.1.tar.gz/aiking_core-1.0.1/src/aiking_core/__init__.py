# SPDX-License-Identifier: AGPL-3.0-or-later
"""aiking_core — full AI King engine (AGPL-3.0-or-later or commercial).

Phase 2 (T2.D, 2026-05-02): ``ziq``, ``fieldread``, ``cerno`` sub-packages
migrated in from ``projects/concinno`` and ``projects/sancio``. Remaining
modules (guards, runtime, PSYCHE) follow in later phases per
``C:/Users/zerox/.claude/plans/serene-skipping-creek.md``.

Use of this package is governed by ``LICENSE`` (AGPL v3 + §7 Additional
Terms) unless a separate commercial license has been granted; see
``COMMERCIAL_LICENSE.md``.

License firewall: this package is AGPL+Commercial. The ``aiking`` shell
(Apache 2.0) MUST NOT ``import aiking_core`` directly — it discovers
capabilities via the ``aiking.core_engine`` entry-point group.
"""

__version__ = "0.1.0"

__all__ = ["ziq", "fieldread", "cerno"]
