# SPDX-License-Identifier: AGPL-3.0-or-later
"""aiking_core.fieldread — Selective field extraction (AGPL).

Migrated from ``concinno.field_read`` (Phase 2 T2.D, 2026-05-02).
The full implementation lives in ``_core``; this module re-exports the
public surface for backward-compatible ``from aiking_core.fieldread import X``.
"""

from aiking_core.fieldread._core import *  # noqa: F401, F403

try:
    from aiking_core.fieldread._core import __all__  # noqa: F401
except ImportError:
    __all__ = []


def get_engine(*args, **kwargs):
    """Late-binding entry-point. Returns this module for now;
    aiking shell uses this for capability detection. May evolve into
    a proper engine factory in 1.1.0+.
    """
    import sys
    return sys.modules[__name__]
