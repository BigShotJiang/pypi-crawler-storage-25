# SPDX-License-Identifier: AGPL-3.0-or-later
"""persona.cerno.intercept — Step I: Enforce decisions.

Problems -> deny. Not warn. (Soft warning = negative ROI.)
Decision tree: critical defects -> deny -> consecutive -> transfer.

Ported from ``projects/aegis/src/aegis/cerno/intercept.py``.
"""

from __future__ import annotations

import time

from aiking_core.cerno.types import (
    CernoAction,
    CernoAllow,
    CernoConfig,
    CernoDeny,
    CernoRetry,
    CernoState,
    CernoTransfer,
    HandoffRecord,
    ReviewResult,
)

# Retry-on-defect codes (Reflexion-lite, MEMORY #56). These defects
# are recoverable via a single retry with tool_feedback_hint — no
# second LLM critic, ground truth = tool_result error flag.
# Gated by ``CernoConfig.enable_retry`` (default False, user directive
# 2026-04-17 "新 feature 預設關閉"). Benchmark runner sets True.
_RETRY_DEFECT_IDS: frozenset[str] = frozenset({"E9", "E10", "E11"})


def _retry_hint_for(defect_ids: list[str]) -> str:
    """Build short feedback hint for the agent based on defect codes."""
    hints: list[str] = []
    if "E9" in defect_ids:
        hints.append(
            "previous attempt refused — commit to a concrete best-guess"
        )
    if "E10" in defect_ids:
        hints.append(
            "previous attempt returned empty — ensure FINAL ANSWER line"
        )
    if "E11" in defect_ids:
        hints.append(
            "previous attempt leaked raw tool_result — synthesise first"
        )
    return "; ".join(hints) if hints else "retry with tool feedback"


def intercept(
    review: ReviewResult,
    state: CernoState,
    config: CernoConfig,
) -> CernoAction:
    """Step I: Decide action based on review result."""
    # 0. Recoverable defects (E9/E10/E11) → retry once (Reflexion-lite,
    #    MEMORY #56). Runs BEFORE critical-deny so a refusal echo
    #    triggers retry rather than transfer. Gated by
    #    ``config.enable_retry`` (default False).
    retryable: list = []
    if config.enable_retry:
        retryable = [
            d for d in review.defects_found
            if d.id in _RETRY_DEFECT_IDS
            and d.confidence >= config.retry_min_confidence
        ]
    if retryable and state.consecutive_denies < config.retry_max_attempts:
        ids = [d.id for d in retryable]
        return CernoRetry(
            reason=(
                f"{len(retryable)} recoverable defect(s): "
                f"{', '.join(ids)}"
            ),
            defects=ids,
            tool_feedback_hint=_retry_hint_for(ids),
        )

    critical = [
        d for d in review.defects_found
        if d.severity == "high" and d.confidence >= 0.6
    ]

    # 1. Critical defects -> deny (or transfer if consecutive)
    if critical:
        ids = [d.id for d in critical]
        if state.consecutive_denies + 1 >= config.max_consecutive_denies:
            return CernoTransfer(
                reason=(
                    f"{state.consecutive_denies + 1} consecutive denies"
                    " — child unsalvageable"
                ),
                handoff=HandoffRecord(
                    from_agent=state.child_id,
                    completed_work="Review history in recent scores",
                    remaining_work="Original task incomplete",
                    unresolved_issues=[
                        f"Defect {i} persists" for i in ids
                    ],
                    transfer_reason=(
                        f"Exceeded {config.max_consecutive_denies}"
                        " consecutive denies"
                    ),
                    transferred_at=time.time(),
                ),
            )
        return CernoDeny(
            reason=(
                f"{len(critical)} critical defect(s): "
                f"{', '.join(ids)}"
            ),
            defects=ids,
        )

    # 2. High sycophancy on risky input -> deny
    if (
        review.sycophancy_risk >= config.sycophancy_threshold
        and state.assessment
        and state.assessment.risk_level != "low"
    ):
        return CernoDeny(
            reason=(
                f"Sycophancy {review.sycophancy_risk:.0%} on"
                f" {state.assessment.risk_level}-risk input"
            ),
            defects=["A1"],
        )

    # 3. Quality below threshold -> deny
    if review.quality_score < config.deny_quality_threshold:
        return CernoDeny(
            reason=(
                f"Quality {review.quality_score}/100 below"
                f" threshold {config.deny_quality_threshold}"
            ),
            defects=[d.id for d in review.defects_found],
        )

    # 4. Allow
    return CernoAllow()
