# SPDX-License-Identifier: AGPL-3.0-or-later
"""persona.cerno.types — Cerno mother-agent type definitions.

Ported from ``projects/aegis/src/aegis/cerno/types.py``.

Seven-step cycle: Assess -> Review -> Balance -> Intercept -> Transfer -> Equilibrate -> Recalibrate
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional, Union

# ── Defect taxonomy ─────────────────────────────────────────

DefectCategory = Literal["L", "A", "B", "D", "E"]
DefectSeverity = Literal["low", "medium", "high"]


@dataclass
class DefectDefinition:
    id: str  # e.g. "L1", "A3"
    category: DefectCategory
    name: str
    detect: str  # detection heuristic description
    severity: DefectSeverity


@dataclass
class DefectHit:
    id: str
    severity: DefectSeverity
    evidence: str
    confidence: float  # 0.0–1.0


# ── Step A: Assess ──────────────────────────────────────────

RiskLevel = Literal["low", "medium", "high", "critical"]


@dataclass
class Assessment:
    user_intent: str
    risk_level: RiskLevel
    expected_traits: list[str]
    assessed_at: float  # timestamp


# ── Step R: Review ──────────────────────────────────────────

@dataclass
class ReviewResult:
    defects_found: list[DefectHit]
    quality_score: int  # 0–100
    aligned_with_assessment: bool
    sycophancy_risk: float  # 0.0–1.0
    reviewed_at: float


# ── Step B: Balance ─────────────────────────────────────────

@dataclass
class EquilibriumConfig:
    deny_increment: float = 1.0
    allow_decrement: float = 0.2
    pressure_threshold: float = 5.0
    cooldown_steps: int = 10
    pressure_cap: float = 20.0


@dataclass
class EquilibriumState:
    pressure: float = 0.0
    breaker_tripped: bool = False
    cooldown_remaining: int = 0
    deny_rate: float = 0.0
    total_steps: int = 0
    pressure_history: list[float] = field(default_factory=list)
    tct_frozen: bool = False


# ── Step I: Intercept ───────────────────────────────────────

@dataclass
class CernoAllow:
    type: Literal["allow"] = "allow"


@dataclass
class CernoDeny:
    type: Literal["deny"] = "deny"
    reason: str = ""
    defects: list[str] = field(default_factory=list)


@dataclass
class CernoTransfer:
    type: Literal["transfer"] = "transfer"
    reason: str = ""
    handoff: Optional["HandoffRecord"] = None


@dataclass
class CernoRecalibrate:
    type: Literal["recalibrate"] = "recalibrate"


@dataclass
class CernoRetry:
    """Retry with tool_result ground-truth feedback (non-LLM critic).

    Emitted when Review detects recoverable defects (E9 refusal echo,
    E10 empty answer, E11 raw tool leak) and the child has not yet
    exhausted retry budget. The agent loop re-runs the same step with
    ``tool_feedback_hint`` appended to context so the model sees what
    went wrong without invoking a separate LLM critic.

    See ``feedback_gaia_stack_s5_decision.md`` DO #1 (Reflexion-lite).
    """

    type: Literal["retry"] = "retry"
    reason: str = ""
    defects: list[str] = field(default_factory=list)
    tool_feedback_hint: str = ""


CernoAction = Union[
    CernoAllow, CernoDeny, CernoTransfer, CernoRecalibrate, CernoRetry,
]


# ── Step T: Transfer ────────────────────────────────────────

@dataclass
class HandoffRecord:
    from_agent: str
    completed_work: str
    remaining_work: str
    unresolved_issues: list[str]
    transfer_reason: str
    transferred_at: float


# ── Step R2: Recalibrate ────────────────────────────────────

@dataclass
class RecalibrationResult:
    steps_since_last_recal: int
    deny_rate_drift: Literal["too_strict", "too_lenient", "balanced"]
    emerging_patterns: list[str]
    adjustments: dict  # partial EquilibriumConfig overrides
    recalibrated_at: float


# ── Mother Identity ─────────────────────────────────────────

MotherIdentity = Literal["architect", "logic_cerno", "mirror", "economist", "compass"]

ChildActionType = Literal[
    "writing_code", "reasoning", "replying_to_user",
    "resource_allocation", "direction_decision", "unknown",
]


@dataclass
class MotherIdentityProfile:
    identity: MotherIdentity
    label: str
    focus: list[str]
    watch_defects: list[str]
    directive: str  # ≤50 tokens


# ── Full State ──────────────────────────────────────────────

@dataclass
class CernoState:
    assessment: Optional[Assessment] = None
    review: Optional[ReviewResult] = None
    equilibrium: EquilibriumState = field(default_factory=EquilibriumState)
    current_identity: MotherIdentity = "mirror"
    steps_since_recal: int = 0
    child_id: str = ""
    recent_scores: list[int] = field(default_factory=list)
    consecutive_denies: int = 0


# ── Configuration ───────────────────────────────────────────

@dataclass
class CernoConfig:
    equilibrium: EquilibriumConfig = field(default_factory=EquilibriumConfig)
    recalibration_interval: int = 100
    max_consecutive_denies: int = 3
    deny_quality_threshold: int = 50
    sycophancy_threshold: float = 0.6
    max_recent_scores: int = 20
    async_review: bool = True
    # Reflexion-lite retry (MEMORY #56). Default OFF — benchmark runners
    # and opt-in callers must set ``enable_retry=True`` explicitly. New
    # features default disabled on install/upgrade (user directive
    # 2026-04-17: "預設功能關閉 剛安裝 或升級 都要變成關閉").
    enable_retry: bool = False
    retry_max_attempts: int = 2
    retry_min_confidence: float = 0.7


DEFAULT_CERNO_CONFIG = CernoConfig()
