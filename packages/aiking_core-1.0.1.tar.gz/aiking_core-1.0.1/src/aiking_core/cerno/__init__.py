# SPDX-License-Identifier: AGPL-3.0-or-later
"""persona.cerno — Cerno mother-agent supervisory framework.

Seven-step cycle: Assess -> Review -> Balance -> Intercept ->
Transfer -> Equilibrate -> Recalibrate.

This is Aegis-only. CCC doesn't have it.
Cerno keeps the mother in supervisor mode — she sees what the
child missed.

Ported from ``projects/aegis/src/aegis/cerno/`` (byte-for-byte
logic, imports rewritten ``aegis.cerno`` -> ``persona.cerno``).
See ``_AI_BRAIN/06_Handoffs/aegis/交接_Aegis.md`` Phase 1 P1.2.
"""

from aiking_core.cerno.cerno import Cerno
from aiking_core.cerno.types import (
    CernoAction,
    CernoAllow,
    CernoConfig,
    CernoDeny,
    CernoRecalibrate,
    CernoState,
    CernoTransfer,
    Assessment,
    DEFAULT_CERNO_CONFIG,
    DefectHit,
    EquilibriumConfig,
    EquilibriumState,
    HandoffRecord,
    MotherIdentity,
    RecalibrationResult,
    ReviewResult,
)

__all__ = [
    "Cerno",
    "CernoAction",
    "CernoAllow",
    "CernoConfig",
    "CernoDeny",
    "CernoRecalibrate",
    "CernoState",
    "CernoTransfer",
    "Assessment",
    "DEFAULT_CERNO_CONFIG",
    "DefectHit",
    "EquilibriumConfig",
    "EquilibriumState",
    "HandoffRecord",
    "MotherIdentity",
    "RecalibrationResult",
    "ReviewResult",
]


def get_engine(*args, **kwargs):
    """Late-binding entry-point. Returns this module for now;
    aiking shell uses this for capability detection. May evolve into
    a proper engine factory in 1.1.0+.
    """
    import sys
    return sys.modules[__name__]
