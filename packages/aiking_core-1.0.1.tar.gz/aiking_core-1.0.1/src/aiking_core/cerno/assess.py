# SPDX-License-Identifier: AGPL-3.0-or-later
"""persona.cerno.assess — Step A: Independent pre-assessment.

Mother reads user input WITHOUT seeing child's response.
Forms independent judgment about intent and risk.
Pure heuristic — no LLM call, zero overhead.

Ported from ``projects/aegis/src/aegis/cerno/assess.py``.
"""

from __future__ import annotations

import re
import time

from aiking_core.cerno.types import Assessment, ChildActionType, RiskLevel

# ── Risk signals ────────────────────────────────────────────

_HIGH_RISK = [
    re.compile(
        r"\b(delet\w*|remov\w*|drop\w*|destroy\w*|force.?push|"
        r"reset\s+--hard|rm\s+-rf)\b",
        re.I,
    ),
    re.compile(
        r"\b(password\w*|secret\w*|api.?key\w*|credential\w*|token\w*)\b",
        re.I,
    ),
    re.compile(
        r"\b(production|prod|main\s+branch|master\s+branch)\b", re.I,
    ),
    re.compile(
        r"\b(publish\w*|release\w*|deploy\w*|"
        r"push\s+to\s+(npm|pypi|registry))\b",
        re.I,
    ),
]

_MEDIUM_RISK = [
    re.compile(
        r"\b(refactor\w*|restructur\w*|migrat\w*|rewrit\w*|overhaul\w*)\b",
        re.I,
    ),
    re.compile(
        r"\b(install\w*|upgrade\w*|downgrade\w*|uninstall\w*)\b", re.I,
    ),
    re.compile(
        r"\b(config\w*|setting\w*|env|environment\w*)\b", re.I,
    ),
    re.compile(
        r"\b(database\w*|schema\w*|table\w*|column\w*|index\w*)\b", re.I,
    ),
]

# ── Action classification ───────────────────────────────────

_ACTION_PATTERNS: list[tuple[re.Pattern, ChildActionType]] = [
    (
        re.compile(
            r"\b(writ\w*|edit\w*|creat\w*|implement\w*|fix\w*|"
            r"refactor\w*|add\w*|remov\w*|delet\w*)\b.*"
            r"\b(code|file|function|class|component|module|test)\b",
            re.I,
        ),
        "writing_code",
    ),
    (
        re.compile(
            r"\b(analy[zs]\w*|reason\w*|think\w*|evaluat\w*|"
            r"compar\w*|research\w*|investigat\w*)\b",
            re.I,
        ),
        "reasoning",
    ),
    (
        re.compile(
            r"\b(respond\w*|repl(?:y|ied|ies)|answer\w*|"
            r"explain\w*|tell|describ\w*|summari[zs]\w*)\b",
            re.I,
        ),
        "replying_to_user",
    ),
    (
        re.compile(
            r"\b(allocat\w*|budget\w*|cost\w*|token\w*|"
            r"resource\w*|priorit\w*|schedul\w*)\b",
            re.I,
        ),
        "resource_allocation",
    ),
    (
        re.compile(
            r"\b(decid\w*|choos\w*|direction\w*|strateg\w*|"
            r"plan\w*|architec\w*|approach\w*)\b",
            re.I,
        ),
        "direction_decision",
    ),
]


def classify_child_action(task: str) -> ChildActionType:
    for pat, action in _ACTION_PATTERNS:
        if pat.search(task):
            return action
    return "unknown"


def assess_risk_level(user_input: str) -> RiskLevel:
    high = sum(1 for p in _HIGH_RISK if p.search(user_input))
    med = sum(1 for p in _MEDIUM_RISK if p.search(user_input))
    if high >= 2:
        return "critical"
    if high >= 1:
        return "high"
    if med >= 2:
        return "high"
    if med >= 1:
        return "medium"
    return "low"


def extract_expected_traits(user_input: str) -> list[str]:
    traits: list[str] = []
    checks = [
        (r"\b(tests?|spec\w*|coverage)\b", "includes_tests"),
        (r"\b(safe\w*|secur\w*|guard\w*|protect\w*)\b", "security_conscious"),
        (r"\b(explain|document|comment)\b", "well_documented"),
        (r"\b(fast|perform|optim|efficien)\b", "performance_focused"),
        (r"\b(simple|minimal|clean|lean)\b", "minimal_complexity"),
        (
            r"\b(backward|compat|migrat|non.?breaking)\b",
            "backward_compatible",
        ),
        (r"\b(type|typed|typescript|schema|validat)\b", "type_safe"),
    ]
    for pattern, trait in checks:
        if re.search(pattern, user_input, re.I):
            traits.append(trait)
    return traits


def assess(user_input: str) -> Assessment:
    """Step A: Form independent assessment. No LLM call."""
    return Assessment(
        user_intent=user_input[:200],
        risk_level=assess_risk_level(user_input),
        expected_traits=extract_expected_traits(user_input),
        assessed_at=time.time(),
    )
