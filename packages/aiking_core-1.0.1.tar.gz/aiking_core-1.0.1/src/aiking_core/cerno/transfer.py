# SPDX-License-Identifier: AGPL-3.0-or-later
"""persona.cerno.transfer — Step T+E: Transfer and equilibrate.

Unsalvageable child -> structured handoff -> replace.
Step E restores balance after transfer.

Ported from ``projects/aegis/src/aegis/cerno/transfer.py``.
"""

from __future__ import annotations

import copy
import time

from aiking_core.cerno.types import (
    CernoState,
    EquilibriumState,
    HandoffRecord,
)


def build_handoff(state: CernoState, reason: str) -> HandoffRecord:
    """Build structured handoff for departing child.

    Honesty: unresolved_issues is NEVER empty.
    """
    defects = (
        [d.id for d in state.review.defects_found]
        if state.review
        else []
    )
    avg = (
        sum(state.recent_scores) / len(state.recent_scores)
        if state.recent_scores
        else 0
    )
    aligned = (
        state.review.aligned_with_assessment if state.review else False
    )

    return HandoffRecord(
        from_agent=state.child_id,
        completed_work=(
            "Partial — output aligned with intent but quality insufficient"
            if aligned
            else "Minimal — output did not align with assessed intent"
        ),
        remaining_work=(
            state.assessment.user_intent
            if state.assessment
            else "Original task (see assessment)"
        ),
        unresolved_issues=(
            [f"Recurring defect: {d}" for d in defects]
            if defects
            else [
                "No specific defect pattern — general quality below threshold"
            ]
        ),
        transfer_reason=(
            f"{reason} (avg score: {avg:.0f}/100,"
            f" {state.consecutive_denies} consecutive denies)"
        ),
        transferred_at=time.time(),
    )


def equilibrate(state: CernoState, new_child_id: str) -> CernoState:
    """Step E: Reset state for new child. Pressure halved, scores cleared."""
    new = copy.copy(state)
    new.child_id = new_child_id
    new.review = None
    new.equilibrium = EquilibriumState(
        pressure=state.equilibrium.pressure * 0.5,
        breaker_tripped=False,
        cooldown_remaining=0,
        deny_rate=state.equilibrium.deny_rate,
        total_steps=state.equilibrium.total_steps,
        pressure_history=list(state.equilibrium.pressure_history),
        tct_frozen=False,
    )
    new.recent_scores = []
    new.consecutive_denies = 0
    return new
