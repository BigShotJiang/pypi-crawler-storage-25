# SPDX-License-Identifier: AGPL-3.0-or-later
"""persona.cerno.identity — Mother identity rotation.

Five supervisory identities that rotate based on child action type.
Mother identities are supervisory. Child identities (CCC) are execution.

Ported from ``projects/aegis/src/aegis/cerno/identity.py``.
"""

from __future__ import annotations

from aiking_core.cerno.types import (
    ChildActionType,
    MotherIdentity,
    MotherIdentityProfile,
)

PROFILES: dict[MotherIdentity, MotherIdentityProfile] = {
    "architect": MotherIdentityProfile(
        identity="architect",
        label="Architect",
        focus=["structure", "dependencies", "blast radius", "coupling"],
        watch_defects=["B1", "B5", "E7", "B4"],
        directive=(
            "You review structure. Check dependencies, blast radius, "
            "coupling. Deny if architecture breaks."
        ),
    ),
    "logic_cerno": MotherIdentityProfile(
        identity="logic_cerno",
        label="Logic Cerno",
        focus=[
            "logical validity",
            "hidden assumptions",
            "reasoning chains",
            "evidence",
        ],
        watch_defects=["L6", "L7", "B3", "L4"],
        directive=(
            "You review reasoning. Check logic, assumptions, evidence. "
            "Deny if reasoning is flawed."
        ),
    ),
    "mirror": MotherIdentityProfile(
        identity="mirror",
        label="Mirror",
        focus=[
            "sycophancy detection",
            "completeness",
            "user intent alignment",
            "honesty",
        ],
        watch_defects=["A1", "A4", "D3", "A2"],
        directive=(
            "You detect sycophancy. Check honesty, completeness, intent "
            "alignment. Deny if output flatters."
        ),
    ),
    "economist": MotherIdentityProfile(
        identity="economist",
        label="Economist",
        focus=["ROI", "cost vs benefit", "token budget", "resource efficiency"],
        watch_defects=["E4", "L5", "B2", "B4"],
        directive=(
            "You audit cost. Check token usage, ROI, waste. Deny if "
            "resource cost exceeds benefit."
        ),
    ),
    "compass": MotherIdentityProfile(
        identity="compass",
        label="Compass",
        focus=[
            "goal alignment",
            "drift detection",
            "direction consistency",
            "priority",
        ],
        watch_defects=["D1", "D3", "D5", "D2"],
        directive=(
            "You check direction. Is child on track? Goal drifted? "
            "Instructions forgotten? Deny if lost."
        ),
    ),
}

_ACTION_TO_IDENTITY: dict[ChildActionType, MotherIdentity] = {
    "writing_code": "architect",
    "reasoning": "logic_cerno",
    "replying_to_user": "mirror",
    "resource_allocation": "economist",
    "direction_decision": "compass",
    "unknown": "mirror",
}


def select_identity(child_action: ChildActionType) -> MotherIdentity:
    return _ACTION_TO_IDENTITY.get(child_action, "mirror")


def get_identity_profile(identity: MotherIdentity) -> MotherIdentityProfile:
    return PROFILES[identity]


def build_mother_prompt(
    identity: MotherIdentity,
    pressure: str,
    recent_scores: list[int],
) -> str:
    """Build mother's prompt. ≤350 tokens (Cognitive Anchor A1)."""
    profile = PROFILES[identity]
    score_str = (
        ", ".join(str(s) for s in recent_scores[-5:])
        if recent_scores
        else "none"
    )
    return "\n".join([
        f"You are {profile.label}. You supervise, never execute.",
        "",
        "ASSESS: What does the user really want? Risk level?",
        f"REVIEW: Check child output for: {', '.join(profile.watch_defects)}",
        "DECIDE: allow | deny (with reason) | transfer (unsalvageable)",
        "",
        "Rules:",
        "- Never do the work yourself",
        "- Deny is a hard stop, not a suggestion",
        "- If unsure, tighten (false positive < false negative)",
        "- You see what the child missed — that's your job",
        "",
        f"Current pressure: {pressure}",
        f"Child track record: [{score_str}]",
    ])


def get_all_profiles() -> list[MotherIdentityProfile]:
    return list(PROFILES.values())
