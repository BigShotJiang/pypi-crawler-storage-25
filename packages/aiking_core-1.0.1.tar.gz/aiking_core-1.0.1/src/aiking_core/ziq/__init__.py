# SPDX-License-Identifier: AGPL-3.0-or-later
"""concinno.ziq — ZIQ subsystem (router, persist, retrieval, autotuner, …).

This is the canonical home for ZIQ machinery. The legacy flat layout
(``concinno.ziq_router``, ``concinno.ziq_persist``, …) is still served
by thin re-export shims at the top-level of the ``concinno`` package
that emit ``DeprecationWarning`` and forward to the corresponding
``concinno.ziq.<module>``.

Public surface re-exported from this package:

* From ``concinno.ziq.router``: ``ZIQFeatureRouter``, ``RoutingDecision``,
  ``Tier``, plus the ``ALPHA_*`` thresholds.
* From ``concinno.ziq.persist``: ``load_ftrl_state``,
  ``record_ftrl_update``, ``compact_ftrl_state``, plus path / disable
  helpers.
* From ``concinno.ziq.retrieval``: ``ZIQRetrieval``, ``SourceState``,
  ``ThresholdState``, the SPS protocol + SPPMI prior, and tuning
  constants.
* From ``concinno.ziq.autotuner``: ``ZIQAutoTuner``, ``TargetKind``,
  ``AutoTuneRegime``, ``AutoTuneObservation``,
  ``is_autotune_enabled``.
* From ``concinno.ziq.autotune_loop``: ``ZIQAutoTuneLoop``,
  ``AuditEntry``, ``significant_delta``.
* From ``concinno.ziq.autotune_registry``: ``TunableSpec``,
  ``TUNABLE_REGISTRY``, ``register``, ``list_targets``, ``describe``,
  ``get_tuner``, ``clear_cache``.
* From ``concinno.ziq.outcome_bus``: ``ZIQOutcomeBus``, ``Outcome``,
  ``get_bus``, ``emit``, ``is_bus_disabled``.
* From ``concinno.ziq.emit_helpers``: ``emit_threshold_outcome``,
  ``emit_iteration_outcome``, ``emit_budget_outcome``,
  ``emit_classification_outcome``, ``emit_boolean_outcome``,
  ``emit_continuous_outcome``.
* From ``concinno.ziq.memory_adapter``: ``register_memory_noise_filter``,
  ``is_memory_skills_available``, ``NOISE_FILTER_OUTCOME_NAME``.
* From ``concinno.ziq.hook_ignore_rate``: ``record_emit``,
  ``record_user_accept_signal``, ``hook_accept_rate``,
  ``pending_emits``, ``sync_outcome_to_bus``, ``ftrl_state_path``.
"""

from aiking_core.ziq.autotune_loop import (  # noqa: F401
    AuditEntry,
    ZIQAutoTuneLoop,
    significant_delta,
)
from aiking_core.ziq.autotune_registry import (  # noqa: F401
    TUNABLE_REGISTRY,
    TunableSpec,
    clear_cache,
    describe,
    get_tuner,
    list_targets,
    register,
)
from aiking_core.ziq.autotuner import (  # noqa: F401
    AutoTuneObservation,
    AutoTuneRegime,
    TargetKind,
    ZIQAutoTuner,
    is_autotune_enabled,
)
from aiking_core.ziq.emit_helpers import (  # noqa: F401
    emit_boolean_outcome,
    emit_budget_outcome,
    emit_classification_outcome,
    emit_continuous_outcome,
    emit_iteration_outcome,
    emit_threshold_outcome,
)
from aiking_core.ziq.hook_ignore_rate import (  # noqa: F401
    NAMESPACE as HOOK_IGNORE_NAMESPACE,
)
from aiking_core.ziq.hook_ignore_rate import (
    ftrl_state_path,
    hook_accept_rate,
    pending_emits,
    record_emit,
    record_user_accept_signal,
    sync_outcome_to_bus,
)
from aiking_core.ziq.memory_adapter import (  # noqa: F401
    NOISE_FILTER_OUTCOME_NAME,
    is_memory_skills_available,
    register_memory_noise_filter,
)
from aiking_core.ziq.outcome_bus import (  # noqa: F401
    Outcome,
    ZIQOutcomeBus,
    emit,
    get_bus,
    is_bus_disabled,
)
from aiking_core.ziq.persist import (  # noqa: F401
    compact_ftrl_state,
    jsonl_path,
    load_ftrl_state,
    record_ftrl_update,
    snapshot_path,
    state_dir,
)
from aiking_core.ziq.retrieval import (  # noqa: F401
    ALL_NS,
    DEFAULT_HIGH_THRESHOLD,
    DEFAULT_LOW_THRESHOLD,
    DEFAULT_LR,
    DEFAULT_SPPMI_SHIFT_K,
    SOURCE_TYPES,
    THRESHOLD_HIGH_MAX,
    THRESHOLD_HIGH_MIN,
    THRESHOLD_LR,
    THRESHOLD_MAX,
    THRESHOLD_MIN,
    WEIGHT_MAX,
    WEIGHT_MIN,
    RetrieverConfidenceSPS,
    SourceState,
    SPPMIPrior,
    SPSProtocol,
    ThresholdState,
    ZIQRetrieval,
    record_feedback,
    rerank_results,
)
from aiking_core.ziq.router import (  # noqa: F401
    ALPHA_COMPLEX_MAX,
    ALPHA_COMPLICATED_MAX,
    ALPHA_SIMPLE_MAX,
    RoutingDecision,
    Tier,
    ZIQFeatureRouter,
)

__all__ = [
    # router
    "ALPHA_COMPLEX_MAX",
    "ALPHA_COMPLICATED_MAX",
    "ALPHA_SIMPLE_MAX",
    "RoutingDecision",
    "Tier",
    "ZIQFeatureRouter",
    # persist
    "compact_ftrl_state",
    "jsonl_path",
    "load_ftrl_state",
    "record_ftrl_update",
    "snapshot_path",
    "state_dir",
    # retrieval
    "ALL_NS",
    "DEFAULT_HIGH_THRESHOLD",
    "DEFAULT_LOW_THRESHOLD",
    "DEFAULT_LR",
    "DEFAULT_SPPMI_SHIFT_K",
    "RetrieverConfidenceSPS",
    "SOURCE_TYPES",
    "SPPMIPrior",
    "SPSProtocol",
    "SourceState",
    "THRESHOLD_HIGH_MAX",
    "THRESHOLD_HIGH_MIN",
    "THRESHOLD_LR",
    "THRESHOLD_MAX",
    "THRESHOLD_MIN",
    "ThresholdState",
    "WEIGHT_MAX",
    "WEIGHT_MIN",
    "ZIQRetrieval",
    "record_feedback",
    "rerank_results",
    # autotuner
    "AutoTuneObservation",
    "AutoTuneRegime",
    "TargetKind",
    "ZIQAutoTuner",
    "is_autotune_enabled",
    # autotune_loop
    "AuditEntry",
    "ZIQAutoTuneLoop",
    "significant_delta",
    # autotune_registry
    "TUNABLE_REGISTRY",
    "TunableSpec",
    "clear_cache",
    "describe",
    "get_tuner",
    "list_targets",
    "register",
    # outcome_bus
    "Outcome",
    "ZIQOutcomeBus",
    "emit",
    "get_bus",
    "is_bus_disabled",
    # emit_helpers
    "emit_boolean_outcome",
    "emit_budget_outcome",
    "emit_classification_outcome",
    "emit_continuous_outcome",
    "emit_iteration_outcome",
    "emit_threshold_outcome",
    # memory_adapter
    "NOISE_FILTER_OUTCOME_NAME",
    "is_memory_skills_available",
    "register_memory_noise_filter",
    # hook_ignore_rate
    "HOOK_IGNORE_NAMESPACE",
    "ftrl_state_path",
    "hook_accept_rate",
    "pending_emits",
    "record_emit",
    "record_user_accept_signal",
    "sync_outcome_to_bus",
]


def get_engine(*args, **kwargs):
    """Late-binding entry-point. Returns this module for now;
    aiking shell uses this for capability detection. May evolve into
    a proper engine factory in 1.1.0+.
    """
    import sys
    return sys.modules[__name__]
