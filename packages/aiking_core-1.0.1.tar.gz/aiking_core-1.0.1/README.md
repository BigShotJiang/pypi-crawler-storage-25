# aiking-core

The substantive engine of the [AI King](https://pypi.org/project/aiking/)
distribution. Wires together the governance stack (Concinno guards +
Sancio runtime), ZIQ retrieval, FieldRead memory, PSYCHE chat-completion
gateway, and the Cerno 7-step mother-agent cycle.

## Install

    pip install aiking-core            # base engine
    pip install "aiking-core[body]"    # adds persona-api adapters (see caveat)

You normally do not install `aiking-core` directly — `pip install aiking`
pulls it transitively and exposes the curated public surface.

## Entry points (group `aiking.core_engine`)

    ziq        = aiking_core.ziq:get_engine
    fieldread  = aiking_core.fieldread:get_engine
    cerno      = aiking_core.cerno:get_engine

The `aiking` shell discovers these via `importlib.metadata` rather than
direct imports, preserving the Apache-2.0 / AGPL boundary.

## License

Dual-licensed:

- **AGPL-3.0-or-later** with §7 Additional Terms — see [`LICENSE`](./LICENSE).
- **Commercial license** for entities that cannot or will not comply with
  AGPL §13 (network-use / SaaS clause), or whose policy bans AGPL-licensed
  dependencies — see [`COMMERCIAL_LICENSE.md`](./COMMERCIAL_LICENSE.md).

If you are not sure which applies, the AGPL terms govern by default.

## Migration window (1.0.x)

`aiking_core.ziq.retrieval` imports `concinno.core.state_store.StateStore`,
and several governance / hooks submodules import from `concinno.*` and
`persona.*` during the Phase 2 migration. The relevant `concinno>=5.3.0`
dep is declared automatically; `persona-api>=2.1.0` is opt-in via the
`[body]` extra because `persona-api 2.1.0` has an upstream
`from .engine import PersonaEngine` self-import bug. Wait for 2.1.1 if
you need the body-engine path.

## Source

<https://github.com/aiking931931/ai-king>
