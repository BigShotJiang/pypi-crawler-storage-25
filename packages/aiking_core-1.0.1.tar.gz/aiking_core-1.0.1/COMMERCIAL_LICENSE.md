# aiking-core Commercial License

aiking-core (the AI King engine, including the Concinno
governance stack, the Sancio runtime, and the Cerno 7-step
maternal-agent cycle) is dual-licensed under AGPL v3 and a
Commercial License.

## What aiking-core includes

| Layer | Concinno (upstream library) | aiking-core (this package)          |
|---|---|---|
| Hook guards / supervisor | yes | yes (consumed) |
| 55-guard pipeline | yes | yes (consumed) |
| **Cerno 7-step cycle** | no | **yes (sense / orient / guard-budget / think / act / verify / consolidate)** |
| Bearer-auth (JWT HS256) RCE-capable endpoints | no | yes |
| Per-user daily/monthly USD budget caps | no | yes |
| Tenant workspace sandbox | no | yes |
| GDPR Art 15/17 endpoints | no | yes |
| US-EAR geo-block middleware | no | yes |
| A2A (agent-to-agent) protocol | no | yes |
| `sancio gui` observability dashboard | no | yes |
| Tier-2 `sancio self-update` auto-update | no | yes |

The **Cerno cycle** is the differentiator. A Commercial License
for aiking-core includes the right to deploy Cerno in commercial
SaaS without AGPL §13 source-disclosure obligations.

## When You Need a Commercial License

You need a Commercial License if any of the following applies:

- You operate a commercial SaaS that calls aiking-core over a
  network and don't want to open-source your modifications under
  AGPL §13
- Your organization's policy bans AGPL-licensed dependencies
- You bundle aiking-core into a commercial product (OEM /
  embedded)
- You want priority support, custom features, or indemnification

## When You Don't Need a Commercial License

- Personal deployment (single-tenant, no commercial offering)
- Academic research / teaching
- Other AGPL-or-stronger open-source projects
- Internal tools that you fully open-source under AGPL

## Pricing Tiers (Hybrid Lite)

| Tier | Criteria | Price | Mode |
|---|---|---|---|
| **Startup** | < 50 employees, < $10M annual revenue | **$1,500 USD** | One-time perpetual + 1 yr free updates |
| **Growth** | 50-200 employees | **$4,500 USD / year** | Annual subscription with continuous updates |
| **Enterprise** | 200+ employees | Contact for quote | Custom |
| **OEM / Embedded** | Bundled with your product | Contact for quote | Custom |

Academic, personal, and open-source projects: **always free** under AGPL.

### Self-serve purchase (Startup tier)

[Buy Startup License — $1,500 USD] (Stripe Payment Link — to be set up)

### Growth tier subscription

[Subscribe — $4,500/yr] (Stripe Subscription — to be set up)

### Enterprise / OEM

Email <me@ai-king.dev> with subject `[aiking-core Commercial License
Inquiry] <your company name>` including:

- Company name and size (employees / revenue)
- Intended use case (Cerno deployment scenario)
- Estimated tenant / instance / RPS

We respond within 3 business days.

## What's Included

- Perpetual / annual royalty-free license to use aiking-core
  (including the Cerno 7-step cycle) commercially without AGPL §13
  obligations
- Commercial use of `sancio gui` and `sancio self-update`
- Email support (response within 5 business days)
- Quarterly version updates (Growth+ tiers continuous)

## Trademark

"AI King", "aiking", "aiking-core", "Concinno", "Sancio",
"Cerno", "ZIQ", "FieldRead", "PSYCHE", and "TACB" are trademarks of Chen Syuan Wang (王晨宣). The Commercial
License does not grant trademark rights — separate trademark
license required for co-marketing or branded forks.

## Copyright Holder

All aiking-core / Concinno / Sancio / Cerno copyright is held by **Chen Syuan
Wang (王晨宣)** as sole author. The Commercial License is granted
by the personal copyright holder. For acquisition or strategic
partnership discussions, contact <me@ai-king.dev>.

---

Last updated: 2026-05-02 (Phase 1 Foundation)
Copyright (C) 2026 Chen Syuan Wang. All rights reserved.
