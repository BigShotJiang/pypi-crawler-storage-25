"""AgentEval CLI — lightweight command-line interface for the SDK.

Phase 5 will add the full ``dashboard`` and ``traces`` sub-commands.
This module provides the entrypoint and base argument parsing.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional, Sequence

from .local_store import LocalStore


def _get_store(db_path: Optional[str] = None) -> LocalStore:
    return LocalStore(db_path)


def cmd_traces(args: argparse.Namespace) -> None:
    """Print recent local traces."""
    store = _get_store(args.db)
    rows = store.get_recent(limit=args.tail)
    if not rows:
        print("No local traces found.")
        return

    # Simple table output
    header = f"{'TRACE_ID':<40} {'AGENT':<20} {'STATUS':<12} {'LATENCY':<10} {'SYNCED':<8}"
    print(header)
    print("-" * len(header))
    for r in rows:
        print(
            f"{r.get('trace_id', ''):<40} "
            f"{r.get('agent_name', ''):<20} "
            f"{r.get('test_status', ''):<12} "
            f"{str(r.get('latency_ms', '')) + 'ms':<10} "
            f"{'yes' if r.get('synced') else 'no':<8}"
        )


def cmd_clear(args: argparse.Namespace) -> None:
    """Clear all local traces."""
    store = _get_store(args.db)
    deleted = store.clear()
    print(f"Cleared {deleted} local trace(s).")


def cmd_status(args: argparse.Namespace) -> None:
    """Show local store summary."""
    store = _get_store(args.db)
    total = store.count()
    synced = store.count(synced_only=True)
    print(f"DB path:   {store.path}")
    print(f"Total:     {total}")
    print(f"Synced:    {synced}")
    print(f"Pending:   {total - synced}")


def cmd_dashboard(args: argparse.Namespace) -> None:
    """Launch the local Flask dashboard."""
    from .dashboard import run as dashboard_run

    dashboard_run(
        db_path=args.db,
        port=args.port,
        open_browser=not args.no_browser,
    )


def main(argv: Optional[Sequence[str]] = None) -> None:
    parser = argparse.ArgumentParser(
        prog="agenteval",
        description="AgentEval SDK CLI — inspect and manage local traces",
    )
    parser.add_argument(
        "--db", default=None, help="Path to SQLite database (default: ~/.agenteval/traces.db)"
    )

    sub = parser.add_subparsers(dest="command")

    # traces
    p_traces = sub.add_parser("traces", help="List recent local traces")
    p_traces.add_argument("--tail", type=int, default=20, help="Number of traces to show")
    p_traces.set_defaults(func=cmd_traces)

    # clear
    p_clear = sub.add_parser("clear", help="Clear all local traces")
    p_clear.set_defaults(func=cmd_clear)

    # status
    p_status = sub.add_parser("status", help="Show local store summary")
    p_status.set_defaults(func=cmd_status)

    # dashboard
    p_dash = sub.add_parser("dashboard", help="Launch local dashboard")
    p_dash.add_argument("--port", type=int, default=8787, help="Port to run the dashboard on")
    p_dash.add_argument("--no-browser", action="store_true", help="Don't auto-open the browser")
    p_dash.set_defaults(func=cmd_dashboard)

    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
