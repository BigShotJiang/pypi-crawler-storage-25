"""SDK core with trace decorator, logging helpers, and AgentEvalClient."""

from __future__ import annotations

import json
import os
import re
import uuid
from contextvars import ContextVar
from datetime import datetime
from functools import wraps
from typing import Any, Callable, Dict, List, Optional

import requests

from .local_store import LocalStore

# ---------------------------------------------------------------------------
# Default endpoint
# ---------------------------------------------------------------------------
DEFAULT_URL = os.environ.get(
    "AGENTEVAL_API_URL", "https://sandbox.agenteval.in/trace"
)

# Validation pattern for project_id (alphanumeric, hyphens, underscores)
_PROJECT_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")

# ---------------------------------------------------------------------------
# OTel-style ContextVars — set by @trace, inherited by nested log_trace calls
# ---------------------------------------------------------------------------
current_trace_id: ContextVar[Optional[str]] = ContextVar("trace_id", default=None)
current_span_id: ContextVar[Optional[str]] = ContextVar("span_id", default=None)
current_parent_span_id: ContextVar[Optional[str]] = ContextVar("parent_span_id", default=None)
current_latency_threshold: ContextVar[Optional[int]] = ContextVar("latency_threshold", default=None)

# In-memory event log for debugging/tests
event_log: List[Dict[str, Any]] = []

# ---------------------------------------------------------------------------
# Lightweight client-side PII patterns
# ---------------------------------------------------------------------------
_PII_PATTERNS: Dict[str, re.Pattern] = {
    "EMAIL":       re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"),
    "PHONE":       re.compile(r"\b[\+]?[\d\s\-\(\)]{7,15}\d\b"),
    "SSN":         re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "IBAN":        re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}([A-Z0-9]?){0,16}\b"),
    "ACCOUNT_ID":  re.compile(r"\b(ACC|ACCT|account)[-_]?\d{4,12}\b", re.IGNORECASE),
    "PASSPORT":    re.compile(r"\b[A-Z]{1,2}[0-9]{6,9}\b"),
    "CREDIT_CARD": re.compile(r"\b(?:\d[ \-]?){13,16}\b"),
}


def _scan_pii(text: str) -> tuple:
    """Lightweight regex PII scan. Returns (has_pii: bool, detected_types: List[str])."""
    detected = [label for label, pattern in _PII_PATTERNS.items() if pattern.search(text or "")]
    return bool(detected), detected


def _log_event(
    event: str,
    *,
    trace_id: str,
    span_id: str,
    parent_span_id: Optional[str],
    name: str,
    result: Any = None,
    error: Optional[str] = None,
) -> None:
    payload = {
        "event": event,
        "trace_id": trace_id,
        "span_id": span_id,
        "parent_span_id": parent_span_id,
        "name": name,
        "timestamp": datetime.utcnow().isoformat(),
    }
    if result is not None:
        try:
            payload["result"] = json.dumps(result)
        except Exception:
            payload["result"] = str(result)
    if error is not None:
        payload["error"] = error
    event_log.append(payload)
    print(payload)


# ---------------------------------------------------------------------------
# @trace decorator — OTel span hierarchy, supports all 3 call styles
# ---------------------------------------------------------------------------
def trace(
    _func: Optional[Callable] = None,
    *,
    name: Optional[str] = None,
    latency_threshold: Optional[int] = None,
) -> Any:
    """Decorator that auto-wires OTel-style span hierarchy.

    Supports three call styles::

        @trace
        def my_agent(x): ...

        @trace(name="KYC")
        def my_agent(x): ...

        @trace(name="KYC", latency_threshold=3000)
        def my_agent(x): ...

    Sets ``current_span_id`` and ``current_parent_span_id`` in ContextVars so
    nested ``log_trace()`` calls inherit the correct hierarchy automatically.
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        agent_name = name or func.__name__

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            parent_trace = current_trace_id.get()
            parent_span = current_span_id.get()

            new_trace_id = parent_trace or str(uuid.uuid4())
            new_span_id = str(uuid.uuid4())
            new_parent_span_id = parent_span  # previous span is our parent

            # Inherit or override latency threshold
            effective_threshold = latency_threshold or current_latency_threshold.get()

            tok_trace = current_trace_id.set(new_trace_id)
            tok_span = current_span_id.set(new_span_id)
            tok_parent = current_parent_span_id.set(new_parent_span_id)
            tok_thresh = current_latency_threshold.set(effective_threshold)

            try:
                _log_event("start", trace_id=new_trace_id, span_id=new_span_id,
                           parent_span_id=new_parent_span_id, name=agent_name)
                result = func(*args, **kwargs)
                _log_event("end", trace_id=new_trace_id, span_id=new_span_id,
                           parent_span_id=new_parent_span_id, name=agent_name, result=result)
                return result
            except Exception as exc:  # noqa: BLE001
                _log_event("end", trace_id=new_trace_id, span_id=new_span_id,
                           parent_span_id=new_parent_span_id, name=agent_name, error=str(exc))
                raise
            finally:
                current_span_id.reset(tok_span)
                current_trace_id.reset(tok_trace)
                current_parent_span_id.reset(tok_parent)
                current_latency_threshold.reset(tok_thresh)

        return wrapper

    if _func is not None:
        return decorator(_func)
    return decorator


# ---------------------------------------------------------------------------
# AgentEvalClient — primary high-level interface
# ---------------------------------------------------------------------------
class AgentEvalClient:
    """High-level SDK client: local-first, fail-safe trace logging.

    Every call to :meth:`log_trace` first writes the trace to a local
    SQLite store so data is *never* lost, then attempts to POST it to the
    central ingestion endpoint.  Network failures are silently swallowed —
    unsynced traces can be flushed later with :meth:`flush`.

    Usage::

        client = AgentEvalClient(api_key="pk_live_...")
        client.log_trace(
            agent_name="KYC_Agent",
            input_text="Check customer 12345",
            output_text="Risk: LOW",
            latency_ms=340,
            tokens_used=180,
            status="pass",
        )
    """

    def __init__(
        self,
        api_key: str,
        project_id: str = "default",
        endpoint: Optional[str] = None,
        db_path: Optional[str] = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self._validate_project_id(project_id)

        self._api_key = api_key
        self._project_id = project_id
        self._endpoint = endpoint or os.environ.get("AGENTEVAL_API_URL") or DEFAULT_URL
        self._store = LocalStore(db_path)

    @staticmethod
    def _validate_project_id(project_id: str) -> None:
        if not _PROJECT_ID_RE.match(project_id):
            raise ValueError(
                f"Invalid project_id '{project_id}'. "
                "Must be 1-64 chars of [a-zA-Z0-9_-]."
            )

    def log_trace(
        self,
        agent_name: str,
        input_text: str,
        output_text: str,
        latency_ms: int,
        tokens_used: int,
        status: str = "NEW",
        error: str = "",
        trace_id: Optional[str] = None,
        session_id: str = "",
        # OTel span fields — auto-populated from @trace ContextVars if not set
        span_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        latency_threshold: Optional[int] = None,
        # PII
        pii_types: Optional[List[str]] = None,
        pii_scan: bool = False,
    ) -> str:
        """Log a trace locally and attempt to sync it to the central endpoint.

        Returns the trace_id (auto-generated if not provided).
        """
        trace_id = trace_id or current_trace_id.get() or str(uuid.uuid4())

        _span_id = span_id or current_span_id.get() or str(uuid.uuid4())
        _parent_span_id = parent_span_id if parent_span_id is not None else (current_parent_span_id.get() or "")
        _latency_threshold = latency_threshold if latency_threshold is not None else current_latency_threshold.get()

        _pii_types: List[str] = pii_types or []
        _has_pii = bool(_pii_types)
        if pii_scan and not _pii_types:
            _has_pii, _pii_types = _scan_pii(f"{input_text} {output_text}")

        payload = {
            "timestamp": datetime.utcnow().isoformat(),
            "trace_id": trace_id,
            "agent_name": agent_name,
            "agent_input": input_text,
            "agent_output": output_text,
            "latency_ms": latency_ms,
            "tokens_used": tokens_used,
            "test_status": status,
            "error_message": error or "",
            "project_id": self._project_id,
            "session_id": session_id,
            "span_id": _span_id,
            "parent_span_id": _parent_span_id,
            "latency_threshold": _latency_threshold,
            "client_has_pii": _has_pii,
            "client_pii_types": _pii_types,
        }

        rowid = self._store.save(payload)

        try:
            resp = requests.post(
                self._endpoint,
                json=payload,
                headers={
                    "Content-Type": "application/json",
                    "X-AgentEval-API-Key": self._api_key,
                },
                timeout=2.0,
            )
            resp.raise_for_status()
            self._store.mark_synced(rowid)
        except requests.exceptions.RequestException:
            pass  # trace safe in local SQLite

        return trace_id

    def flush(self, batch_size: int = 50) -> int:
        """Push unsynced local traces to the remote endpoint.

        Returns the number of traces successfully synced.
        """
        synced = 0
        unsynced = self._store.get_unsynced(limit=batch_size)
        for row in unsynced:
            payload = {
                "timestamp": row.get("created_at", datetime.utcnow().isoformat()),
                "trace_id": row["trace_id"],
                "agent_name": row.get("agent_name", ""),
                "agent_input": row.get("agent_input", ""),
                "agent_output": row.get("agent_output", ""),
                "latency_ms": row.get("latency_ms", 0),
                "tokens_used": row.get("tokens_used", 0),
                "test_status": row.get("test_status", "NEW"),
                "error_message": row.get("error_message", ""),
                "project_id": row.get("project_id", self._project_id),
                "session_id": row.get("session_id", ""),
                "span_id": row.get("span_id", ""),
                "parent_span_id": row.get("parent_span_id", ""),
                "latency_threshold": row.get("latency_threshold"),
                "client_has_pii": row.get("client_has_pii", False),
                "client_pii_types": row.get("client_pii_types", []),
            }
            try:
                resp = requests.post(
                    self._endpoint,
                    json=payload,
                    headers={
                        "Content-Type": "application/json",
                        "X-AgentEval-API-Key": self._api_key,
                    },
                    timeout=2.0,
                )
                resp.raise_for_status()
                self._store.mark_synced(row["id"])
                synced += 1
            except requests.exceptions.RequestException:
                break
        return synced

    @property
    def store(self) -> LocalStore:
        """Access the underlying :class:`LocalStore`."""
        return self._store

    @property
    def project_id(self) -> str:
        return self._project_id

    @property
    def endpoint(self) -> str:
        return self._endpoint


# ---------------------------------------------------------------------------
# Standalone log_trace — backward compatible with v0.1/v0.2
# ---------------------------------------------------------------------------
def log_trace(
    trace_id: str,
    input_text: str,
    output_text: str,
    latency_ms: int,
    tokens_used: int,
    status: str,
    error: str = "",
    url: Optional[str] = None,
    api_key: Optional[str] = None,
    agent_name: str = "",
    session_id: str = "",
    project_id: str = "default",
    # OTel span hierarchy — auto-populated from @trace ContextVars if not set
    span_id: Optional[str] = None,
    parent_span_id: Optional[str] = None,
    latency_threshold: Optional[int] = None,
    # PII
    pii_types: Optional[List[str]] = None,
    pii_scan: bool = False,
) -> bool:
    """Send a trace record to the ingestion API.

    Span hierarchy is automatically populated from :data:`current_span_id` and
    :data:`current_parent_span_id` ContextVars set by the ``@trace`` decorator,
    so multi-agent code works without any manual wiring.
    """
    target_url = url or os.environ.get("AGENTEVAL_API_URL") or DEFAULT_URL

    _span_id = span_id or current_span_id.get() or str(uuid.uuid4())
    _parent_span_id = parent_span_id if parent_span_id is not None else (current_parent_span_id.get() or "")
    _latency_threshold = latency_threshold if latency_threshold is not None else current_latency_threshold.get()

    _pii_types: List[str] = pii_types or []
    _has_pii = bool(_pii_types)
    if pii_scan and not _pii_types:
        _has_pii, _pii_types = _scan_pii(f"{input_text} {output_text}")

    payload = {
        "timestamp": datetime.utcnow().isoformat(),
        "trace_id": trace_id,
        "agent_name": agent_name,
        "agent_input": input_text,
        "agent_output": output_text,
        "project_id": project_id,
        "session_id": session_id,
        "latency_ms": latency_ms,
        "tokens_used": tokens_used,
        "test_status": status,
        "error_message": error or "",
        "span_id": _span_id,
        "parent_span_id": _parent_span_id,
        "latency_threshold": _latency_threshold,
        "client_has_pii": _has_pii,
        "client_pii_types": _pii_types,
    }

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["X-AgentEval-API-Key"] = api_key
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        resp = requests.post(target_url, json=payload, headers=headers, timeout=5)
        resp.raise_for_status()
        return True
    except requests.RequestException as exc:
        print(f"Failed to send trace {trace_id}: {exc}")
        return False


__all__ = [
    "AgentEvalClient",
    "LocalStore",
    "trace",
    "log_trace",
    "event_log",
    "current_trace_id",
    "current_span_id",
    "current_parent_span_id",
    "current_latency_threshold",
]
