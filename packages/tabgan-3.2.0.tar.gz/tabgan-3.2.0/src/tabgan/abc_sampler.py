import gc
import logging
import time
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple
from .utils import seed_everything
import pandas as pd

__author__ = "Insaf Ashrapov"
__copyright__ = "Insaf Ashrapov"
__license__ = "Apache 2.0"


class SampleData(ABC):
    """
        Factory method for different sampler strategies. The goal is to generate more train data
        which should be more close to test, in other word we're trying to fix uneven distribution.
    """

    @abstractmethod
    def get_object_generator(self):
        """Getter for object sampler aka generator, which is not a generator"""
        raise NotImplementedError

    def generate_data_pipe(
        self,
        train_df: pd.DataFrame,
        target: pd.DataFrame,
        test_df: pd.DataFrame,
        deep_copy: bool = True,
        only_adversarial: bool = False,
        use_adversarial: bool = True,
        only_generated_data: bool = False,
        constraints: Optional[List] = None,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Defines logic for sampling
        @param train_df: Train dataframe which has separate target
        @param target: Input target for the train dataset
        @param test_df: Test dataframe - newly generated train dataframe should be close to it
        @param deep_copy: make copy of input files or not. If not input dataframes will be overridden
        @param only_adversarial: only adversarial fitering to train dataframe will be performed
        @param use_adversarial: perform or not adversarial filtering
        @param only_generated_data: After generation get only newly generated, without concating input train dataframe.
        Only works for SamplerGAN or ForestDiffusionGenerator.
        @param constraints: Optional list of Constraint instances to enforce on generated data.
        @return: Newly generated train dataframe and test data
        """
        seed_everything()
        _t_total_start = time.perf_counter()
        _timings: Dict[str, float] = {}
        generator = self.get_object_generator()
        _t_step = time.perf_counter()
        if deep_copy:
            logging.info("Preprocessing input data with deep copying input data.")
            if target is None or test_df is None:
                new_train = generator.preprocess_data_df(train_df.copy())
                new_target = None
            else:
                new_train, new_target, test_df = generator.preprocess_data(
                    train_df.copy(), target.copy(), test_df
                )
        else:
            logging.info("Preprocessing input data without deep copying.")
            new_train, new_target, test_df = generator.preprocess_data(
                train_df, target, test_df
            )
        _timings["preprocess"] = time.perf_counter() - _t_step

        if only_adversarial and use_adversarial:
            logging.info("Applying adversarial filtering")
            _t_step = time.perf_counter()
            result = generator.adversarial_filtering(new_train, new_target, test_df)
            _timings["adversarial_filtering"] = time.perf_counter() - _t_step
            _timings["total"] = time.perf_counter() - _t_total_start
            self.last_timing_ = _timings
            logging.info("Timing: %s", self._format_timing(_timings))
            return result
        else:
            logging.info("Starting generation step.")
            _t_step = time.perf_counter()
            new_train, new_target = generator.generate_data(
                new_train, new_target, test_df, only_generated_data
            )
            _timings["generation"] = time.perf_counter() - _t_step

            logging.info("Starting postprocessing step.")
            _t_step = time.perf_counter()
            new_train, new_target = generator.postprocess_data(
                new_train, new_target, test_df
            )
            _timings["postprocess"] = time.perf_counter() - _t_step

            if use_adversarial:
                logging.info("Applying adversarial filtering")
                _t_step = time.perf_counter()
                new_train, new_target = generator.adversarial_filtering(
                    new_train, new_target, test_df
                )
                _timings["adversarial_filtering"] = time.perf_counter() - _t_step

            if constraints:
                from .constraints import ConstraintEngine
                logging.info("Applying constraints")
                engine = ConstraintEngine(constraints, strategy="fix")
                # Temporarily attach target to keep rows aligned
                target_col = "__constraint_target__"
                if new_target is not None:
                    new_train[target_col] = new_target.values if hasattr(new_target, 'values') else new_target
                new_train = engine.apply(new_train)
                if new_target is not None:
                    new_target = new_train[target_col].reset_index(drop=True)
                    new_train = new_train.drop(columns=[target_col]).reset_index(drop=True)

            gc.collect()

            _timings["total"] = time.perf_counter() - _t_total_start
            self.last_timing_ = _timings
            logging.info("Timing: %s", self._format_timing(_timings))
            return new_train, new_target

    @staticmethod
    def _format_timing(timings: Dict[str, float]) -> str:
        parts = []
        for step, secs in timings.items():
            if secs < 1:
                parts.append(f"{step}={secs * 1000:.0f}ms")
            else:
                parts.append(f"{step}={secs:.1f}s")
        return " | ".join(parts)


class Sampler(ABC):
    """Interface for each sampling strategy.

    Concrete sampler implementations share a common configuration interface
    (generation factor, categorical columns, post-processing flags, etc.).
    This base ``__init__`` stores those shared parameters so that subclasses
    can call ``super().__init__(...)`` and focus on strategy-specific logic.
    """

    def __init__(
        self,
        gen_x_times: float,
        cat_cols: list | None,
        bot_filter_quantile: float,
        top_filter_quantile: float,
        is_post_process: bool,
        adversarial_model_params: dict,
        pregeneration_frac: float,
        only_generated_data: bool,
        gen_params: dict | None = None,
    ) -> None:
        self.gen_x_times = gen_x_times
        self.cat_cols = cat_cols
        self.bot_filter_quantile = bot_filter_quantile
        self.top_filter_quantile = top_filter_quantile
        self.is_post_process = is_post_process
        self.adversarial_model_params = adversarial_model_params
        self.pregeneration_frac = pregeneration_frac
        self.only_generated_data = only_generated_data
        self.gen_params = gen_params or {}

    def get_generated_shape(self, input_df):
        """Calculates final output shape"""
        if self.gen_x_times <= 0:
            raise ValueError(
                "Passed gen_x_times = {} should be bigger than 0".format(
                    self.gen_x_times
                )
            )
        return int(self.gen_x_times * input_df.shape[0])

    @abstractmethod
    def preprocess_data(self, train, target, test_df):
        """Before we can start data generation we might need some preprocessing, numpy to pandas
        and etc"""
        raise NotImplementedError

    @abstractmethod
    def generate_data(self, train_df, target, test_df):
        raise NotImplementedError

    @abstractmethod
    def postprocess_data(self, train_df, target, test_df):
        """Filtering data which far beyond from test_df data distribution"""
        raise NotImplementedError

    @abstractmethod
    def adversarial_filtering(self, train_df, target, test_df):
        raise NotImplementedError
