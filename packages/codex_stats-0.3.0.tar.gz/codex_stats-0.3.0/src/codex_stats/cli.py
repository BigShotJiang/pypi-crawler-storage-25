from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .config import Paths
from .display import (
    as_json,
    format_breakdown,
    format_costs,
    format_history,
    format_insights,
    format_session,
    format_summary,
    resolve_format_options,
)
from .ingest import get_session, get_session_details
from .metrics import (
    details_for_last_days,
    summarize_imported_details,
    summarize_last_days,
    summarize_costs,
    summarize_costs_from_details,
    summarize_history,
    summarize_history_from_details,
    summarize_insights,
    summarize_insights_from_details,
    summarize_models,
    summarize_models_from_details,
    summarize_month,
    summarize_projects,
    summarize_projects_from_details,
    summarize_today,
    summarize_week,
)
from .transfer import read_import, write_export


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="codex-stats", description="Local usage analytics for Codex.")
    parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")
    parser.add_argument("--days", type=int, help="Show a rolling summary for the last N days.")
    parser.add_argument(
        "--color",
        choices=["auto", "always", "never"],
        default="auto",
        help="Control ANSI color output.",
    )
    subparsers = parser.add_subparsers(dest="command")

    today_parser = subparsers.add_parser("today", help="Show today's usage summary.")
    today_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")

    week_parser = subparsers.add_parser("week", help="Show the last 7 days of usage.")
    week_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")

    month_parser = subparsers.add_parser("month", help="Show the last 30 days of usage.")
    month_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")

    session_parser = subparsers.add_parser("session", help="Show a session summary.")
    session_parser.add_argument("--id", dest="session_id", help="Specific session ID.")
    session_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")

    models_parser = subparsers.add_parser("models", help="Show usage by model.")
    models_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")

    project_parser = subparsers.add_parser("project", help="Show usage by project.")
    project_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")

    history_parser = subparsers.add_parser("history", help="Show recent session history.")
    history_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")
    history_parser.add_argument("--limit", type=int, default=10, help="Maximum sessions to show.")

    costs_parser = subparsers.add_parser("costs", help="Show estimated cost breakdown.")
    costs_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")
    costs_parser.add_argument("--days", type=int, help="Use the last N days for the projection basis.")

    insights_parser = subparsers.add_parser("insights", help="Show usage insights.")
    insights_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")
    insights_parser.add_argument("--days", type=int, help="Analyze the last N days.")

    export_parser = subparsers.add_parser("export", help="Export normalized local stats to JSON.")
    export_parser.add_argument("output", help="Output JSON file.")

    import_parser = subparsers.add_parser("import", help="Read an exported stats JSON file.")
    import_parser.add_argument("input", help="Input JSON file.")
    import_parser.add_argument("--json", action="store_true", dest="json_output", help="Output JSON.")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    paths = Paths.discover()
    options = resolve_format_options(args.color)

    if args.command in (None, "today"):
        summary = summarize_last_days(paths, args.days) if args.days else summarize_today(paths)
        if args.json_output:
            print(as_json(summary.to_dict()))
        else:
            print(format_summary(summary, options))
        return 0

    if args.command == "week":
        summary = summarize_week(paths)
        if args.json_output:
            print(as_json(summary.to_dict()))
        else:
            print(format_summary(summary, options))
        return 0

    if args.command == "month":
        summary = summarize_month(paths)
        if args.json_output:
            print(as_json(summary.to_dict()))
        else:
            print(format_summary(summary, options))
        return 0

    if args.command == "session":
        session = get_session(paths, session_id=args.session_id)
        if session is None:
            print("No Codex session found.", file=sys.stderr)
            return 1
        details = get_session_details(paths, session)
        if args.json_output:
            print(as_json(details.to_dict()))
        else:
            print(format_session(details, options))
        return 0

    if args.command == "models":
        entries = summarize_models(paths)
        if args.json_output:
            print(as_json({"models": [entry.to_dict() for entry in entries]}))
        else:
            print(format_breakdown("Model Usage", entries, options))
        return 0

    if args.command == "project":
        entries = summarize_projects(paths)
        if args.json_output:
            print(as_json({"projects": [entry.to_dict() for entry in entries]}))
        else:
            print(format_breakdown("Project Usage", entries, options))
        return 0

    if args.command == "history":
        entries = summarize_history(paths, limit=args.limit)
        if args.json_output:
            print(as_json({"history": [entry.to_dict() for entry in entries]}))
        else:
            print(format_history(entries, options))
        return 0

    if args.command == "costs":
        if args.days:
            details = details_for_last_days(paths, args.days)
            summary = summarize_details_for_range(args.days, details)
            costs = summarize_costs_from_details(details, today=summary, week=summary, month=summary)
        else:
            costs = summarize_costs(paths)
        if args.json_output:
            print(as_json(costs.to_dict()))
        else:
            print(format_costs(costs, options))
        return 0

    if args.command == "insights":
        if args.days:
            details = details_for_last_days(paths, args.days)
            summary = summarize_details_for_range(args.days, details)
            insights = summarize_insights_from_details(details, month=summary)
        else:
            insights = summarize_insights(paths)
        if args.json_output:
            print(as_json(insights.to_dict()))
        else:
            print(format_insights(insights, options))
        return 0

    if args.command == "export":
        output_path = write_export(paths, Path(args.output).expanduser())
        print(f"Exported stats to {output_path}")
        return 0

    if args.command == "import":
        details = read_import(Path(args.input).expanduser())
        summary = summarize_imported_details(details)
        if args.json_output:
            print(
                as_json(
                    {
                        "summary": summary.to_dict(),
                        "models": [entry.to_dict() for entry in summarize_models_from_details(details)],
                        "projects": [entry.to_dict() for entry in summarize_projects_from_details(details)],
                        "history": [entry.to_dict() for entry in summarize_history_from_details(details)],
                        "costs": summarize_costs_from_details(details).to_dict(),
                        "insights": summarize_insights_from_details(details).to_dict(),
                    }
                )
            )
        else:
            print(format_summary(summary, options))
        return 0

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())


def summarize_details_for_range(days: int, details):
    return summarize_imported_details(details, label=f"last {max(days, 1)} days")
