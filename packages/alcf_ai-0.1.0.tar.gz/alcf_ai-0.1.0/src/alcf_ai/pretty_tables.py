from rich.console import Console
from rich.table import Table
from rich import print
from typing import Any
import re


def format_walltime(wt: str | None) -> str:
    if not wt:
        return "NA"

    h, m, s = map(int, wt.split(":"))
    days, hours = divmod(h, 24)
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if m:
        parts.append(f"{m}m")
    return " ".join(parts) or f"{s}s"


def short_job_id(jid: str) -> str:
    return jid.split(".")[0]


def parse_host(host: str) -> str:
    return host.split("/")[0]


def parse_gpus(comments: str) -> str:
    m = re.search(r"ngpus=(\d+)", comments)
    return m.group(1) if m else "?"


def render_cluster_jobs(name: str, data: dict[str, Any]) -> None:
    console = Console(width=120)
    console.print(f"{name} status:", data["cluster_status"])

    for key in ("running", "queued", "stopped"):
        jobs = data[key]
        if not jobs:
            console.print(f"No jobs in {key} state.")
            continue

        table = Table(
            title=f"{key.capitalize()} Models",
            title_style="bold cyan",
            border_style="dim",
            show_lines=True,
            pad_edge=False,
            expand=False,
        )
        table.add_column("Job", style="dim", width=7, justify="right")
        table.add_column("Model(s)", style="bold white", max_width=48)
        table.add_column("Host", style="cyan", width=15)
        table.add_column("GPUs", justify="center", width=5)
        table.add_column("Uptime", style="green", justify="right", width=12)

        for job in jobs:
            models = job["Models"].replace(",", "\n")
            uptime = format_walltime(job.get("Walltime"))
            table.add_row(
                short_job_id(job.get("Job ID", "NA")),
                models,
                parse_host(job.get("Host Name", "NA")),
                parse_gpus(job.get("Job Comments", "NA")),
                uptime,
            )

        console.print(table)
        console.print()
