from httpx import Client, Auth, Request, Timeout
from typing import Any
from .auth import get_authorizer
from .resources import ClusterResource

class AutoGlobusAuth(Auth):
    def auth_flow(self, request: Request):
        auth = get_authorizer(force=False)
        auth.ensure_valid_token()
        assert auth.access_token, "Empty access token"

        request.headers['Authorization'] = f"Bearer {auth.access_token}"
        yield request


class InferenceClient(Client):

    def __init__(
        self, 
        base_url: str = "https://inference-api.alcf.anl.gov/resource_server/", 
        timeout: Timeout = Timeout(10.0, read=30.0),
    ) -> None:
        super().__init__(
            auth=AutoGlobusAuth(),
            base_url=base_url,
            timeout=timeout,
        )
        self._resources = {}

    def __repr__(self) -> str:
        return f"InferenceClient({self.base_url})"

    def clusters(self, name: str) -> "ClusterResource":
        key = f"cluster:{name}"
        return self._resources.setdefault(key, ClusterResource(name, self))

    def list_endpoints(self) -> dict[str, Any]:
        resp = self.get("list-endpoints")
        resp.raise_for_status()
        return resp.json()
