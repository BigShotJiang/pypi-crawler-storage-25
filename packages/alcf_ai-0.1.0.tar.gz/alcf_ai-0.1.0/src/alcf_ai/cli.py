import typer
from typer import Typer
from .auth import cli as auth_cli
from typer import Typer, Option
from typing import Annotated, TypedDict
from rich.console import Console
from .client import InferenceClient
from .pretty_tables import render_cluster_jobs
from rich import print
from rich.markdown import Markdown


console = Console()

class CliState(TypedDict, total=False):
    client: InferenceClient

cli = Typer(no_args_is_help=True)
_cli_state: CliState = {}

cli.add_typer(auth_cli, name="auth", help="Login and get access tokens")

@cli.callback()
def main(
    base_url: str = "https://inference-api.alcf.anl.gov/resource_server/",
) -> None:
    """
    Inference Gateway CLI
    """
    _cli_state["client"] = InferenceClient(base_url)

@cli.command()
def ls_endpoints() -> None:
    """
    List all endpoints available across clusters 
    """
    client = _cli_state["client"]
    print(client.list_endpoints())

@cli.command()
def ls_jobs(cluster: str) -> None:
    """
    List ongoing jobs for a cluster
    """
    client = _cli_state["client"]

    jobs = client.clusters(cluster).get_jobs()
    render_cluster_jobs(cluster, jobs)

@cli.command()
def chat(
    prompt: str = typer.Argument(..., help="The prompt to send"),
    model: str = typer.Option("meta-llama/Llama-4-Scout-17B-16E-Instruct", "--model", "-m"),
    stream: bool = typer.Option(True, "--stream/--no-stream", "-s/-S"),
    temperature: float = typer.Option(0.7, "--temp", "-t"),
    max_tokens: int = typer.Option(1024, "--max-tokens", "-n"),
    cluster: str = typer.Option("sophia", "--cluster", "-c"),
):
    """Send a prompt to an LLM and print the response."""
    client = _cli_state["client"]
    oai  = client.clusters(cluster).openai

    if stream:
        collected = []
        with console.status("[dim]Thinking…[/dim]", spinner="dots"):
            response = oai.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )

        for chunk in response:
            if chunk.choices and chunk.choices[0].delta.content:
                token = chunk.choices[0].delta.content
                console.print(token, end="", highlight=False)
                collected.append(token)

        console.print()  # final newline
    else:
        with console.status("[dim]Thinking…[/dim]", spinner="dots"):
            response = oai.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                max_tokens=max_tokens,
            )
        text = response.choices[0].message.content
        console.print(Markdown(text))

if __name__ == "__main__":
    cli()