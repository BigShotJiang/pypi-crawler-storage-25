import globus_sdk
from pathlib import Path
import sys
from globus_sdk.login_flows import LocalServerLoginFlowManager # Needed to access globus_sdk.gare
from globus_sdk.authorizers import GlobusAuthorizer
import time
from datetime import  timedelta
from enum import Enum
from typer import Typer

class InferenceAuthError(Exception):
    """
    Error during Inference authentication 
    """

class TimeUnit(str, Enum):
    auto = "auto"
    seconds = "seconds"
    minutes = "minutes"
    hours = "hours"

# Globus UserApp name
APP_NAME = "inference_app"

# Public inference auth client
AUTH_CLIENT_ID = "58fdd3bc-e1c3-4ce5-80ea-8d6b87cfb944"

# Inference gateway API scope
GATEWAY_CLIENT_ID = "681c10cc-f684-4540-bcd7-0b4df3bc26ef"
GATEWAY_SCOPE = f"https://auth.globus.org/scopes/{GATEWAY_CLIENT_ID}/action_all"

TOKENS_PATH = Path.home() / f".globus/app/{AUTH_CLIENT_ID}/{APP_NAME}/tokens.json"

# Globus authorizer parameters to point to specific identity providers
GA_PARAMS = globus_sdk.gare.GlobusAuthorizationParameters(session_required_policies=["83732ff2-9c42-4548-b5ce-17e498c84f6a"])


# Error handler to guide user through specific identity providers 
class DomainBasedErrorHandler:
    def __call__(self, app, error):
        print(f"Encountered error '{error}', initiating login...")
        app.login(auth_params=GA_PARAMS)


# Get refresh authorizer object
def get_authorizer(force: bool = False) -> GlobusAuthorizer:
    """
    Create a Globus UserApp with the inference service scope
    and trigger the authentication process. If authentication
    has already happened, existing tokens will be reused.
    """

    # Create Globus user application
    app = globus_sdk.UserApp(
        APP_NAME,
        client_id=AUTH_CLIENT_ID,
        scope_requirements={GATEWAY_CLIENT_ID: [GATEWAY_SCOPE]},
        config=globus_sdk.GlobusAppConfig(
            request_refresh_tokens=True,
            token_validation_error_handler=DomainBasedErrorHandler()
        ),
    )

    # Force re-login if required
    if force:
        app.login(auth_params=GA_PARAMS)

    # Authenticate using your Globus account or reuse existing tokens
    auth = app.get_authorizer(GATEWAY_CLIENT_ID)

    # Return the Globus refresh token authorizer
    return auth

def format_timedelta(td: timedelta, units: TimeUnit= TimeUnit.auto) -> str:
    total = td.total_seconds()
    if units == "seconds":
        return f"{total:.2f}"
    if units == "minutes":
        return f"{total / 60:.2f}"
    if units == "hours":
        return f"{total / 3600:.2f}"

    days, rem = divmod(int(total), 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    parts = []

    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if seconds or not parts:
        parts.append(f"{seconds}s")
    return " ".join(parts)

# Get time until token expiration
def get_time_until_token_expiration() -> timedelta:
    """
    Returns the time until the access token expires, in units of
    seconds, minutes, or hours. Negative times reveal that the token
    is expired already.
    """

    # Get authorizer object
    auth = get_authorizer(force=False)

    # Gather the time difference between now and the expiration time (both Unix timestamps)
    now = time.time()
    return timedelta(seconds=auth.expires_at - now)


cli = Typer(no_args_is_help=True)

@cli.command()
def login() -> None:
    """
    Log in with Globus. Stores credentials in your home directory.
    """
    get_authorizer(force=True)

@cli.command()
def get_access_token() -> None:
    """
    Fetch an access token for the inference API. 
    
    Automatically utilizes locally cached tokens, refreshing the access token if
    necessary, and returns a valid access token. If there is no token stored in
    the home directory, or if the refresh token is expired following 6 months of
    inactivity, an authentication will be triggered.
    """
    # Make sure tokens exist
    # This is important otherwise the CLI will print more than just the access token
    if not TOKENS_PATH.is_file():
        raise InferenceAuthError(
            'Access token does not exist. '
            f'Please authenticate by running "{sys.argv[0]} login".'
        )

    # Get authorizer object and authenticate if need be
    auth = get_authorizer(force=False)

    # Make sure the stored access token if valid, and refresh otherwise
    auth.ensure_valid_token()

    # Return the access token
    print(auth.access_token)

@cli.command()
def get_token_expiration(units: TimeUnit = TimeUnit.auto) -> None:
    """
    Show how much time remains until the token expires. 
    """
    # Make sure tokens exist
    # This is important otherwise the CLI will print more than just the access token
    if not TOKENS_PATH.is_file():
        raise InferenceAuthError('Access token does not exist. '
            'Please authenticate by running "python3 inference_auth_token.py authenticate".')
    
    print(format_timedelta(get_time_until_token_expiration(), units=units))