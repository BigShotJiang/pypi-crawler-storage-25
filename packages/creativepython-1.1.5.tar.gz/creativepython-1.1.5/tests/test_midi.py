#######################################################################################
# test_midi.py       Version 1.0     01-Apr-2026
# Taj Ballinger
#######################################################################################
#
# Tests MidiIn and MidiOut by sending notes through a MIDI loopback device at a
# fixed interval and confirming they are received by the MidiIn callback.
#
# Requires a MIDI loopback device. On macOS, enable the IAC Driver in
# Audio MIDI Setup (Applications > Utilities > Audio MIDI Setup > MIDI Studio).
#
#######################################################################################

import sys, time
sys.path.insert(0, '.')

from midi  import MidiIn, MidiOut, NOTE_ON, NOTE_OFF, ALL_EVENTS
from timer import Timer

##### Configuration ###################################################################

LOOPBACK_DEVICE = "IAC Driver Bus 1"   # change to match your system
BEAT_MS         = 50                  # ms between notes
NOTE_DURATION   = BEAT_MS // 2        # ms each note is held

NOTES = [60, 64, 67, 72]              # C4, E4, G4, C5

##### Setup ###########################################################################

midiOut = MidiOut(LOOPBACK_DEVICE)
midiIn  = MidiIn(LOOPBACK_DEVICE)
midiIn.hideMessages()                  # suppress default print; callback handles output

##### Callback ########################################################################

eventCount = [0]

def onMidiEvent(msgType, msgChannel, msgData1, msgData2):
   label = {NOTE_ON: "NOTE_ON", NOTE_OFF: "NOTE_OFF"}.get(msgType, f"type={msgType}")
   print(f"  Received  {label:8s}  pitch={msgData1}  velocity={msgData2}  ch={msgChannel}")
   eventCount[0] += 1

midiIn.onInput(ALL_EVENTS, onMidiEvent)

##### Note sender #####################################################################

noteIndex = [0]

def sendNextNote():
   pitch = NOTES[noteIndex[0]]
   print(f"Sending   NOTE_ON   pitch={pitch}")
   midiOut.noteOn(pitch)
   Timer(NOTE_DURATION, midiOut.noteOff, [pitch], False).start()
   noteIndex[0] = (noteIndex[0] + 1) % len(NOTES)

##### Run #############################################################################

beatTimer = Timer(BEAT_MS, sendNextNote, [], True)
beatTimer.start()

print(f"Loopback test running on '{LOOPBACK_DEVICE}' — one note every {BEAT_MS}ms.")
print("Press Ctrl+C to stop.\n")

try:
   while True:
      time.sleep(0.1)

except KeyboardInterrupt:
   beatTimer.stop()
   midiOut.allNotesOff()
   print(f"\nStopped. Total events received: {eventCount[0]}")
