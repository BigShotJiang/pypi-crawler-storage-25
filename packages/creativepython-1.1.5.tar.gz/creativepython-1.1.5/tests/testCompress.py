from music import *

### bP - Main Phrase
bP = Phrase(0.0)       # Arrange "bP" in time as header
#   Main's Melody (4 measures)
bSaxPitch1 = [D2, E2, REST, E2, REST, E2, REST, E2, REST]
bSaxDurat1 = [EN, EN, EN, EN, EN, EN, EN, EN, WN]
bP.addNoteList(bSaxPitch1, bSaxDurat1)

Mod.compress(bP, 8)

print(bP)