#######################################################################################
# test_osc.py       Version 1.0     01-Apr-2026
# Taj Ballinger
#######################################################################################
#
# Tests OscIn and OscOut by sending OSC messages to a local loopback server at a
# fixed interval and confirming they are received by the OscIn callback.
#
#######################################################################################

import sys, time
sys.path.insert(0, '.')

from osc   import OscIn, OscOut, ALL_MESSAGES
from timer import Timer

##### Configuration ###################################################################

LISTEN_PORT = 57110   # OscIn listens on this port; OscOut sends to the same port
BEAT_MS     = 500     # ms between messages

MESSAGES = [
   ("/note",    [60, 100]),
   ("/note",    [64, 80]),
   ("/control", [7, 127]),
   ("/note",    [67, 90]),
]

##### Setup ###########################################################################

oscIn  = OscIn(LISTEN_PORT)
oscOut = OscOut("localhost", LISTEN_PORT)
oscIn.hideMessages()   # suppress default print; callback handles output

##### Callback ########################################################################

eventCount = [0]

def onMessage(message):
   addr = message.getAddress()
   args = message.getArguments()
   print(f"  Received  {addr:12s}  args={args}")
   eventCount[0] += 1

oscIn.onInput(ALL_MESSAGES, onMessage)

##### Message sender ##################################################################

msgIndex = [0]

def sendNextMessage():
   addr, args = MESSAGES[msgIndex[0]]
   print(f"Sending   {addr:12s}  args={args}")
   oscOut.sendMessage(addr, *args)
   msgIndex[0] = (msgIndex[0] + 1) % len(MESSAGES)

##### Run #############################################################################

beatTimer = Timer(BEAT_MS, sendNextMessage, [], True)
beatTimer.start()

print(f"Loopback test running on port {LISTEN_PORT} — one message every {BEAT_MS}ms.")
print("Press Ctrl+C to stop.\n")

try:
   while True:
      time.sleep(0.1)

except KeyboardInterrupt:
   beatTimer.stop()
   print(f"\nStopped. Total events received: {eventCount[0]}")
