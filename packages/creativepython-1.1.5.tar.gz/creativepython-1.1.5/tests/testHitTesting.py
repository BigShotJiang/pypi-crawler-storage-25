# testHitTesting.py
#
# Tests hit-testing between two circles.
# A stationary circle sits in the center of the display; a second circle
# follows the mouse.  When they intersect, a message is printed to the console.

from gui import *

DISPLAY_WIDTH  = 600
DISPLAY_HEIGHT = 400
RADIUS         = 50

d = Display("Hit Testing", DISPLAY_WIDTH, DISPLAY_HEIGHT)

# stationary circle in the center of the display
center = Circle(DISPLAY_WIDTH // 2, DISPLAY_HEIGHT // 2, RADIUS, Color.BLUE, True)
d.add(center)

# circle that follows the mouse
cursor = Circle(0, 0, RADIUS, Color.RED, True)
d.add(cursor)

def onMouseMove(x, y):
   cursor.setCenter(x, y)
   if cursor.intersects(center):
      print(f"Intersection at ({x}, {y})!")

d.onMouseMove(onMouseMove)
