from gui import *

width = 600
height = 400

d = Display()
c = Circle(width/2, height/2, 50, fill=True)
d.add(c)

def printClick(x, y):
   print(f"Mouse Clicked at ({x}, {y})")

def printDown(x, y):
   print(f"Mouse Down at ({x}, {y})")

def printUp(x, y):
   print(f"Mouse Up at ({x}, {y})")

def printMove(x, y):
   print(f"Mouse Move at ({x}, {y})")

def printDrag(x, y):
   print(f"Mouse Drag at ({x}, {y})")

def printEnter(x, y):
   print(f"Mouse Enter at ({x}, {y})")

def printExit(x, y):
   print(f"Mouse Exit at ({x}, {y})")

def printKeyDown(key):
   print(f"Key Down ({key})")

def printKeyUp(key):
   print(f"Key Up ({key})")

def printKeyType(key):
   print(f"Key Type ({key})")

c.onMouseUp(printUp)
c.onMouseDown(printDown)
c.onMouseClick(printClick)
c.onMouseMove(printMove)
c.onMouseDrag(printDrag)
c.onMouseEnter(printEnter)
c.onMouseExit(printExit)
c.onKeyDown(printKeyDown)
c.onKeyUp(printKeyUp)
c.onKeyType(printKeyType)