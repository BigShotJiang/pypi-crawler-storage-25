#######################################################################################
# midi.py       Version 1.1     01-Apr-2026
# Trevor Ritchie, Taj Ballinger, and Bill Manaris
#######################################################################################
#
# [LICENSING GOES HERE]
#
# This module provides MIDI input and output device handling.
#
#######################################################################################

import mido                   # MIDI input/output and message handling
from timer import Timer       # for scheduling MIDI events
from music import freqToNote, mapValue, Note, Phrase, Part, Score, REST  # music data structures and utilities
import atexit                 # ensures cleanup of MIDI resources on program exit
import threading              # for MidiIn polling thread
import time                   # for polling sleep interval

##### Constants #######################################################################
# MIDI event type constants
ALL_EVENTS     = -1   # register a callback for all event types
NOTE_ON        = 144  # 0x90 - Note On
NOTE_OFF       = 128  # 0x80 - Note Off
SET_INSTRUMENT = 192  # 0xC0 - Program Change (set instrument)
CONTROL_CHANGE = 176  # 0xB0 - Control Change
PITCH_BEND     = 224  # 0xE0 - Pitch Bend
AFTERTOUCH     = 208  # 0xD0 - Aftertouch
POLYTOUCH      = 160  # 0xA0 - Polyphonic Aftertouch

# system common and real-time message type values
SYSTEM_MESSAGE_VALUES = {
   'system_reset':     255,   # 0xFF - System Reset
   'system_exclusive': 240,   # 0xF0 - System Exclusive
   'songpos':          242,   # 0xF2 - Song Position Pointer
   'songsel':          243,   # 0xF3 - Song Select
   'tune_request':     246    # 0xF6 - Tune Request
}

REALTIME_MESSAGE_VALUES = {
   'clock':    248,   # 0xF8 - Timing Clock
   'start':    250,   # 0xFA - Start
   'continue': 251,   # 0xFB - Continue
   'stop':     252    # 0xFC - Stop
}

# Pitch bend range: 0 = max downward, 16383 = max upward, 8192 = center (no bend).
PITCHBEND_MIN    = 0
PITCHBEND_MAX    = 16383
PITCHBEND_NORMAL = 8192

##### Globals #########################################################################
_activeMidiInObjects  = []   # tracks open MidiIn objects for cleanup
_activeMidiOutObjects = []   # tracks open MidiOut objects for cleanup

notesCurrentlyPlaying = []   # (pitch, channel) tuples; prevents early note-off for overlapping notes


#################### MidiIn ###########################################################
#
# Receives MIDI input from a connected device.
#
# Usage:
#   midiIn = MidiIn()
#
#   def onEvent(msgType, msgChannel, msgData1, msgData2):
#      print(msgType, msgChannel, msgData1, msgData2)
#
#   midiIn.onInput(ALL_EVENTS, onEvent)

class MidiIn:
   """Receives MIDI messages from a connected input device."""

   def __init__(self, preferredDevice=""):
      """Opens 'preferredDevice' for input, or shows a device-selection GUI if not found."""

      self.preferredDevice      = preferredDevice   # device to open automatically (if available)
      self.display              = None              # device-selection GUI (shown when needed)
      self.waitingToSetup       = True              # True until a device is selected
      self.midiDevice           = None              # selected MIDI device
      self.midiDeviceName       = None              # display name of selected device
      self.showIncomingMessages = True              # print incoming messages to console
      self.eventHandlers        = {}                # {eventType: [callbacks]}
      self._port                = None              # mido port object
      self._stopEvent           = threading.Event() # signals the polling thread to stop
      self._pollThread          = None              # background thread for polling MIDI input

      self.selectMidiInput(self.preferredDevice)


   def __str__(self):
      return f'MidiIn(preferredDevice = {self.preferredDevice})'


   def __repr__(self):
      return str(self)


   def selectMidiInput(self, preferredDevice=""):
      """
      Opens preferred MIDI device for input. If this device does not exist,
      creates display with available input MIDI devices and allows to select one.
      """
      self.preferredDevice = preferredDevice

      availablePorts = mido.get_input_names()
      self.inputDevices = {}

      for port in availablePorts:
         self.inputDevices[port] = port

      if self.preferredDevice in self.inputDevices:
         self.openInputDevice(self.preferredDevice)

      else:
         items = sorted(self.inputDevices.keys())

         if items:
            from gui import Display, DropDownList, Color

            self.display = Display("Select MIDI Input", 400, 125)
            self.display.drawLabel('Select a MIDI input device from the list', 45, 30)

            deviceDropdown = DropDownList(items, self.openInputDevice)
            self.display.add(deviceDropdown, 40, 50)
            self.display.setColor( Color(124, 201, 251) )

         else:
            print("MidiIn: No available MIDI input devices. Please connect a device.")


   def openInputDevice(self, selectedItem):
      """Opens the selected MIDI input device."""
      global _activeMidiInObjects

      try:
         print(f'MIDI input device set to "{selectedItem}".')
         deviceInfo = self.inputDevices[selectedItem]

         self.midiDeviceName = selectedItem
         self._port = mido.open_input(deviceInfo)
         self.waitingToSetup = False

         self._stopEvent.clear()
         self._pollThread = threading.Thread(target=self._pollingLoop, daemon=True)
         self._pollThread.start()

         if self.display:
            self.display.close()

         _activeMidiInObjects.append(self)

      except Exception as e:
         print(f"Error opening MIDI device: {e}")


   def close(self):
      """Closes the MIDI input device and frees its resources."""
      self._stopEvent.set()
      if self._pollThread and self._pollThread.is_alive():
         self._pollThread.join(timeout=2.0)

      if self._port:
         self._port.close()
         self._port = None

      if self in _activeMidiInObjects:
         _activeMidiInObjects.remove(self)


   def onNoteOn(self, action):
      """Registers 'action' to be called on NOTE_ON events."""
      if NOTE_ON not in self.eventHandlers:
         self.eventHandlers[NOTE_ON] = []
      self.eventHandlers[NOTE_ON].append(action)


   def onNoteOff(self, action):
      """Registers 'action' to be called on NOTE_OFF events."""
      if NOTE_OFF not in self.eventHandlers:
         self.eventHandlers[NOTE_OFF] = []
      self.eventHandlers[NOTE_OFF].append(action)


   def onSetInstrument(self, action):
      """Registers 'action' to be called on SET_INSTRUMENT events."""
      if SET_INSTRUMENT not in self.eventHandlers:
         self.eventHandlers[SET_INSTRUMENT] = []
      self.eventHandlers[SET_INSTRUMENT].append(action)


   def onInput(self, eventType, action):
      """
      Registers 'action' as a callback for the given 'eventType'.
      Use ALL_EVENTS to receive every event type not handled by a more specific handler.
      Multiple callbacks may be registered for the same event type.
      """
      if eventType not in self.eventHandlers:
         self.eventHandlers[eventType] = []
      self.eventHandlers[eventType].append(action)


   def showMessages(self):
      """Enables printing of incoming MIDI messages to the console."""
      self.showIncomingMessages = True


   def hideMessages(self):
      """Disables printing of incoming MIDI messages to the console."""
      self.showIncomingMessages = False


   def _pollingLoop(self):
      """Continuously polls the MIDI port at 1ms intervals and dispatches incoming messages."""
      while not self._stopEvent.is_set():
         if self._port:
            for message in self._port.iter_pending():
               self._handleMidiMessage(message)
         time.sleep(0.001)


   def _handleMidiMessage(self, message):
      """Parses a raw mido message and dispatches it to registered callbacks."""
      msgType    = None
      msgChannel = 0
      msgData1   = 0
      msgData2   = 0

      if message.type == 'note_on':
         msgType    = NOTE_ON
         msgChannel = message.channel
         msgData1   = message.note
         msgData2   = message.velocity
         if msgData2 == 0:               # velocity 0 means note off (per MIDI spec)
            msgType = NOTE_OFF

      elif message.type == 'note_off':
         msgType    = NOTE_OFF
         msgChannel = message.channel
         msgData1   = message.note
         msgData2   = message.velocity

      elif message.type == 'program_change':
         msgType    = SET_INSTRUMENT
         msgChannel = message.channel
         msgData1   = message.program
         msgData2   = 0

      elif message.type == 'control_change':
         msgType    = CONTROL_CHANGE
         msgChannel = message.channel
         msgData1   = message.control
         msgData2   = message.value

      elif message.type == 'pitchwheel':
         msgType     = PITCH_BEND
         msgChannel  = message.channel
         pitch_value = message.pitch + 8192      # convert mido's -8192..8191 to 0..16383
         msgData1    = pitch_value & 0x7F        # LSB
         msgData2    = (pitch_value >> 7) & 0x7F # MSB

      elif message.type == 'aftertouch':
         msgType    = AFTERTOUCH
         msgChannel = message.channel
         msgData1   = message.value
         msgData2   = 0

      elif message.type == 'polytouch':
         msgType    = POLYTOUCH
         msgChannel = message.channel
         msgData1   = message.note
         msgData2   = message.value

      elif message.type == 'sysex':
         msgType    = 240
         msgChannel = 0
         msgData1   = 0
         msgData2   = 0

      elif message.type.startswith('system_'):
         msgType    = SYSTEM_MESSAGE_VALUES.get(message.type, 240)
         msgChannel = 0
         msgData1   = getattr(message, 'data1', 0)
         msgData2   = getattr(message, 'data2', 0)

      elif message.type in ('clock', 'start', 'continue', 'stop'):
         msgType    = REALTIME_MESSAGE_VALUES.get(message.type, 248)
         msgChannel = 0
         msgData1   = 0
         msgData2   = 0

      if msgType is None:
         return

      if self.showIncomingMessages:
         print(f"{self.midiDeviceName} (MidiIn) - Event Type: {msgType}, Channel: {msgChannel}, Data 1: {msgData1}, Data 2: {msgData2}")

      for handler in self.eventHandlers.get(msgType, []):
         try:
            self._executeCallback(handler, msgType, msgChannel, msgData1, msgData2)
         except Exception as e:
            print(f"Error executing MIDI event handler: {e}")

      for handler in self.eventHandlers.get(ALL_EVENTS, []):
         try:
            self._executeCallback(handler, msgType, msgChannel, msgData1, msgData2)
         except Exception as e:
            print(f"Error executing MIDI event handler: {e}")


   def _executeCallback(self, handler, msgType, msgChannel, msgData1, msgData2):
      """Calls 'handler' with the four MIDI message parameters."""
      try:
         handler(msgType, msgChannel, msgData1, msgData2)
      except Exception as e:
         print(f"MidiIn: Error executing callback: {e}")


#################### MidiOut ##########################################################
#
# Sends MIDI output to a connected device.
#
# Usage:
#   midiOut = MidiOut()
#   midiOut.sendMidiMessage(NOTE_ON, channel, pitch, velocity)
#   midiOut.sendMidiMessage(NOTE_OFF, channel, pitch, 0)

class MidiOut:
   """Sends MIDI messages to a connected output device."""

   def __init__(self, preferredDevice=""):
      """Opens 'preferredDevice' for output, or shows a device-selection GUI if not found."""

      self.preferredDevice = preferredDevice
      self.display         = None    # device-selection GUI (shown when needed)
      self.waitingToSetup  = True    # True until a device is selected
      self.midiDevice      = None    # selected MIDI device
      self.midiDeviceName  = None    # display name of selected device
      self._port           = None    # mido port object

      self.instrument = {}   # current instrument per channel
      self.volume     = {}   # current volume per channel
      self.panning    = {}   # current panning per channel
      self.pitchBend  = {}   # current pitch bend per channel

      for channel in range(16):
         self.instrument[channel] = 0    # PIANO (default)
         self.volume[channel]     = 127  # max volume
         self.panning[channel]    = 63   # center
         self.pitchBend[channel]  = 0    # no bend

      self.selectMidiOutput(self.preferredDevice)


   def __str__(self):
      return f'MidiOut(preferredDevice = {self.preferredDevice})'

   def __repr__(self):
      return str(self)


   def close(self):
      """Stops all notes and closes the MIDI output device."""
      self.allNotesOff()

      if self._port:
         self._port.close()
         self._port = None

      if self in _activeMidiOutObjects:
         _activeMidiOutObjects.remove(self)


   def play(self, material):
      """Plays jMusic material (Score, Part, Phrase, Note) via this MIDI output device."""
      # do necessary datatype wrapping (we need a Score to traverse parts/phrases/notes)
      if isinstance(material, Note):
         material = Phrase(material)
      if isinstance(material, Phrase):   # no elif - we need to successively wrap from Note to Score
         material = Part(material)
         material.setInstrument(-1)     # indicate no default instrument (needed to access per-channel instrument)
      if isinstance(material, Part):     # no elif - we need to successively wrap from Note to Score
         material = Score(material)
      if not isinstance(material, Score):
         print(f'MidiOut.play(): Unrecognized type {type(material)}, expected Note, Phrase, Part, or Score.')
         return

      score = material

      # collect all non-REST notes with absolute ms start times
      noteList = []
      tempo = score.getTempo()
      for part in score.getPartList():
         channel    = part.getChannel()
         instrument = self.getInstrument(channel)
         if part.getInstrument() > -1:   # part instrument overrides channel default
            instrument = part.getInstrument()
         if part.getTempo() > -1:        # part tempo overrides score tempo
            tempo = part.getTempo()
         for phrase in part.getPhraseList():
            if phrase.getInstrument() > -1:   # phrase instrument overrides part instrument
               instrument = phrase.getInstrument()
            if phrase.getTempo() > -1:        # phrase tempo overrides part tempo
               tempo = phrase.getTempo()

            FACTOR    = 1000 * 60.0 / tempo   # convert quarter-note units → milliseconds
            startTime = phrase.getStartTime() * FACTOR

            for note in phrase.getNoteList():
               frequency = note.getFrequency()
               panning   = mapValue(note.getPan(), 0.0, 1.0, 0, 127)   # map 0.0–1.0 → 0–127
               start     = int(startTime)
               duration  = int(note.getLength() * FACTOR)
               startTime += note.getDuration() * FACTOR
               velocity  = note.getDynamic()

               if frequency != REST:
                  noteList.append((start, duration, frequency, velocity, channel, instrument, panning))

      # sort by start time so chords (same start time, duration=0) sort before their anchor note
      noteList.sort()

      # schedule all notes; chords are sequences of duration=0 notes followed by one note with the real duration
      chordNotes = []
      for start, duration, pitch, velocity, channel, instrument, panning in noteList:
         self.setInstrument(instrument, channel)

         if duration == 0:   # chord member — collect it
            chordNotes.append([start, duration, pitch, velocity, channel, panning])

         elif chordNotes == []:   # regular solo note
            self.note(pitch, start, duration, velocity, channel, panning)

         else:   # final note of a chord — schedule all collected chord members with this duration
            chordNotes.append([start, duration, pitch, velocity, channel, panning])
            for start, _, pitch, velocity, channel, panning in chordNotes:
               self.note(pitch, start, duration, velocity, channel, panning)
            chordNotes = []


   def noteOn(self, pitch, velocity=100, channel=0, panning=-1):
      """Sends NOTE_ON for 'pitch' (MIDI int 0-127 or Hz float) on 'channel'."""

      if isinstance(pitch, int) and (0 <= pitch <= 127):
         if panning != -1:
            self.sendMidiMessage(CONTROL_CHANGE, channel, 10, panning)
         self.sendMidiMessage(NOTE_ON, channel, pitch, velocity)
         notesCurrentlyPlaying.append((pitch, channel))

      elif isinstance(pitch, float):
         self.frequencyOn(pitch, velocity, channel, panning)

      else:
         print(f"MidiOut.noteOn(): Unrecognized pitch {pitch}, expected int 0-127 or float Hz 8.17-12600.0.")


   def frequencyOn(self, frequency, velocity=100, channel=0, panning=-1):
      """Sends NOTE_ON for 'frequency' (in Hz) on 'channel', applying pitch bend for microtones."""
      if isinstance(frequency, float) and (8.17 <= frequency <= 12600.0):
         pitch, bend = freqToNote(frequency)
         notesCurrentlyPlaying.append((pitch, channel))
         self.noteOnPitchBend(pitch, bend, velocity, channel, panning)
      else:
         print(f"MidiOut.frequencyOn(): Invalid frequency {frequency}, expected float Hz 8.17-12600.0.")


   def noteOff(self, pitch, channel=0):
      """Sends NOTE_OFF for 'pitch' (MIDI int 0-127 or Hz float) on 'channel'."""

      if isinstance(pitch, int) and (0 <= pitch <= 127):
         noteID = (pitch, channel)
         if noteID in notesCurrentlyPlaying:
            notesCurrentlyPlaying.remove(noteID)
            if noteID not in notesCurrentlyPlaying:   # only send if no more instances are playing
               self.sendMidiMessage(NOTE_OFF, channel, pitch, 0)

      elif isinstance(pitch, float):
         self.frequencyOff(pitch, channel)

      else:
         print(f"MidiOut.noteOff(): Unrecognized pitch {pitch}, expected int 0-127 or float Hz 8.17-12600.0.")


   def frequencyOff(self, frequency, channel=0):
      """Sends NOTE_OFF for 'frequency' (in Hz) on 'channel'."""
      if isinstance(frequency, float) and (8.17 <= frequency <= 12600.0):
         pitch, _ = freqToNote(frequency)
         noteID = (pitch, channel)

         if noteID in notesCurrentlyPlaying:
            notesCurrentlyPlaying.remove(noteID)
            if noteID not in notesCurrentlyPlaying:
               self.sendMidiMessage(NOTE_OFF, channel, pitch, 0)
         else:
            print(f"MidiOut.frequencyOff(): Frequency {frequency} Hz (pitch {pitch}) on channel {channel} is not currently playing.")

      else:
         print(f"MidiOut.frequencyOff(): Invalid frequency {frequency}, expected float Hz 8.17-12600.0.")


   def note(self, pitch, start, duration, velocity=100, channel=0, panning=-1):
      """Schedules a note to start at 'start' ms from now and last 'duration' ms."""
      Timer(start,          self.noteOn,  [pitch, velocity, channel, panning], False).start()
      Timer(start+duration, self.noteOff, [pitch, channel],                    False).start()


   def frequency(self, frequency, start, duration, velocity=100, channel=0, panning=-1):
      """Schedules a frequency (in Hz) to start at 'start' ms from now and last 'duration' ms."""
      Timer(start,          self.frequencyOn,  [frequency, velocity, channel, panning], False).start()
      Timer(start+duration, self.frequencyOff, [frequency, channel],                    False).start()


   def setPitchBend(self, bend=0, channel=0):
      """Sets pitch bend for 'channel'. Range: -8192 (max down) to 8191 (max up), 0 = center."""
      self.pitchBend[channel] = bend

      midiBend = max(PITCHBEND_MIN, min(bend + PITCHBEND_NORMAL, PITCHBEND_MAX))
      lsb = midiBend & 0x7F
      msb = (midiBend >> 7) & 0x7F

      self.sendMidiMessage(PITCH_BEND, channel, lsb, msb)


   def getPitchBend(self, channel=0):
      """Returns the current pitch bend for 'channel'."""
      return self.pitchBend[channel]


   def noteOnPitchBend(self, pitch, bend=0, velocity=100, channel=0, panning=-1):
      """Sends NOTE_ON for 'pitch' with 'bend' applied on 'channel'."""
      self.setPitchBend(bend, channel)
      if panning != -1:
         self.sendMidiMessage(CONTROL_CHANGE, channel, 10, panning)
      self.sendMidiMessage(NOTE_ON, channel, pitch, velocity)


   def allNotesOff(self):
      """Turns off all notes on all channels."""
      self.allFrequenciesOff()


   def allFrequenciesOff(self):
      """Sends All Notes Off and resets pitch bend on every channel."""
      for channel in range(16):
         self.sendMidiMessage(CONTROL_CHANGE, channel, 123, 0)
         self.setPitchBend(0, channel)


   def stop(self):
      """Stops all sounding MIDI notes."""
      self.allNotesOff()


   def setInstrument(self, instrument, channel=0):
      """Sets 'channel' to 'instrument' (MIDI program number 0-127)."""
      self.instrument[channel] = instrument
      self.sendMidiMessage(SET_INSTRUMENT, channel, instrument, 0)


   def getInstrument(self, channel=0):
      """Returns the current instrument for 'channel'."""
      return self.instrument[channel]


   def setVolume(self, volume, channel=0):
      """Sets the coarse volume (0-127) for 'channel'."""
      self.volume[channel] = volume
      self.sendMidiMessage(CONTROL_CHANGE, channel, 7, volume)


   def getVolume(self, channel=0):
      """Returns the current volume for 'channel'."""
      return self.volume[channel]


   def setPanning(self, panning, channel=0):
      """Sets the panning (0=left, 63=center, 127=right) for 'channel'."""
      self.panning[channel] = panning
      self.sendMidiMessage(CONTROL_CHANGE, channel, 10, panning)


   def getPanning(self, channel=0):
      """Returns the current panning for 'channel'."""
      return self.panning[channel]


   def sendMidiMessage(self, msgType, msgChannel, msgData1, msgData2):
      """Sends a raw MIDI message to the output device."""
      try:
         if msgType == NOTE_ON:
            msg = mido.Message('note_on', channel=msgChannel, note=msgData1, velocity=msgData2)

         elif msgType == NOTE_OFF:
            msg = mido.Message('note_off', channel=msgChannel, note=msgData1, velocity=msgData2)

         elif msgType == SET_INSTRUMENT:
            msg = mido.Message('program_change', channel=msgChannel, program=msgData1)

         elif msgType == CONTROL_CHANGE:
            msg = mido.Message('control_change', channel=msgChannel, control=msgData1, value=msgData2)

         elif msgType == PITCH_BEND:
            # Recombine 7-bit LSB/MSB into a 14-bit value, then shift to mido's -8192..8191 range.
            bendValue = ((msgData2 << 7) + msgData1) - PITCHBEND_NORMAL
            msg = mido.Message('pitchwheel', channel=msgChannel, pitch=bendValue)

         elif msgType == AFTERTOUCH:
            msg = mido.Message('aftertouch', channel=msgChannel, value=msgData1)

         elif msgType == POLYTOUCH:
            msg = mido.Message('polytouch', channel=msgChannel, note=msgData1, value=msgData2)

         elif msgType == SYSTEM_MESSAGE_VALUES['system_exclusive']:
            msg = mido.Message('sysex', data=[msgData1, msgData2])

         elif msgType == SYSTEM_MESSAGE_VALUES['songpos']:
            msg = mido.Message('songpos', pos=(msgData2 << 7) + msgData1)

         elif msgType == SYSTEM_MESSAGE_VALUES['songsel']:
            msg = mido.Message('songsel', song=msgData1)

         elif msgType == SYSTEM_MESSAGE_VALUES['tune_request']:
            msg = mido.Message('tune_request')

         elif msgType == SYSTEM_MESSAGE_VALUES['system_reset']:
            msg = mido.Message('reset')

         elif msgType == REALTIME_MESSAGE_VALUES['clock']:
            msg = mido.Message('clock')

         elif msgType == REALTIME_MESSAGE_VALUES['start']:
            msg = mido.Message('start')

         elif msgType == REALTIME_MESSAGE_VALUES['continue']:
            msg = mido.Message('continue')

         elif msgType == REALTIME_MESSAGE_VALUES['stop']:
            msg = mido.Message('stop')

         else:
            print(f"Unsupported MIDI message type: {msgType}")
            return

         if self._port:
            self._port.send(msg)

      except Exception as e:
         print(f"Error sending MIDI message: {e}")


   def selectMidiOutput(self, preferredDevice=""):
      """
      Opens preferred MIDI device for output. If this device does not exist,
      creates display with available output MIDI devices and allows to select one.
      """
      self.preferredDevice = preferredDevice

      availablePorts = mido.get_output_names()
      self.outputDevices = {}

      for port in availablePorts:
         self.outputDevices[port] = port

      if self.preferredDevice in self.outputDevices:
         self.openOutputDevice(self.preferredDevice)

      else:
         items = sorted(self.outputDevices.keys())

         if items:
            from gui import Display, DropDownList, Color

            self.display = Display("Select MIDI Output", 400, 125)
            self.display.drawLabel('Select a MIDI output device from the list', 45, 30)

            deviceDropdown = DropDownList(items, self.openOutputDevice)
            self.display.add(deviceDropdown, 40, 50)
            self.display.setColor( Color(255, 153, 153) )

         else:
            print("MidiOut: No available MIDI output devices.")


   def openOutputDevice(self, selectedItem):
      """Opens the selected MIDI output device."""
      global _activeMidiOutObjects

      try:
         print(f'MIDI output device set to "{selectedItem}".')
         deviceInfo = self.outputDevices[selectedItem]

         self.midiDeviceName = selectedItem
         self._port = mido.open_output(deviceInfo)
         self.waitingToSetup = False

         if self.display:
            self.display.close()

         _activeMidiOutObjects.append(self)

      except Exception as e:
         print(f"Error opening MIDI device: {e}")


##### Cleanup #########################################################################

def _stopActiveMidiObjects():
   """Closes all active MIDI devices; called automatically on program exit."""
   global _activeMidiInObjects, _activeMidiOutObjects

   for midiIn in _activeMidiInObjects.copy():
      try:
         midiIn.close()
      except Exception as e:
         print(f"Error closing MIDI input device: {e}")

   for midiOut in _activeMidiOutObjects.copy():
      try:
         midiOut.allNotesOff()
         midiOut.close()
      except Exception as e:
         print(f"Error closing MIDI output device: {e}")

   _activeMidiInObjects.clear()
   _activeMidiOutObjects.clear()

atexit.register(_stopActiveMidiObjects)


##### Tests ###########################################################################

if __name__ == '__main__':
   pass
