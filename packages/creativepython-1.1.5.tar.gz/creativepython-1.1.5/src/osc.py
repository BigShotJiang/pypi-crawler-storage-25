#######################################################################################
# osc.py       Version 1.1     01-Apr-2026
# Trevor Ritchie, Taj Ballinger, Drew Smuniewski, and Bill Manaris
#######################################################################################
#
# [LICENSING GOES HERE]
#
# This module provides OSC (Open Sound Control) input and output handling.
#
#######################################################################################

from osc4py3.as_eventloop import osc_startup, osc_terminate, osc_process, osc_send, osc_udp_client, osc_udp_server, osc_method
from osc4py3 import oscbuildparse
from osc4py3 import oscmethod
import threading
import socket
import time
import sys
import atexit
import re

# only expose OscIn, OscOut, and ALL_MESSAGES
__all__ = ['OscIn', 'OscOut', 'OscMessage', 'ALL_MESSAGES']


##### Globals #########################################################################

_oscStarted   = False   # True once osc_startup() has been called
_activeOscIns = []      # tracks open OscIn objects for cleanup


#################### OscIn ############################################################
#
# Receives OSC messages on a specified port.
#
# Usage:
#   oscIn = OscIn(57110)
#
#   def onMessage(message):
#      print(message.getAddress(), message.getArguments())
#
#   oscIn.onInput("/helloWorld", onMessage)   # call onMessage for /helloWorld messages
#   oscIn.onInput("*",          onMessage)   # call onMessage for all messages

ALL_MESSAGES = "/.*"   # matches all OSC addresses (Java 8 regex)

class OscIn:
   """Receives OSC messages on a specified port."""

   def __init__(self, port=57110):
      """Creates an OSC server listening on 'port'."""
      global _oscStarted, _activeOscIns
      _activeOscIns.append(self)

      self._stopEvent = threading.Event()   # signals the processing thread to stop

      if not _oscStarted:
         osc_startup()
         _oscStarted = True

      self.port       = port
      hostIP          = "127.0.0.1"
      alternativeIPs  = []

      try:
         hostname       = socket.gethostname()
         hostIP         = socket.gethostbyname(hostname)
         allIPs         = socket.gethostbyname_ex(hostname)[2]
         alternativeIPs = sorted(list(set(ip for ip in allIPs if ip != hostIP and ip != "127.0.0.1")))
      except socket.gaierror:
         pass

      self.ipAddress  = hostIP
      self.serverName = f"oscServer_{self.port}"

      osc_udp_server("0.0.0.0", self.port, self.serverName)

      print('OSC Server started:')
      print(f'Accepting OSC input on IP address {self.ipAddress}, at port {self.port}')
      if alternativeIPs:
         print(f'(Alternative IP addresses: {", ".join(alternativeIPs)})')
      elif self.ipAddress != "127.0.0.1" and "127.0.0.1" in socket.gethostbyname_ex(socket.gethostname())[2]:
         print('(Alternative IP addresses: 127.0.0.1)')
      print('Use this info to configure OSC clients.\n')

      self.showIncomingMessages = True
      self._handlers = []   # [(compiled_regex, callback), ...]

      # Register a single catch-all handler; all pattern matching is done in _dispatch via Python regex.
      # "/*" covers single-level addresses (e.g. /note, /fader1). For deeper addresses (e.g. /a/b),
      # register additional patterns like "/*/*" explicitly.
      osc_method("/*", self._dispatch, argscheme=oscmethod.OSCARG_MESSAGE)

      self._processThread = threading.Thread(target=self._processingLoop, daemon=True)
      self._processThread.start()


   def __str__(self):
      return f'OscIn(port = {self.port})'


   def __repr__(self):
      return str(self)


   def onInput(self, oscAddress, function):
      """Registers 'function' as a callback for OSC messages whose address matches the Java 8 regex 'oscAddress'."""
      self._handlers.append((re.compile(oscAddress), function))


   def _dispatch(self, rawMsg):
      """Routes an incoming OSC message to all callbacks with a matching pattern."""
      address = rawMsg.addrpattern
      msg     = OscMessage(address, rawMsg.arguments)
      printed = False

      for pattern, callback in self._handlers:
         if re.fullmatch(pattern, address):
            if self.showIncomingMessages and not printed:
               self._printIncomingMessage(msg)
               printed = True
            self._executeCallback(callback, msg)


   def showMessages(self):
      """Enables printing of incoming OSC messages to the console."""
      self.showIncomingMessages = True


   def hideMessages(self):
      """Disables printing of incoming OSC messages to the console."""
      self.showIncomingMessages = False


   def _printIncomingMessage(self, message):
      """Prints an incoming OSC message to the console."""
      oscAddress = message.getAddress()
      oscArgs    = message.getArguments()

      print(f'OSC In - Address: "{oscAddress}"', end='')
      for i, arg in enumerate(oscArgs):
         if isinstance(arg, str):
            print(f' , Argument {i}: "{arg}"', end='')
         else:
            print(f' , Argument {i}: {arg}', end='')
      print()


   def _executeCallback(self, handler, message):
      """Calls 'handler' with 'message'. NOTE: Runs on the OSC processing thread."""
      try:
         handler(message)
      except Exception as e:
         print(f"OscIn: Error executing callback: {e}")


   def _processingLoop(self):
      """Continuously calls osc_process() until _stopEvent is set."""
      try:
         while not self._stopEvent.is_set():
            osc_process()
            time.sleep(0.001)
      except Exception as e:
         print(f"[OSC Error] OscIn on port {self.port} encountered an error: {e}", file=sys.stderr)


#################### OscOut ###########################################################
#
# Sends OSC messages to a specified IP address and port.
#
# Usage:
#   oscOut = OscOut("localhost", 57110)
#   oscOut.sendMessage("/helloWorld")
#   oscOut.sendMessage("/itsFullOfStars", 1, 2.3, "wow!", True)

class OscOut:
   """Sends OSC messages to a specified IP address and port."""

   def __init__(self, IP="localhost", port=57110):
      """Creates an OSC client targeting 'IP' and 'port'."""
      global _oscStarted

      if not _oscStarted:
         osc_startup()
         _oscStarted = True

      if IP == "localhost":
         IP = "127.0.0.1"

      self.IP     = IP
      self.port   = port
      self.client = f"oscClient_{self.IP}_{self.port}"

      osc_udp_client(self.IP, self.port, self.client)


   def __str__(self):
      return f'OscOut(IP = {self.IP}, port = {self.port})'


   def __repr__(self):
      return str(self)


   def sendMessage(self, oscAddress, *args):
      """Sends an OSC message to 'oscAddress' with optional 'args'."""
      message = oscbuildparse.OSCMessage(oscAddress, None, args)
      osc_send(message, self.client)


#################### OscMessage #######################################################

class OscMessage:
   """An OSC message: an address pattern (e.g. '/synth/freq') and zero or more arguments."""

   def __init__(self, oscAddress, *args):
      """Creates an OSC message with 'oscAddress' and optional arguments."""
      self.oscAddress = oscAddress
      if len(args) == 1 and isinstance(args[0], (list, tuple)):
         self.arguments = list(args[0])
      else:
         self.arguments = list(args)


   def __str__(self):
      return f'OscMessage(oscAddress = {self.oscAddress}, args = {self.arguments})'


   def __repr__(self):
      return str(self)


   def getAddress(self):
      """Returns the OSC address pattern of this message."""
      return self.oscAddress


   def getArguments(self):
      """Returns the arguments of this message."""
      return self.arguments


##### Cleanup #########################################################################

def _cleanupOsc():
   """Stops all OSC processing threads and terminates the OSC system; called on exit."""
   global _activeOscIns

   for instance in list(_activeOscIns):
      if hasattr(instance, '_processThread') and instance._processThread.is_alive():
         instance._stopEvent.set()
         instance._processThread.join(timeout=2.0)   # wait up to 2s for clean shutdown

   if _oscStarted:
      try:
         osc_terminate()
      except Exception as e:
         print(f"[OSC Cleanup Error] {e}", file=sys.stderr)

atexit.register(_cleanupOsc)


##### Tests ###########################################################################

if __name__ == '__main__':
   pass
