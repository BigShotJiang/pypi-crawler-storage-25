################################################################################
# image.py       Version 1.0     30-Jan-2025
# Taj Ballinger, Trevor Ritchie, and Bill Manaris
#
##############################################################
##################

from gui import Display, Icon

class Image:
   """
   Display window for rendering images.
   """
   def __init__(self, arg1, arg2=None):
      """
      Creates a new image display.
      """
      # JythonMusic's Image class has overloaded constructors,
      # but Python doesn't allow that.  We replicate an overload based on the
      # data types of arg1 and arg2.
      #
      # (str, None) -> a filename for an image to load
      # (str, int)  -> a filename for an image to load, scaled to a width
      # (int, None) -> the width of a square, blank canvas
      # (int, int)  -> the width and height of a blank canvas

      self._display = Display()  # the display the image is on
      self._icon    = None       # the icon that holds the image data (created in read())
      self.read(arg1, arg2)      # read() loads the icon and sets Display properties

   def show(self):
      """
      Shows the display window.
      """
      self._display.show()

   def hide(self):
      """
      Hides the display window.
      """
      self._display.hide()

   def getWidth(self):
      """
      Returns the display's canvas width (in pixels).
      """
      return self._display.getWidth()

   def getHeight(self):
      """
      Returns the display's canvas height (in pixels).
      """
      return self._display.getHeight()

   # pixel manipulation wrappers

   def getPixel(self, col, row):
      """
      Returns the [r, g, b] color of a given pixel in the image.
      """
      return self._icon.getPixel(col, row)

   def setPixel(self, col, row, RGBList):
      """
      Sets the [r, g, b] color of a given pixel in the image.
      """
      self._icon.setPixel(col, row, RGBList)

   def getPixels(self):
      """
      Returns the [r, g, b] color of all pixels in the icon as a 2-dimensional array.
      """
      return self._icon.getPixels()

   def setPixels(self, pixels):
      """
      Sets the [r, g, b] color of all pixels in the icon from a 2-dimensional array.
      """
      self._icon.setPixels(pixels)

   def write(self, filename):
      """
      Saves the display's currently visible canvas to an image file.
      The file format is determined by the filename extension (e.g. .png, .jpg).
      """
      self._display.save(filename)

   def read(self, arg1, arg2=None):
      """
      Updates the image with a new filename.
      arg1 and arg2 have the same overloaded behavior as Image's constructor.
      (str, None) -> a filename for an image to load
      (str, int)  -> a filename for an image to load, scaled to a width
      (int, None) -> the width of a square, blank canvas
      (int, int)  -> the width and height of a blank canvas
      """
      # first, load the icon
      if isinstance(arg1, str):
         # arg1 is a filename
         title = arg1
         icon  = Icon(arg1, arg2)  # load icon with optional resizing
      else:
         # arg1 is a image size
         title = "Image"
         icon  = Icon("", arg1, arg2)  # load blank icon, sized to given dimensions

      # remove the previous icon, if needed
      if self._icon is not None:
         self._display.remove(self._icon)

      # next, update the Display
      width, height = icon.getSize()
      self._display.setSize(width, height)
      self._display.setTitle(title)

      # finally, add new icon to the display
      self._icon = icon
      self._display.add(icon)


###### Unit Tests ###################################

if __name__ == "__main__":
   pass