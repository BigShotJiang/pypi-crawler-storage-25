import platform, ctypes, importlib.resources
from importlib.metadata import version as _metadata_version

try:
    __version__ = _metadata_version("CreativePython")
except Exception:
    __version__ = "unknown"


# import portaudio binary on MacOS
if platform.system() == "Darwin":
   try:
      with importlib.resources.path("CreativePython.bin", "libportaudio.2.dylib") as libpath:
         ctypes.CDLL(str(libpath))
   except Exception:
      pass
