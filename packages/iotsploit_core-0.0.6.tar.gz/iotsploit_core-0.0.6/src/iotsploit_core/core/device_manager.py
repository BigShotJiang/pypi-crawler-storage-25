from __future__ import annotations

import datetime
from importlib import metadata as importlib_metadata
import importlib.util
import json
import logging
import os
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from iotsploit_core.core.base_plugin import BaseDeviceDriver
from iotsploit_core.core.device_spec import DevicePluginSpec, DeviceState
from iotsploit_core.domain.device import Device
from iotsploit_core.ports.driver_state_repo import DriverStateRepository

logger = logging.getLogger(__name__)

class DeviceDriverManager:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(DeviceDriverManager, cls).__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(
        self,
        *,
        driver_state_repo: DriverStateRepository,
        plugins_dir: str | Path | None = None,
        usb_config_file: str | Path | None = None,
    ):
        if not self._initialized:
            logger.info("Initializing DeviceDriverManager")
            self._driver_state_repo = driver_state_repo

            self.plugins_dir = Path(plugins_dir) if plugins_dir is not None else self._default_plugins_dir()
            self.usb_config_file = str(
                Path(usb_config_file) if usb_config_file is not None else self._default_usb_config_file()
            )
            self.plugins = {}
            self.drivers = {}  # Store driver instances
            self.device_states = {}  # Store device states, format: 'driver_name::device_id': DeviceState
            self._connection_locks = {}  # Device operation locks, format: 'driver_name::device_id': Lock
            self.driver_states = {}  # Store driver enablement states
            
            # 添加USB设备配置
            self.usb_device_configs = self._load_usb_config()
            
            # Define valid state transitions
            self._state_transitions = {
                DeviceState.UNKNOWN: [DeviceState.DISCOVERED],
                DeviceState.DISCOVERED: [DeviceState.INITIALIZED],
                DeviceState.INITIALIZED: [DeviceState.CONNECTED, DeviceState.DISCONNECTED],
                DeviceState.CONNECTED: [DeviceState.ACTIVE, DeviceState.DISCONNECTED],
                DeviceState.ACTIVE: [DeviceState.CONNECTED, DeviceState.ERROR],
                DeviceState.ERROR: [DeviceState.DISCONNECTED],
                DeviceState.DISCONNECTED: [DeviceState.INITIALIZED]
            }
            
            self.load_plugins()
            self._load_driver_states()
            self._initialized = True
            logger.info("DeviceDriverManager initialized")

    @staticmethod
    def _default_plugins_dir() -> Path | None:
        env = os.getenv("IOTSPLOIT_DEVICE_PLUGINS_DIR") or os.getenv("SAT_DEVICE_PLUGINS_DIR")
        if env:
            return Path(env)
        return None

    @staticmethod
    def _default_usb_config_file() -> Path:
        env = os.getenv("IOTSPLOIT_USB_CONFIG_FILE") or os.getenv("SAT_USB_CONFIG_FILE")
        if env:
            return Path(env)
        repo_root = Path(__file__).resolve().parents[2]
        return repo_root / "conf" / "usb_devices.json"

    def _load_usb_config(self) -> Dict:
        """加载USB设备配置文件"""
        try:
            if os.path.exists(self.usb_config_file):
                with open(self.usb_config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                logger.warning(f"USB配置文件不存在: {self.usb_config_file}")
                return {}
        except Exception as e:
            logger.error(f"加载USB配置文件失败: {e}")
            return {}

    def get_usb_device_info(self, device_type: str) -> List[Dict]:
        """根据设备类型获取USB设备完整信息
        
        Args:
            device_type: 设备类型，如 "logic_analyzer"
            
        Returns:
            List[Dict]: 设备完整信息列表，包含端口、VID/PID、配置等
        """
        import serial.tools.list_ports
        
        config = self.usb_device_configs.get(device_type)
        if not config:
            return []
        
        devices = []
        for vid_pid in config.get("vid_pid_list", []):
            vid = int(vid_pid["vid"], 16)
            pid = int(vid_pid["pid"], 16)
            
            # 查找匹配的串口设备
            for port in serial.tools.list_ports.comports():
                if port.vid == vid and port.pid == pid:
                    device_info = {
                        "device_type": device_type,
                        "port": port.device,
                        "vid": vid,
                        "pid": pid,
                        "description": port.description,
                        "manufacturer": port.manufacturer,
                        "product": port.product,
                        "serial_number": port.serial_number,
                        "config": config
                    }
                    devices.append(device_info)
        
        return devices

    def get_usb_vid_pid(self, device_type: str) -> List[Dict]:
        """根据设备类型获取VID/PID列表
        
        Args:
            device_type: 设备类型，如 "logic_analyzer"
            
        Returns:
            List[Dict]: VID/PID列表，格式 [{"vid": "0x1d50", "pid": "0x5128"}]
        """
        config = self.usb_device_configs.get(device_type)
        if not config:
            return []
        
        return config.get("vid_pid_list", [])

    def _load_driver_states(self):
        """Load driver states from database"""
        try:
            self.driver_states = self._driver_state_repo.list_enabled()
            for name, enabled in self.driver_states.items():
                logger.info(f"Loaded driver state: {name} -> {'enabled' if enabled else 'disabled'}")
        except Exception as e:
            logger.error(f"Error loading driver states: {e}")
            
        # For any driver not in the database, set to enabled by default
        for driver_name in self.drivers.keys():
            if driver_name not in self.driver_states:
                self.driver_states[driver_name] = True
                self._save_driver_state(driver_name, True)

    def _save_driver_state(self, driver_name, enabled, description=None):
        """Save driver state to database"""
        try:
            self._driver_state_repo.set_enabled(driver_name, bool(enabled), description=description)
            logger.info(f"Saved driver state: {driver_name} -> {'enabled' if enabled else 'disabled'}")
        except Exception as e:
            logger.error(f"Error saving driver state: {e}")

    @staticmethod
    def _iter_entry_points(group: str):
        entry_points = importlib_metadata.entry_points()
        if hasattr(entry_points, "select"):
            return list(entry_points.select(group=group))
        return list(entry_points.get(group, []))

    def _load_entry_point_drivers(self) -> None:
        """Load packaged drivers declared via Python entry points."""
        group = "iotsploit.device_drivers"
        for entry_point in self._iter_entry_points(group):
            driver_name = entry_point.name
            if driver_name in self.drivers:
                logger.debug("Skipping duplicate device driver entry point: %s", driver_name)
                continue

            try:
                driver_class = entry_point.load()
                if (
                    not isinstance(driver_class, type)
                    or not issubclass(driver_class, BaseDeviceDriver)
                    or driver_class is BaseDeviceDriver
                ):
                    logger.warning(
                        "Ignoring invalid device driver entry point %s -> %s",
                        driver_name,
                        entry_point.value,
                    )
                    continue

                self.plugins[driver_name] = driver_class
                self.drivers[driver_name] = driver_class()
                logger.info("Loaded device driver entry point: %s (%s)", driver_name, driver_class.__name__)
            except Exception as e:
                logger.error("Failed to load device driver entry point %s: %s", driver_name, str(e))

    def load_plugins(self):
        """Load device drivers from entry points first, then legacy filesystem fallbacks."""
        self._load_entry_point_drivers()

        if self.plugins_dir is None:
            logger.debug("No legacy device plugins directory configured; skipping filesystem scan")
            return
        plugin_dir = str(self.plugins_dir)
        logger.info(f"Loading device plugins from {plugin_dir}")
        for root, _, files in os.walk(plugin_dir):
            for filename in files:
                if filename.endswith(".py") and not filename.startswith("__"):
                    self.load_plugin(os.path.join(root, filename))

    def load_plugin(self, filepath: str):
        """Load a single plugin"""
        try:
            module_name = os.path.splitext(os.path.basename(filepath))[0]
            if module_name in self.drivers:
                logger.debug("Skipping legacy device plugin because %s is already registered", module_name)
                return

            spec = importlib.util.spec_from_file_location(module_name, filepath)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Modify plugin registration logic, remove pluggy related code
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and 
                    issubclass(attr, BaseDeviceDriver) and 
                    attr != BaseDeviceDriver):
                    driver_instance = attr()
                    self.plugins[module_name] = module
                    self.drivers[module_name] = driver_instance
                    logger.info(f"Loaded device plugin: {module_name} ({attr_name})")
                    break
        except Exception as e:
            logger.error(f"Failed to load plugin {filepath}: {str(e)}")

    def execute_command(self, driver_name: str, command: str, device_id: str = "", **kwargs) -> Dict:
        """Execute device command
        
        Args:
            driver_name: Driver name (e.g., 'drv_socketcan')
            command: Command to execute
            device_id: Optional device ID for multi-device scenarios
            **kwargs: Command parameters
        
        Returns:
            Dict: Dictionary containing operation results
        """
        # Check if driver is enabled
        if not self.is_driver_enabled(driver_name):
            logger.warning(f"Attempted to execute command on disabled driver: {driver_name}")
            return {
                "status": "error", 
                "message": f"Driver {driver_name} is disabled"
            }
            
        return self._manage_device_lifecycle(
            driver_name=driver_name,
            action='command',
            device_id=device_id,
            command=command,
            args=kwargs
        )

    def scan_devices(self, driver_name: str) -> Dict:
        """Scan devices"""
        # Check if driver is enabled
        if not self.is_driver_enabled(driver_name):
            return {
                "status": "error",
                "message": f"Driver {driver_name} is disabled"
            }
            
        return self._manage_device_lifecycle(
            driver_name=driver_name,
            action='scan'
        )

    def initialize_device(self, driver_name: str, device: Device) -> Dict:
        """Initialize device"""
        # Check if driver is enabled
        if not self.is_driver_enabled(driver_name):
            return {
                "status": "error",
                "message": f"Driver {driver_name} is disabled"
            }
            
        return self._manage_device_lifecycle(
            driver_name=driver_name,
            action='initialize',
            device=device
        )

    def connect_device(self, driver_name: str, device: Device) -> Dict:
        """Connect device"""
        # Check if driver is enabled
        if not self.is_driver_enabled(driver_name):
            return {
                "status": "error",
                "message": f"Driver {driver_name} is disabled"
            }
            
        return self._manage_device_lifecycle(
            driver_name=driver_name,
            action='connect',
            device=device
        )

    def reset_device(self, driver_name: str, device: Device) -> Dict:
        """Reset device"""
        # Check if driver is enabled
        if not self.is_driver_enabled(driver_name):
            return {
                "status": "error",
                "message": f"Driver {driver_name} is disabled"
            }
            
        return self._manage_device_lifecycle(
            driver_name=driver_name,
            action='reset',
            device=device
        )

    def close_device(self, driver_name: str, device: Device) -> Dict:
        """Close device"""
        return self._manage_device_lifecycle(
            driver_name=driver_name,
            action='close',
            device=device
        )

    def get_device_state(self, driver_name: str, device_id: str = "") -> DeviceState:
        """Get current device state"""
        device_key = self._get_device_key(driver_name, device_id=device_id)
        return self.device_states.get(device_key, DeviceState.UNKNOWN)

    def get_supported_commands(self, driver_name: str) -> Dict[str, str]:
        """Get commands supported by the device"""
        driver = self.get_driver_instance(driver_name)
        if driver:
            return driver.get_supported_commands()
        return {}

    def get_plugin_commands(self, plugin_name: str) -> Dict[str, str]:
        """Get commands supported by the plugin
        
        Args:
            plugin_name: Plugin name
            
        Returns:
            Dict[str, str]: Dictionary of command names and descriptions
        """
        driver = self.get_driver_instance(plugin_name)
        if driver:
            return driver.get_supported_commands()
        return {}

    def _manage_device_lifecycle(self, driver_name: str, action: str, **kwargs) -> Dict:
        """Internal method for device lifecycle management"""
        try:
            driver = self.get_driver_instance(driver_name)
            if not driver:
                return {
                    "status": "error",
                    "message": f"Driver {driver_name} not found"
                }

            device = kwargs.get('device')
            device_id = kwargs.get('device_id', '')
            device_key = self._get_device_key(driver_name, device, device_id)

            with self._get_device_lock(device_key):
                current_state = self.device_states.get(device_key, DeviceState.UNKNOWN)
                
                # Modify state transition logic
                if action != 'scan':
                    if action == 'initialize':
                        # For initialization operations, only execute in uninitialized state
                        if current_state not in [DeviceState.UNKNOWN, DeviceState.DISCOVERED]:
                            return {
                                "status": "error",
                                "message": f"Cannot perform initialize in current state {current_state}. Expected states: [unknown, discovered]"
                            }
                    elif action == 'connect':
                        # For connection operations, ensure the device is initialized
                        if current_state == DeviceState.UNKNOWN:
                            # Auto scan
                            scan_result = self._handle_scan(driver, driver_name, **kwargs)
                            if scan_result["status"] != "success":
                                return scan_result
                            current_state = self.device_states.get(device_key, DeviceState.UNKNOWN)
                        
                        if current_state == DeviceState.DISCOVERED:
                            # Only initialize in discovered state
                            init_result = self._handle_initialize(driver, driver_name, **kwargs)
                            if init_result["status"] != "success":
                                return init_result
                            current_state = self.device_states.get(device_key, DeviceState.UNKNOWN)
                        
                        if current_state != DeviceState.INITIALIZED:
                            return {
                                "status": "error",
                                "message": f"Cannot connect device in state {current_state}. Expected state: initialized"
                            }

                return self._execute_action(driver, action, current_state, device_key, driver_name, **kwargs)

        except Exception as e:
            logger.error(f"Lifecycle management failed: {str(e)}", exc_info=True)
            self._update_device_state(device_key, DeviceState.ERROR)
            return {
                "status": "error",
                "message": str(e)
            }

    def _get_device_lock(self, device_key: str) -> threading.Lock:
        """Get device operation lock"""
        if device_key not in self._connection_locks:
            self._connection_locks[device_key] = threading.Lock()
        return self._connection_locks[device_key]

    def _update_device_state(self, device_key: str, new_state: DeviceState):
        """Update device state"""
        current_state = self.device_states.get(device_key, DeviceState.UNKNOWN)
        
        if current_state == new_state:
            return
        
        if new_state in self._state_transitions.get(current_state, []):
            self.device_states[device_key] = new_state
            logger.info(f"Device {device_key} state changed: {current_state} -> {new_state}")
        else:
            # Special handling: don't downgrade if device is in a higher state
            state_hierarchy = {
                DeviceState.UNKNOWN: 0,
                DeviceState.DISCOVERED: 1,
                DeviceState.INITIALIZED: 2,
                DeviceState.CONNECTED: 3,
                DeviceState.ACTIVE: 4,
            }
            
            # Only update when new state's level is higher than current state
            if state_hierarchy.get(new_state, 0) > state_hierarchy.get(current_state, 0):
                self.device_states[device_key] = new_state
                logger.info(f"Device {device_key} state upgraded: {current_state} -> {new_state}")
            else:
                logger.info(f"Ignoring state transition: {current_state} -> {new_state}")

    def _execute_action(self, 
                        driver: BaseDeviceDriver, 
                        action: str, 
                        current_state: DeviceState, 
                        device_key: str, 
                        driver_name: str,
                        **kwargs) -> Dict:
        """Execute specific action"""
        try:
            if action == 'scan':
                return self._handle_scan(driver, driver_name, **kwargs)
            elif action == 'initialize':
                return self._handle_initialize(driver, driver_name, **kwargs)
            elif action == 'connect':
                return self._handle_connect(driver, driver_name, **kwargs)
            elif action == 'command':
                return self._handle_command(driver, driver_name, device_key, **kwargs)
            elif action == 'reset':
                return self._handle_reset(driver, driver_name, **kwargs)
            elif action == 'close':
                return self._handle_close(driver, driver_name, **kwargs)
            else:
                return {"status": "error", "message": f"Unknown action: {action}"}
        except Exception as e:
            logger.error(f"Action execution failed: {str(e)}")
            self._update_device_state(device_key, DeviceState.ERROR)
            return {"status": "error", "message": str(e)}

    def _get_device_key(self, driver_name: str, device: Device = None, device_id: str = "") -> str:
        """Method to generate unified device key
        
        Args:
            driver_name: Driver name (e.g., 'drv_socketcan')
            device: Device instance (optional)
            device_id: Device ID (optional, used when device doesn't exist)
            
        Returns:
            str: Formatted device key (e.g., 'drv_socketcan::vcan0')
        """
        if device and hasattr(device, 'device_id'):
            key = f"{driver_name}::{device.device_id}"
        else:
            key = f"{driver_name}::{device_id}"
        return key

    def _parse_device_key(self, device_key: str) -> tuple[str, str]:
        """Parse device key
        
        Args:
            device_key: Device key (e.g., 'drv_socketcan::vcan0')
            
        Returns:
            tuple[str, str]: (driver_name, device_id)
        """
        try:
            driver_name, device_id = device_key.split("::", 1)
            return driver_name, device_id
        except ValueError:
            logger.error(f"Invalid device key format: {device_key}")
            return "", ""

    def _handle_scan(self, driver: BaseDeviceDriver, driver_name: str, **kwargs) -> Dict:
        """Handle scan operation"""
        try:
            devices = driver.scan()
            for device in devices:
                device_key = self._get_device_key(driver_name, device)
                self._update_device_state(device_key, DeviceState.DISCOVERED)
            return {
                "status": "success",
                "devices": devices
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _handle_initialize(self, driver: BaseDeviceDriver, driver_name: str, **kwargs) -> Dict:
        """Handle initialization operation"""
        try:
            device = kwargs.get('device')
            if not device:
                return {"status": "error", "message": "Device not specified"}

            success = driver.initialize(device)
            device_key = self._get_device_key(driver_name, device)
            if success:
                self._update_device_state(device_key, DeviceState.INITIALIZED)
                return {
                    "status": "success",
                    "message": "Device initialized"
                }
            return {
                "status": "error",
                "message": "Initialization failed"
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _handle_connect(self, driver: BaseDeviceDriver, driver_name: str, **kwargs) -> Dict:
        """Handle connection operation"""
        try:
            device = kwargs.get('device')
            if not device:
                return {"status": "error", "message": "Device not specified"}

            success = driver.connect(device)
            device_key = self._get_device_key(driver_name, device)
            if success:
                self._update_device_state(device_key, DeviceState.CONNECTED)
                return {
                    "status": "success",
                    "message": "Device connected"
                }
            return {
                "status": "error",
                "message": "Connection failed"
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _handle_command(self, driver: BaseDeviceDriver, driver_name: str, device_key: str, **kwargs) -> Dict:
        """Handle command execution"""
        try:
            command = kwargs.get('command')
            args = kwargs.get('args', {})
            device_id = kwargs.get('device_id')
            
            if not command:
                return {"status": "error", "message": "Command not specified"}

            # Get device instance
            device = driver.get_device(device_id)
            if not device:
                return {"status": "error", "message": f"Device {device_id} not found"}

            # Move to ACTIVE
            self._update_device_state(device_key, DeviceState.ACTIVE)

            try:
                # Execute command using device instance
                result = driver.command(device, command, args)

                # Transition back to CONNECTED
                self._update_device_state(device_key, DeviceState.CONNECTED)

                return {
                    "status": "success",
                    "result": result
                }
            except Exception as cmd_error:
                # On command execution failure, still return to CONNECTED state, not ERROR
                self._update_device_state(device_key, DeviceState.CONNECTED)
                raise cmd_error

        except Exception as e:
            # Only set ERROR state when there's an issue with the device itself
            if isinstance(e, (IOError, ConnectionError)):
                self._update_device_state(device_key, DeviceState.ERROR)
            return {"status": "error", "message": str(e)}

    def _handle_reset(self, driver: BaseDeviceDriver, driver_name: str, **kwargs) -> Dict:
        """Handle reset operation"""
        try:
            device = kwargs.get('device')
            if not device:
                return {"status": "error", "message": "Device not specified"}
            
            success = driver.reset(device)
            return {
                "status": "success" if success else "error",
                "message": "Device reset" if success else "Reset failed"
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _handle_close(self, driver: BaseDeviceDriver, driver_name: str, **kwargs) -> Dict:
        """Handle close operation"""
        try:
            device = kwargs.get('device')
            if not device:
                return {"status": "error", "message": "Device not specified"}
            
            success = driver.close(device)
            return {
                "status": "success" if success else "error",
                "message": "Device closed" if success else "Close failed"
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_driver_instance(self, plugin_name: str) -> Optional[BaseDeviceDriver]:
        """Get driver instance"""
        return self.drivers.get(plugin_name)

    def list_drivers(self) -> List[str]:
        """Get list of all loaded drivers
        
        Returns:
            List[str]: List of driver names
        """
        return list(self.drivers.keys())

    def cleanup_all_devices(self) -> Dict:
        """Clean up all device connections and reset states"""
        logger.info("Starting device cleanup")
        
        results = {}
        for device_key in list(self.device_states.keys()):
            logger.info(f"Closing device: {device_key}")
            try:
                driver_name, device_id = self._parse_device_key(device_key)
                if not driver_name:
                    continue
                    
                driver = self.get_driver_instance(driver_name)
                if not driver:
                    logger.warning(f"Driver {driver_name} not found")
                    continue
                
                device = driver.get_device(device_id)
                if device:
                    result = self._manage_device_lifecycle(
                        driver_name=driver_name,
                        action='close',
                        device=device
                    )
                    results[driver_name] = result
                else:
                    logger.warning(f"Device not found for ID: {device_id}")
                    
            except Exception as e:
                logger.error(f"Error closing device {device_key}: {str(e)}")
                results[driver_name if 'driver_name' in locals() else device_key] = {
                    "status": "error",
                    "message": str(e)
                }

        # Reset all internal state
        self.device_states.clear()
        self._connection_locks.clear()
        
        # Note: Drivers don't have a global reset method - only individual devices can be reset
        # The device reset is handled above in the device closing loop

        return results

    def initialize_all_devices(self) -> Dict:
        """Initialize and connect all available devices"""
        logger.info("Starting device initialization")
        
        # Reset internal state
        self.device_states.clear()
        self._connection_locks.clear()
        
        # Get all available drivers
        available_drivers = list(self.drivers.keys())
        if not available_drivers:
            return {
                "status": "warning",
                "message": "No device drivers available!"
            }

        results = {}
        for driver_name in available_drivers:
            try:
                # Check if driver is enabled before proceeding
                if not self.is_driver_enabled(driver_name):
                    logger.info(f"Skipping disabled driver: {driver_name}")
                    results[driver_name] = {
                        "status": "skipped",
                        "message": "Driver is disabled"
                    }
                    continue
                    
                logger.info(f"Initializing {driver_name}...")
                
                # Scan devices using _manage_device_lifecycle
                scan_result = self._manage_device_lifecycle(
                    driver_name=driver_name,
                    action='scan'
                )
                
                if scan_result['status'] != 'success':
                    results[driver_name] = {
                        "status": "error",
                        "message": f"Failed to scan: {scan_result.get('message', 'Unknown error')}"
                    }
                    continue
                
                devices = scan_result.get('devices', [])
                if not devices:
                    results[driver_name] = {
                        "status": "warning",
                        "message": "No devices found"
                    }
                    continue

                # Process each device
                device_results = []
                for device in devices:
                    try:
                        # Initialize device using _manage_device_lifecycle
                        init_result = self._manage_device_lifecycle(
                            driver_name=driver_name,
                            action='initialize',
                            device=device
                        )
                        if init_result['status'] != 'success':
                            device_results.append({
                                "device": device.name,
                                "status": "error",
                                "message": f"Init failed: {init_result['message']}"
                            })
                            continue

                        # Connect device using _manage_device_lifecycle
                        connect_result = self._manage_device_lifecycle(
                            driver_name=driver_name,
                            action='connect',
                            device=device
                        )
                        if connect_result['status'] != 'success':
                            device_results.append({
                                "device": device.name,
                                "status": "error",
                                "message": f"Connect failed: {connect_result['message']}"
                            })
                            continue

                        device_results.append({
                            "device": device.name,
                            "status": "success",
                            "message": "Successfully connected"
                        })

                    except Exception as e:
                        device_results.append({
                            "device": getattr(device, 'name', 'Unknown'),
                            "status": "error",
                            "message": str(e)
                        })

                results[driver_name] = {
                    "status": "success",
                    "devices": device_results
                }

            except Exception as e:
                results[driver_name] = {
                    "status": "error",
                    "message": str(e)
                }

        return results

    # Driver enable/disable methods
    def enable_driver(self, driver_name: str, description=None) -> Dict:
        """Enable a device driver
        
        Args:
            driver_name: Name of driver to enable
            description: Optional description of why the driver was enabled
            
        Returns:
            Dict: Operation result
        """
        if driver_name not in self.drivers:
            return {
                "status": "error",
                "message": f"Driver {driver_name} not found"
            }
            
        self.driver_states[driver_name] = True
        self._save_driver_state(driver_name, True, description)
        
        return {
            "status": "success",
            "message": f"Driver {driver_name} enabled",
            "driver_name": driver_name,
            "enabled": True
        }
        
    def disable_driver(self, driver_name: str, description=None) -> Dict:
        """Disable a device driver
        
        Args:
            driver_name: Name of driver to disable
            description: Optional description of why the driver was disabled
            
        Returns:
            Dict: Operation result
        """
        if driver_name not in self.drivers:
            return {
                "status": "error",
                "message": f"Driver {driver_name} not found"
            }
            
        # Close all connected devices for this driver
        closed_devices = self._close_all_driver_devices(driver_name)
        
        self.driver_states[driver_name] = False
        self._save_driver_state(driver_name, False, description)
        
        return {
            "status": "success",
            "message": f"Driver {driver_name} disabled",
            "driver_name": driver_name,
            "enabled": False,
            "closed_devices": closed_devices
        }
    
    def _close_all_driver_devices(self, driver_name: str) -> List[str]:
        """Close all devices for a specific driver
        
        Args:
            driver_name: Driver name
            
        Returns:
            List[str]: List of closed device IDs
        """
        closed_devices = []
        
        # Find all connected devices for this driver
        for device_key in list(self.device_states.keys()):
            key_driver_name, device_id = self._parse_device_key(device_key)
            
            if key_driver_name == driver_name:
                try:
                    driver = self.get_driver_instance(driver_name)
                    if driver:
                        device = driver.get_device(device_id)
                        if device:
                            self._manage_device_lifecycle(
                                driver_name=driver_name,
                                action='close',
                                device=device
                            )
                            closed_devices.append(device_id)
                            logger.info(f"Closed device {device_id} for disabled driver {driver_name}")
                except Exception as e:
                    logger.error(f"Error closing device {device_id} for driver {driver_name}: {e}")
        
        return closed_devices
    
    def is_driver_enabled(self, driver_name: str) -> bool:
        """Check if a driver is enabled
        
        Args:
            driver_name: Driver name to check
            
        Returns:
            bool: True if driver is enabled, False otherwise
        """
        if driver_name not in self.drivers:
            return False
            
        return self.driver_states.get(driver_name, True)
    
    def get_driver_states(self) -> Dict[str, Dict]:
        """Get states of all drivers
        
        Returns:
            Dict[str, Dict]: Dictionary of driver states
        """
        try:
            result: Dict[str, Dict] = {}
            persisted = self._driver_state_repo.list_enabled()
            for driver_name in self.drivers.keys():
                enabled = persisted.get(driver_name, True)
                result[driver_name] = {
                    "driver_name": driver_name,
                    "enabled": bool(enabled),
                    "description": None,
                    "last_updated": None,
                }
            return result
        except Exception as e:
            logger.error(f"Error getting driver states: {e}")
            return {}
