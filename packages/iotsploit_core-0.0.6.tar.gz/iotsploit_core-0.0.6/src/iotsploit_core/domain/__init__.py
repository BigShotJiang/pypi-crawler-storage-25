"""Domain layer (framework-agnostic)."""


