#!/usr/bin/env python

# =============================================================================
# Imports
# =============================================================================
import os
import argparse
import numpy as np
from mpi4py import MPI
import openmdao.api as om
from mphys.multipoint import Multipoint
from dafoam.mphys import DAFoamBuilder, OptFuncs, DAFoamLinearConstraint, DAFoamVSPVolume
from mphys.scenario_aerodynamic import ScenarioAerodynamic
from pygeo.mphys import OM_DVGEOCOMP

parser = argparse.ArgumentParser()
parser.add_argument("-optimizer", help="optimizer to use", type=str, default="IPOPT")
parser.add_argument("-task", help="type of run to do", type=str, default="run_model")
parser.add_argument("-angle_of_attack", help="angle of attack", type=float, default=3.0)
parser.add_argument("-mach_number", help="mach number", type=float, default=0.3)
parser.add_argument(
    "-solver_name",
    help="Resolved solver name passed by the calling skill.",
    type=str,
    required=True,
)
parser.add_argument("-reynolds_number", help="Reynolds number", type=float, default=1000000.0)
parser.add_argument("-lift_constraint", help="The lift constraint", type=float, default=0.5)
parser.add_argument("-max_opt_iters", help="The max optimization iterations", type=int, default=20)
parser.add_argument("-max_flow_iters", help="The max flow iterations", type=int, default=3000)
parser.add_argument(
    "-cst_coeffs",
    help="Initial CST coefficients for the VSP geometry path, ordered as [upper..., lower...].",
    type=float,
    nargs="+",
    default=None,
)
parser.add_argument(
    "-thickness_constraint", help="Thickness constraint lower bound (-1 to disable)", type=float, default=0.5
)
parser.add_argument(
    "-le_radius_constraint", help="LE radius constraint lower bound (-1 to disable)", type=float, default=-1
)
args = parser.parse_args()
# Validate the user-provided CST coefficients once and reuse the resolved count below.
if args.cst_coeffs is None:
    raise ValueError("cst_coeffs must be provided for the VSP geometry path.")
if len(args.cst_coeffs) < 2 or len(args.cst_coeffs) % 2 != 0:
    raise ValueError(
        "cst_coeffs must contain an even number of CST coefficients "
        f"(upper surface followed by lower surface), got {len(args.cst_coeffs)}"
    )
n_cst_coeffs = len(args.cst_coeffs) // 2

# =============================================================================
# Input Parameters
# =============================================================================

# Clean up previous run results
if MPI.COMM_WORLD.rank == 0:
    os.system("rm -rf postProcessing")
    os.system("rm -rf processor* 0.00* ")
    os.system("rm -rf *.bin *.info *.jpeg *.png reports *.hst")
    os.system("rm -rf {1..9}*")
    # Update the copied controlDict before the primal run so the iteration cap is reproducible.
    os.system(f"sed -i 's/^endTime.*/endTime         {int(args.max_flow_iters)};/' system/controlDict")
    os.system(f"sed -i 's/^writeInterval.*/writeInterval   {int(args.max_flow_iters)};/' system/controlDict")

T0 = 300.0
nuTilda0 = 4.5e-5

L0 = 1.0
R = 287.0
k = 1.4
C = float(np.sqrt(k * R * T0))
U0 = args.mach_number * C

lift_constraint = args.lift_constraint
aoa0 = args.angle_of_attack
A0 = 0.01
Ux = float(U0 * np.cos(np.radians(aoa0)))
Uz = float(U0 * np.sin(np.radians(aoa0)))

solverName = args.solver_name
if solverName == "DASimpleFoam":
    transonicPC = 0
    p0 = 0.0
    rho0 = 1.0
    p_norm = U0 * U0 / 2.0
    IC = {"U": [Ux, 0.0, Uz], "p": p0}
elif solverName == "DARhoSimpleFoam":
    transonicPC = 0
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    IC = {"U": [Ux, 0.0, Uz], "p": p0, "T": T0}
elif solverName == "DARhoSimpleCFoam":
    transonicPC = 1
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    IC = {"U": [Ux, 0.0, Uz], "p": p0, "T": T0}
elif solverName == "DAHisaFoam":
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    transonicPC = 1  # this is actually not used in hisa
    IC = {"U": [Ux, 0.0, Uz], "p": p0, "T": T0}
else:
    raise ValueError(f"Unsupported solverName `{solverName}`")

nu = U0 * L0 / args.reynolds_number
mu = nu * rho0


if solverName == "DAHisaFoam":
    BC = {
        "charFarFieldBC": [Ux, 0.0, Uz, p0, T0],
        "thermo:mu": mu,
        "useWallFunction": False,
    }
elif solverName == "DASimpleFoam":
    BC = {
        "U0": {"variable": "U", "patches": ["inout"], "value": [Ux, 0.0, Uz]},
        "p0": {"variable": "p", "patches": ["inout"], "value": [p0]},
        "nuTilda0": {"variable": "nuTilda", "patches": ["inout"], "value": [nuTilda0]},
        "transport:nu": nu,
        "useWallFunction": True,
    }
else:
    BC = {
        "U0": {"variable": "U", "patches": ["inout"], "value": [Ux, 0.0, Uz]},
        "p0": {"variable": "p", "patches": ["inout"], "value": [p0]},
        "T0": {"variable": "T", "patches": ["inout"], "value": [T0]},
        "nuTilda0": {"variable": "nuTilda", "patches": ["inout"], "value": [nuTilda0]},
        "thermo:mu": mu,
        "useWallFunction": True,
    }

# Input parameters for DAFoam
daOptions = {
    "designSurfaces": ["wing"],
    "solverName": solverName,
    "transonicPCOption": transonicPC,
    "primalMinResTol": 1.0e-7,
    "primalMinResTolDiff": 1e3,
    "primalFuncStdTol": {"tol": 1e-5, "funcName": "CD", "nStepsFrac": 0.2},
    "primalMinIters": 50,
    "printInterval": 10,
    "primalInitCondition": IC,
    "primalBC": BC,
    "function": {
        "CD": {
            "type": "force",
            "source": "patchToFace",
            "patches": ["wing"],
            "directionMode": "parallelToFlow",
            "patchVelocityInputName": "patchV",
            "scale": 1.0 / (0.5 * U0 * U0 * A0 * rho0),
        },
        "CL": {
            "type": "force",
            "source": "patchToFace",
            "patches": ["wing"],
            "directionMode": "normalToFlow",
            "patchVelocityInputName": "patchV",
            "scale": 1.0 / (0.5 * U0 * U0 * A0 * rho0),
        },
        "CM": {
            "type": "moment",
            "source": "patchToFace",
            "patches": ["wing"],
            "axis": [0.0, 1.0, 0.0],
            "center": [0.25, 0.0, 0.0],
            "scale": 1.0 / (0.5 * U0 * U0 * A0 * rho0 * L0),
        },
    },
    "adjStateOrdering": "cell",
    "adjEqnOption": {
        "gmresRelTol": 1.0e-5,
        "pcFillLevel": 1,
        "jacMatReOrdering": "natural",
    },
    "normalizeStates": {
        "U": U0,
        "p": p_norm,
        "T": T0,
        "nuTilda": nuTilda0 * 10.0,
        "phi": 1.0,
    },
    "inputInfo": {
        "aero_vol_coords": {"type": "volCoord", "components": ["solver", "function"]},
        "patchV": {
            "type": "patchVelocity",
            "patches": ["inout"],
            "flowAxis": "x",
            "normalAxis": "z",
            "components": ["solver", "function"],
        },
    },
    "checkMeshThreshold": {
        "maxNonOrth": 70.0,
        "maxSkewness": 6.0,
        "maxAspectRatio": 10000.0,
    },
}

# Mesh deformation setup
meshOptions = {
    "gridFile": os.getcwd(),
    "fileType": "OpenFOAM",
    # point and normal for the symmetry plane
    "symmetryPlanes": [
        [[0.0, 0.0, 0.0], [0.0, 1.0, 0.0]],
        [[0.0, 0.01, 0.0], [0.0, 1.0, 0.0]],
    ],
}


# Top class to setup the optimization problem
class Top(Multipoint):
    def setup(self):

        # create the builder to initialize the DASolvers
        dafoam_builder = DAFoamBuilder(daOptions, meshOptions, scenario="aerodynamic")
        dafoam_builder.initialize(self.comm)

        # add the design variable component to keep the top level design variables
        self.add_subsystem("dvs", om.IndepVarComp(), promotes=["*"])

        # add the mesh component
        self.add_subsystem("mesh", dafoam_builder.get_mesh_coordinate_subsystem())

        # Always use the case-local OpenVSP geometry for airfoil design updates.
        self.add_subsystem("geometry", OM_DVGEOCOMP(file="airfoil.vsp3", type="vsp"))

        # add a scenario (flow condition) for optimization, we pass the builder
        # to the scenario to actually run the flow and adjoint
        self.mphys_add_scenario("scenario1", ScenarioAerodynamic(aero_builder=dafoam_builder))

        # need to manually connect the x_aero0 between the mesh and geometry components
        # here x_aero0 means the surface coordinates of structurally undeformed mesh
        self.connect("mesh.x_aero0", "geometry.x_aero_in")
        # need to manually connect the x_aero0 between the geometry component and the scenario1
        # scenario group
        self.connect("geometry.x_aero0", "scenario1.x_aero")

        # Thickness and LE continuity constraints operate on the CST design variables directly.
        varA = []
        varB = []
        for j in range(n_cst_coeffs):
            varA.append(f"UpperCoeff_{j}")
            varB.append(f"LowerCoeff_{j}")
        self.add_subsystem(
            "thickness",
            DAFoamLinearConstraint(
                varA=varA, coeffA=1.0, varB=varB, coeffB=-1.0, size=1, output_name="thickness_val"
            ),
            promotes=["*"],
        )

        self.add_subsystem(
            "le_c1",
            DAFoamLinearConstraint(
                varA=["UpperCoeff_0"],
                coeffA=1.0,
                varB=["LowerCoeff_0"],
                coeffB=1.0,
                size=1,
                output_name="le_c1_val",
            ),
            promotes=["*"],
        )

        vsp_vars = []
        for i in range(2):
            for j in range(n_cst_coeffs):
                vsp_vars.append(f"Airfoil:UpperCoeff_{i}:Au_{j}")
                vsp_vars.append(f"Airfoil:LowerCoeff_{i}:Al_{j}")
        self.add_subsystem(
            "volume",
            DAFoamVSPVolume(
                vsp_file="airfoil.vsp3",
                vsp_vars=vsp_vars,
                slice_dir="x",
                n_slices=10,
                output_name="volume_val",
                step=1e-3,
                relativeStep=False,
            ),
        )

    def configure(self):

        # get the surface coordinates from the mesh component
        points = self.mesh.mphys_get_surface_mesh()

        # add pointset to the geometry component
        self.geometry.nom_add_discipline_coords("aero", points)

        # set the triangular points to the geometry component for geometric constraints
        tri_points = self.mesh.mphys_get_triangulated_surface()
        self.geometry.nom_setConstraintSurface(tri_points)

        # Register the CST coefficients on both airfoil sections so one DV updates the whole 2D extrusion.
        for i in range(2):
            for j in range(n_cst_coeffs):
                self.geometry.nom_addVSPVariable("Airfoil", f"UpperCoeff_{i}", f"Au_{j}", scaledStep=False, dh=1e-3)
                self.geometry.nom_addVSPVariable("Airfoil", f"LowerCoeff_{i}", f"Al_{j}", scaledStep=False, dh=1e-3)

        for j in range(n_cst_coeffs):
            self.dvs.add_output(f"UpperCoeff_{j}", val=args.cst_coeffs[j])
            self.connect(f"UpperCoeff_{j}", f"geometry.Airfoil:UpperCoeff_0:Au_{j}")
            self.connect(f"UpperCoeff_{j}", f"geometry.Airfoil:UpperCoeff_1:Au_{j}")
            self.connect(f"UpperCoeff_{j}", f"volume.Airfoil:UpperCoeff_0:Au_{j}")
            self.connect(f"UpperCoeff_{j}", f"volume.Airfoil:UpperCoeff_1:Au_{j}")

            self.dvs.add_output(f"LowerCoeff_{j}", val=args.cst_coeffs[j + n_cst_coeffs])
            self.connect(f"LowerCoeff_{j}", f"geometry.Airfoil:LowerCoeff_0:Al_{j}")
            self.connect(f"LowerCoeff_{j}", f"geometry.Airfoil:LowerCoeff_1:Al_{j}")
            self.connect(f"LowerCoeff_{j}", f"volume.Airfoil:LowerCoeff_0:Al_{j}")
            self.connect(f"LowerCoeff_{j}", f"volume.Airfoil:LowerCoeff_1:Al_{j}")

        for j in range(n_cst_coeffs):
            self.add_design_var(f"UpperCoeff_{j}", lower=-1.0, upper=1.0, scaler=1.0)
            self.add_design_var(f"LowerCoeff_{j}", lower=-1.0, upper=1.0, scaler=1.0)

        self.dvs.add_output("patchV", val=np.array([U0, aoa0]))
        self.connect("patchV", "scenario1.patchV")
        self.add_design_var("patchV", lower=[U0, -10.0], upper=[U0, 10.0], scaler=0.1)

        self.add_objective("scenario1.aero_post.CD", scaler=1.0)
        self.add_constraint("scenario1.aero_post.CL", lower=lift_constraint, scaler=1.0)
        self.add_constraint("volume.volume_val", lower=1.0, scaler=1.0)

        if args.thickness_constraint >= 0:
            for j in range(1, n_cst_coeffs):
                lb = args.thickness_constraint * (args.cst_coeffs[j] - args.cst_coeffs[n_cst_coeffs + j])
                self.add_constraint(f"thickness_val_{j}", lower=lb, scaler=1.0, linear=True)
        if args.le_radius_constraint >= 0:
            lb = args.le_radius_constraint * (args.cst_coeffs[0] - args.cst_coeffs[n_cst_coeffs])
            self.add_constraint("thickness_val_0", lower=lb, scaler=1.0, linear=True)
        self.add_constraint("le_c1_val_0", equals=0.0, scaler=1.0, linear=True)


# OpenMDAO setup
prob = om.Problem()
prob.model = Top()
prob.setup(mode="rev")

# initialize the optimization function
optFuncs = OptFuncs(daOptions, prob)

# use pyoptsparse to setup optimization
prob.driver = om.pyOptSparseDriver()
prob.driver.options["optimizer"] = args.optimizer
# options for optimizers
if args.optimizer == "SNOPT":
    prob.driver.opt_settings = {
        "Major feasibility tolerance": 1.0e-4,
        "Major optimality tolerance": 1.0e-4,
        "Minor feasibility tolerance": 1.0e-4,
        "Verify level": -1,
        "Function precision": 1.0e-5,
        "Major iterations limit": args.max_opt_iters,
        "Nonderivative linesearch": None,
        "Print file": "opt_SNOPT_print.txt",
        "Summary file": "opt_SNOPT_summary.txt",
    }
elif args.optimizer == "IPOPT":
    prob.driver.opt_settings = {
        "tol": 1.0e-4,
        "constr_viol_tol": 1.0e-4,
        "max_iter": args.max_opt_iters,
        "print_level": 5,
        "output_file": "opt_IPOPT.txt",
        "mu_strategy": "adaptive",
        "limited_memory_max_history": 10,
        "nlp_scaling_method": "none",
        "alpha_for_y": "full",
        "recalc_y": "yes",
        "bound_frac": 1e-3,  # allow IPOPT to use init dv closer to upper bound
    }
elif args.optimizer == "SLSQP":
    prob.driver.opt_settings = {
        "ACC": 1.0e-4,
        "MAXIT": args.max_opt_iters,
        "IFILE": "opt_SLSQP.txt",
    }
else:
    print("optimizer arg not valid!")
    exit(1)

prob.driver.options["debug_print"] = ["nl_cons", "objs", "desvars"]
prob.driver.options["print_opt_prob"] = True
prob.driver.hist_file = "OptView.hst"

if args.task == "run_driver":
    # solve CL
    optFuncs.findFeasibleDesign(
        ["scenario1.aero_post.CL"],
        ["patchV"],
        targets=[lift_constraint * 1.001],
        designVarsComp=[1],
        epsFD=[1e-2],
        tol=1e-3,
    )
    # run the optimization
    prob.run_driver()
elif args.task == "run_model":
    # just run the primal once
    prob.run_model()
elif args.task == "compute_totals":
    # just run the primal and adjoint once
    prob.run_model()
    totals = prob.compute_totals()
    if MPI.COMM_WORLD.rank == 0:
        print(totals)
elif args.task == "check_totals":
    # verify the total derivatives against the finite-difference
    prob.run_model()
    prob.check_totals(compact_print=False, step=1e-3, form="central", step_calc="abs")
else:
    print("task arg not found!")
    exit(1)
