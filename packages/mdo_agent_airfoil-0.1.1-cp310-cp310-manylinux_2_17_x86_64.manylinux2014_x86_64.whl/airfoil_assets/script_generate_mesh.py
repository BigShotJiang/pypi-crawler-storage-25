#!/usr/bin/env python

import argparse

from mdo_agent_mesh import _resolve_airfoil_mesh_settings
from mdo_agent_mesh import extrude_volume_mesh
from mdo_agent_mesh import generate_airfoil_surface_mesh


def parse_args():
    parser = argparse.ArgumentParser(
        description="Thin mdo_agent_airfoil wrapper for case-local airfoil mesh generation."
    )
    parser.add_argument("-airfoil_profile", type=str, default="naca0012")
    parser.add_argument("-mesh_cells", type=int, default=6000)
    parser.add_argument("-blunt_te", type=float, default=0.01)
    parser.add_argument("-y_plus", type=float, default=50.0)
    parser.add_argument("-mach_number", type=float, default=0.3)
    parser.add_argument("-d0", type=float, default=-1.0)
    return parser.parse_args()


def main():
    args = parse_args()

    # Compose the shared airfoil surface and shared volume-extrusion APIs in the case-local workflow script.
    generate_airfoil_surface_mesh(
        airfoil_profile=args.airfoil_profile,
        mesh_cells=args.mesh_cells,
        blunt_te=args.blunt_te,
        output_dir=".",
        vsp3_file="airfoil.vsp3",
    )
    _, _, resolved_extrusion_layers = _resolve_airfoil_mesh_settings(args.mesh_cells)
    resolved_d0 = args.d0 if args.d0 >= 0.0 else None
    extrude_volume_mesh(
        input="airfoil.xyz",
        out_dir="constant/polyMesh",
        L=30.0,
        d0=resolved_d0,
        y_plus=args.y_plus,
        mach_number=args.mach_number,
        ref_chord=1.0,
        N=resolved_extrusion_layers,
        hyperbolic_sweeps=10,
        neighbor_rings=3,
        diffuse_start=0.002,
        mesh_2d=True,
        quiet=False,
    )


if __name__ == "__main__":
    main()
