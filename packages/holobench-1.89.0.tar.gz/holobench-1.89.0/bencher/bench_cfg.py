from __future__ import annotations

import argparse
import logging

from typing import Any, TypeVar

import param
import panel as pn
from datetime import datetime
from copy import deepcopy

from bencher.variables.sweep_base import hash_sha1, describe_variable, LEVEL_SAMPLES
from bencher.variables.time import TimeSnapshot, TimeEvent
from bencher.variables.results import OptDir
from bencher.results.composable_container.composable_container_base import PaneLayout
from bencher.job import Executors
from bencher.cache_management import CACHE_VERSION
from bencher.results.laxtex_result import to_latex

T = TypeVar("T")  # Generic type variable


class BenchPlotSrvCfg(param.Parameterized):
    """Configuration for the benchmarking plot server.

    This class defines parameters for controlling how the benchmark visualization
    server operates, including network configuration.

    Attributes:
        port (int): The port to launch panel with
        allow_ws_origin (bool): Add the port to the whitelist (warning will disable remote
                               access if set to true)
        show (bool): Open the served page in a web browser
    """

    port: int | None = param.Integer(None, doc="The port to launch panel with")
    allow_ws_origin: bool = param.Boolean(
        False,
        doc="Add the port to the whitelist, (warning will disable remote access if set to true)",
    )
    show: bool = param.Boolean(True, doc="Open the served page in a web browser")


class BenchRunCfg(BenchPlotSrvCfg):
    """Configuration class for benchmark execution parameters.

    This class extends BenchPlotSrvCfg to provide comprehensive control over benchmark execution,
    including caching behavior, reporting options, visualization settings, and execution strategy.
    It defines numerous parameters that control how benchmark runs are performed, cached,
    and displayed to the user.

    Quick-start examples::

        # Use defaults — each variable uses its own ``samples`` setting:
        run_cfg = BenchRunCfg()

        # Set a sampling level (geometrically increasing sample counts):
        run_cfg = BenchRunCfg(level=5)        # 9 samples per variable
        run_cfg = BenchRunCfg(level=8)        # 65 samples per variable

        # Or set an exact sample count directly:
        run_cfg = BenchRunCfg(samples_per_var=20)

    Level-to-samples mapping
    ~~~~~~~~~~~~~~~~~~~~~~~~
    ====== ======= ====== ======= ====== =======
    Level  Samples Level  Samples Level  Samples
    ====== ======= ====== ======= ====== =======
    1      1       5      9       9      129
    2      2       6      17      10     257
    3      3       7      33      11     513
    4      5       8      65      12     1025
    ====== ======= ====== ======= ====== =======

    Attributes:
        repeats (int): The number of times to sample the inputs
        over_time (bool): If true each time the function is called it will plot a
                         timeseries of historical and the latest result
        use_optuna (bool): Show optuna plots
        summarise_constant_inputs (bool): Print the inputs that are kept constant
                                         when describing the sweep parameters
        print_bench_inputs (bool): Print the inputs to the benchmark function
                                  every time it is called
        print_bench_results (bool): Print the results of the benchmark function
                                   every time it is called
        clear_history (bool): Clear historical results
        max_time_events (int): Maximum number of over_time events to retain. None means unlimited.
        max_slider_points (int): Maximum time points in the over_time slider. Defaults to 10,
                                None means all.
        show_aggregated_time_tab (bool): Show the aggregated tab for over_time plots.
                                        Defaults to False.
        show_aggregate_plots (bool): Show aggregated BandResult plots when aggregate is set.
        print_pandas (bool): Print a pandas summary of the results to the console
        print_xarray (bool): Print an xarray summary of the results to the console
        serve_pandas (bool): Serve a pandas summary on the results webpage
        serve_pandas_flat (bool): Serve a flattened pandas summary on the results webpage
        serve_xarray (bool): Serve an xarray summary on the results webpage
        auto_plot (bool): Automatically deduce the best type of plot for the results
        raise_duplicate_exception (bool): Used to debug unique plot names
        cache_results (bool): Benchmark level cache for completed benchmark results
        clear_cache (bool): Clear the cache of saved input->output mappings
        cache_samples (bool): Enable per-sample caching
        only_hash_tag (bool): Use only the tag hash for cache identification
        clear_sample_cache (bool): Clear the per-sample cache
        overwrite_sample_cache (bool): Recalculate and overwrite cached sample values
        only_plot (bool): Do not calculate benchmarks if no results are found in cache
        use_holoview (bool): Use holoview for plotting
        nightly (bool): Run a more extensive set of tests for a nightly benchmark
        time_event (str): String representation of a sequence over time
        headless (bool): Run the benchmarks headlessly
        dry_run (bool): Preview sweep grid without executing the benchmark function
        level (int): Method of defining the number of samples to sweep over
        samples_per_var (int | None): Explicit sample count per variable (overrides level)
        run_tag (str): Tag for isolating cached results
        run_date (datetime): Date the benchmark run was performed
        executor (Executors): Executor for running the benchmark
        plot_size (int): Sets both width and height of the plot
        plot_width (int): Sets width of the plots
        plot_height (int): Sets height of the plot
    """

    # ==================== EXECUTION PARAMETERS ====================
    # These parameters control how the benchmark function is executed

    repeats: int = param.Integer(1, doc="The number of times to sample the inputs")

    level: int = param.Integer(
        default=0,
        bounds=[0, 12],
        doc="Controls sample count for every sweep variable at once. "
        "Level 0 (default) uses each variable's own `samples` setting. "
        "Levels 1-12 override with geometrically increasing counts: "
        "1→1, 2→2, 3→3, 4→5, 5→9, 6→17, 7→33, 8→65, 9→129, 10→257, 11→513, 12→1025. "
        "Use `BenchRunCfg.level_to_samples(level)` to query programmatically, "
        "or set `samples_per_var` for a direct sample count.",
    )

    samples_per_var: int | None = param.Integer(
        default=None,
        allow_None=True,
        bounds=(1, None),
        doc="Explicit number of samples per sweep variable. "
        "When set, takes precedence over `level`. "
        "Example: samples_per_var=20 gives exactly 20 samples for every input variable.",
    )

    executor = param.Selector(
        objects=list(Executors),
        doc="The function can be run serially or in parallel with different futures executors",
    )

    nightly: bool = param.Boolean(
        False, doc="Run a more extensive set of tests for a nightly benchmark"
    )

    headless: bool = param.Boolean(False, doc="Run the benchmarks headlessly")

    dry_run: bool = param.Boolean(
        False,
        doc="When True, plot_sweep() computes the sweep grid and logs a summary "
        "(total combinations, parameter ranges, evaluation count) without "
        "executing the benchmark function.",
    )

    # ==================== CACHE PARAMETERS ====================
    # These parameters control caching behavior at both benchmark and sample level

    cache_results: bool = param.Boolean(
        False,
        doc="This is a benchmark level cache that stores the results of a fully completed benchmark. At the end of a benchmark the values are added to the cache but are not if the benchmark does not complete.  If you want to cache values during the benchmark you need to use the cache_samples option. Beware that depending on how you change code in the objective function, the cache could provide values that are not correct.",
    )

    cache_samples: bool = param.Boolean(
        False,
        doc="If true, every time the benchmark function is called, bencher will check if that value has been calculated before and if so load the from the cache.  Note that the sample level cache is different from the benchmark level cache which only caches the aggregate of all the results at the end of the benchmark. This cache lets you stop a benchmark halfway through and continue. However, beware that depending on how you change code in the objective function, the cache could provide values that are not correct.",
    )

    clear_cache: bool = param.Boolean(
        False, doc=" Clear the cache of saved input->output mappings."
    )

    clear_sample_cache: bool = param.Boolean(
        False,
        doc="Clears the per-sample cache.  Use this if you get unexpected behavior.  The per_sample cache is tagged by the specific benchmark it was sampled from. So clearing the cache of one benchmark will not clear the cache of other benchmarks.",
    )

    overwrite_sample_cache: bool = param.Boolean(
        False,
        doc="If True, recalculate the value and overwrite the value stored in the sample cache",
    )

    only_hash_tag: bool = param.Boolean(
        False,
        doc="By default when checking if a sample has been calculated before it includes the hash of the greater benchmarking context.  This is safer because it means that data generated from one benchmark will not affect data from another benchmark.  However, if you are careful it can be more flexible to ignore which benchmark generated the data and only use the tag hash to check if that data has been calculated before. ie, you can create two benchmarks that sample a subset of the problem during exploration and give them the same tag, and then afterwards create a larger benchmark that covers the cases you already explored.  If this value is true, the combined benchmark will use any data from other benchmarks with the same tag.",
    )

    only_plot: bool = param.Boolean(
        False, doc="Do not attempt to calculate benchmarks if no results are found in the cache"
    )

    cache_size: int = param.Integer(
        default=None,
        allow_None=True,
        bounds=(1, None),
        doc="Maximum size of the disk cache in megabytes (MB). If None, uses the default (100 GB).",
    )

    # ==================== DISPLAY PARAMETERS ====================
    # These parameters control console output and reporting

    print_bench_inputs: bool = param.Boolean(
        True, doc="Print the inputs to the benchmark function every time it is called"
    )

    print_bench_results: bool = param.Boolean(
        True, doc="Print the results of the benchmark function every time it is called"
    )

    summarise_constant_inputs: bool = param.Boolean(
        True, doc="Print the inputs that are kept constant when describing the sweep parameters"
    )

    print_pandas: bool = param.Boolean(
        False, doc="Print a pandas summary of the results to the console."
    )

    print_xarray: bool = param.Boolean(
        False, doc="Print an xarray summary of the results to the console"
    )

    serve_pandas: bool = param.Boolean(
        False,
        doc="Serve a pandas summary on the results webpage.  If you have a large dataset consider setting this to false if the page loading is slow",
    )

    serve_pandas_flat: bool = param.Boolean(
        True,
        doc="Serve a flattened pandas summary on the results webpage.  If you have a large dataset consider setting this to false if the page loading is slow",
    )

    serve_xarray: bool = param.Boolean(
        False,
        doc="Serve an xarray summary on the results webpage. If you have a large dataset consider setting this to false if the page loading is slow",
    )

    # ==================== VISUALIZATION PARAMETERS ====================
    # These parameters control plotting and visualization

    auto_plot: bool = param.Boolean(
        True, doc=" Automatically dedeuce the best type of plot for the results."
    )

    use_holoview: bool = param.Boolean(False, doc="Use holoview for plotting")

    use_optuna: bool = param.Boolean(False, doc="show optuna plots")

    plot_size: int | None = param.Integer(default=None, doc="Sets the width and height of the plot")

    plot_width: int | None = param.Integer(
        default=None,
        doc="Sets with width of the plots, this will override the plot_size parameter",
    )

    plot_height: int | None = param.Integer(
        default=None, doc="Sets the height of the plot, this will override the plot_size parameter"
    )

    raise_duplicate_exception: bool = param.Boolean(False, doc=" Used to debug unique plot names.")

    pane_layout = param.Selector(
        default=PaneLayout.grid,
        objects=list(PaneLayout),
        doc="Controls how multi-dimensional data is laid out in panel displays. "
        "'grid' uses rows/columns (default). "
        "'tabs' uses tabs for all outer dimensions. "
        "'tabs_and_grid' uses tabs for the outermost dimension and grid for inner ones.",
    )

    backend = param.Selector(
        default="panel",
        objects=["panel", "rerun"],
        doc="Visualization backend. 'panel' uses the default holoviews/panel plotting pipeline. "
        "'rerun' renders N-dimensional benchmark data in the rerun viewer.",
    )

    # ==================== TIME & HISTORY PARAMETERS ====================
    # These parameters control time-based features and historical tracking

    over_time: bool = param.Boolean(
        False,
        doc="If true each time the function is called it will plot a timeseries of historical and the latest result.",
    )

    clear_history: bool = param.Boolean(False, doc="Clear historical results")

    max_time_events: int | None = param.Integer(
        None,
        bounds=[1, None],
        allow_None=True,
        doc="Maximum number of over_time events to retain. "
        "Oldest events are trimmed. Set to None for unlimited.",
    )

    max_slider_points: int | None = param.Integer(
        10,
        bounds=[2, None],
        allow_None=True,
        doc="Maximum number of time points shown in the over_time slider. "
        "Evenly subsampled (first and last always included). "
        "The aggregated tab still uses all data. "
        "Defaults to 10 to cap embed cost. Set to None for no subsampling.",
    )

    show_aggregated_time_tab: bool = param.Boolean(
        False,
        doc="When over_time is active, show an 'All Time Points (aggregated)' tab "
        "alongside the per-time-point slider. Defaults to False for performance. "
        "Set True to enable the aggregation view.",
    )

    show_aggregate_plots: bool = param.Boolean(
        True,
        doc="When aggregate is set on plot_sweep, show the aggregated BandResult "
        "plots in the auto-plots view. Set False to skip the aggregation "
        "computation and extra render, improving performance.",
    )

    time_event: str | None = param.String(
        None,
        doc="A string representation of a sequence over time, i.e. datetime, pull request number, or run number",
    )

    run_tag: str = param.String(
        default="",
        doc="Define a tag for a run to isolate the results stored in the cache from other runs",
    )

    run_date: datetime = param.Date(
        default=None,
        doc="The date the bench run was performed",
    )

    # ==================== REGRESSION DETECTION PARAMETERS ====================
    # These parameters control automatic regression detection for over_time benchmarks

    regression_detection: bool = param.Boolean(
        False,
        doc="Enable regression detection when over_time is True. After loading history, "
        "statistically compare the latest run against historical data.",
    )

    regression_method: str = param.Selector(
        default="adaptive",
        objects=["percentage", "adaptive", "delta", "absolute"],
        doc="Detection method. 'percentage': mean comparison vs historical mean. "
        "'adaptive': robust MAD-based step + drift test for noisy metrics. "
        "'delta': absolute-unit change vs historical mean (uses regression_delta). "
        "'absolute': hard directional threshold, no history required (uses "
        "regression_absolute).",
    )

    regression_mad: float = param.Number(
        default=3.5,
        doc="Step-test threshold for the 'adaptive' method, in robust MAD-sigma "
        "units. A current value more than this many MAD-sigma from the historical "
        "median (in the regression direction) is flagged. Higher = less sensitive.",
    )

    regression_percentage: float = param.Number(
        default=10.0,
        doc="Minimum directional percent change required to flag a regression. "
        "For 'percentage' method this is the primary threshold. For 'adaptive' "
        "method it acts as a dual-band AND gate alongside regression_mad: a "
        "regression only fires when BOTH the MAD-based test AND the percent "
        "change exceed their thresholds. Suppresses noise-floor false positives "
        "on low-repeat or integer-valued metrics where the MAD noise floor can "
        "collapse to zero.",
    )

    regression_delta: float = param.Number(
        default=None,
        allow_None=True,
        doc="Threshold for regression_method='delta'. Largest acceptable "
        "absolute-unit delta of the current run's mean from the mean of all "
        "historical per-time means, respecting the result variable's OptDir "
        "(minimize: curr - hist must not exceed; maximize: hist - curr must "
        "not exceed). Ignored when regression_method is not 'delta'.",
    )

    regression_absolute: float = param.Number(
        default=None,
        allow_None=True,
        doc="Threshold for regression_method='absolute'. Hard directional limit "
        "the current run's mean must not violate in the direction of the result "
        "variable's OptDir (minimize: ceiling; maximize: floor). No history "
        "required — fires on the first recording. Ignored when regression_method "
        "is not 'absolute'.",
    )

    regression_fail: bool = param.Boolean(
        False,
        doc="If True, raise RegressionError when a regression is detected. "
        "Useful for failing CI pipelines on benchmark regressions.",
    )

    def __init__(self, **params: Any) -> None:
        """Initialize BenchRunCfg with current datetime if not provided."""
        if "run_date" not in params:
            params["run_date"] = datetime.now()
        super().__init__(**params)

    @staticmethod
    def from_cmd_line() -> BenchRunCfg:  # pragma: no cover
        """Create a BenchRunCfg by parsing command line arguments.

        Parses command line arguments to create a configuration for benchmark runs.

        Returns:
            BenchRunCfg: Configuration object with settings from command line arguments
        """

        parser = argparse.ArgumentParser(description="benchmark")

        parser.add_argument(
            "--use-cache",
            action="store_true",
            help=BenchRunCfg.param.cache_results.doc,
        )

        parser.add_argument(
            "--only-plot",
            action="store_true",
            help=BenchRunCfg.param.only_plot.doc,
        )

        parser.add_argument(
            "--port",
            type=int,
            help=BenchRunCfg.param.port.doc,
        )

        parser.add_argument(
            "--nightly",
            action="store_true",
            help="Turn on nightly benchmarking",
        )

        parser.add_argument(
            "--time_event",
            type=str,
            default=BenchRunCfg.param.time_event.default,
            help=BenchRunCfg.param.time_event.doc,
        )

        parser.add_argument(
            "--repeats",
            type=int,
            default=BenchRunCfg.param.repeats.default,
            help=BenchRunCfg.param.repeats.doc,
        )

        return BenchRunCfg(**vars(parser.parse_args()))

    @staticmethod
    def level_to_samples(level: int, max_level: int = 12) -> int:
        """Return the number of samples-per-variable for a given *level*.

        Args:
            level: Sampling level (1-12).
            max_level: Cap applied before lookup. Defaults to 12.

        Returns:
            The sample count for this level.

        Raises:
            ValueError: If *level* is out of range.

        Example::

            >>> BenchRunCfg.level_to_samples(5)
            9
        """
        if level < 1 or level >= len(LEVEL_SAMPLES):
            raise ValueError(f"level must be between 1 and {len(LEVEL_SAMPLES) - 1}, got {level}")
        return LEVEL_SAMPLES[min(max_level, level)]

    def deep(self):
        return deepcopy(self)

    @classmethod
    def with_defaults(cls, run_cfg=None, **defaults):
        """Merge *defaults* into *run_cfg*, creating a new instance when needed.

        When *run_cfg* is ``None`` a fresh ``BenchRunCfg`` is created with *defaults*.
        When *run_cfg* is provided, a shallow copy is made and each default is applied
        only if the corresponding field is still at its param-level default value
        (i.e. the caller did not explicitly set it).  The original *run_cfg* is never
        mutated.  This lets benchmark functions declare sensible defaults while still
        allowing callers to override::

            run_cfg = bn.BenchRunCfg.with_defaults(run_cfg, repeats=5, level=4)

        Raises:
            ValueError: If any key in *defaults* is not a recognised parameter.
        """
        unknown = set(defaults) - set(cls.param)
        if unknown:
            raise ValueError(f"Unknown BenchRunCfg parameter(s): {', '.join(sorted(unknown))}")
        if run_cfg is None:
            return cls(**defaults)
        result = deepcopy(run_cfg)
        for key, value in defaults.items():
            if getattr(result, key) == cls.param[key].default:  # pylint: disable=unsubscriptable-object
                setattr(result, key, value)
        return result


class BenchCfg(BenchRunCfg):
    """Complete configuration for a benchmark protocol.

    This class extends BenchRunCfg and provides a comprehensive set of parameters
    for configuring benchmark runs. It maintains a unique hash value based on its
    configuration to ensure that benchmark results can be consistently referenced
    and that plots are uniquely identified across runs.

    The class handles input variables, result variables, constant values, meta variables,
    and various presentation options. It also provides methods for generating
    descriptive summaries and visualizations of the benchmark configuration.

    Attributes:
        input_vars (list): A list of ParameterizedSweep variables to perform a parameter sweep over
        result_vars (list): A list of ParameterizedSweep results to collect and plot
        const_vars (list): Variables to keep constant but are different from the default value
        result_hmaps (list): A list of holomap results
        meta_vars (list): Meta variables such as recording time and repeat id
        all_vars (list): Stores a list of both the input_vars and meta_vars
        iv_time (list[TimeSnapshot | TimeEvent]): Parameter for sampling the same inputs over time
        over_time (bool): Controls whether the function is sampled over time
        name (str): The name of the benchmarkCfg
        title (str): The title of the benchmark
        raise_duplicate_exception (bool): Used for debugging filename generation uniqueness
        bench_name (str): The name of the benchmark and save folder
        description (str): A longer description of the benchmark function
        post_description (str): Comments on the output of the graphs
        has_results (bool): Whether this config has results
        pass_repeat (bool): Whether to pass the 'repeat' kwarg to the benchmark function
        tag (str): Tags for grouping different benchmarks
        hash_value (str): Stored hash value of the config
        plot_callbacks (list): Callables that take a BenchResult and return panel representation
    """

    input_vars = param.List(
        default=None,
        doc="A list of ParameterizedSweep variables to perform a parameter sweep over",
    )
    result_vars = param.List(
        default=None,
        doc="A list of ParameterizedSweep results collect and plot.",
    )

    const_vars = param.List(
        default=None,
        doc="Variables to keep constant but are different from the default value",
    )

    result_hmaps = param.List(default=None, doc="a list of holomap results")

    meta_vars = param.List(
        default=None,
        doc="Meta variables such as recording time and repeat id",
    )
    all_vars = param.List(
        default=None,
        doc="Stores a list of both the input_vars and meta_vars that are used to define a unique hash for the input",
    )
    iv_time = param.List(
        default=[],
        item_type=TimeSnapshot | TimeEvent,
        doc="A parameter to represent the sampling the same inputs over time as a scalar type",
    )

    # Note: over_time is already inherited from BenchRunCfg
    name: str | None = param.String(None, doc="The name of the benchmarkCfg")
    title: str | None = param.String(None, doc="The title of the benchmark")
    raise_duplicate_exception: bool = param.Boolean(
        False, doc="Use this while debugging if filename generation is unique"
    )
    bench_name: str | None = param.String(
        None, doc="The name of the benchmark and the name of the save folder"
    )
    description: str | None = param.String(
        None,
        doc="A place to store a longer description of the function of the benchmark",
    )
    post_description: str | None = param.String(
        None, doc="A place to comment on the output of the graphs"
    )

    has_results: bool = param.Boolean(
        False,
        doc="If this config has results, true, otherwise used to store titles and other bench metadata",
    )

    pass_repeat: bool = param.Boolean(
        False,
        doc="By default do not pass the kwarg 'repeat' to the benchmark function.  Set to true if you want the benchmark function to be passed the repeat number",
    )

    tag: str = param.String(
        "",
        doc="Use tags to group different benchmarks together. By default benchmarks are considered distinct from each other and are identified by the hash of their name and inputs, constants and results and tag, but you can optionally change the hash value to only depend on the tag.  This way you can have multiple unrelated benchmarks share values with each other based only on the tag value.",
    )

    hash_value: str = param.String(
        "",
        doc="store the hash value of the config to avoid having to hash multiple times",
    )

    plot_callbacks = param.List(
        None,
        doc="A callable that takes a BenchResult and returns panel representation of the results",
    )

    agg_over_dims = param.List(
        default=None,
        doc="Dimension names to aggregate over when auto-appending aggregated views. "
        "When set, run_sweep will automatically append CurveResult (mean +/- std) "
        "and BandResult (percentile bands) with these dims collapsed.",
    )
    agg_fn = param.ObjectSelector(
        default="mean",
        objects=["mean", "sum", "max", "min", "median"],
        doc="Aggregation function to use when agg_over_dims is set.",
    )

    def __init__(self, **params: Any) -> None:
        """Initialize a BenchCfg with the given parameters.

        Args:
            **params (Any): Parameters to set on the BenchCfg
        """
        super().__init__(**params)
        self.plot_lib = None
        self.hmap_kdims = None
        self.iv_repeat = None

    def hash_persistent(self, include_repeats: bool) -> str:
        """Generate a persistent hash for the benchmark configuration.

        Overrides the default hash function because the default hash function does not
        return the same value for the same inputs. This method references only stable
        variables that are consistent across instances of BenchCfg with the same
        configuration.

        Args:
            include_repeats (bool): Whether to include repeats as part of the hash
                                   (True by default except when using the sample cache)

        Returns:
            str: A persistent hash value for the benchmark configuration
        """

        if include_repeats:
            # needed so that the historical xarray arrays are the same size
            repeats_hash = hash_sha1(self.repeats)
        else:
            repeats_hash = 0

        # NOTE: title is intentionally excluded from the hash so that renaming
        # a benchmark's display title does not invalidate cached results or
        # lose over_time history.  The benchmark is uniquely identified by
        # bench_name + input/result/const vars + tag + over_time + repeats.
        #
        # CACHE_VERSION is folded in so that bumping it atomically invalidates
        # every benchmark-level and over_time history key without relying
        # solely on the on-disk version-file check in ``ensure_cache_version``.
        hash_val = hash_sha1(
            (
                CACHE_VERSION,
                hash_sha1(str(self.bench_name)),
                hash_sha1(self.over_time),
                repeats_hash,
                hash_sha1(self.tag),
            )
        )
        all_vars = (self.input_vars or []) + (self.result_vars or [])
        for v in all_vars:
            hash_val = hash_sha1((hash_val, v.hash_persistent()))

        for v in self.const_vars or []:
            hash_val = hash_sha1((hash_val, v[0].hash_persistent(), hash_sha1(v[1])))

        return hash_val

    def inputs_as_str(self) -> list[str]:
        """Get a list of input variable names.

        Returns:
            list[str]: List of the names of input variables
        """
        return [i.name for i in self.input_vars]

    def to_latex(self) -> pn.pane.LaTeX | None:
        """Convert benchmark configuration to LaTeX representation.

        Returns:
            pn.pane.LaTeX | None: LaTeX representation of the benchmark configuration
        """
        return to_latex(self)

    def to_cartesian_animation(self) -> str | None:
        """Render an animation of the Cartesian product data collection.

        Delegates to :func:`bencher.results.manim_cartesian.render_animation`,
        which currently uses a PIL-based renderer. Returns the filesystem path
        to the generated animated PNG (or other format, depending on the
        renderer), or ``None`` on failure so callers can degrade gracefully.

        Returns:
            str | None: Path to the rendered animation file, or None on failure.
        """
        try:
            from bencher.results.manim_cartesian import from_bench_cfg, render_animation

            cfg = from_bench_cfg(self)
            return render_animation(cfg, width=350, height=250)
        except (ImportError, AttributeError, ValueError, RuntimeError, OSError) as e:
            # Log the exception so failures remain diagnosable while preserving
            # the existing graceful fallback behavior.
            logging.getLogger(__name__).exception(
                "Failed to render Cartesian animation for bench config %r: %s", self, e
            )
            return None

    def describe_sweep(
        self, width: int = 800, accordion: bool = True
    ) -> pn.pane.Markdown | pn.Column:
        """Produce a markdown summary of the sweep settings.

        Args:
            width (int): Width of the markdown panel in pixels. Defaults to 800.
            accordion (bool): Whether to wrap the description in an accordion. Defaults to True.

        Returns:
            pn.pane.Markdown | pn.Column: Panel containing the sweep description
        """

        latex = self.to_latex()
        desc = pn.pane.Markdown(self.describe_benchmark(), width=width)
        if accordion:
            desc = pn.Accordion(("Expand Full Data Collection Parameters", desc))

        sentence = self.sweep_sentence()

        parts = [sentence]
        if latex is not None:
            parts.append(latex)

        # Render Cartesian product animation (gracefully skipped on error)
        animation_path = self.to_cartesian_animation()
        if animation_path is not None:
            from pathlib import Path

            abs_path = str(Path(animation_path).resolve())
            parts.append(pn.pane.Image(abs_path, width=350))

        parts.append(desc)
        return pn.Column(*parts)

    def sweep_sentence(self) -> pn.pane.Markdown:
        """Generate a concise summary sentence of the sweep configuration.

        Returns:
            pn.pane.Markdown: A panel containing a markdown summary sentence
        """
        inputs = " by ".join([iv.name for iv in self.all_vars])

        all_vars_lens = [len(iv.values()) for iv in reversed(self.all_vars)]
        if len(all_vars_lens) == 1:
            all_vars_lens.append(1)
        result_sizes = "x".join([str(iv) for iv in all_vars_lens])
        results = ", ".join([rv.name for rv in self.result_vars])

        return pn.pane.Markdown(
            f"Sweeping {inputs} to generate a {result_sizes} result dataframe containing {results}. "
        )

    def describe_benchmark(self) -> str:
        """Generate a detailed string summary of the inputs and results from a BenchCfg.

        Returns:
            str: Comprehensive summary of BenchCfg
        """
        benchmark_sampling_str = ["```text"]
        benchmark_sampling_str.append("")

        benchmark_sampling_str.append("Input Variables:")
        for iv in self.input_vars:
            benchmark_sampling_str.extend(describe_variable(iv, True))

        if self.const_vars and (self.summarise_constant_inputs):
            benchmark_sampling_str.append("\nConstants:")
            for cv in self.const_vars:
                benchmark_sampling_str.extend(describe_variable(cv[0], False, cv[1]))

        benchmark_sampling_str.append("\nResult Variables:")
        for rv in self.result_vars:
            benchmark_sampling_str.extend(describe_variable(rv, False))

        benchmark_sampling_str.append("\nMeta Variables:")
        benchmark_sampling_str.append(f"    run date: {self.run_date}")
        if self.run_tag:
            benchmark_sampling_str.append(f"    run tag: {self.run_tag}")
        if self.level is not None:
            benchmark_sampling_str.append(f"    bench level: {self.level}")
        benchmark_sampling_str.append(f"    cache_results: {self.cache_results}")
        benchmark_sampling_str.append(f"    cache_samples {self.cache_samples}")
        benchmark_sampling_str.append(f"    only_hash_tag: {self.only_hash_tag}")
        benchmark_sampling_str.append(f"    executor: {self.executor}")

        for mv in self.meta_vars:
            benchmark_sampling_str.extend(describe_variable(mv, True))

        benchmark_sampling_str.append("```")

        benchmark_sampling_str = "\n".join(benchmark_sampling_str)
        return benchmark_sampling_str

    def to_title(self, panel_name: str | None = None) -> pn.pane.Markdown:
        """Create a markdown panel with the benchmark title.

        Args:
            panel_name (str | None): The name for the panel. Defaults to the benchmark title.

        Returns:
            pn.pane.Markdown: A panel with the benchmark title as a heading
        """
        if panel_name is None:
            panel_name = self.title
        return pn.pane.Markdown(f"# {self.title}", name=panel_name)

    def to_description(self, width: int = 800) -> pn.pane.Markdown:
        """Create a markdown panel with the benchmark description.

        Args:
            width (int): Width of the markdown panel in pixels. Defaults to 800.

        Returns:
            pn.pane.Markdown: A panel with the benchmark description
        """
        return pn.pane.Markdown(self.description or "", width=width)

    def to_post_description(self, width: int = 800) -> pn.pane.Markdown:
        """Create a markdown panel with the benchmark post-description.

        Args:
            width (int): Width of the markdown panel in pixels. Defaults to 800.

        Returns:
            pn.pane.Markdown: A panel with the benchmark post-description
        """
        return pn.pane.Markdown(self.post_description or "", width=width)

    def to_sweep_summary(
        self,
        name: str | None = None,
        description: bool = True,
        describe_sweep: bool = True,
        results_suffix: bool = True,
        title: bool = True,
    ) -> pn.Column:
        """Produce panel output summarising the title, description and sweep setting.

        Args:
            name (str | None): Name for the panel. Defaults to benchmark title or
                                 "Data Collection Parameters" if title is False.
            description (bool): Whether to include the benchmark description. Defaults to True.
            describe_sweep (bool): Whether to include the sweep description. Defaults to True.
            results_suffix (bool): Whether to add a "Results:" heading. Defaults to True.
            title (bool): Whether to include the benchmark title. Defaults to True.

        Returns:
            pn.Column: A panel with the benchmark summary
        """
        if name is None:
            if title:
                name = self.title
            else:
                name = "Data Collection Parameters"
        col = pn.Column(name=name)
        if title:
            col.append(self.to_title())
        if self.description is not None and description:
            col.append(self.to_description())
        if describe_sweep:
            col.append(self.describe_sweep())
        if results_suffix:
            col.append(pn.pane.Markdown("## Results:"))
        return col

    @staticmethod
    def partition_input_vars(vars_) -> tuple[list, list]:
        """Split variables into (optimized, non-optimized) based on the optimize flag."""
        opt = [v for v in vars_ if getattr(v, "optimize", True)]
        non_opt = [v for v in vars_ if not getattr(v, "optimize", True)]
        return opt, non_opt

    @property
    def optimized_input_vars(self) -> list:
        """Return input variables where optimize=True (suggested by Optuna)."""
        return self.partition_input_vars(self.input_vars or [])[0]

    @property
    def non_optimized_input_vars(self) -> list:
        """Return input variables where optimize=False (swept/aggregated, not suggested)."""
        return self.partition_input_vars(self.input_vars or [])[1]

    def optuna_targets(self, as_var: bool = False) -> list[Any]:
        """Get the list of result variables that are optimization targets.

        Args:
            as_var (bool): If True, return the variable objects rather than their names.
                          Defaults to False.

        Returns:
            list[Any]: List of result variable names or objects that are optimization targets
        """
        targets = []
        for rv in self.result_vars:
            if hasattr(rv, "direction") and rv.direction != OptDir.none:
                if as_var:
                    targets.append(rv)
                else:
                    targets.append(rv.name)
        return targets


class DimsCfg:
    """A class to store data about the sampling and result dimensions.

    This class processes a BenchCfg object to extract and organize information about
    the dimensions of the benchmark, including names, ranges, sizes, and coordinates.
    It is used to set up the structure for analyzing and visualizing benchmark results.

    Attributes:
        dims_name (list[str]): Names of the benchmark dimensions
        dim_ranges (list[list[Any]]): Values for each dimension
        dims_size (list[int]): Size (number of values) for each dimension
        dim_ranges_index (list[list[int]]): Indices for each dimension value
        dim_ranges_str (list[str]): String representation of dimension ranges
        coords (dict[str, list[Any]]): Mapping of dimension names to their values
    """

    def __init__(self, bench_cfg: BenchCfg) -> None:
        """Initialize the DimsCfg with dimension information from a benchmark configuration.

        Extracts dimension names, ranges, sizes, and coordinates from the provided benchmark
        configuration for use in organizing and analyzing benchmark results.

        Args:
            bench_cfg (BenchCfg): The benchmark configuration containing dimension information
        """
        self.dims_name: list[str] = [i.name for i in bench_cfg.all_vars]

        self.dim_ranges: list[list[Any]] = [i.values() for i in bench_cfg.all_vars]
        self.dims_size: list[int] = [len(p) for p in self.dim_ranges]
        self.dim_ranges_index: list[list[int]] = [list(range(i)) for i in self.dims_size]
        self.dim_ranges_str: list[str] = [f"{s}\n" for s in self.dim_ranges]
        self.coords: dict[str, list[Any]] = dict(zip(self.dims_name, self.dim_ranges))

        logging.debug(f"dims_name: {self.dims_name}")
        logging.debug(f"dim_ranges {self.dim_ranges_str}")
        logging.debug(f"dim_ranges_index {self.dim_ranges_index}")
        logging.debug(f"coords: {self.coords}")
