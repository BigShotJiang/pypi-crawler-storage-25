"""Deprecated alias package — forwards to :mod:`dsk`.

The implementation package was renamed from ``keeper_sdk`` to ``dsk`` to
align the import path with the long-standing ``dsk`` CLI binary and to
avoid implying any affiliation with Keeper Security. This module exists
as a one-shot deprecation alias so existing callers keep working while
they migrate their imports.

Migration::

    # Old (still works, emits DeprecationWarning once per process)
    from keeper_sdk.core import load_manifest
    from keeper_sdk import providers

    # New
    from dsk.core import load_manifest
    from dsk import providers

The ``keeper_sdk`` alias will be removed in a future major version.

Implementation note
-------------------
Two layers of aliasing are needed for full compatibility:

1.  Eager submodule registration for the top-level subpackages, so
    ``from keeper_sdk import auth, cli, core, ...`` returns the same
    module objects as ``from dsk import auth, cli, core, ...``.
2.  Bulk re-registration of every already-loaded ``dsk.*`` submodule
    under the ``keeper_sdk.*`` prefix in :data:`sys.modules`. This makes
    deep imports such as ``keeper_sdk.cli.main`` resolve to the *same*
    module object as ``dsk.cli.main`` whenever the target has already
    been loaded by the application. A meta path finder also handles
    deep paths that have not yet been loaded.
"""

from __future__ import annotations

import importlib
import importlib.abc
import importlib.machinery
import sys
import warnings

_ALIAS_PREFIX = "keeper_sdk."
_TARGET_PREFIX = "dsk."

_WARNING_MARKER = "_keeper_sdk_alias_warning_emitted"
_WARNING_MESSAGE = (
    "keeper_sdk is a deprecated alias for the dsk package; update imports to "
    "`from dsk.<submodule> import ...` — the keeper_sdk alias will be removed "
    "in a future major version"
)


def _warn_once() -> None:
    if getattr(sys, _WARNING_MARKER, False):
        return
    warnings.warn(_WARNING_MESSAGE, DeprecationWarning, stacklevel=2)
    setattr(sys, _WARNING_MARKER, True)


_warn_once()


class _DskAliasFinder(importlib.abc.MetaPathFinder):
    """Map a ``keeper_sdk.<...>`` import request to ``dsk.<...>``.

    Only fires for paths that are NOT yet in ``sys.modules`` — bulk
    re-registration in this package's __init__ already covers
    already-loaded submodules. For lazy / never-yet-imported paths we
    import the target via :func:`importlib.import_module`, then
    register the same module object under both names.

    The finder returns ``None`` (signalling "no spec") after pre-populating
    ``sys.modules`` for the alias key, because :func:`_find_and_load_unlocked`
    re-checks ``sys.modules`` before invoking the spec, so the existing
    object is reused without going through a custom loader.
    """

    def find_spec(
        self,
        fullname: str,
        path: object | None = None,  # noqa: ARG002
        target: object | None = None,  # noqa: ARG002
    ) -> importlib.machinery.ModuleSpec | None:
        if not fullname.startswith(_ALIAS_PREFIX):
            return None
        target_name = _TARGET_PREFIX + fullname[len(_ALIAS_PREFIX) :]
        if fullname in sys.modules:
            return None
        try:
            target_module = importlib.import_module(target_name)
        except ImportError:
            return None
        sys.modules[fullname] = target_module
        # Return a sentinel spec that points at the target module's file
        # so the import-machinery's "already in sys.modules" short-circuit
        # picks up our pre-registered alias without re-loading.
        spec = importlib.util.spec_from_loader(
            fullname, loader=None, origin=getattr(target_module, "__file__", None)
        )
        if spec is None:
            return None
        if hasattr(target_module, "__path__"):
            spec.submodule_search_locations = list(target_module.__path__)
        return spec


sys.meta_path.insert(0, _DskAliasFinder())

from dsk import *  # noqa: E402,F401,F403
from dsk import __all__, __version__  # noqa: E402,F401

_SUBMODULE_ALIASES = (
    "auth",
    "cli",
    "core",
    "providers",
    "secrets",
    "mcp",
    "crossplane",
    "daemon",
    "extras",
    "formats",
    "integrations",
    "policy",
)

for _name in _SUBMODULE_ALIASES:
    _module = importlib.import_module(f"dsk.{_name}")
    sys.modules.setdefault(f"{__name__}.{_name}", _module)
    globals()[_name] = _module

# Bulk re-register every already-loaded dsk.* submodule under the
# keeper_sdk.* prefix so deep imports preserve module identity. Snapshot
# the keys first because we mutate sys.modules during iteration.
for _key in [k for k in sys.modules if k.startswith(_TARGET_PREFIX)]:
    _alias_key = _ALIAS_PREFIX + _key[len(_TARGET_PREFIX) :]
    sys.modules.setdefault(_alias_key, sys.modules[_key])

del _name, _module, _key
