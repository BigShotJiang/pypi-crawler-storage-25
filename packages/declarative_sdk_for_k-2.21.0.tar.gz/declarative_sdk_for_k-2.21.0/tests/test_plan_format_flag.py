"""CLI coverage for the transitional ``dsk plan --format`` flag."""

from __future__ import annotations

import json
from pathlib import Path

from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_CAPABILITY, EXIT_CHANGES


def _run(args: list[str]):
    return CliRunner().invoke(main, args, catch_exceptions=False)


def test_plan_format_json_routes_to_existing_json_renderer(minimal_manifest_path: Path) -> None:
    result = _run(["plan", str(minimal_manifest_path), "--format", "json"])

    assert result.exit_code == EXIT_CHANGES, result.output
    payload = json.loads(result.output)
    assert payload["manifest_name"] == "acme-lab-minimal"
    assert set(payload["summary"]) == {"create", "update", "delete", "conflict", "noop"}


def test_plan_format_table_routes_to_existing_table_renderer(minimal_manifest_path: Path) -> None:
    result = _run(["plan", str(minimal_manifest_path), "--format", "table"])

    assert result.exit_code == EXIT_CHANGES, result.output
    assert "create" in result.output
    assert "acme-lab-minimal" in result.output


def test_plan_format_backstage_is_capability_stub(minimal_manifest_path: Path) -> None:
    result = _run(["plan", str(minimal_manifest_path), "--format", "backstage"])

    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "capability error" in result.output
    assert "plan output format `backstage` is not implemented" in result.output
    assert "--format json" in result.output


def test_plan_format_unknown_string_is_capability_error(minimal_manifest_path: Path) -> None:
    result = _run(["plan", str(minimal_manifest_path), "--format", "not-a-format"])

    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "not-a-format" in result.output


def test_plan_no_format_flag_defaults_to_table(minimal_manifest_path: Path) -> None:
    result = _run(["plan", str(minimal_manifest_path)])

    assert result.exit_code == EXIT_CHANGES, result.output
    # Table renderer uses Rich table — output must be human-readable, not JSON
    import json

    try:
        json.loads(result.output)
        assert False, "Default output should not be pure JSON"
    except (json.JSONDecodeError, ValueError):
        pass


def test_plan_format_json_and_json_flag_agree(minimal_manifest_path: Path) -> None:
    result_flag = _run(["plan", str(minimal_manifest_path), "--json"])
    result_fmt = _run(["plan", str(minimal_manifest_path), "--format", "json"])

    assert result_flag.exit_code == result_fmt.exit_code
    payload_flag = json.loads(result_flag.output)
    payload_fmt = json.loads(result_fmt.output)
    assert payload_flag["manifest_name"] == payload_fmt["manifest_name"]
    assert payload_flag["summary"] == payload_fmt["summary"]
