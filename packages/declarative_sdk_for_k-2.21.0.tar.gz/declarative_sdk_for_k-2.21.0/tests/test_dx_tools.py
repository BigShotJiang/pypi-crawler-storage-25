from __future__ import annotations

import json
from pathlib import Path

import yaml

from dsk.extras.dx_tools import (
    PATTERN_NAMES,
    build_headline,
    extract_changes,
    format_plan_pager_friendly,
    init_pattern,
    list_patterns,
    render_pattern,
    semantic_diff,
)

FIXTURES = Path(__file__).resolve().parent / "fixtures" / "dx_tools"


def _load_yaml(name: str) -> dict:
    raw = (FIXTURES / name).read_text(encoding="utf-8")
    loaded = yaml.safe_load(raw)
    assert isinstance(loaded, dict)
    return loaded


def test_plan_pager_renders_headline_bullets_and_payload() -> None:
    plan = _load_yaml("pager-plan.yaml")
    output = format_plan_pager_friendly(plan)

    assert output.startswith("3 changes: 1 add + 1 update + 1 conflict")
    assert "- add principal alice@acme.example" in output
    assert "blast radius: tenant alpha-bank" in output
    assert "PagerDuty event:" in output

    payload_text = output.split("PagerDuty event:\n", 1)[1]
    payload = json.loads(payload_text)
    assert payload["event_action"] == "trigger"
    assert payload["payload"]["severity"] == "critical"
    assert payload["payload"]["custom_details"]["change_count"] == 3


def test_headline_pluralizes_action_families() -> None:
    changes = extract_changes(
        {
            "changes": [
                {"action": "add", "kind": "record", "uid": "r1"},
                {"action": "create", "kind": "record", "uid": "r2"},
                {"action": "update", "kind": "record", "uid": "r3"},
            ]
        }
    )

    assert build_headline(changes) == "3 changes: 2 adds + 1 update"


def test_plan_pager_can_infer_manifest_creates() -> None:
    changes = extract_changes(
        {
            "records": [
                {
                    "uid_ref": "record.demo",
                    "name": "${DSK_DEMO_PREFIX}-demo-record",
                    "tenant": "tenant.alpha",
                }
            ]
        }
    )

    assert len(changes) == 1
    assert changes[0].kind == "record"
    assert changes[0].blast_radius == "tenant.alpha"


def test_semantic_diff_uses_operator_verbs() -> None:
    before = _load_yaml("semantic-before.yaml")
    after = _load_yaml("semantic-after.yaml")
    output = semantic_diff(before, after)

    assert "Added principal alice@acme.example to record prod-db" in output
    assert "Rotated database password for prod-db" in output
    assert "Expanded scope from production to production+staging for record prod-db" in output
    assert "+ uid_ref" not in output
    assert "old-redacted-value" not in output
    assert "new-redacted-value" not in output


def test_semantic_diff_reports_no_changes_for_equal_docs() -> None:
    doc = _load_yaml("semantic-before.yaml")
    assert semantic_diff(doc, doc) == "No semantic changes."


def test_patterns_are_listed_and_parse_as_yaml() -> None:
    assert list_patterns() == PATTERN_NAMES

    for name in list_patterns():
        rendered = render_pattern(name)
        parsed = yaml.safe_load(rendered)
        assert parsed["metadata"]["labels"]["pattern"] == name
        assert "${DSK_DEMO_PREFIX}" in rendered
        assert parsed["checklist"]


def test_unknown_pattern_names_show_available_patterns() -> None:
    try:
        render_pattern("not-a-pattern")
    except ValueError as exc:
        message = str(exc)
    else:
        raise AssertionError("render_pattern should reject unknown pattern names")

    assert "unknown pattern" in message
    assert "msp-fintech-saas" in message


def test_init_pattern_writes_file(tmp_path: Path) -> None:
    out = init_pattern("msp-fintech-saas", tmp_path)
    assert out == tmp_path / "msp-fintech-saas.yaml"
    parsed = yaml.safe_load(out.read_text(encoding="utf-8"))
    assert parsed["metadata"]["labels"]["pattern"] == "msp-fintech-saas"
    assert len(parsed["tenants"]) == 3
