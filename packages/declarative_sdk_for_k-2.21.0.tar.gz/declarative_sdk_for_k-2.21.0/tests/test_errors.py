from dsk.core import CapabilityError, DeleteUnsupportedError
from dsk.core.errors import (
    DeleteUnsupportedError as DirectDeleteUnsupportedError,
)
from dsk.core.errors import (
    ManifestError,
    SchemaError,
    UnsupportedFamilyError,
)


def test_delete_unsupported_error_remains_public_capability_error() -> None:
    assert DirectDeleteUnsupportedError is DeleteUnsupportedError
    assert issubclass(DeleteUnsupportedError, CapabilityError)

    exc = DeleteUnsupportedError(reason="delete is not supported by this provider")

    assert isinstance(exc, CapabilityError)
    assert "delete is not supported" in str(exc)


def test_capability_error_has_expected_fields_and_defaults() -> None:
    exc = CapabilityError(reason="r")
    assert exc.reason == "r" and exc.context == {}
    assert exc.next_action is exc.uid_ref is exc.resource_type is None


def test_capability_error_str_contains_reason() -> None:
    exc = CapabilityError(reason="missing capability")
    assert "missing capability" in str(exc)


def test_schema_error_reason_next_action_and_str() -> None:
    exc = SchemaError(reason="invalid manifest", next_action="fix keys")
    assert "invalid manifest" in str(exc) and "fix keys" in str(exc)


def test_manifest_error_basic_instantiation() -> None:
    exc = ManifestError(reason="engine failure")
    assert exc.reason == "engine failure"


def test_unsupported_family_error_is_manifest_not_schema_subclass() -> None:
    assert issubclass(UnsupportedFamilyError, ManifestError)
    assert not issubclass(UnsupportedFamilyError, SchemaError)


def test_unsupported_family_error_reason_and_next_action() -> None:
    exc = UnsupportedFamilyError(reason="no planner", next_action="upgrade sdk")
    assert exc.reason == "no planner" and exc.next_action == "upgrade sdk"


def test_capability_error_chains_from_other_exception() -> None:
    root = ValueError("upstream")
    try:
        raise CapabilityError(reason="wrapped") from root
    except CapabilityError as e:
        assert e.__cause__ is root


def test_capability_error_context_accepts_arbitrary_payload() -> None:
    exc = CapabilityError(reason="x", context={"n": 1, "nested": {"flag": True}})
    assert exc.context["n"] == 1 and exc.context["nested"]["flag"] is True
