"""Focused security tests for ``dsk import-from-keepercmd`` helpers."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from dsk.cli.cmd_import_from_keepercmd import (
    _collect_rows,
    _iter_sha256sum_entries,
    _parse_manifest_csv,
    _read_suspect_marker,
    _records_export_dir,
    _records_export_dirname,
    _safe_export_path,
    _safe_open,
    _sha256_python_fallback,
    _validate_commander_config,
    _validate_source_uid,
    _write_output_manifest,
)


class TestSourceUidValidator:
    def test_valid_safe_source_uids(self) -> None:
        assert _validate_source_uid("abc123") == "abc123"
        assert _validate_source_uid("abc_123-XYZ") == "abc_123-XYZ"

    def test_rejects_path_traversal_double_dot(self) -> None:
        with pytest.raises(ImportError, match="invalid characters"):
            _validate_source_uid("../../etc/passwd")

    def test_rejects_slash(self) -> None:
        with pytest.raises(ImportError):
            _validate_source_uid("foo/bar")

    def test_rejects_backslash(self) -> None:
        with pytest.raises(ImportError):
            _validate_source_uid("foo\\bar")

    def test_rejects_null_byte(self) -> None:
        with pytest.raises(ImportError):
            _validate_source_uid("foo\x00bar")

    def test_rejects_too_long(self) -> None:
        with pytest.raises(ImportError):
            _validate_source_uid("a" * 65)

    def test_rejects_empty(self) -> None:
        with pytest.raises(ImportError):
            _validate_source_uid("")

    def test_rejects_non_string(self) -> None:
        with pytest.raises(ImportError):
            _validate_source_uid(None)  # type: ignore[arg-type]


class TestSafeExportPath:
    def test_safe_path_inside_base(self, tmp_path: Path) -> None:
        base = tmp_path / "records-export"
        base.mkdir()
        result = _safe_export_path(base, "abc123")
        assert result == (base / "abc123.json").resolve()

    def test_rejects_symlink_escape_after_resolution(self, tmp_path: Path) -> None:
        base = tmp_path / "records-export"
        base.mkdir()
        outside = tmp_path / "outside.json"
        outside.write_text("{}", encoding="utf-8")
        (base / "evil.json").symlink_to(outside)

        with pytest.raises(ImportError, match="outside records-export"):
            _safe_export_path(base, "evil")


class TestSuspectMarkerFailClosed:
    def test_valid_marker_returns_value(self, tmp_path: Path) -> None:
        export_path = tmp_path / "abc.json"
        export_path.write_text(json.dumps({"suspect": True}), encoding="utf-8")
        assert _read_suspect_marker(export_path, suspect_threshold=10) is True

    def test_corrupt_json_with_threshold_zero_raises(self, tmp_path: Path) -> None:
        export_path = tmp_path / "abc.json"
        export_path.write_text('{"suspect": true' + "x", encoding="utf-8")
        with pytest.raises(ImportError, match="unreadable"):
            _read_suspect_marker(export_path, suspect_threshold=0)

    def test_corrupt_json_with_threshold_nonzero_returns_true(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level("WARNING")
        export_path = tmp_path / "abc.json"
        export_path.write_text('{"suspect": true' + "x", encoding="utf-8")
        result = _read_suspect_marker(export_path, suspect_threshold=10)
        assert result is True
        assert "fail-closed" in caplog.text or "unreadable" in caplog.text

    def test_missing_file_with_threshold_zero_raises(self, tmp_path: Path) -> None:
        export_path = tmp_path / "missing.json"
        with pytest.raises(ImportError):
            _read_suspect_marker(export_path, suspect_threshold=0)


class TestInputArtifactHardening:
    def test_sha256sums_rejects_path_traversal(self, tmp_path: Path) -> None:
        sha_file = tmp_path / "SHA256SUMS.txt"
        sha_file.write_text(f"{'0' * 64}  ../../../etc/passwd\n", encoding="utf-8")

        with pytest.raises(ImportError, match="contains '..'"):
            _iter_sha256sum_entries(tmp_path, sha_file)

    def test_sha256sums_rejects_absolute_path(self, tmp_path: Path) -> None:
        sha_file = tmp_path / "SHA256SUMS.txt"
        sha_file.write_text(f"{'0' * 64}  /etc/passwd\n", encoding="utf-8")

        with pytest.raises(ImportError, match="absolute"):
            _iter_sha256sum_entries(tmp_path, sha_file)

    def test_sha256_python_fallback_rejects_symlink_entry(self, tmp_path: Path) -> None:
        from rich.console import Console

        target = tmp_path / "target.json"
        target.write_text("{}", encoding="utf-8")
        (tmp_path / "inventory.json").symlink_to(target)
        sha_file = tmp_path / "SHA256SUMS.txt"
        sha_file.write_text(f"{'0' * 64}  inventory.json\n", encoding="utf-8")

        assert _sha256_python_fallback(tmp_path, sha_file, Console(record=True)) is False

    def test_sha256sums_bare_filename_resolves_under_records_export(self, tmp_path: Path) -> None:
        from rich.console import Console

        records_export = tmp_path / "records_export"
        records_export.mkdir()
        artifact = records_export / "abc123.json"
        artifact.write_text("{}", encoding="utf-8")
        digest = "44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a"
        sha_file = tmp_path / "SHA256SUMS.txt"
        sha_file.write_text(f"{digest}  abc123.json\n", encoding="utf-8")

        assert _sha256_python_fallback(tmp_path, sha_file, Console(record=True)) is True

    def test_sha256sums_prefixed_path_remains_backward_compatible(self, tmp_path: Path) -> None:
        from rich.console import Console

        records_export = tmp_path / "records_export"
        records_export.mkdir()
        artifact = records_export / "abc123.json"
        artifact.write_text("{}", encoding="utf-8")
        digest = "44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a"
        sha_file = tmp_path / "SHA256SUMS.txt"
        sha_file.write_text(f"{digest}  records_export/abc123.json\n", encoding="utf-8")

        assert _sha256_python_fallback(tmp_path, sha_file, Console(record=True)) is True

    def test_sha256sums_missing_bare_filename_reports_not_found(self, tmp_path: Path) -> None:
        from rich.console import Console

        sha_file = tmp_path / "SHA256SUMS.txt"
        sha_file.write_text(f"{'0' * 64}  missing.json\n", encoding="utf-8")
        console = Console(record=True)

        assert _sha256_python_fallback(tmp_path, sha_file, console) is False
        assert "missing.json: file not found" in console.export_text()

    def test_safe_open_rejects_symlink(self, tmp_path: Path) -> None:
        target = tmp_path / "target.txt"
        target.write_text("secret", encoding="utf-8")
        link = tmp_path / "manifest.csv"
        link.symlink_to(target)

        with pytest.raises(ImportError, match="symlink"):
            with _safe_open(link):
                pass

    def test_safe_open_rejects_oversized_artifact(self, tmp_path: Path) -> None:
        artifact = tmp_path / "inventory.json"
        with artifact.open("wb") as fh:
            fh.seek((200 * 1024 * 1024) - 1)
            fh.write(b"\0")

        with pytest.raises(ImportError, match="exceeding DSK_MAX_ARTIFACT_BYTES"):
            with _safe_open(artifact):
                pass

    def test_parse_manifest_csv_rejects_symlink(self, tmp_path: Path) -> None:
        target = tmp_path / "target.csv"
        target.write_text("source_uid,target_uid,title,type,status,timestamp\n", encoding="utf-8")
        link = tmp_path / "manifest.csv"
        link.symlink_to(target)

        with pytest.raises(ImportError, match="symlink"):
            _parse_manifest_csv(link)

    def test_parse_manifest_csv_skips_comment_preamble(self, tmp_path: Path) -> None:
        csv_path = tmp_path / "manifest.csv"
        csv_path.write_text(
            "# columns 1-6 canonical OUTPUT_CONTRACT v1.1; extras follow\n"
            "source_uid,target_uid,title,type,status,timestamp\n"
            "SRC,TGT,Title,login,paired,2026-05-09T00:00:00Z\n",
            encoding="utf-8",
        )

        rows = _parse_manifest_csv(csv_path)

        assert len(rows) == 1
        assert rows[0]["source_uid"] == "SRC"
        assert rows[0]["status"] == "paired"

    def test_records_export_dir_finds_keepercmd_underscore(self, tmp_path: Path) -> None:
        underscore = tmp_path / "records_export"
        underscore.mkdir()

        assert _records_export_dirname(tmp_path) == "records_export"
        assert _records_export_dir(tmp_path) == underscore

    def test_records_export_dir_accepts_legacy_hyphen_with_deprecation_log(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level("WARNING")
        legacy = tmp_path / "records-export"
        legacy.mkdir()

        assert _records_export_dirname(tmp_path) == "records-export"
        assert _records_export_dir(tmp_path) == legacy
        assert "deprecated" in caplog.text

    def test_records_export_dir_prefers_underscore_when_both_present_with_warning(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level("WARNING")
        legacy = tmp_path / "records-export"
        legacy.mkdir()
        underscore = tmp_path / "records_export"
        underscore.mkdir()

        assert _records_export_dirname(tmp_path) == "records_export"
        assert _records_export_dir(tmp_path) == underscore
        assert "both records_export/" in caplog.text
        assert "using canonical records_export/" in caplog.text

    def test_records_export_dir_defaults_to_keepercmd_underscore(self, tmp_path: Path) -> None:
        assert _records_export_dirname(tmp_path) is None
        assert _records_export_dir(tmp_path) == tmp_path / "records_export"

    def test_collect_rows_rejects_invalid_paired_source_uid(self, tmp_path: Path) -> None:
        from rich.console import Console

        records_export = tmp_path / "records-export"
        records_export.mkdir()
        rows = [
            {
                "source_uid": "../escape",
                "target_uid": "TGT",
                "title": "Bad",
                "type": "login",
                "status": "paired",
                "timestamp": "",
            }
        ]

        with pytest.raises(ImportError, match="invalid characters"):
            _collect_rows(rows, records_export, False, Console(record=True))

    def test_commander_config_rejects_untrusted_server(self, tmp_path: Path) -> None:
        config_path = tmp_path / "keeper-config.json"
        config_path.write_text(json.dumps({"server": "attacker.com"}), encoding="utf-8")

        with pytest.raises(ImportError, match="not allowed"):
            _validate_commander_config(config_path)

    def test_write_output_manifest_returns_false_for_directory(self, tmp_path: Path) -> None:
        from rich.console import Console

        console = Console(record=True)
        assert _write_output_manifest(tmp_path, "schema: keeper-vault.v1\n", console) is False
        assert "cannot write manifest YAML" in console.export_text()
