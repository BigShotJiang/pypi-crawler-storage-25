"""Tests for `dsk audit explain`."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli.audit_chain import AuditChainCorrupt, explain_audit_log
from dsk.cli.main import main


def _write_audit_log(
    log_path: Path,
    events: list[dict[str, Any]],
    *,
    genesis_prev_hash: str = "",
    link_mode: str = "line_hash",
) -> None:
    prev_hash = genesis_prev_hash
    lines: list[str] = []
    for event in events:
        payload = {**event, "prev_hash": prev_hash}
        payload["signature"] = hashlib.sha256(
            json.dumps(payload, sort_keys=True).encode()
        ).hexdigest()
        line = json.dumps(payload)
        lines.append(line)
        if link_mode == "signature":
            prev_hash = payload["signature"]
        else:
            prev_hash = hashlib.sha256(line.encode()).hexdigest()
    log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _run(*args: str) -> Any:
    return CliRunner().invoke(main, ["audit", "explain", *args], catch_exceptions=False)


def test_audit_explain_happy_path_with_summary(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(
        log_path,
        [
            {"event": "MIGRATION_START", "timestamp": "2026-05-09T20:00:00Z"},
            {"event": "RECORD_PAIRED", "timestamp": "2026-05-09T20:01:00Z"},
            {"event": "MIGRATION_END", "timestamp": "2026-05-09T20:02:00Z"},
        ],
    )

    result = _run(str(log_path), "--summary")

    assert result.exit_code == 0
    assert "audit chain verified" in result.output
    assert "MIGRATION_START=1" in result.output
    assert "MIGRATION_END=1" in result.output
    assert "2026-05-09T20:00:00Z" in result.output


def test_audit_genesis_empty_prev_hash_is_accepted(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "start"}], genesis_prev_hash="")

    result = explain_audit_log(log_path)

    assert result.ok


def test_audit_genesis_zero_prev_hash_is_accepted(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(
        log_path,
        [{"event": "start"}, {"event": "finish"}],
        genesis_prev_hash="0" * 64,
        link_mode="signature",
    )

    result = explain_audit_log(log_path)

    assert result.ok


def test_audit_genesis_malformed_zero_like_prev_hash_is_rejected(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "start"}], genesis_prev_hash=("0" * 63) + "1")

    result = explain_audit_log(log_path)

    assert not result.ok
    assert "prev_hash mismatch" in (result.failures[0].error or "")


def test_audit_explain_broken_chain_reports_prev_hash_context(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "start"}, {"event": "finish"}])
    lines = log_path.read_text(encoding="utf-8").splitlines()
    first = json.loads(lines[0])
    first["event"] = "start-mutated"
    payload = {key: value for key, value in first.items() if key != "signature"}
    first["signature"] = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    lines[0] = json.dumps(first)
    log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    result = _run(str(log_path), "--summary")

    assert result.exit_code == 5
    assert "prev_hash mismatch" in result.output
    assert "line 2" in result.output
    assert "audit chain corrupt" in result.output


def test_audit_explain_mutated_entry_reports_signature_mismatch(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "start"}])
    row = json.loads(log_path.read_text(encoding="utf-8"))
    row["event"] = "start-mutated"
    log_path.write_text(json.dumps(row) + "\n", encoding="utf-8")

    result = _run(str(log_path))

    assert result.exit_code == 5
    assert "signature mismatch" in result.output
    assert "line 1" in result.output


def test_audit_explain_truncated_file_reports_malformed_json(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "start"}, {"event": "finish"}])
    text = log_path.read_text(encoding="utf-8")
    log_path.write_text(text[:-3], encoding="utf-8")

    result = _run(str(log_path))

    assert result.exit_code == 5
    assert "malformed JSON" in result.output
    assert "line 2" in result.output


def test_explain_audit_log_rejects_non_object_json_line(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    log_path.write_text('["not", "object"]\n', encoding="utf-8")

    result = explain_audit_log(log_path)

    assert result.failures[0].line_no == 1
    assert "JSON value is not an object" in (result.failures[0].error or "")


def test_explain_audit_log_env_size_guard_rejects_bad_values(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "start"}])
    monkeypatch.setenv("DSK_MAX_ARTIFACT_BYTES", "0")

    with pytest.raises(AuditChainCorrupt) as exc:
        explain_audit_log(log_path)

    assert "greater than 0" in str(exc.value)


def test_explain_audit_log_rejects_oversized_file(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    log_path = tmp_path / "audit.log"
    log_path.write_text("{}\n", encoding="utf-8")
    monkeypatch.setenv("DSK_MAX_ARTIFACT_BYTES", "2")

    with pytest.raises(AuditChainCorrupt, match="DSK_MAX_ARTIFACT_BYTES=2"):
        explain_audit_log(log_path)
