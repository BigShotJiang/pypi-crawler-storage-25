"""Tests for AI session policy models (keeper-ai-policy.v1)."""

from pathlib import Path

import pytest
import yaml


def test_ai_policy_defaults():
    from dsk.core.models_ai_policy import AiSessionPolicy

    policy = AiSessionPolicy(name="test-policy")
    assert policy.recording_required is True
    assert policy.baseline_window_days == 30
    assert policy.audit_log is True
    assert policy.applies_to_pam_config_uid_refs == []


def test_ai_policy_manifest_round_trip():
    from dsk.core.models_ai_policy import (
        AiPolicyManifestV1,
        SessionAction,
    )

    example = Path(__file__).parent.parent / "examples/ai-policy/acme-ai-session-policy.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = AiPolicyManifestV1(**data)
    assert manifest.schema_ == "keeper-ai-policy.v1"
    assert len(manifest.policies) == 2
    geo_rule = next(r for r in manifest.policies[0].anomaly_rules if r.pattern == "geo_anomaly")
    assert SessionAction.terminate in geo_rule.actions


def test_anomaly_rule_defaults():
    from dsk.core.models_ai_policy import (
        AnomalyRule,
        AnomalySensitivity,
        SessionAction,
    )

    rule = AnomalyRule(name="test-rule", pattern="unusual_hour")
    assert rule.sensitivity == AnomalySensitivity.medium
    assert SessionAction.alert in rule.actions


def test_ai_policy_schema_alias():
    from dsk.core.models_ai_policy import AiPolicyManifestV1

    m = AiPolicyManifestV1(**{"schema": "keeper-ai-policy.v1", "name": "test"})
    assert m.schema_ == "keeper-ai-policy.v1"


def test_anomaly_rule_negative_cooldown_rejected():
    """AnomalyRule cooldown_minutes must be >= 0."""
    from pydantic import ValidationError

    from dsk.core.models_ai_policy import AnomalyRule

    with pytest.raises(ValidationError):
        AnomalyRule(name="bad", pattern="unusual_hour", cooldown_minutes=-1)


def test_ai_session_policy_baseline_window_minimum():
    """AiSessionPolicy baseline_window_days must be at least 7."""
    from pydantic import ValidationError

    from dsk.core.models_ai_policy import AiSessionPolicy

    with pytest.raises(ValidationError):
        AiSessionPolicy(name="x", baseline_window_days=6)


def test_ai_policy_manifest_default_version_and_manager():
    """Root manifest defaults version and manager when omitted."""
    from dsk.core.models_ai_policy import AiPolicyManifestV1

    m = AiPolicyManifestV1(**{"schema": "keeper-ai-policy.v1", "name": "root"})
    assert m.version == "1"
    assert m.manager == "dsk"
    assert m.policies == []
