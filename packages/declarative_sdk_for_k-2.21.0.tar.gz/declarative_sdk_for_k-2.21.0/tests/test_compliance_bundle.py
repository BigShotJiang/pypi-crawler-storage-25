"""Tests for compliance-bundle.v1 models and dsk bundle command."""

import json
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner


def test_compliance_bundle_defaults():
    from dsk.core.models_compliance import ComplianceBundleManifestV1

    m = ComplianceBundleManifestV1(**{"schema": "compliance-bundle.v1", "name": "test"})
    assert m.schema_ == "compliance-bundle.v1"
    assert m.output_dir == "compliance-evidence/"
    assert m.controls == []
    assert m.frameworks == []


def test_compliance_manifest_round_trip():
    from dsk.core.models_compliance import ComplianceBundleManifestV1, ComplianceFramework

    example = Path(__file__).parent.parent / "examples/compliance/fedramp-high-bundle.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = ComplianceBundleManifestV1(**data)
    assert manifest.schema_ == "compliance-bundle.v1"
    assert ComplianceFramework.fedramp_high in manifest.frameworks
    assert len(manifest.controls) == 4
    assert manifest.controls[0].control_id == "AC-2"


def test_bundle_dry_run(tmp_path):
    from dsk.cli.cmd_bundle import cmd_bundle

    manifest = tmp_path / "bundle.yaml"
    manifest.write_text(
        yaml.dump(
            {
                "schema": "compliance-bundle.v1",
                "name": "test-bundle",
                "version": "1",
                "frameworks": ["fedramp-high"],
                "controls": [
                    {
                        "control_id": "AC-2",
                        "description": "test",
                        "report": "compliance-report",
                        "report_args": [],
                        "evidence_file": "ac-2.json",
                    }
                ],
                "output_dir": str(tmp_path / "evidence/"),
            }
        )
    )
    runner = CliRunner()
    result = runner.invoke(cmd_bundle, [str(manifest), "--dry-run"])
    assert result.exit_code == 0
    assert "AC-2" in result.output


def test_bundle_wrong_schema(tmp_path):
    from dsk.cli.cmd_bundle import cmd_bundle

    manifest = tmp_path / "bundle.yaml"
    manifest.write_text(yaml.dump({"schema": "pam-environment.v1", "name": "test"}))
    runner = CliRunner()
    result = runner.invoke(cmd_bundle, [str(manifest)])
    assert result.exit_code == 1


def test_control_mapping_requires_evidence_file():
    """ControlMapping requires evidence_file and valid report enum."""
    from pydantic import ValidationError

    from dsk.core.models_compliance import ControlMapping, ReportType

    with pytest.raises(ValidationError):
        ControlMapping(
            control_id="AC-2",
            description="d",
            report=ReportType.compliance_report,
        )


def test_compliance_bundle_scope_defaults():
    """ComplianceBundleManifestV1 scope defaults to empty paths and null node."""
    from dsk.core.models_compliance import ComplianceBundleManifestV1

    m = ComplianceBundleManifestV1(**{"schema": "compliance-bundle.v1", "name": "s"})
    assert m.scope.manifest_paths == []
    assert m.scope.node is None


def test_bundle_dry_run_output_dir_option_accepted(tmp_path):
    """--output-dir is accepted during dry-run (no report subprocess)."""
    from dsk.cli.cmd_bundle import cmd_bundle

    manifest = tmp_path / "bundle.yaml"
    manifest.write_text(
        yaml.dump(
            {
                "schema": "compliance-bundle.v1",
                "name": "t",
                "controls": [
                    {
                        "control_id": "X-1",
                        "description": "d",
                        "report": "compliance-report",
                        "evidence_file": "x.json",
                    }
                ],
            }
        )
    )
    runner = CliRunner()
    result = runner.invoke(cmd_bundle, [str(manifest), "--dry-run", "--output-dir", "/tmp/nope"])
    assert result.exit_code == 0
    assert "X-1" in result.output


def test_bundle_manifest_helpers_validate_shape_and_header(tmp_path):
    """Extracted bundle helpers validate schema and format stable header lines."""
    from dsk.cli.cmd_bundle import _bundle_header_lines, _load_bundle_manifest

    manifest = tmp_path / "bundle.yaml"
    manifest.write_text(
        yaml.dump(
            {
                "schema": "compliance-bundle.v1",
                "name": "audit-pack",
                "frameworks": ["soc2", "iso27001"],
                "controls": [{"control_id": "CC-1"}],
            }
        )
    )

    data = _load_bundle_manifest(str(manifest))

    assert data["name"] == "audit-pack"
    assert _bundle_header_lines(data, "out") == [
        "Compliance bundle: audit-pack",
        "Frameworks: soc2, iso27001",
        "Controls: 1",
        "Output: out",
    ]


def test_bundle_manifest_loader_rejects_non_mapping(tmp_path):
    from dsk.cli.cmd_bundle import _load_bundle_manifest

    manifest = tmp_path / "bundle.yaml"
    manifest.write_text("- not\n- a\n- mapping\n")

    with pytest.raises(ValueError, match="manifest must be a mapping"):
        _load_bundle_manifest(str(manifest))


def test_bundle_manifest_loader_rejects_oversized_manifest(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
):
    from dsk.cli.cmd_bundle import _load_bundle_manifest
    from dsk.core.resource_limits import ResourceLimitError

    monkeypatch.setenv("DSK_BUNDLE_MAX_MANIFEST_BYTES", "64")
    manifest = tmp_path / "bundle.yaml"
    manifest.write_text(
        yaml.dump(
            {
                "schema": "compliance-bundle.v1",
                "name": "bundle",
                "padding": "x" * 128,
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ResourceLimitError, match="DSK_BUNDLE_MAX_MANIFEST_BYTES=64"):
        _load_bundle_manifest(str(manifest))


def test_bundle_manifest_loader_rejects_excessive_depth(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
):
    from dsk.cli.cmd_bundle import _load_bundle_manifest
    from dsk.core.resource_limits import ResourceLimitError

    monkeypatch.setenv("DSK_BUNDLE_MAX_MANIFEST_DEPTH", "3")
    manifest = tmp_path / "bundle.yaml"
    manifest.write_text(
        "schema: compliance-bundle.v1\nname: bundle\ncontrols:\n- report_args:\n  - nested:\n      value: x\n",
        encoding="utf-8",
    )

    with pytest.raises(ResourceLimitError, match="DSK_BUNDLE_MAX_MANIFEST_DEPTH=3"):
        _load_bundle_manifest(str(manifest))


def test_bundle_dry_run_lines_are_deterministic():
    from dsk.cli.cmd_bundle import _dry_run_lines

    assert _dry_run_lines(
        [
            {
                "control_id": "AC-2",
                "evidence_file": "ac-2.json",
            }
        ]
    ) == ["", "[dry-run] Would generate:", "  AC-2         -> ac-2.json"]


def test_generate_bundle_records_report_errors(tmp_path):
    """The pure generator writes evidence and marks failed reports in the index."""
    from dsk.cli.cmd_bundle import _generate_bundle

    calls: list[tuple[str, list[str]]] = []

    def fake_report(report_type: str, args: list[str]) -> dict[str, object]:
        calls.append((report_type, args))
        if report_type == "security-audit":
            return {"error": "audit failed"}
        return {"ok": True}

    progress: list[tuple[str, str, bool]] = []

    errors, index_path = _generate_bundle(
        {
            "name": "bundle",
            "frameworks": ["fedramp-high"],
            "controls": [
                {
                    "control_id": "AC-2",
                    "description": "accounts",
                    "report": "compliance-report",
                    "report_args": ["--json"],
                    "evidence_file": "ac-2.json",
                },
                {
                    "control_id": "AU-6",
                    "description": "audit review",
                    "report": "security-audit",
                    "evidence_file": "au-6.json",
                },
            ],
        },
        str(tmp_path),
        report_runner=fake_report,
        progress=lambda control_id, evidence_file, evidence: progress.append(
            (control_id, evidence_file, "error" in evidence)
        ),
    )

    assert errors == 1
    assert calls == [("compliance-report", ["--json"]), ("security-audit", [])]
    assert progress == [("AC-2", "ac-2.json", False), ("AU-6", "au-6.json", True)]
    payload = json.loads((tmp_path / "ac-2.json").read_text())
    assert payload["_control_id"] == "AC-2"
    index = json.loads(index_path.read_text())
    assert index["controls"] == [
        {"control_id": "AC-2", "evidence_file": "ac-2.json", "status": "ok"},
        {"control_id": "AU-6", "evidence_file": "au-6.json", "status": "error"},
    ]


def test_run_report_returns_error_dict_on_subprocess_file_not_found(monkeypatch):
    """_run_report maps FileNotFoundError from subprocess.run to an error dict."""
    import dsk.cli.cmd_bundle as mod

    def boom(*_a, **_kw):
        raise FileNotFoundError("no dsk binary")

    monkeypatch.setattr(mod.subprocess, "run", boom)
    out = mod._run_report("compliance-report", [])
    assert out == {"error": "no dsk binary"}


def test_bundle_dry_run_does_not_invoke_run_report(tmp_path, monkeypatch):
    """--dry-run lists evidence targets only; _run_report is never called."""
    from dsk.cli.cmd_bundle import cmd_bundle

    def fail_run_report(*_a, **_kw):
        raise AssertionError("_run_report must not be called during dry-run")

    monkeypatch.setattr(
        "dsk.cli.cmd_bundle._run_report",
        fail_run_report,
    )
    manifest = tmp_path / "bundle.yaml"
    manifest.write_text(
        yaml.dump(
            {
                "schema": "compliance-bundle.v1",
                "name": "dry",
                "controls": [
                    {
                        "control_id": "SC-1",
                        "description": "d",
                        "report": "compliance-report",
                        "evidence_file": "sc-1.json",
                    }
                ],
            }
        )
    )
    runner = CliRunner()
    result = runner.invoke(cmd_bundle, [str(manifest), "--dry-run"])
    assert result.exit_code == 0
    assert "SC-1" in result.output
    assert "sc-1.json" in result.output


def test_bundle_writes_json_evidence_when_not_dry_run(tmp_path, monkeypatch):
    """Non-dry-run writes one JSON file per control and bundle-index.json."""
    from dsk.cli.cmd_bundle import cmd_bundle

    def fake_run_report(_report_type, _extra_args):
        return {"finding": "none"}

    monkeypatch.setattr(
        "dsk.cli.cmd_bundle._run_report",
        fake_run_report,
    )
    out_dir = tmp_path / "evidence"
    manifest = tmp_path / "bundle.yaml"
    manifest.write_text(
        yaml.dump(
            {
                "schema": "compliance-bundle.v1",
                "name": "evidence-test",
                "frameworks": ["soc2"],
                "controls": [
                    {
                        "control_id": "CC-1",
                        "description": "check",
                        "report": "compliance-report",
                        "report_args": ["--json"],
                        "evidence_file": "cc-1.json",
                    }
                ],
                "output_dir": str(out_dir),
            }
        )
    )
    runner = CliRunner()
    result = runner.invoke(cmd_bundle, [str(manifest)])
    assert result.exit_code == 0
    evidence = out_dir / "cc-1.json"
    assert evidence.is_file()
    payload = json.loads(evidence.read_text())
    assert payload["finding"] == "none"
    assert payload["_control_id"] == "CC-1"
    index = out_dir / "bundle-index.json"
    assert index.is_file()
    meta = json.loads(index.read_text())
    assert meta["bundle_name"] == "evidence-test"
    assert meta["controls"][0]["status"] == "ok"


def test_bundle_exits_on_missing_or_invalid_manifest(tmp_path):
    """Invalid manifest path or YAML yields exit code 1 and an error message."""
    from dsk.cli.cmd_bundle import cmd_bundle

    runner = CliRunner()
    missing = tmp_path / "missing.yaml"
    r1 = runner.invoke(cmd_bundle, [str(missing)])
    assert r1.exit_code == 1
    assert "Error reading manifest" in r1.output

    bad = tmp_path / "bad.yaml"
    bad.write_text("{ not yaml at all")
    r2 = runner.invoke(cmd_bundle, [str(bad)])
    assert r2.exit_code == 1
    assert "Error reading manifest" in r2.output


# ── coverage: compliance_diff.py lines 21, 44-45 ──────────────────────────


def test_compute_compliance_diff_live_raises_not_implemented():
    from dsk.core.compliance_diff import compute_compliance_diff
    from dsk.core.models_compliance import ComplianceBundleManifestV1

    m = ComplianceBundleManifestV1.model_validate(
        {"schema": "compliance-bundle.v1", "name": "c", "version": "1", "manager": "dsk"}
    )
    with pytest.raises(NotImplementedError):
        compute_compliance_diff(m, live={"x": 1})


def test_compute_compliance_diff_with_frameworks():
    from dsk.core.compliance_diff import compute_compliance_diff
    from dsk.core.models_compliance import ComplianceBundleManifestV1

    m = ComplianceBundleManifestV1.model_validate(
        {
            "schema": "compliance-bundle.v1",
            "name": "c",
            "version": "1",
            "manager": "dsk",
            "frameworks": ["fedramp-high"],
        }
    )
    changes = compute_compliance_diff(m, manifest_name="my-bundle")
    fw = [c for c in changes if c.resource_type == "compliance_framework"]
    assert len(fw) == 1
