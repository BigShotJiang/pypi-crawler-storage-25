"""CommanderCliProvider keeper-scim.v1 apply (ScimPushCommand) tests."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.planner import Plan
from dsk.providers import commander_cli
from dsk.providers.commander_cli import CommanderCliProvider


def _plan(*changes: Change) -> Plan:
    return Plan(
        manifest_name="scim-apply-test",
        changes=list(changes),
        order=[c.uid_ref or "" for c in changes],
    )


def _provider(monkeypatch: pytest.MonkeyPatch) -> CommanderCliProvider:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    params = object()
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda operation: operation())
    return provider


def _install_scim_command_module(
    monkeypatch: pytest.MonkeyPatch,
    command_cls: type[Any],
) -> None:
    keepercommander_module = types.ModuleType("keepercommander")
    commands_module = types.ModuleType("keepercommander.commands")
    scim_module = types.ModuleType("keepercommander.commands.scim")
    setattr(keepercommander_module, "__path__", [])
    setattr(commands_module, "__path__", [])
    setattr(keepercommander_module, "commands", commands_module)
    scim_module.ScimPushCommand = command_cls
    monkeypatch.setitem(sys.modules, "keepercommander", keepercommander_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", commands_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.scim", scim_module)


def test_apply_scim_plan_push_dry_run_outcomes(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.UPDATE,
            uid_ref="scim.push:n1",
            resource_type="scim_push",
            title="scim push n1",
            before={},
            after={
                "node_id": "node-123",
                "push_type": "all",
                "source": "record",
            },
            manifest_name="scim-apply-test",
        )
    )
    out = provider.apply_scim_plan(plan, dry_run=True)
    assert len(out) == 1
    assert out[0].action == "update"
    assert out[0].details.get("dry_run") is True
    assert out[0].details.get("push_type") == "all"


def test_apply_scim_plan_push_missing_node_id_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.UPDATE,
            uid_ref="scim.push",
            resource_type="scim_push",
            title="scim push",
            before={},
            after={"source": "record"},
            manifest_name="scim-apply-test",
        )
    )
    with pytest.raises(CapabilityError, match="node_id"):
        provider.apply_scim_plan(plan, dry_run=False)


def test_apply_scim_plan_push_invokes_commander_scim_push(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakeScimPushCommand:
        def execute(self, params: object, **kwargs: Any) -> None:
            calls.append((params, kwargs))

    _install_scim_command_module(monkeypatch, FakeScimPushCommand)
    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.UPDATE,
            uid_ref="ep1",
            resource_type="scim_push",
            title="push",
            before={},
            after={
                "node_id": "55",
                "push_type": "users",
                "source": "ad",
                "creds_record_uid": "AD-CREDS-1",
            },
            manifest_name="m",
        )
    )
    provider.apply_scim_plan(plan, dry_run=False)
    assert len(calls) == 1
    assert calls[0][1]["target"] == "55"
    assert calls[0][1]["source"] == "ad"
    assert calls[0][1]["record"] == "AD-CREDS-1"
    assert calls[0][1]["auto_approve"] == "off"
    assert calls[0][1]["dry_run"] is False


def test_apply_scim_plan_structural_rows_dry_run(monkeypatch: pytest.MonkeyPatch) -> None:
    """Structural rows (node/role/team/user) must produce create/update outcomes in dry_run."""
    provider = _provider(monkeypatch)
    changes = [
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="n1",
            resource_type="scim_node",
            title="Eng",
            before={},
            after={"name": "Eng"},
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="r1",
            resource_type="scim_role",
            title="Admin",
            before={},
            after={"name": "Admin"},
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="t1",
            resource_type="scim_team",
            title="Core",
            before={},
            after={"name": "Core"},
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="u1",
            resource_type="scim_user",
            title="alice@acme.com",
            before={},
            after={"email": "alice@acme.com"},
            manifest_name="m",
        ),
    ]
    plan = _plan(*changes)
    out = provider.apply_scim_plan(plan, dry_run=True)
    assert len(out) == 4
    assert all(o.action == "create" for o in out)
    assert all(o.details.get("dry_run") is True for o in out)
    resource_types = {o.uid_ref for o in out}
    assert resource_types == {"n1", "r1", "t1", "u1"}


def test_apply_scim_plan_unsupported_resource_type_raises_capability_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Unknown plan rows must still fail closed with an explicit resource_type message."""
    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="z1",
            resource_type="scim_custom_placeholder",
            title="?",
            before={},
            after={},
            manifest_name="m",
        ),
    )
    with pytest.raises(CapabilityError, match="unsupported resource_type"):
        provider.apply_scim_plan(plan, dry_run=False)


def test_apply_scim_plan_mixed_push_and_structural_dry_run(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Mixed manifest (structural + push) should produce all EXIT_CHANGES in dry_run."""
    provider = _provider(monkeypatch)
    changes = [
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="n1",
            resource_type="scim_node",
            title="Eng",
            before={},
            after={"name": "Eng"},
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.UPDATE,
            uid_ref="ep1",
            resource_type="scim_push",
            title="push",
            before={},
            after={"node_id": "55", "push_type": "all"},
            manifest_name="m",
        ),
    ]
    plan = _plan(*changes)
    out = provider.apply_scim_plan(plan, dry_run=True)
    assert len(out) == 2
    actions = {o.uid_ref: o.action for o in out}
    assert actions["n1"] == "create"
    assert actions["ep1"] == "update"
