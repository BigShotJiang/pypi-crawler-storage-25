"""Policy scaffold tests for ``keeper-policy.v1``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli.main import main
from dsk.core import build_plan
from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_policy import (
    AUDIT_POLICY,
    IP_ALLOWLIST_POLICY,
    PASSWORD_POLICY,
    POLICY_FAMILY,
    SESSION_TIMEOUT_POLICY,
    SHARING_POLICY,
    TWO_FA_POLICY,
    commander_enforcement_flags_for_policy,
    compute_policy_diff,
    load_policy_manifest,
    policy_apply_order,
)
from dsk.core.schema import load_schema_for_family, validate_manifest
from dsk.providers.commander_cli import CommanderCliProvider
from dsk.providers.mock import MockProvider

ROLE_REF = "keeper-enterprise:roles:security-admins"

POLICY_CASES: list[tuple[str, str, dict[str, Any], str]] = [
    (
        "password_policies",
        PASSWORD_POLICY,
        {"min_length": 16, "min_digits": 2, "max_age_days": 90},
        "master_password_minimum_length:16",
    ),
    (
        "sharing_policies",
        SHARING_POLICY,
        {"restrict_all": True, "restrict_link_sharing": True},
        "restrict_sharing_all:true",
    ),
    (
        "two_fa_policies",
        TWO_FA_POLICY,
        {"require_two_factor": True, "duration_web": "24_hours"},
        "require_two_factor:true",
    ),
    (
        "ip_allowlist_policies",
        IP_ALLOWLIST_POLICY,
        {"login_ip_ranges": ["10.0.0.1", "10.0.1.0/24"]},
        "restrict_ip_addresses:10.0.0.1,10.0.1.0/24",
    ),
    (
        "session_timeout_policies",
        SESSION_TIMEOUT_POLICY,
        {"max_session_login_minutes": 480, "logout_timer_web_minutes": 30},
        "max_session_login_time:480",
    ),
    (
        "audit_policies",
        AUDIT_POLICY,
        {"retention_days": 365, "report_recipients": ["audit@example.com"]},
        "",
    ),
]

WIREABLE_CASES = [case for case in POLICY_CASES if case[1] != AUDIT_POLICY]


def _policy_row(resource_type: str, extra: dict[str, Any]) -> dict[str, Any]:
    return {
        "uid_ref": f"policy.{resource_type}",
        "name": f"{resource_type}-default",
        "role_uid_ref": ROLE_REF,
        **extra,
    }


def _manifest_doc(block: str, resource_type: str, extra: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema": POLICY_FAMILY,
        "name": "policy-suite",
        block: [_policy_row(resource_type, extra)],
    }


def _manifest(block: str, resource_type: str, extra: dict[str, Any]):
    return load_policy_manifest(_manifest_doc(block, resource_type, extra))


@pytest.mark.parametrize(("block", "resource_type", "extra", "_flag"), POLICY_CASES)
def test_policy_schema_and_dataclass_model_for_each_type(
    block: str,
    resource_type: str,
    extra: dict[str, Any],
    _flag: str,
) -> None:
    doc = _manifest_doc(block, resource_type, extra)

    assert validate_manifest(doc) == POLICY_FAMILY
    manifest = load_policy_manifest(doc)

    rows = list(manifest.iter_policies())
    assert rows[0][0] == resource_type
    assert rows[0][1].uid_ref == f"policy.{resource_type}"
    assert rows[0][1].role_uid_ref == ROLE_REF


@pytest.mark.parametrize(("block", "resource_type", "extra", "_flag"), POLICY_CASES)
def test_policy_diff_create_for_each_type(
    block: str,
    resource_type: str,
    extra: dict[str, Any],
    _flag: str,
) -> None:
    manifest = _manifest(block, resource_type, extra)

    changes = compute_policy_diff(manifest)

    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.CREATE
    assert changes[0].resource_type == resource_type
    assert changes[0].after["role_uid_ref"] == ROLE_REF


@pytest.mark.parametrize(("block", "resource_type", "extra", "_flag"), POLICY_CASES)
def test_policy_mock_apply_for_each_type(
    block: str,
    resource_type: str,
    extra: dict[str, Any],
    _flag: str,
) -> None:
    manifest = _manifest(block, resource_type, extra)
    plan = build_plan(manifest.name, compute_policy_diff(manifest), policy_apply_order(manifest))
    provider = MockProvider(manifest.name)

    outcomes = provider.apply_policy_plan(plan)

    assert outcomes[0].action == "create"
    records = provider.discover()
    assert records[0].resource_type == resource_type
    assert records[0].payload["role_uid_ref"] == ROLE_REF


@pytest.mark.parametrize(("block", "resource_type", "extra", "flag"), WIREABLE_CASES)
def test_policy_commander_enforcement_mapping_for_wired_types(
    block: str,
    resource_type: str,
    extra: dict[str, Any],
    flag: str,
) -> None:
    manifest = _manifest(block, resource_type, extra)
    payload = compute_policy_diff(manifest)[0].after

    flags = commander_enforcement_flags_for_policy(resource_type, payload)

    assert flag in flags


@pytest.mark.parametrize(("block", "resource_type", "extra", "flag"), WIREABLE_CASES)
def test_commander_policy_apply_dry_run_for_wired_types(
    monkeypatch: pytest.MonkeyPatch,
    block: str,
    resource_type: str,
    extra: dict[str, Any],
    flag: str,
) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    manifest = _manifest(block, resource_type, extra)
    plan = build_plan(manifest.name, compute_policy_diff(manifest), policy_apply_order(manifest))
    provider = CommanderCliProvider(manifest_source=manifest.to_dict())

    outcomes = provider.apply_policy_plan(plan, dry_run=True)

    assert outcomes[0].action == "create"
    assert outcomes[0].details["role"] == "security-admins"
    assert flag in outcomes[0].details["enforcements"]


def test_commander_policy_apply_invokes_enterprise_role_enforcement(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    manifest = _manifest(
        "password_policies",
        PASSWORD_POLICY,
        {"min_length": 20, "min_special": 2},
    )
    plan = build_plan(manifest.name, compute_policy_diff(manifest), policy_apply_order(manifest))
    provider = CommanderCliProvider(manifest_source=manifest.to_dict())
    calls: list[tuple[str, list[str]]] = []
    monkeypatch.setattr(
        provider,
        "_apply_role_enforcements",
        lambda role, flags: calls.append((role, flags)),
    )

    outcomes = provider.apply_policy_plan(plan)

    assert outcomes[0].action == "create"
    assert calls == [
        (
            "security-admins",
            ["master_password_minimum_length:20", "master_password_minimum_special:2"],
        )
    ]


def test_commander_policy_audit_reclassified_upstream_gap(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    manifest = _manifest(
        "audit_policies",
        AUDIT_POLICY,
        {"retention_days": 365, "report_recipients": ["audit@example.com"]},
    )
    provider = CommanderCliProvider(manifest_source=manifest.to_dict())
    plan = build_plan(manifest.name, compute_policy_diff(manifest), policy_apply_order(manifest))

    gaps = provider.unsupported_capabilities(manifest)

    assert len(gaps) == 1
    assert "audit-policy" in gaps[0]
    with pytest.raises(CapabilityError, match="audit-policy"):
        provider.apply_policy_plan(plan)


def test_policy_schema_is_packaged() -> None:
    schema = load_schema_for_family(POLICY_FAMILY)

    assert schema["properties"]["schema"]["const"] == POLICY_FAMILY
    assert "password_policies" in schema["properties"]


def test_policy_diff_noop_when_live_matches() -> None:
    manifest = _manifest(
        "session_timeout_policies",
        SESSION_TIMEOUT_POLICY,
        {"max_session_login_minutes": 480},
    )
    desired = compute_policy_diff(manifest)[0].after

    changes = compute_policy_diff(
        manifest,
        {"session_timeout_policies": [{**desired, "keeper_uid": "role-1"}]},
    )

    assert changes[0].kind is ChangeKind.NOOP


def test_policy_diff_delete_requires_allow_delete() -> None:
    manifest = load_policy_manifest({"schema": POLICY_FAMILY, "name": "empty"})
    live = {
        "password_policies": [
            {
                "uid_ref": "policy.password_policy",
                "name": "password-default",
                "role_uid_ref": ROLE_REF,
                "min_length": 16,
            }
        ]
    }

    skipped = compute_policy_diff(manifest, live)
    deletes = compute_policy_diff(manifest, live, allow_delete=True)

    assert skipped[0].kind is ChangeKind.SKIP
    assert deletes[0].kind is ChangeKind.DELETE


def test_policy_cli_plan_json(tmp_path: Path) -> None:
    manifest_path = tmp_path / "policy.json"
    manifest_path.write_text(
        json.dumps(
            _manifest_doc(
                "password_policies",
                PASSWORD_POLICY,
                {"min_length": 16, "min_digits": 2},
            )
        ),
        encoding="utf-8",
    )

    result = CliRunner().invoke(main, ["plan", str(manifest_path), "--json"])

    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["manifest_name"] == "policy-suite"
    assert payload["changes"][0]["resource_type"] == PASSWORD_POLICY
