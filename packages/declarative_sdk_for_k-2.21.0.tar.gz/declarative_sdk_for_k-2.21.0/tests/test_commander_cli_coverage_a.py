"""Targeted coverage for ``commander_cli`` helper branches and guarded apply paths."""

from __future__ import annotations

import builtins
import json
import sys
from subprocess import CompletedProcess, TimeoutExpired
from types import ModuleType, SimpleNamespace
from typing import Any
from unittest.mock import MagicMock

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.planner import Plan
from dsk.providers.commander_cli import (
    CommanderCliProvider,
    _enterprise_manifest_from_commander_rows,
    _saas_remove_kwargs,
    _saas_set_kwargs,
)


def _stub_keeper_params(
    monkeypatch: pytest.MonkeyPatch, provider: CommanderCliProvider
) -> SimpleNamespace:
    """Avoid real Commander login; return mutable params for MSP discover hooks."""
    sentinel = SimpleNamespace()
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: sentinel)
    return sentinel


def _pam_only_manifest() -> dict[str, Any]:
    return {"version": "1", "name": "coverage-gw-test", "resources": []}


def _patch_keepersemver(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli._keepercommander_installed_tuple",
        lambda: (18, 0, 0),
    )


def _stub_keeper_pkg_for_discover_managed(
    monkeypatch: pytest.MonkeyPatch, *, enterprise: dict[str, Any]
) -> None:
    """Inject ``keepercommander`` package + ``keepercommander.api`` for importer."""
    pkg = ModuleType("keepercommander")
    api_mod = ModuleType("keepercommander.api")

    def fake_query(p: Any) -> None:
        p.enterprise = enterprise

    api_mod.query_enterprise = fake_query
    monkeypatch.setitem(sys.modules, "keepercommander", pkg)
    monkeypatch.setitem(sys.modules, "keepercommander.api", api_mod)
    pkg.api = api_mod


def _stub_keepercommander_ksm(monkeypatch: pytest.MonkeyPatch, ksm_cls: Any) -> None:
    pkg = ModuleType("keepercommander")
    commands_pkg = ModuleType("keepercommander.commands")
    ksm_pkg = ModuleType("keepercommander.commands.ksm")
    ksm_pkg.KSMCommand = ksm_cls
    monkeypatch.setitem(sys.modules, "keepercommander", pkg)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", commands_pkg)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.ksm", ksm_pkg)


def test_enterprise_manifest_from_commander_rows_resolves_parents_roles_and_team_restrictions() -> (
    None
):
    nodes = [
        {"node_id": "n-root", "name": "RootCo", "parent_node": ""},
        {"node_id": "n-dept", "name": "Engineering", "parent_node": "RootCo"},
    ]
    users = [
        {
            "user_id": "u1",
            "email": "a@corp.test",
            "name": "Alex",
            "node": "RootCo\\Engineering",
            "status": "active",
        },
    ]
    roles = [
        {
            "role_id": "r-view",
            "name": "Viewer",
            "node": "RootCo",
            "visible_below": True,
            "default_role": False,
            "admin": False,
            "users": ["a@corp.test"],
        }
    ]
    teams = [
        {
            "team_uid": "t1",
            "name": "All Hands",
            "node": "RootCo",
            "restricts": "R, W, S",
            "users": ["a@corp.test"],
            "roles": ["Viewer"],
        }
    ]

    manifest = _enterprise_manifest_from_commander_rows(
        nodes=nodes,
        users=users,
        roles=roles,
        teams=teams,
    )

    assert manifest["schema"] == "keeper-enterprise.v1"
    assert manifest["enforcements"] == []
    root = next(n for n in manifest["nodes"] if n["name"] == "RootCo")
    dept = next(n for n in manifest["nodes"] if n["name"] == "Engineering")
    assert dept["parent_uid_ref"] == f"keeper-enterprise:nodes:{root['uid_ref']}"

    alex = manifest["users"][0]
    assert alex["email"] == "a@corp.test"
    assert alex["status"] == "active"
    assert alex["node_uid_ref"] == f"keeper-enterprise:nodes:{dept['uid_ref']}"
    viewer = manifest["roles"][0]
    assert viewer["visible_below"] is True
    assert viewer["new_user_inherit"] is False
    assert viewer["manage_nodes"] is False
    assert viewer["user_uid_refs"][0] == f"keeper-enterprise:users:{alex['uid_ref']}"
    team_row = manifest["teams"][0]
    assert team_row["restrict_view"] is True
    assert team_row["restrict_edit"] is True
    assert team_row["restrict_share"] is True
    assert team_row["role_uid_refs"] == [f"keeper-enterprise:roles:{viewer['uid_ref']}"]


@pytest.mark.parametrize(
    "default_role_val,expected_new_user_inherit",
    [
        (True, True),
        (False, False),
        ("true", True),
        ("false", False),
    ],
    ids=["true-bool", "false-bool", "true-str", "false-str"],
)
def test_default_role_maps_to_new_user_inherit_both_states(
    default_role_val: object, expected_new_user_inherit: bool
) -> None:
    """Commander CLI column ``default_role`` must map to manifest field ``new_user_inherit``
    for both the set and unset state.

    Mirrors keeperCMD Bug-3: the underlying Keeper API field is ``new_user_inherit``; DSK
    reads the CLI column output (``default_role``) and must correctly convert both boolean
    and string-boolean variants to avoid key-drift (Bug-3 / Bug-2 class from LIVE_BUGS.md).
    """
    manifest = _enterprise_manifest_from_commander_rows(
        nodes=[{"node_id": "n1", "name": "Root", "parent_node": ""}],
        users=[],
        roles=[
            {
                "role_id": "r1",
                "name": "Test Role",
                "node": "Root",
                "default_role": default_role_val,
            }
        ],
        teams=[],
    )
    role = manifest["roles"][0]
    assert "new_user_inherit" in role, (
        "default_role column must map to new_user_inherit; "
        "field absent from manifest — possible key-drift"
    )
    assert role["new_user_inherit"] is expected_new_user_inherit, (
        f"default_role={default_role_val!r} must produce new_user_inherit={expected_new_user_inherit}; "
        f"got {role['new_user_inherit']!r}"
    )


def test_enterprise_manifest_commander_live_fixture_round_trip() -> None:
    """Diff against a Commander-shaped live snapshot (not a model_dump mirror).

    Addresses the test-masking risk (Bug-48 pattern, LIVE_BUGS.md): tests that
    build ``live`` from ``desired.model_dump()`` never exercise the Commander
    row-parsing projection in ``_enterprise_manifest_from_commander_rows``.
    This test builds the live snapshot from real Commander CLI-shaped rows so
    field-name drift between Commander output and the DSK manifest model is
    detectable.
    """
    from keeper_sdk.core.enterprise_diff import compute_enterprise_diff
    from keeper_sdk.core.models_enterprise import load_enterprise_manifest

    # Simulate what Commander ``enterprise-info -r --columns ...`` returns for a role
    commander_rows = {
        "nodes": [{"node_id": "node-1", "name": "Corp", "parent_node": ""}],
        "users": [
            {
                "user_id": "user-1",
                "email": "alice@corp.test",
                "name": "Alice",
                "node": "Corp",
                "status": "active",
            }
        ],
        "roles": [
            {
                "role_id": "role-1",
                "name": "Admin",
                "node": "Corp",
                "visible_below": True,
                "default_role": True,  # Commander column name
                "admin": True,
                "users": ["alice@corp.test"],
            }
        ],
        "teams": [],
    }

    live_manifest_dict = _enterprise_manifest_from_commander_rows(**commander_rows)

    # Desired manifest mirrors what the Commander rows describe
    desired_doc = {
        "schema": "keeper-enterprise.v1",
        "nodes": [{"uid_ref": "node.node-1", "name": "Corp"}],
        "users": [
            {
                "uid_ref": "user.user-1",
                "email": "alice@corp.test",
                "name": "Alice",
                "node_uid_ref": "keeper-enterprise:nodes:node.node-1",
                "status": "active",
            }
        ],
        "roles": [
            {
                "uid_ref": "role.role-1",
                "name": "Admin",
                "node_uid_ref": "keeper-enterprise:nodes:node.node-1",
                "user_uid_refs": ["keeper-enterprise:users:user.user-1"],
                "visible_below": True,
                "new_user_inherit": True,  # DSK manifest field name
                "manage_nodes": True,
            }
        ],
    }
    desired = load_enterprise_manifest(desired_doc)
    changes = compute_enterprise_diff(desired, live_manifest_dict)

    noop_uids = {c.uid_ref for c in changes if c.kind.name == "NOOP"}
    update_uids = {c.uid_ref for c in changes if c.kind.name == "UPDATE"}

    # All entities should be NOOP — Commander's default_role maps to new_user_inherit
    assert "role.role-1" in noop_uids, (
        f"role.role-1 should be NOOP after default_role→new_user_inherit mapping; "
        f"got updates: {update_uids}"
    )


def test_enterprise_manifest_duplicate_parent_lookup_still_indexes_paths() -> None:
    manifest = _enterprise_manifest_from_commander_rows(
        nodes=[
            {"node_id": "1", "name": "Dup", "parent_node": ""},
            {"node_id": "2", "name": "Dup", "parent_node": "Parent"},
            {"node_id": "3", "name": "Child", "parent_node": "Dup"},
        ],
        users=[],
        roles=[],
        teams=[],
    )
    assert len(manifest["nodes"]) == 3


def test_saas_set_kwargs_raises_when_user_binding_missing() -> None:
    change = Change(
        kind=ChangeKind.ADD,
        uid_ref="saas-bind-1",
        resource_type="keeper_saas_binding_row",
        title="bind",
        after={"saas_config_record_uid": "keeper-vault:records:cfg1"},
        keeper_uid=None,
    )
    with pytest.raises(CapabilityError, match="missing user_uid"):
        _saas_set_kwargs(change)


def test_saas_set_kwargs_raises_when_config_missing() -> None:
    change = Change(
        kind=ChangeKind.ADD,
        uid_ref="saas-bind-2",
        resource_type="keeper_saas_binding_row",
        title="bind",
        after={"user_uid": "keeper-vault:records:uu1"},
        keeper_uid=None,
    )
    with pytest.raises(CapabilityError, match="missing config_record_uid"):
        _saas_set_kwargs(change)


def test_saas_set_kwargs_resolves_rotation_ref_and_strips_keepersPrefixes() -> None:
    change = Change(
        kind=ChangeKind.ADD,
        uid_ref="saas-bind-3",
        resource_type="keeper_saas_binding_row",
        title="bind",
        keeper_uid=None,
        after={
            "user_uid": "keeper-vault:records:user123",
            "rotation_uid_ref": "keeper-saas-rotation:rotations:rot-9",
        },
    )
    assert _saas_set_kwargs(change) == {
        "user_uid": "user123",
        "config_record_uid": "rot-9",
    }


def test_saas_remove_kwargs_falls_back_to_title_and_keeps_optional_resource() -> None:
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref=None,
        resource_type="keeper_saas_binding_row",
        title="legacy-title",
        before={
            "resource_uid": "keeper-vault:records:rid9",
        },
        keeper_uid=None,
    )
    kwargs = _saas_remove_kwargs(change)
    assert kwargs["user_uid"] == "legacy-title"
    assert kwargs["resource_uid"] == "rid9"


def test_discover_managed_companies_import_error_raises_capability(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )

    saved = builtins.__import__

    def _block_keeper_only(name: str, *args: Any, **kwargs: Any) -> Any:
        if name == "keepercommander":
            raise ImportError("simulated missing keepercommander")
        return saved(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _block_keeper_only)

    provider = CommanderCliProvider(folder_uid="fld")
    with pytest.raises(CapabilityError, match="MSP discover requires keepercommander"):
        provider.discover_managed_companies()


def test_discover_managed_companies_skips_bad_rows_and_sorts(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    _stub_keeper_pkg_for_discover_managed(
        monkeypatch,
        enterprise={
            "managed_companies": [
                {"mc_enterprise_name": "", "product_id": "business"},  # ValueError branch
                {"mc_enterprise_name": "ZebraMSP", "number_of_seats": 10},
                {"mc_enterprise_name": "AcmeMSP", "number_of_seats": 7},
                "not-a-dict",  # skipped by isinstance guard
                {"oops": True},  # missing name triggers ValueError in normaliser → skip row
            ]
        },
    )
    provider = CommanderCliProvider(folder_uid="fld")
    _stub_keeper_params(monkeypatch, provider)
    rows = provider.discover_managed_companies()
    names = [r["name"] for r in rows]
    assert names == ["AcmeMSP", "ZebraMSP"]
    assert all("name" in r for r in rows)


def test_discover_managed_companies_wraps_unexpected_exceptions(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    pkg = ModuleType("keepercommander")
    api_mod = ModuleType("keepercommander.api")
    api_mod.query_enterprise = lambda _params: (_ for _ in ()).throw(RuntimeError("mc boom"))
    monkeypatch.setitem(sys.modules, "keepercommander", pkg)
    monkeypatch.setitem(sys.modules, "keepercommander.api", api_mod)
    pkg.api = api_mod

    provider = CommanderCliProvider(folder_uid="fld")
    _stub_keeper_params(monkeypatch, provider)
    with pytest.raises(CapabilityError, match="MSP managed-company discover failed"):
        provider.discover_managed_companies()


def test_discover_managed_companies_capability_error_reraises(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    pkg = ModuleType("keepercommander")
    api_mod = ModuleType("keepercommander.api")
    api_mod.query_enterprise = lambda _params: (_ for _ in ()).throw(
        CapabilityError(reason="inner sentinel", uid_ref=None, resource_type=None)
    )
    monkeypatch.setitem(sys.modules, "keepercommander", pkg)
    monkeypatch.setitem(sys.modules, "keepercommander.api", api_mod)
    pkg.api = api_mod

    provider = CommanderCliProvider(folder_uid="fld")
    _stub_keeper_params(monkeypatch, provider)
    with pytest.raises(CapabilityError, match="inner sentinel"):
        provider.discover_managed_companies()


def test_run_enterprise_info_cmd_timeout_raises_capability(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )

    def _boom(cmd: Any, **_kwargs: Any) -> CompletedProcess[str]:
        raise TimeoutExpired(cmd, timeout=60)

    monkeypatch.setattr(
        "dsk.providers.commander_cli.subprocess.run",
        lambda *a, **k: _boom(a[0] if a else []),
    )

    provider = CommanderCliProvider(folder_uid="fld")
    with pytest.raises(CapabilityError, match="timed out"):
        provider._run_enterprise_info_cmd(
            ["enterprise-info", "--format", "json"],
            command="enterprise-info probe",
        )


def test_run_enterprise_info_cmd_nonzero_rc_raises_capability(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )

    monkeypatch.setattr(
        "dsk.providers.commander_cli.subprocess.run",
        lambda *_a, **_k: CompletedProcess([], 9, stdout="oops", stderr="bad"),
    )

    provider = CommanderCliProvider(folder_uid="fld")
    with pytest.raises(CapabilityError) as excinfo:
        provider._run_enterprise_info_cmd(["enterprise-info"], command="enterprise-info fail")
    assert "failed (rc=9)" in excinfo.value.reason
    assert "oops" in str(excinfo.value.context.get("stdout"))


def test_discover_enterprise_requires_node_rows(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )

    monkeypatch.setattr(
        CommanderCliProvider,
        "_run_enterprise_info_cmd",
        lambda self, args, *, command: "[]",
    )

    provider = CommanderCliProvider(folder_uid="fld")
    with pytest.raises(CapabilityError, match="no node rows"):
        provider.discover_enterprise()


def test_discover_enterprise_handles_non_json_list_payload(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    payloads = iter([json.dumps({"kind": "object"})])

    monkeypatch.setattr(
        CommanderCliProvider,
        "_run_enterprise_info_cmd",
        lambda self, args, *, command: next(payloads),
    )

    provider = CommanderCliProvider(folder_uid="fld")
    with pytest.raises(CapabilityError, match="non-array JSON"):
        provider.discover_enterprise()


def test_discover_enterprise_wraps_generic_exception(monkeypatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )

    monkeypatch.setattr(
        CommanderCliProvider,
        "_run_enterprise_info_cmd",
        lambda self, args, *, command: (_ for _ in ()).throw(ValueError("parse boom")),
    )

    provider = CommanderCliProvider(folder_uid="fld")
    with pytest.raises(CapabilityError, match="enterprise-info discover failed"):
        provider.discover_enterprise()


def test_apply_gateway_dry_run_create_update_delete_argv_shapes(monkeypatch) -> None:
    _patch_keepersemver(monkeypatch)
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    recorder: list[list[str]] = []

    def _no_shell(self: CommanderCliProvider, args: list[str]) -> str:
        recorder.append(list(args))
        return ""

    monkeypatch.setattr(CommanderCliProvider, "_run_cmd", _no_shell)

    provider = CommanderCliProvider(folder_uid="fld", manifest_source=_pam_only_manifest())
    plan = Plan(
        manifest_name=_pam_only_manifest()["name"],
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="gw-create",
                resource_type="gateway",
                title="edge-gw",
                after={
                    "name": "edge-gw",
                    "ksm_application_name": "ProdKsmApp",
                },
            ),
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="gw-update",
                resource_type="gateway",
                title="edge-gw-2",
                keeper_uid="keeper-uid-live",
                after={"name": "edge-gw-2-renamed", "node_id": "node-777"},
                before={},
            ),
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="gw-delete",
                resource_type="gateway",
                title="obsolete",
                keeper_uid="obsolete-uid",
            ),
        ],
        order=["gw-create", "gw-update", "gw-delete"],
    )

    outcomes = provider.apply_plan(plan, dry_run=True)

    commander_argvs = [
        tuple(o.details["commander_argv"])
        for o in outcomes
        if (o.details or {}).get("commander_argv") is not None
    ]
    wanted_new = tuple(
        [
            "pam",
            "gateway",
            "new",
            "--name",
            "edge-gw",
            "--application",
            "ProdKsmApp",
            "--return_value",
        ]
    )
    assert wanted_new in commander_argvs

    argv_edit = [
        "pam",
        "gateway",
        "edit",
        "--gateway",
        "keeper-uid-live",
        "--name",
        "edge-gw-2-renamed",
        "--node-id",
        "node-777",
    ]

    details_by_ref = {o.uid_ref: o for o in outcomes}
    assert details_by_ref["gw-update"].details["commander_argv"] == argv_edit
    rm_argv = ["pam", "gateway", "remove", "--gateway", "obsolete-uid"]
    assert details_by_ref["gw-delete"].details["commander_argv"] == rm_argv
    assert recorder == []


def test_apply_gateway_update_no_fields_is_noop(monkeypatch) -> None:
    _patch_keepersemver(monkeypatch)
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    edits: list[tuple[Any, ...]] = []

    monkeypatch.setattr(
        CommanderCliProvider, "_pam_gateway_edit", lambda *args, **kwargs: edits.append(args)
    )

    def _boom(self: CommanderCliProvider, args: list[str]) -> str:
        raise AssertionError(f"unexpected _run_cmd: {args}")

    monkeypatch.setattr(CommanderCliProvider, "_run_cmd", _boom)

    provider = CommanderCliProvider(folder_uid="fld", manifest_source=_pam_only_manifest())
    plan = Plan(
        manifest_name=_pam_only_manifest()["name"],
        changes=[
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="gw-plain",
                resource_type="gateway",
                title="only-title",
                keeper_uid="GWUID",
                after={},
                before={},
            ),
        ],
        order=["gw-plain"],
    )
    outs = provider.apply_plan(plan)
    assert outs[0].action == "noop"
    assert "no gateway edit fields" in outs[0].details.get("reason", "")
    assert edits == []


def test_apply_gateway_non_dry_create_records_outcome(monkeypatch) -> None:
    _patch_keepersemver(monkeypatch)
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    pam_calls: list[tuple[Any, ...]] = []

    def _pam_new(self: CommanderCliProvider, name: str, app_uid: str, **kwargs: Any) -> None:
        pam_calls.append((name, app_uid, kwargs.get("node_id")))

    monkeypatch.setattr(CommanderCliProvider, "_pam_gateway_new", _pam_new)
    monkeypatch.setattr(CommanderCliProvider, "_run_cmd", lambda self, args: "")
    monkeypatch.setattr(
        CommanderCliProvider, "_pam_gateway_edit", MagicMock(side_effect=AssertionError)
    )
    monkeypatch.setattr(
        CommanderCliProvider, "_pam_gateway_remove", MagicMock(side_effect=AssertionError)
    )

    provider = CommanderCliProvider(folder_uid="fld", manifest_source=_pam_only_manifest())
    manifest_name = _pam_only_manifest()["name"]
    plan = Plan(
        manifest_name=manifest_name,
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="gw-prod",
                resource_type="gateway",
                title="prod-gw",
                after={
                    "name": "prod-gw",
                    "ksm_application_name": "KsmNine",
                    "node_id": "node-555",
                },
            ),
        ],
        order=["gw-prod"],
    )
    outs = provider.apply_plan(plan)
    assert pam_calls == [("prod-gw", "KsmNine", "node-555")]
    assert outs[0].action == "create"
    assert outs[0].details["manifest"] == manifest_name
    assert outs[0].details["one_time_token_returned"] is True


def test_apply_ksm_app_delete_and_rename_dry_run(monkeypatch) -> None:
    _patch_keepersemver(monkeypatch)

    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    removals: list[Any] = []
    monkeypatch.setattr(
        CommanderCliProvider, "ksm_app_remove", lambda *_a, **_k: removals.append(True)
    )

    _stub_keepercommander_ksm(
        monkeypatch,
        MagicMock(
            update_app=MagicMock(side_effect=AssertionError("dry_run must skip update_app")),
        ),
    )

    provider = CommanderCliProvider(folder_uid="fld")
    plan = Plan(
        manifest_name="ksm-batch",
        changes=[
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="app-del",
                resource_type="ksm_app",
                title="OldApp",
                keeper_uid="deadbeef",
                before={},
            ),
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="app-ren",
                resource_type="ksm_app",
                title="Current",
                keeper_uid="ab12cd34ef",
                before={"name": "Current"},
                after={"name": "RenamedApp"},
            ),
        ],
        order=["app-del", "app-ren"],
    )

    outs = provider.apply_ksm_plan(plan, dry_run=True)
    assert removals == []
    delete_out = next(o for o in outs if o.action == "delete")
    rename_out = next(o for o in outs if o.action == "update" and "new_name" in o.details)
    assert delete_out.details["dry_run"] is True
    assert delete_out.details["force"] is True
    assert rename_out.details == {"dry_run": True, "new_name": "RenamedApp"}


def test_apply_ksm_app_rename_requires_new_name(monkeypatch) -> None:
    _patch_keepersemver(monkeypatch)

    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    provider = CommanderCliProvider(folder_uid="fld")
    plan = Plan(
        manifest_name="ksm",
        changes=[
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="broken",
                resource_type="ksm_app",
                title="NoNameMeta",
                keeper_uid="uuid",
                after={},
                before={"name": "NoNameMeta"},
            ),
        ],
        order=["broken"],
    )
    with pytest.raises(CapabilityError, match="no new 'name'"):
        provider.apply_ksm_plan(plan)


def test_apply_ksm_app_rename_capability_when_ks_command_missing(monkeypatch) -> None:
    _patch_keepersemver(monkeypatch)

    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    importer = builtins.__import__

    def _block_ksm(name: str, *args: Any, **kwargs: Any) -> Any:
        if name == "keepercommander.commands.ksm":
            raise ImportError("missing ksm command module")
        return importer(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _block_ksm)

    provider = CommanderCliProvider(folder_uid="fld")
    plan = Plan(
        manifest_name="ksm",
        changes=[
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="blocked",
                resource_type="ksm_app",
                title="t",
                keeper_uid="uuid",
                after={"name": "Next"},
                before={},
            ),
        ],
        order=["blocked"],
    )
    with pytest.raises(CapabilityError) as excinfo:
        provider.apply_ksm_plan(plan)
    assert "KSMCommand is unavailable" in excinfo.value.reason
