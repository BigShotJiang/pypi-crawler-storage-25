"""keeper-drive.v1 private schema and typed-model scaffold tests."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
import yaml

from dsk.core.errors import SchemaError
from dsk.core.manifest import load_declarative_manifest_string
from dsk.core.models_keeper_drive import (
    KEEPER_DRIVE_FAMILY,
    KeeperDriveManifestV1,
    load_keeper_drive_manifest,
)
from dsk.core.schema import load_schema_for_family, validate_manifest


def _doc() -> dict[str, Any]:
    return yaml.safe_load(
        Path("tests/fixtures/examples/keeper-drive/environment.yaml").read_text(encoding="utf-8")
    )


def test_keeper_drive_schema_is_private_and_packaged() -> None:
    schema = load_schema_for_family(KEEPER_DRIVE_FAMILY)

    assert schema["title"] == KEEPER_DRIVE_FAMILY
    assert schema["x-keeper-live-proof"]["status"] == "preview-gated"
    assert "PR #1975" in schema["x-keeper-live-proof"]["evidence"]


def test_keeper_drive_fixture_validates_and_loads_typed_model() -> None:
    document = _doc()

    assert validate_manifest(document) == KEEPER_DRIVE_FAMILY
    loaded = load_declarative_manifest_string(json.dumps(document), suffix=".json")

    assert isinstance(loaded, KeeperDriveManifestV1)
    assert loaded.files[0].folder_uid_ref == "keeper-drive:folders:folder.root"
    assert loaded.shares[0].permission == "read"


def test_keeper_drive_family_constant_matches_schema_title() -> None:
    assert KEEPER_DRIVE_FAMILY == "keeper-drive.v1"
    schema = load_schema_for_family(KEEPER_DRIVE_FAMILY)
    assert schema["title"] == KEEPER_DRIVE_FAMILY


def test_keeper_drive_schema_has_files_and_shares_properties() -> None:
    schema = load_schema_for_family(KEEPER_DRIVE_FAMILY)
    props = schema.get("properties", {})
    assert "files" in props or "folders" in props or "shares" in props


def test_keeper_drive_validate_manifest_returns_correct_family() -> None:
    document = _doc()
    family = validate_manifest(document)
    assert family == KEEPER_DRIVE_FAMILY


def test_register_private_adds_drive_to_registry() -> None:
    """register_private must add KEEPER_DRIVE_FAMILY to a provided empty dict."""
    from dsk.core._private_families import register_private

    registry: dict[str, str] = {}
    register_private(registry)
    assert KEEPER_DRIVE_FAMILY in registry


def test_load_private_manifest_returns_none_for_public_family() -> None:
    """load_private_manifest must return None for non-drive families."""
    from dsk.core._private_families import load_private_manifest

    result = load_private_manifest("pam-environment.v1", {"schema": "pam-environment.v1"})
    assert result is None


def test_keeper_drive_loader_rejects_unknown_file_ref() -> None:
    document = _doc()
    document["shares"][0]["file_uid_ref"] = "keeper-drive:files:file.missing"

    with pytest.raises(SchemaError) as exc:
        load_keeper_drive_manifest(document)

    assert "unknown KeeperDrive file refs" in exc.value.reason


def test_compute_keeper_drive_diff_not_implemented_on_live() -> None:
    """compute_keeper_drive_diff raises NotImplementedError when live data is passed."""
    import pytest

    from dsk.core.keeper_drive_diff import compute_keeper_drive_diff
    from dsk.core.models_keeper_drive import load_keeper_drive_manifest

    doc = _doc()
    manifest = load_keeper_drive_manifest(doc)
    with pytest.raises(NotImplementedError):
        compute_keeper_drive_diff(manifest, live=[{"uid_ref": "x"}])


def test_compute_keeper_drive_diff_emits_resource_types() -> None:
    """compute_keeper_drive_diff emits folder, file, and share resource types."""
    from dsk.core.keeper_drive_diff import compute_keeper_drive_diff
    from dsk.core.models_keeper_drive import load_keeper_drive_manifest

    doc = _doc()
    manifest = load_keeper_drive_manifest(doc)
    changes = compute_keeper_drive_diff(manifest, live=None)
    types = {c.resource_type for c in changes}
    assert "keeper_drive_folder" in types
    assert "keeper_drive_file" in types
    assert "keeper_drive_share" in types
