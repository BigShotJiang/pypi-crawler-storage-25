"""Tests for secret scanner bridge manifest + integration module."""

import json
from pathlib import Path

import pytest
import yaml


def test_manifest_defaults():
    from dsk.core.models_secret_scanner import (
        SecretScannerBridgeManifestV1,
        SecretScannerSource,
    )

    m = SecretScannerBridgeManifestV1(**{"schema": "secret-scanner-bridge.v1", "name": "t"})
    assert m.schema_ == "secret-scanner-bridge.v1"
    assert m.source == SecretScannerSource.github
    assert m.dry_run_mode is False
    assert m.mappings == []


def test_manifest_round_trip():
    from dsk.core.models_secret_scanner import (
        RotationSeverity,
        SecretScannerBridgeManifestV1,
    )

    example = (
        Path(__file__).parent.parent / "examples/secret_scanner/acme-secret-scanner-bridge.yaml"
    )
    data = yaml.safe_load(example.read_text())
    manifest = SecretScannerBridgeManifestV1(**data)
    assert manifest.schema_ == "secret-scanner-bridge.v1"
    assert len(manifest.repos) == 3
    assert len(manifest.mappings) == 5
    aws_mapping = manifest.mappings[0]
    assert aws_mapping.secret_type == "aws_access_key_id"
    assert aws_mapping.severity == RotationSeverity.critical
    assert aws_mapping.auto_rotate is True
    no_auto = manifest.mappings[4]
    assert no_auto.auto_rotate is False


def test_normalize_github_alert():
    from dsk.integrations.secret_scanner_bridge import normalize_github_alert

    payload = {
        "alert": {
            "secret_type": "aws_access_key_id",
            "state": "open",
            "html_url": "https://github.com/acme/backend/security/secret-scanning/1",
            "number": 42,
        },
        "repository": {"full_name": "acme/backend"},
    }
    result = normalize_github_alert(payload)
    assert result["secret_type"] == "aws_access_key_id"
    assert result["state"] == "open"
    assert result["repo"] == "acme/backend"


def test_find_mapping():
    from dsk.integrations.secret_scanner_bridge import find_mapping

    mappings = [
        {"secret_type": "aws_access_key_id", "keeper_uid_ref": "res.aws"},
        {"secret_type": "cloudflare_api_token", "keeper_uid_ref": "res.cf"},
    ]
    assert find_mapping("aws_access_key_id", mappings)["keeper_uid_ref"] == "res.aws"
    assert find_mapping("CLOUDFLARE_API_TOKEN", mappings)["keeper_uid_ref"] == "res.cf"
    assert find_mapping("unknown_type", mappings) is None


def test_handle_alert_dry_run():
    from dsk.integrations.secret_scanner_bridge import handle_alert

    payload = json.dumps(
        {
            "alert": {
                "secret_type": "aws_access_key_id",
                "state": "open",
                "html_url": "https://example.com/1",
                "number": 1,
            },
            "repository": {"full_name": "acme/test"},
        }
    ).encode()
    mappings = [
        {
            "secret_type": "aws_access_key_id",
            "keeper_uid_ref": "res.aws",
            "auto_rotate": True,
            "severity": "critical",
        }
    ]
    result = handle_alert(payload, "", mappings, dry_run=True)
    assert result["action"] == "rotate"
    assert result["dry_run"] is True


def test_handle_alert_closed_state():
    from dsk.integrations.secret_scanner_bridge import handle_alert

    payload = json.dumps(
        {
            "alert": {
                "secret_type": "aws_access_key_id",
                "state": "resolved",
                "html_url": "",
                "number": 1,
            },
            "repository": {"full_name": "acme/test"},
        }
    ).encode()
    result = handle_alert(payload, "", [], dry_run=True)
    assert result["action"] == "skip"


def test_schema_alias():
    from dsk.core.models_secret_scanner import SecretScannerBridgeManifestV1

    m = SecretScannerBridgeManifestV1(**{"schema": "secret-scanner-bridge.v1", "name": "t"})
    assert m.schema_ == "secret-scanner-bridge.v1"


def test_compute_secret_scanner_diff_not_implemented_on_live() -> None:
    """compute_secret_scanner_diff raises NotImplementedError when live data is passed."""
    import pytest

    from dsk.core.models_secret_scanner import SecretScannerBridgeManifestV1
    from dsk.core.secret_scanner_diff import compute_secret_scanner_diff

    manifest = SecretScannerBridgeManifestV1(**{"schema": "secret-scanner-bridge.v1", "name": "t"})
    with pytest.raises(NotImplementedError):
        compute_secret_scanner_diff(manifest, live=[{"uid_ref": "x"}])


def test_compute_secret_scanner_diff_emits_repo_and_mapping_types() -> None:
    """compute_secret_scanner_diff emits secret_scanner_repo and mapping resource types."""
    from dsk.core.models_secret_scanner import SecretScannerBridgeManifestV1
    from dsk.core.secret_scanner_diff import compute_secret_scanner_diff

    manifest = SecretScannerBridgeManifestV1(
        **{
            "schema": "secret-scanner-bridge.v1",
            "name": "test-ss",
            "repos": ["acme/backend"],
            "mappings": [
                {
                    "secret_type": "aws_access_key_id",
                    "keeper_uid_ref": "keeper-vault:records:rec.one",
                }
            ],
        }
    )
    changes = compute_secret_scanner_diff(manifest, live=None)
    types = {c.resource_type for c in changes}
    assert "secret_scanner_repo" in types
    assert "secret_scanner_mapping" in types


def test_verify_github_hmac_valid() -> None:
    """verify_github_hmac returns True for a matching HMAC."""
    import hashlib
    import hmac as hmac_lib

    from dsk.integrations.secret_scanner_bridge import verify_github_hmac

    body = b"webhook-body"
    secret = "webhook-secret"
    sig = "sha256=" + hmac_lib.new(secret.encode(), body, hashlib.sha256).hexdigest()
    assert verify_github_hmac(body, sig, secret) is True


def test_verify_github_hmac_bad_prefix() -> None:
    """verify_github_hmac returns False for signatures without sha256= prefix."""
    from dsk.integrations.secret_scanner_bridge import verify_github_hmac

    assert verify_github_hmac(b"body", "md5=abc123", "secret") is False


def test_handle_alert_hmac_failure(monkeypatch) -> None:
    """handle_alert raises ScannerBridgeError when HMAC verification fails."""
    import json

    import pytest

    from dsk.integrations.secret_scanner_bridge import ScannerBridgeError, handle_alert

    monkeypatch.setenv("SECRET_SCANNER_WEBHOOK_SECRET", "real-secret")
    payload = json.dumps({"alert": {"state": "open"}, "repository": {"full_name": "x/y"}}).encode()
    with pytest.raises(ScannerBridgeError, match="HMAC"):
        handle_alert(payload, "sha256=badsig", [], dry_run=True)


def test_handle_alert_no_mapping_skips() -> None:
    """handle_alert returns skip when no mapping is found for the secret type."""
    import json

    from dsk.integrations.secret_scanner_bridge import handle_alert

    payload = json.dumps(
        {
            "alert": {
                "secret_type": "aws_access_key_id",
                "state": "open",
                "html_url": "",
                "number": 1,
            },
            "repository": {"full_name": "acme/backend"},
        }
    ).encode()
    result = handle_alert(payload, "", [], dry_run=True)
    assert result["action"] == "skip"
    assert result["reason"] == "no_mapping"


def test_handle_alert_accepts_at_webhook_byte_cap(monkeypatch: pytest.MonkeyPatch) -> None:
    from dsk.integrations.secret_scanner_bridge import handle_alert

    payload = json.dumps(
        {
            "alert": {"secret_type": "token", "state": "open", "html_url": "", "number": 1},
            "repository": {"full_name": "acme/backend"},
        }
    ).encode()
    monkeypatch.setenv("DSK_SECRET_SCANNER_MAX_WEBHOOK_BYTES", str(len(payload)))

    result = handle_alert(payload, "", [], dry_run=True)

    assert result["action"] == "skip"


def test_handle_alert_rejects_just_over_webhook_byte_cap(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from dsk.integrations.secret_scanner_bridge import ScannerBridgeError, handle_alert

    payload = json.dumps(
        {
            "alert": {"secret_type": "token", "state": "open", "html_url": "", "number": 1},
            "repository": {"full_name": "acme/backend"},
        }
    ).encode()
    monkeypatch.setenv("DSK_SECRET_SCANNER_MAX_WEBHOOK_BYTES", str(len(payload) - 1))

    with pytest.raises(ScannerBridgeError, match="DSK_SECRET_SCANNER_MAX_WEBHOOK_BYTES"):
        handle_alert(payload, "", [], dry_run=True)
