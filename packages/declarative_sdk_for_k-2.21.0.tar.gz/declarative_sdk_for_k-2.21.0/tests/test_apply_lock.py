"""Tests for DSK distributed apply lock (file-based)."""

import json
import os
import pathlib
import threading
import time

import pytest

from dsk.core import lock as lock_module
from dsk.core.lock import ApplyLockError, FileLock, LockInfo, _manifest_hash


def test_lock_acquire_and_release(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/manifest.yaml"
    pathlib.Path(manifest).write_text("family: test\n", encoding="utf-8")
    lock = FileLock(manifest)
    info = lock.acquire()
    assert info.holder.endswith(str(os.getpid()))
    assert info.pid == os.getpid()
    assert info.pid_start_time
    lock.release()
    assert not __import__("pathlib").Path(manifest + ".dsk-lock").exists()


def test_lock_context_manager(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/manifest.yaml"
    pathlib.Path(manifest).write_text("family: test\n", encoding="utf-8")
    with FileLock(manifest) as info:
        assert info is not None
    assert not __import__("pathlib").Path(manifest + ".dsk-lock").exists()


def test_double_acquire_raises(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/manifest.yaml"
    pathlib.Path(manifest).write_text("family: test\n", encoding="utf-8")
    lock1 = FileLock(manifest)
    lock2 = FileLock(manifest)
    lock1.acquire()
    try:
        with pytest.raises(ApplyLockError, match="held by"):
            lock2.acquire()
    finally:
        lock1.release()


def test_lock_released_on_exception(tmp_path: object) -> None:
    """Lock file must be cleaned up even if the body raises."""
    manifest = str(tmp_path / "manifest.yaml")
    pathlib.Path(manifest).write_text("family: test\n")
    lock = FileLock(manifest)
    try:
        with lock:
            raise ValueError("simulate apply failure")
    except ValueError:
        pass
    assert not pathlib.Path(manifest + ".dsk-lock").exists()


def test_lock_info_round_trip_dict():
    """LockInfo serializes to flat strings and reconstructs via from_dict."""
    info = LockInfo(
        holder="host:123",
        acquired_at=1000.5,
        manifest_hash="deadbeef",
        expires_at=2000.0,
        pid=123,
    )
    restored = LockInfo.from_dict(info.to_dict())
    assert restored == info


def test_acquire_overwrites_corrupt_lock_file(tmp_path: object) -> None:
    """Malformed lock JSON is replaced on acquire."""
    manifest = str(tmp_path / "manifest.yaml")
    pathlib.Path(manifest).write_text("family: test\n")
    pathlib.Path(manifest + ".dsk-lock").write_text("{ not valid json")
    lock = FileLock(manifest)
    lock.acquire()
    lock.release()
    assert not pathlib.Path(manifest + ".dsk-lock").exists()


def test_expired_existing_lock_allows_acquire(tmp_path: object) -> None:
    """Stale lock file with past expires_at is overwritten."""
    manifest = str(tmp_path / "manifest.yaml")
    pathlib.Path(manifest).write_text("family: test\n")
    lock_path = pathlib.Path(manifest + ".dsk-lock")
    old = LockInfo(
        holder="other:999",
        acquired_at=time.time() - 1000.0,
        manifest_hash="x",
        expires_at=time.time() - 1.0,
    )
    lock_path.write_text(json.dumps(old.to_dict()))
    lock = FileLock(manifest)
    info = lock.acquire()
    assert "other:999" not in info.holder
    lock.release()
    assert not lock_path.exists()


def test_dead_pid_lock_file_is_cleaned_up(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")
    lock_path = pathlib.Path(str(manifest) + ".dsk-lock")
    dead_pid = 42424242
    old = LockInfo(
        holder=f"other:{dead_pid}",
        acquired_at=time.time(),
        manifest_hash="x",
        expires_at=time.time() + 60.0,
        pid=dead_pid,
        pid_start_time="old-start",
    )
    lock_path.write_text(json.dumps(old.to_dict()), encoding="utf-8")
    monkeypatch.setattr(
        lock_module,
        "_pid_exists",
        lambda pid: False if pid == dead_pid else True,
    )

    lock = FileLock(str(manifest))
    info = lock.acquire()

    assert info.pid == os.getpid()
    assert f"other:{dead_pid}" not in info.holder
    lock.release()
    assert not lock_path.exists()


def test_stale_pid_start_time_lock_file_is_cleaned_up(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")
    lock_path = pathlib.Path(str(manifest) + ".dsk-lock")
    pid = os.getpid()
    old = LockInfo(
        holder=f"other:{pid}",
        acquired_at=time.time(),
        manifest_hash="x",
        expires_at=time.time() + 60.0,
        pid=pid,
        pid_start_time="old-start",
    )
    lock_path.write_text(json.dumps(old.to_dict()), encoding="utf-8")
    monkeypatch.setattr(lock_module, "_process_start_stamp", lambda _: "new-start")

    lock = FileLock(str(manifest))
    info = lock.acquire()

    assert info.pid_start_time == "new-start"
    lock.release()
    assert not lock_path.exists()


def test_live_pid_start_time_metadata_without_os_lock_is_rejected(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")
    lock_path = pathlib.Path(str(manifest) + ".dsk-lock")
    pid = os.getpid()
    live = LockInfo(
        holder=f"other:{pid}",
        acquired_at=time.time(),
        manifest_hash="x",
        expires_at=time.time() + 60.0,
        pid=pid,
        pid_start_time="same-start",
    )
    lock_path.write_text(json.dumps(live.to_dict()), encoding="utf-8")
    monkeypatch.setattr(lock_module, "_process_start_stamp", lambda _: "same-start")

    with pytest.raises(ApplyLockError, match=f"other:{pid}"):
        FileLock(str(manifest)).acquire()


def test_concurrent_acquisition_under_thread_load(tmp_path: pathlib.Path) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")
    worker_count = 16
    barrier = threading.Barrier(worker_count)
    release_event = threading.Event()
    results: list[bool] = []
    results_lock = threading.Lock()

    def contender() -> None:
        barrier.wait(timeout=5)
        lock = FileLock(str(manifest))
        try:
            lock.acquire()
        except ApplyLockError:
            with results_lock:
                results.append(False)
            return

        with results_lock:
            results.append(True)
        release_event.wait(timeout=5)
        lock.release()

    threads = [threading.Thread(target=contender) for _ in range(worker_count)]
    for thread in threads:
        thread.start()

    deadline = time.time() + 5
    while time.time() < deadline:
        with results_lock:
            if len(results) == worker_count:
                break
        time.sleep(0.01)
    release_event.set()
    for thread in threads:
        thread.join(timeout=5)

    assert results.count(True) == 1
    assert results.count(False) == worker_count - 1


def test_permission_error_opening_lock_becomes_apply_lock_error(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")
    lock_path = pathlib.Path(str(manifest) + ".dsk-lock")
    original_open = pathlib.Path.open

    def deny_lock_open(self: pathlib.Path, *args: object, **kwargs: object) -> object:
        if self == lock_path:
            raise PermissionError("denied")
        return original_open(self, *args, **kwargs)

    monkeypatch.setattr(pathlib.Path, "open", deny_lock_open)

    with pytest.raises(ApplyLockError, match="Could not open apply lock"):
        FileLock(str(manifest)).acquire()


def test_release_without_acquire_is_noop(tmp_path: pathlib.Path) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")

    FileLock(str(manifest)).release()


def test_release_swallows_unlink_error_and_releases_registry(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")
    lock_path = pathlib.Path(str(manifest) + ".dsk-lock")
    original_unlink = pathlib.Path.unlink
    lock = FileLock(str(manifest))
    lock.acquire()

    def flaky_unlink(self: pathlib.Path, *args: object, **kwargs: object) -> object:
        if self == lock_path:
            raise OSError("simulated unlink failure")
        return original_unlink(self, *args, **kwargs)

    monkeypatch.setattr(pathlib.Path, "unlink", flaky_unlink)
    lock.release()
    monkeypatch.undo()

    lock_path.unlink(missing_ok=True)
    second = FileLock(str(manifest))
    second.acquire()
    second.release()


def test_lock_read_info_rejects_blank_and_non_object(tmp_path: pathlib.Path) -> None:
    lock_path = tmp_path / "lock"
    lock_path.write_bytes(b"   ")
    with lock_path.open("rb") as fh:
        assert lock_module._read_lock_info_from_handle(fh) is None

    lock_path.write_text("[]", encoding="utf-8")
    with lock_path.open("rb") as fh:
        assert lock_module._read_lock_info_from_handle(fh) is None


def test_lock_read_info_os_error_becomes_apply_lock_error(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    lock_path = tmp_path / "lock"
    lock_path.write_text("{}", encoding="utf-8")

    def broken_fstat(_fd: int) -> object:
        raise OSError("fstat failed")

    monkeypatch.setattr(lock_module.os, "fstat", broken_fstat)
    with lock_path.open("rb") as fh:
        with pytest.raises(ApplyLockError, match="metadata"):
            lock_module._read_lock_info_from_handle(fh)


def test_process_start_stamp_fallbacks(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lock_module, "_pid_exists", lambda _pid: False)
    assert lock_module._process_start_stamp(12345) is None

    monkeypatch.setattr(lock_module, "_pid_exists", lambda _pid: True)

    def fake_proc_stat(self: pathlib.Path, *args: object, **kwargs: object) -> str:
        if str(self) == "/proc/12345/stat":
            return "12345 (python) " + " ".join(["S", *[str(i) for i in range(1, 21)]])
        raise OSError("missing")

    monkeypatch.setattr(pathlib.Path, "read_text", fake_proc_stat)
    assert lock_module._process_start_stamp(12345) == "linux-starttime:19"

    def bad_proc_stat(self: pathlib.Path, *args: object, **kwargs: object) -> str:
        if str(self) == "/proc/12345/stat":
            return "not a proc stat"
        raise OSError("missing")

    class Result:
        returncode = 0
        stdout = "Sun May 10 10:00:00 2026\n"

    monkeypatch.setattr(pathlib.Path, "read_text", bad_proc_stat)
    monkeypatch.setattr(lock_module.subprocess, "run", lambda *_args, **_kwargs: Result())
    assert lock_module._process_start_stamp(12345).startswith("ps-lstart:")


def test_lock_file_read_accepts_at_byte_cap(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = str(tmp_path / "manifest.yaml")
    pathlib.Path(manifest).write_text("family: test\n")
    lock_path = pathlib.Path(manifest + ".dsk-lock")
    old = LockInfo(
        holder="other:999",
        acquired_at=time.time(),
        manifest_hash="x",
        expires_at=time.time() + 60.0,
    )
    raw = json.dumps(old.to_dict())
    lock_path.write_text(raw, encoding="utf-8")
    monkeypatch.setenv("DSK_LOCK_MAX_BYTES", str(len(raw.encode("utf-8"))))

    with pytest.raises(ApplyLockError, match="other:999"):
        FileLock(manifest).acquire()


def test_lock_file_read_rejects_just_over_byte_cap(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = str(tmp_path / "manifest.yaml")
    pathlib.Path(manifest).write_text("family: test\n")
    lock_path = pathlib.Path(manifest + ".dsk-lock")
    old = LockInfo(
        holder="other:999",
        acquired_at=time.time(),
        manifest_hash="x",
        expires_at=time.time() + 60.0,
    )
    raw = json.dumps(old.to_dict())
    lock_path.write_text(raw, encoding="utf-8")
    monkeypatch.setenv("DSK_LOCK_MAX_BYTES", str(len(raw.encode("utf-8")) - 1))

    lock = FileLock(manifest)
    info = lock.acquire()

    assert "other:999" not in info.holder
    lock.release()


def test_lock_manifest_hash_accepts_at_byte_cap(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")
    monkeypatch.setenv("DSK_LOCK_MAX_MANIFEST_BYTES", str(manifest.stat().st_size))

    assert _manifest_hash(str(manifest)) != "unknown"


def test_lock_manifest_hash_rejects_just_over_byte_cap(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("family: test\n", encoding="utf-8")
    monkeypatch.setenv("DSK_LOCK_MAX_MANIFEST_BYTES", str(manifest.stat().st_size - 1))

    assert _manifest_hash(str(manifest)) == "unknown"
