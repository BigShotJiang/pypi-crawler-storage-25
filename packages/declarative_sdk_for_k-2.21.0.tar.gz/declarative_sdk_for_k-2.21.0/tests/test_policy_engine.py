"""Tests for the DSK policy engine (offline — no OPA binary required)."""

from __future__ import annotations

from dsk.policy.engine import PolicyEngine, validate_policy


def test_unknown_engine_returns_error() -> None:
    result = validate_policy({}, "policy.rego", engine="unknown")  # type: ignore[arg-type]
    assert not result.passed
    assert result.error is not None


def test_cedar_stub_returns_milestone_note() -> None:
    result = validate_policy({}, "policy.cedar", engine=PolicyEngine.CEDAR)
    # Cedar is a future milestone — stub must signal "not evaluated", not "passed"
    assert result.engine == PolicyEngine.CEDAR
    assert "milestone" in (result.error or "").lower()
    # evaluated=False distinguishes "skipped" from a genuine policy pass
    assert result.evaluated is False
    assert result.passed is False
    assert "cedar not integrated" in (result.error or "").lower()


def test_opa_missing_binary_returns_error() -> None:
    """When OPA binary is absent, should return PolicyResult with error not crash."""
    from unittest.mock import patch

    with patch("subprocess.run", side_effect=FileNotFoundError("opa not found")):
        result = validate_policy({"name": "test"}, "policy.rego", engine=PolicyEngine.OPA)
    assert not result.passed
    assert result.error is not None


def test_policy_violation_dataclass() -> None:
    from dsk.policy.engine import PolicyViolation

    v = PolicyViolation(resource_uid_ref="res.x", rule="deny", message="missing rotation")
    assert v.severity == "error"
    assert "rotation" in v.message


def test_policy_result_violations_list() -> None:
    from dsk.policy.engine import PolicyResult, PolicyViolation

    v = PolicyViolation(resource_uid_ref="res.x", rule="deny", message="missing rotation")
    r = PolicyResult(passed=False, violations=[v])
    assert len(r.violations) == 1
    assert not r.passed


def test_validate_with_policy_flag_no_policy_file(tmp_path) -> None:
    """--policy with missing file or failed OPA should not raise unhandled exceptions."""
    from click.testing import CliRunner

    from dsk.cli.main import main

    runner = CliRunner()
    manifest = tmp_path / "test.yaml"
    manifest.write_text('version: "1"\nschema: pam-environment.v1\nname: test\nresources: []\n')

    result = runner.invoke(
        main, ["validate", str(manifest), "--policy", "/nonexistent/policy.rego"]
    )
    assert result.exit_code in (0, 1, 2, 3)


def test_opa_engine_non_zero_return_gives_error(monkeypatch, tmp_path) -> None:
    """When OPA returns non-zero exit code, result reports error."""
    from unittest.mock import MagicMock

    from dsk.policy.engine import PolicyEngine, validate_policy

    mock_result = MagicMock()
    mock_result.returncode = 1
    mock_result.stderr = "OPA: policy syntax error"
    mock_result.stdout = ""
    monkeypatch.setattr("dsk.policy.engine.subprocess.run", lambda *a, **k: mock_result)

    policy = tmp_path / "deny.rego"
    policy.write_text("package keeper.pam\n")
    result = validate_policy({"resources": []}, str(policy), engine=PolicyEngine.OPA)

    assert not result.passed
    assert "OPA error" in (result.error or "")


def test_opa_engine_zero_return_no_violations(monkeypatch, tmp_path) -> None:
    """When OPA returns 0 with empty result set, policy passes."""
    import json
    from unittest.mock import MagicMock

    from dsk.policy.engine import PolicyEngine, validate_policy

    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stderr = ""
    mock_result.stdout = json.dumps({"result": []})
    monkeypatch.setattr("dsk.policy.engine.subprocess.run", lambda *a, **k: mock_result)

    policy = tmp_path / "deny.rego"
    policy.write_text("package keeper.pam\n")
    result = validate_policy({"resources": []}, str(policy), engine=PolicyEngine.OPA)

    assert result.passed
    assert result.violations == []


def test_opa_engine_violations_parsed(monkeypatch, tmp_path) -> None:
    """When OPA returns violations array, PolicyViolations are populated."""
    import json
    from unittest.mock import MagicMock

    from dsk.policy.engine import PolicyEngine, validate_policy

    opa_output = {
        "result": [{"expressions": [{"value": ["no-mfa on resource X", "stale creds on Y"]}]}]
    }
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stderr = ""
    mock_result.stdout = json.dumps(opa_output)
    monkeypatch.setattr("dsk.policy.engine.subprocess.run", lambda *a, **k: mock_result)

    policy = tmp_path / "deny.rego"
    policy.write_text("package keeper.pam\n")
    result = validate_policy({"resources": []}, str(policy), engine=PolicyEngine.OPA)

    assert not result.passed
    assert len(result.violations) == 2
    messages = [v.message for v in result.violations]
    assert "no-mfa on resource X" in messages


def test_opa_engine_timeout_returns_error(monkeypatch, tmp_path) -> None:
    """OPA timeout is reported as a policy error instead of hanging validation."""
    import subprocess

    from dsk.policy.engine import POLICY_EVAL_TIMEOUT_SECONDS

    def timeout_run(*_args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        assert kwargs["timeout"] == POLICY_EVAL_TIMEOUT_SECONDS
        raise subprocess.TimeoutExpired(cmd=["opa"], timeout=POLICY_EVAL_TIMEOUT_SECONDS)

    monkeypatch.setattr("dsk.policy.engine.subprocess.run", timeout_run)
    policy = tmp_path / "deny.rego"
    policy.write_text("package keeper.pam\n")

    result = validate_policy({"resources": []}, str(policy), engine=PolicyEngine.OPA)

    assert not result.passed
    assert result.error == f"OPA evaluation timed out after {POLICY_EVAL_TIMEOUT_SECONDS}s"
