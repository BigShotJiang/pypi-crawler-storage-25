"""agentic-skill-policy.v1 offline schema, model, and round-trip tests."""

from __future__ import annotations

import json
from typing import Any

import pytest
import yaml

from dsk.core.errors import SchemaError
from dsk.core.manifest import load_declarative_manifest_string
from dsk.core.models_agentic_skill_policy import (
    AGENTIC_SKILL_POLICY_FAMILY,
    AgenticSkillPolicyManifest,
    load_agentic_skill_policy_manifest,
)
from dsk.core.schema import load_schema_for_family, validate_manifest


def _asp_minimal() -> dict[str, Any]:
    return {
        "schema": AGENTIC_SKILL_POLICY_FAMILY,
        "name": "minimal-policy",
        "skills": [
            {
                "uid_ref": "skill.one",
                "name": "One",
                "skill_id": "vendor.one",
                "platform": "cursor",
            }
        ],
    }


def _asp_full() -> dict[str, Any]:
    return {
        "schema": AGENTIC_SKILL_POLICY_FAMILY,
        "name": "full-policy",
        "skills": [
            {
                "uid_ref": "skill.full-a",
                "name": "Skill A",
                "skill_id": "@acme/skill-a",
                "platform": "claude",
                "version_constraint": ">=1.0.0,<2.0.0",
                "sha256_pin": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "approved_by": "sec",
                "approved_at": "2026-05-01",
                "risk_level": "high",
                "allowed_operations": ["read_file"],
                "denied_operations": ["delete_file"],
                "requires_human_approval": True,
                "audit_log_enabled": False,
                "tags": {"tier": "1"},
            },
            {
                "uid_ref": "skill.full-b",
                "name": "Skill B",
                "skill_id": "codex.search",
                "platform": "codex",
                "risk_level": "low",
            },
        ],
        "role_policies": [
            {
                "uid_ref": "role.dev",
                "role_name": "dev",
                "allowed_skill_refs": ["skill.full-a", "skill.full-b"],
                "deny_unlisted": True,
                "max_concurrent_skills": 2,
                "session_timeout_minutes": 45,
            },
            {
                "uid_ref": "role.cicd",
                "role_name": "cicd",
                "allowed_skill_refs": ["skill.full-b"],
                "deny_unlisted": False,
            },
        ],
    }


def test_asp_schema_is_packaged() -> None:
    schema = load_schema_for_family(AGENTIC_SKILL_POLICY_FAMILY)

    assert schema["title"] == AGENTIC_SKILL_POLICY_FAMILY
    assert "skills" in schema["properties"]
    assert "role_policies" in schema["properties"]
    assert schema["x-keeper-live-proof"]["status"] == "upstream-gap"


def test_asp_validate_minimal() -> None:
    assert validate_manifest(_asp_minimal()) == AGENTIC_SKILL_POLICY_FAMILY


def test_asp_validate_full() -> None:
    assert validate_manifest(_asp_full()) == AGENTIC_SKILL_POLICY_FAMILY


def test_asp_missing_required_manifest_name() -> None:
    doc = _asp_minimal()
    del doc["name"]

    with pytest.raises(SchemaError):
        validate_manifest(doc)


def test_asp_missing_required_skill_id() -> None:
    doc = _asp_minimal()
    del doc["skills"][0]["skill_id"]

    with pytest.raises(SchemaError):
        validate_manifest(doc)


def test_asp_invalid_platform() -> None:
    doc = _asp_minimal()
    doc["skills"][0]["platform"] = "emacs"

    with pytest.raises(SchemaError) as exc:
        validate_manifest(doc)

    assert "not one of" in exc.value.reason or "not valid" in exc.value.reason.lower()


def test_asp_role_references_unknown_skill_uid_ref() -> None:
    doc = _asp_full()
    doc["role_policies"][0]["allowed_skill_refs"].append("skill.nonexistent")

    with pytest.raises(SchemaError) as exc:
        load_agentic_skill_policy_manifest(doc)

    assert "unknown" in exc.value.reason.lower() and "skill" in exc.value.reason.lower()


def test_asp_load_returns_typed_model() -> None:
    loaded = load_declarative_manifest_string(
        json.dumps(_asp_full()),
        suffix=".json",
    )

    assert isinstance(loaded, AgenticSkillPolicyManifest)
    assert loaded.skills[0].uid_ref == "skill.full-a"
    assert loaded.skills[0].platform == "claude"
    assert loaded.role_policies[0].role_name == "dev"


def test_asp_manifest_roundtrip_yaml() -> None:
    manifest = load_agentic_skill_policy_manifest(_asp_full())
    dumped = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    yaml_out = yaml.safe_dump(dumped, sort_keys=False, allow_unicode=True)
    reloaded = load_declarative_manifest_string(yaml_out, suffix=".yaml")

    assert isinstance(reloaded, AgenticSkillPolicyManifest)
    assert reloaded.model_dump(mode="json", exclude_none=True, by_alias=True) == dumped


def test_asp_rejects_duplicate_skill_uid_refs() -> None:
    doc = _asp_minimal()
    doc["skills"].append(
        {
            "uid_ref": "skill.one",
            "name": "Dup",
            "skill_id": "vendor.dup",
            "platform": "any",
        }
    )

    with pytest.raises(SchemaError) as exc:
        load_agentic_skill_policy_manifest(doc)

    assert "duplicate uid_ref" in exc.value.reason


def test_asp_rejects_duplicate_uid_refs_across_skills_and_roles() -> None:
    doc = _asp_minimal()
    doc["role_policies"] = [
        {
            "uid_ref": "skill.one",
            "role_name": "dup-role",
            "allowed_skill_refs": [],
        }
    ]

    with pytest.raises(SchemaError) as exc:
        load_agentic_skill_policy_manifest(doc)

    assert "duplicate uid_ref" in exc.value.reason


def test_asp_wrong_family_rejected() -> None:
    doc = {"schema": "ai-agent.v1"}

    with pytest.raises(SchemaError) as exc:
        load_agentic_skill_policy_manifest(doc)

    assert "agentic-skill-policy.v1" in exc.value.reason


def test_compute_agentic_skill_diff_not_implemented_on_live() -> None:
    """compute_agentic_skill_policy_diff raises NotImplementedError with live data."""
    import pytest

    from dsk.core.agentic_skill_policy_diff import compute_agentic_skill_policy_diff
    from dsk.core.models_agentic_skill_policy import load_agentic_skill_policy_manifest

    doc = {
        "schema": "agentic-skill-policy.v1",
        "name": "test-asp",
        "skills": [],
        "role_policies": [],
    }
    manifest = load_agentic_skill_policy_manifest(doc)
    with pytest.raises(NotImplementedError):
        compute_agentic_skill_policy_diff(manifest, live=[{"uid_ref": "x"}])


def test_compute_agentic_skill_diff_emits_skill_and_role_types() -> None:
    """compute_agentic_skill_policy_diff emits agentic_skill and role_policy resource types."""
    from dsk.core.agentic_skill_policy_diff import compute_agentic_skill_policy_diff
    from dsk.core.models_agentic_skill_policy import load_agentic_skill_policy_manifest

    doc = {
        "schema": "agentic-skill-policy.v1",
        "name": "test-asp",
        "skills": [
            {
                "uid_ref": "asp:skills:read-vault",
                "name": "read-vault",
                "skill_id": "builtin:read-vault",
                "platform": "cursor",
            }
        ],
        "role_policies": [
            {
                "uid_ref": "asp:roles:admin",
                "role_name": "admin",
                "allowed_skill_refs": ["asp:skills:read-vault"],
            }
        ],
    }
    manifest = load_agentic_skill_policy_manifest(doc)
    changes = compute_agentic_skill_policy_diff(manifest, live=None)
    types = {c.resource_type for c in changes}
    assert "agentic_skill" in types
    assert "agentic_skill_role_policy" in types
