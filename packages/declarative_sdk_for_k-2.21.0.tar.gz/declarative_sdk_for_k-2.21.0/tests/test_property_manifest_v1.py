"""Property tests for public V1 manifest model round trips."""

from __future__ import annotations

from dataclasses import MISSING, fields, is_dataclass
from typing import Any, TypeAlias, cast

import pytest
import yaml
from hypothesis import given, settings
from hypothesis import strategies as st
from pydantic import BaseModel, ValidationError

from dsk import KsmManifestV1, PolicyManifestV1, SharingManifestV1, VaultManifestV1
from dsk.core.errors import SchemaError
from dsk.core.models_ksm import KSM_FAMILY
from dsk.core.models_policy import (
    AUDIT_POLICY,
    IP_ALLOWLIST_POLICY,
    PASSWORD_POLICY,
    POLICY_FAMILY,
    SESSION_TIMEOUT_POLICY,
    SHARING_POLICY,
    TWO_FA_POLICY,
    AuditPolicy,
    IpAllowlistPolicy,
    PasswordPolicy,
    PolicyRow,
    SessionTimeoutPolicy,
    SharingPolicy,
    TwoFactorPolicy,
    load_policy_manifest,
)
from dsk.core.schema import load_schema_for_family, validate_manifest
from dsk.core.sharing_models import SHARING_FAMILY
from dsk.core.vault_models import VAULT_FAMILY
from dsk.core.vault_models import VaultManifestV1 as CoreVaultManifestV1

MAX_EXAMPLES = 30
MAX_COLLECTION_SIZE = 6
LARGE_RECORD_COUNT = 1_000
ROLE_REF = "keeper-enterprise:roles:security-admins"
SENSITIVE_SCHEMA_BLOCKS = (
    "password_policies",
    "sharing_policies",
    "two_fa_policies",
    "ip_allowlist_policies",
    "session_timeout_policies",
    "audit_policies",
)
POLICY_COLLECTIONS = (
    "password_policies",
    "sharing_policies",
    "two_fa_policies",
    "ip_allowlist_policies",
    "session_timeout_policies",
    "audit_policies",
)
PydanticManifest: TypeAlias = VaultManifestV1 | SharingManifestV1 | KsmManifestV1


def _uid(prefix: str, value: int) -> str:
    return f"{prefix}.{value}"


def _record_ref(value: int) -> str:
    return f"keeper-vault:records:rec.{value}"


def _app_ref(value: int) -> str:
    return f"keeper-ksm:apps:app.{value}"


def _sharing_ref(block: str, value: int) -> str:
    return f"keeper-vault-sharing:{block}:share.{value}"


def _pydantic_manifest_payload(manifest: PydanticManifest) -> dict[str, Any]:
    payload = manifest.model_dump(mode="json", by_alias=True, exclude_none=True)
    assert isinstance(payload, dict)
    return payload


def _policy_payload_for_schema(manifest: PolicyManifestV1) -> dict[str, Any]:
    payload = manifest.to_dict()
    for block in POLICY_COLLECTIONS:
        for row in payload.get(block, []):
            row.pop("policy_type", None)
    return payload


def _yaml_document(payload: dict[str, Any]) -> dict[str, Any]:
    loaded = yaml.safe_load(yaml.safe_dump(payload, sort_keys=True))
    assert isinstance(loaded, dict)
    return loaded


def _schema_required_fields(family: str) -> tuple[str, ...]:
    schema = load_schema_for_family(family)
    return tuple(cast(list[str], schema.get("required", [])))


def _required_dataclass_fields(cls: type[Any]) -> tuple[str, ...]:
    return tuple(
        item.name
        for item in fields(cls)
        if item.default is MISSING and item.default_factory is MISSING
    )


def _non_empty_string(prefix: str) -> st.SearchStrategy[str]:
    return st.integers(min_value=0, max_value=10_000).map(lambda value: f"{prefix}-{value}")


def _vault_record(index: int, *, title: str, login: str) -> dict[str, Any]:
    return {
        "uid_ref": _uid("rec", index),
        "type": "login",
        "title": title,
        "fields": [{"type": "login", "label": "Login", "value": [login]}],
    }


@st.composite
def vault_manifest_strategy(draw: st.DrawFn) -> VaultManifestV1:
    record_ids = draw(
        st.lists(
            st.integers(min_value=0, max_value=2_000),
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    shared_folder_ids = draw(
        st.lists(
            st.integers(min_value=2_001, max_value=3_000),
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    records = [
        _vault_record(
            record_id,
            title=draw(_non_empty_string("record")),
            login=draw(_non_empty_string("login")),
        )
        for record_id in record_ids
    ]
    shared_folders = [
        {
            "uid_ref": _uid("sf", folder_id),
            "title": draw(_non_empty_string("shared-folder")),
            "manager": "dsk",
            "permissions": {
                "manage_records": draw(st.booleans()),
                "manage_users": draw(st.booleans()),
            },
            "members": [],
        }
        for folder_id in shared_folder_ids
    ]
    keeper_fill = draw(
        st.one_of(
            st.none(),
            st.fixed_dictionaries({"owner": _non_empty_string("owner")}),
        )
    )
    return VaultManifestV1.model_validate(
        {
            "schema": VAULT_FAMILY,
            "records": records,
            "shared_folders": shared_folders,
            "record_types": [],
            "attachments": [],
            "keeper_fill": keeper_fill,
        }
    )


@st.composite
def sharing_manifest_strategy(draw: st.DrawFn) -> SharingManifestV1:
    folder_ids = draw(
        st.lists(
            st.integers(min_value=0, max_value=1_000),
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    shared_folder_ids = draw(
        st.lists(
            st.integers(min_value=1_001, max_value=2_000),
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    record_share_ids = draw(
        st.lists(
            st.integers(min_value=2_001, max_value=3_000),
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    folders = [
        {
            "uid_ref": _uid("folder", folder_id),
            "path": f"/Folder/{folder_id}",
            "color": draw(st.one_of(st.none(), st.sampled_from(["red", "green", "blue"]))),
        }
        for folder_id in folder_ids
    ]
    shared_folders = [
        {
            "uid_ref": _uid("share", folder_id),
            "path": f"/Shared/{folder_id}",
            "defaults": {
                "manage_users": draw(st.booleans()),
                "manage_records": draw(st.booleans()),
                "can_edit": draw(st.booleans()),
                "can_share": draw(st.booleans()),
            },
        }
        for folder_id in shared_folder_ids
    ]
    share_records = [
        {
            "uid_ref": _uid("record-share", share_id),
            "record_uid_ref": _record_ref(share_id),
            "user_email": f"user{share_id}@example.com",
            "permissions": {
                "can_edit": draw(st.booleans()),
                "can_share": draw(st.booleans()),
            },
        }
        for share_id in record_share_ids
    ]
    shared_folder_ref = (
        _sharing_ref("shared_folders", shared_folder_ids[0])
        if shared_folder_ids
        else _sharing_ref("shared_folders", 9_999)
    )
    share_folders = draw(
        st.lists(
            st.sampled_from(
                [
                    {
                        "kind": "grantee",
                        "uid_ref": "grantee-share.1",
                        "shared_folder_uid_ref": shared_folder_ref,
                        "grantee": {"kind": "user", "user_email": "ops@example.com"},
                        "permissions": {"manage_records": True, "manage_users": False},
                    },
                    {
                        "kind": "record",
                        "uid_ref": "record-share.1",
                        "shared_folder_uid_ref": shared_folder_ref,
                        "record_uid_ref": _record_ref(4_001),
                        "permissions": {"can_edit": True, "can_share": False},
                    },
                    {
                        "kind": "default",
                        "uid_ref": "default-share.1",
                        "shared_folder_uid_ref": shared_folder_ref,
                        "target": "record",
                        "permissions": {"can_edit": False, "can_share": False},
                    },
                ]
            ),
            max_size=1,
        )
    )
    return SharingManifestV1.model_validate(
        {
            "schema": SHARING_FAMILY,
            "folders": folders,
            "shared_folders": shared_folders,
            "share_records": share_records,
            "share_folders": share_folders,
        }
    )


@st.composite
def ksm_manifest_strategy(draw: st.DrawFn) -> KsmManifestV1:
    app_ids = draw(
        st.lists(
            st.integers(min_value=0, max_value=1_000),
            min_size=1,
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    token_ids = draw(
        st.lists(
            st.integers(min_value=1_001, max_value=2_000),
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    client_ids = draw(
        st.lists(
            st.integers(min_value=2_001, max_value=3_000),
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    apps = [
        {
            "uid_ref": _uid("app", app_id),
            "name": f"App {app_id}",
            "scopes": ["records:read"] if draw(st.booleans()) else [],
            "allowed_ips": ["198.51.100.10/32"] if draw(st.booleans()) else [],
        }
        for app_id in app_ids
    ]
    tokens = [
        {
            "uid_ref": _uid("token", token_id),
            "name": f"Token {token_id}",
            "app_uid_ref": _app_ref(app_ids[token_id % len(app_ids)]),
            "one_time": draw(st.booleans()),
        }
        for token_id in token_ids
    ]
    clients = [
        {
            "uid_ref": _uid("client", client_id),
            "app_uid_ref": _app_ref(app_ids[client_id % len(app_ids)]),
            "name": f"Client {client_id}",
            "count": draw(st.integers(min_value=1, max_value=3)),
            "first_access_expires_in_min": draw(st.integers(min_value=1, max_value=1_440)),
        }
        for client_id in client_ids
    ]
    record_shares = [
        {
            "record_uid_ref": _record_ref(app_id),
            "app_uid_ref": _app_ref(app_id),
            "editable": draw(st.booleans()),
        }
        for app_id in app_ids[:MAX_COLLECTION_SIZE]
    ]
    config_outputs = [
        {
            "app_uid_ref": _app_ref(app_id),
            "format": draw(st.sampled_from(["json", "base64"])),
            "output_path": f"/tmp/keeper-config-{app_id}.json",
        }
        for app_id in app_ids[:MAX_COLLECTION_SIZE]
    ]
    return KsmManifestV1.model_validate(
        {
            "schema": KSM_FAMILY,
            "apps": apps,
            "tokens": tokens,
            "clients": clients,
            "record_shares": record_shares,
            "config_outputs": config_outputs,
        }
    )


def _password_policy(index: int, min_length: int) -> PasswordPolicy:
    return PasswordPolicy(
        uid_ref=_uid("password-policy", index),
        name=f"Password {index}",
        role_uid_ref=ROLE_REF,
        min_length=min_length,
    )


def _sharing_policy(index: int, restrict_all: bool) -> SharingPolicy:
    return SharingPolicy(
        uid_ref=_uid("sharing-policy", index),
        name=f"Sharing {index}",
        role_uid_ref=ROLE_REF,
        restrict_all=restrict_all,
    )


def _two_factor_policy(index: int, duration_web: str) -> TwoFactorPolicy:
    return TwoFactorPolicy(
        uid_ref=_uid("two-fa-policy", index),
        name=f"Two FA {index}",
        role_uid_ref=ROLE_REF,
        require_two_factor=True,
        duration_web=cast(Any, duration_web),
    )


def _ip_allowlist_policy(index: int, cidr: str) -> IpAllowlistPolicy:
    return IpAllowlistPolicy(
        uid_ref=_uid("ip-policy", index),
        name=f"IP {index}",
        role_uid_ref=ROLE_REF,
        login_ip_ranges=[cidr],
    )


def _session_timeout_policy(index: int, minutes: int) -> SessionTimeoutPolicy:
    return SessionTimeoutPolicy(
        uid_ref=_uid("session-policy", index),
        name=f"Session {index}",
        role_uid_ref=ROLE_REF,
        max_session_login_minutes=minutes,
    )


def _audit_policy(index: int, retention_days: int) -> AuditPolicy:
    return AuditPolicy(
        uid_ref=_uid("audit-policy", index),
        name=f"Audit {index}",
        role_uid_ref=ROLE_REF,
        retention_days=retention_days,
    )


@st.composite
def policy_manifest_strategy(draw: st.DrawFn) -> PolicyManifestV1:
    policy_ids = draw(
        st.lists(
            st.integers(min_value=0, max_value=500),
            max_size=MAX_COLLECTION_SIZE,
            unique=True,
        )
    )
    password_policies = tuple(
        _password_policy(policy_id, draw(st.integers(min_value=8, max_value=64)))
        for policy_id in policy_ids
    )
    sharing_policies = tuple(
        _sharing_policy(policy_id, draw(st.booleans())) for policy_id in policy_ids[:2]
    )
    two_fa_policies = tuple(
        _two_factor_policy(
            policy_id,
            draw(st.sampled_from(["login", "12_hours", "24_hours", "30_days", "forever"])),
        )
        for policy_id in policy_ids[:2]
    )
    ip_allowlist_policies = tuple(
        _ip_allowlist_policy(policy_id, f"10.0.{policy_id % 255}.0/24")
        for policy_id in policy_ids[:2]
    )
    session_timeout_policies = tuple(
        _session_timeout_policy(policy_id, draw(st.integers(min_value=1, max_value=1_440)))
        for policy_id in policy_ids[:2]
    )
    audit_policies = tuple(
        _audit_policy(policy_id, draw(st.integers(min_value=1, max_value=3_650)))
        for policy_id in policy_ids[:2]
    )
    return PolicyManifestV1(
        name=draw(_non_empty_string("policy-suite")),
        manager=draw(_non_empty_string("manager")),
        password_policies=password_policies,
        sharing_policies=sharing_policies,
        two_fa_policies=two_fa_policies,
        ip_allowlist_policies=ip_allowlist_policies,
        session_timeout_policies=session_timeout_policies,
        audit_policies=audit_policies,
    )


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=vault_manifest_strategy())
def test_vault_manifest_v1_yaml_roundtrip(manifest: VaultManifestV1) -> None:
    """YAML serialization preserves every vault manifest field."""
    rehydrated = VaultManifestV1.model_validate(
        _yaml_document(_pydantic_manifest_payload(manifest))
    )

    assert rehydrated == manifest


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=vault_manifest_strategy())
def test_vault_manifest_v1_dict_roundtrip(manifest: VaultManifestV1) -> None:
    """Dict serialization preserves every vault manifest field."""
    rehydrated = VaultManifestV1.model_validate(_pydantic_manifest_payload(manifest))

    assert rehydrated == manifest


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=sharing_manifest_strategy())
def test_sharing_manifest_v1_yaml_roundtrip(manifest: SharingManifestV1) -> None:
    """YAML serialization preserves every sharing manifest field."""
    rehydrated = SharingManifestV1.model_validate(
        _yaml_document(_pydantic_manifest_payload(manifest))
    )

    assert rehydrated == manifest


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=sharing_manifest_strategy())
def test_sharing_manifest_v1_dict_roundtrip(manifest: SharingManifestV1) -> None:
    """Dict serialization preserves every sharing manifest field."""
    rehydrated = SharingManifestV1.model_validate(_pydantic_manifest_payload(manifest))

    assert rehydrated == manifest


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=ksm_manifest_strategy())
def test_ksm_manifest_v1_yaml_roundtrip(manifest: KsmManifestV1) -> None:
    """YAML serialization preserves every KSM manifest field."""
    rehydrated = KsmManifestV1.model_validate(_yaml_document(_pydantic_manifest_payload(manifest)))

    assert rehydrated == manifest


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=ksm_manifest_strategy())
def test_ksm_manifest_v1_dict_roundtrip(manifest: KsmManifestV1) -> None:
    """Dict serialization preserves every KSM manifest field."""
    rehydrated = KsmManifestV1.model_validate(_pydantic_manifest_payload(manifest))

    assert rehydrated == manifest


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=policy_manifest_strategy())
def test_policy_manifest_v1_yaml_roundtrip(manifest: PolicyManifestV1) -> None:
    """YAML serialization preserves every policy manifest field."""
    rehydrated = load_policy_manifest(_yaml_document(_policy_payload_for_schema(manifest)))

    assert rehydrated == manifest


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=policy_manifest_strategy())
def test_policy_manifest_v1_dict_roundtrip(manifest: PolicyManifestV1) -> None:
    """Dict serialization preserves every policy manifest field."""
    rehydrated = load_policy_manifest(_policy_payload_for_schema(manifest))

    assert rehydrated == manifest


@pytest.mark.parametrize(
    "document, expected_error",
    [
        ({"schema": "wrong"}, ValidationError),
        (
            {"schema": VAULT_FAMILY, "records": [{"uid_ref": "r1", "type": "login"}]},
            ValidationError,
        ),
        (
            {
                "schema": VAULT_FAMILY,
                "records": [
                    {
                        "uid_ref": "r1",
                        "type": "login",
                        "title": "Bad Field",
                        "fields": [{"type": "notAField", "value": ["x"]}],
                    }
                ],
            },
            ValidationError,
        ),
        (
            {
                "schema": VAULT_FAMILY,
                "shared_folders": [
                    {
                        "uid_ref": "sf1",
                        "title": "Shared",
                        "manager": "dsk",
                        "permissions": {"manage_records": True},
                    }
                ],
            },
            ValidationError,
        ),
        (
            {
                "schema": VAULT_FAMILY,
                "records": [{"uid_ref": "r1", "type": "pamMachine", "title": "PAM"}],
            },
            SchemaError,
        ),
        (
            {
                "schema": VAULT_FAMILY,
                "records": [
                    {
                        "uid_ref": "r1",
                        "type": "serverCredentials",
                        "title": "Server",
                        "fields": [{"type": "fileRef", "value": []}],
                    }
                ],
            },
            ValidationError,
        ),
    ],
)
def test_vault_manifest_v1_validation_rejects_invalid(
    document: dict[str, Any],
    expected_error: type[Exception],
) -> None:
    """Vault model validation rejects malformed manifests."""
    with pytest.raises(expected_error):
        VaultManifestV1.model_validate(document)


@pytest.mark.parametrize(
    "document",
    [
        {"schema": "wrong"},
        {"schema": SHARING_FAMILY, "folders": [{"uid_ref": "folder.prod"}]},
        {"schema": SHARING_FAMILY, "unexpected": True},
        {
            "schema": SHARING_FAMILY,
            "folders": [{"uid_ref": "folder.prod", "path": "/Prod", "color": "purple"}],
        },
        {
            "schema": SHARING_FAMILY,
            "share_records": [
                {
                    "uid_ref": "share.bad",
                    "record_uid_ref": "records:rec.prod",
                    "user_email": "ops@example.com",
                    "permissions": {"can_edit": False, "can_share": False},
                }
            ],
        },
        {
            "schema": SHARING_FAMILY,
            "share_folders": [
                {
                    "kind": "grantee",
                    "uid_ref": "share.bad",
                    "shared_folder_uid_ref": _sharing_ref("shared_folders", 1),
                    "grantee": {
                        "kind": "user",
                        "user_email": "ops@example.com",
                        "team_uid_ref": "keeper-enterprise:teams:ops",
                    },
                    "permissions": {"manage_records": False, "manage_users": False},
                }
            ],
        },
    ],
)
def test_sharing_manifest_v1_validation_rejects_invalid(document: dict[str, Any]) -> None:
    """Sharing model validation rejects malformed manifests."""
    with pytest.raises(ValidationError):
        SharingManifestV1.model_validate(document)


@pytest.mark.parametrize(
    "document",
    [
        {"schema": "wrong"},
        {"schema": KSM_FAMILY, "apps": [{"uid_ref": "app.api"}]},
        {"schema": KSM_FAMILY, "apps": [{"uid_ref": "_bad", "name": "API"}]},
        {
            "schema": KSM_FAMILY,
            "clients": [
                {
                    "uid_ref": "client.api",
                    "app_uid_ref": "keeper-ksm:apps:app.api",
                    "count": 0,
                }
            ],
        },
        {
            "schema": KSM_FAMILY,
            "apps": [{"uid_ref": "dup", "name": "API"}],
            "tokens": [{"uid_ref": "dup", "name": "token", "app_uid_ref": "keeper-ksm:apps:dup"}],
        },
        {
            "schema": KSM_FAMILY,
            "config_outputs": [
                {
                    "app_uid_ref": "keeper-ksm:apps:app.api",
                    "format": "toml",
                    "output_path": "/tmp/config.toml",
                }
            ],
        },
    ],
)
def test_ksm_manifest_v1_validation_rejects_invalid(document: dict[str, Any]) -> None:
    """KSM model validation rejects malformed manifests."""
    with pytest.raises(ValidationError):
        KsmManifestV1.model_validate(document)


@pytest.mark.parametrize(
    "document",
    [
        {"schema": POLICY_FAMILY},
        {"schema": "wrong", "name": "policy-suite"},
        {"schema": POLICY_FAMILY, "name": "policy-suite", "unexpected": True},
        {
            "schema": POLICY_FAMILY,
            "name": "policy-suite",
            "password_policies": [{"uid_ref": "policy.password", "name": "Password"}],
        },
        {
            "schema": POLICY_FAMILY,
            "name": "policy-suite",
            "password_policies": [
                {
                    "uid_ref": "policy.password",
                    "name": "Password",
                    "role_uid_ref": ROLE_REF,
                    "min_length": 7,
                }
            ],
        },
        {
            "schema": POLICY_FAMILY,
            "name": "policy-suite",
            "two_fa_policies": [
                {
                    "uid_ref": "policy.two-fa",
                    "name": "Two FA",
                    "role_uid_ref": ROLE_REF,
                    "duration_web": "tomorrow",
                }
            ],
        },
    ],
)
def test_policy_manifest_v1_validation_rejects_invalid(document: dict[str, Any]) -> None:
    """Policy schema validation rejects malformed manifests."""
    with pytest.raises(SchemaError):
        load_policy_manifest(document)


@pytest.mark.skip(
    reason="VaultManifestV1, SharingManifestV1, KsmManifestV1, and PolicyManifestV1 "
    "do not expose merge, overlay, or apply_overlay methods.",
)
def test_manifest_v1_apply_overlay_idempotent_not_applicable() -> None:
    """Merge idempotence is not part of the current V1 manifest API."""


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=vault_manifest_strategy())
def test_vault_manifest_v1_schema_family_always_v1(manifest: VaultManifestV1) -> None:
    """Vault manifests always declare the keeper-vault v1 family."""
    assert manifest.vault_schema == VAULT_FAMILY
    assert manifest.vault_schema.endswith(".v1")


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=vault_manifest_strategy())
def test_vault_manifest_v1_required_fields_present(manifest: VaultManifestV1) -> None:
    """Vault manifests retain every schema-required top-level field."""
    payload = _pydantic_manifest_payload(manifest)

    for required in _schema_required_fields(VAULT_FAMILY):
        assert payload[required] is not None


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=sharing_manifest_strategy())
def test_sharing_manifest_v1_schema_family_always_v1(manifest: SharingManifestV1) -> None:
    """Sharing manifests always declare the keeper-vault-sharing v1 family."""
    assert manifest.vault_schema == SHARING_FAMILY
    assert manifest.vault_schema.endswith(".v1")


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=sharing_manifest_strategy())
def test_sharing_manifest_v1_required_fields_present(manifest: SharingManifestV1) -> None:
    """Sharing manifests retain every schema-required top-level field."""
    payload = _pydantic_manifest_payload(manifest)

    for required in _schema_required_fields(SHARING_FAMILY):
        assert payload[required] is not None


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=ksm_manifest_strategy())
def test_ksm_manifest_v1_schema_family_always_v1(manifest: KsmManifestV1) -> None:
    """KSM manifests always declare the keeper-ksm v1 family."""
    assert manifest.ksm_schema == KSM_FAMILY
    assert manifest.ksm_schema.endswith(".v1")


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=ksm_manifest_strategy())
def test_ksm_manifest_v1_required_fields_present(manifest: KsmManifestV1) -> None:
    """KSM manifests retain every schema-required top-level field."""
    payload = _pydantic_manifest_payload(manifest)

    for required in _schema_required_fields(KSM_FAMILY):
        assert payload[required] is not None


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=policy_manifest_strategy())
def test_policy_manifest_v1_schema_family_always_v1(manifest: PolicyManifestV1) -> None:
    """Policy manifests always declare the keeper-policy v1 family."""
    assert manifest.schema == POLICY_FAMILY
    assert manifest.schema.endswith(".v1")


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=policy_manifest_strategy())
def test_policy_manifest_v1_required_fields_present(manifest: PolicyManifestV1) -> None:
    """Policy manifests retain every schema-required top-level field."""
    payload = _policy_payload_for_schema(manifest)

    for required in _schema_required_fields(POLICY_FAMILY):
        assert payload[required] is not None


@settings(max_examples=MAX_EXAMPLES)
@given(manifest=policy_manifest_strategy())
def test_policy_manifest_v1_policy_rows_required_fields_present(
    manifest: PolicyManifestV1,
) -> None:
    """Policy rows retain every dataclass-required field."""
    for _resource_type, policy in manifest.iter_policies():
        for required in _required_dataclass_fields(type(policy)):
            assert getattr(policy, required) is not None


def test_manifest_v1_required_field_introspection_covers_all_model_styles() -> None:
    """Required-field checks cover Pydantic and dataclass manifests."""
    assert issubclass(CoreVaultManifestV1, BaseModel)
    assert issubclass(SharingManifestV1, BaseModel)
    assert issubclass(KsmManifestV1, BaseModel)
    assert is_dataclass(PolicyManifestV1)
    assert _required_dataclass_fields(PolicyManifestV1) == ("name",)


def test_vault_manifest_v1_empty_records() -> None:
    """An empty vault records list remains valid."""
    manifest = VaultManifestV1(
        records=[],
        shared_folders=[],
        record_types=[],
        attachments=[],
        keeper_fill=None,
    )

    assert manifest.records == []
    assert manifest.iter_uid_refs() == []


def test_vault_manifest_v1_huge_records_roundtrip() -> None:
    """A large vault records list survives parse and serialization."""
    records = [
        _vault_record(index, title=f"Record {index}", login=f"user{index}")
        for index in range(LARGE_RECORD_COUNT)
    ]
    manifest = VaultManifestV1.model_validate({"schema": VAULT_FAMILY, "records": records})
    payload = _pydantic_manifest_payload(manifest)

    rehydrated = VaultManifestV1.model_validate(_yaml_document(payload))

    assert len(rehydrated.records) == LARGE_RECORD_COUNT
    assert rehydrated == manifest


def test_sharing_manifest_v1_empty_collections() -> None:
    """Empty sharing manifest collections remain valid."""
    manifest = SharingManifestV1()

    assert manifest.folders == []
    assert manifest.shared_folders == []
    assert validate_manifest(_pydantic_manifest_payload(manifest)) == SHARING_FAMILY


def test_ksm_manifest_v1_empty_collections() -> None:
    """Empty KSM manifest collections remain valid."""
    manifest = KsmManifestV1()

    assert manifest.apps == []
    assert manifest.tokens == []
    assert validate_manifest(_pydantic_manifest_payload(manifest)) == KSM_FAMILY


def test_policy_manifest_v1_empty_policy_collections() -> None:
    """Empty policy collections remain valid when the manifest has a name."""
    manifest = PolicyManifestV1(name="empty-policy-suite")

    assert list(manifest.iter_policies()) == []
    assert validate_manifest(_policy_payload_for_schema(manifest)) == POLICY_FAMILY
    assert all(getattr(manifest, block) == () for block in SENSITIVE_SCHEMA_BLOCKS)


def test_policy_manifest_v1_to_dict_policy_type_is_loader_normalized() -> None:
    """Policy runtime serialization is normalized before schema validation."""
    policy = _password_policy(1, 16)
    manifest = PolicyManifestV1(name="policy-suite", password_policies=(policy,))
    raw_payload = manifest.to_dict()
    schema_payload = _policy_payload_for_schema(manifest)
    row = cast(list[dict[str, Any]], raw_payload["password_policies"])[0]

    assert row["policy_type"] == "password-policy"
    assert "policy_type" not in schema_payload["password_policies"][0]
    assert load_policy_manifest(schema_payload) == manifest


def test_policy_manifest_v1_strategy_covers_every_policy_type() -> None:
    """Policy strategy emits all policy row classes when input IDs exist."""
    manifest = PolicyManifestV1(
        name="coverage",
        password_policies=(_password_policy(1, 16),),
        sharing_policies=(_sharing_policy(1, True),),
        two_fa_policies=(_two_factor_policy(1, "24_hours"),),
        ip_allowlist_policies=(_ip_allowlist_policy(1, "10.0.1.0/24"),),
        session_timeout_policies=(_session_timeout_policy(1, 60),),
        audit_policies=(_audit_policy(1, 365),),
    )

    rows: dict[str, PolicyRow] = dict(manifest.iter_policies())

    assert set(rows) == {
        PASSWORD_POLICY,
        SHARING_POLICY,
        TWO_FA_POLICY,
        IP_ALLOWLIST_POLICY,
        SESSION_TIMEOUT_POLICY,
        AUDIT_POLICY,
    }
