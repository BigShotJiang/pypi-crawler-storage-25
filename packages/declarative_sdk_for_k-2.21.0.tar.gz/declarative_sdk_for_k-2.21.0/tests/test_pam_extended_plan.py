"""Offline plan-row coverage for ``keeper-pam-extended.v1``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from click.testing import CliRunner

from dsk.cli import main
from dsk.core.diff import Change, ChangeKind
from dsk.core.models_pam_extended import (
    PAM_EXTENDED_FAMILY,
    PamExtendedManifestV1,
    load_pam_extended_manifest,
)
from dsk.core.pam_extended_diff import compute_pam_extended_diff
from dsk.core.planner import Plan, build_plan


def _pam_extended_doc() -> dict[str, Any]:
    return {
        "schema": PAM_EXTENDED_FAMILY,
        "gateway_configs": [
            {
                "gateway_uid_ref": "gw.edge",
                "network_segment": "corp-edge",
                "allowed_ports": [22, 3389],
                "health_check_interval_s": 30,
            }
        ],
        "rotation_schedules": [
            {
                "name": "DB hourly",
                "uid_ref": "rot.db_hourly",
                "cron_expr": "0 * * * *",
                "resource_uid_refs": ["res.db_prod"],
                "notify_emails": ["ops@example.com"],
            }
        ],
        "discovery_rules": [
            {
                "name": "SSH scan",
                "uid_ref": "disc.ssh",
                "scan_network": True,
                "target_cidr": "10.20.0.0/16",
                "protocol": "ssh",
                "credential_uid_ref": "cred.discovery",
            }
        ],
        "service_mappings": [
            {
                "name": "nginx",
                "uid_ref": "svc.nginx",
                "service_type": "unix_daemon",
                "host_uid_ref": "host.web01",
                "credential_uid_ref": "cred.nginx",
            }
        ],
    }


def _manifest(document: dict[str, Any] | None = None) -> PamExtendedManifestV1:
    return load_pam_extended_manifest(document or _pam_extended_doc())


def _offline_plan(manifest: PamExtendedManifestV1, extra: list[Change] | None = None) -> Plan:
    changes = compute_pam_extended_diff(
        manifest,
        {},
        manifest_name=PAM_EXTENDED_FAMILY,
    )
    order = [uid_ref for uid_ref, _kind in manifest.iter_object_refs()]
    return build_plan(PAM_EXTENDED_FAMILY, [*(extra or []), *changes], order)


def _write_json(tmp_path: Path, document: dict[str, Any]) -> Path:
    path = tmp_path / "pam-extended.json"
    path.write_text(json.dumps(document), encoding="utf-8")
    return path


def test_pam_extended_valid_manifest_builds_expected_plan_rows() -> None:
    plan = _offline_plan(_manifest())

    assert [change.uid_ref for change in plan.ordered()] == [
        "gw.edge",
        "rot.db_hourly",
        "disc.ssh",
        "svc.nginx",
    ]
    assert {(change.uid_ref, change.resource_type, change.kind) for change in plan.creates} == {
        ("gw.edge", "pam_extended_gateway_config", ChangeKind.CREATE),
        ("rot.db_hourly", "pam_extended_rotation_schedule", ChangeKind.CREATE),
        ("disc.ssh", "pam_extended_discovery_rule", ChangeKind.CREATE),
        ("svc.nginx", "pam_extended_service_mapping", ChangeKind.CREATE),
    }
    rotation = next(change for change in plan.creates if change.uid_ref == "rot.db_hourly")
    assert rotation.after["cron_expr"] == "0 * * * *"


def test_pam_extended_unsupported_apply_field_is_conflict_row() -> None:
    conflict = Change(
        kind=ChangeKind.CONFLICT,
        uid_ref=None,
        resource_type="capability",
        title="unsupported-by-provider",
        reason=(
            "service_mappings is preview-gated for apply "
            "(Commander write/readback proof is not available)"
        ),
        manifest_name=PAM_EXTENDED_FAMILY,
    )

    plan = _offline_plan(_manifest(), extra=[conflict])

    assert len(plan.conflicts) == 1
    assert plan.conflicts[0].resource_type == "capability"
    assert plan.conflicts[0].title == "unsupported-by-provider"
    assert "service_mappings" in (plan.conflicts[0].reason or "")
    assert "preview-gated" in (plan.conflicts[0].reason or "")


def test_pam_extended_round_trip_validate_cli_exits_zero(tmp_path: Path) -> None:
    dumped = _manifest().model_dump(mode="json", exclude_none=True, by_alias=True)
    path = _write_json(tmp_path, dumped)

    result = CliRunner().invoke(main, ["validate", str(path), "--json"], catch_exceptions=False)

    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert payload["family"] == PAM_EXTENDED_FAMILY
    assert payload["mode"] == "schema_only"


def test_pam_extended_noop_after_apply() -> None:
    manifest = _manifest()
    live = manifest.model_dump(mode="python", exclude_none=True, by_alias=True)
    changes = compute_pam_extended_diff(
        manifest,
        live,
        manifest_name=PAM_EXTENDED_FAMILY,
    )
    assert changes
    assert all(change.kind is ChangeKind.NOOP for change in changes)


def test_pam_extended_empty_resources_produces_no_creates() -> None:
    document = {"schema": PAM_EXTENDED_FAMILY, "resources": []}
    manifest = load_pam_extended_manifest(document)
    changes = compute_pam_extended_diff(
        manifest,
        {},
        manifest_name=PAM_EXTENDED_FAMILY,
    )
    creates = [change for change in changes if change.kind is ChangeKind.CREATE]
    assert creates == []


def test_pam_extended_plan_json_output_has_summary(tmp_path: Path) -> None:
    dumped = _manifest().model_dump(mode="json", exclude_none=True, by_alias=True)
    path = _write_json(tmp_path, dumped)

    result = CliRunner().invoke(main, ["plan", str(path), "--json"], catch_exceptions=False)

    payload = json.loads(result.output)
    assert "summary" in payload
