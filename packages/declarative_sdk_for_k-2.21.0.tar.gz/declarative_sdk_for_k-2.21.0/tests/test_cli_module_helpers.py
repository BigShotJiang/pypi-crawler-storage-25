"""Direct tests for small CLI helper extractions."""

from __future__ import annotations

import json
import subprocess
from collections import Counter
from io import StringIO
from pathlib import Path
from typing import Any

import pytest
import yaml
from click.testing import CliRunner
from rich.console import Console


def test_scan_nhi_drift_helpers_format_json_and_text() -> None:
    from dsk.cli.cmd_scan import _nhi_drift_payload, _nhi_drift_text_lines
    from dsk.core.models_ai_agent import AI_AGENT_FAMILY
    from dsk.core.models_nhi import NHI_FAMILY

    rows = [{"family": NHI_FAMILY, "uid_ref": "nhi.one", "name": "robot"}]

    assert _nhi_drift_payload(rows, 1, 2) == {
        "declared_nhi_resources": 1,
        "manifest_counts": {NHI_FAMILY: 1, AI_AGENT_FAMILY: 2},
        "resources": rows,
    }
    assert _nhi_drift_text_lines(1, 1, 2) == [
        "Declared NHI resources: 1",
        f"Families scanned: {NHI_FAMILY} (1 manifests), {AI_AGENT_FAMILY} (2 manifests)",
        "",
        "To detect unmanaged vault NHIs, run with --live (requires Commander session).",
    ]


def test_discover_helpers_collect_unmanaged_and_serialize(monkeypatch) -> None:
    import dsk.cli.cmd_discover as mod

    def fake_run_pam_list(resource_type: str) -> list[dict[str, Any]]:
        assert resource_type in {"machine", "database"}
        if resource_type == "machine":
            return [
                {"uid": "MANAGED_UID", "title": "Managed"},
                {"uid": "NEW_UID_123456", "title": "New machine"},
            ]
        return [{"record_uid": "DB_UID_123456", "name": "New database"}]

    monkeypatch.setattr(mod, "_run_pam_list", fake_run_pam_list)

    resource_types = mod._resource_type_list("machine,database")
    all_discovered, unmanaged_stubs = mod._discover_unmanaged_stubs(
        resource_types,
        {"MANAGED_UID"},
    )
    manifest = mod._discovery_output_manifest(unmanaged_stubs)
    serialized_json = mod._serialize_discovery_output(manifest, emit_json=True)
    serialized_yaml = mod._serialize_discovery_output(manifest, emit_json=False)

    assert all_discovered == [
        {"uid": "MANAGED_UID", "type": "machine", "title": "Managed"},
        {"uid": "NEW_UID_123456", "type": "machine", "title": "New machine"},
        {"uid": "DB_UID_123456", "type": "database", "title": ""},
    ]
    assert [stub["resource_type"] for stub in unmanaged_stubs] == ["machine", "database"]
    assert json.loads(serialized_json)["resources"][0]["keeper_uid"] == "NEW_UID_123456"
    assert yaml.safe_load(serialized_yaml)["name"] == "discovered-unmanaged"


def test_discover_run_pam_list_handles_commander_edges(monkeypatch: pytest.MonkeyPatch) -> None:
    import dsk.cli.cmd_discover as mod

    class Result:
        def __init__(self, returncode: int, stdout: str) -> None:
            self.returncode = returncode
            self.stdout = stdout

    def ok_run(args: list[str], **kwargs: Any) -> Result:
        assert args == ["keeper", "pam", "machine", "list", "--json"]
        assert kwargs["capture_output"] is True
        assert kwargs["text"] is True
        assert kwargs["timeout"] == 30
        return Result(0, '[{"uid": "MACHINE_UID", "title": "machine"}]')

    monkeypatch.setattr(mod.subprocess, "run", ok_run)
    assert mod._run_pam_list("machine") == [{"uid": "MACHINE_UID", "title": "machine"}]

    monkeypatch.setattr(mod.subprocess, "run", lambda *_args, **_kwargs: Result(2, "[]"))
    assert mod._run_pam_list("machine") == []

    monkeypatch.setattr(mod.subprocess, "run", lambda *_args, **_kwargs: Result(0, "{"))
    assert mod._run_pam_list("machine") == []

    def timeout_run(*_args: Any, **_kwargs: Any) -> Result:
        raise subprocess.TimeoutExpired(cmd="keeper", timeout=30)

    monkeypatch.setattr(mod.subprocess, "run", timeout_run)
    assert mod._run_pam_list("machine") == []

    def missing_run(*_args: Any, **_kwargs: Any) -> Result:
        raise FileNotFoundError("keeper")

    monkeypatch.setattr(mod.subprocess, "run", missing_run)
    assert mod._run_pam_list("machine") == []

    monkeypatch.setenv("DSK_DISCOVER_COMMANDER_STDOUT_MAX_BYTES", "2")
    monkeypatch.setattr(mod.subprocess, "run", lambda *_args, **_kwargs: Result(0, "[{}]"))
    assert mod._run_pam_list("machine") == []


def test_discover_extract_managed_uids_reads_all_manifest_sections(tmp_path: Path) -> None:
    from dsk.cli.cmd_discover import _extract_managed_uids

    manifest = tmp_path / "manifest.yaml"
    manifest.write_text(
        yaml.safe_dump(
            {
                "gateways": [{"keeper_uid": "GATEWAY_UID"}],
                "pam_configurations": [{"keeper_uid": "CONFIG_UID"}],
                "resources": [{"keeper_uid": "RESOURCE_UID"}],
                "machines": [{"keeper_uid": "MACHINE_UID"}],
                "databases": [{"keeper_uid": "DATABASE_UID"}],
                "directories": [{"keeper_uid": "DIRECTORY_UID"}],
                "remote_browsers": [{"keeper_uid": "RBI_UID"}],
            }
        ),
        encoding="utf-8",
    )

    assert _extract_managed_uids(str(manifest)) == {
        "GATEWAY_UID",
        "CONFIG_UID",
        "RESOURCE_UID",
        "MACHINE_UID",
        "DATABASE_UID",
        "DIRECTORY_UID",
        "RBI_UID",
    }

    broken = tmp_path / "broken.yaml"
    broken.write_text("[", encoding="utf-8")
    assert _extract_managed_uids(str(broken)) == set()

    oversized = tmp_path / "oversized.yaml"
    oversized.write_text("resources: []\n", encoding="utf-8")
    monkeypatch = pytest.MonkeyPatch()
    try:
        monkeypatch.setenv("DSK_DISCOVER_MANAGED_MANIFEST_MAX_BYTES", "2")
        assert _extract_managed_uids(str(oversized)) == set()
    finally:
        monkeypatch.undo()


def test_scan_iter_yaml_files_returns_sorted_yaml_and_yml(tmp_path: Path) -> None:
    from dsk.cli.cmd_scan import _iter_yaml_files

    (tmp_path / "b.yml").write_text("schema: keeper-vault.v1\n", encoding="utf-8")
    (tmp_path / "a.yaml").write_text("schema: keeper-vault.v1\n", encoding="utf-8")
    (tmp_path / "nested").mkdir()
    (tmp_path / "nested" / "c.yaml").write_text("schema: keeper-vault.v1\n", encoding="utf-8")
    (tmp_path / "ignored.txt").write_text("schema: keeper-vault.v1\n", encoding="utf-8")

    assert [path.relative_to(tmp_path).as_posix() for path in _iter_yaml_files(tmp_path)] == [
        "a.yaml",
        "b.yml",
        "nested/c.yaml",
    ]


def test_scan_collect_declared_resources_skips_bad_manifests(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    import dsk.cli.cmd_scan as mod

    class FakeResource:
        def __init__(self, uid_ref: str, name: str) -> None:
            self.uid_ref = uid_ref
            self.name = name

    class FakeNhiManifest:
        resources = [FakeResource("nhi.one", "robot")]

    class FakeAiManifest:
        resources = [FakeResource("ai.one", "assistant")]

    paths = [tmp_path / "nhi.yaml", tmp_path / "bad.yaml", tmp_path / "ai.yml"]
    monkeypatch.setattr(mod, "_iter_yaml_files", lambda _root: paths)
    monkeypatch.setattr(mod, "NhiAgentManifest", FakeNhiManifest)
    monkeypatch.setattr(mod, "AiAgentManifest", FakeAiManifest)

    def fake_load(path: Path) -> object:
        if path.name == "bad.yaml":
            raise ValueError("bad manifest")
        if path.name == "nhi.yaml":
            return FakeNhiManifest()
        return FakeAiManifest()

    monkeypatch.setattr(mod, "load_declarative_manifest", fake_load)

    rows, nhi_count, ai_count = mod._collect_declared_from_manifests(tmp_path)

    assert nhi_count == 1
    assert ai_count == 1
    assert rows == [
        {
            "family": mod.NHI_FAMILY,
            "manifest": str(tmp_path / "nhi.yaml"),
            "uid_ref": "nhi.one",
            "name": "robot",
        },
        {
            "family": mod.AI_AGENT_FAMILY,
            "manifest": str(tmp_path / "ai.yml"),
            "uid_ref": "ai.one",
            "name": "assistant",
        },
    ]


def test_scan_nhi_drift_live_gate_and_output_formats(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    import dsk.cli.cmd_scan as mod

    rows = [
        {"family": mod.NHI_FAMILY, "manifest": "nhi.yaml", "uid_ref": "nhi.one", "name": "robot"}
    ]
    monkeypatch.setattr(mod, "_collect_declared_from_manifests", lambda _root: (rows, 1, 0))
    runner = CliRunner()

    live = runner.invoke(mod.nhi_drift_cmd, ["--manifests", str(tmp_path), "--live"])
    assert live.exit_code == mod.EXIT_CAPABILITY
    assert "Live NHI drift scan requires" in live.output

    emitted_json = runner.invoke(
        mod.nhi_drift_cmd,
        ["--manifests", str(tmp_path), "--format", "json"],
    )
    assert emitted_json.exit_code == 0
    assert json.loads(emitted_json.output)["resources"] == rows

    emitted_text = runner.invoke(mod.nhi_drift_cmd, ["--manifests", str(tmp_path)])
    assert emitted_text.exit_code == 0
    assert "Declared NHI resources: 1" in emitted_text.output


def test_audit_render_result_success_and_failure() -> None:
    from dsk.cli.audit_chain import AuditExplainResult, AuditLine
    from dsk.cli.cmd_audit import EXIT_CAPABILITY, EXIT_OK, _render_audit_explain_result

    ok_entry = AuditLine(
        line_no=1,
        ok=True,
        operation="write",
        prev_hash="",
        expected_prev_hash="",
        signature="sig",
        expected_signature="sig",
        line_hash="line",
        timestamp="2026-05-10T00:00:00Z",
    )
    fail_entry = AuditLine(
        line_no=2,
        ok=False,
        operation="delete",
        prev_hash="old",
        expected_prev_hash="new",
        signature="bad",
        expected_signature="good",
        line_hash="line2",
        timestamp="2026-05-10T00:01:00Z",
        error="signature mismatch",
    )

    ok_buffer = StringIO()
    ok_console = Console(file=ok_buffer, force_terminal=False, color_system=None, width=120)
    ok_result = AuditExplainResult(
        path=Path("audit.log"),
        entries=(ok_entry,),
        failures=(),
        operation_counts=Counter({"write": 1}),
    )

    assert _render_audit_explain_result(ok_console, ok_result, summary=True) == EXIT_OK
    assert "audit chain verified" in ok_buffer.getvalue()

    fail_buffer = StringIO()
    fail_console = Console(file=fail_buffer, force_terminal=False, color_system=None, width=120)
    fail_result = AuditExplainResult(
        path=Path("audit.log"),
        entries=(ok_entry, fail_entry),
        failures=(fail_entry,),
        operation_counts=Counter({"write": 1, "delete": 1}),
    )

    assert _render_audit_explain_result(fail_console, fail_result, summary=False) == EXIT_CAPABILITY
    output = fail_buffer.getvalue()
    assert "signature mismatch" in output
    assert "audit chain corrupt" in output
