"""Governance ownership-transfer tests."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.governance import (
    GOVERNANCE_TRANSFER_RESOURCE,
    governance_transfer_from_change,
)
from dsk.core.planner import Plan
from dsk.providers.commander_cli import CommanderCliProvider
from dsk.providers.mock import MockProvider


def _change(**after: Any) -> Change:
    return Change(
        kind=ChangeKind.UPDATE,
        uid_ref="transfer.1",
        resource_type=GOVERNANCE_TRANSFER_RESOURCE,
        title="transfer.1",
        after=after,
    )


def _plan(change: Change) -> Plan:
    return Plan("governance-test", [change], [change.uid_ref or ""])


def test_governance_transfer_accepts_plain_record_fields() -> None:
    transfer = governance_transfer_from_change(
        _change(record_uid="REC123", target_user="owner@example.com")
    )

    assert transfer.object_type == "record"
    assert transfer.object_uid == "REC123"
    assert transfer.target_user == "owner@example.com"


def test_mock_governance_record_transfer_records_audit_row() -> None:
    provider = MockProvider()
    change = _change(record_uid="REC123", target_user="owner@example.com")

    outcomes = provider.apply_governance_transfer_plan(_plan(change))

    assert [outcome.action for outcome in outcomes] == ["update"]
    assert outcomes[0].keeper_uid == "REC123"
    assert provider.governance_transfers()["transfer.1"]["target_user"] == "owner@example.com"


def test_mock_governance_dry_run_does_not_mutate() -> None:
    provider = MockProvider()
    change = _change(record_uid="REC123", target_user="owner@example.com")

    outcomes = provider.apply_governance_transfer_plan(_plan(change), dry_run=True)

    assert outcomes[0].details["dry_run"] is True
    assert provider.governance_transfers() == {}


def test_commander_governance_record_transfer_uses_share_record_owner(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    params = object()
    calls: list[tuple[object, dict[str, Any]]] = []
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda operation: operation())

    class FakeShareRecordCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    register_module = types.ModuleType("keepercommander.commands.register")
    register_module.ShareRecordCommand = FakeShareRecordCommand
    monkeypatch.setitem(sys.modules, "keepercommander.commands.register", register_module)

    outcomes = provider.apply_governance_transfer_plan(
        _plan(_change(record_uid="REC123", target_user="owner@example.com"))
    )

    assert [outcome.action for outcome in outcomes] == ["update"]
    assert calls == [
        (
            params,
            {
                "record": "REC123",
                "email": ["owner@example.com"],
                "action": "owner",
                "force": True,
                "recursive": False,
            },
        )
    ]


def test_commander_governance_folder_transfer_is_upstream_gap() -> None:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    change = _change(
        object_type="shared_folder",
        shared_folder_uid="SF123",
        target_user="owner@example.com",
    )

    with pytest.raises(CapabilityError) as exc_info:
        provider.apply_governance_transfer_plan(_plan(change))

    assert "no `share-folder transfer-ownership`" in exc_info.value.reason
