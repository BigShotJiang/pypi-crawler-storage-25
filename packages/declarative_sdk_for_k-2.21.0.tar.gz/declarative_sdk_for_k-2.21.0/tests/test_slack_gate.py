"""Tests for Slack approval gate manifest models and integration logic."""

from __future__ import annotations

import sys
from pathlib import Path
from types import ModuleType
from unittest.mock import MagicMock

import pytest
import yaml


def test_slack_gate_defaults():
    from dsk.core.models_slack_gate import SlackApprovalGateManifestV1

    m = SlackApprovalGateManifestV1(**{"schema": "slack-approval-gate.v1", "name": "test"})
    assert m.schema_ == "slack-approval-gate.v1"
    assert m.gates == []
    assert m.default_gate is None


def test_slack_gate_round_trip():
    from dsk.core.models_slack_gate import (
        SlackApprovalGateManifestV1,
        SlackApprovalMode,
        SlackEscalationAction,
    )

    example = Path(__file__).parent.parent / "examples/slack_gate/acme-slack-approval.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = SlackApprovalGateManifestV1(**data)
    assert manifest.schema_ == "slack-approval-gate.v1"
    assert len(manifest.gates) == 3
    prod = manifest.gates[0]
    assert prod.name == "prod-default"
    assert prod.mode == SlackApprovalMode.any_approver
    assert prod.on_timeout == SlackEscalationAction.block
    assert prod.require_reason is True
    auto = manifest.gates[2]
    assert auto.on_timeout == SlackEscalationAction.auto_approve


def test_slack_gate_approver_fields():
    from dsk.core.models_slack_gate import SlackApprover

    a = SlackApprover(slack_user_id="U123", keeper_uid_ref="user.alice")
    assert a.slack_user_id == "U123"
    assert a.keeper_uid_ref == "user.alice"
    assert a.slack_group_id is None


def test_slack_gate_schema_alias():
    from dsk.core.models_slack_gate import SlackApprovalGateManifestV1

    m = SlackApprovalGateManifestV1(**{"schema": "slack-approval-gate.v1", "name": "t"})
    assert m.schema_ == "slack-approval-gate.v1"


# --- Integration tests for dsk/integrations/slack_gate.py ---


def _mock_requests_module(post_response: dict, get_response: dict) -> ModuleType:
    """Return a fake ``requests`` module with mocked post/get."""
    mock_req = MagicMock()
    post_resp = MagicMock()
    post_resp.json.return_value = post_response
    mock_req.post.return_value = post_resp

    get_resp = MagicMock()
    get_resp.json.return_value = get_response
    mock_req.get.return_value = get_resp
    return mock_req


def test_check_slack_gate_raises_without_token(monkeypatch: pytest.MonkeyPatch) -> None:
    """check_slack_gate must raise SlackGateError when SLACK_BOT_TOKEN is unset."""
    from dsk.integrations.slack_gate import SlackGateError, check_slack_gate

    monkeypatch.delenv("SLACK_BOT_TOKEN", raising=False)
    with pytest.raises(SlackGateError, match="SLACK_BOT_TOKEN"):
        check_slack_gate("gate", "manifest", "#deploys")


def test_post_approval_request_raises_without_requests(monkeypatch: pytest.MonkeyPatch) -> None:
    """_post_approval_request must raise SlackGateError when requests is not installed."""
    import dsk.integrations.slack_gate as sg_mod

    original = sys.modules.get("requests")
    sys.modules["requests"] = None  # type: ignore[assignment]
    try:
        with pytest.raises(sg_mod.SlackGateError, match="requests not installed"):
            sg_mod._post_approval_request("#ch", "mfst", "gate", "tok")
    finally:
        if original is None:
            sys.modules.pop("requests", None)
        else:
            sys.modules["requests"] = original


def test_post_approval_request_raises_on_slack_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """_post_approval_request must raise SlackGateError when Slack returns ok=False."""
    import dsk.integrations.slack_gate as sg_mod

    mock_req = _mock_requests_module(
        post_response={"ok": False, "error": "channel_not_found"},
        get_response={},
    )
    monkeypatch.setitem(sys.modules, "requests", mock_req)
    with pytest.raises(sg_mod.SlackGateError, match="channel_not_found"):
        sg_mod._post_approval_request("#ch", "mfst", "gate", "tok")


def _past_deadline_time() -> float:
    """Return a callable whose 1st call sets deadline=0+60=60, 2nd+ calls return 9e9 (past)."""
    _calls: list[int] = [0]

    def _t() -> float:
        _calls[0] += 1
        return 0.0 if _calls[0] == 1 else 9_000_000.0

    return _t  # type: ignore[return-value]


def test_poll_reactions_auto_approve_on_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    """_poll_reactions with on_timeout='auto_approve' must return True after deadline."""
    import dsk.integrations.slack_gate as sg_mod

    mock_req = _mock_requests_module(
        post_response={},
        get_response={"ok": True, "message": {"reactions": []}},
    )
    monkeypatch.setitem(sys.modules, "requests", mock_req)
    monkeypatch.setattr(sg_mod.time, "time", _past_deadline_time())
    monkeypatch.setattr(sg_mod.time, "sleep", lambda _: None)
    result = sg_mod._poll_reactions(
        "#ch", "ts-123", "tok", timeout_minutes=1, on_timeout="auto_approve"
    )
    assert result is True


def test_poll_reactions_auto_reject_on_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    """_poll_reactions with on_timeout='auto_reject' must return False after deadline."""
    import dsk.integrations.slack_gate as sg_mod

    mock_req = _mock_requests_module(
        post_response={},
        get_response={"ok": True, "message": {"reactions": []}},
    )
    monkeypatch.setitem(sys.modules, "requests", mock_req)
    monkeypatch.setattr(sg_mod.time, "time", _past_deadline_time())
    monkeypatch.setattr(sg_mod.time, "sleep", lambda _: None)
    result = sg_mod._poll_reactions(
        "#ch", "ts-123", "tok", timeout_minutes=1, on_timeout="auto_reject"
    )
    assert result is False


def test_poll_reactions_block_on_timeout_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    """_poll_reactions with on_timeout='block' must raise SlackGateError after deadline."""
    import dsk.integrations.slack_gate as sg_mod

    mock_req = _mock_requests_module(
        post_response={},
        get_response={"ok": True, "message": {"reactions": []}},
    )
    monkeypatch.setitem(sys.modules, "requests", mock_req)
    monkeypatch.setattr(sg_mod.time, "time", _past_deadline_time())
    monkeypatch.setattr(sg_mod.time, "sleep", lambda _: None)
    with pytest.raises(sg_mod.SlackGateError, match="timed out"):
        sg_mod._poll_reactions("#ch", "ts-123", "tok", timeout_minutes=1, on_timeout="block")


def test_post_approval_request_returns_ts_on_success(monkeypatch: pytest.MonkeyPatch) -> None:
    """_post_approval_request returns message ts when Slack API succeeds."""
    import dsk.integrations.slack_gate as sg_mod

    mock_req = _mock_requests_module(
        post_response={"ok": True, "ts": "1234567890.000100"},
        get_response={"ok": True, "message": {"reactions": []}},
    )
    monkeypatch.setitem(sys.modules, "requests", mock_req)

    ts = sg_mod._post_approval_request(
        channel="#ch",
        manifest_name="test-manifest",
        gate_name="deploy-gate",
        bot_token="xoxb-fake",
        message_template=None,
    )
    assert ts == "1234567890.000100"


def test_poll_reactions_returns_true_on_checkmark(monkeypatch: pytest.MonkeyPatch) -> None:
    """_poll_reactions returns True when white_check_mark reaction is detected."""
    import dsk.integrations.slack_gate as sg_mod

    mock_req = _mock_requests_module(
        post_response={"ok": True, "ts": "111"},
        get_response={
            "ok": True,
            "message": {"reactions": [{"name": "white_check_mark", "count": 1}]},
        },
    )
    monkeypatch.setitem(sys.modules, "requests", mock_req)
    # Keep time well within deadline
    monkeypatch.setattr(sg_mod.time, "time", lambda: 0.0)
    monkeypatch.setattr(sg_mod.time, "sleep", lambda _: None)

    result = sg_mod._poll_reactions(
        "#ch", "111", "tok", timeout_minutes=5, on_timeout="auto_reject"
    )
    assert result is True


def test_poll_reactions_returns_false_on_x_reaction(monkeypatch: pytest.MonkeyPatch) -> None:
    """_poll_reactions returns False when :x: reaction is detected."""
    import dsk.integrations.slack_gate as sg_mod

    mock_req = _mock_requests_module(
        post_response={"ok": True, "ts": "111"},
        get_response={
            "ok": True,
            "message": {"reactions": [{"name": "x", "count": 1}]},
        },
    )
    monkeypatch.setitem(sys.modules, "requests", mock_req)
    monkeypatch.setattr(sg_mod.time, "time", lambda: 0.0)
    monkeypatch.setattr(sg_mod.time, "sleep", lambda _: None)

    result = sg_mod._poll_reactions(
        "#ch", "111", "tok", timeout_minutes=5, on_timeout="auto_approve"
    )
    assert result is False
