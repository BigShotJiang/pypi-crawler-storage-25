"""Public in-process helpers exposed by dsk.cli.main."""

from __future__ import annotations

import inspect

from dsk.cli.main import build_plan, dispatch_main


def test_dispatch_main_signature_is_stable() -> None:
    assert list(inspect.signature(dispatch_main).parameters) == [
        "ctx",
        "provider",
        "folder_uid",
    ]


def test_build_plan_signature_is_stable() -> None:
    signature = inspect.signature(build_plan)

    assert list(signature.parameters) == ["ctx", "manifest_path", "allow_delete"]
    assert signature.parameters["allow_delete"].kind is inspect.Parameter.KEYWORD_ONLY
