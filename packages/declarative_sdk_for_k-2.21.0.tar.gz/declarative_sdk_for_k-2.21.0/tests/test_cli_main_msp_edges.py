"""Focused edge coverage for MSP helper paths in ``dsk.cli.main``."""

from __future__ import annotations

import importlib

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.planner import Plan
from dsk.providers import MockProvider

cli_main = importlib.import_module("dsk.cli.main")


def _change(
    kind: ChangeKind,
    *,
    uid_ref: str = "mc.acme",
    resource_type: str = "managed_company",
    title: str = "Acme",
    keeper_uid: str | None = "mc-1",
    before: dict | None = None,
    after: dict | None = None,
    reason: str | None = None,
) -> Change:
    return Change(
        kind=kind,
        uid_ref=uid_ref,
        resource_type=resource_type,
        title=title,
        keeper_uid=keeper_uid,
        before=before or {},
        after=after or {},
        reason=reason,
    )


def test_enterprise_live_object_count_only_counts_known_blocks() -> None:
    live = {"nodes": [{}, {}], "teams": [{}], "aliases": [], "ignored": [{}, {}, {}]}

    assert cli_main._enterprise_live_object_count(live) == 3


def test_msp_change_name_prefers_after_then_before_then_uid_ref() -> None:
    assert cli_main._msp_change_name(_change(ChangeKind.UPDATE, after={"name": "After"})) == "After"
    assert (
        cli_main._msp_change_name(_change(ChangeKind.UPDATE, before={"name": "Before"})) == "Before"
    )
    assert (
        cli_main._msp_change_name(_change(ChangeKind.UPDATE, uid_ref="mc.fallback"))
        == "mc.fallback"
    )


def test_msp_plan_changes_preserves_ordered_then_unordered_rows() -> None:
    create = _change(ChangeKind.CREATE, uid_ref="mc.create")
    conflict = _change(ChangeKind.CONFLICT, uid_ref="mc.conflict")
    noop = _change(ChangeKind.NOOP, uid_ref="mc.noop")
    plan = Plan("msp", [noop, conflict, create], ["mc.create"])

    assert [row.uid_ref for row in cli_main._msp_plan_changes(plan)] == [
        "mc.create",
        "mc.noop",
        "mc.conflict",
    ]


def test_mock_adopt_managed_companies_rejects_non_msp_rows() -> None:
    provider = MockProvider("msp")
    bad = _change(ChangeKind.UPDATE, uid_ref="vault.login.x", resource_type="login")

    with pytest.raises(ValueError, match="MSP-only"):
        provider.adopt_managed_companies(Plan("msp", [bad], []))  # type: ignore[attr-defined]


def test_mock_adopt_managed_companies_updates_existing_company() -> None:
    provider = MockProvider("msp")
    provider.seed_managed_companies([{"name": "Acme", "plan": "starter", "seats": 3}])
    change = _change(
        ChangeKind.UPDATE,
        before={"name": "Acme", "plan": "starter"},
        after={"name": "Acme", "plan": "enterprise", "seats": 10},
    )

    outcomes = provider.adopt_managed_companies(Plan("msp", [change], ["mc.acme"]))  # type: ignore[attr-defined]

    assert outcomes[0].action == "update"
    assert outcomes[0].details["marker_written"] is True
    assert provider.discover_managed_companies()[0]["plan"] == "enterprise"
    assert provider.discover_managed_companies()[0]["manager"] == "msp"


def test_mock_adopt_managed_companies_reports_missing_update() -> None:
    provider = MockProvider("msp")
    change = _change(
        ChangeKind.UPDATE,
        before={"name": "Missing"},
        after={"name": "Missing", "plan": "enterprise"},
    )

    outcomes = provider.adopt_managed_companies(Plan("msp", [change], ["mc.acme"]))  # type: ignore[attr-defined]

    assert outcomes[0].action == "update"
    assert outcomes[0].details["skipped"] == "record_missing"


def test_mock_adopt_managed_companies_preserves_conflict_reason() -> None:
    provider = MockProvider("msp")
    change = _change(ChangeKind.CONFLICT, reason="owned by another manifest")

    outcomes = provider.adopt_managed_companies(Plan("msp", [change], []))  # type: ignore[attr-defined]

    assert outcomes[0].action == "conflict"
    assert outcomes[0].details["reason"] == "owned by another manifest"
