"""Tests for the rehearse-report CLI command and helpers (D9 R1 stub)."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

from click.testing import CliRunner

from dsk.cli.cmd_rehearse_report import (
    _build_drift_report,
    _build_junit_xml,
    rehearse_report_cmd,
)


def test_rehearse_report_exits_nonzero_without_implementation(tmp_path: Path) -> None:
    """Stub must exit 1 — no implementation exists yet."""
    runner = CliRunner()
    result = runner.invoke(rehearse_report_cmd, [str(tmp_path)])
    assert result.exit_code == 1


def test_rehearse_report_stderr_explains_stub(tmp_path: Path) -> None:
    """Stub output must mention it is not yet implemented so CI consumers can identify it."""
    runner = CliRunner()
    result = runner.invoke(rehearse_report_cmd, [str(tmp_path)])
    # Rich writes to sys.stderr; CliRunner captures both streams in result.output by default
    combined = result.output.lower()
    assert "not yet implemented" in combined or "d9 r1 stub" in combined


def test_rehearse_report_requires_existing_run_dir(tmp_path: Path) -> None:
    """Click must reject a non-existent run_dir with a usage error (exit 2)."""
    runner = CliRunner()
    nonexistent = str(tmp_path / "does_not_exist")
    result = runner.invoke(rehearse_report_cmd, [nonexistent])
    assert result.exit_code == 2


def test_build_drift_report_happy_path_counts_import_outcomes(tmp_path: Path) -> None:
    """_build_drift_report converts import/plan facts into the stable report schema."""
    report = _build_drift_report(
        run_dir=tmp_path,
        import_outcomes=[
            {"status": "adopted"},
            {"status": "adopted"},
            {"status": "suspect"},
            {"status": "error"},
        ],
        plan_summary={"creates": 1, "updates": 2, "deletes": 3},
        contract_version="1.1",
        warnings=["custom type"],
        errors=[],
    )

    assert report["run_dir"] == str(tmp_path.resolve())
    assert report["contract_version"] == "1.1"
    assert report["import_exit_code"] == 0
    assert report["records_total"] == 4
    assert report["records_adopted"] == 2
    assert report["records_suspect"] == 1
    assert report["records_error"] == 1
    assert report["plan_summary"] == {"creates": 1, "updates": 2, "deletes": 3}
    assert report["warnings"] == ["custom type"]


def test_build_drift_report_errors_set_nonzero_import_exit(tmp_path: Path) -> None:
    report = _build_drift_report(
        run_dir=tmp_path,
        import_outcomes=[],
        plan_summary={},
        contract_version="1.0",
        warnings=[],
        errors=["import failed"],
    )

    assert report["import_exit_code"] == 1
    assert report["plan_summary"] == {"creates": 0, "updates": 0, "deletes": 0}
    assert report["errors"] == ["import failed"]


# ---------------------------------------------------------------------------
# D9 R2 — _build_junit_xml tests
# ---------------------------------------------------------------------------

_CLEAN_REPORT: dict = {
    "run_dir": "/tmp/rehearsal",
    "dsk_version": "0.1.0",
    "contract_version": "1.0",
    "import_exit_code": 0,
    "records_total": 10,
    "records_adopted": 10,
    "records_suspect": 0,
    "records_error": 0,
    "plan_summary": {"creates": 0, "updates": 0, "deletes": 0},
    "warnings": [],
    "errors": [],
}


def test_build_junit_xml_all_pass() -> None:
    """Clean report produces a testsuite with failures=0 and no <failure> children."""
    xml_str = _build_junit_xml(_CLEAN_REPORT)
    root = ET.fromstring(xml_str)
    assert root.get("failures") == "0"
    assert root.get("tests") == "7"
    for tc in root.findall("testcase"):
        assert tc.find("failure") is None, f"unexpected failure in {tc.get('name')}"


def test_build_junit_xml_import_failure() -> None:
    """import_exit_code=3 (EXIT_AUDIT) marks audit_chain_verify as failed."""
    report = {**_CLEAN_REPORT, "import_exit_code": 3}
    xml_str = _build_junit_xml(report)
    root = ET.fromstring(xml_str)
    audit_tc = next(tc for tc in root.findall("testcase") if tc.get("name") == "audit_chain_verify")
    assert audit_tc.find("failure") is not None


def test_build_junit_xml_suspect_markers() -> None:
    """records_suspect > 0 marks suspect_markers testcase as failed."""
    report = {**_CLEAN_REPORT, "records_suspect": 2}
    xml_str = _build_junit_xml(report)
    root = ET.fromstring(xml_str)
    suspect_tc = next(tc for tc in root.findall("testcase") if tc.get("name") == "suspect_markers")
    assert suspect_tc.find("failure") is not None


def test_build_junit_xml_custom_type_warnings() -> None:
    """Non-empty warnings list marks custom_type_warnings testcase as failed."""
    report = {**_CLEAN_REPORT, "warnings": ["unknown type foo"]}
    xml_str = _build_junit_xml(report)
    root = ET.fromstring(xml_str)
    warn_tc = next(
        tc for tc in root.findall("testcase") if tc.get("name") == "custom_type_warnings"
    )
    assert warn_tc.find("failure") is not None


def test_build_junit_xml_returns_valid_xml_string() -> None:
    """Output must be parseable by ET.fromstring without raising."""
    xml_str = _build_junit_xml(_CLEAN_REPORT)
    assert isinstance(xml_str, str)
    ET.fromstring(xml_str)  # raises on invalid XML


def test_rehearse_report_junit_format_emits_xml(tmp_path: Path) -> None:
    """--format junit must exit 1 AND emit a <testsuite> element on stdout."""
    runner = CliRunner()
    result = runner.invoke(rehearse_report_cmd, [str(tmp_path), "--format", "junit"])
    assert result.exit_code == 1
    assert "<testsuite" in result.output


def test_rehearse_report_rejects_bad_format_choice(tmp_path: Path) -> None:
    result = CliRunner().invoke(rehearse_report_cmd, [str(tmp_path), "--format", "json"])

    assert result.exit_code == 2
    assert "invalid value" in result.output.lower()
