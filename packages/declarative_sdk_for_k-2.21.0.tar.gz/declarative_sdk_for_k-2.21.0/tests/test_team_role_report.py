"""Offline coverage for ``dsk report team-report`` (enterprise-info + compliance)."""

from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from dsk.cli import main


def _run(args: list[str]):
    runner = CliRunner()
    return runner.invoke(main, args, catch_exceptions=False)


def _install_enterprise_info(
    monkeypatch: pytest.MonkeyPatch,
    responses: list[list[dict[str, object]]],
    calls: list[list[str]] | None = None,
    *,
    more_stdout: tuple[str, ...] = (),
) -> None:
    queue = [json.dumps(response) for response in responses]
    queue.extend(more_stdout)

    def fake_run_keeper_batch(argv: list[str], **_kwargs: object) -> str:
        if calls is not None:
            calls.append(argv)
        if not queue:
            raise AssertionError("no fake keeper response queued")
        return queue.pop(0)

    monkeypatch.setattr(
        "dsk.cli._report.runner.run_keeper_batch",
        fake_run_keeper_batch,
    )


def test_team_report_uses_enterprise_info_and_compliance_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    team_uid = "ZzYyXxWwVvUuTtSsRrQqPp"
    calls: list[list[str]] = []
    _install_enterprise_info(
        monkeypatch,
        [
            [
                {
                    "team_uid": team_uid,
                    "name": "Platform",
                    "node": "Root",
                    "user_count": 1,
                    "users": ["alice@example.com"],
                    "role_count": 1,
                    "roles": ["Admin"],
                }
            ]
        ],
        calls,
        more_stdout=(json.dumps([]),),
    )

    result = _run(["report", "team-report", "--quiet"])

    assert result.exit_code == 0, result.output
    assert team_uid not in result.output
    payload = json.loads(result.stdout)
    assert payload["command"] == "team-report"
    assert payload["meta"]["sources"] == ["enterprise-info-teams", "compliance-team-report"]
    assert payload["rows"][0]["team_uid"].startswith("<uid:")
    assert payload["rows"][0]["roles"] == ["Admin"]
    assert payload["rows"][0]["shared_folders"] == []
    assert len(calls) == 2
    assert calls[0][0] == "enterprise-info"
    assert calls[1][:4] == ["compliance", "team-report", "--format", "json"]


def test_team_report_empty_enterprise_info_returns_empty_rows(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_enterprise_info(monkeypatch, [[]])

    result = _run(["report", "team-report"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["command"] == "team-report"
    assert payload["rows"] == []


def test_team_report_envelope_includes_sources_and_column_meta(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_enterprise_info(
        monkeypatch,
        [
            [
                {
                    "team_uid": "ZzYyXxWwVvUuTtSsRrQqPp",
                    "name": "Solo",
                    "node": "Root",
                    "user_count": 0,
                    "users": [],
                    "role_count": 0,
                    "roles": [],
                }
            ]
        ],
        more_stdout=(json.dumps([]),),
    )

    result = _run(["report", "team-report", "--quiet"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["meta"]["sources"] == ["enterprise-info-teams", "compliance-team-report"]
    assert payload["meta"]["team_list_columns"][0] == "restricts"
