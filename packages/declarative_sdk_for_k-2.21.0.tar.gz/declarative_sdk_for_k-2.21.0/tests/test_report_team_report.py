"""Offline tests for ``dsk report team-report`` (enterprise teams + compliance team-report)."""

from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_GENERIC


def _run(args: list[str]):
    runner = CliRunner()
    return runner.invoke(main, args, catch_exceptions=False)


def _install_team_report_batch(
    monkeypatch: pytest.MonkeyPatch,
    responses: list[list[dict[str, object]]],
    calls: list[list[str]] | None = None,
) -> None:
    queue = [json.dumps(response) for response in responses]

    def fake_run_keeper_batch(argv: list[str], **_kwargs: object) -> str:
        if calls is not None:
            calls.append(argv)
        if not queue:
            raise AssertionError("no fake keeper response queued")
        return queue.pop(0)

    monkeypatch.setattr(
        "dsk.cli._report.runner.run_keeper_batch",
        fake_run_keeper_batch,
    )


def test_team_report_empty_enterprise_skips_compliance_call(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    _install_team_report_batch(monkeypatch, [[]], calls)

    result = _run(["report", "team-report", "--json"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["command"] == "team-report"
    assert payload["rows"] == []
    assert len(calls) == 1
    assert calls[0][:4] == ["enterprise-info", "-t", "-v", "--format"]


def test_team_report_three_teams_merges_shared_folders(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    teams = [
        {
            "team_uid": "TEAM111111111111111",
            "name": "Alpha",
            "node": "Root",
            "restricts": "",
            "user_count": 2,
            "users": ["alice@example.com", "bob@example.com"],
            "queued_user_count": 0,
            "queued_users": [],
            "role_count": 1,
            "roles": ["Admin"],
        },
        {
            "team_uid": "TEAM222222222222222",
            "name": "Beta",
            "node": "Root",
            "restricts": "",
            "user_count": 1,
            "users": ["carol@example.com"],
            "queued_user_count": 0,
            "queued_users": [],
            "role_count": 2,
            "roles": ["Dev", "Viewer"],
        },
        {
            "team_uid": "TEAM333333333333333",
            "name": "Gamma",
            "node": "Root",
            "restricts": "",
            "user_count": 0,
            "users": [],
            "queued_user_count": 0,
            "queued_users": [],
            "role_count": 0,
            "roles": [],
        },
    ]
    sf_rows = [
        {
            "team_name": "Alpha",
            "team_uid": "TEAM111111111111111",
            "shared_folder_name": "SF1",
            "shared_folder_uid": "SFUID11111111111111",
            "permissions": "Read Only",
            "records": 3,
        },
        {
            "team_name": "Beta",
            "team_uid": "TEAM222222222222222",
            "shared_folder_name": "SF2",
            "shared_folder_uid": "SFUID22222222222222",
            "permissions": "Can Edit",
            "records": 1,
        },
    ]
    _install_team_report_batch(monkeypatch, [teams, sf_rows], calls)

    result = _run(["report", "team-report"])

    assert result.exit_code == 0, result.output
    assert len(calls) == 2
    assert calls[1][:2] == ["compliance", "team-report"]
    payload = json.loads(result.stdout)
    by_name = {row["name"]: row for row in payload["rows"]}
    assert by_name["Alpha"]["user_count"] == 2
    assert by_name["Alpha"]["roles"] == ["Admin"]
    assert len(by_name["Alpha"]["shared_folders"]) == 1
    assert by_name["Alpha"]["shared_folder_count"] == 1
    assert by_name["Beta"]["user_count"] == 1
    assert by_name["Beta"]["roles"] == ["Dev", "Viewer"]
    assert by_name["Gamma"]["shared_folder_count"] == 0


def test_team_report_team_filter_limits_rows_and_passes_compliance_team(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    teams = [
        {
            "team_uid": "TEAM111111111111111",
            "name": "Alpha",
            "node": "Root",
            "restricts": "",
            "user_count": 1,
            "users": ["alice@example.com"],
            "queued_user_count": 0,
            "queued_users": [],
            "role_count": 0,
            "roles": [],
        },
        {
            "team_uid": "TEAM222222222222222",
            "name": "Beta",
            "node": "Root",
            "restricts": "",
            "user_count": 0,
            "users": [],
            "queued_user_count": 0,
            "queued_users": [],
            "role_count": 0,
            "roles": [],
        },
    ]
    _install_team_report_batch(monkeypatch, [teams, []], calls)
    target = "TEAM222222222222222"

    result = _run(["report", "team-report", "--team", target])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert len(payload["rows"]) == 1
    assert payload["rows"][0]["name"] == "Beta"
    assert payload["meta"]["team_filter"] == [target]
    assert calls[1][calls[1].index("--team") + 1] == target


def test_team_report_quiet_fingerprints_team_uid(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    uid = "ZzYyXxWwVvUuTtSsRrQqPp"
    _install_team_report_batch(
        monkeypatch,
        [
            [
                {
                    "team_uid": uid,
                    "name": "Solo",
                    "node": "Root",
                    "restricts": "",
                    "user_count": 0,
                    "users": [],
                    "queued_user_count": 0,
                    "queued_users": [],
                    "role_count": 0,
                    "roles": [],
                }
            ],
            [],
        ],
    )

    result = _run(["report", "team-report", "--quiet"])

    assert result.exit_code == 0, result.output
    assert uid not in result.output
    payload = json.loads(result.stdout)
    assert payload["rows"][0]["team_uid"].startswith("<uid:")


def test_team_report_cli_exits_generic_on_leak_check(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    uid = "AaBbCcDdEeFfGgHhIiJjKk"
    _install_team_report_batch(
        monkeypatch,
        [
            [
                {
                    "team_uid": uid,
                    "name": "Leak",
                    "node": "Root",
                    "restricts": "",
                    "user_count": 0,
                    "users": [],
                    "queued_user_count": 0,
                    "queued_users": [],
                    "role_count": 0,
                    "roles": [],
                }
            ],
            [],
        ],
    )

    def fake_secret_leak_check(text: str, **_kwargs: object) -> list[str]:
        if uid in text:
            return ["report leaks raw Keeper UID"]
        return []

    monkeypatch.setattr(
        "dsk.cli._report.common.secret_leak_check",
        fake_secret_leak_check,
    )

    result = _run(["report", "team-report"])

    assert result.exit_code == EXIT_GENERIC, result.output
    assert "output failed leak check" in result.output


def test_team_report_node_passed_to_both_commands(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    one_team = [
        {
            "team_uid": "TEAM111111111111111",
            "name": "Only",
            "node": "Root",
            "restricts": "",
            "user_count": 0,
            "users": [],
            "queued_user_count": 0,
            "queued_users": [],
            "role_count": 0,
            "roles": [],
        }
    ]
    _install_team_report_batch(monkeypatch, [one_team, []], calls)
    node = "N1234567890"

    result = _run(["report", "team-report", "--node", node])

    assert result.exit_code == 0, result.output
    assert len(calls) == 2
    assert "--node" in calls[0]
    assert calls[0][calls[0].index("--node") + 1] == node
    assert "--node" in calls[1]
    assert calls[1][calls[1].index("--node") + 1] == node
