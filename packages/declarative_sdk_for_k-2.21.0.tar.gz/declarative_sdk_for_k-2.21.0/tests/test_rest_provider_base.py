"""Tests for dsk.providers.rest_provider_base utilities."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.planner import Plan
from dsk.providers import rest_provider_base
from dsk.providers.rest_provider_base import (
    KeeperRestProvider,
    _json_safe,
    configuration_from_plan,
    outcomes_from_plan,
    plan_has_mutations,
)

# ── KeeperRestProvider (offline) ───────────────────────────────────────────────


def test_get_keeper_params_injected_without_login_attempt() -> None:
    sentinel = object()
    provider = KeeperRestProvider(keeper_params=sentinel)
    with patch.object(rest_provider_base, "EnvLoginHelper") as env_cls:
        assert provider._get_keeper_params() is sentinel
        env_cls.assert_not_called()


def test_get_keeper_params_login_failed_then_guard_on_second_call(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("KEEPER_SDK_LOGIN_HELPER", raising=False)
    mock_helper = MagicMock()
    mock_helper.load_keeper_creds.side_effect = RuntimeError("offline-login-failure")
    with patch.object(rest_provider_base, "EnvLoginHelper", return_value=mock_helper):
        provider = KeeperRestProvider()
        with pytest.raises(CapabilityError) as first_exc:
            provider._get_keeper_params()
        assert first_exc.value.reason is not None
        assert "previously failed" not in first_exc.value.reason

        with pytest.raises(CapabilityError) as second_exc:
            provider._get_keeper_params()

    assert (second_exc.value.reason or "").startswith(
        "in-process Commander login previously failed"
    )


def test_get_keeper_params_ksm_helper(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("KEEPER_SDK_LOGIN_HELPER", "ksm")
    fake_params = object()
    mock_helper = MagicMock()
    mock_helper.load_keeper_creds.return_value = {
        "email": "a@example.invalid",
        "password": "s3cret",
        "totp_secret": "totp",
    }
    mock_helper.keeper_login.return_value = fake_params
    with patch.object(rest_provider_base, "KsmLoginHelper", return_value=mock_helper):
        provider = KeeperRestProvider()
        assert provider._get_keeper_params() is fake_params
    mock_helper.load_keeper_creds.assert_called_once_with()
    mock_helper.keeper_login.assert_called_once_with(
        "a@example.invalid",
        "s3cret",
        "totp",
    )


def test_rest_post_without_commander_raises_capability_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import builtins as _builtins

    real_import = _builtins.__import__

    def guarded_import(name, globals_=None, locals_=None, fromlist=(), level=0):
        if level == 0 and name.partition(".")[0] == "keepercommander":
            raise ImportError("offline test: keepercommander missing")
        return real_import(name, globals_, locals_, fromlist, level)

    monkeypatch.setattr(_builtins, "__import__", guarded_import)
    provider = KeeperRestProvider(keeper_params=object())
    with pytest.raises(CapabilityError) as ei:
        provider._rest_post("/x", {})

    reason = ei.value.reason or ""
    assert "keepercommander" in reason.lower() or "keepercommander" in reason


def test_unsupported_capabilities_and_tenant_bindings_are_empty_default() -> None:
    provider = KeeperRestProvider()
    manifest = object()
    assert provider.unsupported_capabilities(manifest) == []
    assert provider.check_tenant_bindings(manifest) == []


def test_discover_returns_empty_default() -> None:
    provider = KeeperRestProvider()
    assert provider.discover() == []


# ── plan_has_mutations ────────────────────────────────────────────────────────


def test_plan_has_mutations_empty_plan_returns_false() -> None:
    plan = Plan(manifest_name="t", changes=[])
    assert plan_has_mutations(plan) is False


def test_plan_has_mutations_create_returns_true() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                resource_type="t",
                uid_ref="x",
                title="X",
                keeper_uid=None,
                reason=None,
                before=None,
                after={},
            ),
        ],
    )
    assert plan_has_mutations(plan) is True


def test_plan_has_mutations_update_returns_true() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.UPDATE,
                resource_type="t",
                uid_ref="x",
                title="X",
                keeper_uid="uid",
                reason=None,
                before={},
                after={"field": "new"},
            ),
        ],
    )
    assert plan_has_mutations(plan) is True


def test_plan_has_mutations_noop_only_returns_false() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.NOOP,
                resource_type="t",
                uid_ref="x",
                title="X",
                keeper_uid="uid",
                reason=None,
                before={},
                after={},
            ),
        ],
    )
    assert plan_has_mutations(plan) is False


# ── _json_safe ────────────────────────────────────────────────────────────────


def test_json_safe_none_returns_none() -> None:
    assert _json_safe(None) is None


def test_json_safe_string_returns_string() -> None:
    assert _json_safe("hello") == "hello"


def test_json_safe_list_returns_list() -> None:
    assert _json_safe([1, 2, 3]) == [1, 2, 3]


def test_json_safe_nested_dict() -> None:
    result = _json_safe({"a": {"b": "c"}})
    assert result == {"a": {"b": "c"}}


def test_json_safe_enum_like_value() -> None:
    """Objects with a .value attribute should unwrap to their primitive."""

    class EnumVal:
        value = "ssh"

    result = _json_safe(EnumVal())
    assert result == "ssh"


# ── outcomes_from_plan ────────────────────────────────────────────────────────


def test_outcomes_from_plan_create_has_create_action() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                resource_type="t",
                uid_ref="x",
                title="X",
                keeper_uid=None,
                reason=None,
                before=None,
                after={},
            ),
        ],
    )
    outcomes = outcomes_from_plan(plan, dry_run=False, family="test.v1")
    assert len(outcomes) == 1
    assert outcomes[0].action == "create"


def test_outcomes_from_plan_dry_run_flag_in_details() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                resource_type="t",
                uid_ref="x",
                title="X",
                keeper_uid=None,
                reason=None,
                before=None,
                after={},
            ),
        ],
    )
    outcomes = outcomes_from_plan(plan, dry_run=True, family="test.v1")
    assert outcomes[0].details["dry_run"] is True


def test_outcomes_from_plan_family_in_details() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.UPDATE,
                resource_type="t",
                uid_ref="x",
                title="X",
                keeper_uid="uid",
                reason=None,
                before={},
                after={"f": "v"},
            ),
        ],
    )
    outcomes = outcomes_from_plan(
        plan, dry_run=False, family="keeper-siem.v1", endpoint="/siem/cfg"
    )
    assert outcomes[0].details["family"] == "keeper-siem.v1"
    assert outcomes[0].details["endpoint"] == "/siem/cfg"


def test_outcomes_from_plan_noop_only_plan_returns_empty() -> None:
    """NOOP changes are filtered by plan.ordered(); outcomes list is empty for pure-noop plans."""
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.NOOP,
                resource_type="t",
                uid_ref="y",
                title="Y",
                keeper_uid="uid",
                reason=None,
                before={},
                after={},
            ),
        ],
    )
    outcomes = outcomes_from_plan(plan, dry_run=False, family="test.v1")
    assert outcomes == []


# ── configuration_from_plan ───────────────────────────────────────────────────


def test_configuration_from_plan_create_adds_to_block() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                resource_type="sink",
                uid_ref="sink.x",
                title="Sink X",
                keeper_uid=None,
                reason=None,
                before=None,
                after={"uid_ref": "sink.x", "name": "X"},
            ),
        ],
    )
    config = configuration_from_plan(
        plan,
        resource_to_block={"sink": "sinks"},
    )
    assert "sinks" in config
    assert len(config["sinks"]) == 1
    assert config["sinks"][0]["uid_ref"] == "sink.x"


def test_configuration_from_plan_delete_excluded() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.DELETE,
                resource_type="sink",
                uid_ref="sink.old",
                title="Old",
                keeper_uid="uid",
                reason=None,
                before={"uid_ref": "sink.old"},
                after=None,
            ),
        ],
    )
    config = configuration_from_plan(plan, resource_to_block={"sink": "sinks"})
    assert config.get("sinks") == []


def test_configuration_from_plan_singleton_block() -> None:
    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.UPDATE,
                resource_type="cfg",
                uid_ref="cfg.main",
                title="Cfg",
                keeper_uid="uid",
                reason=None,
                before={"mode": "old"},
                after={"mode": "new", "uid_ref": "cfg.main"},
            ),
        ],
    )
    config = configuration_from_plan(
        plan,
        resource_to_block={"cfg": "config"},
        singleton_blocks=("config",),
    )
    assert config["config"]["mode"] == "new"


# ── Sprint BF: rest_provider_base additional coverage ─────────────────────


def test_response_to_dict_none_returns_empty() -> None:
    """_response_to_dict returns {} for None input."""
    from dsk.providers.rest_provider_base import _response_to_dict

    assert _response_to_dict(None) == {}


def test_response_to_dict_dict_passthrough() -> None:
    """_response_to_dict returns a copy of a dict input."""
    from dsk.providers.rest_provider_base import _response_to_dict

    result = _response_to_dict({"key": "value"})
    assert result == {"key": "value"}


def test_response_to_dict_bytes_valid_json() -> None:
    """_response_to_dict decodes bytes as JSON dict."""
    import json

    from dsk.providers.rest_provider_base import _response_to_dict

    payload = json.dumps({"k": "v"}).encode("utf-8")
    assert _response_to_dict(payload) == {"k": "v"}


def test_response_to_dict_bytes_non_dict_json() -> None:
    """_response_to_dict wraps non-dict JSON under 'result' key."""
    import json

    from dsk.providers.rest_provider_base import _response_to_dict

    payload = json.dumps([1, 2, 3]).encode("utf-8")
    assert _response_to_dict(payload) == {"result": [1, 2, 3]}


def test_response_to_dict_bytes_invalid_json_base64_fallback() -> None:
    """_response_to_dict returns raw base64 for non-JSON bytes."""
    from dsk.providers.rest_provider_base import _response_to_dict

    result = _response_to_dict(b"\xff\xfe binary")
    assert "raw" in result


def test_response_to_dict_bytes_empty() -> None:
    """_response_to_dict returns {} for empty bytes."""
    from dsk.providers.rest_provider_base import _response_to_dict

    assert _response_to_dict(b"") == {}


def test_response_to_dict_string_valid_json() -> None:
    """_response_to_dict parses valid JSON string."""
    from dsk.providers.rest_provider_base import _response_to_dict

    assert _response_to_dict('{"a": 1}') == {"a": 1}


def test_response_to_dict_string_invalid_json() -> None:
    """_response_to_dict wraps invalid JSON string under 'result'."""
    from dsk.providers.rest_provider_base import _response_to_dict

    result = _response_to_dict("not json")
    assert result == {"result": "not json"}


def test_response_to_dict_other_type() -> None:
    """_response_to_dict wraps arbitrary types under 'result'."""
    from dsk.providers.rest_provider_base import _response_to_dict

    assert _response_to_dict(42) == {"result": 42}


def test_json_safe_handles_tuple() -> None:
    """_json_safe converts tuples to lists."""
    from dsk.providers.rest_provider_base import _json_safe

    assert _json_safe((1, 2, 3)) == [1, 2, 3]


def test_json_safe_unwraps_enum_like_value() -> None:
    """_json_safe extracts .value from enum-like objects."""
    from dsk.providers.rest_provider_base import _json_safe

    class FakeEnum:
        value = "on"

    assert _json_safe(FakeEnum()) == "on"


def test_outcomes_from_plan_creates_action() -> None:
    """outcomes_from_plan maps CREATE changes to action='create'."""
    from dsk.core.diff import Change, ChangeKind
    from dsk.core.planner import Plan
    from dsk.providers.rest_provider_base import outcomes_from_plan

    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                resource_type="x",
                uid_ref="x.ref",
                title="New",
                keeper_uid="",
                reason=None,
            ),
        ],
    )
    outcomes = outcomes_from_plan(
        plan, dry_run=True, family="test-family", endpoint="/api/v1/thing"
    )
    assert len(outcomes) == 1
    assert outcomes[0].action == "create"
    assert outcomes[0].details["dry_run"] is True
    assert outcomes[0].details["endpoint"] == "/api/v1/thing"


def test_plan_has_mutations_empty_plan() -> None:
    """plan_has_mutations returns False for a plan with only NOOP changes."""
    from dsk.core.diff import Change, ChangeKind
    from dsk.core.planner import Plan
    from dsk.providers.rest_provider_base import plan_has_mutations

    plan = Plan(
        manifest_name="t",
        changes=[
            Change(
                kind=ChangeKind.NOOP,
                resource_type="x",
                uid_ref="x.ref",
                title="No-op",
                keeper_uid="uid",
                reason=None,
            ),
        ],
    )
    assert not plan_has_mutations(plan)


def test_config_from_response_uses_manifest_key() -> None:
    """config_from_response falls back to 'manifest' key for config source."""
    from dsk.providers.rest_provider_base import config_from_response

    response = {"manifest": {"domains": ["example.com"]}}
    result = config_from_response(response, blocks=("domains",))
    assert result["domains"] == ["example.com"]


def test_config_from_response_uses_top_level_fallback() -> None:
    """config_from_response uses top-level response dict when no config or manifest key."""
    from dsk.providers.rest_provider_base import config_from_response

    response = {"domains": ["fallback.com"]}
    result = config_from_response(response, blocks=("domains",))
    assert result["domains"] == ["fallback.com"]


def test_config_from_response_singleton_block_none_when_missing() -> None:
    """config_from_response returns None for missing singleton blocks."""
    from dsk.providers.rest_provider_base import config_from_response

    response = {}
    result = config_from_response(response, blocks=("audit",), singleton_blocks=("audit",))
    assert result["audit"] is None
