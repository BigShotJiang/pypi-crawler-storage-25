"""Focused edge tests for Commander vault mixin helpers."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import LiveRecord
from dsk.core.planner import Plan
from dsk.providers.commander_cli import _VAULT_SHARED_FOLDER_RESOURCE_TYPE, CommanderCliProvider


def _provider() -> CommanderCliProvider:
    return CommanderCliProvider(folder_uid="folder-scope")


def _shared_folder_update(before: list[dict], after: list[dict]) -> Change:
    return Change(
        kind=ChangeKind.UPDATE,
        uid_ref="sf.team",
        resource_type=_VAULT_SHARED_FOLDER_RESOURCE_TYPE,
        title="Team",
        keeper_uid="SF_UID",
        before={"members": before},
        after={"members": after},
    )


def test_shared_folder_member_permission_normalizes_roles_and_flags() -> None:
    helper = CommanderCliProvider._vault_shared_folder_member_permission

    assert helper({"permission": " manage "}) == "manage"
    assert helper({"role": "read"}) == "read_only"
    assert helper({"role": "edit"}) == "manage_records"
    assert helper({"manage_records": True, "manage_users": True}) == "manage"
    assert helper({"manage_users": True}) == "manage_users"
    assert helper({}) == ""


def test_shared_folder_members_by_email_ignores_invalid_rows_casefolds() -> None:
    rows = [
        {"email": "Admin@Example.com", "role": "edit"},
        {"email": "admin@example.com", "permission": "manage"},
        {"email": "", "role": "edit"},
        "not-a-member",
    ]

    members = CommanderCliProvider._vault_shared_folder_members_by_email(rows)

    assert members == {"admin@example.com": {"email": "admin@example.com", "permission": "manage"}}
    assert CommanderCliProvider._vault_shared_folder_removed_member_count(rows, []) == 1
    assert CommanderCliProvider._vault_shared_folder_removed_member_count({}, rows) == 0


def test_shared_folder_membership_removal_requires_allow_delete() -> None:
    provider = _provider()
    plan = Plan(
        "vault",
        [_shared_folder_update([{"email": "old@example.com", "role": "edit"}], [])],
        ["sf.team"],
    )

    with pytest.raises(CapabilityError, match="membership removal"):
        provider._vault_guard_shared_folder_membership_removals(plan)

    assert getattr(plan, "requires_allow_delete") is True


def test_shared_folder_membership_removal_allows_explicit_delete_gate() -> None:
    provider = _provider()
    plan = Plan(
        "vault",
        [_shared_folder_update([{"email": "old@example.com", "role": "edit"}], [])],
        ["sf.team"],
    )
    setattr(plan, "allow_delete", True)

    provider._vault_guard_shared_folder_membership_removals(plan)

    assert getattr(plan, "requires_allow_delete") is True


def test_shared_folder_create_parent_uses_user_folder_scope_only() -> None:
    provider = _provider()
    params = SimpleNamespace(
        folder_cache={
            "folder-scope": SimpleNamespace(type="user_folder"),
            "shared": SimpleNamespace(type="shared_folder"),
        }
    )

    assert provider._vault_shared_folder_create_parent(params) == "folder-scope"
    provider._folder_uid = "shared"
    assert provider._vault_shared_folder_create_parent(params) == ""
    provider._folder_uid = "missing"
    assert provider._vault_shared_folder_create_parent(params) == ""


def test_shared_folder_membership_update_revokes_and_grants(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _provider()
    calls: list[tuple[str, dict]] = []

    def fake_revoke(**kwargs) -> None:
        calls.append(("revoke", kwargs))

    def fake_share(**kwargs) -> None:
        calls.append(("share", kwargs))

    monkeypatch.setattr(provider, "_revoke_folder_grantee", fake_revoke)
    monkeypatch.setattr(provider, "_share_folder_to_grantee", fake_share)

    result = provider._vault_apply_shared_folder_membership_update(
        "SF_UID",
        before_members=[{"email": "old@example.com", "permission": "manage"}],
        after_members=[{"email": "new@example.com", "permission": "manage_users"}],
    )

    assert result == {"members_granted": 1, "members_removed": 1}
    assert calls[0][0] == "revoke"
    assert calls[0][1]["identifier"] == "old@example.com"
    assert calls[1] == (
        "share",
        {
            "shared_folder_uid": "SF_UID",
            "grantee_kind": "user",
            "identifier": "new@example.com",
            "manage_records": False,
            "manage_users": True,
        },
    )


def test_shared_folder_default_permissions_update(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider()
    calls: list[dict] = []
    monkeypatch.setattr(provider, "_share_folder_to_grantee", lambda **kwargs: calls.append(kwargs))

    assert provider._vault_apply_shared_folder_permissions_update("SF_UID", None) is False
    assert provider._vault_apply_shared_folder_permissions_update(
        "SF_UID", {"manage_records": True, "manage_users": False}
    )
    assert calls == [
        {
            "shared_folder_uid": "SF_UID",
            "grantee_kind": "default",
            "manage_records": True,
            "manage_users": False,
        }
    ]


def test_resource_attachments_no_attachment_config_returns_empty() -> None:
    provider = _provider()
    provider._manifest_source = {"resources": [{"uid_ref": "r1", "type": "pamMachine"}]}

    assert provider._apply_resource_attachments([]) == []


def test_resource_attachments_discover_failure_preserves_context(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _provider()
    provider._manifest_source = {
        "resources": [{"uid_ref": "r1", "type": "pamMachine", "attachments": ["a.txt"]}]
    }

    def fail_discover() -> list[LiveRecord]:
        raise CapabilityError(
            reason="discover broke",
            next_action="retry later",
            context={"stderr": "boom"},
        )

    monkeypatch.setattr(provider, "discover", fail_discover)

    with pytest.raises(CapabilityError) as exc:
        provider._apply_resource_attachments([])

    assert "discover() refresh failed" in exc.value.reason
    assert exc.value.next_action == "retry later"
    assert exc.value.context["stderr"] == "boom"


def test_resource_attachments_missing_live_record_fails(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    provider = _provider()
    attachment = tmp_path / "a.txt"
    attachment.write_text("content", encoding="utf-8")
    provider._manifest_source = {
        "resources": [
            {
                "uid_ref": "r1",
                "type": "pamMachine",
                "title": "Host",
                "attachments": [str(attachment)],
            }
        ]
    }
    monkeypatch.setattr(provider, "discover", lambda: [])

    with pytest.raises(CapabilityError, match="cannot resolve"):
        provider._apply_resource_attachments([])


def test_resource_attachments_missing_file_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider()
    provider._manifest_source = {
        "resources": [
            {
                "uid_ref": "r1",
                "type": "pamMachine",
                "title": "Host",
                "attachments": ["/no/such/dsk-attachment.txt"],
            }
        ]
    }
    monkeypatch.setattr(
        provider,
        "discover",
        lambda: [
            LiveRecord(
                keeper_uid="REC_UID",
                title="Host",
                resource_type="pamMachine",
                marker={"uid_ref": "r1"},
                payload={},
            )
        ],
    )

    with pytest.raises(CapabilityError, match="file missing"):
        provider._apply_resource_attachments([])


def test_resource_attachments_uploads_existing_file(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    provider = _provider()
    attachment = tmp_path / "a.txt"
    attachment.write_text("content", encoding="utf-8")
    provider._manifest_source = {
        "resources": [
            {
                "uid_ref": "r1",
                "type": "pamMachine",
                "title": "Host",
                "attachments": [str(attachment)],
            }
        ]
    }
    calls: list[list[str]] = []
    monkeypatch.setattr(
        provider,
        "discover",
        lambda: [
            LiveRecord(
                keeper_uid="REC_UID",
                title="Host",
                resource_type="pamMachine",
                marker={"uid_ref": "r1"},
                payload={},
            )
        ],
    )
    monkeypatch.setattr(provider, "_run_cmd", lambda argv: calls.append(argv) or "")

    outcomes = provider._apply_resource_attachments([])

    assert calls == [["upload-attachment", "REC_UID", "--file", str(attachment)]]
    assert outcomes[0].action == "attachment"
    assert outcomes[0].details["file"] == "a.txt"
