"""Tests for drift_policy enforcement in rules.py."""

import pytest

from dsk.core.errors import SchemaError
from dsk.core.rules import enforce_drift_policy


def test_no_drift_policy_no_raise():
    enforce_drift_policy({}, has_drift=True)


def test_drift_policy_report_mode_no_raise():
    doc = {"drift_policy": {"mode": "report"}}
    enforce_drift_policy(doc, has_drift=True)


def test_drift_policy_block_pipeline_raises_on_drift():
    doc = {"drift_policy": {"mode": "block_pipeline", "max_drift_fields": 3}}
    with pytest.raises(SchemaError) as exc_info:
        enforce_drift_policy(doc, has_drift=True)
    assert "block_pipeline" in str(exc_info.value)
    assert "3" in str(exc_info.value)


def test_drift_policy_block_pipeline_no_raise_when_no_drift():
    doc = {"drift_policy": {"mode": "block_pipeline"}}
    enforce_drift_policy(doc, has_drift=False)


def test_drift_policy_auto_apply_no_raise():
    doc = {"drift_policy": {"mode": "auto_apply"}}
    enforce_drift_policy(doc, has_drift=True)


def test_enforce_drift_policy_exported():
    from dsk.core.rules import enforce_drift_policy

    assert callable(enforce_drift_policy)
