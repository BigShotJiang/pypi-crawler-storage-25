"""Sprint BK: batch coverage for 14 diff modules — live-branch + empty-manifest paths."""

from __future__ import annotations

import pytest

# ── Helpers ────────────────────────────────────────────────────────────────


def _build(cls, extra=None):
    """Construct a minimal manifest model."""
    doc = {
        "schema": cls.model_fields["schema_"].default or "x",
        "name": "test",
        "version": "1",
        "manager": "dsk",
    }
    if extra:
        doc.update(extra)
    return cls.model_validate(doc)


# ══════════════════════════════════════════════════════════════════════════
# cmmc_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_cmmc_diff_live_raises_not_implemented():
    from dsk.core.cmmc_diff import compute_cmmc_diff
    from dsk.core.models_cmmc import CmmcProfileManifestV1

    m = _build(CmmcProfileManifestV1)
    with pytest.raises(NotImplementedError):
        compute_cmmc_diff(m, live={"control_id": "AC.1"})


def test_compute_cmmc_diff_empty_returns_empty():
    from dsk.core.cmmc_diff import compute_cmmc_diff
    from dsk.core.models_cmmc import CmmcProfileManifestV1

    m = _build(CmmcProfileManifestV1)
    assert compute_cmmc_diff(m) == []


def test_compute_cmmc_diff_with_controls_returns_changes():
    from dsk.core.cmmc_diff import compute_cmmc_diff
    from dsk.core.models_cmmc import CmmcProfileManifestV1

    m = _build(
        CmmcProfileManifestV1,
        {
            "controls": [
                {"practice_id": "AC.1.001", "domain": "AC", "description": "desc", "status": "met"}
            ]
        },
    )
    changes = compute_cmmc_diff(m, manifest_name="my-cmmc")
    assert len(changes) == 1
    assert len(changes) == 1
    assert changes[0].resource_type == "cmmc_control"


# ══════════════════════════════════════════════════════════════════════════
# dora_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_dora_diff_live_raises_not_implemented():
    from dsk.core.dora_diff import compute_dora_diff
    from dsk.core.models_dora import DoraProfileManifestV1

    m = _build(DoraProfileManifestV1)
    with pytest.raises(NotImplementedError):
        compute_dora_diff(m, live={"x": 1})


def test_compute_dora_diff_empty_returns_empty():
    from dsk.core.dora_diff import compute_dora_diff
    from dsk.core.models_dora import DoraProfileManifestV1

    m = _build(DoraProfileManifestV1)
    assert compute_dora_diff(m) == []


def test_compute_dora_diff_with_controls_returns_changes():
    from dsk.core.dora_diff import compute_dora_diff
    from dsk.core.models_dora import DoraProfileManifestV1

    m = _build(
        DoraProfileManifestV1,
        {
            "controls": [
                {"article": "art-5", "control_description": "ICT resilience", "status": "satisfied"}
            ]
        },
    )
    changes = compute_dora_diff(m)
    assert len(changes) == 1


# ══════════════════════════════════════════════════════════════════════════
# pqc_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_pqc_diff_live_raises_not_implemented():
    from dsk.core.models_pqc import PqcPolicyManifestV1
    from dsk.core.pqc_diff import compute_pqc_diff

    m = _build(PqcPolicyManifestV1)
    with pytest.raises(NotImplementedError):
        compute_pqc_diff(m, live={"x": 1})


def test_compute_pqc_diff_empty_returns_empty():
    from dsk.core.models_pqc import PqcPolicyManifestV1
    from dsk.core.pqc_diff import compute_pqc_diff

    m = _build(PqcPolicyManifestV1)
    assert compute_pqc_diff(m) == []


def test_compute_pqc_diff_with_requirements():
    from dsk.core.models_pqc import PqcPolicyManifestV1
    from dsk.core.pqc_diff import compute_pqc_diff

    m = _build(
        PqcPolicyManifestV1,
        {"requirements": [{"uid_ref": "res-1", "required_algorithm": "kyber-768"}]},
    )
    changes = compute_pqc_diff(m)
    assert len(changes) == 1


# ══════════════════════════════════════════════════════════════════════════
# itsm_gate_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_itsm_gate_diff_live_raises_not_implemented():
    from dsk.core.itsm_gate_diff import compute_itsm_gate_diff
    from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1

    m = _build(ItsmApprovalGateManifestV1)
    with pytest.raises(NotImplementedError):
        compute_itsm_gate_diff(m, live={"x": 1})


def test_compute_itsm_gate_diff_empty_returns_empty():
    from dsk.core.itsm_gate_diff import compute_itsm_gate_diff
    from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1

    m = _build(ItsmApprovalGateManifestV1)
    assert compute_itsm_gate_diff(m) == []


def test_compute_itsm_gate_diff_with_gates():
    from dsk.core.itsm_gate_diff import compute_itsm_gate_diff
    from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1

    m = _build(
        ItsmApprovalGateManifestV1, {"gates": [{"name": "gate-1", "platform": "servicenow"}]}
    )
    changes = compute_itsm_gate_diff(m, manifest_name="my-itsm")
    assert len(changes) == 1


# ══════════════════════════════════════════════════════════════════════════
# slack_gate_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_slack_gate_diff_live_raises_not_implemented():
    from dsk.core.models_slack_gate import SlackApprovalGateManifestV1
    from dsk.core.slack_gate_diff import compute_slack_gate_diff

    m = _build(SlackApprovalGateManifestV1)
    with pytest.raises(NotImplementedError):
        compute_slack_gate_diff(m, live={"x": 1})


def test_compute_slack_gate_diff_empty_returns_empty():
    from dsk.core.models_slack_gate import SlackApprovalGateManifestV1
    from dsk.core.slack_gate_diff import compute_slack_gate_diff

    m = _build(SlackApprovalGateManifestV1)
    assert compute_slack_gate_diff(m) == []


def test_compute_slack_gate_diff_with_gates():
    from dsk.core.models_slack_gate import SlackApprovalGateManifestV1
    from dsk.core.slack_gate_diff import compute_slack_gate_diff

    m = _build(
        SlackApprovalGateManifestV1, {"gates": [{"name": "gate-1", "channel": "#approvals"}]}
    )
    changes = compute_slack_gate_diff(m)
    assert len(changes) == 1


# ══════════════════════════════════════════════════════════════════════════
# mcp_allowlist_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_mcp_allowlist_diff_live_raises_not_implemented():
    from dsk.core.mcp_allowlist_diff import compute_mcp_allowlist_diff
    from dsk.core.models_mcp_allowlist import McpAllowlistManifest

    m = McpAllowlistManifest.model_validate({"schema": "mcp-server-allowlist.v1", "name": "test"})
    with pytest.raises(NotImplementedError):
        compute_mcp_allowlist_diff(m, live={"x": 1})


def test_compute_mcp_allowlist_diff_empty_returns_empty():
    from dsk.core.mcp_allowlist_diff import compute_mcp_allowlist_diff
    from dsk.core.models_mcp_allowlist import McpAllowlistManifest

    m = McpAllowlistManifest.model_validate({"schema": "mcp-server-allowlist.v1", "name": "test"})
    assert compute_mcp_allowlist_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# mcp_diff (mcp-secrets-binding.v1)
# ══════════════════════════════════════════════════════════════════════════


def test_compute_mcp_diff_live_raises_not_implemented():
    from dsk.core.mcp_diff import compute_mcp_diff
    from dsk.core.models_mcp import McpSecretsBindingManifestV1

    m = _build(McpSecretsBindingManifestV1)
    with pytest.raises(NotImplementedError):
        compute_mcp_diff(m, live={"x": 1})


def test_compute_mcp_diff_empty_returns_empty():
    from dsk.core.mcp_diff import compute_mcp_diff
    from dsk.core.models_mcp import McpSecretsBindingManifestV1

    m = _build(McpSecretsBindingManifestV1)
    assert compute_mcp_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# spiffe_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_spiffe_diff_live_raises_not_implemented():
    from dsk.core.models_spiffe import SpiffeBindingManifestV1
    from dsk.core.spiffe_diff import compute_spiffe_diff

    m = _build(SpiffeBindingManifestV1, {"trust_domain": "example.org"})
    with pytest.raises(NotImplementedError):
        compute_spiffe_diff(m, live={"x": 1})


def test_compute_spiffe_diff_empty_returns_empty():
    from dsk.core.models_spiffe import SpiffeBindingManifestV1
    from dsk.core.spiffe_diff import compute_spiffe_diff

    m = _build(SpiffeBindingManifestV1, {"trust_domain": "example.org"})
    assert compute_spiffe_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# trust_chain_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_trust_chain_diff_live_raises_not_implemented():
    from dsk.core.models_trust_chain import TrustChainManifestV1
    from dsk.core.trust_chain_diff import compute_trust_chain_diff

    m = _build(TrustChainManifestV1)
    with pytest.raises(NotImplementedError):
        compute_trust_chain_diff(m, live={"x": 1})


def test_compute_trust_chain_diff_empty_returns_empty():
    from dsk.core.models_trust_chain import TrustChainManifestV1
    from dsk.core.trust_chain_diff import compute_trust_chain_diff

    m = _build(TrustChainManifestV1)
    assert compute_trust_chain_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# workflow_gate_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_workflow_gate_diff_live_raises_not_implemented():
    from dsk.core.models_workflow_gate import WorkflowGateManifestV1
    from dsk.core.workflow_gate_diff import compute_workflow_gate_diff

    m = _build(WorkflowGateManifestV1)
    with pytest.raises(NotImplementedError):
        compute_workflow_gate_diff(m, live={"x": 1})


def test_compute_workflow_gate_diff_empty_returns_empty():
    from dsk.core.models_workflow_gate import WorkflowGateManifestV1
    from dsk.core.workflow_gate_diff import compute_workflow_gate_diff

    m = _build(WorkflowGateManifestV1)
    assert compute_workflow_gate_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# cloud_jit_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_cloud_jit_diff_live_raises_not_implemented():
    from dsk.core.cloud_jit_diff import compute_cloud_jit_diff
    from dsk.core.models_cloud_jit import CloudJitManifestV1

    m = _build(CloudJitManifestV1)
    with pytest.raises(NotImplementedError):
        compute_cloud_jit_diff(m, live={"x": 1})


def test_compute_cloud_jit_diff_empty_returns_empty():
    from dsk.core.cloud_jit_diff import compute_cloud_jit_diff
    from dsk.core.models_cloud_jit import CloudJitManifestV1

    m = _build(CloudJitManifestV1)
    assert compute_cloud_jit_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# connection_profile_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_connection_profile_diff_live_raises_not_implemented():
    from dsk.core.connection_profile_diff import compute_connection_profile_diff
    from dsk.core.models_connection_profile import PamConnectionProfileManifestV1

    m = _build(PamConnectionProfileManifestV1)
    with pytest.raises(NotImplementedError):
        compute_connection_profile_diff(m, live={"x": 1})


def test_compute_connection_profile_diff_empty_returns_empty():
    from dsk.core.connection_profile_diff import compute_connection_profile_diff
    from dsk.core.models_connection_profile import PamConnectionProfileManifestV1

    m = _build(PamConnectionProfileManifestV1)
    assert compute_connection_profile_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# db_access_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_db_access_diff_live_raises_not_implemented():
    from dsk.core.db_access_diff import compute_db_access_diff
    from dsk.core.models_db_access import DbAccessPolicyManifestV1

    m = _build(DbAccessPolicyManifestV1)
    with pytest.raises(NotImplementedError):
        compute_db_access_diff(m, live={"x": 1})


def test_compute_db_access_diff_empty_returns_empty():
    from dsk.core.db_access_diff import compute_db_access_diff
    from dsk.core.models_db_access import DbAccessPolicyManifestV1

    m = _build(DbAccessPolicyManifestV1)
    assert compute_db_access_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# gateway_ha_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_gateway_ha_diff_live_raises_not_implemented():
    from dsk.core.gateway_ha_diff import compute_gateway_ha_diff
    from dsk.core.models_gateway_ha import GatewayHaManifestV1

    m = _build(GatewayHaManifestV1)
    with pytest.raises(NotImplementedError):
        compute_gateway_ha_diff(m, live={"x": 1})


def test_compute_gateway_ha_diff_empty_returns_empty():
    from dsk.core.gateway_ha_diff import compute_gateway_ha_diff
    from dsk.core.models_gateway_ha import GatewayHaManifestV1

    m = _build(GatewayHaManifestV1)
    assert compute_gateway_ha_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# pipeline_env_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_pipeline_env_diff_live_raises_not_implemented():
    from dsk.core.models_pipeline_env import PipelineEphemeralManifestV1
    from dsk.core.pipeline_env_diff import compute_pipeline_env_diff

    m = _build(PipelineEphemeralManifestV1)
    with pytest.raises(NotImplementedError):
        compute_pipeline_env_diff(m, live={"x": 1})


def test_compute_pipeline_env_diff_empty_returns_empty():
    from dsk.core.models_pipeline_env import PipelineEphemeralManifestV1
    from dsk.core.pipeline_env_diff import compute_pipeline_env_diff

    m = _build(PipelineEphemeralManifestV1)
    assert compute_pipeline_env_diff(m) == []


# ══════════════════════════════════════════════════════════════════════════
# agent_memory_policy_diff
# ══════════════════════════════════════════════════════════════════════════


def test_compute_agent_memory_policy_diff_live_raises_not_implemented():
    from dsk.core.agent_memory_policy_diff import compute_agent_memory_policy_diff
    from dsk.core.models_agent_memory_policy import AgentMemoryPolicyManifest

    m = AgentMemoryPolicyManifest.model_validate(
        {"schema": "agent-memory-policy.v1", "name": "test"}
    )
    with pytest.raises(NotImplementedError):
        compute_agent_memory_policy_diff(m, live={"x": 1})


def test_compute_agent_memory_policy_diff_empty_returns_empty():
    from dsk.core.agent_memory_policy_diff import compute_agent_memory_policy_diff
    from dsk.core.models_agent_memory_policy import AgentMemoryPolicyManifest

    m = AgentMemoryPolicyManifest.model_validate(
        {"schema": "agent-memory-policy.v1", "name": "test"}
    )
    assert compute_agent_memory_policy_diff(m) == []
