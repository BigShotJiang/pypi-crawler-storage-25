"""Tests for PQC public API: load_pqc_manifest, exports."""

import pytest

from dsk.core import PqcAlgorithm, PqcPolicyManifestV1, load_pqc_manifest

PQC_YAML = """
schema: pqc-policy.v1
version: "1"
name: acme-pqc-policy
trust_domain: acme.com
default_algorithm: kyber-768
migration_deadline: "2027-12-31"
requirements:
  - uid_ref: res.db-prod
    required_algorithm: kyber-768
    migration_deadline: "2026-12-31"
    current_status: not_started
"""


def test_pqc_exports_available():
    from dsk.core import PqcAlgorithm, PqcMigrationStatus, PqcPolicyManifestV1

    assert PqcPolicyManifestV1 is not None
    assert PqcAlgorithm is not None
    assert PqcMigrationStatus is not None


def test_load_pqc_manifest_from_string(tmp_path):
    p = tmp_path / "policy.yaml"
    p.write_text(PQC_YAML)
    manifest = load_pqc_manifest(p)
    assert isinstance(manifest, PqcPolicyManifestV1)
    assert manifest.name == "acme-pqc-policy"
    assert manifest.default_algorithm == PqcAlgorithm.kyber_768
    assert len(manifest.requirements) == 1


def test_load_pqc_manifest_wrong_schema_raises(tmp_path):
    p = tmp_path / "wrong.yaml"
    p.write_text("schema: pam-environment.v1\nname: test\n")
    with pytest.raises(Exception):
        load_pqc_manifest(p)


def test_spiffe_exports_available():
    from dsk.core import SpiffeBindingManifestV1, SpiffeMatchMode

    assert SpiffeBindingManifestV1 is not None
    assert SpiffeMatchMode is not None


def test_load_spiffe_manifest(tmp_path):
    from dsk.core import SpiffeBindingManifestV1, load_spiffe_manifest

    content = """
schema: spiffe-binding.v1
name: test-rules
trust_domain: acme.com
rules: []
"""
    p = tmp_path / "spiffe.yaml"
    p.write_text(content)
    manifest = load_spiffe_manifest(p)
    assert isinstance(manifest, SpiffeBindingManifestV1)
    assert manifest.trust_domain == "acme.com"
