"""JIT import/extend support coverage."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_CHANGES
from dsk.core.manifest import load_manifest
from dsk.core.normalize import to_pam_import_json
from dsk.providers.commander_cli import CommanderCliProvider


def _run(args: list[str]):
    runner = CliRunner()
    return runner.invoke(main, args, catch_exceptions=False)


@pytest.fixture
def commander_offline(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    monkeypatch.setattr(CommanderCliProvider, "discover", lambda self: [])


def _write_jit_manifest(tmp_path: Path) -> Path:
    manifest_path = tmp_path / "jit.yaml"
    manifest_path.write_text(
        """
version: "1"
name: jit-project-import
resources:
  - uid_ref: dir.linux
    type: pamDirectory
    title: Linux Directory
    directory_type: ldap
    host: ldap.example.com
  - uid_ref: res.shell
    type: pamMachine
    title: shell
    host: shell.example.com
    pam_settings:
      options:
        jit_settings:
          create_ephemeral: true
          elevate: true
          elevation_method: group
          elevation_string: wheel
          ephemeral_account_type: linux
          pam_directory_uid_ref: dir.linux
""".lstrip(),
        encoding="utf-8",
    )
    return manifest_path


def test_jit_design_declares_supported_import_extend_path() -> None:
    text = Path("docs/JIT_DESIGN.md").read_text(encoding="utf-8")

    assert "Status: `supported`" in text
    assert "pam project import" in text
    assert "pam project extend" in text


def test_jit_plan_emits_resource_creates_without_capability_conflict(
    commander_offline: None,
    tmp_path: Path,
) -> None:
    manifest_path = _write_jit_manifest(tmp_path)

    result = _run(["--provider", "commander", "plan", str(manifest_path), "--json"])

    assert result.exit_code == EXIT_CHANGES, result.output
    payload = json.loads(result.output)
    assert payload["summary"]["conflict"] == 0
    assert any(change["resource_type"] == "pamMachine" for change in payload["changes"])


def test_jit_pam_directory_uid_ref_maps_to_commander_import_key(tmp_path: Path) -> None:
    manifest_path = _write_jit_manifest(tmp_path)
    manifest = load_manifest(manifest_path)

    payload = to_pam_import_json(manifest.model_dump(mode="python", exclude_none=True))
    machine = next(row for row in payload["pam_data"]["resources"] if row["title"] == "shell")

    jit_settings = machine["pam_settings"]["options"]["jit_settings"]
    assert jit_settings["pam_directory_record"] == "Linux Directory"
    assert "pam_directory_uid_ref" not in jit_settings


def test_jit_plan_json_summary_keys_are_complete(
    commander_offline: None,
    tmp_path: Path,
) -> None:
    """Plan JSON output must carry all required summary keys."""
    manifest_path = _write_jit_manifest(tmp_path)
    result = _run(["--provider", "commander", "plan", str(manifest_path), "--json"])

    payload = json.loads(result.output)
    assert set(payload["summary"]) >= {"create", "update", "delete", "noop", "conflict"}


def test_jit_validate_exits_zero(tmp_path: Path) -> None:
    """JIT manifest must pass dsk validate with EXIT_OK."""
    from dsk.cli.main import EXIT_OK

    manifest_path = _write_jit_manifest(tmp_path)
    result = _run(["validate", str(manifest_path)])
    assert result.exit_code == EXIT_OK, result.output


def test_jit_manifest_loads_as_pam_environment(tmp_path: Path) -> None:
    """load_manifest must return a Manifest with family pam-environment.v1."""
    manifest_path = _write_jit_manifest(tmp_path)
    manifest = load_manifest(manifest_path)
    assert manifest.name == "jit-project-import"
    resources = manifest.resources
    assert any(r.type == "pamMachine" for r in resources)
    assert any(r.type == "pamDirectory" for r in resources)
