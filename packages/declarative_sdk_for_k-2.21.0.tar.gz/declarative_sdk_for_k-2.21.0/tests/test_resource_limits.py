"""Resource-limit tests for manifest and keeperCMD import parsing."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from dsk.cli.cmd_import_from_keepercmd import _parse_manifest_csv
from dsk.core.errors import ManifestError
from dsk.core.manifest import read_manifest_document_string
from dsk.core.resource_limits import (
    ResourceLimitError,
    json_loads_limited,
    read_bytes_limited,
    read_text_limited,
)
from dsk.mcp.server import _frame_limit_error, _tool_argument_limit_error


def _write_csv(path: Path, row_count: int) -> None:
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=["source_uid", "target_uid", "title", "type", "status", "timestamp"],
        )
        writer.writeheader()
        for index in range(row_count):
            writer.writerow(
                {
                    "source_uid": f"SRC{index}",
                    "target_uid": f"TGT{index}",
                    "title": "Title",
                    "type": "login",
                    "status": "paired",
                    "timestamp": "",
                }
            )


def test_manifest_csv_row_cap_accepts_just_under(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("DSK_MAX_MANIFEST_CSV_ROWS", "3")
    path = tmp_path / "manifest.csv"
    _write_csv(path, 2)

    assert len(_parse_manifest_csv(path)) == 2


def test_manifest_csv_row_cap_accepts_at_limit(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("DSK_MAX_MANIFEST_CSV_ROWS", "3")
    path = tmp_path / "manifest.csv"
    _write_csv(path, 3)

    assert len(_parse_manifest_csv(path)) == 3


def test_manifest_csv_row_cap_rejects_just_over(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("DSK_MAX_MANIFEST_CSV_ROWS", "3")
    path = tmp_path / "manifest.csv"
    _write_csv(path, 4)

    with pytest.raises(ImportError, match="DSK_MAX_MANIFEST_CSV_ROWS=3"):
        _parse_manifest_csv(path)


def test_yaml_parse_depth_accepts_just_under(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MAX_PARSE_DEPTH", "3")

    assert read_manifest_document_string("schema: keeper-vault.v1\nrecords: []\n")["records"] == []


def test_json_parse_depth_accepts_at_limit(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MAX_PARSE_DEPTH", "3")
    raw = json.dumps({"schema": "keeper-vault.v1", "nested": {"value": "x"}})

    assert read_manifest_document_string(raw, suffix=".json")["nested"]["value"] == "x"


def test_json_parse_depth_rejects_just_over(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MAX_PARSE_DEPTH", "3")
    raw = json.dumps({"schema": "keeper-vault.v1", "nested": {"child": {"leaf": {"value": "x"}}}})

    with pytest.raises(ManifestError, match="DSK_MAX_PARSE_DEPTH=3"):
        read_manifest_document_string(raw, suffix=".json")


def _sized_rpc_frame(size: int) -> str:
    prefix = '{"jsonrpc":"2.0","id":1,"method":"ping","params":{"x":"'
    suffix = '"}}\n'
    return prefix + ("a" * (size - len(prefix.encode()) - len(suffix.encode()))) + suffix


def test_mcp_frame_cap_accepts_just_under(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MCP_MAX_FRAME_BYTES", "128")

    assert _frame_limit_error(_sized_rpc_frame(127)) is None


def test_mcp_frame_cap_accepts_at_limit(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MCP_MAX_FRAME_BYTES", "128")

    assert _frame_limit_error(_sized_rpc_frame(128)) is None


def test_mcp_frame_cap_rejects_just_over(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MCP_MAX_FRAME_BYTES", "128")

    assert "DSK_MCP_MAX_FRAME_BYTES=128" in (_frame_limit_error(_sized_rpc_frame(129)) or "")


def _argument_payload_with_size(size: int) -> dict[str, str]:
    prefix = '{"x":"'
    suffix = '"}'
    return {"x": "a" * (size - len(prefix.encode()) - len(suffix.encode()))}


def test_mcp_argument_byte_cap_accepts_just_under(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MCP_MAX_ARGUMENT_BYTES", "32")

    assert _tool_argument_limit_error("tool", _argument_payload_with_size(31)) is None


def test_mcp_argument_byte_cap_accepts_at_limit(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MCP_MAX_ARGUMENT_BYTES", "32")

    assert _tool_argument_limit_error("tool", _argument_payload_with_size(32)) is None


def test_mcp_argument_byte_cap_rejects_just_over(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MCP_MAX_ARGUMENT_BYTES", "32")

    assert "DSK_MCP_MAX_ARGUMENT_BYTES=32" in (
        _tool_argument_limit_error("tool", _argument_payload_with_size(33)) or ""
    )


def test_mcp_argument_depth_cap_rejects_just_over(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_MCP_MAX_ARGUMENT_DEPTH", "3")

    assert _tool_argument_limit_error("tool", {"a": {"b": "c"}}) is None
    assert "DSK_MCP_MAX_ARGUMENT_DEPTH=3" in (
        _tool_argument_limit_error("tool", {"a": {"b": {"c": {"d": "e"}}}}) or ""
    )


def test_json_loads_limited_accepts_at_byte_cap() -> None:
    raw = b'{"x":"a"}'

    assert json_loads_limited(
        raw,
        max_bytes=len(raw),
        max_depth=2,
        label="payload",
        byte_limit_name="TEST_MAX_BYTES",
        depth_limit_name="TEST_MAX_DEPTH",
    ) == {"x": "a"}


def test_json_loads_limited_rejects_just_over_byte_cap() -> None:
    raw = b'{"x":"a"}'

    with pytest.raises(ResourceLimitError, match="TEST_MAX_BYTES"):
        json_loads_limited(
            raw,
            max_bytes=len(raw) - 1,
            max_depth=2,
            label="payload",
            byte_limit_name="TEST_MAX_BYTES",
            depth_limit_name="TEST_MAX_DEPTH",
        )


def test_json_loads_limited_rejects_just_over_depth_cap() -> None:
    with pytest.raises(ResourceLimitError, match="TEST_MAX_DEPTH=2"):
        json_loads_limited(
            b'{"a":{"b":{"c":"d"}}}',
            max_bytes=128,
            max_depth=2,
            label="payload",
            byte_limit_name="TEST_MAX_BYTES",
            depth_limit_name="TEST_MAX_DEPTH",
        )


def test_read_text_limited_accepts_just_under(tmp_path: Path) -> None:
    path = tmp_path / "payload.txt"
    path.write_text("abc", encoding="utf-8")

    assert (
        read_text_limited(path, max_bytes=4, label="payload", limit_name="TEST_MAX_BYTES") == "abc"
    )


def test_read_text_limited_accepts_at_cap(tmp_path: Path) -> None:
    path = tmp_path / "payload.txt"
    path.write_text("abc", encoding="utf-8")

    assert (
        read_text_limited(path, max_bytes=3, label="payload", limit_name="TEST_MAX_BYTES") == "abc"
    )


def test_read_text_limited_rejects_just_over(tmp_path: Path) -> None:
    path = tmp_path / "payload.txt"
    path.write_text("abc", encoding="utf-8")

    with pytest.raises(ResourceLimitError, match="TEST_MAX_BYTES=2"):
        read_text_limited(path, max_bytes=2, label="payload", limit_name="TEST_MAX_BYTES")


def test_read_bytes_limited_accepts_at_cap(tmp_path: Path) -> None:
    path = tmp_path / "payload.bin"
    path.write_bytes(b"abc")

    assert (
        read_bytes_limited(path, max_bytes=3, label="payload", limit_name="TEST_MAX_BYTES")
        == b"abc"
    )


def test_read_bytes_limited_rejects_just_over(tmp_path: Path) -> None:
    path = tmp_path / "payload.bin"
    path.write_bytes(b"abcd")

    with pytest.raises(ResourceLimitError, match="TEST_MAX_BYTES=3"):
        read_bytes_limited(path, max_bytes=3, label="payload", limit_name="TEST_MAX_BYTES")


def test_read_bytes_limited_checks_actual_read_size_after_open(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path = tmp_path / "payload.bin"
    path.write_bytes(b"abcd")
    monkeypatch.setattr("dsk.core.resource_limits.os.fstat", lambda _fd: SimpleNamespace(st_size=1))

    with pytest.raises(ResourceLimitError, match="TEST_MAX_BYTES=3"):
        read_bytes_limited(path, max_bytes=3, label="payload", limit_name="TEST_MAX_BYTES")
