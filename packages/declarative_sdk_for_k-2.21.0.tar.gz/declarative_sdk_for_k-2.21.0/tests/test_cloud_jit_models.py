"""Tests for multi-cloud JIT federation models."""

from pathlib import Path

import pytest
import yaml

from dsk.core.models_cloud_jit import CloudJitManifestV1, CloudJitPolicy, CloudProvider


def test_cloud_jit_policy_defaults():
    policy = CloudJitPolicy(
        name="test",
        provider=CloudProvider.aws,
        keeper_pam_uid_ref="cfg.test",
    )
    assert policy.require_keeper_session is True
    assert policy.audit_log is True
    assert policy.aws is None


def test_cloud_jit_manifest_round_trip():
    example = Path(__file__).parent.parent / "examples/cloud-jit/acme-cloud-jit.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = CloudJitManifestV1(**data)
    assert manifest.schema_ == "cloud-jit.v1"
    assert len(manifest.policies) == 3
    assert manifest.policies[0].provider == CloudProvider.aws
    assert manifest.policies[1].azure is not None
    assert manifest.policies[1].azure.require_mfa is True
    assert manifest.policies[2].gcp is not None
    assert manifest.policies[2].gcp.role == "roles/compute.admin"


def test_aws_jit_duration_bounds():
    from pydantic import ValidationError

    from dsk.core.models_cloud_jit import AwsJitConfig

    with pytest.raises(ValidationError):
        AwsJitConfig(
            account_id="123",
            permission_set_arn="arn:x",
            identity_store_id="d-x",
            duration_hours=24,
        )


def test_cloud_jit_schema_alias():
    m = CloudJitManifestV1(**{"schema": "cloud-jit.v1", "name": "test"})
    assert m.schema_ == "cloud-jit.v1"


def test_azure_jit_duration_upper_bound():
    """AzureJitConfig duration_hours cannot exceed 8."""
    from pydantic import ValidationError

    from dsk.core.models_cloud_jit import AzureJitConfig

    with pytest.raises(ValidationError):
        AzureJitConfig(
            subscription_id="sub",
            role_definition_id="role",
            tenant_id="ten",
            duration_hours=9,
        )


def test_gcp_jit_duration_minimum():
    """GcpJitConfig duration_hours must be at least 1."""
    from pydantic import ValidationError

    from dsk.core.models_cloud_jit import GcpJitConfig

    with pytest.raises(ValidationError):
        GcpJitConfig(project_id="p", role="roles/viewer", duration_hours=0)


def test_cloud_jit_manifest_defaults():
    """Root manifest defaults version, manager, and empty policies."""
    m = CloudJitManifestV1(**{"schema": "cloud-jit.v1", "name": "root"})
    assert m.version == "1"
    assert m.manager == "dsk"
    assert m.policies == []
