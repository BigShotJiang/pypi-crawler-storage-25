"""Tests for AI agent capability token models."""

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError


def test_token_defaults():
    from dsk.core.models_ai_token import AiCapabilityToken, TokenRevocationTrigger

    token = AiCapabilityToken(
        name="test-token",
        agent_uid_ref="nhi.test-agent",
    )
    assert token.ttl_seconds == 900
    assert token.revocation == TokenRevocationTrigger.any
    assert token.audit_log is True
    assert token.max_issuances_per_hour == 10


def test_token_manifest_round_trip():
    from dsk.core.models_ai_token import AiTokenManifestV1, TokenScope

    example = Path(__file__).parent.parent / "examples/ai-tokens/acme-ai-tokens.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = AiTokenManifestV1(**data)
    assert manifest.schema_ == "ai-token.v1"
    assert len(manifest.tokens) == 2
    assert manifest.tokens[0].resources[0].scope == TokenScope.read
    assert manifest.tokens[1].resources[0].allow_connection is True


def test_token_ttl_bounds():
    from dsk.core.models_ai_token import AiCapabilityToken

    with pytest.raises(ValidationError):
        AiCapabilityToken(name="t", agent_uid_ref="nhi.x", ttl_seconds=30)
    with pytest.raises(ValidationError):
        AiCapabilityToken(name="t", agent_uid_ref="nhi.x", ttl_seconds=7200)


def test_workload_identity_binding_valid():
    from dsk.core.models_ai_token import (
        AiCapabilityToken,
        FederationType,
        WorkloadIdentityBinding,
    )

    wi = WorkloadIdentityBinding(
        federation_type=FederationType.github_actions,
        issuer_uri="https://token.actions.githubusercontent.com",
        subject_pattern="repo:acme-org/acme-repo:ref:refs/heads/main",
        max_token_lifetime_seconds=3600,
    )
    token = AiCapabilityToken(
        name="fed-token",
        agent_uid_ref="nhi.test-agent",
        workload_identity=wi,
        ttl_seconds=1800,
    )
    assert token.workload_identity is not None
    assert token.workload_identity.federation_type == FederationType.github_actions
    assert token.ttl_seconds == 1800


def test_workload_identity_ttl_exceeds_max():
    from dsk.core.models_ai_token import (
        AiCapabilityToken,
        FederationType,
        WorkloadIdentityBinding,
    )

    wi = WorkloadIdentityBinding(
        federation_type=FederationType.github_actions,
        issuer_uri="https://token.actions.githubusercontent.com",
        subject_pattern="repo:acme-org/acme-repo:ref:refs/heads/main",
        max_token_lifetime_seconds=900,
    )
    with pytest.raises(ValidationError):
        AiCapabilityToken(
            name="bad",
            agent_uid_ref="nhi.x",
            workload_identity=wi,
            ttl_seconds=3600,
        )


def test_workload_identity_optional():
    from dsk.core.models_ai_token import AiCapabilityToken

    token = AiCapabilityToken(name="legacy", agent_uid_ref="nhi.legacy")
    assert token.workload_identity is None


def test_token_schema_alias():
    from dsk.core.models_ai_token import AiTokenManifestV1

    m = AiTokenManifestV1(**{"schema": "ai-token.v1", "name": "test"})
    assert m.schema_ == "ai-token.v1"
