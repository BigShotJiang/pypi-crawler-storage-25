"""Tests for SCIM provisioning models."""

import pytest
from pydantic import ValidationError

from dsk.core.diff import ChangeKind
from dsk.core.models_scim import (
    ScimEndpointSpec,
    ScimManifestV1,
    ScimNode,
    ScimRole,
    ScimTeam,
    ScimUser,
)
from dsk.core.scim_diff import compute_scim_diff, scim_apply_order


def test_scim_manifest_defaults() -> None:
    m = ScimManifestV1(name="test")
    assert m.family == "keeper-scim.v1"
    assert m.nodes == []
    assert m.users == []


def test_scim_user_roles_and_teams() -> None:
    user = ScimUser(
        uid_ref="user.alice",
        email="alice@example.com",
        role_uid_refs=["role.admin"],
        team_uid_refs=["team.platform"],
    )
    assert "role.admin" in user.role_uid_refs
    assert "team.platform" in user.team_uid_refs


def test_scim_endpoint_spec_requires_node_id() -> None:
    ScimEndpointSpec(node_id="12345")
    with pytest.raises(ValidationError):
        ScimEndpointSpec.model_validate({"push_type": "all"})


def test_scim_manifest_name_is_required() -> None:
    with pytest.raises(ValidationError):
        ScimManifestV1.model_validate({})


def test_scim_user_can_have_empty_roles_and_teams() -> None:
    user = ScimUser(uid_ref="user.bob", email="bob@example.com")
    assert user.role_uid_refs == []
    assert user.team_uid_refs == []


def test_scim_endpoint_base_is_optional() -> None:
    ScimEndpointSpec(node_id="node-1")


def test_compute_scim_diff_resource_types_for_all_sections() -> None:
    manifest = ScimManifestV1(
        name="offline",
        nodes=[ScimNode(uid_ref="node.a", name="Alpha")],
        roles=[ScimRole(uid_ref="role.a", name="Viewer")],
        teams=[ScimTeam(uid_ref="team.a", name="Crew")],
        users=[ScimUser(uid_ref="user.a", email="a@example.com")],
        endpoints=[ScimEndpointSpec(node_id="999")],
    )
    changes = compute_scim_diff(manifest, live={})
    assert [c.resource_type for c in changes] == [
        "scim_node",
        "scim_role",
        "scim_team",
        "scim_user",
        "scim_push",
    ]
    node_role_team_user_kinds = [c.kind for c in changes[:-1]]
    assert all(k == ChangeKind.CREATE for k in node_role_team_user_kinds)
    assert changes[-1].kind == ChangeKind.UPDATE


def test_scim_apply_order_nodes_roles_teams_users_endpoints() -> None:
    manifest = ScimManifestV1(
        name="order-test",
        nodes=[ScimNode(uid_ref="n1", name="N1"), ScimNode(uid_ref="n2", name="N2")],
        roles=[ScimRole(uid_ref="r1", name="R1")],
        teams=[ScimTeam(uid_ref="t1", name="T1")],
        users=[ScimUser(uid_ref="u1", email="u@example.com")],
        endpoints=[ScimEndpointSpec(node_id="ep-node", uid_ref="ep.fixed")],
    )
    assert scim_apply_order(manifest) == [
        "n1",
        "n2",
        "r1",
        "t1",
        "u1",
        "ep.fixed",
    ]


def test_compute_scim_diff_allow_delete_empty_live_still_emits_non_delete_rows() -> None:
    manifest = ScimManifestV1(
        name="del-flag",
        nodes=[ScimNode(uid_ref="node.only", name="Only")],
    )
    changes = compute_scim_diff(manifest, live={}, allow_delete=True)
    assert len(changes) == 1
    assert changes[0].kind == ChangeKind.CREATE
    assert ChangeKind.DELETE not in [c.kind for c in changes]
