"""Tests for ``dsk import-from-keepercmd``."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner
from keeper_sdk.cli.cmd_import_from_keepercmd import (
    AuditChainCorrupt,
    _check_contract_version,
    _collect_rows,
    _has_ownership_marker,
    _load_signature_pubkey,
    _read_text_artifact,
    _verify_audit_log,
)
from keeper_sdk.cli.main import main
from rich.console import Console

# ---------------------------------------------------------------------------
# helpers


def _make_run_dir(
    tmp_path: Path,
    *,
    rows: list[dict[str, str]] | None = None,
    audit_lines: list[dict[str, Any]] | None = None,
    record_exports: dict[str, dict[str, Any]] | None = None,
    inventory: dict[str, Any] | None = None,
    records_export_dir_name: str = "records-export",
) -> Path:
    run_dir = tmp_path / "keepercmd-run"
    run_dir.mkdir()
    records_export_dir = run_dir / records_export_dir_name
    records_export_dir.mkdir()

    default_rows = [
        {
            "source_uid": "AAAAAAAAAAAAAAAAAAAAAA",
            "target_uid": "BBBBBBBBBBBBBBBBBBBBBB",
            "title": "My Login",
            "type": "login",
            "status": "paired",
            "timestamp": "2026-05-08T18:30:00Z",
        }
    ]
    csv_rows = rows if rows is not None else default_rows
    csv_path = run_dir / "manifest.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        if csv_rows:
            writer = csv.DictWriter(fh, fieldnames=list(csv_rows[0].keys()))
            writer.writeheader()
            writer.writerows(csv_rows)
        else:
            fh.write("source_uid,target_uid,title,type,status,timestamp\n")

    if audit_lines is not None:
        _write_audit_log(run_dir / "audit.log", audit_lines)
    else:
        _write_audit_log(run_dir / "audit.log", [{"event": "run_start", "run_id": "test"}])

    if record_exports:
        for uid, data in record_exports.items():
            (records_export_dir / f"{uid}.json").write_text(json.dumps(data), encoding="utf-8")

    inv = inventory or {
        "schema_version": "1.0",
        "entities": {"records": []},
    }
    (run_dir / "inventory.json").write_text(json.dumps(inv), encoding="utf-8")

    return run_dir


def _write_audit_log(log_path: Path, events: list[dict[str, Any]]) -> None:
    prev_hash = ""
    lines: list[str] = []
    for event in events:
        payload = {**event, "prev_hash": prev_hash}
        check = json.dumps(payload, sort_keys=True)
        sig = hashlib.sha256(check.encode()).hexdigest()
        payload["signature"] = sig
        line = json.dumps(payload)
        lines.append(line)
        prev_hash = hashlib.sha256(line.encode()).hexdigest()
    log_path.write_text("\n".join(lines), encoding="utf-8")


def _run(*args: str) -> Any:
    runner = CliRunner()
    return runner.invoke(
        main,
        ["import-from-keepercmd", *args],
        catch_exceptions=False,
    )


# ---------------------------------------------------------------------------
# unit: _verify_audit_log


def test_verify_audit_log_clean(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "start"}, {"event": "finish"}])
    _verify_audit_log(log_path)


def test_verify_audit_log_empty_lines_ignored(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    events = [{"event": "only"}]
    _write_audit_log(log_path, events)
    content = log_path.read_text()
    log_path.write_text("\n" + content + "\n\n")
    _verify_audit_log(log_path)


def test_verify_audit_log_zero_verifiable_entries_fails_closed(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    log_path.write_bytes(b"\x1c")

    with pytest.raises(AuditChainCorrupt, match="no verifiable entries"):
        _verify_audit_log(log_path)


def test_verify_audit_log_corrupt_signature(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "ok"}])
    raw = json.loads(log_path.read_text().strip())
    raw["signature"] = "deadbeef" * 8
    log_path.write_text(json.dumps(raw))
    with pytest.raises(AuditChainCorrupt, match="signature mismatch"):
        _verify_audit_log(log_path)


def test_verify_audit_log_missing_signature(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    payload = {"event": "test", "prev_hash": ""}
    log_path.write_text(json.dumps(payload))
    with pytest.raises(AuditChainCorrupt, match="missing signature field"):
        _verify_audit_log(log_path)


def test_verify_audit_log_prev_hash_mismatch(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    _write_audit_log(log_path, [{"event": "a"}, {"event": "b"}])
    lines = log_path.read_text().splitlines()
    # Mutate first line's content (add extra field) and re-sign so line 1 is valid
    # but its hash changes, breaking line 2's prev_hash reference.
    first = json.loads(lines[0])
    first["extra"] = "injected"
    payload = {k: v for k, v in first.items() if k != "signature"}
    first["signature"] = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    modified_line = json.dumps(first)
    log_path.write_text(modified_line + "\n" + lines[1])
    with pytest.raises(AuditChainCorrupt, match="prev_hash mismatch"):
        _verify_audit_log(log_path)


def test_verify_audit_log_malformed_json(tmp_path: Path) -> None:
    log_path = tmp_path / "audit.log"
    log_path.write_text("not json\n")
    with pytest.raises(AuditChainCorrupt, match="malformed JSON"):
        _verify_audit_log(log_path)


def test_read_text_artifact_accepts_at_byte_cap(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    artifact = tmp_path / "artifact.txt"
    artifact.write_text("abcd", encoding="utf-8")
    monkeypatch.setenv("DSK_MAX_ARTIFACT_BYTES", "4")

    assert _read_text_artifact(artifact) == "abcd"


def test_read_text_artifact_rejects_just_over_byte_cap(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    artifact = tmp_path / "artifact.txt"
    artifact.write_text("abcde", encoding="utf-8")
    monkeypatch.setenv("DSK_MAX_ARTIFACT_BYTES", "4")

    with pytest.raises(ImportError, match="DSK_MAX_ARTIFACT_BYTES=4"):
        _read_text_artifact(artifact)


def test_read_text_artifact_rejects_symlink(tmp_path: Path) -> None:
    target = tmp_path / "target.txt"
    target.write_text("ok", encoding="utf-8")
    link = tmp_path / "artifact.txt"
    link.symlink_to(target)

    with pytest.raises(ImportError, match="symlink"):
        _read_text_artifact(link)


def test_inventory_json_accepts_at_depth_cap(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    run_dir = _make_run_dir(tmp_path)
    monkeypatch.setenv("DSK_MAX_ARTIFACT_DEPTH", "3")

    _check_contract_version(run_dir, Console())


def test_inventory_json_rejects_just_over_depth_cap(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    run_dir = _make_run_dir(
        tmp_path,
        inventory={"schema_version": "1.0", "entities": {"records": [{"nested": {"too": "deep"}}]}},
    )
    monkeypatch.setenv("DSK_MAX_ARTIFACT_DEPTH", "4")

    with pytest.raises(ImportError, match="DSK_MAX_ARTIFACT_DEPTH=4"):
        _check_contract_version(run_dir, Console())


def test_signature_pubkey_file_accepts_at_byte_cap(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    pubkey = tmp_path / "minisign.pub"
    pubkey.write_text("abcd", encoding="utf-8")
    monkeypatch.setenv("DSK_SIGNATURE_PUBKEY_MAX_BYTES", "4")

    assert _load_signature_pubkey(pubkey, None) == "abcd"


def test_signature_pubkey_file_rejects_just_over_byte_cap(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    pubkey = tmp_path / "minisign.pub"
    pubkey.write_text("abcde", encoding="utf-8")
    monkeypatch.setenv("DSK_SIGNATURE_PUBKEY_MAX_BYTES", "4")

    with pytest.raises(ImportError, match="DSK_SIGNATURE_PUBKEY_MAX_BYTES=4"):
        _load_signature_pubkey(pubkey, None)


# ---------------------------------------------------------------------------
# unit: _has_ownership_marker


def test_has_ownership_marker_present() -> None:
    record = {"custom": [{"label": "keeper_declarative_manager", "value": ["{}"], "type": "text"}]}
    assert _has_ownership_marker(record) is True


def test_has_ownership_marker_present_with_keeper_type_label_form() -> None:
    record = {
        "custom": [{"label": "$text:keeper_declarative_manager", "value": ["{}"], "type": "text"}]
    }
    assert _has_ownership_marker(record) is True


def test_has_ownership_marker_absent() -> None:
    record = {"custom": [{"label": "other_field", "value": ["x"], "type": "text"}]}
    assert _has_ownership_marker(record) is False


def test_has_ownership_marker_no_custom() -> None:
    assert _has_ownership_marker({}) is False


# ---------------------------------------------------------------------------
# unit: _collect_rows


def test_collect_rows_paired_only(tmp_path: Path) -> None:
    from rich.console import Console

    records_export = tmp_path / "records-export"
    records_export.mkdir()
    rows = [
        {
            "source_uid": "SRC1",
            "target_uid": "TGT1",
            "title": "A",
            "type": "login",
            "status": "paired",
            "timestamp": "",
        },
        {
            "source_uid": "SRC2",
            "target_uid": "",
            "title": "B",
            "type": "login",
            "status": "unpaired",
            "timestamp": "",
        },
        {
            "source_uid": "SRC3",
            "target_uid": "TGT3",
            "title": "C",
            "type": "login",
            "status": "ambiguous",
            "timestamp": "",
        },
        {
            "source_uid": "SRC4",
            "target_uid": "",
            "title": "D",
            "type": "login",
            "status": "skipped",
            "timestamp": "",
        },
    ]
    console = Console()
    paired, unpaired_count, skipped_count = _collect_rows(rows, records_export, False, console)
    assert len(paired) == 1
    assert paired[0].source_uid == "SRC1"
    assert paired[0].target_uid == "TGT1"
    assert unpaired_count == 2
    assert skipped_count == 1


def test_collect_rows_suspect_detection(tmp_path: Path) -> None:
    from rich.console import Console

    records_export = tmp_path / "records-export"
    records_export.mkdir()
    export_data = {
        "custom": [
            {
                "label": "keeper_declarative_manager",
                "value": ['{"manager":"keeper-pam-declarative"}'],
                "type": "text",
            }
        ]
    }
    (records_export / "SRCMARKED.json").write_text(json.dumps(export_data), encoding="utf-8")
    rows = [
        {
            "source_uid": "SRCMARKED",
            "target_uid": "TGT1",
            "title": "Marked",
            "type": "login",
            "status": "paired",
            "timestamp": "",
        },
        {
            "source_uid": "SRCCLEAN",
            "target_uid": "TGT2",
            "title": "Clean",
            "type": "login",
            "status": "paired",
            "timestamp": "",
        },
    ]
    console = Console()
    paired, _, _ = _collect_rows(rows, records_export, False, console)
    assert len(paired) == 2
    suspect_rows = [r for r in paired if r.suspect]
    assert len(suspect_rows) == 1
    assert suspect_rows[0].source_uid == "SRCMARKED"
    assert not any(r.suspect for r in paired if r.source_uid == "SRCCLEAN")


# ---------------------------------------------------------------------------
# CLI integration


def test_missing_manifest_csv(tmp_path: Path) -> None:
    run_dir = tmp_path / "empty-run"
    run_dir.mkdir()
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 1
    assert "manifest.csv" in result.output


def test_corrupt_audit_log_aborts(tmp_path: Path) -> None:
    run_dir = _make_run_dir(tmp_path, audit_lines=None)
    run_dir_path = run_dir
    (run_dir_path / "audit.log").write_text(
        '{"event": "bad", "prev_hash": "", "signature": "wrong"}'
    )
    result = _run(str(run_dir_path), "--skip-sha256")
    assert result.exit_code == 5
    assert "corrupt" in result.output.lower() or "signature" in result.output.lower()


def test_skip_audit_verify_ignores_bad_log(tmp_path: Path) -> None:
    run_dir = _make_run_dir(tmp_path)
    (run_dir / "audit.log").write_text("not json\n")
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 0


def test_dry_run_shows_summary_no_errors(tmp_path: Path) -> None:
    run_dir = _make_run_dir(tmp_path)
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 0
    assert "1" in result.output


def test_dry_run_accepts_keepercmd_records_export_underscore(tmp_path: Path) -> None:
    run_dir = _make_run_dir(tmp_path, records_export_dir_name="records_export")
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 0
    assert "1" in result.output


def test_dry_run_unpaired_rows_skipped(tmp_path: Path) -> None:
    rows = [
        {
            "source_uid": "AAA",
            "target_uid": "BBB",
            "title": "Paired",
            "type": "login",
            "status": "paired",
            "timestamp": "",
        },
        {
            "source_uid": "CCC",
            "target_uid": "",
            "title": "Unpaired",
            "type": "login",
            "status": "unpaired",
            "timestamp": "",
        },
        {
            "source_uid": "DDD",
            "target_uid": "EEE",
            "title": "Ambiguous",
            "type": "login",
            "status": "ambiguous",
            "timestamp": "",
        },
    ]
    run_dir = _make_run_dir(tmp_path, rows=rows)
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 0
    assert "1" in result.output


def test_suspect_marker_detection_threshold_exceeded(tmp_path: Path) -> None:
    export_data = {
        "custom": [{"label": "keeper_declarative_manager", "value": ["{}"], "type": "text"}]
    }
    run_dir = _make_run_dir(
        tmp_path,
        record_exports={"AAAAAAAAAAAAAAAAAAAAAA": export_data},
    )
    result = _run(
        str(run_dir),
        "--skip-audit-verify",
        "--skip-sha256",
        "--dry-run",
        "--suspect-threshold",
        "0",
    )
    assert result.exit_code == 5
    assert "suspect" in result.output.lower()


def test_suspect_marker_above_threshold_allowed(tmp_path: Path) -> None:
    export_data = {
        "custom": [{"label": "keeper_declarative_manager", "value": ["{}"], "type": "text"}]
    }
    run_dir = _make_run_dir(
        tmp_path,
        record_exports={"AAAAAAAAAAAAAAAAAAAAAA": export_data},
    )
    result = _run(
        str(run_dir),
        "--skip-audit-verify",
        "--skip-sha256",
        "--dry-run",
        "--suspect-threshold",
        "5",
    )
    assert result.exit_code == 0


def test_dry_run_output_yaml(tmp_path: Path) -> None:
    import yaml

    run_dir = _make_run_dir(tmp_path)
    out_file = tmp_path / "adoption.yaml"
    result = _run(
        str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run", "--output", str(out_file)
    )
    assert result.exit_code == 0
    assert out_file.exists()
    doc = yaml.safe_load(out_file.read_text())
    assert doc["schema"] == "keeper-vault.v1"
    assert len(doc["records"]) == 1
    rec = doc["records"][0]
    assert rec["keeper_uid"] == "BBBBBBBBBBBBBBBBBBBBBB"
    assert rec["title"] == "My Login"


def test_dry_run_output_directory_exits_cleanly(tmp_path: Path) -> None:
    run_dir = _make_run_dir(tmp_path)
    result = _run(
        str(run_dir),
        "--skip-audit-verify",
        "--skip-sha256",
        "--dry-run",
        "--output",
        str(tmp_path),
    )
    assert result.exit_code == 1
    assert "cannot write manifest YAML" in result.output


def test_no_paired_rows_exits_cleanly(tmp_path: Path) -> None:
    rows = [
        {
            "source_uid": "AAA",
            "target_uid": "",
            "title": "Unpaired",
            "type": "login",
            "status": "unpaired",
            "timestamp": "",
        },
    ]
    run_dir = _make_run_dir(tmp_path, rows=rows)
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 0
    assert "no paired" in result.output.lower()


def test_command_registered_in_main() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["import-from-keepercmd", "--help"], catch_exceptions=False)
    assert result.exit_code == 0
    assert "keeperCMD" in result.output or "keepercmd" in result.output.lower()


def test_dry_run_writes_markers_not_called(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import keeper_sdk.cli.cmd_import_from_keepercmd as mod

    calls: list[Any] = []

    def fake_write_markers(paired, manifest_name, console, verbose):
        calls.append(paired)
        return []

    monkeypatch.setattr(mod, "_write_markers", fake_write_markers)
    run_dir = _make_run_dir(tmp_path)
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 0
    assert calls == []


# ---------------------------------------------------------------------------
# Phase 4-F: _contract_version defensive consumer check


def test_contract_version_absent_defaults_to_v1(tmp_path: Path) -> None:
    """inventory.json with no _contract_version should succeed (defaults to v1.0)."""
    inv = {"schema_version": "1.0", "entities": {"records": []}}
    run_dir = _make_run_dir(tmp_path, inventory=inv)
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 0


def test_contract_version_v1_1_accepted(tmp_path: Path) -> None:
    """inventory.json with _contract_version: "1.1" should succeed and print info."""
    inv = {"schema_version": "1.0", "_contract_version": "1.1", "entities": {"records": []}}
    run_dir = _make_run_dir(tmp_path, inventory=inv)
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code == 0
    assert "1.1" in result.output


def test_contract_version_v2_unsupported_aborts(tmp_path: Path) -> None:
    """inventory.json with _contract_version: "2.0" should exit non-zero with clear message."""
    inv = {"schema_version": "1.0", "_contract_version": "2.0", "entities": {"records": []}}
    run_dir = _make_run_dir(tmp_path, inventory=inv)
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--dry-run")
    assert result.exit_code != 0
    assert "not supported" in result.output


def test_auto_approve_calls_write_markers(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import keeper_sdk.cli.cmd_import_from_keepercmd as mod

    adopted: list[str] = []

    def fake_write_markers(paired, manifest_name, console, verbose):
        adopted.extend(r.target_uid for r in paired)
        return [
            {
                "source_uid": r.source_uid,
                "target_uid": r.target_uid,
                "title": r.title,
                "status": "adopted",
            }
            for r in paired
        ]

    monkeypatch.setattr(mod, "_write_markers", fake_write_markers)
    run_dir = _make_run_dir(tmp_path)
    result = _run(str(run_dir), "--skip-audit-verify", "--skip-sha256", "--auto-approve")
    assert result.exit_code == 0
    assert "BBBBBBBBBBBBBBBBBBBBBB" in adopted


# ---------------------------------------------------------------------------
# Phase 4-G: custom record type auto-manifest generation
# ---------------------------------------------------------------------------


def test_custom_type_generates_manifest_entry(tmp_path: Path) -> None:
    """A custom/admin-defined record type must generate a manifest entry, not an error."""
    import yaml

    rows = [
        {
            "source_uid": "CUSTOMSRCAAAAAAAAAAAAAA",
            "target_uid": "CUSTOMTGTBBBBBBBBBBBBB",
            "title": "My Custom Vault Record",
            "type": "myCustomVaultType",
            "status": "paired",
            "timestamp": "2026-05-09T10:00:00Z",
        }
    ]
    run_dir = _make_run_dir(tmp_path, rows=rows)
    out_file = tmp_path / "custom_adoption.yaml"
    result = _run(
        str(run_dir),
        "--skip-audit-verify",
        "--skip-sha256",
        "--dry-run",
        "--output",
        str(out_file),
    )

    # Custom type is expected behaviour — must not be an error
    assert result.exit_code == 0, f"unexpected exit: {result.output}"

    # Must emit info, not warn
    assert "info:" in result.output.lower(), f"expected 'info:' in output, got: {result.output!r}"
    assert "warn:" not in result.output.lower(), f"unexpected 'warn:' in output: {result.output!r}"

    # Manifest file must be generated
    assert out_file.exists(), "manifest YAML was not written"
    doc = yaml.safe_load(out_file.read_text())
    assert doc["schema"] == "keeper-vault.v1"
    records = doc["records"]
    assert len(records) == 1
    rec = records[0]
    assert rec["type"] == "myCustomVaultType"
    assert rec["keeper_uid"] == "CUSTOMTGTBBBBBBBBBBBBB"
    assert rec["title"] == "My Custom Vault Record"
    # fields must be present and empty so dsk plan can track the record
    assert "fields" in rec
    assert rec["fields"] == []


def test_custom_type_passes_schema_validation(tmp_path: Path) -> None:
    """A manifest with a custom record type must pass validate_manifest / load_vault_manifest."""
    import yaml

    from dsk.core.vault_models import load_vault_manifest

    manifest = {
        "schema": "keeper-vault.v1",
        "records": [
            {
                "uid_ref": "custom.myCustomType.SRC1",
                "type": "myCustomType",
                "title": "Custom Record",
                "fields": [],
            }
        ],
    }
    manifest_path = tmp_path / "custom.yaml"
    manifest_path.write_text(yaml.safe_dump(manifest), encoding="utf-8")

    loaded = yaml.safe_load(manifest_path.read_text())
    # Must not raise
    result = load_vault_manifest(loaded)
    assert len(result.records) == 1
    assert result.records[0].type == "myCustomType"


# ---------------------------------------------------------------------------
# Phase 4-H: --commander-config live custom type field resolution
# ---------------------------------------------------------------------------


def test_fetch_custom_type_fields_returns_empty_without_commander(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When keepercommander is not installed, returns [] without raising."""
    import builtins

    real_import = builtins.__import__

    def mock_import(name: str, *args: object, **kwargs: object) -> object:
        if name == "keepercommander" or name.startswith("keepercommander."):
            raise ImportError("No module named 'keepercommander'")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", mock_import)

    from dsk.cli.cmd_import_from_keepercmd import _fetch_custom_type_fields

    result = _fetch_custom_type_fields(Path("/dev/null"), "myCustomType")
    assert result == []


def test_fetch_custom_type_fields_populates_from_cache(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """When Commander is available and the type is cached, returns field dicts."""
    from unittest.mock import MagicMock, patch

    config_path = tmp_path / "config.json"
    config_path.write_text("{}", encoding="utf-8")

    mock_field = MagicMock()
    mock_field.field_type = "login"
    mock_field.label = "Username"

    mock_type_info = MagicMock()
    mock_type_info.fields = [mock_field]

    mock_params_instance = MagicMock()
    mock_params_instance.record_type_cache = {"myCustomType": mock_type_info}

    mock_params_module = MagicMock()
    mock_params_module.KeeperParams.return_value = mock_params_instance

    mock_api = MagicMock()
    mock_api.login.return_value = None
    mock_api.sync_down.return_value = None

    mock_keepercommander = MagicMock()

    modules = {
        "keepercommander": mock_keepercommander,
        "keepercommander.api": mock_api,
        "keepercommander.params": mock_params_module,
    }
    with patch.dict("sys.modules", modules):
        # Reload the function so the lazy import sees our mocks
        import importlib

        import dsk.cli.cmd_import_from_keepercmd as mod

        importlib.reload(mod)
        result = mod._fetch_custom_type_fields(config_path, "myCustomType")

    assert isinstance(result, list)
    assert len(result) >= 1
    assert result[0]["type"] == "login"
    assert result[0].get("label") == "Username"


def test_import_with_commander_config_populates_fields(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """--commander-config causes custom type fields to be populated in the output YAML."""
    from unittest.mock import MagicMock, patch

    import yaml

    config_file = tmp_path / "keeper_config.json"
    config_file.write_text("{}", encoding="utf-8")

    mock_field = MagicMock()
    mock_field.field_type = "login"
    mock_field.label = "Username"

    mock_type_info = MagicMock()
    mock_type_info.fields = [mock_field]

    mock_params_instance = MagicMock()
    mock_params_instance.record_type_cache = {"myCustomVaultType": mock_type_info}

    mock_params_module = MagicMock()
    mock_params_module.KeeperParams.return_value = mock_params_instance

    mock_api = MagicMock()
    mock_api.login.return_value = None
    mock_api.sync_down.return_value = None

    mock_keepercommander = MagicMock()

    rows = [
        {
            "source_uid": "CUSTOMSRCAAAAAAAAAAAAAA",
            "target_uid": "CUSTOMTGTBBBBBBBBBBBBB",
            "title": "My Custom Vault Record",
            "type": "myCustomVaultType",
            "status": "paired",
            "timestamp": "2026-05-09T10:00:00Z",
        }
    ]
    run_dir = _make_run_dir(tmp_path, rows=rows)
    out_file = tmp_path / "out.yaml"

    modules = {
        "keepercommander": mock_keepercommander,
        "keepercommander.api": mock_api,
        "keepercommander.params": mock_params_module,
    }
    with patch.dict("sys.modules", modules):
        import importlib

        import dsk.cli.cmd_import_from_keepercmd as mod

        importlib.reload(mod)

        runner = __import__("click.testing", fromlist=["CliRunner"]).CliRunner()
        from dsk.cli.main import main as dsk_main

        result = runner.invoke(
            dsk_main,
            [
                "import-from-keepercmd",
                str(run_dir),
                "--skip-audit-verify",
                "--skip-sha256",
                "--dry-run",
                "--output",
                str(out_file),
                "--commander-config",
                str(config_file),
            ],
            catch_exceptions=False,
        )

    assert result.exit_code == 0, f"unexpected exit: {result.output}"
    assert out_file.exists()
    doc = yaml.safe_load(out_file.read_text())
    records = doc["records"]
    assert len(records) == 1
    assert records[0].get("fields") not in (None, [])


def test_import_without_commander_config_leaves_fields_empty(tmp_path: Path) -> None:
    """Without --commander-config, custom type manifests have fields: []."""
    import yaml

    rows = [
        {
            "source_uid": "CUSTOMSRCAAAAAAAAAAAAAA",
            "target_uid": "CUSTOMTGTBBBBBBBBBBBBB",
            "title": "My Custom Vault Record",
            "type": "myCustomVaultType",
            "status": "paired",
            "timestamp": "2026-05-09T10:00:00Z",
        }
    ]
    run_dir = _make_run_dir(tmp_path, rows=rows)
    out_file = tmp_path / "out.yaml"
    result = _run(
        str(run_dir),
        "--skip-audit-verify",
        "--skip-sha256",
        "--dry-run",
        "--output",
        str(out_file),
    )
    assert result.exit_code == 0, f"unexpected exit: {result.output}"
    assert out_file.exists()
    doc = yaml.safe_load(out_file.read_text())
    records = doc["records"]
    assert len(records) == 1
    assert records[0].get("fields") == []


# ---------------------------------------------------------------------------
# Phase 4-E: custom record type passthrough edge cases
# ---------------------------------------------------------------------------


class TestPhase4ECustomTypeEdgeCases:
    """Edge cases for ``_normalise_record_type`` and custom manifest YAML (Phase 4-E)."""

    def test_custom_type_with_unicode_name_passes_through(self) -> None:
        """Unicode in admin-defined type names must not raise."""
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type

        t, is_custom = _normalise_record_type("café_record_型")
        assert t == "café_record_型"
        assert is_custom is True

    def test_custom_type_with_empty_string_treated_as_login(self) -> None:
        """Empty *raw* falls back to ``login`` (falsy guard), not custom."""
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type

        t, is_custom = _normalise_record_type("")
        assert t == "login"
        assert is_custom is False

    def test_custom_type_with_whitespace_normalised(self) -> None:
        """Leading and trailing whitespace is stripped before alias/custom resolution."""
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type

        t, is_custom = _normalise_record_type("  myType  ")
        assert t == "myType"
        assert is_custom is True

    def test_custom_type_with_special_chars_passes_through(self) -> None:
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type

        t, is_custom = _normalise_record_type("type-with_underscore.dot")
        assert t == "type-with_underscore.dot"
        assert is_custom is True

    def test_pam_type_case_insensitive_block(self) -> None:
        """Mixed-case PAM labels map to canonical Keeper camelCase and are not custom."""
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type

        t, is_custom = _normalise_record_type("PamMachine")
        assert t == "pamMachine"
        assert is_custom is False

    def test_pam_type_with_extra_whitespace_blocked(self) -> None:
        """Whitespace around a PAM type name is stripped; canonical form is returned."""
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type

        t, is_custom = _normalise_record_type("  pamMachine  ")
        assert t == "pamMachine"
        assert is_custom is False

    def test_custom_type_yaml_comment_includes_admin_defined_marker(self) -> None:
        """Custom entries prepend a YAML comment mentioning *custom* (open schema)."""
        from dsk.cli.cmd_import_from_keepercmd import _AdoptionRow, _build_manifest_yaml

        paired = [
            _AdoptionRow(
                source_uid="SRCUIDAAAAAAAAAAAAAA",
                target_uid="TGTUIDBBBBBBBBBBBBBB",
                title="t",
                record_type="adminSpecial",
                suspect=False,
            )
        ]
        yaml_text = _build_manifest_yaml(paired, "adoption", commander_config=None)
        assert "custom" in yaml_text or "admin" in yaml_text

    def test_native_l2_type_not_marked_custom(self) -> None:
        """Every L2-typed native record name is supported (not custom)."""
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type
        from dsk.core.vault_models import VAULT_L2_TYPED_RECORD_TYPES

        for name in VAULT_L2_TYPED_RECORD_TYPES:
            _t, is_custom = _normalise_record_type(name)
            assert is_custom is False, f"expected native L2 type {name!r} to be supported"

    def test_alias_resolves_before_custom_check(self) -> None:
        """Alias `secureNote` resolves to native ``generalNote``."""
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type

        t, is_custom = _normalise_record_type("secureNote")
        assert t == "generalNote"
        assert is_custom is False

    def test_known_login_alias_not_marked_custom(self) -> None:
        """All Commander alias keys map to supported types."""
        from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type
        from dsk.core.vault_models import _VAULT_RECORD_TYPE_ALIASES

        for key in _VAULT_RECORD_TYPE_ALIASES:
            _t, is_custom = _normalise_record_type(key)
            assert is_custom is False, f"alias key {key!r} should resolve to a supported type"
