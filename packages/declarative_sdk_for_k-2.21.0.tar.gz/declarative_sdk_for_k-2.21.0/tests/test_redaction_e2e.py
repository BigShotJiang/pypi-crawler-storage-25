"""
Cross-process redaction tests ensuring DSK never emits secrets to stdout/stderr.

These run as NEW-H1 regression guards from the 2026-05-10 pentest sweep.
"""

from __future__ import annotations

import ast
import asyncio
import json
import logging
import os
import subprocess
import sys
from pathlib import Path

import pytest

from dsk._obs import JSONFormatter
from dsk.mcp.server import JsonRpcMcpServer

REPO_ROOT = Path(__file__).resolve().parents[1]
SECRET_SCHEMA_VALUE = "SUPER_SECRET_VALUE_12345"
SECRET_PLAN_VALUE = "JSON_PLAN_SECRET_67890"
SECRET_RUNTIME_VALUE = "hunter2"
SECRET_LOG_VALUE = "LOG_SECRET_VALUE_12345"


def _cli_env() -> dict[str, str]:
    env = dict(os.environ)
    existing = env.get("PYTHONPATH")
    env["PYTHONPATH"] = str(REPO_ROOT) if not existing else f"{REPO_ROOT}{os.pathsep}{existing}"
    return env


def _run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "dsk.cli", *args],
        cwd=REPO_ROOT,
        env=_cli_env(),
        capture_output=True,
        text=True,
        check=False,
    )


def _assert_no_secret_output(result: subprocess.CompletedProcess[str], *secrets: str) -> None:
    combined = f"{result.stdout}\n{result.stderr}"
    for secret in secrets:
        assert secret not in combined
    assert "Traceback (most recent call last)" not in combined


def test_validate_error_no_secret_echo(tmp_path: Path) -> None:
    manifest = tmp_path / "secret.yaml"
    manifest.write_text(
        f"""
schema: keeper-vault.v1
records:
  - uid_ref: rec.secret
    type: login
    title: Secret Login
    fields:
      - type: password
        value: {SECRET_SCHEMA_VALUE}
""",
        encoding="utf-8",
    )

    result = _run_cli("validate", str(manifest))

    assert result.returncode == 2
    _assert_no_secret_output(result, SECRET_SCHEMA_VALUE)


def test_plan_error_no_raw_traceback_with_secrets(tmp_path: Path) -> None:
    manifest = tmp_path / "bad.yaml"
    manifest.write_text(
        f"""
schema: keeper-vault.v1
records:
  - uid_ref: rec.secret
    type: login
    title: Secret Login
    fields:
      - type: password
        value: {SECRET_RUNTIME_VALUE}
""",
        encoding="utf-8",
    )

    result = _run_cli("plan", str(manifest), "--format", "json")

    assert result.returncode == 2
    _assert_no_secret_output(result, SECRET_RUNTIME_VALUE)


def test_plan_json_output_redacts_sensitive_record_fields(tmp_path: Path) -> None:
    help_result = _run_cli("plan", "--help")
    if "--format" not in help_result.stdout:
        pytest.skip("plan --format json not supported")
    manifest = tmp_path / "vault.yaml"
    manifest.write_text(
        f"""
schema: keeper-vault.v1
records:
  - uid_ref: rec.login
    type: login
    title: Login
    fields:
      - type: login
        value: [alice@example.com]
      - type: password
        value: [{SECRET_PLAN_VALUE}]
""",
        encoding="utf-8",
    )

    result = _run_cli("--provider", "mock", "plan", str(manifest), "--format", "json")

    assert result.returncode == 2
    _assert_no_secret_output(result, SECRET_PLAN_VALUE)
    payload = json.loads(result.stdout)
    encoded = json.dumps(payload)
    assert "***redacted***" in encoded


def test_json_error_response_redacts_exception_text() -> None:
    server = JsonRpcMcpServer("redaction-test")

    @server.tool("boom")
    async def boom() -> str:
        raise RuntimeError(f"secret_key={SECRET_RUNTIME_VALUE}")

    response = asyncio.run(
        server.handle(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {"name": "boom", "arguments": {}},
            }
        )
    )

    encoded = json.dumps(response)
    assert SECRET_RUNTIME_VALUE not in encoded
    assert "***" in encoded


def test_structured_json_logging_redacts_record_fields_and_exceptions() -> None:
    record = logging.LogRecord(
        "dsk.redaction",
        logging.ERROR,
        __file__,
        1,
        f"secret_key={SECRET_RUNTIME_VALUE}",
        (),
        None,
    )
    record.record_fields = {"fields": [{"type": "password", "value": [SECRET_LOG_VALUE]}]}
    try:
        raise RuntimeError(f"password={SECRET_PLAN_VALUE}")
    except RuntimeError:
        record.exc_info = sys.exc_info()

    payload = json.loads(JSONFormatter().format(record))
    encoded = json.dumps(payload)

    for secret in (SECRET_RUNTIME_VALUE, SECRET_LOG_VALUE, SECRET_PLAN_VALUE):
        assert secret not in encoded
    assert payload["record_fields"]["fields"][0]["value"] == ["***redacted***"]


def test_no_builtin_print_outside_cli_or_tests() -> None:
    offenders: list[str] = []
    for path in sorted((REPO_ROOT / "dsk").rglob("*.py")):
        relative = path.relative_to(REPO_ROOT)
        if relative.parts[1:2] == ("cli",):
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(relative))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and _is_builtin_print_call(node):
                offenders.append(f"{relative}:{node.lineno}")

    assert offenders == []


def _is_builtin_print_call(node: ast.Call) -> bool:
    return isinstance(node.func, ast.Name) and node.func.id == "print"
