"""Validation coverage for ``examples/**/*.yaml`` manifests."""

from __future__ import annotations

from pathlib import Path

import pytest

from dsk.core.manifest import read_manifest_document
from dsk.core.schema import validate_manifest

REPO_ROOT = Path(__file__).resolve().parents[1]
EXAMPLES_DIR = REPO_ROOT / "examples"

# Root-level examples (original subset)
EXAMPLE_MANIFESTS: tuple[Path, ...] = tuple(sorted(EXAMPLES_DIR.glob("*.yaml")))

# All examples including subdirectories (broader coverage)
ALL_EXAMPLE_MANIFESTS: tuple[Path, ...] = tuple(sorted(EXAMPLES_DIR.rglob("*.yaml")))


def _example_id(manifest_path: Path) -> str:
    try:
        return str(manifest_path.relative_to(EXAMPLES_DIR))
    except ValueError:
        return manifest_path.name


def test_root_examples_exist() -> None:
    assert len(EXAMPLE_MANIFESTS) >= 10


def test_all_examples_exist() -> None:
    assert len(ALL_EXAMPLE_MANIFESTS) >= 30


@pytest.mark.parametrize("manifest_path", EXAMPLE_MANIFESTS, ids=_example_id)
def test_root_example_validate_manifest_succeeds(manifest_path: Path) -> None:
    document = read_manifest_document(manifest_path)

    family = validate_manifest(document)

    assert family


@pytest.mark.parametrize("manifest_path", ALL_EXAMPLE_MANIFESTS, ids=_example_id)
def test_all_examples_validate_manifest_succeeds(manifest_path: Path) -> None:
    """Every example YAML in any subdirectory must pass JSON Schema validation."""
    document = read_manifest_document(manifest_path)

    family = validate_manifest(document)

    assert family, f"{manifest_path.name} returned empty family"
