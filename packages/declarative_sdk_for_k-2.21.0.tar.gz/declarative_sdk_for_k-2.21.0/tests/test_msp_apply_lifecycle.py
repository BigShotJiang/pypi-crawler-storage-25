"""MSP managed-company lifecycle: planner diff + MockProvider ``apply_msp_plan`` (no live tenant)."""

from __future__ import annotations

from typing import Any

from dsk.core.diff import ChangeKind
from dsk.core.msp_diff import compute_msp_diff
from dsk.core.msp_graph import msp_apply_order
from dsk.core.msp_models import MspManifestV1, load_msp_manifest
from dsk.core.planner import Plan, build_plan
from dsk.providers import MockProvider


def _manifest(*managed_companies: dict[str, Any]) -> MspManifestV1:
    return load_msp_manifest(
        {
            "schema": "msp-environment.v1",
            "name": "msp-lifecycle-test",
            "managed_companies": list(managed_companies),
        }
    )


def _mc(
    name: str,
    *,
    plan: str = "business",
    seats: int = 5,
    file_plan: str | None = None,
) -> dict[str, Any]:
    row: dict[str, Any] = {"name": name, "plan": plan, "seats": seats}
    if file_plan is not None:
        row["file_plan"] = file_plan
    return row


def _plan(
    manifest: MspManifestV1,
    provider: MockProvider,
    *,
    allow_delete: bool = False,
) -> Plan:
    return build_plan(
        manifest.name,
        compute_msp_diff(
            manifest,
            provider.discover_managed_companies(),
            allow_delete=allow_delete,
        ),
        msp_apply_order(manifest),
    )


def test_create_new_mc_business_plan_planner_create_apply_create() -> None:
    """New MC in manifest with Business plan → diff CREATE; apply performs create."""
    provider = MockProvider()
    manifest = _manifest(_mc("BetaCorp", plan="business", seats=3))
    changes = compute_msp_diff(manifest, provider.discover_managed_companies())
    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.CREATE
    assert changes[0].after is not None
    assert changes[0].after.get("plan") == "business"

    outcomes = provider.apply_msp_plan(_plan(manifest, provider))
    assert [o.action for o in outcomes] == ["create"]
    assert provider.discover_managed_companies()[0]["name"] == "BetaCorp"


def test_update_existing_mc_planner_update_includes_field_level_diff() -> None:
    """Seeded MC + desired change → UPDATE with distinct before/after field values."""
    provider = MockProvider()
    provider.seed_managed_companies([_mc("GammaLLC", plan="business", seats=5)])
    manifest = _manifest(_mc("GammaLLC", plan="enterprise", seats=12))
    changes = compute_msp_diff(manifest, provider.discover_managed_companies())
    assert len(changes) == 1
    ch = changes[0]
    assert ch.kind is ChangeKind.UPDATE
    assert ch.before is not None and ch.after is not None
    assert ch.before.get("plan") == "business"
    assert ch.after.get("plan") == "enterprise"
    assert ch.before.get("seats") != ch.after.get("seats")

    outcomes = provider.apply_msp_plan(_plan(manifest, provider))
    assert [o.action for o in outcomes] == ["update"]
    live = provider.discover_managed_companies()[0]
    assert live["plan"] == "enterprise"
    assert live["seats"] == 12


def test_remove_mc_delete_requires_allow_delete_confirmation_gate() -> None:
    """Without allow_delete: SKIP (gate); with allow_delete: DELETE and apply removes row."""
    provider = MockProvider()
    provider.seed_managed_companies([_mc("ZedCo", plan="business", seats=1)])
    empty = _manifest()

    gated = compute_msp_diff(empty, provider.discover_managed_companies(), allow_delete=False)
    assert len(gated) == 1
    assert gated[0].kind is ChangeKind.SKIP
    assert "allow_delete=True" in (gated[0].reason or "")

    outcomes_gated = provider.apply_msp_plan(_plan(empty, provider, allow_delete=False))
    assert [o.action for o in outcomes_gated] == ["noop"]
    assert provider.discover_managed_companies()[0]["name"] == "ZedCo"

    delete_changes = compute_msp_diff(
        empty, provider.discover_managed_companies(), allow_delete=True
    )
    assert len(delete_changes) == 1
    assert delete_changes[0].kind is ChangeKind.DELETE

    outcomes = provider.apply_msp_plan(_plan(empty, provider, allow_delete=True))
    assert [o.action for o in outcomes] == ["delete"]
    assert provider.discover_managed_companies() == []
