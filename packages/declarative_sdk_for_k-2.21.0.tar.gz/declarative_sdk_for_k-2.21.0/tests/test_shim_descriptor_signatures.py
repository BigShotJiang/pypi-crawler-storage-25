"""Verify shim descriptor command parameters match actual Click commands."""

from __future__ import annotations

import importlib

import click
import pytest

from dsk.shim._descriptor import VERB_DESCRIPTORS


def _get_click_command(verb_name: str) -> click.Command:
    verb_to_module_attr = {
        "adopt": ("dsk.cli.cmd_import_from_keepercmd", "import_from_keepercmd_cmd"),
        "plan": ("dsk.cli.main", "plan"),
        "apply": ("dsk.cli.main", "apply"),
        "diff": ("dsk.cli.main", "diff"),
        "verify": ("dsk.cli.cmd_verify", "verify_cmd"),
        "audit_explain": ("dsk.cli.cmd_audit", "audit_explain_cmd"),
        "drift_watch": ("dsk.cli.cmd_drift_watch", "drift_watch_cmd"),
        "rehearse_report": ("dsk.cli.cmd_rehearse_report", "rehearse_report_cmd"),
        "bundle": ("dsk.cli.cmd_bundle", "cmd_bundle"),
        "discover": ("dsk.cli.discover", "discover_cmd"),
    }
    module_name, attr = verb_to_module_attr[verb_name]
    command = getattr(importlib.import_module(module_name), attr)
    assert isinstance(command, click.Command)
    return command


@pytest.mark.parametrize("verb", sorted(VERB_DESCRIPTORS))
def test_descriptor_click_params_match_command(verb: str) -> None:
    descriptor_params = VERB_DESCRIPTORS[verb]["click_params"]
    click_params = [param.name for param in _get_click_command(verb).params]

    assert descriptor_params == click_params
