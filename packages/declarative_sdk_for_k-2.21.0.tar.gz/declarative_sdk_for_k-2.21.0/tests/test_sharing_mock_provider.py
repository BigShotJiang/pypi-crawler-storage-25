"""keeper-vault-sharing.v1 folders + MockProvider apply round-trip tests."""

from __future__ import annotations

from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.interfaces import ApplyOutcome, LiveRecord
from dsk.core.metadata import (
    MANAGER_NAME,
    MARKER_FIELD_LABEL,
    MARKER_VERSION,
    encode_marker,
    serialize_marker,
)
from dsk.core.planner import build_plan
from dsk.core.sharing_diff import (
    _SHARING_FOLDER_RESOURCE,
    _compute_folders_changes,
)
from dsk.core.sharing_models import (
    SHARING_FAMILY,
    SharingManifestV1,
    load_sharing_manifest,
)
from dsk.providers import MockProvider

MANIFEST_NAME = "vault-sharing"


def _folder(
    uid_ref: str = "folder.prod",
    path: str = "/Prod",
    *,
    parent_folder_uid_ref: str | None = None,
    color: str | None = "blue",
) -> dict[str, Any]:
    data: dict[str, Any] = {"uid_ref": uid_ref, "path": path}
    if parent_folder_uid_ref is not None:
        data["parent_folder_uid_ref"] = parent_folder_uid_ref
    if color is not None:
        data["color"] = color
    return data


def _manifest(*folders: dict[str, Any]) -> SharingManifestV1:
    return load_sharing_manifest({"schema": SHARING_FAMILY, "folders": list(folders)})


def _to_live_folders(records: list[LiveRecord]) -> list[dict[str, Any]]:
    return [
        {
            "keeper_uid": record.keeper_uid,
            "resource_type": record.resource_type,
            "title": record.title,
            "payload": dict(record.payload),
            "marker": dict(record.marker) if record.marker else None,
        }
        for record in records
        if record.resource_type == _SHARING_FOLDER_RESOURCE
    ]


def _folder_changes(
    manifest: SharingManifestV1,
    provider: MockProvider,
    *,
    allow_delete: bool = False,
) -> list[Change]:
    return _compute_folders_changes(
        manifest,
        _to_live_folders(provider.discover()),
        manifest_name=MANIFEST_NAME,
        allow_delete=allow_delete,
    )


def _folder_order(manifest: SharingManifestV1) -> list[str]:
    return [folder.uid_ref for folder in manifest.folders]


def _apply_folder_changes(
    provider: MockProvider,
    manifest: SharingManifestV1,
    changes: list[Change],
    *,
    dry_run: bool = False,
) -> list[ApplyOutcome]:
    plan = build_plan(MANIFEST_NAME, changes, _folder_order(manifest))
    return provider.apply_plan(plan, dry_run=dry_run)


def _seed_folder(
    provider: MockProvider,
    uid_ref: str = "folder.prod",
    path: str = "/Prod",
    *,
    manifest_name: str = MANIFEST_NAME,
    manager: str = MANAGER_NAME,
    color: str | None = "blue",
) -> str:
    marker = encode_marker(
        uid_ref=uid_ref,
        manifest=manifest_name,
        resource_type=_SHARING_FOLDER_RESOURCE,
    )
    marker["manager"] = manager
    payload: dict[str, Any] = {
        "uid_ref": uid_ref,
        "path": path,
        "custom_fields": {MARKER_FIELD_LABEL: serialize_marker(marker)},
    }
    if color is not None:
        payload["color"] = color
    keeper_uid = f"live-{uid_ref}"
    provider.seed(
        [
            LiveRecord(
                keeper_uid=keeper_uid,
                title=path,
                resource_type=_SHARING_FOLDER_RESOURCE,
                payload=payload,
                marker=marker,
            )
        ]
    )
    return keeper_uid


def _actionable(changes: list[Change]) -> list[Change]:
    return [change for change in changes if change.kind is not ChangeKind.NOOP]


def test_sharing_mock_empty_manifest_and_live_no_changes_no_outcomes() -> None:
    manifest = _manifest()
    provider = MockProvider(MANIFEST_NAME)

    changes = _folder_changes(manifest, provider)
    outcomes = _apply_folder_changes(provider, manifest, changes)

    assert changes == []
    assert outcomes == []


def test_sharing_mock_create_folder_writes_record_and_marker() -> None:
    manifest = _manifest(_folder())
    provider = MockProvider(MANIFEST_NAME)

    changes = _folder_changes(manifest, provider)
    outcomes = _apply_folder_changes(provider, manifest, changes)
    records = provider.discover()

    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.CREATE
    assert len(outcomes) == 1
    assert outcomes[0].action == "create"
    assert len(records) == 1
    assert records[0].resource_type == _SHARING_FOLDER_RESOURCE
    assert records[0].marker is not None
    assert records[0].marker["manager"] == MANAGER_NAME
    assert records[0].marker["uid_ref"] == "folder.prod"


def test_sharing_mock_create_then_rediff_is_clean() -> None:
    manifest = _manifest(_folder())
    provider = MockProvider(MANIFEST_NAME)

    _apply_folder_changes(provider, manifest, _folder_changes(manifest, provider))
    changes = _folder_changes(manifest, provider)

    assert _actionable(changes) == []


def test_sharing_mock_update_owned_folder_path() -> None:
    manifest = _manifest(_folder(path="/Prod/New"))
    provider = MockProvider(MANIFEST_NAME)
    _seed_folder(provider, path="/Prod")

    changes = _folder_changes(manifest, provider)
    outcomes = _apply_folder_changes(provider, manifest, changes)
    records = provider.discover()

    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.UPDATE
    assert outcomes[0].action == "update"
    assert len(records) == 1
    assert records[0].payload["path"] == "/Prod/New"


def test_sharing_mock_delete_owned_folder_when_allowed() -> None:
    manifest = _manifest()
    provider = MockProvider(MANIFEST_NAME)
    _seed_folder(provider)

    changes = _folder_changes(manifest, provider, allow_delete=True)
    outcomes = _apply_folder_changes(provider, manifest, changes)

    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.DELETE
    assert outcomes[0].action == "delete"
    assert provider.discover() == []


def test_sharing_mock_delete_refused_without_allow_delete() -> None:
    manifest = _manifest()
    provider = MockProvider(MANIFEST_NAME)
    _seed_folder(provider)

    changes = _folder_changes(manifest, provider)
    outcomes = _apply_folder_changes(provider, manifest, changes)

    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.SKIP
    assert (
        changes[0].reason == "managed folder missing from manifest; pass --allow-delete to remove"
    )
    assert outcomes == []
    assert len(provider.discover()) == 1


def test_sharing_mock_unmanaged_folder_is_skipped() -> None:
    manifest = _manifest(_folder())
    provider = MockProvider(MANIFEST_NAME)
    _seed_folder(provider, manager="other-manager")

    changes = _folder_changes(manifest, provider)
    outcomes = _apply_folder_changes(provider, manifest, changes)

    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.SKIP
    assert changes[0].reason == "unmanaged folder"
    assert outcomes == []
    assert len(provider.discover()) == 1


def test_sharing_mock_three_folder_round_trip_then_destroy() -> None:
    manifest = _manifest(
        _folder("folder.prod", "/Prod", color="blue"),
        _folder("folder.eng", "/Engineering", color="green"),
        _folder("folder.ops", "/Operations", color="orange"),
    )
    provider = MockProvider(MANIFEST_NAME)

    create_changes = _folder_changes(manifest, provider)
    create_outcomes = _apply_folder_changes(provider, manifest, create_changes)
    clean_changes = _folder_changes(manifest, provider)

    assert [change.kind for change in create_changes] == [
        ChangeKind.CREATE,
        ChangeKind.CREATE,
        ChangeKind.CREATE,
    ]
    assert [outcome.action for outcome in create_outcomes] == ["create", "create", "create"]
    assert _actionable(clean_changes) == []
    assert len(provider.discover()) == 3

    empty_manifest = _manifest()
    delete_changes = _folder_changes(empty_manifest, provider, allow_delete=True)
    delete_outcomes = _apply_folder_changes(provider, empty_manifest, delete_changes)

    assert [change.kind for change in delete_changes] == [
        ChangeKind.DELETE,
        ChangeKind.DELETE,
        ChangeKind.DELETE,
    ]
    assert [outcome.action for outcome in delete_outcomes] == ["delete", "delete", "delete"]
    assert provider.discover() == []


def test_sharing_mock_dry_run_create_reports_outcome_without_state_change() -> None:
    manifest = _manifest(_folder())
    provider = MockProvider(MANIFEST_NAME)

    changes = _folder_changes(manifest, provider)
    outcomes = _apply_folder_changes(provider, manifest, changes, dry_run=True)

    assert len(outcomes) == 1
    assert outcomes[0].action == "create"
    assert outcomes[0].details["dry_run"] is True
    assert provider.discover() == []


def test_sharing_mock_create_marker_version_matches_core_constant() -> None:
    manifest = _manifest(_folder())
    provider = MockProvider(MANIFEST_NAME)

    _apply_folder_changes(provider, manifest, _folder_changes(manifest, provider))
    [record] = provider.discover()

    assert record.marker is not None
    assert record.marker["version"] == MARKER_VERSION
