"""Tests for manifest.py load_declarative_manifest_string dispatch paths.

Covers the ``if family == "..."`` dispatch blocks for 32 families (lines 355-688).
Also covers dump_manifest JSON/invalid-format paths and UnsupportedFamilyError.
"""

from __future__ import annotations

import pytest

from dsk.core.errors import SchemaError
from dsk.core.manifest import dump_manifest, load_declarative_manifest_string


def _yaml(schema: str, **extra: object) -> str:
    """Build a minimal valid YAML doc for a family."""
    lines = [f"schema: {schema}", "name: test-manifest", "version: '1'", "manager: dsk"]
    for k, v in extra.items():
        lines.append(f"{k}: {v}")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Families with a plain minimal doc (no required extra fields)
# ---------------------------------------------------------------------------
_PLAIN_FAMILIES: list[str] = [
    "keeper-ai-policy.v1",
    "ai-token.v1",
    "cmmc-profile.v1",
    "dora-profile.v1",
    "pqc-policy.v1",
    "itsm-approval-gate.v1",
    "slack-approval-gate.v1",
    "mcp-secrets-binding.v1",
    "workflow-gate.v1",
    "ai-agent-trust-chain.v1",
    "pam-connection-profile.v1",
    "db-access-policy.v1",
    "gateway-ha.v1",
    # keeper-tunnel needs schema-only (additionalProperties:false in some versions)
    "pipeline-ephemeral-environment.v1",
    "cloud-jit.v1",
    "compliance-bundle.v1",
    "cspm-remediation.v1",
    "continuous-evidence-stream.v1",
    "secret-scanner-bridge.v1",
    "keeper-agent-kit.v1",
    "rotation-policy.v1",
    "jit-access.v1",
    "epm-policy.v1",
    # NB: keeper-workflow, keeper-scim, keeper-tunnel, keeper-drive use schema-only
    # or name-only docs tested separately below.
    # keeper-enterprise, keeper-saas-rotation, keeper-privileged-access: same.
]


@pytest.mark.parametrize("family", _PLAIN_FAMILIES)
def test_load_declarative_manifest_string_dispatches_family(family: str) -> None:
    """load_declarative_manifest_string should dispatch and return a typed model."""
    raw = _yaml(family)
    result = load_declarative_manifest_string(raw)
    assert result is not None


def test_load_declarative_manifest_string_spiffe_binding() -> None:
    """spiffe-binding.v1 requires trust_domain."""
    raw = _yaml("spiffe-binding.v1", trust_domain="example.org")
    result = load_declarative_manifest_string(raw)
    assert result is not None


def test_load_declarative_manifest_string_tunnel_schema_only() -> None:
    result = load_declarative_manifest_string("schema: keeper-tunnel.v1\n")
    assert result is not None


def test_load_declarative_manifest_string_drive_schema_only() -> None:
    result = load_declarative_manifest_string("schema: keeper-drive.v1\n")
    assert result is not None


def test_load_declarative_manifest_string_workflow_schema_only() -> None:
    result = load_declarative_manifest_string("schema: keeper-workflow.v1\n")
    assert result is not None


def test_load_declarative_manifest_string_scim_with_name() -> None:
    result = load_declarative_manifest_string("schema: keeper-scim.v1\nname: t\n")
    assert result is not None


def test_load_declarative_manifest_string_enterprise_schema_only() -> None:
    """keeper-enterprise.v1 schema uses additionalProperties:false — only schema key allowed."""
    result = load_declarative_manifest_string("schema: keeper-enterprise.v1\n")
    assert result is not None


def test_load_declarative_manifest_string_saas_rotation_schema_only() -> None:
    result = load_declarative_manifest_string("schema: keeper-saas-rotation.v1\n")
    assert result is not None


def test_load_declarative_manifest_string_privileged_access_schema_only() -> None:
    result = load_declarative_manifest_string("schema: keeper-privileged-access.v1\n")
    assert result is not None


def test_load_declarative_manifest_string_ai_act_profile() -> None:
    """ai-act-profile.v1 dispatches successfully."""
    raw = _yaml("ai-act-profile.v1")
    result = load_declarative_manifest_string(raw)
    assert result is not None


def test_unsupported_family_raises_schema_error() -> None:
    """Unknown family raises SchemaError (unknown family check in validate_manifest)."""
    raw = "schema: totally-unknown-family.v99\nname: x\nversion: '1'\nmanager: dsk\n"
    with pytest.raises(SchemaError):
        load_declarative_manifest_string(raw)


def test_load_declarative_manifest_string_bad_schema_value_raises() -> None:
    """A field with wrong type raises SchemaError from JSON schema validation."""
    raw = "schema: pqc-policy.v1\nname: 999\nversion: '1'\nmanager: dsk\n"
    with pytest.raises(SchemaError):
        load_declarative_manifest_string(raw)


# ---------------------------------------------------------------------------
# dump_manifest: JSON + invalid format paths
# ---------------------------------------------------------------------------
def _minimal_pam_manifest():  # type: ignore[return]
    import yaml

    from dsk.core.models import Manifest

    raw = (
        "version: '1'\n"
        "name: dump-test\n"
        "gateways:\n"
        "  - uid_ref: gw\n"
        "    name: gw\n"
        "    mode: reference_existing\n"
        "pam_configurations:\n"
        "  - uid_ref: cfg\n"
        "    environment: local\n"
        "    gateway_uid_ref: gw\n"
        "resources: []\n"
    )
    return Manifest.model_validate(yaml.safe_load(raw))


def test_dump_manifest_json_format() -> None:
    manifest = _minimal_pam_manifest()
    out = dump_manifest(manifest, fmt="json")
    assert '"name"' in out
    assert "dump-test" in out


def test_dump_manifest_yaml_format() -> None:
    manifest = _minimal_pam_manifest()
    out = dump_manifest(manifest, fmt="yaml")
    assert "dump-test" in out


def test_dump_manifest_invalid_format_raises() -> None:
    manifest = _minimal_pam_manifest()
    with pytest.raises(ValueError, match="unsupported dump format"):
        dump_manifest(manifest, fmt="toml")
