"""Tests for rotation policy manifest models."""

import json
import sys
import types
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from dsk.cli.main import main

EXAMPLE = Path(__file__).parent.parent / "examples/rotation/acme-rotation-policies.yaml"


def test_rotation_policy_defaults():
    from dsk.core.models_rotation import RotationPolicy, RotationScheduleType

    policy = RotationPolicy(name="test-policy")
    assert policy.schedule.type == RotationScheduleType.interval
    assert policy.password.min_length == 20
    assert policy.pause_on_failure is True
    assert policy.applies_to == []


def test_rotation_manifest_round_trip():
    from dsk.core.models_rotation import RotationPolicyManifestV1, RotationScheduleType

    data = yaml.safe_load(EXAMPLE.read_text())
    manifest = RotationPolicyManifestV1(**data)
    assert manifest.schema_ == "rotation-policy.v1"
    assert len(manifest.policies) == 2
    assert manifest.policies[0].schedule.interval_hours == 2160
    assert manifest.policies[1].schedule.type == RotationScheduleType.on_use


def test_rotation_password_min_length_bound():
    from pydantic import ValidationError

    from dsk.core.models_rotation import RotationPasswordPolicy

    with pytest.raises(ValidationError):
        RotationPasswordPolicy(min_length=8)  # below 12 minimum


def test_rotation_schema_alias():
    from dsk.core.models_rotation import RotationPolicyManifestV1

    m = RotationPolicyManifestV1(**{"schema": "rotation-policy.v1", "name": "test"})
    assert m.schema_ == "rotation-policy.v1"


def test_rotation_policy_validate_json_example():
    result = CliRunner().invoke(main, ["validate", str(EXAMPLE), "--json"], catch_exceptions=False)

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["family"] == "rotation-policy.v1"
    assert payload["mode"] == "rotation_policy_offline"
    assert payload["target_count"] == 3


def test_rotation_policy_plan_json_example():
    result = CliRunner().invoke(main, ["plan", str(EXAMPLE), "--json"], catch_exceptions=False)

    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["manifest_name"] == "acme-rotation-policies"
    assert payload["order"] == ["res.db-prod", "res.app-server-prod", "res.break-glass-admin"]
    assert payload["summary"] == {
        "create": 0,
        "update": 3,
        "delete": 0,
        "conflict": 0,
        "noop": 0,
    }
    first = payload["changes"][0]
    assert first["uid_ref"] == "res.db-prod"
    assert first["resource_type"] == "rotation_policy"
    assert first["after"]["record_uid_ref"] == "res.db-prod"
    assert first["after"]["schedule_type"] == "DAILY"
    assert first["after"]["schedule_json"]["intervalCount"] == 90
    assert payload["changes"][2]["after"]["schedule_type"] == "ON_DEMAND"


def test_rotation_policy_commander_fields_validate_and_plan(tmp_path: Path):
    manifest = tmp_path / "rotation.yaml"
    manifest.write_text(
        """\
schema: rotation-policy.v1
name: commander-rotation
policies:
  - name: db-rotation
    applies_to:
      - keeper-vault:records:db-admin
    rotation_profile: general
    config_uid_ref: keeper-pam:configurations:prod
    resource_uid_ref: keeper-pam:resources:db-prod
    password_complexity: "32,2,2,2,2,:'"
    schedule:
      type: configuration
      schedule_config:
        type: DAILY
        utcTime: "02:00"
        intervalCount: 1
""",
        encoding="utf-8",
    )

    validate = CliRunner().invoke(main, ["validate", str(manifest), "--json"], catch_exceptions=False)
    assert validate.exit_code == 0

    result = CliRunner().invoke(main, ["plan", str(manifest), "--json"], catch_exceptions=False)
    assert result.exit_code == 2
    payload = json.loads(result.output)
    after = payload["changes"][0]["after"]
    assert after["rotation_profile"] == "general"
    assert after["config_uid_ref"] == "keeper-pam:configurations:prod"
    assert after["resource_uid_ref"] == "keeper-pam:resources:db-prod"
    assert after["password_complexity"] == "***redacted***"
    assert after["schedule_type"] == "CONFIGURATION"
    assert after["schedule_config"]["type"] == "DAILY"


def test_rotation_policy_rejects_bad_commander_complexity(tmp_path: Path):
    manifest = tmp_path / "rotation.yaml"
    manifest.write_text(
        """\
schema: rotation-policy.v1
name: commander-rotation
policies:
  - name: db-rotation
    applies_to: [db-admin]
    password_complexity: "not-a-complexity"
""",
        encoding="utf-8",
    )

    result = CliRunner().invoke(main, ["validate", str(manifest)], catch_exceptions=False)

    assert result.exit_code == 2
    assert "failed pattern validation" in result.output


def test_commander_rotation_apply_missing_command(monkeypatch: pytest.MonkeyPatch):
    import dsk.providers.commander_cli as commander_cli
    from dsk.core import CapabilityError, Change, ChangeKind, build_plan
    from dsk.providers.commander_cli import CommanderCliProvider

    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: "/usr/bin/keeper")
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.delitem(sys.modules, "keepercommander.commands.discoveryrotation", raising=False)
    original_import = __import__

    def fake_import(name: str, *args: object, **kwargs: object) -> object:
        if name == "keepercommander.commands.discoveryrotation":
            raise ImportError("missing rotation command")
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", fake_import)
    provider = CommanderCliProvider(folder_uid="folder-uid")
    plan = build_plan(
        "rotation",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="pam.user",
                resource_type="rotation_policy",
                title="daily",
                after={"record_uid_ref": "USER_UID", "schedule_type": "ON_DEMAND"},
            )
        ],
        ["pam.user"],
    )

    with pytest.raises(CapabilityError) as exc_info:
        provider.apply_rotation_plan(plan)

    assert "PAMCreateRecordRotationCommand is unavailable" in exc_info.value.reason
    assert "keepercommander.commands.discoveryrotation.PAMCreateRecordRotationCommand" in (
        exc_info.value.next_action or ""
    )


def test_commander_rotation_apply_invokes_command(monkeypatch: pytest.MonkeyPatch):
    import dsk.providers.commander_cli as commander_cli
    from dsk.core import Change, ChangeKind, build_plan
    from dsk.providers.commander_cli import CommanderCliProvider

    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: "/usr/bin/keeper")
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    params = object()
    seen: list[tuple[object, dict[str, object]]] = []

    class _FakeRotationCommand:
        def execute(self, params_arg: object, **kwargs: object) -> None:
            seen.append((params_arg, kwargs))

    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.discoveryrotation",
        types.SimpleNamespace(PAMCreateRecordRotationCommand=_FakeRotationCommand),
    )
    provider = CommanderCliProvider(folder_uid="folder-uid")
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda fn: fn())
    plan = build_plan(
        "rotation",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="pam.user",
                resource_type="rotation_policy",
                title="daily",
                after={
                    "record_uid_ref": "USER_UID",
                    "schedule_type": "DAILY",
                    "schedule_json": {"type": "DAILY", "utcTime": "02:00", "intervalCount": 1},
                    "rotation_profile": "general",
                    "resource_uid_ref": "RES_UID",
                    "config_uid_ref": "CFG_UID",
                    "password_complexity": "32,2,2,2,2",
                    "enabled": True,
                },
            )
        ],
        ["pam.user"],
    )

    outcomes = provider.apply_rotation_plan(plan)

    assert len(outcomes) == 1
    assert outcomes[0].uid_ref == "pam.user"
    assert outcomes[0].keeper_uid == "USER_UID"
    assert outcomes[0].action == "update"
    assert seen == [
        (
            params,
            {
                "record_name": "USER_UID",
                "force": True,
                "schedule_json_data": ['{"type":"DAILY","utcTime":"02:00","intervalCount":1}'],
                "rotation_profile": "general",
                "resource": "RES_UID",
                "config": "CFG_UID",
                "pwd_complexity": "32,2,2,2,2",
                "enable": True,
                "disable": False,
            },
        )
    ]
