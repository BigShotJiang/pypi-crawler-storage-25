"""KSM declarative extras apply coverage without live tenant access."""

from __future__ import annotations

import json
import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.ksm_diff import compute_ksm_diff
from dsk.core.ksm_graph import ksm_apply_order
from dsk.core.models_ksm import load_ksm_manifest
from dsk.core.planner import Plan, build_plan
from dsk.providers import KsmMockProvider, commander_cli
from dsk.providers.commander_cli import CommanderCliProvider
from tests._fakes.commander import FakeKeeperParams, FakeKsmCommand


class _ExtrasKsmCommand(FakeKsmCommand):
    remove_client_calls: list[dict[str, Any]] = []
    remove_all_client_calls: list[dict[str, Any]] = []
    remove_share_calls: list[dict[str, Any]] = []

    @classmethod
    def reset(cls) -> None:
        super().reset()
        cls.remove_client_calls = []
        cls.remove_all_client_calls = []
        cls.remove_share_calls = []

    @classmethod
    def remove_client(
        cls,
        params: FakeKeeperParams,
        app_name_or_uid: str,
        client_names_and_hashes: list[str],
        force: bool = False,
    ) -> None:
        cls.remove_client_calls.append(
            {
                "app_name_or_uid": app_name_or_uid,
                "client_names_and_hashes": list(client_names_and_hashes),
                "force": force,
            }
        )

    @classmethod
    def remove_all_clients(
        cls,
        params: FakeKeeperParams,
        app_name_or_uid: str,
        force: bool,
    ) -> None:
        cls.remove_all_client_calls.append({"app_name_or_uid": app_name_or_uid, "force": force})

    @classmethod
    def remove_share(
        cls,
        params: FakeKeeperParams,
        app_name_or_uid: str,
        secret_uids: list[str],
    ) -> None:
        cls.remove_share_calls.append(
            {
                "app_name_or_uid": app_name_or_uid,
                "secret_uids": list(secret_uids),
            }
        )


def _install_fake_ksm_module(monkeypatch, command: type[Any] = _ExtrasKsmCommand) -> None:
    keepercommander_module = types.ModuleType("keepercommander")
    api_module = types.ModuleType("keepercommander.api")
    commands_module = types.ModuleType("keepercommander.commands")
    ksm_module = types.ModuleType("keepercommander.commands.ksm")
    setattr(keepercommander_module, "__path__", [])
    setattr(commands_module, "__path__", [])
    api_module.sync_down = lambda params: setattr(params, "sync_calls", params.sync_calls + 1)
    setattr(keepercommander_module, "api", api_module)
    setattr(keepercommander_module, "commands", commands_module)
    setattr(commands_module, "ksm", ksm_module)
    ksm_module.KSMCommand = command
    monkeypatch.setitem(sys.modules, "keepercommander", keepercommander_module)
    monkeypatch.setitem(sys.modules, "keepercommander.api", api_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", commands_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.ksm", ksm_module)


def _provider(params: FakeKeeperParams) -> CommanderCliProvider:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    provider._keeper_params = params
    provider._keeper_login_attempted = False
    provider._ksm_app_rows_cache = None
    provider._with_keeper_session_refresh = lambda operation: operation()
    provider._get_keeper_params = lambda: params
    return provider


def _apply(provider: CommanderCliProvider, change: Change, *, dry_run: bool = False):
    return provider.apply_ksm_plan(Plan("ksm", [change], []), dry_run=dry_run)


@pytest.fixture(autouse=True)
def _commander_apply_gate(monkeypatch) -> None:
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    _ExtrasKsmCommand.reset()


def test_ksm_client_model_accepts_registration_defaults() -> None:
    manifest = load_ksm_manifest(
        {
            "schema": "keeper-ksm.v1",
            "apps": [{"uid_ref": "app.api", "name": "API Service"}],
            "clients": [
                {
                    "uid_ref": "client.bootstrap",
                    "app_uid_ref": "keeper-ksm:apps:app.api",
                }
            ],
        }
    )

    assert manifest.clients[0].count == 1
    assert manifest.clients[0].first_access_expires_in_min == 60
    assert ("client.bootstrap", "ksm_client") in manifest.iter_uid_refs()


def test_ksm_mock_provider_applies_client_create_and_replans_noop() -> None:
    manifest = load_ksm_manifest(
        {
            "schema": "keeper-ksm.v1",
            "apps": [{"uid_ref": "app.api", "name": "API Service"}],
            "clients": [
                {
                    "uid_ref": "client.bootstrap",
                    "app_uid_ref": "keeper-ksm:apps:app.api",
                    "name": "bootstrap",
                    "unlock_ip": True,
                }
            ],
        }
    )
    provider = KsmMockProvider("ksm")
    changes = compute_ksm_diff(manifest, provider.discover_ksm_state(), manifest_name="ksm")
    plan = build_plan("ksm", changes, ksm_apply_order(manifest))

    outcomes = provider.apply_ksm_plan(plan)
    replan = build_plan(
        "ksm",
        compute_ksm_diff(manifest, provider.discover_ksm_state(), manifest_name="ksm"),
        ksm_apply_order(manifest),
    )

    assert [outcome.action for outcome in outcomes] == ["create", "create"]
    assert provider.discover_ksm_state()["clients"][0]["uid_ref"] == "client.bootstrap"
    assert replan.is_clean


def test_ksm_mock_provider_deletes_client_when_allowed() -> None:
    manifest = load_ksm_manifest(
        {
            "schema": "keeper-ksm.v1",
            "apps": [{"uid_ref": "app.api", "name": "API Service"}],
        }
    )
    provider = KsmMockProvider("ksm")
    provider.seed_ksm_state(
        {
            "apps": [{"uid_ref": "app.api", "name": "API Service"}],
            "clients": [
                {
                    "uid_ref": "client.bootstrap",
                    "app_uid_ref": "keeper-ksm:apps:app.api",
                    "name": "bootstrap",
                }
            ],
        }
    )
    changes = compute_ksm_diff(
        manifest,
        provider.discover_ksm_state(),
        manifest_name="ksm",
        allow_delete=True,
    )
    plan = build_plan("ksm", changes, ksm_apply_order(manifest))

    provider.apply_ksm_plan(plan)

    assert provider.discover_ksm_state()["clients"] == []


def test_apply_ksm_client_create_calls_add_client_without_exposing_token(monkeypatch) -> None:
    params = FakeKeeperParams()
    params.add_app(uid="APP_UID", title="API Service")
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(params)
    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="client.bootstrap",
        resource_type="ksm_client",
        title="bootstrap",
        after={
            "app_uid_ref": "keeper-ksm:apps:APP_UID",
            "name": "bootstrap",
            "count": 2,
            "unlock_ip": True,
            "first_access_expires_in_min": 30,
            "access_expires_in_min": 120,
            "config_init": "json",
        },
    )

    outcomes = _apply(provider, change)

    assert outcomes[0].action == "create"
    assert _ExtrasKsmCommand.add_client_calls == [
        {
            "app_name_or_uid": "APP_UID",
            "count": 2,
            "unlock_ip": True,
            "first_access_expire_on": 30,
            "access_expire_in_min": 120,
            "client_name": "bootstrap",
            "config_init": "json",
            "silent": True,
            "client_type": 1,
        }
    ]
    assert outcomes[0].details["tokens_created"] == 1
    assert "fake-bootstrap-token" not in json.dumps(outcomes[0].details)


def test_apply_ksm_client_create_dry_run_does_not_call_commander(monkeypatch) -> None:
    params = FakeKeeperParams()
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(params)
    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="client.bootstrap",
        resource_type="ksm_client",
        title="bootstrap",
        after={"app_uid_ref": "keeper-ksm:apps:APP_UID", "name": "bootstrap"},
    )

    outcomes = _apply(provider, change, dry_run=True)

    assert outcomes[0].details["dry_run"] is True
    assert outcomes[0].details["first_access_expire_on"] == 60
    assert _ExtrasKsmCommand.add_client_calls == []


def test_apply_ksm_client_create_requires_app_ref(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="client.bootstrap",
        resource_type="ksm_client",
        title="bootstrap",
        after={"name": "bootstrap"},
    )

    with pytest.raises(CapabilityError) as excinfo:
        _apply(provider, change)

    assert "clients[].app_uid_ref" in (excinfo.value.next_action or "")


def test_apply_ksm_client_delete_calls_remove_client(monkeypatch) -> None:
    params = FakeKeeperParams()
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(params)
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref="client.bootstrap",
        resource_type="ksm_client",
        title="bootstrap",
        keeper_uid="APP_UID|CLIENT_ID",
        before={
            "app_uid_ref": "keeper-ksm:apps:APP_UID",
            "client_id": "CLIENT_ID",
        },
    )

    outcomes = _apply(provider, change)

    assert outcomes[0].action == "delete"
    assert _ExtrasKsmCommand.remove_client_calls == [
        {
            "app_name_or_uid": "APP_UID",
            "client_names_and_hashes": ["CLIENT_ID"],
            "force": True,
        }
    ]


def test_apply_ksm_client_delete_all_uses_remove_all_clients(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref="client.all",
        resource_type="ksm_client",
        title="all clients",
        before={"app_uid_ref": "keeper-ksm:apps:APP_UID", "client_id": "all"},
    )

    _apply(provider, change)

    assert _ExtrasKsmCommand.remove_all_client_calls == [
        {"app_name_or_uid": "APP_UID", "force": True}
    ]
    assert _ExtrasKsmCommand.remove_client_calls == []


def test_apply_ksm_client_delete_requires_identifier(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref="client.missing",
        resource_type="ksm_client",
        title="missing",
        before={"app_uid_ref": "keeper-ksm:apps:APP_UID"},
    )

    with pytest.raises(CapabilityError) as excinfo:
        _apply(provider, change)

    assert "client_id/client_name" in (excinfo.value.next_action or "")


def test_apply_ksm_record_share_delete_calls_remove_share(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref="share:keeper-ksm:apps:app.api:keeper-vault:records:rec.db",
        resource_type="ksm_record_share",
        title="app -> rec",
        keeper_uid="APP_UID|REC_UID",
        before={
            "app_uid_ref": "keeper-ksm:apps:APP_UID",
            "record_uid_ref": "keeper-vault:records:REC_UID",
        },
    )

    outcomes = _apply(provider, change)

    assert outcomes[0].action == "delete"
    assert _ExtrasKsmCommand.remove_share_calls == [
        {"app_name_or_uid": "APP_UID", "secret_uids": ["REC_UID"]}
    ]


def test_apply_ksm_record_share_delete_dry_run_resolves_shared_folder_ref(
    monkeypatch,
) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref="share:keeper-ksm:apps:app.api:keeper-vault:shared-folders:sf.ops",
        resource_type="ksm_record_share",
        title="app -> shared folder",
        before={
            "app_uid_ref": "keeper-ksm:apps:APP_UID",
            "shared_folder_uid_ref": "keeper-vault:shared-folders:SF_UID",
        },
    )

    outcomes = _apply(provider, change, dry_run=True)

    assert outcomes[0].details == {
        "dry_run": True,
        "app_uid": "APP_UID",
        "secret_uid": "SF_UID",
    }
    assert _ExtrasKsmCommand.remove_share_calls == []


def test_apply_ksm_record_share_delete_requires_secret_uid(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref="share.missing",
        resource_type="ksm_record_share",
        title="missing",
        before={"app_uid_ref": "keeper-ksm:apps:APP_UID"},
    )

    with pytest.raises(CapabilityError) as excinfo:
        _apply(provider, change)

    assert "app and secret UIDs" in excinfo.value.reason


def test_ksm_client_update_rotation_reports_missing_commander_rotate(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="client.bootstrap",
        resource_type="ksm_client",
        title="bootstrap",
        before={"app_uid_ref": "keeper-ksm:apps:APP_UID", "client_id": "CLIENT_ID"},
        after={"rotate": True},
    )

    with pytest.raises(CapabilityError) as excinfo:
        _apply(provider, change)

    assert "`secrets-manager client rotate`" in (excinfo.value.next_action or "")


def test_ksm_access_record_update_reports_missing_ip_update(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="access.api",
        resource_type="ksm_access_record",
        title="access",
        before={"allowed_ips": ["198.51.100.10/32"]},
        after={"allowed_ips": ["198.51.100.11/32"]},
    )

    with pytest.raises(CapabilityError) as excinfo:
        _apply(provider, change)

    assert "`secrets-manager access update --allowed-ip`" in (excinfo.value.next_action or "")


def test_ksm_secret_folder_update_reports_missing_secret_move(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="secret.db",
        resource_type="ksm_secret_metadata",
        title="db",
        before={"folder_uid_ref": "keeper-vault:folders:old"},
        after={"folder_uid_ref": "keeper-vault:folders:new"},
    )

    with pytest.raises(CapabilityError) as excinfo:
        _apply(provider, change)

    assert "`secrets-manager secret move`" in (excinfo.value.next_action or "")


def test_ksm_master_key_rotation_reports_missing_rotate_key(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="app.api",
        resource_type="ksm_master_key_rotation",
        title="API Service",
        after={"rotate": True},
    )

    with pytest.raises(CapabilityError) as excinfo:
        _apply(provider, change)

    assert "`secrets-manager app rotate-key`" in (excinfo.value.next_action or "")


def test_ksm_event_query_reports_missing_machine_readable_audit(monkeypatch) -> None:
    _install_fake_ksm_module(monkeypatch)
    provider = _provider(FakeKeeperParams())
    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="event.query",
        resource_type="ksm_event_query",
        title="KSM events",
        after={"since": "2026-05-01T00:00:00Z"},
    )

    with pytest.raises(CapabilityError) as excinfo:
        _apply(provider, change)

    assert "`secrets-manager event list --format json`" in (excinfo.value.next_action or "")
