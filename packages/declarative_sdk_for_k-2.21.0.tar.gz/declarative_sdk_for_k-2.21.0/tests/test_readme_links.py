"""Regression test: every relative link in the user-facing README and the
public docs site must resolve to a file in the repo.

Craig Lurey's review (2026-05-04) flagged 404 errors when reading the
project landing pages. This test prevents those broken links from
re-appearing. It is intentionally narrow: it only checks the human-facing
entry points (README, docs/index.md, docs/QUICK_START.md,
docs/INSTALLATION.md) plus the GitHub Action README, because those are
what a new reader sees first.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
REPO_ROOT = Path(__file__).resolve().parents[1]

ENTRY_POINT_DOCS = (
    "README.md",
    "AGENTS.md",
    "docs/index.md",
    "docs/QUICK_START.md",
    "docs/INSTALLATION.md",
    ".github/actions/dsk/README.md",
)


def _broken_links(rel_path: str) -> list[str]:
    p = REPO_ROOT / rel_path
    text = p.read_text(encoding="utf-8")
    broken: list[str] = []
    for m in LINK_RE.finditer(text):
        target = m.group(2).split("#", 1)[0].strip()
        if not target:
            continue
        if target.startswith(("http://", "https://", "mailto:", "tel:")):
            continue
        candidate = (p.parent / target).resolve()
        if not candidate.exists():
            broken.append(target)
    return broken


@pytest.mark.parametrize("doc", ENTRY_POINT_DOCS)
def test_entry_point_doc_has_no_broken_relative_links(doc: str) -> None:
    """Every entry-point doc must have zero unresolved relative links."""
    broken = _broken_links(doc)
    assert not broken, f"{doc} has {len(broken)} broken relative link(s):\n  - " + "\n  - ".join(
        broken
    )


def test_readme_explains_loop_in_plain_language() -> None:
    """The README lead must include the plain-English summary so first-time
    readers are not dropped straight into jargon. Guards against regressions
    of Craig's 2026-05-04 review feedback.
    """
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    head = readme[:2000]
    plain_phrases = (
        "plain English",
        "describe what your Keeper tenant should look like",
        "validate",
        "plan",
        "apply",
    )
    missing = [p for p in plain_phrases if p.lower() not in head.lower()]
    assert not missing, f"README lead is missing plain-language anchors: {missing}"


def test_readme_includes_examples_section() -> None:
    """README must surface a recipe-book / examples section in the first
    half so readers see usage before they hit the reference tables.
    """
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    assert "Common tasks" in readme, "README must include a 'Common tasks' recipe section"
    assert "## Testing" in readme, (
        "README must surface a Testing section so reviewers know how every feature is exercised"
    )
