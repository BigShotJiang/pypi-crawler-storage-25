"""Dispatch tests for MockProvider PAM stubs, bridge stubs, JIT bindings, seeds (Lurey #4).

Each named MockProvider surface gets at least one behaviour assertion: outcome count versus
planned rows plus stable ``family`` / ``mock`` tagging on stub applies; state assertions on
seed helpers and snapshot shape for JIT bindings.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.planner import Plan, build_plan
from dsk.providers.mock import MockProvider


class _RawPlan(Plan):
    """Plan variant that exposes conflict/noop rows to branch-focused provider tests."""

    def ordered(self) -> list[Change]:
        return list(self.changes)


def _plan_two_creates(
    manifest_name: str,
    resource_type: str,
    *,
    uid_a: str = "pam-bridge.uid-a",
    uid_b: str = "pam-bridge.uid-b",
) -> Plan:
    changes = [
        Change(
            kind=ChangeKind.CREATE,
            uid_ref=uid_a,
            resource_type=resource_type,
            title=uid_a,
            before={},
            after={"stamp": uid_a},
        ),
        Change(
            kind=ChangeKind.CREATE,
            uid_ref=uid_b,
            resource_type=resource_type,
            title=uid_b,
            before={},
            after={"stamp": uid_b},
        ),
    ]
    return build_plan(manifest_name, changes, [uid_a, uid_b])


def _assert_stub_outcomes(
    apply_fn: Callable[..., list[Any]],
    plan: Plan,
    *,
    expected_family: str,
) -> None:
    outcomes = apply_fn(plan, dry_run=False)
    assert len(outcomes) == 2
    assert [o.action for o in outcomes] == ["create", "create"]
    for row in outcomes:
        assert row.details.get("dry_run") is False
        assert row.details.get("mock") is True
        assert row.details.get("family") == expected_family


_STUB_CASES = [
    pytest.param(
        "apply_db_access_plan",
        "db-access-policy.v1",
        "db_access_rule",
        id="apply_db_access_plan",
    ),
    pytest.param(
        "apply_cloud_jit_plan",
        "cloud-jit.v1",
        "cloud_jit_policy",
        id="apply_cloud_jit_plan",
    ),
    pytest.param(
        "apply_rotation_plan",
        "rotation-policy.v1",
        "rotation_policy",
        id="apply_rotation_plan",
    ),
    pytest.param(
        "apply_saas_rotation_plan",
        "keeper-saas-rotation.v1",
        "saas_rotation_config",
        id="apply_saas_rotation_plan",
    ),
    pytest.param(
        "apply_tunnel_m_plan",
        "keeper-tunnel.v1",
        "tunnel_config",
        id="apply_tunnel_m_plan",
    ),
    pytest.param(
        "apply_gateway_ha_plan",
        "gateway-ha.v1",
        "gateway_ha_cluster",
        id="apply_gateway_ha_plan",
    ),
    pytest.param(
        "apply_pipeline_env_plan",
        "pipeline-ephemeral-environment.v1",
        "pipeline_ephemeral_env",
        id="apply_pipeline_env_plan",
    ),
    pytest.param(
        "apply_secret_scanner_plan",
        "secret-scanner-bridge.v1",
        "secret_scanner_repo",
        id="apply_secret_scanner_plan",
    ),
    pytest.param(
        "apply_keeper_drive_m_plan",
        "keeper-drive.v1",
        "keeper_drive_folder",
        id="apply_keeper_drive_m_plan",
    ),
    pytest.param(
        "apply_agent_kit_m_plan",
        "keeper-agent-kit.v1",
        "agent_kit_policy",
        id="apply_agent_kit_m_plan",
    ),
    pytest.param(
        "apply_mcp_binding_plan",
        "mcp-secrets-binding.v1",
        "mcp_server_binding",
        id="apply_mcp_binding_plan",
    ),
    pytest.param(
        "apply_mcp_allowlist_plan",
        "mcp-server-allowlist.v1",
        "mcp_server_allowlist",
        id="apply_mcp_allowlist_plan",
    ),
    pytest.param(
        "apply_spiffe_plan",
        "spiffe-binding.v1",
        "spiffe_rule",
        id="apply_spiffe_plan",
    ),
    pytest.param(
        "apply_trust_chain_plan",
        "ai-agent-trust-chain.v1",
        "trust_chain_rule",
        id="apply_trust_chain_plan",
    ),
    pytest.param(
        "apply_workflow_gate_plan",
        "workflow-gate.v1",
        "workflow_gate",
        id="apply_workflow_gate_plan",
    ),
    pytest.param(
        "apply_workflow_plan",
        "keeper-workflow.v1",
        "workflow_config",
        id="apply_workflow_plan",
    ),
    pytest.param(
        "apply_itsm_gate_plan",
        "itsm-approval-gate.v1",
        "itsm_gate",
        id="apply_itsm_gate_plan",
    ),
    pytest.param(
        "apply_slack_gate_plan",
        "slack-approval-gate.v1",
        "slack_gate",
        id="apply_slack_gate_plan",
    ),
]


@pytest.mark.parametrize("method_name,family,resource_type", _STUB_CASES)
def test_mock_stub_apply_emits_one_outcome_per_ordered_change(
    method_name: str,
    family: str,
    resource_type: str,
) -> None:
    provider = MockProvider("pam-bridge")
    plan = _plan_two_creates("pam-bridge", resource_type)
    apply_fn = getattr(provider, method_name)
    _assert_stub_outcomes(apply_fn, plan, expected_family=family)


def test_apply_jit_plan_writes_binding_state() -> None:
    provider = MockProvider("pam-bridge")
    uid = "pam-bridge.jit-target"
    plan = build_plan(
        "pam-bridge",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid,
                resource_type="jit_binding",
                title=uid,
                before={},
                after={"approvers": ["u1"], "window_minutes": 15},
            ),
        ],
        [uid],
    )
    assert provider.jit_bindings_snapshot() == {}
    outcomes = provider.apply_jit_plan(plan, dry_run=False)
    assert len(outcomes) == 1
    assert outcomes[0].action == "create"
    assert outcomes[0].uid_ref == uid
    stored = provider.jit_bindings_snapshot()[uid]
    assert stored["window_minutes"] == 15
    assert stored["approvers"] == ["u1"]


def test_apply_jit_plan_dry_run_does_not_mutate_bindings() -> None:
    provider = MockProvider("pam-bridge")
    uid = "pam-bridge.jit-dry"
    plan = build_plan(
        "pam-bridge",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid,
                resource_type="jit_binding",
                title=uid,
                before={},
                after={"window_minutes": 5},
            ),
        ],
        [uid],
    )
    outcomes = provider.apply_jit_plan(plan, dry_run=True)
    assert len(outcomes) == 1 and outcomes[0].action == "create"
    assert provider.jit_bindings_snapshot() == {}


def test_jit_bindings_snapshot_returns_detached_payloads() -> None:
    provider = MockProvider("pam-bridge")
    uid = "pam-bridge.jit-snapshot"
    plan = build_plan(
        "pam-bridge",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid,
                resource_type="jit_binding",
                title=uid,
                before={},
                after={"window_minutes": 9},
            ),
        ],
        [uid],
    )
    provider.apply_jit_plan(plan, dry_run=False)
    snapshot = provider.jit_bindings_snapshot()
    assert snapshot[uid]["window_minutes"] == 9
    snapshot[uid]["window_minutes"] = 999
    assert provider.jit_bindings_snapshot()[uid]["window_minutes"] == 9


def test_apply_jit_plan_update_replaces_binding_state() -> None:
    provider = MockProvider("pam-bridge")
    uid = "pam-bridge.jit-update"
    provider.apply_jit_plan(
        build_plan(
            "pam-bridge",
            [
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=uid,
                    resource_type="jit_binding",
                    title=uid,
                    after={"window_minutes": 5},
                )
            ],
            [uid],
        )
    )

    outcomes = provider.apply_jit_plan(
        build_plan(
            "pam-bridge",
            [
                Change(
                    kind=ChangeKind.UPDATE,
                    uid_ref=uid,
                    resource_type="jit_binding",
                    title=uid,
                    after={"window_minutes": 30, "approvers": ["secops"]},
                )
            ],
            [uid],
        )
    )

    assert outcomes[0].action == "update"
    assert provider.jit_bindings_snapshot()[uid] == {
        "window_minutes": 30,
        "approvers": ["secops"],
    }


def test_apply_jit_plan_conflict_noop_and_delete_are_non_mutating_rows() -> None:
    provider = MockProvider("pam-bridge")
    plan = _RawPlan(
        "pam-bridge",
        [
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref="jit.conflict",
                resource_type="jit_binding",
                title="conflict",
                reason="blocked",
            ),
            Change(
                kind=ChangeKind.NOOP,
                uid_ref="jit.noop",
                resource_type="jit_binding",
                title="noop",
            ),
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="jit.delete",
                resource_type="jit_binding",
                title="delete",
            ),
        ],
        ["jit.delete", "jit.noop", "jit.conflict"],
    )

    outcomes = provider.apply_jit_plan(plan)

    assert [(row.uid_ref, row.action) for row in outcomes] == [
        ("jit.conflict", "conflict"),
        ("jit.noop", "noop"),
        ("jit.delete", "noop"),
    ]
    assert outcomes[0].details["reason"] == "blocked"
    assert outcomes[2].details["skipped"] == "delete"
    assert provider.jit_bindings_snapshot() == {}


def test_apply_privileged_access_plan_conflict_and_noop_rows() -> None:
    provider = MockProvider("pam-bridge")
    plan = _RawPlan(
        "pam-bridge",
        [
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref="pa.conflict",
                resource_type="privileged_access_policy",
                title="conflict",
                reason="external owner",
            ),
            Change(
                kind=ChangeKind.NOOP,
                uid_ref="pa.noop",
                resource_type="privileged_access_policy",
                title="noop",
            ),
        ],
        ["pa.noop", "pa.conflict"],
    )

    outcomes = provider.apply_privileged_access_plan(plan)

    assert [(row.uid_ref, row.action) for row in outcomes] == [
        ("pa.conflict", "conflict"),
        ("pa.noop", "noop"),
    ]
    assert outcomes[0].details["reason"] == "external owner"
    assert outcomes[1].details["skipped"] == "noop"


def test_apply_nhi_plan_update_is_family_tagged() -> None:
    provider = MockProvider("pam-bridge")
    plan = build_plan(
        "pam-bridge",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="nhi.agent",
                resource_type="nhi_agent",
                title="agent",
            )
        ],
        ["nhi.agent"],
    )

    outcomes = provider.apply_nhi_plan(plan, dry_run=True)

    assert outcomes[0].action == "update"
    assert outcomes[0].details["dry_run"] is True
    assert outcomes[0].details["mock"] is True
    assert outcomes[0].details["family"] == "nhi-agent.v1"


def test_apply_ai_agent_plan_conflict_preserves_reason() -> None:
    provider = MockProvider("pam-bridge")
    plan = _RawPlan(
        "pam-bridge",
        [
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref="ai.conflict",
                resource_type="ai_agent_identity",
                title="agent",
                reason="ambiguous principal",
            )
        ],
        ["ai.conflict"],
    )

    outcomes = provider.apply_ai_agent_plan(plan)

    assert outcomes[0].action == "conflict"
    assert outcomes[0].details["reason"] == "ambiguous principal"


def test_seed_enterprise_state_populates_rows_and_marker_ledger() -> None:
    provider = MockProvider("pam-bridge")
    provider.seed_enterprise_state(
        {
            "nodes": [
                {
                    "uid_ref": "pam-bridge.node",
                    "name": "edge",
                    "manager": "dsk",
                    "manifest": "pam-bridge",
                },
            ],
        },
    )
    rows = provider.discover_enterprise()["nodes"]
    assert len(rows) == 1
    row = rows[0]
    assert row["uid_ref"] == "pam-bridge.node"
    assert row["keeper_uid"]
    assert isinstance(row["marker"], dict)
    ledger = provider.enterprise_markers()
    assert ledger[row["keeper_uid"]]["uid_ref"] == "pam-bridge.node"


def test_seed_managed_companies_assigns_stable_ids_and_sorts_discovery() -> None:
    provider = MockProvider("pam-bridge")
    provider.seed_managed_companies(
        [
            {"name": "BravoCorp"},
            {"name": "alpha LLC"},
            {"name": "Charlie"},
        ],
    )
    discovered = provider.discover_managed_companies()
    assert [row["name"] for row in discovered] == ["alpha LLC", "BravoCorp", "Charlie"]
    for row in discovered:
        assert row.get("mc_enterprise_id") is not None


def test_apply_ai_agent_plan_stub_tags_family() -> None:
    provider = MockProvider("pam-bridge-ai")
    plan = _plan_two_creates(
        "pam-bridge-ai",
        "ai_agent_identity",
        uid_a="ai.agent.alpha",
        uid_b="ai.agent.beta",
    )
    _assert_stub_outcomes(provider.apply_ai_agent_plan, plan, expected_family="ai-agent.v1")
