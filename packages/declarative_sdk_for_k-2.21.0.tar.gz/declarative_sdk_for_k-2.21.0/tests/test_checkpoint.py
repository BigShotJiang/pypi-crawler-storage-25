"""Tests for DSK partial-apply checkpoint."""

from __future__ import annotations

import json
import pathlib

import pytest

from dsk.core.checkpoint import ApplyCheckpoint


def test_checkpoint_round_trip(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/manifest.yaml"
    cp = ApplyCheckpoint.load_or_create(manifest, "abc123")
    cp.mark_applied("res.db", "create")
    assert cp.is_applied("res.db")
    assert not cp.is_applied("res.gw")

    cp2 = ApplyCheckpoint.load_or_create(manifest, "abc123")
    assert cp2.is_applied("res.db")


def test_checkpoint_hash_mismatch_starts_fresh(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/manifest.yaml"
    cp = ApplyCheckpoint.load_or_create(manifest, "hash1")
    cp.mark_applied("res.x", "create")

    cp2 = ApplyCheckpoint.load_or_create(manifest, "different-hash")
    assert not cp2.is_applied("res.x")


def test_checkpoint_clear(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/manifest.yaml"
    cp = ApplyCheckpoint.load_or_create(manifest, "abc")
    cp.mark_applied("res.a", "create")
    assert pathlib.Path(manifest + ".dsk-checkpoint").exists()
    cp.clear()
    assert not pathlib.Path(manifest + ".dsk-checkpoint").exists()


def test_checkpoint_multiple_resources_all_tracked(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/m.yaml"
    cp = ApplyCheckpoint.load_or_create(manifest, "hash-abc")
    for uid in ["res.gw", "res.cfg", "res.machine"]:
        cp.mark_applied(uid, "create")

    assert cp.is_applied("res.gw")
    assert cp.is_applied("res.cfg")
    assert cp.is_applied("res.machine")
    assert not cp.is_applied("res.missing")


def test_checkpoint_persists_kind_field(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/m.yaml"
    cp = ApplyCheckpoint.load_or_create(manifest, "hash-xyz")
    cp.mark_applied("res.db", "update")

    cp2 = ApplyCheckpoint.load_or_create(manifest, "hash-xyz")
    assert cp2.is_applied("res.db")
    matching = [e for e in cp2.entries if e.uid_ref == "res.db"]
    assert matching[0].kind == "update"


def test_checkpoint_clear_then_reload_starts_empty(tmp_path: object) -> None:
    manifest = str(tmp_path) + "/m.yaml"
    cp = ApplyCheckpoint.load_or_create(manifest, "hash-reset")
    cp.mark_applied("res.x", "create")
    cp.clear()

    cp2 = ApplyCheckpoint.load_or_create(manifest, "hash-reset")
    assert not cp2.is_applied("res.x")
    assert cp2.entries == []


def test_checkpoint_load_accepts_at_byte_cap(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = str(tmp_path / "m.yaml")
    cp = ApplyCheckpoint.load_or_create(manifest, "hash-cap")
    cp.mark_applied("res.cap", "create")
    raw = pathlib.Path(manifest + ".dsk-checkpoint").read_text(encoding="utf-8")
    monkeypatch.setenv("DSK_CHECKPOINT_MAX_BYTES", str(len(raw.encode("utf-8"))))

    cp2 = ApplyCheckpoint.load_or_create(manifest, "hash-cap")

    assert cp2.is_applied("res.cap")


def test_checkpoint_load_rejects_just_over_byte_cap(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = str(tmp_path / "m.yaml")
    payload = {
        "manifest_path": manifest,
        "manifest_hash": "hash-cap",
        "started_at": 1.0,
        "entries": [{"uid_ref": "res.big", "applied_at": 1.0, "kind": "create"}],
    }
    raw = json.dumps(payload)
    pathlib.Path(manifest + ".dsk-checkpoint").write_text(raw, encoding="utf-8")
    monkeypatch.setenv("DSK_CHECKPOINT_MAX_BYTES", str(len(raw.encode("utf-8")) - 1))

    cp = ApplyCheckpoint.load_or_create(manifest, "hash-cap")

    assert not cp.is_applied("res.big")
