"""Change classification."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import pytest

from dsk.core import compute_diff, load_manifest
from dsk.core.diff import ChangeKind
from dsk.core.errors import CollisionError
from dsk.core.interfaces import LiveRecord
from dsk.core.metadata import encode_marker
from dsk.core.models import Manifest


def test_diff_all_create(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    changes = compute_diff(manifest, live_records=[])
    kinds = {c.kind for c in changes}
    assert kinds == {ChangeKind.CREATE}
    uid_refs = {c.uid_ref for c in changes if c.uid_ref}
    # resource + pam_config + nested user
    assert "acme-lab-linux1" in uid_refs
    assert "acme-lab-cfg" in uid_refs
    assert "acme-lab-linux1-root" in uid_refs


def test_diff_noop_when_marker_matches(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    # simulate a live record owned by us, same payload
    payload = {"title": "lab-linux-1", "host": "10.16.9.10", "port": "22"}
    live = [
        LiveRecord(
            keeper_uid="LIVE_UID_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=payload,
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        )
    ]
    changes = compute_diff(manifest, live_records=live)
    machine_changes = [c for c in changes if c.uid_ref == "acme-lab-linux1"]
    assert len(machine_changes) == 1
    # host matches, other unspecified fields count as missing -> UPDATE
    # Acceptable because manifest has additional keys not present in payload.
    assert machine_changes[0].kind in (ChangeKind.UPDATE, ChangeKind.NOOP)


def test_diff_conflict_on_foreign_manager(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    live = [
        LiveRecord(
            keeper_uid="LIVE_UID",
            title="lab-linux-1",
            resource_type="pamMachine",
            marker={"manager": "someone-else", "uid_ref": "acme-lab-linux1", "version": "1"},
            payload={"title": "lab-linux-1"},
        )
    ]
    changes = compute_diff(manifest, live_records=live)
    conflicts = [c for c in changes if c.kind is ChangeKind.CONFLICT]
    assert len(conflicts) == 1
    assert conflicts[0].title == "lab-linux-1"


def test_diff_conflict_when_unmanaged_title_matches_by_default(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    live = [
        LiveRecord(
            keeper_uid="LIVE_UID",
            title="lab-linux-1",
            resource_type="pamMachine",
            marker=None,
            payload={"title": "lab-linux-1", "host": "10.16.9.10"},
        )
    ]
    changes = compute_diff(manifest, live_records=live)
    conflicts = [c for c in changes if c.uid_ref == "acme-lab-linux1"]
    assert conflicts
    assert conflicts[0].kind is ChangeKind.CONFLICT
    assert conflicts[0].reason
    assert any(term in conflicts[0].reason for term in ("unmanaged", "claim", "import"))


def test_diff_adoption_when_unmanaged_title_matches_with_adopt_flag(
    minimal_manifest_path: Path,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    live = [
        LiveRecord(
            keeper_uid="LIVE_UID",
            title="lab-linux-1",
            resource_type="pamMachine",
            marker=None,
            payload={"title": "lab-linux-1", "host": "10.16.9.10"},
        )
    ]
    changes = compute_diff(manifest, live_records=live, adopt=True)
    adopt = [c for c in changes if c.uid_ref == "acme-lab-linux1"]
    assert adopt
    assert adopt[0].kind is ChangeKind.UPDATE
    assert adopt[0].reason == "adoption: write ownership marker"


def test_diff_delete_when_allowed(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    orphan = LiveRecord(
        keeper_uid="ORPHAN",
        title="old-host",
        resource_type="pamMachine",
        marker=encode_marker(
            uid_ref="acme-lab-old",
            manifest=manifest.name,
            resource_type="pamMachine",
        ),
        payload={"title": "old-host"},
    )
    changes = compute_diff(manifest, live_records=[orphan], allow_delete=True)
    deletes = [c for c in changes if c.kind is ChangeKind.DELETE]
    assert deletes and deletes[0].title == "old-host"


def test_diff_no_delete_without_flag(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    orphan = LiveRecord(
        keeper_uid="ORPHAN",
        title="old-host",
        resource_type="pamMachine",
        marker=encode_marker(
            uid_ref="acme-lab-old",
            manifest=manifest.name,
            resource_type="pamMachine",
        ),
        payload={"title": "old-host"},
    )
    changes = compute_diff(manifest, live_records=[orphan], allow_delete=False)
    assert not [c for c in changes if c.kind is ChangeKind.DELETE]
    assert [c for c in changes if c.kind is ChangeKind.CONFLICT and c.title == "old-host"]


def test_collision_duplicate_marker_uid_ref(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    live = [
        LiveRecord(
            keeper_uid="LIVE_UID_A",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload={"title": "lab-linux-1"},
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_UID_B",
            title="lab-linux-1-copy",
            resource_type="pamMachine",
            payload={"title": "lab-linux-1-copy"},
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        ),
    ]

    with pytest.raises(CollisionError) as exc_info:
        compute_diff(manifest, live_records=live)

    err = exc_info.value
    assert err.uid_ref == "acme-lab-linux1"
    assert err.context["live_identifiers"] == ["LIVE_UID_A", "LIVE_UID_B"]
    assert "claiming uid_ref='acme-lab-linux1'" in err.reason


def test_collision_duplicate_title_no_marker(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    live = [
        LiveRecord(
            keeper_uid="LIVE_UID_A",
            title="lab-linux-1",
            resource_type="pamMachine",
            marker=None,
            payload={"title": "lab-linux-1"},
        ),
        LiveRecord(
            keeper_uid="LIVE_UID_B",
            title="lab-linux-1",
            resource_type="pamMachine",
            marker=None,
            payload={"title": "lab-linux-1"},
        ),
    ]

    with pytest.raises(CollisionError) as exc_info:
        compute_diff(manifest, live_records=live)

    err = exc_info.value
    assert err.uid_ref is None
    assert err.resource_type == "pamMachine"
    assert err.context["live_identifiers"] == ["LIVE_UID_A", "LIVE_UID_B"]
    assert "records titled 'lab-linux-1' with no ownership markers" in err.reason


def test_no_collision_single_marker_pair(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    live = [
        LiveRecord(
            keeper_uid="LIVE_UID_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload={"title": "lab-linux-1", "host": "10.16.9.10", "port": "22"},
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        )
    ]

    changes = compute_diff(manifest, live_records=live)
    machine_changes = [c for c in changes if c.uid_ref == "acme-lab-linux1"]
    assert len(machine_changes) == 1
    assert machine_changes[0].kind in (ChangeKind.UPDATE, ChangeKind.NOOP)


def test_diff_nested_pam_user_rotation_drift_surfaces_rotation_settings_key(
    minimal_manifest_path: Path,
) -> None:
    """P2.1 offline anchor: nested ``pamUser`` rotation readback shape drift keys ``rotation_settings``.

    Live Commander payloads can disagree with manifest schedule shape while still
    representing the same applied intent; ``compute_diff`` must name
    ``rotation_settings`` in UPDATE ``before``/``after`` so smoke/parent tails
    stay diagnosable (SDK_DA §P2.1 task 2).
    """
    manifest = load_manifest(minimal_manifest_path)
    assert isinstance(manifest, Manifest)
    data = manifest.model_dump(mode="python", exclude_none=True)
    machine = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    user_desired = next(u for u in machine["users"] if u["uid_ref"] == "acme-lab-linux1-root")
    live_user = {k: v for k, v in user_desired.items() if k not in {"rotation_settings"}} | {
        "rotation_settings": {
            "rotation": "general",
            "enabled": "on",
            "schedule": {"type": "CRON", "cron": "0 0 * * *"},
            "password_complexity": user_desired["rotation_settings"]["password_complexity"],
        }
    }
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=deepcopy(machine),
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_USER",
            title="lab-linux-1-root",
            resource_type="pamUser",
            payload=live_user,
            marker=encode_marker(
                uid_ref="acme-lab-linux1-root",
                manifest=manifest.name,
                resource_type="pamUser",
            ),
        ),
    ]
    changes = compute_diff(manifest, live_records=live)
    user_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1-root")
    assert user_change.kind is ChangeKind.UPDATE
    assert user_change.before is not None
    assert user_change.after is not None
    assert "rotation_settings" in user_change.before
    assert "rotation_settings" in user_change.after


def test_diff_pam_user_rotation_missing_readback_is_noop_with_sdk_marker(
    minimal_manifest_path: Path,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    data = manifest.model_dump(mode="python", exclude_none=True)
    machine = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    user_desired = next(u for u in machine["users"] if u["uid_ref"] == "acme-lab-linux1-root")
    live_user = {k: v for k, v in user_desired.items() if k != "rotation_settings"}
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=deepcopy(machine),
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_USER",
            title="lab-linux-1-root",
            resource_type="pamUser",
            payload=live_user,
            marker=encode_marker(
                uid_ref="acme-lab-linux1-root",
                manifest=manifest.name,
                resource_type="pamUser",
            ),
        ),
    ]
    changes = compute_diff(manifest, live_records=live)
    user_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1-root")
    assert user_change.kind is ChangeKind.NOOP


def test_diff_pam_user_rotation_missing_readback_updates_without_matching_sdk_marker(
    minimal_manifest_path: Path,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    data = manifest.model_dump(mode="python", exclude_none=True)
    machine = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    user_desired = next(u for u in machine["users"] if u["uid_ref"] == "acme-lab-linux1-root")
    live_user = {k: v for k, v in user_desired.items() if k != "rotation_settings"}
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=deepcopy(machine),
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_USER",
            title="lab-linux-1-root",
            resource_type="pamUser",
            payload=live_user,
            marker=encode_marker(
                uid_ref="other-user",
                manifest=manifest.name,
                resource_type="pamUser",
            ),
        ),
    ]
    changes = compute_diff(manifest, live_records=live)
    user_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1-root")
    assert user_change.kind is ChangeKind.UPDATE
    assert user_change.before == {"rotation_settings": None}
    assert "rotation_settings" in user_change.after


def test_diff_pam_user_managed_string_skew_is_noop(
    minimal_manifest_path: Path,
) -> None:
    """P2.1: nested ``pamUser.managed`` — Commander can return stringy flags vs manifest bools."""
    manifest = load_manifest(minimal_manifest_path)
    data = manifest.model_dump(mode="python", exclude_none=True)
    machine = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    user_desired = next(u for u in machine["users"] if u["uid_ref"] == "acme-lab-linux1-root")
    user_desired = {**user_desired, "managed": True}
    new_resources: list[dict[str, Any]] = []
    for r in data["resources"]:
        if r["uid_ref"] == "acme-lab-linux1":
            new_resources.append({**deepcopy(r), "users": [user_desired]})
        else:
            new_resources.append(deepcopy(r))
    manifest2 = Manifest.model_validate({**data, "resources": new_resources})
    live_user = {**user_desired, "managed": "on"}
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=next(r for r in new_resources if r["uid_ref"] == "acme-lab-linux1"),
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest2.name,
                resource_type="pamMachine",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_USER",
            title="lab-linux-1-root",
            resource_type="pamUser",
            payload=live_user,
            marker=encode_marker(
                uid_ref="acme-lab-linux1-root",
                manifest=manifest2.name,
                resource_type="pamUser",
            ),
        ),
    ]
    changes = compute_diff(manifest2, live_records=live)
    user_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1-root")
    assert user_change.kind is ChangeKind.NOOP


def test_diff_pam_machine_pam_settings_live_extra_options_is_noop(
    minimal_manifest_path: Path,
) -> None:
    """P2.1: parent ``pamMachine`` re-plan must not UPDATE when Commander only adds tri-states."""
    manifest = load_manifest(minimal_manifest_path)
    data = manifest.model_dump(mode="python", exclude_none=True)
    machine = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    live_settings = deepcopy(machine["pam_settings"])
    assert isinstance(live_settings, dict)
    options = live_settings.get("options")
    assert isinstance(options, dict)
    # Simulate TunnelDAG/Commander backfill the parent machine would see post-apply.
    options = {**options, "remote_browser_isolation": "off", "graphical_session_recording": "off"}
    live_settings["options"] = options
    live_machine = {**deepcopy(machine), "pam_settings": live_settings}
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=live_machine,
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        )
    ]
    changes = compute_diff(manifest, live_records=live)
    machine_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1")
    assert machine_change.kind is ChangeKind.NOOP


def test_diff_pam_machine_connection_only_ignores_live_default_options(
    minimal_manifest_path: Path,
) -> None:
    """Commander may add ``options`` defaults when the manifest only owns ``connection``."""
    manifest0 = load_manifest(minimal_manifest_path)
    data = manifest0.model_dump(mode="python", exclude_none=True)
    machine0 = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    connection = deepcopy(machine0["pam_settings"]["connection"])
    machine_d = {**deepcopy(machine0), "pam_settings": {"connection": connection}}
    resources = [
        machine_d if r["uid_ref"] == "acme-lab-linux1" else deepcopy(r) for r in data["resources"]
    ]
    manifest = Manifest.model_validate({**data, "resources": resources})
    machine = next(
        r
        for r in manifest.model_dump(mode="python", exclude_none=True)["resources"]
        if r["uid_ref"] == "acme-lab-linux1"
    )
    live_machine = {
        **deepcopy(machine),
        "pam_settings": {
            "options": {"connections": "on", "rotation": "on"},
            "connection": deepcopy(connection),
        },
    }
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=live_machine,
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        )
    ]
    changes = compute_diff(manifest, live_records=live)
    machine_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1")
    assert machine_change.kind is ChangeKind.NOOP


def test_diff_pam_machine_connection_only_live_default_options_stay_out_of_diff(
    minimal_manifest_path: Path,
) -> None:
    """Manifest-owned ``connection`` must not surface live default ``options`` in updates."""
    manifest0 = load_manifest(minimal_manifest_path)
    data = manifest0.model_dump(mode="python", exclude_none=True)
    machine0 = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    connection = deepcopy(machine0["pam_settings"]["connection"])
    machine_d = {**deepcopy(machine0), "pam_settings": {"connection": connection}}
    resources = [
        machine_d if r["uid_ref"] == "acme-lab-linux1" else deepcopy(r) for r in data["resources"]
    ]
    manifest = Manifest.model_validate({**data, "resources": resources})
    machine = next(
        r
        for r in manifest.model_dump(mode="python", exclude_none=True)["resources"]
        if r["uid_ref"] == "acme-lab-linux1"
    )
    live_machine = {
        **deepcopy(machine),
        "host": "10.16.9.11",
        "pam_settings": {
            "options": {"connections": "on", "rotation": "on"},
            "connection": deepcopy(connection),
        },
    }
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=live_machine,
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        )
    ]
    changes = compute_diff(manifest, live_records=live)
    machine_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1")
    assert machine_change.kind is ChangeKind.UPDATE
    assert machine_change.before == {"host": "10.16.9.11"}
    assert machine_change.after == {"host": "10.16.9.10"}


def test_diff_pam_machine_pam_settings_nested_options_live_extra_inner_keys_is_noop(
    minimal_manifest_path: Path,
) -> None:
    """Nested dicts under ``options``/``port_forward`` allow live-only inner keys (overlay)."""
    manifest0 = load_manifest(minimal_manifest_path)
    data = manifest0.model_dump(mode="python", exclude_none=True)
    machine0 = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    ps0 = machine0.get("pam_settings") or {}
    options0 = dict(ps0.get("options") or {})
    # Arbitrary nested block (PAM model allows extra keys) — only ``k1``/``k2`` are "owned".
    options0["nested"] = {"k1": 1, "k2": 2}
    machine_d = {**machine0, "pam_settings": {**ps0, "options": options0}}
    new_resources = []
    for r in data["resources"]:
        if r["uid_ref"] == "acme-lab-linux1":
            new_resources.append(machine_d)
        else:
            new_resources.append(deepcopy(r))
    manifest = Manifest.model_validate({**data, "resources": new_resources})
    m_dump = next(
        r
        for r in manifest.model_dump(mode="python", exclude_none=True)["resources"]
        if r["uid_ref"] == "acme-lab-linux1"
    )
    live_settings = deepcopy(m_dump["pam_settings"])
    assert isinstance(live_settings, dict)
    n = {**((live_settings.get("options") or {}).get("nested") or {}), "k3": "live-only"}
    opt_live = {**(live_settings.get("options") or {}), "nested": n}
    live_settings = {**live_settings, "options": opt_live}
    live_machine = {**deepcopy(m_dump), "pam_settings": live_settings}
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=live_machine,
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        )
    ]
    changes = compute_diff(manifest, live_records=live)
    machine_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1")
    assert machine_change.kind is ChangeKind.NOOP


def test_diff_pam_database_pam_settings_live_extra_options_is_noop(
    pam_db_overlay_manifest_path: Path,
) -> None:
    """P2.1: ``pamDatabase.pam_settings`` must use the same overlay semantics as ``pamMachine``."""
    manifest = load_manifest(pam_db_overlay_manifest_path)
    assert isinstance(manifest, Manifest)
    data = manifest.model_dump(mode="python", exclude_none=True)
    cfg = next(c for c in data["pam_configurations"] if c["uid_ref"] == "acme-cfg")
    database = next(r for r in data["resources"] if r["uid_ref"] == "acme-mysql-1")
    live_settings = deepcopy(database["pam_settings"])
    assert isinstance(live_settings, dict)
    options = live_settings.get("options")
    assert isinstance(options, dict)
    options = {**options, "text_session_recording": "off", "ai_threat_detection": "off"}
    live_settings["options"] = options
    live_database = {**deepcopy(database), "pam_settings": live_settings}
    live = [
        LiveRecord(
            keeper_uid="LIVE_CFG",
            title=cfg.get("title") or "acme-cfg",
            resource_type="pam_configuration",
            payload=deepcopy(cfg),
            marker=encode_marker(
                uid_ref="acme-cfg",
                manifest=manifest.name,
                resource_type="pam_configuration",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_DB",
            title="mysql-1",
            resource_type="pamDatabase",
            payload=live_database,
            marker=encode_marker(
                uid_ref="acme-mysql-1",
                manifest=manifest.name,
                resource_type="pamDatabase",
            ),
        ),
    ]
    changes = compute_diff(manifest, live_records=live)
    db_change = next(c for c in changes if c.uid_ref == "acme-mysql-1")
    assert db_change.kind is ChangeKind.NOOP


def test_diff_pam_directory_pam_settings_live_extra_options_is_noop(
    pam_dir_overlay_manifest_path: Path,
) -> None:
    """P2.1: ``pamDirectory.pam_settings`` must use the same overlay semantics as machine/db."""
    manifest = load_manifest(pam_dir_overlay_manifest_path)
    assert isinstance(manifest, Manifest)
    data = manifest.model_dump(mode="python", exclude_none=True)
    cfg = next(c for c in data["pam_configurations"] if c["uid_ref"] == "acme2-cfg")
    directory = next(r for r in data["resources"] if r["uid_ref"] == "acme-ad-1")
    live_settings = deepcopy(directory["pam_settings"])
    assert isinstance(live_settings, dict)
    options = live_settings.get("options")
    assert isinstance(options, dict)
    options = {**options, "text_session_recording": "on", "graphical_session_recording": "on"}
    live_settings["options"] = options
    live_directory = {**deepcopy(directory), "pam_settings": live_settings}
    live = [
        LiveRecord(
            keeper_uid="LIVE2_CFG",
            title=cfg.get("title") or "acme2-cfg",
            resource_type="pam_configuration",
            payload=deepcopy(cfg),
            marker=encode_marker(
                uid_ref="acme2-cfg",
                manifest=manifest.name,
                resource_type="pam_configuration",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE2_DIR",
            title="ad-1",
            resource_type="pamDirectory",
            payload=live_directory,
            marker=encode_marker(
                uid_ref="acme-ad-1",
                manifest=manifest.name,
                resource_type="pamDirectory",
            ),
        ),
    ]
    changes = compute_diff(manifest, live_records=live)
    d_change = next(c for c in changes if c.uid_ref == "acme-ad-1")
    assert d_change.kind is ChangeKind.NOOP


def test_diff_pam_user_rotation_same_cron_extra_schedule_keys_is_noop(
    minimal_manifest_path: Path,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    data = manifest.model_dump(mode="python", exclude_none=True)
    machine = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    user_desired = next(u for u in machine["users"] if u["uid_ref"] == "acme-lab-linux1-root")
    live_user = dict(user_desired)
    live_user["rotation_settings"] = {
        "rotation": "general",
        "enabled": True,
        "schedule": {
            "type": "CRON",
            "cron": "0 0 * * *",
            "timezone": "UTC",
        },
        "password_complexity": user_desired["rotation_settings"]["password_complexity"],
    }
    desired_user = dict(user_desired)
    desired_user["rotation_settings"] = {
        "rotation": "general",
        "enabled": "on",
        "schedule": {"type": "CRON", "cron": "0 0 * * *"},
        "password_complexity": user_desired["rotation_settings"]["password_complexity"],
    }
    machine_live = deepcopy(machine)
    machine_live["users"] = [live_user]
    new_resources: list[dict[str, Any]] = []
    for r in data["resources"]:
        if r["uid_ref"] == "acme-lab-linux1":
            new_resources.append({**deepcopy(machine), "users": [desired_user]})
        else:
            new_resources.append(deepcopy(r))
    manifest2 = Manifest.model_validate({**data, "resources": new_resources})
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=machine_live,
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_USER",
            title="lab-linux-1-root",
            resource_type="pamUser",
            payload=live_user,
            marker=encode_marker(
                uid_ref="acme-lab-linux1-root",
                manifest=manifest.name,
                resource_type="pamUser",
            ),
        ),
    ]
    changes = compute_diff(manifest2, live_records=live)
    user_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1-root")
    assert user_change.kind is ChangeKind.NOOP


# ── Sprint BC: private helper unit tests ──────────────────────────────────


def test_rotation_scripts_readback_available_import_error() -> None:
    """_rotation_scripts_readback_available returns False when import fails."""
    import unittest.mock as mock

    from dsk.core.diff import _rotation_scripts_readback_available

    with mock.patch.dict("sys.modules", {"dsk.providers.commander_version": None}):
        result = _rotation_scripts_readback_available()
    assert result is False


def test_dict_overlay_matches_nested_mismatch() -> None:
    """_dict_overlay_matches returns False when nested dict values differ."""
    from dsk.core.diff import _dict_overlay_matches

    live = {"options": {"port": 22, "timeout": 10}}
    desired = {"options": {"port": 22, "timeout": 30}}
    assert not _dict_overlay_matches(live, desired)


def test_dict_overlay_matches_nested_match() -> None:
    """_dict_overlay_matches returns True for matching nested dicts."""
    from dsk.core.diff import _dict_overlay_matches

    live = {"options": {"port": 22, "extra": "ignored"}, "name": "x"}
    desired = {"options": {"port": 22}}
    assert _dict_overlay_matches(live, desired)


def test_dict_overlay_matches_live_not_dict_for_nested_desired() -> None:
    """_dict_overlay_matches returns False when live value is scalar but desired is dict."""
    from dsk.core.diff import _dict_overlay_matches

    live = {"options": "string"}
    desired = {"options": {"port": 22}}
    assert not _dict_overlay_matches(live, desired)


def test_normalize_rotation_enabled_bool_true() -> None:
    """_normalize_rotation_enabled converts True -> 'on'."""
    from dsk.core.diff import _normalize_rotation_enabled

    assert _normalize_rotation_enabled(True) == "on"
    assert _normalize_rotation_enabled(False) == "off"


def test_normalize_rotation_enabled_string_variants() -> None:
    """_normalize_rotation_enabled normalizes string truthy/falsy values."""
    from dsk.core.diff import _normalize_rotation_enabled

    assert _normalize_rotation_enabled("yes") == "on"
    assert _normalize_rotation_enabled("1") == "on"
    assert _normalize_rotation_enabled("no") == "off"
    assert _normalize_rotation_enabled("0") == "off"
    assert _normalize_rotation_enabled("unknown") == "unknown"


def test_normalize_rotation_schedule_tuple_non_dict() -> None:
    """_normalize_rotation_schedule_tuple handles non-dict schedule value."""
    from dsk.core.diff import _normalize_rotation_schedule_tuple

    result = _normalize_rotation_schedule_tuple("daily")
    assert result == ("raw", "daily")


def test_normalize_rotation_schedule_tuple_cron() -> None:
    """_normalize_rotation_schedule_tuple extracts cron expression."""
    from dsk.core.diff import _normalize_rotation_schedule_tuple

    result = _normalize_rotation_schedule_tuple({"type": "cron", "cron": "0 0 * * *"})
    assert result == ("CRON", "0 0 * * *")


def test_normalize_rotation_schedule_tuple_cron_expression_fallback() -> None:
    """_normalize_rotation_schedule_tuple uses expression key as fallback."""
    from dsk.core.diff import _normalize_rotation_schedule_tuple

    result = _normalize_rotation_schedule_tuple({"type": "cron", "expression": "0 1 * * *"})
    assert result == ("CRON", "0 1 * * *")


def test_pam_user_managed_flag_equivalent_zero_is_false() -> None:
    """_pam_user_managed_flag_equivalent treats 0 and False as both unmanaged."""
    from dsk.core.diff import _pam_user_managed_flag_equivalent

    assert _pam_user_managed_flag_equivalent(0, False)
    assert _pam_user_managed_flag_equivalent(None, False)
    assert not _pam_user_managed_flag_equivalent(True, False)


def test_pam_user_managed_flag_equivalent_string_forms() -> None:
    """_pam_user_managed_flag_equivalent handles string 'true'/'false' etc."""
    from dsk.core.diff import _pam_user_managed_flag_equivalent

    assert _pam_user_managed_flag_equivalent("true", True)
    assert _pam_user_managed_flag_equivalent("0", False)
    assert _pam_user_managed_flag_equivalent("yes", True)


def test_vault_canonical_value_dict() -> None:
    """_vault_canonical_value converts dict to sorted tuple."""
    from dsk.core.diff import _vault_canonical_value

    result = _vault_canonical_value({"b": 2, "a": 1})
    assert isinstance(result, tuple)
    assert ("a", 1) in result


def test_vault_canonical_value_list() -> None:
    """_vault_canonical_value recursively processes list items."""
    from dsk.core.diff import _vault_canonical_value

    result = _vault_canonical_value([1, 2, {"x": 3}])
    assert isinstance(result, tuple)


def test_vault_field_entries_not_flattenable_non_mapping() -> None:
    """_vault_field_entries_are_flattenable returns False for non-dict entries."""
    from dsk.core.diff import _vault_field_entries_are_flattenable

    assert not _vault_field_entries_are_flattenable(["not_a_dict"])


def test_vault_field_entries_not_flattenable_multi_value() -> None:
    """_vault_field_entries_are_flattenable returns False when values list has >1 item."""
    from dsk.core.diff import _vault_field_entries_are_flattenable

    entries = [{"type": "login", "value": ["a", "b"]}]
    assert not _vault_field_entries_are_flattenable(entries)


def test_vault_field_entries_not_flattenable_complex_value() -> None:
    """_vault_field_entries_are_flattenable returns False for complex (dict) value."""
    from dsk.core.diff import _vault_field_entries_are_flattenable

    entries = [{"type": "login", "value": [{"nested": "dict"}]}]
    assert not _vault_field_entries_are_flattenable(entries)


def test_vault_flatten_login_field_entries_skips_no_type() -> None:
    """_vault_flatten_login_field_entries skips entries without a type."""
    from dsk.core.diff import _vault_flatten_login_field_entries

    result = _vault_flatten_login_field_entries([{"value": ["x"]}])
    assert result == {}


def test_vault_flatten_login_field_entries_skips_empty_values() -> None:
    """_vault_flatten_login_field_entries skips entries with empty values list."""
    from dsk.core.diff import _vault_flatten_login_field_entries

    result = _vault_flatten_login_field_entries([{"type": "login", "value": []}])
    assert result == {}


def test_vault_flatten_login_field_entries_skips_dict_value() -> None:
    """_vault_flatten_login_field_entries skips when value is a dict."""
    from dsk.core.diff import _vault_flatten_login_field_entries

    result = _vault_flatten_login_field_entries([{"type": "url", "value": [{"url": "http://x"}]}])
    assert result == {}


def test_field_diff_ignores_extra_live_fields() -> None:
    """_field_diff skips fields present only in live (before) but not in desired (after)."""
    from dsk.core.diff import _field_diff

    result = _field_diff({"a": 1, "extra": "live_only"}, {"a": 1})
    assert result == []


def test_field_diff_detects_changed_field() -> None:
    """_field_diff returns keys that changed between live and desired."""
    from dsk.core.diff import _field_diff

    result = _field_diff({"a": 1, "b": "old"}, {"a": 1, "b": "new"})
    assert "b" in result
    assert "a" not in result


def test_classify_orphans_delete_when_allow_delete() -> None:
    """_classify_orphans emits DELETE for unmatched owned records when allow_delete=True."""
    from dsk.core.diff import ChangeKind, _classify_orphans
    from dsk.core.interfaces import LiveRecord
    from dsk.core.metadata import encode_marker

    live = [
        LiveRecord(
            keeper_uid="ORPHAN_UID",
            title="orphaned",
            resource_type="pamMachine",
            payload={},
            marker=encode_marker(
                uid_ref="orphan.ref", manifest="test-manifest", resource_type="pamMachine"
            ),
        )
    ]
    changes = _classify_orphans(
        live, matched=set(), manifest_name="test-manifest", allow_delete=True
    )
    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.DELETE


def test_classify_orphans_conflict_when_no_delete() -> None:
    """_classify_orphans emits CONFLICT for unmatched owned records when allow_delete=False."""
    from dsk.core.diff import ChangeKind, _classify_orphans
    from dsk.core.interfaces import LiveRecord
    from dsk.core.metadata import encode_marker

    live = [
        LiveRecord(
            keeper_uid="ORPHAN_UID",
            title="orphaned",
            resource_type="pamMachine",
            payload={},
            marker=encode_marker(
                uid_ref="orphan.ref", manifest="test-manifest", resource_type="pamMachine"
            ),
        )
    ]
    changes = _classify_orphans(
        live, matched=set(), manifest_name="test-manifest", allow_delete=False
    )
    assert len(changes) == 1
    assert changes[0].kind is ChangeKind.CONFLICT


# ── Sprint BH: additional diff.py helper coverage ─────────────────────────


def test_desired_objects_with_create_mode_gateway(minimal_manifest_path) -> None:
    """_desired_objects includes pam_configurations from manifest."""
    from dsk.core import load_manifest
    from dsk.core.diff import _desired_objects

    manifest = load_manifest(minimal_manifest_path)
    objects = _desired_objects(manifest)
    resource_types = [o[1] for o in objects]
    # minimal manifest has pam_configuration
    assert "pam_configuration" in resource_types


def test_desired_objects_includes_nested_users(minimal_manifest_path) -> None:
    """_desired_objects yields nested pamUser from resources."""
    from dsk.core import load_manifest
    from dsk.core.diff import _desired_objects

    manifest = load_manifest(minimal_manifest_path)
    objects = _desired_objects(manifest)
    resource_types = [o[1] for o in objects]
    # minimal manifest has pamMachine + nested pamUser
    assert "pamMachine" in resource_types


def test_rotation_settings_equivalent_password_complexity_dict() -> None:
    """_rotation_settings_equivalent normalizes dict password_complexity to JSON."""
    from dsk.core.diff import _rotation_settings_equivalent

    live = {"enabled": True, "password_complexity": {"length": 16, "special": 2}}
    desired = {"enabled": True, "password_complexity": {"length": 16, "special": 2}}
    assert _rotation_settings_equivalent(live, desired)


def test_pam_user_managed_flag_float_zero_is_false() -> None:
    """_pam_user_managed_flag_equivalent treats float 0.0 as unmanaged."""
    from dsk.core.diff import _pam_user_managed_flag_equivalent

    assert _pam_user_managed_flag_equivalent(0.0, False)


def test_pam_user_managed_flag_unknown_string_coerces() -> None:
    """_pam_user_managed_flag_equivalent coerces non-standard truthy strings."""
    from dsk.core.diff import _pam_user_managed_flag_equivalent

    # "2" is neither 0/1/true/false, defaults to bool(str("2")) = True
    assert _pam_user_managed_flag_equivalent("2", True)


def test_field_diff_pam_user_saas_plugins_noop_equivalent() -> None:
    """_field_diff_pam_user treats None and [] for saas_plugins as equivalent (no drift)."""
    from dsk.core.diff import _field_diff_pam_user

    live = {"saas_plugins": None}
    desired = {"saas_plugins": []}
    result = _field_diff_pam_user(live, desired)
    assert "saas_plugins" not in result


def test_field_diff_pam_configuration_pam_settings_mismatch() -> None:
    """_field_diff_pam_configuration detects pam_settings mismatch."""
    from dsk.core.diff import _field_diff_pam_configuration

    live = {"pam_settings": {"options": {"port": 22}}}
    desired = {"pam_settings": {"options": {"port": 2222}}}
    result = _field_diff_pam_configuration(live, desired)
    assert "pam_settings" in result


def test_vault_canonical_field_entries_non_list_returns_empty() -> None:
    """_vault_canonical_field_entries returns [] for non-list input."""
    from dsk.core.diff import _vault_canonical_field_entries

    assert _vault_canonical_field_entries(None) == []
    assert _vault_canonical_field_entries("string") == []


def test_vault_field_entries_not_flattenable_file_ref_type() -> None:
    """_vault_field_entries_are_flattenable returns False for file ref types."""
    from dsk.core.diff import _vault_field_entries_are_flattenable

    entries = [{"type": "fileRef", "value": ["file123"]}]
    assert not _vault_field_entries_are_flattenable(entries)


def test_vault_flatten_login_multi_value_entry_skipped() -> None:
    """_vault_flatten_login_field_entries skips entries with >1 values (not simple scalar)."""
    from dsk.core.diff import _vault_flatten_login_field_entries

    # len(values) > 1 → value becomes a list → not isinstance(str/int/float/bool) → skip
    entries = [{"type": "login", "label": "username", "value": ["user1", "user2"]}]
    result = _vault_flatten_login_field_entries(entries)
    assert "username" not in result  # multi-value entries are excluded from flat map


def test_classify_desired_pam_configuration_noop() -> None:
    """_classify_desired emits NOOP for a pam_configuration when no diff fields."""
    from dsk.core.diff import ChangeKind, _classify_desired
    from dsk.core.interfaces import LiveRecord
    from dsk.core.metadata import encode_marker

    payload = {"uid_ref": "cfg.ref", "title": "MyConfig", "environment": "prod"}
    marker = encode_marker(
        uid_ref="cfg.ref", manifest="test-manifest", resource_type="pam_configuration"
    )
    live = LiveRecord(
        keeper_uid="LIVE_CFG",
        title="MyConfig",
        resource_type="pam_configuration",
        payload=payload,
        marker=marker,
    )
    change = _classify_desired(
        uid_ref="cfg.ref",
        resource_type="pam_configuration",
        title="MyConfig",
        payload=payload,
        live=live,
        by_title={},
        adopt=False,
    )
    assert change.kind is ChangeKind.NOOP
