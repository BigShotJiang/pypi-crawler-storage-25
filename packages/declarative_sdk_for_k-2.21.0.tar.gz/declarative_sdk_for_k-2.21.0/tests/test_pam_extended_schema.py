from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_CHANGES, EXIT_OK
from dsk.core import PamExtendedManifest, PamExtendedResource
from dsk.core.errors import SchemaError
from dsk.core.manifest import load_declarative_manifest
from dsk.core.models_pam_extended import load_pam_extended_manifest
from dsk.core.schema import validate_manifest

FIXTURE = (
    Path(__file__).resolve().parent / "fixtures" / "examples" / "pam-extended" / "environment.yaml"
)


def test_pam_extended_valid_loads_minimal_resource_shape() -> None:
    loaded = load_declarative_manifest(FIXTURE)

    assert isinstance(loaded, PamExtendedManifest)
    assert loaded.resources == [
        PamExtendedResource(
            name="db-admin-rotation",
            gateway_ref="gw.edge",
            rotation_policy={"type": "on-demand"},
            jit_policy={"enabled": False},
            tags={"env": "test", "owner": "platform"},
        )
    ]


def test_pam_extended_resource_missing_name_is_schema_error() -> None:
    document = {
        "schema": "keeper-pam-extended.v1",
        "resources": [
            {
                "gateway_ref": "gw.edge",
                "rotation_policy": {"type": "on-demand"},
            }
        ],
    }

    with pytest.raises(SchemaError) as exc:
        validate_manifest(document)

    assert exc.value.context["location"] == "resources/0"
    assert "name" in exc.value.reason


def test_pam_extended_validate_fixture_exits_zero() -> None:
    result = CliRunner().invoke(main, ["validate", str(FIXTURE), "--json"], catch_exceptions=False)

    assert result.exit_code == EXIT_OK, result.output
    payload = json.loads(result.output)
    assert payload["family"] == "keeper-pam-extended.v1"
    assert payload["mode"] == "schema_only"


def test_pam_extended_plan_fixture_exits_changes_present() -> None:
    result = CliRunner().invoke(main, ["plan", str(FIXTURE), "--json"], catch_exceptions=False)

    assert result.exit_code == EXIT_CHANGES, result.output
    payload = json.loads(result.output)
    assert payload["summary"]["create"] == 1
    assert payload["changes"][0]["resource_type"] == "pam_extended_resource"
    assert payload["changes"][0]["uid_ref"] == "db-admin-rotation"


def test_load_pam_extended_manifest_rejects_duplicate_gateway_uid_refs() -> None:
    """Typed guards keep gateway configuration rows unique offline."""
    row = {
        "gateway_uid_ref": "gw.duplicate",
        "network_segment": "dmz",
        "allowed_ports": [22],
        "health_check_interval_s": 120,
    }
    document = {
        "schema": "keeper-pam-extended.v1",
        "gateway_configs": [row, dict(row)],
        "resources": [],
    }
    with pytest.raises(SchemaError) as exc_info:
        load_pam_extended_manifest(document)
    assert "duplicate gateway_uid_ref" in str(exc_info.value).lower()


def test_load_pam_extended_manifest_rejects_duplicate_resource_names() -> None:
    """Planner handles must be unique across ``resources[]`` rows."""
    resource = {
        "name": "same-name",
        "gateway_ref": "gw.edge",
        "rotation_policy": {"type": "on-demand"},
        "jit_policy": {"enabled": False},
        "tags": {},
    }
    document = {
        "schema": "keeper-pam-extended.v1",
        "resources": [resource, dict(resource)],
        "gateway_configs": [],
    }
    with pytest.raises(SchemaError) as exc_info:
        load_pam_extended_manifest(document)
    assert "duplicate resource names" in str(exc_info.value).lower()
