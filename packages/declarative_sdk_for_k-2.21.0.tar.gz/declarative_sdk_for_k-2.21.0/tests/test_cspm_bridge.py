"""Tests for CSPM remediation bridge."""


def test_cspm_manifest_defaults():
    from dsk.core.models_cspm import CspmRemediationManifestV1, CspmSource

    m = CspmRemediationManifestV1(**{"schema": "cspm-remediation.v1", "name": "test"})
    assert m.schema_ == "cspm-remediation.v1"
    assert m.webhook.source == CspmSource.generic
    assert m.webhook.listen_port == 8087


def test_cspm_manifest_round_trip():
    from pathlib import Path

    import yaml

    from dsk.core.models_cspm import CspmRemediationManifestV1, RemediationAction

    example = Path(__file__).parent.parent / "examples/cspm/acme-cspm-remediation.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = CspmRemediationManifestV1(**data)
    assert manifest.webhook.source.value == "wiz"
    assert len(manifest.webhook.finding_rules) == 4
    first = manifest.webhook.finding_rules[0]
    assert first.action == RemediationAction.add_pam_gateway
    assert first.create_pr is True


def test_normalize_wiz():
    from dsk.integrations.cspm_bridge import normalize_payload

    payload = {
        "issues": [
            {
                "type": "EXPOSED_VM",
                "severity": "High",
                "resource": {"id": "aws/i-abc123"},
                "title": "Exposed VM",
            }
        ]
    }
    findings = normalize_payload(payload, "wiz")
    assert len(findings) == 1
    assert findings[0].finding_type == "EXPOSED_VM"
    assert findings[0].severity == "high"


def test_normalize_generic():
    from dsk.integrations.cspm_bridge import normalize_payload

    payload = {
        "finding_type": "STALE_CREDS",
        "severity": "critical",
        "resource_id": "rds-prod-01",
        "description": "90-day-old creds",
    }
    findings = normalize_payload(payload, "generic")
    assert len(findings) == 1
    assert findings[0].resource_id == "rds-prod-01"


def test_generate_stub():
    from dsk.integrations.cspm_bridge import CspmFinding, generate_remediation_stub

    finding = CspmFinding("EXPOSED_VM", "high", "aws/i-abc12345", "Public VM", {})
    stub = generate_remediation_stub(finding, "add_pam_gateway")
    assert stub["schema"] == "pam-environment.v1"
    assert stub["# next_action"].startswith("Review")
    assert "aws-i-abc1" in stub["resources"][0]["uid_ref"]
    assert stub["resources"][0]["# keeper_uid_hint"] == "fill in after dsk discover"


def test_normalize_wiz_findings() -> None:
    """_normalize_wiz parses Wiz issues into CspmFinding objects."""
    from dsk.integrations.cspm_bridge import normalize_payload

    payload = {
        "issues": [
            {
                "type": "VM_EXPOSED",
                "severity": "critical",
                "title": "Open port",
                "resource": {"id": "aws/i-abc123"},
            }
        ]
    }
    findings = normalize_payload(payload, "wiz")
    assert len(findings) == 1
    assert findings[0].finding_type == "VM_EXPOSED"
    assert findings[0].severity == "critical"
    assert findings[0].resource_id == "aws/i-abc123"


def test_normalize_orca_findings() -> None:
    """_normalize_orca parses Orca alerts into CspmFinding objects."""
    from dsk.integrations.cspm_bridge import normalize_payload

    payload = {
        "alerts": [
            {
                "category": "STORAGE_EXPOSED",
                "severity_level": "high",
                "asset_unique_id": "azure/bucket-prod",
                "description": "Public bucket",
            }
        ]
    }
    findings = normalize_payload(payload, "orca")
    assert len(findings) == 1
    assert findings[0].finding_type == "STORAGE_EXPOSED"
    assert findings[0].resource_id == "azure/bucket-prod"


def test_verify_hmac_valid() -> None:
    """verify_hmac returns True for a correctly signed payload."""
    import hashlib
    import hmac as hmac_lib

    from dsk.integrations.cspm_bridge import verify_hmac

    body = b"test payload"
    secret = "my-webhook-secret"
    sig = "sha256=" + hmac_lib.new(secret.encode(), body, hashlib.sha256).hexdigest()
    assert verify_hmac(body, sig, secret) is True


def test_verify_hmac_invalid() -> None:
    """verify_hmac returns False for a tampered payload."""
    from dsk.integrations.cspm_bridge import verify_hmac

    assert verify_hmac(b"tampered", "sha256=badbadbad", "secret") is False
