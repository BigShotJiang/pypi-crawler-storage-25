"""Tests for the split Service Mode transport mixin."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

import dsk.providers.commander_cli as commander_cli
from dsk.core.errors import CapabilityError
from dsk.providers.commander_cli import CommanderCliProvider


def _provider(monkeypatch: pytest.MonkeyPatch, **kwargs: object) -> CommanderCliProvider:
    monkeypatch.setattr(commander_cli.shutil, "which", lambda _bin: "/usr/bin/keeper")
    return CommanderCliProvider(folder_uid="MARKERS", **kwargs)


def test_service_mode_requires_api_key_without_injected_client(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _provider(monkeypatch, service_mode=True, service_api_key=None)

    with pytest.raises(CapabilityError, match="API key"):
        provider._get_service_mode_client(require_api_key=True)


def test_service_mode_unknown_status_fails_closed(monkeypatch: pytest.MonkeyPatch) -> None:
    class FakeClient:
        def _request_json(self, _method: str, _path: str) -> dict[str, str]:
            return {"status": "ok"}

        def _post_async(self, _command: str, _filedata: object) -> str:
            return "REQ1"

        def _poll_status(self, _request_id: str, _timeout: int) -> dict[str, str]:
            return {"status": "mystery"}

    provider = _provider(
        monkeypatch,
        service_mode=True,
        service_api_key="api-key",
        service_client=FakeClient(),
    )

    with pytest.raises(CapabilityError, match="unknown status"):
        provider._run_service_mode_cmd(["enterprise-info"])


def test_service_start_without_keeper_binary_is_structured_rejection(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _provider(monkeypatch, service_mode=True)
    provider._service_autostart = True
    provider._bin_path = None

    with pytest.raises(CapabilityError) as exc:
        provider._start_service_mode()

    assert "keeper CLI is not on PATH" in exc.value.reason
    assert "set KEEPER_SERVICE_URL" in (exc.value.next_action or "")


def test_service_start_failure_preserves_tail_context(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider(monkeypatch, service_mode=True)
    provider._service_autostart = True
    monkeypatch.setattr(
        "dsk.providers._commander_mixins.transport_service_mode.subprocess.run",
        lambda *_args, **_kwargs: SimpleNamespace(
            returncode=1,
            stdout="out" * 2000,
            stderr="err" * 2000,
        ),
    )

    with pytest.raises(CapabilityError) as exc:
        provider._start_service_mode()

    assert "service-start failed" in exc.value.reason
    assert len(exc.value.context["stdout"]) <= 4000
    assert len(exc.value.context["stderr"]) <= 4000
