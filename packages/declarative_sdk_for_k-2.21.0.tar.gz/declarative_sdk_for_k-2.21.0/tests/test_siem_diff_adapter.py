"""Tests for dsk.core.ir_adapters — offline IR adapter helpers.

All tests are fully offline: no network, no Commander, no Pydantic models.
"""

from __future__ import annotations

from datetime import datetime

from dsk.core.ir_adapters import (
    AsyncRotationStub,
    BuildVsRuntimeClass,
    SiemReconcileResult,
    classify_secret,
    reconcile_siem_manifest,
    schedule_rotation,
)

# ---------------------------------------------------------------------------
# reconcile_siem_manifest
# ---------------------------------------------------------------------------


def test_reconcile_both_empty_zero_drift() -> None:
    """Both expected and actual empty → all lists empty, drift == 0.0."""
    result = reconcile_siem_manifest({}, {})
    assert isinstance(result, SiemReconcileResult)
    assert result.new_streams == []
    assert result.removed_streams == []
    assert result.modified_streams == []
    assert result.drift_score == 0.0


def test_reconcile_actual_has_extra_stream() -> None:
    """actual has 1 stream not in expected → new_streams=[uid], drift > 0."""
    expected_doc: dict = {}
    actual_doc = {"sinks": [{"uid_ref": "sink-extra", "type": "splunk", "endpoint": "https://x"}]}
    result = reconcile_siem_manifest(expected_doc, actual_doc, manifest_name="test-siem")
    assert result.new_streams == ["sink-extra"]
    assert result.removed_streams == []
    assert result.drift_score > 0.0
    assert result.manifest_name == "test-siem"


def test_reconcile_actual_missing_stream() -> None:
    """actual is missing 1 stream that expected has → removed_streams=[uid]."""
    expected_doc = {"sinks": [{"uid_ref": "sink-gone", "type": "datadog", "endpoint": "https://y"}]}
    actual_doc: dict = {}
    result = reconcile_siem_manifest(expected_doc, actual_doc)
    assert result.removed_streams == ["sink-gone"]
    assert result.new_streams == []
    assert result.drift_score == 1.0


# ---------------------------------------------------------------------------
# classify_secret
# ---------------------------------------------------------------------------


def test_classify_rotation_enabled_is_runtime() -> None:
    """rotation_settings.enabled='on' → RUNTIME."""
    resource = {"rotation_settings": {"enabled": "on", "schedule": "daily"}}
    assert classify_secret(resource) is BuildVsRuntimeClass.RUNTIME


def test_classify_ci_secret_class_is_build() -> None:
    """secret_class starting with 'ci-' → BUILD."""
    resource = {"secret_class": "ci-test", "title": "pipeline token"}
    assert classify_secret(resource) is BuildVsRuntimeClass.BUILD


def test_classify_build_prefix_secret_class_is_build() -> None:
    """secret_class starting with 'build-' → BUILD."""
    resource = {"secret_class": "build-artifact-key"}
    assert classify_secret(resource) is BuildVsRuntimeClass.BUILD


def test_classify_no_class_no_rotation_is_hybrid() -> None:
    """No secret_class, no rotation settings → HYBRID."""
    resource = {"title": "generic secret"}
    assert classify_secret(resource) is BuildVsRuntimeClass.HYBRID


# ---------------------------------------------------------------------------
# schedule_rotation / AsyncRotationStub
# ---------------------------------------------------------------------------


def test_schedule_rotation_returns_pending_stub() -> None:
    """schedule_rotation returns AsyncRotationStub with status='pending'."""
    stub = schedule_rotation("secret-uid-001")
    assert isinstance(stub, AsyncRotationStub)
    assert stub.uid_ref == "secret-uid-001"
    assert stub.status == "pending"
    assert stub.error is None


def test_schedule_rotation_scheduled_at_is_iso8601() -> None:
    """scheduled_at is a parseable ISO8601 datetime string."""
    stub = schedule_rotation("secret-uid-002", delay_seconds=60)
    assert stub.scheduled_at
    # Must parse without exception; fromisoformat handles offset-aware strings.
    parsed = datetime.fromisoformat(stub.scheduled_at)
    assert parsed.tzinfo is not None  # should be timezone-aware
