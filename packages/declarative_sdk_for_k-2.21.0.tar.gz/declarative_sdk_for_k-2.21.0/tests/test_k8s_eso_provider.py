from __future__ import annotations

import json
import subprocess
from typing import Any
from unittest.mock import patch

import pytest

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_k8s_eso import K8S_ESO_FAMILY, K8sEsoManifestV1
from dsk.providers.k8s_eso_provider import _KUBECTL_TIMEOUT_SECONDS, K8sEsoProvider


def _manifest() -> K8sEsoManifestV1:
    return K8sEsoManifestV1.model_validate(
        {
            "schema": K8S_ESO_FAMILY,
            "eso_stores": [
                {
                    "name": "keeper-prod",
                    "ks_uid": "ksm-config-secret",
                    "namespace": "external-secrets",
                }
            ],
            "external_secrets": [
                {
                    "name": "database-credentials",
                    "store_ref": "keeper-prod",
                    "target_k8s_secret": "database-credentials",
                    "data": [
                        {
                            "keeper_uid_ref": "ABC123",
                            "remote_key": "password",
                            "property": "password",
                        }
                    ],
                }
            ],
        }
    )


def test_plan_returns_create_when_kubectl_unavailable() -> None:
    provider = K8sEsoProvider()

    with patch(
        "dsk.providers.k8s_eso_provider.subprocess.run",
        side_effect=FileNotFoundError,
    ):
        plan = provider.plan(_manifest())

    assert len(plan.creates) == 2
    assert {change.resource_type for change in plan.creates} == {
        "ClusterSecretStore",
        "ExternalSecret",
    }


def test_apply_dry_run_uses_kubectl_dry_run_flag() -> None:
    provider = K8sEsoProvider()
    with patch(
        "dsk.providers.k8s_eso_provider.subprocess.run",
        side_effect=FileNotFoundError,
    ):
        plan = provider.plan(_manifest())

    completed = subprocess.CompletedProcess(args=[], returncode=0)
    with patch(
        "dsk.providers.k8s_eso_provider.subprocess.run",
        return_value=completed,
    ) as run:
        outcomes = provider.apply(plan, dry_run=True)

    assert outcomes
    assert any("--dry-run=client" in call.args[0] for call in run.call_args_list)


def test_apply_timeout_raises_capability_error() -> None:
    provider = K8sEsoProvider()
    with patch(
        "dsk.providers.k8s_eso_provider.subprocess.run",
        side_effect=FileNotFoundError,
    ):
        plan = provider.plan(_manifest())

    def timeout_run(*_args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        assert kwargs["timeout"] == _KUBECTL_TIMEOUT_SECONDS
        raise subprocess.TimeoutExpired(cmd=["kubectl", "apply"], timeout=_KUBECTL_TIMEOUT_SECONDS)

    with patch("dsk.providers.k8s_eso_provider.subprocess.run", side_effect=timeout_run):
        with pytest.raises(CapabilityError, match="kubectl apply timed out"):
            provider.apply(plan, dry_run=True)


def test_plan_diffs_existing_resource() -> None:
    provider = K8sEsoProvider()
    live_external_secret = {
        "apiVersion": "external-secrets.io/v1",
        "kind": "ExternalSecret",
        "metadata": {
            "name": "database-credentials",
            "namespace": "external-secrets",
            "resourceVersion": "123",
        },
        "spec": {
            "secretStoreRef": {"name": "keeper-prod", "kind": "ClusterSecretStore"},
            "target": {"name": "old-database-credentials", "creationPolicy": "Owner"},
            "data": [
                {
                    "secretKey": "password",
                    "remoteRef": {"key": "ABC123", "property": "password"},
                }
            ],
        },
        "status": {"refreshTime": "ignored"},
    }

    def fake_run(args: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:  # noqa: ARG001
        if "externalsecret" in args:
            return subprocess.CompletedProcess(
                args=args,
                returncode=0,
                stdout=json.dumps({"items": [live_external_secret]}),
            )
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps({"items": []})
        )

    with patch("dsk.providers.k8s_eso_provider.subprocess.run", side_effect=fake_run):
        plan = provider.plan(_manifest())

    external_secret_change = next(
        change for change in plan.changes if change.resource_type == "ExternalSecret"
    )
    assert external_secret_change.kind is ChangeKind.UPDATE
    assert external_secret_change.before["spec"]["target"]["name"] == "old-database-credentials"
    assert external_secret_change.after["spec"]["target"]["name"] == "database-credentials"


def test_apply_full_run_calls_kubectl_apply() -> None:
    provider = K8sEsoProvider()
    with patch(
        "dsk.providers.k8s_eso_provider.subprocess.run",
        side_effect=FileNotFoundError,
    ):
        plan = provider.plan(_manifest())

    completed = subprocess.CompletedProcess(args=[], returncode=0)
    with patch(
        "dsk.providers.k8s_eso_provider.subprocess.run",
        return_value=completed,
    ) as run:
        outcomes = provider.apply(plan, dry_run=False)

    assert outcomes
    apply_calls = [c for c in run.call_args_list if "apply" in c.args[0]]
    assert apply_calls, "kubectl apply must be called for a non-dry-run"
    assert "--dry-run=client" not in apply_calls[0].args[0]


def test_plan_resource_types_are_cluster_store_and_external_secret() -> None:
    provider = K8sEsoProvider()
    with patch(
        "dsk.providers.k8s_eso_provider.subprocess.run",
        side_effect=FileNotFoundError,
    ):
        plan = provider.plan(_manifest())

    resource_types = {c.resource_type for c in plan.changes}
    assert "ClusterSecretStore" in resource_types
    assert "ExternalSecret" in resource_types
