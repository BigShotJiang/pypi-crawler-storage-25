"""Plan/mock-apply routing for ``ai-agent.v1``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from click.testing import CliRunner

from dsk.cli.main import main
from dsk.core.ai_agent_diff import compute_ai_agent_diff
from dsk.core.diff import ChangeKind
from dsk.core.models_ai_agent import AI_AGENT_FAMILY, AiAgentManifest
from dsk.core.planner import build_plan
from dsk.providers.mock import MockProvider


def _ai_doc() -> dict[str, Any]:
    return {
        "schema": AI_AGENT_FAMILY,
        "resources": [
            {
                "uid_ref": "ai.support.l1",
                "name": "l1-helper",
                "purpose": "answer product FAQs",
                "scope": ["public-docs"],
                "allowed_tools": ["search"],
            },
        ],
    }


def _ai_two_resources_doc() -> dict[str, Any]:
    return {
        "schema": AI_AGENT_FAMILY,
        "resources": [
            {
                "uid_ref": "ai.support.l1",
                "name": "l1-helper",
                "purpose": "answer product FAQs",
                "scope": ["public-docs"],
                "allowed_tools": ["search"],
            },
            {
                "uid_ref": "ai.sec.review",
                "name": "review-bot",
                "purpose": "triage tickets",
                "scope": ["tickets-internal"],
                "allowed_tools": ["read"],
            },
        ],
    }


def _ai_empty_resources_doc() -> dict[str, Any]:
    return {"schema": AI_AGENT_FAMILY, "resources": []}


def test_ai_agent_manifest_and_cli_plan_shows_create_row(tmp_path: Path) -> None:
    manifest = AiAgentManifest.model_validate(_ai_doc())
    changes = compute_ai_agent_diff(
        manifest,
        None,
        manifest_name="lab-ai",
        allow_delete=False,
    )
    assert len(changes) == 1
    assert changes[0].kind == ChangeKind.CREATE and changes[0].resource_type == "ai_agent"

    path = tmp_path / "ai-agent-manifest.json"
    path.write_text(json.dumps(_ai_doc()), encoding="utf-8")
    result = CliRunner().invoke(main, ["plan", str(path), "--json"], catch_exceptions=False)
    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["summary"]["create"] == 1


def test_mock_apply_ai_agent_returns_outcomes() -> None:
    manifest = AiAgentManifest.model_validate(_ai_doc())
    changes = compute_ai_agent_diff(manifest, None, manifest_name="t", allow_delete=False)
    plan = build_plan(
        "t",
        changes,
        [r.uid_ref for r in manifest.resources],
    )
    outcomes = MockProvider("t").apply_ai_agent_plan(plan, dry_run=False)
    assert len(outcomes) == 1 and outcomes[0].action == "create"
    assert outcomes[0].details.get("family") == "ai-agent.v1"


def test_ai_agent_diff_multiple_resources_multiple_creates(tmp_path: Path) -> None:
    manifest = AiAgentManifest.model_validate(_ai_two_resources_doc())
    changes = compute_ai_agent_diff(
        manifest,
        None,
        manifest_name="lab-ai-multi",
        allow_delete=False,
    )
    assert len(changes) == 2
    assert all(c.kind == ChangeKind.CREATE and c.resource_type == "ai_agent" for c in changes)
    assert {c.uid_ref for c in changes} == {"ai.support.l1", "ai.sec.review"}

    path = tmp_path / "ai-multi.json"
    path.write_text(json.dumps(_ai_two_resources_doc()), encoding="utf-8")
    result = CliRunner().invoke(main, ["plan", str(path), "--json"], catch_exceptions=False)
    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["summary"]["create"] == 2


def test_ai_agent_diff_empty_resources_no_changes(tmp_path: Path) -> None:
    manifest = AiAgentManifest.model_validate(_ai_empty_resources_doc())
    changes = compute_ai_agent_diff(manifest, None, manifest_name="empty", allow_delete=False)
    assert changes == []

    path = tmp_path / "ai-empty.json"
    path.write_text(json.dumps(_ai_empty_resources_doc()), encoding="utf-8")
    result = CliRunner().invoke(main, ["plan", str(path), "--json"], catch_exceptions=False)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["summary"]["create"] == 0


def test_ai_agent_allow_delete_no_live_no_delete_changes() -> None:
    manifest = AiAgentManifest.model_validate(_ai_doc())
    changes = compute_ai_agent_diff(
        manifest,
        None,
        manifest_name="t",
        allow_delete=True,
    )
    deletes = [c for c in changes if c.kind == ChangeKind.DELETE]
    assert deletes == []
    assert len(changes) == 1 and changes[0].kind == ChangeKind.CREATE


def test_mock_apply_ai_agent_dry_run_still_reports_create_actions() -> None:
    manifest = AiAgentManifest.model_validate(_ai_doc())
    changes = compute_ai_agent_diff(manifest, None, manifest_name="t", allow_delete=False)
    plan = build_plan(
        "t",
        changes,
        [r.uid_ref for r in manifest.resources],
    )
    outcomes = MockProvider("t").apply_ai_agent_plan(plan, dry_run=True)
    assert len(outcomes) == 1 and outcomes[0].action == "create"
    assert outcomes[0].details.get("dry_run") is True
    assert outcomes[0].details.get("family") == "ai-agent.v1"
