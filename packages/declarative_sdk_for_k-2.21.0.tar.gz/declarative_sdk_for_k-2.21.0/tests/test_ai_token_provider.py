"""REST provider tests for ``ai-token.v1``."""

from __future__ import annotations

from typing import Any

import pytest

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_ai_token import AiTokenManifestV1
from dsk.providers.ai_token_provider import AiTokenProvider


def _manifest() -> AiTokenManifestV1:
    return AiTokenManifestV1.model_validate(
        {
            "schema": "ai-token.v1",
            "name": "ai-tokens",
            "tokens": [{"name": "agent-read", "agent_uid_ref": "nhi.agent"}],
        }
    )


def test_ai_token_provider_plan_returns_diff() -> None:
    provider = AiTokenProvider(endpoint_base="/ai/tokens")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"tokens": []}
    }

    plan = provider.plan(_manifest())

    assert plan.changes[0].kind is ChangeKind.CREATE
    assert plan.changes[0].resource_type == "ai_capability_token"
    assert plan.changes[0].title == "agent-read"


def test_ai_token_provider_apply_calls_configured_endpoint() -> None:
    calls: list[tuple[str, dict[str, Any]]] = []
    provider = AiTokenProvider(endpoint_base="/ai/tokens")

    def fake_rest(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append((endpoint, payload))
        if payload["method"] == "GET":
            return {"configuration": {"tokens": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())

    provider.apply_ai_token_plan(plan)

    assert calls[-1][0] == "ai/tokens"
    assert calls[-1][1]["method"] == "PUT"
    assert calls[-1][1]["configuration"]["tokens"][0]["name"] == "agent-read"


def test_ai_token_provider_unknown_endpoint_raises_capability_error() -> None:
    provider = AiTokenProvider()

    with pytest.raises(CapabilityError) as exc:
        provider.plan(_manifest())

    assert "endpoint is not confirmed" in exc.value.reason


def test_ai_token_provider_plan_noop_when_live_matches() -> None:
    provider = AiTokenProvider(endpoint_base="/ai/tokens")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"tokens": [{"name": "agent-read", "agent_uid_ref": "nhi.agent"}]}
    }
    plan = provider.plan(_manifest())
    assert not any(c.kind in (ChangeKind.CREATE, ChangeKind.UPDATE) for c in plan.changes)


def test_ai_token_provider_apply_dry_run_skips_put() -> None:
    calls: list[dict[str, Any]] = []
    provider = AiTokenProvider(endpoint_base="/ai/tokens")

    def fake_rest(_endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append(payload)
        if payload["method"] == "GET":
            return {"configuration": {"tokens": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())
    provider.apply_ai_token_plan(plan, dry_run=True)
    assert not any(p.get("method") == "PUT" for p in calls)


def test_ai_token_provider_plan_create_when_live_empty() -> None:
    provider = AiTokenProvider(endpoint_base="/ai/tokens")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"tokens": []}
    }
    plan = provider.plan(_manifest())
    assert any(c.kind is ChangeKind.CREATE for c in plan.changes)


def test_ai_token_provider_apply_returns_create_outcome() -> None:
    provider = AiTokenProvider(endpoint_base="/ai/tokens")

    def fake_rest(_endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        if payload["method"] == "GET":
            return {"configuration": {"tokens": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())
    outcomes = provider.apply_ai_token_plan(plan)
    assert outcomes[0].action == "create"
