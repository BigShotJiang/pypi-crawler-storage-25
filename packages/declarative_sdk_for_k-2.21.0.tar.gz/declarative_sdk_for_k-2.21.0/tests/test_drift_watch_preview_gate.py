"""Drift-watch CLI: DSK_PREVIEW substring gate (``drift-watch`` token)."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.cmd_drift_watch import _PREVIEW_GATE_ERROR


def _manifest_file(tmp_path: Path) -> Path:
    path = tmp_path / "pam.yaml"
    path.write_text("schema: pam-environment.v1\nname: drift-gate-test\n", encoding="utf-8")
    return path


def test_drift_watch_unset_preview_refuses_with_gate_message(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("DSK_PREVIEW", raising=False)
    mf = _manifest_file(tmp_path)
    result = CliRunner().invoke(main, ["drift-watch", str(mf)], catch_exceptions=False)
    assert result.exit_code != 0
    combined = (result.stdout or "") + (result.stderr or "")
    assert _PREVIEW_GATE_ERROR in combined


def test_drift_watch_generic_preview_still_refuses(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("DSK_PREVIEW", "1")
    mf = _manifest_file(tmp_path)
    result = CliRunner().invoke(main, ["drift-watch", str(mf)], catch_exceptions=False)
    assert result.exit_code != 0
    combined = (result.stdout or "") + (result.stderr or "")
    assert _PREVIEW_GATE_ERROR in combined


def test_drift_watch_preview_token_passes_gate_and_calls_watch_loop(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("DSK_PREVIEW", "drift-watch")
    seen: list[object] = []

    def fake_watch_loop(cfg: object) -> None:
        seen.append(cfg)

    monkeypatch.setattr("dsk.daemon.drift_watch.watch_loop", fake_watch_loop)
    mf = _manifest_file(tmp_path)
    result = CliRunner().invoke(main, ["drift-watch", str(mf)], catch_exceptions=False)
    assert result.exit_code == 0
    assert len(seen) == 1
    cfg = seen[0]
    assert getattr(cfg, "manifest_paths", None) == [str(mf)]
