"""Lock CommanderLibraryProvider public interface to CommanderServiceProvider (Wave 2 scaffold)."""

from __future__ import annotations

import inspect
import sys
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.interfaces import ApplyOutcome, LiveRecord
from dsk.core.planner import Plan
from dsk.providers.commander_library_provider import CommanderLibraryProvider
from dsk.providers.commander_service import CommanderServiceProvider


def _public_callable_names(cls: type[Any]) -> set[str]:
    names: set[str] = set()
    for name, _ in inspect.getmembers(cls, predicate=inspect.isfunction):
        if name.startswith("_") and name != "__init__":
            continue
        names.add(name)
    return names


def test_interface_public_methods_match() -> None:
    lib = _public_callable_names(CommanderLibraryProvider)
    svc = _public_callable_names(CommanderServiceProvider)
    missing = svc - lib
    assert not missing, f"CommanderLibraryProvider missing public methods: {sorted(missing)}"


def test_interface_signatures_match() -> None:
    for name in sorted(_public_callable_names(CommanderServiceProvider)):
        lib_m = getattr(CommanderLibraryProvider, name)
        svc_m = getattr(CommanderServiceProvider, name)
        lib_sig = inspect.signature(lib_m)
        svc_sig = inspect.signature(svc_m)
        assert list(lib_sig.parameters.keys()) == list(svc_sig.parameters.keys()), (
            f"{name}: parameter names differ — lib={list(lib_sig.parameters.keys())} "
            f"svc={list(svc_sig.parameters.keys())}"
        )
        for pname, svc_p in svc_sig.parameters.items():
            lib_p = lib_sig.parameters[pname]
            assert lib_p.annotation == svc_p.annotation, f"{name}.{pname}: annotation mismatch"
        assert lib_sig.return_annotation == svc_sig.return_annotation, f"{name}: return mismatch"


def test_scaffold_raises_not_implemented() -> None:
    msg_fragment = "CommanderLibraryProvider scaffold"
    with pytest.raises(NotImplementedError, match=msg_fragment):
        CommanderLibraryProvider(api_key="token")

    inst = CommanderLibraryProvider.__new__(CommanderLibraryProvider)

    plan = Plan(manifest_name="m")

    with pytest.raises(NotImplementedError, match=msg_fragment):
        inst.discover()
    with pytest.raises(NotImplementedError, match=msg_fragment):
        inst.apply_plan(plan)
    with pytest.raises(NotImplementedError, match=msg_fragment):
        inst.apply_plan(plan, dry_run=True)
    with pytest.raises(NotImplementedError, match=msg_fragment):
        inst.unsupported_capabilities()
    with pytest.raises(NotImplementedError, match=msg_fragment):
        inst.unsupported_capabilities({})
    with pytest.raises(NotImplementedError, match=msg_fragment):
        inst.check_tenant_bindings()
    with pytest.raises(NotImplementedError, match=msg_fragment):
        inst.check_tenant_bindings({})


def test_public_methods_have_docstrings() -> None:
    for name in sorted(_public_callable_names(CommanderServiceProvider)):
        doc = getattr(CommanderLibraryProvider, name).__doc__
        assert doc is not None and doc.strip(), f"{name} is missing a non-empty docstring"


def test_module_docstring_warns() -> None:
    module = sys.modules[CommanderLibraryProvider.__module__]
    doc = (module.__doc__ or "").lower()
    assert "gated" in doc
    assert "operator" in doc


class _FakeWave2Adapter:
    def __init__(self) -> None:
        self.applied: list[tuple[Plan, bool, dict[str, Any]]] = []

    def discover(self) -> list[LiveRecord]:
        return [
            LiveRecord(
                keeper_uid="UID1",
                title="Record",
                resource_type="login",
                payload={"title": "Record"},
            )
        ]

    def apply_plan(
        self,
        plan: Plan,
        *,
        dry_run: bool = False,
        manifest_source: dict[str, Any] | None = None,
    ) -> list[ApplyOutcome]:
        self.applied.append((plan, dry_run, manifest_source or {}))
        return [
            ApplyOutcome(
                uid_ref="record.one",
                keeper_uid="UID1",
                action="update",
                details={"dry_run": dry_run},
            )
        ]

    def unsupported_capabilities(self, manifest: Any = None) -> list[str]:
        return ["unsupported from fake"] if manifest else []

    def check_tenant_bindings(self, manifest: Any = None) -> list[str]:
        return ["binding from fake"] if manifest else []


def test_wave2_live_path_delegates_to_adapter(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_WAVE2_LIVE", "1")
    adapter = _FakeWave2Adapter()
    provider = CommanderLibraryProvider(
        api_key="token",
        manifest_source={"schema": "keeper-vault.v1"},
        client=adapter,  # type: ignore[arg-type]
    )

    assert provider.discover()[0].keeper_uid == "UID1"
    plan = Plan(
        manifest_name="m",
        changes=[
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="record.one",
                resource_type="login",
                title="Record",
                keeper_uid="UID1",
            )
        ],
    )
    outcomes = provider.apply_plan(plan, dry_run=True)

    assert outcomes == [
        ApplyOutcome(
            uid_ref="record.one",
            keeper_uid="UID1",
            action="update",
            details={"dry_run": True},
        )
    ]
    assert adapter.applied == [(plan, True, {"schema": "keeper-vault.v1"})]


def test_wave2_live_path_delegates_capability_and_binding_checks(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DSK_WAVE2_LIVE", "1")
    provider = CommanderLibraryProvider(
        api_key="token",
        client=_FakeWave2Adapter(),  # type: ignore[arg-type]
    )

    assert provider.unsupported_capabilities({"records": []}) == ["unsupported from fake"]
    assert provider.check_tenant_bindings({"records": []}) == ["binding from fake"]
