"""Plan/apply routing for ``keeper-privileged-access.v1``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli.main import main
from dsk.core import load_declarative_manifest
from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.manifest import load_declarative_manifest_string
from dsk.core.models_privileged_access import (
    PRIVILEGED_ACCESS_FAMILY,
    PrivilegedAccessManifestV1,
)
from dsk.core.planner import build_plan
from dsk.core.privileged_access_diff import compute_privileged_access_diff
from dsk.providers.commander_cli import CommanderCliProvider


def _privileged_doc() -> dict[str, Any]:
    return {
        "schema": PRIVILEGED_ACCESS_FAMILY,
        "users": [
            {"uid_ref": "priv.user.admin", "principal": "alice", "provider": "aws"},
        ],
        "groups": [{"uid_ref": "priv.gr.ops", "name": "Operators", "provider": "aws"}],
        "group_memberships": [
            {
                "uid_ref": "priv.mem.admops",
                "user_uid_ref": "keeper-privileged-access:users:priv.user.admin",
                "group_uid_ref": "keeper-privileged-access:groups:priv.gr.ops",
            }
        ],
    }


def test_privileged_manifest_load_round_trip_and_diff_three_creates(tmp_path: Path) -> None:
    path = tmp_path / "privileged.json"
    path.write_text(json.dumps(_privileged_doc()), encoding="utf-8")

    typed = load_declarative_manifest(path)
    assert isinstance(typed, PrivilegedAccessManifestV1)

    raw = json.dumps(_privileged_doc())
    typed_alt = load_declarative_manifest_string(raw, suffix=".json")
    assert typed_alt.users[0].uid_ref == typed.users[0].uid_ref

    changes = compute_privileged_access_diff(
        typed,
        {},
        manifest_name="lab-privileged",
        allow_delete=False,
    )
    kinds = {(c.uid_ref, c.resource_type, c.kind) for c in changes}
    assert kinds == {
        ("priv.user.admin", "privileged_user", ChangeKind.CREATE),
        ("priv.gr.ops", "privileged_group", ChangeKind.CREATE),
        ("priv.mem.admops", "privileged_group_membership", ChangeKind.CREATE),
    }


def test_cli_plan_mock_json_reports_three_creates(tmp_path: Path) -> None:
    path = tmp_path / "pa.json"
    path.write_text(json.dumps(_privileged_doc()), encoding="utf-8")

    result = CliRunner().invoke(main, ["plan", str(path), "--json"], catch_exceptions=False)

    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["manifest_name"] == path.stem
    assert payload["summary"]["create"] == 3


def test_commander_provider_refuses_declarative_privileged_access_apply(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _b: "/usr/bin/keeper",
    )
    doc = _privileged_doc()
    provider = CommanderCliProvider(folder_uid="folder-x", manifest_source=doc)

    manifest = PrivilegedAccessManifestV1.model_validate(doc)
    changes = compute_privileged_access_diff(manifest, {}, manifest_name="t")
    order = [u for u, _ in manifest.iter_uid_refs()]
    plan = build_plan("t", changes, order)

    with pytest.raises(CapabilityError) as direct_exc:
        provider.apply_privileged_access_plan(plan)

    na = direct_exc.value.next_action or ""
    assert "keeper pam tunnel" in na.lower() and "keeper pam access" in na.lower()
    assert "operation-first" in na.lower() and "not declarative-shaped" in na.lower()

    with pytest.raises(CapabilityError):
        provider.apply_plan(plan)


def test_privileged_access_diff_empty_manifest_returns_no_changes() -> None:
    empty = {
        "schema": PRIVILEGED_ACCESS_FAMILY,
        "users": [],
        "groups": [],
        "group_memberships": [],
    }
    manifest = PrivilegedAccessManifestV1.model_validate(empty)
    assert compute_privileged_access_diff(manifest, {}, manifest_name="empty-pa") == []


def test_privileged_access_diff_manifest_name_on_each_change() -> None:
    manifest = PrivilegedAccessManifestV1.model_validate(_privileged_doc())
    changes = compute_privileged_access_diff(manifest, {}, manifest_name="ledger-name")
    assert changes
    assert {c.manifest_name for c in changes} == {"ledger-name"}


def test_privileged_access_diff_rejects_non_empty_live_snapshot() -> None:
    manifest = PrivilegedAccessManifestV1.model_validate(_privileged_doc())
    with pytest.raises(NotImplementedError, match="live readback"):
        compute_privileged_access_diff(manifest, {"users": []})
