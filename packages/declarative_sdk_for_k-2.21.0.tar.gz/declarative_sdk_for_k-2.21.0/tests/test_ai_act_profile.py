"""Tests for EU AI Act compliance profile manifest models."""

from pathlib import Path

import yaml


def test_ai_act_defaults():
    from dsk.core.models_ai_act import AiActProfileManifestV1, AiActRiskTier

    m = AiActProfileManifestV1(**{"schema": "ai-act-profile.v1", "name": "test"})
    assert m.schema_ == "ai-act-profile.v1"
    assert m.risk_tier == AiActRiskTier.high_risk
    assert m.enforcement_deadline == "2026-08-02"
    assert m.controls == []
    assert m.logging_requirements == []


def test_ai_act_round_trip():
    from dsk.core.models_ai_act import (
        AiActAnnexIiiCategory,
        AiActArticleStatus,
        AiActProfileManifestV1,
        AiActRiskTier,
    )

    example = Path(__file__).parent.parent / "examples/ai_act/acme-ai-act-profile.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = AiActProfileManifestV1(**data)
    assert manifest.schema_ == "ai-act-profile.v1"
    assert manifest.risk_tier == AiActRiskTier.high_risk
    assert manifest.annex_iii_category == AiActAnnexIiiCategory.essential_services
    assert len(manifest.controls) == 4
    assert len(manifest.logging_requirements) == 2
    assert len(manifest.oversight_gates) == 1
    art9 = manifest.controls[0]
    assert art9.article == "art-9"
    assert art9.status == AiActArticleStatus.compliant
    assert "ai-token.v1" in art9.dsk_families_used
    partial = manifest.controls[2]
    assert partial.status == AiActArticleStatus.partially_compliant
    assert partial.remediation_note is not None
    na = manifest.controls[3]
    assert na.status == AiActArticleStatus.not_applicable


def test_ai_act_logging_defaults():
    from dsk.core.models_ai_act import AiActLoggingRequirement

    req = AiActLoggingRequirement(uid_ref="mcp.test")
    assert req.retain_days == 365
    assert req.log_inputs is True
    assert req.log_credential_access is True


def test_ai_act_oversight_gate():
    from dsk.core.models_ai_act import AiActOversightGate

    gate = AiActOversightGate(name="test", ai_system_uid_ref="mcp.test")
    assert gate.override_allowed is True
    assert gate.stop_button is True


def test_ai_act_schema_alias():
    from dsk.core.models_ai_act import AiActProfileManifestV1

    m = AiActProfileManifestV1(**{"schema": "ai-act-profile.v1", "name": "t"})
    assert m.schema_ == "ai-act-profile.v1"


def test_compute_ai_act_diff_raises_on_live() -> None:
    """compute_ai_act_diff must raise NotImplementedError when live snapshot is provided."""
    import pytest

    from dsk.core.ai_act_diff import compute_ai_act_diff
    from dsk.core.models_ai_act import AiActProfileManifestV1

    manifest = AiActProfileManifestV1(**{"schema": "ai-act-profile.v1", "name": "t"})
    with pytest.raises(NotImplementedError, match="live readback not implemented"):
        compute_ai_act_diff(manifest, live={"some": "data"})


def test_compute_ai_act_diff_empty_manifest_returns_no_changes() -> None:
    """compute_ai_act_diff with no requirements/gates/controls returns empty list."""
    from dsk.core.ai_act_diff import compute_ai_act_diff
    from dsk.core.models_ai_act import AiActProfileManifestV1

    manifest = AiActProfileManifestV1(**{"schema": "ai-act-profile.v1", "name": "empty"})
    changes = compute_ai_act_diff(manifest, live=None)
    assert changes == []


def test_compute_ai_act_diff_gate_resource_type() -> None:
    """compute_ai_act_diff must emit ai_act_oversight_gate for each gate."""
    from dsk.core.ai_act_diff import compute_ai_act_diff
    from dsk.core.models_ai_act import AiActProfileManifestV1

    manifest = AiActProfileManifestV1(
        **{
            "schema": "ai-act-profile.v1",
            "name": "act-test",
            "oversight_gates": [{"name": "stop", "ai_system_uid_ref": "sys.assistant"}],
        }
    )
    changes = compute_ai_act_diff(manifest, live=None)
    types = {c.resource_type for c in changes}
    assert "ai_act_oversight_gate" in types


def test_compute_ai_act_diff_control_resource_type() -> None:
    """compute_ai_act_diff emits ai_act_control for each control item."""
    from dsk.core.ai_act_diff import compute_ai_act_diff
    from dsk.core.models_ai_act import AiActProfileManifestV1

    manifest = AiActProfileManifestV1(
        **{
            "schema": "ai-act-profile.v1",
            "name": "act-controls",
            "controls": [
                {"article": "Art.13", "obligation": "Log all decisions", "status": "compliant"}
            ],
        }
    )
    changes = compute_ai_act_diff(manifest, live=None)
    types = {c.resource_type for c in changes}
    assert "ai_act_control" in types
