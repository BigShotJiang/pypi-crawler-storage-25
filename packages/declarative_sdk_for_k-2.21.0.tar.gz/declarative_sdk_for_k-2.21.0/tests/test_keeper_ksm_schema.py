"""keeper-ksm.v1 live-proof schema annotation tests."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import jsonschema
import pytest

from dsk.cli._live.transcript import secret_leak_check

_REPO = Path(__file__).resolve().parents[1]
_SCHEMA_PATH = _REPO / "dsk" / "core" / "schemas" / "keeper-ksm" / "keeper-ksm.v1.schema.json"


def _schema() -> dict[str, Any]:
    return json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))


def test_keeper_ksm_live_proof_status_supported() -> None:
    proof = _schema()["x-keeper-live-proof"]

    assert proof["status"] == "supported"
    assert proof["evidence"] == "docs/live-proof/keeper-ksm.v1.89047920.sanitized.json"
    assert "KsmLoginHelper" in proof["notes"]


def test_keeper_ksm_schema_has_title_and_type() -> None:
    schema = _schema()
    assert schema.get("title") == "keeper-ksm.v1"
    assert schema.get("type") == "object"


def test_keeper_ksm_schema_has_required_fields() -> None:
    schema = _schema()
    required = schema.get("required", [])
    assert "name" in required or "applications" in required or len(required) > 0


def test_keeper_ksm_evidence_artifact_shape_and_leak_check() -> None:
    evidence = _REPO / _schema()["x-keeper-live-proof"]["evidence"]
    raw = evidence.read_text(encoding="utf-8")
    data = json.loads(raw)

    assert secret_leak_check(raw) == []
    assert data["family"] == "keeper-ksm.v1"
    assert data["scenario"] == "ksmLoginHelperBootstrapRoundTrip"
    assert data["commit"] == "8044bb89"
    assert data["commander_version"] == "17.2.13"
    assert isinstance(data["tenant_hash"], str)
    assert len(data["tenant_hash"]) == 8
    assert data["notes"]
    event_names = {event["event"] for event in data["events"]}
    assert {
        "bootstrap_ksm_application",
        "sample_fetch",
        "write_update",
        "fetch_back",
        "restore",
        "sanitization",
    } <= event_names


def test_keeper_ksm_schema_rejects_additional_properties() -> None:
    """Bundled keeper-ksm.v1 closes the manifest body until modeled fields ship."""
    instance = {"schema": "keeper-ksm.v1", "unsupported_field": {"x": 1}}
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.Draft202012Validator(_schema()).validate(instance)


def test_keeper_ksm_live_proof_since_pin_matches_short_commit_hex() -> None:
    proof = _schema()["x-keeper-live-proof"]
    assert isinstance(proof.get("since_pin"), str)
    assert len(proof["since_pin"]) >= 40
    assert all(c in "0123456789abcdef" for c in proof["since_pin"].lower())


def test_keeper_ksm_schema_version_id_and_const() -> None:
    schema = _schema()
    schema_field = schema["properties"]["schema"]
    assert schema_field.get("type") == "string"
    assert schema_field["const"] == "keeper-ksm.v1"
    assert schema["$schema"] == "https://json-schema.org/draft/2020-12/schema"
