"""Offline coverage for ``dsk report team-roles`` (matrix + redaction + leak check)."""

from __future__ import annotations

import json
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_GENERIC, EXIT_OK


def _run(args: list[str]):
    runner = CliRunner()
    return runner.invoke(main, args, catch_exceptions=False)


def _install_enterprise_info_queue(
    monkeypatch: pytest.MonkeyPatch,
    responses: list[list[dict[str, object]]],
    calls: list[list[str]] | None = None,
) -> None:
    queue = [json.dumps(response) for response in responses]

    def fake_run_keeper_batch(argv: list[str], **_kwargs: object) -> str:
        if calls is not None:
            calls.append(argv)
        if not queue:
            raise AssertionError("no fake enterprise-info response queued")
        return queue.pop(0)

    monkeypatch.setattr(
        "dsk.cli._report.runner.run_keeper_batch",
        fake_run_keeper_batch,
    )


def test_team_roles_empty_enterprise_has_zero_teams_and_roles(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    _install_enterprise_info_queue(monkeypatch, [[], []], calls)

    result = _run(["report", "team-roles", "--json"])

    assert result.exit_code == EXIT_OK, result.output
    payload = json.loads(result.stdout)
    assert payload["command"] == "team-roles"
    assert payload["meta"]["team_count"] == 0
    assert payload["meta"]["role_count"] == 0
    assert payload["meta"]["binding_count"] == 0
    assert payload["rows"] == []
    assert len(calls) == 2


def test_team_roles_matrix_three_teams_two_roles_cross_bindings(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    perm_a: list[dict[str, Any]] = [
        {"node_name": "Root", "node_id": 1, "cascade": False, "privileges": ["run_reports"]}
    ]
    perm_b: list[dict[str, Any]] = [
        {"node_name": "Child", "node_id": 2, "cascade": True, "privileges": ["manage_users"]}
    ]
    teams_json = [
        {
            "team_uid": "TeamUidAlphaBetaGammaDelta01",
            "name": "T1",
            "restricts": "   ",
            "node": "Root",
            "role_count": 1,
            "roles": ["R1"],
        },
        {
            "team_uid": "TeamUidAlphaBetaGammaDelta02",
            "name": "T2",
            "restricts": "   ",
            "node": "Root",
            "role_count": 2,
            "roles": ["R1", "R2"],
        },
        {
            "team_uid": "TeamUidAlphaBetaGammaDelta03",
            "name": "T3",
            "restricts": "   ",
            "node": "Root",
            "role_count": 1,
            "roles": ["R2"],
        },
    ]
    roles_json = [
        {"role_id": 101, "name": "R1", "managed_nodes_permissions": perm_a},
        {"role_id": 202, "name": "R2", "managed_nodes_permissions": perm_b},
    ]
    _install_enterprise_info_queue(monkeypatch, [teams_json, roles_json], calls)

    result = _run(["report", "team-roles"])

    assert result.exit_code == EXIT_OK, result.output
    payload = json.loads(result.stdout)
    assert payload["meta"]["team_count"] == 3
    assert payload["meta"]["role_count"] == 2
    assert payload["meta"]["binding_count"] == 4
    rows = payload["rows"]
    assert len(rows) == 3
    by_name = {t["team_name"]: t for t in rows}
    assert [r["role_name"] for r in by_name["T1"]["roles"]] == ["R1"]
    assert by_name["T1"]["roles"][0]["permissions"] == perm_a
    assert sorted(r["role_name"] for r in by_name["T2"]["roles"]) == ["R1", "R2"]
    assert [r["role_name"] for r in by_name["T3"]["roles"]] == ["R2"]
    assert calls[0][-2:] == ["--columns", "restricts,node,role_count,roles"]
    assert calls[1][-2:] == ["--columns", "managed_nodes_permissions"]


def test_team_roles_passes_node_filter_to_both_enterprise_info_calls(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    _install_enterprise_info_queue(
        monkeypatch,
        [
            [
                {
                    "team_uid": "TeamUidAlphaBetaGammaDelta01",
                    "name": "Scoped",
                    "node": "East",
                    "role_count": 0,
                    "roles": [],
                }
            ],
            [],
        ],
        calls,
    )

    result = _run(["report", "team-roles", "--node", "east-node-uid"])

    assert result.exit_code == EXIT_OK, result.output
    assert (
        calls[0].count("--node") == 1 and calls[0][calls[0].index("--node") + 1] == "east-node-uid"
    )
    assert (
        calls[1].count("--node") == 1 and calls[1][calls[1].index("--node") + 1] == "east-node-uid"
    )


def test_team_roles_quiet_fingerprints_team_uid_and_role_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    team_uid = "ZzYyXxWwVvUuTtSsRrQqPp"
    role_key = 555
    _install_enterprise_info_queue(
        monkeypatch,
        [
            [
                {
                    "team_uid": team_uid,
                    "name": "OnlyTeam",
                    "node": "Root",
                    "role_count": 1,
                    "roles": ["SoloRole"],
                }
            ],
            [
                {
                    "role_id": role_key,
                    "name": "SoloRole",
                    "managed_nodes_permissions": [],
                }
            ],
        ],
    )

    result = _run(["report", "team-roles", "--quiet"])

    assert result.exit_code == EXIT_OK, result.output
    assert team_uid not in result.stdout
    assert str(role_key) not in result.stdout
    payload = json.loads(result.stdout)
    assert payload["rows"][0]["team_uid"].startswith("<uid:")
    assert payload["rows"][0]["roles"][0]["role_id"].startswith("<uid:")


def test_team_roles_leak_check_exit_one_when_env_password_echoed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    secret = "live-leak-password-value-min-eight"
    monkeypatch.setenv("KEEPER_PASSWORD", secret)
    _install_enterprise_info_queue(
        monkeypatch,
        [
            [
                {
                    "team_uid": "TeamUidAlphaBetaGammaDelta01",
                    "name": "Bad",
                    "node": "Root",
                    "role_count": 1,
                    "roles": ["Leaky"],
                }
            ],
            [
                {
                    "role_id": 1,
                    "name": "Leaky",
                    "managed_nodes_permissions": [
                        {"node_name": secret, "node_id": 9, "cascade": False, "privileges": []}
                    ],
                }
            ],
        ],
    )

    result = _run(["report", "team-roles"])

    assert result.exit_code == EXIT_GENERIC
    assert "report refused" in result.stderr
    assert secret not in result.stdout
