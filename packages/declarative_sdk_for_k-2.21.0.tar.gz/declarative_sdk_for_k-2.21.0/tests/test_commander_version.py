"""Commander runtime-version feature gates."""

from __future__ import annotations

import subprocess
import sys
import types
from unittest.mock import patch

import pytest

from dsk.providers import commander_version


@pytest.fixture(autouse=True)
def _clear_version_cache(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("DSK_COMMANDER_V18", raising=False)
    commander_version.get_commander_version.cache_clear()
    yield
    commander_version.get_commander_version.cache_clear()


def test_v17_version_tuple_and_gate_false() -> None:
    with patch("importlib.metadata.version", return_value="17.2.16"):
        assert commander_version.commander_version() == "17.2.16"
        assert commander_version.get_commander_version() == (17, 2, 16)
        assert commander_version.v18_or_later() is False


def test_v18_version_tuple_and_gate_true() -> None:
    with patch("importlib.metadata.version", return_value="18.0.0"):
        assert commander_version.get_commander_version() == (18, 0, 0)
        assert commander_version.v18_or_later() is True


def test_version_parse_failure_returns_zero_tuple_and_gate_false() -> None:
    with patch("importlib.metadata.version", side_effect=ValueError("bad version")):
        assert commander_version.get_commander_version() == (0, 0, 0)
        assert commander_version.v18_or_later() is False


def test_env_override_enables_v18_with_v17_installed(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_COMMANDER_V18", "1")
    with patch("importlib.metadata.version", return_value="17.2.16"):
        assert commander_version.v18_or_later() is True


def test_keeper_binary_version_no_binary(monkeypatch: pytest.MonkeyPatch) -> None:
    """When keeper is not on PATH, return None."""
    monkeypatch.setattr(commander_version.shutil, "which", lambda _name: None)

    assert commander_version.keeper_binary_version() is None


def test_keeper_binary_version_returns_string_when_present(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When keeper is on PATH, parse a version-like string."""
    monkeypatch.setattr(commander_version.shutil, "which", lambda _name: "/usr/local/bin/keeper")

    def _fake_run(*args: object, **_kwargs: object) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(args, 0, stdout="keeper version 18.0.0\n", stderr="")

    monkeypatch.setattr(commander_version.subprocess, "run", _fake_run)

    assert commander_version.keeper_binary_version() == "18.0.0"


def test_keeper_binary_version_uses_five_second_probe_timeout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(commander_version.shutil, "which", lambda _name: "/usr/local/bin/keeper")
    captured: dict[str, object] = {}

    def _fake_run(args: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
        captured["args"] = args
        captured["timeout"] = kwargs.get("timeout")
        return subprocess.CompletedProcess(args, 0, stdout="Keeper Commander 18.0.0\n", stderr="")

    monkeypatch.setattr(commander_version.subprocess, "run", _fake_run)

    assert commander_version.keeper_binary_version() == "18.0.0"
    assert captured == {
        "args": ["/usr/local/bin/keeper", "--version"],
        "timeout": 5,
    }


def test_keeper_binary_version_timeout_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(commander_version.shutil, "which", lambda _name: "/usr/local/bin/keeper")

    def _timeout(*args: object, **_kwargs: object) -> subprocess.CompletedProcess[str]:
        raise subprocess.TimeoutExpired(cmd=["keeper", "--version"], timeout=5)

    monkeypatch.setattr(commander_version.subprocess, "run", _timeout)

    assert commander_version.keeper_binary_version() is None


def test_keeper_binary_version_oserror_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(commander_version.shutil, "which", lambda _name: "/usr/local/bin/keeper")

    def _oserror(*args: object, **_kwargs: object) -> subprocess.CompletedProcess[str]:
        raise OSError("binary disappeared")

    monkeypatch.setattr(commander_version.subprocess, "run", _oserror)

    assert commander_version.keeper_binary_version() is None


def test_keeper_binary_version_nonzero_stderr_only_parses_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(commander_version.shutil, "which", lambda _name: "/usr/local/bin/keeper")

    def _fake_run(*args: object, **_kwargs: object) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(args, 2, stdout="", stderr="Keeper Commander 18.0.1\n")

    monkeypatch.setattr(commander_version.subprocess, "run", _fake_run)

    assert commander_version.keeper_binary_version() == "18.0.1"


def test_keeper_binary_version_nonzero_empty_output_returns_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(commander_version.shutil, "which", lambda _name: "/usr/local/bin/keeper")

    def _fake_run(*args: object, **_kwargs: object) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(args, 2, stdout="", stderr="")

    monkeypatch.setattr(commander_version.subprocess, "run", _fake_run)

    assert commander_version.keeper_binary_version() is None


def test_has_version_mismatch_returns_none_when_aligned(monkeypatch: pytest.MonkeyPatch) -> None:
    """When binary and package major versions match, return None."""
    monkeypatch.setattr(commander_version, "keeper_binary_version", lambda: "18.1.0")
    monkeypatch.setattr(commander_version, "commander_version", lambda: "18.0.0")

    assert commander_version.has_version_mismatch() is None


def test_has_version_mismatch_detects_split(monkeypatch: pytest.MonkeyPatch) -> None:
    """When binary major differs from package major, return the split tuple."""
    monkeypatch.setattr(commander_version, "keeper_binary_version", lambda: "17.1.14")
    monkeypatch.setattr(commander_version, "commander_version", lambda: "18.0.0")

    assert commander_version.has_version_mismatch() == ("17.1.14", "18.0.0")


def test_has_version_mismatch_ignores_unparseable_binary_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(commander_version, "keeper_binary_version", lambda: "unknown")
    monkeypatch.setattr(commander_version, "commander_version", lambda: "18.0.0")

    assert commander_version.has_version_mismatch() is None


def test_rotation_info_json_predicate(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(commander_version, "supports_rotation_info_json", lambda: True)

    assert commander_version.v18_rotation_info_json() is True


def test_sm_token_add_predicate(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(commander_version, "supports_secrets_manager_token_add", lambda: True)

    assert commander_version.v18_sm_token_add() is True


def test_project_import_server_dedup_predicate() -> None:
    with patch("importlib.metadata.version", return_value="18.0.0"):
        assert commander_version.v18_project_import_server_dedup() is True


def test_project_export_native_predicate(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(commander_version, "supports_pam_project_export", lambda: True)

    assert commander_version.v18_project_export_native() is True


def test_prerelease_version_rc_parses_as_v18() -> None:
    """18.0.0rc1 must gate as v18, not fall back to (0,0,0)."""
    with patch("importlib.metadata.version", return_value="18.0.0rc1"):
        assert commander_version.get_commander_version() == (18, 0, 0)
        assert commander_version.v18_or_later() is True


def test_prerelease_version_dev_parses_as_v18() -> None:
    with patch("importlib.metadata.version", return_value="18.0.0.dev0"):
        assert commander_version.get_commander_version() == (18, 0, 0)
        assert commander_version.v18_or_later() is True


def test_prerelease_version_alpha_parses_correctly() -> None:
    with patch("importlib.metadata.version", return_value="17.3.0a1"):
        assert commander_version.get_commander_version() == (17, 3, 0)
        assert commander_version.v18_or_later() is False


def test_commander_version_metadata_exception_returns_zero() -> None:
    with patch("importlib.metadata.version", side_effect=RuntimeError("metadata broke")):
        assert commander_version.commander_version() == "0.0.0"


def test_command_class_rejects_non_type(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(
        sys.modules, "keeper.fake.non_type", types.SimpleNamespace(Command=object())
    )

    assert commander_version._command_class("keeper.fake.non_type", "Command") is None


def test_supports_rotation_info_json_detects_parser_options(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class Action:
        def __init__(
            self, dest: str, option_strings: tuple[str, ...], choices: tuple[str, ...] = ()
        ):
            self.dest = dest
            self.option_strings = option_strings
            self.choices = choices or None

    class Parser:
        _actions = [
            Action("record_uid", ("--record-uid",)),
            Action("format", ("--format",), ("text", "json")),
        ]

    class Command:
        def get_parser(self) -> Parser:
            return Parser()

    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.discoveryrotation",
        types.SimpleNamespace(PAMRouterGetRotationInfo=Command),
    )

    assert commander_version.supports_rotation_info_json() is True


def test_supports_secrets_manager_token_add_rejects_missing_token_help(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class Parser:
        _actions: list[object] = []

    class KSMCommand:
        def get_parser(self) -> Parser:
            return Parser()

    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.ksm",
        types.SimpleNamespace(KSMCommand=KSMCommand, available_ksm_commands="app create"),
    )

    assert commander_version.supports_secrets_manager_token_add() is False
