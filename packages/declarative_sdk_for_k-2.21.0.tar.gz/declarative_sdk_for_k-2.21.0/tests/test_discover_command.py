"""Tests for `dsk discover`."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_CAPABILITY, EXIT_GENERIC, EXIT_OK
from dsk.core.metadata import MARKER_FIELD_LABEL, encode_marker, serialize_marker

_runner = CliRunner()


def _sample_pam_json_with_marker() -> dict:
    marker = encode_marker(
        uid_ref="res.managed-host",
        manifest="acme",
        resource_type="pamMachine",
    )
    managed_cf = {MARKER_FIELD_LABEL: serialize_marker(marker)}
    return {
        "project": "lab-discover",
        "pam_configuration": {
            "environment": "local",
            "title": "cfg1",
            "gateway_name": "gw1",
        },
        "pam_data": {
            "resources": [
                {
                    "type": "pamMachine",
                    "title": "owned-box",
                    "host": "10.0.0.1",
                    "port": "22",
                    "operating_system": "Linux",
                    "custom_fields": managed_cf,
                },
                {
                    "type": "pamMachine",
                    "title": "stray-box",
                    "host": "10.0.0.2",
                    "port": "22",
                    "operating_system": "Linux",
                },
            ]
        },
    }


def test_discover_mock_json_valid_yaml(tmp_path: Path) -> None:
    js = tmp_path / "in.json"
    js.write_text(json.dumps(_sample_pam_json_with_marker()), encoding="utf-8")
    outp = tmp_path / "out.yaml"
    result = _runner.invoke(
        main,
        ["discover", "--input", str(js), "-o", str(outp)],
        catch_exceptions=False,
    )
    assert result.exit_code == EXIT_OK, result.output
    text = outp.read_text(encoding="utf-8")
    assert "manager: discovered" in text
    assert "stray-box" in text
    assert "owned-box" not in text


def test_discover_commander_capability(tmp_path: Path) -> None:
    js = tmp_path / "in.json"
    js.write_text("{}", encoding="utf-8")
    outp = tmp_path / "out.yaml"
    result = _runner.invoke(
        main,
        ["--provider", "commander", "discover", "--input", str(js), "-o", str(outp)],
        catch_exceptions=False,
    )
    assert result.exit_code == EXIT_CAPABILITY, result.output
    out = result.output.lower()
    assert "pam project export" in out
    assert "dsk export" in out


def test_discover_includes_only_unmanaged_resources(tmp_path: Path) -> None:
    """Managed (marker-tagged) resources must NOT appear in discover output."""
    js = tmp_path / "in.json"
    js.write_text(json.dumps(_sample_pam_json_with_marker()), encoding="utf-8")
    outp = tmp_path / "out.yaml"
    _runner.invoke(
        main,
        ["discover", "--input", str(js), "-o", str(outp)],
        catch_exceptions=False,
    )
    text = outp.read_text(encoding="utf-8")
    assert "stray-box" in text
    assert "owned-box" not in text


def test_discover_output_schema_is_pam_environment(tmp_path: Path) -> None:
    """Discover output must carry schema: pam-environment.v1."""
    js = tmp_path / "in.json"
    js.write_text(json.dumps(_sample_pam_json_with_marker()), encoding="utf-8")
    outp = tmp_path / "out.yaml"
    _runner.invoke(
        main,
        ["discover", "--input", str(js), "-o", str(outp)],
        catch_exceptions=False,
    )
    text = outp.read_text(encoding="utf-8")
    assert "pam-environment.v1" in text


def test_discover_missing_output_flag_exits_with_usage_error(tmp_path: Path) -> None:
    """discover requires --output/-o; missing it must fail with usage error."""
    js = tmp_path / "in.json"
    js.write_text(json.dumps(_sample_pam_json_with_marker()), encoding="utf-8")
    result = _runner.invoke(
        main,
        ["discover", "--input", str(js)],
    )
    assert result.exit_code != EXIT_OK
    assert "--output" in result.output or "-o" in result.output or "Error" in result.output


def test_discovered_manifest_passes_validate(tmp_path: Path) -> None:
    js = tmp_path / "in.json"
    js.write_text(json.dumps(_sample_pam_json_with_marker()), encoding="utf-8")
    outp = tmp_path / "out.yaml"
    d = _runner.invoke(
        main,
        ["discover", "--input", str(js), "-o", str(outp)],
        catch_exceptions=False,
    )
    assert d.exit_code == EXIT_OK, d.output
    v = _runner.invoke(main, ["validate", str(outp)], catch_exceptions=False)
    assert v.exit_code == EXIT_OK, v.output


def test_discover_input_cap_accepts_just_under(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    js = tmp_path / "in.json"
    raw = json.dumps(_sample_pam_json_with_marker())
    js.write_text(raw, encoding="utf-8")
    monkeypatch.setenv("DSK_DISCOVER_MAX_INPUT_BYTES", str(len(raw.encode("utf-8")) + 1))
    outp = tmp_path / "out.yaml"

    result = _runner.invoke(main, ["discover", "--input", str(js), "-o", str(outp)])

    assert result.exit_code == EXIT_OK, result.output


def test_discover_input_cap_accepts_at_cap(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    js = tmp_path / "in.json"
    raw = json.dumps(_sample_pam_json_with_marker())
    js.write_text(raw, encoding="utf-8")
    monkeypatch.setenv("DSK_DISCOVER_MAX_INPUT_BYTES", str(len(raw.encode("utf-8"))))
    outp = tmp_path / "out.yaml"

    result = _runner.invoke(main, ["discover", "--input", str(js), "-o", str(outp)])

    assert result.exit_code == EXIT_OK, result.output


def test_discover_input_cap_rejects_just_over(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    js = tmp_path / "in.json"
    raw = json.dumps(_sample_pam_json_with_marker())
    js.write_text(raw, encoding="utf-8")
    monkeypatch.setenv("DSK_DISCOVER_MAX_INPUT_BYTES", str(len(raw.encode("utf-8")) - 1))
    outp = tmp_path / "out.yaml"

    result = _runner.invoke(main, ["discover", "--input", str(js), "-o", str(outp)])

    assert result.exit_code == EXIT_GENERIC
    assert "DSK_DISCOVER_MAX_INPUT_BYTES" in result.output


def test_discover_mock_invalid_json_exits(tmp_path: Path) -> None:
    """discover command exits 1 when input file contains invalid JSON."""
    from click.testing import CliRunner

    from dsk.cli.main import main

    bad_json = tmp_path / "bad.json"
    bad_json.write_text("{not valid json}", encoding="utf-8")

    runner = CliRunner()
    result = runner.invoke(main, ["discover", "--input", str(bad_json)])
    assert result.exit_code in (1, 2)


def test_discover_mock_non_dict_json_exits(tmp_path: Path) -> None:
    """discover command exits 1 when JSON root is not an object."""
    import json

    from click.testing import CliRunner

    from dsk.cli.main import main

    bad_json = tmp_path / "arr.json"
    bad_json.write_text(json.dumps(["not", "a", "dict"]), encoding="utf-8")

    runner = CliRunner()
    result = runner.invoke(main, ["discover", "--input", str(bad_json)])
    assert result.exit_code in (1, 2)


def test_discover_requires_input_flag() -> None:
    """discover command exits 1 when no --input flag is given (mock provider)."""
    from click.testing import CliRunner

    from dsk.cli.main import main

    runner = CliRunner()
    result = runner.invoke(main, ["discover"])
    # Should exit with 1 or 2 (missing input)
    assert result.exit_code != 0
