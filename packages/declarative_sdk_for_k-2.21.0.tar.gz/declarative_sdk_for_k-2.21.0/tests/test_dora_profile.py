"""Tests for DORA compliance profile manifest models."""

from pathlib import Path

import yaml


def test_dora_defaults():
    from dsk.core.models_dora import DoraProfileManifestV1

    m = DoraProfileManifestV1(**{"schema": "dora-profile.v1", "name": "test"})
    assert m.schema_ == "dora-profile.v1"
    assert m.controls == []
    assert m.reporting.output_dir == "dora-evidence/"
    assert m.reporting.audit_period_days == 365


def test_dora_round_trip():
    from dsk.core.models_dora import DoraArticle, DoraControlStatus, DoraProfileManifestV1

    example = Path(__file__).parent.parent / "examples/dora/acme-bank-dora-profile.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = DoraProfileManifestV1(**data)
    assert manifest.schema_ == "dora-profile.v1"
    assert manifest.entity_name == "Acme Bank S.A."
    assert len(manifest.controls) == 6
    art9 = manifest.controls[0]
    assert art9.article == DoraArticle.art9
    assert art9.status == DoraControlStatus.satisfied
    partial = manifest.controls[2]
    assert partial.status == DoraControlStatus.partial
    assert partial.remediation_note is not None


def test_dora_gap_requires_note():
    from dsk.core.models_dora import DoraArticle, DoraControlMapping, DoraControlStatus

    mapping = DoraControlMapping(
        article=DoraArticle.art9,
        control_description="test",
        status=DoraControlStatus.gap,
        remediation_note="Must fix by Q4 2026",
    )
    assert mapping.remediation_note == "Must fix by Q4 2026"


def test_dora_schema_alias():
    from dsk.core.models_dora import DoraProfileManifestV1

    m = DoraProfileManifestV1(**{"schema": "dora-profile.v1", "name": "t"})
    assert m.schema_ == "dora-profile.v1"


def test_dora_control_evidence_types():
    from dsk.core.models_dora import (
        DoraArticle,
        DoraControlMapping,
        DoraControlStatus,
        DoraEvidenceType,
    )

    mapping = DoraControlMapping(
        article=DoraArticle.art10,
        control_description="test",
        status=DoraControlStatus.satisfied,
        evidence_types=[
            DoraEvidenceType.session_recording,
            DoraEvidenceType.mfa_enforcement,
        ],
    )
    assert len(mapping.evidence_types) == 2
