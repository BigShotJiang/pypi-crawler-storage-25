"""Validate AI security example YAML files can be loaded without errors."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from dsk.core.manifest import (
    load_declarative_manifest_string,
    read_manifest_document,
)
from dsk.core.schema import validate_manifest

EXAMPLES_ROOT = Path(__file__).resolve().parent.parent / "examples"

AI_SECURITY_EXAMPLES = [
    EXAMPLES_ROOT / "ai-coding-agents" / "acme-agents.yaml",
    EXAMPLES_ROOT / "ai-coding-agents" / "acme-memory-policy.yaml",
    EXAMPLES_ROOT / "ai-coding-agents" / "acme-skill-policy.yaml",
    EXAMPLES_ROOT / "mcp" / "acme-mcp-allowlist.yaml",
    EXAMPLES_ROOT / "mcp" / "acme-mcp-secrets.yaml",
]


@pytest.mark.parametrize("example_path", AI_SECURITY_EXAMPLES, ids=lambda p: p.name)
def test_ai_security_example_parses_yaml(example_path: Path) -> None:
    """Each AI security example file must be valid YAML."""
    assert example_path.exists(), f"Example file missing: {example_path}"
    doc = yaml.safe_load(example_path.read_text(encoding="utf-8"))
    assert isinstance(doc, dict)
    assert "schema" in doc


_EXPECTED_FAMILY = (
    ("ai-coding-agents", "acme-agents.yaml", "nhi-agent.v1"),
    ("ai-coding-agents", "acme-memory-policy.yaml", "agent-memory-policy.v1"),
    ("ai-coding-agents", "acme-skill-policy.yaml", "agentic-skill-policy.v1"),
    ("mcp", "acme-mcp-allowlist.yaml", "mcp-server-allowlist.v1"),
    ("mcp", "acme-mcp-secrets.yaml", "mcp-secrets-binding.v1"),
)


@pytest.mark.parametrize(
    ("subdir", "filename", "expected_family"),
    _EXPECTED_FAMILY,
    ids=lambda p: p[1] if isinstance(p, tuple) else "",
)
def test_ai_security_example_validates_schema(
    subdir: str, filename: str, expected_family: str
) -> None:
    """Each AI security example file must pass JSON Schema validation."""
    path = EXAMPLES_ROOT / subdir / filename
    doc = read_manifest_document(path)
    family = validate_manifest(doc)
    assert family == expected_family
    assert family.endswith(".v1")


@pytest.mark.parametrize("example_path", AI_SECURITY_EXAMPLES, ids=lambda p: p.name)
def test_ai_security_example_loads_via_declarative_string(example_path: Path) -> None:
    """Typed load from raw YAML string (validate + family dispatch)."""
    raw = example_path.read_text(encoding="utf-8")
    load_declarative_manifest_string(raw, suffix=".yaml")


def test_acme_agents_example_structure() -> None:
    doc = read_manifest_document(EXAMPLES_ROOT / "ai-coding-agents" / "acme-agents.yaml")
    assert doc["schema"] == "nhi-agent.v1"
    assert isinstance(doc["resources"], list)
    assert len(doc["resources"]) >= 1


def test_acme_mcp_allowlist_example_structure() -> None:
    doc = read_manifest_document(EXAMPLES_ROOT / "mcp" / "acme-mcp-allowlist.yaml")
    assert doc["schema"] == "mcp-server-allowlist.v1"
    assert isinstance(doc["servers"], list)
    assert len(doc["servers"]) >= 1


def test_acme_skill_policy_example_schema() -> None:
    doc = read_manifest_document(EXAMPLES_ROOT / "ai-coding-agents" / "acme-skill-policy.yaml")
    assert doc["schema"] == "agentic-skill-policy.v1"


def test_acme_memory_policy_example_schema() -> None:
    doc = read_manifest_document(EXAMPLES_ROOT / "ai-coding-agents" / "acme-memory-policy.yaml")
    assert doc["schema"] == "agent-memory-policy.v1"
