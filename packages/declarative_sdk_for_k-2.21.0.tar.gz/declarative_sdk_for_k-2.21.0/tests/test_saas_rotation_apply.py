"""CommanderCliProvider keeper-saas-rotation.v1 apply tests."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.planner import Plan
from dsk.providers import commander_cli
from dsk.providers.commander_cli import CommanderCliProvider


def _plan(*changes: Change) -> Plan:
    return Plan(
        manifest_name="saas-apply-test",
        changes=list(changes),
        order=[change.uid_ref or "" for change in changes],
    )


def _provider(monkeypatch: pytest.MonkeyPatch) -> tuple[CommanderCliProvider, object]:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    params = object()
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda operation: operation())
    return provider, params


def _install_saas_modules(
    monkeypatch: pytest.MonkeyPatch,
    *,
    config_command: type[Any] | None = None,
    remove_command: type[Any] | None = None,
    update_command: type[Any] | None = None,
) -> None:
    keepercommander_module = types.ModuleType("keepercommander")
    commands_module = types.ModuleType("keepercommander.commands")
    pam_saas_module = types.ModuleType("keepercommander.commands.pam_saas")
    config_module = types.ModuleType("keepercommander.commands.pam_saas.config")
    remove_module = types.ModuleType("keepercommander.commands.pam_saas.remove")
    update_module = types.ModuleType("keepercommander.commands.pam_saas.update")
    setattr(keepercommander_module, "__path__", [])
    setattr(commands_module, "__path__", [])
    setattr(pam_saas_module, "__path__", [])
    setattr(keepercommander_module, "commands", commands_module)
    setattr(commands_module, "pam_saas", pam_saas_module)
    setattr(pam_saas_module, "config", config_module)
    setattr(pam_saas_module, "remove", remove_module)
    setattr(pam_saas_module, "update", update_module)
    if config_command is not None:
        config_module.PAMActionSaasConfigCommand = config_command
    if remove_command is not None:
        remove_module.PAMActionSaasRemoveCommand = remove_command
    if update_command is not None:
        update_module.PAMActionSaasUpdateCommand = update_command
    monkeypatch.setitem(sys.modules, "keepercommander", keepercommander_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", commands_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.pam_saas", pam_saas_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.pam_saas.config", config_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.pam_saas.remove", remove_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.pam_saas.update", update_module)


def test_saas_apply_config_called_on_create(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, params = _provider(monkeypatch)
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakePAMActionSaasConfigCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    _install_saas_modules(monkeypatch, config_command=FakePAMActionSaasConfigCommand)
    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="rotation.salesforce-admin",
        resource_type="saas_rotation_config",
        title="Salesforce Admin Rotation",
        after={
            "gateway": "lab-gateway",
            "configuration_uid": "PAMCFG123",
            "shared_folder_uid": "SF123",
            "provider": "salesforce",
        },
    )

    outcomes = provider.apply_saas_rotation_plan(_plan(change))

    assert [outcome.action for outcome in outcomes] == ["create"]
    assert calls == [
        (
            params,
            {
                "gateway": "lab-gateway",
                "plugin": "salesforce",
                "do_create": True,
                "configuration_uid": "PAMCFG123",
                "shared_folder_uid": "SF123",
            },
        )
    ]


def test_saas_apply_remove_called_on_delete(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, params = _provider(monkeypatch)
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakePAMActionSaasRemoveCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    _install_saas_modules(monkeypatch, remove_command=FakePAMActionSaasRemoveCommand)
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref="binding.salesforce-admin",
        resource_type="saas_rotation_binding",
        title="binding.salesforce-admin",
        before={
            "record_uid_ref": "keeper-vault:records:PAMUSER123",
            "resource_uid_ref": "keeper-vault:records:PAMRES123",
        },
    )

    outcomes = provider.apply_saas_rotation_plan(_plan(change))

    assert [outcome.action for outcome in outcomes] == ["delete"]
    assert calls == [(params, {"user_uid": "PAMUSER123", "resource_uid": "PAMRES123"})]


def test_saas_apply_dry_run_skips(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, _params = _provider(monkeypatch)
    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="rotation.salesforce-admin",
        resource_type="saas_rotation_config",
        title="Salesforce Admin Rotation",
        after={"gateway": "lab-gateway", "provider": "salesforce"},
    )

    outcomes = provider.apply_saas_rotation_plan(_plan(change), dry_run=True)

    assert len(outcomes) == 1
    assert outcomes[0].status == "would_apply"
    assert outcomes[0].details["dry_run"] is True
    assert outcomes[0].details["would"] == "create"


def test_saas_apply_update_changes_config(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, params = _provider(monkeypatch)
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakePAMActionSaasUpdateCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    _install_saas_modules(monkeypatch, update_command=FakePAMActionSaasUpdateCommand)
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="rotation.salesforce-admin",
        resource_type="saas_rotation_config",
        title="Salesforce Admin Rotation",
        keeper_uid="CFGRECUID",
        before={
            "gateway": "lab-gateway",
            "configuration_uid": "PAMCFG123",
            "shared_folder_uid": "SF123",
            "provider": "salesforce",
        },
        after={
            "gateway": "lab-gateway",
            "configuration_uid": "PAMCFG456",
            "shared_folder_uid": "SF123",
            "provider": "salesforce",
        },
    )

    outcomes = provider.apply_saas_rotation_plan(_plan(change))

    assert [outcome.action for outcome in outcomes] == ["update"]
    assert calls == [
        (
            params,
            {
                "gateway": "lab-gateway",
                "config_uid": "CFGRECUID",
                "configuration_uid": "PAMCFG456",
            },
        )
    ]


def test_saas_apply_noop_returns_empty_outcomes(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, _params = _provider(monkeypatch)
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakePAMActionSaasConfigCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    _install_saas_modules(monkeypatch, config_command=FakePAMActionSaasConfigCommand)

    outcomes = provider.apply_saas_rotation_plan(
        Plan(manifest_name="saas-apply-test", changes=[], order=[]),
    )

    assert outcomes == []
    assert calls == []


def test_saas_apply_multiple_creates_calls_once_per_record(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, params = _provider(monkeypatch)
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakePAMActionSaasConfigCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    _install_saas_modules(monkeypatch, config_command=FakePAMActionSaasConfigCommand)
    change_a = Change(
        kind=ChangeKind.CREATE,
        uid_ref="rotation.salesforce-admin",
        resource_type="saas_rotation_config",
        title="Salesforce Admin Rotation",
        after={
            "gateway": "lab-gateway",
            "configuration_uid": "PAMCFG1",
            "shared_folder_uid": "SF1",
            "provider": "salesforce",
        },
    )
    change_b = Change(
        kind=ChangeKind.CREATE,
        uid_ref="rotation.snow-admin",
        resource_type="saas_rotation_config",
        title="Snowflake Admin Rotation",
        after={
            "gateway": "lab-gateway",
            "configuration_uid": "PAMCFG2",
            "shared_folder_uid": "SF2",
            "provider": "snowflake",
        },
    )

    outcomes = provider.apply_saas_rotation_plan(
        _plan(change_a, change_b),
    )

    assert len(calls) == 2
    assert [outcome.action for outcome in outcomes] == ["create", "create"]
    assert calls[0][0] is params and calls[1][0] is params
