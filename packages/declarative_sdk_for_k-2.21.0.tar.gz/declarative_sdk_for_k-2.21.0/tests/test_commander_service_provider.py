from __future__ import annotations

import json
import urllib.error
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli.main import main
from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.metadata import MARKER_FIELD_LABEL, encode_marker, serialize_marker
from dsk.core.planner import Plan
from dsk.providers.commander_service import CommanderServiceProvider
from dsk.providers.service_client import CommanderServiceClient


class FakeClient:
    def __init__(
        self,
        *,
        statuses: list[dict[str, Any]] | None = None,
        results: list[dict[str, Any]] | None = None,
    ) -> None:
        self.submits: list[tuple[str, dict[str, Any] | None]] = []
        self.statuses = statuses or [{"status": "completed"}]
        self.results = results or [{"status": "success"}]

    def _post_async(self, command: str, filedata: dict[str, Any] | None = None) -> str:
        self.submits.append((command, filedata))
        return f"req-{len(self.submits)}"

    def _poll_status(self, request_id: str, timeout: int | None = None) -> dict[str, Any]:
        assert request_id.startswith("req-")
        assert timeout == 300
        return self.statuses.pop(0)

    def _get_result(self, request_id: str) -> dict[str, Any]:
        assert request_id.startswith("req-")
        return self.results.pop(0)


def test_execute_submits_async_polls_and_returns_result() -> None:
    client = FakeClient(results=[{"status": "success", "stdout": '{"ok": true}'}])
    provider = CommanderServiceProvider(api_key="token", client=client)

    result = provider._execute("pam project list --format=json")

    assert result["stdout"] == '{"ok": true}'
    assert client.submits == [("pam project list --format=json", None)]


@pytest.mark.parametrize("status", ["failed", "expired"])
def test_execute_raises_capability_error_on_failed_or_expired(status: str) -> None:
    client = FakeClient(statuses=[{"status": status, "message": "boom"}])
    provider = CommanderServiceProvider(api_key="token", client=client)

    with pytest.raises(CapabilityError, match="boom"):
        provider._execute("pam project list --format=json")


def test_discover_parses_pam_project_list_stdout() -> None:
    marker = serialize_marker(
        encode_marker(uid_ref="res.db", manifest="m", resource_type="pamDatabase")
    )
    stdout = json.dumps(
        {
            "records": [
                {
                    "uid": "UID1",
                    "title": "prod-db",
                    "resource_type": "pamDatabase",
                    "host": "db.example.com",
                    "custom_fields": {MARKER_FIELD_LABEL: marker},
                }
            ]
        }
    )
    client = FakeClient(results=[{"status": "success", "stdout": stdout}])
    provider = CommanderServiceProvider(api_key="token", client=client)

    records = provider.discover()

    assert len(records) == 1
    assert records[0].keeper_uid == "UID1"
    assert records[0].title == "prod-db"
    assert records[0].resource_type == "pamDatabase"
    assert records[0].marker and records[0].marker["uid_ref"] == "res.db"


def test_discover_parses_nested_project_resources() -> None:
    client = FakeClient(
        results=[
            {
                "status": "success",
                "result": {
                    "projects": [
                        {
                            "name": "acme",
                            "pam_data": {
                                "resources": [
                                    {
                                        "record_uid": "UID2",
                                        "title": "machine",
                                        "type": "pamMachine",
                                    }
                                ]
                            },
                        }
                    ]
                },
            }
        ]
    )
    provider = CommanderServiceProvider(api_key="token", client=client)

    records = provider.discover()

    assert [(r.keeper_uid, r.resource_type, r.title) for r in records] == [
        ("UID2", "pamMachine", "machine")
    ]


def test_apply_plan_dry_run_skips_http_calls() -> None:
    client = FakeClient()
    provider = CommanderServiceProvider(api_key="token", client=client)
    plan = Plan(
        "m",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="res.machine",
                resource_type="pamMachine",
                title="machine",
                after={"title": "machine", "type": "pamMachine"},
            ),
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="res.db",
                resource_type="pamDatabase",
                title="db",
                keeper_uid="UID3",
                after={"host": "db.example.com"},
            ),
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="res.old",
                resource_type="pamDirectory",
                title="old",
                keeper_uid="UID4",
            ),
        ],
        ["res.machine", "res.db", "res.old"],
    )

    outcomes = provider.apply_plan(plan, dry_run=True)

    assert client.submits == []
    assert [o.action for o in outcomes] == ["create", "update", "delete"]
    assert all(o.details["dry_run"] for o in outcomes)


def test_apply_plan_create_uses_filedata_import() -> None:
    client = FakeClient(results=[{"status": "success", "uid": "NEWUID"}])
    provider = CommanderServiceProvider(api_key="token", client=client)
    plan = Plan(
        "acme",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="res.db",
                resource_type="pamDatabase",
                title="db",
                after={"title": "db", "type": "pamDatabase", "host": "db.example.com"},
            )
        ],
        ["res.db"],
    )

    outcomes = provider.apply_plan(plan)

    assert outcomes[0].keeper_uid == "NEWUID"
    assert client.submits[0][0] == "pam project import --filename=FILEDATA"
    assert client.submits[0][1] == {
        "project": "acme",
        "pam_data": {
            "resources": [{"title": "db", "type": "pamDatabase", "host": "db.example.com"}]
        },
    }


def test_apply_plan_create_with_manifest_source_serializes_commander_project() -> None:
    source = {
        "name": "acme",
        "resources": [
            {
                "uid_ref": "res.db",
                "type": "pamDatabase",
                "title": "db",
                "host": "db.example.com",
            }
        ],
    }
    client = FakeClient(results=[{"status": "success"}])
    provider = CommanderServiceProvider(api_key="token", client=client, manifest_source=source)
    plan = Plan(
        "acme",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="res.db",
                resource_type="pamDatabase",
                title="db",
                after=source["resources"][0],
            )
        ],
        ["res.db"],
    )

    provider.apply_plan(plan)

    assert client.submits[0][1] == {
        "project": "acme",
        "pam_data": {
            "resources": [{"type": "pamDatabase", "title": "db", "host": "db.example.com"}]
        },
    }


def test_apply_plan_update_builds_edit_command() -> None:
    client = FakeClient(results=[{"status": "success"}])
    provider = CommanderServiceProvider(api_key="token", client=client)
    plan = Plan(
        "m",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="res.db",
                resource_type="pamDatabase",
                title="db",
                keeper_uid="UID3",
                after={"host": "db.example.com", "port": 3306, "title": "db"},
            )
        ],
        ["res.db"],
    )

    provider.apply_plan(plan)

    assert client.submits[0][0] == "pam database edit UID3 --host=db.example.com --port=3306"
    assert client.submits[0][1] is None


def test_apply_plan_delete_builds_delete_command() -> None:
    client = FakeClient(results=[{"status": "success"}])
    provider = CommanderServiceProvider(api_key="token", client=client)
    plan = Plan(
        "m",
        [
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="res.old",
                resource_type="pamDirectory",
                title="old",
                keeper_uid="UID4",
            )
        ],
        ["res.old"],
    )

    provider.apply_plan(plan)

    assert client.submits[0][0] == "pam directory delete UID4"


def test_unsupported_capabilities_match_cli_detector() -> None:
    provider = CommanderServiceProvider(
        api_key="token",
        manifest_source={
            "pam_configurations": [
                {
                    "uid_ref": "cfg",
                    "default_rotation_schedule": {"type": "on-demand"},
                }
            ]
        },
    )

    gaps = provider.unsupported_capabilities()

    assert "default_rotation_schedule" in gaps[0]


def test_service_client_post_async_serializes_filedata(monkeypatch: pytest.MonkeyPatch) -> None:
    seen: list[tuple[str, str, dict[str, str]]] = []

    class Response:
        def __enter__(self) -> Response:
            return self

        def __exit__(self, *_args: object) -> None:
            return None

        def read(self) -> bytes:
            return b'{"request_id":"REQ1"}'

    def fake_urlopen(request: Any, timeout: int) -> Response:
        seen.append((request.full_url, request.data.decode("utf-8"), dict(request.headers)))
        assert timeout == 300
        return Response()

    monkeypatch.setattr("dsk.providers.service_client.urllib.request.urlopen", fake_urlopen)

    client = CommanderServiceClient("http://svc", "token")
    request_id = client._post_async("pam project import --filename=FILEDATA", {"x": 1})

    assert request_id == "REQ1"
    assert seen[0][0] == "http://svc/api/v2/executecommand-async"
    assert json.loads(seen[0][1]) == {
        "command": "pam project import --filename=FILEDATA",
        "filedata": {"x": 1},
    }
    assert seen[0][2]["Api-key"] == "token"


def test_service_client_429_backs_off_and_retries(monkeypatch: pytest.MonkeyPatch) -> None:
    calls = 0
    sleeps: list[float] = []

    class Response:
        def __enter__(self) -> Response:
            return self

        def __exit__(self, *_args: object) -> None:
            return None

        def read(self) -> bytes:
            return b'{"request_id":"REQ2"}'

    def fake_urlopen(_request: Any, timeout: int) -> Response:
        nonlocal calls
        calls += 1
        if calls == 1:
            raise urllib.error.HTTPError(
                url="http://svc/api/v2/executecommand-async",
                code=429,
                msg="rate limited",
                hdrs={"Retry-After": "0.25"},
                fp=None,
            )
        return Response()

    monkeypatch.setattr("dsk.providers.service_client.urllib.request.urlopen", fake_urlopen)
    monkeypatch.setattr("dsk.providers.service_client.time.sleep", sleeps.append)

    client = CommanderServiceClient("http://svc", "token")
    assert client._post_async("pam project list --format=json") == "REQ2"
    assert calls == 2
    assert sleeps == [0.25]


def test_service_client_poll_status_until_completed(monkeypatch: pytest.MonkeyPatch) -> None:
    statuses = [{"status": "running"}, {"status": "completed"}]
    sleeps: list[float] = []
    client = CommanderServiceClient("http://svc", "token", poll_interval=0.1)

    def fake_request(method: str, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        assert method == "GET"
        assert path == "/api/v2/status/REQ3"
        return statuses.pop(0)

    monkeypatch.setattr(client, "_request_json", fake_request)
    monkeypatch.setattr("dsk.providers.service_client.time.sleep", sleeps.append)

    assert client._poll_status("REQ3") == {"status": "completed"}
    assert sleeps == [0.1]


def test_provider_wired_via_cli_provider_service(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    path = tmp_path / "env.yaml"
    path.write_text(
        """
version: "1"
name: svc-test
shared_folders:
  resources:
    uid_ref: sf.resources
    manage_users: true
    manage_records: true
    can_edit: true
    can_share: true
gateways:
  - uid_ref: gw.existing
    name: Existing Gateway
    mode: reference_existing
pam_configurations:
  - uid_ref: cfg.existing
    title: Existing Config
    environment: local
    gateway_uid_ref: gw.existing
resources:
  - uid_ref: res.db
    type: pamDatabase
    title: prod-db
    pam_configuration_uid_ref: cfg.existing
    shared_folder: resources
    database_type: mysql
    database_id: prod
    host: db.example.com
    port: "3306"
""".strip(),
        encoding="utf-8",
    )

    monkeypatch.setenv("KEEPER_SERVICE_API_KEY", "token")
    monkeypatch.setattr(
        CommanderServiceProvider,
        "discover",
        lambda self: [],
    )

    result = CliRunner().invoke(
        main,
        ["--provider", "service", "plan", str(path), "--json"],
        catch_exceptions=False,
    )

    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["summary"]["create"] == 2


# ── Sprint BG: commander_service helper unit tests ─────────────────────────


def test_status_helper_falls_back_to_state() -> None:
    """_status returns lowercase value from 'state' key when 'status' absent."""
    from dsk.providers.commander_service import _status

    assert _status({"state": "Completed"}) == "completed"
    assert _status({"status": "RUNNING"}) == "running"
    assert _status({}) == ""


def test_failure_reason_extracts_first_match() -> None:
    """_failure_reason returns first non-empty value from candidate keys."""
    from dsk.providers.commander_service import _failure_reason

    payload = {"reason": "access denied", "message": "other"}
    assert _failure_reason(payload, fallback="default") == "access denied"


def test_failure_reason_fallback_when_no_keys() -> None:
    """_failure_reason returns fallback when no recognized key has value."""
    from dsk.providers.commander_service import _failure_reason

    assert _failure_reason({}, fallback="fallback text") == "fallback text"


def test_extract_json_payload_list_passthrough() -> None:
    """_extract_json_payload returns list input directly."""
    from dsk.providers.commander_service import _extract_json_payload

    result = _extract_json_payload([1, 2, 3])
    assert result == [1, 2, 3]


def test_extract_json_payload_from_records_key() -> None:
    """_extract_json_payload extracts 'records' key from dict."""
    from dsk.providers.commander_service import _extract_json_payload

    result = _extract_json_payload({"records": [{"keeper_uid": "U1"}], "other": "ignored"})
    assert result == [{"keeper_uid": "U1"}]


def test_extract_json_payload_from_stdout_key() -> None:
    """_extract_json_payload parses JSON from stdout key."""
    from dsk.providers.commander_service import _extract_json_payload

    result = _extract_json_payload({"stdout": '[{"keeper_uid": "U2"}]'})
    assert isinstance(result, list)


def test_extract_json_payload_non_dict_returns_as_is() -> None:
    """_extract_json_payload returns primitive types unchanged."""
    from dsk.providers.commander_service import _extract_json_payload

    assert _extract_json_payload(42) == 42


def test_json_or_value_empty_string_returns_list() -> None:
    """_json_or_value returns [] for empty/whitespace string."""
    from dsk.providers.commander_service import _json_or_value

    assert _json_or_value("  ") == []


def test_json_or_value_invalid_json_returns_string() -> None:
    """_json_or_value returns the original string when not valid JSON."""
    from dsk.providers.commander_service import _json_or_value

    assert _json_or_value("not json") == "not json"


def test_looks_like_record_with_record_uid() -> None:
    """_looks_like_record returns True for a record-like row with record_uid."""
    from dsk.providers.commander_service import _looks_like_record

    assert _looks_like_record({"record_uid": "X", "type": "pamMachine"})
    assert not _looks_like_record({"title": "no uid"})


def test_live_record_from_row_with_pam_resource_uid() -> None:
    """_live_record_from_row creates LiveRecord using pam_resource_uid fallback."""
    from dsk.providers.commander_service import _live_record_from_row

    row = {"pam_resource_uid": "PAM123", "title": "PAM host", "resource_type": "pamMachine"}
    live = _live_record_from_row(row)
    assert live is not None
    assert live.keeper_uid == "PAM123"


def test_live_record_from_row_returns_none_without_uid() -> None:
    """_live_record_from_row returns None when no UID key is present."""
    from dsk.providers.commander_service import _live_record_from_row

    result = _live_record_from_row({"title": "no uid", "resource_type": "pamMachine"})
    assert result is None


def test_live_record_from_row_returns_none_without_resource_type() -> None:
    """_live_record_from_row returns None when resource_type is empty."""
    from dsk.providers.commander_service import _live_record_from_row

    result = _live_record_from_row({"keeper_uid": "X", "resource_type": ""})
    assert result is None


def test_commander_resource_fallback_to_type() -> None:
    """_commander_resource returns resource_type unchanged for unmapped types."""
    from dsk.providers.commander_service import _commander_resource

    result = _commander_resource("unknown_resource_type")
    assert result == "unknown_resource_type"


def test_command_value_dict_produces_json() -> None:
    """_command_value encodes dicts as compact JSON."""
    import json

    from dsk.providers.commander_service import _command_value

    val = _command_value({"key": "value"})
    assert json.loads(val) == {"key": "value"}


def test_command_value_bool_true() -> None:
    """_command_value returns 'true'/'false' for bool values."""
    from dsk.providers.commander_service import _command_value

    assert _command_value(True) == "true"
    assert _command_value(False) == "false"


def test_keeper_uid_from_result_nested_dict() -> None:
    """_keeper_uid_from_result recursively searches nested 'result' dict."""
    from dsk.providers.commander_service import _keeper_uid_from_result

    result = {"result": {"keeper_uid": "NESTED_UID"}}
    assert _keeper_uid_from_result(result) == "NESTED_UID"


def test_keeper_uid_from_result_returns_none_when_missing() -> None:
    """_keeper_uid_from_result returns None when no UID key found."""
    from dsk.providers.commander_service import _keeper_uid_from_result

    assert _keeper_uid_from_result({"other": "data"}) is None


def test_optional_str_none_returns_none() -> None:
    """_optional_str returns None for None input."""
    from dsk.providers.commander_service import _optional_str

    assert _optional_str(None) is None
    assert _optional_str("value") == "value"
    assert _optional_str(42) == "42"
