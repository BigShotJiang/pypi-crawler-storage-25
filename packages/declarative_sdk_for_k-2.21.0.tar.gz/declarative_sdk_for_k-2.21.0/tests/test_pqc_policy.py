"""Tests for PQC policy manifest models."""

from pathlib import Path

import yaml


def test_pqc_policy_defaults():
    from dsk.core.models_pqc import PqcAlgorithm, PqcPolicyManifestV1

    m = PqcPolicyManifestV1(**{"schema": "pqc-policy.v1", "name": "test"})
    assert m.schema_ == "pqc-policy.v1"
    assert m.default_algorithm == PqcAlgorithm.kyber_768
    assert m.audit_log is True
    assert m.requirements == []


def test_pqc_manifest_round_trip():
    from dsk.core.models_pqc import (
        PqcAlgorithm,
        PqcMigrationStatus,
        PqcPolicyManifestV1,
    )

    example = Path(__file__).parent.parent / "examples/pqc/acme-pqc-policy.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = PqcPolicyManifestV1(**data)
    assert manifest.schema_ == "pqc-policy.v1"
    assert len(manifest.requirements) == 4
    assert manifest.requirements[1].required_algorithm == PqcAlgorithm.kyber_1024
    assert manifest.requirements[1].current_status == PqcMigrationStatus.completed
    exempt = manifest.requirements[3]
    assert exempt.current_status == PqcMigrationStatus.exempt
    assert exempt.exemption_justification is not None


def test_pqc_requirement_defaults():
    from dsk.core.models_pqc import (
        PqcAlgorithm,
        PqcMigrationStatus,
        PqcResourceRequirement,
    )

    req = PqcResourceRequirement(uid_ref="res.test")
    assert req.required_algorithm == PqcAlgorithm.kyber_768
    assert req.current_status == PqcMigrationStatus.not_started


def test_pqc_schema_alias():
    from dsk.core.models_pqc import PqcPolicyManifestV1

    m = PqcPolicyManifestV1(**{"schema": "pqc-policy.v1", "name": "test"})
    assert m.schema_ == "pqc-policy.v1"


def test_pqc_requirement_exemption_justification_field() -> None:
    """Exempt resources carry a human justification string."""
    from dsk.core.models_pqc import (
        PqcMigrationStatus,
        PqcResourceRequirement,
    )

    req = PqcResourceRequirement(
        uid_ref="res.legacy",
        current_status=PqcMigrationStatus.exempt,
        exemption_justification="Vendor appliance; PQC not available until 2028",
    )
    assert req.exemption_justification.startswith("Vendor")


def test_pqc_policy_manifest_default_empty_frameworks() -> None:
    """Framework tags are optional metadata for policy consumers."""
    from dsk.core.models_pqc import PqcPolicyManifestV1

    manifest = PqcPolicyManifestV1(**{"schema": "pqc-policy.v1", "name": "standalone"})
    assert manifest.frameworks == []


def test_pqc_policy_manifest_accepts_compliance_framework_enums() -> None:
    from dsk.core.models_pqc import PqcComplianceFramework, PqcPolicyManifestV1

    m = PqcPolicyManifestV1(
        **{
            "schema": "pqc-policy.v1",
            "name": "fed",
            "frameworks": ["nsm-10", "nist-pqc"],
        }
    )
    assert PqcComplianceFramework.nsm10 in m.frameworks
    assert PqcComplianceFramework.nist_pqc in m.frameworks
