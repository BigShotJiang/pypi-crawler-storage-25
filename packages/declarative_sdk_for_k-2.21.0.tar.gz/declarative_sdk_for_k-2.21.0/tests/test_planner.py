from pathlib import Path

from dsk.core import (
    build_graph,
    build_plan,
    compute_diff,
    execution_order,
    load_manifest,
)
from dsk.core.diff import Change, ChangeKind
from dsk.core.planner import Plan


def test_ordered_plan_creates_deps_first(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    graph = build_graph(manifest)
    order = execution_order(graph)
    changes = compute_diff(manifest, live_records=[])
    plan = build_plan(manifest.name, changes, order)
    uids = [c.uid_ref for c in plan.ordered() if c.kind is ChangeKind.CREATE and c.uid_ref]
    assert uids.index("acme-lab-cfg") < uids.index("acme-lab-linux1")


def test_plan_is_clean_when_no_changes(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    plan = build_plan(manifest.name, [], [])
    assert plan.is_clean


def test_plan_not_clean_with_create_change() -> None:
    change = Change(
        kind=ChangeKind.CREATE,
        resource_type="pam_machine",
        uid_ref="machine.x",
        title="X",
        keeper_uid=None,
        reason=None,
        before=None,
        after={"hostname": "x"},
    )
    plan = Plan(manifest_name="test", changes=[change])
    assert not plan.is_clean
    assert len(plan.creates) == 1
    assert plan.creates[0].uid_ref == "machine.x"


def test_plan_categorises_create_update_delete_noop() -> None:
    changes = [
        Change(
            kind=ChangeKind.CREATE,
            resource_type="t",
            uid_ref="c1",
            title="C1",
            keeper_uid=None,
            reason=None,
            before=None,
            after={},
        ),
        Change(
            kind=ChangeKind.UPDATE,
            resource_type="t",
            uid_ref="u1",
            title="U1",
            keeper_uid="uid22chars0000000000AB",
            reason=None,
            before={},
            after={},
        ),
        Change(
            kind=ChangeKind.DELETE,
            resource_type="t",
            uid_ref="d1",
            title="D1",
            keeper_uid="uid22chars0000000000AB",
            reason=None,
            before={},
            after=None,
        ),
        Change(
            kind=ChangeKind.NOOP,
            resource_type="t",
            uid_ref="n1",
            title="N1",
            keeper_uid="uid22chars0000000000AB",
            reason=None,
            before={},
            after={},
        ),
    ]
    plan = Plan(manifest_name="cat-test", changes=changes)
    assert len(plan.creates) == 1
    assert len(plan.updates) == 1
    assert len(plan.deletes) == 1
    assert len(plan.noops) == 1
    assert len(plan.conflicts) == 0


def test_plan_conflict_change_is_counted() -> None:
    change = Change(
        kind=ChangeKind.CONFLICT,
        resource_type="pam_machine",
        uid_ref="machine.conflict",
        title="Conflict",
        keeper_uid=None,
        reason="duplicate uid_ref",
        before=None,
        after=None,
    )
    plan = Plan(manifest_name="conflict-test", changes=[change])
    assert len(plan.conflicts) == 1
    assert not plan.is_clean


def test_plan_ordered_returns_all_changes(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    graph = build_graph(manifest)
    order = execution_order(graph)
    changes = compute_diff(manifest, live_records=[])
    plan = build_plan(manifest.name, changes, order)
    ordered = list(plan.ordered())
    assert len(ordered) == len(changes)
