"""Offline tests for CommanderServiceClient."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from dsk.core.errors import CapabilityError
from dsk.providers.service_client import _MAX_RESPONSE_BYTES, CommanderServiceClient


def _client(**kw) -> CommanderServiceClient:
    return CommanderServiceClient(base_url="http://localhost:4020", api_key="test-key", **kw)


def test_client_default_construction() -> None:
    """CommanderServiceClient can be constructed with defaults."""
    c = CommanderServiceClient()
    assert c.base_url == "http://localhost:4020"
    assert c.timeout == 300


def test_client_custom_base_url_strips_trailing_slash() -> None:
    c = CommanderServiceClient(base_url="http://srv:9090/")
    assert c.base_url == "http://srv:9090"


def test_decrypt_response_passthrough_without_ciphertext() -> None:
    """_decrypt_response returns payload unchanged if ciphertext key is missing."""
    c = _client()
    result = c._decrypt_response({"foo": "bar"})
    assert result == {"foo": "bar"}


def test_decrypt_response_raises_without_encryption_key() -> None:
    """_decrypt_response raises CapabilityError if ciphertext present but no key."""
    c = _client()
    with pytest.raises(CapabilityError, match="encryption_key"):
        c._decrypt_response({"ciphertext": "abc123", "nonce": "nonce123"})


def test_request_json_http_error_raises_capability_error() -> None:
    """_request_json raises CapabilityError on HTTP 403."""
    import urllib.error

    c = _client()

    class FakeHTTPError(urllib.error.HTTPError):
        def __init__(self):
            pass

        code = 403
        headers: dict = {}  # type: ignore[assignment]

    with patch("urllib.request.urlopen", side_effect=FakeHTTPError()):
        with pytest.raises(CapabilityError, match="403"):
            c._request_json("GET", "/test")


def test_request_json_url_error_raises_capability_error() -> None:
    """_request_json raises CapabilityError on URLError."""
    import urllib.error

    c = _client()
    with patch("urllib.request.urlopen", side_effect=urllib.error.URLError("no route")):
        with pytest.raises(CapabilityError, match="request failed"):
            c._request_json("GET", "/test")


def test_poll_status_returns_timeout_when_deadline_exceeded() -> None:
    """_poll_status returns status=expired when deadline passes before completion."""
    c = _client(timeout=0, poll_interval=0.0)

    with patch.object(c, "_request_json", return_value={"status": "pending"}):
        result = c._poll_status("req-123", timeout=0)
    assert result["status"] in ("expired", "pending")


# ── Sprint BD: additional helper coverage ────────────────────────────────


def test_first_str_returns_none_when_no_match() -> None:
    """_first_str returns None when none of the keys have a string value."""
    from dsk.providers.service_client import _first_str

    assert _first_str({}, "a", "b") is None
    assert _first_str({"a": 123, "b": None}, "a", "b") is None


def test_first_str_returns_stripped_first_match() -> None:
    """_first_str returns stripped value of first matching key."""
    from dsk.providers.service_client import _first_str

    assert _first_str({"a": "  hello  ", "b": "world"}, "a", "b") == "hello"


def test_status_helper_state_fallback() -> None:
    """_status falls back to 'state' key when 'status' is absent."""
    from dsk.providers.service_client import _status

    assert _status({"state": "Completed"}) == "completed"
    assert _status({}) == ""


def test_retry_delay_parses_retry_after_header() -> None:
    """_retry_delay returns parsed float from retry_after string."""
    from dsk.providers.service_client import _retry_delay

    assert _retry_delay("3.0", attempt=0) == 3.0
    assert _retry_delay("0", attempt=5) == 0.0


def test_retry_delay_uses_exponential_backoff_on_invalid() -> None:
    """_retry_delay falls back to exponential backoff when retry_after is invalid."""
    from dsk.providers.service_client import _retry_delay

    delay = _retry_delay("not-a-number", attempt=2)
    assert delay > 0.0


def test_retry_delay_caps_at_2_seconds() -> None:
    """_retry_delay caps at 2.0 when retry_after is None and attempt is high."""
    from dsk.providers.service_client import _retry_delay

    assert _retry_delay(None, attempt=20) == 2.0


def test_decode_key_passes_through_bytes() -> None:
    """_decode_key returns bytes unchanged."""
    from dsk.providers.service_client import _decode_key

    key = b"rawbytes"
    assert _decode_key(key) is key


def test_decode_key_decodes_base64_string() -> None:
    """_decode_key decodes base64-encoded string to bytes."""
    import base64

    from dsk.providers.service_client import _decode_key

    encoded = base64.b64encode(b"secret").decode("utf-8")
    assert _decode_key(encoded) == b"secret"


def test_decode_key_falls_back_to_utf8_on_invalid_base64() -> None:
    """_decode_key encodes to UTF-8 when base64 decode fails."""
    from dsk.providers.service_client import _decode_key

    result = _decode_key("not@@base64!!!")
    assert isinstance(result, bytes)


def test_post_async_raises_on_missing_request_id() -> None:
    """_post_async raises CapabilityError when response lacks request_id."""
    from unittest.mock import patch

    from dsk.core.errors import CapabilityError

    c = _client()
    with patch.object(c, "_request_json", return_value={"status": "ok"}):
        with pytest.raises(CapabilityError, match="request_id"):
            c._post_async("commander.get-enterprise-data")


def test_get_result_non_encrypted_returns_payload() -> None:
    """_get_result returns payload directly when encrypted=False."""
    from unittest.mock import patch

    c = _client()
    payload = {"result": "ok", "data": [1, 2, 3]}
    with patch.object(c, "_request_json", return_value=payload):
        result = c._get_result("req-abc")
    assert result == payload


# ── coverage: lines 74, 100, 103, 122-127, 144-161 ────────────────────────


def test_get_result_encrypted_calls_decrypt() -> None:
    """_get_result calls _decrypt_response when encrypted=True."""
    c = CommanderServiceClient(base_url="http://x", api_key="k", encrypted=True)
    raw = {"ciphertext": "abc", "nonce": "nonce"}
    with (
        patch.object(c, "_request_json", return_value=raw),
        patch.object(c, "_decrypt_response", return_value={"ok": 1}) as mock_dec,
    ):
        result = c._get_result("req-1")
    assert result == {"ok": 1}
    mock_dec.assert_called_once_with(raw)


def test_request_json_empty_response_returns_empty_dict() -> None:
    """_request_json returns {} when response body is blank."""
    c = _client()
    resp = type(
        "R",
        (),
        {"read": lambda self: b"  ", "__enter__": lambda s: s, "__exit__": lambda s, *a: None},
    )()
    with patch("urllib.request.urlopen", return_value=resp):
        result = c._request_json("GET", "/api/v2/status")
    assert result == {}


def test_request_json_list_response_wrapped() -> None:
    """_request_json wraps list responses as {'result': list}."""
    import json

    c = _client()
    body = json.dumps([1, 2, 3]).encode()
    resp = type(
        "R",
        (),
        {"read": lambda self: body, "__enter__": lambda s: s, "__exit__": lambda s, *a: None},
    )()
    with patch("urllib.request.urlopen", return_value=resp):
        result = c._request_json("GET", "/api/v2/list")
    assert result == {"result": [1, 2, 3]}


def test_request_json_rejects_oversized_response() -> None:
    c = _client()
    body = b"x" * (_MAX_RESPONSE_BYTES + 1)
    resp = type(
        "R",
        (),
        {
            "read": lambda self, _size=-1: body,
            "__enter__": lambda s: s,
            "__exit__": lambda s, *a: None,
        },
    )()

    with patch("urllib.request.urlopen", return_value=resp):
        with pytest.raises(CapabilityError, match="response exceeded"):
            c._request_json("GET", "/api/v2/large")


def test_request_json_429_retries_then_raises() -> None:
    """HTTP 429 triggers retry up to 3 attempts then raises CapabilityError."""
    import http.client
    import urllib.error

    c = _client()

    headers = http.client.HTTPMessage()
    err = urllib.error.HTTPError(url="/", code=429, msg="Too Many Requests", hdrs=headers, fp=None)
    with (
        patch("urllib.request.urlopen", side_effect=err),
        patch("time.sleep"),
    ):  # don't actually sleep in tests
        with pytest.raises(CapabilityError, match="429"):
            c._request_json("GET", "/api/v2/health")


def test_decrypt_response_no_ciphertext_returns_raw() -> None:
    """_decrypt_response returns payload as-is if no ciphertext field."""
    c = CommanderServiceClient(
        base_url="http://x", api_key="k", encrypted=True, encryption_key=None
    )
    payload = {"status": "ok"}
    result = c._decrypt_response(payload)
    assert result == payload


def test_decrypt_response_no_key_raises_capability() -> None:
    """_decrypt_response raises CapabilityError when encryption_key is None but data is present."""
    import base64

    c = CommanderServiceClient(
        base_url="http://x", api_key="k", encrypted=True, encryption_key=None
    )
    payload = {
        "ciphertext": base64.b64encode(b"data").decode(),
        "nonce": base64.b64encode(b"iv123456").decode(),
    }
    with pytest.raises(CapabilityError, match="encryption_key"):
        c._decrypt_response(payload)
