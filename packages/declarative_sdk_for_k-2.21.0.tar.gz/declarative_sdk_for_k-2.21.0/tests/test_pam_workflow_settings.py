"""Post-import ``pam workflow`` argv wiring for ``workflow_settings`` on PAM resources."""

from __future__ import annotations

import builtins
import importlib

import pytest
from pydantic import ValidationError

from dsk.core.diff import Change, ChangeKind, compute_diff
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import LiveRecord
from dsk.core.metadata import encode_marker
from dsk.core.models import Manifest, PamDatabase
from dsk.core.planner import Plan, build_plan
from dsk.providers import commander_cli as commander_cli_mod
from dsk.providers.commander_cli import (
    build_pam_workflow_apply_argvs,
    build_post_import_tuning_argvs,
)
from dsk.providers.mock import MockProvider


def test_workflow_settings_absent_no_pam_workflow_in_post_import_argv() -> None:
    argvs = build_post_import_tuning_argvs(
        "record-1",
        {"type": "pamMachine", "title": "m1"},
        change_kind=ChangeKind.UPDATE,
        manifest={"name": "p", "resources": []},
    )
    assert argvs == []


def test_workflow_settings_update_argv_pam_machine() -> None:
    argvs = build_post_import_tuning_argvs(
        "rec-m",
        {
            "type": "pamMachine",
            "title": "web",
            "workflow_settings": {"approvals_needed": 0, "checkout_needed": True},
        },
        change_kind=ChangeKind.UPDATE,
        manifest={"name": "p", "resources": []},
    )
    assert argvs == [
        [
            "pam",
            "workflow",
            "update",
            "rec-m",
            "-n",
            "0",
            "-co",
            "true",
        ]
    ]


def test_workflow_settings_update_argv_pam_database() -> None:
    argvs = build_pam_workflow_apply_argvs(
        "rec-db",
        {
            "type": "pamDatabase",
            "title": "postgres",
            "workflow_settings": {"require_reason": True},
        },
        change_kind=ChangeKind.UPDATE,
        manifest={},
    )
    assert argvs == [["pam", "workflow", "update", "rec-db", "-rr", "true"]]


def test_workflow_settings_schema_rejects_invalid_allowed_day() -> None:
    with pytest.raises(ValidationError):
        PamDatabase.model_validate(
            {
                "uid_ref": "db1",
                "type": "pamDatabase",
                "title": "db",
                "database_type": "postgresql",
                "workflow_settings": {"allowed_days": ["Mon", "FUN"]},
            }
        )


def test_resolve_post_import_capability_error_on_workflow_approver_uid_refs_update() -> None:
    plan = Plan(manifest_name="proj", changes=[], order=[])
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="res1",
        resource_type="pamMachine",
        title="m",
        keeper_uid="live-uid",
        before={},
        after={"workflow_settings": {"approver_uid_refs": ["u.appr"]}},
    )
    manifest = {
        "name": "proj",
        "resources": [
            {
                "uid_ref": "res1",
                "type": "pamMachine",
                "title": "m",
                "workflow_settings": {"approver_uid_refs": ["u.appr"]},
            }
        ],
    }
    with pytest.raises(CapabilityError, match="approver_uid_refs"):
        commander_cli_mod._resolve_post_import_tuning_argvs(
            manifest,
            plan=plan,
            live_records=[
                LiveRecord(
                    keeper_uid="live-uid",
                    title="m",
                    resource_type="pamMachine",
                    payload={"type": "pamMachine", "title": "m"},
                    marker=encode_marker(
                        uid_ref="res1",
                        manifest="proj",
                        resource_type="pamMachine",
                    ),
                )
            ],
            changes=[change],
        )


def test_ensure_pam_workflow_raises_capability_when_import_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    real_import = builtins.__import__

    def fake_import(
        name: str,
        globals: dict[str, object] | None = None,
        locals: dict[str, object] | None = None,
        fromlist: tuple[str, ...] = (),
        level: int = 0,
    ) -> object:
        if name == "keepercommander.commands.workflow.config_commands":
            raise ImportError("simulated missing pam workflow")
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    importlib.reload(commander_cli_mod)
    try:
        with pytest.raises(CapabilityError, match="pam workflow"):
            commander_cli_mod._ensure_pam_workflow_config_commands_available()
    finally:
        monkeypatch.undo()
        importlib.reload(commander_cli_mod)


def test_planner_emits_update_when_workflow_settings_drift() -> None:
    manifest = Manifest.model_validate(
        {
            "version": "1",
            "name": "n",
            "gateways": [{"uid_ref": "gw", "name": "Gw"}],
            "pam_configurations": [
                {
                    "uid_ref": "cfg",
                    "environment": "local",
                    "title": "cfg-title",
                    "gateway_uid_ref": "gw",
                }
            ],
            "resources": [
                {
                    "uid_ref": "m1",
                    "type": "pamMachine",
                    "title": "machine",
                    "pam_configuration_uid_ref": "cfg",
                    "workflow_settings": {"checkout_needed": True},
                }
            ],
        }
    )
    live_records = [
        LiveRecord(
            keeper_uid="k1",
            title="machine",
            resource_type="pamMachine",
            payload={
                "type": "pamMachine",
                "title": "machine",
                "pam_configuration_uid_ref": "cfg-title",
            },
            marker=encode_marker(
                uid_ref="m1",
                manifest="n",
                resource_type="pamMachine",
            ),
        )
    ]
    changes = compute_diff(
        manifest,
        live_records,
        manifest_name="n",
    )
    order = [c.uid_ref for c in changes if c.uid_ref]
    plan = build_plan("n", changes, order)
    update_rows = [
        c
        for c in plan.changes
        if c.kind == ChangeKind.UPDATE and c.uid_ref == "m1" and c.resource_type == "pamMachine"
    ]
    assert len(update_rows) == 1
    assert update_rows[0].after is not None
    assert update_rows[0].after.get("workflow_settings", {}).get("checkout_needed") is True


def test_mock_provider_dry_run_records_workflow_argvs() -> None:
    plan = Plan(
        manifest_name="demo",
        changes=[
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="r1",
                resource_type="pamMachine",
                title="m",
                keeper_uid="uid-1",
                after={"workflow_settings": {"require_mfa": True}},
            )
        ],
        order=["r1"],
    )
    provider = MockProvider("demo")
    provider._records["uid-1"] = LiveRecord(
        keeper_uid="uid-1",
        title="m",
        resource_type="pamMachine",
        payload={"type": "pamMachine", "title": "m", "host": "h1"},
    )
    outcomes = provider.apply_plan(plan, dry_run=True)
    assert outcomes[0].details["workflow_argvs"] == [
        ["pam", "workflow", "update", "uid-1", "-rm", "true"]
    ]


def test_to_pam_import_json_drops_workflow_settings() -> None:
    from dsk.core.normalize import to_pam_import_json

    doc = to_pam_import_json(
        {
            "version": "1",
            "name": "p",
            "pam_configurations": [{"uid_ref": "c", "title": "cfg"}],
            "resources": [
                {
                    "uid_ref": "m",
                    "type": "pamMachine",
                    "title": "x",
                    "pam_configuration_uid_ref": "c",
                    "workflow_settings": {"checkout_needed": True},
                }
            ],
        }
    )
    resources = (doc.get("pam_data") or {}).get("resources") or []
    assert resources
    assert "workflow_settings" not in resources[0]
