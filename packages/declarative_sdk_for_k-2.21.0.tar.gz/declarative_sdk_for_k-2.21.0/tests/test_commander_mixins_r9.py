"""Focused R9 coverage for CommanderCliProvider mixin primary methods."""

from __future__ import annotations

from typing import Any

import pytest

import dsk.providers.commander_cli as commander_cli
from dsk.core import CapabilityError, Change, ChangeKind, build_plan
from dsk.providers.commander_cli import CommanderCliProvider


def _provider(monkeypatch: pytest.MonkeyPatch, **kwargs: Any) -> CommanderCliProvider:
    monkeypatch.setattr(commander_cli.shutil, "which", lambda _bin: "/usr/bin/keeper")
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    return CommanderCliProvider(folder_uid="MARKERS", **kwargs)


def test_transport_service_mode_command_success(monkeypatch: pytest.MonkeyPatch) -> None:
    class FakeClient:
        def _request_json(self, method: str, path: str) -> dict[str, str]:
            assert (method, path) == ("GET", "/health")
            return {"status": "ok"}

        def _post_async(self, command: str, filedata: object) -> str:
            assert command == "enterprise-info"
            assert filedata is None
            return "REQ1"

        def _poll_status(self, request_id: str, timeout: int) -> dict[str, str]:
            assert (request_id, timeout) == ("REQ1", 300)
            return {"status": "completed"}

        def _get_result(self, request_id: str) -> dict[str, str]:
            assert request_id == "REQ1"
            return {"stdout": '{"enterprise": true}'}

    provider = _provider(
        monkeypatch,
        service_mode=True,
        service_api_key="api-key",
        service_client=FakeClient(),
    )

    assert provider._run_service_mode_cmd(["enterprise-info"]) == '{"enterprise": true}'


def test_transport_service_mode_failure_raises_capability(monkeypatch: pytest.MonkeyPatch) -> None:
    class FakeClient:
        def _request_json(self, _method: str, _path: str) -> dict[str, str]:
            return {"status": "ok"}

        def _post_async(self, _command: str, _filedata: object) -> str:
            return "REQ1"

        def _poll_status(self, _request_id: str, _timeout: int) -> dict[str, str]:
            return {"status": "failed", "message": "bad command"}

    provider = _provider(
        monkeypatch,
        service_mode=True,
        service_api_key="api-key",
        service_client=FakeClient(),
    )

    with pytest.raises(CapabilityError) as exc:
        provider._run_service_mode_cmd(["enterprise-info"])

    assert "bad command" in exc.value.reason


def test_vault_mixin_dry_run_create_and_permission_helpers(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _provider(monkeypatch, manifest_source={"schema": "keeper-vault.v1"})
    plan = build_plan(
        "vault",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="rec.one",
                resource_type="login",
                title="One",
                after={"title": "One", "type": "login"},
            )
        ],
        ["rec.one"],
    )

    outcomes = provider._apply_vault_plan(plan, dry_run=True)

    assert outcomes[0].action == "create"
    assert outcomes[0].details == {"dry_run": True}
    assert provider._vault_shared_folder_role_permissions("manage") == (True, True)
    assert provider._folder_parent_path("Root/Child/Grandchild") == "Root/Child"
    assert provider._commander_path_components("Root/Child") == ["Root", "Child"]


def test_sharing_mixin_dry_run_orders_deletes_and_conflicts(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _provider(monkeypatch)
    plan = build_plan(
        "sharing",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="folder.one",
                resource_type="sharing_folder",
                title="Folder",
                after={"path": "Folder"},
            ),
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="share.one",
                resource_type="sharing_share_folder",
                title="Share",
                keeper_uid="SHARE_UID",
            ),
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref="conflict.one",
                resource_type="sharing_folder",
                title="Conflict",
                reason="blocked",
            ),
        ],
        ["folder.one", "share.one", "conflict.one"],
    )

    outcomes = provider._apply_sharing_plan(plan, dry_run=True)

    assert [outcome.action for outcome in outcomes] == ["create", "delete", "conflict"]
    assert provider._sharing_grantee({"user_email": "u@example.com"}) == ("user", "u@example.com")
    assert provider._sharing_uid_ref_from_ref("folder:alpha") == "alpha"


def test_pam_core_apply_plan_dispatches_sharing_manifest(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _provider(monkeypatch, manifest_source={"schema": "keeper-vault-sharing.v1"})
    seen: list[tuple[object, bool]] = []
    monkeypatch.setattr(
        provider,
        "_apply_sharing_plan",
        lambda plan, dry_run=False, checkpoint=None: seen.append((plan, dry_run)) or [],
    )
    plan = build_plan("sharing", [], [])

    assert provider.apply_plan(plan, dry_run=True) == []
    assert seen == [(plan, True)]


def test_ksm_mixin_app_delete_dry_run(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider(monkeypatch)
    plan = build_plan(
        "ksm",
        [
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="app.one",
                resource_type="ksm_app",
                title="App",
                keeper_uid="APP_UID",
            )
        ],
        ["app.one"],
    )

    outcomes = provider.apply_ksm_plan(plan, dry_run=True)

    assert outcomes[0].action == "delete"
    assert outcomes[0].details["force"] is True
    assert outcomes[0].details["dry_run"] is True


def test_msp_mixin_managed_company_create_dry_run(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider(monkeypatch)
    monkeypatch.setattr(provider, "discover_managed_companies", lambda: [])
    plan = build_plan(
        "msp",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="mc.one",
                resource_type="managed_company",
                title="Acme MC",
                after={"name": "Acme MC", "plan": "business", "seats": 10},
            )
        ],
        ["mc.one"],
    )

    outcomes = provider.apply_msp_plan(plan, dry_run=True)

    assert outcomes[0].action == "create"
    assert outcomes[0].details["dry_run"] is True
    assert outcomes[0].details["kwargs"]["name"] == "Acme MC"


def test_enterprise_mixin_team_create_dry_run(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider(monkeypatch)
    plan = build_plan(
        "enterprise",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="team.one",
                resource_type="enterprise_team",
                title="Team",
                after={"name": "Security", "restrict_edit": True},
            )
        ],
        ["team.one"],
    )

    outcomes = provider.apply_enterprise_plan(plan, manifest=object(), dry_run=True)

    assert outcomes[0].action == "create"
    assert outcomes[0].details == {"dry_run": True, "team_name": "Security"}
