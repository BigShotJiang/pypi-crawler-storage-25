"""Tests for continuous evidence stream models."""

from pathlib import Path

import pytest
import yaml


def test_evidence_stream_defaults():
    from dsk.core.models_evidence_stream import (
        ContinuousEvidenceStreamManifestV1,
        EvidenceSamplingSchedule,
        EvidenceStorageBackend,
    )

    m = ContinuousEvidenceStreamManifestV1(
        **{"schema": "continuous-evidence-stream.v1", "name": "test"}
    )
    assert m.schema_ == "continuous-evidence-stream.v1"
    assert m.schedule == EvidenceSamplingSchedule.daily
    assert m.storage.backend == EvidenceStorageBackend.local
    assert m.alert_on_failure is True


def test_evidence_stream_round_trip():
    from dsk.core.models_evidence_stream import (
        ContinuousEvidenceStreamManifestV1,
        EvidenceSamplingSchedule,
        EvidenceStorageBackend,
    )

    example = Path(__file__).parent.parent / "examples/evidence-stream/acme-evidence-stream.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = ContinuousEvidenceStreamManifestV1(**data)
    assert manifest.schema_ == "continuous-evidence-stream.v1"
    assert manifest.schedule == EvidenceSamplingSchedule.daily
    assert manifest.storage.backend == EvidenceStorageBackend.s3
    assert manifest.storage.bucket == "acme-compliance-evidence"
    assert len(manifest.entries) == 4
    assert manifest.entries[0].control_id == "AC-2"


def test_storage_retention_minimum():
    from pydantic import ValidationError

    from dsk.core.models_evidence_stream import EvidenceStorageConfig

    with pytest.raises(ValidationError):
        EvidenceStorageConfig(retention_days=10)  # below 30-day minimum


def test_schema_alias():
    from dsk.core.models_evidence_stream import ContinuousEvidenceStreamManifestV1

    m = ContinuousEvidenceStreamManifestV1(
        **{"schema": "continuous-evidence-stream.v1", "name": "test"}
    )
    assert m.schema_ == "continuous-evidence-stream.v1"


def test_retention_days_minimum_boundary_ok():
    """Evidence retention may be exactly 30 days."""
    from dsk.core.models_evidence_stream import EvidenceStorageConfig

    cfg = EvidenceStorageConfig(retention_days=30)
    assert cfg.retention_days == 30


def test_evidence_stream_entry_defaults_empty_report_args():
    """EvidenceStreamEntry defaults report_args to empty list."""
    from dsk.core.models_evidence_stream import EvidenceStreamEntry

    e = EvidenceStreamEntry(
        control_id="AC-2",
        description="acct mgmt",
        report="compliance-report",
        evidence_file_prefix="ac-2",
    )
    assert e.report_args == []


def test_schedule_cron_allows_manifest_without_entries():
    """schedule=cron is valid; cron field can be set for future use."""
    from dsk.core.models_evidence_stream import (
        ContinuousEvidenceStreamManifestV1,
        EvidenceSamplingSchedule,
    )

    m = ContinuousEvidenceStreamManifestV1(
        **{
            "schema": "continuous-evidence-stream.v1",
            "name": "crony",
            "schedule": EvidenceSamplingSchedule.cron,
            "cron": "0 0 * * *",
        }
    )
    assert m.schedule == EvidenceSamplingSchedule.cron
    assert m.cron == "0 0 * * *"


# ── coverage: evidence_stream_diff.py lines 21, 44-45 ─────────────────────


def test_compute_evidence_stream_diff_live_raises():
    from dsk.core.evidence_stream_diff import compute_evidence_stream_diff
    from dsk.core.models_evidence_stream import ContinuousEvidenceStreamManifestV1

    m = ContinuousEvidenceStreamManifestV1.model_validate(
        {"schema": "continuous-evidence-stream.v1", "name": "ev", "version": "1", "manager": "dsk"}
    )
    with pytest.raises(NotImplementedError):
        compute_evidence_stream_diff(m, live={"x": 1})


def test_compute_evidence_stream_diff_with_frameworks():
    from dsk.core.evidence_stream_diff import compute_evidence_stream_diff
    from dsk.core.models_evidence_stream import ContinuousEvidenceStreamManifestV1

    m = ContinuousEvidenceStreamManifestV1.model_validate(
        {
            "schema": "continuous-evidence-stream.v1",
            "name": "ev",
            "version": "1",
            "manager": "dsk",
            "frameworks": ["soc2"],
        }
    )
    changes = compute_evidence_stream_diff(m, manifest_name="my-ev")
    fw = [c for c in changes if c.resource_type == "evidence_framework"]
    assert len(fw) == 1
