"""Security hardening regression tests.

Covers the URL-scheme allowlists, default-bind hardening, and other
guards added in response to the OX Security MCP-stdio disclosure
(VentureBeat, 2026-05-01) and DSK-specific threat model in
``SECURITY_AUDIT.md``.

The DSK MCP server itself does **not** execute arbitrary OS commands —
it dispatches to typed Python tool handlers — so the OX-flagged
"STDIO transport executes any OS command" class of bug does not apply
to it. These tests pin the adjacent guards we added on URL inputs,
default network binds, and YAML loading so they cannot regress.
"""

from __future__ import annotations

import importlib
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------------------
# 1. Service-mode REST client must reject non-http(s) base URLs.
# ---------------------------------------------------------------------------


def test_service_client_rejects_file_scheme() -> None:
    from dsk.core.errors import CapabilityError
    from dsk.providers.service_client import CommanderServiceClient

    with pytest.raises(CapabilityError) as exc:
        CommanderServiceClient(base_url="file:///etc/passwd", api_key="x")
    assert "scheme" in str(exc.value).lower()


def test_service_client_rejects_gopher_scheme() -> None:
    from dsk.core.errors import CapabilityError
    from dsk.providers.service_client import CommanderServiceClient

    with pytest.raises(CapabilityError):
        CommanderServiceClient(base_url="gopher://example.com:70/", api_key="x")


def test_service_client_rejects_ftp_scheme() -> None:
    from dsk.core.errors import CapabilityError
    from dsk.providers.service_client import CommanderServiceClient

    with pytest.raises(CapabilityError):
        CommanderServiceClient(base_url="ftp://internal/", api_key="x")


def test_service_client_rejects_empty_url() -> None:
    from dsk.core.errors import CapabilityError
    from dsk.providers.service_client import CommanderServiceClient

    with pytest.raises(CapabilityError):
        CommanderServiceClient(base_url="", api_key="x")


def test_service_client_rejects_url_without_host() -> None:
    from dsk.core.errors import CapabilityError
    from dsk.providers.service_client import CommanderServiceClient

    with pytest.raises(CapabilityError):
        CommanderServiceClient(base_url="http://", api_key="x")


def test_service_client_accepts_http() -> None:
    from dsk.providers.service_client import CommanderServiceClient

    client = CommanderServiceClient(base_url="http://localhost:4020", api_key="x")
    assert client.base_url == "http://localhost:4020"


def test_service_client_accepts_https() -> None:
    from dsk.providers.service_client import CommanderServiceClient

    client = CommanderServiceClient(base_url="https://commander.example.com/", api_key="x")
    assert client.base_url == "https://commander.example.com"


# ---------------------------------------------------------------------------
# 2. Ticket gate must reject non-http(s) JIRA_BASE_URL / SNOW_INSTANCE.
# ---------------------------------------------------------------------------


def test_ticket_gate_rejects_jira_file_scheme(monkeypatch: pytest.MonkeyPatch) -> None:
    from dsk.integrations.ticket_gate import TicketGateError, check_ticket

    monkeypatch.setenv("JIRA_BASE_URL", "file:///etc/passwd")
    monkeypatch.setenv("JIRA_TOKEN", "x")
    with pytest.raises(TicketGateError) as exc:
        check_ticket("INFRA-1", system="jira")
    assert "JIRA_BASE_URL" in str(exc.value)


def test_ticket_gate_rejects_snow_file_scheme(monkeypatch: pytest.MonkeyPatch) -> None:
    from dsk.integrations.ticket_gate import TicketGateError, check_ticket

    monkeypatch.setenv("SNOW_INSTANCE", "file:///etc/passwd")
    monkeypatch.setenv("SNOW_TOKEN", "x")
    with pytest.raises(TicketGateError) as exc:
        check_ticket("CHG0001", system="servicenow")
    assert "SNOW_INSTANCE" in str(exc.value)


# ---------------------------------------------------------------------------
# 3. ESO bridge defaults to loopback bind.
# ---------------------------------------------------------------------------


def test_eso_bridge_defaults_to_loopback(monkeypatch: pytest.MonkeyPatch) -> None:
    """run_bridge must default to 127.0.0.1, not 0.0.0.0."""
    monkeypatch.delenv("ESO_BRIDGE_HOST", raising=False)
    eso_bridge = importlib.import_module("dsk.integrations.eso_bridge")

    bound: dict[str, object] = {}

    class _FakeServer:
        def __init__(self, addr: tuple[str, int], _handler: object) -> None:
            bound["addr"] = addr

        def serve_forever(self) -> None:
            raise RuntimeError("stop")

    monkeypatch.setattr(eso_bridge, "HTTPServer", _FakeServer)
    with pytest.raises(RuntimeError):
        eso_bridge.run_bridge(port=18080)
    assert bound["addr"] == ("127.0.0.1", 18080)


def test_eso_bridge_explicit_opt_in_for_all_interfaces(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """0.0.0.0 must require explicit operator opt-in via env var."""
    eso_bridge = importlib.import_module("dsk.integrations.eso_bridge")
    monkeypatch.setenv("ESO_BRIDGE_HOST", "0.0.0.0")

    bound: dict[str, object] = {}

    class _FakeServer:
        def __init__(self, addr: tuple[str, int], _handler: object) -> None:
            bound["addr"] = addr

        def serve_forever(self) -> None:
            raise RuntimeError("stop")

    monkeypatch.setattr(eso_bridge, "HTTPServer", _FakeServer)
    with pytest.raises(RuntimeError):
        eso_bridge.run_bridge(port=18080)
    assert bound["addr"] == ("0.0.0.0", 18080)


# ---------------------------------------------------------------------------
# 4. Repository-wide invariants from the SECURITY_AUDIT.md threat model.
# ---------------------------------------------------------------------------


def _scan(predicate: str, ignore: tuple[str, ...] = ()) -> list[str]:
    """Scan dsk/ for any line containing ``predicate``."""
    hits: list[str] = []
    for path in (REPO_ROOT / "dsk").rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        text = path.read_text(encoding="utf-8")
        for lineno, line in enumerate(text.splitlines(), start=1):
            if predicate in line and not any(token in line for token in ignore):
                hits.append(f"{path.relative_to(REPO_ROOT)}:{lineno}: {line.strip()}")
    return hits


def test_no_shell_true_subprocess_in_keeper_sdk() -> None:
    """``shell=True`` is a known argv-injection foot-gun. Forbid it.

    The OX disclosure landed because MCP STDIO servers shelled out via
    ``shell=True`` and trusted caller-supplied strings. DSK never builds
    a shell command from a string; this test pins that invariant.
    """
    hits = _scan("shell=True")
    assert not hits, (
        "subprocess(..., shell=True) is forbidden in keeper_sdk; offenders:\n" + "\n".join(hits)
    )


def test_no_unsafe_yaml_loaders_in_keeper_sdk() -> None:
    """Only ``yaml.safe_load`` / ``safe_dump`` / ``safe_dump_all`` allowed.

    PyYAML's ``yaml.load`` without a SafeLoader instantiates arbitrary
    Python objects from YAML — equivalent to ``pickle.loads``. DSK must
    never accept that risk on manifest input.
    """
    forbidden = ("yaml.load(", "yaml.full_load(", "yaml.unsafe_load(")
    offenders: list[str] = []
    for token in forbidden:
        offenders.extend(_scan(token))
    assert not offenders, "Use yaml.safe_load instead. Offenders:\n" + "\n".join(offenders)


def test_no_eval_or_exec_in_keeper_sdk() -> None:
    """``eval`` / ``exec`` / ``pickle.loads`` are forbidden in product code."""
    offenders: list[str] = []
    offenders.extend(_scan("eval(", ignore=("# noqa",)))
    offenders.extend(_scan("exec(", ignore=("# noqa", "# safe", "executemany", "executable")))
    offenders.extend(_scan("pickle.loads", ignore=("# noqa",)))
    offenders.extend(_scan("marshal.loads", ignore=("# noqa",)))
    # Filter accidental hits in Python keywords used as identifiers.
    offenders = [
        h
        for h in offenders
        if not any(skip in h for skip in (".execute(", "execute_command", "execute_request"))
    ]
    assert not offenders, "eval/exec/pickle/marshal load forbidden in product code:\n" + "\n".join(
        offenders
    )


def test_redact_module_strips_keeper_password_env() -> None:
    """The redaction module must mask KEEPER_PASSWORD= in any captured text."""
    from dsk.core.redact import redact

    leaky = "running with KEEPER_PASSWORD=hunter2 set"
    redacted = redact(leaky)
    assert "hunter2" not in redacted
    assert "KEEPER_PASSWORD" in redacted


def test_redact_module_strips_bearer_tokens() -> None:
    from dsk.core.redact import redact

    leaky = "Authorization: Bearer abcdef0123456789ZZZZZZZZ"
    redacted = redact(leaky)
    assert "abcdef0123456789ZZZZZZZZ" not in redacted


def test_redact_module_strips_jwt() -> None:
    from dsk.core.redact import redact

    jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhYmMifQ.signaturepart"
    redacted = redact(f"token={jwt}")
    assert jwt not in redacted


# ---------------------------------------------------------------------------
# 5. SECURITY_AUDIT.md must exist and call out the MCP threat model.
# ---------------------------------------------------------------------------


def test_security_audit_doc_exists_and_addresses_mcp_stdio() -> None:
    audit = (REPO_ROOT / "SECURITY_AUDIT.md").read_text(encoding="utf-8")
    assert len(audit) > 3000, "SECURITY_AUDIT.md too thin to be a real audit"
    must_mention = (
        "MCP",
        "STDIO",
        "OX Security",
        "shell=True",
        "yaml.safe_load",
        "redact",
        "ownership marker",
        "SSRF",
    )
    missing = [m for m in must_mention if m.lower() not in audit.lower()]
    assert not missing, f"SECURITY_AUDIT.md is missing key topics: {missing}"
