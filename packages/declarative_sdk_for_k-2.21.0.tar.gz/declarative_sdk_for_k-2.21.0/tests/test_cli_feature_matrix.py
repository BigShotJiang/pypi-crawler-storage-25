"""Feature-coverage matrix: every public CLI subcommand must have at least
``--help`` smoke coverage.

This is a deliberate, narrow guard prompted by Craig Lurey's 2026-05-04
review feedback: "ask Claude to create a whole series of unit tests to
make sure that every feature is exercised in an automated way." The
deeper exit-code / behaviour tests for each command live in their own
files (see ``tests/SCAFFOLD.md``); this matrix only proves that no
command silently disappears or crashes on ``--help``.

If you add a new top-level ``dsk`` subcommand, add it to
``EXPECTED_SUBCOMMANDS`` so this test fails until you also add a real
behaviour test for it.
"""

from __future__ import annotations

import pytest
from click.testing import CliRunner

from dsk.cli import main

EXPECTED_SUBCOMMANDS: tuple[str, ...] = (
    "apply",
    "bootstrap-ksm",
    "bundle",
    "diff",
    "discover",
    "doctor",
    "drift-watch",
    "export",
    "import",
    "live-smoke",
    "mcp",
    "orient",
    "plan",
    "report",
    "run",
    "scan",
    "validate",
)


def _runner() -> CliRunner:
    return CliRunner()


def test_top_level_help_lists_every_expected_subcommand() -> None:
    result = _runner().invoke(main, ["--help"], catch_exceptions=False)
    assert result.exit_code == 0, result.output
    missing = [c for c in EXPECTED_SUBCOMMANDS if c not in result.output]
    assert not missing, (
        "Top-level `dsk --help` is missing subcommands: "
        f"{missing}. Either restore them or update EXPECTED_SUBCOMMANDS."
    )


@pytest.mark.parametrize("subcommand", EXPECTED_SUBCOMMANDS)
def test_subcommand_help_runs_cleanly(subcommand: str) -> None:
    result = _runner().invoke(main, [subcommand, "--help"], catch_exceptions=False)
    assert result.exit_code == 0, (
        f"`dsk {subcommand} --help` exited {result.exit_code}\noutput:\n{result.output}"
    )
    assert "Usage:" in result.output
    assert "--help" in result.output


def test_report_subcommands_help() -> None:
    """The ``report`` group has its own subcommand fan-out; smoke each one."""
    report_subcommands = (
        "password-report",
        "compliance-report",
        "security-audit-report",
        "vault-health",
        "team-report",
        "team-roles",
        "ksm-usage",
        "role-report",
    )
    runner = _runner()
    for sub in report_subcommands:
        result = runner.invoke(main, ["report", sub, "--help"], catch_exceptions=False)
        assert result.exit_code == 0, (
            f"`dsk report {sub} --help` exited {result.exit_code}\noutput:\n{result.output}"
        )
        assert "Usage:" in result.output


def test_mcp_serve_help_runs_cleanly() -> None:
    result = _runner().invoke(main, ["mcp", "serve", "--help"], catch_exceptions=False)
    assert result.exit_code == 0, result.output
    assert "Usage:" in result.output


def test_dsk_version_flag() -> None:
    result = _runner().invoke(main, ["--version"], catch_exceptions=False)
    assert result.exit_code == 0, result.output
    assert result.output.strip() != ""
