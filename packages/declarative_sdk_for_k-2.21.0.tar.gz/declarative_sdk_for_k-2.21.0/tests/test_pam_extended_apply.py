"""Commander apply coverage for ``keeper-pam-extended.v1`` schedules/rules."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.planner import Plan
from dsk.providers import commander_cli as commander_cli_mod
from dsk.providers.commander_cli import CommanderCliProvider


def _provider(monkeypatch: pytest.MonkeyPatch) -> CommanderCliProvider:
    monkeypatch.setattr(commander_cli_mod.shutil, "which", lambda _bin: "/usr/bin/keeper")
    provider = CommanderCliProvider(
        folder_uid="folder-uid",
        manifest_source={"schema": "keeper-pam-extended.v1"},
    )
    provider._keeper_params = object()
    monkeypatch.setattr(
        commander_cli_mod,
        "_ensure_keepercommander_version_for_apply",
        lambda: None,
    )
    return provider


def _install_fake_pam_extended(
    monkeypatch: pytest.MonkeyPatch,
    calls: list[tuple[str, object, dict[str, Any]]],
) -> None:
    root = types.ModuleType("keepercommander")
    commands = types.ModuleType("keepercommander.commands")
    package = types.ModuleType("keepercommander.commands.pam_extended")
    schedules = types.ModuleType("keepercommander.commands.pam_extended.schedule_commands")
    rules = types.ModuleType("keepercommander.commands.pam_extended.discovery_rule_commands")

    class _ScheduleCreate:
        def execute(self, params: object, **kwargs: Any) -> None:
            calls.append(("schedule_create", params, kwargs))

    class _ScheduleDelete:
        def execute(self, params: object, **kwargs: Any) -> None:
            calls.append(("schedule_delete", params, kwargs))

    class _RuleCreate:
        def execute(self, params: object, **kwargs: Any) -> None:
            calls.append(("rule_create", params, kwargs))

    class _RuleDelete:
        def execute(self, params: object, **kwargs: Any) -> None:
            calls.append(("rule_delete", params, kwargs))

    schedules.PAMExtendedScheduleCreateCommand = _ScheduleCreate  # type: ignore[attr-defined]
    schedules.PAMExtendedScheduleDeleteCommand = _ScheduleDelete  # type: ignore[attr-defined]
    rules.PAMExtendedRuleCreateCommand = _RuleCreate  # type: ignore[attr-defined]
    rules.PAMExtendedRuleDeleteCommand = _RuleDelete  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "keepercommander", root)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", commands)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.pam_extended", package)
    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.pam_extended.schedule_commands",
        schedules,
    )
    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.pam_extended.discovery_rule_commands",
        rules,
    )


def test_schedule_create_calls_commander(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, object, dict[str, Any]]] = []
    _install_fake_pam_extended(monkeypatch, calls)
    provider = _provider(monkeypatch)
    params = provider._keeper_params
    plan = Plan(
        manifest_name="keeper-pam-extended",
        order=["rot.db"],
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="rot.db",
                resource_type="pam_extended_rotation_schedule",
                title="DB nightly",
                after={
                    "name": "DB nightly",
                    "cron_expr": "0 2 * * *",
                    "config_uid": "CFG_UID",
                },
            )
        ],
    )

    outcomes = provider.apply_pam_extended_plan(plan)

    assert calls == [
        (
            "schedule_create",
            params,
            {"name": "DB nightly", "cron": "0 2 * * *", "config_uid": "CFG_UID"},
        )
    ]
    assert outcomes[0].action == "create"
    assert outcomes[0].details["commander_argv"] == [
        "pam",
        "extended",
        "schedule",
        "create",
        "DB nightly",
        "--cron",
        "0 2 * * *",
        "--config-uid",
        "CFG_UID",
    ]


def test_rule_create_calls_commander(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, object, dict[str, Any]]] = []
    _install_fake_pam_extended(monkeypatch, calls)
    provider = _provider(monkeypatch)
    params = provider._keeper_params
    plan = Plan(
        manifest_name="keeper-pam-extended",
        order=["disc.ssh"],
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="disc.ssh",
                resource_type="pam_extended_discovery_rule",
                title="SSH hosts",
                after={
                    "name": "SSH hosts",
                    "type": "machine",
                    "pattern": "web-*",
                    "config_uid": "CFG_UID",
                },
            )
        ],
    )

    outcomes = provider.apply_pam_extended_plan(plan)

    assert calls == [
        (
            "rule_create",
            params,
            {
                "name": "SSH hosts",
                "rule_type": "machine",
                "pattern": "web-*",
                "config_uid": "CFG_UID",
            },
        )
    ]
    assert outcomes[0].action == "create"
    assert outcomes[0].details["commander_argv"] == [
        "pam",
        "extended",
        "rule",
        "create",
        "SSH hosts",
        "--type",
        "machine",
        "--pattern",
        "web-*",
        "--config-uid",
        "CFG_UID",
    ]


def test_schedule_delete_calls_commander(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, object, dict[str, Any]]] = []
    _install_fake_pam_extended(monkeypatch, calls)
    provider = _provider(monkeypatch)
    plan = Plan(
        manifest_name="keeper-pam-extended",
        order=["rot.db"],
        changes=[
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="rot.db",
                resource_type="pam_extended_rotation_schedule",
                title="DB nightly",
                before={"name": "DB nightly", "cron_expr": "0 2 * * *", "config_uid": "CFG"},
            )
        ],
    )

    outcomes = provider.apply_pam_extended_plan(plan)

    assert any(c[0] == "schedule_delete" for c in calls)
    assert outcomes[0].action == "delete"


def test_pam_extended_dry_run_skips(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider(monkeypatch)

    def fail_login() -> object:
        raise AssertionError("dry-run must not open a Commander session")

    provider._keeper_params = None
    monkeypatch.setattr(provider, "_get_keeper_params", fail_login)
    plan = Plan(
        manifest_name="keeper-pam-extended",
        order=["rot.db"],
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="rot.db",
                resource_type="pam_extended_rotation_schedule",
                title="DB nightly",
                after={
                    "name": "DB nightly",
                    "cron_expr": "0 2 * * *",
                    "config_uid": "CFG_UID",
                },
            )
        ],
    )

    outcomes = provider.apply_pam_extended_plan(plan, dry_run=True)

    assert len(outcomes) == 1
    assert outcomes[0].details["dry_run"] is True
    assert outcomes[0].details["commander_argv"][:5] == [
        "pam",
        "extended",
        "schedule",
        "create",
        "DB nightly",
    ]


def test_rule_delete_calls_commander(monkeypatch: pytest.MonkeyPatch) -> None:
    """Discovery-rule deletes map to Commander ``pam extended rule delete``."""
    calls: list[tuple[str, object, dict[str, Any]]] = []
    _install_fake_pam_extended(monkeypatch, calls)
    provider = _provider(monkeypatch)
    params = provider._keeper_params
    plan = Plan(
        manifest_name="keeper-pam-extended",
        order=["disc.ssh"],
        changes=[
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="disc.ssh",
                resource_type="pam_extended_discovery_rule",
                title="SSH hosts",
                before={"name": "SSH hosts", "credential_uid_ref": "CRED"},
            )
        ],
    )

    outcomes = provider.apply_pam_extended_plan(plan)

    assert calls == [("rule_delete", params, {"name_or_uid": "SSH hosts"})]
    assert outcomes[0].action == "delete"
    assert outcomes[0].details["commander_argv"] == [
        "pam",
        "extended",
        "rule",
        "delete",
        "SSH hosts",
    ]


def test_pam_extended_apply_rejects_unknown_resource_type(monkeypatch: pytest.MonkeyPatch) -> None:
    """Commander pam-extended hooks only handle schedules and discovery rules."""
    provider = _provider(monkeypatch)
    plan = Plan(
        manifest_name="keeper-pam-extended",
        order=["pam.ext.gateway"],
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="pam.ext.gateway",
                resource_type="pam_extended_gateway_config",
                title="edge-gateway",
                after={
                    "gateway_uid_ref": "gw.edge",
                    "network_segment": "dmz",
                    "health_check_interval_s": 30,
                },
            )
        ],
    )

    with pytest.raises(CapabilityError):
        provider.apply_pam_extended_plan(plan)
