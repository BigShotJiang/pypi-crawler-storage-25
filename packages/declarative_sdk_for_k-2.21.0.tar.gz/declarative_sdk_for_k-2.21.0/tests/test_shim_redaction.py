"""Regression tests for ShimCommandResult.args secret redaction (NEW-H1)."""

from __future__ import annotations

import pytest

from dsk.shim._types import _REDACTION_PLACEHOLDER, ShimCommandResult, _redact_sensitive_args


@pytest.mark.parametrize(
    ("input_args", "expected_redacted_value"),
    [
        (("--github-token", "ghp_secret123"), True),
        (("--slack-webhook", "https://hooks.slack.com/services/T0/B0/secret"), True),
        (("--servicenow-api-key", "sn_key_abc"), True),
        (("--password", "hunter2"), True),
        (("--api-key", "k_xyz"), True),
        (("--token", "any_token"), True),
        (("--manifest", "/tmp/m.yml"), False),
        (("--output", "/tmp/out.yml"), False),
    ],
)
def test_redact_separated_form(input_args: tuple[str, str], expected_redacted_value: bool) -> None:
    redacted = _redact_sensitive_args(input_args)
    if expected_redacted_value:
        assert _REDACTION_PLACEHOLDER in redacted
        assert input_args[1] not in redacted
    else:
        assert input_args == redacted


@pytest.mark.parametrize(
    ("input_arg", "should_redact"),
    [
        ("--github-token=ghp_secret", True),
        ("--password=hunter2", True),
        ("--manifest=/tmp/m.yml", False),
    ],
)
def test_redact_equals_form(input_arg: str, should_redact: bool) -> None:
    redacted = _redact_sensitive_args((input_arg,))
    if should_redact:
        assert _REDACTION_PLACEHOLDER in redacted[0]
        assert "secret" not in redacted[0]
        assert "hunter2" not in redacted[0]
    else:
        assert redacted == (input_arg,)


def test_shim_command_result_redacts_args_on_construction() -> None:
    result = ShimCommandResult(
        args=("drift-watch", "--github-token", "ghp_real_secret", "--manifest", "/tmp/m.yml"),
        exit_code=0,
        stdout="",
        stderr="",
    )

    assert "ghp_real_secret" not in result.args
    assert _REDACTION_PLACEHOLDER in result.args
    assert "--manifest" in result.args
    assert "/tmp/m.yml" in result.args


def test_drift_watch_args_are_redacted_end_to_end() -> None:
    from dsk.shim import drift_watch

    result = drift_watch(
        ("/tmp/m.yml",),
        github_token="ghp_real_secret",
        slack_webhook="https://hooks.slack.com/services/T0/B0/secret",
        servicenow_api_key="sn_key_abc",
    )

    assert result.exit_code == 1
    assert "ghp_real_secret" not in result.args
    assert "https://hooks.slack.com/services/T0/B0/secret" not in result.args
    assert "sn_key_abc" not in result.args
    assert result.args.count(_REDACTION_PLACEHOLDER) == 3


class TestRedactionPlaceholderInvariants:
    """Mutation regression for keeping the redaction marker diagnostic."""

    def test_placeholder_is_non_empty_string(self) -> None:
        assert isinstance(_REDACTION_PLACEHOLDER, str)
        assert len(_REDACTION_PLACEHOLDER) > 0
        assert _REDACTION_PLACEHOLDER.strip(), "placeholder must contain non-whitespace characters"

    def test_placeholder_appears_verbatim_in_redacted_separated_form(self) -> None:
        redacted = _redact_sensitive_args(("--github-token", "ghp_secret_xyz"))

        assert _REDACTION_PLACEHOLDER in redacted, (
            f"expected placeholder {_REDACTION_PLACEHOLDER!r} in redacted args {redacted!r}"
        )
        assert "ghp_secret_xyz" not in redacted

    def test_placeholder_appears_verbatim_in_redacted_equals_form(self) -> None:
        redacted = _redact_sensitive_args(("--password=hunter2",))

        assert any(_REDACTION_PLACEHOLDER in arg for arg in redacted), (
            f"expected placeholder in equals-form redacted args {redacted!r}"
        )
        assert all("hunter2" not in arg for arg in redacted)
