"""Additional coverage for epm-policy.v1 — multi-policy manifests, rule fields, diff."""

from __future__ import annotations

from typing import Any

from dsk.core.models_epm import (
    DefaultPolicyCategory,
    EpmApplicationRule,
    EpmRuleEffect,
    EpmTargetPlatform,
    load_epm_policy_manifest,
)


def _manifest_doc(**extra: Any) -> dict[str, Any]:
    base: dict[str, Any] = {"schema": "epm-policy.v1", "name": "acme-epm", "version": "1"}
    base.update(extra)
    return base


# --- EpmApplicationRule fields ---


def test_application_rule_all_fields() -> None:
    rule = EpmApplicationRule(
        name="allow-chrome",
        description="Allow Google Chrome",
        effect=EpmRuleEffect.allow,
        platform=EpmTargetPlatform.windows,
        match_path=r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        match_hash="abc123" * 8 + "ab",
        match_publisher="Google LLC",
        require_justification=True,
        notify=False,
    )
    assert rule.match_publisher == "Google LLC"
    assert rule.require_justification is True
    assert rule.notify is False
    assert rule.effect == EpmRuleEffect.allow


def test_application_rule_defaults() -> None:
    rule = EpmApplicationRule(name="audit-all", effect=EpmRuleEffect.audit)
    assert rule.platform == EpmTargetPlatform.all_
    assert rule.require_justification is False
    assert rule.notify is True
    assert rule.match_hash is None
    assert rule.match_path is None


def test_all_rule_effects() -> None:
    for effect in EpmRuleEffect:
        rule = EpmApplicationRule(name=f"rule-{effect}", effect=effect)
        assert rule.effect == effect


def test_all_target_platforms() -> None:
    for plat in EpmTargetPlatform:
        rule = EpmApplicationRule(name=f"rule-{plat}", effect=EpmRuleEffect.audit, platform=plat)
        assert rule.platform == plat


# --- EpmPolicy applies_to_groups ---


def test_policy_applies_to_groups() -> None:
    doc = _manifest_doc(
        policies=[
            {
                "uid_ref": "p1",
                "name": "DevElevation",
                "applies_to_groups": ["developers", "contractors"],
                "rules": [],
            }
        ]
    )
    manifest = load_epm_policy_manifest(doc)
    p = manifest.policies[0]
    assert p.applies_to_groups == ["developers", "contractors"]


# --- multi-policy manifest ---


def test_multi_policy_manifest_round_trip() -> None:
    doc = _manifest_doc(
        policies=[
            {
                "uid_ref": "p1",
                "name": "AllowChrome",
                "default_policy_category": "allow_listed_applications",
                "rules": [
                    {
                        "name": "chrome-rule",
                        "effect": "allow",
                        "platform": "windows",
                        "match_publisher": "Google LLC",
                    }
                ],
            },
            {
                "uid_ref": "p2",
                "name": "BlockShady",
                "default_policy_category": "deny_listed_applications",
                "rules": [
                    {
                        "name": "block-unsigned",
                        "effect": "deny",
                        "platform": "all",
                    }
                ],
            },
        ],
        default_policies=["block_unsigned_executables", "audit_all_executions"],
    )
    manifest = load_epm_policy_manifest(doc)
    assert len(manifest.policies) == 2
    p1 = manifest.policies[0]
    assert p1.default_policy_category == DefaultPolicyCategory.allow_listed_applications
    assert len(p1.rules) == 1
    assert p1.rules[0].match_publisher == "Google LLC"
    assert manifest.default_policies == [
        DefaultPolicyCategory.block_unsigned_executables,
        DefaultPolicyCategory.audit_all_executions,
    ]


# --- diff with rules changes ---


def test_epm_policy_diff_detects_rule_content_change() -> None:
    """Adding a rule to a policy should surface as UPDATE via compute_epm_policy_diff."""
    from dsk.core.epm_diff import compute_epm_policy_diff

    base_doc = _manifest_doc(policies=[{"name": "MyPolicy", "rules": []}])
    base = load_epm_policy_manifest(base_doc)
    live_snapshot = {p.name: p.model_dump(exclude_unset=True) for p in base.policies}

    new_doc = _manifest_doc(
        policies=[{"name": "MyPolicy", "rules": [{"name": "new-rule", "effect": "allow"}]}]
    )
    new_m = load_epm_policy_manifest(new_doc)
    changes = compute_epm_policy_diff(new_m, live_snapshot, manifest_name="test")
    assert any(c.uid_ref == "MyPolicy" and c.kind.value == "update" for c in changes), (
        f"expected update change for MyPolicy, got: {[(c.uid_ref, c.kind) for c in changes]}"
    )


def test_epm_policy_diff_detects_applies_to_groups_change() -> None:
    """Changing applies_to_groups should surface as UPDATE via compute_epm_policy_diff."""
    from dsk.core.epm_diff import compute_epm_policy_diff

    base_doc = _manifest_doc(
        policies=[{"name": "Policy", "applies_to_groups": ["devs"], "rules": []}]
    )
    before = load_epm_policy_manifest(base_doc)
    live_snapshot = {p.name: p.model_dump(exclude_unset=True) for p in before.policies}

    after_doc = _manifest_doc(
        policies=[{"name": "Policy", "applies_to_groups": ["devs", "admins"], "rules": []}]
    )
    after = load_epm_policy_manifest(after_doc)
    changes = compute_epm_policy_diff(after, live_snapshot, manifest_name="test")
    assert any(c.uid_ref == "Policy" and c.kind.value == "update" for c in changes)


# --- all 8 DefaultPolicyCategory values ---


def test_all_default_policy_categories_parse() -> None:
    all_cats = [cat.value for cat in DefaultPolicyCategory]
    doc = _manifest_doc(default_policies=all_cats)
    manifest = load_epm_policy_manifest(doc)
    assert len(manifest.default_policies) == 8
    assert set(manifest.default_policies) == set(DefaultPolicyCategory)


def test_default_policy_category_in_policy_object() -> None:
    doc = _manifest_doc(
        policies=[
            {
                "uid_ref": "p1",
                "name": "JIT",
                "default_policy_category": "just_in_time_elevation",
                "rules": [],
            }
        ]
    )
    manifest = load_epm_policy_manifest(doc)
    assert (
        manifest.policies[0].default_policy_category == DefaultPolicyCategory.just_in_time_elevation
    )


def test_credential_injection_rules_category() -> None:
    doc = _manifest_doc(
        policies=[
            {
                "uid_ref": "p1",
                "name": "CredsInjection",
                "default_policy_category": "credential_injection_rules",
                "rules": [],
            }
        ]
    )
    manifest = load_epm_policy_manifest(doc)
    assert (
        manifest.policies[0].default_policy_category
        == DefaultPolicyCategory.credential_injection_rules
    )
