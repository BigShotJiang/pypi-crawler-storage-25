"""Tests for jit-access.v1 manifests."""

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from dsk.cli.main import main

EXAMPLE = Path(__file__).parent.parent / "examples/jit/acme-jit-policy.yaml"


def test_jit_manifest_alias_schema_field():
    from dsk.core.models_jit import JitManifestV1

    manifest = JitManifestV1(**{"schema": "jit-access.v1", "name": "t"})
    assert manifest.schema_ == "jit-access.v1"


def test_jit_validate_json_example():
    result = CliRunner().invoke(main, ["validate", str(EXAMPLE), "--json"], catch_exceptions=False)

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["family"] == "jit-access.v1"
    assert payload["mode"] == "jit_access_offline"
    assert payload["target_count"] == 2


def test_jit_plan_json_mock_provider():
    result = CliRunner().invoke(main, ["plan", str(EXAMPLE), "--json"], catch_exceptions=False)

    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["manifest_name"] == "acme-lab-jit"
    assert set(payload["order"]) == {"res.db-prod", "res.ci-secrets"}
    assert payload["summary"]["create"] == 2
    first = next(c for c in payload["changes"] if c["uid_ref"] == "res.db-prod")
    assert first["kind"] == "create"
    assert first["resource_type"] == "jit_access"
    assert first["after"]["policy_name"] == "db-prod-emergency"


def test_jit_apply_mock_auto_approve():
    result = CliRunner().invoke(
        main,
        ["apply", str(EXAMPLE), "--provider", "mock", "--yes"],
        catch_exceptions=False,
    )
    assert result.exit_code == 0
    assert "create" in result.output.lower()


def test_jit_apply_commander_exits_capability(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: "/usr/bin/keeper")
    result = CliRunner().invoke(
        main,
        ["apply", str(EXAMPLE), "--provider", "commander", "--yes"],
        catch_exceptions=False,
    )
    assert result.exit_code == 5
