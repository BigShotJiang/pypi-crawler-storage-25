"""Tests for AI agent trust chain models."""

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError


def test_delegation_rule_defaults():
    from dsk.core.models_trust_chain import (
        AgentDelegationRule,
        AttestationRequirement,
        DelegationMode,
    )

    rule = AgentDelegationRule(
        name="test",
        orchestrator_uid_ref="nhi.orchestrator",
    )
    assert rule.mode == DelegationMode.attenuation
    assert rule.attestation == AttestationRequirement.signed_jwt
    assert rule.revoke_on_orchestrator_exit is True
    assert rule.scope.allow_re_delegation is False


def test_trust_chain_manifest_round_trip():
    from dsk.core.models_trust_chain import (
        AttestationRequirement,
        DelegationMode,
        TrustChainManifestV1,
    )

    example = Path(__file__).parent.parent / "examples/trust-chain/acme-trust-chain.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = TrustChainManifestV1(**data)
    assert manifest.schema_ == "ai-agent-trust-chain.v1"
    assert len(manifest.rules) == 2
    rule1 = manifest.rules[0]
    assert rule1.mode == DelegationMode.attenuation
    assert rule1.scope.max_ttl_seconds == 900
    assert "read" in rule1.scope.scopes
    rule2 = manifest.rules[1]
    assert rule2.attestation == AttestationRequirement.spiffe


def test_delegation_scope_re_delegation_default():
    from dsk.core.models_trust_chain import DelegationScope

    scope = DelegationScope()
    assert scope.allow_re_delegation is False
    assert scope.max_ttl_seconds == 900


def test_schema_alias():
    from dsk.core.models_trust_chain import TrustChainManifestV1

    m = TrustChainManifestV1(**{"schema": "ai-agent-trust-chain.v1", "name": "test"})
    assert m.schema_ == "ai-agent-trust-chain.v1"


def test_delegation_scope_rejects_ttl_outside_bounds() -> None:
    """Sub-agent credential TTL must stay between 60s and 1h per model."""
    from dsk.core.models_trust_chain import DelegationScope

    with pytest.raises(ValidationError):
        DelegationScope(max_ttl_seconds=30)


def test_agent_delegation_rule_audit_log_defaults_on() -> None:
    from dsk.core.models_trust_chain import AgentDelegationRule

    rule = AgentDelegationRule(name="r", orchestrator_uid_ref="orch.1")
    assert rule.audit_log is True


def test_trust_chain_manifest_default_empty_rules() -> None:
    from dsk.core.models_trust_chain import TrustChainManifestV1

    manifest = TrustChainManifestV1(**{"schema": "ai-agent-trust-chain.v1", "name": "solo"})
    assert manifest.rules == []
