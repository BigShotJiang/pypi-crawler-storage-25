"""MockProvider round-trip: apply creates records, second plan is clean."""

from __future__ import annotations

from pathlib import Path

from dsk.core import (
    build_graph,
    build_plan,
    compute_diff,
    execution_order,
    load_manifest,
)
from dsk.core.diff import ChangeKind
from dsk.providers import MockProvider


def test_apply_then_replan_is_mostly_noop(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)

    graph = build_graph(manifest)
    order = execution_order(graph)

    # first apply -> all creates
    changes = compute_diff(manifest, provider.discover())
    plan = build_plan(manifest.name, changes, order)
    outcomes = provider.apply_plan(plan)
    assert all(o.action in ("create", "noop") for o in outcomes)
    assert len([o for o in outcomes if o.action == "create"]) >= 1

    # replan -> no creates (records now carry our markers)
    changes2 = compute_diff(manifest, provider.discover())
    creates = [c for c in changes2 if c.kind is ChangeKind.CREATE]
    assert creates == []


def test_initial_apply_produces_create_outcomes(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)

    graph = build_graph(manifest)
    order = execution_order(graph)

    changes = compute_diff(manifest, provider.discover())
    plan = build_plan(manifest.name, changes, order)
    outcomes = provider.apply_plan(plan)
    assert len([o for o in outcomes if o.action == "create"]) >= 1


def test_plan_without_apply_does_not_mutate_state(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)

    graph = build_graph(manifest)
    order = execution_order(graph)

    plan1 = build_plan(manifest.name, compute_diff(manifest, provider.discover()), order)
    plan2 = build_plan(manifest.name, compute_diff(manifest, provider.discover()), order)

    assert len(plan1.creates) >= 1
    assert len(plan2.creates) >= 1


def test_update_after_seeded_live_record(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    marker_uid_ref = manifest.resources[0].uid_ref
    provider = MockProvider(manifest.name)

    provider.seed_payload(
        title="web-server-01",
        resource_type="pamMachine",
        payload={"title": "web-server-01"},
        marker_uid_ref=marker_uid_ref,
        manifest_name=manifest.name,
    )

    changes = compute_diff(manifest, provider.discover())
    for change in changes:
        if change.uid_ref == marker_uid_ref:
            assert change.kind in (ChangeKind.NOOP, ChangeKind.UPDATE)


def test_delete_with_allow_delete(minimal_manifest_path: Path) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    graph = build_graph(manifest)
    order = execution_order(graph)

    plan = build_plan(
        manifest.name,
        compute_diff(manifest, provider.discover()),
        order,
    )
    provider.apply_plan(plan)

    # seed an orphan owned by the same manifest
    provider.seed_payload(
        title="retired-host",
        resource_type="pamMachine",
        payload={"title": "retired-host"},
        marker_uid_ref="retired",
        manifest_name=manifest.name,
    )

    changes = compute_diff(manifest, provider.discover(), allow_delete=True)
    deletes = [c for c in changes if c.kind is ChangeKind.DELETE]
    assert any(c.title == "retired-host" for c in deletes)

    plan2 = build_plan(manifest.name, changes, order)
    outcomes = provider.apply_plan(plan2)
    assert any(o.action == "delete" for o in outcomes)
