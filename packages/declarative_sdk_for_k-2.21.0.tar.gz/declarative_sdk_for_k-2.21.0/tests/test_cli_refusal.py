"""CLI tests for `dsk refusal` and `dsk panic-revoke`."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from dsk.cli.main import main

# ---------------------------------------------------------------------------
# Minimal manifest helpers


_SHARED_PAM_USER_UID = "pam-user-shared-uid"

VIOLATING_MANIFEST = {
    "kind": "pam-environment.v1",
    "name": "test-env",
    "resources": [
        {
            "uid_ref": "res-a",
            "title": "Resource A",
            "users": [{"uid_ref": _SHARED_PAM_USER_UID}],
        },
        {
            "uid_ref": "res-b",
            "title": "Resource B",
            "users": [{"uid_ref": _SHARED_PAM_USER_UID}],
        },
    ],
}

CLEAN_MANIFEST = {
    "kind": "pam-environment.v1",
    "name": "clean-env",
    "resources": [
        {
            "uid_ref": "res-clean",
            "title": "Clean Resource",
            "users": [
                {
                    "uid_ref": "unique-user-uid",
                    "rotation_settings": {"enabled": "on"},
                }
            ],
        },
    ],
}


def _write_yaml(tmp_path: Path, name: str, data: dict) -> Path:
    p = tmp_path / name
    p.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# refusal check tests


def test_refusal_check_violating_exits_2(tmp_path: Path) -> None:
    """Shared pamUser → at least one ERROR violation → exit code 2."""
    manifest = _write_yaml(tmp_path, "violating.yaml", VIOLATING_MANIFEST)
    runner = CliRunner()
    result = runner.invoke(main, ["refusal", str(manifest)])
    assert result.exit_code == 2, result.output
    assert "error" in result.output.lower()


def test_refusal_check_clean_exits_0(tmp_path: Path) -> None:
    """Clean manifest → no violations → exit 0 and success message."""
    manifest = _write_yaml(tmp_path, "clean.yaml", CLEAN_MANIFEST)
    runner = CliRunner()
    result = runner.invoke(main, ["refusal", str(manifest)])
    assert result.exit_code == 0, result.output
    assert "No refusal violations" in result.output


def test_refusal_check_json_flag(tmp_path: Path) -> None:
    """--json flag → stdout is valid JSON array regardless of violations."""
    manifest = _write_yaml(tmp_path, "violating.yaml", VIOLATING_MANIFEST)
    runner = CliRunner()
    result = runner.invoke(main, ["refusal", "--json", str(manifest)])
    parsed = json.loads(result.output)
    assert isinstance(parsed, list)
    # each item should have expected keys
    for item in parsed:
        assert "severity" in item
        assert "uid_ref" in item
        assert "predicate" in item
        assert "reason" in item


def test_refusal_check_exit_zero_flag(tmp_path: Path) -> None:
    """--exit-zero on violating manifest → exit 0 always."""
    manifest = _write_yaml(tmp_path, "violating.yaml", VIOLATING_MANIFEST)
    runner = CliRunner()
    result = runner.invoke(main, ["refusal", "--exit-zero", str(manifest)])
    assert result.exit_code == 0, result.output


def test_refusal_check_rejects_oversized_manifest(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = _write_yaml(tmp_path, "clean.yaml", CLEAN_MANIFEST)
    size = manifest.stat().st_size
    monkeypatch.setenv("DSK_CLI_MAX_REFUSAL_MANIFEST_BYTES", str(size - 1))

    result = CliRunner().invoke(main, ["refusal", str(manifest)], catch_exceptions=False)

    assert result.exit_code == 1
    assert "DSK_CLI_MAX_REFUSAL_MANIFEST_BYTES" in result.output


# ---------------------------------------------------------------------------
# panic-revoke tests


def test_panic_revoke_dry_run_no_write(tmp_path: Path) -> None:
    """--dry-run prints annotation to stdout and does NOT modify the file."""
    manifest = _write_yaml(tmp_path, "m.yaml", CLEAN_MANIFEST)
    original_text = manifest.read_text()

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "panic-revoke",
            "res-clean",
            "--manifest",
            str(manifest),
            "--reason",
            "breach",
            "--dry-run",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "PANIC-REVOKE" in result.output
    assert "breach" in result.output
    # File must be unchanged
    assert manifest.read_text() == original_text


def test_panic_revoke_writes_annotation(tmp_path: Path) -> None:
    """Without --dry-run, annotation is written above the uid_ref line."""
    manifest = _write_yaml(tmp_path, "m.yaml", CLEAN_MANIFEST)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "panic-revoke",
            "res-clean",
            "--manifest",
            str(manifest),
            "--reason",
            "breach",
        ],
    )
    assert result.exit_code == 0, result.output

    updated = manifest.read_text()
    assert "# PANIC-REVOKE: res-clean" in updated
    assert "# Reason: breach" in updated
    assert "# Action required:" in updated
    # Original content still present
    assert "res-clean" in updated


def test_panic_revoke_rejects_oversized_manifest(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = _write_yaml(tmp_path, "m.yaml", CLEAN_MANIFEST)
    size = manifest.stat().st_size
    monkeypatch.setenv("DSK_CLI_MAX_PANIC_MANIFEST_BYTES", str(size - 1))

    result = CliRunner().invoke(
        main,
        [
            "panic-revoke",
            "res-clean",
            "--manifest",
            str(manifest),
            "--reason",
            "breach",
        ],
        catch_exceptions=False,
    )

    assert result.exit_code == 1
    assert "DSK_CLI_MAX_PANIC_MANIFEST_BYTES" in result.output
