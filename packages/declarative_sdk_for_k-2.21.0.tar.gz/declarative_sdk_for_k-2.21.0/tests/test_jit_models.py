"""Tests for jit-access.v1 Pydantic models."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from dsk.core.errors import SchemaError
from dsk.core.models_jit import (
    JitAccessWindow,
    JitApprovalMode,
    JitManifestV1,
    JitPolicy,
    JitResource,
    load_jit_manifest,
)

REPO_ROOT = Path(__file__).resolve().parents[1]


def test_jit_policy_defaults() -> None:
    policy = JitPolicy(name="p", resources=[JitResource(uid_ref="res.a")])
    assert policy.window.duration_minutes == 60
    assert policy.approval.mode == JitApprovalMode.auto
    assert policy.auto_revoke is True


def test_jit_manifest_round_trip() -> None:
    yaml_path = REPO_ROOT / "examples" / "jit" / "acme-jit-policy.yaml"
    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
    manifest = JitManifestV1(**data)
    assert manifest.policies[0].approval.mode == JitApprovalMode.dual


def test_jit_window_bounds() -> None:
    with pytest.raises(ValidationError):
        JitAccessWindow(duration_minutes=0)


def test_jit_manifest_v1_schema_field() -> None:
    manifest = JitManifestV1(schema="jit-access.v1", name="n")
    assert manifest.schema_ == "jit-access.v1"


def test_load_jit_manifest_missing_name_raises_schema_error() -> None:
    """``load_jit_manifest`` wraps Pydantic failures as :class:`SchemaError`."""
    with pytest.raises(SchemaError) as exc_info:
        load_jit_manifest({"schema": "jit-access.v1"})
    assert "typed validation failed" in str(exc_info.value).lower()


def test_jit_access_window_duration_upper_bound_raises() -> None:
    """``duration_minutes`` must not exceed 24 hours."""
    with pytest.raises(ValidationError):
        JitAccessWindow(duration_minutes=1441)


def test_jit_resource_defaults_role_and_justification() -> None:
    """``JitResource`` defaults match manifest defaults."""
    resource = JitResource(uid_ref="res.a")
    assert resource.role == "read"
    assert resource.justification_required is True
