"""Sanity checks for in-repo phase-harness shell helpers."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
BUNDLE_SCRIPT = REPO / "scripts" / "phase_harness" / "bundle_unpushed_commits.sh"
GATES_SCRIPT = REPO / "scripts" / "phase_harness" / "run_local_gates.sh"


@pytest.mark.parametrize("path", [BUNDLE_SCRIPT, GATES_SCRIPT])
def test_phase_harness_script_bash_syntax(path: Path) -> None:
    assert path.is_file(), path
    proc = subprocess.run(
        ["bash", "-n", str(path)],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, f"bash -n {path}:\n{proc.stderr or proc.stdout}"


def test_bundle_unpushed_commits_script_runs_helpfully_when_nothing_to_pack(tmp_path: Path) -> None:
    """When main is ahead of origin, the script must create a valid bundle (smoke)."""
    out = tmp_path / "b.bundle"
    proc = subprocess.run(
        ["bash", str(BUNDLE_SCRIPT), str(out)],
        cwd=REPO,
        capture_output=True,
        text=True,
        check=False,
    )
    out_combined = proc.stdout + proc.stderr
    if "Nothing to bundle" in out_combined:
        pytest.skip("main is not ahead of origin in this clone")
    assert proc.returncode == 0, proc.stderr
    assert "git pull" in out_combined and "git push" in out_combined, out_combined
    assert out.is_file()
    v = subprocess.run(
        ["git", "bundle", "verify", str(out)],
        cwd=REPO,
        capture_output=True,
        text=True,
        check=False,
    )
    assert v.returncode == 0, v.stderr


def test_phase_harness_scripts_exist() -> None:
    """Both harness scripts must exist on disk."""
    assert BUNDLE_SCRIPT.is_file(), f"missing: {BUNDLE_SCRIPT}"
    assert GATES_SCRIPT.is_file(), f"missing: {GATES_SCRIPT}"


def test_run_local_gates_is_executable_shell() -> None:
    """run_local_gates.sh must be syntactically valid bash."""
    proc = subprocess.run(
        ["bash", "-n", str(GATES_SCRIPT)],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr


def test_scripts_dir_contains_only_expected_harness_files() -> None:
    """phase_harness dir must contain at least bundle and gates scripts."""
    harness_dir = BUNDLE_SCRIPT.parent
    scripts = {p.name for p in harness_dir.iterdir() if p.suffix == ".sh"}
    assert BUNDLE_SCRIPT.name in scripts
    assert GATES_SCRIPT.name in scripts
