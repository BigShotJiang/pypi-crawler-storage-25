"""Tests for DSK ESO bridge (offline — no Keeper connection)."""

from __future__ import annotations

import json
import sys
from io import BytesIO
from unittest.mock import MagicMock, patch

import pytest

import dsk.integrations.eso_bridge as eso_bridge


class _TestableEsoBridgeHandler(eso_bridge._EsoBridgeHandler):
    """Minimal handler shell for exercising do_GET/_respond without a socket."""

    def __init__(self, path: str) -> None:
        self.path = path
        self.rfile = BytesIO()
        self.wfile = BytesIO()
        self._status_code: int | None = None

    def send_response(self, code: int, message: str | None = None) -> None:  # noqa: ARG002
        self._status_code = code

    def send_header(self, keyword: str, value: str) -> None:
        pass

    def end_headers(self) -> None:
        pass

    def json_body(self) -> dict[str, str]:
        return json.loads(self.wfile.getvalue().decode())


def test_resolve_uid_ref_returns_none_on_failure(monkeypatch) -> None:
    from dsk.integrations.eso_bridge import _resolve_uid_ref

    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=1, stderr="not found", stdout="")
        result = _resolve_uid_ref("res.unknown")
    assert result is None


def test_resolve_uid_ref_parses_fields(monkeypatch) -> None:
    from dsk.integrations.eso_bridge import _resolve_uid_ref

    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    fake_output = json.dumps(
        {
            "fields": [
                {"type": "password", "label": "Password", "value": ["s3cr3t"]},
                {"type": "login", "label": "Login", "value": ["admin"]},
            ]
        }
    )
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout=fake_output, stderr="")
        result = _resolve_uid_ref("res.db")
    assert result is not None
    assert result.get("password") == "s3cr3t"
    assert result.get("login") == "admin"


def test_detect_mode_ksm_when_config_file_set(monkeypatch) -> None:
    from dsk.integrations.eso_bridge import _detect_fetch_mode

    monkeypatch.setenv("KSM_CONFIG_FILE", "/tmp/ksm.json")
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    assert _detect_fetch_mode() == "ksm"


def test_detect_mode_commander_by_default(monkeypatch) -> None:
    from dsk.integrations.eso_bridge import _detect_fetch_mode

    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    assert _detect_fetch_mode() == "commander"


def test_resolve_via_ksm_missing_package_returns_none() -> None:
    from dsk.integrations.eso_bridge import _resolve_via_ksm

    with patch.dict(sys.modules, {"keeper_secrets_manager_core": None}):
        result = _resolve_via_ksm("ABC123")
    assert result is None


@pytest.mark.parametrize(
    ("path", "expected_status", "body_keys"),
    [
        (
            "/secrets/rec1/customfield",
            200,
            {"value"},
        ),
        (
            "/secrets/rec1",
            200,
            {"value"},
        ),
    ],
)
def test_handler_get_returns_json_value_structure(
    monkeypatch: pytest.MonkeyPatch,
    path: str,
    expected_status: int,
    body_keys: set[str],
) -> None:
    """ESO webhook response is JSON with a ``value`` key (REMOTE web hook contract)."""

    monkeypatch.setenv("KSM_CONFIG_FILE", "/tmp/absent-ksm.json")
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)

    def fake_resolve(_uid: str) -> dict[str, str]:
        return {"password": "pw1", "customfield": "extra"}

    with patch.object(eso_bridge, "_resolve_uid_ref", side_effect=fake_resolve):
        h = _TestableEsoBridgeHandler(path)
        h.do_GET()

    assert h._status_code == expected_status
    body = h.json_body()
    assert set(body.keys()) == body_keys
    assert isinstance(body["value"], str)


def test_handler_bad_path_returns_404_json(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    with patch.object(eso_bridge, "_resolve_uid_ref") as resolve:
        h = _TestableEsoBridgeHandler("/v1/other")
        h.do_GET()
    resolve.assert_not_called()
    assert h._status_code == 404
    assert "error" in h.json_body()


def test_handler_uid_not_found_returns_404(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    with patch.object(eso_bridge, "_resolve_uid_ref", return_value=None):
        h = _TestableEsoBridgeHandler("/secrets/missing-record")
        h.do_GET()
    assert h._status_code == 404
    err = h.json_body()["error"]
    assert "not found" in err.lower()


def test_resolve_via_ksm_no_config_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    """KSM stubs importable but no file or credential — client cannot run."""

    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)

    import types

    ksm_pkg = types.ModuleType("keeper_secrets_manager_core")
    ksm_storage = types.ModuleType("keeper_secrets_manager_core.storage")
    ksm_pkg.SecretsManager = MagicMock
    ksm_storage.FileKeyValueStorage = MagicMock

    with patch.dict(
        sys.modules,
        {
            "keeper_secrets_manager_core": ksm_pkg,
            "keeper_secrets_manager_core.storage": ksm_storage,
        },
    ):
        result = eso_bridge._resolve_via_ksm("ANYUID22CHARACTERSSSS")

    assert result is None


def test_resolve_via_commander_malformed_json_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    from dsk.integrations.eso_bridge import _resolve_via_commander

    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    with patch("dsk.integrations.eso_bridge.subprocess.run") as run:
        run.return_value = MagicMock(returncode=0, stdout="not-json", stderr="")
        assert _resolve_via_commander("rid") is None


def test_resolve_via_commander_timeout_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    import subprocess

    from dsk.integrations.eso_bridge import _COMMANDER_TIMEOUT_SECONDS, _resolve_via_commander

    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)

    def timeout_run(*_args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        assert kwargs["timeout"] == _COMMANDER_TIMEOUT_SECONDS
        raise subprocess.TimeoutExpired(cmd=["keeper", "get"], timeout=_COMMANDER_TIMEOUT_SECONDS)

    with patch("dsk.integrations.eso_bridge.subprocess.run", side_effect=timeout_run):
        assert _resolve_via_commander("rid") is None


def test_resolve_via_commander_accepts_at_json_byte_cap(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from dsk.integrations.eso_bridge import _resolve_via_commander

    payload = json.dumps({"fields": [{"type": "password", "value": ["secret"]}]})
    monkeypatch.setenv("DSK_ESO_BRIDGE_MAX_RECORD_JSON_BYTES", str(len(payload)))
    with patch("dsk.integrations.eso_bridge.subprocess.run") as run:
        run.return_value = MagicMock(returncode=0, stdout=payload, stderr="")

        assert _resolve_via_commander("rid") == {"password": "secret"}


def test_resolve_via_commander_rejects_just_over_json_byte_cap(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from dsk.integrations.eso_bridge import _resolve_via_commander

    payload = json.dumps({"fields": [{"type": "password", "value": ["secret"]}]})
    monkeypatch.setenv("DSK_ESO_BRIDGE_MAX_RECORD_JSON_BYTES", str(len(payload) - 1))
    with patch("dsk.integrations.eso_bridge.subprocess.run") as run:
        run.return_value = MagicMock(returncode=0, stdout=payload, stderr="")

        assert _resolve_via_commander("rid") is None


def test_resolve_via_ksm_with_config_file_returns_fields(monkeypatch: pytest.MonkeyPatch) -> None:
    """_resolve_via_ksm returns field dict when KSM fetch returns a record."""
    import json
    import types
    from unittest.mock import MagicMock, patch

    from dsk.integrations import eso_bridge

    monkeypatch.setenv("KSM_CONFIG_FILE", "/fake/ksm.json")
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)

    mock_record = MagicMock()
    mock_record.raw_json = json.dumps(
        {
            "fields": [
                {"type": "login", "value": ["admin"], "label": "login"},
                {"type": "password", "value": ["secret123"], "label": "password"},
            ],
            "custom": [],
        }
    )

    ksm_pkg = types.ModuleType("keeper_secrets_manager_core")
    ksm_storage = types.ModuleType("keeper_secrets_manager_core.storage")
    mock_sm = MagicMock()
    mock_sm.get_secrets.return_value = [mock_record]
    ksm_pkg.SecretsManager = MagicMock(return_value=mock_sm)
    ksm_storage.FileKeyValueStorage = MagicMock()

    with patch.dict(
        pytest.importorskip("sys").modules,
        {
            "keeper_secrets_manager_core": ksm_pkg,
            "keeper_secrets_manager_core.storage": ksm_storage,
        },
    ):
        result = eso_bridge._resolve_via_ksm("uid-xyz")

    assert result is not None
    assert "login" in result or "password" in result


def test_detect_fetch_mode_returns_ksm_when_config_set(monkeypatch: pytest.MonkeyPatch) -> None:
    """_detect_fetch_mode returns 'ksm' when KSM_CONFIG_FILE is set."""
    from dsk.integrations.eso_bridge import _detect_fetch_mode

    monkeypatch.setenv("KSM_CONFIG_FILE", "/fake/ksm.json")
    monkeypatch.delenv("KEEPER_EMAIL", raising=False)
    mode = _detect_fetch_mode()
    assert mode == "ksm"


def test_detect_fetch_mode_returns_commander_when_email_set(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """_detect_fetch_mode returns 'commander' when KEEPER_EMAIL is set."""
    from dsk.integrations.eso_bridge import _detect_fetch_mode

    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    monkeypatch.setenv("KEEPER_EMAIL", "user@example.com")
    mode = _detect_fetch_mode()
    assert mode == "commander"


# ── Sprint BE: eso_bridge additional coverage ─────────────────────────────


def test_resolve_via_ksm_returns_none_without_config(monkeypatch: pytest.MonkeyPatch) -> None:
    """_resolve_via_ksm returns None when neither KSM_CONFIG_FILE nor KEEPER_CREDENTIAL set."""
    from dsk.integrations.eso_bridge import _resolve_via_ksm

    monkeypatch.delenv("KSM_CONFIG_FILE", raising=False)
    monkeypatch.delenv("KEEPER_CREDENTIAL", raising=False)
    result = _resolve_via_ksm("fake.uid")
    assert result is None


def test_resolve_via_ksm_returns_none_on_exception(monkeypatch: pytest.MonkeyPatch) -> None:
    """_resolve_via_ksm returns None when KSM package import raises."""
    import sys
    from unittest.mock import patch

    from dsk.integrations.eso_bridge import _resolve_via_ksm

    monkeypatch.setenv("KSM_CONFIG_FILE", "/fake/ksm.json")
    with patch.dict(
        sys.modules,
        {"keeper_secrets_manager_core": None, "keeper_secrets_manager_core.storage": None},
    ):
        result = _resolve_via_ksm("fake.uid")
    assert result is None


def test_resolve_uid_ref_returns_ksm_when_available(monkeypatch: pytest.MonkeyPatch) -> None:
    """_resolve_uid_ref returns KSM result when KSM mode active and succeeds."""
    from unittest.mock import patch

    from dsk.integrations.eso_bridge import _resolve_uid_ref

    monkeypatch.setenv("KSM_CONFIG_FILE", "/fake/ksm.json")
    monkeypatch.delenv("KEEPER_EMAIL", raising=False)
    with patch("dsk.integrations.eso_bridge._resolve_via_ksm", return_value={"login": "user"}):
        with patch("dsk.integrations.eso_bridge._resolve_via_commander") as mock_cmd:
            result = _resolve_uid_ref("fake.uid")
    assert result == {"login": "user"}
    mock_cmd.assert_not_called()
