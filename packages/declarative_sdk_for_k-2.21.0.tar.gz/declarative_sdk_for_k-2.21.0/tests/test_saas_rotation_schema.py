"""keeper-saas-rotation.v1 schema and typed-model scaffold tests."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
import yaml

from dsk.core.errors import SchemaError
from dsk.core.manifest import load_declarative_manifest_string
from dsk.core.models_saas_rotation import (
    SAAS_ROTATION_FAMILY,
    SaaSRotationManifestV1,
    load_saas_rotation_manifest,
)
from dsk.core.schema import load_schema_for_family, validate_manifest


def _doc() -> dict[str, Any]:
    return yaml.safe_load(
        Path("tests/fixtures/examples/saas-rotation/environment.yaml").read_text(encoding="utf-8")
    )


def test_saas_rotation_schema_is_packaged() -> None:
    schema = load_schema_for_family(SAAS_ROTATION_FAMILY)

    assert schema["title"] == SAAS_ROTATION_FAMILY
    assert schema["x-keeper-live-proof"]["status"] == "preview-gated"
    assert schema["properties"]["schema"]["const"] == SAAS_ROTATION_FAMILY


def test_saas_rotation_fixture_validates_and_loads_typed_model() -> None:
    document = _doc()

    assert validate_manifest(document) == SAAS_ROTATION_FAMILY
    loaded = load_declarative_manifest_string(json.dumps(document), suffix=".json")

    assert isinstance(loaded, SaaSRotationManifestV1)
    assert loaded.rotations[0].provider == "salesforce"
    assert loaded.bindings[0].record_uid_ref.endswith("rec.salesforce-admin")


def test_saas_rotation_loader_rejects_unknown_rotation_ref() -> None:
    document = _doc()
    document["bindings"][0]["rotation_uid_ref"] = "keeper-saas-rotation:rotations:rotation.missing"

    with pytest.raises(SchemaError) as exc:
        load_saas_rotation_manifest(document)

    assert "unknown SaaS rotation refs" in exc.value.reason


def test_saas_rotation_schema_has_required_fields() -> None:
    schema = load_schema_for_family(SAAS_ROTATION_FAMILY)

    assert "required" in schema
    assert "name" in schema["$defs"]["saas_rotation_config"]["required"]


def test_saas_rotation_empty_rotations_validates() -> None:
    document = {
        "schema": SAAS_ROTATION_FAMILY,
        "rotations": [],
        "bindings": [],
    }

    assert validate_manifest(document) == SAAS_ROTATION_FAMILY


def test_saas_rotation_example_has_known_ref_types() -> None:
    document = _doc()

    assert isinstance(document.get("rotations"), list)
    assert len(document["rotations"]) >= 1
    uid = document["rotations"][0].get("uid_ref")
    assert isinstance(uid, str)
    assert uid


def test_compute_saas_rotation_diff_raises_on_live_snapshot() -> None:
    """compute_saas_rotation_diff must raise NotImplementedError when live data is passed."""
    from dsk.core.models_saas_rotation import SaaSRotationManifestV1
    from dsk.core.saas_rotation_diff import compute_saas_rotation_diff

    manifest = SaaSRotationManifestV1(rotations=[], bindings=[])
    with pytest.raises(NotImplementedError, match="live readback is not implemented"):
        compute_saas_rotation_diff(manifest, live={"some": "data"})


def test_compute_saas_rotation_diff_includes_bindings() -> None:
    """compute_saas_rotation_diff must emit changes for both rotations and bindings."""
    from dsk.core.models_saas_rotation import SaaSRotationManifestV1
    from dsk.core.saas_rotation_diff import compute_saas_rotation_diff

    manifest = SaaSRotationManifestV1(
        rotations=[
            {
                "uid_ref": "r.salesforce",
                "name": "SF Admin",
                "provider": "salesforce",
            }
        ],
        bindings=[
            {
                "uid_ref": "b.sf-admin",
                "rotation_uid_ref": "keeper-saas-rotation:rotations:r.salesforce",
                "record_uid_ref": "keeper-vault:records:rec1",
            }
        ],
    )
    changes = compute_saas_rotation_diff(manifest, live=None)
    types = {c.resource_type for c in changes}
    assert "saas_rotation_config" in types
    assert "saas_rotation_binding" in types


def test_compute_saas_rotation_diff_sets_manifest_name() -> None:
    """compute_saas_rotation_diff must apply the manifest_name arg to all changes."""
    from dsk.core.models_saas_rotation import SaaSRotationManifestV1
    from dsk.core.saas_rotation_diff import compute_saas_rotation_diff

    manifest = SaaSRotationManifestV1(
        rotations=[
            {
                "uid_ref": "r.x",
                "name": "X Rotation",
                "provider": "salesforce",
            }
        ],
        bindings=[],
    )
    changes = compute_saas_rotation_diff(manifest, live=None, manifest_name="my-saas")
    assert all(c.manifest_name == "my-saas" for c in changes)
