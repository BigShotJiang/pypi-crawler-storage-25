"""G1a / row 151: ``dsk report vault-health`` contract (stats, redaction, leak exit)."""

from __future__ import annotations

import json
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli._live.transcript import secret_leak_check
from dsk.cli._report.common import ReportOutputLeakError
from dsk.cli.main import EXIT_GENERIC


def _run(args: list[str]):
    return CliRunner().invoke(main, args, catch_exceptions=False)


def _install_list_records(
    monkeypatch: pytest.MonkeyPatch,
    rows: list[dict[str, Any]] | dict[str, Any],
    *,
    shared_folders: list[dict[str, Any]] | None = None,
    calls: list[list[str]] | None = None,
) -> None:
    sf_payload = [] if shared_folders is None else shared_folders

    def fake_run_keeper_batch(argv: list[str], **_kwargs: object) -> str:
        if calls is not None:
            calls.append(argv)
        if argv[:2] == ["list-records", "--format"]:
            return json.dumps(rows)
        if argv[:2] == ["shared-folder-list", "--format"]:
            return json.dumps(sf_payload)
        raise AssertionError(f"unexpected keeper argv head: {argv[:4]}")

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", fake_run_keeper_batch)


def _healthy_row(uid: str = "AaBbCcDdEeFfGgHhIiJjKk") -> dict[str, Any]:
    return {
        "record_uid": uid,
        "title": "healthy login",
        "type": "login",
        "folder_uid": "user-folder-stable",
        "fields": [{"type": "password", "value": [f"vault-health-password-{uid}"]}],
        "rotation_policy": {"name": "quarterly"},
        "modified": "2999-01-01T00:00:00Z",
    }


def test_report_vault_health_empty_vault_zero_counts(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_list_records(monkeypatch, [], shared_folders=[])

    result = _run(["report", "vault-health", "--json"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["summary"]["total_records"] == 0
    assert payload["summary"]["shared_folder_count"] == 0
    assert payload["summary"]["record_count_by_type"] == {}
    assert payload["meta"]["shared_folders"] == []


def test_report_vault_health_five_records_two_shared_folders(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def row(uid: str, rtype: str, sf_uid: str) -> dict[str, Any]:
        base = _healthy_row(uid)
        base["type"] = rtype
        base["folder_uid"] = ""
        base["shared_folder_uid"] = sf_uid
        base["fields"] = [{"type": "password", "value": [f"pw-{uid}"]}]
        return base

    lr = [
        row("Ua01", "login", "SfAAAA"),
        row("Ua02", "login", "SfAAAA"),
        row("Ua03", "contact", "SfBBBB"),
        row("Ua04", "contact", "SfBBBB"),
        row("Ua05", "contact", "SfBBBB"),
    ]
    sf = [
        {"shared_folder_uid": "SfAAAA", "name": "Team A", "record_count": 0},
        {"shared_folder_uid": "SfBBBB", "name": "Team B"},
    ]
    _install_list_records(monkeypatch, lr, shared_folders=sf)

    result = _run(["report", "vault-health"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["summary"]["total_records"] == 5
    assert payload["summary"]["record_count_by_type"] == {"contact": 3, "login": 2}
    assert payload["summary"]["shared_folder_count"] == 2
    by_uid = {r["shared_folder_uid"]: r for r in payload["meta"]["shared_folders"]}
    assert by_uid["SfAAAA"]["record_count"] == 2
    assert by_uid["SfBBBB"]["record_count"] == 3


def test_report_vault_health_flags_orphan_without_folder_or_shared_link(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    row = _healthy_row("ORPHA123456789ABCDEF")
    row["folder_uid"] = ""
    row.pop("rotation_policy", None)
    row["fields"] = [{"type": "password", "value": ["orphan-only"]}]
    row["modified"] = "2999-01-01T00:00:00Z"
    _install_list_records(monkeypatch, [row])

    result = _run(["report", "vault-health"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["summary"]["orphan_record_count"] == 1
    assert payload["summary"]["orphan"] == 1
    titles = [r["title"] for r in payload["records"]]
    assert "healthy login" in titles
    issue_sets = [tuple(r["issues"]) for r in payload["records"]]
    assert any("orphan" in issues for issues in issue_sets)


def test_report_vault_health_sanitize_uids_hides_plain_uids(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    raw_uid = "ZzYyXxWwVvUuTtSsRrQqOoNnMm"
    lr = [_healthy_row(raw_uid)]
    lr[0]["shared_folder_uid"] = "SsFfUuIiDd1122334455"
    sf = [{"shared_folder_uid": lr[0]["shared_folder_uid"], "name": "Secrets"}]
    monkeypatch.setenv("KEEPER_PASSWORD", "dummy-not-in-output")
    _install_list_records(monkeypatch, lr, shared_folders=sf)

    result = _run(["report", "vault-health", "--sanitize-uids"])

    assert result.exit_code == 0, result.output
    assert raw_uid not in result.stdout
    assert lr[0]["shared_folder_uid"] not in result.stdout
    needle = str(lr[0]["fields"][0]["value"][0])
    assert needle not in result.stdout
    assert (
        secret_leak_check(
            result.stdout,
            env_keys=("KEEPER_PASSWORD",),
        )
        == []
    )


def test_report_vault_health_leak_in_serialized_payload_exits_generic(
    monkeypatch: pytest.MonkeyPatch,
) -> None:

    _install_list_records(monkeypatch, [], shared_folders=[])

    def _boom(payload: dict[str, Any]) -> str:
        raise ReportOutputLeakError(["synthetic-for-test"])

    monkeypatch.setattr(
        "dsk.cli._report.common.serialize_report_payload",
        _boom,
    )

    result = _run(["report", "vault-health"])

    assert result.exit_code == EXIT_GENERIC, result.output
    assert "leak" in result.stderr.casefold()
