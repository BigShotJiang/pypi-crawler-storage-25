"""pamUser ``saas_plugins`` argv builders and Commander apply wiring (G2b)."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import LiveRecord
from dsk.core.models import SaasPluginConfig
from dsk.core.planner import Plan
from dsk.providers import commander_cli
from dsk.providers.commander_cli import (
    CommanderCliProvider,
    build_pam_user_saas_plugin_remove_argvs,
    build_pam_user_saas_plugin_set_entries,
)
from dsk.providers.mock import MockProvider


def _manifest_with_user(*, saas_plugins: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "name": "saas-plug-test",
        "resources": [
            {
                "uid_ref": "res.db",
                "type": "pamMachine",
                "title": "db-1",
                "host": "h",
                "users": [
                    {
                        "type": "pamUser",
                        "uid_ref": "user.alice",
                        "title": "alice",
                        "saas_plugins": saas_plugins,
                    }
                ],
            }
        ],
    }


def _live_fixture() -> list[LiveRecord]:
    return [
        LiveRecord(
            keeper_uid="MACH_UID",
            title="db-1",
            resource_type="pamMachine",
            marker={"uid_ref": "res.db"},
            payload={},
        ),
        LiveRecord(
            keeper_uid="USER_UID",
            title="alice",
            resource_type="pamUser",
            marker={"uid_ref": "user.alice", "title": "alice"},
            payload={},
        ),
    ]


def test_no_saas_plugins_yields_no_argv_rows() -> None:
    m = _manifest_with_user(saas_plugins=[])
    assert build_pam_user_saas_plugin_set_entries(m, _live_fixture()) == []


def test_saas_plugins_with_config_record_use_pam_action_saas_set() -> None:
    m = _manifest_with_user(
        saas_plugins=[
            {"plugin_name": "salesforce", "config_record_uid": "CFGREC", "config": {"a": 1}},
        ]
    )
    rows = build_pam_user_saas_plugin_set_entries(m, _live_fixture())
    assert len(rows) == 1
    uid_ref, user_uid, argv = rows[0]
    assert uid_ref == "user.alice"
    assert user_uid == "USER_UID"
    assert argv == [
        "pam",
        "action",
        "saas",
        "set",
        "--user-uid",
        "USER_UID",
        "--config-record-uid",
        "CFGREC",
    ]


def test_saas_plugins_inline_use_pam_saas_set_json_argv() -> None:
    m = _manifest_with_user(
        saas_plugins=[{"plugin_name": "okta", "config": {"region": "us"}}],
    )
    rows = build_pam_user_saas_plugin_set_entries(m, _live_fixture())
    assert len(rows) == 1
    _uid_ref, _user_uid, argv = rows[0]
    assert argv[:3] == ["pam", "saas", "set"]
    assert argv[argv.index("--user") + 1] == "USER_UID"
    assert argv[argv.index("--plugin") + 1] == "okta"
    assert argv[argv.index("--json") + 1] == '{"region": "us"}'


def test_saas_plugins_shrink_emits_pam_action_saas_remove() -> None:
    manifest = _manifest_with_user(saas_plugins=[])
    live = _live_fixture()
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="user.alice",
        resource_type="pamUser",
        title="alice",
        keeper_uid="USER_UID",
        before={
            "saas_plugins": [{"plugin_name": "salesforce", "config_record_uid": "CFG"}],
        },
        after={"saas_plugins": []},
    )
    plan = Plan(manifest_name="x", changes=[change], order=["user.alice"])
    rows = build_pam_user_saas_plugin_remove_argvs(plan, manifest, live)
    assert len(rows) == 1
    uid_ref, argv = rows[0]
    assert uid_ref == "user.alice"
    assert argv == [
        "pam",
        "action",
        "saas",
        "remove",
        "--user-uid",
        "USER_UID",
        "--resource-uid",
        "MACH_UID",
    ]


def test_malformed_saas_plugin_rejects_missing_plugin_name() -> None:
    with pytest.raises(Exception):
        SaasPluginConfig.model_validate({"config": {}})


def test_apply_saas_set_missing_commander_raises_capability_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: object())
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda fn: fn())
    provider._manifest_source = _manifest_with_user(
        saas_plugins=[{"plugin_name": "x", "config_record_uid": "CFG"}],
    )

    kc = types.ModuleType("keepercommander")
    kc.__path__ = []
    cmd = types.ModuleType("keepercommander.commands")
    cmd.__path__ = []
    pam = types.ModuleType("keepercommander.commands.pam_saas")
    pam.__path__ = []
    st = types.ModuleType("keepercommander.commands.pam_saas.set")
    kc.commands = cmd
    cmd.pam_saas = pam
    pam.set = st
    monkeypatch.setitem(sys.modules, "keepercommander", kc)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", cmd)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.pam_saas", pam)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.pam_saas.set", st)

    live = _live_fixture()
    plan = Plan(manifest_name="p", changes=[], order=[])
    with pytest.raises(CapabilityError, match="PAMActionSaasSetCommand is unavailable"):
        provider._apply_pam_user_saas_plugins(plan, live)


def test_mock_dry_run_records_saas_preview_commands() -> None:
    live = _live_fixture()
    provider = MockProvider("preview", pam_manifest_source=_manifest_with_user(saas_plugins=[]))
    provider._records = {r.keeper_uid: r for r in live}
    plan = Plan(manifest_name="preview", changes=[], order=[])
    outcomes = provider.apply_plan(plan, dry_run=True)
    saas_rows = [o for o in outcomes if o.details.get("would", "").startswith("saas_plugin")]
    assert saas_rows == []

    src = _manifest_with_user(
        saas_plugins=[{"plugin_name": "p", "config_record_uid": "R1"}],
    )
    provider2 = MockProvider("preview", pam_manifest_source=src)
    provider2._records = {r.keeper_uid: r for r in live}
    out2 = provider2.apply_plan(plan, dry_run=True)
    saas2 = [o for o in out2 if o.details.get("would") == "saas_plugin_set"]
    assert len(saas2) == 1
    assert "R1" in saas2[0].details["command"]


def test_mock_dry_run_remove_preview() -> None:
    live = _live_fixture()
    src = _manifest_with_user(saas_plugins=[])
    provider = MockProvider("p", pam_manifest_source=src)
    provider._records = {r.keeper_uid: r for r in live}
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="user.alice",
        resource_type="pamUser",
        title="alice",
        keeper_uid="USER_UID",
        before={"saas_plugins": [{"plugin_name": "z", "config_record_uid": "C1"}]},
        after={"saas_plugins": []},
    )
    plan = Plan(manifest_name="p", changes=[change], order=["user.alice"])
    outs = provider.apply_plan(plan, dry_run=True)
    rem = [o for o in outs if o.details.get("would") == "saas_plugin_remove"]
    assert len(rem) == 1
    assert rem[0].details["command"][:4] == ["pam", "action", "saas", "remove"]
