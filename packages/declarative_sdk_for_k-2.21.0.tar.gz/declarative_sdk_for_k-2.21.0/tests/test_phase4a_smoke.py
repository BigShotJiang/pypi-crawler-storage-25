"""Phase 4-A Tier 1 — offline smoke harness for dsk import-from-keepercmd.

Uses the `tests/fixtures/keepercmd_rehearsal/` fixture directory.
No live Commander tenant required — all tests are fully offline.

Tier 2 (live smoke against Acme +lab) is a separate file pending D1 fixture from Bob.

Fixture requirements:
  - audit.log   — valid HMAC chain
  - manifest.csv — 4 rows (3 adoptable, 1 dsk_adoptable=false)
  - manifest.csv.sha256 — sidecar
  - inventory.json — 4 records, 2 shared folders
  - SHA256SUMS.txt — placeholder (no per-record exports in rehearsal fixture)
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest

REHEARSAL = Path(__file__).parent / "fixtures" / "keepercmd_rehearsal"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run_import(
    run_dir: Path, output_path: Path, extra_args: list[str] | None = None
) -> subprocess.CompletedProcess[str]:
    """Run `dsk import-from-keepercmd` and return the CompletedProcess."""
    cmd = [
        "python3",
        "-m",
        "dsk.cli",
        "import-from-keepercmd",
        str(run_dir),
        "--output",
        str(output_path / "manifest.yaml"),
        "--suspect-threshold",
        "0",
    ] + (extra_args or [])
    return subprocess.run(cmd, capture_output=True, text=True, timeout=30)


# ---------------------------------------------------------------------------
# Fixture validation (these tests confirm the fixture itself is well-formed)
# ---------------------------------------------------------------------------


def test_rehearsal_fixture_exists() -> None:
    """Ensure the rehearsal fixture directory and required files are present."""
    assert REHEARSAL.exists(), f"rehearsal fixture missing: {REHEARSAL}"
    for fname in (
        "audit.log",
        "manifest.csv",
        "manifest.csv.sha256",
        "inventory.json",
        "SHA256SUMS.txt",
    ):
        assert (REHEARSAL / fname).exists(), f"fixture file missing: {fname}"


def test_rehearsal_manifest_csv_sha256_valid() -> None:
    """manifest.csv.sha256 sidecar must match the actual SHA256 of manifest.csv."""
    import hashlib

    csv_bytes = (REHEARSAL / "manifest.csv").read_bytes()
    actual = hashlib.sha256(csv_bytes).hexdigest()
    sidecar_line = (REHEARSAL / "manifest.csv.sha256").read_text().strip().split()[0]
    assert actual == sidecar_line, (
        f"manifest.csv.sha256 sidecar mismatch:\n  stored: {sidecar_line}\n  actual: {actual}"
    )


def test_rehearsal_audit_log_chain_valid() -> None:
    """audit.log must have a valid chain: each event has signature field and correct prev_hash."""
    import hashlib

    raw_lines = [
        line for line in (REHEARSAL / "audit.log").read_text().splitlines() if line.strip()
    ]
    assert raw_lines, "audit.log is empty"
    prev_hash = ""
    for i, line in enumerate(raw_lines):
        event = json.loads(line)
        assert "signature" in event, f"audit.log line {i + 1}: missing signature field"
        assert event.get("prev_hash", "") == prev_hash, (
            f"audit.log chain broken at line {i + 1}: "
            f"expected prev_hash={prev_hash!r}, got {event.get('prev_hash')!r}"
        )
        # Verify signature: SHA256 of event excluding the signature field, sorted keys
        check = {k: v for k, v in event.items() if k != "signature"}
        expected_sig = hashlib.sha256(json.dumps(check, sort_keys=True).encode()).hexdigest()
        assert event["signature"] == expected_sig, f"audit.log line {i + 1}: signature mismatch"
        prev_hash = hashlib.sha256(line.encode()).hexdigest()


def test_rehearsal_inventory_has_four_records() -> None:
    """inventory.json must have exactly 4 records."""
    inv = json.loads((REHEARSAL / "inventory.json").read_text())
    assert inv["record_count"] == 4
    assert len(inv["records"]) == 4


def test_rehearsal_manifest_has_three_adoptable_rows() -> None:
    """manifest.csv must have 3 adoptable rows and 1 dsk_adoptable=false."""
    import csv

    rows = list(csv.DictReader((REHEARSAL / "manifest.csv").read_text().splitlines()))
    adoptable = [r for r in rows if r.get("dsk_adoptable", "true").lower() == "true"]
    non_adoptable = [r for r in rows if r.get("dsk_adoptable", "true").lower() == "false"]
    assert len(adoptable) == 3, f"expected 3 adoptable rows, got {len(adoptable)}"
    assert len(non_adoptable) == 1, f"expected 1 non-adoptable row, got {len(non_adoptable)}"


# ---------------------------------------------------------------------------
# Tier 1 smoke tests (offline, no live Commander)
# ---------------------------------------------------------------------------


@pytest.mark.skipif(
    not shutil.which("dsk")
    and not (Path(__file__).parents[1] / "dsk" / "cli" / "main.py").exists(),
    reason="dsk not installed and not found in source tree",
)
def test_dry_run_exits_zero(tmp_path: Path) -> None:
    """dsk import-from-keepercmd --dry-run should exit 0 against the rehearsal fixture."""
    result = _run_import(REHEARSAL, tmp_path / "out", extra_args=["--dry-run"])
    assert result.returncode == 0, (
        f"dry-run failed (exit {result.returncode}):\n"
        f"stdout: {result.stdout}\nstderr: {result.stderr}"
    )


@pytest.mark.skipif(
    not shutil.which("dsk")
    and not (Path(__file__).parents[1] / "dsk" / "cli" / "main.py").exists(),
    reason="dsk not installed and not found in source tree",
)
def test_tampered_audit_log_aborts(tmp_path: Path) -> None:
    """dsk import-from-keepercmd must abort (non-zero exit) when audit.log chain is broken."""
    run_dir = tmp_path / "run"
    shutil.copytree(REHEARSAL, run_dir)

    # Break the chain by appending a rogue line with wrong prev_hash
    log = run_dir / "audit.log"
    log.write_text(log.read_text() + '{"event":"TAMPERED","prev_hash":"' + "f" * 64 + '"}\n')

    result = _run_import(run_dir, tmp_path / "out")
    assert result.returncode != 0, "tampered audit.log should cause non-zero exit"
    combined = (result.stdout + result.stderr).lower()
    assert (
        "corrupt" in combined
        or "chain" in combined
        or "audit" in combined
        or "signature" in combined
    ), (
        f"expected audit chain error in stdout/stderr:\nstdout: {result.stdout!r}\nstderr: {result.stderr!r}"
    )


@pytest.mark.skipif(
    not shutil.which("dsk")
    and not (Path(__file__).parents[1] / "dsk" / "cli" / "main.py").exists(),
    reason="dsk not installed and not found in source tree",
)
def test_tampered_manifest_csv_sidecar_aborts(tmp_path: Path) -> None:
    """dsk import-from-keepercmd must abort when manifest.csv doesn't match its sha256 sidecar."""
    run_dir = tmp_path / "run"
    shutil.copytree(REHEARSAL, run_dir)

    # Tamper manifest.csv without updating sidecar
    (run_dir / "manifest.csv").write_text(
        (run_dir / "manifest.csv").read_text() + "TAMPERED,row,login,/x,SF_X,x@y.z,2026,true\n"
    )

    result = _run_import(run_dir, tmp_path / "out")
    assert result.returncode != 0, "tampered manifest.csv should cause non-zero exit"


# ---------------------------------------------------------------------------
# Fixture verification tests (always run, no CLI needed)
# ---------------------------------------------------------------------------


def test_rehearsal_two_shared_folders() -> None:
    """inventory.json must reference exactly 2 distinct shared folder UIDs."""
    inv = json.loads((REHEARSAL / "inventory.json").read_text())
    sf_uids = {r["shared_folder_uid"] for r in inv["records"]}
    assert len(sf_uids) == 2, f"expected 2 shared folders, got: {sf_uids}"


# ---------------------------------------------------------------------------
# D3 bug assertions (Bugs 34, 33, 87)
# ---------------------------------------------------------------------------


def test_records_import_json_uses_dollar_type() -> None:
    """Bug 34 — every record in records_import.json must use '$type', not bare 'type'.

    If records_import.json is absent the test creates a minimal synthetic fixture
    (2 records) so the assertion is always exercisable without a live run-dir.
    """
    import csv

    fixture = REHEARSAL / "records_import.json"
    if not fixture.exists():
        manifest_rows = list(csv.DictReader((REHEARSAL / "manifest.csv").read_text().splitlines()))
        adoptable = [r for r in manifest_rows if r.get("dsk_adoptable", "true").lower() == "true"]
        records = []
        for i, row in enumerate(adoptable[:2]):
            records.append(
                {
                    "uid": f"T_SYNTH_{i:03d}_{row['uid'][-8:]}",
                    "title": row["title"],
                    "$type": row["type"],
                    "fields": {},
                    "custom_fields": {},
                    "shared_folder_uid": row["shared_folder_uid"],
                }
            )
        bundle = {
            "schema_version": "1.0",
            "tenant": "rehearsal-anon",
            "run_id": "synthetic-smoke",
            "exported_at": "2026-05-09T00:00:00Z",
            "records": records,
        }
        fixture.write_text(json.dumps(bundle, indent=2))

    bundle = json.loads(fixture.read_text())
    records = bundle.get("records", [])
    assert records, "records_import.json has no records"
    for rec in records:
        assert "$type" in rec, (
            f"Bug 34: record uid={rec.get('uid')!r} uses bare 'type' instead of '$type'. "
            f"Keys present: {list(rec.keys())}"
        )
        assert "type" not in rec, (
            f"Bug 34: record uid={rec.get('uid')!r} has bare 'type' key alongside (or instead of) '$type'. "
            f"Keys present: {list(rec.keys())}"
        )


def test_no_source_uid_leakage_in_records_import() -> None:
    """Bug 33 — no source UID from manifest.csv must appear in any field value.

    The conversion pipeline must map source → target UIDs everywhere; leaking
    a source UID into a field value breaks round-trip identity.
    """
    import csv

    fixture = REHEARSAL / "records_import.json"
    if not fixture.exists():
        pytest.skip("records_import.json not present in fixture dir — skip UID-leakage check")

    manifest_text = (REHEARSAL / "manifest.csv").read_text()
    source_uids = {
        row["uid"] for row in csv.DictReader(manifest_text.splitlines()) if row.get("uid")
    }
    assert source_uids, "manifest.csv has no UID column — check fixture"

    bundle = json.loads(fixture.read_text())
    violations: list[str] = []
    for rec in bundle.get("records", []):
        rec_uid = rec.get("uid", "<unknown>")
        for section in ("fields", "custom_fields"):
            for field_name, field_val in (rec.get(section) or {}).items():
                val_str = json.dumps(field_val)
                for src_uid in source_uids:
                    if src_uid in val_str:
                        violations.append(
                            f"Bug 33: source UID {src_uid!r} leaked into record "
                            f"uid={rec_uid!r} field {section}.{field_name!r}"
                        )
        # Also check the record-level uid itself shouldn't be a source UID
        if rec_uid in source_uids:
            violations.append(
                f"Bug 33: record uid={rec_uid!r} is a source UID — should be a target UID"
            )

    assert not violations, "\n".join(violations)


def test_records_import_json_has_no_backward_refs() -> None:
    """Bug 87 — topological ordering: fileRef values must only reference UIDs seen earlier.

    A 'backward ref' means record[i] references a UID that only appears at
    record[j] where j > i.  The conversion pipeline must sort records so that
    referenced files precede their referencing records.

    For synthetic fixtures with no fileRef records this test passes trivially.
    """
    fixture = REHEARSAL / "records_import.json"
    if not fixture.exists():
        pytest.skip("records_import.json not present in fixture dir — skip topological check")

    bundle = json.loads(fixture.read_text())
    records = bundle.get("records", [])
    if not records:
        pytest.skip("records_import.json has no records")

    seen_uids: set[str] = set()
    backward_refs: list[str] = []
    has_file_refs = False

    for rec in records:
        rec_uid = rec.get("uid", "<unknown>")
        for section in ("fields", "custom_fields"):
            for field_name, field_val in (rec.get(section) or {}).items():
                if "fileRef" in field_name or field_name.endswith("_ref"):
                    has_file_refs = True
                    ref_uids = (
                        [field_val]
                        if isinstance(field_val, str)
                        else (field_val if isinstance(field_val, list) else [])
                    )
                    for ref_uid in ref_uids:
                        if ref_uid and ref_uid not in seen_uids:
                            backward_refs.append(
                                f"Bug 87: record uid={rec_uid!r} has forward reference to "
                                f"{ref_uid!r} in field {section}.{field_name!r} "
                                f"(referenced UID not yet seen)"
                            )
        seen_uids.add(rec_uid)

    if not has_file_refs:
        # Synthetic fixture — no fileRef fields; pass trivially but note it
        return

    assert not backward_refs, (
        f"Topological ordering violated ({len(backward_refs)} backward ref(s)):\n"
        + "\n".join(backward_refs)
    )


# ---------------------------------------------------------------------------
# Record-type alias coverage (unit, always runs)
# ---------------------------------------------------------------------------

#: Complete set of $type values keeperCMD can emit in a records_import.json.
#: Sourced from:
#:   - keeperCMD converter.py (passes through rec['type'] verbatim)
#:   - pam_detection.py docstring (pam* prefix family)
#:   - Keeper v3 built-in type catalogue
#:   - keeperCMD tests (test_converter.py, test_pam_detection.py, test_validate.py)
_KEEPERCMD_EMITTABLE_TYPES = [
    # Standard credential / vault types
    "login",
    "secureNote",
    "encryptedNotes",
    "general",
    "bankCard",
    "bankAccount",
    "address",
    "contact",
    "softwareLicense",
    "sshKeys",
    "databaseCredentials",
    "serverCredentials",
    "healthInsurance",
    "passport",
    "driverLicense",
    "membership",
    "file",
    "photo",
    "ssnCard",
    "paymentCard",
    # Rare types — explicit documented fallback to login
    "wifiCredentials",
    "birthCertificate",
]

#: Phase 4-E: these 7 types now have native DSK support and must normalise
#: to themselves (identity mapping), not to "login".
_PHASE4E_NATIVE_TYPES = frozenset(
    {
        "sshKeys",
        "databaseCredentials",
        "serverCredentials",
        "softwareLicense",
        "passport",
        "driverLicense",
        "membership",
    }
)

#: PAM types are detected and excluded by keeperCMD before migration; they
#: must NOT appear in the adoption manifest.  Listed here as documentation
#: only — not parametrized into the alias-coverage test.
_KEEPERCMD_PAM_TYPES = [
    "pamUser",
    "pamMachine",
    "pamDatabase",
    "pamDirectory",
    "pamRemoteBrowser",
    "pamNetworkConfiguration",
    "pamAwsConfiguration",
]


def test_native_typed_record_in_manifest_passes_schema() -> None:
    """A minimal keeper-vault.v1 manifest with a sshKeys record must pass validate_manifest.

    Phase 5 regression guard: sshKeys is in the record_type_name enum and
    VAULT_SUPPORTED_RECORD_TYPES, so schema validation must not raise.
    """
    from dsk.core.vault_models import load_vault_manifest

    document = {
        "schema": "keeper-vault.v1",
        "records": [
            {
                "uid_ref": "smoke.sshkeys.001",
                "type": "sshKeys",
                "title": "Test SSH Key",
            }
        ],
    }
    manifest = load_vault_manifest(document)
    assert manifest.records[0].type == "sshKeys"


def test_custom_type_passthrough_warns_not_crashes() -> None:
    """_normalise_record_type must return unknown types unchanged (not raise, not crash).

    Phase 5 → Phase 4-G: custom/admin-defined record types should survive the
    import normalisation step.  The function now returns a (type, is_custom)
    tuple and emits [blue]info:[/] instead of [yellow]warn:[/] — a custom type
    is expected behaviour, not a problem.
    """
    from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type

    result, is_custom = _normalise_record_type("myCustomType")
    assert result == "myCustomType", (
        f"Expected custom type to pass through unchanged, got {result!r}"
    )
    assert is_custom is True, "Expected is_custom=True for an unknown type"


@pytest.mark.parametrize("keeper_type", _KEEPERCMD_EMITTABLE_TYPES)
def test_all_keeper_record_types_have_dsk_alias(keeper_type: str) -> None:
    """Every $type keeperCMD can emit must survive _normalise_record_type
    without raising and must resolve to a type in VAULT_SUPPORTED_RECORD_TYPES.

    Phase 4-E regression guard: the 7 native types must map to themselves
    (not to "login").

    Regression guard: if a new keeperCMD type is added without a corresponding
    DSK alias, this test fails loudly before a live tenant migration hits the
    VaultManifestV1._l1_login_slice guard at runtime.
    """
    from dsk.cli.cmd_import_from_keepercmd import _normalise_record_type
    from dsk.core.vault_models import VAULT_SUPPORTED_RECORD_TYPES

    normalised, is_custom = _normalise_record_type(keeper_type)
    assert not is_custom, (
        f"keeperCMD type {keeper_type!r} was flagged as custom (is_custom=True) — "
        f"normalised to {normalised!r}.\n"
        f"Supported: {sorted(VAULT_SUPPORTED_RECORD_TYPES)}\n"
        f"Fix: add an alias in dsk/cli/cmd_import_from_keepercmd.py "
        f"_normalise_record_type AND in dsk/core/vault_models.py "
        f"_VAULT_RECORD_TYPE_ALIASES."
    )
    assert normalised in VAULT_SUPPORTED_RECORD_TYPES, (
        f"keeperCMD type {keeper_type!r} normalises to {normalised!r} which is not in "
        f"VAULT_SUPPORTED_RECORD_TYPES.\n"
        f"Supported: {sorted(VAULT_SUPPORTED_RECORD_TYPES)}\n"
        f"Fix: add an alias in dsk/cli/cmd_import_from_keepercmd.py "
        f"_normalise_record_type AND in dsk/core/vault_models.py "
        f"_VAULT_RECORD_TYPE_ALIASES."
    )
    # Phase 4-E: native types must round-trip as themselves, not as "login"
    if keeper_type in _PHASE4E_NATIVE_TYPES:
        assert normalised == keeper_type, (
            f"Phase 4-E: native type {keeper_type!r} should normalise to itself, "
            f"but got {normalised!r}. Remove it from any → login alias map."
        )
