"""agent-memory-policy.v1 offline schema, model, and round-trip tests."""

from __future__ import annotations

import json
from typing import Any

import pytest
import yaml

from dsk.core.errors import SchemaError
from dsk.core.manifest import load_declarative_manifest_string
from dsk.core.models_agent_memory_policy import (
    AGENT_MEMORY_POLICY_FAMILY,
    AgentMemoryPolicyManifest,
    MemoryIsolationMode,
    load_agent_memory_policy_manifest,
)
from dsk.core.schema import load_schema_for_family, validate_manifest


def _memory_minimal() -> dict[str, Any]:
    return {
        "schema": AGENT_MEMORY_POLICY_FAMILY,
        "name": "minimal-memory-policy",
        "policies": [
            {
                "uid_ref": "mem.one",
                "name": "One",
            }
        ],
    }


def _memory_full() -> dict[str, Any]:
    return {
        "schema": AGENT_MEMORY_POLICY_FAMILY,
        "name": "full-memory-policy",
        "policies": [
            {
                "uid_ref": "mem.full-a",
                "name": "Full Policy A",
                "applies_to_agent_refs": ["nhi.agent-one", "nhi.agent-two"],
                "isolation_mode": "global_",
                "max_context_tokens": 64000,
                "allow_cross_session_recall": True,
                "allow_tool_output_in_memory": False,
                "allow_file_content_in_memory": False,
                "allow_web_content_in_memory": True,
                "sanitize_html": False,
                "sanitize_markdown_links": False,
                "goal_lock_enabled": True,
                "max_instruction_depth": 50,
                "tags": {"env": "staging"},
            },
            {
                "uid_ref": "mem.full-b",
                "name": "Full Policy B",
                "isolation_mode": "role",
                "max_context_tokens": None,
                "max_instruction_depth": None,
                "tags": {},
            },
        ],
    }


def test_agent_memory_policy_schema_is_packaged() -> None:
    schema = load_schema_for_family(AGENT_MEMORY_POLICY_FAMILY)

    assert schema["title"] == AGENT_MEMORY_POLICY_FAMILY
    assert "policies" in schema["properties"]
    assert schema["x-keeper-live-proof"]["status"] == "upstream-gap"


def test_agent_memory_validate_minimal() -> None:
    assert validate_manifest(_memory_minimal()) == AGENT_MEMORY_POLICY_FAMILY


def test_agent_memory_validate_full() -> None:
    assert validate_manifest(_memory_full()) == AGENT_MEMORY_POLICY_FAMILY


def test_agent_memory_session_isolation_default() -> None:
    doc = _memory_minimal()
    loaded = load_agent_memory_policy_manifest(doc)
    assert loaded.policies[0].isolation_mode is MemoryIsolationMode.session


def test_agent_memory_allow_web_defaults_false() -> None:
    doc = _memory_minimal()
    loaded = load_agent_memory_policy_manifest(doc)
    assert loaded.policies[0].allow_web_content_in_memory is False


def test_agent_memory_invalid_isolation_mode() -> None:
    doc = _memory_minimal()
    doc["policies"][0]["isolation_mode"] = "invalid-mode"

    with pytest.raises(SchemaError) as exc:
        validate_manifest(doc)

    msg = exc.value.reason.lower()
    assert "invalid-mode" in msg or "enum" in msg or "not valid" in msg


def test_agent_memory_rejects_duplicate_uid_refs() -> None:
    doc = _memory_minimal()
    doc["policies"].append(
        {
            "uid_ref": "mem.one",
            "name": "Duplicate",
        }
    )

    with pytest.raises(SchemaError) as exc:
        load_agent_memory_policy_manifest(doc)

    assert "duplicate uid_ref" in exc.value.reason


def test_agent_memory_load_returns_typed_model() -> None:
    loaded = load_declarative_manifest_string(
        json.dumps(_memory_full()),
        suffix=".json",
    )

    assert isinstance(loaded, AgentMemoryPolicyManifest)
    assert loaded.policies[0].uid_ref == "mem.full-a"
    assert loaded.policies[0].isolation_mode is MemoryIsolationMode.global_


def test_agent_memory_manifest_roundtrip_yaml() -> None:
    manifest = load_agent_memory_policy_manifest(_memory_full())
    dumped = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    yaml_out = yaml.safe_dump(dumped, sort_keys=False, allow_unicode=True)
    reloaded = load_declarative_manifest_string(yaml_out, suffix=".yaml")

    assert isinstance(reloaded, AgentMemoryPolicyManifest)
    assert reloaded.model_dump(mode="json", exclude_none=True, by_alias=True) == dumped
