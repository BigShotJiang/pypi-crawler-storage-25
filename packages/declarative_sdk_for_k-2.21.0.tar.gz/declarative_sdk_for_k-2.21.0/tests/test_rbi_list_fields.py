"""Unit tests for RBI list-shaped connection fields (autofill + URL allowlists).

Commander uses repeated flags; manifest model uses ``list[str]`` with newline
scalar coercion. Order is significant (matches repeated-flag order).
"""

from __future__ import annotations

from dsk.core.diff import ChangeKind, compute_diff
from dsk.core.graph import build_graph
from dsk.core.interfaces import LiveRecord
from dsk.core.metadata import encode_marker
from dsk.core.models import Manifest

_CFG = {
    "uid_ref": "cfg1",
    "environment": "local",
    "title": "Cfg",
    "gateway_uid_ref": "gw1",
}


def _manifest(
    *,
    uid_ref: str = "rbi1",
    connection: dict,
) -> Manifest:
    return Manifest.model_validate(
        {
            "version": "1",
            "name": "smoke",
            "gateways": [{"uid_ref": "gw1", "name": "gw", "mode": "reference_existing"}],
            "pam_configurations": [_CFG],
            "resources": [
                {
                    "uid_ref": uid_ref,
                    "type": "pamRemoteBrowser",
                    "title": "rbi-1",
                    "pam_configuration_uid_ref": "cfg1",
                    "url": "https://example.com/x",
                    "pam_settings": {
                        "options": {
                            "remote_browser_isolation": "on",
                            "graphical_session_recording": "on",
                        },
                        "connection": {"protocol": "http", **connection},
                    },
                }
            ],
        }
    )


def _pam_cfg_live() -> LiveRecord:
    return LiveRecord(
        keeper_uid="CONFIGUIDCONFIGUIDCONFIGUID",
        title="Cfg",
        resource_type="pam_configuration",
        folder_uid=None,
        payload={"title": "Cfg"},
        marker=encode_marker(uid_ref="cfg1", manifest="smoke", resource_type="pam_configuration"),
    )


def _live(uid_ref: str, connection: dict) -> LiveRecord:
    marker = encode_marker(uid_ref=uid_ref, manifest="smoke", resource_type="pamRemoteBrowser")
    return LiveRecord(
        keeper_uid="RBIRBIRBIRBIRBIRBIRBIRBI",
        title="rbi-1",
        resource_type="pamRemoteBrowser",
        folder_uid=None,
        payload={
            "title": "rbi-1",
            "type": "pamRemoteBrowser",
            "url": "https://example.com/x",
            "pam_settings": {
                "options": {"remote_browser_isolation": "on", "graphical_session_recording": "on"},
                "connection": {"protocol": "http", **connection},
            },
        },
        marker=marker,
    )


def test_autofill_targets_identical_lists_noop_round_trip() -> None:
    conn = {"allow_url_manipulation": False, "autofill_targets": ["#a", "#b"]}
    m = _manifest(connection=conn)
    build_graph(m)
    ch = compute_diff(m, [_pam_cfg_live(), _live("rbi1", conn)])
    assert [c.kind for c in ch if c.resource_type == "pamRemoteBrowser"] == [ChangeKind.NOOP]


def test_allowed_url_patterns_identical_lists_noop_round_trip() -> None:
    conn = {
        "allow_url_manipulation": False,
        "allowed_url_patterns": ["https://a.example/*", "https://b.example/*"],
    }
    m = _manifest(connection=conn)
    build_graph(m)
    ch = compute_diff(m, [_pam_cfg_live(), _live("rbi1", conn)])
    assert [c.kind for c in ch if c.resource_type == "pamRemoteBrowser"] == [ChangeKind.NOOP]


def test_allowed_resource_url_patterns_identical_lists_noop_round_trip() -> None:
    conn = {
        "allow_url_manipulation": False,
        "allowed_resource_url_patterns": ["https://cdn1/*", "https://cdn2/*"],
    }
    m = _manifest(connection=conn)
    build_graph(m)
    ch = compute_diff(m, [_pam_cfg_live(), _live("rbi1", conn)])
    assert [c.kind for c in ch if c.resource_type == "pamRemoteBrowser"] == [ChangeKind.NOOP]


def test_autofill_targets_repeated_flag_order_matters_update() -> None:
    desired = {"allow_url_manipulation": False, "autofill_targets": ["#first", "#second"]}
    live = {"allow_url_manipulation": False, "autofill_targets": ["#second", "#first"]}
    m = _manifest(connection=desired)
    ch = compute_diff(m, [_pam_cfg_live(), _live("rbi1", live)])
    assert [c.kind for c in ch if c.resource_type == "pamRemoteBrowser"] == [ChangeKind.UPDATE]


def test_allow_url_and_allowed_resource_patterns_repeated_flag_order_matters_update() -> None:
    cases = (
        ("allowed_url_patterns", ["https://aa/*", "https://bb/*"]),
        ("allowed_resource_url_patterns", ["https://res-a/*", "https://res-b/*"]),
    )
    for conn_key, pair in cases:
        desired = {"allow_url_manipulation": False, conn_key: [pair[0], pair[1]]}
        live = {"allow_url_manipulation": False, conn_key: [pair[1], pair[0]]}
        m = _manifest(connection=desired)
        ch = compute_diff(m, [_pam_cfg_live(), _live("rbi1", live)])
        assert [c.kind for c in ch if c.resource_type == "pamRemoteBrowser"] == [ChangeKind.UPDATE]


def test_list_shaped_connection_fields_empty_list_vs_live_absent() -> None:
    """Manifest ``[]`` is explicit; omitting the key is ``None`` — live missing key ⇒ UPDATE."""

    marker = encode_marker(uid_ref="rbi1", manifest="smoke", resource_type="pamRemoteBrowser")
    live_conn_base: dict = {"protocol": "http", "allow_url_manipulation": False}

    def _chk(
        *,
        desired_conn: dict[str, object],
        live_extra: dict[str, object],
        kind: ChangeKind,
    ) -> None:
        m = _manifest(connection=desired_conn)
        ch = compute_diff(
            m,
            [
                _pam_cfg_live(),
                LiveRecord(
                    keeper_uid="RBIX",
                    title="rbi-1",
                    resource_type="pamRemoteBrowser",
                    folder_uid=None,
                    payload={
                        "title": "rbi-1",
                        "type": "pamRemoteBrowser",
                        "url": "https://example.com/x",
                        "pam_settings": {
                            "options": {
                                "remote_browser_isolation": "on",
                                "graphical_session_recording": "on",
                            },
                            "connection": {**live_conn_base, **live_extra},
                        },
                    },
                    marker=marker,
                ),
            ],
        )
        rbi = [c for c in ch if c.resource_type == "pamRemoteBrowser"]
        assert len(rbi) == 1
        assert rbi[0].kind is kind

    for fname in (
        "autofill_targets",
        "allowed_url_patterns",
        "allowed_resource_url_patterns",
    ):
        _chk(
            desired_conn={"allow_url_manipulation": False, fname: []},
            live_extra={},
            kind=ChangeKind.UPDATE,
        )
        _chk(
            desired_conn={"allow_url_manipulation": False},
            live_extra={fname: []},
            kind=ChangeKind.NOOP,
        )
