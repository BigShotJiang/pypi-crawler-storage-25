"""REST provider tests for ``keeper-integrations-identity.v1``."""

from __future__ import annotations

from typing import Any

import pytest

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_integrations_identity import IDENTITY_FAMILY, IdentityManifestV1
from dsk.providers.integrations_identity_provider import IntegrationsIdentityProvider


def _manifest() -> IdentityManifestV1:
    return IdentityManifestV1.model_validate(
        {
            "schema": IDENTITY_FAMILY,
            "domains": [
                {
                    "name": "example.com",
                    "verified": True,
                    "primary": True,
                },
            ],
        },
    )


def test_identity_provider_plan_returns_update_diff() -> None:
    provider = IntegrationsIdentityProvider(endpoint_base="/identity/routing")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {
            "domains": [
                {"name": "example.com", "verified": False, "primary": True},
            ],
            "scim": [],
            "sso_providers": [],
            "outbound_email": None,
        }
    }

    plan = provider.plan(_manifest())

    updates = [c for c in plan.changes if c.kind is ChangeKind.UPDATE]
    assert updates
    assert updates[0].after == {"verified": True}


def test_identity_provider_plan_returns_create_diff() -> None:
    provider = IntegrationsIdentityProvider(endpoint_base="/identity/routing")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {
            "domains": [],
            "scim": [],
            "sso_providers": [],
            "outbound_email": None,
        }
    }

    plan = provider.plan(_manifest())

    creates = [c for c in plan.changes if c.kind is ChangeKind.CREATE]
    assert creates
    assert creates[0].uid_ref == "example.com"


def test_identity_provider_apply_calls_configured_endpoint() -> None:
    calls: list[tuple[str, dict[str, Any]]] = []
    provider = IntegrationsIdentityProvider(endpoint_base="/identity/routing")

    def fake_rest(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append((endpoint, payload))
        if payload["method"] == "GET":
            return {
                "configuration": {
                    "domains": [],
                    "scim": [],
                    "sso_providers": [],
                    "outbound_email": None,
                },
            }
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())

    outcomes = provider.apply_identity_plan(plan)

    assert outcomes[0].action == "create"
    assert calls[-1][0] == "identity/routing"
    assert calls[-1][1]["method"] == "PUT"
    assert calls[-1][1]["configuration"]["domains"][0]["name"] == "example.com"


def test_identity_provider_raises_capability_error_without_endpoint(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    for key in (
        "DSK_KEEPER_IDENTITY_ENDPOINT_BASE",
        "DSK_KEEPER_IDENTITY_READ_ENDPOINT",
        "DSK_KEEPER_IDENTITY_WRITE_ENDPOINT",
    ):
        monkeypatch.delenv(key, raising=False)

    provider = IntegrationsIdentityProvider()
    provider._rest_post = lambda *_a, **_k: {}  # type: ignore[method-assign]

    with pytest.raises(CapabilityError) as exc_info:
        provider.apply(_manifest())

    assert "endpoint is not confirmed" in (exc_info.value.reason or "")


def test_identity_provider_apply_dry_run_offline() -> None:
    """dry_run apply never touches REST and needs no endpoint env."""
    provider = IntegrationsIdentityProvider()
    outcomes = provider.apply(_manifest(), dry_run=True)
    assert outcomes
    assert all(getattr(o, "dry_run", False) or o.action for o in outcomes)


def test_discover_identity_configuration_uses_get_payload() -> None:
    """discover_identity_configuration sends GET method and family in payload."""
    calls: list[dict[str, object]] = []

    def fake_rest(_endpoint: str, payload: dict[str, object]) -> dict[str, object]:
        calls.append(payload)
        return {
            "configuration": {
                "domains": [],
                "scim": [],
                "sso_providers": [],
                "outbound_email": None,
            },
        }

    provider = IntegrationsIdentityProvider(endpoint_base="/identity/routing")
    provider._rest_post = fake_rest  # type: ignore[method-assign]
    cfg = provider.discover_identity_configuration()
    assert calls and calls[0]["method"] == "GET"
    assert cfg["domains"] == []


def test_identity_provider_plan_empty_when_live_matches_manifest() -> None:
    """When remote config matches desired, plan has no UPDATE mutations."""
    provider = IntegrationsIdentityProvider(endpoint_base="/identity/routing")
    desired = _manifest()
    payload = {
        "configuration": {
            "domains": [
                {"name": "example.com", "verified": True, "primary": True},
            ],
            "scim": [],
            "sso_providers": [],
            "outbound_email": None,
        },
    }
    provider._rest_post = lambda _e, _p: payload  # type: ignore[method-assign]
    plan = provider.plan(desired)
    updates = [c for c in plan.changes if c.kind is ChangeKind.UPDATE]
    assert not updates
