"""CLI smoke tests."""

from __future__ import annotations

import importlib
import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import (
    EXIT_CAPABILITY,
    EXIT_CHANGES,
    EXIT_CONFLICT,
    EXIT_GENERIC,
    EXIT_REF,
    EXIT_SCHEMA,
)
from dsk.core import (
    build_graph,
    build_plan,
    compute_diff,
    execution_order,
    load_manifest,
)
from dsk.core.interfaces import LiveRecord
from dsk.core.metadata import encode_marker
from dsk.providers import MockProvider

cli_main_module = importlib.import_module("dsk.cli.main")


def _run(args: list[str]):
    runner = CliRunner()
    return runner.invoke(main, args, catch_exceptions=False)


def test_validate_ok(minimal_manifest_path: Path) -> None:
    result = _run(["validate", str(minimal_manifest_path)])
    assert result.exit_code == 0, result.output
    assert "ok:" in result.output


def test_validate_json_pam_offline(minimal_manifest_path: Path) -> None:
    result = _run(["validate", str(minimal_manifest_path), "--json"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output.strip())
    assert data["ok"] is True
    assert data["family"] == "pam-environment.v1"
    assert data["mode"] == "pam_full"
    assert data["online"] is False
    assert "uid_ref_count" in data


def test_validate_json_scaffold_vault() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    path = repo_root / "examples" / "scaffold_only" / "vaultMinimal.yaml"
    result = _run(["validate", str(path), "--json"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output.strip())
    assert data["ok"] is True
    assert data["family"] == "keeper-vault.v1"
    assert data["mode"] == "vault_offline"
    assert data["online"] is False
    assert data["uid_ref_count"] == 0
    assert "uid_ref_graph" in data["stages_completed"]


def test_validate_json_scaffold_vault_one_login() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    path = repo_root / "examples" / "scaffold_only" / "vaultOneLogin.yaml"
    result = _run(["validate", str(path), "--json"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output.strip())
    assert data["ok"] is True
    assert data["family"] == "keeper-vault.v1"
    assert data["uid_ref_count"] == 1


def _vault_minimal_path() -> Path:
    return Path(__file__).resolve().parents[1] / "examples" / "scaffold_only" / "vaultMinimal.yaml"


def test_validate_vault_online_requires_commander() -> None:
    result = _run(["validate", str(_vault_minimal_path()), "--online"])
    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "commander" in result.output.lower()


def test_validate_vault_online_requires_folder_uid() -> None:
    result = _run(["--provider", "commander", "validate", str(_vault_minimal_path()), "--online"])
    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "folder" in result.output.lower()


def test_validate_vault_online_json_smoke(monkeypatch: pytest.MonkeyPatch) -> None:
    from unittest.mock import MagicMock

    fake = MagicMock()
    fake.discover.return_value = []
    fake.unsupported_capabilities.return_value = []
    fake.check_tenant_bindings.return_value = []
    monkeypatch.setattr(cli_main_module, "CommanderCliProvider", lambda **kw: fake)

    result = _run(
        [
            "--provider",
            "commander",
            "--folder-uid",
            "FOLDER_UID",
            "validate",
            str(_vault_minimal_path()),
            "--online",
            "--json",
        ]
    )
    assert result.exit_code == 0, result.output
    data = json.loads(result.output.strip())
    assert data["mode"] == "vault_online"
    assert data["online"] is True
    assert "diff_smoke" in data["stages_completed"]
    assert data["live_record_count"] == 0
    assert data["stage5_summary"]["create"] == 0


def test_validate_enterprise_online_json_smoke(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from unittest.mock import MagicMock

    manifest = tmp_path / "enterprise.yaml"
    manifest.write_text(
        "schema: keeper-enterprise.v1\n"
        "nodes:\n"
        "  - uid_ref: node.root\n"
        "    name: Root\n"
        "users:\n"
        "  - uid_ref: user.alice\n"
        "    email: alice@example.com\n"
        "    node_uid_ref: keeper-enterprise:nodes:node.root\n",
        encoding="utf-8",
    )
    live = {
        "schema": "keeper-enterprise.v1",
        "nodes": [{"uid_ref": "node.root", "keeper_uid": "1", "name": "Root"}],
        "users": [
            {
                "uid_ref": "user.alice",
                "keeper_uid": "2",
                "email": "alice@example.com",
                "node_uid_ref": "keeper-enterprise:nodes:node.root",
                "status": "active",
            }
        ],
        "roles": [],
        "teams": [],
        "enforcements": [],
        "aliases": [],
    }
    fake = MagicMock()
    fake.discover_enterprise.return_value = live
    monkeypatch.setattr(cli_main_module, "CommanderCliProvider", lambda **kw: fake)

    result = _run(["--provider", "commander", "validate", str(manifest), "--online", "--json"])

    assert result.exit_code == 0, result.output
    data = json.loads(result.output.strip())
    assert data["mode"] == "enterprise_online"
    assert data["online"] is True
    assert data["live_enterprise_object_count"] == 2
    assert data["stage5_summary"]["noop"] == 2


def test_plan_vault_mock_creates(tmp_path: Path) -> None:
    p = tmp_path / "vault-one.yaml"
    p.write_text(
        "schema: keeper-vault.v1\n"
        "records:\n"
        "  - uid_ref: cli.v.login\n"
        "    type: login\n"
        "    title: CLI Vault Login\n",
        encoding="utf-8",
    )
    result = _run(["--provider", "mock", "plan", str(p)])
    assert result.exit_code == EXIT_CHANGES, result.output
    assert "create" in result.output


def test_import_rejects_vault(tmp_path: Path) -> None:
    p = tmp_path / "vault.yaml"
    p.write_text("schema: keeper-vault.v1\nrecords: []\n", encoding="utf-8")
    result = _run(["import", str(p)])
    assert result.exit_code == EXIT_CAPABILITY
    assert "capability error" in result.output
    assert "pam-environment" in result.output


def test_validate_rejects_missing_ref(invalid_manifest) -> None:
    path = invalid_manifest("missing-ref.yaml")
    result = _run(["validate", str(path)])
    assert result.exit_code == EXIT_REF


def test_validate_rejects_schema(invalid_manifest) -> None:
    path = invalid_manifest("rbi-rotation-on.yaml")
    result = _run(["validate", str(path)])
    assert result.exit_code == EXIT_SCHEMA


def test_validate_rejects_capability(invalid_manifest) -> None:
    path = invalid_manifest("gateway-create-in-unsupported-env.yaml")
    result = _run(["validate", str(path)])
    assert result.exit_code == EXIT_CAPABILITY


def test_validate_online_passes_with_mock_provider(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    provider.seed(
        [
            LiveRecord(
                keeper_uid="LIVE_GW_UID",
                title="Acme Lab Gateway",
                resource_type="gateway",
                payload={"name": "Acme Lab Gateway"},
                marker=None,
            )
        ]
    )

    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["validate", str(minimal_manifest_path), "--online"])
    assert result.exit_code == 0, result.output
    assert "online:" in result.output


def test_validate_online_warns_on_missing_gateway(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)

    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["validate", str(minimal_manifest_path), "--online"])
    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "stage 4" in result.output


def test_validate_online_fails_on_provider_capability_gap(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)

    class GapProvider(MockProvider):
        def unsupported_capabilities(self, manifest=None) -> list[str]:
            return ["rotation_settings requires pam rotation edit"]

    provider = GapProvider(manifest.name)
    provider.seed(
        [
            LiveRecord(
                keeper_uid="LIVE_GW_UID",
                title="Acme Lab Gateway",
                resource_type="gateway",
                payload={"name": "Acme Lab Gateway"},
                marker=None,
            )
        ]
    )

    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["validate", str(minimal_manifest_path), "--online"])
    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "capability gaps" in result.output
    assert "rotation_settings requires pam rotation edit" in result.output


def test_validate_without_online_unchanged(minimal_manifest_path: Path) -> None:
    result = _run(["validate", str(minimal_manifest_path)])
    assert result.exit_code == 0, result.output
    assert "online" not in result.output
    assert "stage" not in result.output


@pytest.mark.parametrize(
    ("scenario", "expected_exit"),
    [
        ("clean", 0),
        ("changes", EXIT_CHANGES),
        ("conflict", EXIT_CONFLICT),
    ],
)
def test_plan_emits_json_exit_codes(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    scenario: str,
    expected_exit: int,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)

    if scenario == "clean":
        graph = build_graph(manifest)
        order = execution_order(graph)
        provider.apply_plan(
            build_plan(manifest.name, compute_diff(manifest, provider.discover()), order)
        )
    elif scenario == "conflict":
        provider.seed(
            [
                LiveRecord(
                    keeper_uid="LIVE_UID",
                    title="lab-linux-1",
                    resource_type="pamMachine",
                    marker={
                        **encode_marker(
                            uid_ref="acme-lab-linux1",
                            manifest=manifest.name,
                            resource_type="pamMachine",
                        ),
                        "manager": "someone-else",
                    },
                    payload={"title": "lab-linux-1"},
                )
            ]
        )

    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["plan", str(minimal_manifest_path), "--json"])
    assert result.exit_code == expected_exit, result.output
    doc = json.loads(result.output)
    assert doc["manifest_name"] == "acme-lab-minimal"
    if scenario == "clean":
        assert doc["summary"] == {"create": 0, "update": 0, "delete": 0, "conflict": 0, "noop": 3}
    elif scenario == "changes":
        assert doc["summary"]["create"] >= 1
        assert doc["summary"]["conflict"] == 0
    else:
        assert doc["summary"]["conflict"] >= 1


def test_apply_auto_approve(minimal_manifest_path: Path) -> None:
    result = _run(["apply", str(minimal_manifest_path), "--auto-approve"])
    assert result.exit_code == 0, result.output
    assert "create" in result.output.lower()


@pytest.mark.parametrize(
    ("seed_clean", "expected_exit"),
    [
        (False, EXIT_CHANGES),
        (True, 0),
    ],
)
def test_apply_dry_run_equivalent_to_plan(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    seed_clean: bool,
    expected_exit: int,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)

    if seed_clean:
        graph = build_graph(manifest)
        order = execution_order(graph)
        provider.apply_plan(
            build_plan(manifest.name, compute_diff(manifest, provider.discover()), order)
        )

    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result_plan = _run(["plan", str(minimal_manifest_path)])
    assert result_plan.exit_code == expected_exit, result_plan.output

    result_apply = _run(["apply", str(minimal_manifest_path), "--dry-run"])
    assert result_apply.exit_code == expected_exit, result_apply.output
    assert result_plan.output == result_apply.output


def test_apply_dry_run_vault_summary_equivalent_to_plan(tmp_path: Path) -> None:
    manifest_path = tmp_path / "vault-one.yaml"
    manifest_path.write_text(
        "schema: keeper-vault.v1\n"
        "records:\n"
        "  - uid_ref: cli.v.login\n"
        "    type: login\n"
        "    title: CLI Vault Login\n",
        encoding="utf-8",
    )

    result_plan = _run(["plan", str(manifest_path)])
    result_apply = _run(["apply", str(manifest_path), "--dry-run"])

    assert result_plan.exit_code == EXIT_CHANGES, result_plan.output
    assert result_apply.exit_code == EXIT_CHANGES, result_apply.output
    assert _plan_summary_line(result_apply.output) == _plan_summary_line(result_plan.output)


def _plan_summary_line(output: str) -> str:
    return next(
        line.strip()
        for line in output.splitlines()
        if " create," in line and " update," in line and " conflict," in line
    )


def test_import_adopts_unmanaged_title_match(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    provider.seed(
        [
            LiveRecord(
                keeper_uid="LIVE_UID",
                title="lab-linux-1",
                resource_type="pamMachine",
                payload={"title": "lab-linux-1", "host": "10.16.9.10"},
                marker=None,
            )
        ]
    )

    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["import", str(minimal_manifest_path), "--auto-approve"])
    assert result.exit_code == 0, result.output

    adopted = next(record for record in provider.discover() if record.keeper_uid == "LIVE_UID")
    assert adopted.marker is not None
    assert adopted.marker["uid_ref"] == "acme-lab-linux1"
    assert adopted.marker["manifest"] == manifest.name


def test_import_noop_when_nothing_to_adopt(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    graph = build_graph(manifest)
    order = execution_order(graph)
    provider.apply_plan(
        build_plan(manifest.name, compute_diff(manifest, provider.discover()), order)
    )

    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["import", str(minimal_manifest_path), "--auto-approve"])
    assert result.exit_code == 0, result.output
    assert "no records to adopt." in result.output


def test_import_dry_run_does_not_mutate(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    provider.seed(
        [
            LiveRecord(
                keeper_uid="LIVE_UID",
                title="lab-linux-1",
                resource_type="pamMachine",
                payload={"title": "lab-linux-1", "host": "10.16.9.10"},
                marker=None,
            )
        ]
    )

    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["import", str(minimal_manifest_path), "--dry-run"])
    assert result.exit_code == 0, result.output

    live = next(record for record in provider.discover() if record.keeper_uid == "LIVE_UID")
    assert live.marker is None


def test_report_password_report_emits_envelope(monkeypatch: pytest.MonkeyPatch) -> None:
    sample = [{"record_uid": "AbCdEfGhIjKlMnOpQrSt", "title": "svc", "length": 8}]

    def _fake_batch(*_a: object, **_k: object) -> str:
        return json.dumps(sample)

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", _fake_batch)

    result = _run(["report", "password-report", "--policy", "8,0,0,0,0"])
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert payload["command"] == "password-report"
    assert payload["dsk_report_version"] == 1
    assert payload["rows"] == sample


def test_report_password_report_quiet_fingerprints_uid(monkeypatch: pytest.MonkeyPatch) -> None:
    uid = "AbCdEfGhIjKlMnOpQrSt"
    sample = [{"record_uid": uid, "title": "svc", "length": 8}]

    def _fake_batch(*_a: object, **_k: object) -> str:
        return json.dumps(sample)

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", _fake_batch)

    result = _run(["report", "password-report", "--policy", "8,0,0,0,0", "--quiet"])
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert payload["rows"][0]["record_uid"] != uid
    assert payload["rows"][0]["record_uid"].startswith("<uid:")


def test_report_compliance_report_emits_envelope(monkeypatch: pytest.MonkeyPatch) -> None:
    sample = [{"record_uid": "ZzYyXxWwVvUuTtSsRrQq", "title": "row1"}]

    def _fake_batch(*_a: object, **_k: object) -> str:
        return json.dumps(sample)

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", _fake_batch)

    result = _run(["report", "compliance-report", "--quiet"])
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert payload["command"] == "compliance-report"
    assert payload["rows"][0]["record_uid"] != sample[0]["record_uid"]


def test_report_security_audit_report_emits_envelope(monkeypatch: pytest.MonkeyPatch) -> None:
    sample = [{"email": "a@example.com", "weak": 1}]

    def _fake_batch(*_a: object, **_k: object) -> str:
        return json.dumps(sample)

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", _fake_batch)

    result = _run(["report", "security-audit-report", "--node", "n1", "--force"])
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert payload["command"] == "security-audit-report"
    assert payload["meta"]["nodes"] == ["n1"]
    assert payload["rows"] == sample


def test_report_password_report_scrubs_secret_dict_keys(monkeypatch: pytest.MonkeyPatch) -> None:
    sample = [{"record_uid": "ab", "title": "svc", "token": "should-not-appear"}]

    def _fake_batch(*_a: object, **_k: object) -> str:
        return json.dumps(sample)

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", _fake_batch)

    result = _run(["report", "password-report", "--policy", "8,0,0,0,0"])
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    row = payload["rows"][0]
    assert row.get("token") == "<redacted>"
    assert row.get("title") == "svc"


def test_report_password_report_refuses_when_output_echoes_env_password(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    secret = "UniqueKeeperPassPhraseForLeakTest99"
    monkeypatch.setenv("KEEPER_PASSWORD", secret)

    def _fake_batch(*_a: object, **_k: object) -> str:
        return json.dumps([{"record_uid": "ab", "title": secret}])

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", _fake_batch)

    result = _run(["report", "password-report", "--policy", "8,0,0,0,0"])
    assert result.exit_code == EXIT_GENERIC, result.output
    assert "refused" in result.output.lower() or "leak" in result.output.lower()
