"""Tests for MCP secrets binding models."""

from __future__ import annotations

from pathlib import Path

import yaml

from dsk.core.models_mcp import (
    McpCredentialSlot,
    McpSecretsBindingManifestV1,
    McpSecretSource,
    McpServerBinding,
    McpServerCredential,
)

REPO_ROOT = Path(__file__).resolve().parents[1]


def test_mcp_server_defaults() -> None:
    binding = McpServerBinding(
        name="test-server",
        mcp_server_id="test",
    )
    assert binding.audit_log is True
    assert binding.alert_on_hardcoded is True
    assert binding.credentials == []


def test_mcp_manifest_round_trip() -> None:
    example = REPO_ROOT / "examples" / "mcp" / "acme-mcp-secrets.yaml"
    data = yaml.safe_load(example.read_text(encoding="utf-8"))
    manifest = McpSecretsBindingManifestV1(**data)
    assert manifest.schema_ == "mcp-secrets-binding.v1"
    assert len(manifest.servers) == 3
    openai = manifest.servers[0]
    assert openai.credentials[0].slot == McpCredentialSlot.api_key
    assert openai.credentials[0].source == McpSecretSource.ksm
    assert openai.credentials[0].inject_as_env == "OPENAI_API_KEY"


def test_mcp_credential_defaults() -> None:
    cred = McpServerCredential(label="test-key", uid_ref="ksm.test")
    assert cred.slot == McpCredentialSlot.api_key
    assert cred.field_name == "password"
    assert cred.inject_as_env is None


def test_mcp_secrets_sha256_pin() -> None:
    binding = McpServerBinding(
        name="pinned",
        mcp_server_id="secure-mcp",
        sha256_pin="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        package_registry="npm",
    )
    assert binding.sha256_pin is not None
    assert binding.package_registry == "npm"


def test_mcp_schema_alias() -> None:
    m = McpSecretsBindingManifestV1(**{"schema": "mcp-secrets-binding.v1", "name": "test"})
    assert m.schema_ == "mcp-secrets-binding.v1"
