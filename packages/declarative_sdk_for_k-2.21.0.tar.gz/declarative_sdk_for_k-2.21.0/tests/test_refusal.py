from dsk.core.refusal import (
    DEFAULT_PREDICATES,
    RefusalRunner,
    refuse_env_var_secret,
    refuse_missing_class,
    refuse_pre_compromised,
    refuse_shared_credential,
    refuse_unrotated_age,
    refuse_wildcard_scope,
)


def test_refuse_shared_credential_detects_reused_uid_ref() -> None:
    doc = {
        "resources": [
            {"uid_ref": "res.one", "users": [{"uid_ref": "user.shared"}]},
            {"uid_ref": "res.two", "users": [{"uid_ref": "user.shared"}]},
        ]
    }

    violations = refuse_shared_credential(doc)

    assert len(violations) == 1
    assert violations[0].uid_ref == "user.shared"
    assert violations[0].severity == "error"


def test_refuse_shared_credential_accepts_unique_uid_refs() -> None:
    doc = {
        "resources": [
            {"uid_ref": "res.one", "users": [{"uid_ref": "user.one"}]},
            {"uid_ref": "res.two", "users": [{"uid_ref": "user.two"}]},
        ]
    }

    assert refuse_shared_credential(doc) == []


def test_refuse_wildcard_scope_detects_otp_wildcard() -> None:
    violations = refuse_wildcard_scope({"resources": [{"uid_ref": "res.db", "otp": "*"}]})

    assert len(violations) == 1
    assert violations[0].severity == "error"


def test_refuse_wildcard_scope_accepts_clean_resource() -> None:
    doc = {
        "resources": [
            {
                "uid_ref": "res.db",
                "otp": "123456",
                "pam_settings": {"options": {"scope": "readonly"}},
            }
        ]
    }

    assert refuse_wildcard_scope(doc) == []


def test_refuse_unrotated_age_detects_missing_rotation_settings() -> None:
    doc = {"resources": [{"uid_ref": "res.db", "users": [{"uid_ref": "user.db"}]}]}

    violations = refuse_unrotated_age(doc)

    assert len(violations) == 1
    assert violations[0].severity == "warning"


def test_refuse_unrotated_age_accepts_enabled_rotation() -> None:
    doc = {
        "resources": [
            {
                "uid_ref": "res.db",
                "users": [{"uid_ref": "user.db", "rotation_settings": {"enabled": "on"}}],
            }
        ]
    }

    assert refuse_unrotated_age(doc) == []


def test_refuse_pre_compromised_detects_breach_marker_notes() -> None:
    doc = {"resources": [{"uid_ref": "res.db", "notes": "This record was breached 2024-01"}]}

    violations = refuse_pre_compromised(doc)

    assert len(violations) == 1
    assert violations[0].severity == "error"


def test_refuse_pre_compromised_accepts_clean_notes() -> None:
    doc = {"resources": [{"uid_ref": "res.db", "notes": "standard database account"}]}

    assert refuse_pre_compromised(doc) == []


def test_refuse_env_var_secret_detects_otp_env_var() -> None:
    violations = refuse_env_var_secret(
        {"resources": [{"uid_ref": "res.db", "otp": "${DB_PASSWORD}"}]}
    )

    assert len(violations) == 1
    assert violations[0].severity == "warning"


def test_refuse_env_var_secret_accepts_literal_secret() -> None:
    doc = {"resources": [{"uid_ref": "res.db", "otp": "real-secret-xyz"}]}

    assert refuse_env_var_secret(doc) == []


def test_refuse_missing_class_required_reports_info() -> None:
    violations = refuse_missing_class({"resources": [{"uid_ref": "res.db"}]}, required=True)

    assert len(violations) == 1
    assert violations[0].severity == "info"


def test_refuse_missing_class_not_required_is_clean() -> None:
    violations = refuse_missing_class({"resources": [{"uid_ref": "res.db"}]}, required=False)

    assert violations == []


def test_refusal_runner_default_predicates_clean_minimal_doc() -> None:
    doc = {
        "resources": [
            {
                "uid_ref": "res.db",
                "otp": "123456",
                "title": "prod db",
                "notes": "clean",
                "pam_settings": {"options": {"scope": "readonly"}},
                "users": [{"uid_ref": "user.db", "rotation_settings": {"enabled": "on"}}],
            }
        ]
    }

    assert RefusalRunner(DEFAULT_PREDICATES).check(doc) == []


def test_refusal_runner_collects_multiple_violations() -> None:
    doc = {
        "resources": [
            {
                "uid_ref": "res.one",
                "notes": "breached in old corpus",
                "users": [{"uid_ref": "user.shared"}],
            },
            {
                "uid_ref": "res.two",
                "otp": "*",
                "title": "${DB_PASSWORD}",
                "users": [{"uid_ref": "user.shared", "rotation_settings": {"enabled": "on"}}],
            },
        ]
    }

    violations = RefusalRunner(DEFAULT_PREDICATES).check(doc)

    assert len(violations) == 5
