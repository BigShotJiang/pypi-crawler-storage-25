"""Tests for `dsk diff` CLI command."""

from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from dsk.cli.main import EXIT_CHANGES, main


def _run(args: list[str]):
    return CliRunner().invoke(main, args, catch_exceptions=False)


def _write_vault_manifest(tmp_path: Path, uid_ref: str = "vault.login.x") -> Path:
    path = tmp_path / "vault.yaml"
    path.write_text(
        f"""
schema: keeper-vault.v1
records:
  - uid_ref: {uid_ref}
    type: login
    title: Example Login
    fields:
      - type: login
        label: Username
        value: ["alice@example.com"]
""",
        encoding="utf-8",
    )
    return path


def _write_pam_manifest(tmp_path: Path) -> Path:
    path = tmp_path / "pam.yaml"
    path.write_text(
        """
schema: pam-environment.v1
version: "1"
name: diff-test
gateways:
  - uid_ref: gw.test
    name: test-gw
    mode: reference_existing
pam_configurations:
  - uid_ref: cfg.test
    environment: local
    title: Test Config
    gateway_uid_ref: gw.test
""",
        encoding="utf-8",
    )
    return path


def test_diff_vault_shows_create_section(tmp_path: Path) -> None:
    path = _write_vault_manifest(tmp_path)
    result = _run(["diff", str(path)])

    assert result.exit_code == EXIT_CHANGES
    assert "create" in result.output.lower()
    assert "Example Login" in result.output


def test_diff_vault_includes_after_content(tmp_path: Path) -> None:
    path = _write_vault_manifest(tmp_path)
    result = _run(["diff", str(path)])

    assert "vault.login.x" in result.output
    assert "alice@example.com" in result.output


def test_diff_pam_shows_pam_configuration_create(tmp_path: Path) -> None:
    path = _write_pam_manifest(tmp_path)
    result = _run(["diff", str(path)])

    assert result.exit_code == EXIT_CHANGES
    assert "pam_configuration" in result.output or "Test Config" in result.output


def test_diff_exits_two_when_changes_exist(tmp_path: Path) -> None:
    """Exit 2 (EXIT_CHANGES) is expected when new records need creation."""
    path = _write_vault_manifest(tmp_path)
    result = _run(["diff", str(path)])

    assert result.exit_code == EXIT_CHANGES


def test_diff_output_is_human_readable(tmp_path: Path) -> None:
    """Diff output must not be raw JSON — it's rendered text."""
    path = _write_vault_manifest(tmp_path)
    result = _run(["diff", str(path)])

    assert "{" not in result.output[:50]
    assert "Diff for" in result.output


def test_diff_nhi_manifest_shows_create(tmp_path: Path) -> None:
    path = tmp_path / "nhi.yaml"
    path.write_text(
        """
schema: nhi-agent.v1
resources:
  - uid_ref: nhi.svc.diff
    name: diff-bot
    type: service_account
    purpose: test diff command
""",
        encoding="utf-8",
    )
    result = _run(["diff", str(path)])

    assert result.exit_code == EXIT_CHANGES
    assert "create" in result.output.lower()
