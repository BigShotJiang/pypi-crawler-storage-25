"""mcp-server-allowlist.v1 offline schema, model, and round-trip tests."""

from __future__ import annotations

import json
from typing import Any

import pytest
import yaml

from dsk.core.errors import SchemaError
from dsk.core.manifest import load_declarative_manifest_string
from dsk.core.models_mcp_allowlist import (
    MCP_ALLOWLIST_FAMILY,
    McpAllowlistManifest,
    load_mcp_allowlist_manifest,
)
from dsk.core.schema import load_schema_for_family, validate_manifest


def _mcp_minimal() -> dict[str, Any]:
    return {
        "schema": MCP_ALLOWLIST_FAMILY,
        "name": "minimal-allowlist",
        "servers": [
            {
                "uid_ref": "mcp.one",
                "name": "One",
                "server_uri": "npx @scope/minimal",
                "transport": "stdio",
            }
        ],
    }


def _mcp_full() -> dict[str, Any]:
    return {
        "schema": MCP_ALLOWLIST_FAMILY,
        "name": "full-allowlist",
        "servers": [
            {
                "uid_ref": "mcp.full-a",
                "name": "Full Entry A",
                "server_uri": "https://mcp.example.com/sse",
                "transport": "sse",
                "sha256_pin": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "version_constraint": ">=1.0.0,<3.0.0",
                "approved_by": "sec-team",
                "approved_at": "2026-05-01",
                "allowed_agents": ["nhi.agent-one", "nhi.agent-two"],
                "allowed_tools": ["tool_a", "tool_b"],
                "credential_ref": "keeper-ksm:apps:mcp-app",
                "risk_level": "high",
                "tags": {"env": "prod"},
            },
            {
                "uid_ref": "mcp.full-b",
                "name": "Full Entry B",
                "server_uri": "npx @corp/other-mcp",
                "transport": "stdio",
                "risk_level": "low",
                "allowed_agents": [],
                "allowed_tools": [],
                "tags": {},
            },
        ],
    }


def test_mcp_schema_is_packaged() -> None:
    schema = load_schema_for_family(MCP_ALLOWLIST_FAMILY)

    assert schema["title"] == MCP_ALLOWLIST_FAMILY
    assert "servers" in schema["properties"]
    assert schema["x-keeper-live-proof"]["status"] == "upstream-gap"


def test_mcp_validate_minimal() -> None:
    assert validate_manifest(_mcp_minimal()) == MCP_ALLOWLIST_FAMILY


def test_mcp_validate_full() -> None:
    assert validate_manifest(_mcp_full()) == MCP_ALLOWLIST_FAMILY


def test_mcp_missing_required_manifest_name() -> None:
    doc = _mcp_minimal()
    del doc["name"]

    with pytest.raises(SchemaError):
        validate_manifest(doc)


def test_mcp_missing_required_server_uri() -> None:
    doc = _mcp_minimal()
    del doc["servers"][0]["server_uri"]

    with pytest.raises(SchemaError):
        validate_manifest(doc)


def test_mcp_invalid_transport() -> None:
    doc = _mcp_minimal()
    doc["servers"][0]["transport"] = "grpc"

    with pytest.raises(SchemaError) as exc:
        validate_manifest(doc)

    assert "not one of" in exc.value.reason or "not valid" in exc.value.reason.lower()


def test_mcp_load_returns_typed_model() -> None:
    loaded = load_declarative_manifest_string(
        json.dumps(_mcp_full()),
        suffix=".json",
    )

    assert isinstance(loaded, McpAllowlistManifest)
    assert loaded.servers[0].uid_ref == "mcp.full-a"
    assert loaded.servers[0].transport == "sse"


def test_mcp_manifest_roundtrip_yaml() -> None:
    manifest = load_mcp_allowlist_manifest(_mcp_full())
    dumped = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    yaml_out = yaml.safe_dump(dumped, sort_keys=False, allow_unicode=True)
    reloaded = load_declarative_manifest_string(yaml_out, suffix=".yaml")

    assert isinstance(reloaded, McpAllowlistManifest)
    assert reloaded.model_dump(mode="json", exclude_none=True, by_alias=True) == dumped


def test_mcp_rejects_duplicate_uid_refs() -> None:
    doc = _mcp_minimal()
    doc["servers"].append(
        {
            "uid_ref": "mcp.one",
            "name": "Duplicate",
            "server_uri": "npx @dup/pkg",
            "transport": "http",
        }
    )

    with pytest.raises(SchemaError) as exc:
        load_mcp_allowlist_manifest(doc)

    assert "duplicate uid_ref" in exc.value.reason


def test_mcp_wrong_family_rejected() -> None:
    doc = {"schema": "ai-agent.v1"}

    with pytest.raises(SchemaError) as exc:
        load_mcp_allowlist_manifest(doc)

    assert "mcp-server-allowlist.v1" in exc.value.reason
