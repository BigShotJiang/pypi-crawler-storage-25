"""Regression tests for declarative apply-order graph APIs (Lurey #4).

Each API gets a small deterministic fixture (≥3 nodes, ≥2 edges where the
graph layer emits edges). Assertions cover permutation validity, topological
ordering relative to dependency edges, and repeatability.
"""

from __future__ import annotations

import networkx as nx
import pytest

from dsk.core.errors import RefError
from dsk.core.graph import execution_order
from dsk.core.msp_graph import build_msp_graph, msp_apply_order
from dsk.core.msp_models import ManagedCompany, MspManifestV1
from dsk.core.sharing_graph import build_sharing_graph, sharing_apply_order
from dsk.core.sharing_models import SharingFolder, SharingManifestV1
from dsk.core.vault_graph import (
    VAULT_FOLDER_NODE_PREFIX,
    build_vault_graph,
    vault_record_apply_order,
)
from dsk.core.vault_models import VaultManifestV1, VaultRecord


def _assert_topo_respects_dependencies(order: list[str], graph: nx.DiGraph) -> None:
    """Edges follow convention dependent → dependency; prerequisites appear earlier."""
    pos = {n: i for i, n in enumerate(order)}
    assert set(order) == set(graph.nodes), "order must be a permutation of graph nodes"
    for dependent, dependency in graph.edges():
        assert pos[dependency] < pos[dependent], (
            f"edge {dependent}→{dependency}: dependency must precede dependent"
        )


def test_execution_order_linear_chain_matches_expected_sequence() -> None:
    """Three-node chain: leaf ← mid ← root (each node depends on the previous)."""
    graph = nx.DiGraph()
    graph.add_node("leaf")
    graph.add_node("mid")
    graph.add_node("root")
    graph.add_edge("mid", "leaf")
    graph.add_edge("root", "mid")

    expected = ["leaf", "mid", "root"]
    first = execution_order(graph)
    second = execution_order(graph)

    assert first == expected == second
    _assert_topo_respects_dependencies(first, graph)


def test_execution_order_cycle_raises_ref_error() -> None:
    graph = nx.DiGraph()
    graph.add_edge("a", "b")
    graph.add_edge("b", "c")
    graph.add_edge("c", "a")

    with pytest.raises(RefError) as excinfo:
        execution_order(graph)

    assert "dependency cycle" in str(excinfo.value.reason)


def test_msp_apply_order_is_sorted_and_topologically_valid() -> None:
    """Slice-1 MSP graph has no edges; order is deterministic alphabetical by MC name."""
    manifest = MspManifestV1(
        name="msp-order-test",
        managed_companies=[
            ManagedCompany(name="Zeta", plan="enterprise", seats=1),
            ManagedCompany(name="alpha", plan="enterprise", seats=2),
            ManagedCompany(name="Beta", plan="enterprise", seats=3),
        ],
    )

    graph = build_msp_graph(manifest)
    expected = ["Beta", "Zeta", "alpha"]

    first = msp_apply_order(manifest)
    second = msp_apply_order(manifest)

    assert first == expected == second
    assert first == sorted(graph.nodes())
    _assert_topo_respects_dependencies(first, graph)


def test_sharing_apply_order_folder_chain_matches_expected_sequence() -> None:
    """Nested folders: child depends on parent via ``parent_folder_uid_ref``."""
    manifest = SharingManifestV1(
        folders=[
            SharingFolder(uid_ref="foldA", path="/a"),
            SharingFolder(
                uid_ref="foldB",
                path="/b",
                parent_folder_uid_ref="keeper-vault-sharing:folders:foldA",
            ),
            SharingFolder(
                uid_ref="foldC",
                path="/c",
                parent_folder_uid_ref="keeper-vault-sharing:folders:foldB",
            ),
        ]
    )
    graph = build_sharing_graph(manifest)
    expected = ["foldA", "foldB", "foldC"]

    first = sharing_apply_order(manifest)
    second = sharing_apply_order(manifest)

    assert first == expected == second
    _assert_topo_respects_dependencies(first, graph)


def test_sharing_apply_order_cycle_raises_ref_error() -> None:
    manifest = SharingManifestV1(
        folders=[
            SharingFolder(
                uid_ref="foldA",
                path="/a",
                parent_folder_uid_ref="keeper-vault-sharing:folders:foldB",
            ),
            SharingFolder(
                uid_ref="foldB",
                path="/b",
                parent_folder_uid_ref="keeper-vault-sharing:folders:foldA",
            ),
        ]
    )

    with pytest.raises(RefError) as excinfo:
        sharing_apply_order(manifest)

    assert "dependency cycle" in str(excinfo.value.reason)


def test_vault_record_apply_order_matches_full_topo_minus_synthetic_folders() -> None:
    """Records depend on synthetic folder nodes; record-only slice preserves full topo order."""
    manifest = VaultManifestV1(
        records=[
            VaultRecord(
                uid_ref="recZ",
                type="login",
                title="z",
                folder_ref="keeper-vault-sharing:folders:fz",
            ),
            VaultRecord(
                uid_ref="recY",
                type="login",
                title="y",
                folder_ref="keeper-vault-sharing:folders:fy",
            ),
            VaultRecord(
                uid_ref="recX",
                type="login",
                title="x",
                folder_ref="keeper-vault-sharing:folders:fx",
            ),
        ]
    )
    graph = build_vault_graph(manifest)
    full_order = execution_order(graph)
    expected_records = [n for n in full_order if not n.startswith(VAULT_FOLDER_NODE_PREFIX)]

    first = vault_record_apply_order(manifest)
    second = vault_record_apply_order(manifest)

    assert first == expected_records == second
    assert set(first) == {r.uid_ref for r in manifest.records}
    _assert_topo_respects_dependencies(full_order, graph)
