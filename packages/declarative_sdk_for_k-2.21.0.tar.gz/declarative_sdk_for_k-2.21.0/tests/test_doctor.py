"""Tests for `dsk doctor` CLI command."""

from __future__ import annotations

import os

from click.testing import CliRunner

from dsk.cli.main import EXIT_OK, main


def _run(env: dict[str, str] | None = None):
    runner = CliRunner(env=env)
    return runner.invoke(main, ["doctor"], catch_exceptions=False)


def test_doctor_exits_zero_on_supported_python():
    """On Python >=3.11 (CI always uses >=3.11) doctor must return EXIT_OK."""
    result = _run()
    assert result.exit_code == EXIT_OK


def test_doctor_output_contains_python_version():
    result = _run()
    assert "Python" in result.output or "python" in result.output


def test_doctor_output_contains_status_column():
    """Output must have ok or fail status indicators."""
    result = _run()
    assert "ok" in result.output or "fail" in result.output or "unknown" in result.output


def test_doctor_mentions_keeper_email_env():
    result = _run(env={})
    assert "KEEPER_EMAIL" in result.output


def test_doctor_shows_set_when_keeper_email_provided():
    result = _run(env={"KEEPER_EMAIL": "test@example.com"})
    assert "✓" in result.output or "set" in result.output.lower()


def test_doctor_shows_dsk_preview_off_when_not_set():
    env_without_preview = {k: v for k, v in os.environ.items() if k != "DSK_PREVIEW"}
    runner = CliRunner(env={**env_without_preview, "DSK_PREVIEW": ""})
    result = runner.invoke(main, ["doctor"], catch_exceptions=False)
    assert "DSK_PREVIEW" in result.output
    assert "off" in result.output.lower() or "○" in result.output


def test_doctor_shows_dsk_preview_on_when_set():
    result = _run(env={"DSK_PREVIEW": "1"})
    assert "DSK_PREVIEW" in result.output
    assert "on" in result.output.lower() or "✓" in result.output
