"""R23 — Pinning tests for red-team Scenarios 02 and 03.

Scenario 02: manifest.csv tamper between keeper-migrate and dsk import-from-keepercmd.
    keeperCMD scenario: keeper_tenant_migrate/tests/red_team/scenarios/02-...md
    DSK defence gate: audit.log chain verification + SHA256SUMS integrity check.

Scenario 03: ownership-marker forgery before dsk import-from-keepercmd.
    keeperCMD scenario: keeper_tenant_migrate/tests/red_team/scenarios/03-...md
    DSK defence gate: manifest.csv cross-reference — a record with a
    keeper_declarative_manager custom field in records-export but no paired CSV row
    must be flagged SUSPECT and not adopted.

These tests are intentionally kept *offline* (no live Commander session).
They exercise the CLI surface via CliRunner against local tmp_path run-dirs.

Status: 🟡 → 🟢 once `dsk import-from-keepercmd` lands (Phase 4-B, B1).
"""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Any

from click.testing import CliRunner

from keeper_sdk.cli import main

# ---------------------------------------------------------------------------
# Helpers — build a valid keeperCMD run-dir fixture
# ---------------------------------------------------------------------------

_SOURCE_UID = "A" * 22
_TARGET_UID = "B" * 22
_ORPHAN_TARGET_UID = "C" * 22  # has marker in records-export but no CSV pair


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _make_audit_event(prev_hash: str, subcommand: str, summary: dict[str, Any]) -> tuple[str, str]:
    """Return (json_line, next_prev_hash)."""
    event: dict[str, Any] = {
        "subcommand": subcommand,
        "inputs": {"input_hash": _sha256(b"inputs")},
        "outputs": {"output_hash": _sha256(b"outputs")},
        "summary": summary,
        "tenant": "test-tenant",
        "operator_email": "operator@test.com",
        "timestamp": "2026-05-08T18:30:00Z",
        "prev_hash": prev_hash,
    }
    sig = _sha256(json.dumps(event, sort_keys=True).encode())
    event["signature"] = sig
    line = json.dumps(event)
    return line, _sha256(line.encode())


def _write_valid_run_dir(
    run_dir: Path,
    *,
    extra_records_export: list[dict[str, Any]] | None = None,
    extra_csv_rows: list[dict[str, str]] | None = None,
) -> Path:
    """Populate a minimal valid keeperCMD run-dir.

    Contains one paired record (_SOURCE_UID → _TARGET_UID) plus any extras
    supplied by the caller.
    """
    run_dir.mkdir(parents=True, exist_ok=True)
    records_dir = run_dir / "records-export"
    records_dir.mkdir()

    # --- inventory.json ---
    inventory = {
        "schema_version": "1.0",
        "captured_at": "2026-05-08T18:30:00Z",
        "source_tenant": {"name": "acme-src", "region": "EU", "captured_by_user": "op@test.com"},
        "scope": {"node_path": "MIGTEST", "prefix": "MT-"},
        "entities": {
            "nodes": [],
            "teams": [],
            "roles": [],
            "shared_folders": [],
            "records": [
                {
                    "uid": _TARGET_UID,
                    "title": "MT-login-record",
                    "type": "login",
                    "folder_uid": None,
                },
            ],
            "users": [],
        },
    }
    (run_dir / "inventory.json").write_text(json.dumps(inventory, indent=2), encoding="utf-8")

    # --- records-export/<source_uid>.json ---
    source_record: dict[str, Any] = {
        "uid": _SOURCE_UID,
        "title": "MT-login-record",
        "type": "login",
        "version": 3,
        "fields": [
            {"type": "login", "value": ["alice@acme.com"]},
            {"type": "password", "value": ["hunter2"]},
        ],
        "custom": [],
        "notes": "",
        "files": [],
    }
    record_file = records_dir / f"{_SOURCE_UID}.json"
    record_bytes = json.dumps(source_record, indent=2).encode()
    record_file.write_bytes(record_bytes)

    if extra_records_export:
        for rec in extra_records_export:
            uid = rec["uid"]
            (records_dir / f"{uid}.json").write_text(json.dumps(rec, indent=2), encoding="utf-8")

    # --- SHA256SUMS.txt ---
    sha_lines = [f"{_sha256(record_bytes)}  records-export/{_SOURCE_UID}.json"]
    if extra_records_export:
        for rec in extra_records_export:
            uid = rec["uid"]
            content = (records_dir / f"{uid}.json").read_bytes()
            sha_lines.append(f"{_sha256(content)}  records-export/{uid}.json")
    (run_dir / "SHA256SUMS.txt").write_text("\n".join(sha_lines) + "\n", encoding="utf-8")

    # --- manifest.csv ---
    csv_rows = [
        {
            "source_uid": _SOURCE_UID,
            "target_uid": _TARGET_UID,
            "title": "MT-login-record",
            "type": "login",
            "status": "paired",
            "timestamp": "2026-05-08T18:30:00Z",
        }
    ]
    if extra_csv_rows:
        csv_rows.extend(extra_csv_rows)
    _write_csv(run_dir / "manifest.csv", csv_rows)

    # --- audit.log (valid hash chain) ---
    prev_hash = ""
    audit_lines = []
    for subcommand, summary in [
        ("records-import", {"created": 1, "skipped": 0, "errors": 0}),
        ("records-attachments", {"created": 1, "skipped": 0, "errors": 0}),
    ]:
        line, prev_hash = _make_audit_event(prev_hash, subcommand, summary)
        audit_lines.append(line)
    (run_dir / "audit.log").write_text("\n".join(audit_lines) + "\n", encoding="utf-8")

    return run_dir


def _write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["source_uid", "target_uid", "title", "type", "status", "timestamp"],
        )
        writer.writeheader()
        writer.writerows(rows)


def _run(*args: str) -> Any:
    runner = CliRunner()
    return runner.invoke(main, list(args), catch_exceptions=False)


# ---------------------------------------------------------------------------
# Scenario 02 — manifest.csv tamper between keeper-migrate and dsk import
# ---------------------------------------------------------------------------


class TestScenario02ManifestCsvTamper:
    """Pinning tests for red-team Scenario 02.

    Defence: audit chain verification + SHA256SUMS integrity gate.
    Attack: attacker swaps target_uid in manifest.csv after keeperCMD wrote it.
    """

    def test_valid_run_dir_dry_run_succeeds(self, tmp_path: Path) -> None:
        """Baseline: a valid unmodified run-dir should succeed in dry-run."""
        run_dir = _write_valid_run_dir(tmp_path / "run")
        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        assert result.exit_code == 0, result.output

    def test_missing_manifest_csv_is_rejected(self, tmp_path: Path) -> None:
        """A run-dir without manifest.csv is not a keeperCMD output — must be rejected."""
        run_dir = _write_valid_run_dir(tmp_path / "run")
        (run_dir / "manifest.csv").unlink()
        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        assert result.exit_code != 0, "Expected non-zero exit when manifest.csv is absent"

    def test_tampered_sha256sums_is_detected(self, tmp_path: Path) -> None:
        """SHA256SUMS.txt mismatch after manifest.csv tamper → integrity failure.

        Attack: attacker modifies manifest.csv (swaps target_uid), but
        SHA256SUMS.txt still has the original hash (SHA256SUMS is read-only
        to the attacker in this threat model).

        Defence: --no-skip-sha256 (or default) causes pre-flight sha256 check.
        Requires SHA256SUMS.txt to cover manifest.csv, which is a v1.x extension.
        Tested here via explicit inclusion in SHA256SUMS.txt in the test fixture.
        """
        run_dir = _write_valid_run_dir(tmp_path / "run")

        # Include manifest.csv in SHA256SUMS.txt (v1.x extension, tested defensively)
        original_csv = (run_dir / "manifest.csv").read_bytes()
        sha_file = run_dir / "SHA256SUMS.txt"
        existing = sha_file.read_text(encoding="utf-8")
        sha_file.write_text(
            existing + f"{_sha256(original_csv)}  manifest.csv\n",
            encoding="utf-8",
        )

        # Now tamper with manifest.csv — swap target_uid
        rows = [
            {
                "source_uid": _SOURCE_UID,
                "target_uid": _ORPHAN_TARGET_UID,  # swapped to hijack a different record
                "title": "MT-login-record",
                "type": "login",
                "status": "paired",
                "timestamp": "2026-05-08T18:30:00Z",
            }
        ]
        _write_csv(run_dir / "manifest.csv", rows)

        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        assert result.exit_code != 0, (
            "Expected non-zero exit when manifest.csv hash mismatches SHA256SUMS"
        )
        assert (
            "integrity" in result.output.lower()
            or "sha256" in result.output.lower()
            or "tamper" in result.output.lower()
            or "mismatch" in result.output.lower()
        ), f"Expected integrity-related message in output, got:\n{result.output}"

    def test_malformed_audit_log_is_hard_fail(self, tmp_path: Path) -> None:
        """Malformed audit.log last line → AuditChainCorrupt → hard fail.

        This is the Scenario 02 audit-chain-reset attack:
        attacker appends garbage as the last line; in the old code this
        silently reset the chain to GENESIS. Post-SEC-3 this raises
        AuditChainCorrupt. DSK must treat this as a hard fail.
        """
        run_dir = _write_valid_run_dir(tmp_path / "run")
        audit_path = run_dir / "audit.log"
        # Append a malformed last line (not valid JSON, not a valid event)
        with audit_path.open("a", encoding="utf-8") as f:
            f.write('{"subcommand":"GARBAGE","prev_hash":"wrong","signature":"nope"}\n')

        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        assert result.exit_code != 0, "Expected non-zero exit on audit chain corruption"

    def test_skip_audit_verify_bypasses_chain_check(self, tmp_path: Path) -> None:
        """--skip-audit-verify allows a corrupted audit.log to proceed (testing mode)."""
        run_dir = _write_valid_run_dir(tmp_path / "run")
        audit_path = run_dir / "audit.log"
        # Corrupt audit.log
        audit_path.write_text("not json at all\n", encoding="utf-8")

        result = _run("import-from-keepercmd", str(run_dir), "--dry-run", "--skip-audit-verify")
        # Should not fail due to audit chain; may still succeed or fail for other reasons
        assert result.exit_code in (0, 2), (
            f"--skip-audit-verify should bypass audit check; got exit {result.exit_code}:\n"
            f"{result.output}"
        )


# ---------------------------------------------------------------------------
# Scenario 02 (second layer) — manifest.csv.sha256 sidecar (keeperCMD v1.1+)
# ---------------------------------------------------------------------------


class TestScenario02SidecarV11:
    """Pinning tests for the v1.1 sidecar integrity gate.

    keeperCMD v1.1+ emits manifest.csv.sha256 alongside manifest.csv.
    DSK checks it before reading any rows. Mismatch → hard abort.
    Absent sidecar → fall-through (backward compatible with v1.0 outputs).
    """

    def test_valid_sidecar_passes(self, tmp_path: Path) -> None:
        """Correct sidecar present → command succeeds in dry-run."""
        run_dir = _write_valid_run_dir(tmp_path / "run")
        csv_bytes = (run_dir / "manifest.csv").read_bytes()
        (run_dir / "manifest.csv.sha256").write_text(
            f"{_sha256(csv_bytes)}  manifest.csv\n", encoding="utf-8"
        )
        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        assert result.exit_code == 0, result.output

    def test_tampered_manifest_with_sidecar_detected(self, tmp_path: Path) -> None:
        """manifest.csv modified after sidecar written → non-zero exit, 'tampered'/'mismatch' in output."""
        run_dir = _write_valid_run_dir(tmp_path / "run")
        original_bytes = (run_dir / "manifest.csv").read_bytes()
        (run_dir / "manifest.csv.sha256").write_text(
            f"{_sha256(original_bytes)}  manifest.csv\n", encoding="utf-8"
        )
        # Now tamper manifest.csv — swap target_uid
        tampered_rows = [
            {
                "source_uid": _SOURCE_UID,
                "target_uid": _ORPHAN_TARGET_UID,
                "title": "MT-login-record",
                "type": "login",
                "status": "paired",
                "timestamp": "2026-05-08T18:30:00Z",
            }
        ]
        _write_csv(run_dir / "manifest.csv", tampered_rows)

        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        assert result.exit_code != 0, (
            "Expected non-zero exit when manifest.csv was tampered after sidecar was written"
        )
        assert "tampered" in result.output.lower() or "mismatch" in result.output.lower(), (
            f"Expected 'tampered' or 'mismatch' in output, got:\n{result.output}"
        )

    def test_absent_sidecar_is_compatible(self, tmp_path: Path) -> None:
        """No manifest.csv.sha256 → pre-v1.1 keeperCMD; command continues normally."""
        run_dir = _write_valid_run_dir(tmp_path / "run")
        # Confirm no sidecar exists (helper never writes one)
        assert not (run_dir / "manifest.csv.sha256").exists()
        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        assert result.exit_code == 0, (
            f"Absent sidecar should be treated as pre-v1.1 and not fail; got:\n{result.output}"
        )


# ---------------------------------------------------------------------------
# Scenario 03 — ownership-marker forgery before dsk import-from-keepercmd
# ---------------------------------------------------------------------------


class TestScenario03OwnershipMarkerForgery:
    """Pinning tests for red-team Scenario 03.

    Defence: manifest.csv cross-reference — a record carrying a
    keeper_declarative_manager custom field but with no matching paired
    CSV row must be flagged SUSPECT and NOT adopted.

    Attack: attacker with write access to target-tenant writes
    keeper_declarative_manager field to a high-value record before
    dsk import-from-keepercmd runs, aiming to make DSK skip or
    over-claim ownership of that record.
    """

    def _forged_record(self, uid: str) -> dict[str, Any]:
        """A target-tenant export record that carries a pre-existing marker (forged)."""
        return {
            "uid": uid,
            "title": "high-value-record",
            "type": "login",
            "version": 3,
            "fields": [
                {"type": "login", "value": ["admin@acme.com"]},
                {"type": "password", "value": ["secret!"]},
            ],
            "custom": [
                {
                    "type": "text",
                    "label": "keeper_declarative_manager",
                    "value": ["forgery-manifest-name"],
                }
            ],
            "notes": "",
            "files": [],
        }

    def test_forged_marker_without_csv_pairing_not_adopted(self, tmp_path: Path) -> None:
        """Forged marker with no paired CSV row → SUSPECT warning, record NOT adopted.

        This tests the core Scenario 03 defence: manifest.csv cross-reference.
        The forged record's UID has no matching paired row in manifest.csv,
        so DSK must not write a new keeper_declarative_manager marker to it.
        """
        forged_uid = "F" * 22

        run_dir = _write_valid_run_dir(
            tmp_path / "run",
            extra_records_export=[self._forged_record(forged_uid)],
            # No CSV pair for forged_uid — the attack pre-conditions exactly this gap
        )

        result = _run("import-from-keepercmd", str(run_dir), "--dry-run", "--verbose")
        # Command may succeed (exit 0) or exit with a warning exit code —
        # either is acceptable; what must NOT happen is silent adoption.
        # The output must mention the suspect/forged record.
        output_lower = result.output.lower()
        assert (
            "suspect" in output_lower
            or "forged" in output_lower
            or "no csv pair" in output_lower
            or "not paired" in output_lower
            or "skip" in output_lower
        ), f"Expected SUSPECT warning for forged-marker record in output, got:\n{result.output}"

    def test_suspect_threshold_exceeded_causes_abort(self, tmp_path: Path) -> None:
        """When suspect count > --suspect-threshold (default 0), command must abort.

        This ensures the operator sees the problem immediately rather than
        having suspect records silently skipped.
        """
        forged_uid = "F" * 22

        run_dir = _write_valid_run_dir(
            tmp_path / "run",
            extra_records_export=[self._forged_record(forged_uid)],
        )

        # Default --suspect-threshold 0 means any suspect aborts
        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        # Either aborts (non-zero) OR exits 0 with suspect count visible —
        # the key invariant is that no marker is written.
        # If --dry-run, no markers are ever written regardless, so we verify
        # the suspect signal appears in output.
        assert "suspect" in result.output.lower() or result.exit_code != 0, (
            f"Expected suspect signal or non-zero exit; got exit={result.exit_code}:\n"
            f"{result.output}"
        )

    def test_legitimate_marker_on_paired_record_is_noted_not_blocked(self, tmp_path: Path) -> None:
        """A record that has a marker AND a paired CSV row is flagged but not hard-blocked.

        This is the edge case where DSK previously adopted the record in an
        earlier session — the marker is legitimate, not forged. The command
        should surface a note ('already managed') but not abort.
        """
        # Source record with a pre-existing marker (legitimate — already adopted)
        source_with_marker: dict[str, Any] = {
            "uid": _SOURCE_UID,
            "title": "MT-login-record",
            "type": "login",
            "version": 3,
            "fields": [{"type": "login", "value": ["alice@acme.com"]}],
            "custom": [
                {
                    "type": "text",
                    "label": "keeper_declarative_manager",
                    "value": ["some-existing-manifest"],
                }
            ],
            "notes": "",
            "files": [],
        }
        run_dir = _write_valid_run_dir(tmp_path / "run")
        # Overwrite the source record export with one carrying a marker
        record_bytes = json.dumps(source_with_marker, indent=2).encode()
        (run_dir / "records-export" / f"{_SOURCE_UID}.json").write_bytes(record_bytes)

        sha_file = run_dir / "SHA256SUMS.txt"
        sha_file.write_text(
            f"{_sha256(record_bytes)}  records-export/{_SOURCE_UID}.json\n",
            encoding="utf-8",
        )

        result = _run(
            "import-from-keepercmd",
            str(run_dir),
            "--dry-run",
            "--skip-audit-verify",
            "--suspect-threshold",
            "1",
        )
        # With --suspect-threshold 1 the command should not hard-abort on a single
        # suspect record — the threshold override is the operator saying "I've reviewed
        # this". The record IS in manifest.csv as paired.
        assert result.exit_code in (0, 1), (
            f"Paired record with existing marker should not hard-abort when "
            f"--suspect-threshold 1 is set; got exit={result.exit_code}:\n{result.output}"
        )

    def test_unpaired_rows_are_skipped_silently(self, tmp_path: Path) -> None:
        """manifest.csv rows with status=unpaired must be skipped (no adoption).

        These are records that didn't pair successfully during migration —
        attempting to adopt them would be wrong regardless of marker state.
        """
        run_dir = _write_valid_run_dir(
            tmp_path / "run",
            extra_csv_rows=[
                {
                    "source_uid": "U" * 22,
                    "target_uid": "",
                    "title": "unpaired-record",
                    "type": "encryptedNotes",
                    "status": "unpaired",
                    "timestamp": "2026-05-08T18:30:00Z",
                }
            ],
        )
        result = _run("import-from-keepercmd", str(run_dir), "--dry-run")
        assert result.exit_code == 0, result.output
        assert (
            "unpaired" in result.output.lower()
            or "skip" in result.output.lower()
            or result.output.count(_TARGET_UID[:6]) >= 0
        )  # at minimum the paired record processed
