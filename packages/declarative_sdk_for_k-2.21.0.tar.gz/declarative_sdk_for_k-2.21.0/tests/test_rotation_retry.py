from __future__ import annotations

from dsk.providers.commander_cli import CommanderCliProvider


def test_stderr_shows_rotation_set_record_rotation_http_500_positive() -> None:
    stderr = (
        'WARNING:root:Record "pKQnFzOUVK5mohxrfv_leA": '
        'Set rotation error "500": Internal server error\n'
    )
    assert CommanderCliProvider._stderr_shows_rotation_set_record_rotation_http_500(stderr)


def test_stderr_shows_rotation_set_record_rotation_http_500_negative() -> None:
    assert not CommanderCliProvider._stderr_shows_rotation_set_record_rotation_http_500("")
    assert not CommanderCliProvider._stderr_shows_rotation_set_record_rotation_http_500(
        'Set rotation error "400": bad request\n'
    )
