"""Tests for keeper-agent-kit.v1 (Keeper Security Agent Kit governance)."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from dsk.core.manifest import read_manifest_document
from dsk.core.models_agent_kit import AgentKitManifestV1
from dsk.core.schema import AGENT_KIT_FAMILY, validate_manifest

REPO_ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = REPO_ROOT / "examples/agent_kit/acme-agent-kit.yaml"


def test_agent_kit_schema_validate_manifest():
    document = read_manifest_document(EXAMPLE)
    assert validate_manifest(document) == AGENT_KIT_FAMILY


def test_agent_kit_model_loads_from_yaml():
    data = yaml.safe_load(EXAMPLE.read_text())
    manifest = AgentKitManifestV1.model_validate(data)
    assert manifest.schema_ == "keeper-agent-kit.v1"
    assert manifest.name == "acme-agent-kit"
    assert len(manifest.policies) == 1
    pol = manifest.policies[0]
    assert pol.uid_ref == "sak.cursor-dev"
    assert pol.ksm_binding is not None
    assert pol.ksm_binding.ksm_app_uid_ref == "ksm.dev-app"


def test_invalid_skill_rejected():
    data = yaml.safe_load(EXAMPLE.read_text())
    data["policies"][0]["enabled_skills"] = ["keeper-secrets", "not-a-skill"]
    with pytest.raises(ValidationError):
        AgentKitManifestV1.model_validate(data)


def test_invalid_agent_rejected():
    data = yaml.safe_load(EXAMPLE.read_text())
    data["policies"][0]["enabled_agents"] = ["cursor", "unknown-agent"]
    with pytest.raises(ValidationError):
        AgentKitManifestV1.model_validate(data)


def test_agent_kit_manifest_default_manager():
    """Loaded example manifest keeps default manager=dsk."""
    data = yaml.safe_load(EXAMPLE.read_text())
    manifest = AgentKitManifestV1.model_validate(data)
    assert manifest.manager == "dsk"


def test_session_timeout_out_of_range_rejected():
    """SakPolicy rejects session_timeout_minutes outside 1..480."""
    data = yaml.safe_load(EXAMPLE.read_text())
    data["policies"][0]["session_timeout_minutes"] = 481
    with pytest.raises(ValidationError):
        AgentKitManifestV1.model_validate(data)


def test_commander_binding_optional_fields_default_empty():
    """Commander binding may omit allowed_commands (defaults to empty list)."""
    data = yaml.safe_load(EXAMPLE.read_text())
    data["policies"][0]["commander_binding"] = {"config_uid_ref": "cmd.test-record"}
    manifest = AgentKitManifestV1.model_validate(data)
    pol = manifest.policies[0]
    assert pol.commander_binding is not None
    assert pol.commander_binding.config_uid_ref == "cmd.test-record"
    assert pol.commander_binding.allowed_commands == []
