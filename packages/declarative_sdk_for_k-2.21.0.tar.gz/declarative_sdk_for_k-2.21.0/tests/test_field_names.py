"""Keeper field-name normalization tests."""

from __future__ import annotations

from dsk.core.field_names import field_name_matches, norm_field_name
from dsk.providers._commander_cli_helpers import _canonical_payload_from_field


def test_norm_field_name_handles_case_and_separators() -> None:
    assert norm_field_name("privateKey") == norm_field_name("private_key")
    assert norm_field_name("hostName") == norm_field_name("host_name")


def test_field_name_matches_keeper_type_label_form() -> None:
    assert field_name_matches("$secret:privatePEMKey", "private_pem_key")
    assert field_name_matches("$secret:privatePEMKey", "secret")
    assert norm_field_name("$oneTimeCode:") == "onetimecode"
    assert field_name_matches("$oneTimeCode:", "one_time_code")


def test_canonical_payload_uses_normalized_field_label_aliases() -> None:
    field = {"type": "text", "label": "Database_Type", "value": ["postgres"]}

    assert _canonical_payload_from_field(field) == {"database_type": "postgres"}


def test_host_payload_accepts_normalized_host_keys() -> None:
    field = {"type": "pamHostname", "value": [{"host_name": "db.example", "Port": 5432}]}

    assert _canonical_payload_from_field(field) == {"host": "db.example", "port": 5432}
