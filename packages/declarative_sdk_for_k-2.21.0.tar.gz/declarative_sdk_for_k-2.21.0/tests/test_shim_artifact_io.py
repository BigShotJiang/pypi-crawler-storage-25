"""Trust-boundary tests exercised through keeperCMD's public DSK hooks."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import pytest
from keeper_tenant_migrate import audit as cmd_audit
from keeper_tenant_migrate.integrations.dsk_hooks import (
    UnsafeArtifactError,
    validate_run_dir_for_adopt,
)


def _inventory() -> dict:
    return {
        "counts": {
            "nodes": 1,
            "teams": 0,
            "roles": 0,
            "shared_folders": 0,
            "records": 0,
            "users": 0,
        },
        "entities": {
            "nodes": [{"name": "Source Co"}],
            "teams": [],
            "roles": [],
            "users": [],
            "shared_folders": [],
            "records": [],
        },
    }


def _write_run_dir(run_dir: Path) -> Path:
    run_dir.mkdir(exist_ok=True)
    (run_dir / "inventory.json").write_text(json.dumps(_inventory()), encoding="utf-8")
    (run_dir / "manifest.csv").write_text("source_uid,target_uid\n", encoding="utf-8")
    (run_dir / "records_import.json").write_text("[]\n", encoding="utf-8")
    (run_dir / "records_export").mkdir(exist_ok=True)
    cmd_audit.append_audit_event(
        run_dir / "audit.log",
        {"event": "fixture", "subcommand": "test", "inputs": {}, "outputs": {}, "summary": {}},
    )
    cmd_audit.write_sha256sums(str(run_dir))
    return run_dir


def test_public_hook_refuses_symlinked_inventory(tmp_path: Path) -> None:
    _write_run_dir(tmp_path)
    real = tmp_path / "real_inventory.json"
    (tmp_path / "inventory.json").rename(real)
    (tmp_path / "inventory.json").symlink_to(real)

    with pytest.raises(UnsafeArtifactError, match="symlink"):
        validate_run_dir_for_adopt(tmp_path)


def test_public_hook_refuses_oversized_inventory(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _write_run_dir(tmp_path)
    (tmp_path / "inventory.json").write_text(json.dumps(_inventory()), encoding="utf-8")
    monkeypatch.setenv("KCM_HOOK_MAX_ARTIFACT_BYTES", "16")

    with pytest.raises(UnsafeArtifactError, match="exceeding KCM_HOOK_MAX_ARTIFACT_BYTES"):
        validate_run_dir_for_adopt(tmp_path)


def test_public_hook_warns_on_world_writable_inventory(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    _write_run_dir(tmp_path)
    (tmp_path / "inventory.json").chmod(0o666)

    with caplog.at_level(logging.WARNING):
        validate_run_dir_for_adopt(tmp_path)

    assert any("group/world-writable" in rec.message for rec in caplog.records)
