"""Offline tests for dsk.mcp.server.

No live Keeper calls. Uses mock provider where a manifest is needed.
"""

from __future__ import annotations

import asyncio
import textwrap

# ── importability ─────────────────────────────────────────────────────────────


def test_import_json_rpc_mcp_server() -> None:
    """JsonRpcMcpServer must be importable without network."""
    from dsk.mcp.server import JsonRpcMcpServer  # noqa: PLC0415

    assert callable(JsonRpcMcpServer)


def test_import_main() -> None:
    """main() must be importable (not called — that would block on stdio)."""
    from dsk.mcp.server import main  # noqa: PLC0415

    assert callable(main)


# ── valid manifest fixtures ────────────────────────────────────────────────────

# Minimal pam-environment.v1: version + schema + name only (no extra fields).
_PAM_YAML = textwrap.dedent("""\
    version: "1"
    name: test-pam
    schema: pam-environment.v1
""")

# Minimal keeper-vault.v1: schema + empty records list.
_VAULT_YAML = textwrap.dedent("""\
    schema: keeper-vault.v1
    records: []
""")


# ── tool: validate ─────────────────────────────────────────────────────────────


def test_validate_tool_pam() -> None:
    """validate() tool returns 'ok' for a valid PAM manifest."""
    from dsk.mcp.server import validate  # noqa: PLC0415

    result = asyncio.run(validate(_PAM_YAML))
    assert result == "ok", f"Expected 'ok', got: {result!r}"


def test_validate_tool_vault() -> None:
    """validate() tool returns 'ok' for a minimal vault manifest."""
    from dsk.mcp.server import validate  # noqa: PLC0415

    result = asyncio.run(validate(_VAULT_YAML))
    assert result == "ok", f"Expected 'ok', got: {result!r}"


def test_validate_tool_missing_version() -> None:
    """validate() returns non-ok error string for schema violation."""
    from dsk.mcp.server import validate  # noqa: PLC0415

    # missing 'version' → schema validation failure
    bad = "name: no-version\nschema: pam-environment.v1\n"
    result = asyncio.run(validate(bad))
    assert result != "ok"
    assert "version" in result.lower() or "validation" in result.lower()


def test_validate_tool_invalid_schema_family() -> None:
    """validate() returns error for unknown schema family."""
    from dsk.mcp.server import validate  # noqa: PLC0415

    yaml = 'version: "1"\nname: bad\nschema: nonexistent-family.v99\n'
    result = asyncio.run(validate(yaml))
    assert result != "ok"


# ── tool: bad YAML propagates as exception (server wraps in isError) ──────────


def test_validate_bad_yaml_via_server_call_tool() -> None:
    """call_tool() wraps YAML parse errors in isError content instead of raising."""
    from dsk.mcp.server import server  # noqa: PLC0415

    bad = "this: is: not: valid: yaml: :\n  - broken"
    result = asyncio.run(server.call_tool("dsk_validate", {"manifest_yaml": bad}))
    # call_tool catches exceptions → returns isError=True content block
    assert result["isError"] is True
    assert len(result["content"]) > 0
    assert result["content"][0]["type"] == "text"


# ── JSON-RPC request/response shape (via server.handle) ───────────────────────


def test_json_rpc_validate_response_shape() -> None:
    """server.handle() for dsk_validate returns valid JSON-RPC 2.0 envelope."""
    from dsk.mcp.server import server  # noqa: PLC0415

    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "dsk_validate",
            "arguments": {"manifest_yaml": _PAM_YAML},
        },
    }
    response = asyncio.run(server.handle(request))

    assert isinstance(response, dict), f"Expected dict, got {type(response)}"
    assert response.get("id") == 1
    assert "result" in response or "error" in response

    if "result" in response:
        content = response["result"].get("content", [])
        assert isinstance(content, list)
        assert len(content) > 0
        text_block = content[0]
        assert text_block.get("type") == "text"
        assert "ok" in text_block.get("text", "")


def test_json_rpc_tools_list() -> None:
    """tools/list returns list of tool descriptors including dsk_validate."""
    from dsk.mcp.server import server  # noqa: PLC0415

    request = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
    response = asyncio.run(server.handle(request))

    assert response is not None
    assert response.get("id") == 2
    assert "result" in response
    tools = response["result"]["tools"]
    names = [t["name"] for t in tools]
    assert "dsk_validate" in names


def test_json_rpc_unknown_method() -> None:
    """server.handle() returns JSON-RPC error for unknown method."""
    from dsk.mcp.server import server  # noqa: PLC0415

    request = {
        "jsonrpc": "2.0",
        "id": 42,
        "method": "tools/call",
        "params": {
            "name": "dsk_nonexistent_tool",
            "arguments": {},
        },
    }
    response = asyncio.run(server.handle(request))
    assert isinstance(response, dict)
    assert response.get("id") == 42
    assert "error" in response


# ── CLI: dsk mcp --help ────────────────────────────────────────────────────────


def test_dsk_mcp_help() -> None:
    """dsk mcp --help must exit 0 and show 'serve'."""
    from click.testing import CliRunner

    from dsk.cli.main import main  # noqa: PLC0415

    runner = CliRunner()
    result = runner.invoke(main, ["mcp", "--help"])
    assert result.exit_code == 0, result.output
    assert "serve" in result.output


def test_dsk_mcp_serve_help() -> None:
    """dsk mcp serve --help must exit 0 and describe the stdio server."""
    from click.testing import CliRunner

    from dsk.cli.main import main  # noqa: PLC0415

    runner = CliRunner()
    result = runner.invoke(main, ["mcp", "serve", "--help"])
    assert result.exit_code == 0, result.output
    assert "stdio" in result.output.lower() or "mcp" in result.output.lower()


# ── JsonRpcMcpServer.handle() protocol coverage ───────────────────────────────


def test_handle_initialize() -> None:
    """handle() with method=initialize must return serverInfo and capabilities."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    req = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    result = resp["result"]
    assert "serverInfo" in result
    assert "capabilities" in result


def test_handle_tools_list() -> None:
    """handle() with method=tools/list must return a list of tool descriptors."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    req = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    assert isinstance(resp["result"]["tools"], list)
    assert len(resp["result"]["tools"]) > 0


def test_handle_ping() -> None:
    """handle() with method=ping must return an empty result dict."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    req = {"jsonrpc": "2.0", "id": 3, "method": "ping", "params": {}}
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    assert resp["result"] == {}


def test_handle_unknown_method_returns_error() -> None:
    """handle() with an unknown method must return a JSON-RPC error response."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    req = {"jsonrpc": "2.0", "id": 4, "method": "nonexistent/method", "params": {}}
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    assert "error" in resp
    assert resp["error"]["code"] == -32601


def test_handle_notification_returns_none() -> None:
    """handle() must return None for notifications (requests without 'id')."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    notification = {"jsonrpc": "2.0", "method": "tools/list"}  # no id
    resp = asyncio.run(mcp_srv.server.handle(notification))
    assert resp is None


def test_tools_call_validate_pam() -> None:
    """tools/call dsk_validate must succeed for a valid PAM manifest."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    req = {
        "jsonrpc": "2.0",
        "id": 5,
        "method": "tools/call",
        "params": {
            "name": "dsk_validate",
            "arguments": {"manifest_yaml": _PAM_YAML},
        },
    }
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    content = resp["result"]["content"]
    assert any("ok" in str(c).lower() for c in content)


def test_plan_tool_via_server_call() -> None:
    """tools/call dsk_plan on a valid PAM manifest must return JSON plan string."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    req = {
        "jsonrpc": "2.0",
        "id": 10,
        "method": "tools/call",
        "params": {
            "name": "dsk_plan",
            "arguments": {"manifest_yaml": _PAM_YAML},
        },
    }
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    # Should return result with content list
    assert "result" in resp or "error" in resp
    if "result" in resp:
        content = resp["result"]["content"]
        text = "".join(str(c) for c in content)
        # Either a plan JSON or a no-changes message
        assert isinstance(text, str)


def test_apply_tool_requires_auto_approve_true() -> None:
    """dsk_apply must return error when auto_approve is not True."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    req = {
        "jsonrpc": "2.0",
        "id": 11,
        "method": "tools/call",
        "params": {
            "name": "dsk_apply",
            "arguments": {"manifest_yaml": _PAM_YAML, "auto_approve": False},
        },
    }
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    # Should either error or return isError=True content
    content = str(resp)
    assert "error" in content.lower() or "approve" in content.lower()


def test_diff_tool_via_server_call() -> None:
    """tools/call dsk_diff on a valid PAM manifest must return some text."""
    from dsk.mcp import server as mcp_srv  # noqa: PLC0415

    req = {
        "jsonrpc": "2.0",
        "id": 12,
        "method": "tools/call",
        "params": {
            "name": "dsk_diff",
            "arguments": {"manifest_yaml": _PAM_YAML},
        },
    }
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    assert "result" in resp or "error" in resp


# ── _json_schema_for_annotation helpers ─────────────────────────────────────


def test_json_schema_for_annotation_all_primitives() -> None:
    """_json_schema_for_annotation maps Python builtins to JSON Schema types."""
    from dsk.mcp.server import _json_schema_for_annotation

    assert _json_schema_for_annotation(str) == {"type": "string"}
    assert _json_schema_for_annotation(bool) == {"type": "boolean"}
    assert _json_schema_for_annotation(int) == {"type": "integer"}
    assert _json_schema_for_annotation(float) == {"type": "number"}
    assert _json_schema_for_annotation(dict) == {"type": "object"}
    assert _json_schema_for_annotation(list) == {"type": "array"}


def test_json_schema_for_annotation_string_hints() -> None:
    """_json_schema_for_annotation resolves string annotations."""
    from dsk.mcp.server import _json_schema_for_annotation

    assert _json_schema_for_annotation("bool flag") == {"type": "boolean"}
    assert _json_schema_for_annotation("dict[str, Any]") == {"type": "object"}
    assert _json_schema_for_annotation("list[str]") == {"type": "array"}
    assert _json_schema_for_annotation("int count") == {"type": "integer"}
    assert _json_schema_for_annotation("float val") == {"type": "number"}
    assert _json_schema_for_annotation("str name") == {"type": "string"}


def test_json_schema_for_annotation_optional() -> None:
    """_json_schema_for_annotation unwraps Optional[X]."""

    from dsk.mcp.server import _json_schema_for_annotation

    assert _json_schema_for_annotation(str | None) == {"type": "string"}
    assert _json_schema_for_annotation(int | None) == {"type": "integer"}


# ── _tool_schema ─────────────────────────────────────────────────────────────


def test_tool_schema_has_required_fields() -> None:
    """_tool_schema produces correct JSON schema for a simple function."""
    from dsk.mcp.server import _tool_schema

    async def my_tool(text: str, count: int = 1) -> str:
        """My doc."""
        return text

    schema = _tool_schema("my_tool", my_tool)
    assert schema["name"] == "my_tool"
    assert schema["description"] == "My doc."
    assert "text" in schema["inputSchema"]["properties"]
    assert "text" in schema["inputSchema"]["required"]
    assert "count" not in schema["inputSchema"]["required"]


# ── _redact_structured_text ──────────────────────────────────────────────────


def test_redact_structured_text_empty_string() -> None:
    """_redact_structured_text returns empty string for blank input."""
    from dsk.mcp.server import _redact_structured_text

    assert _redact_structured_text("") == ""
    assert _redact_structured_text("   \n  ") == ""


def test_redact_structured_text_json_payload() -> None:
    """_redact_structured_text round-trips valid JSON."""
    import json

    from dsk.mcp.server import _redact_structured_text

    payload = json.dumps({"key": "value", "num": 42})
    result = _redact_structured_text(payload)
    parsed = json.loads(result)
    assert parsed["key"] == "value"
    assert parsed["num"] == 42


def test_redact_structured_text_plain_text() -> None:
    """_redact_structured_text passes through non-JSON plain text."""
    from dsk.mcp.server import _redact_structured_text

    result = _redact_structured_text("hello world")
    assert "hello" in result


# ── _rpc_error ────────────────────────────────────────────────────────────────


def test_rpc_error_shape() -> None:
    """_rpc_error produces a properly shaped JSON-RPC error response."""
    from dsk.mcp.server import _rpc_error

    resp = _rpc_error(42, -32601, "method not found")
    assert resp["jsonrpc"] == "2.0"
    assert resp["id"] == 42
    assert resp["error"]["code"] == -32601
    assert resp["error"]["message"] == "method not found"


def test_rpc_error_none_id() -> None:
    """_rpc_error with None id is valid (parse-error case)."""
    from dsk.mcp.server import _rpc_error

    resp = _rpc_error(None, -32700, "parse error")
    assert resp["id"] is None
    assert resp["error"]["code"] == -32700


# ── dsk_export ────────────────────────────────────────────────────────────────


def test_export_tool_pam_json() -> None:
    """dsk_export converts a minimal PAM import JSON to YAML."""
    import asyncio
    import json

    from dsk.mcp import server as mcp_srv

    # from_pam_import_json expects flat Commander export format
    pam_data = json.dumps({"pam_configurations": [], "machines": [], "machine_users": []})
    result = asyncio.run(mcp_srv.export(pam_data))
    # Should produce some YAML (or raise if load_manifest_string fails; still a valid path)
    assert isinstance(result, str)


# ── Sprint BI: mcp/server.py helper coverage ──────────────────────────────


def test_manifest_name_returns_pam_name() -> None:
    """_manifest_name returns pam.name when pam manifest present."""
    from pathlib import Path
    from unittest.mock import MagicMock

    from dsk.mcp.server import _manifest_name

    pam = MagicMock()
    pam.name = "my-pam"
    result = _manifest_name(
        Path("/tmp/manifest.yaml"),
        pam=pam,
        msp=None,
        identity=None,
        pam_extended=None,
        events=None,
        nhi=None,
        ai_agent=None,
    )
    assert result == "my-pam"


def test_manifest_name_falls_back_to_path_stem() -> None:
    """_manifest_name uses path.stem when all manifests are None."""
    from pathlib import Path

    from dsk.mcp.server import _manifest_name

    result = _manifest_name(
        Path("/tmp/my-env.yaml"),
        pam=None,
        msp=None,
        identity=None,
        pam_extended=None,
        events=None,
        nhi=None,
        ai_agent=None,
    )
    assert result == "my-env"


def test_manifest_name_returns_identity_family() -> None:
    """_manifest_name returns IDENTITY_FAMILY when identity manifest is set."""
    from pathlib import Path
    from unittest.mock import MagicMock

    from dsk.mcp.server import IDENTITY_FAMILY, _manifest_name

    result = _manifest_name(
        Path("/tmp/x.yaml"),
        pam=None,
        msp=None,
        identity=MagicMock(),
        pam_extended=None,
        events=None,
        nhi=None,
        ai_agent=None,
    )
    assert result == IDENTITY_FAMILY


def test_unsupported_plan_apply_returns_capability_error() -> None:
    """_unsupported_plan_apply returns CapabilityError with correct family in message."""
    from dsk.core.errors import CapabilityError
    from dsk.mcp.server import _unsupported_plan_apply

    exc = _unsupported_plan_apply("test-family.v1", "offline-only")
    assert isinstance(exc, CapabilityError)
    assert "test-family.v1" in exc.reason


def test_outcome_to_dict_returns_dict() -> None:
    """_outcome_to_dict returns a dict with uid_ref, action etc."""
    from dsk.core.interfaces import ApplyOutcome
    from dsk.mcp.server import _outcome_to_dict

    outcome = ApplyOutcome(uid_ref="x.ref", keeper_uid="K1", action="create", details={})
    result = _outcome_to_dict(outcome)
    assert isinstance(result, dict)
    assert result["uid_ref"] == "x.ref"


def test_redacted_json_produces_valid_json() -> None:
    """_redacted_json returns JSON string."""
    import json

    from dsk.mcp.server import _redacted_json

    result = _redacted_json({"key": "value", "password": "secret"})
    parsed = json.loads(result)
    assert isinstance(parsed, dict)


def test_redact_structured_text_yaml_dict() -> None:
    """_redact_structured_text returns redacted YAML for dict input."""
    from dsk.mcp.server import _redact_structured_text

    yaml_text = "key: value\npassword: secret123\n"
    result = _redact_structured_text(yaml_text)
    assert isinstance(result, str)


def test_redact_structured_text_invalid_yaml() -> None:
    """_redact_structured_text handles non-YAML text by redacting as string."""
    from dsk.mcp.server import _redact_structured_text

    result = _redact_structured_text("not: [yaml: {{broken}")
    assert isinstance(result, str)


def test_report_tool_raises_on_invalid_report_type() -> None:
    """dsk_report raises ValueError for unsupported report types."""
    import asyncio

    import pytest as _pytest

    from dsk.mcp import server as mcp_srv

    with _pytest.raises(Exception):  # ValueError or similar
        asyncio.run(mcp_srv.report("invalid-report-type"))


def test_apply_raises_when_auto_approve_false() -> None:
    """dsk_apply raises when auto_approve is not True."""
    import asyncio

    import pytest as _pytest

    from dsk.mcp import server as mcp_srv

    with _pytest.raises(ValueError, match="auto_approve"):
        asyncio.run(mcp_srv.apply("schema: pam-environment.v1\nname: test\n", auto_approve=False))
