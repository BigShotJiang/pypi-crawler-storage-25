"""Focused keeper-epm.v1 offline manifest tests."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_CAPABILITY
from dsk.core.diff import ChangeKind
from dsk.core.epm_diff import compute_epm_diff
from dsk.core.errors import SchemaError
from dsk.core.manifest import load_declarative_manifest_string
from dsk.core.models_epm import EPM_FAMILY, EpmManifestV1, load_epm_manifest
from dsk.core.planner import build_plan


def _minimal_doc() -> dict[str, Any]:
    return {"schema": EPM_FAMILY, "policies": []}


def _policy(uid_ref: str, name: str, elevation_type: str = "approval") -> dict[str, Any]:
    return {
        "uid_ref": uid_ref,
        "name": name,
        "elevation_type": elevation_type,
        "target_users": ["alice@example.com"],
        "target_groups": ["admin-workstations"],
        "application_patterns": ["keeper://epm/apps/admin-tools/*"],
    }


def _policy_doc(*policies: dict[str, Any]) -> dict[str, Any]:
    return {"schema": EPM_FAMILY, "policies": list(policies)}


def _write_json(tmp_path: Path, name: str, document: dict[str, Any]) -> Path:
    path = tmp_path / name
    path.write_text(json.dumps(document), encoding="utf-8")
    return path


def _epm_apply_order(manifest: EpmManifestV1) -> list[str]:
    return [uid_ref for uid_ref, _kind in manifest.iter_uid_refs()]


def test_epm_valid_minimal_manifest_with_empty_policies() -> None:
    manifest = load_epm_manifest(_minimal_doc())

    assert manifest.epm_schema == EPM_FAMILY
    assert manifest.policies == []
    assert manifest.watchlists == []
    assert manifest.approvers == []


def test_epm_missing_schema_field_raises_schema_error() -> None:
    with pytest.raises(SchemaError) as exc:
        load_epm_manifest({"policies": []})

    assert "schema" in exc.value.reason


def test_epm_roundtrip_after_order_build_remains_equal() -> None:
    manifest = load_epm_manifest(_policy_doc(_policy("pol.admin", "Admin elevation")))
    assert _epm_apply_order(manifest) == ["pol.admin"]

    dumped = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    reloaded = load_declarative_manifest_string(json.dumps(dumped), suffix=".json")

    assert isinstance(reloaded, EpmManifestV1)
    assert reloaded.model_dump(mode="json", exclude_none=True, by_alias=True) == dumped


def test_epm_policy_entry_validation() -> None:
    document = _policy_doc(_policy("pol.admin", "Admin elevation", elevation_type="auto"))
    manifest = load_epm_manifest(document)

    assert manifest.policies[0].name == "Admin elevation"
    assert manifest.policies[0].elevation_type == "auto"
    assert manifest.policies[0].target_users == ["alice@example.com"]
    assert manifest.policies[0].target_groups == ["admin-workstations"]
    assert manifest.policies[0].application_patterns == ["keeper://epm/apps/admin-tools/*"]

    invalid = _policy_doc(_policy("pol.bad", "Bad policy", elevation_type="prompt"))
    with pytest.raises(SchemaError) as exc:
        load_epm_manifest(invalid)

    assert "not one of" in exc.value.reason


def test_epm_two_policy_manifest_plans_both_in_manifest_order() -> None:
    manifest = load_epm_manifest(
        _policy_doc(
            _policy("pol.zeta", "Zeta elevation"),
            _policy("pol.alpha", "Alpha elevation"),
        )
    )

    changes = compute_epm_diff(manifest, {}, manifest_name="epm-test")
    plan = build_plan("epm-test", changes, _epm_apply_order(manifest))

    assert [change.kind for change in plan.ordered()] == [ChangeKind.CREATE, ChangeKind.CREATE]
    assert [change.uid_ref for change in plan.ordered()] == ["pol.zeta", "pol.alpha"]


def test_epm_apply_mock_provider_exits_capability(tmp_path: Path) -> None:
    path = _write_json(tmp_path, "epm.json", _policy_doc(_policy("pol.admin", "Admin elevation")))

    result = CliRunner().invoke(
        main,
        ["--provider", "mock", "apply", "--auto-approve", str(path)],
        catch_exceptions=False,
    )

    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert EPM_FAMILY in result.output


def test_epm_apply_mock_provider_reports_upstream_gap_or_pedm(tmp_path: Path) -> None:
    path = _write_json(tmp_path, "epm.json", _policy_doc(_policy("pol.admin", "Admin elevation")))

    result = CliRunner().invoke(
        main,
        ["--provider", "mock", "apply", "--auto-approve", str(path)],
        catch_exceptions=False,
    )

    assert "upstream-gap" in result.output or "PEDM" in result.output
    assert "PEDM tenant write/readback proof" in result.output


def test_epm_unknown_field_raises_schema_error() -> None:
    document = _minimal_doc()
    document["unexpected"] = True

    with pytest.raises(SchemaError) as exc:
        load_epm_manifest(document)

    assert "Additional properties" in exc.value.reason


# ── epm_diff additional paths ─────────────────────────────────────────────────


def test_compute_epm_policy_diff_create_from_empty_live() -> None:
    """compute_epm_policy_diff emits CREATE when live is empty dict."""
    from dsk.core.epm_diff import compute_epm_policy_diff
    from dsk.core.models_epm import EpmPolicyManifestV1

    manifest = EpmPolicyManifestV1(
        name="test", default_policies=["just_in_time_elevation"], policies=[]
    )
    changes = compute_epm_policy_diff(manifest, live={})
    assert any(c.resource_type == "epm_default_policy" and c.kind.name == "CREATE" for c in changes)


def test_compute_epm_policy_diff_update_on_mismatch() -> None:
    """compute_epm_policy_diff emits UPDATE when live entry differs from desired."""
    from dsk.core.epm_diff import compute_epm_policy_diff
    from dsk.core.models_epm import EpmPolicyManifestV1

    manifest = EpmPolicyManifestV1(
        name="test", default_policies=["just_in_time_elevation"], policies=[]
    )
    # Live has the uid_ref but different data
    live = {"default_policies:just_in_time_elevation": {"category": "old-value"}}
    changes = compute_epm_policy_diff(manifest, live=live)
    assert any(c.kind.name == "UPDATE" for c in changes)


def test_compute_epm_diff_live_only_emits_skip_or_delete() -> None:
    """compute_epm_diff emits SKIP for live-only entries when allow_delete=False."""
    from dsk.core.epm_diff import compute_epm_diff
    from dsk.core.models_epm import EpmManifestV1

    manifest = EpmManifestV1(**{"schema": "keeper-epm.v1"})
    live_epm = EpmManifestV1(
        **{
            "schema": "keeper-epm.v1",
            "watchlists": [{"uid_ref": "wl.1", "name": "Old WL", "policy_type": "allowlist"}],
        }
    )
    changes = compute_epm_diff(manifest, live_epm=live_epm, allow_delete=False)
    kinds = {c.kind.name for c in changes}
    assert "SKIP" in kinds or "DELETE" in kinds or len(changes) == 0


# ── Sprint BE: epm_diff additional paths ─────────────────────────────────


def test_compute_epm_diff_duplicate_live_emits_conflict() -> None:
    """compute_epm_diff emits CONFLICT when live has duplicate keyed objects."""
    from dsk.core.epm_diff import _index_live

    # Construct live payload with duplicate watchlist keys
    live_payload = {
        "watchlists": [
            {"uid_ref": "wl.dup", "name": "WL One", "policy_type": "allowlist"},
            {"uid_ref": "wl.dup", "name": "WL Two", "policy_type": "allowlist"},
        ],
    }
    _, duplicate_live = _index_live(live_payload)
    assert len(duplicate_live) > 0  # sanity check


def test_compute_epm_policy_diff_noop_when_data_matches() -> None:
    """compute_epm_policy_diff emits NOOP when desired matches live."""
    from dsk.core.epm_diff import compute_epm_policy_diff
    from dsk.core.models_epm import EpmPolicyManifestV1

    manifest = EpmPolicyManifestV1(
        name="test", default_policies=["just_in_time_elevation"], policies=[]
    )
    live = {"default_policies:just_in_time_elevation": {"category": "just_in_time_elevation"}}
    changes = compute_epm_policy_diff(manifest, live=live)
    assert any(c.kind.name == "NOOP" for c in changes)


def test_compute_epm_policy_diff_delete_when_allow_delete() -> None:
    """compute_epm_policy_diff emits DELETE for live-only entries when allow_delete=True."""
    from dsk.core.epm_diff import compute_epm_policy_diff
    from dsk.core.models_epm import EpmPolicyManifestV1

    manifest = EpmPolicyManifestV1(name="test", default_policies=[], policies=[])
    live = {"orphan_policy_uid_ref": {"category": "some_category"}}
    changes = compute_epm_policy_diff(manifest, live=live, allow_delete=True)
    assert any(c.kind.name == "DELETE" for c in changes)
