"""Dispatch contracts for Commander-backed provider helpers (offline).

The production type is :class:`dsk.providers.commander_cli.CommanderCliProvider`
(parent briefs sometimes shorten this to ``CommanderCli``). These tests monkeypatch
Commander modules and ``_run_cmd`` to capture argv/kwargs — no live tenant I/O.
"""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

import dsk.providers.commander_cli as commander_cli
from dsk.core import CapabilityError, Change, ChangeKind, build_plan
from dsk.providers.commander_cli import (
    _PAM_EXTENDED_ROTATION_SCHEDULE,
    CommanderCliProvider,
)


def _provider(monkeypatch: pytest.MonkeyPatch) -> CommanderCliProvider:
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    return CommanderCliProvider(folder_uid="folder-uid")


def test_apply_ai_agent_plan_raises_capability_error(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider(monkeypatch)
    plan = build_plan("ai-agent", [], [])
    with pytest.raises(CapabilityError) as exc_info:
        provider.apply_ai_agent_plan(plan)
    assert "ai-agent.v1 declarative apply is unavailable" in exc_info.value.reason
    assert exc_info.value.next_action == (
        "pending NHI PAM API GA — monitor Keeper product announcements"
    )


def test_apply_rotation_plan_dispatches_rotation_edit_kwargs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    params = object()
    seen: list[tuple[object, dict[str, Any]]] = []

    class _FakeRotationCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            seen.append((params_arg, kwargs))

    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.discoveryrotation",
        types.SimpleNamespace(PAMCreateRecordRotationCommand=_FakeRotationCommand),
    )
    provider = _provider(monkeypatch)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda fn: fn())
    plan = build_plan(
        "rotation",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="pam.user",
                resource_type="rotation_policy",
                title="daily",
                after={
                    "record_uid_ref": "USER_UID",
                    "schedule_type": "ON_DEMAND",
                },
            )
        ],
        ["pam.user"],
    )

    outcomes = provider.apply_rotation_plan(plan)

    assert outcomes[0].action == "update"
    assert seen == [(params, {"record_name": "USER_UID", "force": True, "on_demand": True})]


def test_apply_pam_extended_plan_records_cli_argv_on_dry_run(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _provider(monkeypatch)
    plan = build_plan(
        "pam-extended",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="sched.daily",
                resource_type=_PAM_EXTENDED_ROTATION_SCHEDULE,
                title="daily-scan",
                after={
                    "name": "daily-scan",
                    "cron_expr": "0 3 * * *",
                    "config_uid_ref": "CFG_UID",
                },
            )
        ],
        ["sched.daily"],
    )

    outcomes = provider.apply_pam_extended_plan(plan, dry_run=True)

    assert outcomes[0].details.get("commander_argv") == [
        "pam",
        "extended",
        "schedule",
        "create",
        "daily-scan",
        "--cron",
        "0 3 * * *",
        "--config-uid",
        "CFG_UID",
    ]


def test_apply_workflow_plan_dispatches_workflow_create_kwargs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    params = object()
    seen: list[tuple[object, dict[str, Any]]] = []

    class _FakeWorkflowCreateCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            seen.append((params_arg, kwargs))

    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.workflow.config_commands",
        types.SimpleNamespace(WorkflowCreateCommand=_FakeWorkflowCreateCommand),
    )
    provider = _provider(monkeypatch)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda fn: fn())
    plan = build_plan(
        "workflow",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="wf.checkout",
                resource_type="workflow",
                title="checkout",
                after={"record_uid_ref": "REC_UID", "checkout": True},
            )
        ],
        ["wf.checkout"],
    )

    outcomes = provider.apply_workflow_plan(plan)

    assert outcomes[0].action == "create"
    assert outcomes[0].keeper_uid == "REC_UID"
    kwargs = seen[0][1]
    assert kwargs["record"] == "REC_UID"
    assert kwargs["checkout"] is True


def test_apply_saas_rotation_plan_dispatches_saas_config_kwargs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    params = object()
    seen: list[tuple[object, dict[str, Any]]] = []

    class _FakeSaasConfigCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            seen.append((params_arg, kwargs))

    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.pam_saas.config",
        types.SimpleNamespace(PAMActionSaasConfigCommand=_FakeSaasConfigCommand),
    )
    provider = _provider(monkeypatch)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda fn: fn())
    plan = build_plan(
        "saas-rotation",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="saas.cfg",
                resource_type="saas_rotation_config",
                title="aws",
                after={"gateway": "GW_UID", "plugin": "aws"},
            )
        ],
        ["saas.cfg"],
    )

    outcomes = provider.apply_saas_rotation_plan(plan)

    assert outcomes[0].action == "create"
    kwargs = seen[0][1]
    assert kwargs["gateway"] == "GW_UID"
    assert kwargs["plugin"] == "aws"
    assert kwargs["do_create"] is True


def test_apply_epm_policy_plan_dispatches_pedm_policy_add_kwargs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    params = object()
    seen: list[tuple[object, dict[str, Any]]] = []

    class _FakePedmPolicyAddCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            seen.append((params_arg, kwargs))

    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.pedm.pedm_admin",
        types.SimpleNamespace(PedmPolicyAddCommand=_FakePedmPolicyAddCommand),
    )
    provider = _provider(monkeypatch)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda fn: fn())
    plan = build_plan(
        "epm-policy",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="epm.rule1",
                resource_type="epm_policy",
                title="rule-one",
                after={"name": "rule-one", "policy_type": "elevation"},
            )
        ],
        ["epm.rule1"],
    )

    outcomes = provider.apply_epm_policy_plan(plan)

    assert outcomes[0].action == "create"
    kwargs = seen[0][1]
    assert kwargs["policy_name"] == "rule-one"
    assert kwargs["policy_type"] == "elevation"


def test_export_pam_project_json_dispatches_native_export_argv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(commander_cli, "_supports_pam_project_export", lambda: True)
    provider = _provider(monkeypatch)
    captured: list[list[str]] = []

    def fake_run_cmd(argv: list[str]) -> str:
        captured.append(list(argv))
        return '{"records": [], "project_uid": "native"}'

    monkeypatch.setattr(provider, "_run_cmd", fake_run_cmd)

    payload = provider.export_pam_project_json("PROJ_UID")

    assert captured == [["pam", "project", "export", "--project-uid", "PROJ_UID"]]
    assert payload["project_uid"] == "native"
