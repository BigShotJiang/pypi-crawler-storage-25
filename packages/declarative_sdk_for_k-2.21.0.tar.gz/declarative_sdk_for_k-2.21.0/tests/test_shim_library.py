"""Unit tests for the ``dsk.shim`` library API."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from dsk.core.planner import Plan
from dsk.shim import (
    ApplyResult,
    AuditExplanation,
    Bundle,
    ImportResult,
    VerifyResult,
    adopt,
    apply,
    audit,
    audit_explain,
    bundle,
    import_from_keepercmd,
    plan,
    shim_info,
    verify,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
MINISIGN_RUNDIR = REPO_ROOT / "tests" / "fixtures" / "minisign-rehearsal"
LEGACY_RUNDIR = REPO_ROOT / "tests" / "fixtures" / "keepercmd_rehearsal"


def _write_vault_manifest(tmp_path: Path) -> Path:
    path = tmp_path / "vault.yaml"
    path.write_text(
        """
schema: keeper-vault.v1
records:
  - uid_ref: shim.v.login
    type: login
    title: Shim API Login
""",
        encoding="utf-8",
    )
    return path


def _write_bundle_manifest(tmp_path: Path) -> Path:
    path = tmp_path / "bundle.yaml"
    path.write_text(
        """
schema: compliance-bundle.v1
name: shim-bundle
output_dir: evidence
frameworks: [SOC2]
controls:
  - control_id: CC6.1
    description: Access control evidence
    report: password-report
    report_args: []
    evidence_file: cc6-1.json
""",
        encoding="utf-8",
    )
    return path


def test_import_from_keepercmd_dry_run_generates_manifest(tmp_path: Path) -> None:
    output = tmp_path / "manifest.yaml"

    result = adopt(MINISIGN_RUNDIR, output=output)

    assert isinstance(result, ImportResult)
    assert result.exit_code == 0
    assert result.output == output
    assert result.manifest_yaml is not None
    assert "schema: keeper-vault.v1" in result.manifest_yaml
    assert "Synthetic Admin Login" in result.manifest_yaml


def test_import_from_keepercmd_old_contract_version_still_succeeds() -> None:
    result = adopt(LEGACY_RUNDIR)

    assert result.exit_code == 0
    assert "no paired records to adopt" in result.stdout


def test_verify_returns_structured_result() -> None:
    result = verify_result = verify(MINISIGN_RUNDIR)

    assert isinstance(verify_result, VerifyResult)
    assert result.exit_code == 0
    assert "verify ok" in result.stdout


def test_audit_explain_returns_summary() -> None:
    result = audit_explain(MINISIGN_RUNDIR / "audit.log")

    assert isinstance(result, AuditExplanation)
    assert result.entry_count > 0
    assert result.failure_count == 0
    assert isinstance(result.operation_counts, dict)


def test_import_from_keepercmd_alias_warns(tmp_path: Path) -> None:
    output = tmp_path / "manifest.yaml"

    with pytest.warns(DeprecationWarning, match=r"deprecated.*adopt"):
        result = import_from_keepercmd(MINISIGN_RUNDIR, output=output)

    assert result.exit_code == 0


def test_audit_alias_warns() -> None:
    with pytest.warns(DeprecationWarning, match=r"deprecated.*audit_explain"):
        result = audit(MINISIGN_RUNDIR / "audit.log")

    assert result.failure_count == 0


def test_plan_returns_core_plan(tmp_path: Path) -> None:
    manifest = _write_vault_manifest(tmp_path)

    result = plan(manifest)

    assert isinstance(result, Plan)
    assert len(result.creates) == 1


def test_apply_dry_run_uses_existing_cli(tmp_path: Path) -> None:
    manifest = _write_vault_manifest(tmp_path)

    result = apply(manifest, dry_run=True)

    assert isinstance(result, ApplyResult)
    assert result.exit_code == 2
    assert result.manifest_path == manifest
    assert "Shim API Login" in result.stdout


def test_apply_requires_manifest_path_for_prebuilt_plan() -> None:
    with pytest.raises(ValueError, match="requires a manifest path"):
        apply(object())


def test_bundle_dry_run_returns_preview(tmp_path: Path) -> None:
    manifest = _write_bundle_manifest(tmp_path)

    result = bundle(manifest, dry_run=True)

    assert isinstance(result, Bundle)
    assert result.exit_code == 0
    assert result.dry_run is True
    assert "Would generate" in result.stdout
    assert "CC6.1" in result.stdout


def test_shim_info_is_json_serializable() -> None:
    info: dict[str, Any] = shim_info()

    assert info["verbs"]["apply"]["is_idempotent"] is False
