"""SCIM push source variants (record / google / ad) and creds_record_uid coupling."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.planner import Plan
from dsk.providers import commander_cli
from dsk.providers.commander_cli import CommanderCliProvider
from dsk.providers.mock import MockProvider


def _plan(*changes: Change) -> Plan:
    return Plan(
        manifest_name="scim-source-test",
        changes=list(changes),
        order=[c.uid_ref or "" for c in changes],
    )


def _provider(monkeypatch: pytest.MonkeyPatch) -> CommanderCliProvider:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    params = object()
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda operation: operation())
    return provider


def _install_scim_command_module(
    monkeypatch: pytest.MonkeyPatch,
    command_cls: type[Any],
) -> None:
    keepercommander_module = types.ModuleType("keepercommander")
    commands_module = types.ModuleType("keepercommander.commands")
    scim_module = types.ModuleType("keepercommander.commands.scim")
    setattr(keepercommander_module, "__path__", [])
    setattr(commands_module, "__path__", [])
    setattr(keepercommander_module, "commands", commands_module)
    scim_module.ScimPushCommand = command_cls
    monkeypatch.setitem(sys.modules, "keepercommander", keepercommander_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", commands_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.scim", scim_module)


def _scim_push_change(
    *,
    source: str,
    creds_record_uid: str | None = None,
    node_id: str = "55",
) -> Change:
    after: dict[str, Any] = {
        "node_id": node_id,
        "push_type": "all",
        "source": source,
    }
    if creds_record_uid is not None:
        after["creds_record_uid"] = creds_record_uid
    return Change(
        kind=ChangeKind.UPDATE,
        uid_ref="ep1",
        resource_type="scim_push",
        title="push",
        before={},
        after=after,
        manifest_name="scim-source-test",
    )


def test_mock_apply_scim_source_record_live_applies() -> None:
    p = MockProvider()
    plan = _plan(_scim_push_change(source="record"))
    out = p.apply_scim_plan(plan, dry_run=False)
    assert len(out) == 1
    assert out[0].action == "update"


def test_mock_apply_scim_source_google_without_creds_raises_capability_error() -> None:
    p = MockProvider()
    plan = _plan(_scim_push_change(source="google"))
    with pytest.raises(CapabilityError, match="creds_record_uid"):
        p.apply_scim_plan(plan, dry_run=False)


def test_mock_apply_scim_source_google_with_creds_applies() -> None:
    p = MockProvider()
    plan = _plan(_scim_push_change(source="google", creds_record_uid="vault-rec-1"))
    out = p.apply_scim_plan(plan, dry_run=False)
    assert len(out) == 1
    assert out[0].action == "update"


def test_mock_apply_scim_source_ad_without_creds_raises_capability_error() -> None:
    p = MockProvider()
    plan = _plan(_scim_push_change(source="ad"))
    with pytest.raises(CapabilityError, match="creds_record_uid"):
        p.apply_scim_plan(plan, dry_run=False)


def test_mock_apply_scim_source_ad_with_creds_applies() -> None:
    p = MockProvider()
    plan = _plan(_scim_push_change(source="ad", creds_record_uid="vault-ad-9"))
    out = p.apply_scim_plan(plan, dry_run=False)
    assert len(out) == 1
    assert out[0].action == "update"


def test_mock_apply_scim_source_google_dry_run_does_not_require_creds() -> None:
    p = MockProvider()
    plan = _plan(_scim_push_change(source="google"))
    out = p.apply_scim_plan(plan, dry_run=True)
    assert len(out) == 1


def test_commander_apply_scim_google_without_creds_raises_before_commander(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []

    class FakeScimPushCommand:
        def execute(self, _params: object, **kwargs: Any) -> None:
            calls.append(kwargs)

    _install_scim_command_module(monkeypatch, FakeScimPushCommand)
    provider = _provider(monkeypatch)
    plan = _plan(_scim_push_change(source="google"))
    with pytest.raises(CapabilityError, match="creds_record_uid"):
        provider.apply_scim_plan(plan, dry_run=False)
    assert calls == []


def test_commander_apply_scim_google_with_creds_invokes_execute_with_record_kwarg(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []

    class FakeScimPushCommand:
        def execute(self, _params: object, **kwargs: Any) -> None:
            calls.append(kwargs)

    _install_scim_command_module(monkeypatch, FakeScimPushCommand)
    provider = _provider(monkeypatch)
    plan = _plan(_scim_push_change(source="google", creds_record_uid="REC-GCP"))
    provider.apply_scim_plan(plan, dry_run=False)
    assert len(calls) == 1
    assert calls[0]["source"] == "google"
    assert calls[0]["record"] == "REC-GCP"
    assert calls[0]["dry_run"] is False


def test_commander_apply_scim_ad_without_creds_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []

    class FakeScimPushCommand:
        def execute(self, _params: object, **kwargs: Any) -> None:
            calls.append(kwargs)

    _install_scim_command_module(monkeypatch, FakeScimPushCommand)
    provider = _provider(monkeypatch)
    plan = _plan(_scim_push_change(source="ad"))
    with pytest.raises(CapabilityError, match="creds_record_uid"):
        provider.apply_scim_plan(plan, dry_run=False)
    assert calls == []


def test_commander_apply_scim_record_source_omits_record_kwarg_without_creds(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []

    class FakeScimPushCommand:
        def execute(self, _params: object, **kwargs: Any) -> None:
            calls.append(kwargs)

    _install_scim_command_module(monkeypatch, FakeScimPushCommand)
    provider = _provider(monkeypatch)
    plan = _plan(_scim_push_change(source="record"))
    provider.apply_scim_plan(plan, dry_run=False)
    assert len(calls) == 1
    assert calls[0]["source"] == "record"
    assert "record" not in calls[0]


def test_commander_apply_scim_record_source_passes_record_when_creds_set(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []

    class FakeScimPushCommand:
        def execute(self, _params: object, **kwargs: Any) -> None:
            calls.append(kwargs)

    _install_scim_command_module(monkeypatch, FakeScimPushCommand)
    provider = _provider(monkeypatch)
    plan = _plan(_scim_push_change(source="record", creds_record_uid="REC-Explicit"))
    provider.apply_scim_plan(plan, dry_run=False)
    assert calls[0]["record"] == "REC-Explicit"
