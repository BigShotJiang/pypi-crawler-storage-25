"""Phase B PAM schema extension tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from dsk.core.manifest import load_manifest
from dsk.core.models import (
    DpopBinding,
    PamDatabase,
    PamMachine,
    PamUser,
    RotationWhenPolicy,
)


def _load_json_manifest(tmp_path: Path, payload: dict[str, object]):
    path = tmp_path / "environment.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    return load_manifest(path)


def test_pam_machine_aal_binding_roundtrips() -> None:
    machine = PamMachine(
        uid_ref="res.host",
        type="pamMachine",
        title="host",
        aal_binding={"aal_level": "AAL2", "hardware_bound": True},
    )

    roundtripped = PamMachine.model_validate(machine.model_dump(mode="json"))

    assert roundtripped.aal_binding is not None
    assert roundtripped.aal_binding.aal_level == "AAL2"
    assert roundtripped.aal_binding.hardware_bound is True


def test_resource_base_new_fields_default_to_none() -> None:
    machine = PamMachine(uid_ref="res.host", type="pamMachine", title="host")

    for field_name in (
        "aal_binding",
        "mtls_binding",
        "dpop_binding",
        "nist_identity",
        "rotation_when",
        "secret_class",
    ):
        assert getattr(machine, field_name) is None

    dumped = machine.model_dump(mode="json", exclude_none=True)
    assert "aal_binding" not in dumped
    assert "mtls_binding" not in dumped
    assert "dpop_binding" not in dumped
    assert "nist_identity" not in dumped
    assert "rotation_when" not in dumped
    assert "secret_class" not in dumped


def test_pam_user_aal_binding() -> None:
    user = PamUser(
        type="pamUser",
        title="admin",
        aal_binding={"aal_level": "AAL3", "phishing_resistant": True},
    )

    assert user.aal_binding is not None
    assert user.aal_binding.aal_level == "AAL3"
    assert user.aal_binding.phishing_resistant is True


def test_dpop_nonce_lifetime_validation() -> None:
    assert DpopBinding(nonce_lifetime_seconds=10).nonce_lifetime_seconds == 10
    assert DpopBinding(nonce_lifetime_seconds=3600).nonce_lifetime_seconds == 3600

    with pytest.raises(ValidationError):
        DpopBinding(nonce_lifetime_seconds=0)


def test_must_not_exist_roundtrip_via_load_manifest(tmp_path: Path) -> None:
    manifest = _load_json_manifest(
        tmp_path,
        {
            "version": "1",
            "name": "phase-b",
            "must_not_exist": ["res.retired"],
        },
    )

    assert manifest.must_not_exist == ["res.retired"]


def test_drift_policy_roundtrip_via_load_manifest(tmp_path: Path) -> None:
    manifest = _load_json_manifest(
        tmp_path,
        {
            "version": "1",
            "name": "phase-b",
            "drift_policy": {
                "mode": "block_pipeline",
                "max_drift_fields": 2,
                "notify_slack": "#pam-alerts",
                "auto_approve": True,
            },
        },
    )

    assert manifest.drift_policy is not None
    assert manifest.drift_policy.mode == "block_pipeline"
    assert manifest.drift_policy.max_drift_fields == 2
    assert manifest.drift_policy.notify_slack == "#pam-alerts"
    assert manifest.drift_policy.auto_approve is True


def test_secret_class_on_pam_database() -> None:
    database = PamDatabase(
        uid_ref="db.prod",
        type="pamDatabase",
        title="prod",
        database_type="mysql",
        secret_class="db-prod",
    )

    roundtripped = PamDatabase.model_validate(database.model_dump(mode="json"))
    assert roundtripped.secret_class == "db-prod"


def test_rotation_when_anomaly_score_validation() -> None:
    assert RotationWhenPolicy(on_anomaly_score_exceed=0.0).on_anomaly_score_exceed == 0.0
    assert RotationWhenPolicy(on_anomaly_score_exceed=1.0).on_anomaly_score_exceed == 1.0

    with pytest.raises(ValidationError):
        RotationWhenPolicy(on_anomaly_score_exceed=-0.1)

    with pytest.raises(ValidationError):
        RotationWhenPolicy(on_anomaly_score_exceed=1.1)
