"""Tests for pipeline ephemeral environment models."""

from pathlib import Path

import pytest
import yaml


def test_ephemeral_env_defaults():
    from dsk.core.models_pipeline_env import PipelineEphemeralEnvironment, PipelineProvider

    env = PipelineEphemeralEnvironment(name="test")
    assert env.provider == PipelineProvider.github_actions
    assert env.destroy_on_completion is True
    assert env.isolate_per_pr is True
    assert env.max_lifetime_minutes == 60


def test_pipeline_manifest_round_trip():
    from dsk.core.models_pipeline_env import PipelineEphemeralManifestV1

    example = Path(__file__).parent.parent / "examples/pipeline-envs/acme-pipeline-envs.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = PipelineEphemeralManifestV1(**data)
    assert manifest.schema_ == "pipeline-ephemeral-environment.v1"
    assert len(manifest.environments) == 2
    pr_env = manifest.environments[0]
    assert pr_env.isolate_per_pr is True
    assert pr_env.resources[0].rotate_on_destroy is True
    assert pr_env.resources[0].inject_as_env == "TEST_DATABASE_URL"


def test_resource_spec_defaults():
    from dsk.core.models_pipeline_env import EphemeralResourceSpec

    spec = EphemeralResourceSpec(uid_ref="res.test")
    assert spec.rotate_on_destroy is True
    assert spec.inject_as_env is None


def test_schema_alias():
    from dsk.core.models_pipeline_env import PipelineEphemeralManifestV1

    m = PipelineEphemeralManifestV1(
        **{"schema": "pipeline-ephemeral-environment.v1", "name": "test"}
    )
    assert m.schema_ == "pipeline-ephemeral-environment.v1"


def test_pipeline_ephemeral_environment_rejects_max_lifetime_below_minimum() -> None:
    """Lifetime is bounded to at least 5 minutes (CI runner safety)."""
    from pydantic import ValidationError

    from dsk.core.models_pipeline_env import PipelineEphemeralEnvironment

    with pytest.raises(ValidationError):
        PipelineEphemeralEnvironment(name="short", max_lifetime_minutes=2)


def test_ephemeral_resource_spec_accepts_inject_as_secret() -> None:
    """CI secret name injection is optional alongside env injection."""
    from dsk.core.models_pipeline_env import EphemeralResourceSpec

    spec = EphemeralResourceSpec(
        uid_ref="res.db",
        inject_as_env="DB_URL",
        inject_as_secret="DATABASE_URL",
    )
    assert spec.inject_as_env == "DB_URL"
    assert spec.inject_as_secret == "DATABASE_URL"
