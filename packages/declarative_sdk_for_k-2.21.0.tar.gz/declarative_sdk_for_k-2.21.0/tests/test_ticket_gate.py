"""Tests for ticket gate integration (offline/unit)."""

from __future__ import annotations

import json
import urllib.error
from io import BytesIO
from unittest.mock import MagicMock, patch

import pytest

from dsk.integrations import ticket_gate


def test_check_ticket_unknown_system():
    from dsk.integrations.ticket_gate import TicketGateError, check_ticket

    with pytest.raises(TicketGateError, match="Unknown ticket system"):
        check_ticket("INFRA-1", system="pagerduty")


def test_check_ticket_jira_missing_env():
    import os

    from dsk.integrations.ticket_gate import TicketGateError, check_ticket

    env_backup = {k: os.environ.pop(k, None) for k in ["JIRA_BASE_URL", "JIRA_TOKEN"]}
    try:
        with pytest.raises(TicketGateError, match="JIRA_BASE_URL"):
            check_ticket("INFRA-1", system="jira")
    finally:
        for k, v in env_backup.items():
            if v is not None:
                os.environ[k] = v


def test_check_ticket_servicenow_missing_env():
    import os

    from dsk.integrations.ticket_gate import TicketGateError, check_ticket

    env_backup = {k: os.environ.pop(k, None) for k in ["SNOW_INSTANCE", "SNOW_TOKEN"]}
    try:
        with pytest.raises(TicketGateError, match="SNOW_INSTANCE"):
            check_ticket("CHG0001", system="servicenow")
    finally:
        for k, v in env_backup.items():
            if v is not None:
                os.environ[k] = v


def test_jira_check_approved(monkeypatch):
    monkeypatch.setenv("JIRA_BASE_URL", "https://acme.atlassian.net")
    monkeypatch.setenv("JIRA_TOKEN", "test-token")

    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps({"fields": {"status": {"name": "Approved"}}}).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)

    with patch("urllib.request.urlopen", return_value=mock_resp):
        result = ticket_gate._jira_check("INFRA-789", "Approved")
    assert result is True


def test_jira_check_not_approved(monkeypatch):
    monkeypatch.setenv("JIRA_BASE_URL", "https://acme.atlassian.net")
    monkeypatch.setenv("JIRA_TOKEN", "test-token")

    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps({"fields": {"status": {"name": "In Review"}}}).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)

    with patch("urllib.request.urlopen", return_value=mock_resp):
        result = ticket_gate._jira_check("INFRA-789", "Approved")
    assert result is False


def test_check_ticket_jira_blocked_when_wrong_status(monkeypatch):
    monkeypatch.setenv("JIRA_BASE_URL", "https://acme.atlassian.net")
    monkeypatch.setenv("JIRA_TOKEN", "test-token")

    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(
        {"fields": {"status": {"name": "In Progress"}}},
    ).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)

    with patch.object(ticket_gate.urllib.request, "urlopen", return_value=mock_resp):
        with pytest.raises(ticket_gate.TicketGateError, match="blocked by ticket gate"):
            ticket_gate.check_ticket("INFRA-789", system="jira", required_status="Approved")


def test_jira_http_error_raises_ticket_gate_error(monkeypatch):
    monkeypatch.setenv("JIRA_BASE_URL", "https://acme.atlassian.net")
    monkeypatch.setenv("JIRA_TOKEN", "test-token")

    def fake_urlopen(_req: object, **_kwargs: object) -> None:
        raise urllib.error.HTTPError("http://test", 404, "nf", hdrs={}, fp=BytesIO(b""))

    monkeypatch.setattr(ticket_gate.urllib.request, "urlopen", fake_urlopen)

    with pytest.raises(ticket_gate.TicketGateError, match="Jira API error.+404"):
        ticket_gate.check_ticket("INFRA-789", system="jira")


def test_check_ticket_servicenow_success(monkeypatch):
    monkeypatch.setenv("SNOW_INSTANCE", "https://acct.service-now.com")
    monkeypatch.setenv("SNOW_TOKEN", "snow-token")

    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(
        {"result": [{"approval": "approved", "state": "3"}]},
    ).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)

    monkeypatch.setattr(ticket_gate.urllib.request, "urlopen", MagicMock(return_value=mock_resp))

    ticket_gate.check_ticket("CHG0001234", system="servicenow", required_status="approved")


def test_servicenow_no_rows_raises_ticket_gate_error(monkeypatch):
    monkeypatch.setenv("SNOW_INSTANCE", "https://acct.service-now.com")
    monkeypatch.setenv("SNOW_TOKEN", "snow-token")

    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps({"result": []}).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)

    monkeypatch.setattr(ticket_gate.urllib.request, "urlopen", MagicMock(return_value=mock_resp))

    with pytest.raises(ticket_gate.TicketGateError, match="not found"):
        ticket_gate._servicenow_check("CHG999", "approved")


def test_servicenow_http_error_raises_ticket_gate_error(monkeypatch):
    monkeypatch.setenv("SNOW_INSTANCE", "https://acct.service-now.com")
    monkeypatch.setenv("SNOW_TOKEN", "snow-token")

    def boom(_req: object, **_kwargs: object) -> None:
        raise urllib.error.HTTPError("http://snow", 500, "err", hdrs={}, fp=BytesIO(b""))

    monkeypatch.setattr(ticket_gate.urllib.request, "urlopen", boom)

    with pytest.raises(ticket_gate.TicketGateError, match="ServiceNow API error.+500"):
        ticket_gate.check_ticket("CHG1", system="servicenow")
