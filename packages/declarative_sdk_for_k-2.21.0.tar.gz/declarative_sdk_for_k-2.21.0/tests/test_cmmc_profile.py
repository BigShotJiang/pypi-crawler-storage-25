"""Tests for CMMC 2.0 compliance profile manifest models."""

from pathlib import Path

import pytest
import yaml


def test_cmmc_defaults():
    from dsk.core.models_cmmc import CmmcLevel, CmmcProfileManifestV1

    m = CmmcProfileManifestV1(**{"schema": "cmmc-profile.v1", "name": "test"})
    assert m.schema_ == "cmmc-profile.v1"
    assert m.target_level == CmmcLevel.level2
    assert m.controls == []
    assert m.evidence_output_dir == "cmmc-evidence/"


def test_cmmc_round_trip():
    from dsk.core.models_cmmc import (
        CmmcControlStatus,
        CmmcDomain,
        CmmcLevel,
        CmmcProfileManifestV1,
    )

    example = Path(__file__).parent.parent / "examples/cmmc/acme-defense-cmmc-profile.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = CmmcProfileManifestV1(**data)
    assert manifest.schema_ == "cmmc-profile.v1"
    assert manifest.target_level == CmmcLevel.level2
    assert len(manifest.controls) == 5
    ac_control = manifest.controls[0]
    assert ac_control.practice_id == "3.1.1"
    assert ac_control.domain == CmmcDomain.access_control
    assert ac_control.status == CmmcControlStatus.met
    partial = manifest.controls[3]
    assert partial.status == CmmcControlStatus.partially_met
    assert partial.c3pao_notes is not None


def test_cmmc_scope_config():
    from dsk.core.models_cmmc import CmmcProfileManifestV1

    example = Path(__file__).parent.parent / "examples/cmmc/acme-defense-cmmc-profile.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = CmmcProfileManifestV1(**data)
    assert len(manifest.scope.cui_systems) == 3
    assert manifest.scope.c3pao_org == "CyberShield Assessors LLC"


def test_cmmc_schema_alias():
    from dsk.core.models_cmmc import CmmcProfileManifestV1

    m = CmmcProfileManifestV1(**{"schema": "cmmc-profile.v1", "name": "t"})
    assert m.schema_ == "cmmc-profile.v1"


def test_cmmc_control_mapping_requires_practice_id():
    """CmmcControlMapping rejects missing practice_id."""
    from pydantic import ValidationError

    from dsk.core.models_cmmc import CmmcControlMapping, CmmcControlStatus, CmmcDomain

    with pytest.raises(ValidationError):
        CmmcControlMapping(
            domain=CmmcDomain.access_control,
            description="x",
            status=CmmcControlStatus.met,
        )


def test_cmmc_level1_enum_loads():
    """target_level accepts level-1 string."""
    from dsk.core.models_cmmc import CmmcLevel, CmmcProfileManifestV1

    m = CmmcProfileManifestV1(
        **{"schema": "cmmc-profile.v1", "name": "l1", "target_level": "level-1"}
    )
    assert m.target_level == CmmcLevel.level1


def test_cmmc_custom_evidence_output_dir():
    """evidence_output_dir can be overridden in manifest."""
    from dsk.core.models_cmmc import CmmcProfileManifestV1

    m = CmmcProfileManifestV1(
        **{
            "schema": "cmmc-profile.v1",
            "name": "custom",
            "evidence_output_dir": "out/custom/",
        }
    )
    assert m.evidence_output_dir == "out/custom/"


def test_is_empty_compliance_payload_empty_string() -> None:
    """_is_empty_compliance_payload returns True for empty string."""
    from dsk.cli._report.compliance import _is_empty_compliance_payload

    assert _is_empty_compliance_payload("") is True
    assert _is_empty_compliance_payload("   ") is True


def test_is_empty_compliance_payload_null_json() -> None:
    """_is_empty_compliance_payload returns True for null/empty JSON."""
    from dsk.cli._report.compliance import _is_empty_compliance_payload

    assert _is_empty_compliance_payload("null") is True
    assert _is_empty_compliance_payload("[]") is True
    assert _is_empty_compliance_payload("{}") is True


def test_is_empty_compliance_payload_empty_nodes() -> None:
    """_is_empty_compliance_payload returns True when nodes list is empty."""
    import json

    from dsk.cli._report.compliance import _is_empty_compliance_payload

    payload = json.dumps({"nodes": [], "other": "data"})
    assert _is_empty_compliance_payload(payload) is True


def test_is_empty_compliance_payload_nonempty() -> None:
    """_is_empty_compliance_payload returns False for non-empty payload."""
    import json

    from dsk.cli._report.compliance import _is_empty_compliance_payload

    payload = json.dumps({"nodes": [{"name": "root"}]})
    assert _is_empty_compliance_payload(payload) is False
