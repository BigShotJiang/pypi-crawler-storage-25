"""keeper-enterprise.v1 offline import path coverage."""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

import yaml
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_CONFLICT, EXIT_OK
from dsk.core.metadata import MANAGER_NAME
from dsk.providers import MockProvider

cli_main_module = importlib.import_module("dsk.cli.main")

MANIFEST_NAME = "enterprise"


def _run(args: list[str]):
    return CliRunner().invoke(main, args, catch_exceptions=False)


def _doc() -> dict[str, Any]:
    return {
        "schema": "keeper-enterprise.v1",
        "nodes": [{"uid_ref": "node.root", "name": "Root"}],
        "users": [
            {
                "uid_ref": "user.alice",
                "email": "alice@example.com",
                "node_uid_ref": "keeper-enterprise:nodes:node.root",
            }
        ],
    }


def _write_manifest(tmp_path: Path, document: dict[str, Any] | None = None) -> Path:
    path = tmp_path / "enterprise.yaml"
    path.write_text(yaml.safe_dump(document or _doc(), sort_keys=False), encoding="utf-8")
    return path


def _live_from_doc(document: dict[str, Any] | None = None) -> dict[str, list[dict[str, Any]]]:
    source = document or _doc()
    return {
        "nodes": [dict(row) for row in source.get("nodes", [])],
        "users": [dict(row) for row in source.get("users", [])],
        "roles": [dict(row) for row in source.get("roles", [])],
        "teams": [dict(row) for row in source.get("teams", [])],
        "enforcements": [dict(row) for row in source.get("enforcements", [])],
        "aliases": [dict(row) for row in source.get("aliases", [])],
    }


def test_enterprise_import_plan_shows_unmanaged_records_and_writes_markers(
    tmp_path: Path,
    monkeypatch,
) -> None:
    path = _write_manifest(tmp_path)
    provider = MockProvider(MANIFEST_NAME)
    provider.seed_enterprise_state(_live_from_doc())
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "import", str(path), "--auto-approve"])

    assert result.exit_code == EXIT_OK, result.output
    assert "node.root" in result.output
    assert "user.alice" in result.output
    assert "~2 update" in result.output
    assert "marker_written=True" in result.output
    markers = provider.enterprise_markers()
    assert len(markers) == 2
    assert {marker["manager"] for marker in markers.values()} == {MANAGER_NAME}


def test_enterprise_import_conflicts_on_already_managed_record(
    tmp_path: Path,
    monkeypatch,
) -> None:
    path = _write_manifest(tmp_path)
    live = _live_from_doc()
    live["users"][0]["manager"] = "other-manager"
    provider = MockProvider(MANIFEST_NAME)
    provider.seed_enterprise_state(live)
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "import", str(path), "--auto-approve"])
    combined = result.output + getattr(result, "stderr", "")

    assert result.exit_code == EXIT_CONFLICT, combined
    assert "managed by other manager" in combined
    markers = provider.enterprise_markers()
    assert len(markers) == 1
    assert next(iter(markers.values()))["manager"] == "other-manager"


def test_enterprise_import_dry_run_shows_plan_without_writing_markers(
    tmp_path: Path,
    monkeypatch,
) -> None:
    path = _write_manifest(tmp_path)
    provider = MockProvider(MANIFEST_NAME)
    provider.seed_enterprise_state(_live_from_doc())
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "import", str(path), "--dry-run"])

    assert result.exit_code == EXIT_OK, result.output
    assert "node.root" in result.output
    assert "user.alice" in result.output
    assert "~2 update" in result.output
    assert provider.enterprise_markers() == {}


def test_enterprise_import_idempotent_after_first_apply(
    tmp_path: Path,
    monkeypatch,
) -> None:
    """Second import after first apply must produce no additional changes."""
    path = _write_manifest(tmp_path)
    provider = MockProvider(MANIFEST_NAME)
    provider.seed_enterprise_state(_live_from_doc())
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    first = _run(["--provider", "mock", "import", str(path), "--auto-approve"])
    assert first.exit_code == EXIT_OK, first.output

    second = _run(["--provider", "mock", "import", str(path), "--auto-approve"])
    assert second.exit_code == EXIT_OK, second.output


def test_enterprise_import_output_mentions_update_and_uid_refs(
    tmp_path: Path,
    monkeypatch,
) -> None:
    """Import output must mention both uid_refs from the manifest."""
    path = _write_manifest(tmp_path)
    provider = MockProvider(MANIFEST_NAME)
    provider.seed_enterprise_state(_live_from_doc())
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "import", str(path), "--auto-approve"])

    assert "node.root" in result.output
    assert "user.alice" in result.output


def test_enterprise_import_empty_manifest_exits_ok(
    tmp_path: Path,
    monkeypatch,
) -> None:
    """Import of a manifest with no rows must exit OK without error."""
    empty_doc = {
        "schema": "keeper-enterprise.v1",
        "nodes": [],
        "users": [],
    }
    path = _write_manifest(tmp_path, empty_doc)
    provider = MockProvider(MANIFEST_NAME)
    provider.seed_enterprise_state(_live_from_doc(empty_doc))
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "import", str(path), "--auto-approve"])
    assert result.exit_code == EXIT_OK, result.output
