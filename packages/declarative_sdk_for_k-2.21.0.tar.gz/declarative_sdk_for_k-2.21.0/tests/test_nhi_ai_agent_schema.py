"""nhi-agent.v1 and ai-agent.v1 offline schema, model, and round-trip tests."""

from __future__ import annotations

import json
from typing import Any

import pytest

from dsk.core.errors import SchemaError
from dsk.core.manifest import load_declarative_manifest_string
from dsk.core.models_ai_agent import (
    AI_AGENT_FAMILY,
    AiAgentManifest,
    AiAgentResource,
    load_ai_agent_manifest,
)
from dsk.core.models_nhi import (
    NHI_FAMILY,
    NhiAgentManifest,
    NhiAgentResource,
    load_nhi_manifest,
)
from dsk.core.planner import Plan
from dsk.core.schema import load_schema_for_family, validate_manifest

# ---------------------------------------------------------------------------
# Fixtures — nhi-agent.v1
# ---------------------------------------------------------------------------


def _nhi_minimal() -> dict[str, Any]:
    return {"schema": NHI_FAMILY}


def _nhi_full() -> dict[str, Any]:
    return {
        "schema": NHI_FAMILY,
        "resources": [
            {
                "uid_ref": "nhi.ci-runner",
                "name": "CI Pipeline Runner",
                "type": "service_account",
                "purpose": "GitHub Actions deployment runner",
                "scope": ["vault:read", "pam:connect"],
                "allowed_tools": ["github-actions", "dsk"],
                "expiration": None,
                "credential_ref": "keeper-ksm:apps:ci-runner-app",
                "tags": {"env": "prod", "team": "platform"},
            },
            {
                "uid_ref": "nhi.ai-reviewer",
                "name": "AI Code Reviewer",
                "type": "ai_agent",
                "purpose": "Automated PR review agent",
                "scope": ["vault:read"],
                "allowed_tools": ["github-api"],
                "expiration": "2026-12-31T00:00:00Z",
            },
        ],
    }


# ---------------------------------------------------------------------------
# Fixtures — ai-agent.v1
# ---------------------------------------------------------------------------


def _ai_minimal() -> dict[str, Any]:
    return {"schema": AI_AGENT_FAMILY}


def _ai_full() -> dict[str, Any]:
    return {
        "schema": AI_AGENT_FAMILY,
        "resources": [
            {
                "uid_ref": "ai.pam-auditor",
                "name": "PAM Audit Agent",
                "purpose": "Automated PAM configuration review and drift detection",
                "scope": ["pam:read", "vault:read"],
                "allowed_tools": ["dsk", "keeper-cli"],
                "expiration": None,
                "credential_ref": "keeper-ksm:apps:audit-agent-app",
                "tags": {"tier": "internal"},
            },
            {
                "uid_ref": "ai.onboarding-bot",
                "name": "Onboarding Bot",
                "purpose": "Automate new-hire vault provisioning",
                "scope": ["vault:write", "pam:connect"],
                "allowed_tools": ["dsk"],
                "expiration": "2027-01-01T00:00:00Z",
                "guardian_policy": "keeper-vault:records:guardian-policy-uid",
            },
        ],
    }


# ---------------------------------------------------------------------------
# nhi-agent.v1 — schema load
# ---------------------------------------------------------------------------


def test_nhi_schema_is_packaged() -> None:
    schema = load_schema_for_family(NHI_FAMILY)

    assert schema["title"] == NHI_FAMILY
    assert "resources" in schema["properties"]
    assert schema["x-keeper-live-proof"]["status"] == "upstream-gap"


# ---------------------------------------------------------------------------
# nhi-agent.v1 — validate_manifest
# ---------------------------------------------------------------------------


def test_nhi_validate_minimal() -> None:
    assert validate_manifest(_nhi_minimal()) == NHI_FAMILY


def test_nhi_validate_full() -> None:
    assert validate_manifest(_nhi_full()) == NHI_FAMILY


def test_nhi_invalid_type_enum() -> None:
    doc = _nhi_full()
    doc["resources"][0]["type"] = "robot"

    with pytest.raises(SchemaError) as exc:
        validate_manifest(doc)

    assert "not one of" in exc.value.reason or "failed enum validation" in exc.value.reason


def test_nhi_missing_required_name() -> None:
    doc = _nhi_full()
    del doc["resources"][0]["name"]

    with pytest.raises(SchemaError):
        validate_manifest(doc)


def test_nhi_missing_required_type() -> None:
    doc = _nhi_full()
    del doc["resources"][0]["type"]

    with pytest.raises(SchemaError):
        validate_manifest(doc)


def test_nhi_rejects_unknown_property() -> None:
    doc = _nhi_full()
    doc["resources"][0]["unexpected_field"] = True

    with pytest.raises(SchemaError) as exc:
        validate_manifest(doc)

    assert (
        "Additional properties" in exc.value.reason
        or "failed additionalProperties validation" in exc.value.reason
    )


# ---------------------------------------------------------------------------
# nhi-agent.v1 — typed load + round-trip
# ---------------------------------------------------------------------------


def test_nhi_load_returns_typed_model() -> None:
    loaded = load_declarative_manifest_string(json.dumps(_nhi_full()), suffix=".json")

    assert isinstance(loaded, NhiAgentManifest)
    assert loaded.resources[0].uid_ref == "nhi.ci-runner"
    assert loaded.resources[0].type == "service_account"


def test_nhi_manifest_roundtrip() -> None:
    manifest = load_nhi_manifest(_nhi_full())
    dumped = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    reloaded = load_declarative_manifest_string(json.dumps(dumped), suffix=".json")

    assert isinstance(reloaded, NhiAgentManifest)
    assert reloaded.model_dump(mode="json", exclude_none=True, by_alias=True) == dumped


def test_nhi_minimal_manifest_roundtrip() -> None:
    manifest = load_nhi_manifest(_nhi_minimal())

    assert isinstance(manifest, NhiAgentManifest)
    assert manifest.resources == []


def test_nhi_rejects_duplicate_uid_refs() -> None:
    doc = _nhi_full()
    doc["resources"][1]["uid_ref"] = "nhi.ci-runner"

    with pytest.raises(SchemaError) as exc:
        load_nhi_manifest(doc)

    assert "duplicate uid_ref" in exc.value.reason


def test_nhi_wrong_family_rejected() -> None:
    doc = {"schema": AI_AGENT_FAMILY, "resources": []}

    with pytest.raises(SchemaError) as exc:
        load_nhi_manifest(doc)

    assert "nhi-agent.v1" in exc.value.reason


# ---------------------------------------------------------------------------
# nhi-agent.v1 — CommanderCliProvider apply stub (upstream GA)
# ---------------------------------------------------------------------------


def test_apply_nhi_plan_raises_capability_until_pam_api_ga(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Commander apply_nhi_plan blocks until NHI PAM API GA (no DSK_PREVIEW bypass)."""
    monkeypatch.delenv("DSK_PREVIEW", raising=False)
    from dsk.core.errors import CapabilityError
    from dsk.providers.commander_cli import CommanderCliProvider

    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    provider._manifest_source = {}  # type: ignore[attr-defined]
    with pytest.raises(CapabilityError) as exc:
        provider.apply_nhi_plan(Plan("t", [], []))
    assert "pending NHI PAM API GA" in (exc.value.next_action or "")


# ---------------------------------------------------------------------------
# ai-agent.v1 — schema load
# ---------------------------------------------------------------------------


def test_ai_schema_is_packaged() -> None:
    schema = load_schema_for_family(AI_AGENT_FAMILY)

    assert schema["title"] == AI_AGENT_FAMILY
    assert "resources" in schema["properties"]
    assert schema["x-keeper-live-proof"]["status"] == "upstream-gap"


# ---------------------------------------------------------------------------
# ai-agent.v1 — validate_manifest
# ---------------------------------------------------------------------------


def test_ai_validate_minimal() -> None:
    assert validate_manifest(_ai_minimal()) == AI_AGENT_FAMILY


def test_ai_validate_full() -> None:
    assert validate_manifest(_ai_full()) == AI_AGENT_FAMILY


def test_ai_missing_required_purpose() -> None:
    doc = _ai_full()
    del doc["resources"][0]["purpose"]

    with pytest.raises(SchemaError):
        validate_manifest(doc)


def test_ai_missing_required_scope() -> None:
    doc = _ai_full()
    del doc["resources"][0]["scope"]

    with pytest.raises(SchemaError):
        validate_manifest(doc)


def test_ai_rejects_unknown_property() -> None:
    doc = _ai_full()
    doc["resources"][0]["rogue_field"] = "bad"

    with pytest.raises(SchemaError) as exc:
        validate_manifest(doc)

    assert (
        "Additional properties" in exc.value.reason
        or "failed additionalProperties validation" in exc.value.reason
    )


# ---------------------------------------------------------------------------
# ai-agent.v1 — typed load + round-trip
# ---------------------------------------------------------------------------


def test_ai_load_returns_typed_model() -> None:
    loaded = load_declarative_manifest_string(json.dumps(_ai_full()), suffix=".json")

    assert isinstance(loaded, AiAgentManifest)
    assert loaded.resources[0].uid_ref == "ai.pam-auditor"
    assert loaded.resources[0].purpose == "Automated PAM configuration review and drift detection"


def test_ai_manifest_roundtrip() -> None:
    manifest = load_ai_agent_manifest(_ai_full())
    dumped = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    reloaded = load_declarative_manifest_string(json.dumps(dumped), suffix=".json")

    assert isinstance(reloaded, AiAgentManifest)
    assert reloaded.model_dump(mode="json", exclude_none=True, by_alias=True) == dumped


def test_ai_minimal_manifest_roundtrip() -> None:
    manifest = load_ai_agent_manifest(_ai_minimal())

    assert isinstance(manifest, AiAgentManifest)
    assert manifest.resources == []


def test_ai_rejects_duplicate_uid_refs() -> None:
    doc = _ai_full()
    doc["resources"][1]["uid_ref"] = "ai.pam-auditor"

    with pytest.raises(SchemaError) as exc:
        load_ai_agent_manifest(doc)

    assert "duplicate uid_ref" in exc.value.reason


def test_ai_wrong_family_rejected() -> None:
    doc = {"schema": NHI_FAMILY, "resources": []}

    with pytest.raises(SchemaError) as exc:
        load_ai_agent_manifest(doc)

    assert "ai-agent.v1" in exc.value.reason


# ---------------------------------------------------------------------------
# Typed resource models — security / governance fields
# ---------------------------------------------------------------------------


def test_nhi_resource_audit_policy_fields() -> None:
    r = NhiAgentResource.model_validate(
        {
            "uid_ref": "nhi.governance-test",
            "name": "Governed NHI",
            "type": "service_account",
            "max_rotation_age_days": 90,
            "require_expiration": True,
            "expiration": "2027-01-01",
        }
    )
    assert r.max_rotation_age_days == 90
    assert r.require_expiration is True
    assert r.expiration == "2027-01-01"


def test_nhi_resource_require_expiration_validation_error() -> None:
    with pytest.raises(SchemaError):
        NhiAgentResource.model_validate(
            {
                "uid_ref": "nhi.no-expiration",
                "name": "Bad",
                "type": "service_account",
                "require_expiration": True,
            }
        )


def test_ai_agent_excessive_agency_fields() -> None:
    r = AiAgentResource.model_validate(
        {
            "uid_ref": "ai.secure-agent",
            "name": "Secure Agent",
            "purpose": "scoped automation",
            "scope": ["vault:read", "pam:read", "audit:read"],
            "max_scope_count": 3,
            "prompt_injection_guard": True,
            "memory_isolation": True,
        }
    )
    assert r.max_scope_count == 3
    assert r.prompt_injection_guard is True
    assert r.memory_isolation is True
