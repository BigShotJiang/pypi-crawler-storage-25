"""Tests for Kubernetes PAM operator (offline — no kopf/k8s required)."""

from __future__ import annotations

import importlib.util
import pathlib
import subprocess
from unittest.mock import MagicMock, patch

_OPERATOR_PATH = pathlib.Path("kubernetes/operator/operator.py")


def _load_operator():  # type: ignore[return]
    if not _OPERATOR_PATH.exists():
        return None
    spec = importlib.util.spec_from_file_location("operator_mod", _OPERATOR_PATH)
    if not (spec and spec.loader):
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


def test_operator_module_importable_without_kopf() -> None:
    """Module must not crash on import even if kopf is not installed."""
    mod = _load_operator()
    if mod is None:
        return
    assert hasattr(mod, "_run_dsk_apply")


def test_run_dsk_apply_plan_called(tmp_path: object) -> None:
    """_run_dsk_apply should call dsk plan with the manifest."""
    mod = _load_operator()
    if mod is None:
        return

    fake_result = MagicMock(returncode=0, stdout='{"summary": {"noop": 3}}', stderr="")
    with patch("subprocess.run", return_value=fake_result) as run:
        result = mod._run_dsk_apply("family: pam-environment.v1\n", {}, dry_run=True)
    assert result["exit_code"] == 0
    assert result["summary"].get("noop") == 3
    assert run.call_args.kwargs["timeout"] == mod.DEFAULT_OPERATOR_COMMAND_TIMEOUT_SECONDS


def test_run_dsk_apply_non_json_stdout_returns_empty_summary() -> None:
    """_run_dsk_apply should not crash when dsk stdout is not valid JSON."""
    mod = _load_operator()
    if mod is None:
        return

    fake_result = MagicMock(returncode=1, stdout="error: connection refused\n", stderr="")
    with patch("subprocess.run", return_value=fake_result):
        result = mod._run_dsk_apply("schema: keeper-vault.v1\nrecords: []\n", {}, dry_run=True)
    assert result["exit_code"] == 1
    assert result["summary"] == {}


def test_run_dsk_apply_oversized_stdout_returns_empty_summary(
    monkeypatch,
) -> None:  # type: ignore[no-untyped-def]
    mod = _load_operator()
    if mod is None:
        return

    monkeypatch.setenv("DSK_OPERATOR_MAX_STDOUT_BYTES", "2")
    fake_result = MagicMock(returncode=0, stdout='{"summary": {}}', stderr="")
    with patch("subprocess.run", return_value=fake_result):
        result = mod._run_dsk_apply("schema: keeper-vault.v1\nrecords: []\n", {}, dry_run=True)
    assert result["exit_code"] == 0
    assert result["summary"] == {}


def test_run_dsk_apply_timeout_returns_124() -> None:
    mod = _load_operator()
    if mod is None:
        return

    with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="dsk", timeout=1)):
        result = mod._run_dsk_apply("schema: keeper-vault.v1\nrecords: []\n", {}, dry_run=True)
    assert result["exit_code"] == 124


def test_run_dsk_apply_dry_run_skips_apply_command() -> None:
    """When dry_run=True, dsk apply must NOT be called."""
    mod = _load_operator()
    if mod is None:
        return

    calls: list[list[str]] = []

    def fake_run(cmd, **_kwargs):  # type: ignore[no-untyped-def]
        calls.append(cmd)
        return MagicMock(returncode=0, stdout='{"summary": {"create": 1}}', stderr="")

    with patch("subprocess.run", side_effect=fake_run):
        mod._run_dsk_apply("schema: keeper-vault.v1\nrecords: []\n", {}, dry_run=True)

    apply_calls = [c for c in calls if "apply" in c]
    assert apply_calls == [], f"apply must not be called in dry_run, got: {apply_calls}"


def test_operator_exposes_require_kopf_guard() -> None:
    """_require_kopf must raise ImportError when kopf is unavailable."""
    mod = _load_operator()
    if mod is None:
        return

    original = mod._KOPF_AVAILABLE
    mod._KOPF_AVAILABLE = False
    try:
        try:
            mod._require_kopf()
            assert False, "Expected ImportError"
        except ImportError as exc:
            assert "kopf" in str(exc).lower()
    finally:
        mod._KOPF_AVAILABLE = original
