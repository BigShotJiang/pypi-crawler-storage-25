"""CommanderCliProvider EPM policy apply tests."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.planner import Plan
from dsk.providers import commander_cli
from dsk.providers.commander_cli import CommanderCliProvider


def _plan(*changes: Change) -> Plan:
    return Plan(
        manifest_name="epm-apply-test",
        changes=list(changes),
        order=[change.uid_ref or "" for change in changes],
    )


def _provider(monkeypatch: pytest.MonkeyPatch) -> tuple[CommanderCliProvider, object]:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    params = object()
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda operation: operation())
    return provider, params


def _install_pedm_module(
    monkeypatch: pytest.MonkeyPatch,
    *,
    add_command: type[Any] | None = None,
    delete_command: type[Any] | None = None,
    edit_command: type[Any] | None = None,
) -> None:
    keepercommander_module = types.ModuleType("keepercommander")
    commands_module = types.ModuleType("keepercommander.commands")
    pedm_module = types.ModuleType("keepercommander.commands.pedm")
    pedm_admin_module = types.ModuleType("keepercommander.commands.pedm.pedm_admin")
    setattr(keepercommander_module, "__path__", [])
    setattr(commands_module, "__path__", [])
    setattr(pedm_module, "__path__", [])
    setattr(keepercommander_module, "commands", commands_module)
    setattr(commands_module, "pedm", pedm_module)
    setattr(pedm_module, "pedm_admin", pedm_admin_module)
    if add_command is not None:
        pedm_admin_module.PedmPolicyAddCommand = add_command
    if delete_command is not None:
        pedm_admin_module.PedmPolicyDeleteCommand = delete_command
    if edit_command is not None:
        pedm_admin_module.PedmPolicyEditCommand = edit_command
    monkeypatch.setitem(sys.modules, "keepercommander", keepercommander_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", commands_module)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.pedm", pedm_module)
    monkeypatch.setitem(
        sys.modules,
        "keepercommander.commands.pedm.pedm_admin",
        pedm_admin_module,
    )


def test_epm_policy_add_called_on_create(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, params = _provider(monkeypatch)
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakePedmPolicyAddCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    _install_pedm_module(monkeypatch, add_command=FakePedmPolicyAddCommand)
    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="allow-tools",
        resource_type="epm_policy_rule",
        title="Allow Tools",
        after={
            "name": "Allow Tools",
            "policy_type": "elevation",
            "control": ["allow"],
            "status": "enforce",
        },
    )

    outcomes = provider.apply_epm_policy_plan(_plan(change))

    assert [outcome.action for outcome in outcomes] == ["create"]
    assert calls == [
        (
            params,
            {
                "policy_name": "Allow Tools",
                "policy_type": "elevation",
                "control": ["allow"],
                "status": "enforce",
            },
        )
    ]


def test_epm_policy_delete_called_on_delete(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, params = _provider(monkeypatch)
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakePedmPolicyDeleteCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    _install_pedm_module(monkeypatch, delete_command=FakePedmPolicyDeleteCommand)
    change = Change(
        kind=ChangeKind.DELETE,
        uid_ref="old-tools",
        resource_type="epm_policy_rule",
        title="Old Tools",
        keeper_uid="POLICY123",
        before={"name": "Old Tools"},
    )

    outcomes = provider.apply_epm_policy_plan(_plan(change))

    assert [outcome.action for outcome in outcomes] == ["delete"]
    assert calls == [(params, {"policy": ["POLICY123"]})]


def test_epm_dry_run_skips(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, _params = _provider(monkeypatch)
    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="allow-tools",
        resource_type="epm_policy_rule",
        title="Allow Tools",
        after={"name": "Allow Tools", "control": ["allow"]},
    )

    outcomes = provider.apply_epm_policy_plan(_plan(change), dry_run=True)

    assert len(outcomes) == 1
    assert outcomes[0].status == "would_apply"
    assert outcomes[0].details["dry_run"] is True
    assert outcomes[0].details["would"] == "create"


def test_epm_policy_update_dry_run_does_not_call_commander(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, _params = _provider(monkeypatch)
    executed: list[str] = []

    class FakePedmPolicyEditCommand:
        def execute(self, _params_arg: object, **kwargs: Any) -> None:
            executed.append(kwargs.get("policy_name", ""))

    _install_pedm_module(monkeypatch, edit_command=FakePedmPolicyEditCommand)
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="policy-row",
        resource_type="epm_policy_rule",
        title="Update Tools",
        keeper_uid="POLICY999",
        after={"name": "Update Tools", "control": ["deny"]},
    )

    outcomes = provider.apply_epm_policy_plan(_plan(change), dry_run=True)

    assert executed == []
    assert len(outcomes) == 1
    assert outcomes[0].action == "would_apply"
    assert outcomes[0].details["would"] == "update"
    assert outcomes[0].details["kwargs"]["policy"] == "POLICY999"


def test_epm_policy_edit_called_on_update(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, params = _provider(monkeypatch)
    calls: list[tuple[object, dict[str, Any]]] = []

    class FakePedmPolicyEditCommand:
        def execute(self, params_arg: object, **kwargs: Any) -> None:
            calls.append((params_arg, kwargs))

    _install_pedm_module(monkeypatch, edit_command=FakePedmPolicyEditCommand)
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="allow-tools",
        resource_type="epm_policy_rule",
        title="Allow Tools",
        keeper_uid="POLICY123",
        after={
            "name": "Allow Tools",
            "policy_type": "elevation",
            "control": ["allow"],
            "status": "enforce",
        },
    )

    outcomes = provider.apply_epm_policy_plan(_plan(change))

    assert [outcome.action for outcome in outcomes] == ["update"]
    assert calls == [
        (
            params,
            {
                "policy": "POLICY123",
                "policy_name": "Allow Tools",
                "policy_type": "elevation",
                "control": ["allow"],
                "status": "enforce",
            },
        )
    ]


def test_epm_policy_empty_plan_returns_no_outcomes(monkeypatch: pytest.MonkeyPatch) -> None:
    provider, _params = _provider(monkeypatch)
    outcomes = provider.apply_epm_policy_plan(_plan())
    assert outcomes == []
