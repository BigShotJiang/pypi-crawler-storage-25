"""Tests for keeperCMD's public DSK artifact hooks consumed by DSK."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from keeper_tenant_migrate import audit as cmd_audit
from keeper_tenant_migrate.integrations.dsk_hooks import (
    IntegrityReport,
    RunDirArtifacts,
    discover_run_dir,
    get_transition_baseline,
    get_users_transition_table,
    verify_run_dir_integrity,
)


def _inventory() -> dict:
    return {
        "captured_at": "2026-05-10T10:00:00Z",
        "counts": {
            "nodes": 1,
            "teams": 1,
            "roles": 1,
            "shared_folders": 0,
            "records": 0,
            "users": 1,
        },
        "entities": {
            "nodes": [{"name": "Source Co", "isolated": False}],
            "teams": [{"name": "ops", "node": "Source Co"}],
            "roles": [{"name": "Admin", "node": "Source Co"}],
            "users": [
                {
                    "email": "Alice@Source.Example",
                    "node": "Source Co",
                    "teams": ["ops"],
                    "roles": ["Admin"],
                }
            ],
            "shared_folders": [],
            "records": [],
        },
    }


def _write_run_dir(run_dir: Path, inventory: dict | None = None) -> Path:
    run_dir.mkdir(exist_ok=True)
    (run_dir / "inventory.json").write_text(json.dumps(inventory or _inventory()), encoding="utf-8")
    (run_dir / "manifest.csv").write_text("source_uid,target_uid\n", encoding="utf-8")
    (run_dir / "records_import.json").write_text("[]\n", encoding="utf-8")
    (run_dir / "records_export").mkdir(exist_ok=True)
    cmd_audit.append_audit_event(
        run_dir / "audit.log",
        {"event": "fixture", "subcommand": "test", "inputs": {}, "outputs": {}, "summary": {}},
    )
    cmd_audit.write_sha256sums(str(run_dir))
    return run_dir


def test_discover_run_dir_returns_required_and_optional_artifacts(tmp_path: Path) -> None:
    _write_run_dir(tmp_path)
    (tmp_path / "manifest.csv.sha256").write_text("bad-sidecar-for-discovery-only\n")

    artifacts = discover_run_dir(tmp_path)

    assert isinstance(artifacts, RunDirArtifacts)
    assert artifacts.run_dir == tmp_path.resolve()
    assert artifacts.inventory_json == tmp_path.resolve() / "inventory.json"
    assert artifacts.records_export_dir == tmp_path.resolve() / "records_export"
    assert artifacts.manifest_csv_sha256 == tmp_path.resolve() / "manifest.csv.sha256"
    assert {p.name for p in artifacts.required()} == {
        "inventory.json",
        "manifest.csv",
        "records_import.json",
        "records_export",
        "audit.log",
        "SHA256SUMS.txt",
    }


def test_discover_run_dir_reports_missing_required_artifacts(tmp_path: Path) -> None:
    tmp_path.mkdir(exist_ok=True)
    (tmp_path / "inventory.json").write_text(json.dumps(_inventory()), encoding="utf-8")

    with pytest.raises(FileNotFoundError, match="manifest.csv"):
        discover_run_dir(tmp_path)


def test_users_transition_table_and_baseline_come_from_dsk_hooks(tmp_path: Path) -> None:
    _write_run_dir(tmp_path)

    rows = get_users_transition_table(tmp_path)
    baseline = get_transition_baseline(tmp_path)

    assert rows == [
        {
            "email": "alice@source.example",
            "node": "Source Co",
            "teams": ["ops"],
            "roles": ["Admin"],
        }
    ]
    assert baseline["alice@source.example"]["roles"] == ["Admin"]


def test_verify_run_dir_integrity_reports_clean_fixture(tmp_path: Path) -> None:
    _write_run_dir(tmp_path)

    report = verify_run_dir_integrity(tmp_path)

    assert isinstance(report, IntegrityReport)
    assert report.ok
    assert report.errors == ()


def test_verify_run_dir_integrity_reports_sha256_drift(tmp_path: Path) -> None:
    _write_run_dir(tmp_path)
    (tmp_path / "records_import.json").write_text("[{}]\n", encoding="utf-8")

    report = verify_run_dir_integrity(tmp_path)

    assert not report.ok
    assert not report.sha256sums_ok
    assert any("records_import.json" in error for error in report.errors)
