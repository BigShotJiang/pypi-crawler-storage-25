"""Tests for `dsk orient` and `dsk export` CLI commands."""

from __future__ import annotations

import json
from pathlib import Path

from click.testing import CliRunner

from dsk.cli.main import main

# ── orient ───────────────────────────────────────────────────────────────────


def test_orient_exits_zero() -> None:
    result = CliRunner().invoke(main, ["orient"], catch_exceptions=False)
    assert result.exit_code == 0


def test_orient_mentions_key_commands() -> None:
    result = CliRunner().invoke(main, ["orient"], catch_exceptions=False)
    output = result.output
    for keyword in ("validate", "plan", "apply", "import", "doctor"):
        assert keyword in output, f"orient output missing: {keyword}"


def test_orient_mentions_providers() -> None:
    result = CliRunner().invoke(main, ["orient"], catch_exceptions=False)
    assert "mock" in result.output
    assert "commander" in result.output


def test_orient_mentions_quick_start() -> None:
    result = CliRunner().invoke(main, ["orient"], catch_exceptions=False)
    assert "Quick start" in result.output or "dsk doctor" in result.output


# ── export ───────────────────────────────────────────────────────────────────


def _pam_json_file(tmp_path: Path, name: str = "test-export") -> Path:
    """Write a minimal Commander PAM project JSON file for export tests."""
    data = {
        "name": name,
        "gateway": {"name": "gw1", "uid": "gw-uid-abcd1234"},
        "config": {"environment": "local", "title": "cfg1"},
        "machines": [],
    }
    path = tmp_path / "pam_project.json"
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


def test_export_exits_zero(tmp_path: Path) -> None:
    path = _pam_json_file(tmp_path)
    result = CliRunner().invoke(main, ["export", str(path)], catch_exceptions=False)
    assert result.exit_code == 0


def test_export_outputs_yaml_with_schema_field(tmp_path: Path) -> None:
    path = _pam_json_file(tmp_path)
    result = CliRunner().invoke(main, ["export", str(path)], catch_exceptions=False)
    assert "schema:" in result.output or "version:" in result.output


def test_export_uses_file_stem_as_name(tmp_path: Path) -> None:
    path = _pam_json_file(tmp_path, name="my-project")
    result = CliRunner().invoke(main, ["export", str(path)], catch_exceptions=False)
    assert result.exit_code == 0
    assert "my-project" in result.output or "pam_project" in result.output


def test_export_writes_to_output_file(tmp_path: Path) -> None:
    pam_path = _pam_json_file(tmp_path)
    out_path = tmp_path / "manifest.yaml"
    result = CliRunner().invoke(
        main, ["export", str(pam_path), "--output", str(out_path)], catch_exceptions=False
    )
    assert result.exit_code == 0
    assert out_path.exists()
    content = out_path.read_text()
    assert len(content) > 10


def test_export_custom_name_overrides_stem(tmp_path: Path) -> None:
    path = _pam_json_file(tmp_path)
    result = CliRunner().invoke(
        main, ["export", str(path), "--name", "custom-env"], catch_exceptions=False
    )
    assert result.exit_code == 0
    assert "custom-env" in result.output
