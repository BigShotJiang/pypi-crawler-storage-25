"""keeper-scim.v1 structural apply (nodes/roles/teams/users) Commander wiring tests."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.planner import Plan
from dsk.providers import commander_cli
from dsk.providers.commander_cli import CommanderCliProvider


def _plan(*changes: Change) -> Plan:
    return Plan(
        manifest_name="scim-struct-test",
        changes=list(changes),
        order=[c.uid_ref or "" for c in changes],
    )


def _provider(monkeypatch: pytest.MonkeyPatch) -> CommanderCliProvider:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    params = types.SimpleNamespace(enterprise=None)
    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(provider, "_get_keeper_params", lambda: params)
    monkeypatch.setattr(provider, "_with_keeper_session_refresh", lambda operation: operation())
    return provider


def _install_fake_enterprise_commands(
    monkeypatch: pytest.MonkeyPatch,
    *,
    node_calls: list[dict[str, Any]],
    team_calls: list[dict[str, Any]],
    role_calls: list[dict[str, Any]],
    user_calls: list[dict[str, Any]],
) -> None:
    """Registers stub Commander enterprise command classes (only those under test import paths)."""

    def _stub(name: str, sink: list[dict[str, Any]]) -> type[Any]:
        class _Cmd:
            def execute(self, _params: object, **kwargs: Any) -> None:
                sink.append(dict(kwargs))

        _Cmd.__name__ = name
        return _Cmd

    ent = types.ModuleType("keepercommander.commands.enterprise")
    ent.EnterpriseNodeCommand = _stub("EnterpriseNodeCommand", node_calls)
    ent.EnterpriseTeamCommand = _stub("EnterpriseTeamCommand", team_calls)
    ent.EnterpriseRoleCommand = _stub("EnterpriseRoleCommand", role_calls)
    ent.EnterpriseUserCommand = _stub("EnterpriseUserCommand", user_calls)

    cmds_pkg = types.ModuleType("keepercommander.commands")
    setattr(cmds_pkg, "__path__", [])
    cmds_pkg.enterprise = ent  # type: ignore[attr-defined]

    root = sys.modules.get("keepercommander")
    if root is None:
        root = types.ModuleType("keepercommander")
        setattr(root, "__path__", [])
        monkeypatch.setitem(sys.modules, "keepercommander", root)
    setattr(root, "commands", cmds_pkg)

    monkeypatch.setitem(sys.modules, "keepercommander.commands", cmds_pkg)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.enterprise", ent)

    api_mod = types.ModuleType("keepercommander.api")

    def _fake_query_enterprise(params: object) -> None:
        setattr(
            params,
            "enterprise",
            {"nodes": [], "enterprise_name": "TestOrg"},
        )

    api_mod.query_enterprise = _fake_query_enterprise
    setattr(root, "api", api_mod)
    monkeypatch.setitem(sys.modules, "keepercommander.api", api_mod)


def _install_scim_push_command(monkeypatch: pytest.MonkeyPatch, sink: list[dict[str, Any]]) -> None:
    class _Push:
        def execute(self, _params: object, **kwargs: Any) -> None:
            sink.append(dict(kwargs))

    scim_mod = types.ModuleType("keepercommander.commands.scim")
    scim_mod.ScimPushCommand = _Push

    root = sys.modules.get("keepercommander")
    if root is None:
        root = types.ModuleType("keepercommander")
        setattr(root, "__path__", [])
        monkeypatch.setitem(sys.modules, "keepercommander", root)

    cmds_pkg = sys.modules.get("keepercommander.commands")
    if cmds_pkg is None:
        cmds_pkg = types.ModuleType("keepercommander.commands")
        setattr(cmds_pkg, "__path__", [])
        monkeypatch.setitem(sys.modules, "keepercommander.commands", cmds_pkg)
        setattr(root, "commands", cmds_pkg)

    setattr(cmds_pkg, "scim", scim_mod)  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "keepercommander.commands.scim", scim_mod)


def test_scim_apply_nodes_skips_when_no_node_rows(monkeypatch: pytest.MonkeyPatch) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="t1",
            resource_type="scim_team",
            title="solo",
            before={},
            after={"name": "solo"},
            manifest_name="m",
        ),
    )
    provider.apply_scim_plan(plan, dry_run=False)
    assert node_calls == []
    assert len(team_calls) == 1


def test_scim_apply_two_nodes_calls_enterprise_node_command_twice(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="n1",
            resource_type="scim_node",
            title="east",
            before={},
            after={"name": "east", "parent_uid_ref": "root-node"},
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="n2",
            resource_type="scim_node",
            title="west",
            before={},
            after={"name": "west"},
            manifest_name="m",
        ),
    )
    outs = provider.apply_scim_plan(plan, dry_run=False)
    assert len(node_calls) == 2
    assert node_calls[0]["node"] == ["east"]
    assert node_calls[0]["parent"] == "root-node"
    assert node_calls[1]["node"] == ["west"]
    assert {o.details.get("commander") for o in outs} == {"enterprise-node"}


def test_scim_apply_roles_skips_when_no_role_rows(monkeypatch: pytest.MonkeyPatch) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="u1",
            resource_type="scim_user",
            title="a@acme.com",
            before={},
            after={"email": "a@acme.com"},
            manifest_name="m",
        ),
    )
    provider.apply_scim_plan(plan, dry_run=False)
    assert role_calls == []
    assert len(user_calls) == 1


def test_scim_apply_two_roles_calls_enterprise_role_command_twice(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="r1",
            resource_type="scim_role",
            title="Admins",
            before={},
            after={"name": "Admins", "node_uid_ref": "east"},
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="r2",
            resource_type="scim_role",
            title="Operators",
            before={},
            after={"name": "Operators"},
            manifest_name="m",
        ),
    )
    outs = provider.apply_scim_plan(plan, dry_run=False)
    assert len(role_calls) == 2
    assert role_calls[0]["role"] == ["Admins"]
    assert role_calls[0]["node"] == "east"
    assert role_calls[1]["role"] == ["Operators"]
    assert {o.details.get("commander") for o in outs} == {"enterprise-role"}


def test_scim_apply_teams_skips_when_no_team_rows(monkeypatch: pytest.MonkeyPatch) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="n-only",
            resource_type="scim_node",
            title="solo-node",
            before={},
            after={"name": "solo-node"},
            manifest_name="m",
        ),
    )
    provider.apply_scim_plan(plan, dry_run=False)
    assert team_calls == []
    assert len(node_calls) == 1


def test_scim_apply_two_teams_calls_enterprise_team_command_twice(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="t1",
            resource_type="scim_team",
            title="Red",
            before={},
            after={"name": "Red", "restrict_edit": True},
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="t2",
            resource_type="scim_team",
            title="Blue",
            before={},
            after={"name": "Blue"},
            manifest_name="m",
        ),
    )
    outs = provider.apply_scim_plan(plan, dry_run=False)
    assert len(team_calls) == 2
    assert team_calls[0]["team"] == ["Red"]
    assert team_calls[1]["team"] == ["Blue"]
    assert {o.details.get("commander") for o in outs} == {"enterprise-team"}


def test_scim_apply_users_skips_when_no_user_rows(monkeypatch: pytest.MonkeyPatch) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="r1",
            resource_type="scim_role",
            title="OnlyRole",
            before={},
            after={"name": "OnlyRole"},
            manifest_name="m",
        ),
    )
    provider.apply_scim_plan(plan, dry_run=False)
    assert user_calls == []
    assert len(role_calls) == 1


def test_scim_apply_two_users_calls_enterprise_user_command_twice(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="u1",
            resource_type="scim_user",
            title="alice@acme.com",
            before={},
            after={
                "email": "alice@acme.com",
                "display_name": "Alice Example",
                "node_uid_ref": "east",
            },
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="u2",
            resource_type="scim_user",
            title="bob@acme.com",
            before={},
            after={"email": "bob@acme.com"},
            manifest_name="m",
        ),
    )
    outs = provider.apply_scim_plan(plan, dry_run=False)
    assert len(user_calls) == 2
    assert user_calls[0]["email"] == ["alice@acme.com"]
    assert user_calls[0]["displayname"] == "Alice Example"
    assert user_calls[0]["node"] == "east"
    assert user_calls[1]["email"] == ["bob@acme.com"]
    assert {o.details.get("commander") for o in outs} == {"enterprise-user"}


def test_scim_apply_mixed_structural_and_record_push_calls_both_surfaces(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    push_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )
    _install_scim_push_command(monkeypatch, push_calls)

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="n1",
            resource_type="scim_node",
            title="edge",
            before={},
            after={"name": "edge"},
            manifest_name="m",
        ),
        Change(
            kind=ChangeKind.UPDATE,
            uid_ref="push1",
            resource_type="scim_push",
            title="push",
            before={},
            after={"node_id": "99", "source": "record", "push_type": "all"},
            manifest_name="m",
        ),
    )
    provider.apply_scim_plan(plan, dry_run=False)
    assert len(node_calls) == 1
    assert len(push_calls) == 1
    assert push_calls[0]["target"] == "99"


def test_scim_apply_node_maps_node_root_parent_sentinel(monkeypatch: pytest.MonkeyPatch) -> None:
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="n-root-sentinel",
            resource_type="scim_node",
            title="child",
            before={},
            after={"name": "child", "parent_uid_ref": "node.root"},
            manifest_name="m",
        ),
    )
    provider.apply_scim_plan(plan, dry_run=False)
    assert len(node_calls) == 1
    assert "parent" not in node_calls[0]


def test_scim_node_apply_calls_query_enterprise_before_enterprise_node_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Commander EnterpriseNodeCommand assumes params.enterprise; avoid NoneType 'in' ops."""
    call_order: list[str] = []
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []

    def _stub(name: str, sink: list[dict[str, Any]]) -> type[Any]:
        class _Cmd:
            def execute(self, _params: object, **kwargs: Any) -> None:
                call_order.append("enterprise_node_execute")
                sink.append(dict(kwargs))

        _Cmd.__name__ = name
        return _Cmd

    ent = types.ModuleType("keepercommander.commands.enterprise")
    ent.EnterpriseNodeCommand = _stub("EnterpriseNodeCommand", node_calls)
    ent.EnterpriseTeamCommand = _stub("EnterpriseTeamCommand", team_calls)
    ent.EnterpriseRoleCommand = _stub("EnterpriseRoleCommand", role_calls)
    ent.EnterpriseUserCommand = _stub("EnterpriseUserCommand", user_calls)

    cmds_pkg = types.ModuleType("keepercommander.commands")
    setattr(cmds_pkg, "__path__", [])
    cmds_pkg.enterprise = ent  # type: ignore[attr-defined]

    root = types.ModuleType("keepercommander")
    setattr(root, "__path__", [])
    root.commands = cmds_pkg

    api_mod = types.ModuleType("keepercommander.api")

    def _qe(_params: object) -> None:
        call_order.append("query_enterprise")
        setattr(
            _params,
            "enterprise",
            {"nodes": [], "enterprise_name": "TestOrg"},
        )

    api_mod.query_enterprise = _qe

    setattr(root, "api", api_mod)
    monkeypatch.setitem(sys.modules, "keepercommander", root)
    monkeypatch.setitem(sys.modules, "keepercommander.commands", cmds_pkg)
    monkeypatch.setitem(sys.modules, "keepercommander.commands.enterprise", ent)
    monkeypatch.setitem(sys.modules, "keepercommander.api", api_mod)

    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="n-qe-order",
            resource_type="scim_node",
            title="edge",
            before={},
            after={"name": "edge"},
            manifest_name="m",
        ),
    )
    provider.apply_scim_plan(plan, dry_run=False)
    assert call_order == ["query_enterprise", "enterprise_node_execute"]
    assert len(node_calls) == 1


def test_scim_apply_user_team_membership_capability_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Live apply must fail closed when manifests carry membership lists Commander cannot atomically invite."""
    node_calls: list[dict[str, Any]] = []
    team_calls: list[dict[str, Any]] = []
    role_calls: list[dict[str, Any]] = []
    user_calls: list[dict[str, Any]] = []
    _install_fake_enterprise_commands(
        monkeypatch,
        node_calls=node_calls,
        team_calls=team_calls,
        role_calls=role_calls,
        user_calls=user_calls,
    )
    provider = _provider(monkeypatch)
    plan = _plan(
        Change(
            kind=ChangeKind.CREATE,
            uid_ref="u1",
            resource_type="scim_user",
            title="who@acme.com",
            before={},
            after={"email": "who@acme.com", "team_uid_refs": ["t1"]},
            manifest_name="m",
        ),
    )
    with pytest.raises(CapabilityError, match="team_uid_refs"):
        provider.apply_scim_plan(plan, dry_run=False)
    assert user_calls == []
