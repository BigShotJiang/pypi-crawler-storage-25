"""REST provider tests for ``keeper-ai-policy.v1``."""

from __future__ import annotations

from typing import Any

import pytest

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_ai_policy import AiPolicyManifestV1
from dsk.providers.ai_policy_provider import AiPolicyProvider


def _manifest() -> AiPolicyManifestV1:
    return AiPolicyManifestV1.model_validate(
        {
            "schema": "keeper-ai-policy.v1",
            "name": "ai-policy",
            "policies": [
                {
                    "name": "monitor-all",
                    "anomaly_rules": [{"name": "geo", "pattern": "geo_anomaly"}],
                }
            ],
        }
    )


def test_ai_policy_provider_plan_returns_diff() -> None:
    provider = AiPolicyProvider(endpoint_base="/ai/session-policy")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"policies": []}
    }

    plan = provider.plan(_manifest())

    assert plan.changes[0].kind is ChangeKind.CREATE
    assert plan.changes[0].resource_type == "ai_session_policy"
    assert plan.changes[0].title == "monitor-all"


def test_ai_policy_provider_apply_calls_configured_endpoint() -> None:
    calls: list[tuple[str, dict[str, Any]]] = []
    provider = AiPolicyProvider(endpoint_base="/ai/session-policy")

    def fake_rest(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append((endpoint, payload))
        if payload["method"] == "GET":
            return {"configuration": {"policies": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())

    provider.apply_ai_policy_plan(plan)

    assert calls[-1][0] == "ai/session-policy"
    assert calls[-1][1]["method"] == "PUT"
    assert calls[-1][1]["configuration"]["policies"][0]["name"] == "monitor-all"


def test_ai_policy_provider_unknown_endpoint_raises_capability_error() -> None:
    provider = AiPolicyProvider()

    with pytest.raises(CapabilityError) as exc:
        provider.plan(_manifest())

    assert "endpoint is not confirmed" in exc.value.reason


def test_ai_policy_provider_plan_noop_when_live_matches() -> None:
    provider = AiPolicyProvider(endpoint_base="/ai/session-policy")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {
            "policies": [
                {
                    "name": "monitor-all",
                    "anomaly_rules": [{"name": "geo", "pattern": "geo_anomaly"}],
                }
            ]
        }
    }
    plan = provider.plan(_manifest())
    assert not any(c.kind in (ChangeKind.CREATE, ChangeKind.UPDATE) for c in plan.changes)


def test_ai_policy_provider_apply_dry_run_skips_put() -> None:
    calls: list[dict[str, Any]] = []
    provider = AiPolicyProvider(endpoint_base="/ai/session-policy")

    def fake_rest(_endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append(payload)
        if payload["method"] == "GET":
            return {"configuration": {"policies": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())
    provider.apply_ai_policy_plan(plan, dry_run=True)
    assert not any(p.get("method") == "PUT" for p in calls)


def test_ai_policy_provider_plan_create_when_live_empty() -> None:
    provider = AiPolicyProvider(endpoint_base="/ai/session-policy")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"policies": []}
    }
    plan = provider.plan(_manifest())
    assert any(c.kind is ChangeKind.CREATE for c in plan.changes)


def test_ai_policy_provider_apply_returns_create_outcome() -> None:
    provider = AiPolicyProvider(endpoint_base="/ai/session-policy")

    def fake_rest(_endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        if payload["method"] == "GET":
            return {"configuration": {"policies": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())
    outcomes = provider.apply_ai_policy_plan(plan)
    assert outcomes[0].action == "create"
    assert outcomes[0].uid_ref in ("monitor-all", "ai-policy.0")
