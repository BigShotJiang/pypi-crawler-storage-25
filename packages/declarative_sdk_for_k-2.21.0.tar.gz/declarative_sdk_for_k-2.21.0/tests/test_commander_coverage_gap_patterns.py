"""Coverage-gap pattern manifests validate through the public CLI."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from dsk.cli.main import EXIT_OK, main

_PATTERN_DIR = Path(__file__).resolve().parents[1] / "dsk" / "extras" / "patterns"


@pytest.mark.parametrize(
    "pattern_name",
    [
        "enterprise_user_roster.yaml",
        "enterprise_team_membership.yaml",
        "enterprise_role_management.yaml",
        "vault_record_sharing.yaml",
        "ksm_app_clients.yaml",
        "pam_rotation_policy.yaml",
    ],
)
def test_commander_coverage_gap_pattern_validates(pattern_name: str) -> None:
    result = CliRunner().invoke(
        main,
        ["validate", str(_PATTERN_DIR / pattern_name)],
        catch_exceptions=False,
    )

    assert result.exit_code == EXIT_OK, result.output
