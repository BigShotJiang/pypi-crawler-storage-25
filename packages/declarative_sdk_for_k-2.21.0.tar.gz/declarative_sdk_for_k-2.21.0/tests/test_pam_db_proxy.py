"""pamDatabase tunnel_settings / KeeperDB Proxy (Wave III1)."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.manifest import load_manifest
from dsk.core.planner import Plan
from dsk.core.schema import PAM_FAMILY, validate_manifest
from dsk.providers.commander_cli import CommanderCliProvider
from tests.test_commander_cli import _apply_recorder

_EXAMPLE = (
    Path(__file__).resolve().parents[1] / "examples/db_proxy/pam-database-keeperdb-proxy.yaml"
)


def test_pam_database_tunnel_settings_model_parse() -> None:
    m = load_manifest(_EXAMPLE)
    db = next(r for r in m.resources if r.type == "pamDatabase")
    assert db.tunnel_settings is not None
    assert db.tunnel_settings.db_proxy_enabled is True
    assert db.tunnel_settings.db_proxy_uid_ref == "ref.tunnel.example-db"
    assert db.tunnel_settings.db_proxy_local_port == 15432


def test_pam_database_tunnel_settings_schema_validate() -> None:
    doc = yaml.safe_load(_EXAMPLE.read_text(encoding="utf-8"))
    assert validate_manifest(doc) == PAM_FAMILY
    ts = doc["resources"][0]["tunnel_settings"]
    assert ts["db_proxy_enabled"] is True
    assert ts["db_proxy_uid_ref"] == "ref.tunnel.example-db"


def test_apply_dry_run_with_db_proxy_enabled_no_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: "/usr/bin/keeper")
    calls: list[list[str]] = []

    def recorder(self: CommanderCliProvider, args: list[str]) -> str:
        calls.append(args)
        return ""

    monkeypatch.setattr(CommanderCliProvider, "_run_cmd", recorder)
    provider = CommanderCliProvider(
        folder_uid="folder-uid",
        manifest_source={
            "version": "1",
            "name": "customer-prod",
            "resources": [
                {
                    "uid_ref": "prod-db",
                    "type": "pamDatabase",
                    "title": "db-prod",
                    "database_type": "postgresql",
                    "tunnel_settings": {
                        "db_proxy_enabled": True,
                        "db_proxy_uid_ref": "ref.tunnel.example-db",
                        "db_proxy_local_port": 15432,
                    },
                }
            ],
        },
    )
    plan = Plan(
        manifest_name="customer-prod",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="prod-db",
                resource_type="pamDatabase",
                title="db-prod",
                after={"title": "db-prod"},
            )
        ],
        order=["prod-db"],
    )
    outcomes = provider.apply_plan(plan, dry_run=True)
    assert len(calls) == 1
    assert calls[0][:3] == ["pam", "project", "import"]
    assert calls[0][-1] == "--dry-run"
    assert outcomes[0].details.get("db_proxy_note") == (
        "tunnel_settings.db_proxy_enabled=True; "
        "after apply run: pam tunnel edit <tunnel-record-uid> --keeper-db-proxy on"
    )


def test_apply_raises_on_dsk_symbolic_uid_ref(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: "/usr/bin/keeper")
    calls: list[list[str]] = []

    def recorder(self: CommanderCliProvider, args: list[str]) -> str:
        calls.append(args)
        return ""

    monkeypatch.setattr(CommanderCliProvider, "_run_cmd", recorder)
    provider = CommanderCliProvider(
        folder_uid="folder-uid",
        manifest_source={
            "version": "1",
            "name": "customer-prod",
            "resources": [
                {
                    "uid_ref": "prod-db",
                    "type": "pamDatabase",
                    "title": "db-prod",
                    "database_type": "postgresql",
                    "tunnel_settings": {
                        "db_proxy_enabled": True,
                        "db_proxy_uid_ref": "ref.tunnel.uid",
                        "db_proxy_local_port": 15432,
                    },
                }
            ],
        },
    )
    plan = Plan(
        manifest_name="customer-prod",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="prod-db",
                resource_type="pamDatabase",
                title="db-prod",
                after={"title": "db-prod"},
            )
        ],
        order=["prod-db"],
    )
    with pytest.raises(CapabilityError) as exc:
        provider.apply_plan(plan)
    assert "db_proxy_enabled" in exc.value.reason
    assert "pam tunnel edit" in exc.value.next_action
    assert "--keeper-db-proxy" in exc.value.next_action
    assert calls == []


def test_apply_with_live_vault_uid_runs_tunnel_edit(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: "/usr/bin/keeper")
    monkeypatch.setattr("dsk.providers.commander_cli.utc_timestamp", lambda: "2026-05-02T12:00:00Z")
    tunnel_uid = "AbCdEfGhIjKlMnOpQrStUv"
    calls: list[list[str]] = []
    inner = _apply_recorder(
        calls,
        project_name="customer-prod",
        get_payload={
            "record_uid": "keeper-created-uid",
            "title": "db-prod",
            "type": "pamDatabase",
            "fields": [],
            "custom": [],
        },
        monkeypatch=monkeypatch,
    )

    def recorder(self: CommanderCliProvider, args: list[str]) -> str:
        if args[:3] == ["pam", "tunnel", "edit"]:
            calls.append(args)
            return ""
        return inner(self, args)

    monkeypatch.setattr(CommanderCliProvider, "_run_cmd", recorder)
    provider = CommanderCliProvider(
        folder_uid="folder-uid",
        manifest_source={
            "version": "1",
            "name": "customer-prod",
            "resources": [
                {
                    "uid_ref": "prod-db",
                    "type": "pamDatabase",
                    "title": "db-prod",
                    "database_type": "postgresql",
                    "tunnel_settings": {
                        "db_proxy_enabled": True,
                        "db_proxy_uid_ref": tunnel_uid,
                        "db_proxy_local_port": 15432,
                    },
                }
            ],
        },
    )
    plan = Plan(
        manifest_name="customer-prod",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="prod-db",
                resource_type="pamDatabase",
                title="db-prod",
                after={"title": "db-prod"},
            )
        ],
        order=["prod-db"],
    )
    provider.apply_plan(plan)
    assert ["pam", "tunnel", "edit", tunnel_uid, "--keeper-db-proxy", "on"] in calls
