"""Plan/mock-apply routing for ``nhi-agent.v1``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from click.testing import CliRunner

from dsk.cli.main import main
from dsk.core.diff import ChangeKind
from dsk.core.models_nhi import NHI_FAMILY, NhiAgentManifest
from dsk.core.nhi_diff import compute_nhi_diff
from dsk.core.planner import build_plan
from dsk.providers.mock import MockProvider


def _nhi_doc() -> dict[str, Any]:
    return {
        "schema": NHI_FAMILY,
        "resources": [
            {
                "uid_ref": "nhi.svc.docs",
                "name": "docs-bot",
                "type": "service_account",
                "purpose": "read internal docs",
            },
        ],
    }


def _nhi_two_resources_doc() -> dict[str, Any]:
    return {
        "schema": NHI_FAMILY,
        "resources": [
            {
                "uid_ref": "nhi.svc.docs",
                "name": "docs-bot",
                "type": "service_account",
                "purpose": "read internal docs",
            },
            {
                "uid_ref": "nhi.svc.build",
                "name": "build-sa",
                "type": "service_account",
                "purpose": "CI pipeline identity",
            },
        ],
    }


def _nhi_empty_resources_doc() -> dict[str, Any]:
    return {"schema": NHI_FAMILY, "resources": []}


def test_nhi_manifest_and_cli_plan_shows_create_row(tmp_path: Path) -> None:
    manifest = NhiAgentManifest.model_validate(_nhi_doc())
    changes = compute_nhi_diff(
        manifest,
        None,
        manifest_name="lab-nhi",
        allow_delete=False,
    )
    assert len(changes) == 1
    assert changes[0].kind == ChangeKind.CREATE and changes[0].resource_type == "nhi_agent"

    path = tmp_path / "nhi-manifest.json"
    path.write_text(json.dumps(_nhi_doc()), encoding="utf-8")
    result = CliRunner().invoke(main, ["plan", str(path), "--json"], catch_exceptions=False)
    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["summary"]["create"] == 1


def test_mock_apply_nhi_returns_outcomes() -> None:
    manifest = NhiAgentManifest.model_validate(_nhi_doc())
    changes = compute_nhi_diff(manifest, None, manifest_name="t", allow_delete=False)
    plan = build_plan("t", changes, [r.uid_ref for r in manifest.resources])
    outcomes = MockProvider("t").apply_nhi_plan(plan, dry_run=False)
    assert len(outcomes) == 1 and outcomes[0].action == "create"
    assert outcomes[0].details.get("family") == "nhi-agent.v1"


def test_nhi_diff_multiple_resources_multiple_creates(tmp_path: Path) -> None:
    manifest = NhiAgentManifest.model_validate(_nhi_two_resources_doc())
    changes = compute_nhi_diff(
        manifest,
        None,
        manifest_name="lab-nhi-multi",
        allow_delete=False,
    )
    assert len(changes) == 2
    assert all(c.kind == ChangeKind.CREATE and c.resource_type == "nhi_agent" for c in changes)
    assert {c.uid_ref for c in changes} == {"nhi.svc.docs", "nhi.svc.build"}

    path = tmp_path / "nhi-multi.json"
    path.write_text(json.dumps(_nhi_two_resources_doc()), encoding="utf-8")
    result = CliRunner().invoke(main, ["plan", str(path), "--json"], catch_exceptions=False)
    assert result.exit_code == 2
    payload = json.loads(result.output)
    assert payload["summary"]["create"] == 2


def test_nhi_diff_empty_resources_no_changes(tmp_path: Path) -> None:
    manifest = NhiAgentManifest.model_validate(_nhi_empty_resources_doc())
    changes = compute_nhi_diff(manifest, None, manifest_name="empty", allow_delete=False)
    assert changes == []

    path = tmp_path / "nhi-empty.json"
    path.write_text(json.dumps(_nhi_empty_resources_doc()), encoding="utf-8")
    result = CliRunner().invoke(main, ["plan", str(path), "--json"], catch_exceptions=False)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["summary"]["create"] == 0


def test_nhi_allow_delete_no_live_no_delete_changes() -> None:
    manifest = NhiAgentManifest.model_validate(_nhi_doc())
    changes = compute_nhi_diff(
        manifest,
        None,
        manifest_name="t",
        allow_delete=True,
    )
    deletes = [c for c in changes if c.kind == ChangeKind.DELETE]
    assert deletes == []
    assert len(changes) == 1 and changes[0].kind == ChangeKind.CREATE


def test_mock_apply_nhi_dry_run_still_reports_create_actions() -> None:
    manifest = NhiAgentManifest.model_validate(_nhi_doc())
    changes = compute_nhi_diff(manifest, None, manifest_name="t", allow_delete=False)
    plan = build_plan("t", changes, [r.uid_ref for r in manifest.resources])
    outcomes = MockProvider("t").apply_nhi_plan(plan, dry_run=True)
    assert len(outcomes) == 1 and outcomes[0].action == "create"
    assert outcomes[0].details.get("dry_run") is True
    assert outcomes[0].details.get("family") == "nhi-agent.v1"
