"""Direct tests for extracted ``dsk.cli.main`` dispatch helpers."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

import click
import pytest

cli_main = importlib.import_module("dsk.cli.main")


def _context() -> click.Context:
    ctx = click.Context(cli_main.main)
    ctx.obj = {"provider": "mock", "renderer": _Renderer()}
    return ctx


class _Renderer:
    def render_plan(self, _plan: object) -> str:
        return "PLAN"

    def render_diff(self, _plan: object) -> str:
        return "DIFF"


def test_dispatch_main_populates_click_context(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cli_main, "configure_json_logging", lambda: None)
    monkeypatch.setattr(cli_main, "set_correlation_id", lambda: "cid-1")
    events: list[dict[str, Any]] = []
    monkeypatch.setattr(cli_main, "log_event", lambda *_args, **kwargs: events.append(kwargs))

    with click.Context(cli_main.main) as ctx:
        ctx.invoked_subcommand = "doctor"
        cli_main._dispatch_main(ctx, "commander", "FOLDER_UID")

    assert ctx.obj["provider"] == "commander"
    assert ctx.obj["folder_uid"] == "FOLDER_UID"
    assert ctx.obj["correlation_id"] == "cid-1"
    assert events[-1]["command"] == "doctor"


def test_dispatch_webui_calls_imported_runner(monkeypatch: pytest.MonkeyPatch) -> None:
    called: dict[str, object] = {}
    module = ModuleType("webui")

    def run(**kwargs: object) -> None:
        called.update(kwargs)

    module.run = run  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "webui", module)

    cli_main._dispatch_webui("127.0.0.1", 8765, False, False, "token")

    assert called == {
        "host": "127.0.0.1",
        "port": 8765,
        "reload": False,
        "insecure_bind": False,
        "token": "token",
    }


def test_dispatch_spiffe_verify_rejects_ambiguous_manifest(tmp_path: Path) -> None:
    manifest = tmp_path / "spiffe.json"
    manifest.write_text("{}", encoding="utf-8")

    with pytest.raises(click.UsageError, match="not both"):
        cli_main._dispatch_spiffe_verify(
            manifest,
            manifest,
            "jwt",
            None,
            "http://localhost:8081",
            False,
            False,
        )


def test_dispatch_plan_renders_text_and_exits(monkeypatch: pytest.MonkeyPatch, capsys: Any) -> None:
    plan = object()
    monkeypatch.setattr(cli_main, "_build_plan", lambda *_args, **_kwargs: plan)
    monkeypatch.setattr(cli_main, "_exit_from_plan", lambda _plan: cli_main.EXIT_CHANGES)
    monkeypatch.setattr(cli_main, "_plan_to_dict", lambda _plan: {"summary": {"create": 1}})
    monkeypatch.setattr(cli_main, "log_event", lambda *_args, **_kwargs: None)

    with pytest.raises(SystemExit) as exc:
        cli_main._dispatch_plan(_context(), Path("manifest.yml"), False, False, None, None)

    assert exc.value.code == cli_main.EXIT_CHANGES
    assert capsys.readouterr().out == "PLAN\n"


def test_dispatch_diff_renders_diff_and_exits(monkeypatch: pytest.MonkeyPatch, capsys: Any) -> None:
    plan = object()
    monkeypatch.setattr(cli_main, "_build_plan", lambda *_args, **_kwargs: plan)
    monkeypatch.setattr(cli_main, "_exit_from_plan", lambda _plan: cli_main.EXIT_OK)
    monkeypatch.setattr(cli_main, "log_event", lambda *_args, **_kwargs: None)

    with pytest.raises(SystemExit) as exc:
        cli_main._dispatch_diff(_context(), Path("manifest.yml"), False)

    assert exc.value.code == cli_main.EXIT_OK
    assert capsys.readouterr().out == "DIFF\n"


def test_dispatch_run_commander_rejects_mock_provider(capsys: Any) -> None:
    with pytest.raises(SystemExit) as exc:
        cli_main._dispatch_run_commander(_context(), False, False, ("whoami",))

    assert exc.value.code == cli_main.EXIT_CAPABILITY
    assert "requires --provider commander" in capsys.readouterr().err


def test_dispatch_refusal_rejects_non_mapping_yaml(tmp_path: Path, capsys: Any) -> None:
    manifest = tmp_path / "list.yml"
    manifest.write_text("- not\n- a\n- mapping\n", encoding="utf-8")

    with pytest.raises(SystemExit) as exc:
        cli_main._dispatch_refusal_check(str(manifest), 90, False, False, False)

    assert exc.value.code == cli_main.EXIT_GENERIC
    assert "mapping" in capsys.readouterr().err


def test_dispatch_panic_revoke_rejects_missing_uid(tmp_path: Path, capsys: Any) -> None:
    manifest = tmp_path / "manifest.yml"
    manifest.write_text("schema: keeper-vault.v1\nrecords: []\n", encoding="utf-8")

    with pytest.raises(SystemExit) as exc:
        cli_main._dispatch_panic_revoke("missing.uid", str(manifest), "breach", False)

    assert exc.value.code == cli_main.EXIT_GENERIC
    assert "not found" in capsys.readouterr().err
