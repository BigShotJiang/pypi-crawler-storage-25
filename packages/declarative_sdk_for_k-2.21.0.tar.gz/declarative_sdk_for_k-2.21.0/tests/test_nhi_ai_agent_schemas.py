"""Schema-forward NHI and AI agent identity contract tests."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
import yaml
from click.testing import CliRunner
from jsonschema import Draft202012Validator

from dsk.cli.main import main
from dsk.core.errors import SchemaError
from dsk.core.schema import load_schema_for_family, validate_manifest

ROOT = Path(__file__).resolve().parents[1]


def _nhi_agent_doc() -> dict[str, Any]:
    return {
        "schema": "nhi-agent.v1",
        "metadata": {"name": "CI service account"},
        "spec": {
            "identity_type": "service_account",
            "keeper_record_uid": "svc-record-uid",
            "ksm_app_uid": "svc-ksm-app-uid",
            "rotation_policy": "0 2 * * *",
            "allowed_scopes": ["ksm:records:read", "pam:connect"],
            "revocation_trigger": "drift_detected",
            "audit_stream": None,
        },
    }


def _ai_agent_doc() -> dict[str, Any]:
    return {
        "schema": "ai-agent.v1",
        "metadata": {"name": "DSK orchestrator"},
        "spec": {
            "keeper_record_uid": "ai-record-uid",
            "ksm_app_uid": "ai-ksm-app-uid",
            "rotation_policy": "on_session_end",
            "allowed_scopes": ["pam:plan", "vault:read", "mcp:tools:propose"],
            "revocation_trigger": "policy_violation",
            "audit_stream": {"siem_url": "https://siem.example.invalid/dsk"},
            "model": "gpt-4o",
            "trust_level": "high",
            "session_recording": True,
            "mcp_server_uid": "mcp-server-record-uid",
            "human_approval_required": True,
            "max_session_duration_minutes": 60,
            "allowed_keeper_products": [
                "keeper_commander",
                "keeper_pam",
                "keeper_vault",
                "keeper_secrets_manager",
                "keeper_ai",
                "keeper_mcp",
            ],
        },
    }


def _write_yaml(tmp_path: Path, name: str, document: dict[str, Any]) -> Path:
    path = tmp_path / name
    path.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    return path


@pytest.mark.parametrize(
    ("family", "flat_path"),
    [
        ("nhi-agent.v1", ROOT / "dsk/core/schemas/nhi_agent_v1.json"),
        ("ai-agent.v1", ROOT / "dsk/core/schemas/ai_agent_v1.json"),
    ],
)
def test_ai_surface_schemas_are_valid_json_schema(family: str, flat_path: Path) -> None:
    Draft202012Validator.check_schema(load_schema_for_family(family))
    Draft202012Validator.check_schema(json.loads(flat_path.read_text(encoding="utf-8")))


def test_minimal_nhi_agent_manifest_passes_dsk_validate(tmp_path: Path) -> None:
    manifest_path = _write_yaml(tmp_path, "nhi-agent.yaml", _nhi_agent_doc())

    result = CliRunner().invoke(main, ["validate", str(manifest_path)], catch_exceptions=False)

    assert result.exit_code == 0, result.output
    assert "nhi-agent.v1" in result.output


def test_minimal_ai_agent_manifest_passes_dsk_validate(tmp_path: Path) -> None:
    manifest_path = _write_yaml(tmp_path, "ai-agent.yaml", _ai_agent_doc())

    result = CliRunner().invoke(main, ["validate", str(manifest_path)], catch_exceptions=False)

    assert result.exit_code == 0, result.output
    assert "ai-agent.v1" in result.output


def test_nhi_agent_missing_required_field_fails_with_meaningful_error() -> None:
    document = _nhi_agent_doc()
    del document["spec"]["keeper_record_uid"]

    with pytest.raises(SchemaError) as exc:
        validate_manifest(document)

    assert "keeper_record_uid" in exc.value.reason
    assert "spec" in exc.value.reason


def test_ai_agent_system_trust_with_human_approval_is_flagged() -> None:
    document = _ai_agent_doc()
    document["spec"]["trust_level"] = "system"
    document["spec"]["human_approval_required"] = True

    with pytest.raises(SchemaError) as exc:
        validate_manifest(document)

    assert exc.value.context["family"] == "ai-agent.v1"
    assert exc.value.context["location"] == "spec"
