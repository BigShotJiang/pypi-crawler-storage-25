"""MSP managed-company ownership marker tests."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_msp import MSP_MARKER_RESOURCE_TYPE, ManagedCompanyMarker
from dsk.core.msp_diff import compute_msp_diff
from dsk.core.msp_graph import msp_apply_order
from dsk.core.msp_models import load_msp_manifest
from dsk.core.planner import build_plan
from dsk.providers import MockProvider
from dsk.providers.commander_cli import CommanderCliProvider


def _manifest(*rows: dict):
    return load_msp_manifest(
        {
            "schema": "msp-environment.v1",
            "name": "msp-marker-test",
            "managed_companies": list(rows),
        }
    )


def _mc(name: str, *, seats: int = 5) -> dict:
    return {"name": name, "plan": "business", "seats": seats}


def _plan(manifest, provider: MockProvider, *, adopt: bool = False):
    return build_plan(
        manifest.name,
        compute_msp_diff(manifest, provider.discover_managed_companies(), adopt=adopt),
        msp_apply_order(manifest),
    )


def test_mock_msp_create_writes_marker_without_vault_custom_field() -> None:
    provider = MockProvider()
    manifest = _manifest(_mc("Acme"))

    outcomes = provider.apply_msp_plan(_plan(manifest, provider))

    live = provider.discover_managed_companies()[0]
    assert outcomes[0].details["marker_written"] is True
    assert "custom_fields" not in live
    assert live["manager"] == "msp-marker-test"
    assert live["marker"]["resource_type"] == "managed_company"
    assert provider.managed_company_markers()[str(live["mc_enterprise_id"])]["uid_ref"] == "Acme"


def test_mock_msp_import_adopts_unmarked_live_company() -> None:
    provider = MockProvider()
    provider.seed_managed_companies([_mc("Acme")])
    manifest = _manifest(_mc("Acme"))

    changes = compute_msp_diff(manifest, provider.discover_managed_companies(), adopt=True)
    assert [change.kind for change in changes] == [ChangeKind.UPDATE]
    outcomes = provider.adopt_managed_companies(_plan(manifest, provider, adopt=True))

    live = provider.discover_managed_companies()[0]
    assert outcomes[0].details["marker_written"] is True
    assert live["manager"] == "msp-marker-test"
    assert live["marker"]["manifest"] == "msp-marker-test"


def test_mock_msp_adoption_conflicts_with_other_manager() -> None:
    provider = MockProvider()
    provider.seed_managed_companies([{**_mc("Acme"), "manager": "other-manager"}])
    manifest = _manifest(_mc("Acme"))

    changes = compute_msp_diff(manifest, provider.discover_managed_companies(), adopt=True)

    assert [change.kind for change in changes] == [ChangeKind.CONFLICT]
    assert "other-manager" in (changes[0].reason or "")


def test_commander_msp_marker_adoption_is_upstream_gap() -> None:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    manifest = _manifest(_mc("Acme"))
    mock = MockProvider()
    mock.seed_managed_companies([_mc("Acme")])
    plan = _plan(manifest, mock, adopt=True)

    with pytest.raises(CapabilityError) as exc_info:
        provider.adopt_managed_companies(plan)

    assert "no managed-company metadata field" in exc_info.value.reason


def test_msp_marker_factory_minimal_defaults() -> None:
    marker = ManagedCompanyMarker(
        manager="  msp-marker-test  ",
        uid_ref="Acme",
        manifest="msp-marker-test",
    )
    assert marker.manager == "msp-marker-test"
    assert marker.uid_ref == "Acme"
    assert marker.manifest == "msp-marker-test"
    assert marker.resource_type == MSP_MARKER_RESOURCE_TYPE


def test_msp_marker_factory_all_fields_explicit() -> None:
    marker = ManagedCompanyMarker(
        manager="mgr",
        uid_ref="uid",
        manifest="man",
        resource_type=MSP_MARKER_RESOURCE_TYPE,
    )
    assert marker.model_dump() == {
        "manager": "mgr",
        "uid_ref": "uid",
        "manifest": "man",
        "resource_type": MSP_MARKER_RESOURCE_TYPE,
    }


def test_msp_marker_extra_forbid() -> None:
    with pytest.raises(ValidationError) as exc_info:
        ManagedCompanyMarker(
            manager="m",
            uid_ref="u",
            manifest="v",
            not_a_marker_field="nope",
        )
    assert "not_a_marker_field" in str(exc_info.value)


def test_msp_marker_required_field_missing() -> None:
    with pytest.raises(ValidationError) as exc_info:
        ManagedCompanyMarker(
            manager="m",
            uid_ref="u",
        )
    assert "manifest" in str(exc_info.value)


def test_msp_marker_invalid_resource_type_rejected() -> None:
    with pytest.raises(ValidationError) as exc_info:
        ManagedCompanyMarker(
            manager="m",
            uid_ref="u",
            manifest="v",
            resource_type="wrong_kind",
        )
    assert "resource_type" in str(exc_info.value)
