from __future__ import annotations

from typing import Any, cast

import pytest

from dsk.core.errors import CapabilityError
from dsk.secrets.bus import BusClient


def _client() -> BusClient:
    """Bypass the sealed __init__ that raises on construction."""
    return object.__new__(BusClient)


def _assert_not_implemented(exc: CapabilityError) -> None:
    assert "not implemented" in str(exc).lower()


def test_init_seals_construction() -> None:
    with pytest.raises(CapabilityError) as excinfo:
        BusClient(store=cast(Any, object()), directory_uid="bus-directory")

    _assert_not_implemented(excinfo.value)


@pytest.mark.parametrize(
    ("method_name", "kwargs"),
    [
        ("post", {"to": "*", "subject": "topic", "payload": {"ok": True}}),
        ("fetch", {"since_id": None, "consumer": "*"}),
        ("ack", {"last_id": "message-id", "consumer": "*"}),
        ("gc", {}),
    ],
)
def test_method_raises_capability_error(method_name: str, kwargs: dict[str, object]) -> None:
    method = getattr(_client(), method_name)

    with pytest.raises(CapabilityError) as excinfo:
        method(**kwargs)

    _assert_not_implemented(excinfo.value)


def test_bus_client_has_expected_methods() -> None:
    """BusClient must expose post, fetch, ack, gc as callable attributes."""
    client = _client()
    for name in ("post", "fetch", "ack", "gc"):
        assert callable(getattr(client, name, None)), f"BusClient missing method: {name}"


def test_capability_error_message_contains_method_name() -> None:
    """CapabilityError from post() should mention the method or 'not implemented'."""
    client = _client()
    with pytest.raises(CapabilityError) as excinfo:
        client.post(to="*", subject="topic", payload={})
    assert str(excinfo.value)  # non-empty message


def test_bus_client_is_sealed_to_subclass() -> None:
    """Subclassing BusClient must not be blocked but instantiation must still seal."""

    class Subbus(BusClient):
        pass

    with pytest.raises(CapabilityError):
        Subbus(store=cast(Any, object()), directory_uid="bus-directory")
