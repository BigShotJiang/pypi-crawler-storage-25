"""Tests for ``epm-policy.v1`` (endpoint privilege management policy manifests)."""

from __future__ import annotations

from typing import Any

import pytest

from dsk.core.errors import SchemaError
from dsk.core.models_epm import (
    DefaultPolicyCategory,
    load_epm_policy_manifest,
)


def _minimal_policy_doc(**extra: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "schema": "epm-policy.v1",
        "name": "test-epm",
        "version": "1",
    }
    base.update(extra)
    return base


def test_epm_policy_default_policies_parse() -> None:
    doc = _minimal_policy_doc(
        default_policies=[
            "allow_listed_applications",
            "block_unsigned_executables",
        ]
    )
    manifest = load_epm_policy_manifest(doc)
    assert manifest.default_policies == [
        DefaultPolicyCategory.allow_listed_applications,
        DefaultPolicyCategory.block_unsigned_executables,
    ]


def test_epm_policy_invalid_default_category_rejected() -> None:
    doc = _minimal_policy_doc(default_policies=["not_a_builtin_category"])
    with pytest.raises(SchemaError) as exc:
        load_epm_policy_manifest(doc)
    assert "not_a_builtin_category" in exc.value.reason or "enum" in exc.value.reason.lower()


def test_epm_policy_empty_default_policies_valid() -> None:
    manifest = load_epm_policy_manifest(_minimal_policy_doc(default_policies=[]))
    assert manifest.default_policies == []


def test_epm_policy_empty_policies_array_valid() -> None:
    manifest = load_epm_policy_manifest(_minimal_policy_doc(policies=[]))
    assert manifest.policies == []


def test_epm_policy_nested_rule_deny_effect_and_platform_loads() -> None:
    doc = _minimal_policy_doc(
        policies=[
            {
                "name": "Block legacy",
                "rules": [
                    {
                        "name": "Legacy path",
                        "effect": "deny",
                        "platform": "windows",
                        "match_path": "C:\\\\Legacy\\\\*.exe",
                    }
                ],
            }
        ]
    )
    manifest = load_epm_policy_manifest(doc)
    assert manifest.policies[0].rules[0].effect.name == "deny"
    assert manifest.policies[0].rules[0].platform.name == "windows"


def test_epm_policy_wrong_schema_family_rejected() -> None:
    doc = _minimal_policy_doc()
    doc["schema"] = "keeper-epm.v1"
    with pytest.raises(SchemaError) as exc:
        load_epm_policy_manifest(doc)
    # validate_manifest picks ``keeper-epm.v1`` from ``schema`` before typed EPM-policy load.
    assert (exc.value.context or {}).get("family") == "keeper-epm.v1"
