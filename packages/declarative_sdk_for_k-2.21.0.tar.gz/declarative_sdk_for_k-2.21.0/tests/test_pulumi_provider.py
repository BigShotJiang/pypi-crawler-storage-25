"""Tests for Pulumi DSK provider (offline — no pulumi install required)."""

from __future__ import annotations

import importlib.util
import subprocess
import types
from pathlib import Path

_PULUMI_SPEC_PATH = Path("pulumi/keeper_pam/__init__.py")


def _load_pulumi_mod(name: str = "keeper_pam"):  # type: ignore[return]
    if not _PULUMI_SPEC_PATH.exists():
        return None
    spec = importlib.util.spec_from_file_location(name, _PULUMI_SPEC_PATH)
    if not (spec and spec.loader):
        return None
    mod = types.ModuleType(name)
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


def test_module_importable_without_pulumi() -> None:
    """Module must not crash on import when pulumi is not installed."""
    mod = _load_pulumi_mod()
    if mod is None:
        return
    assert hasattr(mod, "PamEnvironment") or not mod._PULUMI_AVAILABLE


def test_require_pulumi_raises_without_install() -> None:
    mod = _load_pulumi_mod("keeper_pam_fresh")
    if mod is None:
        return
    if hasattr(mod, "_require_pulumi"):
        orig = mod._PULUMI_AVAILABLE
        mod._PULUMI_AVAILABLE = False
        try:
            try:
                mod._require_pulumi()
                assert False, "Expected ImportError"
            except ImportError as exc:
                assert "pulumi" in str(exc).lower()
        finally:
            mod._PULUMI_AVAILABLE = orig


def test_run_dsk_function_exists() -> None:
    """_run_dsk must be exposed and callable."""
    mod = _load_pulumi_mod("keeper_pam_dsk")
    if mod is None:
        return
    assert hasattr(mod, "_run_dsk") and callable(mod._run_dsk)


def test_run_dsk_returns_exit_code_and_dict_on_bad_json(tmp_path: Path) -> None:
    """_run_dsk must not crash when dsk output is not JSON."""
    from unittest.mock import MagicMock, patch

    mod = _load_pulumi_mod("keeper_pam_dsk2")
    if mod is None or not hasattr(mod, "_run_dsk"):
        return

    fake = MagicMock(returncode=1, stdout="not-json", stderr="")
    with patch("subprocess.run", return_value=fake) as run:
        code, data = mod._run_dsk("plan", "manifest.yaml", {})
    assert code == 1
    assert isinstance(data, dict)
    assert run.call_args.kwargs["timeout"] == mod.DEFAULT_PULUMI_COMMAND_TIMEOUT_SECONDS


def test_run_dsk_returns_124_on_timeout() -> None:
    from unittest.mock import patch

    mod = _load_pulumi_mod("keeper_pam_timeout")
    if mod is None or not hasattr(mod, "_run_dsk"):
        return

    with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="dsk", timeout=1)):
        code, data = mod._run_dsk("plan", "manifest.yaml", {})
    assert code == 124
    assert data == {}


def test_run_dsk_oversized_stdout_returns_empty_dict(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    from unittest.mock import MagicMock, patch

    mod = _load_pulumi_mod("keeper_pam_oversized")
    if mod is None or not hasattr(mod, "_run_dsk"):
        return

    monkeypatch.setenv("DSK_PULUMI_MAX_STDOUT_BYTES", "2")
    fake = MagicMock(returncode=0, stdout='{"summary": {}}', stderr="")
    with patch("subprocess.run", return_value=fake):
        code, data = mod._run_dsk("plan", "manifest.yaml", {})
    assert code == 0
    assert data == {}


def test_pulumi_spec_path_exists() -> None:
    """Confirm the Pulumi provider source file is present in the repo."""
    assert _PULUMI_SPEC_PATH.exists(), f"Missing: {_PULUMI_SPEC_PATH}"
