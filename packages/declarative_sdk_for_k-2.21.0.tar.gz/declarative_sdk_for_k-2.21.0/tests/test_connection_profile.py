"""Tests for pam-connection-profile.v1 models."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from dsk.core.models_connection_profile import (
    ConnectionProtocol,
    DatabaseConnectionOptions,
    PamConnectionProfile,
    PamConnectionProfileManifestV1,
    ProxyConfig,
    RdpConnectionOptions,
    RecordingQuality,
)


def test_profile_defaults() -> None:
    profile = PamConnectionProfile(name="test", protocol=ConnectionProtocol.ssh)
    assert profile.recording_quality == RecordingQuality.medium
    assert profile.session_timeout_minutes == 60
    assert profile.proxy is None


def test_manifest_round_trip() -> None:
    example = (
        Path(__file__).parent.parent / "examples/connection-profiles/acme-connection-profiles.yaml"
    )
    data = yaml.safe_load(example.read_text())
    manifest = PamConnectionProfileManifestV1(**data)
    assert manifest.schema_ == "pam-connection-profile.v1"
    assert len(manifest.profiles) == 4
    ssh = manifest.profiles[0]
    assert ssh.protocol == ConnectionProtocol.ssh
    assert ssh.ssh is not None
    assert ssh.ssh.port == 22
    proxy = manifest.profiles[3]
    assert proxy.proxy is not None
    assert proxy.proxy.type == "socks5"


def test_rdp_profile() -> None:
    profile = PamConnectionProfile(
        name="rdp-test",
        protocol=ConnectionProtocol.rdp,
        rdp=RdpConnectionOptions(color_depth=32, enable_drive_redirection=True),
    )
    assert profile.rdp is not None
    assert profile.rdp.color_depth == 32


def test_schema_alias() -> None:
    m = PamConnectionProfileManifestV1(
        **{"schema": "pam-connection-profile.v1", "name": "test"},
    )
    assert m.schema_ == "pam-connection-profile.v1"


# --- launch_credentials ---


def test_launch_credentials_field() -> None:
    profile = PamConnectionProfile(
        name="launch-test",
        protocol=ConnectionProtocol.ssh,
        launch_credentials="pamUser.example-launch-creds",
    )
    assert profile.launch_credentials == "pamUser.example-launch-creds"


def test_launch_credentials_absent_by_default() -> None:
    profile = PamConnectionProfile(name="no-launch", protocol=ConnectionProtocol.rdp)
    assert profile.launch_credentials is None


def test_launch_credentials_in_manifest_round_trip() -> None:
    raw = yaml.safe_load(
        """
schema: pam-connection-profile.v1
name: test-launch
version: "1"
manager: dsk
profiles:
  - name: ssh-with-launch
    protocol: ssh
    launch_credentials: pamUser.launch-user
    recording_quality: high
"""
    )
    manifest = PamConnectionProfileManifestV1(**raw)
    assert manifest.profiles[0].launch_credentials == "pamUser.launch-user"
    dumped = manifest.model_dump(by_alias=True)
    assert dumped["profiles"][0]["launch_credentials"] == "pamUser.launch-user"


# --- database connection options ---


def test_database_connection_options_defaults() -> None:
    opts = DatabaseConnectionOptions()
    assert opts.ssl_mode == "prefer"
    assert opts.connection_timeout_seconds == 30
    assert opts.max_connections == 10


def test_database_connection_options_custom() -> None:
    opts = DatabaseConnectionOptions(
        port=5432,
        ssl_mode="verify-full",
        connection_timeout_seconds=15,
        max_connections=20,
    )
    assert opts.ssl_mode == "verify-full"
    assert opts.max_connections == 20


def test_database_protocol_profile() -> None:
    profile = PamConnectionProfile(
        name="pg-prod",
        protocol=ConnectionProtocol.postgres,
        recording_quality=RecordingQuality.low,
        session_timeout_minutes=30,
        max_concurrent_sessions=50,
    )
    assert profile.protocol == ConnectionProtocol.postgres
    assert profile.max_concurrent_sessions == 50


# --- proxy ---


def test_proxy_with_credential_uid_ref() -> None:
    proxy = ProxyConfig(
        type="http",
        host="proxy.example.com",
        port=8080,
        credential_uid_ref="ref.proxy.creds",
    )
    assert proxy.credential_uid_ref == "ref.proxy.creds"
    assert proxy.type == "http"


def test_proxy_defaults() -> None:
    proxy = ProxyConfig(host="proxy.example.com")
    assert proxy.type == "socks5"
    assert proxy.port == 1080
    assert proxy.credential_uid_ref is None


# --- protocol + quality completeness ---


def test_all_protocol_variants() -> None:
    for proto in ConnectionProtocol:
        p = PamConnectionProfile(name=f"test-{proto.value}", protocol=proto)
        assert p.protocol == proto


def test_recording_quality_all_variants() -> None:
    for quality in RecordingQuality:
        p = PamConnectionProfile(
            name=f"test-{quality.value}",
            protocol=ConnectionProtocol.ssh,
            recording_quality=quality,
        )
        assert p.recording_quality == quality


# --- boundary values ---


def test_session_timeout_boundary() -> None:
    from pydantic import ValidationError

    p = PamConnectionProfile(
        name="max-timeout", protocol=ConnectionProtocol.ssh, session_timeout_minutes=1440
    )
    assert p.session_timeout_minutes == 1440
    with pytest.raises(ValidationError):
        PamConnectionProfile(
            name="over-max", protocol=ConnectionProtocol.ssh, session_timeout_minutes=1441
        )


def test_max_concurrent_sessions_minimum() -> None:
    from pydantic import ValidationError

    p = PamConnectionProfile(
        name="min-sessions", protocol=ConnectionProtocol.ssh, max_concurrent_sessions=1
    )
    assert p.max_concurrent_sessions == 1
    with pytest.raises(ValidationError):
        PamConnectionProfile(
            name="zero-sessions", protocol=ConnectionProtocol.ssh, max_concurrent_sessions=0
        )


# --- full multi-profile manifest ---


def test_full_manifest_with_all_profile_types() -> None:
    raw = yaml.safe_load(
        """
schema: pam-connection-profile.v1
name: full-manifest
version: "1"
manager: dsk
profiles:
  - name: ssh-profile
    protocol: ssh
    launch_credentials: pamUser.svc
    recording_quality: high
  - name: rdp-profile
    protocol: rdp
    rdp:
      color_depth: 32
  - name: mysql-profile
    protocol: mysql
    database:
      ssl_mode: require
      max_connections: 5
"""
    )
    manifest = PamConnectionProfileManifestV1(**raw)
    assert len(manifest.profiles) == 3
    ssh = manifest.profiles[0]
    assert ssh.launch_credentials == "pamUser.svc"
    rdp = manifest.profiles[1]
    assert rdp.rdp is not None
    assert rdp.rdp.color_depth == 32
    db = manifest.profiles[2]
    assert db.database is not None
    assert db.database.ssl_mode == "require"
