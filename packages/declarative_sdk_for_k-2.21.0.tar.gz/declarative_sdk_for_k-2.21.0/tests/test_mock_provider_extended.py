"""Extended unit tests for :mod:`dsk.providers.mock` coverage gaps."""

from __future__ import annotations

import pytest

from dsk.core import (
    CapabilityError,
    Change,
    ChangeKind,
    Plan,
    build_plan,
)
from dsk.core.enterprise_diff import compute_enterprise_diff
from dsk.core.enterprise_graph import build_enterprise_graph, enterprise_apply_order
from dsk.core.models_enterprise import EnterpriseManifestV1
from dsk.providers import MockProvider


class _PlanWithConflictNoopTail(Plan):
    """``MockProvider.apply_plan`` iterates only ``ordered()``; append tail kinds."""

    def ordered(self):  # type: ignore[override]
        tail_kinds = frozenset({ChangeKind.CONFLICT, ChangeKind.NOOP, ChangeKind.SKIP})
        return super().ordered() + [c for c in self.changes if c.kind in tail_kinds]


def _enterprise_manifest() -> EnterpriseManifestV1:
    raw = {
        "schema": "keeper-enterprise.v1",
        "nodes": [{"uid_ref": "n-root", "name": "Root"}],
        "teams": [
            {
                "uid_ref": "t1",
                "name": "Alpha",
                "node_uid_ref": "keeper-enterprise:nodes:n-root",
            },
        ],
    }
    m = EnterpriseManifestV1.model_validate(raw)
    build_enterprise_graph(m)
    return m


def test_apply_plan_update_existing_record_mutates_payload() -> None:
    provider = MockProvider("ext")
    keeper_uid = provider.seed_payload(
        title="host-a",
        resource_type="pamMachine",
        payload={"title": "host-a"},
        marker_uid_ref="m1",
        manifest_name="ext",
    )
    before_payload = dict(provider._records[keeper_uid].payload)
    plan = build_plan(
        "ext",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="m1",
                resource_type="pamMachine",
                title="host-a",
                keeper_uid=keeper_uid,
                before=before_payload,
                after={"notes": "patched"},
            )
        ],
        ["m1"],
    )

    outcomes = provider.apply_plan(plan, dry_run=False)

    assert outcomes[0].action == "update"
    assert outcomes[0].details.get("dry_run") is False
    assert provider._records[keeper_uid].payload.get("notes") == "patched"


def test_apply_plan_update_missing_record_skipped_in_details() -> None:
    provider = MockProvider("ext")
    plan = build_plan(
        "ext",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="missing-ref",
                resource_type="pamMachine",
                title="ghost",
                keeper_uid="not-a-real-uid",
                after={"notes": "x"},
            )
        ],
        ["missing-ref"],
    )

    outcomes = provider.apply_plan(plan)

    assert outcomes[0].action == "update"
    assert outcomes[0].details.get("skipped") == "record_missing"
    assert outcomes[0].keeper_uid == "not-a-real-uid"


def test_apply_plan_delete_removes_record_and_reports_delete() -> None:
    provider = MockProvider("ext")
    keeper_uid = provider.seed_payload(
        title="rm-me",
        resource_type="pamMachine",
        payload={"title": "rm-me"},
        marker_uid_ref="r1",
        manifest_name="ext",
    )
    plan = build_plan(
        "ext",
        [
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="r1",
                resource_type="pamMachine",
                title="rm-me",
                keeper_uid=keeper_uid,
                before={"title": "rm-me"},
            )
        ],
        ["r1"],
    )

    outcomes = provider.apply_plan(plan, dry_run=False)

    assert outcomes[0].action == "delete"
    assert keeper_uid not in provider._records


def test_apply_plan_dry_run_skips_create_update_delete_mutations() -> None:
    provider = MockProvider("ext")
    created_uid = provider.seed_payload(
        title="live",
        resource_type="pamMachine",
        payload={"title": "live"},
        marker_uid_ref="live-ref",
        manifest_name="ext",
    )

    plan = _PlanWithConflictNoopTail(
        manifest_name="ext",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="new-r",
                resource_type="pamMachine",
                title="new-host",
                after={"title": "new-host"},
            ),
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="live-ref",
                resource_type="pamMachine",
                title="live",
                keeper_uid=created_uid,
                after={"notes": "would-write"},
            ),
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="live-ref",
                resource_type="pamMachine",
                title="live",
                keeper_uid=created_uid,
                before={"title": "live"},
            ),
        ],
        order=["new-r", "live-ref"],
    )

    before_live = dict(provider._records[created_uid].payload)
    outcomes = provider.apply_plan(plan, dry_run=True)

    actions = [o.action for o in outcomes]
    assert actions[:3] == ["create", "update", "delete"]
    assert all(o.details.get("dry_run") is True for o in outcomes[:3])
    assert created_uid in provider._records
    assert provider._records[created_uid].payload == before_live
    stable_new = outcomes[0].keeper_uid
    assert stable_new not in provider._records


def test_apply_plan_update_existing_dry_run_leaves_payload_unchanged() -> None:
    provider = MockProvider("ext")
    keeper_uid = provider.seed_payload(
        title="x",
        resource_type="pamMachine",
        payload={"title": "x", "color": "blue"},
        marker_uid_ref="u1",
        manifest_name="ext",
    )
    snapshot = dict(provider._records[keeper_uid].payload)
    plan = build_plan(
        "ext",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="u1",
                resource_type="pamMachine",
                title="x",
                keeper_uid=keeper_uid,
                after={"color": "red"},
            )
        ],
        ["u1"],
    )

    outcomes = provider.apply_plan(plan, dry_run=True)

    assert outcomes[0].action == "update"
    assert outcomes[0].details == {"dry_run": True}
    assert provider._records[keeper_uid].payload == snapshot


def test_apply_plan_conflict_noop_and_skip_outcomes() -> None:
    provider = MockProvider("ext")
    plan = _PlanWithConflictNoopTail(
        manifest_name="ext",
        changes=[
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref="c1",
                resource_type="pamMachine",
                title="t",
                keeper_uid="ku",
                reason="manual-block",
            ),
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref="c2",
                resource_type="pamMachine",
                title="t2",
                keeper_uid="ku2",
                reason=None,
            ),
            Change(
                kind=ChangeKind.NOOP,
                uid_ref="n1",
                resource_type="pamMachine",
                title="ok",
                keeper_uid="k9",
            ),
            Change(
                kind=ChangeKind.SKIP,
                uid_ref="s1",
                resource_type="pamMachine",
                title="skip",
                keeper_uid="k8",
            ),
        ],
        order=["c1", "c2", "n1", "s1"],
    )

    outcomes = provider.apply_plan(plan)

    assert [(o.action, o.details.get("reason")) for o in outcomes[:2]] == [
        ("conflict", "manual-block"),
        ("conflict", "blocked"),
    ]
    assert outcomes[2].action == "noop"
    assert outcomes[2].keeper_uid == "k9"
    assert outcomes[3].action == "noop"


def test_apply_plan_sharing_delete_requires_allow_delete_when_not_dry_run() -> None:
    provider = MockProvider("ext")
    plan = build_plan(
        "ext",
        [
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="sf1",
                resource_type="sharing_shared_folder",
                title="Folder",
                keeper_uid="uid-folder",
                before={"name": "Folder"},
            )
        ],
        ["sf1"],
    )
    setattr(plan, "allow_delete", False)

    with pytest.raises(CapabilityError, match="allow-delete"):
        provider.apply_plan(plan, dry_run=False)


def test_apply_plan_sharing_delete_allowed_when_dry_run_without_allow_delete() -> None:
    provider = MockProvider("ext")
    plan = build_plan(
        "ext",
        [
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="sf1",
                resource_type="sharing_shared_folder",
                title="Folder",
                keeper_uid="uid-folder",
                before={"name": "Folder"},
            )
        ],
        ["sf1"],
    )
    setattr(plan, "allow_delete", False)

    outcomes = provider.apply_plan(plan, dry_run=True)
    assert outcomes[0].action == "delete"
    assert outcomes[0].details.get("dry_run") is True


def test_apply_scim_plan_create_update_delete_conflict_and_noop() -> None:
    provider = MockProvider("scim")
    plan = _PlanWithConflictNoopTail(
        manifest_name="scim",
        changes=[
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="u1",
                resource_type="scim_user",
                title="User",
                after={"userName": "a@b.com"},
            ),
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="u2",
                resource_type="scim_user",
                title="User2",
                after={"active": False},
            ),
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="u3",
                resource_type="scim_user",
                title="del",
                keeper_uid="x",
                before={},
            ),
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref="u4",
                resource_type="scim_user",
                title="bad",
                reason="duplicate",
            ),
            Change(
                kind=ChangeKind.NOOP,
                uid_ref="u5",
                resource_type="scim_user",
                title="noop",
            ),
        ],
        order=["u1", "u2", "u3", "u4", "u5"],
    )

    out = provider.apply_scim_plan(plan, dry_run=False)
    assert [o.action for o in out[:3]] == ["create", "update", "noop"]
    assert out[2].details.get("skipped") == "delete"
    assert out[3].action == "conflict"
    assert out[4].action == "noop"
    assert out[4].details.get("skipped") == "noop"


def test_apply_scim_plan_respects_dry_run_flag_in_details() -> None:
    provider = MockProvider("scim")
    plan = build_plan(
        "scim",
        [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref="idp",
                resource_type="scim_group",
                title="grp",
                after={"displayName": "G"},
            ),
        ],
        ["idp"],
    )
    outs = provider.apply_scim_plan(plan, dry_run=True)
    assert outs[0].details["dry_run"] is True
    assert outs[0].details["mock"] is True


def test_apply_enterprise_plan_conflict_and_non_enterprise_row() -> None:
    manifest = _enterprise_manifest()
    provider = MockProvider("lab")
    conflict = Change(
        kind=ChangeKind.CONFLICT,
        uid_ref="x",
        resource_type="enterprise_team",
        title="t",
        reason="collision",
    )
    noise = Change(
        kind=ChangeKind.NOOP,
        uid_ref="p",
        resource_type="pamMachine",
        title="m",
        reason=None,
    )
    order = enterprise_apply_order(manifest)
    plan = build_plan("lab", [conflict, noise], order)

    out = provider.apply_enterprise_plan(plan, manifest, dry_run=False)
    assert out[0].action == "conflict"
    assert out[0].details["reason"] == "collision"
    assert out[1].action == "noop"
    assert out[1].details["reason"] == "non-enterprise-plan-row"


def test_apply_enterprise_plan_update_missing_record() -> None:
    manifest = _enterprise_manifest()
    provider = MockProvider("lab")
    plan = build_plan(
        "lab",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="t-missing",
                resource_type="enterprise_team",
                title="Ghost",
                keeper_uid="no-such-row",
                before={},
                after={"name": "Ghost"},
            ),
        ],
        enterprise_apply_order(manifest),
    )

    out = provider.apply_enterprise_plan(plan, manifest, dry_run=False)
    assert out[0].action == "update"
    assert out[0].details.get("skipped") == "record_missing"


def test_apply_enterprise_plan_delete_missing_record() -> None:
    manifest = _enterprise_manifest()
    provider = MockProvider("lab")
    plan = build_plan(
        "lab",
        [
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="gone",
                resource_type="enterprise_team",
                title="Gone",
                keeper_uid="missing-kuid",
                before={"name": "Gone"},
            ),
        ],
        enterprise_apply_order(manifest),
    )

    out = provider.apply_enterprise_plan(plan, manifest, dry_run=False)
    assert out[0].action == "delete"
    assert out[0].details.get("skipped") == "record_missing"


def test_apply_enterprise_plan_update_dry_run_does_not_write_state() -> None:
    manifest = _enterprise_manifest()
    provider = MockProvider("lab")
    setup_changes = compute_enterprise_diff(manifest, None, manifest_name="lab")
    setup_plan = build_plan("lab", setup_changes, enterprise_apply_order(manifest))
    provider.apply_enterprise_plan(setup_plan, manifest, dry_run=False)
    before = provider.discover_enterprise()

    row = next(iter(provider.discover_enterprise()["teams"]))
    update = Change(
        kind=ChangeKind.UPDATE,
        uid_ref=str(row["uid_ref"]),
        resource_type="enterprise_team",
        title=str(row.get("name") or ""),
        keeper_uid=str(row["keeper_uid"]),
        before=dict(row),
        after={**dict(row), "restrict_edit": True},
    )
    plan = build_plan("lab", [update], enterprise_apply_order(manifest))
    out = provider.apply_enterprise_plan(plan, manifest, dry_run=True)

    assert out[0].action == "update"
    assert out[0].details["dry_run"] is True
    assert out[0].details["marker_written"] is False
    assert provider.discover_enterprise() == before


def test_apply_msp_plan_dry_run_update_without_mutating_store() -> None:
    provider = MockProvider()
    provider.seed_managed_companies([{"name": "Acme", "plan": "business", "seats": 3}])
    before = provider.discover_managed_companies()
    plan = build_plan(
        "msp",
        [
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref="Acme",
                resource_type="managed_company",
                title="Acme",
                keeper_uid="ignored",
                after={"name": "Acme", "plan": "enterprise", "seats": 3},
            ),
        ],
        ["Acme"],
    )

    out = provider.apply_msp_plan(plan, dry_run=True)
    assert out[0].action == "update"
    assert provider.discover_managed_companies() == before


def test_discover_returns_seeded_live_records() -> None:
    provider = MockProvider("d")
    provider.seed_payload(
        title="one",
        resource_type="pamMachine",
        payload={"title": "one"},
        marker_uid_ref="a",
        manifest_name="d",
    )
    rows = provider.discover()
    assert len(rows) == 1
    assert rows[0].title == "one"


def test_discover_managed_companies_sorted_case_insensitive() -> None:
    provider = MockProvider()
    provider.seed_managed_companies(
        [
            {"name": "Beta"},
            {"name": "alpha"},
        ]
    )
    names = [row["name"] for row in provider.discover_managed_companies()]
    assert names == ["alpha", "Beta"]


def test_discover_enterprise_returns_all_blocks() -> None:
    provider = MockProvider("lab")
    snap = provider.discover_enterprise()
    assert set(snap.keys()) == {
        "nodes",
        "users",
        "roles",
        "teams",
        "enforcements",
        "aliases",
    }
    assert all(isinstance(v, list) for v in snap.values())


def test_unsupported_capabilities_and_tenant_bindings_empty() -> None:
    mp = MockProvider("x")
    assert mp.unsupported_capabilities() == []
    assert mp.check_tenant_bindings() == []


def test_apply_privileged_access_delete_emits_skipped_noop() -> None:
    provider = MockProvider("pa")
    plan = build_plan(
        "pa",
        [
            Change(
                kind=ChangeKind.DELETE,
                uid_ref="jit1",
                resource_type="pam_project",
                title="p",
                keeper_uid="k",
                before={},
            ),
        ],
        ["jit1"],
    )
    out = provider.apply_privileged_access_plan(plan, dry_run=False)
    assert out[0].action == "noop"
    assert out[0].details.get("skipped") == "delete"
