"""Offline tests for Commander PAM rotation readback wiring."""

from __future__ import annotations

import json

import pytest

from dsk.core.metadata import encode_marker, serialize_marker
from dsk.providers import commander_cli
from dsk.providers.commander_cli import CommanderCliProvider


def _marker(uid_ref: str) -> dict[str, object]:
    return {
        "type": "text",
        "label": "keeper_declarative_manager",
        "value": [
            serialize_marker(
                encode_marker(
                    uid_ref=uid_ref,
                    manifest="customer-prod",
                    resource_type="pamUser",
                )
            )
        ],
    }


def _manifest() -> dict[str, object]:
    return {
        "version": "1",
        "name": "customer-prod",
        "resources": [
            {
                "uid_ref": "res.db",
                "type": "pamDatabase",
                "title": "db-prod",
                "users": [
                    {
                        "uid_ref": "usr.db",
                        "type": "pamUser",
                        "title": "db-user",
                        "rotation_settings": {
                            "rotation": "general",
                            "enabled": "on",
                            "schedule": {"type": "CRON", "cron": "30 18 * * *"},
                            "password_complexity": "32,5,5,5,5",
                        },
                    },
                    {"uid_ref": "usr.admin", "type": "pamUser", "title": "admin-user"},
                ],
            }
        ],
    }


def test_get_pam_rotation_state_calls_record_uid_json(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: "/usr/bin/keeper")
    monkeypatch.setattr(commander_cli, "_supports_rotation_info_json", lambda: True)
    calls: list[list[str]] = []

    def fake_run(self: CommanderCliProvider, args: list[str]) -> str:
        calls.append(args)
        return json.dumps(
            [
                {
                    "record_uid": "USER_UID",
                    "rotation_profile": "general",
                    "enabled": True,
                    "schedule": {"type": "CRON", "cron": "30 18 * * *"},
                    "password_complexity": "32,5,5,5,5",
                }
            ]
        )

    monkeypatch.setattr(CommanderCliProvider, "_run_cmd", fake_run)
    provider = CommanderCliProvider(folder_uid="folder-uid")

    assert provider._get_pam_rotation_state("USER_UID") == {
        "rotation": "general",
        "enabled": "on",
        "schedule": {"type": "CRON", "cron": "30 18 * * *"},
        "password_complexity": "32,5,5,5,5",
    }
    assert calls == [["pam", "rotation", "info", "--record-uid", "USER_UID", "--format", "json"]]


def test_discover_populates_rotation_settings_on_nested_pam_user(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: "/usr/bin/keeper")
    monkeypatch.setattr(commander_cli, "_supports_rotation_info_json", lambda: True)
    calls: list[list[str]] = []

    def fake_run(self: CommanderCliProvider, args: list[str]) -> str:
        calls.append(args)
        if args == ["ls", "folder-uid", "--format", "json"]:
            return json.dumps(
                [
                    {
                        "type": "record",
                        "uid": "USER_UID",
                        "name": "db-user",
                        "details": "Type: pamUser, Description: ...",
                    },
                    {
                        "type": "record",
                        "uid": "ADMIN_UID",
                        "name": "admin-user",
                        "details": "Type: pamUser, Description: ...",
                    },
                ]
            )
        if args == ["get", "USER_UID", "--format", "json"]:
            return json.dumps(
                {
                    "record_uid": "USER_UID",
                    "title": "db-user",
                    "type": "pamUser",
                    "fields": [],
                    "custom": [_marker("usr.db")],
                }
            )
        if args == ["get", "ADMIN_UID", "--format", "json"]:
            return json.dumps(
                {
                    "record_uid": "ADMIN_UID",
                    "title": "admin-user",
                    "type": "pamUser",
                    "fields": [],
                    "custom": [_marker("usr.admin")],
                }
            )
        if args == ["pam", "rotation", "info", "--record-uid", "USER_UID", "--format", "json"]:
            return json.dumps(
                {
                    "rotations": [
                        {
                            "recordUid": "USER_UID",
                            "rotationSettings": {
                                "rotation": "general",
                                "enabled": "on",
                                "schedule": {"type": "CRON", "cron": "30 18 * * *"},
                                "passwordComplexity": "32,5,5,5,5",
                            },
                        }
                    ]
                }
            )
        raise AssertionError(f"unexpected command: {args}")

    monkeypatch.setattr(CommanderCliProvider, "_run_cmd", fake_run)
    provider = CommanderCliProvider(folder_uid="folder-uid", manifest_source=_manifest())
    provider._manifest_name = None

    records = provider.discover()

    by_uid = {record.keeper_uid: record for record in records}
    assert by_uid["USER_UID"].payload["rotation_settings"] == {
        "rotation": "general",
        "enabled": "on",
        "schedule": {"type": "CRON", "cron": "30 18 * * *"},
        "password_complexity": "32,5,5,5,5",
    }
    assert "rotation_settings" not in by_uid["ADMIN_UID"].payload
    assert [
        "pam",
        "rotation",
        "info",
        "--record-uid",
        "USER_UID",
        "--format",
        "json",
    ] in calls


def test_get_pam_rotation_state_v17_returns_empty_without_cli(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Commander without JSON rotation info readback skips subprocess."""
    provider = CommanderCliProvider.__new__(CommanderCliProvider)

    def boom(*_args: object, **_kwargs: object) -> str:
        raise AssertionError("_run_cmd must not run when rotation JSON is unavailable")

    monkeypatch.setattr(commander_cli, "_supports_rotation_info_json", lambda: False)
    provider._run_cmd = boom  # type: ignore[method-assign]

    assert provider._get_pam_rotation_state("rec-uid-a") == {}


def test_get_pam_rotation_state_capability_calls_pam_rotation_info(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)
    calls: list[list[str]] = []

    def fake_run_cmd(args: list[str]) -> str:
        calls.append(args)
        return json.dumps([{"record_uid": "rec-uid-b", "rotation": "lab-profile"}])

    monkeypatch.setattr(commander_cli, "_supports_rotation_info_json", lambda: True)
    provider._run_cmd = fake_run_cmd  # type: ignore[method-assign]

    out = provider._get_pam_rotation_state("rec-uid-b")

    assert calls == [
        ["pam", "rotation", "info", "--record-uid", "rec-uid-b", "--format", "json"],
    ]
    assert out == {"rotation": "lab-profile"}


def test_rotation_readback_rows_prefers_nested_rotations_list() -> None:
    """``pam rotation list`` often wraps rows in a rotations array."""
    data = {
        "rotations": [
            {"record_uid": "u1", "rotation": "ignored"},
            {"recordUid": "u2", "rotation_profile": "db-profile"},
        ]
    }
    rows = commander_cli._rotation_readback_rows(data)
    assert len(rows) == 2
    assert rows[1].get("recordUid") == "u2"


def test_rotation_settings_from_readback_selects_matching_row_only() -> None:
    """Readback payloads may contain multiple rotations; filtering must match UID."""
    data = [
        {"record_uid": "other", "rotation": "foreign"},
        {
            "record_uid": "target",
            "enabled": False,
            "password_complexity": "16,4,4,4,4",
        },
    ]
    got = commander_cli._rotation_settings_from_readback(data, uid="target")
    assert "rotation" not in got
    assert got.get("enabled") == "off"
    assert got["password_complexity"] == "16,4,4,4,4"


def test_rotation_info_json_shape_maps_disabled_and_manual_schedule() -> None:
    data = {
        "disabled": False,
        "schedule_type": "manual",
        "password_complexity": "20,5,5,5,5",
    }

    assert commander_cli._rotation_settings_from_readback(data, uid="target") == {
        "enabled": "on",
        "schedule": {"type": "on-demand"},
        "password_complexity": "20,5,5,5,5",
    }


def test_rotation_readback_flat_mapping_becomes_singleton_row_list() -> None:
    """A single-object JSON body should still yield one parseable mapping row."""
    flat = {"record_uid": "solo", "rotation": "minimal"}
    rows = commander_cli._rotation_readback_rows(flat)
    assert rows == [flat]
