"""Tests for ``dsk scan`` CLI."""

from __future__ import annotations

import json

import yaml
from click.testing import CliRunner

from dsk.cli.main import main


def _run(args: list[str]):
    runner = CliRunner()
    return runner.invoke(main, args, catch_exceptions=False)


def test_scan_nhi_drift_help() -> None:
    result = _run(["scan", "nhi-drift", "--help"])
    assert result.exit_code == 0
    assert "--manifests" in result.output


def test_scan_nhi_drift_empty_dir(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("empty_scan")
    result = _run(["scan", "nhi-drift", "--manifests", str(tmp)])
    assert result.exit_code == 0
    assert "Declared NHI resources: 0" in result.output


def test_scan_nhi_drift_with_nhi_manifest(tmp_path) -> None:
    doc = {
        "schema": "nhi-agent.v1",
        "resources": [
            {
                "uid_ref": "nhi.ci-runner",
                "name": "CI Pipeline Runner",
                "type": "service_account",
                "purpose": "deploy",
                "scope": [],
                "allowed_tools": [],
            },
        ],
    }
    mf = tmp_path / "agents.yaml"
    mf.write_text(yaml.dump(doc, default_flow_style=False, sort_keys=False), encoding="utf-8")

    result = _run(["scan", "nhi-drift", "--manifests", str(tmp_path)])
    assert result.exit_code == 0
    assert "Declared NHI resources: 1" in result.output


def test_scan_nhi_drift_json_format(tmp_path_factory) -> None:
    tmp = tmp_path_factory.mktemp("json_scan")
    result = _run(["scan", "nhi-drift", "--manifests", str(tmp), "--format", "json"])
    assert result.exit_code == 0
    data = json.loads(result.output.strip())
    assert data["declared_nhi_resources"] == 0
    assert data["manifest_counts"]["nhi-agent.v1"] == 0
    assert data["manifest_counts"]["ai-agent.v1"] == 0
    assert data["resources"] == []


def test_scan_nhi_drift_with_ai_agent_manifest(tmp_path) -> None:
    doc = {
        "schema": "ai-agent.v1",
        "resources": [
            {
                "uid_ref": "agent.codex",
                "name": "OpenAI Codex Agent",
                "purpose": "coding_assistant",
                "scope": ["vault:read"],
                "allowed_tools": ["code_execute"],
            },
        ],
    }
    mf = tmp_path / "agents.yaml"
    mf.write_text(__import__("yaml").dump(doc, default_flow_style=False), encoding="utf-8")

    result = _run(["scan", "nhi-drift", "--manifests", str(tmp_path)])
    assert result.exit_code == 0
    assert "Declared NHI resources: 1" in result.output


def test_scan_nhi_drift_mixed_manifests_json(tmp_path) -> None:
    import yaml as _yaml

    nhi_doc = {
        "schema": "nhi-agent.v1",
        "resources": [
            {
                "uid_ref": "nhi.svc-a",
                "name": "Service A",
                "type": "service_account",
                "purpose": "deploy",
                "scope": [],
                "allowed_tools": [],
            },
        ],
    }
    ai_doc = {
        "schema": "ai-agent.v1",
        "resources": [
            {
                "uid_ref": "agent.gpt",
                "name": "GPT-4 Agent",
                "purpose": "code_review",
                "scope": ["vault:read"],
                "allowed_tools": [],
            },
        ],
    }
    (tmp_path / "nhi.yaml").write_text(_yaml.dump(nhi_doc), encoding="utf-8")
    (tmp_path / "ai.yaml").write_text(_yaml.dump(ai_doc), encoding="utf-8")

    result = _run(["scan", "nhi-drift", "--manifests", str(tmp_path), "--format", "json"])
    assert result.exit_code == 0
    data = __import__("json").loads(result.output.strip())
    assert data["declared_nhi_resources"] == 2
    assert data["manifest_counts"]["nhi-agent.v1"] == 1
    assert data["manifest_counts"]["ai-agent.v1"] == 1
    assert len(data["resources"]) == 2


def test_scan_nhi_drift_ignores_invalid_yaml(tmp_path) -> None:
    (tmp_path / "broken.yaml").write_text("schema: totally-unknown-family.v99\n", encoding="utf-8")
    result = _run(["scan", "nhi-drift", "--manifests", str(tmp_path)])
    assert result.exit_code == 0
    assert "Declared NHI resources: 0" in result.output
