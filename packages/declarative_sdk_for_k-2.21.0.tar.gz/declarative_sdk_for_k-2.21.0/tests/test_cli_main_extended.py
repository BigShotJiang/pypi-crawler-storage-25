"""Extended CLI and private-family tests for main.py and _private_families coverage."""

from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import (
    EXIT_CAPABILITY,
    EXIT_CHANGES,
    EXIT_GENERIC,
    EXIT_OK,
    EXIT_SCHEMA,
)
from dsk.core._private_families import (
    KEEPER_DRIVE_FAMILY,
    load_private_manifest,
    register_private,
)
from dsk.core.models_k8s_eso import K8S_ESO_FAMILY
from dsk.core.schema import SCHEMA_RESOURCE_BY_FAMILY

cli_main_module = importlib.import_module("dsk.cli.main")


def _run(args: list[str]) -> Any:
    return CliRunner().invoke(main, args, catch_exceptions=False)


def _k8s_eso_doc() -> dict[str, Any]:
    return {
        "schema": K8S_ESO_FAMILY,
        "eso_stores": [
            {
                "name": "keeper-prod",
                "ks_uid": "ksm-config-secret",
                "namespace": "external-secrets",
            }
        ],
        "external_secrets": [
            {
                "name": "database-credentials",
                "store_ref": "keeper-prod",
                "target_k8s_secret": "database-credentials",
                "data": [
                    {
                        "keeper_uid_ref": "ABC123",
                        "remote_key": "username",
                        "property": "login",
                    },
                ],
            }
        ],
    }


def test_plan_format_json_outputs_parseable_plan_dict(tmp_path: Path) -> None:
    path = tmp_path / "eso.json"
    path.write_text(json.dumps(_k8s_eso_doc()), encoding="utf-8")

    result = _run(["plan", str(path), "--format", "json"])
    assert result.exit_code == EXIT_CHANGES, result.output
    data = json.loads(result.output.strip())
    assert data["manifest_name"] in {"eso", "keeper-k8s-eso.v1"}
    assert data["summary"]["create"] >= 1
    assert len(data["changes"]) >= 1
    assert {c.get("kind") for c in data["changes"]} == {"create"}


def test_plan_format_json_matches_delivery_family(tmp_path: Path) -> None:
    """keeper-k8s-eso.v1 plan via explicit --format json (delivery-only family)."""
    path = tmp_path / "k8s.json"
    path.write_text(json.dumps(_k8s_eso_doc()), encoding="utf-8")

    result = _run(["plan", str(path), "--format", "json", "--allow-delete"])
    assert result.exit_code == EXIT_CHANGES, result.output
    body = result.output.strip()
    assert K8S_ESO_FAMILY in body


def test_plan_unsupported_output_format_exits_capability() -> None:
    repo = Path(__file__).resolve().parents[1]
    manifest = repo / "examples" / "pam" / "acme-k8s-eso.yaml"

    result = _run(["plan", str(manifest), "--format", "xml"])
    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "not implemented" in result.output.lower()


def test_apply_dry_run_mock_vault_shows_plan_and_exits_changes(tmp_path: Path) -> None:
    vault = tmp_path / "v.yaml"
    vault.write_text(
        "schema: keeper-vault.v1\n"
        "records:\n"
        "  - uid_ref: cli.v.login\n"
        "    type: login\n"
        "    title: CLI Vault Login\n",
        encoding="utf-8",
    )
    result = _run(["--provider", "mock", "apply", str(vault), "--dry-run"])
    assert result.exit_code == EXIT_CHANGES, result.output
    assert "create" in result.output.lower() or "Create" in result.output


def test_validate_manifest_not_a_file_exits_generic(tmp_path: Path) -> None:
    result = _run(["validate", str(tmp_path)])
    assert result.exit_code == EXIT_GENERIC, result.output
    assert "manifest" in result.output.lower() or "not found" in result.output.lower()


def test_validate_missing_path_click_error() -> None:
    result = _run(["validate", "/no/such/manifest/path/dsk-test-404.yaml"])
    assert result.exit_code != 0
    assert result.exit_code == 2


def test_validate_rejects_bad_schema_document(tmp_path: Path) -> None:
    bad = tmp_path / "bad.yaml"
    bad.write_text(
        "schema: keeper-vault.v1\nrecords:\n  - uid_ref: x\n    type: not-a-real-type\n",
        encoding="utf-8",
    )
    result = _run(["validate", str(bad)])
    assert result.exit_code == EXIT_SCHEMA, result.output


def test_scan_nhi_drift_live_flag_exits_capability() -> None:
    result = _run(["scan", "nhi-drift", "--live"])
    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "upstream" in result.output.lower() or "live" in result.output.lower()


def test_scan_nhi_drift_text_format_lists_families(tmp_path: Path) -> None:
    result = _run(["scan", "nhi-drift", "--manifests", str(tmp_path), "--format", "text"])
    assert result.exit_code == EXIT_OK, result.output
    assert "Declared NHI resources: 0" in result.output
    assert "nhi-agent.v1" in result.output


def test_register_private_none_uses_packaged_schema_registry() -> None:
    register_private(None)
    assert KEEPER_DRIVE_FAMILY in SCHEMA_RESOURCE_BY_FAMILY


def test_register_private_setdefault_does_not_clobber_existing() -> None:
    reg: dict[str, str] = {"keeper-drive.v1": "custom"}
    register_private(reg)
    assert reg["keeper-drive.v1"] == "custom"


def test_load_private_manifest_returns_typed_drive_manifest() -> None:
    doc = {"schema": "keeper-drive.v1", "folders": [], "files": [], "shares": []}
    loaded = load_private_manifest(KEEPER_DRIVE_FAMILY, doc)
    assert loaded is not None
    assert loaded.keeper_drive_schema == KEEPER_DRIVE_FAMILY


def test_load_private_manifest_public_family_still_none() -> None:
    assert load_private_manifest("keeper-vault.v1", {"schema": "keeper-vault.v1"}) is None


def test_doctor_reports_missing_optional_packages(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_version(_name: str) -> str:
        raise cli_main_module.metadata.PackageNotFoundError

    monkeypatch.setattr(cli_main_module.metadata, "version", fake_version)
    monkeypatch.delenv("KEEPER_EMAIL", raising=False)
    monkeypatch.delenv("KEEPER_TOTP_SECRET", raising=False)
    monkeypatch.delenv("DSK_PREVIEW", raising=False)

    result = _run(["doctor"])

    assert result.exit_code == EXIT_GENERIC, result.output
    assert "keepercommander" in result.output
    assert "missing" in result.output
    assert "DSK_PREVIEW" in result.output


def test_webui_missing_extra_exits_capability(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "webui", None)

    result = _run(["webui"])

    assert result.exit_code == EXIT_CAPABILITY, result.output
    assert "webui dependencies missing" in result.output


def test_spiffe_verify_rejects_both_manifest_forms(tmp_path: Path) -> None:
    manifest = tmp_path / "spiffe.json"
    manifest.write_text(json.dumps({"trust_domain": "example.com"}), encoding="utf-8")

    result = _run(
        [
            "spiffe-verify",
            str(manifest),
            "--manifest",
            str(manifest),
            "--jwt",
            "token",
        ]
    )

    assert result.exit_code == 2
    assert "not both" in result.output


def test_spiffe_verify_requires_manifest_path() -> None:
    result = _run(["spiffe-verify", "--jwt", "token"])

    assert result.exit_code == 2
    assert "missing manifest path" in result.output


def test_spiffe_verify_requires_exactly_one_jwt_source(tmp_path: Path) -> None:
    manifest = tmp_path / "spiffe.json"
    token_file = tmp_path / "token.jwt"
    manifest.write_text(json.dumps({"trust_domain": "example.com"}), encoding="utf-8")
    token_file.write_text("token", encoding="utf-8")

    no_token = _run(["spiffe-verify", str(manifest)])
    both_tokens = _run(
        [
            "spiffe-verify",
            str(manifest),
            "--jwt",
            "token",
            "--jwt-file",
            str(token_file),
        ]
    )

    assert no_token.exit_code == 2
    assert both_tokens.exit_code == 2
    assert "exactly one" in no_token.output
    assert "exactly one" in both_tokens.output
