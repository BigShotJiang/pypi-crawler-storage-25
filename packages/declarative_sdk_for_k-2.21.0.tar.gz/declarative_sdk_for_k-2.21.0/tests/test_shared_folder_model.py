"""Offline shared-folder model skeleton tests."""

from __future__ import annotations

from dsk.core.diff import ChangeKind
from dsk.core.vault_models import VaultSharedFolder, diff_shared_folder


def _shared_folder(*, members: list[dict[str, str]] | None = None) -> VaultSharedFolder:
    return VaultSharedFolder.model_validate(
        {
            "title": "Ops Shared",
            "uid_ref": "sf.ops",
            "manager": "keeper-pam-declarative",
            "members": members
            if members is not None
            else [{"email": "alice@example.com", "role": "manage"}],
            "permissions": {"manage_records": True, "manage_users": False},
        }
    )


def test_build_shared_folder_from_dict_fields_correct() -> None:
    folder = _shared_folder()

    assert folder.title == "Ops Shared"
    assert folder.uid_ref == "sf.ops"
    assert folder.manager == "keeper-pam-declarative"
    assert folder.members == [{"email": "alice@example.com", "role": "manage"}]
    assert folder.permissions == {"manage_records": True, "manage_users": False}


def test_shared_folder_diff_member_added_update() -> None:
    before = _shared_folder()
    after = _shared_folder(
        members=[
            {"email": "alice@example.com", "role": "manage"},
            {"email": "bob@example.com", "role": "read"},
        ]
    )

    row = diff_shared_folder(before, after)

    assert row.kind is ChangeKind.UPDATE
    assert row.before["members"] == [{"email": "alice@example.com", "role": "manage"}]
    assert row.after["members"] == [
        {"email": "alice@example.com", "role": "manage"},
        {"email": "bob@example.com", "role": "read"},
    ]


def test_shared_folder_diff_member_removed_update() -> None:
    before = _shared_folder(
        members=[
            {"email": "alice@example.com", "role": "manage"},
            {"email": "bob@example.com", "role": "read"},
        ]
    )
    after = _shared_folder()

    row = diff_shared_folder(before, after)

    assert row.kind is ChangeKind.UPDATE
    assert row.before["members"] == [
        {"email": "alice@example.com", "role": "manage"},
        {"email": "bob@example.com", "role": "read"},
    ]
    assert row.after["members"] == [{"email": "alice@example.com", "role": "manage"}]


def test_shared_folder_diff_identical_noop() -> None:
    before = _shared_folder()
    after = _shared_folder()

    row = diff_shared_folder(before, after)

    assert row.kind is ChangeKind.NOOP


def test_shared_folder_diff_title_change_produces_update() -> None:
    """Title participates in planner diff payloads for shared folders."""
    before = _shared_folder()
    payload_after = before.model_dump(mode="python") | {"title": "Renamed Ops"}
    after = VaultSharedFolder.model_validate(payload_after)

    row = diff_shared_folder(before, after)

    assert row.kind is ChangeKind.UPDATE
    assert row.before == {"title": "Ops Shared"}
    assert row.after == {"title": "Renamed Ops"}


def test_shared_folder_diff_permissions_change_produces_update() -> None:
    """ACL map changes propagate as bounded UPDATE rows."""
    before = _shared_folder()
    payload_after = before.model_dump(mode="python") | {
        "permissions": {"manage_records": False, "manage_users": True}
    }
    after = VaultSharedFolder.model_validate(payload_after)

    row = diff_shared_folder(before, after)

    assert row.kind is ChangeKind.UPDATE
    assert row.before == {
        "permissions": {"manage_records": True, "manage_users": False},
    }
    assert row.after == {
        "permissions": {"manage_records": False, "manage_users": True},
    }


def test_shared_folder_diff_updates_member_role_preserves_identity() -> None:
    """Member email stable with role escalation should still emit UPDATE."""
    before = _shared_folder(members=[{"email": "alice@example.com", "role": "read"}])
    after = _shared_folder(members=[{"email": "alice@example.com", "role": "manage"}])

    row = diff_shared_folder(before, after)

    assert row.kind is ChangeKind.UPDATE
    assert row.before["members"][0]["role"] == "read"
    assert row.after["members"][0]["role"] == "manage"
