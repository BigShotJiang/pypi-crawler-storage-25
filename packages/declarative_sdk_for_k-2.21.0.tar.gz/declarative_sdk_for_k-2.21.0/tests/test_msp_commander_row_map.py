"""Unit tests for Commander → SDK managed-company row mapping."""

from __future__ import annotations

import pytest

from dsk.providers.commander_cli import _commander_mc_dict_to_sdk_row


def test_commander_row_maps_product_id_and_file_plan() -> None:
    row = {
        "mc_enterprise_name": "Acme Corp",
        "mc_enterprise_id": 42,
        "number_of_seats": 5,
        "product_id": 1,
        "file_plan_type": "STORAGE_100GB",
        "add_ons": [{"name": "chat", "seats": 0}],
    }
    out = _commander_mc_dict_to_sdk_row(row)
    assert out["name"] == "Acme Corp"
    assert out["plan"] == "business"
    assert out["seats"] == 5
    assert out["mc_enterprise_id"] == 42
    assert out["file_plan"] == "100GB"
    assert out["addons"] == [{"name": "chat", "seats": 0}]


def test_commander_row_unlimited_seats() -> None:
    row = {
        "mc_enterprise_name": "BigCo",
        "mc_enterprise_id": 1,
        "number_of_seats": 2147483647,
        "product_id": "enterprise",
        "file_plan_type": None,
        "add_ons": [],
    }
    out = _commander_mc_dict_to_sdk_row(row)
    assert out["seats"] == -1
    assert out["plan"] == "enterprise"


def test_commander_row_rejects_empty_name() -> None:
    with pytest.raises(ValueError):
        _commander_mc_dict_to_sdk_row(
            {
                "mc_enterprise_name": "  ",
                "product_id": 1,
                "number_of_seats": 1,
            }
        )


def test_commander_row_maps_product_id_2_to_business_plus() -> None:
    row = {
        "mc_enterprise_name": "Plus Corp",
        "mc_enterprise_id": 99,
        "number_of_seats": 10,
        "product_id": 2,
        "add_ons": [],
    }
    out = _commander_mc_dict_to_sdk_row(row)
    assert out["plan"] == "businessPlus"
    assert out["name"] == "Plus Corp"


def test_commander_row_missing_product_id_defaults_to_business() -> None:
    row = {
        "mc_enterprise_name": "DefaultCo",
        "mc_enterprise_id": 7,
        "number_of_seats": 3,
        "add_ons": [],
    }
    out = _commander_mc_dict_to_sdk_row(row)
    assert out["plan"] == "business"


def test_commander_row_multiple_addons_preserved() -> None:
    row = {
        "mc_enterprise_name": "Multi Co",
        "mc_enterprise_id": 5,
        "number_of_seats": 1,
        "product_id": 1,
        "add_ons": [{"name": "msp_add_on", "seats": 5}, {"name": "chat", "seats": 0}],
    }
    out = _commander_mc_dict_to_sdk_row(row)
    addon_names = {a["name"] for a in out["addons"]}
    assert "msp_add_on" in addon_names
    assert "chat" in addon_names
