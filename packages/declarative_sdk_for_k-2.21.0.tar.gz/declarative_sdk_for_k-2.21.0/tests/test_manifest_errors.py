"""Tests for improved manifest validation error messages."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from dsk.core.errors import CapabilityError, ManifestError, RefError, SchemaError
from dsk.core.graph import build_graph
from dsk.core.manifest import (
    load_declarative_manifest_string,
    load_manifest,
    read_manifest_document_string,
)
from dsk.core.models_ai_act import AiActProfileManifestV1
from dsk.core.models_ai_policy import AiPolicyManifestV1
from dsk.core.models_ai_token import AiTokenManifestV1
from dsk.core.models_cmmc import CmmcProfileManifestV1
from dsk.core.models_dora import DoraProfileManifestV1
from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1
from dsk.core.models_pqc import PqcPolicyManifestV1
from dsk.core.models_slack_gate import SlackApprovalGateManifestV1
from dsk.core.schema import resolve_manifest_family, validate_manifest


def test_unknown_family_message_is_helpful() -> None:
    """Unknown family should name the family and list known ones."""
    with pytest.raises(SchemaError) as exc_info:
        resolve_manifest_family({"schema": "not-a-real-family.v1"})
    msg = str(exc_info.value).lower()
    assert "not-a-real-family" in msg
    assert "known families" in msg


def test_missing_required_field_message_points_to_validation_stages() -> None:
    """JSON Schema *required* violations should cite VALIDATION_STAGES."""
    raw = yaml.safe_dump(
        {"schema": "keeper-vault.v1", "records": [{"type": "login"}]},
        sort_keys=False,
    )
    doc = read_manifest_document_string(raw, suffix=".yaml")
    with pytest.raises(SchemaError) as exc_info:
        validate_manifest(doc)
    msg = str(exc_info.value)
    assert "VALIDATION_STAGES.md" in msg
    assert "required" in msg.lower() or "missing" in msg.lower()


def test_duplicate_uid_ref_message_names_manifest() -> None:
    """PAM graph duplicate uid_ref errors should name the manifest and ref."""
    path = Path(__file__).resolve().parent / "fixtures/examples/invalid/duplicate-uid-ref.yaml"
    manifest = load_manifest(path)
    with pytest.raises(RefError) as exc_info:
        build_graph(manifest)
    msg = str(exc_info.value)
    assert "Duplicate uid_ref" in msg
    assert "dup-1" in msg
    assert "invalid-duplicate-uid-ref" in msg


def test_manifest_error_str_includes_uid_ref_and_next_action() -> None:
    """Operators should see resource context and a concrete next step."""
    err = RefError(
        reason="target record is missing",
        uid_ref="pam.db",
        resource_type="pamDatabase",
        next_action="ensure the record exists or fix the uid_ref",
    )
    text = str(err)
    assert "pamDatabase" in text
    assert "uid_ref=pam.db" in text
    assert "Next:" in text


def test_schema_error_is_actionable_schema_bucket() -> None:
    """SchemaError shares the ManifestError string shape for CLI surfacing."""
    err = SchemaError(reason="JSON Schema validation failed", next_action="repair the manifest")
    text = str(err)
    assert "JSON Schema validation failed" in text
    assert "repair the manifest" in text


def test_capability_error_names_operator_remediation_path() -> None:
    """CapabilityError is used for missing platform support; message must guide."""
    err = CapabilityError(
        reason="KSM client API unavailable in this environment",
        next_action="install optional [ksm] extras or use mock provider",
        resource_type="ksm_app",
        uid_ref="app.api",
    )
    text = str(err)
    assert "ksm_app" in text
    assert "uid_ref=app.api" in text
    assert "[ksm]" in text or "mock" in text.lower()


def test_load_manifest_rejects_oversized_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "large.yaml"
    manifest.write_text("schema: pam-environment.v1\n" + ("x" * 64), encoding="utf-8")
    monkeypatch.setenv("DSK_MAX_MANIFEST_BYTES", "16")

    with pytest.raises(ManifestError, match="exceeding DSK_MAX_MANIFEST_BYTES"):
        load_manifest(manifest)


def test_load_manifest_rejects_invalid_manifest_size_env(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("schema: pam-environment.v1\nname: t\nversion: '1'\n", encoding="utf-8")
    monkeypatch.setenv("DSK_MAX_MANIFEST_BYTES", "not-an-int")

    with pytest.raises(ManifestError, match="must be an integer"):
        load_manifest(manifest)


def _minimal_declarative_doc(schema: str, name: str) -> dict[str, str]:
    """Fields required by family JSON Schemas (defaults are not injected pre-validate)."""
    return {"schema": schema, "name": name, "version": "1", "manager": "dsk"}


def test_load_declarative_manifest_string_ai_act_profile_v1_minimal() -> None:
    doc = _minimal_declarative_doc("ai-act-profile.v1", "t-min-ai-act")
    loaded = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert isinstance(loaded, AiActProfileManifestV1)


def test_load_declarative_manifest_string_keeper_ai_policy_v1_minimal() -> None:
    doc = _minimal_declarative_doc("keeper-ai-policy.v1", "t-min-ai-policy")
    loaded = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert isinstance(loaded, AiPolicyManifestV1)


def test_load_declarative_manifest_string_ai_token_v1_minimal() -> None:
    doc = _minimal_declarative_doc("ai-token.v1", "t-min-ai-token")
    loaded = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert isinstance(loaded, AiTokenManifestV1)


def test_load_declarative_manifest_string_cmmc_profile_v1_minimal() -> None:
    doc = _minimal_declarative_doc("cmmc-profile.v1", "t-min-cmmc")
    loaded = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert isinstance(loaded, CmmcProfileManifestV1)


def test_load_declarative_manifest_string_dora_profile_v1_minimal() -> None:
    doc = _minimal_declarative_doc("dora-profile.v1", "t-min-dora")
    loaded = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert isinstance(loaded, DoraProfileManifestV1)


def test_load_declarative_manifest_string_pqc_policy_v1_minimal() -> None:
    doc = _minimal_declarative_doc("pqc-policy.v1", "t-min-pqc")
    loaded = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert isinstance(loaded, PqcPolicyManifestV1)


def test_load_declarative_manifest_string_itsm_approval_gate_v1_minimal() -> None:
    doc = _minimal_declarative_doc("itsm-approval-gate.v1", "t-min-itsm-gate")
    loaded = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert isinstance(loaded, ItsmApprovalGateManifestV1)


def test_load_declarative_manifest_string_slack_approval_gate_v1_minimal() -> None:
    doc = _minimal_declarative_doc("slack-approval-gate.v1", "t-min-slack-gate")
    loaded = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert isinstance(loaded, SlackApprovalGateManifestV1)


def test_read_manifest_document_string_parses_json_minimal() -> None:
    """JSON input with suffix=.json should parse to the same shape as YAML."""
    doc = _minimal_declarative_doc("pqc-policy.v1", "t-json-parse")
    raw = json.dumps(doc)
    parsed = read_manifest_document_string(raw, suffix=".json")
    assert parsed.get("schema") == "pqc-policy.v1"
    assert parsed.get("name") == "t-json-parse"


def test_load_manifest_raises_for_missing_path(tmp_path: Path) -> None:
    """load_manifest raises ManifestError when file does not exist."""
    import pytest

    from dsk.core.errors import ManifestError
    from dsk.core.manifest import load_manifest

    with pytest.raises(ManifestError, match="manifest not found"):
        load_manifest(tmp_path / "nonexistent.yaml")


def test_read_manifest_document_raises_for_non_mapping(tmp_path: Path) -> None:
    """read_manifest_document_string raises SchemaError for YAML list (not mapping)."""
    import pytest

    from dsk.core.errors import SchemaError
    from dsk.core.manifest import read_manifest_document_string

    with pytest.raises(SchemaError, match="mapping"):
        read_manifest_document_string("- item1\n- item2\n")


def test_load_declarative_manifest_string_validate_false_raises() -> None:
    """load_declarative_manifest_string with validate=False must raise ManifestError."""
    import pytest

    from dsk.core.errors import ManifestError
    from dsk.core.manifest import load_declarative_manifest_string

    with pytest.raises(ManifestError, match="validate=True"):
        load_declarative_manifest_string(
            "schema: pam-environment.v1\nversion: '1'\nname: t\n",
            validate=False,
        )


def test_load_declarative_manifest_raises_for_missing_path(tmp_path: Path) -> None:
    """load_declarative_manifest raises ManifestError when file does not exist."""
    import pytest

    from dsk.core.errors import ManifestError
    from dsk.core.manifest import load_declarative_manifest

    with pytest.raises(ManifestError, match="manifest not found"):
        load_declarative_manifest(tmp_path / "missing.yaml")


# ── Typed dispatch coverage for families not hit by other tests ──────────────


_DISPATCH_FAMILIES = [
    (
        "spiffe-binding.v1",
        {"schema": "spiffe-binding.v1", "name": "test", "trust_domain": "example.org"},
    ),
    (
        "workflow-gate.v1",
        {"schema": "workflow-gate.v1", "name": "test", "version": "1.0", "steps": []},
    ),
    (
        "ai-agent-trust-chain.v1",
        {"schema": "ai-agent-trust-chain.v1", "name": "test", "version": "1.0", "chains": []},
    ),
    (
        "pam-connection-profile.v1",
        {"schema": "pam-connection-profile.v1", "name": "test", "version": "1.0", "tunnels": []},
    ),
    (
        "db-access-policy.v1",
        {"schema": "db-access-policy.v1", "name": "test", "version": "1.0", "policies": []},
    ),
    (
        "gateway-ha.v1",
        {"schema": "gateway-ha.v1", "name": "test", "version": "1.0", "gateways": []},
    ),
    ("keeper-enterprise.v1", {"schema": "keeper-enterprise.v1"}),
    ("keeper-workflow.v1", {"schema": "keeper-workflow.v1"}),
    ("keeper-saas-rotation.v1", {"schema": "keeper-saas-rotation.v1"}),
    (
        "compliance-bundle.v1",
        {"schema": "compliance-bundle.v1", "name": "test", "version": "1.0", "bundles": []},
    ),
    (
        "cloud-jit.v1",
        {"schema": "cloud-jit.v1", "name": "test", "version": "1.0", "configurations": []},
    ),
    ("keeper-drive.v1", {"schema": "keeper-drive.v1", "folders": [], "files": [], "shares": []}),
    (
        "continuous-evidence-stream.v1",
        {
            "schema": "continuous-evidence-stream.v1",
            "name": "test",
            "version": "1.0",
            "streams": [],
        },
    ),
    (
        "cspm-remediation.v1",
        {"schema": "cspm-remediation.v1", "name": "test", "version": "1.0", "remediations": []},
    ),
    (
        "secret-scanner-bridge.v1",
        {
            "schema": "secret-scanner-bridge.v1",
            "name": "test",
            "version": "1.0",
            "repos": [],
            "mappings": [],
        },
    ),
    ("keeper-agent-kit.v1", {"schema": "keeper-agent-kit.v1", "name": "test"}),
    (
        "pipeline-ephemeral-environment.v1",
        {
            "schema": "pipeline-ephemeral-environment.v1",
            "name": "test",
            "version": "1.0",
            "pipelines": [],
        },
    ),
    ("keeper-tunnel.v1", {"schema": "keeper-tunnel.v1"}),
    ("keeper-privileged-access.v1", {"schema": "keeper-privileged-access.v1"}),
    (
        "mcp-secrets-binding.v1",
        {"schema": "mcp-secrets-binding.v1", "name": "test", "version": "1.0", "bindings": []},
    ),
    ("jit-access.v1", {"schema": "jit-access.v1", "name": "test"}),
    ("epm-policy.v1", {"schema": "epm-policy.v1", "name": "test", "version": "1.0"}),
    ("rotation-policy.v1", {"schema": "rotation-policy.v1", "name": "test"}),
    ("keeper-scim.v1", {"schema": "keeper-scim.v1", "name": "test"}),
]


@pytest.mark.parametrize("family,doc", _DISPATCH_FAMILIES, ids=[f for f, _ in _DISPATCH_FAMILIES])
def test_load_declarative_manifest_string_dispatch(family: str, doc: dict) -> None:
    """load_declarative_manifest_string correctly dispatches all typed families."""
    import yaml

    from dsk.core.manifest import load_declarative_manifest_string

    yaml_text = yaml.dump(doc)
    manifest = load_declarative_manifest_string(yaml_text)
    # Each family must return a non-None typed manifest
    assert manifest is not None


# ── Typed dispatch error paths (ValidationError → SchemaError) ───────────────

_DISPATCH_ERROR_FAMILIES = [
    # Include version+manager so JSON schema passes; then invalid Pydantic typed field triggers except
    (
        "ai-act-profile.v1",
        {
            "schema": "ai-act-profile.v1",
            "name": "test",
            "version": "1",
            "manager": "dsk",
            "oversight_gates": [{"gate_id": "x"}],
        },
    ),
    (
        "ai-token.v1",
        {
            "schema": "ai-token.v1",
            "name": "test",
            "version": "1",
            "manager": "dsk",
            "tokens": [{"provider": "x"}],
        },
    ),
    (
        "rotation-policy.v1",
        {
            "schema": "rotation-policy.v1",
            "name": "test",
            "version": "1",
            "manager": "dsk",
            "policies": [{"policy_name": "x"}],
        },
    ),
    # Families below fail at JSON-schema stage (strict extra=forbid schema), so SchemaError still raised
    ("keeper-scim.v1", {"schema": "keeper-scim.v1", "name": "test", "nodes": "WRONG"}),
    ("keeper-enterprise.v1", {"schema": "keeper-enterprise.v1", "nodes": "BAD"}),
]


@pytest.mark.parametrize(
    "family,doc", _DISPATCH_ERROR_FAMILIES, ids=[f for f, _ in _DISPATCH_ERROR_FAMILIES]
)
def test_load_declarative_manifest_string_dispatch_invalid_raises_schema_error(
    family: str, doc: dict
) -> None:
    """load_declarative_manifest_string raises SchemaError on invalid typed manifest data."""
    import yaml

    from dsk.core.errors import SchemaError
    from dsk.core.manifest import load_declarative_manifest_string

    with pytest.raises(SchemaError):
        load_declarative_manifest_string(yaml.dump(doc))


def test_load_declarative_manifest_string_keeper_security_posture_v1_raises_unsupported() -> None:
    import pytest
    import yaml

    from dsk.core.errors import SchemaError, UnsupportedFamilyError
    from dsk.core.manifest import load_declarative_manifest_string

    doc = {
        "schema": "keeper-security-posture.v1",
        "name": "posture-test",
        "version": "1",
        "manager": "dsk",
    }
    with pytest.raises((UnsupportedFamilyError, SchemaError)):
        load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)


# ── Sprint BJ part 2: manifest.py structural gaps ─────────────────────────


def test_load_manifest_raises_manifest_error_for_missing_path(tmp_path) -> None:
    from dsk.core.errors import ManifestError
    from dsk.core.manifest import load_manifest

    missing = tmp_path / "nonexistent.yaml"
    with pytest.raises(ManifestError, match="manifest not found"):
        load_manifest(missing)


def test_dump_manifest_json_format() -> None:
    import yaml

    from dsk.core.manifest import dump_manifest, load_declarative_manifest_string

    doc = {"schema": "cmmc-profile.v1", "name": "test-json", "version": "1", "manager": "dsk"}
    manifest = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    result = dump_manifest(manifest, fmt="json")
    import json

    parsed = json.loads(result)
    assert parsed["name"] == "test-json"


def test_dump_manifest_unsupported_format_raises() -> None:
    import yaml

    from dsk.core.manifest import dump_manifest, load_declarative_manifest_string

    doc = {"schema": "cmmc-profile.v1", "name": "test-fmt", "version": "1", "manager": "dsk"}
    manifest = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    with pytest.raises(ValueError, match="unsupported dump format"):
        dump_manifest(manifest, fmt="toml")


def test_load_declarative_manifest_string_keeper_tunnel_v1_minimal() -> None:
    import yaml

    from dsk.core.manifest import load_declarative_manifest_string

    doc = {"schema": "keeper-tunnel.v1"}
    result = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert result is not None


def test_pam_family_typed_validation_error_raises_schema_error() -> None:
    """PAM_FAMILY except (ValueError, TypeError) branch — patch validate_manifest and model_validate."""
    from unittest.mock import patch

    import yaml

    from dsk.core import manifest as _manifest_mod
    from dsk.core.errors import SchemaError
    from dsk.core.manifest import PAM_FAMILY, load_declarative_manifest_string
    from dsk.core.models import Manifest

    doc = {"schema": PAM_FAMILY, "name": "test", "version": "1"}
    # Bypass schema validation by stubbing validate_manifest, then force Pydantic error
    with patch.object(_manifest_mod, "validate_manifest", return_value=PAM_FAMILY):
        with patch.object(Manifest, "model_validate", side_effect=ValueError("pydantic fail")):
            with pytest.raises(SchemaError, match="typed validation failed"):
                load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)


def test_mcp_secrets_binding_v1_minimal() -> None:
    import yaml

    from dsk.core.manifest import load_declarative_manifest_string

    doc = {"schema": "mcp-secrets-binding.v1", "name": "mcp-bind", "version": "1", "manager": "dsk"}
    result = load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
    assert result is not None


def test_keeper_privileged_access_v1_typed_error_raises_schema_error() -> None:
    """keeper-privileged-access.v1 except (ValueError, TypeError) branch."""
    from unittest.mock import patch

    import yaml

    from dsk.core import manifest as _manifest_mod
    from dsk.core.errors import SchemaError
    from dsk.core.manifest import load_declarative_manifest_string

    doc = {"schema": "keeper-privileged-access.v1"}
    with patch.object(
        _manifest_mod, "validate_manifest", return_value="keeper-privileged-access.v1"
    ):
        with patch(
            "dsk.core.models_privileged_access.PrivilegedAccessManifestV1.model_validate",
            side_effect=ValueError("bad field"),
        ):
            with pytest.raises(SchemaError, match="typed validation failed"):
                load_declarative_manifest_string(yaml.safe_dump(doc), validate=True)
