"""Tests for gateway-ha.v1 and epm-policy.v1 models."""

from pathlib import Path

import yaml

from dsk.core.models_epm import EpmPolicy, EpmPolicyManifestV1, EpmRuleEffect
from dsk.core.models_gateway_ha import (
    GatewayHaCluster,
    GatewayHaManifestV1,
    GatewayHaStrategy,
)


def test_gateway_ha_defaults():
    cluster = GatewayHaCluster(name="test-cluster")
    assert cluster.strategy == GatewayHaStrategy.active_passive
    assert cluster.failover_delay_seconds == 0
    assert cluster.members == []


def test_gateway_ha_round_trip():
    example = Path(__file__).parent.parent / "examples/gateway-ha/acme-gw-cluster.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = GatewayHaManifestV1(**data)
    assert manifest.schema_ == "gateway-ha.v1"
    cluster = manifest.clusters[0]
    assert cluster.strategy == GatewayHaStrategy.active_passive
    assert len(cluster.members) == 3
    assert cluster.members[0].priority == 300


def test_epm_policy_defaults():
    policy = EpmPolicy(name="test")
    assert policy.default_effect == EpmRuleEffect.audit
    assert policy.audit_log is True
    assert policy.rules == []


def test_epm_manifest_round_trip():
    example = Path(__file__).parent.parent / "examples/epm/acme-epm-policies.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = EpmPolicyManifestV1(**data)
    assert manifest.schema_ == "epm-policy.v1"
    deny_rule = next(r for r in manifest.policies[0].rules if r.effect == EpmRuleEffect.deny)
    assert deny_rule.match_path is not None and "psexec" in deny_rule.match_path


def test_gateway_ha_schema_alias():
    m = GatewayHaManifestV1(**{"schema": "gateway-ha.v1", "name": "test"})
    assert m.schema_ == "gateway-ha.v1"
