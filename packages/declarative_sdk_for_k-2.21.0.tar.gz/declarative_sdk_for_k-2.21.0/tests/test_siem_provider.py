"""REST provider tests for ``keeper-siem.v1``."""

from __future__ import annotations

from typing import Any

import pytest

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_siem import SIEM_FAMILY, SiemManifestV1
from dsk.providers.rest_provider_base import plan_has_mutations
from dsk.providers.siem_provider import SiemProvider


def _manifest() -> SiemManifestV1:
    return SiemManifestV1.model_validate(
        {
            "schema": SIEM_FAMILY,
            "name": "acme-siem",
            "sinks": [
                {
                    "uid_ref": "sink.splunk",
                    "name": "Splunk",
                    "type": "splunk",
                    "endpoint": "https://splunk.example.com:8088/services/collector",
                }
            ],
        }
    )


def test_siem_provider_plan_returns_diff() -> None:
    provider = SiemProvider(endpoint_base="/siem/configuration")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {
            "sinks": [
                {
                    "uid_ref": "sink.splunk",
                    "name": "Splunk",
                    "type": "splunk",
                    "endpoint": "https://old.example.com/services/collector",
                }
            ],
            "routes": [],
        }
    }

    plan = provider.plan(_manifest())

    assert plan.changes[0].kind is ChangeKind.UPDATE
    assert plan.changes[0].after == {
        "endpoint": "https://splunk.example.com:8088/services/collector"
    }


def test_siem_provider_apply_calls_configured_endpoint() -> None:
    calls: list[tuple[str, dict[str, Any]]] = []
    provider = SiemProvider(endpoint_base="/siem/configuration")

    def fake_rest(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append((endpoint, payload))
        if payload["method"] == "GET":
            return {"configuration": {"sinks": [], "routes": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())

    outcomes = provider.apply_siem_plan(plan)

    assert outcomes[0].action == "create"
    assert calls[-1][0] == "siem/configuration"
    assert calls[-1][1]["method"] == "PUT"
    assert calls[-1][1]["configuration"]["sinks"][0]["uid_ref"] == "sink.splunk"


def test_siem_provider_plan_returns_noop_when_live_matches() -> None:
    provider = SiemProvider(endpoint_base="/siem/configuration")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {
            "sinks": [
                {
                    "uid_ref": "sink.splunk",
                    "name": "Splunk",
                    "type": "splunk",
                    "endpoint": "https://splunk.example.com:8088/services/collector",
                }
            ],
            "routes": [],
        }
    }

    plan = provider.plan(_manifest())

    assert not plan_has_mutations(plan)
    assert all(change.kind is ChangeKind.NOOP for change in plan.changes)


def test_siem_provider_apply_dry_run_skips_put() -> None:
    calls: list[tuple[str, dict[str, Any]]] = []
    provider = SiemProvider(endpoint_base="/siem/configuration")

    def fake_rest(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append((endpoint, payload))
        if payload["method"] == "GET":
            return {"configuration": {"sinks": [], "routes": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())

    provider.apply_siem_plan(plan, dry_run=True)

    assert not any(payload.get("method") == "PUT" for _, payload in calls)


def test_siem_provider_plan_create_when_live_empty() -> None:
    provider = SiemProvider(endpoint_base="/siem/configuration")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"sinks": [], "routes": []}
    }

    plan = provider.plan(_manifest())

    assert any(change.kind is ChangeKind.CREATE for change in plan.changes)


def test_siem_provider_apply_raises_capability_error_without_endpoint() -> None:
    provider_with_endpoint = SiemProvider(endpoint_base="/siem/configuration")
    provider_with_endpoint._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"sinks": [], "routes": []}
    }
    plan = provider_with_endpoint.plan(_manifest())

    bare = SiemProvider()
    with pytest.raises(CapabilityError):
        bare.apply_siem_plan(plan)
