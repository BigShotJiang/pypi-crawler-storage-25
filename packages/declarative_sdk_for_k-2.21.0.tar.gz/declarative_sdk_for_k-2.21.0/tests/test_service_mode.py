from __future__ import annotations

import json
import subprocess
from typing import Any

import pytest

from dsk.core.errors import CapabilityError
from dsk.providers.commander_cli import CommanderCliProvider


class FakeServiceClient:
    def __init__(
        self,
        *,
        health: list[dict[str, Any] | BaseException] | None = None,
        statuses: list[dict[str, Any]] | None = None,
        results: list[dict[str, Any]] | None = None,
    ) -> None:
        self.health = health or [{"status": "ok"}]
        self.statuses = statuses or [{"status": "completed"}]
        self.results = results or [{"status": "success"}]
        self.submits: list[tuple[str, dict[str, Any] | None]] = []

    def _request_json(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        assert method == "GET"
        assert path == "/health"
        assert body is None
        item = self.health.pop(0) if self.health else {"status": "ok"}
        if isinstance(item, BaseException):
            raise item
        return item

    def _post_async(self, command: str, filedata: dict[str, Any] | None = None) -> str:
        self.submits.append((command, filedata))
        return f"req-{len(self.submits)}"

    def _poll_status(self, request_id: str, timeout: int | None = None) -> dict[str, Any]:
        assert request_id.startswith("req-")
        assert timeout == 300
        return self.statuses.pop(0)

    def _get_result(self, request_id: str) -> dict[str, Any]:
        assert request_id.startswith("req-")
        return self.results.pop(0)


def _clear_service_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in (
        "KEEPER_SERVICE_MODE",
        "KEEPER_SERVICE_URL",
        "KEEPER_SERVICE_API_KEY",
        "KEEPER_SERVICE_AUTOSTART",
        "KEEPER_SERVICE_START_TIMEOUT",
    ):
        monkeypatch.delenv(name, raising=False)


def test_service_mode_reuses_running_service_without_keeper_binary(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _clear_service_env(monkeypatch)
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: None)
    client = FakeServiceClient(results=[{"status": "success", "data": [{"uid": "UID1"}]}])

    provider = CommanderCliProvider(
        folder_uid="folder-uid",
        service_mode=True,
        service_api_key="token",
        service_client=client,
    )

    assert json.loads(provider._run_cmd(["ls", "folder-uid", "--format", "json"])) == [
        {"uid": "UID1"}
    ]
    assert client.submits == [("ls folder-uid --format json", None)]


def test_service_mode_pam_project_import_uses_filedata(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    _clear_service_env(monkeypatch)
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: None)
    payload_path = tmp_path / "pam_import.json"
    payload = {"project": "acme", "pam_data": {"resources": []}}
    payload_path.write_text(json.dumps(payload), encoding="utf-8")
    client = FakeServiceClient(results=[{"status": "success", "data": {}}])
    provider = CommanderCliProvider(
        folder_uid="folder-uid",
        service_mode=True,
        service_api_key="token",
        service_client=client,
    )

    provider._run_cmd(["pam", "project", "import", "--file", str(payload_path), "--name", "acme"])

    assert client.submits == [("pam project import --filename=FILEDATA --name acme", payload)]


def test_service_mode_requires_api_key_before_start(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _clear_service_env(monkeypatch)
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: None)
    provider = CommanderCliProvider(folder_uid="folder-uid", service_mode=True)

    with pytest.raises(CapabilityError, match="API key is required"):
        provider._run_cmd(["ls", "folder-uid", "--format", "json"])


def test_service_mode_starts_configured_service_when_health_fails(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _clear_service_env(monkeypatch)
    monkeypatch.setattr(
        "dsk.providers.commander_cli.shutil.which",
        lambda _bin: "/usr/bin/keeper",
    )
    client = FakeServiceClient(
        health=[
            CapabilityError(reason="down", next_action="start service"),
            {"status": "ok"},
        ],
        results=[{"status": "success", "data": "ok"}],
    )
    calls: list[list[str]] = []

    def fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[str]:
        calls.append(cmd)
        return subprocess.CompletedProcess(cmd, 0, stdout="started", stderr="")

    monkeypatch.setattr("dsk.providers.commander_cli.subprocess.run", fake_run)
    provider = CommanderCliProvider(
        folder_uid="folder-uid",
        service_mode=True,
        service_api_key="token",
        service_client=client,
    )

    assert provider._run_cmd(["whoami"]) == "ok"
    assert calls == [["/usr/bin/keeper", "--batch-mode", "service-start"]]
    assert client.submits == [("whoami", None)]


def test_service_mode_command_failure_raises_capability(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _clear_service_env(monkeypatch)
    monkeypatch.setattr("dsk.providers.commander_cli.shutil.which", lambda _bin: None)
    client = FakeServiceClient(statuses=[{"status": "failed", "message": "denied"}])
    provider = CommanderCliProvider(
        folder_uid="folder-uid",
        service_mode=True,
        service_api_key="token",
        service_client=client,
    )

    with pytest.raises(CapabilityError, match="denied"):
        provider._run_cmd(["rm", "--force", "UID1"])
