"""Test JSON manifest loading and round-trip parity with YAML."""

from __future__ import annotations

import json

import pytest

from dsk.core.errors import ManifestError, SchemaError
from dsk.core.manifest import (
    load_declarative_manifest_string,
    load_manifest_string,
    read_manifest_document_string,
    validate_manifest,
)

# ── JSON loading (pam-environment.v1) ────────────────────────────────────────


def test_json_manifest_loads() -> None:
    manifest = json.dumps(
        {
            "schema": "pam-environment.v1",
            "version": "1",
            "name": "test-json",
            "resources": [],
        }
    )
    result = load_manifest_string(manifest, suffix=".json")
    assert result is not None
    assert result.name == "test-json"


def test_json_manifest_name_round_trips() -> None:
    doc = {"schema": "pam-environment.v1", "version": "1", "name": "round-trip", "resources": []}
    raw = json.dumps(doc)
    result = load_manifest_string(raw, suffix=".json")
    assert result.name == "round-trip"


def test_yaml_and_json_pam_manifest_load_same_name() -> None:
    name = "parity-test"
    yaml_raw = f"schema: pam-environment.v1\nversion: '1'\nname: {name}\nresources: []\n"
    json_raw = json.dumps(
        {"schema": "pam-environment.v1", "version": "1", "name": name, "resources": []}
    )
    yaml_result = load_manifest_string(yaml_raw, suffix=".yaml")
    json_result = load_manifest_string(json_raw, suffix=".json")
    assert yaml_result.name == json_result.name == name


def test_load_manifest_string_rejects_non_pam_family() -> None:
    """load_manifest_string only handles pam-environment.v1; others raise ManifestError."""
    raw = json.dumps({"schema": "keeper-vault.v1", "records": []})
    with pytest.raises(ManifestError) as excinfo:
        load_manifest_string(raw, suffix=".json")
    assert "keeper-vault.v1" in str(excinfo.value)


# ── read_manifest_document_string ────────────────────────────────────────────


def test_read_manifest_document_string_returns_dict() -> None:
    raw = json.dumps(
        {"schema": "pam-environment.v1", "version": "1", "name": "doc-only", "resources": []}
    )
    doc = read_manifest_document_string(raw, suffix=".json")
    assert isinstance(doc, dict)
    assert doc["name"] == "doc-only"


def test_read_manifest_document_string_yaml() -> None:
    raw = "schema: pam-environment.v1\nversion: '1'\nname: yaml-doc\nresources: []\n"
    doc = read_manifest_document_string(raw, suffix=".yaml")
    assert doc["name"] == "yaml-doc"


# ── validate_manifest ─────────────────────────────────────────────────────────


def test_validate_manifest_returns_family_string() -> None:
    doc = {"schema": "pam-environment.v1", "version": "1", "name": "x", "resources": []}
    family = validate_manifest(doc)
    assert family == "pam-environment.v1"


def test_validate_manifest_rejects_unknown_family() -> None:
    doc = {"schema": "totally-unknown-family.v99", "name": "x"}
    with pytest.raises(SchemaError):
        validate_manifest(doc)


# ── load_declarative_manifest_string (multi-family) ──────────────────────────


def test_declarative_manifest_string_loads_keeper_vault() -> None:
    raw = "schema: keeper-vault.v1\nrecords: []\n"
    manifest = load_declarative_manifest_string(raw)
    # VaultManifestV1 uses vault_schema field aliased to 'schema'
    assert manifest.model_dump(by_alias=True).get("schema") == "keeper-vault.v1"


def test_declarative_manifest_string_loads_nhi_agent() -> None:
    raw = (
        "schema: nhi-agent.v1\n"
        "resources:\n"
        "  - uid_ref: nhi.svc.test\n"
        "    name: test-bot\n"
        "    type: service_account\n"
        "    purpose: testing\n"
    )
    from dsk.core.models_nhi import NhiAgentManifest

    manifest = load_declarative_manifest_string(raw)
    assert isinstance(manifest, NhiAgentManifest)
    assert len(manifest.resources) == 1
