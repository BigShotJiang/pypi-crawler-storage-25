"""REST provider tests for ``keeper-integrations-events.v1``."""

from __future__ import annotations

from typing import Any

import pytest

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_integrations_events import EVENTS_FAMILY, EventsManifestV1
from dsk.providers.integrations_events_provider import IntegrationsEventsProvider


def _manifest() -> EventsManifestV1:
    return EventsManifestV1.model_validate(
        {
            "schema": EVENTS_FAMILY,
            "name": "acme-events",
            "audit_alerts": [
                {
                    "uid_ref": "alert.critical",
                    "name": "Critical alerts",
                    "event_types": ["login_failure"],
                    "severity": "critical",
                    "notify_emails": ["secops@example.com"],
                }
            ],
        }
    )


def test_events_provider_plan_returns_diff() -> None:
    provider = IntegrationsEventsProvider(endpoint_base="/events/routing")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {
            "audit_alerts": [
                {
                    "uid_ref": "alert.critical",
                    "name": "Critical alerts",
                    "event_types": ["login_failure"],
                    "severity": "medium",
                    "notify_emails": ["secops@example.com"],
                }
            ]
        }
    }

    plan = provider.plan(_manifest())

    assert plan.changes[0].kind is ChangeKind.UPDATE
    assert plan.changes[0].after == {"severity": "critical"}


def test_events_provider_apply_calls_configured_endpoint() -> None:
    calls: list[tuple[str, dict[str, Any]]] = []
    provider = IntegrationsEventsProvider(endpoint_base="/events/routing")

    def fake_rest(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append((endpoint, payload))
        if payload["method"] == "GET":
            return {"configuration": {"audit_alerts": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())

    outcomes = provider.apply_events_plan(plan)

    assert outcomes[0].action == "create"
    assert calls[-1][0] == "events/routing"
    assert calls[-1][1]["method"] == "PUT"
    assert calls[-1][1]["configuration"]["audit_alerts"][0]["uid_ref"] == "alert.critical"


def test_events_provider_plan_noop_when_live_matches() -> None:
    provider = IntegrationsEventsProvider(endpoint_base="/events/routing")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {
            "audit_alerts": [
                {
                    "uid_ref": "alert.critical",
                    "name": "Critical alerts",
                    "event_types": ["login_failure"],
                    "severity": "critical",
                    "notify_emails": ["secops@example.com"],
                }
            ]
        }
    }

    plan = provider.plan(_manifest())

    assert not plan.creates
    assert not plan.updates


def test_events_provider_apply_dry_run_skips_put() -> None:
    calls: list[tuple[str, dict[str, Any]]] = []
    provider = IntegrationsEventsProvider(endpoint_base="/events/routing")

    def fake_rest(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        calls.append((endpoint, payload))
        if payload["method"] == "GET":
            return {"configuration": {"audit_alerts": []}}
        return {"ok": True}

    provider._rest_post = fake_rest  # type: ignore[method-assign]
    plan = provider.plan(_manifest())

    provider.apply_events_plan(plan, dry_run=True)

    assert not any(payload.get("method") == "PUT" for _, payload in calls)


def test_events_provider_plan_create_when_live_empty() -> None:
    provider = IntegrationsEventsProvider(endpoint_base="/events/routing")
    provider._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"audit_alerts": []}
    }

    plan = provider.plan(_manifest())

    assert any(change.kind is ChangeKind.CREATE for change in plan.changes)


def test_events_provider_apply_raises_capability_error_without_endpoint() -> None:
    provider_with_endpoint = IntegrationsEventsProvider(endpoint_base="/events/routing")
    provider_with_endpoint._rest_post = lambda _endpoint, _payload: {  # type: ignore[method-assign]
        "configuration": {"audit_alerts": []}
    }
    plan = provider_with_endpoint.plan(_manifest())

    bare = IntegrationsEventsProvider()
    with pytest.raises(CapabilityError):
        bare.apply_events_plan(plan)
