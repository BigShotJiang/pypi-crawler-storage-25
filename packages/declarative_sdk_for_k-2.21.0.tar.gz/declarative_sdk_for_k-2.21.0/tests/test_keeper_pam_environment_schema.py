"""pam-environment.v1 live-proof schema annotation tests."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_REPO = Path(__file__).resolve().parents[1]
_SCHEMA_PATH = _REPO / "dsk" / "core" / "schemas" / "pam-environment.v1.schema.json"
_MACHINE_EVIDENCE = "docs/live-proof/keeper-pam-environment.v1.89047920.machine.sanitized.json"
_RBI_EVIDENCE = "docs/live-proof/keeper-pam-environment.v1.89047920.rbi.sanitized.json"


def _schema() -> dict[str, Any]:
    return json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))


def test_pam_environment_live_proof_evidence_appends_machine_and_rbi_transcripts() -> None:
    proof = _schema()["x-keeper-live-proof"]

    assert proof["status"] == "supported"
    assert proof["evidence"] == [
        "scripts/smoke/scenarios.py",
        _MACHINE_EVIDENCE,
        _RBI_EVIDENCE,
    ]
    assert len(proof["evidence"]) == 3
    assert (_REPO / _MACHINE_EVIDENCE).is_file()
    assert (_REPO / _RBI_EVIDENCE).is_file()


def test_pam_environment_schema_has_required_version_and_name() -> None:
    schema = _schema()
    assert "version" in schema["required"]
    assert "name" in schema["required"]


def test_pam_environment_schema_title_is_set() -> None:
    schema = _schema()
    assert schema.get("title") is not None
    assert len(schema["title"]) > 0


def test_pam_environment_schema_has_expected_top_level_properties() -> None:
    schema = _schema()
    expected = {"version", "name", "gateways", "pam_configurations", "resources"}
    actual = set(schema.get("properties", {}).keys())
    assert expected.issubset(actual)


def test_pam_environment_schema_additional_properties_false() -> None:
    schema = _schema()
    assert schema.get("additionalProperties") is False
