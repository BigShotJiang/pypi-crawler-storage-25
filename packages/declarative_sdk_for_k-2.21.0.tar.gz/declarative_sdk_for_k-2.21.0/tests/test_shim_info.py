"""Tests for the DSK shim discovery descriptor."""

from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from dsk.cli.main import main
from dsk.shim import (
    OUTPUT_CONTRACT_VERSIONS_SUPPORTED,
    SIGNATURE_BACKENDS,
    SUPPORTED_VERBS,
    shim_info,
    shim_info_json,
)


def test_shim_info_top_level_contract_values() -> None:
    info = shim_info()

    assert info["shim_contract_version"] == "1.0"
    assert info["dsk_version"]
    assert info["supported_verbs"] == SUPPORTED_VERBS
    assert info["output_contract_versions_supported"] == OUTPUT_CONTRACT_VERSIONS_SUPPORTED
    assert info["signature_backends"] == SIGNATURE_BACKENDS


def test_shim_info_has_required_descriptor_for_each_verb() -> None:
    info = shim_info()
    required = {
        "name",
        "signature",
        "cli_signature",
        "library_signature",
        "contract_inputs",
        "contract_outputs",
        "click_params",
        "is_idempotent",
        "requires_keeper_session",
        "absorption_subset",
        "standalone_only",
    }

    for verb in SUPPORTED_VERBS:
        assert verb in info["verbs"]
        assert required <= set(info["verbs"][verb])


def test_shim_info_json_matches_dict_descriptor() -> None:
    assert json.loads(shim_info_json()) == shim_info()


def test_shim_info_negotiates_old_contract_version() -> None:
    info = shim_info("1.0")

    assert info["negotiated_output_contract_version"] == "1.0"


def test_shim_info_rejects_unsupported_contract_version() -> None:
    with pytest.raises(ValueError, match="unsupported output contract version"):
        shim_info("0.9")


def test_cli_shim_info_outputs_valid_json() -> None:
    result = CliRunner().invoke(main, ["shim-info"], catch_exceptions=False)

    assert result.exit_code == 0
    info = json.loads(result.output)
    assert info["shim_contract_version"] == "1.0"
    assert info["verbs"]["adopt"]["cli_signature"].startswith("dsk import-from-keepercmd")
    assert info["verbs"]["verify"]["absorption_subset"] is False
    assert info["verbs"]["verify"]["standalone_only"] is True


def test_cli_shim_info_negotiates_requested_version() -> None:
    result = CliRunner().invoke(
        main,
        ["shim-info", "--output-contract-version", "1.0"],
        catch_exceptions=False,
    )

    assert result.exit_code == 0
    assert json.loads(result.output)["negotiated_output_contract_version"] == "1.0"


def test_cli_shim_info_rejects_unknown_version() -> None:
    result = CliRunner().invoke(main, ["shim-info", "--output-contract-version", "0.9"])

    assert result.exit_code == 2
    assert "unsupported output contract version" in result.output
