"""Tests for DB access policy manifest models."""

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError


def test_db_access_defaults():
    from dsk.core.models_db_access import DbAccessPolicyManifestV1

    m = DbAccessPolicyManifestV1(**{"schema": "db-access-policy.v1", "name": "test"})
    assert m.schema_ == "db-access-policy.v1"
    assert m.rules == []
    assert m.default_audit.record_queries is True
    assert m.default_audit.retain_days == 365


def test_db_access_round_trip():
    from dsk.core.models_db_access import (
        DbAccessPolicyManifestV1,
        DbAccountMode,
        DbEngine,
        SqlAssistMode,
    )

    example = Path(__file__).parent.parent / "examples/db_access/acme-db-access-policy.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = DbAccessPolicyManifestV1(**data)
    assert manifest.schema_ == "db-access-policy.v1"
    assert len(manifest.rules) == 3
    prod = manifest.rules[0]
    assert prod.db_engine == DbEngine.mysql
    assert prod.account_mode == DbAccountMode.jit_ephemeral
    assert prod.jit_ttl_minutes == 60
    assert prod.sql_assist == SqlAssistMode.read_only_assist
    assert prod.max_concurrent_sessions == 3
    assert prod.db_proxy_enabled is True
    assert prod.db_proxy_local_port == 3307
    assert prod.idle_timeout_minutes == 30
    assert prod.max_session_duration_minutes == 120
    legacy = manifest.rules[2]
    assert legacy.account_mode == DbAccountMode.standing
    assert legacy.sql_assist == SqlAssistMode.disabled


def test_db_audit_defaults():
    from dsk.core.models_db_access import DbSessionAudit

    a = DbSessionAudit()
    assert a.record_queries is True
    assert a.alert_on_ddl is True
    assert a.alert_on_bulk_export is True


def test_db_proxy_enabled_validates():
    from dsk.core.models_db_access import DbAccessRule, DbEngine

    rule = DbAccessRule(
        uid_ref="res.db-test",
        db_engine=DbEngine.postgresql,
        db_proxy_enabled=True,
    )
    assert rule.db_proxy_enabled is True


def test_db_proxy_local_port_range_ok():
    from dsk.core.models_db_access import DbAccessRule, DbEngine

    rule = DbAccessRule(
        uid_ref="res.db-test",
        db_engine=DbEngine.mysql,
        db_proxy_local_port=3307,
    )
    assert rule.db_proxy_local_port == 3307


def test_db_proxy_local_port_out_of_range_rejected():
    from dsk.core.models_db_access import DbAccessRule, DbEngine

    with pytest.raises(ValidationError):
        DbAccessRule(
            uid_ref="res.db-test",
            db_engine=DbEngine.mysql,
            db_proxy_local_port=80,
        )


def test_db_access_schema_alias():
    from dsk.core.models_db_access import DbAccessPolicyManifestV1

    m = DbAccessPolicyManifestV1(**{"schema": "db-access-policy.v1", "name": "t"})
    assert m.schema_ == "db-access-policy.v1"
