"""Tests for dsk discover command (offline)."""

from unittest.mock import patch

import yaml
from click.testing import CliRunner


def test_discover_no_commander(tmp_path):
    """Without Commander, _run_pam_list returns empty — no unmanaged found."""
    from dsk.cli.cmd_discover import cmd_discover

    runner = CliRunner()
    with patch("dsk.cli.cmd_discover._run_pam_list", return_value=[]):
        result = runner.invoke(cmd_discover, [])
    assert result.exit_code == 0
    assert "Unmanaged: 0" in result.output


def test_discover_finds_unmanaged(tmp_path):
    """Unmanaged resource → exit 2 + stub in output."""
    from dsk.cli.cmd_discover import cmd_discover

    runner = CliRunner()
    fake_records = [{"uid": "ABC123DEF456", "title": "prod-mysql"}]

    def fake_list(rtype: str):
        return fake_records if rtype == "machine" else []

    with patch("dsk.cli.cmd_discover._run_pam_list", side_effect=fake_list):
        result = runner.invoke(cmd_discover, [])
    assert result.exit_code == 2
    assert "Unmanaged: 1" in result.output
    assert "prod-mysql" in result.output


def test_discover_managed_uid_excluded(tmp_path):
    """Resource already in manifest → not counted as unmanaged."""
    from dsk.cli.cmd_discover import cmd_discover

    manifest = tmp_path / "env.yaml"
    manifest.write_text(
        yaml.dump(
            {
                "schema": "pam-environment.v1",
                "name": "test",
                "version": "1",
                "resources": [{"uid_ref": "res.db", "title": "DB", "keeper_uid": "ABC123DEF456"}],
            }
        )
    )
    runner = CliRunner()
    fake_records = [{"uid": "ABC123DEF456", "title": "prod-mysql"}]

    def fake_list(rtype: str):
        return fake_records if rtype == "machine" else []

    with patch("dsk.cli.cmd_discover._run_pam_list", side_effect=fake_list):
        result = runner.invoke(cmd_discover, [str(manifest)])
    assert result.exit_code == 0
    assert "Unmanaged: 0" in result.output


def test_discover_output_file(tmp_path):
    """--output writes YAML file."""
    from dsk.cli.cmd_discover import cmd_discover

    out = tmp_path / "discovered.yaml"
    runner = CliRunner()
    fake_records = [{"uid": "XYZ789ABCDEF", "title": "legacy-server"}]

    def fake_list(rtype: str):
        return fake_records if rtype == "machine" else []

    with patch("dsk.cli.cmd_discover._run_pam_list", side_effect=fake_list):
        result = runner.invoke(cmd_discover, ["-o", str(out)])
    assert result.exit_code == 2
    assert out.exists()
    data = yaml.safe_load(out.read_text())
    assert data["schema"] == "pam-environment.v1"
    assert data["resources"][0]["# next_action"].startswith("review")


def test_discover_emit_json_to_stdout():
    """--json emits JSON manifest text instead of YAML."""
    from dsk.cli.cmd_discover import cmd_discover

    runner = CliRunner()
    fake_records = [{"uid": "UIDJSON01", "title": "json-host"}]

    def fake_list(rtype: str):
        return fake_records if rtype == "machine" else []

    with patch("dsk.cli.cmd_discover._run_pam_list", side_effect=fake_list):
        result = runner.invoke(cmd_discover, ["--resource-types", "machine", "--json"])
    assert result.exit_code == 2
    assert '"schema": "pam-environment.v1"' in result.output


def test_discover_multiple_resource_types_merges_unmanaged():
    """Scanning machine and database counts both when unmanaged."""
    from dsk.cli.cmd_discover import cmd_discover

    runner = CliRunner()

    def fake_list(rtype: str):
        if rtype == "machine":
            return [{"uid": "M1", "title": "vm"}]
        if rtype == "database":
            return [{"uid": "D1", "title": "db"}]
        return []

    with patch("dsk.cli.cmd_discover._run_pam_list", side_effect=fake_list):
        result = runner.invoke(cmd_discover, ["--resource-types", "machine,database"])
    assert result.exit_code == 2
    assert "Unmanaged: 2" in result.output


def test_discover_missing_manifest_file_treats_as_zero_managed():
    """Nonexistent manifest path yields zero managed UIDs (no crash)."""
    from dsk.cli.cmd_discover import cmd_discover

    runner = CliRunner()
    fake_records = [{"uid": "ABC123DEF456", "title": "orphan"}]

    def fake_list(rtype: str):
        return fake_records if rtype == "machine" else []

    missing = "/no/such/dsk-manifest.yaml"
    with patch("dsk.cli.cmd_discover._run_pam_list", side_effect=fake_list):
        result = runner.invoke(cmd_discover, ["--resource-types", "machine", missing])
    assert result.exit_code == 2
    assert "Unmanaged: 1" in result.output


def test_extract_resources_and_users_flat_doc() -> None:
    """_extract_resources_and_users handles docs with direct top-level resources/users."""
    from dsk.cli.discover import build_discovered_manifest_dict

    doc = {
        "resources": [{"uid_ref": "r1", "type": "pamMachine"}],
        "users": [],
        "pam_configurations": [],
    }
    manifest_dict, rows = build_discovered_manifest_dict(doc, manifest_name="test")
    assert isinstance(manifest_dict, dict)


def test_extract_resources_and_users_nested_pam_data() -> None:
    """_extract_resources_and_users handles pam_data nested structure."""
    from dsk.cli.discover import build_discovered_manifest_dict

    doc = {
        "pam_data": {
            "resources": [{"uid_ref": "r2", "type": "pamDatabase"}],
            "users": [],
        }
    }
    manifest_dict, rows = build_discovered_manifest_dict(doc, manifest_name="pam-data-test")
    assert isinstance(manifest_dict, dict)


# ── Sprint BG: discover.py additional coverage ────────────────────────────


def test_build_discovered_manifest_includes_single_pc_auto_ref() -> None:
    """build_discovered_manifest_dict auto-assigns single pam_configuration_uid_ref."""
    from dsk.cli.discover import build_discovered_manifest_dict

    doc = {
        "pam_configurations": [{"uid_ref": "cfg.single"}],
        "resources": [{"uid_ref": "res.one", "type": "pamMachine"}],
        "users": [],
    }
    manifest_dict, _rows = build_discovered_manifest_dict(doc, manifest_name="auto-pc")
    resources = manifest_dict.get("resources", [])
    if resources:
        assert resources[0].get("pam_configuration_uid_ref") == "cfg.single"


def test_build_discovered_manifest_multiple_pcs_no_auto_ref() -> None:
    """build_discovered_manifest_dict does not auto-assign when there are multiple pam_configs."""
    from dsk.cli.discover import build_discovered_manifest_dict

    doc = {
        "pam_configurations": [{"uid_ref": "cfg.a"}, {"uid_ref": "cfg.b"}],
        "resources": [{"uid_ref": "res.one", "type": "pamMachine"}],
        "users": [],
    }
    manifest_dict, _rows = build_discovered_manifest_dict(doc, manifest_name="multi-pc")
    resources = manifest_dict.get("resources", [])
    if resources:
        # Should not have been auto-assigned since there are 2 PCs
        assert resources[0].get("pam_configuration_uid_ref") is None
