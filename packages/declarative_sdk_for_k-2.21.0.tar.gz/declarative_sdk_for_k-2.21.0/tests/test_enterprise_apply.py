"""keeper-enterprise.v1 plan/apply wiring tests (mock + Commander stub)."""

from __future__ import annotations

import pytest

from dsk.core import build_plan
from dsk.core.diff import ChangeKind
from dsk.core.enterprise_diff import compute_enterprise_diff
from dsk.core.enterprise_graph import build_enterprise_graph, enterprise_apply_order
from dsk.core.models_enterprise import EnterpriseManifestV1
from dsk.providers import commander_cli
from dsk.providers.commander_cli import CommanderCliProvider
from dsk.providers.mock import MockProvider


def _manifest() -> EnterpriseManifestV1:
    raw = {
        "schema": "keeper-enterprise.v1",
        "nodes": [{"uid_ref": "n-root", "name": "Root"}],
        "teams": [
            {
                "uid_ref": "t1",
                "name": "Alpha",
                "node_uid_ref": "keeper-enterprise:nodes:n-root",
            },
        ],
    }
    m = EnterpriseManifestV1.model_validate(raw)
    build_enterprise_graph(m)
    return m


def test_enterprise_mock_plan_has_create_rows() -> None:
    manifest = _manifest()
    changes = compute_enterprise_diff(manifest, None, manifest_name="lab")
    creates = [c for c in changes if c.kind is ChangeKind.CREATE]
    assert len(creates) >= 2
    assert any(c.resource_type == "enterprise_team" for c in creates)


def test_enterprise_mock_apply_succeeds() -> None:
    manifest = _manifest()
    changes = compute_enterprise_diff(manifest, None, manifest_name="lab")
    order = enterprise_apply_order(manifest)
    plan = build_plan("lab", changes, order)
    prov = MockProvider("lab")
    out = prov.apply_enterprise_plan(plan, manifest, dry_run=False)
    assert any(o.action == "create" for o in out)
    assert all(o.action != "conflict" for o in out)


def test_enterprise_commander_apply_team_create_wired(monkeypatch: pytest.MonkeyPatch) -> None:
    manifest = _manifest()
    changes = compute_enterprise_diff(manifest, None, manifest_name="lab")
    team_change = next(c for c in changes if c.resource_type == "enterprise_team")
    order = enterprise_apply_order(manifest)
    plan = build_plan("lab", [team_change], order)
    src = manifest.model_dump(mode="python", exclude_none=True, by_alias=True)
    prov = CommanderCliProvider(folder_uid=None, manifest_source=src)
    refresh_calls: list[object] = []

    def fake_refresh(self: CommanderCliProvider, operation: object) -> None:
        refresh_calls.append(operation)

    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(CommanderCliProvider, "_with_keeper_session_refresh", fake_refresh)

    outcomes = prov.apply_enterprise_plan(plan, manifest, dry_run=False)

    assert refresh_calls
    assert [out.action for out in outcomes] == ["create"]
    assert outcomes[0].details == {"team_name": "Alpha"}


def _update_change(resource_type: str, before: dict, after: dict) -> object:
    """Build a minimal ChangeKind.UPDATE Change object for testing."""
    from dsk.core.diff import Change, ChangeKind

    return Change(
        kind=ChangeKind.UPDATE,
        uid_ref=before.get("uid_ref") or after.get("uid_ref") or "",
        resource_type=resource_type,
        title=after.get("name") or "",
        keeper_uid=before.get("uid_ref") or "",
        before=before,
        after=after,
    )


def test_enterprise_commander_apply_team_update_wired(monkeypatch: pytest.MonkeyPatch) -> None:
    """Team UPDATE should reach EnterpriseTeamCommand (no CapabilityError)."""

    change = _update_change(
        "enterprise_team",
        before={"name": "Alpha", "uid_ref": "t1"},
        after={"name": "AlphaRenamed", "uid_ref": "t1", "restrict_edit": True},
    )
    manifest = _manifest()
    from dsk.core import build_plan
    from dsk.core.enterprise_graph import enterprise_apply_order

    order = enterprise_apply_order(manifest)
    plan = build_plan("lab", [change], order)
    src = manifest.model_dump(mode="python", exclude_none=True, by_alias=True)
    prov = CommanderCliProvider(folder_uid=None, manifest_source=src)
    refresh_calls: list[object] = []

    def fake_refresh(self: CommanderCliProvider, operation: object) -> None:
        refresh_calls.append(operation)

    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(CommanderCliProvider, "_with_keeper_session_refresh", fake_refresh)

    outcomes = prov.apply_enterprise_plan(plan, manifest, dry_run=False)

    assert refresh_calls
    assert [out.action for out in outcomes] == ["update"]
    assert outcomes[0].details["team_name"] == "AlphaRenamed"


def test_enterprise_commander_apply_role_create_wired(monkeypatch: pytest.MonkeyPatch) -> None:
    """Role CREATE should reach EnterpriseRoleCommand (no CapabilityError)."""
    from dsk.core.diff import Change, ChangeKind

    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="r1",
        resource_type="enterprise_role",
        title="Admins",
        keeper_uid="",
        before=None,
        after={"name": "Admins", "uid_ref": "r1", "node_uid_ref": "n-root"},
    )
    manifest = _manifest()
    from dsk.core import build_plan
    from dsk.core.enterprise_graph import enterprise_apply_order

    order = enterprise_apply_order(manifest)
    plan = build_plan("lab", [change], order)
    src = manifest.model_dump(mode="python", exclude_none=True, by_alias=True)
    prov = CommanderCliProvider(folder_uid=None, manifest_source=src)
    refresh_calls: list[object] = []

    def fake_refresh(self: CommanderCliProvider, operation: object) -> None:
        refresh_calls.append(operation)

    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(CommanderCliProvider, "_with_keeper_session_refresh", fake_refresh)

    outcomes = prov.apply_enterprise_plan(plan, manifest, dry_run=False)

    assert refresh_calls
    assert [out.action for out in outcomes] == ["create"]
    assert outcomes[0].details["role_name"] == "Admins"


def test_enterprise_commander_apply_node_create_wired(monkeypatch: pytest.MonkeyPatch) -> None:
    """Node CREATE should reach EnterpriseNodeCommand (no CapabilityError)."""
    from dsk.core.diff import Change, ChangeKind

    change = Change(
        kind=ChangeKind.CREATE,
        uid_ref="n-engineering",
        resource_type="enterprise_node",
        title="Engineering",
        keeper_uid="",
        before=None,
        after={"name": "Engineering", "uid_ref": "n-engineering", "parent_uid_ref": "n-root"},
    )
    manifest = _manifest()
    from dsk.core import build_plan
    from dsk.core.enterprise_graph import enterprise_apply_order

    order = enterprise_apply_order(manifest)
    plan = build_plan("lab", [change], order)
    src = manifest.model_dump(mode="python", exclude_none=True, by_alias=True)
    prov = CommanderCliProvider(folder_uid=None, manifest_source=src)
    refresh_calls: list[object] = []

    def fake_refresh(self: CommanderCliProvider, operation: object) -> None:
        refresh_calls.append(operation)

    monkeypatch.setattr(commander_cli, "_ensure_keepercommander_version_for_apply", lambda: None)
    monkeypatch.setattr(CommanderCliProvider, "_with_keeper_session_refresh", fake_refresh)

    outcomes = prov.apply_enterprise_plan(plan, manifest, dry_run=False)

    assert refresh_calls
    assert [out.action for out in outcomes] == ["create"]
    assert outcomes[0].details["node_name"] == "Engineering"


def test_enterprise_commander_apply_team_update_dry_run() -> None:
    """Team UPDATE dry_run should succeed without calling Commander."""
    change = _update_change(
        "enterprise_team",
        before={"name": "Alpha", "uid_ref": "t1"},
        after={"name": "AlphaRenamed", "uid_ref": "t1"},
    )
    manifest = _manifest()
    from dsk.core import build_plan
    from dsk.core.enterprise_graph import enterprise_apply_order

    order = enterprise_apply_order(manifest)
    plan = build_plan("lab", [change], order)
    src = manifest.model_dump(mode="python", exclude_none=True, by_alias=True)
    prov = CommanderCliProvider(folder_uid=None, manifest_source=src)

    outcomes = prov.apply_enterprise_plan(plan, manifest, dry_run=True)
    assert [out.action for out in outcomes] == ["update"]
    assert outcomes[0].details == {"dry_run": True, "team_name": "AlphaRenamed"}
