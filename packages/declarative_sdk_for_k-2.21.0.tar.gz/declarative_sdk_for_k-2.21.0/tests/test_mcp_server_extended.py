"""Extended unit tests for dsk.mcp.server (stdio, stubs, tooling paths).

Targets previously uncovered branches in server.py via mocks/subprocess helpers.
Production modules are not edited.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import textwrap
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from dsk.core.resource_limits import ResourceLimitError

REPO_ROOT = Path(__file__).resolve().parents[1]

_PAM_MIN = textwrap.dedent("""\
    version: "1"
    name: test-pam
    schema: pam-environment.v1
""")

_MSP_FIXTURE = REPO_ROOT / "tests" / "fixtures" / "examples" / "msp" / "01-minimal-msp.yaml"

_MSP_DIFF_YAML = textwrap.dedent("""\
    schema: msp-environment.v1
    name: mcp-msp-cover
    manager: keeper-msp-declarative
    managed_companies:
      - name: AcmeMcpCover
        plan: business
        seats: 3
""")


def test_tool_decorator_registers_handler() -> None:
    """JsonRpcMcpServer.tool() binds a callable into list_tools."""

    from dsk.mcp.server import JsonRpcMcpServer

    srv = JsonRpcMcpServer("custom")

    @srv.tool("echo_test")
    async def echo_tool(msg: str) -> str:
        """Echo fixture."""
        return msg

    names = sorted(t["name"] for t in srv.list_tools())
    assert "echo_test" in names
    resp = asyncio.run(
        srv.handle(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {"name": "echo_test", "arguments": {"msg": "hi"}},
            }
        )
    )
    assert resp is not None
    text = resp["result"]["content"][0]["text"]
    assert text == "hi"


def test_optional_compute_pam_extended_diff_import_removed_assigns_none() -> None:
    """ImportError loading pam_extended_diff sets compute_pam_extended_diff=None."""

    script = textwrap.dedent(
        """\
        import builtins, sys

        TARGET = "dsk.core.pam_extended_diff"
        for key in list(sys.modules):
            if key == "keeper_sdk" or key.startswith("dsk."):
                del sys.modules[key]
        _real_import = builtins.__import__

        def _guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
            if name == TARGET:
                raise ImportError("blocked for test")
            return _real_import(name, globals, locals, fromlist, level)

        builtins.__import__ = _guarded_import
        import dsk.mcp.server as s
        assert s.compute_pam_extended_diff is None
        """
    )

    subprocess.check_call(
        [sys.executable, "-c", script],
        cwd=str(REPO_ROOT),
        env={**dict(os.environ), "PYTHONPATH": str(REPO_ROOT)},
    )


def test_run_stdio_processes_health_request_and_writes_json() -> None:
    """run_stdio parses one JSON-RPC line, responds, then exits on stdin EOF."""

    from dsk.mcp.server import JsonRpcMcpServer

    lines = iter(['{"jsonrpc":"2.0","id":7,"method":"health","params":{}}\n', ""])
    written: list[str] = []

    def fake_readline() -> str:
        try:
            return next(lines)
        except StopIteration:
            return ""

    srv = JsonRpcMcpServer("stdio-test")

    async def _runner() -> None:
        with (
            patch.object(sys.stdin, "readline", side_effect=fake_readline),
            patch.object(sys.stdout, "write", side_effect=written.append),
            patch.object(sys.stdout, "flush"),
        ):
            await srv.run_stdio()

    asyncio.run(_runner())
    payload = json.loads(written[-1])
    assert payload["jsonrpc"] == "2.0"
    assert payload["id"] == 7
    assert payload["result"] == {}


def test_run_stdio_blank_line_then_request() -> None:
    """Whitespace-only stdin lines are ignored before a valid request."""

    from dsk.mcp.server import JsonRpcMcpServer

    lines = iter(
        [
            "   \n",
            '{"jsonrpc":"2.0","id":9,"method":"ping","params":{}}\n',
            "",
        ]
    )
    written: list[str] = []

    def fake_readline() -> str:
        try:
            return next(lines)
        except StopIteration:
            return ""

    srv = JsonRpcMcpServer("stdio-test")

    async def _runner() -> None:
        with (
            patch.object(sys.stdin, "readline", side_effect=fake_readline),
            patch.object(sys.stdout, "write", side_effect=written.append),
            patch.object(sys.stdout, "flush"),
        ):
            await srv.run_stdio()

    asyncio.run(_runner())
    assert json.loads(written[-1])["result"] == {}


def test_run_stdio_bad_json_writes_parse_error() -> None:
    """Invalid JSON on stdin emits JSON-RPC parse error (-32700) with id null."""

    from dsk.mcp.server import JsonRpcMcpServer

    lines_iter = iter(["{{{not-json\n", ""])
    written: list[str] = []

    def fake_readline() -> str:
        try:
            return next(lines_iter)
        except StopIteration:
            return ""

    srv = JsonRpcMcpServer("stdio-test")

    async def _runner() -> None:
        with (
            patch.object(sys.stdin, "readline", side_effect=fake_readline),
            patch.object(sys.stdout, "write", side_effect=written.append),
            patch.object(sys.stdout, "flush"),
        ):
            await srv.run_stdio()

    asyncio.run(_runner())
    out = json.loads(written[-1])
    assert out["error"]["code"] == -32700


def test_handle_tools_call_missing_name_key_returns_rpc_error() -> None:
    """tools/call without params.name yields JSON-RPC Invalid Params (-32602)."""

    from dsk.mcp import server as mcp_srv

    req = {"jsonrpc": "2.0", "id": 100, "method": "tools/call", "params": {"arguments": {}}}
    resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    assert "error" in resp
    assert resp["error"]["code"] == -32602


def test_handle_tools_list_surfaces_exceptions_as_internal_error() -> None:
    """Unexpected errors in handlers map to JSON-RPC -32603."""

    from dsk.mcp import server as mcp_srv

    with patch.object(mcp_srv.server, "list_tools", side_effect=RuntimeError("boom")):
        req = {"jsonrpc": "2.0", "id": 200, "method": "tools/list", "params": {}}
        resp = asyncio.run(mcp_srv.server.handle(req))
    assert resp is not None
    assert resp["error"]["code"] == -32603


def test_plan_ksm_family_raises_via_call_tool(monkeypatch: pytest.MonkeyPatch) -> None:
    """KSM manifests cannot load for MCP planner — CapabilityError wraps isError."""

    from dsk.mcp import server as mcp_srv

    yaml_text = textwrap.dedent("""\
        schema: keeper-ksm.v1
        apps: []
    """)
    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)
    resp = asyncio.run(mcp_srv.server.call_tool("dsk_plan", {"manifest_yaml": yaml_text}))
    assert resp["isError"] is True


def test_apply_clean_plan_returns_empty_outcomes() -> None:
    """When plan.is_clean apply returns outcomes [] without invoking provider."""

    from dsk.core.planner import Plan
    from dsk.mcp import server as mcp_srv

    stub_bundle = MagicMock()
    stub_bundle.msp = None
    stub_bundle.provider = MagicMock()

    with patch.object(mcp_srv, "_build_mcp_plan", return_value=(Plan("x", [], []), stub_bundle)):
        out = asyncio.run(mcp_srv.apply(_PAM_MIN, auto_approve=True, dry_run=False))
    data = json.loads(out)
    assert data["outcomes"] == []
    stub_bundle.provider.apply_plan.assert_not_called()
    stub_bundle.provider.apply_msp_plan.assert_not_called()


def test_apply_conflicts_returns_error_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    """Plans with conflicting rows return JSON error with embedded plan."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.core.diff import Change, ChangeKind
    from dsk.core.planner import Plan
    from dsk.mcp import server as mcp_srv

    row = Change(
        kind=ChangeKind.CONFLICT,
        uid_ref="ref.bad",
        resource_type="pamMachine",
        title="overlap",
        reason="collision fixture",
    )
    plan_obj = Plan("pam", [row], ["ref.bad"])
    stub_bundle = MagicMock()
    stub_bundle.msp = None
    stub_bundle.provider = MagicMock()

    with patch.object(mcp_srv, "_build_mcp_plan", return_value=(plan_obj, stub_bundle)):
        payload = asyncio.run(mcp_srv.apply(_PAM_MIN, auto_approve=True))
    decoded = json.loads(payload)
    assert "error" in decoded
    assert decoded["error"] == "plan has conflicts"
    stub_bundle.provider.apply_plan.assert_not_called()


def test_apply_msp_manifest_uses_apply_msp_plan_with_dry_run(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """MSP bundle invokes apply_msp_plan on the resolved provider with dry_run flag."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.mcp import server as mcp_srv
    from dsk.providers import MockProvider as _RealMock

    captures: dict[str, Any] = {"dry_runs": []}

    class _TrackMspMock(_RealMock):
        """Records dry_run handed to MSP apply."""

        def apply_msp_plan(self, plan, *, dry_run: bool = False):  # type: ignore[override]
            captures["dry_runs"].append(dry_run)
            return []

    with patch.object(mcp_srv, "MockProvider", _TrackMspMock):
        out = asyncio.run(mcp_srv.apply(_MSP_DIFF_YAML, auto_approve=True, dry_run=True))
    decoded = json.loads(out)
    assert decoded.get("dry_run") is True
    assert decoded["summary"] is not None
    assert captures["dry_runs"] == [True]


def test_fixture_msp_minimal_fixture_exists() -> None:
    """Bundle fixture path used elsewhere must exist."""

    assert _MSP_FIXTURE.is_file(), f"missing MSP fixture at {_MSP_FIXTURE}"


def test_diff_tool_runs_renderer(monkeypatch: pytest.MonkeyPatch) -> None:
    """dsk_diff calls RichRenderer.render_diff(plan_obj)."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.mcp import server as mcp_srv

    with patch("dsk.mcp.server.RichRenderer") as rr:
        inst = rr.return_value
        inst.render_diff.return_value = "diff-output"
        out = asyncio.run(mcp_srv.diff(_PAM_MIN))
    assert out == "diff-output"


def test_export_tool_writes_yaml_from_json(monkeypatch: pytest.MonkeyPatch) -> None:
    """dsk_export round-trips import JSON via temp file helpers."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.mcp import server as mcp_srv

    project = json.dumps({"pam_configurations": [], "machines": [], "machine_users": []})
    monkeypatch.setenv("DSK_MCP_MAX_ARGUMENT_BYTES", str(len(project.encode("utf-8"))))
    yaml_out = asyncio.run(mcp_srv.export(project))
    assert "schema:" in yaml_out.lower() or "name:" in yaml_out.lower()


def test_export_tool_rejects_project_json_just_over_byte_cap(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.mcp import server as mcp_srv

    project = json.dumps({"pam_configurations": [], "machines": [], "machine_users": []})
    monkeypatch.setenv("DSK_MCP_MAX_ARGUMENT_BYTES", str(len(project.encode("utf-8")) - 1))

    with pytest.raises(ResourceLimitError, match="DSK_MCP_MAX_ARGUMENT_BYTES"):
        asyncio.run(mcp_srv.export(project))


def test_report_dispatches_three_cli_branches(monkeypatch: pytest.MonkeyPatch) -> None:
    """_invoke_report_cli routes password / compliance / security-audit payloads."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.mcp import server as mcp_srv

    def _stub_payload_runpw(**_kwargs):  # pragma: no cover - thin stub
        return {"kind": "password"}

    def _stub_payload_compliance(**_kwargs):
        return {"kind": "compliance"}

    def _stub_payload_security_audit(**_kwargs):
        return {"kind": "security"}

    payloads: list[Any] = []

    def capture(payload):
        payloads.append(payload)

    with (
        patch("dsk.cli._report.password.run_password_report", side_effect=_stub_payload_runpw),
        patch(
            "dsk.cli._report.compliance.run_compliance_report",
            side_effect=_stub_payload_compliance,
        ),
        patch(
            "dsk.cli._report.security_audit.run_security_audit_report",
            side_effect=_stub_payload_security_audit,
        ),
        patch.object(mcp_srv, "_emit_report_json", side_effect=capture),
    ):
        mcp_srv._invoke_report_cli(["password-report", "--quiet", "--sanitize-uids"])
        mcp_srv._invoke_report_cli(["compliance-report", "--quiet"])
        mcp_srv._invoke_report_cli(["security-audit-report", "--quiet"])

    assert [p.get("kind") for p in payloads] == ["password", "compliance", "security"]


def test_report_tool_passes_without_sanitize(monkeypatch: pytest.MonkeyPatch) -> None:
    """dsk_report with sanitize_uids=False does not inject --sanitize-uids flag."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.mcp import server as mcp_srv

    seen: dict[str, list[str]] = {"args": []}

    def cap(fn, args):
        seen["args"].extend(args)
        return '{"ok": true}'

    with patch.object(mcp_srv, "capture_dsk_output", side_effect=cap):
        asyncio.run(mcp_srv.report("password-report", sanitize_uids=False))
    assert "--sanitize-uids" not in seen["args"]


def test_bus_tools_publish_and_get(monkeypatch: pytest.MonkeyPatch) -> None:
    """dsk_bus_publish / dsk_bus_get integrate with KsmBus."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.mcp import server as mcp_srv

    envelope = MagicMock()
    envelope.value = {"payload": "x"}
    envelope.version = 4

    with patch.object(mcp_srv, "KsmSecretStore"), patch.object(mcp_srv, "KsmBus") as kb_cls:
        bus = kb_cls.return_value
        bus.publish.return_value = 5
        bus.get.return_value = None

        asyncio.run(mcp_srv.bus_publish("agents", {}, "RECORD_UID_ALPHA"))
        out_none = asyncio.run(mcp_srv.bus_get("agents", "RECORD_UID_ALPHA"))
        decoded_none = json.loads(out_none)

        assert bus.publish.call_args[0][0] == "agents"
        assert decoded_none["value"] is None

        bus.get.return_value = envelope
        out_val = asyncio.run(mcp_srv.bus_get("agents", "RECORD_UID_ALPHA"))
        decoded = json.loads(out_val)
        assert decoded["value"] == {"payload": "x"}
        assert decoded["version"] == 4


def test_build_mcp_plan_prepends_capability_conflicts(monkeypatch: pytest.MonkeyPatch) -> None:
    """unsupported_capabilities rows become synthetic CONFLICT change headers."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.mcp import server as mcp_srv
    from dsk.providers import MockProvider as _Mp

    mcp_srv._MOCK_PROVIDERS.clear()

    class _Limited(_Mp):  # type: ignore[misc]
        def unsupported_capabilities(self, manifest=None):
            return ["rotation-not-modeled"]

    with patch.object(mcp_srv, "MockProvider", _Limited):
        plan_obj = asyncio.run(mcp_srv.server.call_tool("dsk_plan", {"manifest_yaml": _PAM_MIN}))
    payload = json.loads(plan_obj["content"][0]["text"])
    rows = payload.get("changes", [])
    assert rows and rows[0]["resource_type"] == "capability"


def test_build_mcp_plan_ownership_maps_to_capability_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """OwnershipError surfaces as CapabilityError (ownership error wording)."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.core.errors import OwnershipError
    from dsk.mcp import server as mcp_srv

    exc = OwnershipError(reason="markers disagree")

    with patch.object(mcp_srv, "compute_diff", side_effect=exc):
        resp = asyncio.run(mcp_srv.server.call_tool("dsk_plan", {"manifest_yaml": _PAM_MIN}))
    assert resp["isError"] is True


def test_build_mcp_plan_pam_extended_capability_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Unreachable production branch for pam_extended is exercised via patched load."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    from dsk.core.errors import CapabilityError
    from dsk.mcp.server import PlanBundle, _build_mcp_plan

    pam_ext = MagicMock()
    bundle = PlanBundle(
        manifest_name="pe",
        order=[],
        provider=MagicMock(unsupported_capabilities=lambda _m: []),
        pam=None,
        vault=None,
        sharing=None,
        msp=None,
        identity=None,
        pam_extended=pam_ext,
        events=None,
        nhi=None,
        ai_agent=None,
        live=[],
        live_msp=[],
        live_record_type_defs=[],
    )

    with (
        patch("dsk.mcp.server._load_mcp_bundle", return_value=bundle),
        patch("dsk.mcp.server.compute_pam_extended_diff", return_value=[]),
    ):
        with pytest.raises(CapabilityError, match="keeper-pam-extended"):
            _build_mcp_plan(Path("_unused.yaml"), allow_delete=False)


def test_manifest_name_other_families(monkeypatch: pytest.MonkeyPatch) -> None:
    """_manifest_name honours msp / events / nhi / pam_extended naming rules."""

    monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
    monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)

    path = Path("/tmp/ignored.yaml")
    import dsk.mcp.server as mcp_srv
    from dsk.mcp.server import PAM_EXTENDED_FAMILY, _manifest_name

    msp_m = MagicMock()
    msp_m.name = "msp-name-unit"
    assert _manifest_name(path, None, msp_m, None, None, None, None, None) == "msp-name-unit"

    ev = MagicMock()
    ev.name = "evt-name"
    assert _manifest_name(path, None, None, None, None, ev, None, None) == "evt-name"

    nhi_stub = MagicMock()
    assert _manifest_name(path, None, None, None, None, None, nhi_stub, None) == mcp_srv.NHI_FAMILY

    ai_stub = MagicMock()
    assert (
        _manifest_name(path, None, None, None, None, None, None, ai_stub) == mcp_srv.AI_AGENT_FAMILY
    )

    pe_stub = MagicMock()
    assert _manifest_name(path, None, None, None, pe_stub, None, None, None) == PAM_EXTENDED_FAMILY


class _KwCapture:
    def __init__(self) -> None:
        self.keywords: dict[str, Any] = {}

    def __call__(self, **kwargs):  # type: ignore[no-untyped-def]
        self.keywords = kwargs


def test_make_mcp_provider_prefers_service_url_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """When env keys are present, CommanderServiceProvider (or patched stub) builds."""

    from dsk.mcp import server as mcp_srv

    monkeypatch.setenv("KEEPER_SERVICE_URL", "https://svc.example/")
    monkeypatch.setenv("KEEPER_SERVICE_API_KEY", "sekret")

    try:
        cap = _KwCapture()
        mcp_srv.CommanderServiceProvider = cap  # type: ignore[method-assign]

        manifest = MagicMock()
        manifest.model_dump = MagicMock(return_value={"schema": "pam-environment.v1", "name": "p"})

        mcp_srv._make_mcp_provider("manifest-x", manifest)
        assert cap.keywords["service_url"] == "https://svc.example/"
        assert cap.keywords["api_key"] == "sekret"
        assert cap.keywords["manifest_source"]["name"] == "p"
    finally:
        mcp_srv.CommanderServiceProvider = None  # type: ignore[method-assign]
        monkeypatch.delenv("KEEPER_SERVICE_URL", raising=False)
        monkeypatch.delenv("KEEPER_SERVICE_API_KEY", raising=False)


def test_import_service_provider_missing_commander_raises_capability_error() -> None:
    """Missing CommanderServiceProvider class maps to CapabilityError guidance."""

    import types

    import dsk.mcp.server as mcp_srv
    from dsk.core.errors import CapabilityError

    key = "dsk.providers.commander_service"
    saved = sys.modules.get(key)
    placeholder = types.ModuleType(key)
    sys.modules[key] = placeholder
    try:
        with pytest.raises(CapabilityError) as ei:
            mcp_srv._import_service_provider()
        assert "CommanderServiceProvider" in ei.value.reason
    finally:
        if saved is None:
            sys.modules.pop(key, None)
        else:
            sys.modules[key] = saved


def test_json_schema_fallback_unknown_type() -> None:
    """_json_schema_for_annotation falls back to string for unknown annotations."""

    from dsk.mcp.server import _json_schema_for_annotation

    class _UnknownType:
        pass

    assert _json_schema_for_annotation(_UnknownType) == {"type": "string"}
