"""Tests for the Terraform external-data bridge script."""

from __future__ import annotations

import importlib.util
import io
import json
import subprocess
import sys
import types
from pathlib import Path

import pytest

SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "terraform/modules/keeper_pam_environment/scripts/dsk_tf_bridge.py"
)


def _load_module() -> types.ModuleType:
    spec = importlib.util.spec_from_file_location("dsk_tf_bridge", SCRIPT)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["dsk_tf_bridge"] = module
    spec.loader.exec_module(module)
    return module


dsk_tf_bridge = _load_module()


def _stdin_from_bytes(payload: bytes) -> io.TextIOWrapper:
    return io.TextIOWrapper(io.BytesIO(payload), encoding="utf-8")


def test_read_query_accepts_at_byte_cap(monkeypatch: pytest.MonkeyPatch) -> None:
    payload = b'{"manifest_path":"m.yaml","provider":"mock"}'
    monkeypatch.setenv("DSK_TF_BRIDGE_MAX_QUERY_BYTES", str(len(payload)))
    monkeypatch.setattr(sys, "stdin", _stdin_from_bytes(payload))

    assert dsk_tf_bridge._read_query()["provider"] == "mock"


def test_read_query_rejects_just_over_byte_cap(monkeypatch: pytest.MonkeyPatch) -> None:
    payload = b'{"manifest_path":"m.yaml","provider":"mock"}'
    monkeypatch.setenv("DSK_TF_BRIDGE_MAX_QUERY_BYTES", str(len(payload) - 1))
    monkeypatch.setattr(sys, "stdin", _stdin_from_bytes(payload))

    with pytest.raises(dsk_tf_bridge.ResourceLimitError, match="DSK_TF_BRIDGE_MAX_QUERY_BYTES"):
        dsk_tf_bridge._read_query()


def test_main_passes_timeout_and_parses_bounded_stdout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    payload = b'{"manifest_path":"m.yaml","provider":"mock"}'
    monkeypatch.setenv("DSK_TF_BRIDGE_TIMEOUT_SECONDS", "7")
    monkeypatch.setattr(sys, "stdin", _stdin_from_bytes(payload))
    output = io.StringIO()
    monkeypatch.setattr(sys, "stdout", output)

    def fake_run(*_args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        assert kwargs["timeout"] == 7
        return subprocess.CompletedProcess(
            args=["dsk"],
            returncode=0,
            stdout=json.dumps({"summary": {"create": 1}, "manifest_name": "m"}),
            stderr="",
        )

    monkeypatch.setattr(dsk_tf_bridge.subprocess, "run", fake_run)

    dsk_tf_bridge.main()

    result = json.loads(output.getvalue())
    assert result["create"] == "1"
    assert result["manifest_name"] == "m"
