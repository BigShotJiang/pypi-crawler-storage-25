"""Tests for the root `dsk` CLI entry-point (--version, --help, --provider)."""

from __future__ import annotations

from click.testing import CliRunner

from dsk.cli.main import main


def test_version_exits_zero() -> None:
    result = CliRunner().invoke(main, ["--version"])
    assert result.exit_code == 0


def test_version_output_contains_version_number() -> None:
    result = CliRunner().invoke(main, ["--version"])
    assert "version" in result.output.lower()
    # Semver pattern: digits.digits.digits somewhere in the output
    import re

    assert re.search(r"\d+\.\d+\.\d+", result.output), result.output


def test_help_exits_zero() -> None:
    result = CliRunner().invoke(main, ["--help"])
    assert result.exit_code == 0


def test_help_lists_core_commands() -> None:
    result = CliRunner().invoke(main, ["--help"])
    assert "validate" in result.output
    assert "plan" in result.output
    assert "apply" in result.output
    assert "diff" in result.output
    assert "verify" in result.output


def test_help_lists_discovery_commands() -> None:
    result = CliRunner().invoke(main, ["--help"])
    assert "orient" in result.output
    assert "doctor" in result.output


def test_invalid_command_exits_nonzero() -> None:
    result = CliRunner().invoke(main, ["does-not-exist"])
    assert result.exit_code != 0


def test_plan_help_exits_zero() -> None:
    result = CliRunner().invoke(main, ["plan", "--help"])
    assert result.exit_code == 0
    assert "--provider" in result.output or "provider" in result.output.lower()


def test_apply_help_exits_zero() -> None:
    result = CliRunner().invoke(main, ["apply", "--help"])
    assert result.exit_code == 0
    assert "--dry-run" in result.output or "dry" in result.output.lower()


def test_verify_help_exits_zero_and_lists_strict() -> None:
    result = CliRunner().invoke(main, ["verify", "--help"])
    assert result.exit_code == 0
    assert "--strict" in result.output


def test_invalid_provider_choice_is_click_usage_error() -> None:
    result = CliRunner().invoke(main, ["--provider", "bogus", "doctor"])
    assert result.exit_code == 2
    assert "invalid value" in result.output.lower()


def test_no_args_prints_help_without_traceback() -> None:
    result = CliRunner().invoke(main, [])
    assert result.exit_code == 2
    assert "Keeper PAM Declarative SDK" in result.output
    assert "Traceback" not in result.output
