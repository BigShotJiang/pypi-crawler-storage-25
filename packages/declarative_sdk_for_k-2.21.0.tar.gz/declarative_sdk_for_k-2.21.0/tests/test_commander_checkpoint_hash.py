"""Resource-limit coverage for Commander checkpoint manifest hashing."""

from __future__ import annotations

import hashlib
from pathlib import Path

import pytest

from dsk.providers.commander_cli import _checkpoint_manifest_hash


def test_checkpoint_manifest_hash_accepts_at_byte_cap(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    raw = b"family: test\n"
    manifest.write_bytes(raw)
    monkeypatch.setenv("DSK_CHECKPOINT_MANIFEST_MAX_BYTES", str(len(raw)))

    assert _checkpoint_manifest_hash(str(manifest)) == hashlib.sha256(raw).hexdigest()[:12]


def test_checkpoint_manifest_hash_rejects_just_over_byte_cap(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest = tmp_path / "manifest.yaml"
    raw = b"family: test\n"
    manifest.write_bytes(raw)
    monkeypatch.setenv("DSK_CHECKPOINT_MANIFEST_MAX_BYTES", str(len(raw) - 1))

    assert _checkpoint_manifest_hash(str(manifest)) == "unknown"
