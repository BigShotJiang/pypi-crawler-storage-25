"""Tests for DSK renderer protocol and core interface contracts."""

from __future__ import annotations

from dsk.cli.renderer import RichRenderer
from dsk.core.diff import Change, ChangeKind
from dsk.core.interfaces import ApplyOutcome, Renderer
from dsk.core.planner import Plan


def test_rich_renderer_conforms_to_renderer_protocol():
    r: Renderer = RichRenderer()

    assert hasattr(r, "render_plan")
    assert hasattr(r, "render_diff")
    assert hasattr(r, "render_outcomes")


def _make_plan(name: str = "test-manifest", changes: list[Change] | None = None) -> Plan:
    return Plan(manifest_name=name, changes=changes or [])


def test_render_plan_returns_string_with_manifest_name():
    renderer = RichRenderer()
    plan = _make_plan("my-plan")
    output = renderer.render_plan(plan)
    assert isinstance(output, str)
    assert "my-plan" in output


def test_render_plan_shows_create_for_create_change():
    renderer = RichRenderer()
    change = Change(
        kind=ChangeKind.CREATE,
        resource_type="pam_machine",
        uid_ref="machine.web1",
        title="web1",
        keeper_uid=None,
        reason=None,
        before=None,
        after={"hostname": "web1"},
    )
    plan = _make_plan("create-test", [change])
    output = renderer.render_plan(plan)
    assert "create" in output.lower()
    assert "machine.web1" in output


def test_render_plan_shows_summary_counts():
    renderer = RichRenderer()
    plan = _make_plan(
        "counts-test",
        [
            Change(
                kind=ChangeKind.CREATE,
                resource_type="pam_machine",
                uid_ref="m1",
                title="M1",
                keeper_uid=None,
                reason=None,
                before=None,
                after={},
            ),
            Change(
                kind=ChangeKind.NOOP,
                resource_type="pam_machine",
                uid_ref="m2",
                title="M2",
                keeper_uid="uid22chars0000000000AB",
                reason=None,
                before={},
                after={},
            ),
        ],
    )
    output = renderer.render_plan(plan)
    assert "+1" in output or "1" in output


def test_render_diff_returns_string():
    renderer = RichRenderer()
    change = Change(
        kind=ChangeKind.UPDATE,
        resource_type="pam_machine",
        uid_ref="machine.x",
        title="x",
        keeper_uid="uid22chars0000000000AB",
        reason="field changed",
        before={"hostname": "old"},
        after={"hostname": "new"},
    )
    plan = _make_plan("diff-test", [change])
    output = renderer.render_diff(plan)
    assert isinstance(output, str)
    assert "diff-test" in output


def test_render_diff_skips_noop_changes():
    renderer = RichRenderer()
    noop = Change(
        kind=ChangeKind.NOOP,
        resource_type="pam_machine",
        uid_ref="machine.quiet",
        title="quiet",
        keeper_uid="uid22chars0000000000AB",
        reason=None,
        before={},
        after={},
    )
    plan = _make_plan("noop-test", [noop])
    output = renderer.render_diff(plan)
    assert "quiet" not in output


def test_render_outcomes_returns_string():
    renderer = RichRenderer()
    outcomes = [
        ApplyOutcome(
            uid_ref="machine.web1",
            keeper_uid="uid22chars0000000000AB",
            action="create",
            details={"mock": True},
        ),
    ]
    output = renderer.render_outcomes(outcomes)
    assert isinstance(output, str)
    assert "machine.web1" in output


def test_render_outcomes_empty_list():
    renderer = RichRenderer()
    output = renderer.render_outcomes([])
    assert isinstance(output, str)
