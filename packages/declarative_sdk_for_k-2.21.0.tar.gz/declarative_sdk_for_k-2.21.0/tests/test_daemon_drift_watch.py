"""Targeted unit tests for dsk.daemon.drift_watch (mocked I/O)."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from dsk.daemon.drift_watch import (
    DriftResult,
    WatchConfig,
    _create_and_push_branch,
    _notify_servicenow,
    _notify_slack,
    _open_github_pr,
    _run_dsk_plan,
    watch_loop,
)


def test_run_dsk_plan_malformed_json_sets_error() -> None:
    """Invalid JSON stdout must populate error (JSONDecodeError path)."""
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="{not-json", stderr="")
        result = _run_dsk_plan("manifest.yaml")
    assert not result.has_drift
    assert result.error is not None


def test_run_dsk_plan_unexpected_exit_sets_error() -> None:
    """Exit code outside 0 and 2 must short-circuit without parsing JSON."""
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=3, stdout="{}", stderr="nope")
        result = _run_dsk_plan("manifest.yaml")
    assert not result.has_drift
    assert result.error is not None
    assert "3" in result.error


def test_run_dsk_plan_exit_zero_parses_summary() -> None:
    """Exit 0 with valid JSON must populate plan_summary and has_drift=False."""
    payload = {"summary": {"create": 0, "noop": 2}}
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout=json.dumps(payload), stderr="")
        result = _run_dsk_plan("m.yaml")
    assert not result.has_drift
    assert result.plan_summary.get("noop") == 2


def test_notify_slack_skips_without_webhook_url() -> None:
    drift = DriftResult(manifest_path="x.yaml", has_drift=True, plan_summary={})
    cfg = WatchConfig(manifest_paths=["x.yaml"])
    with patch("urllib.request.urlopen") as mock_open:
        _notify_slack(drift, cfg)
    mock_open.assert_not_called()


def test_notify_slack_success_posts_and_logs(caplog: pytest.LogCaptureFixture) -> None:
    """Successful webhook post must log info (happy path)."""
    import logging

    caplog.set_level(logging.INFO, logger="dsk.daemon.drift_watch")
    drift = DriftResult(
        manifest_path="x.yaml",
        has_drift=True,
        plan_summary={"create": 1},
    )
    cfg = WatchConfig(
        manifest_paths=["x.yaml"],
        slack_webhook_url="https://hooks.slack.com/fake",
        slack_channel="#alerts",
    )
    mock_cm = MagicMock()
    mock_cm.__enter__ = lambda s: s
    mock_cm.__exit__ = MagicMock(return_value=False)
    with patch("urllib.request.urlopen", return_value=mock_cm) as mock_open:
        _notify_slack(drift, cfg)
    mock_open.assert_called_once()
    messages = [r.getMessage() for r in caplog.records]
    assert any("Slack drift alert sent" in m for m in messages)


def test_notify_slack_urlopen_failure_is_swallowed() -> None:
    """Slack webhook errors must be caught and logged, not raised."""
    drift = DriftResult(
        manifest_path="x.yaml",
        has_drift=True,
        plan_summary={"create": 1},
    )
    cfg = WatchConfig(
        manifest_paths=["x.yaml"],
        slack_webhook_url="https://hooks.slack.com/fake",
    )
    with patch("urllib.request.urlopen", side_effect=OSError("network down")):
        _notify_slack(drift, cfg)


def test_notify_servicenow_skips_without_credentials() -> None:
    drift = DriftResult(manifest_path="m.yaml", has_drift=True, plan_summary={})
    cfg = WatchConfig(manifest_paths=["m.yaml"])  # no ServiceNow fields
    assert _notify_servicenow(drift, cfg) is None


def test_notify_servicenow_success_returns_ticket_number() -> None:
    """ServiceNow POST success must return incident number from JSON body."""
    drift = DriftResult(
        manifest_path="m.yaml",
        has_drift=True,
        plan_summary={"create": 1, "update": 0, "delete": 0, "conflict": 0},
    )
    cfg = WatchConfig(
        manifest_paths=["m.yaml"],
        servicenow_instance="dev.example.service-now.com",
        servicenow_api_key="user:pass",
        servicenow_table="incident",
    )
    body = json.dumps({"result": {"number": "INC10001"}}).encode()
    mock_resp = MagicMock()
    mock_resp.read.return_value = body
    mock_ctx = MagicMock()
    mock_ctx.__enter__.return_value = mock_resp
    mock_ctx.__exit__.return_value = False
    with patch("urllib.request.urlopen", return_value=mock_ctx):
        ticket = _notify_servicenow(drift, cfg)
    assert ticket == "INC10001"


def test_notify_servicenow_success_uses_unknown_when_number_missing() -> None:
    """Missing result.number still completes; code uses default 'unknown'."""
    drift = DriftResult(
        manifest_path="m.yaml",
        has_drift=True,
        plan_summary={},
    )
    cfg = WatchConfig(
        manifest_paths=["m.yaml"],
        servicenow_instance="dev.example.service-now.com",
        servicenow_api_key="k",
    )
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps({"result": {}}).encode()
    mock_ctx = MagicMock()
    mock_ctx.__enter__.return_value = mock_resp
    mock_ctx.__exit__.return_value = False
    with patch("urllib.request.urlopen", return_value=mock_ctx):
        ticket = _notify_servicenow(drift, cfg)
    assert ticket == "unknown"


def test_notify_servicenow_request_failure_returns_none() -> None:
    """HTTP or parse errors must return None and not raise."""
    drift = DriftResult(manifest_path="m.yaml", has_drift=True, plan_summary={})
    cfg = WatchConfig(
        manifest_paths=["m.yaml"],
        servicenow_instance="dev.example.service-now.com",
        servicenow_api_key="k",
    )
    with patch("urllib.request.urlopen", side_effect=ValueError("bad response")):
        assert _notify_servicenow(drift, cfg) is None


def test_create_and_push_branch_oserror_returns_false() -> None:
    """OSError from subprocess.run must short-circuit with False."""
    with patch("subprocess.run", side_effect=OSError("no git")):
        ok = _create_and_push_branch("b", "manifest.yaml", {})
    assert ok is False


def test_create_and_push_branch_nonzero_exit_returns_false() -> None:
    """Non-zero git step must return False (after try block, not OSError)."""
    fail = MagicMock(returncode=1, stderr="rejected", stdout="")
    with patch("subprocess.run", return_value=fail):
        ok = _create_and_push_branch("b", "manifest.yaml", {})
    assert ok is False


def test_create_and_push_branch_all_git_steps_succeed() -> None:
    """All three git commands succeeding must return True."""
    ok_result = MagicMock(returncode=0, stderr="", stdout="")
    with patch("subprocess.run", return_value=ok_result) as mock_run:
        ok = _create_and_push_branch("feature/x", "dir/manifest.yaml", {"GIT": "1"})
    assert ok is True
    assert mock_run.call_count == 3


def test_open_github_pr_warns_and_skips_without_credentials() -> None:
    """Missing repo or token must log and return None without subprocess."""
    drift = DriftResult(
        manifest_path="m.yaml",
        has_drift=True,
        plan_summary={"create": 1},
    )
    cfg = WatchConfig(manifest_paths=["m.yaml"], dry_run=False)
    with patch("dsk.daemon.drift_watch.subprocess.run") as mock_run:
        url = _open_github_pr(drift, cfg, "branch")
    assert url is None
    mock_run.assert_not_called()


def test_open_github_pr_returns_none_when_branch_creation_fails() -> None:
    with patch(
        "dsk.daemon.drift_watch._create_and_push_branch",
        return_value=False,
    ):
        drift = DriftResult(
            manifest_path="m.yaml",
            has_drift=True,
            plan_summary={},
        )
        cfg = WatchConfig(
            manifest_paths=["m.yaml"],
            github_repo="o/r",
            github_token="tok",
            dry_run=False,
        )
        assert _open_github_pr(drift, cfg, "b") is None


def test_open_github_pr_returns_none_when_gh_fails() -> None:
    git_ok = MagicMock(returncode=0, stderr="", stdout="")
    gh_fail = MagicMock(returncode=1, stderr="gh failed", stdout="")
    drift = DriftResult(
        manifest_path="m.yaml",
        has_drift=True,
        plan_summary={},
    )
    cfg = WatchConfig(
        manifest_paths=["m.yaml"],
        github_repo="o/r",
        github_token="tok",
        dry_run=False,
    )
    with patch(
        "dsk.daemon.drift_watch.subprocess.run",
        side_effect=[git_ok, git_ok, git_ok, gh_fail],
    ):
        assert _open_github_pr(drift, cfg, "br") is None


def test_open_github_pr_returns_url_when_gh_succeeds() -> None:
    git_ok = MagicMock(returncode=0, stderr="", stdout="")
    gh_ok = MagicMock(
        returncode=0,
        stderr="",
        stdout="https://github.com/o/r/pull/99\n",
    )
    drift = DriftResult(
        manifest_path="m.yaml",
        has_drift=True,
        plan_summary={},
    )
    cfg = WatchConfig(
        manifest_paths=["m.yaml"],
        github_repo="o/r",
        github_token="tok",
        dry_run=False,
    )
    with patch(
        "dsk.daemon.drift_watch.subprocess.run",
        side_effect=[git_ok, git_ok, git_ok, gh_ok],
    ):
        url = _open_github_pr(drift, cfg, "br")
    assert url == "https://github.com/o/r/pull/99"


def test_watch_loop_one_iteration_then_interrupt() -> None:
    """Exercise plan error, no drift, drift+PR paths; exit on sleep."""
    cfg = WatchConfig(
        manifest_paths=["bad.yaml", "clean.yaml", "drift.yaml"],
        poll_interval_seconds=1,
        dry_run=False,
        github_repo="o/r",
        github_token="t",
    )

    def plan_side_effect(path: str) -> DriftResult:
        if path == "bad.yaml":
            return DriftResult(manifest_path=path, has_drift=False, error="plan blew up")
        if path == "clean.yaml":
            return DriftResult(
                manifest_path=path,
                has_drift=False,
                plan_summary={"noop": 1},
            )
        return DriftResult(
            manifest_path=path,
            has_drift=True,
            plan_summary={"create": 1},
        )

    pr_mock = MagicMock(return_value="https://github.com/o/r/pull/1")
    with (
        patch("dsk.daemon.drift_watch._run_dsk_plan", side_effect=plan_side_effect),
        patch("dsk.daemon.drift_watch._notify_slack"),
        patch("dsk.daemon.drift_watch._notify_servicenow"),
        patch("dsk.daemon.drift_watch._open_github_pr", pr_mock),
        patch(
            "dsk.daemon.drift_watch.time.sleep",
            side_effect=KeyboardInterrupt,
        ),
    ):
        with pytest.raises(KeyboardInterrupt):
            watch_loop(cfg)

    pr_mock.assert_called_once()


def test_watch_loop_dry_run_skips_open_github_pr() -> None:
    cfg = WatchConfig(
        manifest_paths=["only.yaml"],
        poll_interval_seconds=0,
        dry_run=True,
        github_repo="o/r",
    )
    drift = DriftResult(
        manifest_path="only.yaml",
        has_drift=True,
        plan_summary={"update": 1},
    )
    pr_mock = MagicMock()
    with (
        patch("dsk.daemon.drift_watch._run_dsk_plan", return_value=drift),
        patch("dsk.daemon.drift_watch._notify_slack"),
        patch("dsk.daemon.drift_watch._notify_servicenow"),
        patch("dsk.daemon.drift_watch._open_github_pr", pr_mock),
        patch(
            "dsk.daemon.drift_watch.time.sleep",
            side_effect=KeyboardInterrupt,
        ),
    ):
        with pytest.raises(KeyboardInterrupt):
            watch_loop(cfg)
    pr_mock.assert_not_called()


def test_watch_loop_inner_exception_is_logged_and_continues() -> None:
    cfg = WatchConfig(manifest_paths=["a.yaml", "b.yaml"], poll_interval_seconds=0)

    def plan_side_effect(path: str) -> DriftResult:
        if path == "a.yaml":
            raise RuntimeError("boom")
        return DriftResult(
            manifest_path=path,
            has_drift=False,
            plan_summary={},
        )

    with (
        patch("dsk.daemon.drift_watch._run_dsk_plan", side_effect=plan_side_effect),
        patch(
            "dsk.daemon.drift_watch.time.sleep",
            side_effect=KeyboardInterrupt,
        ),
    ):
        with pytest.raises(KeyboardInterrupt):
            watch_loop(cfg)
