"""Tests for SPIFFE workload identity binding models."""

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError


def test_spiffe_rule_defaults() -> None:
    from dsk.core.models_spiffe import SpiffeIdentityRule, SpiffeMatchMode

    rule = SpiffeIdentityRule(
        spiffe_id="spiffe://acme.com/workload",
        trust_domain="acme.com",
    )
    assert rule.match == SpiffeMatchMode.exact
    assert rule.allow_jit is False
    assert rule.audit_log is True
    assert rule.resources == []


def test_spiffe_manifest_round_trip() -> None:
    from dsk.core.models_spiffe import SpiffeBindingManifestV1, SpiffeMatchMode

    example = Path(__file__).parent.parent / "examples/spiffe/acme-spiffe-binding.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = SpiffeBindingManifestV1(**data)
    assert manifest.schema_ == "spiffe-binding.v1"
    assert manifest.trust_domain == "acme.com"
    assert len(manifest.rules) == 2
    assert manifest.rules[1].match == SpiffeMatchMode.prefix


def test_spiffe_resource_ttl_bounds() -> None:
    from dsk.core.models_spiffe import SpiffeResourceBinding

    with pytest.raises(ValidationError):
        SpiffeResourceBinding(uid_ref="res.x", ttl_seconds=30)  # below 60s minimum


def test_spiffe_schema_field_alias() -> None:
    from dsk.core.models_spiffe import SpiffeBindingManifestV1

    m = SpiffeBindingManifestV1(
        **{"schema": "spiffe-binding.v1", "name": "test", "trust_domain": "acme.com"}
    )
    assert m.schema_ == "spiffe-binding.v1"


def test_spiffe_resource_binding_accepts_max_ttl() -> None:
    """TTL may be set to the 24h upper bound."""
    from dsk.core.models_spiffe import SpiffeResourceBinding

    binding = SpiffeResourceBinding(uid_ref="res.long", ttl_seconds=86400)
    assert binding.ttl_seconds == 86400


def test_spiffe_manifest_default_empty_rules() -> None:
    """Rules list defaults to empty when only trust domain is configured."""
    from dsk.core.models_spiffe import SpiffeBindingManifestV1

    manifest = SpiffeBindingManifestV1(
        **{"schema": "spiffe-binding.v1", "name": "minimal", "trust_domain": "acme.com"}
    )
    assert manifest.rules == []


def test_spiffe_rule_accepts_prefix_match_mode() -> None:
    from dsk.core.models_spiffe import SpiffeIdentityRule, SpiffeMatchMode

    rule = SpiffeIdentityRule(
        spiffe_id="spiffe://acme.com/",
        trust_domain="acme.com",
        match=SpiffeMatchMode.prefix,
    )
    assert rule.match is SpiffeMatchMode.prefix
