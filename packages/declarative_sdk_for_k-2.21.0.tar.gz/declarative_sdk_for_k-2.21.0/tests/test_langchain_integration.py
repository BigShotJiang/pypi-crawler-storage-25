"""Tests for DSK LangChain integration module."""

from __future__ import annotations

import importlib


def test_module_importable_without_langchain() -> None:
    """Module must not crash on import even if langchain is not installed."""
    mod = importlib.import_module("dsk.integrations.langchain")
    assert hasattr(mod, "get_dsk_tools")
    assert hasattr(mod, "DskValidateTool")


def test_require_langchain_raises_without_install() -> None:
    """_require_langchain must raise ImportError when _LANGCHAIN_AVAILABLE=False."""
    import dsk.integrations.langchain as lc

    original = lc._LANGCHAIN_AVAILABLE
    lc._LANGCHAIN_AVAILABLE = False
    try:
        try:
            lc._require_langchain()
            assert False, "Expected ImportError"
        except ImportError as exc:
            assert "langchain" in str(exc).lower()
    finally:
        lc._LANGCHAIN_AVAILABLE = original


def test_dsk_validate_tool_has_expected_name() -> None:
    """DskValidateTool must expose name='dsk_validate'."""
    import dsk.integrations.langchain as lc

    tool = lc.DskValidateTool()
    assert tool.name == "dsk_validate"
    assert tool.description


def test_dsk_plan_tool_has_expected_name() -> None:
    """DskPlanTool must expose name='dsk_plan'."""
    import dsk.integrations.langchain as lc

    tool = lc.DskPlanTool()
    assert tool.name == "dsk_plan"
    assert tool.description


def test_dsk_apply_tool_has_expected_name() -> None:
    """DskApplyTool must expose name='dsk_apply'."""
    import dsk.integrations.langchain as lc

    tool = lc.DskApplyTool()
    assert tool.name == "dsk_apply"
    assert tool.description


def test_get_dsk_tools_raises_without_langchain() -> None:
    """get_dsk_tools() must raise ImportError when langchain is unavailable."""
    import dsk.integrations.langchain as lc

    original = lc._LANGCHAIN_AVAILABLE
    lc._LANGCHAIN_AVAILABLE = False
    try:
        try:
            lc.get_dsk_tools()
            assert False, "Expected ImportError"
        except ImportError:
            pass
    finally:
        lc._LANGCHAIN_AVAILABLE = original


def _with_langchain(monkeypatch):
    """Ensure _LANGCHAIN_AVAILABLE is True for the test scope."""
    import dsk.integrations.langchain as lc

    monkeypatch.setattr(lc, "_LANGCHAIN_AVAILABLE", True)
    return lc


def test_validate_tool_run_success(monkeypatch, tmp_path) -> None:
    """DskValidateTool._run returns 'VALID:...' when dsk exits 0."""
    import subprocess

    lc = _with_langchain(monkeypatch)

    fake = subprocess.CompletedProcess(args=[], returncode=0, stdout="family=pam\n", stderr="")
    monkeypatch.setattr(subprocess, "run", lambda *a, **kw: fake)

    tool = lc.DskValidateTool()
    result = tool._run(str(tmp_path / "manifest.yaml"))
    assert result.startswith("VALID:")


def test_validate_tool_run_failure(monkeypatch, tmp_path) -> None:
    """DskValidateTool._run returns 'INVALID...' when dsk exits non-zero."""
    import subprocess

    lc = _with_langchain(monkeypatch)

    fake = subprocess.CompletedProcess(args=[], returncode=2, stdout="", stderr="bad schema")
    monkeypatch.setattr(subprocess, "run", lambda *a, **kw: fake)

    tool = lc.DskValidateTool()
    result = tool._run(str(tmp_path / "manifest.yaml"))
    assert "INVALID" in result


def test_plan_tool_run_returns_summary(monkeypatch, tmp_path) -> None:
    """DskPlanTool._run parses JSON plan output and returns summary string."""
    import json
    import subprocess

    lc = _with_langchain(monkeypatch)

    payload = {"summary": {"create": 3, "update": 0, "delete": 0, "conflict": 0, "noop": 5}}
    fake = subprocess.CompletedProcess(args=[], returncode=2, stdout=json.dumps(payload), stderr="")
    monkeypatch.setattr(subprocess, "run", lambda *a, **kw: fake)

    tool = lc.DskPlanTool()
    result = tool._run(str(tmp_path / "manifest.yaml"))
    assert "create=3" in result


def test_apply_tool_dry_run_flag(monkeypatch, tmp_path) -> None:
    """DskApplyTool._run adds --dry-run when dry_run=True."""
    import subprocess

    lc = _with_langchain(monkeypatch)

    captured_cmd: list[list[str]] = []

    def fake_run(cmd, **kw):
        captured_cmd.append(cmd)
        return subprocess.CompletedProcess(args=[], returncode=0, stdout="ok", stderr="")

    monkeypatch.setattr(subprocess, "run", fake_run)

    tool = lc.DskApplyTool()
    tool._run(str(tmp_path / "manifest.yaml"), dry_run=True)
    assert "--dry-run" in captured_cmd[0]


def test_get_dsk_tools_requires_langchain(monkeypatch) -> None:
    """get_dsk_tools raises ImportError when langchain is not installed."""
    import sys

    import pytest

    lc_mod = sys.modules.get("dsk.integrations.langchain")
    if lc_mod is None:
        return  # module not loaded yet; skip

    # Patch _require_langchain to simulate missing langchain
    monkeypatch.setattr(
        "dsk.integrations.langchain._require_langchain",
        lambda: (_ for _ in ()).throw(ImportError("No module named 'langchain'")),
    )
    with pytest.raises(ImportError, match="langchain"):
        lc_mod.get_dsk_tools()


def test_arun_delegates_to_run(monkeypatch, tmp_path) -> None:
    """DskValidateTool._arun returns same result as _run (sync wrapper)."""
    import asyncio
    import subprocess

    lc = _with_langchain(monkeypatch)

    def fake_run(cmd, **kw):
        return subprocess.CompletedProcess(args=[], returncode=0, stdout="ok: validated", stderr="")

    monkeypatch.setattr(subprocess, "run", fake_run)

    tool = lc.DskValidateTool()
    result_sync = tool._run(str(tmp_path / "manifest.yaml"))
    result_async = asyncio.run(tool._arun(str(tmp_path / "manifest.yaml")))
    assert result_sync == result_async
