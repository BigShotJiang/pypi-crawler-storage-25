"""Snapshot tests for the DSK Tier 1 absorption API."""

from __future__ import annotations

import dataclasses
import inspect
from pathlib import Path
from typing import Any

import pytest
from jsonschema import Draft202012Validator

import dsk
import dsk.shim as shim
from dsk.core.planner import Plan
from dsk.shim import (
    ApplyResult,
    AuditExplanation,
    Bundle,
    ImportResult,
    ShimCommandResult,
    VerifyResult,
)

EMPTY = "<empty>"
ParamSnapshot = tuple[str, str, str, str]

TOP_LEVEL_ALL = {
    "shim",
    "VaultManifestV1",
    "SharingManifestV1",
    "KsmManifestV1",
    "PolicyManifestV1",
    "__version__",
}

ABSORPTION_VERBS = {
    "adopt",
    "plan",
    "apply",
    "diff",
    "audit_explain",
    "drift_watch",
    "rehearse_report",
    "bundle",
}
STANDALONE_VERBS = {"verify", "discover"}
DEPRECATED_ALIASES = {"import_from_keepercmd", "audit"}
CANONICAL_VERBS = (
    "adopt",
    "plan",
    "apply",
    "diff",
    "audit_explain",
    "drift_watch",
    "rehearse_report",
    "bundle",
    "verify",
    "discover",
)

EXPECTED_SHIM_ALL = {
    "DEFAULT_DRIFT_WATCH_INTERVAL_SECONDS",
    "SHIM_CONTRACT_VERSION",
    "OUTPUT_CONTRACT_VERSIONS_SUPPORTED",
    "SIGNATURE_BACKENDS",
    "SUPPORTED_VERBS",
    "ShimCommandResult",
    "ImportResult",
    "ApplyResult",
    "VerifyResult",
    "AuditExplanation",
    "Bundle",
    "shim_info",
    "shim_info_json",
    "adopt",
    "import_from_keepercmd",
    "plan",
    "apply",
    "diff",
    "verify",
    "audit_explain",
    "audit",
    "bundle",
    "discover",
    "drift_watch",
    "rehearse_report",
}

EXPECTED_SIGNATURES: dict[str, tuple[ParamSnapshot, ...]] = {
    "adopt": (
        ("run_dir", "POSITIONAL_OR_KEYWORD", "str | Path", EMPTY),
        ("output", "KEYWORD_ONLY", "str | Path | None", "None"),
        ("dry_run", "KEYWORD_ONLY", "bool", "True"),
        ("auto_approve", "KEYWORD_ONLY", "bool", "False"),
        ("skip_audit_verify", "KEYWORD_ONLY", "bool", "False"),
        ("skip_sha256", "KEYWORD_ONLY", "bool", "False"),
        ("suspect_threshold", "KEYWORD_ONLY", "int", "0"),
        ("verbose", "KEYWORD_ONLY", "bool", "False"),
        ("require_output_signature", "KEYWORD_ONLY", "bool", "False"),
        ("signature_pubkey", "KEYWORD_ONLY", "str | Path | None", "None"),
        ("signature_pubkey_keeper_record", "KEYWORD_ONLY", "str | None", "None"),
        ("commander_config", "KEYWORD_ONLY", "str | Path | None", "None"),
    ),
    "plan": (
        ("target_state", "POSITIONAL_OR_KEYWORD", "str | Path", EMPTY),
        ("allow_delete", "KEYWORD_ONLY", "bool", "False"),
        ("provider", "KEYWORD_ONLY", "str", "'mock'"),
        ("folder_uid", "KEYWORD_ONLY", "str | None", "None"),
    ),
    "apply": (
        ("plan", "POSITIONAL_OR_KEYWORD", "Plan | str | Path", EMPTY),
        ("manifest_path", "KEYWORD_ONLY", "str | Path | None", "None"),
        ("dry_run", "KEYWORD_ONLY", "bool", "True"),
        ("allow_delete", "KEYWORD_ONLY", "bool", "False"),
        ("auto_approve", "KEYWORD_ONLY", "bool", "False"),
        ("provider", "KEYWORD_ONLY", "str", "'mock'"),
        ("folder_uid", "KEYWORD_ONLY", "str | None", "None"),
    ),
    "diff": (
        ("manifest_path", "POSITIONAL_OR_KEYWORD", "str | Path", EMPTY),
        ("allow_delete", "KEYWORD_ONLY", "bool", "False"),
        ("provider", "KEYWORD_ONLY", "str", "'mock'"),
        ("folder_uid", "KEYWORD_ONLY", "str | None", "None"),
    ),
    "audit_explain": (
        ("audit_log", "POSITIONAL_OR_KEYWORD", "str | Path", EMPTY),
        ("summary", "KEYWORD_ONLY", "bool", "True"),
    ),
    "drift_watch": (
        ("manifest_paths", "POSITIONAL_OR_KEYWORD", "Sequence[str | Path]", EMPTY),
        ("interval", "KEYWORD_ONLY", "int", "300"),
        ("github_repo", "KEYWORD_ONLY", "str | None", "None"),
        ("github_token", "KEYWORD_ONLY", "str | None", "None"),
        ("pr_base", "KEYWORD_ONLY", "str", "'main'"),
        ("dry_run", "KEYWORD_ONLY", "bool", "True"),
        ("slack_webhook", "KEYWORD_ONLY", "str | None", "None"),
        ("slack_channel", "KEYWORD_ONLY", "str | None", "None"),
        ("servicenow_instance", "KEYWORD_ONLY", "str | None", "None"),
        ("servicenow_api_key", "KEYWORD_ONLY", "str | None", "None"),
        ("verbose", "KEYWORD_ONLY", "bool", "False"),
    ),
    "rehearse_report": (
        ("run_dir", "POSITIONAL_OR_KEYWORD", "str | Path", EMPTY),
        ("output", "KEYWORD_ONLY", "str | Path | None", "None"),
        ("dry_run", "KEYWORD_ONLY", "bool", "False"),
        ("verbose", "KEYWORD_ONLY", "bool", "False"),
        ("output_format", "KEYWORD_ONLY", "str", "'text'"),
    ),
    "bundle": (
        ("manifest_path", "POSITIONAL_OR_KEYWORD", "str | Path", EMPTY),
        ("output_dir", "KEYWORD_ONLY", "str | Path | None", "None"),
        ("dry_run", "KEYWORD_ONLY", "bool", "False"),
    ),
    "verify": (
        ("run_dir", "POSITIONAL_OR_KEYWORD", "str | Path", EMPTY),
        ("strict", "KEYWORD_ONLY", "bool", "False"),
        ("require_output_signature", "KEYWORD_ONLY", "bool", "False"),
        ("signature_pubkey", "KEYWORD_ONLY", "str | Path | None", "None"),
        ("signature_pubkey_keeper_record", "KEYWORD_ONLY", "str | None", "None"),
    ),
    "discover": (
        ("output", "KEYWORD_ONLY", "str | Path", EMPTY),
        ("provider", "KEYWORD_ONLY", "str | None", "None"),
        ("input_path", "KEYWORD_ONLY", "str | Path | None", "None"),
        ("name", "KEYWORD_ONLY", "str | None", "None"),
        ("folder_uid", "KEYWORD_ONLY", "str | None", "None"),
    ),
    "import_from_keepercmd": (
        ("args", "VAR_POSITIONAL", "Any", EMPTY),
        ("kwargs", "VAR_KEYWORD", "Any", EMPTY),
    ),
    "audit": (
        ("args", "VAR_POSITIONAL", "Any", EMPTY),
        ("kwargs", "VAR_KEYWORD", "Any", EMPTY),
    ),
}

EXPECTED_RETURNS: dict[str, type[Any]] = {
    "adopt": ImportResult,
    "plan": Plan,
    "apply": ApplyResult,
    "diff": ShimCommandResult,
    "audit_explain": AuditExplanation,
    "drift_watch": ShimCommandResult,
    "rehearse_report": ShimCommandResult,
    "bundle": Bundle,
    "verify": VerifyResult,
    "discover": ShimCommandResult,
    "import_from_keepercmd": ImportResult,
    "audit": AuditExplanation,
}

EXPECTED_DESCRIPTOR_FLAGS = {
    "adopt": (True, False),
    "plan": (True, False),
    "apply": (True, False),
    "diff": (True, False),
    "audit_explain": (True, False),
    "drift_watch": (True, False),
    "rehearse_report": (True, False),
    "bundle": (True, False),
    "verify": (False, True),
    "discover": (False, True),
}

EXPECTED_DESCRIPTOR_ALIASES = {
    "adopt": ("import_from_keepercmd",),
    "audit_explain": ("audit",),
}

EXPECTED_MANIFEST_FIELDS = {
    "VaultManifestV1": (
        "vault_schema",
        "records",
        "shared_folders",
        "record_types",
        "attachments",
        "keeper_fill",
    ),
    "SharingManifestV1": (
        "vault_schema",
        "folders",
        "shared_folders",
        "share_records",
        "share_folders",
    ),
    "KsmManifestV1": (
        "ksm_schema",
        "apps",
        "tokens",
        "clients",
        "record_shares",
        "config_outputs",
    ),
    "PolicyManifestV1": (
        "schema",
        "name",
        "manager",
        "password_policies",
        "sharing_policies",
        "two_fa_policies",
        "ip_allowlist_policies",
        "session_timeout_policies",
        "audit_policies",
    ),
}

EXPECTED_MANIFEST_ALIASES = {
    "VaultManifestV1": {"vault_schema": "schema"},
    "SharingManifestV1": {"vault_schema": "schema"},
    "KsmManifestV1": {"ksm_schema": "schema"},
    "PolicyManifestV1": {},
}

EXPECTED_SCHEMA_DEFAULTS = {
    "VaultManifestV1": ("vault_schema", "keeper-vault.v1"),
    "SharingManifestV1": ("vault_schema", "keeper-vault-sharing.v1"),
    "KsmManifestV1": ("ksm_schema", "keeper-ksm.v1"),
    "PolicyManifestV1": ("schema", "keeper-policy.v1"),
}


def _annotation_name(annotation: object) -> str:
    if annotation is inspect.Signature.empty:
        return EMPTY
    if isinstance(annotation, str):
        return annotation
    name = getattr(annotation, "__name__", None)
    return str(name or annotation)


def _default_name(default: object) -> str:
    if default is inspect.Signature.empty:
        return EMPTY
    return repr(default)


def _signature_snapshot(function: Any) -> tuple[ParamSnapshot, ...]:
    signature = inspect.signature(function)
    return tuple(
        (
            parameter.name,
            parameter.kind.name,
            _annotation_name(parameter.annotation),
            _default_name(parameter.default),
        )
        for parameter in signature.parameters.values()
    )


def _manifest_class(name: str) -> type[Any]:
    value = getattr(dsk, name)
    assert isinstance(value, type)
    return value


def _manifest_field_names(model: type[Any]) -> tuple[str, ...]:
    if dataclasses.is_dataclass(model):
        return tuple(field.name for field in dataclasses.fields(model))

    model_fields = getattr(model, "model_fields", None)
    assert isinstance(model_fields, dict)
    return tuple(str(name) for name in model_fields)


def _manifest_aliases(model: type[Any]) -> dict[str, str]:
    if dataclasses.is_dataclass(model):
        return {}

    model_fields = getattr(model, "model_fields", None)
    assert isinstance(model_fields, dict)
    aliases: dict[str, str] = {}
    for name, field in model_fields.items():
        alias = getattr(field, "alias", None)
        if alias is not None:
            aliases[str(name)] = str(alias)
    return aliases


def _manifest_default(model: type[Any], field_name: str) -> object:
    if dataclasses.is_dataclass(model):
        fields = {field.name: field for field in dataclasses.fields(model)}
        return fields[field_name].default

    model_fields = getattr(model, "model_fields", None)
    assert isinstance(model_fields, dict)
    return model_fields[field_name].default


def _shim_info_schema() -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": [
            "shim_contract_version",
            "dsk_version",
            "supported_verbs",
            "verbs",
            "output_contract_versions_supported",
            "negotiated_output_contract_version",
            "signature_backends",
        ],
        "properties": {
            "shim_contract_version": {"type": "string"},
            "dsk_version": {"type": "string", "minLength": 1},
            "supported_verbs": {
                "type": "array",
                "items": {"enum": list(CANONICAL_VERBS)},
                "uniqueItems": True,
            },
            "verbs": {
                "type": "object",
                "required": list(CANONICAL_VERBS),
                "additionalProperties": {"$ref": "#/$defs/verb_descriptor"},
            },
            "output_contract_versions_supported": {
                "type": "array",
                "items": {"type": "string"},
                "minItems": 1,
            },
            "negotiated_output_contract_version": {"type": "string"},
            "signature_backends": {
                "type": "array",
                "items": {"type": "string"},
            },
        },
        "$defs": {
            "verb_descriptor": {
                "type": "object",
                "required": [
                    "name",
                    "signature",
                    "cli_signature",
                    "library_signature",
                    "contract_inputs",
                    "contract_outputs",
                    "click_params",
                    "is_idempotent",
                    "requires_keeper_session",
                    "keeper_session_mode",
                    "absorption_subset",
                    "standalone_only",
                    "deprecated_aliases",
                ],
                "properties": {
                    "name": {"type": "string"},
                    "signature": {"type": "string"},
                    "cli_signature": {"type": "string"},
                    "library_signature": {"type": "string"},
                    "contract_inputs": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "contract_outputs": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "click_params": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "is_idempotent": {"type": "boolean"},
                    "requires_keeper_session": {"type": "boolean"},
                    "keeper_session_mode": {"type": "string"},
                    "absorption_subset": {"type": "boolean"},
                    "standalone_only": {"type": "boolean"},
                    "deprecated_aliases": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
            },
        },
    }


def test_dsk_top_level_all_exact() -> None:
    """The top-level __all__ list is the absorption-relevant API contract."""

    assert set(dsk.__all__) == TOP_LEVEL_ALL


def test_shim_module_all_exact() -> None:
    assert set(shim.__all__) == EXPECTED_SHIM_ALL


def test_shim_exposes_all_absorption_verbs() -> None:
    for verb in ABSORPTION_VERBS:
        assert hasattr(shim, verb), f"missing absorption verb: {verb}"


def test_shim_exposes_standalone_verbs() -> None:
    for verb in STANDALONE_VERBS:
        assert hasattr(shim, verb), f"missing standalone verb: {verb}"


def test_shim_exposes_deprecated_aliases() -> None:
    for alias in DEPRECATED_ALIASES:
        assert hasattr(shim, alias), f"missing deprecated alias: {alias}"


@pytest.mark.parametrize(("verb_name", "expected_params"), EXPECTED_SIGNATURES.items())
def test_verb_signature_stable(
    verb_name: str,
    expected_params: tuple[ParamSnapshot, ...],
) -> None:
    assert _signature_snapshot(getattr(shim, verb_name)) == expected_params


@pytest.mark.parametrize(("verb_name", "expected_type"), EXPECTED_RETURNS.items())
def test_verb_return_type_stable(verb_name: str, expected_type: type[Any]) -> None:
    signature = inspect.signature(getattr(shim, verb_name))
    assert signature.return_annotation is not inspect.Signature.empty
    assert _annotation_name(signature.return_annotation) == expected_type.__name__
    assert dataclasses.is_dataclass(expected_type)


def test_import_from_keepercmd_warns_and_dispatches(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[tuple[Any, ...], dict[str, Any]]] = []

    def fake_adopt(*args: Any, **kwargs: Any) -> ImportResult:
        calls.append((args, kwargs))
        return ImportResult(0, "ok\n", "", ("adopt",), Path(str(args[0])), None, "schema: x\n")

    monkeypatch.setattr(shim, "adopt", fake_adopt)

    with pytest.warns(DeprecationWarning, match=r"deprecated.*adopt"):
        result = shim.import_from_keepercmd("run-dir", dry_run=True)

    assert result.exit_code == 0
    assert result.run_dir == Path("run-dir")
    assert calls == [(("run-dir",), {"dry_run": True})]


def test_audit_warns_and_dispatches(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[tuple[Any, ...], dict[str, Any]]] = []

    def fake_audit_explain(*args: Any, **kwargs: Any) -> AuditExplanation:
        calls.append((args, kwargs))
        return AuditExplanation(Path(str(args[0])), 1, 0, {"create": 1}, (), (None, None))

    monkeypatch.setattr(shim, "audit_explain", fake_audit_explain)

    with pytest.warns(DeprecationWarning, match=r"deprecated.*audit_explain"):
        result = shim.audit("audit.log", summary=False)

    assert result.entry_count == 1
    assert result.failure_count == 0
    assert calls == [(("audit.log",), {"summary": False})]


def test_shim_info_schema() -> None:
    schema = _shim_info_schema()
    info = shim.shim_info()

    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(info)
    assert tuple(info["supported_verbs"]) == CANONICAL_VERBS


@pytest.mark.parametrize(("verb_name", "expected_flags"), EXPECTED_DESCRIPTOR_FLAGS.items())
def test_descriptor_absorption_flags_stable(
    verb_name: str,
    expected_flags: tuple[bool, bool],
) -> None:
    descriptor = shim.shim_info()["verbs"][verb_name]
    absorption_subset, standalone_only = expected_flags

    assert descriptor["name"] == verb_name
    assert descriptor["absorption_subset"] is absorption_subset
    assert descriptor["standalone_only"] is standalone_only


@pytest.mark.parametrize(("verb_name", "aliases"), EXPECTED_DESCRIPTOR_ALIASES.items())
def test_descriptor_deprecated_aliases_stable(
    verb_name: str,
    aliases: tuple[str, ...],
) -> None:
    descriptor = shim.shim_info()["verbs"][verb_name]

    assert tuple(descriptor["deprecated_aliases"]) == aliases


def test_descriptor_non_alias_verbs_have_no_deprecated_aliases() -> None:
    descriptors = shim.shim_info()["verbs"]
    aliased_verbs = set(EXPECTED_DESCRIPTOR_ALIASES)

    for verb_name in set(CANONICAL_VERBS) - aliased_verbs:
        assert descriptors[verb_name]["deprecated_aliases"] == []


@pytest.mark.parametrize(("manifest_name", "expected_fields"), EXPECTED_MANIFEST_FIELDS.items())
def test_manifest_fields_stable(
    manifest_name: str,
    expected_fields: tuple[str, ...],
) -> None:
    assert _manifest_field_names(_manifest_class(manifest_name)) == expected_fields


@pytest.mark.parametrize(("manifest_name", "expected_aliases"), EXPECTED_MANIFEST_ALIASES.items())
def test_manifest_aliases_stable(
    manifest_name: str,
    expected_aliases: dict[str, str],
) -> None:
    assert _manifest_aliases(_manifest_class(manifest_name)) == expected_aliases


@pytest.mark.parametrize(("manifest_name", "schema_default"), EXPECTED_SCHEMA_DEFAULTS.items())
def test_manifest_schema_defaults_stable(
    manifest_name: str,
    schema_default: tuple[str, str],
) -> None:
    field_name, expected_default = schema_default

    assert _manifest_default(_manifest_class(manifest_name), field_name) == expected_default
