"""Enterprise write capability decisions for G4a."""

from __future__ import annotations

import pytest

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_enterprise import ENTERPRISE_CONFIG_RESOURCE_TYPES
from dsk.core.planner import Plan
from dsk.providers.commander_cli import CommanderCliProvider


def _enterprise_config_plan(resource_type: str = "enterprise_config") -> Plan:
    change = Change(
        kind=ChangeKind.UPDATE,
        uid_ref="policy.security",
        resource_type=resource_type,
        title="Security policy",
        before={"policy": "security"},
        after={"policy": "security", "settings": {"minimum_password_length": 16}},
    )
    return Plan("enterprise-write-test", [change], [change.uid_ref or ""])


def test_enterprise_config_resource_types_are_plain_language() -> None:
    assert "enterprise_security_policy" in ENTERPRISE_CONFIG_RESOURCE_TYPES
    assert "enterprise_password_rules" in ENTERPRISE_CONFIG_RESOURCE_TYPES
    assert "enterprise_2fa_policy" in ENTERPRISE_CONFIG_RESOURCE_TYPES
    assert "enterprise_sharing_policy" in ENTERPRISE_CONFIG_RESOURCE_TYPES


def test_commander_enterprise_config_apply_is_explicit_upstream_gap() -> None:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)

    with pytest.raises(CapabilityError) as exc_info:
        provider.apply_enterprise_plan(_enterprise_config_plan(), manifest=None)

    assert "enterprise-info` as a read-only report" in exc_info.value.reason
    assert "enterprise-info edit/set" in exc_info.value.next_action


def test_commander_enterprise_policy_alias_is_same_gap() -> None:
    provider = CommanderCliProvider.__new__(CommanderCliProvider)

    with pytest.raises(CapabilityError) as exc_info:
        provider.apply_enterprise_plan(
            _enterprise_config_plan("enterprise_password_rules"),
            manifest=None,
        )

    assert exc_info.value.resource_type == "enterprise_password_rules"
    assert "Commander 18.0.0" in exc_info.value.reason
