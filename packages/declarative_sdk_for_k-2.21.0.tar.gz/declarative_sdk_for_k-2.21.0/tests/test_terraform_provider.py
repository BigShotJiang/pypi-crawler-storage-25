from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.models_terraform import TERRAFORM_FAMILY, TerraformIntegrationManifestV1
from dsk.providers.terraform_provider import (
    _TERRAFORM_TIMEOUT_SECONDS,
    GENERATED_TF,
    TerraformProvider,
    render_terraform_hcl,
)


def _manifest() -> TerraformIntegrationManifestV1:
    return TerraformIntegrationManifestV1.model_validate(
        {
            "schema": TERRAFORM_FAMILY,
            "resource_mappings": [
                {
                    "dsk_family": "keeper-vault.v1",
                    "tf_resource_type": "secretsmanager_login",
                    "direction": "bidirectional",
                },
                {
                    "dsk_family": "pam-environment.v1",
                    "tf_resource_type": "secretsmanager_pam_machine",
                    "direction": "tf_source",
                },
            ],
        }
    )


def test_apply_dry_run_runs_plan_only(tmp_path: Path) -> None:
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(_manifest())
    completed = subprocess.CompletedProcess(args=[], returncode=0)

    with patch(
        "dsk.providers.terraform_provider.subprocess.run",
        return_value=completed,
    ) as run:
        provider.apply(plan, dry_run=True)

    assert run.call_count == 1
    assert run.call_args.args[0] == ["terraform", "plan"]


def test_apply_writes_tf_file(tmp_path: Path) -> None:
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(_manifest())
    completed = subprocess.CompletedProcess(args=[], returncode=0)

    with patch(
        "dsk.providers.terraform_provider.subprocess.run",
        return_value=completed,
    ):
        provider.apply(plan, dry_run=True)

    rendered = (tmp_path / GENERATED_TF).read_text(encoding="utf-8")
    assert "keeper_dsk_resource_mappings" in rendered
    assert 'dsk_family       = "keeper-vault.v1"' in rendered
    assert 'tf_resource_type = "secretsmanager_login"' in rendered


def test_plan_creates_all_mappings(tmp_path: Path) -> None:
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(_manifest())

    assert len(plan.changes) == 2
    assert all(c.kind == ChangeKind.CREATE for c in plan.changes)


def test_full_apply_runs_apply_command(tmp_path: Path) -> None:
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(_manifest())
    completed = subprocess.CompletedProcess(args=[], returncode=0)

    with patch(
        "dsk.providers.terraform_provider.subprocess.run",
        return_value=completed,
    ) as run:
        provider.apply(plan, dry_run=False)

    assert run.call_count == 2
    apply_calls = [c.args[0] for c in run.call_args_list]
    assert ["terraform", "apply", "-auto-approve"] in apply_calls


def test_render_terraform_hcl_includes_direction() -> None:
    hcl = render_terraform_hcl(_manifest())

    assert 'direction = "bidirectional"' in hcl
    assert 'direction = "tf_source"' in hcl


def test_plan_pam_database_tf_resource_type(tmp_path: Path) -> None:
    """pam-environment mappings use keeper_pam_database as Terraform resource type."""
    manifest = TerraformIntegrationManifestV1.model_validate(
        {
            "schema": TERRAFORM_FAMILY,
            "resource_mappings": [
                {
                    "dsk_family": "pam-environment.v1",
                    "tf_resource_type": "keeper_pam_database",
                    "direction": "bidirectional",
                }
            ],
        }
    )
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(manifest)
    assert len(plan.changes) == 1
    assert plan.changes[0].title == "keeper_pam_database"

    hcl = render_terraform_hcl(manifest)
    assert 'tf_resource_type = "keeper_pam_database"' in hcl


def test_plan_empty_resource_mappings(tmp_path: Path) -> None:
    manifest = TerraformIntegrationManifestV1.model_validate(
        {"schema": TERRAFORM_FAMILY, "resource_mappings": []}
    )
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(manifest)
    assert plan.changes == []


def test_apply_dry_run_monkeypatch_only_terraform_plan(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(_manifest())
    recorded: list[list[str]] = []

    def fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[str]:
        recorded.append(cmd)
        return subprocess.CompletedProcess(cmd, 0, "", "")

    monkeypatch.setattr(
        "dsk.providers.terraform_provider.subprocess.run",
        fake_run,
    )
    provider.apply(plan, dry_run=True)
    assert recorded == [["terraform", "plan"]]


def test_apply_empty_plan_skips_subprocess(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    manifest = TerraformIntegrationManifestV1.model_validate(
        {"schema": TERRAFORM_FAMILY, "resource_mappings": []}
    )
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(manifest)

    def boom(*_args: object, **_kwargs: object) -> None:
        raise AssertionError("subprocess.run must not be called for an empty plan")

    monkeypatch.setattr(
        "dsk.providers.terraform_provider.subprocess.run",
        boom,
    )
    assert provider.apply(plan, dry_run=True) == []


def test_terraform_plan_timeout_raises_capability_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    (tmp_path / ".terraform").mkdir()
    provider = TerraformProvider(workdir=tmp_path)

    def timeout_run(*_args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        assert kwargs["timeout"] == _TERRAFORM_TIMEOUT_SECONDS
        raise subprocess.TimeoutExpired(
            cmd=["terraform", "plan"], timeout=_TERRAFORM_TIMEOUT_SECONDS
        )

    monkeypatch.setattr("dsk.providers.terraform_provider.subprocess.run", timeout_run)

    with pytest.raises(CapabilityError, match="terraform plan timed out"):
        provider.plan(_manifest())


def test_terraform_plan_has_changes_true_for_summary() -> None:
    """_terraform_plan_has_changes returns True for change_summary with adds."""
    import json

    from dsk.providers.terraform_provider import _terraform_plan_has_changes

    line = json.dumps({"type": "change_summary", "changes": {"add": 2, "change": 0, "remove": 0}})
    assert _terraform_plan_has_changes(line) is True


def test_terraform_plan_has_changes_false_for_noop() -> None:
    """_terraform_plan_has_changes returns False when only no-op actions."""
    import json

    from dsk.providers.terraform_provider import _terraform_plan_has_changes

    line = json.dumps({"type": "change_summary", "changes": {"add": 0, "change": 0, "remove": 0}})
    assert _terraform_plan_has_changes(line) is False


def test_actions_have_changes_detects_non_noop() -> None:
    """_actions_have_changes returns True when actions list has non-no-op entries."""
    from dsk.providers.terraform_provider import _actions_have_changes

    assert _actions_have_changes(["create"]) is True
    assert _actions_have_changes(["no-op"]) is False
    assert _actions_have_changes([]) is False
    assert _actions_have_changes("not-a-list") is False


def test_change_summary_has_changes_wrong_type() -> None:
    """_change_summary_has_changes returns False for non-change_summary events."""
    from dsk.providers.terraform_provider import _change_summary_has_changes

    assert _change_summary_has_changes({"type": "apply", "changes": {"add": 5}}) is False
    assert _change_summary_has_changes({"type": "change_summary", "changes": None}) is False


# ── Sprint BF: terraform_provider additional coverage ─────────────────────


def test_render_terraform_hcl_basic_mapping() -> None:
    """render_terraform_hcl produces HCL content with resource mappings."""
    from dsk.core.models_terraform import TerraformIntegrationManifestV1
    from dsk.providers.terraform_provider import render_terraform_hcl

    manifest = TerraformIntegrationManifestV1(
        **{
            "schema": "keeper-terraform.v1",
            "resource_mappings": [
                {
                    "dsk_family": "pam-environment.v1",
                    "tf_resource_type": "keeper_pam_record",
                    "direction": "dsk_source",
                },
            ],
        }
    )
    hcl = render_terraform_hcl(manifest)
    assert isinstance(hcl, str) and len(hcl) > 0


def test_terraform_provider_discover_returns_empty() -> None:
    """TerraformProvider.discover always returns empty list (plan-only routing)."""
    from pathlib import Path

    from dsk.providers.terraform_provider import TerraformProvider

    provider = TerraformProvider(workdir=Path("/tmp"))
    assert provider.discover() == []


def test_terraform_provider_unsupported_capabilities_empty() -> None:
    """TerraformProvider.unsupported_capabilities returns []."""
    from dsk.providers.terraform_provider import TerraformProvider

    assert TerraformProvider().unsupported_capabilities() == []


def test_terraform_provider_check_tenant_bindings_empty() -> None:
    """TerraformProvider.check_tenant_bindings returns []."""
    from dsk.providers.terraform_provider import TerraformProvider

    assert TerraformProvider().check_tenant_bindings() == []


def test_outcome_changes_returns_noops_when_ordered_empty() -> None:
    """_outcome_changes falls back to plan.noops when ordered() is empty."""
    from dsk.core.diff import Change, ChangeKind
    from dsk.core.planner import Plan
    from dsk.providers.terraform_provider import _outcome_changes

    noop_change = Change(
        kind=ChangeKind.NOOP,
        resource_type="x",
        uid_ref="x.ref",
        title="Noop",
        keeper_uid="uid",
        reason=None,
    )
    plan = Plan(manifest_name="t", changes=[noop_change])
    result = _outcome_changes(plan)
    assert noop_change in result


# ── coverage: lines 40-98 (subprocess plan/apply paths) ───────────────────


def test_plan_with_terraform_dir_no_changes(tmp_path):
    """When .terraform exists and plan exits 0, returns NOOP plan."""
    (tmp_path / ".terraform").mkdir()
    m = _manifest()
    proc = type("R", (), {"returncode": 0, "stdout": ""})()
    with patch("subprocess.run", return_value=proc):
        p = TerraformProvider(workdir=tmp_path).plan(m)
    assert any(c.kind.value == "noop" for c in p.changes)


def test_plan_with_terraform_dir_has_changes(tmp_path):
    """When .terraform exists and plan exits 2, returns UPDATE plan."""
    (tmp_path / ".terraform").mkdir()
    m = _manifest()
    # Simulate a plan JSON summary with resource_changes
    stdout = '{"type": "change_summary", "changes": {"add": 1, "change": 0, "remove": 0}}'
    proc = type("R", (), {"returncode": 2, "stdout": stdout})()
    with patch("subprocess.run", return_value=proc):
        p = TerraformProvider(workdir=tmp_path).plan(m)
    assert any(c.kind.value in ("update", "create") for c in p.changes)


def test_plan_with_terraform_dir_subprocess_error_raises_capability(tmp_path):
    """terraform plan non-0/2 exit → CapabilityError."""
    from dsk.core.errors import CapabilityError

    (tmp_path / ".terraform").mkdir()
    m = _manifest()
    proc = type("R", (), {"returncode": 1, "stdout": ""})()
    with patch("subprocess.run", return_value=proc):
        with pytest.raises(CapabilityError):
            TerraformProvider(workdir=tmp_path).plan(m)


def test_plan_terraform_not_found_raises_capability(tmp_path):
    """FileNotFoundError for terraform binary → CapabilityError."""
    from dsk.core.errors import CapabilityError

    (tmp_path / ".terraform").mkdir()
    m = _manifest()
    with patch("subprocess.run", side_effect=FileNotFoundError):
        with pytest.raises(CapabilityError, match="terraform not found"):
            TerraformProvider(workdir=tmp_path).plan(m)


def test_apply_dry_run_writes_hcl_and_runs_plan_only(tmp_path):
    """apply(dry_run=True) writes HCL and runs plan, skips apply."""
    m = _manifest()
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(m)  # no .terraform → _create_plan path
    setattr(plan, "_terraform_manifest", m)

    calls = []

    def _fake_run(cmd, **kwargs):
        calls.append(cmd)

    with patch("subprocess.run", side_effect=_fake_run):
        _ = provider.apply(plan, dry_run=True)
    assert any("plan" in c for c in calls)
    assert not any("apply" in c for c in calls)


def test_apply_not_dry_run_runs_apply(tmp_path):
    """apply(dry_run=False) runs both plan and apply commands."""
    m = _manifest()
    provider = TerraformProvider(workdir=tmp_path)
    plan = provider.plan(m)
    setattr(plan, "_terraform_manifest", m)

    calls = []

    def _fake_run(cmd, **kwargs):
        calls.append(cmd)

    with patch("subprocess.run", side_effect=_fake_run):
        provider.apply(plan, dry_run=False)
    assert any("apply" in c for c in calls)
