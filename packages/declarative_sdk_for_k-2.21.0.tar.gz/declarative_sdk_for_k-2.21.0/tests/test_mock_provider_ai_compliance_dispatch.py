"""MockProvider RED stubs for AI + compliance families — dispatch smoke + outcome shape."""

from __future__ import annotations

from dsk.core.ai_act_diff import compute_ai_act_diff
from dsk.core.ai_agent_diff import compute_ai_agent_diff
from dsk.core.ai_policy_diff import compute_ai_policy_diff
from dsk.core.ai_token_diff import compute_ai_token_diff
from dsk.core.cmmc_diff import compute_cmmc_diff
from dsk.core.compliance_diff import compute_compliance_diff
from dsk.core.cspm_diff import compute_cspm_diff
from dsk.core.dora_diff import compute_dora_diff
from dsk.core.models_ai_act import AiActProfileManifestV1
from dsk.core.models_ai_agent import AiAgentManifest
from dsk.core.models_ai_policy import AiPolicyManifestV1
from dsk.core.models_ai_token import AiCapabilityToken, AiTokenManifestV1
from dsk.core.models_cmmc import (
    CmmcControlMapping,
    CmmcControlStatus,
    CmmcDomain,
    CmmcProfileManifestV1,
)
from dsk.core.models_compliance import ComplianceBundleManifestV1, ComplianceFramework
from dsk.core.models_cspm import CspmRemediationManifestV1
from dsk.core.models_dora import (
    DoraArticle,
    DoraControlMapping,
    DoraControlStatus,
    DoraProfileManifestV1,
)
from dsk.core.models_pqc import PqcPolicyManifestV1, PqcResourceRequirement
from dsk.core.planner import Plan, build_plan
from dsk.core.pqc_diff import compute_pqc_diff
from dsk.providers.mock import MockProvider

_MANIFEST = "mock-ai-compliance"


def _plan_from_changes(changes: list) -> Plan:
    order = [c.uid_ref or "" for c in changes]
    return build_plan(_MANIFEST, changes, order)


def test_mock_apply_ai_agent_plan_returns_family_tagged_create_row() -> None:
    manifest = AiAgentManifest.model_validate(
        {
            "schema": "ai-agent.v1",
            "resources": [
                {
                    "uid_ref": "ai.stub.agent",
                    "name": "stub",
                    "purpose": "tests",
                    "scope": ["internal"],
                    "allowed_tools": ["read"],
                },
            ],
        }
    )
    changes = compute_ai_agent_diff(manifest, None, manifest_name=_MANIFEST, allow_delete=False)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    before_records = len(provider.discover())

    outcomes = provider.apply_ai_agent_plan(plan, dry_run=False)
    assert len(outcomes) == len(changes) == 1
    row = outcomes[0]
    assert row.uid_ref == "ai.stub.agent"
    assert row.action == "create" and row.status == "create"
    assert row.keeper_uid
    assert row.details.get("family") == "ai-agent.v1"
    assert row.details.get("mock") is True
    assert len(provider.discover()) == before_records


def test_mock_apply_ai_act_plan_returns_family_tagged_create_row() -> None:
    manifest = AiActProfileManifestV1(
        **{
            "schema": "ai-act-profile.v1",
            "name": "stub-act",
            "controls": [
                {
                    "article": "art-test",
                    "obligation": "keep logs",
                    "status": "compliant",
                }
            ],
        }
    )
    changes = compute_ai_act_diff(manifest, live=None)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    outcomes = provider.apply_ai_act_plan(plan)
    assert len(outcomes) == len(changes)
    assert len(changes) >= 1
    create_rows = [o for o in outcomes if o.action == "create"]
    assert create_rows
    assert all(o.details.get("family") == "ai-act-profile.v1" for o in create_rows)
    assert all(o.uid_ref for o in outcomes)


def test_mock_apply_ai_policy_plan_returns_family_tagged_create_row() -> None:
    manifest = AiPolicyManifestV1.model_validate(
        {
            "schema": "keeper-ai-policy.v1",
            "name": "stub-pol",
            "policies": [{"name": "p1", "anomaly_rules": [{"name": "r", "pattern": "x"}]}],
        }
    )
    changes = compute_ai_policy_diff(manifest, live=None, manifest_name=_MANIFEST)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    outcomes = provider.apply_ai_policy_plan(plan)
    assert len(outcomes) == 1
    assert outcomes[0].action == "create"
    assert outcomes[0].details.get("family") == "keeper-ai-policy.v1"
    assert outcomes[0].keeper_uid


def test_mock_apply_ai_token_plan_returns_family_tagged_create_row() -> None:
    manifest = AiTokenManifestV1(
        schema="ai-token.v1",
        name="stub-token",
        tokens=[
            AiCapabilityToken(name="t1", agent_uid_ref="agent.stub", ttl_seconds=900),
        ],
    )
    changes = compute_ai_token_diff(manifest, live=None, manifest_name=_MANIFEST)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    outcomes = provider.apply_ai_token_plan(plan)
    assert len(outcomes) == 1
    assert outcomes[0].action == "create"
    assert outcomes[0].details.get("family") == "ai-token.v1"
    assert outcomes[0].keeper_uid


def test_mock_apply_cmmc_plan_returns_family_tagged_create_row() -> None:
    manifest = CmmcProfileManifestV1(
        schema="cmmc-profile.v1",
        name="stub-cmmc",
        controls=[
            CmmcControlMapping(
                practice_id="3.1.1",
                domain=CmmcDomain.access_control,
                description="AC stub",
                status=CmmcControlStatus.met,
            ),
        ],
    )
    changes = compute_cmmc_diff(manifest, live=None, manifest_name=_MANIFEST)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    outcomes = provider.apply_cmmc_plan(plan)
    assert len(outcomes) == 1
    assert outcomes[0].action == "create"
    assert outcomes[0].uid_ref == changes[0].uid_ref
    assert outcomes[0].details.get("family") == "cmmc-profile.v1"
    assert outcomes[0].keeper_uid


def test_mock_apply_dora_plan_returns_family_tagged_create_row() -> None:
    manifest = DoraProfileManifestV1(
        schema="dora-profile.v1",
        name="stub-dora",
        controls=[
            DoraControlMapping(
                article=DoraArticle.art9,
                control_description="ICT risk",
                status=DoraControlStatus.satisfied,
            ),
        ],
    )
    changes = compute_dora_diff(manifest, live=None, manifest_name=_MANIFEST)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    outcomes = provider.apply_dora_plan(plan)
    assert len(outcomes) == 1
    assert outcomes[0].action == "create"
    assert outcomes[0].uid_ref == DoraArticle.art9.value
    assert outcomes[0].details.get("family") == "dora-profile.v1"


def test_mock_apply_pqc_plan_returns_family_tagged_create_row() -> None:
    manifest = PqcPolicyManifestV1(
        schema="pqc-policy.v1",
        name="stub-pqc",
        requirements=[PqcResourceRequirement(uid_ref="pam.machine.stub")],
    )
    changes = compute_pqc_diff(manifest, live=None, manifest_name=_MANIFEST)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    outcomes = provider.apply_pqc_plan(plan)
    assert len(outcomes) == 1
    assert outcomes[0].uid_ref == "pam.machine.stub"
    assert outcomes[0].details.get("family") == "pqc-policy.v1"


def test_mock_apply_compliance_m_plan_returns_family_tagged_rows() -> None:
    manifest = ComplianceBundleManifestV1(
        schema="compliance-bundle.v1",
        name="stub-compliance",
        frameworks=[ComplianceFramework.soc2_type2],
    )
    changes = compute_compliance_diff(manifest, live=None, manifest_name=_MANIFEST)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    outcomes = provider.apply_compliance_m_plan(plan)
    assert len(outcomes) == len(changes) == 1
    assert outcomes[0].action == "create"
    assert outcomes[0].details.get("family") == "compliance-bundle.v1"


def test_mock_apply_cspm_plan_returns_family_tagged_create_row() -> None:
    manifest = CspmRemediationManifestV1(schema="cspm-remediation.v1", name="stub-cspm")
    changes = compute_cspm_diff(manifest, live=None, manifest_name=_MANIFEST)
    plan = _plan_from_changes(changes)
    provider = MockProvider(_MANIFEST)
    outcomes = provider.apply_cspm_plan(plan)
    assert len(outcomes) == 1
    assert outcomes[0].uid_ref == f"{_MANIFEST}.webhook"
    assert outcomes[0].action == "create"
    assert outcomes[0].details.get("family") == "cspm-remediation.v1"
