"""Additional CLI coverage for dsk.cli.main command bodies."""

from __future__ import annotations

import importlib
import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest
import yaml
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import (
    EXIT_CAPABILITY,
    EXIT_CHANGES,
    EXIT_CONFLICT,
    EXIT_GENERIC,
    EXIT_OK,
)
from dsk.core import (
    build_graph,
    build_plan,
    compute_diff,
    execution_order,
    load_manifest,
)
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import LiveRecord
from dsk.core.metadata import encode_marker
from dsk.providers import MockProvider

cli_main_module = importlib.import_module("dsk.cli.main")


def _run(args: list[str]) -> Any:
    return CliRunner().invoke(main, args, catch_exceptions=False)


# ---------------------------------------------------------------------------
# apply
# ---------------------------------------------------------------------------


def test_apply_dry_run_mock_provider_exits_changes_when_live_empty(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "apply", str(minimal_manifest_path), "--dry-run"])
    assert result.exit_code == EXIT_CHANGES, result.output
    assert "create" in result.output.lower() or "Create" in result.output


def test_apply_dry_run_mock_exits_ok_when_manifest_matches_live(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    graph = build_graph(manifest)
    order = execution_order(graph)
    provider.apply_plan(
        build_plan(manifest.name, compute_diff(manifest, provider.discover()), order)
    )
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "apply", str(minimal_manifest_path), "--dry-run"])
    assert result.exit_code == EXIT_OK, result.output


def test_apply_dry_run_conflict_exit_code_four(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    provider.seed(
        [
            LiveRecord(
                keeper_uid="LIVE_UID",
                title="lab-linux-1",
                resource_type="pamMachine",
                marker={
                    **encode_marker(
                        uid_ref="acme-lab-linux1",
                        manifest=manifest.name,
                        resource_type="pamMachine",
                    ),
                    "manager": "someone-else",
                },
                payload={"title": "lab-linux-1"},
            )
        ]
    )
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result_dry = _run(["--provider", "mock", "apply", str(minimal_manifest_path), "--dry-run"])
    assert result_dry.exit_code == EXIT_CONFLICT, result_dry.output

    result_live = _run(
        ["--provider", "mock", "apply", str(minimal_manifest_path), "--auto-approve"],
    )
    assert result_live.exit_code == EXIT_CONFLICT, result_live.output
    assert "conflict" in result_live.output.lower()


def test_plan_json_conflict_summary_matches_apply_dry_run_exit(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    provider.seed(
        [
            LiveRecord(
                keeper_uid="LIVE_UID",
                title="lab-linux-1",
                resource_type="pamMachine",
                marker={
                    **encode_marker(
                        uid_ref="acme-lab-linux1",
                        manifest=manifest.name,
                        resource_type="pamMachine",
                    ),
                    "manager": "someone-else",
                },
                payload={"title": "lab-linux-1"},
            )
        ]
    )
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result_json = _run(["--provider", "mock", "plan", str(minimal_manifest_path), "--json"])
    assert result_json.exit_code == EXIT_CONFLICT, result_json.output
    doc = json.loads(result_json.output.strip())
    assert doc["summary"]["conflict"] >= 1


def test_apply_clean_auto_approve_says_nothing_to_do(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    graph = build_graph(manifest)
    order = execution_order(graph)
    provider.apply_plan(
        build_plan(manifest.name, compute_diff(manifest, provider.discover()), order)
    )
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "apply", str(minimal_manifest_path), "--auto-approve"])
    assert result.exit_code == EXIT_OK, result.output
    assert "nothing to do" in result.output.lower()


# ---------------------------------------------------------------------------
# diff
# ---------------------------------------------------------------------------


def test_diff_pam_mock_reports_changes_against_empty_live(minimal_manifest_path: Path) -> None:
    result = _run(["--provider", "mock", "diff", str(minimal_manifest_path)])
    assert result.exit_code == EXIT_CHANGES, result.output


def test_diff_pam_allow_delete_still_reports_creates_when_live_empty(
    minimal_manifest_path: Path,
) -> None:
    result = _run(["--provider", "mock", "diff", str(minimal_manifest_path), "--allow-delete"])
    assert result.exit_code == EXIT_CHANGES, result.output


def test_diff_vault_mock_shows_changes(tmp_path: Path) -> None:
    manifest = tmp_path / "vault.yaml"
    manifest.write_text(
        "schema: keeper-vault.v1\n"
        "records:\n"
        "  - uid_ref: cli.v.login\n"
        "    type: login\n"
        "    title: CLI Vault Login\n",
        encoding="utf-8",
    )
    result = _run(["--provider", "mock", "diff", str(manifest)])
    assert result.exit_code == EXIT_CHANGES, result.output


# ---------------------------------------------------------------------------
# import
# ---------------------------------------------------------------------------


def test_import_adopts_using_manifest_copied_to_tmp_path(
    minimal_manifest_path: Path,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    copied = tmp_path / "env.yaml"
    copied.write_bytes(minimal_manifest_path.read_bytes())
    manifest = load_manifest(copied)
    provider = MockProvider(manifest.name)
    provider.seed(
        [
            LiveRecord(
                keeper_uid="LIVE_UID",
                title="lab-linux-1",
                resource_type="pamMachine",
                payload={"title": "lab-linux-1", "host": "10.16.9.10"},
                marker=None,
            )
        ]
    )
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["--provider", "mock", "import", str(copied), "--auto-approve"])
    assert result.exit_code == EXIT_OK, result.output
    adopted = next(r for r in provider.discover() if r.keeper_uid == "LIVE_UID")
    assert adopted.marker is not None
    assert adopted.marker["uid_ref"] == "acme-lab-linux1"


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------


def test_export_writes_yaml_roundtrip_file(tmp_path: Path, minimal_manifest_path: Path) -> None:
    doc = yaml.safe_load(minimal_manifest_path.read_text(encoding="utf-8"))
    commander_json = tmp_path / "cmd.json"
    commander_json.write_text(json.dumps(doc), encoding="utf-8")
    out_yaml = tmp_path / "lifted.yaml"
    result = _run(
        ["export", str(commander_json), "--name", "acme-lab-minimal", "-o", str(out_yaml)]
    )
    assert result.exit_code == EXIT_OK, result.output
    assert out_yaml.is_file()
    assert "wrote" in result.output.lower()
    body = out_yaml.read_text(encoding="utf-8")
    assert "name: acme-lab-minimal" in body
    assert "gateways:" in body


def test_export_prints_yaml_to_stdout(tmp_path: Path, minimal_manifest_path: Path) -> None:
    doc = yaml.safe_load(minimal_manifest_path.read_text(encoding="utf-8"))
    commander_json = tmp_path / "cmd.json"
    commander_json.write_text(json.dumps(doc), encoding="utf-8")
    result = _run(["export", str(commander_json), "--name", "acme-lab-minimal"])
    assert result.exit_code == EXIT_OK, result.output
    assert "name: acme-lab-minimal" in result.output
    assert "pam_configurations:" in result.output


def test_export_rejects_oversized_commander_json(
    tmp_path: Path,
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    doc = yaml.safe_load(minimal_manifest_path.read_text(encoding="utf-8"))
    commander_json = tmp_path / "cmd.json"
    raw = json.dumps(doc)
    commander_json.write_text(raw, encoding="utf-8")
    monkeypatch.setenv("DSK_CLI_MAX_COMMANDER_JSON_BYTES", str(len(raw.encode("utf-8")) - 1))

    result = CliRunner().invoke(main, ["export", str(commander_json)], catch_exceptions=True)

    assert result.exit_code == EXIT_GENERIC
    assert "DSK_CLI_MAX_COMMANDER_JSON_BYTES" in result.output


# ---------------------------------------------------------------------------
# doctor / orient
# ---------------------------------------------------------------------------


def test_doctor_prints_core_checks() -> None:
    result = _run(["doctor"])
    assert result.exit_code in {EXIT_OK, EXIT_GENERIC}, result.output
    assert "Python version" in result.output
    assert "keepercommander" in result.output.lower()
    assert "dsk version" in result.output.lower()


def test_orient_prints_commands_and_agent_runbook() -> None:
    result = _run(["orient"])
    assert result.exit_code == EXIT_OK, result.output
    assert "validate" in result.output
    assert "plan" in result.output
    assert "AGENT_RUNBOOK.md" in result.output


# ---------------------------------------------------------------------------
# validate --emit-canonical / --online
# ---------------------------------------------------------------------------


def test_validate_emit_canonical_text_prints_yaml_after_ok(minimal_manifest_path: Path) -> None:
    result = _run(["validate", str(minimal_manifest_path), "--emit-canonical"])
    assert result.exit_code == EXIT_OK, result.output
    lines = result.output.strip().splitlines()
    assert any(line.startswith("ok:") for line in lines)
    assert "acme-lab-minimal" in result.output


def test_validate_emit_canonical_json_includes_canonical_yaml_key(
    minimal_manifest_path: Path,
) -> None:
    result = _run(["validate", str(minimal_manifest_path), "--json", "--emit-canonical"])
    assert result.exit_code == EXIT_OK, result.output
    data = json.loads(result.output.strip())
    assert data["ok"] is True
    assert "canonical_yaml" in data
    assert "acme-lab-minimal" in data["canonical_yaml"]


def test_validate_online_json_mock_provider_includes_diff_smoke(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest = load_manifest(minimal_manifest_path)
    provider = MockProvider(manifest.name)
    provider.seed(
        [
            LiveRecord(
                keeper_uid="LIVE_GW_UID",
                title="Acme Lab Gateway",
                resource_type="gateway",
                payload={"name": "Acme Lab Gateway"},
                marker=None,
            )
        ]
    )
    monkeypatch.setattr(cli_main_module, "MockProvider", lambda manifest_name: provider)

    result = _run(["validate", str(minimal_manifest_path), "--online", "--json"])
    assert result.exit_code == EXIT_OK, result.output
    data = json.loads(result.output.strip())
    assert data["online"] is True
    assert "diff_smoke" in data["stages_completed"]


# ---------------------------------------------------------------------------
# bootstrap-ksm
# ---------------------------------------------------------------------------


def test_bootstrap_ksm_missing_session_token_exits_capability_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _raise(_login_helper: str) -> None:
        raise CapabilityError(
            reason="Commander config has no authenticated session token",
            next_action="run 'keeper login' first to authenticate the source admin session",
        )

    monkeypatch.setattr(cli_main_module, "_params_for_bootstrap", _raise)

    result = _run(
        [
            "bootstrap-ksm",
            "--app-name",
            "dsk-unit-test-app",
            "--login-helper",
            "commander",
        ]
    )
    assert result.exit_code == EXIT_CAPABILITY, result.output
    payload = json.loads(result.output.strip())
    assert payload["status"] == "fail"
    assert "session" in payload["reason"].lower()


def test_bootstrap_ksm_commander_import_error_exits_capability_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _raise(_login_helper: str) -> None:
        raise CapabilityError(
            reason="keepercommander is required for bootstrap-ksm commander login mode: No module named 'keepercommander'",
            next_action="pip install keepercommander>=18.0.0,<19",
        )

    monkeypatch.setattr(cli_main_module, "_params_for_bootstrap", _raise)

    result = _run(
        [
            "bootstrap-ksm",
            "--app-name",
            "dsk-unit-test-app",
            "--login-helper",
            "commander",
        ]
    )
    assert result.exit_code == EXIT_CAPABILITY, result.output
    payload = json.loads(result.output.strip())
    assert payload["status"] == "fail"
    assert "keepercommander" in payload["reason"].lower()


# ---------------------------------------------------------------------------
# plan --provider commander
# ---------------------------------------------------------------------------


def test_plan_with_commander_provider_mocked_runs_discovery(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = MagicMock()
    fake.discover.return_value = []
    fake.unsupported_capabilities.return_value = []
    fake.check_tenant_bindings.return_value = []
    monkeypatch.setattr(cli_main_module, "CommanderCliProvider", lambda **kw: fake)

    result = _run(["plan", "--provider", "commander", str(minimal_manifest_path)])
    assert result.exit_code == EXIT_CHANGES, result.output
    fake.discover.assert_called()


def test_plan_commander_with_allow_delete_flag(
    minimal_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = MagicMock()
    fake.discover.return_value = []
    fake.unsupported_capabilities.return_value = []
    fake.check_tenant_bindings.return_value = []
    monkeypatch.setattr(cli_main_module, "CommanderCliProvider", lambda **kw: fake)

    result = _run(
        ["plan", "--provider", "commander", "--allow-delete", str(minimal_manifest_path)],
    )
    assert result.exit_code == EXIT_CHANGES, result.output
