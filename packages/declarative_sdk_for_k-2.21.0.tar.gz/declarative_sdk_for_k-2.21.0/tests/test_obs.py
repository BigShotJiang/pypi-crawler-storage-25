"""Tests for DSK structured logging helpers."""

from __future__ import annotations

import json
import logging
import sys
from typing import Any

import pytest

import dsk._obs as obs
from dsk._obs import (
    JSONFormatter,
    configure_json_logging,
    get_correlation_id,
    log_event,
    set_correlation_id,
)


def _format(message: str, *, extra: dict[str, Any] | None = None) -> dict[str, Any]:
    record = logging.LogRecord("dsk.test", logging.INFO, __file__, 1, message, (), None)
    for key, value in (extra or {}).items():
        setattr(record, key, value)
    return json.loads(JSONFormatter().format(record))


def test_json_formatter_outputs_well_formed_json(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DSK_CORRELATION_ID", "corr-json")
    obs._CORRELATION_ID.set(None)

    payload = _format("hello")

    assert payload["message"] == "hello"
    assert payload["level"] == "info"
    assert payload["correlation_id"] == "corr-json"


def test_json_formatter_escapes_special_chars() -> None:
    payload = _format('line1\nquote " slash \\')

    encoded = json.dumps(payload)
    assert "\\n" in encoded
    assert payload["message"] == 'line1\nquote " slash \\'


def test_json_formatter_redacts_known_secret_fields() -> None:
    payload = _format("event", extra={"api_key": "sk-testSECRETSECRETSECRET", "safe": "visible"})

    assert payload["api_key"] == "<redacted>"
    assert payload["safe"] == "visible"


def test_env_log_level_respects_dsk_log_level(monkeypatch: pytest.MonkeyPatch) -> None:
    logger = logging.getLogger("dsk")
    logger.handlers.clear()
    monkeypatch.setenv("DSK_JSON_LOGS", "1")
    monkeypatch.setenv("DSK_LOG_LEVEL", "DEBUG")

    configure_json_logging()

    assert logger.level == logging.DEBUG
    logger.handlers.clear()


def test_env_log_level_falls_back_to_info(monkeypatch: pytest.MonkeyPatch) -> None:
    logger = logging.getLogger("dsk")
    logger.handlers.clear()
    monkeypatch.setenv("DSK_JSON_LOGS", "1")
    monkeypatch.setenv("DSK_LOG_LEVEL", "not-a-level")

    configure_json_logging()

    assert logger.level == logging.INFO
    logger.handlers.clear()


def test_correlation_id_propagates_through_nested_calls() -> None:
    set_correlation_id("outer-correlation")

    def nested() -> str:
        return get_correlation_id()

    assert nested() == "outer-correlation"


def test_correlation_id_generates_when_absent(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("DSK_CORRELATION_ID", raising=False)
    obs._CORRELATION_ID.set(None)

    generated = get_correlation_id()

    assert generated
    assert get_correlation_id() == generated


def test_log_event_includes_correlation_id(caplog: pytest.LogCaptureFixture) -> None:
    set_correlation_id("event-correlation")
    logger = logging.getLogger("dsk.test.event")

    with caplog.at_level(logging.INFO, logger="dsk.test.event"):
        log_event(logger, "unit.event", subject="value")

    assert caplog.records[0].correlation_id == "event-correlation"
    assert caplog.records[0].subject == "value"


def test_nested_secret_records_are_redacted() -> None:
    payload = _format(
        "nested", extra={"record": {"password": "hunter2", "child": {"token": "abc"}}}
    )

    assert payload["record"]["password"] == "<redacted>"
    assert payload["record"]["child"]["token"] == "<redacted>"


def test_json_formatter_redacts_event_exception_and_repr() -> None:
    class SecretRepr:
        def __repr__(self) -> str:
            return "SecretRepr(token=abc123)"

    record = logging.LogRecord("dsk.test", logging.ERROR, __file__, 1, "boom", (), None)
    record.event = "api_key=abc123"
    record.obj = SecretRepr()
    try:
        raise RuntimeError("failed")
    except RuntimeError:
        record.exc_info = sys.exc_info()

    payload = json.loads(JSONFormatter().format(record))

    assert payload["event"] == "<redacted>"
    assert payload["obj"] == "SecretRepr(<redacted>"
    assert "RuntimeError" in payload["exc_info"]


def test_configure_json_logging_is_idempotent(monkeypatch: pytest.MonkeyPatch) -> None:
    logger = logging.getLogger("dsk")
    logger.handlers.clear()
    monkeypatch.setenv("DSK_JSON_LOGS", "1")

    configure_json_logging()
    configure_json_logging()

    assert (
        sum(1 for handler in logger.handlers if getattr(handler, "_dsk_json_handler", False)) == 1
    )
    logger.handlers.clear()
