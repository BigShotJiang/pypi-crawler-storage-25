"""Tests for ITSM approval gate manifest models."""

from pathlib import Path

import yaml


def test_itsm_defaults():
    from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1

    m = ItsmApprovalGateManifestV1(**{"schema": "itsm-approval-gate.v1", "name": "test"})
    assert m.schema_ == "itsm-approval-gate.v1"
    assert m.gates == []
    assert m.default_gate is None


def test_itsm_round_trip():
    from dsk.core.models_itsm_gate import (
        ItsmApprovalGateManifestV1,
        ItsmChangeCategory,
        ItsmGatePolicy,
        ItsmPlatform,
    )

    example = Path(__file__).parent.parent / "examples/itsm_gate/acme-itsm-approval.yaml"
    data = yaml.safe_load(example.read_text())
    manifest = ItsmApprovalGateManifestV1(**data)
    assert manifest.schema_ == "itsm-approval-gate.v1"
    assert manifest.default_gate == "prod-snow"
    assert len(manifest.gates) == 3
    prod = manifest.gates[0]
    assert prod.platform == ItsmPlatform.servicenow
    assert prod.change_category == ItsmChangeCategory.normal
    assert prod.auto_create_ticket is False
    dev = manifest.gates[2]
    assert dev.platform == ItsmPlatform.jira_sm
    assert dev.auto_create_ticket is True
    assert dev.policy == ItsmGatePolicy.block_on_pending


def test_itsm_gate_env_vars():
    from dsk.core.models_itsm_gate import ItsmApprovalGate, ItsmPlatform

    g = ItsmApprovalGate(name="test", platform=ItsmPlatform.servicenow)
    assert g.instance_url_env == "SERVICENOW_INSTANCE_URL"
    assert g.api_token_env == "ITSM_API_TOKEN"


def test_itsm_schema_alias():
    from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1

    m = ItsmApprovalGateManifestV1(**{"schema": "itsm-approval-gate.v1", "name": "t"})
    assert m.schema_ == "itsm-approval-gate.v1"


def test_itsm_gate_jira_env_names():
    """Jira SM gate keeps distinct default env var names for URL/token."""
    from dsk.core.models_itsm_gate import ItsmApprovalGate, ItsmPlatform

    g = ItsmApprovalGate(name="j", platform=ItsmPlatform.jira_sm)
    assert g.instance_url_env == "SERVICENOW_INSTANCE_URL"
    assert g.api_token_env == "ITSM_API_TOKEN"


def test_itsm_manifest_default_version_manager():
    """Root manifest defaults version and manager."""
    from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1

    m = ItsmApprovalGateManifestV1(**{"schema": "itsm-approval-gate.v1", "name": "root"})
    assert m.version == "1"
    assert m.manager == "dsk"


def test_itsm_gate_optional_ticket_template():
    """ticket_template may be null."""
    from dsk.core.models_itsm_gate import ItsmApprovalGate, ItsmPlatform

    g = ItsmApprovalGate(name="g", platform=ItsmPlatform.servicenow)
    assert g.ticket_template is None
