"""Offline coverage for SPIFFE runtime JWT-SVID validation."""

from __future__ import annotations

import base64
import json
import time
from pathlib import Path
from typing import Any
from unittest.mock import Mock, patch

import pytest
import yaml
from click.testing import CliRunner

from dsk.cli import main
from dsk.core.models_spiffe import SpiffeIdentityRule
from dsk.core.spiffe_runtime import (
    SpiffeRuleEvaluator,
    SpiffeRuntime,
    SpiffeRuntimeError,
)


def _manifest_doc(
    *,
    spiffe_id: str = "spiffe://acme.com/ns/prod/sa/ci-runner",
    match: str = "exact",
    allow_jit: bool = False,
    resource: str = "res.ci-secrets",
) -> dict[str, Any]:
    return {
        "schema": "spiffe-binding.v1",
        "name": "acme-spiffe",
        "trust_domain": "acme.com",
        "rules": [
            {
                "spiffe_id": spiffe_id,
                "match": match,
                "trust_domain": "acme.com",
                "resources": [{"uid_ref": resource, "role": "read", "ttl_seconds": 900}],
                "allow_jit": allow_jit,
            }
        ],
    }


def _jwt(sub: str, *, kid: str = "kid1", alg: str = "RS256") -> str:
    header = {"alg": alg, "kid": kid}
    payload = {"sub": sub, "exp": int(time.time()) + 600, "aud": ["dsk"]}
    return f"{_b64(header)}.{_b64(payload)}.sig"


def _b64(data: dict[str, Any]) -> str:
    raw = json.dumps(data, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def test_offline_verify_matches_exact_rule() -> None:
    token = _jwt("spiffe://acme.com/ns/prod/sa/ci-runner")

    result = SpiffeRuntime().verify_jwt_offline(token, _manifest_doc())

    assert result.offline_only is True
    assert result.spiffe_id == "spiffe://acme.com/ns/prod/sa/ci-runner"
    assert result.matched_rules == ["spiffe://acme.com/ns/prod/sa/ci-runner"]
    assert result.granted_resources == ["res.ci-secrets"]
    assert result.jit_required == []


def test_offline_verify_no_match() -> None:
    token = _jwt("spiffe://acme.com/ns/prod/sa/other")

    result = SpiffeRuntime().verify_jwt_offline(token, _manifest_doc())

    assert result.matched_rules == []
    assert result.granted_resources == []
    assert result.jit_required == []


def test_offline_verify_prefix_match() -> None:
    token = _jwt("spiffe://acme.com/ns/prod/sa/ci-runner")
    doc = _manifest_doc(
        spiffe_id="spiffe://acme.com/ns/prod/sa/",
        match="prefix",
        allow_jit=True,
        resource="res.db-prod",
    )

    result = SpiffeRuntime().verify_jwt_offline(token, doc)

    assert result.matched_rules == ["spiffe://acme.com/ns/prod/sa/"]
    assert result.granted_resources == ["res.db-prod"]
    assert result.jit_required == ["res.db-prod"]


def test_rule_evaluator_regex() -> None:
    rule = SpiffeIdentityRule(
        spiffe_id=r"spiffe://acme\.com/ns/.+/sa/ci-runner",
        match="regex",
        trust_domain="acme.com",
        resources=[{"uid_ref": "res.regex"}],
    )

    matched, resources, jit_required = SpiffeRuleEvaluator().match(
        "spiffe://acme.com/ns/prod/sa/ci-runner",
        [rule],
    )

    assert matched == [r"spiffe://acme\.com/ns/.+/sa/ci-runner"]
    assert resources == ["res.regex"]
    assert jit_required == []


def test_fetch_jwks_connection_refused() -> None:
    import dsk.core.spiffe_runtime as runtime_module

    runtime = SpiffeRuntime(jwks_url="http://127.0.0.1:1", timeout_seconds=0.01)
    if runtime_module.requests is None:
        with pytest.raises(SpiffeRuntimeError) as exc_info:
            runtime._fetch_jwks()
    else:
        with (
            patch(
                "dsk.core.spiffe_runtime.requests.get",
                side_effect=OSError("connection refused"),
            ),
            pytest.raises(SpiffeRuntimeError) as exc_info,
        ):
            runtime._fetch_jwks()

    assert "bootstrap.sh" in exc_info.value.next_action


def test_verify_jwt_live_mocked() -> None:
    pytest.importorskip("jwt")
    token = _jwt("spiffe://acme.com/ns/prod/sa/ci-runner")
    response = Mock()
    response.json.return_value = {"keys": [{"kid": "kid1", "alg": "RS256", "kty": "mock"}]}
    response.raise_for_status.return_value = None

    with (
        patch("dsk.core.spiffe_runtime.requests.get", return_value=response),
        patch(
            "dsk.core.spiffe_runtime.jwt.decode",
            return_value={
                "sub": "spiffe://acme.com/ns/prod/sa/ci-runner",
                "exp": int(time.time()) + 600,
            },
        ) as decode_mock,
    ):
        result = SpiffeRuntime().verify_jwt(token, _manifest_doc())

    assert result.offline_only is False
    assert result.matched_rules == ["spiffe://acme.com/ns/prod/sa/ci-runner"]
    decode_mock.assert_called_once()


def test_cli_spiffe_verify_offline(tmp_path: Path) -> None:
    manifest_path = tmp_path / "spiffe.yaml"
    manifest_path.write_text(yaml.safe_dump(_manifest_doc()), encoding="utf-8")
    token = _jwt("spiffe://acme.com/ns/prod/sa/ci-runner")

    result = CliRunner().invoke(
        main,
        ["spiffe-verify", str(manifest_path), "--offline", "--jwt", token, "--json"],
        catch_exceptions=False,
    )

    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert payload["matched_rules"] == ["spiffe://acme.com/ns/prod/sa/ci-runner"]
    assert payload["offline_only"] is True


def test_cli_spiffe_verify_no_match_offline(tmp_path: Path) -> None:
    manifest_path = tmp_path / "spiffe.yaml"
    manifest_path.write_text(yaml.safe_dump(_manifest_doc()), encoding="utf-8")
    token = _jwt("spiffe://acme.com/ns/prod/sa/other")

    result = CliRunner().invoke(
        main,
        ["spiffe-verify", str(manifest_path), "--offline", "--jwt", token, "--json"],
        catch_exceptions=False,
    )

    assert result.exit_code == 2, result.output
    assert json.loads(result.output)["matched_rules"] == []


def test_cli_spiffe_verify_rejects_oversized_jwt_file(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest_path = tmp_path / "spiffe.yaml"
    manifest_path.write_text(yaml.safe_dump(_manifest_doc()), encoding="utf-8")
    token_path = tmp_path / "token.jwt"
    token = _jwt("spiffe://acme.com/ns/prod/sa/ci-runner")
    token_path.write_text(token, encoding="utf-8")
    monkeypatch.setenv("DSK_CLI_MAX_JWT_FILE_BYTES", str(len(token.encode("utf-8")) - 1))

    result = CliRunner().invoke(
        main,
        ["spiffe-verify", str(manifest_path), "--offline", "--jwt-file", str(token_path)],
        catch_exceptions=False,
    )

    assert result.exit_code == 1
    assert "DSK_CLI_MAX_JWT_FILE_BYTES" in result.output
