"""Offline coverage for ``dsk report ksm-usage``."""

from __future__ import annotations

import importlib
import json
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli._report.ksm_usage import render_ksm_usage_table, run_ksm_usage_report
from dsk.cli.main import EXIT_GENERIC
from dsk.core.errors import CapabilityError
from dsk.providers import KsmMockProvider

cli_main_module = importlib.import_module("dsk.cli.main")

MANIFEST_NAME = "ksm-usage"
API_APP_UID = "AaBbCcDdEeFfGgHhIiJjKk"
WORKER_APP_UID = "ZzYyXxWwVvUuTtSsRrQqPp"


def _run(args: list[str]):
    return CliRunner().invoke(main, args, catch_exceptions=False)


def _seeded_provider() -> KsmMockProvider:
    provider = KsmMockProvider(MANIFEST_NAME)
    provider.seed_ksm_state(
        {
            "apps": [
                {
                    "uid_ref": "app.api",
                    "name": "API Service",
                    "keeper_uid": API_APP_UID,
                },
                {
                    "uid_ref": "app.worker",
                    "name": "Worker Service",
                    "keeper_uid": WORKER_APP_UID,
                },
            ],
            "tokens": [],
            "record_shares": [
                {
                    "app_uid_ref": "keeper-ksm:apps:app.api",
                    "record_uid_ref": "keeper-vault:records:record.db",
                    "editable": True,
                },
                {
                    "app_uid_ref": "keeper-ksm:apps:app.api",
                    "record_uid_ref": "keeper-vault:records:record.cache",
                    "editable": False,
                },
                {
                    "app_uid_ref": "keeper-ksm:apps:app.worker",
                    "record_uid_ref": "keeper-vault:records:record.queue",
                    "editable": False,
                },
            ],
            "config_outputs": [],
        }
    )
    return provider


def _install_provider(monkeypatch: pytest.MonkeyPatch, provider: KsmMockProvider) -> None:
    monkeypatch.setattr(cli_main_module, "KsmMockProvider", lambda _manifest_name: provider)


def test_ksm_usage_empty_mock_state_renders_empty_table() -> None:
    result = _run(["report", "ksm-usage"])

    assert result.exit_code == 0, result.output
    assert "KSM Usage" in result.output
    assert "Application" in result.output
    assert "0 apps, 0 keys" in result.output


def test_ksm_usage_table_shows_apps_and_key_counts(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_provider(monkeypatch, _seeded_provider())

    result = _run(["report", "ksm-usage"])

    assert result.exit_code == 0, result.output
    assert "2 apps, 3 keys" in result.output
    api_line = next(line for line in result.output.splitlines() if "API Service" in line)
    worker_line = next(line for line in result.output.splitlines() if "Worker Service" in line)
    assert "2" in api_line
    assert "1" in worker_line


def test_ksm_usage_json_flag_emits_apps_and_total_keys(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_provider(monkeypatch, _seeded_provider())

    result = _run(["report", "ksm-usage", "--json"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert set(payload) >= {"apps", "total_keys"}
    assert payload["total_keys"] == 3
    assert [app["name"] for app in payload["apps"]] == ["API Service", "Worker Service"]


def test_ksm_usage_sanitize_uids_fingerprints_app_uids(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_provider(monkeypatch, _seeded_provider())

    result = _run(["report", "ksm-usage", "--json", "--sanitize-uids"])

    assert result.exit_code == 0, result.output
    assert API_APP_UID not in result.output
    assert WORKER_APP_UID not in result.output
    payload = json.loads(result.output)
    assert all(app["app_uid"].startswith("<uid:") for app in payload["apps"])


def test_ksm_usage_commander_ksm_unavailable_returns_empty_warning(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_run_keeper_batch(_argv: list[str], **_kwargs: Any) -> str:
        raise CapabilityError(
            reason="Commander KSM discovery unavailable",
            next_action="configure Commander before live KSM usage discovery",
        )

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", fake_run_keeper_batch)

    result = _run(["--provider", "commander", "report", "ksm-usage", "--json"])

    assert result.exit_code == 0, result.output
    assert json.loads(result.output) == {
        "apps": [],
        "total_keys": 0,
        "warning": "ksm_unavailable",
    }


def test_ksm_usage_unexpected_commander_error_exits_generic(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_run_keeper_batch(_argv: list[str], **_kwargs: Any) -> str:
        raise RuntimeError("Commander transport broke")

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", fake_run_keeper_batch)

    result = _run(["--provider", "commander", "report", "ksm-usage"])

    assert result.exit_code == EXIT_GENERIC, result.output
    assert "unexpected Commander error" in result.output
    assert "Commander transport broke" in result.output


def test_ksm_usage_quiet_json_fingerprints_app_uids_and_exits_ok(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """dsk report ksm-usage --quiet --json → exit 0, fingerprinted app_uid values."""
    _install_provider(monkeypatch, _seeded_provider())

    result = _run(["report", "ksm-usage", "--quiet", "--json"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert set(payload) >= {"apps", "total_keys"}
    # All app_uid values must be fingerprinted, not raw UIDs
    for app in payload["apps"]:
        uid = app.get("app_uid")
        assert uid is None or uid.startswith("<uid:"), f"app_uid not fingerprinted: {uid}"
    # Raw UIDs must not appear in output
    assert API_APP_UID not in result.output
    assert WORKER_APP_UID not in result.output
    # Table must be suppressed when --quiet is set with --json
    assert "KSM Usage" not in result.output


def test_run_ksm_usage_report_empty_state_full_envelope() -> None:
    class EmptyKsmProvider:
        def discover_ksm_state(self) -> dict[str, Any]:
            return {"apps": [], "record_shares": [], "tokens": []}

    payload = run_ksm_usage_report(provider=EmptyKsmProvider())
    assert payload["dsk_report_version"] == 1
    assert payload["command"] == "ksm-usage"
    assert payload["apps"] == []
    assert payload["total_keys"] == 0
    assert set(payload["meta"].keys()) >= {"source", "sanitize_uids"}
    assert payload["meta"]["source"] == "mock"


def test_run_ksm_usage_report_discover_ksm_apps_counts_keys() -> None:
    class AppsProvider:
        def discover_ksm_apps(self) -> list[dict[str, Any]]:
            return [
                {"name": "Alpha", "app_uid": "uid-a", "keys": ["k1", "k2"]},
                {"title": "Beta", "uid": "uid-b", "record_count": 4},
            ]

    payload = run_ksm_usage_report(provider=AppsProvider())
    assert len(payload["apps"]) == 2
    assert payload["total_keys"] == 6
    names = sorted(app["name"] for app in payload["apps"])
    assert names == ["Alpha", "Beta"]


def test_run_ksm_usage_report_provider_without_discovery_raises() -> None:
    with pytest.raises(CapabilityError, match="does not expose KSM app discovery"):
        run_ksm_usage_report(provider=object())


def test_run_ksm_usage_report_discover_ksm_apps_non_list_raises() -> None:
    class BadAppsProvider:
        def discover_ksm_apps(self) -> str:
            return "not-a-list"

    with pytest.raises(CapabilityError, match="non-list app rows"):
        run_ksm_usage_report(provider=BadAppsProvider())


def test_run_ksm_usage_report_discover_ksm_state_non_mapping_raises() -> None:
    class BadStateProvider:
        def discover_ksm_state(self) -> list[Any]:
            return []

    with pytest.raises(CapabilityError, match="non-object state"):
        run_ksm_usage_report(provider=BadStateProvider())


def test_run_ksm_usage_commander_non_json_returns_unavailable_envelope(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Commander path maps discovery CapabilityError (incl. bad JSON) to empty warning."""

    def fake_run_keeper_batch(_argv: list[str], **_kwargs: Any) -> str:
        return "%%% no json anywhere"

    monkeypatch.setattr("dsk.cli._report.runner.run_keeper_batch", fake_run_keeper_batch)
    payload = run_ksm_usage_report(provider=None)
    assert payload == {
        "apps": [],
        "total_keys": 0,
        "warning": "ksm_unavailable",
    }


def test_render_ksm_usage_table_shows_apps_and_footer_totals() -> None:
    text = render_ksm_usage_table(
        {
            "apps": [
                {
                    "name": "Svc One",
                    "app_uid": "u1",
                    "key_count": 2,
                    "last_access_at": "2026-01-01T00:00:00Z",
                }
            ],
            "total_keys": 2,
        }
    )
    assert "KSM Usage" in text
    assert "Svc One" in text
    assert "1 apps, 2 keys" in text


def test_apps_from_commander_list_input() -> None:
    """_apps_from_commander handles list JSON from Commander."""
    import json

    from dsk.cli._report.ksm_usage import _apps_from_commander

    raw = json.dumps([{"uid": "app1", "name": "TestApp", "client_count": 2}])
    apps = _apps_from_commander(raw)
    assert len(apps) == 1
    assert apps[0]["name"] == "TestApp"


def test_apps_from_commander_dict_input() -> None:
    """_apps_from_commander handles dict JSON with 'applications' key."""
    import json

    from dsk.cli._report.ksm_usage import _apps_from_commander

    raw = json.dumps({"applications": [{"uid": "app2", "name": "App2"}]})
    apps = _apps_from_commander(raw)
    assert len(apps) == 1


def test_apps_from_commander_raises_on_non_json() -> None:
    """_apps_from_commander raises CapabilityError on non-JSON input."""
    import pytest

    from dsk.cli._report.ksm_usage import _apps_from_commander
    from dsk.core.errors import CapabilityError

    with pytest.raises(CapabilityError):
        _apps_from_commander("not json at all")


def test_first_list_value_returns_first_match() -> None:
    """_first_list_value returns first matching key's list value."""
    from dsk.cli._report.ksm_usage import _first_list_value

    data = {"items": ["a", "b"], "rows": ["c"]}
    result = _first_list_value(data, ("applications", "items", "rows"))
    assert result == ["a", "b"]


def test_first_list_value_returns_none_when_no_match() -> None:
    """_first_list_value returns None when no key matches."""
    from dsk.cli._report.ksm_usage import _first_list_value

    data = {"other": "not a list"}
    result = _first_list_value(data, ("applications", "apps"))
    assert result is None
