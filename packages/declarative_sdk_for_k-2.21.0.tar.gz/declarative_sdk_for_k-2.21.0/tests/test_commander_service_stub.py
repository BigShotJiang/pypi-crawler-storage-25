"""Tests for the Wave 1 CommanderLibraryProvider stub.

Verifies that the stub interface exists, raises NotImplementedError correctly,
and that the gate conditions are documented.
"""

from __future__ import annotations

import sys

import pytest

from dsk.providers.commander_library_provider import (
    _WAVE_1_GATE_CONDITIONS,
    CommanderLibraryProvider,
)


def test_instantiation_raises_not_implemented() -> None:
    """Constructing the stub must raise NotImplementedError immediately."""
    with pytest.raises(NotImplementedError):
        CommanderLibraryProvider(api_key="token")


def test_wave1_gate_conditions_listed() -> None:
    """At least 4 gate conditions must be documented in _WAVE_1_GATE_CONDITIONS."""
    assert len(_WAVE_1_GATE_CONDITIONS) >= 4


def test_module_docstring_mentions_wave1() -> None:
    """The provider module docstring must mention Wave 1 gate list or Wave 2 scaffold."""
    module = sys.modules[CommanderLibraryProvider.__module__]
    assert module.__doc__ is not None, "Module is missing a docstring"
    doc = module.__doc__.lower()
    assert "wave 1" in doc or "wave 2" in doc or "scaffold" in doc
