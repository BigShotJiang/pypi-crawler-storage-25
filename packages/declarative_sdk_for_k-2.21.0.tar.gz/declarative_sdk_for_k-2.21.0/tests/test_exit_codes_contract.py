"""AGENTS.md exit-code contract (Lurey #4) — focused CLI red paths."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_CHANGES, EXIT_CONFLICT, EXIT_GENERIC, EXIT_SCHEMA
from dsk.providers.mock import MockProvider


def _run(args: list[str], *, catch_exceptions: bool = False):
    runner = CliRunner()
    return runner.invoke(main, args, catch_exceptions=catch_exceptions)


def test_exit_generic_malformed_export_json(tmp_path: Path) -> None:
    """EXIT_GENERIC (1): unexpected failure — export on invalid JSON (no try/except in command)."""
    bad = tmp_path / "not-json.json"
    bad.write_text("not valid json {", encoding="utf-8")
    # Click maps uncaught exceptions to exit code 1 when exceptions are caught by the runner.
    result = _run(["export", str(bad)], catch_exceptions=True)
    assert result.exit_code == EXIT_GENERIC
    assert result.exception is not None


def test_exit_schema_validate_invalid_manifest(invalid_manifest) -> None:
    """EXIT_SCHEMA (2): validate rejects schema-invalid PAM manifest."""
    path = invalid_manifest("rbi-rotation-on.yaml")
    result = _run(["validate", str(path)])
    assert result.exit_code == EXIT_SCHEMA
    err = result.stderr or result.output
    assert "validation failed" in err


def test_exit_changes_plan_has_work(tmp_path: Path) -> None:
    """EXIT_CHANGES (2): plan with actionable work uses same numeric exit as schema failures."""
    manifest = tmp_path / "vault-one.yaml"
    manifest.write_text(
        "schema: keeper-vault.v1\n"
        "records:\n"
        "  - uid_ref: cli.v.login\n"
        "    type: login\n"
        "    title: CLI Vault Login\n",
        encoding="utf-8",
    )
    result = _run(["--provider", "mock", "plan", str(manifest), "--json"])
    assert result.exit_code == EXIT_CHANGES, result.output
    doc = json.loads(result.output)
    s = doc["summary"]
    assert s["create"] + s["update"] + s["delete"] > 0


def test_exit_conflict_plan_rotation_capability_row(
    aws_manifest_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """EXIT_CONFLICT (4): provider capability gap surfaces as plan conflict (rotation_settings in manifest)."""
    monkeypatch.setattr(
        MockProvider,
        "unsupported_capabilities",
        lambda self, _m=None: [
            "rotation_settings is not implemented (Commander hook: `pam rotation edit --schedulejson / --schedulecron`)"
        ],
    )
    result = _run(["--provider", "mock", "plan", str(aws_manifest_path), "--json"])
    assert result.exit_code == EXIT_CONFLICT, result.output
    doc = json.loads(result.output)
    caps = [
        c for c in doc["changes"] if c["kind"] == "conflict" and c["resource_type"] == "capability"
    ]
    assert len(caps) >= 1
    assert "rotation_settings" in (caps[0].get("reason") or "")
