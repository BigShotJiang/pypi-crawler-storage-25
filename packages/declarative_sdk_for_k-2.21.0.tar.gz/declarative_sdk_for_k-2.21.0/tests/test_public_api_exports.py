import dsk


def test_all_exports_importable() -> None:
    for name in dsk.__all__:
        assert hasattr(dsk, name), f"{name} in __all__ but not importable from dsk"


def test_version_present() -> None:
    assert hasattr(dsk, "__version__")
    assert dsk.__version__ == "2.21.0"


def test_shim_module_exposes_eight_absorption_verbs_plus_extras() -> None:
    from dsk import shim

    expected_absorption_verbs = {
        "adopt",
        "plan",
        "apply",
        "diff",
        "audit_explain",
        "drift_watch",
        "rehearse_report",
        "bundle",
    }
    actual = {
        name
        for name in dir(shim)
        if not name.startswith("_") and callable(getattr(shim, name, None))
    }
    missing = expected_absorption_verbs - actual
    assert not missing, f"dsk.shim missing absorption verbs: {missing}"


def test_deprecated_shim_aliases_present() -> None:
    from dsk import shim

    for alias in {"import_from_keepercmd", "audit"}:
        assert hasattr(shim, alias), f"dsk.shim missing deprecated alias {alias}"


def test_shim_optional_standalone_verbs_present() -> None:
    """Verify the standalone-only verbs stay in dsk.shim."""

    from dsk import shim

    standalone_verbs = {"shim_info", "verify", "discover"}
    for verb in standalone_verbs:
        assert hasattr(shim, verb), f"dsk.shim missing standalone verb {verb}"


def test_manifest_schemas_top_level_importable() -> None:
    """The 4 declarative manifest schemas are top-level for absorption."""

    expected = {"VaultManifestV1", "SharingManifestV1", "KsmManifestV1", "PolicyManifestV1"}
    for name in expected:
        assert hasattr(dsk, name), f"Top-level manifest schema {name} not importable from dsk"
