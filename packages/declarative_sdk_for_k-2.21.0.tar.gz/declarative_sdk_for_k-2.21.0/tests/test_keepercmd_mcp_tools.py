"""Tests for Phase 4-D KeeperMigrate MCP tools.

All subprocess calls are mocked — keeper-migrate need not be installed.
run_dir fixtures use tmp_path to satisfy the guard checks for required files.
"""

from __future__ import annotations

import asyncio
import json
import subprocess
from pathlib import Path
from subprocess import CompletedProcess
from unittest.mock import patch

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

REPO_ROOT = Path(__file__).resolve().parents[1]


def _fake_completed(
    returncode: int = 0, stdout: str = "", stderr: str = ""
) -> CompletedProcess[str]:
    return CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr=stderr)


def _run(coro):  # type: ignore[no-untyped-def]
    return asyncio.run(coro)


def _make_verify_run_dir(tmp_path: Path) -> Path:
    """Create a minimal run_dir with the files verify requires."""
    (tmp_path / "inventory.json").write_text('{"schema_version": "1.0"}', encoding="utf-8")
    (tmp_path / "target_state.json").write_text('{"entities": []}', encoding="utf-8")
    return tmp_path


def _make_structure_run_dir(tmp_path: Path) -> Path:
    """Create a minimal run_dir with the files structure requires."""
    (tmp_path / "inventory.json").write_text('{"schema_version": "1.0"}', encoding="utf-8")
    return tmp_path


def _make_records_import_run_dir(tmp_path: Path) -> Path:
    """Create a minimal run_dir with the files records-import requires."""
    (tmp_path / "inventory.json").write_text('{"schema_version": "1.0"}', encoding="utf-8")
    return tmp_path


# ---------------------------------------------------------------------------
# keeper_migrate_verify — error paths (missing files return early before subprocess)
# ---------------------------------------------------------------------------


def test_verify_missing_inventory_returns_error(tmp_path: Path) -> None:
    """verify returns error JSON when inventory.json is absent (no subprocess call)."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_verify

    result = _run(keeper_migrate_verify(run_dir=str(tmp_path)))
    data = json.loads(result)
    assert "error" in data
    assert "inventory.json" in data["error"]


def test_verify_missing_target_state_returns_error(tmp_path: Path) -> None:
    """verify returns error JSON when target_state.json is absent."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_verify

    (tmp_path / "inventory.json").write_text("{}", encoding="utf-8")
    result = _run(keeper_migrate_verify(run_dir=str(tmp_path)))
    data = json.loads(result)
    assert "error" in data
    assert "target_state.json" in data["error"]


# ---------------------------------------------------------------------------
# keeper_migrate_verify — subprocess paths (files present, subprocess mocked)
# ---------------------------------------------------------------------------


def test_verify_tool_keeper_migrate_not_found(tmp_path: Path) -> None:
    """FileNotFoundError from subprocess is caught and returned as error JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_verify

    _make_verify_run_dir(tmp_path)

    with patch("subprocess.run", side_effect=FileNotFoundError("no such file")):
        result = _run(keeper_migrate_verify(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert "error" in data
    assert "keeper-migrate" in data["error"]


def test_verify_tool_timeout(tmp_path: Path) -> None:
    """TimeoutExpired from subprocess is caught and returned as error JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_verify

    _make_verify_run_dir(tmp_path)

    with patch(
        "subprocess.run",
        side_effect=subprocess.TimeoutExpired(cmd="keeper-migrate", timeout=300),
    ):
        result = _run(keeper_migrate_verify(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert "error" in data
    assert "timed out" in data["error"]


def test_verify_tool_nonzero_exit(tmp_path: Path) -> None:
    """Non-zero exit code → passed=False in result."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_verify

    _make_verify_run_dir(tmp_path)
    fake = _fake_completed(returncode=1, stdout="", stderr="verify failed")

    with patch("subprocess.run", return_value=fake):
        result = _run(keeper_migrate_verify(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert data["passed"] is False
    assert data["exit_code"] == 1


def test_verify_tool_success_with_csv_rows(tmp_path: Path) -> None:
    """Passing verify call with CSV rows → passed=True, rows populated."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_verify

    _make_verify_run_dir(tmp_path)
    csv_content = "check,status,detail\nsanity,pass,ok\nschema,pass,all good\n"

    def fake_run(args, **kwargs):  # type: ignore[no-untyped-def]
        output_idx = args.index("--output") + 1
        Path(args[output_idx]).write_text(csv_content, encoding="utf-8")
        return _fake_completed(returncode=0)

    with patch("subprocess.run", side_effect=fake_run):
        result = _run(keeper_migrate_verify(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert data["passed"] is True
    assert len(data["rows"]) == 2
    assert data["summary"]["total"] == 2
    assert data["summary"]["pass"] == 2
    assert data["summary"]["fail"] == 0


# ---------------------------------------------------------------------------
# keeper_migrate_structure
# ---------------------------------------------------------------------------


def test_structure_tool_defaults_to_dry_run(tmp_path: Path) -> None:
    """--dry-run is included in subprocess args when dry_run=True (default)."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_structure

    _make_structure_run_dir(tmp_path)
    captured_args: list[list[str]] = []

    def spy_run(args, **kwargs):  # type: ignore[no-untyped-def]
        captured_args.append(list(args))
        return _fake_completed(returncode=0, stdout="structure ok")

    with patch("subprocess.run", side_effect=spy_run):
        _run(keeper_migrate_structure(run_dir=str(tmp_path)))

    assert captured_args, "subprocess.run was not called"
    assert "--dry-run" in captured_args[0]
    assert "--inventory" in captured_args[0]


def test_structure_tool_no_dry_run_when_false(tmp_path: Path) -> None:
    """--dry-run is absent when dry_run=False."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_structure

    _make_structure_run_dir(tmp_path)
    captured_args: list[list[str]] = []

    def spy_run(args, **kwargs):  # type: ignore[no-untyped-def]
        captured_args.append(list(args))
        return _fake_completed(returncode=0, stdout="structure ok")

    with patch("subprocess.run", side_effect=spy_run):
        _run(keeper_migrate_structure(run_dir=str(tmp_path), dry_run=False))

    assert captured_args, "subprocess.run was not called"
    assert "--dry-run" not in captured_args[0]


def test_structure_tool_returns_exit_code_and_stdout_tail(tmp_path: Path) -> None:
    """Returns exit_code and stdout_tail in result JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_structure

    _make_structure_run_dir(tmp_path)
    fake = _fake_completed(returncode=0, stdout="all done\n")

    with patch("subprocess.run", return_value=fake):
        result = _run(keeper_migrate_structure(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert data["exit_code"] == 0
    assert "stdout_tail" in data
    assert data["dry_run"] is True


def test_structure_tool_keeper_migrate_not_found(tmp_path: Path) -> None:
    """FileNotFoundError → error JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_structure

    _make_structure_run_dir(tmp_path)

    with patch("subprocess.run", side_effect=FileNotFoundError):
        result = _run(keeper_migrate_structure(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert "error" in data


# ---------------------------------------------------------------------------
# keeper_migrate_records_import
# ---------------------------------------------------------------------------


def test_records_import_tool_defaults_to_dry_run(tmp_path: Path) -> None:
    """--dry-run is included in subprocess args when dry_run=True (default)."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_records_import

    _make_records_import_run_dir(tmp_path)
    captured_args: list[list[str]] = []

    def spy_run(args, **kwargs):  # type: ignore[no-untyped-def]
        captured_args.append(list(args))
        return _fake_completed(returncode=0, stdout="created=0 skipped=0 errors=0")

    with patch("subprocess.run", side_effect=spy_run):
        _run(keeper_migrate_records_import(run_dir=str(tmp_path)))

    assert captured_args, "subprocess.run was not called"
    assert "--dry-run" in captured_args[0]
    assert "--input" in captured_args[0]


def test_records_import_tool_parses_counts(tmp_path: Path) -> None:
    """Regex parsing extracts created/skipped/errors from stdout."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_records_import

    _make_records_import_run_dir(tmp_path)
    stdout = "Import finished: created=42 skipped=7 errors=3\n"
    fake = _fake_completed(returncode=0, stdout=stdout)

    with patch("subprocess.run", return_value=fake):
        result = _run(keeper_migrate_records_import(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert data["created"] == 42
    assert data["skipped"] == 7
    assert data["errors"] == 3


def test_records_import_tool_counts_zero_when_absent(tmp_path: Path) -> None:
    """Counts default to 0 when not present in stdout."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_records_import

    _make_records_import_run_dir(tmp_path)
    fake = _fake_completed(returncode=0, stdout="dry-run: no changes made")

    with patch("subprocess.run", return_value=fake):
        result = _run(keeper_migrate_records_import(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert data["created"] == 0
    assert data["skipped"] == 0
    assert data["errors"] == 0


def test_records_import_tool_keeper_migrate_not_found(tmp_path: Path) -> None:
    """FileNotFoundError → error JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_records_import

    _make_records_import_run_dir(tmp_path)

    with patch("subprocess.run", side_effect=FileNotFoundError):
        result = _run(keeper_migrate_records_import(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert "error" in data


def test_records_import_prefers_records_import_json_over_inventory(tmp_path: Path) -> None:
    """records_import.json (from keeper-migrate convert) is preferred over inventory.json."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_records_import

    _make_records_import_run_dir(tmp_path)
    bundle = tmp_path / "records_import.json"
    bundle.write_text('{"records": []}', encoding="utf-8")

    captured_args: list[list[str]] = []

    def spy_run(args, **kwargs):  # type: ignore[no-untyped-def]
        captured_args.append(list(args))
        return _fake_completed(returncode=0, stdout="created=0")

    with patch("subprocess.run", side_effect=spy_run):
        _run(keeper_migrate_records_import(run_dir=str(tmp_path)))

    assert captured_args
    input_idx = captured_args[0].index("--input") + 1
    assert captured_args[0][input_idx] == str(bundle)


# ---------------------------------------------------------------------------
# keeper_migrate_convert
# ---------------------------------------------------------------------------


def _make_convert_run_dir(tmp_path: Path) -> Path:
    """Create a minimal run_dir with the records_export subdir convert requires."""
    records_export = tmp_path / "records_export"
    records_export.mkdir()
    (records_export / "records.json").write_text('{"records": []}', encoding="utf-8")
    return tmp_path


def test_convert_missing_run_dir_returns_error(tmp_path: Path) -> None:
    """convert returns error JSON when run_dir does not exist."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_convert

    nonexistent = tmp_path / "no_such_dir"
    result = _run(keeper_migrate_convert(run_dir=str(nonexistent)))
    data = json.loads(result)
    assert "error" in data
    assert "run_dir" in data["error"]


def test_convert_missing_records_export_returns_error(tmp_path: Path) -> None:
    """convert returns error JSON when records_export subdir is absent."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_convert

    result = _run(keeper_migrate_convert(run_dir=str(tmp_path)))
    data = json.loads(result)
    assert "error" in data
    assert "records_export" in data["error"]


def test_convert_default_output_path(tmp_path: Path) -> None:
    """When output is omitted, default is <run_dir>/records_import.json."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_convert

    _make_convert_run_dir(tmp_path)
    captured_args: list[list[str]] = []

    def spy_run(args, **kwargs):  # type: ignore[no-untyped-def]
        captured_args.append(list(args))
        return _fake_completed(returncode=0, stdout="convert ok")

    with patch("subprocess.run", side_effect=spy_run):
        result = _run(keeper_migrate_convert(run_dir=str(tmp_path)))

    assert captured_args, "subprocess.run was not called"
    output_idx = captured_args[0].index("--output") + 1
    assert captured_args[0][output_idx] == str(tmp_path / "records_import.json")
    data = json.loads(result)
    assert data["exit_code"] == 0
    assert "records_import.json" in data["output"]


def test_convert_explicit_output_path(tmp_path: Path) -> None:
    """Explicit output path is passed through to keeper-migrate convert."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_convert

    _make_convert_run_dir(tmp_path)
    explicit_output = str(tmp_path / "custom_output.json")
    captured_args: list[list[str]] = []

    def spy_run(args, **kwargs):  # type: ignore[no-untyped-def]
        captured_args.append(list(args))
        return _fake_completed(returncode=0, stdout="convert ok")

    with patch("subprocess.run", side_effect=spy_run):
        result = _run(keeper_migrate_convert(run_dir=str(tmp_path), output=explicit_output))

    assert captured_args
    output_idx = captured_args[0].index("--output") + 1
    assert captured_args[0][output_idx] == explicit_output
    data = json.loads(result)
    assert data["output"] == explicit_output


def test_convert_input_dir_points_to_records_export(tmp_path: Path) -> None:
    """--input-dir must point at <run_dir>/records_export."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_convert

    _make_convert_run_dir(tmp_path)
    captured_args: list[list[str]] = []

    def spy_run(args, **kwargs):  # type: ignore[no-untyped-def]
        captured_args.append(list(args))
        return _fake_completed(returncode=0, stdout="convert ok")

    with patch("subprocess.run", side_effect=spy_run):
        _run(keeper_migrate_convert(run_dir=str(tmp_path)))

    assert captured_args
    input_idx = captured_args[0].index("--input-dir") + 1
    assert captured_args[0][input_idx] == str(tmp_path / "records_export")


def test_convert_keeper_migrate_not_found(tmp_path: Path) -> None:
    """FileNotFoundError → error JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_convert

    _make_convert_run_dir(tmp_path)

    with patch("subprocess.run", side_effect=FileNotFoundError):
        result = _run(keeper_migrate_convert(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert "error" in data
    assert "keeper-migrate" in data["error"]


def test_convert_timeout(tmp_path: Path) -> None:
    """TimeoutExpired → error JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_convert

    _make_convert_run_dir(tmp_path)

    with patch(
        "subprocess.run",
        side_effect=subprocess.TimeoutExpired(cmd="keeper-migrate", timeout=300),
    ):
        result = _run(keeper_migrate_convert(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert "error" in data
    assert "timed out" in data["error"]


# ---------------------------------------------------------------------------
# keeper_migrate_audit_verify
# ---------------------------------------------------------------------------


def _make_audit_verify_run_dir(tmp_path: Path) -> Path:
    """Create a minimal run_dir with audit.log that audit-verify requires."""
    (tmp_path / "audit.log").write_text("audit log line 1\naudit log line 2\n", encoding="utf-8")
    return tmp_path


def test_audit_verify_missing_audit_log_returns_error(tmp_path: Path) -> None:
    """audit-verify returns error JSON when audit.log is absent."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_audit_verify

    result = _run(keeper_migrate_audit_verify(run_dir=str(tmp_path)))
    data = json.loads(result)
    assert "error" in data
    assert "audit.log" in data["error"]


def test_audit_verify_passes_directory_flag(tmp_path: Path) -> None:
    """--directory is passed with run_dir value to keeper-migrate audit-verify."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_audit_verify

    _make_audit_verify_run_dir(tmp_path)
    captured_args: list[list[str]] = []

    def spy_run(args, **kwargs):  # type: ignore[no-untyped-def]
        captured_args.append(list(args))
        return _fake_completed(returncode=0, stdout="verification passed")

    with patch("subprocess.run", side_effect=spy_run):
        result = _run(keeper_migrate_audit_verify(run_dir=str(tmp_path)))

    assert captured_args
    assert "audit-verify" in captured_args[0]
    dir_idx = captured_args[0].index("--directory") + 1
    assert captured_args[0][dir_idx] == str(tmp_path)
    data = json.loads(result)
    assert data["verification_passed"] is True
    assert data["exit_code"] == 0


def test_audit_verify_nonzero_exit_sets_verification_passed_false(tmp_path: Path) -> None:
    """Non-zero exit code → verification_passed=False."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_audit_verify

    _make_audit_verify_run_dir(tmp_path)
    fake = _fake_completed(returncode=1, stdout="", stderr="hash mismatch")

    with patch("subprocess.run", return_value=fake):
        result = _run(keeper_migrate_audit_verify(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert data["verification_passed"] is False
    assert data["exit_code"] == 1


def test_audit_verify_keeper_migrate_not_found(tmp_path: Path) -> None:
    """FileNotFoundError → error JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_audit_verify

    _make_audit_verify_run_dir(tmp_path)

    with patch("subprocess.run", side_effect=FileNotFoundError):
        result = _run(keeper_migrate_audit_verify(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert "error" in data
    assert "keeper-migrate" in data["error"]


def test_audit_verify_timeout(tmp_path: Path) -> None:
    """TimeoutExpired → error JSON."""
    from dsk.mcp.keepercmd_tools import keeper_migrate_audit_verify

    _make_audit_verify_run_dir(tmp_path)

    with patch(
        "subprocess.run",
        side_effect=subprocess.TimeoutExpired(cmd="keeper-migrate", timeout=300),
    ):
        result = _run(keeper_migrate_audit_verify(run_dir=str(tmp_path)))

    data = json.loads(result)
    assert "error" in data
    assert "timed out" in data["error"]


# ---------------------------------------------------------------------------
# Server registration
# ---------------------------------------------------------------------------


def test_tools_are_registered_in_server() -> None:
    """verify, structure, records_import, convert, and audit_verify must be in server._tools."""
    from dsk.mcp.server import server

    registered = set(server._tools.keys())
    assert "keeper_migrate_verify" in registered
    assert "keeper_migrate_structure" in registered
    assert "keeper_migrate_records_import" in registered
    assert "keeper_migrate_convert" in registered
    assert "keeper_migrate_audit_verify" in registered


def test_destructive_subcommands_not_registered() -> None:
    """Destructive subcommands must NOT be in server._tools per D8 opt-out."""
    from dsk.mcp.server import server

    registered = set(server._tools.keys())
    for name in (
        "keeper_migrate_cleanup",
        "keeper_migrate_decommission",
        "keeper_migrate_take_ownership",
        "keeper_migrate_transfer_user",
    ):
        assert name not in registered, f"{name!r} should not be registered (D8 opt-out)"
