"""F5d bucket B: nested rotation preview argv + planner rows; JIT vs post-import argv.

``resources[].users[].rotation_settings`` maps to ``pam rotation edit`` argv
(including ``--schedulejson`` when ``schedule_json`` is set). ``pam_settings.options.jit_settings``
is colocated on PAM resources but has no ``pam connection edit`` flags in Commander
18.0.0 (see ``docs/COMMANDER.md``) — import/extend carries JIT blobs; post-import
tuning argv excludes JIT-only option blocks.
"""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

from dsk.core import compute_diff, load_manifest
from dsk.core.diff import ChangeKind
from dsk.core.interfaces import LiveRecord
from dsk.core.metadata import encode_marker
from dsk.core.models import Manifest
from dsk.core.planner import build_plan
from dsk.providers import commander_cli
from dsk.providers.commander_cli import (
    _build_pam_rotation_edit_args,
    _detect_unsupported_capabilities,
    _preview_rotation_argvs_by_ref,
    build_post_import_tuning_argvs,
)


def _minimal_manifest_dict(minimal_manifest_path: Path) -> dict[str, Any]:
    manifest = load_manifest(minimal_manifest_path)
    assert isinstance(manifest, Manifest)
    return manifest.model_dump(mode="python", exclude_none=True)


def test_preview_rotation_argv_matches_nested_user_via_preview_map(
    minimal_manifest_path: Path,
) -> None:
    data = _minimal_manifest_dict(minimal_manifest_path)
    by_ref = _preview_rotation_argvs_by_ref(data)
    assert "acme-lab-linux1-root" in by_ref
    argvs = by_ref["acme-lab-linux1-root"]
    assert len(argvs) == 1
    argv = argvs[0]
    assert argv[:3] == ["pam", "rotation", "edit"]
    assert "--schedulecron" in argv or "--on-demand" in argv or "--schedulejson" in argv


def test_preview_rotation_omits_user_without_rotation_settings() -> None:
    manifest = {
        "pam_configurations": [{"uid_ref": "cfg", "title": "C", "environment": "local"}],
        "resources": [
            {
                "uid_ref": "res.db",
                "type": "pamDatabase",
                "title": "db",
                "pam_configuration_uid_ref": "cfg",
                "users": [
                    {
                        "uid_ref": "usr.admin",
                        "type": "pamUser",
                        "title": "admin",
                    }
                ],
            }
        ],
    }
    assert _preview_rotation_argvs_by_ref(manifest) == {}


def test_build_rotation_edit_prefers_schedulejson_over_typed_schedule() -> None:
    argv = _build_pam_rotation_edit_args(
        record_uid="user-uid",
        settings={
            "rotation": "general",
            "enabled": "on",
            "schedule_json": {"type": "DAILY", "utcTime": "02:00", "intervalCount": 1},
            "schedule": {"type": "CRON", "cron": "0 0 * * *"},
        },
        resource_uid="resource-uid",
        config_uid="config-uid",
    )
    assert "--schedulejson" in argv
    joined = " ".join(argv)
    assert '{"type":"DAILY"' in joined or '{"type": "DAILY"' in joined
    assert "--schedulecron" not in argv


def test_build_rotation_edit_maps_cron_schedule_to_schedulecron() -> None:
    argv = _build_pam_rotation_edit_args(
        record_uid="u",
        settings={
            "rotation": "general",
            "enabled": "on",
            "schedule": {"type": "CRON", "cron": "30 18 * * *"},
        },
        config_uid="c",
        resource_uid="r",
    )
    assert "--schedulecron" in argv
    assert "30 18 * * *" in argv


def test_plan_pam_user_update_when_rotation_readback_missing_and_marker_mismatched(
    minimal_manifest_path: Path,
) -> None:
    """No live rotation readback + uid_ref marker mismatch → UPDATE (trust path off)."""
    manifest = load_manifest(minimal_manifest_path)
    data = manifest.model_dump(mode="python", exclude_none=True)
    machine = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    user_desired = next(u for u in machine["users"] if u["uid_ref"] == "acme-lab-linux1-root")
    live_user = {k: v for k, v in user_desired.items() if k != "rotation_settings"}
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=deepcopy(machine),
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_USER",
            title="lab-linux-1-root",
            resource_type="pamUser",
            payload=live_user,
            marker=encode_marker(
                uid_ref="other-user",
                manifest=manifest.name,
                resource_type="pamUser",
            ),
        ),
    ]

    changes = compute_diff(manifest, live_records=live)
    order: list[str | None] = []
    for uid, _kind in manifest.iter_uid_refs():
        order.append(uid)
    plan = build_plan(manifest.name, changes, order)

    user_change = next(c for c in plan.changes if c.uid_ref == "acme-lab-linux1-root")
    assert user_change.kind is ChangeKind.UPDATE


def test_plan_pam_user_noop_when_rotation_readback_missing_with_matching_marker(
    minimal_manifest_path: Path,
) -> None:
    """SDK-owned pamUser: missing Commander rotation readback does not force UPDATE."""
    manifest = load_manifest(minimal_manifest_path)
    data = manifest.model_dump(mode="python", exclude_none=True)
    machine = next(r for r in data["resources"] if r["uid_ref"] == "acme-lab-linux1")
    user_desired = next(u for u in machine["users"] if u["uid_ref"] == "acme-lab-linux1-root")
    live_user = {k: v for k, v in user_desired.items() if k != "rotation_settings"}
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=deepcopy(machine),
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=manifest.name,
                resource_type="pamMachine",
            ),
        ),
        LiveRecord(
            keeper_uid="LIVE_USER",
            title="lab-linux-1-root",
            resource_type="pamUser",
            payload=live_user,
            marker=encode_marker(
                uid_ref="acme-lab-linux1-root",
                manifest=manifest.name,
                resource_type="pamUser",
            ),
        ),
    ]
    changes = compute_diff(manifest, live_records=live)
    order = [uid for uid, _k in manifest.iter_uid_refs()]
    plan = build_plan(manifest.name, changes, order)
    user_change = next(c for c in plan.changes if c.uid_ref == "acme-lab-linux1-root")
    assert user_change.kind is ChangeKind.NOOP


def test_post_import_connection_argv_has_no_jit_flags_when_only_jit_in_options() -> None:
    """``pam connection edit`` pinned matrix has no JIT switches — argv cannot carry JIT."""
    resource: dict[str, Any] = {
        "uid_ref": "res.ad",
        "type": "pamMachine",
        "title": "lab-linux",
        "pam_configuration_uid_ref": "cfg.local",
        "pam_settings": {
            "options": {"jit_settings": {"elevate": True, "elevation_method": "group"}}
        },
    }
    argvs = build_post_import_tuning_argvs(
        "REC_UID", resource, resolved_refs={"cfg.local": "LIVE_CFG"}
    )
    assert argvs
    joined = " ".join(argvs[0]).casefold()
    assert "jit" not in joined


def test_jit_settings_drift_surfaces_pam_machine_update(minimal_manifest_path: Path) -> None:
    base = load_manifest(minimal_manifest_path)
    data_desired = base.model_dump(mode="python", exclude_none=True)
    for res in data_desired["resources"]:
        if res["uid_ref"] == "acme-lab-linux1":
            res.setdefault("pam_settings", {}).setdefault("options", {})["jit_settings"] = {
                "elevate": True,
                "elevation_method": "group",
            }
    manifest_desired = Manifest.model_validate(data_desired)
    data_live = base.model_dump(mode="python", exclude_none=True)
    machine_live = next(r for r in data_live["resources"] if r["uid_ref"] == "acme-lab-linux1")
    live = [
        LiveRecord(
            keeper_uid="LIVE_MACHINE",
            title="lab-linux-1",
            resource_type="pamMachine",
            payload=deepcopy(machine_live),
            marker=encode_marker(
                uid_ref="acme-lab-linux1",
                manifest=base.name,
                resource_type="pamMachine",
            ),
        ),
    ]
    changes = compute_diff(manifest_desired, live_records=live)
    m_change = next(c for c in changes if c.uid_ref == "acme-lab-linux1")
    assert m_change.kind is ChangeKind.UPDATE


def test_resource_level_rotation_settings_surfaces_commander_unsupported_detector() -> None:
    manifest = {
        "pam_configurations": [{"uid_ref": "cfg", "title": "C", "environment": "local"}],
        "resources": [
            {
                "uid_ref": "res.x",
                "type": "pamMachine",
                "title": "machine",
                "rotation_settings": {
                    "rotation": "general",
                    "enabled": "on",
                    "schedule": {"type": "CRON", "cron": "0 * * * *"},
                },
                "pam_configuration_uid_ref": "cfg",
            }
        ],
    }
    hits = _detect_unsupported_capabilities(manifest)
    assert any("resources[].rotation_settings is not implemented" in h for h in hits)


def test_commander_rotation_preview_wires_through_module_alias() -> None:
    """Guardrail: preview helpers stay reachable for dry-run rotation_argv injection."""
    assert callable(commander_cli._preview_rotation_argvs_by_ref)
