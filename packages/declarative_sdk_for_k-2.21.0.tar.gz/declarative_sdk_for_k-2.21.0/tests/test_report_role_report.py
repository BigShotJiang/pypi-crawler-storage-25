"""Offline coverage for ``dsk report role-report`` (G1d)."""

from __future__ import annotations

import json
from collections import deque
from typing import Any

import pytest
from click.testing import CliRunner

from dsk.cli import main
from dsk.cli.main import EXIT_GENERIC


def _run(args: list[str]):
    runner = CliRunner()
    return runner.invoke(main, args, catch_exceptions=False)


def _install_role_report_queue(
    monkeypatch: pytest.MonkeyPatch,
    responses: deque[str],
    calls: list[list[str]] | None = None,
) -> None:
    def fake_run_keeper_batch(argv: list[str], **_kwargs: object) -> str:
        if calls is not None:
            calls.append(list(argv))
        if not responses:
            raise AssertionError("no fake keeper response queued")
        return responses.popleft()

    monkeypatch.setattr(
        "dsk.cli._report.runner.run_keeper_batch",
        fake_run_keeper_batch,
    )


def _role_json(
    *,
    role_id: int,
    name: str,
    enforcements: dict[str, Any],
    users: list[dict[str, Any]] | None = None,
    teams: list[dict[str, Any]] | None = None,
    managed: list[dict[str, Any]] | None = None,
) -> str:
    payload = {
        "role_id": role_id,
        "name": name,
        "node_id": 100,
        "node_name": "Root",
        "default_role": False,
        "users": users or [],
        "teams": teams or [],
        "managed_nodes": managed or [],
        "enforcements": enforcements,
    }
    return json.dumps(payload)


def test_role_report_empty_enterprise_zero_roles(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    _install_role_report_queue(monkeypatch, deque([json.dumps([])]), calls)

    result = _run(["report", "role-report"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["command"] == "role-report"
    assert payload["rows"] == []
    assert payload["meta"]["role_count"] == 0
    assert len(calls) == 1
    assert calls[0][0:4] == ["enterprise-info", "-r", "-v", "--format"]


def test_role_report_three_roles_enforcement_counts(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    q = deque(
        [
            json.dumps(
                [
                    {"role_id": 1, "name": "Alpha", "node": "Root"},
                    {"role_id": 2, "name": "Beta", "node": "Root"},
                    {"role_id": 3, "name": "Gamma", "node": "Root"},
                ]
            ),
            _role_json(role_id=1, name="Alpha", enforcements={}),
            _role_json(
                role_id=2,
                name="Beta",
                enforcements={"master_password_minimum_length": 12},
            ),
            _role_json(
                role_id=3,
                name="Gamma",
                enforcements={
                    "master_password_minimum_length": 14,
                    "require_two_factor": True,
                },
            ),
        ]
    )
    _install_role_report_queue(monkeypatch, q, calls)

    result = _run(["report", "role-report", "--json"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert len(payload["rows"]) == 3
    counts = {row["role_id"]: row["enforcement_policy_count"] for row in payload["rows"]}
    assert counts == {1: 0, 2: 1, 3: 2}
    assert payload["meta"]["role_count"] == 3
    assert payload["meta"]["enforcement_catalog_count"] >= 50
    assert "master_password_minimum_length" in payload["meta"]["enforcement_catalog_keys"]
    assert len(calls) == 4
    assert calls[0][0] == "enterprise-info"
    assert [(c[0], c[1]) for c in calls[1:]] == [
        ("enterprise-role", "1"),
        ("enterprise-role", "2"),
        ("enterprise-role", "3"),
    ]


def test_role_report_role_filter_single_role(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    q = deque(
        [
            json.dumps(
                [
                    {"role_id": 1, "name": "Skip", "node": "Root"},
                    {"role_id": 2, "name": "Pick", "node": "Root"},
                ]
            ),
            _role_json(
                role_id=2,
                name="Pick",
                enforcements={"master_password_minimum_length": 10},
            ),
        ]
    )
    _install_role_report_queue(monkeypatch, q, calls)

    result = _run(["report", "role-report", "--role", "2"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert len(payload["rows"]) == 1
    assert payload["rows"][0]["role_id"] == 2
    assert payload["rows"][0]["name"] == "Pick"
    assert len(calls) == 2


def test_role_report_member_users_and_teams_from_role_info(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    q = deque(
        [
            json.dumps([{"role_id": 42, "name": "Developers", "node": "Root"}]),
            json.dumps(
                {
                    "role_id": 42,
                    "name": "Developers",
                    "node_id": 1,
                    "node_name": "Root",
                    "default_role": False,
                    "users": [
                        {"user_id": 1, "username": "alice@example.com"},
                        {"user_id": 2, "username": "bob@example.com"},
                    ],
                    "teams": [
                        {"team_id": "t1", "team_name": "Platform"},
                        {"team_id": "t2", "team_name": "Data"},
                    ],
                    "managed_nodes": [],
                    "enforcements": {},
                }
            ),
        ]
    )
    _install_role_report_queue(monkeypatch, q, calls)

    result = _run(["report", "role-report"])

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    row = payload["rows"][0]
    assert [u["username"] for u in row["member_users"]] == [
        "alice@example.com",
        "bob@example.com",
    ]
    assert [t["team_name"] for t in row["member_teams"]] == ["Platform", "Data"]


def test_role_report_node_flag_passed_to_enterprise_info(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []
    q = deque(
        [
            json.dumps([{"role_id": 9, "name": "Scoped", "node": "Leaf"}]),
            _role_json(role_id=9, name="Scoped", enforcements={}),
        ]
    )
    _install_role_report_queue(monkeypatch, q, calls)

    result = _run(["report", "role-report", "--node", "node-42"])

    assert result.exit_code == 0, result.output
    assert "--node" in calls[0]
    assert calls[0][calls[0].index("--node") + 1] == "node-42"


def test_role_report_sanitize_uids_and_quiet_redact_nested_ids(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    uid_like = "AbCdEfGhIjKlMnOpQrStUv"
    calls: list[list[str]] = []
    q = deque(
        [
            json.dumps([{"role_id": 7, "name": "Ops", "node": "Root"}]),
            _role_json(
                role_id=7,
                name="Ops",
                enforcements={},
                users=[{"user_id": 9001, "username": "u@example.com"}],
                teams=[{"team_id": uid_like, "team_name": "T1"}],
            ),
        ]
    )
    _install_role_report_queue(monkeypatch, q, calls)

    result = _run(["report", "role-report", "--sanitize-uids", "--quiet"])

    assert result.exit_code == 0, result.output
    assert uid_like not in result.stdout
    payload = json.loads(result.stdout)
    team = payload["rows"][0]["member_teams"][0]
    assert team["team_id"].startswith("<uid:")


def test_role_report_leak_check_exits_generic(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    secret = "plain-secret-token"
    monkeypatch.setenv("KEEPER_PASSWORD", secret)
    calls: list[list[str]] = []
    q = deque(
        [
            json.dumps([{"role_id": 1, "name": "X", "node": "Root"}]),
            json.dumps(
                {
                    "role_id": 1,
                    "name": f"x-{secret}-y",
                    "node_id": 1,
                    "node_name": "Root",
                    "default_role": False,
                    "users": [],
                    "teams": [],
                    "managed_nodes": [],
                    "enforcements": {},
                }
            ),
        ]
    )
    _install_role_report_queue(monkeypatch, q, calls)

    result = _run(["report", "role-report"])

    assert result.exit_code == EXIT_GENERIC
    assert secret not in result.stdout
    assert "report refused" in result.stderr
    assert len(calls) == 2
