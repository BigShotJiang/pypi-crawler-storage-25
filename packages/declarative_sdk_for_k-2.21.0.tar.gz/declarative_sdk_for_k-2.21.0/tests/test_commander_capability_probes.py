"""Tests for Commander capability probes.

Per Codex absorption audit 2026-05-09: capability probes replace coarse version
checks for individual commands.
"""

from __future__ import annotations

import argparse
import types
from unittest import mock

from dsk.providers import commander_version
from dsk.providers.commander_version import (
    supports_pam_project_export,
    supports_rotation_info_json,
    supports_secrets_manager_token_add,
)


def test_supports_pam_project_export_returns_bool() -> None:
    """Probe must return a bool, not raise."""
    result = supports_pam_project_export()
    assert isinstance(result, bool)


def test_supports_rotation_info_json_returns_bool() -> None:
    result = supports_rotation_info_json()
    assert isinstance(result, bool)


def test_supports_secrets_manager_token_add_returns_bool() -> None:
    result = supports_secrets_manager_token_add()
    assert isinstance(result, bool)


def test_pam_project_export_probe_handles_import_error() -> None:
    """If the import path doesn't exist, probe returns False, doesn't raise."""
    with mock.patch.object(commander_version, "import_module", side_effect=ImportError):
        assert supports_pam_project_export() is False


def test_pam_project_export_probe_detects_command_class(
    monkeypatch,
) -> None:
    class PAMProjectExportCommand:
        pass

    fake_module = types.SimpleNamespace(PAMProjectExportCommand=PAMProjectExportCommand)

    def fake_import_module(name: str):
        if name == "keepercommander.commands.pam_import.export":
            return fake_module
        raise ImportError(name)

    monkeypatch.setattr(commander_version, "import_module", fake_import_module)

    assert supports_pam_project_export() is True


def test_rotation_info_json_probe_inspects_parser(
    monkeypatch,
) -> None:
    class PAMRouterGetRotationInfo:
        def get_parser(self):
            parser = argparse.ArgumentParser()
            parser.add_argument("--record-uid", dest="record_uid")
            parser.add_argument("--format", dest="format", choices=["table", "json"])
            return parser

    fake_module = types.SimpleNamespace(PAMRouterGetRotationInfo=PAMRouterGetRotationInfo)

    def fake_import_module(name: str):
        if name == "keepercommander.commands.discoveryrotation":
            return fake_module
        raise ImportError(name)

    monkeypatch.setattr(commander_version, "import_module", fake_import_module)

    assert supports_rotation_info_json() is True


def test_rotation_info_json_probe_rejects_parser_without_json(
    monkeypatch,
) -> None:
    class PAMRouterGetRotationInfo:
        def get_parser(self):
            parser = argparse.ArgumentParser()
            parser.add_argument("--record-uid", dest="record_uid")
            parser.add_argument("--format", dest="format", choices=["table"])
            return parser

    fake_module = types.SimpleNamespace(PAMRouterGetRotationInfo=PAMRouterGetRotationInfo)

    def fake_import_module(name: str):
        if name == "keepercommander.commands.discoveryrotation":
            return fake_module
        raise ImportError(name)

    monkeypatch.setattr(commander_version, "import_module", fake_import_module)

    assert supports_rotation_info_json() is False


def test_secrets_manager_token_add_probe_detects_positional_command(
    monkeypatch,
) -> None:
    class KSMCommand:
        def get_parser(self):
            parser = argparse.ArgumentParser()
            parser.add_argument("command", nargs="*", help='"app list" or "token add"')
            return parser

        def execute(self, params, **kwargs):
            ksm_obj = "token"
            ksm_action = "add"
            if ksm_obj == "token" and ksm_action == "add":
                return self.add_client(params, **kwargs)
            return None

        def add_client(self, params, **kwargs):
            return None

    fake_module = types.SimpleNamespace(KSMCommand=KSMCommand, available_ksm_commands="")

    def fake_import_module(name: str):
        if name == "keepercommander.commands.ksm":
            return fake_module
        raise ImportError(name)

    monkeypatch.setattr(commander_version, "import_module", fake_import_module)

    assert supports_secrets_manager_token_add() is True


def test_secrets_manager_token_add_probe_rejects_missing_token_help(
    monkeypatch,
) -> None:
    class KSMCommand:
        def get_parser(self):
            parser = argparse.ArgumentParser()
            parser.add_argument("command", nargs="*", help='"app list" or "client add"')
            return parser

    fake_module = types.SimpleNamespace(KSMCommand=KSMCommand, available_ksm_commands="")

    def fake_import_module(name: str):
        if name == "keepercommander.commands.ksm":
            return fake_module
        raise ImportError(name)

    monkeypatch.setattr(commander_version, "import_module", fake_import_module)

    assert supports_secrets_manager_token_add() is False
