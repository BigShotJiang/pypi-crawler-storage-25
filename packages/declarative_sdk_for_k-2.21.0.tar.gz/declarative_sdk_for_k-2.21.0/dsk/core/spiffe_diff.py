"""Desired-vs-live diff for ``spiffe-binding.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_spiffe import SpiffeBindingManifestV1


def compute_spiffe_diff(
    manifest: SpiffeBindingManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared SPIFFE identity rule."""
    if live:
        raise NotImplementedError(
            "spiffe-binding.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or "spiffe-binding"
    changes: list[Change] = []

    for idx, rule in enumerate(manifest.rules):
        payload = rule.model_dump(mode="python", exclude_none=True)
        uid_ref = str(getattr(rule, "uid_ref", None) or f"{name}.rules.{idx}")
        title = str(getattr(rule, "name", None) or uid_ref)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="spiffe_rule",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_spiffe_diff"]
