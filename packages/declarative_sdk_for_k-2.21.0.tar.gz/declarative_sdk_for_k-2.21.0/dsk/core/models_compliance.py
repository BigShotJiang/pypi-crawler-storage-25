"""Compliance bundle manifest models — compliance-bundle.v1.

Declares which DSK reports map to which compliance controls,
enabling automated evidence collection for FedRAMP High, SOC2, ISO27001.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class ComplianceFramework(StrEnum):
    fedramp_high = "fedramp-high"
    fedramp_moderate = "fedramp-moderate"
    soc2_type2 = "soc2-type2"
    iso27001 = "iso27001"
    nist_csf = "nist-csf"


class ReportType(StrEnum):
    password_report = "password-report"
    compliance_report = "compliance-report"
    security_audit_report = "security-audit-report"


class ControlMapping(BaseModel):
    control_id: str = Field(
        ...,
        description="Control identifier, e.g. 'AC-2', 'CC6.1', 'A.9.2.3'",
    )
    description: str = Field(
        ...,
        description="Human-readable control description",
    )
    report: ReportType
    report_args: list[str] = Field(
        default_factory=list,
        description="Extra flags passed to dsk report, e.g. ['--sanitize-uids']",
    )
    evidence_file: str = Field(
        ...,
        description=("Output filename for this control's evidence, e.g. 'ac-2-account-mgmt.json'"),
    )


class ComplianceBundleScope(BaseModel):
    manifest_paths: list[str] = Field(
        default_factory=list,
        description="DSK manifest files in scope for this compliance bundle",
    )
    node: str | None = Field(
        None,
        description="Keeper node UID to scope compliance reports to",
    )


class ComplianceBundleManifestV1(BaseModel):
    """Root model for a compliance-bundle.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("compliance-bundle.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    frameworks: list[ComplianceFramework] = Field(default_factory=list)
    scope: ComplianceBundleScope = Field(default_factory=lambda: ComplianceBundleScope())  # type: ignore[call-arg]
    controls: list[ControlMapping] = Field(default_factory=list)
    output_dir: str = Field(
        "compliance-evidence/",
        description="Directory to write evidence files",
    )
