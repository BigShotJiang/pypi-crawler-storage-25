"""Desired-vs-live diff for ``keeper-agent-kit.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_agent_kit import AgentKitManifestV1


def compute_agent_kit_diff(
    manifest: AgentKitManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared Keeper Agent Kit resource."""
    if live:
        raise NotImplementedError(
            "keeper-agent-kit.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    for policy in manifest.policies:
        payload = policy.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=policy.uid_ref,
                resource_type="agent_kit_policy",
                title=str(policy.uid_ref),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_agent_kit_diff"]
