"""AI agent trust chain models — ai-agent-trust-chain.v1.

Declares delegation policies for inter-agent credential passing.
Solves the unsolved problem: orchestrator agent → sub-agent trust without
sharing the orchestrator's full credential set.

Source: Gartner IAM Summit 2026 — inter-agent delegation named as top unsolved gap.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class DelegationMode(StrEnum):
    attenuation = "attenuation"  # sub-agent gets subset of orchestrator's access
    projection = "projection"  # sub-agent gets scoped credentials for specific task
    impersonation = "impersonation"  # sub-agent acts as a specific service identity


class AttestationRequirement(StrEnum):
    none_ = "none"  # no attestation (low security)
    signed_jwt = "signed_jwt"  # sub-agent must present signed JWT from orchestrator
    spiffe = "spiffe"  # sub-agent must present SPIFFE SVID
    ksm_token = "ksm_token"  # sub-agent must present KSM-issued capability token


class DelegationScope(BaseModel):
    uid_refs: list[str] = Field(
        default_factory=list,
        description="DSK uid_refs the sub-agent may access under this delegation",
    )
    max_ttl_seconds: int = Field(
        900,
        ge=60,
        le=3600,
        description="Maximum credential lifetime for delegated access",
    )
    allow_re_delegation: bool = Field(
        False,
        description="Whether the sub-agent may further delegate to its own sub-agents",
    )
    scopes: list[str] = Field(
        default_factory=list,
        description="Permission scopes: read, execute, write (subset of orchestrator's)",
    )


class AgentDelegationRule(BaseModel):
    name: str
    description: str | None = None
    orchestrator_uid_ref: str = Field(
        ...,
        description="uid_ref of the nhi-agent.v1 orchestrator identity",
    )
    sub_agent_uid_refs: list[str] = Field(
        default_factory=list,
        description="uid_refs of nhi-agent.v1 sub-agent identities that may receive delegation",
    )
    mode: DelegationMode = DelegationMode.attenuation
    attestation: AttestationRequirement = AttestationRequirement.signed_jwt
    scope: DelegationScope = Field(default_factory=lambda: DelegationScope())  # type: ignore[call-arg]
    audit_log: bool = Field(True)
    revoke_on_orchestrator_exit: bool = Field(
        True,
        description="Auto-revoke all sub-agent delegations when orchestrator session ends",
    )


class TrustChainManifestV1(BaseModel):
    """Root model for an ai-agent-trust-chain.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("ai-agent-trust-chain.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    rules: list[AgentDelegationRule] = Field(default_factory=list)
