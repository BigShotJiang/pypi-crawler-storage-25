"""IR (Incident Response) adapter helpers for DSK core.

Wraps the existing SiemManifestV1 / compute_siem_diff infrastructure with
higher-level helpers useful for IR loops.

NOTE: schedule_rotation is a stub — actual rotation scheduling goes through
Commander and is not implemented here.  Fully offline; no network calls,
no subprocess, no Commander imports.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Any, Literal

# ---------------------------------------------------------------------------
# SIEM reconcile
# ---------------------------------------------------------------------------


@dataclass
class SiemReconcileResult:
    """Result of comparing two SIEM manifest snapshots."""

    manifest_name: str
    new_streams: list[str]  # uid_refs in actual but not in expected
    removed_streams: list[str]  # uid_refs in expected but not in actual
    modified_streams: list[str]  # uid_refs in both but with changed content
    drift_score: float  # 0.0–1.0, total changes / expected size


def _extract_stream_map(doc: dict[str, Any]) -> dict[str, str]:
    """Return uid_ref → stable JSON fingerprint for all sinks + routes."""
    items: dict[str, str] = {}
    for block in ("sinks", "routes"):
        for entry in doc.get(block) or []:
            if not isinstance(entry, dict):
                continue
            uid = entry.get("uid_ref") or entry.get("uid")
            if uid:
                items[str(uid)] = json.dumps(entry, sort_keys=True, separators=(",", ":"))
    return items


def reconcile_siem_manifest(
    expected_doc: dict[str, Any],
    actual_doc: dict[str, Any],
    *,
    manifest_name: str = "keeper-siem",
) -> SiemReconcileResult:
    """Compare two SIEM manifest dicts and return a reconcile result.

    Both inputs are plain Python dicts (parsed YAML/JSON), keeping this
    offline-friendly without Pydantic model instantiation.
    """
    expected = _extract_stream_map(expected_doc)
    actual = _extract_stream_map(actual_doc)

    expected_keys = set(expected)
    actual_keys = set(actual)

    new_streams = sorted(actual_keys - expected_keys)
    removed_streams = sorted(expected_keys - actual_keys)
    modified_streams = sorted(
        uid for uid in expected_keys & actual_keys if expected[uid] != actual[uid]
    )

    total_changed = len(new_streams) + len(removed_streams) + len(modified_streams)
    drift_score = total_changed / max(len(expected_keys), 1)

    return SiemReconcileResult(
        manifest_name=manifest_name,
        new_streams=new_streams,
        removed_streams=removed_streams,
        modified_streams=modified_streams,
        drift_score=drift_score,
    )


class BuildVsRuntimeClass(StrEnum):
    """Secret lifecycle boundary: where a secret is consumed."""

    BUILD = "build"
    RUNTIME = "runtime"
    HYBRID = "hybrid"


def classify_secret(resource_dict: dict[str, Any]) -> BuildVsRuntimeClass:
    """Classify a resource dict as BUILD, RUNTIME, or HYBRID.

    Rules (first match wins):
    - rotation_settings.enabled == "on"  → RUNTIME
    - secret_class starts with "ci-" or "build-"  → BUILD
    - otherwise                          → HYBRID
    """
    rotation = resource_dict.get("rotation_settings") or {}
    if isinstance(rotation, dict) and rotation.get("enabled") == "on":
        return BuildVsRuntimeClass.RUNTIME

    secret_class = str(resource_dict.get("secret_class") or "")
    if secret_class.startswith(("ci-", "build-")):
        return BuildVsRuntimeClass.BUILD

    return BuildVsRuntimeClass.HYBRID


# ---------------------------------------------------------------------------
# Async rotation stub
# ---------------------------------------------------------------------------


@dataclass
class AsyncRotationStub:
    """Planned (not applied) rotation intent for one secret.

    IMPORTANT: Actual rotation goes through Commander.  This stub records
    offline planning intent only; nothing is executed by creating this object.
    """

    uid_ref: str
    scheduled_at: str  # ISO8601
    status: Literal["pending", "in_progress", "complete", "failed"] = "pending"
    error: str | None = None


def schedule_rotation(uid_ref: str, delay_seconds: int = 0) -> AsyncRotationStub:
    """Return a pending rotation stub for *uid_ref*.

    NOTE: This is a stub — actual rotation goes through Commander.  Nothing is
    scheduled or applied by this call; it records offline planning intent only.
    """
    now = datetime.now(UTC)
    scheduled_at = (now + timedelta(seconds=delay_seconds)).isoformat()
    return AsyncRotationStub(uid_ref=uid_ref, scheduled_at=scheduled_at)
