"""Desired-vs-live diff for ``compliance-bundle.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_compliance import ComplianceBundleManifestV1


def compute_compliance_diff(
    manifest: ComplianceBundleManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared compliance bundle resource."""
    if live:
        raise NotImplementedError(
            "compliance-bundle.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    for idx, control in enumerate(manifest.controls):
        uid_ref = f"{name}.controls.{idx}"
        payload = control.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="compliance_control",
                title=uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for idx, framework in enumerate(manifest.frameworks):
        uid_ref = f"{name}.frameworks.{idx}"
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="compliance_framework",
                title=str(framework),
                before={},
                after={"framework": str(framework)},
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_compliance_diff"]
