"""Desired-vs-live diff for ``mcp-server-allowlist.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_mcp_allowlist import McpAllowlistManifest


def compute_mcp_allowlist_diff(
    manifest: McpAllowlistManifest,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for MCP server allowlist entries (offline demo path)."""
    if live:
        raise NotImplementedError(
            "mcp-server-allowlist.v1 live readback is not implemented — pass live=None",
        )

    name = manifest_name or "mcp-server-allowlist"
    changes: list[Change] = []

    for server in manifest.servers:
        payload = server.model_dump(mode="python", exclude_none=True)
        uid_ref = str(server.uid_ref)
        title = str(server.name)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="mcp_server_allowlist",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_mcp_allowlist_diff"]
