"""Desired-vs-live diff for ``keeper-tunnel.v1`` (offline)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_tunnel import TunnelManifestV1


def compute_tunnel_diff(
    manifest: TunnelManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared tunnel resource."""
    if live:
        raise NotImplementedError(
            "keeper-tunnel.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or "keeper-tunnel"
    changes: list[Change] = []

    for idx, tunnel in enumerate(manifest.tunnels):
        payload = tunnel.model_dump(mode="python", exclude_none=True)
        uid_ref_value = getattr(tunnel, "uid_ref", None)
        uid_ref = str(uid_ref_value) if uid_ref_value is not None else f"{name}.tunnels.{idx}"
        title_value = getattr(tunnel, "name", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="tunnel_config",
                title=str(title_value) if title_value is not None else uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for idx, binding in enumerate(manifest.gateway_bindings):
        payload = binding.model_dump(mode="python", exclude_none=True)
        uid_ref_value = getattr(binding, "uid_ref", None)
        uid_ref = (
            str(uid_ref_value) if uid_ref_value is not None else f"{name}.gateway_bindings.{idx}"
        )
        title_value = getattr(binding, "name", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="tunnel_gateway_binding",
                title=str(title_value) if title_value is not None else uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for idx, mapping in enumerate(manifest.host_mappings):
        payload = mapping.model_dump(mode="python", exclude_none=True)
        uid_ref_value = getattr(mapping, "uid_ref", None)
        uid_ref = str(uid_ref_value) if uid_ref_value is not None else f"{name}.host_mappings.{idx}"
        title_value = getattr(mapping, "name", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="tunnel_host_mapping",
                title=str(title_value) if title_value is not None else uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_tunnel_diff"]
