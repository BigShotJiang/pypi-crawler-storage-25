"""
NHI (Non-Human Identity) models for DSK — private preview.

Gated behind DSK_PREVIEW=nhi. Do not import at top-level without the gate.
CyberArk paid $1.54B for Venafi to address this problem space.
Keeper + DSK addresses it declaratively with zero acquisition cost.

This module also defines JSON-Schema-aligned ``NhiAgentManifest`` /
``load_nhi_manifest`` for packaged ``nhi-agent.v1`` manifests (``schema`` +
``resources``). Governance-oriented types (``NhiAgent``, ``NhiManifestV1``)
are for preview / pitch; they are not the same shape as the shipped schema.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Any, Literal, TypeAlias

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    model_validator,
)

from dsk.core.errors import SchemaError


class NhiAgentKind(StrEnum):
    """Classification of non-human identity."""

    AI_AGENT = "ai_agent"
    CI_CD = "ci_cd"
    SERVICE_ACCOUNT = "service_account"
    WORKLOAD = "workload"
    API_KEY = "api_key"
    MACHINE_CREDENTIAL = "machine_credential"


class NhiRotationPolicy(BaseModel):
    """Rotation policy for an NHI credential."""

    interval_days: int = Field(
        default=90,
        ge=1,
        le=365,
        description="Rotate credential every N days",
    )
    auto_rotate: bool = Field(
        default=True,
        description="Automatically rotate on schedule (requires rotation runner)",
    )
    notify_owners_days_before: int = Field(
        default=7,
        ge=0,
        description="Notify identity owners N days before rotation",
    )
    revoke_on_expiry: bool = Field(
        default=True,
        description="Revoke credential if rotation fails after deadline",
    )


class NhiScopeBinding(BaseModel):
    """Access scope bound to an NHI — what it can access."""

    resource_uid_ref: str = Field(description="DSK uid_ref of the PAM resource")
    permission: str = Field(
        default="read",
        description="Permission level: read | write | admin",
    )
    time_limit_hours: int | None = Field(
        default=None,
        description="If set, access expires after N hours (JIT-style)",
    )


class NhiAgent(BaseModel):
    """
    A Non-Human Identity declaration in a DSK manifest.

    Represents an AI agent, service account, CI/CD pipeline, or workload
    identity that needs declarative lifecycle management: creation, rotation,
    scope binding, and revocation.
    """

    uid_ref: str = Field(description="Stable manifest identifier")
    display_name: str = Field(description="Human-readable name for this NHI")
    kind: NhiAgentKind = Field(description="Classification of this non-human identity")
    description: str | None = Field(default=None)
    owner_uid_refs: list[str] = Field(
        default_factory=list,
        description="uid_refs of human users who own this NHI",
    )
    rotation_policy: NhiRotationPolicy = Field(
        default_factory=NhiRotationPolicy,
        description="Credential rotation policy",
    )
    scope_bindings: list[NhiScopeBinding] = Field(
        default_factory=list,
        description="What this NHI can access",
    )
    tags: dict[str, str] = Field(
        default_factory=dict,
        description="Arbitrary key-value tags for governance (e.g. team, environment, cost-center)",
    )
    ksm_record_uid_ref: str | None = Field(
        default=None,
        description="uid_ref of KSM app record that holds this identity's credentials",
    )


class NhiManifestV1(BaseModel):
    """Top-level nhi-agent.v1 manifest."""

    family: str = Field(default="nhi-agent.v1")
    name: str
    description: str | None = None
    agents: list[NhiAgent] = Field(default_factory=list)


# --- Packaged JSON Schema family: ``schema`` + ``resources`` (tests, MCP, manifest loader) ---

NHI_FAMILY: Literal["nhi-agent.v1"] = "nhi-agent.v1"

UidRef: TypeAlias = Annotated[
    str,
    StringConstraints(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
NonEmptyString: TypeAlias = Annotated[str, StringConstraints(min_length=1)]

NhiAgentType = Literal["service_account", "ai_agent", "automation"]


class _NhiSchemaModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid", str_strip_whitespace=True)


class NhiAgentResource(_NhiSchemaModel):
    """One NHI agent / service-account resource (schema-aligned)."""

    uid_ref: UidRef
    name: NonEmptyString
    type: NhiAgentType
    purpose: str = ""
    scope: list[NonEmptyString] = Field(default_factory=list)
    allowed_tools: list[NonEmptyString] = Field(default_factory=list)
    expiration: str | None = None
    credential_ref: str | None = None
    tags: dict[str, str] = Field(default_factory=dict)
    # Audit policy fields — OWASP A1 excessive agency guard + NHI governance
    max_rotation_age_days: int | None = (
        None  # alert if credential older than N days (None = no limit)
    )
    require_expiration: bool = False  # if True, expiration field must be set
    max_scope_count: int | None = None  # alert if scope list exceeds N entries (None = no limit)
    privilege_review_required: bool = False  # flag requiring periodic human review
    caep_enabled: bool = False  # Continuous Access Evaluation Protocol session interruption

    @model_validator(mode="after")
    def _expiration_required_when_flagged(self) -> NhiAgentResource:
        if self.require_expiration:
            exp = self.expiration
            if exp is None or not str(exp).strip():
                raise SchemaError(
                    reason="require_expiration is True but expiration is missing or empty",
                    next_action="set a non-empty expiration on the NHI resource",
                )
        return self


class NhiAgentManifest(_NhiSchemaModel):
    """Top-level ``nhi-agent.v1`` manifest (JSON Schema shape)."""

    nhi_schema: Literal["nhi-agent.v1"] = Field(default=NHI_FAMILY, alias="schema")
    resources: list[NhiAgentResource] = Field(default_factory=list)

    @model_validator(mode="after")
    def _uid_refs_are_unique(self) -> NhiAgentManifest:
        seen: dict[str, str] = {}
        duplicates: set[str] = set()
        for resource in self.resources:
            if resource.uid_ref in seen:
                duplicates.add(resource.uid_ref)
            seen[resource.uid_ref] = "nhi_agent"
        if duplicates:
            raise ValueError(f"duplicate uid_ref values: {sorted(duplicates)}")
        return self

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        """Return ``(uid_ref, kind)`` for all NHI resources."""
        return [(r.uid_ref, "nhi_agent") for r in self.resources]


def load_nhi_manifest(document: dict[str, Any]) -> NhiAgentManifest:
    """Validate with JSON Schema, then parse as ``NhiAgentManifest``."""
    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != NHI_FAMILY:
        raise SchemaError(
            reason=f"expected {NHI_FAMILY!r}, got {family!r}",
            next_action="set schema: nhi-agent.v1 on the manifest",
        )
    try:
        return NhiAgentManifest.model_validate(document)
    except ValidationError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match nhi-agent.v1 typed rules",
        ) from exc
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match nhi-agent.v1 typed rules",
        ) from exc


__all__ = [
    "NHI_FAMILY",
    "NhiAgent",
    "NhiAgentKind",
    "NhiAgentManifest",
    "NhiAgentResource",
    "NhiManifestV1",
    "NhiRotationPolicy",
    "NhiScopeBinding",
    "load_nhi_manifest",
]
