"""Desired-vs-live diff for ``keeper-drive.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_keeper_drive import KeeperDriveManifestV1


def compute_keeper_drive_diff(
    manifest: KeeperDriveManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared Keeper Drive resource."""
    if live:
        raise NotImplementedError(
            "keeper-drive.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or "keeper-drive"
    changes: list[Change] = []

    for folder in manifest.folders:
        payload = folder.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=folder.uid_ref,
                resource_type="keeper_drive_folder",
                title=str(folder.name),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for file in manifest.files:
        payload = file.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=file.uid_ref,
                resource_type="keeper_drive_file",
                title=str(file.name),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for share in manifest.shares:
        payload = share.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=share.uid_ref,
                resource_type="keeper_drive_share",
                title=str(share.uid_ref),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_keeper_drive_diff"]
