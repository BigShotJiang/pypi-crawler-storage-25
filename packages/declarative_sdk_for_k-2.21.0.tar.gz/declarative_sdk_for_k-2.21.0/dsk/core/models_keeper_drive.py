"""Private typed models for ``keeper-drive.v1`` manifests."""

from __future__ import annotations

from typing import Annotated, Any, Literal, TypeAlias

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    model_validator,
)

from dsk.core.errors import SchemaError

KEEPER_DRIVE_FAMILY: Literal["keeper-drive.v1"] = "keeper-drive.v1"

UidRef: TypeAlias = Annotated[
    str,
    StringConstraints(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
FolderRef: TypeAlias = Annotated[
    str,
    StringConstraints(pattern=r"^keeper-drive:folders:[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
FileRef: TypeAlias = Annotated[
    str,
    StringConstraints(pattern=r"^keeper-drive:files:[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
NonEmptyString: TypeAlias = Annotated[str, StringConstraints(min_length=1)]


class _KeeperDriveModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid", str_strip_whitespace=True)


class KeeperDriveFolder(_KeeperDriveModel):
    """One KeeperDrive folder."""

    uid_ref: UidRef
    name: NonEmptyString
    parent_folder_uid_ref: FolderRef | None = None


class KeeperDriveFile(_KeeperDriveModel):
    """One KeeperDrive file placeholder."""

    uid_ref: UidRef
    name: NonEmptyString
    folder_uid_ref: FolderRef
    source_path: NonEmptyString | None = None
    content_hash: NonEmptyString | None = None


class KeeperDriveShare(_KeeperDriveModel):
    """One KeeperDrive file share."""

    uid_ref: UidRef
    file_uid_ref: FileRef
    grantee: NonEmptyString
    permission: Literal["read", "write", "owner"] = "read"


class KeeperDriveManifestV1(_KeeperDriveModel):
    """Top-level private ``keeper-drive.v1`` manifest."""

    keeper_drive_schema: Literal["keeper-drive.v1"] = Field(
        default=KEEPER_DRIVE_FAMILY,
        alias="schema",
    )
    folders: list[KeeperDriveFolder] = Field(default_factory=list)
    files: list[KeeperDriveFile] = Field(default_factory=list)
    shares: list[KeeperDriveShare] = Field(default_factory=list)

    @model_validator(mode="after")
    def _refs_are_consistent(self) -> KeeperDriveManifestV1:
        seen: dict[str, str] = {}
        duplicates: list[str] = []
        for uid_ref, kind in self.iter_uid_refs():
            if uid_ref in seen:
                duplicates.append(uid_ref)
            seen[uid_ref] = kind
        if duplicates:
            raise ValueError(f"duplicate uid_ref values: {sorted(set(duplicates))}")

        folders = {folder.uid_ref for folder in self.folders}
        files = {file.uid_ref for file in self.files}
        missing_folders = sorted(
            {
                _ref_uid(ref)
                for ref in [f.parent_folder_uid_ref for f in self.folders]
                + [f.folder_uid_ref for f in self.files]
                if ref is not None and _ref_uid(ref) not in folders
            }
        )
        if missing_folders:
            raise ValueError(f"unknown KeeperDrive folder refs: {missing_folders}")
        missing_files = sorted(
            {
                _ref_uid(share.file_uid_ref)
                for share in self.shares
                if _ref_uid(share.file_uid_ref) not in files
            }
        )
        if missing_files:
            raise ValueError(f"unknown KeeperDrive file refs: {missing_files}")
        return self

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        refs: list[tuple[str, str]] = []
        refs.extend((folder.uid_ref, "keeper_drive_folder") for folder in self.folders)
        refs.extend((file.uid_ref, "keeper_drive_file") for file in self.files)
        refs.extend((share.uid_ref, "keeper_drive_share") for share in self.shares)
        return refs


def _ref_uid(ref: str) -> str:
    return ref.rsplit(":", 1)[-1]


def load_keeper_drive_manifest(document: dict[str, Any]) -> KeeperDriveManifestV1:
    """Validate with JSON Schema, then parse as ``KeeperDriveManifestV1``."""
    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != KEEPER_DRIVE_FAMILY:
        raise SchemaError(
            reason=f"expected {KEEPER_DRIVE_FAMILY!r}, got {family!r}",
            next_action="set schema: keeper-drive.v1 on the manifest",
        )
    try:
        return KeeperDriveManifestV1.model_validate(document)
    except ValidationError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match keeper-drive.v1 typed rules",
        ) from exc
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match keeper-drive.v1 typed rules",
        ) from exc


__all__ = [
    "KEEPER_DRIVE_FAMILY",
    "KeeperDriveFile",
    "KeeperDriveFolder",
    "KeeperDriveManifestV1",
    "KeeperDriveShare",
    "load_keeper_drive_manifest",
]
