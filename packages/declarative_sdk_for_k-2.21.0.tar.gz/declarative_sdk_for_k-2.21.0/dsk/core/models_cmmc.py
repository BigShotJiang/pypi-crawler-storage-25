"""CMMC 2.0 compliance profile models — cmmc-profile.v1.

Declares CMMC Level 2 (NIST SP 800-171) PAM control attestations.
Trigger: CMMC 2.0 Phase 2 C3PAO deadline November 10, 2026.
48 CFR final rule effective November 10, 2025.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class CmmcLevel(StrEnum):
    level1 = "level-1"  # 17 practices (FAR 52.204-21)
    level2 = "level-2"  # 110 practices (NIST SP 800-171)
    level3 = "level-3"  # 134+ practices (NIST SP 800-172)


class CmmcDomain(StrEnum):
    access_control = "AC"  # Access Control
    identification_auth = "IA"  # Identification & Authentication
    audit_accountability = "AU"  # Audit & Accountability
    config_management = "CM"  # Configuration Management
    incident_response = "IR"  # Incident Response
    risk_assessment = "RA"  # Risk Assessment
    system_comms_protection = "SC"  # System & Communications Protection
    system_info_integrity = "SI"  # System & Information Integrity


class CmmcControlStatus(StrEnum):
    met = "met"
    partially_met = "partially_met"
    not_met = "not_met"
    not_applicable = "not_applicable"


class CmmcControlMapping(BaseModel):
    practice_id: str = Field(
        ...,
        description="NIST SP 800-171 practice ID, e.g. '3.1.1', '3.5.3'",
    )
    domain: CmmcDomain
    description: str
    status: CmmcControlStatus
    keeper_resources: list[str] = Field(
        default_factory=list,
        description="DSK uid_refs satisfying this control",
    )
    evidence_artifacts: list[str] = Field(
        default_factory=list,
        description=(
            "Evidence artifact types: session_log, rotation_log, mfa_record, config_snapshot"
        ),
    )
    c3pao_notes: str | None = Field(
        None,
        description="Assessor-facing notes; required when status=partially_met or not_met",
    )


class CmmcScopeConfig(BaseModel):
    cui_systems: list[str] = Field(
        default_factory=list,
        description="DSK uid_refs of systems processing CUI",
    )
    enclave_boundary: str | None = None
    assessment_date: str | None = None
    c3pao_org: str | None = Field(
        None,
        description="Certified Third-Party Assessment Organization name",
    )


class CmmcProfileManifestV1(BaseModel):
    """Root model for a cmmc-profile.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("cmmc-profile.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    target_level: CmmcLevel = CmmcLevel.level2
    cage_code: str | None = Field(
        None,
        description="DoD CAGE code of the assessed organization",
    )
    scope: CmmcScopeConfig = Field(default_factory=lambda: CmmcScopeConfig())  # type: ignore[call-arg]
    controls: list[CmmcControlMapping] = Field(default_factory=list)
    evidence_output_dir: str = "cmmc-evidence/"
