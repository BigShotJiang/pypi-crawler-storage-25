"""JSON Schema validation.

Uses jsonschema if available; falls back to typed-model validation for
``pam-environment.v1`` only when jsonschema is missing.

Phase 0 (PAM parity program): every packaged ``*.v1`` family resolves via
``schema: <family>.v1`` (or legacy ``version`` + ``name`` for PAM). See
``docs/PAM_PARITY_PROGRAM.md``.
"""

from __future__ import annotations

import json
from functools import cache
from importlib import resources
from pathlib import Path
from typing import Any

from dsk.core.errors import SchemaError
from dsk.core.resource_limits import (
    ResourceLimitError,
    positive_int_env,
    read_json_file_limited,
)

PAM_FAMILY = "pam-environment.v1"
ENTERPRISE_FAMILY = "keeper-enterprise.v1"
IDENTITY_FAMILY = "keeper-integrations-identity.v1"
EVENTS_FAMILY = "keeper-integrations-events.v1"
KSM_FAMILY = "keeper-ksm.v1"
SHARING_FAMILY = "keeper-vault-sharing.v1"
PAM_EXTENDED_FAMILY = "keeper-pam-extended.v1"
EPM_FAMILY = "keeper-epm.v1"
TERRAFORM_FAMILY = "keeper-terraform.v1"
K8S_ESO_FAMILY = "keeper-k8s-eso.v1"
SIEM_FAMILY = "keeper-siem.v1"
NHI_FAMILY = "nhi-agent.v1"  # private: NHI governance
JIT_ACCESS_FAMILY = "jit-access.v1"  # private/preview: JIT / ephemeral access policies
PIPELINE_EPHEMERAL_FAMILY = "pipeline-ephemeral-environment.v1"  # private: CI ephemeral PAM envs
MCP_SECRETS_BINDING_FAMILY = (
    "mcp-secrets-binding.v1"  # private/preview: MCP server secrets governance
)
TRUST_CHAIN_FAMILY = (
    "ai-agent-trust-chain.v1"  # private/preview: inter-agent credential delegation policies
)
AGENT_KIT_FAMILY = "keeper-agent-kit.v1"  # private: SAK policy governance
CSPM_REMEDIATION_FAMILY = "cspm-remediation.v1"  # private: CSPM → DSK remediation bridge
SECRET_SCANNER_FAMILY = "secret-scanner-bridge.v1"  # private: GHAS secret scanning → PAM rotation
CLOUD_JIT_FAMILY = "cloud-jit.v1"  # private/preview: multi-cloud JIT federation (TEAM/PIM/PAM)
WORKFLOW_GATE_FAMILY = "workflow-gate.v1"  # semi-public: Keeper-native PAM approval chains
SLACK_GATE_FAMILY = "slack-approval-gate.v1"  # private: Slack human approval for GitOps apply
ITSM_GATE_FAMILY = "itsm-approval-gate.v1"  # private: ITSM human approval for GitOps apply
GATEWAY_HA_FAMILY = "gateway-ha.v1"  # semi-public: core PAM gateway HA clusters
CONNECTION_PROFILE_FAMILY = (
    "pam-connection-profile.v1"  # semi-public: core PAM reusable connection profiles
)
EPM_POLICY_FAMILY = "epm-policy.v1"  # semi-public: endpoint privilege application control rules
SPIFFE_BINDING_FAMILY = "spiffe-binding.v1"  # private/preview: SPIFFE workload identity → PAM
AI_TOKEN_FAMILY = (
    "ai-token.v1"  # private/preview: short-lived scoped capability bundles for AI agents
)
AI_POLICY_FAMILY = "keeper-ai-policy.v1"  # private/preview: AI-powered session governance policies
AI_AGENT_FAMILY = "ai-agent.v1"
MCP_ALLOWLIST_FAMILY = "mcp-server-allowlist.v1"
AGENTIC_SKILL_POLICY_FAMILY = "agentic-skill-policy.v1"
AGENT_MEMORY_POLICY_FAMILY = "agent-memory-policy.v1"
WORKFLOW_FAMILY = "keeper-workflow.v1"
PRIVILEGED_ACCESS_FAMILY = "keeper-privileged-access.v1"
TUNNEL_FAMILY = "keeper-tunnel.v1"
SAAS_ROTATION_FAMILY = "keeper-saas-rotation.v1"
ROTATION_POLICY_FAMILY = "rotation-policy.v1"
COMPLIANCE_BUNDLE_FAMILY = "compliance-bundle.v1"
EVIDENCE_STREAM_FAMILY = "continuous-evidence-stream.v1"
PQC_POLICY_FAMILY = "pqc-policy.v1"  # private: post-quantum cryptography migration policy
DORA_PROFILE_FAMILY = "dora-profile.v1"
AI_ACT_PROFILE_FAMILY = "ai-act-profile.v1"
CMMC_PROFILE_FAMILY = "cmmc-profile.v1"
DB_ACCESS_POLICY_FAMILY = "db-access-policy.v1"  # private: KeeperDB session policy for pamDatabase
SCIM_FAMILY = "keeper-scim.v1"  # private: enterprise SCIM provisioning manifest
KEEPER_POLICY_FAMILY = "keeper-policy.v1"  # private/preview: enterprise role policies
PAM_SCHEMA_FILENAME = "pam-environment.v1.schema.json"

# Preview / private mirror only — see scripts/publish.sh OPERATOR_EXCLUDES.
PRIVATE_FAMILIES: frozenset[str] = frozenset(
    {
        NHI_FAMILY,
        JIT_ACCESS_FAMILY,
        CLOUD_JIT_FAMILY,
        SPIFFE_BINDING_FAMILY,
        AI_TOKEN_FAMILY,
        AI_POLICY_FAMILY,
        CSPM_REMEDIATION_FAMILY,
        MCP_SECRETS_BINDING_FAMILY,
        TRUST_CHAIN_FAMILY,
        AGENT_KIT_FAMILY,
        PIPELINE_EPHEMERAL_FAMILY,
        EVIDENCE_STREAM_FAMILY,
        PQC_POLICY_FAMILY,
        SLACK_GATE_FAMILY,
        ITSM_GATE_FAMILY,
        SECRET_SCANNER_FAMILY,
        DORA_PROFILE_FAMILY,
        CMMC_PROFILE_FAMILY,
        DB_ACCESS_POLICY_FAMILY,
        AI_ACT_PROFILE_FAMILY,
        SCIM_FAMILY,
        KEEPER_POLICY_FAMILY,
    }
)
_DEFAULT_MAX_SCHEMA_BYTES = 5 * 1024 * 1024
_DEFAULT_MAX_SCHEMA_DEPTH = 128


def _schema_max_bytes() -> int:
    return positive_int_env("DSK_SCHEMA_MAX_BYTES", _DEFAULT_MAX_SCHEMA_BYTES)


def _schema_max_depth() -> int:
    return positive_int_env("DSK_SCHEMA_MAX_DEPTH", _DEFAULT_MAX_SCHEMA_DEPTH)


def _read_schema_json_file(path: Path, *, label: str) -> dict[str, Any]:
    try:
        data = read_json_file_limited(
            path,
            max_bytes=_schema_max_bytes(),
            max_depth=_schema_max_depth(),
            label=label,
            byte_limit_name="DSK_SCHEMA_MAX_BYTES",
            depth_limit_name="DSK_SCHEMA_MAX_DEPTH",
        )
    except ResourceLimitError as exc:
        raise SchemaError(
            reason=f"{label} exceeds resource limits: {exc}",
            next_action="set DSK_SCHEMA_MAX_BYTES/DSK_SCHEMA_MAX_DEPTH explicitly if trusted",
        ) from exc
    if not isinstance(data, dict):
        raise SchemaError(reason=f"{label} must parse to a JSON object")
    return data


# Canonical registry: manifest ``schema:`` const -> path under dsk.core.schemas
SCHEMA_RESOURCE_BY_FAMILY: dict[str, str] = {
    PAM_FAMILY: PAM_SCHEMA_FILENAME,
    ENTERPRISE_FAMILY: "keeper-enterprise/keeper-enterprise.v1.schema.json",
    EPM_FAMILY: "epm/epm.v1.schema.json",
    EVENTS_FAMILY: "integrations/events.v1.schema.json",
    IDENTITY_FAMILY: "integrations/identity.v1.schema.json",
    KSM_FAMILY: "ksm/ksm.v1.schema.json",
    PAM_EXTENDED_FAMILY: "pam-extended/keeper-pam-extended.v1.schema.json",
    "keeper-security-posture.v1": (
        "keeper-security-posture/keeper-security-posture.v1.schema.json"
    ),
    SHARING_FAMILY: "keeper-vault-sharing/keeper-vault-sharing.v1.schema.json",
    "keeper-vault.v1": "keeper-vault/keeper-vault.v1.schema.json",
    K8S_ESO_FAMILY: "keeper-k8s-eso/keeper-k8s-eso.v1.schema.json",
    SIEM_FAMILY: "keeper-siem/keeper-siem.v1.schema.json",
    TERRAFORM_FAMILY: "keeper-terraform/keeper-terraform.v1.schema.json",
    "msp-environment.v1": "msp-environment/msp-environment.v1.schema.json",
    NHI_FAMILY: "nhi-agent/nhi-agent.v1.schema.json",
    AI_AGENT_FAMILY: "ai-agent/ai-agent.v1.schema.json",
    MCP_ALLOWLIST_FAMILY: ("mcp-server-allowlist/mcp-server-allowlist.v1.schema.json"),
    AGENTIC_SKILL_POLICY_FAMILY: ("agentic-skill-policy/agentic-skill-policy.v1.schema.json"),
    AGENT_MEMORY_POLICY_FAMILY: ("agent-memory-policy/agent-memory-policy.v1.schema.json"),
    WORKFLOW_FAMILY: "workflow/workflow.v1.schema.json",
    PRIVILEGED_ACCESS_FAMILY: ("keeper-privileged-access/keeper-privileged-access.v1.schema.json"),
    TUNNEL_FAMILY: "keeper-tunnel/keeper-tunnel.v1.schema.json",
    SAAS_ROTATION_FAMILY: "keeper-saas-rotation/keeper-saas-rotation.v1.schema.json",
    JIT_ACCESS_FAMILY: "jit-access/jit-access.v1.schema.json",
    PIPELINE_EPHEMERAL_FAMILY: (
        "pipeline-ephemeral-environment/pipeline-ephemeral-environment.v1.schema.json"
    ),
    MCP_SECRETS_BINDING_FAMILY: ("mcp-secrets-binding/mcp-secrets-binding.v1.schema.json"),
    TRUST_CHAIN_FAMILY: ("ai-agent-trust-chain/ai-agent-trust-chain.v1.schema.json"),
    AGENT_KIT_FAMILY: "keeper-agent-kit/keeper-agent-kit.v1.schema.json",
    CLOUD_JIT_FAMILY: "cloud-jit/cloud-jit.v1.schema.json",
    WORKFLOW_GATE_FAMILY: "workflow-gate/workflow-gate.v1.schema.json",
    SLACK_GATE_FAMILY: ("slack-approval-gate/slack-approval-gate.v1.schema.json"),
    ITSM_GATE_FAMILY: ("itsm-approval-gate/itsm-approval-gate.v1.schema.json"),
    GATEWAY_HA_FAMILY: "gateway-ha/gateway-ha.v1.schema.json",
    CONNECTION_PROFILE_FAMILY: ("pam-connection-profile/pam-connection-profile.v1.schema.json"),
    EPM_POLICY_FAMILY: "epm-policy/epm-policy.v1.schema.json",
    SPIFFE_BINDING_FAMILY: "spiffe-binding/spiffe-binding.v1.schema.json",
    AI_TOKEN_FAMILY: "ai-token/ai-token.v1.schema.json",
    AI_POLICY_FAMILY: "keeper-ai-policy/keeper-ai-policy.v1.schema.json",
    ROTATION_POLICY_FAMILY: "rotation-policy/rotation-policy.v1.schema.json",
    COMPLIANCE_BUNDLE_FAMILY: ("compliance-bundle/compliance-bundle.v1.schema.json"),
    CSPM_REMEDIATION_FAMILY: ("cspm-remediation/cspm-remediation.v1.schema.json"),
    SECRET_SCANNER_FAMILY: ("secret-scanner-bridge/secret-scanner-bridge.v1.schema.json"),
    EVIDENCE_STREAM_FAMILY: (
        "continuous-evidence-stream/continuous-evidence-stream.v1.schema.json"
    ),
    PQC_POLICY_FAMILY: "pqc-policy/pqc-policy.v1.schema.json",
    DORA_PROFILE_FAMILY: ("dora-profile/dora-profile.v1.schema.json"),
    AI_ACT_PROFILE_FAMILY: ("ai-act-profile/ai-act-profile.v1.schema.json"),
    CMMC_PROFILE_FAMILY: ("cmmc-profile/cmmc-profile.v1.schema.json"),
    DB_ACCESS_POLICY_FAMILY: ("db-access-policy/db-access-policy.v1.schema.json"),
    SCIM_FAMILY: "keeper-scim/keeper-scim.v1.schema.json",
    KEEPER_POLICY_FAMILY: "keeper-policy/keeper-policy.v1.schema.json",
}

try:
    from dsk.core._private_families import register_private
except ImportError:
    pass
else:
    register_private(SCHEMA_RESOURCE_BY_FAMILY)

# Backward-compat alias used by older imports / docs.
SCHEMA_ID = PAM_SCHEMA_FILENAME


def _manifest_display_name(document: dict[str, Any]) -> str:
    raw = document.get("name")
    if isinstance(raw, str) and raw.strip():
        return raw.strip()
    return "<unnamed>"


def _friendly_jsonschema_required_reason(first: Any, *, document: dict[str, Any]) -> str | None:
    """Return a clearer copy for JSON Schema *required* violations, else None."""
    if getattr(first, "validator", None) != "required":
        return None
    manifest_name = _manifest_display_name(document)
    loc = "/".join(str(part) for part in first.absolute_path) or "<root>"
    msg = str(getattr(first, "message", "") or "")
    field_name = msg.removesuffix(" is a required property").strip()
    if len(field_name) >= 2 and field_name[0] == field_name[-1] and field_name[0] in {'"', "'"}:
        field_name = field_name[1:-1]
    field_display = f"{loc}/{field_name}" if loc != "<root>" else field_name
    return (
        f"manifest {manifest_name!r}: field {field_display!r} is required but missing — "
        "see docs/VALIDATION_STAGES.md"
    )


def _jsonschema_error_location(error: Any) -> str:
    return "/".join(str(part) for part in getattr(error, "absolute_path", ())) or "<root>"


def _safe_jsonschema_error_message(error: Any, *, document: dict[str, Any]) -> str:
    """Summarize a schema error without embedding the failing manifest value."""

    friendly = _friendly_jsonschema_required_reason(error, document=document)
    if friendly is not None:
        return friendly
    validator = str(getattr(error, "validator", "schema") or "schema")
    if validator == "minLength":
        return f"value at {_jsonschema_error_location(error)} must be non-empty"
    return f"value at {_jsonschema_error_location(error)} failed {validator} validation"


def resolve_manifest_family(document: dict[str, Any]) -> str:
    """Return the manifest family key (e.g. ``pam-environment.v1``).

    New families declare ``schema: "<family>.v1"``. Legacy PAM manifests omit
    ``schema`` and use ``version: "1"`` plus ``name``.
    """
    raw = document.get("schema")
    if isinstance(raw, str) and raw.strip():
        key = raw.strip()
        if key not in SCHEMA_RESOURCE_BY_FAMILY:
            known = ", ".join(sorted(SCHEMA_RESOURCE_BY_FAMILY))
            raise SchemaError(
                reason=f"Unknown manifest family {key!r}. Known families: {known}",
                next_action="set schema: to one of the packaged family keys listed in the message",
            )
        return key

    if document.get("version") == "1" and isinstance(document.get("name"), str):
        name = document.get("name")
        assert isinstance(name, str)
        if name.strip():
            return PAM_FAMILY

    raise SchemaError(
        reason="manifest must declare schema: <family>.v1 or legacy PAM fields version+name",
        next_action=(
            "for PAM examples use version: '1' and name: ...; for other families set "
            "schema: keeper-vault.v1 (etc.)"
        ),
    )


def _read_packaged_schema_bytes(family: str) -> str:
    rel = SCHEMA_RESOURCE_BY_FAMILY[family]
    try:
        root = resources.files("dsk.core.schemas")
    except (FileNotFoundError, ModuleNotFoundError, AttributeError, OSError, TypeError) as exc:
        raise SchemaError(
            reason=f"packaged schema namespace unavailable for {family}",
            next_action="reinstall dsk or report a packaging bug",
        ) from exc
    node = root.joinpath(rel)
    try:
        return node.read_text(encoding="utf-8")
    except (FileNotFoundError, OSError) as exc:
        raise SchemaError(
            reason=f"packaged schema not found for {family} ({rel})",
            next_action="reinstall dsk or report a packaging bug",
        ) from exc


def _read_pam_schema_from_sibling_or_env() -> dict[str, Any] | None:
    """Legacy fallbacks for ``pam-environment.v1`` only (dev trees without wheel)."""
    import os

    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent.parent / "keeper-pam-declarative" / "manifests" / PAM_SCHEMA_FILENAME
        if candidate.is_file():
            return _read_schema_json_file(candidate, label="legacy sibling PAM schema")
        candidate2 = parent / "keeper-pam-declarative" / "manifests" / PAM_SCHEMA_FILENAME
        if candidate2.is_file():
            return _read_schema_json_file(candidate2, label="legacy sibling PAM schema")

    override = os.environ.get("KEEPER_DECLARATIVE_SCHEMA")
    if override:
        return _read_schema_json_file(Path(override), label="KEEPER_DECLARATIVE_SCHEMA")
    return None


@cache
def load_schema_for_family(family: str) -> dict[str, Any]:
    """Load the packaged JSON Schema dict for *family* (const matches ``schema:``)."""
    if family not in SCHEMA_RESOURCE_BY_FAMILY:
        known = ", ".join(sorted(SCHEMA_RESOURCE_BY_FAMILY))
        raise SchemaError(
            reason=f"Unknown manifest family {family!r}. Known families: {known}",
            next_action="use resolve_manifest_family or SCHEMA_RESOURCE_BY_FAMILY keys",
        )

    if family == PAM_FAMILY:
        try:
            text = _read_packaged_schema_bytes(PAM_FAMILY)
            return json.loads(text)
        except (
            SchemaError,
            FileNotFoundError,
            OSError,
            ModuleNotFoundError,
            AttributeError,
            TypeError,
            ValueError,
        ):
            blob = _read_pam_schema_from_sibling_or_env()
            if blob is not None:
                return blob
            raise SchemaError(
                reason="manifest schema not found",
                next_action=(
                    "Install dsk with packaged schemas, or set "
                    "KEEPER_DECLARATIVE_SCHEMA to pam-environment.v1.schema.json, "
                    "or clone keeper-pam-declarative alongside this repo."
                ),
            ) from None

    text = _read_packaged_schema_bytes(family)
    return json.loads(text)


def load_schema() -> dict[str, Any]:
    """Load **pam-environment.v1** schema (backward-compatible alias)."""
    return load_schema_for_family(PAM_FAMILY)


def _assert_family_not_dropped(schema: dict[str, Any], *, family: str) -> None:
    block = schema.get("x-keeper-live-proof")
    if not isinstance(block, dict):
        return
    status = block.get("status")
    if status == "dropped-design":
        raise SchemaError(
            reason=(
                f"manifest family {family} is dropped-design — it cannot be used as a "
                "declarative manifest (see docs/V2_DECISIONS.md Q1/Q3)."
            ),
            next_action=(
                "remove the schema pin or use the supported `dsk report` verbs for "
                "read-only posture output."
            ),
        )


_PAM_MODEL_ONLY_SCHEMA_EXTENSION_KEYS: frozenset[str] = frozenset(
    {
        "aal_binding",
        "mtls_binding",
        "dpop_binding",
        "nist_identity",
        "rotation_when",
        "secret_class",
        "must_not_exist",
        "drift_policy",
    }
)


def _strip_pam_model_only_schema_extensions(node: Any) -> Any:
    """Remove Python-model-only extension keys so the document matches the published JSON Schema.

    These fields live in the ``Manifest`` Pydantic model (e.g. ``must_not_exist``,
    ``drift_policy``) but are absent from the ``pam-environment.v1`` JSON Schema.
    Stripping them lets ``validate_manifest`` pass without false-positive schema
    errors when a serialised manifest is re-validated from disk.
    """
    if isinstance(node, dict):
        return {
            k: _strip_pam_model_only_schema_extensions(v)
            for k, v in node.items()
            if k not in _PAM_MODEL_ONLY_SCHEMA_EXTENSION_KEYS
        }
    if isinstance(node, list):
        return [_strip_pam_model_only_schema_extensions(item) for item in node]
    return node


def validate_manifest(document: dict[str, Any]) -> str:
    """Validate *document* against its family's JSON Schema.

    Returns the resolved family key (e.g. ``pam-environment.v1``).

    Raises :class:`SchemaError` if the family is ``dropped-design`` or the
    document fails schema / semantic rules.
    """
    from dsk.core.rules import apply_semantic_rules

    family = resolve_manifest_family(document)

    if family == PAM_FAMILY:
        # Strip Python-model-only extension fields before JSON-Schema validation.
        # These fields (must_not_exist, drift_policy, …) are part of the Manifest
        # Pydantic model but absent from the published pam-environment.v1 schema.
        document = _strip_pam_model_only_schema_extensions(document)

    try:
        import jsonschema
    except ImportError:
        if family != PAM_FAMILY:
            raise SchemaError(
                reason="jsonschema is required to validate non-PAM manifest families",
                next_action="pip install jsonschema",
            ) from None
        _validate_with_pydantic(document)
        apply_semantic_rules(document)
        return family

    schema = load_schema_for_family(family)
    _assert_family_not_dropped(schema, family=family)

    validator = jsonschema.Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(document), key=lambda error: list(error.absolute_path))
    if errors:
        enterprise_stub_error = _enterprise_legacy_stub_error(
            family=family,
            document=document,
            error_count=len(errors),
        )
        if enterprise_stub_error is not None:
            raise enterprise_stub_error
        first = errors[0]
        location = _jsonschema_error_location(first)
        reason_text = _safe_jsonschema_error_message(first, document=document)
        raise SchemaError(
            reason=f"manifest failed schema: {reason_text}",
            context={
                "family": family,
                "location": location,
                "error_count": len(errors),
                "additional": [
                    {
                        "path": _jsonschema_error_location(extra),
                        "message": _safe_jsonschema_error_message(extra, document=document),
                    }
                    for extra in errors[1:5]
                ],
            },
            next_action="fix the reported fields then re-run `dsk validate`",
        )

    apply_semantic_rules(document)
    return family


def _enterprise_legacy_stub_error(
    *,
    family: str,
    document: dict[str, Any],
    error_count: int,
) -> SchemaError | None:
    """Keep the old Phase-7 empty-stub failure copy for partial team/role rows."""
    if family != ENTERPRISE_FAMILY:
        return None
    for collection in ("teams", "roles"):
        rows = document.get(collection)
        if not isinstance(rows, list) or not rows:
            continue
        if not all(_is_legacy_team_role_stub(row) for row in rows):
            continue
        return SchemaError(
            reason=(
                f"manifest failed schema: {collection} is expected to be empty unless "
                "rows use the full keeper-enterprise.v1 shape"
            ),
            context={
                "family": family,
                "location": collection,
                "error_count": error_count,
                "additional": [],
            },
            next_action="add node_uid_ref and supported membership fields, or leave the block empty",
        )
    return None


def _is_legacy_team_role_stub(row: Any) -> bool:
    if not isinstance(row, dict):
        return False
    return set(row).issubset({"uid_ref", "name"})


def _validate_with_pydantic(document: dict[str, Any]) -> None:
    from pydantic import ValidationError

    from dsk.core.models import Manifest

    try:
        Manifest.model_validate(document)
    except ValidationError as exc:
        errors = exc.errors()
        manifest_name = _manifest_display_name(document)
        first = errors[0]
        if first.get("type") == "missing":
            loc = ".".join(str(part) for part in first.get("loc", ()))
            raise SchemaError(
                reason=(
                    f"manifest {manifest_name!r}: field {loc!r} is required but missing — "
                    "see docs/VALIDATION_STAGES.md"
                ),
                context={"errors": errors[:5], "error_count": len(errors)},
                next_action="fix the reported fields then re-run `keeper-sdk validate`",
            ) from exc
        raise SchemaError(
            reason="manifest failed typed validation",
            context={"errors": errors[:5], "error_count": len(errors)},
            next_action="fix the reported fields then re-run `keeper-sdk validate`",
        ) from exc


def packaged_schema_families() -> tuple[str, ...]:
    """Stable list of family keys shipped in ``dsk.core.schemas``."""
    return tuple(sorted(SCHEMA_RESOURCE_BY_FAMILY.keys()))
