"""Desired-vs-live diff for ``dora-profile.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_dora import DoraProfileManifestV1


def compute_dora_diff(
    manifest: DoraProfileManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared DORA control resource."""
    if live:
        raise NotImplementedError("dora-profile.v1 live readback not implemented")

    name = manifest_name or "dora-profile.v1"
    changes: list[Change] = []

    for idx, control in enumerate(manifest.controls):
        payload = control.model_dump(mode="python", exclude_none=True)
        article = getattr(control, "article", None)
        uid_ref = article or getattr(control, "uid_ref", None) or f"{name}.{idx}"
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=str(uid_ref),
                resource_type="dora_control",
                title=str(article) if article else str(uid_ref),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_dora_diff"]
