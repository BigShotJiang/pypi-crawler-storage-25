"""Typed models for ``agentic-skill-policy.v1`` manifests.

Declarative allowlist of approved AI agent skills/plugins per role.
Addresses OWASP Agentic Skills Top 10 (AST10, Q1 2026):
36.82% of scanned skills contain security flaws; 13.4% critical.
"""

from __future__ import annotations

from typing import Annotated, Any, Literal, TypeAlias

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    model_validator,
)

from dsk.core.errors import SchemaError

AGENTIC_SKILL_POLICY_FAMILY: Literal["agentic-skill-policy.v1"] = "agentic-skill-policy.v1"

UidRef: TypeAlias = Annotated[
    str,
    StringConstraints(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
NonEmptyString: TypeAlias = Annotated[str, StringConstraints(min_length=1)]


class _AgenticSkillPolicyModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid", str_strip_whitespace=True)


class SkillEntry(_AgenticSkillPolicyModel):
    """One approved agent skill or plugin entry."""

    uid_ref: UidRef
    name: NonEmptyString
    skill_id: NonEmptyString
    platform: Literal["cursor", "claude", "codex", "copilot", "vscode", "gemini", "any"]
    version_constraint: str | None = None
    sha256_pin: str | None = None
    approved_by: str | None = None
    approved_at: str | None = None
    risk_level: Literal["low", "medium", "high", "critical"] = "medium"
    allowed_operations: list[str] = Field(default_factory=list)
    denied_operations: list[str] = Field(default_factory=list)
    requires_human_approval: bool = False
    audit_log_enabled: bool = True
    tags: dict[str, str] = Field(default_factory=dict)


class AgentRolePolicy(_AgenticSkillPolicyModel):
    """Policy mapping one agent role to allowed skills."""

    uid_ref: UidRef
    role_name: NonEmptyString
    allowed_skill_refs: list[str] = Field(default_factory=list)
    deny_unlisted: bool = True
    max_concurrent_skills: int | None = None
    session_timeout_minutes: int | None = None


class AgenticSkillPolicyManifest(_AgenticSkillPolicyModel):
    """Top-level ``agentic-skill-policy.v1`` manifest."""

    agentic_skill_policy_schema: Literal["agentic-skill-policy.v1"] = Field(
        default=AGENTIC_SKILL_POLICY_FAMILY,
        alias="schema",
    )
    name: NonEmptyString
    skills: list[SkillEntry] = Field(default_factory=list)
    role_policies: list[AgentRolePolicy] = Field(default_factory=list)

    @model_validator(mode="after")
    def _uid_refs_and_skill_refs(self) -> AgenticSkillPolicyManifest:
        seen: dict[str, str] = {}
        duplicates: set[str] = set()
        for skill in self.skills:
            if skill.uid_ref in seen:
                duplicates.add(skill.uid_ref)
            seen[skill.uid_ref] = "skill"
        for role in self.role_policies:
            if role.uid_ref in seen:
                duplicates.add(role.uid_ref)
            seen[role.uid_ref] = "role"
        if duplicates:
            raise ValueError(f"duplicate uid_ref values: {sorted(duplicates)}")
        skill_uid_set = {s.uid_ref for s in self.skills}
        for role in self.role_policies:
            for ref in role.allowed_skill_refs:
                if ref not in skill_uid_set:
                    raise ValueError(
                        f"role {role.uid_ref!r} allowed_skill_refs references unknown "
                        f"skill uid_ref {ref!r}"
                    )
        return self

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        """Return ``(uid_ref, kind)`` for skills and role policies."""
        out: list[tuple[str, str]] = [(s.uid_ref, "skill") for s in self.skills]
        out.extend((r.uid_ref, "role") for r in self.role_policies)
        return out


def load_agentic_skill_policy_manifest(document: dict[str, Any]) -> AgenticSkillPolicyManifest:
    """Validate with JSON Schema, then parse as ``AgenticSkillPolicyManifest``."""
    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != AGENTIC_SKILL_POLICY_FAMILY:
        raise SchemaError(
            reason=f"expected {AGENTIC_SKILL_POLICY_FAMILY!r}, got {family!r}",
            next_action="set schema: agentic-skill-policy.v1 on the manifest",
        )
    try:
        return AgenticSkillPolicyManifest.model_validate(document)
    except ValidationError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match agentic-skill-policy.v1 typed rules",
        ) from exc
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match agentic-skill-policy.v1 typed rules",
        ) from exc


__all__ = [
    "AGENTIC_SKILL_POLICY_FAMILY",
    "AgentRolePolicy",
    "AgenticSkillPolicyManifest",
    "SkillEntry",
    "load_agentic_skill_policy_manifest",
]
