"""Post-quantum cryptography policy models — pqc-policy.v1.

Declares PQC requirements for Keeper records and PAM resources.
Tracks migration from classical to post-quantum cryptography.

Source: Keeper Kyber live Feb 25, 2026. NSM-10: federal PQC mandate by 2030.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class PqcAlgorithm(StrEnum):
    kyber_768 = "kyber-768"  # NIST ML-KEM-768 (Keeper native)
    kyber_1024 = "kyber-1024"  # NIST ML-KEM-1024 (highest security)
    dilithium_3 = "dilithium-3"  # NIST ML-DSA-65 (signature)
    hybrid_classical_pqc = "hybrid-classical-pqc"  # transitional hybrid mode


class PqcMigrationStatus(StrEnum):
    not_started = "not_started"
    in_progress = "in_progress"
    completed = "completed"
    exempt = "exempt"  # explicitly exempted with justification


class PqcComplianceFramework(StrEnum):
    nsm10 = "nsm-10"  # US National Security Memorandum 10
    nist_pqc = "nist-pqc"  # NIST Post-Quantum Standards
    fedramp_pqc = "fedramp-pqc"  # FedRAMP PQC requirements
    bsi_pqc = "bsi-pqc"  # German BSI PQC guidance


class PqcResourceRequirement(BaseModel):
    uid_ref: str = Field(
        ...,
        description="DSK uid_ref of the record/resource requiring PQC",
    )
    required_algorithm: PqcAlgorithm = PqcAlgorithm.kyber_768
    migration_deadline: str | None = Field(
        None,
        description="ISO 8601 date by which PQC must be enabled, e.g. 2027-12-31",
    )
    current_status: PqcMigrationStatus = PqcMigrationStatus.not_started
    exemption_justification: str | None = Field(
        None,
        description="Required when current_status=exempt",
    )


class PqcPolicyManifestV1(BaseModel):
    """Root model for a pqc-policy.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("pqc-policy.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    frameworks: list[PqcComplianceFramework] = Field(default_factory=list)
    default_algorithm: PqcAlgorithm = PqcAlgorithm.kyber_768
    migration_deadline: str | None = Field(
        None,
        description="Global deadline for all resources unless overridden per-resource",
    )
    requirements: list[PqcResourceRequirement] = Field(default_factory=list)
    audit_log: bool = Field(True)
