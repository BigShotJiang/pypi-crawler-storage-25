"""Keeper field-name normalization helpers."""

from __future__ import annotations

import re
from typing import Any

_FIELD_NAME_TOKEN_RE = re.compile(r"[^0-9a-z]+")


def _field_name_candidates(name: Any) -> list[str]:
    raw = str(name or "").strip()
    if not raw:
        return []
    candidates = [raw]
    if raw.startswith("$"):
        body = raw[1:]
        candidates.append(body)
        if ":" in body:
            field_type, label = body.split(":", 1)
            candidates.extend([label, field_type])
    return candidates


def norm_field_name(name: Any) -> str:
    """Normalize a Keeper field label/type for tolerant matching."""
    candidates = _field_name_candidates(name)
    raw = candidates[0] if candidates else ""
    if raw.startswith("$") and ":" in raw:
        field_type, label = raw[1:].split(":", 1)
        raw = label or field_type
    elif raw.startswith("$"):
        raw = raw[1:]
    return _FIELD_NAME_TOKEN_RE.sub("", raw.casefold())


def field_name_variants(name: Any) -> set[str]:
    """Return normalized variants, including both sides of ``$type:label``."""
    return {
        _FIELD_NAME_TOKEN_RE.sub("", candidate.casefold())
        for candidate in _field_name_candidates(name)
        if candidate
    }


def field_name_matches(left: Any, right: Any) -> bool:
    """Return true when two Keeper field names are literal or normalized matches."""
    left_raw = str(left or "").strip()
    right_raw = str(right or "").strip()
    if left_raw and right_raw and left_raw == right_raw:
        return True
    return bool(field_name_variants(left_raw) & field_name_variants(right_raw))
