"""AI agent capability token models — ai-token.v1.

Capability tokens are short-lived, scoped credential bundles issued to AI agents
for the duration of a single task. They expire automatically (no standing access).
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator


class TokenScope(StrEnum):
    read = "read"  # read-only access to bound resources
    execute = "execute"  # execute access (e.g. run PAM tunnel)
    admin = "admin"  # admin access (high-risk, requires dual approval)


class TokenRevocationTrigger(StrEnum):
    expiry = "expiry"  # auto-revoke on TTL expiry
    task_complete = "task_complete"  # revoke when agent signals task done
    error = "error"  # revoke immediately on agent error signal
    any = "any"  # first of the above to fire


class FederationType(StrEnum):
    github_actions = "github_actions"
    google_wif = "google_wif"
    aws_oidc = "aws_oidc"
    azure_wif = "azure_wif"
    spiffe = "spiffe"
    custom = "custom"


class WorkloadIdentityBinding(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    federation_type: FederationType
    issuer_uri: str  # OIDC issuer URL
    subject_pattern: str  # e.g. "repo:acme-org/acme-repo:ref:refs/heads/main"
    audience: str | None = None
    max_token_lifetime_seconds: int = Field(3600, ge=60, le=86400)


class AiTokenResourceBinding(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    uid_ref: str = Field(..., description="DSK uid_ref of the Keeper PAM resource")
    scope: TokenScope = TokenScope.read
    allow_secret_fetch: bool = Field(
        True,
        description="Allow fetching secrets within the bound resource",
    )
    allow_connection: bool = Field(
        False,
        description="Allow PAM tunnel/RDP/SSH connection (higher risk)",
    )


class AiCapabilityToken(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: str | None = None
    agent_uid_ref: str = Field(
        ...,
        description="uid_ref of the AI agent identity resource that receives this token",
    )
    resources: list[AiTokenResourceBinding] = Field(default_factory=list)
    workload_identity: WorkloadIdentityBinding | None = None
    ttl_seconds: int = Field(
        900,
        ge=60,
        le=86400,
        description=(
            "Token lifetime in seconds. Static credential tokens: 60s–1h. "
            "Federation: capped by workload_identity.max_token_lifetime_seconds."
        ),
    )
    revocation: TokenRevocationTrigger = TokenRevocationTrigger.any
    audit_log: bool = Field(True)
    max_issuances_per_hour: int = Field(
        10,
        ge=1,
        description="Rate-limit: max tokens issued per agent per hour",
    )

    @model_validator(mode="after")
    def _ttl_vs_workload_identity(self) -> AiCapabilityToken:
        if self.workload_identity is None:
            if self.ttl_seconds > 3600:
                raise ValueError(
                    "ttl_seconds must be <= 3600 when workload_identity is not set (static credential)"
                )
        elif self.ttl_seconds > self.workload_identity.max_token_lifetime_seconds:
            raise ValueError(
                "ttl_seconds must be <= workload_identity.max_token_lifetime_seconds "
                f"when workload_identity is set (got ttl_seconds={self.ttl_seconds}, "
                f"max_token_lifetime_seconds={self.workload_identity.max_token_lifetime_seconds})"
            )
        return self


class AiTokenManifestV1(BaseModel):
    """Root model for an ai-token.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("ai-token.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    tokens: list[AiCapabilityToken] = Field(default_factory=list)
