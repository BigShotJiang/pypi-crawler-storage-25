"""ITSM approval gate models — itsm-approval-gate.v1.

Declares ServiceNow / Jira Service Management approval gate for DSK apply.
Trigger: Keeper ServiceNow ITSM integration GA December 10, 2025.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class ItsmPlatform(StrEnum):
    servicenow = "servicenow"
    jira_sm = "jira_sm"  # Jira Service Management


class ItsmApprovalState(StrEnum):
    approved = "approved"
    approved_with_conditions = "approved_with_conditions"
    pending = "pending"
    rejected = "rejected"


class ItsmChangeCategory(StrEnum):
    normal = "normal"  # standard change request
    standard = "standard"  # pre-approved change template
    emergency = "emergency"  # expedited CAB approval


class ItsmGatePolicy(StrEnum):
    block_on_pending = "block_on_pending"  # block apply if ticket pending
    require_approved = "require_approved"  # must be in approved state
    require_implementation_window = "require_implementation_window"  # must be in active window


class ItsmApprovalGate(BaseModel):
    name: str
    platform: ItsmPlatform = ItsmPlatform.servicenow
    instance_url_env: str = Field(
        "SERVICENOW_INSTANCE_URL",
        description="Env var holding the ServiceNow/Jira instance base URL",
    )
    api_token_env: str = Field(
        "ITSM_API_TOKEN",
        description="Env var holding the API token / OAuth2 token",
    )
    change_category: ItsmChangeCategory = ItsmChangeCategory.normal
    required_state: ItsmApprovalState = ItsmApprovalState.approved
    policy: ItsmGatePolicy = ItsmGatePolicy.require_approved
    assignment_group: str | None = Field(
        None,
        description="ServiceNow assignment group or Jira SM team for the change request",
    )
    auto_create_ticket: bool = Field(
        False,
        description="Auto-create a change request if none is supplied",
    )
    ticket_template: str | None = Field(
        None,
        description="ServiceNow change template sys_id or Jira SM request type ID",
    )


class ItsmApprovalGateManifestV1(BaseModel):
    """Root model for an itsm-approval-gate.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("itsm-approval-gate.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    gates: list[ItsmApprovalGate] = Field(default_factory=list)
    default_gate: str | None = Field(
        None,
        description="Name of gate applied when no specific gate is requested",
    )
