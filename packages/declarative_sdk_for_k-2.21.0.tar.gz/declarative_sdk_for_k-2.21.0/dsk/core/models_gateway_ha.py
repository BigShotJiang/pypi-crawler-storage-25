"""Gateway HA cluster manifest models — gateway-ha.v1.

Declares Keeper PAM gateway high-availability clusters.
Models the cluster topology, failover behavior, and load balancing.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class GatewayHaStrategy(StrEnum):
    active_passive = "active_passive"  # one active, others on standby
    active_active = "active_active"  # all gateways serve traffic (round-robin)
    weighted = "weighted"  # weighted round-robin


class GatewayHaMember(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    uid_ref: str = Field(
        ...,
        description="uid_ref of the existing gateway in pam-environment.v1",
    )
    priority: int = Field(
        100,
        ge=1,
        le=1000,
        description="Priority in active_passive (higher = preferred)",
    )
    weight: int = Field(
        1,
        ge=1,
        description="Weight in weighted strategy",
    )
    labels: dict[str, str] = Field(
        default_factory=dict,
        description="Key-value labels for routing (e.g. region: us-east-1)",
    )


class GatewayHaHealthCheck(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    interval_seconds: int = Field(30, ge=5)
    timeout_seconds: int = Field(10, ge=1)
    failure_threshold: int = Field(
        3,
        ge=1,
        description="Consecutive failures before marking gateway unhealthy",
    )
    recovery_threshold: int = Field(
        2,
        ge=1,
        description="Consecutive successes before marking gateway healthy again",
    )


class GatewayHaCluster(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: str | None = None
    strategy: GatewayHaStrategy = GatewayHaStrategy.active_passive
    members: list[GatewayHaMember] = Field(
        default_factory=list,
        description="Gateway members in this cluster (min 2 for HA)",
    )
    health_check: GatewayHaHealthCheck = Field(default_factory=lambda: GatewayHaHealthCheck())  # type: ignore[call-arg]
    failover_delay_seconds: int = Field(
        0,
        ge=0,
        description="Seconds to wait before failing over (0 = immediate)",
    )
    session_persistence: bool = Field(
        False,
        description="Maintain session affinity to a specific gateway member",
    )


class GatewayHaManifestV1(BaseModel):
    """Root model for a gateway-ha.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("gateway-ha.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    clusters: list[GatewayHaCluster] = Field(default_factory=list)


GATEWAY_HA_FAMILY: str = "gateway-ha.v1"

__all__ = [
    "GATEWAY_HA_FAMILY",
    "GatewayHaCluster",
    "GatewayHaHealthCheck",
    "GatewayHaManifestV1",
    "GatewayHaMember",
    "GatewayHaStrategy",
]
