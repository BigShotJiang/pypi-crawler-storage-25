"""SPIFFE runtime — JWT-SVID validation against SpiffeBindingManifestV1 rules.

Uses SPIRE HTTP federation bundle endpoint (no gRPC required).
SPIRE exposes JWKS at: http://<server>:8081/v1/jwks/<trust_domain>
"""

from __future__ import annotations

import base64
import json
import re
import time
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from dsk.core.models_spiffe import SpiffeBindingManifestV1, SpiffeIdentityRule

try:
    import jwt
except ImportError:
    jwt = None  # type: ignore[assignment]

try:
    import requests  # type: ignore[import-untyped]
except ImportError:
    requests = None  # type: ignore[assignment]


@dataclass
class SpiffeVerifyResult:
    spiffe_id: str
    trust_domain: str
    matched_rules: list[str]
    granted_resources: list[str]
    jit_required: list[str]
    expires_at: str
    offline_only: bool = False


class SpiffeRuntimeError(Exception):
    def __init__(self, message: str, spiffe_id: str = "", next_action: str = "") -> None:
        super().__init__(message)
        self.message = message
        self.spiffe_id = spiffe_id
        self.next_action = next_action

    def __str__(self) -> str:
        if self.next_action:
            return f"{self.message}; next_action: {self.next_action}"
        return self.message


class SpiffeRuleEvaluator:
    def match(
        self,
        spiffe_id: str,
        rules: Iterable[SpiffeIdentityRule],
    ) -> tuple[list[str], list[str], list[str]]:
        trust_domain = _trust_domain_from_spiffe_id(spiffe_id)
        matched_rules: list[str] = []
        granted_resources: list[str] = []
        jit_required: list[str] = []

        for rule in rules:
            if rule.trust_domain != trust_domain:
                continue
            match_mode = str(getattr(rule.match, "value", rule.match))
            if not self._matches(spiffe_id, rule.spiffe_id, match_mode):
                continue
            matched_rules.append(rule.spiffe_id)
            for resource in rule.resources:
                granted_resources.append(resource.uid_ref)
                if rule.allow_jit:
                    jit_required.append(resource.uid_ref)

        return _dedupe(matched_rules), _dedupe(granted_resources), _dedupe(jit_required)

    def _matches(self, spiffe_id: str, pattern: str, match_mode: str) -> bool:
        if match_mode == "exact":
            return spiffe_id == pattern
        if match_mode == "prefix":
            return spiffe_id.startswith(pattern)
        if match_mode == "regex":
            try:
                return re.fullmatch(pattern, spiffe_id) is not None
            except re.error:
                return False
        return False


class SpiffeRuntime:
    def __init__(
        self,
        jwks_url: str = "http://localhost:8081",
        socket_path: str = "/tmp/spire-agent/api.sock",
        trust_domain: str = "acme.com",
        timeout_seconds: float = 5.0,
    ) -> None:
        self.jwks_url = jwks_url.rstrip("/")
        self.socket_path = socket_path
        self.trust_domain = trust_domain
        self.timeout_seconds = timeout_seconds
        self._jwks_cache: dict[str, Any] | None = None
        self._jwks_cache_expires_at = 0.0

    def _fetch_jwks(self) -> dict[str, Any]:
        now = time.monotonic()
        if self._jwks_cache is not None and now < self._jwks_cache_expires_at:
            return self._jwks_cache
        if requests is None:
            raise SpiffeRuntimeError(
                "requests is not installed",
                next_action=(
                    "install requests or use --offline; for local SPIRE run "
                    "`cd scripts/spire && bash bootstrap.sh`"
                ),
            )

        url = f"{self.jwks_url}/v1/jwks/{self.trust_domain}"
        try:
            response = requests.get(url, timeout=self.timeout_seconds)
            raise_for_status = getattr(response, "raise_for_status", None)
            if callable(raise_for_status):
                raise_for_status()
            data = response.json()
        except Exception as exc:
            raise SpiffeRuntimeError(
                "failed to fetch SPIRE JWKS",
                next_action=(
                    f"start local SPIRE with `cd scripts/spire && bash bootstrap.sh`; "
                    f"verify JWKS URL {url}"
                ),
            ) from exc

        if not isinstance(data, dict) or not isinstance(data.get("keys"), list):
            raise SpiffeRuntimeError(
                "SPIRE JWKS response is not a JWKS document",
                next_action=(
                    f"check {url}; for local SPIRE run `cd scripts/spire && bash bootstrap.sh`"
                ),
            )

        self._jwks_cache = dict(data)
        self._jwks_cache_expires_at = now + 60
        return self._jwks_cache

    def verify_jwt(
        self,
        token: str,
        manifest_doc: SpiffeBindingManifestV1 | Mapping[str, Any],
    ) -> SpiffeVerifyResult:
        if jwt is None:
            raise SpiffeRuntimeError(
                "PyJWT is not installed",
                next_action=(
                    "install PyJWT and requests, or use --offline; for local SPIRE run "
                    "`cd scripts/spire && bash bootstrap.sh`"
                ),
            )

        manifest = _coerce_manifest(manifest_doc)
        jwks = self._fetch_jwks()
        try:
            header = jwt.get_unverified_header(token)
        except Exception as exc:
            raise SpiffeRuntimeError(
                "JWT-SVID header is invalid",
                next_action="mint a fresh token with `cd scripts/spire && bash bootstrap.sh`",
            ) from exc

        signing_key, algorithm = self._signing_key_from_jwks(jwks, header)
        try:
            claims = jwt.decode(
                token,
                key=signing_key,
                algorithms=[algorithm],
                options={"verify_aud": False},
            )
        except Exception as exc:
            spiffe_id = _spiffe_id_from_unverified_token(token)
            raise SpiffeRuntimeError(
                "JWT-SVID verification failed",
                spiffe_id=spiffe_id,
                next_action=(
                    "confirm token was minted by the configured SPIRE server; "
                    "for local SPIRE run `cd scripts/spire && bash bootstrap.sh`"
                ),
            ) from exc

        if not isinstance(claims, dict):
            raise SpiffeRuntimeError(
                "JWT-SVID claims are not a JSON object",
                next_action="mint a fresh token with `cd scripts/spire && bash bootstrap.sh`",
            )
        return _result_from_claims(claims, manifest, offline_only=False)

    def verify_jwt_offline(
        self,
        token: str,
        manifest_doc: SpiffeBindingManifestV1 | Mapping[str, Any],
    ) -> SpiffeVerifyResult:
        manifest = _coerce_manifest(manifest_doc)
        claims = _decode_unverified_claims(token)
        return _result_from_claims(claims, manifest, offline_only=True)

    def _signing_key_from_jwks(
        self,
        jwks: Mapping[str, Any],
        header: Mapping[str, Any],
    ) -> tuple[Any, str]:
        keys = jwks.get("keys")
        if not isinstance(keys, list):
            raise SpiffeRuntimeError(
                "JWKS has no keys",
                next_action="restart SPIRE with `cd scripts/spire && bash bootstrap.sh`",
            )
        kid = header.get("kid")
        for raw_key in keys:
            if not isinstance(raw_key, dict):
                continue
            if kid is not None and raw_key.get("kid") != kid:
                continue
            algorithm = str(header.get("alg") or raw_key.get("alg") or "")
            if not algorithm or algorithm == "none":
                raise SpiffeRuntimeError(
                    "JWT-SVID uses an unsupported algorithm",
                    next_action="mint a signed JWT-SVID with `cd scripts/spire && bash bootstrap.sh`",
                )
            try:
                return jwt.PyJWK.from_dict(raw_key).key, algorithm
            except Exception:
                return raw_key, algorithm

        raise SpiffeRuntimeError(
            "JWT-SVID key id was not found in SPIRE JWKS",
            next_action="mint a fresh token with `cd scripts/spire && bash bootstrap.sh`",
        )


def _coerce_manifest(
    manifest_doc: SpiffeBindingManifestV1 | Mapping[str, Any],
) -> SpiffeBindingManifestV1:
    if isinstance(manifest_doc, SpiffeBindingManifestV1):
        return manifest_doc
    try:
        return SpiffeBindingManifestV1.model_validate(dict(manifest_doc))
    except Exception as exc:
        raise SpiffeRuntimeError(
            "spiffe-binding manifest is invalid",
            next_action="fix manifest schema before running spiffe-verify",
        ) from exc


def _result_from_claims(
    claims: Mapping[str, Any],
    manifest: SpiffeBindingManifestV1,
    *,
    offline_only: bool,
) -> SpiffeVerifyResult:
    spiffe_id = claims.get("sub")
    if not isinstance(spiffe_id, str) or not spiffe_id.startswith("spiffe://"):
        raise SpiffeRuntimeError(
            "JWT-SVID subject is not a SPIFFE ID",
            next_action="mint a JWT-SVID with a spiffe:// subject",
        )

    trust_domain = _trust_domain_from_spiffe_id(spiffe_id)
    matched_rules, granted_resources, jit_required = SpiffeRuleEvaluator().match(
        spiffe_id,
        manifest.rules,
    )
    return SpiffeVerifyResult(
        spiffe_id=spiffe_id,
        trust_domain=trust_domain,
        matched_rules=matched_rules,
        granted_resources=granted_resources,
        jit_required=jit_required,
        expires_at=_expires_at(claims.get("exp")),
        offline_only=offline_only,
    )


def _decode_unverified_claims(token: str) -> dict[str, Any]:
    parts = token.split(".")
    if len(parts) < 2:
        raise SpiffeRuntimeError(
            "JWT-SVID is not a compact JWT",
            next_action="pass --jwt or --jwt-file containing a compact JWT-SVID",
        )
    try:
        payload = json.loads(_b64url_decode(parts[1]).decode("utf-8"))
    except Exception as exc:
        raise SpiffeRuntimeError(
            "JWT-SVID payload is not valid JSON",
            next_action="mint a fresh token with `cd scripts/spire && bash bootstrap.sh`",
        ) from exc
    if not isinstance(payload, dict):
        raise SpiffeRuntimeError(
            "JWT-SVID payload is not a JSON object",
            next_action="mint a fresh token with `cd scripts/spire && bash bootstrap.sh`",
        )
    return payload


def _spiffe_id_from_unverified_token(token: str) -> str:
    try:
        claims = _decode_unverified_claims(token)
    except SpiffeRuntimeError:
        return ""
    sub = claims.get("sub")
    return sub if isinstance(sub, str) else ""


def _b64url_decode(value: str) -> bytes:
    padding = "=" * ((4 - len(value) % 4) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def _trust_domain_from_spiffe_id(spiffe_id: str) -> str:
    if not spiffe_id.startswith("spiffe://"):
        return ""
    rest = spiffe_id.removeprefix("spiffe://")
    return rest.split("/", 1)[0]


def _expires_at(value: Any) -> str:
    if isinstance(value, int | float):
        return datetime.fromtimestamp(value, tz=UTC).isoformat().replace("+00:00", "Z")
    if isinstance(value, str):
        if value.isdigit():
            return datetime.fromtimestamp(int(value), tz=UTC).isoformat().replace("+00:00", "Z")
        return value
    return ""


def _dedupe(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


__all__ = ["SpiffeRuntime", "SpiffeRuntimeError", "SpiffeVerifyResult"]
