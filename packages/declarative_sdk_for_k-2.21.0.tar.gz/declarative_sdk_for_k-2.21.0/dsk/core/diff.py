"""Change classification between desired (manifest) and observed (provider)."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from dsk.core.errors import CollisionError, OwnershipError
from dsk.core.field_names import field_name_matches, norm_field_name
from dsk.core.interfaces import LiveRecord
from dsk.core.metadata import MANAGER_NAME, MARKER_FIELD_LABEL, MARKER_VERSION
from dsk.core.models import Manifest
from dsk.core.normalize import normalize_rbi_repeatable_connection_list

ConflictError = CollisionError


class ChangeKind(StrEnum):
    """Classification of a single planned change.

    * ``CREATE`` / ``ADD`` — manifest describes a resource that does not exist in
      the vault yet.
    * ``ADD`` — backwards-compatible alias for ``CREATE`` used by newer
      sibling-block diff helpers.
    * ``UPDATE`` — manifest and vault both carry the resource but their
      fields drift. Only raised when drift is detected on declarative
      (manifest-owned) fields — SDK-internal placement metadata is
      ignored via :data:`_DIFF_IGNORED_FIELDS`.
    * ``DELETE`` — vault carries a record with an ownership marker whose
      ``uid_ref`` is absent from the manifest. Requires
      ``allow_delete=True`` on ``compute_diff``.
    * ``NOOP`` — manifest and vault agree; no action required.
    * ``SKIP`` — a non-actionable observed object is intentionally left
      untouched, usually because it is unmanaged by this SDK or because
      a managed live object is missing from the manifest without
      ``allow_delete``.
    * ``CONFLICT`` — a situation the planner cannot resolve automatically
      (name collision, ambiguous marker, incompatible type). Operator
      must resolve before re-running.
    """

    CREATE = "create"
    ADD = "create"
    UPDATE = "update"
    DELETE = "delete"
    NOOP = "noop"
    SKIP = "skip"
    CONFLICT = "conflict"


@dataclass
class Change:
    """One row of a :class:`Plan`.

    Attributes:
        kind: Classification — see :class:`ChangeKind`.
        uid_ref: Manifest handle. ``None`` only for deletes on records
            that never had a declarative owner (should be rare).
        resource_type: Declarative type (``pamMachine``, ``gateway``, …).
        title: Human-facing identifier used by renderers and by
            Commander ``pam project import`` to match records.
        keeper_uid: Vault UID of the matched live record; ``None`` on
            pure creates.
        before / after: Normalised field dicts for diff rendering.
        reason: Optional human-readable explanation (used for NOOP /
            CONFLICT rows).
        manifest_name: Optional manifest identifier for synthetic rows that
            do not map to a live record marker.
    """

    kind: ChangeKind
    uid_ref: str | None
    resource_type: str
    title: str
    keeper_uid: str | None = None
    before: dict[str, Any] = field(default_factory=dict)
    after: dict[str, Any] = field(default_factory=dict)
    reason: str | None = None
    manifest_name: str | None = None


_MANAGED_TYPES = (
    "gateway",
    "pam_configuration",
    "pamMachine",
    "pamDatabase",
    "pamDirectory",
    "pamRemoteBrowser",
    "pamUser",
    "login",
)

# RBI connection keys backed by Commander repeated flags (order-sensitive).
_RBI_REPEATABLE_CONNECTION_KEYS = frozenset(
    {"autofill_targets", "allowed_url_patterns", "allowed_resource_url_patterns"}
)


def _desired_objects(manifest: Manifest) -> list[tuple[str, str, str, dict[str, Any]]]:
    """Yield (uid_ref, resource_type, title, payload) for every managed object."""
    out: list[tuple[str, str, str, dict[str, Any]]] = []
    data = manifest.model_dump(mode="python", exclude_none=True)

    for gateway in data.get("gateways") or []:
        if gateway.get("mode") == "create":
            out.append((gateway["uid_ref"], "gateway", gateway.get("name", ""), gateway))
    for cfg in data.get("pam_configurations") or []:
        title = cfg.get("title") or cfg.get("uid_ref")
        out.append((cfg["uid_ref"], "pam_configuration", title, cfg))
    for res in data.get("resources") or []:
        out.append((res["uid_ref"], res["type"], res.get("title", ""), res))
        for user in res.get("users") or []:
            out.append((user.get("uid_ref") or "", user["type"], user.get("title", ""), user))
    for user in data.get("users") or []:
        out.append((user.get("uid_ref") or "", user["type"], user.get("title", ""), user))
    return out


def _rotation_scripts_readback_available() -> bool:
    try:
        from dsk.providers.commander_version import supports_rotation_info_json
    except Exception:
        return False
    return supports_rotation_info_json()


def compute_diff(
    manifest: Manifest,
    live_records: list[LiveRecord],
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,
    adopt: bool = False,
) -> list[Change]:
    """Classify desired (manifest) vs observed (live) state.

    Matching rules:
      1. Prefer ``LiveRecord.marker.uid_ref == desired.uid_ref`` when present.
      2. Otherwise match by ``(resource_type, title)``.
      3. Records marked by a *different* manager are flagged as CONFLICT
         and never touched — the SDK owns only what it wrote.

    The function is deliberately a thin orchestrator: the three hard
    sub-problems (duplicate detection, desired-vs-live matching, orphan
    classification) live in private helpers so each can be read + tested
    in isolation.
    """
    manifest_name = manifest_name or manifest.name
    _raise_live_record_collisions(live_records)

    by_uid_ref, by_title = _index_live(live_records)

    changes: list[Change] = []
    matched: set[str] = set()

    for uid_ref, resource_type, title, payload in _desired_objects(manifest):
        live = by_uid_ref.get(uid_ref) or by_title.get((resource_type, title))
        change = _classify_desired(
            uid_ref=uid_ref,
            resource_type=resource_type,
            title=title,
            payload=payload,
            live=live,
            by_title=by_title,
            adopt=adopt,
        )
        changes.append(change)
        if change.kind in (ChangeKind.UPDATE, ChangeKind.NOOP) and live is not None:
            matched.add(live.keeper_uid)

    # Emit a NOOP warning row for every desired pamUser that carries rotation_scripts
    # so the plan surface notes that script attachment cannot be verified (no readback).
    data_for_warn = manifest.model_dump(mode="python", exclude_none=True)
    for resource in data_for_warn.get("resources") or []:
        if not isinstance(resource, dict):
            continue
        for user in resource.get("users") or []:
            if not isinstance(user, dict):
                continue
            if user.get("type") != "pamUser":
                continue
            scripts = user.get("rotation_scripts") or []
            if not scripts:
                continue
            if _rotation_scripts_readback_available():
                continue
            changes.append(
                Change(
                    kind=ChangeKind.NOOP,
                    uid_ref=user.get("uid_ref") or None,
                    resource_type="pamUser",
                    title=str(user.get("title") or ""),
                    reason=(
                        "rotation_scripts readback warning: attachment will run on apply but "
                        "cannot be verified (no pam rotation info --format=json in "
                        "Commander 17.x)"
                    ),
                    manifest_name=manifest_name,
                )
            )

    changes.extend(
        _classify_orphans(
            live_records,
            matched=matched,
            manifest_name=manifest_name,
            allow_delete=allow_delete,
        )
    )

    return changes


def _index_live(
    live_records: list[LiveRecord],
) -> tuple[dict[str, LiveRecord], dict[tuple[str, str], LiveRecord]]:
    """Return two lookup dicts over live records: by marker uid_ref, by (type, title)."""
    by_uid_ref: dict[str, LiveRecord] = {}
    by_title: dict[tuple[str, str], LiveRecord] = {}
    for live in live_records:
        marker_uid_ref = (live.marker or {}).get("uid_ref") if live.marker else None
        if marker_uid_ref:
            by_uid_ref[marker_uid_ref] = live
        by_title[(live.resource_type, live.title)] = live
    return by_uid_ref, by_title


def _dict_overlay_matches(live: dict[str, Any], desired: dict[str, Any]) -> bool:
    """True when *live* has the same value as *desired* for every non-``None`` *desired* entry.

    Nested dicts on *desired* are compared recursively. *Live* may contain extra
    keys (Commander / DAG / tunnel merge noise).
    """
    for k, want in desired.items():
        if want is None:
            continue
        got = live.get(k)
        if isinstance(want, dict):
            if not isinstance(got, dict):
                return False
            if not _dict_overlay_matches(got, want):
                return False
        elif got != want:
            return False
    return True


def _strip_unowned_pam_settings_options(
    live_ps: dict[str, Any], desired_ps: dict[str, Any]
) -> dict[str, Any]:
    """Drop Commander-injected ``options`` keys the manifest does not own."""
    desired_options = desired_ps.get("options")
    owned_option_keys = (
        {key for key, value in desired_options.items() if value is not None}
        if isinstance(desired_options, dict)
        else set()
    )
    live_options = live_ps.get("options")
    if not isinstance(live_options, dict):
        return live_ps
    unowned_defaults = {"connections", "rotation"} - owned_option_keys
    if not unowned_defaults or not any(key in live_options for key in unowned_defaults):
        return live_ps
    stripped_options = {k: v for k, v in live_options.items() if k not in unowned_defaults}
    if stripped_options:
        return {**live_ps, "options": stripped_options}
    return {k: v for k, v in live_ps.items() if k != "options"}


def _pam_resource_settings_equivalent(live_ps: Any, desired_ps: Any) -> bool:
    """``pam_settings`` for ``pamMachine`` / ``pamDatabase`` / ``pamDirectory`` — overlay match.

    Commander and TunnelDAG can add tri-states and extra keys under ``options`` / ``connection``;
    matching must require only manifest-owned keys, else post-apply re-plan spuriously updates
    the parent resource (P2.1 / issue #4).
    """
    if not isinstance(desired_ps, dict):
        return live_ps == desired_ps
    live_ps = live_ps if isinstance(live_ps, dict) else {}
    live_ps = _strip_unowned_pam_settings_options(live_ps, desired_ps)
    for section in ("options", "connection", "port_forward"):
        desired_sec = desired_ps.get(section)
        if not isinstance(desired_sec, dict):
            continue
        live_sec = live_ps.get(section)
        live_sec = live_sec if isinstance(live_sec, dict) else {}
        if not _dict_overlay_matches(live_sec, desired_sec):
            return False
    for scalar_key in ("allow_supply_host",):
        if desired_ps.get(scalar_key) is not None and live_ps.get(scalar_key) != desired_ps.get(
            scalar_key
        ):
            return False
    return True


def _pam_remote_browser_settings_equivalent(live_ps: Any, desired_ps: Any) -> bool:
    """True when every ``pam_settings`` option/connection key set on *desired* matches *live*."""
    if not isinstance(desired_ps, dict):
        return live_ps == desired_ps
    live_ps = live_ps if isinstance(live_ps, dict) else {}
    for section in ("options", "connection"):
        desired_sec = desired_ps.get(section)
        if not isinstance(desired_sec, dict):
            continue
        live_sec = live_ps.get(section)
        live_sec = live_sec if isinstance(live_sec, dict) else {}
        for k, want in desired_sec.items():
            if want is None:
                continue
            if k in _RBI_REPEATABLE_CONNECTION_KEYS:
                if normalize_rbi_repeatable_connection_list(
                    live_sec.get(k)
                ) != normalize_rbi_repeatable_connection_list(want):
                    return False
            elif live_sec.get(k) != want:
                return False
    return True


def _normalize_rotation_enabled(val: Any) -> str | None:
    if val is None:
        return None
    if isinstance(val, bool):
        return "on" if val else "off"
    s = str(val).strip().lower()
    if s in ("true", "1", "yes", "on"):
        return "on"
    if s in ("false", "0", "no", "off"):
        return "off"
    return s


def _normalize_rotation_schedule_tuple(sched: Any) -> tuple[Any, ...]:
    if sched is None:
        return ("",)
    if not isinstance(sched, dict):
        return ("raw", str(sched))
    st = sched.get("type")
    st_s = str(st).strip() if st is not None else ""
    slug = st_s.casefold().replace("_", "-").replace(" ", "")
    if slug == "cron":
        cron = sched.get("cron")
        if cron is None:
            cron = sched.get("expression")
        return ("CRON", str(cron or "").strip())
    rest = {k: v for k, v in sched.items() if k != "type"}
    return (slug or st_s, json.dumps(rest, sort_keys=True) if rest else "")


def _rotation_settings_equivalent(live: Any, desired: Any) -> bool:
    """Semantic equality for Commander vs manifest ``rotation_settings`` shape drift."""
    if live == desired:
        return True
    if not isinstance(desired, dict):
        return live == desired
    live_d = live if isinstance(live, dict) else {}

    def norm(rs: dict[str, Any]) -> tuple[Any, ...]:
        rot = rs.get("rotation")
        en = _normalize_rotation_enabled(rs.get("enabled"))
        sched_t = _normalize_rotation_schedule_tuple(rs.get("schedule"))
        pc = rs.get("password_complexity")
        if isinstance(pc, (dict, list)):
            pc = json.dumps(pc, sort_keys=True)
        else:
            pc = str(pc) if pc is not None else None
        return (rot, en, sched_t, pc)

    return norm(live_d) == norm(desired)


def _trust_missing_rotation_settings_readback(
    live: dict[str, Any],
    desired: dict[str, Any],
    *,
    marker: dict[str, Any] | None,
    uid_ref: str,
) -> bool:
    """Option A: trust SDK-owned pamUser rotation apply when Commander get omits readback.

    Repository fixtures and provider parsers have no proven
    ``keeper get --format json`` typed field for nested user rotation; apply
    writes it through ``pam rotation edit``. Until Commander exposes stable
    readback, a matching SDK marker is the offline proof that suppresses the
    desired-only re-plan drift.
    """
    if "rotation_settings" not in desired or "rotation_settings" in live:
        return False
    if desired.get("rotation_settings") is None:
        return False
    marker_d = marker or {}
    return (
        bool(uid_ref)
        and marker_d.get("manager") == MANAGER_NAME
        and marker_d.get("uid_ref") == uid_ref
        and marker_d.get("resource_type") in (None, "pamUser")
    )


def _pam_user_managed_flag_equivalent(live: Any, desired: Any) -> bool:
    """``pamUser.managed`` — compare normalized booleans (Commander readback can skew)."""

    def norm(v: Any) -> bool:
        if v in (None, False, 0, ""):
            return False
        if v in (True, 1, "1"):
            return True
        if isinstance(v, (int, float)) and v == 0.0:
            return False
        s = str(v).strip().lower()
        if s in ("0", "false", "off", "no", "f", "n"):
            return False
        if s in ("1", "true", "on", "yes", "t", "y"):
            return True
        return bool(v)

    return norm(live) == norm(desired)


def _field_diff_pam_user(
    live: dict[str, Any],
    desired: dict[str, Any],
    *,
    marker: dict[str, Any] | None = None,
    uid_ref: str = "",
) -> list[str]:
    keys: set[str] = set(live) | set(desired)
    changed: list[str] = []
    for key in keys:
        if key in _DIFF_IGNORED_FIELDS:
            continue
        if key not in desired:
            continue
        if key == "rotation_settings":
            if _trust_missing_rotation_settings_readback(
                live,
                desired,
                marker=marker,
                uid_ref=uid_ref,
            ):
                continue
            if not _rotation_settings_equivalent(live.get(key), desired.get(key)):
                changed.append(key)
        elif key == "managed":
            if not _pam_user_managed_flag_equivalent(live.get(key), desired.get(key)):
                changed.append(key)
        elif key == "rotation_scripts":
            # No readback available (Commander 17.x lacks pam rotation info --format=json
            # for script attachments).  Exclude from field diff to prevent spurious UPDATE
            # rows; apply handles attachment unconditionally.
            pass
        elif key == "saas_plugins":
            # Commander returns null (None) when no SaaS plugins are configured,
            # while the manifest default is [].  Treat None and [] as equivalent
            # to avoid a spurious UPDATE on every re-plan after a clean apply.
            live_sp = live.get(key) or []
            desired_sp = desired.get(key) or []
            if live_sp != desired_sp:
                changed.append(key)
        elif live.get(key) != desired.get(key):
            changed.append(key)
    return sorted(changed)


def _field_diff_pam_configuration(live: dict[str, Any], desired: dict[str, Any]) -> list[str]:
    """Field diff for ``pam_configuration`` records with overlay semantics on ``options``.

    Uses overlay matching for the top-level ``options`` block so that
    Commander-injected default option flags (e.g. ``connections``,
    ``tunneling``, ``ai_threat_detection``) that are absent from the manifest
    do not cause spurious UPDATE rows.  Every key the manifest *does* declare
    in ``options`` is compared exactly against the live value.

    All other top-level fields (``title``, ``environment``, ``network_id``,
    etc.) are compared with strict equality, identical to :func:`_field_diff`.
    """
    keys: set[str] = set(live) | set(desired)
    changed: list[str] = []
    for key in keys:
        if key in _DIFF_IGNORED_FIELDS:
            continue
        if key not in desired:
            continue
        if key == "options":
            desired_opts = desired.get("options")
            if not isinstance(desired_opts, dict):
                if live.get("options") != desired_opts:
                    changed.append(key)
                continue
            live_opts = live.get("options")
            live_opts = live_opts if isinstance(live_opts, dict) else {}
            if not _dict_overlay_matches(live_opts, desired_opts):
                changed.append(key)
        elif live.get(key) != desired.get(key):
            changed.append(key)
    return sorted(changed)


def _field_diff_pam_remote_browser(live: dict[str, Any], desired: dict[str, Any]) -> list[str]:
    """Like :func:`_field_diff` but treats ``pam_settings`` as a partial overlay for RBI."""
    keys: set[str] = set(live) | set(desired)
    changed: list[str] = []
    for key in keys:
        if key in _DIFF_IGNORED_FIELDS:
            continue
        if key not in desired:
            continue
        if key == "pam_settings":
            if not _pam_remote_browser_settings_equivalent(live.get(key), desired.get(key)):
                changed.append(key)
        elif live.get(key) != desired.get(key):
            changed.append(key)
    return sorted(changed)


def _field_diff_pam_settings_resource(live: dict[str, Any], desired: dict[str, Any]) -> list[str]:
    """Field diff for PAM resource records whose ``pam_settings`` allows live-side extras."""
    keys: set[str] = set(live) | set(desired)
    changed: list[str] = []
    for key in keys:
        if key in _DIFF_IGNORED_FIELDS:
            continue
        if key not in desired:
            continue
        if key == "pam_settings":
            if not _pam_resource_settings_equivalent(live.get(key), desired.get(key)):
                changed.append(key)
        elif live.get(key) != desired.get(key):
            changed.append(key)
    return sorted(changed)


_VAULT_FILE_REF_FIELD_TYPES = {"file_ref", "fileref"}


def _vault_normalized_field_type(field_type: Any) -> str:
    return str(field_type or "").replace("_", "").casefold()


def _vault_field_label(entry: Mapping[str, Any]) -> str:
    return str(entry.get("label") or entry.get("name") or entry.get("type") or "")


def _vault_norm_field_label(entry: Mapping[str, Any]) -> str:
    return norm_field_name(_vault_field_label(entry))


def _vault_canonical_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return tuple(sorted((str(k), _vault_canonical_value(v)) for k, v in value.items()))
    if isinstance(value, list):
        return tuple(_vault_canonical_value(item) for item in value)
    return value


def _vault_canonical_field_entries(entries: Any) -> list[tuple[str, str, Any]]:
    out: list[tuple[str, str, Any]] = []
    if not isinstance(entries, list):
        return out
    for entry in entries:
        if not isinstance(entry, Mapping):
            continue
        out.append(
            (
                _vault_norm_field_label(entry),
                _vault_normalized_field_type(entry.get("type")),
                _vault_canonical_value(entry.get("value")),
            )
        )
    return sorted(out, key=lambda item: json.dumps(item, sort_keys=True, default=str))


def _vault_field_entries_are_flattenable(entries: Any) -> bool:
    if not isinstance(entries, list):
        return True
    for entry in entries:
        if not isinstance(entry, Mapping):
            return False
        if _vault_normalized_field_type(entry.get("type")) in _VAULT_FILE_REF_FIELD_TYPES:
            return False
        values = entry.get("value")
        if not isinstance(values, list) or len(values) != 1:
            return False
        value = values[0]
        if not isinstance(value, (str, int, float, bool)) and value is not None:
            return False
    return True


def _vault_flatten_login_field_entries(entries: Any) -> dict[str, Any]:
    """Map typed ``fields[]`` entries to a flat ``label -> scalar`` dict (L1 login)."""
    out: dict[str, Any] = {}
    if not isinstance(entries, list):
        return out
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        field_type = entry.get("type")
        values = entry.get("value")
        label = str(entry.get("label") or "")
        if not field_type or not isinstance(values, list) or not values:
            continue
        value = values[0] if len(values) == 1 else values
        if isinstance(value, dict):
            continue
        if isinstance(value, (str, int, float, bool)):
            key = label or str(field_type)
            out[key] = value
    return out


def _vault_norm_login_field_map(m: dict[str, Any]) -> dict[str, Any]:
    return {norm_field_name(k): v for k, v in m.items()}


def _vault_flatten_live_login_scalar_map(
    live: dict[str, Any],
    flat_desired: dict[str, Any],
) -> dict[str, Any]:
    """When live has no ``fields[]`` (Commander ``get`` flattening), read scalars by label."""
    out: dict[str, Any] = {}
    for label in flat_desired:
        got = live.get(label)
        if got is None:
            for lk, lv in live.items():
                if lk in _DIFF_IGNORED_FIELDS:
                    continue
                if field_name_matches(lk, label):
                    got = lv
                    break
        out[label] = got
    return out


def _vault_normalize_custom_entry(entry: dict[str, Any]) -> dict[str, Any]:
    normalised = dict(entry)
    for key in ("key", "label", "name", "type"):
        if isinstance(normalised.get(key), str):
            normalised[key] = norm_field_name(normalised[key])
    return normalised


def _vault_sorted_custom_json(entries: list[dict[str, Any]]) -> str:
    norm = sorted(
        (_vault_normalize_custom_entry(e) for e in entries),
        key=lambda e: str(e.get("key") or e.get("label") or e.get("name") or e.get("type") or ""),
    )
    return json.dumps(norm, sort_keys=True)


def _field_diff_vault_login(live: dict[str, Any], desired: dict[str, Any]) -> list[str]:
    """Diff ``login`` rows for ``keeper-vault.v1`` vs Commander-shaped live payloads.

    Commander ``get`` merges typed ``fields`` into top-level scalar keys; manifests
    keep ``fields[]``. Compare semantically so matching logins do not churn UPDATE.
    """
    changed: list[str] = []
    for k in ("title", "notes"):
        if k not in desired:
            continue
        if live.get(k) != desired.get(k):
            changed.append(k)

    if "fields" in desired and desired.get("fields") is not None:
        live_fields = live.get("fields")
        if isinstance(live_fields, list) and live_fields:
            # Commander in-process RecordGetUidCommand returns write-only fields
            # (type "password", "secret", "pinCode") as value:[""] — the vault
            # value is encrypted at rest and is not decrypted for JSON output.
            # Normalise: when a live write-only field has a blank value but the
            # matching desired field has a non-blank value, promote the live field
            # to match desired so the comparison does not flag a spurious UPDATE.
            # Genuine drift (old-secret → new-secret) is still detected because
            # both values are non-blank and differ; field-added / field-removed
            # cases remain detectable because the entry count differs.
            _WRITE_ONLY_FIELD_TYPES = {"password", "secret", "pinCode"}

            def _maybe_promote_blank(
                live_entry: dict[str, Any],
                desired_fields: list[Any],
            ) -> dict[str, Any]:
                if not isinstance(live_entry, dict):
                    return live_entry
                ftype = _vault_normalized_field_type(live_entry.get("type"))
                if ftype not in _WRITE_ONLY_FIELD_TYPES:
                    return live_entry
                live_val = live_entry.get("value")
                if not isinstance(live_val, list) or any(v for v in live_val if v):
                    return live_entry  # non-blank; compare as-is
                # live value is blank — find matching desired entry by type+label
                live_label = _vault_norm_field_label(live_entry)
                for d_entry in desired_fields:
                    if not isinstance(d_entry, dict):
                        continue
                    if (
                        _vault_normalized_field_type(d_entry.get("type")) == ftype
                        and _vault_norm_field_label(d_entry) == live_label
                    ):
                        return {**live_entry, "value": d_entry.get("value", live_val)}
                return live_entry

            live_normalised = [
                _maybe_promote_blank(e, desired["fields"]) if isinstance(e, dict) else e
                for e in live_fields
            ]
            # Filter out live-side extra fields that Commander injects automatically
            # (e.g. fileRef with empty value=[]) when they are not declared in the manifest.
            # A live field that IS declared in the manifest but with a non-empty value is
            # NOT filtered — its absence from desired is meaningful removal drift.
            _desired_keys: set[tuple[str, str]] = {
                (
                    _vault_norm_field_label(e),
                    _vault_normalized_field_type(e.get("type")),
                )
                for e in desired["fields"]
                if isinstance(e, dict)
            }

            def _is_injected_empty(entry: Any) -> bool:
                if not isinstance(entry, dict):
                    return False
                key = (
                    _vault_norm_field_label(entry),
                    _vault_normalized_field_type(entry.get("type")),
                )
                if key in _desired_keys:
                    return False  # declared in desired — keep for comparison
                vals = entry.get("value")
                return isinstance(vals, list) and not any(vals)

            live_filtered = [e for e in live_normalised if not _is_injected_empty(e)]
            if _vault_canonical_field_entries(live_filtered) != _vault_canonical_field_entries(
                desired["fields"]
            ):
                changed.append("fields")
        else:
            if not _vault_field_entries_are_flattenable(desired["fields"]):
                changed.append("fields")
                return sorted(changed)
            flat_d = _vault_flatten_login_field_entries(desired["fields"])
            flat_l = _vault_flatten_live_login_scalar_map(live, flat_d)
            if _vault_norm_login_field_map(flat_l) != _vault_norm_login_field_map(flat_d):
                changed.append("fields")

    # Treat missing ``custom`` as [] so live-only custom rows (removals) still
    # surface as UPDATE when manifests omit the key after L2 normalization.
    d_raw = desired.get("custom")
    d_list = [
        e
        for e in (d_raw if isinstance(d_raw, list) else [])
        if isinstance(e, dict)
        and not field_name_matches(
            e.get("key") or e.get("label") or e.get("name"), MARKER_FIELD_LABEL
        )
    ]
    live_custom = live.get("custom")
    l_raw = live_custom if isinstance(live_custom, list) else []
    l_list = [
        e
        for e in l_raw
        if isinstance(e, dict)
        and not field_name_matches(
            e.get("key") or e.get("label") or e.get("name"), MARKER_FIELD_LABEL
        )
    ]
    if _vault_sorted_custom_json(l_list) != _vault_sorted_custom_json(d_list):
        changed.append("custom")

    return sorted(changed)


def _classify_desired(
    *,
    uid_ref: str,
    resource_type: str,
    title: str,
    payload: dict[str, Any],
    live: LiveRecord | None,
    by_title: dict[tuple[str, str], LiveRecord],
    adopt: bool,
    vault_login_diff: bool = False,
) -> Change:
    """Classify ONE desired resource against its best live match.

    Branches in order:
      * no live match → CREATE
      * foreign marker → CONFLICT (never adopt)
      * unsupported marker version → raise OwnershipError
      * unmanaged title collision → CONFLICT (or UPDATE with adoption
        reason when ``adopt`` is set)
      * field drift → UPDATE; otherwise NOOP
    """
    if live is None:
        return Change(
            kind=ChangeKind.CREATE,
            uid_ref=uid_ref or None,
            resource_type=resource_type,
            title=title,
            after=payload,
        )

    marker = live.marker or {}
    manager = marker.get("manager")
    if marker and manager and manager != MANAGER_NAME:
        return Change(
            kind=ChangeKind.CONFLICT,
            uid_ref=uid_ref or None,
            resource_type=resource_type,
            title=title,
            keeper_uid=live.keeper_uid,
            reason=f"record managed by '{manager}', refusing to touch",
        )
    if marker and marker.get("version") not in (None, MARKER_VERSION):
        raise OwnershipError(
            reason=f"marker version {marker.get('version')} not supported by core v{MARKER_VERSION}",
            uid_ref=uid_ref,
            resource_type=resource_type,
            live_identifier=live.keeper_uid,
            next_action="upgrade the declarative core or rewrite the marker",
        )
    if not marker and by_title.get((resource_type, title)) is live:
        if not adopt:
            return Change(
                kind=ChangeKind.CONFLICT,
                uid_ref=uid_ref or None,
                resource_type=resource_type,
                title=title,
                keeper_uid=live.keeper_uid,
                reason="unmanaged record with matching title; pass --adopt or use an import workflow to claim it",
            )
        return Change(
            kind=ChangeKind.UPDATE,
            uid_ref=uid_ref or None,
            resource_type=resource_type,
            title=title,
            keeper_uid=live.keeper_uid,
            before=live.payload,
            after=payload,
            reason="adoption: write ownership marker",
        )

    if vault_login_diff and resource_type == "login":
        diff_fields = _field_diff_vault_login(live.payload, payload)
    elif resource_type == "pamRemoteBrowser":
        diff_fields = _field_diff_pam_remote_browser(live.payload, payload)
    elif resource_type in ("pamMachine", "pamDatabase", "pamDirectory"):
        diff_fields = _field_diff_pam_settings_resource(live.payload, payload)
    elif resource_type == "pamUser":
        diff_fields = _field_diff_pam_user(
            live.payload,
            payload,
            marker=live.marker,
            uid_ref=uid_ref,
        )
    elif resource_type == "pam_configuration":
        diff_fields = _field_diff_pam_configuration(live.payload, payload)
    else:
        diff_fields = _field_diff(live.payload, payload)
    if not diff_fields:
        return Change(
            kind=ChangeKind.NOOP,
            uid_ref=uid_ref or None,
            resource_type=resource_type,
            title=title,
            keeper_uid=live.keeper_uid,
        )
    before = {k: live.payload.get(k) for k in diff_fields}
    after = {k: payload.get(k) for k in diff_fields}
    if vault_login_diff and resource_type == "login":
        if "custom" in before and before["custom"] is None:
            before["custom"] = []
        if "custom" in after and after["custom"] is None:
            after["custom"] = []
    return Change(
        kind=ChangeKind.UPDATE,
        uid_ref=uid_ref or None,
        resource_type=resource_type,
        title=title,
        keeper_uid=live.keeper_uid,
        before=before,
        after=after,
    )


def _classify_orphans(
    live_records: list[LiveRecord],
    *,
    matched: set[str],
    manifest_name: str,
    allow_delete: bool,
) -> list[Change]:
    """Emit DELETE / CONFLICT rows for records that went unmatched.

    Only this-manifest-managed records are considered. Foreign-managed
    and unmanaged records silently fall through — the SDK refuses to
    remove anything it did not create.
    """
    out: list[Change] = []
    for live in live_records:
        if live.keeper_uid in matched:
            continue
        marker = live.marker or {}
        if marker.get("manager") != MANAGER_NAME:
            continue
        if marker.get("manifest") and manifest_name and marker.get("manifest") != manifest_name:
            continue
        if allow_delete:
            out.append(
                Change(
                    kind=ChangeKind.DELETE,
                    uid_ref=marker.get("uid_ref"),
                    resource_type=live.resource_type,
                    title=live.title,
                    keeper_uid=live.keeper_uid,
                    before=live.payload,
                )
            )
        else:
            out.append(
                Change(
                    kind=ChangeKind.CONFLICT,
                    uid_ref=marker.get("uid_ref"),
                    resource_type=live.resource_type,
                    title=live.title,
                    keeper_uid=live.keeper_uid,
                    reason="managed record missing from manifest; pass --allow-delete to remove",
                )
            )
    return out


def _raise_live_record_collisions(live_records: list[LiveRecord]) -> None:
    """Reject ambiguous live-record matches before diffing desired state."""
    marker_matches: dict[str, list[LiveRecord]] = {}
    title_matches: dict[tuple[str, str], list[LiveRecord]] = {}

    for live in live_records:
        marker_uid_ref = (live.marker or {}).get("uid_ref") if live.marker else None
        if marker_uid_ref:
            marker_matches.setdefault(marker_uid_ref, []).append(live)
        title_matches.setdefault((live.resource_type, live.title), []).append(live)

    for uid_ref, matches in marker_matches.items():
        if len(matches) < 2:
            continue
        raise CollisionError(
            reason=f"live tenant has {len(matches)} records claiming uid_ref='{uid_ref}'",
            uid_ref=uid_ref,
            next_action="reconcile the duplicate ownership markers manually before re-running apply",
            context={"live_identifiers": [live.keeper_uid for live in matches]},
        )

    for (resource_type, title), matches in title_matches.items():
        if len(matches) < 2:
            continue
        marker_uids = [(live.marker or {}).get("uid_ref") for live in matches]
        if all(uid for uid in marker_uids) and len(set(marker_uids)) == len(marker_uids):
            continue
        reason = f"duplicate titles found for '{title}' — cannot safely resolve; rename one"
        if not any(marker_uids):
            reason = (
                f"{reason}; live tenant has {len(matches)} {resource_type} "
                f"records titled '{title}' with no ownership markers"
            )
        raise ConflictError(
            reason=reason,
            uid_ref=None,
            resource_type=resource_type,
            next_action="rename one duplicate title before planning",
            context={"live_identifiers": [live.keeper_uid for live in matches]},
        )


_DIFF_IGNORED_FIELDS = frozenset(
    {
        "uid_ref",
        "attachments",
        "scripts",
        "custom_fields",
        "record_uid",
        # SDK-only placement/linkage metadata — not record fields and never
        # observable from Commander `get`. Keep them out of the planner diff so
        # re-plans are clean when fields match.
        "pam_configuration",
        "pam_configuration_uid_ref",
        "shared_folder",
        "users",
        "gateway",
        "gateway_uid_ref",
        # Apply-time manual step: pam tunnel edit --keeper-db-proxy
        "tunnel_settings",
    }
)


def _field_diff(before: dict[str, Any], after: dict[str, Any]) -> list[str]:
    """Return keys whose value differs. Only compare overlapping canonical keys."""
    keys: set[str] = set(before) | set(after)
    changed: list[str] = []
    for key in keys:
        if key in _DIFF_IGNORED_FIELDS:
            continue
        # only treat a key as changed if the desired side actually set it; this
        # avoids churn on fields the caller doesn't manage.
        if key not in after:
            continue
        if before.get(key) != after.get(key):
            changed.append(key)
    return sorted(changed)


__all__ = ["Change", "ChangeKind", "compute_diff", "CollisionError", "ConflictError"]
