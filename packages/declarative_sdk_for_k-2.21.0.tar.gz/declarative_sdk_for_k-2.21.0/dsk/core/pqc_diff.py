"""Desired-vs-live diff for ``pqc-policy.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_pqc import PqcPolicyManifestV1


def compute_pqc_diff(
    manifest: PqcPolicyManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared PQC requirement resource."""
    if live:
        raise NotImplementedError("pqc-policy.v1 live readback not implemented")

    name = manifest_name or "pqc-policy.v1"
    changes: list[Change] = []

    for idx, requirement in enumerate(manifest.requirements):
        payload = requirement.model_dump(mode="python", exclude_none=True)
        uid_ref = getattr(requirement, "uid_ref", None) or f"{name}.{idx}"
        resource_type = getattr(requirement, "resource_type", None)
        title = str(resource_type) if resource_type else f"{name}.req.{idx}"
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=str(uid_ref),
                resource_type="pqc_requirement",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_pqc_diff"]
