"""Desired-vs-live diff for ``secret-scanner-bridge.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_secret_scanner import SecretScannerBridgeManifestV1


def compute_secret_scanner_diff(
    manifest: SecretScannerBridgeManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared secret scanner bridge resource."""
    if live:
        raise NotImplementedError(
            "secret-scanner-bridge.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    for idx, repo in enumerate(manifest.repos):
        uid_ref = f"{name}.repos.{idx}"
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="secret_scanner_repo",
                title=str(repo),
                before={},
                after={"repo": str(repo)},
                manifest_name=name,
            ),
        )

    for idx, mapping in enumerate(manifest.mappings):
        uid_ref = f"{name}.mappings.{idx}"
        payload = mapping.model_dump(mode="python", exclude_none=True)
        title = str(getattr(mapping, "name", getattr(mapping, "repo", uid_ref)))
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="secret_scanner_mapping",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_secret_scanner_diff"]
