"""Desired-vs-live diff for ``keeper-epm.v1`` offline manifests."""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_epm import EPM_POLICY_FAMILY, EpmManifestV1, EpmPolicyManifestV1

_BLOCK_ORDER = ("watchlists", "policies", "approvers", "audit_config")
_RESOURCE_BY_BLOCK = {
    "watchlists": "epm_watchlist",
    "policies": "epm_policy",
    "approvers": "epm_approver",
    "audit_config": "epm_audit_config",
}
_DELETE_SKIP_REASON = "unmanaged EPM object; pass allow_delete=True to remove"
_KIND_ORDER = {
    ChangeKind.CREATE: 0,
    ChangeKind.UPDATE: 1,
    ChangeKind.NOOP: 2,
    ChangeKind.DELETE: 3,
    ChangeKind.SKIP: 3,
    ChangeKind.CONFLICT: 4,
}


def compute_epm_diff(
    manifest: EpmManifestV1,
    live_epm: EpmManifestV1 | Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,
) -> list[Change]:
    """Classify desired EPM state against an offline live snapshot."""
    desired = _index_objects(_payload_from_manifest(manifest))
    live, duplicate_live = _index_live(_payload_from_live(live_epm))
    manifest_name = manifest_name or "keeper-epm"

    changes: list[Change] = []
    for key, desired_obj in desired.items():
        if key in duplicate_live:
            continue
        live_obj = live.get(key)
        if live_obj is None:
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=desired_obj.uid_ref,
                    resource_type=desired_obj.resource_type,
                    title=desired_obj.title,
                    before={},
                    after=desired_obj.payload,
                    manifest_name=manifest_name,
                )
            )
            continue

        before, after = _field_delta(live_obj.payload, desired_obj.payload, desired_obj.key_field)
        if before or after:
            changes.append(
                Change(
                    kind=ChangeKind.UPDATE,
                    uid_ref=desired_obj.uid_ref,
                    resource_type=desired_obj.resource_type,
                    title=desired_obj.title,
                    keeper_uid=live_obj.keeper_uid,
                    before=before,
                    after=after,
                    manifest_name=manifest_name,
                )
            )
            continue

        changes.append(
            Change(
                kind=ChangeKind.NOOP,
                uid_ref=desired_obj.uid_ref,
                resource_type=desired_obj.resource_type,
                title=desired_obj.title,
                keeper_uid=live_obj.keeper_uid,
                before=live_obj.payload,
                after=desired_obj.payload,
                reason="no drift",
                manifest_name=manifest_name,
            )
        )

    for key, live_obj in live.items():
        if key in desired or key in duplicate_live:
            continue
        kind = ChangeKind.DELETE if allow_delete else ChangeKind.SKIP
        changes.append(
            Change(
                kind=kind,
                uid_ref=live_obj.uid_ref,
                resource_type=live_obj.resource_type,
                title=live_obj.title,
                keeper_uid=live_obj.keeper_uid,
                before=live_obj.payload,
                reason=None if allow_delete else _DELETE_SKIP_REASON,
                manifest_name=manifest_name,
            )
        )

    for rows in duplicate_live.values():
        first = rows[0]
        changes.append(
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref=first.uid_ref,
                resource_type=first.resource_type,
                title=first.title,
                before={"key": first.key, "count": len(rows)},
                reason=f"duplicate live EPM object key: {first.key}",
                manifest_name=manifest_name,
            )
        )

    return sorted(changes, key=_change_sort_key)


class _EpmObject:
    def __init__(self, *, block: str, payload: dict[str, Any]) -> None:
        self.block = block
        self.payload = _normalise_payload(block, payload)
        self.resource_type = _RESOURCE_BY_BLOCK[block]
        self.key_field = "uid_ref"
        self.key = _key_for(block, self.payload)
        self.uid_ref = _uid_ref_for(block, self.payload)
        self.title = _title_for(block, self.payload)
        keeper_uid = self.payload.get("keeper_uid")
        self.keeper_uid = str(keeper_uid) if keeper_uid is not None else None


def _payload_from_manifest(manifest: EpmManifestV1) -> dict[str, Any]:
    return manifest.model_dump(mode="python", exclude_none=True, by_alias=True)


def _payload_from_live(live_epm: EpmManifestV1 | Mapping[str, Any] | None) -> dict[str, Any]:
    if live_epm is None:
        return {block: [] for block in _BLOCK_ORDER if block != "audit_config"}
    if isinstance(live_epm, EpmManifestV1):
        return live_epm.model_dump(mode="python", exclude_none=True, by_alias=True)
    return dict(live_epm)


def _index_objects(payload: Mapping[str, Any]) -> dict[str, _EpmObject]:
    out: dict[str, _EpmObject] = {}
    for block in ("watchlists", "policies", "approvers"):
        for row in payload.get(block) or []:
            if not isinstance(row, Mapping):
                continue
            obj = _EpmObject(block=block, payload=dict(row))
            out[obj.key] = obj

    audit_config = payload.get("audit_config")
    if isinstance(audit_config, Mapping):
        obj = _EpmObject(block="audit_config", payload=dict(audit_config))
        out[obj.key] = obj
    return out


def _index_live(
    payload: Mapping[str, Any],
) -> tuple[dict[str, _EpmObject], dict[str, list[_EpmObject]]]:
    grouped: dict[str, list[_EpmObject]] = defaultdict(list)
    for block in ("watchlists", "policies", "approvers"):
        for row in payload.get(block) or []:
            if not isinstance(row, Mapping):
                continue
            obj = _EpmObject(block=block, payload=dict(row))
            grouped[obj.key].append(obj)

    audit_config = payload.get("audit_config")
    if isinstance(audit_config, Mapping):
        obj = _EpmObject(block="audit_config", payload=dict(audit_config))
        grouped[obj.key].append(obj)

    live: dict[str, _EpmObject] = {}
    duplicate: dict[str, list[_EpmObject]] = {}
    for key, rows in grouped.items():
        if len(rows) > 1:
            duplicate[key] = rows
        else:
            live[key] = rows[0]
    return live, duplicate


def _normalise_payload(block: str, payload: dict[str, Any]) -> dict[str, Any]:
    out = {key: _normalise_value(value) for key, value in payload.items() if value is not None}
    out.pop("keeper_uid", None)
    if block == "watchlists":
        out.setdefault("description", "")
        out.setdefault("entries", [])
    if block == "policies":
        out.setdefault("target_users", [])
        out.setdefault("target_groups", [])
        out.setdefault("application_patterns", [])
    if block == "approvers":
        out.setdefault("scope_uid_refs", [])
    return out


def _normalise_value(value: Any) -> Any:
    if isinstance(value, list):
        normalised = [_normalise_value(item) for item in value]
        if all(not isinstance(item, dict | list) for item in normalised):
            return sorted(normalised, key=lambda item: str(item))
        return sorted(normalised, key=lambda item: json.dumps(item, sort_keys=True))
    if isinstance(value, dict):
        return {key: _normalise_value(value[key]) for key in sorted(value)}
    return value


def _field_delta(
    live_payload: dict[str, Any],
    desired_payload: dict[str, Any],
    key_field: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    keys = sorted(set(live_payload) | set(desired_payload))
    before: dict[str, Any] = {}
    after: dict[str, Any] = {}
    for key in keys:
        if key == key_field:
            continue
        if live_payload.get(key) == desired_payload.get(key):
            continue
        before[key] = live_payload.get(key)
        after[key] = desired_payload.get(key)
    return before, after


def _key_for(block: str, payload: dict[str, Any]) -> str:
    if block == "audit_config":
        return "audit_config"
    return f"{block}:{payload['uid_ref']}"


def _uid_ref_for(block: str, payload: dict[str, Any]) -> str:
    if block == "audit_config":
        return "audit_config"
    return str(payload["uid_ref"])


def _title_for(block: str, payload: dict[str, Any]) -> str:
    if block == "audit_config":
        return "audit_config"
    return str(payload.get("name") or payload["uid_ref"])


def _change_sort_key(change: Change) -> tuple[int, int, str]:
    block_rank = {
        resource: index for index, resource in enumerate(_RESOURCE_BY_BLOCK.values())
    }.get(change.resource_type, len(_RESOURCE_BY_BLOCK))
    return (_KIND_ORDER[change.kind], block_rank, change.uid_ref or change.title)


def compute_epm_policy_diff(
    manifest: EpmPolicyManifestV1,
    live: Mapping[str, Any] | None,
    *,
    manifest_name: str = EPM_POLICY_FAMILY,
    allow_delete: bool = False,
) -> list[Change]:
    """Desired-vs-live diff for ``epm-policy.v1`` offline manifests."""
    if live is None:
        live = {}
    changes: list[Change] = []
    seen: set[str] = set()

    for category in manifest.default_policies or []:
        category_name = str(category)
        uid_ref = f"default_policies:{category_name}"
        seen.add(uid_ref)
        desired = {"category": category_name}
        live_entry = live.get(uid_ref)
        if live_entry is None:
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=uid_ref,
                    resource_type="epm_default_policy",
                    title=category_name,
                    before={},
                    after=desired,
                    reason=None,
                    manifest_name=manifest_name,
                )
            )
        elif desired != live_entry:
            changes.append(
                Change(
                    kind=ChangeKind.UPDATE,
                    uid_ref=uid_ref,
                    resource_type="epm_default_policy",
                    title=category_name,
                    before=dict(live_entry),
                    after=desired,
                    reason=None,
                    manifest_name=manifest_name,
                )
            )
        else:
            changes.append(
                Change(
                    kind=ChangeKind.NOOP,
                    uid_ref=uid_ref,
                    resource_type="epm_default_policy",
                    title=category_name,
                    before=dict(live_entry),
                    after=desired,
                    reason=None,
                    manifest_name=manifest_name,
                )
            )

    for policy in manifest.policies or []:
        uid_ref = str(getattr(policy, "uid_ref", None) or getattr(policy, "name", ""))
        seen.add(uid_ref)
        live_entry = live.get(uid_ref)
        if live_entry is None:
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=uid_ref,
                    resource_type="epm_policy_rule",
                    title=getattr(policy, "name", uid_ref),
                    before={},
                    after=policy.model_dump(exclude_unset=True),
                    reason=None,
                    manifest_name=manifest_name,
                )
            )
        else:
            desired = policy.model_dump(exclude_unset=True)
            if desired != live_entry:
                changes.append(
                    Change(
                        kind=ChangeKind.UPDATE,
                        uid_ref=uid_ref,
                        resource_type="epm_policy_rule",
                        title=getattr(policy, "name", uid_ref),
                        before=dict(live_entry),
                        after=desired,
                        reason=None,
                        manifest_name=manifest_name,
                    )
                )
            else:
                changes.append(
                    Change(
                        kind=ChangeKind.NOOP,
                        uid_ref=uid_ref,
                        resource_type="epm_policy_rule",
                        title=getattr(policy, "name", uid_ref),
                        before=dict(live_entry),
                        after=desired,
                        reason=None,
                        manifest_name=manifest_name,
                    )
                )
    if allow_delete:
        for uid_ref, live_entry in live.items():
            if uid_ref not in seen:
                changes.append(
                    Change(
                        kind=ChangeKind.DELETE,
                        uid_ref=uid_ref,
                        resource_type="epm_policy_rule",
                        title=uid_ref,
                        before=dict(live_entry),
                        after={},
                        reason=None,
                        manifest_name=manifest_name,
                    )
                )
    return changes


__all__ = ["compute_epm_diff", "compute_epm_policy_diff"]
