"""DORA compliance profile models — dora-profile.v1.

Declares DORA ICT risk management control coverage via Keeper PAM resources.
Regulation in force: January 17, 2025. Article 9(4) mandates PAM controls.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class DoraArticle(StrEnum):
    """DORA articles with direct PAM relevance."""

    art5 = "art-5"  # ICT governance
    art9 = "art-9"  # ICT risk management
    art10 = "art-10"  # Protection & prevention
    art11 = "art-11"  # Detection
    art12 = "art-12"  # Response & recovery
    art16 = "art-16"  # Simplified ICT risk management
    art28 = "art-28"  # Third-party risk (ICT providers)


class DoraControlStatus(StrEnum):
    satisfied = "satisfied"
    partial = "partial"
    not_applicable = "not_applicable"
    gap = "gap"  # explicit gap — remediation required


class DoraEvidenceType(StrEnum):
    session_recording = "session_recording"
    access_log = "access_log"
    rotation_log = "rotation_log"
    mfa_enforcement = "mfa_enforcement"
    jit_access_record = "jit_access_record"
    pam_configuration_snapshot = "pam_configuration_snapshot"
    compliance_report = "compliance_report"


class DoraControlMapping(BaseModel):
    """Maps a DORA article/paragraph to Keeper PAM evidence."""

    article: DoraArticle
    paragraph: str | None = Field(
        None,
        description="Sub-paragraph, e.g. '4.a', '4.b'",
    )
    control_description: str
    status: DoraControlStatus
    keeper_resources: list[str] = Field(
        default_factory=list,
        description="DSK uid_refs satisfying this control",
    )
    evidence_types: list[DoraEvidenceType] = Field(default_factory=list)
    remediation_note: str | None = Field(
        None,
        description="Required when status=gap or status=partial",
    )


class DoraReportingConfig(BaseModel):
    output_dir: str = Field(
        "dora-evidence/",
        description="Directory to write evidence JSON files",
    )
    include_session_logs: bool = True
    include_rotation_history: bool = True
    audit_period_days: int = Field(365, ge=1, le=3650)


class DoraProfileManifestV1(BaseModel):
    """Root model for a dora-profile.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("dora-profile.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    entity_name: str | None = Field(
        None,
        description="Legal entity name of the financial institution",
    )
    lei_code: str | None = Field(
        None,
        description="Legal Entity Identifier (LEI) for the regulated entity",
    )
    controls: list[DoraControlMapping] = Field(default_factory=list)
    reporting: DoraReportingConfig = Field(default_factory=lambda: DoraReportingConfig())  # type: ignore[call-arg]
    reviewed_by: str | None = None
    review_date: str | None = Field(
        None,
        description="ISO 8601 date of last compliance review",
    )
