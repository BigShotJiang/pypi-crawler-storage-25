"""Desired-vs-live diff for ``pam-connection-profile.v1`` (offline)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_connection_profile import PamConnectionProfileManifestV1


def compute_connection_profile_diff(
    manifest: PamConnectionProfileManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared connection profile."""
    if live:
        raise NotImplementedError(
            "pam-connection-profile.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    for idx, profile in enumerate(manifest.profiles):
        payload = profile.model_dump(mode="python", exclude_none=True)
        uid_ref_value = getattr(profile, "uid_ref", None)
        uid_ref = str(uid_ref_value) if uid_ref_value is not None else f"{name}.profiles.{idx}"
        title_value = getattr(profile, "name", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="pam_connection_profile",
                title=str(title_value) if title_value is not None else uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_connection_profile_diff"]
