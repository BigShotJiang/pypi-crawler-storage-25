"""CSPM remediation bridge models — cspm-remediation.v1.

Maps Cloud Security Posture Management findings to DSK remediation actions.
Supports Wiz, Orca, Lacework, and generic webhook payloads.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class CspmSource(StrEnum):
    wiz = "wiz"
    orca = "orca"
    lacework = "lacework"
    generic = "generic"  # any webhook with standard fields


class CspmSeverity(StrEnum):
    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"
    informational = "informational"


class RemediationAction(StrEnum):
    add_pam_gateway = "add_pam_gateway"  # add PAM gateway to unprotected resource
    enforce_rotation = "enforce_rotation"  # add rotation policy to stale credentials
    add_to_manifest = "add_to_manifest"  # adopt resource into DSK manifest
    create_jit_policy = "create_jit_policy"  # replace standing access with JIT
    alert_only = "alert_only"  # no auto-remediation, just log


class CspmFindingRule(BaseModel):
    """Maps a CSPM finding type to a DSK remediation action."""

    finding_type: str = Field(
        ...,
        description=("CSPM finding type string, e.g. 'EXPOSED_VM', 'OVERPRIVILEGED_ROLE'"),
    )
    min_severity: CspmSeverity = CspmSeverity.high
    action: RemediationAction = RemediationAction.alert_only
    target_manifest: str | None = Field(
        None,
        description="DSK manifest path to update for add_pam_gateway / add_to_manifest",
    )
    auto_approve: bool = Field(
        False,
        description="Auto-apply remediation without human review (use with caution)",
    )
    create_pr: bool = Field(
        True,
        description="Open a GitHub PR with the remediation manifest",
    )


class CspmWebhookConfig(BaseModel):
    source: CspmSource = CspmSource.generic
    listen_port: int = Field(8087, ge=1024, le=65535)
    secret_env_var: str = Field(
        "CSPM_WEBHOOK_SECRET",
        description="Env var name containing webhook HMAC secret",
    )
    finding_rules: list[CspmFindingRule] = Field(default_factory=list)


class CspmRemediationManifestV1(BaseModel):
    """Root model for a cspm-remediation.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("cspm-remediation.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    webhook: CspmWebhookConfig = Field(default_factory=lambda: CspmWebhookConfig())  # type: ignore[call-arg]
