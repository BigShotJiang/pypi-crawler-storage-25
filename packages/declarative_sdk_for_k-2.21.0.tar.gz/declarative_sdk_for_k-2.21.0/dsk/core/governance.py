"""Governance operation models.

G4a only models ownership-transfer requests.  Commander 18.0.0 exposes record
ownership transfer through ``share-record --action owner``; shared-folder
ownership transfer remains a Commander surface gap.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from dsk.core.diff import Change

GOVERNANCE_TRANSFER_RESOURCE = "governance_transfer"
GovernanceObjectType = Literal["record", "folder", "shared_folder"]


class GovernanceTransfer(BaseModel):
    """One record/folder ownership-transfer request."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    uid_ref: str | None = None
    object_type: GovernanceObjectType
    object_uid: str = Field(min_length=1)
    target_user: str = Field(min_length=1)
    source_user: str | None = None
    recursive: bool = False


def governance_transfer_from_change(change: Change) -> GovernanceTransfer:
    """Parse a governance transfer from a plan row."""

    payload = dict(change.after or {})
    object_type = _object_type(payload)
    payload.setdefault("object_type", object_type)
    payload.setdefault("object_uid", _object_uid(payload, object_type=object_type))
    payload.setdefault("target_user", payload.get("target_email"))
    payload.setdefault("source_user", payload.get("source_email"))
    payload.setdefault("uid_ref", change.uid_ref or change.title or None)
    for alias in (
        "record_uid",
        "folder_uid",
        "shared_folder_uid",
        "target_email",
        "source_email",
        "target_type",
    ):
        payload.pop(alias, None)
    return GovernanceTransfer.model_validate(payload)


def _object_type(payload: dict[str, Any]) -> str:
    raw = str(payload.get("object_type") or payload.get("target_type") or "").strip()
    if raw:
        return raw
    if payload.get("record_uid"):
        return "record"
    if payload.get("shared_folder_uid"):
        return "shared_folder"
    if payload.get("folder_uid"):
        return "folder"
    return ""


def _object_uid(payload: dict[str, Any], *, object_type: str) -> Any:
    if payload.get("object_uid"):
        return payload["object_uid"]
    if object_type == "record":
        return payload.get("record_uid")
    if object_type == "shared_folder":
        return payload.get("shared_folder_uid")
    if object_type == "folder":
        return payload.get("folder_uid")
    return None


__all__ = [
    "GOVERNANCE_TRANSFER_RESOURCE",
    "GovernanceObjectType",
    "GovernanceTransfer",
    "governance_transfer_from_change",
]
