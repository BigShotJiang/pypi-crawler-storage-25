"""Refusal predicates — offline policy checks on PAM manifests.

Each predicate accepts the manifest document dict (post-schema-validation) and
returns a list of RefusalViolation objects. Empty list = clean.

Usage:
    from dsk.core.refusal import RefusalRunner, DEFAULT_PREDICATES
    violations = RefusalRunner(DEFAULT_PREDICATES).check(manifest_doc)
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from dsk.core.resource_limits import positive_int_env, read_yaml_file_limited

Severity = Literal["error", "warning", "info"]
RefusalPredicate = Callable[..., list["RefusalViolation"]]
_DEFAULT_MAX_REFUSAL_MANIFEST_BYTES = 20 * 1024 * 1024
_DEFAULT_MAX_REFUSAL_MANIFEST_DEPTH = 64


@dataclass(frozen=True)
class RefusalViolation:
    uid_ref: str
    predicate: str
    severity: Severity
    reason: str
    remediation: str


_BREACH_RE = re.compile(r"breached|compromised|leaked|pwned", re.IGNORECASE)
_ENV_VAR_RE = re.compile(r"\$\{[A-Z_]+\}|\$[A-Z_]{4,}")

_DEDICATED_USER_REMEDIATION = "Create a dedicated pamUser per resource."
_WILDCARD_SCOPE_REMEDIATION = "Replace wildcard scope with explicit permissions."
_ROTATION_REMEDIATION = "Enable rotation_settings with an appropriate schedule."
_BREACH_REMEDIATION = "Rotate immediately and remove breach indicators from notes."
_ENV_VAR_REMEDIATION = "Use KSM record references instead of environment variable placeholders."
_SECRET_CLASS_REMEDIATION = "Set secret_class on each resource for policy grouping."


def refuse_shared_credential(doc: dict[str, Any]) -> list[RefusalViolation]:
    """Reject pamUser uid_refs reused by multiple resource user blocks."""

    refs: dict[str, list[str]] = {}
    for resource in _iter_resources(doc):
        resource_uid = _uid_ref(resource)
        for user in _iter_resource_users(resource):
            user_uid = _uid_ref(user)
            if not user_uid:
                continue
            refs.setdefault(user_uid, []).append(resource_uid or "<unknown-resource>")

    violations: list[RefusalViolation] = []
    for user_uid, resource_uids in refs.items():
        if len(resource_uids) <= 1:
            continue
        violations.append(
            RefusalViolation(
                uid_ref=user_uid,
                predicate="refuse_shared_credential",
                severity="error",
                reason=(
                    f"pamUser uid_ref {user_uid!r} is referenced by {len(resource_uids)} resources."
                ),
                remediation=_DEDICATED_USER_REMEDIATION,
            )
        )
    return violations


def refuse_wildcard_scope(doc: dict[str, Any]) -> list[RefusalViolation]:
    """Reject wildcard resource OTP or explicit all-resource scope settings."""

    violations: list[RefusalViolation] = []
    for resource in _iter_resources(doc):
        reasons: list[str] = []
        if resource.get("otp") == "*":
            reasons.append("otp is wildcard '*'")

        options = _as_dict(_as_dict(resource.get("pam_settings")).get("options"))
        scope = options.get("scope")
        if scope == "*" or (isinstance(scope, str) and scope.lower() == "all"):
            reasons.append("pam_settings.options.scope is wildcard")

        if reasons:
            violations.append(
                RefusalViolation(
                    uid_ref=_uid_ref(resource),
                    predicate="refuse_wildcard_scope",
                    severity="error",
                    reason="; ".join(reasons),
                    remediation=_WILDCARD_SCOPE_REMEDIATION,
                )
            )
    return violations


def refuse_unrotated_age(doc: dict[str, Any], max_age_days: int = 90) -> list[RefusalViolation]:
    """Warn on pamUser records without enabled rotation."""

    violations: list[RefusalViolation] = []
    for user in _iter_users(doc):
        rotation_settings = user.get("rotation_settings")
        if rotation_settings is None:
            reason = f"pamUser has no rotation_settings; max age is {max_age_days} days."
        elif (
            isinstance(rotation_settings, dict)
            and str(rotation_settings.get("enabled", "")).lower() == "off"
        ):
            reason = f"pamUser rotation_settings.enabled is off; max age is {max_age_days} days."
        else:
            continue

        violations.append(
            RefusalViolation(
                uid_ref=_uid_ref(user),
                predicate="refuse_unrotated_age",
                severity="warning",
                reason=reason,
                remediation=_ROTATION_REMEDIATION,
            )
        )
    return violations


def refuse_pre_compromised(
    doc: dict[str, Any], breach_corpus: set[str] | None = None
) -> list[RefusalViolation]:
    """Reject resources or users carrying breach indicators."""

    violations: list[RefusalViolation] = []
    corpus = breach_corpus or set()

    for item in _iter_resource_and_user_records(doc):
        reasons: list[str] = []
        notes = item.get("notes")
        if isinstance(notes, str) and _BREACH_RE.search(notes):
            reasons.append("notes contain breach marker")

        title = item.get("title")
        if isinstance(title, str) and title in corpus:
            reasons.append("title appears in breach corpus")

        if reasons:
            violations.append(
                RefusalViolation(
                    uid_ref=_uid_ref(item),
                    predicate="refuse_pre_compromised",
                    severity="error",
                    reason="; ".join(reasons),
                    remediation=_BREACH_REMEDIATION,
                )
            )
    return violations


def refuse_env_var_secret(doc: dict[str, Any]) -> list[RefusalViolation]:
    """Warn on environment-variable placeholders stored as manifest values."""

    violations: list[RefusalViolation] = []
    for item in _iter_resource_and_user_records(doc):
        fields = [
            field
            for field in ("notes", "title", "otp")
            if isinstance(item.get(field), str) and _ENV_VAR_RE.search(item[field])
        ]
        if not fields:
            continue

        violations.append(
            RefusalViolation(
                uid_ref=_uid_ref(item),
                predicate="refuse_env_var_secret",
                severity="warning",
                reason=f"field(s) reference environment variables: {', '.join(fields)}",
                remediation=_ENV_VAR_REMEDIATION,
            )
        )
    return violations


def refuse_missing_class(doc: dict[str, Any], required: bool = False) -> list[RefusalViolation]:
    """Report resources missing secret_class when that policy is required."""

    if not required:
        return []

    violations: list[RefusalViolation] = []
    for resource in _iter_resources(doc):
        if resource.get("secret_class"):
            continue
        violations.append(
            RefusalViolation(
                uid_ref=_uid_ref(resource),
                predicate="refuse_missing_class",
                severity="info",
                reason="resource has no secret_class",
                remediation=_SECRET_CLASS_REMEDIATION,
            )
        )
    return violations


DEFAULT_PREDICATES: list[RefusalPredicate] = [
    refuse_shared_credential,
    refuse_wildcard_scope,
    refuse_unrotated_age,
    refuse_pre_compromised,
    refuse_env_var_secret,
]


class RefusalRunner:
    def __init__(self, predicates: list[RefusalPredicate], **predicate_kwargs: Any) -> None:
        self.predicates = list(predicates)
        self.predicate_kwargs = dict(predicate_kwargs)

    def check(self, doc: dict[str, Any]) -> list[RefusalViolation]:
        violations: list[RefusalViolation] = []
        for predicate in self.predicates:
            name = _predicate_name(predicate)
            kwargs = _filter_predicate_kwargs(name, self.predicate_kwargs)
            violations.extend(predicate(doc, **kwargs))
        return violations

    def check_manifest_path(self, path: str) -> list[RefusalViolation]:
        data = (
            read_yaml_file_limited(
                Path(path),
                max_bytes=positive_int_env(
                    "DSK_REFUSAL_MAX_MANIFEST_BYTES",
                    _DEFAULT_MAX_REFUSAL_MANIFEST_BYTES,
                ),
                max_depth=positive_int_env(
                    "DSK_REFUSAL_MAX_MANIFEST_DEPTH",
                    _DEFAULT_MAX_REFUSAL_MANIFEST_DEPTH,
                ),
                label="refusal manifest",
                byte_limit_name="DSK_REFUSAL_MAX_MANIFEST_BYTES",
                depth_limit_name="DSK_REFUSAL_MAX_MANIFEST_DEPTH",
            )
            or {}
        )
        if not isinstance(data, dict):
            raise TypeError("manifest must parse to a dict")
        return self.check(data)


def _filter_predicate_kwargs(name: str, kwargs: dict[str, Any]) -> dict[str, Any]:
    accepted: dict[str, set[str]] = {
        "refuse_unrotated_age": {"max_age_days"},
        "refuse_pre_compromised": {"breach_corpus"},
        "refuse_missing_class": {"required"},
    }
    allowed = accepted.get(name, set())
    return {key: value for key, value in kwargs.items() if key in allowed}


def _predicate_name(predicate: RefusalPredicate) -> str:
    return str(getattr(predicate, "__name__", predicate.__class__.__name__))


def _iter_resources(doc: dict[str, Any]) -> Iterator[dict[str, Any]]:
    for resource in _as_list(doc.get("resources")):
        if isinstance(resource, dict):
            yield resource


def _iter_resource_users(resource: dict[str, Any]) -> Iterator[dict[str, Any]]:
    for user in _as_list(resource.get("users")):
        if isinstance(user, dict):
            yield user


def _iter_users(doc: dict[str, Any]) -> Iterator[dict[str, Any]]:
    for user in _as_list(doc.get("users")):
        if isinstance(user, dict):
            yield user
    for resource in _iter_resources(doc):
        yield from _iter_resource_users(resource)


def _iter_resource_and_user_records(doc: dict[str, Any]) -> Iterator[dict[str, Any]]:
    yield from _iter_resources(doc)
    yield from _iter_users(doc)


def _as_dict(value: object) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    return {}


def _as_list(value: object) -> list[object]:
    if isinstance(value, list):
        return value
    return []


def _uid_ref(item: dict[str, Any]) -> str:
    uid_ref = item.get("uid_ref")
    if isinstance(uid_ref, str):
        return uid_ref
    return ""
