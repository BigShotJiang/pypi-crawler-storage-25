"""Keeper PAM Workflow Gate models — workflow-gate.v1.

WorkflowGate is Keeper's native approval workflow engine (Commander v17.2.14+).
Distinct from external ticket gates (Jira/ServiceNow) — these are Keeper-internal
approval chains attached to PAM configurations.

Note: ``dsk.core.models_workflow`` is reserved for ``keeper-workflow.v1``
(PAM workflow uid_ref graphs). This module is ``workflow-gate.v1`` (declarative
approval chain manifest).
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class WorkflowApprovalType(StrEnum):
    any_approver = "any_approver"  # any one approver from list suffices
    all_approvers = "all_approvers"  # all approvers must approve (sequential)
    majority = "majority"  # majority vote
    auto = "auto"  # no approval (auto-grant, audit only)


class WorkflowNotifyChannel(StrEnum):
    email = "email"
    push = "push"  # Keeper app push notification
    both = "both"


class WorkflowApprover(BaseModel):
    email: str = Field(..., description="Keeper user email of the approver")
    notify: WorkflowNotifyChannel = WorkflowNotifyChannel.both
    fallback_email: str | None = Field(
        None,
        description="If primary approver unavailable, escalate to this email",
    )


class WorkflowStep(BaseModel):
    name: str
    approvers: list[WorkflowApprover] = Field(default_factory=list)
    approval_type: WorkflowApprovalType = WorkflowApprovalType.any_approver
    timeout_minutes: int = Field(
        60,
        ge=5,
        le=1440,
        description="Time to wait for approval before escalating or denying",
    )
    auto_deny_on_timeout: bool = Field(
        False,
        description="Deny access if approval not received within timeout",
    )


class WorkflowTrigger(BaseModel):
    pam_config_uid_ref: str = Field(
        ...,
        description="uid_ref of the pam_configuration this workflow guards",
    )
    require_justification: bool = Field(True)
    max_session_minutes: int = Field(
        60,
        ge=5,
        le=1440,
        description="Maximum session duration after approval",
    )


class WorkflowGate(BaseModel):
    name: str
    description: str | None = None
    trigger: WorkflowTrigger
    steps: list[WorkflowStep] = Field(
        default_factory=list,
        description="Approval steps in order. Empty steps = auto-approve (audit only).",
    )
    audit_log: bool = Field(True)
    notify_requester: bool = Field(
        True,
        description="Notify the requester of approval decision",
    )


class WorkflowGateManifestV1(BaseModel):
    """Root model for a workflow-gate.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("workflow-gate.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    workflows: list[WorkflowGate] = Field(default_factory=list)


WORKFLOW_GATE_FAMILY: str = "workflow-gate.v1"

__all__ = [
    "WORKFLOW_GATE_FAMILY",
    "WorkflowApprovalType",
    "WorkflowApprover",
    "WorkflowGate",
    "WorkflowGateManifestV1",
    "WorkflowNotifyChannel",
    "WorkflowStep",
    "WorkflowTrigger",
]
