"""Continuous compliance evidence stream models — continuous-evidence-stream.v1.

Declares a daemon configuration for always-on compliance evidence collection.
Extends compliance-bundle.v1 (CC3) from snapshot → continuous stream.

Source: SOC2 automation research 2026 — 86% less effort with continuous compliance.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class EvidenceStorageBackend(StrEnum):
    s3 = "s3"
    gcs = "gcs"
    azure_blob = "azure_blob"
    local = "local"  # local filesystem (dev/test)


class EvidenceSamplingSchedule(StrEnum):
    hourly = "hourly"
    daily = "daily"
    weekly = "weekly"
    cron = "cron"


class EvidenceStorageConfig(BaseModel):
    backend: EvidenceStorageBackend = EvidenceStorageBackend.local
    bucket: str | None = Field(
        None,
        description="Bucket/container name (S3, GCS, Azure Blob)",
    )
    prefix: str = Field(
        "dsk-evidence/",
        description="Key prefix for stored evidence files",
    )
    region: str | None = Field(
        None,
        description="Cloud region (S3, GCS)",
    )
    credential_env_var: str = Field(
        "CLOUD_STORAGE_CREDENTIALS",
        description="Env var name with cloud credentials (never stored in manifest)",
    )
    local_path: str | None = Field(
        None,
        description="Local path for local backend (dev/test only)",
    )
    retention_days: int = Field(
        365,
        ge=30,
        description="Evidence file retention in days before auto-deletion",
    )


class EvidenceStreamEntry(BaseModel):
    control_id: str
    description: str
    report: str = Field(
        ...,
        description=("DSK report type: password-report, compliance-report, security-audit-report"),
    )
    report_args: list[str] = Field(default_factory=list)
    evidence_file_prefix: str = Field(
        ...,
        description=("Filename prefix — timestamp appended automatically: ac-2-{timestamp}.json"),
    )


class ContinuousEvidenceStreamManifestV1(BaseModel):
    """Root model for a continuous-evidence-stream.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("continuous-evidence-stream.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    frameworks: list[str] = Field(
        default_factory=list,
        description=("Compliance frameworks: fedramp-high, soc2-type2, iso27001, etc."),
    )
    schedule: EvidenceSamplingSchedule = EvidenceSamplingSchedule.daily
    cron: str | None = Field(
        None,
        description="Cron expression (required when schedule=cron)",
    )
    storage: EvidenceStorageConfig = Field(default_factory=lambda: EvidenceStorageConfig())  # type: ignore[call-arg]
    entries: list[EvidenceStreamEntry] = Field(default_factory=list)
    alert_on_failure: bool = Field(
        True,
        description=("Alert via drift-watch Slack/SN channel if evidence collection fails"),
    )
