"""Desired-vs-live diff for ``pipeline-ephemeral-environment.v1`` (offline)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_pipeline_env import PipelineEphemeralManifestV1


def compute_pipeline_env_diff(
    manifest: PipelineEphemeralManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared pipeline ephemeral environment."""
    if live:
        raise NotImplementedError(
            "pipeline-ephemeral-environment.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    for idx, environment in enumerate(manifest.environments):
        payload = environment.model_dump(mode="python", exclude_none=True)
        uid_ref_value = getattr(environment, "uid_ref", None)
        uid_ref = str(uid_ref_value) if uid_ref_value is not None else f"{name}.environments.{idx}"
        title_value = getattr(environment, "name", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="pipeline_ephemeral_env",
                title=str(title_value) if title_value is not None else uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_pipeline_env_diff"]
