"""Single-host apply lock for DSK manifests.

Prevents concurrent ``dsk apply`` runs against the same manifest from
conflicting. The lock is an OS-backed advisory file lock plus JSON metadata
that records the holder PID and process start stamp for stale-file cleanup.
"""

from __future__ import annotations

import errno
import hashlib
import json
import os
import socket
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO

from dsk.core.resource_limits import (
    ResourceLimitError,
    json_loads_limited,
    positive_int_env,
    read_bytes_limited,
)

_LOCK_TIMEOUT_SECONDS = 300  # 5 minutes default
_LOCK_POLL_INTERVAL = 5
_DEFAULT_LOCK_MAX_BYTES = 64 * 1024
_DEFAULT_LOCK_MAX_DEPTH = 16
_DEFAULT_LOCK_MANIFEST_MAX_BYTES = 20 * 1024 * 1024
_PROCESS_START_TIMEOUT_SECONDS = 2

_HELD_LOCKS_GUARD = threading.Lock()
_HELD_LOCKS: set[Path] = set()


def _lock_max_bytes() -> int:
    return positive_int_env("DSK_LOCK_MAX_BYTES", _DEFAULT_LOCK_MAX_BYTES)


def _lock_max_depth() -> int:
    return positive_int_env("DSK_LOCK_MAX_DEPTH", _DEFAULT_LOCK_MAX_DEPTH)


def _lock_manifest_max_bytes() -> int:
    return positive_int_env("DSK_LOCK_MAX_MANIFEST_BYTES", _DEFAULT_LOCK_MANIFEST_MAX_BYTES)


@dataclass
class LockInfo:
    holder: str  # hostname:pid
    acquired_at: float
    manifest_hash: str
    expires_at: float
    pid: int | None = None
    pid_start_time: str | None = None

    @property
    def is_expired(self) -> bool:
        return time.time() > self.expires_at

    def to_dict(self) -> dict[str, str]:
        payload = {
            "holder": self.holder,
            "acquired_at": str(self.acquired_at),
            "manifest_hash": self.manifest_hash,
            "expires_at": str(self.expires_at),
        }
        if self.pid is not None:
            payload["pid"] = str(self.pid)
        if self.pid_start_time:
            payload["pid_start_time"] = self.pid_start_time
        return payload

    @classmethod
    def from_dict(cls, d: dict[str, str]) -> LockInfo:
        return cls(
            holder=d["holder"],
            acquired_at=float(d["acquired_at"]),
            manifest_hash=d["manifest_hash"],
            expires_at=float(d["expires_at"]),
            pid=_parse_pid(d.get("pid")) or _pid_from_holder(d["holder"]),
            pid_start_time=d.get("pid_start_time") or None,
        )


class ApplyLockError(Exception):
    """Raised when the apply lock cannot be acquired."""


class FileLock:
    """
    File-based apply lock for single-host use.
    Uses a .dsk-lock file alongside the manifest.
    """

    def __init__(self, manifest_path: str, timeout_seconds: int = _LOCK_TIMEOUT_SECONDS) -> None:
        self._lock_path = manifest_path + ".dsk-lock"
        self._timeout = timeout_seconds
        self._manifest_hash = _manifest_hash(manifest_path)
        self._fh: BinaryIO | None = None
        self._lock_key: Path | None = None

    def acquire(self) -> LockInfo:
        """Acquire the lock. Raises ApplyLockError if already held."""
        lock_path = Path(self._lock_path)
        lock_key = _lock_key(lock_path)
        _reserve_process_lock(lock_key, self._lock_path)

        fh: BinaryIO | None = None
        try:
            try:
                fh = lock_path.open("a+b")
            except OSError as exc:
                raise ApplyLockError(
                    f"Could not open apply lock '{self._lock_path}': {exc}"
                ) from exc

            if not _try_lock_handle(fh):
                raise ApplyLockError(_lock_held_message(self._lock_path, lock_path))

            existing = _read_lock_info_from_handle(fh)
            if existing is not None and not _lock_info_is_stale(existing):
                _unlock_handle(fh)
                raise ApplyLockError(_lock_held_message(self._lock_path, lock_path, existing))

            now = time.time()
            pid = os.getpid()
            info = LockInfo(
                holder=f"{socket.gethostname()}:{pid}",
                acquired_at=now,
                manifest_hash=self._manifest_hash,
                expires_at=now + self._timeout,
                pid=pid,
                pid_start_time=_process_start_stamp(pid),
            )
            _write_lock_info_to_handle(fh, info)
            self._fh = fh
            self._lock_key = lock_key
            return info
        except Exception:
            if fh is not None:
                try:
                    _unlock_handle(fh)
                finally:
                    fh.close()
            _release_process_lock(lock_key)
            raise

    def release(self) -> None:
        """Release the lock."""
        if self._fh is None:
            return

        fh = self._fh
        lock_key = self._lock_key
        self._fh = None
        self._lock_key = None
        try:
            Path(self._lock_path).unlink(missing_ok=True)
        except OSError:
            pass
        finally:
            try:
                _unlock_handle(fh)
            finally:
                fh.close()
                if lock_key is not None:
                    _release_process_lock(lock_key)

    def __enter__(self) -> LockInfo:
        return self.acquire()

    def __exit__(self, *_: object) -> None:
        self.release()


def _manifest_hash(manifest_path: str) -> str:
    """SHA256 of manifest content for lock identity."""
    try:
        data = read_bytes_limited(
            Path(manifest_path),
            max_bytes=_lock_manifest_max_bytes(),
            label="lock manifest",
            limit_name="DSK_LOCK_MAX_MANIFEST_BYTES",
        )
        return hashlib.sha256(data).hexdigest()[:12]
    except ResourceLimitError:
        return "unknown"


def _lock_key(lock_path: Path) -> Path:
    try:
        return lock_path.resolve(strict=False)
    except OSError:
        return lock_path.absolute()


def _reserve_process_lock(lock_key: Path, lock_path: str) -> None:
    with _HELD_LOCKS_GUARD:
        if lock_key in _HELD_LOCKS:
            raise ApplyLockError(f"Apply lock held by current process for '{lock_path}'.")
        _HELD_LOCKS.add(lock_key)


def _release_process_lock(lock_key: Path) -> None:
    with _HELD_LOCKS_GUARD:
        _HELD_LOCKS.discard(lock_key)


def _try_lock_handle(fh: BinaryIO) -> bool:
    if os.name == "nt":
        import msvcrt

        try:
            fh.seek(0)
            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)  # type: ignore[attr-defined]
        except OSError:
            return False
        return True

    import fcntl

    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return False
    return True


def _unlock_handle(fh: BinaryIO) -> None:
    if os.name == "nt":
        import msvcrt

        try:
            fh.seek(0)
            msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)  # type: ignore[attr-defined]
        except OSError:
            pass
        return

    import fcntl

    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
    except OSError:
        pass


def _read_lock_info_from_handle(fh: BinaryIO) -> LockInfo | None:
    try:
        size = os.fstat(fh.fileno()).st_size
        if size == 0:
            return None
        max_bytes = _lock_max_bytes()
        if size > max_bytes:
            return None
        fh.seek(0)
        raw = fh.read(max_bytes + 1)
    except OSError as exc:
        raise ApplyLockError(f"Could not read apply lock metadata: {exc}") from exc
    except ResourceLimitError:
        return None

    if len(raw) > _lock_max_bytes() or not raw.strip():
        return None

    try:
        data = json_loads_limited(
            raw,
            max_bytes=_lock_max_bytes(),
            max_depth=_lock_max_depth(),
            label="apply lock",
            byte_limit_name="DSK_LOCK_MAX_BYTES",
            depth_limit_name="DSK_LOCK_MAX_DEPTH",
        )
        if not isinstance(data, dict):
            raise ValueError("apply lock must be a JSON object")
        return LockInfo.from_dict({str(key): str(value) for key, value in data.items()})
    except (
        KeyError,
        ValueError,
        json.JSONDecodeError,
        UnicodeDecodeError,
        ResourceLimitError,
    ):
        return None


def _write_lock_info_to_handle(fh: BinaryIO, info: LockInfo) -> None:
    raw = json.dumps(info.to_dict(), sort_keys=True).encode("utf-8")
    fh.seek(0)
    fh.truncate(0)
    fh.write(raw)
    fh.write(b"\n")
    fh.flush()
    os.fsync(fh.fileno())


def _lock_info_is_stale(info: LockInfo) -> bool:
    if info.is_expired:
        return True

    pid = info.pid or _pid_from_holder(info.holder)
    if pid is None:
        return False
    if not _pid_exists(pid):
        return True
    if info.pid_start_time:
        current_start = _process_start_stamp(pid)
        return current_start is not None and current_start != info.pid_start_time
    return False


def _lock_held_message(
    lock_path_display: str,
    lock_path: Path,
    existing: LockInfo | None = None,
) -> str:
    existing = existing or _read_lock_info_from_path(lock_path)
    if existing is None:
        return (
            f"Apply lock already held for '{lock_path_display}'. "
            "Wait for the active apply to finish."
        )
    age = max(0, int(time.time() - existing.acquired_at))
    expires_in = int(existing.expires_at - time.time())
    return (
        f"Apply lock held by '{existing.holder}' "
        f"(acquired {age}s ago, expires in {expires_in}s). "
        f"Wait or remove '{lock_path_display}' if the holder crashed."
    )


def _read_lock_info_from_path(lock_path: Path) -> LockInfo | None:
    try:
        with lock_path.open("rb") as fh:
            return _read_lock_info_from_handle(fh)
    except OSError:
        return None


def _parse_pid(raw: str | None) -> int | None:
    if not raw:
        return None
    try:
        pid = int(raw)
    except ValueError:
        return None
    return pid if pid > 0 else None


def _pid_from_holder(holder: str) -> int | None:
    return _parse_pid(holder.rsplit(":", 1)[-1])


def _pid_exists(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError as exc:
        return exc.errno == errno.EPERM
    return True


def _process_start_stamp(pid: int) -> str | None:
    if not _pid_exists(pid):
        return None

    proc_stat = Path(f"/proc/{pid}/stat")
    try:
        raw = proc_stat.read_text(encoding="utf-8")
    except OSError:
        raw = ""
    if raw:
        try:
            after_comm = raw.rsplit(") ", 1)[1]
            fields = after_comm.split()
            return f"linux-starttime:{fields[19]}"
        except (IndexError, ValueError):
            pass

    if os.name == "nt":
        return _windows_process_start_stamp(pid)
    return _posix_process_start_stamp(pid)


def _posix_process_start_stamp(pid: int) -> str | None:
    try:
        result = subprocess.run(
            ["ps", "-o", "lstart=", "-p", str(pid)],
            check=False,
            capture_output=True,
            text=True,
            timeout=_PROCESS_START_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    stamp = result.stdout.strip()
    return f"ps-lstart:{stamp}" if stamp else None


def _windows_process_start_stamp(pid: int) -> str | None:
    try:
        result = subprocess.run(
            ["wmic", "process", "where", f"ProcessId={pid}", "get", "CreationDate", "/value"],
            check=False,
            capture_output=True,
            text=True,
            timeout=_PROCESS_START_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    for line in result.stdout.splitlines():
        if line.startswith("CreationDate="):
            stamp = line.split("=", 1)[1].strip()
            return f"wmic-creationdate:{stamp}" if stamp else None
    return None
