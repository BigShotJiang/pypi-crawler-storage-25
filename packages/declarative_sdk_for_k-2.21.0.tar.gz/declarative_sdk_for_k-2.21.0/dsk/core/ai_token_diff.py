"""Desired-vs-live diff for ``ai-token.v1`` (offline; no tenant readback)."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_ai_token import AiCapabilityToken, AiTokenManifestV1


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def compute_ai_token_diff(
    manifest: AiTokenManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Classify declared AI capability tokens against a live configuration snapshot."""
    name = manifest_name or "ai-token.v1"
    changes: list[Change] = []

    if live is None:
        for idx, token in enumerate(manifest.tokens):
            payload = token.model_dump(mode="python", exclude_none=True)
            uid_ref = getattr(token, "uid_ref", None) or f"{name}.{idx}"
            token_name = getattr(token, "name", None)
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=str(uid_ref),
                    resource_type="ai_capability_token",
                    title=str(token_name) if token_name else str(uid_ref),
                    before={},
                    after=payload,
                    manifest_name=name,
                ),
            )
        return changes

    live_by_name: dict[str, dict[str, Any]] = {}
    for row in live.get("tokens") or []:
        if isinstance(row, Mapping) and row.get("name") is not None:
            live_by_name[str(row["name"])] = dict(row)

    for idx, token in enumerate(manifest.tokens):
        payload = token.model_dump(mode="python", exclude_none=True)
        uid_ref = getattr(token, "uid_ref", None) or f"{name}.{idx}"
        token_name = getattr(token, "name", None)
        title = str(token_name) if token_name else str(uid_ref)
        live_row = live_by_name.get(str(token_name)) if token_name is not None else None

        if live_row is None:
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=str(uid_ref),
                    resource_type="ai_capability_token",
                    title=title,
                    before={},
                    after=payload,
                    manifest_name=name,
                ),
            )
            continue

        live_payload = AiCapabilityToken.model_validate(live_row).model_dump(
            mode="python", exclude_none=True
        )
        if _canonical_json(live_payload) == _canonical_json(payload):
            changes.append(
                Change(
                    kind=ChangeKind.NOOP,
                    uid_ref=str(uid_ref),
                    resource_type="ai_capability_token",
                    title=title,
                    before=dict(live_row),
                    after=payload,
                    reason="no drift",
                    manifest_name=name,
                ),
            )
        else:
            changes.append(
                Change(
                    kind=ChangeKind.UPDATE,
                    uid_ref=str(uid_ref),
                    resource_type="ai_capability_token",
                    title=title,
                    before=dict(live_row),
                    after=payload,
                    manifest_name=name,
                ),
            )

    return changes


__all__ = ["compute_ai_token_diff"]
