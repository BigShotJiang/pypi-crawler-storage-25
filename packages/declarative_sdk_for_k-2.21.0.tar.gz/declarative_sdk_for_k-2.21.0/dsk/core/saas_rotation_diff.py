"""Desired-vs-live diff for ``keeper-saas-rotation.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_saas_rotation import SaaSRotationManifestV1


def compute_saas_rotation_diff(
    manifest: SaaSRotationManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 — reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared SaaS rotation resource (offline demo path).

    Live SaaS rotation surfaces require ``pam saas config`` (Commander 18.0.0+);
    callers pass ``None`` until that readback path is implemented.
    """
    if live:
        raise NotImplementedError(
            "keeper-saas-rotation.v1 live readback is not implemented — pass live=None",
        )

    name = manifest_name or "keeper-saas-rotation"
    changes: list[Change] = []

    for rotation in manifest.rotations:
        payload = rotation.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=rotation.uid_ref,
                resource_type="saas_rotation_config",
                title=str(rotation.name),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for binding in manifest.bindings:
        payload = binding.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=binding.uid_ref,
                resource_type="saas_rotation_binding",
                title=str(binding.uid_ref),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_saas_rotation_diff"]
