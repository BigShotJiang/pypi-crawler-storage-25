"""Desired-vs-live diff for ``keeper-privileged-access.v1`` (offline/live-empty)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_privileged_access import PrivilegedAccessManifestV1


def compute_privileged_access_diff(
    manifest: PrivilegedAccessManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved for future live readback
) -> list[Change]:
    """Classify declared privileged-access objects against an empty or stub live snapshot.

    Live backends for this family are not declarative-shaped today — callers pass ``{}``.
    """
    _ = allow_delete  # reserved for delete semantics once live readback exists
    if live:
        raise NotImplementedError(
            "privileged-access live readback is not implemented — pass {} or omit live"
        )
    name = manifest_name or "keeper-privileged-access"

    changes: list[Change] = []
    for user in manifest.users:
        payload = user.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=user.uid_ref,
                resource_type="privileged_user",
                title=user.principal,
                before={},
                after=payload,
                manifest_name=name,
            )
        )
    for group in manifest.groups:
        payload = group.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=group.uid_ref,
                resource_type="privileged_group",
                title=group.name,
                before={},
                after=payload,
                manifest_name=name,
            )
        )
    for membership in manifest.group_memberships:
        payload = membership.model_dump(mode="python", exclude_none=True)
        title = membership.uid_ref
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=membership.uid_ref,
                resource_type="privileged_group_membership",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            )
        )
    return changes


__all__ = ["compute_privileged_access_diff"]
