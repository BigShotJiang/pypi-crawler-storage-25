"""SPIFFE workload identity binding models — spiffe-binding.v1."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class SpiffeMatchMode(StrEnum):
    exact = "exact"  # exact SPIFFE ID match
    prefix = "prefix"  # prefix match on the path component
    regex = "regex"  # regex match (advanced)


class SpiffeResourceBinding(BaseModel):
    uid_ref: str = Field(..., description="DSK uid_ref of the Keeper PAM resource")
    role: str = Field("read", description="Access role granted on match: read | admin | custom")
    ttl_seconds: int = Field(
        3600,
        ge=60,
        le=86400,
        description="Credential TTL in seconds (60s – 24h)",
    )


class SpiffeIdentityRule(BaseModel):
    spiffe_id: str = Field(
        ...,
        description="SPIFFE ID or pattern, e.g. spiffe://acme.com/ns/prod/sa/ci-runner",
    )
    match: SpiffeMatchMode = SpiffeMatchMode.exact
    trust_domain: str = Field(..., description="SPIFFE trust domain, e.g. acme.com")
    resources: list[SpiffeResourceBinding] = Field(default_factory=list)
    allow_jit: bool = Field(
        False,
        description="If true, binding triggers JIT access window rather than standing grant",
    )
    audit_log: bool = Field(True)


class SpiffeBindingManifestV1(BaseModel):
    """Root model for a spiffe-binding.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("spiffe-binding.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    trust_domain: str = Field(
        ..., description="Default trust domain for all rules in this manifest"
    )
    rules: list[SpiffeIdentityRule] = Field(default_factory=list)
