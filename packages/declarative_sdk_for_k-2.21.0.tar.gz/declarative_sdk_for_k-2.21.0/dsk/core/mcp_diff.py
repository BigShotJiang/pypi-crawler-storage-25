"""Desired-vs-live diff for ``mcp-secrets-binding.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_mcp import McpSecretsBindingManifestV1


def compute_mcp_diff(
    manifest: McpSecretsBindingManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared MCP server binding."""
    if live:
        raise NotImplementedError(
            "mcp-secrets-binding.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or "mcp-secrets-binding"
    changes: list[Change] = []

    for idx, server in enumerate(manifest.servers):
        payload = server.model_dump(mode="python", exclude_none=True)
        uid_ref = str(getattr(server, "uid_ref", None) or f"{name}.servers.{idx}")
        title = str(
            getattr(server, "server_name", None) or getattr(server, "name", None) or uid_ref,
        )
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="mcp_server_binding",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_mcp_diff"]
