"""Desired-vs-live diff for ``gateway-ha.v1`` (offline)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_gateway_ha import GatewayHaManifestV1


def compute_gateway_ha_diff(
    manifest: GatewayHaManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared gateway HA cluster."""
    if live:
        raise NotImplementedError(
            "gateway-ha.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    for idx, cluster in enumerate(manifest.clusters):
        payload = cluster.model_dump(mode="python", exclude_none=True)
        uid_ref_value = getattr(cluster, "uid_ref", None)
        uid_ref = str(uid_ref_value) if uid_ref_value is not None else f"{name}.clusters.{idx}"
        title_value = getattr(cluster, "name", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="gateway_ha_cluster",
                title=str(title_value) if title_value is not None else uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_gateway_ha_diff"]
