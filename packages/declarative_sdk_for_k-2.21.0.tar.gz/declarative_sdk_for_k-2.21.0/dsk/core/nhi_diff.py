"""Desired-vs-live diff for ``nhi-agent.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_nhi import NhiAgentManifest


def compute_nhi_diff(
    manifest: NhiAgentManifest,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 — reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared NHI resource (offline demo path).

    Live NHI surfaces are not declarative-shaped today — callers pass ``None`` or omit live.
    """
    if live:
        raise NotImplementedError(
            "nhi-agent.v1 live readback is not implemented — pass live=None",
        )

    name = manifest_name or "nhi-agent"
    changes: list[Change] = []
    for resource in manifest.resources:
        payload = resource.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=resource.uid_ref,
                resource_type="nhi_agent",
                title=str(resource.name),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )
    return changes


__all__ = ["compute_nhi_diff"]
