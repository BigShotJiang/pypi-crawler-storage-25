"""Typed models for ``ai-agent.v1`` manifests.

AI agent identity scaffold — maps to Keeper's AI security spec attributes:
purpose, scope, allowed_tools, and expiration. Guardian policy alignment is
optional and preview-gated. Commander write path is an upstream gap pending
AI identity surface GA.

Credential delivery is planned via ``keeper-ksm.v1`` (``credential_ref``
cross-family reference to a KSM app or vault record).
"""

from __future__ import annotations

from typing import Annotated, Any, Literal, TypeAlias

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    model_validator,
)

from dsk.core.errors import SchemaError

AI_AGENT_FAMILY: Literal["ai-agent.v1"] = "ai-agent.v1"

UidRef: TypeAlias = Annotated[
    str,
    StringConstraints(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
NonEmptyString: TypeAlias = Annotated[str, StringConstraints(min_length=1)]


class _AiAgentModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid", str_strip_whitespace=True)


class AiAgentResource(_AiAgentModel):
    """One AI agent identity resource."""

    uid_ref: UidRef
    name: NonEmptyString
    purpose: NonEmptyString
    scope: list[NonEmptyString] = Field(default_factory=list)
    allowed_tools: list[NonEmptyString] = Field(default_factory=list)
    expiration: str | None = None
    guardian_policy: str | None = None
    credential_ref: str | None = None
    tags: dict[str, str] = Field(default_factory=dict)
    # Excessive-agency guard — OWASP Agentic Top 10 A1 + A2
    max_scope_count: int | None = None  # fail plan if scope list exceeds N
    allowed_mcp_server_refs: list[UidRef] = Field(
        default_factory=list,
    )  # uid_refs from mcp-server-allowlist.v1
    prompt_injection_guard: bool = (
        False  # marks agent as protected; triggers audit on PR/issue inputs
    )
    memory_isolation: bool = (
        False  # agent memory scoped to single session (no cross-session recall)
    )


class AiAgentManifest(_AiAgentModel):
    """Top-level ``ai-agent.v1`` manifest."""

    ai_schema: Literal["ai-agent.v1"] = Field(default=AI_AGENT_FAMILY, alias="schema")
    resources: list[AiAgentResource] = Field(default_factory=list)

    @model_validator(mode="after")
    def _uid_refs_are_unique(self) -> AiAgentManifest:
        seen: dict[str, str] = {}
        duplicates: set[str] = set()
        for resource in self.resources:
            if resource.uid_ref in seen:
                duplicates.add(resource.uid_ref)
            seen[resource.uid_ref] = "ai_agent"
        if duplicates:
            raise ValueError(f"duplicate uid_ref values: {sorted(duplicates)}")
        return self

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        """Return ``(uid_ref, kind)`` for all AI agent resources."""
        return [(r.uid_ref, "ai_agent") for r in self.resources]


def load_ai_agent_manifest(document: dict[str, Any]) -> AiAgentManifest:
    """Validate with JSON Schema, then parse as ``AiAgentManifest``."""
    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != AI_AGENT_FAMILY:
        raise SchemaError(
            reason=f"expected {AI_AGENT_FAMILY!r}, got {family!r}",
            next_action="set schema: ai-agent.v1 on the manifest",
        )
    try:
        return AiAgentManifest.model_validate(document)
    except ValidationError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match ai-agent.v1 typed rules",
        ) from exc
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match ai-agent.v1 typed rules",
        ) from exc


__all__ = [
    "AI_AGENT_FAMILY",
    "AiAgentManifest",
    "AiAgentResource",
    "load_ai_agent_manifest",
]
