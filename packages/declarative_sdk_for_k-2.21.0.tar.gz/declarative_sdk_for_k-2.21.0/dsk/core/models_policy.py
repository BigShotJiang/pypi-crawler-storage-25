"""Dataclass models and diff helpers for ``keeper-policy.v1``.

The policy scaffold groups role-enforcement-backed Keeper enterprise policies
under one manifest family. Commander 18.0.0 exposes these as
``enterprise-role --enforcement`` writes, so this module keeps the model and
the enforcement mapping in one place for both mock and Commander providers.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass, field, fields
from typing import Any, ClassVar, Literal

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import SchemaError

POLICY_FAMILY: Literal["keeper-policy.v1"] = "keeper-policy.v1"
KEEPER_POLICY_FAMILY: Literal["keeper-policy.v1"] = POLICY_FAMILY

PASSWORD_POLICY = "password_policy"
SHARING_POLICY = "sharing_policy"
TWO_FA_POLICY = "two_fa_policy"
IP_ALLOWLIST_POLICY = "ip_allowlist_policy"
SESSION_TIMEOUT_POLICY = "session_timeout_policy"
AUDIT_POLICY = "audit_policy"

PASSWORD_POLICY_NAME = "password-policy"
SHARING_POLICY_NAME = "sharing-policy"
TWO_FA_POLICY_NAME = "2FA-policy"
IP_ALLOWLIST_POLICY_NAME = "ip-allowlist-policy"
SESSION_TIMEOUT_POLICY_NAME = "session-timeout-policy"
AUDIT_POLICY_NAME = "audit-policy"

COMMANDER_WIRED_POLICY_TYPES: frozenset[str] = frozenset(
    {
        PASSWORD_POLICY,
        SHARING_POLICY,
        TWO_FA_POLICY,
        IP_ALLOWLIST_POLICY,
        SESSION_TIMEOUT_POLICY,
    }
)
UPSTREAM_GAP_POLICY_TYPES: frozenset[str] = frozenset({AUDIT_POLICY})

_POLICY_DISPLAY_BY_RESOURCE = {
    PASSWORD_POLICY: PASSWORD_POLICY_NAME,
    SHARING_POLICY: SHARING_POLICY_NAME,
    TWO_FA_POLICY: TWO_FA_POLICY_NAME,
    IP_ALLOWLIST_POLICY: IP_ALLOWLIST_POLICY_NAME,
    SESSION_TIMEOUT_POLICY: SESSION_TIMEOUT_POLICY_NAME,
    AUDIT_POLICY: AUDIT_POLICY_NAME,
}
_POLICY_RESOURCE_BY_DISPLAY = {v: k for k, v in _POLICY_DISPLAY_BY_RESOURCE.items()}


def _drop_none(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _drop_none(v) for k, v in value.items() if v is not None}
    if isinstance(value, list):
        return [_drop_none(item) for item in value]
    if isinstance(value, tuple):
        return [_drop_none(item) for item in value]
    return value


def _canonical_json(value: Any) -> str:
    return json.dumps(_drop_none(value), sort_keys=True, separators=(",", ":"), default=str)


@dataclass(frozen=True, kw_only=True)
class PolicyBase:
    """Shared fields for every policy row."""

    uid_ref: str
    name: str
    role_uid_ref: str
    description: str | None = None
    role_id: str | None = None
    role_name: str | None = None

    policy_resource_type: ClassVar[str]
    policy_type: ClassVar[str]

    def to_dict(self) -> dict[str, Any]:
        payload = _drop_none(asdict(self))
        payload["policy_type"] = self.policy_type
        return payload


@dataclass(frozen=True, kw_only=True)
class PasswordPolicy(PolicyBase):
    """Master-password and generated-password enforcement policy."""

    policy_resource_type: ClassVar[str] = PASSWORD_POLICY
    policy_type: ClassVar[str] = PASSWORD_POLICY_NAME

    min_length: int | None = None
    min_digits: int | None = None
    min_uppercase: int | None = None
    min_lowercase: int | None = None
    min_special: int | None = None
    max_age_days: int | None = None
    reuse_restrict_days: int | None = None
    expired_as_of_epoch_ms: int | None = None
    allow_alternate_passwords: bool | None = None
    mask_passwords_while_editing: bool | None = None


@dataclass(frozen=True, kw_only=True)
class SharingPolicy(PolicyBase):
    """Sharing and upload restriction policy."""

    policy_resource_type: ClassVar[str] = SHARING_POLICY
    policy_type: ClassVar[str] = SHARING_POLICY_NAME

    restrict_all: bool | None = None
    restrict_incoming: bool | None = None
    restrict_outgoing: bool | None = None
    restrict_enterprise: bool | None = None
    restrict_enterprise_incoming: bool | None = None
    restrict_enterprise_outgoing: bool | None = None
    restrict_file_upload: bool | None = None
    restrict_export: bool | None = None
    restrict_create_shared_folder: bool | None = None
    restrict_link_sharing: bool | None = None
    restrict_record_share_attachments: bool | None = None
    restrict_record_to_shared_folders: bool | None = None
    restrict_shared_folder_record_removal: bool | None = None
    restrict_shared_folder_folder_deletion: bool | None = None
    restrict_can_edit_external_shares: bool | None = None


@dataclass(frozen=True, kw_only=True)
class TwoFactorPolicy(PolicyBase):
    """Two-factor requirement, duration, and channel policy."""

    policy_resource_type: ClassVar[str] = TWO_FA_POLICY
    policy_type: ClassVar[str] = TWO_FA_POLICY_NAME

    require_two_factor: bool | None = None
    duration_web: Literal["login", "12_hours", "24_hours", "30_days", "forever"] | None = None
    duration_mobile: Literal["login", "12_hours", "24_hours", "30_days", "forever"] | None = None
    duration_desktop: Literal["login", "12_hours", "24_hours", "30_days", "forever"] | None = None
    restrict_text: bool | None = None
    restrict_google: bool | None = None
    restrict_duo: bool | None = None
    restrict_rsa: bool | None = None
    restrict_dna: bool | None = None
    restrict_security_keys: bool | None = None
    require_security_key_pin: bool | None = None
    restrict_totp_field: bool | None = None


@dataclass(frozen=True, kw_only=True)
class IpAllowlistPolicy(PolicyBase):
    """IP allowlist policy for login, vault, and TIP zone access."""

    policy_resource_type: ClassVar[str] = IP_ALLOWLIST_POLICY
    policy_type: ClassVar[str] = IP_ALLOWLIST_POLICY_NAME

    login_ip_ranges: list[str] | None = None
    vault_ip_ranges: list[str] | None = None
    tip_zone_ip_ranges: list[str] | None = None
    restrict_ip_autoapproval: bool | None = None


@dataclass(frozen=True, kw_only=True)
class SessionTimeoutPolicy(PolicyBase):
    """Session lifetime, logout timer, and persistent-login policy."""

    policy_resource_type: ClassVar[str] = SESSION_TIMEOUT_POLICY
    policy_type: ClassVar[str] = SESSION_TIMEOUT_POLICY_NAME

    max_session_login_minutes: int | None = None
    logout_timer_web_minutes: int | None = None
    logout_timer_mobile_minutes: int | None = None
    logout_timer_desktop_minutes: int | None = None
    restrict_persistent_login: bool | None = None
    stay_logged_in_default: bool | None = None
    restrict_offline_access: bool | None = None


@dataclass(frozen=True, kw_only=True)
class AuditPolicy(PolicyBase):
    """Audit policy scaffold.

    Commander 18.0.0 has breach-watch event toggles, but no complete
    declarative audit retention/export/reporting writer. The provider keeps
    this type as an upstream gap until that surface exists.
    """

    policy_resource_type: ClassVar[str] = AUDIT_POLICY
    policy_type: ClassVar[str] = AUDIT_POLICY_NAME

    send_breach_watch_events: bool | None = None
    restrict_breach_watch: bool | None = None
    retention_days: int | None = None
    export_events: bool | None = None
    report_recipients: list[str] | None = None


PolicyRow = (
    PasswordPolicy
    | SharingPolicy
    | TwoFactorPolicy
    | IpAllowlistPolicy
    | SessionTimeoutPolicy
    | AuditPolicy
)


@dataclass(frozen=True, kw_only=True)
class PolicyManifestV1:
    """Top-level ``keeper-policy.v1`` manifest."""

    schema: str = POLICY_FAMILY
    name: str
    manager: str = "dsk"
    password_policies: tuple[PasswordPolicy, ...] = field(default_factory=tuple)
    sharing_policies: tuple[SharingPolicy, ...] = field(default_factory=tuple)
    two_fa_policies: tuple[TwoFactorPolicy, ...] = field(default_factory=tuple)
    ip_allowlist_policies: tuple[IpAllowlistPolicy, ...] = field(default_factory=tuple)
    session_timeout_policies: tuple[SessionTimeoutPolicy, ...] = field(default_factory=tuple)
    audit_policies: tuple[AuditPolicy, ...] = field(default_factory=tuple)

    def iter_policies(self) -> Iterable[tuple[str, PolicyRow]]:
        yield from ((PASSWORD_POLICY, p) for p in self.password_policies)
        yield from ((SHARING_POLICY, p) for p in self.sharing_policies)
        yield from ((TWO_FA_POLICY, p) for p in self.two_fa_policies)
        yield from ((IP_ALLOWLIST_POLICY, p) for p in self.ip_allowlist_policies)
        yield from ((SESSION_TIMEOUT_POLICY, p) for p in self.session_timeout_policies)
        yield from ((AUDIT_POLICY, p) for p in self.audit_policies)

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        return [(policy.uid_ref, resource_type) for resource_type, policy in self.iter_policies()]

    def to_dict(self) -> dict[str, Any]:
        return _drop_none(
            {
                "schema": self.schema,
                "name": self.name,
                "manager": self.manager,
                "password_policies": [p.to_dict() for p in self.password_policies],
                "sharing_policies": [p.to_dict() for p in self.sharing_policies],
                "two_fa_policies": [p.to_dict() for p in self.two_fa_policies],
                "ip_allowlist_policies": [p.to_dict() for p in self.ip_allowlist_policies],
                "session_timeout_policies": [p.to_dict() for p in self.session_timeout_policies],
                "audit_policies": [p.to_dict() for p in self.audit_policies],
            }
        )


_POLICY_COLLECTIONS: tuple[tuple[str, str, type[PolicyRow]], ...] = (
    (PASSWORD_POLICY, "password_policies", PasswordPolicy),
    (SHARING_POLICY, "sharing_policies", SharingPolicy),
    (TWO_FA_POLICY, "two_fa_policies", TwoFactorPolicy),
    (IP_ALLOWLIST_POLICY, "ip_allowlist_policies", IpAllowlistPolicy),
    (SESSION_TIMEOUT_POLICY, "session_timeout_policies", SessionTimeoutPolicy),
    (AUDIT_POLICY, "audit_policies", AuditPolicy),
)
_POLICY_BLOCK_BY_RESOURCE = {
    resource_type: block for resource_type, block, _cls in _POLICY_COLLECTIONS
}


def _coerce_policy(cls: type[PolicyRow], row: Mapping[str, Any]) -> PolicyRow:
    allowed = {item.name for item in fields(cls)}
    payload = {key: value for key, value in row.items() if key in allowed}
    return cls(**payload)  # type: ignore[arg-type, misc]


def policy_manifest_from_dict(document: Mapping[str, Any]) -> PolicyManifestV1:
    """Build dataclass models from an already schema-valid document."""

    two_fa_rows = (
        document.get("two_fa_policies")
        or document.get("two_factor_policies")
        or document.get("2fa_policies")
        or []
    )
    data: dict[str, Any] = {
        "schema": str(document.get("schema") or POLICY_FAMILY),
        "name": str(document.get("name") or "keeper-policy"),
        "manager": str(document.get("manager") or "dsk"),
        "two_fa_policies": tuple(_coerce_policy(TwoFactorPolicy, row) for row in two_fa_rows),
    }
    for resource_type, block, cls in _POLICY_COLLECTIONS:
        if resource_type == TWO_FA_POLICY:
            continue
        rows = document.get(block) or []
        data[block] = tuple(_coerce_policy(cls, row) for row in rows)
    return PolicyManifestV1(**data)


def load_policy_manifest(document: dict[str, Any]) -> PolicyManifestV1:
    """Validate with JSON Schema, then parse as dataclass models."""

    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != POLICY_FAMILY:
        raise SchemaError(
            reason=f"expected {POLICY_FAMILY!r}, got {family!r}",
            next_action="set schema: keeper-policy.v1 on the manifest",
        )
    try:
        return policy_manifest_from_dict(document)
    except (TypeError, ValueError) as exc:
        raise SchemaError(
            reason=f"typed validation failed: {exc}",
            next_action="fix fields to match keeper-policy.v1 typed rules",
        ) from exc


def policy_apply_order(manifest: PolicyManifestV1) -> list[str]:
    """Return deterministic policy uid_ref order."""

    return [uid_ref for uid_ref, _kind in manifest.iter_uid_refs()]


def _policy_payload(policy: PolicyRow) -> dict[str, Any]:
    return policy.to_dict()


def _desired_policy_objects(
    manifest: PolicyManifestV1,
) -> list[tuple[str, str, str, dict[str, Any]]]:
    out: list[tuple[str, str, str, dict[str, Any]]] = []
    for resource_type, policy in manifest.iter_policies():
        out.append((policy.uid_ref, resource_type, policy.name, _policy_payload(policy)))
    return out


def _live_policy_rows(
    live: Mapping[str, Any] | list[Mapping[str, Any]] | None,
) -> list[dict[str, Any]]:
    if live is None:
        return []
    rows: list[dict[str, Any]] = []
    if isinstance(live, list):
        for row in live:
            if isinstance(row, Mapping):
                rows.append(dict(row))
        return rows
    for resource_type, block, _cls in _POLICY_COLLECTIONS:
        for row in live.get(block) or []:
            if isinstance(row, Mapping):
                payload = dict(row)
                payload.setdefault("resource_type", resource_type)
                rows.append(payload)
    for row in live.get("policies") or []:
        if isinstance(row, Mapping):
            rows.append(dict(row))
    return rows


def _row_resource_type(row: Mapping[str, Any]) -> str:
    raw = row.get("resource_type") or row.get("type") or row.get("policy_type")
    value = str(raw or "")
    return _POLICY_RESOURCE_BY_DISPLAY.get(value, value)


def _normalise_live_payload(row: Mapping[str, Any]) -> dict[str, Any]:
    skip = {"keeper_uid", "marker", "resource_type", "type"}
    return {key: value for key, value in row.items() if key not in skip}


def compute_policy_diff(
    manifest: PolicyManifestV1,
    live: Mapping[str, Any] | list[Mapping[str, Any]] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,
) -> list[Change]:
    """Classify desired policy rows against an optional live policy snapshot."""

    name = manifest_name or manifest.name
    desired = _desired_policy_objects(manifest)
    if live is None:
        return [
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type=resource_type,
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            )
            for uid_ref, resource_type, title, payload in desired
        ]

    live_rows = _live_policy_rows(live)
    by_uid_ref = {
        str(row["uid_ref"]): row for row in live_rows if row.get("uid_ref") not in (None, "")
    }
    by_title = {
        (_row_resource_type(row), str(row.get("name") or row.get("title") or "")): row
        for row in live_rows
    }
    matched: set[int] = set()
    changes: list[Change] = []

    for uid_ref, resource_type, title, payload in desired:
        live_row = by_uid_ref.get(uid_ref) or by_title.get((resource_type, title))
        if live_row is None:
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=uid_ref,
                    resource_type=resource_type,
                    title=title,
                    before={},
                    after=payload,
                    manifest_name=name,
                )
            )
            continue
        matched.add(id(live_row))
        before = _normalise_live_payload(live_row)
        kind = (
            ChangeKind.NOOP
            if _canonical_json(before) == _canonical_json(payload)
            else ChangeKind.UPDATE
        )
        changes.append(
            Change(
                kind=kind,
                uid_ref=uid_ref,
                resource_type=resource_type,
                title=title,
                keeper_uid=str(live_row.get("keeper_uid") or ""),
                before=before,
                after=payload,
                reason="no drift" if kind is ChangeKind.NOOP else None,
                manifest_name=name,
            )
        )

    for row in live_rows:
        if id(row) in matched:
            continue
        resource_type = _row_resource_type(row)
        if resource_type not in _POLICY_BLOCK_BY_RESOURCE:
            continue
        title = str(row.get("name") or row.get("title") or row.get("uid_ref") or resource_type)
        kind = ChangeKind.DELETE if allow_delete else ChangeKind.SKIP
        changes.append(
            Change(
                kind=kind,
                uid_ref=str(row.get("uid_ref") or ""),
                resource_type=resource_type,
                title=title,
                keeper_uid=str(row.get("keeper_uid") or ""),
                before=_normalise_live_payload(row),
                after={},
                reason=None if allow_delete else "delete requires --allow-delete",
                manifest_name=name,
            )
        )

    return changes


_PASSWORD_ENFORCEMENTS = (
    ("min_length", "master_password_minimum_length"),
    ("min_digits", "master_password_minimum_digits"),
    ("min_uppercase", "master_password_minimum_upper"),
    ("min_lowercase", "master_password_minimum_lower"),
    ("min_special", "master_password_minimum_special"),
    ("max_age_days", "master_password_maximum_days_before_change"),
    ("reuse_restrict_days", "master_password_restrict_days_before_reuse"),
    ("expired_as_of_epoch_ms", "master_password_expired_as_of"),
    ("allow_alternate_passwords", "allow_alternate_passwords"),
    ("mask_passwords_while_editing", "mask_passwords_while_editing"),
)
_SHARING_ENFORCEMENTS = (
    ("restrict_all", "restrict_sharing_all"),
    ("restrict_incoming", "restrict_sharing_all_incoming"),
    ("restrict_outgoing", "restrict_sharing_all_outgoing"),
    ("restrict_enterprise", "restrict_sharing_enterprise"),
    ("restrict_enterprise_incoming", "restrict_sharing_enterprise_incoming"),
    ("restrict_enterprise_outgoing", "restrict_sharing_enterprise_outgoing"),
    ("restrict_file_upload", "restrict_file_upload"),
    ("restrict_export", "restrict_export"),
    ("restrict_create_shared_folder", "restrict_create_shared_folder"),
    ("restrict_link_sharing", "restrict_link_sharing"),
    ("restrict_record_share_attachments", "restrict_sharing_record_with_attachments"),
    ("restrict_record_to_shared_folders", "restrict_sharing_record_to_shared_folders"),
    ("restrict_shared_folder_record_removal", "restrict_sf_record_removal"),
    ("restrict_shared_folder_folder_deletion", "restrict_sf_folder_deletion"),
    ("restrict_can_edit_external_shares", "restrict_can_edit_external_shares"),
)
_TWO_FA_ENFORCEMENTS = (
    ("require_two_factor", "require_two_factor"),
    ("duration_web", "two_factor_duration_web"),
    ("duration_mobile", "two_factor_duration_mobile"),
    ("duration_desktop", "two_factor_duration_desktop"),
    ("restrict_text", "restrict_two_factor_channel_text"),
    ("restrict_google", "restrict_two_factor_channel_google"),
    ("restrict_duo", "restrict_two_factor_channel_duo"),
    ("restrict_rsa", "restrict_two_factor_channel_rsa"),
    ("restrict_dna", "restrict_two_factor_channel_dna"),
    ("restrict_security_keys", "restrict_two_factor_channel_security_keys"),
    ("require_security_key_pin", "require_security_key_pin"),
    ("restrict_totp_field", "restrict_totp_field"),
)
_IP_ALLOWLIST_ENFORCEMENTS = (
    ("login_ip_ranges", "restrict_ip_addresses"),
    ("vault_ip_ranges", "restrict_vault_ip_addresses"),
    ("tip_zone_ip_ranges", "tip_zone_restrict_allowed_ip_ranges"),
    ("restrict_ip_autoapproval", "restrict_ip_autoapproval"),
)
_SESSION_TIMEOUT_ENFORCEMENTS = (
    ("max_session_login_minutes", "max_session_login_time"),
    ("logout_timer_web_minutes", "logout_timer_web"),
    ("logout_timer_mobile_minutes", "logout_timer_mobile"),
    ("logout_timer_desktop_minutes", "logout_timer_desktop"),
    ("restrict_persistent_login", "restrict_persistent_login"),
    ("stay_logged_in_default", "stay_logged_in_default"),
    ("restrict_offline_access", "restrict_offline_access"),
)
_ENFORCEMENT_FIELDS_BY_RESOURCE = {
    PASSWORD_POLICY: _PASSWORD_ENFORCEMENTS,
    SHARING_POLICY: _SHARING_ENFORCEMENTS,
    TWO_FA_POLICY: _TWO_FA_ENFORCEMENTS,
    IP_ALLOWLIST_POLICY: _IP_ALLOWLIST_ENFORCEMENTS,
    SESSION_TIMEOUT_POLICY: _SESSION_TIMEOUT_ENFORCEMENTS,
}


def policy_is_commander_supported(resource_type: str) -> bool:
    return resource_type in COMMANDER_WIRED_POLICY_TYPES


def policy_upstream_gap_reason(resource_type: str, title: str) -> str | None:
    if resource_type != AUDIT_POLICY:
        return None
    return (
        f"{AUDIT_POLICY_NAME} {title!r} is upstream-gap on Commander 18.0.0 "
        "(no `keeper enforcement` / `keeper role-enforcements` writer for audit "
        "retention, export, or report-recipient policy)"
    )


def policy_upstream_gap_reasons(manifest: PolicyManifestV1) -> list[str]:
    hits: list[str] = []
    for resource_type, policy in manifest.iter_policies():
        reason = policy_upstream_gap_reason(resource_type, policy.name)
        if reason:
            hits.append(reason)
    return hits


def _format_enforcement_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (list, tuple)):
        return ",".join(str(item) for item in value)
    return str(value)


def commander_enforcement_flags_for_policy(
    resource_type: str,
    payload: Mapping[str, Any],
    *,
    remove: bool = False,
) -> list[str]:
    """Return ``enterprise-role --enforcement`` values for one policy payload."""

    fields_for_type = _ENFORCEMENT_FIELDS_BY_RESOURCE.get(resource_type)
    if fields_for_type is None:
        return []
    flags: list[str] = []
    for field_name, enforcement_key in fields_for_type:
        if remove:
            flags.append(f"{enforcement_key}:")
            continue
        if field_name not in payload or payload[field_name] is None:
            continue
        flags.append(f"{enforcement_key}:{_format_enforcement_value(payload[field_name])}")
    return flags


def policy_role_identifier(payload: Mapping[str, Any]) -> str:
    raw = payload.get("role_id") or payload.get("role_name") or payload.get("role_uid_ref")
    value = str(raw or "").strip()
    for prefix in ("keeper-enterprise:roles:", "enterprise:roles:"):
        if value.startswith(prefix):
            return value[len(prefix) :]
    return value


__all__ = [
    "AUDIT_POLICY",
    "AUDIT_POLICY_NAME",
    "COMMANDER_WIRED_POLICY_TYPES",
    "IP_ALLOWLIST_POLICY",
    "IP_ALLOWLIST_POLICY_NAME",
    "KEEPER_POLICY_FAMILY",
    "PASSWORD_POLICY",
    "PASSWORD_POLICY_NAME",
    "POLICY_FAMILY",
    "SESSION_TIMEOUT_POLICY",
    "SESSION_TIMEOUT_POLICY_NAME",
    "SHARING_POLICY",
    "SHARING_POLICY_NAME",
    "TWO_FA_POLICY",
    "TWO_FA_POLICY_NAME",
    "UPSTREAM_GAP_POLICY_TYPES",
    "AuditPolicy",
    "IpAllowlistPolicy",
    "PasswordPolicy",
    "PolicyManifestV1",
    "PolicyRow",
    "SessionTimeoutPolicy",
    "SharingPolicy",
    "TwoFactorPolicy",
    "commander_enforcement_flags_for_policy",
    "compute_policy_diff",
    "load_policy_manifest",
    "policy_apply_order",
    "policy_is_commander_supported",
    "policy_manifest_from_dict",
    "policy_role_identifier",
    "policy_upstream_gap_reason",
    "policy_upstream_gap_reasons",
]
