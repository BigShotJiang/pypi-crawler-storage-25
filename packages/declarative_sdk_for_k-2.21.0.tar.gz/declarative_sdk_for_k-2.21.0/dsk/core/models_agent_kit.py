"""Keeper Security Agent Kit (SAK) manifest models — keeper-agent-kit.v1."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class SakSkill(StrEnum):
    secrets = "keeper-secrets"  # KSM integration
    admin = "keeper-admin"  # Commander integration
    setup = "keeper-setup"  # Install/config


class SakAgent(StrEnum):
    claude_code = "claude-code"
    cursor = "cursor"
    codex = "codex"
    copilot = "github-copilot"
    vscode = "vscode-copilot"
    generic = "generic"


class SakKsmBinding(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    ksm_app_uid_ref: str = Field(..., description="KSM application UID ref")
    allowed_secret_refs: list[str] = Field(
        default_factory=list,
        description="Allowed KSM record UID refs (empty = all in app)",
    )


class SakCommanderBinding(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    config_uid_ref: str | None = Field(None, description="Commander config record UID ref")
    allowed_commands: list[str] = Field(
        default_factory=list,
        description="Allowed Commander commands (empty = all)",
    )


class SakPolicy(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    uid_ref: str
    enabled_skills: list[SakSkill] = Field(
        default_factory=list,
        description="Which SAK skills to enable",
    )
    enabled_agents: list[SakAgent] = Field(
        default_factory=list,
        description="Which AI agents can use this kit",
    )
    ksm_binding: SakKsmBinding | None = None
    commander_binding: SakCommanderBinding | None = None
    audit_log_enabled: bool = True
    session_timeout_minutes: int = Field(60, ge=1, le=480)


class AgentKitManifestV1(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, populate_by_name=True)

    schema_: str = Field("keeper-agent-kit.v1", alias="schema")
    name: str
    manager: str = "dsk"
    policies: list[SakPolicy] = Field(default_factory=list)
