"""Desired-vs-live diff for ``workflow-gate.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_workflow_gate import WorkflowGateManifestV1


def compute_workflow_gate_diff(
    manifest: WorkflowGateManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared Keeper workflow gate."""
    if live:
        raise NotImplementedError(
            "workflow-gate.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or "workflow-gate"
    changes: list[Change] = []

    for idx, workflow in enumerate(manifest.workflows):
        payload = workflow.model_dump(mode="python", exclude_none=True)
        uid_ref = str(getattr(workflow, "uid_ref", None) or f"{name}.workflows.{idx}")
        title = str(getattr(workflow, "name", None) or uid_ref)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="workflow_gate",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_workflow_gate_diff"]
