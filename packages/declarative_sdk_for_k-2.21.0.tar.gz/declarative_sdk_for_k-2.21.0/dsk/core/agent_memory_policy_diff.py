"""Desired-vs-live diff for ``agent-memory-policy.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_agent_memory_policy import AgentMemoryPolicyManifest


def compute_agent_memory_policy_diff(
    manifest: AgentMemoryPolicyManifest,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for memory policy entries (offline demo path)."""
    if live:
        raise NotImplementedError(
            "agent-memory-policy.v1 live readback is not implemented — pass live=None",
        )

    name = manifest_name or "agent-memory-policy"
    changes: list[Change] = []

    for policy in manifest.policies:
        payload = policy.model_dump(mode="python", exclude_none=True)
        uid_ref = str(policy.uid_ref)
        title = str(policy.name)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="agent_memory_policy",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_agent_memory_policy_diff"]
