"""Secret scanner bridge models — secret-scanner-bridge.v1.

Bridges GitHub Advanced Security secret-scanning alerts to Keeper PAM rotation.
Trigger: GitHub secret scanning API 2026-03-10 + Cloudflare GHAS partner Apr 14 2026.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class SecretScannerSource(StrEnum):
    github = "github"  # GitHub Advanced Security
    gitlab = "gitlab"  # GitLab Ultimate secret detection
    gitleaks = "gitleaks"  # open-source scanner


class RotationSeverity(StrEnum):
    critical = "critical"  # rotate immediately, page on-call
    high = "high"  # rotate within 1 hour
    medium = "medium"  # rotate within 24 hours
    low = "low"  # rotate at next scheduled window


class AlertPatternMapping(BaseModel):
    """Map a scanner secret type to a Keeper rotation target."""

    secret_type: str = Field(
        ...,
        description="Scanner-native secret type, e.g. 'aws_access_key_id', 'cloudflare_api_token'",
    )
    keeper_uid_ref: str = Field(..., description="DSK uid_ref of the credential record to rotate")
    rotation_policy_ref: str | None = Field(
        None, description="DSK uid_ref of a rotation-policy.v1 manifest to apply"
    )
    severity: RotationSeverity = RotationSeverity.critical
    auto_rotate: bool = Field(
        True, description="Trigger rotation automatically on alert (vs. create ticket only)"
    )
    notify_slack_channel: str | None = None


class WebhookConfig(BaseModel):
    path: str = Field("/webhook/secret-scanner", description="HTTP path for the webhook receiver")
    hmac_secret_env: str = Field(
        "SECRET_SCANNER_WEBHOOK_SECRET",
        description="Env var holding HMAC secret for webhook verification",
    )
    port: int = Field(8443, ge=1024, le=65535)


class SecretScannerBridgeManifestV1(BaseModel):
    """Root model for a secret-scanner-bridge.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("secret-scanner-bridge.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    source: SecretScannerSource = SecretScannerSource.github
    repos: list[str] = Field(
        default_factory=list, description="GitHub org/repo slugs to watch, e.g. ['acme/backend']"
    )
    mappings: list[AlertPatternMapping] = Field(default_factory=list)
    webhook: WebhookConfig = Field(default_factory=lambda: WebhookConfig())  # type: ignore[call-arg]
    dry_run_mode: bool = Field(
        False, description="Log alerts without triggering rotation (testing)"
    )
