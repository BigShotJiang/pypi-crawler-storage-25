"""EU AI Act compliance profile models — ai-act-profile.v1.

Binds DSK AI governance families to EU AI Act Annex III obligations.
Enforcement deadline: August 2, 2026.
Articles: 9 (risk management), 12 (automatic logging), 14 (human oversight).
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class AiActRiskTier(StrEnum):
    """EU AI Act risk classification tiers."""

    unacceptable = "unacceptable"  # Art. 5 — prohibited systems
    high_risk = "high_risk"  # Annex III — subject to full obligations
    limited_risk = "limited_risk"  # Art. 50 — transparency obligations only
    minimal_risk = "minimal_risk"  # No obligations


class AiActAnnexIiiCategory(StrEnum):
    """Annex III high-risk AI system categories relevant to PAM."""

    biometric_id = "biometric_identification"
    critical_infrastructure = "critical_infrastructure"
    education = "education_training"
    employment = "employment_hr"
    essential_services = "essential_services"
    law_enforcement = "law_enforcement"
    migration = "migration_asylum"
    justice = "justice_democracy"


class AiActArticleStatus(StrEnum):
    compliant = "compliant"
    partially_compliant = "partially_compliant"
    gap = "gap"
    not_applicable = "not_applicable"


class AiActLoggingRequirement(BaseModel):
    """Article 12 automatic logging configuration."""

    uid_ref: str = Field(
        ...,
        description="DSK uid_ref of the AI system or mcp-secrets-binding record",
    )
    retain_days: int = Field(
        365,
        ge=30,
        le=3650,
        description="Minimum log retention per Art. 12(1)",
    )
    log_inputs: bool = True
    log_outputs: bool = True
    log_credential_access: bool = True
    log_human_overrides: bool = True


class AiActOversightGate(BaseModel):
    """Article 14 human oversight gate declaration."""

    name: str
    ai_system_uid_ref: str
    approval_gate_ref: str | None = Field(
        None,
        description="uid_ref of a slack-approval-gate.v1 or itsm-approval-gate.v1 manifest",
    )
    override_allowed: bool = Field(
        True,
        description="Human operators can override AI decisions",
    )
    stop_button: bool = Field(
        True,
        description="Humans can interrupt or stop AI system operations",
    )


class AiActControlMapping(BaseModel):
    article: str = Field(
        ...,
        description="EU AI Act article, e.g. 'art-9', 'art-12', 'art-14'",
    )
    obligation: str
    status: AiActArticleStatus
    dsk_families_used: list[str] = Field(
        default_factory=list,
        description="DSK manifest families satisfying this obligation, e.g. 'ai-token.v1'",
    )
    remediation_note: str | None = Field(
        None,
        description="Required when status=gap or partially_compliant",
    )


class AiActProfileManifestV1(BaseModel):
    """Root model for an ai-act-profile.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("ai-act-profile.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    risk_tier: AiActRiskTier = AiActRiskTier.high_risk
    annex_iii_category: AiActAnnexIiiCategory | None = None
    enforcement_deadline: str = "2026-08-02"
    logging_requirements: list[AiActLoggingRequirement] = Field(default_factory=list)
    oversight_gates: list[AiActOversightGate] = Field(default_factory=list)
    controls: list[AiActControlMapping] = Field(default_factory=list)
    evidence_output_dir: str = "ai-act-evidence/"
