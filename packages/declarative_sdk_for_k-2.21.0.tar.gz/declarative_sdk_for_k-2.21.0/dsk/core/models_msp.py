"""MSP ownership marker helpers.

The main ``msp-environment.v1`` manifest model lives in
``dsk.core.msp_models``.  This module carries the marker shape used by
providers that can store managed-company ownership metadata.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

MSP_MARKER_RESOURCE_TYPE: Literal["managed_company"] = "managed_company"


class ManagedCompanyMarker(BaseModel):
    """Ownership marker for one managed company."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    manager: str = Field(min_length=1)
    uid_ref: str = Field(min_length=1)
    manifest: str = Field(min_length=1)
    resource_type: Literal["managed_company"] = MSP_MARKER_RESOURCE_TYPE


def managed_company_marker(
    *,
    manager: str,
    uid_ref: str,
    manifest: str,
) -> dict[str, str]:
    """Return a serialisable managed-company marker."""

    marker = ManagedCompanyMarker(
        manager=manager,
        uid_ref=uid_ref,
        manifest=manifest,
    )
    return marker.model_dump(mode="python")


__all__ = [
    "MSP_MARKER_RESOURCE_TYPE",
    "ManagedCompanyMarker",
    "managed_company_marker",
]
