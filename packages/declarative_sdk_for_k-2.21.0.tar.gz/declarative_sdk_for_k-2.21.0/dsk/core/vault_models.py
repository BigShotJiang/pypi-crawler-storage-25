"""Typed models for ``keeper-vault.v1`` manifests (PAM parity program PR-V1).

Slice 1 per ``docs/VAULT_L1_DESIGN.md``: ``records[]`` are typed rows; today L1
accepts ``login`` plus lightweight ``file`` placeholders for planner smoke tests.
Graph over ``uid_ref`` / ``folder_ref`` lives in :mod:`dsk.core.vault_graph`.

Load via :func:`~dsk.core.manifest.load_declarative_manifest` (or
:func:`load_vault_manifest` after :func:`~dsk.core.schema.validate_manifest`).
:func:`~dsk.core.manifest.load_manifest` is **PAM-only** and refuses this family.
CLI + providers ship in ``dsk/cli`` and ``dsk.providers`` — see
``docs/VAULT_L1_DESIGN.md`` §8.
"""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import SchemaError
from dsk.core.record_type_aliases import RECORD_TYPE_ALIASES as _VAULT_RECORD_TYPE_ALIASES

VAULT_FAMILY: Literal["keeper-vault.v1"] = "keeper-vault.v1"

VAULT_L2_TYPED_RECORD_TYPES = frozenset(
    {
        "bankAccount",
        "address",
        "paymentCard",
        "contact",
        "ssnCard",
        "healthInsurance",
        "photo",
        "file",
        "generalNote",
        # Phase 4-E: native Keeper v3 credential record types
        "sshKeys",
        "databaseCredentials",
        "serverCredentials",
        "softwareLicense",
        "passport",
        "driverLicense",
        "membership",
    }
)
VAULT_SUPPORTED_RECORD_TYPES = frozenset({"login"}) | VAULT_L2_TYPED_RECORD_TYPES

# PAM record types belong in PAM manifests, not vault manifests. Explicitly
# blocked even under the open custom-type policy so operators get a clear error.
_VAULT_PAM_BLOCKED_RECORD_TYPES: frozenset[str] = frozenset(
    {
        "pamUser",
        "pamMachine",
        "pamDatabase",
        "pamDirectory",
        "pamRemoteBrowser",
        "pamNetworkConfiguration",
    }
)
_VAULT_PAM_CANONICAL_BY_LOWER: dict[str, str] = {
    t.lower(): t for t in _VAULT_PAM_BLOCKED_RECORD_TYPES
}

_VAULT_COMMANDER_RECORD_TYPE_ALIASES = {
    "paymentCard": "bankCard",
    "generalNote": "encryptedNotes",
}
_VAULT_FIELD_TYPE_ALIASES = {
    "file_ref": "fileRef",
    "secret_question": "securityQuestion",
}
_VAULT_L2_ALLOWED_FIELD_TYPES = {
    "bankAccount": frozenset(
        {"bankAccount", "name", "login", "password", "url", "fileRef", "secret", "text"}
    ),
    "address": frozenset({"address", "fileRef"}),
    "paymentCard": frozenset({"paymentCard", "text", "pinCode", "address", "fileRef"}),
    "contact": frozenset({"name", "text", "email", "phone", "address", "fileRef"}),
    "ssnCard": frozenset({"secret", "name", "fileRef", "text"}),
    "healthInsurance": frozenset(
        {"secret", "name", "login", "password", "url", "fileRef", "securityQuestion", "text"}
    ),
    "photo": frozenset({"fileRef"}),
    "file": frozenset({"fileRef"}),
    "generalNote": frozenset({"multiline", "text", "fileRef"}),
    # Phase 4-E: Keeper standard templates (keeperCMD validate.py _STD_RECORD_TYPE_ID_TO_NAME)
    # sshKeys: SSH key pair with optional host/login/password context
    "sshKeys": frozenset({"keyPair", "host", "login", "password", "text"}),
    # databaseCredentials: database host + auth
    "databaseCredentials": frozenset({"host", "login", "password", "text"}),
    # serverCredentials: server host + auth + url
    "serverCredentials": frozenset({"host", "login", "password", "url", "text"}),
    # softwareLicense: license key + expiration + free-form notes (Keeper stock template)
    "softwareLicense": frozenset({"secret", "text", "multiline", "date"}),
    # passport: identity document fields (Keeper stock includes date, address, phone)
    "passport": frozenset({"name", "text", "secret", "date", "address", "phone"}),
    # driverLicense: identity document fields (Keeper stock includes date, address, phone)
    "driverLicense": frozenset({"name", "text", "secret", "date", "address", "phone"}),
    # membership: membership/loyalty card fields
    "membership": frozenset({"name", "text", "secret"}),
}


def normalize_vault_record_type(record_type: Any) -> str:
    """Return the manifest-facing Keeper vault record type name."""
    raw = str(record_type or "").strip()
    return _VAULT_RECORD_TYPE_ALIASES.get(raw, raw)


def get_allowed_field_types(record_type: str) -> frozenset[str] | None:
    """Return allowed field types for a record type, or None for custom types (open).

    Returns ``None`` when the type is custom/unknown — callers should allow any
    field type rather than raising a validation error.
    """
    return _VAULT_L2_ALLOWED_FIELD_TYPES.get(record_type)


def commander_vault_record_type(record_type: Any) -> str:
    """Return the Commander v3 record-type name for a manifest record type."""
    normalized = normalize_vault_record_type(record_type)
    return _VAULT_COMMANDER_RECORD_TYPE_ALIASES.get(normalized, normalized)


def normalize_vault_field_type(field_type: Any) -> str:
    """Return the canonical Keeper typed-field name used for profile checks."""
    raw = str(field_type or "").strip()
    return _VAULT_FIELD_TYPE_ALIASES.get(raw, raw)


class _VaultModel(BaseModel):
    """Permissive leaf blocks so schema growth does not break reads."""

    model_config = ConfigDict(extra="allow", populate_by_name=True, str_strip_whitespace=True)


class _StrictVaultModel(BaseModel):
    """Strict typed leaf blocks for manifest-owned Keeper field values."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True, str_strip_whitespace=True)


VaultJsonScalar: TypeAlias = str | int | float | bool | None
VaultCustomValue: TypeAlias = (
    VaultJsonScalar
    | list[VaultJsonScalar]
    | dict[str, VaultJsonScalar]
    | list[dict[str, VaultJsonScalar]]
)


class VaultSecurityQuestionValue(_StrictVaultModel):
    question: str
    answer: str | None = None


class VaultNameValue(_StrictVaultModel):
    first: str | None = None
    middle: str | None = None
    last: str | None = None


class VaultAddressValue(_StrictVaultModel):
    street1: str | None = None
    street2: str | None = None
    city: str | None = None
    state: str | None = None
    zip: str | None = None
    country: str | None = None


class VaultPhoneValue(_StrictVaultModel):
    region: str | None = None
    number: str | None = None
    ext: str | None = None
    type: str | None = None


class VaultPaymentCardValue(_StrictVaultModel):
    cardNumber: str | None = None
    cardExpirationDate: str | None = None
    cardSecurityCode: str | None = None


class VaultBankAccountValue(_StrictVaultModel):
    accountType: str | None = None
    routingNumber: str | None = None
    accountNumber: str | None = None
    otherType: str | None = None


class VaultKeyPairValue(_StrictVaultModel):
    publicKey: str | None = None
    privateKey: str | None = None


class VaultHostValue(_StrictVaultModel):
    hostName: str | None = None
    port: int | str | None = None


class VaultFileRefValue(_StrictVaultModel):
    uid_ref: str | None = None
    keeper_uid: str | None = None
    name: str | None = None
    title: str | None = None
    mime_type: str | None = None
    size: int | None = None
    content_sha256: str | None = None


VaultFieldValue: TypeAlias = (
    VaultJsonScalar
    | VaultSecurityQuestionValue
    | VaultNameValue
    | VaultAddressValue
    | VaultPhoneValue
    | VaultPaymentCardValue
    | VaultBankAccountValue
    | VaultKeyPairValue
    | VaultHostValue
    | VaultFileRefValue
)


class VaultTypedField(_StrictVaultModel):
    """Manifest-owned Keeper typed field entry.

    ``fields`` and ``custom`` still store plain dictionaries on ``VaultRecord``
    for backwards compatibility, but both lists validate through this model.
    """

    type: Literal[
        "login",
        "password",
        "url",
        "email",
        "phone",
        "address",
        "secret_question",
        "securityQuestion",
        "multiline",
        "text",
        "secret",
        "pinCode",
        "name",
        "paymentCard",
        "bankAccount",
        "keyPair",
        "host",
        "file_ref",
        "fileRef",
    ]
    value: list[VaultFieldValue]
    label: str | None = None


class VaultCustomKeyValue(_StrictVaultModel):
    """Free-form custom key/value row accepted in ``records[].custom[]``."""

    key: str
    value: VaultCustomValue


def _validate_typed_fields(fields: list[dict[str, Any]], *, allow_custom_kv: bool) -> None:
    for field in fields:
        try:
            VaultTypedField.model_validate(field)
            continue
        except ValidationError:
            if not allow_custom_kv:
                raise
        VaultCustomKeyValue.model_validate(field)


class VaultRecord(_VaultModel):
    """One ``records[]`` entry (see ``keeper-vault.v1`` schema ``$defs.record``)."""

    uid_ref: str
    type: str
    title: str
    folder_ref: str | None = None
    notes: str | None = None
    fields: list[dict[str, Any]] = Field(default_factory=list)
    custom: list[dict[str, Any]] = Field(default_factory=list)
    keeper_uid: str | None = None

    @field_validator("type", mode="before")
    @classmethod
    def _normalize_type(cls, record_type: Any) -> str:
        return normalize_vault_record_type(record_type)

    @field_validator("fields")
    @classmethod
    def _validate_fields(cls, fields: list[dict[str, Any]]) -> list[dict[str, Any]]:
        _validate_typed_fields(fields, allow_custom_kv=False)
        return fields

    @field_validator("custom")
    @classmethod
    def _validate_custom(cls, custom: list[dict[str, Any]]) -> list[dict[str, Any]]:
        _validate_typed_fields(custom, allow_custom_kv=True)
        return custom

    @model_validator(mode="after")
    def _validate_l2_field_profile(self) -> VaultRecord:
        allowed = _VAULT_L2_ALLOWED_FIELD_TYPES.get(self.type)
        if allowed is None or not self.fields:
            return self
        field_types = [
            normalize_vault_field_type(field.get("type"))
            for field in self.fields
            if isinstance(field, dict)
        ]
        bad = sorted({field_type for field_type in field_types if field_type not in allowed})
        if bad:
            allowed_text = ", ".join(sorted(allowed))
            raise ValueError(
                f"keeper-vault L2 record type {self.type!r} does not allow "
                f"fields[] type(s): {bad}; allowed fields: {allowed_text}"
            )
        return self


class VaultSharedFolder(_VaultModel):
    """Offline model for a future Commander shared-folder write surface."""

    title: str
    uid_ref: str
    manager: str
    members: list[dict[str, Any]] = Field(default_factory=list)
    permissions: dict[str, bool] = Field(
        default_factory=lambda: {"manage_records": False, "manage_users": False}
    )

    @field_validator("members")
    @classmethod
    def _validate_members(cls, members: list[dict[str, Any]]) -> list[dict[str, Any]]:
        allowed_roles = {"read", "edit", "manage"}
        out: list[dict[str, Any]] = []
        for member in members:
            if not isinstance(member, dict):
                raise ValueError("shared-folder member must be an object")
            email = member.get("email")
            role = member.get("role")
            if not isinstance(email, str) or not email:
                raise ValueError("shared-folder member requires email")
            if role not in allowed_roles:
                raise ValueError("shared-folder member role must be read, edit, or manage")
            out.append({"email": email, "role": role})
        return out

    @field_validator("permissions")
    @classmethod
    def _validate_permissions(cls, permissions: dict[str, bool]) -> dict[str, bool]:
        required = {"manage_records", "manage_users"}
        missing = required - set(permissions)
        if missing:
            raise ValueError("shared-folder permissions require manage_records and manage_users")
        out: dict[str, bool] = {}
        for key, value in permissions.items():
            if key not in required:
                raise ValueError(
                    "shared-folder permissions only support manage_records and manage_users"
                )
            if not isinstance(value, bool):
                raise ValueError("shared-folder permission flags must be booleans")
            out[key] = value
        return out


class VaultManifestV1(_VaultModel):
    """Top-level ``keeper-vault.v1`` manifest (slice 1).

    JSON key remains ``schema`` (alias). Python attribute is ``vault_schema`` so
    we do not shadow :meth:`pydantic.BaseModel.schema`.
    """

    vault_schema: Literal["keeper-vault.v1"] = Field(default=VAULT_FAMILY, alias="schema")
    records: list[VaultRecord] = Field(default_factory=list)
    shared_folders: list[VaultSharedFolder] = Field(default_factory=list)
    record_types: list[dict[str, Any]] = Field(default_factory=list)
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    keeper_fill: dict[str, Any] | None = None

    @model_validator(mode="after")
    def _l1_login_slice(self) -> VaultManifestV1:
        """``docs/VAULT_L1_DESIGN.md`` §1 plus L2 typed-record allow-list.

        Known PAM types are explicitly rejected (use PAM manifests instead).
        Custom/admin-defined types (not in ``VAULT_SUPPORTED_RECORD_TYPES`` and
        not a PAM type) pass through with an open field profile.
        """
        from dsk.core.errors import SchemaError  # noqa: PLC0415

        for record in self.records:
            if record.type.strip().lower() in _VAULT_PAM_CANONICAL_BY_LOWER:
                raise SchemaError(
                    f"record type '{record.type}' is a PAM type and cannot appear "
                    "in a keeper-vault.v1 manifest — use a PAM manifest instead",
                )
        return self

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        """Return ``(uid_ref, record_type)`` for each record (graph prelude)."""
        return [(r.uid_ref, r.type) for r in self.records]


def _shared_folder_diff_payload(folder: VaultSharedFolder) -> dict[str, Any]:
    payload = folder.model_dump(mode="python")
    payload["members"] = sorted(
        payload["members"],
        key=lambda member: str(member.get("email") or "").casefold(),
    )
    return payload


def diff_shared_folder(before: VaultSharedFolder, after: VaultSharedFolder) -> Change:
    """Diff two shared-folder models as one offline planner row."""
    before_payload = _shared_folder_diff_payload(before)
    after_payload = _shared_folder_diff_payload(after)
    diff_fields = [
        key
        for key in ("title", "manager", "members", "permissions")
        if before_payload.get(key) != after_payload.get(key)
    ]
    if not diff_fields:
        return Change(
            kind=ChangeKind.NOOP,
            uid_ref=after.uid_ref,
            resource_type="shared_folder",
            title=after.title,
        )
    return Change(
        kind=ChangeKind.UPDATE,
        uid_ref=after.uid_ref,
        resource_type="shared_folder",
        title=after.title,
        before={key: before_payload.get(key) for key in diff_fields},
        after={key: after_payload.get(key) for key in diff_fields},
    )


SharedFolder = VaultSharedFolder


def diff_shared_folders(before: VaultSharedFolder, after: VaultSharedFolder) -> list[Change]:
    """List-shaped wrapper for callers expecting planner rows."""
    return [diff_shared_folder(before, after)]


def load_vault_manifest(document: dict[str, Any]) -> VaultManifestV1:
    """Validate with JSON Schema + semantic rules, then parse as :class:`VaultManifestV1`.

    Raises :class:`SchemaError` if the document is not ``keeper-vault.v1`` or
    fails validation / L1 slice rules.
    """
    from dsk.core.schema import PAM_FAMILY, validate_manifest

    family = validate_manifest(document)
    if family == PAM_FAMILY:
        raise SchemaError(
            reason="document is a pam-environment manifest, not keeper-vault.v1",
            next_action="use load_manifest() for PAM or fix top-level schema:",
        )
    if family != VAULT_FAMILY:
        raise SchemaError(
            reason=f"expected {VAULT_FAMILY!r}, got {family!r}",
            next_action="set schema: keeper-vault.v1 on the manifest",
        )
    try:
        return VaultManifestV1.model_validate(document)
    except ValueError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix records to match L1 rules in docs/VAULT_L1_DESIGN.md",
        ) from exc
