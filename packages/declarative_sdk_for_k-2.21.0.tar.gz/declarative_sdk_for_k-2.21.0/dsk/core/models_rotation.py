"""Declarative rotation policy models — rotation-policy.v1."""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class RotationScheduleType(StrEnum):
    cron = "cron"  # cron expression
    interval = "interval"  # fixed interval in hours
    on_use = "on_use"  # rotate after each use (highest security)
    manual = "manual"  # no automatic rotation
    configuration = "configuration"  # use or override PAM configuration schedule


class RotationNotifyMode(StrEnum):
    none_ = "none"
    slack = "slack"
    email = "email"
    servicenow = "servicenow"


class RotationSchedule(BaseModel):
    type: RotationScheduleType = RotationScheduleType.interval
    cron: str | None = Field(
        None,
        description="Cron expression (required when type=cron)",
    )
    schedule_config: dict[str, Any] | None = Field(
        None,
        description="Commander --schedulejson object for configuration-backed schedules",
    )
    interval_hours: int | None = Field(
        None,
        ge=1,
        description="Rotation interval in hours (required when type=interval)",
    )
    window_start: str | None = Field(
        None,
        description="Maintenance window start time (HH:MM UTC) for interval rotation",
    )
    window_end: str | None = Field(
        None,
        description="Maintenance window end time (HH:MM UTC)",
    )


class RotationPasswordPolicy(BaseModel):
    min_length: int = Field(20, ge=12)
    max_length: int = Field(64, le=256)
    require_uppercase: bool = True
    require_lowercase: bool = True
    require_digits: bool = True
    require_special: bool = True
    excluded_special: str = Field(
        "'\"\\`",
        description="Special chars to exclude from generated passwords",
    )
    complexity_regex: str | None = Field(
        None,
        description="Additional regex the generated password must match",
    )


class RotationNotification(BaseModel):
    mode: RotationNotifyMode = RotationNotifyMode.none_
    target: str | None = Field(
        None,
        description="Slack webhook URL, email address, or ServiceNow instance",
    )
    on_success: bool = Field(False)
    on_failure: bool = Field(True)


class RotationPolicy(BaseModel):
    name: str
    description: str | None = None
    applies_to: list[str] = Field(
        default_factory=list,
        description="List of DSK uid_refs this policy applies to",
    )
    schedule: RotationSchedule = Field(default_factory=lambda: RotationSchedule())  # type: ignore[call-arg]
    password: RotationPasswordPolicy = Field(default_factory=lambda: RotationPasswordPolicy())  # type: ignore[call-arg]
    notification: RotationNotification = Field(default_factory=lambda: RotationNotification())  # type: ignore[call-arg]
    rotation_profile: str | None = Field(
        None,
        pattern=r"^(general|iam_user|scripts_only)$",
        description="Commander pam rotation edit --rotation-profile value",
    )
    config_uid_ref: str | None = Field(
        None,
        description="PAM configuration UID/ref for Commander pam rotation edit --config",
    )
    resource_uid_ref: str | None = Field(
        None,
        description="PAM resource UID/ref for Commander pam rotation edit --resource",
    )
    password_complexity: str | None = Field(
        None,
        pattern=r"^\d+,\d+,\d+,\d+,\d+(?:,[^,]*)?$",
        description="Commander --complexity string: length,caps,lowercase,digits,special[,excluded]",
    )
    pause_on_failure: bool = Field(
        True,
        description="Pause rotation schedule if a rotation fails",
    )
    max_consecutive_failures: int = Field(3, ge=1)


class RotationPolicyManifestV1(BaseModel):
    """Root model for a rotation-policy.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("rotation-policy.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    policies: list[RotationPolicy] = Field(default_factory=list)
