"""Desired-vs-live diff for ``db-access-policy.v1`` (offline)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_db_access import DbAccessPolicyManifestV1


def compute_db_access_diff(
    manifest: DbAccessPolicyManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared database access rule."""
    if live:
        raise NotImplementedError(
            "db-access-policy.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    for idx, rule in enumerate(manifest.rules):
        payload = rule.model_dump(mode="python", exclude_none=True)
        uid_ref_value = getattr(rule, "uid_ref", None)
        uid_ref = str(uid_ref_value) if uid_ref_value is not None else f"{name}.rules.{idx}"
        title_value = getattr(rule, "name", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="db_access_rule",
                title=str(title_value) if title_value is not None else uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_db_access_diff"]
