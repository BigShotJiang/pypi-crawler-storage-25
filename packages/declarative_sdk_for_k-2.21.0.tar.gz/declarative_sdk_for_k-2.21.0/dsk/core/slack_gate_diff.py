"""Desired-vs-live diff for ``slack-approval-gate.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_slack_gate import SlackApprovalGateManifestV1


def compute_slack_gate_diff(
    manifest: SlackApprovalGateManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared Slack approval gate."""
    if live:
        raise NotImplementedError(
            "slack-approval-gate.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or "slack-approval-gate"
    changes: list[Change] = []

    for idx, gate in enumerate(manifest.gates):
        payload = gate.model_dump(mode="python", exclude_none=True)
        uid_ref = str(getattr(gate, "uid_ref", None) or f"{name}.gates.{idx}")
        title = str(getattr(gate, "name", None) or uid_ref)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="slack_gate",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_slack_gate_diff"]
