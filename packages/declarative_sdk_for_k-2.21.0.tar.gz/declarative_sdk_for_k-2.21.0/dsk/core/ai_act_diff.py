"""Desired-vs-live diff for ``ai-act-profile.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_ai_act import AiActProfileManifestV1


def compute_ai_act_diff(
    manifest: AiActProfileManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared AI Act profile resource."""
    if live:
        raise NotImplementedError("ai-act-profile.v1 live readback not implemented")

    name = manifest_name or "ai-act-profile.v1"
    changes: list[Change] = []

    for idx, requirement in enumerate(manifest.logging_requirements):
        payload = requirement.model_dump(mode="python", exclude_none=True)
        uid_ref = getattr(requirement, "uid_ref", None) or f"{name}.{idx}"
        article = getattr(requirement, "article", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=str(uid_ref),
                resource_type="ai_act_logging_req",
                title=str(article) if article else str(uid_ref),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for idx, gate in enumerate(manifest.oversight_gates):
        payload = gate.model_dump(mode="python", exclude_none=True)
        uid_ref = getattr(gate, "uid_ref", None) or f"{name}.{idx}"
        article = getattr(gate, "article", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=str(uid_ref),
                resource_type="ai_act_oversight_gate",
                title=str(article) if article else str(uid_ref),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for idx, control in enumerate(manifest.controls):
        payload = control.model_dump(mode="python", exclude_none=True)
        uid_ref = getattr(control, "uid_ref", None) or f"{name}.{idx}"
        article = getattr(control, "article", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=str(uid_ref),
                resource_type="ai_act_control",
                title=str(article) if article else str(uid_ref),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_ai_act_diff"]
