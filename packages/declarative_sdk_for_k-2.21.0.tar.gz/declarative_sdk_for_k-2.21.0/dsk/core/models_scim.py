"""
SCIM provisioning models for DSK — keeper-scim.v1 family.

Addresses customer pain point: SCIM provisioning delays and
async team/user assignment complexity.

Declarative SCIM: define teams, users, role assignments in YAML.
DSK applies via Commander enterprise-push or direct SCIM API calls.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ScimUser(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    uid_ref: str
    email: str
    display_name: str | None = None
    role_uid_refs: list[str] = Field(default_factory=list)
    team_uid_refs: list[str] = Field(default_factory=list)
    node_uid_ref: str | None = None


class ScimTeam(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    uid_ref: str
    name: str
    node_uid_ref: str | None = None
    member_uid_refs: list[str] = Field(default_factory=list)
    restrict_edit: bool = False
    restrict_share: bool = False
    restrict_view: bool = False


class ScimRole(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    uid_ref: str
    name: str
    node_uid_ref: str | None = None
    enforce_2fa: bool = False
    restrict_vault_ip: bool = False
    disable_offline_mode: bool = False


class ScimNode(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    uid_ref: str
    name: str
    parent_uid_ref: str | None = None


class ScimEndpointSpec(BaseModel):
    """SCIM endpoint push target (maps to Commander ``scim push``)."""

    model_config = ConfigDict(str_strip_whitespace=True)

    node_id: str = Field(
        ...,
        description="SCIM node id or resolvable node name (see ``scim list`` / ``scim create --node``)",
    )
    push_type: Literal["users", "teams", "all"] = Field(
        "all",
        description="Intent for what to sync (Commander push still runs full user/group/membership sync)",
    )
    prefix: str | None = Field(
        None,
        description="Optional team name prefix filter (documentation only today)",
    )
    uid_ref: str | None = Field(
        None,
        description="Optional stable handle for plan rows; defaults to scim.push:<node_id>",
    )
    source: Literal["google", "ad", "record"] = Field(
        "record",
        description="``scim push`` data source (Keeper SCIM record / Google / AD)",
    )
    creds_record_uid: str | None = Field(
        None,
        description=(
            "Vault record UID passed to Commander ``scim push --record`` when the push "
            "needs an explicit SCIM configuration record (required for ``google`` and ``ad`` "
            "sources: Google Workspace admin login + ``credentials.json`` attachment; AD binds "
            "and group metadata on that record per Commander SCIM docs)"
        ),
    )


class ScimManifestV1(BaseModel):
    """Top-level keeper-scim.v1 manifest for enterprise provisioning."""

    model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True)

    family: str = Field(default="keeper-scim.v1", alias="schema")
    name: str
    description: str | None = None
    nodes: list[ScimNode] = Field(default_factory=list)
    roles: list[ScimRole] = Field(default_factory=list)
    teams: list[ScimTeam] = Field(default_factory=list)
    users: list[ScimUser] = Field(default_factory=list)
    endpoints: list[ScimEndpointSpec] = Field(
        default_factory=list,
        description="Declarative SCIM push targets (Commander ScimPushCommand)",
    )
