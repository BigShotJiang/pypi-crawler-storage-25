"""Pipeline ephemeral environment models — pipeline-ephemeral-environment.v1.

Declares PAM environments that auto-provision on CI/CD pipeline start
and auto-destroy (credentials rotated, access revoked) on pipeline end.

Source: GitGuardian Shai-Hulud 2 (2026) — 59% of breaches from CI/CD runners.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class PipelineProvider(StrEnum):
    github_actions = "github_actions"
    gitlab_ci = "gitlab_ci"
    jenkins = "jenkins"
    circleci = "circleci"
    buildkite = "buildkite"
    generic = "generic"


class EphemeralResourceSpec(BaseModel):
    uid_ref: str = Field(
        ...,
        description="uid_ref of the PAM resource to provision ephemerally",
    )
    credential_scope: str = Field(
        "read",
        description="Credential scope for this resource: read | execute | write",
    )
    rotate_on_destroy: bool = Field(
        True,
        description="Rotate the credential immediately when environment is destroyed",
    )
    inject_as_env: str | None = Field(
        None,
        description="CI env var name to inject the credential into (e.g. DB_PASSWORD)",
    )
    inject_as_secret: str | None = Field(
        None,
        description=("CI secret name (GitHub Actions secret, GitLab CI variable)"),
    )


class PipelineEphemeralEnvironment(BaseModel):
    name: str
    description: str | None = None
    provider: PipelineProvider = PipelineProvider.github_actions
    trigger_on: list[str] = Field(
        default_factory=lambda: ["push", "pull_request"],
        description="Pipeline events that trigger environment creation",
    )
    branch_pattern: str = Field(
        "*",
        description="Branch pattern (glob) for which to create environments",
    )
    resources: list[EphemeralResourceSpec] = Field(default_factory=list)
    max_lifetime_minutes: int = Field(
        60,
        ge=5,
        le=480,
        description=("Hard limit on environment lifetime — destroy regardless of pipeline state"),
    )
    destroy_on_completion: bool = Field(
        True,
        description="Destroy environment when pipeline job completes",
    )
    audit_log: bool = Field(True)
    isolate_per_pr: bool = Field(
        True,
        description="Create separate environments per PR (not shared across PRs)",
    )


class PipelineEphemeralManifestV1(BaseModel):
    """Root model for a pipeline-ephemeral-environment.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field(
        "pipeline-ephemeral-environment.v1",
        alias="schema",
    )
    name: str
    version: str = "1"
    manager: str = "dsk"
    environments: list[PipelineEphemeralEnvironment] = Field(default_factory=list)
