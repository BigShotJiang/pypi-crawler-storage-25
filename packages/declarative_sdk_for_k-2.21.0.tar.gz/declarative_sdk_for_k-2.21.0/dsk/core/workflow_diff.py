"""Desired-vs-live diff for ``keeper-workflow.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_workflow import WorkflowManifestV1


def compute_workflow_diff(
    manifest: WorkflowManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 — reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared workflow resource (offline demo path).

    Live workflow surfaces require ``pam workflow list`` (Commander 17.2.14+);
    callers pass ``None`` until that readback path is implemented.
    """
    if live:
        raise NotImplementedError(
            "keeper-workflow.v1 live readback is not implemented — pass live=None",
        )

    name = manifest_name or "keeper-workflow"
    changes: list[Change] = []

    for approver in manifest.approvers:
        payload = approver.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=approver.uid_ref,
                resource_type="workflow_approver",
                title=str(approver.name),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for workflow in manifest.workflows:
        payload = workflow.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=workflow.uid_ref,
                resource_type="workflow_config",
                title=str(workflow.name),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for request in manifest.requests:
        payload = request.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=request.uid_ref,
                resource_type="workflow_request",
                title=str(request.uid_ref),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_workflow_diff"]
