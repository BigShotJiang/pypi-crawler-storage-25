"""MCP (Model Context Protocol) secrets binding models — mcp-secrets-binding.v1.

Governs credentials used by MCP server configurations.
Binds MCP server credential slots to Keeper KSM records, enforcing
rotation and eliminating hardcoded secrets in MCP configs.

Source: GitGuardian 2026 report — 24,008 secrets in MCP configs, 2,117 valid.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class McpCredentialSlot(StrEnum):
    api_key = "api_key"
    database_url = "database_url"
    oauth_token = "oauth_token"
    service_account = "service_account"
    webhook_secret = "webhook_secret"
    custom = "custom"


class McpSecretSource(StrEnum):
    ksm = "ksm"  # Keeper Secrets Manager record
    vault_record = "vault_record"  # keeper-vault.v1 managed record
    pam_resource = "pam_resource"  # PAM resource credential


class McpServerCredential(BaseModel):
    slot: McpCredentialSlot = McpCredentialSlot.api_key
    label: str = Field(
        ...,
        description="Human label for this credential slot, e.g. 'openai-api-key'",
    )
    source: McpSecretSource = McpSecretSource.ksm
    uid_ref: str = Field(
        ...,
        description="DSK uid_ref of the KSM/vault/PAM record holding this credential",
    )
    field_name: str = Field(
        "password",
        description="Field name within the record, e.g. 'password', 'api_key', 'custom_field'",
    )
    inject_as_env: str | None = Field(
        None,
        description="If set, inject credential as this env var name in MCP server process",
    )
    inject_as_file: str | None = Field(
        None,
        description="If set, write credential to this file path for the MCP server",
    )
    rotation_policy_uid_ref: str | None = Field(
        None,
        description="uid_ref of a rotation-policy.v1 policy to apply to this credential",
    )


class McpServerBinding(BaseModel):
    name: str
    description: str | None = None
    mcp_server_id: str = Field(
        ...,
        description="MCP server identifier (as declared in the MCP config file)",
    )
    config_file: str | None = Field(
        None,
        description="Path to the MCP config file (e.g. ~/.cursor/mcp.json)",
    )
    credentials: list[McpServerCredential] = Field(default_factory=list)
    audit_log: bool = Field(True)
    alert_on_hardcoded: bool = Field(
        True,
        description="Alert if credentials appear hardcoded in the MCP config file",
    )
    sha256_pin: str | None = None  # SHA-256 of the MCP secrets package/binary
    package_registry: str | None = None  # e.g. "npm", "pypi", "github"


class McpSecretsBindingManifestV1(BaseModel):
    """Root model for a mcp-secrets-binding.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("mcp-secrets-binding.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    servers: list[McpServerBinding] = Field(default_factory=list)
