"""JIT (Just-In-Time) / Ephemeral Access manifest models — jit-access.v1."""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class JitApprovalMode(StrEnum):
    auto = "auto"  # no approval needed
    single = "single"  # one approver required
    dual = "dual"  # two approvers required (4-eyes)
    ticket = "ticket"  # ticket system gate (Jira/ServiceNow)


class JitAccessWindow(BaseModel):
    duration_minutes: int = Field(
        60,
        ge=1,
        le=1440,
        description="Access window in minutes (1 min – 24 h)",
    )
    max_extensions: int = Field(
        0,
        ge=0,
        description="Number of times window can be extended (0 = no extension)",
    )
    extension_minutes: int = Field(
        0,
        ge=0,
        description="Minutes added per extension",
    )


class JitApprovalGate(BaseModel):
    mode: JitApprovalMode = JitApprovalMode.auto
    approvers: list[str] = Field(
        default_factory=list,
        description="Keeper user emails who can approve",
    )
    ticket_system: str | None = Field(
        None,
        description="'jira' or 'servicenow' — required when mode=ticket",
    )
    ticket_field: str | None = Field(
        None,
        description="Field name to verify on the ticket (e.g. 'status')",
    )
    ticket_value: str | None = Field(
        None,
        description="Required field value (e.g. 'Approved')",
    )


class JitResource(BaseModel):
    uid_ref: str = Field(..., description="DSK uid_ref of the PAM resource to grant")
    role: str = Field("read", description="Access role: read | admin | custom")
    justification_required: bool = Field(
        True,
        description="Require requestor to supply a justification string",
    )


class JitPolicy(BaseModel):
    name: str
    description: str | None = None
    resources: list[JitResource] = Field(default_factory=list)
    window: JitAccessWindow = Field(default_factory=lambda: JitAccessWindow())  # type: ignore[call-arg]
    approval: JitApprovalGate = Field(default_factory=lambda: JitApprovalGate())  # type: ignore[call-arg]
    audit_log: bool = Field(True, description="Write access events to Keeper audit log")
    auto_revoke: bool = Field(
        True,
        description="Auto-revoke access when window expires (requires Keeper JIT platform support)",
    )


class JitManifestV1(BaseModel):
    """Root model for a jit-access.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("jit-access.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    policies: list[JitPolicy] = Field(default_factory=list)


def load_jit_manifest(document: dict[str, Any]) -> JitManifestV1:
    """Typed load for ``jit-access.v1`` documents (schema already validated)."""
    from dsk.core.errors import SchemaError

    try:
        return JitManifestV1.model_validate(document)
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=f"typed validation failed: {exc}",
            next_action="fix the reported fields",
        ) from exc
