"""Shared record-type alias map.

Single source of truth for record-type alias resolution. Imported by
both dsk.core.vault_models (L2 schema validation) and
dsk.cli.cmd_import_from_keepercmd (alias resolution during import).

Per Bob code review M8 (agent-collab inbox/martin/2026-05-09T190000Z):
the previous duplicate maps in vault_models.py and cmd_import_from_keepercmd.py
risked drift on next type addition. This module is the canonical map.
"""

from __future__ import annotations

# Map alias → canonical Keeper record type name.
# When adding a new alias, only edit this file.
RECORD_TYPE_ALIASES: dict[str, str] = {
    # Commander legacy / alternate names
    "bankCard": "paymentCard",
    "encryptedNotes": "generalNote",
    "general": "generalNote",
    "secureNote": "generalNote",
    # Rare Keeper v3 types with no direct DSK equivalent yet — explicit
    # documented fallback to login is better than an unexpected crash.
    "wifiCredentials": "login",
    "birthCertificate": "login",
}
