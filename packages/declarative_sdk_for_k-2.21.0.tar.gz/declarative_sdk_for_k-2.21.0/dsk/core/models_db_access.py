"""Database access policy models — db-access-policy.v1.

Declares vault-embedded database session policy for pamDatabase records.
Trigger: KeeperDB GA March 19, 2026 (KeeperDB Proxy + Gateway v1.8.0).
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class DbEngine(StrEnum):
    mysql = "mysql"
    postgresql = "postgresql"
    mssql = "mssql"
    oracle = "oracle"
    mongodb = "mongodb"
    redis = "redis"


class DbAccountMode(StrEnum):
    jit_ephemeral = "jit_ephemeral"  # create account on session, destroy after
    jit_checkout = "jit_checkout"  # check out existing account for duration
    standing = "standing"  # traditional standing access (less preferred)


class SqlAssistMode(StrEnum):
    disabled = "disabled"
    read_only_assist = "read_only_assist"  # KeeperAI suggests only; no writes
    full_assist = "full_assist"  # KeeperAI can draft write queries


class DbSessionAudit(BaseModel):
    record_queries: bool = True
    retain_days: int = Field(365, ge=1, le=3650)
    alert_on_ddl: bool = Field(
        True, description="Alert when DROP/ALTER/TRUNCATE detected in session"
    )
    alert_on_bulk_export: bool = Field(
        True, description="Alert when SELECT returning >10k rows detected"
    )


class DbAccessRule(BaseModel):
    uid_ref: str = Field(..., description="DSK uid_ref of the pamDatabase resource")
    db_engine: DbEngine
    account_mode: DbAccountMode = DbAccountMode.jit_checkout
    jit_ttl_minutes: int | None = Field(
        None,
        ge=1,
        le=10080,
        description="JIT session TTL; required when account_mode=jit_ephemeral",
    )
    allowed_users: list[str] = Field(
        default_factory=list,
        description="Keeper user emails or uid_refs permitted to open sessions",
    )
    sql_assist: SqlAssistMode = SqlAssistMode.disabled
    audit: DbSessionAudit = Field(default_factory=lambda: DbSessionAudit())  # type: ignore[call-arg]
    max_concurrent_sessions: int | None = Field(None, ge=1)

    # KeeperDB Proxy settings (Gateway v1.8.0+, March 2026)
    db_proxy_enabled: bool = Field(
        False,
        description="Enable KeeperDB Proxy for passwordless local-port database access",
    )
    db_proxy_local_port: int | None = Field(
        None,
        ge=1024,
        le=65535,
        description="Local port for KeeperDB Proxy (default: auto-assigned)",
    )
    idle_timeout_minutes: int | None = Field(
        None,
        ge=1,
        description="Auto-close idle sessions after N minutes",
    )
    max_session_duration_minutes: int | None = Field(
        None,
        ge=1,
        description="Maximum allowed session duration in minutes",
    )


class DbAccessPolicyManifestV1(BaseModel):
    """Root model for a db-access-policy.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("db-access-policy.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    rules: list[DbAccessRule] = Field(default_factory=list)
    default_audit: DbSessionAudit = Field(default_factory=lambda: DbSessionAudit())  # type: ignore[call-arg]
