"""Desired-vs-live diff for ``ai-agent.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_ai_agent import AiAgentManifest


def compute_ai_agent_diff(
    manifest: AiAgentManifest,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 — reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared AI agent resource (offline demo path).

    Commander apply remains an upstream gap pending AI/NHI identity API GA.

    Live readback is not implemented — callers pass ``live=None``.
    """
    if live:
        raise NotImplementedError(
            "ai-agent.v1 live readback is not implemented — pass live=None",
        )

    name = manifest_name or "ai-agent"
    changes: list[Change] = []
    for resource in manifest.resources:
        payload = resource.model_dump(mode="python", exclude_none=True)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=resource.uid_ref,
                resource_type="ai_agent",
                title=str(resource.name),
                before={},
                after=payload,
                manifest_name=name,
            ),
        )
    return changes


__all__ = ["compute_ai_agent_diff"]
