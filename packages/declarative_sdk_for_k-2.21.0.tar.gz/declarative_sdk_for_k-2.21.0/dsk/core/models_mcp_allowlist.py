"""Typed models for ``mcp-server-allowlist.v1`` manifests.

Declarative allowlist of approved MCP servers for AI agent deployments.
Addresses OWASP MCP Tool Poisoning (2025) and CVE-2025-6514 (CVSS 9.6).
Provides schema validation and offline plan diff; write path via KSM/Commander
is an upstream gap pending stable MCP registry API.
"""

from __future__ import annotations

from typing import Annotated, Any, Literal, TypeAlias

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    model_validator,
)

from dsk.core.errors import SchemaError

MCP_ALLOWLIST_FAMILY: Literal["mcp-server-allowlist.v1"] = "mcp-server-allowlist.v1"

UidRef: TypeAlias = Annotated[
    str,
    StringConstraints(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
NonEmptyString: TypeAlias = Annotated[str, StringConstraints(min_length=1)]


class _McpAllowlistModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid", str_strip_whitespace=True)


class McpServerEntry(_McpAllowlistModel):
    """One approved MCP server entry."""

    uid_ref: UidRef
    name: NonEmptyString
    server_uri: NonEmptyString
    transport: Literal["http", "stdio", "sse"]
    sha256_pin: str | None = None
    version_constraint: str | None = None
    approved_by: str | None = None
    approved_at: str | None = None
    allowed_agents: list[str] = Field(default_factory=list)
    allowed_tools: list[str] = Field(default_factory=list)
    credential_ref: str | None = None
    risk_level: Literal["low", "medium", "high", "critical"] = "medium"
    tags: dict[str, str] = Field(default_factory=dict)


class McpAllowlistManifest(_McpAllowlistModel):
    """Top-level ``mcp-server-allowlist.v1`` manifest."""

    mcp_allowlist_schema: Literal["mcp-server-allowlist.v1"] = Field(
        default=MCP_ALLOWLIST_FAMILY,
        alias="schema",
    )
    name: NonEmptyString
    servers: list[McpServerEntry] = Field(default_factory=list)

    @model_validator(mode="after")
    def _uid_refs_are_unique(self) -> McpAllowlistManifest:
        seen: dict[str, str] = {}
        duplicates: set[str] = set()
        for server in self.servers:
            if server.uid_ref in seen:
                duplicates.add(server.uid_ref)
            seen[server.uid_ref] = "mcp_server"
        if duplicates:
            raise ValueError(f"duplicate uid_ref values: {sorted(duplicates)}")
        return self

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        """Return ``(uid_ref, kind)`` for all MCP server entries."""
        return [(s.uid_ref, "mcp_server") for s in self.servers]


def load_mcp_allowlist_manifest(document: dict[str, Any]) -> McpAllowlistManifest:
    """Validate with JSON Schema, then parse as ``McpAllowlistManifest``."""
    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != MCP_ALLOWLIST_FAMILY:
        raise SchemaError(
            reason=f"expected {MCP_ALLOWLIST_FAMILY!r}, got {family!r}",
            next_action="set schema: mcp-server-allowlist.v1 on the manifest",
        )
    try:
        return McpAllowlistManifest.model_validate(document)
    except ValidationError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match mcp-server-allowlist.v1 typed rules",
        ) from exc
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match mcp-server-allowlist.v1 typed rules",
        ) from exc


__all__ = [
    "MCP_ALLOWLIST_FAMILY",
    "McpAllowlistManifest",
    "McpServerEntry",
    "load_mcp_allowlist_manifest",
]
