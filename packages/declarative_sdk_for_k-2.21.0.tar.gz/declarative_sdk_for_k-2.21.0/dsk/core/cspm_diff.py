"""Desired-vs-live diff for ``cspm-remediation.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_cspm import CspmRemediationManifestV1


def compute_cspm_diff(
    manifest: CspmRemediationManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared CSPM remediation resource."""
    if live:
        raise NotImplementedError(
            "cspm-remediation.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    if manifest.webhook:
        uid_ref = f"{name}.webhook"
        payload = manifest.webhook.model_dump(mode="python", exclude_none=True)
        title = str(getattr(manifest.webhook, "name", uid_ref))
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="cspm_webhook",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_cspm_diff"]
