"""Desired-vs-live diff for ``ai-agent-trust-chain.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_trust_chain import TrustChainManifestV1


def compute_trust_chain_diff(
    manifest: TrustChainManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared AI agent trust-chain rule."""
    if live:
        raise NotImplementedError(
            "ai-agent-trust-chain.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or "ai-agent-trust-chain"
    changes: list[Change] = []

    for idx, rule in enumerate(manifest.rules):
        payload = rule.model_dump(mode="python", exclude_none=True)
        uid_ref = str(getattr(rule, "uid_ref", None) or f"{name}.rules.{idx}")
        title = str(getattr(rule, "name", None) or uid_ref)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="trust_chain_rule",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_trust_chain_diff"]
