"""Typed models for ``agent-memory-policy.v1`` manifests.

Declarative memory isolation and recall policy for AI agents.
Addresses OWASP Agentic Top 10 A3 (Memory Poisoning) and A4 (Goal Hijacking).
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Any, Literal, TypeAlias

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    model_validator,
)

from dsk.core.errors import SchemaError

AGENT_MEMORY_POLICY_FAMILY: Literal["agent-memory-policy.v1"] = "agent-memory-policy.v1"

UidRef: TypeAlias = Annotated[
    str,
    StringConstraints(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
NonEmptyString: TypeAlias = Annotated[str, StringConstraints(min_length=1)]


class MemoryIsolationMode(StrEnum):
    """How agent memory is isolated between sessions and identities."""

    session = "session"
    agent = "agent"
    role = "role"
    global_ = "global_"


class _AgentMemoryPolicyModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid", str_strip_whitespace=True)


class MemoryPolicyEntry(_AgentMemoryPolicyModel):
    """One memory policy scoped by uid_ref and optional agent bindings."""

    uid_ref: UidRef
    name: NonEmptyString
    applies_to_agent_refs: list[str] = Field(default_factory=list)
    isolation_mode: MemoryIsolationMode = MemoryIsolationMode.session
    max_context_tokens: int | None = Field(default=None, ge=1)
    allow_cross_session_recall: bool = False
    allow_tool_output_in_memory: bool = True
    allow_file_content_in_memory: bool = True
    allow_web_content_in_memory: bool = False
    sanitize_html: bool = True
    sanitize_markdown_links: bool = True
    goal_lock_enabled: bool = False
    max_instruction_depth: int | None = Field(default=None, ge=1)
    tags: dict[str, str] = Field(default_factory=dict)


class AgentMemoryPolicyManifest(_AgentMemoryPolicyModel):
    """Top-level ``agent-memory-policy.v1`` manifest."""

    agent_memory_policy_schema: Literal["agent-memory-policy.v1"] = Field(
        default=AGENT_MEMORY_POLICY_FAMILY,
        alias="schema",
    )
    name: NonEmptyString
    policies: list[MemoryPolicyEntry] = Field(default_factory=list)

    @model_validator(mode="after")
    def _uid_refs_are_unique(self) -> AgentMemoryPolicyManifest:
        seen: dict[str, str] = {}
        duplicates: set[str] = set()
        for policy in self.policies:
            if policy.uid_ref in seen:
                duplicates.add(policy.uid_ref)
            seen[policy.uid_ref] = "memory_policy"
        if duplicates:
            raise ValueError(f"duplicate uid_ref values: {sorted(duplicates)}")
        return self

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        """Return ``(uid_ref, kind)`` for all policy entries."""
        return [(p.uid_ref, "memory_policy") for p in self.policies]


def load_agent_memory_policy_manifest(document: dict[str, Any]) -> AgentMemoryPolicyManifest:
    """Validate with JSON Schema, then parse as ``AgentMemoryPolicyManifest``."""
    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != AGENT_MEMORY_POLICY_FAMILY:
        raise SchemaError(
            reason=f"expected {AGENT_MEMORY_POLICY_FAMILY!r}, got {family!r}",
            next_action="set schema: agent-memory-policy.v1 on the manifest",
        )
    try:
        return AgentMemoryPolicyManifest.model_validate(document)
    except ValidationError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match agent-memory-policy.v1 typed rules",
        ) from exc
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match agent-memory-policy.v1 typed rules",
        ) from exc


__all__ = [
    "AGENT_MEMORY_POLICY_FAMILY",
    "AgentMemoryPolicyManifest",
    "MemoryIsolationMode",
    "MemoryPolicyEntry",
    "load_agent_memory_policy_manifest",
]
