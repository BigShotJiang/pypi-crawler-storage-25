"""Typed models for Keeper EPM-related manifests.

* ``keeper-epm.v1`` — elevation policies, watchlists, approvers (W18 offline
  foundation).

* ``epm-policy.v1`` — declarative application allow/deny/elevation rules
  for Endpoint Privilege Management (distinct schema family).

W18 ships an offline foundation only for ``keeper-epm.v1``: schema validation,
typed load, and field-level diff. Apply remains an upstream gap until a PEDM
tenant writer and readback path are proven through an MSP managed company.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Any, Literal, TypeAlias

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    model_validator,
)

from dsk.core.errors import SchemaError

EPM_FAMILY: Literal["keeper-epm.v1"] = "keeper-epm.v1"

UidRef: TypeAlias = Annotated[
    str,
    StringConstraints(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$"),
]
NonEmptyString: TypeAlias = Annotated[str, StringConstraints(min_length=1)]
EmailString: TypeAlias = Annotated[
    str,
    StringConstraints(min_length=3, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$"),
]


class _EpmModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid", str_strip_whitespace=True)


class EpmWatchlist(_EpmModel):
    """One EPM allowlist/blocklist row."""

    uid_ref: UidRef
    name: NonEmptyString
    description: str = ""
    policy_type: Literal["allowlist", "blocklist"]
    entries: list[NonEmptyString] = Field(default_factory=list)


class EpmElevationPolicy(_EpmModel):
    """One EPM elevation policy row within ``keeper-epm.v1``."""

    uid_ref: UidRef
    name: NonEmptyString
    elevation_type: Literal["auto", "approval", "denied"]
    target_users: list[NonEmptyString] = Field(default_factory=list)
    target_groups: list[NonEmptyString] = Field(default_factory=list)
    application_patterns: list[NonEmptyString] = Field(default_factory=list)


class EpmApprover(_EpmModel):
    """One EPM approver row."""

    uid_ref: UidRef
    name: NonEmptyString
    email: EmailString
    scope_uid_refs: list[UidRef] = Field(default_factory=list)


class EpmAuditConfig(_EpmModel):
    """Tenant-wide EPM audit configuration."""

    retention_days: Annotated[int, Field(ge=1)]
    alert_on_denied: bool
    export_format: Literal["json", "siem", "csv"]


class EpmManifestV1(_EpmModel):
    """Top-level ``keeper-epm.v1`` manifest."""

    epm_schema: Literal["keeper-epm.v1"] = Field(default=EPM_FAMILY, alias="schema")
    watchlists: list[EpmWatchlist] = Field(default_factory=list)
    policies: list[EpmElevationPolicy] = Field(default_factory=list)
    approvers: list[EpmApprover] = Field(default_factory=list)
    audit_config: EpmAuditConfig | None = None

    @model_validator(mode="after")
    def _uid_refs_are_unique(self) -> EpmManifestV1:
        seen: dict[str, str] = {}
        duplicates: set[str] = set()
        for uid_ref, kind in self.iter_uid_refs():
            if uid_ref in seen:
                duplicates.add(uid_ref)
            seen[uid_ref] = kind
        if duplicates:
            raise ValueError(f"duplicate uid_ref values: {sorted(duplicates)}")
        return self

    @model_validator(mode="after")
    def _approver_scopes_exist(self) -> EpmManifestV1:
        policy_refs = {policy.uid_ref for policy in self.policies}
        unknown = sorted(
            {
                scope
                for approver in self.approvers
                for scope in approver.scope_uid_refs
                if scope not in policy_refs
            }
        )
        if unknown:
            raise ValueError(f"approver scope_uid_refs must reference policies: {unknown}")
        return self

    def iter_uid_refs(self) -> list[tuple[str, str]]:
        """Return ``(uid_ref, kind)`` for all EPM objects with manifest handles."""
        refs: list[tuple[str, str]] = []
        refs.extend((row.uid_ref, "epm_watchlist") for row in self.watchlists)
        refs.extend((row.uid_ref, "epm_policy") for row in self.policies)
        refs.extend((row.uid_ref, "epm_approver") for row in self.approvers)
        return refs


# --- epm-policy.v1 — application control rules ------------------------------------------------

EPM_POLICY_FAMILY: Literal["epm-policy.v1"] = "epm-policy.v1"


class DefaultPolicyCategory(StrEnum):
    """Built-in EPM policy categories (Admin Console 17.8.1+)."""

    allow_listed_applications = "allow_listed_applications"
    deny_listed_applications = "deny_listed_applications"
    elevate_specific_applications = "elevate_specific_applications"
    block_unsigned_executables = "block_unsigned_executables"
    restrict_installer_access = "restrict_installer_access"
    audit_all_executions = "audit_all_executions"
    just_in_time_elevation = "just_in_time_elevation"
    credential_injection_rules = "credential_injection_rules"


class EpmRuleEffect(StrEnum):
    allow = "allow"
    deny = "deny"
    elevate = "elevate"
    audit = "audit"


class EpmTargetPlatform(StrEnum):
    windows = "windows"
    macos = "macos"
    linux = "linux"
    all_ = "all"


class EpmApplicationRule(BaseModel):
    """One application matching rule inside an ``epm-policy.v1`` policy."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: str | None = None
    effect: EpmRuleEffect = EpmRuleEffect.audit
    platform: EpmTargetPlatform = EpmTargetPlatform.all_
    match_path: str | None = Field(
        None,
        description="Application path pattern (glob), e.g. C:\\\\Program Files\\\\*\\\\app.exe",
    )
    match_hash: str | None = Field(None, description="SHA-256 hash of the allowed executable")
    match_publisher: str | None = Field(
        None,
        description="Code signing publisher name",
    )
    require_justification: bool = Field(
        False,
        description="Require user to provide justification for elevation",
    )
    notify: bool = Field(
        True,
        description="Send alert when this rule matches",
    )


class EpmPolicy(BaseModel):
    """Grouped EPM rules and defaults for ``epm-policy.v1``."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: str | None = None
    default_policy_category: DefaultPolicyCategory | None = None
    applies_to_groups: list[str] = Field(
        default_factory=list,
        description="Keeper group names or UIDs this policy applies to",
    )
    rules: list[EpmApplicationRule] = Field(default_factory=list)
    default_effect: EpmRuleEffect = Field(
        EpmRuleEffect.audit,
        description="Effect for applications not matched by any rule",
    )
    audit_log: bool = Field(True)


class EpmPolicyManifestV1(BaseModel):
    """Root model for an epm-policy.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("epm-policy.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    default_policies: list[DefaultPolicyCategory] = Field(
        default_factory=list,
        description=(
            "Admin Console default policy categories to enable in bulk (17.8.1 built-ins)"
        ),
    )
    policies: list[EpmPolicy] = Field(default_factory=list)


def load_epm_policy_manifest(document: dict[str, Any]) -> EpmPolicyManifestV1:
    """Validate with JSON Schema, then parse as ``EpmPolicyManifestV1``."""
    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != EPM_POLICY_FAMILY:
        raise SchemaError(
            reason=f"expected {EPM_POLICY_FAMILY!r}, got {family!r}",
            next_action="set schema: epm-policy.v1 on the manifest",
        )
    try:
        return EpmPolicyManifestV1.model_validate(document)
    except ValidationError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match epm-policy.v1 typed rules",
        ) from exc
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match epm-policy.v1 typed rules",
        ) from exc


def load_epm_manifest(document: dict[str, Any]) -> EpmManifestV1:
    """Validate with JSON Schema, then parse as ``EpmManifestV1``."""
    from dsk.core.schema import validate_manifest

    family = validate_manifest(document)
    if family != EPM_FAMILY:
        raise SchemaError(
            reason=f"expected {EPM_FAMILY!r}, got {family!r}",
            next_action="set schema: keeper-epm.v1 on the manifest",
        )
    try:
        return EpmManifestV1.model_validate(document)
    except ValidationError as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match keeper-epm.v1 typed rules",
        ) from exc
    except (ValueError, TypeError) as exc:
        raise SchemaError(
            reason=str(exc),
            next_action="fix fields to match keeper-epm.v1 typed rules",
        ) from exc


__all__ = [
    "EPM_FAMILY",
    "EPM_POLICY_FAMILY",
    "DefaultPolicyCategory",
    "EpmApplicationRule",
    "EpmApprover",
    "EpmAuditConfig",
    "EpmElevationPolicy",
    "EpmManifestV1",
    "EpmPolicy",
    "EpmPolicyManifestV1",
    "EpmRuleEffect",
    "EpmTargetPlatform",
    "EpmWatchlist",
    "load_epm_manifest",
    "load_epm_policy_manifest",
]
