"""Desired-vs-live diff for ``keeper-ai-policy.v1`` (offline; no tenant readback)."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_ai_policy import AiPolicyManifestV1, AiSessionPolicy


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def compute_ai_policy_diff(
    manifest: AiPolicyManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Classify declared AI session policies against a live configuration snapshot."""
    name = manifest_name or "keeper-ai-policy.v1"
    changes: list[Change] = []

    if live is None:
        for idx, policy in enumerate(manifest.policies):
            payload = policy.model_dump(mode="python", exclude_none=True)
            uid_ref = getattr(policy, "uid_ref", None) or f"{name}.{idx}"
            policy_name = getattr(policy, "name", None)
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=str(uid_ref),
                    resource_type="ai_session_policy",
                    title=str(policy_name) if policy_name else str(uid_ref),
                    before={},
                    after=payload,
                    manifest_name=name,
                ),
            )
        return changes

    live_by_name: dict[str, dict[str, Any]] = {}
    for row in live.get("policies") or []:
        if isinstance(row, Mapping) and row.get("name") is not None:
            live_by_name[str(row["name"])] = dict(row)

    for idx, policy in enumerate(manifest.policies):
        payload = policy.model_dump(mode="python", exclude_none=True)
        uid_ref = getattr(policy, "uid_ref", None) or f"{name}.{idx}"
        policy_name = getattr(policy, "name", None)
        title = str(policy_name) if policy_name else str(uid_ref)
        live_row = live_by_name.get(str(policy_name)) if policy_name is not None else None

        if live_row is None:
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=str(uid_ref),
                    resource_type="ai_session_policy",
                    title=title,
                    before={},
                    after=payload,
                    manifest_name=name,
                ),
            )
            continue

        live_payload = AiSessionPolicy.model_validate(live_row).model_dump(
            mode="python", exclude_none=True
        )
        if _canonical_json(live_payload) == _canonical_json(payload):
            changes.append(
                Change(
                    kind=ChangeKind.NOOP,
                    uid_ref=str(uid_ref),
                    resource_type="ai_session_policy",
                    title=title,
                    before=dict(live_row),
                    after=payload,
                    reason="no drift",
                    manifest_name=name,
                ),
            )
        else:
            changes.append(
                Change(
                    kind=ChangeKind.UPDATE,
                    uid_ref=str(uid_ref),
                    resource_type="ai_session_policy",
                    title=title,
                    before=dict(live_row),
                    after=payload,
                    manifest_name=name,
                ),
            )

    return changes


__all__ = ["compute_ai_policy_diff"]
