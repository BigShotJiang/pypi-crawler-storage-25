"""PAM connection profile models — pam-connection-profile.v1.

Declares reusable PAM connection profiles (port, protocol, proxy, recording quality).
Profiles can be referenced by multiple pam-environment.v1 resources.

Source: Commander 17.2.11 (April 2026) + KSM SDK 17.1.3 (January 2026) connection fields.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class ConnectionProtocol(StrEnum):
    ssh = "ssh"
    rdp = "rdp"
    vnc = "vnc"
    http = "http"
    https = "https"
    mysql = "mysql"
    postgres = "postgres"
    mssql = "mssql"
    oracle = "oracle"


class RecordingQuality(StrEnum):
    off = "off"
    low = "low"  # compressed, minimal storage
    medium = "medium"  # balanced quality/storage
    high = "high"  # full fidelity, maximum storage


class ProxyConfig(BaseModel):
    type: str = Field("socks5", description="Proxy type: socks5, http, https")
    host: str = Field(..., description="Proxy host (no credentials — use uid_ref)")
    port: int = Field(1080, ge=1, le=65535)
    credential_uid_ref: str | None = Field(
        None,
        description="DSK uid_ref of the record holding proxy credentials",
    )


class SshConnectionOptions(BaseModel):
    port: int = Field(22, ge=1, le=65535)
    host_key_checking: bool = Field(True)
    compression: bool = Field(False)
    keepalive_interval: int = Field(60, ge=0)
    preferred_authentications: str = Field(
        "publickey,keyboard-interactive,password",
    )


class RdpConnectionOptions(BaseModel):
    port: int = Field(3389, ge=1, le=65535)
    color_depth: int = Field(16, description="Color depth: 8, 16, 24, 32")
    width: int = Field(1920)
    height: int = Field(1080)
    disable_audio: bool = Field(False)
    enable_drive_redirection: bool = Field(False)


class DatabaseConnectionOptions(BaseModel):
    port: int | None = Field(
        None,
        description=("Override default port. Defaults: MySQL=3306, Postgres=5432, MSSQL=1433"),
    )
    ssl_mode: str = Field(
        "prefer",
        description="SSL mode: disable, allow, prefer, require, verify-ca, verify-full",
    )
    connection_timeout_seconds: int = Field(30, ge=1)
    max_connections: int = Field(10, ge=1)


class PamConnectionProfile(BaseModel):
    name: str
    description: str | None = None
    protocol: ConnectionProtocol
    recording_quality: RecordingQuality = RecordingQuality.medium
    proxy: ProxyConfig | None = None
    ssh: SshConnectionOptions | None = None
    rdp: RdpConnectionOptions | None = None
    database: DatabaseConnectionOptions | None = None
    session_timeout_minutes: int = Field(60, ge=1, le=1440)
    idle_timeout_minutes: int = Field(15, ge=1)
    max_concurrent_sessions: int = Field(5, ge=1)
    launch_credentials: str | None = Field(
        None,
        description=(
            "UID ref of a pamUser record to use as launch credentials (Commander 17.2.8+)"
        ),
    )


class PamConnectionProfileManifestV1(BaseModel):
    """Root model for a pam-connection-profile.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("pam-connection-profile.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    profiles: list[PamConnectionProfile] = Field(default_factory=list)
