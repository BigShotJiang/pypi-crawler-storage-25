"""Desired-vs-live diff for ``keeper-enterprise.v1`` offline manifests."""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.metadata import MANAGER_NAME
from dsk.core.models_enterprise import EnterpriseManifestV1

_BLOCK_ORDER = ("nodes", "users", "roles", "teams", "enforcements", "aliases")
_RESOURCE_BY_BLOCK = {
    "nodes": "enterprise_node",
    "users": "enterprise_user",
    "roles": "enterprise_role",
    "teams": "enterprise_team",
    "enforcements": "enterprise_enforcement",
    "aliases": "enterprise_alias",
}
_DELETE_SKIP_REASON = "unmanaged enterprise object; pass allow_delete=True to remove"
_KIND_ORDER = {
    ChangeKind.CREATE: 0,
    ChangeKind.UPDATE: 1,
    ChangeKind.NOOP: 2,
    ChangeKind.DELETE: 3,
    ChangeKind.SKIP: 3,
    ChangeKind.CONFLICT: 4,
}


def compute_enterprise_diff(
    manifest: EnterpriseManifestV1,
    live_enterprise: EnterpriseManifestV1 | Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,
    adopt: bool = False,
) -> list[Change]:
    """Classify desired enterprise state against an offline live snapshot."""
    desired = _index_objects(_payload_from_manifest(manifest))
    live, duplicate_live = _index_live(_payload_from_live(live_enterprise))
    manifest_name = manifest_name or "keeper-enterprise"

    changes: list[Change] = []
    for key, desired_obj in desired.items():
        if key in duplicate_live:
            continue
        live_obj = live.get(key)
        if live_obj is None:
            changes.append(
                Change(
                    kind=ChangeKind.CREATE,
                    uid_ref=desired_obj.uid_ref,
                    resource_type=desired_obj.resource_type,
                    title=desired_obj.title,
                    before={},
                    after=desired_obj.payload,
                    manifest_name=manifest_name,
                )
            )
            continue

        live_manager = live_obj.manager
        if live_manager is not None:
            if live_manager != MANAGER_NAME:
                changes.append(
                    Change(
                        kind=ChangeKind.CONFLICT,
                        uid_ref=desired_obj.uid_ref,
                        resource_type=desired_obj.resource_type,
                        title=desired_obj.title,
                        keeper_uid=live_obj.keeper_uid,
                        before={**live_obj.payload, "manager": live_manager},
                        after=desired_obj.payload,
                        reason=(
                            f"managed by other manager {live_manager!r}; expected {MANAGER_NAME!r}"
                        ),
                        manifest_name=manifest_name,
                    )
                )
                continue
            if adopt:
                changes.append(
                    Change(
                        kind=ChangeKind.NOOP,
                        uid_ref=desired_obj.uid_ref,
                        resource_type=desired_obj.resource_type,
                        title=desired_obj.title,
                        keeper_uid=live_obj.keeper_uid,
                        before={**live_obj.payload, "manager": live_manager},
                        after=desired_obj.payload,
                        reason="already managed by manifest manager",
                        manifest_name=manifest_name,
                    )
                )
                continue

        if adopt:
            changes.append(
                Change(
                    kind=ChangeKind.UPDATE,
                    uid_ref=desired_obj.uid_ref,
                    resource_type=desired_obj.resource_type,
                    title=desired_obj.title,
                    keeper_uid=live_obj.keeper_uid,
                    before=live_obj.payload,
                    after=desired_obj.payload,
                    reason="adoption: write ownership marker",
                    manifest_name=manifest_name,
                )
            )
            continue

        before, after = _field_delta(live_obj.payload, desired_obj.payload)
        if before or after:
            changes.append(
                Change(
                    kind=ChangeKind.UPDATE,
                    uid_ref=desired_obj.uid_ref,
                    resource_type=desired_obj.resource_type,
                    title=desired_obj.title,
                    keeper_uid=live_obj.keeper_uid,
                    before=before,
                    after=after,
                    manifest_name=manifest_name,
                )
            )
            continue

        changes.append(
            Change(
                kind=ChangeKind.NOOP,
                uid_ref=desired_obj.uid_ref,
                resource_type=desired_obj.resource_type,
                title=desired_obj.title,
                keeper_uid=live_obj.keeper_uid,
                before=live_obj.payload,
                after=desired_obj.payload,
                reason="no drift",
                manifest_name=manifest_name,
            )
        )

    for key, live_obj in live.items():
        if key in desired or key in duplicate_live:
            continue
        kind = ChangeKind.DELETE if allow_delete else ChangeKind.SKIP
        changes.append(
            Change(
                kind=kind,
                uid_ref=live_obj.uid_ref,
                resource_type=live_obj.resource_type,
                title=live_obj.title,
                keeper_uid=live_obj.keeper_uid,
                before=live_obj.payload,
                reason=None if allow_delete else _DELETE_SKIP_REASON,
                manifest_name=manifest_name,
            )
        )

    for rows in duplicate_live.values():
        first = rows[0]
        changes.append(
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref=first.uid_ref,
                resource_type=first.resource_type,
                title=first.title,
                before={"uid_ref": first.uid_ref, "count": len(rows)},
                reason=f"duplicate live enterprise uid_ref: {first.uid_ref}",
                manifest_name=manifest_name,
            )
        )

    return sorted(changes, key=_change_sort_key)


class _EnterpriseObject:
    def __init__(self, *, block: str, payload: dict[str, Any]) -> None:
        self.block = block
        keeper_uid = payload.get("keeper_uid")
        self.manager = _manager_from_payload(payload)
        self.payload = _normalise_payload(payload)
        self.uid_ref = str(self.payload["uid_ref"])
        self.resource_type = _RESOURCE_BY_BLOCK[block]
        self.title = _title_for(block, self.payload)
        self.keeper_uid = str(keeper_uid) if keeper_uid is not None else None


def _payload_from_manifest(manifest: EnterpriseManifestV1) -> dict[str, Any]:
    return manifest.model_dump(mode="python", exclude_none=True, by_alias=True)


def _payload_from_live(
    live_enterprise: EnterpriseManifestV1 | Mapping[str, Any] | None,
) -> dict[str, Any]:
    if live_enterprise is None:
        return {block: [] for block in _BLOCK_ORDER}
    if isinstance(live_enterprise, EnterpriseManifestV1):
        return live_enterprise.model_dump(mode="python", exclude_none=True, by_alias=True)
    return dict(live_enterprise)


def _index_objects(payload: Mapping[str, Any]) -> dict[str, _EnterpriseObject]:
    out: dict[str, _EnterpriseObject] = {}
    for block in _BLOCK_ORDER:
        for row in payload.get(block) or []:
            if not isinstance(row, Mapping):
                continue
            obj = _EnterpriseObject(block=block, payload=dict(row))
            out[obj.uid_ref] = obj
    return out


def _index_live(
    payload: Mapping[str, Any],
) -> tuple[dict[str, _EnterpriseObject], dict[str, list[_EnterpriseObject]]]:
    grouped: dict[str, list[_EnterpriseObject]] = defaultdict(list)
    for block in _BLOCK_ORDER:
        for row in payload.get(block) or []:
            if not isinstance(row, Mapping):
                continue
            obj = _EnterpriseObject(block=block, payload=dict(row))
            grouped[obj.uid_ref].append(obj)

    live: dict[str, _EnterpriseObject] = {}
    duplicate: dict[str, list[_EnterpriseObject]] = {}
    for key, rows in grouped.items():
        if len(rows) > 1:
            duplicate[key] = rows
        else:
            live[key] = rows[0]
    return live, duplicate


def _normalise_payload(payload: dict[str, Any]) -> dict[str, Any]:
    out = {key: _normalise_value(value) for key, value in payload.items() if value is not None}
    out.pop("keeper_uid", None)
    out.pop("manager", None)
    out.pop("marker", None)
    return out


def _manager_from_payload(payload: Mapping[str, Any]) -> str | None:
    marker = payload.get("marker")
    if isinstance(marker, Mapping):
        marker_manager = marker.get("manager")
        if marker_manager is not None and str(marker_manager).strip():
            return str(marker_manager).strip()
    manager = payload.get("manager")
    if manager is not None and str(manager).strip():
        return str(manager).strip()
    return None


def _normalise_value(value: Any) -> Any:
    if isinstance(value, list):
        normalised = [_normalise_value(item) for item in value]
        if all(not isinstance(item, dict | list) for item in normalised):
            return sorted(normalised, key=lambda item: str(item))
        return sorted(normalised, key=lambda item: json.dumps(item, sort_keys=True))
    if isinstance(value, dict):
        return {key: _normalise_value(value[key]) for key in sorted(value)}
    return value


def _field_delta(
    live_payload: dict[str, Any],
    desired_payload: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    keys = sorted(set(live_payload) | set(desired_payload))
    before: dict[str, Any] = {}
    after: dict[str, Any] = {}
    for key in keys:
        if key == "uid_ref":
            continue
        if live_payload.get(key) == desired_payload.get(key):
            continue
        before[key] = live_payload.get(key)
        after[key] = desired_payload.get(key)
    return before, after


def _title_for(block: str, payload: dict[str, Any]) -> str:
    if block in ("nodes", "roles", "teams"):
        return str(payload.get("name") or payload["uid_ref"])
    if block in ("users", "aliases"):
        return str(payload.get("email") or payload["uid_ref"])
    if block == "enforcements":
        return str(payload.get("key") or payload["uid_ref"])
    return str(payload["uid_ref"])


def _change_sort_key(change: Change) -> tuple[int, int, str]:
    block_rank = {
        resource: index for index, resource in enumerate(_RESOURCE_BY_BLOCK.values())
    }.get(change.resource_type, len(_RESOURCE_BY_BLOCK))
    return (_KIND_ORDER[change.kind], block_rank, change.uid_ref or change.title)


__all__ = ["compute_enterprise_diff"]
