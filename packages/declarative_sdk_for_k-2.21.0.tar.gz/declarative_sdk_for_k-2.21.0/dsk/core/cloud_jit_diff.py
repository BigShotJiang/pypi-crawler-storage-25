"""Desired-vs-live diff for ``cloud-jit.v1`` (offline)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_cloud_jit import CloudJitManifestV1


def compute_cloud_jit_diff(
    manifest: CloudJitManifestV1,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for every declared cloud JIT policy."""
    if live:
        raise NotImplementedError(
            "cloud-jit.v1 live readback is not implemented - pass live=None",
        )

    name = manifest_name or manifest.name
    changes: list[Change] = []

    for idx, policy in enumerate(manifest.policies):
        payload = policy.model_dump(mode="python", exclude_none=True)
        uid_ref_value = getattr(policy, "uid_ref", None)
        uid_ref = str(uid_ref_value) if uid_ref_value is not None else f"{name}.policies.{idx}"
        title_value = getattr(policy, "name", None)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="cloud_jit_policy",
                title=str(title_value) if title_value is not None else uid_ref,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_cloud_jit_diff"]
