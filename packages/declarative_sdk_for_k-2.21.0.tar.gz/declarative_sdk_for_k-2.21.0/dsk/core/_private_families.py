"""Private manifest-family registration.

This file is intentionally excluded from the public mirror. Public code imports
it behind ``ImportError`` guards so excluding private models and schemas cannot
break package imports.
"""

from __future__ import annotations

from typing import Any

KEEPER_DRIVE_FAMILY = "keeper-drive.v1"


def register_private(registry: dict[str, str] | None = None) -> None:
    """Register private schema resources in the caller-provided registry."""
    if registry is None:
        from dsk.core.schema import SCHEMA_RESOURCE_BY_FAMILY

        registry = SCHEMA_RESOURCE_BY_FAMILY
    registry.setdefault(
        KEEPER_DRIVE_FAMILY,
        "keeper-drive/keeper-drive.v1.schema.json",
    )


def load_private_manifest(family: str, document: dict[str, Any]) -> Any | None:
    """Return a typed private manifest, or ``None`` for public families."""
    if family != KEEPER_DRIVE_FAMILY:
        return None
    from dsk.core.models_keeper_drive import load_keeper_drive_manifest

    return load_keeper_drive_manifest(document)


__all__ = ["KEEPER_DRIVE_FAMILY", "load_private_manifest", "register_private"]
