"""Desired-vs-live diff for ``agentic-skill-policy.v1`` (offline; no tenant readback)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_agentic_skill_policy import AgenticSkillPolicyManifest


def compute_agentic_skill_policy_diff(
    manifest: AgenticSkillPolicyManifest,
    live: Mapping[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,  # noqa: ARG004 - reserved when live snapshots exist
) -> list[Change]:
    """Emit CREATE rows for skills and role policies (offline demo path)."""
    if live:
        raise NotImplementedError(
            "agentic-skill-policy.v1 live readback is not implemented — pass live=None",
        )

    name = manifest_name or "agentic-skill-policy"
    changes: list[Change] = []

    for skill in manifest.skills:
        payload = skill.model_dump(mode="python", exclude_none=True)
        uid_ref = str(skill.uid_ref)
        title = str(skill.name)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="agentic_skill",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    for role in manifest.role_policies:
        payload = role.model_dump(mode="python", exclude_none=True)
        uid_ref = str(role.uid_ref)
        title = str(role.role_name)
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=uid_ref,
                resource_type="agentic_skill_role_policy",
                title=title,
                before={},
                after=payload,
                manifest_name=name,
            ),
        )

    return changes


__all__ = ["compute_agentic_skill_policy_diff"]
