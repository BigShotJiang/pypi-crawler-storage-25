"""Multi-cloud JIT federation models — cloud-jit.v1.

Declares cloud-provider JIT access policies (AWS IAM Identity Center,
Azure PIM, GCP PAM) aligned with Keeper PAM resources.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class CloudProvider(StrEnum):
    aws = "aws"
    azure = "azure"
    gcp = "gcp"


class AwsJitConfig(BaseModel):
    account_id: str = Field(..., description="AWS account ID")
    permission_set_arn: str = Field(
        ...,
        description="AWS IAM Identity Center Permission Set ARN",
    )
    identity_store_id: str = Field(
        ...,
        description="AWS IAM Identity Center Identity Store ID",
    )
    duration_hours: int = Field(1, ge=1, le=12)


class AzureJitConfig(BaseModel):
    subscription_id: str = Field(..., description="Azure subscription ID")
    role_definition_id: str = Field(..., description="Azure role definition GUID")
    tenant_id: str = Field(..., description="Azure tenant ID")
    duration_hours: int = Field(1, ge=1, le=8)
    require_mfa: bool = Field(True)


class GcpJitConfig(BaseModel):
    project_id: str = Field(..., description="GCP project ID")
    role: str = Field(..., description="GCP IAM role, e.g. roles/compute.admin")
    organization_id: str | None = Field(None)
    duration_hours: int = Field(1, ge=1, le=12)


class CloudJitPolicy(BaseModel):
    name: str
    description: str | None = None
    provider: CloudProvider
    keeper_pam_uid_ref: str = Field(
        ...,
        description="uid_ref of the Keeper PAM resource that guards this cloud access",
    )
    aws: AwsJitConfig | None = None
    azure: AzureJitConfig | None = None
    gcp: GcpJitConfig | None = None
    require_keeper_session: bool = Field(
        True,
        description="Require an active Keeper PAM session before granting cloud JIT",
    )
    audit_log: bool = Field(True)


class CloudJitManifestV1(BaseModel):
    """Root model for a cloud-jit.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("cloud-jit.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    policies: list[CloudJitPolicy] = Field(default_factory=list)


CLOUD_JIT_FAMILY: str = "cloud-jit.v1"

__all__ = [
    "CLOUD_JIT_FAMILY",
    "AwsJitConfig",
    "AzureJitConfig",
    "CloudJitManifestV1",
    "CloudJitPolicy",
    "CloudProvider",
    "GcpJitConfig",
]
