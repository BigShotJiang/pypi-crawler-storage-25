"""Manifest IO (YAML and JSON).

Parse paths or strings, canonicalise aliases, validate schema, build **typed**
models. **PAM only:** :func:`load_manifest` / :func:`load_manifest_string` →
:class:`~dsk.core.models.Manifest`. **PAM + vault L1 + sharing L1 + MSP slice 1:**
:func:`load_declarative_manifest` / :func:`load_declarative_manifest_string` →
``Manifest``, :class:`~dsk.core.vault_models.VaultManifestV1` for
``keeper-vault.v1``, :class:`~dsk.core.models_vault_sharing.VaultSharingManifestV1`
for ``keeper-vault-sharing.v1``, :class:`~dsk.core.msp_models.MspManifestV1`
for ``msp-environment.v1``, :class:`~dsk.core.models_ksm.KsmManifestV1`
for ``keeper-ksm.v1``, or
:class:`~dsk.core.models_integrations_identity.IdentityManifestV1` for
``keeper-integrations-identity.v1``, or
:class:`~dsk.core.models_integrations_events.EventsManifestV1` for
``keeper-integrations-events.v1``, or
:class:`~dsk.core.models_pam_extended.PamExtendedManifestV1` for
``keeper-pam-extended.v1``, or
:class:`~dsk.core.models_epm.EpmManifestV1` for ``keeper-epm.v1``, or
:class:`~dsk.core.models_terraform.TerraformIntegrationManifestV1` for
``keeper-terraform.v1``, or
:class:`~dsk.core.models_k8s_eso.K8sEsoManifestV1` for
``keeper-k8s-eso.v1``, or
:class:`~dsk.core.models_siem.SiemManifestV1` for ``keeper-siem.v1``, or
:class:`~dsk.core.models_nhi.NhiAgentManifest` for ``nhi-agent.v1``, or
:class:`~dsk.core.models_ai_agent.AiAgentManifest` for ``ai-agent.v1``, or
:class:`~dsk.core.models_mcp_allowlist.McpAllowlistManifest` for
``mcp-server-allowlist.v1``, or
:class:`~dsk.core.models_agentic_skill_policy.AgenticSkillPolicyManifest` for
``agentic-skill-policy.v1``, or
:class:`~dsk.core.models_agent_memory_policy.AgentMemoryPolicyManifest` for
``agent-memory-policy.v1``,
:class:`~dsk.core.models_policy.PolicyManifestV1` for ``keeper-policy.v1``,
or other packaged typed families registered by the private-family hook.
Dump: stable canonical YAML/JSON for git diffs and Commander interop.
"""

from __future__ import annotations

import json
import logging
import os
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Any

from dsk.core.errors import ManifestError, SchemaError, UnsupportedFamilyError
from dsk.core.models import Manifest
from dsk.core.resource_limits import ResourceLimitError, read_text_limited

try:
    from dsk.core.models_ai_agent import AI_AGENT_FAMILY
except ImportError:  # stripped in public build
    AI_AGENT_FAMILY = "ai-agent.v1"
from dsk.core.models_agent_memory_policy import (
    AGENT_MEMORY_POLICY_FAMILY,
    load_agent_memory_policy_manifest,
)
from dsk.core.models_agentic_skill_policy import (
    AGENTIC_SKILL_POLICY_FAMILY,
    load_agentic_skill_policy_manifest,
)
from dsk.core.models_enterprise import ENTERPRISE_FAMILY
from dsk.core.models_epm import EPM_FAMILY
from dsk.core.models_integrations_events import EVENTS_FAMILY
from dsk.core.models_integrations_identity import IDENTITY_FAMILY
from dsk.core.models_k8s_eso import K8S_ESO_FAMILY
from dsk.core.models_mcp_allowlist import (
    MCP_ALLOWLIST_FAMILY,
    load_mcp_allowlist_manifest,
)

try:
    from dsk.core.models_nhi import NHI_FAMILY
except ImportError:  # stripped in public build
    NHI_FAMILY = "nhi-agent.v1"
try:
    from dsk.core.models_pam_extended import PAM_EXTENDED_FAMILY
except ImportError:  # stripped in public build
    PAM_EXTENDED_FAMILY = "keeper-pam-extended.v1"
from dsk.core.models_policy import KEEPER_POLICY_FAMILY, PolicyManifestV1
from dsk.core.models_privileged_access import PRIVILEGED_ACCESS_FAMILY
from dsk.core.models_saas_rotation import SAAS_ROTATION_FAMILY
from dsk.core.models_siem import SIEM_FAMILY
from dsk.core.models_terraform import TERRAFORM_FAMILY
from dsk.core.models_tunnel import TUNNEL_FAMILY
from dsk.core.models_vault_sharing import (
    SHARING_FAMILY,
    SharingManifestV1,
    load_vault_sharing_manifest,
)
from dsk.core.models_workflow import WORKFLOW_FAMILY
from dsk.core.msp_models import MSP_FAMILY
from dsk.core.normalize import canonicalize
from dsk.core.preview import assert_preview_keys_allowed
from dsk.core.schema import (
    _PAM_MODEL_ONLY_SCHEMA_EXTENSION_KEYS,
    EPM_POLICY_FAMILY,
    JIT_ACCESS_FAMILY,
    PAM_FAMILY,
    ROTATION_POLICY_FAMILY,
    SCIM_FAMILY,
    _strip_pam_model_only_schema_extensions,
    validate_manifest,
)

DEFAULT_MAX_MANIFEST_BYTES = 20 * 1024 * 1024
DEFAULT_MAX_PARSE_DEPTH = 64
_LOG = logging.getLogger(__name__)


def _max_manifest_bytes() -> int:
    raw = os.environ.get("DSK_MAX_MANIFEST_BYTES")
    if raw is None:
        return DEFAULT_MAX_MANIFEST_BYTES
    try:
        value = int(raw)
    except ValueError as exc:
        raise ManifestError(
            reason="DSK_MAX_MANIFEST_BYTES must be an integer",
            next_action="set DSK_MAX_MANIFEST_BYTES to a positive byte count",
        ) from exc
    if value <= 0:
        raise ManifestError(
            reason="DSK_MAX_MANIFEST_BYTES must be greater than 0",
            next_action="set DSK_MAX_MANIFEST_BYTES to a positive byte count",
        )
    return value


def _max_parse_depth() -> int:
    raw = os.environ.get("DSK_MAX_PARSE_DEPTH")
    if raw is None:
        return DEFAULT_MAX_PARSE_DEPTH
    try:
        value = int(raw)
    except ValueError as exc:
        raise ManifestError(
            reason="DSK_MAX_PARSE_DEPTH must be an integer",
            next_action="set DSK_MAX_PARSE_DEPTH to a positive integer",
        ) from exc
    if value <= 0:
        raise ManifestError(
            reason="DSK_MAX_PARSE_DEPTH must be greater than 0",
            next_action="set DSK_MAX_PARSE_DEPTH to a positive integer",
        )
    return value


def _structural_depth(value: Any) -> int:
    if isinstance(value, Mapping):
        if not value:
            return 1
        return 1 + max(_structural_depth(item) for item in value.values())
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        if not value:
            return 1
        return 1 + max(_structural_depth(item) for item in value)
    return 0


def _validate_parse_depth(value: Any) -> None:
    max_depth = _max_parse_depth()
    depth = _structural_depth(value)
    if depth > max_depth:
        _LOG.info(
            "manifest.resource_limit.applied",
            extra={
                "event": "manifest.resource_limit.applied",
                "limit": "DSK_MAX_PARSE_DEPTH",
                "value": max_depth,
                "depth": depth,
            },
        )
        raise ManifestError(
            reason=f"manifest parse depth {depth} exceeds DSK_MAX_PARSE_DEPTH={max_depth}",
            next_action="reduce nesting or raise DSK_MAX_PARSE_DEPTH explicitly",
        )


def _read_manifest_text(path: Path) -> str:
    max_bytes = _max_manifest_bytes()
    try:
        return read_text_limited(
            path,
            max_bytes=max_bytes,
            label="manifest",
            limit_name="DSK_MAX_MANIFEST_BYTES",
        )
    except ResourceLimitError as exc:
        raise ManifestError(
            reason=str(exc),
            next_action="check the path, permissions, or DSK_MAX_MANIFEST_BYTES",
        ) from exc


def _validation_document_for_load(document: dict[str, Any]) -> dict[str, Any]:
    schema = document.get("schema")
    is_legacy_pam = schema is None and document.get("version") == "1"
    if schema == PAM_FAMILY or is_legacy_pam:
        return _strip_pam_model_only_schema_extensions(document)
    return document


if TYPE_CHECKING:
    from dsk.core.models_agent_memory_policy import AgentMemoryPolicyManifest
    from dsk.core.models_agentic_skill_policy import AgenticSkillPolicyManifest
    from dsk.core.models_ai_agent import AiAgentManifest
    from dsk.core.models_enterprise import EnterpriseManifestV1
    from dsk.core.models_epm import EpmManifestV1
    from dsk.core.models_integrations_events import EventsManifestV1
    from dsk.core.models_integrations_identity import IdentityManifestV1
    from dsk.core.models_k8s_eso import K8sEsoManifestV1
    from dsk.core.models_ksm import KsmManifestV1
    from dsk.core.models_mcp_allowlist import McpAllowlistManifest
    from dsk.core.models_nhi import NhiAgentManifest
    from dsk.core.models_pam_extended import PamExtendedManifestV1
    from dsk.core.models_pqc import PqcPolicyManifestV1
    from dsk.core.models_privileged_access import PrivilegedAccessManifestV1
    from dsk.core.models_saas_rotation import SaaSRotationManifestV1
    from dsk.core.models_scim import ScimManifestV1
    from dsk.core.models_siem import SiemManifestV1
    from dsk.core.models_spiffe import SpiffeBindingManifestV1
    from dsk.core.models_terraform import TerraformIntegrationManifestV1
    from dsk.core.models_tunnel import TunnelManifestV1
    from dsk.core.models_workflow import WorkflowManifestV1
    from dsk.core.msp_models import MspManifestV1
    from dsk.core.vault_models import VaultManifestV1


def read_manifest_document(source: str | Path) -> dict[str, Any]:
    """Parse + canonicalise a manifest file without typed-model load.

    Used by ``dsk validate`` for non-PAM families and by tests.
    """
    path = Path(source)
    if not path.is_file():
        raise ManifestError(reason=f"manifest not found: {path}", next_action="check the path")
    raw = _read_manifest_text(path)
    return read_manifest_document_string(raw, suffix=path.suffix)


def read_manifest_document_string(raw: str, *, suffix: str = ".yaml") -> dict[str, Any]:
    data = _parse(raw, suffix)
    if not isinstance(data, dict):
        raise SchemaError(reason="manifest must be a JSON object / YAML mapping")
    return canonicalize(data)


def load_manifest(source: str | Path, *, validate: bool = True) -> Manifest:
    """Load a manifest from a path.

    Supports ``.yaml``, ``.yml``, ``.json``. Always returns a typed Manifest.
    """
    path = Path(source)
    if not path.is_file():
        raise ManifestError(reason=f"manifest not found: {path}", next_action="check the path")

    raw = _read_manifest_text(path)
    return load_manifest_string(raw, suffix=path.suffix, validate=validate)


def load_manifest_string(raw: str, *, suffix: str = ".yaml", validate: bool = True) -> Manifest:
    document = read_manifest_document_string(raw, suffix=suffix)
    if validate:
        family = validate_manifest(_validation_document_for_load(document))
        if family != PAM_FAMILY:
            raise ManifestError(
                reason=(
                    f"typed manifest load supports {PAM_FAMILY} only (document declares {family})"
                ),
                next_action=(
                    "for keeper-vault.v1 use load_declarative_manifest(); "
                    "for schema-only checks use read_manifest_document + validate_manifest; "
                    "see docs/PAM_PARITY_PROGRAM.md for other families."
                ),
            )
        # Schema accepts more than the SDK implements; the preview gate
        # closes that gap at load time with a one-line remediation
        # (DSK_PREVIEW=1) instead of forcing operators to read plan
        # output to find out their manifest is half-declarative.
        assert_preview_keys_allowed(document)
    try:
        return Manifest.model_validate(document)
    except (ValueError, TypeError) as exc:  # pydantic ValidationError subclasses ValueError
        raise SchemaError(
            reason=f"typed validation failed: {exc}",
            next_action="fix the reported fields",
        ) from exc


def load_declarative_manifest(
    source: str | Path, *, validate: bool = True
) -> (
    Manifest
    | VaultManifestV1
    | SharingManifestV1
    | MspManifestV1
    | EnterpriseManifestV1
    | KsmManifestV1
    | IdentityManifestV1
    | EventsManifestV1
    | PamExtendedManifestV1
    | EpmManifestV1
    | TerraformIntegrationManifestV1
    | K8sEsoManifestV1
    | SiemManifestV1
    | NhiAgentManifest
    | AiAgentManifest
    | McpAllowlistManifest
    | AgenticSkillPolicyManifest
    | AgentMemoryPolicyManifest
    | PolicyManifestV1
    | WorkflowManifestV1
    | PrivilegedAccessManifestV1
    | TunnelManifestV1
    | SaaSRotationManifestV1
    | ScimManifestV1
    | Any
):
    """Load a typed manifest for families the engine can plan (PAM + vault/sharing L1 + MSP).

    Returns :class:`~dsk.core.models.Manifest` for ``pam-environment.v1``
    or :class:`~dsk.core.vault_models.VaultManifestV1` for
    ``keeper-vault.v1``, or
    :class:`~dsk.core.models_vault_sharing.VaultSharingManifestV1` for
    ``keeper-vault-sharing.v1``, or
    :class:`~dsk.core.msp_models.MspManifestV1` for
    ``msp-environment.v1``, or
    :class:`~dsk.core.models_ksm.KsmManifestV1` for
    ``keeper-ksm.v1``, or
    :class:`~dsk.core.models_integrations_identity.IdentityManifestV1` for
    ``keeper-integrations-identity.v1``, or
    :class:`~dsk.core.models_integrations_events.EventsManifestV1` for
    ``keeper-integrations-events.v1``, or
    :class:`~dsk.core.models_pam_extended.PamExtendedManifestV1` for
    ``keeper-pam-extended.v1``, or
    :class:`~dsk.core.models_epm.EpmManifestV1` for ``keeper-epm.v1``, or
    :class:`~dsk.core.models_terraform.TerraformIntegrationManifestV1` for
    ``keeper-terraform.v1``, or
    :class:`~dsk.core.models_k8s_eso.K8sEsoManifestV1` for
    ``keeper-k8s-eso.v1``, or
    :class:`~dsk.core.models_siem.SiemManifestV1` for ``keeper-siem.v1``.
    Other schema-valid families raise
    :class:`ManifestError` (use :func:`read_manifest_document` +
    :func:`validate_manifest` for schema-only checks).

    ``keeper-vault.v1`` and ``keeper-vault-sharing.v1`` do not use the PAM
    preview gate.
    """
    path = Path(source)
    if not path.is_file():
        raise ManifestError(reason=f"manifest not found: {path}", next_action="check the path")
    raw = _read_manifest_text(path)
    return load_declarative_manifest_string(raw, suffix=path.suffix, validate=validate)


def load_pqc_manifest(source: str | Path) -> PqcPolicyManifestV1:
    """Convenience wrapper - loads and validates a pqc-policy.v1 manifest."""
    from dsk.core.models_pqc import PqcPolicyManifestV1

    result = load_declarative_manifest(source)
    if not isinstance(result, PqcPolicyManifestV1):
        raise SchemaError(
            reason=f"Expected pqc-policy.v1, got {type(result).__name__}",
            uid_ref=None,
            resource_type="pqc-policy",
            next_action="Set schema: pqc-policy.v1 in your manifest",
        )
    return result


def load_spiffe_manifest(source: str | Path) -> SpiffeBindingManifestV1:
    """Convenience wrapper - loads and validates a spiffe-binding.v1 manifest."""
    from dsk.core.models_spiffe import SpiffeBindingManifestV1

    result = load_declarative_manifest(source)
    if not isinstance(result, SpiffeBindingManifestV1):
        raise SchemaError(
            reason=f"Expected spiffe-binding.v1, got {type(result).__name__}",
            uid_ref=None,
            resource_type="spiffe-binding",
            next_action="Set schema: spiffe-binding.v1 in your manifest",
        )
    return result


def load_declarative_manifest_string(
    raw: str, *, suffix: str = ".yaml", validate: bool = True
) -> (
    Manifest
    | VaultManifestV1
    | SharingManifestV1
    | MspManifestV1
    | EnterpriseManifestV1
    | KsmManifestV1
    | IdentityManifestV1
    | EventsManifestV1
    | PamExtendedManifestV1
    | EpmManifestV1
    | TerraformIntegrationManifestV1
    | K8sEsoManifestV1
    | SiemManifestV1
    | NhiAgentManifest
    | AiAgentManifest
    | McpAllowlistManifest
    | AgenticSkillPolicyManifest
    | AgentMemoryPolicyManifest
    | PolicyManifestV1
    | WorkflowManifestV1
    | PrivilegedAccessManifestV1
    | TunnelManifestV1
    | SaaSRotationManifestV1
    | ScimManifestV1
    | Any
):
    """Like :func:`load_declarative_manifest` but from a string."""
    try:
        from dsk.core.models_ai_agent import (
            load_ai_agent_manifest,  # stripped in public build
        )
    except ImportError:
        load_ai_agent_manifest = None  # type: ignore[assignment]
    from dsk.core.models_epm import load_epm_manifest
    from dsk.core.models_integrations_events import load_events_manifest
    from dsk.core.models_integrations_identity import load_identity_manifest
    from dsk.core.models_k8s_eso import load_k8s_eso_manifest
    from dsk.core.models_ksm import KSM_FAMILY, load_ksm_manifest

    try:
        from dsk.core.models_nhi import load_nhi_manifest  # stripped in public build
    except ImportError:
        load_nhi_manifest = None  # type: ignore[assignment]
    try:
        from dsk.core.models_pam_extended import (
            load_pam_extended_manifest,  # stripped in public build
        )
    except ImportError:
        load_pam_extended_manifest = None  # type: ignore[assignment]
    from dsk.core.models_siem import load_siem_manifest
    from dsk.core.models_terraform import load_terraform_manifest
    from dsk.core.models_tunnel import load_tunnel_manifest
    from dsk.core.msp_models import load_msp_manifest
    from dsk.core.vault_models import VAULT_FAMILY, load_vault_manifest

    document = read_manifest_document_string(raw, suffix=suffix)
    if not validate:
        raise ManifestError(
            reason="load_declarative_manifest_string requires validate=True",
            next_action="parse with read_manifest_document_string then validate_manifest",
        )
    family = validate_manifest(_validation_document_for_load(document))
    if family == PAM_FAMILY:
        assert_preview_keys_allowed(document)
        try:
            return Manifest.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == VAULT_FAMILY:
        return load_vault_manifest(document)
    if family == SHARING_FAMILY:
        return load_vault_sharing_manifest(document)
    if family == MSP_FAMILY:
        return load_msp_manifest(document)
    if family == KSM_FAMILY:
        return load_ksm_manifest(document)
    if family == IDENTITY_FAMILY:
        return load_identity_manifest(document)
    if family == EVENTS_FAMILY:
        return load_events_manifest(document)
    if family == PAM_EXTENDED_FAMILY and load_pam_extended_manifest is not None:
        return load_pam_extended_manifest(document)
    if family == EPM_FAMILY:
        return load_epm_manifest(document)
    if family == TERRAFORM_FAMILY:
        return load_terraform_manifest(document)
    if family == K8S_ESO_FAMILY:
        return load_k8s_eso_manifest(document)
    if family == SIEM_FAMILY:
        return load_siem_manifest(document)
    if family == NHI_FAMILY and load_nhi_manifest is not None:
        return load_nhi_manifest(document)
    if family == AI_AGENT_FAMILY and load_ai_agent_manifest is not None:
        return load_ai_agent_manifest(document)
    if family == MCP_ALLOWLIST_FAMILY:
        return load_mcp_allowlist_manifest(document)
    if family == AGENTIC_SKILL_POLICY_FAMILY:
        return load_agentic_skill_policy_manifest(document)
    if family == AGENT_MEMORY_POLICY_FAMILY:
        return load_agent_memory_policy_manifest(document)
    if family == KEEPER_POLICY_FAMILY:
        from dsk.core.models_policy import load_policy_manifest

        return load_policy_manifest(document)
    if family == TUNNEL_FAMILY:
        return load_tunnel_manifest(document)
    if family == "ai-act-profile.v1":
        from dsk.core.models_ai_act import AiActProfileManifestV1

        try:
            return AiActProfileManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-ai-policy.v1":
        from dsk.core.models_ai_policy import AiPolicyManifestV1

        try:
            return AiPolicyManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "ai-token.v1":
        from dsk.core.models_ai_token import AiTokenManifestV1

        try:
            return AiTokenManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "cmmc-profile.v1":
        from dsk.core.models_cmmc import CmmcProfileManifestV1

        try:
            return CmmcProfileManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "dora-profile.v1":
        from dsk.core.models_dora import DoraProfileManifestV1

        try:
            return DoraProfileManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "pqc-policy.v1":
        from dsk.core.models_pqc import PqcPolicyManifestV1

        try:
            return PqcPolicyManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "itsm-approval-gate.v1":
        from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1

        try:
            return ItsmApprovalGateManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "slack-approval-gate.v1":
        from dsk.core.models_slack_gate import SlackApprovalGateManifestV1

        try:
            return SlackApprovalGateManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "mcp-secrets-binding.v1":
        from dsk.core.models_mcp import McpSecretsBindingManifestV1

        try:
            return McpSecretsBindingManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "spiffe-binding.v1":
        from dsk.core.models_spiffe import SpiffeBindingManifestV1

        try:
            return SpiffeBindingManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "workflow-gate.v1":
        from dsk.core.models_workflow_gate import WorkflowGateManifestV1

        try:
            return WorkflowGateManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "ai-agent-trust-chain.v1":
        from dsk.core.models_trust_chain import TrustChainManifestV1

        try:
            return TrustChainManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "pam-connection-profile.v1":
        from dsk.core.models_connection_profile import PamConnectionProfileManifestV1

        try:
            return PamConnectionProfileManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "db-access-policy.v1":
        from dsk.core.models_db_access import DbAccessPolicyManifestV1

        try:
            return DbAccessPolicyManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "gateway-ha.v1":
        from dsk.core.models_gateway_ha import GatewayHaManifestV1

        try:
            return GatewayHaManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-tunnel.v1":
        from dsk.core.models_tunnel import TunnelManifestV1

        try:
            return TunnelManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "pipeline-ephemeral-environment.v1":
        from dsk.core.models_pipeline_env import PipelineEphemeralManifestV1

        try:
            return PipelineEphemeralManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "cloud-jit.v1":
        from dsk.core.models_cloud_jit import CloudJitManifestV1

        try:
            return CloudJitManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "compliance-bundle.v1":
        from dsk.core.models_compliance import ComplianceBundleManifestV1

        try:
            return ComplianceBundleManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "cspm-remediation.v1":
        from dsk.core.models_cspm import CspmRemediationManifestV1

        try:
            return CspmRemediationManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "continuous-evidence-stream.v1":
        from dsk.core.models_evidence_stream import ContinuousEvidenceStreamManifestV1

        try:
            return ContinuousEvidenceStreamManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "secret-scanner-bridge.v1":
        from dsk.core.models_secret_scanner import SecretScannerBridgeManifestV1

        try:
            return SecretScannerBridgeManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-drive.v1":
        from dsk.core.models_keeper_drive import KeeperDriveManifestV1

        try:
            return KeeperDriveManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-agent-kit.v1":
        from dsk.core.models_agent_kit import AgentKitManifestV1

        try:
            return AgentKitManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "rotation-policy.v1":
        from dsk.core.models_rotation import RotationPolicyManifestV1

        try:
            return RotationPolicyManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "jit-access.v1":
        from dsk.core.models_jit import JitManifestV1

        try:
            return JitManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "epm-policy.v1":
        from dsk.core.models_epm import EpmPolicyManifestV1

        try:
            return EpmPolicyManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-workflow.v1":
        from dsk.core.models_workflow import WorkflowManifestV1

        try:
            return WorkflowManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-scim.v1":
        from dsk.core.models_scim import ScimManifestV1

        try:
            return ScimManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-enterprise.v1":
        from dsk.core.models_enterprise import EnterpriseManifestV1

        try:
            return EnterpriseManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-saas-rotation.v1":
        from dsk.core.models_saas_rotation import SaaSRotationManifestV1

        try:
            return SaaSRotationManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    if family == "keeper-security-posture.v1":
        raise UnsupportedFamilyError(
            reason=(
                "keeper-security-posture.v1 is a dropped-design family. "
                "Posture surface is read-only; use `dsk report` verbs instead "
                "(compliance-report, security-audit-report, password-report, "
                "breachwatch-list, record-totp, enterprise-reports)."
            ),
            next_action=(
                "Replace the manifest with a `dsk report` invocation. "
                "See docs/V2_DECISIONS.md Q3 for details."
            ),
        )

    if family == "keeper-privileged-access.v1":
        from dsk.core.models_privileged_access import PrivilegedAccessManifestV1

        try:
            return PrivilegedAccessManifestV1.model_validate(document)
        except (ValueError, TypeError) as exc:
            raise SchemaError(
                reason=f"typed validation failed: {exc}",
                next_action="fix the reported fields",
            ) from exc
    private_manifest = _load_private_manifest(family, document)
    if private_manifest is not None:
        return private_manifest
    raise UnsupportedFamilyError(
        reason=(
            f"typed plan/load supports {PAM_FAMILY}, {VAULT_FAMILY}, "
            f"{SHARING_FAMILY}, {MSP_FAMILY}, {ENTERPRISE_FAMILY}, "
            f"{KSM_FAMILY}, {IDENTITY_FAMILY}, {EVENTS_FAMILY}, "
            f"{PAM_EXTENDED_FAMILY}, {EPM_FAMILY}, {TERRAFORM_FAMILY}, "
            f"{K8S_ESO_FAMILY}, {SIEM_FAMILY}, {NHI_FAMILY}, and "
            f"{AI_AGENT_FAMILY}, {MCP_ALLOWLIST_FAMILY}, {AGENTIC_SKILL_POLICY_FAMILY}, "
            f"{AGENT_MEMORY_POLICY_FAMILY}, {KEEPER_POLICY_FAMILY}, "
            f"{ROTATION_POLICY_FAMILY}, {EPM_POLICY_FAMILY}, "
            f"{WORKFLOW_FAMILY}, {SAAS_ROTATION_FAMILY}, "
            f"{JIT_ACCESS_FAMILY}, {SCIM_FAMILY}, "
            f"{PRIVILEGED_ACCESS_FAMILY}, and packaged Commander 18.0.0 families only "
            f"(document declares {family!r})"
        ),
        next_action=(
            "use `dsk validate` for schema-only checks on other families; "
            "see docs/PAM_PARITY_PROGRAM.md"
        ),
    )


def _load_private_manifest(family: str, document: dict[str, Any]) -> Any | None:
    try:
        from dsk.core._private_families import load_private_manifest
    except ImportError:
        return None
    return load_private_manifest(family, document)


def dump_manifest(manifest: Manifest, *, fmt: str = "yaml") -> str:
    """Serialize a Manifest back to canonical YAML or JSON.

    Drops ``None`` fields so the output matches the hand-authored style.
    PAM-model-only extension keys (e.g. ``must_not_exist``) that are still at
    their empty-list default are also omitted; the JSON schema does not declare
    them and ``additionalProperties: false`` would cause ``dsk validate`` to
    reject the output.
    """
    data = manifest.model_dump(mode="json", exclude_none=True, by_alias=False)
    # Strip PAM-model-only keys that carry no information (empty-list default).
    # These keys are valid in hand-authored manifests and accepted by the Pydantic
    # model, but the JSON schema does not list them, so we must not emit them when
    # they are empty.
    for key in _PAM_MODEL_ONLY_SCHEMA_EXTENSION_KEYS:
        if data.get(key) == []:
            del data[key]
    if fmt == "json":
        return json.dumps(data, indent=2, sort_keys=False)
    if fmt == "yaml":
        import yaml

        return yaml.safe_dump(data, sort_keys=False, allow_unicode=True)
    raise ValueError(f"unsupported dump format: {fmt}")


def _parse(raw: str, suffix: str) -> Any:
    data: Any
    if suffix.lower() in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError as exc:  # pragma: no cover
            raise ManifestError(
                reason="pyyaml is required to load YAML manifests",
                next_action="`pip install pyyaml`",
            ) from exc
        data = yaml.safe_load(raw)
        _validate_parse_depth(data)
        return data
    if suffix.lower() == ".json":
        data = json.loads(raw)
        _validate_parse_depth(data)
        return data
    # autodetect
    stripped = raw.lstrip()
    if stripped.startswith("{"):
        data = json.loads(raw)
        _validate_parse_depth(data)
        return data
    import yaml

    data = yaml.safe_load(raw)
    _validate_parse_depth(data)
    return data
