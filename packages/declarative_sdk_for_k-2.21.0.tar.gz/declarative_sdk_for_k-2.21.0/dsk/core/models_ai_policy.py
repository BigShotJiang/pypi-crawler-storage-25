"""AI session policy models — keeper-ai-policy.v1.

Declares AI-powered session monitoring policies for PAM sessions.
Controls anomaly detection sensitivity, alert thresholds, and automated responses.

NOTE: Preview capability. Apply path pending platform GA.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class AnomalySensitivity(StrEnum):
    low = "low"  # alert only on high-confidence anomalies
    medium = "medium"  # balanced (default)
    high = "high"  # alert on any suspicious signal


class SessionAction(StrEnum):
    alert = "alert"  # send alert only
    terminate = "terminate"  # terminate session immediately
    record = "record"  # ensure session is recorded (even if not default)
    notify_approver = "notify_approver"  # ping session approver


class AnomalyRule(BaseModel):
    name: str
    description: str | None = None
    pattern: str = Field(
        ...,
        description="Anomaly pattern type: 'unusual_hour', 'high_command_rate', "
        "'sensitive_data_access', 'geo_anomaly', 'credential_stuffing'",
    )
    sensitivity: AnomalySensitivity = AnomalySensitivity.medium
    actions: list[SessionAction] = Field(default_factory=lambda: [SessionAction.alert])
    cooldown_minutes: int = Field(
        15,
        ge=0,
        description="Minutes before re-alerting on same pattern (0 = no cooldown)",
    )


class AiSessionPolicy(BaseModel):
    name: str
    description: str | None = None
    applies_to_pam_config_uid_refs: list[str] = Field(
        default_factory=list,
        description="uid_refs of pam_configurations this policy monitors. Empty = all.",
    )
    recording_required: bool = Field(
        True,
        description="Require session recording for all sessions under this policy",
    )
    anomaly_rules: list[AnomalyRule] = Field(default_factory=list)
    baseline_window_days: int = Field(
        30,
        ge=7,
        description="Days of session history used to build behavioral baseline",
    )
    audit_log: bool = Field(True)


class AiPolicyManifestV1(BaseModel):
    """Root model for a keeper-ai-policy.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("keeper-ai-policy.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    policies: list[AiSessionPolicy] = Field(default_factory=list)


AI_POLICY_FAMILY: str = "keeper-ai-policy.v1"
