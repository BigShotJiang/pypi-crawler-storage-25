"""Shared helpers for bounded external input parsing."""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any


class ResourceLimitError(ValueError):
    """Raised when external input exceeds a configured resource limit."""


def positive_int_env(name: str, default: int) -> int:
    """Return a positive integer from ``name`` or ``default``.

    Raises ``ResourceLimitError`` on invalid configuration so callers can
    convert it into their own CLI or integration error type.
    """
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ResourceLimitError(f"{name} must be an integer") from exc
    if value <= 0:
        raise ResourceLimitError(f"{name} must be greater than 0")
    return value


def payload_size_bytes(value: str | bytes | bytearray) -> int:
    """Return UTF-8 byte length for text or raw byte length for bytes."""
    if isinstance(value, str):
        return len(value.encode("utf-8"))
    return len(value)


def ensure_payload_within_limit(
    value: str | bytes | bytearray,
    *,
    max_bytes: int,
    label: str,
    limit_name: str,
) -> None:
    """Reject an in-memory payload above ``max_bytes``.

    Used immediately before JSON/YAML parsing or response decoding when
    the surrounding API has already delivered a complete payload.
    """
    size = payload_size_bytes(value)
    if size > max_bytes:
        raise ResourceLimitError(f"{label} is {size} bytes, exceeding {limit_name}={max_bytes}")


def read_text_limited(
    path: Path,
    *,
    max_bytes: int,
    label: str,
    limit_name: str,
    encoding: str = "utf-8",
) -> str:
    """Read a text file through an open descriptor under a byte cap."""
    return read_bytes_limited(
        path,
        max_bytes=max_bytes,
        label=label,
        limit_name=limit_name,
    ).decode(encoding)


def read_bytes_limited(
    path: Path,
    *,
    max_bytes: int,
    label: str,
    limit_name: str,
) -> bytes:
    """Read a binary file through an open descriptor under a byte cap."""
    try:
        fh = path.open("rb")
    except OSError as exc:
        raise ResourceLimitError(f"{label} unreadable: {type(exc).__name__}") from exc

    with fh:
        try:
            size = os.fstat(fh.fileno()).st_size
        except OSError as exc:
            raise ResourceLimitError(f"{label} unreadable: {type(exc).__name__}") from exc
        if size > max_bytes:
            raise ResourceLimitError(f"{label} is {size} bytes, exceeding {limit_name}={max_bytes}")
        try:
            data = fh.read(max_bytes + 1)
        except OSError as exc:
            raise ResourceLimitError(f"{label} unreadable: {type(exc).__name__}") from exc
    if len(data) > max_bytes:
        raise ResourceLimitError(f"{label} exceeds {limit_name}={max_bytes}")
    return data


def structural_depth(value: Any) -> int:
    """Return nesting depth for JSON-like mappings and sequences."""
    if isinstance(value, Mapping):
        if not value:
            return 1
        return 1 + max(structural_depth(item) for item in value.values())
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        if not value:
            return 1
        return 1 + max(structural_depth(item) for item in value)
    return 0


def validate_structural_depth(
    value: Any,
    *,
    max_depth: int,
    label: str,
    limit_name: str,
) -> None:
    """Reject JSON-like values nested deeper than ``max_depth``."""
    depth = structural_depth(value)
    if depth > max_depth:
        raise ResourceLimitError(f"{label} depth {depth} exceeds {limit_name}={max_depth}")


def json_loads_limited(
    raw: str | bytes | bytearray,
    *,
    max_bytes: int,
    max_depth: int,
    label: str,
    byte_limit_name: str,
    depth_limit_name: str,
) -> Any:
    """Parse JSON after byte and structural-depth checks."""
    ensure_payload_within_limit(
        raw,
        max_bytes=max_bytes,
        label=label,
        limit_name=byte_limit_name,
    )
    parsed = json.loads(raw)
    validate_structural_depth(
        parsed,
        max_depth=max_depth,
        label=label,
        limit_name=depth_limit_name,
    )
    return parsed


def yaml_loads_limited(
    raw: str | bytes | bytearray,
    *,
    max_bytes: int,
    max_depth: int,
    label: str,
    byte_limit_name: str,
    depth_limit_name: str,
) -> Any:
    """Parse YAML after byte and structural-depth checks."""
    import yaml

    ensure_payload_within_limit(
        raw,
        max_bytes=max_bytes,
        label=label,
        limit_name=byte_limit_name,
    )
    yaml_raw: str | bytes = bytes(raw) if isinstance(raw, bytearray) else raw
    parsed = yaml.safe_load(yaml_raw)
    validate_structural_depth(
        parsed,
        max_depth=max_depth,
        label=label,
        limit_name=depth_limit_name,
    )
    return parsed


def read_json_file_limited(
    path: Path,
    *,
    max_bytes: int,
    max_depth: int,
    label: str,
    byte_limit_name: str,
    depth_limit_name: str,
    encoding: str = "utf-8",
) -> Any:
    """Read and parse a JSON file under byte and depth caps."""
    raw = read_text_limited(
        path,
        max_bytes=max_bytes,
        label=label,
        limit_name=byte_limit_name,
        encoding=encoding,
    )
    return json_loads_limited(
        raw,
        max_bytes=max_bytes,
        max_depth=max_depth,
        label=label,
        byte_limit_name=byte_limit_name,
        depth_limit_name=depth_limit_name,
    )


def read_yaml_file_limited(
    path: Path,
    *,
    max_bytes: int,
    max_depth: int,
    label: str,
    byte_limit_name: str,
    depth_limit_name: str,
    encoding: str = "utf-8",
) -> Any:
    """Read and parse a YAML file under byte and depth caps."""
    raw = read_text_limited(
        path,
        max_bytes=max_bytes,
        label=label,
        limit_name=byte_limit_name,
        encoding=encoding,
    )
    return yaml_loads_limited(
        raw,
        max_bytes=max_bytes,
        max_depth=max_depth,
        label=label,
        byte_limit_name=byte_limit_name,
        depth_limit_name=depth_limit_name,
    )
