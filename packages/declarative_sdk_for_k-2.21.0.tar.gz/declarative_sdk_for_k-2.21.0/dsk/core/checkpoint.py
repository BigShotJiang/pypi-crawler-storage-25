"""
Partial-apply checkpoint for DSK.

When `dsk apply` processes multiple resources sequentially, it writes a
checkpoint file after each successful resource. If apply fails mid-run,
the next run reads the checkpoint and skips already-applied resources.

Checkpoint file: <manifest_path>.dsk-checkpoint (JSON, alongside manifest)
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

from dsk.core.resource_limits import ResourceLimitError, positive_int_env, read_json_file_limited

_DEFAULT_CHECKPOINT_MAX_BYTES = 1 * 1024 * 1024
_DEFAULT_CHECKPOINT_MAX_DEPTH = 32


def _checkpoint_max_bytes() -> int:
    return positive_int_env("DSK_CHECKPOINT_MAX_BYTES", _DEFAULT_CHECKPOINT_MAX_BYTES)


def _checkpoint_max_depth() -> int:
    return positive_int_env("DSK_CHECKPOINT_MAX_DEPTH", _DEFAULT_CHECKPOINT_MAX_DEPTH)


@dataclass
class CheckpointEntry:
    uid_ref: str
    applied_at: float
    kind: str  # create | update | delete | noop


@dataclass
class ApplyCheckpoint:
    manifest_path: str
    manifest_hash: str
    started_at: float
    entries: list[CheckpointEntry] = field(default_factory=list)

    @property
    def _path(self) -> Path:
        return Path(self.manifest_path + ".dsk-checkpoint")

    def mark_applied(self, uid_ref: str, kind: str) -> None:
        """Record that uid_ref was successfully applied."""
        self.entries.append(
            CheckpointEntry(
                uid_ref=uid_ref,
                applied_at=time.time(),
                kind=kind,
            )
        )
        self._save()

    def is_applied(self, uid_ref: str) -> bool:
        """True if uid_ref was already applied in a previous interrupted run."""
        return any(e.uid_ref == uid_ref for e in self.entries)

    def clear(self) -> None:
        """Remove checkpoint on successful completion."""
        self._path.unlink(missing_ok=True)

    def _save(self) -> None:
        data = {
            "manifest_path": self.manifest_path,
            "manifest_hash": self.manifest_hash,
            "started_at": self.started_at,
            "entries": [
                {"uid_ref": e.uid_ref, "applied_at": e.applied_at, "kind": e.kind}
                for e in self.entries
            ],
        }
        self._path.write_text(json.dumps(data, indent=2))

    @classmethod
    def load_or_create(cls, manifest_path: str, manifest_hash: str) -> ApplyCheckpoint:
        """Load existing checkpoint or create a fresh one."""
        path = Path(manifest_path + ".dsk-checkpoint")
        if path.exists():
            try:
                data = read_json_file_limited(
                    path,
                    max_bytes=_checkpoint_max_bytes(),
                    max_depth=_checkpoint_max_depth(),
                    label="apply checkpoint",
                    byte_limit_name="DSK_CHECKPOINT_MAX_BYTES",
                    depth_limit_name="DSK_CHECKPOINT_MAX_DEPTH",
                )
                if data.get("manifest_hash") == manifest_hash:
                    entries = [
                        CheckpointEntry(
                            uid_ref=e["uid_ref"],
                            applied_at=e["applied_at"],
                            kind=e["kind"],
                        )
                        for e in data.get("entries", [])
                    ]
                    cp = cls(
                        manifest_path=manifest_path,
                        manifest_hash=manifest_hash,
                        started_at=data["started_at"],
                        entries=entries,
                    )
                    return cp
            except (KeyError, ValueError, json.JSONDecodeError, ResourceLimitError):
                pass  # corrupt checkpoint — start fresh
        return cls(
            manifest_path=manifest_path,
            manifest_hash=manifest_hash,
            started_at=time.time(),
        )
