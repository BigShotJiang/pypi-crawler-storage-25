"""Offline diff for ``keeper-scim.v1`` manifests."""

from __future__ import annotations

from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.models_scim import ScimManifestV1


def scim_apply_order(manifest: ScimManifestV1) -> list[str]:
    """Deterministic apply order: nodes, roles, teams, users, then SCIM pushes."""
    order: list[str] = []
    for node in manifest.nodes:
        order.append(node.uid_ref)
    for role in manifest.roles:
        order.append(role.uid_ref)
    for team in manifest.teams:
        order.append(team.uid_ref)
    for user in manifest.users:
        order.append(user.uid_ref)
    for ep in manifest.endpoints:
        order.append(ep.uid_ref or f"scim.push:{ep.node_id}")
    return order


def compute_scim_diff(
    manifest: ScimManifestV1,
    live: dict[str, Any] | None = None,
    *,
    manifest_name: str | None = None,
    allow_delete: bool = False,
) -> list[Change]:
    """Declare desired SCIM objects vs offline live (default: empty → all creates)."""
    _ = live  # reserved for future enterprise readback
    _ = allow_delete
    manifest_name = manifest_name or manifest.name
    changes: list[Change] = []
    for node in manifest.nodes:
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=node.uid_ref,
                resource_type="scim_node",
                title=node.name,
                before={},
                after=node.model_dump(mode="json", exclude_none=True),
                manifest_name=manifest_name,
            )
        )
    for role in manifest.roles:
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=role.uid_ref,
                resource_type="scim_role",
                title=role.name,
                before={},
                after=role.model_dump(mode="json", exclude_none=True),
                manifest_name=manifest_name,
            )
        )
    for team in manifest.teams:
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=team.uid_ref,
                resource_type="scim_team",
                title=team.name,
                before={},
                after=team.model_dump(mode="json", exclude_none=True),
                manifest_name=manifest_name,
            )
        )
    for user in manifest.users:
        display = user.display_name or user.email
        changes.append(
            Change(
                kind=ChangeKind.CREATE,
                uid_ref=user.uid_ref,
                resource_type="scim_user",
                title=display,
                before={},
                after=user.model_dump(mode="json", exclude_none=True),
                manifest_name=manifest_name,
            )
        )
    for ep in manifest.endpoints:
        uid = ep.uid_ref or f"scim.push:{ep.node_id}"
        changes.append(
            Change(
                kind=ChangeKind.UPDATE,
                uid_ref=uid,
                resource_type="scim_push",
                title=f"scim push {ep.node_id}",
                before={},
                after=ep.model_dump(mode="json", exclude_none=True),
                manifest_name=manifest_name,
            )
        )
    return changes
