"""Slack approval gate models — slack-approval-gate.v1.

Declares Slack-based human approval requirements for DSK apply operations.
Integrates with Keeper Slack App (GA Feb 4, 2026) and DSK GitOps sync hook.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class SlackApprovalMode(StrEnum):
    any_approver = "any_approver"  # first responder wins
    all_approvers = "all_approvers"  # unanimous approval required
    majority = "majority"  # simple majority


class SlackEscalationAction(StrEnum):
    block = "block"  # block apply if timeout
    auto_approve = "auto_approve"  # approve after timeout (low-risk)
    auto_reject = "auto_reject"  # reject after timeout (high-risk)


class SlackApprover(BaseModel):
    slack_user_id: str | None = None
    slack_group_id: str | None = None  # Slack user group
    keeper_uid_ref: str | None = None  # map to a Keeper user record


class SlackApprovalGate(BaseModel):
    name: str
    channel: str = Field(..., description="Slack channel ID, e.g. C01234567")
    message_template: str | None = Field(
        None,
        description="Jinja2 template for the approval request message",
    )
    approvers: list[SlackApprover] = Field(default_factory=list)
    mode: SlackApprovalMode = SlackApprovalMode.any_approver
    timeout_minutes: int = Field(30, ge=1, le=10080)
    on_timeout: SlackEscalationAction = SlackEscalationAction.block
    require_reason: bool = False


class SlackApprovalGateManifestV1(BaseModel):
    """Root model for a slack-approval-gate.v1 manifest."""

    model_config = ConfigDict(populate_by_name=True)

    schema_: str = Field("slack-approval-gate.v1", alias="schema")
    name: str
    version: str = "1"
    manager: str = "dsk"
    slack_workspace_id: str | None = None
    gates: list[SlackApprovalGate] = Field(default_factory=list)
    default_gate: str | None = Field(
        None,
        description="Name of gate to apply when no specific gate matches",
    )
