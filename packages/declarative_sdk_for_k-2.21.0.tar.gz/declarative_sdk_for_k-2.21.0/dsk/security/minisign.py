"""Pure-Python minisign verifier for keeperCMD SHA256SUMS manifests."""

from __future__ import annotations

import base64
import binascii
import hashlib
from dataclasses import dataclass
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from dsk.core.resource_limits import (
    ResourceLimitError,
    positive_int_env,
    read_bytes_limited,
    read_text_limited,
)

_COMMENT_PREFIX = "untrusted comment: "
_TRUSTED_PREFIX = "trusted comment: "
DEFAULT_MAX_SHA256SUMS_BYTES = 100 * 1024 * 1024
DEFAULT_MAX_MINISIG_BYTES = 16 * 1024


@dataclass(frozen=True)
class MinisignVerificationResult:
    verified: bool
    key_identifier: str
    key_id: str
    trusted_comment: str


class MinisignVerificationError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        self.code = code
        super().__init__(message)


def _max_sha256sums_bytes() -> int:
    try:
        return positive_int_env("DSK_MINISIGN_MAX_SHA256SUMS_BYTES", DEFAULT_MAX_SHA256SUMS_BYTES)
    except ResourceLimitError as exc:
        raise MinisignVerificationError("resource_limit", str(exc)) from exc


def _max_minisig_bytes() -> int:
    try:
        return positive_int_env("DSK_MINISIGN_MAX_MINISIG_BYTES", DEFAULT_MAX_MINISIG_BYTES)
    except ResourceLimitError as exc:
        code = "missing_sha256sums" if "unreadable" in str(exc) else "resource_limit"
        raise MinisignVerificationError(code, str(exc)) from exc


def _decode_b64(value: str, expected_len: int, label: str) -> bytes:
    expected_chars = ((expected_len + 2) // 3) * 4
    if len(value.strip()) > expected_chars:
        raise MinisignVerificationError(
            "malformed_signature", f"{label} is too large for {expected_len} bytes"
        )
    try:
        raw = base64.b64decode(value.encode("ascii"), validate=True)
    except (UnicodeEncodeError, binascii.Error) as exc:
        raise MinisignVerificationError("malformed_signature", f"{label} is not base64") from exc
    if len(raw) != expected_len:
        raise MinisignVerificationError(
            "malformed_signature", f"{label} is {len(raw)} bytes, expected {expected_len}"
        )
    return raw


def _public_key(public_key: str) -> tuple[bytes, Ed25519PublicKey]:
    lines = [line.strip() for line in public_key.splitlines() if line.strip()]
    if not lines:
        raise MinisignVerificationError("missing_public_key", "minisign public key is empty")
    payload = lines[1] if lines[0].startswith(_COMMENT_PREFIX) and len(lines) >= 2 else lines[0]
    raw = _decode_b64(payload, 42, "public key")
    if raw[:2] != b"Ed":
        raise MinisignVerificationError("unsupported_public_key", "public key magic must be Ed")
    return raw[2:10], Ed25519PublicKey.from_public_bytes(raw[10:])


def _signature(sidecar_text: str) -> tuple[str, bytes, bytes, bytes, str]:
    lines = sidecar_text.splitlines()
    if len(lines) != 4:
        raise MinisignVerificationError("malformed_signature", "minisign sidecar needs 4 lines")
    if not lines[0].startswith(_COMMENT_PREFIX):
        raise MinisignVerificationError("missing_untrusted_comment", "missing untrusted comment")
    key_identifier = lines[0][len(_COMMENT_PREFIX) :].strip()
    if not key_identifier:
        raise MinisignVerificationError("missing_untrusted_comment", "empty untrusted comment")
    if not lines[2].startswith(_TRUSTED_PREFIX):
        raise MinisignVerificationError("malformed_signature", "missing trusted comment")
    sig_struct = _decode_b64(lines[1].strip(), 74, "signature")
    if sig_struct[:2] != b"ED":
        raise MinisignVerificationError("unsupported_signature", "only ED signatures are supported")
    return (
        key_identifier,
        sig_struct[2:10],
        sig_struct[10:],
        _decode_b64(lines[3].strip(), 64, "trusted comment signature"),
        lines[2][len(_TRUSTED_PREFIX) :],
    )


def verify_minisign(
    message: bytes,
    sidecar_text: str,
    public_key: str,
) -> MinisignVerificationResult:
    pub_key_id, verifier = _public_key(public_key)
    key_identifier, sig_key_id, signature, global_sig, trusted_comment = _signature(sidecar_text)
    if sig_key_id != pub_key_id:
        raise MinisignVerificationError("key_id_mismatch", "signature key id mismatch")
    try:
        verifier.verify(signature, hashlib.blake2b(message, digest_size=64).digest())
    except InvalidSignature as exc:
        raise MinisignVerificationError(
            "signature_failed", "signature verification failed"
        ) from exc
    try:
        verifier.verify(global_sig, signature + trusted_comment.encode("utf-8"))
    except InvalidSignature as exc:
        raise MinisignVerificationError(
            "comment_signature_failed", "trusted comment signature failed"
        ) from exc
    return MinisignVerificationResult(True, key_identifier, sig_key_id.hex(), trusted_comment)


def verify_sha256sums_signature(run_dir: Path, public_key: str) -> MinisignVerificationResult:
    try:
        message = read_bytes_limited(
            run_dir / "SHA256SUMS.txt",
            max_bytes=_max_sha256sums_bytes(),
            label="SHA256SUMS.txt",
            limit_name="DSK_MINISIGN_MAX_SHA256SUMS_BYTES",
        )
    except ResourceLimitError as exc:
        raise MinisignVerificationError("resource_limit", str(exc)) from exc
    try:
        sidecar_text = read_text_limited(
            run_dir / "SHA256SUMS.txt.minisig",
            max_bytes=_max_minisig_bytes(),
            label="SHA256SUMS.txt.minisig",
            limit_name="DSK_MINISIGN_MAX_MINISIG_BYTES",
        )
    except ResourceLimitError as exc:
        code = "missing_sha256sums" if "SHA256SUMS.txt unreadable" in str(exc) else "resource_limit"
        if "SHA256SUMS.txt.minisig unreadable" in str(exc):
            code = "missing_signature"
        raise MinisignVerificationError(code, str(exc)) from exc
    except UnicodeDecodeError as exc:
        raise MinisignVerificationError("malformed_signature", "sidecar is not UTF-8") from exc
    return verify_minisign(message, sidecar_text, public_key)
