"""Keeper-backed minisign public-key lookup helpers."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from dsk.core.field_names import field_name_matches

MINISIGN_PUBKEY_FIELD = "minisign_pubkey"
_FIELD_ALIASES = (MINISIGN_PUBKEY_FIELD, "minisign public key", "minisignPubkey")


class KeeperPubkeyError(RuntimeError):
    """Base error for Keeper minisign public-key lookup failures."""


class KeeperSessionRequired(KeeperPubkeyError):
    """Raised when a Keeper record lookup is requested without a session."""


class KeeperRecordNotFound(KeeperPubkeyError):
    """Raised when the requested Keeper record is not visible."""


class KeeperPubkeyFieldNotFound(KeeperPubkeyError):
    """Raised when the record lacks the canonical minisign public-key field."""


def _string_value(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray, str)):
        for item in value:
            if isinstance(item, str) and item.strip():
                return item.strip()
    return None


def _record_mapping(record: Any) -> Mapping[str, Any]:
    if isinstance(record, Mapping):
        return record
    data = getattr(record, "dict", None)
    return data if isinstance(data, Mapping) else {}


def _fetch_record(record_uid: str, keeper_session: Any) -> Any:
    get_record = getattr(keeper_session, "get_record", None)
    if callable(get_record):
        return get_record(record_uid)
    if isinstance(keeper_session, Mapping):
        return keeper_session.get(record_uid)
    cache = getattr(keeper_session, "record_cache", None)
    return cache.get(record_uid) if isinstance(cache, Mapping) else None


def _extract_pubkey(record: Any) -> str | None:
    field_method = getattr(record, "field", None)
    if callable(field_method):
        for name in _FIELD_ALIASES:
            try:
                value = field_method(name, single=True)
            except Exception:  # noqa: BLE001 - SDK record adapters raise varied lookup errors.
                continue
            if found := _string_value(value):
                return found

    data = _record_mapping(record)
    for key, value in data.items():
        if any(field_name_matches(key, name) for name in _FIELD_ALIASES):
            if found := _string_value(value):
                return found
    for block_name in ("fields", "custom"):
        for entry in data.get(block_name, []) or []:
            if not isinstance(entry, Mapping):
                continue
            if any(
                field_name_matches(entry.get("type"), name)
                or field_name_matches(entry.get("label"), name)
                for name in _FIELD_ALIASES
            ) and (found := _string_value(entry.get("value"))):
                return found
    return None


def fetch_minisign_pubkey_from_keeper(record_uid: str, keeper_session: Any) -> str:
    """Fetch the minisign public key stored on a Keeper record."""
    if keeper_session is None:
        raise KeeperSessionRequired(
            "--signature-pubkey-keeper-record requires active Keeper session; "
            "use --signature-pubkey FILE for offline mode"
        )
    record = _fetch_record(record_uid, keeper_session)
    if record is None:
        raise KeeperRecordNotFound(f"Keeper record {record_uid!r} not found")
    pubkey = _extract_pubkey(record)
    if pubkey is None:
        raise KeeperPubkeyFieldNotFound(
            f"Keeper record {record_uid!r} has no {MINISIGN_PUBKEY_FIELD!r} field"
        )
    return pubkey
