"""CSPM remediation bridge — HTTP webhook receiver for CSPM finding payloads.

Ingests Wiz / Orca / Lacework webhooks, matches findings to remediation rules,
and generates DSK manifest stubs or GitHub PRs for remediation.
"""

from __future__ import annotations

import hashlib
import hmac
from typing import Any


class CspmFinding:
    """Normalized CSPM finding from any source."""

    def __init__(
        self,
        finding_type: str,
        severity: str,
        resource_id: str,
        description: str,
        raw: dict[str, Any],
    ) -> None:
        self.finding_type = finding_type
        self.severity = severity
        self.resource_id = resource_id
        self.description = description
        self.raw = raw


def _normalize_wiz(payload: dict[str, Any]) -> list[CspmFinding]:
    """Parse Wiz webhook payload into normalized findings."""
    findings: list[CspmFinding] = []
    for issue in payload.get("issues", []):
        if not isinstance(issue, dict):
            continue
        resource = issue.get("resource") or {}
        res_id = resource.get("id", "") if isinstance(resource, dict) else ""
        sev_raw = issue.get("severity", "medium")
        sev = str(sev_raw).lower() if sev_raw is not None else "medium"
        findings.append(
            CspmFinding(
                finding_type=str(issue.get("type", "UNKNOWN")),
                severity=sev,
                resource_id=str(res_id),
                description=str(issue.get("title", "")),
                raw=issue,
            )
        )
    return findings


def _normalize_orca(payload: dict[str, Any]) -> list[CspmFinding]:
    """Parse Orca webhook payload."""
    findings: list[CspmFinding] = []
    for alert in payload.get("alerts", []):
        if not isinstance(alert, dict):
            continue
        sev_raw = alert.get("severity_level", "medium")
        sev = str(sev_raw).lower() if sev_raw is not None else "medium"
        findings.append(
            CspmFinding(
                finding_type=str(alert.get("category", "UNKNOWN")),
                severity=sev,
                resource_id=str(alert.get("asset_unique_id", "")),
                description=str(alert.get("description", "")),
                raw=alert,
            )
        )
    return findings


def _normalize_generic(payload: dict[str, Any]) -> list[CspmFinding]:
    """Parse generic webhook (must have finding_type, severity, resource_id)."""
    if "finding_type" in payload:
        sev_raw = payload.get("severity", "medium")
        sev = str(sev_raw).lower() if sev_raw is not None else "medium"
        return [
            CspmFinding(
                finding_type=str(payload["finding_type"]),
                severity=sev,
                resource_id=str(payload.get("resource_id", "")),
                description=str(payload.get("description", "")),
                raw=dict(payload),
            )
        ]
    return []


def normalize_payload(payload: dict[str, Any], source: str = "generic") -> list[CspmFinding]:
    """Route payload to source-specific normalizer."""
    if source == "wiz":
        return _normalize_wiz(payload)
    if source == "orca":
        return _normalize_orca(payload)
    return _normalize_generic(payload)


def verify_hmac(body: bytes, signature: str, secret: str) -> bool:
    """Verify HMAC-SHA256 webhook signature."""
    expected = hmac.new(secret.encode("utf-8"), body, digestmod=hashlib.sha256).hexdigest()
    prefixed = signature if signature.startswith("sha256=") else f"sha256={signature}"
    return hmac.compare_digest(f"sha256={expected}", prefixed)


def _resource_uid_suffix(resource_id: str, max_len: int = 32) -> str:
    slug = resource_id.lower().replace("/", "-").strip("-") or "unknown"
    return slug[:max_len]


def generate_remediation_stub(finding: CspmFinding, action: str) -> dict[str, Any]:
    """Generate a minimal DSK manifest stub for a CSPM finding."""
    suffix = _resource_uid_suffix(finding.resource_id)
    return {
        "schema": "pam-environment.v1",
        "name": f"cspm-remediation-{suffix[:8]}",
        "version": "1",
        "# CSPM finding": finding.finding_type,
        "# Resource": finding.resource_id,
        "# Severity": finding.severity,
        "# Suggested action": action,
        "# next_action": "Review and apply this manifest to remediate the finding.",
        "resources": [
            {
                "uid_ref": f"discovered.{suffix}",
                "title": finding.description[:60],
                "# keeper_uid_hint": "fill in after dsk discover",
            }
        ],
    }
