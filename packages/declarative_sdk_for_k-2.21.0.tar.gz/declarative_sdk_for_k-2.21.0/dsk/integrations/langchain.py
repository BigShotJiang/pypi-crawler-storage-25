"""LangChain tool wrappers for the DSK declarative PAM SDK."""

from __future__ import annotations

import json
import os
import subprocess
from typing import Any

_DSK_SUBPROCESS_TIMEOUT_SECONDS = 120

try:
    from langchain.tools import BaseTool
    from pydantic import BaseModel, Field

    _LANGCHAIN_AVAILABLE = True
except ImportError:
    _LANGCHAIN_AVAILABLE = False
    BaseTool = object
    BaseModel = object  # type: ignore[assignment,misc]

    def Field(*args: Any, **kwargs: Any) -> Any:  # type: ignore[no-redef]
        return None


def _require_langchain() -> None:
    if not _LANGCHAIN_AVAILABLE:
        raise ImportError("langchain is not installed. Run: pip install langchain langchain-core")


class _DskRunInput(BaseModel):
    manifest_path: str = Field(description="Path to DSK manifest YAML/JSON file")


class DskValidateTool(BaseTool):
    """Validate a DSK manifest (schema + references, offline)."""

    name: str = "dsk_validate"
    description: str = (
        "Validate a Keeper DSK manifest for schema correctness and reference integrity. "
        "Returns 'ok' or error details. Does not require Keeper credentials. "
        "Use before plan or apply."
    )
    args_schema: type[BaseModel] = _DskRunInput

    def _run(self, manifest_path: str) -> str:
        _require_langchain()
        try:
            result = subprocess.run(
                ["dsk", "validate", manifest_path],
                capture_output=True,
                text=True,
                timeout=_DSK_SUBPROCESS_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return f"INVALID: dsk validate timed out after {_DSK_SUBPROCESS_TIMEOUT_SECONDS}s"
        if result.returncode == 0:
            return f"VALID: {result.stdout.strip()}"
        return (
            f"INVALID (exit {result.returncode}): {result.stderr.strip() or result.stdout.strip()}"
        )

    async def _arun(self, manifest_path: str) -> str:
        return self._run(manifest_path)


class DskPlanTool(BaseTool):
    """Compute a plan (diff) for a DSK manifest against the live Keeper tenant."""

    name: str = "dsk_plan"
    description: str = (
        "Compute a declarative plan showing what changes DSK would make to the Keeper tenant. "
        "Returns JSON with create/update/delete/conflict/noop counts and per-resource change details. "
        "Exit 0 = no changes. Exit 2 = changes present (not an error). "
        "Requires KEEPER_EMAIL, KEEPER_PASSWORD, KEEPER_TOTP_SECRET env vars for live runs."
    )
    args_schema: type[BaseModel] = _DskRunInput

    def _run(self, manifest_path: str) -> str:
        _require_langchain()
        try:
            result = subprocess.run(
                ["dsk", "plan", manifest_path, "--json"],
                capture_output=True,
                text=True,
                env={**os.environ},
                timeout=_DSK_SUBPROCESS_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return f"PLAN ERROR: dsk plan timed out after {_DSK_SUBPROCESS_TIMEOUT_SECONDS}s"
        if result.returncode in (0, 2):
            try:
                data = json.loads(result.stdout)
                summary = data.get("summary", {})
                return (
                    f"PLAN OK (exit {result.returncode}): "
                    f"create={summary.get('create', 0)} "
                    f"update={summary.get('update', 0)} "
                    f"delete={summary.get('delete', 0)} "
                    f"conflict={summary.get('conflict', 0)} "
                    f"noop={summary.get('noop', 0)}"
                )
            except (json.JSONDecodeError, ValueError):
                return result.stdout.strip()
        return f"PLAN ERROR (exit {result.returncode}): {result.stderr.strip()}"

    async def _arun(self, manifest_path: str) -> str:
        return self._run(manifest_path)


class _DskApplyInput(BaseModel):
    manifest_path: str = Field(description="Path to DSK manifest YAML/JSON file")
    dry_run: bool = Field(default=True, description="If True, simulate apply without changes")


class DskApplyTool(BaseTool):
    """Apply a DSK manifest to the live Keeper tenant."""

    name: str = "dsk_apply"
    description: str = (
        "Apply a DSK manifest to the live Keeper tenant (create/update resources). "
        "ALWAYS validate and plan first. Set dry_run=True for a simulation. "
        "Requires KEEPER_EMAIL, KEEPER_PASSWORD, KEEPER_TOTP_SECRET env vars."
    )
    args_schema: type[BaseModel] = _DskApplyInput

    def _run(self, manifest_path: str, dry_run: bool = True) -> str:
        _require_langchain()
        cmd = ["dsk", "apply", manifest_path, "--auto-approve"]
        if dry_run:
            cmd.append("--dry-run")
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                env={**os.environ},
                timeout=_DSK_SUBPROCESS_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return f"APPLY ERROR: dsk apply timed out after {_DSK_SUBPROCESS_TIMEOUT_SECONDS}s"
        if result.returncode == 0:
            return f"APPLIED (exit 0): {result.stdout.strip()}"
        return f"APPLY ERROR (exit {result.returncode}): {result.stderr.strip()}"

    async def _arun(self, manifest_path: str, dry_run: bool = True) -> str:
        return self._run(manifest_path, dry_run)


def get_dsk_tools() -> list[BaseTool]:
    """Return all DSK LangChain tools. Import langchain first."""
    _require_langchain()
    return [DskValidateTool(), DskPlanTool(), DskApplyTool()]
