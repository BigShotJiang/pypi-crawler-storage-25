"""
External Secrets Operator (ESO) webhook bridge for DSK.

Exposes an HTTP endpoint that ESO's Webhook provider calls to resolve
DSK uid_refs to Keeper secret values.

Fetch backends (auto-detected): prefer KSM Python SDK when ``KSM_CONFIG_FILE`` or
``KEEPER_CREDENTIAL`` is set; otherwise fall back to Commander ``keeper get``.

Run: python3 -m dsk.integrations.eso_bridge
Env (KSM): KSM_CONFIG_FILE or KEEPER_CREDENTIAL
Env (Commander fallback): KEEPER_EMAIL, KEEPER_PASSWORD, KEEPER_TOTP_SECRET
Env (server): ESO_BRIDGE_PORT (default 8080)
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any
from urllib.parse import urlparse

from dsk.core.resource_limits import ResourceLimitError, json_loads_limited, positive_int_env

logger = logging.getLogger(__name__)

_COMMANDER_TIMEOUT_SECONDS = 60
DEFAULT_RECORD_JSON_BYTES = 1_048_576
DEFAULT_RECORD_JSON_DEPTH = 32


def _max_record_json_bytes() -> int:
    return positive_int_env("DSK_ESO_BRIDGE_MAX_RECORD_JSON_BYTES", DEFAULT_RECORD_JSON_BYTES)


def _max_record_json_depth() -> int:
    return positive_int_env("DSK_ESO_BRIDGE_MAX_RECORD_JSON_DEPTH", DEFAULT_RECORD_JSON_DEPTH)


def _load_record_json(raw: str | bytes | bytearray, *, label: str) -> Any:
    return json_loads_limited(
        raw,
        max_bytes=_max_record_json_bytes(),
        max_depth=_max_record_json_depth(),
        label=label,
        byte_limit_name="DSK_ESO_BRIDGE_MAX_RECORD_JSON_BYTES",
        depth_limit_name="DSK_ESO_BRIDGE_MAX_RECORD_JSON_DEPTH",
    )


def _detect_fetch_mode() -> str:
    """Detect which fetch backend is available. Returns 'ksm' or 'commander'."""
    if os.environ.get("KSM_CONFIG_FILE") or os.environ.get("KEEPER_CREDENTIAL"):
        return "ksm"
    return "commander"


def _resolve_via_ksm(uid_ref: str) -> dict[str, str] | None:
    """
    Fetch a Keeper record via KSM Python SDK.
    uid_ref must be a Keeper record UID (22 chars) for KSM path.
    """
    try:
        from keeper_secrets_manager_core import SecretsManager
        from keeper_secrets_manager_core.storage import FileKeyValueStorage
    except ImportError:
        logger.warning("keeper_secrets_manager_core not installed — cannot use KSM path")
        return None

    config_file = os.environ.get("KSM_CONFIG_FILE", "")
    credential = os.environ.get("KEEPER_CREDENTIAL", "")

    try:
        if config_file:
            sm = SecretsManager(config=FileKeyValueStorage(config_file))
        elif credential:
            sm = SecretsManager(token=credential)
        else:
            return None

        secrets = sm.get_secrets([uid_ref])
        if not secrets:
            return None
        record = secrets[0]
        fields: dict[str, str] = {}
        # Parse raw JSON — KSM SDK <17.3 lacks .fields attribute
        raw = (
            _load_record_json(record.raw_json, label="KSM record raw_json")
            if hasattr(record, "raw_json") and record.raw_json
            else {}
        )
        for fld in raw.get("fields", []) + raw.get("custom", []):
            label = (fld.get("label") or fld.get("type") or "unknown").lower()
            value = fld.get("value", [])
            if isinstance(value, list):
                value = value[0] if value else ""
            if isinstance(value, str):
                fields[label] = value
        return fields if fields else None
    except Exception as exc:  # noqa: BLE001
        logger.warning("KSM fetch failed for '%s': %s", uid_ref, exc)
        return None


def _resolve_via_commander(uid_ref: str) -> dict[str, str] | None:
    """Fetch a Keeper record via Commander CLI subprocess."""
    env = os.environ.copy()
    try:
        result = subprocess.run(
            ["keeper", "get", "--format", "json", "--", uid_ref],
            capture_output=True,
            text=True,
            env=env,
            timeout=_COMMANDER_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        logger.warning(
            "keeper get timed out for '%s' after %ss", uid_ref, _COMMANDER_TIMEOUT_SECONDS
        )
        return None
    if result.returncode != 0:
        logger.warning("keeper get failed for '%s': %s", uid_ref, result.stderr[:100])
        return None
    try:
        data = _load_record_json(result.stdout, label="Commander record JSON")
        fields: dict[str, str] = {}
        for field in data.get("fields", []):
            label = field.get("label", field.get("type", "unknown")).lower()
            value = field.get("value", [""])[0] if field.get("value") else ""
            if isinstance(value, str):
                fields[label] = value
        return fields
    except (json.JSONDecodeError, KeyError, ResourceLimitError):
        return None


def _resolve_uid_ref(uid_ref: str) -> dict[str, str] | None:
    """
    Resolve a uid_ref (Keeper record UID or title) to a field map.
    Auto-detects KSM or Commander based on available env vars.
    KSM: set KSM_CONFIG_FILE or KEEPER_CREDENTIAL.
    Commander: set KEEPER_EMAIL + KEEPER_PASSWORD + KEEPER_TOTP_SECRET.
    """
    mode = _detect_fetch_mode()
    logger.debug("ESO bridge fetch mode: %s", mode)
    if mode == "ksm":
        result = _resolve_via_ksm(uid_ref)
        if result is not None:
            return result
        logger.info("KSM fetch failed, falling back to Commander for '%s'", uid_ref)
    return _resolve_via_commander(uid_ref)


class _EsoBridgeHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args: object) -> None:
        logger.debug(fmt, *args)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        parts = parsed.path.strip("/").split("/")

        # Expected: /secrets/<uid_ref> or /secrets/<uid_ref>/<field>
        if len(parts) < 2 or parts[0] != "secrets":
            self._respond(404, {"error": "path must be /secrets/<uid_ref>"})
            return

        uid_ref = parts[1]
        field = parts[2] if len(parts) > 2 else "password"

        fields = _resolve_uid_ref(uid_ref)
        if fields is None:
            self._respond(404, {"error": f"uid_ref '{uid_ref}' not found"})
            return

        value = fields.get(field, fields.get("password", ""))
        self._respond(200, {"value": value})

    def _respond(self, status: int, body: dict[str, str]) -> None:
        payload = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


def run_bridge(port: int = 8080, host: str | None = None) -> None:
    """Start the ESO bridge HTTP server.

    Defaults to ``127.0.0.1`` so secrets are only served to in-cluster
    sidecars on the loopback interface. To accept off-host traffic
    explicitly opt in with ``ESO_BRIDGE_HOST=0.0.0.0`` (kubernetes pod
    DNS) and front the bridge with a TLS-terminating proxy + auth.
    """
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    bind_host = host or os.environ.get("ESO_BRIDGE_HOST", "127.0.0.1")
    server = HTTPServer((bind_host, port), _EsoBridgeHandler)
    logger.info("DSK ESO bridge listening on %s:%d", bind_host, port)
    if bind_host in ("0.0.0.0", "::"):
        logger.warning(
            "ESO bridge bound to %s — front with TLS + auth before exposing off-host. "
            "Default is 127.0.0.1 for safer-by-default deployment.",
            bind_host,
        )
    server.serve_forever()


if __name__ == "__main__":
    port = int(os.environ.get("ESO_BRIDGE_PORT", "8080"))
    run_bridge(port)
