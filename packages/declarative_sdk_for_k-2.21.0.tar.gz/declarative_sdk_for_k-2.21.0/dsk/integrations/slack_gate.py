"""Slack approval gate integration.

Posts approval request to Slack, polls for response, returns True/False.
Uses Slack Web API (requests-based, no SDK dependency required).
"""

from __future__ import annotations

import logging
import os
import time

log = logging.getLogger(__name__)

# Slack approval checks are operator-facing gates; short HTTP timeouts prevent
# applies from hanging on API stalls, while polling remains intentionally slower.
SLACK_API_TIMEOUT_SECONDS = 10
SLACK_POLL_INTERVAL_SECONDS = 15
DEFAULT_SLACK_TIMEOUT_MINUTES = 30


class SlackGateError(Exception):
    """Raised when Slack gate cannot be completed."""


def _post_approval_request(
    channel: str,
    manifest_name: str,
    gate_name: str,
    bot_token: str,
    message_template: str | None = None,
) -> str:
    """Post approval request to Slack, return thread timestamp (ts)."""
    try:
        import requests  # type: ignore[import-untyped]
    except ImportError as exc:
        raise SlackGateError("requests not installed") from exc

    text = message_template or (
        f":lock: *DSK apply approval needed*\n"
        f"Manifest: `{manifest_name}` · Gate: `{gate_name}`\n"
        f"Reply :white_check_mark: to approve, :x: to reject."
    )
    resp = requests.post(
        "https://slack.com/api/chat.postMessage",
        headers={
            "Authorization": f"Bearer {bot_token}",
            "Content-Type": "application/json",
        },
        json={"channel": channel, "text": text, "mrkdwn": True},
        timeout=SLACK_API_TIMEOUT_SECONDS,
    )
    data = resp.json()
    if not data.get("ok"):
        raise SlackGateError(f"Slack post failed: {data.get('error', 'unknown')}")
    return str(data["ts"])


def _poll_reactions(
    channel: str,
    message_ts: str,
    bot_token: str,
    timeout_minutes: int,
    on_timeout: str,
) -> bool:
    """Poll Slack message reactions. Returns True=approved, False=rejected."""
    try:
        import requests
    except ImportError as exc:
        raise SlackGateError("requests not installed") from exc

    deadline = time.time() + timeout_minutes * 60
    while time.time() < deadline:
        resp = requests.get(
            "https://slack.com/api/reactions.get",
            headers={"Authorization": f"Bearer {bot_token}"},
            params={"channel": channel, "timestamp": message_ts},
            timeout=SLACK_API_TIMEOUT_SECONDS,
        )
        data = resp.json()
        if data.get("ok"):
            reactions = {
                r["name"]: r["count"] for r in data.get("message", {}).get("reactions", [])
            }
            if reactions.get("white_check_mark", 0) > 0:
                return True
            if reactions.get("x", 0) > 0:
                return False
        time.sleep(SLACK_POLL_INTERVAL_SECONDS)

    # Timeout reached
    if on_timeout == "auto_approve":
        log.warning("Slack gate timeout — auto-approving per policy")
        return True
    elif on_timeout == "auto_reject":
        log.warning("Slack gate timeout — auto-rejecting per policy")
        return False
    else:  # block
        raise SlackGateError(f"Slack gate timed out after {timeout_minutes}m — apply blocked")


def check_slack_gate(
    gate_name: str,
    manifest_name: str,
    channel: str,
    timeout_minutes: int = DEFAULT_SLACK_TIMEOUT_MINUTES,
    on_timeout: str = "block",
    message_template: str | None = None,
) -> None:
    """Check Slack approval gate. Raises SlackGateError if not approved."""
    bot_token = os.environ.get("SLACK_BOT_TOKEN", "")
    if not bot_token:
        raise SlackGateError("SLACK_BOT_TOKEN not set — slack gate cannot proceed")

    ts = _post_approval_request(channel, manifest_name, gate_name, bot_token, message_template)
    approved = _poll_reactions(channel, ts, bot_token, timeout_minutes, on_timeout)
    if not approved:
        raise SlackGateError(f"Slack gate '{gate_name}' rejected — apply blocked")
