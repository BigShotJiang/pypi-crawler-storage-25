"""Secret scanner webhook bridge.

Receives GitHub GHAS secret-scanning webhook events, verifies HMAC,
maps the secret type to a Keeper credential uid_ref, and triggers rotation.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
from typing import Any

from dsk.core.resource_limits import (
    ResourceLimitError,
    ensure_payload_within_limit,
    json_loads_limited,
    positive_int_env,
)

log = logging.getLogger(__name__)

DEFAULT_WEBHOOK_PAYLOAD_BYTES = 1_048_576
DEFAULT_WEBHOOK_JSON_DEPTH = 32


class ScannerBridgeError(Exception):
    pass


def _max_webhook_payload_bytes() -> int:
    return positive_int_env("DSK_SECRET_SCANNER_MAX_WEBHOOK_BYTES", DEFAULT_WEBHOOK_PAYLOAD_BYTES)


def _max_webhook_json_depth() -> int:
    return positive_int_env("DSK_SECRET_SCANNER_MAX_JSON_DEPTH", DEFAULT_WEBHOOK_JSON_DEPTH)


def verify_github_hmac(payload: bytes, signature_header: str, secret: str) -> bool:
    """Verify GitHub webhook HMAC-SHA256 signature."""
    if not signature_header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature_header)


def normalize_github_alert(payload: dict[str, Any]) -> dict[str, Any]:
    """Extract canonical fields from a GitHub secret-scanning alert payload."""
    alert = payload.get("alert", {})
    return {
        "secret_type": alert.get("secret_type", ""),
        "state": alert.get("state", ""),
        "repo": payload.get("repository", {}).get("full_name", ""),
        "url": alert.get("html_url", ""),
        "alert_number": alert.get("number"),
    }


def find_mapping(secret_type: str, mappings: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Find the first mapping matching the detected secret type."""
    for m in mappings:
        if m.get("secret_type", "").lower() == secret_type.lower():
            return m
    return None


def handle_alert(
    raw_payload: bytes,
    signature: str,
    manifest_mappings: list[dict[str, Any]],
    dry_run: bool = False,
) -> dict[str, Any]:
    """Process a scanner webhook alert. Returns action summary dict."""
    try:
        ensure_payload_within_limit(
            raw_payload,
            max_bytes=_max_webhook_payload_bytes(),
            label="secret scanner webhook payload",
            limit_name="DSK_SECRET_SCANNER_MAX_WEBHOOK_BYTES",
        )
    except ResourceLimitError as exc:
        raise ScannerBridgeError(str(exc)) from exc

    secret_env = os.environ.get("SECRET_SCANNER_WEBHOOK_SECRET", "")
    if secret_env and not verify_github_hmac(raw_payload, signature, secret_env):
        raise ScannerBridgeError("HMAC verification failed — alert rejected")

    try:
        payload = json_loads_limited(
            raw_payload,
            max_bytes=_max_webhook_payload_bytes(),
            max_depth=_max_webhook_json_depth(),
            label="secret scanner webhook payload",
            byte_limit_name="DSK_SECRET_SCANNER_MAX_WEBHOOK_BYTES",
            depth_limit_name="DSK_SECRET_SCANNER_MAX_JSON_DEPTH",
        )
    except (json.JSONDecodeError, ResourceLimitError) as exc:
        raise ScannerBridgeError(f"invalid scanner payload: {exc}") from exc
    alert = normalize_github_alert(payload)

    if alert["state"] != "open":
        return {"action": "skip", "reason": f"alert state={alert['state']}"}

    mapping = find_mapping(alert["secret_type"], manifest_mappings)
    if not mapping:
        log.warning("No DSK mapping for secret_type=%r", alert["secret_type"])
        return {"action": "skip", "reason": "no_mapping", "secret_type": alert["secret_type"]}

    result = {
        "action": "rotate" if mapping.get("auto_rotate", True) else "ticket",
        "uid_ref": mapping["keeper_uid_ref"],
        "severity": mapping.get("severity", "critical"),
        "dry_run": dry_run,
        "repo": alert["repo"],
        "alert_url": alert["url"],
    }
    if dry_run:
        log.info("[DRY-RUN] Would rotate %s — %r", mapping["keeper_uid_ref"], result)
    else:
        log.warning(
            "ROTATION TRIGGERED: %s for secret_type=%r repo=%s",
            mapping["keeper_uid_ref"],
            alert["secret_type"],
            alert["repo"],
        )

    return result
