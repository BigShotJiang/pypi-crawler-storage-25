"""Ticket gate — verifies a change ticket is approved before dsk apply.

Supported systems:
  - Jira: checks issue status via REST API
  - ServiceNow: checks change_request state via REST API

Environment variables:
  JIRA_BASE_URL, JIRA_TOKEN  — Jira Cloud token (email:api_token base64 or Bearer)
  SNOW_INSTANCE, SNOW_TOKEN  — ServiceNow instance + Bearer token
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Protocol

# Hardening: prevent SSRF / scheme-abuse via JIRA_BASE_URL / SNOW_INSTANCE.
# urllib.request.urlopen will happily speak file://, ftp://, gopher://; restrict
# the ticket gate to plain http(s) so an attacker who can set the relevant env
# var cannot read local files or pivot to internal services.
_ALLOWED_SCHEMES: frozenset[str] = frozenset({"http", "https"})
_MAX_TICKET_RESPONSE_BYTES = 1_048_576
# Human approval systems should fail fast enough to avoid blocking apply
# workflows indefinitely, while still allowing normal SaaS latency.
TICKET_GATE_REQUEST_TIMEOUT_SECONDS = 10


def _require_http_url(url: str, *, env_var: str) -> str:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme.lower() not in _ALLOWED_SCHEMES or not parsed.netloc:
        raise TicketGateError(f"{env_var} must be an http(s):// URL with a host; got {url!r}")
    return url


class TicketGateError(Exception):
    """Raised when ticket gate check fails or ticket is not approved."""


class _ReadableResponse(Protocol):
    def read(self, size: int = -1) -> bytes: ...


def _read_json_response(resp: _ReadableResponse, *, label: str) -> dict:
    raw = resp.read(_MAX_TICKET_RESPONSE_BYTES + 1)
    if len(raw) > _MAX_TICKET_RESPONSE_BYTES:
        raise TicketGateError(f"{label} response exceeded {_MAX_TICKET_RESPONSE_BYTES} bytes")
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise TicketGateError(f"{label} response must be a JSON object")
    return data


def _jira_check(ticket_id: str, required_status: str = "Approved") -> bool:
    """Return True if Jira issue is in required_status."""
    base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
    token = os.environ.get("JIRA_TOKEN", "")
    if not base_url or not token:
        raise TicketGateError("JIRA_BASE_URL and JIRA_TOKEN required for Jira ticket gate")
    base_url = _require_http_url(base_url, env_var="JIRA_BASE_URL")
    url = f"{base_url}/rest/api/3/issue/{urllib.parse.quote(ticket_id, safe='')}"
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=TICKET_GATE_REQUEST_TIMEOUT_SECONDS) as resp:
            data = _read_json_response(resp, label="Jira")
        status = str(data.get("fields", {}).get("status", {}).get("name", ""))
        return status.lower() == required_status.lower()
    except urllib.error.HTTPError as exc:
        raise TicketGateError(f"Jira API error for {ticket_id}: {exc.code}") from exc


def _servicenow_check(ticket_id: str, required_state: str = "approved") -> bool:
    """Return True if ServiceNow change_request is in required_state."""
    instance = os.environ.get("SNOW_INSTANCE", "").rstrip("/")
    token = os.environ.get("SNOW_TOKEN", "")
    if not instance or not token:
        raise TicketGateError("SNOW_INSTANCE and SNOW_TOKEN required for ServiceNow ticket gate")
    instance = _require_http_url(instance, env_var="SNOW_INSTANCE")
    safe_ticket = urllib.parse.quote(ticket_id, safe="")
    url = (
        f"{instance}/api/now/table/change_request"
        f"?sysparm_query=number={safe_ticket}&sysparm_fields=state,approval"
    )
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=TICKET_GATE_REQUEST_TIMEOUT_SECONDS) as resp:
            data = _read_json_response(resp, label="ServiceNow")
        records = data.get("result", [])
        if not records:
            raise TicketGateError(f"ServiceNow: ticket {ticket_id} not found")
        approval = str(records[0].get("approval", ""))
        return approval.lower() == required_state.lower()
    except urllib.error.HTTPError as exc:
        raise TicketGateError(f"ServiceNow API error for {ticket_id}: {exc.code}") from exc


def check_ticket(ticket_id: str, system: str = "jira", required_status: str = "Approved") -> None:
    """Verify ticket is approved. Raises TicketGateError if not.

    Args:
        ticket_id: e.g. "CHG0012345" or "INFRA-789"
        system: "jira" or "servicenow"
        required_status: status/approval string to match (case-insensitive)
    """
    if system == "jira":
        ok = _jira_check(ticket_id, required_status)
    elif system == "servicenow":
        ok = _servicenow_check(ticket_id, required_status)
    else:
        raise TicketGateError(f"Unknown ticket system: {system!r} (use 'jira' or 'servicenow')")

    if not ok:
        raise TicketGateError(
            f"Ticket {ticket_id} ({system}) is not in '{required_status}' state — "
            "apply blocked by ticket gate."
        )
