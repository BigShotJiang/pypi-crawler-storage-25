"""
HCL importer for DSK — converts Terraform HCL to DSK YAML manifest.

Requires: python-hcl2 (pip install python-hcl2)
"""

from __future__ import annotations

import io
from typing import Any


def _strip_hcl_quoting(token: str) -> str:
    """python-hcl2 often leaves outer quotes from labels and string literals."""
    s = token.strip()
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        inner = s[1:-1].replace('\\"', '"').replace("\\\\", "\\")
        return inner
    return s


def _normalize_hcl_value(value: Any) -> Any:
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for k, raw in value.items():
            if k == "__is_block__":
                continue
            key_s = _strip_hcl_quoting(str(k))
            out[key_s] = _normalize_hcl_value(raw)
        return out if out else {}
    if isinstance(value, list):
        return [_normalize_hcl_value(x) for x in value]
    if isinstance(value, str):
        return _strip_hcl_quoting(value)
    return value


def _require_hcl2() -> Any:
    try:
        import hcl2
    except ImportError as exc:  # pragma: no cover - exercised when extras missing
        raise ImportError(
            "python-hcl2 is required for HCL import. Run: pip install python-hcl2"
        ) from exc
    else:
        return hcl2


_TF_TYPE_TO_DSK: dict[str, str] = {
    "keeper_pam_gateway": "pamGateway",
    "keeper_pam_configuration": "pamConfiguration",
    "keeper_pam_machine": "pamMachine",
    "keeper_pam_database": "pamDatabase",
    "keeper_pam_directory": "pamDirectory",
    "keeper_pam_user": "pamUser",
    "keeper_pam_remote_browser": "pamRemoteBrowser",
}


def hcl_to_manifest(hcl_content: str, manifest_name: str = "imported") -> dict[str, Any]:
    """
    Parse HCL content and return a DSK manifest dict.

    Supports Terraform resource blocks with keeper_pam_* types.
    Returns a dict suitable for serialization as YAML or JSON.
    """
    hcl2_mod = _require_hcl2()
    parsed = hcl2_mod.load(io.StringIO(hcl_content))

    resources: list[dict[str, Any]] = []
    for resource_block in parsed.get("resource", []):
        for tf_type_raw, instances in resource_block.items():
            tf_type = _strip_hcl_quoting(str(tf_type_raw))
            instances_n = _normalize_hcl_value(instances)
            if not isinstance(instances_n, dict):
                continue
            dsk_type = _TF_TYPE_TO_DSK.get(tf_type, tf_type)
            for uid_ref_raw, attrs in instances_n.items():
                uid_key = _strip_hcl_quoting(str(uid_ref_raw))
                uid_ref = uid_key.replace("_", ".")
                attr_map = attrs if isinstance(attrs, dict) else {}
                resource: dict[str, Any] = {
                    "uid_ref": uid_ref,
                    "resource_type": dsk_type,
                }
                for k, v in attr_map.items():
                    resource[k] = v
                resources.append(resource)

    return {
        "schema": "pam-environment.v1",
        "name": manifest_name,
        "resources": resources,
    }
