"""Production library shim for embedding DSK behind keeper-migrate commands.

The shim calls DSK command handlers and planner helpers directly. It does not
use Click's test harness or parse synthetic argv inside the current process.
"""

from __future__ import annotations

import contextlib
import io
import json
import tomllib
import warnings
from collections.abc import Callable, Sequence
from importlib import metadata
from pathlib import Path
from typing import Any

import click

from dsk.core.planner import Plan
from dsk.shim._descriptor import (
    OUTPUT_CONTRACT_VERSIONS_SUPPORTED,
    SHIM_CONTRACT_VERSION,
    SIGNATURE_BACKENDS,
    SUPPORTED_VERBS,
    build_descriptor,
)
from dsk.shim._types import (
    ApplyResult,
    AuditExplanation,
    Bundle,
    ImportResult,
    ShimCommandResult,
    VerifyResult,
    _redact_sensitive_args,
)

DEFAULT_DRIFT_WATCH_INTERVAL_SECONDS = 300


def _dsk_version() -> str:
    pyproject_path = Path(__file__).resolve().parents[2] / "pyproject.toml"
    if pyproject_path.exists():
        data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
        return str(data["project"]["version"])
    try:
        return metadata.version("declarative-sdk-for-k")
    except metadata.PackageNotFoundError:
        return "2.21.0"


def shim_info(output_contract_version: str | None = None) -> dict[str, Any]:
    """Return the JSON-serializable shim discovery descriptor."""

    return build_descriptor(_dsk_version(), output_contract_version)


def shim_info_json(output_contract_version: str | None = None) -> str:
    """Return :func:`shim_info` as stable, sorted JSON text."""

    return json.dumps(shim_info(output_contract_version), indent=2, sort_keys=True) + "\n"


def _as_path(value: str | Path) -> Path:
    return value if isinstance(value, Path) else Path(value)


def _optional_path(value: str | Path | None) -> Path | None:
    return None if value is None else _as_path(value)


def _exit_code_from_system_exit(exc: SystemExit) -> int:
    if exc.code is None:
        return 0
    if isinstance(exc.code, int):
        return exc.code
    return 1


def _capture_direct(args: Sequence[str], callback: Callable[[], None]) -> ShimCommandResult:
    stdout = io.StringIO()
    stderr = io.StringIO()
    exit_code = 0
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        try:
            callback()
        except SystemExit as exc:
            exit_code = _exit_code_from_system_exit(exc)
        except click.ClickException as exc:
            exc.show(file=stderr)
            exit_code = exc.exit_code
        except click.Abort:
            stderr.write("Aborted!\n")
            exit_code = 1
    return ShimCommandResult(
        exit_code, stdout.getvalue(), stderr.getvalue(), _redact_sensitive_args(args)
    )


def _main_context(provider: str, folder_uid: str | None) -> click.Context:
    from dsk.cli.main import dispatch_main, main

    ctx = click.Context(main)
    dispatch_main(ctx, provider, folder_uid)
    return ctx


def adopt(
    run_dir: str | Path,
    *,
    output: str | Path | None = None,
    dry_run: bool = True,
    auto_approve: bool = False,
    skip_audit_verify: bool = False,
    skip_sha256: bool = False,
    suspect_threshold: int = 0,
    verbose: bool = False,
    require_output_signature: bool = False,
    signature_pubkey: str | Path | None = None,
    signature_pubkey_keeper_record: str | None = None,
    commander_config: str | Path | None = None,
) -> ImportResult:
    """Adopt a keeperCMD run-dir into a DSK manifest or ownership markers.

    Parameters mirror ``dsk import-from-keepercmd``. ``dry_run`` defaults to
    true for library safety; set ``dry_run=False`` with ``auto_approve=True`` to
    write ownership markers.

    Returns an ``ImportResult`` with captured command output and optional
    manifest YAML when ``output`` is written.

    Raises command-handler exceptions that are not represented as DSK exit
    codes, including invalid argument conversion failures.
    """

    from dsk.cli.cmd_import_from_keepercmd import import_from_keepercmd_cmd

    run_dir_path = _as_path(run_dir)
    output_path = _optional_path(output)
    signature_path = _optional_path(signature_pubkey)
    commander_config_path = _optional_path(commander_config)
    args = [
        "import-from-keepercmd",
        str(run_dir_path),
        "--suspect-threshold",
        str(suspect_threshold),
    ]
    if dry_run:
        args.append("--dry-run")
    if auto_approve:
        args.append("--auto-approve")
    if skip_audit_verify:
        args.append("--skip-audit-verify")
    if skip_sha256:
        args.append("--skip-sha256")
    if verbose:
        args.append("--verbose")
    if require_output_signature:
        args.append("--require-output-signature")
    option_pairs: list[tuple[str, str | Path | None]] = [
        ("--output", output_path),
        ("--signature-pubkey", signature_path),
        ("--signature-pubkey-keeper-record", signature_pubkey_keeper_record),
        ("--commander-config", commander_config_path),
    ]
    for flag, value in option_pairs:
        if value is not None:
            args.extend([flag, str(value)])

    callback = import_from_keepercmd_cmd.callback
    if callback is None:
        raise RuntimeError("import-from-keepercmd command has no callback")
    result = _capture_direct(
        args,
        lambda: callback(
            run_dir_path,
            output_path,
            dry_run,
            auto_approve,
            skip_audit_verify,
            skip_sha256,
            suspect_threshold,
            verbose,
            require_output_signature,
            signature_path,
            signature_pubkey_keeper_record,
            commander_config_path,
        ),
    )
    manifest_yaml = (
        output_path.read_text(encoding="utf-8") if output_path and output_path.exists() else None
    )
    return ImportResult(
        result.exit_code,
        result.stdout,
        result.stderr,
        result.args,
        run_dir_path,
        output_path,
        manifest_yaml,
    )


def import_from_keepercmd(*args: Any, **kwargs: Any) -> ImportResult:
    """DEPRECATED: use :func:`adopt`; retained until DSK 3.0."""

    warnings.warn(
        "`import_from_keepercmd` is deprecated; use `dsk.shim.adopt` (will be removed in DSK 3.0)",
        DeprecationWarning,
        stacklevel=2,
    )
    return adopt(*args, **kwargs)


def plan(
    target_state: str | Path,
    *,
    allow_delete: bool = False,
    provider: str = "mock",
    folder_uid: str | None = None,
) -> Plan:
    """Build and return a DSK ``Plan`` for ``target_state``.

    Parameters select the manifest path, delete policy, provider, and optional
    Keeper shared-folder scope.

    Returns the core planner ``Plan`` object.

    Raises schema, reference, ownership, provider, and capability errors from
    the public in-process planner.
    """

    from dsk.cli.main import build_plan

    with _main_context(provider, folder_uid) as ctx:
        return build_plan(ctx, _as_path(target_state), allow_delete=allow_delete)


def apply(
    plan: Plan | str | Path,
    *,
    manifest_path: str | Path | None = None,
    dry_run: bool = True,
    allow_delete: bool = False,
    auto_approve: bool = False,
    provider: str = "mock",
    folder_uid: str | None = None,
) -> ApplyResult:
    """Apply a DSK manifest, optionally paired with a prebuilt ``Plan``.

    When ``plan`` is a path, it is used as the manifest path. When ``plan`` is a
    ``Plan`` object, ``manifest_path`` must be supplied because the existing
    apply path recomputes provider context from the manifest.

    Returns captured apply output and exit code.

    Raises ``ValueError`` when no manifest path can be resolved.
    """

    from dsk.cli.main import apply as apply_cmd

    resolved = _as_path(plan) if isinstance(plan, (str, Path)) else _optional_path(manifest_path)
    if resolved is None:
        raise ValueError("apply() requires a manifest path or manifest_path when plan is a Plan")

    args = ["apply", str(resolved)]
    if allow_delete:
        args.append("--allow-delete")
    if auto_approve:
        args.append("--auto-approve")
    if dry_run:
        args.append("--dry-run")
    if provider != "mock":
        args.extend(["--provider", provider])
    if folder_uid is not None:
        args.extend(["--folder-uid", folder_uid])

    callback = apply_cmd.callback
    if callback is None:
        raise RuntimeError("apply command has no callback")
    with _main_context(provider, folder_uid):
        result = _capture_direct(
            args,
            lambda: callback(
                resolved,
                allow_delete,
                auto_approve,
                dry_run,
                None,
            ),
        )
    return ApplyResult(
        result.exit_code, result.stdout, result.stderr, result.args, resolved, dry_run
    )


def verify(
    run_dir: str | Path,
    *,
    strict: bool = False,
    require_output_signature: bool = False,
    signature_pubkey: str | Path | None = None,
    signature_pubkey_keeper_record: str | None = None,
) -> VerifyResult:
    """Verify keeperCMD run-dir integrity.

    Parameters mirror ``dsk verify``. The verb is standalone-only and not part
    of the keeper-migrate absorption subset.

    Returns captured verifier output and exit code.

    Raises command-handler exceptions that are not represented as DSK exit
    codes.
    """

    from dsk.cli.cmd_verify import verify_cmd

    run_dir_path = _as_path(run_dir)
    signature_path = _optional_path(signature_pubkey)
    args = ["verify", str(run_dir_path)]
    if strict:
        args.append("--strict")
    if require_output_signature:
        args.append("--require-output-signature")
    if signature_path is not None:
        args.extend(["--signature-pubkey", str(signature_path)])
    if signature_pubkey_keeper_record is not None:
        args.extend(["--signature-pubkey-keeper-record", signature_pubkey_keeper_record])

    callback = verify_cmd.callback
    if callback is None:
        raise RuntimeError("verify command has no callback")
    result = _capture_direct(
        args,
        lambda: callback(
            run_dir_path,
            strict,
            require_output_signature,
            signature_path,
            signature_pubkey_keeper_record,
        ),
    )
    return VerifyResult(result.exit_code, result.stdout, result.stderr, result.args, run_dir_path)


def audit_explain(audit_log: str | Path, *, summary: bool = True) -> AuditExplanation:
    """Return a structured explanation of a keeperCMD audit chain.

    Parameters select the audit log and whether to include the time span.

    Returns counts, operation totals, suspicious-pattern strings, and optional
    time span.

    Raises audit parser exceptions for malformed, missing, or corrupt logs.
    """

    from dsk.cli.audit_chain import explain_audit_log

    audit_log_path = _as_path(audit_log)
    result = explain_audit_log(audit_log_path)
    return AuditExplanation(
        audit_log_path,
        len(result.entries),
        len(result.failures),
        dict(result.operation_counts),
        tuple(result.suspicious_patterns),
        result.time_span if summary else (None, None),
    )


def audit(*args: Any, **kwargs: Any) -> AuditExplanation:
    """DEPRECATED: use :func:`audit_explain`; retained until DSK 3.0."""

    warnings.warn(
        "`audit` is deprecated; use `dsk.shim.audit_explain` (will be removed in DSK 3.0)",
        DeprecationWarning,
        stacklevel=2,
    )
    return audit_explain(*args, **kwargs)


def diff(
    manifest_path: str | Path,
    *,
    allow_delete: bool = False,
    provider: str = "mock",
    folder_uid: str | None = None,
) -> ShimCommandResult:
    """Render a field-level DSK diff for ``manifest_path``.

    Parameters mirror ``dsk diff`` plus the inherited provider options.

    Returns captured diff output and exit code. Exit code ``2`` means changes
    are present.

    Raises command-handler exceptions that are not represented as DSK exit
    codes.
    """

    from dsk.cli.main import diff as diff_cmd

    manifest = _as_path(manifest_path)
    args = ["diff", str(manifest)]
    if allow_delete:
        args.append("--allow-delete")
    if provider != "mock":
        args.extend(["--provider", provider])
    if folder_uid is not None:
        args.extend(["--folder-uid", folder_uid])

    callback = diff_cmd.callback
    if callback is None:
        raise RuntimeError("diff command has no callback")
    with _main_context(provider, folder_uid):
        return _capture_direct(args, lambda: callback(manifest, allow_delete))


def bundle(
    manifest_path: str | Path,
    *,
    output_dir: str | Path | None = None,
    dry_run: bool = False,
) -> Bundle:
    """Generate or preview a compliance evidence bundle.

    Parameters mirror ``dsk bundle``.

    Returns bundle metadata, exit code, and rendered output.

    Raises resource-limit, manifest-shape, provider, and filesystem exceptions
    from bundle helper logic.
    """

    from dsk.cli.cmd_bundle import (
        _bundle_header_lines,
        _dry_run_lines,
        _generate_bundle,
        _load_bundle_manifest,
    )

    manifest = _as_path(manifest_path)
    data = _load_bundle_manifest(str(manifest))
    resolved_output = _optional_path(output_dir) or Path(
        str(data.get("output_dir", "compliance-evidence/"))
    )
    controls = data.get("controls", [])
    if not isinstance(controls, list):
        raise ValueError("controls must be a list")
    lines = _bundle_header_lines(data, str(resolved_output))
    if dry_run:
        lines.extend(_dry_run_lines(controls))
        return Bundle(0, manifest, resolved_output, None, True, "\n".join(lines) + "\n")
    errors, index_path = _generate_bundle(data, str(resolved_output))
    lines.extend(
        [
            f"Bundle index: {index_path}",
            f"Complete. {len(controls) - errors}/{len(controls)} controls OK.",
        ]
    )
    return Bundle(
        0 if errors == 0 else 1,
        manifest,
        resolved_output,
        index_path,
        False,
        "\n".join(lines) + "\n",
    )


def discover(
    *,
    output: str | Path,
    provider: str | None = None,
    input_path: str | Path | None = None,
    name: str | None = None,
    folder_uid: str | None = None,
) -> ShimCommandResult:
    """Discover unmanaged PAM resources into a starter manifest.

    Parameters mirror ``dsk discover``. The verb is standalone-only and not part
    of the keeper-migrate absorption subset.

    Returns captured output and exit code.

    Raises command-handler exceptions that are not represented as DSK exit
    codes.
    """

    from dsk.cli.discover import discover_cmd

    output_path = _as_path(output)
    input_path_obj = _optional_path(input_path)
    args = ["discover", "--output", str(output_path)]
    if provider is not None:
        args.extend(["--provider", provider])
    if input_path_obj is not None:
        args.extend(["--input", str(input_path_obj)])
    if name is not None:
        args.extend(["--name", name])
    if folder_uid is not None:
        args.extend(["--folder-uid", folder_uid])

    callback = discover_cmd.callback
    if callback is None:
        raise RuntimeError("discover command has no callback")
    with _main_context(provider or "mock", folder_uid):
        return _capture_direct(
            args,
            lambda: callback(provider, input_path_obj, output_path, name),
        )


def drift_watch(
    manifest_paths: Sequence[str | Path],
    *,
    interval: int = DEFAULT_DRIFT_WATCH_INTERVAL_SECONDS,
    github_repo: str | None = None,
    github_token: str | None = None,
    pr_base: str = "main",
    dry_run: bool = True,
    slack_webhook: str | None = None,
    slack_channel: str | None = None,
    servicenow_instance: str | None = None,
    servicenow_api_key: str | None = None,
    verbose: bool = False,
) -> ShimCommandResult:
    """Run the preview-gated drift watcher.

    Parameters mirror ``dsk drift-watch``.

    Returns captured output and exit code.

    Raises command-handler exceptions that are not represented as DSK exit
    codes. Runtime remains gated by ``DSK_PREVIEW=drift-watch``.
    """

    from dsk.cli.cmd_drift_watch import drift_watch_cmd

    manifest_arg = tuple(str(_as_path(path)) for path in manifest_paths)
    args = ["drift-watch", *manifest_arg, "--interval", str(interval), "--pr-base", pr_base]
    if github_repo is not None:
        args.extend(["--github-repo", github_repo])
    if github_token is not None:
        args.extend(["--github-token", github_token])
    args.append("--dry-run" if dry_run else "--no-dry-run")
    if slack_webhook is not None:
        args.extend(["--slack-webhook", slack_webhook])
    if slack_channel is not None:
        args.extend(["--slack-channel", slack_channel])
    if servicenow_instance is not None:
        args.extend(["--servicenow-instance", servicenow_instance])
    if servicenow_api_key is not None:
        args.extend(["--servicenow-api-key", servicenow_api_key])
    if verbose:
        args.append("--verbose")

    callback = drift_watch_cmd.callback
    if callback is None:
        raise RuntimeError("drift-watch command has no callback")
    return _capture_direct(
        args,
        lambda: callback(
            manifest_arg,
            interval,
            github_repo,
            github_token,
            pr_base,
            dry_run,
            slack_webhook,
            slack_channel,
            servicenow_instance,
            servicenow_api_key,
            verbose,
        ),
    )


def rehearse_report(
    run_dir: str | Path,
    *,
    output: str | Path | None = None,
    dry_run: bool = False,
    verbose: bool = False,
    output_format: str = "text",
) -> ShimCommandResult:
    """Emit the keeperCMD rehearsal drift report.

    Parameters mirror ``dsk rehearse-report``.

    Returns captured text or JUnit output plus exit code.

    Raises command-handler exceptions that are not represented as DSK exit
    codes.
    """

    from dsk.cli.cmd_rehearse_report import rehearse_report_cmd

    run_dir_path = _as_path(run_dir)
    output_value = "" if output is None else str(output)
    args = ["rehearse-report", str(run_dir_path), "--format", output_format]
    if output is not None:
        args.extend(["--output", output_value])
    if dry_run:
        args.append("--dry-run")
    if verbose:
        args.append("--verbose")

    callback = rehearse_report_cmd.callback
    if callback is None:
        raise RuntimeError("rehearse-report command has no callback")
    return _capture_direct(
        args,
        lambda: callback(run_dir_path, output_value, dry_run, verbose, output_format),
    )


__all__ = [
    "DEFAULT_DRIFT_WATCH_INTERVAL_SECONDS",
    "SHIM_CONTRACT_VERSION",
    "OUTPUT_CONTRACT_VERSIONS_SUPPORTED",
    "SIGNATURE_BACKENDS",
    "SUPPORTED_VERBS",
    "ShimCommandResult",
    "ImportResult",
    "ApplyResult",
    "VerifyResult",
    "AuditExplanation",
    "Bundle",
    "shim_info",
    "shim_info_json",
    "adopt",
    "import_from_keepercmd",
    "plan",
    "apply",
    "diff",
    "verify",
    "audit_explain",
    "audit",
    "bundle",
    "discover",
    "drift_watch",
    "rehearse_report",
]
