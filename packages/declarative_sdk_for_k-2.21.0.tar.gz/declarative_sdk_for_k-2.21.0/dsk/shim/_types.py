"""Public dataclasses returned by ``dsk.shim``."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

_SENSITIVE_OPTION_NAMES = (
    "--github-token",
    "--slack-webhook",
    "--servicenow-api-key",
    "--password",
    "--passphrase",
    "--api-key",
    "--secret",
    "--token",
)
_SENSITIVE_OPTION_SUFFIXES = (
    "-token",
    "-secret",
    "-webhook",
    "-api-key",
    "-key",
    "-password",
)
_REDACTION_PLACEHOLDER = "***REDACTED***"


def _is_sensitive_option(arg: str) -> bool:
    return arg in _SENSITIVE_OPTION_NAMES or any(
        arg.endswith(suffix) for suffix in _SENSITIVE_OPTION_SUFFIXES
    )


def _redact_sensitive_args(args: Sequence[str]) -> tuple[str, ...]:
    """Strip secret-bearing values from a CLI arglist.

    Defense-in-depth for ``ShimCommandResult.args``, which is JSON-serialized
    by Commander's ``migrate.py``. Without this, drift_watch's token options
    leak via JSON/log output (pentest finding NEW-H1, BLOCKER for Commander
    PR approval, 2026-05-10).

    Matches exact option names and suffixes such as ``--custom-token``. Handles
    both ``--opt value`` and ``--opt=value`` forms.

    Note: the suffix list (``-token``, ``-secret``, ``-webhook``,
    ``-api-key``, ``-key``, ``-password``) is intentionally safety-first.
    Flags like ``--public-key`` or ``--shared-key`` may be over-redacted
    (their values replaced with the placeholder) even though they are not
    secrets. Per Bob (2026-05-10 review): "minor false-positive on
    public-key-style flags is accepted" - log fidelity yields to leak
    prevention.
    """
    redacted: list[str] = []
    args_list = list(args)
    i = 0
    while i < len(args_list):
        arg = args_list[i]
        if "=" in arg and arg.startswith("--"):
            opt_name, _, _ = arg.partition("=")
            if _is_sensitive_option(opt_name):
                redacted.append(f"{opt_name}={_REDACTION_PLACEHOLDER}")
                i += 1
                continue
            redacted.append(arg)
            i += 1
            continue
        if _is_sensitive_option(arg):
            redacted.append(arg)
            if i + 1 < len(args_list):
                redacted.append(_REDACTION_PLACEHOLDER)
                i += 2
                continue
            i += 1
            continue
        redacted.append(arg)
        i += 1
    return tuple(redacted)


@dataclass(frozen=True)
class ShimCommandResult:
    """Captured result from an in-process DSK CLI command invocation."""

    exit_code: int
    stdout: str
    stderr: str
    args: tuple[str, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "args", _redact_sensitive_args(self.args))


@dataclass(frozen=True)
class ImportResult(ShimCommandResult):
    """Result returned by ``import_from_keepercmd``."""

    run_dir: Path
    output: Path | None = None
    manifest_yaml: str | None = None


@dataclass(frozen=True)
class ApplyResult(ShimCommandResult):
    """Result returned by ``apply``."""

    manifest_path: Path | None = None
    dry_run: bool = True


@dataclass(frozen=True)
class VerifyResult(ShimCommandResult):
    """Result returned by ``verify``."""

    run_dir: Path | None = None


@dataclass(frozen=True)
class AuditExplanation:
    """Structured summary from ``dsk audit explain``."""

    path: Path
    entry_count: int
    failure_count: int
    operation_counts: dict[str, int]
    suspicious_patterns: tuple[str, ...]
    time_span: tuple[str | None, str | None]


@dataclass(frozen=True)
class Bundle:
    """Result returned by ``bundle``."""

    exit_code: int
    manifest_path: Path
    output_dir: Path
    index_path: Path | None
    dry_run: bool
    stdout: str
