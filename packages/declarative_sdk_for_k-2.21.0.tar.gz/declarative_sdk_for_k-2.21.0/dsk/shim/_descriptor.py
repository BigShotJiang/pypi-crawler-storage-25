"""Static descriptor data for the keeper-migrate shim.

``absorption_subset`` marks verbs ratified for keeper-migrate absorption.
``standalone_only`` marks DSK utilities advertised for direct DSK consumers but
not for keeper-migrate wrapper subcommands.
"""

from __future__ import annotations

from typing import Any

SHIM_CONTRACT_VERSION = "1.0"
OUTPUT_CONTRACT_VERSIONS_SUPPORTED = ["1.0", "1.1", "1.2-draft"]
SIGNATURE_BACKENDS = ["minisign"]
SUPPORTED_VERBS = [
    "adopt",
    "plan",
    "apply",
    "diff",
    "audit_explain",
    "drift_watch",
    "rehearse_report",
    "bundle",
    "verify",
    "discover",
]


def _verb(
    name: str,
    cli: str,
    library: str,
    inputs: list[str],
    outputs: list[str],
    click_params: list[str],
    *,
    idempotent: bool,
    session: bool,
    mode: str,
    absorption_subset: bool = True,
    standalone_only: bool = False,
    deprecated_aliases: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "name": name,
        "signature": cli,
        "cli_signature": cli,
        "library_signature": library,
        "contract_inputs": inputs,
        "contract_outputs": outputs,
        "click_params": click_params,
        "is_idempotent": idempotent,
        "requires_keeper_session": session,
        "keeper_session_mode": mode,
        "absorption_subset": absorption_subset,
        "standalone_only": standalone_only,
        "deprecated_aliases": list(deprecated_aliases or []),
    }


VERB_DESCRIPTORS: dict[str, dict[str, Any]] = {
    "adopt": _verb(
        "adopt",
        "dsk import-from-keepercmd RUN_DIR [--output FILE] [--dry-run]",
        "dsk.shim.adopt(run_dir: Path, ...) -> ImportResult",
        ["keeperCMD run-dir", "OUTPUT_CONTRACT artifacts"],
        ["DSK manifest YAML", "ownership marker adoption report"],
        [
            "run_dir",
            "output",
            "dry_run",
            "auto_approve",
            "skip_audit_verify",
            "skip_sha256",
            "suspect_threshold",
            "verbose",
            "require_output_signature",
            "signature_pubkey",
            "signature_pubkey_keeper_record",
            "commander_config",
        ],
        idempotent=True,
        session=True,
        mode="required only when dry_run is false or Keeper pubkey lookup is used",
        deprecated_aliases=["import_from_keepercmd"],
    ),
    "plan": _verb(
        "plan",
        "dsk plan MANIFEST [--json] [--allow-delete] [--provider mock|commander|service]",
        "dsk.shim.plan(target_state: Path, ...) -> Plan",
        ["DSK manifest path"],
        ["dsk.core.planner.Plan"],
        ["manifest_path", "allow_delete", "as_json", "output_format", "provider_override"],
        idempotent=True,
        session=True,
        mode="required for commander/service providers; mock stays offline",
    ),
    "apply": _verb(
        "apply",
        "dsk apply MANIFEST [--dry-run] [--allow-delete] [--auto-approve]",
        "dsk.shim.apply(plan: Plan | Path, ...) -> ApplyResult",
        ["DSK plan object or manifest path"],
        ["apply outcome text", "exit code"],
        ["manifest_path", "allow_delete", "auto_approve", "dry_run", "provider_override"],
        idempotent=False,
        session=True,
        mode="required for non-mock providers and real mutations",
    ),
    "diff": _verb(
        "diff",
        "dsk diff MANIFEST [--allow-delete]",
        "dsk.shim.diff(manifest_path: Path, ...) -> ShimCommandResult",
        ["DSK manifest path"],
        ["field-level diff text", "exit code"],
        ["manifest_path", "allow_delete"],
        idempotent=True,
        session=True,
        mode="required for commander/service providers; mock stays offline",
    ),
    "verify": _verb(
        "verify",
        "dsk verify RUN_DIR [--strict] [--require-output-signature]",
        "dsk.shim.verify(run_dir: Path, ...) -> VerifyResult",
        ["keeperCMD run-dir"],
        ["integrity verification table", "exit code"],
        [
            "run_dir",
            "strict",
            "require_output_signature",
            "signature_pubkey",
            "signature_pubkey_keeper_record",
        ],
        idempotent=True,
        session=False,
        mode="offline unless Keeper pubkey lookup is requested",
        absorption_subset=False,
        standalone_only=True,
    ),
    "audit_explain": _verb(
        "audit_explain",
        "dsk audit explain AUDIT_LOG [--summary]",
        "dsk.shim.audit_explain(audit_log: Path, ...) -> AuditExplanation",
        ["keeperCMD audit.log"],
        ["audit chain explanation", "operation counts"],
        ["audit_log", "summary"],
        idempotent=True,
        session=False,
        mode="offline",
        deprecated_aliases=["audit"],
    ),
    "drift_watch": _verb(
        "drift_watch",
        "dsk drift-watch MANIFEST...",
        "dsk.shim.drift_watch(manifest_paths: Sequence[Path], ...) -> ShimCommandResult",
        ["one or more DSK manifest paths"],
        ["drift report", "exit code"],
        [
            "manifest_paths",
            "interval",
            "github_repo",
            "github_token",
            "pr_base",
            "dry_run",
            "slack_webhook",
            "slack_channel",
            "servicenow_instance",
            "servicenow_api_key",
            "verbose",
        ],
        idempotent=True,
        session=True,
        mode="required for live providers; mock remains offline",
    ),
    "rehearse_report": _verb(
        "rehearse_report",
        "dsk rehearse-report RUN_DIR [--dry-run] [--format text|junit]",
        "dsk.shim.rehearse_report(run_dir: Path, ...) -> ShimCommandResult",
        ["keeperCMD rehearsal run-dir"],
        ["drift report text or JUnit XML", "exit code"],
        ["run_dir", "output", "dry_run", "verbose", "output_format"],
        idempotent=True,
        session=True,
        mode="dry-run/report generation is offline; real adoption paths may need Commander",
    ),
    "bundle": _verb(
        "bundle",
        "dsk bundle MANIFEST [--dry-run] [--output-dir DIR]",
        "dsk.shim.bundle(manifest_path: Path, ...) -> Bundle",
        ["compliance-bundle.v1 manifest"],
        ["bundle-index.json", "evidence files"],
        ["manifest_path", "dry_run", "output_dir"],
        idempotent=True,
        session=True,
        mode="dry-run is offline; report collection needs Commander",
    ),
    "discover": _verb(
        "discover",
        "dsk discover [OPTIONS]",
        "dsk.shim.discover(output: Path, ...) -> ShimCommandResult",
        ["provider options"],
        ["discovered manifest skeleton"],
        ["provider", "input_path", "output", "name"],
        idempotent=True,
        session=True,
        mode="required for live discovery; mock remains offline",
        absorption_subset=False,
        standalone_only=True,
    ),
}


def build_descriptor(
    dsk_version: str, output_contract_version: str | None = None
) -> dict[str, Any]:
    """Build the JSON-serializable shim descriptor."""

    if (
        output_contract_version is not None
        and output_contract_version not in OUTPUT_CONTRACT_VERSIONS_SUPPORTED
    ):
        supported = ", ".join(OUTPUT_CONTRACT_VERSIONS_SUPPORTED)
        raise ValueError(
            f"unsupported output contract version {output_contract_version!r}; "
            f"supported: {supported}"
        )
    return {
        "shim_contract_version": SHIM_CONTRACT_VERSION,
        "dsk_version": dsk_version,
        "supported_verbs": list(SUPPORTED_VERBS),
        "verbs": {key: dict(value) for key, value in VERB_DESCRIPTORS.items()},
        "output_contract_versions_supported": list(OUTPUT_CONTRACT_VERSIONS_SUPPORTED),
        "negotiated_output_contract_version": output_contract_version or "1.1",
        "signature_backends": list(SIGNATURE_BACKENDS),
    }
