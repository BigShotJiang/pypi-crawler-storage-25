"""Keeper Declarative SDK package root.

The semver-protected absorption API is intentionally small. Names exported
through ``__all__`` are the stable surface consumed by keeper-migrate shim
subcommands; standalone DSK modules remain importable through their module
paths without being part of that absorption contract.
"""

from __future__ import annotations

from importlib import metadata

from dsk import shim as shim
from dsk.core.models_ksm import KsmManifestV1
from dsk.core.models_policy import PolicyManifestV1
from dsk.core.sharing_models import SharingManifestV1
from dsk.core.vault_models import VaultManifestV1


def _package_version() -> str:
    try:
        return metadata.version("dsk")
    except metadata.PackageNotFoundError:
        pass
    return "2.21.0"


__version__ = _package_version()

__all__ = [
    "shim",
    "VaultManifestV1",
    "SharingManifestV1",
    "KsmManifestV1",
    "PolicyManifestV1",
    "__version__",
]
