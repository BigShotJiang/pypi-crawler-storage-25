"""`dsk audit` forensic helpers."""

from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from dsk._obs import get_logger, log_event
from dsk.cli.audit_chain import AuditChainCorrupt, AuditExplainResult, explain_audit_log

EXIT_OK = 0
EXIT_GENERIC = 1
EXIT_CAPABILITY = 5
_LOG = get_logger(__name__)


def _short(value: str, *, length: int = 12) -> str:
    if not value:
        return "-"
    return value[:length]


def _print_chain(console: Console, result: AuditExplainResult) -> None:
    table = Table(title=f"audit.log SHA256 chain: {result.path}")
    table.add_column("Line", justify="right")
    table.add_column("Status")
    table.add_column("Operation")
    table.add_column("Prev")
    table.add_column("Signature")
    table.add_column("Line hash")
    table.add_column("Context")

    for entry in result.entries:
        status = "[green]ok[/]" if entry.ok else "[red]FAIL[/]"
        context = entry.error or entry.raw_context
        table.add_row(
            str(entry.line_no),
            status,
            entry.operation,
            _short(entry.prev_hash),
            _short(entry.signature),
            _short(entry.line_hash),
            context,
        )

    console.print(table)
    if result.failures:
        console.print("failures:")
        for failure in result.failures:
            console.print(f"  line {failure.line_no}: {failure.error}")


def _print_summary(console: Console, result: AuditExplainResult) -> None:
    summary = Table(title="audit.log summary")
    summary.add_column("Metric")
    summary.add_column("Value")

    started, finished = result.time_span
    summary.add_row("entries", str(len(result.entries)))
    summary.add_row("failures", str(len(result.failures)))
    summary.add_row("time_start", started or "-")
    summary.add_row("time_end", finished or "-")
    summary.add_row(
        "operations",
        ", ".join(f"{name}={count}" for name, count in sorted(result.operation_counts.items()))
        or "-",
    )
    summary.add_row(
        "suspicious_patterns",
        "; ".join(result.suspicious_patterns) if result.suspicious_patterns else "-",
    )
    console.print(summary)


def _render_audit_explain_result(
    console: Console, result: AuditExplainResult, *, summary: bool
) -> int:
    _print_chain(console, result)
    if summary:
        _print_summary(console, result)

    if result.failures:
        console.print(f"[red]audit chain corrupt:[/] {len(result.failures)} failure(s)")
        return EXIT_CAPABILITY

    console.print("[green]audit chain verified[/]")
    return EXIT_OK


@click.group("audit")
def audit_cmd() -> None:
    """Audit log inspection and forensics helpers."""


@audit_cmd.command("explain")
@click.argument("audit_log", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--summary", is_flag=True, default=False, help="Print operation counts and span.")
def audit_explain_cmd(audit_log: Path, summary: bool) -> None:
    """Explain a keeperCMD audit.log SHA256 chain line by line."""

    console = Console()
    log_event(_LOG, "cli.audit_explain.start", audit_log=str(audit_log), summary=summary)
    try:
        result = explain_audit_log(audit_log)
    except AuditChainCorrupt as exc:
        console.print(f"[red]error:[/] {exc}")
        sys.exit(EXIT_GENERIC)

    exit_code = _render_audit_explain_result(console, result, summary=summary)
    log_event(
        _LOG,
        "cli.audit_explain.complete",
        audit_log=str(audit_log),
        failures=len(result.failures),
        exit_code=exit_code,
    )
    sys.exit(exit_code)
