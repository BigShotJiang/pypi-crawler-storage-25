"""dsk rehearse-report — DSK consumer for keeperCMD service-mode rehearsal run-dirs.

:public: CLI command surface and report schema are public preview API.
:internal: Helper functions remain internal until D9 R1 exits stub status.

Phase: D9 R1 stub — API shape locked, implementation pending D1 fixture.

Contract (to be implemented):
    Input:  a keeperCMD rehearsal run-dir produced by ``keeper-migrate rehearse``
            (same artifact shape as a migration run-dir: audit.log, manifest.csv,
            inventory.json, records_import.json, SHA256SUMS.txt)
    Output: a drift report — JSON summary of what DSK would plan/create/update
            after consuming the rehearsal run-dir via ``dsk import-from-keepercmd``

Design notes (from shared/context/d9-service-mode-rehearsal-proposal.md):
    - Bob (keeperCMD side) owns the runner/auth/orchestration (~3 days, R0 phase)
    - Midas (DSK side) owns this consumer and the drift report format (~2 hr, R1 phase)
    - R1 is gated on D1 (anonymised rehearsal-16 fixture) for meaningful testing
    - The JUnit-compatible report schema (R2) will wrap this command's output

Drift report schema (proposed, subject to R2 alignment with Bob):
    {
        "run_dir": str,              # absolute path to the rehearsal run-dir
        "dsk_version": str,          # dsk.__version__
        "contract_version": str,     # _contract_version from inventory.json or "1.0"
        "import_exit_code": int,     # exit code from dsk import-from-keepercmd
        "records_total": int,        # rows in manifest.csv
        "records_adopted": int,      # successfully adopted (ownership marker written)
        "records_suspect": int,      # flagged as suspect
        "records_error": int,        # errored during adoption
        "plan_summary": {            # from dsk plan after import
            "creates": int,
            "updates": int,
            "deletes": int,
        },
        "warnings": list[str],       # custom-type passthrough warnings etc.
        "errors": list[str],         # any hard errors
    }
"""

from __future__ import annotations

import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

import click
from rich.console import Console


@click.command("rehearse-report")
@click.argument("run_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--output", "-o", default="", help="Write JSON report to FILE (default: stdout).")
@click.option("--dry-run", is_flag=True, default=False, help="Do not write ownership markers.")
@click.option("--verbose", "-v", is_flag=True, default=False)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "junit"]),
    default="text",
    help="Output format: text (default) or junit XML.",
)
def rehearse_report_cmd(
    run_dir: Path,
    output: str,
    dry_run: bool,
    verbose: bool,
    output_format: str,
) -> None:
    """Consume a keeperCMD rehearsal run-dir and emit a DSK drift report.

    RUN_DIR must be a keeperCMD-produced run-dir (audit.log, manifest.csv,
    inventory.json, SHA256SUMS.txt).  Runs dsk import-from-keepercmd internally
    and captures a structured drift summary for CI / JUnit reporting (D9 R1/R2).

    \b
    STATUS: stub — implementation pending D1 anonymised fixture (D9 R1 gate).
    """
    if output_format == "junit":
        suite = ET.Element(
            "testsuite",
            name="dsk.rehearse",
            tests="1",
            failures="0",
            errors="0",
            time="0",
        )
        tc = ET.SubElement(suite, "testcase", name="rehearse_report", classname="dsk.rehearse")
        ET.SubElement(tc, "skipped", message="D9 R1 stub — not yet implemented")
        try:
            ET.indent(suite)
        except AttributeError:
            pass
        click.echo(ET.tostring(suite, encoding="unicode", xml_declaration=False))
        sys.exit(1)

    console = Console(stderr=True)
    console.print(
        "[yellow]warn:[/] rehearse-report is a D9 R1 stub — not yet implemented. "
        "Implementation is gated on D1 fixture availability. "
        "Use [bold]dsk import-from-keepercmd[/] directly for now."
    )
    sys.exit(1)


def _build_junit_xml(report: dict[str, Any], suite_name: str = "dsk.rehearse") -> str:
    """Convert a drift report dict to a JUnit XML string.

    Each pipeline stage becomes a ``<testcase>``; a stage fails when the
    corresponding field exceeds the expected threshold.  The returned string is
    a well-formed XML document suitable for consumption by CI systems (Jenkins,
    GitHub Actions test-reporter, etc.).

    Exit-code constants (DSK):
        EXIT_AUDIT    = 3  → audit-chain verification failed
        EXIT_CHECKSUM = 4  → SHA-256 checksum verification failed
    """
    _EXIT_AUDIT = 3
    _EXIT_CHECKSUM = 4

    import_exit_code: int = report.get("import_exit_code", 0)
    plan: dict[str, int] = report.get("plan_summary", {"creates": 0, "updates": 0, "deletes": 0})
    records_suspect: int = report.get("records_suspect", 0)
    warnings: list[str] = report.get("warnings", [])

    cases: list[tuple[str, bool, str]] = [
        (
            "audit_chain_verify",
            import_exit_code != _EXIT_AUDIT,
            f"import exited {import_exit_code} (EXIT_AUDIT={_EXIT_AUDIT})",
        ),
        (
            "sha256sums_verify",
            import_exit_code != _EXIT_CHECKSUM,
            f"import exited {import_exit_code} (EXIT_CHECKSUM={_EXIT_CHECKSUM})",
        ),
        (
            "records_import",
            import_exit_code == 0,
            f"import exited {import_exit_code} (expected 0)",
        ),
        (
            "drift_plan_creates",
            plan.get("creates", 0) == 0,
            f"unexpected creates: {plan.get('creates', 0)}",
        ),
        (
            "drift_plan_deletes",
            plan.get("deletes", 0) == 0,
            f"unexpected deletes: {plan.get('deletes', 0)}",
        ),
        (
            "suspect_markers",
            records_suspect == 0,
            f"suspect record count: {records_suspect}",
        ),
        (
            "custom_type_warnings",
            len(warnings) == 0,
            "; ".join(warnings),
        ),
    ]

    failures = sum(1 for _, passed, _ in cases if not passed)

    suite = ET.Element(
        "testsuite",
        name=suite_name,
        tests=str(len(cases)),
        failures=str(failures),
        errors="0",
        time="0",
    )

    for name, passed, failure_msg in cases:
        tc = ET.SubElement(suite, "testcase", name=name, classname=suite_name)
        if not passed:
            ET.SubElement(tc, "failure", message=failure_msg)

    try:
        ET.indent(suite)
    except AttributeError:
        pass

    return ET.tostring(suite, encoding="unicode", xml_declaration=False)


def _build_drift_report(
    run_dir: Path,
    import_outcomes: list[dict[str, Any]],
    plan_summary: dict[str, int],
    contract_version: str,
    warnings: list[str],
    errors: list[str],
) -> dict[str, Any]:
    """Build the structured drift report dict (used by rehearse_report_cmd when implemented).

    This function is the integration seam for D9 R1. Call it after running
    ``dsk import-from-keepercmd`` and ``dsk plan``, passing their structured outputs.
    The return value is JSON-serialisable and maps directly to the drift report schema
    documented in this module's docstring.
    """
    statuses = [str(row.get("status", "")) for row in import_outcomes]
    return {
        "run_dir": str(run_dir.resolve()),
        "dsk_version": _dsk_version(),
        "contract_version": contract_version,
        "import_exit_code": 0 if not errors else 1,
        "records_total": len(import_outcomes),
        "records_adopted": statuses.count("adopted"),
        "records_suspect": statuses.count("suspect"),
        "records_error": statuses.count("error"),
        "plan_summary": {
            "creates": int(plan_summary.get("creates", 0)),
            "updates": int(plan_summary.get("updates", 0)),
            "deletes": int(plan_summary.get("deletes", 0)),
        },
        "warnings": list(warnings),
        "errors": list(errors),
    }


def _dsk_version() -> str:
    try:
        from dsk import __version__
    except Exception:  # pragma: no cover - defensive import guard
        return "unknown"
    return __version__
