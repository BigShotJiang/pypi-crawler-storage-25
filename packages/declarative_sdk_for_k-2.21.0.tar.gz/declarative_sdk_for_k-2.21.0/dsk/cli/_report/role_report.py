"""Enterprise role-report: role-list + per-role JSON + enforcement catalog."""

from __future__ import annotations

import json
from typing import Any

import dsk.cli._report.runner as keeper_runner
from dsk.cli._report.common import (
    build_envelope,
    parse_report_json_array,
    prepare_report_rows,
)
from dsk.core.errors import CapabilityError

_ROLE_LIST_COLUMNS = ("role_id", "name", "node")


def _enforcement_catalog_keys() -> tuple[list[str], int]:
    from keepercommander import constants as kc_constants

    keys = sorted({key for _, key, _ in kc_constants.enforcement_list()})
    return keys, len(keys)


def _role_list_argv(*, node: str | None) -> list[str]:
    argv = [
        "enterprise-info",
        "-r",
        "-v",
        "--format",
        "json",
        "--columns",
        ",".join(_ROLE_LIST_COLUMNS),
    ]
    if node:
        argv.extend(["--node", node])
    return argv


def _parse_role_info_stdout(raw: str) -> dict[str, Any]:
    text = (raw or "").strip()
    if not text:
        raise CapabilityError(
            reason="enterprise-role JSON stdout was empty",
            next_action="run `keeper enterprise-role <ROLE> --format json` manually",
        )
    try:
        parsed: Any = json.loads(text)
    except json.JSONDecodeError as exc:
        raise CapabilityError(
            reason=f"enterprise-role returned non-JSON stdout: {exc}",
            context={"head": text[:400]},
            next_action="inspect Commander output format",
        ) from exc

    if isinstance(parsed, dict):
        return parsed
    if isinstance(parsed, list):
        if len(parsed) != 1:
            raise CapabilityError(
                reason="enterprise-role JSON list must contain exactly one role object",
                context={"sample": str(parsed)[:200]},
                next_action="use a single role argument with `--format json`",
            )
        item = parsed[0]
        if not isinstance(item, dict):
            raise CapabilityError(
                reason="enterprise-role JSON row was not an object",
                context={"sample": str(item)[:200]},
                next_action="upgrade Keeper Commander to a compatible version",
            )
        return item

    raise CapabilityError(
        reason="unexpected enterprise-role JSON type",
        context={"sample": str(parsed)[:200]},
        next_action="inspect Commander stdout",
    )


def _summarize_role(*, role_info: dict[str, Any]) -> dict[str, Any]:
    enforcements = role_info.get("enforcements") or {}
    if not isinstance(enforcements, dict):
        enforcements = {}

    return {
        "role_id": role_info.get("role_id"),
        "name": role_info.get("name"),
        "node_id": role_info.get("node_id"),
        "node_path": role_info.get("node_name"),
        "default_role": bool(role_info.get("default_role")),
        "enforcements": enforcements,
        "enforcement_policy_count": len(enforcements),
        "member_users": role_info.get("users") or [],
        "member_teams": role_info.get("teams") or [],
        "scoped_nodes": role_info.get("managed_nodes") or [],
    }


def run_role_report(
    *,
    node: str | None = None,
    role: str | None = None,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None = None,
    config_file: str | None = None,
    password: str | None = None,
) -> dict[str, Any]:
    """List roles (``enterprise-info -r``) and enrich each with ``enterprise-role --format json``."""
    catalog_keys, catalog_count = _enforcement_catalog_keys()
    list_raw = keeper_runner.run_keeper_batch(
        _role_list_argv(node=node),
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )
    list_rows = parse_report_json_array(
        list_raw,
        command="enterprise-info -r -v --format json",
    )

    if role:
        wanted = str(role).strip().lower()
        list_rows = [
            row
            for row in list_rows
            if str(row.get("role_id", "")).lower() == wanted
            or str(row.get("name", "")).lower() == wanted
        ]

    merged: list[dict[str, Any]] = []
    for row in list_rows:
        rid = row.get("role_id")
        if rid is None:
            continue
        info_raw = keeper_runner.run_keeper_batch(
            ["enterprise-role", str(rid), "--format", "json"],
            keeper_bin=keeper_bin,
            config_file=config_file,
            password=password,
        )
        role_info = _parse_role_info_stdout(info_raw)
        merged.append(_summarize_role(role_info=role_info))

    fingerprint_keys = (
        "role_id",
        "node_id",
        "team_id",
        "user_id",
        "team_uid",
    )
    sanitized_rows = prepare_report_rows(
        merged,
        sanitize_uids=sanitize_uids,
        quiet=quiet,
        fingerprint_keys=fingerprint_keys,
    )

    return build_envelope(
        command="role-report",
        rows=sanitized_rows,
        meta={
            "sources": [
                "enterprise-info -r (role-list)",
                "enterprise-role --format json (role-info)",
                "keepercommander.constants.enforcement_list (enforcement-list)",
            ],
            "role_list_columns": list(_ROLE_LIST_COLUMNS),
            "node": node or "",
            "role_filter": role or "",
            "quiet": quiet,
            "sanitize_uids": sanitize_uids,
            "role_count": len(sanitized_rows),
            "enforcement_catalog_count": catalog_count,
            "enforcement_catalog_keys": catalog_keys,
        },
    )
