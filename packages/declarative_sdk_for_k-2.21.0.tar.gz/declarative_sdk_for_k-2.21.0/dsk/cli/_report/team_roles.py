"""Enterprise team/role reports backed by Commander ``enterprise-info``."""

from __future__ import annotations

from typing import Any

import dsk.cli._report.runner as keeper_runner
from dsk.cli._report.common import (
    build_envelope,
    parse_report_json_array,
    prepare_report_rows,
)

_TEAM_COLUMNS = (
    "restricts",
    "node",
    "user_count",
    "users",
    "queued_user_count",
    "queued_users",
    "role_count",
    "roles",
)
_ROLE_COLUMNS = (
    "visible_below",
    "default_role",
    "admin",
    "node",
    "user_count",
    "users",
    "team_count",
    "teams",
    "enforcement_count",
    "enforcements",
    "managed_node_count",
    "managed_nodes",
    "managed_nodes_permissions",
)
# Columns for ``dsk report team-roles``: teams expose role names per team; roles
# supply ``managed_nodes_permissions`` (JSON matrix from Commander).
_TEAM_ROLES_TEAM_COLUMNS = ("restricts", "node", "role_count", "roles")
_TEAM_ROLES_ROLE_COLUMNS = ("managed_nodes_permissions",)


def _enterprise_info_rows(
    argv: list[str],
    *,
    command: str,
    keeper_bin: str | None,
    config_file: str | None,
    password: str | None,
) -> list[dict[str, Any]]:
    raw = keeper_runner.run_keeper_batch(
        argv, keeper_bin=keeper_bin, config_file=config_file, password=password
    )
    raw = keeper_runner.extract_json_array_stdout(raw)
    return parse_report_json_array(raw, command=command)


def _enterprise_info_argv(
    selector: str,
    columns: tuple[str, ...],
    *,
    node: str | None = None,
) -> list[str]:
    argv = [
        "enterprise-info",
        selector,
        "-v",
        "--format",
        "json",
        "--columns",
        ",".join(columns),
    ]
    if node:
        argv.extend(["--node", node])
    return argv


def _team_rows(
    columns: tuple[str, ...],
    *,
    node: str | None = None,
    keeper_bin: str | None,
    config_file: str | None,
    password: str | None,
) -> list[dict[str, Any]]:
    return _enterprise_info_rows(
        _enterprise_info_argv("-t", columns, node=node),
        command="enterprise-info -t -v --format json",
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )


def _role_rows(
    columns: tuple[str, ...],
    *,
    node: str | None = None,
    keeper_bin: str | None,
    config_file: str | None,
    password: str | None,
) -> list[dict[str, Any]]:
    return _enterprise_info_rows(
        _enterprise_info_argv("-r", columns, node=node),
        command="enterprise-info -r -v --format json",
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )


def run_team_report(
    *,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None = None,
    config_file: str | None = None,
    password: str | None = None,
) -> dict[str, Any]:
    """Run ``keeper enterprise-info -t -v --format json``."""
    rows = _team_rows(
        _TEAM_COLUMNS,
        node=None,
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )
    sanitized_rows = prepare_report_rows(
        rows,
        sanitize_uids=sanitize_uids,
        quiet=quiet,
        fingerprint_keys=("team_uid",),
    )
    return build_envelope(
        command="team-report",
        rows=sanitized_rows,
        meta={
            "source": "enterprise-info",
            "selector": "teams",
            "columns": list(_TEAM_COLUMNS),
            "quiet": quiet,
            "sanitize_uids": sanitize_uids,
        },
    )


def run_role_report(
    *,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None = None,
    config_file: str | None = None,
    password: str | None = None,
) -> dict[str, Any]:
    """Run ``keeper enterprise-info -r -v --format json``."""
    rows = _role_rows(
        _ROLE_COLUMNS,
        node=None,
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )
    sanitized_rows = prepare_report_rows(
        rows,
        sanitize_uids=sanitize_uids,
        quiet=quiet,
        fingerprint_keys=("role_id",),
    )
    return build_envelope(
        command="role-report",
        rows=sanitized_rows,
        meta={
            "source": "enterprise-info",
            "selector": "roles",
            "columns": list(_ROLE_COLUMNS),
            "quiet": quiet,
            "sanitize_uids": sanitize_uids,
        },
    )


def _binding_rows_from_team_role_lists(
    team_rows: list[dict[str, Any]],
    role_rows: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Pair enterprise-info team rows with role rows by role display name.

    Commander team JSON exposes bound roles as **names** only; pairing uses the
    role ``name`` field (first match wins if duplicate names exist).
    """
    role_by_name: dict[str, dict[str, Any]] = {}
    for r in role_rows:
        name = r.get("name")
        if isinstance(name, str) and name:
            role_by_name.setdefault(name, r)

    shells: list[dict[str, Any]] = []
    bindings: list[dict[str, Any]] = []
    for t in team_rows:
        team_uid = t.get("team_uid")
        if team_uid is None:
            continue
        shells.append(
            {
                "team_uid": team_uid,
                "team_name": t.get("name"),
                "node": t.get("node"),
                "restricts": t.get("restricts"),
            }
        )
        role_names = t.get("roles") or []
        if not isinstance(role_names, list):
            role_names = []
        for rn in role_names:
            if not isinstance(rn, str):
                continue
            rr = role_by_name.get(rn)
            if not rr:
                continue
            bindings.append(
                {
                    "team_uid": team_uid,
                    "team_name": t.get("name"),
                    "node": t.get("node"),
                    "restricts": t.get("restricts"),
                    "role_id": None if rr.get("role_id") is None else str(rr.get("role_id")),
                    "role_name": rr.get("name"),
                    "permissions": rr.get("managed_nodes_permissions") or [],
                }
            )
    return bindings, shells


def _nest_team_roles_matrix(
    shells: list[dict[str, Any]],
    sanitized_bindings: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    by_team: dict[Any, list[dict[str, Any]]] = {}
    for b in sanitized_bindings:
        uid = b.get("team_uid")
        by_team.setdefault(uid, []).append(b)

    nested: list[dict[str, Any]] = []
    for shell in shells:
        uid = shell["team_uid"]
        role_entries = []
        for b in by_team.get(uid, []):
            role_entries.append(
                {
                    "role_id": b.get("role_id"),
                    "role_name": b.get("role_name"),
                    "permissions": b.get("permissions") or [],
                }
            )
        nested.append(
            {
                "team_uid": uid,
                "team_name": shell.get("team_name"),
                "node": shell.get("node"),
                "restricts": shell.get("restricts"),
                "roles": role_entries,
            }
        )
    return nested


def run_team_roles_report(
    *,
    node: str | None,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None = None,
    config_file: str | None = None,
    password: str | None = None,
) -> dict[str, Any]:
    """Team → roles → managed-node permission matrix via ``enterprise-info``.

    Uses Commander ``enterprise-info`` team list and role list (same source as
    ``keeper_commander.commands.enterprise`` enterprise-info selectors ``-t`` /
    ``-r``), joining ``role_teams`` edges exposed as team ``roles`` names plus
    role ``managed_nodes_permissions`` JSON.
    """
    team_rows = _team_rows(
        _TEAM_ROLES_TEAM_COLUMNS,
        node=node,
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )
    role_rows = _role_rows(
        _TEAM_ROLES_ROLE_COLUMNS,
        node=node,
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )
    raw_bindings, shells = _binding_rows_from_team_role_lists(team_rows, role_rows)
    sanitized_bindings = prepare_report_rows(
        raw_bindings,
        sanitize_uids=sanitize_uids,
        quiet=quiet,
        fingerprint_keys=("team_uid", "role_id"),
    )
    sanitized_shells = prepare_report_rows(
        shells,
        sanitize_uids=sanitize_uids,
        quiet=quiet,
        fingerprint_keys=("team_uid",),
    )
    matrix_rows = _nest_team_roles_matrix(sanitized_shells, sanitized_bindings)
    return build_envelope(
        command="team-roles",
        rows=matrix_rows,
        meta={
            "source": "enterprise-info",
            "node": node or "",
            "team_columns": list(_TEAM_ROLES_TEAM_COLUMNS),
            "role_columns": list(_TEAM_ROLES_ROLE_COLUMNS),
            "team_count": len(team_rows),
            "role_count": len(role_rows),
            "binding_count": len(raw_bindings),
            "quiet": quiet,
            "sanitize_uids": sanitize_uids,
        },
    )
