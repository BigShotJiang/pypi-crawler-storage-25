"""Vault posture summary from Commander ``list-records`` JSON output."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from collections.abc import Iterable, Mapping
from datetime import UTC, datetime, timedelta
from typing import Any

import dsk.cli._report.runner as keeper_runner
from dsk.cli._report.common import prepare_report_rows
from dsk.core.errors import CapabilityError

_COMMAND = "list-records"
_SF_COMMAND = "shared-folder-list"
_ISSUES = (
    "no_password",
    "weak_password",
    "reused_password",
    "shared_over_threshold",
    "no_rotation_policy",
    "stale",
    "orphan",
)
_FOLDER_KEYS = (
    "folder_uid",
    "folderUid",
    "user_folder_uid",
    "userFolderUid",
    "parent_uid",
    "parentUid",
)
_SF_LINK_KEYS = (
    "shared_folder_uid",
    "sharedFolderUid",
    "shared_folderUid",
    "sf_uid",
    "sharedFolder",
)
_SF_ROW_UID_KEYS = ("shared_folder_uid", "sharedFolderUid", "uid", "folder_uid", "folderUid")
_SF_ROW_NAME_KEYS = ("name", "title", "folder", "path")
_SF_ROW_COUNT_KEYS = ("record_count", "recordCount", "records", "size")
_UID_KEYS = ("record_uid", "recordUid", "uid", "recordUID")
_TITLE_KEYS = ("title", "name")
_TYPE_KEYS = ("type", "record_type", "recordType")
_PASSWORD_KEYS = ("password", "Password")
_HAS_PASSWORD_KEYS = (
    "has_password",
    "hasPassword",
    "password_present",
    "passwordPresent",
    "hasPasswordField",
)
_WEAK_KEYS = (
    "weak",
    "weak_password",
    "weakPassword",
    "password_weak",
    "passwordWeak",
    "is_weak",
    "isWeak",
    "strength",
    "password_strength",
    "passwordStrength",
    "password_status",
    "passwordStatus",
    "password_score",
    "passwordScore",
    "score",
    "breachwatch_status",
    "breachwatchStatus",
)
_WEAK_SCORE_KEYS = {"password_score", "passwordScore", "score"}
_SHARED_COUNT_KEYS = (
    "shared_user_count",
    "sharedUserCount",
    "share_user_count",
    "shareUserCount",
    "user_share_count",
    "userShareCount",
)
_SHARED_CONTAINER_KEYS = (
    "shared_users",
    "sharedUsers",
    "user_shares",
    "userShares",
    "sharees",
    "shares",
    "permissions",
)
_ROTATION_KEYS = (
    "rotation_policy",
    "rotationPolicy",
    "rotation_settings",
    "rotationSettings",
    "rotation_schedule",
    "rotationSchedule",
    "pam_rotation",
    "pamRotation",
    "record_rotation",
    "recordRotation",
)
_ROTATION_ENABLED_KEYS = (
    "rotation_enabled",
    "rotationEnabled",
    "rotate_on_expiration",
    "rotateOnExpiration",
)
_MODIFIED_KEYS = (
    "modified",
    "modified_time",
    "modifiedTime",
    "last_modified",
    "lastModified",
    "client_modified_time",
    "clientModifiedTime",
    "updated_at",
    "updatedAt",
)
_EMPTY_STRINGS = {"", "-", "none", "null", "n/a", "na"}
_FALSE_STRINGS = _EMPTY_STRINGS | {"false", "off", "disabled", "no", "0"}
_WEAK_STRINGS = {
    "weak",
    "very weak",
    "poor",
    "low",
    "bad",
    "fail",
    "failed",
    "at risk",
    "risk",
    "compromised",
    "breached",
}


def run_vault_health_report(
    *,
    shared_threshold: int,
    stale_days: int,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None = None,
    config_file: str | None = None,
    password: str | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Run Commander ``list-records`` + ``shared-folder-list`` JSON and return posture findings."""
    raw = keeper_runner.run_keeper_batch(
        [_COMMAND, "--format", "json"],
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )
    rows = _parse_list_records(raw)
    raw_sf = keeper_runner.run_keeper_batch(
        [_SF_COMMAND, "--format", "json"],
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )
    sf_rows = _parse_shared_folder_list(raw_sf)
    checked_at = _coerce_utc(now or datetime.now(UTC))
    reused_uids = _reused_password_record_uids(rows)
    records = [
        finding
        for finding in (
            _record_finding(
                row,
                shared_threshold=shared_threshold,
                stale_days=stale_days,
                now=checked_at,
                reused_password_uids=reused_uids,
            )
            for row in rows
        )
        if finding is not None
    ]
    record_count_by_type = _record_counts_by_type(rows)
    per_sf_from_records = _record_counts_per_shared_folder(rows)
    shared_folders_table = _merge_shared_folder_rows(sf_rows, per_sf_from_records)
    summary = _build_summary(
        total_records=len(rows),
        records=records,
        record_count_by_type=record_count_by_type,
        shared_folder_count=len(shared_folders_table),
    )
    sanitized_records = prepare_report_rows(
        records,
        sanitize_uids=sanitize_uids,
        quiet=quiet,
        fingerprint_keys=("record_uid", "shared_folder_uid"),
    )
    sanitized_sf = prepare_report_rows(
        shared_folders_table,
        sanitize_uids=sanitize_uids,
        quiet=quiet,
        fingerprint_keys=("shared_folder_uid",),
    )
    return {
        "dsk_report_version": 1,
        "command": "vault-health",
        "summary": summary,
        "records": sanitized_records,
        "meta": {
            "shared_threshold": shared_threshold,
            "stale_days": stale_days,
            "checked_at": checked_at.isoformat().replace("+00:00", "Z"),
            "quiet": quiet,
            "sanitize_uids": sanitize_uids,
            "shared_folders": sanitized_sf,
        },
    }


def _parse_list_records(raw: str) -> list[dict[str, Any]]:
    text = keeper_runner.extract_json_array_stdout(raw)
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise CapabilityError(
            reason=f"{_COMMAND} returned non-JSON stdout: {exc}",
            context={"head": (raw or "")[:400]},
            next_action="run `keeper list-records --format json` manually and inspect output",
        ) from exc

    rows: list[Any]
    if isinstance(parsed, list):
        rows = parsed
    elif isinstance(parsed, dict):
        maybe_rows = _first_list_value(parsed, ("records", "items", "rows", "data"))
        if maybe_rows is None:
            raise CapabilityError(
                reason=f"{_COMMAND} JSON object did not contain records/items/rows/data",
                context={"keys": sorted(str(k) for k in parsed.keys())[:20]},
                next_action="upgrade Keeper Commander or inspect `keeper list-records --format json`",
            )
        rows = maybe_rows
    else:
        raise CapabilityError(
            reason=f"{_COMMAND} JSON was not an array or object",
            context={"sample": str(parsed)[:200]},
            next_action="upgrade Keeper Commander to a compatible version",
        )

    out: list[dict[str, Any]] = []
    for item in rows:
        if isinstance(item, dict):
            out.append(dict(item))
        else:
            out.append({"value": item})
    return out


def _first_list_value(data: Mapping[str, Any], keys: Iterable[str]) -> list[Any] | None:
    for key in keys:
        value = data.get(key)
        if isinstance(value, list):
            return value
    return None


def _parse_shared_folder_list(raw: str) -> list[dict[str, Any]]:
    text = keeper_runner.extract_json_array_stdout(raw)
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise CapabilityError(
            reason=f"{_SF_COMMAND} returned non-JSON stdout: {exc}",
            context={"head": (raw or "")[:400]},
            next_action=f"run `keeper {_SF_COMMAND} --format json` manually and inspect output",
        ) from exc

    rows: list[Any]
    if isinstance(parsed, list):
        rows = parsed
    elif isinstance(parsed, dict):
        maybe_rows = _first_list_value(
            parsed, ("shared_folders", "folders", "items", "rows", "data", "records")
        )
        if maybe_rows is None:
            raise CapabilityError(
                reason=f"{_SF_COMMAND} JSON object did not contain shared_folders/items/rows",
                context={"keys": sorted(str(k) for k in parsed.keys())[:20]},
                next_action="upgrade Keeper Commander or inspect "
                f"`keeper {_SF_COMMAND} --format json`",
            )
        rows = maybe_rows
    else:
        raise CapabilityError(
            reason=f"{_SF_COMMAND} JSON was not an array or object",
            context={"sample": str(parsed)[:200]},
            next_action="upgrade Keeper Commander to a compatible version",
        )

    out: list[dict[str, Any]] = []
    for item in rows:
        if isinstance(item, dict):
            out.append(dict(item))
        else:
            out.append({"value": item})
    return out


def _extract_password_plaintext(row: Mapping[str, Any]) -> str | None:
    for key in _PASSWORD_KEYS:
        if key in row:
            val = row[key]
            if isinstance(val, str) and not _is_empty(val):
                return val.strip()
    for field in _iter_field_dicts(row):
        if not _field_is_password(field):
            continue
        val = field.get("value")
        if isinstance(val, list):
            for item in val:
                if isinstance(item, str) and not _is_empty(item):
                    return item.strip()
        elif isinstance(val, str) and not _is_empty(val):
            return val.strip()
    return None


def _reused_password_record_uids(rows: list[dict[str, Any]]) -> set[str]:
    digests: dict[str, list[str]] = {}
    for row in rows:
        pwd = _extract_password_plaintext(row)
        uid = _string_or_empty(_first_value(row, _UID_KEYS)).strip()
        if not pwd or not uid:
            continue
        digest = hashlib.sha256(pwd.encode("utf-8")).hexdigest()
        digests.setdefault(digest, []).append(uid)
    out: set[str] = set()
    for uids in digests.values():
        if len(uids) > 1:
            out.update(uids)
    return out


def _record_counts_by_type(rows: list[dict[str, Any]]) -> dict[str, int]:
    counts: Counter[str] = Counter()
    for row in rows:
        label = _string_or_empty(_first_value(row, _TYPE_KEYS)).strip()
        if not label:
            label = "unknown"
        counts[label] += 1
    return dict(sorted(counts.items()))


def _record_counts_per_shared_folder(rows: list[dict[str, Any]]) -> dict[str, int]:
    counts: Counter[str] = Counter()
    for row in rows:
        sf = _first_value(row, _SF_LINK_KEYS)
        if sf is None or _is_empty(sf):
            continue
        counts[str(sf).strip()] += 1
    return dict(counts)


def _merge_shared_folder_rows(
    sf_rows: list[dict[str, Any]],
    per_record_counts: Mapping[str, int],
) -> list[dict[str, Any]]:
    table: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in sf_rows:
        uid = _string_or_empty(_first_value(row, _SF_ROW_UID_KEYS)).strip()
        if not uid:
            continue
        seen.add(uid)
        name = _string_or_empty(_first_value(row, _SF_ROW_NAME_KEYS))
        cmd_count = _coerce_positive_int(_first_value(row, _SF_ROW_COUNT_KEYS))
        derived = per_record_counts.get(uid, 0)
        record_count = max(cmd_count, derived)
        table.append({"shared_folder_uid": uid, "title": name, "record_count": record_count})
    for uid, cnt in sorted(per_record_counts.items()):
        if uid in seen:
            continue
        table.append({"shared_folder_uid": uid, "title": "", "record_count": cnt})
    return table


def _coerce_positive_int(value: Any) -> int:
    if value is None or _is_empty(value):
        return 0
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return max(value, 0)
    if isinstance(value, float):
        return max(int(value), 0)
    if isinstance(value, list | tuple | set):
        return len(value)
    if isinstance(value, str):
        m = re.search(r"\d+", value)
        if m:
            return max(int(m.group(0)), 0)
        return 0
    if isinstance(value, dict):
        for key in ("count", "record_count", "size"):
            nested = value.get(key)
            if nested is not None:
                return _coerce_positive_int(nested)
    return 0


def _is_orphan_record(row: Mapping[str, Any]) -> bool:
    if _string_or_empty(_first_value(row, _SF_LINK_KEYS)).strip():
        return False
    if _string_or_empty(_first_value(row, _FOLDER_KEYS)).strip():
        return False
    return True


def _record_finding(
    row: dict[str, Any],
    *,
    shared_threshold: int,
    stale_days: int,
    now: datetime,
    reused_password_uids: set[str],
) -> dict[str, Any] | None:
    issues: list[str] = []
    if not _has_password(row):
        issues.append("no_password")
    record_uid_str = _string_or_empty(_first_value(row, _UID_KEYS)).strip()
    if record_uid_str and record_uid_str in reused_password_uids:
        issues.append("reused_password")
    if _has_weak_password_indicator(row):
        issues.append("weak_password")
    shared_user_count = _shared_user_count(row)
    if shared_user_count > shared_threshold:
        issues.append("shared_over_threshold")
    if not _has_rotation_policy(row):
        issues.append("no_rotation_policy")
    modified_at = _modified_at(row)
    if modified_at is not None and now - modified_at > timedelta(days=stale_days):
        issues.append("stale")
    if _is_orphan_record(row):
        issues.append("orphan")

    if not issues:
        return None
    sf_uid = _string_or_empty(_first_value(row, _SF_LINK_KEYS))
    return {
        "record_uid": _string_or_empty(_first_value(row, _UID_KEYS)),
        "title": _string_or_empty(_first_value(row, _TITLE_KEYS)),
        "record_type": _string_or_empty(_first_value(row, _TYPE_KEYS)),
        "shared_folder_uid": sf_uid,
        "issues": issues,
        "shared_user_count": shared_user_count,
        "modified_at": modified_at.isoformat().replace("+00:00", "Z") if modified_at else "",
    }


def _build_summary(
    *,
    total_records: int,
    records: list[dict[str, Any]],
    record_count_by_type: Mapping[str, int],
    shared_folder_count: int,
) -> dict[str, int | dict[str, int]]:
    summary: dict[str, int | dict[str, int]] = {
        "total_records": total_records,
        "flagged_records": len(records),
    }
    summary.update({issue: 0 for issue in _ISSUES})
    for record in records:
        for issue in record.get("issues", []):
            if issue in summary:
                cur = summary[issue]
                if isinstance(cur, int):
                    summary[issue] = cur + 1
    summary["record_count_by_type"] = dict(record_count_by_type)
    summary["shared_folder_count"] = shared_folder_count
    summary["orphan_record_count"] = int(summary["orphan"])  # type: ignore[arg-type]
    summary["weak_password_records"] = int(summary["weak_password"])  # type: ignore[arg-type]
    summary["reused_password_records"] = int(summary["reused_password"])  # type: ignore[arg-type]
    return summary


def _has_password(row: Mapping[str, Any]) -> bool:
    for key in _HAS_PASSWORD_KEYS:
        if key in row:
            return _truthy(row[key])
    for key in _PASSWORD_KEYS:
        if key in row:
            return not _is_empty(row[key])
    for field in _iter_field_dicts(row):
        if _field_is_password(field):
            return not _is_empty(field.get("value"))
    return False


def _has_weak_password_indicator(row: Mapping[str, Any]) -> bool:
    for key in _WEAK_KEYS:
        if key in row and _value_indicates_weak(row[key], numeric_score=key in _WEAK_SCORE_KEYS):
            return True
    for field in _iter_field_dicts(row):
        label = _string_or_empty(_first_value(field, ("label", "name", "key", "type")))
        if "strength" in label.casefold() or "weak" in label.casefold():
            if _value_indicates_weak(field.get("value"), numeric_score=True):
                return True
    return False


def _shared_user_count(row: Mapping[str, Any]) -> int:
    for key in _SHARED_COUNT_KEYS:
        value = row.get(key)
        if value is not None:
            return _count_value(value)
    for key in _SHARED_CONTAINER_KEYS:
        value = row.get(key)
        if value is not None:
            return _count_value(value)
    shared = row.get("shared")
    if isinstance(shared, bool):
        return 1 if shared else 0
    if isinstance(shared, str) and shared.strip().casefold() == "true":
        return 1
    return 0


def _has_rotation_policy(row: Mapping[str, Any]) -> bool:
    for key in _ROTATION_ENABLED_KEYS:
        if key in row and _truthy(row[key]):
            return True
    for key in _ROTATION_KEYS:
        if key in row and _rotation_value_enabled(row[key]):
            return True
    return False


def _modified_at(row: Mapping[str, Any]) -> datetime | None:
    for key in _MODIFIED_KEYS:
        parsed = _parse_datetime(row.get(key))
        if parsed is not None:
            return parsed
    return None


def _iter_field_dicts(row: Mapping[str, Any]) -> Iterable[Mapping[str, Any]]:
    for source in _field_sources(row):
        for key in ("fields", "custom", "custom_fields", "customFields"):
            block = source.get(key)
            if not isinstance(block, list):
                continue
            for field in block:
                if isinstance(field, dict):
                    yield field


def _field_sources(row: Mapping[str, Any]) -> Iterable[Mapping[str, Any]]:
    yield row
    for key in ("data", "data_unencrypted", "dataUnencrypted"):
        value = row.get(key)
        if isinstance(value, dict):
            yield value
        elif isinstance(value, str) and value.strip().startswith("{"):
            try:
                parsed = json.loads(value)
            except json.JSONDecodeError:
                continue
            if isinstance(parsed, dict):
                yield parsed


def _field_is_password(field: Mapping[str, Any]) -> bool:
    field_type = _string_or_empty(field.get("type")).replace("_", "").casefold()
    if field_type == "password":
        return True
    for key in ("label", "name", "key"):
        if "password" in _string_or_empty(field.get(key)).casefold():
            return True
    return False


def _first_value(row: Mapping[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            return value
    return None


def _string_or_empty(value: Any) -> str:
    return "" if value is None else str(value)


def _is_empty(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip().casefold() in _EMPTY_STRINGS
    if isinstance(value, list | tuple | set):
        return all(_is_empty(item) for item in value)
    if isinstance(value, dict):
        return not value or all(_is_empty(item) for item in value.values())
    return False


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().casefold() not in _FALSE_STRINGS
    if isinstance(value, int | float):
        return value != 0
    return not _is_empty(value)


def _value_indicates_weak(value: Any, *, numeric_score: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lower = value.strip().casefold()
        return lower in _WEAK_STRINGS or lower.startswith("weak")
    if isinstance(value, int | float):
        if numeric_score:
            return 0 <= value <= 2 or 0 < value <= 40
        return value != 0
    if isinstance(value, list | tuple | set):
        return any(_value_indicates_weak(item, numeric_score=numeric_score) for item in value)
    if isinstance(value, dict):
        return any(
            _value_indicates_weak(item, numeric_score=numeric_score) for item in value.values()
        )
    return False


def _count_value(value: Any) -> int:
    if isinstance(value, bool):
        return 1 if value else 0
    if isinstance(value, int):
        return max(value, 0)
    if isinstance(value, str):
        match = re.search(r"\d+", value)
        if match:
            return int(match.group(0))
        return 1 if value.strip().casefold() == "true" else 0
    if isinstance(value, list | tuple | set):
        user_entries = [item for item in value if _looks_like_user_share(item)]
        return len(user_entries) if user_entries else len(value)
    if isinstance(value, dict):
        for key in ("users", "shared_users", "sharedUsers", "members"):
            nested = value.get(key)
            if nested is not None:
                return _count_value(nested)
        return len(value)
    return 0


def _looks_like_user_share(item: Any) -> bool:
    if isinstance(item, str):
        return True
    if not isinstance(item, dict):
        return False
    share_type = _string_or_empty(
        _first_value(item, ("type", "share_type", "shareType", "kind"))
    ).casefold()
    if share_type and "team" in share_type:
        return False
    if share_type and "user" in share_type:
        return True
    return any(key in item for key in ("username", "email", "account_uid", "accountUid"))


def _rotation_value_enabled(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().casefold() not in _FALSE_STRINGS
    if isinstance(value, list | tuple | set):
        return any(_rotation_value_enabled(item) for item in value)
    if isinstance(value, dict):
        if _truthy(value.get("disabled")) or _truthy(value.get("is_disabled")):
            return False
        for key in ("enabled", "rotation_enabled", "rotationEnabled"):
            if key in value:
                return _truthy(value[key])
        return not _is_empty(value)
    return not _is_empty(value)


def _parse_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, int | float):
        timestamp = float(value)
        if timestamp > 10_000_000_000:
            timestamp = timestamp / 1000
        try:
            return datetime.fromtimestamp(timestamp, tz=UTC)
        except (OSError, OverflowError, ValueError):
            return None
    text = str(value).strip()
    if text.casefold() in _EMPTY_STRINGS:
        return None
    if text.isdigit():
        return _parse_datetime(int(text))
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    return _coerce_utc(parsed)


def _coerce_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)
