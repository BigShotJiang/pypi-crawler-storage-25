"""Per-team summary from ``enterprise-info`` teams + ``compliance team-report``."""

from __future__ import annotations

from typing import Any

import dsk.cli._report.runner as keeper_runner
from dsk.cli._report.common import (
    build_envelope,
    parse_report_json_array,
    prepare_report_rows,
)

_TEAM_LIST_COLUMNS = (
    "restricts",
    "node",
    "user_count",
    "users",
    "queued_user_count",
    "queued_users",
    "role_count",
    "roles",
)


def _team_list_argv(node: str | None) -> list[str]:
    argv = [
        "enterprise-info",
        "-t",
        "-v",
        "--format",
        "json",
        "--columns",
        ",".join(_TEAM_LIST_COLUMNS),
    ]
    if node:
        argv.extend(["--node", node])
    return argv


def _compliance_team_report_argv(node: str | None, team_filters: tuple[str, ...]) -> list[str]:
    argv = ["compliance", "team-report", "--format", "json"]
    if node:
        argv.extend(["--node", node])
    for team in team_filters:
        argv.extend(["--team", team])
    return argv


def _parse_json_rows(raw: str, *, command: str) -> list[dict[str, Any]]:
    text = keeper_runner.extract_json_array_stdout(raw)
    return parse_report_json_array(text, command=command)


def _team_matches_filters(row: dict[str, Any], filters: tuple[str, ...]) -> bool:
    if not filters:
        return True
    uid = str(row.get("team_uid") or "")
    name = str(row.get("name") or "")
    for f in filters:
        if f == uid or f.lower() == uid.lower():
            return True
        if f.lower() == name.lower() or f == name:
            return True
    return False


def _shared_folders_by_team(sf_rows: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    out: dict[str, list[dict[str, Any]]] = {}
    for r in sf_rows:
        team_uid = str(r.get("team_uid") or "")
        if not team_uid:
            continue
        out.setdefault(team_uid, []).append(
            {
                "shared_folder_uid": r.get("shared_folder_uid"),
                "shared_folder_name": r.get("shared_folder_name"),
                "permissions": r.get("permissions"),
                "records": r.get("records"),
            }
        )
    return out


def run_team_report(
    *,
    node: str | None = None,
    teams: tuple[str, ...] = (),
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None = None,
    config_file: str | None = None,
    password: str | None = None,
) -> dict[str, Any]:
    """Team rows with members, team role names, and shared-folder rows from compliance."""
    raw_list = keeper_runner.run_keeper_batch(
        _team_list_argv(node),
        keeper_bin=keeper_bin,
        config_file=config_file,
        password=password,
    )
    team_rows = _parse_json_rows(raw_list, command="enterprise-info -t --format json")
    filtered = [r for r in team_rows if _team_matches_filters(r, teams)]

    merged: list[dict[str, Any]] = []
    if filtered:
        raw_sf = keeper_runner.run_keeper_batch(
            _compliance_team_report_argv(node, teams),
            keeper_bin=keeper_bin,
            config_file=config_file,
            password=password,
        )
        sf_rows = _parse_json_rows(raw_sf, command="compliance team-report --format json")
        sf_by_team = _shared_folders_by_team(sf_rows)
        for row in filtered:
            uid = str(row.get("team_uid") or "")
            sf_list = sf_by_team.get(uid, [])
            piece = dict(row)
            piece["shared_folders"] = sf_list
            piece["shared_folder_count"] = len(sf_list)
            merged.append(piece)

    sanitized_rows = prepare_report_rows(
        merged,
        sanitize_uids=sanitize_uids,
        quiet=quiet,
        fingerprint_keys=("team_uid",),
    )
    return build_envelope(
        command="team-report",
        rows=sanitized_rows,
        meta={
            "sources": ["enterprise-info-teams", "compliance-team-report"],
            "node": node or "",
            "team_filter": list(teams),
            "team_list_columns": list(_TEAM_LIST_COLUMNS),
            "quiet": quiet,
            "sanitize_uids": sanitize_uids,
        },
    )
