"""`dsk discover` — build a skeleton PAM manifest from unmanaged live-shaped JSON."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.table import Table

from dsk.core.errors import CapabilityError
from dsk.core.manifest import dump_manifest, load_manifest_string
from dsk.core.metadata import MANAGER_NAME, decode_marker
from dsk.core.normalize import canonicalize, from_pam_import_json
from dsk.core.resource_limits import (
    ResourceLimitError,
    positive_int_env,
    read_json_file_limited,
)
from dsk.providers._commander_cli_helpers import _extract_marker_field

_EXIT_CAPABILITY = 5
_EXIT_GENERIC = 1
_DEFAULT_MAX_DISCOVER_INPUT_BYTES = 5 * 1024 * 1024
_DEFAULT_MAX_DISCOVER_JSON_DEPTH = 64


def _is_dsk_managed_row(row: dict[str, Any]) -> bool:
    raw = _extract_marker_field(row)
    marker = decode_marker(raw if isinstance(raw, str) else None)
    return bool(marker) and bool(marker) and marker.get("manager") == MANAGER_NAME  # type: ignore[union-attr]


def _strip_custom_fields(obj: Any) -> Any:
    if isinstance(obj, dict):
        out = {k: _strip_custom_fields(v) for k, v in obj.items() if k != "custom_fields"}
        return out
    if isinstance(obj, list):
        return [_strip_custom_fields(x) for x in obj]
    return obj


def _raw_resource_and_user_lists(
    document: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    doc = canonicalize(document)
    _pam_data_raw = doc.get("pam_data")
    pam_data: dict[str, Any] = _pam_data_raw if isinstance(_pam_data_raw, dict) else {}
    if isinstance(doc.get("resources"), list):
        resources = [dict(x) for x in doc["resources"] if isinstance(x, dict)]
    else:
        resources = [dict(x) for x in (pam_data.get("resources") or []) if isinstance(x, dict)]
    if isinstance(doc.get("users"), list):
        users = [dict(x) for x in doc["users"] if isinstance(x, dict)]
    else:
        users = [dict(x) for x in (pam_data.get("users") or []) if isinstance(x, dict)]
    return resources, users


def build_discovered_manifest_dict(
    document: dict[str, Any],
    *,
    manifest_name: str,
) -> tuple[dict[str, Any], list[tuple[str, str, str]]]:
    """Return manifest dict (PAM) plus table rows: (uid_ref, resource_type, title)."""
    full = from_pam_import_json(document, name=manifest_name)
    raw_res, raw_usr = _raw_resource_and_user_lists(document)

    out: dict[str, Any] = {
        "version": "1",
        "schema": "pam-environment.v1",
        "name": manifest_name,
    }
    if full.get("projects"):
        out["projects"] = _strip_custom_fields(full["projects"])
    if full.get("shared_folders"):
        out["shared_folders"] = _strip_custom_fields(full["shared_folders"])
    if full.get("gateways"):
        out["gateways"] = _strip_custom_fields(full["gateways"])
    if full.get("pam_configurations"):
        out["pam_configurations"] = _strip_custom_fields(full["pam_configurations"])

    table_rows: list[tuple[str, str, str]] = []
    discovered_resources: list[dict[str, Any]] = []
    full_resources = list(full.get("resources") or [])
    for i, lifted in enumerate(full_resources):
        raw = raw_res[i] if i < len(raw_res) else {}
        if _is_dsk_managed_row(raw):
            continue
        item = _strip_custom_fields(dict(lifted))
        item["manager"] = "discovered"
        discovered_resources.append(item)
        table_rows.append(
            (str(item.get("uid_ref", "")), str(item.get("type", "")), str(item.get("title", "")))
        )

    discovered_users: list[dict[str, Any]] = []
    full_users = list(full.get("users") or [])
    for i, lifted in enumerate(full_users):
        raw = raw_usr[i] if i < len(raw_usr) else {}
        if _is_dsk_managed_row(raw):
            continue
        item = _strip_custom_fields(dict(lifted))
        item["manager"] = "discovered"
        discovered_users.append(item)
        utype = str(item.get("type", "user"))
        table_rows.append((str(item.get("uid_ref", "")), utype, str(item.get("title", ""))))

    single_pc_ref: str | None = None
    pcs = out.get("pam_configurations")
    if isinstance(pcs, list) and len(pcs) == 1:
        ref = pcs[0].get("uid_ref") if isinstance(pcs[0], dict) else None
        single_pc_ref = str(ref) if ref else None
    for res in discovered_resources:
        if single_pc_ref and not res.get("pam_configuration_uid_ref"):
            res["pam_configuration_uid_ref"] = single_pc_ref

    out["resources"] = discovered_resources
    out["users"] = discovered_users
    return out, table_rows


@click.command("discover")
@click.pass_context
@click.option(
    "--provider",
    type=click.Choice(["mock", "commander"]),
    default=None,
    help="Override parent group provider (default: inherit from `dsk --provider`).",
)
@click.option(
    "--input",
    "input_path",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Commander-shaped PAM project JSON (required for mock).",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    required=True,
    help="Write discovered skeleton manifest (YAML).",
)
@click.option("--name", default=None, help="Manifest name (defaults to JSON stem or 'discovered').")
def discover_cmd(
    ctx: click.Context,
    provider: str | None,
    input_path: Path | None,
    output: Path,
    name: str | None,
) -> None:
    """List unmanaged PAM resources (no DSK marker) and emit a starter manifest."""
    obj = ctx.obj if ctx.obj is not None else {}
    effective = (provider or obj.get("provider") or "mock").strip()

    if effective == "commander":
        exc = CapabilityError(
            reason="dsk discover does not query Commander directly; use an exported PAM JSON file",
            next_action=(
                "run: keeper pam project export --output project.json; then dsk export project.json"
            ),
        )
        click.echo(f"capability error: {exc}", err=True)
        sys.exit(_EXIT_CAPABILITY)

    if input_path is None:
        click.echo("discover: --input is required for mock provider", err=True)
        sys.exit(_EXIT_GENERIC)

    try:
        max_bytes = positive_int_env(
            "DSK_DISCOVER_MAX_INPUT_BYTES",
            _DEFAULT_MAX_DISCOVER_INPUT_BYTES,
        )
        max_depth = positive_int_env(
            "DSK_DISCOVER_MAX_JSON_DEPTH",
            _DEFAULT_MAX_DISCOVER_JSON_DEPTH,
        )
        data = read_json_file_limited(
            input_path,
            max_bytes=max_bytes,
            max_depth=max_depth,
            label="discover input JSON",
            byte_limit_name="DSK_DISCOVER_MAX_INPUT_BYTES",
            depth_limit_name="DSK_DISCOVER_MAX_JSON_DEPTH",
        )
    except (OSError, json.JSONDecodeError, ResourceLimitError) as exc:
        click.echo(f"discover: failed to read JSON: {exc}", err=True)
        sys.exit(_EXIT_GENERIC)

    if not isinstance(data, dict):
        click.echo("discover: JSON root must be an object", err=True)
        sys.exit(_EXIT_GENERIC)

    manifest_name = (
        name or data.get("project") or data.get("name") or input_path.stem or "discovered"
    )

    try:
        manifest_dict, rows = build_discovered_manifest_dict(data, manifest_name=manifest_name)
        manifest = load_manifest_string(json.dumps(manifest_dict), suffix=".json")

        rendered = dump_manifest(manifest, fmt="yaml")
    except Exception as exc:  # pragma: no cover - defensive
        click.echo(f"discover: {exc}", err=True)
        sys.exit(_EXIT_GENERIC)

    console = Console()
    table = Table(title="Discovered (unmanaged) resources")
    table.add_column("uid_ref")
    table.add_column("type")
    table.add_column("title")
    if not rows:
        table.add_row("—", "—", "(none)")
    for uid_ref, rtype, title in rows:
        table.add_row(uid_ref, rtype, title)
    console.print(table)

    output.write_text(rendered, encoding="utf-8")
    click.echo(f"wrote {output}")
