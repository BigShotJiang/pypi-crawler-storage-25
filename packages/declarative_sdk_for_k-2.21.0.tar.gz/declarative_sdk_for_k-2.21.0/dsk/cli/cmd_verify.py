"""``dsk verify`` — integrity verification for keeperCMD run-dirs.

:public: CLI command module. The Python helpers it imports from
``cmd_import_from_keepercmd`` remain internal implementation details.
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from dsk.cli.audit_chain import AuditChainCorrupt
from dsk.cli.cmd_import_from_keepercmd import (
    _check_contract_version,
    _parse_manifest_csv,
    _verify_audit_log,
    _verify_manifest_csv_sidecar,
    _verify_output_signature,
    _verify_sha256sums,
    _verify_signed_inventory_hash,
)

EXIT_OK = 0
EXIT_GENERIC = 1
EXIT_CAPABILITY = 5


_STRICT_REQUIRED = (
    "audit.log",
    "inventory.json",
    "manifest.csv",
    "manifest.csv.sha256",
    "records_import.json",
    "SHA256SUMS.txt",
)


def _missing_required(run_dir: Path, names: tuple[str, ...]) -> list[str]:
    return [name for name in names if not (run_dir / name).exists()]


@click.command("verify")
@click.argument("run_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option(
    "--strict",
    is_flag=True,
    default=False,
    help="Require all keeperCMD v1.1 integrity artifacts before verifying.",
)
@click.option(
    "--require-output-signature",
    is_flag=True,
    default=False,
    help="Require SHA256SUMS.txt.minisig before consuming keeperCMD output.",
)
@click.option(
    "--signature-pubkey",
    default=None,
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Minisign public key file used to verify SHA256SUMS.txt.minisig.",
)
@click.option(
    "--signature-pubkey-keeper-record",
    default=None,
    help=(
        "Keeper record UID containing the minisign public key. "
        "Current offline CLI sessions should use --signature-pubkey FILE."
    ),
)
def verify_cmd(
    run_dir: Path,
    strict: bool,
    require_output_signature: bool,
    signature_pubkey: Path | None,
    signature_pubkey_keeper_record: str | None,
) -> None:
    """Verify keeperCMD run-dir integrity without importing or writing markers.

    Non-strict mode verifies the artifacts that are present and still requires
    ``manifest.csv`` plus ``inventory.json`` for contract inspection. Strict mode
    also requires ``audit.log``, ``manifest.csv.sha256``, ``records_import.json``,
    and ``SHA256SUMS.txt``.
    """
    console = Console()
    contract_checked = False

    if require_output_signature:
        _verify_output_signature(
            run_dir,
            console,
            signature_pubkey=signature_pubkey,
            signature_pubkey_keeper_record=signature_pubkey_keeper_record,
            verbose=strict,
        )
        if not _verify_signed_inventory_hash(run_dir, console):
            sys.exit(EXIT_CAPABILITY)
        try:
            _check_contract_version(run_dir, console)
        except ImportError as exc:
            console.print(f"[red]error:[/] {exc}")
            sys.exit(EXIT_GENERIC)
        contract_checked = True

    missing_core = _missing_required(run_dir, ("manifest.csv", "inventory.json"))
    if missing_core:
        console.print("[red]error:[/] missing required artifact(s): " + ", ".join(missing_core))
        sys.exit(EXIT_GENERIC)

    if strict:
        missing = _missing_required(run_dir, _STRICT_REQUIRED)
        if missing:
            console.print(
                "[red]error:[/] strict verification missing artifact(s): " + ", ".join(missing)
            )
            sys.exit(EXIT_CAPABILITY)

    if not contract_checked:
        try:
            _check_contract_version(run_dir, console)
        except ImportError as exc:
            console.print(f"[red]error:[/] {exc}")
            sys.exit(EXIT_GENERIC)

    audit_log = run_dir / "audit.log"
    if audit_log.exists():
        try:
            _verify_audit_log(audit_log)
        except AuditChainCorrupt as exc:
            console.print(f"[red]audit chain corrupt:[/] {exc}")
            sys.exit(EXIT_CAPABILITY)
        except ImportError as exc:
            console.print(f"[red]error:[/] {exc}")
            sys.exit(EXIT_GENERIC)

    if not _verify_manifest_csv_sidecar(run_dir, console, verbose=strict):
        sys.exit(EXIT_CAPABILITY)

    sha_file = run_dir / "SHA256SUMS.txt"
    if sha_file.exists():
        if not _verify_sha256sums(run_dir, console, verbose=strict):
            sys.exit(EXIT_CAPABILITY)

    try:
        manifest_rows = _parse_manifest_csv(run_dir / "manifest.csv")
    except (OSError, csv.Error, ImportError) as exc:
        console.print(f"[red]error:[/] cannot read manifest.csv: {type(exc).__name__}")
        sys.exit(EXIT_GENERIC)

    table = Table(show_header=True, header_style="bold")
    table.add_column("Check")
    table.add_column("Status")
    table.add_row("contract", "ok")
    table.add_row("audit.log", "ok" if audit_log.exists() else "skipped")
    table.add_row(
        "manifest.csv.sha256", "ok" if (run_dir / "manifest.csv.sha256").exists() else "skipped"
    )
    table.add_row("SHA256SUMS.txt", "ok" if sha_file.exists() else "skipped")
    table.add_row("manifest rows", str(len(manifest_rows)))
    console.print(table)
    console.print("[green]verify ok[/]")
    sys.exit(EXIT_OK)


__all__ = ["verify_cmd"]
