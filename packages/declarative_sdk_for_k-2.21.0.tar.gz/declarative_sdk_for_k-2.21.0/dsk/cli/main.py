"""Keeper PAM Declarative CLI.

:public: Command names, options, and exit-code meanings are stable CLI surface.
:internal: Python callback functions in this module are implementation details
unless re-exported from :mod:`dsk.cli`.

Subcommands:
    doctor     - Python, keepercommander, package version, key env vars
    orient     - Compact agent orientation (commands + pointers)
    validate   - JSON Schema (all families); vault graph + optional online; PAM graph + online
    export     - Commander JSON export -> declarative YAML manifest
    discover   - Unmanaged PAM resources -> skeleton YAML (mock JSON; commander: export path)
    plan       - compute and render a plan (pam-environment.v1 or keeper-vault.v1 + mock)
    import     - adopt unmanaged matching records and write ownership markers
    diff       - plan + field-by-field render
    apply      - execute a plan via the selected provider
    report     - read-only Commander reports: password-report, compliance-report,
                 security-audit-report, vault-health, ksm-usage, team-roles,
                 team-report, role-report (JSON, redacted)
    run        - Commander passthrough with redaction and exit-code passthrough

Exit codes:
    0 success, clean
    1 unexpected error
    2 validation error
    3 unresolved uid_ref / cycle
    4 plan produced conflicts (non-zero actionable conflicts)
    5 capability / provider error
"""

from __future__ import annotations

import contextlib
import io
import json
import os
import shlex
import sys
from dataclasses import asdict, dataclass
from importlib import metadata
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.table import Table

from dsk._obs import configure_json_logging, get_logger, log_event, set_correlation_id
from dsk.auth import KsmLoginHelper, LoginHelper, load_helper_from_path
from dsk.cli.cmd_audit import audit_cmd
from dsk.cli.cmd_bundle import cmd_bundle
from dsk.cli.cmd_drift_watch import drift_watch_cmd
from dsk.cli.cmd_import_from_keepercmd import import_from_keepercmd_cmd
from dsk.cli.cmd_rehearse_report import rehearse_report_cmd
from dsk.cli.cmd_scan import scan_cmd
from dsk.cli.cmd_shim_info import shim_info_cmd
from dsk.cli.cmd_verify import verify_cmd
from dsk.cli.discover import discover_cmd
from dsk.cli.renderer import RichRenderer
from dsk.core import (
    IDENTITY_FAMILY,
    K8S_ESO_FAMILY,
    MSP_FAMILY,
    SIEM_FAMILY,
    VAULT_MANIFEST_FAMILY,
    CapabilityError,
    Change,
    ChangeKind,
    IdentityManifestV1,
    K8sEsoManifestV1,
    Manifest,
    ManifestError,
    MspManifestV1,
    OwnershipError,
    RefError,
    SchemaError,
    SpiffeRuntime,
    SpiffeRuntimeError,
    UnsupportedFamilyError,
    build_graph,
    build_vault_graph,
    compute_diff,
    compute_identity_diff,
    compute_msp_diff,
    compute_sharing_diff,
    compute_siem_diff,
    compute_vault_diff,
    dump_manifest,
    execution_order,
    from_pam_import_json,
    load_declarative_manifest,
    load_msp_manifest,
    msp_apply_order,
    redact,
    vault_record_apply_order,
)
from dsk.core import (
    build_plan as core_build_plan,
)
from dsk.core.enterprise_diff import compute_enterprise_diff
from dsk.core.enterprise_graph import build_enterprise_graph, enterprise_apply_order
from dsk.core.epm_diff import compute_epm_diff, compute_epm_policy_diff
from dsk.core.integrations_events_diff import compute_events_diff
from dsk.core.interfaces import ApplyOutcome, LiveRecord
from dsk.core.ksm_diff import compute_ksm_diff
from dsk.core.ksm_graph import ksm_apply_order
from dsk.core.manifest import read_manifest_document
from dsk.core.models_enterprise import (
    ENTERPRISE_FAMILY,
    EnterpriseManifestV1,
    load_enterprise_manifest,
)
from dsk.core.models_epm import (
    EPM_FAMILY,
    EPM_POLICY_FAMILY,
    EpmManifestV1,
    EpmPolicyManifestV1,
)
from dsk.core.models_integrations_events import EventsManifestV1
from dsk.core.models_jit import JitManifestV1, load_jit_manifest
from dsk.core.models_ksm import KSM_FAMILY, KsmManifestV1
from dsk.core.models_rotation import RotationPolicyManifestV1
from dsk.core.models_scim import ScimManifestV1

try:
    from dsk.core.models_pam_extended import (  # stripped in public build
        PAM_EXTENDED_FAMILY,
        PamExtendedManifestV1,
    )
except ImportError:
    PAM_EXTENDED_FAMILY = "keeper-pam-extended.v1"  # type: ignore[assignment]

    class PamExtendedManifestV1:  # type: ignore[no-redef]  # stripped in public build
        """Stub for stripped private module."""


from dsk.core.models_siem import SiemManifestV1
from dsk.core.models_terraform import TERRAFORM_FAMILY, TerraformIntegrationManifestV1
from dsk.providers.k8s_eso_provider import K8sEsoProvider, k8s_eso_apply_order
from dsk.providers.terraform_provider import TerraformProvider

try:
    from dsk.core.pam_extended_diff import (
        compute_pam_extended_diff,  # stripped in public build
    )
except ImportError:
    compute_pam_extended_diff = None  # type: ignore[assignment]
from dsk.core.agent_kit_diff import compute_agent_kit_diff
from dsk.core.agent_memory_policy_diff import compute_agent_memory_policy_diff
from dsk.core.agentic_skill_policy_diff import compute_agentic_skill_policy_diff
from dsk.core.ai_act_diff import compute_ai_act_diff
from dsk.core.ai_agent_diff import compute_ai_agent_diff
from dsk.core.ai_policy_diff import compute_ai_policy_diff
from dsk.core.ai_token_diff import compute_ai_token_diff
from dsk.core.cloud_jit_diff import compute_cloud_jit_diff
from dsk.core.cmmc_diff import compute_cmmc_diff
from dsk.core.compliance_diff import compute_compliance_diff
from dsk.core.connection_profile_diff import compute_connection_profile_diff
from dsk.core.cspm_diff import compute_cspm_diff
from dsk.core.db_access_diff import compute_db_access_diff
from dsk.core.dora_diff import compute_dora_diff
from dsk.core.evidence_stream_diff import compute_evidence_stream_diff
from dsk.core.gateway_ha_diff import compute_gateway_ha_diff
from dsk.core.itsm_gate_diff import compute_itsm_gate_diff
from dsk.core.keeper_drive_diff import compute_keeper_drive_diff
from dsk.core.mcp_allowlist_diff import compute_mcp_allowlist_diff
from dsk.core.mcp_diff import compute_mcp_diff
from dsk.core.models_agent_kit import AgentKitManifestV1
from dsk.core.models_agent_memory_policy import AgentMemoryPolicyManifest
from dsk.core.models_agentic_skill_policy import AgenticSkillPolicyManifest
from dsk.core.models_ai_act import AiActProfileManifestV1
from dsk.core.models_ai_agent import AiAgentManifest
from dsk.core.models_ai_policy import AiPolicyManifestV1
from dsk.core.models_ai_token import AiTokenManifestV1
from dsk.core.models_cloud_jit import CloudJitManifestV1
from dsk.core.models_cmmc import CmmcProfileManifestV1
from dsk.core.models_compliance import ComplianceBundleManifestV1
from dsk.core.models_connection_profile import (
    PamConnectionProfileManifestV1,
)
from dsk.core.models_cspm import CspmRemediationManifestV1
from dsk.core.models_db_access import DbAccessPolicyManifestV1
from dsk.core.models_dora import DoraProfileManifestV1
from dsk.core.models_evidence_stream import (
    ContinuousEvidenceStreamManifestV1,
)
from dsk.core.models_gateway_ha import GatewayHaManifestV1
from dsk.core.models_itsm_gate import ItsmApprovalGateManifestV1
from dsk.core.models_keeper_drive import KeeperDriveManifestV1
from dsk.core.models_mcp import McpSecretsBindingManifestV1
from dsk.core.models_mcp_allowlist import McpAllowlistManifest
from dsk.core.models_nhi import NhiAgentManifest
from dsk.core.models_pipeline_env import (
    PipelineEphemeralManifestV1,
)
from dsk.core.models_policy import (
    PolicyManifestV1,
    compute_policy_diff,
    policy_apply_order,
)
from dsk.core.models_pqc import PqcPolicyManifestV1
from dsk.core.models_privileged_access import PrivilegedAccessManifestV1
from dsk.core.models_saas_rotation import SaaSRotationManifestV1
from dsk.core.models_secret_scanner import (
    SecretScannerBridgeManifestV1,
)
from dsk.core.models_slack_gate import SlackApprovalGateManifestV1
from dsk.core.models_spiffe import SpiffeBindingManifestV1
from dsk.core.models_trust_chain import TrustChainManifestV1
from dsk.core.models_tunnel import TunnelManifestV1
from dsk.core.models_workflow import WorkflowManifestV1
from dsk.core.models_workflow_gate import WorkflowGateManifestV1
from dsk.core.nhi_diff import compute_nhi_diff
from dsk.core.pipeline_env_diff import compute_pipeline_env_diff
from dsk.core.planner import Plan
from dsk.core.pqc_diff import compute_pqc_diff
from dsk.core.preview import assert_preview_keys_allowed
from dsk.core.privileged_access_diff import compute_privileged_access_diff
from dsk.core.resource_limits import (
    ResourceLimitError,
    positive_int_env,
    read_json_file_limited,
    read_text_limited,
    read_yaml_file_limited,
)
from dsk.core.saas_rotation_diff import compute_saas_rotation_diff
from dsk.core.schema import (
    JIT_ACCESS_FAMILY,
    PAM_FAMILY,
    ROTATION_POLICY_FAMILY,
    SHARING_FAMILY,
    validate_manifest,
)
from dsk.core.scim_diff import compute_scim_diff, scim_apply_order
from dsk.core.secret_scanner_diff import compute_secret_scanner_diff
from dsk.core.sharing_graph import sharing_apply_order
from dsk.core.sharing_models import SharingManifestV1, load_sharing_manifest
from dsk.core.slack_gate_diff import compute_slack_gate_diff
from dsk.core.spiffe_diff import compute_spiffe_diff
from dsk.core.trust_chain_diff import compute_trust_chain_diff
from dsk.core.tunnel_diff import compute_tunnel_diff
from dsk.core.vault_models import VaultManifestV1
from dsk.core.workflow_diff import compute_workflow_diff
from dsk.core.workflow_gate_diff import compute_workflow_gate_diff
from dsk.providers import (
    CommanderCliProvider,
    CommanderServiceProvider,
    KsmMockProvider,
    MockProvider,
)
from dsk.secrets import bootstrap_ksm_application

EXIT_OK = 0
EXIT_GENERIC = 1
# Exit code 2 is intentionally overloaded per DOR (DELIVERY_PLAN.md + ARCHITECTURE.md):
#   - `plan` / `diff`: 2 = "changes present" (actionable, not a failure)
#   - `validate`: 2 = "schema invalid" (failure)
# Operators distinguish via the subcommand. Do NOT split these into
# different numbers without a spec update — CI pipelines depend on 2.
EXIT_CHANGES = 2
EXIT_SCHEMA = 2
EXIT_REF = 3
EXIT_CONFLICT = 4
EXIT_CAPABILITY = 5
_LOG = get_logger(__name__)
DEFAULT_CLI_MAX_COMMANDER_JSON_BYTES = 5 * 1024 * 1024
DEFAULT_CLI_MAX_JWT_FILE_BYTES = 64 * 1024
DEFAULT_CLI_MAX_MANIFEST_BYTES = 20 * 1024 * 1024
DEFAULT_CLI_MAX_CONFIG_BYTES = 1 * 1024 * 1024
DEFAULT_CLI_MAX_JSON_DEPTH = 64
DEFAULT_CLI_MAX_YAML_DEPTH = 64
_REPORT_HELP = """Run read-only Commander reports; prints redacted JSON to stdout.

Available reports:
  password-report        Weak-password rows from Commander password-report.
  compliance-report      Enterprise compliance table with graceful empty-cache handling.
  security-audit-report  Enterprise security-audit summary.
  vault-health           Vault posture findings from list-records metadata.
  ksm-usage              KSM app/share usage summary.
  team-roles             Enterprise team → roles → managed-node permission matrix (enterprise-info).
  team-report            Enterprise team rows from enterprise-info.
  role-report            Per-role enforcement, members, and scoped nodes (enterprise-info + enterprise-role).
"""
_MSP_COMMANDER_UNSUPPORTED_REASON = (
    "MSP import and adoption are not implemented on commander provider "
    "(no declarative ownership marker writer for managed companies; see docs/MSP_FAMILY_DESIGN.md)"
)


def _cli_json_depth_limit() -> int:
    return positive_int_env("DSK_CLI_MAX_JSON_DEPTH", DEFAULT_CLI_MAX_JSON_DEPTH)


def _cli_yaml_depth_limit() -> int:
    return positive_int_env("DSK_CLI_MAX_YAML_DEPTH", DEFAULT_CLI_MAX_YAML_DEPTH)


def _resource_limit_exit(exc: ResourceLimitError) -> None:
    click.echo(f"resource limit exceeded: {exc}", err=True)
    sys.exit(EXIT_GENERIC)


_ENTERPRISE_IMPORT_UNSUPPORTED_REASON = (
    "keeper-enterprise.v1 import is supported for the mock provider only "
    "(Commander enterprise ownership marker writes are not implemented)"
)
_MSP_MANAGED_COMPANY_RESOURCE = "managed_company"
_ENTERPRISE_COLLECTIONS = ("nodes", "users", "roles", "teams", "enforcements", "aliases")


def _enterprise_live_object_count(live: dict[str, Any]) -> int:
    return sum(len(live.get(collection) or []) for collection in _ENTERPRISE_COLLECTIONS)


def _mock_adopt_managed_companies(self: MockProvider, plan: Plan) -> list[ApplyOutcome]:
    offenders = sorted(
        str(change.uid_ref or change.title or "<unknown>")
        for change in plan.changes
        if change.resource_type != _MSP_MANAGED_COMPANY_RESOURCE
    )
    if offenders:
        joined = ", ".join(offenders)
        raise ValueError(
            "MSP mock adoption only accepts managed_company rows; "
            f"offending uid_refs: {joined}; "
            "next_action: build an MSP-only adoption plan"
        )

    current = {str(row["name"]).casefold(): dict(row) for row in self.discover_managed_companies()}
    outcomes: list[ApplyOutcome] = []
    changed = False
    for change in _msp_plan_changes(plan):
        name = _msp_change_name(change)
        existing = current.get(name.casefold())

        if change.kind is ChangeKind.UPDATE:
            if existing is None:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=name,
                        keeper_uid=change.keeper_uid or "",
                        action="update",
                        details={"skipped": "record_missing"},
                    )
                )
                continue
            payload = {**existing, **change.after}
            payload["manager"] = str(change.after.get("manager") or plan.manifest_name)
            current[name.casefold()] = payload
            changed = True
            outcomes.append(
                ApplyOutcome(
                    uid_ref=name,
                    keeper_uid=str(payload.get("mc_enterprise_id") or change.keeper_uid or ""),
                    action="update",
                    details={"marker_written": True},
                )
            )
            continue

        if change.kind is ChangeKind.CONFLICT:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=name,
                    keeper_uid=change.keeper_uid or "",
                    action="conflict",
                    details={"reason": change.reason or "blocked"},
                )
            )
            continue

        details: dict[str, Any] = {}
        if change.reason is not None:
            details["reason"] = change.reason
        outcomes.append(
            ApplyOutcome(
                uid_ref=name,
                keeper_uid=change.keeper_uid or "",
                action="noop",
                details=details,
            )
        )

    if changed:
        self.seed_managed_companies(list(current.values()))
    return outcomes


def _commander_adopt_managed_companies(
    self: CommanderCliProvider,
    plan: Plan,
) -> list[ApplyOutcome]:
    raise CapabilityError(_MSP_COMMANDER_UNSUPPORTED_REASON)


def _msp_change_name(change: Change) -> str:
    for payload in (change.after, change.before):
        value = payload.get("name")
        if value is not None:
            return str(value)
    return str(change.uid_ref or change.title)


def _msp_plan_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    seen = {id(change) for change in ordered}
    return ordered + [change for change in plan.changes if id(change) not in seen]


if not hasattr(MockProvider, "adopt_managed_companies"):
    setattr(MockProvider, "adopt_managed_companies", _mock_adopt_managed_companies)
if not hasattr(CommanderCliProvider, "adopt_managed_companies"):
    setattr(CommanderCliProvider, "adopt_managed_companies", _commander_adopt_managed_companies)


@dataclass
class PlanLoadBundle:
    """Result of loading a manifest for plan/diff/apply."""

    pam: Manifest | None
    vault: VaultManifestV1 | None
    sharing: SharingManifestV1 | None
    msp: MspManifestV1 | None
    identity: IdentityManifestV1 | None
    ksm: KsmManifestV1 | None
    pam_extended: PamExtendedManifestV1 | None
    epm: EpmManifestV1 | None
    terraform: TerraformIntegrationManifestV1 | None
    k8s_eso: K8sEsoManifestV1 | None
    siem: SiemManifestV1 | None
    rotation: RotationPolicyManifestV1 | None
    jit: JitManifestV1 | None
    scim: ScimManifestV1 | None
    enterprise: EnterpriseManifestV1 | None
    privileged_access: PrivilegedAccessManifestV1 | None
    nhi: NhiAgentManifest | None
    ai_agent: AiAgentManifest | None
    agentic_skill_policy: AgenticSkillPolicyManifest | None
    agent_memory_policy: AgentMemoryPolicyManifest | None
    mcp_allowlist: McpAllowlistManifest | None
    workflow: WorkflowManifestV1 | None
    saas_rotation: SaaSRotationManifestV1 | None
    epm_policy: EpmPolicyManifestV1 | None
    manifest_name: str
    order: list[str]
    live: list[LiveRecord]
    live_msp: list[dict[str, Any]]
    live_ksm: dict[str, list[dict[str, Any]]]
    live_record_type_defs: list[dict[str, Any]]
    live_enterprise: dict[str, Any] | None
    provider: Any
    events: EventsManifestV1 | None
    ai_act: AiActProfileManifestV1 | None
    ai_policy: AiPolicyManifestV1 | None
    ai_token: AiTokenManifestV1 | None
    cmmc: CmmcProfileManifestV1 | None
    dora: DoraProfileManifestV1 | None
    pqc: PqcPolicyManifestV1 | None
    itsm_gate: ItsmApprovalGateManifestV1 | None
    slack_gate: SlackApprovalGateManifestV1 | None
    mcp_binding: McpSecretsBindingManifestV1 | None
    spiffe: SpiffeBindingManifestV1 | None
    workflow_gate: WorkflowGateManifestV1 | None
    trust_chain: TrustChainManifestV1 | None
    connection_profile_m: PamConnectionProfileManifestV1 | None
    db_access: DbAccessPolicyManifestV1 | None
    gateway_ha: GatewayHaManifestV1 | None
    tunnel_m: TunnelManifestV1 | None
    pipeline_env: PipelineEphemeralManifestV1 | None
    cloud_jit: CloudJitManifestV1 | None
    compliance_m: ComplianceBundleManifestV1 | None
    cspm: CspmRemediationManifestV1 | None
    evidence_stream: ContinuousEvidenceStreamManifestV1 | None
    secret_scanner: SecretScannerBridgeManifestV1 | None
    keeper_drive_m: KeeperDriveManifestV1 | None
    agent_kit_m: AgentKitManifestV1 | None
    policy: PolicyManifestV1 | None


def dispatch_main(ctx: click.Context, provider: str, folder_uid: str | None) -> None:
    """Initialize a Click context for public in-process CLI consumers."""

    ctx.ensure_object(dict)
    configure_json_logging()
    ctx.obj["provider"] = provider
    ctx.obj["folder_uid"] = folder_uid
    ctx.obj["renderer"] = RichRenderer()
    ctx.obj["correlation_id"] = set_correlation_id()
    log_event(
        _LOG,
        "cli.start",
        provider=provider,
        folder_uid_set=folder_uid is not None,
        command=ctx.invoked_subcommand or "",
    )


_dispatch_main = dispatch_main


def _dispatch_doctor() -> None:
    console = Console()
    table = Table(show_header=True, header_style="bold")
    table.add_column("Check")
    table.add_column("Status")
    table.add_column("Notes")

    critical_ok = True

    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    if sys.version_info < (3, 11):  # noqa: UP036
        critical_ok = False
        table.add_row("Python version", "✗ fail", f"need >=3.11; got {py_ver}")
    else:
        table.add_row("Python version", "✓ ok", py_ver)

    try:
        kc_ver = metadata.version("keepercommander")
        table.add_row("keepercommander", "✓ ok", kc_ver)
    except metadata.PackageNotFoundError:
        critical_ok = False
        table.add_row("keepercommander", "✗ missing", "pip install keepercommander>=18.0.0,<19")

    try:
        dsk_ver = metadata.version("declarative-sdk-for-k")
        table.add_row("dsk version", "✓ ok", dsk_ver)
    except metadata.PackageNotFoundError:
        table.add_row("dsk version", "○ unknown", "pip install -e . or use a release wheel")

    if os.environ.get("KEEPER_EMAIL"):
        table.add_row("KEEPER_EMAIL", "✓ set", "commander provider usable")
    else:
        table.add_row("KEEPER_EMAIL", "○ unset", "optional; use docs/LOGIN.md patterns")

    if os.environ.get("KEEPER_TOTP_SECRET"):
        table.add_row("KEEPER_TOTP_SECRET", "✓ set", "TOTP auth available")
    else:
        table.add_row("KEEPER_TOTP_SECRET", "○ unset", "optional when not using TOTP")

    preview_raw = (os.environ.get("DSK_PREVIEW") or "").strip()
    if preview_raw == "1":
        table.add_row("DSK_PREVIEW", "✓ on", "preview families enabled")
    else:
        table.add_row(
            "DSK_PREVIEW",
            "○ off",
            "set DSK_PREVIEW=1 for preview families",
        )

    console.print(table)
    sys.exit(EXIT_OK if critical_ok else EXIT_GENERIC)


def _dispatch_orient() -> None:
    console = Console()
    console.print("[bold]dsk[/] — Keeper declarative SDK: manifests for PAM, vault, MSP, KSM, …")
    console.print("[dim]Flow:[/] manifest → validate → plan → apply  (+ diff, import, export)")
    console.print()

    cmd_table = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False)
    cmd_table.add_column("Command")
    cmd_table.add_column("Purpose")
    cmd_table.add_column("Example")
    cmd_table.add_row("validate", "Schema / graph / optional online", "dsk validate env.yaml")
    cmd_table.add_row("plan", "Delta vs provider", "dsk --provider mock plan env.yaml")
    cmd_table.add_row("apply", "Run plan", "dsk apply env.yaml --auto-approve")
    cmd_table.add_row("diff", "Field-level view", "dsk diff env.yaml")
    cmd_table.add_row("import", "Adopt unmanaged (markers)", "dsk import env.yaml --dry-run")
    cmd_table.add_row("doctor", "Deps + env snapshot", "dsk doctor")
    console.print(cmd_table)
    console.print()
    console.print("[bold]Quick start[/]")
    console.print("  1. pip install -e '.[dev]'")
    console.print("  2. dsk doctor")
    console.print("  3. dsk validate examples/…  (see repo)")
    console.print("  4. dsk --provider mock plan …")
    console.print()
    prov = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False)
    prov.add_column("Provider")
    prov.add_column("Use")
    prov.add_row("mock", "Offline / CI (in-memory)")
    prov.add_row("commander", "Live tenant (keepercommander session)")
    prov.add_row("service", "Future HTTP integration stub")
    console.print(prov)
    console.print()
    console.print("Full agent runbook: docs/AGENT_RUNBOOK.md")


def _dispatch_webui(
    host: str, port: int, reload: bool, insecure_bind: bool, token: str | None
) -> None:
    try:
        from webui import run as run_webui
    except ImportError as exc:
        click.echo(
            "webui dependencies missing — install with `pip install 'declarative-sdk-for-k[webui]'`",
            err=True,
        )
        click.echo(f"  detail: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    run_webui(
        host=host,
        port=port,
        reload=reload,
        insecure_bind=insecure_bind,
        token=token,
    )


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(package_name="declarative-sdk-for-k")
@click.option(
    "--provider",
    type=click.Choice(["mock", "commander", "service"]),
    default="mock",
    show_default=True,
)
@click.option(
    "--folder-uid", default=None, help="Keeper shared-folder UID scope (for commander provider)"
)
@click.pass_context
def main(ctx: click.Context, provider: str, folder_uid: str | None) -> None:
    """Keeper PAM Declarative SDK.

    \b
    Exit codes:
      0  success / clean plan (no changes)
      1  unexpected error
      2  schema invalid (validate) OR changes present (plan/diff) — disambiguate by subcommand
      3  unresolved uid_ref or dependency cycle
      4  plan has conflicts (use --json to inspect changes[*].reason)
      5  provider / capability error (stderr carries next_action)
    """
    dispatch_main(ctx, provider, folder_uid)


@main.command("doctor")
def doctor() -> None:
    """Check Python, keepercommander, package versions, and common env vars."""
    _dispatch_doctor()


@main.command("orient")
def orient() -> None:
    """Print a short orientation for agents and new users."""
    _dispatch_orient()


@main.command("webui")
@click.option("--host", default="127.0.0.1", show_default=True, help="Bind address")
@click.option("--port", default=8765, show_default=True, type=int, help="Bind port")
@click.option(
    "--reload",
    is_flag=True,
    help="Enable uvicorn auto-reload (development only)",
)
@click.option(
    "--insecure-bind",
    is_flag=True,
    help="Allow binding to a non-loopback host. Pair with --token.",
)
@click.option(
    "--token",
    default=None,
    help=(
        "Bearer token required on /api/* requests. Required when "
        "--insecure-bind is set. Also readable from DSK_WEBUI_TOKEN."
    ),
)
def webui(host: str, port: int, reload: bool, insecure_bind: bool, token: str | None) -> None:
    """Launch the browser-based dsk web UI.

    The UI is a thin client over the existing CLI: every action endpoint
    shells out to ``dsk`` and surfaces stdout / stderr / exit code in the
    browser. Open http://HOST:PORT in your browser after the server starts.

    Loopback-only by default. Pass ``--insecure-bind --token <secret>`` to
    expose the UI to a network; without those flags non-loopback binds are
    refused outright. Requires the ``webui`` extra::

        pip install 'declarative-sdk-for-k[webui]'
    """
    _dispatch_webui(host, port, reload, insecure_bind, token)


# ---------------------------------------------------------------------------
# spiffe-verify


def _dispatch_spiffe_verify(
    manifest_path: Path | None,
    manifest_option: Path | None,
    jwt_token: str | None,
    jwt_file: Path | None,
    jwks_url: str,
    offline: bool,
    emit_json: bool,
) -> None:
    if manifest_path is not None and manifest_option is not None:
        raise click.UsageError(
            "pass manifest path either positionally or with --manifest, not both"
        )
    resolved_manifest = manifest_option or manifest_path
    if resolved_manifest is None:
        raise click.UsageError("missing manifest path")
    if bool(jwt_token) == bool(jwt_file):
        raise click.UsageError("pass exactly one of --jwt or --jwt-file")

    try:
        if jwt_token:
            token = jwt_token
        else:
            assert jwt_file is not None  # guaranteed by the bool-equality check above
            max_bytes = positive_int_env(
                "DSK_CLI_MAX_JWT_FILE_BYTES",
                DEFAULT_CLI_MAX_JWT_FILE_BYTES,
            )
            token = read_text_limited(
                jwt_file,
                max_bytes=max_bytes,
                label="JWT file",
                limit_name="DSK_CLI_MAX_JWT_FILE_BYTES",
            ).strip()
        manifest_doc = read_manifest_document(resolved_manifest)
        trust_domain = str(manifest_doc.get("trust_domain") or "acme.com")
        runtime = SpiffeRuntime(jwks_url=jwks_url, trust_domain=trust_domain)
        if offline:
            result = runtime.verify_jwt_offline(token, manifest_doc)
        else:
            result = runtime.verify_jwt(token, manifest_doc)
    except ResourceLimitError as exc:
        _resource_limit_exit(exc)
    except SchemaError as exc:
        click.echo(f"validation failed: {exc}", err=True)
        sys.exit(EXIT_SCHEMA)
    except ManifestError as exc:
        click.echo(f"manifest error: {exc}", err=True)
        sys.exit(EXIT_GENERIC)
    except SpiffeRuntimeError as exc:
        click.echo(f"spiffe verify failed: {exc.message}", err=True)
        if exc.next_action:
            click.echo(f"next_action: {exc.next_action}", err=True)
        sys.exit(EXIT_CAPABILITY)

    payload = asdict(result)
    if emit_json:
        click.echo(json.dumps(payload, indent=2))
    else:
        table = Table(title="SPIFFE Verify", show_header=True, header_style="bold")
        table.add_column("Field")
        table.add_column("Value")
        table.add_row("spiffe_id", result.spiffe_id)
        table.add_row("trust_domain", result.trust_domain)
        table.add_row("matched_rules", ", ".join(result.matched_rules) or "-")
        table.add_row("granted_resources", ", ".join(result.granted_resources) or "-")
        table.add_row("jit_required", ", ".join(result.jit_required) or "-")
        table.add_row("expires_at", result.expires_at or "-")
        table.add_row("offline_only", str(result.offline_only).lower())
        Console().print(table)
    sys.exit(EXIT_OK if result.matched_rules else EXIT_CHANGES)


@main.command("spiffe-verify")
@click.argument("manifest_path", required=False, type=click.Path(exists=True, path_type=Path))
@click.option(
    "--manifest",
    "manifest_option",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="SPIFFE binding manifest path.",
)
@click.option("--jwt", "jwt_token", default=None, help="JWT-SVID token string.")
@click.option(
    "--jwt-file",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help="Path containing a JWT-SVID token.",
)
@click.option("--jwks-url", default="http://localhost:8081", show_default=True)
@click.option("--offline", is_flag=True, help="Decode JWT without signature verification.")
@click.option("--json", "emit_json", is_flag=True, help="Emit JSON result.")
def spiffe_verify(
    manifest_path: Path | None,
    manifest_option: Path | None,
    jwt_token: str | None,
    jwt_file: Path | None,
    jwks_url: str,
    offline: bool,
    emit_json: bool,
) -> None:
    """Verify a JWT-SVID against spiffe-binding.v1 manifest rules."""
    _dispatch_spiffe_verify(
        manifest_path,
        manifest_option,
        jwt_token,
        jwt_file,
        jwks_url,
        offline,
        emit_json,
    )


# ---------------------------------------------------------------------------
# validate


@main.command()
@click.argument("manifest_path", type=click.Path(exists=True, path_type=Path))
@click.option("--emit-canonical", is_flag=True, help="Print the canonicalised document")
@click.option("--json", "as_json", is_flag=True, help="Emit validation summary as JSON on stdout")
@click.option(
    "--online",
    is_flag=True,
    help=(
        "Tenant checks: PAM discover+diff; keeper-vault.v1 discover+diff; "
        "MSP discover+diff; keeper-enterprise.v1 enterprise-info discover+diff"
    ),
)
@click.pass_context
def validate(
    ctx: click.Context,
    manifest_path: Path,
    emit_canonical: bool,
    as_json: bool,
    online: bool,
) -> None:
    """Validate JSON Schema for any packaged family; typed graph / online checks where wired."""
    log_event(
        _LOG,
        "cli.validate.start",
        manifest_path=str(manifest_path),
        online=online,
    )
    try:
        document = read_manifest_document(manifest_path)
        family = validate_manifest(document)
    except SchemaError as exc:
        click.echo(f"validation failed: {exc}", err=True)
        sys.exit(EXIT_SCHEMA)
    except RefError as exc:
        click.echo(f"reference error: {exc}", err=True)
        sys.exit(EXIT_REF)
    except CapabilityError as exc:
        click.echo(f"capability error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    except UnsupportedFamilyError as exc:
        click.echo(f"capability error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    except ManifestError as exc:
        click.echo(f"manifest error: {exc}", err=True)
        sys.exit(EXIT_GENERIC)

    if family != PAM_FAMILY:
        if online and family not in (
            VAULT_MANIFEST_FAMILY,
            MSP_FAMILY,
            ENTERPRISE_FAMILY,
            ROTATION_POLICY_FAMILY,
        ):
            click.echo(
                "`--online` is supported for pam-environment.v1, keeper-vault.v1, "
                "msp-environment.v1, keeper-enterprise.v1, and rotation-policy.v1 only.",
                err=True,
            )
            sys.exit(EXIT_CAPABILITY)

        if family == VAULT_MANIFEST_FAMILY:
            from dsk.core.vault_models import load_vault_manifest

            vm = load_vault_manifest(document)
            try:
                build_vault_graph(vm)
            except RefError as exc:
                click.echo(f"reference error: {exc}", err=True)
                sys.exit(EXIT_REF)
            uid_n = len(vm.iter_uid_refs())

            live: list[LiveRecord] | None = None
            online_suffix = ""
            create_count = update_count = delete_count = conflict_count = 0
            stage4_failed = False
            stage5_failed = False

            if online:
                if ctx.obj.get("provider") != "commander":
                    click.echo(
                        "`keeper-vault.v1` --online requires --provider commander "
                        "(tenant discover + diff smoke).",
                        err=True,
                    )
                    sys.exit(EXIT_CAPABILITY)
                folder_uid = ctx.obj.get("folder_uid") or os.environ.get(
                    "KEEPER_DECLARATIVE_FOLDER"
                )
                if not folder_uid:
                    click.echo(
                        "vault --online requires --folder-uid or KEEPER_DECLARATIVE_FOLDER.",
                        err=True,
                    )
                    sys.exit(EXIT_CAPABILITY)
                manifest_source = vm.model_dump(mode="python", exclude_none=True, by_alias=True)
                provider = CommanderCliProvider(
                    folder_uid=folder_uid, manifest_source=manifest_source
                )
                try:
                    live = provider.discover()
                except CapabilityError as exc:
                    click.echo(f"discovery failed: {exc}", err=True)
                    sys.exit(EXIT_CAPABILITY)

                gaps: list[str] = getattr(provider, "unsupported_capabilities", lambda _m: [])(vm)
                if gaps:
                    stage4_failed = True
                    if not as_json:
                        click.echo("capability gaps (will appear as plan conflicts):", err=True)
                        for reason in gaps:
                            click.echo(f"  - {reason}", err=True)

                try:
                    assert live is not None
                    live_records, live_record_type_defs = _vault_live_inputs(live)
                    changes = compute_vault_diff(
                        vm,
                        live_records,
                        manifest_name=manifest_path.stem,
                        adopt=False,
                        live_record_type_defs=live_record_type_defs,
                    )
                except OwnershipError as exc:
                    click.echo(f"ownership error: {exc}", err=True)
                    sys.exit(EXIT_CAPABILITY)

                create_count = sum(1 for c in changes if c.kind.value == "create")
                update_count = sum(1 for c in changes if c.kind.value == "update")
                delete_count = sum(1 for c in changes if c.kind.value == "delete")
                conflict_count = sum(1 for c in changes if c.kind.value == "conflict")
                if not as_json:
                    click.echo(
                        "stage 5: "
                        f"{create_count} create, "
                        f"{update_count} update, "
                        f"{delete_count} delete-candidates, "
                        f"{conflict_count} conflicts"
                    )

                binding_issues: list[str] = getattr(
                    provider, "check_tenant_bindings", lambda _m: []
                )(vm)
                if binding_issues:
                    stage5_failed = True
                    if not as_json:
                        click.echo("stage 5: tenant binding failures:", err=True)
                        for issue in binding_issues:
                            click.echo(f"  - {issue}", err=True)

                online_suffix = f"; online: {len(live)} live records"
                if stage4_failed or stage5_failed:
                    sys.exit(EXIT_CAPABILITY)

            if emit_canonical and not as_json:
                import yaml

                click.echo(yaml.safe_dump(document, sort_keys=False, allow_unicode=True))
            if as_json:
                vpayload: dict[str, Any] = {
                    "ok": True,
                    "family": family,
                    "mode": "vault_online" if online else "vault_offline",
                    "manifest_path": str(manifest_path.resolve()),
                    "stages_completed": [
                        "json_schema",
                        "semantic_rules",
                        "typed_model",
                        "uid_ref_graph",
                    ],
                    "uid_ref_count": uid_n,
                    "online": online,
                }
                if online and live is not None:
                    vpayload["stages_completed"].extend(
                        ["tenant_capability", "tenant_bindings", "diff_smoke"]
                    )
                    vpayload["live_record_count"] = len(live)
                    vpayload["stage5_summary"] = {
                        "create": create_count,
                        "update": update_count,
                        "delete": delete_count,
                        "conflict": conflict_count,
                    }
                if emit_canonical:
                    import yaml

                    vpayload["canonical_yaml"] = yaml.safe_dump(
                        document, sort_keys=False, allow_unicode=True
                    )
                click.echo(json.dumps(vpayload, indent=2))
            else:
                msg = f"ok: vault ({uid_n} uid_refs)"
                if online_suffix:
                    msg += online_suffix
                click.echo(msg)
            return

        if family == ENTERPRISE_FAMILY:
            try:
                enterprise_manifest = load_enterprise_manifest(document)
                build_enterprise_graph(enterprise_manifest)
                order = enterprise_apply_order(enterprise_manifest)
            except SchemaError as exc:
                click.echo(f"validation failed: {exc}", err=True)
                sys.exit(EXIT_SCHEMA)
            except RefError as exc:
                click.echo(f"reference error: {exc}", err=True)
                sys.exit(EXIT_REF)

            live_enterprise: dict[str, Any] | None = None
            online_suffix = ""
            create_count = update_count = delete_count = conflict_count = 0
            noop_count = skip_count = 0

            if online:
                if ctx.obj.get("provider") != "commander":
                    click.echo(
                        "`keeper-enterprise.v1` --online requires --provider commander "
                        "(Commander CLI enterprise-info discover + diff smoke).",
                        err=True,
                    )
                    sys.exit(EXIT_CAPABILITY)
                provider = CommanderCliProvider()
                try:
                    live_enterprise = provider.discover_enterprise()
                except CapabilityError as exc:
                    click.echo(f"discovery failed: {exc}", err=True)
                    sys.exit(EXIT_CAPABILITY)

                changes = compute_enterprise_diff(
                    enterprise_manifest,
                    live_enterprise,
                    manifest_name=manifest_path.stem,
                )
                create_count = sum(1 for c in changes if c.kind.value == "create")
                update_count = sum(1 for c in changes if c.kind.value == "update")
                delete_count = sum(1 for c in changes if c.kind.value == "delete")
                conflict_count = sum(1 for c in changes if c.kind.value == "conflict")
                noop_count = sum(1 for c in changes if c.kind.value == "noop")
                skip_count = sum(1 for c in changes if c.kind.value == "skip")
                if not as_json:
                    click.echo(
                        "stage 5: "
                        f"{create_count} create, "
                        f"{update_count} update, "
                        f"{delete_count} delete-candidates, "
                        f"{conflict_count} conflicts, "
                        f"{noop_count} noop, "
                        f"{skip_count} skip"
                    )
                online_suffix = (
                    f"; online: {_enterprise_live_object_count(live_enterprise)} enterprise objects"
                )

            if emit_canonical and not as_json:
                import yaml

                click.echo(yaml.safe_dump(document, sort_keys=False, allow_unicode=True))
            if as_json:
                epayload: dict[str, Any] = {
                    "ok": True,
                    "family": family,
                    "mode": "enterprise_online" if online else "enterprise_offline",
                    "manifest_path": str(manifest_path.resolve()),
                    "stages_completed": [
                        "json_schema",
                        "semantic_rules",
                        "typed_model",
                        "uid_ref_graph",
                    ],
                    "uid_ref_count": len(enterprise_manifest.iter_uid_refs()),
                    "online": online,
                }
                if online and live_enterprise is not None:
                    epayload["stages_completed"].append("diff_smoke")
                    epayload["live_enterprise_object_count"] = _enterprise_live_object_count(
                        live_enterprise
                    )
                    epayload["stage5_summary"] = {
                        "create": create_count,
                        "update": update_count,
                        "delete": delete_count,
                        "conflict": conflict_count,
                        "noop": noop_count,
                        "skip": skip_count,
                    }
                if emit_canonical:
                    import yaml

                    epayload["canonical_yaml"] = yaml.safe_dump(
                        document, sort_keys=False, allow_unicode=True
                    )
                click.echo(json.dumps(epayload, indent=2))
            else:
                click.echo(f"ok: {ENTERPRISE_FAMILY} ({len(order)} uid_refs){online_suffix}")
            return

        if family == MSP_FAMILY:
            try:
                msp_manifest = load_msp_manifest(document)
                order = msp_apply_order(msp_manifest)
            except SchemaError as exc:
                click.echo(f"validation failed: {exc}", err=True)
                sys.exit(EXIT_SCHEMA)
            except RefError as exc:
                click.echo(f"reference error: {exc}", err=True)
                sys.exit(EXIT_REF)

            live_msp: list[dict[str, Any]] | None = None
            online_suffix = ""
            create_count = update_count = delete_count = conflict_count = 0
            noop_count = skip_count = 0

            if online:
                provider = _make_provider(ctx, manifest_path, msp=msp_manifest)
                try:
                    live_msp = provider.discover_managed_companies()
                except CapabilityError as exc:
                    click.echo(f"discovery failed: {exc}", err=True)
                    sys.exit(EXIT_CAPABILITY)

                changes = compute_msp_diff(msp_manifest, live_msp)
                create_count = sum(1 for c in changes if c.kind.value == "create")
                update_count = sum(1 for c in changes if c.kind.value == "update")
                delete_count = sum(1 for c in changes if c.kind.value == "delete")
                conflict_count = sum(1 for c in changes if c.kind.value == "conflict")
                noop_count = sum(1 for c in changes if c.kind.value == "noop")
                skip_count = sum(1 for c in changes if c.kind.value == "skip")
                if not as_json:
                    click.echo(
                        "stage 5: "
                        f"{create_count} create, "
                        f"{update_count} update, "
                        f"{delete_count} delete-candidates, "
                        f"{conflict_count} conflicts, "
                        f"{noop_count} noop, "
                        f"{skip_count} skip"
                    )
                online_suffix = f"; online: {len(live_msp)} live managed_companies"

            if emit_canonical and not as_json:
                import yaml

                click.echo(yaml.safe_dump(document, sort_keys=False, allow_unicode=True))
            if as_json:
                mpayload: dict[str, Any] = {
                    "ok": True,
                    "family": family,
                    "mode": "msp_online" if online else "msp_offline",
                    "manifest_name": msp_manifest.name,
                    "manifest_path": str(manifest_path.resolve()),
                    "stages_completed": [
                        "json_schema",
                        "semantic_rules",
                        "typed_model",
                        "managed_company_graph",
                    ],
                    "managed_company_count": len(order),
                    "online": online,
                }
                if online and live_msp is not None:
                    mpayload["stages_completed"].append("diff_smoke")
                    mpayload["live_managed_company_count"] = len(live_msp)
                    mpayload["stage5_summary"] = {
                        "create": create_count,
                        "update": update_count,
                        "delete": delete_count,
                        "conflict": conflict_count,
                        "noop": noop_count,
                        "skip": skip_count,
                    }
                if emit_canonical:
                    import yaml

                    mpayload["canonical_yaml"] = yaml.safe_dump(
                        document, sort_keys=False, allow_unicode=True
                    )
                click.echo(json.dumps(mpayload, indent=2))
            else:
                click.echo(f"ok: {MSP_FAMILY} ({len(order)} managed_companies){online_suffix}")
            return

        if family == SHARING_FAMILY:
            try:
                sharing_manifest = load_sharing_manifest(document)
                order = sharing_apply_order(sharing_manifest)
            except SchemaError as exc:
                click.echo(f"validation failed: {exc}", err=True)
                sys.exit(EXIT_SCHEMA)
            except RefError as exc:
                click.echo(f"reference error: {exc}", err=True)
                sys.exit(EXIT_REF)
            uid_n = len(order)
            if emit_canonical and not as_json:
                import yaml

                click.echo(yaml.safe_dump(document, sort_keys=False, allow_unicode=True))
            if as_json:
                spayload: dict[str, Any] = {
                    "ok": True,
                    "family": family,
                    "mode": "sharing_offline",
                    "manifest_path": str(manifest_path.resolve()),
                    "stages_completed": [
                        "json_schema",
                        "semantic_rules",
                        "typed_model",
                        "uid_ref_graph",
                    ],
                    "uid_ref_count": uid_n,
                    "online": False,
                }
                if emit_canonical:
                    import yaml

                    spayload["canonical_yaml"] = yaml.safe_dump(
                        document, sort_keys=False, allow_unicode=True
                    )
                click.echo(json.dumps(spayload, indent=2))
            else:
                click.echo(f"ok: {SHARING_FAMILY} ({uid_n} uid_refs); online stages skipped.")
            return

        if family == ROTATION_POLICY_FAMILY:
            try:
                rotation_manifest = RotationPolicyManifestV1.model_validate(document)
            except (ValueError, TypeError) as exc:
                click.echo(f"validation failed: typed validation failed: {exc}", err=True)
                sys.exit(EXIT_SCHEMA)

            order = _rotation_policy_apply_order(rotation_manifest)
            online_suffix = ""
            live_rotation: list[LiveRecord] | None = None
            missing_targets: list[str] = []
            if online:
                if ctx.obj.get("provider") != "commander":
                    click.echo(
                        "`rotation-policy.v1` --online requires --provider commander "
                        "(tenant discover + target binding smoke).",
                        err=True,
                    )
                    sys.exit(EXIT_CAPABILITY)
                provider = _make_provider(ctx, manifest_path, rotation=rotation_manifest)
                try:
                    live_rotation = provider.discover()
                except CapabilityError as exc:
                    click.echo(f"discovery failed: {exc}", err=True)
                    sys.exit(EXIT_CAPABILITY)
                missing_targets = _rotation_policy_missing_targets(rotation_manifest, live_rotation)
                if missing_targets and not as_json:
                    click.echo("stage 5: rotation target binding failures:", err=True)
                    for target in missing_targets:
                        click.echo(f"  - target '{target}' not found in tenant records", err=True)
                online_suffix = f"; online: {len(live_rotation)} live records"
                if missing_targets:
                    sys.exit(EXIT_CAPABILITY)

            if emit_canonical and not as_json:
                import yaml

                click.echo(yaml.safe_dump(document, sort_keys=False, allow_unicode=True))
            if as_json:
                rpayload: dict[str, Any] = {
                    "ok": True,
                    "family": family,
                    "mode": "rotation_policy_online" if online else "rotation_policy_offline",
                    "manifest_name": rotation_manifest.name,
                    "manifest_path": str(manifest_path.resolve()),
                    "stages_completed": ["json_schema", "semantic_rules", "typed_model"],
                    "target_count": len(order),
                    "online": online,
                }
                if online and live_rotation is not None:
                    rpayload["stages_completed"].extend(["tenant_bindings", "diff_smoke"])
                    rpayload["live_record_count"] = len(live_rotation)
                    rpayload["stage5_summary"] = {
                        "update": len(order),
                        "missing": len(missing_targets),
                    }
                if emit_canonical:
                    import yaml

                    rpayload["canonical_yaml"] = yaml.safe_dump(
                        document, sort_keys=False, allow_unicode=True
                    )
                click.echo(json.dumps(rpayload, indent=2))
            else:
                click.echo(f"ok: {ROTATION_POLICY_FAMILY} ({len(order)} targets){online_suffix}")
            return

        if family == JIT_ACCESS_FAMILY:
            try:
                jit_manifest = load_jit_manifest(document)
            except SchemaError as exc:
                click.echo(f"validation failed: {exc}", err=True)
                sys.exit(EXIT_SCHEMA)
            order = _jit_apply_order(jit_manifest)
            if emit_canonical and not as_json:
                import yaml

                click.echo(yaml.safe_dump(document, sort_keys=False, allow_unicode=True))
            if as_json:
                jpayload: dict[str, Any] = {
                    "ok": True,
                    "family": family,
                    "mode": "jit_access_offline",
                    "manifest_name": jit_manifest.name,
                    "manifest_path": str(manifest_path.resolve()),
                    "stages_completed": [
                        "json_schema",
                        "semantic_rules",
                        "typed_model",
                        "uid_ref_graph",
                    ],
                    "target_count": len(order),
                    "online": bool(online),
                }
                if emit_canonical:
                    import yaml

                    jpayload["canonical_yaml"] = yaml.safe_dump(
                        document, sort_keys=False, allow_unicode=True
                    )
                click.echo(json.dumps(jpayload, indent=2))
            else:
                click.echo(f"ok: {JIT_ACCESS_FAMILY} ({len(order)} targets)")
            return

        if emit_canonical and not as_json:
            import yaml

            click.echo(yaml.safe_dump(document, sort_keys=False, allow_unicode=True))
        if as_json:
            payload: dict[str, Any] = {
                "ok": True,
                "family": family,
                "mode": "schema_only",
                "manifest_path": str(manifest_path.resolve()),
                "stages_completed": ["json_schema", "semantic_rules"],
            }
            if emit_canonical:
                import yaml

                payload["canonical_yaml"] = yaml.safe_dump(
                    document, sort_keys=False, allow_unicode=True
                )
            click.echo(json.dumps(payload, indent=2))
        else:
            click.echo(
                f"ok: schema-valid ({family}); uid_ref graph + online stages skipped "
                f"(PAM-only until docs/PAM_PARITY_PROGRAM.md provider slices land)."
            )
        return

    try:
        assert_preview_keys_allowed(document)
        manifest = Manifest.model_validate(document)
    except SchemaError as exc:
        click.echo(f"validation failed: {exc}", err=True)
        sys.exit(EXIT_SCHEMA)

    # uid_ref graph sanity
    try:
        build_graph(manifest)
    except RefError as exc:
        click.echo(f"reference error: {exc}", err=True)
        sys.exit(EXIT_REF)

    online_suffix = ""
    pam_live: list[LiveRecord] | None = None
    if online:
        provider = _make_provider(ctx, manifest_path, pam=manifest, vault=None)
        try:
            pam_live = provider.discover()
        except CapabilityError as exc:
            click.echo(f"discovery failed: {exc}", err=True)
            sys.exit(EXIT_CAPABILITY)

        pam_gaps: list[str] = getattr(provider, "unsupported_capabilities", lambda _m: [])(manifest)
        stage4_failed = False
        if pam_gaps:
            if not as_json:
                click.echo("capability gaps (will appear as plan conflicts):", err=True)
                for reason in pam_gaps:
                    click.echo(f"  - {reason}", err=True)
            stage4_failed = True

        live_gateway_names = {
            record.title for record in pam_live if record.resource_type == "gateway"
        }
        for gateway in manifest.gateways:
            if gateway.mode != "reference_existing":
                continue
            if gateway.name in live_gateway_names:
                continue
            if not as_json:
                click.echo(f"stage 4: gateway '{gateway.name}' not found in tenant", err=True)
            stage4_failed = True

        try:
            changes = compute_diff(manifest, pam_live, adopt=False)
        except OwnershipError as exc:
            click.echo(f"ownership error: {exc}", err=True)
            sys.exit(EXIT_CAPABILITY)

        create_count = sum(1 for change in changes if change.kind.value == "create")
        update_count = sum(1 for change in changes if change.kind.value == "update")
        delete_count = sum(1 for change in changes if change.kind.value == "delete")
        conflict_count = sum(1 for change in changes if change.kind.value == "conflict")
        if not as_json:
            click.echo(
                "stage 5: "
                f"{create_count} create, "
                f"{update_count} update, "
                f"{delete_count} delete-candidates, "
                f"{conflict_count} conflicts"
            )

        pam_binding_issues: list[str] = getattr(provider, "check_tenant_bindings", lambda _m: [])(
            manifest
        )
        stage5_failed = False
        if pam_binding_issues:
            stage5_failed = True
            if not as_json:
                click.echo("stage 5: tenant binding failures:", err=True)
                for issue in pam_binding_issues:
                    click.echo(f"  - {issue}", err=True)

        online_suffix = f"; online: {len(pam_live)} live records"
        if stage4_failed or stage5_failed:
            sys.exit(EXIT_CAPABILITY)

    uid_n = len(manifest.iter_uid_refs())
    if as_json:
        payload = {
            "ok": True,
            "family": PAM_FAMILY,
            "mode": "pam_full",
            "manifest_name": manifest.name,
            "uid_ref_count": uid_n,
            "stages_completed": ["json_schema", "semantic_rules", "typed_model", "uid_ref_graph"],
        }
        if online:
            assert pam_live is not None
            payload["stages_completed"].extend(
                ["tenant_capability", "tenant_bindings", "diff_smoke"]
            )
            payload["online"] = True
            payload["live_record_count"] = len(pam_live)
            payload["stage5_summary"] = {
                "create": create_count,
                "update": update_count,
                "delete": delete_count,
                "conflict": conflict_count,
            }
        else:
            payload["online"] = False
        if emit_canonical:
            payload["canonical_yaml"] = dump_manifest(manifest, fmt="yaml")
        click.echo(json.dumps(payload, indent=2))
    else:
        click.echo(f"ok: {manifest.name} ({uid_n} uid_refs){online_suffix}")
        if emit_canonical:
            click.echo(dump_manifest(manifest, fmt="yaml"))


# ---------------------------------------------------------------------------
# export


def _dispatch_export_cmd(commander_json: Path, name: str | None, output: Path | None) -> None:
    try:
        max_bytes = positive_int_env(
            "DSK_CLI_MAX_COMMANDER_JSON_BYTES",
            DEFAULT_CLI_MAX_COMMANDER_JSON_BYTES,
        )
        data = read_json_file_limited(
            commander_json,
            max_bytes=max_bytes,
            max_depth=_cli_json_depth_limit(),
            label="Commander export JSON",
            byte_limit_name="DSK_CLI_MAX_COMMANDER_JSON_BYTES",
            depth_limit_name="DSK_CLI_MAX_JSON_DEPTH",
        )
    except ResourceLimitError as exc:
        raise click.ClickException(f"resource limit exceeded: {exc}") from exc
    manifest_dict = from_pam_import_json(data, name=name or commander_json.stem)
    # validate + type
    from dsk.core.manifest import load_manifest_string

    manifest = load_manifest_string(json.dumps(manifest_dict), suffix=".json")
    rendered = dump_manifest(manifest, fmt="yaml")
    if output:
        output.write_text(rendered, encoding="utf-8")
        click.echo(f"wrote {output}")
    else:
        click.echo(rendered)


@main.command(name="export")
@click.argument("commander_json", type=click.Path(exists=True, path_type=Path))
@click.option("--name", default=None, help="Manifest name (defaults to file stem)")
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Write YAML to file (else stdout)",
)
def export_cmd(commander_json: Path, name: str | None, output: Path | None) -> None:
    """Lift a Commander-shaped PAM project JSON document into a manifest."""
    _dispatch_export_cmd(commander_json, name, output)


# ---------------------------------------------------------------------------
# bootstrap-ksm


def _dispatch_bootstrap_ksm_cmd(
    app_name: str,
    admin_record_uid: str | None,
    create_admin_record: bool,
    config_out: Path | None,
    first_access_minutes: int,
    unlock_ip: bool,
    with_bus: bool,
    bus_title: str,
    overwrite: bool,
    login_helper: str,
) -> None:
    try:
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            params = _params_for_bootstrap(login_helper)
            config_path = config_out or (Path.home() / ".keeper" / f"{app_name}-ksm-config.json")
            result = bootstrap_ksm_application(
                params=params,
                app_name=app_name,
                admin_record_uid=admin_record_uid,
                create_admin_record=create_admin_record,
                config_out=config_path.expanduser().resolve(),
                first_access_minutes=first_access_minutes,
                unlock_ip=unlock_ip,
                create_bus_directory=with_bus,
                bus_directory_title=bus_title,
                overwrite=overwrite,
            )
    except CapabilityError as exc:
        click.echo(
            json.dumps(
                {
                    "status": "fail",
                    "reason": exc.reason,
                    "next_action": exc.next_action or "",
                },
                separators=(",", ":"),
            )
        )
        sys.exit(EXIT_CAPABILITY)

    payload = {
        "status": "ok",
        "app_uid": _uid_prefix(result.app_uid),
        "record_uid": _uid_prefix(result.admin_record_uid),
        "config_path": str(Path(result.config_path).expanduser().resolve()),
        "bus_uid": _uid_prefix(result.bus_directory_uid) if result.bus_directory_uid else None,
        "expires_at": result.expires_at_iso,
        "created_admin_record": result.created_admin_record,
        "created_bus_directory": result.created_bus_directory,
    }
    if result.created_admin_record:
        payload["warning"] = (
            "admin record created with placeholder fields; populate login/password/oneTimeCode "
            "in Web UI"
        )
    click.echo(json.dumps(payload, separators=(",", ":")))
    sys.exit(EXIT_OK)


@main.command("bootstrap-ksm")
@click.option("--app-name", required=True, help="KSM application name, 64 characters max")
@click.option("--admin-record-uid", default=None, help="Existing admin login record UID")
@click.option("--create-admin-record", is_flag=True, help="Create a placeholder admin login record")
@click.option(
    "--config-out",
    type=click.Path(path_type=Path),
    default=None,
    help="Output ksm-config.json path (defaults to ~/.keeper/<app-name>-ksm-config.json)",
)
@click.option(
    "--first-access-minutes",
    type=click.IntRange(0, 1440),
    default=10,
    show_default=True,
    help="Client token first-access expiry in minutes",
)
@click.option("--unlock-ip", is_flag=True, help="Create the KSM client without IP lock")
@click.option("--with-bus", is_flag=True, help="Create or reuse the Phase B bus directory record")
@click.option("--bus-title", default="dsk-agent-bus-directory", show_default=True)
@click.option("--overwrite", is_flag=True, help="Overwrite an existing --config-out file")
@click.option(
    "--login-helper",
    default="commander",
    show_default=True,
    help="Source admin session: commander, ksm, or /path/to/custom_helper.py",
)
def bootstrap_ksm_cmd(
    app_name: str,
    admin_record_uid: str | None,
    create_admin_record: bool,
    config_out: Path | None,
    first_access_minutes: int,
    unlock_ip: bool,
    with_bus: bool,
    bus_title: str,
    overwrite: bool,
    login_helper: str,
) -> None:
    """Provision a KSM application, admin-record share, client token, and config."""
    _dispatch_bootstrap_ksm_cmd(
        app_name,
        admin_record_uid,
        create_admin_record,
        config_out,
        first_access_minutes,
        unlock_ip,
        with_bus,
        bus_title,
        overwrite,
        login_helper,
    )


# ---------------------------------------------------------------------------
# plan / diff


def _dispatch_plan(
    ctx: click.Context,
    manifest_path: Path,
    allow_delete: bool,
    as_json: bool,
    output_format: str | None,
    provider_override: str | None,
) -> None:
    if provider_override is not None:
        ctx.obj["provider"] = provider_override
    log_event(
        _LOG,
        "cli.plan.start",
        manifest_path=str(manifest_path),
        allow_delete=allow_delete,
        provider=ctx.obj.get("provider"),
    )
    try:
        resolved_format = _resolve_plan_output_format(as_json, output_format)
    except CapabilityError as exc:
        click.echo(f"capability error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    plan_obj = _build_plan(ctx, manifest_path, allow_delete=allow_delete)
    if resolved_format == "json":
        click.echo(json.dumps(_plan_to_dict(plan_obj), indent=2))
    else:
        click.echo(ctx.obj["renderer"].render_plan(plan_obj))
    exit_code = _exit_from_plan(plan_obj)
    log_event(
        _LOG,
        "cli.plan.complete",
        summary=_plan_to_dict(plan_obj).get("summary", {}),
        exit_code=exit_code,
    )
    sys.exit(exit_code)


def _dispatch_diff(ctx: click.Context, manifest_path: Path, allow_delete: bool) -> None:
    log_event(_LOG, "cli.diff.start", manifest_path=str(manifest_path), allow_delete=allow_delete)
    plan_obj = _build_plan(ctx, manifest_path, allow_delete=allow_delete)
    click.echo(ctx.obj["renderer"].render_diff(plan_obj))
    exit_code = _exit_from_plan(plan_obj)
    log_event(_LOG, "cli.diff.complete", exit_code=exit_code)
    sys.exit(exit_code)


@main.command()
@click.argument("manifest_path", type=click.Path(exists=True, path_type=Path))
@click.option("--allow-delete", is_flag=True)
@click.option("--json", "as_json", is_flag=True, help="Emit plan as JSON")
@click.option(
    "--format",
    "output_format",
    metavar="FORMAT",
    default=None,
    help="Emit plan as table or json; other formats are reserved capability stubs",
)
@click.option(
    "--provider",
    "provider_override",
    type=click.Choice(["mock", "commander", "service"]),
    default=None,
    help="Override the configured provider",
)
@click.pass_context
def plan(
    ctx: click.Context,
    manifest_path: Path,
    allow_delete: bool,
    as_json: bool,
    output_format: str | None,
    provider_override: str | None,
) -> None:
    """Compute an execution plan against the configured provider.

    Exits 0 when the plan is clean, 2 when changes are present, 4 when conflicts exist.
    """
    _dispatch_plan(ctx, manifest_path, allow_delete, as_json, output_format, provider_override)


@main.command()
@click.argument("manifest_path", type=click.Path(exists=True, path_type=Path))
@click.option("--allow-delete", is_flag=True)
@click.pass_context
def diff(ctx: click.Context, manifest_path: Path, allow_delete: bool) -> None:
    """Show a full field-level diff (secrets redacted)."""
    _dispatch_diff(ctx, manifest_path, allow_delete)


@main.command(name="import")
@click.argument("manifest_path", type=click.Path(exists=True, path_type=Path))
@click.option("--auto-approve", is_flag=True)
@click.option("--dry-run", is_flag=True, help="Show what would be adopted without writing markers")
@click.pass_context
def import_(
    ctx: click.Context,
    manifest_path: Path,
    auto_approve: bool,
    dry_run: bool,
) -> None:
    """Adopt unmanaged live records matching the manifest (writes ownership markers).

    Shows the adoption plan first, then writes markers only after confirmation.
    """
    try:
        document = read_manifest_document(manifest_path)
        fam = validate_manifest(document)
    except SchemaError as exc:
        click.echo(f"validation failed: {exc}", err=True)
        sys.exit(EXIT_SCHEMA)
    except UnsupportedFamilyError as exc:
        click.echo(f"capability error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    except ManifestError as exc:
        click.echo(f"manifest error: {exc}", err=True)
        sys.exit(EXIT_GENERIC)
    if fam != PAM_FAMILY:
        if fam == ENTERPRISE_FAMILY:
            if ctx.obj.get("provider") != "mock":
                click.echo(f"provider error: {_ENTERPRISE_IMPORT_UNSUPPORTED_REASON}", err=True)
                sys.exit(EXIT_CAPABILITY)
            try:
                enterprise_manifest = load_enterprise_manifest(document)
                build_enterprise_graph(enterprise_manifest)
                order = enterprise_apply_order(enterprise_manifest)
            except SchemaError as exc:
                click.echo(f"validation failed: {exc}", err=True)
                sys.exit(EXIT_SCHEMA)
            except RefError as exc:
                click.echo(f"reference error: {exc}", err=True)
                sys.exit(EXIT_REF)

            provider = _make_provider(ctx, manifest_path, enterprise=enterprise_manifest)
            try:
                live_enterprise = provider.discover_enterprise()
            except CapabilityError as exc:
                click.echo(f"discovery failed: {exc}", err=True)
                sys.exit(EXIT_CAPABILITY)

            changes = compute_enterprise_diff(
                enterprise_manifest,
                live_enterprise,
                manifest_name=manifest_path.stem,
                adopt=True,
            )
            import_changes = [
                change
                for change in changes
                if (change.kind is ChangeKind.UPDATE and "adoption" in (change.reason or ""))
                or change.kind is ChangeKind.CONFLICT
            ]
            plan_obj = core_build_plan(manifest_path.stem, import_changes, order)

            click.echo(ctx.obj["renderer"].render_plan(plan_obj))
            for change in plan_obj.updates:
                if change.reason:
                    click.echo(f"adoption: {change.uid_ref or change.title}: {change.reason}")
            if plan_obj.conflicts:
                for conflict in plan_obj.conflicts:
                    click.echo(
                        f"conflict: {conflict.uid_ref or conflict.title}: "
                        f"{conflict.reason or 'blocked'}",
                        err=True,
                    )
                sys.exit(EXIT_CONFLICT)
            if plan_obj.is_clean:
                click.echo("no records to adopt.")
                sys.exit(EXIT_OK)
            if dry_run:
                sys.exit(EXIT_OK)
            if not auto_approve:
                click.confirm("Proceed?", abort=True)

            try:
                outcomes = provider.adopt_enterprise_plan(plan_obj)
            except CapabilityError as exc:
                click.echo(f"provider error: {exc}", err=True)
                sys.exit(EXIT_CAPABILITY)

            click.echo(ctx.obj["renderer"].render_outcomes(outcomes))
            sys.exit(EXIT_OK)
        if fam == MSP_FAMILY:
            if ctx.obj.get("provider") == "commander":
                click.echo(f"provider error: {_MSP_COMMANDER_UNSUPPORTED_REASON}", err=True)
                sys.exit(EXIT_CAPABILITY)
            bundle = _load_plan_context(ctx, manifest_path)
            msp_manifest = bundle.msp
            assert msp_manifest is not None
            changes = compute_msp_diff(msp_manifest, bundle.live_msp, adopt=True)
            adopt_changes = [
                change
                for change in changes
                if change.kind is ChangeKind.UPDATE and "adoption" in (change.reason or "")
            ]
            plan_obj = core_build_plan(bundle.manifest_name, adopt_changes, bundle.order)

            click.echo(ctx.obj["renderer"].render_plan(plan_obj))
            if plan_obj.is_clean:
                click.echo("no records to adopt.")
                sys.exit(EXIT_OK)
            if dry_run:
                sys.exit(EXIT_OK)
            if not auto_approve:
                click.confirm("Proceed?", abort=True)

            try:
                outcomes = bundle.provider.adopt_managed_companies(plan_obj)
            except CapabilityError as exc:
                click.echo(f"provider error: {exc}", err=True)
                sys.exit(EXIT_CAPABILITY)

            click.echo(ctx.obj["renderer"].render_outcomes(outcomes))
            sys.exit(EXIT_OK)
        click.echo("capability error: dsk import applies to pam-environment.v1 only.", err=True)
        sys.exit(EXIT_CAPABILITY)

    bundle = _load_plan_context(ctx, manifest_path)
    pam_manifest = bundle.pam
    assert pam_manifest is not None
    order, live = bundle.order, bundle.live
    try:
        changes = compute_diff(pam_manifest, live, adopt=True)
    except OwnershipError as exc:
        click.echo(f"ownership error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)

    adopt_changes = [
        change
        for change in changes
        if change.kind is ChangeKind.UPDATE and "adoption" in (change.reason or "")
    ]
    plan_obj = core_build_plan(pam_manifest.name, adopt_changes, order)

    click.echo(ctx.obj["renderer"].render_plan(plan_obj))
    if plan_obj.is_clean:
        click.echo("no records to adopt.")
        sys.exit(EXIT_OK)
    if dry_run:
        sys.exit(EXIT_OK)
    if not auto_approve:
        click.confirm("Proceed?", abort=True)

    provider = bundle.provider
    try:
        outcomes = provider.apply_plan(plan_obj, dry_run=False)
    except CapabilityError as exc:
        click.echo(f"provider error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)

    click.echo(ctx.obj["renderer"].render_outcomes(outcomes))
    sys.exit(EXIT_OK)


# ---------------------------------------------------------------------------
# apply


@main.command()
@click.argument("manifest_path", type=click.Path(exists=True, path_type=Path))
@click.option("--allow-delete", is_flag=True)
@click.option("--auto-approve", "--yes", is_flag=True)
@click.option("--dry-run", is_flag=True, help="Render what would run without mutating")
@click.option(
    "--provider",
    "provider_override",
    type=click.Choice(["mock", "commander", "service"]),
    default=None,
    help="Override the configured provider",
)
@click.pass_context
def apply(
    ctx: click.Context,
    manifest_path: Path,
    allow_delete: bool,
    auto_approve: bool,
    dry_run: bool,
    provider_override: str | None,
) -> None:
    """Apply a manifest via the selected provider."""
    if provider_override is not None:
        ctx.obj["provider"] = provider_override
    log_event(
        _LOG,
        "cli.apply.start",
        manifest_path=str(manifest_path),
        allow_delete=allow_delete,
        dry_run=dry_run,
        provider=ctx.obj.get("provider"),
    )
    plan_obj = _build_plan(ctx, manifest_path, allow_delete=allow_delete)
    bundle = ctx.obj["_plan_bundle"]
    if dry_run:
        click.echo(ctx.obj["renderer"].render_plan(plan_obj))
        if bundle.k8s_eso is not None:
            try:
                K8sEsoProvider().apply_plan(plan_obj, dry_run=True)
            except CapabilityError as exc:
                click.echo(f"provider error: {exc}", err=True)
                if exc.context:
                    for key, value in exc.context.items():
                        click.echo(f"  {key}: {value}", err=True)
                sys.exit(EXIT_CAPABILITY)
            sys.exit(EXIT_OK)
        if bundle.terraform is not None:
            try:
                TerraformProvider(workdir=manifest_path.parent).apply_plan(plan_obj, dry_run=True)
            except CapabilityError as exc:
                click.echo(f"provider error: {exc}", err=True)
                if exc.context:
                    for key, value in exc.context.items():
                        click.echo(f"  {key}: {value}", err=True)
                sys.exit(EXIT_CAPABILITY)
            sys.exit(EXIT_OK)
        sys.exit(_exit_from_plan(plan_obj))
    click.echo(ctx.obj["renderer"].render_plan(plan_obj))
    if plan_obj.is_clean:
        click.echo("nothing to do.")
        sys.exit(EXIT_OK)
    if plan_obj.conflicts and not allow_delete:
        for conflict in plan_obj.conflicts:
            if conflict.reason:
                click.echo(f"conflict: {conflict.reason}", err=True)
        click.echo(f"{len(plan_obj.conflicts)} conflict(s) must be resolved first.", err=True)
        sys.exit(EXIT_CONFLICT)
    if bundle.pam_extended is not None:
        click.echo(
            (
                f"provider error: {PAM_EXTENDED_FAMILY} apply is upstream-gap "
                "(offline schema/model/diff and plan only; no Commander write/readback proof)"
            ),
            err=True,
        )
        sys.exit(EXIT_CAPABILITY)
    if not auto_approve and not dry_run:
        click.confirm("Proceed?", abort=True)
    provider = bundle.provider
    try:
        if bundle.msp is not None:
            outcomes = provider.apply_msp_plan(plan_obj, dry_run=dry_run)
        elif bundle.jit is not None:
            if not hasattr(provider, "apply_jit_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "jit-access.v1 apply support"
                    ),
                    next_action=(
                        "configure jit_settings via pam project import JSON; see docs/JIT_ACCESS.md"
                    ),
                )
            outcomes = provider.apply_jit_plan(plan_obj, dry_run=dry_run)
        elif bundle.rotation is not None:
            if not hasattr(provider, "apply_rotation_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "rotation-policy.v1 apply support"
                    ),
                    next_action="use `--provider commander` for rotation-policy.v1 apply",
                )
            outcomes = provider.apply_rotation_plan(plan_obj, dry_run=dry_run)
        elif bundle.ksm is not None:
            if not hasattr(provider, "apply_ksm_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no KSM apply support"
                    ),
                    next_action=(
                        "use `--provider commander` for supported KSM app lifecycle rows "
                        "or `--provider mock` for full offline simulation"
                    ),
                )
            outcomes = provider.apply_ksm_plan(plan_obj, dry_run=dry_run)
        elif bundle.scim is not None:
            if not hasattr(provider, "apply_scim_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "keeper-scim.v1 apply support"
                    ),
                    next_action=(
                        "use `--provider commander` for the SCIM apply stub or "
                        "`--provider mock` for offline simulation"
                    ),
                )
            outcomes = provider.apply_scim_plan(plan_obj, dry_run=dry_run)
        elif bundle.enterprise is not None:
            if not hasattr(provider, "apply_enterprise_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "keeper-enterprise.v1 apply support"
                    ),
                    next_action=(
                        "use `--provider commander` for Commander stub next_action hints "
                        "or `--provider mock` for offline simulation"
                    ),
                )
            outcomes = provider.apply_enterprise_plan(
                plan_obj,
                bundle.enterprise,
                dry_run=dry_run,
            )
        elif bundle.nhi is not None:
            if not hasattr(provider, "apply_nhi_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "nhi-agent.v1 apply support"
                    ),
                    next_action=(
                        "use `--provider commander` for upstream GA stub diagnostics "
                        "or `--provider mock` for offline simulation"
                    ),
                )
            outcomes = provider.apply_nhi_plan(plan_obj, dry_run=dry_run)
        elif bundle.ai_agent is not None:
            if not hasattr(provider, "apply_ai_agent_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "ai-agent.v1 apply support"
                    ),
                    next_action=(
                        "use `--provider commander` for upstream GA stub diagnostics "
                        "or `--provider mock` for offline simulation"
                    ),
                )
            outcomes = provider.apply_ai_agent_plan(plan_obj, dry_run=dry_run)
        elif bundle.privileged_access is not None:
            if not hasattr(provider, "apply_privileged_access_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "keeper-privileged-access.v1 apply support"
                    ),
                    next_action="use `--provider mock` for offline simulation",
                )
            outcomes = provider.apply_privileged_access_plan(plan_obj, dry_run=dry_run)
        elif bundle.workflow is not None:
            if not hasattr(provider, "apply_workflow_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "keeper-workflow.v1 apply support"
                    ),
                    next_action="use `--provider mock` for offline simulation or `DSK_PREVIEW=1` with commander 17.2.14+",
                )
            outcomes = provider.apply_workflow_plan(plan_obj, dry_run=dry_run)
        elif bundle.saas_rotation is not None:
            if not hasattr(provider, "apply_saas_rotation_plan"):
                raise CapabilityError(
                    reason=(
                        f"provider {ctx.obj.get('provider', 'mock')!r} has no "
                        "keeper-saas-rotation.v1 apply support"
                    ),
                    next_action="use `--provider mock` for offline simulation or `DSK_PREVIEW=1` with commander 18.0.0+",
                )
            outcomes = provider.apply_saas_rotation_plan(plan_obj, dry_run=dry_run)
        elif bundle.epm_policy is not None:
            outcomes = provider.apply_epm_policy_plan(plan_obj, dry_run=dry_run)
        elif bundle.policy is not None:
            if not hasattr(provider, "apply_policy_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_policy_plan(plan_obj, dry_run=dry_run)
        elif bundle.ai_act is not None:
            if not hasattr(provider, "apply_ai_act_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_ai_act_plan(plan_obj, dry_run=dry_run)
        elif bundle.ai_policy is not None:
            if not hasattr(provider, "apply_ai_policy_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_ai_policy_plan(plan_obj, dry_run=dry_run)
        elif bundle.ai_token is not None:
            if not hasattr(provider, "apply_ai_token_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_ai_token_plan(plan_obj, dry_run=dry_run)
        elif bundle.cmmc is not None:
            if not hasattr(provider, "apply_cmmc_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_cmmc_plan(plan_obj, dry_run=dry_run)
        elif bundle.dora is not None:
            if not hasattr(provider, "apply_dora_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_dora_plan(plan_obj, dry_run=dry_run)
        elif bundle.pqc is not None:
            if not hasattr(provider, "apply_pqc_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_pqc_plan(plan_obj, dry_run=dry_run)
        elif bundle.itsm_gate is not None:
            if not hasattr(provider, "apply_itsm_gate_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_itsm_gate_plan(plan_obj, dry_run=dry_run)
        elif bundle.slack_gate is not None:
            if not hasattr(provider, "apply_slack_gate_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_slack_gate_plan(plan_obj, dry_run=dry_run)
        elif bundle.mcp_binding is not None:
            if not hasattr(provider, "apply_mcp_binding_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_mcp_binding_plan(plan_obj, dry_run=dry_run)
        elif bundle.spiffe is not None:
            if not hasattr(provider, "apply_spiffe_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_spiffe_plan(plan_obj, dry_run=dry_run)
        elif bundle.workflow_gate is not None:
            if not hasattr(provider, "apply_workflow_gate_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_workflow_gate_plan(plan_obj, dry_run=dry_run)
        elif bundle.trust_chain is not None:
            if not hasattr(provider, "apply_trust_chain_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_trust_chain_plan(plan_obj, dry_run=dry_run)
        elif bundle.connection_profile_m is not None:
            if not hasattr(provider, "apply_connection_profile_m_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_connection_profile_m_plan(plan_obj, dry_run=dry_run)
        elif bundle.db_access is not None:
            if not hasattr(provider, "apply_db_access_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_db_access_plan(plan_obj, dry_run=dry_run)
        elif bundle.gateway_ha is not None:
            if not hasattr(provider, "apply_gateway_ha_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_gateway_ha_plan(plan_obj, dry_run=dry_run)
        elif bundle.tunnel_m is not None:
            if not hasattr(provider, "apply_tunnel_m_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_tunnel_m_plan(plan_obj, dry_run=dry_run)
        elif bundle.pipeline_env is not None:
            if not hasattr(provider, "apply_pipeline_env_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_pipeline_env_plan(plan_obj, dry_run=dry_run)
        elif bundle.cloud_jit is not None:
            if not hasattr(provider, "apply_cloud_jit_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_cloud_jit_plan(plan_obj, dry_run=dry_run)
        elif bundle.compliance_m is not None:
            if not hasattr(provider, "apply_compliance_m_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_compliance_m_plan(plan_obj, dry_run=dry_run)
        elif bundle.cspm is not None:
            if not hasattr(provider, "apply_cspm_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_cspm_plan(plan_obj, dry_run=dry_run)
        elif bundle.evidence_stream is not None:
            if not hasattr(provider, "apply_evidence_stream_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_evidence_stream_plan(plan_obj, dry_run=dry_run)
        elif bundle.secret_scanner is not None:
            if not hasattr(provider, "apply_secret_scanner_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_secret_scanner_plan(plan_obj, dry_run=dry_run)
        elif bundle.keeper_drive_m is not None:
            if not hasattr(provider, "apply_keeper_drive_m_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_keeper_drive_m_plan(plan_obj, dry_run=dry_run)
        elif bundle.agent_kit_m is not None:
            if not hasattr(provider, "apply_agent_kit_m_plan"):
                outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
            else:
                outcomes = provider.apply_agent_kit_m_plan(plan_obj, dry_run=dry_run)
        elif bundle.k8s_eso is not None:
            outcomes = K8sEsoProvider().apply_plan(plan_obj, dry_run=dry_run)
        elif bundle.terraform is not None:
            outcomes = TerraformProvider(workdir=manifest_path.parent).apply_plan(
                plan_obj, dry_run=dry_run
            )
        else:
            outcomes = provider.apply_plan(plan_obj, dry_run=dry_run)
    except CapabilityError as exc:
        click.echo(f"provider error: {exc}", err=True)
        if exc.context:
            for key, value in exc.context.items():
                click.echo(f"  {key}: {value}", err=True)
        sys.exit(EXIT_CAPABILITY)
    click.echo(ctx.obj["renderer"].render_outcomes(outcomes))
    log_event(_LOG, "cli.apply.complete", outcomes=len(outcomes), dry_run=dry_run)
    sys.exit(EXIT_OK)


# ---------------------------------------------------------------------------
# shared helpers


def build_plan(ctx: click.Context, manifest_path: Path, *, allow_delete: bool) -> Plan:
    """Build a DSK plan for in-process library consumers."""

    bundle = _load_plan_context(ctx, manifest_path)
    ctx.obj["_plan_bundle"] = bundle
    capability_subject: (
        Manifest
        | VaultManifestV1
        | SharingManifestV1
        | MspManifestV1
        | IdentityManifestV1
        | KsmManifestV1
        | EventsManifestV1
        | PamExtendedManifestV1
        | EpmManifestV1
        | EpmPolicyManifestV1
        | TerraformIntegrationManifestV1
        | K8sEsoManifestV1
        | SiemManifestV1
        | NhiAgentManifest
        | AiAgentManifest
        | WorkflowManifestV1
        | SaaSRotationManifestV1
        | RotationPolicyManifestV1
        | JitManifestV1
        | ScimManifestV1
        | EnterpriseManifestV1
        | PrivilegedAccessManifestV1
        | AiActProfileManifestV1
        | AiPolicyManifestV1
        | AiTokenManifestV1
        | CmmcProfileManifestV1
        | DoraProfileManifestV1
        | PqcPolicyManifestV1
        | ItsmApprovalGateManifestV1
        | SlackApprovalGateManifestV1
        | McpSecretsBindingManifestV1
        | SpiffeBindingManifestV1
        | WorkflowGateManifestV1
        | TrustChainManifestV1
        | PamConnectionProfileManifestV1
        | DbAccessPolicyManifestV1
        | GatewayHaManifestV1
        | TunnelManifestV1
        | PipelineEphemeralManifestV1
        | CloudJitManifestV1
        | ComplianceBundleManifestV1
        | CspmRemediationManifestV1
        | ContinuousEvidenceStreamManifestV1
        | SecretScannerBridgeManifestV1
        | KeeperDriveManifestV1
        | AgentKitManifestV1
        | PolicyManifestV1
    )
    try:
        if bundle.pam is not None:
            changes = compute_diff(
                bundle.pam,
                bundle.live,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.pam
        elif bundle.vault is not None:
            changes = compute_vault_diff(
                bundle.vault,
                bundle.live,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
                live_record_type_defs=bundle.live_record_type_defs,
            )
            capability_subject = bundle.vault
        elif bundle.msp is not None:
            changes = compute_msp_diff(
                bundle.msp,
                bundle.live_msp,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.msp
        elif bundle.sharing is not None:
            changes = _build_sharing_changes(
                bundle.provider,
                bundle.sharing,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.sharing
        elif bundle.identity is not None:
            changes = compute_identity_diff(
                bundle.identity,
                {},
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.identity
        elif bundle.ksm is not None:
            changes = compute_ksm_diff(
                bundle.ksm,
                bundle.live_ksm,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.ksm
        elif bundle.events is not None:
            changes = compute_events_diff(
                bundle.events,
                {},
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.events
        elif bundle.pam_extended is not None:
            changes = compute_pam_extended_diff(
                bundle.pam_extended,
                {},
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.pam_extended
        elif bundle.epm is not None:
            changes = compute_epm_diff(
                bundle.epm,
                {},
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            if ctx.obj.get("provider", "mock") != "mock":
                raise CapabilityError(
                    reason=(
                        f"{EPM_FAMILY} plan/apply is upstream-gap "
                        "(offline schema/model/diff only; no PEDM tenant write/readback proof)"
                    ),
                    next_action=(
                        "use `dsk validate` for schema checks; apply waits on a PEDM tenant "
                        "writer proven through MSP managed-company lab context"
                    ),
                )
            capability_subject = bundle.epm
        elif bundle.epm_policy is not None:
            changes = compute_epm_policy_diff(
                bundle.epm_policy,
                {},
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            if ctx.obj.get("provider", "mock") != "mock":
                raise CapabilityError(
                    reason=(
                        f"{EPM_POLICY_FAMILY} plan/apply is upstream-gap "
                        "(offline schema/model/diff only; no PEDM tenant Commander apply verb)"
                    ),
                    next_action=(
                        "use `dsk validate` for schema checks; apply waits on PEDM Commander integration"
                    ),
                )
            capability_subject = bundle.epm_policy
        elif bundle.policy is not None:
            changes = compute_policy_diff(
                bundle.policy,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.policy
        elif bundle.terraform is not None:
            tf_plan = TerraformProvider(workdir=manifest_path.parent).plan(bundle.terraform)
            changes = list(tf_plan.changes)
            capability_subject = bundle.terraform
        elif bundle.k8s_eso is not None:
            k8s_plan = K8sEsoProvider().plan(bundle.k8s_eso)
            changes = list(k8s_plan.changes)
            capability_subject = bundle.k8s_eso
        elif bundle.siem is not None:
            changes = compute_siem_diff(
                bundle.siem,
                {},
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.siem
        elif bundle.rotation is not None:
            changes = _build_rotation_policy_changes(bundle.rotation, bundle.live)
            capability_subject = bundle.rotation
        elif bundle.jit is not None:
            changes = _build_jit_policy_changes(bundle.jit, bundle.provider)
            capability_subject = bundle.jit
        elif bundle.scim is not None:
            changes = compute_scim_diff(
                bundle.scim,
                {},
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.scim
        elif bundle.enterprise is not None:
            changes = compute_enterprise_diff(
                bundle.enterprise,
                bundle.live_enterprise,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.enterprise
        elif bundle.nhi is not None:
            changes = compute_nhi_diff(
                bundle.nhi,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.nhi
        elif bundle.ai_agent is not None:
            changes = compute_ai_agent_diff(
                bundle.ai_agent,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.ai_agent
        elif bundle.agentic_skill_policy is not None:
            changes = compute_agentic_skill_policy_diff(
                bundle.agentic_skill_policy,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.agentic_skill_policy  # type: ignore[assignment]
        elif bundle.agent_memory_policy is not None:
            changes = compute_agent_memory_policy_diff(
                bundle.agent_memory_policy,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.agent_memory_policy  # type: ignore[assignment]
        elif bundle.mcp_allowlist is not None:
            changes = compute_mcp_allowlist_diff(
                bundle.mcp_allowlist,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.mcp_allowlist  # type: ignore[assignment]
        elif bundle.privileged_access is not None:
            changes = compute_privileged_access_diff(
                bundle.privileged_access,
                {},
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.privileged_access
        elif bundle.workflow is not None:
            changes = compute_workflow_diff(
                bundle.workflow,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.workflow
        elif bundle.saas_rotation is not None:
            changes = compute_saas_rotation_diff(
                bundle.saas_rotation,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.saas_rotation
        elif bundle.ai_act is not None:
            changes = compute_ai_act_diff(
                bundle.ai_act,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.ai_act
        elif bundle.ai_policy is not None:
            changes = compute_ai_policy_diff(
                bundle.ai_policy,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.ai_policy
        elif bundle.ai_token is not None:
            changes = compute_ai_token_diff(
                bundle.ai_token,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.ai_token
        elif bundle.cmmc is not None:
            changes = compute_cmmc_diff(
                bundle.cmmc,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.cmmc
        elif bundle.dora is not None:
            changes = compute_dora_diff(
                bundle.dora,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.dora
        elif bundle.pqc is not None:
            changes = compute_pqc_diff(
                bundle.pqc,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.pqc
        elif bundle.itsm_gate is not None:
            changes = compute_itsm_gate_diff(
                bundle.itsm_gate,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.itsm_gate
        elif bundle.slack_gate is not None:
            changes = compute_slack_gate_diff(
                bundle.slack_gate,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.slack_gate
        elif bundle.mcp_binding is not None:
            changes = compute_mcp_diff(
                bundle.mcp_binding,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.mcp_binding
        elif bundle.spiffe is not None:
            changes = compute_spiffe_diff(
                bundle.spiffe,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.spiffe
        elif bundle.workflow_gate is not None:
            changes = compute_workflow_gate_diff(
                bundle.workflow_gate,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.workflow_gate
        elif bundle.trust_chain is not None:
            changes = compute_trust_chain_diff(
                bundle.trust_chain,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.trust_chain
        elif bundle.connection_profile_m is not None:
            changes = compute_connection_profile_diff(
                bundle.connection_profile_m,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.connection_profile_m
        elif bundle.db_access is not None:
            changes = compute_db_access_diff(
                bundle.db_access,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.db_access
        elif bundle.gateway_ha is not None:
            changes = compute_gateway_ha_diff(
                bundle.gateway_ha,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.gateway_ha
        elif bundle.tunnel_m is not None:
            changes = compute_tunnel_diff(
                bundle.tunnel_m,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.tunnel_m
        elif bundle.pipeline_env is not None:
            changes = compute_pipeline_env_diff(
                bundle.pipeline_env,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.pipeline_env
        elif bundle.cloud_jit is not None:
            changes = compute_cloud_jit_diff(
                bundle.cloud_jit,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.cloud_jit
        elif bundle.compliance_m is not None:
            changes = compute_compliance_diff(
                bundle.compliance_m,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.compliance_m
        elif bundle.cspm is not None:
            changes = compute_cspm_diff(
                bundle.cspm,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.cspm
        elif bundle.evidence_stream is not None:
            changes = compute_evidence_stream_diff(
                bundle.evidence_stream,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.evidence_stream
        elif bundle.secret_scanner is not None:
            changes = compute_secret_scanner_diff(
                bundle.secret_scanner,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.secret_scanner
        elif bundle.keeper_drive_m is not None:
            changes = compute_keeper_drive_diff(
                bundle.keeper_drive_m,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.keeper_drive_m
        elif bundle.agent_kit_m is not None:
            changes = compute_agent_kit_diff(
                bundle.agent_kit_m,
                None,
                manifest_name=bundle.manifest_name,
                allow_delete=allow_delete,
            )
            capability_subject = bundle.agent_kit_m
        else:
            raise CapabilityError(
                "plan is not supported for this manifest family; "
                "use `dsk validate` to check schema only",
                next_action="dsk validate <path>",
            )
    except OwnershipError as exc:
        click.echo(f"ownership error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    except CapabilityError as exc:
        click.echo(f"discovery failed: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)

    # Surface provider capability gaps as CONFLICT rows so plan / dry-run /
    # apply are behaviourally identical (DELIVERY_PLAN.md: "plan == apply
    # --dry-run"). Without this, CommanderCliProvider.apply_plan would only
    # raise at real-apply time — operators would see green plans. See
    # REVIEW.md "Update — second pass / C3".
    try:
        capability_gaps = bundle.provider.unsupported_capabilities(capability_subject)
    except AttributeError:
        # Older third-party providers may not implement the hook; treat
        # as "no gaps" rather than breaking their integration.
        capability_gaps = []
    for reason in capability_gaps:
        from dsk.core.diff import Change, ChangeKind

        changes.insert(
            0,
            Change(
                kind=ChangeKind.CONFLICT,
                uid_ref=None,
                resource_type="capability",
                title="unsupported-by-provider",
                reason=reason,
            ),
        )

    plan_obj = core_build_plan(bundle.manifest_name, changes, bundle.order)
    setattr(plan_obj, "allow_delete", allow_delete)
    if bundle.k8s_eso is not None:
        setattr(plan_obj, "_k8s_eso_manifest", bundle.k8s_eso)
    elif bundle.terraform is not None:
        setattr(plan_obj, "_terraform_manifest", bundle.terraform)
    return plan_obj


_build_plan = build_plan


def _load_plan_context(ctx: click.Context, manifest_path: Path) -> PlanLoadBundle:
    try:
        typed = load_declarative_manifest(manifest_path)
    except SchemaError as exc:
        click.echo(f"validation failed: {exc}", err=True)
        sys.exit(EXIT_SCHEMA)
    except RefError as exc:
        click.echo(f"reference error: {exc}", err=True)
        sys.exit(EXIT_REF)
    except CapabilityError as exc:
        click.echo(f"capability error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    except UnsupportedFamilyError as exc:
        try:
            document = read_manifest_document(manifest_path)
            family = validate_manifest(document)
        except (SchemaError, RefError, CapabilityError, ManifestError) as fallback_exc:
            click.echo(f"capability error: {fallback_exc}", err=True)
            sys.exit(EXIT_CAPABILITY)
        if family == ROTATION_POLICY_FAMILY:
            try:
                typed = RotationPolicyManifestV1.model_validate(document)
            except (ValueError, TypeError) as rotation_exc:
                click.echo(f"validation failed: typed validation failed: {rotation_exc}", err=True)
                sys.exit(EXIT_SCHEMA)
        elif family == EPM_POLICY_FAMILY:
            try:
                typed = EpmPolicyManifestV1.model_validate(document)
            except (ValueError, TypeError) as epm_policy_exc:
                click.echo(
                    f"validation failed: typed validation failed: {epm_policy_exc}",
                    err=True,
                )
                sys.exit(EXIT_SCHEMA)
        else:
            click.echo(f"capability error: {exc}", err=True)
            sys.exit(EXIT_CAPABILITY)
    except ManifestError as exc:
        click.echo(f"manifest error: {exc}", err=True)
        sys.exit(EXIT_GENERIC)

    pam: Manifest | None = typed if isinstance(typed, Manifest) else None
    vault: VaultManifestV1 | None = typed if isinstance(typed, VaultManifestV1) else None
    sharing: SharingManifestV1 | None = typed if isinstance(typed, SharingManifestV1) else None
    msp: MspManifestV1 | None = typed if isinstance(typed, MspManifestV1) else None
    identity: IdentityManifestV1 | None = typed if isinstance(typed, IdentityManifestV1) else None
    ksm: KsmManifestV1 | None = typed if isinstance(typed, KsmManifestV1) else None
    pam_extended: PamExtendedManifestV1 | None = (
        typed if isinstance(typed, PamExtendedManifestV1) else None
    )
    epm: EpmManifestV1 | None = typed if isinstance(typed, EpmManifestV1) else None
    terraform: TerraformIntegrationManifestV1 | None = (
        typed if isinstance(typed, TerraformIntegrationManifestV1) else None
    )
    k8s_eso: K8sEsoManifestV1 | None = typed if isinstance(typed, K8sEsoManifestV1) else None
    siem: SiemManifestV1 | None = typed if isinstance(typed, SiemManifestV1) else None
    events: EventsManifestV1 | None = typed if isinstance(typed, EventsManifestV1) else None
    epm_policy: EpmPolicyManifestV1 | None = (
        typed if isinstance(typed, EpmPolicyManifestV1) else None
    )
    rotation: RotationPolicyManifestV1 | None = (
        typed if isinstance(typed, RotationPolicyManifestV1) else None
    )
    jit: JitManifestV1 | None = typed if isinstance(typed, JitManifestV1) else None
    scim: ScimManifestV1 | None = typed if isinstance(typed, ScimManifestV1) else None
    enterprise: EnterpriseManifestV1 | None = (
        typed if isinstance(typed, EnterpriseManifestV1) else None
    )
    privileged_access: PrivilegedAccessManifestV1 | None = (
        typed if isinstance(typed, PrivilegedAccessManifestV1) else None
    )
    nhi: NhiAgentManifest | None = typed if isinstance(typed, NhiAgentManifest) else None
    ai_agent: AiAgentManifest | None = typed if isinstance(typed, AiAgentManifest) else None
    agentic_skill_policy: AgenticSkillPolicyManifest | None = (
        typed if isinstance(typed, AgenticSkillPolicyManifest) else None
    )
    agent_memory_policy: AgentMemoryPolicyManifest | None = (
        typed if isinstance(typed, AgentMemoryPolicyManifest) else None
    )
    mcp_allowlist: McpAllowlistManifest | None = (
        typed if isinstance(typed, McpAllowlistManifest) else None
    )
    workflow: WorkflowManifestV1 | None = typed if isinstance(typed, WorkflowManifestV1) else None
    saas_rotation: SaaSRotationManifestV1 | None = (
        typed if isinstance(typed, SaaSRotationManifestV1) else None
    )
    ai_act: AiActProfileManifestV1 | None = (
        typed if isinstance(typed, AiActProfileManifestV1) else None
    )
    ai_policy: AiPolicyManifestV1 | None = typed if isinstance(typed, AiPolicyManifestV1) else None
    ai_token: AiTokenManifestV1 | None = typed if isinstance(typed, AiTokenManifestV1) else None
    cmmc: CmmcProfileManifestV1 | None = typed if isinstance(typed, CmmcProfileManifestV1) else None
    dora: DoraProfileManifestV1 | None = typed if isinstance(typed, DoraProfileManifestV1) else None
    pqc: PqcPolicyManifestV1 | None = typed if isinstance(typed, PqcPolicyManifestV1) else None
    itsm_gate: ItsmApprovalGateManifestV1 | None = (
        typed if isinstance(typed, ItsmApprovalGateManifestV1) else None
    )
    slack_gate: SlackApprovalGateManifestV1 | None = (
        typed if isinstance(typed, SlackApprovalGateManifestV1) else None
    )
    mcp_binding: McpSecretsBindingManifestV1 | None = (
        typed if isinstance(typed, McpSecretsBindingManifestV1) else None
    )
    spiffe: SpiffeBindingManifestV1 | None = (
        typed if isinstance(typed, SpiffeBindingManifestV1) else None
    )
    workflow_gate: WorkflowGateManifestV1 | None = (
        typed if isinstance(typed, WorkflowGateManifestV1) else None
    )
    trust_chain: TrustChainManifestV1 | None = (
        typed if isinstance(typed, TrustChainManifestV1) else None
    )
    connection_profile_m: PamConnectionProfileManifestV1 | None = (
        typed if isinstance(typed, PamConnectionProfileManifestV1) else None
    )
    db_access: DbAccessPolicyManifestV1 | None = (
        typed if isinstance(typed, DbAccessPolicyManifestV1) else None
    )
    gateway_ha: GatewayHaManifestV1 | None = (
        typed if isinstance(typed, GatewayHaManifestV1) else None
    )
    tunnel_m: TunnelManifestV1 | None = typed if isinstance(typed, TunnelManifestV1) else None
    pipeline_env: PipelineEphemeralManifestV1 | None = (
        typed if isinstance(typed, PipelineEphemeralManifestV1) else None
    )
    cloud_jit: CloudJitManifestV1 | None = typed if isinstance(typed, CloudJitManifestV1) else None
    compliance_m: ComplianceBundleManifestV1 | None = (
        typed if isinstance(typed, ComplianceBundleManifestV1) else None
    )
    cspm: CspmRemediationManifestV1 | None = (
        typed if isinstance(typed, CspmRemediationManifestV1) else None
    )
    evidence_stream: ContinuousEvidenceStreamManifestV1 | None = (
        typed if isinstance(typed, ContinuousEvidenceStreamManifestV1) else None
    )
    secret_scanner: SecretScannerBridgeManifestV1 | None = (
        typed if isinstance(typed, SecretScannerBridgeManifestV1) else None
    )
    keeper_drive_m: KeeperDriveManifestV1 | None = (
        typed if isinstance(typed, KeeperDriveManifestV1) else None
    )
    agent_kit_m: AgentKitManifestV1 | None = (
        typed if isinstance(typed, AgentKitManifestV1) else None
    )
    policy: PolicyManifestV1 | None = typed if isinstance(typed, PolicyManifestV1) else None
    if pam is not None:
        manifest_name = pam.name
    elif msp is not None:
        manifest_name = msp.name
    elif rotation is not None:
        manifest_name = rotation.name
    elif jit is not None:
        manifest_name = jit.name
    elif identity is not None:
        manifest_name = IDENTITY_FAMILY
    elif events is not None:
        manifest_name = events.name
    elif pam_extended is not None:
        manifest_name = PAM_EXTENDED_FAMILY
    elif epm is not None:
        manifest_name = EPM_FAMILY
    elif terraform is not None:
        manifest_name = TERRAFORM_FAMILY
    elif k8s_eso is not None:
        manifest_name = K8S_ESO_FAMILY
    elif siem is not None:
        manifest_name = siem.name or SIEM_FAMILY
    elif scim is not None:
        manifest_name = scim.name
    elif workflow is not None:
        manifest_name = "keeper-workflow"
    elif saas_rotation is not None:
        manifest_name = "keeper-saas-rotation"
    elif epm_policy is not None:
        manifest_name = EPM_POLICY_FAMILY
    elif ai_act is not None:
        manifest_name = manifest_path.stem
    elif ai_policy is not None:
        manifest_name = manifest_path.stem
    elif ai_token is not None:
        manifest_name = manifest_path.stem
    elif cmmc is not None:
        manifest_name = manifest_path.stem
    elif dora is not None:
        manifest_name = manifest_path.stem
    elif pqc is not None:
        manifest_name = manifest_path.stem
    elif itsm_gate is not None:
        manifest_name = manifest_path.stem
    elif slack_gate is not None:
        manifest_name = manifest_path.stem
    elif mcp_binding is not None:
        manifest_name = manifest_path.stem
    elif spiffe is not None:
        manifest_name = manifest_path.stem
    elif workflow_gate is not None:
        manifest_name = manifest_path.stem
    elif trust_chain is not None:
        manifest_name = manifest_path.stem
    elif connection_profile_m is not None:
        manifest_name = manifest_path.stem
    elif db_access is not None:
        manifest_name = manifest_path.stem
    elif gateway_ha is not None:
        manifest_name = manifest_path.stem
    elif tunnel_m is not None:
        manifest_name = manifest_path.stem
    elif pipeline_env is not None:
        manifest_name = manifest_path.stem
    elif cloud_jit is not None:
        manifest_name = manifest_path.stem
    elif compliance_m is not None:
        manifest_name = manifest_path.stem
    elif cspm is not None:
        manifest_name = manifest_path.stem
    elif evidence_stream is not None:
        manifest_name = manifest_path.stem
    elif secret_scanner is not None:
        manifest_name = manifest_path.stem
    elif keeper_drive_m is not None:
        manifest_name = manifest_path.stem
    elif agent_kit_m is not None:
        manifest_name = manifest_path.stem
    elif policy is not None:
        manifest_name = policy.name
    elif agentic_skill_policy is not None:
        manifest_name = agentic_skill_policy.name
    elif agent_memory_policy is not None:
        manifest_name = agent_memory_policy.name
    elif mcp_allowlist is not None:
        manifest_name = mcp_allowlist.name
    else:
        manifest_name = manifest_path.stem

    try:
        if pam is not None:
            graph = build_graph(pam)
            order = execution_order(graph)
        elif vault is not None:
            assert vault is not None
            order = vault_record_apply_order(vault)
        elif msp is not None:
            order = msp_apply_order(msp)
        elif sharing is not None:
            order = sharing_apply_order(sharing)
        elif rotation is not None:
            order = _rotation_policy_apply_order(rotation)
        elif jit is not None:
            order = _jit_apply_order(jit)
        elif scim is not None:
            order = scim_apply_order(scim)
        elif enterprise is not None:
            build_enterprise_graph(enterprise)
            order = enterprise_apply_order(enterprise)
        elif identity is not None:
            order = [domain.name for domain in identity.domains]
            order.extend(uid_ref for uid_ref, _kind in identity.iter_uid_refs())
            if identity.outbound_email is not None:
                order.append("outbound_email")
        elif ksm is not None:
            provider_name = ctx.obj.get("provider", "mock")
            if provider_name == "service":
                raise CapabilityError(
                    reason=(
                        f"{KSM_FAMILY} plan/apply is not implemented for {provider_name} provider"
                    ),
                    next_action=(
                        "use `--provider commander` for supported KSM app lifecycle rows "
                        "or `--provider mock` for full offline simulation"
                    ),
                )
            order = ksm_apply_order(ksm)
        elif events is not None:
            order = [uid_ref for uid_ref, _kind in events.iter_uid_refs()]
        elif pam_extended is not None:
            order = [uid_ref for uid_ref, _kind in pam_extended.iter_object_refs()]
        elif epm is not None:
            raise CapabilityError(
                reason=(
                    f"{EPM_FAMILY} plan/apply is upstream-gap "
                    "(offline schema/model/diff only; no PEDM tenant write/readback proof)"
                ),
                next_action=(
                    "use `dsk validate` for schema checks; apply waits on a PEDM tenant "
                    "writer proven through MSP managed-company lab context"
                ),
            )
        elif epm_policy is not None:
            order = [f"default_policies:{category}" for category in epm_policy.default_policies]
            order.extend(
                str(getattr(policy, "uid_ref", None) or policy.name)
                for policy in epm_policy.policies
            )
        elif terraform is not None:
            order = [
                f"{row.dsk_family}:{row.tf_resource_type}" for row in terraform.resource_mappings
            ]
        elif k8s_eso is not None:
            order = k8s_eso_apply_order(k8s_eso)
        elif siem is not None:
            order = [uid_ref for uid_ref, _kind in siem.iter_uid_refs()]
        elif privileged_access is not None:
            order = [uid_ref for uid_ref, _kind in privileged_access.iter_uid_refs()]
        elif nhi is not None:
            order = [uid_ref for uid_ref, _kind in nhi.iter_uid_refs()]
        elif ai_agent is not None:
            order = [uid_ref for uid_ref, _kind in ai_agent.iter_uid_refs()]
        elif agentic_skill_policy is not None:
            order = [uid_ref for uid_ref, _kind in agentic_skill_policy.iter_uid_refs()]
        elif agent_memory_policy is not None:
            order = [uid_ref for uid_ref, _kind in agent_memory_policy.iter_uid_refs()]
        elif mcp_allowlist is not None:
            order = [uid_ref for uid_ref, _kind in mcp_allowlist.iter_uid_refs()]
        elif workflow is not None:
            order = [
                c.uid_ref
                for c in workflow.workflows + workflow.approvers + workflow.requests
                if c.uid_ref
            ]
        elif saas_rotation is not None:
            order = [
                c.uid_ref
                for c in (list(saas_rotation.rotations) + list(saas_rotation.bindings))
                if c.uid_ref
            ]
        elif ai_act is not None:
            order = []
        elif ai_policy is not None:
            order = []
        elif ai_token is not None:
            order = []
        elif cmmc is not None:
            order = []
        elif dora is not None:
            order = []
        elif pqc is not None:
            order = []
        elif itsm_gate is not None:
            order = []
        elif slack_gate is not None:
            order = []
        elif mcp_binding is not None:
            order = []
        elif spiffe is not None:
            order = []
        elif workflow_gate is not None:
            order = []
        elif trust_chain is not None:
            order = []
        elif connection_profile_m is not None:
            order = []
        elif db_access is not None:
            order = []
        elif gateway_ha is not None:
            order = []
        elif tunnel_m is not None:
            order = []
        elif pipeline_env is not None:
            order = []
        elif cloud_jit is not None:
            order = []
        elif compliance_m is not None:
            order = []
        elif cspm is not None:
            order = []
        elif evidence_stream is not None:
            order = []
        elif secret_scanner is not None:
            order = []
        elif keeper_drive_m is not None:
            order = []
        elif agent_kit_m is not None:
            order = []
        elif policy is not None:
            order = policy_apply_order(policy)
        else:
            raise CapabilityError(
                "plan is not supported for this manifest family; "
                "use `dsk validate` to check schema only",
                next_action="dsk validate <path>",
            )
    except RefError as exc:
        click.echo(f"reference error: {exc}", err=True)
        sys.exit(EXIT_REF)
    except CapabilityError as exc:
        click.echo(f"capability error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)

    provider = _make_provider(
        ctx,
        manifest_path,
        pam=pam,
        vault=vault,
        sharing=sharing,
        msp=msp,
        ksm=ksm,
        rotation=rotation,
        jit=jit,
        scim=scim,
        enterprise=enterprise,
        privileged_access=privileged_access,
        nhi=nhi,
        ai_agent=ai_agent,
        workflow=workflow,
        saas_rotation=saas_rotation,
        ai_act=ai_act,
        ai_policy=ai_policy,
        ai_token=ai_token,
        cmmc=cmmc,
        dora=dora,
        pqc=pqc,
        itsm_gate=itsm_gate,
        slack_gate=slack_gate,
        mcp_binding=mcp_binding,
        spiffe=spiffe,
        workflow_gate=workflow_gate,
        trust_chain=trust_chain,
        connection_profile_m=connection_profile_m,
        db_access=db_access,
        gateway_ha=gateway_ha,
        tunnel_m=tunnel_m,
        pipeline_env=pipeline_env,
        cloud_jit=cloud_jit,
        compliance_m=compliance_m,
        cspm=cspm,
        evidence_stream=evidence_stream,
        secret_scanner=secret_scanner,
        keeper_drive_m=keeper_drive_m,
        agent_kit_m=agent_kit_m,
        policy=policy,
    )
    live_record_type_defs: list[dict[str, Any]] = []
    live: list[LiveRecord] = []
    live_msp: list[dict[str, Any]] = []
    live_ksm: dict[str, list[dict[str, Any]]] = {}
    live_enterprise: dict[str, Any] | None = None
    if ksm is not None:
        try:
            discover_ksm_state = provider.discover_ksm_state
        except AttributeError:
            click.echo(
                f"discovery failed: provider {ctx.obj.get('provider', 'mock')!r} has no KSM discovery support",
                err=True,
            )
            sys.exit(EXIT_CAPABILITY)
        try:
            live_ksm = discover_ksm_state()
        except CapabilityError as exc:
            click.echo(f"discovery failed: {exc}", err=True)
            sys.exit(EXIT_CAPABILITY)
    elif msp is not None:
        try:
            live_msp = provider.discover_managed_companies()
        except CapabilityError as exc:
            click.echo(f"discovery failed: {exc}", err=True)
            sys.exit(EXIT_CAPABILITY)
    elif enterprise is not None:
        try:
            discover_ent = provider.discover_enterprise
        except AttributeError:
            click.echo(
                f"discovery failed: provider {ctx.obj.get('provider', 'mock')!r} "
                "has no keeper-enterprise.v1 discovery support",
                err=True,
            )
            sys.exit(EXIT_CAPABILITY)
        try:
            live_enterprise = discover_ent()
        except CapabilityError as exc:
            click.echo(f"discovery failed: {exc}", err=True)
            sys.exit(EXIT_CAPABILITY)
    elif (
        sharing is None
        and pam_extended is None
        and privileged_access is None
        and nhi is None
        and ai_agent is None
        and agentic_skill_policy is None
        and agent_memory_policy is None
        and mcp_allowlist is None
        and rotation is None
        and jit is None
        and scim is None
        and epm_policy is None
        and policy is None
    ):
        try:
            live = provider.discover()
        except CapabilityError as exc:
            click.echo(f"discovery failed: {exc}", err=True)
            sys.exit(EXIT_CAPABILITY)
        if vault is not None:
            live, live_record_type_defs = _vault_live_inputs(live)

    return PlanLoadBundle(
        pam=pam,
        vault=vault,
        sharing=sharing,
        msp=msp,
        identity=identity,
        ksm=ksm,
        pam_extended=pam_extended,
        epm=epm,
        terraform=terraform,
        k8s_eso=k8s_eso,
        siem=siem,
        rotation=rotation,
        jit=jit,
        scim=scim,
        enterprise=enterprise,
        privileged_access=privileged_access,
        nhi=nhi,
        ai_agent=ai_agent,
        agentic_skill_policy=agentic_skill_policy,
        agent_memory_policy=agent_memory_policy,
        mcp_allowlist=mcp_allowlist,
        workflow=workflow,
        saas_rotation=saas_rotation,
        epm_policy=epm_policy,
        ai_act=ai_act,
        ai_policy=ai_policy,
        ai_token=ai_token,
        cmmc=cmmc,
        dora=dora,
        pqc=pqc,
        itsm_gate=itsm_gate,
        slack_gate=slack_gate,
        mcp_binding=mcp_binding,
        spiffe=spiffe,
        workflow_gate=workflow_gate,
        trust_chain=trust_chain,
        connection_profile_m=connection_profile_m,
        db_access=db_access,
        gateway_ha=gateway_ha,
        tunnel_m=tunnel_m,
        pipeline_env=pipeline_env,
        cloud_jit=cloud_jit,
        compliance_m=compliance_m,
        cspm=cspm,
        evidence_stream=evidence_stream,
        secret_scanner=secret_scanner,
        keeper_drive_m=keeper_drive_m,
        agent_kit_m=agent_kit_m,
        policy=policy,
        manifest_name=manifest_name,
        order=order,
        live=live,
        live_msp=live_msp,
        live_ksm=live_ksm,
        live_record_type_defs=live_record_type_defs,
        live_enterprise=live_enterprise,
        provider=provider,
        events=events,
    )


def _vault_live_inputs(live: list[LiveRecord]) -> tuple[list[LiveRecord], list[dict[str, Any]]]:
    records: list[LiveRecord] = []
    record_type_defs: list[dict[str, Any]] = []
    for record in live:
        if record.resource_type == "record_type":
            record_type_defs.append(
                {
                    "keeper_uid": record.keeper_uid,
                    "title": record.title,
                    "resource_type": record.resource_type,
                    "payload": dict(record.payload),
                    "marker": dict(record.marker) if record.marker else None,
                }
            )
            continue
        records.append(record)
    return records, record_type_defs


def _build_sharing_changes(
    provider: Any,
    manifest: SharingManifestV1,
    *,
    allow_delete: bool,
) -> list[Change]:
    live_by_type = _sharing_live_rows_by_type(provider.discover())
    manifest_name = getattr(provider, "_manifest_name", None) or "vault-sharing"
    return compute_sharing_diff(
        manifest,
        live_folders=live_by_type["sharing_folder"],
        live_shared_folders=live_by_type["sharing_shared_folder"],
        live_share_records=live_by_type["sharing_record_share"],
        live_share_folders=live_by_type["sharing_share_folder"],
        manifest_name=manifest_name,
        allow_delete=allow_delete,
    )


def _sharing_live_rows_by_type(live: list[LiveRecord]) -> dict[str, list[dict[str, Any]]]:
    rows: dict[str, list[dict[str, Any]]] = {
        "sharing_folder": [],
        "sharing_shared_folder": [],
        "sharing_record_share": [],
        "sharing_share_folder": [],
    }
    for record in live:
        if record.resource_type not in rows:
            continue
        rows[record.resource_type].append(
            {
                "keeper_uid": record.keeper_uid,
                "resource_type": record.resource_type,
                "title": record.title,
                "payload": dict(record.payload),
                "marker": dict(record.marker) if record.marker else None,
            }
        )
    return rows


def _rotation_policy_apply_order(manifest: RotationPolicyManifestV1) -> list[str]:
    order: list[str] = []
    seen: set[str] = set()
    for policy in manifest.policies:
        for record_uid_ref in policy.applies_to:
            if record_uid_ref in seen:
                continue
            seen.add(record_uid_ref)
            order.append(record_uid_ref)
    return order


def _build_rotation_policy_changes(
    manifest: RotationPolicyManifestV1,
    live_records: list[LiveRecord] | None = None,
) -> list[Change]:
    live_by_ref = _rotation_live_by_ref(live_records or [])
    changes: list[Change] = []
    owners: dict[str, str] = {}
    for policy in manifest.policies:
        for record_uid_ref in policy.applies_to:
            if record_uid_ref in owners:
                changes.append(
                    Change(
                        kind=ChangeKind.CONFLICT,
                        uid_ref=record_uid_ref,
                        resource_type="rotation_policy",
                        title=policy.name,
                        reason=(
                            f"rotation target {record_uid_ref!r} is claimed by both "
                            f"{owners[record_uid_ref]!r} and {policy.name!r}"
                        ),
                        manifest_name=manifest.name,
                    )
                )
                continue
            owners[record_uid_ref] = policy.name
            live = live_by_ref.get(record_uid_ref)
            changes.append(
                Change(
                    kind=ChangeKind.UPDATE,
                    uid_ref=record_uid_ref,
                    resource_type="rotation_policy",
                    title=policy.name,
                    keeper_uid=live.keeper_uid if live else None,
                    before=dict(live.payload) if live else {},
                    after=_rotation_policy_payload(policy, record_uid_ref),
                    manifest_name=manifest.name,
                )
            )
    return changes


def _rotation_policy_payload(policy: Any, record_uid_ref: str) -> dict[str, Any]:
    schedule = policy.schedule
    schedule_type = str(getattr(schedule, "type", "") or "").lower()
    payload: dict[str, Any] = {
        "policy_name": policy.name,
        "record_uid_ref": record_uid_ref,
        "enabled": schedule_type != "manual",
    }
    for attr in (
        "rotation_profile",
        "config_uid_ref",
        "resource_uid_ref",
        "password_complexity",
    ):
        value = getattr(policy, attr, None)
        if value not in (None, ""):
            payload[attr] = value
    if schedule_type == "cron":
        payload["schedule_type"] = "CRON"
        if getattr(schedule, "cron", None):
            payload["schedule_cron"] = schedule.cron
    elif schedule_type == "configuration":
        payload["schedule_type"] = "CONFIGURATION"
        if getattr(schedule, "schedule_config", None):
            payload["schedule_config"] = schedule.schedule_config
    elif schedule_type in {"on_use", "manual"}:
        payload["schedule_type"] = "ON_DEMAND"
    else:
        payload["schedule_type"] = "DAILY"
        interval_hours = getattr(schedule, "interval_hours", None)
        interval_count = 1
        if isinstance(interval_hours, int) and interval_hours > 0:
            interval_count = max(1, interval_hours // 24) if interval_hours % 24 == 0 else 1
        schedule_json: dict[str, Any] = {
            "type": "DAILY",
            "intervalCount": interval_count,
        }
        if getattr(schedule, "window_start", None):
            schedule_json["utcTime"] = schedule.window_start
        payload["schedule_json"] = schedule_json
    password = getattr(policy, "password", None)
    if password is not None:
        payload["password_policy"] = password.model_dump(mode="python", exclude_none=True)
    return payload


def _rotation_live_by_ref(live_records: list[LiveRecord]) -> dict[str, LiveRecord]:
    out: dict[str, LiveRecord] = {}
    for record in live_records:
        out.setdefault(record.keeper_uid, record)
        out.setdefault(record.title, record)
        marker = record.marker or {}
        uid_ref = marker.get("uid_ref")
        if isinstance(uid_ref, str) and uid_ref:
            out.setdefault(uid_ref, record)
    return out


def _rotation_policy_missing_targets(
    manifest: RotationPolicyManifestV1,
    live_records: list[LiveRecord],
) -> list[str]:
    live_by_ref = _rotation_live_by_ref(live_records)
    return [
        target for target in _rotation_policy_apply_order(manifest) if target not in live_by_ref
    ]


def _jit_apply_order(manifest: JitManifestV1) -> list[str]:
    order: list[str] = []
    seen: set[str] = set()
    for policy in manifest.policies:
        for resource in policy.resources:
            uid = resource.uid_ref
            if uid in seen:
                continue
            seen.add(uid)
            order.append(uid)
    return order


def _jit_binding_payload(policy: Any, resource: Any) -> dict[str, Any]:
    return {
        "policy_name": policy.name,
        "uid_ref": resource.uid_ref,
        "role": resource.role,
        "justification_required": resource.justification_required,
        "window": policy.window.model_dump(mode="python"),
        "approval": policy.approval.model_dump(mode="python"),
        "audit_log": policy.audit_log,
        "auto_revoke": policy.auto_revoke,
        "description": policy.description,
    }


def _build_jit_policy_changes(manifest: JitManifestV1, provider: Any) -> list[Change]:
    snapshot: dict[str, dict[str, Any]] = {}
    snap_fn = getattr(provider, "jit_bindings_snapshot", None)
    if callable(snap_fn):
        snapshot = dict(snap_fn())

    changes: list[Change] = []
    owners: dict[str, str] = {}
    for policy in manifest.policies:
        for resource in policy.resources:
            uid_ref = resource.uid_ref
            if uid_ref in owners:
                changes.append(
                    Change(
                        kind=ChangeKind.CONFLICT,
                        uid_ref=uid_ref,
                        resource_type="jit_access",
                        title=policy.name,
                        reason=(
                            f"jit target {uid_ref!r} is claimed by both "
                            f"{owners[uid_ref]!r} and {policy.name!r}"
                        ),
                        manifest_name=manifest.name,
                    )
                )
                continue
            owners[uid_ref] = policy.name
            desired = _jit_binding_payload(policy, resource)
            before = snapshot.get(uid_ref)
            if before is None:
                changes.append(
                    Change(
                        kind=ChangeKind.CREATE,
                        uid_ref=uid_ref,
                        resource_type="jit_access",
                        title=policy.name,
                        after=desired,
                        manifest_name=manifest.name,
                    )
                )
            elif before == desired:
                changes.append(
                    Change(
                        kind=ChangeKind.NOOP,
                        uid_ref=uid_ref,
                        resource_type="jit_access",
                        title=policy.name,
                        before=dict(before),
                        after=dict(desired),
                        reason="jit binding matches mock state",
                        manifest_name=manifest.name,
                    )
                )
            else:
                changes.append(
                    Change(
                        kind=ChangeKind.UPDATE,
                        uid_ref=uid_ref,
                        resource_type="jit_access",
                        title=policy.name,
                        keeper_uid=None,
                        before=dict(before),
                        after=dict(desired),
                        manifest_name=manifest.name,
                    )
                )
    return changes


def _make_provider(
    ctx: click.Context,
    manifest_path: Path,
    *,
    pam: Manifest | None = None,
    vault: VaultManifestV1 | None = None,
    sharing: SharingManifestV1 | None = None,
    msp: MspManifestV1 | None = None,
    ksm: KsmManifestV1 | None = None,
    enterprise: EnterpriseManifestV1 | None = None,
    rotation: RotationPolicyManifestV1 | None = None,
    jit: JitManifestV1 | None = None,
    scim: ScimManifestV1 | None = None,
    privileged_access: PrivilegedAccessManifestV1 | None = None,
    nhi: NhiAgentManifest | None = None,
    ai_agent: AiAgentManifest | None = None,
    workflow: WorkflowManifestV1 | None = None,
    saas_rotation: SaaSRotationManifestV1 | None = None,
    ai_act: AiActProfileManifestV1 | None = None,
    ai_policy: AiPolicyManifestV1 | None = None,
    ai_token: AiTokenManifestV1 | None = None,
    cmmc: CmmcProfileManifestV1 | None = None,
    dora: DoraProfileManifestV1 | None = None,
    pqc: PqcPolicyManifestV1 | None = None,
    itsm_gate: ItsmApprovalGateManifestV1 | None = None,
    slack_gate: SlackApprovalGateManifestV1 | None = None,
    mcp_binding: McpSecretsBindingManifestV1 | None = None,
    spiffe: SpiffeBindingManifestV1 | None = None,
    workflow_gate: WorkflowGateManifestV1 | None = None,
    trust_chain: TrustChainManifestV1 | None = None,
    connection_profile_m: PamConnectionProfileManifestV1 | None = None,
    db_access: DbAccessPolicyManifestV1 | None = None,
    gateway_ha: GatewayHaManifestV1 | None = None,
    tunnel_m: TunnelManifestV1 | None = None,
    pipeline_env: PipelineEphemeralManifestV1 | None = None,
    cloud_jit: CloudJitManifestV1 | None = None,
    compliance_m: ComplianceBundleManifestV1 | None = None,
    cspm: CspmRemediationManifestV1 | None = None,
    evidence_stream: ContinuousEvidenceStreamManifestV1 | None = None,
    secret_scanner: SecretScannerBridgeManifestV1 | None = None,
    keeper_drive_m: KeeperDriveManifestV1 | None = None,
    agent_kit_m: AgentKitManifestV1 | None = None,
    policy: PolicyManifestV1 | None = None,
) -> Any:
    provider_name = ctx.obj.get("provider", "mock")
    folder_uid = ctx.obj.get("folder_uid")
    if pam is not None:
        manifest_name = pam.name
    elif msp is not None:
        manifest_name = msp.name
    elif rotation is not None:
        manifest_name = rotation.name
    elif jit is not None:
        manifest_name = jit.name
    elif scim is not None:
        manifest_name = scim.name
    elif workflow is not None:
        manifest_name = "keeper-workflow"
    elif saas_rotation is not None:
        manifest_name = "keeper-saas-rotation"
    elif policy is not None:
        manifest_name = policy.name
    else:
        manifest_name = manifest_path.stem
    if provider_name == "mock" and ksm is not None:
        return ctx.obj.setdefault("_ksm_provider_instance", KsmMockProvider(manifest_name))
    if provider_name == "mock":
        return ctx.obj.setdefault("_provider_instance", MockProvider(manifest_name))
    if provider_name == "commander":
        manifest_source: dict[str, Any] = {}
        if pam is not None:
            manifest_source = pam.model_dump(mode="python", exclude_none=True)
        elif vault is not None:
            manifest_source = vault.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif sharing is not None:
            manifest_source = sharing.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif msp is not None:
            manifest_source = msp.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif ksm is not None:
            manifest_source = ksm.model_dump(mode="python", exclude_none=True, by_alias=True)
            manifest_source.setdefault("name", manifest_path.stem)
        elif enterprise is not None:
            manifest_source = enterprise.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif rotation is not None:
            manifest_source = rotation.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif jit is not None:
            manifest_source = jit.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif scim is not None:
            manifest_source = scim.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif privileged_access is not None:
            manifest_source = privileged_access.model_dump(
                mode="python",
                exclude_none=True,
                by_alias=True,
            )
        elif nhi is not None:
            manifest_source = nhi.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif ai_agent is not None:
            manifest_source = ai_agent.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif policy is not None:
            manifest_source = policy.to_dict()
        return CommanderCliProvider(
            folder_uid=folder_uid or os.environ.get("KEEPER_DECLARATIVE_FOLDER"),
            manifest_source=manifest_source,
        )
    if provider_name == "service":
        manifest_source = {}
        if pam is not None:
            manifest_source = pam.model_dump(mode="python", exclude_none=True)
        elif vault is not None:
            manifest_source = vault.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif sharing is not None:
            manifest_source = sharing.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif msp is not None:
            manifest_source = msp.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif ksm is not None:
            manifest_source = ksm.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif enterprise is not None:
            manifest_source = enterprise.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif rotation is not None:
            manifest_source = rotation.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif jit is not None:
            manifest_source = jit.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif scim is not None:
            manifest_source = scim.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif privileged_access is not None:
            manifest_source = privileged_access.model_dump(
                mode="python",
                exclude_none=True,
                by_alias=True,
            )
        elif policy is not None:
            manifest_source = policy.to_dict()
        return CommanderServiceProvider(
            base_url=os.environ.get("KEEPER_SERVICE_URL", "http://localhost:4020"),
            api_key=os.environ.get("KEEPER_SERVICE_API_KEY"),
            timeout=int(os.environ.get("KEEPER_SERVICE_TIMEOUT", "300")),
            manifest_source=manifest_source,
        )
    raise click.ClickException(f"unknown provider '{provider_name}'")


def _params_for_bootstrap(login_helper: str) -> Any:
    if login_helper == "commander":
        return _load_commander_config_params()
    helper: LoginHelper
    if login_helper == "ksm":
        helper = KsmLoginHelper()
    else:
        helper = load_helper_from_path(login_helper)
    creds = helper.load_keeper_creds()
    params = helper.keeper_login(**creds)
    if not getattr(params, "session_token", None):
        raise CapabilityError(
            reason="login helper returned no Commander session token",
            next_action="verify the helper authenticates successfully before running bootstrap-ksm",
        )
    return params


def _load_commander_config_params() -> Any:
    try:
        from keepercommander.config_storage.loader import load_config_properties
        from keepercommander.params import KeeperParams
    except ImportError as exc:
        raise CapabilityError(
            reason=f"keepercommander is required for bootstrap-ksm commander login mode: {exc}",
            next_action="pip install keepercommander>=18.0.0,<19",
        ) from exc

    config_path = Path.home() / ".keeper" / "config.json"
    config: dict[str, object] = {}
    if config_path.is_file():
        try:
            max_bytes = positive_int_env(
                "DSK_CLI_MAX_CONFIG_BYTES",
                DEFAULT_CLI_MAX_CONFIG_BYTES,
            )
            parsed_config = read_json_file_limited(
                config_path,
                max_bytes=max_bytes,
                max_depth=_cli_json_depth_limit(),
                label="Commander config",
                byte_limit_name="DSK_CLI_MAX_CONFIG_BYTES",
                depth_limit_name="DSK_CLI_MAX_JSON_DEPTH",
            )
            config = parsed_config if isinstance(parsed_config, dict) else {}
        except Exception as exc:
            raise CapabilityError(
                reason=f"cannot parse Commander config at {config_path}: {exc}",
                next_action="run 'keeper login' again to refresh the source admin session",
            ) from exc

    params = KeeperParams(config_filename=str(config_path), config=config)
    load_config_properties(params)
    if not getattr(params, "session_token", None):
        raise CapabilityError(
            reason="Commander config has no authenticated session token",
            next_action="run 'keeper login' first to authenticate the source admin session",
        )
    return params


def _uid_prefix(uid: str | None) -> str:
    if not uid:
        return ""
    return uid[:6] + "..." if len(uid) > 6 else uid


def _resolve_plan_output_format(as_json: bool, output_format: str | None) -> str:
    if output_format is None:
        return "json" if as_json else "table"

    normalized = output_format.strip().lower()
    if normalized in {"json", "table"}:
        return normalized

    raise CapabilityError(
        reason=(
            f"plan output format `{output_format}` is not implemented "
            "(supported formats: json, table)"
        ),
        next_action="use `--json`, `--format json`, or `--format table`",
    )


def _exit_from_plan(plan_obj: Plan) -> int:
    if plan_obj.conflicts:
        return EXIT_CONFLICT
    if plan_obj.is_clean:
        return EXIT_OK
    return EXIT_CHANGES


def _plan_to_dict(plan_obj: Plan) -> dict:
    return {
        "manifest_name": plan_obj.manifest_name,
        "summary": {
            "create": len(plan_obj.creates),
            "update": len(plan_obj.updates),
            "delete": len(plan_obj.deletes),
            "conflict": len(plan_obj.conflicts),
            "noop": len(plan_obj.noops),
        },
        "order": plan_obj.order,
        "changes": [
            {
                "kind": change.kind.value,
                "uid_ref": change.uid_ref,
                "resource_type": change.resource_type,
                "title": change.title,
                "keeper_uid": change.keeper_uid,
                "before": redact(change.before),
                "after": redact(change.after),
                "reason": change.reason,
            }
            for change in plan_obj.changes
        ],
    }


def _emit_report_json(payload: dict[str, Any]) -> None:
    """Print report envelope; exit 1 if ``secret_leak_check`` flags output."""
    from dsk.cli._report.common import (
        ReportOutputLeakError,
        serialize_report_payload,
    )

    try:
        click.echo(serialize_report_payload(payload))
    except ReportOutputLeakError as exc:
        click.echo(f"report refused: output failed leak check: {exc.warnings!r}", err=True)
        sys.exit(EXIT_GENERIC)
    sys.exit(EXIT_OK)


def _run_argv_from_command(command: tuple[str, ...]) -> list[str]:
    if not command:
        raise click.UsageError("missing Commander command")
    if len(command) == 1:
        return shlex.split(command[0])
    return list(command)


def _redact_run_output(text: str, *, sanitize_uids: bool) -> str:
    if not text:
        return ""
    from dsk.cli._live.transcript import _sanitize_value
    from dsk.core.redact import redact as redact_secrets

    stripped = text.strip()
    if stripped.startswith(("{", "[")):
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            redacted = str(redact_secrets(text))
        else:
            redacted = json.dumps(redact_secrets(parsed), indent=2)
            if text.endswith("\n"):
                redacted += "\n"
    else:
        redacted = str(redact_secrets(text))
    if sanitize_uids:
        redacted = str(_sanitize_value(redacted))
    return redacted


def _echo_preserving_newline(text: str, *, err: bool = False) -> None:
    if text:
        click.echo(text, nl=not text.endswith("\n"), err=err)


def _dispatch_run_commander(
    ctx: click.Context,
    sanitize_uids: bool,
    as_json: bool,
    command: tuple[str, ...],
) -> None:
    if ctx.obj.get("provider") != "commander":
        click.echo(
            "capability error: dsk run requires --provider commander; "
            "mock provider has no Commander session; "
            "next_action: dsk --provider commander run <commander-command>",
            err=True,
        )
        sys.exit(EXIT_CAPABILITY)

    try:
        argv = _run_argv_from_command(command)
        if as_json and "--json" not in argv:
            argv.append("--json")
        from dsk.cli._report import runner as keeper_runner

        result = keeper_runner.run_keeper_passthrough(
            argv,
            keeper_bin=os.environ.get("KEEPER_BIN"),
            config_file=os.environ.get("KEEPER_CONFIG"),
            password=os.environ.get("KEEPER_PASSWORD"),
        )
    except CapabilityError as exc:
        click.echo(f"capability error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)

    _echo_preserving_newline(_redact_run_output(result.stdout or "", sanitize_uids=sanitize_uids))
    _echo_preserving_newline(
        _redact_run_output(result.stderr or "", sanitize_uids=sanitize_uids),
        err=True,
    )
    sys.exit(result.returncode)


@main.command("run", context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in Commander output",
)
@click.option("--json", "as_json", is_flag=True, help="Append --json to the Commander command")
@click.argument("command", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def run_commander(
    ctx: click.Context,
    sanitize_uids: bool,
    as_json: bool,
    command: tuple[str, ...],
) -> None:
    """Run an arbitrary Commander command via the configured Commander session."""
    _dispatch_run_commander(ctx, sanitize_uids, as_json, command)


@main.group("report", help=_REPORT_HELP)
def report_cli() -> None:
    """Run read-only Commander reports."""


@report_cli.command("password-report")
@click.option(
    "--policy",
    default="12,2,2,2,0",
    show_default=True,
    help="Password policy Length,Lower,Upper,Digits,Special (Commander format)",
)
@click.option(
    "--folder",
    default=None,
    help="Optional folder path or UID to scope the report",
)
@click.option("-v", "--verbose", is_flag=True, help="Verbose Commander columns")
@click.option(
    "--quiet",
    is_flag=True,
    help="Fingerprint record_uid values instead of printing raw UIDs",
)
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in all string fields (live-transcript mode)",
)
@click.option(
    "--keeper-bin",
    default=None,
    envvar="KEEPER_BIN",
    help="Path to keeper CLI (default: keeper on PATH)",
)
def report_password_report(
    policy: str,
    folder: str | None,
    verbose: bool,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None,
) -> None:
    """Weak-password rows from Commander ``password-report`` (JSON envelope)."""
    from dsk.cli._report.password import run_password_report

    try:
        payload = run_password_report(
            policy=policy,
            folder=folder,
            verbose=verbose,
            quiet=quiet,
            sanitize_uids=sanitize_uids,
            keeper_bin=keeper_bin,
            config_file=os.environ.get("KEEPER_CONFIG"),
            password=os.environ.get("KEEPER_PASSWORD"),
        )
    except CapabilityError as exc:
        click.echo(f"report error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    _emit_report_json(payload)


@report_cli.command("compliance-report")
@click.option("--node", default=None, help="Node ID or name (Commander --node)")
@click.option("--username", multiple=True, help="Filter by username (repeatable)")
@click.option("--team", multiple=True, help="Filter by team name or UID (repeatable)")
@click.option("--rebuild", is_flag=True, help="Rebuild local compliance cache from source")
@click.option("--no-cache", is_flag=True, help="Remove local compliance cache after report")
@click.option(
    "--no-fail-on-empty/--fail-on-empty",
    default=True,
    show_default=True,
    help="Exit 0 with a warning envelope when the no-rebuild compliance cache is empty",
)
@click.option(
    "--quiet",
    is_flag=True,
    help="Fingerprint record_uid values in JSON output",
)
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in all string fields (live-transcript mode)",
)
@click.option(
    "--keeper-bin",
    default=None,
    envvar="KEEPER_BIN",
    help="Path to keeper CLI (default: keeper on PATH)",
)
def report_compliance_report(
    node: str | None,
    username: tuple[str, ...],
    team: tuple[str, ...],
    rebuild: bool,
    no_cache: bool,
    no_fail_on_empty: bool,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None,
) -> None:
    """Default enterprise compliance table via ``keeper compliance report``."""
    from dsk.cli._report.compliance import (
        COMPLIANCE_CACHE_EMPTY_WARNING,
        run_compliance_report,
    )

    try:
        payload = run_compliance_report(
            node=node,
            username=username,
            team=team,
            rebuild=rebuild,
            no_cache=no_cache,
            no_fail_on_empty=no_fail_on_empty,
            quiet=quiet,
            sanitize_uids=sanitize_uids,
            keeper_bin=keeper_bin,
            config_file=os.environ.get("KEEPER_CONFIG"),
            password=os.environ.get("KEEPER_PASSWORD"),
        )
    except CapabilityError as exc:
        click.echo(f"report error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    if payload.get("warning") == "cache_empty":
        click.echo(COMPLIANCE_CACHE_EMPTY_WARNING, err=True)
    _emit_report_json(payload)


@report_cli.command("security-audit-report")
@click.option("--node", multiple=True, help="Node name or UID filter (repeatable)")
@click.option(
    "--record-details",
    is_flag=True,
    help="Per-record password strength rows (when incremental data exists)",
)
@click.option("--breachwatch", is_flag=True, help="Include BreachWatch columns when licensed")
@click.option(
    "--score-type",
    type=click.Choice(["default", "strong_passwords"]),
    default="default",
    show_default=True,
)
@click.option(
    "-f",
    "--force",
    is_flag=True,
    help="Skip confirmation prompts (Commander non-interactive)",
)
@click.option(
    "--quiet",
    is_flag=True,
    help="Fingerprint record_uid when using --record-details",
)
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in all string fields (live-transcript mode)",
)
@click.option(
    "--keeper-bin",
    default=None,
    envvar="KEEPER_BIN",
    help="Path to keeper CLI (default: keeper on PATH)",
)
def report_security_audit_report(
    node: tuple[str, ...],
    record_details: bool,
    breachwatch: bool,
    score_type: str,
    force: bool,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None,
) -> None:
    """Enterprise security audit summary via ``keeper security-audit report``."""
    from dsk.cli._report.security_audit import run_security_audit_report

    try:
        payload = run_security_audit_report(
            nodes=node,
            record_details=record_details,
            breachwatch=breachwatch,
            score_type=score_type,
            force=force,
            quiet=quiet,
            sanitize_uids=sanitize_uids,
            keeper_bin=keeper_bin,
            config_file=os.environ.get("KEEPER_CONFIG"),
            password=os.environ.get("KEEPER_PASSWORD"),
        )
    except CapabilityError as exc:
        click.echo(f"report error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    _emit_report_json(payload)


@report_cli.command("vault-health")
@click.option("--json", "as_json", is_flag=True, help="Emit JSON (default; compatibility flag)")
@click.option(
    "--shared-threshold",
    "--shared-user-threshold",
    "shared_threshold",
    type=click.IntRange(min=0),
    default=10,
    show_default=True,
    help="Flag records shared to more than this many users",
)
@click.option(
    "--stale-days",
    type=click.IntRange(min=1),
    default=90,
    show_default=True,
    help="Flag records not modified for more than this many days",
)
@click.option(
    "--quiet",
    is_flag=True,
    help="Fingerprint record_uid values in JSON output",
)
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in all string fields (live-transcript mode)",
)
@click.option(
    "--keeper-bin",
    default=None,
    envvar="KEEPER_BIN",
    help="Path to keeper CLI (default: keeper on PATH)",
)
def report_vault_health(
    as_json: bool,
    shared_threshold: int,
    stale_days: int,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None,
) -> None:
    """Summarize vault counts, shared folders, orphans, and password posture via ``list-records`` + ``shared-folder-list`` JSON."""
    _ = as_json
    from dsk.cli._report.vault_health import run_vault_health_report

    try:
        payload = run_vault_health_report(
            shared_threshold=shared_threshold,
            stale_days=stale_days,
            quiet=quiet,
            sanitize_uids=sanitize_uids,
            keeper_bin=keeper_bin,
            config_file=os.environ.get("KEEPER_CONFIG"),
            password=os.environ.get("KEEPER_PASSWORD"),
        )
    except CapabilityError as exc:
        click.echo(f"report error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    _emit_report_json(payload)


@report_cli.command("team-report")
@click.option("--json", "as_json", is_flag=True, help="Emit JSON envelope (default; CLI parity)")
@click.option(
    "--node", default=None, help="Limit enterprise + compliance reports to this node (name or UID)"
)
@click.option("--team", multiple=True, help="Limit to team UID or name (repeatable)")
@click.option(
    "--quiet",
    is_flag=True,
    help="Fingerprint team_uid values instead of printing raw UIDs",
)
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in all string fields (live-transcript mode)",
)
@click.option(
    "--keeper-bin",
    default=None,
    envvar="KEEPER_BIN",
    help="Path to keeper CLI (default: keeper on PATH)",
)
def report_team_report(
    as_json: bool,
    node: str | None,
    team: tuple[str, ...],
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None,
) -> None:
    """Per-team members, role names, and shared-folder rows (enterprise + compliance)."""
    _ = as_json  # CLI parity; envelope is always JSON on stdout
    from dsk.cli._report.team_report_cmd import run_team_report

    try:
        payload = run_team_report(
            node=node,
            teams=team,
            quiet=quiet,
            sanitize_uids=sanitize_uids,
            keeper_bin=keeper_bin,
            config_file=os.environ.get("KEEPER_CONFIG"),
            password=os.environ.get("KEEPER_PASSWORD"),
        )
    except CapabilityError as exc:
        click.echo(f"report error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    _emit_report_json(payload)


@report_cli.command("team-roles")
@click.option("--node", default=None, help="Node ID or name (Commander --node)")
@click.option("--json", "as_json", is_flag=True, help="Emit JSON (default; kept for compatibility)")
@click.option(
    "--quiet",
    is_flag=True,
    help="Fingerprint team_uid / role_id values instead of raw identifiers",
)
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in all string fields (live-transcript mode)",
)
@click.option(
    "--keeper-bin",
    default=None,
    envvar="KEEPER_BIN",
    help="Path to keeper CLI (default: keeper on PATH)",
)
def report_team_roles(
    node: str | None,
    as_json: bool,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None,
) -> None:
    """Enterprise team → roles → permission matrix from ``keeper enterprise-info``."""
    from dsk.cli._report.team_roles import run_team_roles_report

    try:
        payload = run_team_roles_report(
            node=node,
            quiet=quiet,
            sanitize_uids=sanitize_uids,
            keeper_bin=keeper_bin,
            config_file=os.environ.get("KEEPER_CONFIG"),
            password=os.environ.get("KEEPER_PASSWORD"),
        )
    except CapabilityError as exc:
        click.echo(f"report error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    _emit_report_json(payload)


@report_cli.command("ksm-usage")
@click.option("--json", "as_json", is_flag=True, help="Emit KSM usage as JSON")
@click.option(
    "--quiet",
    is_flag=True,
    help="Fingerprint app_uid values in JSON output; suppress table when --json is set",
)
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in output",
)
@click.option(
    "--keeper-bin",
    default=None,
    envvar="KEEPER_BIN",
    help="Path to keeper CLI (default: keeper on PATH)",
)
@click.pass_context
def report_ksm_usage(
    ctx: click.Context,
    as_json: bool,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None,
) -> None:
    """KSM app/share usage summary."""
    from dsk.cli._report.ksm_usage import (
        render_ksm_usage_table,
        run_ksm_usage_report,
    )

    try:
        if ctx.obj.get("provider") == "mock":
            provider = ctx.obj.get("_ksm_report_provider_instance")
            if provider is None:
                provider = KsmMockProvider("ksm-usage")
                ctx.obj["_ksm_report_provider_instance"] = provider
            payload = run_ksm_usage_report(
                provider=provider, sanitize_uids=sanitize_uids, quiet=quiet
            )
        elif ctx.obj.get("provider") == "commander":
            payload = run_ksm_usage_report(
                sanitize_uids=sanitize_uids,
                quiet=quiet,
                keeper_bin=keeper_bin,
                config_file=os.environ.get("KEEPER_CONFIG"),
                password=os.environ.get("KEEPER_PASSWORD"),
            )
        else:
            raise CapabilityError(
                reason="dsk report ksm-usage supports --provider mock or --provider commander",
                next_action="rerun with --provider mock for offline coverage",
            )
    except CapabilityError as exc:
        click.echo(f"report error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    except Exception as exc:
        source = "Commander" if ctx.obj.get("provider") == "commander" else "KSM usage"
        click.echo(f"report error: unexpected {source} error: {exc}", err=True)
        sys.exit(EXIT_GENERIC)

    if as_json:
        _emit_report_json(payload)
    if not quiet:
        click.echo(render_ksm_usage_table(payload))
    sys.exit(EXIT_OK)


@report_cli.command("role-report")
@click.option(
    "--json", "as_json", is_flag=True, help="Emit JSON envelope (default; kept for parity)"
)
@click.option(
    "--node",
    default=None,
    help="Limit ``enterprise-info -r`` results to subtree of this node (name or ID)",
)
@click.option(
    "--role",
    "role_filter",
    default=None,
    help="Only include roles matching this Role ID or name (case-insensitive)",
)
@click.option(
    "--quiet",
    is_flag=True,
    help="Fingerprint role identifiers in nested structures (role/member IDs)",
)
@click.option(
    "--sanitize-uids",
    is_flag=True,
    help="Fingerprint UID-like substrings in all string fields (live-transcript mode)",
)
@click.option(
    "--keeper-bin",
    default=None,
    envvar="KEEPER_BIN",
    help="Path to keeper CLI (default: keeper on PATH)",
)
def report_role_report(
    as_json: bool,
    role_filter: str | None,
    node: str | None,
    quiet: bool,
    sanitize_uids: bool,
    keeper_bin: str | None,
) -> None:
    """Enterprise role summary via ``enterprise-info -r`` + ``enterprise-role --format json``."""
    del as_json

    from dsk.cli._report.role_report import run_role_report

    try:
        payload = run_role_report(
            node=node,
            role=role_filter,
            quiet=quiet,
            sanitize_uids=sanitize_uids,
            keeper_bin=keeper_bin,
            config_file=os.environ.get("KEEPER_CONFIG"),
            password=os.environ.get("KEEPER_PASSWORD"),
        )
    except CapabilityError as exc:
        click.echo(f"report error: {exc}", err=True)
        sys.exit(EXIT_CAPABILITY)
    _emit_report_json(payload)


@main.command("live-smoke")
@click.option(
    "--ksm-record-uid",
    required=True,
    envvar="KEEPER_LIVE_KSM_RECORD_UID",
    help="UID of the Keeper record holding the KSM bootstrap config",
)
@click.option(
    "--ksm-config",
    type=click.Path(path_type=Path),
    envvar="KEEPER_LIVE_KSM_CONFIG",
    help="Optional path to a KSM config file (alternative to --ksm-record-uid)",
)
@click.option(
    "--manifest",
    "manifest_path",
    required=True,
    type=click.Path(exists=True, path_type=Path),
    help="Smoke manifest to apply + diff",
)
@click.option(
    "--workdir",
    type=click.Path(path_type=Path),
    default=Path("./.live-smoke"),
    show_default=True,
    help="Working directory for transcripts + per-run artefacts",
)
@click.option(
    "--evidence-out",
    type=click.Path(path_type=Path),
    required=True,
    help="Where to write the sanitized proof transcript JSON",
)
@click.option(
    "--schema-family",
    required=True,
    help="Schema family being proven (e.g. pam-environment, keeper-vault)",
)
@click.option(
    "--schema-version",
    default="v1",
    show_default=True,
    help="Schema version being proven",
)
@click.option(
    "--commander-pin",
    default=None,
    help="Commander pin SHA; defaults to reading .commander-pin",
)
@click.pass_context
def live_smoke(
    ctx: click.Context,
    ksm_record_uid: str,
    ksm_config: Path | None,
    manifest_path: Path,
    workdir: Path,
    evidence_out: Path,
    schema_family: str,
    schema_version: str,
    commander_pin: str | None,
) -> None:
    """Run the live-tenant smoke loop and write a sanitized proof transcript.

    Phases: bootstrap-ksm → login → apply → diff (clean re-plan) → cleanup.

    Skipped without an active KSM-provisioned tenant. Sanitization in
    `dsk.cli._live.transcript` strips secrets, fingerprints UIDs;
    `secret_leak_check` is the post-write belt-and-braces grep.
    """
    from dsk.cli._live.runbook import iter_default_phases
    from dsk.cli._live.transcript import (
        Transcript,
        secret_leak_check,
    )

    if commander_pin is None:
        pin_path = Path(__file__).resolve().parents[2] / ".commander-pin"
        commander_pin = pin_path.read_text().strip() if pin_path.exists() else "unknown"

    workdir.mkdir(parents=True, exist_ok=True)
    empty = workdir / "_smoke_empty.yml"
    if not empty.exists():
        empty.write_text('version: "1"\nname: _smoke_placeholder\nschema: pam-environment.v1\n')

    transcript = Transcript(
        schema_family=schema_family,
        schema_version=schema_version,
        commander_pin=commander_pin,
    )
    for phase in iter_default_phases(
        ksm_record_uid=ksm_record_uid,
        ksm_config_path=ksm_config,
        manifest_path=manifest_path,
        workdir=workdir,
    ):
        transcript.add_phase(phase)
        click.echo(f"[live-smoke] {phase.name}: {phase.status} ({phase.elapsed_ms}ms)")

    transcript.finalize()
    written_path = transcript.write(evidence_out)
    leaks = secret_leak_check(
        written_path.read_text(),
        env_keys=("KEEPER_CONFIG", "KEEPER_LIVE_KSM_CONFIG", "KEEPER_LOGIN_TOKEN"),
    )
    if leaks:
        click.echo(
            f"live-smoke: SECRET LEAK DETECTED — refusing to leave evidence file. warnings={leaks}",
            err=True,
        )
        written_path.unlink(missing_ok=True)
        sys.exit(EXIT_GENERIC)
    click.echo(f"[live-smoke] transcript: {written_path}")
    summary = transcript.summary()
    if summary["failed"] > 0:
        sys.exit(EXIT_GENERIC)
    sys.exit(EXIT_OK)


_MCP_HELP = "Run the DSK MCP (Model Context Protocol) server."


@main.group("mcp", help=_MCP_HELP)
def mcp_cli() -> None:
    """MCP server commands."""


main.add_command(cmd_bundle)
main.add_command(audit_cmd)
main.add_command(drift_watch_cmd)
main.add_command(discover_cmd)
main.add_command(scan_cmd)
main.add_command(import_from_keepercmd_cmd)
main.add_command(rehearse_report_cmd)
main.add_command(verify_cmd)
main.add_command(shim_info_cmd)


@mcp_cli.command("serve")
def mcp_serve() -> None:
    """Start the DSK MCP stdio server (JSON-RPC).

    Requires the 'mcp' extra: pip install 'declarative-sdk-for-k[mcp]'
    """
    try:
        from dsk.mcp.server import main as mcp_main  # noqa: PLC0415
    except ImportError as exc:
        click.echo(
            f"mcp extra not installed: {exc}\n"
            "Install with: pip install 'declarative-sdk-for-k[mcp]'",
            err=True,
        )
        sys.exit(EXIT_GENERIC)
    mcp_main()


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------------------
# refusal check


def _dispatch_refusal_check(
    path: str,
    max_age_days: int,
    require_class: bool,
    emit_json: bool,
    exit_zero: bool,
) -> None:
    from dsk.core.refusal import DEFAULT_PREDICATES, RefusalRunner  # noqa: PLC0415

    try:
        max_bytes = positive_int_env(
            "DSK_CLI_MAX_REFUSAL_MANIFEST_BYTES",
            DEFAULT_CLI_MAX_MANIFEST_BYTES,
        )
        doc = (
            read_yaml_file_limited(
                Path(path),
                max_bytes=max_bytes,
                max_depth=_cli_yaml_depth_limit(),
                label="refusal manifest",
                byte_limit_name="DSK_CLI_MAX_REFUSAL_MANIFEST_BYTES",
                depth_limit_name="DSK_CLI_MAX_YAML_DEPTH",
            )
            or {}
        )
    except ResourceLimitError as exc:
        _resource_limit_exit(exc)
    if not isinstance(doc, dict):
        click.echo("manifest must parse to a mapping", err=True)
        sys.exit(EXIT_GENERIC)

    predicates = list(DEFAULT_PREDICATES)
    from dsk.core.refusal import refuse_missing_class  # noqa: PLC0415

    if refuse_missing_class not in predicates:
        predicates.append(refuse_missing_class)

    runner = RefusalRunner(
        predicates,
        max_age_days=max_age_days,
        required=require_class,
    )
    violations = runner.check(doc)

    if emit_json:
        import dataclasses  # noqa: PLC0415

        click.echo(json.dumps([dataclasses.asdict(v) for v in violations]))
        if exit_zero:
            sys.exit(EXIT_OK)
        has_error = any(v.severity == "error" for v in violations)
        has_warning = any(v.severity == "warning" for v in violations)
        if has_error:
            sys.exit(2)
        if has_warning:
            sys.exit(EXIT_GENERIC)
        sys.exit(EXIT_OK)

    console = Console()
    if not violations:
        console.print("[green]✓ No refusal violations[/green]")
        sys.exit(EXIT_OK)

    table = Table(show_header=True, header_style="bold")
    table.add_column("Severity")
    table.add_column("uid_ref")
    table.add_column("Predicate")
    table.add_column("Reason")

    _SEVERITY_COLOR = {"error": "red", "warning": "yellow", "info": "blue"}
    for v in violations:
        color = _SEVERITY_COLOR.get(v.severity, "white")
        table.add_row(
            f"[{color}]{v.severity}[/{color}]",
            v.uid_ref,
            v.predicate,
            v.reason,
        )
    console.print(table)

    if exit_zero:
        sys.exit(EXIT_OK)

    has_error = any(v.severity == "error" for v in violations)
    has_warning = any(v.severity == "warning" for v in violations)
    if has_error:
        sys.exit(2)
    if has_warning:
        sys.exit(EXIT_GENERIC)
    sys.exit(EXIT_OK)


@main.command("refusal")
@click.argument("path", type=click.Path(exists=True))
@click.option(
    "--max-age-days", default=90, show_default=True, help="Max allowed credential age in days."
)
@click.option(
    "--require-class", is_flag=True, default=False, help="Require secret_class on all resources."
)
@click.option("--json", "emit_json", is_flag=True, default=False)
@click.option("--exit-zero", is_flag=True, default=False, help="Always exit 0 (CI report mode).")
def refusal_check(
    path: str,
    max_age_days: int,
    require_class: bool,
    emit_json: bool,
    exit_zero: bool,
) -> None:
    """Run refusal policy checks on a manifest. Exit 2 if any ERROR violations found."""
    _dispatch_refusal_check(path, max_age_days, require_class, emit_json, exit_zero)


# ---------------------------------------------------------------------------
# panic-revoke


def _dispatch_panic_revoke(
    uid_ref: str,
    manifest_path: str,
    reason: str,
    dry_run: bool,
) -> None:
    import datetime  # noqa: PLC0415

    file_path = Path(manifest_path)
    try:
        max_bytes = positive_int_env(
            "DSK_CLI_MAX_PANIC_MANIFEST_BYTES",
            DEFAULT_CLI_MAX_MANIFEST_BYTES,
        )
        text = read_text_limited(
            file_path,
            max_bytes=max_bytes,
            label="panic-revoke manifest",
            limit_name="DSK_CLI_MAX_PANIC_MANIFEST_BYTES",
        )
    except ResourceLimitError as exc:
        _resource_limit_exit(exc)

    timestamp = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    annotation = (
        f"# PANIC-REVOKE: {uid_ref}\n"
        f"# Reason: {reason}\n"
        f"# Timestamp: {timestamp}\n"
        f"# Action required: rotate or delete this resource immediately\n"
    )

    lines = text.splitlines(keepends=True)
    insert_idx: int | None = None
    for i, line in enumerate(lines):
        if uid_ref in line:
            insert_idx = i
            break

    if insert_idx is None:
        click.echo(f"uid_ref {uid_ref!r} not found in manifest", err=True)
        sys.exit(EXIT_GENERIC)

    annotated_lines = lines[:insert_idx] + [annotation] + lines[insert_idx:]
    annotated_text = "".join(annotated_lines)

    console = Console()
    if dry_run:
        click.echo(annotation, nl=False)
        console.print(f"[yellow]dry-run: annotation NOT written for {uid_ref}[/yellow]")
        sys.exit(EXIT_OK)

    file_path.write_text(annotated_text, encoding="utf-8")
    console.print(f"[red]⚠ Panic revoke annotation added for {uid_ref}[/red]")
    sys.exit(EXIT_OK)


@main.command("panic-revoke")
@click.argument("uid_ref")
@click.option(
    "--manifest",
    "manifest_path",
    required=True,
    type=click.Path(exists=True),
    help="Manifest file to annotate.",
)
@click.option("--reason", required=True, help="Reason for revocation (required for audit trail).")
@click.option("--dry-run", is_flag=True, default=False)
def panic_revoke(
    uid_ref: str,
    manifest_path: str,
    reason: str,
    dry_run: bool,
) -> None:
    """Mark a resource for emergency revocation in the manifest. Writes a YAML comment block."""
    _dispatch_panic_revoke(uid_ref, manifest_path, reason, dry_run)
