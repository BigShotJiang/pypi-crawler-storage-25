"""dsk bundle — generate compliance evidence bundle from a compliance-bundle.v1 manifest."""

from __future__ import annotations

import json
import subprocess
import sys
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

import click

from dsk.core.resource_limits import (
    ResourceLimitError,
    positive_int_env,
    read_yaml_file_limited,
)

BundleManifest = dict[str, object]
ReportRunner = Callable[[str, list[str]], dict[str, object]]
ProgressCallback = Callable[[str, str, dict[str, object]], None]

REPORT_TIMEOUT_SECONDS = 60
REPORT_STDERR_PREVIEW_CHARS = 200
# Bundle manifests are operator-authored but may point at generated evidence
# trees; keep the CLI reader bounded before YAML parsing.
DEFAULT_BUNDLE_MANIFEST_MAX_BYTES = 1 * 1024 * 1024
DEFAULT_BUNDLE_MANIFEST_MAX_DEPTH = 64


def _bundle_manifest_max_bytes() -> int:
    return positive_int_env(
        "DSK_BUNDLE_MAX_MANIFEST_BYTES",
        DEFAULT_BUNDLE_MANIFEST_MAX_BYTES,
    )


def _bundle_manifest_max_depth() -> int:
    return positive_int_env(
        "DSK_BUNDLE_MAX_MANIFEST_DEPTH",
        DEFAULT_BUNDLE_MANIFEST_MAX_DEPTH,
    )


def _safe_evidence_path(out_dir: Path, evidence_file: str) -> Path:
    if "\x00" in evidence_file:
        raise ValueError("unsafe evidence_file contains NUL byte")

    relative_path = Path(evidence_file)
    if relative_path.is_absolute():
        raise ValueError(f"unsafe evidence_file {evidence_file!r}: absolute paths are not allowed")
    if ".." in relative_path.parts:
        raise ValueError(f"unsafe evidence_file {evidence_file!r}: parent traversal is not allowed")

    root = out_dir.resolve(strict=False)
    candidate = (out_dir / relative_path).resolve(strict=False)
    if not candidate.is_relative_to(root):
        raise ValueError(
            f"unsafe evidence_file {evidence_file!r}: resolved path escapes output dir"
        )
    return candidate


def _run_report(report_type: str, extra_args: list[str]) -> dict:
    """Run dsk report <type> and return parsed JSON output."""
    cmd = [sys.executable, "-m", "dsk.cli", "report", report_type, *extra_args]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=REPORT_TIMEOUT_SECONDS)
        if result.returncode not in (0, 1):
            return {
                "error": f"report exit {result.returncode}",
                "stderr": result.stderr[:REPORT_STDERR_PREVIEW_CHARS],
            }
        return json.loads(result.stdout or "{}")
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError) as exc:
        return {"error": str(exc)}


def _load_bundle_manifest(manifest_path: str) -> BundleManifest:
    data = read_yaml_file_limited(
        Path(manifest_path),
        max_bytes=_bundle_manifest_max_bytes(),
        max_depth=_bundle_manifest_max_depth(),
        label="compliance bundle manifest",
        byte_limit_name="DSK_BUNDLE_MAX_MANIFEST_BYTES",
        depth_limit_name="DSK_BUNDLE_MAX_MANIFEST_DEPTH",
    )
    if not isinstance(data, dict):
        raise ValueError("manifest must be a mapping")
    schema = data.get("schema", "")
    if schema != "compliance-bundle.v1":
        raise ValueError(f"expected compliance-bundle.v1, got {schema!r}")
    return data


def _bundle_header_lines(data: BundleManifest, out_dir: str) -> list[str]:
    name = str(data.get("name", "bundle"))
    frameworks = data.get("frameworks", [])
    controls = data.get("controls", [])
    framework_names = [str(item) for item in frameworks] if isinstance(frameworks, list) else []
    control_count = len(controls) if isinstance(controls, list) else 0
    return [
        f"Compliance bundle: {name}",
        f"Frameworks: {', '.join(framework_names)}",
        f"Controls: {control_count}",
        f"Output: {out_dir}",
    ]


def _dry_run_lines(controls: list[dict[str, object]]) -> list[str]:
    lines = ["", "[dry-run] Would generate:"]
    for ctrl in controls:
        lines.append(f"  {str(ctrl['control_id']):12s} -> {ctrl['evidence_file']}")
    return lines


def _generate_bundle(
    data: BundleManifest,
    out_dir: str,
    *,
    report_runner: ReportRunner | None = None,
    progress: ProgressCallback | None = None,
) -> tuple[int, Path]:
    controls = data.get("controls", [])
    if not isinstance(controls, list):
        raise ValueError("controls must be a list")

    output_root = Path(out_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    bundle_meta: dict[str, object] = {
        "bundle_name": data.get("name", "bundle"),
        "frameworks": data.get("frameworks", []),
        "generated_at": datetime.now(UTC).isoformat(),
        "controls": [],
    }
    meta_controls: list[dict[str, str]] = []
    errors = 0
    runner = report_runner or _run_report
    for ctrl in controls:
        if not isinstance(ctrl, dict):
            raise ValueError("control rows must be mappings")
        control_id = str(ctrl["control_id"])
        evidence_file = str(ctrl["evidence_file"])
        report_type = str(ctrl["report"])
        extra_args = ctrl.get("report_args", [])
        if not isinstance(extra_args, list):
            raise ValueError("report_args must be a list")

        out_path = _safe_evidence_path(output_root, evidence_file)
        evidence = runner(report_type, [str(arg) for arg in extra_args])
        evidence["_control_id"] = control_id
        evidence["_description"] = str(ctrl.get("description", ""))
        evidence["_collected_at"] = datetime.now(UTC).isoformat()
        if progress is not None:
            progress(control_id, evidence_file, evidence)

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(evidence, indent=2), encoding="utf-8")
        status = "error" if "error" in evidence else "ok"
        if status == "error":
            errors += 1
        meta_controls.append(
            {"control_id": control_id, "evidence_file": evidence_file, "status": status}
        )

    bundle_meta["controls"] = meta_controls
    index_path = output_root / "bundle-index.json"
    index_path.write_text(json.dumps(bundle_meta, indent=2), encoding="utf-8")
    return errors, index_path


def _echo_bundle_progress(control_id: str, evidence_file: str, evidence: dict[str, object]) -> None:
    if "error" in evidence:
        click.echo(f"  {control_id} -> {evidence_file} WARN ({evidence['error']})")
    else:
        click.echo(f"  {control_id} -> {evidence_file} OK")


@click.command("bundle")
@click.argument("manifest_path")
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Show what would be generated without running reports",
)
@click.option("--output-dir", default=None, help="Override output directory from manifest")
def cmd_bundle(manifest_path: str, dry_run: bool, output_dir: str | None) -> None:
    """Generate a compliance evidence bundle from a compliance-bundle.v1 manifest.

    Runs dsk report commands for each declared control and writes JSON evidence
    files to the output directory. Suitable for FedRAMP High, SOC2 Type 2, ISO27001.

    \b
    Exit codes:
      0 = bundle generated successfully
      1 = error (manifest invalid, reports failed)
    """
    try:
        data = _load_bundle_manifest(manifest_path)
    except ResourceLimitError as exc:
        click.echo(f"Error reading manifest: resource limit exceeded: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Error reading manifest: {exc}", err=True)
        sys.exit(1)

    out_dir = output_dir or data.get("output_dir", "compliance-evidence/")
    controls = data.get("controls", [])
    if not isinstance(controls, list):
        click.echo("Error reading manifest: controls must be a list", err=True)
        sys.exit(1)

    for line in _bundle_header_lines(data, str(out_dir)):
        click.echo(line)

    if dry_run:
        for line in _dry_run_lines(controls):
            click.echo(line)
        sys.exit(0)

    errors, index_path = _generate_bundle(data, str(out_dir), progress=_echo_bundle_progress)
    click.echo(f"\nBundle index: {index_path}")
    click.echo(f"Complete. {len(controls) - errors}/{len(controls)} controls OK.")

    sys.exit(0 if errors == 0 else 1)
