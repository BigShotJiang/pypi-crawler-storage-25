"""keeper-sdk CLI package.

:public: Console entry point re-export. Command callback functions and helper
modules are internal unless documented as CLI surface in ``docs/api/stability.md``.
"""

from dsk.cli.main import main

__all__ = ["main"]
