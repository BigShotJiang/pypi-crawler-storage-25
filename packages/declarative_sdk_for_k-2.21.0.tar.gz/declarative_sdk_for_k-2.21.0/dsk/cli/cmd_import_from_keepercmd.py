"""``dsk import-from-keepercmd`` — adopt keeperCMD-migrated records under DSK ownership.

Consumes a keeperCMD run-dir (OUTPUT_CONTRACT.md v1.0) and either reports the
adoption plan or writes ``keeper_declarative_manager`` ownership markers on the
matched target records via the Commander SDK.

Run-dir layout expected::

    <run-dir>/
    ├── inventory.json
    ├── manifest.csv
    ├── records_export/          # <source_uid>.json per record (keeperCMD v1.x)
    ├── audit.log
    └── SHA256SUMS.txt
"""

from __future__ import annotations

import csv
import errno
import hashlib
import json
import logging
import os
import re
import stat
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Any, cast

import click
import yaml
from rich.console import Console
from rich.table import Table

from dsk._obs import get_logger, log_event
from dsk.cli.audit_chain import AuditChainCorrupt, verify_audit_log
from dsk.core.field_names import field_name_matches
from dsk.core.metadata import MARKER_FIELD_LABEL, encode_marker
from dsk.core.record_type_aliases import RECORD_TYPE_ALIASES as _aliases
from dsk.core.resource_limits import (
    ResourceLimitError,
    json_loads_limited,
    positive_int_env,
    read_text_limited,
)
from dsk.core.vault_models import _VAULT_PAM_CANONICAL_BY_LOWER, VAULT_SUPPORTED_RECORD_TYPES
from dsk.security.keeper_pubkey import KeeperSessionRequired, fetch_minisign_pubkey_from_keeper
from dsk.security.minisign import MinisignVerificationError, verify_sha256sums_signature

EXIT_OK = 0
EXIT_GENERIC = 1
EXIT_FORMAT = 2
EXIT_CAPABILITY = 5

DEFAULT_MAX_ARTIFACT_BYTES = 100 * 1024 * 1024
DEFAULT_MAX_ARTIFACT_DEPTH = 64
DEFAULT_MAX_MANIFEST_CSV_ROWS = 1_000_000
DEFAULT_MAX_SIGNATURE_PUBKEY_BYTES = 16 * 1024
DEFAULT_COMMANDER_SERVER_ALLOWLIST = (
    "keepersecurity.com",
    "keepersecurity.eu",
    "keepersecurity.com.au",
    "govcloud.keepersecurity.us",
)
_LOG = get_logger(__name__)

_SOURCE_UID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_SHA256SUMS_PATH_PATTERN = re.compile(r"^[A-Za-z0-9_./-]+$")


def _max_artifact_bytes() -> int:
    raw = os.environ.get("DSK_MAX_ARTIFACT_BYTES")
    if raw is None:
        return DEFAULT_MAX_ARTIFACT_BYTES
    try:
        value = int(raw)
    except ValueError as exc:
        raise ImportError("DSK_MAX_ARTIFACT_BYTES must be an integer") from exc
    if value <= 0:
        raise ImportError("DSK_MAX_ARTIFACT_BYTES must be greater than 0")
    return value


def _max_manifest_csv_rows() -> int:
    raw = os.environ.get("DSK_MAX_MANIFEST_CSV_ROWS")
    if raw is None:
        return DEFAULT_MAX_MANIFEST_CSV_ROWS
    try:
        value = int(raw)
    except ValueError as exc:
        raise ImportError("DSK_MAX_MANIFEST_CSV_ROWS must be an integer") from exc
    if value <= 0:
        raise ImportError("DSK_MAX_MANIFEST_CSV_ROWS must be greater than 0")
    return value


def _max_artifact_depth() -> int:
    try:
        return positive_int_env("DSK_MAX_ARTIFACT_DEPTH", DEFAULT_MAX_ARTIFACT_DEPTH)
    except ResourceLimitError as exc:
        raise ImportError(str(exc)) from exc


def _max_signature_pubkey_bytes() -> int:
    try:
        return positive_int_env(
            "DSK_SIGNATURE_PUBKEY_MAX_BYTES", DEFAULT_MAX_SIGNATURE_PUBKEY_BYTES
        )
    except ResourceLimitError as exc:
        raise ImportError(str(exc)) from exc


def _safe_open(
    path: Path,
    mode: str = "r",
    *,
    encoding: str | None = "utf-8",
    newline: str | None = None,
) -> IO[Any]:
    """Open an input artifact after symlink, mode, and size checks."""
    if not set(mode) & {"r", "+"}:
        raise ValueError("_safe_open is only for reading existing input artifacts")
    try:
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(path, flags)
    except OSError as exc:
        if exc.errno in {errno.ELOOP, errno.EMLINK}:
            raise ImportError(f"{path.name} is a symlink; refusing to read input artifact") from exc
        raise ImportError(f"{path.name} unreadable: {type(exc).__name__}") from exc

    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            raise ImportError(f"{path.name} is not a regular file; refusing to read input artifact")
        if st.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            logging.warning(
                "input artifact %s is group/world-writable; continuing with warning",
                path,
            )
        max_bytes = _max_artifact_bytes()
        if st.st_size > max_bytes:
            raise ImportError(
                f"{path.name} is {st.st_size} bytes, exceeding DSK_MAX_ARTIFACT_BYTES={max_bytes}"
            )
    except Exception:
        os.close(fd)
        raise

    if "b" in mode:
        return open(fd, mode, closefd=True)
    return open(fd, mode, encoding=encoding, newline=newline, closefd=True)


def _read_json_artifact(path: Path) -> Any:
    raw = _read_text_artifact(path)
    try:
        return json_loads_limited(
            raw,
            max_bytes=_max_artifact_bytes(),
            max_depth=_max_artifact_depth(),
            label=path.name,
            byte_limit_name="DSK_MAX_ARTIFACT_BYTES",
            depth_limit_name="DSK_MAX_ARTIFACT_DEPTH",
        )
    except ResourceLimitError as exc:
        raise ImportError(str(exc)) from exc


def _read_text_artifact(path: Path) -> str:
    with _safe_open(path, "r", encoding="utf-8") as fh:
        return cast(str, fh.read())


def _read_bytes_artifact(path: Path) -> bytes:
    with _safe_open(path, "rb", encoding=None) as fh:
        return cast(bytes, fh.read())


def _validate_source_uid(source_uid: str) -> str:
    """Validate that source_uid contains only safe characters.

    Rejects path traversal attempts (../, /), null bytes, length > 64,
    and any non-[A-Za-z0-9_-] characters.

    Returns the validated source_uid (unchanged on success).
    Raises ImportError on any violation.
    """
    if not isinstance(source_uid, str):
        raise ImportError(f"source_uid must be string, got {type(source_uid).__name__}")
    if not _SOURCE_UID_PATTERN.match(source_uid):
        raise ImportError(
            f"source_uid {source_uid[:32]!r} contains invalid characters "
            f"(allowed: [A-Za-z0-9_-]{{1,64}}); rejecting to prevent path traversal"
        )
    return source_uid


def _safe_export_path(records_export_dir: Path, source_uid: str) -> Path:
    """Build the records-export path with traversal-resistance.

    Validates source_uid format, then resolves the joined path and asserts
    it remains inside records_export_dir (prevents symlink-following escape).
    """
    validated = _validate_source_uid(source_uid)
    candidate = (records_export_dir / f"{validated}.json").resolve()
    base = records_export_dir.resolve()
    if not candidate.is_relative_to(base):
        raise ImportError(
            f"refusing path traversal: {validated!r} resolves outside records-export dir"
        )
    return candidate


_SUPPORTED_CONTRACT_VERSIONS = {"1.0", "1.1"}
_DEFAULT_CONTRACT_VERSION = "1.0"
_SUPPORTED_INVENTORY_SCHEMA_VERSIONS = frozenset({"1.0", "1.1"})
_RECORDS_EXPORT_DIR_NAMES = ("records_export", "records-export")
_REQUIRED_SHA256SUM_FILES = frozenset({"inventory.json", "manifest.csv", "records_import.json"})

_RECORD_TYPE_CACHE: dict[str, list[dict[str, Any]]] = {}
_COMMANDER_SESSION: Any = None


def _check_inventory_schema_version(inv: dict[str, Any], console: Console) -> None:
    """OUTPUT_CONTRACT §6: inspect inventory.json schema_version."""
    sv = inv.get("schema_version")
    if sv is None:
        console.print(
            "[yellow]warn:[/] inventory.json missing schema_version field — "
            "artifact schema inspection incomplete (OUTPUT_CONTRACT §6)"
        )
        return
    if sv not in _SUPPORTED_INVENTORY_SCHEMA_VERSIONS:
        raise ImportError(
            f"inventory.json schema_version {sv!r} is not supported "
            f"(expected one of {sorted(_SUPPORTED_INVENTORY_SCHEMA_VERSIONS)})"
        )


def _check_contract_version(run_dir: Path, console: Console) -> None:
    """Inspect _contract_version + schema_version in inventory.json.

    Requires a readable inventory.json (integrity must be verified upstream).
    Defaults to v1.0 contract if _contract_version absent (per OUTPUT_CONTRACT §2).
    Aborts with EXIT_FORMAT if _contract_version is present but unsupported.
    """
    inventory_path = run_dir / "inventory.json"
    if not inventory_path.exists():
        raise ImportError(
            "inventory.json missing — cannot verify contract version. "
            "Refusing to consume run-dir without integrity check."
        )
    try:
        data = _read_json_artifact(inventory_path)
    except json.JSONDecodeError as e:
        raise ImportError(
            f"inventory.json malformed: {type(e).__name__}. Refusing to consume."
        ) from e
    _check_inventory_schema_version(data, console)

    version = data.get("_contract_version", _DEFAULT_CONTRACT_VERSION)
    if version not in _SUPPORTED_CONTRACT_VERSIONS:
        console.print(
            f"[red]abort:[/] OUTPUT_CONTRACT version [bold]{version}[/] is not supported "
            f"by this version of DSK (supports: {sorted(_SUPPORTED_CONTRACT_VERSIONS)}). "
            "Upgrade dsk to consume this run-dir."
        )
        sys.exit(EXIT_FORMAT)
    if version != _DEFAULT_CONTRACT_VERSION:
        console.print(f"[dim]info:[/] OUTPUT_CONTRACT {version} detected (supported)")


def _verify_audit_log(log_path: Path) -> None:
    """Raises AuditChainCorrupt on any integrity failure."""
    verify_audit_log(log_path)


def _has_ownership_marker(record_export: dict[str, Any]) -> bool:
    for field in record_export.get("custom") or []:
        if field_name_matches(field.get("label"), MARKER_FIELD_LABEL):
            return True
    return False


def _read_suspect_marker(export_path: Path, suspect_threshold: int) -> bool:
    """Read suspect marker from records-export JSON.

    Fail-CLOSED on parse errors: any unreadable / corrupt JSON marker is
    treated as suspect=True. This prevents an attacker from bypassing
    the marker by appending one trailing byte to corrupt parsing.

    If --suspect-threshold is 0 (no records allowed suspect) and parse
    fails, raise a hard ImportError instead of silently passing.
    """
    try:
        data = _read_json_artifact(export_path)
        return bool(data.get("suspect", False)) or _has_ownership_marker(data)
    except (OSError, json.JSONDecodeError, ImportError) as e:
        if suspect_threshold == 0:
            raise ImportError(
                f"records-export JSON {export_path.name} unreadable ({type(e).__name__}); "
                f"--suspect-threshold=0 forbids any suspect records, refusing to proceed"
            ) from e
        logging.warning(
            "records-export JSON %s unreadable (%s); treating as suspect=True (fail-closed)",
            export_path.name,
            type(e).__name__,
        )
        return True


def _validate_sha256sum_path(
    run_dir: Path, file_path: str, *, sha_parent: Path | None = None
) -> Path:
    if file_path.startswith("/"):
        raise ImportError(f"SHA256SUMS path {file_path!r} is absolute; refusing to read")
    if ".." in file_path:
        raise ImportError(f"SHA256SUMS path {file_path!r} contains '..'; refusing to read")
    if not _SHA256SUMS_PATH_PATTERN.fullmatch(file_path):
        raise ImportError(
            f"SHA256SUMS path {file_path!r} contains unsupported characters; refusing to read"
        )
    base_dir = sha_parent or run_dir
    resolved_run_dir = run_dir.resolve()
    resolved_path = (base_dir / file_path).resolve()
    if not resolved_path.is_relative_to(resolved_run_dir):
        raise ImportError(
            f"SHA256SUMS path {file_path!r} resolves outside run-dir; refusing to read"
        )
    if resolved_path.exists() or "/" in file_path:
        return resolved_path
    # sha256sum convention resolves entries relative to the SHA256SUMS file.
    # keeperCMD D1 emitted bare record basenames, so if a safe basename is not
    # beside SHA256SUMS.txt, try common v1.x records export dirs.
    for dirname in _RECORDS_EXPORT_DIR_NAMES:
        fallback = (base_dir / dirname / file_path).resolve()
        if fallback.is_relative_to(resolved_run_dir) and fallback.exists():
            return fallback
    return resolved_path


def _iter_sha256sum_entries(run_dir: Path, sha_file: Path) -> list[tuple[str, str, Path]]:
    try:
        lines = _read_text_artifact(sha_file).splitlines()
    except OSError as exc:
        raise ImportError(f"cannot read SHA256SUMS.txt: {type(exc).__name__}") from exc
    entries: list[tuple[str, str, Path]] = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        expected_hash, file_path = parts
        file_path = file_path.lstrip("*")
        abs_path = _validate_sha256sum_path(run_dir, file_path, sha_parent=sha_file.parent)
        entries.append((expected_hash, file_path, abs_path))
    return entries


def _sha256_python_fallback(run_dir: Path, sha_file: Path, console: Console) -> bool:
    try:
        entries = _iter_sha256sum_entries(run_dir, sha_file)
    except ImportError as exc:
        console.print(f"[red]error:[/] {exc}")
        return False
    failures: list[str] = []
    for expected_hash, file_path, abs_path in entries:
        if not abs_path.exists():
            failures.append(f"{file_path}: file not found")
            continue
        try:
            actual = hashlib.sha256(_read_bytes_artifact(abs_path)).hexdigest()
        except ImportError as exc:
            failures.append(f"{file_path}: {exc}")
            continue
        if actual != expected_hash:
            failures.append(f"{file_path}: hash mismatch (expected {expected_hash[:12]}…)")
    if failures:
        for msg in failures:
            console.print(f"[red]sha256 fail:[/] {msg}")
        return False
    return True


def _verify_manifest_csv_sidecar(run_dir: Path, console: Console, verbose: bool) -> bool:
    """Check manifest.csv.sha256 sidecar (keeperCMD v1.1+). Returns True if ok or absent."""
    sidecar = run_dir / "manifest.csv.sha256"
    csv_path = run_dir / "manifest.csv"
    if not sidecar.exists():
        if verbose:
            console.print(
                "[dim]manifest.csv.sha256 sidecar absent — pre-v1.1 keeperCMD, skipping sidecar check[/dim]"
            )
        return True
    try:
        stored_line = _read_text_artifact(sidecar).strip()
        stored_digest = stored_line.split()[0]
    except (ImportError, OSError, IndexError) as exc:
        console.print(f"[red]error:[/] cannot read manifest.csv.sha256: {type(exc).__name__}")
        return False
    try:
        live_digest = hashlib.sha256(_read_bytes_artifact(csv_path)).hexdigest()
    except ImportError as exc:
        console.print(f"[red]error:[/] cannot read manifest.csv: {exc}")
        return False
    if live_digest != stored_digest:
        console.print(
            f"[red]error:[/] manifest.csv.sha256 mismatch — "
            f"stored={stored_digest[:12]}… live={live_digest[:12]}… "
            "manifest.csv may have been tampered with after keeperCMD wrote it"
        )
        return False
    if verbose:
        console.print(f"[green]manifest.csv.sha256:[/] {stored_digest[:16]}… ✓")
    return True


def _verify_sha256sums(run_dir: Path, console: Console, verbose: bool) -> bool:
    sha_file = run_dir / "SHA256SUMS.txt"
    if not sha_file.exists():
        console.print("[yellow]warn:[/] SHA256SUMS.txt not found — skipping file integrity check")
        return True
    try:
        entries = _iter_sha256sum_entries(run_dir, sha_file)
    except ImportError as exc:
        console.print(f"[red]error:[/] {exc}")
        return False
    entry_paths = {file_path for _expected_hash, file_path, _abs_path in entries}
    # Older keeperCMD fixtures sometimes used SHA256SUMS.txt only for per-record
    # exports. Once any core run-dir artifact is listed, require the complete
    # core set so a missing row cannot silently bypass integrity verification.
    listed_required = _REQUIRED_SHA256SUM_FILES & entry_paths
    missing = sorted(_REQUIRED_SHA256SUM_FILES - entry_paths)
    if listed_required and missing:
        console.print(
            "[red]sha256 fail:[/] SHA256SUMS.txt missing required row(s): " + ", ".join(missing)
        )
        return False
    ok = _sha256_python_fallback(run_dir, sha_file, console)
    if ok and verbose:
        console.print("[green]sha256 (python fallback):[/] all entries verified")
    return ok


def _load_signature_pubkey(
    signature_pubkey: Path | None,
    signature_pubkey_keeper_record: str | None,
) -> str:
    if signature_pubkey is not None:
        try:
            return read_text_limited(
                signature_pubkey,
                max_bytes=_max_signature_pubkey_bytes(),
                label="--signature-pubkey",
                limit_name="DSK_SIGNATURE_PUBKEY_MAX_BYTES",
            ).strip()
        except ResourceLimitError as exc:
            raise ImportError(f"--signature-pubkey unreadable: {exc}") from exc
    if signature_pubkey_keeper_record:
        try:
            return fetch_minisign_pubkey_from_keeper(signature_pubkey_keeper_record, None)
        except KeeperSessionRequired as exc:
            raise ImportError(str(exc)) from exc
    raise ImportError(
        "--require-output-signature needs --signature-pubkey FILE "
        "or --signature-pubkey-keeper-record UID"
    )


def _verify_output_signature(
    run_dir: Path,
    console: Console,
    *,
    signature_pubkey: Path | None,
    signature_pubkey_keeper_record: str | None,
    verbose: bool,
) -> None:
    try:
        pubkey = _load_signature_pubkey(signature_pubkey, signature_pubkey_keeper_record)
        result = verify_sha256sums_signature(run_dir, pubkey)
    except MinisignVerificationError as exc:
        console.print(f"[red]signature error:[/] {exc.code}: {exc}")
        sys.exit(EXIT_CAPABILITY)
    except ImportError as exc:
        console.print(f"[red]signature error:[/] {exc}")
        sys.exit(EXIT_CAPABILITY)
    if verbose:
        console.print(f"[green]output signature:[/] verified by {result.key_identifier}")


def _sha256sum_path_matches(file_path: str, expected: str) -> bool:
    normalized = file_path.strip()
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized == expected


def _verify_signed_inventory_hash(run_dir: Path, console: Console) -> bool:
    sha_file = run_dir / "SHA256SUMS.txt"
    try:
        entries = _iter_sha256sum_entries(run_dir, sha_file)
    except ImportError as exc:
        console.print(f"[red]signature error:[/] {exc}")
        return False
    for expected_hash, file_path, abs_path in entries:
        if not _sha256sum_path_matches(file_path, "inventory.json"):
            continue
        if not abs_path.exists():
            console.print(
                "[red]signature error:[/] signed SHA256SUMS.txt lists missing inventory.json"
            )
            return False
        try:
            actual = hashlib.sha256(_read_bytes_artifact(abs_path)).hexdigest()
        except ImportError as exc:
            console.print(f"[red]signature error:[/] cannot read signed inventory.json: {exc}")
            return False
        if actual != expected_hash:
            console.print(
                "[red]signature error:[/] inventory.json hash mismatch under signed SHA256SUMS.txt "
                f"(expected {expected_hash[:12]}…, got {actual[:12]}…)"
            )
            return False
        return True
    console.print("[red]signature error:[/] signed SHA256SUMS.txt must cover inventory.json")
    return False


def _parse_manifest_csv(csv_path: Path) -> list[dict[str, str]]:
    with _safe_open(csv_path, newline="", encoding="utf-8") as fh:
        content_lines = (line for line in fh if line.strip() and not line.lstrip().startswith("#"))
        reader = csv.DictReader(content_lines)
        rows: list[dict[str, str]] = []
        max_rows = _max_manifest_csv_rows()
        for index, row in enumerate(reader, start=1):
            if index > max_rows:
                _LOG.info(
                    "keepercmd_import.resource_limit.applied",
                    extra={
                        "event": "keepercmd_import.resource_limit.applied",
                        "limit": "DSK_MAX_MANIFEST_CSV_ROWS",
                        "value": max_rows,
                        "rows": index,
                    },
                )
                raise ImportError(
                    f"manifest.csv row count exceeds DSK_MAX_MANIFEST_CSV_ROWS={max_rows}"
                )
            rows.append(row)
        return rows


def _records_export_dirname(run_dir: Path) -> str | None:
    """Return the keeperCMD per-record export dirname when one is present."""
    canonical, deprecated = _RECORDS_EXPORT_DIR_NAMES
    canonical_exists = (run_dir / canonical).is_dir()
    deprecated_exists = (run_dir / deprecated).is_dir()
    if canonical_exists:
        if deprecated_exists:
            _LOG.warning(
                "both %s/ and %s/ exist; using canonical %s/",
                canonical,
                deprecated,
                canonical,
                extra={
                    "event": "keepercmd_import.records_export_dir.both_present",
                    "canonical": canonical,
                    "deprecated": deprecated,
                    "selected": canonical,
                },
            )
        return canonical
    if deprecated_exists:
        _LOG.warning(
            "%s/ is deprecated; use canonical %s/",
            deprecated,
            canonical,
            extra={
                "event": "keepercmd_import.records_export_dir.deprecated",
                "canonical": canonical,
                "deprecated": deprecated,
                "selected": deprecated,
            },
        )
        return deprecated
    return None


def _records_export_dir(run_dir: Path) -> Path:
    """Return the keeperCMD per-record export dir, accepting legacy spelling."""
    dirname = _records_export_dirname(run_dir)
    return run_dir / (dirname or _RECORDS_EXPORT_DIR_NAMES[0])


def _build_inventory_lookup(inv_path: Path) -> dict[str, dict[str, Any]]:
    if not inv_path.exists():
        raise ImportError(
            "inventory.json missing — cannot build entity lookup. "
            "Refusing to consume run-dir without inventory."
        )
    try:
        data = json.loads(_read_text_artifact(inv_path))
    except (OSError, ImportError) as e:
        raise ImportError(
            f"inventory.json unreadable: {type(e).__name__}. Refusing to consume."
        ) from e
    except json.JSONDecodeError as e:
        raise ImportError(
            f"inventory.json malformed: {type(e).__name__}. Refusing to consume."
        ) from e
    if not isinstance(data, dict):
        raise ImportError("inventory.json must contain a JSON object")
    lookup: dict[str, dict[str, Any]] = {}
    entities = data.get("entities", {})
    if not isinstance(entities, dict):
        raise ImportError("inventory.json entities must contain a JSON object")
    for _collection, items in entities.items():
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            uid = item.get("uid") or item.get("target_uid") or item.get("record_uid")
            if uid:
                lookup[str(uid)] = item
    return lookup


@dataclass
class _AdoptionRow:
    source_uid: str
    target_uid: str
    title: str
    record_type: str
    suspect: bool


def _collect_rows(
    manifest_rows: list[dict[str, str]],
    records_export_dir: Path,
    verbose: bool,
    console: Console,
    suspect_threshold: int = 0,
) -> tuple[list[_AdoptionRow], int, int]:
    """Return (paired_rows, unpaired_count, skipped_count)."""
    paired: list[_AdoptionRow] = []
    unpaired_count = 0
    skipped_count = 0
    for row in manifest_rows:
        if not isinstance(row, dict):
            raise ImportError("manifest.csv row must be a mapping")
        status = (row.get("status") or "").strip()
        target_uid = (row.get("target_uid") or "").strip()
        source_uid = (row.get("source_uid") or "").strip()
        title = (row.get("title") or "").strip()
        record_type = (row.get("type") or "").strip()
        if status != "paired" or not target_uid:
            if status in ("unpaired", "ambiguous"):
                unpaired_count += 1
            else:
                skipped_count += 1
            if verbose:
                console.print(f"  skip [{status}]: {source_uid or '(no source_uid)'}")
            continue
        export_path = _safe_export_path(records_export_dir, source_uid)
        suspect = False
        if export_path.exists():
            suspect = _read_suspect_marker(export_path, suspect_threshold)
            if suspect and verbose:
                console.print(f"  [yellow]suspect:[/] {source_uid} flagged by records-export")
        paired.append(
            _AdoptionRow(
                source_uid=source_uid,
                target_uid=target_uid,
                title=title,
                record_type=record_type,
                suspect=suspect,
            )
        )
    return paired, unpaired_count, skipped_count


def _normalise_record_type(raw: str) -> tuple[str, bool]:
    """Map keeperCMD / Commander type names to DSK canonical names.

    Returns ``(canonical_type, is_custom)`` where ``is_custom`` is ``True``
    for any type not in ``VAULT_SUPPORTED_RECORD_TYPES``.

    Known aliases are resolved; unknown types pass through unchanged and are
    flagged as custom.  An ``[blue]info:[/]`` message is printed to stderr —
    custom types are expected for admin-defined vaults, not an error condition.
    """
    raw_stripped = (raw or "").strip()
    if not raw_stripped:
        return "login", False
    pam = _VAULT_PAM_CANONICAL_BY_LOWER.get(raw_stripped.lower())
    if pam is not None:
        return pam, False
    result = _aliases.get(raw_stripped, raw_stripped)
    is_custom = result not in VAULT_SUPPORTED_RECORD_TYPES
    if is_custom:
        from rich.console import Console  # noqa: PLC0415

        Console(stderr=True).print(
            f"[blue]info:[/] custom record type {raw!r} — "
            "manifest entry will be generated with empty fields; review and add field definitions"
        )
    return result, is_custom


def _open_commander_session(config_path: str) -> Any:
    """Open or reuse a Commander session, with non-interactive guard.

    Refusing api.login() in non-interactive contexts where session_token is empty,
    to avoid empty-stdin lockout risk.
    """
    global _COMMANDER_SESSION
    if _COMMANDER_SESSION is not None:
        return _COMMANDER_SESSION

    from keepercommander import api as _api  # noqa: PLC0415
    from keepercommander.params import KeeperParams  # noqa: PLC0415

    params = KeeperParams(config_filename=config_path)
    token = getattr(params, "session_token", "") or ""
    if not token and not sys.stdin.isatty():
        raise RuntimeError(
            "No valid session token + non-interactive context — refusing "
            "_api.login() to avoid empty-stdin lockout. Run keeper login "
            "interactively first to populate session_token."
        )
    _api.login(params)
    _api.sync_down(params, record_types=True)
    _COMMANDER_SESSION = params
    return params


def _resolve_from_record_type_cache(
    params: Any, type_name: str, stderr_console: Console
) -> list[dict[str, Any]]:
    cache = getattr(params, "record_type_cache", {}) or {}
    type_info = cache.get(type_name)
    if type_info is None:
        stderr_console.print(
            f"[yellow]warn:[/] custom type {type_name!r} not found in "
            "record_type_cache — leaving fields empty"
        )
        return []
    raw_fields = getattr(type_info, "fields", None) or []
    result: list[dict[str, Any]] = []
    for f in raw_fields:
        field_type = getattr(f, "field_type", None) or getattr(f, "type", None)
        label = getattr(f, "label", None)
        if field_type:
            entry: dict[str, Any] = {"type": str(field_type)}
            if label:
                entry["label"] = str(label)
            result.append(entry)
    return result


def _fetch_custom_type_fields(config_path: Path, type_name: str) -> list[dict[str, Any]]:
    """Resolve fields for a custom record type via Commander record_type_cache.

    Cached by type_name; opens Commander session once per process.
    Raises RuntimeError when Commander dependency is present but the fetch fails
    (other than ImportError — missing keepercommander yields [] plus warn).
    """
    if type_name in _RECORD_TYPE_CACHE:
        return _RECORD_TYPE_CACHE[type_name]

    stderr_console = Console(stderr=True)
    try:
        params = _open_commander_session(str(config_path))
        fields = _resolve_from_record_type_cache(params, type_name, stderr_console)
    except ImportError as exc:
        stderr_console.print(
            "[yellow]warn:[/] keepercommander not installed — "
            f"cannot resolve custom type fields: {type(exc).__name__}"
        )
        return []
    except Exception as exc:
        raise RuntimeError(
            f"failed to fetch custom type fields from Commander: {type(exc).__name__}"
        ) from exc

    _RECORD_TYPE_CACHE[type_name] = fields
    return fields


def _commander_server_allowlist() -> set[str]:
    raw = os.environ.get("DSK_COMMANDER_SERVER_ALLOWLIST")
    if raw is None:
        return set(DEFAULT_COMMANDER_SERVER_ALLOWLIST)
    return {item.strip().lower() for item in raw.split(",") if item.strip()}


def _validate_commander_config(config_path: Path) -> dict[str, Any]:
    try:
        data = json.loads(_read_text_artifact(config_path))
    except json.JSONDecodeError as e:
        raise ImportError(f"--commander-config has invalid JSON: {type(e).__name__}") from e
    except (OSError, ImportError) as e:
        raise ImportError(f"--commander-config unreadable: {type(e).__name__}") from e

    if not isinstance(data, dict):
        raise ImportError("--commander-config must contain a JSON object")

    server = str(data.get("server", "") or "").strip().lower()
    if not server:
        return data

    allowlist = _commander_server_allowlist()
    if server not in allowlist:
        raise ImportError(
            f"--commander-config server {server!r} is not allowed (allowed: {sorted(allowlist)})"
        )
    return data


def _build_manifest_yaml(
    paired: list[_AdoptionRow],
    manifest_name: str,  # noqa: ARG001
    commander_config: Path | None = None,
) -> str:
    header = "schema: keeper-vault.v1\nrecords:\n"
    if not paired:
        return header + "[]\n"
    record_blocks: list[str] = []
    for row in paired:
        normalised_type, is_custom = _normalise_record_type(row.record_type)
        entry: dict[str, Any] = {
            "uid_ref": f"keepercmd.{row.record_type}.{row.source_uid}",
            "type": normalised_type,
            "title": row.title,
            "keeper_uid": row.target_uid,
        }
        if is_custom:
            if commander_config is not None:
                fields = _fetch_custom_type_fields(commander_config, normalised_type)
            else:
                fields = []
            entry["fields"] = fields
        block = yaml.safe_dump([entry], sort_keys=False, allow_unicode=True)
        if is_custom:
            block = "# custom record type — DSK has no field schema for this type\n" + block
        record_blocks.append(block)
    return header + "".join(record_blocks)


def _write_output_manifest(output: Path, content: str, console: Console) -> bool:
    try:
        output.write_text(content, encoding="utf-8")
    except OSError as exc:
        console.print(f"[red]error:[/] cannot write manifest YAML: {type(exc).__name__}")
        return False
    return True


def _write_markers(
    paired: list[_AdoptionRow],
    manifest_name: str,
    console: Console,
    verbose: bool,
) -> list[dict[str, Any]]:
    """Write ownership markers to target records via CommanderCliProvider.

    Returns a list of outcome dicts (uid, keeper_uid, status, reason).
    """
    try:
        from dsk.providers.commander_cli import CommanderCliProvider  # noqa: PLC0415
    except ImportError as exc:
        console.print(f"[red]error:[/] commander provider unavailable: {type(exc).__name__}")
        sys.exit(EXIT_CAPABILITY)

    provider = CommanderCliProvider()
    outcomes: list[dict[str, Any]] = []
    for row in paired:
        marker = encode_marker(
            uid_ref=f"keepercmd.{row.record_type}.{row.source_uid}",
            manifest=manifest_name,
            resource_type=row.record_type or "login",
            applied_by="keepercmd/import",
        )
        try:
            provider._write_marker(row.target_uid, marker)  # noqa: SLF001
            outcomes.append(
                {
                    "source_uid": row.source_uid,
                    "target_uid": row.target_uid,
                    "title": row.title,
                    "status": "adopted",
                }
            )
            if verbose:
                console.print(f"  [green]adopted:[/] {row.title} → {row.target_uid}")
        except Exception as exc:  # noqa: BLE001
            outcomes.append(
                {
                    "source_uid": row.source_uid,
                    "target_uid": row.target_uid,
                    "title": row.title,
                    "status": "error",
                    "reason": type(exc).__name__,
                }
            )
            console.print(f"  [red]error:[/] {row.title} ({row.target_uid}): {type(exc).__name__}")
    return outcomes


@click.command("import-from-keepercmd")
@click.argument("run_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option(
    "--output",
    "-o",
    default=None,
    type=click.Path(path_type=Path),
    help="Write manifest YAML here (default: stdout when --dry-run)",
)
@click.option("--dry-run", is_flag=True, default=False, help="Show plan without writing markers")
@click.option("--auto-approve", is_flag=True, default=False, help="Skip confirmation prompt")
@click.option(
    "--skip-audit-verify", is_flag=True, default=False, help="Skip audit.log chain verification"
)
@click.option("--skip-sha256", is_flag=True, default=False, help="Skip SHA256SUMS.txt verification")
@click.option(
    "--suspect-threshold",
    default=0,
    show_default=True,
    type=int,
    help="Max allowed suspect-marker rows before aborting",
)
@click.option("--verbose", "-v", is_flag=True, default=False, help="Extra logging")
@click.option(
    "--require-output-signature",
    is_flag=True,
    default=False,
    help="Require SHA256SUMS.txt.minisig before consuming keeperCMD output.",
)
@click.option(
    "--signature-pubkey",
    default=None,
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Minisign public key file used to verify SHA256SUMS.txt.minisig.",
)
@click.option(
    "--signature-pubkey-keeper-record",
    default=None,
    help=(
        "Keeper record UID containing the minisign public key. "
        "Current offline CLI sessions should use --signature-pubkey FILE."
    ),
)
@click.option(
    "--commander-config",
    default=None,
    envvar="DSK_KEEPER_CONFIG",
    help=(
        "Path to Keeper Commander config (e.g. ~/.keeper/config.json). "
        "When provided, resolves custom record type field schemas from the live vault."
    ),
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
)
def import_from_keepercmd_cmd(
    run_dir: Path,
    output: Path | None,
    dry_run: bool,
    auto_approve: bool,
    skip_audit_verify: bool,
    skip_sha256: bool,
    suspect_threshold: int,
    verbose: bool,
    require_output_signature: bool,
    signature_pubkey: Path | None,
    signature_pubkey_keeper_record: str | None,
    commander_config: Path | None,
) -> None:
    """Adopt keeperCMD-migrated records under DSK ownership.

    Reads a keeperCMD run-dir (OUTPUT_CONTRACT.md v1.0), verifies integrity,
    and writes ``keeper_declarative_manager`` ownership markers on paired
    target records via the Commander SDK.

    Only rows with status=paired and a non-empty target_uid are candidates.
    Rows with a pre-existing marker are flagged as suspect.

    \b
    Exit codes:
      0 = adoption complete (or dry-run summary shown)
      1 = run-dir invalid or unexpected error
      5 = audit chain corrupt or suspect-threshold exceeded
    """
    console = Console()
    log_event(
        _LOG,
        "keepercmd_import.start",
        run_dir=str(run_dir),
        dry_run=dry_run,
        skip_audit_verify=skip_audit_verify,
        skip_sha256=skip_sha256,
        require_output_signature=require_output_signature,
    )

    if commander_config is not None:
        try:
            _validate_commander_config(Path(commander_config))
        except ImportError as e:
            raise click.BadParameter(
                str(e),
                param_hint="--commander-config",
            ) from e

    contract_checked = False
    if require_output_signature:
        _verify_output_signature(
            run_dir,
            console,
            signature_pubkey=signature_pubkey,
            signature_pubkey_keeper_record=signature_pubkey_keeper_record,
            verbose=verbose,
        )
        if not _verify_signed_inventory_hash(run_dir, console):
            sys.exit(EXIT_CAPABILITY)
        try:
            _check_contract_version(run_dir, console)
        except ImportError as exc:
            console.print(f"[red]error:[/] {exc}")
            sys.exit(EXIT_GENERIC)
        contract_checked = True

    manifest_csv = run_dir / "manifest.csv"
    if not manifest_csv.exists():
        console.print(
            f"[red]error:[/] {run_dir} does not contain manifest.csv — not a keeperCMD run-dir",
            highlight=False,
        )
        sys.exit(EXIT_GENERIC)

    audit_log = run_dir / "audit.log"
    if not skip_audit_verify:
        if not audit_log.exists():
            console.print(
                "[yellow]warn:[/] audit.log not found — "
                "pass --skip-audit-verify to suppress this check"
            )
            sys.exit(EXIT_CAPABILITY)
        try:
            _verify_audit_log(audit_log)
        except AuditChainCorrupt as exc:
            console.print(f"[red]audit chain corrupt:[/] {exc}")
            sys.exit(EXIT_CAPABILITY)
        except ImportError as exc:
            console.print(f"[red]error:[/] {exc}")
            sys.exit(EXIT_GENERIC)
        if verbose:
            console.print("[green]audit.log:[/] chain verified")
        log_event(_LOG, "keepercmd_import.audit_verified", run_dir=str(run_dir))

    if not skip_sha256:
        if not _verify_manifest_csv_sidecar(run_dir, console, verbose):
            sys.exit(EXIT_CAPABILITY)
        if not _verify_sha256sums(run_dir, console, verbose):
            sys.exit(EXIT_CAPABILITY)
        log_event(_LOG, "keepercmd_import.sha256_verified", run_dir=str(run_dir))

    if not contract_checked:
        try:
            _check_contract_version(run_dir, console)
        except ImportError as exc:
            console.print(f"[red]error:[/] {exc}")
            sys.exit(EXIT_GENERIC)

    try:
        manifest_rows = _parse_manifest_csv(manifest_csv)
    except (OSError, csv.Error, ImportError) as exc:
        console.print(f"[red]error:[/] cannot read manifest.csv: {type(exc).__name__}")
        sys.exit(EXIT_GENERIC)

    records_export_dir = _records_export_dir(run_dir)
    try:
        paired, unpaired_count, skipped_count = _collect_rows(
            manifest_rows,
            records_export_dir,
            verbose,
            console,
            suspect_threshold,
        )
    except ImportError as exc:
        console.print(f"[red]error:[/] {exc}")
        sys.exit(EXIT_GENERIC)

    suspect_rows = [r for r in paired if r.suspect]
    suspect_count = len(suspect_rows)
    clean_paired = [r for r in paired if not r.suspect]

    table = Table(show_header=True, header_style="bold")
    table.add_column("Category")
    table.add_column("Count", justify="right")
    table.add_row("paired (adoption candidates)", str(len(clean_paired)))
    table.add_row("[yellow]suspect (pre-existing marker)[/]", str(suspect_count))
    table.add_row("unpaired / ambiguous", str(unpaired_count))
    table.add_row("skipped", str(skipped_count))
    console.print(table)
    log_event(
        _LOG,
        "keepercmd_import.rows_collected",
        paired=len(clean_paired),
        suspect=suspect_count,
        unpaired=unpaired_count,
        skipped=skipped_count,
    )

    if suspect_count > suspect_threshold:
        console.print(
            f"[red]abort:[/] {suspect_count} suspect row(s) exceeds threshold {suspect_threshold}. "
            f"Inspect {records_export_dir.name}/ for pre-existing ownership markers before proceeding."
        )
        sys.exit(EXIT_CAPABILITY)

    if not clean_paired:
        console.print("no paired records to adopt.")
        sys.exit(EXIT_OK)

    manifest_name = run_dir.name

    if dry_run:
        console.print(f"[dim]dry-run:[/] {len(clean_paired)} record(s) would be adopted")
        if output:
            content = _build_manifest_yaml(clean_paired, manifest_name, commander_config)
            if not _write_output_manifest(output, content, console):
                sys.exit(EXIT_GENERIC)
            console.print(f"manifest YAML written to {output}")
        elif verbose:
            console.print(_build_manifest_yaml(clean_paired, manifest_name, commander_config))
        log_event(_LOG, "keepercmd_import.dry_run_complete", candidates=len(clean_paired))
        sys.exit(EXIT_OK)

    if not auto_approve:
        click.confirm(
            f"Adopt {len(clean_paired)} record(s) by writing ownership markers?",
            abort=True,
        )

    outcomes = _write_markers(clean_paired, manifest_name, console, verbose)

    adopted = sum(1 for o in outcomes if o["status"] == "adopted")
    errors = sum(1 for o in outcomes if o["status"] == "error")

    console.print(f"[green]done:[/] {adopted} adopted, {errors} error(s)")
    log_event(_LOG, "keepercmd_import.complete", adopted=adopted, errors=errors)

    if output:
        content = _build_manifest_yaml(clean_paired, manifest_name, commander_config)
        if not _write_output_manifest(output, content, console):
            sys.exit(EXIT_GENERIC)
        console.print(f"manifest YAML written to {output}")

    if errors:
        sys.exit(EXIT_GENERIC)
    sys.exit(EXIT_OK)
