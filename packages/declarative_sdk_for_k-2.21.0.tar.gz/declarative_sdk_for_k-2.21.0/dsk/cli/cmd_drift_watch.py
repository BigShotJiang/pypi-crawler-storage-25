"""CLI command: dsk drift-watch — autonomous PAM drift detection daemon.

Preview gate (env contract):
    ``DSK_PREVIEW`` is read as a string; the command runs only when this value
    contains the substring ``drift-watch`` (see ``_PREVIEW_KEY``). Examples that
    **enable**: ``DSK_PREVIEW=drift-watch``, ``DSK_PREVIEW=foo,drift-watch``.
    Values that **do not** enable: unset, ``DSK_PREVIEW=1``, or any string without
    ``drift-watch``. Generic preview flags alone are insufficient.
"""

from __future__ import annotations

import logging
import os
from typing import TypedDict

import click

_PREVIEW_KEY = "drift-watch"
_PREVIEW_GATE_ERROR = "drift-watch is preview-gated; set DSK_PREVIEW=drift-watch to enable"


class _WatchConfigKwargs(TypedDict):
    manifest_paths: list[str]
    poll_interval_seconds: int
    github_repo: str | None
    github_token: str | None
    pr_base_branch: str
    dry_run: bool
    slack_webhook_url: str | None
    slack_channel: str | None
    servicenow_instance: str | None
    servicenow_api_key: str | None


def _preview_enabled(value: str | None) -> bool:
    return _PREVIEW_KEY in (value or "")


def _logging_level(verbose: bool) -> int:
    return logging.DEBUG if verbose else logging.INFO


def _watch_config_kwargs(
    *,
    manifest_paths: tuple[str, ...],
    interval: int,
    github_repo: str | None,
    github_token: str | None,
    pr_base: str,
    dry_run: bool,
    slack_webhook: str | None,
    slack_channel: str | None,
    servicenow_instance: str | None,
    servicenow_api_key: str | None,
) -> _WatchConfigKwargs:
    return {
        "manifest_paths": list(manifest_paths),
        "poll_interval_seconds": interval,
        "github_repo": github_repo,
        "github_token": github_token,
        "pr_base_branch": pr_base,
        "dry_run": dry_run,
        "slack_webhook_url": slack_webhook,
        "slack_channel": slack_channel,
        "servicenow_instance": servicenow_instance,
        "servicenow_api_key": servicenow_api_key,
    }


@click.command("drift-watch")
@click.argument("manifest_paths", nargs=-1, required=True)
@click.option("--interval", default=300, show_default=True, help="Poll interval in seconds")
@click.option(
    "--github-repo", default=None, envvar="DSK_GITHUB_REPO", help="owner/repo for PR creation"
)
@click.option(
    "--github-token", default=None, envvar="GITHUB_TOKEN", help="GitHub token (envvar preferred)"
)
@click.option("--pr-base", default="main", show_default=True, help="Base branch for drift PRs")
@click.option("--dry-run/--no-dry-run", default=True, show_default=True, help="Disable PR creation")
@click.option(
    "--slack-webhook",
    default=None,
    envvar="DSK_SLACK_WEBHOOK",
    help="Slack incoming webhook URL for drift alerts",
)
@click.option(
    "--slack-channel",
    default=None,
    help="Slack channel override (e.g. #pam-alerts)",
)
@click.option(
    "--servicenow-instance",
    default=None,
    envvar="DSK_SERVICENOW_INSTANCE",
    help="ServiceNow instance (e.g. dev12345.service-now.com)",
)
@click.option(
    "--servicenow-api-key",
    default=None,
    envvar="DSK_SERVICENOW_API_KEY",
    help="ServiceNow API key (format: user:password)",
)
@click.option("--verbose", "-v", is_flag=True, default=False)
def drift_watch_cmd(
    manifest_paths: tuple[str, ...],
    interval: int,
    github_repo: str | None,
    github_token: str | None,
    pr_base: str,
    dry_run: bool,
    slack_webhook: str | None,
    slack_channel: str | None,
    servicenow_instance: str | None,
    servicenow_api_key: str | None,
    verbose: bool,
) -> None:
    """
    Autonomous PAM drift detection daemon.

    Polls MANIFEST_PATHS against the live Keeper tenant and opens GitHub PRs
    when drift is detected. Like Dependabot — but for PAM configuration.

    \b
    Preview gate: ``DSK_PREVIEW`` must contain the substring ``drift-watch`` (not
    merely ``DSK_PREVIEW=1``). See module docstring.
    """
    if not _preview_enabled(os.environ.get("DSK_PREVIEW", "")):
        raise click.ClickException(_PREVIEW_GATE_ERROR)

    logging.basicConfig(
        level=_logging_level(verbose),
        format="%(asctime)s %(levelname)s %(message)s",
    )

    from dsk.daemon.drift_watch import WatchConfig, watch_loop

    cfg = WatchConfig(
        **_watch_config_kwargs(
            manifest_paths=manifest_paths,
            interval=interval,
            github_repo=github_repo,
            github_token=github_token,
            pr_base=pr_base,
            dry_run=dry_run,
            slack_webhook=slack_webhook,
            slack_channel=slack_channel,
            servicenow_instance=servicenow_instance,
            servicenow_api_key=servicenow_api_key,
        )
    )
    watch_loop(cfg)
