"""``dsk scan`` subcommands — surface unmanaged/drift identities."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import click

from dsk.core.errors import (
    CapabilityError,
    ManifestError,
    SchemaError,
    UnsupportedFamilyError,
)
from dsk.core.manifest import load_declarative_manifest
from dsk.core.models_ai_agent import AI_AGENT_FAMILY, AiAgentManifest
from dsk.core.models_nhi import NHI_FAMILY, NhiAgentManifest

# Mirrors ``dsk.cli.main.EXIT_CAPABILITY`` for gated provider features.
EXIT_CAPABILITY = 5


def _iter_yaml_files(root: Path) -> list[Path]:
    found: set[Path] = set()
    for pattern in ("**/*.yaml", "**/*.yml"):
        for path in root.glob(pattern):
            if path.is_file():
                found.add(path)
    return sorted(found)


def _collect_declared_from_manifests(root: Path) -> tuple[list[dict[str, Any]], int, int]:
    """Return declared resource rows, nhi manifest count, ai manifest count."""
    rows: list[dict[str, Any]] = []
    nhi_manifests = 0
    ai_manifests = 0
    for path in _iter_yaml_files(root):
        try:
            typed = load_declarative_manifest(path)
        except (ManifestError, SchemaError, UnsupportedFamilyError, OSError, ValueError, TypeError):
            continue
        if isinstance(typed, NhiAgentManifest):
            nhi_manifests += 1
            for resource in typed.resources:
                rows.append(
                    {
                        "family": NHI_FAMILY,
                        "manifest": str(path),
                        "uid_ref": resource.uid_ref,
                        "name": resource.name,
                    }
                )
        elif isinstance(typed, AiAgentManifest):
            ai_manifests += 1
            for ai_res in typed.resources:
                rows.append(
                    {
                        "family": AI_AGENT_FAMILY,
                        "manifest": str(path),
                        "uid_ref": ai_res.uid_ref,
                        "name": ai_res.name,
                    }
                )
    return rows, nhi_manifests, ai_manifests


def _nhi_drift_payload(
    rows: list[dict[str, Any]], nhi_manifests: int, ai_manifests: int
) -> dict[str, Any]:
    return {
        "declared_nhi_resources": len(rows),
        "manifest_counts": {NHI_FAMILY: nhi_manifests, AI_AGENT_FAMILY: ai_manifests},
        "resources": rows,
    }


def _nhi_drift_text_lines(declared_count: int, nhi_manifests: int, ai_manifests: int) -> list[str]:
    return [
        f"Declared NHI resources: {declared_count}",
        (
            f"Families scanned: {NHI_FAMILY} ({nhi_manifests} manifests), "
            f"{AI_AGENT_FAMILY} ({ai_manifests} manifests)"
        ),
        "",
        "To detect unmanaged vault NHIs, run with --live (requires Commander session).",
    ]


@click.group("scan")
def scan_cmd() -> None:
    """Surface unmanaged identities and configuration drift."""


@scan_cmd.command("nhi-drift")
@click.option(
    "--manifests",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    default=".",
    show_default=True,
    help="Directory to scan for NHI and AI capability manifests.",
)
@click.option(
    "--live",
    is_flag=True,
    default=False,
    help="Connect to live vault (requires KEEPER_SDK_LOGIN_HELPER).",
)
@click.option(
    "--format",
    "output_format",
    default="text",
    type=click.Choice(["text", "json"]),
    show_default=True,
)
def nhi_drift_cmd(manifests: Path, live: bool, output_format: str) -> None:
    """Detect NHI and AI capability resources declared in manifests vs live vault.

    Offline: reports declared resources from manifest files.
    Live: cross-references against vault records to surface unmanaged NHIs.

    Addresses NHI governance crisis: 250K+ unmanaged NHIs per enterprise
    (2026 NHI Reality Report; Gartner Top 6 Cybersecurity Trend 2026).
    """
    if live:
        exc = CapabilityError(
            reason=(
                "Live NHI drift scan requires NHI capability vault enumeration in Commander "
                "(upstream gap; planned provider support)"
            ),
            next_action=(
                "use offline manifest scan without --live, or track the NHI capability GA "
                "provider before enabling live unmanaged-NHI detection"
            ),
        )
        click.echo(str(exc), err=True)
        sys.exit(EXIT_CAPABILITY)

    root = manifests.expanduser().resolve()
    rows, x_nhi, y_ai = _collect_declared_from_manifests(root)
    n_declared = len(rows)

    if output_format == "json":
        click.echo(json.dumps(_nhi_drift_payload(rows, x_nhi, y_ai), indent=2))
        return

    for line in _nhi_drift_text_lines(n_declared, x_nhi, y_ai):
        click.echo(line)
