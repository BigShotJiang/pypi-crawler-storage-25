"""Helpers for keeperCMD audit.log SHA256-chain verification and explanation."""

from __future__ import annotations

import errno
import hashlib
import json
import os
import stat
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dsk._obs import get_logger, log_event

DEFAULT_MAX_ARTIFACT_BYTES = 100 * 1024 * 1024
_GENESIS_ZERO_HASH = "0" * 64
_LOG = get_logger(__name__)


class AuditChainCorrupt(Exception):
    """Raised when the keeperCMD audit.log hash chain fails verification."""


@dataclass(frozen=True)
class AuditLine:
    """One non-blank audit.log line and its verification result."""

    line_no: int
    ok: bool
    operation: str
    prev_hash: str
    expected_prev_hash: str
    signature: str
    expected_signature: str
    line_hash: str
    timestamp: str | None = None
    error: str | None = None
    raw_context: str = ""


@dataclass(frozen=True)
class AuditExplainResult:
    """Structured forensic view of an audit.log chain."""

    path: Path
    entries: tuple[AuditLine, ...]
    failures: tuple[AuditLine, ...]
    operation_counts: Counter[str] = field(default_factory=Counter)
    suspicious_patterns: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.failures

    @property
    def time_span(self) -> tuple[str | None, str | None]:
        timestamps = [entry.timestamp for entry in self.entries if entry.timestamp]
        if not timestamps:
            return None, None
        return timestamps[0], timestamps[-1]


def _max_artifact_bytes() -> int:
    raw = os.environ.get("DSK_MAX_ARTIFACT_BYTES")
    if raw is None:
        return DEFAULT_MAX_ARTIFACT_BYTES
    try:
        value = int(raw)
    except ValueError as exc:
        raise AuditChainCorrupt("DSK_MAX_ARTIFACT_BYTES must be an integer") from exc
    if value <= 0:
        raise AuditChainCorrupt("DSK_MAX_ARTIFACT_BYTES must be greater than 0")
    return value


def _read_audit_text(path: Path) -> str:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags)
    except OSError as exc:
        if exc.errno == errno.ELOOP:
            raise AuditChainCorrupt(
                "audit.log is a symlink; refusing to read input artifact"
            ) from exc
        raise AuditChainCorrupt(f"audit.log unreadable: {type(exc).__name__}") from exc

    max_bytes = _max_artifact_bytes()
    try:
        with os.fdopen(fd, "rb") as fh:
            st = os.fstat(fh.fileno())
            if stat.S_ISLNK(st.st_mode):
                raise AuditChainCorrupt("audit.log is a symlink; refusing to read input artifact")
            if not stat.S_ISREG(st.st_mode):
                raise AuditChainCorrupt("audit.log is not a regular file")
            if st.st_size > max_bytes:
                raise AuditChainCorrupt(
                    f"audit.log exceeding DSK_MAX_ARTIFACT_BYTES={max_bytes}; "
                    f"size={st.st_size} bytes"
                )
            data = fh.read(max_bytes + 1)
    except OSError as exc:
        raise AuditChainCorrupt(f"audit.log unreadable: {type(exc).__name__}") from exc
    if len(data) > max_bytes:
        raise AuditChainCorrupt(f"audit.log exceeds DSK_MAX_ARTIFACT_BYTES={max_bytes}")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise AuditChainCorrupt("audit.log is not valid UTF-8") from exc


def _operation_name(event: dict[str, Any]) -> str:
    for key in ("event", "operation", "subcommand", "command", "type", "action"):
        value = event.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return "unknown"


def _timestamp(event: dict[str, Any]) -> str | None:
    for key in ("timestamp", "time", "ts", "created_at"):
        value = event.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _prev_hash_matches(
    line_no: int,
    prev_hash: str,
    expected_prev_hash: str,
    expected_prev_signature: str,
) -> bool:
    if line_no == 1:
        # Genesis convention varies; both empty string (legacy) and zero-hash
        # (cryptographic standard, used by D1+) are accepted.
        return prev_hash in {"", _GENESIS_ZERO_HASH}
    return prev_hash in {expected_prev_hash, expected_prev_signature}


def _event_signature(event: dict[str, Any], *, compact: bool) -> str:
    # keeperCMD canonical signatures use compact JSON separators; older DSK
    # fixtures used json.dumps defaults. Verification accepts both encodings.
    kwargs: dict[str, Any] = {"sort_keys": True}
    if compact:
        kwargs["separators"] = (",", ":")
    return hashlib.sha256(json.dumps(event, **kwargs).encode()).hexdigest()


def _short_context(line: str, *, width: int = 120) -> str:
    compact = " ".join(line.split())
    if len(compact) <= width:
        return compact
    return compact[: width - 3] + "..."


def explain_audit_log(log_path: Path) -> AuditExplainResult:
    """Return line-by-line chain verification context for an audit log."""

    log_event(_LOG, "audit.explain.start", audit_log=str(log_path))
    text = _read_audit_text(log_path)
    entries: list[AuditLine] = []
    failures: list[AuditLine] = []
    counts: Counter[str] = Counter()
    suspicious: list[str] = []
    prev_hash = ""
    # keeperCMD links prev_hash to the previous event signature; older DSK
    # fixtures linked to the previous raw line hash. Accept both chain shapes.
    prev_signature = ""

    for index, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue

        expected_prev = prev_hash
        actual_line_hash = hashlib.sha256(line.encode()).hexdigest()
        operation = "malformed"
        signature = ""
        expected_signature = ""
        prev_value = ""
        timestamp: str | None = None
        error: str | None = None

        try:
            event = json.loads(line)
        except json.JSONDecodeError as exc:
            error = f"audit.log line {index}: malformed JSON - {type(exc).__name__}"
        else:
            if not isinstance(event, dict):
                error = f"audit.log line {index}: JSON value is not an object"
            else:
                operation = _operation_name(event)
                timestamp = _timestamp(event)
                signature_value = event.get("signature")
                signature = signature_value if isinstance(signature_value, str) else ""
                prev_raw = event.get("prev_hash", "")
                prev_value = prev_raw if isinstance(prev_raw, str) else str(prev_raw)
                check_event = {k: v for k, v in event.items() if k != "signature"}
                expected_signature = _event_signature(check_event, compact=True)
                legacy_signature = _event_signature(check_event, compact=False)
                if not signature:
                    error = f"audit.log line {index}: missing signature field"
                elif not _prev_hash_matches(index, prev_value, expected_prev, prev_signature):
                    error = (
                        f"audit.log line {index}: prev_hash mismatch "
                        f"(expected {expected_prev!r}, got {prev_value!r})"
                    )
                elif signature not in {expected_signature, legacy_signature}:
                    error = f"audit.log line {index}: signature mismatch"
                if index > 1 and prev_value == "":
                    suspicious.append(f"line {index}: non-genesis row resets prev_hash")

        entry = AuditLine(
            line_no=index,
            ok=error is None,
            operation=operation,
            prev_hash=prev_value,
            expected_prev_hash=expected_prev,
            signature=signature,
            expected_signature=expected_signature,
            line_hash=actual_line_hash,
            timestamp=timestamp,
            error=error,
            raw_context=_short_context(line),
        )
        entries.append(entry)
        counts[operation] += 1
        if error:
            failures.append(entry)
            suspicious.append(error)
        prev_hash = actual_line_hash
        prev_signature = signature

    result = AuditExplainResult(
        path=log_path,
        entries=tuple(entries),
        failures=tuple(failures),
        operation_counts=counts,
        suspicious_patterns=tuple(dict.fromkeys(suspicious)),
    )
    log_event(
        _LOG,
        "audit.explain.complete",
        audit_log=str(log_path),
        entries=len(result.entries),
        failures=len(result.failures),
    )
    return result


def verify_audit_log(log_path: Path) -> None:
    """Raise AuditChainCorrupt on the first chain verification failure."""

    result = explain_audit_log(log_path)
    if not result.entries:
        # UTF-8 control bytes can decode to a non-empty file with no JSON lines;
        # that is corrupt evidence, not an empty successful audit chain.
        log_event(_LOG, "audit.verify.failure", audit_log=str(log_path), error="empty audit.log")
        raise AuditChainCorrupt("audit.log contains no verifiable entries")
    if result.failures:
        failure = result.failures[0]
        log_event(
            _LOG,
            "audit.verify.failure",
            audit_log=str(log_path),
            line_no=failure.line_no,
            error=failure.error or "",
        )
        raise AuditChainCorrupt(failure.error or f"audit.log line {failure.line_no}: invalid")
    log_event(_LOG, "audit.verify.complete", audit_log=str(log_path), entries=len(result.entries))
