"""``dsk shim-info`` discovery command for keeper-migrate embedding."""

from __future__ import annotations

import click

from dsk.shim import shim_info_json

EXIT_OK = 0
EXIT_FORMAT = 2


@click.command("shim-info")
@click.option(
    "--output-contract-version",
    default=None,
    help="Negotiate a specific OUTPUT_CONTRACT version with the shim descriptor.",
)
def shim_info_cmd(output_contract_version: str | None) -> None:
    """Emit the DSK shim descriptor as JSON."""

    try:
        click.echo(shim_info_json(output_contract_version), nl=False)
    except ValueError as exc:
        click.echo(f"error: {exc}", err=True)
        raise SystemExit(EXIT_FORMAT) from exc


__all__ = ["shim_info_cmd"]
