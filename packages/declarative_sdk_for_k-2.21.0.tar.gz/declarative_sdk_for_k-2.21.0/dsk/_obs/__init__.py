"""Small structured-logging helpers for DSK."""

from __future__ import annotations

import contextvars
import json
import logging
import os
import re
import sys
import time
import uuid
from collections.abc import Mapping
from typing import Any

_CORRELATION_ID: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "dsk_correlation_id", default=None
)

_RESERVED_LOG_RECORD_KEYS = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__.keys())
_SECRET_KEY_RE = re.compile(
    r"(token|password|secret|api[_-]?key|private[_-]?key|authorization|bearer)", re.I
)
_SECRET_TEXT_PATTERNS = (
    re.compile(r"Bearer\s+[A-Za-z0-9._~+/=-]+", re.I),
    re.compile(
        r"(?i)(api[_-]?key|password|token|secret(?:[_-]?key)?|private[_-]?key)"
        r"[\"']?\s*[:=]\s*[\"']?[^,\s]+"
    ),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S),
    re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{16,}\b"),
)
_REDACTED = "<redacted>"


class JSONFormatter(logging.Formatter):
    """Format log records as compact JSON with correlation IDs."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": _redact_text(record.getMessage()),
            "correlation_id": getattr(record, "correlation_id", None) or get_correlation_id(),
        }
        event = getattr(record, "event", None)
        if isinstance(event, str) and event:
            payload["event"] = _redact_text(event)
        for key, value in record.__dict__.items():
            if key in _RESERVED_LOG_RECORD_KEYS or key in payload:
                continue
            payload[key] = _json_safe(value, key=key)
        if record.exc_info:
            payload["exc_info"] = _redact_text(self.formatException(record.exc_info))
        return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def configure_json_logging(*, level: int | None = None) -> None:
    """Install a stderr JSON handler when `DSK_JSON_LOGS=1` is set."""

    if os.environ.get("DSK_JSON_LOGS") not in {"1", "true", "TRUE", "yes", "on"}:
        return
    root = logging.getLogger("dsk")
    if any(getattr(handler, "_dsk_json_handler", False) for handler in root.handlers):
        return
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(JSONFormatter())
    handler._dsk_json_handler = True  # type: ignore[attr-defined]
    root.addHandler(handler)
    root.setLevel(level if level is not None else _log_level_from_env())


def get_logger(name: str | None = None) -> logging.Logger:
    """Return a DSK logger without changing application output behavior."""

    return logging.getLogger(name or "dsk")


def get_correlation_id() -> str:
    current = _CORRELATION_ID.get()
    if current:
        return current
    generated = os.environ.get("DSK_CORRELATION_ID") or uuid.uuid4().hex
    _CORRELATION_ID.set(generated)
    return generated


def set_correlation_id(value: str | None = None) -> str:
    correlation_id = value or os.environ.get("DSK_CORRELATION_ID") or uuid.uuid4().hex
    _CORRELATION_ID.set(correlation_id)
    return correlation_id


def log_event(logger: logging.Logger, event: str, **fields: Any) -> None:
    """Emit one structured event on an existing logger."""

    extra = {"event": event, "correlation_id": get_correlation_id(), **fields}
    logger.info(event, extra=extra)


def _log_level_from_env() -> int:
    raw = os.environ.get("DSK_LOG_LEVEL", "INFO").strip().upper()
    level = logging.getLevelName(raw)
    return level if isinstance(level, int) else logging.INFO


def _json_safe(value: Any, *, key: str | None = None) -> Any:
    if key and _SECRET_KEY_RE.search(key):
        return _REDACTED
    if isinstance(value, (str, int, float, bool)) or value is None:
        return _redact_text(value) if isinstance(value, str) else value
    if isinstance(value, Mapping):
        value = _redact_structured(value)
        return {
            str(item_key): _json_safe(item, key=str(item_key)) for item_key, item in value.items()
        }
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(item) for item in value]
    return _redact_text(repr(value))


def _redact_structured(value: Any) -> Any:
    try:
        from dsk.core.redact import redact
    except ImportError:  # pragma: no cover - defensive import isolation
        return value
    return redact(value)


def _redact_text(value: str) -> str:
    redacted = value
    for pattern in _SECRET_TEXT_PATTERNS:
        redacted = pattern.sub(_REDACTED, redacted)
    return redacted
