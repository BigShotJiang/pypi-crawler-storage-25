"""Keeper Secrets Manager (KSM) consumer for SDK-side credential pulls.

See :mod:`dsk.secrets` for the package-level rationale.

Public surface
--------------

- :class:`KsmSecretStore` — thin façade over
  ``keeper_secrets_manager_core.SecretsManager`` with field-value caching
  scoped to a single store instance. Callers that need a long-lived
  cache should hold the store; callers that need fresh reads after a
  rotation should construct a new store.

- :class:`KsmLoginCreds` — the three values the Commander login flow
  needs, returned by :func:`load_keeper_login_from_ksm`.

- :func:`load_keeper_login_from_ksm` — the convenience wrapper used by
  :class:`dsk.auth.KsmLoginHelper`. Lives here so SDK callers
  building their own login flows can reuse it without depending on
  ``dsk.auth``.

Configuration
-------------

The store accepts an explicit ``config_path``; otherwise it walks the
following list (first usable wins):

1. ``$KEEPER_SDK_KSM_CONFIG``
2. ``$KSM_CONFIG`` (common Keeper tooling override)
3. ``~/.keeper/ksm-config.json``

Different KSM applications see different shared-folder grants; the
caller is expected to know which application owns the records they want
to read. ``KsmSecretStore.config_path`` exposes the resolved choice for
auditing / logging.

Field-name conventions
----------------------

The Commander admin-login record produced by the Keeper Web UI carries
typed fields ``login`` (email), ``password``, and ``oneTimeCode``
(``otpauth://`` URI). :func:`load_keeper_login_from_ksm` defaults to
those names but accepts overrides via the ``KEEPER_SDK_KSM_*_FIELD``
env vars listed below — useful when the operator wants to pin a
different record schema (e.g. a ``custom`` field labelled ``svc-admin-totp``).

| Env var                                | Default        |
|----------------------------------------|----------------|
| ``KEEPER_SDK_KSM_LOGIN_FIELD``         | ``login``      |
| ``KEEPER_SDK_KSM_PASSWORD_FIELD``      | ``password``   |
| ``KEEPER_SDK_KSM_TOTP_FIELD``          | ``oneTimeCode``|
| ``KEEPER_SDK_KSM_CREDS_RECORD_UID``    | (no default)   |

The TOTP value is normalised to a base32 secret (the ``secret=``
parameter of an ``otpauth://`` URI) so callers can drop it straight into
``pyotp.TOTP``. If the field already holds a bare base32 string the
parser passes it through; the heuristic only converts ``otpauth://``
inputs.
"""

from __future__ import annotations

import os
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from dsk.core.errors import CapabilityError
from dsk.core.field_names import field_name_matches

KSM_CONFIG_ENV = "KEEPER_SDK_KSM_CONFIG"
"""Primary env var an operator sets to point the SDK at a KSM app config.

Independent from ``KSM_CONFIG`` so SDK consumers can co-exist with the
other Keeper tooling without fighting over a shared variable. If both are
unset the auto-discovery probes fire.
"""

KSM_TOTP_ENV_PARSE_FALLBACK = "KEEPER_SDK_KSM_ALLOW_OTPAUTH_PASSTHROUGH"
"""When set to a truthy value, :func:`load_keeper_login_from_ksm` will
return the raw ``otpauth://`` URI for callers that prefer to parse it
themselves. Default behaviour (env unset / ``"0"``) extracts the
``secret`` query param so the value drops straight into ``pyotp.TOTP``.
"""

DEFAULT_CONFIG_PROBES: tuple[Path, ...] = (Path.home() / ".keeper" / "ksm-config.json",)
"""Standard locations checked when no explicit ``config_path`` is given.

Production adopters should drop their KSM client config under
``~/.keeper/`` (the same convention Commander uses) rather than relying on
a path the SDK guesses. Override via ``KEEPER_SDK_KSM_CONFIG`` for
ad-hoc runs.
"""

DEFAULT_CLIENT_FIRST_ACCESS_EXPIRES_IN_MIN = 60
"""Commander ``secrets-manager client add`` default first-access timeout."""


def _resolve_config_path(config_path: str | os.PathLike[str] | None) -> Path:
    if config_path:
        candidate = Path(config_path).expanduser()
        if not candidate.is_file():
            raise CapabilityError(
                reason=f"KSM config not found at {candidate}",
                next_action=(
                    f"create the KSM client config at {candidate} or pass a "
                    "different config_path / set KEEPER_SDK_KSM_CONFIG"
                ),
            )
        return candidate
    for env_name in (KSM_CONFIG_ENV, "KSM_CONFIG"):
        env_val = os.environ.get(env_name)
        if not env_val:
            continue
        candidate = Path(env_val).expanduser()
        if candidate.is_file():
            return candidate
    for probe in DEFAULT_CONFIG_PROBES:
        if probe.is_file():
            return probe
    raise CapabilityError(
        reason="no KSM client config found",
        next_action=(
            f"set {KSM_CONFIG_ENV} to your ksm-config.json path, or place the "
            f"file at one of: {', '.join(str(p) for p in DEFAULT_CONFIG_PROBES)}"
        ),
    )


def _import_ksm_core() -> Any:
    """Import ``keeper_secrets_manager_core`` lazily.

    Raises :class:`CapabilityError` with a copy-pasteable next-action when
    the optional extra is missing — keeps the rest of the SDK importable
    without the heavy KSM dep.
    """
    try:
        import keeper_secrets_manager_core
        from keeper_secrets_manager_core.storage import (
            FileKeyValueStorage,
        )
    except ImportError as exc:
        raise CapabilityError(
            reason=f"keeper_secrets_manager_core is required for KSM-backed access: {exc}",
            next_action="pip install 'declarative-sdk-for-k[ksm]' (or pip install keeper-secrets-manager-core>=17)",
        ) from exc
    return keeper_secrets_manager_core, FileKeyValueStorage


_OTPAUTH_URI = re.compile(r"^otpauth://", re.IGNORECASE)


def _coerce_totp_secret(value: str) -> str:
    """Return a base32 TOTP secret, parsing ``otpauth://`` URIs if needed.

    Pass-through behaviour is suppressed when
    ``KEEPER_SDK_KSM_ALLOW_OTPAUTH_PASSTHROUGH`` is truthy — useful for
    callers that prefer to consume the URI shape directly (e.g. mobile
    enrolment flows).
    """
    if not isinstance(value, str) or not value:
        raise CapabilityError(
            reason="KSM TOTP field is empty",
            next_action="populate the record's oneTimeCode field with a TOTP URI or base32 secret",
        )
    if _is_truthy(os.environ.get(KSM_TOTP_ENV_PARSE_FALLBACK, "")):
        return value
    if not _OTPAUTH_URI.match(value):
        return value
    qs = parse_qs(urlparse(value).query)
    secrets = qs.get("secret") or []
    if not secrets:
        raise CapabilityError(
            reason="KSM TOTP otpauth:// URI has no `secret` query parameter",
            next_action="re-enrol the TOTP factor or store the base32 secret directly in the field",
        )
    return secrets[0]


def _is_truthy(s: str | None) -> bool:
    return (s or "").strip().lower() in {"1", "true", "yes", "on"}


def ksm_client_add_kwargs(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Return sanitized kwargs for ``KSMCommand.add_client`` from a plan payload.

    The Commander API names are historical (``first_access_expire_on``), while
    manifests/plans prefer explicit minute-based names. This helper keeps the
    conversion in one place and raises provider-grade errors for invalid values.
    """
    first_access = _positive_int(
        _first_present(
            payload,
            "first_access_expires_in_min",
            "first_access_expire_in_min",
            "first_access_expire_on",
        ),
        default=DEFAULT_CLIENT_FIRST_ACCESS_EXPIRES_IN_MIN,
        field="first_access_expires_in_min",
    )
    if first_access > 1440:
        raise CapabilityError(
            reason="KSM client first-access expiry cannot exceed 1440 minutes",
            next_action="set first_access_expires_in_min to a value from 1 to 1440",
        )

    return {
        "count": _positive_int(payload.get("count"), default=1, field="count"),
        "unlock_ip": _coerce_payload_bool(
            _first_present(payload, "unlock_ip", "unlockIp"),
            default=False,
        ),
        "first_access_expire_on": first_access,
        "access_expire_in_min": _optional_positive_int(
            _first_present(payload, "access_expires_in_min", "access_expire_in_min"),
            field="access_expires_in_min",
        ),
        "client_name": _optional_str(_first_present(payload, "client_name", "name")),
        "config_init": _optional_str(payload.get("config_init")),
        "client_type": _positive_int(payload.get("client_type"), default=1, field="client_type"),
    }


def ksm_client_token_summary(tokens: Any) -> dict[str, int | bool]:
    """Summarise Commander client-add output without returning token material."""
    if tokens is None:
        rows: list[Any] = []
    elif isinstance(tokens, Sequence) and not isinstance(tokens, str | bytes | bytearray):
        rows = list(tokens)
    else:
        rows = [tokens]

    one_time = 0
    configs = 0
    devices = 0
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        one_time += int(bool(row.get("oneTimeToken")))
        configs += int(bool(row.get("config")))
        devices += int(bool(row.get("deviceToken")))
    return {
        "tokens_created": len(rows),
        "one_time_tokens_redacted": one_time,
        "configs_redacted": configs,
        "device_tokens_redacted": devices,
        "redacted": bool(rows),
    }


def _first_present(payload: Mapping[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in payload and payload[key] is not None:
            return payload[key]
    return None


def _positive_int(value: Any, *, default: int, field: str) -> int:
    if value is None or value == "":
        value = default
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise CapabilityError(
            reason=f"KSM client field {field!r} must be an integer",
            next_action=f"set {field} to a positive integer",
        ) from exc
    if parsed < 1:
        raise CapabilityError(
            reason=f"KSM client field {field!r} must be positive",
            next_action=f"set {field} to a positive integer",
        )
    return parsed


def _optional_positive_int(value: Any, *, field: str) -> int | None:
    if value is None or value == "":
        return None
    return _positive_int(value, default=1, field=field)


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _coerce_payload_bool(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return _is_truthy(value)
    return bool(value)


@dataclass(frozen=True)
class KsmLoginCreds:
    """Frozen credential bundle returned by :func:`load_keeper_login_from_ksm`.

    Mirrors the dict shape :class:`dsk.auth.LoginHelper` produces
    so the result can be unpacked directly into
    :meth:`dsk.auth.LoginHelper.keeper_login` callsites.
    """

    email: str
    password: str
    totp_secret: str
    config_path: str = ""
    server: str = ""

    def as_helper_dict(self) -> dict[str, str]:
        """Return the dict form expected by ``LoginHelper.load_keeper_creds``."""
        out = {
            "email": self.email,
            "password": self.password,
            "totp_secret": self.totp_secret,
            "config_path": self.config_path,
        }
        if self.server:
            out["server"] = self.server
        return out


class KsmSecretStore:
    """Lazily-initialised reader for a single KSM application config.

    The store is intentionally minimal — it does NOT cache decrypted
    values across instances and does NOT attempt to refresh on schedule.
    Callers that want long-lived caching wrap it; callers that want
    fresh reads construct a new store. This keeps the SDK from holding
    decrypted credentials in process memory longer than the caller's
    apply / plan loop.

    Example::

        store = KsmSecretStore()  # auto-discovers config
        password = store.field("<record-uid>", "password")

    Multi-app deployments::

        lab = KsmSecretStore(config_path="/path/to/lab/ksm-config.json")
        prod = KsmSecretStore(config_path="/path/to/prod/ksm-config.json")
    """

    def __init__(
        self,
        *,
        config_path: str | os.PathLike[str] | None = None,
    ) -> None:
        self._explicit_config_path = config_path
        self._client: Any | None = None
        self._resolved_config_path: Path | None = None

    @property
    def config_path(self) -> Path:
        """Resolved config path (lazy; raises until first access)."""
        if self._resolved_config_path is None:
            self._resolved_config_path = _resolve_config_path(self._explicit_config_path)
        return self._resolved_config_path

    def client(self) -> Any:
        """Return the cached :class:`SecretsManager` instance.

        Construction is deferred to first use so importing the SDK
        without setting up KSM does not crash.
        """
        if self._client is None:
            ksm_core, FileKeyValueStorage = _import_ksm_core()
            self._client = ksm_core.SecretsManager(
                config=FileKeyValueStorage(str(self.config_path))
            )
        return self._client

    def get_record(self, uid: str) -> Any:
        """Return the raw KSM record object for ``uid``.

        Raises :class:`CapabilityError` (rather than ``LookupError``) so
        the SDK's CLI surface can map it to exit-code 5 with a concrete
        next-action — most "no record" errors are config-mismatch bugs
        the operator can fix in 30 seconds.
        """
        records = self.client().get_secrets([uid])
        if not records:
            raise CapabilityError(
                reason=(
                    f"KSM record {uid[:6]}... not visible to client at {self.config_path} "
                    "(wrong KSM application or no shared-folder grant)"
                ),
                next_action=(
                    "verify the KSM application has the record's shared folder, or "
                    "point KEEPER_SDK_KSM_CONFIG at the application that does"
                ),
            )
        return records[0]

    def field(
        self,
        uid: str,
        field_type: str,
        *,
        label: str | None = None,
        single: bool = True,
    ) -> Any:
        """Return one field value from a record.

        ``field_type`` matches Keeper's typed-field names (``login``,
        ``password``, ``oneTimeCode``, ``url`` ...). When multiple
        fields share a type, pass ``label`` to disambiguate against
        either the typed or the custom block.
        """
        record = self.get_record(uid)
        if label is None:
            return record.field(field_type, single=single)
        for source in (record.dict.get("fields", []), record.dict.get("custom", [])):
            for entry in source or []:
                if field_name_matches(entry.get("type"), field_type) and field_name_matches(
                    entry.get("label"), label
                ):
                    values = entry.get("value") or []
                    return (values[0] if values else None) if single else values
        raise CapabilityError(
            reason=(f"KSM record {uid[:6]}... has no field type={field_type!r} label={label!r}"),
            next_action=(
                "verify the field exists on the record (Keeper Web UI → record → fields), "
                "or drop the label to take the first matching typed field"
            ),
        )

    def describe(self, uid: str) -> dict[str, Any]:
        """Return shape-only metadata for a record (no values).

        Useful for audit logging or for wiring custom helpers to verify
        a record carries the expected fields before attempting a login.
        """
        record = self.get_record(uid)
        return {
            "uid_prefix": uid[:6] + "..." if len(uid) > 6 else uid,
            "title_prefix": (record.title or "")[:8] + "..." if record.title else "(no title)",
            "fields": [
                {
                    "type": entry.get("type"),
                    "label": entry.get("label") or "",
                    "has_value": bool(entry.get("value")),
                }
                for entry in record.dict.get("fields", [])
            ],
            "custom": [
                {
                    "type": entry.get("type"),
                    "label": entry.get("label") or "",
                    "has_value": bool(entry.get("value")),
                }
                for entry in record.dict.get("custom", [])
            ],
        }


def load_keeper_login_from_ksm(
    record_uid: str,
    *,
    config_path: str | os.PathLike[str] | None = None,
    login_field: str = "login",
    password_field: str = "password",
    totp_field: str = "oneTimeCode",
    server: str | None = None,
    config_path_for_login: str = "",
) -> KsmLoginCreds:
    """Read a Commander admin-login record from KSM.

    ``record_uid`` is the KSM record holding the typed fields
    ``login`` / ``password`` / ``oneTimeCode``. Field names may be
    overridden if the operator stores credentials under custom labels.

    The TOTP value is normalised to a base32 secret unless
    ``KEEPER_SDK_KSM_ALLOW_OTPAUTH_PASSTHROUGH`` is truthy.

    ``config_path_for_login`` and ``server`` are passed through to the
    returned :class:`KsmLoginCreds` so callers can pre-populate the
    Commander config-load path / explicit server (the KSM record
    itself does not own those — they're per-machine).
    """
    store = KsmSecretStore(config_path=config_path)
    email = store.field(record_uid, login_field)
    password = store.field(record_uid, password_field)
    totp_raw = store.field(record_uid, totp_field)

    if not (email and password and totp_raw):
        raise CapabilityError(
            reason=(
                f"KSM record {record_uid[:6]}... missing one of "
                f"{login_field!r} / {password_field!r} / {totp_field!r}"
            ),
            next_action=(
                "populate the record's typed fields via Keeper Web UI, or override "
                "field names via KEEPER_SDK_KSM_LOGIN_FIELD / "
                "KEEPER_SDK_KSM_PASSWORD_FIELD / KEEPER_SDK_KSM_TOTP_FIELD"
            ),
        )

    return KsmLoginCreds(
        email=email,
        password=password,
        totp_secret=_coerce_totp_secret(totp_raw),
        config_path=config_path_for_login,
        server=server or "",
    )
