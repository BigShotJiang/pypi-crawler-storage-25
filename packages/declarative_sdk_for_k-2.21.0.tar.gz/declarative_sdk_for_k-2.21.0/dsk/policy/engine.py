"""
Policy-as-Code engine for DSK — Cedar and OPA integration.

Private preview — not published to public mirror.
Validates DSK manifests against OPA Rego or Cedar policies before apply.
"""

from __future__ import annotations

import json
import subprocess
import tempfile
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any

POLICY_EVAL_TIMEOUT_SECONDS = 30


class PolicyEngine(StrEnum):
    OPA = "opa"
    CEDAR = "cedar"


@dataclass
class PolicyViolation:
    resource_uid_ref: str
    rule: str
    message: str
    severity: str = "error"  # error | warning


@dataclass
class PolicyResult:
    passed: bool
    violations: list[PolicyViolation] = field(default_factory=list)
    engine: PolicyEngine | None = None
    error: str | None = None
    # False when the engine is a stub and no evaluation actually ran.
    # Callers must check this before trusting `passed`.
    evaluated: bool = True


def _manifest_to_opa_input(manifest_data: dict[str, Any]) -> dict[str, Any]:
    """Convert DSK manifest dict to OPA input format."""
    return {"manifest": manifest_data}


def validate_with_opa(
    manifest_data: dict[str, Any],
    policy_path: str,
) -> PolicyResult:
    """
    Validate a DSK manifest against an OPA Rego policy.

    Requires: `opa` binary on PATH.
    Policy must define `deny[msg]` rules.
    Returns PolicyResult with all violations.
    """
    input_data = _manifest_to_opa_input(manifest_data)

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(input_data, f)
        input_file = f.name

    try:
        result = subprocess.run(
            [
                "opa",
                "eval",
                "--data",
                policy_path,
                "--input",
                input_file,
                "--format",
                "json",
                "data.keeper.pam.deny",
            ],
            capture_output=True,
            text=True,
            timeout=POLICY_EVAL_TIMEOUT_SECONDS,
        )
        if result.returncode != 0:
            return PolicyResult(
                passed=False,
                engine=PolicyEngine.OPA,
                error=f"OPA error: {result.stderr[:200]}",
            )
        output = json.loads(result.stdout)
        results = output.get("result", [])
        violations = []
        for r in results:
            expressions = r.get("expressions", [])
            for expr in expressions:
                for msg in expr.get("value") or []:
                    violations.append(
                        PolicyViolation(
                            resource_uid_ref="manifest",
                            rule="deny",
                            message=str(msg),
                        )
                    )
        return PolicyResult(
            passed=len(violations) == 0,
            violations=violations,
            engine=PolicyEngine.OPA,
        )
    except subprocess.TimeoutExpired:
        return PolicyResult(
            passed=False,
            engine=PolicyEngine.OPA,
            error=f"OPA evaluation timed out after {POLICY_EVAL_TIMEOUT_SECONDS}s",
        )
    except (json.JSONDecodeError, FileNotFoundError) as exc:
        return PolicyResult(
            passed=False,
            engine=PolicyEngine.OPA,
            error=str(exc),
        )
    finally:
        Path(input_file).unlink(missing_ok=True)


def validate_with_cedar(
    manifest_data: dict[str, Any],
    policy_path: str,
) -> PolicyResult:
    """
    Validate a DSK manifest against a Cedar policy.

    Requires: `cedar` CLI on PATH (from AWS Cedar Rust implementation).
    Returns PolicyResult — Cedar integration is a future milestone.
    """
    # Cedar CLI integration is a future milestone.
    # Cedar requires entities + schema in its own format.
    # evaluated=False signals that no validation ran — callers must NOT treat
    # passed=False as a policy failure; it means "skipped, not evaluated".
    return PolicyResult(
        passed=False,
        evaluated=False,
        engine=PolicyEngine.CEDAR,
        error="Cedar not integrated — validation skipped (milestone planned for Wave V.1)",
    )


def validate_policy(
    manifest_data: dict[str, Any],
    policy_path: str,
    engine: PolicyEngine = PolicyEngine.OPA,
) -> PolicyResult:
    """Dispatch to the appropriate policy engine."""
    if engine == PolicyEngine.OPA:
        return validate_with_opa(manifest_data, policy_path)
    if engine == PolicyEngine.CEDAR:
        return validate_with_cedar(manifest_data, policy_path)
    return PolicyResult(
        passed=False,
        error=f"Unknown policy engine: {engine}",
    )
