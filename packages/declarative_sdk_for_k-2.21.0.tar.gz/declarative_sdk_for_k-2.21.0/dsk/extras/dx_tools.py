"""Optional DX helpers: pager-friendly plan summaries, semantic manifest diffs, starter patterns."""

from __future__ import annotations

import json
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any

import yaml

PATTERN_NAMES: tuple[str, ...] = ("msp-fintech-saas", "paved-road-eks", "agentic-llm-tenant")

ACTION_LABELS = {
    "add": ("add", "adds"),
    "create": ("add", "adds"),
    "created": ("add", "adds"),
    "update": ("update", "updates"),
    "change": ("update", "updates"),
    "modify": ("update", "updates"),
    "rotate": ("update", "updates"),
    "delete": ("remove", "removes"),
    "remove": ("remove", "removes"),
    "conflict": ("conflict", "conflicts"),
    "blocked": ("conflict", "conflicts"),
}

SECTION_KIND_HINTS = {
    "records": "record",
    "principals": "principal",
    "databases": "database",
    "tenants": "tenant",
    "policies": "policy",
    "clusters": "cluster",
    "agents": "agent",
    "mcp_servers": "mcp_server",
    "resources": "resource",
}

SECTION_KINDS = {
    "records": "record",
    "principals": "principal",
    "databases": "database",
    "tenants": "tenant",
    "policies": "policy",
    "clusters": "cluster",
    "agents": "agent",
    "mcp_servers": "mcp_server",
}

PRINCIPAL_KEYS = ("principals", "principal_refs", "users", "groups", "owners", "readers", "writers")
SCOPE_KEYS = (
    "scope",
    "scopes",
    "environment",
    "environments",
    "namespace",
    "namespaces",
    "allowed_scopes",
)
SECRET_WORDS = (
    "password",
    "secret",
    "secret_value",
    "token",
    "api_key",
    "private_key",
    "credential",
)


@dataclass(frozen=True)
class PlanChange:
    """A normalized operator-facing change row."""

    action: str
    kind: str
    uid: str
    name: str
    what: str
    blast_radius: str

    @property
    def action_family(self) -> str:
        return ACTION_LABELS.get(self.action.lower(), ("update", "updates"))[0]

    def bullet(self) -> str:
        subject = self.name or self.uid
        return (
            f"- {self.action_family} {self.kind} {subject}: "
            f"{self.what} (blast radius: {self.blast_radius})"
        )


@dataclass(frozen=True)
class Resource:
    kind: str
    identity: str
    body: dict[str, Any]

    @property
    def display(self) -> str:
        for key in ("name", "title", "label"):
            value = self.body.get(key)
            if value:
                return str(value)
        return self.identity


def list_patterns() -> tuple[str, ...]:
    """Return supported starter pattern names."""

    return PATTERN_NAMES


def format_plan_pager_friendly(plan: dict[str, Any]) -> str:
    """Render pager-friendly plan summary plus trailing PagerDuty-shaped JSON block."""

    changes = extract_changes(plan)
    headline = build_headline(changes)
    lines = [headline]
    lines.extend(change.bullet() for change in changes)
    lines.append("PagerDuty event:")
    lines.append(json.dumps(build_pagerduty_event(headline, changes), indent=2, sort_keys=True))
    return "\n".join(lines)


def semantic_diff(before: dict[str, Any], after: dict[str, Any]) -> str:
    """Return ops-language diff between two in-memory manifest mappings."""

    messages = diff_manifests(before, after)
    if not messages:
        return "No semantic changes."
    return "\n".join(f"- {message}" for message in messages)


def init_pattern(pattern_name: str, dest_dir: Path) -> Path:
    """Write starter pattern YAML into dest_dir and return written path."""

    text = render_pattern(pattern_name)
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / f"{pattern_name}.yaml"
    out.write_text(text, encoding="utf-8")
    return out


def render_pattern(name: str) -> str:
    """Return packaged starter pattern YAML text."""

    if name not in PATTERN_NAMES:
        available = ", ".join(PATTERN_NAMES)
        raise ValueError(f"unknown pattern {name!r}; available patterns: {available}")
    raw = (
        resources.files("dsk.extras.patterns").joinpath(f"{name}.yaml").read_text(encoding="utf-8")
    )
    parsed = yaml.safe_load(raw)
    if not isinstance(parsed, dict):
        raise ValueError(f"pattern {name!r} is not a YAML mapping")
    return raw if raw.endswith("\n") else f"{raw}\n"


def extract_changes(manifest: dict[str, Any]) -> list[PlanChange]:
    """Normalize explicit plan rows or infer create rows from manifest resources."""

    explicit = _explicit_changes(manifest)
    if explicit:
        return [_normalize_change(row, index) for index, row in enumerate(explicit, start=1)]
    return _infer_manifest_changes(manifest)


def build_headline(changes: list[PlanChange]) -> str:
    if not changes:
        return "0 changes: no action"

    counts: dict[str, int] = {}
    for change in changes:
        counts[change.action_family] = counts.get(change.action_family, 0) + 1

    parts: list[str] = []
    for family in ("add", "update", "remove", "conflict"):
        count = counts.get(family, 0)
        if count:
            parts.append(f"{count} {_plural_action(family, count)}")

    for family in sorted(set(counts) - {"add", "update", "remove", "conflict"}):
        count = counts[family]
        parts.append(f"{count} {_plural_action(family, count)}")

    return f"{len(changes)} changes: {' + '.join(parts)}"


def build_pagerduty_event(headline: str, changes: list[PlanChange]) -> dict[str, Any]:
    severity = (
        "critical" if any(change.action_family == "conflict" for change in changes) else "warning"
    )
    return {
        "routing_key": "replace-with-pagerduty-routing-key",
        "event_action": "trigger",
        "payload": {
            "summary": headline,
            "severity": severity,
            "source": "keeper-sdk-dx plan-pager",
            "component": "dsk",
            "group": "declarative-plan",
            "class": "change-preview",
            "custom_details": {
                "change_count": len(changes),
                "changes": [
                    {
                        "action": change.action_family,
                        "kind": change.kind,
                        "uid": change.uid,
                        "name": change.name,
                        "what": change.what,
                        "blast_radius": change.blast_radius,
                    }
                    for change in changes
                ],
            },
        },
    }


def _explicit_changes(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    candidates: list[Any] = []
    plan = manifest.get("plan")
    if isinstance(plan, dict):
        candidates.append(plan.get("changes"))
    candidates.append(manifest.get("changes"))

    for candidate in candidates:
        if isinstance(candidate, list):
            return [row for row in candidate if isinstance(row, dict)]
    return []


def _normalize_change(row: dict[str, Any], index: int) -> PlanChange:
    action = _row_string(row, "action", "operation", "change_type", default="update").lower()
    kind = _row_string(row, "kind", "resource_type", "type", default="resource")
    uid = _row_string(row, "uid", "uid_ref", "id", default=f"change-{index}")
    name = _row_string(row, "name", "title", "label", "resource", default=uid)
    what = _row_string(
        row, "what", "summary", "description", default=_default_what(action, kind, name)
    )
    blast_radius = _blast_radius(row)
    return PlanChange(
        action=action, kind=kind, uid=uid, name=name, what=what, blast_radius=blast_radius
    )


def _infer_manifest_changes(manifest: dict[str, Any]) -> list[PlanChange]:
    changes: list[PlanChange] = []
    for section, kind in SECTION_KIND_HINTS.items():
        value = manifest.get(section)
        if value is None:
            continue
        for row in _iter_hint_rows(value):
            action = _row_string(row, "action", "operation", default="add").lower()
            uid = _row_string(row, "uid", "uid_ref", "id", default=f"{kind}-{len(changes) + 1}")
            name = _row_string(row, "name", "title", "label", default=uid)
            what = _row_string(
                row, "what", "summary", "description", default=_default_what(action, kind, name)
            )
            changes.append(
                PlanChange(
                    action=action,
                    kind=_row_string(row, "kind", "resource_type", default=kind),
                    uid=uid,
                    name=name,
                    what=what,
                    blast_radius=_blast_radius(row),
                )
            )
    return changes


def _iter_hint_rows(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        rows = []
        for key, row in value.items():
            if isinstance(row, dict):
                merged = dict(row)
                merged.setdefault("uid_ref", str(key))
                rows.append(merged)
        return rows
    return []


def _row_string(row: dict[str, Any], *keys: str, default: str) -> str:
    for key in keys:
        value = row.get(key)
        if value is not None:
            return str(value)
    return default


def _blast_radius(row: dict[str, Any]) -> str:
    for key in ("blast_radius", "tenant", "scope", "environment", "namespace", "cluster"):
        value = row.get(key)
        if value:
            return _format_cell(value)
    controls = row.get("controls")
    if controls:
        return f"controls {_format_cell(controls)}"
    return "single resource"


def _format_cell(value: Any) -> str:
    if isinstance(value, list):
        return "+".join(str(item) for item in value)
    if isinstance(value, dict):
        return ", ".join(f"{key}={item}" for key, item in value.items())
    return str(value)


def _default_what(action: str, kind: str, name: str) -> str:
    family = ACTION_LABELS.get(action.lower(), (action.lower(), action.lower()))[0]
    verb = {
        "add": "create",
        "update": "update",
        "remove": "remove",
        "conflict": "review conflict for",
    }.get(family, family)
    return f"{verb} {kind} {name}"


def _plural_action(family: str, count: int) -> str:
    if count == 1:
        return family
    if family == "add":
        return "adds"
    if family == "remove":
        return "removes"
    return f"{family}s"


def diff_manifests(before: dict[str, Any], after: dict[str, Any]) -> list[str]:
    before_resources = index_resources(before)
    after_resources = index_resources(after)
    messages: list[str] = []

    for key in sorted(after_resources.keys() - before_resources.keys()):
        resource = after_resources[key]
        messages.append(f"Added {resource.kind} {resource.display}")

    for key in sorted(before_resources.keys() - after_resources.keys()):
        resource = before_resources[key]
        messages.append(f"Removed {resource.kind} {resource.display}")

    for key in sorted(before_resources.keys() & after_resources.keys()):
        messages.extend(diff_resource(before_resources[key], after_resources[key]))

    return _dedupe_messages(messages)


def index_resources(manifest: dict[str, Any]) -> dict[tuple[str, str], Resource]:
    resources_map: dict[tuple[str, str], Resource] = {}

    for section, kind in SECTION_KINDS.items():
        for identity, body in _semantic_section_rows(manifest.get(section)):
            resources_map[(kind, identity)] = Resource(kind=kind, identity=identity, body=body)

    for index, body in enumerate(manifest.get("resources") or [], start=1):
        if not isinstance(body, dict):
            continue
        kind = str(body.get("kind") or body.get("resource_type") or body.get("type") or "resource")
        identity = _identity_key(body, fallback=f"{kind}-{index}")
        resources_map[(kind, identity)] = Resource(kind=kind, identity=identity, body=body)

    return resources_map


def diff_resource(before: Resource, after: Resource) -> list[str]:
    messages: list[str] = []
    messages.extend(_principal_messages(before, after))
    messages.extend(_secret_messages(before, after))
    messages.extend(_scope_messages(before, after))
    if not messages and _comparable_tree(before.body) != _comparable_tree(after.body):
        messages.append(f"Updated {after.kind} {after.display}")
    return messages


def _semantic_section_rows(value: Any) -> list[tuple[str, dict[str, Any]]]:
    if isinstance(value, list):
        rows = []
        for index, row in enumerate(value, start=1):
            if isinstance(row, dict):
                rows.append((_identity_key(row, fallback=f"item-{index}"), row))
        return rows
    if isinstance(value, dict):
        rows = []
        for key, row in value.items():
            if isinstance(row, dict):
                merged = dict(row)
                merged.setdefault("uid_ref", str(key))
                rows.append((_identity_key(merged, fallback=str(key)), merged))
        return rows
    return []


def _identity_key(row: dict[str, Any], fallback: str) -> str:
    for key in ("uid_ref", "uid", "id", "name", "title", "label"):
        value = row.get(key)
        if value:
            return str(value)
    return fallback


def _principal_messages(before: Resource, after: Resource) -> list[str]:
    messages: list[str] = []
    before_refs = _collect_named_sets(before.body, PRINCIPAL_KEYS)
    after_refs = _collect_named_sets(after.body, PRINCIPAL_KEYS)
    for label in sorted(after_refs):
        added = sorted(after_refs[label] - before_refs.get(label, set()))
        removed = sorted(before_refs.get(label, set()) - after_refs[label])
        for principal in added:
            messages.append(f"Added principal {principal} to {after.kind} {after.display}")
        for principal in removed:
            messages.append(f"Removed principal {principal} from {after.kind} {after.display}")
    return messages


def _secret_messages(before: Resource, after: Resource) -> list[str]:
    messages: list[str] = []
    before_secrets = _collect_secret_values(before.body)
    after_secrets = _collect_secret_values(after.body)
    for path, old_value in sorted(before_secrets.items()):
        if path in after_secrets and after_secrets[path] != old_value:
            messages.append(_rotation_message(after, path))
    return messages


def _scope_messages(before: Resource, after: Resource) -> list[str]:
    messages: list[str] = []
    before_scopes = _collect_named_sets(before.body, SCOPE_KEYS)
    after_scopes = _collect_named_sets(after.body, SCOPE_KEYS)
    for label in sorted(before_scopes.keys() | after_scopes.keys()):
        old = before_scopes.get(label, set())
        new = after_scopes.get(label, set())
        if old and new and old < new:
            messages.append(
                f"Expanded scope from {_join_scope(old)} to {_join_scope(new)} for {after.kind} {after.display}"
            )
        elif old and new and new < old:
            messages.append(
                f"Narrowed scope from {_join_scope(old)} to {_join_scope(new)} for {after.kind} {after.display}"
            )
    return messages


def _collect_named_sets(body: dict[str, Any], keys: tuple[str, ...]) -> dict[str, set[str]]:
    found: dict[str, set[str]] = {}

    def walk(value: Any, path: tuple[str, ...]) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                next_path = (*path, str(key))
                if key in keys:
                    normalized = _as_string_set(item)
                    if normalized:
                        found[".".join(next_path)] = normalized
                walk(item, next_path)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                walk(item, (*path, str(index)))

    walk(body, ())
    return found


def _as_string_set(value: Any) -> set[str]:
    if value is None:
        return set()
    if isinstance(value, str):
        return {value}
    if isinstance(value, list):
        return {_display_ref(item) for item in value if _display_ref(item)}
    if isinstance(value, dict):
        if any(key in value for key in ("uid_ref", "uid", "id", "name", "email", "title")):
            display = _display_ref(value)
            return {display} if display else set()
        return {str(key) for key in value}
    return {str(value)}


def _display_ref(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("email", "name", "uid_ref", "uid", "id", "title", "label"):
            item = value.get(key)
            if item:
                return str(item)
        return ""
    return str(value)


def _collect_secret_values(body: dict[str, Any]) -> dict[str, str]:
    found: dict[str, str] = {}

    def walk(value: Any, path: tuple[str, ...]) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                next_path = (*path, str(key))
                if _is_secret_key(str(key)):
                    found[".".join(next_path)] = repr(item)
                walk(item, next_path)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                walk(item, (*path, str(index)))

    walk(body, ())
    return found


def _is_secret_key(key: str) -> bool:
    lowered = key.lower()
    return any(word in lowered for word in SECRET_WORDS)


def _rotation_message(resource: Resource, path: str) -> str:
    lowered_path = path.lower()
    body_type = str(resource.body.get("type") or resource.kind).lower()
    if "password" in lowered_path and (resource.kind == "database" or body_type == "database"):
        return f"Rotated database password for {resource.display}"
    if "password" in lowered_path:
        return f"Rotated password for {resource.kind} {resource.display}"
    return f"Rotated secret for {resource.kind} {resource.display}"


def _join_scope(values: set[str]) -> str:
    return "+".join(sorted(values))


def _comparable_tree(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: _comparable_tree(item)
            for key, item in value.items()
            if not _is_secret_key(str(key))
        }
    if isinstance(value, list):
        return [_comparable_tree(item) for item in value]
    return value


def _dedupe_messages(messages: list[str]) -> list[str]:
    seen: set[str] = set()
    unique: list[str] = []
    for message in messages:
        if message not in seen:
            unique.append(message)
            seen.add(message)
    return unique
