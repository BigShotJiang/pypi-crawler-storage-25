"""Starter manifest patterns shipped with dx_tools."""
