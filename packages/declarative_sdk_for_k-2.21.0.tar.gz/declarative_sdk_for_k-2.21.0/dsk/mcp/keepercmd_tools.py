"""Phase 4-D — KeeperMigrate MCP tools.

Five tools wrapping keeper-migrate subcommands as MCP tools:
- keeper_migrate_verify (KeeperMigrateVerifyTool)
- keeper_migrate_structure (KeeperMigrateStructureTool)
- keeper_migrate_records_import (KeeperMigrateRecordsImportTool)
- keeper_migrate_convert (KeeperMigrateConvertTool)
- keeper_migrate_audit_verify (KeeperMigrateAuditVerifyTool)

Destructive subcommands (cleanup, decommission, take-ownership, transfer-user)
are intentionally NOT wrapped per D8 opt-out decision (keeperCMD@fbbff3b).
"""

from __future__ import annotations

import csv
import json
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from dsk.core.redact import redact

_TIMEOUT = 300
_KEEPER_MIGRATE_BIN = "keeper-migrate"


def _run(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=_TIMEOUT,
    )


def _tail(text: str, n: int = 20) -> str:
    lines = text.splitlines()
    return "\n".join(lines[-n:]) if len(lines) > n else text


def _keeper_not_found_response(subcommand: str) -> str:
    return json.dumps(
        redact(
            {
                "error": "keeper-migrate not found on PATH",
                "subcommand": subcommand,
            }
        )
    )


def _timeout_response(subcommand: str) -> str:
    return json.dumps(
        redact(
            {
                "error": f"keeper-migrate {subcommand} timed out after {_TIMEOUT}s",
                "subcommand": subcommand,
            }
        )
    )


async def keeper_migrate_verify(run_dir: str) -> str:
    """Run keeper-migrate verify and return structured pass/fail rows as JSON.

    keeper-migrate verify requires --inventory <inventory.json> and
    --target-state <target_state.json>. Both are expected inside run_dir/.
    --output FILE.csv is optional; the tool uses it to capture CSV rows.

    Returns JSON: {"run_dir": str, "passed": bool, "rows": [...], "summary": {...}}
    Exit code 0 with non-empty CSV rows = passed; any other outcome = failed.
    """
    run_dir_path = Path(run_dir)
    inventory_path = run_dir_path / "inventory.json"
    target_state_path = run_dir_path / "target_state.json"

    if not inventory_path.exists():
        return json.dumps({"error": "inventory.json not found in run_dir", "run_dir": run_dir})
    if not target_state_path.exists():
        return json.dumps({"error": "target_state.json not found in run_dir", "run_dir": run_dir})

    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as tmp:
        tmp_csv = tmp.name

    try:
        try:
            result = _run(
                [
                    _KEEPER_MIGRATE_BIN,
                    "verify",
                    "--inventory",
                    str(inventory_path),
                    "--target-state",
                    str(target_state_path),
                    "--output",
                    tmp_csv,
                ]
            )
        except FileNotFoundError:
            return _keeper_not_found_response("verify")
        except subprocess.TimeoutExpired:
            return _timeout_response("verify")

        rows: list[dict[str, Any]] = []
        csv_path = Path(tmp_csv)
        if csv_path.exists() and csv_path.stat().st_size > 0:
            with csv_path.open(newline="", encoding="utf-8") as fh:
                reader = csv.DictReader(fh)
                rows = [dict(row) for row in reader]

        passed = result.returncode == 0 and len(rows) > 0

        summary: dict[str, Any] = {
            "total": len(rows),
            "pass": sum(1 for r in rows if str(r.get("status", "")).lower() == "pass"),
            "fail": sum(1 for r in rows if str(r.get("status", "")).lower() != "pass"),
        }

        payload: dict[str, Any] = {
            "run_dir": run_dir,
            "passed": passed,
            "exit_code": result.returncode,
            "rows": rows,
            "summary": summary,
        }
        if result.stderr.strip():
            payload["stderr_tail"] = _tail(result.stderr)

        return json.dumps(redact(payload))
    finally:
        Path(tmp_csv).unlink(missing_ok=True)


async def keeper_migrate_structure(run_dir: str, dry_run: bool = True) -> str:
    """Run keeper-migrate structure from a run_dir containing inventory.json.

    keeper-migrate structure accepts --inventory <inventory.json> or --plan <dir>.
    This tool resolves inventory.json from run_dir automatically.
    Always defaults to dry_run=True. Pass dry_run=False to mutate.
    Returns JSON: {"run_dir": str, "exit_code": int, "stdout_tail": str, "dry_run": bool}
    """
    run_dir_path = Path(run_dir)
    inventory_path = run_dir_path / "inventory.json"

    if not inventory_path.exists():
        return json.dumps({"error": "inventory.json not found in run_dir", "run_dir": run_dir})

    cmd = [_KEEPER_MIGRATE_BIN, "structure", "--inventory", str(inventory_path)]
    if dry_run:
        cmd.append("--dry-run")

    try:
        result = _run(cmd)
    except FileNotFoundError:
        return _keeper_not_found_response("structure")
    except subprocess.TimeoutExpired:
        return _timeout_response("structure")

    payload: dict[str, Any] = {
        "run_dir": run_dir,
        "exit_code": result.returncode,
        "stdout_tail": _tail(result.stdout),
        "dry_run": dry_run,
    }
    if result.stderr.strip():
        payload["stderr_tail"] = _tail(result.stderr)

    return json.dumps(redact(payload))


async def keeper_migrate_records_import(run_dir: str, dry_run: bool = True) -> str:
    """Run keeper-migrate records-import from a run_dir.

    keeper-migrate records-import requires --input <bundle.json>.
    This tool resolves records_bundle.json from run_dir automatically.
    Falls back to inventory.json if records_bundle.json is absent.
    Always defaults to dry_run=True. Pass dry_run=False to mutate.
    Returns JSON: {"run_dir": str, "exit_code": int, "stdout_tail": str,
                   "created": int, "skipped": int, "errors": int, "dry_run": bool}
    """
    run_dir_path = Path(run_dir)
    # keeper-migrate auto-run writes records_import.json (via convert --output).
    # Fall back to inventory.json for callers that only ran the export phase.
    bundle = run_dir_path / "records_import.json"
    if not bundle.exists():
        bundle = run_dir_path / "inventory.json"
    if not bundle.exists():
        return json.dumps(
            {"error": "no records_import.json or inventory.json in run_dir", "run_dir": run_dir}
        )

    cmd = [_KEEPER_MIGRATE_BIN, "records-import", "--input", str(bundle)]
    if dry_run:
        cmd.append("--dry-run")

    try:
        result = _run(cmd)
    except FileNotFoundError:
        return _keeper_not_found_response("records-import")
    except subprocess.TimeoutExpired:
        return _timeout_response("records-import")

    stdout_tail = _tail(result.stdout)

    def _parse_count(pattern: str) -> int:
        m = re.search(pattern, result.stdout)
        return int(m.group(1)) if m else 0

    payload: dict[str, Any] = {
        "run_dir": run_dir,
        "exit_code": result.returncode,
        "stdout_tail": stdout_tail,
        "created": _parse_count(r"created=(\d+)"),
        "skipped": _parse_count(r"skipped=(\d+)"),
        "errors": _parse_count(r"errors=(\d+)"),
        "dry_run": dry_run,
    }
    if result.stderr.strip():
        payload["stderr_tail"] = _tail(result.stderr)

    return json.dumps(redact(payload))


async def keeper_migrate_convert(run_dir: str, output: str = "") -> str:
    """Run keeper-migrate convert to transform a v3 records export into import-ready JSON.

    keeper-migrate convert requires --input-dir <records_export_dir> and
    --output <output_file>. The records_export subdirectory is expected inside run_dir.
    If output is omitted, defaults to <run_dir>/records_import.json.

    Returns JSON: {"run_dir": str, "output": str, "exit_code": int, "stdout_tail": str}
    """
    run_dir_path = Path(run_dir)
    records_export_path = run_dir_path / "records_export"

    if not run_dir_path.exists():
        return json.dumps({"error": "run_dir does not exist", "run_dir": run_dir})
    if not records_export_path.exists():
        return json.dumps(
            {"error": "records_export subdirectory not found in run_dir", "run_dir": run_dir}
        )

    output_path = output if output else str(run_dir_path / "records_import.json")

    cmd = [
        _KEEPER_MIGRATE_BIN,
        "convert",
        "--input-dir",
        str(records_export_path),
        "--output",
        output_path,
    ]

    try:
        result = _run(cmd)
    except FileNotFoundError:
        return _keeper_not_found_response("convert")
    except subprocess.TimeoutExpired:
        return _timeout_response("convert")

    payload: dict[str, Any] = {
        "run_dir": run_dir,
        "output": output_path,
        "exit_code": result.returncode,
        "stdout_tail": _tail(result.stdout),
    }
    if result.stderr.strip():
        payload["stderr_tail"] = _tail(result.stderr)

    return json.dumps(redact(payload))


async def keeper_migrate_audit_verify(run_dir: str) -> str:
    """Run keeper-migrate audit-verify to check artifact integrity of a run directory.

    keeper-migrate audit-verify requires --directory pointing at the run_dir.
    Verifies SHA256SUMS.txt against each file and validates the prev-hash chain
    in audit.log. The run_dir must contain audit.log.

    Returns JSON: {"run_dir": str, "exit_code": int, "verification_passed": bool,
                   "stdout_tail": str}
    """
    run_dir_path = Path(run_dir)
    audit_log_path = run_dir_path / "audit.log"

    if not audit_log_path.exists():
        return json.dumps({"error": "audit.log not found in run_dir", "run_dir": run_dir})

    cmd = [
        _KEEPER_MIGRATE_BIN,
        "audit-verify",
        "--directory",
        str(run_dir_path),
    ]

    try:
        result = _run(cmd)
    except FileNotFoundError:
        return _keeper_not_found_response("audit-verify")
    except subprocess.TimeoutExpired:
        return _timeout_response("audit-verify")

    payload: dict[str, Any] = {
        "run_dir": run_dir,
        "exit_code": result.returncode,
        "verification_passed": result.returncode == 0,
        "stdout_tail": _tail(result.stdout),
    }
    if result.stderr.strip():
        payload["stderr_tail"] = _tail(result.stderr)

    return json.dumps(redact(payload))


__all__ = [
    "keeper_migrate_audit_verify",
    "keeper_migrate_convert",
    "keeper_migrate_records_import",
    "keeper_migrate_structure",
    "keeper_migrate_verify",
]
