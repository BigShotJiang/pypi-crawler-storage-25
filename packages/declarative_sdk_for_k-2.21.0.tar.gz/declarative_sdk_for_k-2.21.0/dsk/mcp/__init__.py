"""DSK MCP server entry point."""

from dsk.mcp.server import main

__all__ = ["main"]
