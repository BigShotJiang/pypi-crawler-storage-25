"""REST-backed provider for ``keeper-integrations-events.v1``."""

from __future__ import annotations

from typing import Any

from dsk.core.errors import CapabilityError
from dsk.core.integrations_events_diff import compute_events_diff
from dsk.core.models_integrations_events import EVENTS_FAMILY, EventsManifestV1
from dsk.core.planner import Plan, build_plan
from dsk.providers.rest_provider_base import (
    KeeperRestProvider,
    config_from_response,
    configuration_from_plan,
    endpoint_from_env_or_override,
    outcomes_from_plan,
    plan_has_mutations,
)

_BLOCKS = ("automator_rules", "audit_alerts", "api_keys", "event_routes")
_RESOURCE_TO_BLOCK = {
    "events_automator_rule": "automator_rules",
    "events_audit_alert": "audit_alerts",
    "events_api_key": "api_keys",
    "events_event_route": "event_routes",
}
_NEXT_ACTION = (
    "Keeper needs to ship or document event-routing configuration REST verbs "
    "(audit alerts, API keys, automator rules, and routes); until then set "
    "DSK_KEEPER_EVENTS_ENDPOINT_BASE or the read/write endpoint overrides for "
    "a lab-proven API"
)


class IntegrationsEventsProvider(KeeperRestProvider):
    """Plan/apply event integration configuration through Keeper REST."""

    def __init__(self, *, endpoint_base: str | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._endpoint_base = endpoint_base

    def plan(self, manifest: EventsManifestV1, *, allow_delete: bool = False) -> Plan:
        self._last_desired_config = _desired_config(manifest)
        try:
            live = self.discover_events_configuration()
        except CapabilityError as exc:
            if "endpoint is not confirmed" not in (exc.reason or ""):
                raise
            live = {}
        changes = compute_events_diff(
            manifest,
            live,
            manifest_name=self._manifest_name or manifest.name,
            allow_delete=allow_delete,
        )
        return build_plan(self._manifest_name or manifest.name, changes, _order(manifest))

    def apply(self, manifest: EventsManifestV1, *, dry_run: bool = False) -> list[Any]:
        return self.apply_events_plan(self.plan(manifest), dry_run=dry_run)

    def discover_events_configuration(self) -> dict[str, Any]:
        # ENDPOINT-UNKNOWN: Keeper documents ARAM/admin reporting and audit-alert
        # Commander commands, but not stable REST write/readback verbs for this
        # whole routing surface. The path is override-driven.
        endpoint = self._endpoint(read=True)
        response = self._rest_post(endpoint, {"method": "GET", "family": EVENTS_FAMILY})
        return config_from_response(response, blocks=_BLOCKS)

    def apply_events_plan(self, plan: Plan, *, dry_run: bool = False) -> list[Any]:
        if dry_run or not plan_has_mutations(plan):
            return outcomes_from_plan(plan, dry_run=dry_run, family=EVENTS_FAMILY)
        # ENDPOINT-UNKNOWN: see discover_events_configuration.
        endpoint = self._endpoint(read=False)
        config = getattr(
            self,
            "_last_desired_config",
            configuration_from_plan(plan, resource_to_block=_RESOURCE_TO_BLOCK),
        )
        self._rest_post(
            endpoint,
            {"method": "PUT", "family": EVENTS_FAMILY, "configuration": config},
        )
        return outcomes_from_plan(plan, dry_run=dry_run, family=EVENTS_FAMILY, endpoint=endpoint)

    def _endpoint(self, *, read: bool) -> str:
        return endpoint_from_env_or_override(
            read=read,
            family=EVENTS_FAMILY,
            endpoint_base=self._endpoint_base,
            base_env="DSK_KEEPER_EVENTS_ENDPOINT_BASE",
            read_env="DSK_KEEPER_EVENTS_READ_ENDPOINT",
            write_env="DSK_KEEPER_EVENTS_WRITE_ENDPOINT",
            next_action=_NEXT_ACTION,
        )


def _order(manifest: EventsManifestV1) -> list[str]:
    return [uid_ref for uid_ref, _kind in manifest.iter_uid_refs()]


def _desired_config(manifest: EventsManifestV1) -> dict[str, Any]:
    data = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    return {block: data.get(block) or [] for block in _BLOCKS}


__all__ = ["IntegrationsEventsProvider"]
