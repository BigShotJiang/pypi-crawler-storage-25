"""Commander library (SDK) provider — Wave 2 gated implementation.

:public: ``CommanderLibraryProvider`` is exported for preview/testing only.
:internal: Runtime promotion remains operator-gated; helper functions are not
stable API.

Wave 2 gated path — DO NOT wire as production provider without operator approval.

This module defines :class:`CommanderLibraryProvider`, a future native-library
counterpart to :class:`~dsk.providers.commander_service.CommanderServiceProvider`
(the current production-oriented Commander Service Mode REST + adapter stack).

All methods raise :exc:`NotImplementedError` by default. Setting
``DSK_WAVE2_LIVE=1`` enables the reviewable SDK-backed implementation while
leaving the production provider selection unchanged. See ``docs/wave2-migration.md``.

Cross-reference: production interface today lives in
``dsk/providers/commander_service.py`` (:class:`CommanderServiceProvider`).
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome, LiveRecord, Provider
from dsk.core.normalize import to_pam_import_json
from dsk.core.planner import Plan
from dsk.providers.commander_cli import (
    _detect_unsupported_capabilities,
    _rotation_apply_is_enabled,
)
from dsk.providers.commander_service import _keeper_uid_from_result, _live_record_from_row
from dsk.providers.service_client import CommanderServiceClient

_WAVE_1_GATE_CONDITIONS = [
    "E2E Path B (D1 anonymised fixture) green",
    "E2E Path C (live tenant) green on at least 1 tenant pair",
    "CommanderLibraryProvider unit tests passing with mocked keepercommander",
    "dsk AGENTS.md Wave 1 section updated",
]

_WAVE2_ENV = "DSK_WAVE2_LIVE"
_SCAFFOLD_ERROR = (
    "CommanderLibraryProvider scaffold not yet promoted to live default. "
    "Set DSK_WAVE2_LIVE=1 to enable (operator nod required first; "
    "see docs/wave2-migration.md)."
)


class _CommanderSdkAdapter:
    def __init__(self, *, config_file: str | None, timeout: int) -> None:
        self.config_file = config_file
        self.timeout = timeout
        self._params: Any | None = None

    def discover(self) -> list[LiveRecord]:
        params = self._sync_down(record_types=True)
        rows = [_row_from_cached_record(params, uid, row) for uid, row in _record_cache(params)]
        return [record for row in rows if (record := _live_record_from_row(row)) is not None]

    def apply_plan(
        self,
        plan: Plan,
        *,
        dry_run: bool,
        manifest_source: dict[str, Any],
    ) -> list[ApplyOutcome]:
        outcomes: list[ApplyOutcome] = []
        ordered = plan.ordered()
        create_update = [c for c in ordered if c.kind in (ChangeKind.CREATE, ChangeKind.UPDATE)]
        if create_update:
            if not manifest_source:
                raise CapabilityError(
                    reason=(
                        "CommanderLibraryProvider SDK apply requires manifest_source for "
                        "create/update rows"
                    ),
                    next_action=(
                        "construct CommanderLibraryProvider with the loaded manifest_source "
                        "or use dry-run planning only"
                    ),
                )
            result = self._apply_pam_project(
                plan,
                manifest_source,
                dry_run=dry_run,
                has_existing=any(c.kind is ChangeKind.UPDATE for c in create_update),
            )
            created_uid = _keeper_uid_from_result(result) if isinstance(result, Mapping) else None
            for change in create_update:
                keeper_uid = change.keeper_uid or (created_uid or "" if not dry_run else "")
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=keeper_uid,
                        action=str(change.kind),
                        details={"dry_run": dry_run, "transport": "keepercommander-sdk"},
                    )
                )

        for change in [c for c in ordered if c.kind is ChangeKind.DELETE]:
            if not dry_run and change.keeper_uid:
                self._delete_record(change.keeper_uid)
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="delete",
                    details={"dry_run": dry_run, "transport": "keepercommander-sdk"},
                )
            )

        for change in plan.conflicts:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="conflict",
                    details={"reason": change.reason or ""},
                )
            )
        for change in plan.noops:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                )
            )
        return outcomes

    def unsupported_capabilities(self, manifest: Any = None) -> list[str]:
        return _detect_unsupported_capabilities(
            manifest or {},
            allow_nested_rotation=_rotation_apply_is_enabled(),
        )

    def check_tenant_bindings(self, manifest: Any = None) -> list[str]:  # noqa: ARG002
        return []

    def _params_or_login(self) -> Any:
        if self._params is not None:
            return self._params
        try:
            from keepercommander import api  # noqa: PLC0415
            from keepercommander.params import KeeperParams  # noqa: PLC0415
        except ImportError as exc:
            raise CapabilityError(
                reason=f"keepercommander SDK unavailable: {type(exc).__name__}: {exc}",
                next_action="install keepercommander>=18.0.0,<19 before enabling DSK_WAVE2_LIVE",
            ) from exc

        params = (
            KeeperParams(config_filename=self.config_file) if self.config_file else KeeperParams()
        )
        token = getattr(params, "session_token", "") or ""
        if not token and not sys.stdin.isatty():
            raise CapabilityError(
                reason="Commander SDK session has no token in a non-interactive context",
                next_action=(
                    "run keeper login interactively first, or provide a Commander config "
                    "with a valid session token"
                ),
            )
        api.login(params)
        self._params = params
        return params

    def _sync_down(self, *, record_types: bool = False) -> Any:
        params = self._params_or_login()
        from keepercommander import api  # noqa: PLC0415

        try:
            api.sync_down(params, record_types=record_types)
        except TypeError:
            api.sync_down(params)
        return params

    def _apply_pam_project(
        self,
        plan: Plan,
        manifest_source: dict[str, Any],
        *,
        dry_run: bool,
        has_existing: bool,
    ) -> Mapping[str, Any]:
        params = self._params_or_login()
        payload = to_pam_import_json(manifest_source)
        temp_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as handle:
                json.dump(payload, handle, indent=2)
                temp_path = Path(handle.name)
            if has_existing:
                from keepercommander.commands.pam_import.extend import (  # noqa: PLC0415
                    PAMProjectExtendCommand,
                )

                result = PAMProjectExtendCommand().execute(
                    params,
                    config=_first_pam_config_name(payload),
                    file_name=str(temp_path),
                    dry_run=dry_run,
                )
            else:
                from keepercommander.commands.pam_import.edit import (  # noqa: PLC0415
                    PAMProjectImportCommand,
                )

                result = PAMProjectImportCommand().execute(
                    params,
                    project_name=plan.manifest_name,
                    file_name=str(temp_path),
                    dry_run=dry_run,
                )
            return result if isinstance(result, Mapping) else {}
        except Exception as exc:
            raise CapabilityError(
                reason=f"Commander SDK pam project apply failed: {type(exc).__name__}: {exc}",
                next_action="inspect Commander SDK output and retry after fixing the manifest",
            ) from exc
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)

    def _delete_record(self, keeper_uid: str) -> None:
        params = self._params_or_login()
        try:
            from keepercommander.commands.base import RecordRemoveCommand  # noqa: PLC0415
        except ImportError:
            try:
                from keepercommander.commands.record import (  # type: ignore[no-redef] # noqa: PLC0415
                    RecordRemoveCommand,
                )
            except ImportError as exc:
                raise CapabilityError(
                    reason="Commander SDK record delete command is unavailable",
                    next_action="upgrade keepercommander or use CommanderServiceProvider for deletes",
                ) from exc
        RecordRemoveCommand().execute(params, record=keeper_uid, force=True)


def _record_cache(params: Any) -> list[tuple[str, Any]]:
    cache = getattr(params, "record_cache", None) or {}
    if isinstance(cache, Mapping):
        return [(str(uid), row) for uid, row in cache.items()]
    return []


def _row_from_cached_record(params: Any, uid: str, cached: Any) -> dict[str, Any]:
    try:
        from keepercommander import vault  # noqa: PLC0415

        record = vault.KeeperRecord.load(params, uid)
    except Exception:
        record = cached
    if isinstance(record, Mapping):
        row = dict(record)
    else:
        row = {
            "keeper_uid": getattr(record, "record_uid", None)
            or getattr(record, "uid", None)
            or uid,
            "title": getattr(record, "title", None) or uid,
            "record_type": getattr(record, "record_type", None)
            or getattr(record, "type", None)
            or getattr(cached, "record_type", None),
            "custom": getattr(record, "custom", None) or getattr(record, "custom_fields", None),
            "fields": getattr(record, "fields", None),
        }
    row.setdefault("keeper_uid", row.get("record_uid") or row.get("uid") or uid)
    row.setdefault("title", row.get("name") or row.get("record_title") or uid)
    row.setdefault("record_type", row.get("type") or row.get("resource_type") or "login")
    return row


def _first_pam_config_name(payload: Mapping[str, Any]) -> str | None:
    configs = payload.get("pam_configuration")
    if isinstance(configs, Mapping):
        value = configs.get("title") or configs.get("name") or configs.get("uid")
        return str(value) if value else None
    if isinstance(configs, list) and configs:
        first = configs[0]
        if isinstance(first, Mapping):
            value = first.get("title") or first.get("name") or first.get("uid")
            return str(value) if value else None
    return None


class CommanderLibraryProvider(Provider):
    """Commander SDK provider — interface locked to CommanderServiceProvider.

    Wave 2 gated implementation — wire after operator nod. Methods mirror
    :class:`~dsk.providers.commander_service.CommanderServiceProvider`; the
    SDK body is available only when ``DSK_WAVE2_LIVE`` is set.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:4020",
        api_key: str | None = None,
        timeout: int = 300,
        *,
        manifest_source: dict[str, Any] | None = None,
        client: CommanderServiceClient | None = None,
    ) -> None:
        """Wave 2 gated SDK path — wire after operator nod.

        Signature matches :meth:`CommanderServiceProvider.__init__`.
        """
        if not os.environ.get("DSK_WAVE2_LIVE"):
            raise NotImplementedError(_SCAFFOLD_ERROR)
        self.base_url = base_url
        self.api_key = api_key
        self.timeout = timeout
        self._manifest_source = manifest_source or {}
        self._adapter: Any = client or _CommanderSdkAdapter(
            config_file=os.environ.get("KEEPER_CONFIG"),
            timeout=timeout,
        )

    def discover(self) -> list[LiveRecord]:
        """Wave 2 gated SDK path — wire after operator nod.

        Signature matches :meth:`CommanderServiceProvider.discover`.
        """
        if not os.environ.get("DSK_WAVE2_LIVE"):
            raise NotImplementedError(_SCAFFOLD_ERROR)
        return list(self._adapter.discover())

    def apply_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Wave 2 gated SDK path — wire after operator nod.

        Signature matches :meth:`CommanderServiceProvider.apply_plan`.
        """
        if not os.environ.get("DSK_WAVE2_LIVE"):
            raise NotImplementedError(_SCAFFOLD_ERROR)
        try:
            return list(
                self._adapter.apply_plan(
                    plan,
                    dry_run=dry_run,
                    manifest_source=self._manifest_source,
                )
            )
        except TypeError:
            return list(self._adapter.apply_plan(plan, dry_run=dry_run))

    def unsupported_capabilities(self, manifest: Any = None) -> list[str]:
        """Wave 2 gated SDK path — wire after operator nod.

        Signature matches :meth:`CommanderServiceProvider.unsupported_capabilities`.
        """
        if not os.environ.get("DSK_WAVE2_LIVE"):
            raise NotImplementedError(_SCAFFOLD_ERROR)
        if hasattr(self._adapter, "unsupported_capabilities"):
            return list(self._adapter.unsupported_capabilities(manifest))
        source = manifest if manifest is not None else self._manifest_source
        return _detect_unsupported_capabilities(
            source,
            allow_nested_rotation=_rotation_apply_is_enabled(),
        )

    def check_tenant_bindings(self, manifest: Any = None) -> list[str]:  # noqa: ARG002
        """Wave 2 gated SDK path — wire after operator nod.

        Signature matches :meth:`CommanderServiceProvider.check_tenant_bindings`.
        """
        if not os.environ.get("DSK_WAVE2_LIVE"):
            raise NotImplementedError(_SCAFFOLD_ERROR)
        if hasattr(self._adapter, "check_tenant_bindings"):
            return list(self._adapter.check_tenant_bindings(manifest))
        return []


__all__ = ["CommanderLibraryProvider", "_WAVE_1_GATE_CONDITIONS"]
