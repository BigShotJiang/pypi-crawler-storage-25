"""REST-backed provider for ``keeper-integrations-identity.v1``."""

from __future__ import annotations

from typing import Any

from dsk.core.errors import CapabilityError
from dsk.core.integrations_identity_diff import compute_identity_diff
from dsk.core.models_integrations_identity import IDENTITY_FAMILY, IdentityManifestV1
from dsk.core.planner import Plan, build_plan
from dsk.providers.rest_provider_base import (
    KeeperRestProvider,
    config_from_response,
    configuration_from_plan,
    endpoint_from_env_or_override,
    outcomes_from_plan,
    plan_has_mutations,
)

_BLOCKS = ("domains", "scim", "sso_providers", "outbound_email")
_RESOURCE_TO_BLOCK = {
    "identity_domain": "domains",
    "identity_scim": "scim",
    "identity_sso_provider": "sso_providers",
    "identity_outbound_email": "outbound_email",
}
_NEXT_ACTION = (
    "Keeper needs to ship or document identity-integration configuration REST verbs "
    "(SCIM endpoint creation/update, SSO provider config, domain and outbound-email "
    "settings); until then set DSK_KEEPER_IDENTITY_ENDPOINT_BASE or the read/write "
    "endpoint overrides for a lab-proven API"
)


class IntegrationsIdentityProvider(KeeperRestProvider):
    """Plan/apply identity integration configuration through Keeper REST."""

    def __init__(self, *, endpoint_base: str | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._endpoint_base = endpoint_base

    def plan(self, manifest: IdentityManifestV1, *, allow_delete: bool = False) -> Plan:
        self._last_desired_config = _desired_config(manifest)
        try:
            live = self.discover_identity_configuration()
        except CapabilityError as exc:
            if "endpoint is not confirmed" not in (exc.reason or ""):
                raise
            live = {}
        changes = compute_identity_diff(
            manifest,
            live,
            manifest_name=self._manifest_name or IDENTITY_FAMILY,
            allow_delete=allow_delete,
        )
        return build_plan(self._manifest_name or IDENTITY_FAMILY, changes, _order(manifest))

    def apply(self, manifest: IdentityManifestV1, *, dry_run: bool = False) -> list[Any]:
        if dry_run:
            changes = compute_identity_diff(
                manifest,
                {},
                manifest_name=self._manifest_name or IDENTITY_FAMILY,
            )
            return outcomes_from_plan(
                build_plan(self._manifest_name or IDENTITY_FAMILY, changes, _order(manifest)),
                dry_run=True,
                family=IDENTITY_FAMILY,
            )
        return self.apply_identity_plan(self.plan(manifest), dry_run=False)

    def discover_identity_configuration(self) -> dict[str, Any]:
        # ENDPOINT-UNKNOWN: Keeper documents public SCIM Users/Groups endpoints,
        # but not a stable Commander REST endpoint for declarative SCIM/SSO/domain
        # configuration management. The path is override-driven.
        endpoint = self._endpoint(read=True)
        response = self._rest_post(endpoint, {"method": "GET", "family": IDENTITY_FAMILY})
        return config_from_response(response, blocks=_BLOCKS, singleton_blocks=("outbound_email",))

    def apply_identity_plan(self, plan: Plan, *, dry_run: bool = False) -> list[Any]:
        if dry_run or not plan_has_mutations(plan):
            return outcomes_from_plan(plan, dry_run=dry_run, family=IDENTITY_FAMILY)
        # ENDPOINT-UNKNOWN: see discover_identity_configuration.
        endpoint = self._endpoint(read=False)
        config = getattr(
            self,
            "_last_desired_config",
            configuration_from_plan(
                plan,
                resource_to_block=_RESOURCE_TO_BLOCK,
                singleton_blocks=("outbound_email",),
            ),
        )
        self._rest_post(
            endpoint,
            {"method": "PUT", "family": IDENTITY_FAMILY, "configuration": config},
        )
        return outcomes_from_plan(plan, dry_run=dry_run, family=IDENTITY_FAMILY, endpoint=endpoint)

    def _endpoint(self, *, read: bool) -> str:
        return endpoint_from_env_or_override(
            read=read,
            family=IDENTITY_FAMILY,
            endpoint_base=self._endpoint_base,
            base_env="DSK_KEEPER_IDENTITY_ENDPOINT_BASE",
            read_env="DSK_KEEPER_IDENTITY_READ_ENDPOINT",
            write_env="DSK_KEEPER_IDENTITY_WRITE_ENDPOINT",
            next_action=_NEXT_ACTION,
        )


def _order(manifest: IdentityManifestV1) -> list[str]:
    order = [domain.name for domain in manifest.domains]
    order.extend(uid_ref for uid_ref, _kind in manifest.iter_uid_refs())
    if manifest.outbound_email is not None:
        order.append("outbound_email")
    return order


def _desired_config(manifest: IdentityManifestV1) -> dict[str, Any]:
    data = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    out = {block: data.get(block) or [] for block in ("domains", "scim", "sso_providers")}
    out["outbound_email"] = data.get("outbound_email")
    return out


__all__ = ["IntegrationsIdentityProvider"]
