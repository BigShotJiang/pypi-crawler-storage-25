"""Internal helpers for the MSP managed-company resource family.

Used by :class:`dsk.providers.commander_cli.CommanderCliProvider`.
Not a public API.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change
from dsk.core.errors import CapabilityError, CollisionError
from dsk.core.planner import Plan

ConflictError = CollisionError

_MSP_UNLIMITED_SEATS = 1_000_000_000


def _msp_plan_slug_from_product_id(product_id: Any) -> str:
    """Map Commander ``product_id`` (int slug id or string slug) to MSP plan code."""
    try:
        from keepercommander import constants
    except ImportError:
        return str(product_id) if product_id is not None else ""
    if product_id is None:
        return ""
    if isinstance(product_id, str):
        s = product_id.strip()
        for row in constants.MSP_PLANS:
            if row[1] == s or row[1].lower() == s.lower():
                return str(row[1])
        return s
    if isinstance(product_id, int):
        for row in constants.MSP_PLANS:
            if row[0] == product_id:
                return str(row[1])
    return str(product_id)


def _msp_file_plan_display(file_plan_type: Any) -> str | None:
    if file_plan_type is None or file_plan_type == "":
        return None
    try:
        from keepercommander import constants
    except ImportError:
        return str(file_plan_type)
    fpt = str(file_plan_type)
    for row in constants.MSP_FILE_PLANS:
        if row[1] == fpt:
            return str(row[2])
    return fpt


def _msp_plan_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    seen = {id(change) for change in ordered}
    return ordered + [change for change in plan.changes if id(change) not in seen]


def _msp_change_name(change: Change) -> str:
    for payload in (change.after, change.before):
        value = payload.get("name")
        if value is not None:
            return str(value)
    return str(change.uid_ref or change.title)


def _msp_commander_seats(value: Any) -> int:
    seats = int(value)
    return -1 if seats >= _MSP_UNLIMITED_SEATS else seats


def _msp_addon_arg(addon: Mapping[str, Any]) -> str:
    name = str(addon["name"])
    seats = _msp_commander_seats(addon.get("seats", 0))
    return f"{name}:{seats}" if seats else name


def _msp_add_command_kwargs(change: Change) -> dict[str, Any]:
    after = change.after
    name = after.get("name") or change.uid_ref or change.title
    if not name:
        raise CapabilityError(
            reason="MSP managed-company create change is missing after.name",
            uid_ref=change.uid_ref,
            resource_type=change.resource_type,
            next_action="rebuild the MSP plan from a valid msp-environment.v1 manifest",
        )
    kwargs: dict[str, Any] = {"name": str(name)}
    if after.get("plan") is not None:
        kwargs["plan"] = str(after["plan"])
    if after.get("seats") is not None:
        kwargs["seats"] = _msp_commander_seats(after["seats"])
    if after.get("file_plan") not in (None, ""):
        kwargs["file_plan"] = str(after["file_plan"])
    if after.get("node") not in (None, ""):
        kwargs["node"] = str(after["node"])
    addons = after.get("addons")
    if isinstance(addons, list):
        addon_args = [_msp_addon_arg(addon) for addon in addons if isinstance(addon, Mapping)]
        if addon_args:
            kwargs["addon"] = addon_args
    return kwargs


def _msp_mc_id_from_payload(payload: Mapping[str, Any]) -> str | None:
    value = payload.get("mc_enterprise_id")
    if value in (None, ""):
        return None
    return str(value)


def _msp_target_mc(change: Change, existing: Mapping[str, Any] | None = None) -> str:
    for value in (
        change.keeper_uid,
        _msp_mc_id_from_payload(change.before),
        _msp_mc_id_from_payload(change.after),
        _msp_mc_id_from_payload(existing or {}),
    ):
        if value not in (None, ""):
            return str(value)
    return _msp_change_name(change)


def _msp_same_mc(row: Mapping[str, Any], *, target_id: str | None, target_names: set[str]) -> bool:
    row_id = _msp_mc_id_from_payload(row)
    if target_id is not None and row_id == target_id:
        return True
    row_name = str(row.get("name") or "")
    return row_name.casefold() in target_names


def _msp_find_target(
    live_rows: list[dict[str, Any]],
    change: Change,
    *,
    name: str,
) -> dict[str, Any] | None:
    target_ids = {
        value
        for value in (
            change.keeper_uid,
            _msp_mc_id_from_payload(change.before),
            _msp_mc_id_from_payload(change.after),
        )
        if value not in (None, "")
    }
    if target_ids:
        existing = next(
            (
                row
                for row in live_rows
                if _msp_mc_id_from_payload(row) in {str(value) for value in target_ids}
            ),
            None,
        )
        if existing is not None:
            return existing

    target_names = {
        str(value).casefold()
        for value in (
            change.before.get("name"),
            change.after.get("name"),
            change.uid_ref,
            change.title,
            name,
        )
        if value not in (None, "")
    }
    return next(
        (row for row in live_rows if str(row.get("name") or "").casefold() in target_names),
        None,
    )


def _msp_guard_update_name_collision(
    *,
    live_rows: list[dict[str, Any]],
    change: Change,
    existing: Mapping[str, Any] | None,
    name: str,
) -> None:
    new_name = str(change.after.get("name") or name)
    target_id = _msp_mc_id_from_payload(existing or {}) or change.keeper_uid
    target_names = {
        str(value).casefold()
        for value in (
            (existing or {}).get("name"),
            change.before.get("name"),
            change.uid_ref,
            change.title,
            name,
        )
        if value not in (None, "")
    }
    conflict = next(
        (
            row
            for row in live_rows
            if str(row.get("name") or "").casefold() == new_name.casefold()
            and not _msp_same_mc(row, target_id=target_id, target_names=target_names)
        ),
        None,
    )
    if conflict is None:
        return
    raise ConflictError(
        reason=f"managed company {new_name!r} already exists; refusing update rename",
        uid_ref=change.uid_ref or name,
        resource_type=change.resource_type,
        live_identifier=str(conflict.get("mc_enterprise_id") or conflict.get("name") or new_name),
        next_action="refresh plan from live MSP state or choose a unique managed-company name",
        context={"live": conflict},
    )


def _msp_addons_by_name(addons: Any) -> dict[str, Mapping[str, Any]]:
    if not isinstance(addons, list):
        return {}
    return {
        str(addon["name"]).casefold(): addon
        for addon in addons
        if isinstance(addon, Mapping) and addon.get("name") is not None
    }


def _msp_update_command_kwargs(
    change: Change,
    existing: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    after = change.after
    kwargs: dict[str, Any] = {"mc": _msp_target_mc(change, existing)}
    if after.get("name") not in (None, ""):
        kwargs["name"] = str(after["name"])
    if after.get("plan") is not None:
        kwargs["plan"] = str(after["plan"])
    if after.get("seats") is not None:
        kwargs["seats"] = _msp_commander_seats(after["seats"])
    if after.get("file_plan") not in (None, ""):
        kwargs["file_plan"] = str(after["file_plan"])
    if after.get("node") not in (None, ""):
        kwargs["node"] = str(after["node"])

    before_addons = _msp_addons_by_name(change.before.get("addons"))
    after_addons = _msp_addons_by_name(after.get("addons"))
    add_addon = [
        _msp_addon_arg(addon)
        for key, addon in sorted(after_addons.items())
        if key not in before_addons
        or _msp_commander_seats(before_addons[key].get("seats", 0))
        != _msp_commander_seats(addon.get("seats", 0))
    ]
    remove_addon = [
        str(addon["name"])
        for key, addon in sorted(before_addons.items())
        if key not in after_addons
    ]
    if add_addon:
        kwargs["add_addon"] = add_addon
    if remove_addon:
        kwargs["remove_addon"] = remove_addon
    return kwargs
