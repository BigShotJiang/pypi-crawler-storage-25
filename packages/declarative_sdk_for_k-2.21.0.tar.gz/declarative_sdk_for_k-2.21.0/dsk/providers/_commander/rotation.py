"""Internal helpers for the rotation-policy resource family.

Used by :class:`dsk.providers.commander_cli.CommanderCliProvider`.
Not a public API.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from dsk.core.diff import Change
from dsk.core.errors import CapabilityError
from dsk.core.planner import Plan
from dsk.providers.commander_cli import (
    _TRUTHY_ENV_VALUES,
    _desired_identity,
    _first_non_empty,
    _first_present,
    _model_dump_dict,
    _non_empty_str,
    _truthy,
)

if TYPE_CHECKING:
    from dsk.providers.commander_cli import _RotationRefResolver

_ROTATION_APPLY_ENV_VAR = "DSK_EXPERIMENTAL_ROTATION_APPLY"


def _rotation_plan_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    seen = {id(change) for change in ordered}
    return ordered + [change for change in plan.changes if id(change) not in seen]


def _rotation_change_record_uid(change: Change) -> str:
    for value in (
        change.after.get("record_uid_ref"),
        change.keeper_uid,
        change.uid_ref,
        change.title,
    ):
        if value not in (None, ""):
            return str(value)
    raise CapabilityError(
        reason="rotation-policy.v1 change is missing record_uid_ref",
        uid_ref=change.uid_ref,
        resource_type=change.resource_type,
        next_action="refresh plan from a valid rotation-policy.v1 manifest",
    )


def _rotation_commander_arg_list(value: Any) -> list[str] | None:
    if value in (None, ""):
        return None
    values = value if isinstance(value, list) else [value]
    out: list[str] = []
    for item in values:
        if item in (None, ""):
            continue
        if isinstance(item, Mapping):
            out.append(json.dumps(item, separators=(",", ":")))
        else:
            out.append(str(item))
    return out or None


def _rotation_change_enabled(change: Change) -> bool | None:
    value = change.after.get("enabled")
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        stripped = value.strip().lower()
        if stripped in _TRUTHY_ENV_VALUES:
            return True
        if stripped in {"0", "false", "no", "off"}:
            return False
    return bool(value)


def _rotation_command_kwargs(change: Change) -> dict[str, Any]:
    record_uid_ref = _rotation_change_record_uid(change)
    after = change.after
    schedule_type = str(after.get("schedule_type") or "").strip().replace("-", "_").lower()
    on_demand = schedule_type in {"on_demand", "on_use", "manual"}

    kwargs: dict[str, Any] = {"record_name": record_uid_ref, "force": True}
    if on_demand:
        kwargs["on_demand"] = True
    else:
        schedule_json = _rotation_commander_arg_list(
            after.get("schedule_json") or after.get("schedule_config")
        )
        schedule_cron = _rotation_commander_arg_list(after.get("schedule_cron"))
        if schedule_json is not None:
            kwargs["schedule_json_data"] = schedule_json
        if schedule_cron is not None:
            kwargs["schedule_cron_data"] = schedule_cron

    for source_key, commander_key in (
        ("rotation_profile", "rotation_profile"),
        ("resource_uid_ref", "resource"),
        ("config_uid_ref", "config"),
    ):
        value = after.get(source_key)
        if value not in (None, ""):
            kwargs[commander_key] = str(value)
    if after.get("password_complexity") not in (None, ""):
        kwargs["pwd_complexity"] = str(after["password_complexity"])

    enabled = _rotation_change_enabled(change)
    if enabled is not None:
        kwargs["enable"] = enabled
        kwargs["disable"] = not enabled
    return kwargs


def _rotation_settings_from_readback(data: Any, *, uid: str) -> dict[str, Any]:
    for row in _rotation_readback_rows(data):
        row_uid = _first_non_empty(row, ("record_uid", "recordUid", "Record UID", "uid", "record"))
        if row_uid and row_uid != uid:
            continue
        settings = _rotation_settings_from_row(row)
        if settings:
            return settings
    return {}


def _rotation_readback_rows(data: Any) -> list[Mapping[str, Any]]:
    if isinstance(data, list):
        return [row for row in data if isinstance(row, Mapping)]
    if not isinstance(data, Mapping):
        return []
    for key in ("rotations", "rotation_schedules", "schedules", "records", "items", "data"):
        value = data.get(key)
        if isinstance(value, list):
            return [row for row in value if isinstance(row, Mapping)]
    return [data]


def _rotation_settings_from_row(row: Mapping[str, Any]) -> dict[str, Any]:
    nested = row.get("rotation_settings") or row.get("rotationSettings")
    source: dict[str, Any] = dict(row)
    if isinstance(nested, Mapping):
        source.update(nested)

    settings: dict[str, Any] = {}
    rotation = _first_non_empty(
        source,
        (
            "rotation",
            "rotation_profile",
            "rotationProfile",
            "Rotation Profile",
            "profile",
            "profile_name",
        ),
    )
    if rotation:
        settings["rotation"] = rotation

    enabled_value = _first_present(
        source,
        (
            "enabled",
            "rotation_enabled",
            "rotationEnabled",
            "Rotation Enabled",
            "Enabled",
            "status",
        ),
    )
    if enabled_value is None and isinstance(source.get("disabled"), bool):
        enabled_value = not source["disabled"]
    enabled = _rotation_enabled_value(enabled_value)
    if enabled:
        settings["enabled"] = enabled

    schedule = _rotation_schedule_from_row(source)
    if schedule:
        settings["schedule"] = schedule

    complexity = _first_non_empty(
        source,
        ("password_complexity", "passwordComplexity", "complexity", "Password Complexity"),
    )
    if complexity:
        settings["password_complexity"] = complexity
    return settings


def _rotation_enabled_value(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return "on" if value else "off"
    text = str(value).strip().lower()
    if text in {"true", "1", "yes", "on", "enabled", "active"}:
        return "on"
    if text in {"false", "0", "no", "off", "disabled", "inactive"}:
        return "off"
    return text or None


def _rotation_schedule_from_row(row: Mapping[str, Any]) -> dict[str, str] | None:
    schedule = row.get("schedule") or row.get("Schedule")
    if isinstance(schedule, Mapping):
        nested_schedule_type = str(schedule.get("type") or "").strip()
        if nested_schedule_type.casefold() == "on-demand":
            return {"type": "on-demand"}
        cron = schedule.get("cron") or schedule.get("expression")
        if cron:
            return {"type": "CRON", "cron": str(cron)}
    schedule_type = _first_non_empty(row, ("schedule_type", "scheduleType", "Schedule Type"))
    if schedule_type and str(schedule_type).casefold() in {"manual", "on-demand", "on_demand"}:
        return {"type": "on-demand"}
    if _truthy(row.get("no_schedule")) or _truthy(row.get("noSchedule")):
        return {"type": "on-demand"}

    cron = _first_non_empty(
        row,
        ("cron", "schedule_cron", "scheduleCron", "schedule_data", "scheduleData"),
    )
    if cron:
        parsed = _rotation_cron_from_string(cron)
        if parsed:
            return {"type": "CRON", "cron": parsed}
    if isinstance(schedule, str):
        if "manual" in schedule.casefold() or "on-demand" in schedule.casefold():
            return {"type": "on-demand"}
        parsed = _rotation_cron_from_string(schedule)
        if parsed:
            return {"type": "CRON", "cron": parsed}
    return None


def _rotation_cron_from_string(value: str) -> str | None:
    text = value.strip()
    if text.startswith("RotateActionJob|"):
        text = text.split("|", 1)[1]
        parts = text.split(".")
        if len(parts) >= 2 and parts[0].casefold() == "cron":
            text = parts[1]
    parts = text.split()
    if len(parts) in {5, 6, 7}:
        return text
    return None


def _rotation_config_ref(
    source: Mapping[str, Any],
    resource: Mapping[str, Any],
) -> tuple[str | None, str | None]:
    config_ref = _non_empty_str(resource.get("pam_configuration_uid_ref"))
    configs = [cfg for cfg in source.get("pam_configurations") or [] if isinstance(cfg, Mapping)]
    if config_ref:
        config = next((cfg for cfg in configs if cfg.get("uid_ref") == config_ref), None)
        config_title = _non_empty_str(config.get("title")) if config is not None else None
        return config_ref, config_title
    if len(configs) == 1:
        config = configs[0]
        return _non_empty_str(config.get("uid_ref")), _non_empty_str(config.get("title"))
    raise ValueError(
        f"missing parent PAM configuration for resource '{resource.get('uid_ref') or resource.get('title')}'; "
        "set resources[].pam_configuration_uid_ref or declare exactly one pam_configurations[] entry"
    )


def _rotation_admin_uid(
    settings: Any,
    refs: _RotationRefResolver,
    source: Mapping[str, Any],
) -> str | None:
    data = _model_dump_dict(settings)
    admin_ref = next(
        (
            _non_empty_str(data.get(key))
            for key in (
                "admin_uid_ref",
                "admin_user_uid_ref",
                "administrative_credentials_uid_ref",
            )
            if _non_empty_str(data.get(key))
        ),
        None,
    )
    if not admin_ref:
        return None
    admin_type, admin_title = _desired_identity(source, admin_ref)
    return refs.resolve(
        uid_ref=admin_ref,
        title=admin_title,
        resource_type=admin_type or "pamUser",
        role="rotation admin user",
    )


def _rotation_schedule_args(schedule: Any) -> list[str]:
    data = _model_dump_dict(schedule)
    schedule_type = str(data.get("type") or "").strip().lower()
    if schedule_type == "on-demand":
        return ["--on-demand"]
    if schedule_type == "cron" and data.get("cron"):
        return ["--schedulecron", str(data["cron"])]
    return []


def _rotation_apply_is_enabled() -> bool:
    raw = os.environ.get(_ROTATION_APPLY_ENV_VAR)
    if raw is None or not raw.strip():
        return True
    return raw.strip().lower() in _TRUTHY_ENV_VALUES
