"""Internal helpers for the enterprise resource family.

Used by :class:`dsk.providers.commander_cli.CommanderCliProvider`.
Not a public API.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from dsk.providers.commander_cli import _TRUTHY_ENV_VALUES

_ENTERPRISE_BLOCKS = ("nodes", "users", "roles", "teams", "enforcements", "aliases")
_ENTERPRISE_STATUS = {
    "active": "active",
    "invited": "invited",
    "disabled": "disabled",
    "locked": "locked",
}


def _enterprise_manifest_from_commander_rows(
    *,
    nodes: list[dict[str, Any]],
    users: list[dict[str, Any]],
    roles: list[dict[str, Any]],
    teams: list[dict[str, Any]],
) -> dict[str, Any]:
    """Normalise ``enterprise-info`` JSON rows into keeper-enterprise.v1 shape."""

    node_uid_by_name: dict[str, list[str]] = {}
    node_uid_by_path: dict[str, str] = {}
    root_node_uid: str | None = None
    out_nodes: list[dict[str, Any]] = []

    for row in nodes:
        uid_ref = _enterprise_uid_ref("node", row.get("node_id") or row.get("id") or row.get("uid"))
        name = _enterprise_clean(row.get("name")) or uid_ref
        node_uid_by_name.setdefault(name.casefold(), []).append(uid_ref)
        if root_node_uid is None:
            root_node_uid = uid_ref

    for row in nodes:
        uid_ref = _enterprise_uid_ref("node", row.get("node_id") or row.get("id") or row.get("uid"))
        name = _enterprise_clean(row.get("name")) or uid_ref
        parent_name = _enterprise_clean(row.get("parent_node"))
        out: dict[str, Any] = {
            "uid_ref": uid_ref,
            "keeper_uid": str(row.get("node_id") or row.get("id") or uid_ref),
            "name": name,
        }
        if parent_name:
            parent_uid = _enterprise_unique_lookup(node_uid_by_name, parent_name)
            if parent_uid:
                out["parent_uid_ref"] = _enterprise_ref("nodes", parent_uid)
                node_uid_by_path[f"{parent_name}\\{name}".casefold()] = uid_ref
        else:
            node_uid_by_path[name.casefold()] = uid_ref
        out_nodes.append(out)

    def node_ref(value: Any) -> str | None:
        path = "\\".join(_enterprise_path_parts(value))
        if path:
            uid = node_uid_by_path.get(path.casefold())
            if uid:
                return _enterprise_ref("nodes", uid)
            last = _enterprise_path_parts(path)[-1]
            uid = _enterprise_unique_lookup(node_uid_by_name, last)
            if uid:
                return _enterprise_ref("nodes", uid)
        if root_node_uid:
            return _enterprise_ref("nodes", root_node_uid)
        return None

    user_uid_by_email: dict[str, str] = {}
    out_users: list[dict[str, Any]] = []
    for row in users:
        uid_ref = _enterprise_uid_ref("user", row.get("user_id") or row.get("id") or row.get("uid"))
        email = str(row.get("email") or "").strip()
        if email:
            user_uid_by_email[email.casefold()] = uid_ref
        out = {
            "uid_ref": uid_ref,
            "keeper_uid": str(row.get("user_id") or row.get("id") or uid_ref),
            "email": email or f"{uid_ref}@example.invalid",
        }
        name = _enterprise_clean(row.get("name"))
        if name:
            out["name"] = name
        nref = node_ref(row.get("node"))
        if nref:
            out["node_uid_ref"] = nref
        status = _ENTERPRISE_STATUS.get(str(row.get("status") or "").strip().lower())
        if status:
            out["status"] = status
        out_users.append(out)

    role_uid_by_name: dict[str, list[str]] = {}
    out_roles: list[dict[str, Any]] = []
    for row in roles:
        uid_ref = _enterprise_uid_ref("role", row.get("role_id") or row.get("id") or row.get("uid"))
        role_uid_by_name.setdefault(
            (_enterprise_clean(row.get("name")) or uid_ref).casefold(), []
        ).append(uid_ref)

    for row in roles:
        uid_ref = _enterprise_uid_ref("role", row.get("role_id") or row.get("id") or row.get("uid"))
        out = {
            "uid_ref": uid_ref,
            "keeper_uid": str(row.get("role_id") or row.get("id") or uid_ref),
            "name": _enterprise_clean(row.get("name")) or uid_ref,
            "node_uid_ref": node_ref(row.get("node"))
            or _enterprise_ref("nodes", root_node_uid or "root"),
        }
        user_refs = [
            _enterprise_ref("users", user_uid_by_email[email.casefold()])
            for email in _enterprise_string_list(row.get("users"))
            if email.casefold() in user_uid_by_email
        ]
        if user_refs:
            out["user_uid_refs"] = user_refs
        if "visible_below" in row:
            out["visible_below"] = _enterprise_bool(row.get("visible_below"))
        if "default_role" in row:
            out["new_user_inherit"] = _enterprise_bool(row.get("default_role"))
        if "admin" in row:
            out["manage_nodes"] = _enterprise_bool(row.get("admin"))
        out_roles.append(out)

    out_teams: list[dict[str, Any]] = []
    for row in teams:
        uid_ref = _enterprise_uid_ref(
            "team", row.get("team_uid") or row.get("id") or row.get("uid")
        )
        out = {
            "uid_ref": uid_ref,
            "keeper_uid": str(row.get("team_uid") or row.get("id") or uid_ref),
            "name": _enterprise_clean(row.get("name")) or uid_ref,
            "node_uid_ref": node_ref(row.get("node"))
            or _enterprise_ref("nodes", root_node_uid or "root"),
        }
        user_refs = [
            _enterprise_ref("users", user_uid_by_email[email.casefold()])
            for email in _enterprise_string_list(row.get("users"))
            if email.casefold() in user_uid_by_email
        ]
        if user_refs:
            out["user_uid_refs"] = user_refs
        role_refs: list[str] = []
        for role_name in _enterprise_string_list(row.get("roles")):
            hits = role_uid_by_name.get(role_name.casefold()) or []
            if len(hits) == 1:
                role_refs.append(_enterprise_ref("roles", hits[0]))
        if role_refs:
            out["role_uid_refs"] = role_refs
        restrict_tokens = set(str(row.get("restricts") or "").replace(",", " ").split())
        out["restrict_view"] = "R" in restrict_tokens
        out["restrict_edit"] = "W" in restrict_tokens
        out["restrict_share"] = "S" in restrict_tokens
        out_teams.append(out)

    return {
        "schema": "keeper-enterprise.v1",
        "nodes": out_nodes,
        "users": out_users,
        "roles": out_roles,
        "teams": out_teams,
        "enforcements": [],
        "aliases": [],
    }


def _enterprise_manifest_from_commander_payload(
    payload: Mapping[str, Any],
) -> dict[str, Any] | None:
    rows = {block: payload.get(block) for block in _ENTERPRISE_BLOCKS}
    if not any(isinstance(rows.get(block), list) for block in ("nodes", "users", "roles", "teams")):
        return None
    return _enterprise_manifest_from_commander_rows(
        nodes=[dict(row) for row in rows.get("nodes") or [] if isinstance(row, Mapping)],
        users=[dict(row) for row in rows.get("users") or [] if isinstance(row, Mapping)],
        roles=[dict(row) for row in rows.get("roles") or [] if isinstance(row, Mapping)],
        teams=[dict(row) for row in rows.get("teams") or [] if isinstance(row, Mapping)],
    )


def _enterprise_uid_ref(prefix: str, value: Any) -> str:
    raw = str(value or "").strip()
    token = re.sub(r"[^A-Za-z0-9_.:-]+", "-", raw).strip(".:-")
    return f"{prefix}.{token or 'unknown'}"


def _enterprise_ref(block: str, uid_ref: str) -> str:
    return f"keeper-enterprise:{block}:{uid_ref}"


def _enterprise_clean(value: Any) -> str:
    return " ".join(str(value or "").split())


def _enterprise_path_parts(value: Any) -> list[str]:
    return [
        _enterprise_clean(part) for part in str(value or "").split("\\") if _enterprise_clean(part)
    ]


def _enterprise_unique_lookup(index: Mapping[str, list[str]], name: str) -> str | None:
    hits = index.get(_enterprise_clean(name).casefold()) or []
    return hits[0] if len(hits) == 1 else None


def _enterprise_string_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [_enterprise_clean(item) for item in value if _enterprise_clean(item)]
    if isinstance(value, str) and value.strip():
        return [_enterprise_clean(value)]
    return []


def _enterprise_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in _TRUTHY_ENV_VALUES
    return bool(value)
