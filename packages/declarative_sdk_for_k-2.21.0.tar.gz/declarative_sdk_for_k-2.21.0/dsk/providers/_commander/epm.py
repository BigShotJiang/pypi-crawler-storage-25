"""Internal helpers for the EPM (Endpoint Privilege Management) policy resource family.

Used by :class:`dsk.providers.commander_cli.CommanderCliProvider`.
Not a public API.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome
from dsk.providers._commander.enterprise import _enterprise_bool
from dsk.providers._commander.workflow import _workflow_string_list
from dsk.providers.commander_cli import _commander_on_off

_EPM_VALID_POLICY_TYPES = {"elevation", "file_access", "command", "least_privilege"}
_EPM_VALID_CONTROLS = {"allow", "deny", "audit", "notify", "mfa", "justify", "approval"}


def _epm_policy_target(change: Change) -> str:
    for value in (
        change.keeper_uid,
        change.before.get("policy"),
        change.before.get("policy_uid"),
        change.before.get("name"),
        change.after.get("policy"),
        change.after.get("policy_uid"),
        change.after.get("name"),
        change.uid_ref,
        change.title,
    ):
        if value not in (None, ""):
            return str(value)
    raise CapabilityError(
        reason="EPM policy row is missing a policy UID or name",
        uid_ref=change.uid_ref,
        resource_type=change.resource_type,
        next_action="refresh the plan from an epm-policy.v1 or keeper-epm.v1 manifest",
    )


def _epm_policy_type(payload: Mapping[str, Any]) -> str:
    raw = str(payload.get("policy_type") or payload.get("type") or "elevation")
    value = raw.strip().replace("-", "_").lower()
    return value if value in _EPM_VALID_POLICY_TYPES else "elevation"


def _epm_controls(payload: Mapping[str, Any]) -> list[str]:
    raw = payload.get("control", payload.get("controls"))
    values = _workflow_string_list(raw)
    if not values:
        elevation_type = str(payload.get("elevation_type") or "").lower()
        if elevation_type == "approval":
            values = ["approval"]
        elif elevation_type == "denied":
            values = ["deny"]
        else:
            effect = str(payload.get("default_effect") or "").lower()
            values = [effect] if effect in {"allow", "deny", "audit"} else ["allow"]
    out: list[str] = []
    for value in values:
        control = str(value).strip().replace("-", "_").lower()
        if control == "elevate":
            control = "allow"
        if control in _EPM_VALID_CONTROLS and control not in out:
            out.append(control)
    return out or ["allow"]


def _epm_policy_name(change: Change) -> str:
    for value in (
        change.after.get("policy_name"),
        change.after.get("name"),
        change.before.get("policy_name"),
        change.before.get("name"),
        change.title,
        change.uid_ref,
    ):
        if value not in (None, ""):
            return str(value)
    return "dsk-epm-policy"


def _epm_policy_kwargs(change: Change, *, for_update: bool) -> dict[str, Any]:
    payload = change.after or change.before
    kwargs: dict[str, Any] = {}
    if for_update:
        kwargs["policy"] = _epm_policy_target(change)
    kwargs["policy_name"] = _epm_policy_name(change)
    kwargs["policy_type"] = _epm_policy_type(payload)
    kwargs["control"] = _epm_controls(payload)
    kwargs["status"] = str(payload.get("status") or "enforce")
    if payload.get("enable") not in (None, ""):
        kwargs["enable"] = _commander_on_off(_enterprise_bool(payload["enable"]))
    if payload.get("notification_message") not in (None, ""):
        kwargs["notification_message"] = str(payload["notification_message"])
    if payload.get("require_acknowledgement") not in (None, ""):
        kwargs["require_acknowledgement"] = _commander_on_off(
            _enterprise_bool(payload["require_acknowledgement"])
        )
    for source_key, commander_key in (
        ("user_filter", "user_filter"),
        ("target_users", "user_filter"),
        ("machine_filter", "machine_filter"),
        ("app_filter", "app_filter"),
        ("application_patterns", "app_filter"),
        ("date_filter", "date_filter"),
        ("time_filter", "time_filter"),
        ("day_filter", "day_filter"),
        ("risk_level", "risk_level"),
    ):
        value = payload.get(source_key)
        if value not in (None, ""):
            kwargs[commander_key] = (
                _workflow_string_list(value) if commander_key != "risk_level" else int(value or 0)
            )
    return kwargs


def _epm_dry_run_outcome(change: Change, kwargs: Mapping[str, Any], action: str) -> ApplyOutcome:
    return ApplyOutcome(
        uid_ref=change.uid_ref or "",
        keeper_uid=change.keeper_uid or _epm_policy_target(change),
        action="would_apply",
        details={"dry_run": True, "would": action, "kwargs": dict(kwargs)},
    )
