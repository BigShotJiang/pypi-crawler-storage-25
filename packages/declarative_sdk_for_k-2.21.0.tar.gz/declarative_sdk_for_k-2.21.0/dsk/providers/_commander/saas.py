"""Internal helpers for the SaaS rotation resource family.

Used by :class:`dsk.providers.commander_cli.CommanderCliProvider`.
Not a public API.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome
from dsk.providers.commander_cli import _ref_leaf


def _saas_value(change: Change, *keys: str) -> Any:
    for payload in (change.after, change.before):
        for key in keys:
            value = payload.get(key)
            if value not in (None, ""):
                return value
    return None


def _saas_gateway(change: Change) -> str:
    value = _saas_value(change, "gateway", "gateway_uid", "gateway_uid_ref")
    if value in (None, ""):
        raise CapabilityError(
            reason="keeper-saas-rotation.v1 command requires a gateway",
            uid_ref=change.uid_ref,
            resource_type=change.resource_type,
            next_action="add gateway or gateway_uid_ref to the SaaS rotation plan row",
        )
    return str(value)


def _saas_config_kwargs(change: Change) -> dict[str, Any]:
    after = change.after
    plugin = after.get("plugin") or after.get("plugin_name") or after.get("provider")
    if plugin in (None, ""):
        raise CapabilityError(
            reason="keeper-saas-rotation.v1 config row is missing provider/plugin",
            uid_ref=change.uid_ref,
            resource_type=change.resource_type,
            next_action="set rotations[].provider to a Commander SaaS plugin name",
        )
    kwargs: dict[str, Any] = {
        "gateway": _saas_gateway(change),
        "plugin": str(plugin),
        "do_create": True,
    }
    configuration_uid = after.get("configuration_uid") or after.get("pam_config_uid_ref")
    if configuration_uid not in (None, ""):
        kwargs["configuration_uid"] = str(configuration_uid)
    shared_folder_uid = after.get("shared_folder_uid")
    if shared_folder_uid not in (None, ""):
        kwargs["shared_folder_uid"] = str(shared_folder_uid)
    return kwargs


def _saas_update_kwargs(change: Change) -> dict[str, Any]:
    config_uid = _saas_value(
        change,
        "config_uid",
        "config_record_uid",
        "saas_config_record_uid",
        "keeper_uid",
    )
    if config_uid in (None, ""):
        config_uid = change.keeper_uid
    kwargs: dict[str, Any] = {"gateway": _saas_gateway(change)}
    if config_uid not in (None, ""):
        kwargs["config_uid"] = str(config_uid)
    else:
        kwargs["do_all"] = True
    configuration_uid = _saas_value(change, "configuration_uid", "pam_config_uid_ref")
    if configuration_uid not in (None, ""):
        kwargs["configuration_uid"] = str(configuration_uid)
    return kwargs


def _saas_set_kwargs(change: Change) -> dict[str, Any]:
    config_uid = _saas_value(change, "config_record_uid", "saas_config_record_uid")
    if config_uid in (None, ""):
        config_uid = change.keeper_uid or _ref_leaf(
            _saas_value(change, "rotation_uid_ref"),
            "keeper-saas-rotation:rotations:",
        )
    user_uid = _saas_value(change, "user_uid", "record_uid_ref", "record_uid")
    if user_uid in (None, ""):
        raise CapabilityError(
            reason="keeper-saas-rotation.v1 binding row is missing user_uid/record_uid_ref",
            uid_ref=change.uid_ref,
            resource_type=change.resource_type,
            next_action="set bindings[].record_uid_ref to the PAM user record UID",
        )
    if config_uid in (None, ""):
        raise CapabilityError(
            reason="keeper-saas-rotation.v1 binding row is missing config_record_uid",
            uid_ref=change.uid_ref,
            resource_type=change.resource_type,
            next_action="include the SaaS configuration record UID on the binding row",
        )
    return {
        "user_uid": _ref_leaf(user_uid, "keeper-vault:records:"),
        "config_record_uid": _ref_leaf(config_uid, "keeper-vault:records:"),
    }


def _saas_remove_kwargs(change: Change) -> dict[str, Any]:
    user_uid = _saas_value(change, "user_uid", "record_uid_ref", "record_uid")
    if user_uid in (None, ""):
        user_uid = change.keeper_uid or change.uid_ref or change.title
    kwargs: dict[str, Any] = {"user_uid": _ref_leaf(user_uid, "keeper-vault:records:")}
    resource_uid = _saas_value(change, "resource_uid", "resource_uid_ref")
    if resource_uid not in (None, ""):
        kwargs["resource_uid"] = _ref_leaf(resource_uid, "keeper-vault:records:")
    return kwargs


def _saas_dry_run_outcome(change: Change, kwargs: Mapping[str, Any], action: str) -> ApplyOutcome:
    return ApplyOutcome(
        uid_ref=change.uid_ref or "",
        keeper_uid=str(change.keeper_uid or ""),
        action="would_apply",
        details={"dry_run": True, "would": action, "kwargs": dict(kwargs)},
    )


def _saas_plugin_entry_as_dict(entry: Any) -> dict[str, Any]:
    if isinstance(entry, dict):
        return entry
    if hasattr(entry, "model_dump"):
        return entry.model_dump()
    return {
        "plugin_name": getattr(entry, "plugin_name", None),
        "config": getattr(entry, "config", None) or {},
        "config_record_uid": getattr(entry, "config_record_uid", None),
    }


def _saas_plugin_key(entry: Any) -> tuple[str, str]:
    data = _saas_plugin_entry_as_dict(entry)
    name = str(data.get("plugin_name") or "")
    cfg = str(data.get("config_record_uid") or "")
    return name, cfg


def _plugins_removed(before_list: Any, after_list: Any) -> list[dict[str, Any]]:
    if not isinstance(before_list, list):
        before_list = []
    if not isinstance(after_list, list):
        after_list = []
    after_keys = {_saas_plugin_key(p) for p in after_list}
    removed: list[dict[str, Any]] = []
    for item in before_list:
        if _saas_plugin_key(item) not in after_keys:
            removed.append(_saas_plugin_entry_as_dict(item))
    return removed
