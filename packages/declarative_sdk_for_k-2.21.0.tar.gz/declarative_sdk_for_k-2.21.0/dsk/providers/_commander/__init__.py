"""Internal helper sub-package for :mod:`dsk.providers.commander_cli`.

The leading-underscore name signals that the modules in this package are
*not* a public API. They exist only to keep ``commander_cli.py`` small by
hosting the per-resource-family module-level helpers (MSP, KSM, rotation,
workflow, SaaS rotation, EPM, PAM extended, enterprise) that the
:class:`~dsk.providers.commander_cli.CommanderCliProvider` calls
from its method bodies. ``commander_cli.py`` re-imports the symbols from
each family module so that ``commander_cli._helper_name`` continues to
work for tests and for sibling production modules.
"""
