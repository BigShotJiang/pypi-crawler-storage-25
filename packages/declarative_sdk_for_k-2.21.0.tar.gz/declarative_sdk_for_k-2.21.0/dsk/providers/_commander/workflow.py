"""Internal helpers for the workflow gate / approval resource family.

Used by :class:`dsk.providers.commander_cli.CommanderCliProvider`.
Not a public API.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome
from dsk.providers._commander.enterprise import _enterprise_bool
from dsk.providers.commander_cli import _ref_leaf, _source_dict


def _workflow_approver_index(source: Any) -> dict[str, str]:
    data = _source_dict(source)
    out: dict[str, str] = {}
    for row in data.get("approvers") or []:
        if not isinstance(row, Mapping):
            continue
        uid_ref = row.get("uid_ref")
        email = row.get("email")
        if uid_ref in (None, "") or email in (None, ""):
            continue
        uid = str(uid_ref)
        value = str(email)
        out[uid] = value
        out[f"keeper-workflow:approvers:{uid}"] = value
    return out


def _workflow_string_list(value: Any) -> list[str]:
    if value in (None, ""):
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        out: list[str] = []
        for item in value:
            if item in (None, ""):
                continue
            if isinstance(item, Mapping):
                for key in ("email", "name", "uid_ref"):
                    if item.get(key) not in (None, ""):
                        out.append(str(item[key]))
                        break
            else:
                out.append(str(item))
        return out
    return [str(value)]


def _workflow_approvers(change: Change, source: Any) -> list[str]:
    index = _workflow_approver_index(source)
    after = change.after
    raw = (
        after.get("approvers")
        or after.get("approver")
        or after.get("approver_emails")
        or after.get("approver_uid_refs")
        or []
    )
    out: list[str] = []
    for item in _workflow_string_list(raw):
        mapped = index.get(item, item)
        if mapped and mapped not in out:
            out.append(mapped)
    return out


def _workflow_record(change: Change) -> str:
    for payload in (change.after, change.before):
        for key in (
            "pam_config_uid_ref",
            "record_uid_ref",
            "resource_uid_ref",
            "record",
            "record_uid",
        ):
            value = payload.get(key)
            if value not in (None, ""):
                return _ref_leaf(value, "keeper-vault:records:")
    for value in (change.keeper_uid, change.uid_ref, change.title):
        if value not in (None, ""):
            return _ref_leaf(value, "keeper-vault:records:")
    raise CapabilityError(
        reason="keeper-workflow.v1 workflow row is missing a PAM record UID",
        uid_ref=change.uid_ref,
        resource_type=change.resource_type,
        next_action="set pam_config_uid_ref, record_uid_ref, or resource_uid_ref on the workflow row",
    )


def _workflow_duration(value: Any) -> str | None:
    if value in (None, ""):
        return None
    if isinstance(value, int):
        return f"{value}m"
    return str(value)


def _workflow_command_kwargs(
    change: Change, source: Any, *, include_defaults: bool
) -> dict[str, Any]:
    after = change.after
    approvers = _workflow_approvers(change, source)
    kwargs: dict[str, Any] = {"record": _workflow_record(change)}

    approvals = after.get("approvals_needed")
    if approvals is None and include_defaults:
        approvals = len(approvers) if approvers else 0
    if approvals is not None:
        kwargs["approvals_needed"] = int(approvals)

    if approvers:
        kwargs["approver"] = approvers

    bool_keys = (
        ("checkout", "checkout"),
        ("checkout_needed", "checkout"),
        ("start_on_approval", "start_on_approval"),
        ("start_access_on_approval", "start_on_approval"),
        ("require_reason", "require_reason"),
        ("require_ticket", "require_ticket"),
        ("require_mfa", "require_mfa"),
    )
    for source_key, commander_key in bool_keys:
        if after.get(source_key) is not None:
            kwargs[commander_key] = _enterprise_bool(after[source_key])

    duration = _workflow_duration(
        after.get("duration", after.get("access_duration", after.get("access_length")))
    )
    if duration is None and include_defaults:
        duration = "1d"
    if duration is not None:
        kwargs["duration"] = duration

    allowed_days = after.get("allowed_days")
    if isinstance(allowed_days, list) and allowed_days:
        kwargs["allowed_days"] = ",".join(str(day).lower() for day in allowed_days)
    elif allowed_days not in (None, ""):
        kwargs["allowed_days"] = str(allowed_days)

    time_range = after.get("time_range")
    if time_range in (None, "") and after.get("allowed_from_time") and after.get("allowed_to_time"):
        time_range = f"{after['allowed_from_time']}-{after['allowed_to_time']}"
    if time_range not in (None, ""):
        kwargs["time_range"] = str(time_range)

    timezone = after.get("timezone", after.get("allowed_timezone"))
    if timezone not in (None, ""):
        kwargs["timezone"] = str(timezone)
    return kwargs


def _workflow_dry_run_outcome(
    change: Change, kwargs: Mapping[str, Any], action: str
) -> ApplyOutcome:
    return ApplyOutcome(
        uid_ref=change.uid_ref or "",
        keeper_uid=str(kwargs.get("record") or change.keeper_uid or ""),
        action="would_apply",
        details={"dry_run": True, "would": action, "kwargs": dict(kwargs)},
    )
