"""Internal helpers for the extended PAM (rotation schedule / discovery rule) family.

Used by :class:`dsk.providers.commander_cli.CommanderCliProvider`.
Not a public API.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.planner import Plan
from dsk.providers.commander_cli import _ref_leaf

_PAM_EXTENDED_ROTATION_SCHEDULE = "pam_extended_rotation_schedule"
_PAM_EXTENDED_DISCOVERY_RULE = "pam_extended_discovery_rule"
_PAM_EXTENDED_SUPPORTED_TYPES = {
    _PAM_EXTENDED_ROTATION_SCHEDULE,
    _PAM_EXTENDED_DISCOVERY_RULE,
}
_PAM_EXTENDED_CONFIG_KEYS = (
    "config_uid",
    "config_uid_ref",
    "configuration_uid",
    "configuration_uid_ref",
    "pam_configuration_uid",
    "pam_configuration_uid_ref",
)


def _pam_extended_plan_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    seen = {id(change) for change in ordered}
    return ordered + [change for change in plan.changes if id(change) not in seen]


def _pam_extended_change_name(change: Change) -> str:
    for payload in (change.after, change.before):
        value = payload.get("name") or payload.get("title")
        if value not in (None, ""):
            return str(value)
    return str(change.uid_ref or change.title)


def _pam_extended_payload_value(change: Change, *keys: str) -> Any:
    for payload in (change.after, change.before):
        for key in keys:
            value = payload.get(key)
            if value not in (None, "", []):
                return value
    return None


def _pam_extended_clean_ref(value: Any) -> str:
    raw = str(value or "")
    for prefix in (
        "keeper-vault:records:",
        "keeper-pam-extended:resources:",
        "keeper-pam-extended:gateway_configs:",
        "keeper-pam-extended:rotation_schedules:",
        "keeper-pam-extended:discovery_rules:",
    ):
        raw = _ref_leaf(raw, prefix)
    return raw


def _pam_extended_first_ref(value: Any) -> str | None:
    values = value if isinstance(value, list | tuple) else [value]
    for item in values:
        if item not in (None, ""):
            return _pam_extended_clean_ref(item)
    return None


def _pam_extended_config_uid(change: Change, *, rule: bool = False) -> str:
    value = _pam_extended_payload_value(change, *_PAM_EXTENDED_CONFIG_KEYS)
    if value not in (None, ""):
        return _pam_extended_clean_ref(value)
    if rule:
        scan_network = _pam_extended_payload_value(change, "scan_network")
        if isinstance(scan_network, str) and scan_network.strip():
            return _pam_extended_clean_ref(scan_network)
        credential_ref = _pam_extended_payload_value(change, "credential_uid_ref")
        if credential_ref not in (None, ""):
            return _pam_extended_clean_ref(credential_ref)
    ref_list = _pam_extended_payload_value(change, "resource_uid_refs", "record_refs")
    first_ref = _pam_extended_first_ref(ref_list)
    if first_ref:
        return first_ref
    raise CapabilityError(
        reason=f"{change.resource_type} requires a PAM configuration UID for Commander apply",
        uid_ref=change.uid_ref,
        resource_type=change.resource_type,
        next_action=(
            "include config_uid/config_uid_ref in the planned payload, or extend "
            "keeper-pam-extended.v1 with a first-class config UID field"
        ),
    )


def _pam_extended_schedule_cron(change: Change) -> str:
    value = _pam_extended_payload_value(change, "cron_expr", "cron")
    if value not in (None, ""):
        return str(value)
    schedule = _pam_extended_payload_value(change, "schedule")
    if isinstance(schedule, Mapping):
        cron = schedule.get("cron")
        if cron not in (None, ""):
            return str(cron)
    raise CapabilityError(
        reason="Extended PAM rotation schedule requires cron_expr for Commander apply",
        uid_ref=change.uid_ref,
        resource_type=change.resource_type,
        next_action="set rotation_schedules[].cron_expr before applying with Commander",
    )


def _pam_extended_rule_type(change: Change) -> str:
    value = _pam_extended_payload_value(change, "type", "target_type", "resource_kind")
    if value not in (None, ""):
        text = str(value).strip().lower()
        return {"database": "db"}.get(text, text)
    protocol = _pam_extended_payload_value(change, "protocol")
    if protocol not in (None, ""):
        text = str(protocol).strip().lower()
        if text == "database":
            return "db"
        if text in {"ssh", "rdp"}:
            return "machine"
    return "machine"


def _pam_extended_rule_pattern(change: Change) -> str:
    value = _pam_extended_payload_value(change, "pattern", "match_value", "target_cidr")
    if value not in (None, ""):
        return str(value)
    return "*"


def _pam_extended_command_spec(change: Change) -> tuple[str, str, dict[str, Any], list[str]]:
    name = _pam_extended_change_name(change)
    if change.resource_type == _PAM_EXTENDED_ROTATION_SCHEDULE:
        if change.kind is ChangeKind.DELETE:
            return (
                "keepercommander.commands.pam_extended.schedule_commands",
                "PAMExtendedScheduleDeleteCommand",
                {"name": name},
                ["pam", "extended", "schedule", "delete", name],
            )
        cron = _pam_extended_schedule_cron(change)
        config_uid = _pam_extended_config_uid(change)
        kwargs: dict[str, Any] = {
            "name": name,
            "cron": cron,
            "config_uid": config_uid,
        }
        for key in ("resource_uid_refs", "record_refs", "notify_emails"):
            value = change.after.get(key)
            if value not in (None, "", []):
                kwargs[key] = value
        return (
            "keepercommander.commands.pam_extended.schedule_commands",
            "PAMExtendedScheduleCreateCommand",
            kwargs,
            [
                "pam",
                "extended",
                "schedule",
                "create",
                name,
                "--cron",
                cron,
                "--config-uid",
                config_uid,
            ],
        )
    if change.resource_type == _PAM_EXTENDED_DISCOVERY_RULE:
        if change.kind is ChangeKind.DELETE:
            return (
                "keepercommander.commands.pam_extended.discovery_rule_commands",
                "PAMExtendedRuleDeleteCommand",
                {"name_or_uid": name},
                ["pam", "extended", "rule", "delete", name],
            )
        rule_type = _pam_extended_rule_type(change)
        pattern = _pam_extended_rule_pattern(change)
        config_uid = _pam_extended_config_uid(change, rule=True)
        kwargs = {
            "name": name,
            "rule_type": rule_type,
            "pattern": pattern,
            "config_uid": config_uid,
        }
        for key in ("protocol", "target_cidr", "credential_uid_ref"):
            value = change.after.get(key)
            if value not in (None, "", []):
                kwargs[key] = value
        return (
            "keepercommander.commands.pam_extended.discovery_rule_commands",
            "PAMExtendedRuleCreateCommand",
            kwargs,
            [
                "pam",
                "extended",
                "rule",
                "create",
                name,
                "--type",
                rule_type,
                "--pattern",
                pattern,
                "--config-uid",
                config_uid,
            ],
        )
    raise CapabilityError(
        reason=f"{change.resource_type} is not supported by pam extended Commander apply",
        uid_ref=change.uid_ref,
        resource_type=change.resource_type,
        next_action="apply only rotation_schedules and discovery_rules through pam extended",
    )
