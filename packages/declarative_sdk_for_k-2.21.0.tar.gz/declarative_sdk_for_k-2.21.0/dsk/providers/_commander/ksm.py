"""Internal helpers for the KSM (Keeper Secrets Manager) resource family.

Used by :class:`dsk.providers.commander_cli.CommanderCliProvider`.
Not a public API.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from dsk.core.diff import Change
from dsk.core.planner import Plan
from dsk.providers._commander.enterprise import _enterprise_bool
from dsk.providers.commander_cli import _ref_leaf

_KSM_UPSTREAM_GAP_NEXT_ACTIONS = {
    "ksm_client_access": (
        "Commander 18.0.0 has no `secrets-manager client update --lock-ip`, "
        "`secrets-manager client update --unlock-ip`, or "
        "`secrets-manager access update --allowed-ip` verb; use the Secrets Manager "
        "console or recreate the client device with `secrets-manager client add --unlock-ip`"
    ),
    "ksm_access_record": (
        "Commander 18.0.0 has no `secrets-manager access update --allowed-ip` or "
        "`secrets-manager access lock/unlock` verb; use the Secrets Manager console"
    ),
    "ksm_secret_metadata": (
        "Commander 18.0.0 has no `secrets-manager secret move` or "
        "`secrets-manager secret folder update` verb; manage vault folder placement "
        "through keeper-vault manifests or the Keeper UI"
    ),
    "ksm_secret_folder_placement": (
        "Commander 18.0.0 has no `secrets-manager secret move` or "
        "`secrets-manager secret folder update` verb; manage vault folder placement "
        "through keeper-vault manifests or the Keeper UI"
    ),
    "ksm_master_key_rotation": (
        "Commander 18.0.0 has no `secrets-manager app rotate-key` or "
        "`secrets-manager master-key rotate` verb; use the Secrets Manager console"
    ),
    "ksm_event_query": (
        "Commander 18.0.0 has no `secrets-manager event list --format json` or "
        "`secrets-manager audit list --format json` verb; use Keeper reporting APIs "
        "outside declarative apply"
    ),
    "ksm_audit_query": (
        "Commander 18.0.0 has no `secrets-manager event list --format json` or "
        "`secrets-manager audit list --format json` verb; use Keeper reporting APIs "
        "outside declarative apply"
    ),
}


def _ksm_plan_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    seen = {id(change) for change in ordered}
    return ordered + [change for change in plan.changes if id(change) not in seen]


def _ksm_change_name(change: Change) -> str:
    for payload in (change.after, change.before):
        value = payload.get("name")
        if value is not None:
            return str(value)
    return str(change.uid_ref or change.title)


def _ksm_change_bool(change: Change, key: str, *, default: bool = False) -> bool:
    for payload in (change.after, change.before):
        value = payload.get(key)
        if value is not None:
            return _enterprise_bool(value)
    return default


def _ksm_upstream_gap_next_action(resource_type: str) -> str | None:
    return _KSM_UPSTREAM_GAP_NEXT_ACTIONS.get(resource_type)


def _ksm_share_keeper_uids(change: Change) -> tuple[str, str]:
    keeper_uid = str(change.keeper_uid or "")
    if "|" in keeper_uid:
        app_uid, secret_uid = keeper_uid.split("|", 1)
        if app_uid and secret_uid:
            return app_uid, secret_uid
    app_ref = change.after.get("app_uid_ref") or change.before.get("app_uid_ref")
    secret_ref = (
        change.after.get("secret_uid_ref")
        or change.before.get("secret_uid_ref")
        or change.after.get("record_uid_ref")
        or change.before.get("record_uid_ref")
        or change.after.get("shared_folder_uid_ref")
        or change.before.get("shared_folder_uid_ref")
    )
    secret_uid = _ref_leaf(secret_ref, "keeper-vault:records:")
    secret_uid = _ref_leaf(secret_uid, "keeper-vault-sharing:shared_folders:")
    secret_uid = _ref_leaf(secret_uid, "keeper-vault:shared-folders:")
    secret_uid = _ref_leaf(secret_uid, "keeper-vault:shared_folders:")
    return (_ref_leaf(app_ref, "keeper-ksm:apps:"), secret_uid)


def _ksm_client_app_uid(change: Change) -> str:
    for payload in (change.after, change.before):
        app_ref = payload.get("app_uid_ref") or payload.get("app_uid")
        if app_ref:
            return _ref_leaf(app_ref, "keeper-ksm:apps:")
    keeper_uid = str(change.keeper_uid or "")
    if "|" in keeper_uid:
        app_uid, _ = keeper_uid.split("|", 1)
        return app_uid
    return ""


def _ksm_client_identifiers(change: Change) -> list[str]:
    values: list[Any] = []
    for payload in (change.after, change.before):
        for key in ("client_ids", "client_names", "clients"):
            raw = payload.get(key)
            if isinstance(raw, list):
                values.extend(raw)
            elif raw not in (None, ""):
                values.append(raw)
        for key in ("client_id", "client_name", "name"):
            raw = payload.get(key)
            if raw not in (None, ""):
                values.append(raw)
    keeper_uid = str(change.keeper_uid or "")
    if "|" in keeper_uid:
        _, client_uid = keeper_uid.split("|", 1)
        if client_uid:
            values.append(client_uid)
    return list(dict.fromkeys(str(value) for value in values if str(value).strip()))


def _ksm_create_result_uid(result: Any) -> str | None:
    if isinstance(result, Mapping):
        for key in ("app_uid", "uid", "record_uid", "application_uid"):
            value = result.get(key)
            if value:
                return str(value)
        return None
    if isinstance(result, str) and result.strip():
        try:
            decoded = json.loads(result)
        except ValueError:
            return None
        return _ksm_create_result_uid(decoded)
    return None


def _ksm_app_record_uid(record: Any) -> str | None:
    if isinstance(record, Mapping):
        for key in ("record_uid", "app_uid", "uid", "application_uid"):
            value = record.get(key)
            if value:
                return str(value)
    for attr in ("record_uid", "app_uid", "uid", "application_uid"):
        value = getattr(record, attr, None)
        if value:
            return str(value)
    return None
