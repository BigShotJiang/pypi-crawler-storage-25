"""REST-backed provider for ``keeper-siem.v1``."""

from __future__ import annotations

from typing import Any

from dsk.core.errors import CapabilityError
from dsk.core.models_siem import SIEM_FAMILY, SiemManifestV1
from dsk.core.planner import Plan, build_plan
from dsk.core.siem_diff import compute_siem_diff
from dsk.providers.rest_provider_base import (
    KeeperRestProvider,
    config_from_response,
    configuration_from_plan,
    endpoint_from_env_or_override,
    outcomes_from_plan,
    plan_has_mutations,
)

_BLOCKS = ("sinks", "routes")
_RESOURCE_TO_BLOCK = {
    "siem_sink": "sinks",
    "siem_route": "routes",
}
_NEXT_ACTION = (
    "Keeper needs to ship or document SIEM configuration read/write REST verbs; "
    "until then set DSK_KEEPER_SIEM_ENDPOINT_BASE or DSK_KEEPER_SIEM_READ_ENDPOINT/"
    "DSK_KEEPER_SIEM_WRITE_ENDPOINT for a lab-proven endpoint"
)


class SiemProvider(KeeperRestProvider):
    """Plan/apply SIEM configuration through Keeper REST when endpoints are configured."""

    def __init__(self, *, endpoint_base: str | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._endpoint_base = endpoint_base

    def plan(self, manifest: SiemManifestV1, *, allow_delete: bool = False) -> Plan:
        self._last_desired_config = _desired_config(manifest)
        try:
            live = self.discover_siem_configuration()
        except CapabilityError as exc:
            if "endpoint is not confirmed" not in (exc.reason or ""):
                raise
            live = {}
        changes = compute_siem_diff(
            manifest,
            live,
            manifest_name=self._manifest_name or manifest.name or SIEM_FAMILY,
            allow_delete=allow_delete,
        )
        return build_plan(
            self._manifest_name or manifest.name or SIEM_FAMILY, changes, _order(manifest)
        )

    def apply(self, manifest: SiemManifestV1, *, dry_run: bool = False) -> list[Any]:
        return self.apply_siem_plan(self.plan(manifest), dry_run=dry_run)

    def discover_siem_configuration(self) -> dict[str, Any]:
        # ENDPOINT-UNKNOWN: public docs describe Admin Console SIEM setup, but not
        # a stable Commander REST readback verb. The path is override-driven.
        endpoint = self._endpoint(read=True)
        response = self._rest_post(endpoint, {"method": "GET", "family": SIEM_FAMILY})
        return config_from_response(response, blocks=_BLOCKS)

    def apply_siem_plan(self, plan: Plan, *, dry_run: bool = False) -> list[Any]:
        if dry_run or not plan_has_mutations(plan):
            return outcomes_from_plan(plan, dry_run=dry_run, family=SIEM_FAMILY)
        # ENDPOINT-UNKNOWN: see discover_siem_configuration.
        endpoint = self._endpoint(read=False)
        config = getattr(
            self,
            "_last_desired_config",
            configuration_from_plan(plan, resource_to_block=_RESOURCE_TO_BLOCK),
        )
        self._rest_post(
            endpoint,
            {"method": "PUT", "family": SIEM_FAMILY, "configuration": config},
        )
        return outcomes_from_plan(plan, dry_run=dry_run, family=SIEM_FAMILY, endpoint=endpoint)

    def _endpoint(self, *, read: bool) -> str:
        return endpoint_from_env_or_override(
            read=read,
            family=SIEM_FAMILY,
            endpoint_base=self._endpoint_base,
            base_env="DSK_KEEPER_SIEM_ENDPOINT_BASE",
            read_env="DSK_KEEPER_SIEM_READ_ENDPOINT",
            write_env="DSK_KEEPER_SIEM_WRITE_ENDPOINT",
            next_action=_NEXT_ACTION,
        )


def _order(manifest: SiemManifestV1) -> list[str]:
    return [uid_ref for uid_ref, _kind in manifest.iter_uid_refs()]


def _desired_config(manifest: SiemManifestV1) -> dict[str, Any]:
    data = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    return {block: data.get(block) or [] for block in _BLOCKS}


__all__ = ["SiemProvider"]
