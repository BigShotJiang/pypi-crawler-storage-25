"""Shared Keeper REST helpers for declarative provider slices."""

from __future__ import annotations

import base64
import json
import os
from collections.abc import Mapping
from typing import Any

from google.protobuf import json_format
from google.protobuf.message import Message
from google.protobuf.struct_pb2 import Struct

from dsk.auth import EnvLoginHelper, KsmLoginHelper, LoginHelper, load_helper_from_path
from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome
from dsk.core.planner import Plan


class KeeperRestProvider:
    """Thin base for Keeper REST providers backed by Commander ``KeeperParams``."""

    def __init__(
        self,
        *,
        manifest_name: str | None = None,
        manifest_source: Mapping[str, Any] | None = None,
        keeper_params: Any | None = None,
        timeout: int | None = None,
    ) -> None:
        self._manifest_name = manifest_name
        self._manifest_source = dict(manifest_source or {})
        self._keeper_params = keeper_params
        self._keeper_login_attempted = keeper_params is not None
        self._timeout = timeout

    def unsupported_capabilities(self, manifest: object = None) -> list[str]:  # noqa: ARG002
        return []

    def check_tenant_bindings(self, manifest: object = None) -> list[str]:  # noqa: ARG002
        return []

    def discover(self) -> list[Any]:
        return []

    def _get_keeper_params(self) -> Any:
        if self._keeper_params is not None:
            return self._keeper_params
        if self._keeper_login_attempted:
            raise CapabilityError(
                reason="in-process Commander login previously failed; cannot retry without a new provider",
                next_action="re-run with a valid admin config + KSM credentials available",
            )
        self._keeper_login_attempted = True

        helper_path = os.environ.get("KEEPER_SDK_LOGIN_HELPER")
        helper: LoginHelper
        try:
            if helper_path == "ksm":
                helper = KsmLoginHelper()
            elif helper_path:
                helper = load_helper_from_path(helper_path)
            else:
                helper = EnvLoginHelper()
            creds = helper.load_keeper_creds()
            email = creds["email"] if isinstance(creds, dict) else creds[0]
            password = creds["password"] if isinstance(creds, dict) else creds[1]
            totp_secret = creds["totp_secret"] if isinstance(creds, dict) else creds[2]
            extra = {
                k: v
                for k, v in (creds.items() if isinstance(creds, dict) else [])
                if k not in {"email", "password", "totp_secret"}
            }
            self._keeper_params = helper.keeper_login(email, password, totp_secret, **extra)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process Commander login failed: {type(exc).__name__}: {exc}",
                next_action="verify credentials are reachable; see docs/LOGIN.md",
            ) from exc
        return self._keeper_params

    def _rest_post(self, endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        """POST a dict payload through Commander ``communicate_rest`` and return a dict."""
        try:
            from keepercommander import api
        except ImportError as exc:
            raise CapabilityError(
                reason=f"Keeper REST provider requires keepercommander: {exc}",
                next_action="pip install 'keepercommander>=18.0.0,<19'",
            ) from exc

        request = Struct()
        request.update(_json_safe(payload))
        normalised_endpoint = endpoint.lstrip("/")
        try:
            response = api.communicate_rest(
                self._get_keeper_params(),
                request,
                normalised_endpoint,
                timeout=self._timeout,
            )
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=(
                    f"Keeper REST call failed for endpoint '{normalised_endpoint}': "
                    f"{type(exc).__name__}: {exc}"
                ),
                next_action="verify the endpoint, admin role permissions, and Keeper session",
            ) from exc
        return _response_to_dict(response)


def endpoint_from_env_or_override(
    *,
    read: bool,
    family: str,
    endpoint_base: str | None,
    base_env: str,
    read_env: str,
    write_env: str,
    default_base: str | None = None,
    next_action: str,
) -> str:
    specific = os.environ.get(read_env if read else write_env)
    base = specific or os.environ.get(base_env) or endpoint_base or default_base
    if not base:
        verb = "read" if read else "write"
        raise CapabilityError(
            reason=f"{family} {verb} endpoint is not confirmed in Keeper Commander REST APIs",
            next_action=next_action,
        )
    return base.lstrip("/")


def config_from_response(
    response: Mapping[str, Any],
    *,
    blocks: tuple[str, ...],
    singleton_blocks: tuple[str, ...] = (),
    config_key: str = "configuration",
) -> dict[str, Any]:
    if isinstance(response.get(config_key), Mapping):
        source = response[config_key]
    elif isinstance(response.get("manifest"), Mapping):
        source = response["manifest"]
    else:
        source = response
    out: dict[str, Any] = {}
    for block in blocks:
        value = source.get(block)
        if block in singleton_blocks:
            out[block] = dict(value) if isinstance(value, Mapping) else None
        else:
            out[block] = list(value or [])
    return out


def configuration_from_plan(
    plan: Plan,
    *,
    resource_to_block: Mapping[str, str],
    singleton_blocks: tuple[str, ...] = (),
) -> dict[str, Any]:
    config: dict[str, Any] = {}
    for block in dict.fromkeys(resource_to_block.values()):
        config[block] = None if block in singleton_blocks else []
    for change in plan.changes:
        block_or_none: str | None = resource_to_block.get(change.resource_type)
        if block_or_none is None or change.kind is ChangeKind.DELETE:
            continue
        block = block_or_none
        payload = change.after or change.before
        if not payload:
            continue
        if block in singleton_blocks:
            config[block] = _json_safe(dict(payload))
        else:
            config.setdefault(block, []).append(_json_safe(dict(payload)))
    return config


def outcomes_from_plan(
    plan: Plan,
    *,
    dry_run: bool,
    family: str,
    endpoint: str | None = None,
) -> list[ApplyOutcome]:
    outcomes: list[ApplyOutcome] = []
    for change in plan.ordered():
        details: dict[str, Any] = {"dry_run": dry_run, "family": family}
        if endpoint is not None:
            details["endpoint"] = endpoint
        if change.reason:
            details["reason"] = change.reason
        action = change.kind.value
        if change.kind is ChangeKind.SKIP:
            action = "noop"
        outcomes.append(
            ApplyOutcome(
                uid_ref=change.uid_ref or "",
                keeper_uid=change.keeper_uid or "",
                action=action,
                details=details,
            )
        )
    return outcomes


def plan_has_mutations(plan: Plan) -> bool:
    return bool(plan.creates or plan.updates or plan.deletes)


def _response_to_dict(response: Any) -> dict[str, Any]:
    if response is None:
        return {}
    if isinstance(response, dict):
        return dict(response)
    if isinstance(response, Message):
        return json_format.MessageToDict(response, preserving_proto_field_name=True)
    if isinstance(response, bytes | bytearray):
        data = bytes(response)
        if not data:
            return {}
        try:
            decoded = data.decode("utf-8")
            parsed = json.loads(decoded)
            return parsed if isinstance(parsed, dict) else {"result": parsed}
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {"raw": base64.urlsafe_b64encode(data).decode("ascii")}
    if isinstance(response, str):
        try:
            parsed = json.loads(response)
            return parsed if isinstance(parsed, dict) else {"result": parsed}
        except json.JSONDecodeError:
            return {"result": response}
    return {"result": response}


def _json_safe(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _json_safe(val) for key, val in value.items()}
    if isinstance(value, list):
        return [_json_safe(item) for item in value]
    if isinstance(value, tuple):
        return [_json_safe(item) for item in value]
    if hasattr(value, "value") and isinstance(value.value, str | int | float | bool):
        return value.value
    return value


__all__ = [
    "KeeperRestProvider",
    "config_from_response",
    "configuration_from_plan",
    "endpoint_from_env_or_override",
    "outcomes_from_plan",
    "plan_has_mutations",
]
