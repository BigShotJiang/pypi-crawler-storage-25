"""Runtime Commander version detection and capability probes."""

from __future__ import annotations

import importlib.metadata as _meta
import inspect
import os
import re
import shutil
import subprocess
from functools import lru_cache
from importlib import import_module
from typing import Any, cast


def commander_version() -> str:
    """Return installed keepercommander version string, or ``0.0.0`` on error."""
    try:
        return _meta.version("keepercommander")
    except Exception:
        return "0.0.0"


def keeper_binary_version() -> str | None:
    """Return the version string of the ``keeper`` binary on PATH, or ``None``.

    This helper is diagnostic only. The capability probes below inspect the
    imported ``keepercommander`` Python package and do not execute the
    standalone ``keeper`` binary. Use this helper when an operator may have a
    different binary installed than the package imported by dsk.
    """
    binary = shutil.which("keeper")
    if not binary:
        return None
    try:
        result = subprocess.run(
            [binary, "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        return None

    out = (result.stdout or result.stderr or "").strip()
    for token in out.replace(",", " ").split():
        if token.replace(".", "").isdigit():
            return token
    return out[:50] if out else None


def _version_major(version: str) -> str | None:
    match = re.match(r"\s*(\d+)", version)
    return match.group(1) if match else None


def has_version_mismatch() -> tuple[str, str] | None:
    """Return ``(binary_version, package_version)`` when major versions differ.

    ``None`` means no mismatch was detected, the binary was not found, or one of
    the version strings did not expose a parseable major version.
    """
    pkg_ver = commander_version()
    bin_ver = keeper_binary_version()
    if bin_ver is None:
        return None

    pkg_major = _version_major(pkg_ver)
    bin_major = _version_major(bin_ver)
    if pkg_major is None or bin_major is None:
        return None
    if pkg_major != bin_major:
        return (bin_ver, pkg_ver)
    return None


@lru_cache(maxsize=1)
def get_commander_version() -> tuple[int, int, int]:
    """Return (major, minor, patch) of installed keepercommander, or (0, 0, 0) on error.

    Pre-release suffixes (``rc1``, ``dev0``, ``a1``, ``b2``) are stripped from each
    segment before parsing so ``18.0.0rc1`` correctly gates as v18, not v0.
    """
    import re as _re

    try:
        ver = commander_version()
        parts = ver.split(".")
        nums = []
        for p in parts[:3]:
            m = _re.match(r"(\d+)", p)
            nums.append(int(m.group(1)) if m else 0)
        while len(nums) < 3:
            nums.append(0)
        return (nums[0], nums[1], nums[2])
    except Exception:
        return (0, 0, 0)


def v18_or_later() -> bool:
    """True when Commander >=18.0.0 OR env override DSK_COMMANDER_V18=1."""
    if os.environ.get("DSK_COMMANDER_V18") == "1":
        return True
    major, _, _ = get_commander_version()
    return major >= 18


def _command_class(module_name: str, class_name: str) -> type[Any] | None:
    try:
        module = import_module(module_name)
        cls = getattr(module, class_name)
    except Exception:
        return None
    return cls if isinstance(cls, type) else None


def _command_parser(command_cls: type[Any]) -> Any | None:
    try:
        command = command_cls()
        return command.get_parser()
    except Exception:
        return getattr(command_cls, "parser", None)


def _parser_actions(parser: Any) -> list[Any]:
    return list(getattr(parser, "_actions", ()) or ())


def _parser_has_option(parser: Any, option: str) -> bool:
    return any(
        option in (getattr(action, "option_strings", ()) or ())
        for action in _parser_actions(parser)
    )


def _parser_choice_contains(parser: Any, dest: str, choice: str) -> bool:
    for action in _parser_actions(parser):
        if getattr(action, "dest", None) != dest:
            continue
        choices = getattr(action, "choices", None)
        return choices is None or choice in choices
    return False


def supports_pam_project_export() -> bool:
    """Probe the imported package for native ``pam project export`` support.

    This inspects the installed ``keepercommander`` Python package, not the
    standalone ``keeper`` binary on PATH. Use :func:`keeper_binary_version` and
    :func:`has_version_mismatch` when callers need binary-side diagnostics.
    """
    candidates = (
        ("keepercommander.commands.pam_import.export", "PAMProjectExportCommand"),
        ("keepercommander.commands.pam.project", "PAMProjectExportCommand"),
    )
    return any(
        _command_class(module_name, class_name) is not None
        for module_name, class_name in candidates
    )


def supports_rotation_info_json() -> bool:
    """Probe the imported package for ``pam rotation info --format=json`` support.

    This inspects the installed ``keepercommander`` Python package parser, not
    the standalone ``keeper`` binary on PATH. Use :func:`keeper_binary_version`
    and :func:`has_version_mismatch` when callers need binary-side diagnostics.
    """
    candidates = (
        ("keepercommander.commands.discoveryrotation", "PAMRouterGetRotationInfo"),
        ("keepercommander.commands.discoveryrotation_v1", "PAMRouterGetRotationInfo"),
        ("keepercommander.commands.pam.rotation", "PAMRouterGetRotationInfo"),
    )
    for module_name, class_name in candidates:
        command_cls = _command_class(module_name, class_name)
        if command_cls is None:
            continue
        parser = _command_parser(command_cls)
        if parser is None:
            continue
        if _parser_has_option(parser, "--record-uid") and _parser_choice_contains(
            parser, "format", "json"
        ):
            return True
    return False


def supports_secrets_manager_token_add() -> bool:
    """Probe the imported package for ``secrets-manager token add <app_uid>``.

    This inspects the installed ``keepercommander`` Python package command
    registry/source, not the standalone ``keeper`` binary on PATH. Use
    :func:`keeper_binary_version` and :func:`has_version_mismatch` when callers
    need binary-side diagnostics.
    """
    try:
        module = import_module("keepercommander.commands.ksm")
    except Exception:
        return False
    command_cls = getattr(module, "KSMCommand", None)
    if not isinstance(command_cls, type):
        return False

    parser = _command_parser(command_cls)
    if parser is None:
        return False

    command_help = ""
    for action in _parser_actions(parser):
        if getattr(action, "dest", None) == "command":
            command_help = str(getattr(action, "help", "") or "")
            break
    help_text = f"{command_help}\n{getattr(module, 'available_ksm_commands', '')}".casefold()
    if "token add" not in help_text:
        return False

    try:
        execute_source = inspect.getsource(cast(Any, command_cls).execute).casefold()
    except (OSError, TypeError):
        return True
    return "token" in execute_source and "add" in execute_source and "add_client" in execute_source


def v18_rotation_info_json() -> bool:
    """Compatibility alias for :func:`supports_rotation_info_json`."""
    return supports_rotation_info_json()


def v18_sm_token_add() -> bool:
    """Compatibility alias for :func:`supports_secrets_manager_token_add`."""
    return supports_secrets_manager_token_add()


def v18_project_import_server_dedup() -> bool:
    """pam project import server-side uid dedup guard (PR #2005)."""
    return v18_or_later()


def v18_project_export_native() -> bool:
    """Compatibility alias for :func:`supports_pam_project_export`."""
    return supports_pam_project_export()
