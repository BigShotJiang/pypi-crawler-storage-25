"""Terraform delivery provider for ``keeper-terraform.v1`` manifests."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome, LiveRecord, Provider
from dsk.core.models_terraform import (
    TERRAFORM_FAMILY,
    TerraformIntegrationManifestV1,
    TerraformResourceMapping,
)
from dsk.core.planner import Plan, build_plan

GENERATED_TF = "keeper_pam_generated.tf"
_TERRAFORM_TIMEOUT_SECONDS = 300


class TerraformProvider(Provider):
    """Render DSK/Terraform mapping HCL and run Terraform."""

    def __init__(self, workdir: str | Path | None = None) -> None:
        self.workdir = Path(workdir) if workdir is not None else Path.cwd()

    def discover(self) -> list[LiveRecord]:
        """DSK plan routing uses :meth:`plan`; generic discovery is empty."""
        return []

    def plan(self, manifest: TerraformIntegrationManifestV1) -> Plan:
        """Build a Terraform delivery plan for the manifest mappings."""
        if not (self.workdir / ".terraform").exists():
            plan = _create_plan(manifest)
            setattr(plan, "_terraform_manifest", manifest)
            return plan

        try:
            result = subprocess.run(
                ["terraform", "plan", "-json"],
                cwd=self.workdir,
                check=False,
                capture_output=True,
                text=True,
                timeout=_TERRAFORM_TIMEOUT_SECONDS,
            )
        except FileNotFoundError as exc:
            raise CapabilityError(
                reason="terraform not found",
                next_action="install terraform or run from an initialized Terraform workspace",
                resource_type=TERRAFORM_FAMILY,
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise CapabilityError(
                reason=f"terraform plan timed out after {_TERRAFORM_TIMEOUT_SECONDS}s",
                next_action="inspect Terraform provider/state backends and retry from the workspace",
                resource_type=TERRAFORM_FAMILY,
            ) from exc
        if result.returncode not in (0, 2):
            raise CapabilityError(
                reason=f"terraform plan failed with exit code {result.returncode}",
                next_action="inspect terraform stderr and workspace initialization",
                resource_type=TERRAFORM_FAMILY,
            )

        has_changes = _terraform_plan_has_changes(result.stdout)
        plan = _mapping_plan(
            manifest,
            ChangeKind.UPDATE if has_changes else ChangeKind.NOOP,
            reason=None if has_changes else "terraform plan reported no changes",
        )
        setattr(plan, "_terraform_manifest", manifest)
        return plan

    def apply(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Write generated HCL and run Terraform plan/apply."""
        manifest = getattr(plan, "_terraform_manifest", None)
        if not isinstance(manifest, TerraformIntegrationManifestV1):
            raise CapabilityError(
                reason="Terraform plan is missing source manifest",
                next_action="build plans with TerraformProvider.plan(manifest) before calling apply",
                resource_type=TERRAFORM_FAMILY,
            )
        if not plan.changes:
            return []
        target = self.workdir / GENERATED_TF
        target.write_text(render_terraform_hcl(manifest), encoding="utf-8")
        commands = [["terraform", "plan"]]
        if not dry_run:
            commands.append(["terraform", "apply", "-auto-approve"])

        try:
            for command in commands:
                subprocess.run(
                    command,
                    cwd=self.workdir,
                    check=True,
                    text=True,
                    timeout=_TERRAFORM_TIMEOUT_SECONDS,
                )
        except FileNotFoundError as exc:
            raise CapabilityError(
                reason="terraform not found",
                next_action="install terraform and run `terraform init`",
                resource_type=TERRAFORM_FAMILY,
            ) from exc
        except subprocess.CalledProcessError as exc:
            failed = exc.cmd[1] if len(exc.cmd) > 1 else exc.cmd
            raise CapabilityError(
                reason=f"terraform {failed} failed with exit code {exc.returncode}",
                next_action="inspect terraform stderr and generated keeper_pam_generated.tf",
                resource_type=TERRAFORM_FAMILY,
            ) from exc
        except subprocess.TimeoutExpired as exc:
            failed = exc.cmd[1] if isinstance(exc.cmd, list) and len(exc.cmd) > 1 else exc.cmd
            raise CapabilityError(
                reason=f"terraform {failed} timed out after {_TERRAFORM_TIMEOUT_SECONDS}s",
                next_action="inspect Terraform provider/state backends and retry from the workspace",
                resource_type=TERRAFORM_FAMILY,
            ) from exc

        return [
            ApplyOutcome(
                uid_ref=change.uid_ref or "",
                keeper_uid="",
                action=change.kind.value,
                details={"dry_run": dry_run, "file": str(target), "tool": "terraform"},
            )
            for change in _outcome_changes(plan)
        ]

    def apply_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Provider protocol alias for :meth:`apply`."""
        return self.apply(plan, dry_run=dry_run)

    def unsupported_capabilities(self, manifest: object = None) -> list[str]:  # noqa: ARG002
        """Terraform delivery is handled by this provider."""
        return []

    def check_tenant_bindings(self, manifest: object = None) -> list[str]:  # noqa: ARG002
        """No Keeper tenant bindings are checked by the Terraform provider."""
        return []


def render_terraform_hcl(manifest: TerraformIntegrationManifestV1) -> str:
    """Render deterministic HCL for the current mapping-only Terraform model."""
    rows = ",\n".join(_render_mapping(row) for row in manifest.resource_mappings)
    return (
        "# Generated by DSK. Do not edit by hand.\n"
        "locals {\n"
        "  keeper_dsk_resource_mappings = [\n"
        f"{rows}\n"
        "  ]\n"
        "}\n"
    )


def _render_mapping(row: TerraformResourceMapping) -> str:
    return (
        "    {\n"
        f'      dsk_family       = "{_hcl_string(row.dsk_family)}"\n'
        f'      tf_resource_type = "{_hcl_string(row.tf_resource_type)}"\n'
        f'      direction = "{_hcl_string(row.direction)}"\n'
        "    }"
    )


def _hcl_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _create_plan(manifest: TerraformIntegrationManifestV1) -> Plan:
    return _mapping_plan(
        manifest,
        ChangeKind.CREATE,
        reason="Terraform workspace is not initialized; generated HCL will be created",
    )


def _mapping_plan(
    manifest: TerraformIntegrationManifestV1,
    kind: ChangeKind,
    *,
    reason: str | None,
) -> Plan:
    changes = [
        Change(
            kind=kind,
            uid_ref=_mapping_uid_ref(row),
            resource_type="terraform_mapping",
            title=row.tf_resource_type,
            before={} if kind is ChangeKind.CREATE else _mapping_payload(row),
            after=_mapping_payload(row),
            reason=reason,
            manifest_name=TERRAFORM_FAMILY,
        )
        for row in manifest.resource_mappings
    ]
    order = [_mapping_uid_ref(row) for row in manifest.resource_mappings]
    return build_plan(TERRAFORM_FAMILY, changes, order)


def _mapping_payload(row: TerraformResourceMapping) -> dict[str, str]:
    return {
        "dsk_family": row.dsk_family,
        "tf_resource_type": row.tf_resource_type,
        "direction": row.direction,
    }


def _mapping_uid_ref(row: TerraformResourceMapping) -> str:
    return f"{row.dsk_family}:{row.tf_resource_type}"


def _terraform_plan_has_changes(stdout: str) -> bool:
    for line in stdout.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            event = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if not isinstance(event, dict):
            continue
        if _change_summary_has_changes(event):
            return True
        change = event.get("change")
        if isinstance(change, dict) and _actions_have_changes(change.get("actions")):
            return True
        if _actions_have_changes(event.get("actions")):
            return True
    return False


def _change_summary_has_changes(event: dict[str, Any]) -> bool:
    if event.get("type") != "change_summary":
        return False
    changes = event.get("changes")
    if not isinstance(changes, dict):
        return False
    return any(int(changes.get(key) or 0) > 0 for key in ("add", "change", "remove", "import"))


def _actions_have_changes(actions: object) -> bool:
    if not isinstance(actions, list):
        return False
    return any(action != "no-op" for action in actions)


def _outcome_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    if ordered:
        return ordered
    return plan.noops
