"""Kubernetes External Secrets Operator delivery provider."""

from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import yaml

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome, LiveRecord, Provider
from dsk.core.models_k8s_eso import ExternalSecret, K8sEsoManifestV1
from dsk.core.planner import Plan, build_plan
from dsk.integrations.k8s import (
    generate_cluster_secret_store,
    generate_external_secret,
)

_KUBECTL_TIMEOUT_SECONDS = 120


class K8sEsoProvider(Provider):
    """Render ESO resources and deliver them with ``kubectl apply``."""

    def discover(self) -> list[LiveRecord]:
        """DSK plan routing uses :meth:`plan`; generic discovery is empty."""
        return []

    def plan(self, manifest: K8sEsoManifestV1) -> Plan:
        """Diff desired ESO resources against live Kubernetes resources."""
        desired = _desired_resources(manifest)
        try:
            live = self._read_live(manifest)
        except FileNotFoundError:
            live = {}

        changes: list[Change] = []
        order: list[str] = []
        for desired_resource in desired:
            uid_ref = _resource_uid_ref(desired_resource)
            order.append(uid_ref)
            before = live.get(_resource_key(desired_resource))
            if before is None:
                changes.append(
                    Change(
                        kind=ChangeKind.CREATE,
                        uid_ref=uid_ref,
                        resource_type=str(desired_resource["kind"]),
                        title=str(desired_resource["metadata"]["name"]),
                        after=desired_resource,
                        manifest_name=manifest.k8s_eso_schema,
                    )
                )
            elif before == desired_resource:
                changes.append(
                    Change(
                        kind=ChangeKind.NOOP,
                        uid_ref=uid_ref,
                        resource_type=str(desired_resource["kind"]),
                        title=str(desired_resource["metadata"]["name"]),
                        before=before,
                        after=desired_resource,
                        reason="Kubernetes resource matches desired manifest",
                        manifest_name=manifest.k8s_eso_schema,
                    )
                )
            else:
                changes.append(
                    Change(
                        kind=ChangeKind.UPDATE,
                        uid_ref=uid_ref,
                        resource_type=str(desired_resource["kind"]),
                        title=str(desired_resource["metadata"]["name"]),
                        keeper_uid=_live_identifier(before),
                        before=before,
                        after=desired_resource,
                        manifest_name=manifest.k8s_eso_schema,
                    )
                )

        plan = build_plan(manifest.k8s_eso_schema, changes, order)
        setattr(plan, "_k8s_eso_manifest", manifest)
        return plan

    def apply(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply rendered ESO YAML with ``kubectl apply``."""
        manifest = getattr(plan, "_k8s_eso_manifest", None)
        if not isinstance(manifest, K8sEsoManifestV1):
            manifest = _manifest_from_plan(plan)
        resources = _desired_resources(manifest)
        command = ["kubectl", "apply"]
        if dry_run:
            command.append("--dry-run=client")
        with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False) as tmp:
            yaml.safe_dump_all(resources, tmp, sort_keys=False)
            tmp_path = Path(tmp.name)
        try:
            subprocess.run(
                [*command, "-f", str(tmp_path)],
                check=True,
                text=True,
                timeout=_KUBECTL_TIMEOUT_SECONDS,
            )
        except FileNotFoundError as exc:
            raise CapabilityError(
                reason="kubectl not found",
                next_action="install kubectl or use --dry-run",
                resource_type="keeper-k8s-eso.v1",
            ) from exc
        except subprocess.CalledProcessError as exc:
            raise CapabilityError(
                reason=f"kubectl apply failed with exit code {exc.returncode}",
                next_action="inspect kubectl stderr and cluster/ESO CRD availability",
                resource_type="keeper-k8s-eso.v1",
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise CapabilityError(
                reason=f"kubectl apply timed out after {_KUBECTL_TIMEOUT_SECONDS}s",
                next_action="inspect cluster/API server availability and retry",
                resource_type="keeper-k8s-eso.v1",
            ) from exc
        finally:
            tmp_path.unlink(missing_ok=True)

        return [
            ApplyOutcome(
                uid_ref=change.uid_ref or "",
                keeper_uid=change.keeper_uid or "",
                action=change.kind.value,
                details={"dry_run": dry_run, "tool": "kubectl"},
            )
            for change in _outcome_changes(plan)
        ]

    def apply_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Provider protocol alias for :meth:`apply`."""
        return self.apply(plan, dry_run=dry_run)

    def unsupported_capabilities(self, manifest: object = None) -> list[str]:  # noqa: ARG002
        """Kubernetes delivery is handled by this provider."""
        return []

    def check_tenant_bindings(self, manifest: object = None) -> list[str]:  # noqa: ARG002
        """No Keeper tenant bindings are checked by the Kubernetes provider."""
        return []

    def _read_live(self, manifest: K8sEsoManifestV1) -> dict[tuple[str, str, str], dict[str, Any]]:
        live: dict[tuple[str, str, str], dict[str, Any]] = {}
        live.update(self._read_live_cluster_secret_stores())
        for namespace in _external_secret_namespaces(manifest):
            live.update(self._read_live_external_secrets(namespace))
        return live

    def _read_live_cluster_secret_stores(self) -> dict[tuple[str, str, str], dict[str, Any]]:
        try:
            result = subprocess.run(
                ["kubectl", "get", "clustersecretstore", "-o", "json"],
                check=False,
                capture_output=True,
                text=True,
                timeout=_KUBECTL_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return {}
        if result.returncode != 0:
            return {}
        return _items_by_key(json.loads(result.stdout or "{}"))

    def _read_live_external_secrets(
        self,
        namespace: str,
    ) -> dict[tuple[str, str, str], dict[str, Any]]:
        try:
            result = subprocess.run(
                ["kubectl", "get", "externalsecret", "-n", namespace, "-o", "json"],
                check=False,
                capture_output=True,
                text=True,
                timeout=_KUBECTL_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return {}
        if result.returncode != 0:
            return {}
        return _items_by_key(json.loads(result.stdout or "{}"))


def k8s_eso_apply_order(manifest: K8sEsoManifestV1) -> list[str]:
    """Return uid_ref ordering for CLI plan/apply (matches :meth:`K8sEsoProvider.plan`)."""
    return [_resource_uid_ref(resource) for resource in _desired_resources(manifest)]


def _desired_resources(manifest: K8sEsoManifestV1) -> list[dict[str, Any]]:
    stores = [generate_cluster_secret_store(store) for store in manifest.eso_stores]
    external_secrets = [
        _external_secret_with_namespace(secret, manifest) for secret in manifest.external_secrets
    ]
    return [_normalize_resource(row) for row in [*stores, *external_secrets]]


def _external_secret_with_namespace(
    secret: ExternalSecret,
    manifest: K8sEsoManifestV1,
) -> dict[str, Any]:
    rendered = generate_external_secret(secret)
    store = next(store for store in manifest.eso_stores if store.name == secret.store_ref)
    metadata = dict(rendered.get("metadata") or {})
    metadata["namespace"] = store.namespace
    rendered["metadata"] = metadata
    return rendered


def _external_secret_namespaces(manifest: K8sEsoManifestV1) -> list[str]:
    stores_by_name = {store.name: store for store in manifest.eso_stores}
    namespaces = {
        stores_by_name[secret.store_ref].namespace
        for secret in manifest.external_secrets
        if secret.store_ref in stores_by_name
    }
    return sorted(namespaces)


def _items_by_key(payload: dict[str, Any]) -> dict[tuple[str, str, str], dict[str, Any]]:
    out: dict[tuple[str, str, str], dict[str, Any]] = {}
    for item in payload.get("items") or []:
        if not isinstance(item, dict):
            continue
        normalized = _normalize_resource(item)
        out[_resource_key(normalized)] = normalized
    return out


def _normalize_resource(resource: dict[str, Any]) -> dict[str, Any]:
    metadata = dict(resource.get("metadata") or {})
    normalized_metadata = {"name": metadata.get("name")}
    if metadata.get("namespace"):
        normalized_metadata["namespace"] = metadata["namespace"]
    return {
        "apiVersion": resource.get("apiVersion"),
        "kind": resource.get("kind"),
        "metadata": normalized_metadata,
        "spec": resource.get("spec") or {},
    }


def _resource_key(resource: dict[str, Any]) -> tuple[str, str, str]:
    metadata = resource.get("metadata") or {}
    namespace = str(metadata.get("namespace") or "")
    return (str(resource.get("kind") or ""), namespace, str(metadata.get("name") or ""))


def _resource_uid_ref(resource: dict[str, Any]) -> str:
    kind, namespace, name = _resource_key(resource)
    if namespace:
        return f"{kind}:{namespace}/{name}"
    return f"{kind}:{name}"


def _live_identifier(resource: dict[str, Any]) -> str:
    _kind, namespace, name = _resource_key(resource)
    return f"{namespace}/{name}" if namespace else name


def _manifest_from_plan(plan: Plan) -> K8sEsoManifestV1:
    resources = [change.after for change in plan.changes if change.after]
    raise CapabilityError(
        reason="K8s ESO plan is missing source manifest",
        next_action=(
            "build plans with K8sEsoProvider.plan(manifest) before calling apply"
            if resources
            else "provide a non-empty K8s ESO plan"
        ),
        resource_type="keeper-k8s-eso.v1",
    )


def _outcome_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    if ordered:
        return ordered
    return plan.noops
