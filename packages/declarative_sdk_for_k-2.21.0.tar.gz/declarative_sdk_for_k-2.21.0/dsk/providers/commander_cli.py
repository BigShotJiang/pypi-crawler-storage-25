"""Commander-backed provider.

:public: ``CommanderCliProvider`` is public via :mod:`dsk.providers`.
:internal: Module-level helper functions/constants are implementation details.

Wraps Commander via subprocess for simple commands and direct in-process
command classes for PAM commands that need the logged-in session. This provider
is the production path today: Commander already implements record I/O, rotation
wiring, KSM binding, gateway registration, and share graph, so we reuse it
instead of re-implementing.

Commands used:
    keeper pam project import --file <manifest>.pam_import.json
    keeper pam project extend --file <manifest>.pam_import.json
    keeper ls <folder_uid> --format json
    keeper get <uid> --format json
    keeper rm <uid>
    keeper-vault.v1: in-process ``RecordAddCommand`` (record-add) for ``login``
    and L2 typed-record creates; ``RecordEditCommand`` merges manifest drift
    into existing v3 JSON then :meth:`_write_marker` refreshes ownership metadata;
    same ``ls`` / ``get`` discover path filters to manifest-owned rows.
    keeper-vault-sharing.v1 (provider helpers): ``mkdir -uf``, ``mkdir -sf``,
    ``mv --user-folder/--shared-folder``, ``rmdir -f``, ``share-record``,
    ``share-folder``, and ``get <shared_folder_uid> --format json``.

The provider:
    1. Lists the target folder (if configured) and fetches each record.
    2. Decodes ownership markers from the custom field.
    3. Applies PAM plans by writing a temp ``pam_import`` JSON document and
       invoking ``keeper pam project import`` or ``extend``. Applies vault
       vault plans via record-add + marker writes (see :meth:`_apply_vault_plan`).
    4. Deletes records via ``keeper rm <uid>``; ``compute_diff`` restricts
       deletes to records whose ownership marker matches ``MANAGER_NAME``.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import subprocess  # noqa: F401
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError, CollisionError
from dsk.core.interfaces import LiveRecord, Provider
from dsk.core.metadata import utc_timestamp  # noqa: F401
from dsk.core.models_policy import (
    POLICY_FAMILY,
    policy_upstream_gap_reasons,
)
from dsk.core.normalize import to_pam_import_json  # noqa: F401
from dsk.core.planner import Plan
from dsk.core.resource_limits import ResourceLimitError, positive_int_env, read_bytes_limited
from dsk.core.vault_diff import (
    _KEEPER_FILL_RESOURCE_TYPE,
    _KEEPER_FILL_SETTING_RESOURCE_TYPE,
    _KEEPER_FILL_UID_REF,
)
from dsk.providers.pam_workflow_argv import build_pam_workflow_apply_argvs

ConflictError = CollisionError
_DEFAULT_CHECKPOINT_MANIFEST_MAX_BYTES = 20 * 1024 * 1024


def _checkpoint_manifest_max_bytes() -> int:
    return positive_int_env(
        "DSK_CHECKPOINT_MANIFEST_MAX_BYTES", _DEFAULT_CHECKPOINT_MANIFEST_MAX_BYTES
    )


def _checkpoint_manifest_hash(manifest_path: str) -> str:
    """SHA256 prefix of manifest bytes (aligns with FileLock identity)."""
    try:
        data = read_bytes_limited(
            Path(manifest_path),
            max_bytes=_checkpoint_manifest_max_bytes(),
            label="checkpoint manifest",
            limit_name="DSK_CHECKPOINT_MANIFEST_MAX_BYTES",
        )
        return hashlib.sha256(data).hexdigest()[:12]
    except ResourceLimitError:
        return "unknown"


def _checkpoint_uid(change: Change) -> str:
    return str(change.uid_ref or change.title or "")


def _is_keeper_fill_change(change: Change) -> bool:
    """Detect whether a vault diff Change targets the keeper_fill block.

    Used by ``_apply_vault_plan`` to route create/update through dedicated
    keeper_fill helpers rather than silently using ``_vault_add_login_record``
    (which would drop the keeper_fill payload). See W3-AB schema-honesty slice.
    """
    rt = change.resource_type
    if rt in (_KEEPER_FILL_RESOURCE_TYPE, _KEEPER_FILL_SETTING_RESOURCE_TYPE):
        return True
    uid = change.uid_ref or ""
    return uid == _KEEPER_FILL_UID_REF or uid.startswith(_KEEPER_FILL_UID_REF + ":")


def _env_truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in _TRUTHY_ENV_VALUES


def _env_falsey(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"0", "false", "no", "off"}


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, str(default)))
    except ValueError:
        return default


def _service_mode_status(payload: Mapping[str, Any]) -> str:
    value = payload.get("status") or payload.get("state") or payload.get("request_status")
    return str(value or "").strip().lower()


def _service_mode_failure_reason(payload: Mapping[str, Any], *, fallback: str) -> str:
    for key in ("reason", "message", "error", "stderr"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return fallback


def _service_mode_output(payload: Any) -> str:
    if isinstance(payload, str):
        return payload
    if isinstance(payload, list):
        return json.dumps(payload)
    if not isinstance(payload, dict):
        return "" if payload is None else str(payload)
    for key in ("stdout", "output", "response"):
        value = payload.get(key)
        if isinstance(value, str):
            return value
        if isinstance(value, (dict, list)):
            return json.dumps(value)
    if payload.get("status") == "success" and "data" in payload:
        value = payload["data"]
        return value if isinstance(value, str) else json.dumps(value)
    if "result" in payload:
        value = payload["result"]
        return value if isinstance(value, str) else json.dumps(value)
    return ""


_SILENT_FAIL_COMMANDS = {
    ("pam", "project", "import"),
    ("pam", "project", "extend"),
    ("pam", "project", "export"),
    ("pam", "connection", "edit"),
    ("pam", "rbi", "edit"),
    ("compliance", "report"),
    ("ls",),
    ("get",),
    ("record-update",),
    ("rm",),
}
LOGGER = logging.getLogger(__name__)
_COMPLIANCE_EMPTY_CACHE_MARKERS = (
    "Cache last update: NONE",
    "compliance-report --rebuild",
    "to build the cache",
)
_SILENT_FAIL_MARKERS = (
    "Project name is required",
    "No such folder or record",
    "cannot be resolved",
    *_COMPLIANCE_EMPTY_CACHE_MARKERS,
)
_SERVICE_MODE_DONE_STATUSES = {"completed", "complete", "success", "succeeded", "done", ""}
_SERVICE_MODE_FAIL_STATUSES = {"failed", "failure", "error", "expired", "cancelled", "canceled"}
_IN_PROCESS_VAULT_COMMANDS = {
    "mkdir",
    "mv",
    "rmdir",
    "rm",
    "share-folder",
    "share-record",
}
_IN_PROCESS_SHARE_FAILURE_MARKERS = (
    "Please repeat this command when invitation is accepted",
    "not found",
)
_SESSION_EXPIRED_CODE = "session_token_expired"
_TRUTHY_ENV_VALUES = {"1", "true", "yes", "on"}
# In-process PAM import / marker writes require a floor documented in docs/COMMANDER.md.
_MIN_KEEPERCOMMANDER_VERSION = (18, 0, 0)
_MSP_APPLY_UNSUPPORTED_REASON = (
    "MSP managed-company apply is not implemented on CommanderCliProvider "
    "(Commander: `msp-add` / `msp-update` / `msp-remove`; see docs/COMMANDER.md)"
)
_MSP_CREATE_ONLY_UNSUPPORTED_REASON = (
    "CommanderCliProvider MSP apply only supports managed-company create/update/delete via "
    "`msp-add`, `msp-update`, and `msp-remove`; import marker writes remain unsupported"
)
_MSP_MARKER_UNSUPPORTED_REASON = (
    "MSP managed-company marker writes are not implemented on CommanderCliProvider "
    "(Commander 18.0.0 exposes `msp-add` / `msp-update` / `msp-remove`, but no "
    "managed-company metadata field or marker writer)"
)
_MSP_MANAGED_COMPANY_RESOURCE_TYPES = {"managed_company", "managedCompany"}
_ENTERPRISE_CONFIG_RESOURCE_TYPES = {
    "enterprise_config",
    "enterprise_policy",
    "enterprise_security_policy",
    "enterprise_password_rules",
    "enterprise_2fa_policy",
    "enterprise_sharing_policy",
}
_ENTERPRISE_CONFIG_UNSUPPORTED_REASON = (
    "keeper-enterprise.v1 enterprise-config policy writes are not implemented: "
    "Commander 18.0.0 exposes `enterprise-info` as a read-only report and has no "
    "`enterprise-info edit` / `enterprise-info set` writer"
)
_GOVERNANCE_FOLDER_TRANSFER_UNSUPPORTED_REASON = (
    "Governance folder ownership transfer is not implemented: Commander 18.0.0 has "
    "`share-folder` permission edits but no `share-folder transfer-ownership` or "
    "`keeper transfer` folder-owner command"
)
_KSM_APP_RESOURCE_TYPE = "ksm_app"
_KSM_CLIENT_RESOURCE_TYPE = "ksm_client"
_KSM_RECORD_SHARE_RESOURCE_TYPE = "ksm_record_share"
_KSM_BLOCKS = ("apps", "tokens", "record_shares", "config_outputs")
_PAM_EXTENDED_FAMILY = "keeper-pam-extended.v1"
_KSM_CREATE_ONLY_UNSUPPORTED_REASON = (
    "CommanderCliProvider KSM apply supports application create/delete/rename via "
    "`KSMCommand.add_new_v5_app` / `KSMCommand.remove_v5_app` / `KSMCommand.update_app` "
    "client create/delete via `KSMCommand.add_client` / `KSMCommand.remove_client`, and "
    "share create/update/delete via `KSMCommand.add_app_share` / "
    "`KSMCommand.update_app_share` / `KSMCommand.remove_share`; config outputs remain "
    "unsupported"
)


def _commander_mc_dict_to_sdk_row(mc: Mapping[str, Any]) -> dict[str, Any]:
    """Normalise one ``params.enterprise['managed_companies']`` row for MSP diff."""
    name = str(mc.get("mc_enterprise_name") or "").strip()
    if not name:
        raise ValueError("managed company missing mc_enterprise_name")
    plan = _msp_plan_slug_from_product_id(mc.get("product_id"))
    if not plan:
        plan = "business"
    seats_raw = int(mc.get("number_of_seats") or 0)
    if seats_raw > 2147483646 or seats_raw < 0:
        seats_raw = -1
    addons_out: list[dict[str, Any]] = []
    for addon in mc.get("add_ons") or []:
        if not isinstance(addon, dict) or addon.get("name") is None:
            continue
        a_seats = int(addon.get("seats") or 0)
        if a_seats > 2147483646 or a_seats < 0:
            a_seats = -1
        addons_out.append({"name": str(addon["name"]), "seats": a_seats})
    addons_out.sort(key=lambda x: str(x["name"]).casefold())
    out: dict[str, Any] = {
        "name": name,
        "plan": plan,
        "seats": seats_raw,
        "file_plan": _msp_file_plan_display(mc.get("file_plan_type")),
        "addons": addons_out,
    }
    eid = mc.get("mc_enterprise_id")
    if eid is not None:
        out["mc_enterprise_id"] = eid
    return out


def _all_plan_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    seen = {id(change) for change in ordered}
    return ordered + [change for change in plan.changes if id(change) not in seen]


def _plan_changes(plan: Plan) -> list[Change]:
    ordered = plan.ordered()
    seen = {id(change) for change in ordered}
    return ordered + [change for change in plan.changes if id(change) not in seen]


def _source_dict(source: Any) -> dict[str, Any]:
    if source is None:
        return {}
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
        return dict(data) if isinstance(data, Mapping) else {}
    if hasattr(source, "to_dict"):
        data = source.to_dict()
        return dict(data) if isinstance(data, Mapping) else {}
    if isinstance(source, Mapping):
        return dict(source)
    return {}


def _live_keeper_uid_for_manifest_uid_ref(live_records: list[LiveRecord], uid_ref: str) -> str:
    if not uid_ref:
        return ""
    for live in live_records:
        marker = live.marker or {}
        if marker.get("uid_ref") == uid_ref:
            return live.keeper_uid
    return ""


def _resolve_nested_pam_user_live(
    user: Mapping[str, Any],
    live_records: list[LiveRecord],
) -> LiveRecord | None:
    live_by_title: dict[tuple[str, str], LiveRecord] = {
        (r.resource_type, str((r.marker or {}).get("title") or "")): r for r in live_records
    }
    user_uid_ref = _non_empty_str(user.get("uid_ref")) or ""
    user_title = str(user.get("title") or "").strip()
    if user_uid_ref:
        for record in live_records:
            if record.resource_type != "pamUser":
                continue
            if (record.marker or {}).get("uid_ref") == user_uid_ref:
                return record
    return live_by_title.get(("pamUser", user_title))


def _manifest_parent_resource_for_nested_user(
    manifest: Mapping[str, Any],
    *,
    user_uid_ref: str,
    user_title: str,
) -> dict[str, Any] | None:
    for resource in manifest.get("resources") or []:
        if not isinstance(resource, dict):
            continue
        for cand in resource.get("users") or []:
            if not isinstance(cand, dict) or cand.get("type") != "pamUser":
                continue
            if user_uid_ref and cand.get("uid_ref") == user_uid_ref:
                return resource
            if not user_uid_ref and str(cand.get("title") or "").strip() == user_title:
                return resource
    return None


def build_pam_user_saas_plugin_set_entries(
    manifest: Mapping[str, Any],
    live_records: list[LiveRecord],
) -> list[tuple[str, str, list[str]]]:
    """Build pamUser SaaS plugin argv rows as ``(uid_ref, user_keeper_uid, argv)`` tuples."""

    entries: list[tuple[str, str, list[str]]] = []
    for resource in manifest.get("resources") or []:
        if not isinstance(resource, dict):
            continue
        for user in resource.get("users") or []:
            if not isinstance(user, dict) or user.get("type") != "pamUser":
                continue
            plugins = user.get("saas_plugins") or []
            if not plugins:
                continue
            live_user = _resolve_nested_pam_user_live(user, live_records)
            if live_user is None or not live_user.keeper_uid:
                continue
            user_uid = live_user.keeper_uid
            uid_ref_val = str((live_user.marker or {}).get("uid_ref") or user.get("uid_ref") or "")
            for entry in plugins:
                pdata = _saas_plugin_entry_as_dict(entry)
                plugin_name = str(pdata.get("plugin_name") or "").strip()
                if not plugin_name:
                    continue
                cfg_uid = pdata.get("config_record_uid")
                if cfg_uid not in (None, ""):
                    argv = [
                        "pam",
                        "action",
                        "saas",
                        "set",
                        "--user-uid",
                        user_uid,
                        "--config-record-uid",
                        str(cfg_uid),
                    ]
                else:
                    argv = [
                        "pam",
                        "saas",
                        "set",
                        "--user",
                        user_uid,
                        "--plugin",
                        plugin_name,
                        "--json",
                        json.dumps(pdata.get("config") or {}, sort_keys=True, default=str),
                    ]
                entries.append((uid_ref_val, user_uid, argv))
    return entries


def build_pam_user_saas_plugin_remove_argvs(
    plan: Plan,
    manifest: Mapping[str, Any],
    live_records: list[LiveRecord],
) -> list[tuple[str, list[str]]]:
    """When an UPDATE shrinks ``saas_plugins``, yield ``(uid_ref, argv)`` remove rows."""

    rows: list[tuple[str, list[str]]] = []
    for change in plan.updates:
        if change.resource_type != "pamUser":
            continue
        before = change.before or {}
        after = change.after or {}
        if "saas_plugins" not in before and "saas_plugins" not in after:
            continue
        b_plugins = before.get("saas_plugins") or []
        a_plugins = after.get("saas_plugins") or []
        if not _plugins_removed(b_plugins, a_plugins):
            continue
        user_dict = {
            "type": "pamUser",
            "title": change.title,
            "uid_ref": change.uid_ref or "",
        }
        live_user = _resolve_nested_pam_user_live(user_dict, live_records)
        if live_user is None or not live_user.keeper_uid:
            continue
        uid_ref_val = str(change.uid_ref or (live_user.marker or {}).get("uid_ref") or "")
        parent = _manifest_parent_resource_for_nested_user(
            manifest,
            user_uid_ref=str(change.uid_ref or ""),
            user_title=str(change.title or ""),
        )
        if parent is None:
            continue
        parent_kuid = _live_keeper_uid_for_manifest_uid_ref(
            live_records,
            str(parent.get("uid_ref") or ""),
        )
        if not parent_kuid:
            continue
        argv = [
            "pam",
            "action",
            "saas",
            "remove",
            "--user-uid",
            live_user.keeper_uid,
            "--resource-uid",
            parent_kuid,
        ]
        rows.append((uid_ref_val, argv))
    return rows


def _ref_leaf(ref: Any, prefix: str) -> str:
    value = str(ref or "")
    if value.startswith(prefix):
        return value[len(prefix) :]
    return value


def _semver_tuple_at_least(installed: tuple[int, ...], minimum: tuple[int, ...]) -> bool:
    span = max(len(installed), len(minimum))
    for i in range(span):
        a = installed[i] if i < len(installed) else 0
        b = minimum[i] if i < len(minimum) else 0
        if a > b:
            return True
        if a < b:
            return False
    return True


def _keepercommander_installed_tuple() -> tuple[int, ...]:
    from importlib.metadata import PackageNotFoundError, version

    try:
        raw = version("keepercommander")
    except PackageNotFoundError:
        return ()
    parts: list[int] = []
    for segment in raw.strip().split("."):
        digits = ""
        for ch in segment:
            if ch.isdigit():
                digits += ch
            else:
                break
        if not digits:
            break
        parts.append(int(digits))
    return tuple(parts)


def _supports_rotation_info_json() -> bool:
    try:
        from .commander_version import supports_rotation_info_json
    except Exception:
        return False
    return supports_rotation_info_json()


def _supports_secrets_manager_token_add() -> bool:
    try:
        from .commander_version import supports_secrets_manager_token_add
    except Exception:
        return False
    return supports_secrets_manager_token_add()


def _v18_project_import_server_dedup() -> bool:
    try:
        from .commander_version import v18_project_import_server_dedup
    except Exception:
        return False
    return v18_project_import_server_dedup()


def _supports_pam_project_export() -> bool:
    try:
        from .commander_version import supports_pam_project_export
    except Exception:
        return False
    return supports_pam_project_export()


def _v18_rotation_info_json() -> bool:
    return _supports_rotation_info_json()


def _v18_sm_token_add() -> bool:
    return _supports_secrets_manager_token_add()


def _v18_project_export_native() -> bool:
    return _supports_pam_project_export()


def _commander_on_off(value: bool) -> str:
    return "on" if value else "off"


def _dict_items(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [dict(item) for item in value if isinstance(item, dict)]


def _ensure_keepercommander_version_for_apply() -> None:
    installed = _keepercommander_installed_tuple()
    if not installed:
        raise CapabilityError(
            reason="keepercommander Python package is not installed",
            next_action="pip install 'keepercommander>=18.0.0,<19'",
        )
    if not _semver_tuple_at_least(installed, _MIN_KEEPERCOMMANDER_VERSION):
        iv = ".".join(str(x) for x in installed)
        mv = ".".join(str(x) for x in _MIN_KEEPERCOMMANDER_VERSION)
        raise CapabilityError(
            reason=(
                f"keepercommander {iv} is below the minimum {mv} required for "
                "CommanderCliProvider in-process apply paths"
            ),
            next_action=(
                "upgrade with pip install -U 'keepercommander>=18.0.0,<19' "
                "and read docs/COMMANDER.md for the pin rationale"
            ),
            context={"installed": installed, "required": _MIN_KEEPERCOMMANDER_VERSION},
        )


def _manifest_source_is_vault(source: Any) -> bool:
    """True when the provider was constructed with a ``keeper-vault.v1`` document."""
    if source is None:
        return False
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
    elif isinstance(source, dict):
        data = source
    else:
        return False
    return data.get("schema") == "keeper-vault.v1"


def _manifest_source_is_sharing(source: Any) -> bool:
    """True when the provider was constructed with a ``keeper-vault-sharing.v1`` document."""
    if source is None:
        return False
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
    elif isinstance(source, dict):
        data = source
    else:
        return False
    return data.get("schema") == "keeper-vault-sharing.v1"


def _manifest_source_is_workflow(source: Any) -> bool:
    """True when the provider was constructed with a ``keeper-workflow.v1`` document."""
    if source is None:
        return False
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
    elif isinstance(source, dict):
        data = source
    else:
        return False
    return data.get("schema") == "keeper-workflow.v1"


def _manifest_source_is_saas_rotation(source: Any) -> bool:
    """True when the provider was constructed with a ``keeper-saas-rotation.v1`` document."""
    if source is None:
        return False
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
    elif isinstance(source, dict):
        data = source
    else:
        return False
    return data.get("schema") == "keeper-saas-rotation.v1"


def _manifest_source_is_pam_extended(source: Any) -> bool:
    """True when the provider was constructed with an extended PAM manifest document."""
    if source is None:
        return False
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
    elif isinstance(source, dict):
        data = source
    else:
        return False
    return (
        data.get("schema") == _PAM_EXTENDED_FAMILY
        or data.get("pam_extended_schema") == _PAM_EXTENDED_FAMILY
    )


def _manifest_source_is_epm(source: Any) -> bool:
    """True when the provider was constructed with a ``keeper-epm.v1`` document."""
    if source is None:
        return False
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
    elif isinstance(source, dict):
        data = source
    else:
        return False
    return data.get("schema") == "keeper-epm.v1"


def _manifest_source_is_epm_policy(source: Any) -> bool:
    """True when the provider was constructed with an ``epm-policy.v1`` document."""
    if source is None:
        return False
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
    elif isinstance(source, dict):
        data = source
    else:
        return False
    return data.get("schema") == "epm-policy.v1"


def _manifest_source_is_privileged_access(source: Any) -> bool:
    """True when the provider was constructed with a ``keeper-privileged-access.v1`` document."""
    if source is None:
        return False
    if hasattr(source, "model_dump"):
        data = source.model_dump(mode="python", exclude_none=True, by_alias=True)
    elif isinstance(source, dict):
        data = source
    else:
        return False
    return data.get("schema") == "keeper-privileged-access.v1"


_SHARING_RESOURCE_TYPES = {
    "sharing_folder",
    "sharing_shared_folder",
    "sharing_record_share",
    "sharing_share_folder",
}
_VAULT_SHARED_FOLDER_RESOURCE_TYPE = "shared_folder"
_SHARING_PAYLOAD_FIELD_LABEL = "keeper_declarative_payload"
_SHARING_MARKER_TITLE_PREFIX = "DSK sharing marker"

_RESOURCE_ATTACHMENT_RESOURCE_TYPES = frozenset(
    {"pamMachine", "pamDatabase", "pamDirectory", "pamRemoteBrowser"}
)


def _is_retryable_keeper_session_error(exc: BaseException) -> bool:
    """True when *exc* or its ``__cause__`` chain signals a refreshable session."""
    parts: list[str] = []
    cur: BaseException | None = exc
    for _ in range(8):
        if cur is None:
            break
        result_code = getattr(cur, "result_code", None)
        if isinstance(result_code, str) and result_code == _SESSION_EXPIRED_CODE:
            return True
        parts.append(f"{type(cur).__name__}: {cur}")
        cur = cur.__cause__ or getattr(cur, "original_error", None)
    text = "\n".join(parts).casefold()
    return _SESSION_EXPIRED_CODE in text or ("session token" in text and "expired" in text)


def _is_retryable_keeper_session_text(stdout: str | None, stderr: str | None) -> bool:
    text = f"{stdout or ''}\n{stderr or ''}".casefold()
    return _SESSION_EXPIRED_CODE in text or ("session token" in text and "expired" in text)


def _ensure_pam_workflow_config_commands_available() -> None:
    """Fail fast when ``pam workflow`` in-process commands are not packaged."""
    try:
        from keepercommander.commands.workflow.config_commands import (  # noqa: F401
            WorkflowCreateCommand,
            WorkflowUpdateCommand,
        )
    except (ImportError, AttributeError) as exc:
        raise CapabilityError(
            reason=(
                "Commander pam workflow create/update is unavailable in this "
                f"keepercommander install: {exc}"
            ),
            resource_type="capability",
            next_action=(
                "upgrade keepercommander to a build shipping "
                "keepercommander.commands.workflow.config_commands "
                "(WorkflowCreateCommand / WorkflowUpdateCommand); CLI: pam workflow …"
            ),
        ) from exc


def build_post_import_tuning_argvs(
    record: str,
    resource: Mapping[str, Any],
    *,
    resolved_refs: Mapping[str, str] | None = None,
    change_kind: ChangeKind | None = None,
    manifest: Mapping[str, Any] | None = None,
) -> list[list[str]]:
    """Build Commander argv for safe post-import tuning fields.

    Pure helper only: it does not resolve refs, inspect live records, or execute
    Commander. ``resolved_refs`` must map manifest ``*_uid_ref`` values to the
    UID/path strings accepted by the target Commander edit command.
    """
    if not record:
        raise ValueError("record is required to build post-import tuning argv")

    refs = resolved_refs or {}
    resource_type = resource.get("type")
    if resource_type == "pamRemoteBrowser":
        argv = _build_pam_rbi_edit_argv(record, resource, refs)
    else:
        argv = _build_pam_connection_edit_argv(record, resource, refs)
    out: list[list[str]] = [] if argv is None else [argv]
    if change_kind is not None:
        out.extend(
            build_pam_workflow_apply_argvs(
                record, resource, change_kind=change_kind, manifest=manifest
            )
        )
    return out


def _resolve_post_import_tuning_argvs(
    manifest: Any,
    *,
    plan: Plan,
    live_records: list[LiveRecord],
    changes: list[Change],
) -> dict[str, list[list[str]]]:
    """Resolve and build post-import tuning argv for changed resources.

    Pure resolver: no Commander calls. It requires live rediscovery because
    create rows do not carry Keeper UIDs until after import / extend runs.
    """
    source = _manifest_source_dict(manifest)
    if not source:
        return {}
    resources = _manifest_resources_by_ref(source)
    refs = _RotationRefResolver(plan=plan, live_records=live_records)
    argvs_by_ref: dict[str, list[list[str]]] = {}

    for change in changes:
        if not change.uid_ref:
            continue
        resource = resources.get(change.uid_ref)
        if resource is None or not _has_post_import_tuning_fields(resource):
            continue
        try:
            record_uid = refs.resolve(
                uid_ref=change.uid_ref,
                title=change.title,
                resource_type=change.resource_type,
                role="post-import tuning record",
            )
            resolved_refs = _resolve_post_import_tuning_refs(source, resource, refs)
            argvs = build_post_import_tuning_argvs(
                record_uid,
                resource,
                resolved_refs=resolved_refs,
                change_kind=change.kind,
                manifest=source,
            )
        except ValueError as exc:
            text = str(exc)
            is_workflow = "workflow_settings" in text or "approver_uid_ref" in text
            raise CapabilityError(
                reason=text if is_workflow else f"post-import tuning could not resolve refs: {exc}",
                uid_ref=change.uid_ref,
                resource_type=change.resource_type,
                next_action=(
                    "fix workflow_settings / approver_uid_refs (manifest must declare pamUser "
                    "login for each approver ref), or ensure every *_uid_ref used by pam_settings "
                    "is declared and visible after import, then re-run apply"
                ),
            ) from exc
        if argvs:
            argvs_by_ref[change.uid_ref] = argvs
    return argvs_by_ref


def _resolve_post_import_tuning_refs(
    source: Mapping[str, Any],
    resource: Mapping[str, Any],
    refs: _RotationRefResolver,
) -> dict[str, str]:
    resolved: dict[str, str] = {}
    for uid_ref in _post_import_tuning_uid_refs(resource):
        resource_type, title = _desired_identity(source, uid_ref)
        resolved[uid_ref] = refs.resolve(
            uid_ref=uid_ref,
            title=title,
            resource_type=resource_type or "resource",
            role="post-import tuning reference",
        )
    return resolved


def _preview_post_import_tuning_argvs(change: Change, manifest: Any) -> list[list[str]]:
    if not change.uid_ref:
        return []
    resource = _manifest_resources_by_ref(_manifest_source_dict(manifest)).get(change.uid_ref)
    if resource is None or not _has_post_import_tuning_fields(resource):
        return []
    resolved_refs = {
        uid_ref: f"<uid_ref:{uid_ref}>" for uid_ref in _post_import_tuning_uid_refs(resource)
    }
    try:
        return build_post_import_tuning_argvs(
            f"<record:{change.uid_ref}>",
            resource,
            resolved_refs=resolved_refs,
            change_kind=change.kind,
            manifest=_manifest_source_dict(manifest),
        )
    except ValueError:
        return []


def _preview_rotation_argvs_by_ref(manifest: Any) -> dict[str, list[list[str]]]:
    source = _manifest_source_dict(manifest)
    if not source:
        return {}
    argvs_by_ref: dict[str, list[list[str]]] = {}
    try:
        _reject_top_level_user_rotation(source)
    except ValueError:
        return {}

    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        parent_ref = _non_empty_str(resource.get("uid_ref"))
        parent_title = _non_empty_str(resource.get("title"))
        if not (parent_ref or parent_title):
            continue
        try:
            config_ref, config_title = _rotation_config_ref(source, resource)
        except ValueError:
            continue
        config_uid = _preview_ref(config_ref, config_title, role="config")
        resource_uid = _preview_ref(parent_ref, parent_title, role="resource")

        for user in resource.get("users") or []:
            if (
                not isinstance(user, Mapping)
                or user.get("type") != "pamUser"
                or user.get("rotation_settings") is None
            ):
                continue
            user_ref = _non_empty_str(user.get("uid_ref"))
            user_title = _non_empty_str(user.get("title"))
            if not (user_ref or user_title):
                continue
            argv = _build_pam_rotation_edit_args(
                record_uid=_preview_ref(user_ref, user_title, role="record"),
                settings=user["rotation_settings"],
                resource_uid=resource_uid,
                config_uid=config_uid,
                admin_uid=_preview_rotation_admin_uid(user["rotation_settings"]),
            )
            argvs_by_ref.setdefault(user_ref or user_title or "", []).append(argv)
    return argvs_by_ref


def _preview_ref(uid_ref: str | None, title: str | None, *, role: str) -> str:
    if uid_ref:
        if role == "record":
            return f"<record:{uid_ref}>"
        return f"<uid_ref:{uid_ref}>"
    if title:
        return f"<{role}:{title}>"
    return f"<{role}:unresolved>"


def _preview_rotation_admin_uid(settings: Any) -> str | None:
    data = _model_dump_dict(settings)
    admin_ref = next(
        (
            _non_empty_str(data.get(key))
            for key in (
                "admin_uid_ref",
                "admin_user_uid_ref",
                "administrative_credentials_uid_ref",
            )
            if _non_empty_str(data.get(key))
        ),
        None,
    )
    return f"<uid_ref:{admin_ref}>" if admin_ref else None


def _manifest_source_dict(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        dumped = value.model_dump(mode="python", exclude_none=True)
        return dumped if isinstance(dumped, dict) else {}
    return value if isinstance(value, dict) else {}


def _manifest_resources_by_ref(source: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    resources: dict[str, Mapping[str, Any]] = {}
    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        uid_ref = _non_empty_str(resource.get("uid_ref"))
        if uid_ref:
            resources[uid_ref] = resource
    return resources


class _NestedRotationUserTargets:
    def __init__(self, *, refs: set[str], titles: set[str]) -> None:
        self.refs = refs
        self.titles = titles


def _nested_rotation_user_targets(source: Mapping[str, Any]) -> _NestedRotationUserTargets:
    refs: set[str] = set()
    titles: set[str] = set()
    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        for user in resource.get("users") or []:
            if (
                not isinstance(user, Mapping)
                or user.get("type") != "pamUser"
                or user.get("rotation_settings") is None
            ):
                continue
            uid_ref = _non_empty_str(user.get("uid_ref"))
            title = _non_empty_str(user.get("title"))
            if uid_ref:
                refs.add(uid_ref)
            if title:
                titles.add(title)
    return _NestedRotationUserTargets(refs=refs, titles=titles)


def _first_present(source: Mapping[str, Any], keys: tuple[str, ...]) -> Any:
    for key in keys:
        if key in source:
            return source[key]
    return None


def _first_non_empty(source: Mapping[str, Any], keys: tuple[str, ...]) -> str | None:
    for key in keys:
        value = source.get(key)
        if value is None or value == "":
            continue
        return str(value)
    return None


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in _TRUTHY_ENV_VALUES


_CONNECTION_TUNING_OPTION_KEYS = frozenset(
    {
        "connections",
        "graphical_session_recording",
        "text_session_recording",
    }
)
_CONNECTION_TUNING_CONNECTION_KEYS = frozenset(
    {
        "administrative_credentials_uid_ref",
        "launch_credentials_uid_ref",
        "protocol",
        "port",
        "recording_include_keys",
    }
)
_RBI_TUNING_OPTION_KEYS = frozenset(
    {
        "remote_browser_isolation",
        "graphical_session_recording",
    }
)
_RBI_TUNING_CONNECTION_KEYS = frozenset(
    {
        "autofill_credentials_uid_ref",
        "autofill_targets",
        "allow_url_manipulation",
        "allowed_url_patterns",
        "allowed_resource_url_patterns",
        "recording_include_keys",
        "disable_copy",
        "disable_paste",
        "ignore_server_cert",
    }
)


def _has_post_import_tuning_fields(resource: Mapping[str, Any]) -> bool:
    pam_settings = _as_mapping(resource.get("pam_settings"))
    options = _as_mapping(pam_settings.get("options"))
    connection = _as_mapping(pam_settings.get("connection"))
    if resource.get("type") == "pamRemoteBrowser":
        option_keys = _RBI_TUNING_OPTION_KEYS
        connection_keys = _RBI_TUNING_CONNECTION_KEYS
    else:
        option_keys = _CONNECTION_TUNING_OPTION_KEYS
        connection_keys = _CONNECTION_TUNING_CONNECTION_KEYS
    pam_branch = any(key in options for key in option_keys) or any(
        key in connection for key in connection_keys
    )
    ws = resource.get("workflow_settings")
    workflow_branch = isinstance(ws, Mapping) and any(v not in (None, [], {}) for v in ws.values())
    return pam_branch or workflow_branch


def _post_import_tuning_uid_refs(resource: Mapping[str, Any]) -> list[str]:
    refs: list[str] = []
    config_ref = _non_empty_str(resource.get("pam_configuration_uid_ref"))
    if config_ref:
        refs.append(config_ref)
    pam_settings = _as_mapping(resource.get("pam_settings"))
    connection = _as_mapping(pam_settings.get("connection"))
    keys: tuple[str, ...]
    if resource.get("type") == "pamRemoteBrowser":
        keys = ("autofill_credentials_uid_ref",)
    else:
        keys = (
            "administrative_credentials_uid_ref",
            "launch_credentials_uid_ref",
        )
    for key in keys:
        uid_ref = _non_empty_str(connection.get(key))
        if uid_ref and uid_ref not in refs:
            refs.append(uid_ref)
    return refs


def build_pam_rotation_edit_argvs(
    manifest: Any,
    *,
    plan: Plan | None = None,
    live_records: list[LiveRecord] | None = None,
) -> list[list[str]]:
    """Build Commander argv for nested ``pamUser`` rotation settings.

    Pure resolver: it never calls Keeper. Nested users need three proven live
    UIDs before a rotation edit is safe: the user record, the parent resource
    record, and the PAM config.
    """
    source = _manifest_dict(manifest)
    _reject_top_level_user_rotation(source)

    refs = _RotationRefResolver(plan=plan, live_records=live_records or [])
    argvs: list[list[str]] = []
    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        rotating_users = [
            user
            for user in resource.get("users") or []
            if isinstance(user, Mapping)
            and user.get("type") == "pamUser"
            and user.get("rotation_settings") is not None
        ]
        if not rotating_users:
            continue

        parent_ref = _non_empty_str(resource.get("uid_ref"))
        parent_title = _non_empty_str(resource.get("title"))
        parent_type = _non_empty_str(resource.get("type")) or "resource"
        if not parent_ref or not parent_title:
            raise ValueError(
                "resources[].users[].rotation_settings requires a parent resource with uid_ref and title"
            )

        config_ref, config_title = _rotation_config_ref(source, resource)
        config_uid = refs.resolve(
            uid_ref=config_ref,
            title=config_title,
            resource_type="pam_configuration",
            role="PAM configuration",
        )
        resource_uid = refs.resolve(
            uid_ref=parent_ref,
            title=parent_title,
            resource_type=parent_type,
            role="parent resource",
        )

        for user in rotating_users:
            settings = user["rotation_settings"]
            user_ref = _non_empty_str(user.get("uid_ref"))
            user_title = _non_empty_str(user.get("title"))
            user_uid = refs.resolve(
                uid_ref=user_ref,
                title=user_title,
                resource_type="pamUser",
                role="nested pamUser",
            )
            admin_uid = _rotation_admin_uid(settings, refs, source)
            argvs.append(
                _build_pam_rotation_edit_args(
                    record_uid=user_uid,
                    settings=settings,
                    resource_uid=resource_uid,
                    config_uid=config_uid,
                    admin_uid=admin_uid,
                )
            )
    return argvs


class _RotationRefResolver:
    def __init__(self, *, plan: Plan | None, live_records: list[LiveRecord]) -> None:
        self._plan_by_ref: dict[str, Change] = {}
        self._plan_by_title: dict[tuple[str, str], Change] = {}
        if plan is not None:
            for change in plan.changes:
                if change.uid_ref:
                    self._plan_by_ref[change.uid_ref] = change
                self._plan_by_title[(change.resource_type, change.title)] = change

        self._live_by_ref: dict[str, list[LiveRecord]] = {}
        self._live_by_title, self._live_by_any_title = _index_live_records_for_title_matching(
            live_records
        )
        for live in live_records:
            marker_ref = _non_empty_str((live.marker or {}).get("uid_ref"))
            if marker_ref:
                self._live_by_ref.setdefault(marker_ref, []).append(live)

    def resolve(
        self,
        *,
        uid_ref: str | None,
        title: str | None,
        resource_type: str,
        role: str,
    ) -> str:
        if uid_ref:
            uid = self._resolve_live_ref(uid_ref, role)
            if uid:
                return uid
            change = self._plan_by_ref.get(uid_ref)
            if change and change.keeper_uid:
                return change.keeper_uid

        if title:
            uid = self._resolve_live_title(resource_type, title, role)
            if uid:
                return uid
            change = self._plan_by_title.get((resource_type, title))
            if change and change.keeper_uid:
                return change.keeper_uid

        ident = f"uid_ref='{uid_ref}'" if uid_ref else f"title='{title}'"
        raise ValueError(
            f"missing live {role} ({ident}, type={resource_type}); "
            "run import/apply first, then pass discovered live records with Keeper UIDs"
        )

    def _resolve_live_ref(self, uid_ref: str, role: str) -> str | None:
        matches = self._live_by_ref.get(uid_ref, [])
        if len(matches) > 1:
            raise ValueError(
                f"duplicate live {role} match for uid_ref '{uid_ref}': "
                f"{[item.keeper_uid for item in matches]}"
            )
        return matches[0].keeper_uid if matches else None

    def _resolve_live_title(self, resource_type: str, title: str, role: str) -> str | None:
        matches = _live_matches_by_identity(
            live_by_key=self._live_by_title,
            live_by_title=self._live_by_any_title,
            resource_type=resource_type,
            title=title,
        )
        if len(matches) > 1:
            raise ValueError(
                f"duplicate live {role} match for title '{title}' ({resource_type}): "
                f"{[item.keeper_uid for item in matches]}"
            )
        return matches[0].keeper_uid if matches else None


def _index_live_records_for_title_matching(
    live_records: list[LiveRecord],
) -> tuple[dict[tuple[str, str], list[LiveRecord]], dict[str, list[LiveRecord]]]:
    live_by_key: dict[tuple[str, str], list[LiveRecord]] = {}
    live_by_title: dict[str, list[LiveRecord]] = {}
    for live in live_records:
        live_by_key.setdefault((live.resource_type, live.title), []).append(live)
        if live.title:
            live_by_title.setdefault(live.title, []).append(live)
    return live_by_key, live_by_title


def _live_matches_by_identity(
    *,
    live_by_key: dict[tuple[str, str], list[LiveRecord]],
    live_by_title: dict[str, list[LiveRecord]],
    resource_type: str,
    title: str,
) -> list[LiveRecord]:
    exact = live_by_key.get((resource_type, title), [])
    if exact:
        return exact
    return live_by_title.get(title, []) if title else []


def _build_pam_connection_edit_argv(
    record: str, resource: Mapping[str, Any], refs: Mapping[str, str]
) -> list[str] | None:
    pam_settings = _as_mapping(resource.get("pam_settings"))
    options = _as_mapping(pam_settings.get("options"))
    connection = _as_mapping(pam_settings.get("connection"))

    argv = ["pam", "connection", "edit"]
    _append_ref(argv, "--configuration", resource.get("pam_configuration_uid_ref"), refs)
    _append_option(argv, "--connections", options.get("connections"))
    _append_option(
        argv,
        "--connections-recording",
        options.get("graphical_session_recording"),
    )
    _append_option(argv, "--typescript-recording", options.get("text_session_recording"))
    _append_ref(
        argv,
        "--admin-user",
        connection.get("administrative_credentials_uid_ref"),
        refs,
    )
    _append_ref(argv, "--launch-user", connection.get("launch_credentials_uid_ref"), refs)
    _append_option(argv, "--protocol", connection.get("protocol"))
    _append_option(argv, "--connections-override-port", connection.get("port"))
    _append_option(argv, "--key-events", _on_off(connection.get("recording_include_keys")))

    if len(argv) == 3:
        return None
    argv.append(record)
    return argv


def _build_pam_rbi_edit_argv(
    record: str, resource: Mapping[str, Any], refs: Mapping[str, str]
) -> list[str] | None:
    pam_settings = _as_mapping(resource.get("pam_settings"))
    options = _as_mapping(pam_settings.get("options"))
    connection = _as_mapping(pam_settings.get("connection"))

    argv = ["pam", "rbi", "edit", "--record", record]
    _append_ref(argv, "--configuration", resource.get("pam_configuration_uid_ref"), refs)
    _append_option(
        argv,
        "--remote-browser-isolation",
        options.get("remote_browser_isolation"),
    )
    _append_option(
        argv,
        "--connections-recording",
        options.get("graphical_session_recording"),
    )
    _append_ref(
        argv,
        "--autofill-credentials",
        connection.get("autofill_credentials_uid_ref"),
        refs,
    )
    _append_repeated(argv, "--autofill-targets", connection.get("autofill_targets"))
    _append_option(
        argv,
        "--allow-url-navigation",
        _on_off(connection.get("allow_url_manipulation")),
    )
    _append_repeated(argv, "--allowed-urls", connection.get("allowed_url_patterns"))
    _append_repeated(
        argv,
        "--allowed-resource-urls",
        connection.get("allowed_resource_url_patterns"),
    )
    _append_option(argv, "--key-events", _on_off(connection.get("recording_include_keys")))
    _append_option(argv, "--allow-copy", _inverse_on_off(connection.get("disable_copy")))
    _append_option(argv, "--allow-paste", _inverse_on_off(connection.get("disable_paste")))
    _append_option(argv, "--ignore-server-cert", _on_off(connection.get("ignore_server_cert")))

    if len(argv) == 5:
        return None
    return argv


def _as_mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _on_off(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return "on" if value else "off"
    return str(value)


def _inverse_on_off(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return "off" if value else "on"
    if value == "on":
        return "off"
    if value == "off":
        return "on"
    return str(value)


def _append_option(argv: list[str], flag: str, value: Any) -> None:
    if value is None:
        return
    rendered = str(value)
    if rendered:
        argv.extend([flag, rendered])


def _append_ref(
    argv: list[str],
    flag: str,
    uid_ref: Any,
    refs: Mapping[str, str],
) -> None:
    if uid_ref is None:
        return
    if not isinstance(uid_ref, str) or not uid_ref:
        return
    resolved = refs.get(uid_ref)
    if not resolved:
        raise ValueError(f"unresolved uid_ref '{uid_ref}' for {flag}")
    argv.extend([flag, resolved])


def _append_repeated(argv: list[str], flag: str, value: Any) -> None:
    if value is None:
        return
    values = [value] if isinstance(value, str) else value
    if not isinstance(values, list | tuple):
        values = [values]
    for item in values:
        rendered = str(item)
        if rendered:
            argv.extend([flag, rendered])


_UNSUPPORTED_CAPABILITY_HINTS: tuple[tuple[str, str, str], ...] = (
    # (dotted manifest path fragment, human name, Commander hook the SDK
    # should eventually drive to fulfil this capability)
    (
        "default_rotation_schedule",
        "pam_configurations[].default_rotation_schedule",
        "no confirmed Commander CLI setter; pam rotation edit --schedule-config only reads config default",
    ),
    ("rotation_schedule", "rotation_schedule (embedded)", "pam rotation edit --schedulecron"),
)

_RBI_UPSTREAM_GAP_OPTION_FIELDS = frozenset(
    {
        "text_session_recording",
    }
)
_RBI_UPSTREAM_GAP_CONNECTION_FIELDS = frozenset(
    {
        "recording_include_keys",
        "disable_audio",
        "audio_channels",
        "audio_bps",
        "audio_sample_rate",
    }
)


def _model_dump_dict(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        dumped = value.model_dump(mode="python", exclude_none=True)
        return dumped if isinstance(dumped, dict) else {}
    return value if isinstance(value, dict) else {}


def _manifest_dict(value: Any) -> dict[str, Any]:
    data = _model_dump_dict(value)
    if not data:
        raise ValueError("manifest data is required to build pam rotation edit argv")
    return data


def _non_empty_str(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value
    return None


def _reject_top_level_user_rotation(source: Mapping[str, Any]) -> None:
    for user in source.get("users") or []:
        if (
            isinstance(user, Mapping)
            and user.get("type") == "pamUser"
            and user.get("rotation_settings")
        ):
            ident = user.get("uid_ref") or user.get("title") or "<unknown>"
            raise ValueError(
                f"top-level users[].rotation_settings is unsupported for pamUser '{ident}'; "
                "nest the pamUser under resources[].users[] so the parent resource UID can be resolved"
            )


def _has_top_level_user_rotation(source: Mapping[str, Any]) -> bool:
    return any(
        isinstance(user, Mapping)
        and user.get("type") == "pamUser"
        and user.get("rotation_settings") is not None
        for user in source.get("users") or []
    )


def _has_nested_user_rotation(source: Mapping[str, Any]) -> bool:
    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        for user in resource.get("users") or []:
            if (
                isinstance(user, Mapping)
                and user.get("type") == "pamUser"
                and user.get("rotation_settings") is not None
            ):
                return True
    return False


def _desired_identity(source: Mapping[str, Any], uid_ref: str) -> tuple[str | None, str | None]:
    for cfg in source.get("pam_configurations") or []:
        if isinstance(cfg, Mapping) and cfg.get("uid_ref") == uid_ref:
            return "pam_configuration", _non_empty_str(cfg.get("title"))
    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        if resource.get("uid_ref") == uid_ref:
            return _non_empty_str(resource.get("type")), _non_empty_str(resource.get("title"))
        for user in resource.get("users") or []:
            if isinstance(user, Mapping) and user.get("uid_ref") == uid_ref:
                return _non_empty_str(user.get("type")) or "pamUser", _non_empty_str(
                    user.get("title")
                )
    for user in source.get("users") or []:
        if isinstance(user, Mapping) and user.get("uid_ref") == uid_ref:
            return _non_empty_str(user.get("type")) or "pamUser", _non_empty_str(user.get("title"))
    return None, None


def _has_resource_rotation(source: Mapping[str, Any]) -> bool:
    for resource in source.get("resources") or []:
        if isinstance(resource, Mapping) and resource.get("rotation_settings") is not None:
            return True
    return False


def _contains_key(node: Any, key: str) -> bool:
    if isinstance(node, dict):
        return key in node or any(_contains_key(value, key) for value in node.values())
    if isinstance(node, list):
        return any(_contains_key(item, key) for item in node)
    return False


def _pam_nested_rotation_schedule_argv(settings: Mapping[str, Any]) -> list[str]:
    """Prefer ``schedule_json`` (``pam rotation edit --schedulejson``) when set.

    Otherwise map the typed ``schedule`` block to ``--schedulecron`` / ``--on-demand``.
    """
    data = _model_dump_dict(settings)
    schedule_json = data.get("schedule_json")
    if schedule_json is not None:
        if isinstance(schedule_json, Mapping):
            return ["--schedulejson", json.dumps(dict(schedule_json), separators=(",", ":"))]
        if isinstance(schedule_json, list):
            return ["--schedulejson", json.dumps(schedule_json, separators=(",", ":"))]
        text = str(schedule_json).strip()
        if text:
            return ["--schedulejson", text]
        return []
    return _rotation_schedule_args(data.get("schedule"))


def _build_pam_rotation_edit_args(
    *,
    record_uid: str,
    settings: Any,
    resource_uid: str | None = None,
    config_uid: str | None = None,
    admin_uid: str | None = None,
    schedule_only: bool = False,
    force: bool = True,
) -> list[str]:
    """Map declarative rotation settings to Commander's `pam rotation edit` argv.

    Pure helper only. `apply_plan` runs nested pamUser rotation by default on
    Commander 18.0.0+ pins; `DSK_EXPERIMENTAL_ROTATION_APPLY=0` remains a
    kill switch for operators who need to disable this slice during triage.
    """
    data = _model_dump_dict(settings)
    args = ["pam", "rotation", "edit", "--record", record_uid]
    if config_uid:
        args += ["--config", config_uid]
    if resource_uid:
        args += ["--resource", resource_uid]
    if admin_uid:
        args += ["--admin-user", admin_uid]
    if data.get("rotation"):
        args += ["--rotation-profile", str(data["rotation"])]
    args += _pam_nested_rotation_schedule_argv(data)
    if data.get("password_complexity"):
        args += ["--complexity", str(data["password_complexity"])]
    enabled = str(data.get("enabled") or "").strip().lower()
    if enabled == "on":
        args.append("--enable")
    elif enabled == "off":
        args.append("--disable")
    if schedule_only:
        args.append("--schedule-only")
    if force:
        args.append("--force")
    return args


_VAULT_UID_RE = re.compile(r"^[A-Za-z0-9_\-]{22}$")


def _db_proxy_tunnel_settings_for_uid_ref(manifest: Any, uid_ref: str) -> dict[str, Any] | None:
    """Return tunnel_settings dict for a pamDatabase resource by uid_ref."""
    source = _manifest_source_dict(manifest)
    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        if resource.get("uid_ref") == uid_ref and resource.get("type") == "pamDatabase":
            ts = resource.get("tunnel_settings")
            return dict(ts) if isinstance(ts, Mapping) else None
    return None


def _db_proxy_post_import_argvs(
    manifest: Any,
    pam_creates_updates: list[Change],
    *,
    dry_run: bool,
) -> list[list[str]]:
    """Collect pam tunnel edit --keeper-db-proxy argvs after pam project import.

    - dry_run=True: returns [] (caller adds db_proxy_note to details).
    - db_proxy_uid_ref is a 22-char base64url vault UID: returns tunnel edit argv.
    - db_proxy_uid_ref is a DSK symbolic ref (e.g. ref.tunnel.*): raises CapabilityError.
    """
    if dry_run:
        return []
    source = _manifest_source_dict(manifest)
    touched = {
        c.uid_ref for c in pam_creates_updates if c.resource_type == "pamDatabase" and c.uid_ref
    }
    argvs: list[list[str]] = []
    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        if resource.get("type") != "pamDatabase":
            continue
        uid_ref = resource.get("uid_ref")
        if uid_ref not in touched:
            continue
        ts = resource.get("tunnel_settings")
        if not isinstance(ts, Mapping) or not ts.get("db_proxy_enabled"):
            continue
        db_proxy_ref = str(ts.get("db_proxy_uid_ref") or "").strip()
        if not db_proxy_ref:
            continue
        ident = uid_ref or resource.get("title") or "<pamDatabase>"
        if _VAULT_UID_RE.match(db_proxy_ref):
            argvs.append(["pam", "tunnel", "edit", db_proxy_ref, "--keeper-db-proxy", "on"])
        else:
            raise CapabilityError(
                reason=(
                    f"pamDatabase '{ident}' sets tunnel_settings.db_proxy_enabled; "
                    "DSK does not run pam tunnel edit --keeper-db-proxy during apply"
                ),
                uid_ref=str(uid_ref or ""),
                resource_type="pamDatabase",
                next_action=(
                    "After the database record exists, run manually: "
                    "`keeper pam tunnel edit <pamDatabase-tunnel-record-uid> --keeper-db-proxy` "
                    "(Gateway v1.8.0+). Resolve `tunnel_settings.db_proxy_uid_ref` to the live tunnel "
                    "UID from the vault, or copy the tunnel record UID from Commander."
                ),
            )
    return argvs


def _pam_database_db_proxy_apply_gate(
    manifest: Any,
    pam_creates_updates: list[Change],
    *,
    dry_run: bool,
) -> None:
    """Validate KeeperDB Proxy settings; raises if uid_ref is a DSK symbolic ref.

    Commander enables proxy with ``pam tunnel edit --keeper-db-proxy`` on the
    tunnel record; that verb is not part of ``pam project import`` / extend.
    Dry-run always passes. Live apply with 22-char vault UID auto-applies via
    _db_proxy_post_import_argvs after import.
    """
    _db_proxy_post_import_argvs(manifest, pam_creates_updates, dry_run=dry_run)


def _detect_unsupported_capabilities(
    manifest: Any,
    *,
    allow_nested_rotation: bool = True,
) -> list[str]:
    """Return human-readable reasons the manifest exceeds this provider.

    Pure detector — does not raise. Returns a list of strings suitable for
    CONFLICT rows in a plan or for a late-apply CapabilityError. Handles
    both ``dict`` manifests (the provider's normalised form) and Pydantic
    ``Manifest`` instances (what the CLI has on hand before building a
    plan); callers pass whichever is convenient.
    """
    if manifest is None:
        return []
    if hasattr(manifest, "model_dump"):
        source = manifest.model_dump(mode="python", exclude_none=True)
    elif hasattr(manifest, "to_dict"):
        source = manifest.to_dict()
    elif isinstance(manifest, dict):
        source = manifest
    else:
        return []

    if source.get("schema") == "keeper-vault.v1" or source.get("vault_schema") == "keeper-vault.v1":
        return []

    if source.get("schema") == POLICY_FAMILY:
        try:
            from dsk.core.models_policy import policy_manifest_from_dict
        except ImportError:
            return [
                "keeper-policy.v1 is not implemented in this build (missing dsk.core.models_policy)"
            ]
        return policy_upstream_gap_reasons(policy_manifest_from_dict(source))

    if (
        source.get("schema") == _PAM_EXTENDED_FAMILY
        or source.get("pam_extended_schema") == _PAM_EXTENDED_FAMILY
    ):
        hits: list[str] = []
        for block in ("resources", "gateway_configs", "service_mappings"):
            if source.get(block):
                hits.append(
                    f"{block} is not implemented for extended PAM manifest Commander apply "
                    "(Commander hook: `pam extended` currently covers schedules and rules only)"
                )
        return hits

    hits = []

    if _has_top_level_user_rotation(source):
        hits.append(
            "top-level users[].rotation_settings is not implemented for pamUser "
            "(Commander hook needs a parent resource; nest the pamUser under resources[].users[])"
        )
    if _has_resource_rotation(source):
        hits.append(
            "resources[].rotation_settings is not implemented "
            "(Commander hook for resource rotation requires a proven mapping)"
        )
    if _has_nested_user_rotation(source) and not allow_nested_rotation:
        hits.append(
            "resources[].users[].rotation_settings is disabled for this provider run "
            "(Commander hook: `pam rotation edit --record / --resource / --schedulecron / --on-demand`; "
            f"unset {_ROTATION_APPLY_ENV_VAR} or set {_ROTATION_APPLY_ENV_VAR}=1 to enable)"
        )

    hits.extend(_detect_rbi_upstream_gap_capabilities(source))

    for needle, human, hook in _UNSUPPORTED_CAPABILITY_HINTS:
        if _contains_key(source, needle):
            hits.append(f"{human} is not implemented (Commander hook: `{hook}`)")

    return hits


def _detect_rbi_upstream_gap_capabilities(source: Mapping[str, Any]) -> list[str]:
    hits: list[str] = []
    for resource in source.get("resources") or []:
        if not isinstance(resource, Mapping):
            continue
        if resource.get("type") != "pamRemoteBrowser":
            continue
        pam_settings = _as_mapping(resource.get("pam_settings"))
        options = _as_mapping(pam_settings.get("options"))
        connection = _as_mapping(pam_settings.get("connection"))

        paths: list[str] = []
        for key in sorted(_RBI_UPSTREAM_GAP_OPTION_FIELDS):
            if key in options and options.get(key) is not None:
                paths.append(f"pam_settings.options.{key}")
        for key in sorted(_RBI_UPSTREAM_GAP_CONNECTION_FIELDS):
            if key in connection and connection.get(key) is not None:
                paths.append(f"pam_settings.connection.{key}")
        if not paths:
            continue

        ident = resource.get("uid_ref") or resource.get("title") or "<unknown>"
        hits.append(
            "upstream-gap: "
            f"pamRemoteBrowser '{ident}' declares unsupported RBI field(s): "
            f"{', '.join(paths)}; not implemented until `pam rbi` writer/readback proof "
            "is complete"
        )
    return hits


def _argv_value(argv: list[str], flag: str) -> str | None:
    try:
        index = argv.index(flag)
    except ValueError:
        return None
    if index + 1 >= len(argv):
        return None
    return argv[index + 1]


# Re-export per-family helpers (extraction round 2026-05-07; see _commander/__init__.py)
from dsk.providers._commander.enterprise import (  # noqa: F401, E402
    _ENTERPRISE_BLOCKS,
    _ENTERPRISE_STATUS,
    _enterprise_bool,
    _enterprise_clean,
    _enterprise_manifest_from_commander_payload,
    _enterprise_manifest_from_commander_rows,
    _enterprise_path_parts,
    _enterprise_ref,
    _enterprise_string_list,
    _enterprise_uid_ref,
    _enterprise_unique_lookup,
)
from dsk.providers._commander.epm import (  # noqa: F401, E402
    _EPM_VALID_CONTROLS,
    _EPM_VALID_POLICY_TYPES,
    _epm_controls,
    _epm_dry_run_outcome,
    _epm_policy_kwargs,
    _epm_policy_name,
    _epm_policy_target,
    _epm_policy_type,
)
from dsk.providers._commander.ksm import (  # noqa: F401, E402
    _KSM_UPSTREAM_GAP_NEXT_ACTIONS,
    _ksm_app_record_uid,
    _ksm_change_bool,
    _ksm_change_name,
    _ksm_client_app_uid,
    _ksm_client_identifiers,
    _ksm_create_result_uid,
    _ksm_plan_changes,
    _ksm_share_keeper_uids,
    _ksm_upstream_gap_next_action,
)
from dsk.providers._commander.msp import (  # noqa: F401, E402
    _MSP_UNLIMITED_SEATS,
    _msp_add_command_kwargs,
    _msp_addon_arg,
    _msp_addons_by_name,
    _msp_change_name,
    _msp_commander_seats,
    _msp_file_plan_display,
    _msp_find_target,
    _msp_guard_update_name_collision,
    _msp_mc_id_from_payload,
    _msp_plan_changes,
    _msp_plan_slug_from_product_id,
    _msp_same_mc,
    _msp_target_mc,
    _msp_update_command_kwargs,
)
from dsk.providers._commander.pam_extended import (  # noqa: F401, E402
    _PAM_EXTENDED_CONFIG_KEYS,
    _PAM_EXTENDED_DISCOVERY_RULE,
    _PAM_EXTENDED_ROTATION_SCHEDULE,
    _PAM_EXTENDED_SUPPORTED_TYPES,
    _pam_extended_change_name,
    _pam_extended_clean_ref,
    _pam_extended_command_spec,
    _pam_extended_config_uid,
    _pam_extended_first_ref,
    _pam_extended_payload_value,
    _pam_extended_plan_changes,
    _pam_extended_rule_pattern,
    _pam_extended_rule_type,
    _pam_extended_schedule_cron,
)
from dsk.providers._commander.rotation import (  # noqa: F401, E402
    _ROTATION_APPLY_ENV_VAR,
    _rotation_admin_uid,
    _rotation_apply_is_enabled,
    _rotation_change_enabled,
    _rotation_change_record_uid,
    _rotation_command_kwargs,
    _rotation_commander_arg_list,
    _rotation_config_ref,
    _rotation_cron_from_string,
    _rotation_enabled_value,
    _rotation_plan_changes,
    _rotation_readback_rows,
    _rotation_schedule_args,
    _rotation_schedule_from_row,
    _rotation_settings_from_readback,
    _rotation_settings_from_row,
)
from dsk.providers._commander.saas import (  # noqa: F401, E402
    _plugins_removed,
    _saas_config_kwargs,
    _saas_dry_run_outcome,
    _saas_gateway,
    _saas_plugin_entry_as_dict,
    _saas_plugin_key,
    _saas_remove_kwargs,
    _saas_set_kwargs,
    _saas_update_kwargs,
    _saas_value,
)
from dsk.providers._commander.workflow import (  # noqa: F401, E402
    _workflow_approver_index,
    _workflow_approvers,
    _workflow_command_kwargs,
    _workflow_dry_run_outcome,
    _workflow_duration,
    _workflow_record,
    _workflow_string_list,
)
from dsk.providers._commander_mixins import (  # noqa: E402
    _EnterpriseMixin,
    _KsmMixin,
    _MspMixin,
    _PamCoreMixin,
    _RotationMixin,
    _SharingMixin,
    _TransportMixin,
    _VaultMixin,
    _WorkflowEpmMixin,
)


class CommanderCliProvider(
    _TransportMixin,
    _PamCoreMixin,
    _VaultMixin,
    _SharingMixin,
    _KsmMixin,
    _MspMixin,
    _EnterpriseMixin,
    _RotationMixin,
    _WorkflowEpmMixin,
    Provider,
):
    """Commander-backed provider — see module docstring."""

    def __init__(
        self,
        *,
        keeper_bin: str | None = None,
        folder_uid: str | None = None,
        config_file: str | None = None,
        manifest_source: dict[str, Any] | None = None,
        keeper_password: str | None = None,
        apply_manifest_path: str | None = None,
        service_mode: bool | None = None,
        service_url: str | None = None,
        service_api_key: str | None = None,
        service_client: Any | None = None,
    ) -> None:
        self._bin = keeper_bin or os.environ.get("KEEPER_BIN", "keeper")
        self._folder_uid = folder_uid or os.environ.get("KEEPER_DECLARATIVE_FOLDER")
        self.last_resolved_folder_uid: str | None = None
        self.last_resolved_users_folder_uid: str | None = None
        self._config = config_file or os.environ.get("KEEPER_CONFIG")
        # Commander's persistent-login still needs the master password on
        # subprocess invocation to unlock the local key; honor --batch-mode by
        # sourcing it from constructor or KEEPER_PASSWORD rather than prompting.
        self._password = keeper_password or os.environ.get("KEEPER_PASSWORD")
        self._manifest_source = manifest_source or {}
        self._apply_manifest_path = apply_manifest_path
        self._manifest_name = self._manifest_name_from_source()
        # In-process Commander session — lazily established the first time a
        # subcommand can't run reliably via subprocess (e.g. `pam project
        # import` / `extend` hit persistent-login re-auth prompts in batch
        # mode). Params are cached for
        # the lifetime of the provider.
        self._keeper_params: Any | None = None
        self._keeper_login_attempted = False
        self._ksm_app_rows_cache: list[dict[str, str]] | None = None
        self._service_mode = (
            _env_truthy(os.environ.get("KEEPER_SERVICE_MODE"))
            if service_mode is None
            else bool(service_mode)
        )
        self._service_url = service_url or os.environ.get(
            "KEEPER_SERVICE_URL", "http://localhost:4020"
        )
        self._service_api_key = (
            service_api_key
            if service_api_key is not None
            else os.environ.get("KEEPER_SERVICE_API_KEY")
        )
        self._service_timeout = _env_int("KEEPER_SERVICE_TIMEOUT", 300)
        self._service_start_timeout = _env_float("KEEPER_SERVICE_START_TIMEOUT", 15.0)
        self._service_autostart = not _env_falsey(os.environ.get("KEEPER_SERVICE_AUTOSTART"))
        self._service_client: Any | None = service_client
        self._service_ready = False

        self._bin_path = shutil.which(self._bin)
        if not self._bin_path and not self._service_mode:
            raise CapabilityError(
                reason=f"keeper CLI not found on PATH (looked up '{self._bin}')",
                next_action="install Keeper Commander or set KEEPER_BIN",
            )


__all__ = [
    "CommanderCliProvider",
    "build_pam_rotation_edit_argvs",
    "build_post_import_tuning_argvs",
    "build_pam_workflow_apply_argvs",
]
