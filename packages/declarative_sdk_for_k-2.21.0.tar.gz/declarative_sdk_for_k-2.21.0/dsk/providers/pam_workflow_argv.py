"""Argv builders for ``pam workflow`` apply on PAM machine/database/directory rows."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from dsk.core.diff import ChangeKind

_WORKFLOW_RESOURCE_TYPES = frozenset({"pamMachine", "pamDatabase", "pamDirectory"})

_DAY_TO_CLI: dict[str, str] = {
    "Mon": "mon",
    "Tue": "tue",
    "Wed": "wed",
    "Thu": "thu",
    "Fri": "fri",
    "Sat": "sat",
    "Sun": "sun",
}


def _manifest_user_emails_by_uid_ref(source: Mapping[str, Any]) -> dict[str, str]:
    """Map ``uid_ref`` of nested ``pamUser`` rows to an email/login string."""
    out: dict[str, str] = {}
    for resource in source.get("resources") or []:
        if not isinstance(resource, dict):
            continue
        for user in resource.get("users") or []:
            if not isinstance(user, dict) or user.get("type") != "pamUser":
                continue
            ref = user.get("uid_ref")
            if not isinstance(ref, str) or not ref:
                continue
            login = user.get("login")
            if isinstance(login, str) and login.strip():
                out[ref] = login.strip()
                continue
            title = user.get("title")
            if isinstance(title, str) and title.strip():
                out[ref] = title.strip()
    for user in source.get("users") or []:
        if not isinstance(user, dict) or user.get("type") != "pamUser":
            continue
        ref = user.get("uid_ref")
        if not isinstance(ref, str) or not ref:
            continue
        login = user.get("login")
        if isinstance(login, str) and login.strip():
            out[ref] = login.strip()
        else:
            title = user.get("title")
            if isinstance(title, str) and title.strip():
                out[ref] = title.strip()
    return out


def _access_duration_flag(minutes_val: Any) -> str | None:
    if minutes_val is None:
        return None
    try:
        m = int(minutes_val)
    except (TypeError, ValueError):
        return None
    if m <= 0:
        return None
    return f"{m}m"


def _allowed_days_csv(days: Any) -> str | None:
    if not isinstance(days, list) or not days:
        return None
    tokens: list[str] = []
    for item in days:
        if item is None:
            continue
        key = str(item)
        cli = _DAY_TO_CLI.get(key)
        if cli is None:
            continue
        tokens.append(cli)
    return ",".join(tokens) if tokens else None


def _time_range(ws: Mapping[str, Any]) -> str | None:
    start = ws.get("allowed_from_time")
    end = ws.get("allowed_to_time")
    if isinstance(start, str) and isinstance(end, str) and start.strip() and end.strip():
        return f"{start.strip()}-{end.strip()}"
    return None


def _resolve_approver_emails(
    ws: Mapping[str, Any], manifest: Mapping[str, Any] | None
) -> list[str]:
    raw = ws.get("approver_uid_refs") or []
    if not raw:
        return []
    if manifest is None:
        raise ValueError("manifest required to resolve workflow_settings.approver_uid_refs")
    by_ref = _manifest_user_emails_by_uid_ref(manifest)
    emails: list[str] = []
    for ref in raw:
        if not isinstance(ref, str) or not ref:
            continue
        email = by_ref.get(ref)
        if not email:
            raise ValueError(
                f"approver_uid_ref {ref!r} has no pamUser login/title in manifest to pass "
                f"to pam workflow --approver/--user"
            )
        emails.append(email)
    return emails


def _append_update_bool(argv: list[str], flag: str, value: Any) -> None:
    if value is None:
        return
    if isinstance(value, bool):
        argv.extend([flag, "true" if value else "false"])
        return
    text = str(value).strip().lower()
    if text in {"true", "1", "yes", "on"}:
        argv.extend([flag, "true"])
    elif text in {"false", "0", "no", "off"}:
        argv.extend([flag, "false"])


def build_pam_workflow_apply_argvs(
    record_uid: str,
    resource: Mapping[str, Any],
    *,
    change_kind: ChangeKind,
    manifest: Mapping[str, Any] | None = None,
) -> list[list[str]]:
    """Return Commander argv lists for ``pam workflow create|update``."""
    ws_raw = resource.get("workflow_settings")
    if not isinstance(ws_raw, Mapping):
        return []
    if resource.get("type") not in _WORKFLOW_RESOURCE_TYPES:
        return []

    ws = dict(ws_raw)
    if not any(v not in (None, [], {}) for v in ws.values()):
        return []

    emails = _resolve_approver_emails(ws, manifest)
    if change_kind is ChangeKind.UPDATE and (ws.get("approver_uid_refs") or []):
        raise ValueError(
            "workflow_settings.approver_uid_refs on UPDATE is unsupported — "
            "use Commander `pam workflow add-approver` after apply"
        )

    if change_kind is ChangeKind.CREATE:
        return [_build_workflow_create_argv(record_uid, ws, emails)]
    if change_kind is ChangeKind.UPDATE:
        upd = _build_workflow_update_argv(record_uid, ws)
        return [upd] if upd else []
    return []


def _build_workflow_create_argv(
    record_uid: str, ws: dict[str, Any], emails: list[str]
) -> list[str]:
    argv = ["pam", "workflow", "create", record_uid]
    an = ws.get("approvals_needed")
    if an is not None:
        argv.extend(["-n", str(int(an))])
    if ws.get("checkout_needed"):
        argv.append("-co")
    if ws.get("start_access_on_approval"):
        argv.append("-sa")
    if ws.get("require_reason"):
        argv.append("-rr")
    if ws.get("require_ticket"):
        argv.append("-rt")
    if ws.get("require_mfa"):
        argv.append("-rm")
    dur = _access_duration_flag(ws.get("access_length"))
    if dur:
        argv.extend(["-d", dur])
    days = _allowed_days_csv(ws.get("allowed_days"))
    if days:
        argv.extend(["--allowed-days", days])
    tr = _time_range(ws)
    if tr:
        argv.extend(["--time-range", tr])
    tz = ws.get("allowed_timezone")
    if isinstance(tz, str) and tz.strip():
        argv.extend(["--timezone", tz.strip()])
    for email in emails:
        argv.extend(["-u", email])
    return argv


def _build_workflow_update_argv(record_uid: str, ws: dict[str, Any]) -> list[str] | None:
    argv = ["pam", "workflow", "update", record_uid]
    had = False
    if ws.get("approvals_needed") is not None:
        argv.extend(["-n", str(int(ws["approvals_needed"]))])
        had = True
    before = len(argv)
    _append_update_bool(argv, "-co", ws.get("checkout_needed"))
    _append_update_bool(argv, "-sa", ws.get("start_access_on_approval"))
    _append_update_bool(argv, "-rr", ws.get("require_reason"))
    _append_update_bool(argv, "-rt", ws.get("require_ticket"))
    _append_update_bool(argv, "-rm", ws.get("require_mfa"))
    if len(argv) > before:
        had = True
    dur = _access_duration_flag(ws.get("access_length"))
    if dur:
        argv.extend(["-d", dur])
        had = True
    days = _allowed_days_csv(ws.get("allowed_days"))
    if days:
        argv.extend(["--allowed-days", days])
        had = True
    tr = _time_range(ws)
    if tr:
        argv.extend(["--time-range", tr])
        had = True
    tz = ws.get("allowed_timezone")
    if isinstance(tz, str) and tz.strip():
        argv.extend(["--timezone", tz.strip()])
        had = True
    if not had:
        return None
    return argv


__all__ = ["build_pam_workflow_apply_argvs"]
