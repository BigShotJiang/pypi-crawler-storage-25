"""REST-backed provider for ``ai-token.v1``."""

from __future__ import annotations

from typing import Any

from dsk.core.ai_token_diff import compute_ai_token_diff
from dsk.core.models_ai_token import AiTokenManifestV1
from dsk.core.planner import Plan, build_plan
from dsk.providers.rest_provider_base import (
    KeeperRestProvider,
    config_from_response,
    configuration_from_plan,
    endpoint_from_env_or_override,
    outcomes_from_plan,
    plan_has_mutations,
)

AI_TOKEN_FAMILY = "ai-token.v1"
_BLOCKS = ("tokens",)
_RESOURCE_TO_BLOCK = {"ai_capability_token": "tokens"}
_NEXT_ACTION = (
    "Keeper needs to ship or document AI capability-token bundle REST verbs; "
    "until then set DSK_KEEPER_AI_TOKEN_ENDPOINT_BASE or the read/write endpoint "
    "overrides for a lab-proven API"
)


class AiTokenProvider(KeeperRestProvider):
    """Plan/apply AI credential bundle declarations through Keeper REST."""

    def __init__(self, *, endpoint_base: str | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._endpoint_base = endpoint_base

    def plan(self, manifest: AiTokenManifestV1, *, allow_delete: bool = False) -> Plan:
        del allow_delete
        self._last_desired_config = _desired_config(manifest)
        live = self.discover_ai_token_configuration()
        changes = compute_ai_token_diff(
            manifest,
            live if live.get("tokens") else None,
            manifest_name=self._manifest_name or manifest.name,
        )
        return build_plan(self._manifest_name or manifest.name, changes, _order(manifest))

    def apply(self, manifest: AiTokenManifestV1, *, dry_run: bool = False) -> list[Any]:
        return self.apply_ai_token_plan(self.plan(manifest), dry_run=dry_run)

    def discover_ai_token_configuration(self) -> dict[str, Any]:
        # ENDPOINT-UNKNOWN: no dedicated Keeper AI capability-token REST
        # readback API is confirmed. The path is override-driven.
        endpoint = self._endpoint(read=True)
        response = self._rest_post(endpoint, {"method": "GET", "family": AI_TOKEN_FAMILY})
        return config_from_response(response, blocks=_BLOCKS)

    def apply_ai_token_plan(self, plan: Plan, *, dry_run: bool = False) -> list[Any]:
        if dry_run or not plan_has_mutations(plan):
            return outcomes_from_plan(plan, dry_run=dry_run, family=AI_TOKEN_FAMILY)
        # ENDPOINT-UNKNOWN: see discover_ai_token_configuration.
        endpoint = self._endpoint(read=False)
        config = getattr(
            self,
            "_last_desired_config",
            configuration_from_plan(plan, resource_to_block=_RESOURCE_TO_BLOCK),
        )
        self._rest_post(
            endpoint,
            {"method": "PUT", "family": AI_TOKEN_FAMILY, "configuration": config},
        )
        return outcomes_from_plan(plan, dry_run=dry_run, family=AI_TOKEN_FAMILY, endpoint=endpoint)

    def _endpoint(self, *, read: bool) -> str:
        return endpoint_from_env_or_override(
            read=read,
            family=AI_TOKEN_FAMILY,
            endpoint_base=self._endpoint_base,
            base_env="DSK_KEEPER_AI_TOKEN_ENDPOINT_BASE",
            read_env="DSK_KEEPER_AI_TOKEN_READ_ENDPOINT",
            write_env="DSK_KEEPER_AI_TOKEN_WRITE_ENDPOINT",
            next_action=_NEXT_ACTION,
        )


def _order(manifest: AiTokenManifestV1) -> list[str]:
    return [f"{manifest.name}.{index}" for index, _token in enumerate(manifest.tokens)]


def _desired_config(manifest: AiTokenManifestV1) -> dict[str, Any]:
    data = manifest.model_dump(mode="json", exclude_none=True, by_alias=True)
    return {"tokens": data.get("tokens") or []}


__all__ = ["AI_TOKEN_FAMILY", "AiTokenProvider"]
