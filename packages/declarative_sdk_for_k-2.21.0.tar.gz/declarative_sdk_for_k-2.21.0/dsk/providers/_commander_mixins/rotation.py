"""Mixin — rotation resource family of CommanderCliProvider.

Private implementation module. Not a public API.
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome
from dsk.core.planner import Plan
from dsk.providers._commander.pam_extended import (
    _PAM_EXTENDED_SUPPORTED_TYPES,
    _pam_extended_change_name,
    _pam_extended_command_spec,
    _pam_extended_plan_changes,
)
from dsk.providers._commander.rotation import (
    _rotation_change_record_uid,
    _rotation_command_kwargs,
    _rotation_plan_changes,
)

if TYPE_CHECKING:
    pass


def _ensure_keepercommander_version_for_apply() -> None:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    _cli_m._ensure_keepercommander_version_for_apply()


class _RotationMixin:
    """Method carrier — rotation resource family."""

    if TYPE_CHECKING:
        # Cross-mixin methods (transport)
        def _get_keeper_params(self) -> Any: ...
        def _with_keeper_session_refresh(self, fn: Any, *a: Any, **kw: Any) -> Any: ...

    def apply_rotation_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply ``rotation-policy.v1`` rows through ``pam rotation edit``."""
        changes = _rotation_plan_changes(plan)
        outcomes: list[ApplyOutcome] = []
        command_cls: Any | None = None
        for change in changes:
            record_uid_ref = _rotation_change_record_uid(change)

            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or record_uid_ref,
                        keeper_uid=change.keeper_uid or record_uid_ref,
                        action="conflict",
                        details={"reason": change.reason or ""},
                    )
                )
                continue

            if change.kind not in (ChangeKind.CREATE, ChangeKind.UPDATE):
                details: dict[str, Any] = {"dry_run": dry_run}
                if change.reason is not None:
                    details["reason"] = change.reason
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or record_uid_ref,
                        keeper_uid=change.keeper_uid or record_uid_ref,
                        action="noop",
                        details=details,
                    )
                )
                continue

            kwargs = _rotation_command_kwargs(change)
            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or record_uid_ref,
                        keeper_uid=change.keeper_uid or record_uid_ref,
                        action="update",
                        details={"dry_run": True, "kwargs": kwargs},
                    )
                )
                continue

            _ensure_keepercommander_version_for_apply()
            if command_cls is None:
                try:
                    from keepercommander.commands.discoveryrotation import (
                        PAMCreateRecordRotationCommand,
                    )
                except (ImportError, AttributeError) as exc:
                    raise CapabilityError(
                        reason=f"Commander PAMCreateRecordRotationCommand is unavailable: {exc}",
                        uid_ref=change.uid_ref or record_uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "upgrade keepercommander to a version that provides "
                            "keepercommander.commands.discoveryrotation.PAMCreateRecordRotationCommand"
                        ),
                    ) from exc
                command_cls = PAMCreateRecordRotationCommand

            def _run_rotation() -> Any:
                params = self._get_keeper_params()
                command = command_cls()
                if not hasattr(command, "execute"):
                    raise CapabilityError(
                        reason=(
                            "Commander PAMCreateRecordRotationCommand has no "
                            "execute(params, **kwargs) API"
                        ),
                        uid_ref=change.uid_ref or record_uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "need PAMCreateRecordRotationCommand.execute(params, "
                            "record_name, schedule_json_data, schedule_cron_data, on_demand, "
                            "rotation_profile, resource, config, enable, disable, force)"
                        ),
                    )
                return command.execute(params, **kwargs)

            try:
                self._with_keeper_session_refresh(_run_rotation)
            except CapabilityError:
                raise
            except Exception as exc:
                raise CapabilityError(
                    reason=(f"rotation-policy.v1 apply failed: {type(exc).__name__}: {exc}"),
                    uid_ref=change.uid_ref or record_uid_ref,
                    resource_type=change.resource_type,
                    next_action=(
                        "verify the PAM record UID/path, optional resource/config UIDs, "
                        "schedule payload, and Commander session permissions"
                    ),
                    context={"kwargs": kwargs},
                ) from exc

            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or record_uid_ref,
                    keeper_uid=record_uid_ref,
                    action="update",
                    details={"dry_run": False, "kwargs": kwargs},
                )
            )
        return outcomes

    def apply_pam_extended_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply extended PAM manifest schedules and discovery rules through Commander.

        Expects in-process Commander command classes backing the ``pam extended`` CLI surface.
        Schedule naming is explicit while PAM protobuf readback stays record-level;
        unsupported extended-PAM blocks raise instead of silently skipping.
        """
        changes = _pam_extended_plan_changes(plan)
        outcomes: list[ApplyOutcome] = []
        version_checked = False
        for change in changes:
            name = _pam_extended_change_name(change)
            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or ""},
                    )
                )
                continue
            if change.kind not in (ChangeKind.CREATE, ChangeKind.UPDATE, ChangeKind.DELETE):
                details: dict[str, Any] = {"dry_run": dry_run}
                if change.reason is not None:
                    details["reason"] = change.reason
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details=details,
                    )
                )
                continue
            if change.resource_type not in _PAM_EXTENDED_SUPPORTED_TYPES:
                raise CapabilityError(
                    reason=(
                        f"{change.resource_type} is not implemented for "
                        "extended PAM manifest Commander apply"
                    ),
                    uid_ref=change.uid_ref,
                    resource_type=change.resource_type,
                    next_action=(
                        "limit Commander apply to rotation_schedules and discovery_rules, "
                        "or add a dedicated Commander verb for this block"
                    ),
                )

            module_name, class_name, kwargs, argv = _pam_extended_command_spec(change)
            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action=change.kind.value,
                        details={
                            "dry_run": True,
                            "kwargs": kwargs,
                            "commander_argv": argv,
                        },
                    )
                )
                continue

            if not version_checked:
                _ensure_keepercommander_version_for_apply()
                version_checked = True
            self._run_pam_extended_command_in_process(
                module_name=module_name,
                class_name=class_name,
                kwargs=kwargs,
                change=change,
            )
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or name,
                    keeper_uid=change.keeper_uid or "",
                    action=change.kind.value,
                    details={
                        "dry_run": False,
                        "kwargs": kwargs,
                        "commander_argv": argv,
                    },
                )
            )
        return outcomes

    def _run_pam_extended_command_in_process(
        self,
        *,
        module_name: str,
        class_name: str,
        kwargs: dict[str, Any],
        change: Change,
    ) -> None:
        def run_once() -> Any:
            params = self._get_keeper_params()
            try:
                module = importlib.import_module(module_name)
                command_cls = getattr(module, class_name)
            except (ImportError, AttributeError) as exc:
                raise CapabilityError(
                    reason=f"Commander pam extended command {module_name}.{class_name} is unavailable: {exc}",
                    uid_ref=change.uid_ref,
                    resource_type=change.resource_type,
                    next_action=(
                        "install the Commander fork branch that provides "
                        "`pam extended schedule` and `pam extended rule`"
                    ),
                ) from exc
            command = command_cls()
            if not hasattr(command, "execute"):
                raise CapabilityError(
                    reason=f"Commander pam extended command {class_name} has no execute(params, **kwargs)",
                    uid_ref=change.uid_ref,
                    resource_type=change.resource_type,
                    next_action="update the Commander fork command class to expose execute(params, **kwargs)",
                )
            return command.execute(params, **kwargs)

        try:
            self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=(
                    f"Extended PAM manifest apply failed via {class_name}: "
                    f"{type(exc).__name__}: {exc}"
                ),
                uid_ref=change.uid_ref,
                resource_type=change.resource_type,
                next_action="verify the PAM config UID, rule/schedule payload, and Commander session",
                context={"kwargs": kwargs},
            ) from exc
