"""Mixin — pam_core resource family of CommanderCliProvider.

Private implementation module. Not a public API.
"""

from __future__ import annotations

import json
import tempfile
from collections.abc import Mapping
from pathlib import Path
from typing import TYPE_CHECKING, Any

from dsk.core.checkpoint import ApplyCheckpoint
from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError, CollisionError
from dsk.core.interfaces import ApplyOutcome, LiveRecord
from dsk.core.metadata import (
    encode_marker,
)
from dsk.core.planner import Plan
from dsk.core.vault_models import (
    VAULT_SUPPORTED_RECORD_TYPES,
    normalize_vault_record_type,
)
from dsk.providers._commander.enterprise import (
    _enterprise_manifest_from_commander_rows,
)
from dsk.providers._commander.rotation import (
    _rotation_apply_is_enabled,
    _rotation_settings_from_readback,
)
from dsk.providers._commander_cli_helpers import (
    _entry_uid_by_name,
    _field_drift,
    _has_existing,
    _load_json,
    _merge_rbi_dag_options_into_pam_settings,
    _pam_configuration_uid_ref,
    _payload_for_extend,
    _record_from_get,
    _uses_reference_existing,
)
from dsk.providers.commander_cli import (
    _KSM_APP_RESOURCE_TYPE,
    _KSM_BLOCKS,
    LOGGER,
    _checkpoint_manifest_hash,
    _checkpoint_uid,
    _commander_mc_dict_to_sdk_row,
    _db_proxy_post_import_argvs,
    _db_proxy_tunnel_settings_for_uid_ref,
    _ensure_pam_workflow_config_commands_available,
    _index_live_records_for_title_matching,
    _live_matches_by_identity,
    _manifest_source_dict,
    _manifest_source_is_epm,
    _manifest_source_is_epm_policy,
    _manifest_source_is_pam_extended,
    _manifest_source_is_privileged_access,
    _manifest_source_is_saas_rotation,
    _manifest_source_is_sharing,
    _manifest_source_is_vault,
    _manifest_source_is_workflow,
    _nested_rotation_user_targets,
    _pam_database_db_proxy_apply_gate,
    _preview_post_import_tuning_argvs,
    _preview_rotation_argvs_by_ref,
    _resolve_post_import_tuning_argvs,
)

if TYPE_CHECKING:
    pass


def _ensure_keepercommander_version_for_apply() -> None:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    _cli_m._ensure_keepercommander_version_for_apply()


def utc_timestamp() -> str:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m.utc_timestamp()  # type: ignore[no-any-return]


def to_pam_import_json(source: Any) -> dict[str, Any]:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m.to_pam_import_json(source)  # type: ignore[no-any-return]


def _detect_unsupported_capabilities(
    manifest: Any, *, allow_nested_rotation: bool = False
) -> list[str]:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m._detect_unsupported_capabilities(
        manifest, allow_nested_rotation=allow_nested_rotation
    )  # type: ignore[no-any-return]


def _supports_pam_project_export() -> bool:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m._supports_pam_project_export()  # type: ignore[no-any-return]


def _supports_rotation_info_json() -> bool:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m._supports_rotation_info_json()  # type: ignore[no-any-return]


class _PamCoreMixin:
    """Method carrier — pam_core resource family."""

    if TYPE_CHECKING:
        # Instance attrs
        _apply_manifest_path: str | None
        _folder_uid: str | None
        last_resolved_folder_uid: str | None
        last_resolved_users_folder_uid: str | None
        _keeper_params: Any | None
        _manifest_name: str | None
        _manifest_source: dict[str, Any]

        # Cross-mixin methods (transport)
        def _get_keeper_params(self) -> Any: ...
        def _invalidate_keeper_params(self) -> None: ...
        def _run_cmd(self, args: list[str]) -> str: ...
        def _run_enterprise_info_cmd(self, args: list[str], *, command: str) -> str: ...
        def _run_pam_gateway_in_process(self, args: list[str]) -> str: ...
        def _with_keeper_session_refresh(self, fn: Any, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (vault)
        def _apply_pam_user_saas_plugins(self, *a: Any, **kw: Any) -> Any: ...
        def _apply_resource_attachments(self, *a: Any, **kw: Any) -> Any: ...
        def _apply_rotation_scripts(self, *a: Any, **kw: Any) -> Any: ...
        def _apply_rotation_settings(self, *a: Any, **kw: Any) -> Any: ...
        def _apply_vault_plan(self, *a: Any, **kw: Any) -> Any: ...
        def _discover_folder_uids(self, *a: Any, **kw: Any) -> Any: ...
        def _ensure_folder_exists(self, *a: Any, **kw: Any) -> Any: ...
        def _ensure_shared_folder_exists(self, *a: Any, **kw: Any) -> Any: ...
        def _write_marker(self, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (sharing)
        def _apply_sharing_plan(self, *a: Any, **kw: Any) -> Any: ...
        def _discover_sharing_rows(self, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (ksm)
        def _gateway_bound_app_name(self, *a: Any, **kw: Any) -> Any: ...
        def _ksm_app_marker(self, *a: Any, **kw: Any) -> Any: ...
        def _ksm_app_rows(self) -> list[dict[str, str]]: ...
        def _ksm_app_share_rows(self, *a: Any, **kw: Any) -> Any: ...
        def _share_folder_to_ksm_app(self, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (workflow_epm)
        def _manifest_source_is_ai_agent(self, plan: object) -> bool: ...
        def _manifest_source_is_nhi(self, plan: object) -> bool: ...
        def apply_ai_agent_plan(self, *a: Any, **kw: Any) -> Any: ...
        def apply_epm_policy_plan(self, *a: Any, **kw: Any) -> Any: ...
        def apply_nhi_plan(self, *a: Any, **kw: Any) -> Any: ...
        def apply_pam_extended_plan(self, *a: Any, **kw: Any) -> Any: ...
        def apply_privileged_access_plan(self, *a: Any, **kw: Any) -> Any: ...
        def apply_saas_rotation_plan(self, *a: Any, **kw: Any) -> Any: ...
        def apply_workflow_plan(self, *a: Any, **kw: Any) -> Any: ...

    def _manifest_has_resource_entries(self) -> bool:
        """True when ``manifest_source`` includes a non-empty ``resources`` list."""
        ms = self._manifest_source
        if not isinstance(ms, dict):
            return False
        resources = ms.get("resources")
        return isinstance(resources, list) and bool(resources)

    def discover(self) -> list[LiveRecord]:
        if _manifest_source_is_sharing(self._manifest_source):
            return self._discover_sharing_rows()

        folder_uids = self._discover_folder_uids()
        if not folder_uids:
            raise CapabilityError(
                reason=(
                    "CommanderCliProvider has no folder_uid for discover(); "
                    "pass an explicit folder_uid or run apply_plan() first so "
                    "the provider can resolve the project Resources folder"
                ),
                next_action="pass --folder-uid (or KEEPER_DECLARATIVE_FOLDER), or call apply_plan() first",
            )

        records: list[LiveRecord] = []
        seen_uids: set[str] = set()
        for folder_uid in folder_uids:
            payload = self._run_cmd(["ls", folder_uid, "--format", "json"])
            entries = _load_json(payload, command="ls --format json")
            if not isinstance(entries, list):
                raise CapabilityError(
                    reason="Commander returned non-array JSON from `ls --format json`"
                )
            for entry in entries:
                if not isinstance(entry, dict) or entry.get("type") != "record":
                    continue
                keeper_uid = entry.get("uid")
                if not keeper_uid:
                    continue
                keeper_uid = str(keeper_uid)
                if keeper_uid in seen_uids:
                    continue
                seen_uids.add(keeper_uid)
                listing_entry = dict(entry)
                listing_entry.setdefault("folder_uid", folder_uid)
                item_payload = self._run_cmd(["get", keeper_uid, "--format", "json"])
                item = _load_json(item_payload, command="get --format json")
                if not isinstance(item, dict):
                    raise CapabilityError(
                        reason="Commander returned non-object JSON from `get --format json`"
                    )
                record = _record_from_get(item, listing_entry=listing_entry)
                if record is not None:
                    records.append(record)
        if _manifest_source_is_vault(self._manifest_source):
            records = [
                r
                for r in records
                if normalize_vault_record_type(r.resource_type) in VAULT_SUPPORTED_RECORD_TYPES
            ]
        elif (config_record := self._synthetic_reference_configuration_record()) is not None:
            records.append(config_record)
        if any(r.resource_type == "pamRemoteBrowser" for r in records):
            if self._keeper_params is None and self._manifest_has_resource_entries():
                try:
                    self._get_keeper_params()
                except CapabilityError:
                    # Subprocess-only discover remains valid; TunnelDAG merge is best-effort.
                    pass
        if self._keeper_params is not None:
            self._enrich_pam_remote_browser_dag_options(records)
        self._enrich_pam_user_rotation_settings(records)
        return records

    def discover_managed_companies(self) -> list[dict[str, Any]]:
        """Load managed companies via in-process ``api.query_enterprise`` (MSP admin)."""
        try:
            from keepercommander import api
        except ImportError as exc:
            raise CapabilityError(
                reason=f"MSP discover requires keepercommander: {exc}",
                next_action="pip install 'keepercommander>=18.0.0,<19'",
            ) from exc

        def _run_discover() -> list[dict[str, Any]]:
            params = self._get_keeper_params()
            api.query_enterprise(params)
            ent = getattr(params, "enterprise", None) or {}
            raw = ent.get("managed_companies")
            if not isinstance(raw, list):
                return []
            rows: list[dict[str, Any]] = []
            for mc in raw:
                if not isinstance(mc, dict):
                    continue
                try:
                    rows.append(_commander_mc_dict_to_sdk_row(mc))
                except (KeyError, TypeError, ValueError):
                    continue
            rows.sort(key=lambda r: str(r["name"]).casefold())
            return rows

        try:
            return self._with_keeper_session_refresh(_run_discover)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"MSP managed-company discover failed: {type(exc).__name__}: {exc}",
                next_action="ensure MSP admin session; run `keeper msp-down` then retry",
            ) from exc

    def discover_ksm_state(self) -> dict[str, list[dict[str, Any]]]:
        """Load SDK-owned KSM applications from Commander app-list output."""
        state: dict[str, list[dict[str, Any]]] = {block: [] for block in _KSM_BLOCKS}
        rows = self._ksm_app_rows()
        for row in rows:
            app_uid = row.get("app_uid") or ""
            if not app_uid:
                continue
            marker = self._ksm_app_marker(app_uid)
            if not marker:
                continue
            if marker.get("resource_type") != _KSM_APP_RESOURCE_TYPE:
                continue
            if self._manifest_name and marker.get("manifest") != self._manifest_name:
                continue
            uid_ref = marker.get("uid_ref")
            if not isinstance(uid_ref, str) or not uid_ref:
                continue
            title = row.get("app_title") or uid_ref
            state["apps"].append(
                {
                    "uid_ref": uid_ref,
                    "name": title,
                    "keeper_uid": app_uid,
                    "scopes": [],
                    "allowed_ips": [],
                }
            )
            state["record_shares"].extend(self._ksm_app_share_rows(app_uid, app_uid_ref=uid_ref))
        return state

    def discover_enterprise(self) -> dict[str, Any]:
        """Load enterprise nodes/users/roles/teams via Commander ``enterprise-info``."""

        def rows(args: list[str], *, command: str) -> list[dict[str, Any]]:
            payload = _load_json(
                self._run_enterprise_info_cmd(args, command=command),
                command=command,
            )
            if not isinstance(payload, list):
                raise CapabilityError(
                    reason=f"Commander returned non-array JSON from `{command}`",
                    next_action="upgrade Commander to a version with enterprise-info JSON list output",
                )
            return [dict(row) for row in payload if isinstance(row, Mapping)]

        try:
            node_rows = rows(
                ["enterprise-info", "-n", "-v", "--format", "json"],
                command="enterprise-info -n -v --format json",
            )
            if not node_rows:
                raise CapabilityError(
                    reason="Commander enterprise-info returned no node rows",
                    next_action="run `keeper enterprise-info -n -v --format json` and confirm admin access",
                )
            user_rows = rows(
                ["enterprise-info", "-u", "-v", "--format", "json"],
                command="enterprise-info -u -v --format json",
            )
            role_rows = rows(
                [
                    "enterprise-info",
                    "-r",
                    "-v",
                    "--format",
                    "json",
                    "--columns",
                    "visible_below,default_role,admin,node,user_count,users,team_count,teams",
                ],
                command="enterprise-info -r -v --format json",
            )
            team_rows = rows(
                [
                    "enterprise-info",
                    "-t",
                    "-v",
                    "--format",
                    "json",
                    "--columns",
                    "restricts,node,user_count,users,role_count,roles",
                ],
                command="enterprise-info -t -v --format json",
            )
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"enterprise-info discover failed: {type(exc).__name__}: {exc}",
                next_action="ensure enterprise admin session; run `keeper enterprise-info` then retry",
            ) from exc

        return _enterprise_manifest_from_commander_rows(
            nodes=node_rows,
            users=user_rows,
            roles=role_rows,
            teams=team_rows,
        )

    def _resolve_pam_configuration_keeper_uid(
        self, live: LiveRecord, records: list[LiveRecord]
    ) -> str | None:
        """Resolve manifest ``pam_configuration_uid_ref`` to a live pam_configuration UID."""
        marker = live.marker or {}
        uid_ref = marker.get("uid_ref")
        if not isinstance(uid_ref, str) or not uid_ref.strip():
            return None
        ms = self._manifest_source
        if not isinstance(ms, dict):
            return None
        pam_cfg_ref: str | None = None
        for res in ms.get("resources") or []:
            if isinstance(res, dict) and res.get("uid_ref") == uid_ref:
                pref = res.get("pam_configuration_uid_ref")
                if isinstance(pref, str) and pref.strip():
                    pam_cfg_ref = pref.strip()
                break
        if not pam_cfg_ref:
            return None
        for lr in records:
            if lr.resource_type != "pam_configuration":
                continue
            m = lr.marker or {}
            if m.get("uid_ref") == pam_cfg_ref:
                return str(lr.keeper_uid)
        return None

    def _enrich_pam_remote_browser_dag_options(self, records: list[LiveRecord]) -> None:
        """Merge DAG ``allowedSettings`` into discovered RBI ``pam_settings.options``.

        Commander's ``pam rbi edit --remote-browser-isolation`` persists the RBI
        toggle on the resource vertex as ``allowedSettings.connections``; session
        recording uses ``allowedSettings.sessionRecording``. When an in-process
        ``KeeperParams`` session exists (for example after apply), map those
        tri-states back onto manifest-shaped ``pam_settings.options`` so smoke
        verify and re-plan can see post-tuning state without direct DAG writes
        from the SDK. :meth:`discover` may call :meth:`_get_keeper_params` once
        when RBI records are present and ``manifest_source`` lists resources so
        ``pam_configuration_uid_ref`` can resolve for TunnelDAG.
        """
        try:
            from keepercommander.commands.tunnel.port_forward.tunnel_helpers import (
                get_keeper_tokens,
            )
            from keepercommander.commands.tunnel.port_forward.TunnelGraph import (
                TunnelDAG,
            )
        except ImportError:
            return
        if self._keeper_params is None:
            return
        params = self._keeper_params
        encrypted_session_token, encrypted_transmission_key, transmission_key = get_keeper_tokens(
            params
        )
        tdag_cache: dict[str, Any] = {}
        for live in records:
            if live.resource_type != "pamRemoteBrowser":
                continue
            cfg_uid = self._resolve_pam_configuration_keeper_uid(live, records)
            if not cfg_uid:
                continue
            if cfg_uid not in tdag_cache:
                tdag_cache[cfg_uid] = TunnelDAG(
                    params,
                    encrypted_session_token,
                    encrypted_transmission_key,
                    cfg_uid,
                    transmission_key=transmission_key,
                )
            tdag = tdag_cache[cfg_uid]
            if tdag is None or not getattr(tdag.linking_dag, "has_graph", False):
                continue
            rid = str(live.keeper_uid)
            connections = tdag.get_resource_setting(rid, "allowedSettings", "connections")
            session_rec = tdag.get_resource_setting(rid, "allowedSettings", "sessionRecording")
            ps = live.payload.setdefault("pam_settings", {})
            _merge_rbi_dag_options_into_pam_settings(
                ps, connections=connections, session_recording=session_rec
            )

    def _enrich_pam_user_rotation_settings(self, records: list[LiveRecord]) -> None:
        """Attach Commander rotation readback to discovered nested ``pamUser`` rows."""
        source = _manifest_source_dict(self._manifest_source)
        targets = _nested_rotation_user_targets(source)
        if not targets.refs and not targets.titles:
            return

        for live in records:
            if live.resource_type != "pamUser":
                continue
            marker_ref = None
            if isinstance(live.marker, dict):
                marker_ref = live.marker.get("uid_ref")
            if marker_ref not in targets.refs and live.title not in targets.titles:
                continue
            rotation_settings = self._get_pam_rotation_state(str(live.keeper_uid))
            if rotation_settings:
                live.payload["rotation_settings"] = rotation_settings

    def _get_pam_rotation_state(self, uid: str) -> dict[str, Any]:
        if not _supports_rotation_info_json():
            return {}
        raw = self._run_cmd(["pam", "rotation", "info", "--record-uid", uid, "--format", "json"])
        data = _load_json(raw, command="pam rotation info --record-uid <uid> --format json")
        return _rotation_settings_from_readback(data, uid=uid)

    def unsupported_capabilities(self, manifest: Any = None) -> list[str]:
        """Enumerate manifest-declared capabilities this provider cannot drive.

        Called by the CLI at plan / dry-run / apply time. Each item becomes a
        CONFLICT row in the plan so ``plan == apply --dry-run == apply``
        (DELIVERY_PLAN.md L94). Previously this ran only inside ``apply_plan``
        as a late-apply guard, producing green plans followed by red applies
        for the same input — see REVIEW.md "Update — second pass / D-4".

        ``manifest`` argument is accepted for protocol parity; the provider
        introspects its own ``self._manifest_source`` in practice.
        """
        source = manifest if manifest is not None else self._manifest_source
        return _detect_unsupported_capabilities(
            source,
            allow_nested_rotation=_rotation_apply_is_enabled(),
        )

    def check_tenant_bindings(self, manifest: Any = None) -> list[str]:
        """Stage-5 online checks: verify every declared binding resolves.

        For each ``reference_existing`` gateway, confirm a live gateway with
        that name exists. For each PAM configuration declared in the manifest,
        confirm a live PAM configuration with the same title resolves and
        carries a valid ``shared_folder_uid`` + ``gateway_uid`` pairing.
        When a ``gateway_uid_ref`` is declared on a PAM configuration, verify
        the live config is actually paired with that gateway. When a gateway
        declares ``ksm_application_name``, verify the tenant's bound KSM app
        matches it or report that the CLI output cannot prove the binding.

        Each returned string is a human-readable binding failure ready for
        ``click.echo(..., err=True)`` and maps 1:1 to a stage-5 violation
        documented in ``docs/VALIDATION_STAGES.md``. Returning ``[]`` means
        stage-5 passed.

        Accepts either the typed :class:`Manifest` (preferred; used by the
        CLI) or the raw manifest dict (for SDK callers bypassing typed
        loading). One round-trip to ``pam gateway list`` + ``pam config list``
        per call; no caching — validate is short-lived.
        """

        def _as_list(value: Any, attr: str) -> list[Any]:
            if value is None:
                return []
            if hasattr(value, attr):
                return list(getattr(value, attr))
            if isinstance(value, dict):
                return list(value.get(attr) or [])
            return []

        source: Any = manifest if manifest is not None else self._manifest_source
        gateways = _as_list(source, "gateways")
        pam_configs = _as_list(source, "pam_configurations")

        def _get(item: Any, key: str) -> Any:
            if hasattr(item, key):
                return getattr(item, key)
            if isinstance(item, dict):
                return item.get(key)
            return None

        if not gateways and not pam_configs:
            return []

        try:
            gateway_rows = self._pam_gateway_rows()
        except (CapabilityError, OSError) as exc:
            return [f"could not list tenant gateways: {exc}"]
        try:
            config_rows = self._pam_config_rows()
        except (CapabilityError, OSError) as exc:
            return [f"could not list tenant PAM configurations: {exc}"]

        live_gateways_by_name: dict[str, dict[str, str]] = {
            row["gateway_name"]: row for row in gateway_rows if row.get("gateway_name")
        }
        live_configs_by_title: dict[str, dict[str, str]] = {
            row["config_name"]: row for row in config_rows if row.get("config_name")
        }

        gateway_uid_by_ref: dict[str, str] = {}
        issues: list[str] = []

        for gateway in gateways:
            mode = _get(gateway, "mode") or "reference_existing"
            name = _get(gateway, "name") or ""
            uid_ref = _get(gateway, "uid_ref") or ""
            if mode != "reference_existing":
                continue
            row = live_gateways_by_name.get(name)
            if row is None:
                issues.append(
                    f"gateway '{name}' (uid_ref={uid_ref}) not found on tenant; "
                    "check the enterprise's `pam gateway list --format json` output"
                )
                continue
            gateway_uid_by_ref[uid_ref] = row["gateway_uid"]
            declared_app = _get(gateway, "ksm_application_name")
            if declared_app:
                actual_app, binding_issue = self._gateway_bound_app_name(row)
                if actual_app and declared_app != actual_app:
                    issues.append(
                        f"gateway '{name}' declares ksm_application_name='{declared_app}' "
                        f"but tenant has it bound to '{actual_app}'"
                    )
                elif binding_issue:
                    issues.append(
                        f"gateway '{name}' declares ksm_application_name='{declared_app}' "
                        f"but the tenant binding could not be verified: {binding_issue}"
                    )

        for config in pam_configs:
            title = _get(config, "title")
            uid_ref = _get(config, "uid_ref") or ""
            if not title:
                continue
            row = live_configs_by_title.get(title)
            if row is None:
                issues.append(
                    f"pam_configuration '{title}' (uid_ref={uid_ref}) not found on tenant; "
                    "declare a matching title or create the configuration in Keeper first"
                )
                continue
            if not row.get("shared_folder_uid"):
                issues.append(
                    f"pam_configuration '{title}' has no shared_folder on tenant — "
                    "apply cannot write resources without a bound shared folder"
                )
            gateway_ref = _get(config, "gateway_uid_ref")
            if gateway_ref:
                expected_gateway_uid = gateway_uid_by_ref.get(gateway_ref)
                actual_gateway_uid = row.get("gateway_uid") or ""
                if (
                    expected_gateway_uid
                    and actual_gateway_uid
                    and expected_gateway_uid != actual_gateway_uid
                ):
                    issues.append(
                        f"pam_configuration '{title}' declares gateway_uid_ref='{gateway_ref}' "
                        f"(uid={expected_gateway_uid}) but tenant pairs it with gateway uid "
                        f"'{actual_gateway_uid}'"
                    )

        return issues

    def _apply_gateway_lifecycle_changes(
        self,
        plan: Plan,
        changes: list[Change],
        *,
        dry_run: bool,
        checkpoint: ApplyCheckpoint | None = None,
    ) -> list[ApplyOutcome]:
        outcomes: list[ApplyOutcome] = []
        for change in changes:
            payload = change.after if change.kind is not ChangeKind.DELETE else change.before
            name = str(payload.get("name") or change.title or change.uid_ref or "")
            ck_uid = str(change.uid_ref or name)
            if checkpoint and not dry_run and ck_uid and checkpoint.is_applied(ck_uid):
                LOGGER.info("apply checkpoint: skipping gateway uid_ref=%s", ck_uid)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=ck_uid,
                        keeper_uid=change.keeper_uid or "",
                        action=change.kind.value,
                        details={"checkpoint_skipped": True},
                    )
                )
                continue
            if change.kind is ChangeKind.CREATE:
                ksm_app_name = str(payload.get("ksm_application_name") or "")
                if not ksm_app_name:
                    raise CapabilityError(
                        reason="gateway mode:create requires ksm_application_name",
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action="set gateways[].ksm_application_name before apply",
                    )
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid="",
                            action="create",
                            details={
                                "dry_run": True,
                                "commander_argv": [
                                    "pam",
                                    "gateway",
                                    "new",
                                    "--name",
                                    name,
                                    "--application",
                                    ksm_app_name,
                                    "--return_value",
                                ],
                                "marker_written": False,
                            },
                        )
                    )
                    continue
                self._pam_gateway_new(
                    name,
                    ksm_app_name,
                    node_id=payload.get("node_id"),
                )
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="create",
                        details={
                            "dry_run": False,
                            "manager_marker": "not-applicable",
                            "one_time_token_returned": True,
                            "manifest": plan.manifest_name,
                        },
                    )
                )
                if checkpoint and ck_uid:
                    checkpoint.mark_applied(ck_uid, "create")
                continue

            if change.kind is ChangeKind.UPDATE:
                gateway = change.keeper_uid or name
                new_name = change.after.get("name")
                node_id = change.after.get("node_id")
                if dry_run:
                    details: dict[str, Any] = {"dry_run": True}
                    argv = ["pam", "gateway", "edit", "--gateway", gateway]
                    if new_name:
                        argv += ["--name", str(new_name)]
                    if node_id:
                        argv += ["--node-id", str(node_id)]
                    details["commander_argv"] = argv
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or "",
                            action="update",
                            details=details,
                        )
                    )
                    continue
                if not new_name and not node_id:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or "",
                            action="noop",
                            details={"reason": "no gateway edit fields changed"},
                        )
                    )
                    continue
                self._pam_gateway_edit(
                    gateway=gateway,
                    name=str(new_name) if new_name else None,
                    node_id=str(node_id) if node_id else None,
                )
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="update",
                        details={"dry_run": False},
                    )
                )
                if checkpoint and ck_uid:
                    checkpoint.mark_applied(ck_uid, "update")
                continue

            if change.kind is ChangeKind.DELETE:
                gateway = change.keeper_uid or name
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or "",
                            action="delete",
                            details={
                                "dry_run": True,
                                "commander_argv": [
                                    "pam",
                                    "gateway",
                                    "remove",
                                    "--gateway",
                                    gateway,
                                ],
                            },
                        )
                    )
                    continue
                self._pam_gateway_remove(gateway)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="delete",
                        details={"dry_run": False, "removed": True},
                    )
                )
                if checkpoint and ck_uid:
                    checkpoint.mark_applied(ck_uid, "delete")
                continue

            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or name,
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                    details={"reason": change.reason or "non-actionable gateway row"},
                )
            )
        return outcomes

    def apply_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        checkpoint: ApplyCheckpoint | None = None
        manifest_apply_path = getattr(self, "_apply_manifest_path", None)
        if not dry_run and manifest_apply_path:
            checkpoint = ApplyCheckpoint.load_or_create(
                manifest_apply_path, _checkpoint_manifest_hash(manifest_apply_path)
            )

        if _manifest_source_is_vault(self._manifest_source):
            applied = self._apply_vault_plan(plan, dry_run=dry_run, checkpoint=checkpoint)
            if checkpoint:
                checkpoint.clear()
            return applied
        if _manifest_source_is_sharing(self._manifest_source):
            applied = self._apply_sharing_plan(plan, dry_run=dry_run, checkpoint=checkpoint)
            if checkpoint:
                checkpoint.clear()
            return applied
        if _manifest_source_is_privileged_access(self._manifest_source):
            applied = self.apply_privileged_access_plan(plan, dry_run=dry_run)
            if checkpoint:
                checkpoint.clear()
            return applied
        if _manifest_source_is_workflow(self._manifest_source):
            applied = self.apply_workflow_plan(plan, dry_run=dry_run)
            if checkpoint:
                checkpoint.clear()
            return applied
        if _manifest_source_is_saas_rotation(self._manifest_source):
            applied = self.apply_saas_rotation_plan(plan, dry_run=dry_run)
            if checkpoint:
                checkpoint.clear()
            return applied
        if _manifest_source_is_pam_extended(self._manifest_source):
            applied = self.apply_pam_extended_plan(plan, dry_run=dry_run)
            if checkpoint:
                checkpoint.clear()
            return applied
        if _manifest_source_is_epm(self._manifest_source) or _manifest_source_is_epm_policy(
            self._manifest_source
        ):
            applied = self.apply_epm_policy_plan(plan, dry_run=dry_run)
            if checkpoint:
                checkpoint.clear()
            return applied
        if self._manifest_source_is_ai_agent(plan):
            applied = self.apply_ai_agent_plan(plan, dry_run=dry_run)
            if checkpoint:
                checkpoint.clear()
            return applied
        if self._manifest_source_is_nhi(plan):
            applied = self.apply_nhi_plan(plan, dry_run=dry_run)
            if checkpoint:
                checkpoint.clear()
            return applied
        # Last-line defence — CLI should have surfaced these as conflicts
        # already (see unsupported_capabilities above). If an SDK caller
        # bypasses the CLI and hands us a plan directly, we still refuse.
        hits = _detect_unsupported_capabilities(
            self._manifest_source,
            allow_nested_rotation=_rotation_apply_is_enabled(),
        )
        if hits:
            raise CapabilityError(
                reason="manifest declares capabilities the CommanderCliProvider does not implement yet: "
                + "; ".join(hits),
                next_action=(
                    "remove the declarations, or drive the Commander hook manually before "
                    "re-running apply. See REVIEW.md D-4."
                ),
            )

        _ensure_keepercommander_version_for_apply()

        outcomes: list[ApplyOutcome] = []
        creates_updates = [
            c for c in plan.ordered() if c.kind in (ChangeKind.CREATE, ChangeKind.UPDATE)
        ]
        gateway_creates_updates = [
            change for change in creates_updates if change.resource_type == "gateway"
        ]
        pam_creates_updates = [
            change for change in creates_updates if change.resource_type != "gateway"
        ]
        gateway_deletes = [change for change in plan.deletes if change.resource_type == "gateway"]
        deletes = [change for change in plan.deletes if change.resource_type != "gateway"]

        if gateway_creates_updates:
            outcomes.extend(
                self._apply_gateway_lifecycle_changes(
                    plan,
                    gateway_creates_updates,
                    dry_run=dry_run,
                    checkpoint=checkpoint,
                )
            )

        if pam_creates_updates:
            _pam_database_db_proxy_apply_gate(
                self._manifest_source,
                pam_creates_updates,
                dry_run=dry_run,
            )
            rotation_preview_argvs = (
                _preview_rotation_argvs_by_ref(self._manifest_source)
                if dry_run and _rotation_apply_is_enabled()
                else {}
            )
            payload = to_pam_import_json(self._manifest_source)
            with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as handle:
                cmd = [
                    "pam",
                    "project",
                    "extend" if _has_existing(pam_creates_updates) else "import",
                ]
                synthetic_config = None
                if _uses_reference_existing(self._manifest_source):
                    synthetic_config = self._resolve_reference_configuration(payload)
                    if not dry_run:
                        scaffold = self._ensure_reference_project_scaffold(
                            project_name=plan.manifest_name,
                            gateway_app_uid=synthetic_config["app_uid"],
                        )
                        # Scaffold uses subprocess `keeper` while earlier stage-5
                        # work may have warmed in-process KeeperParams. Idle or
                        # alternate sessions can leave cached params stale for the
                        # graph-heavy `pam project extend` call (session_token_expired).
                        self._invalidate_keeper_params()
                        self._folder_uid = scaffold["resources_uid"]
                        self.last_resolved_folder_uid = scaffold["resources_uid"]
                        self.last_resolved_users_folder_uid = scaffold["users_uid"]
                        payload = _payload_for_extend(
                            payload,
                            resources_folder_name=scaffold["resources_name"],
                            users_folder_name=scaffold["users_name"],
                        )
                    else:
                        payload = _payload_for_extend(
                            payload,
                            resources_folder_name=f"{plan.manifest_name} - Resources",
                            users_folder_name=f"{plan.manifest_name} - Users",
                        )
                    cmd = [
                        "pam",
                        "project",
                        "extend",
                        "--config",
                        synthetic_config["config_name"],
                        "--file",
                    ]
                json.dump(payload, handle, indent=2)
                temp_path = Path(handle.name)
            try:
                if cmd[:3] == ["pam", "project", "import"]:
                    cmd += ["--file", str(temp_path)]
                    cmd += ["--name", plan.manifest_name]
                else:
                    cmd.append(str(temp_path))
                if dry_run:
                    cmd.append("--dry-run")
                self._run_cmd(cmd)
                if not dry_run:
                    for _tunnel_argv in _db_proxy_post_import_argvs(
                        self._manifest_source, pam_creates_updates, dry_run=False
                    ):
                        self._run_cmd(_tunnel_argv)
                if not dry_run and not synthetic_config:
                    self._resolve_project_resources_folder(plan.manifest_name)
                for change in pam_creates_updates:
                    keeper_uid = ""
                    if synthetic_config and change.resource_type == "pam_configuration":
                        keeper_uid = synthetic_config["config_uid"]
                    details: dict[str, Any] = {"dry_run": dry_run}
                    if dry_run:
                        preview_argvs = _preview_post_import_tuning_argvs(
                            change, self._manifest_source
                        )
                        if preview_argvs:
                            details["post_import_tuning_argvs"] = preview_argvs
                            details["post_import_tuning_dry_run"] = True
                        rotation_argvs = rotation_preview_argvs.get(change.uid_ref or change.title)
                        if rotation_argvs:
                            details["rotation_argvs"] = rotation_argvs
                            details["rotation_dry_run"] = True
                        if change.resource_type == "pamDatabase":
                            _ts = _db_proxy_tunnel_settings_for_uid_ref(
                                self._manifest_source, change.uid_ref or ""
                            )
                            if _ts and _ts.get("db_proxy_enabled"):
                                details["db_proxy_note"] = (
                                    "tunnel_settings.db_proxy_enabled=True; "
                                    "after apply run: pam tunnel edit "
                                    "<tunnel-record-uid> --keeper-db-proxy on"
                                )
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=keeper_uid or change.keeper_uid or "",
                            action=change.kind.value,
                            details=details,
                        )
                    )
            finally:
                temp_path.unlink(missing_ok=True)

            if not dry_run:
                try:
                    live_records = self.discover()
                except CapabilityError as exc:
                    raise CapabilityError(
                        reason=f"discover() after pam import/extend failed: {exc.reason}",
                        next_action=exc.next_action,
                        context={**exc.context, "partial_outcomes": list(outcomes)},
                    ) from exc
                live_by_key, live_by_title = _index_live_records_for_title_matching(live_records)

                now = utc_timestamp()
                # outcomes is built by iterating creates_updates in the same
                # order above, so lengths must match — strict=True turns any
                # future drift into a loud failure rather than a silent
                # mis-association of markers to changes.
                pam_outcomes = outcomes[-len(pam_creates_updates) :]
                for change, outcome in zip(pam_creates_updates, pam_outcomes, strict=True):
                    try:
                        if synthetic_config and change.resource_type == "pam_configuration":
                            outcome.details.update(
                                {
                                    "marker_written": True,
                                    "keeper_uid": synthetic_config["config_uid"],
                                    "verified": True,
                                    "reused_existing": True,
                                }
                            )
                            continue
                        exact_matches = live_by_key.get((change.resource_type, change.title), [])
                        matches = exact_matches or _live_matches_by_identity(
                            live_by_key=live_by_key,
                            live_by_title=live_by_title,
                            resource_type=change.resource_type,
                            title=change.title,
                        )
                        if len(matches) > 1:
                            match_label = (
                                f"{change.resource_type} records" if exact_matches else "records"
                            )
                            raise CollisionError(
                                reason=(
                                    f"live tenant has {len(matches)} {match_label} titled "
                                    f"'{change.title}' after apply"
                                ),
                                uid_ref=change.uid_ref,
                                resource_type=change.resource_type,
                                next_action=(
                                    "rename duplicates or add ownership markers so matching "
                                    "is unambiguous"
                                ),
                                context={"live_identifiers": [live.keeper_uid for live in matches]},
                            )
                        if not matches:
                            outcome.details.update(
                                {
                                    "marker_written": False,
                                    "reason": "record not found after apply",
                                }
                            )
                            continue

                        live = matches[0]
                        post_import_argvs = _resolve_post_import_tuning_argvs(
                            self._manifest_source,
                            plan=plan,
                            live_records=live_records,
                            changes=[change],
                        ).get(change.uid_ref or "", [])
                        for argv in post_import_argvs:
                            if len(argv) >= 2 and argv[0] == "pam" and argv[1] == "workflow":
                                _ensure_pam_workflow_config_commands_available()
                            self._run_cmd(argv)
                        marker = encode_marker(
                            uid_ref=change.uid_ref or change.title,
                            manifest=plan.manifest_name,
                            resource_type=change.resource_type,
                            last_applied_at=now,
                        )
                        self._write_marker(live.keeper_uid, marker)
                        outcome.details.update(
                            {
                                "marker_written": True,
                                "keeper_uid": live.keeper_uid,
                            }
                        )
                        if post_import_argvs:
                            outcome.details["post_import_tuning_argvs"] = post_import_argvs
                            outcome.details["post_import_tuning_executed"] = True
                        drift = _field_drift(change.after or {}, live.payload)
                        if drift:
                            outcome.details["field_drift"] = drift
                        else:
                            outcome.details["verified"] = True
                    except CapabilityError as exc:
                        outcome.details["apply_failed"] = True
                        outcome.details["apply_failure_reason"] = exc.reason
                        if exc.next_action:
                            outcome.details["apply_failure_next_action"] = exc.next_action
                        raise CapabilityError(
                            reason=(
                                f"apply stopped mid-batch while processing "
                                f"{change.resource_type} uid_ref={change.uid_ref!r}: {exc.reason}"
                            ),
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=exc.next_action,
                            context={**exc.context, "partial_outcomes": list(outcomes)},
                        ) from exc

                try:
                    outcomes.extend(self._apply_rotation_settings(plan, live_records))
                except CapabilityError as exc:
                    raise CapabilityError(
                        reason=f"rotation apply failed after resource writes: {exc.reason}",
                        next_action=exc.next_action,
                        context={**exc.context, "partial_outcomes": list(outcomes)},
                    ) from exc

                try:
                    outcomes.extend(self._apply_rotation_scripts(live_records))
                except CapabilityError as exc:
                    raise CapabilityError(
                        reason=f"rotation script attach failed: {exc.reason}",
                        next_action=exc.next_action,
                        context={**exc.context, "partial_outcomes": list(outcomes)},
                    ) from exc

                try:
                    outcomes.extend(self._apply_resource_attachments(live_records))
                except CapabilityError as exc:
                    raise CapabilityError(
                        reason=f"resource attachment upload failed: {exc.reason}",
                        next_action=exc.next_action,
                        context={**exc.context, "partial_outcomes": list(outcomes)},
                    ) from exc

                try:
                    outcomes.extend(self._apply_pam_user_saas_plugins(plan, live_records))
                except CapabilityError as exc:
                    raise CapabilityError(
                        reason=f"pamUser saas_plugins apply failed: {exc.reason}",
                        next_action=exc.next_action,
                        context={**exc.context, "partial_outcomes": list(outcomes)},
                    ) from exc

        if gateway_deletes:
            outcomes.extend(
                self._apply_gateway_lifecycle_changes(
                    plan,
                    gateway_deletes,
                    dry_run=dry_run,
                    checkpoint=checkpoint,
                )
            )

        for change in deletes:
            ck_uid = _checkpoint_uid(change)
            if checkpoint and not dry_run and ck_uid and checkpoint.is_applied(ck_uid):
                LOGGER.info("apply checkpoint: skipping delete uid_ref=%s", ck_uid)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=ck_uid,
                        keeper_uid=change.keeper_uid or "",
                        action="delete",
                        details={"checkpoint_skipped": True},
                    )
                )
                continue
            if not change.keeper_uid:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="delete",
                        details={
                            "skipped": True,
                            "reason": "no keeper_uid on delete change",
                            "warning": "dependency checks are enforced by Keeper CLI/server, not client-side",
                        },
                    )
                )
                continue

            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid,
                        action="delete",
                        details={
                            "dry_run": True,
                            "keeper_uid": change.keeper_uid,
                            "warning": "dependency checks are enforced by Keeper CLI/server, not client-side",
                        },
                    )
                )
                continue

            outcome = ApplyOutcome(
                uid_ref=change.uid_ref or "",
                keeper_uid=change.keeper_uid,
                action="delete",
                details={
                    "keeper_uid": change.keeper_uid,
                    "removed": False,
                    "warning": "dependency checks are enforced by Keeper CLI/server, not client-side",
                },
            )
            outcomes.append(outcome)
            try:
                self._run_cmd(["rm", "--force", change.keeper_uid])
            except CapabilityError:
                raise
            outcome.details["removed"] = True
            if checkpoint and ck_uid:
                checkpoint.mark_applied(ck_uid, "delete")

        for change in plan.conflicts:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="conflict",
                    details={"reason": change.reason or ""},
                )
            )
        for change in plan.noops:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                )
            )
        if checkpoint:
            checkpoint.clear()
        return outcomes

    def _manifest_name_from_source(self) -> str | None:
        name = self._manifest_source.get("name") or self._manifest_source.get("project")
        return str(name) if isinstance(name, str) and name.strip() else None

    def _maybe_resolve_project_resources_folder(self, project_name: str) -> str | None:
        try:
            return self._resolve_project_resources_folder(project_name)
        except CapabilityError:
            return None

    def _synthetic_reference_configuration_record(self) -> LiveRecord | None:
        if not _uses_reference_existing(self._manifest_source):
            return None
        project_name = self._manifest_name
        if not project_name:
            return None
        if not self.last_resolved_folder_uid and not self._maybe_resolve_project_resources_folder(
            project_name
        ):
            return None

        payload = to_pam_import_json(self._manifest_source)
        config = self._resolve_reference_configuration(payload)
        uid_ref = _pam_configuration_uid_ref(self._manifest_source)
        marker = encode_marker(
            uid_ref=uid_ref or config["config_name"],
            manifest=project_name,
            resource_type="pam_configuration",
        )
        # Reflect the manifest's declared fields onto the synthetic payload so
        # the planner's field diff treats a reused reference config as noop.
        # We don't actually own the record — we're just asserting the caller
        # declared it identically to what's already in the vault.
        declared: dict[str, Any] = {}
        configs = self._manifest_source.get("pam_configurations") or []
        if isinstance(configs, list) and configs and isinstance(configs[0], dict):
            for key, value in configs[0].items():
                if key in {"uid_ref", "mode"}:
                    continue
                declared[key] = value
        declared.setdefault("title", config["config_name"])
        return LiveRecord(
            keeper_uid=config["config_uid"],
            title=config["config_name"],
            resource_type="pam_configuration",
            folder_uid=None,
            payload=declared,
            marker=marker,
        )

    def _ensure_reference_project_scaffold(
        self, *, project_name: str, gateway_app_uid: str
    ) -> dict[str, str]:
        root_name = "PAM Environments"
        project_path = f"{root_name}/{project_name}"
        resources_name = f"{project_name} - Resources"
        users_name = f"{project_name} - Users"
        resources_path = f"{project_path}/{resources_name}"
        users_path = f"{project_path}/{users_name}"

        self._ensure_folder_exists(root_name)
        self._ensure_folder_exists(project_path)
        self._ensure_shared_folder_exists(resources_path)
        self._ensure_shared_folder_exists(users_path)

        project_entries = _load_json(
            self._run_cmd(["ls", "--format", "json", project_path]),
            command=f"ls --format json {project_path}",
        )
        resources_uid = _entry_uid_by_name(project_entries, resources_name)
        users_uid = _entry_uid_by_name(project_entries, users_name)
        if not resources_uid or not users_uid:
            raise CapabilityError(
                reason=f"Commander did not return the shared folders for {project_path}",
                next_action=f'inspect `keeper ls --format json "{project_path}"` and confirm scaffold creation succeeded',
            )

        self._share_folder_to_ksm_app(folder_uid=resources_uid, app_uid=gateway_app_uid)
        self._share_folder_to_ksm_app(folder_uid=users_uid, app_uid=gateway_app_uid)
        return {
            "resources_uid": resources_uid,
            "users_uid": users_uid,
            "resources_name": resources_name,
            "users_name": users_name,
        }

    def _resolve_reference_configuration(self, payload: dict[str, Any]) -> dict[str, str]:
        config_name = str((payload.get("pam_configuration") or {}).get("title", "")).strip()
        gateway_name = str((payload.get("pam_configuration") or {}).get("gateway_name", "")).strip()

        gateway_rows = self._pam_gateway_rows()
        config_rows = self._pam_config_rows()

        gateway_row = next(
            (row for row in gateway_rows if row["gateway_name"] == gateway_name), None
        )
        config_row = next((row for row in config_rows if row["config_name"] == config_name), None)
        if config_row is None and gateway_row is not None:
            matches = [
                row for row in config_rows if row["gateway_uid"] == gateway_row["gateway_uid"]
            ]
            if len(matches) == 1:
                config_row = matches[0]

        if gateway_row is None:
            raise CapabilityError(
                reason=f"reference-existing gateway '{gateway_name}' not found in `keeper pam gateway list`",
                next_action="update the manifest to a real gateway name or create the gateway first",
            )
        if config_row is None:
            raise CapabilityError(
                reason=(
                    f"reference-existing PAM configuration '{config_name}' not found and no unique configuration "
                    f"was attached to gateway '{gateway_name}'"
                ),
                next_action="update the manifest title or bind the gateway to exactly one PAM configuration",
            )
        return {
            "gateway_name": gateway_row["gateway_name"],
            "gateway_uid": gateway_row["gateway_uid"],
            "app_uid": gateway_row["app_uid"],
            "config_uid": config_row["config_uid"],
            "config_name": config_row["config_name"],
        }

    def _pam_gateway_rows(self) -> list[dict[str, str]]:
        """Return gateway rows using Commander's JSON output.

        Commander release `18.0.0+` exposes ``pam gateway list --format json``
        (``keepercommander/commands/discoveryrotation.py`` L1373-1606). The
        response is ``{"gateways": [{gateway_name, gateway_uid, ksm_app_name,
        ksm_app_uid, ksm_app_accessible, status, gateway_version, ...}, ...]}``.
        Empty enterprises return ``{"gateways": [], "message": ...}``.
        """
        raw = self._run_cmd(["pam", "gateway", "list", "--format", "json"])
        data = _load_json(raw, command="pam gateway list --format json")
        if isinstance(data, dict):
            items = data.get("gateways") or []
        else:
            items = []
        rows: list[dict[str, str]] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            rows.append(
                {
                    "app_title": str(item.get("ksm_app_name") or ""),
                    "app_uid": str(item.get("ksm_app_uid") or ""),
                    "gateway_name": str(item.get("gateway_name") or ""),
                    "gateway_uid": str(item.get("gateway_uid") or ""),
                }
            )
        return rows

    def _pam_config_rows(self) -> list[dict[str, str]]:
        """Return PAM configuration rows using Commander's JSON output.

        Commander release `18.0.0+` exposes ``pam config list --format json``
        (``keepercommander/commands/discoveryrotation.py`` L1729-1967).
        Response: ``{"configurations": [{uid, config_name, config_type,
        shared_folder: {name, uid}, gateway_uid, resource_record_uids,
        ...}, ...]}``.
        """
        raw = self._run_cmd(["pam", "config", "list", "--format", "json"])
        data = _load_json(raw, command="pam config list --format json")
        if isinstance(data, dict):
            items = data.get("configurations") or []
        else:
            items = []
        rows: list[dict[str, str]] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            sf = item.get("shared_folder") or {}
            rows.append(
                {
                    "config_uid": str(item.get("uid") or ""),
                    "config_name": str(item.get("config_name") or ""),
                    "gateway_uid": str(item.get("gateway_uid") or ""),
                    "shared_folder_title": str(sf.get("name") or "")
                    if isinstance(sf, dict)
                    else "",
                    "shared_folder_uid": str(sf.get("uid") or "") if isinstance(sf, dict) else "",
                }
            )
        return rows

    def _resolve_project_resources_folder(self, project_name: str) -> str:
        return self._resolve_project_scaffold_folders(project_name)["resources_uid"]

    def export_pam_project_json(self, project_uid: str) -> dict[str, Any]:
        """Return Commander-shaped PAM project JSON, preferring probed native export."""
        native = self._try_native_pam_project_export(project_uid)
        if native is not None:
            return native
        LOGGER.debug("using synthesized PAM project export path for project %s", project_uid)
        return self._synthesise_pam_project_export(project_uid)

    def _try_native_pam_project_export(self, project_uid: str) -> dict[str, Any] | None:
        if not _supports_pam_project_export():
            return None
        try:
            raw = self._run_cmd(["pam", "project", "export", "--project-uid", project_uid])
            data = _load_json(
                raw,
                command="pam project export --project-uid <uid>",
            )
            if not isinstance(data, dict):
                raise CapabilityError(
                    reason="Commander returned non-object JSON from `pam project export`"
                )
            LOGGER.debug("using native PAM project export path for project %s", project_uid)
            return data
        except (CapabilityError, OSError, ValueError):
            LOGGER.debug(
                "native PAM project export failed; falling back to synthesized path",
                exc_info=True,
            )
            return None

    def _synthesise_pam_project_export(self, project_uid: str) -> dict[str, Any]:
        entries = _load_json(
            self._run_cmd(["ls", "--format", "json", project_uid]),
            command=f"ls --format json {project_uid}",
        )
        if not isinstance(entries, list):
            raise CapabilityError(
                reason="Commander returned non-array JSON from project folder `ls`",
                next_action="inspect `keeper ls --format json <project_uid>` and retry",
            )
        records: list[dict[str, Any]] = []
        for entry in entries:
            if not isinstance(entry, Mapping) or entry.get("type") != "record":
                continue
            uid = str(entry.get("uid") or "")
            if not uid:
                continue
            payload = _load_json(
                self._run_cmd(["get", uid, "--format", "json"]),
                command=f"get {uid} --format json",
            )
            if isinstance(payload, dict):
                records.append(payload)
        return {"records": records}

    def _resolve_project_scaffold_folders(self, project_name: str) -> dict[str, str]:
        # Commander's `ls <path>` returns the CHILDREN of that path, not the
        # path entry itself. So `ls "PAM Environments"` already gives us the
        # project folders directly — no extra layer to strip.
        project_entries = _load_json(
            self._run_cmd(["ls", "--format", "json", "PAM Environments"]),
            command="ls --format json PAM Environments",
        )
        project_uid = _entry_uid_by_name(project_entries, project_name)
        if not project_uid:
            raise CapabilityError(
                reason=f"Commander did not return project folder '{project_name}' under PAM Environments",
                next_action='inspect `keeper ls --format json "PAM Environments"` and confirm import created the project folder',
            )

        resources_entries = _load_json(
            self._run_cmd(["ls", "--format", "json", project_uid]),
            command=f"ls --format json {project_uid}",
        )
        resources_name = f"{project_name} - Resources"
        resources_uid = _entry_uid_by_name(resources_entries, resources_name)
        if not resources_uid:
            raise CapabilityError(
                reason=f"Commander did not return resources folder '{resources_name}' under project '{project_name}'",
                next_action=f"inspect `keeper ls --format json {project_uid}` and confirm import created the Resources folder",
            )
        self._folder_uid = resources_uid
        self.last_resolved_folder_uid = resources_uid
        users_name = f"{project_name} - Users"
        users_uid = _entry_uid_by_name(resources_entries, users_name)
        self.last_resolved_users_folder_uid = users_uid
        return {
            "resources_uid": resources_uid,
            "users_uid": users_uid or "",
        }

    def _pam_gateway_new(
        self,
        name: str,
        ksm_app_name: str,
        node_id: str | None = None,
    ) -> str:
        args = [
            "pam",
            "gateway",
            "new",
            "--name",
            name,
            "--application",
            ksm_app_name,
            "--return_value",
        ]
        result = self._run_pam_gateway_in_process(args)
        if node_id:
            self._pam_gateway_edit(gateway=name, node_id=node_id)
        return result

    def _pam_gateway_edit(
        self,
        *,
        gateway: str,
        name: str | None = None,
        node_id: str | None = None,
    ) -> str:
        args = ["pam", "gateway", "edit", "--gateway", gateway]
        if name:
            args += ["--name", name]
        if node_id:
            args += ["--node-id", node_id]
        return self._run_pam_gateway_in_process(args)

    def _pam_gateway_remove(self, gateway: str) -> str:
        return self._run_pam_gateway_in_process(["pam", "gateway", "remove", "--gateway", gateway])
