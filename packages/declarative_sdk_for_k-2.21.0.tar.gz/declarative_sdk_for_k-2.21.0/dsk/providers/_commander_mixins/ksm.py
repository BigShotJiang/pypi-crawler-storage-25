"""Mixin — ksm resource family of CommanderCliProvider.

Private implementation module. Not a public API.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome
from dsk.core.metadata import (
    decode_marker,
    encode_marker,
)
from dsk.core.planner import Plan
from dsk.providers._commander.ksm import (
    _ksm_app_record_uid,
    _ksm_change_bool,
    _ksm_change_name,
    _ksm_client_app_uid,
    _ksm_client_identifiers,
    _ksm_create_result_uid,
    _ksm_plan_changes,
    _ksm_share_keeper_uids,
    _ksm_upstream_gap_next_action,
)
from dsk.providers._commander.msp import (
    _msp_plan_changes,
)
from dsk.providers._commander_cli_helpers import (
    _extract_marker_field,
    _load_json,
)
from dsk.providers.commander_cli import (
    _KSM_APP_RESOURCE_TYPE,
    _KSM_CLIENT_RESOURCE_TYPE,
    _KSM_CREATE_ONLY_UNSUPPORTED_REASON,
    _KSM_RECORD_SHARE_RESOURCE_TYPE,
    _MSP_MARKER_UNSUPPORTED_REASON,
    ConflictError,
    _ref_leaf,
)
from dsk.secrets.ksm import ksm_client_add_kwargs, ksm_client_token_summary

if TYPE_CHECKING:
    pass


def _ensure_keepercommander_version_for_apply() -> None:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    _cli_m._ensure_keepercommander_version_for_apply()


def utc_timestamp() -> str:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m.utc_timestamp()  # type: ignore[no-any-return]


def _supports_secrets_manager_token_add() -> bool:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m._supports_secrets_manager_token_add()  # type: ignore[no-any-return]


class _KsmMixin:
    """Method carrier — ksm resource family."""

    if TYPE_CHECKING:
        # Instance attrs
        _ksm_app_rows_cache: list[dict[str, str]] | None

        # Cross-mixin methods (transport)
        def _get_keeper_params(self) -> Any: ...
        def _run_cmd(self, args: list[str]) -> str: ...
        def _with_keeper_session_refresh(self, fn: Any, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (vault)
        def _vault_record_ref_for_uid(self, uid: str) -> Any: ...
        def _write_marker(self, *a: Any, **kw: Any) -> Any: ...

    def apply_ksm_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply supported ``keeper-ksm.v1`` app-create rows via Commander."""
        changes = _ksm_plan_changes(plan)
        _ensure_keepercommander_version_for_apply()
        outcomes: list[ApplyOutcome] = []
        for change in changes:
            name = _ksm_change_name(change)

            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or ""},
                    )
                )
                continue

            upstream_gap_next_action = _ksm_upstream_gap_next_action(change.resource_type)
            if upstream_gap_next_action:
                raise CapabilityError(
                    reason=(
                        f"{change.resource_type} is an upstream-gap KSM operation on "
                        "Commander 18.0.0"
                    ),
                    uid_ref=change.uid_ref or name,
                    resource_type=change.resource_type,
                    next_action=upstream_gap_next_action,
                )

            if change.kind is not ChangeKind.CREATE:
                details: dict[str, Any] = {"dry_run": dry_run}
                if change.reason is not None:
                    details["reason"] = change.reason
                if (
                    change.kind is ChangeKind.UPDATE
                    and change.resource_type == _KSM_RECORD_SHARE_RESOURCE_TYPE
                ):
                    app_uid, secret_uid = _ksm_share_keeper_uids(change)
                    editable = _ksm_change_bool(change, "editable")
                    if dry_run:
                        outcomes.append(
                            ApplyOutcome(
                                uid_ref=change.uid_ref or name,
                                keeper_uid=change.keeper_uid or "",
                                action="update",
                                details={
                                    "dry_run": True,
                                    "app_uid": app_uid,
                                    "secret_uid": secret_uid,
                                    "editable": editable,
                                },
                            )
                        )
                        continue
                    if not app_uid or not secret_uid:
                        raise CapabilityError(
                            reason="KSM share update requires resolvable app and secret UIDs",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action=(
                                "refresh live KSM state so change.keeper_uid is "
                                "`<app_uid>|<secret_uid>` or use UID-shaped refs"
                            ),
                        )
                    self.ksm_app_share_update(app_uid, [secret_uid], editable)
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or f"{app_uid}|{secret_uid}",
                            action="update",
                            details={
                                "dry_run": False,
                                "app_uid": app_uid,
                                "secret_uid": secret_uid,
                                "editable": editable,
                            },
                        )
                    )
                    continue
                if (
                    change.kind is ChangeKind.DELETE
                    and change.resource_type == _KSM_RECORD_SHARE_RESOURCE_TYPE
                ):
                    app_uid, secret_uid = _ksm_share_keeper_uids(change)
                    if dry_run:
                        outcomes.append(
                            ApplyOutcome(
                                uid_ref=change.uid_ref or name,
                                keeper_uid=change.keeper_uid or "",
                                action="delete",
                                details={
                                    "dry_run": True,
                                    "app_uid": app_uid,
                                    "secret_uid": secret_uid,
                                },
                            )
                        )
                        continue
                    if not app_uid or not secret_uid:
                        raise CapabilityError(
                            reason="KSM share delete requires resolvable app and secret UIDs",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action=(
                                "refresh live KSM state so change.keeper_uid is "
                                "`<app_uid>|<secret_uid>` or use UID-shaped refs"
                            ),
                        )
                    self.ksm_app_share_remove(app_uid, [secret_uid])
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or f"{app_uid}|{secret_uid}",
                            action="delete",
                            details={
                                "dry_run": False,
                                "app_uid": app_uid,
                                "secret_uid": secret_uid,
                                "removed": True,
                            },
                        )
                    )
                    continue
                if (
                    change.kind is ChangeKind.DELETE
                    and change.resource_type == _KSM_CLIENT_RESOURCE_TYPE
                ):
                    app_uid = _ksm_client_app_uid(change)
                    client_ids = _ksm_client_identifiers(change)
                    if dry_run:
                        outcomes.append(
                            ApplyOutcome(
                                uid_ref=change.uid_ref or name,
                                keeper_uid=change.keeper_uid or "",
                                action="delete",
                                details={
                                    "dry_run": True,
                                    "app_uid": app_uid,
                                    "client_identifiers": client_ids,
                                },
                            )
                        )
                        continue
                    if not app_uid or not client_ids:
                        raise CapabilityError(
                            reason="KSM client delete requires app_uid_ref and client identifier",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action=(
                                "set app_uid_ref plus client_id/client_name, or set "
                                "change.keeper_uid as `<app_uid>|<client_id>`"
                            ),
                        )
                    self.ksm_client_remove(app_uid, client_ids, force=True)
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or f"{app_uid}|{client_ids[0]}",
                            action="delete",
                            details={
                                "dry_run": False,
                                "app_uid": app_uid,
                                "client_identifiers": client_ids,
                                "removed": True,
                            },
                        )
                    )
                    continue
                if (
                    change.kind is ChangeKind.DELETE
                    and change.resource_type == _KSM_APP_RESOURCE_TYPE
                ):
                    app_uid_or_name = change.keeper_uid or name
                    if dry_run:
                        outcomes.append(
                            ApplyOutcome(
                                uid_ref=change.uid_ref or name,
                                keeper_uid=change.keeper_uid or "",
                                action="delete",
                                details={
                                    "dry_run": True,
                                    "purge": False,
                                    "force": True,
                                },
                            )
                        )
                        continue
                    self.ksm_app_remove(app_uid_or_name, purge=False, force=True)
                    self._ksm_app_rows_cache = None
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or "",
                            action="delete",
                            details={
                                "dry_run": False,
                                "purge": False,
                                "force": True,
                                "removed": True,
                            },
                        )
                    )
                    continue
                if (
                    change.kind is ChangeKind.UPDATE
                    and change.resource_type == _KSM_APP_RESOURCE_TYPE
                ):
                    # Metadata update (name change) — delegate to KSMCommand.update_app.
                    new_name = str(change.after.get("name") or "").strip()
                    app_uid_or_name = change.keeper_uid or name
                    if not new_name:
                        raise CapabilityError(
                            reason="KSM app UPDATE change has no new 'name' in after-dict",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action="refresh plan from live KSM state",
                        )
                    try:
                        from keepercommander.commands.ksm import (
                            KSMCommand,  # noqa: PLC0415
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander KSMCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action="upgrade keepercommander",
                        ) from exc
                    if dry_run:
                        outcomes.append(
                            ApplyOutcome(
                                uid_ref=change.uid_ref or name,
                                keeper_uid=change.keeper_uid or "",
                                action="update",
                                details={
                                    "dry_run": True,
                                    "new_name": new_name,
                                },
                            )
                        )
                        continue
                    if not hasattr(KSMCommand, "update_app"):
                        raise CapabilityError(
                            reason="Commander KSMCommand has no update_app API",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action="need KSMCommand.update_app(params, app_name_or_uid, new_name)",
                        )

                    def _run_update_app() -> None:
                        params = self._get_keeper_params()
                        KSMCommand.update_app(params, app_uid_or_name, new_name)

                    try:
                        self._with_keeper_session_refresh(_run_update_app)
                    except CapabilityError:
                        raise
                    except Exception as exc:
                        raise CapabilityError(
                            reason=f"KSM app rename failed: {type(exc).__name__}: {exc}",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action="verify the app exists and the new name is unique",
                        ) from exc
                    self._ksm_app_rows_cache = None
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or "",
                            action="update",
                            details={
                                "dry_run": False,
                                "new_name": new_name,
                            },
                        )
                    )
                    continue

                if (
                    change.kind is ChangeKind.UPDATE
                    and change.resource_type == _KSM_CLIENT_RESOURCE_TYPE
                ):
                    raise CapabilityError(
                        reason="KSM client in-place update/rotation is not implemented",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action=(
                            "Commander 18.0.0 has no `secrets-manager client rotate` "
                            "or `secrets-manager client update` verb; remove the old "
                            "client with `secrets-manager client remove` and register a "
                            "new one with `secrets-manager client add`"
                        ),
                    )

                if change.kind in (ChangeKind.UPDATE, ChangeKind.DELETE):
                    raise CapabilityError(
                        reason=_KSM_CREATE_ONLY_UNSUPPORTED_REASON,
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action=(
                            "apply ksm_app create/delete rows or existing ksm_record_share "
                            "editable updates with Commander; use mock provider for full "
                            "offline KSM lifecycle simulation"
                        ),
                    )
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details=details,
                    )
                )
                continue

            if (
                change.kind is ChangeKind.CREATE
                and change.resource_type == _KSM_CLIENT_RESOURCE_TYPE
            ):
                app_uid = _ksm_client_app_uid(change)
                add_kwargs = ksm_client_add_kwargs(change.after)
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or "",
                            action="create",
                            details={
                                "dry_run": True,
                                "app_uid": app_uid,
                                "count": add_kwargs["count"],
                                "unlock_ip": add_kwargs["unlock_ip"],
                                "first_access_expire_on": add_kwargs["first_access_expire_on"],
                                "access_expire_in_min": add_kwargs["access_expire_in_min"],
                                "client_name": add_kwargs["client_name"],
                                "config_init": add_kwargs["config_init"],
                            },
                        )
                    )
                    continue
                if not app_uid:
                    raise CapabilityError(
                        reason="KSM client create requires after.app_uid_ref",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action="refresh plan from a keeper-ksm.v1 manifest with clients[].app_uid_ref",
                    )
                tokens = self.ksm_client_add(app_uid, **add_kwargs)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or app_uid,
                        action="create",
                        details={
                            "dry_run": False,
                            "app_uid": app_uid,
                            **ksm_client_token_summary(tokens),
                        },
                    )
                )
                continue

            if change.kind is ChangeKind.CREATE and change.resource_type == "ksm_token":
                if not _supports_secrets_manager_token_add():
                    raise CapabilityError(
                        reason=(
                            "KSM token create requires Commander capability "
                            "`secrets-manager token add <app_uid>`"
                        ),
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action=(
                            "install a Commander build that exposes "
                            "`secrets-manager token add <app_uid>`"
                        ),
                    )
                outcomes.append(self._apply_ksm_token_add(change, plan, dry_run=dry_run))
                continue

            if change.kind is ChangeKind.CREATE and change.resource_type == "ksm_record_share":
                app_uid, secret_uid = _ksm_share_keeper_uids(change)
                editable = _ksm_change_bool(change, "editable")
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=change.keeper_uid or "",
                            action="create",
                            details={
                                "dry_run": True,
                                "app_uid": app_uid,
                                "secret_uid": secret_uid,
                                "editable": editable,
                            },
                        )
                    )
                    continue
                if not app_uid or not secret_uid:
                    raise CapabilityError(
                        reason="KSM record share create requires resolvable app and secret UIDs",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action=(
                            "set after.app_uid_ref and after.record_uid_ref on the share row, "
                            "or change.keeper_uid as `<app_uid>|<secret_uid>`"
                        ),
                    )
                self.ksm_app_share_add(app_uid, [secret_uid], editable)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=f"{app_uid}|{secret_uid}",
                        action="create",
                        details={
                            "dry_run": False,
                            "app_uid": app_uid,
                            "secret_uid": secret_uid,
                            "editable": editable,
                        },
                    )
                )
                continue

            if change.resource_type != _KSM_APP_RESOURCE_TYPE:
                raise CapabilityError(
                    reason=_KSM_CREATE_ONLY_UNSUPPORTED_REASON,
                    uid_ref=change.uid_ref or name,
                    resource_type=change.resource_type,
                    next_action=(
                        "apply only ksm_app create rows with Commander; use mock provider "
                        "or CLI for unsupported KSM resource creates (e.g. config outputs)"
                    ),
                )

            duplicate = next(
                (
                    row
                    for row in self._ksm_app_rows()
                    if str(row.get("app_title", "")).casefold() == name.casefold()
                ),
                None,
            )
            if duplicate is not None:
                raise ConflictError(
                    reason=f"KSM application {name!r} already exists; refusing create",
                    uid_ref=change.uid_ref or name,
                    resource_type=change.resource_type,
                    live_identifier=str(
                        duplicate.get("app_uid") or duplicate.get("app_title") or name
                    ),
                    next_action="refresh plan from live KSM state or rename the application",
                    context={"live": duplicate},
                )

            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid="",
                        action="create",
                        details={"dry_run": True, "marker_written": False},
                    )
                )
                continue

            try:
                from keepercommander.commands.ksm import KSMCommand
            except (ImportError, AttributeError) as exc:
                raise CapabilityError(
                    reason=f"Commander KSMCommand is unavailable: {exc}",
                    uid_ref=change.uid_ref or name,
                    resource_type=change.resource_type,
                    next_action=(
                        "upgrade keepercommander to a version that provides "
                        "keepercommander.commands.ksm.KSMCommand"
                    ),
                ) from exc

            try:
                from keepercommander import api as commander_api
            except (ImportError, AttributeError):
                commander_api = None

            def _run_create() -> str:
                params = self._get_keeper_params()
                if not hasattr(KSMCommand, "add_new_v5_app"):
                    raise CapabilityError(
                        reason="Commander KSMCommand has no add_new_v5_app(params, name) API",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action="need KSMCommand.add_new_v5_app(params, name)",
                    )
                result = KSMCommand.add_new_v5_app(params, name)
                if commander_api is not None and hasattr(commander_api, "sync_down"):
                    commander_api.sync_down(params)
                app_uid = _ksm_create_result_uid(result)
                if not app_uid and hasattr(KSMCommand, "get_app_record"):
                    app_uid = _ksm_app_record_uid(KSMCommand.get_app_record(params, name))
                if not app_uid:
                    raise CapabilityError(
                        reason=f"Commander KSMCommand created no resolvable app UID for {name!r}",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action="inspect Commander KSM app-create output and retry after cleanup",
                    )
                return app_uid

            try:
                app_uid = self._with_keeper_session_refresh(_run_create)
            except CapabilityError:
                raise
            except Exception as exc:
                raise CapabilityError(
                    reason=f"KSM application create failed: {type(exc).__name__}: {exc}",
                    uid_ref=change.uid_ref or name,
                    resource_type=change.resource_type,
                    next_action="verify Keeper Secrets Manager application create permissions",
                ) from exc

            marker = encode_marker(
                uid_ref=change.uid_ref or name,
                manifest=plan.manifest_name,
                resource_type=change.resource_type,
                last_applied_at=utc_timestamp(),
            )
            self._write_marker(app_uid, marker)
            self._ksm_app_rows_cache = None
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or name,
                    keeper_uid=app_uid,
                    action="create",
                    details={"dry_run": False, "marker_written": True},
                )
            )
        return outcomes

    def adopt_managed_companies(
        self,
        plan: Plan,
        *,
        dry_run: bool = False,  # noqa: ARG002
    ) -> list[ApplyOutcome]:
        """Reject MSP marker adoption on Commander until a marker writer exists."""
        first = next(iter(_msp_plan_changes(plan)), None)
        raise CapabilityError(
            reason=_MSP_MARKER_UNSUPPORTED_REASON,
            uid_ref=(first.uid_ref if first else None),
            resource_type=(first.resource_type if first else "managed_company"),
            next_action=(
                "use the mock provider for offline adoption tests; wait for a Commander "
                "managed-company metadata writer before live MSP marker import"
            ),
        )

    def _apply_ksm_token_add(
        self,
        change: Change,
        plan: Plan,
        *,
        dry_run: bool,
    ) -> ApplyOutcome:
        name = _ksm_change_name(change)
        app_uid_ref = str(change.after.get("app_uid_ref") or "")
        app_uid = _ref_leaf(app_uid_ref, "keeper-ksm:apps:")
        if not app_uid:
            raise CapabilityError(
                reason="KSM token create requires after.app_uid_ref",
                uid_ref=change.uid_ref or name,
                resource_type=change.resource_type,
                next_action="refresh plan from a keeper-ksm.v1 manifest with tokens[].app_uid_ref",
            )
        argv = ["secrets-manager", "token", "add", app_uid]
        if dry_run:
            return ApplyOutcome(
                uid_ref=change.uid_ref or name,
                keeper_uid="",
                action="create",
                details={"dry_run": True, "command": argv},
            )
        self._run_cmd(argv)
        return ApplyOutcome(
            uid_ref=change.uid_ref or name,
            keeper_uid="",
            action="create",
            details={
                "dry_run": False,
                "command": argv,
                "token_created": True,
            },
        )

    def _ksm_app_rows(self) -> list[dict[str, str]]:
        """Return KSM application rows, caching the JSON payload per provider."""
        if self._ksm_app_rows_cache is not None:
            return self._ksm_app_rows_cache
        raw = self._run_cmd(["secrets-manager", "app", "list", "--format", "json"])
        data = _load_json(raw, command="secrets-manager app list --format json")
        if isinstance(data, dict):
            items = data.get("applications") or []
        elif isinstance(data, list):
            items = data
        else:
            items = []
        rows: list[dict[str, str]] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            rows.append(
                {
                    "app_title": str(
                        item.get("app_name")
                        or item.get("title")
                        or item.get("name")
                        or item.get("application_name")
                        or ""
                    ),
                    "app_uid": str(
                        item.get("app_uid") or item.get("uid") or item.get("application_uid") or ""
                    ),
                }
            )
        self._ksm_app_rows_cache = rows
        return rows

    def ksm_app_remove(
        self,
        app_name_or_uid: str,
        *,
        purge: bool = False,
        force: bool = False,
    ) -> None:
        """Remove a KSM application through Commander's in-process API."""
        try:
            from keepercommander import api as commander_api
            from keepercommander.commands.ksm import KSMCommand
        except (ImportError, AttributeError) as exc:
            raise CapabilityError(
                reason=f"Commander KSMCommand is unavailable: {exc}",
                next_action=(
                    "upgrade keepercommander to a version that provides "
                    "KSMCommand.remove_v5_app(params, app_name_or_uid, purge, force)"
                ),
            ) from exc

        def run_once() -> None:
            params = self._get_keeper_params()
            if not hasattr(KSMCommand, "remove_v5_app"):
                raise CapabilityError(
                    reason="Commander KSMCommand has no remove_v5_app API",
                    next_action="need KSMCommand.remove_v5_app(params, app_name_or_uid, purge, force)",
                )
            KSMCommand.remove_v5_app(params, app_name_or_uid, purge, force)
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)

        try:
            self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"KSM application delete failed: {type(exc).__name__}: {exc}",
                next_action="verify Keeper Secrets Manager application delete permissions",
            ) from exc

    def ksm_app_share_update(
        self,
        app_uid: str,
        secret_uids: list[str],
        editable: bool,
    ) -> None:
        """Update editable permission on secrets already shared to a KSM app."""
        try:
            from keepercommander import api as commander_api
            from keepercommander.commands.ksm import KSMCommand
        except (ImportError, AttributeError) as exc:
            raise CapabilityError(
                reason=f"Commander KSMCommand is unavailable: {exc}",
                next_action=(
                    "upgrade keepercommander to a version that provides "
                    "KSMCommand.update_app_share(params, secret_uids, app_uid, editable)"
                ),
            ) from exc

        def run_once() -> None:
            params = self._get_keeper_params()
            if not hasattr(KSMCommand, "update_app_share"):
                raise CapabilityError(
                    reason="Commander KSMCommand has no update_app_share API",
                    next_action=(
                        "need KSMCommand.update_app_share(params, secret_uids, "
                        "app_name_or_uid, is_editable)"
                    ),
                )
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)
            KSMCommand.update_app_share(params, secret_uids, app_uid, editable)
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)

        try:
            self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"KSM app share update failed: {type(exc).__name__}: {exc}",
                next_action="verify the secret is already shared with this KSM app",
            ) from exc

    def ksm_app_share_remove(
        self,
        app_uid: str,
        secret_uids: list[str],
    ) -> None:
        """Remove record/shared-folder grants from a KSM app."""
        try:
            from keepercommander import api as commander_api
            from keepercommander.commands.ksm import KSMCommand
        except (ImportError, AttributeError) as exc:
            raise CapabilityError(
                reason=f"Commander KSMCommand is unavailable: {exc}",
                next_action=(
                    "upgrade keepercommander to a version that provides "
                    "KSMCommand.remove_share(params, app_uid, secret_uids)"
                ),
            ) from exc

        def run_once() -> None:
            params = self._get_keeper_params()
            if not hasattr(KSMCommand, "remove_share"):
                raise CapabilityError(
                    reason="Commander KSMCommand has no remove_share API",
                    next_action=(
                        "need KSMCommand.remove_share(params, app_name_or_uid, secret_uids); "
                        "manual fallback: keeper secrets-manager share remove --app "
                        "<app_uid> --secret <record_or_shared_folder_uid>"
                    ),
                )
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)
            KSMCommand.remove_share(params, app_uid, secret_uids)
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)

        try:
            self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"KSM app share delete failed: {type(exc).__name__}: {exc}",
                next_action=(
                    "keeper secrets-manager share remove --app <app_uid> "
                    "--secret <record_or_shared_folder_uid>"
                ),
            ) from exc

    def ksm_app_share_add(
        self,
        app_uid: str,
        secret_uids: list[str],
        editable: bool,
    ) -> None:
        """Share vault records with a KSM app via ``KSMCommand.add_app_share``."""
        try:
            from keepercommander import api as commander_api
            from keepercommander.commands.ksm import KSMCommand
        except (ImportError, AttributeError) as exc:
            raise CapabilityError(
                reason=f"Commander KSMCommand is unavailable: {exc}",
                next_action=(
                    "upgrade keepercommander to a version that provides "
                    "KSMCommand.add_app_share(params, secret_uids, app_uid, editable)"
                ),
            ) from exc

        def run_once() -> None:
            params = self._get_keeper_params()
            if not hasattr(KSMCommand, "add_app_share"):
                raise CapabilityError(
                    reason="Commander KSMCommand has no add_app_share API",
                    next_action=(
                        "run manually: keeper secrets-manager app share <app_uid> "
                        "--record-uid <record_uid>"
                    ),
                )
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)
            KSMCommand.add_app_share(params, secret_uids, app_uid, editable)
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)

        try:
            self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"KSM app share create failed: {type(exc).__name__}: {exc}",
                next_action=(
                    "keeper secrets-manager app share <app_uid> --record-uid <record_uid>"
                ),
            ) from exc

    def ksm_client_add(
        self,
        app_uid: str,
        *,
        count: int,
        unlock_ip: bool,
        first_access_expire_on: int,
        access_expire_in_min: int | None,
        client_name: str | None,
        config_init: str | None,
        client_type: int,
    ) -> Any:
        """Register KSM client devices and return Commander's token rows."""
        try:
            from keepercommander import api as commander_api
            from keepercommander.commands.ksm import KSMCommand
        except (ImportError, AttributeError) as exc:
            raise CapabilityError(
                reason=f"Commander KSMCommand is unavailable: {exc}",
                next_action=(
                    "upgrade keepercommander to a version that provides "
                    "KSMCommand.add_client(params, app_uid, ...)"
                ),
            ) from exc

        def run_once() -> Any:
            params = self._get_keeper_params()
            if not hasattr(KSMCommand, "add_client"):
                raise CapabilityError(
                    reason="Commander KSMCommand has no add_client API",
                    next_action=(
                        "need KSMCommand.add_client(params, app_name_or_uid, count, "
                        "unlock_ip, first_access_expire_on, access_expire_in_min, ...); "
                        "manual fallback: keeper secrets-manager client add --app <app_uid>"
                    ),
                )
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)
            return KSMCommand.add_client(
                params,
                app_uid,
                count,
                unlock_ip,
                first_access_expire_on,
                access_expire_in_min,
                client_name=client_name,
                config_init=config_init,
                silent=True,
                client_type=client_type,
            )

        try:
            return self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"KSM client registration failed: {type(exc).__name__}: {exc}",
                next_action=(
                    "keeper secrets-manager client add --app <app_uid> --name <client_name>"
                ),
            ) from exc

    def ksm_client_remove(
        self,
        app_uid: str,
        client_identifiers: list[str],
        *,
        force: bool = True,
    ) -> None:
        """Remove one or more KSM client devices from an application."""
        try:
            from keepercommander import api as commander_api
            from keepercommander.commands.ksm import KSMCommand
        except (ImportError, AttributeError) as exc:
            raise CapabilityError(
                reason=f"Commander KSMCommand is unavailable: {exc}",
                next_action=(
                    "upgrade keepercommander to a version that provides "
                    "KSMCommand.remove_client(params, app_uid, client_names_and_hashes, force)"
                ),
            ) from exc

        def run_once() -> None:
            params = self._get_keeper_params()
            remove_all = any(item in {"*", "all"} for item in client_identifiers)
            if remove_all:
                if not hasattr(KSMCommand, "remove_all_clients"):
                    raise CapabilityError(
                        reason="Commander KSMCommand has no remove_all_clients API",
                        next_action=(
                            "need KSMCommand.remove_all_clients(params, app_name_or_uid, force); "
                            "manual fallback: keeper secrets-manager client remove --app "
                            "<app_uid> --client all --force"
                        ),
                    )
                KSMCommand.remove_all_clients(params, app_uid, force)
            else:
                if not hasattr(KSMCommand, "remove_client"):
                    raise CapabilityError(
                        reason="Commander KSMCommand has no remove_client API",
                        next_action=(
                            "need KSMCommand.remove_client(params, app_name_or_uid, "
                            "client_names_and_hashes, force); manual fallback: keeper "
                            "secrets-manager client remove --app <app_uid> --client "
                            "<name_or_id> --force"
                        ),
                    )
                KSMCommand.remove_client(params, app_uid, client_identifiers, force=force)
            if hasattr(commander_api, "sync_down"):
                commander_api.sync_down(params)

        try:
            self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"KSM client removal failed: {type(exc).__name__}: {exc}",
                next_action=(
                    "keeper secrets-manager client remove --app <app_uid> "
                    "--client <name_or_id> --force"
                ),
            ) from exc

    def _ksm_app_marker(self, app_uid: str) -> dict[str, Any] | None:
        """Best-effort read of the SDK ownership marker from a KSM app record."""
        try:
            raw = self._run_cmd(["get", app_uid, "--format", "json"])
            item = _load_json(raw, command="get <ksm_app_uid> --format json")
        except CapabilityError:
            return None
        if not isinstance(item, dict):
            return None
        marker = decode_marker(_extract_marker_field(item))
        return marker if isinstance(marker, dict) else None

    def _ksm_app_share_rows(self, app_uid: str, *, app_uid_ref: str) -> list[dict[str, Any]]:
        """Best-effort KSM app-share readback for editable-permission updates."""
        try:
            from keepercommander import utils
            from keepercommander.commands.ksm import KSMCommand
        except (ImportError, AttributeError):
            return []
        if not hasattr(KSMCommand, "get_app_info"):
            return []

        def run_once() -> list[dict[str, Any]]:
            params = self._get_keeper_params()
            app_infos = KSMCommand.get_app_info(params, app_uid) or []
            rows: list[dict[str, Any]] = []
            for app_info in app_infos:
                for share in getattr(app_info, "shares", None) or []:
                    share_type = getattr(share, "shareType", None)
                    if str(share_type) not in {"0", "SHARE_TYPE_RECORD"}:
                        continue
                    secret_uid_raw = getattr(share, "secretUid", None)
                    if isinstance(secret_uid_raw, bytes):
                        secret_uid = utils.base64_url_encode(secret_uid_raw)
                    else:
                        secret_uid = str(secret_uid_raw or "")
                    if not secret_uid:
                        continue
                    rows.append(
                        {
                            "record_uid_ref": self._vault_record_ref_for_uid(secret_uid),
                            "app_uid_ref": f"keeper-ksm:apps:{app_uid_ref}",
                            "editable": bool(getattr(share, "editable", False)),
                            "keeper_uid": f"{app_uid}|{secret_uid}",
                        }
                    )
            return rows

        try:
            return self._with_keeper_session_refresh(run_once)
        except Exception:
            return []

    def _gateway_bound_app_name(self, row: dict[str, str]) -> tuple[str | None, str | None]:
        """Resolve the KSM app title for a gateway row, or explain why not."""
        app_title = row.get("app_title") or ""
        if app_title:
            return app_title, None

        app_uid = row.get("app_uid") or ""
        next_action = (
            "next_action=confirm the gateway's bound KSM application in the Keeper UI "
            "(PAM Gateway details / Secrets Manager Applications) and update the manifest "
            "or tenant to match"
        )
        if not app_uid:
            return (
                None,
                "CLI output exposed neither a KSM app name nor a KSM app UID for this gateway; "
                f"`secrets-manager app list --format json` is application-only and cannot link "
                f"an unlabelled gateway to an app. {next_action}",
            )

        try:
            app_rows = self._ksm_app_rows()
        except (CapabilityError, OSError) as exc:
            return (
                None,
                "CLI output exposed only KSM app UID "
                f"'{app_uid}', and `secrets-manager app list --format json` could not be read: "
                f"{exc}. {next_action}",
            )

        app_by_uid = {item["app_uid"]: item for item in app_rows if item.get("app_uid")}
        resolved = app_by_uid.get(app_uid)
        if resolved and resolved.get("app_title"):
            return resolved["app_title"], None
        return (
            None,
            "CLI output exposed only KSM app UID "
            f"'{app_uid}', and `secrets-manager app list --format json` did not resolve it "
            f"to a visible application name. {next_action}",
        )
