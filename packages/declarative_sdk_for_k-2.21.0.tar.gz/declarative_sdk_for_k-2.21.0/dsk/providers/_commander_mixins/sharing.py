"""Mixin — sharing resource family of CommanderCliProvider.

Private implementation module. Not a public API.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal

from dsk.core.checkpoint import ApplyCheckpoint
from dsk.core.diff import Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome, LiveRecord
from dsk.core.metadata import (
    encode_marker,
)
from dsk.core.planner import Plan
from dsk.providers._commander_cli_helpers import (
    _load_json,
)
from dsk.providers.commander_cli import (
    _SHARING_MARKER_TITLE_PREFIX,
    _SHARING_PAYLOAD_FIELD_LABEL,
    _SHARING_RESOURCE_TYPES,
    LOGGER,
    _checkpoint_uid,
    _commander_on_off,
    _dict_items,
)

if TYPE_CHECKING:
    pass


def _ensure_keepercommander_version_for_apply() -> None:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    _cli_m._ensure_keepercommander_version_for_apply()


class _SharingMixin:
    """Method carrier — sharing resource family."""

    if TYPE_CHECKING:
        # Instance attrs
        _folder_uid: str | None

        # Cross-mixin methods (transport)
        def _run_cmd(self, args: list[str]) -> str: ...
        # Cross-mixin methods (vault)
        def _create_shared_folder(self, *a: Any, **kw: Any) -> Any: ...
        def _create_user_folder(self, *a: Any, **kw: Any) -> Any: ...
        def _delete_folder(self, *a: Any, **kw: Any) -> Any: ...
        def _discover_marker_records(self, *a: Any, **kw: Any) -> Any: ...
        def _vault_add_login_record(self, *a: Any, **kw: Any) -> Any: ...
        def _write_marker(self, *a: Any, **kw: Any) -> Any: ...

    @staticmethod
    def _sharing_delete_order(changes: list[Change]) -> list[Change]:
        rank = {
            "sharing_share_folder": 0,
            "sharing_record_share": 1,
            "sharing_shared_folder": 2,
            "sharing_folder": 3,
        }
        return sorted(
            changes, key=lambda change: (rank.get(change.resource_type, 99), change.title)
        )

    def _apply_sharing_plan(
        self, plan: Plan, *, dry_run: bool = False, checkpoint: ApplyCheckpoint | None = None
    ) -> list[ApplyOutcome]:
        """Apply ``keeper-vault-sharing.v1`` folder + ACL rows.

        Keeper folders/ACL rows do not expose record custom fields. For this
        first Commander-backed sharing slice we persist ownership metadata in
        small sidecar records in the configured declarative folder, while the
        actual folders and ACLs are driven through Commander folder/share
        commands.
        """
        _ensure_keepercommander_version_for_apply()
        if not self._folder_uid:
            raise CapabilityError(
                reason="keeper-vault-sharing apply requires a marker shared folder uid",
                next_action="pass --folder-uid or set KEEPER_DECLARATIVE_FOLDER",
            )

        outcomes: list[ApplyOutcome] = []
        for change in plan.ordered():
            ck_uid = _checkpoint_uid(change)
            if (
                checkpoint
                and not dry_run
                and ck_uid
                and change.kind in (ChangeKind.CREATE, ChangeKind.UPDATE)
                and checkpoint.is_applied(ck_uid)
            ):
                LOGGER.info("apply checkpoint: skipping sharing uid_ref=%s", ck_uid)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=ck_uid,
                        keeper_uid=change.keeper_uid or "",
                        action=change.kind.value,
                        details={"checkpoint_skipped": True},
                    )
                )
                continue
            if change.kind is ChangeKind.CREATE:
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create",
                            details={"dry_run": True},
                        )
                    )
                    continue
                keeper_uid = self._sharing_apply_create_or_update(change)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=keeper_uid,
                        action="create",
                        details={"marker_sidecar_written": True},
                    )
                )
                if checkpoint and ck_uid:
                    checkpoint.mark_applied(ck_uid, "create")
            elif change.kind is ChangeKind.UPDATE:
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=change.keeper_uid or "",
                            action="update",
                            details={"dry_run": True},
                        )
                    )
                    continue
                keeper_uid = self._sharing_apply_create_or_update(change)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=keeper_uid,
                        action="update",
                        details={"marker_sidecar_written": True},
                    )
                )
                if checkpoint and ck_uid:
                    checkpoint.mark_applied(ck_uid, "update")

        for change in self._sharing_delete_order(plan.deletes):
            ck_uid = _checkpoint_uid(change)
            if checkpoint and not dry_run and ck_uid and checkpoint.is_applied(ck_uid):
                LOGGER.info("apply checkpoint: skipping sharing delete uid_ref=%s", ck_uid)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=ck_uid,
                        keeper_uid=change.keeper_uid or "",
                        action="delete",
                        details={"checkpoint_skipped": True},
                    )
                )
                continue
            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="delete",
                        details={"dry_run": True},
                    )
                )
                continue
            self._sharing_apply_delete(change)
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="delete",
                    details={"removed": True},
                )
            )
            if checkpoint and ck_uid:
                checkpoint.mark_applied(ck_uid, "delete")

        for change in plan.conflicts:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="conflict",
                    details={"reason": change.reason or ""},
                )
            )
        for change in plan.noops:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                )
            )
        return outcomes

    def _sharing_apply_create_or_update(self, change: Change) -> str:
        payload = self._sharing_full_payload(change)
        marker = self._sharing_marker_for_change(change, payload)
        resource_type = change.resource_type

        if resource_type == "sharing_folder":
            path = self._require_payload_str(payload, "path", change)
            keeper_uid = self._create_user_folder(
                path=path,
                parent_uid=payload.get("parent_folder_uid_ref"),
                color=payload.get("color"),
            )
            payload["keeper_uid"] = keeper_uid
        elif resource_type == "sharing_shared_folder":
            path = self._require_payload_str(payload, "path", change)
            keeper_uid = self._create_shared_folder(
                path=path,
                manage_records=self._payload_bool(payload, "default_manage_records", True),
                manage_users=self._payload_bool(payload, "default_manage_users", True),
                can_edit=self._payload_bool(payload, "default_can_edit", True),
                can_share=self._payload_bool(payload, "default_can_share", True),
            )
            payload["keeper_uid"] = keeper_uid
            payload.setdefault("name", payload.get("path"))
        elif resource_type == "sharing_share_folder":
            self._sharing_apply_share_folder_acl(payload, change=change)
            keeper_uid = (
                str(payload.get("keeper_uid"))
                if payload.get("keeper_uid")
                else f"{payload.get('shared_folder_uid_ref')}:{change.uid_ref or change.title}"
            )
            payload["keeper_uid"] = keeper_uid
        elif resource_type == "sharing_record_share":
            self._sharing_apply_record_share(payload, change=change)
            keeper_uid = (
                str(payload.get("keeper_uid"))
                if payload.get("keeper_uid")
                else f"{payload.get('record_uid_ref')}:{payload.get('user_email')}"
            )
            payload["keeper_uid"] = keeper_uid
        else:
            raise CapabilityError(
                reason=f"unsupported keeper-vault-sharing resource type {resource_type!r}",
                uid_ref=change.uid_ref,
                resource_type=resource_type,
                next_action="remove the unsupported sharing row and retry",
            )

        self._sharing_upsert_sidecar(payload=payload, marker=marker, title=change.title)
        return str(payload["keeper_uid"])

    def _sharing_apply_delete(self, change: Change) -> None:
        sidecar = self._sharing_sidecar_for(change.uid_ref, change.resource_type)
        payload = dict(sidecar.payload if sidecar is not None else change.before or {})
        if change.resource_type == "sharing_share_folder":
            self._sharing_revoke_share_folder_acl(payload, change=change)
        elif change.resource_type == "sharing_record_share":
            self._sharing_revoke_record_share(payload, change=change)
        elif change.resource_type in {"sharing_folder", "sharing_shared_folder"}:
            path_or_uid = str(payload.get("keeper_uid") or change.keeper_uid or payload.get("path"))
            if path_or_uid:
                self._delete_folder(path_or_uid=path_or_uid)
        else:
            raise CapabilityError(
                reason=f"unsupported keeper-vault-sharing delete type {change.resource_type!r}",
                uid_ref=change.uid_ref,
                resource_type=change.resource_type,
                next_action="remove the unsupported sharing row and retry",
            )
        self._sharing_delete_sidecar(change.uid_ref, change.resource_type)

    def _sharing_full_payload(self, change: Change) -> dict[str, Any]:
        payload = dict(change.after or {})
        if change.kind is ChangeKind.UPDATE:
            sidecar = self._sharing_sidecar_for(change.uid_ref, change.resource_type)
            if sidecar is not None:
                merged = dict(sidecar.payload)
                merged.update(payload)
                payload = merged
        return payload

    def _sharing_marker_for_change(self, change: Change, payload: dict[str, Any]) -> dict[str, Any]:
        raw_marker = payload.get("marker")
        if isinstance(raw_marker, dict):
            return dict(raw_marker)
        return encode_marker(
            uid_ref=change.uid_ref or change.title,
            manifest=change.manifest_name or "vault-sharing",
            resource_type=change.resource_type,
            parent_uid_ref=(
                str(payload.get("shared_folder_uid_ref") or payload.get("record_uid_ref"))
                if payload.get("shared_folder_uid_ref") or payload.get("record_uid_ref")
                else None
            ),
        )

    @staticmethod
    def _require_payload_str(payload: Mapping[str, Any], key: str, change: Change) -> str:
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip():
            raise CapabilityError(
                reason=f"{change.resource_type} {change.uid_ref or change.title} missing {key}",
                uid_ref=change.uid_ref,
                resource_type=change.resource_type,
                next_action=f"fix {key} in the sharing manifest and retry",
            )
        return value

    @staticmethod
    def _payload_bool(payload: Mapping[str, Any], key: str, default: bool) -> bool:
        value = payload.get(key)
        return default if value is None else bool(value)

    def _sharing_apply_share_folder_acl(self, payload: dict[str, Any], *, change: Change) -> None:
        sf_uid = self._sharing_resolve_ref(
            self._require_payload_str(payload, "shared_folder_uid_ref", change),
            expected_resource_type="sharing_shared_folder",
        )
        payload["shared_folder_uid"] = sf_uid
        kind = self._require_payload_str(payload, "kind", change)
        if kind == "grantee":
            grantee_kind, identifier = self._sharing_grantee(payload)
            self._share_folder_to_grantee(
                shared_folder_uid=sf_uid,
                grantee_kind=grantee_kind,
                identifier=identifier,
                manage_records=self._payload_bool(payload, "manage_records", False),
                manage_users=self._payload_bool(payload, "manage_users", False),
            )
            return
        if kind == "default":
            target = self._require_payload_str(payload, "target", change)
            if target == "grantee":
                self._share_folder_to_grantee(
                    shared_folder_uid=sf_uid,
                    grantee_kind="default",
                    manage_records=self._payload_bool(payload, "manage_records", False),
                    manage_users=self._payload_bool(payload, "manage_users", False),
                )
                return
            if target == "record":
                self._set_shared_folder_default_record_share(
                    shared_folder_uid=sf_uid,
                    can_edit=self._payload_bool(payload, "can_edit", False),
                    can_share=self._payload_bool(payload, "can_share", False),
                )
                return
        raise CapabilityError(
            reason=f"unsupported share_folder ACL row kind/target: {kind}/{payload.get('target')}",
            uid_ref=change.uid_ref,
            resource_type=change.resource_type,
            next_action="use a grantee row or a default grantee/record row for V9a",
        )

    def _sharing_revoke_share_folder_acl(self, payload: dict[str, Any], *, change: Change) -> None:
        sf_uid = str(payload.get("shared_folder_uid") or "")
        if not sf_uid and payload.get("shared_folder_uid_ref"):
            sf_uid = self._sharing_resolve_ref(
                str(payload["shared_folder_uid_ref"]),
                expected_resource_type="sharing_shared_folder",
            )
        if not sf_uid:
            return
        kind = str(payload.get("kind") or "")
        if kind == "grantee":
            grantee_kind, identifier = self._sharing_grantee(payload)
            try:
                self._revoke_folder_grantee(
                    shared_folder_uid=sf_uid,
                    grantee_kind=grantee_kind,
                    identifier=identifier,
                )
            except CapabilityError as exc:
                if not self._sharing_missing_folder_error(exc):
                    raise
        elif kind == "default":
            try:
                self._revoke_folder_grantee(shared_folder_uid=sf_uid, grantee_kind="default")
            except CapabilityError as exc:
                if not self._sharing_missing_folder_error(exc):
                    raise

    @staticmethod
    def _sharing_missing_folder_error(exc: CapabilityError) -> bool:
        text = f"{exc.reason}\n{exc.context.get('stderr', '')}"
        return "Enter name of at least one existing folder" in text

    def _sharing_apply_record_share(self, payload: dict[str, Any], *, change: Change) -> None:
        record_uid = self._sharing_resolve_record_ref(
            self._require_payload_str(payload, "record_uid_ref", change)
        )
        user_email = self._require_payload_str(payload, "user_email", change)
        payload["record_uid"] = record_uid
        self._share_record_to_user(
            record_uid=record_uid,
            user_email=user_email,
            can_edit=self._payload_bool(payload, "can_edit", False),
            can_share=self._payload_bool(payload, "can_share", False),
            contacts_only=self._payload_bool(payload, "contacts_only", False),
            recursive=self._payload_bool(payload, "recursive", False),
            expiration_iso=payload.get("expires_at")
            if isinstance(payload.get("expires_at"), str)
            else None,
        )

    def _sharing_revoke_record_share(self, payload: dict[str, Any], *, change: Change) -> None:
        record_uid = str(payload.get("record_uid") or "")
        if not record_uid and payload.get("record_uid_ref"):
            record_uid = self._sharing_resolve_record_ref(str(payload["record_uid_ref"]))
        user_email = str(payload.get("user_email") or "")
        if record_uid and user_email:
            self._revoke_record_share_from_user(record_uid=record_uid, user_email=user_email)

    @staticmethod
    def _sharing_grantee(payload: Mapping[str, Any]) -> tuple[Literal["user", "team"], str]:
        grantee = payload.get("grantee")
        if isinstance(grantee, Mapping):
            kind = grantee.get("kind")
            if kind == "user" and grantee.get("user_email"):
                return "user", str(grantee["user_email"])
            if kind == "team" and grantee.get("team_uid_ref"):
                return "team", str(grantee["team_uid_ref"])
        if payload.get("user_email"):
            return "user", str(payload["user_email"])
        if payload.get("team_uid_ref"):
            return "team", str(payload["team_uid_ref"])
        raise CapabilityError(
            reason="share_folder grantee row is missing a user_email or team_uid_ref",
            next_action="add grantee.user_email or grantee.team_uid_ref and retry",
        )

    @staticmethod
    def _sharing_uid_ref_from_ref(ref: str) -> str:
        return ref.rsplit(":", 1)[-1]

    def _sharing_resolve_ref(self, ref: str, *, expected_resource_type: str) -> str:
        uid_ref = self._sharing_uid_ref_from_ref(ref)
        sidecar = self._sharing_sidecar_for(uid_ref, expected_resource_type)
        if sidecar is None:
            raise CapabilityError(
                reason=f"could not resolve {ref} from sharing marker sidecars",
                uid_ref=uid_ref,
                resource_type=expected_resource_type,
                next_action="apply the referenced sharing folder first, then retry",
            )
        return sidecar.keeper_uid

    def _sharing_resolve_record_ref(self, ref: str) -> str:
        uid_ref = self._sharing_uid_ref_from_ref(ref)
        for record in self._discover_marker_records():
            marker = record.marker or {}
            if marker.get("uid_ref") == uid_ref and marker.get("resource_type") == "login":
                return record.keeper_uid
        raise CapabilityError(
            reason=f"could not resolve record ref {ref} from scoped marker records",
            uid_ref=uid_ref,
            resource_type="sharing_record_share",
            next_action="create the keeper-vault record in the same declarative scope first",
        )

    def _sharing_upsert_sidecar(
        self,
        *,
        payload: dict[str, Any],
        marker: dict[str, Any],
        title: str,
    ) -> str:
        self._sharing_delete_sidecar(
            str(marker.get("uid_ref") or ""),
            str(marker.get("resource_type") or ""),
        )
        payload_for_record = dict(payload)
        payload_for_record.pop("marker", None)
        sidecar_title = self._sharing_sidecar_title(marker, title)
        payload_json = json.dumps(payload_for_record, separators=(",", ":"), sort_keys=True)
        sidecar_uid = self._vault_add_login_record(
            {
                "type": "login",
                "title": sidecar_title,
                "fields": [
                    {
                        "type": "login",
                        "label": "Login",
                        "value": ["dsk-sharing-marker"],
                    }
                ],
                "custom": [
                    {
                        "type": "text",
                        "label": _SHARING_PAYLOAD_FIELD_LABEL,
                        "value": [payload_json],
                    }
                ],
            }
        )
        self._write_marker(sidecar_uid, marker)
        return sidecar_uid

    @staticmethod
    def _sharing_sidecar_title(marker: Mapping[str, Any], fallback: str) -> str:
        manifest = str(marker.get("manifest") or "vault-sharing")
        uid_ref = str(marker.get("uid_ref") or fallback)
        return f"{_SHARING_MARKER_TITLE_PREFIX}: {manifest}: {uid_ref}"

    def _sharing_delete_sidecar(self, uid_ref: str | None, resource_type: str | None) -> None:
        if not uid_ref or not resource_type:
            return
        for sidecar in self._discover_sharing_sidecars():
            marker = sidecar.marker or {}
            if marker.get("uid_ref") != uid_ref or marker.get("resource_type") != resource_type:
                continue
            sidecar_uid = str(sidecar.payload.get("_sidecar_uid") or "")
            if sidecar_uid:
                self._run_cmd(["rm", "--force", sidecar_uid])
            return

    def _sharing_sidecar_for(
        self,
        uid_ref: str | None,
        resource_type: str | None,
    ) -> LiveRecord | None:
        if not uid_ref or not resource_type:
            return None
        for sidecar in self._discover_sharing_sidecars():
            marker = sidecar.marker or {}
            if marker.get("uid_ref") == uid_ref and marker.get("resource_type") == resource_type:
                return sidecar
        return None

    def _discover_sharing_rows(self) -> list[LiveRecord]:
        return self._discover_sharing_sidecars()

    def _discover_sharing_sidecars(self) -> list[LiveRecord]:
        rows: list[LiveRecord] = []
        for record in self._discover_marker_records():
            marker = record.marker or {}
            resource_type = marker.get("resource_type")
            if resource_type not in _SHARING_RESOURCE_TYPES:
                continue
            raw_payload = record.payload.get(_SHARING_PAYLOAD_FIELD_LABEL)
            if isinstance(raw_payload, list):
                raw_payload = raw_payload[0] if raw_payload else None
            payload: dict[str, Any]
            if isinstance(raw_payload, str) and raw_payload.strip():
                try:
                    loaded = json.loads(raw_payload)
                    payload = loaded if isinstance(loaded, dict) else {}
                except ValueError:
                    payload = {}
            else:
                payload = {}
            payload.setdefault("uid_ref", marker.get("uid_ref"))
            payload.setdefault("resource_type", resource_type)
            payload["_sidecar_uid"] = record.keeper_uid
            keeper_uid = str(payload.get("keeper_uid") or record.keeper_uid)
            rows.append(
                LiveRecord(
                    keeper_uid=keeper_uid,
                    title=str(payload.get("path") or payload.get("name") or record.title),
                    resource_type=str(resource_type),
                    folder_uid=record.folder_uid,
                    payload=payload,
                    marker=marker,
                )
            )
        return rows

    def _share_record_to_user(
        self,
        *,
        record_uid: str,
        user_email: str,
        can_edit: bool,
        can_share: bool,
        contacts_only: bool = False,
        recursive: bool = False,
        expiration_iso: str | None = None,
    ) -> None:
        args = ["share-record", "-a", "grant", "-e", user_email, "-f"]
        if contacts_only:
            args.append("--contacts-only")
        if can_edit:
            args.append("-w")
        if can_share:
            args.append("-s")
        if recursive:
            args.append("-R")
        if expiration_iso is not None:
            args.extend(["--expire-at", expiration_iso])
        args.append(record_uid)
        self._run_cmd(args)

    def _revoke_record_share_from_user(self, *, record_uid: str, user_email: str) -> None:
        self._run_cmd(["share-record", "-a", "revoke", "-e", user_email, record_uid])

    def _share_folder_to_grantee(
        self,
        *,
        shared_folder_uid: str,
        grantee_kind: Literal["user", "team", "default"],
        identifier: str | None = None,
        manage_records: bool,
        manage_users: bool,
    ) -> None:
        grantee = self._share_folder_grantee_arg(
            grantee_kind=grantee_kind,
            identifier=identifier,
        )
        self._run_cmd(
            [
                "share-folder",
                "-a",
                "grant",
                "-e",
                grantee,
                "-f",
                "-p",
                _commander_on_off(manage_records),
                "-o",
                _commander_on_off(manage_users),
                shared_folder_uid,
            ]
        )

    def _revoke_folder_grantee(
        self,
        *,
        shared_folder_uid: str,
        grantee_kind: Literal["user", "team", "default"],
        identifier: str | None = None,
    ) -> None:
        grantee = self._share_folder_grantee_arg(
            grantee_kind=grantee_kind,
            identifier=identifier,
        )
        self._run_cmd(["share-folder", "-a", "remove", "-e", grantee, "-f", shared_folder_uid])

    def _share_record_to_shared_folder(
        self,
        *,
        shared_folder_uid: str,
        record_uid: str,
        can_edit: bool,
        can_share: bool,
    ) -> None:
        self._run_cmd(
            [
                "share-folder",
                "-a",
                "grant",
                "-r",
                record_uid,
                "-f",
                "-d",
                _commander_on_off(can_edit),
                "-s",
                _commander_on_off(can_share),
                shared_folder_uid,
            ]
        )

    def _set_shared_folder_default_record_share(
        self,
        *,
        shared_folder_uid: str,
        can_edit: bool,
        can_share: bool,
    ) -> None:
        self._run_cmd(
            [
                "share-folder",
                "-a",
                "grant",
                "-r",
                "*",
                "-f",
                "-d",
                _commander_on_off(can_edit),
                "-s",
                _commander_on_off(can_share),
                shared_folder_uid,
            ]
        )

    def _discover_shared_folder_acl(self, *, shared_folder_uid: str) -> dict[str, Any]:
        payload = self._run_cmd(["get", shared_folder_uid, "--format", "json"])
        item = _load_json(payload, command="get --format json")
        if not isinstance(item, dict):
            raise CapabilityError(
                reason="Commander returned non-object JSON from `get --format json`"
            )
        return {
            "users": _dict_items(item.get("users")),
            "teams": _dict_items(item.get("teams")),
            "records": _dict_items(item.get("records")),
            "default": {
                "manage_records": item.get("manage_records", item.get("default_manage_records")),
                "manage_users": item.get("manage_users", item.get("default_manage_users")),
                "can_edit": item.get("can_edit", item.get("default_can_edit")),
                "can_share": item.get("can_share", item.get("default_can_share")),
            },
        }

    @staticmethod
    def _share_folder_grantee_arg(
        *,
        grantee_kind: Literal["user", "team", "default"],
        identifier: str | None,
    ) -> str:
        if grantee_kind == "default":
            if identifier is not None:
                raise ValueError("default shared-folder grantee must not specify identifier")
            return "*"
        if grantee_kind in {"user", "team"}:
            if not identifier:
                raise ValueError(f"{grantee_kind} shared-folder grantee requires identifier")
            return identifier
        raise ValueError(f"unsupported shared-folder grantee kind: {grantee_kind}")

    def _share_folder_to_ksm_app(self, *, folder_uid: str, app_uid: str) -> None:
        try:
            self._run_cmd(
                [
                    "secrets-manager",
                    "share",
                    "add",
                    "--app",
                    app_uid,
                    "--secret",
                    folder_uid,
                    "--editable",
                ]
            )
        except CapabilityError as exc:
            text = "\n".join(
                str(value) for value in (exc.context or {}).values() if isinstance(value, str)
            ).casefold()
            if "already" not in text:
                raise
