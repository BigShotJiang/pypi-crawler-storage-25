"""Mixin — enterprise resource family of CommanderCliProvider.

Private implementation module. Not a public API.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.governance import (
    GOVERNANCE_TRANSFER_RESOURCE,
    governance_transfer_from_change,
)
from dsk.core.interfaces import ApplyOutcome
from dsk.core.planner import Plan
from dsk.providers.commander_cli import (
    _ENTERPRISE_CONFIG_RESOURCE_TYPES,
    _ENTERPRISE_CONFIG_UNSUPPORTED_REASON,
    _GOVERNANCE_FOLDER_TRANSFER_UNSUPPORTED_REASON,
    _all_plan_changes,
    _commander_on_off,
)

if TYPE_CHECKING:
    pass


def _ensure_keepercommander_version_for_apply() -> None:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    _cli_m._ensure_keepercommander_version_for_apply()


class _EnterpriseMixin:
    """Method carrier — enterprise resource family."""

    if TYPE_CHECKING:
        # Cross-mixin methods (transport)
        def _get_keeper_params(self) -> Any: ...
        def _with_keeper_session_refresh(self, fn: Any, *a: Any, **kw: Any) -> Any: ...

    def apply_scim_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply ``keeper-scim.v1`` — SCIM sync via Commander :class:`ScimPushCommand`.

        Declarative ``endpoints[]`` rows become ``resource_type=scim_push`` plan changes.
        Each live apply calls ``scim push`` (full user/group/membership sync for that node).

        Structural ``nodes`` / ``roles`` / ``teams`` / ``users`` rows map to Commander
        ``enterprise-node`` / ``enterprise-role`` / ``enterprise-team`` / ``enterprise-user``
        (in-process), mirroring :meth:`apply_enterprise_plan` where shapes align. Role
        enforcement flags and user role/team membership lists are not wired on live apply
        yet and raise :class:`~dsk.core.errors.CapabilityError` with the missing hook.
        """
        outcomes: list[ApplyOutcome] = []
        for change in plan.changes:
            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="conflict",
                        details={"reason": change.reason or "blocked"},
                    )
                )
                continue
            if change.kind not in (ChangeKind.CREATE, ChangeKind.UPDATE):
                continue

            if change.resource_type == "scim_push":
                uid_key = change.uid_ref or ""
                after = change.after or {}
                push_type = after.get("push_type", "all")
                source = after.get("source", "record")
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=uid_key,
                            keeper_uid=str(after.get("node_id") or ""),
                            action="update",
                            details={"dry_run": True, "push_type": push_type, "source": source},
                        )
                    )
                    continue
                node_id = after.get("node_id")
                if not node_id:
                    raise CapabilityError(
                        reason=(
                            "keeper-scim.v1 apply: node_id required on scim_push plan row — "
                            "set endpoints[].node_id (see scim list / scim create --node)"
                        ),
                        uid_ref=uid_key,
                        resource_type=change.resource_type,
                        next_action=(
                            "add node_id to the manifest endpoint or align the push change payload"
                        ),
                    )
                creds_record_uid = after.get("creds_record_uid")
                if source == "google":
                    if not creds_record_uid:
                        raise CapabilityError(
                            reason=(
                                "keeper-scim.v1 apply: source=google requires creds_record_uid — "
                                "bind endpoints[].creds_record_uid to the vault record that holds "
                                "Google Workspace SCIM configuration (login + credentials.json "
                                "attachment per Commander scim push)"
                            ),
                            uid_ref=uid_key,
                            resource_type=change.resource_type,
                            next_action=(
                                "set creds_record_uid on the endpoint row (Commander: scim push "
                                "--source google --record <uid>)"
                            ),
                        )
                elif source == "ad":
                    if not creds_record_uid:
                        raise CapabilityError(
                            reason=(
                                "keeper-scim.v1 apply: source=ad requires creds_record_uid — "
                                "bind endpoints[].creds_record_uid to the vault record that holds "
                                "Active Directory SCIM configuration for Commander scim push"
                            ),
                            uid_ref=uid_key,
                            resource_type=change.resource_type,
                            next_action=(
                                "set creds_record_uid on the endpoint row (Commander: scim push "
                                "--source ad --record <uid>)"
                            ),
                        )
                _ensure_keepercommander_version_for_apply()

                def _run_push() -> Any:
                    from keepercommander.commands.scim import ScimPushCommand

                    params = self._get_keeper_params()
                    cmd = ScimPushCommand()
                    exec_kwargs: dict[str, Any] = {
                        "source": str(source),
                        "dry_run": False,
                        "auto_approve": "off",
                    }
                    if creds_record_uid:
                        exec_kwargs["record"] = str(creds_record_uid)
                    return cmd.execute(
                        params,
                        target=str(node_id),
                        **exec_kwargs,
                    )

                try:
                    self._with_keeper_session_refresh(_run_push)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"SCIM push failed: {type(exc).__name__}: {exc}",
                        uid_ref=uid_key,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify SCIM endpoint vault record (URL + Bearer token), "
                            "source (google|ad|record), and scim push prerequisites"
                        ),
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=uid_key,
                        keeper_uid=str(node_id),
                        action="update",
                        details={"push_type": push_type, "source": source},
                    )
                )
                continue

            rt = change.resource_type
            payload_after = dict(change.after) if change.after else {}

            if rt == "scim_node":
                node_name = str(payload_after.get("name") or change.uid_ref or "")
                parent_ref = str(payload_after.get("parent_uid_ref") or "").strip()
                if parent_ref.casefold() == "node.root":
                    parent_ref = ""
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create" if change.kind == ChangeKind.CREATE else "update",
                            details={"dry_run": True, "node_name": node_name},
                        )
                    )
                    continue
                if change.kind is not ChangeKind.CREATE:
                    raise CapabilityError(
                        reason="keeper-scim.v1 node update is not wired to Commander yet",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "manage node renames/moves via Keeper Admin Console or "
                            "Commander enterprise-node verbs"
                        ),
                    )
                try:
                    from keepercommander.commands.enterprise import EnterpriseNodeCommand
                except ImportError as exc:
                    raise CapabilityError(
                        reason=(
                            "keeper-scim.v1 node create requires Commander EnterpriseNodeCommand"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "upgrade keepercommander to a version that provides "
                            "keepercommander.commands.enterprise.EnterpriseNodeCommand"
                        ),
                    ) from exc
                _ensure_keepercommander_version_for_apply()
                _scim_node_kwargs: dict[str, Any] = {
                    "node": [node_name],
                    "add": True,
                    "name": node_name,
                    "force": True,
                }
                if parent_ref:
                    _scim_node_kwargs["parent"] = parent_ref

                def _run_scim_node_op() -> Any:
                    from keepercommander import api as _api_scim_node_qe

                    _params = self._get_keeper_params()
                    _api_scim_node_qe.query_enterprise(_params)
                    _ent_snapshot = getattr(_params, "enterprise", None)
                    if not isinstance(_ent_snapshot, dict):
                        raise CapabilityError(
                            reason=(
                                "keeper-scim.v1 node create requires Commander enterprise snapshot "
                                "(params.enterprise unset after api.query_enterprise)"
                            ),
                            uid_ref=change.uid_ref or "",
                            resource_type=rt,
                            next_action=(
                                "ensure login is enterprise administrator and rerun sync "
                                "(Commander enterprise-node prerequisites)"
                            ),
                        )

                    _cmd = EnterpriseNodeCommand()
                    return _cmd.execute(_params, **_scim_node_kwargs)

                try:
                    self._with_keeper_session_refresh(_run_scim_node_op)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"SCIM node create failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action="verify Commander enterprise admin permissions, then retry",
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="create",
                        details={"node_name": node_name, "commander": "enterprise-node"},
                    )
                )
                continue

            if rt == "scim_team":
                team_name = str(payload_after.get("name") or change.uid_ref or change.title or "")
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create" if change.kind == ChangeKind.CREATE else "update",
                            details={"dry_run": True, "team_name": team_name},
                        )
                    )
                    continue
                try:
                    from keepercommander.commands.enterprise import EnterpriseTeamCommand
                except ImportError as exc:
                    raise CapabilityError(
                        reason=(
                            "keeper-scim.v1 team apply requires Commander EnterpriseTeamCommand"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "upgrade keepercommander to a version that provides "
                            "keepercommander.commands.enterprise.EnterpriseTeamCommand"
                        ),
                    ) from exc
                _ensure_keepercommander_version_for_apply()
                _is_scim_team_create = change.kind is ChangeKind.CREATE

                if _is_scim_team_create:

                    def _run_scim_team_op() -> Any:
                        _params = self._get_keeper_params()
                        _cmd = EnterpriseTeamCommand()
                        return _cmd.execute(
                            _params,
                            add=True,
                            team=[team_name],
                            team_name=team_name,
                            restrict_edit=_commander_on_off(
                                bool(payload_after.get("restrict_edit"))
                            ),
                            restrict_share=_commander_on_off(
                                bool(payload_after.get("restrict_share"))
                            ),
                            restrict_view=_commander_on_off(
                                bool(payload_after.get("restrict_view"))
                            ),
                        )
                else:
                    _team_id = str(
                        (change.before or {}).get("name")
                        or change.keeper_uid
                        or change.uid_ref
                        or team_name
                    )
                    _scim_team_upd: dict[str, Any] = {"team": [_team_id], "force": True}
                    _new_team_name = payload_after.get("name")
                    if _new_team_name and _new_team_name != (change.before or {}).get("name"):
                        _scim_team_upd["name"] = str(_new_team_name)
                    for _flag in ("restrict_edit", "restrict_share", "restrict_view"):
                        if _flag in payload_after:
                            _scim_team_upd[_flag] = _commander_on_off(bool(payload_after[_flag]))

                    def _run_scim_team_op() -> Any:
                        _params = self._get_keeper_params()
                        _cmd = EnterpriseTeamCommand()
                        return _cmd.execute(_params, **_scim_team_upd)

                try:
                    self._with_keeper_session_refresh(_run_scim_team_op)
                except CapabilityError:
                    raise
                except Exception as exc:
                    _op = "create" if _is_scim_team_create else "update"
                    raise CapabilityError(
                        reason=f"SCIM team {_op} failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action="verify Commander enterprise admin permissions, then retry",
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="create" if _is_scim_team_create else "update",
                        details={"team_name": team_name, "commander": "enterprise-team"},
                    )
                )
                continue

            if rt == "scim_role":
                role_name = str(payload_after.get("name") or change.uid_ref or "")
                node_ref = str(payload_after.get("node_uid_ref") or "")
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create" if change.kind == ChangeKind.CREATE else "update",
                            details={"dry_run": True, "role_name": role_name},
                        )
                    )
                    continue
                if any(
                    bool(payload_after.get(k))
                    for k in ("enforce_2fa", "restrict_vault_ip", "disable_offline_mode")
                ):
                    raise CapabilityError(
                        reason=(
                            "keeper-scim.v1 role apply does not wire enforcement flags "
                            "(enforce_2fa / restrict_vault_ip / disable_offline_mode) to "
                            "Commander EnterpriseRoleCommand yet"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "use `keeper enterprise-role` enforcements or Admin Console, "
                            "or extend CommanderCliProvider.apply_scim_plan to map flags"
                        ),
                    )
                try:
                    from keepercommander.commands.enterprise import EnterpriseRoleCommand
                except ImportError as exc:
                    raise CapabilityError(
                        reason=(
                            "keeper-scim.v1 role apply requires Commander EnterpriseRoleCommand"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "upgrade keepercommander to a version that provides "
                            "keepercommander.commands.enterprise.EnterpriseRoleCommand"
                        ),
                    ) from exc
                _ensure_keepercommander_version_for_apply()
                _is_scim_role_create = change.kind is ChangeKind.CREATE
                _scim_role_kwargs: dict[str, Any] = {
                    "role": [role_name],
                    "force": True,
                }
                if _is_scim_role_create:
                    _scim_role_kwargs["add"] = True
                    if node_ref:
                        _scim_role_kwargs["node"] = node_ref
                    _new_user = payload_after.get("new_user_inherit")
                    if _new_user is not None:
                        _scim_role_kwargs["new_user"] = "on" if _new_user else "off"
                else:
                    _role_id = str(
                        (change.before or {}).get("name")
                        or change.keeper_uid
                        or change.uid_ref
                        or role_name
                    )
                    _scim_role_kwargs["role"] = [_role_id]
                    _new_role_name = payload_after.get("name")
                    if _new_role_name and _new_role_name != (change.before or {}).get("name"):
                        _scim_role_kwargs["name"] = str(_new_role_name)

                def _run_scim_role_op() -> Any:
                    _params = self._get_keeper_params()
                    _cmd = EnterpriseRoleCommand()
                    return _cmd.execute(_params, **_scim_role_kwargs)

                try:
                    self._with_keeper_session_refresh(_run_scim_role_op)
                except CapabilityError:
                    raise
                except Exception as exc:
                    _op = "create" if _is_scim_role_create else "update"
                    raise CapabilityError(
                        reason=f"SCIM role {_op} failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action="verify Commander enterprise admin permissions, then retry",
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="create" if _is_scim_role_create else "update",
                        details={"role_name": role_name, "commander": "enterprise-role"},
                    )
                )
                continue

            if rt == "scim_user":
                email = str(payload_after.get("email") or change.uid_ref or "")
                role_refs = list(payload_after.get("role_uid_refs") or [])
                team_refs = list(payload_after.get("team_uid_refs") or [])
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create" if change.kind == ChangeKind.CREATE else "update",
                            details={"dry_run": True, "email": email},
                        )
                    )
                    continue
                if role_refs or team_refs:
                    raise CapabilityError(
                        reason=(
                            "keeper-scim.v1 user apply does not wire role_uid_refs / team_uid_refs "
                            "to Commander EnterpriseUserCommand on live apply "
                            "(invite path cannot attach roles/teams atomically)"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "provision the user via this row, then assign roles/teams with "
                            "`keeper enterprise-user --add-role/--add-team` or Admin Console"
                        ),
                    )
                display_name = payload_after.get("display_name")
                node_hint = str(payload_after.get("node_uid_ref") or "")
                if change.kind is not ChangeKind.CREATE:
                    raise CapabilityError(
                        reason="keeper-scim.v1 user update is not wired to Commander yet",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "use `keeper enterprise-user` management verbs or Admin Console"
                        ),
                    )
                try:
                    from keepercommander.commands.enterprise import EnterpriseUserCommand
                except ImportError as exc:
                    raise CapabilityError(
                        reason=(
                            "keeper-scim.v1 user invite requires Commander EnterpriseUserCommand"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "upgrade keepercommander to a version that provides "
                            "keepercommander.commands.enterprise.EnterpriseUserCommand"
                        ),
                    ) from exc
                _ensure_keepercommander_version_for_apply()
                _scim_user_kwargs: dict[str, Any] = {
                    "add": True,
                    "invite": True,
                    "email": [email],
                    "force": True,
                }
                if display_name:
                    _scim_user_kwargs["displayname"] = str(display_name)
                if node_hint:
                    _scim_user_kwargs["node"] = node_hint

                def _run_scim_user_invite() -> Any:
                    _params = self._get_keeper_params()
                    _cmd = EnterpriseUserCommand()
                    return _cmd.execute(_params, **_scim_user_kwargs)

                try:
                    self._with_keeper_session_refresh(_run_scim_user_invite)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"SCIM user invite failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action="verify Commander enterprise admin permissions, then retry",
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="create",
                        details={"email": email, "commander": "enterprise-user"},
                    )
                )
                continue

            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="create" if change.kind == ChangeKind.CREATE else "update",
                        details={"dry_run": True},
                    )
                )
                continue
            raise CapabilityError(
                reason=(
                    f"keeper-scim.v1 apply: unsupported resource_type {change.resource_type!r} "
                    "for CommanderCliProvider.apply_scim_plan"
                ),
                uid_ref=change.uid_ref or "",
                resource_type=change.resource_type,
                next_action=(
                    "limit manifest rows to scim_push and structural scim_* kinds, "
                    "or extend CommanderCliProvider.apply_scim_plan"
                ),
            )
        return outcomes

    def apply_enterprise_plan(
        self,
        plan: Plan,
        manifest: Any,
        *,
        dry_run: bool = False,
    ) -> list[ApplyOutcome]:
        """Apply ``keeper-enterprise.v1`` through Commander enterprise commands."""
        del manifest

        outcomes: list[ApplyOutcome] = []
        for change in plan.ordered():
            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or "blocked"},
                    )
                )
                continue

            if change.kind in (ChangeKind.NOOP, ChangeKind.SKIP):
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details={"dry_run": dry_run, "skipped": change.kind.value},
                    )
                )
                continue

            rt = change.resource_type
            payload_after = dict(change.after) if change.after else {}

            if rt == "enterprise_team":
                team_name = str(payload_after.get("name") or change.uid_ref or change.title or "")
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create" if change.kind is ChangeKind.CREATE else "update",
                            details={"dry_run": True, "team_name": team_name},
                        )
                    )
                    continue
                try:
                    from keepercommander.commands.enterprise import EnterpriseTeamCommand
                except ImportError as exc:
                    raise CapabilityError(
                        reason=(
                            "keeper-enterprise.v1 team apply requires Commander "
                            "EnterpriseTeamCommand"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "upgrade keepercommander to a version that provides "
                            "keepercommander.commands.enterprise.EnterpriseTeamCommand"
                        ),
                    ) from exc

                _ensure_keepercommander_version_for_apply()
                _is_team_create = change.kind is ChangeKind.CREATE

                if _is_team_create:

                    def _run_team_op() -> Any:
                        _params = self._get_keeper_params()
                        _cmd = EnterpriseTeamCommand()
                        return _cmd.execute(
                            _params,
                            add=True,
                            team=[team_name],
                            team_name=team_name,
                            restrict_edit=_commander_on_off(
                                bool(payload_after.get("restrict_edit"))
                            ),
                            restrict_share=_commander_on_off(
                                bool(payload_after.get("restrict_share"))
                            ),
                            restrict_view=_commander_on_off(
                                bool(payload_after.get("restrict_view"))
                            ),
                        )
                else:
                    _team_id = str(
                        (change.before or {}).get("name")
                        or change.keeper_uid
                        or change.uid_ref
                        or team_name
                    )
                    _upd_kwargs: dict[str, Any] = {"team": [_team_id], "force": True}
                    _new_name = payload_after.get("name")
                    if _new_name and _new_name != (change.before or {}).get("name"):
                        _upd_kwargs["name"] = str(_new_name)
                    for _flag in ("restrict_edit", "restrict_share", "restrict_view"):
                        if _flag in payload_after:
                            _upd_kwargs[_flag] = _commander_on_off(bool(payload_after[_flag]))

                    def _run_team_op() -> Any:
                        _params = self._get_keeper_params()
                        _cmd = EnterpriseTeamCommand()
                        return _cmd.execute(_params, **_upd_kwargs)

                try:
                    self._with_keeper_session_refresh(_run_team_op)
                except CapabilityError:
                    raise
                except Exception as exc:
                    _op = "create" if _is_team_create else "update"
                    raise CapabilityError(
                        reason=f"Enterprise team {_op} failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action="verify Commander enterprise admin permissions, then retry",
                    ) from exc

                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="create" if _is_team_create else "update",
                        details={"team_name": team_name},
                    )
                )
                continue

            if rt == "enterprise_user":
                email = str(payload_after.get("email") or change.uid_ref or "")
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create" if change.kind is ChangeKind.CREATE else "update",
                            details={"dry_run": True, "email": email},
                        )
                    )
                    continue
                raise CapabilityError(
                    reason=(
                        "keeper-enterprise.v1 user rows are not implemented on "
                        "CommanderCliProvider yet"
                    ),
                    uid_ref=change.uid_ref or "",
                    resource_type=rt,
                    next_action=(
                        "use Commander enterprise-user-management verbs "
                        "(invite/provision) or Keeper Admin Console"
                    ),
                )

            if rt == "enterprise_role":
                role_name = str(payload_after.get("name") or change.uid_ref or "")
                node_ref = str(payload_after.get("node_uid_ref") or "")
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create" if change.kind is ChangeKind.CREATE else "update",
                            details={"dry_run": True, "role_name": role_name},
                        )
                    )
                    continue
                try:
                    from keepercommander.commands.enterprise import EnterpriseRoleCommand
                except ImportError as exc:
                    raise CapabilityError(
                        reason=(
                            "keeper-enterprise.v1 role apply requires Commander "
                            "EnterpriseRoleCommand"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "upgrade keepercommander to a version that provides "
                            "keepercommander.commands.enterprise.EnterpriseRoleCommand"
                        ),
                    ) from exc
                _ensure_keepercommander_version_for_apply()
                _is_role_create = change.kind is ChangeKind.CREATE
                _role_kwargs: dict[str, Any] = {
                    "role": [role_name],
                    "force": True,
                }
                if _is_role_create:
                    _role_kwargs["add"] = True
                    if node_ref:
                        _role_kwargs["node"] = node_ref
                    _new_user = payload_after.get("new_user_inherit")
                    if _new_user is not None:
                        _role_kwargs["new_user"] = "on" if _new_user else "off"
                else:
                    _role_id = str(
                        (change.before or {}).get("name")
                        or change.keeper_uid
                        or change.uid_ref
                        or role_name
                    )
                    _role_kwargs["role"] = [_role_id]
                    _new_role_name = payload_after.get("name")
                    if _new_role_name and _new_role_name != (change.before or {}).get("name"):
                        _role_kwargs["name"] = str(_new_role_name)

                def _run_role_op() -> Any:
                    _params = self._get_keeper_params()
                    _cmd = EnterpriseRoleCommand()
                    return _cmd.execute(_params, **_role_kwargs)

                try:
                    self._with_keeper_session_refresh(_run_role_op)
                except CapabilityError:
                    raise
                except Exception as exc:
                    _op = "create" if _is_role_create else "update"
                    raise CapabilityError(
                        reason=f"Enterprise role {_op} failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action="verify Commander enterprise admin permissions, then retry",
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="create" if _is_role_create else "update",
                        details={"role_name": role_name},
                    )
                )
                continue

            if rt == "enterprise_node":
                node_name = str(payload_after.get("name") or change.uid_ref or "")
                parent_ref = str(payload_after.get("parent_uid_ref") or "")
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create" if change.kind is ChangeKind.CREATE else "update",
                            details={"dry_run": True, "node_name": node_name},
                        )
                    )
                    continue
                if change.kind is not ChangeKind.CREATE:
                    raise CapabilityError(
                        reason="keeper-enterprise.v1 node update is not wired to Commander yet",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "manage node renames/moves via Keeper Admin Console or "
                            "Commander enterprise-node verbs"
                        ),
                    )
                try:
                    from keepercommander.commands.enterprise import EnterpriseNodeCommand
                except ImportError as exc:
                    raise CapabilityError(
                        reason=(
                            "keeper-enterprise.v1 node create requires Commander "
                            "EnterpriseNodeCommand"
                        ),
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action=(
                            "upgrade keepercommander to a version that provides "
                            "keepercommander.commands.enterprise.EnterpriseNodeCommand"
                        ),
                    ) from exc
                _ensure_keepercommander_version_for_apply()
                _node_kwargs: dict[str, Any] = {
                    "node": [node_name],
                    "add": True,
                    "name": node_name,
                    "force": True,
                }
                if parent_ref:
                    _node_kwargs["parent"] = parent_ref

                def _run_node_op() -> Any:
                    _params = self._get_keeper_params()
                    _cmd = EnterpriseNodeCommand()
                    return _cmd.execute(_params, **_node_kwargs)

                try:
                    self._with_keeper_session_refresh(_run_node_op)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"Enterprise node create failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or "",
                        resource_type=rt,
                        next_action="verify Commander enterprise admin permissions, then retry",
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="create",
                        details={"node_name": node_name},
                    )
                )
                continue

            if rt in {"enterprise_enforcement", "enterprise_alias"}:
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=change.keeper_uid or "",
                            action="noop",
                            details={"dry_run": True, "resource_type": rt},
                        )
                    )
                    continue
                raise CapabilityError(
                    reason=f"keeper-enterprise.v1 {rt} apply is not wired to Commander yet",
                    uid_ref=change.uid_ref or "",
                    resource_type=rt,
                    next_action=(
                        "manage enforcements and aliases via Keeper Admin Console "
                        "until declarative hooks land"
                    ),
                )

            if rt in _ENTERPRISE_CONFIG_RESOURCE_TYPES:
                raise CapabilityError(
                    reason=_ENTERPRISE_CONFIG_UNSUPPORTED_REASON,
                    uid_ref=change.uid_ref or "",
                    resource_type=rt,
                    next_action=(
                        "keep enterprise-config policy rows classified upstream-gap until "
                        "Commander ships a policy writer such as `enterprise-info edit/set`"
                    ),
                )

            details: dict[str, Any] = {"dry_run": dry_run, "skipped": rt}
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                    details=details,
                )
            )

        return outcomes

    def apply_governance_transfer_plan(
        self,
        plan: Plan,
        *,
        dry_run: bool = False,
    ) -> list[ApplyOutcome]:
        """Apply governance ownership-transfer rows through Commander."""

        outcomes: list[ApplyOutcome] = []
        for change in _all_plan_changes(plan):
            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or "blocked"},
                    )
                )
                continue
            if change.resource_type != GOVERNANCE_TRANSFER_RESOURCE:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details={"dry_run": dry_run, "skipped": change.resource_type},
                    )
                )
                continue
            if change.kind not in (ChangeKind.CREATE, ChangeKind.UPDATE):
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details={"dry_run": dry_run, "skipped": change.kind.value},
                    )
                )
                continue

            transfer = governance_transfer_from_change(change)
            if transfer.object_type != "record":
                raise CapabilityError(
                    reason=_GOVERNANCE_FOLDER_TRANSFER_UNSUPPORTED_REASON,
                    uid_ref=change.uid_ref or transfer.uid_ref or "",
                    resource_type=change.resource_type,
                    next_action=(
                        "transfer record ownership with `share-record --action owner`; "
                        "manage folder ownership manually until Commander exposes a folder "
                        "ownership-transfer verb"
                    ),
                )
            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or transfer.uid_ref or "",
                        keeper_uid=transfer.object_uid,
                        action="update",
                        details={
                            "dry_run": True,
                            "command": [
                                "share-record",
                                "--action",
                                "owner",
                                "--email",
                                transfer.target_user,
                                transfer.object_uid,
                            ],
                        },
                    )
                )
                continue

            try:
                from keepercommander.commands.register import ShareRecordCommand
            except (ImportError, AttributeError) as exc:
                raise CapabilityError(
                    reason=f"Commander ShareRecordCommand is unavailable: {exc}",
                    uid_ref=change.uid_ref or transfer.uid_ref or "",
                    resource_type=change.resource_type,
                    next_action=(
                        "upgrade keepercommander to a version that provides "
                        "keepercommander.commands.register.ShareRecordCommand"
                    ),
                ) from exc

            def _run_transfer() -> Any:
                params = self._get_keeper_params()
                command = ShareRecordCommand()
                if not hasattr(command, "execute"):
                    raise CapabilityError(
                        reason="Commander ShareRecordCommand has no execute(params, **kwargs) API",
                        uid_ref=change.uid_ref or transfer.uid_ref or "",
                        resource_type=change.resource_type,
                        next_action=(
                            "need ShareRecordCommand.execute(params, record, email, action, force)"
                        ),
                    )
                return command.execute(
                    params,
                    record=transfer.object_uid,
                    email=[transfer.target_user],
                    action="owner",
                    force=True,
                    recursive=transfer.recursive,
                )

            try:
                self._with_keeper_session_refresh(_run_transfer)
            except CapabilityError:
                raise
            except Exception as exc:
                raise CapabilityError(
                    reason=f"Governance record ownership transfer failed: {type(exc).__name__}: {exc}",
                    uid_ref=change.uid_ref or transfer.uid_ref or "",
                    resource_type=change.resource_type,
                    next_action=(
                        "verify source ownership/share-admin rights and target user acceptance, "
                        "then retry"
                    ),
                ) from exc

            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or transfer.uid_ref or "",
                    keeper_uid=transfer.object_uid,
                    action="update",
                    details={"dry_run": False, "target_user": transfer.target_user},
                )
            )
        return outcomes

    def _apply_role_enforcements(
        self,
        role_identifier: str,
        enforcement_flags: list[str],
    ) -> None:
        try:
            from keepercommander.commands.enterprise import EnterpriseRoleCommand
        except (ImportError, AttributeError) as exc:
            raise CapabilityError(
                reason=f"Commander EnterpriseRoleCommand is unavailable: {exc}",
                next_action=(
                    "upgrade keepercommander to a version that provides "
                    "`enterprise-role --enforcement`"
                ),
            ) from exc

        def run_once() -> Any:
            params = self._get_keeper_params()
            command = EnterpriseRoleCommand()
            return command.execute(
                params,
                role=[role_identifier],
                enforcements=list(enforcement_flags),
                force=True,
            )

        try:
            self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"role enforcement apply failed: {type(exc).__name__}: {exc}",
                next_action=(
                    "verify the target role exists and the Commander session can run "
                    "`keeper enterprise-role --enforcement`"
                ),
                context={"role": role_identifier, "enforcements": enforcement_flags},
            ) from exc
