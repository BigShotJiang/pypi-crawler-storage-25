"""Mixin — transport resource family of _TransportMixin.

Private implementation module. Not a public API.
"""

from __future__ import annotations

import contextlib
import io
import json
import logging
import os
import subprocess
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from dsk.core.errors import CapabilityError
from dsk.providers._commander_cli_helpers import _parse_pam_project_args
from dsk.providers._commander_mixins.transport_service_mode import _ServiceModeTransportMixin
from dsk.providers.commander_cli import (
    _IN_PROCESS_SHARE_FAILURE_MARKERS,
    _IN_PROCESS_VAULT_COMMANDS,
    _SILENT_FAIL_COMMANDS,
    _SILENT_FAIL_MARKERS,
    _is_retryable_keeper_session_error,
    _is_retryable_keeper_session_text,
)

if TYPE_CHECKING:
    pass


def _write_command_result(buffer: io.StringIO, result: Any) -> None:
    """Write Commander return values into the capture buffer without process stdout."""

    if isinstance(result, bytes):
        buffer.write(result.decode("utf-8", errors="replace"))
    elif isinstance(result, str):
        buffer.write(result)
    elif isinstance(result, (dict, list)):
        buffer.write(json.dumps(result))


class _TransportMixin(_ServiceModeTransportMixin):
    """Method carrier — transport resource family."""

    if TYPE_CHECKING:
        # Instance attrs from CommanderCliProvider.__init__
        _bin: str
        _bin_path: str | None
        _config: str | None
        _folder_uid: str | None
        _keeper_login_attempted: bool
        _keeper_params: Any | None
        _ksm_app_rows_cache: list[dict[str, str]] | None
        _manifest_name: str | None
        _manifest_source: dict[str, Any]
        _password: str | None
        _service_api_key: str | None
        _service_autostart: bool
        _service_client: Any | None
        _service_mode: bool
        _service_ready: bool
        _service_start_timeout: float
        _service_timeout: int
        _service_url: str
        last_resolved_folder_uid: str | None
        last_resolved_users_folder_uid: str | None

    def _run_enterprise_info_cmd(self, args: list[str], *, command: str) -> str:
        base = [self._bin]
        if self._config:
            base += ["--config", self._config]
        env = os.environ.copy()
        if self._password:
            env["KEEPER_PASSWORD"] = self._password
        try:
            result = subprocess.run(
                base + args,
                check=False,
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,
                env=env,
                timeout=60,
            )
        except subprocess.TimeoutExpired as exc:
            raise CapabilityError(
                reason=f"keeper {command} timed out",
                next_action="run `keeper enterprise-info` and confirm the Commander session is unlocked",
            ) from exc
        if result.returncode != 0:
            raise CapabilityError(
                reason=f"keeper {command} failed (rc={result.returncode})",
                context={"stdout": result.stdout[-6000:], "stderr": result.stderr[-4000:]},
                next_action="inspect the Commander output above and retry",
            )
        return result.stdout

    def _run_cmd(self, args: list[str]) -> str:
        if self._service_mode:
            return self._run_service_mode_cmd(args)
        # `pam project import` / `pam project extend` can't run reliably under
        # `keeper --batch-mode` in subprocess: persistent-login works for
        # sibling commands like `pam gateway list`, but for these two the
        # Commander binary drops back to an interactive `Email:` prompt even
        # with a warmed config + KEEPER_PASSWORD set. Root cause: the bundled
        # macOS binary at /usr/local/bin/keeper is 17.1.14 (doesn't know
        # `pam project extend`) and `python3 -m keepercommander` 18.0.0 in
        # subprocess can't resume the session for this specific subcommand.
        # In-process invocation via the Commander Python API works cleanly
        # once we've done one api.login() with full TOTP, so we delegate.
        if (
            len(args) >= 3
            and args[0] == "pam"
            and args[1] == "project"
            and args[2] in {"import", "extend"}
        ):
            return self._run_pam_project_in_process(args)
        if (
            len(args) >= 3
            and args[0] == "pam"
            and args[1] == "gateway"
            and args[2] in {"new", "edit", "remove"}
        ):
            return self._run_pam_gateway_in_process(args)
        if args[:3] == ["pam", "rotation", "edit"]:
            return self._run_pam_rotation_edit_in_process(args)
        if args[:3] == ["pam", "rotation", "list"]:
            return self._run_pam_list_in_process(args)
        if args in (
            ["pam", "gateway", "list", "--format", "json"],
            ["pam", "config", "list", "--format", "json"],
        ):
            return self._run_pam_list_in_process(args)
        # ``ls <FOLDER_UID> --format json`` / ``get <UID> --format json`` are
        # the read-side of every discover() round-trip. Subprocess execution
        # against ``/usr/local/bin/keeper`` uses ``~/.keeper/commander-config.json``
        # which can hold a stale device_token (e.g. on dev workstations) and
        # then fails to resync just-applied records on a post-apply re-plan
        # — even though the in-process Commander 18.0.0 session that ran
        # the apply itself is fresh. Route through the same in-process
        # session when login config is detectable so discover() shares the
        # apply-time auth context. Falls through to subprocess when no
        # in-process login is configured (plain installs).
        if (
            len(args) >= 2
            and args[0] == "ls"
            and "--format" in args
            and args[args.index("--format") + 1 : args.index("--format") + 2] == ["json"]
            and self._can_attempt_in_process_login()
        ):
            return self._run_ls_in_process(args)
        if (
            len(args) >= 2
            and args[0] == "get"
            and "--format" in args
            and args[args.index("--format") + 1 : args.index("--format") + 2] == ["json"]
            and self._can_attempt_in_process_login()
        ):
            return self._run_record_get_in_process(args)
        if args and args[0] in _IN_PROCESS_VAULT_COMMANDS and self._can_attempt_in_process_login():
            return self._run_vault_command_in_process(args)

        # --batch-mode suppresses interactive prompts (password, 2FA,
        # confirmations). stdin=DEVNULL is belt-and-braces — if Commander ever
        # tries to read stdin despite --batch-mode we want EOF, not a hang.
        base = [self._bin, "--batch-mode"]
        if self._config:
            base += ["--config", self._config]
        env = os.environ.copy()
        if self._password:
            env["KEEPER_PASSWORD"] = self._password
        result = None
        for attempt in range(2):
            try:
                result = subprocess.run(
                    base + args,
                    check=False,
                    capture_output=True,
                    text=True,
                    stdin=subprocess.DEVNULL,
                    env=env,
                    timeout=self._service_timeout,
                )
            except subprocess.TimeoutExpired as exc:
                raise CapabilityError(
                    reason=f"keeper {' '.join(args)} timed out after {self._service_timeout}s",
                    next_action="inspect Commander session health and retry",
                ) from exc
            if result.returncode == 0 or attempt == 1:
                break
            if not _is_retryable_keeper_session_text(result.stdout, result.stderr):
                break
        assert result is not None
        if result.returncode != 0:
            raise CapabilityError(
                reason=f"keeper {' '.join(args)} failed (rc={result.returncode})",
                context={"stdout": result.stdout[-6000:], "stderr": result.stderr[-4000:]},
                next_action="inspect the Commander output above and retry",
            )
        stderr = (result.stderr or "").strip()
        if self._is_silent_failure(args, stdout=result.stdout, stderr=stderr):
            stderr_head = stderr[:200]
            raise CapabilityError(
                reason=f"keeper {' '.join(args)} silent-fail: {stderr_head}",
                context={"stdout": result.stdout[-400:], "stderr": result.stderr[-400:]},
                next_action="inspect the Commander output above and retry",
            )
        return result.stdout

    @staticmethod
    def _is_silent_failure(args: list[str], *, stdout: str, stderr: str) -> bool:
        if stdout.strip() or not stderr:
            return False
        if not any(args[: len(prefix)] == list(prefix) for prefix in _SILENT_FAIL_COMMANDS):
            return False
        return any(marker in stderr for marker in _SILENT_FAIL_MARKERS)

    def _run_vault_command_in_process(self, args: list[str]) -> str:
        """Run vault/folder/share commands through the authenticated Commander API."""
        stdout = ""
        stderr = ""

        def command_for_name(command_name: str) -> Any:
            if command_name == "mkdir":
                from keepercommander.commands.folder import FolderMakeCommand

                return FolderMakeCommand()
            if command_name == "mv":
                from keepercommander.commands.folder import FolderMoveCommand

                return FolderMoveCommand()
            if command_name == "rmdir":
                from keepercommander.commands.folder import FolderRemoveCommand

                return FolderRemoveCommand()
            if command_name == "rm":
                from keepercommander.commands.record import RecordRemoveCommand

                return RecordRemoveCommand()
            if command_name == "share-folder":
                from keepercommander.commands.register import ShareFolderCommand

                return ShareFolderCommand()
            if command_name == "share-record":
                from keepercommander.commands.register import ShareRecordCommand

                return ShareRecordCommand()
            raise CapabilityError(
                reason=f"unsupported in-process Commander command {command_name!r}",
                next_action="fall back to a supported Commander CLI command",
            )

        def run_once() -> str:
            nonlocal stdout, stderr
            from keepercommander import api

            params = self._get_keeper_params()
            command = command_for_name(args[0])
            parser = command.get_parser()
            # Keeper UIDs are 22-char base64url strings and may start with '-'.
            # Argparse would treat any dash-prefixed token as an option flag,
            # causing "required: uid" errors. Detect 22-char dash-prefixed tokens
            # (UID pattern) and insert '--' end-of-options marker before them.
            _KEEPER_UID_LEN = 22
            _share_argv: list[str] = []
            for _vi, _tok in enumerate(args[1:]):
                if _tok == "--":
                    _share_argv.extend(args[1 + _vi :])
                    break
                if _tok.startswith("-") and len(_tok) == _KEEPER_UID_LEN:
                    _share_argv.append("--")
                    _share_argv.extend(args[1 + _vi :])
                    break
                _share_argv.append(_tok)
            else:
                _share_argv = list(args[1:])
            parsed = vars(parser.parse_args(_share_argv))
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            err_log_handler = logging.StreamHandler(buf_err)
            err_log_handler.setLevel(logging.WARNING)
            root_logger = logging.getLogger()
            root_logger.addHandler(err_log_handler)
            try:
                api.sync_down(params)
                with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                    result = command.execute(params, **parsed)
                    _write_command_result(buf_out, result)
            finally:
                stdout = buf_out.getvalue()
                stderr = buf_err.getvalue()
                root_logger.removeHandler(err_log_handler)
            if self._in_process_share_command_failed(args, stderr=stderr):
                raise CapabilityError(
                    reason=f"in-process keeper {' '.join(args)} reported unresolved share target",
                    context={"stdout": stdout[-6000:], "stderr": stderr[-4000:]},
                    next_action=(
                        "verify the grantee is an active Keeper user/contact and has accepted "
                        "any pending invitation, then re-run plan/apply"
                    ),
                )
            return stdout

        try:
            return self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process keeper {' '.join(args)} failed: {type(exc).__name__}: {exc}",
                context={"stdout": stdout[-6000:], "stderr": stderr[-4000:]},
                next_action="inspect Commander output above and retry",
            ) from exc

    @staticmethod
    def _in_process_share_command_failed(args: list[str], *, stderr: str) -> bool:
        if not stderr.strip() or not args or args[0] not in {"share-folder", "share-record"}:
            return False
        if _TransportMixin._share_command_action(args) != "grant":
            return False
        return any(marker in stderr for marker in _IN_PROCESS_SHARE_FAILURE_MARKERS)

    @staticmethod
    def _share_command_action(args: list[str]) -> str | None:
        for index, token in enumerate(args):
            if token in {"-a", "--action"} and index + 1 < len(args):
                return args[index + 1]
            if token.startswith("--action="):
                return token.split("=", 1)[1]
        return None

    def _run_pam_list_in_process(self, args: list[str]) -> str:
        """Run PAM list commands in-process so they share refreshable auth."""
        stdout = ""
        stderr = ""

        def run_once() -> str:
            nonlocal stdout, stderr
            params = self._get_keeper_params()
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            err_log_handler = logging.StreamHandler(buf_err)
            err_log_handler.setLevel(logging.WARNING)
            root_logger = logging.getLogger()
            root_logger.addHandler(err_log_handler)
            result: Any = None
            try:
                from keepercommander import api

                api.sync_down(params)
                with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                    if args[:3] == ["pam", "gateway", "list"]:
                        from keepercommander.commands.discoveryrotation import (
                            PAMGatewayListCommand,
                        )

                        result = PAMGatewayListCommand().execute(params, format="json")
                    elif args[:3] == ["pam", "config", "list"]:
                        from keepercommander.commands.discoveryrotation import (
                            PAMConfigurationListCommand,
                        )

                        result = PAMConfigurationListCommand().execute(params, format="json")
                    else:
                        from keepercommander.commands.discoveryrotation import (
                            PAMListRecordRotationCommand,
                        )

                        cmd = PAMListRecordRotationCommand()
                        parsed = vars(cmd.get_parser().parse_args(args[3:]))
                        result = cmd.execute(params, **parsed)
            finally:
                stdout = buf_out.getvalue()
                stderr = buf_err.getvalue()
                root_logger.removeHandler(err_log_handler)
            return result if isinstance(result, str) and result else stdout

        try:
            return self._with_keeper_session_refresh(run_once)
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process keeper {' '.join(args)} failed: {type(exc).__name__}: {exc}",
                context={"stdout": stdout[-6000:], "stderr": stderr[-4000:]},
                next_action="inspect the Commander output above and retry",
            ) from exc

    def _run_pam_gateway_in_process(self, args: list[str]) -> str:
        """Run ``pam gateway new/edit/remove`` via Commander's command classes."""
        subcmd = args[2]
        stdout = ""
        stderr = ""

        def command_for_subcmd() -> Any:
            if subcmd == "new":
                from keepercommander.commands.discoveryrotation import (
                    PAMCreateGatewayCommand,
                )

                return PAMCreateGatewayCommand()
            if subcmd == "edit":
                from keepercommander.commands.discoveryrotation import (
                    PAMEditGatewayCommand,
                )

                return PAMEditGatewayCommand()
            if subcmd == "remove":
                from keepercommander.commands.discoveryrotation import (
                    PAMGatewayRemoveCommand,
                )

                return PAMGatewayRemoveCommand()
            raise CapabilityError(
                reason=f"unsupported PAM gateway subcommand {subcmd!r}",
                next_action="use pam gateway new, edit, or remove",
            )

        def run_once() -> str:
            nonlocal stdout, stderr
            from keepercommander import api

            params = self._get_keeper_params()
            command = command_for_subcmd()
            parsed = vars(command.get_parser().parse_args(args[3:]))
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            err_log_handler = logging.StreamHandler(buf_err)
            err_log_handler.setLevel(logging.WARNING)
            root_logger = logging.getLogger()
            root_logger.addHandler(err_log_handler)
            try:
                api.sync_down(params)
                with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                    result = command.execute(params, **parsed)
                    _write_command_result(buf_out, result)
            finally:
                stdout = buf_out.getvalue()
                stderr = buf_err.getvalue()
                root_logger.removeHandler(err_log_handler)
            return stdout

        try:
            return self._with_keeper_session_refresh(run_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process keeper pam gateway {subcmd} failed: {type(exc).__name__}: {exc}",
                context={"stdout": stdout[-6000:], "stderr": stderr[-4000:]},
                next_action="inspect the Commander output above and retry",
            ) from exc

    def _run_pam_project_in_process(self, args: list[str]) -> str:
        """Parse argv for pam project {import,extend} and call the
        Commander class directly with a logged-in KeeperParams. Returns
        whatever the command printed to stdout, so callers that greppy the
        output (e.g. for access_token) keep working.
        """
        subcmd = args[2]
        parsed = _parse_pam_project_args(args[3:])

        stdout = ""
        stderr = ""

        def run_once() -> str:
            nonlocal stdout, stderr
            params = self._get_keeper_params()
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            err_log_handler = logging.StreamHandler(buf_err)
            err_log_handler.setLevel(logging.WARNING)
            root_logger = logging.getLogger()
            root_logger.addHandler(err_log_handler)
            try:
                with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                    if subcmd == "import":
                        from keepercommander.commands.pam_import.edit import (
                            PAMProjectImportCommand,
                        )

                        cmd = PAMProjectImportCommand()
                        cmd.execute(
                            params,
                            project_name=parsed.get("name"),
                            file_name=parsed.get("file"),
                            dry_run=parsed.get("dry_run", False),
                        )
                    else:
                        from keepercommander.commands.pam_import.extend import (
                            PAMProjectExtendCommand,
                        )

                        cmd = PAMProjectExtendCommand()
                        cmd.execute(
                            params,
                            config=parsed.get("config"),
                            file_name=parsed.get("file"),
                            dry_run=parsed.get("dry_run", False),
                        )
            finally:
                stdout = buf_out.getvalue()
                stderr = buf_err.getvalue()
                root_logger.removeHandler(err_log_handler)
            return stdout

        try:
            return self._with_keeper_session_refresh(run_once)
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process keeper pam project {subcmd} failed: {type(exc).__name__}: {exc}",
                context={"stdout": stdout[-6000:], "stderr": stderr[-4000:]},
                next_action="inspect the Commander output above and retry",
            ) from exc

    def _run_pam_rotation_edit_in_process(self, args: list[str]) -> str:
        """Run ``pam rotation edit`` against the cached Commander session."""

        stdout = ""
        stderr = ""

        def run_once() -> str:
            nonlocal stdout, stderr
            params = self._get_keeper_params()
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            err_log_handler = logging.StreamHandler(buf_err)
            err_log_handler.setLevel(logging.WARNING)
            root_logger = logging.getLogger()
            root_logger.addHandler(err_log_handler)
            try:
                from keepercommander import api
                from keepercommander.commands.discoveryrotation import (
                    PAMCreateRecordRotationCommand,
                )

                cmd = PAMCreateRecordRotationCommand()
                with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                    parsed = vars(cmd.get_parser().parse_args(args[3:]))
                    api.sync_down(params)
                    cmd.execute(params, **parsed)
            finally:
                stdout = buf_out.getvalue()
                stderr = buf_err.getvalue()
                root_logger.removeHandler(err_log_handler)
            return stdout

        backoff_sec = 5
        max_attempts = 3

        try:
            attempt = 0
            last_out = ""
            while attempt < max_attempts:
                attempt += 1
                last_out = self._with_keeper_session_refresh(run_once)
                if not self._stderr_shows_rotation_set_record_rotation_http_500(stderr):
                    return last_out
                if attempt < max_attempts:
                    time.sleep(backoff_sec)
            raise CapabilityError(
                reason=(
                    "keeper pam rotation edit surfaced repeated Commander warnings "
                    '`Set rotation error "500"` from Keeper router `/api/user/set_record_rotation` '
                    f"after {max_attempts} attempts — upstream regression likely (client protobuf unchanged vs v17)."
                ),
                context={
                    "stdout": stdout[-6000:],
                    "stderr": stderr[-4000:],
                    "attempts": max_attempts,
                },
                next_action=(
                    "escalate to Keeper router/backend with persisted protobuf from "
                    "`$KEEPER_ROTATION_DEBUG_PATH` (default `/tmp/g8-rotation-last.pb`)"
                ),
            )
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process keeper pam rotation edit failed: {type(exc).__name__}: {exc}",
                context={"stdout": stdout[-6000:], "stderr": stderr[-4000:]},
                next_action="inspect the Commander output above and retry",
            ) from exc

    @staticmethod
    def _stderr_shows_rotation_set_record_rotation_http_500(stderr: str) -> bool:
        """Match Commander`s `pam rotation edit` KeeperApiError surfacing used as WARNING text."""
        return bool(stderr) and "Set rotation error" in stderr and '"500"' in stderr

    def _run_ls_in_process(self, args: list[str]) -> str:
        """Run ``ls <pattern> --format json`` in-process so discover() shares apply auth.

        Mirrors :meth:`_run_pam_rotation_edit_in_process`: parse argv via the
        Commander command's own argparse, sync_down once, capture stdout.
        Output shape is identical to subprocess ``keeper ls --format json``
        because the same command class produces it.
        """
        stdout = ""
        stderr = ""

        def run_once() -> str:
            nonlocal stdout, stderr
            params = self._get_keeper_params()
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            err_log_handler = logging.StreamHandler(buf_err)
            err_log_handler.setLevel(logging.WARNING)
            root_logger = logging.getLogger()
            root_logger.addHandler(err_log_handler)
            try:
                from keepercommander import api
                from keepercommander.commands.folder import (
                    FolderListCommand,
                )

                cmd = FolderListCommand()
                with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                    # UIDs passed to ls may start with '-' (e.g. -ZHjqRH…).
                    # argparse would misread them as flags unless we insert '--'
                    # before positionals. Separate recognised flags (--format etc.)
                    # from everything else and reconstruct with '--' separator.
                    _known_val_flags = {"--format"}
                    _raw = list(args[1:])
                    _flags: list[str] = []
                    _pos: list[str] = []
                    _i = 0
                    while _i < len(_raw):
                        _tok = _raw[_i]
                        if _tok == "--":
                            _pos.extend(_raw[_i + 1 :])
                            break
                        if _tok in _known_val_flags and _i + 1 < len(_raw):
                            _flags += [_tok, _raw[_i + 1]]
                            _i += 2
                        elif _tok.startswith("--"):
                            _flags.append(_tok)
                            _i += 1
                        else:
                            _pos.append(_tok)
                            _i += 1
                    _ls_argv = _flags + (["--"] + _pos if _pos else [])
                    parsed = vars(cmd.get_parser().parse_args(_ls_argv))
                    api.sync_down(params)
                    buf_out.seek(0)
                    buf_out.truncate(0)
                    result = cmd.execute(params, **parsed)
                    _write_command_result(buf_out, result)
            finally:
                stdout = buf_out.getvalue()
                stderr = buf_err.getvalue()
                root_logger.removeHandler(err_log_handler)
            return stdout

        try:
            return self._with_keeper_session_refresh(run_once)
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process keeper ls failed: {type(exc).__name__}: {exc}",
                context={"stdout": stdout[-6000:], "stderr": stderr[-4000:]},
                next_action="inspect the Commander output above and retry",
            ) from exc

    def _run_record_get_in_process(self, args: list[str]) -> str:
        """Run ``get <uid> --format json`` in-process; same auth context as apply."""
        stdout = ""
        stderr = ""

        def run_once() -> str:
            nonlocal stdout, stderr
            params = self._get_keeper_params()
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            err_log_handler = logging.StreamHandler(buf_err)
            err_log_handler.setLevel(logging.WARNING)
            root_logger = logging.getLogger()
            root_logger.addHandler(err_log_handler)
            try:
                from keepercommander import api
                from keepercommander.commands.record import (
                    RecordGetUidCommand,
                )

                cmd = RecordGetUidCommand()
                # Separate flags from positionals so dash-prefixed Keeper UIDs
                # (e.g. ``-abc123...``, 22 chars) are not misread as argparse
                # options; same technique as ``_run_ls_in_process``.
                _known_get_val_flags = {"--format", "--output"}
                _raw_get = list(args[1:])
                _get_flags: list[str] = []
                _get_pos: list[str] = []
                _gi = 0
                while _gi < len(_raw_get):
                    _gt = _raw_get[_gi]
                    if _gt == "--":
                        _get_pos.extend(_raw_get[_gi + 1 :])
                        break
                    if _gt in _known_get_val_flags and _gi + 1 < len(_raw_get):
                        _get_flags += [_gt, _raw_get[_gi + 1]]
                        _gi += 2
                    elif _gt.startswith("--"):
                        _get_flags.append(_gt)
                        _gi += 1
                    else:
                        _get_pos.append(_gt)
                        _gi += 1
                _get_argv = _get_flags + (["--"] + _get_pos if _get_pos else [])
                with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                    parsed = vars(cmd.get_parser().parse_args(_get_argv))
                    api.sync_down(params)
                    buf_out.seek(0)
                    buf_out.truncate(0)
                    result = cmd.execute(params, **parsed)
                    _write_command_result(buf_out, result)
            finally:
                stdout = buf_out.getvalue()
                stderr = buf_err.getvalue()
                root_logger.removeHandler(err_log_handler)
            return stdout

        try:
            return self._with_keeper_session_refresh(run_once)
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process keeper get failed: {type(exc).__name__}: {exc}",
                context={"stdout": stdout[-6000:], "stderr": stderr[-4000:]},
                next_action="inspect the Commander output above and retry",
            ) from exc

    def _can_attempt_in_process_login(self) -> bool:
        """True when in-process Commander login is plausibly available.

        Checked before routing read-side commands (``ls``/``get``) through
        the in-process path. When False the dispatcher falls through to
        subprocess so plain installs (no helper, no env creds) keep working.
        """
        if self._keeper_params is not None:
            return True
        if self._keeper_login_attempted:
            return False
        if os.environ.get("KEEPER_SDK_LOGIN_HELPER"):
            return True
        env_creds = ("KEEPER_EMAIL", "KEEPER_PASSWORD", "KEEPER_TOTP_SECRET")
        if all(os.environ.get(v) for v in env_creds):
            return True
        return False

    def _with_keeper_session_refresh(self, operation: Callable[[], Any]) -> Any:
        """Run an in-process Commander operation, re-login once on session expiry."""
        try:
            return operation()
        except Exception as exc:
            if not _is_retryable_keeper_session_error(exc):
                raise
            self._invalidate_keeper_params()
        return operation()

    def _invalidate_keeper_params(self) -> None:
        self._keeper_params = None
        self._keeper_login_attempted = False

    def _get_keeper_params(self) -> Any:
        if self._keeper_params is not None:
            return self._keeper_params
        if self._keeper_login_attempted:
            raise CapabilityError(
                reason="in-process Commander login previously failed; cannot retry without a new provider",
                next_action="re-run with a valid admin config + KSM credentials available",
            )
        self._keeper_login_attempted = True

        # Resolution order:
        # 1. Setting KEEPER_SDK_LOGIN_HELPER=ksm triggers the in-tree KSM
        #    helper, which reads KEEPER_SDK_KSM_CREDS_RECORD_UID and pulls
        #    login/password/oneTimeCode from that KSM record.
        # 2. If KEEPER_SDK_LOGIN_HELPER points at a Python file, use it
        #    (custom flows — HSM-backed TOTP, device-approval queue).
        # 3. Otherwise fall back to the in-tree EnvLoginHelper reading
        #    KEEPER_EMAIL / KEEPER_PASSWORD / KEEPER_TOTP_SECRET.
        # The KEEPER_SDK_LOGIN_HELPER path is validated but the env-var
        # fallback kicks in only when the var is unset — an operator
        # pointing at a missing file gets a loud error (the point of
        # setting the var is to say "do not use the default").
        from dsk.auth import (
            EnvLoginHelper,
            KsmLoginHelper,
            LoginHelper,
            load_helper_from_path,
        )

        helper_path = os.environ.get("KEEPER_SDK_LOGIN_HELPER")
        helper: LoginHelper
        try:
            if helper_path == "ksm":
                helper = KsmLoginHelper()
            elif helper_path:
                helper = load_helper_from_path(helper_path)
            else:
                helper = EnvLoginHelper()
            creds = helper.load_keeper_creds()
            email = creds["email"] if isinstance(creds, dict) else creds[0]
            password = creds["password"] if isinstance(creds, dict) else creds[1]
            totp_secret = creds["totp_secret"] if isinstance(creds, dict) else creds[2]
            extra = {
                k: v
                for k, v in (creds.items() if isinstance(creds, dict) else [])
                if k not in {"email", "password", "totp_secret"}
            }
            params = helper.keeper_login(email, password, totp_secret, **extra)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"in-process Commander login failed: {type(exc).__name__}: {exc}",
                next_action=(
                    "verify credentials are reachable; see docs/LOGIN.md for the "
                    "helper contract + a 30-line skeleton"
                ),
            ) from exc
        self._keeper_params = params
        return params
