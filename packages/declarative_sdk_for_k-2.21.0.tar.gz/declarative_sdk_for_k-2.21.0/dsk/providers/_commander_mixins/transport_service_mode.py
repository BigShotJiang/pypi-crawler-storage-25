"""Service Mode transport helpers for CommanderCliProvider.

:internal: Imported by ``transport._TransportMixin``; not a public API.
"""

from __future__ import annotations

import os
import subprocess
import time
from typing import TYPE_CHECKING, Any

from dsk.core.errors import CapabilityError
from dsk.providers._commander_cli_helpers import _service_mode_command_payload
from dsk.providers.commander_cli import (
    _SERVICE_MODE_DONE_STATUSES,
    _SERVICE_MODE_FAIL_STATUSES,
    _service_mode_failure_reason,
    _service_mode_output,
    _service_mode_status,
)

if TYPE_CHECKING:
    pass


class _ServiceModeTransportMixin:
    """Method carrier for Commander Service Mode command transport."""

    if TYPE_CHECKING:
        _bin_path: str | None
        _config: str | None
        _password: str | None
        _service_api_key: str | None
        _service_autostart: bool
        _service_client: Any | None
        _service_ready: bool
        _service_start_timeout: float
        _service_timeout: int
        _service_url: str

    def _get_service_mode_client(self, *, require_api_key: bool) -> Any:
        if require_api_key and not self._service_api_key and self._service_client is None:
            raise CapabilityError(
                reason="Commander Service Mode API key is required when KEEPER_SERVICE_MODE=1",
                next_action="set KEEPER_SERVICE_API_KEY, or unset KEEPER_SERVICE_MODE",
            )
        if self._service_client is None:
            from dsk.providers.service_client import CommanderServiceClient

            self._service_client = CommanderServiceClient(
                self._service_url,
                self._service_api_key or "",
                timeout=self._service_timeout,
            )
        return self._service_client

    def _service_mode_health_ok(self) -> bool:
        try:
            payload = self._get_service_mode_client(require_api_key=False)._request_json(
                "GET", "/health"
            )
        except CapabilityError:
            return False
        return _service_mode_status(payload) == "ok"

    def _ensure_service_mode_ready(self) -> None:
        if self._service_ready:
            return
        if self._service_mode_health_ok():
            self._service_ready = True
            return
        if not self._service_autostart:
            raise CapabilityError(
                reason="Commander Service Mode is not reachable",
                next_action=(
                    "start `keeper service-start`, verify KEEPER_SERVICE_URL, "
                    "or unset KEEPER_SERVICE_MODE"
                ),
            )
        self._start_service_mode()
        deadline = time.monotonic() + self._service_start_timeout
        while True:
            if self._service_mode_health_ok():
                self._service_ready = True
                return
            if time.monotonic() >= deadline:
                break
            time.sleep(0.25)
        raise CapabilityError(
            reason="Commander Service Mode did not become healthy after service-start",
            next_action=(
                "run `keeper service-status`, inspect Commander service logs, "
                "and verify KEEPER_SERVICE_URL matches the configured port"
            ),
        )

    def _start_service_mode(self) -> None:
        if not self._bin_path:
            raise CapabilityError(
                reason="Commander Service Mode is not reachable and keeper CLI is not on PATH",
                next_action=(
                    "start Commander Service Mode separately, set KEEPER_SERVICE_URL / "
                    "KEEPER_SERVICE_API_KEY, or install Keeper Commander and set KEEPER_BIN"
                ),
            )
        base = [self._bin_path, "--batch-mode"]
        if self._config:
            base += ["--config", self._config]
        env = os.environ.copy()
        if self._password:
            env["KEEPER_PASSWORD"] = self._password
        try:
            result = subprocess.run(
                base + ["service-start"],
                check=False,
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,
                env=env,
                timeout=self._service_timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise CapabilityError(
                reason=f"keeper service-start timed out after {self._service_timeout}s",
                next_action="inspect Commander service logs and retry service-start manually",
            ) from exc
        if result.returncode != 0:
            raise CapabilityError(
                reason=f"keeper service-start failed (rc={result.returncode})",
                context={"stdout": result.stdout[-4000:], "stderr": result.stderr[-4000:]},
                next_action=(
                    "run `keeper service-create` once, then `keeper service-start`; "
                    "set KEEPER_SERVICE_API_KEY for DSK"
                ),
            )

    def _run_service_mode_cmd(self, args: list[str]) -> str:
        client = self._get_service_mode_client(require_api_key=True)
        self._ensure_service_mode_ready()
        command, filedata = _service_mode_command_payload(args)
        request_id = client._post_async(command, filedata)
        status_payload = client._poll_status(request_id, self._service_timeout)
        status = _service_mode_status(status_payload)
        if status in _SERVICE_MODE_FAIL_STATUSES:
            raise CapabilityError(
                reason=_service_mode_failure_reason(
                    status_payload,
                    fallback=f"Commander Service Mode command {command!r} {status}",
                ),
                next_action="inspect Commander Service Mode request logs and retry after fixing the command",
                context={"request_id": request_id, "status": status_payload},
            )
        if status not in _SERVICE_MODE_DONE_STATUSES:
            raise CapabilityError(
                reason=f"Commander Service Mode returned unknown status {status!r}",
                next_action="check service-mode API v2 compatibility",
                context={"request_id": request_id, "status": status_payload},
            )
        result = client._get_result(request_id)
        result_status = _service_mode_status(result) if isinstance(result, dict) else ""
        if result_status in _SERVICE_MODE_FAIL_STATUSES:
            raise CapabilityError(
                reason=_service_mode_failure_reason(result, fallback=f"command {command!r} failed"),
                next_action="inspect Commander Service Mode result output",
                context={"request_id": request_id, "result": result},
            )
        return _service_mode_output(result)
