"""Mixin — msp resource family of CommanderCliProvider.

Private implementation module. Not a public API.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome
from dsk.core.planner import Plan
from dsk.providers._commander.msp import (
    _msp_add_command_kwargs,
    _msp_change_name,
    _msp_find_target,
    _msp_guard_update_name_collision,
    _msp_plan_changes,
    _msp_target_mc,
    _msp_update_command_kwargs,
)
from dsk.providers.commander_cli import (
    _MSP_APPLY_UNSUPPORTED_REASON,
    _MSP_CREATE_ONLY_UNSUPPORTED_REASON,
    _MSP_MANAGED_COMPANY_RESOURCE_TYPES,
    ConflictError,
)

if TYPE_CHECKING:
    pass


def _ensure_keepercommander_version_for_apply() -> None:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    _cli_m._ensure_keepercommander_version_for_apply()


class _MspMixin:
    """Method carrier — msp resource family."""

    if TYPE_CHECKING:
        # Cross-mixin methods (transport)
        def _get_keeper_params(self) -> Any: ...
        def _with_keeper_session_refresh(self, fn: Any, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (pam_core)
        def discover_managed_companies(self, *a: Any, **kw: Any) -> Any: ...

    def apply_msp_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        changes = _msp_plan_changes(plan)
        if not changes:
            raise CapabilityError(_MSP_APPLY_UNSUPPORTED_REASON)

        unsupported = [
            change
            for change in changes
            if change.resource_type not in _MSP_MANAGED_COMPANY_RESOURCE_TYPES
        ]
        if unsupported:
            first = unsupported[0]
            raise CapabilityError(
                reason=_MSP_CREATE_ONLY_UNSUPPORTED_REASON,
                uid_ref=first.uid_ref,
                resource_type=first.resource_type,
                next_action=(
                    "apply only managed_company create/update/delete rows with Commander; "
                    "use mock provider for unsupported MSP family rows"
                ),
            )

        _ensure_keepercommander_version_for_apply()
        outcomes: list[ApplyOutcome] = []
        for change in changes:
            name = _msp_change_name(change)

            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or ""},
                    )
                )
                continue

            if change.kind not in (ChangeKind.CREATE, ChangeKind.UPDATE, ChangeKind.DELETE):
                details: dict[str, Any] = {"dry_run": dry_run}
                if change.reason is not None:
                    details["reason"] = change.reason
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details=details,
                    )
                )
                continue

            live_rows = self.discover_managed_companies()
            existing = _msp_find_target(live_rows, change, name=name)

            if change.kind is ChangeKind.CREATE:
                duplicate = next(
                    (
                        row
                        for row in live_rows
                        if str(row.get("name", "")).casefold() == name.casefold()
                    ),
                    None,
                )
                if duplicate is not None:
                    raise ConflictError(
                        reason=f"managed company {name!r} already exists; refusing create",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        live_identifier=str(
                            duplicate.get("mc_enterprise_id") or duplicate.get("name") or name
                        ),
                        next_action="refresh plan from live MSP state or rename the managed company",
                        context={"live": duplicate},
                    )

                kwargs = _msp_add_command_kwargs(change)
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid="",
                            action="create",
                            details={"dry_run": True, "kwargs": kwargs},
                        )
                    )
                    continue

                try:
                    from keepercommander.commands.msp import (
                        MSPAddCommand,
                    )
                except (ImportError, AttributeError) as exc:
                    raise CapabilityError(
                        reason=f"Commander MSPAddCommand is unavailable: {exc}",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action="upgrade keepercommander to a version that provides keepercommander.commands.msp.MSPAddCommand",
                    ) from exc

                def _run_create() -> Any:
                    params = self._get_keeper_params()
                    command = MSPAddCommand()
                    if not hasattr(command, "execute"):
                        raise CapabilityError(
                            reason="Commander MSPAddCommand has no execute(params, **kwargs) API",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action=(
                                "need MSPAddCommand.execute(params, name, plan, seats, "
                                "file_plan, addon, node)"
                            ),
                        )
                    return command.execute(params, **kwargs)

                try:
                    mc_id = self._with_keeper_session_refresh(_run_create)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"MSP managed-company create failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify MSP admin permissions, plan/file_plan/addon permits, "
                            "and root node access"
                        ),
                    ) from exc

                if mc_id is None:
                    raise CapabilityError(
                        reason="Commander MSPAddCommand returned no managed-company id",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action=(
                            "inspect Commander warnings for invalid plan/file_plan/addon permits "
                            "or missing MSP root node"
                        ),
                    )
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=str(mc_id),
                        action="create",
                        details={"dry_run": False, "mc_enterprise_id": mc_id, "kwargs": kwargs},
                    )
                )

            elif change.kind is ChangeKind.UPDATE:
                _msp_guard_update_name_collision(
                    live_rows=live_rows,
                    change=change,
                    existing=existing,
                    name=name,
                )
                kwargs = _msp_update_command_kwargs(change, existing)
                mc_id = _msp_target_mc(change, existing)
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=mc_id,
                            action="update",
                            details={"dry_run": True, "kwargs": kwargs},
                        )
                    )
                    continue

                try:
                    from keepercommander.commands.msp import (
                        MSPUpdateCommand,
                    )
                except (ImportError, AttributeError) as exc:
                    raise CapabilityError(
                        reason=f"Commander MSPUpdateCommand is unavailable: {exc}",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action="upgrade keepercommander to a version that provides keepercommander.commands.msp.MSPUpdateCommand",
                    ) from exc

                def _run_update() -> Any:
                    params = self._get_keeper_params()
                    command = MSPUpdateCommand()
                    if not hasattr(command, "execute"):
                        raise CapabilityError(
                            reason="Commander MSPUpdateCommand has no execute(params, **kwargs) API",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action=(
                                "need MSPUpdateCommand.execute(params, mc, name, plan, seats, "
                                "file_plan, add_addon, remove_addon, node)"
                            ),
                        )
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_update)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"MSP managed-company update failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify MSP admin permissions, target managed-company id/name, "
                            "and plan/file_plan/addon permits"
                        ),
                    ) from exc

                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=mc_id,
                        action="update",
                        details={"dry_run": False, "mc_enterprise_id": mc_id, "kwargs": kwargs},
                    )
                )

            elif change.kind is ChangeKind.DELETE:
                if getattr(plan, "allow_delete", True) is False:
                    raise CapabilityError(
                        reason="MSP managed-company delete requires allow_delete=True",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action="rerun plan/apply with --allow-delete before deleting MSP managed companies",
                    )

                kwargs = {"mc": _msp_target_mc(change, existing), "force": True}
                mc_id = str(kwargs["mc"])
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or name,
                            keeper_uid=mc_id,
                            action="delete",
                            details={"dry_run": True, "kwargs": kwargs},
                        )
                    )
                    continue

                try:
                    from keepercommander.commands.msp import (
                        MSPRemoveCommand,
                    )
                except (ImportError, AttributeError) as exc:
                    raise CapabilityError(
                        reason=f"Commander MSPRemoveCommand is unavailable: {exc}",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action="upgrade keepercommander to a version that provides keepercommander.commands.msp.MSPRemoveCommand",
                    ) from exc

                def _run_delete() -> Any:
                    params = self._get_keeper_params()
                    command = MSPRemoveCommand()
                    if not hasattr(command, "execute"):
                        raise CapabilityError(
                            reason="Commander MSPRemoveCommand has no execute(params, **kwargs) API",
                            uid_ref=change.uid_ref or name,
                            resource_type=change.resource_type,
                            next_action="need MSPRemoveCommand.execute(params, mc, force)",
                        )
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_delete)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"MSP managed-company delete failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref or name,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify MSP admin permissions and target managed-company id/name "
                            "before retrying with --allow-delete"
                        ),
                    ) from exc

                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or name,
                        keeper_uid=mc_id,
                        action="delete",
                        details={"dry_run": False, "mc_enterprise_id": mc_id, "kwargs": kwargs},
                    )
                )
        return outcomes
