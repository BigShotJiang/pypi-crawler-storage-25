"""Mixin — vault resource family of _VaultMixin.

Private implementation module. Not a public API.
"""

from __future__ import annotations

import contextlib
import copy
import importlib
import io
import json
import os
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from dsk.core.checkpoint import ApplyCheckpoint
from dsk.core.diff import _DIFF_IGNORED_FIELDS, Change, ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.field_names import field_name_matches, norm_field_name
from dsk.core.interfaces import ApplyOutcome, LiveRecord
from dsk.core.metadata import (
    MARKER_FIELD_LABEL,
    decode_marker,
    encode_marker,
    serialize_marker,
)
from dsk.core.planner import Plan
from dsk.core.vault_models import (
    commander_vault_record_type,
)
from dsk.providers._commander.rotation import (
    _rotation_apply_is_enabled,
)
from dsk.providers._commander_cli_helpers import (
    _extract_marker_field,
    _load_json,
    _record_from_get,
)
from dsk.providers.commander_cli import (
    _RESOURCE_ATTACHMENT_RESOURCE_TYPES,
    _VAULT_SHARED_FOLDER_RESOURCE_TYPE,
    LOGGER,
    _argv_value,
    _checkpoint_uid,
    _is_keeper_fill_change,
    _non_empty_str,
    build_pam_rotation_edit_argvs,
    build_pam_user_saas_plugin_remove_argvs,
    build_pam_user_saas_plugin_set_entries,
)

if TYPE_CHECKING:
    pass


def _ensure_keepercommander_version_for_apply() -> None:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    _cli_m._ensure_keepercommander_version_for_apply()


def utc_timestamp() -> str:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m.utc_timestamp()  # type: ignore[no-any-return]


def _detect_unsupported_capabilities(
    manifest: Any, *, allow_nested_rotation: bool = False
) -> list[str]:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    return _cli_m._detect_unsupported_capabilities(
        manifest, allow_nested_rotation=allow_nested_rotation
    )  # type: ignore[no-any-return]


class _VaultMixin:
    """Method carrier — vault resource family."""

    if TYPE_CHECKING:
        # Instance attrs
        _folder_uid: str | None
        _manifest_name: str | None
        _manifest_source: dict[str, Any]
        last_resolved_users_folder_uid: str | None

        # Cross-mixin methods (transport)
        def _get_keeper_params(self) -> Any: ...
        def _run_cmd(self, args: list[str]) -> str: ...
        def _with_keeper_session_refresh(self, fn: Any, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (pam_core)
        def _maybe_resolve_project_resources_folder(self, project_name: str) -> str | None: ...
        # Cross-mixin methods (sharing)
        def _revoke_folder_grantee(self, *a: Any, **kw: Any) -> Any: ...
        def _share_folder_to_grantee(self, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (pam_core)
        def discover(self, *a: Any, **kw: Any) -> list[Any]: ...

    def _apply_vault_plan(
        self, plan: Plan, *, dry_run: bool = False, checkpoint: ApplyCheckpoint | None = None
    ) -> list[ApplyOutcome]:
        """Apply ``keeper-vault.v1`` records via record-add + marker + ``rm``."""
        hits = _detect_unsupported_capabilities(
            self._manifest_source,
            allow_nested_rotation=_rotation_apply_is_enabled(),
        )
        if hits:
            raise CapabilityError(
                reason="manifest declares capabilities the CommanderCliProvider does not implement yet: "
                + "; ".join(hits),
                next_action=(
                    "remove the declarations, or drive the Commander hook manually before "
                    "re-running apply. See REVIEW.md D-4."
                ),
            )
        _ensure_keepercommander_version_for_apply()
        if not self._folder_uid:
            raise CapabilityError(
                reason="keeper-vault apply requires a shared folder uid (discover scope)",
                next_action="pass --folder-uid or set KEEPER_DECLARATIVE_FOLDER",
            )
        self._vault_guard_shared_folder_membership_removals(plan)

        outcomes: list[ApplyOutcome] = []
        now = utc_timestamp()
        for change in plan.ordered():
            ck_uid = _checkpoint_uid(change)
            if (
                checkpoint
                and not dry_run
                and ck_uid
                and change.kind in (ChangeKind.CREATE, ChangeKind.UPDATE)
                and checkpoint.is_applied(ck_uid)
            ):
                LOGGER.info("apply checkpoint: skipping vault uid_ref=%s", ck_uid)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=ck_uid,
                        keeper_uid=change.keeper_uid or "",
                        action=change.kind.value,
                        details={"checkpoint_skipped": True},
                    )
                )
                continue
            if change.kind is ChangeKind.CREATE:
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="create",
                            details={"dry_run": True},
                        )
                    )
                    continue
                if change.resource_type == "record_type":
                    self._vault_apply_record_type_reject()
                if change.resource_type == _VAULT_SHARED_FOLDER_RESOURCE_TYPE:
                    keeper_uid = self._vault_add_shared_folder(change.after or {})
                    membership = self._vault_apply_shared_folder_membership_update(
                        keeper_uid,
                        before_members=[],
                        after_members=change.after.get("members") if change.after else None,
                    )
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=keeper_uid,
                            action="create",
                            details={"marker_written": False, **membership},
                        )
                    )
                    if checkpoint and ck_uid:
                        checkpoint.mark_applied(ck_uid, "create")
                    continue
                if _is_keeper_fill_change(change):
                    keeper_uid = self._vault_apply_keeper_fill_create(change.after or {})
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=keeper_uid,
                            action="create",
                            details={"marker_written": False},
                        )
                    )
                    if checkpoint and ck_uid:
                        checkpoint.mark_applied(ck_uid, "create")
                    continue
                keeper_uid = self._vault_add_login_record(change.after or {})
                marker = encode_marker(
                    uid_ref=change.uid_ref or change.title,
                    manifest=plan.manifest_name,
                    resource_type=change.resource_type,
                    last_applied_at=now,
                )
                self._write_marker(keeper_uid, marker)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=keeper_uid,
                        action="create",
                        details={"marker_written": True},
                    )
                )
                if checkpoint and ck_uid:
                    checkpoint.mark_applied(ck_uid, "create")
            elif change.kind is ChangeKind.UPDATE:
                keeper_uid = change.keeper_uid or ""
                if not keeper_uid:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid="",
                            action="update",
                            details={"skipped": True, "reason": "no keeper_uid on update change"},
                        )
                    )
                    continue
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=keeper_uid,
                            action="update",
                            details={"dry_run": True},
                        )
                    )
                    continue
                if change.resource_type == "record_type":
                    self._vault_apply_record_type_reject()
                patch = dict(change.after or {})
                if change.resource_type == _VAULT_SHARED_FOLDER_RESOURCE_TYPE:
                    membership = self._vault_apply_shared_folder_membership_update(
                        keeper_uid,
                        before_members=change.before.get("members"),
                        after_members=patch.get("members"),
                    )
                    default_permissions_updated = (
                        self._vault_apply_shared_folder_permissions_update(
                            keeper_uid,
                            patch.get("permissions"),
                        )
                    )
                    if patch.get("title") not in (None, ""):
                        self._run_cmd(["rndir", "-n", str(patch["title"]), keeper_uid])
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=keeper_uid,
                            action="update",
                            details={
                                "marker_written": False,
                                "record_updated": bool(patch),
                                **membership,
                                "default_permissions_updated": default_permissions_updated,
                            },
                        )
                    )
                    if checkpoint and ck_uid:
                        checkpoint.mark_applied(ck_uid, "update")
                    continue
                if _is_keeper_fill_change(change):
                    self._vault_apply_keeper_fill_update(keeper_uid, patch)
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=keeper_uid,
                            action="update",
                            details={"marker_written": False, "record_updated": bool(patch)},
                        )
                    )
                    if checkpoint and ck_uid:
                        checkpoint.mark_applied(ck_uid, "update")
                    continue
                if patch:
                    self._vault_apply_login_body_update(keeper_uid, patch)
                marker = encode_marker(
                    uid_ref=change.uid_ref or change.title,
                    manifest=plan.manifest_name,
                    resource_type=change.resource_type,
                    last_applied_at=now,
                )
                self._write_marker(keeper_uid, marker)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=keeper_uid,
                        action="update",
                        details={"marker_written": True, "record_updated": bool(patch)},
                    )
                )
                if checkpoint and ck_uid:
                    checkpoint.mark_applied(ck_uid, "update")

        for change in plan.deletes:
            ck_uid = _checkpoint_uid(change)
            if checkpoint and not dry_run and ck_uid and checkpoint.is_applied(ck_uid):
                LOGGER.info("apply checkpoint: skipping vault delete uid_ref=%s", ck_uid)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=ck_uid,
                        keeper_uid=change.keeper_uid or "",
                        action="delete",
                        details={"checkpoint_skipped": True},
                    )
                )
                continue
            if not change.keeper_uid:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid="",
                        action="delete",
                        details={
                            "skipped": True,
                            "reason": "no keeper_uid on delete change",
                            "warning": "dependency checks are enforced by Keeper CLI/server, not client-side",
                        },
                    )
                )
                continue
            if change.resource_type == _VAULT_SHARED_FOLDER_RESOURCE_TYPE:
                if getattr(plan, "allow_delete", False) is not True:
                    raise CapabilityError(
                        reason="shared_folder delete requires --allow-delete",
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action="rerun plan/apply with --allow-delete before deleting shared folders",
                    )
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=change.keeper_uid,
                            action="delete",
                            details={
                                "dry_run": True,
                                "keeper_uid": change.keeper_uid,
                                "warning": "dependency checks are enforced by Keeper CLI/server, not client-side",
                            },
                        )
                    )
                    continue
                outcome = ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid,
                    action="delete",
                    details={
                        "keeper_uid": change.keeper_uid,
                        "removed": False,
                        "warning": "dependency checks are enforced by Keeper CLI/server, not client-side",
                    },
                )
                outcomes.append(outcome)
                self._delete_folder(path_or_uid=change.keeper_uid)
                outcome.details["removed"] = True
                if checkpoint and ck_uid:
                    checkpoint.mark_applied(ck_uid, "delete")
                continue
            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid,
                        action="delete",
                        details={
                            "dry_run": True,
                            "keeper_uid": change.keeper_uid,
                            "warning": "dependency checks are enforced by Keeper CLI/server, not client-side",
                        },
                    )
                )
                continue
            outcome = ApplyOutcome(
                uid_ref=change.uid_ref or "",
                keeper_uid=change.keeper_uid,
                action="delete",
                details={
                    "keeper_uid": change.keeper_uid,
                    "removed": False,
                    "warning": "dependency checks are enforced by Keeper CLI/server, not client-side",
                },
            )
            outcomes.append(outcome)
            try:
                self._run_cmd(["rm", "--force", change.keeper_uid])
            except CapabilityError:
                raise
            outcome.details["removed"] = True
            if checkpoint and ck_uid:
                checkpoint.mark_applied(ck_uid, "delete")

        for change in plan.conflicts:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="conflict",
                    details={"reason": change.reason or ""},
                )
            )
        for change in plan.noops:
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                )
            )
        return outcomes

    @staticmethod
    def _vault_shared_folder_permissions(
        permissions: Any,
    ) -> tuple[bool, bool]:
        if not isinstance(permissions, Mapping):
            return False, False
        return bool(permissions.get("manage_records")), bool(permissions.get("manage_users"))

    @staticmethod
    def _vault_shared_folder_role_permissions(role: Any) -> tuple[bool, bool]:
        if role == "manage":
            return True, True
        if role in {"edit", "manage_records"}:
            return True, False
        if role == "manage_users":
            return False, True
        return False, False

    @staticmethod
    def _vault_shared_folder_member_permission(member: Mapping[str, Any]) -> str:
        permission = member.get("permission")
        if permission is not None:
            return str(permission).strip()
        role = str(member.get("role") or "").strip()
        if role == "read":
            return "read_only"
        if role == "edit":
            return "manage_records"
        if role:
            return role
        if "manage_records" in member or "manage_users" in member:
            manage_records = bool(member.get("manage_records"))
            manage_users = bool(member.get("manage_users"))
            if manage_records and manage_users:
                return "manage"
            if manage_records:
                return "manage_records"
            if manage_users:
                return "manage_users"
            return "read_only"
        return ""

    @staticmethod
    def _vault_shared_folder_members_by_email(members: Any) -> dict[str, dict[str, str]]:
        if not isinstance(members, list):
            return {}
        out: dict[str, dict[str, str]] = {}
        for member in members:
            if not isinstance(member, Mapping):
                continue
            email = str(member.get("email") or "").strip()
            permission = _VaultMixin._vault_shared_folder_member_permission(member)
            if email and permission:
                out[email.casefold()] = {"email": email, "permission": permission}
        return out

    @staticmethod
    def _vault_shared_folder_removed_member_count(
        before_members: Any,
        after_members: Any,
    ) -> int:
        if not isinstance(before_members, list) or not isinstance(after_members, list):
            return 0
        before_by_email = _VaultMixin._vault_shared_folder_members_by_email(before_members)
        after_by_email = _VaultMixin._vault_shared_folder_members_by_email(after_members)
        return len(set(before_by_email) - set(after_by_email))

    def _vault_guard_shared_folder_membership_removals(self, plan: Plan) -> None:
        removed_count = 0
        first_change: Change | None = None
        for change in plan.ordered():
            if (
                change.kind is not ChangeKind.UPDATE
                or change.resource_type != _VAULT_SHARED_FOLDER_RESOURCE_TYPE
            ):
                continue
            count = self._vault_shared_folder_removed_member_count(
                change.before.get("members"),
                change.after.get("members"),
            )
            if count:
                removed_count += count
                first_change = first_change or change
        if not removed_count:
            return
        setattr(plan, "requires_allow_delete", True)
        if getattr(plan, "allow_delete", False) is True:
            return
        assert first_change is not None
        raise CapabilityError(
            reason="shared_folder membership removal requires --allow-delete",
            uid_ref=first_change.uid_ref,
            resource_type=first_change.resource_type,
            next_action=(
                "rerun plan/apply with --allow-delete before removing shared-folder members"
            ),
            context={
                "requires_allow_delete": True,
                "removed_member_count": removed_count,
            },
        )

    def _vault_add_shared_folder(self, after: dict[str, Any]) -> str:
        """Create a Keeper shared folder using Commander's folder-add equivalent."""
        title = str(after.get("title") or "").strip()
        if not title:
            raise CapabilityError(
                reason="shared_folder create is missing after.title",
                resource_type=_VAULT_SHARED_FOLDER_RESOURCE_TYPE,
                next_action="rebuild the vault plan from a manifest with shared_folders[].title",
            )
        manage_records, manage_users = self._vault_shared_folder_permissions(
            after.get("permissions")
        )
        try:
            from keepercommander import api

            folder_module = importlib.import_module("keepercommander.commands.folder")
        except ImportError as exc:
            raise CapabilityError(
                reason=f"cannot create shared folder: keepercommander unavailable: {exc}",
                next_action="install Commander Python package in the same interpreter as the SDK",
            ) from exc

        command_cls = getattr(folder_module, "FolderAddCommand", None) or getattr(
            folder_module,
            "FolderMakeCommand",
            None,
        )
        if command_cls is None:
            raise CapabilityError(
                reason="Commander shared-folder create command is unavailable",
                resource_type=_VAULT_SHARED_FOLDER_RESOURCE_TYPE,
                next_action=(
                    "upgrade keepercommander to a version with "
                    "keepercommander.commands.folder.FolderMakeCommand"
                ),
            )

        def _run_add() -> Any:
            params = self._get_keeper_params()
            api.sync_down(params)
            old_current = getattr(params, "current_folder", None)
            had_current = hasattr(params, "current_folder")
            target_current = self._vault_shared_folder_create_parent(params)
            setattr(params, "current_folder", target_current)
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                    uid = command_cls().execute(
                        params,
                        folder=title,
                        shared_folder=True,
                        user_folder=False,
                        grant=False,
                        manage_records=manage_records,
                        manage_users=manage_users,
                        can_edit=False,
                        can_share=False,
                    )
            finally:
                if had_current:
                    setattr(params, "current_folder", old_current)
                elif hasattr(params, "current_folder"):
                    delattr(params, "current_folder")
            api.sync_down(params)
            return uid

        try:
            uid = self._with_keeper_session_refresh(_run_add)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"shared_folder create failed: {type(exc).__name__}: {exc}",
                next_action="verify shared-folder create permission and Commander folder cache, then retry",
            ) from exc

        uid_str = ""
        if isinstance(uid, str):
            uid_str = uid.strip()
        elif isinstance(uid, bytes):
            uid_str = uid.decode("utf-8", errors="replace").strip()
        elif uid is not None:
            uid_str = str(uid).strip()
        if not uid_str:
            raise CapabilityError(
                reason="Commander shared-folder create did not return a folder UID",
                resource_type=_VAULT_SHARED_FOLDER_RESOURCE_TYPE,
                next_action="inspect Commander folder-add/mkdir output and retry",
            )
        return uid_str

    def _vault_shared_folder_create_parent(self, params: Any) -> str:
        """Return a user/root folder parent for a new shared folder.

        keeper-vault L1 uses ``folder_uid`` as the record scope, normally a
        shared folder. Commander refuses nested shared folders, so create at
        root unless the configured scope is visibly a user/root folder.
        """
        if not self._folder_uid:
            return ""
        folder_cache = getattr(params, "folder_cache", None)
        if not isinstance(folder_cache, Mapping):
            return ""
        folder = folder_cache.get(self._folder_uid)
        if folder is None:
            return ""
        folder_type = getattr(folder, "type", None)
        if folder_type is None and isinstance(folder, Mapping):
            folder_type = folder.get("type")
        if folder_type in {"shared_folder", "shared_folder_folder"}:
            return ""
        return self._folder_uid

    def _vault_apply_shared_folder_membership_update(
        self,
        keeper_uid: str,
        *,
        before_members: Any,
        after_members: Any,
    ) -> dict[str, int]:
        if not isinstance(after_members, list):
            return {"members_granted": 0, "members_removed": 0}
        before_by_email = self._vault_shared_folder_members_by_email(before_members)
        after_by_email = self._vault_shared_folder_members_by_email(after_members)
        granted = 0
        removed = 0
        for key in sorted(set(before_by_email) - set(after_by_email)):
            self._revoke_folder_grantee(
                shared_folder_uid=keeper_uid,
                grantee_kind="user",
                identifier=before_by_email[key]["email"],
            )
            removed += 1
        for key in sorted(after_by_email):
            desired = after_by_email[key]
            if before_by_email.get(key) == desired:
                continue
            manage_records, manage_users = self._vault_shared_folder_role_permissions(
                desired["permission"]
            )
            self._share_folder_to_grantee(
                shared_folder_uid=keeper_uid,
                grantee_kind="user",
                identifier=desired["email"],
                manage_records=manage_records,
                manage_users=manage_users,
            )
            granted += 1
        return {"members_granted": granted, "members_removed": removed}

    def _vault_apply_shared_folder_permissions_update(
        self,
        keeper_uid: str,
        permissions: Any,
    ) -> bool:
        if not isinstance(permissions, Mapping):
            return False
        manage_records, manage_users = self._vault_shared_folder_permissions(permissions)
        self._share_folder_to_grantee(
            shared_folder_uid=keeper_uid,
            grantee_kind="default",
            manage_records=manage_records,
            manage_users=manage_users,
        )
        return True

    def _discover_marker_records(self) -> list[LiveRecord]:
        if not self._folder_uid:
            return []
        payload = self._run_cmd(["ls", self._folder_uid, "--format", "json"])
        entries = _load_json(payload, command="ls --format json")
        if not isinstance(entries, list):
            raise CapabilityError(
                reason="Commander returned non-array JSON from `ls --format json`"
            )
        records: list[LiveRecord] = []
        for entry in entries:
            if not isinstance(entry, dict) or entry.get("type") != "record":
                continue
            keeper_uid = entry.get("uid")
            if not keeper_uid:
                continue
            item_payload = self._run_cmd(["get", str(keeper_uid), "--format", "json"])
            item = _load_json(item_payload, command="get --format json")
            if not isinstance(item, dict):
                continue
            record = _record_from_get(item, listing_entry={**entry, "folder_uid": self._folder_uid})
            if record is not None and record.marker:
                records.append(record)
        return records

    @staticmethod
    def _vault_custom_field_label(entry: dict[str, Any]) -> str:
        return norm_field_name(entry.get("label") or entry.get("name") or "")

    @classmethod
    def _vault_merge_custom_for_update(
        cls,
        existing_list: list[Any],
        patch_list: list[Any],
    ) -> list[dict[str, Any]]:
        """Overlay ``patch_list`` entries onto ``existing_list`` by field label.

        Preserves the SDK ownership marker entry if the manifest ``custom`` patch
        omits it (declarative manifests normally do not carry the live marker).
        """
        marker_key = norm_field_name(MARKER_FIELD_LABEL)
        patch_by = {
            cls._vault_custom_field_label(e): copy.deepcopy(e)
            for e in patch_list
            if isinstance(e, dict) and cls._vault_custom_field_label(e)
        }
        out: list[dict[str, Any]] = []
        used_patch: set[str] = set()
        for e in existing_list:
            if not isinstance(e, dict):
                continue
            lab = cls._vault_custom_field_label(e)
            if lab in patch_by:
                out.append(copy.deepcopy(patch_by[lab]))
                used_patch.add(lab)
            else:
                out.append(copy.deepcopy(e))
        for lab, ent in patch_by.items():
            if lab not in used_patch:
                out.append(ent)
        labels_present = {cls._vault_custom_field_label(x) for x in out}
        if marker_key not in labels_present:
            marker_keep = next(
                (
                    copy.deepcopy(x)
                    for x in existing_list
                    if isinstance(x, dict) and cls._vault_custom_field_label(x) == marker_key
                ),
                None,
            )
            if marker_keep is not None:
                out.append(marker_keep)
        return out

    @staticmethod
    def _vault_patch_login_record_data(
        existing: dict[str, Any],
        patch: dict[str, Any],
    ) -> dict[str, Any]:
        """Merge planner ``patch`` (subset of manifest record) into v3 ``data`` JSON."""
        out = copy.deepcopy(existing)
        for key, val in patch.items():
            if key in _DIFF_IGNORED_FIELDS:
                continue
            if key == "custom":
                if not isinstance(val, list):
                    continue
                out["custom"] = _VaultMixin._vault_merge_custom_for_update(
                    out.get("custom") or [],
                    val,
                )
            else:
                out[key] = copy.deepcopy(val)
        return out

    def _vault_apply_keeper_fill_create(self, after: dict[str, Any]) -> str:
        """Reject keeper_fill create: no Commander verb writes the keeper_fill record-type yet.

        Keeper Commander 17.2.x exposes ``record-add`` only for typed records; the
        ``keeper_fill`` block has no analogous create verb. The W3-AB schema-honesty
        slice routes the change here rather than silently dropping it through the
        login-record path. See audit `notes/dsk-improvement-audit-2026-04-27.md` F2;
        schema marker for ``keeper_fill`` flipped to ``scaffold-only`` in the same
        slice. Raise rather than fake support.
        """
        del after  # not used; retained so the signature matches the call site
        raise CapabilityError(
            reason=(
                "keeper_fill create has no Commander writer in the pinned upstream "
                "(17.2.x); manifest declares a keeper_fill block but apply cannot "
                "land it without a tenant-side verb."
            ),
            next_action=(
                "remove the keeper_fill block from the manifest, or wait for the "
                "Commander team to publish a typed keeper_fill writer; track via "
                "schema status `scaffold-only`."
            ),
        )

    def _vault_apply_keeper_fill_update(self, keeper_uid: str, patch: dict[str, Any]) -> None:
        """Reject keeper_fill update for the same reason as create (see above)."""
        del keeper_uid, patch
        raise CapabilityError(
            reason=(
                "keeper_fill update has no Commander writer in the pinned upstream "
                "(17.2.x); apply cannot land manifest drift onto the live keeper_fill "
                "record-type."
            ),
            next_action=(
                "remove the keeper_fill block from the manifest, or wait for upstream "
                "support; schema status is `scaffold-only`."
            ),
        )

    def _vault_apply_record_type_reject(self) -> None:
        """Reject record_type create/update: no Commander writer for type definitions (W3-AB)."""
        raise CapabilityError(
            reason=(
                "no Commander writer for record_type definitions in the pinned upstream "
                "(17.2.x); plan can surface `record_types[]` but apply cannot land them in-vault."
            ),
            next_action=(
                "treat `record_types` as preview-gated (schema status `preview-gated`); use "
                "plan/mock/discovery only until an upstream record-type apply verb exists."
            ),
            resource_type="record_type",
        )

    def _vault_apply_login_body_update(self, keeper_uid: str, patch: dict[str, Any]) -> None:
        """Push manifest field drift onto an existing v3 ``login`` via RecordEditCommand."""
        if not patch:
            return
        try:
            from keepercommander import api
            from keepercommander.commands.recordv3 import (
                RecordEditCommand,
            )
        except ImportError as exc:
            raise CapabilityError(
                reason=f"cannot update vault record body: keepercommander unavailable: {exc}",
                next_action="install Commander Python package in the same interpreter as the SDK",
            ) from exc

        def run_edit() -> None:
            params = self._get_keeper_params()
            api.sync_down(params)
            cache = getattr(params, "record_cache", None) or {}
            if keeper_uid not in cache:
                raise CapabilityError(
                    reason=f"vault update: record {keeper_uid} not found in Commander cache after sync",
                    next_action="confirm the record uid and folder scope, then retry",
                )
            rec = cache[keeper_uid]
            version = int(rec.get("version") or 0)
            # Commander ``RecordEditCommand`` only accepts ``rv == 3`` for the
            # ``--data`` JSON path we use (see keepercommander ``recordv3.py``).
            if version != 3:
                raise CapabilityError(
                    reason=(
                        f"vault update: record {keeper_uid} must be record version 3 for JSON edit "
                        f"(got version={version})"
                    ),
                    next_action="use v3 typed records in the scoped folder for keeper-vault",
                )
            raw = rec.get("data_unencrypted")
            if raw is None:
                raise CapabilityError(
                    reason=f"vault update: record {keeper_uid} has no decrypted data in cache",
                    next_action="retry after a successful Commander sync_down",
                )
            raw_str = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else str(raw)
            existing = json.loads(raw_str or "{}")
            merged = self._vault_patch_login_record_data(existing, patch)
            if merged == existing:
                return
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            return_result: dict[str, Any] = {}
            with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                RecordEditCommand().execute(
                    params,
                    record=keeper_uid,
                    data=json.dumps(merged),
                    return_result=return_result,
                )
            if not return_result.get("update_record_v3"):
                err_tail = (buf_err.getvalue() or "").strip()
                reason = (
                    "vault update: RecordEditCommand returned without applying a v3 update "
                    "(Commander may have logged an error and exited)"
                )
                if err_tail:
                    reason = f"{reason}; stderr: {err_tail[:800]}"
                raise CapabilityError(
                    reason=reason,
                    next_action=(
                        "inspect Commander stderr for edit validation errors; "
                        "confirm record type, v3 JSON shape, and account record-types policy, then retry"
                    ),
                )

        try:
            self._with_keeper_session_refresh(run_edit)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"vault record body update failed: {type(exc).__name__}: {exc}",
                next_action="inspect Commander stderr/stdout and the manifest patch fields, then retry",
            ) from exc

    def _vault_add_login_record(self, after: dict[str, Any]) -> str:
        """Create a vault typed record in the configured shared folder (in-process)."""
        try:
            from keepercommander.commands.recordv3 import (
                RecordAddCommand,
            )
        except ImportError as exc:
            raise CapabilityError(
                reason=f"cannot create vault record: keepercommander unavailable: {exc}",
                next_action="install Commander Python package in the same interpreter as the SDK",
            ) from exc

        record_data: dict[str, Any] = {
            "type": commander_vault_record_type(after.get("type") or "login"),
            "title": str(after.get("title") or ""),
            "fields": list(after.get("fields") or []),
            "custom": list(after.get("custom") or []),
        }
        notes = after.get("notes")
        if isinstance(notes, str) and notes.strip():
            record_data["notes"] = notes

        def _run_add() -> Any:
            params = self._get_keeper_params()
            buf_out = io.StringIO()
            buf_err = io.StringIO()
            with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
                return RecordAddCommand().execute(
                    params,
                    data=json.dumps(record_data),
                    force=False,
                    folder=self._folder_uid,
                    attach=[],
                )

        try:
            uid = self._with_keeper_session_refresh(_run_add)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"vault record-add failed: {type(exc).__name__}: {exc}",
                next_action="verify folder permissions and login session, then retry",
            ) from exc

        uid_str = ""
        if isinstance(uid, str):
            uid_str = uid.strip()
        elif isinstance(uid, bytes):
            uid_str = uid.decode("utf-8", errors="replace").strip()
        elif uid is not None:
            uid_str = str(uid).strip()
        if not uid_str:
            raise CapabilityError(
                reason="Commander record-add did not return a record UID",
                next_action="verify keepercommander record-add for typed records in shared folders",
            )
        return uid_str

    def _apply_rotation_settings(
        self,
        plan: Plan,
        live_records: list[LiveRecord],
    ) -> list[ApplyOutcome]:
        if not _rotation_apply_is_enabled():
            return []
        try:
            argvs = build_pam_rotation_edit_argvs(
                self._manifest_source,
                plan=plan,
                live_records=live_records,
            )
        except ValueError as exc:
            raise CapabilityError(
                reason=f"cannot apply resources[].users[].rotation_settings: {exc}",
                next_action=(
                    "confirm pam project import/extend created the nested pamUser, "
                    "parent resource, admin user, and PAM configuration; then rerun plan/apply"
                ),
            ) from exc

        live_by_uid = {record.keeper_uid: record for record in live_records}
        outcomes: list[ApplyOutcome] = []
        for argv in argvs:
            self._run_cmd(argv)
            record_uid = _argv_value(argv, "--record") or ""
            live = live_by_uid.get(record_uid)
            uid_ref = _non_empty_str((live.marker or {}).get("uid_ref")) if live else ""
            outcomes.append(
                ApplyOutcome(
                    uid_ref=uid_ref or "",
                    keeper_uid=record_uid,
                    action="rotation",
                    details={"command": argv},
                )
            )
        return outcomes

    def _apply_rotation_scripts(
        self,
        live_records: list[LiveRecord],
    ) -> list[ApplyOutcome]:
        """Apply ``rotation_scripts`` attachments for nested pamUser records.

        Calls ``pam rotation script add <user-uid> --script-uid <script_uid>``
        for every entry.  Readback is unavailable in Commander 17.x so the
        attachment is unconditional (idempotent on the Commander side).
        """
        source = self._manifest_source
        live_by_title: dict[tuple[str, str], LiveRecord] = {
            (r.resource_type, str((r.marker or {}).get("title") or "")): r for r in live_records
        }
        outcomes: list[ApplyOutcome] = []
        for resource in source.get("resources") or []:
            if not isinstance(resource, dict):
                continue
            for user in resource.get("users") or []:
                if not isinstance(user, dict):
                    continue
                if user.get("type") != "pamUser":
                    continue
                scripts = user.get("rotation_scripts") or []
                if not scripts:
                    continue
                # Resolve user UID from live records
                user_uid_ref = _non_empty_str(user.get("uid_ref"))
                user_title = _non_empty_str(user.get("title")) or ""
                live = None
                if user_uid_ref:
                    live = next(
                        (
                            r
                            for r in live_records
                            if (r.marker or {}).get("uid_ref") == user_uid_ref
                        ),
                        None,
                    )
                if live is None:
                    live = live_by_title.get(("pamUser", user_title))
                if live is None or not live.keeper_uid:
                    raise CapabilityError(
                        reason=(
                            f"rotation_scripts: cannot resolve pamUser '{user_title}' "
                            "to a live Keeper UID — run plan/import first"
                        ),
                        uid_ref=user_uid_ref or "",
                        resource_type="pamUser",
                        next_action=(
                            "ensure the pamUser exists in the vault before applying "
                            "rotation_scripts"
                        ),
                    )
                user_uid = live.keeper_uid
                for script_entry in scripts:
                    script_uid = (
                        script_entry.get("script_uid")
                        if isinstance(script_entry, dict)
                        else getattr(script_entry, "script_uid", None)
                    )
                    if not script_uid:
                        continue
                    argv = [
                        "pam",
                        "rotation",
                        "script",
                        "add",
                        user_uid,
                        "--script-uid",
                        script_uid,
                    ]
                    self._run_cmd(argv)
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=user_uid_ref or "",
                            keeper_uid=user_uid,
                            action="rotation_script",
                            details={"command": argv, "script_uid": script_uid},
                        )
                    )
        return outcomes

    def _apply_resource_attachments(
        self,
        _live_records: list[LiveRecord],
    ) -> list[ApplyOutcome]:
        """Upload ``resources[].attachments`` paths via Commander ``upload-attachment``."""

        source = self._manifest_source
        if not any(
            isinstance(r, dict)
            and r.get("type") in _RESOURCE_ATTACHMENT_RESOURCE_TYPES
            and (r.get("attachments") or [])
            for r in (source.get("resources") or [])
        ):
            return []

        try:
            live_records = self.discover()
        except CapabilityError as exc:
            raise CapabilityError(
                reason=f"attachments: discover() refresh failed: {exc.reason}",
                next_action=exc.next_action,
                context={**exc.context},
            ) from exc

        outcomes: list[ApplyOutcome] = []
        live_by_uid_ref: dict[str, LiveRecord] = {}
        live_by_title: dict[tuple[str, str], LiveRecord] = {}
        for record in live_records:
            ref = _non_empty_str((record.marker or {}).get("uid_ref"))
            if ref:
                live_by_uid_ref[ref] = record
            rt = record.resource_type or ""
            title = str(record.title or "").strip()
            if rt and title:
                live_by_title[(rt, title)] = record

        for resource in source.get("resources") or []:
            if not isinstance(resource, dict):
                continue
            rtype = resource.get("type")
            if rtype not in _RESOURCE_ATTACHMENT_RESOURCE_TYPES:
                continue
            paths = resource.get("attachments") or []
            if not paths:
                continue
            uid_ref = _non_empty_str(resource.get("uid_ref")) or ""
            title_res = str(resource.get("title") or "").strip()
            live: LiveRecord | None = None
            if uid_ref:
                live = live_by_uid_ref.get(uid_ref)
            if live is None and isinstance(rtype, str) and title_res:
                live = live_by_title.get((rtype, title_res))
            if live is None or not live.keeper_uid:
                raise CapabilityError(
                    reason=(
                        f"attachments: cannot resolve {rtype!r} uid_ref={uid_ref!r} "
                        f"title={title_res!r} to a live Keeper UID — run plan/import first"
                    ),
                    uid_ref=uid_ref,
                    resource_type=str(rtype),
                    next_action=(
                        "ensure the resource exists in the vault before uploading attachments"
                    ),
                )
            keeper_uid = live.keeper_uid
            for raw_path in paths:
                if not isinstance(raw_path, str) or not raw_path.strip():
                    continue
                file_path = os.path.expanduser(raw_path.strip())
                if not os.path.isfile(file_path):
                    raise CapabilityError(
                        reason=f"attachments: file missing on disk: {file_path!r}",
                        uid_ref=uid_ref,
                        resource_type=str(rtype),
                        next_action="ensure attachment paths exist before apply",
                    )
                argv = ["upload-attachment", keeper_uid, "--file", file_path]
                self._run_cmd(argv)
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=uid_ref,
                        keeper_uid=keeper_uid,
                        action="attachment",
                        details={
                            "command": argv,
                            "file": os.path.basename(file_path),
                        },
                    )
                )
        return outcomes

    def _apply_pam_user_saas_plugins(
        self,
        plan: Plan,
        live_records: list[LiveRecord],
    ) -> list[ApplyOutcome]:
        """Apply ``resources[].users[].saas_plugins`` via Commander ``pam action saas``."""

        source = self._manifest_source
        outcomes: list[ApplyOutcome] = []

        for uid_ref_val, user_uid, argv in build_pam_user_saas_plugin_set_entries(
            source, live_records
        ):
            if argv[:4] == ["pam", "action", "saas", "set"]:
                kwargs = {
                    "user_uid": argv[argv.index("--user-uid") + 1],
                    "config_record_uid": argv[argv.index("--config-record-uid") + 1],
                }
                _ensure_keepercommander_version_for_apply()
                try:
                    from keepercommander.commands.pam_saas.set import PAMActionSaasSetCommand
                except (ImportError, AttributeError) as exc:
                    raise CapabilityError(
                        reason=f"Commander PAMActionSaasSetCommand is unavailable: {exc}",
                        uid_ref=uid_ref_val,
                        resource_type="pamUser",
                        next_action=(
                            "upgrade keepercommander to a build with "
                            "keepercommander.commands.pam_saas.set.PAMActionSaasSetCommand"
                        ),
                    ) from exc

                def _run_set() -> Any:
                    params = self._get_keeper_params()
                    return PAMActionSaasSetCommand().execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_set)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"pamUser saas_plugins set failed: {type(exc).__name__}: {exc}",
                        uid_ref=uid_ref_val,
                        resource_type="pamUser",
                        next_action=(
                            "verify pamUser + SaaS config record UIDs and Commander session permissions"
                        ),
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=uid_ref_val,
                        keeper_uid=user_uid,
                        action="saas_plugin_set",
                        details={"command": argv, "kwargs": kwargs},
                    )
                )
            elif argv[:3] == ["pam", "saas", "set"]:
                raise CapabilityError(
                    reason=(
                        "pamUser saas_plugins without config_record_uid is not supported for live Commander "
                        "apply (inline plugin_name/config only)"
                    ),
                    uid_ref=uid_ref_val,
                    resource_type="pamUser",
                    next_action=(
                        "set config_record_uid on each saas_plugins[] entry to the vault UID of the "
                        "saasConfiguration/login row, or manage bindings via keeper-saas-rotation.v1"
                    ),
                )

        for uid_ref_val, argv in build_pam_user_saas_plugin_remove_argvs(
            plan, source, live_records
        ):
            kwargs = {
                "user_uid": argv[argv.index("--user-uid") + 1],
                "resource_uid": argv[argv.index("--resource-uid") + 1],
            }
            _ensure_keepercommander_version_for_apply()
            try:
                from keepercommander.commands.pam_saas.remove import PAMActionSaasRemoveCommand
            except (ImportError, AttributeError) as exc:
                raise CapabilityError(
                    reason=f"Commander PAMActionSaasRemoveCommand is unavailable: {exc}",
                    uid_ref=uid_ref_val,
                    resource_type="pamUser",
                    next_action=(
                        "upgrade keepercommander to a build with "
                        "keepercommander.commands.pam_saas.remove.PAMActionSaasRemoveCommand"
                    ),
                ) from exc

            def _run_remove() -> Any:
                params = self._get_keeper_params()
                return PAMActionSaasRemoveCommand().execute(params, **kwargs)

            try:
                self._with_keeper_session_refresh(_run_remove)
            except CapabilityError:
                raise
            except Exception as exc:
                raise CapabilityError(
                    reason=f"pamUser saas_plugins remove failed: {type(exc).__name__}: {exc}",
                    uid_ref=uid_ref_val,
                    resource_type="pamUser",
                    next_action=(
                        "verify pamUser, parent resource UIDs, and Commander session permissions"
                    ),
                ) from exc
            outcomes.append(
                ApplyOutcome(
                    uid_ref=uid_ref_val,
                    keeper_uid=kwargs["user_uid"],
                    action="saas_plugin_remove",
                    details={"command": argv, "kwargs": kwargs},
                )
            )

        return outcomes

    def _discover_folder_uids(self) -> list[str]:
        project_name = self._manifest_name
        if project_name:
            self._maybe_resolve_project_resources_folder(project_name)

        folder_uids: list[str] = []
        for folder_uid in (self._folder_uid, self.last_resolved_users_folder_uid):
            if folder_uid and folder_uid not in folder_uids:
                folder_uids.append(folder_uid)
        return folder_uids

    def _ensure_folder_exists(self, path: str) -> None:
        parent_path = self._folder_parent_path(path)
        if parent_path:
            self._ensure_folder_exists(parent_path)
        try:
            self._run_cmd(["ls", "--format", "json", path])
        except CapabilityError:
            self._run_cmd(["mkdir", "-uf", path])

    @staticmethod
    def _folder_parent_path(path: str) -> str | None:
        normalized = path.strip()
        if not normalized or normalized == "/":
            return None
        if len(normalized) > 1:
            normalized = normalized.rstrip("/")
        absolute = normalized.startswith("/")
        body = normalized[1:] if absolute else normalized
        components = _VaultMixin._commander_path_components(body)
        if len(components) <= 1:
            return None
        parent = "/".join(components[:-1])
        return f"/{parent}" if absolute else parent

    @staticmethod
    def _commander_path_components(path: str) -> list[str]:
        components: list[str] = []
        chars: list[str] = []
        index = 0
        while index < len(path):
            char = path[index]
            if char == "/":
                if index + 1 < len(path) and path[index + 1] == "/":
                    chars.append("//")
                    index += 2
                    continue
                components.append("".join(chars))
                chars = []
                index += 1
                continue
            chars.append(char)
            index += 1
        components.append("".join(chars))
        return [component for component in components if component]

    def _create_user_folder(
        self,
        *,
        path: str,
        parent_uid: str | None = None,
        color: str | None = None,
    ) -> str:
        _ = parent_uid
        parent_path = self._folder_parent_path(path)
        if parent_path:
            self._ensure_folder_exists(parent_path)
        args = ["mkdir", "-uf", path]
        if color is not None:
            args.extend(["--color", color])
        self._run_cmd(args)
        return self._resolve_folder_uid_by_path(path)

    def _create_shared_folder(
        self,
        *,
        path: str,
        manage_records: bool = True,
        manage_users: bool = True,
        can_edit: bool = True,
        can_share: bool = True,
    ) -> str:
        parent_path = self._folder_parent_path(path)
        if parent_path:
            self._ensure_folder_exists(parent_path)
        args = ["mkdir", "-sf"]
        if manage_records:
            args.append("--manage-records")
        if manage_users:
            args.append("--manage-users")
        if can_edit:
            args.append("--can-edit")
        if can_share:
            args.append("--can-share")
        args.append(path)
        self._run_cmd(args)
        return self._resolve_folder_uid_by_path(path)

    def _move_folder(self, *, source: str, destination: str, is_shared: bool = False) -> None:
        folder_flag = "--shared-folder" if is_shared else "--user-folder"
        self._run_cmd(["mv", folder_flag, source, destination])

    def _delete_folder(self, *, path_or_uid: str) -> None:
        self._run_cmd(["rmdir", "-f", path_or_uid])

    def _resolve_folder_uid_by_path(self, path: str) -> str:
        def resolve_once() -> str | None:
            from keepercommander import api
            from keepercommander.subfolder import (
                get_folder_uids,
            )

            params = self._get_keeper_params()
            api.sync_down(params)
            uids = sorted(uid for uid in get_folder_uids(params, path) if uid)
            return str(uids[0]) if uids else None

        try:
            uid = self._with_keeper_session_refresh(resolve_once)
        except Exception as exc:
            raise CapabilityError(
                reason=f"could not resolve folder path {path!r}: {type(exc).__name__}: {exc}",
                next_action="inspect the Commander folder tree and retry",
            ) from exc
        if uid:
            return uid
        raise CapabilityError(
            reason=f"Commander did not return folder UID for {path!r} after create",
            next_action="inspect `keeper ls -f --format json` and retry",
        )

    def _ensure_shared_folder_exists(self, path: str) -> None:
        try:
            self._run_cmd(["ls", "--format", "json", path])
        except CapabilityError:
            self._run_cmd(
                [
                    "mkdir",
                    "-sf",
                    "--manage-users",
                    "--manage-records",
                    "--can-edit",
                    "--can-share",
                    path,
                ]
            )

    def _vault_record_ref_for_uid(self, record_uid: str) -> str:
        try:
            raw = self._run_cmd(["get", record_uid, "--format", "json"])
            item = _load_json(raw, command="get <record_uid> --format json")
        except CapabilityError:
            return f"keeper-vault:records:{record_uid}"
        if not isinstance(item, dict):
            return f"keeper-vault:records:{record_uid}"
        marker = decode_marker(_extract_marker_field(item))
        uid_ref = marker.get("uid_ref") if isinstance(marker, dict) else None
        if isinstance(uid_ref, str) and uid_ref:
            return f"keeper-vault:records:{uid_ref}"
        return f"keeper-vault:records:{record_uid}"

    def _write_marker(self, keeper_uid: str, marker: dict[str, Any]) -> None:
        """Persist the ownership marker custom field on a record.

        Prefer the in-process Commander vault API — the bundled macOS
        `keeper` binary (17.1.14) doesn't know `record-update`, and Commander
        18.0.0's CLI uses a field-syntax (`custom.label=value`) that's
        fragile across versions. We already have KeeperParams available for
        the pam project import/extend path; reuse them.
        """
        payload = serialize_marker(marker)
        try:
            from keepercommander import api, record_management, vault
        except ImportError as exc:
            raise CapabilityError(
                reason=f"cannot write ownership marker: keepercommander unavailable: {exc}",
                next_action="install Commander Python package in the same interpreter as the SDK",
            ) from exc

        def write_once() -> None:
            params = self._get_keeper_params()
            api.sync_down(params)
            record = vault.KeeperRecord.load(params, keeper_uid)
            if not isinstance(record, vault.TypedRecord):
                raise CapabilityError(
                    reason=f"cannot write ownership marker: record {keeper_uid} is not a TypedRecord",
                    next_action="confirm the record type and retry",
                )

            existing = None
            for field in record.custom:
                if field_name_matches(field.label, MARKER_FIELD_LABEL):
                    existing = field
                    break
            if existing is not None:
                existing.type = "text"
                existing.value = [payload]
            else:
                new_field = vault.TypedField.new_field("text", payload, MARKER_FIELD_LABEL)
                record.custom.append(new_field)

            record_management.update_record(params, record)
            api.sync_down(params)

        try:
            self._with_keeper_session_refresh(write_once)
        except CapabilityError:
            raise
        except Exception as exc:
            raise CapabilityError(
                reason=f"cannot write ownership marker: {type(exc).__name__}: {exc}",
                next_action="inspect the Commander output above and retry",
            ) from exc
