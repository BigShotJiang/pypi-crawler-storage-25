"""Mixin — workflow_epm resource family of CommanderCliProvider.

Private implementation module. Not a public API.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from dsk.core.diff import ChangeKind
from dsk.core.errors import CapabilityError
from dsk.core.interfaces import ApplyOutcome
from dsk.core.models_policy import (
    AUDIT_POLICY,
    commander_enforcement_flags_for_policy,
    policy_role_identifier,
    policy_upstream_gap_reason,
)
from dsk.core.planner import Plan
from dsk.providers._commander.epm import (
    _epm_dry_run_outcome,
    _epm_policy_kwargs,
    _epm_policy_target,
)
from dsk.providers._commander.saas import (
    _saas_config_kwargs,
    _saas_dry_run_outcome,
    _saas_remove_kwargs,
    _saas_set_kwargs,
    _saas_update_kwargs,
)
from dsk.providers._commander.workflow import (
    _workflow_command_kwargs,
    _workflow_dry_run_outcome,
    _workflow_record,
)
from dsk.providers.commander_cli import (
    _plan_changes,
)

if TYPE_CHECKING:
    pass


def _ensure_keepercommander_version_for_apply() -> None:  # noqa: D103
    """Proxy — delegates to commander_cli so tests can monkeypatch there."""
    import dsk.providers.commander_cli as _cli_m  # noqa: PLC0415

    _cli_m._ensure_keepercommander_version_for_apply()


class _WorkflowEpmMixin:
    """Method carrier — workflow_epm resource family."""

    if TYPE_CHECKING:
        # Instance attrs
        _manifest_source: dict[str, Any]

        # Cross-mixin methods (transport)
        def _get_keeper_params(self) -> Any: ...
        def _with_keeper_session_refresh(self, fn: Any, *a: Any, **kw: Any) -> Any: ...
        # Cross-mixin methods (enterprise)
        def _apply_role_enforcements(self, *a: Any, **kw: Any) -> Any: ...

    def apply_workflow_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply ``keeper-workflow.v1`` rows through Commander ``pam workflow`` verbs."""
        outcomes: list[ApplyOutcome] = []
        command_classes: dict[str, Any] = {}
        for change in _plan_changes(plan):
            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or "blocked"},
                    )
                )
                continue

            if change.resource_type not in {
                "workflow",
                "workflow_config",
                "keeper_workflow",
            }:
                details: dict[str, Any] = {"dry_run": dry_run, "skipped": change.resource_type}
                if change.reason is not None:
                    details["reason"] = change.reason
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details=details,
                    )
                )
                continue

            if change.kind is ChangeKind.CREATE:
                kwargs = _workflow_command_kwargs(
                    change, self._manifest_source, include_defaults=True
                )
                if dry_run:
                    outcomes.append(_workflow_dry_run_outcome(change, kwargs, "create"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "create" not in command_classes:
                    try:
                        from keepercommander.commands.workflow.config_commands import (
                            WorkflowCreateCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander WorkflowCreateCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.workflow.config_commands.WorkflowCreateCommand"
                            ),
                        ) from exc
                    command_classes["create"] = WorkflowCreateCommand

                def _run_create() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["create"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_create)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"keeper-workflow.v1 create failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify the PAM record UID, approver emails, workflow settings, "
                            "and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=str(kwargs["record"]),
                        action="create",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            if change.kind is ChangeKind.UPDATE:
                kwargs = _workflow_command_kwargs(
                    change,
                    self._manifest_source,
                    include_defaults=False,
                )
                kwargs.pop("approver", None)
                if dry_run:
                    outcomes.append(_workflow_dry_run_outcome(change, kwargs, "update"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "update" not in command_classes:
                    try:
                        from keepercommander.commands.workflow.config_commands import (
                            WorkflowUpdateCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander WorkflowUpdateCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.workflow.config_commands.WorkflowUpdateCommand"
                            ),
                        ) from exc
                    command_classes["update"] = WorkflowUpdateCommand

                def _run_update() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["update"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_update)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"keeper-workflow.v1 update failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify the PAM record UID, workflow settings, "
                            "and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=str(kwargs["record"]),
                        action="update",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            if change.kind is ChangeKind.DELETE:
                kwargs = {"record": _workflow_record(change)}
                if dry_run:
                    outcomes.append(_workflow_dry_run_outcome(change, kwargs, "delete"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "delete" not in command_classes:
                    try:
                        from keepercommander.commands.workflow.config_commands import (
                            WorkflowDeleteCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander WorkflowDeleteCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.workflow.config_commands.WorkflowDeleteCommand"
                            ),
                        ) from exc
                    command_classes["delete"] = WorkflowDeleteCommand

                def _run_delete() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["delete"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_delete)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"keeper-workflow.v1 delete failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action="verify the PAM record UID and Commander session permissions",
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=str(kwargs["record"]),
                        action="delete",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                    details={"dry_run": dry_run, "skipped": change.kind.value},
                )
            )
        return outcomes

    def apply_saas_rotation_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply ``keeper-saas-rotation.v1`` rows through Commander ``pam action saas``."""
        outcomes: list[ApplyOutcome] = []
        command_classes: dict[str, Any] = {}
        for change in _plan_changes(plan):
            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or "blocked"},
                    )
                )
                continue

            if change.kind is ChangeKind.CREATE and change.resource_type == "saas_rotation_config":
                kwargs = _saas_config_kwargs(change)
                if dry_run:
                    outcomes.append(_saas_dry_run_outcome(change, kwargs, "create"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "config" not in command_classes:
                    try:
                        from keepercommander.commands.pam_saas.config import (
                            PAMActionSaasConfigCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander PAMActionSaasConfigCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.pam_saas.config.PAMActionSaasConfigCommand"
                            ),
                        ) from exc
                    command_classes["config"] = PAMActionSaasConfigCommand

                def _run_config() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["config"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_config)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=(
                            f"keeper-saas-rotation.v1 config create failed: "
                            f"{type(exc).__name__}: {exc}"
                        ),
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify the gateway, PAM configuration UID, shared folder UID, "
                            "SaaS plugin name, and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="create",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            if change.kind is ChangeKind.CREATE and change.resource_type == "saas_rotation_binding":
                kwargs = _saas_set_kwargs(change)
                if dry_run:
                    outcomes.append(_saas_dry_run_outcome(change, kwargs, "set"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "set" not in command_classes:
                    try:
                        from keepercommander.commands.pam_saas.set import (
                            PAMActionSaasSetCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander PAMActionSaasSetCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.pam_saas.set.PAMActionSaasSetCommand"
                            ),
                        ) from exc
                    command_classes["set"] = PAMActionSaasSetCommand

                def _run_set() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["set"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_set)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=(
                            f"keeper-saas-rotation.v1 binding set failed: "
                            f"{type(exc).__name__}: {exc}"
                        ),
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify the PAM user record UID, SaaS configuration record UID, "
                            "and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=str(kwargs["user_uid"]),
                        action="create",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            if change.kind is ChangeKind.UPDATE:
                kwargs = _saas_update_kwargs(change)
                if dry_run:
                    outcomes.append(_saas_dry_run_outcome(change, kwargs, "update"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "update" not in command_classes:
                    try:
                        from keepercommander.commands.pam_saas.update import (
                            PAMActionSaasUpdateCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander PAMActionSaasUpdateCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.pam_saas.update.PAMActionSaasUpdateCommand"
                            ),
                        ) from exc
                    command_classes["update"] = PAMActionSaasUpdateCommand

                def _run_update() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["update"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_update)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=(
                            f"keeper-saas-rotation.v1 update failed: {type(exc).__name__}: {exc}"
                        ),
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify the gateway, configuration/config-record UID, "
                            "and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="update",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            if change.kind is ChangeKind.DELETE:
                kwargs = _saas_remove_kwargs(change)
                if dry_run:
                    outcomes.append(_saas_dry_run_outcome(change, kwargs, "delete"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "remove" not in command_classes:
                    try:
                        from keepercommander.commands.pam_saas.remove import (
                            PAMActionSaasRemoveCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander PAMActionSaasRemoveCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.pam_saas.remove.PAMActionSaasRemoveCommand"
                            ),
                        ) from exc
                    command_classes["remove"] = PAMActionSaasRemoveCommand

                def _run_remove() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["remove"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_remove)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=(
                            f"keeper-saas-rotation.v1 remove failed: {type(exc).__name__}: {exc}"
                        ),
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify the PAM user/resource record UID and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=str(kwargs["user_uid"]),
                        action="delete",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                    details={"dry_run": dry_run, "skipped": change.kind.value},
                )
            )
        return outcomes

    def apply_epm_policy_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply ``epm-policy.v1`` / policy rows from ``keeper-epm.v1`` through PEDM."""
        outcomes: list[ApplyOutcome] = []
        command_classes: dict[str, Any] = {}
        for change in _plan_changes(plan):
            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or "blocked"},
                    )
                )
                continue

            if change.resource_type not in {"epm_policy", "epm_policy_rule"}:
                details: dict[str, Any] = {"dry_run": dry_run, "skipped": change.resource_type}
                if change.reason is not None:
                    details["reason"] = change.reason
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details=details,
                    )
                )
                continue

            if change.kind is ChangeKind.CREATE:
                kwargs = _epm_policy_kwargs(change, for_update=False)
                if dry_run:
                    outcomes.append(_epm_dry_run_outcome(change, kwargs, "create"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "add" not in command_classes:
                    try:
                        from keepercommander.commands.pedm.pedm_admin import (
                            PedmPolicyAddCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander PedmPolicyAddCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.pedm.pedm_admin.PedmPolicyAddCommand"
                            ),
                        ) from exc
                    command_classes["add"] = PedmPolicyAddCommand

                def _run_add() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["add"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_add)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"EPM policy create failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify PEDM admin permissions, policy type/control/status, "
                            "and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="create",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            if change.kind is ChangeKind.UPDATE:
                kwargs = _epm_policy_kwargs(change, for_update=True)
                if dry_run:
                    outcomes.append(_epm_dry_run_outcome(change, kwargs, "update"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "edit" not in command_classes:
                    try:
                        from keepercommander.commands.pedm.pedm_admin import (
                            PedmPolicyEditCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander PedmPolicyEditCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.pedm.pedm_admin.PedmPolicyEditCommand"
                            ),
                        ) from exc
                    command_classes["edit"] = PedmPolicyEditCommand

                def _run_edit() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["edit"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_edit)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"EPM policy update failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify PEDM admin permissions, target policy UID/name, "
                            "policy type/control/status, and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or _epm_policy_target(change),
                        action="update",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            if change.kind is ChangeKind.DELETE:
                kwargs = {"policy": [_epm_policy_target(change)]}
                if dry_run:
                    outcomes.append(_epm_dry_run_outcome(change, kwargs, "delete"))
                    continue
                _ensure_keepercommander_version_for_apply()
                if "delete" not in command_classes:
                    try:
                        from keepercommander.commands.pedm.pedm_admin import (
                            PedmPolicyDeleteCommand,
                        )
                    except (ImportError, AttributeError) as exc:
                        raise CapabilityError(
                            reason=f"Commander PedmPolicyDeleteCommand is unavailable: {exc}",
                            uid_ref=change.uid_ref,
                            resource_type=change.resource_type,
                            next_action=(
                                "upgrade keepercommander to a build with "
                                "keepercommander.commands.pedm.pedm_admin.PedmPolicyDeleteCommand"
                            ),
                        ) from exc
                    command_classes["delete"] = PedmPolicyDeleteCommand

                def _run_delete() -> Any:
                    params = self._get_keeper_params()
                    command = command_classes["delete"]()
                    return command.execute(params, **kwargs)

                try:
                    self._with_keeper_session_refresh(_run_delete)
                except CapabilityError:
                    raise
                except Exception as exc:
                    raise CapabilityError(
                        reason=f"EPM policy delete failed: {type(exc).__name__}: {exc}",
                        uid_ref=change.uid_ref,
                        resource_type=change.resource_type,
                        next_action=(
                            "verify PEDM admin permissions, target policy UID/name, "
                            "and Commander session permissions"
                        ),
                        context={"kwargs": kwargs},
                    ) from exc
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or kwargs["policy"][0],
                        action="delete",
                        details={"dry_run": False, "kwargs": kwargs},
                    )
                )
                continue

            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or "",
                    action="noop",
                    details={"dry_run": dry_run, "skipped": change.kind.value},
                )
            )
        return outcomes

    def apply_policy_plan(self, plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Apply ``keeper-policy.v1`` rows through enterprise role enforcements."""

        outcomes: list[ApplyOutcome] = []
        for change in _plan_changes(plan):
            if change.kind is ChangeKind.CONFLICT:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="conflict",
                        details={"reason": change.reason or "blocked"},
                    )
                )
                continue

            if change.resource_type == AUDIT_POLICY:
                reason = policy_upstream_gap_reason(change.resource_type, change.title) or (
                    "audit-policy is upstream-gap on Commander 18.0.0"
                )
                if dry_run:
                    outcomes.append(
                        ApplyOutcome(
                            uid_ref=change.uid_ref or "",
                            keeper_uid=change.keeper_uid or "",
                            action="conflict",
                            details={"dry_run": True, "reason": reason},
                        )
                    )
                    continue
                raise CapabilityError(
                    reason=reason,
                    uid_ref=change.uid_ref,
                    resource_type=change.resource_type,
                    next_action=(
                        "use `dsk validate` / mock provider for audit-policy scaffolds "
                        "until Commander exposes an audit policy writer"
                    ),
                )

            if change.kind not in (ChangeKind.CREATE, ChangeKind.UPDATE, ChangeKind.DELETE):
                details: dict[str, Any] = {"dry_run": dry_run, "skipped": change.kind.value}
                if change.reason is not None:
                    details["reason"] = change.reason
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or "",
                        action="noop",
                        details=details,
                    )
                )
                continue

            payload = change.before if change.kind is ChangeKind.DELETE else change.after
            role_identifier = policy_role_identifier(payload)
            if not role_identifier:
                raise CapabilityError(
                    reason=f"{change.resource_type} requires role_uid_ref, role_id, or role_name",
                    uid_ref=change.uid_ref,
                    resource_type=change.resource_type,
                    next_action=(
                        "set role_uid_ref to the target enterprise role ref, or provide "
                        "role_id / role_name for Commander apply"
                    ),
                )
            enforcement_flags = commander_enforcement_flags_for_policy(
                change.resource_type,
                payload,
                remove=change.kind is ChangeKind.DELETE,
            )
            if dry_run:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or role_identifier,
                        action=change.kind.value,
                        details={
                            "dry_run": True,
                            "role": role_identifier,
                            "enforcements": enforcement_flags,
                        },
                    )
                )
                continue
            if not enforcement_flags:
                outcomes.append(
                    ApplyOutcome(
                        uid_ref=change.uid_ref or "",
                        keeper_uid=change.keeper_uid or role_identifier,
                        action="noop",
                        details={"dry_run": False, "role": role_identifier, "skipped": "empty"},
                    )
                )
                continue
            self._apply_role_enforcements(role_identifier, enforcement_flags)
            outcomes.append(
                ApplyOutcome(
                    uid_ref=change.uid_ref or "",
                    keeper_uid=change.keeper_uid or role_identifier,
                    action=change.kind.value,
                    details={
                        "dry_run": False,
                        "role": role_identifier,
                        "enforcements": enforcement_flags,
                    },
                )
            )
        return outcomes

    def apply_privileged_access_plan(
        self,
        _plan: Plan,
        *,
        dry_run: bool = False,
    ) -> list[ApplyOutcome]:
        """Declarative privileged-access apply is unsupported — use PAM operation-first verbs."""
        _ = dry_run

        raise CapabilityError(
            reason=(
                "keeper-privileged-access.v1 apply is not implemented on CommanderCliProvider "
                "(PAM privileged access has no declarative Commander surface today)"
            ),
            next_action=(
                "keeper pam tunnel / keeper pam access (operation-first; not declarative-shaped)"
            ),
        )

    def _manifest_source_is_ai_agent(self, plan: object) -> bool:
        """True when ``manifest_source`` declares the AI capability manifest schema."""
        src = self._manifest_source
        if src is None:
            return False
        if hasattr(src, "model_dump"):
            data = src.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif isinstance(src, dict):
            data = src
        else:
            data = {}
        return data.get("schema") == "ai-agent.v1"

    def _manifest_source_is_nhi(self, plan: object) -> bool:
        """True when ``manifest_source`` declares the NHI capability manifest schema."""
        src = self._manifest_source
        if src is None:
            return False
        if hasattr(src, "model_dump"):
            data = src.model_dump(mode="python", exclude_none=True, by_alias=True)
        elif isinstance(src, dict):
            data = src
        else:
            data = {}
        return data.get("schema") == "nhi-agent.v1"

    def apply_ai_agent_plan(self, _plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Raise until the NHI / AI identity Commander surface GA (no declarative hooks yet)."""
        _ = dry_run
        raise CapabilityError(
            reason=(
                "ai-agent.v1 declarative apply is unavailable: Commander awaits the NHI PAM identity API GA."
            ),
            next_action="pending NHI PAM API GA — monitor Keeper product announcements",
        )

    def apply_nhi_plan(self, _plan: Plan, *, dry_run: bool = False) -> list[ApplyOutcome]:
        """Raise until NHI declarative Commander hooks GA (upstream product dependency)."""
        _ = dry_run
        raise CapabilityError(
            reason=(
                "nhi-agent.v1 declarative apply is unavailable: Commander awaits the NHI PAM identity API GA."
            ),
            next_action="pending NHI PAM API GA — monitor Keeper product announcements",
        )
