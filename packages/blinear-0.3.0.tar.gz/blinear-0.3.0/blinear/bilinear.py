# blinear/bilinear.py

import tensorflow as tf
from tensorflow.keras import layers


# =========================================================
# HIROTA BILINEAR LAYER
# (rename from BilinearLayer → HirotaBilinear)
# =========================================================
class HirotaBilinear(layers.Layer):
    def __init__(self, units, r=32, activation=None):
        super(HirotaBilinear, self).__init__()

        self.units = units
        self.r = r
        self.activation = tf.keras.activations.get(activation)

    def build(self, input_shape):
        d_f = int(input_shape[0][-1])
        d_g = int(input_shape[1][-1])

        # =================================================
        # Full bilinear term
        # =================================================
        self.W1 = self.add_weight(
            name="W1",
            shape=(d_f, self.units),
            initializer="glorot_uniform",
            dtype=tf.float32,
            trainable=True
        )

        self.W2 = self.add_weight(
            name="W2",
            shape=(d_g, self.units),
            initializer="glorot_uniform",
            dtype=tf.float32,
            trainable=True
        )

        # =================================================
        # Low-rank bilinear term
        # =================================================
        self.W3 = self.add_weight(
            name="W3",
            shape=(d_f, self.r),
            initializer="glorot_uniform",
            dtype=tf.float32,
            trainable=True
        )

        self.W4 = self.add_weight(
            name="W4",
            shape=(d_g, self.r),
            initializer="glorot_uniform",
            dtype=tf.float32,
            trainable=True
        )

        self.V = self.add_weight(
            name="V",
            shape=(self.r, self.units),
            initializer="glorot_uniform",
            dtype=tf.float32,
            trainable=True
        )

        # =================================================
        # Bias
        # =================================================
        self.b = self.add_weight(
            name="bias",
            shape=(self.units,),
            initializer="zeros",
            dtype=tf.float32,
            trainable=True
        )

        super(HirotaBilinear, self).build(input_shape)

    def call(self, inputs):
        f, g = inputs

        f = tf.cast(f, tf.float32)
        g = tf.cast(g, tf.float32)

        # =================================================
        # Full bilinear interaction
        # =================================================
        h = tf.matmul(f, self.W1) * tf.matmul(g, self.W2)

        # =================================================
        # Low-rank bilinear refinement
        # =================================================
        b_low = tf.matmul(f, self.W3) * tf.matmul(g, self.W4)
        b_low = tf.matmul(b_low, self.V)

        # =================================================
        # Final output
        # =================================================
        out = h + b_low + self.b

        if self.activation is not None:
            return self.activation(out)

        return out
BilinearLayer = HirotaBilinear