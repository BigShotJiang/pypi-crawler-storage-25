# blinear/__init__.py

from .bilinear import BilinearLayer
from .convbilinear import ConvBilinear
from .ogd import OGDLayer

from .models import (
    build_hirota_model,
    build_conv_hirota_model,
    build_double_bilinear,
    build_conv_hirota_ogd
)

from .version import __version__

__all__ = [
    # Main Layers
    "BilinearLayer",
    "ConvBilinear",
    "OGDLayer",

    # Models
    "build_hirota_model",
    "build_conv_hirota_model",
    "build_double_bilinear",
    "build_conv_hirota_ogd",

    # Version
    "__version__",
]