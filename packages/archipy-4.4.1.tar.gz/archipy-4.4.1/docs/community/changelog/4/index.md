---
title: "4.x Changelog"
description: "Release history for ArchiPy 4.x series"
---

# 4.x Changelog

[↑ All versions](../index.md)

| Version           | Date       | Summary                                                                                         |
|-------------------|------------|-------------------------------------------------------------------------------------------------|
| [4.4.1](4.4.1.md) | 2026-04-06 | Dependency refresh, regenerated lockfile, and typing cleanups for Keycloak and atomic decorator |
| [4.4.0](4.4.0.md) | 2026-03-13 | Async Kafka producer and consumer adapters, async BDD step refactor                             |
| [4.3.6](4.3.6.md) | 2026-03-13 | SQLAlchemy filter type expansion, docs overhaul, CI pipeline fixes                              |
| [4.3.5](4.3.5.md) | 2026-03-10 | SSL Config Typing: Improved type safety and optional-field handling for SSL configuration in... |
| [4.3.4](4.3.4.md) | 2026-02-24 | BaseError `__str__` Enhancement: Improved string representation to expose full error context    |
| [4.3.3](4.3.3.md) | 2026-02-23 | Type-Safe Field References: Reverted the experimental type-safe field references feature        |
| [4.3.1](4.3.1.md) | 2026-02-22 | Boto3 Migration: Migrated MinIO adapter from minio library to boto3                             |
| [4.3.0](4.3.0.md) | 2026-02-22 | Prometheus Utilities: Added shared Prometheus server management module                          |
| [4.2.0](4.2.0.md) | 2026-02-21 | Metric Interceptors: Enhanced Prometheus metrics collection across frameworks                   |
| [4.1.0](4.1.0.md) | 2026-02-09 | Organization Management: Implemented comprehensive organization management functionality        |
| [4.0.4](4.0.4.md) | 2026-01-31 | Enhanced Exception Handling: Improved exception handling in SQLAlchemy atomic decorators        |
| [4.0.3](4.0.3.md) | 2026-01-24 | Add PostgreSQL and SQLite support for atomic transaction tests                                  |
| [4.0.2](4.0.2.md) | 2025-12-11 | Broadened Ruff configuration (additional ignores, per-file overrides, relaxed limits) a...      |
| [4.0.1](4.0.1.md) | 2025-12-10 | Comprehensive Cache Decorator BDD Tests: Added extensive BDD test suite for cache decorators    |
| [4.0.0](4.0.0.md) | 2025-12-08 | Error System Migration to T-Strings: Refactored error system to use t-string template format... |
