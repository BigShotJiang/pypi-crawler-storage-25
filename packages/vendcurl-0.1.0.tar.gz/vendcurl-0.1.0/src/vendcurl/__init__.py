"""vendcurl: fetch, validate, and vendor remote artifacts into S3-compatible storage."""

__version__ = "0.1.0"
