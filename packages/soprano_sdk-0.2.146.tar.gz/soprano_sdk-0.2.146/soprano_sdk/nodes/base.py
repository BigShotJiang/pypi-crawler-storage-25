from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Dict, Any, Callable, List, TYPE_CHECKING

from langgraph.errors import GraphInterrupt

from ..core.constants import WorkflowKeys, ActionType
from ..utils.logger import logger

if TYPE_CHECKING:
    from ..core.engine import WorkflowEngine


class ActionStrategy(ABC):
    def __init__(self, step_config: Dict[str, Any], engine_context: WorkflowEngine):
        self.step_config = step_config
        self.engine_context = engine_context
        self.step_id = step_config.get('id')
        self.action = step_config.get('action')

    @abstractmethod
    def execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    def pre_execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass

    def get_node_function(self) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
        def node_fn(state: Dict[str, Any]) -> Dict[str, Any]:
            initial_status = state.get(WorkflowKeys.STATUS)
            logger.info(f"Executing node: {self.step_id} (action: {self.action})")
            try:
                self.pre_execute(state)
                result = self.execute(state)
                logger.info(f"Node {self.step_id} completed successfully")
                # logger.debug(f"Result: {result}")

                if (
                    result.get(WorkflowKeys.ERROR) and
                    not result.get(WorkflowKeys.OUTCOME_ID) and
                    (result.get(WorkflowKeys.STATUS) == initial_status or
                     "_failed" in str(result.get(WorkflowKeys.STATUS)) or
                     "_error" in str(result.get(WorkflowKeys.STATUS)))
                ):
                    result[WorkflowKeys.OUTCOME_ID] = WorkflowKeys.ERROR
                    result[WorkflowKeys.STATUS] = f'{self.step_id}_{WorkflowKeys.ERROR}'
                return result
            except GraphInterrupt:
                raise
            except Exception as e:
                logger.error(f"Node {self.step_id} failed: {e}", exc_info=True)
                self._set_status(state, WorkflowKeys.ERROR)

                # Use custom error message from engine context if available
                failure_message = getattr(self.engine_context, 'failure_message', None)
                error_message = state.get(WorkflowKeys.ERROR) or failure_message or f"Unable to complete the request: {str(e)}"

                state[WorkflowKeys.ERROR] = error_message
                state[WorkflowKeys.OUTCOME_ID] = WorkflowKeys.ERROR
                return state

        return node_fn

    def _get_transitions(self) -> List[Dict[str, Any]]:
        return self.step_config.get('transitions', [])

    def _get_next_step(self) -> str:
        return self.step_config.get('next')

    def _set_status(self, state: Dict[str, Any], status_suffix: str):
        state[WorkflowKeys.STATUS] = f'{self.step_id}_{status_suffix}'

    def _set_outcome(self, state: Dict[str, Any], outcome_id: str):
        state[WorkflowKeys.OUTCOME_ID] = outcome_id

    def _rollback_state_to_node(
        self,
        state: Dict[str, Any],
        target_node: str,
        preserve_conversations: bool = False
    ) -> Dict[str, Any]:
        """Rollback state to the target node, clearing future data."""
        logger.info(
            f"[ROLLBACK] {self.step_id} -> {target_node} | "
            f"strategy={self.rollback_strategy.get_strategy_name()}, "
            f"preserve_conversations={preserve_conversations}"
        )
        current_user_message = state.get(WorkflowKeys.USER_MESSAGE, "")
        is_user_message_utilized = state.get(WorkflowKeys.USER_MESSAGE_UTILIZED, False)
        node_execution_order = state.get(WorkflowKeys.NODE_EXECUTION_ORDER, [])
        node_field_map = state.get(WorkflowKeys.NODE_FIELD_MAP, {})
        workflow_steps = self.engine_context.steps

        restored_state = self.rollback_strategy.rollback_to_node(
            state=state,
            target_node=target_node,
            node_execution_order=node_execution_order,
            node_field_map=node_field_map,
            workflow_steps=workflow_steps,
            preserve_conversations=preserve_conversations
        )

        agentic_nodes = ActionType.get_agentic_nodes()

        agentic_fields_collected = set()
        for node in self.engine_context.steps:
            if node.get('action') in agentic_nodes:
                # Add single field if present
                field = node.get('field')
                if field:
                    agentic_fields_collected.add(field)

                # Add multiple fields if present
                fields = node.get('fields')
                if isinstance(fields, list):
                    agentic_fields_collected.update(fields)

        for key, value in restored_state.items():
            if key in agentic_fields_collected:
                logger.info(f"Stopping agent-collected field '{key}' from being set with '{value}' during rollback")
                self.engine_context.remove_context_field(key)
                continue
            context_value = self.engine_context.get_context_value(key)
            if context_value is not None:
                restored_state[key] = context_value

        if not restored_state:
            logger.warning(f"Rollback strategy returned empty state for node '{target_node}'")
            return None

        restored_state[WorkflowKeys.STATUS] = f"{self.step_id}_{target_node}"
        restored_state[WorkflowKeys.USER_MESSAGE] = current_user_message
        restored_state[WorkflowKeys.USER_MESSAGE_UTILIZED] = is_user_message_utilized

        return restored_state

    def _filter_hidden_tools(self, available_tools: set) -> set:
        """Filter out tools that are marked as hidden from prompt context."""
        if not hasattr(self.engine_context, 'config'):
            return available_tools

        tool_definitions = self.engine_context.config.get("tool_config", {}).get("tools", [])
        if not tool_definitions:
            return available_tools

        hidden_tools = {
            td["name"] for td in tool_definitions
            if td.get("name") in available_tools
            and not td.get("include_response_in_prompt", True)
        }
        return available_tools - hidden_tools
