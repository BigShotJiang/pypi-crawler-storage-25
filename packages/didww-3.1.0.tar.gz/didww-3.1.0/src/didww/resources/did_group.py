from didww.enums import Feature
from didww.resources.base import DidwwApiModel, EnumListAttributeField, SafeAttributeField, RelationField, ReadOnlyRepository


class DidGroup(DidwwApiModel):
    prefix = SafeAttributeField("prefix")
    features = EnumListAttributeField("features", Feature)
    is_metered = SafeAttributeField("is_metered")
    area_name = SafeAttributeField("area_name")
    allow_additional_channels = SafeAttributeField("allow_additional_channels")
    service_restrictions = SafeAttributeField("service_restrictions")

    country = RelationField("country")
    region = RelationField("region")
    city = RelationField("city")
    did_group_type = RelationField("did_group_type")
    stock_keeping_units = RelationField("stock_keeping_units")
    address_requirement = RelationField("address_requirement")

    class Meta:
        type = "did_groups"


class DidGroupRepository(ReadOnlyRepository):
    _resource_class = DidGroup
    _path = "did_groups"
