"""
Tests for MCP Apps dual-mode support (in-memory state, structuredContent, _owg_action).
"""

from __future__ import annotations

import asyncio
import os
import sys
import threading
from unittest import mock

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import mcp_server
from mcp_server import (
    AppModeState,
    _check_host_supports_ui,
    _get_app_state,
    _is_app_mode,
    _make_merge_validator,
    _owg_action,
    _reset_mode,
    _resolve_mode,
    openwebgoggles,
    openwebgoggles_close,
    openwebgoggles_read,
    openwebgoggles_status,
    openwebgoggles_update,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_app_mode():
    """Reset app mode globals before each test."""
    old_host = mcp_server._host_fetched_ui_resource
    old_pending = mcp_server._reload_pending
    old_active = mcp_server._active_tool_calls
    old_gate = mcp_server._security_gate
    old_cached_mode = mcp_server._cached_mode
    old_manager = mcp_server._session_manager

    mcp_server._host_fetched_ui_resource = False
    mcp_server._reload_pending = False
    mcp_server._active_tool_calls = 0
    mcp_server._cached_mode = None
    mcp_server._session_manager = mcp_server.SessionManager()

    yield

    mcp_server._host_fetched_ui_resource = old_host
    mcp_server._reload_pending = old_pending
    mcp_server._active_tool_calls = old_active
    mcp_server._security_gate = old_gate
    mcp_server._cached_mode = old_cached_mode
    mcp_server._session_manager = old_manager


def _enable_app_mode():
    """Enable MCP Apps mode by setting the cached mode and host-fetched flag."""
    mcp_server._cached_mode = "app"
    mcp_server._host_fetched_ui_resource = True


# ---------------------------------------------------------------------------
# AppModeState
# ---------------------------------------------------------------------------


class TestAppModeState:
    def test_write_state_increments_version(self):
        """write_state increments state_version on each call."""
        ams = AppModeState()
        ams.write_state({"title": "A"})
        v1 = ams.state_version
        ams.write_state({"title": "B"})
        v2 = ams.state_version
        assert v2 == v1 + 1

    def test_write_state_stores_data(self):
        """write_state stores the state dict and stamps version into it."""
        ams = AppModeState()
        ams.write_state({"title": "Hello"})
        assert ams.state["title"] == "Hello"
        assert ams.state["version"] == ams.state_version

    def test_merge_state_deep_merges(self):
        """merge_state deep-merges a partial dict into existing state."""
        ams = AppModeState()
        ams.write_state({"title": "Root", "data": {"sections": [], "meta": {"a": 1, "b": 2}}})
        merged = ams.merge_state({"data": {"meta": {"b": 99, "c": 3}}})
        assert merged["title"] == "Root"
        assert merged["data"]["meta"]["a"] == 1
        assert merged["data"]["meta"]["b"] == 99
        assert merged["data"]["meta"]["c"] == 3

    def test_merge_state_with_validator(self):
        """merge_state calls the validator with the merged result."""
        ams = AppModeState()
        ams.write_state({"title": "Root"})
        validator = mock.MagicMock()
        ams.merge_state({"status": "ok"}, validator=validator)
        validator.assert_called_once()
        call_arg = validator.call_args[0][0]
        assert call_arg["title"] == "Root"
        assert call_arg["status"] == "ok"

    def test_merge_state_validator_rejects(self):
        """merge_state propagates ValueError from validator."""
        ams = AppModeState()
        ams.write_state({"title": "Root"})

        def bad_validator(merged):
            raise ValueError("Nope")

        with pytest.raises(ValueError, match="Nope"):
            ams.merge_state({"bad": True}, validator=bad_validator)

    def test_add_and_read_actions(self):
        """add_action stores actions, read_actions returns them."""
        ams = AppModeState()
        ams.add_action({"action_id": "a", "type": "approve"})
        ams.add_action({"action_id": "b", "type": "reject"})
        actions = ams.read_actions()
        assert len(actions) == 2
        assert actions[0]["action_id"] == "a"
        assert actions[1]["action_id"] == "b"

    def test_clear_actions(self):
        """clear_actions empties the action queue."""
        ams = AppModeState()
        ams.add_action({"action_id": "x"})
        ams.clear_actions()
        assert ams.read_actions() == []

    def test_clear_resets_everything(self):
        """clear() resets state and actions; version resets to a fresh epoch-ms timestamp."""
        ams = AppModeState()
        ams.write_state({"title": "T"})
        ams.add_action({"action_id": "x"})
        ams.clear()
        assert ams.state == {}
        # Version is reset to a new epoch-ms baseline (not zero), so the next write
        # always produces a version larger than any iframe's remembered state.
        assert ams.state_version > 0
        # A subsequent write must still increment beyond the reset baseline
        ams.write_state({"title": "new"})
        assert ams.state_version == ams.state["version"]
        assert ams.read_actions() == []

    def test_concurrent_action_adds(self):
        """Concurrent add_action calls from multiple threads are safe."""
        ams = AppModeState()
        errors = []

        def add_many(n):
            try:
                for i in range(n):
                    ams.add_action({"action_id": f"t-{threading.current_thread().name}-{i}"})
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=add_many, args=(10,)) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(ams.read_actions()) == 100


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


class TestAppModeHelpers:
    def test_is_app_mode_false_by_default(self):
        """_is_app_mode() returns False when no mode is set."""
        assert _is_app_mode() is False

    def test_is_app_mode_true_after_flag(self):
        """_is_app_mode() returns True after the cached mode is set to 'app'."""
        _enable_app_mode()
        assert _is_app_mode() is True

    def test_is_app_mode_true_via_host_fetched(self):
        """_is_app_mode() returns True when only _host_fetched_ui_resource is set."""
        mcp_server._host_fetched_ui_resource = True
        assert _is_app_mode() is True

    def test_get_app_state_creates_singleton(self):
        """_get_app_state() returns the same object on repeated calls."""
        s1 = _get_app_state()
        s2 = _get_app_state()
        assert s1 is s2

    def test_make_merge_validator_none_without_gate(self):
        """_make_merge_validator() returns None when _security_gate is None."""
        mcp_server._security_gate = None
        assert _make_merge_validator() is None

    def test_make_merge_validator_returns_callable(self):
        """_make_merge_validator() returns a callable when _security_gate is present."""
        gate = mock.MagicMock()
        gate.validate_state.return_value = (True, None, {})
        mcp_server._security_gate = gate
        validator = _make_merge_validator()
        assert callable(validator)
        # Calling it should not raise when gate says valid
        validator({"title": "OK"})
        gate.validate_state.assert_called_once()


# ---------------------------------------------------------------------------
# Mode detection
# ---------------------------------------------------------------------------


class TestModeDetection:
    def test_resolve_mode_defaults_to_browser(self):
        """_resolve_mode(None) returns 'browser' when nothing is cached."""
        assert _resolve_mode(None) == "browser"

    def test_resolve_mode_caches_app(self):
        """_resolve_mode caches 'app' when host supports UI."""
        mcp_server._host_fetched_ui_resource = True
        assert _resolve_mode(None) == "app"
        assert mcp_server._cached_mode == "app"

    def test_resolve_mode_cached_value(self):
        """_resolve_mode returns cached mode without re-checking."""
        mcp_server._cached_mode = "app"
        # Even with _host_fetched_ui_resource = False, cached mode wins
        assert _resolve_mode(None) == "app"

    def test_resolve_mode_browser_with_ctx(self):
        """_resolve_mode caches 'browser' when ctx is provided but no UI support."""
        mock_ctx = mock.MagicMock()
        mock_ctx.session.client_params.capabilities = mock.MagicMock()
        mock_ctx.session.client_params.capabilities.experimental = None
        # No extensions attribute means no UI support
        del mock_ctx.session.client_params.capabilities.extensions
        result = _resolve_mode(mock_ctx)
        assert result == "browser"
        assert mcp_server._cached_mode == "browser"

    def test_resolve_mode_app_via_capabilities(self):
        """_resolve_mode detects app mode via client capabilities extensions."""
        mock_ctx = mock.MagicMock()
        mock_caps = mock.MagicMock()
        mock_caps.extensions = {"io.modelcontextprotocol/ui": {}}
        mock_caps.experimental = None
        mock_ctx.session.client_params.capabilities = mock_caps
        result = _resolve_mode(mock_ctx)
        assert result == "app"
        assert mcp_server._cached_mode == "app"

    def test_resolve_mode_app_via_experimental(self):
        """_resolve_mode detects app mode via experimental capabilities."""
        mock_ctx = mock.MagicMock()
        mock_caps = mock.MagicMock()
        # No extensions attribute
        del mock_caps.extensions
        mock_caps.experimental = {"io.modelcontextprotocol/ui": {}}
        mock_ctx.session.client_params.capabilities = mock_caps
        result = _resolve_mode(mock_ctx)
        assert result == "app"
        assert mcp_server._cached_mode == "app"

    def test_check_host_supports_ui_no_ctx(self):
        """_check_host_supports_ui returns False with no ctx and no flag."""
        assert _check_host_supports_ui(None) is False

    def test_check_host_supports_ui_fallback_to_flag(self):
        """_check_host_supports_ui falls back to _host_fetched_ui_resource."""
        mcp_server._host_fetched_ui_resource = True
        assert _check_host_supports_ui(None) is True

    def test_check_host_supports_ui_ctx_exception(self):
        """_check_host_supports_ui handles exceptions gracefully."""
        mock_ctx = mock.MagicMock()
        mock_ctx.session.client_params.capabilities = mock.PropertyMock(
            side_effect=AttributeError("no capabilities"),
        )
        assert _check_host_supports_ui(mock_ctx) is False

    def test_reset_mode(self):
        """_reset_mode clears the cached mode."""
        mcp_server._cached_mode = "app"
        _reset_mode()
        assert mcp_server._cached_mode is None

    def test_dynamic_app_resource_sets_cached_mode(self):
        """dynamic_app_resource() sets _cached_mode to 'app'."""
        with mock.patch("mcp_server._get_bundled_html", return_value="<html></html>"):
            mcp_server.dynamic_app_resource()
        assert mcp_server._cached_mode == "app"
        assert mcp_server._host_fetched_ui_resource is True

    def test_server_advertises_ui_extension(self):
        """Server capabilities include io.modelcontextprotocol/ui extension."""
        init_opts = mcp_server.mcp._mcp_server.create_initialization_options()
        caps = init_opts.capabilities
        assert hasattr(caps, "extensions"), "ServerCapabilities must include extensions field"
        assert "io.modelcontextprotocol/ui" in caps.extensions
        assert "mimeTypes" in caps.extensions["io.modelcontextprotocol/ui"]

    def test_local_agent_mode_client_triggers_app_mode(self):
        """'local-agent-mode-*' client name triggers app mode (Strategy 3)."""
        mock_ctx = mock.MagicMock()
        mock_caps = mock.MagicMock()
        del mock_caps.extensions
        mock_caps.experimental = None
        mock_ctx.session.client_params.capabilities = mock_caps
        mock_ctx.session.client_params.clientInfo.name = "local-agent-mode-openwebgoggles"
        assert _check_host_supports_ui(mock_ctx) is True

    def test_local_agent_mode_any_suffix_triggers_app_mode(self):
        """Any 'local-agent-mode-*' suffix triggers app mode, not just openwebgoggles."""
        mock_ctx = mock.MagicMock()
        mock_caps = mock.MagicMock()
        del mock_caps.extensions
        mock_caps.experimental = None
        mock_ctx.session.client_params.capabilities = mock_caps
        mock_ctx.session.client_params.clientInfo.name = "local-agent-mode-other-server"
        assert _check_host_supports_ui(mock_ctx) is True

    def test_claude_code_bare_name_does_not_trigger_app_mode(self):
        """'claude-code' bare client name does NOT trigger app mode (removed heuristic)."""
        mock_ctx = mock.MagicMock()
        mock_caps = mock.MagicMock()
        del mock_caps.extensions
        mock_caps.experimental = None
        mock_ctx.session.client_params.capabilities = mock_caps
        mock_ctx.session.client_params.clientInfo.name = "claude-code"
        assert _check_host_supports_ui(mock_ctx) is False

    def test_unknown_client_name_does_not_trigger_app_mode(self):
        """An unrecognised client name falls through to _host_fetched_ui_resource."""
        mock_ctx = mock.MagicMock()
        mock_caps = mock.MagicMock()
        del mock_caps.extensions
        mock_caps.experimental = None
        mock_ctx.session.client_params.capabilities = mock_caps
        mock_ctx.session.client_params.clientInfo.name = "some-other-client"
        assert _check_host_supports_ui(mock_ctx) is False


# ---------------------------------------------------------------------------
# _owg_action tool
# ---------------------------------------------------------------------------


class TestOwgAction:
    async def test_not_in_app_mode(self):
        """_owg_action returns error when not in app mode."""

        result = await _owg_action("approve", "approve", True)
        assert "error" in result
        assert "Not in MCP Apps mode" in result["error"]

    async def test_stores_action(self):
        """_owg_action stores the action in the in-memory queue."""
        _enable_app_mode()

        result = await _owg_action("approve", "approve", True)
        assert result == {"received": True}
        actions = _get_app_state().read_actions()
        assert len(actions) == 1
        assert actions[0]["action_id"] == "approve"

    async def test_action_has_required_fields(self):
        """Stored action contains action_id, type, value, id, and timestamp."""
        _enable_app_mode()

        await _owg_action("submit", "submit", {"key": "val"})
        action = _get_app_state().read_actions()[0]
        assert "action_id" in action
        assert "type" in action
        assert "value" in action
        assert "id" in action
        assert "timestamp" in action
        assert action["action_id"] == "submit"
        assert action["type"] == "submit"
        assert action["value"] == {"key": "val"}

    async def test_action_with_context(self):
        """_owg_action stores context when provided."""
        _enable_app_mode()

        ctx = {"item_index": 0, "section_id": "items"}
        await _owg_action("select", "select", True, context=ctx)
        action = _get_app_state().read_actions()[0]
        assert action["context"] == ctx

    async def test_security_gate_rejects(self):
        """_owg_action returns error when security gate rejects the action."""
        _enable_app_mode()
        gate = mock.MagicMock()
        gate.validate_action.return_value = (False, "bad payload")
        mcp_server._security_gate = gate
        result = await _owg_action("approve", "approve", True)
        assert "error" in result
        assert "security gate" in result["error"]
        # Action should NOT be stored
        assert _get_app_state().read_actions() == []


# ---------------------------------------------------------------------------
# webview tool — app mode
# ---------------------------------------------------------------------------


class TestWebviewAppMode:
    async def test_returns_structured_content(self):
        """webview returns CallToolResult with structuredContent in app mode."""
        _enable_app_mode()

        result = await openwebgoggles(state={"title": "Test"})
        assert hasattr(result, "structuredContent")
        assert result.structuredContent["title"] == "Test"

    async def test_clears_actions_on_new_webview(self):
        """webview clears pending actions when called in app mode."""
        _enable_app_mode()

        app_state = _get_app_state()
        app_state.add_action({"action_id": "old"})
        await openwebgoggles(state={"title": "Fresh"})
        assert app_state.read_actions() == []

    async def test_does_not_block(self):
        """webview returns immediately in app mode (no timeout/blocking)."""
        _enable_app_mode()

        # If this blocks, the test will time out
        result = await asyncio.wait_for(
            openwebgoggles(state={"title": "Quick"}),
            timeout=2.0,
        )
        assert hasattr(result, "structuredContent")

    async def test_state_stored_in_memory(self):
        """webview stores state in the AppModeState singleton."""
        _enable_app_mode()

        await openwebgoggles(state={"title": "Stored", "data": {"sections": []}})
        app_state = _get_app_state()
        assert app_state.state["title"] == "Stored"
        assert app_state.state_version >= 1


# ---------------------------------------------------------------------------
# webview_read tool — app mode
# ---------------------------------------------------------------------------


class TestWebviewReadAppMode:
    async def test_reads_from_memory(self):
        """webview_read returns actions from the in-memory queue."""
        _enable_app_mode()

        app_state = _get_app_state()
        app_state.add_action({"action_id": "btn", "type": "approve", "value": True})
        result = await openwebgoggles_read()
        assert len(result["actions"]) == 1
        assert result["actions"][0]["action_id"] == "btn"

    async def test_clear_drains_queue(self):
        """webview_read(clear=True) drains the queue so next read is empty."""
        _enable_app_mode()

        app_state = _get_app_state()
        app_state.add_action({"action_id": "a"})
        result1 = await openwebgoggles_read(clear=True)
        assert len(result1["actions"]) == 1
        result2 = await openwebgoggles_read()
        assert result2["actions"] == []

    async def test_empty_when_no_actions(self):
        """webview_read returns empty actions when queue is empty."""
        _enable_app_mode()

        # Ensure singleton exists but has no actions
        _get_app_state()
        result = await openwebgoggles_read()
        assert result["actions"] == []


# ---------------------------------------------------------------------------
# webview_update tool — app mode
# ---------------------------------------------------------------------------


class TestWebviewUpdateAppMode:
    async def test_update_replaces_state(self):
        """webview_update returns CallToolResult with structuredContent."""
        _enable_app_mode()

        app_state = _get_app_state()
        app_state.write_state({"title": "Old"})
        result = await openwebgoggles_update(state={"title": "New"})
        assert hasattr(result, "structuredContent")
        assert result.structuredContent["title"] == "New"
        assert app_state.state["title"] == "New"

    async def test_update_merge_mode(self):
        """webview_update(merge=True) deep-merges into existing state."""
        _enable_app_mode()

        app_state = _get_app_state()
        app_state.write_state({"title": "Base", "data": {"meta": {"a": 1}}})
        result = await openwebgoggles_update(state={"data": {"meta": {"b": 2}}}, merge=True)
        assert hasattr(result, "structuredContent")
        merged = result.structuredContent
        assert merged["title"] == "Base"
        assert merged["data"]["meta"]["a"] == 1
        assert merged["data"]["meta"]["b"] == 2

    async def test_preset_expansion(self):
        """webview_update with preset="confirm" expands state."""
        _enable_app_mode()

        _get_app_state()
        result = await openwebgoggles_update(
            state={"title": "Sure?", "message": "Do it?"},
            preset="confirm",
        )
        assert hasattr(result, "structuredContent")
        sc = result.structuredContent
        assert "actions_requested" in sc
        assert sc["status"] == "pending_review"


# ---------------------------------------------------------------------------
# webview_close tool — app mode
# ---------------------------------------------------------------------------


class TestWebviewCloseAppMode:
    async def test_clears_state(self):
        """webview_close clears in-memory state and resets mode in app mode."""
        _enable_app_mode()

        app_state = _get_app_state()
        app_state.write_state({"title": "Active"})
        app_state.add_action({"action_id": "x"})
        result = await openwebgoggles_close()
        assert result["status"] == "ok"
        assert app_state.state == {}
        assert app_state.state_version > 0  # reset to epoch-ms, not zero
        assert app_state.read_actions() == []
        # Mode should be reset so next session can re-detect
        assert mcp_server._cached_mode is None
        assert mcp_server._host_fetched_ui_resource is False


# ---------------------------------------------------------------------------
# webview_status tool — app mode
# ---------------------------------------------------------------------------


class TestWebviewStatusAppMode:
    async def test_active_when_state_exists(self):
        """webview_status reports active=True when state is non-empty."""
        _enable_app_mode()

        app_state = _get_app_state()
        app_state.write_state({"title": "Live"})
        result = await openwebgoggles_status(session="default")
        assert result["active"] is True
        assert result["mode"] == "mcp_apps"
        assert result["version"] >= 1

    async def test_inactive_when_empty(self):
        """webview_status reports active=False when no state has been written."""
        _enable_app_mode()

        _get_app_state()  # create slot but don't write state
        result = await openwebgoggles_status(session="default")
        assert result["active"] is False
        assert result["mode"] == "mcp_apps"
