"""Shared utilities for CLI commands (deploy, serve)."""

import importlib
import json
import os
import sys
import tempfile
import zipfile
from importlib import metadata
from pathlib import Path

from . import terminal

IGNORE_PATTERNS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "node_modules",
    ".DS_Store",
    ".idea",
    ".vscode",
    ".env.local",
    ".envrc",
    ".next",
    ".capsuleignore",
    ".capsule",
}

IGNORE_EXTENSIONS = {".pyc"}


def resolve_entry_point(entry_point: str) -> dict:
    """Import the entry point module, resolve the target, and return
    its ``_cpsl_config`` dict.

    The target can be a class decorated with ``@app.cls`` or a functional
    ``App`` instance.  Accepts formats like ``app:MyAgent``, ``app:app``,
    or ``examples/echo/app.py:app``.
    """
    from .app import App

    if ":" not in entry_point:
        terminal.error(
            "Invalid entry point. Expected format: capsule <command> <module>:<name>"
        )

    module_path, target_name = entry_point.rsplit(":", 1)
    if not target_name:
        terminal.error(
            "Invalid entry point. Expected format: capsule <command> <module>:<name>"
        )

    file_path = Path(module_path)
    if file_path.parent != Path("."):
        os.chdir(file_path.parent)
        module_name = file_path.stem
    else:
        module_name = module_path.replace(".py", "")

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    try:
        mod = importlib.import_module(module_name)
    except ImportError as e:
        terminal.error(f"Cannot import '{module_path}': {e}")

    obj = getattr(mod, target_name, None)
    if obj is None:
        terminal.error(f"'{target_name}' not found in module '{module_path}'")

    if isinstance(obj, App):
        obj._finalize_config()
        cfg = obj._cpsl_config
        if cfg.get("module") is None:
            cfg["module"] = module_name
        return cfg

    config = getattr(obj, "_cpsl_config", None)
    if config is None:
        terminal.error(
            f"'{target_name}' is not a functional App or a class decorated with @app.cls"
        )

    return config


def should_ignore(name: str) -> bool:
    """Return True if *name* matches an ignore pattern or extension."""
    if name in IGNORE_PATTERNS:
        return True
    return any(name.endswith(ext) for ext in IGNORE_EXTENSIONS)


def collect_source_archive() -> bytes:
    """ZIP the current working directory, respecting ignore patterns."""
    root = Path.cwd()
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    tmp.close()
    file_count = 0

    try:
        with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as zf:
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [d for d in dirnames if not should_ignore(d)]
                for fname in filenames:
                    if should_ignore(fname):
                        continue
                    full = os.path.join(dirpath, fname)
                    rel = os.path.relpath(full, root)
                    zf.write(full, rel)
                    terminal.detail(f"  + {rel}")
                    file_count += 1

        data = Path(tmp.name).read_bytes()
        terminal.detail(
            f"  {file_count} file{'' if file_count == 1 else 's'}, "
            f"{terminal.humanize_memory(len(data), base=10)}"
        )
        return data
    finally:
        os.unlink(tmp.name)


def _pip_package_name(spec: str) -> str:
    for i, c in enumerate(spec.strip()):
        if c in "=<>!~[ ":
            return spec[:i].strip().lower()
    return spec.strip().lower()


def _local_sdk_version() -> str | None:
    pyproject = Path(__file__).resolve().parents[2] / "pyproject.toml"
    try:
        for line in pyproject.read_text().splitlines():
            line = line.strip()
            if line.startswith("version = "):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    except OSError:
        pass

    try:
        return metadata.version("cpsl")
    except metadata.PackageNotFoundError:
        return None

    return None


def normalize_image(image: dict) -> dict:
    normalized = {
        "python_packages": list(image.get("python_packages", [])),
        "apt_packages": list(image.get("apt_packages", [])),
        "commands": list(image.get("commands", [])),
    }

    if not any(_pip_package_name(pkg) == "cpsl" for pkg in normalized["python_packages"]):
        version = _local_sdk_version()
        if version:
            normalized["python_packages"].insert(0, f"cpsl=={version}")

    return normalized


def build_image_spec(image: dict, *, cpu: float = 0.25, memory: int = 512):
    """Build a gRPC ``ImageSpec`` from the config dict."""
    from .clients.capsule import ImageSpec

    image = normalize_image(image)
    return ImageSpec(
        python_packages=image.get("python_packages", []),
        apt_packages=image.get("apt_packages", []),
        commands=image.get("commands", []),
        cpu=cpu,
        memory_mib=memory,
    )


def build_channel_specs(channels: list[dict]):
    """Build a list of gRPC ``ChannelSpec`` from channel config dicts.

    Handles both built-in types (chat, api) and named resource references
    (type="_resource", name="my-channel").
    """
    from .clients.capsule import ChannelSpec

    return [
        ChannelSpec(
            type=ch["type"],
            config={
                k: (json.dumps(v) if isinstance(v, dict) else str(v))
                for k, v in ch.items()
                if k != "type"
            },
        )
        for ch in channels
    ]


def build_integration_specs(integrations: list[dict]):
    """Build a list of gRPC ``IntegrationSpec`` from integration config dicts."""
    from .clients.capsule import IntegrationSpec

    return [
        IntegrationSpec(
            type=ig["type"],
            scopes=ig.get("scopes", []),
            client_id_secret=ig.get("client_id_secret", ""),
            client_secret_secret=ig.get("client_secret_secret", ""),
            mode=ig.get("mode", "oauth"),
            fields=ig.get("fields", []),
        )
        for ig in integrations
    ]


def build_schedule_specs(schedules: list[dict]):
    """Build a list of gRPC ``ScheduleSpec`` from schedule config dicts."""
    from .clients.capsule import ScheduleSpec

    return [
        ScheduleSpec(name=s["name"], cron=s["cron"])
        for s in schedules
    ]
