"""Theme system for amp_stories.

A :class:`Theme` controls the colour palette, typography, and default
animations used by the page-factory functions in :mod:`amp_stories.templates`.
Call :meth:`Theme.generate_css` to get a stylesheet string ready to pass to
``Story.custom_css``::

    from amp_stories import Story, SUMMIT_THEME, title_page

    story = Story(
        ...,
        custom_css=SUMMIT_THEME.generate_css(),
        pages=[title_page("cover", "Hello World", background_src="hero.jpg")],
    )
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

from amp_stories._validation import (
    ValidationError,
    validate_css_size,
    validate_hex_color,
)

if TYPE_CHECKING:
    from amp_stories._types import AnimateIn

_CSS_SIZE_RE = re.compile(r"^(\d+(?:\.\d+)?)(rem|px|pt|em)$")


def _scale_css_size(size: str, scale: float) -> str:
    """Scale a CSS size string by *scale*.

    Parses a validated CSS size like ``'3.2rem'`` or ``'24px'``, multiplies the
    numeric part by *scale*, and returns the formatted result with the same unit.
    """
    m = _CSS_SIZE_RE.match(size)
    assert m  # size was already validated via validate_css_size
    value = float(m.group(1)) * scale
    unit = m.group(2)
    return f"{value:.4f}".rstrip("0").rstrip(".") + unit


def _hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    """Convert ``#RRGGBB`` to an RGB tuple."""
    return (
        int(hex_color[1:3], 16),
        int(hex_color[3:5], 16),
        int(hex_color[5:7], 16),
    )


@dataclass
class Theme:
    """Visual theme controlling colours, typography, and animation defaults.

    Args:
        bg_color: Solid background colour used when no image is given.
        text_color: Primary text colour.
        accent_color: Accent colour for eyebrows, stats, quote marks, etc.
        muted_color: Secondary / muted text colour (attributions, captions).
        overlay_opacity: Darkness of the semi-transparent overlay placed over
            background images (0.0 = transparent, 1.0 = opaque).
        font_family: CSS font-family stack for body text.
        heading_font: CSS font-family for headings; falls back to *font_family*
            when ``None``.
        h1_size: CSS font-size for primary headings (e.g. ``'3.2rem'``).
        h2_size: CSS font-size for secondary headings.
        body_size: CSS font-size for body text.
        small_size: CSS font-size for small labels and captions.
        heading_animate_in: ``animate-in`` value applied to heading elements in
            page templates (``None`` disables animation).
        body_animate_in: ``animate-in`` value applied to body text in page
            templates.
        animate_in_duration: Duration applied to animated template elements.
        animate_in_delay: Delay applied to the *second* animated element on a
            page, creating a stagger effect.
    """

    # Colours
    bg_color: str = "#16213e"
    text_color: str = "#f5f5f5"
    accent_color: str = "#0f8b8d"
    muted_color: str = "#9e9eb0"
    overlay_opacity: float = 0.50
    panel_color: str = "#0b1220"
    panel_opacity: float = 0.82
    caption_opacity: float = 0.68

    # Typography
    font_family: str = "'Georgia', 'Times New Roman', serif"
    heading_font: str | None = None  # falls back to font_family

    # Font sizes (AMP recommends ≥ 24pt ≈ 1.5rem at 16px base)
    h1_size: str = "3.2rem"
    h2_size: str = "2.4rem"
    body_size: str = "1.6rem"
    small_size: str = "1.1rem"
    panel_radius: str = "1.25rem"
    panel_padding: str = "1rem"
    content_max_width: str = "32rem"

    # Animation defaults used by page factory functions
    heading_animate_in: AnimateIn | None = "fly-in-bottom"
    body_animate_in: AnimateIn | None = "fade-in"
    animate_in_duration: str = "0.5s"
    animate_in_delay: str = "0.3s"

    # Desktop / landscape layout
    landscape_font_scale: float | None = None  # 0.1–2.0; None disables landscape CSS

    # Font loading
    google_font: str | None = None  # e.g. "Montserrat" or "Roboto:400,700"

    def __post_init__(self) -> None:
        validate_hex_color(self.bg_color, "Theme.bg_color")
        validate_hex_color(self.text_color, "Theme.text_color")
        validate_hex_color(self.accent_color, "Theme.accent_color")
        validate_hex_color(self.muted_color, "Theme.muted_color")
        validate_hex_color(self.panel_color, "Theme.panel_color")
        if not 0.0 <= self.overlay_opacity <= 1.0:
            raise ValidationError(
                f"Theme.overlay_opacity must be between 0.0 and 1.0. Got: {self.overlay_opacity}"
            )
        if not 0.0 <= self.panel_opacity <= 1.0:
            raise ValidationError(
                f"Theme.panel_opacity must be between 0.0 and 1.0. Got: {self.panel_opacity}"
            )
        if not 0.0 <= self.caption_opacity <= 1.0:
            raise ValidationError(
                f"Theme.caption_opacity must be between 0.0 and 1.0. Got: {self.caption_opacity}"
            )
        validate_css_size(self.h1_size, "Theme.h1_size")
        validate_css_size(self.h2_size, "Theme.h2_size")
        validate_css_size(self.body_size, "Theme.body_size")
        validate_css_size(self.small_size, "Theme.small_size")
        validate_css_size(self.panel_radius, "Theme.panel_radius")
        validate_css_size(self.panel_padding, "Theme.panel_padding")
        validate_css_size(self.content_max_width, "Theme.content_max_width")
        if self.landscape_font_scale is not None and not 0.1 <= self.landscape_font_scale <= 2.0:
            raise ValidationError(
                "Theme.landscape_font_scale must be between 0.1 and 2.0. "
                f"Got: {self.landscape_font_scale}"
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _heading_font_css(self) -> str:
        return self.heading_font if self.heading_font is not None else self.font_family

    def _overlay_rgba(self) -> str:
        alpha = round(self.overlay_opacity, 3)
        return f"rgba(0,0,0,{alpha})"

    def _panel_rgba(self, opacity: float | None = None) -> str:
        alpha = round(self.panel_opacity if opacity is None else opacity, 3)
        r, g, b = _hex_to_rgb(self.panel_color)
        return f"rgba({r},{g},{b},{alpha})"

    def get_google_fonts_url(self) -> str | None:
        """Return the Google Fonts CSS URL for this theme's font, or ``None``.

        Use the result with :attr:`~amp_stories.story.Story.font_links`::

            story = Story(..., font_links=[theme.get_google_fonts_url()])
        """
        if self.google_font is None:
            return None
        from urllib.parse import quote  # noqa: PLC0415

        return f"https://fonts.googleapis.com/css2?family={quote(self.google_font)}&display=swap"

    # ------------------------------------------------------------------
    # CSS generation
    # ------------------------------------------------------------------

    def generate_css(self) -> str:
        """Return a CSS string defining all ``.ast-*`` classes for this theme.

        The result should be passed to :attr:`~amp_stories.story.Story.custom_css`
        so that page-template elements render correctly.
        """
        hf = self._heading_font_css()
        bf = self.font_family
        tc = self.text_color
        ac = self.accent_color
        mc = self.muted_color
        bg = self.bg_color
        ov = self._overlay_rgba()
        panel = self._panel_rgba()
        caption_panel = self._panel_rgba(self.caption_opacity)
        h1 = self.h1_size
        h2 = self.h2_size
        bs = self.body_size
        sm = self.small_size
        panel_radius = self.panel_radius
        panel_padding = self.panel_padding
        measure = self.content_max_width

        # Fluid horizontal padding: scales with viewport width, capped at the
        # original 2.4rem on anything wider than ~480 px.
        pad = "clamp(.75rem,5vw,2.4rem)"

        rules: list[str] = [
            # Background div — used when no background image is provided
            f".ast-bg{{background-color:{bg}}}",
            # Overlay — darkens a background image for text legibility
            f".ast-overlay{{background:{ov}}}",
            # Eyebrow — small uppercase category label
            (
                f".ast-eyebrow{{font-family:{bf};font-size:{sm};"
                f"color:{ac};letter-spacing:.12em;text-transform:uppercase;"
                f"margin:0 0 .6rem;padding:0 {pad}}}"
            ),
            # Primary heading
            (
                f".ast-title{{font-family:{hf};font-size:{h1};"
                f"font-weight:700;color:{tc};line-height:1.15;"
                f"overflow-wrap:break-word;margin:0;padding:0 {pad}}}"
            ),
            # Secondary heading / subtitle
            (
                f".ast-subtitle{{font-family:{hf};font-size:{h2};"
                f"font-weight:400;color:{tc};line-height:1.2;"
                f"margin:.8rem 0 0;padding:0 {pad}}}"
            ),
            # Body text
            (
                f".ast-body{{font-family:{bf};font-size:{bs};"
                f"color:{tc};line-height:1.55;overflow-wrap:break-word;"
                f"margin:0;padding:0 {pad}}}"
            ),
            # Attribution / author line
            (
                f".ast-attribution{{font-family:{bf};font-size:{sm};"
                f"color:{mc};font-style:italic;margin:1.2rem 0 0;padding:0 {pad}}}"
            ),
            # Decorative opening quotation mark — clamped so it fits on narrow phones
            (
                f".ast-quote-mark{{font-family:{hf};font-size:clamp(5rem,19vw,8rem);"
                f"color:{ac};line-height:.8;margin:0;"
                f"padding:0 clamp(.6rem,4vw,2rem) 0 {pad}}}"
            ),
            # Large stat number — clamped so it fits on narrow phones
            (
                f".ast-stat-number{{font-family:{hf};font-size:clamp(4rem,14vw,6rem);"
                f"font-weight:900;color:{ac};line-height:1;"
                f"margin:0;padding:0 {pad}}}"
            ),
            # Stat descriptor label
            (
                f".ast-stat-label{{font-family:{bf};font-size:{bs};"
                f"color:{tc};text-transform:uppercase;letter-spacing:.08em;"
                f"margin:.5rem 0 0;padding:0 {pad}}}"
            ),
            # Image caption bar
            (
                f".ast-caption{{font-family:{bf};font-size:{sm};"
                f"color:{tc};background:rgba(0,0,0,.55);"
                f"padding:.5rem {pad};margin:0}}"
            ),
            # Chapter / part number label
            (
                f".ast-chapter-number{{font-family:{bf};font-size:{sm};"
                f"color:{ac};letter-spacing:.2em;text-transform:uppercase;"
                f"margin:0 0 .6rem;padding:0 {pad}}}"
            ),
            # Chapter divider heading
            (
                f".ast-chapter-title{{font-family:{hf};font-size:{h1};"
                f"font-weight:700;color:{tc};line-height:1.15;"
                f"margin:0;padding:0 {pad}}}"
            ),
            # News / e-commerce badge (BREAKING, SALE, etc.)
            (
                f".ast-badge{{font-family:{bf};font-size:{sm};color:#fff;"
                f"background:{ac};display:inline-block;padding:.25rem .75rem;"
                f"border-radius:2rem;letter-spacing:.08em;text-transform:uppercase;"
                f"font-weight:700;margin:0 0 .6rem {pad}}}"
            ),
            # Strikethrough "was" price
            (
                f".ast-price-was{{font-family:{hf};font-size:{h2};color:{mc};"
                f"text-decoration:line-through;font-weight:400;line-height:1;"
                f"margin:0 0 .4rem;padding:0 {pad}}}"
            ),
            # Bar-chart title row
            (
                f".ast-chart-title{{font-family:{hf};font-size:{bs};font-weight:600;"
                f"color:{tc};line-height:1.2;margin:0 0 1rem;padding:0 {pad}}}"
            ),
            # Bar-chart flex row container
            f".ast-chart-row{{display:flex;align-items:center;padding:0 {pad};margin:0 0 .6rem}}",
            # Bar-chart label (left side) — min-width clamped for narrow screens
            (
                f".ast-chart-label{{font-family:{bf};font-size:{sm};color:{tc};"
                f"min-width:clamp(3rem,9vw,5rem);flex-shrink:0;padding-right:.5rem;"
                f"text-align:right;line-height:1.2}}"
            ),
            # Bar-chart track (background rail)
            ".ast-chart-track{flex:1;min-width:0;height:2rem;background:rgba(0,0,0,.12);border-radius:.25rem;overflow:hidden}",
            # Bar-chart filled bar
            f".ast-chart-bar{{height:100%;background:{ac};border-radius:.25rem;display:block;min-width:.25rem}}",
            # Bar-chart value label (right side)
            (
                f".ast-chart-value{{font-family:{bf};font-size:{sm};color:{ac};"
                f"font-weight:700;flex-shrink:0;padding-left:.4rem;line-height:1}}"
            ),
            # Comparison page — flex row wrapper
            f".ast-comparison-row{{display:flex;align-items:center;width:100%;padding:0 {pad}}}",
            # Comparison column — each side of the VS split
            ".ast-comparison-col{flex:1;min-width:0;text-align:center;padding:0 .5rem}",
            # Comparison VS label in centre column
            ".ast-comparison-vs{flex:0 0 auto;text-align:center;padding:0 .5rem}",
            # Large stat number inside a comparison column — smaller than ast-stat-number
            # to fit two side-by-side on narrow phones
            (
                f".ast-comparison-stat{{font-family:{hf};font-size:clamp(2rem,8vw,3rem);"
                f"font-weight:900;color:{ac};line-height:1.1;margin:0}}"
            ),
            # Descriptor label inside a comparison column
            (
                f".ast-comparison-label{{font-family:{bf};font-size:{sm};color:{tc};"
                f"text-transform:uppercase;letter-spacing:.08em;margin:.5rem 0 0}}"
            ),
            # Shared layout helpers
            ".ast-stack{display:flex;flex-direction:column;width:100%;gap:.75rem}",
            ".ast-stack--split{gap:1rem}",
            f".ast-measure{{max-width:{measure};width:100%}}",
            (
                f".ast-panel{{background:{panel};border-radius:{panel_radius};"
                f"padding:{panel_padding};max-width:{measure};width:100%;"
                f"box-shadow:0 .5rem 2rem rgba(0,0,0,.18)}}"
            ),
            (
                ".ast-panel--card{background:"
                f"{self._panel_rgba(min(self.panel_opacity + 0.08, 1.0))}"
                "}"
            ),
            (
                f".ast-panel--caption{{background:{caption_panel};border-radius:0;"
                f"max-width:none;padding:.5rem {pad};box-shadow:none}}"
            ),
            (
                ".ast-panel .ast-eyebrow,.ast-panel .ast-title,.ast-panel .ast-subtitle,"
                ".ast-panel .ast-body,.ast-panel .ast-attribution,.ast-panel .ast-stat-number,"
                ".ast-panel .ast-stat-label,.ast-panel .ast-caption,.ast-panel .ast-chapter-number,"
                ".ast-panel .ast-chapter-title,.ast-panel .ast-price-was,"
                ".ast-panel .ast-chart-title{padding:0;margin-left:0;margin-right:0}"
            ),
            ".ast-panel .ast-caption{background:none;padding:0}",
            ".ast-panel .ast-badge{margin-left:0}",
        ]

        # Narrow-screen breakpoint (≤ 370 px — older / budget phones).
        # Scale large headings down slightly so long titles don't overflow.
        rules.append(
            "@media (max-width:370px){"
            f".ast-title{{font-size:{_scale_css_size(h1, 0.8)}}}"
            f".ast-chapter-title{{font-size:{_scale_css_size(h1, 0.8)}}}"
            f".ast-subtitle{{font-size:{_scale_css_size(h2, 0.83)}}}"
            f".ast-stat-label{{font-size:{_scale_css_size(bs, 0.875)}}}"
            "}"
        )

        if self.landscape_font_scale is not None:
            s = self.landscape_font_scale
            rules.append(
                "@media (orientation:landscape){"
                f".ast-title{{font-size:{_scale_css_size(h1, s)}}}"
                f".ast-chapter-title{{font-size:{_scale_css_size(h1, s)}}}"
                f".ast-subtitle{{font-size:{_scale_css_size(h2, s)}}}"
                f".ast-body{{font-size:{_scale_css_size(bs, s)}}}"
                f".ast-stat-label{{font-size:{_scale_css_size(bs, s)}}}"
                f".ast-eyebrow{{font-size:{_scale_css_size(sm, s)}}}"
                f".ast-attribution{{font-size:{_scale_css_size(sm, s)}}}"
                f".ast-caption{{font-size:{_scale_css_size(sm, s)}}}"
                f".ast-chapter-number{{font-size:{_scale_css_size(sm, s)}}}"
                f".ast-badge{{font-size:{_scale_css_size(sm, s)}}}"
                f".ast-price-was{{font-size:{_scale_css_size(h2, s)}}}"
                f".ast-chart-title{{font-size:{_scale_css_size(bs, s)}}}"
                f".ast-chart-label{{font-size:{_scale_css_size(sm, s)}}}"
                f".ast-chart-value{{font-size:{_scale_css_size(sm, s)}}}"
                f".ast-comparison-label{{font-size:{_scale_css_size(sm, s)}}}"
                f".ast-panel{{max-width:{_scale_css_size(measure, min(max(s, 0.75), 1.0))}}}"
                "}"
            )

        return "".join(rules)


# ---------------------------------------------------------------------------
# Built-in themes
# ---------------------------------------------------------------------------

#: Cohesive news/explainer theme recommended by the style guide.
SIGNAL_THEME: Theme = Theme(
    bg_color="#101820",
    text_color="#f8f5f1",
    accent_color="#ff5a5f",
    muted_color="#b6bcc6",
    panel_color="#111827",
    font_family="'Helvetica Neue', Arial, sans-serif",
    heading_font="'Merriweather', 'Georgia', serif",
    h1_size="2.5rem",
    h2_size="1.95rem",
    heading_animate_in="fade-in",
    body_animate_in="fade-in",
)

#: Cohesive adventure/editorial default theme recommended by the style guide.
SUMMIT_THEME: Theme = Theme(
    bg_color="#152226",
    text_color="#f4efe6",
    accent_color="#d7a14d",
    muted_color="#a7b1ab",
    panel_color="#102028",
    font_family="'Source Serif 4', 'Georgia', serif",
    heading_font="'Fraunces', 'Georgia', serif",
    h1_size="2.8rem",
    h2_size="2rem",
    landscape_font_scale=0.8,
)

#: Cohesive commerce/recommendation theme recommended by the style guide.
MARKET_THEME: Theme = Theme(
    bg_color="#171717",
    text_color="#f5f5f4",
    accent_color="#d9a441",
    muted_color="#b0b0aa",
    panel_color="#111111",
    font_family="'Helvetica Neue', Arial, sans-serif",
    heading_font="'Helvetica Neue', Arial, sans-serif",
    overlay_opacity=0.38,
)

#: Cohesive premium feature theme recommended by the style guide.
FEATURE_THEME: Theme = Theme(
    bg_color="#221c1d",
    text_color="#faf6f2",
    accent_color="#cf6f88",
    muted_color="#b8a7ac",
    panel_color="#261e20",
    font_family="'Source Serif 4', 'Georgia', serif",
    heading_font="'Cormorant Garamond', 'Georgia', serif",
    h1_size="2.9rem",
    h2_size="2.1rem",
)
