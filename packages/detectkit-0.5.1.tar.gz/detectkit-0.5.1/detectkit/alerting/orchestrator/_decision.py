"""Decision logic: ``should_alert`` and the consecutive-anomaly helpers."""

from __future__ import annotations

import math
from datetime import datetime, timezone

import numpy as np

from detectkit.alerting.channels.base import AlertData
from detectkit.alerting.orchestrator._base import _OrchestratorBase
from detectkit.alerting.orchestrator._types import DetectionRecord
from detectkit.utils.datetime_utils import now_utc, to_aware_utc


class _DecisionMixin(_OrchestratorBase):
    def should_alert(
        self,
        recent_detections: list[DetectionRecord],
    ) -> tuple[bool, AlertData | None]:
        """Decide whether to fire an alert from recent detections.

        Steps (cheap → expensive):
            1. Bail out on empty input.
            2. Honour the alert cooldown so we don't spam channels.
            3. Require ``min_detectors`` triggering on the latest point.
            4. Require ``consecutive_anomalies`` matching the direction.
        """
        if not recent_detections:
            return False, None

        # Cooldown is checked first so a noisy run doesn't waste effort.
        if self._is_in_cooldown():
            return False, None

        detections_by_time = self._group_by_timestamp(recent_detections)
        timestamps_sorted = sorted(detections_by_time.keys(), reverse=True)

        latest_anomalies = [d for d in detections_by_time[timestamps_sorted[0]] if d.is_anomaly]
        if len(latest_anomalies) < self.conditions.min_detectors:
            return False, None

        consecutive = self._count_consecutive_anomalies(detections_by_time, timestamps_sorted)
        if consecutive < self.conditions.consecutive_anomalies:
            return False, None

        return True, self._build_alert_data(latest_anomalies, consecutive)

    def _count_consecutive_anomalies(
        self,
        detections_by_time: dict[np.datetime64, list[DetectionRecord]],
        timestamps_sorted: list[np.datetime64],
    ) -> int:
        """Walk timestamps newest→oldest counting matching anomalies."""
        direction_condition = self.conditions.direction
        consecutive = 0
        prev_direction: str | None = None

        for ts in timestamps_sorted:
            anomalies = [d for d in detections_by_time[ts] if d.is_anomaly]
            if len(anomalies) < self.conditions.min_detectors:
                break

            current_direction = anomalies[0].direction

            if direction_condition == "any":
                consecutive += 1
            elif direction_condition == "same":
                if prev_direction is None:
                    consecutive = 1
                    prev_direction = current_direction
                elif current_direction == prev_direction:
                    consecutive += 1
                else:
                    break  # direction flipped → stop counting
            elif direction_condition == "up":
                if current_direction == "up":
                    consecutive += 1
                else:
                    break
            elif direction_condition == "down":
                if current_direction == "down":
                    consecutive += 1
                else:
                    break
            else:
                # Unknown direction policy — treat as "any" to stay safe.
                consecutive += 1

        return consecutive

    def _build_alert_data(
        self,
        anomalies: list[DetectionRecord],
        consecutive_count: int,
    ) -> AlertData:
        primary = anomalies[0]

        if len(anomalies) > 1:
            max_severity = max(d.severity for d in anomalies)
            detector_names = [d.detector_name for d in anomalies]
            detector_name = f"{len(anomalies)} detectors"
            detector_params = "; ".join(
                f"{d.detector_name}: {d.detector_params}" for d in anomalies
            )
            combined_metadata = {
                "detectors": detector_names,
                "count": len(anomalies),
            }
            for i, d in enumerate(anomalies):
                combined_metadata[f"detector_{i}_metadata"] = d.detection_metadata
        else:
            max_severity = primary.severity
            detector_name = primary.detector_name
            detector_params = primary.detector_params
            combined_metadata = primary.detection_metadata

        return AlertData(
            metric_name=self.metric_name,
            timestamp=primary.timestamp,
            timezone=self.timezone_display,
            value=primary.value,
            confidence_lower=primary.confidence_lower,
            confidence_upper=primary.confidence_upper,
            detector_name=detector_name,
            detector_params=detector_params,
            direction=primary.direction,
            severity=max_severity,
            detection_metadata=combined_metadata,
            consecutive_count=consecutive_count,
            description=self.description,
            mentions=self.mentions,
        )

    def should_alert_no_data(
        self,
        last_point: datetime,
    ) -> tuple[bool, AlertData | None]:
        """Decide whether to fire a no-data alert for *last_point*.

        Conditions (all must hold):
            1. ``alert_config.no_data_alert`` is true.
            2. Not currently in alert cooldown for this alert config.
            3. The latest expected datapoint is missing — there is no row
               in ``_dtk_datapoints`` for *last_point* OR the row's value
               is NULL/NaN. ``get_value_at`` returns ``None`` for both.

        ``min_detectors`` and ``consecutive_anomalies`` deliberately do
        not apply here: missing data is a single binary metric-level
        signal, not a per-detector vote.
        """
        if not self.alert_config or not getattr(self.alert_config, "no_data_alert", False):
            return False, None
        if not self.internal:
            return False, None

        if self._is_in_cooldown():
            return False, None

        value = self.internal.get_value_at(self.metric_name, last_point)
        if value is not None and not (isinstance(value, float) and math.isnan(value)):
            return False, None

        return True, self._build_no_data_alert_data(last_point)

    def _build_no_data_alert_data(self, last_point: datetime) -> AlertData:
        """Construct the AlertData payload for a no-data alert."""
        return AlertData(
            metric_name=self.metric_name,
            timestamp=np.datetime64(last_point, "ms"),
            timezone=self.timezone_display,
            value=None,
            confidence_lower=None,
            confidence_upper=None,
            detector_name="no_data",
            detector_params="",
            direction="none",
            severity=0.0,
            detection_metadata={"reason": "no_data"},
            consecutive_count=0,
            is_no_data=True,
            description=self.description,
            mentions=self.mentions,
        )

    def get_last_complete_point(self, now: datetime | None = None) -> datetime:
        """Floor ``now`` to the previous fully completed interval boundary."""
        if now is None:
            now = now_utc()
        now = to_aware_utc(now)

        interval_seconds = self.interval.seconds
        floored = (int(now.timestamp()) // interval_seconds) * interval_seconds
        last_complete = floored - interval_seconds
        return datetime.fromtimestamp(last_complete, tz=timezone.utc)
