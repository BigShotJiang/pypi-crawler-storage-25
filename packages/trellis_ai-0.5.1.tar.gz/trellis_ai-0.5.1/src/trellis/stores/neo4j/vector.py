"""Neo4jVectorStore — Neo4j 2025.06+ HNSW vectors as optional properties on :Node.

Minimum version is **Neo4j 2025.06** (Cypher 25), driven by the SEARCH
clause used in :meth:`Neo4jVectorStore.query`. The deprecated
``db.index.vector.queryNodes`` procedure that older versions used emits
a ``DEPRECATION`` notification on every call against AuraDB and will
eventually be removed. AuraDB always runs the latest engine; self-
hosted Docker users on the ``neo4j:5`` tag should upgrade to a
``neo4j:2025`` (or newer) image.

Shape #2 of the design discussion: vectors live as an ``embedding``
property directly on the ``(:Node)`` rows that the
:class:`Neo4jGraphStore` already manages, rather than on a parallel
``(:VectorItem)`` label. This means:

* The vector store's ``item_id`` IS the graph store's ``node_id``.
* Embeddings are genuinely optional — Neo4j's HNSW index only indexes
  nodes that have the property set, so the structural majority of
  nodes pay zero index cost.
* Queries can filter by graph attributes natively (``valid_to IS NULL``
  to exclude historical versions, ``node_type IN [...]`` to scope a
  search) in the same Cypher pass.
* :meth:`upsert` requires the node to already have a current version —
  embeddings attach to existing entities, they don't create them.

Trade-offs vs. shape #1 (separate ``:VectorItem`` label):

* Couples the two stores on Neo4j (other backends keep their split).
* Updating a node via ``GraphStore.upsert_node`` creates a new version
  row that does NOT inherit the prior embedding. Callers that update
  content must re-embed afterwards. The old (closed) version still
  carries its embedding for audit / time-travel reads, but the
  ``query`` path filters them out via ``valid_to IS NULL``.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

import structlog

from trellis.stores.base.vector import VectorStore
from trellis.stores.neo4j.base import (
    DriverConfig,
    Neo4jSessionRunner,
    build_driver,
    check_driver_installed,
    wait_for_vector_index_online,
)

if TYPE_CHECKING:
    from neo4j import Driver

logger = structlog.get_logger(__name__)

_VALID_SIMILARITY = frozenset({"cosine", "euclidean"})
_OVER_FETCH_MULT = 10


class Neo4jVectorStore(Neo4jSessionRunner, VectorStore):
    """Vectors as optional properties on the graph store's ``:Node`` rows.

    See module docstring for the data model. The HNSW index is created
    on ``(:Node).embedding`` and indexes only the nodes that have the
    property set.
    """

    def __init__(
        self,
        uri: str,
        *,
        user: str = "neo4j",
        password: str | None = None,
        database: str = "neo4j",
        dimensions: int = 1536,
        similarity: str = "cosine",
        index_name: str = "trellis_node_embeddings",
        index_wait_timeout: float = 30.0,
        m: int = 16,
        ef_construction: int = 100,
        quantization: bool = False,
        driver: Driver | None = None,
        driver_config: DriverConfig | None = None,
    ) -> None:
        # See ``Neo4jGraphStore.__init__`` for the driver-ownership contract.
        #
        # HNSW knobs (``m`` / ``ef_construction`` / ``quantization``) only
        # apply when this store creates the index. ``CREATE VECTOR INDEX
        # IF NOT EXISTS`` is a no-op against an existing index, so swapping
        # values on an existing index requires a manual ``DROP INDEX``
        # first. The chosen defaults err on correctness: ``quantization
        # =False`` because AuraDB's quantization=true default collapses
        # recall on low-dimensional vectors (recall@10 = 0.36 measured on
        # dim=16 vectors against AuraDB Free, 2026-04-27).
        check_driver_installed()
        if similarity not in _VALID_SIMILARITY:
            msg = (
                f"similarity must be one of {sorted(_VALID_SIMILARITY)}, "
                f"got {similarity!r}"
            )
            raise ValueError(msg)
        if dimensions <= 0:
            msg = f"dimensions must be > 0, got {dimensions}"
            raise ValueError(msg)
        if m <= 0:
            msg = f"m must be > 0, got {m}"
            raise ValueError(msg)
        if ef_construction <= 0:
            msg = f"ef_construction must be > 0, got {ef_construction}"
            raise ValueError(msg)

        if driver is not None:
            if password is not None or driver_config is not None:
                msg = (
                    "Pass either ``driver`` (caller-owned) or "
                    "``password`` + ``driver_config`` (store-owned), not both."
                )
                raise ValueError(msg)
            self._driver: Driver = driver
            self._owns_driver = False
        else:
            if password is None:
                msg = "password is required when ``driver`` is not provided"
                raise ValueError(msg)
            self._driver = build_driver(uri, user, password, config=driver_config)
            self._owns_driver = True
        self._database = database
        self._dimensions = dimensions
        self._similarity = similarity
        self._index = index_name
        self._index_wait_timeout = index_wait_timeout
        self._m = m
        self._ef_construction = ef_construction
        self._quantization = quantization
        self._init_schema()
        logger.info(
            "neo4j_vector_store_initialized",
            dimensions=dimensions,
            similarity=similarity,
            index_name=index_name,
            m=m,
            ef_construction=ef_construction,
            quantization=quantization,
        )

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def _init_schema(self) -> None:
        # The VECTOR INDEX DDL doesn't accept bound parameters for the
        # index name or options map — they must be Cypher literals.
        # All inputs are validated in ``__init__`` so inlining is safe.
        quantization_literal = "true" if self._quantization else "false"
        index = (
            f"CREATE VECTOR INDEX {self._index} IF NOT EXISTS "
            "FOR (n:Node) ON n.embedding "
            "OPTIONS {indexConfig: {"
            f"  `vector.dimensions`: {self._dimensions}, "
            f"  `vector.similarity_function`: '{self._similarity}', "
            f"  `vector.hnsw.m`: {self._m}, "
            f"  `vector.hnsw.ef_construction`: {self._ef_construction}, "
            f"  `vector.quantization.enabled`: {quantization_literal}"
            "}}"
        )
        with self._driver.session(database=self._database) as session:
            session.run(index)
        # AuraDB provisions vector indexes asynchronously. Block until
        # ONLINE so the first query after init doesn't race the
        # population background job. The 30s default covers AuraDB Free
        # comfortably; tighten via ``index_wait_timeout`` for tests
        # that already share a persistent index, or to fail fast on a
        # known-broken cluster.
        wait_for_vector_index_online(
            self._driver,
            database=self._database,
            index_name=self._index,
            timeout=self._index_wait_timeout,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def upsert(
        self,
        item_id: str,
        vector: list[float],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        if len(vector) != self._dimensions:
            msg = (
                f"vector has {len(vector)} dimensions but store was "
                f"configured for {self._dimensions}"
            )
            raise ValueError(msg)
        meta_json = json.dumps(metadata or {})
        # Embedding attaches to the CURRENT (valid_to IS NULL) version
        # of the node. No node ⇒ caller mistake; raise.
        cypher = (
            "MATCH (n:Node {node_id: $item_id}) WHERE n.valid_to IS NULL "
            "SET n.embedding = $vector, n.vector_metadata_json = $meta_json "
            "RETURN n.node_id AS node_id"
        )
        record = self._run_write_single(
            cypher,
            item_id=item_id,
            vector=vector,
            meta_json=meta_json,
        )
        if record is None:
            msg = (
                f"Cannot attach vector: node {item_id!r} has no current "
                "version. Create the node via GraphStore.upsert_node first."
            )
            raise ValueError(msg)

    def upsert_bulk(self, items: list[dict[str, Any]]) -> None:
        if not items:
            return

        # Pass 1 — Python-side validation. Catches dimension mismatches
        # and missing keys before any I/O so a bad row in the middle of
        # a 1K-vector batch doesn't leave half written. Within-batch
        # duplicate item_ids are rejected because UNWIND would fire SET
        # twice non-deterministically (last-write-wins by Neo4j
        # iteration order).
        self._validate_bulk_required_keys(items, ("item_id", "vector"), "upsert_bulk")
        rows: list[dict[str, Any]] = []
        for i, spec in enumerate(items):
            vector = spec["vector"]
            if len(vector) != self._dimensions:
                msg = (
                    f"upsert_bulk[{i}]: vector has {len(vector)} dimensions "
                    f"but store was configured for {self._dimensions}"
                )
                raise ValueError(msg)
            rows.append(
                {
                    "item_id": spec["item_id"],
                    "vector": vector,
                    "meta_json": json.dumps(spec.get("metadata") or {}),
                }
            )
        self._pre_validate_bulk_item_ids(items)

        # One round trip — UNWIND attaches every row to its current
        # node. Rows whose node has no current version (or doesn't
        # exist) are silently dropped by the MATCH; we count returned
        # rows after to detect and raise on missing endpoints. Mirrors
        # the single-row :meth:`upsert` error message.
        cypher = """
        UNWIND $rows AS row
        MATCH (n:Node {node_id: row.item_id}) WHERE n.valid_to IS NULL
        SET n.embedding = row.vector,
            n.vector_metadata_json = row.meta_json
        RETURN n.node_id AS node_id
        """
        with self._driver.session(database=self._database) as session:
            records = session.execute_write(lambda tx: list(tx.run(cypher, rows=rows)))

        if len(records) != len(rows):
            written = {r["node_id"] for r in records}
            for i, spec in enumerate(items):
                if spec["item_id"] not in written:
                    msg = (
                        f"upsert_bulk[{i}]: cannot attach vector — node "
                        f"{spec['item_id']!r} has no current version. "
                        "Create the node via GraphStore.upsert_node first."
                    )
                    raise ValueError(msg)

        logger.debug("vectors_upserted_bulk", count=len(rows))

    def query(
        self,
        vector: list[float],
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        if len(vector) != self._dimensions:
            msg = (
                f"query vector has {len(vector)} dimensions but store was "
                f"configured for {self._dimensions}"
            )
            raise ValueError(msg)
        # Over-fetch when filters are present (applied client-side after
        # JSON decode) and to compensate for any closed historical
        # versions the index might still return — query filters those
        # out via valid_to IS NULL.
        fetch_k = top_k * _OVER_FETCH_MULT if filters else top_k * 2
        # Cypher 25 SEARCH clause replaces the deprecated
        # ``db.index.vector.queryNodes`` procedure. The index name must
        # be a Cypher literal — bound parameters are not accepted on the
        # ``VECTOR INDEX`` reference. ``self._index`` is validated at
        # construction time, so inlining is safe (same rule the CREATE
        # DDL in ``_init_schema`` follows).
        #
        # ``valid_to IS NULL`` lives in the post-SEARCH WHERE rather
        # than the index-WHERE because the vector index only honours
        # properties explicitly registered as additional filter
        # properties at CREATE time — empirically confirmed against
        # AuraDB 2026-04-27. Pushing the filter down would require
        # reissuing CREATE VECTOR INDEX with ``additionalFilterProperties``,
        # which is a separate optimisation gated on its own evidence.
        cypher = (
            f"MATCH (n:Node) "
            f"SEARCH n IN ( "
            f"  VECTOR INDEX {self._index} FOR $vector "
            f"  LIMIT $k "
            f") SCORE AS score "
            f"WHERE n.valid_to IS NULL "
            f"RETURN n.node_id AS item_id, score, "
            f"       n.vector_metadata_json AS metadata_json"
        )
        records = self._run_read_list(cypher, k=fetch_k, vector=vector)

        results: list[dict[str, Any]] = []
        for r in records:
            meta = json.loads(r["metadata_json"] or "{}")
            if filters and not all(meta.get(k) == v for k, v in filters.items()):
                continue
            results.append(
                {
                    "item_id": r["item_id"],
                    "score": float(r["score"]),
                    "metadata": meta,
                }
            )
            if len(results) >= top_k:
                break
        return results

    def get(self, item_id: str) -> dict[str, Any] | None:
        cypher = (
            "MATCH (n:Node {node_id: $item_id}) "
            "WHERE n.valid_to IS NULL AND n.embedding IS NOT NULL "
            "RETURN n.embedding AS embedding, "
            "       n.vector_metadata_json AS metadata_json"
        )
        record = self._run_read_single(cypher, item_id=item_id)
        if record is None:
            return None
        vec = list(record["embedding"])
        meta = json.loads(record["metadata_json"] or "{}")
        return {
            "item_id": item_id,
            "vector": vec,
            "dimensions": len(vec),
            "metadata": meta,
        }

    def delete(self, item_id: str) -> bool:
        # Removes the embedding from the current version only — the
        # node itself stays. Historical versions retain their
        # embeddings (queryable via ``GraphStore.get_node_history``
        # but excluded from vector search by the ``valid_to IS NULL``
        # filter).
        def _tx(tx: Any) -> bool:
            record = tx.run(
                "MATCH (n:Node {node_id: $id}) "
                "WHERE n.valid_to IS NULL AND n.embedding IS NOT NULL "
                "RETURN count(n) AS cnt",
                id=item_id,
            ).single()
            existed = bool(record and record["cnt"] > 0)
            tx.run(
                "MATCH (n:Node {node_id: $id}) WHERE n.valid_to IS NULL "
                "REMOVE n.embedding, n.vector_metadata_json",
                id=item_id,
            ).consume()
            return existed

        with self._driver.session(database=self._database) as session:
            return bool(session.execute_write(_tx))

    def count(self) -> int:
        cypher = (
            "MATCH (n:Node) "
            "WHERE n.valid_to IS NULL AND n.embedding IS NOT NULL "
            "RETURN count(n) AS cnt"
        )
        record = self._run_read_single(cypher)
        return int(record["cnt"]) if record else 0

    def close(self) -> None:
        if self._owns_driver:
            self._driver.close()
            logger.info("neo4j_vector_store_closed")
        else:
            logger.debug("neo4j_vector_store_close_noop_injected_driver")
