# src/rhosocial/activerecord/backend/impl/sqlite/cli/named_query.py
"""named-query subcommand - Adapter for shared CLI helper.

named-query requires connection arguments, output arguments, and --rich-ascii.
"""


from rhosocial.activerecord.backend.impl.sqlite.backend import SQLiteBackend
from rhosocial.activerecord.backend.options import ExecutionOptions

from .connection import create_connection_parent_parser, resolve_connection_config_from_args
from .output import create_provider


def create_parser(subparsers):
    """Create the named-query subcommand parser.

    Reuses the shared create_named_query_parser, passing a parent parser
    containing only connection and output arguments.
    """
    from rhosocial.activerecord.backend.named_query.cli import create_named_query_parser
    local_parent = create_connection_parent_parser()
    return create_named_query_parser(subparsers, local_parent)


def handle(args):
    """Handle the named-query subcommand."""
    from rhosocial.activerecord.backend.named_query.cli import handle_named_query as handle_nq

    provider = create_provider(args.output, ascii_borders=args.rich_ascii)

    backend = None

    def backend_factory():
        nonlocal backend
        config = resolve_connection_config_from_args(args)
        backend = SQLiteBackend(connection_config=config)
        backend.connect()
        backend.introspect_and_adapt()
        return backend

    def get_dialect(b):
        return b.dialect

    def execute_query_by_name(sql, params, stmt_type):
        return backend.execute(sql, params, options=ExecutionOptions(stmt_type=stmt_type))

    def disconnect():
        if backend and backend._connection:
            backend.disconnect()

    is_async = getattr(args, "is_async", False)
    if is_async:
        async_backend = None

        def backend_async_factory():
            nonlocal async_backend
            from rhosocial.activerecord.backend.impl.sqlite import AsyncSQLiteBackend
            config = resolve_connection_config_from_args(args)
            async_backend = AsyncSQLiteBackend(connection_config=config)
            return async_backend

        async def get_dialect_async(b):
            return b.dialect

        async def execute_query_async(sql, params, stmt_type):
            return await async_backend.execute(sql, params, options=ExecutionOptions(stmt_type=stmt_type))

        async def disconnect_async():
            if async_backend and async_backend._connection:
                await async_backend.disconnect()

        handle_nq(
            args,
            provider,
            backend_factory=backend_factory,
            get_dialect=get_dialect,
            execute_query=execute_query_by_name,
            disconnect=disconnect,
            backend_async_factory=backend_async_factory,
            get_dialect_async=get_dialect_async,
            execute_query_async=execute_query_async,
            disconnect_async=disconnect_async,
        )
        return

    handle_nq(
        args,
        provider,
        backend_factory=backend_factory,
        get_dialect=get_dialect,
        execute_query=execute_query_by_name,
        disconnect=disconnect,
    )
