# src/rhosocial/activerecord/backend/impl/sqlite/cli/named_procedure.py
"""named-procedure subcommand - Adapter for shared CLI helper.

named-procedure requires connection arguments, output arguments, and --rich-ascii.
"""

from rhosocial.activerecord.backend.impl.sqlite.backend import SQLiteBackend

from .connection import create_connection_parent_parser, resolve_connection_config_from_args
from .output import create_provider


def create_parser(subparsers):
    """Create the named-procedure subcommand parser.

    Reuses the shared create_named_procedure_parser, passing a parent parser
    containing only connection and output arguments.
    """
    from rhosocial.activerecord.backend.named_query.cli_procedure import create_named_procedure_parser
    local_parent = create_connection_parent_parser()
    return create_named_procedure_parser(subparsers, local_parent)


def handle(args):
    """Handle the named-procedure subcommand."""
    from rhosocial.activerecord.backend.named_query.cli_procedure import handle_named_procedure as handle_np

    provider = create_provider(args.output, ascii_borders=args.rich_ascii)

    backend = None

    def backend_factory():
        nonlocal backend
        config = resolve_connection_config_from_args(args)
        backend = SQLiteBackend(connection_config=config)
        backend.connect()
        backend.introspect_and_adapt()
        return backend

    def disconnect():
        if backend and backend._connection:
            backend.disconnect()

    is_async = getattr(args, "is_async", False)
    if is_async:
        async_backend = None

        def backend_async_factory():
            nonlocal async_backend
            from rhosocial.activerecord.backend.impl.sqlite import AsyncSQLiteBackend
            config = resolve_connection_config_from_args(args)
            async_backend = AsyncSQLiteBackend(connection_config=config)
            return async_backend

        async def disconnect_async():
            if async_backend and async_backend._connection:
                await async_backend.disconnect()

        handle_np(
            args,
            provider,
            backend_factory=backend_factory,
            disconnect=disconnect,
            backend_async_factory=backend_async_factory,
            disconnect_async=disconnect_async,
        )
        return

    handle_np(
        args,
        provider,
        backend_factory=backend_factory,
        disconnect=disconnect,
    )