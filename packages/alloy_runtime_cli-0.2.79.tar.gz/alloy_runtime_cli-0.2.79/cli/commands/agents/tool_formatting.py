import json

from alloy_runtime_types.dtos.agents import AgentToolResponse


def _format_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def format_tool_details(tools: list[AgentToolResponse]) -> str:
    if not tools:
        return "(none)"
    parts: list[str] = []
    for tool in tools:
        lines = [
            f"{tool.tool_alias} ({tool.tool_id}, {tool.config_source}, {tool.update_mode})",
            f"submitted={_format_json(tool.submitted_config)}",
            f"effective={_format_json(tool.effective_config)}",
        ]
        if tool.defaults_applied:
            lines.append(f"defaults={', '.join(tool.defaults_applied)}")
        if tool.tool_config_name:
            lines.append(f"tool_config_name={tool.tool_config_name}")
        parts.append(" ".join(lines))
    return "\n\n".join(parts)
