"""Presenter for agents list command output."""

from datetime import datetime

from alloy_runtime_types.dtos.agents import ListAgentsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_created_at(value: datetime | None) -> str:
    if value is None:
        return "(null)"
    return value.strftime("%Y-%m-%d")


def _format_model_count(value: int | None) -> str:
    if value is None:
        return "(null)"
    suffix = "model" if value == 1 else "models"
    return f"{value} {suffix}"


def _format_description(value: str | None) -> str:
    if value is None:
        return "(null)"
    return value


def present_agents_list(response: ListAgentsResponse) -> None:
    output = OutputService.get()
    columns = [
        ColumnConfig(
            source_field="name",
            header_label="Name",
        ),
        ColumnConfig(
            source_field="id",
            header_label="ID",
        ),
        ColumnConfig(
            source_field="model_count",
            header_label="Models",
            formatter=_format_model_count,
        ),
        ColumnConfig(
            source_field="created_at",
            header_label="Created",
            formatter=_format_created_at,
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=_format_description,
        ),
    ]

    output.table(
        items=response.agents,  # type: ignore[arg-type]
        title="Agents",
        columns=columns,
        raw_payload=response,
    )
