"""Тесты для core.py"""

import pytest
from pathlib import Path
import tempfile
from unittest.mock import patch, MagicMock

from etgdlp.core import (
    download, 
    download_audio, 
    download_video, 
    download_playlist,
    check_ffmpeg,
    _sanitize_filename
)
from etgdlp.types import DownloadResult, MediaType
from etgdlp.exceptions import FFmpegNotFoundError


class TestSanitizeFilename:
    """Тесты для очистки имен файлов"""
    
    def test_sanitize_simple(self):
        """Простое имя без спецсимволов"""
        assert _sanitize_filename("hello") == "hello"
    
    def test_sanitize_with_spaces(self):
        """Имя с пробелами"""
        assert _sanitize_filename("hello world") == "hello world"
    
    def test_sanitize_with_invalid_chars(self):
        """Имя с недопустимыми символами"""
        assert _sanitize_filename('hello:world?') == 'hello_world_'
        assert _sanitize_filename('a<b>c') == 'a_b_c'
        assert _sanitize_filename('file"name') == 'file_name'
    
    def test_sanitize_with_slashes(self):
        """Имя со слешами"""
        assert _sanitize_filename('path/to/file') == 'path_to_file'
        assert _sanitize_filename('C:\\Windows') == 'C_Windows'


class TestCheckFFmpeg:
    """Тесты для проверки FFmpeg"""
    
    @patch('subprocess.run')
    def test_ffmpeg_found(self, mock_run):
        """FFmpeg найден"""
        mock_run.return_value = MagicMock(returncode=0)
        assert check_ffmpeg() is True
    
    @patch('subprocess.run')
    def test_ffmpeg_not_found(self, mock_run):
        """FFmpeg не найден"""
        mock_run.side_effect = FileNotFoundError()
        assert check_ffmpeg() is False


class TestDownload:
    """Тесты для функции download"""
    
    def test_download_invalid_url(self):
        """Неверный URL"""
        result = download("https://youtube.com/watch?v=invalid123")
        assert isinstance(result, DownloadResult)
        assert result.success is False
        assert result.error is not None
        assert result.url == "https://youtube.com/watch?v=invalid123"
    
    def test_download_with_custom_output_dir(self):
        """Скачивание с кастомной папкой"""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            result = download(
                "https://youtube.com/watch?v=invalid123",
                output_dir=output_dir
            )
            assert result.success is False  # URL невалидный, но папка создана
            assert output_dir.exists()
    
    def test_download_result_structure(self):
        """Проверка структуры результата"""
        result = download("https://youtube.com/watch?v=invalid123")
        assert hasattr(result, 'success')
        assert hasattr(result, 'path')
        assert hasattr(result, 'error')
        assert hasattr(result, 'url')
        assert hasattr(result, 'title')
        assert hasattr(result, 'duration')
        assert hasattr(result, 'file_size')
        assert hasattr(result, 'media_type')
        assert hasattr(result, 'download_time')


class TestDownloadAudio:
    """Тесты для скачивания аудио"""
    
    def test_download_audio_invalid_url(self):
        """Неверный URL для аудио"""
        result = download_audio("https://youtube.com/watch?v=invalid123")
        assert isinstance(result, DownloadResult)
        assert result.success is False
    
    def test_download_audio_params(self):
        """Проверка передачи параметров"""
        with patch('etgdlp.core.download') as mock_download:
            mock_download.return_value = DownloadResult(success=True)
            
            download_audio(
                "https://youtube.com/watch?v=test",
                quality="320",
                audio_format="mp3",
                verbose=True
            )
            
            # Проверяем, что download вызван с правильными параметрами
            mock_download.assert_called_once()
            call_kwargs = mock_download.call_args[1]
            assert call_kwargs['download_type'] == 'audio'
            assert call_kwargs['quality'] == '320'
            assert call_kwargs['audio_format'] == 'mp3'
            assert call_kwargs['verbose'] is True


class TestDownloadVideo:
    """Тесты для скачивания видео"""
    
    def test_download_video_invalid_url(self):
        """Неверный URL для видео"""
        result = download_video("https://youtube.com/watch?v=invalid123")
        assert isinstance(result, DownloadResult)
        assert result.success is False
    
    def test_download_video_params(self):
        """Проверка передачи параметров"""
        with patch('etgdlp.core.download') as mock_download:
            mock_download.return_value = DownloadResult(success=True)
            
            download_video(
                "https://youtube.com/watch?v=test",
                quality="720",
                verbose=True
            )
            
            mock_download.assert_called_once()
            call_kwargs = mock_download.call_args[1]
            assert call_kwargs['download_type'] == 'video'
            assert call_kwargs['quality'] == '720'
            assert call_kwargs['verbose'] is True


class TestDownloadPlaylist:
    """Тесты для скачивания плейлистов"""
    
    def test_download_playlist_invalid_url(self):
        """Неверный URL для плейлиста"""
        result = download_playlist("https://youtube.com/playlist?list=invalid")
        assert isinstance(result, DownloadResult)
        assert result.success is False
    
    def test_download_playlist_params(self):
        """Проверка передачи параметров"""
        with patch('etgdlp.core.download') as mock_download:
            mock_download.return_value = DownloadResult(success=True)
            
            download_playlist(
                "https://youtube.com/playlist?list=test",
                max_items=10,
                quality="480"
            )
            
            mock_download.assert_called_once()
            call_kwargs = mock_download.call_args[1]
            assert call_kwargs['playlist'] is True
            assert call_kwargs['max_playlist_items'] == 10
            assert call_kwargs['quality'] == '480'