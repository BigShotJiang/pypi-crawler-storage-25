"""Тесты для исключений"""

import pytest

from etgdlp.exceptions import (
    ETGDLPError,
    DownloadError,
    InvalidURLError,
    FFmpegNotFoundError,
    FormatNotAvailableError,
    CookieError,
    PlaylistError
)


class TestExceptions:
    """Тесты для иерархии исключений"""
    
    def test_base_exception(self):
        """Базовое исключение"""
        with pytest.raises(ETGDLPError):
            raise ETGDLPError("Base error")
    
    def test_download_error(self):
        """Ошибка загрузки"""
        with pytest.raises(DownloadError):
            raise DownloadError("Download failed")
        
        # Проверяем наследование
        with pytest.raises(ETGDLPError):
            raise DownloadError("Download failed")
    
    def test_invalid_url_error(self):
        """Ошибка неверного URL"""
        with pytest.raises(InvalidURLError):
            raise InvalidURLError("Invalid URL")
    
    def test_ffmpeg_not_found_error(self):
        """Ошибка отсутствия FFmpeg"""
        with pytest.raises(FFmpegNotFoundError):
            raise FFmpegNotFoundError("FFmpeg not found")
    
    def test_format_not_available_error(self):
        """Ошибка недоступного формата"""
        with pytest.raises(FormatNotAvailableError):
            raise FormatNotAvailableError("Format not available")
    
    def test_cookie_error(self):
        """Ошибка cookies"""
        with pytest.raises(CookieError):
            raise CookieError("Cookie error")
    
    def test_playlist_error(self):
        """Ошибка плейлиста"""
        with pytest.raises(PlaylistError):
            raise PlaylistError("Playlist error")
    
    def test_exception_hierarchy(self):
        """Проверка иерархии исключений"""
        exceptions = [
            DownloadError,
            InvalidURLError,
            FFmpegNotFoundError,
            FormatNotAvailableError,
            CookieError,
            PlaylistError
        ]
        
        for exc in exceptions:
            with pytest.raises(ETGDLPError):
                raise exc("Test")