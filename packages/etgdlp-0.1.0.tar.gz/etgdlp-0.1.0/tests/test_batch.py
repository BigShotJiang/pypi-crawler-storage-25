"""Тесты для batch.py"""

import pytest
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

from etgdlp.batch import download_batch, download_from_file
from etgdlp.types import DownloadResult, BatchDownloadResult
from etgdlp.exceptions import DownloadError


class TestDownloadBatch:
    """Тесты для пакетной загрузки"""
    
    def test_download_batch_empty(self):
        """Пустой список URL"""
        result = download_batch([])
        
        assert isinstance(result, BatchDownloadResult)
        assert result.total == 0
        assert result.successful == 0
        assert result.failed == 0
    
    @patch('etgdlp.batch.download')
    def test_download_batch_all_success(self, mock_download):
        """Все успешно"""
        mock_download.side_effect = [
            DownloadResult(success=True),
            DownloadResult(success=True),
            DownloadResult(success=True)
        ]
        
        urls = ["url1", "url2", "url3"]
        result = download_batch(urls)
        
        assert result.total == 3
        assert result.successful == 3
        assert result.failed == 0
        assert len(result.results) == 3
    
    @patch('etgdlp.batch.download')
    def test_download_batch_with_failures(self, mock_download):
        """Некоторые неудачные"""
        mock_download.side_effect = [
            DownloadResult(success=True),
            DownloadResult(success=False, error="Failed"),
            DownloadResult(success=True)
        ]
        
        result = download_batch(["url1", "url2", "url3"])
        
        assert result.total == 3
        assert result.successful == 2
        assert result.failed == 1
    
    @patch('etgdlp.batch.download')
    def test_download_batch_stop_on_error(self, mock_download):
        """Остановка при первой ошибке"""
        mock_download.side_effect = [
            DownloadResult(success=True),
            DownloadResult(success=False, error="Failed"),
            DownloadResult(success=True)  # Не должен вызваться
        ]
        
        result = download_batch(
            ["url1", "url2", "url3"],
            stop_on_error=True
        )
        
        assert result.total == 3
        assert result.successful == 1
        assert result.failed == 1
        assert len(result.results) == 2  # Только первые два
    
    @patch('etgdlp.batch.download')
    def test_download_batch_with_callback(self, mock_download):
        """С callback функцией"""
        mock_download.side_effect = [
            DownloadResult(success=True),
            DownloadResult(success=True)
        ]
        
        callback_calls = []
        
        def callback(current, total, result):
            callback_calls.append((current, total))
        
        result = download_batch(
            ["url1", "url2"],
            progress_callback=callback
        )
        
        assert len(callback_calls) == 2
        assert callback_calls[0] == (1, 2)
        assert callback_calls[1] == (2, 2)


class TestDownloadFromFile:
    """Тесты для загрузки из файла"""
    
    def test_download_from_file_valid(self):
        """Валидный файл со ссылками"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("https://youtube.com/watch?v=1\n")
            f.write("https://youtube.com/watch?v=2\n")
            f.write("# Это комментарий\n")
            f.write("https://youtube.com/watch?v=3\n")
            file_path = f.name
        
        with patch('etgdlp.batch.download_batch') as mock_batch:
            mock_batch.return_value = BatchDownloadResult(total=3, successful=3, failed=0)
            
            result = download_from_file(file_path)
            
            # Проверяем, что download_batch вызван с 3 URL (комментарий пропущен)
            call_args = mock_batch.call_args[1]
            assert len(call_args['urls']) == 3
            assert call_args['urls'][0] == "https://youtube.com/watch?v=1"
            assert call_args['urls'][2] == "https://youtube.com/watch?v=3"
        
        Path(file_path).unlink()
    
    def test_download_from_file_empty(self):
        """Пустой файл"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("# Только комментарии\n")
            f.write("\n")
            file_path = f.name
        
        with pytest.raises(ValueError, match="Файл не содержит ссылок"):
            download_from_file(file_path)
        
        Path(file_path).unlink()
    
    def test_download_from_file_not_exists(self):
        """Файл не существует"""
        with pytest.raises(FileNotFoundError):
            download_from_file("/nonexistent/file.txt")
    
    def test_download_from_file_with_options(self):
        """С опциями"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("https://youtube.com/watch?v=1\n")
            file_path = f.name
        
        with patch('etgdlp.batch.download_batch') as mock_batch:
            mock_batch.return_value = BatchDownloadResult(total=1, successful=1, failed=0)
            
            result = download_from_file(
                file_path,
                download_type="audio",
                quality="192",
                verbose=True
            )
            
            call_kwargs = mock_batch.call_args[1]
            assert call_kwargs['download_type'] == "audio"
            assert call_kwargs['quality'] == "192"
            assert call_kwargs['verbose'] is True
        
        Path(file_path).unlink()