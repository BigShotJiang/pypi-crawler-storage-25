"""Тесты для info.py"""

import pytest
from unittest.mock import patch, MagicMock

from etgdlp.info import (
    get_video_info,
    check_url,
    get_available_formats
)
from etgdlp.types import VideoInfo
from etgdlp.exceptions import InvalidURLError, FormatNotAvailableError


class TestGetVideoInfo:
    """Тесты для получения информации о видео"""
    
    @patch('yt_dlp.YoutubeDL')
    def test_get_video_info_success(self, mock_ydl):
        """Успешное получение информации"""
        # Мокаем информацию
        mock_info = {
            'id': 'test123',
            'title': 'Test Video',
            'duration': 120,
            'uploader': 'Test Uploader',
            'upload_date': '20240101',
            'view_count': 1000,
            'like_count': 100,
            'description': 'Test description',
            'thumbnail': 'https://example.com/thumb.jpg',
            'formats': [
                {'height': 1080, 'vcodec': 'avc1', 'acodec': 'mp4a'},
                {'height': 720, 'vcodec': 'avc1', 'acodec': 'mp4a'},
            ],
            'subtitles': {'en': [], 'ru': []}
        }
        
        mock_ydl_instance = MagicMock()
        mock_ydl_instance.extract_info.return_value = mock_info
        mock_ydl.return_value.__enter__.return_value = mock_ydl_instance
        
        info = get_video_info("https://youtube.com/watch?v=test123")
        
        assert info is not None
        assert isinstance(info, VideoInfo)
        assert info.id == 'test123'
        assert info.title == 'Test Video'
        assert info.duration == 120
        assert info.uploader == 'Test Uploader'
        assert info.view_count == 1000
        assert '1080p' in info.available_formats
    
    @patch('yt_dlp.YoutubeDL')
    def test_get_video_info_failure(self, mock_ydl):
        """Ошибка получения информации"""
        mock_ydl_instance = MagicMock()
        mock_ydl_instance.extract_info.side_effect = Exception("Network error")
        mock_ydl.return_value.__enter__.return_value = mock_ydl_instance
        
        info = get_video_info("https://youtube.com/watch?v=test123")
        
        assert info is None
    
    @patch('yt_dlp.YoutubeDL')
    def test_get_video_info_empty(self, mock_ydl):
        """Пустая информация"""
        mock_ydl_instance = MagicMock()
        mock_ydl_instance.extract_info.return_value = None
        mock_ydl.return_value.__enter__.return_value = mock_ydl_instance
        
        info = get_video_info("https://youtube.com/watch?v=test123")
        
        assert info is None


class TestCheckURL:
    """Тесты для проверки URL"""
    
    @patch('yt_dlp.YoutubeDL')
    def test_check_url_valid(self, mock_ydl):
        """Валидный URL"""
        mock_ydl_instance = MagicMock()
        mock_ydl_instance.extract_info.return_value = {'id': 'test'}
        mock_ydl.return_value.__enter__.return_value = mock_ydl_instance
        
        assert check_url("https://youtube.com/watch?v=test") is True
    
    @patch('yt_dlp.YoutubeDL')
    def test_check_url_invalid(self, mock_ydl):
        """Невалидный URL"""
        mock_ydl_instance = MagicMock()
        mock_ydl_instance.extract_info.side_effect = Exception("Invalid URL")
        mock_ydl.return_value.__enter__.return_value = mock_ydl_instance
        
        assert check_url("invalid") is False


class TestGetAvailableFormats:
    """Тесты для получения доступных форматов"""
    
    @patch('etgdlp.info.get_video_info')
    def test_get_available_formats_success(self, mock_get_info):
        """Успешное получение форматов"""
        mock_info = MagicMock()
        mock_info.available_formats = ['1080p', '720p', '480p']
        mock_get_info.return_value = mock_info
        
        formats = get_available_formats("https://youtube.com/watch?v=test")
        
        assert formats == ['1080p', '720p', '480p']
    
    @patch('etgdlp.info.get_video_info')
    def test_get_available_formats_no_info(self, mock_get_info):
        """Нет информации"""
        mock_get_info.return_value = None
        
        with pytest.raises(InvalidURLError):
            get_available_formats("https://youtube.com/watch?v=test")
    
    @patch('etgdlp.info.get_video_info')
    def test_get_available_formats_empty(self, mock_get_info):
        """Пустой список форматов"""
        mock_info = MagicMock()
        mock_info.available_formats = []
        mock_get_info.return_value = mock_info
        
        with pytest.raises(FormatNotAvailableError):
            get_available_formats("https://youtube.com/watch?v=test")