"""Тесты для types.py"""

import pytest
from datetime import datetime
from pathlib import Path

from etgdlp.types import (
    DownloadResult,
    VideoInfo,
    BatchDownloadResult,
    MediaType,
    DownloadStatus
)


class TestDownloadResult:
    """Тесты для DownloadResult"""
    
    def test_download_result_success(self):
        """Успешный результат"""
        result = DownloadResult(
            success=True,
            path=Path("/tmp/video.mp4"),
            title="Test Video",
            duration=120,
            file_size=1024
        )
        
        assert result.success is True
        assert result.path == Path("/tmp/video.mp4")
        assert result.title == "Test Video"
        assert result.error is None
        assert result.warnings == []
    
    def test_download_result_failure(self):
        """Неуспешный результат"""
        result = DownloadResult(
            success=False,
            error="Network error"
        )
        
        assert result.success is False
        assert result.error == "Network error"
    
    def test_download_result_to_dict(self):
        """Конвертация в словарь"""
        result = DownloadResult(
            success=True,
            path=Path("/tmp/video.mp4"),
            title="Test",
            duration=120,
            download_time=datetime(2024, 1, 1, 12, 0)
        )
        
        d = result.to_dict()
        assert d['success'] is True
        assert d['path'] == "/tmp/video.mp4"
        assert d['title'] == "Test"
        assert d['duration'] == 120
        assert d['download_time'] == "2024-01-01T12:00:00"
    
    def test_download_result_repr(self):
        """Строковое представление"""
        result_success = DownloadResult(success=True, path=Path("/tmp/file.mp4"))
        result_fail = DownloadResult(success=False, error="Error")
        
        assert "success=True" in repr(result_success)
        assert "success=False" in repr(result_fail)


class TestVideoInfo:
    """Тесты для VideoInfo"""
    
    def test_video_info_creation(self):
        """Создание объекта"""
        info = VideoInfo(
            id="test123",
            title="Test Video",
            duration=120,
            uploader="Test User"
        )
        
        assert info.id == "test123"
        assert info.title == "Test Video"
        assert info.duration == 120
        assert info.uploader == "Test User"
        assert info.formats == []
    
    def test_video_info_to_dict(self):
        """Конвертация в словарь"""
        info = VideoInfo(
            id="test123",
            title="Test Video",
            duration=120,
            uploader="Test User",
            view_count=1000,
            available_formats=["720p", "1080p"]
        )
        
        d = info.to_dict()
        assert d['id'] == "test123"
        assert d['title'] == "Test Video"
        assert d['view_count'] == 1000
        assert d['available_formats'] == ["720p", "1080p"]


class TestBatchDownloadResult:
    """Тесты для BatchDownloadResult"""
    
    def test_batch_result_creation(self):
        """Создание результата пакетной загрузки"""
        results = [
            DownloadResult(success=True),
            DownloadResult(success=False),
            DownloadResult(success=True)
        ]
        
        batch = BatchDownloadResult(
            total=3,
            successful=2,
            failed=1,
            results=results
        )
        
        assert batch.total == 3
        assert batch.successful == 2
        assert batch.failed == 1
        assert batch.success_rate == 66.66666666666666
    
    def test_batch_result_empty(self):
        """Пустой результат"""
        batch = BatchDownloadResult(total=0, successful=0, failed=0)
        
        assert batch.success_rate == 0.0
    
    def test_batch_result_to_dict(self):
        """Конвертация в словарь"""
        results = [DownloadResult(success=True)]
        batch = BatchDownloadResult(
            total=1,
            successful=1,
            failed=0,
            results=results
        )
        
        d = batch.to_dict()
        assert d['total'] == 1
        assert d['successful'] == 1
        assert d['failed'] == 0
        assert len(d['results']) == 1


class TestEnums:
    """Тесты для Enum классов"""
    
    def test_media_type(self):
        """MediaType enum"""
        assert MediaType.VIDEO.value == "video"
        assert MediaType.AUDIO.value == "audio"
        assert MediaType.PLAYLIST.value == "playlist"
    
    def test_download_status(self):
        """DownloadStatus enum"""
        assert DownloadStatus.PENDING.value == "pending"
        assert DownloadStatus.DOWNLOADING.value == "downloading"
        assert DownloadStatus.COMPLETED.value == "completed"