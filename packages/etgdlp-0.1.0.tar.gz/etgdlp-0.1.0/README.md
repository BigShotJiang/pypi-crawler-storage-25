# etgdlp

[![PyPI version](https://badge.fury.io/py/etgdlp.svg)](https://pypi.org/project/etgdlp/)
[![Python Versions](https://img.shields.io/pypi/pyversions/etgdlp.svg)](https://pypi.org/project/etgdlp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Простая и мощная библиотека для скачивания видео и аудио с YouTube и других сайтов. Построена на основе yt-dlp.

## Возможности

- Скачивание видео в любом качестве (до 4K)
- Скачивание аудио в MP3, M4A, WAV, FLAC
- Поддержка плейлистов
- Пакетная загрузка из файла
- Получение информации о видео
- Красивый прогресс-бар
- CLI интерфейс
- Поддержка cookies

## Установка

```bash
pip install etgdlp