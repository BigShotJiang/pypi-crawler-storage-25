"""Прогресс-бар для загрузки"""

import sys
from typing import Optional
from tqdm import tqdm
import yt_dlp


class ProgressHook:
    """Хук для отображения прогресса загрузки"""
    
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.pbar: Optional[tqdm] = None
        self.total_bytes: Optional[int] = None
        self.downloaded_bytes: int = 0
        self.status: str = "Starting..."
        
    def __call__(self, d: dict):
        """Обрабатывает события от yt-dlp"""
        if d['status'] == 'downloading':
            self._handle_downloading(d)
        elif d['status'] == 'finished':
            self._handle_finished()
        elif d['status'] == 'error':
            self._handle_error(d)
    
    def _handle_downloading(self, d: dict):
        """Обрабатывает событие загрузки"""
        if self.total_bytes is None and d.get('total_bytes'):
            self.total_bytes = d['total_bytes']
            self.pbar = tqdm(
                total=self.total_bytes,
                unit='B',
                unit_scale=True,
                unit_divisor=1024,
                desc=self.status,
                file=sys.stdout,
                bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{rate_fmt}] {postfix}'
            )
        
        if self.pbar:
            downloaded = d.get('downloaded_bytes', 0)
            if downloaded > self.downloaded_bytes:
                self.pbar.update(downloaded - self.downloaded_bytes)
                self.downloaded_bytes = downloaded
                
            if self.verbose and d.get('speed'):
                speed = d['speed'] / 1024 / 1024  # MB/s
                self.pbar.set_postfix(speed=f"{speed:.2f} MB/s")
    
    def _handle_finished(self):
        """Обрабатывает завершение загрузки"""
        if self.pbar:
            self.pbar.close()
            self.pbar = None
        
        if self.verbose:
            print("\n✅ Загрузка завершена!")
    
    def _handle_error(self, d: dict):
        """Обрабатывает ошибку загрузки"""
        if self.pbar:
            self.pbar.close()
            self.pbar = None
        
        if self.verbose:
            print(f"\n❌ Ошибка: {d.get('error', 'Unknown error')}")
    
    def update_status(self, status: str):
        """Обновляет статус загрузки"""
        self.status = status
        if self.pbar:
            self.pbar.set_description(status)


class YTDLPLogger:
    """Логгер для yt-dlp"""
    
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
    
    def debug(self, msg: str):
        if self.verbose:
            print(f"[DEBUG] {msg}")
    
    def info(self, msg: str):
        if self.verbose:
            print(f"[INFO] {msg}")
    
    def warning(self, msg: str):
        print(f"[WARNING] {msg}")
    
    def error(self, msg: str):
        print(f"[ERROR] {msg}")