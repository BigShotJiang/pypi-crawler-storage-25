"""Пакетная загрузка"""

from pathlib import Path
from typing import List, Optional, Union, Callable, Dict, Any
from .core import download
from .types import DownloadResult, BatchDownloadResult
from .exceptions import DownloadError


def download_batch(
    urls: List[str],
    output_dir: Optional[Path] = None,
    download_type: str = "video",
    quality: str = "best",
    verbose: bool = False,
    stop_on_error: bool = False,
    progress_callback: Optional[Callable[[int, int, DownloadResult], None]] = None,
) -> BatchDownloadResult:
    """
    Скачивает несколько видео/аудио по списку URL
    
    Args:
        urls: Список ссылок
        output_dir: Папка для сохранения
        download_type: "video" или "audio"
        quality: Качество
        verbose: Выводить ли подробную информацию
        stop_on_error: Останавливаться ли при первой ошибке
        progress_callback: Функция для отслеживания прогресса
            Принимает (current, total, result)
    
    Returns:
        BatchDownloadResult
    """
    results = []
    successful = 0
    failed = 0
    
    for i, url in enumerate(urls, 1):
        if verbose:
            print(f"\n[{i}/{len(urls)}] Скачивание: {url}")
        
        try:
            result = download(
                url=url,
                output_dir=output_dir,
                download_type=download_type,  # type: ignore
                quality=quality,
                verbose=verbose,
            )
            
            results.append(result)
            
            if result.success:
                successful += 1
            else:
                failed += 1
                if stop_on_error:
                    break
            
            if progress_callback:
                progress_callback(i, len(urls), result)
                
        except Exception as e:
            result = DownloadResult(success=False, error=str(e), url=url)
            results.append(result)
            failed += 1
            if stop_on_error:
                break
    
    return BatchDownloadResult(
        total=len(urls),
        successful=successful,
        failed=failed,
        results=results,
    )


def download_from_file(
    file_path: Union[str, Path],
    output_dir: Optional[Path] = None,
    download_type: str = "video",
    quality: str = "best",
    verbose: bool = False,
    skip_comments: bool = True,
) -> BatchDownloadResult:
    """
    Скачивает видео из файла (по одному URL на строку)
    
    Args:
        file_path: Путь к файлу со ссылками
        output_dir: Папка для сохранения
        download_type: "video" или "audio"
        quality: Качество
        verbose: Выводить ли подробную информацию
        skip_comments: Пропускать строки, начинающиеся с #
    
    Returns:
        BatchDownloadResult
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Файл не найден: {file_path}")
    
    urls = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if skip_comments and line.startswith('#'):
                continue
            urls.append(line)
    
    if not urls:
        raise ValueError("Файл не содержит ссылок")
    
    return download_batch(
        urls=urls,
        output_dir=output_dir,
        download_type=download_type,
        quality=quality,
        verbose=verbose,
    )