"""etgdlp - простая библиотека для скачивания видео и аудио с YouTube"""

from .core import download, download_audio, download_video, download_playlist, check_ffmpeg
from .types import DownloadResult, VideoInfo, MediaType, DownloadStatus, BatchDownloadResult
from .info import get_video_info, get_available_formats, check_url
from .batch import download_batch, download_from_file
from .exceptions import *

__version__ = "0.1.0"
__author__ = "itzmeso"
__all__ = [
    "download",
    "download_audio",
    "download_video",
    "download_playlist",
    "download_batch",
    "download_from_file",
    "get_video_info",
    "get_available_formats",
    "check_url",
    "check_ffmpeg",
    "DownloadResult",
    "VideoInfo",
    "BatchDownloadResult",
    "MediaType",
    "DownloadStatus",
    "ETGDLPError",
    "DownloadError",
    "InvalidURLError",
    "FFmpegNotFoundError",
    "FormatNotAvailableError",
    "CookieError",
    "PlaylistError",
]