"""Кастомные исключения для etgdlp"""


class ETGDLPError(Exception):
    """Базовое исключение для всех ошибок библиотеки"""
    pass


class DownloadError(ETGDLPError):
    """Ошибка при скачивании"""
    pass


class InvalidURLError(ETGDLPError):
    """Неверный URL"""
    pass


class FFmpegNotFoundError(ETGDLPError):
    """FFmpeg не найден в системе"""
    pass


class FormatNotAvailableError(ETGDLPError):
    """Запрошенный формат недоступен"""
    pass


class CookieError(ETGDLPError):
    """Ошибка при работе с cookies"""
    pass


class PlaylistError(ETGDLPError):
    """Ошибка при обработке плейлиста"""
    pass