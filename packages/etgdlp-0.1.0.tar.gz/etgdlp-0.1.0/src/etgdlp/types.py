"""Типы данных и dataclasses"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


class DownloadStatus(Enum):
    """Статус загрузки"""
    PENDING = "pending"
    DOWNLOADING = "downloading"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class MediaType(Enum):
    """Тип медиа"""
    VIDEO = "video"
    AUDIO = "audio"
    PLAYLIST = "playlist"
    SUBTITLES = "subtitles"


@dataclass
class DownloadResult:
    """Результат загрузки"""
    success: bool
    path: Optional[Path] = None
    error: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    url: Optional[str] = None
    title: Optional[str] = None
    duration: Optional[int] = None
    file_size: Optional[int] = None
    media_type: Optional[MediaType] = None
    download_time: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Конвертирует в словарь"""
        result = {
            "success": self.success,
            "path": str(self.path) if self.path else None,
            "error": self.error,
            "warnings": self.warnings,
            "url": self.url,
            "title": self.title,
            "duration": self.duration,
            "file_size": self.file_size,
            "media_type": self.media_type.value if self.media_type else None,
            "download_time": self.download_time.isoformat() if self.download_time else None,
        }
        return result
    
    def __repr__(self) -> str:
        if self.success:
            return f"<DownloadResult: success=True, path={self.path}>"
        return f"<DownloadResult: success=False, error={self.error}>"


@dataclass
class VideoInfo:
    """Информация о видео"""
    id: str
    title: str
    duration: int
    uploader: str
    upload_date: Optional[str] = None
    view_count: Optional[int] = None
    like_count: Optional[int] = None
    description: Optional[str] = None
    thumbnail: Optional[str] = None
    formats: List[Dict[str, Any]] = field(default_factory=list)
    available_formats: List[str] = field(default_factory=list)
    subtitles: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Конвертирует в словарь"""
        return {
            "id": self.id,
            "title": self.title,
            "duration": self.duration,
            "uploader": self.uploader,
            "upload_date": self.upload_date,
            "view_count": self.view_count,
            "like_count": self.like_count,
            "description": self.description[:500] if self.description else None,
            "thumbnail": self.thumbnail,
            "available_formats": self.available_formats,
            "subtitles": self.subtitles,
        }


@dataclass
class BatchDownloadResult:
    """Результат пакетной загрузки"""
    total: int
    successful: int
    failed: int
    results: List[DownloadResult] = field(default_factory=list)
    
    @property
    def success_rate(self) -> float:
        """Процент успешных загрузок"""
        if self.total == 0:
            return 0.0
        return (self.successful / self.total) * 100
    
    def to_dict(self) -> Dict[str, Any]:
        """Конвертирует в словарь"""
        return {
            "total": self.total,
            "successful": self.successful,
            "failed": self.failed,
            "success_rate": self.success_rate,
            "results": [r.to_dict() for r in self.results],
        }