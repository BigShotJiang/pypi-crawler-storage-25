"""Основная логика скачивания"""

import yt_dlp
import os
import re
import subprocess
from pathlib import Path
from typing import Optional, Literal, Callable, Dict, Any
from datetime import datetime

from .types import DownloadResult, MediaType, DownloadStatus
from .exceptions import (
    DownloadError, 
    InvalidURLError, 
    FFmpegNotFoundError,
    FormatNotAvailableError
)
from .progress import ProgressHook, YTDLPLogger


def check_ffmpeg() -> bool:
    """Проверяет наличие FFmpeg в системе"""
    try:
        subprocess.run(['ffmpeg', '-version'], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def _sanitize_filename(name: str) -> str:
    """Очищает имя файла от недопустимых символов"""
    return re.sub(r'[<>:"/\\|?*]', '_', name)


def download(
    url: str,
    output_dir: Optional[Path] = None,
    download_type: Literal["video", "audio"] = "video",
    quality: str = "best",
    format: Optional[str] = None,
    verbose: bool = False,
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    cookies: Optional[Path] = None,
    extract_audio: bool = False,
    audio_format: str = "mp3",
    audio_quality: str = "192",
    playlist: bool = False,
    max_playlist_items: Optional[int] = None,
) -> DownloadResult:
    """
    Универсальная функция для скачивания видео или аудио
    
    Args:
        url: Ссылка на видео/плейлист
        output_dir: Папка для сохранения (по умолчанию ./etgdlp_downloads)
        download_type: "video" или "audio"
        quality: Качество ("best", "worst", "1080", "720", "480", "360")
        format: Конкретный формат (если указан, переопределяет quality)
        verbose: Выводить ли подробную информацию
        progress_callback: Функция для отслеживания прогресса
        cookies: Путь к файлу cookies
        extract_audio: Извлечь аудио (для видео)
        audio_format: Формат аудио (mp3, m4a, wav, flac)
        audio_quality: Качество аудио (192, 256, 320)
        playlist: Скачивать ли плейлист целиком
        max_playlist_items: Максимальное количество элементов в плейлисте
    
    Returns:
        DownloadResult с информацией о результате
    """
    # Настройка путей
    if output_dir is None:
        output_dir = Path.cwd() / "etgdlp_downloads"
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Проверка FFmpeg для аудио
    if download_type == "audio" or extract_audio:
        if not check_ffmpeg():
            raise FFmpegNotFoundError(
                "FFmpeg не найден. Установите FFmpeg для конвертации аудио.\n"
                "https://ffmpeg.org/download.html"
            )
    
    # Настройка прогресса
    progress_hook = ProgressHook(verbose=verbose)
    
    def progress_hook_wrapper(d: dict):
        progress_hook(d)
        if progress_callback:
            progress_callback(d)
    
    # Базовые настройки yt-dlp
    ydl_opts: Dict[str, Any] = {
        'outtmpl': str(output_dir / '%(title)s.%(ext)s'),
        'quiet': not verbose,
        'no_warnings': not verbose,
        'progress_hooks': [progress_hook_wrapper],
        'logger': YTDLPLogger(verbose=verbose),
        'ignoreerrors': True,
    }
    
    # Настройки для плейлистов
    if playlist:
        ydl_opts['extract_flat'] = False
        if max_playlist_items:
            ydl_opts['playlistend'] = max_playlist_items
    
    # Cookies
    if cookies and cookies.exists():
        ydl_opts['cookiefile'] = str(cookies)
    
    # Настройки для видео
    if download_type == "video" and not extract_audio:
        if format:
            ydl_opts['format'] = format
        else:
            if quality == "best":
                ydl_opts['format'] = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]'
            elif quality == "worst":
                ydl_opts['format'] = 'worstvideo+worstaudio/worst'
            else:
                # Например: 720p, 1080p
                ydl_opts['format'] = f'bestvideo[height<={quality}]+bestaudio/best'
    
    # Настройки для аудио
    elif download_type == "audio" or extract_audio:
        if format:
            ydl_opts['format'] = format
        else:
            ydl_opts['format'] = 'bestaudio/best'
        
        ydl_opts['postprocessors'] = [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': audio_format,
            'preferredquality': audio_quality,
        }]
        
        # Меняем шаблон имени для аудио
        ydl_opts['outtmpl'] = str(output_dir / '%(title)s.%(ext)s')
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # Получаем информацию перед загрузкой
            progress_hook.update_status("Получение информации...")
            info = ydl.extract_info(url, download=False)
            
            if not info:
                raise InvalidURLError(f"Не удалось получить информацию: {url}")
            
            title = info.get('title', 'unknown')
            duration = info.get('duration', 0)
            is_playlist = 'entries' in info
            
            progress_hook.update_status("Скачивание...")
            
            # Скачиваем
            ydl.download([url])
            
            # Ищем скачанный файл
            downloaded_file = None
            title_clean = _sanitize_filename(title)
            
            extensions = ['mp4', 'webm', 'mkv', audio_format, 'm4a', 'mp3', 'wav', 'flac']
            for ext in extensions:
                possible_path = output_dir / f"{title_clean}.{ext}"
                if possible_path.exists():
                    downloaded_file = possible_path
                    break
            
            # Если файл не найден с точным названием, ищем частичное совпадение
            if not downloaded_file:
                for file in output_dir.iterdir():
                    if file.is_file() and title_clean in file.name:
                        downloaded_file = file
                        break
            
            # Получаем размер файла
            file_size = None
            if downloaded_file and downloaded_file.exists():
                file_size = downloaded_file.stat().st_size
            
            return DownloadResult(
                success=True,
                path=downloaded_file or output_dir,
                url=url,
                title=title,
                duration=duration,
                file_size=file_size,
                media_type=MediaType.VIDEO if download_type == "video" else MediaType.AUDIO,
                download_time=datetime.now(),
                warnings=[f"Плейлист: {len(info.get('entries', []))} видео"] if is_playlist else []
            )
            
    except Exception as e:
        return DownloadResult(
            success=False,
            error=str(e),
            url=url,
            download_time=datetime.now()
        )


def download_audio(
    url: str,
    output_dir: Optional[Path] = None,
    quality: str = "192",
    audio_format: str = "mp3",
    verbose: bool = False,
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> DownloadResult:
    """
    Скачивает аудио с YouTube
    
    Args:
        url: Ссылка на видео
        output_dir: Папка для сохранения
        quality: Качество аудио (128, 192, 256, 320)
        audio_format: Формат аудио (mp3, m4a, wav, flac)
        verbose: Выводить ли подробную информацию
        progress_callback: Функция для отслеживания прогресса
    
    Returns:
        DownloadResult
    """
    return download(
        url=url,
        output_dir=output_dir,
        download_type="audio",
        quality=quality,
        verbose=verbose,
        progress_callback=progress_callback,
        audio_format=audio_format,
        audio_quality=quality,
    )


def download_video(
    url: str,
    output_dir: Optional[Path] = None,
    quality: str = "best",
    verbose: bool = False,
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> DownloadResult:
    """
    Скачивает видео с YouTube
    
    Args:
        url: Ссылка на видео
        output_dir: Папка для сохранения
        quality: Качество видео ("best", "1080", "720", "480", "360")
        verbose: Выводить ли подробную информацию
        progress_callback: Функция для отслеживания прогресса
    
    Returns:
        DownloadResult
    """
    return download(
        url=url,
        output_dir=output_dir,
        download_type="video",
        quality=quality,
        verbose=verbose,
        progress_callback=progress_callback,
    )


def download_playlist(
    url: str,
    output_dir: Optional[Path] = None,
    download_type: Literal["video", "audio"] = "video",
    max_items: Optional[int] = None,
    quality: str = "best",
    verbose: bool = False,
) -> DownloadResult:
    """
    Скачивает плейлист
    
    Args:
        url: Ссылка на плейлист
        output_dir: Папка для сохранения
        download_type: "video" или "audio"
        max_items: Максимальное количество видео в плейлисте
        quality: Качество
        verbose: Выводить ли подробную информацию
    
    Returns:
        DownloadResult
    """
    return download(
        url=url,
        output_dir=output_dir,
        download_type=download_type,
        quality=quality,
        verbose=verbose,
        playlist=True,
        max_playlist_items=max_items,
    )