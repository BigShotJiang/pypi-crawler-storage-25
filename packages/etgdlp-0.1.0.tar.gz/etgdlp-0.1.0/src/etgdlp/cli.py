"""CLI интерфейс для etgdlp"""

import argparse
import sys
from pathlib import Path
from typing import Optional

from .core import download, download_audio, download_video, download_playlist, check_ffmpeg
from .batch import download_batch, download_from_file
from .info import get_video_info, get_available_formats
from .exceptions import FFmpegNotFoundError, InvalidURLError


def main():
    """Главная точка входа CLI"""
    parser = argparse.ArgumentParser(
        description="etgdlp - скачивание видео и аудио с YouTube",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры:
  etgdlp https://youtube.com/watch?v=...              # Скачать видео в лучшем качестве
  etgdlp -a https://youtube.com/watch?v=...           # Скачать только аудио
  etgdlp -q 720 https://youtube.com/watch?v=...       # Скачать видео в 720p
  etgdlp -p https://youtube.com/playlist?list=...     # Скачать плейлист
  etgdlp -f urls.txt                                  # Скачать список ссылок из файла
  etgdlp -i https://youtube.com/watch?v=...           # Показать информацию о видео
  etgdlp --formats https://youtube.com/watch?v=...    # Показать доступные форматы
        """
    )
    
    parser.add_argument("url", nargs="?", help="URL видео или плейлиста")
    parser.add_argument("-o", "--output", help="Папка для сохранения (по умолчанию ./etgdlp_downloads)")
    parser.add_argument("-q", "--quality", default="best", help="Качество (best, 1080, 720, 480, 360)")
    parser.add_argument("-a", "--audio", action="store_true", help="Скачать только аудио")
    parser.add_argument("-f", "--file", help="Файл со списком URL (по одному на строку)")
    parser.add_argument("-p", "--playlist", action="store_true", help="Скачать плейлист целиком")
    parser.add_argument("--max-items", type=int, help="Максимальное количество элементов в плейлисте")
    parser.add_argument("--audio-format", default="mp3", help="Формат аудио (mp3, m4a, wav, flac)")
    parser.add_argument("--audio-quality", default="192", help="Качество аудио (128, 192, 256, 320)")
    parser.add_argument("-i", "--info", action="store_true", help="Показать информацию о видео")
    parser.add_argument("--formats", action="store_true", help="Показать доступные форматы")
    parser.add_argument("-v", "--verbose", action="store_true", help="Подробный вывод")
    parser.add_argument("--cookies", help="Путь к файлу cookies")
    parser.add_argument("--check-ffmpeg", action="store_true", help="Проверить наличие FFmpeg")
    
    args = parser.parse_args()
    
    # Проверка FFmpeg
    if args.check_ffmpeg:
        if check_ffmpeg():
            print("✅ FFmpeg найден в системе")
        else:
            print("❌ FFmpeg не найден. Установите FFmpeg для конвертации аудио")
            print("   https://ffmpeg.org/download.html")
        return
    
    # Проверка наличия URL
    if not args.url and not args.file:
        parser.print_help()
        sys.exit(1)
    
    # Информация о видео
    if args.info and args.url:
        info = get_video_info(args.url, args.verbose)
        if info:
            print("\n📹 Информация о видео:")
            print(f"  Название: {info.title}")
            print(f"  ID: {info.id}")
            print(f"  Автор: {info.uploader}")
            print(f"  Длительность: {info.duration // 60}:{info.duration % 60:02d}")
            print(f"  Просмотров: {info.view_count:,}" if info.view_count else "  Просмотров: N/A")
            print(f"  Лайков: {info.like_count:,}" if info.like_count else "  Лайков: N/A")
            if info.available_formats:
                print(f"  Доступные форматы: {', '.join(info.available_formats)}")
            if info.subtitles:
                print(f"  Субтитры: {', '.join(info.subtitles)}")
        else:
            print("❌ Не удалось получить информацию о видео")
        return
    
    # Доступные форматы
    if args.formats and args.url:
        try:
            formats = get_available_formats(args.url)
            print("\n🎬 Доступные форматы:")
            for fmt in sorted(formats, key=lambda x: int(x.replace('p', '')) if x != 'best' and x != 'worst' else 0, reverse=True):
                print(f"  • {fmt}")
        except InvalidURLError as e:
            print(f"❌ {e}")
        return
    
    # Настройка вывода
    output_dir = Path(args.output) if args.output else None
    
    # Обработка файла со ссылками
    if args.file:
        try:
            result = download_from_file(
                file_path=args.file,
                output_dir=output_dir,
                download_type="audio" if args.audio else "video",
                quality=args.quality,
                verbose=args.verbose,
            )
            print(f"\n📊 Результаты:")
            print(f"  Всего: {result.total}")
            print(f"  Успешно: {result.successful}")
            print(f"  Ошибок: {result.failed}")
            print(f"  Успешность: {result.success_rate:.1f}%")
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            sys.exit(1)
        return
    
    # Обработка плейлиста
    if args.playlist and args.url:
        try:
            result = download_playlist(
                url=args.url,
                output_dir=output_dir,
                download_type="audio" if args.audio else "video",
                max_items=args.max_items,
                quality=args.quality,
                verbose=args.verbose,
            )
            if result.success:
                print(f"\n✅ Скачано: {result.path}")
                if result.title:
                    print(f"   Название: {result.title}")
            else:
                print(f"\n❌ Ошибка: {result.error}")
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            sys.exit(1)
        return
    
    # Обычное скачивание
    if args.url:
        try:
            if args.audio:
                result = download_audio(
                    url=args.url,
                    output_dir=output_dir,
                    quality=args.audio_quality,
                    audio_format=args.audio_format,
                    verbose=args.verbose,
                )
            else:
                result = download_video(
                    url=args.url,
                    output_dir=output_dir,
                    quality=args.quality,
                    verbose=args.verbose,
                )
            
            if result.success:
                print(f"\n✅ Скачано успешно!")
                print(f"   Файл: {result.path}")
                if result.title:
                    print(f"   Название: {result.title}")
                if result.duration:
                    mins, secs = divmod(result.duration, 60)
                    print(f"   Длительность: {mins}:{secs:02d}")
                if result.file_size:
                    size_mb = result.file_size / (1024 * 1024)
                    print(f"   Размер: {size_mb:.2f} MB")
                if result.warnings:
                    for warning in result.warnings:
                        print(f"   ⚠️ {warning}")
            else:
                print(f"\n❌ Ошибка: {result.error}")
                sys.exit(1)
                
        except FFmpegNotFoundError as e:
            print(f"❌ {e}")
            sys.exit(1)
        except Exception as e:
            print(f"❌ Неожиданная ошибка: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
            sys.exit(1)


if __name__ == "__main__":
    main()