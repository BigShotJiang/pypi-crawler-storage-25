"""Получение информации о видео"""

import yt_dlp
from typing import Optional, List, Dict, Any
from .types import VideoInfo
from .exceptions import InvalidURLError, FormatNotAvailableError


def get_video_info(url: str, verbose: bool = False) -> Optional[VideoInfo]:
    """
    Получает подробную информацию о видео
    
    Args:
        url: Ссылка на видео
        verbose: Выводить ли отладочную информацию
    
    Returns:
        VideoInfo или None в случае ошибки
    """
    ydl_opts = {
        'quiet': not verbose,
        'no_warnings': not verbose,
        'extract_flat': False,
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            if not info:
                return None
            
            # Получаем доступные форматы
            available_formats = []
            formats = info.get('formats', [])
            for fmt in formats:
                if fmt.get('vcodec') != 'none' and fmt.get('acodec') != 'none':
                    if fmt.get('height'):
                        available_formats.append(f"{fmt['height']}p")
                    elif fmt.get('format_note'):
                        available_formats.append(fmt['format_note'])
            
            available_formats = list(set(available_formats))
            
            # Получаем субтитры
            subtitles = list(info.get('subtitles', {}).keys())
            
            return VideoInfo(
                id=info.get('id', ''),
                title=info.get('title', 'Unknown'),
                duration=info.get('duration', 0),
                uploader=info.get('uploader', 'Unknown'),
                upload_date=info.get('upload_date'),
                view_count=info.get('view_count'),
                like_count=info.get('like_count'),
                description=info.get('description'),
                thumbnail=info.get('thumbnail'),
                formats=formats,
                available_formats=available_formats,
                subtitles=subtitles,
            )
            
    except Exception as e:
        if verbose:
            print(f"Ошибка при получении информации: {e}")
        return None


def check_url(url: str) -> bool:
    """
    Проверяет, является ли URL валидным для скачивания
    
    Args:
        url: Ссылка для проверки
    
    Returns:
        True если URL валидный
    """
    try:
        with yt_dlp.YoutubeDL({'quiet': True}) as ydl:
            ydl.extract_info(url, download=False)
            return True
    except Exception:
        return False


def get_available_formats(url: str) -> List[str]:
    """
    Возвращает список доступных форматов для видео
    
    Args:
        url: Ссылка на видео
    
    Returns:
        Список доступных форматов
    
    Raises:
        InvalidURLError: Если URL невалидный
        FormatNotAvailableError: Если форматы не найдены
    """
    info = get_video_info(url)
    if not info:
        raise InvalidURLError(f"Не удалось получить информацию: {url}")
    
    if not info.available_formats:
        raise FormatNotAvailableError("Форматы не найдены")
    
    return info.available_formats