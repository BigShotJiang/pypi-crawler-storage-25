#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike FalconPy SDK initialization and authentication helpers.

SDK instances share an authenticated session via auth_object reuse,
reducing connection overhead during bulk operations.
"""

import logging
from typing import Optional

from falconpy import Alerts, Hosts, Intel, SpotlightVulnerabilities, UserManagement

from regscale.core.app.application import Application
from regscale.core.app.utils.app_utils import error_and_exit

logger = logging.getLogger("regscale")

# Constants for error messages
DEFAULT_ERROR_MESSAGE = "Unknown error occurred"
NO_USER_FOUND_MESSAGE = "No user information found"
NO_INCIDENTS_FOUND_MESSAGE = "No incidents found"
SDK_INIT_FAILED_MESSAGE = "Failed to initialize CrowdStrike SDK."

# Module-level cached auth object for SDK instance reuse
_cached_auth_object = None


def validate_falcon_response(response: dict, expected_status: int = 200) -> dict:
    """
    Validate a FalconPy API response following SDK best practices.

    :param dict response: The response dictionary from FalconPy SDK
    :param int expected_status: Expected HTTP status code, defaults to 200
    :raises SystemExit: If response status doesn't match expected or errors are present
    :return: The response body dictionary
    :rtype: dict
    """
    status_code = response.get("status_code")
    body = response.get("body", {})

    if status_code != expected_status:
        errors = body.get("errors", [])
        if errors:
            error_messages = [
                err.get("message", DEFAULT_ERROR_MESSAGE) if isinstance(err, dict) else str(err) for err in errors
            ]
            error_msg = "; ".join(error_messages)
        else:
            error_msg = DEFAULT_ERROR_MESSAGE

        logger.error(f"CrowdStrike API returned status {status_code}: {error_msg}")
        error_and_exit(error_msg)

    return body


def open_sdk() -> Optional[Alerts]:
    """
    Create an authenticated instance of the CrowdStrike Alerts SDK.

    Uses the Alerts service class (replacing the retired Incidents API).
    Caches the auth_object so subsequent calls to get_users() and get_intel()
    can reuse the authenticated session instead of re-authenticating.

    :return: Alerts object or None on failure
    :rtype: Optional[Alerts]
    """
    global _cached_auth_object
    creds = _get_falcon_credentials()
    try:
        alerts_object = Alerts(**creds)
        auth = alerts_object.auth_object
        if not auth.authenticated():
            logger.debug(
                "CrowdStrike auth failure detail - status: %s, reason: %s",
                auth.token_status,
                auth.token_fail_reason or "unknown",
            )
            logger.error("CrowdStrike authentication failed.")
            error_and_exit(
                "Unable to authenticate with CrowdStrike API. "
                "Please check your crowdstrikeClientId, crowdstrikeClientSecret, and crowdstrikeBaseUrl."
            )
            return None
        _cached_auth_object = auth
        logger.info("Successfully created Crowdstrike client.")
        return alerts_object
    except AttributeError as aex:
        logger.error(aex)
        if str(aex) == """'str' object has no attribute 'authenticated'""":
            error_and_exit("Unable to Authenticate with CrowdStrike API. Please check your credentials.")
        return None


def _get_falcon_credentials() -> dict:
    """
    Retrieve CrowdStrike credentials and SSL configuration from the application config.

    :return: Dictionary with client_id, client_secret, base_url, and ssl_verify
    :rtype: dict
    """
    app = Application()
    return {
        "client_id": app.config.get("crowdstrikeClientId"),
        "client_secret": app.config.get("crowdstrikeClientSecret"),
        "base_url": app.config.get("crowdstrikeBaseUrl"),
        "ssl_verify": app.config.get("verifySsl", True),
    }


def get_users(auth_object=None) -> UserManagement:
    """
    Create a UserManagement SDK instance for user lookups.

    Reuses a cached auth_object when available to avoid re-authentication.

    :param auth_object: Optional pre-authenticated auth object to reuse
    :return: UserManagement object
    :rtype: UserManagement
    """
    auth = auth_object or _cached_auth_object
    if auth is None:
        sdk = open_sdk()
        if sdk is None:
            error_and_exit("Unable to create CrowdStrike client for user management. Please check your credentials.")
        auth = _cached_auth_object
    return UserManagement(auth_object=auth)


def get_user_detail(uuid: str) -> str:
    """
    Retrieve assigned to user information for tabular display.

    :param str uuid: User ID to retrieve information for in CrowdStrike
    :return: User information
    :rtype: str
    """
    users = get_users()
    lookup_result = users.retrieve_users(ids=uuid)

    body = validate_falcon_response(lookup_result)
    resources = body.get("resources", [])

    if not resources:
        error_and_exit(NO_USER_FOUND_MESSAGE)

    user_info = resources[0]
    first = user_info.get("firstName", "Unknown")
    last = user_info.get("lastName", "Unknown")
    uid = user_info.get("uid", "Unknown")

    return f"{first} {last} ({uid})"


def get_spotlight(auth_object=None) -> SpotlightVulnerabilities:
    """
    Create a SpotlightVulnerabilities SDK instance for vulnerability queries.

    Reuses a cached auth_object when available to avoid re-authentication.

    :param auth_object: Optional pre-authenticated auth object to reuse
    :return: SpotlightVulnerabilities SDK object
    :rtype: SpotlightVulnerabilities
    """
    auth = auth_object or _cached_auth_object
    if auth is None:
        sdk = open_sdk()
        if sdk is None:
            error_and_exit("Unable to create CrowdStrike client for Spotlight. Please check your credentials.")
        auth = _cached_auth_object
    return SpotlightVulnerabilities(auth_object=auth)


def get_hosts(auth_object=None) -> Hosts:
    """
    Create a Hosts SDK instance for device/asset queries.

    Reuses a cached auth_object when available to avoid re-authentication.

    :param auth_object: Optional pre-authenticated auth object to reuse
    :return: Hosts SDK object
    :rtype: Hosts
    """
    auth = auth_object or _cached_auth_object
    if auth is None:
        sdk = open_sdk()
        if sdk is None:
            error_and_exit("Unable to create CrowdStrike client for Hosts. Please check your credentials.")
        auth = _cached_auth_object
    return Hosts(auth_object=auth)


def resolve_auth(auth_object=None):
    """
    Resolve a valid auth object, refreshing if needed.

    :param auth_object: Optional pre-authenticated auth object to reuse
    :return: Authenticated auth object
    :raises RuntimeError: If authentication fails
    """
    global _cached_auth_object

    auth = auth_object or _cached_auth_object
    if auth is not None:
        return auth

    sdk = open_sdk()
    if sdk is None or _cached_auth_object is None:
        raise RuntimeError(
            "CrowdStrike authentication failed. Check crowdstrikeClientId, crowdstrikeClientSecret, "
            "and crowdstrikeBaseUrl in your init.yaml configuration."
        )
    return _cached_auth_object


def get_intel(auth_object=None) -> Intel:
    """
    Create an Intel SDK instance for vulnerability queries.

    Reuses a cached auth_object when available to avoid re-authentication.

    :param auth_object: Optional pre-authenticated auth object to reuse
    :return: Intel SDK object
    :rtype: Intel
    """
    auth = auth_object or _cached_auth_object
    if auth is not None:
        return Intel(auth_object=auth)
    creds = _get_falcon_credentials()
    return Intel(**creds)
