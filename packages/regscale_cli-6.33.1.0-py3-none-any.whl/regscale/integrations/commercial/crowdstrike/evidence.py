#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike evidence collection for SOC2 audit compliance.

Generates evidence packages containing:
- Host inventory summary (count by OS, status, sensor version)
- Prevention policy assignment matrix
- Recent detection/alert examples
- HTML evidence reports attached as RegScale Evidence records
"""

import gzip
import json
import logging
from datetime import datetime, timedelta, timezone
from html import escape
from io import BytesIO
from typing import Any, Dict, List, Optional

from regscale.core.app.api import Api
from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.models.regscale_models.evidence import Evidence
from regscale.models.regscale_models.evidence_mapping import EvidenceMapping
from regscale.models.regscale_models.file import File

logger = logging.getLogger("regscale")


_MAX_ALERT_LIMIT = 100


def fetch_recent_alerts(days: int = 30, limit: int = 10, auth_object=None) -> List[Dict[str, Any]]:
    """
    Fetch recent alerts from CrowdStrike Alerts API.

    :param int days: Number of days to look back
    :param int limit: Maximum number of alerts to return (capped at 100)
    :param auth_object: Optional pre-authenticated auth object
    :return: List of alert dictionaries
    :rtype: List[Dict[str, Any]]
    """
    from falconpy import Alerts

    from regscale.integrations.commercial.crowdstrike.sdk import resolve_auth

    if limit > _MAX_ALERT_LIMIT:
        logger.warning("alert_limit capped at %d (requested: %d)", _MAX_ALERT_LIMIT, limit)
        limit = _MAX_ALERT_LIMIT

    auth = resolve_auth(auth_object)
    alerts_sdk = Alerts(auth_object=auth)

    cutoff = (datetime.now(tz=timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
    fql_filter = "created_timestamp:>'%s'" % cutoff

    logger.info("Fetching recent alerts from CrowdStrike (last %d days)...", days)

    # Query alert IDs
    query_response = alerts_sdk.query_alerts_v2(filter=fql_filter, limit=limit, sort="created_timestamp|desc")
    query_body = query_response.get("body", {})

    if query_response.get("status_code") != 200:
        errors = query_body.get("errors", [])
        error_msg = "; ".join(e.get("message", "Unknown") if isinstance(e, dict) else str(e) for e in errors)
        logger.error("CrowdStrike Alerts query error: %s", error_msg)
        return []

    alert_ids = query_body.get("resources", [])
    if not alert_ids:
        logger.info("No recent alerts found in the last %d days.", days)
        return []

    # Get alert details — v2 API uses composite_ids in body
    detail_response = alerts_sdk.get_alerts_v2(body={"composite_ids": alert_ids})
    detail_body = detail_response.get("body", {})

    if detail_response.get("status_code") != 200:
        errors = detail_body.get("errors", [])
        error_msg = "; ".join(e.get("message", "Unknown") if isinstance(e, dict) else str(e) for e in errors)
        logger.error("CrowdStrike Alerts detail error (status %s): %s", detail_response.get("status_code"), error_msg)
        return []

    alerts = detail_body.get("resources", [])
    logger.info("Fetched %d recent alerts.", len(alerts))
    return alerts


def generate_host_summary_html(hosts: List[Dict[str, Any]]) -> str:
    """
    Generate HTML summary of host inventory.

    :param List[Dict[str, Any]] hosts: List of host device dictionaries
    :return: HTML report string
    :rtype: str
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
    total = len(hosts)

    # Count by platform
    platform_counts: Dict[str, int] = {}
    status_counts: Dict[str, int] = {}
    version_counts: Dict[str, int] = {}

    for host in hosts:
        platform = host.get("platform_name", "Unknown")
        platform_counts[platform] = platform_counts.get(platform, 0) + 1

        status = host.get("status", "Unknown")
        status_counts[status] = status_counts.get(status, 0) + 1

        version = host.get("agent_version", "Unknown")
        version_counts[version] = version_counts.get(version, 0) + 1

    parts = [
        "<h1>CrowdStrike Host Inventory Summary</h1>",
        "<p><strong>Generated:</strong> %s</p>" % escape(now),
        "<p><strong>Total Protected Hosts:</strong> %d</p>" % total,
        "<hr>",
    ]

    # Platform breakdown
    parts.append("<h2>Hosts by Platform</h2>")
    parts.append("<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse;width:50%'>")
    parts.append("<tr style='background-color:#f0f0f0'><th>Platform</th><th>Count</th><th>Percentage</th></tr>")
    for platform in sorted(platform_counts, key=platform_counts.get, reverse=True):
        count = platform_counts[platform]
        pct = count / max(total, 1) * 100
        parts.append("<tr><td>%s</td><td>%d</td><td>%.1f%%</td></tr>" % (escape(platform), count, pct))
    parts.append("</table>")

    # Status breakdown
    parts.append("<h2>Hosts by Status</h2>")
    parts.append("<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse;width:50%'>")
    parts.append("<tr style='background-color:#f0f0f0'><th>Status</th><th>Count</th></tr>")
    for status in sorted(status_counts, key=status_counts.get, reverse=True):
        parts.append("<tr><td>%s</td><td>%d</td></tr>" % (escape(status), status_counts[status]))
    parts.append("</table>")

    # Sensor version breakdown (top 10)
    parts.append("<h2>Top Sensor Versions</h2>")
    parts.append("<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse;width:50%'>")
    parts.append("<tr style='background-color:#f0f0f0'><th>Agent Version</th><th>Count</th></tr>")
    sorted_versions = sorted(version_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    for version, count in sorted_versions:
        parts.append("<tr><td>%s</td><td>%d</td></tr>" % (escape(version), count))
    parts.append("</table>")

    return "".join(parts)


def generate_alerts_html(alerts: List[Dict[str, Any]]) -> str:
    """
    Generate HTML report of recent CrowdStrike alerts.

    :param List[Dict[str, Any]] alerts: List of alert dictionaries
    :return: HTML report string
    :rtype: str
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")

    parts = [
        "<h1>CrowdStrike Recent Alerts / Detections</h1>",
        "<p><strong>Generated:</strong> %s</p>" % escape(now),
        "<p><strong>Total Alerts Shown:</strong> %d</p>" % len(alerts),
        "<hr>",
    ]

    if not alerts:
        parts.append("<p><em>No recent alerts found.</em></p>")
        return "".join(parts)

    parts.append("<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse;width:100%'>")
    parts.append(
        "<tr style='background-color:#f0f0f0'>"
        "<th>Date</th><th>Severity</th><th>Tactic</th>"
        "<th>Technique</th><th>Hostname</th><th>Description</th></tr>"
    )

    for alert in alerts:
        timestamp = alert.get("created_timestamp", alert.get("timestamp", "Unknown"))
        severity_name = _extract_alert_severity(alert)
        tactic = alert.get("tactic", "")
        technique = alert.get("technique", "")
        hostname = _extract_alert_hostname(alert)
        description = escape(alert.get("description", alert.get("name", "")))

        # Truncate long descriptions (after escaping to prevent broken HTML entities)
        if len(description) > 200:
            description = description[:197] + "..."

        color = _severity_color(severity_name)
        parts.append(
            "<tr><td>%s</td><td style='color:%s'>%s</td><td>%s</td>"
            "<td>%s</td><td>%s</td><td>%s</td></tr>"
            % (
                escape(str(timestamp)),
                color,
                escape(severity_name),
                escape(tactic),
                escape(technique),
                escape(hostname),
                description,
            )
        )

    parts.append("</table>")
    return "".join(parts)


def _extract_alert_severity(alert: Dict[str, Any]) -> str:
    """Extract severity name from alert, handling nested structures."""
    severity = alert.get("severity_name", "")
    if severity:
        return severity
    severity_val = alert.get("severity", 0)
    severity_map = {1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
    return severity_map.get(severity_val, "Unknown") if isinstance(severity_val, int) else str(severity_val)


def _extract_alert_hostname(alert: Dict[str, Any]) -> str:
    """Extract hostname from alert, handling nested device structures."""
    hostname = alert.get("hostname", "")
    if hostname:
        return hostname
    device = alert.get("device", {})
    if isinstance(device, dict):
        return device.get("hostname", "Unknown")
    return "Unknown"


def _severity_color(severity: str) -> str:
    """Return HTML color for severity level."""
    colors = {
        "Critical": "#d32f2f",
        "High": "#e65100",
        "Medium": "#f57f17",
        "Low": "#2e7d32",
    }
    return colors.get(severity, "#333333")


def collect_and_upload_evidence(
    plan_id: int,
    evidence_title: str,
    html_content: str,
    raw_data: Optional[List[Dict[str, Any]]] = None,
    tags: str = "crowdstrike,automated",
) -> Optional[int]:
    """
    Create an Evidence record in RegScale and optionally upload raw data.

    :param int plan_id: SSP/Security Plan ID to link evidence to
    :param str evidence_title: Title for the evidence record
    :param str html_content: HTML description/content for the evidence
    :param Optional[List[Dict[str, Any]]] raw_data: Raw data to upload as JSONL.gz attachment
    :param str tags: Comma-separated tags for the file upload
    :return: Evidence record ID if created, None on failure
    :rtype: Optional[int]
    """
    evidence_id = None
    try:
        due_date = (datetime.now() + timedelta(days=365)).isoformat()

        evidence = Evidence(
            title=evidence_title,
            description=html_content,
            status="Collected",
            updateFrequency=365,
            dueDate=due_date,
        )

        created_evidence = evidence.create()
        if not created_evidence or not created_evidence.id:
            logger.error("Failed to create evidence record: %s", evidence_title)
            return None

        evidence_id = created_evidence.id
        logger.info("Created evidence record %d: %s", evidence_id, evidence_title)

        # Link evidence to SSP (required — fail if this doesn't succeed)
        _link_evidence_to_ssp(evidence_id, plan_id)

        # Auto-link evidence to matching control implementations (best-effort)
        _link_evidence_to_controls(evidence_id, plan_id)

        # Upload raw data as compressed JSONL if provided
        if raw_data:
            _upload_raw_evidence_data(evidence_id, evidence_title, raw_data, tags)

        return evidence_id

    except Exception as e:
        logger.error("Error creating evidence record '%s': %s", evidence_title, e, exc_info=True)
        if evidence_id:
            logger.error(
                "Evidence %d created but linking failed. Manual cleanup may be required.",
                evidence_id,
            )
        return None


def _link_evidence_to_ssp(evidence_id: int, plan_id: int) -> None:
    """
    Link an evidence record to a security plan.

    :param int evidence_id: Evidence record ID
    :param int plan_id: Security plan ID
    """
    try:
        mapping = EvidenceMapping(
            evidenceID=evidence_id,
            mappedID=plan_id,
            mappingType="securityplans",
        )
        mapping.create()
        logger.info("Linked evidence %d to SSP %d", evidence_id, plan_id)
    except Exception as ex:
        logger.error("Failed to link evidence %d to SSP %d: %s", evidence_id, plan_id, ex)
        raise


def _link_evidence_to_controls(evidence_id: int, plan_id: int) -> int:
    """
    Auto-link evidence to control implementations based on CrowdStrike's compliance mapping.

    Loads CrowdStrike's NIST 800-53 control mapping, detects the SSP's framework,
    translates control IDs via CrossFrameworkMapper if needed (e.g., NIST -> SOC2),
    and creates EvidenceMapping records for each matching control implementation.

    :param int evidence_id: Evidence record ID
    :param int plan_id: Security plan ID
    :return: Number of controls linked
    :rtype: int
    """
    try:
        crowdstrike_control_ids = _get_crowdstrike_supported_controls()
        if not crowdstrike_control_ids:
            logger.warning("No CrowdStrike compliance mapping data found for control linking.")
            return 0

        target_control_ids = _translate_controls_for_ssp(crowdstrike_control_ids, plan_id)
        if not target_control_ids:
            logger.info("No translatable control IDs for this SSP's framework.")
            return 0

        return _create_control_evidence_mappings(evidence_id, plan_id, target_control_ids)

    except Exception as e:
        logger.warning("Error auto-linking evidence %d to controls: %s", evidence_id, e)
        return 0


def _get_crowdstrike_supported_controls() -> List[str]:
    """
    Load the list of NIST control IDs that CrowdStrike supports (Full or Partial).

    :return: List of NIST control IDs
    :rtype: List[str]
    """
    try:
        from regscale.integrations.commercial.crowdstrike.compliance import _load_compliance_data

        data = _load_compliance_data("nist_800_53_r5_controls")
        return [k for k, v in data.items() if v.get("support") in ("Full", "Partial")]
    except Exception as e:
        logger.debug("Could not load CrowdStrike compliance mapping: %s", e)
        return []


def _translate_controls_for_ssp(nist_control_ids: List[str], plan_id: int) -> List[str]:
    """
    Translate NIST control IDs to the SSP's framework if needed.

    If the SSP uses NIST controls, returns the original IDs.
    If the SSP uses SOC2, CMMC, CSF, etc., attempts cross-framework translation
    via CrossFrameworkMapper (available after REG-21004 merges).

    :param List[str] nist_control_ids: NIST control IDs from CrowdStrike mapping
    :param int plan_id: Security plan ID to detect framework from
    :return: Control IDs in the SSP's framework
    :rtype: List[str]
    """
    from regscale.integrations.compliance_integration import detect_framework_from_control_ids
    from regscale.models.regscale_models import ControlImplementation

    implementations = ControlImplementation.get_existing_control_implementations(parent_id=plan_id)
    if not implementations:
        logger.warning("No control implementations found on SSP %d.", plan_id)
        return nist_control_ids

    control_names = list(implementations.keys())
    detected_framework = detect_framework_from_control_ids(control_names)
    logger.info("SSP %d framework detected as '%s' for evidence control linking.", plan_id, detected_framework)

    # NIST SSPs can use the control IDs directly
    if detected_framework in ("NIST800-53R5", "NIST"):
        return nist_control_ids

    # For other frameworks, try cross-framework translation
    return _cross_framework_translate(nist_control_ids, detected_framework)


def _cross_framework_translate(nist_control_ids: List[str], target_framework: str) -> List[str]:
    """
    Translate NIST control IDs to a target framework using CrossFrameworkMapper.

    Falls back to returning NIST IDs if the mapper is not available
    (e.g., before REG-21004 merges to main).

    :param List[str] nist_control_ids: NIST control IDs to translate
    :param str target_framework: Target framework name (e.g., "SOC2", "CSF", "CMMC")
    :return: Translated control IDs in the target framework
    :rtype: List[str]
    """
    try:
        from regscale.integrations.cross_framework_mapper import CrossFrameworkMapper

        mapper = CrossFrameworkMapper()
        mapped = mapper.map_controls("NIST", target_framework, nist_control_ids)

        if not mapped:
            logger.info(
                "No crosswalk available for NIST -> %s. Falling back to NIST control IDs.",
                target_framework,
            )
            return nist_control_ids

        # Flatten: collect all unique target control IDs
        translated = set()
        for target_ids in mapped.values():
            translated.update(target_ids)

        logger.info(
            "Translated %d NIST controls to %d %s controls for evidence linking.",
            len(nist_control_ids),
            len(translated),
            target_framework,
        )
        return sorted(translated)

    except ImportError:
        logger.error(
            "CrossFrameworkMapper not available. Cannot translate NIST controls to %s framework. "
            "Cross-framework support (SOC2, CMMC, etc.) requires the cross-framework mapping module.",
            target_framework,
        )
        return []


def _create_control_evidence_mappings(evidence_id: int, plan_id: int, control_ids: List[str]) -> int:
    """
    Create EvidenceMapping records linking evidence to matching control implementations.

    :param int evidence_id: Evidence record ID
    :param int plan_id: Security plan ID
    :param List[str] control_ids: Control IDs to match against the SSP's implementations
    :return: Number of controls successfully linked
    :rtype: int
    """
    from regscale.integrations.control_matcher import ControlMatcher

    matcher = ControlMatcher()
    matches = matcher.match_controls_to_implementations(
        control_ids=control_ids,
        parent_id=plan_id,
        parent_module="securityplans",
    )

    linked = 0
    for control_id, impl in matches.items():
        if not impl:
            continue
        try:
            mapping = EvidenceMapping(
                evidenceID=evidence_id,
                mappedID=impl.id,
                mappingType="controls",
            )
            mapping.create()
            linked += 1
        except Exception as e:
            logger.debug("Failed to link evidence %d to control %s (impl %d): %s", evidence_id, control_id, impl.id, e)

    logger.info("Linked evidence %d to %d control implementations on SSP %d.", evidence_id, linked, plan_id)
    return linked


def _upload_raw_evidence_data(
    evidence_id: int,
    title: str,
    raw_data: List[Dict[str, Any]],
    tags: str,
) -> None:
    """
    Upload raw data as compressed JSONL file to evidence record.

    :param int evidence_id: Evidence record ID
    :param str title: Base title for file naming
    :param List[Dict[str, Any]] raw_data: Data to serialize
    :param str tags: Tags for the file upload
    """
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = title.lower().replace(" ", "_").replace("-", "_")[:40]
        file_name = "crowdstrike_%s_%s.jsonl.gz" % (safe_title, timestamp)

        jsonl_content = "\n".join(json.dumps(item, default=str) for item in raw_data)

        compressed_buffer = BytesIO()
        with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz_file:
            gz_file.write(jsonl_content)

        compressed_data = compressed_buffer.getvalue()

        api = Api()
        success = File.upload_file_to_regscale(
            file_name=file_name,
            parent_id=evidence_id,
            parent_module="evidence",
            api=api,
            file_data=compressed_data,
            tags=tags,
        )

        if success:
            logger.info("Uploaded evidence file to Evidence %d: %s", evidence_id, file_name)
        else:
            logger.warning("Failed to upload evidence file to Evidence %d", evidence_id)

    except Exception as e:
        logger.error("Error uploading evidence data: %s", e, exc_info=True)


def sync_policies_evidence(plan_id: int) -> None:
    """
    Fetch CrowdStrike prevention policies and create evidence in RegScale.

    :param int plan_id: SSP record ID
    """
    from regscale.integrations.commercial.crowdstrike.policies import (
        fetch_host_groups,
        fetch_prevention_policies,
        generate_policy_html_report,
    )

    logger.info("Starting CrowdStrike prevention policy evidence collection...")

    policies = fetch_prevention_policies()
    if not policies:
        logger.warning("No prevention policies found in CrowdStrike.")
        return

    host_groups = fetch_host_groups()
    html_report = generate_policy_html_report(policies, host_groups)

    scan_date = get_current_datetime(dt_format="%Y-%m-%d")
    title = "CrowdStrike Prevention Policies - %s" % scan_date

    evidence_id = collect_and_upload_evidence(
        plan_id=plan_id,
        evidence_title=title,
        html_content=html_report,
        raw_data=policies,
        tags="crowdstrike,prevention-policies,soc2,automated",
    )

    if evidence_id:
        logger.info(
            "Successfully created prevention policy evidence (ID: %d) for SSP %d with %d policies.",
            evidence_id,
            plan_id,
            len(policies),
        )
    else:
        logger.error("Failed to create prevention policy evidence for SSP %d.", plan_id)


def collect_evidence_package(plan_id: int, alert_days: int = 30, alert_limit: int = 10) -> None:
    """
    Collect a comprehensive CrowdStrike evidence package for SOC2 audits.

    Creates three evidence records:
    1. Host inventory summary
    2. Prevention policy configurations
    3. Recent alerts/detections

    :param int plan_id: SSP record ID
    :param int alert_days: Number of days to look back for alerts
    :param int alert_limit: Maximum alerts to include
    """
    from regscale.integrations.commercial.crowdstrike.policies import (
        fetch_host_groups,
        fetch_prevention_policies,
        generate_policy_html_report,
    )
    from regscale.integrations.commercial.crowdstrike.sdk import get_hosts

    logger.info("Starting CrowdStrike evidence collection for SSP %d...", plan_id)
    scan_date = get_current_datetime(dt_format="%Y-%m-%d")

    # 1. Host inventory
    logger.info("Collecting host inventory evidence...")
    hosts_sdk = get_hosts()
    all_hosts = _fetch_all_hosts_raw(hosts_sdk)

    if all_hosts:
        host_html = generate_host_summary_html(all_hosts)
        collect_and_upload_evidence(
            plan_id=plan_id,
            evidence_title="CrowdStrike Host Inventory - %s" % scan_date,
            html_content=host_html,
            raw_data=all_hosts,
            tags="crowdstrike,host-inventory,soc2,automated",
        )
        logger.info("Host inventory evidence created (%d hosts).", len(all_hosts))
    else:
        logger.warning("No hosts found for inventory evidence.")

    # 2. Prevention policies
    logger.info("Collecting prevention policy evidence...")
    policies = fetch_prevention_policies()
    if policies:
        host_groups = fetch_host_groups()
        policy_html = generate_policy_html_report(policies, host_groups)
        collect_and_upload_evidence(
            plan_id=plan_id,
            evidence_title="CrowdStrike Prevention Policies - %s" % scan_date,
            html_content=policy_html,
            raw_data=policies,
            tags="crowdstrike,prevention-policies,soc2,automated",
        )
        logger.info("Prevention policy evidence created (%d policies).", len(policies))

    # 3. Recent alerts
    logger.info("Collecting recent alert evidence...")
    alerts = fetch_recent_alerts(days=alert_days, limit=alert_limit)
    alert_html = generate_alerts_html(alerts)
    collect_and_upload_evidence(
        plan_id=plan_id,
        evidence_title="CrowdStrike Recent Alerts - %s" % scan_date,
        html_content=alert_html,
        raw_data=alerts if alerts else None,
        tags="crowdstrike,alerts,detections,soc2,automated",
    )
    logger.info("Alert evidence created (%d alerts).", len(alerts))

    logger.info("CrowdStrike evidence collection complete for SSP %d.", plan_id)


def _fetch_all_hosts_raw(hosts_sdk) -> List[Dict[str, Any]]:
    """
    Fetch all raw host data from CrowdStrike Hosts API.

    :param hosts_sdk: Hosts SDK instance
    :return: List of raw host dictionaries
    :rtype: List[Dict[str, Any]]
    """
    all_hosts = []
    offset = None
    batch_size = 100
    batch_count = 0

    while True:
        params = {"limit": batch_size}
        if offset:
            params["offset"] = offset

        response = hosts_sdk.query_devices_by_filter_scroll(**params)
        body = response.get("body", {})

        if response.get("status_code") != 200:
            logger.error("Failed to fetch hosts for evidence (status %s)", response.get("status_code"))
            break

        device_ids = body.get("resources", [])
        if not device_ids:
            break

        detail_response = hosts_sdk.get_device_details_v2(ids=device_ids)
        detail_body = detail_response.get("body", {})

        if detail_response.get("status_code") != 200:
            logger.error("Failed to fetch host details (status %s)", detail_response.get("status_code"))
            break

        all_hosts.extend(detail_body.get("resources", []))

        meta = body.get("meta", {})
        pagination = meta.get("pagination", {})
        offset = pagination.get("offset")
        total = pagination.get("total", 0)

        batch_count += 1
        if batch_count % 10 == 0:
            logger.info("Fetched %d of %d hosts so far...", len(all_hosts), total)

        if not offset or len(all_hosts) >= total:
            break

    logger.info("Completed fetching %d hosts for evidence collection.", len(all_hosts))
    return all_hosts
