#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike CLI commands for the RegScale CLI."""

import logging

import click

from regscale.models import regscale_id, regscale_module
from regscale.models.app_models.orchestration_options import orchestration_options

logger = logging.getLogger("regscale")


@click.group()
def crowdstrike():
    """[BETA] CrowdStrike Integration to load threat intelligence to RegScale."""


@crowdstrike.command(name="query_incidents")  # type: ignore[misc]
@regscale_id(help="RegScale will create and update issues as children of this record.")
@regscale_module()
@click.option(
    "--filter",
    type=click.STRING,
    default=None,
    hide_input=False,
    required=False,
    help="Falcon Query Language(FQL) string.",
)
def query_incidents(regscale_id: int, regscale_module: str, filter: str, limit=500) -> None:
    """Query Incidents from CrowdStrike."""
    from regscale.integrations.commercial.crowdstrike.incidents import query_crowdstrike_incidents

    query_crowdstrike_incidents(regscale_id, regscale_module, filter_query=filter, limit=limit)


@crowdstrike.command(name="sync_incidents")  # type: ignore[misc]
@regscale_id(help="RegScale will create and update incidents as children of this record.")
@regscale_module()
@orchestration_options()
def sync_incidents(
    regscale_id: int, regscale_module: str, dry_run: bool = False, offset: int = None, limit: int = None
):
    """Sync Incidents and Assets from CrowdStrike to RegScale."""
    from regscale.integrations.commercial.crowdstrike.incidents import sync_incidents_to_regscale

    sync_incidents_to_regscale(regscale_id, regscale_module, dry_run=dry_run, offset=offset, limit=limit)


@crowdstrike.command(name="sync_vulnerabilities")  # type: ignore[misc]
@regscale_id(help="RegScale will create and update vulnerabilities as children of this record.")
@orchestration_options()
def sync_vulnerabilities(regscale_id: int, dry_run: bool = False, offset: int = None, limit: int = None) -> None:
    """Sync vulnerabilities from CrowdStrike Spotlight to RegScale."""
    from regscale.integrations.commercial.crowdstrike.scanner import CrowdStrikeScanner

    logger.info("Starting CrowdStrike vulnerability synchronization...")
    CrowdStrikeScanner.sync_findings(plan_id=regscale_id, dry_run=dry_run, offset=offset, limit=limit)
    logger.info("CrowdStrike vulnerability synchronization complete.")


@crowdstrike.command(name="sync_assets")  # type: ignore[misc]
@regscale_id(help="RegScale will create and update assets as children of this record.")
@orchestration_options()
def sync_assets(regscale_id: int, dry_run: bool = False, offset: int = None, limit: int = None) -> None:
    """Sync hosts/devices from CrowdStrike to RegScale as assets."""
    from regscale.integrations.commercial.crowdstrike.scanner import CrowdStrikeScanner

    logger.info("Starting CrowdStrike asset synchronization...")
    CrowdStrikeScanner.sync_assets(plan_id=regscale_id, dry_run=dry_run, offset=offset, limit=limit)
    logger.info("CrowdStrike asset synchronization complete.")


@crowdstrike.command(name="sync_compliance")  # type: ignore[misc]
@regscale_id(help="The ID of the SSP record in RegScale.")
@click.option("--ssp_id", "-s", type=click.INT, default=None, hidden=True, help="[Deprecated] Use --id instead.")
@click.option(
    "--framework",
    type=click.STRING,
    default=None,
    help="Compliance framework override (e.g. NIST, CSF, SOC2, CMMC, ISO, CIS, OWASP). Auto-detected if omitted.",
)
def run_compliance_sync(
    regscale_id: int,
    ssp_id: int = None,
    framework: str = None,
) -> None:
    """Run a compliance sync from CrowdStrike to RegScale.

    Auto-detects the compliance framework from the control implementations on the SSP
    and maps CrowdStrike's compliance data against them, updating their status using
    the SSP's compliance settings. Supports NIST, CSF, SOC2, CMMC, ISO, CIS, and OWASP.

    For frameworks without direct CrowdStrike mapping data, the NIST mapping is
    automatically translated using known public crosswalks.

    Ensure a security profile has been applied to the security plan before running.
    """
    from regscale.integrations.commercial.crowdstrike.compliance import CrowdStrikeComplianceIntegration

    plan_id = regscale_id
    if ssp_id is not None:
        logger.warning(
            "DEPRECATION: --ssp_id/-s is deprecated and will be removed in a future release. Use --id/-i instead."
        )
        plan_id = ssp_id
    integration = CrowdStrikeComplianceIntegration(plan_id=plan_id, framework=framework)
    integration.sync_compliance()


@crowdstrike.command(name="sync_policies")  # type: ignore[misc]
@regscale_id(help="The ID of the SSP record in RegScale.")
@click.option("--ssp_id", "-s", type=click.INT, default=None, hidden=True, help="[Deprecated] Use --id instead.")
def sync_policies(regscale_id: int, ssp_id: int = None) -> None:
    """Sync prevention policy configurations from CrowdStrike as evidence.

    Fetches all prevention policies (server, workstation, general) from CrowdStrike,
    generates an auditor-friendly HTML report, and creates an Evidence record in
    RegScale linked to the specified SSP.
    """
    from regscale.integrations.commercial.crowdstrike.evidence import sync_policies_evidence

    plan_id = regscale_id
    if ssp_id is not None:
        logger.warning(
            "DEPRECATION: --ssp_id/-s is deprecated and will be removed in a future release. Use --id/-i instead."
        )
        plan_id = ssp_id
    sync_policies_evidence(plan_id=plan_id)


@crowdstrike.command(name="collect_evidence")  # type: ignore[misc]
@regscale_id(help="The ID of the SSP record in RegScale.")
@click.option("--ssp_id", "-s", type=click.INT, default=None, hidden=True, help="[Deprecated] Use --id instead.")
@click.option("--alert_days", "-d", type=click.INT, default=30, help="Number of days to look back for alerts.")
@click.option("--alert_limit", "-l", type=click.INT, default=10, help="Maximum number of alerts to include.")
def collect_evidence(regscale_id: int, ssp_id: int = None, alert_days: int = 30, alert_limit: int = 10) -> None:
    """Collect a comprehensive CrowdStrike evidence package for SOC2 audits.

    Generates three evidence records attached to the SSP:
    1. Host inventory summary (count by OS, status, sensor version)
    2. Prevention policy configurations with assigned host groups
    3. Recent alerts/detections with timestamps

    This is designed for SOC2 CC.6.8.1 (antivirus configurations) and similar
    audit evidence requests.
    """
    from regscale.integrations.commercial.crowdstrike.evidence import collect_evidence_package

    plan_id = regscale_id
    if ssp_id is not None:
        logger.warning(
            "DEPRECATION: --ssp_id/-s is deprecated and will be removed in a future release. Use --id/-i instead."
        )
        plan_id = ssp_id
    collect_evidence_package(plan_id=plan_id, alert_days=alert_days, alert_limit=alert_limit)
