#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike incident query, sync, and RegScale incident creation logic."""

import json
import logging
from typing import Dict, Optional
from urllib.parse import urljoin

import click
from falconpy import Alerts

from regscale.core.app.api import Api
from regscale.core.app.application import Application
from regscale.core.app.utils.app_utils import (
    error_and_exit,
    format_data_to_html,
    get_current_datetime,
    tqdm,
)
from regscale.core.app.utils.regscale_utils import verify_provided_module
from regscale.integrations.commercial.crowdstrike.sdk import (
    NO_INCIDENTS_FOUND_MESSAGE,
    SDK_INIT_FAILED_MESSAGE,
    open_sdk,
    validate_falcon_response,
)
from regscale.models import regscale_models
from regscale.models.regscale_models.asset import Asset
from regscale.models.regscale_models.incident import Incident

logger = logging.getLogger("regscale")


def determine_incident_level(severity: int) -> str:
    """
    Determine the incident level based on the alert severity score (0-100).

    CrowdStrike Alerts API severity bands:
      80-100 = Critical, 60-79 = High, 40-59 = Medium, 20-39 = Low, 0-19 = Informational

    :param int severity: The severity score (0-100)
    :return: The incident level as a string
    :rtype: str
    """
    if severity >= 80:
        return "S1 - High Severity"
    elif severity >= 60:
        return "S2 - Moderate Severity"
    elif severity >= 40:
        return "S3 - Low Severity"
    elif severity >= 20:
        return "S4 - Non-Incident"
    else:
        return "S5 - Uncategorized"


def map_status_to_phase(status: str) -> str:
    """
    Map a CrowdStrike alert status to a RegScale phase.

    :param str status: The status string from CrowdStrike Alerts API
        (e.g., "new", "in_progress", "closed", "reopened").
    :return: The corresponding phase in RegScale as a string.
    :rtype: str
    """
    crowdstrike_to_regscale_mapping = {
        "new": "Detection",
        "in_progress": "Analysis",
        "true_positive": "Containment",
        "false_positive": "Closed",
        "closed": "Closed",
        "reopened": "Detection",
    }
    return crowdstrike_to_regscale_mapping.get(str(status).lower(), "Analysis")


def create_properties_for_incident(device_data: dict, regscale_id: int) -> None:
    """
    Create properties in RegScale based on the given device data dictionary.

    :param dict device_data: The device data as a dictionary.
    :param int regscale_id: The parent ID of the incidents.
    :rtype: None
    """
    properties = []
    api = Api()
    domain = api.config.get("domain", "")
    url = urljoin(domain, "/api/properties/batchCreate")
    for key, value in device_data.items():
        if not isinstance(value, list):
            prop = {
                "isPublic": "true",
                "key": key,
                "value": value,
                "parentId": regscale_id,
                "parentModule": "incidents",
            }
            properties.append(prop)
    response = api.post(url=url, json=properties)
    if response and not response.ok:
        logger.error("Failed to create property.")


def get_existing_regscale_incidents(parent_id: int, parent_module: str) -> list[dict]:
    """
    Get existing RegScale incidents for the given parent ID and parent module.

    :param int parent_id: The parent ID of the incidents.
    :param str parent_module: The parent module of the incidents.
    :return: The existing incidents as a list of dictionaries.
    :rtype: list[dict]
    """
    existing_incidents: list[Incident] = Incident.get_all_by_parent(parent_id, parent_module)
    return [incident.dict() for incident in existing_incidents]


def incidents_exist(title: str, existing_incidents: list[dict]) -> bool:
    """
    Determine if an incident already exists in RegScale.

    :param str title: The title of the incident.
    :param list[dict] existing_incidents: The existing incidents as a list of dictionaries.
    :return: If the incident already exists in RegScale
    :rtype: bool
    """
    if existing_incidents:
        for existing_incident in existing_incidents:
            if existing_incident["title"] == title:
                logger.info("Incident '%s' already exists in RegScale.", existing_incident["title"])
                return True
    return False


def create_regscale_incidents(alerts: list[dict], regscale_id: int, regscale_module: str) -> None:
    """
    Create Incidents in RegScale based on given CrowdStrike alerts.

    :param list[dict] alerts: List of CrowdStrike alert dictionaries
    :param int regscale_id: RegScale parent ID
    :param str regscale_module: RegScale parent module
    :rtype: None
    """
    app = Application()
    existing_incidents = get_existing_regscale_incidents(regscale_id, regscale_module)
    logger.info("Found %d existing incidents.", len(existing_incidents))
    user_id = app.config.get("userId")

    for alert in tqdm(
        alerts,
        desc="Comparing Crowdstrike and RegScale incident(s)...",
    ):
        title = "CrowdStrike alertId: %s" % alert.get("composite_id", "")

        if not incidents_exist(title, existing_incidents):
            regscale_incident = create_regscale_incident(alert, regscale_id, regscale_module, user_id)
            post_incident_and_associate_properties(regscale_incident, alert, user_id)


def create_regscale_incident(
    alert: dict,
    regscale_id: int,
    regscale_module: str,
    user_id: Optional[str] = None,
) -> Incident:
    """
    Create a RegScale incident object from a CrowdStrike alert.

    :param dict alert: CrowdStrike alert dictionary from Alerts API v2
    :param int regscale_id: RegScale parent ID
    :param str regscale_module: RegScale parent module
    :param Optional[str] user_id: User ID of the user performing the operation, defaults to None
    :return: RegScale incident object
    :rtype: Incident
    """
    severity = determine_incident_level(alert.get("severity", 0))
    technique = alert.get("technique", "")
    source_cause = technique if technique else ""
    alert_status = alert.get("status", "new")
    created_timestamp = alert.get("created_timestamp", "")
    phase = map_status_to_phase(alert_status)
    now = get_current_datetime()

    # Alert ID: try composite_id first, fall back to id
    alert_id = alert.get("composite_id") or alert.get("id", "unknown")

    # Log first alert structure for debugging (only keys, not values)
    logger.debug("Alert keys: %s", list(alert.keys()))

    return Incident(
        title="CrowdStrike alertId: %s" % alert_id,
        severity=severity,
        sourceCause=source_cause,
        category="CAT 6 - Investigation",
        phase=phase,
        description=format_data_to_html(alert),
        detectionMethod="Intrusion Detection System",
        incidentPOCId=user_id or "",
        dateDetected=created_timestamp or now,
        parentId=regscale_id if regscale_id is not None else None,
        parentModule=regscale_module if regscale_module is not None else None,
        lastUpdatedById=user_id or "",
        dateCreated=created_timestamp or now,
        dateLastUpdated=now,
        dateResolved=(alert.get("updated_timestamp") or now) if phase == "Closed" else None,
        createdById=user_id or "",
    )


def post_incident_and_associate_properties(
    regscale_incident: Incident, incident: dict, user_id: Optional[str] = None
) -> None:
    """
    Post the incident to RegScale and associate related properties.

    :param Incident regscale_incident: RegScale incident object
    :param dict incident: Falcon incident dictionary
    :param Optional[str] user_id: ID of the user performing the operation, defaults to None
    :rtype: None
    """
    response = Incident.post_incident(regscale_incident)
    if response.ok:
        incident_id = response.json()["id"]
        create_and_associate_incident_properties(incident, incident_id, user_id)
        logger.info("Created Incident: %s with ID: %s", regscale_incident.title, incident_id)
    else:
        logger.error(
            "Failed to create Incident: %s in RegScale. Status: %s, Response: %s",
            regscale_incident.title,
            response.status_code,
            response.text[:500],
        )
        response.raise_for_status()


def create_and_associate_incident_properties(alert: dict, incident_id: int, user_id: Optional[str] = None) -> None:
    """
    Create and associate properties for a RegScale incident from a CrowdStrike alert.

    Alerts have a single device object (not a list) and single tactic/technique strings.

    :param dict alert: CrowdStrike alert dictionary
    :param int incident_id: ID of the RegScale incident
    :param Optional[str] user_id: ID of the user performing the operation, defaults to None
    :rtype: None
    """
    # Alerts have a single device object instead of a hosts array
    device = alert.get("device")
    if device and isinstance(device, dict):
        create_asset(
            data=device,
            parent_id=incident_id,
            parent_module="incidents",
            user_id=user_id or "",
        )

    tactic = alert.get("tactic", "")
    if tactic:
        create_properties_for_incident({"tactic": tactic}, incident_id)

    technique = alert.get("technique", "")
    if technique:
        create_properties_for_incident({"technique": technique}, incident_id)

    objective = alert.get("objective", "")
    if objective:
        create_properties_for_incident({"objective": objective}, incident_id)


def create_asset(data: dict, parent_id: int, parent_module: str, user_id: str) -> Dict:
    """
    Create an asset in RegScale.

    :param dict data: The asset data as a dictionary
    :param int parent_id: The parent ID in RegScale
    :param str parent_module: The parent module in RegScale
    :param str user_id: The user ID in RegScale
    :return: Asset object as a dictionary
    :rtype: Dict
    """
    device_id = data.get("device_id", "")
    asset = Asset(
        parentId=parent_id,
        parentModule=parent_module,
        name=f"{data.get('hostname', device_id)} - {data.get('system_product_name', 'Asset')}",
        description=data.get("product_type_desc", None),
        ipAddress=data.get("external_ip", None),
        macAddress=data.get("mac_address", None),
        manufacturer=data.get("bios_manufacturer", None),
        model=data.get("bios_version", None),
        serialNumber=data.get("serial-number", None),
        assetCategory=regscale_models.AssetCategory.Hardware,
        assetType="Desktop",
        fqdn=data.get("fqdn", None),
        notes=data.get("remarks", None),
        operatingSystem=data.get("os_version", None),
        osVersion=(
            f"{data.get('major_version', None)}.{data.get('minor_version', None)}"
            if data.get("major_version", None)
            else None
        ),
        netBIOS=data.get("netbios-name", None),
        iPv6Address=data.get("ipv6-address", None),
        ram=0,
        diskStorage=0,
        cpu=0,
        assetOwnerId=user_id,
        status="Active (On Network)",
        isPublic=True,
        dateCreated=get_current_datetime(),
        dateLastUpdated=get_current_datetime(),
    ).create()
    return asset.dict()


def query_crowdstrike_incidents(regscale_id: int, regscale_module: str, filter_query: str, limit: int = 500) -> None:
    """
    Query alerts from CrowdStrike and create RegScale incidents.

    Uses the Alerts API v2 (replacing the retired Incidents API).

    :param int regscale_id: RegScale parent ID
    :param str regscale_module: RegScale parent module
    :param str filter_query: Falcon Query Language Filter
    :param int limit: Record limit, 1-500, defaults to 500
    :rtype: None
    """
    alert_id_list = []
    avail = True
    offset = 0
    sdk = open_sdk()

    if sdk is None:
        logger.error(SDK_INIT_FAILED_MESSAGE)
        error_and_exit("Unable to create CrowdStrike client. Please check your credentials.")

    while avail:
        try:
            params = {"limit": limit, "offset": offset}
            if filter_query:
                params["filter"] = filter_query
            response = sdk.query_alerts_v2(**params)

            body = validate_falcon_response(response)
            resources = body.get("resources", [])

            logger.info("Found %d alerts at offset %d.", len(resources), offset)

            if not resources:
                avail = False
            else:
                offset += limit
                alert_id_list.extend(resources)
        except Exception as e:
            logger.error("Error querying CrowdStrike alerts at offset %d: %s", offset, e)
            raise

    logger.info("Total alert IDs retrieved: %d", len(alert_id_list))
    if alert_id_list:
        alerts = get_alert_data(id_list=alert_id_list, sdk=sdk)
        logger.info("Retrieved details for %d alerts.", len(alerts))
        create_regscale_incidents(alerts, regscale_id, regscale_module)
    else:
        logger.warning("No alerts found matching the specified filter.")


def get_alert_ids(sdk: Alerts, filter_string: Optional[str]) -> list:
    """
    Retrieve all available alert IDs from CrowdStrike.

    Uses the Alerts API v2 (replacing the retired Incidents API).

    :param Alerts sdk: CrowdStrike Alerts SDK object
    :param Optional[str] filter_string: Filter string to use for query
    :return: List of alert composite IDs
    :rtype: list
    """
    params = {}
    if filter_string:
        params["filter"] = filter_string
    alert_id_lookup = sdk.query_alerts_v2(**params)

    body = validate_falcon_response(alert_id_lookup)
    resources = body.get("resources", [])

    if not resources:
        logger.warning(NO_INCIDENTS_FOUND_MESSAGE)

    return resources


def get_alert_data(id_list: list, sdk: Alerts) -> list[dict]:
    """
    Retrieve alert details using the composite IDs provided.

    Uses the Alerts API v2 (replacing the retired Incidents API).

    :param list id_list: List of alert composite IDs from CrowdStrike
    :param Alerts sdk: CrowdStrike Alerts SDK object
    :return: List of alert details
    :rtype: list[dict]
    """
    alert_detail_lookup = sdk.get_alerts_v2(composite_ids=id_list)

    body = validate_falcon_response(alert_detail_lookup)
    return body.get("resources", [])


def tagging(alert_id: str, tags: list, untag: bool = False) -> None:
    """
    Assign or remove tags on a CrowdStrike alert.

    :param str alert_id: Alert composite ID to tag
    :param list tags: List of tags to assign
    :param bool untag: Flag to remove tags instead of assign, defaults to False
    :rtype: None
    """
    sdk = open_sdk()
    if sdk is None:
        error_and_exit(SDK_INIT_FAILED_MESSAGE)
    full_id = get_alert_full_id(alert_id)
    if untag:
        change_result = sdk.update_alerts_v3(composite_ids=[full_id], remove_tag=tags[0] if tags else "")
    else:
        change_result = sdk.update_alerts_v3(composite_ids=[full_id], add_tag=tags[0] if tags else "")

    validate_falcon_response(change_result)


def get_alert_full_id(partial: str) -> str:
    """
    Retrieve the full alert composite ID based on the partial ID provided.

    :param str partial: Partial alert ID to search for
    :return: Full alert composite ID
    :rtype: str
    """
    sdk = open_sdk()
    if sdk is None:
        error_and_exit(SDK_INIT_FAILED_MESSAGE)
    search_result = sdk.query_alerts_v2()

    body = validate_falcon_response(search_result)
    resources = body.get("resources", [])
    found: str = ""

    for alert_id in resources:
        parts = alert_id.split(":")
        if len(parts) >= 3 and parts[2] == partial:
            found = alert_id
            break

    if not found:
        error_and_exit("Unable to find alert ID specified.")

    return found


def assignment(alert_id: str, assign_to: str = "", unassign: bool = False) -> None:
    """
    Assign the alert specified to the user specified.

    :param str alert_id: Alert composite ID to assign
    :param str assign_to: User ID to assign alert to
    :param bool unassign: Flag to unassign alert, defaults to False
    :rtype: None
    """
    sdk = open_sdk()
    if sdk is None:
        error_and_exit(SDK_INIT_FAILED_MESSAGE)
    full_id = get_alert_full_id(alert_id)
    if unassign:
        change_result = sdk.update_alerts_v3(composite_ids=[full_id], assign_to_uuid="")
        validate_falcon_response(change_result)
    else:
        from regscale.integrations.commercial.crowdstrike.sdk import get_users

        users = get_users()
        lookup_result = users.query_users(filter="uid:'%s'" % assign_to)

        body = validate_falcon_response(lookup_result)
        resources = body.get("resources", [])

        if not resources:
            error_and_exit("No user found with that UID")

        change_result = sdk.update_alerts_v3(
            composite_ids=[full_id],
            assign_to_uuid=resources[0],
        )
        validate_falcon_response(change_result)


def sync_incidents_to_regscale(
    regscale_id: int,
    regscale_module: str,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
) -> None:
    """
    Sync alerts from CrowdStrike to RegScale as incidents.

    Uses the Alerts API v2 (replacing the retired Incidents API).

    :param int regscale_id: RegScale record ID
    :param str regscale_module: RegScale Module
    :param bool dry_run: If True, return item counts without syncing
    :param Optional[int] offset: Skip this many items from the start
    :param Optional[int] limit: Process at most this many items
    :rtype: None
    """
    verify_provided_module(regscale_module)
    sdk = open_sdk()
    alert_id_list = get_alert_ids(filter_string=None, sdk=sdk)
    if not alert_id_list:
        error_and_exit("No alerts found!")

    if dry_run:
        click.echo(json.dumps({"total_items": len(alert_id_list)}))
        return

    if offset is not None:
        alert_id_list = alert_id_list[offset:]
    if limit is not None:
        alert_id_list = alert_id_list[:limit]

    alerts = get_alert_data(id_list=alert_id_list, sdk=sdk)
    logger.info("Found %d alerts to sync.", len(alerts))
    create_regscale_incidents(alerts=alerts, regscale_id=regscale_id, regscale_module=regscale_module)
