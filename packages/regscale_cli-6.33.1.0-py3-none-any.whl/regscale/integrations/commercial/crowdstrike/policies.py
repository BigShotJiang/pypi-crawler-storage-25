#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike Prevention Policy fetching and HTML report generation.

Retrieves prevention policy configurations from CrowdStrike Falcon
and generates auditor-friendly HTML evidence reports for SOC2 compliance.
"""

import logging
from datetime import datetime
from html import escape
from typing import Any, Dict, List, Optional

logger = logging.getLogger("regscale")

# Platform grouping for policy categorization
_SERVER_KEYWORDS = {"server", "datacenter", "production", "hosted", "archiving"}
_WORKSTATION_KEYWORDS = {"end user", "workstation", "corporate", "laptop", "desktop", "employee"}


def fetch_prevention_policies(auth_object=None) -> List[Dict[str, Any]]:
    """
    Fetch all prevention policies from CrowdStrike.

    :param auth_object: Optional pre-authenticated auth object to reuse
    :return: List of prevention policy dictionaries
    :rtype: List[Dict[str, Any]]
    """
    from falconpy import PreventionPolicies

    from regscale.integrations.commercial.crowdstrike.sdk import resolve_auth

    auth = resolve_auth(auth_object)
    policies_sdk = PreventionPolicies(auth_object=auth)

    all_policies = []
    offset = 0
    limit = 100

    logger.info("Fetching prevention policies from CrowdStrike...")

    while True:
        response = policies_sdk.query_combined_policies(limit=limit, offset=offset)
        status_code = response.get("status_code")
        body = response.get("body", {})

        if status_code != 200:
            errors = body.get("errors", [])
            error_msg = "; ".join(e.get("message", "Unknown") if isinstance(e, dict) else str(e) for e in errors)
            logger.error("CrowdStrike PreventionPolicies API error (status %s): %s", status_code, error_msg)
            break

        resources = body.get("resources", [])
        if not resources:
            break

        all_policies.extend(resources)
        offset += limit

        meta = body.get("meta", {})
        pagination = meta.get("pagination", {})
        total = pagination.get("total", 0)

        logger.info("Fetched %d of %d prevention policies...", len(all_policies), total)

        if len(all_policies) >= total:
            break

    logger.info("Completed fetching %d prevention policies.", len(all_policies))
    return all_policies


def fetch_host_groups(auth_object=None) -> Dict[str, Dict[str, Any]]:
    """
    Fetch all host groups from CrowdStrike, keyed by group ID.

    :param auth_object: Optional pre-authenticated auth object to reuse
    :return: Dictionary mapping group ID to group details
    :rtype: Dict[str, Dict[str, Any]]
    """
    from falconpy import HostGroup

    from regscale.integrations.commercial.crowdstrike.sdk import resolve_auth

    auth = resolve_auth(auth_object)
    host_groups_sdk = HostGroup(auth_object=auth)

    groups = {}
    offset = 0
    limit = 100

    while True:
        response = host_groups_sdk.query_combined_host_groups(limit=limit, offset=offset)
        status_code = response.get("status_code")
        body = response.get("body", {})

        if status_code != 200:
            logger.warning("Failed to fetch host groups (status %s)", status_code)
            break

        resources = body.get("resources", [])
        if not resources:
            break

        for group in resources:
            group_id = group.get("id", "")
            if group_id:
                groups[group_id] = group

        offset += limit
        meta = body.get("meta", {})
        total = meta.get("pagination", {}).get("total", 0)
        if len(groups) >= total:
            break

    logger.info("Fetched %d host groups.", len(groups))
    return groups


def categorize_policy(policy: Dict[str, Any]) -> str:
    """
    Categorize a policy as Server, Workstation, or General based on name/description.

    :param Dict[str, Any] policy: Policy dictionary
    :return: Category string
    :rtype: str
    """
    name_lower = policy.get("name", "").lower()
    desc_lower = policy.get("description", "").lower()
    combined = name_lower + " " + desc_lower

    if any(kw in combined for kw in _SERVER_KEYWORDS):
        return "Server"
    if any(kw in combined for kw in _WORKSTATION_KEYWORDS):
        return "Workstation"
    return "General"


def _format_setting_value(setting: Dict[str, Any]) -> str:
    """
    Format a prevention setting value for display.

    :param Dict[str, Any] setting: Setting dictionary with id and value keys
    :return: Human-readable setting value
    :rtype: str
    """
    value = setting.get("value", {})
    if isinstance(value, dict):
        enabled = value.get("enabled", False)
        detection = value.get("detection", "DISABLED")
        prevention = value.get("prevention", "DISABLED")
        if detection != "DISABLED" or prevention != "DISABLED":
            return "Detection: %s, Prevention: %s" % (detection, prevention)
        return "Enabled" if enabled else "Disabled"
    return str(value)


def generate_policy_html_report(
    policies: List[Dict[str, Any]],
    host_groups: Optional[Dict[str, Dict[str, Any]]] = None,
) -> str:
    """
    Generate an auditor-friendly HTML report of prevention policy configurations.

    :param List[Dict[str, Any]] policies: List of prevention policy dictionaries
    :param Optional[Dict[str, Dict[str, Any]]] host_groups: Host groups keyed by ID
    :return: HTML report string
    :rtype: str
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
    host_groups = host_groups or {}

    # Categorize policies
    server_policies = []
    workstation_policies = []
    general_policies = []

    for policy in policies:
        category = categorize_policy(policy)
        if category == "Server":
            server_policies.append(policy)
        elif category == "Workstation":
            workstation_policies.append(policy)
        else:
            general_policies.append(policy)

    parts = [
        "<h1>CrowdStrike Prevention Policy Configuration Report</h1>",
        "<p><strong>Generated:</strong> %s</p>" % escape(now),
        "<p><strong>Total Policies:</strong> %d</p>" % len(policies),
        "<hr>",
    ]

    # Summary table
    parts.append("<h2>Policy Summary</h2>")
    parts.append("<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse;width:100%'>")
    parts.append(
        "<tr style='background-color:#f0f0f0'>"
        "<th>Policy Name</th><th>Platform</th><th>Category</th>"
        "<th>Enabled</th><th>Assigned Groups</th></tr>"
    )

    for policy in policies:
        name = escape(policy.get("name", "Unknown"))
        platform = escape(policy.get("platform_name", "Unknown"))
        category = categorize_policy(policy)
        enabled = policy.get("enabled", False)
        enabled_str = "<span style='color:green'>Yes</span>" if enabled else "<span style='color:red'>No</span>"
        group_ids = policy.get("groups", [])
        group_names = _resolve_group_names(group_ids, host_groups)

        parts.append(
            "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
            % (name, platform, category, enabled_str, escape(", ".join(group_names) if group_names else "None"))
        )

    parts.append("</table>")

    # Detailed sections
    if server_policies:
        parts.append(_generate_policy_section("Server Policies", server_policies, host_groups))

    if workstation_policies:
        parts.append(_generate_policy_section("Workstation Policies", workstation_policies, host_groups))

    if general_policies:
        parts.append(_generate_policy_section("General Policies", general_policies, host_groups))

    return "".join(parts)


def _resolve_group_names(
    group_ids: List[Dict[str, Any]],
    host_groups: Dict[str, Dict[str, Any]],
) -> List[str]:
    """
    Resolve host group IDs to names.

    :param List[Dict[str, Any]] group_ids: List of group reference dicts
    :param Dict[str, Dict[str, Any]] host_groups: Host groups keyed by ID
    :return: List of group names
    :rtype: List[str]
    """
    names = []
    for group_ref in group_ids:
        gid = group_ref.get("id", "") if isinstance(group_ref, dict) else str(group_ref)
        group = host_groups.get(gid, {})
        names.append(group.get("name", gid))
    return names


def _generate_policy_section(
    section_title: str,
    policies: List[Dict[str, Any]],
    host_groups: Dict[str, Dict[str, Any]],
) -> str:
    """
    Generate HTML section for a category of policies with full setting details.

    :param str section_title: Section heading
    :param List[Dict[str, Any]] policies: Policies in this category
    :param Dict[str, Dict[str, Any]] host_groups: Host groups keyed by ID
    :return: HTML section string
    :rtype: str
    """
    parts = ["<h2>%s</h2>" % escape(section_title)]

    for policy in policies:
        name = escape(policy.get("name", "Unknown"))
        description = escape(policy.get("description", "No description"))
        platform = escape(policy.get("platform_name", "Unknown"))
        enabled = policy.get("enabled", False)
        enabled_str = "Yes" if enabled else "No"
        created = escape(policy.get("created_timestamp", "Unknown"))
        modified = escape(policy.get("modified_timestamp", "Unknown"))

        parts.append("<h3>%s</h3>" % name)
        parts.append("<ul>")
        parts.append("<li><strong>Description:</strong> %s</li>" % description)
        parts.append("<li><strong>Platform:</strong> %s</li>" % platform)
        parts.append("<li><strong>Enabled:</strong> %s</li>" % enabled_str)
        parts.append("<li><strong>Created:</strong> %s</li>" % created)
        parts.append("<li><strong>Last Modified:</strong> %s</li>" % modified)

        # Assigned host groups
        group_ids = policy.get("groups", [])
        group_names = _resolve_group_names(group_ids, host_groups)
        parts.append(
            "<li><strong>Assigned Host Groups:</strong> %s</li>"
            % escape(", ".join(group_names) if group_names else "None")
        )
        parts.append("</ul>")

        # Prevention settings
        settings = policy.get("prevention_settings", [])
        if settings:
            parts.append("<h4>Prevention Settings</h4>")
            parts.append(
                "<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%'>"
            )
            parts.append("<tr style='background-color:#f0f0f0'><th>Setting</th><th>Value</th></tr>")
            for setting_group in settings:
                group_settings = setting_group.get("settings", [])
                for s in group_settings:
                    setting_name = escape(s.get("name", s.get("id", "Unknown")))
                    setting_val = escape(_format_setting_value(s))
                    parts.append("<tr><td>%s</td><td>%s</td></tr>" % (setting_name, setting_val))
            parts.append("</table>")

    return "".join(parts)
