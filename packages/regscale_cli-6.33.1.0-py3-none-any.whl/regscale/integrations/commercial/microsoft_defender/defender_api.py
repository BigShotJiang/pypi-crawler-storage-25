"""
Module to handle API calls to Microsoft Defender for Cloud
"""

import os.path
from json import JSONDecodeError
from logging import getLogger
from pathlib import Path
from typing import Any, Literal, Optional
from urllib.parse import urljoin

from requests import Response

from regscale.core.app.api import Api
from regscale.core.app.utils.app_utils import (
    check_file_path,
    error_and_exit,
    get_current_datetime,
    save_data_to,
)
from regscale.integrations.commercial.microsoft_defender.defender_constants import (
    ACR_ARM_API_VERSION,
    APP_JSON,
    DATA_TYPE,
    ENTRA_ENDPOINTS,
    ENTRA_SAVE_DIR,
)
from regscale.integrations.commercial.microsoft_defender.defender_variables import DefenderVariables

logger = getLogger("regscale")


class DefenderApi:
    """
    Class to handle API calls to Microsoft Defender 365, Microsoft Defender for Cloud, or Azure Entra

    :param Literal["cloud", "365", "entra"] system: Which system to make API calls to
    :param Optional[str] cloud_env: Azure cloud environment (commercial, government, or china). Overrides init.yaml setting.
    """

    def __init__(self, system: Literal["cloud", "365", "entra"], cloud_env: Optional[str] = None):
        self.api: Api = Api()
        self.system: Literal["cloud", "365", "entra"] = system
        self.decode_error: str = "JSON Decode error"
        self.skip_token_key: str = "$skipToken"
        # Detect Azure cloud environment for cross-cloud support (must be before set_headers)
        self.azure_cloud_env = self._detect_azure_cloud_environment(cloud_env)
        # Now set headers after cloud environment is detected
        self.headers: dict = self.set_headers()

    def _detect_azure_cloud_environment(self, cloud_env: Optional[str] = None) -> str:
        """
        Detect Azure cloud environment from CLI flag, config, or default to commercial.

        Supports:
        - commercial: Azure Commercial Cloud (login.microsoftonline.com)
        - government: Azure Government Cloud / GovCloud (login.microsoftonline.us) - for FedRAMP
        - china: Azure China Cloud (login.chinacloudapi.cn)

        :param Optional[str] cloud_env: Cloud environment from CLI flag (overrides config)
        :return: Azure cloud environment identifier
        :rtype: str
        """
        # Priority: CLI flag > config file > default
        if cloud_env:
            env = cloud_env.lower()
            logger.info(f"Using cloud environment from CLI flag: {env}")
        else:
            # Check if user has explicitly configured Azure cloud environment
            env = DefenderVariables.azureCloudEnvironment.lower()

        # Validate environment
        if env not in ["commercial", "government", "china"]:
            logger.warning(
                f"Invalid azureCloudEnvironment '{env}'. Defaulting to 'commercial'. "
                "Valid options: commercial, government, china. "
                "Use --cloud-env flag or add 'azureCloudEnvironment: government' to your init.yaml for Azure GovCloud."
            )
            env = "commercial"

        if env == "government":
            logger.info("Using Azure Government Cloud endpoints (login.microsoftonline.us) for FedRAMP compliance")
        elif env == "china":
            logger.info("Using Azure China Cloud endpoints (login.chinacloudapi.cn)")
        else:
            logger.info("Using Azure Commercial Cloud endpoints (login.microsoftonline.com)")

        return env

    def _get_azure_authority_url(self) -> str:
        """
        Get the Azure AD authority URL based on cloud environment.

        :return: Azure AD authority base URL
        :rtype: str
        """
        # if the defender base url is set, use it
        if DefenderVariables.defenderBaseUrl:
            return DefenderVariables.defenderBaseUrl
        authority_urls = {
            "commercial": "https://login.microsoftonline.com",
            "government": "https://login.microsoftonline.us",
            "china": "https://login.chinacloudapi.cn",
        }
        return authority_urls.get(self.azure_cloud_env, authority_urls["commercial"])

    def _get_graph_api_base_url(self) -> str:
        """
        Get the Microsoft Graph API base URL (without version path) based on cloud environment.
        Used for authentication scopes.

        :return: Graph API base URL (e.g., https://graph.microsoft.com)
        :rtype: str
        """
        # if the defender base url is set, use it
        if DefenderVariables.defenderBaseUrl:
            return DefenderVariables.defenderBaseUrl
        graph_urls = {
            "commercial": "https://graph.microsoft.com",
            "government": "https://graph.microsoft.us",
            "china": "https://microsoftgraph.chinacloudapi.cn",
        }
        return graph_urls.get(self.azure_cloud_env, graph_urls["commercial"])

    def _get_graph_api_url(self) -> str:
        """
        Get the Microsoft Graph API URL with version path based on cloud environment.
        Used for API endpoint calls.

        :return: Graph API base URL with /v1.0 path
        :rtype: str
        """
        return f"{self._get_graph_api_base_url()}/v1.0"

    def set_headers(self) -> dict:
        """
        Function to set the headers for the API calls
        """
        token = self.check_token()
        return {"Content-Type": APP_JSON, "Authorization": token}

    def get_token(self) -> str:
        """
        Function to get a token from Microsoft Azure and saves it to init.yaml

        :return: JWT from Azure
        :rtype: str
        """
        # Get the Azure authority URL based on cloud environment
        authority_url = self._get_azure_authority_url()

        # set the url and body for request
        if self.system == "365":
            url = f"{authority_url}/{DefenderVariables.azure365TenantId}/oauth2/token"
            client_id = DefenderVariables.azure365ClientId
            client_secret = DefenderVariables.azure365Secret
            resource = DefenderVariables.defenderBaseUrl or "https://api.securitycenter.windows.com"
            key = "azure365AccessToken"
        elif self.system == "cloud":
            url = f"{authority_url}/{DefenderVariables.azureCloudTenantId}/oauth2/token"
            client_id = DefenderVariables.azureCloudClientId
            client_secret = DefenderVariables.azureCloudSecret
            resource = DefenderVariables.defenderBaseUrl or "https://management.azure.com"
            key = "azureCloudAccessToken"
        elif self.system == "entra":
            # Get Graph API base URL for the cloud environment (for authentication scope)
            graph_url = self._get_graph_api_base_url()
            url = f"{authority_url}/{DefenderVariables.azureEntraTenantId}/oauth2/v2.0/token"
            client_id = DefenderVariables.azureEntraClientId
            client_secret = DefenderVariables.azureEntraSecret
            resource = DefenderVariables.defenderBaseUrl or f"{graph_url}/.default"
            key = "azureEntraAccessToken"
            logger.info(f"Authenticating to {url} with resource {resource}")
        if self.system == "entra":
            data = {
                "scope": resource,
                "client_id": client_id,
                "client_secret": client_secret,
                "grant_type": "client_credentials",
            }
        else:
            data = {
                "resource": resource,
                "client_id": client_id,
                "client_secret": client_secret,
                "grant_type": "client_credentials",
            }
        # get the data
        response = self.api.post(
            url=url,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data=data,
        )

        # Log response details for debugging
        logger.info(f"Azure response status: {response.status_code}")
        logger.debug(f"Azure response headers: {response.headers}")

        # Try to parse as JSON first, log the raw response if it fails
        try:
            response_json = response.json()
            logger.debug(f"Azure response JSON: {response_json}")
        except JSONDecodeError:
            logger.error(f"Azure returned non-JSON response. Status: {response.status_code}")
            logger.error(f"Response content (first 1000 chars): {response.text[:1000]}")
            error_and_exit(
                f"Unable to authenticate with Azure. Expected JSON response but got:\n"
                f"Status Code: {response.status_code}\n"
                f"Content-Type: {response.headers.get('Content-Type', 'unknown')}\n"
                f"Response: {response.text[:500]}"
            )

        try:
            return self._parse_and_save_token(response, key)
        except KeyError as ex:
            # notify user we weren't able to get a token and exit
            error_and_exit(f"Didn't receive token from Azure.\nMissing key: {ex}\nResponse: {response_json}")

    def check_token(self, url: Optional[str] = None) -> str:
        """
        Function to check if current Azure token from init.yaml is valid, if not replace it

        :param str url: The URL to use for authentication, defaults to None
        :return: returns JWT for Microsoft 365 Defender or Microsoft Defender for Cloud depending on system provided
        :rtype: str
        """
        # set up variables for the provided system
        if self.system == "cloud":
            key = "azureCloudAccessToken"
        elif self.system.lower() == "365":
            key = "azure365AccessToken"
        elif self.system == "entra":
            key = "azureEntraAccessToken"
        else:
            error_and_exit(
                f"{self.system.title()} is not supported, only Microsoft 365 Defender, Microsoft Defender for Cloud, and Azure Entra."
            )
        current_token = getattr(DefenderVariables, key)
        # check the token if it isn't blank
        if current_token and url:
            # set the headers
            header = {"Content-Type": APP_JSON, "Authorization": current_token}
            # test current token by getting recommendations
            token_pass = self.api.get(url=url, headers=header)
            # check the status code
            if getattr(token_pass, "status_code", 0) == 200:
                # token still valid, return it
                token = current_token
                logger.info(
                    "Current token for %s is still valid and will be used for future requests.",
                    self.system.title(),
                )
            elif getattr(token_pass, "status_code", 0) == 403:
                # token doesn't have permissions, notify user and exit
                error_and_exit(
                    "Incorrect permissions set for application. Cannot retrieve recommendations.\n"
                    + f"{token_pass.status_code}: {token_pass.reason}\n{token_pass.text}"
                )
            else:
                # token is no longer valid, get a new one
                token = self.get_token()
        # token is empty, get a new token
        else:
            token = self.get_token()
        return token

    def _parse_and_save_token(self, response: Response, key: str) -> str:
        """
        Function to parse the token from the response and save it to init.yaml

        :param Response response: Response from API call
        :param str key: Key to use for init.yaml token update
        :return: JWT from Azure for the provided system
        :rtype: str
        """
        # try to read the response and parse the token
        res = response.json()
        token = res["access_token"]

        # add the token to init.yaml
        setattr(DefenderVariables, key, f"Bearer {token}")

        # update the application config
        self.api.config[key] = getattr(DefenderVariables, key)

        # write the changes back to file
        self.api.app.save_config(self.api.config)  # type: ignore

        # notify the user we were successful
        logger.info(
            f"Azure {self.system.title()} Login Successful! Init.yaml file was updated with the new access token."
        )
        # return the token string
        return getattr(DefenderVariables, key)

    def execute_resource_graph_query(
        self, query: str = None, skip_token: Optional[str] = None, record_count: int = 0
    ) -> list[dict]:
        """
        Function to fetch Microsoft Defender resources from Azure

        :param str query: Query to use for the API call
        :param Optional[str] skip_token: Token to skip results, used during pagination, defaults to None
        :param int record_count: Number of records fetched, defaults to 0, used for logging during pagination
        :return: list of Microsoft Defender resources
        :rtype: list[dict]
        """
        base = DefenderVariables.defenderBaseUrl or "https://management.azure.com"
        url = urljoin(base, "/providers/Microsoft.ResourceGraph/resources?api-version=2024-04-01")
        if query:
            payload: dict[str, Any] = {"query": query}
        else:
            payload: dict[str, Any] = {
                "query": query,
                "subscriptions": [DefenderVariables.azureCloudSubscriptionId],
            }
        if skip_token:
            payload["options"] = {self.skip_token_key: skip_token}
            logger.info("Retrieving more Microsoft Defender resources from Azure...")
        else:
            logger.info("Retrieving Microsoft Defender resources from Azure...")
        response = self.api.post(url=url, headers=self.headers, json=payload)
        if response.status_code != 200:
            error_and_exit(
                f"Received unexpected response from Microsoft Defender.\n{response.status_code}:{response.reason}"
                + f"\n{response.text}",
            )
        try:
            response_data = response.json()
            total_records = response_data.get("totalRecords", 0)
            count = response_data.get("count", len(response_data.get("data", [])))
            logger.info(f"Received {count + record_count}/{total_records} items from Microsoft Defender.")
            # try to get the values from the api response
            defender_data = response_data["data"]
        except JSONDecodeError:
            # notify user if there was a json decode error from API response and exit
            error_and_exit(self.decode_error)
        except KeyError:
            # notify user there was no data from API response and exit
            error_and_exit(
                f"Received unexpected response from Microsoft Defender.\n{response.status_code}: {response.reason}\n"
                + f"{response.text}"
            )
        # check if pagination is required to fetch all data from Microsoft Defender
        skip_token = response_data.get(self.skip_token_key)
        if response.status_code == 200 and skip_token:
            # get the rest of the data
            defender_data.extend(
                self.execute_resource_graph_query(
                    query=query,
                    skip_token=skip_token,
                    record_count=count + record_count,
                )
            )
        # return the defender recommendations
        return defender_data

    def get_items_from_azure(self, url: str, parse_value: Optional[bool] = True) -> list:
        """
        Function to get data from Microsoft Defender returns the data as a list while handling pagination

        :param str url: URL to use for the API call
        :param Optional[bool] parse_value: Whether to parse the value from the API response, defaults to True
        :return: list of recommendations
        :rtype: list
        """
        # get the data via api call
        response = self.api.get(url=url, headers=self.headers)
        if response.status_code != 200:
            KNOWN_LICENSE_ERRORS = {"AadPremiumLicenseRequired"}
            try:
                error_body = response.json()
                error_code = error_body.get("error", {}).get("code", "")
            except Exception:
                error_code = ""
            if error_code in KNOWN_LICENSE_ERRORS:
                license_msg = response.json().get("error", {}).get("message", error_code)
                logger.warning(
                    f"Skipping data collection due to licensing limitation: {license_msg} "
                    f"(HTTP {response.status_code}). This is expected for tenants without "
                    f"the required premium license."
                )
                return []
            error_and_exit(
                f"Received unexpected response from Microsoft Defender.\n{response.status_code}:{response.reason}"
                + f"\n{response.text}",
            )
        # try to read the response
        try:
            response_data = response.json()
            # try to get the values from the api response
            if parse_value:
                defender_data = response_data["value"]
            else:
                defender_data = response_data
        except JSONDecodeError:
            # notify user if there was a json decode error from API response and exit
            error_and_exit(self.decode_error)
        except KeyError:
            # notify user there was no data from API response and exit
            error_and_exit(
                f"Received unexpected response from Microsoft Defender.\n{response.status_code}: {response.text}"
            )
        # check if pagination is required to fetch all data from Microsoft Defender
        if next_link := (response_data.get("nextLink") or response_data.get("@odata.nextLink")):
            # get the rest of the data
            defender_data.extend(self.get_items_from_azure(url=next_link))
        # return the defender recommendations
        return defender_data

    def fetch_queries_from_azure(self) -> list[dict]:
        """
        Function to fetch queries from Microsoft Defender for Cloud
        """
        url = (
            f"{DefenderVariables.defenderBaseUrl or 'https://management.azure.com'}/subscriptions/{DefenderVariables.azureCloudSubscriptionId}/"
            "providers/Microsoft.ResourceGraph/queries?api-version=2024-04-01"
        )
        logger.info("Fetching saved queries from Azure Resource Graph...")
        response = self.api.get(url=url, headers=self.headers)
        logger.debug(f"Azure API response status: {response.status_code}")
        if response.raise_for_status():
            error_and_exit(
                f"Received unexpected response from Microsoft Defender.\n{response.status_code}:{response.reason}"
                + f"\n{response.text}",
            )
        logger.debug("Parsing Azure API response...")
        cloud_queries = response.json().get("value", [])
        logger.info(f"Found {len(cloud_queries)} saved queries in Azure Resource Graph.")
        return cloud_queries

    def fetch_and_run_query(self, query: dict) -> list[dict]:
        """
        Function to fetch and run a query from Microsoft Defender for Cloud

        :param dict query: Query to run in Azure Resource Graph
        :return: Results from the query
        :rtype: list[dict]
        """
        url = (
            f"{DefenderVariables.defenderBaseUrl or 'https://management.azure.com'}/subscriptions/{query['subscriptionId']}/resourceGroups/"
            f"{query['resourceGroup']}/providers/Microsoft.ResourceGraph/queries/{query['name']}"
            "?api-version=2024-04-01"
        )
        response = self.api.get(url=url, headers=self.headers)
        if response.raise_for_status():
            error_and_exit(
                f"Received unexpected response from Microsoft Defender.\n{response.status_code}:{response.reason}"
                + f"\n{response.text}",
            )
        query_string = response.json().get("properties", {}).get("query")
        return self.execute_resource_graph_query(query=query_string)

    def get_and_save_entra_evidence(self, endpoint_key: str, **kwargs) -> list[Path]:
        """
        Function to get Azure Entra evidence data from Microsoft Graph API and saves it to a csv file

        :param str endpoint_key: Key from ENTRA_ENDPOINTS to specify which endpoint to call
        :param kwargs: Additional parameters for URL formatting
        :return: List of Paths to the saved csv files
        :rtype: list[Path]
        """
        if self.system != "entra":
            error_and_exit("This method can only be used with system='entra'")

        if endpoint_key not in ENTRA_ENDPOINTS:
            error_and_exit(f"Unknown endpoint key: {endpoint_key}")

        endpoint = ENTRA_ENDPOINTS[endpoint_key]

        # Handle URL parameter substitution
        if "{start_date}" in endpoint:
            start_date = kwargs.get("start_date", get_current_datetime("%Y-%m-%dT00:00:00Z"))
            endpoint = endpoint.replace("{start_date}", start_date)

        if "{group-id}" in endpoint:
            group_id = kwargs.get("group_id")
            if not group_id:
                error_and_exit("group_id parameter is required for this endpoint")
            endpoint = endpoint.replace("{group-id}", group_id)

        if "{def_id}" in endpoint:
            def_id = kwargs.get("def_id")
            if not def_id:
                error_and_exit("def_id parameter is required for this endpoint")
            endpoint = endpoint.replace("{def_id}", def_id)

        if "{instance_id}" in endpoint:
            instance_id = kwargs.get("instance_id")
            if not instance_id:
                error_and_exit("instance_id parameter is required for this endpoint")
            endpoint = endpoint.replace("{instance_id}", instance_id)

        url = f"{DefenderVariables.defenderBaseUrl or self._get_graph_api_url()}{endpoint}"
        logger.info(f"Retrieving Azure Entra evidence from: {endpoint_key}")

        data = self.get_items_from_azure(url=url, parse_value=kwargs.get("parse_value", True))
        if not data:
            logger.warning(f"No data returned for {endpoint_key}, skipping file save.")
            return []
        save_path = Path(
            os.path.join(
                ENTRA_SAVE_DIR,
                f"azure_entra_{endpoint_key}_{get_current_datetime('%Y%m%d')}.xlsx",
            )
        )
        save_data_to(file=save_path, data=data, transpose_data=False)
        return [save_path]

    def _safe_collect_evidence(self, evidence_key: str, **kwargs) -> list[Path]:
        """
        Safely collect a single evidence type, returning an empty list on failure
        so that other evidence types are not affected.

        :param str evidence_key: The evidence endpoint key to collect
        :param kwargs: Additional keyword arguments passed to get_and_save_entra_evidence
        :return: List of file paths to saved evidence, or empty list on failure
        :rtype: list[Path]
        """
        try:
            return self.get_and_save_entra_evidence(evidence_key, **kwargs)
        except (Exception, SystemExit) as e:
            logger.error(f"Error collecting {evidence_key} evidence: {e}")
            return []

    def collect_all_entra_evidence(self, days_back: int = 30) -> dict[str, list[Path]]:
        """
        Function to collect all Azure Entra evidence data for FedRAMP compliance

        :param int days_back: Number of days back to collect audit logs, defaults to 30
        :return: Dict containing all evidence data categorized by type and list of Paths to the saved csv evidence files
        :rtype: dict[str, list[Path]]
        """
        from datetime import datetime, timedelta

        evidence_data = {}
        start_date = (datetime.now() - timedelta(days=days_back)).strftime("%Y-%m-%dT00:00:00Z")

        check_file_path(ENTRA_SAVE_DIR)

        # Users and Groups
        evidence_data["users"] = self._safe_collect_evidence("users")
        evidence_data["users_delta"] = self._safe_collect_evidence("users_delta")
        evidence_data["guest_users"] = self._safe_collect_evidence("guest_users")
        evidence_data["groups_and_members"] = self._safe_collect_evidence("groups_and_members")
        evidence_data["security_groups"] = self._safe_collect_evidence("security_groups")

        # RBAC and PIM
        evidence_data["role_assignments"] = self._safe_collect_evidence("role_assignments")
        evidence_data["role_definitions"] = self._safe_collect_evidence("role_definitions")
        evidence_data["pim_assignments"] = self._safe_collect_evidence("pim_assignments")
        evidence_data["pim_eligibility"] = self._safe_collect_evidence("pim_eligibility")

        # Conditional Access
        evidence_data["conditional_access"] = self._safe_collect_evidence("conditional_access")

        # Authentication Methods
        evidence_data["auth_methods_policy"] = self._safe_collect_evidence("auth_methods_policy", parse_value=False)
        evidence_data["user_mfa_registration"] = self._safe_collect_evidence("user_mfa_registration")
        evidence_data["mfa_registered_users"] = self._safe_collect_evidence("mfa_registered_users")

        # Audit Logs (may require additional permissions)
        evidence_data["sign_in_logs"] = self._safe_collect_evidence("sign_in_logs", start_date=start_date)
        evidence_data["directory_audits"] = self._safe_collect_evidence("directory_audits", start_date=start_date)
        evidence_data["provisioning_logs"] = self._safe_collect_evidence("provisioning_logs", start_date=start_date)

        # Access Reviews
        try:
            evidence_data["access_review_definitions"] = self.collect_entra_access_reviews()
            logger.info("Successfully collected access review evidence")
        except (Exception, SystemExit) as e:
            logger.error(f"Error collecting access review evidence: {e}")
            evidence_data["access_review_definitions"] = []

        collected = {k: v for k, v in evidence_data.items() if v}
        skipped = {k for k, v in evidence_data.items() if not v}
        logger.info(
            f"Evidence collection complete: {len(collected)} types collected successfully"
            + (f", {len(skipped)} types skipped or empty ({', '.join(sorted(skipped))})" if skipped else "")
        )

        return evidence_data

    def collect_entra_access_reviews(self) -> list[Path]:
        """
        Function to collect access reviews from Microsoft Graph API

        :return: List of paths to the saved csv files
        :rtype: list[Path]
        """
        file_paths = []
        url = urljoin(
            DefenderVariables.defenderBaseUrl or self._get_graph_api_url(), ENTRA_ENDPOINTS["access_review_definitions"]
        )
        definitions = self.get_items_from_azure(url=url)
        current_date = get_current_datetime("%Y-%m-%d")

        for definition in definitions:
            definition_name = definition["displayName"].replace("/", "_").replace(" ", "_")

            # Save flattened definition data
            definition_path = Path(
                os.path.join(
                    ENTRA_SAVE_DIR,
                    f"access_reviews_definitions_{definition_name}_{current_date}.csv",
                )
            )
            flattened_definition = self._flatten_access_review_definition(definition)
            save_data_to(file=definition_path, data=[flattened_definition], transpose_data=False)
            file_paths.append(definition_path)

            # Get instances and decisions
            instance_url = urljoin(
                DefenderVariables.defenderBaseUrl or self._get_graph_api_url(),
                ENTRA_ENDPOINTS["access_review_instances"].format(def_id=definition["id"]),
            )
            instances = self.get_items_from_azure(url=instance_url)

            # Save flattened instances data
            instances_path = Path(
                os.path.join(
                    ENTRA_SAVE_DIR,
                    f"access_reviews_instances_{definition_name}_{current_date}.csv",
                )
            )
            flattened_instances = []
            for instance in instances:
                flattened_instance = self._flatten_access_review_instance(definition["id"], instance)
                flattened_instances.append(flattened_instance)

            if flattened_instances:
                save_data_to(file=instances_path, data=flattened_instances, transpose_data=False)
                file_paths.append(instances_path)

            # Save flattened decisions data
            decisions_path = Path(
                os.path.join(
                    ENTRA_SAVE_DIR,
                    f"access_reviews_decisions_{definition_name}_{current_date}.csv",
                )
            )
            all_decisions = []
            for instance in instances:
                decision_url = urljoin(
                    DefenderVariables.defenderBaseUrl or self._get_graph_api_url(),
                    ENTRA_ENDPOINTS["access_review_decisions"].format(
                        def_id=definition["id"], instance_id=instance["id"]
                    ),
                )
                decisions = self.get_items_from_azure(url=decision_url)
                for decision in decisions:
                    flattened_decision = self._flatten_access_review_decision(
                        definition["id"], instance["id"], decision
                    )
                    all_decisions.append(flattened_decision)

            if all_decisions:
                save_data_to(file=decisions_path, data=all_decisions, transpose_data=False)
                file_paths.append(decisions_path)

        return file_paths

    @staticmethod
    def _flatten_access_review_definition(definition: dict) -> dict:
        """
        Flatten access review definition for CSV export

        :param dict definition: Definition data
        :return: Flattened definition data
        :rtype: dict
        """
        return {
            "id": definition.get("id"),
            "displayName": definition.get("displayName"),
            "status": definition.get("status"),
            "createdDateTime": definition.get("createdDateTime"),
            "lastModifiedDateTime": definition.get("lastModifiedDateTime"),
            "descriptionForAdmins": definition.get("descriptionForAdmins"),
            "descriptionForReviewers": definition.get("descriptionForReviewers"),
            "createdBy_displayName": definition.get("createdBy", {}).get("displayName"),
            "createdBy_id": definition.get("createdBy", {}).get("id"),
            "createdBy_userPrincipalName": definition.get("createdBy", {}).get("userPrincipalName"),
            "scope_type": definition.get("scope", {}).get(DATA_TYPE),
            "scope_query": definition.get("scope", {}).get("query"),
            "scope_inactiveDuration": definition.get("scope", {}).get("inactiveDuration"),
            "instanceEnumerationScope_type": definition.get("instanceEnumerationScope", {}).get(DATA_TYPE),
            "instanceEnumerationScope_query": definition.get("instanceEnumerationScope", {}).get("query"),
            "settings_defaultDecision": definition.get("settings", {}).get("defaultDecision"),
            "settings_autoApplyDecisionsEnabled": definition.get("settings", {}).get("autoApplyDecisionsEnabled"),
            "settings_instanceDurationInDays": definition.get("settings", {}).get("instanceDurationInDays"),
            "settings_justificationRequiredOnApproval": definition.get("settings", {}).get(
                "justificationRequiredOnApproval"
            ),
            "settings_mailNotificationsEnabled": definition.get("settings", {}).get("mailNotificationsEnabled"),
            "settings_recommendationsEnabled": definition.get("settings", {}).get("recommendationsEnabled"),
            "settings_recurrence_type": definition.get("settings", {})
            .get("recurrence", {})
            .get("pattern", {})
            .get("type"),
            "settings_recurrence_interval": definition.get("settings", {})
            .get("recurrence", {})
            .get("pattern", {})
            .get("interval"),
        }

    @staticmethod
    def _flatten_access_review_instance(definition_id: str, instance: dict) -> dict:
        """
        Flatten access review instance for CSV export

        :param str definition_id: ID of the access review definition
        :param dict instance: Instance data
        :return: Flattened instance data
        :rtype: dict
        """
        return {
            "definition_id": definition_id,
            "id": instance.get("id"),
            "status": instance.get("status"),
            "startDateTime": instance.get("startDateTime"),
            "endDateTime": instance.get("endDateTime"),
            "scope_type": instance.get("scope", {}).get(DATA_TYPE),
            "scope_query": instance.get("scope", {}).get("query"),
            "scope_inactiveDuration": instance.get("scope", {}).get("inactiveDuration"),
            "reviewers_count": len(instance.get("reviewers", [])),
            "fallbackReviewers_count": len(instance.get("fallbackReviewers", [])),
        }

    @staticmethod
    def _flatten_access_review_decision(definition_id: str, instance_id: str, decision: dict) -> dict:
        """
        Flatten access review decision for CSV export

        :param str definition_id: ID of the access review definition
        :param str instance_id: ID of the access review instance
        :param dict decision: Decision data
        :return: Flattened decision data
        :rtype: dict
        """
        return {
            "definition_id": definition_id,
            "instance_id": instance_id,
            "decision_id": decision.get("id"),
            "accessReviewId": decision.get("accessReviewId"),
            "decision": decision.get("decision"),
            "recommendation": decision.get("recommendation"),
            "justification": decision.get("justification"),
            "reviewedDateTime": decision.get("reviewedDateTime"),
            "appliedDateTime": decision.get("appliedDateTime"),
            "applyResult": decision.get("applyResult"),
            "principalLink": decision.get("principalLink"),
            "resourceLink": decision.get("resourceLink"),
            "reviewedBy_id": decision.get("reviewedBy", {}).get("id"),
            "reviewedBy_displayName": decision.get("reviewedBy", {}).get("displayName"),
            "reviewedBy_userPrincipalName": decision.get("reviewedBy", {}).get("userPrincipalName"),
            "appliedBy_id": decision.get("appliedBy", {}).get("id"),
            "appliedBy_displayName": decision.get("appliedBy", {}).get("displayName"),
            "appliedBy_userPrincipalName": decision.get("appliedBy", {}).get("userPrincipalName"),
            "target_type": decision.get("target", {}).get(DATA_TYPE),
            "target_userId": decision.get("target", {}).get("userId"),
            "target_userDisplayName": decision.get("target", {}).get("userDisplayName"),
            "target_userPrincipalName": decision.get("target", {}).get("userPrincipalName"),
            "principal_type": decision.get("principal", {}).get(DATA_TYPE),
            "principal_id": decision.get("principal", {}).get("id"),
            "principal_displayName": decision.get("principal", {}).get("displayName"),
            "principal_userPrincipalName": decision.get("principal", {}).get("userPrincipalName"),
        }

    # ── Azure Container Registry (ACR) methods ──

    def list_acr_registries(self, acr_name: Optional[str] = None) -> list[dict]:
        """
        List Azure Container Registry registries in the subscription.

        :param Optional[str] acr_name: If provided, filter to a single registry by name
        :return: List of ACR registry resource dicts
        :rtype: list[dict]
        """
        base = DefenderVariables.defenderBaseUrl or "https://management.azure.com"
        sub_id = DefenderVariables.azureCloudSubscriptionId
        url = (
            f"{base}/subscriptions/{sub_id}"
            f"/providers/Microsoft.ContainerRegistry/registries"
            f"?api-version={ACR_ARM_API_VERSION}"
        )
        logger.info("Listing ACR registries in subscription %s...", sub_id)
        registries = self.get_items_from_azure(url=url)
        if acr_name:
            registries = [r for r in registries if r.get("name", "").lower() == acr_name.lower()]
            if not registries:
                error_and_exit(f"ACR registry '{acr_name}' not found in subscription {sub_id}.")
        logger.info("Found %d ACR registr%s.", len(registries), "y" if len(registries) == 1 else "ies")
        return registries

    def get_acr_access_token(self, login_server: str) -> str:
        """
        Exchange the ARM bearer token for an ACR data-plane access token.

        Uses the OAuth2 token exchange flow:
        1. POST /oauth2/exchange  (ARM token -> ACR refresh token)
        2. POST /oauth2/token     (refresh token -> scoped access token)

        :param str login_server: The ACR login server (e.g. myregistry.azurecr.io)
        :return: ACR access token string
        :rtype: str
        """
        arm_token = self.headers.get("Authorization", "").replace("Bearer ", "")
        tenant_id = DefenderVariables.azureCloudTenantId

        exchange_url = f"https://{login_server}/oauth2/exchange"
        exchange_data = {
            "grant_type": "access_token",
            "service": login_server,
            "tenant": tenant_id,
            "access_token": arm_token,
        }
        exchange_resp = self.api.post(
            url=exchange_url,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data=exchange_data,
        )
        if exchange_resp.status_code != 200:
            error_and_exit(
                f"Failed to exchange ARM token for ACR refresh token on {login_server}.\n"
                f"{exchange_resp.status_code}: {exchange_resp.text}"
            )
        refresh_token = exchange_resp.json().get("refresh_token")

        token_url = f"https://{login_server}/oauth2/token"
        token_data = {
            "grant_type": "refresh_token",
            "service": login_server,
            "refresh_token": refresh_token,
            "scope": "registry:catalog:* repository:*:pull",
        }
        token_resp = self.api.post(
            url=token_url,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data=token_data,
        )
        if token_resp.status_code != 200:
            error_and_exit(
                f"Failed to obtain ACR access token from {login_server}.\n{token_resp.status_code}: {token_resp.text}"
            )
        acr_token = token_resp.json().get("access_token")
        logger.info("Successfully obtained ACR access token for %s.", login_server)
        return acr_token

    def list_acr_repositories(self, login_server: str, acr_token: str) -> list[str]:
        """
        List all repositories in an ACR registry using the data-plane API.

        :param str login_server: The ACR login server
        :param str acr_token: ACR data-plane access token
        :return: List of repository name strings
        :rtype: list[str]
        """
        url = f"https://{login_server}/acr/v1/_catalog"
        headers = {"Authorization": f"Bearer {acr_token}"}
        all_repos: list[str] = []

        while url:
            response = self.api.get(url=url, headers=headers)
            if response.status_code != 200:
                error_and_exit(
                    f"Failed to list repositories from {login_server}.\n{response.status_code}: {response.text}"
                )
            data = response.json()
            all_repos.extend(data.get("repositories") or [])
            url = data.get("link")
            if url and not url.startswith("http"):
                url = f"https://{login_server}{url}"

        logger.info("Found %d repositor%s in %s.", len(all_repos), "y" if len(all_repos) == 1 else "ies", login_server)
        return all_repos

    def list_acr_tags(self, login_server: str, repository: str, acr_token: str) -> list[dict]:
        """
        List all tags for a repository in an ACR registry.

        :param str login_server: The ACR login server
        :param str repository: Repository name
        :param str acr_token: ACR data-plane access token
        :return: List of tag detail dicts (name, digest, createdTime, etc.)
        :rtype: list[dict]
        """
        url = f"https://{login_server}/acr/v1/{repository}/_tags?orderby=timedesc"
        headers = {"Authorization": f"Bearer {acr_token}"}
        all_tags: list[dict] = []

        while url:
            response = self.api.get(url=url, headers=headers)
            if response.status_code != 200:
                logger.warning("Failed to list tags for %s/%s: %s", login_server, repository, response.text)
                break
            data = response.json()
            all_tags.extend(data.get("tags") or [])
            url = data.get("link")
            if url and not url.startswith("http"):
                url = f"https://{login_server}{url}"

        logger.info("Found %d tag(s) for %s in %s.", len(all_tags), repository, login_server)
        return all_tags
