#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tenable commands for the RegScale CLI.

This module provides Click command definitions for interacting with Tenable.io and Tenable SC.
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Tuple

import click
from requests.exceptions import RequestException

from regscale.core.app.utils.app_utils import (
    check_file_path,
    check_license,
    get_current_datetime,
    save_data_to,
    tqdm,
)
from regscale.integrations.commercial.nessus.nessus_utils import get_cpe_file
from regscale.integrations.commercial.nessus.scanner import NessusIntegration
from regscale.integrations.commercial.tenablev2.authenticate import gen_tio, gen_tsc
from regscale.integrations.commercial.tenablev2.cis_scanner import (
    TenableIOCISChecklistIntegration,
    TenableSCCISChecklistIntegration,
)
from regscale.integrations.commercial.tenablev2.constants import ARTIFACTS_DIR
from regscale.integrations.commercial.tenablev2.jsonl_scanner import (
    TenableSCJsonlScanner,
)
from regscale.integrations.commercial.tenablev2.sc_scanner import SCIntegration
from regscale.integrations.commercial.tenablev2.variables import TenableVariables
from regscale.models import regscale_id, regscale_ssp_id
from regscale.models.app_models.click import (
    file_types,
    hidden_file_path,
    save_output_to,
    ssp_or_component_id,
)
from regscale.models.app_models.orchestration_options import orchestration_options
from regscale.models.regscale_models import SecurityPlan

logger = logging.getLogger("regscale")
artifacts_dir = ARTIFACTS_DIR


# Define a helper function for gen_client to replace the original one
def gen_client():
    """
    Generate the appropriate Tenable client based on configuration.

    :return: Either a TenableIO or TenableSC client
    """
    return gen_tsc()  # Default to TenableSC for now


@click.group(name="tenable", help="Tenable commands.")
def tenable():
    """Tenable commands."""
    pass


@tenable.group(name="sc")
def sc():
    """Tenable SC commands."""
    pass


@tenable.group(name="io")
def io():
    """Tenable.io commands."""
    pass


@tenable.group(help="Import Nessus scans and assets to RegScale.")
def nessus():
    """Operations for Nessus scanner files."""
    pass


def validate_tags(ctx: click.Context, param: click.Option, value: str) -> List[Tuple[str, str]]:
    """
    Validate the tuple elements.

    :param click.Context ctx: Click context
    :param click.Option param: Click option
    :param str value: A string value to parse and validate
    :return: Tuple of validated values
    :rtype: List[Tuple[str,str]]
    :raise ValueError: If the value is not in the correct format
    """
    if not value:
        return []

    tuple_list = []
    for item in value.split(","):
        parts = [part for part in item.strip().split(":") if part]
        if len(parts) != 2:
            raise ValueError(f"""Invalid format: "{item}". Expected 'key:value'""")
        tuple_list.append((parts[0], parts[1]))

    return tuple_list


@io.command(name="info")
def io_info():
    """Display information about the configured Tenable.io instance."""
    click.echo("Tenable.io Configuration Information")

    try:
        client = gen_tio()

        # Get scanner information
        scanner_info = client.scanners.details()

        # Get user information
        user_info = client.session.details()

        # Display information
        click.echo(f"URL: {TenableVariables.tenableUrl}")
        click.echo(f"User: {user_info.get('username', 'Unknown')}")
        click.echo(f"Username: {user_info.get('email', 'Unknown')}")
        click.echo(f"Scanner Count: {len(scanner_info)}")

        # Display scanner information
        if scanner_info:
            click.echo("\nScanner Information:")
            for scanner in scanner_info:
                click.echo(f"  Name: {scanner.get('name', 'Unknown')}")
                click.echo(f"  Status: {scanner.get('status', 'Unknown')}")
                click.echo("")

    except Exception as e:
        logger.error(f"Error getting Tenable.io information: {e}", exc_info=True)
        click.echo("Error connecting to Tenable.io. Please check your configuration.")


@io.command(name="sync_assets")
@regscale_ssp_id(help="RegScale will create and update assets as children of this security plan.")
@click.option(
    "--tags",
    type=str,
    help="Filter assets by tags (format: 'key:value,key2:value2').",
    callback=validate_tags,
    required=False,
)
@orchestration_options()
def io_sync_assets(
    regscale_ssp_id: int,
    tags: List[Tuple[str, str]] = None,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """Sync assets from Tenable.io to RegScale."""
    click.echo("Starting Tenable.io asset synchronization...")

    try:
        from regscale.integrations.commercial.tenablev2.scanner import (
            TenableIntegration,
        )

        integration = TenableIntegration(plan_id=regscale_ssp_id)
        integration.sync_assets(plan_id=regscale_ssp_id, tags=tags, dry_run=dry_run, offset=offset, limit=limit)

        click.echo("Tenable.io asset synchronization complete.")
    except Exception as e:
        logger.error(f"Error syncing assets from Tenable.io: {e}", exc_info=True)


@io.command(name="sync_findings")
@regscale_ssp_id(help="RegScale will create findings as children of this security plan.")
@click.option(
    "--tags",
    type=str,
    help="Filter assets by tags (format: 'key:value,key2:value2').",
    callback=validate_tags,
    required=False,
)
@click.option(
    "--severity",
    type=click.Choice(["critical", "high", "medium", "low", "all"], case_sensitive=False),
    default="all",
    help="Filter findings by severity.",
    required=False,
)
@click.option(
    "--scan_date",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="The scan date of the findings.",
    required=False,
)
@orchestration_options()
def io_sync_findings(
    regscale_ssp_id: int,
    tags: List[Tuple[str, str]] = None,
    severity: str = "all",
    scan_date: datetime = None,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """Sync vulnerability findings from Tenable.io to RegScale."""
    click.echo("Starting Tenable.io finding synchronization...")

    try:
        from regscale.integrations.commercial.tenablev2.scanner import (
            TenableIntegration,
        )

        integration = TenableIntegration(plan_id=regscale_ssp_id, scan_date=scan_date)
        integration.sync_findings(
            plan_id=regscale_ssp_id, severity=severity, tags=tags, dry_run=dry_run, offset=offset, limit=limit
        )

        click.echo("Tenable.io finding synchronization complete.")
    except Exception as e:
        logger.error(f"Error syncing findings from Tenable.io: {e}", exc_info=True)


@io.command(name="export_assets")
@save_output_to()
@file_types([".json", ".csv", ".xlsx"])
@click.option(
    "--tags",
    type=str,
    help="Filter assets by tags (format: 'key:value,key2:value2').",
    callback=validate_tags,
    required=False,
)
def export_io_assets(save_output_to: Path, file_type: str, tags: List[Tuple[str, str]] = None):
    """Export assets from Tenable.io to a .json, .csv or .xlsx file."""
    click.echo("Exporting Tenable.io assets...")

    try:
        client = gen_tio()

        # Create artifacts directory if not exists
        Path(artifacts_dir).mkdir(exist_ok=True, parents=True)
        current_datetime = datetime.now().strftime("%Y%m%d%H")
        temp_file = Path(artifacts_dir) / Path(f"tenable_assets_{current_datetime}.json")

        # Fetch assets
        logger.info("Fetching Tenable.io assets...")
        assets = []
        assets_iterator = client.exports.assets(tags=tags) if tags else client.exports.assets()
        i = 0

        with open(temp_file, "w") as f:
            for i, asset in enumerate(assets_iterator, 1):
                f.write(json.dumps(asset) + "\n")
                assets.append(asset)
                if i % 100 == 0:
                    logger.info(f"Fetched {i} assets")

        logger.info(f"Total assets fetched: {i}")

        # Set the output file name
        file_name = f"tenable_io_assets_{get_current_datetime('%m%d%Y')}"
        output_file = Path(save_output_to) / f"{file_name}{file_type}"

        # Save the data to the selected file format
        save_data_to(
            file=output_file,
            data=assets,
        )

        click.echo(f"Tenable.io assets exported to {output_file}")
    except Exception as e:
        logger.error(f"Error exporting assets from Tenable.io: {e}", exc_info=True)


@io.command(name="export_compliance")
@save_output_to()
@file_types([".json", ".csv", ".xlsx"])
@click.option(
    "--asset-filter-file",
    type=click.Path(exists=True),
    help="JSON file mapping asset IDs to filter by (keys are used as asset filter list).",
    required=False,
)
@click.option(
    "--compliance-results",
    type=click.Choice(["PASSED", "FAILED", "ALL"], case_sensitive=True),
    default="ALL",
    help="Filter compliance results by status.",
    required=False,
)
@click.option(
    "--days",
    type=click.INT,
    default=30,
    help="Number of days to look back for compliance data (default: 30).",
    required=False,
)
def export_io_compliance(
    save_output_to: Path,
    file_type: str,
    asset_filter_file: str = None,
    compliance_results: str = "ALL",
    days: int = 30,
):
    """Export compliance scans from Tenable.io to a .json, .csv or .xlsx file."""
    click.echo("Exporting Tenable.io compliance scans...")

    try:
        client = gen_tio()

        # Create artifacts directory if not exists
        Path(artifacts_dir).mkdir(exist_ok=True, parents=True)
        current_datetime = datetime.now().strftime("%Y%m%d%H")
        temp_file = Path(artifacts_dir) / f"tenable_compliance_{current_datetime}.json"

        # Build export parameters
        export_params = {}

        # Apply asset filter if provided
        if asset_filter_file:
            with open(asset_filter_file) as f:
                asset_map = json.load(f)
            filtered_assets = list(asset_map.keys())
            logger.info("Filtering by %d assets from %s", len(filtered_assets), asset_filter_file)
            export_params["asset"] = filtered_assets

        # Apply compliance result filter
        if compliance_results != "ALL":
            export_params["compliance_results"] = [compliance_results]
        else:
            export_params["compliance_results"] = ["PASSED", "FAILED"]

        # Apply date filter
        lookback_time = int((datetime.now() - timedelta(days=days)).timestamp())
        export_params["indexed_at"] = lookback_time

        # Fetch compliance data
        logger.info("Fetching Tenable.io compliance scans...")
        results = []
        assets_iterator = client.exports.compliance(**export_params)
        i = 0

        with open(temp_file, "w") as f:
            for i, item in enumerate(assets_iterator, 1):
                f.write(json.dumps(item) + "\n")
                results.append(item)
                if i % 100 == 0:
                    logger.info("Fetched %d compliance scans", i)

        logger.info("Total compliance scans fetched: %d", i)

        # Set the output file name
        file_name = f"tenable_io_compliance_{get_current_datetime('%m%d%Y')}"
        output_file = Path(save_output_to) / f"{file_name}{file_type}"

        # Save the data to the selected file format
        save_data_to(
            file=output_file,
            data=results,
        )

        click.echo(f"Tenable.io compliance scans exported to {output_file}")
    except Exception as e:
        logger.error("Error exporting compliance scans from Tenable.io: %s", e, exc_info=True)


@io.command(name="export_findings")
@save_output_to()
@file_types([".json", ".csv", ".xlsx"])
@click.option(
    "--severity",
    type=click.Choice(["critical", "high", "medium", "low", "all"], case_sensitive=False),
    default="all",
    help="Filter findings by severity.",
    required=False,
)
@click.option(
    "--days",
    type=click.INT,
    default=30,
    help="Number of days to look back for vulnerabilities (default: 30).",
    required=False,
)
def export_io_findings(save_output_to: Path, file_type: str, severity: str = "all", days: int = 30):
    """Export vulnerability findings from Tenable.io to a .json, .csv or .xlsx file."""
    click.echo("Exporting Tenable.io vulnerability findings...")

    try:
        client = gen_tio()

        # Create artifacts directory if not exists
        Path(artifacts_dir).mkdir(exist_ok=True, parents=True)
        current_datetime = datetime.now().strftime("%Y%m%d%H")
        temp_file = Path(artifacts_dir) / Path(f"tenable_findings_{current_datetime}.json")

        # Calculate lookback time
        lookback_time = int((datetime.now() - timedelta(days=days)).timestamp())

        # Set severity filter
        severity_list = ["low", "medium", "high", "critical"]
        if severity != "all":
            severity_list = [severity.lower()]

        # Fetch vulnerabilities
        logger.info("Fetching Tenable.io vulnerability findings...")
        vulns = []

        vuln_iterator = client.exports.vulns(last_found=lookback_time, severity=severity_list)

        i = 0
        with open(temp_file, "w") as f:
            for i, vuln in enumerate(vuln_iterator, 1):
                f.write(json.dumps(vuln) + "\n")
                vulns.append(vuln)
                if i % 100 == 0:
                    logger.info(f"Fetched {i} findings")

        logger.info(f"Total findings fetched: {i}")

        # Set the output file name
        file_name = f"tenable_io_findings_{get_current_datetime('%m%d%Y')}"
        output_file = Path(f"{save_output_to}/{file_name}{file_type}")

        # Save the data to the selected file format
        save_data_to(
            file=output_file,
            data=vulns,
        )

        click.echo(f"Tenable.io findings exported to {output_file}")
    except Exception as e:
        logger.error(f"Error exporting findings from Tenable.io: {e}", exc_info=True)


@nessus.command(name="import_nessus")
@click.option(
    "--folder_path",
    "-f",
    prompt="Enter the folder path of the Nessus files to process",
    help="RegScale will load the Nessus Scans",
    type=click.Path(exists=True),
)
@click.option(
    "--scan_date",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="The scan date of the file.",
    required=False,
)
@regscale_ssp_id()
def import_nessus(folder_path: click.Path, regscale_ssp_id: int, scan_date: datetime = None):
    """Import Nessus scans, vulnerabilities and assets to RegScale."""
    from regscale.validation.record import validate_regscale_object

    if not validate_regscale_object(regscale_ssp_id, "securityplans"):
        logger.warning("SSP #%i is not a valid RegScale Security Plan.", regscale_ssp_id)
        return

    click.echo("Starting Nessus import...")
    NessusIntegration.sync_assets(plan_id=regscale_ssp_id, path=folder_path)
    NessusIntegration.sync_findings(
        plan_id=regscale_ssp_id,
        path=folder_path,
        enable_finding_date_update=True,
        scan_date=scan_date,
    )
    click.echo("Nessus import complete.")


@nessus.command(name="update_cpe_dictionary")
def update_cpe_dictionary():
    """
    Manually update the CPE 2.2 dictionary from NIST.
    """
    click.echo("Updating CPE dictionary...")
    get_cpe_file(download=True)
    click.echo("CPE dictionary update complete.")


@sc.command(name="export_scans")
@save_output_to()
@file_types([".json", ".csv", ".xlsx"])
def export_scans(save_output_to: Path, file_type: str):
    """Export scans from Tenable Host to a .json, .csv or .xlsx file."""
    click.echo("Exporting Tenable SC scans...")

    # get the scan results
    results = get_usable_scan_list()

    # check if file path exists
    check_file_path(save_output_to)

    # set the file name
    file_name = f"tenable_scans_{get_current_datetime('%m%d%Y')}"

    # save the data as the selected file by the user
    save_data_to(
        file=Path(save_output_to) / f"{file_name}{file_type}",
        data=results,
    )

    click.echo(f"Tenable SC scans exported to {Path(save_output_to) / f'{file_name}{file_type}'}")


def get_usable_scan_list() -> List[dict]:
    """
    Get usable scans from Tenable Host.

    :return: List of scans from Tenable
    :rtype: list
    """
    results = []
    try:
        client = gen_client()
        results = client.scans.list()["usable"]
    except Exception as ex:
        logger.error(f"Error getting scan list: {ex}")
    return results


def get_detailed_scans(scan_list: Optional[List[dict]] = None) -> List[dict]:
    """
    Generate list of detailed scans.

    Warning: this action could take a long time to complete.

    :param list scan_list: List of scans from Tenable, defaults to None
    :raise SystemExit: If there is an error with the request
    :return: Detailed list of Tenable scans
    :rtype: list
    """
    client = gen_client()
    detailed_scans = []
    for scan in tqdm(scan_list, desc="Fetching detailed scans..."):
        try:
            det = client.scans.details(id=scan["id"])
            detailed_scans.append(det)
        except RequestException as ex:
            raise SystemExit(ex) from ex

    return detailed_scans


@sc.command(name="save_queries")
@save_output_to()
@file_types([".json", ".csv", ".xlsx"])
def save_queries(save_output_to: Path, file_type: str):
    """Get a list of query definitions and save them as a .json, .csv or .xlsx file."""
    click.echo("Exporting Tenable SC queries...")

    # get the queries from Tenable
    query_list = get_queries()

    # check if file path exists
    check_file_path(save_output_to)

    # set the file name
    file_name = f"tenable_queries_{get_current_datetime('%m%d%Y')}"

    # save the data as a file
    save_data_to(
        file=Path(save_output_to) / f"{file_name}{file_type}",
        data=query_list,
    )

    click.echo(f"Tenable SC queries exported to {Path(save_output_to) / f'{file_name}{file_type}'}")


def get_queries() -> List[dict]:
    """
    Get list of query definitions from Tenable SC.

    :return: List of queries from Tenable
    :rtype: list
    """
    tsc = gen_tsc()
    return tsc.queries.list()


@sc.command(name="query_vuln")
@click.option(
    "--query_id",
    type=click.INT,
    help="Tenable query ID to retrieve via API",
    prompt="Enter Tenable query ID",
    required=True,
)
@ssp_or_component_id()
@click.option(
    "--scan_date",
    "-sd",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="The scan date of the file.",
    required=False,
)
def query_vuln(query_id: int, regscale_ssp_id: int, component_id: int, scan_date: datetime = None):
    """Query Tenable SC vulnerabilities and sync assets to RegScale."""
    try:
        # Validate license
        check_license()

        click.echo("Starting Tenable SC vulnerability query...")

        # Use the SCIntegration class method to fetch vulnerabilities by query ID
        if component_id:
            sc_integration = SCIntegration(plan_id=component_id, scan_date=scan_date, is_component=True)
        elif regscale_ssp_id:
            sc_integration = SCIntegration(plan_id=regscale_ssp_id, scan_date=scan_date)
        else:
            raise click.UsageError(
                "You must provide either a --regscale_ssp_id or a --component_id to query Tenable vulnerabilities."
            )

        sc_integration.fetch_vulns_query(query_id=query_id)

        click.echo("Tenable SC vulnerability query complete.")
    except Exception as e:
        logger.error(f"Error querying Tenable SC vulnerabilities: {str(e)}", exc_info=True)
        click.echo(f"Error querying Tenable SC vulnerabilities: {str(e)}")


@sc.command(name="list_tags")
def sc_tags():
    """List the tags available in Tenable SC."""
    list_tags()


def list_tags() -> None:
    """
    List the tags from Tenable SC.
    """
    tags = get_tags()
    for tag in tags:
        click.echo(f"{tag['id']}: {tag['name']} ({tag['description']})")


def get_tags() -> list:
    """
    Get the list of tags from Tenable SC.

    :return: List of tags
    :rtype: list
    """
    try:
        tsc = gen_tsc()
        result = tsc.tags.list()
        return result.get("response", [])
    except Exception as ex:
        logger.error("Error getting tags: %s", ex)
        return []


def _validate_ssp(regscale_ssp_id: int, skip_validation: bool) -> bool:
    """
    Validate security plan ID.

    :param int regscale_ssp_id: The security plan ID to validate
    :param bool skip_validation: Whether to skip validation
    :return: True if validation passes or is skipped, False otherwise
    :rtype: bool
    """
    if skip_validation:
        click.echo("Skipping RegScale validation for development mode")
        return True

    ssp = SecurityPlan.get_object(object_id=regscale_ssp_id)
    if not ssp:
        click.echo(f"Error: No security plan with ID {regscale_ssp_id} exists.")
        return False
    return True


def _create_scanner(
    regscale_ssp_id: int,
    query_id: int,
    file_path: str,
    scan_date: datetime,
    batch_size: int,
    optimize_memory: bool,
    force_download: bool,
) -> TenableSCJsonlScanner:
    """
    Create and configure TenableSCJsonlScanner instance.

    :param int regscale_ssp_id: RegScale security plan ID
    :param int query_id: Tenable query ID
    :param str file_path: Path to existing data files
    :param datetime scan_date: Scan date
    :param int batch_size: Batch size for processing
    :param bool optimize_memory: Enable memory optimization
    :param bool force_download: Force download fresh data
    :return: Configured scanner instance
    :rtype: TenableSCJsonlScanner
    """
    return TenableSCJsonlScanner(
        plan_id=regscale_ssp_id,
        query_id=query_id,
        file_path=file_path,
        scan_date=scan_date.strftime("%Y-%m-%d") if scan_date else None,
        batch_size=batch_size,
        optimize_memory=optimize_memory,
        force_download=force_download,
    )


def _run_sync(
    scanner: TenableSCJsonlScanner,
    mapping_file: str,
    query_id: int,
    file_path: str,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
) -> None:
    """
    Execute the synchronization process.

    :param TenableSCJsonlScanner scanner: Scanner instance
    :param str mapping_file: Optional mapping file for transformer processing
    :param int query_id: Tenable query ID
    :param str file_path: Path to existing data files
    :param bool dry_run: If True, discover item counts without syncing
    :param Optional[int] offset: Skip this many items from the start
    :param Optional[int] limit: Process at most this many items
    """
    if mapping_file:
        click.echo("Using custom mapping file for transformer-based processing.")
        scanner.sync_with_transformer(mapping_file=mapping_file)
        return

    if query_id and not file_path:
        click.echo(f"Downloading data from Tenable SC using query ID: {query_id}")

    scanner.sync_assets_and_findings(dry_run=dry_run, offset=offset, limit=limit)


@sc.command(name="sync_jsonl")
@regscale_ssp_id()
@click.option(
    "--query_id",
    type=click.INT,
    help="Tenable query ID to retrieve via API. Either query_id or file_path must be provided.",
    required=False,
)
@click.option(
    "--scan_date",
    "-sd",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="The scan date of the file.",
    required=False,
)
@click.option(
    "--file_path",
    type=click.Path(exists=True),
    help="Path to existing Tenable SC data files to process instead of downloading from API. Either query_id or file_path must be provided.",
    required=False,
)
@click.option(
    "--batch_size",
    type=click.INT,
    help="Number of items to process in each batch for large datasets.",
    default=1000,
    show_default=True,
    required=False,
)
@click.option(
    "--optimize-memory",
    is_flag=True,
    help="Enable memory optimization to reduce RAM usage.",
    default=True,
    show_default=True,
)
@click.option(
    "--mapping_file",
    type=click.Path(exists=True),
    help="Optional custom mapping file for transformer-based processing.",
    required=False,
)
@click.option(
    "--skip-validation",
    is_flag=True,
    help="Skip RegScale object validation (use for development environments)",
    default=True,
)
@click.option(
    "--force-download",
    is_flag=True,
    help="Force download of fresh data from Tenable SC, ignoring any existing files.",
    default=False,
)
@orchestration_options()
def sc_sync_jsonl(
    regscale_ssp_id: int,
    query_id: int = None,
    scan_date: datetime = None,
    file_path: str = None,
    batch_size: int = 1000,
    optimize_memory: bool = True,
    mapping_file: str = None,
    skip_validation: bool = False,
    force_download: bool = False,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync Tenable SC query results to RegScale using the JSONL implementation.

    This command uses the JSONLScannerIntegration to process Tenable SC data,
    which provides better performance and memory efficiency for large datasets.

    The implementation includes efficient batch processing and optional
    transformer-based mapping of complex data fields.

    Vulnerabilities are fetched from Tenable SC using the specified query ID,
    or existing data files can be processed from the specified file path.

    Note: Either query_id or file_path must be provided.
    """
    if not _validate_ssp(regscale_ssp_id, skip_validation):
        return

    if not query_id and not file_path:
        click.echo("Error: Either --query_id or --file_path must be provided.")
        return

    click.echo("Starting Tenable SC sync with JSONL Scanner...")
    click.echo("This command uses efficient batch processing for optimal performance.")

    try:
        scanner = _create_scanner(
            regscale_ssp_id,
            query_id,
            file_path,
            scan_date,
            batch_size,
            optimize_memory,
            force_download,
        )
        _run_sync(scanner, mapping_file, query_id, file_path, dry_run=dry_run, offset=offset, limit=limit)
        click.echo("Tenable SC sync completed successfully.")
    except Exception as e:
        click.echo(f"Error: {str(e)}")
        logger.error(f"Error in Tenable SC JSONL sync: {str(e)}", exc_info=True)


# Command from existing commands.py
@tenable.command(name="sync_vulns")
@regscale_id(help="RegScale will create findings as children of this security plan.")
@click.option(
    "--query-id",
    type=click.INT,
    required=True,
    help="Tenable SC Query ID to retrieve vulnerability data from.",
    prompt="Enter Tenable SC Query ID",
)
def sync_vulns(regscale_id: int, query_id: int):
    """
    Sync vulnerabilities from Tenable SC to RegScale.

    Fetches vulnerability data from Tenable SC based on the specified query ID
    and syncs it to RegScale as findings under the specified security plan.
    """
    try:
        # Use the original SC scanner for direct API sync
        click.echo("Starting Tenable SC vulnerability sync...")
        scanner = SCIntegration(plan_id=regscale_id, scan_date=get_current_datetime())
        scanner.fetch_vulns_query(query_id=query_id)
        click.echo("Tenable SC vulnerability sync complete.")
    except Exception as e:
        logger.error(f"Error syncing Tenable SC vulnerabilities: {str(e)}", exc_info=True)
        click.echo(f"Error syncing Tenable SC vulnerabilities: {str(e)}")


@io.command(name="sync_compliance_controls")
@regscale_ssp_id()
@click.option(
    "--catalog_id",
    type=click.INT,
    help="The ID number from RegScale Catalog that the System Security Plan's controls belong to",
    prompt="Enter RegScale Catalog ID",
    required=True,
)
@click.option(
    "--framework",
    required=True,
    type=click.Choice(["800-53", "800-53r5", "CSF", "800-171"], case_sensitive=True),
    help="The framework to use. from Tenable.io frameworks MUST be the same RegScale Catalog of controls",
)
@hidden_file_path(help="The file path to load control data instead of fetching from Tenable.io")
def sync_compliance_data(
    regscale_ssp_id: int,
    catalog_id: int,
    framework: str,
    offline: Optional[Path] = None,
):
    """
    Sync the compliance data from Tenable.io to create control implementations for controls in frameworks.
    """
    from regscale.integrations.commercial.tenablev2.sync_compliance import (
        sync_compliance_data,
    )

    sync_compliance_data(
        ssp_id=regscale_ssp_id,
        catalog_id=catalog_id,
        framework=framework,
        offline=offline,
    )


@io.command(name="sync_cis_checklist")
@regscale_id(help="RegScale security plan ID to create CIS checklist findings under.")
@click.option(
    "--cis_level",
    type=click.Choice(["1", "2"]),
    default="1",
    help="CIS benchmark level to sync (1 or 2). Default: 1",
)
@click.option(
    "--audit_file_filter",
    type=click.STRING,
    default=None,
    help="Filter by audit file name pattern (e.g., 'CIS_Ubuntu_Linux').",
)
@click.option(
    "--tags",
    type=click.STRING,
    multiple=True,
    default=None,
    help="Filter by Tenable.io tags (can specify multiple times).",
)
def sync_cis_checklist_io(
    regscale_id: int,
    cis_level: str,
    audit_file_filter: Optional[str],
    tags: Optional[tuple],
):
    """
    Sync CIS benchmark compliance checklist from Tenable.io to RegScale.

    This command fetches CIS benchmark compliance data from Tenable.io
    and creates checklist findings in RegScale for failed or warning compliance checks.

    Examples:
        # Sync CIS Level 1 findings
        regscale tenable io sync_cis_checklist --regscale-id 123

        # Sync CIS Level 2 findings for Ubuntu
        regscale tenable io sync_cis_checklist --regscale-id 123 --cis-level 2 --audit-file-filter "Ubuntu"

        # Sync with tag filtering
        regscale tenable io sync_cis_checklist --regscale-id 123 --tags production --tags linux
    """
    try:
        logger.info("Starting Tenable.io CIS checklist sync...")
        logger.info("CIS Level: %s", cis_level)
        if audit_file_filter:
            logger.info("Audit File Filter: %s", audit_file_filter)
        if tags:
            logger.info("Tags: %s", ", ".join(tags))

        # Initialize the CIS scanner
        scanner = TenableIOCISChecklistIntegration(
            plan_id=regscale_id,
            cis_level=cis_level,
            audit_file_filter=audit_file_filter,
            tags=list(tags) if tags else None,
        )

        # Fetch and sync findings
        findings_count = 0
        assets_count = 0

        for _ in scanner.fetch_findings():
            findings_count += 1

        for _ in scanner.fetch_assets():
            assets_count += 1

        logger.info("Synced %d CIS findings and %d assets", findings_count, assets_count)
        logger.info("Tenable.io CIS checklist sync completed successfully.")

    except Exception as e:
        logger.error("Error syncing Tenable.io CIS checklist: %s", str(e), exc_info=True)
        raise


@sc.command(name="sync_cis_checklist")
@regscale_id(help="RegScale security plan ID to create CIS checklist findings under.")
@click.option(
    "--query_id",
    type=click.INT,
    required=True,
    help="Tenable SC Query ID to retrieve CIS compliance data from.",
    prompt="Enter Tenable SC Query ID for CIS data",
)
@click.option(
    "--cis_level",
    type=click.Choice(["1", "2"]),
    default="1",
    help="CIS benchmark level to sync (1 or 2). Default: 1",
)
def sync_cis_checklist_sc(regscale_id: int, query_id: int, cis_level: str):
    """
    Sync CIS benchmark compliance checklist from Tenable SC to RegScale.

    This command fetches CIS benchmark compliance data from Tenable Security Center
    using an analysis query and creates checklist findings in RegScale.

    The query should be configured in Tenable SC to return CIS compliance plugin results.
    Common CIS plugin IDs: 21156, 24760

    Examples:
        # Sync CIS Level 1 findings from query 42
        regscale tenable sc sync_cis_checklist --regscale-id 123 --query-id 42

        # Sync CIS Level 2 findings
        regscale tenable sc sync_cis_checklist --regscale-id 123 --query-id 42 --cis-level 2
    """
    try:
        logger.info("Starting Tenable SC CIS checklist sync...")
        logger.info("Query ID: %d", query_id)
        logger.info("CIS Level: %s", cis_level)

        # Initialize the CIS scanner
        scanner = TenableSCCISChecklistIntegration(
            plan_id=regscale_id,
            query_id=query_id,
            cis_level=cis_level,
        )

        # Fetch and sync findings
        findings_count = 0
        assets_count = 0

        for _ in scanner.fetch_findings():
            findings_count += 1

        for _ in scanner.fetch_assets():
            assets_count += 1

        logger.info("Synced %d CIS findings and %d assets", findings_count, assets_count)
        logger.info("Tenable SC CIS checklist sync completed successfully.")

    except Exception as e:
        logger.error("Error syncing Tenable SC CIS checklist: %s", str(e), exc_info=True)
        raise


# Add exports at the end of the file
__all__ = [
    "tenable",
    "sc",
    "io",
    "nessus",
    "import_nessus",
    "sync_vulns",
    "sc_sync_jsonl",
    "sync_cis_checklist_io",
    "sync_cis_checklist_sc",
]
