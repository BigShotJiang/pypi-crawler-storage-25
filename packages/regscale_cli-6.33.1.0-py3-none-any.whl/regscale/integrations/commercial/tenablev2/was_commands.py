"""
Tenable WAS (Web Application Scanning) CLI commands.

Provides Click commands for syncing web application findings and assets
from Tenable.io WAS into RegScale.
"""

import logging
from datetime import datetime

import click

from regscale.models import regscale_ssp_id

logger = logging.getLogger("regscale")


WAS_HELP = """Tenable WAS (Web Application Scanning) commands.

These commands use the Tenable.io WAS export API and require Tenable.io
(cloud) credentials. If you are using Tenable Security Center with the
WAS add-on, WAS findings flow through SC's standard vulnerability data
and are already captured by 'regscale tenable sc' commands (sync_jsonl,
query_vuln).
"""


@click.group(name="was", help=WAS_HELP)
def was():
    """Tenable WAS (Web Application Scanning) commands."""


@was.command(name="sync_findings")
@regscale_ssp_id(help="RegScale will create findings as children of this security plan.")
@click.option(
    "--severity",
    type=click.Choice(["critical", "high", "medium", "low", "all"], case_sensitive=False),
    default="all",
    help="Filter findings by severity.",
    required=False,
)
@click.option(
    "--scan_date",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="The scan date of the findings.",
    required=False,
)
def was_sync_findings(regscale_ssp_id: int, severity: str = "all", scan_date: datetime = None):
    """Sync WAS vulnerability findings from Tenable.io to RegScale."""
    click.echo("Starting Tenable WAS finding synchronization...")

    try:
        from regscale.integrations.commercial.tenablev2.was_scanner import (
            TenableWASIntegration,
        )

        integration = TenableWASIntegration(plan_id=regscale_ssp_id, scan_date=scan_date)
        integration.sync_findings(plan_id=regscale_ssp_id, severity=severity)

        click.echo("Tenable WAS finding synchronization complete.")
    except Exception as e:
        logger.error("Error syncing WAS findings from Tenable.io: %s", e, exc_info=True)
        click.echo(f"Error syncing WAS findings: {e}")


@was.command(name="sync_apps")
@regscale_ssp_id(help="RegScale will create and update web app assets as children of this security plan.")
def was_sync_apps(regscale_ssp_id: int):
    """Sync web applications from Tenable WAS as assets to RegScale."""
    click.echo("Starting Tenable WAS app synchronization...")

    try:
        from regscale.integrations.commercial.tenablev2.was_scanner import (
            TenableWASIntegration,
        )

        integration = TenableWASIntegration(plan_id=regscale_ssp_id)
        integration.sync_assets(plan_id=regscale_ssp_id)

        click.echo("Tenable WAS app synchronization complete.")
    except Exception as e:
        logger.error("Error syncing WAS apps from Tenable.io: %s", e, exc_info=True)
        click.echo(f"Error syncing WAS apps: {e}")
