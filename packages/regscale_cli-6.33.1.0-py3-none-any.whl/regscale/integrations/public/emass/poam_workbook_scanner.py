#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eMASS POAM Workbook Scanner Integration.

This module provides import of POA&M data from eMASS Excel workbooks into RegScale
via the streaming batch create/update endpoint. It follows the same patterns as the
FedRAMP POAM scanner and supports both Rev4 and Rev5 eMASS POAM template formats.

The scanner auto-detects the template revision based on header column names and
adjusts column mapping accordingly for proper round-trip compatibility with the
RegScale export engine.

Rev4 vs Rev5 key differences:
    - Status column: "Status" (Rev4) vs "POA&M Status" (Rev5)
    - Completion date: embedded in status text (Rev4) vs separate column (Rev5)
    - Source column: "Source Identifying Vulnerability" (Rev4) vs "Identification Source" (Rev5)
    - Milestones: combined (Rev4) vs separate description/status/comments (Rev5)
    - Rev5 adds: POA&M Completion Date, Risk Accepted Expiration Date,
      Identification Source Details, Milestone Status/Comments/Dates

Usage:
    integration = EmassPoamWorkbookScanner(plan_id=123, file_path="/path/to/emass_poam.xlsm")
    stats = integration.process()
"""

import hashlib
import logging
import os
import re
from collections import deque
from typing import Any, Dict, Iterator, List, Optional, Tuple

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException
from openpyxl.workbook import Workbook
from openpyxl.worksheet.worksheet import Worksheet

from regscale.core.app.utils.app_utils import error_and_exit, get_current_datetime
from regscale.core.utils.date import date_str
from regscale.integrations.scanner.models import IntegrationFinding
from regscale.integrations.scanner_integration import issue_due_date
from regscale.models import IssueSeverity, regscale_models
from regscale.models.regscale_models.batch_options import IssueBatchOptions

logger = logging.getLogger("regscale")

# -------------------------------------------------------------------
# Batch & circuit-breaker configuration (mirrors FedRAMP scanner)
# -------------------------------------------------------------------
BATCH_SIZE = int(os.getenv("REGSCALE_POAM_BATCH_SIZE", "100"))
if not 1 <= BATCH_SIZE <= 1000:
    logger.warning("Invalid REGSCALE_POAM_BATCH_SIZE=%d (must be 1-1000). Using default 100.", BATCH_SIZE)
    BATCH_SIZE = 100

CIRCUIT_BREAKER_THRESHOLD = int(os.getenv("REGSCALE_CIRCUIT_BREAKER_THRESHOLD", "10"))
CIRCUIT_BREAKER_WINDOW_SIZE = 20
CIRCUIT_BREAKER_FAILURE_RATE = 0.5

# -------------------------------------------------------------------
# eMASS POAM workbook column constants (shared across Rev4/Rev5)
# -------------------------------------------------------------------
COL_POAM_ITEM_ID = "POA&M Item ID"
COL_CONTROL_VULN_DESC = "Control Vulnerability Description"
COL_CONTROLS_APS = "Controls / APs"
COL_OFFICE_ORG = "Office/Org"
COL_SECURITY_CHECKS = "Security Checks"
COL_RESOURCES_REQUIRED = "Resources Required"
COL_MILESTONE_ID = "Milestone ID"
COL_COMMENTS = "Comments"
COL_RAW_SEVERITY = "Raw Severity"
COL_DEVICES_AFFECTED = "Devices Affected"
COL_MITIGATIONS = "Mitigations"
COL_PREDISPOSING_CONDITIONS = "Predisposing Conditions"
COL_SEVERITY = "Severity"
COL_RELEVANCE_OF_THREAT = "Relevance of Threat"
COL_THREAT_DESCRIPTION = "Threat Description"
COL_LIKELIHOOD = "Likelihood"
COL_IMPACT = "Impact"
COL_IMPACT_DESC = "Impact Description"
COL_RESIDUAL_RISK = "Residual Risk Level"
COL_RECOMMENDATIONS = "Recommendations"
COL_RESULTING_RESIDUAL_RISK = "Resulting Residual Risk after Proposed Mitigations"

# Rev4-specific column names
COL_REV4_STATUS = "Status"
COL_REV4_SCHEDULED_COMPLETION = "Scheduled Completion Date"
COL_REV4_MILESTONES = "Milestone with Completion Dates"
COL_REV4_MILESTONE_CHANGES = "Milestone Changes"
COL_REV4_SOURCE_IDENT_VULN = "Source Identifying Vulnerability"

# Rev5-specific column names
COL_REV5_STATUS = "POA&M Status"
COL_REV5_SCHEDULED_COMPLETION = "POA&M Scheduled Completion Date"
COL_REV5_RISK_ACCEPTED_EXPIRATION = "POA&M Requested Risk Accepted Expiration Date"
COL_REV5_COMPLETION_DATE = "POA&M Completion Date"
COL_REV5_MILESTONE_DESC = "Milestone Description"
COL_REV5_MILESTONE_STATUS = "Milestone Status"
COL_REV5_MILESTONE_STATUS_COMMENTS = "Milestone Status Comments"
COL_REV5_MILESTONE_SCHED_COMPLETION = "Milestone Scheduled Completion Date"
COL_REV5_MILESTONE_COMPLETION = "Milestone Completion Date"
COL_REV5_IDENTIFICATION_SOURCE = "Identification Source"
COL_REV5_IDENTIFICATION_SOURCE_DETAILS = "Identification Source Details"

# Template revision identifiers
TEMPLATE_REV4 = "rev4"
TEMPLATE_REV5 = "rev5"

# Pre-compiled patterns
_CVE_PATTERN = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)
_COMPLETED_PATTERN = re.compile(r"Completed\s*(.*)", re.IGNORECASE)
_REGSCALE_ISSUE_ID_PATTERN = re.compile(r"#(\d+)")

# Severity mapping: eMASS RAR → RegScale IssueSeverity
SEVERITY_MAP = {
    "very high": IssueSeverity.Critical,
    "critical": IssueSeverity.Critical,
    "high": IssueSeverity.High,
    "moderate": IssueSeverity.Moderate,
    "medium": IssueSeverity.Moderate,
    "low": IssueSeverity.Low,
    "very low": IssueSeverity.Low,
    "informational": IssueSeverity.Low,
}

# Header row typically starts at row 7 in eMASS POAM templates (rows 1-6 are metadata)
DEFAULT_HEADER_ROW = 7
# Data starts one row after header
DEFAULT_DATA_START_ROW = DEFAULT_HEADER_ROW + 1
# Maximum consecutive blank rows before stopping
BLANK_ROW_THRESHOLD = 3


class EmassPoamWorkbookScanner:
    """
    Scanner for importing eMASS POAM workbooks into RegScale.

    This scanner parses eMASS-formatted Excel workbooks (.xlsm/.xlsx) and
    sends the data to RegScale's streaming batch create/update endpoint for
    efficient, deduplicated processing at scale.

    Features:
    - Memory-efficient read-only Excel mode for large workbooks
    - Streaming batch upload via ``Issue.batch_create_or_update()``
    - Configurable batch sizes for performance tuning
    - Circuit breaker to halt on sustained API failures
    - CVE extraction from Source Identifying Vulnerability column
    - Multi-asset row expansion (one finding per asset+CVE combo)
    - Idempotent: safe to re-run without creating duplicates

    Example::

        scanner = EmassPoamWorkbookScanner(
            plan_id=123,
            file_path="/path/to/emass_poam.xlsm",
        )
        stats = scanner.process()
        print(f"Created: {stats['created']}, Updated: {stats['updated']}, Errors: {stats['errors']}")
    """

    def __init__(
        self,
        plan_id: int,
        file_path: str,
        poam_sheet_name: Optional[str] = None,
        header_row: int = DEFAULT_HEADER_ROW,
        enable_mop_up: bool = False,
        dry_run: bool = False,
        issue_owner_id: Optional[str] = None,
    ) -> None:
        """
        Initialize the eMASS POAM workbook scanner.

        :param int plan_id: RegScale security plan ID to import POAMs into
        :param str file_path: Path to the eMASS POAM workbook (.xlsm or .xlsx)
        :param Optional[str] poam_sheet_name: Explicit sheet name to parse.
            If None, auto-detects the POA&M sheet.
        :param int header_row: 1-based row number containing column headers (default: 7)
        :param bool enable_mop_up: If True, close issues not present in the workbook
        :param bool dry_run: If True, parse and validate only — do not send to API
        :param Optional[str] issue_owner_id: User ID to assign as issue owner
        """
        if not file_path:
            error_and_exit("file_path is required for eMASS POAM workbook import.")

        self.plan_id = plan_id
        self.file_path = file_path
        self.poam_sheet_name = poam_sheet_name
        self.header_row = header_row
        self.enable_mop_up = enable_mop_up
        self.dry_run = dry_run
        self.issue_owner_id = issue_owner_id

        # Workbook state
        self.workbook: Optional[Workbook] = None
        self._column_indices: Dict[str, int] = {}
        self.template_revision: str = TEMPLATE_REV4  # Auto-detected during header scan

        # Stats tracking
        self.stats: Dict[str, Any] = {
            "total_rows": 0,
            "parsed_findings": 0,
            "created": 0,
            "updated": 0,
            "skipped": 0,
            "errors": 0,
            "blank_rows": 0,
            "error_details": [],
        }

        # Load workbook
        self._load_workbook()

    # ------------------------------------------------------------------
    # Workbook loading & sheet detection
    # ------------------------------------------------------------------

    def _load_workbook(self) -> None:
        """Load the Excel workbook in read-only mode for memory efficiency."""
        try:
            self.workbook = load_workbook(
                filename=self.file_path,
                data_only=True,
                read_only=True,
            )
            logger.info("Loaded eMASS POAM workbook: %s", self.file_path)
        except FileNotFoundError:
            error_and_exit(f"File not found: {self.file_path}")
        except InvalidFileException as e:
            error_and_exit(f"Invalid Excel file: {self.file_path} — {e}")

    def _detect_poam_sheet(self) -> Optional[Worksheet]:
        """
        Auto-detect the POA&M data sheet in the workbook.

        Looks for sheets matching common eMASS POAM naming conventions:
        - "POA&M" (exact or partial match)
        - "POAM" (without ampersand)
        - Sheets containing "POA&M Items"

        :return: The worksheet or None if not found
        :rtype: Optional[Worksheet]
        """
        if self.poam_sheet_name:
            if self.poam_sheet_name in self.workbook.sheetnames:
                return self.workbook[self.poam_sheet_name]
            logger.error("Sheet '%s' not found in workbook.", self.poam_sheet_name)
            return None

        # Auto-detect: try common eMASS POAM sheet name patterns
        poam_patterns = [
            r"POA&M",
            r"POAM",
            r"POA&M\s*Items",
        ]
        for sheet_name in self.workbook.sheetnames:
            for pattern in poam_patterns:
                if re.search(pattern, sheet_name, re.IGNORECASE):
                    logger.info("Auto-detected POAM sheet: '%s'", sheet_name)
                    return self.workbook[sheet_name]

        # Fallback: use the first sheet if only one exists
        if len(self.workbook.sheetnames) == 1:
            logger.warning(
                "No POA&M sheet detected. Using the only sheet: '%s'",
                self.workbook.sheetnames[0],
            )
            return self.workbook[self.workbook.sheetnames[0]]

        logger.error(
            "Could not auto-detect POAM sheet. Available sheets: %s. Use --poam-sheet-name to specify.",
            self.workbook.sheetnames,
        )
        return None

    # ------------------------------------------------------------------
    # Header detection & column mapping
    # ------------------------------------------------------------------

    def _build_column_indices(self, ws: Worksheet) -> bool:
        """
        Find the header row, build a column-name → index mapping, and detect template revision.

        Scans rows around ``self.header_row`` to locate the header.
        The eMASS template typically has headers at row 7.

        After finding headers, auto-detects Rev4 vs Rev5 based on the presence
        of Rev5-specific columns like "POA&M Status" or "Identification Source".

        :param Worksheet ws: The worksheet to scan
        :return: True if headers were found and mapped
        :rtype: bool
        """
        # Search a range around the expected header row
        search_range = range(max(1, self.header_row - 3), self.header_row + 5)

        for row_num in search_range:
            row_cells = list(ws.iter_rows(min_row=row_num, max_row=row_num, values_only=True))
            if not row_cells:
                continue

            row = row_cells[0]
            # Look for a row containing recognizable eMASS column names
            cell_values = [str(c).strip() if c else "" for c in row]

            # Check for key indicator columns (works for both Rev4 and Rev5)
            # Note: "POA&M" lowered is "poa&m" so check both "poam" and "poa&m"
            has_poam_id = any(("poam" in v.lower() or "poa&m" in v.lower()) and "id" in v.lower() for v in cell_values)
            has_severity = any("severity" in v.lower() or "raw severity" in v.lower() for v in cell_values)
            has_status = any("status" in v.lower() for v in cell_values)

            if has_poam_id or (has_severity and has_status):
                self._column_indices = {cell_values[i]: i for i in range(len(cell_values)) if cell_values[i]}
                self.header_row = row_num

                # Detect template revision from column names
                self.template_revision = self._detect_template_revision()

                logger.info(
                    "Found eMASS POAM headers at row %d (%s). Mapped %d columns.",
                    row_num,
                    self.template_revision.upper(),
                    len(self._column_indices),
                )
                logger.debug("Column mapping: %s", list(self._column_indices.keys()))
                return True

        logger.error(
            "Could not find eMASS POAM headers near row %d. Check the workbook format or specify --header-row.",
            self.header_row,
        )
        return False

    def _detect_template_revision(self) -> str:
        """
        Detect whether the workbook uses the Rev4 or Rev5 template format.

        Rev5 is identified by the presence of Rev5-specific column names:
        - "POA&M Status" (Rev5) vs "Status" (Rev4)
        - "Identification Source" (Rev5) vs "Source Identifying Vulnerability" (Rev4)
        - "POA&M Completion Date" (Rev5-only column)

        :return: TEMPLATE_REV4 or TEMPLATE_REV5
        :rtype: str
        """
        col_names_lower = {name.lower() for name in self._column_indices}

        rev5_indicators = [
            "poa&m status",
            "identification source",
            "poa&m completion date",
            "milestone description",
        ]
        rev5_matches = sum(1 for indicator in rev5_indicators if indicator in col_names_lower)

        if rev5_matches >= 2:
            return TEMPLATE_REV5

        return TEMPLATE_REV4

    def _get_col_index(self, *column_names: str) -> Optional[int]:
        """
        Get the column index for a column name, trying multiple aliases.

        eMASS templates can vary in column naming (e.g., "Raw Severity Value"
        vs "Raw Severity" vs "Severity"). This method tries each alias in order.

        :param column_names: One or more column name aliases to try
        :return: Column index (0-based) or None
        :rtype: Optional[int]
        """
        for name in column_names:
            if name in self._column_indices:
                return self._column_indices[name]
            # Try case-insensitive partial match
            for col_name, idx in self._column_indices.items():
                if name.lower() in col_name.lower():
                    return idx
        return None

    # ------------------------------------------------------------------
    # Row parsing
    # ------------------------------------------------------------------

    def _extract_row_values(self, row: tuple) -> Dict[str, Any]:
        """
        Extract all cell values from a row into a named dictionary.

        Uses the column index mapping to convert positional cell values
        into a named dictionary for clean downstream access. Handles both
        Rev4 and Rev5 column naming conventions via aliases.

        :param tuple row: Tuple of cell values from openpyxl
        :return: Dictionary of field_name → cell_value
        :rtype: Dict[str, Any]
        """

        def _safe_get(idx: Optional[int]) -> str:
            """Safely get a string value from the row by index."""
            if idx is None or idx >= len(row):
                return ""
            val = row[idx]
            if val is None:
                return ""
            return str(val).strip()

        is_rev5 = self.template_revision == TEMPLATE_REV5

        # Status: "POA&M Status" (Rev5) or "Status" (Rev4)
        status_val = _safe_get(
            self._get_col_index(COL_REV5_STATUS, COL_REV4_STATUS)
            if is_rev5
            else self._get_col_index(COL_REV4_STATUS, COL_REV5_STATUS)
        )

        # Scheduled completion: "POA&M Scheduled Completion Date" (Rev5) or "Scheduled Completion Date" (Rev4)
        sched_completion = _safe_get(
            self._get_col_index(COL_REV5_SCHEDULED_COMPLETION, COL_REV4_SCHEDULED_COMPLETION)
            if is_rev5
            else self._get_col_index(COL_REV4_SCHEDULED_COMPLETION, COL_REV5_SCHEDULED_COMPLETION)
        )

        # Source identification: "Identification Source" (Rev5) or "Source Identifying Vulnerability" (Rev4)
        source_ident = _safe_get(
            self._get_col_index(COL_REV5_IDENTIFICATION_SOURCE, COL_REV4_SOURCE_IDENT_VULN)
            if is_rev5
            else self._get_col_index(COL_REV4_SOURCE_IDENT_VULN, COL_REV5_IDENTIFICATION_SOURCE)
        )

        values = {
            "poam_id": _safe_get(self._get_col_index(COL_POAM_ITEM_ID, "POAM Item ID", "POAM ID")),
            "description": _safe_get(self._get_col_index(COL_CONTROL_VULN_DESC, "Control Vulnerability Description")),
            "controls_aps": _safe_get(
                self._get_col_index(COL_CONTROLS_APS, "Controls / APs", "Security Control Number")
            ),
            "office_org": _safe_get(self._get_col_index(COL_OFFICE_ORG, "Office/Org")),
            "security_checks": _safe_get(
                self._get_col_index(COL_SECURITY_CHECKS, "Security Checks", "Assessment Procedures")
            ),
            "resources_required": _safe_get(self._get_col_index(COL_RESOURCES_REQUIRED, "Resources Required")),
            "scheduled_completion": sched_completion,
            "milestone_id": _safe_get(self._get_col_index(COL_MILESTONE_ID, "Milestone ID")),
            "source_ident_vuln": source_ident,
            "status": status_val,
            "comments": _safe_get(self._get_col_index(COL_COMMENTS, "Comments")),
            "raw_severity": _safe_get(self._get_col_index(COL_RAW_SEVERITY, "Raw Severity", "Raw Severity Value")),
            "devices_affected": _safe_get(
                self._get_col_index(COL_DEVICES_AFFECTED, "Devices Affected", "Asset Identifier")
            ),
            "mitigations": _safe_get(self._get_col_index(COL_MITIGATIONS, "Mitigations", "Mitigations (in-house")),
            "predisposing_conditions": _safe_get(
                self._get_col_index(COL_PREDISPOSING_CONDITIONS, "Predisposing Conditions")
            ),
            "severity": _safe_get(self._get_col_index(COL_SEVERITY, "Severity")),
            "relevance_of_threat": _safe_get(self._get_col_index(COL_RELEVANCE_OF_THREAT, "Relevance of Threat")),
            "threat_description": _safe_get(self._get_col_index(COL_THREAT_DESCRIPTION, "Threat Description")),
            "likelihood": _safe_get(self._get_col_index(COL_LIKELIHOOD, "Likelihood")),
            "impact": _safe_get(self._get_col_index(COL_IMPACT, "Impact")),
            "impact_desc": _safe_get(self._get_col_index(COL_IMPACT_DESC, "Impact Description")),
            "residual_risk": _safe_get(self._get_col_index(COL_RESIDUAL_RISK, "Residual Risk Level", "Residual Risk")),
            "recommendations": _safe_get(self._get_col_index(COL_RECOMMENDATIONS, "Recommendations")),
            "resulting_residual_risk": _safe_get(
                self._get_col_index(COL_RESULTING_RESIDUAL_RISK, "Resulting Residual Risk after Proposed Mitigations")
            ),
        }

        if is_rev5:
            # Rev5-specific columns
            values["poam_completion_date"] = _safe_get(
                self._get_col_index(COL_REV5_COMPLETION_DATE, "POA&M Completion Date")
            )
            values["risk_accepted_expiration"] = _safe_get(self._get_col_index(COL_REV5_RISK_ACCEPTED_EXPIRATION))
            values["identification_source_details"] = _safe_get(
                self._get_col_index(COL_REV5_IDENTIFICATION_SOURCE_DETAILS, "Identification Source Details")
            )
            values["milestone_description"] = _safe_get(
                self._get_col_index(COL_REV5_MILESTONE_DESC, "Milestone Description")
            )
            values["milestone_status"] = _safe_get(self._get_col_index(COL_REV5_MILESTONE_STATUS, "Milestone Status"))
            values["milestone_status_comments"] = _safe_get(
                self._get_col_index(COL_REV5_MILESTONE_STATUS_COMMENTS, "Milestone Status Comments")
            )
            values["milestone_sched_completion"] = _safe_get(
                self._get_col_index(COL_REV5_MILESTONE_SCHED_COMPLETION, "Milestone Scheduled Completion Date")
            )
            values["milestone_completion_date"] = _safe_get(
                self._get_col_index(COL_REV5_MILESTONE_COMPLETION, "Milestone Completion Date")
            )
        else:
            # Rev4-specific columns
            values["milestones"] = _safe_get(
                self._get_col_index(COL_REV4_MILESTONES, "Milestone with Completion Dates", "Milestones")
            )
            values["milestone_changes"] = _safe_get(
                self._get_col_index(COL_REV4_MILESTONE_CHANGES, "Milestone Changes")
            )
            # Rev4 defaults for Rev5 fields
            values["poam_completion_date"] = ""
            values["identification_source_details"] = ""

        return values

    def _parse_status(self, status_str: str, poam_completion_date: str = "") -> Tuple[str, Optional[str]]:
        """
        Parse eMASS status string into RegScale status and optional completion date.

        Handles both Rev4 and Rev5 status formats:
        - Rev4: "Completed 3/24/2026" (date embedded in status text)
        - Rev5: "Completed" (date in separate "POA&M Completion Date" column)
        - Both: "Ongoing" → Open, "Risk Accepted" → Open, "Delayed" → Open

        :param str status_str: Raw status string from workbook
        :param str poam_completion_date: Separate completion date (Rev5 only)
        :return: Tuple of (regscale_status, completion_date_or_None)
        :rtype: Tuple[str, Optional[str]]
        """
        if not status_str:
            return "Open", None

        status_lower = status_str.lower().strip()

        if status_lower.startswith("completed"):
            # Rev5: completion date is in a separate column
            if poam_completion_date:
                return "Closed", poam_completion_date
            # Rev4: completion date may be embedded in the status text
            match = _COMPLETED_PATTERN.match(status_str)
            completion_date = match.group(1).strip() if match else None
            return "Closed", completion_date if completion_date else None

        if "risk accepted" in status_lower:
            return "Open", None  # Risk-accepted POAMs remain open in RegScale

        if "ongoing" in status_lower or "delayed" in status_lower:
            return "Open", None

        return "Open", None

    def _map_severity(self, raw_severity: str) -> IssueSeverity:
        """
        Map eMASS raw severity to RegScale IssueSeverity.

        :param str raw_severity: Raw severity string from workbook
        :return: Mapped severity enum
        :rtype: IssueSeverity
        """
        if not raw_severity:
            return IssueSeverity.Moderate

        return SEVERITY_MAP.get(raw_severity.lower().strip(), IssueSeverity.Moderate)

    def _extract_cves(self, source_ident_vuln: str) -> List[str]:
        """
        Extract CVE identifiers from the Source Identifying Vulnerability column.

        :param str source_ident_vuln: Raw text from column L
        :return: List of CVE strings (may be empty)
        :rtype: List[str]
        """
        if not source_ident_vuln:
            return []
        return _CVE_PATTERN.findall(source_ident_vuln)

    def _parse_devices_affected(self, devices_str: str) -> List[str]:
        """
        Parse the Devices Affected column into individual asset identifiers.

        Handles multiple delimiters: newlines, commas, semicolons, pipes.

        :param str devices_str: Raw devices text from workbook
        :return: List of cleaned asset identifiers
        :rtype: List[str]
        """
        if not devices_str:
            return []

        # Split on common delimiters
        raw_ids = re.split(r"[,;\|\n\t]+", devices_str)

        # Clean and filter
        cleaned = []
        for raw_id in raw_ids:
            asset_id = raw_id.strip()
            if asset_id and len(asset_id) > 1 and asset_id.lower() not in ("n/a", "none", "null", "tbd", "na"):
                cleaned.append(asset_id)

        return cleaned

    def _parse_date_safe(self, value: str, field_name: str, default: str = "") -> str:
        """
        Safely parse a date value with error handling.

        :param str value: Raw date value
        :param str field_name: Field name for logging
        :param str default: Default if parsing fails
        :return: Parsed date string or default
        :rtype: str
        """
        if not value or str(value) in ("", "NaT", "#REF!", "None"):
            return default
        try:
            return date_str(value)
        except Exception as e:
            logger.debug("Failed to parse %s '%s': %s", field_name, value, e)
            return default

    # ------------------------------------------------------------------
    # Finding generation (yields IntegrationFinding per row)
    # ------------------------------------------------------------------

    @staticmethod
    def _generate_finding_id(description: str, row_idx: int) -> str:
        """
        Generate a stable finding identifier from the description or row index.

        For Rev5 exports, POAM Item IDs may be empty. This generates a stable
        identifier by extracting a RegScale issue ID from the description (if
        present) or creating a hash-based ID from the description content.

        :param str description: Row description text
        :param int row_idx: Row index (fallback)
        :return: A stable identifier string
        :rtype: str
        """
        if description:
            # Try to extract RegScale issue ID from description (e.g., "#33341")
            match = _REGSCALE_ISSUE_ID_PATTERN.search(description)
            if match:
                return match.group(1)

            # Hash the description for a stable ID
            desc_hash = hashlib.md5(description.encode("utf-8")).hexdigest()[:12]  # noqa: S324
            return f"emass-{desc_hash}"

        return f"row-{row_idx}"

    def _parse_rows(self, ws: Worksheet) -> Iterator[IntegrationFinding]:
        """
        Parse all data rows from the worksheet and yield IntegrationFinding objects.

        Each row may produce multiple findings if it contains multiple
        assets or CVEs (one finding per unique asset+CVE combination).

        Handles Rev5 exports where the POAM Item ID column may be empty
        by generating stable identifiers from the description content.

        :param Worksheet ws: The POA&M worksheet
        :yields: IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        consecutive_blanks = 0
        data_start = self.header_row + 1

        for row_idx, row in enumerate(
            ws.iter_rows(min_row=data_start, values_only=True),
            start=data_start,
        ):
            self.stats["total_rows"] += 1

            # Extract named values
            values = self._extract_row_values(row)

            # Blank row detection: skip rows where both POAM ID and description are empty
            poam_id = values["poam_id"]
            description = values["description"]
            if not poam_id and not description:
                consecutive_blanks += 1
                self.stats["blank_rows"] += 1
                if consecutive_blanks >= BLANK_ROW_THRESHOLD:
                    logger.info("Stopping after %d consecutive blank rows at row %d.", BLANK_ROW_THRESHOLD, row_idx)
                    break
                continue

            consecutive_blanks = 0

            # For Rev5 exports, POAM Item ID may be empty - generate from description
            if not poam_id:
                poam_id = self._generate_finding_id(description, row_idx)
                logger.debug(
                    "Row %d: No POAM Item ID, generated identifier: %s",
                    row_idx,
                    poam_id,
                )

            # Parse core fields
            poam_completion_date = self._parse_date_safe(values.get("poam_completion_date", ""), "poam_completion_date")
            status, completion_date = self._parse_status(values["status"], poam_completion_date)
            # Normalize the completion date (Rev4 may have "3/24/2026" from status text)
            if completion_date:
                completion_date = self._parse_date_safe(completion_date, "completion_date") or completion_date
            severity = self._map_severity(values["raw_severity"] or values["severity"])
            cves = self._extract_cves(values["source_ident_vuln"])
            assets = self._parse_devices_affected(values["devices_affected"])

            # Parse dates
            due_date = self._parse_date_safe(values["scheduled_completion"], "scheduled_completion")
            if not due_date:
                due_date = issue_due_date(severity, get_current_datetime())

            date_created = get_current_datetime()

            # Build title from POAM ID + first line of description
            title = f"POAM-{poam_id}"
            if description:
                # Use first 200 chars of description as title supplement
                desc_preview = description[:200].split("\n")[0]
                title = f"POAM-{poam_id}: {desc_preview}"
            title = title[:255]

            # Build consolidated asset string
            consolidated_assets = ", ".join(assets) if assets else ""
            primary_asset = assets[0] if assets else ""

            # Build common finding fields matching the Rev5 export mapping
            # for proper round-trip: import fields must match what the export reads
            common_kwargs = {
                "category": "POA&M",
                "severity": severity,
                "description": description[:7900] if description else "eMASS POAM",
                "status": (
                    regscale_models.IssueStatus.Closed if status == "Closed" else regscale_models.IssueStatus.Open
                ),
                "priority": self._severity_to_priority(severity),
                "issue_type": "POA&M",
                "date_created": date_created,
                "due_date": due_date,
                "external_id": str(poam_id),
                "poam_id": str(poam_id),
                "identification": values["source_ident_vuln"] or "Vulnerability Assessment",
                "recommendation_for_mitigation": values["recommendations"] or "",
                "observations": values.get("milestone_changes", "") or "",
                "poam_comments": values["comments"] or "",
                "point_of_contact": values["office_org"] or "",
                "source_report": "eMASS POAM Workbook",
                "milestone_changes": values.get("milestone_changes", "") or "",
                "affected_controls": values["controls_aps"] or "",
                "extra_data": {
                    "row_index": row_idx,
                    "template_revision": self.template_revision,
                    "security_checks": values["security_checks"] or "",
                    "resources_required": values["resources_required"] or "",
                    "mitigations": values["mitigations"] or "",
                    "predisposing_conditions": values["predisposing_conditions"] or "",
                    "relevance_of_threat": values["relevance_of_threat"] or "",
                    "threat_description": values["threat_description"] or "",
                    "likelihood": values["likelihood"] or "",
                    "impact": values["impact"] or "",
                    "impact_description": values["impact_desc"] or "",
                    "residual_risk_level": values["residual_risk"] or "",
                    "resulting_residual_risk": values["resulting_residual_risk"] or "",
                    "raw_severity": values["raw_severity"] or "",
                    "severity": values["severity"] or "",
                    "completion_date": completion_date or "",
                    "identification_source_details": values.get("identification_source_details", "") or "",
                },
            }

            # Generate findings: one per CVE (or one with no CVE) × consolidated assets
            if cves:
                for cve in cves:
                    finding = IntegrationFinding(
                        control_labels=self._extract_control_labels(values["controls_aps"]),
                        title=title,
                        asset_identifier=primary_asset,
                        issue_asset_identifier_value=consolidated_assets,
                        cve=cve,
                        plugin_name=values["source_ident_vuln"] or "eMASS POAM",
                        **common_kwargs,
                    )
                    self.stats["parsed_findings"] += 1
                    yield finding
            else:
                # No CVEs — single finding with all assets
                finding = IntegrationFinding(
                    control_labels=self._extract_control_labels(values["controls_aps"]),
                    title=title,
                    asset_identifier=primary_asset,
                    issue_asset_identifier_value=consolidated_assets,
                    cve=None,
                    plugin_name=values["source_ident_vuln"] or "eMASS POAM",
                    **common_kwargs,
                )
                self.stats["parsed_findings"] += 1
                yield finding

    @staticmethod
    def _extract_control_labels(security_control: str) -> List[str]:
        """
        Extract control labels from the Security Control column.

        :param str security_control: Raw control text (e.g., "AC-2; AU-6(1)")
        :return: List of control labels
        :rtype: List[str]
        """
        if not security_control:
            return []
        # Split on semicolons, commas, or whitespace-separated controls
        raw_labels = re.split(r"[;,]\s*", security_control)
        return [label.strip() for label in raw_labels if label.strip()]

    @staticmethod
    def _severity_to_priority(severity: IssueSeverity) -> str:
        """Map severity to priority string."""
        return {
            IssueSeverity.Critical: "Critical",
            IssueSeverity.High: "High",
            IssueSeverity.Moderate: "Medium",
            IssueSeverity.Low: "Low",
        }.get(severity, "Medium")

    # ------------------------------------------------------------------
    # Finding → Issue conversion
    # ------------------------------------------------------------------

    ISSUE_DESCRIPTION_MAX_LENGTH = 7900

    def _finding_to_issue(self, finding: IntegrationFinding) -> regscale_models.Issue:
        """
        Convert an IntegrationFinding to a RegScale Issue model.

        Maps fields to match the RegScale eMASS POAM export templates (Rev4 and Rev5)
        for proper round-trip compatibility. Key Issue fields mapped:
            - description → Control Vulnerability Description
            - affectedControls → Controls / APs
            - securityChecks → Security Checks
            - dueDate → Scheduled Completion Date / POA&M Scheduled Completion Date
            - identification → Source Identifying Vulnerability / Identification Source
            - status → Status / POA&M Status
            - dateCompleted → (parsed from status text in Rev4, POA&M Completion Date in Rev5)
            - poamComments → Comments
            - severityLevel → Raw Severity, Severity, Likelihood
            - assetIdentifier → Devices Affected
            - securityImpact → Impact Description
            - adjustedRiskRating → Residual Risk Level
            - recommendedActions → Recommendations

        :param IntegrationFinding finding: The finding to convert
        :return: Issue object ready for batch submission
        :rtype: regscale_models.Issue
        """
        description = finding.description or ""
        if len(description) > self.ISSUE_DESCRIPTION_MAX_LENGTH:
            description = description[: self.ISSUE_DESCRIPTION_MAX_LENGTH - 3] + "..."

        extra = finding.extra_data or {}

        # Determine completion date for completed issues
        date_completed = None
        status_str = str(finding.status.value) if hasattr(finding.status, "value") else str(finding.status)
        if status_str == "Closed":
            # Use the parsed completion date from the workbook, or fall back to now
            date_completed = extra.get("completion_date") or get_current_datetime()

        return regscale_models.Issue(
            title=finding.title[:255] if finding.title else "Untitled eMASS POAM",
            description=description,
            severityLevel=finding.severity,
            status=status_str,
            parentId=self.plan_id,
            parentModule="securityplans",
            integrationFindingId=finding.external_id,
            otherIdentifier=finding.poam_id,
            isPoam=True,
            identification=finding.identification or "Vulnerability Assessment",
            dueDate=finding.due_date,
            dateCreated=finding.date_created,
            dateCompleted=date_completed,
            cve=finding.cve,
            assetIdentifier=finding.asset_identifier,
            poamComments=finding.poam_comments,
            recommendedActions=finding.recommendation_for_mitigation,
            affectedControls=finding.affected_controls,
            securityChecks=extra.get("security_checks", ""),
            securityImpact=extra.get("impact_description", ""),
            adjustedRiskRating=extra.get("residual_risk_level", ""),
            originalRiskRating=extra.get("raw_severity", ""),
            remediationDescription=extra.get("mitigations", ""),
            sourceReport="eMASS POAM Workbook",
        )

    # ------------------------------------------------------------------
    # Batch submission via streaming endpoint
    # ------------------------------------------------------------------

    def _submit_batch(self, issues: List[regscale_models.Issue]) -> None:
        """
        Submit a batch of issues to RegScale's streaming batch create/update endpoint.

        Uses ``Issue.batch_create_or_update()`` which calls
        ``/api/v2/issues/streamBatchCreateOrUpdate`` with server-side deduplication.

        :param List[regscale_models.Issue] issues: Issues to submit
        """
        if not issues:
            return

        options: IssueBatchOptions = {
            "source": "eMASS POAM Workbook",
            "uniqueKeyFields": ["integrationFindingId", "parentId", "parentModule"],
            "enableMopUp": self.enable_mop_up,
            "poamCreation": True,
            "parentId": self.plan_id,
            "parentModule": "securityplans",
            "batchSize": BATCH_SIZE,
        }

        if self.issue_owner_id:
            options["issueOwnerId"] = self.issue_owner_id

        try:
            result = regscale_models.Issue.batch_create_or_update(
                items=issues,
                batch_size=BATCH_SIZE,
                options=options,
            )
            result_count = len(result) if result else 0
            self.stats["created"] += result_count
            logger.info(
                "Batch submitted: %d issues sent, %d processed.",
                len(issues),
                result_count,
            )
        except Exception as e:
            logger.error("Batch submission failed: %s. Falling back to individual creates.", e)
            self._submit_individually(issues)

    def _submit_individually(self, issues: List[regscale_models.Issue]) -> None:
        """
        Fallback: submit issues one at a time with circuit breaker protection.

        :param List[regscale_models.Issue] issues: Issues to submit individually
        """
        consecutive_failures = 0
        recent_attempts: deque = deque(maxlen=CIRCUIT_BREAKER_WINDOW_SIZE)

        for issue in issues:
            try:
                regscale_models.Issue.create(issue)
                self.stats["created"] += 1
                consecutive_failures = 0
                recent_attempts.append(False)

            except Exception as e:
                consecutive_failures += 1
                recent_attempts.append(True)
                self.stats["errors"] += 1
                self.stats["error_details"].append(
                    {
                        "poam_id": issue.otherIdentifier,
                        "error": str(e),
                    }
                )
                logger.error("Failed to create issue for POAM %s: %s", issue.otherIdentifier, e)

                # Circuit breaker
                if consecutive_failures >= CIRCUIT_BREAKER_THRESHOLD:
                    logger.critical(
                        "Circuit breaker triggered: %d consecutive failures. Aborting.",
                        consecutive_failures,
                    )
                    raise RuntimeError(
                        f"Circuit breaker triggered after {consecutive_failures} consecutive failures."
                    ) from e

                if len(recent_attempts) >= CIRCUIT_BREAKER_WINDOW_SIZE:
                    failure_rate = sum(recent_attempts) / len(recent_attempts)
                    if failure_rate > CIRCUIT_BREAKER_FAILURE_RATE:
                        logger.critical(
                            "Circuit breaker triggered: %.0f%% failure rate in last %d attempts.",
                            failure_rate * 100,
                            CIRCUIT_BREAKER_WINDOW_SIZE,
                        )
                        raise RuntimeError(f"Circuit breaker: {failure_rate:.0%} failure rate") from e

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def process(self) -> Dict[str, Any]:
        """
        Parse the eMASS POAM workbook and import findings into RegScale.

        This is the main entry point. It:
        1. Detects the POAM sheet
        2. Builds column index mapping from headers
        3. Parses all data rows into IntegrationFinding objects
        4. Converts to Issue models
        5. Submits in batches via the streaming endpoint

        :return: Statistics dictionary with counts of created, updated, errors, etc.
        :rtype: Dict[str, Any]
        """
        ws = self._detect_poam_sheet()
        if ws is None:
            error_and_exit("No POAM sheet found in workbook.")
            return self.stats

        if not self._build_column_indices(ws):
            error_and_exit("Could not build column mapping from workbook headers.")
            return self.stats

        logger.info(
            "Processing eMASS POAM workbook: %s (sheet: '%s', header_row: %d, template: %s)",
            self.file_path,
            ws.title,
            self.header_row,
            self.template_revision.upper(),
        )

        # Parse all findings
        findings = list(self._parse_rows(ws))

        logger.info(
            "Parsed %d findings from %d rows (%d blank, %d skipped).",
            self.stats["parsed_findings"],
            self.stats["total_rows"],
            self.stats["blank_rows"],
            self.stats["skipped"],
        )

        if self.dry_run:
            logger.info("Dry run complete. No data was sent to RegScale.")
            self._print_dry_run_summary(findings)
            return self.stats

        # Convert findings to Issue models
        issues = [self._finding_to_issue(f) for f in findings]

        # Submit in batches
        for i in range(0, len(issues), BATCH_SIZE):
            batch = issues[i : i + BATCH_SIZE]
            batch_num = (i // BATCH_SIZE) + 1
            total_batches = (len(issues) + BATCH_SIZE - 1) // BATCH_SIZE
            logger.info("Submitting batch %d/%d (%d issues)...", batch_num, total_batches, len(batch))
            self._submit_batch(batch)

        logger.info(
            "eMASS POAM import complete. Created: %d, Updated: %d, Errors: %d",
            self.stats["created"],
            self.stats["updated"],
            self.stats["errors"],
        )

        return self.stats

    def _print_dry_run_summary(self, findings: List[IntegrationFinding]) -> None:
        """Print a summary of parsed findings for dry-run mode."""
        logger.info("=" * 60)
        logger.info("DRY RUN SUMMARY")
        logger.info("=" * 60)
        logger.info("Total rows scanned: %d", self.stats["total_rows"])
        logger.info("Findings parsed:    %d", self.stats["parsed_findings"])
        logger.info("Blank rows:         %d", self.stats["blank_rows"])

        if findings:
            # Show first 5 findings as preview
            preview_count = min(5, len(findings))
            logger.info("-" * 60)
            logger.info("First %d findings:", preview_count)
            for f in findings[:preview_count]:
                logger.info(
                    "  POAM: %s | Severity: %s | Status: %s | CVE: %s | Asset: %s",
                    f.poam_id,
                    f.severity,
                    f.status,
                    f.cve or "N/A",
                    f.asset_identifier[:50] if f.asset_identifier else "N/A",
                )

            # Show severity distribution
            severity_counts: Dict[str, int] = {}
            for f in findings:
                sev = str(f.severity)
                severity_counts[sev] = severity_counts.get(sev, 0) + 1
            logger.info("-" * 60)
            logger.info("Severity distribution:")
            for sev, count in sorted(severity_counts.items()):
                logger.info("  %s: %d", sev, count)

        logger.info("=" * 60)

    def close(self) -> None:
        """Close the workbook and release resources."""
        if self.workbook:
            try:
                self.workbook.close()
            except Exception:
                pass
            self.workbook = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
