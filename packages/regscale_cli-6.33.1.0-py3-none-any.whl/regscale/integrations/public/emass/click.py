#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI commands for eMASS POAM workbook import."""

import logging
import warnings
from typing import Optional

import click

from regscale.models import regscale_id

logger = logging.getLogger("regscale")


@click.command(name="import_poam_workbook")
@click.option(
    "--file_path",
    "-f",
    type=click.Path(exists=True, dir_okay=False, file_okay=True),
    required=True,
    help="Path to the eMASS POAM workbook (.xlsm or .xlsx).",
)
@regscale_id(help="Enter the RegScale Security Plan ID to import eMASS POAMs into.")
@click.option(
    "--poam-sheet-name",
    "-s",
    type=click.STRING,
    required=False,
    default=None,
    help="Explicit sheet name to parse. If omitted, auto-detects the POA&M sheet.",
)
@click.option(
    "--header-row",
    "-hr",
    type=click.INT,
    default=7,
    show_default=True,
    help="1-based row number containing column headers in the workbook.",
)
@click.option(
    "--enable-mop-up",
    is_flag=True,
    default=False,
    help="Close issues in RegScale that are NOT present in the workbook (mop-up).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Parse and validate only — do not send data to RegScale.",
)
@click.option(
    "--issue-owner-id",
    "-o",
    type=click.STRING,
    required=False,
    default=None,
    help="User ID to assign as the issue owner for all imported POAMs.",
)
def import_emass_poam_workbook(
    file_path: str,
    regscale_id: int,
    poam_sheet_name: Optional[str],
    header_row: int,
    enable_mop_up: bool,
    dry_run: bool,
    issue_owner_id: Optional[str],
) -> None:
    """
    Import an eMASS POA&M workbook into RegScale as issues/POAMs.

    Parses the standard DoD eMASS POAM Excel template and imports each POA&M
    item as a RegScale issue via the streaming batch create/update endpoint.
    Supports deduplication, CVE extraction, multi-asset rows, and mop-up.

    Examples:

        \b
        # Basic import
        regscale emass import-poam-workbook -f /path/to/emass_poam.xlsm --regscale-id 123

        \b
        # Specify sheet name and header row
        regscale emass import-poam-workbook -f /path/to/emass_poam.xlsx --regscale-id 123 -s "POA&M" --header-row 8

        \b
        # Dry run (validate without importing)
        regscale emass import-poam-workbook -f /path/to/emass_poam.xlsm --regscale-id 123 --dry-run

        \b
        # Import with mop-up (close issues not in workbook)
        regscale emass import-poam-workbook -f /path/to/emass_poam.xlsm --regscale-id 123 --enable-mop-up
    """
    # Suppress openpyxl UserWarnings about styles in read-only mode
    warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

    from regscale.integrations.public.emass.poam_workbook_scanner import EmassPoamWorkbookScanner

    logger.info(
        "Starting eMASS POAM workbook import: file=%s, plan_id=%d, dry_run=%s",
        file_path,
        regscale_id,
        dry_run,
    )

    with EmassPoamWorkbookScanner(
        plan_id=regscale_id,
        file_path=str(file_path),
        poam_sheet_name=poam_sheet_name,
        header_row=header_row,
        enable_mop_up=enable_mop_up,
        dry_run=dry_run,
        issue_owner_id=issue_owner_id,
    ) as scanner:
        stats = scanner.process()

    # Summary output
    logger.info("\n--- eMASS POAM Import Results ---")
    logger.info(f"  Total rows scanned: {stats['total_rows']}")
    logger.info(f"  Findings parsed:    {stats['parsed_findings']}")
    logger.info(f"  Created/Updated:    {stats['created']}")
    logger.info(f"  Errors:             {stats['errors']}")
    logger.info(f"  Blank rows:         {stats['blank_rows']}")

    if stats["errors"] > 0:
        logger.error("\n  Error details:")
        for err in stats["error_details"][:10]:
            logger.error(f"    POAM {err.get('poam_id', '?')}: {err.get('error', 'Unknown')}")
        if len(stats["error_details"]) > 10:
            logger.error(f"    ... and {len(stats['error_details']) - 10} more errors.")

    if dry_run:
        logger.warning("\n  [DRY RUN] No data was sent to RegScale.")
