#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Add functionality to upgrade application catalog information via API."""


# pylint: disable=line-too-long, global-statement, global-at-module-level, abstract-class-instantiated, too-many-lines

# Standard Imports
import contextlib
import operator
import sys
from typing import Optional, Tuple

import click  # type: ignore
from requests import JSONDecodeError  # type: ignore

from regscale.core.app.api import Api
from regscale.core.app.logz import create_logger
from regscale.core.app.utils.app_utils import create_progress_object, error_and_exit
from regscale.core.app.utils.catalog_utils.common import get_new_catalog
from regscale.models.app_models.catalog_compare import CatalogCompare

# create logger function to log to the console
logger = create_logger()
# create progress object
job_progress = create_progress_object()

DOWNLOAD_URL: str = ""
CAT_UUID: str = ""
SECURITY_CONTROL_ID_KEY: list = []


def _print_catalog_menu(catalogues: list) -> list:
    """
    Print catalog menu and return menu counter.

    :param list catalogues: List of catalogues
    :return: Menu counter list
    :rtype: list
    """
    menu_counter: list = []
    catalogues.sort(key=operator.itemgetter("id"))
    for i, catalog in enumerate(catalogues):
        print(f"{catalog['id']}: {catalog['value']}")
        menu_counter.append(i)
    return menu_counter


def _get_catalog_selection(menu_counter: list) -> int:
    """
    Get catalog selection from user.

    :param list menu_counter: Valid menu options
    :return: Selected catalog ID
    :rtype: int
    """
    while True:
        value = click.prompt(
            "Please enter the number of the catalog you would like to run diagnostics on",
            type=int,
        )
        if min(menu_counter) <= value <= max(menu_counter):
            return value
        print("That is not a valid selection, please try again")


def _process_selected_catalog(catalogues: list, value: int) -> None:
    """
    Process the selected catalog and set global variables.

    :param list catalogues: List of catalogues
    :param int value: Selected catalog ID
    """
    global CAT_UUID, DOWNLOAD_URL
    for catalog in catalogues:
        if catalog["id"] == value:
            CAT_UUID = catalog["metadata"]["uuid"]
            if catalog["download"] is True:
                if catalog["paid"] is False:
                    DOWNLOAD_URL = catalog["link"]
                else:
                    logger.warning("This is a paid catalog, please contact RegScale customer support.")
                    sys.exit()
            break


def display_menu() -> None:
    """
    Start the process of comparing two catalogs, one from the master catalog list
    and one from the user's RegScale instance

    :rtype: None
    """
    api = Api()
    api.timeout = 180

    data = CatalogCompare.get_master_catalogs(api=api)
    catalogues = data["catalogues"]
    menu_counter = _print_catalog_menu(catalogues)
    value = _get_catalog_selection(menu_counter)
    _process_selected_catalog(catalogues, value)
    compare_and_update_catalog_elements(api=api)


def compare_and_update_catalog_elements(api: Api) -> None:
    """
    Function to compare and update elements between catalogs

    :param Api api: Api object
    :rtype: None
    """
    new_catalog_elements = parse_new_catalog()
    old_catalog_elements = parse_old_catalog(api=api)
    update_security_controls(
        new_security_controls=new_catalog_elements[0],
        old_security_controls=old_catalog_elements[0],
        api=api,
    )
    update_ccis(
        new_ccis=new_catalog_elements[1],
        old_ccis=old_catalog_elements[1],
        api=api,
    )
    update_objectives(
        new_objectives=new_catalog_elements[2],
        old_objectives=old_catalog_elements[2],
        api=api,
    )
    update_parameters(
        new_parameters=new_catalog_elements[3],
        old_parameters=old_catalog_elements[3],
        api=api,
    )
    update_tests(
        new_tests=new_catalog_elements[4],
        old_tests=old_catalog_elements[4],
        api=api,
    )


def _update_existing_control(
    new_control: dict, old_control: dict, api: Api, archived_list: list, updated_list: list
) -> None:
    """
    Update an existing security control.

    :param dict new_control: New control data
    :param dict old_control: Old control data
    :param Api api: API object
    :param list archived_list: List to append archived controls
    :param list updated_list: List to append updated controls
    """
    key_dict = {"old_sc_id": old_control["id"], "new_sc_id": new_control["id"]}
    SECURITY_CONTROL_ID_KEY.append(key_dict)

    with contextlib.suppress(KeyError):
        if new_control["archived"] is True:
            old_control["archived"] = True
            archived_list.append(old_control)
            return

    _copy_control_fields(new_control, old_control)
    update = api.put(
        url=api.config["domain"] + f"/api/SecurityControls/{old_control['id']}",
        json=old_control,
    )
    update.raise_for_status()
    if update.ok:
        logger.info("Updated Security Control for Control ID: %i", old_control["id"])
        updated_list.append(old_control)


def _copy_control_fields(new_control: dict, old_control: dict) -> None:
    """
    Copy fields from new control to old control, excluding protected fields.

    :param dict new_control: New control data
    :param dict old_control: Old control data to update
    """
    protected_fields = ["id", "catalogueID", "tenantsId", "sortId", "lastUpdatedById"]
    for key in old_control:
        try:
            if key not in protected_fields:
                old_control[key] = new_control[key]
        except KeyError:
            old_control["archived"] = False


def _create_new_control(new_control: dict, old_controls: list[dict], api: Api, created_list: list) -> None:
    """
    Create a new security control.

    :param dict new_control: New control data
    :param list[dict] old_controls: List of old controls for reference
    :param Api api: API object
    :param list created_list: List to append created controls
    """
    try:
        new_control["catalogueID"] = old_controls[0]["controls"]["catalogueID"]
    except KeyError:
        new_control["catalogueID"] = old_controls[0]["catalogueID"]
    create = api.post(
        url=api.config["domain"] + "/api/SecurityControls",
        json=new_control,
    )
    create.raise_for_status()
    if create.ok:
        logger.info("Created Security Control for Control ID: %s", new_control.get("controlId"))
        created_list.append(new_control)


def update_security_controls(new_security_controls: list[dict], old_security_controls: list[dict], api: Api) -> None:
    """
    Function to compare and update security controls

    :param list[dict] new_security_controls: security controls from new catalog
    :param list[dict] old_security_controls: security controls from old catalog
    :param Api api: api object
    :rtype: None
    """
    archived_list = []
    updated_list = []
    created_list = []
    for new_security_control in new_security_controls:
        element_exists = False
        for old_security_control in old_security_controls:
            if new_security_control.get("controlId") == old_security_control.get("controlId"):
                _update_existing_control(new_security_control, old_security_control, api, archived_list, updated_list)
                element_exists = True
                break
        if not element_exists:
            try:
                new_security_control["catalogueID"] = old_security_controls[0]["controls"]["catalogueID"]
            except KeyError:
                new_security_control["catalogueID"] = old_security_controls[0]["catalogueID"]
            create = api.post(
                url=api.config["domain"] + "/api/SecurityControls",
                json=new_security_control,
            )
            create.raise_for_status()
            if create.ok:
                logger.info(
                    "Created Security Control for Control ID: %i",
                    new_security_control["id"],
                )
                created_list.append(new_security_control)
    data_report(
        data_name="SecurityControls",
        archived=archived_list,
        updated=updated_list,
        created=created_list,
    )


def update_ccis(new_ccis: list[dict], old_ccis: list[dict], api: Api) -> None:
    """
    Function to compare and update ccis

    :param list[dict] new_ccis: ccis from new catalog
    :param list[dict] old_ccis: ccis from old catalog
    :param Api api: api object
    :rtype: None
    """
    archived_list = []
    updated_list = []
    created_list = []
    element_exists = False
    for new_cci in new_ccis:
        for old_cci in old_ccis:
            for cci in old_cci:
                if new_cci["name"] == cci["name"]:
                    element_exists = True
                    _update_or_archive_cci(new_cci, cci, api, archived_list, updated_list)
        if not element_exists:
            _create_new_cci(new_cci, api, created_list)
    data_report(
        data_name="CCIs",
        archived=archived_list,
        updated=updated_list,
        created=created_list,
    )


def _update_or_archive_cci(new_cci: dict, cci: dict, api: Api, archived_list: list, updated_list: list) -> None:
    """
    Update or archive a single CCI element.

    :param dict new_cci: New CCI data
    :param dict cci: Existing CCI data
    :param Api api: API object
    :param list archived_list: List to append archived CCIs
    :param list updated_list: List to append updated CCIs
    """
    with contextlib.suppress(KeyError):
        if new_cci["archived"] is True:
            cci["archived"] = True
            archived_list.append(cci)
            return

    _copy_cci_fields(new_cci, cci, protected_keys=["id", "securityControlId"])
    cci["securityControlId"] = _get_mapped_security_control_id(new_cci["securityControlId"])

    update = api.put(
        url=api.config["domain"] + f"/api/cci/{cci['id']}",
        json=cci,
    )
    update.raise_for_status()
    if update.ok:
        logger.info("Updated CCI for CCI ID: %i", cci["id"])
        updated_list.append(cci)


def _create_new_cci(new_cci: dict, api: Api, created_list: list) -> None:
    """
    Create a new CCI element.

    :param dict new_cci: New CCI data
    :param Api api: API object
    :param list created_list: List to append created CCIs
    """
    new_cci["securityControlId"] = _get_mapped_security_control_id(new_cci["securityControlId"])
    create = api.post(
        url=api.config["domain"] + "/api/cci",
        json=new_cci,
    )
    create.raise_for_status()
    if create.ok:
        logger.info("Created CCI for CCI ID: %i", new_cci["id"])
        created_list.append(new_cci)


def _copy_cci_fields(new_item: dict, old_item: dict, protected_keys: list[str]) -> None:
    """
    Copy fields from new item to old item, setting isPublic to False and skipping protected keys.

    :param dict new_item: Source data
    :param dict old_item: Target data to update
    :param list[str] protected_keys: Keys to skip during copy
    """
    for key in old_item:
        if key == "isPublic":
            old_item["isPublic"] = False
        elif key not in protected_keys:
            old_item[key] = new_item[key]


def update_objectives(new_objectives: list[dict], old_objectives: list[dict], api: Api) -> None:
    """
    Function to compare and update objectives

    :param list[dict] new_objectives: objectives from new catalog
    :param list[dict] old_objectives: objectives from old catalog
    :param Api api: Api object
    :rtype: None
    """
    archived_list = []
    updated_list = []
    created_list = []
    element_exists = False
    for new_objective in new_objectives:
        for old_objective in old_objectives:
            if new_objective["name"] == old_objective["name"]:
                element_exists = True
                _update_or_archive_objective(new_objective, old_objective, api, archived_list, updated_list)
        if not element_exists:
            _create_new_objective(new_objective, api, created_list)
    data_report(
        data_name="Objectives",
        archived=archived_list,
        updated=updated_list,
        created=created_list,
    )


def _update_or_archive_objective(
    new_objective: dict, old_objective: dict, api: Api, archived_list: list, updated_list: list
) -> None:
    """
    Update or archive a single objective element.

    :param dict new_objective: New objective data
    :param dict old_objective: Existing objective data
    :param Api api: API object
    :param list archived_list: List to append archived objectives
    :param list updated_list: List to append updated objectives
    """
    with contextlib.suppress(KeyError):
        if new_objective["archived"] is True:
            old_objective["archived"] = True
            archived_list.append(old_objective)
            return

    _copy_cci_fields(new_objective, old_objective, protected_keys=["id", "securityControlId", "tenantsId"])
    old_objective["securityControlId"] = _get_mapped_security_control_id(new_objective["securityControlId"])
    old_objective.pop("tenantsId", None)

    update = api.put(
        url=api.config["domain"] + f"/api/controlObjectives/{old_objective['id']}",
        json=old_objective,
    )
    update.raise_for_status()
    if update.ok:
        logger.info("Updated Objective for Objective ID: %i", old_objective["id"])
        updated_list.append(old_objective)


def _create_new_objective(new_objective: dict, api: Api, created_list: list) -> None:
    """
    Create a new objective element.

    :param dict new_objective: New objective data
    :param Api api: API object
    :param list created_list: List to append created objectives
    """
    new_objective["securityControlId"] = _get_mapped_security_control_id(new_objective["securityControlId"])
    create = api.post(
        url=api.config["domain"] + "/api/controlObjectives",
        json=new_objective,
    )
    create.raise_for_status()
    if create.ok:
        logger.info("Created Objective for Objective ID: %i", new_objective["id"])
        created_list.append(new_objective)


def parse_parameters(data: dict) -> dict:
    """
    Function to parse keys from the provided dictionary

    :param dict data: parameters from catalog
    :return: dictionary with parsed keys
    :rtype: dict
    """
    for key in data:
        if key == "isPublic":
            data["isPublic"] = False
        elif key == "default":
            data["default"] = None
        elif key == "dataType":
            data["dataType"] = None
        elif key != "id" or key != "securityControlId":
            continue
    return data


def update_parameters(new_parameters: list[dict], old_parameters: list[dict], api: Api) -> None:
    """
    Function to compare and update parameters

    :param list[dict] new_parameters: parameters from new catalog
    :param list[dict] old_parameters: parameters from old catalog
    :param Api api: Api object
    :rtype: None
    """
    archived_list = []
    updated_list = []
    created_list = []
    element_exists = False
    for new_parameter in new_parameters:
        for old_parameter in old_parameters:
            if new_parameter["parameterId"] == old_parameter["parameterId"]:
                element_exists = True
                _update_or_archive_parameter(new_parameter, old_parameter, api, archived_list, updated_list)
        if not element_exists:
            _create_new_parameter(new_parameter, api, created_list)
    data_report(
        data_name="Parameters",
        archived=archived_list,
        updated=updated_list,
        created=created_list,
    )


def _update_or_archive_parameter(
    new_parameter: dict, old_parameter: dict, api: Api, archived_list: list, updated_list: list
) -> None:
    """
    Update or archive a single parameter element.

    :param dict new_parameter: New parameter data
    :param dict old_parameter: Existing parameter data
    :param Api api: API object
    :param list archived_list: List to append archived parameters
    :param list updated_list: List to append updated parameters
    """
    with contextlib.suppress(KeyError):
        if new_parameter["archived"] is True:
            old_parameter["archived"] = True
            archived_list.append(old_parameter)
            return

    old_parameter = parse_parameters(old_parameter)
    old_parameter["securityControlId"] = _get_mapped_security_control_id(new_parameter["securityControlId"])

    update = api.put(
        url=api.config["domain"] + f"/api/controlParameters/{old_parameter['id']}",
        json=old_parameter,
    )
    update.raise_for_status()
    if update.ok:
        logger.info("Updated Parameter for Parameter ID: %i", old_parameter["id"])
        updated_list.append(old_parameter)


def _create_new_parameter(new_parameter: dict, api: Api, created_list: list) -> None:
    """
    Create a new parameter element.

    :param dict new_parameter: New parameter data
    :param Api api: API object
    :param list created_list: List to append created parameters
    """
    new_parameter["securityControlId"] = _get_mapped_security_control_id(new_parameter["securityControlId"])
    create = api.post(
        url=api.config["domain"] + "/api/controlParameters",
        json=new_parameter,
    )
    create.raise_for_status()
    if create.ok:
        logger.info("Created Parameter for Parameter ID: %i", new_parameter["id"])
        created_list.append(new_parameter)


def update_tests(
    new_tests: list[dict], old_tests: list[dict], api: Api, test_method_map: dict[str, str] | None = None
) -> None:
    """
    Function to compare and update tests

    :param list[dict] new_tests: tests from new catalog
    :param list[dict] old_tests: tests from old catalog
    :param Api api: API Object
    :param dict[str, str] | None test_method_map: Optional mapping of testId -> testMethod (REG-6394)
    :rtype: None
    """
    # Create lookup dictionary for O(1) access
    old_tests_by_id = {test["testId"]: test for test in old_tests}

    archived_list = []
    updated_list = []
    created_list = []

    for new_test in new_tests:
        # REG-6394: Add test method if available in mapping
        _apply_test_method(new_test, test_method_map)

        old_test = old_tests_by_id.get(new_test["testId"])

        if old_test:
            # Test exists - update or archive
            _process_existing_test(new_test, old_test, api, archived_list, updated_list)
        else:
            # Test doesn't exist - create new
            _create_new_test(new_test, api, created_list)

    data_report(
        data_name="Tests",
        archived=archived_list,
        updated=updated_list,
        created=created_list,
    )


def _apply_test_method(test: dict, test_method_map: dict[str, str] | None) -> None:
    """Apply test method from mapping if available."""
    if test_method_map and test.get("testId") in test_method_map:
        test["testMethod"] = test_method_map[test["testId"]]


def _process_existing_test(new_test: dict, old_test: dict, api: Api, archived_list: list, updated_list: list) -> None:
    """Process an existing test - either archive or update it."""
    # Check if test should be archived
    with contextlib.suppress(KeyError):
        if new_test.get("archived") is True:
            old_test["archived"] = True
            archived_list.append(old_test)
            return

    # Update test fields
    _update_test_fields(old_test, new_test)

    # Get mapped security control ID
    old_sc_id = _get_mapped_security_control_id(new_test["securityControlId"])
    old_test["securityControlId"] = old_sc_id

    # Perform API update
    update = api.put(
        url=api.config["domain"] + f"/api/controlTestPlans/{old_test['id']}",
        json=old_test,
    )
    update.raise_for_status()

    if update.ok:
        logger.info("Updated test for test ID: %i", old_test["id"])
        updated_list.append(old_test)


def _update_test_fields(old_test: dict, new_test: dict) -> None:
    """Update fields from new test to old test, preserving certain fields."""
    for key in old_test:
        if key == "isPublic":
            old_test["isPublic"] = False
        elif key not in ["id", "securityControlId", "tenantsId"]:
            old_test[key] = new_test[key]


def _create_new_test(new_test: dict, api: Api, created_list: list) -> None:
    """Create a new test in the system."""
    # Get mapped security control ID
    old_sc_id = _get_mapped_security_control_id(new_test["securityControlId"])
    new_test["securityControlId"] = old_sc_id

    # Perform API creation
    create = api.post(
        url=api.config["domain"] + "/api/controlTestPlans",
        json=new_test,
    )
    create.raise_for_status()

    if create.ok:
        logger.info("Created test for test ID: %i", new_test["id"])
        created_list.append(new_test)


def _get_mapped_security_control_id(new_sc_id: int) -> int | None:
    """Get the old security control ID mapped from the new ID."""
    key_set = next(
        (item for item in SECURITY_CONTROL_ID_KEY if item["new_sc_id"] == new_sc_id),
        None,
    )
    return key_set.get("old_sc_id") if key_set else None


def parse_new_catalog() -> Tuple[list, list, list, list, list]:
    """
    Function to parse elements from the new catalog

    :return: Tuple containing lists of new catalog data elements
    :rtype: Tuple[list, list, list, list, list]
    """
    with job_progress:
        # add task for retrieving new catalog
        retrieving_new_catalog = job_progress.add_task(
            "[#f8b737]Retrieving selected catalog from RegScale.com/regulations.",
            total=6,
        )
        # retrieve new catalog to run diagnostics on
        new_catalog = get_new_catalog(url=DOWNLOAD_URL)
        # update the task as complete
        job_progress.update(retrieving_new_catalog, advance=1)
        # retrieve new catalog security controls
        new_security_controls = parse_dict_and_sublevel(
            data=new_catalog,
            key="catalogue",
            sub_key="securityControls",
            del_key="tenantsId",
        )
        # update the task as complete
        job_progress.update(retrieving_new_catalog, advance=1)
        # retrieve new catalog ccis
        new_ccis = parse_dict_and_sublevel(data=new_catalog, key="catalogue", sub_key="ccis")
        # update the task as complete
        job_progress.update(retrieving_new_catalog, advance=1)
        # retrieve new catalog objectives
        new_objectives = parse_dict_and_sublevel(data=new_catalog, key="catalogue", sub_key="objectives")
        # update the task as complete
        job_progress.update(retrieving_new_catalog, advance=1)
        # retrieve new catalog parameters
        new_parameters = parse_dict_and_sublevel(data=new_catalog, key="catalogue", sub_key="parameters")
        # update the task as complete
        job_progress.update(retrieving_new_catalog, advance=1)
        # retrieve new catalog tests
        new_tests = parse_dict_and_sublevel(data=new_catalog, key="catalogue", sub_key="tests")
        # update the task as complete
        job_progress.update(retrieving_new_catalog, completed=6)
    return new_security_controls, new_ccis, new_objectives, new_parameters, new_tests


def parse_old_catalog(api: Api) -> Tuple[list, list, list, list, list]:
    """
    Function to parse elements from the old catalog

    :param Api api: RegScale API object
    :return: Tuple containing lists of old catalog elements
    :rtype: Tuple[list, list, list, list, list]
    """
    with job_progress:
        # add task for retrieving old catalog
        retrieving_old_catalog = job_progress.add_task(
            "[#ef5d23]Retrieving selected catalog from RegScale application instance.",
            total=5,
        )
        # retrieve old catalog security controls
        security_controls = parse_controls(api=api)
        old_security_controls = security_controls[0]
        # update the task as complete
        job_progress.update(retrieving_old_catalog, advance=1)
        # retrive old catalog ccis
        old_ccis = security_controls[4]
        # update the task as complete
        job_progress.update(retrieving_old_catalog, advance=1)
        # retrieve old catalog objectives
        old_objectives = security_controls[2]
        # update the task as complete
        job_progress.update(retrieving_old_catalog, advance=1)
        # retrieve old catalog parameters
        old_parameters = security_controls[1]
        # update the task as complete
        job_progress.update(retrieving_old_catalog, advance=1)
        # retrieve old catalog tests
        old_tests = security_controls[3]
        # update the task as complete
        job_progress.update(retrieving_old_catalog, advance=1)

    return old_security_controls, old_ccis, old_objectives, old_parameters, old_tests


def parse_dict_and_sublevel(data: dict, key: str, sub_key: str, del_key: Optional[str] = None) -> list:
    """
    Function to parse a dictionary and retrieve data from the sublevel dictionary key

    :param dict data: dictionary to parse
    :param str key: key to be extracted from the dictionary
    :param str sub_key: the sub-level key being looked for
    :param Optional[str] del_key: the sub-level key to delete, defaults to None
    :return: a list containing the parsed data elements
    :rtype: list
    """
    parse_list = []
    with contextlib.suppress(KeyError):
        parse_list.extend(iter(data[key][sub_key]))
        if del_key:
            for parsed_item in parse_list:
                del parsed_item[del_key]
    return parse_list


def data_report(data_name: str, archived: list, updated: list, created: list) -> None:
    """Creates output data report for changed data elements in the catalog

    :param str data_name: catalog data element being updated
    :param list archived: archived data elements
    :param list updated: updated data elements
    :param list created: created data elements
    :rtype: None
    """
    import polars as pl  # Optimize import performance
    from xlsxwriter import Workbook

    try:
        archived_data = pl.DataFrame(archived)
        updated_data = pl.DataFrame(updated)
        created_data = pl.DataFrame(created)
    except (pl.exceptions.SchemaError, pl.exceptions.ShapeError, pl.exceptions.ComputeError) as exc:
        logger.error("Failed to build report DataFrame for %s: %s", data_name, exc)
        raise
    with Workbook(f"{data_name}.xlsx") as workbook:
        archived_data.write_excel(workbook=workbook, worksheet="Archived")
        updated_data.write_excel(workbook=workbook, worksheet="Updated")
        created_data.write_excel(workbook=workbook, worksheet="Created")


def get_old_security_controls(uuid_value: str, api: Api) -> list[dict]:
    """
    Function to retrieve the old catalog security controls from a RegScale instance via API & GraphQL

    :param str uuid_value: UUID of the catalog to retrieve
    :param Api api: RegScale API object
    :return: a list containing security controls
    :rtype: list[dict]
    """
    body = """
                query {
                    catalogues(
                        skip: 0
                        take: 50
                        where: { uuid: { eq: "uuid_value" } }
                    ) {
                        items {
                        id
                        }
                        pageInfo {
                        hasNextPage
                        }
                        totalCount
                    }
                    }""".replace("uuid_value", uuid_value)
    try:
        catalogue_id = api.graph(query=body)["catalogues"]["items"][0]["id"]
    except (IndexError, KeyError):
        error_and_exit(f"Catalog with UUID: {uuid_value} not found in RegScale instance.")
    try:
        old_security_controls = api.get(
            url=api.config["domain"] + f"/api/SecurityControls/getAllByCatalogWithDetails/{catalogue_id}"
        ).json()
        if len(old_security_controls) == 0:
            error_and_exit("This catalog does not currently exist in the RegScale application")
    except JSONDecodeError as ex:
        error_and_exit(f"Unable to retrieve control objectives from RegScale.\n{ex}")
    except TimeoutError:
        error_and_exit("The selected catalog is too large to update, please contact RegScale customer service.")
    return old_security_controls


def parse_controls(
    api: Api,
) -> Tuple[list[dict], list[dict], list[dict], list[dict], list[dict]]:
    """
    Function to retrieve the old catalog security controls from a RegScale instance via API & GraphQL

    :param Api api: RegScale API object
    :return: a tuple containing a list for each catalog element
    :rtype: Tuple[list[dict], list[dict], list[dict], list[dict], list[dict]]
    """
    old_security_controls = get_old_security_controls(uuid_value=CAT_UUID, api=api)
    parsed_old_security_controls = []
    for old_control in old_security_controls:
        parsed_old_security_controls.append(old_control["control"])
    old_parameters = []
    for control in old_security_controls:
        for parameter in control["parameters"]:
            old_parameters.append(parameter)
    old_objectives = []
    for control in old_security_controls:
        for objective in control["objectives"]:
            old_objectives.append(objective)
    old_tests = []
    for control in old_security_controls:
        for test in control["tests"]:
            old_tests.append(test)
    old_ccis = []
    for control in old_security_controls:
        id_number = control["control"]["id"]
        try:
            ccis = api.get(url=api.config["domain"] + f"/api/cci/getByControl/{id_number}").json()
            if ccis:
                old_ccis.append(ccis)
        except JSONDecodeError as ex:
            error_and_exit(f"Unable to retrieve control objectives from RegScale.\n{ex}")
    return (
        parsed_old_security_controls,
        old_parameters,
        old_objectives,
        old_tests,
        old_ccis,
    )
