#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Utility functions and classes for handling application variables"""

import logging
import os
import re
import sys
from typing import Any, Callable, Dict, Optional, Tuple, Type

logger = logging.getLogger(__name__)


class RsVariableType:
    """
    Configuration variable type

    :param Type var_type: The data type of the configuration variable
    :param str example: An example value for the configuration variable
    :param Optional[bool] required: A flag indicating if the configuration variable is required, defaults to True
    :param Optional[bool] sensitive: A flag indicating if the configuration variable is sensitive, defaults to False
    :param Optional[Any] default: A default value for the configuration variable, defaults to None
    """

    def __init__(
        self,
        var_type: Type,
        example: str,
        required: Optional[bool] = True,
        sensitive: Optional[bool] = False,
        default: Optional[Any] = None,
        hidden: Optional[bool] = False,
    ) -> None:
        self.type = var_type
        self.example = example
        self.required = required
        self.sensitive = sensitive
        self.default = default
        self.hidden = hidden


class RsVariableClassProperty:
    """
    Class property for retrieving configuration variables

    :param Callable getter: The getter function for the property
    """

    def __init__(self, getter: Callable):
        self.getter = getter
        self.name = None  # Will store the attribute name

    def __set_name__(self, owner: Any, name: str) -> None:
        """
        Sets the name of the property when it's assigned to a class

        :param Any owner: The class that owns this property
        :param str name: The name of the property
        """
        self.name = name

    def __get__(self, obj: Any, cls: Optional[type] = None) -> Any:
        """
        Retrieves the value using the getter when the property is accessed

        :param Any obj: The object instance
        :param Optional[type] cls: The class instance, defaults to None
        :return: The value of the property
        :rtype: Any
        :raises AttributeError: If required config is missing (for hasattr() compatibility in Python 3.14)
        """
        try:
            if obj is None:
                # Class-level access
                return self.getter(cls)

            # Instance-level access
            if not hasattr(obj, f"_{self.name}"):
                # Initialize the instance-specific value
                value = self.getter(cls)
                setattr(obj, f"_{self.name}", value)
            return getattr(obj, f"_{self.name}")
        except ValueError as e:
            # Convert ValueError to AttributeError for hasattr() compatibility in Python 3.14+
            # hasattr() only catches AttributeError, not ValueError
            if "Required configuration" in str(e) and "is missing" in str(e):
                raise AttributeError(str(e)) from e
            raise

    def __set__(self, obj: Any, value: Any) -> None:
        """
        Sets the value for an instance

        :param Any obj: The object instance
        :param Any value: The value to set
        """
        setattr(obj, f"_{self.name}", value)


class RsVariablesMeta(type):
    """
    Metaclass for creating RsVariables classes with properties for each configuration variable.

    Example::

        .. code-block:: python

            >>>class GcpVariables(metaclass=RsVariablesMeta):
            >>>    # Define class-level attributes with type annotations and examples
            >>>    gcpProjectId: RsVariableType(str, "000000000000")
            >>>    gcpCredentials: RsVariableType(str, "path/to/credentials.json", sensitive=True)
    """

    @staticmethod
    def _get_annotations(attrs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Get annotations from attrs, handling Python 3.12, 3.13+, and 3.14+ (PEP 649).

        :param Dict[str, Any] attrs: The class attributes
        :return: Dictionary of annotations
        :rtype: Dict[str, Any]
        """
        annotations = attrs.get("__annotations__", {})
        if annotations:
            return annotations

        # Python 3.14+ uses __annotate_func__ during metaclass __new__
        if "__annotate_func__" in attrs:
            try:
                # __annotate_func__ format: 1=VALUE, 2=FORWARDREF, 3=STRING
                return attrs["__annotate_func__"](1)
            except Exception:
                pass

        # Python 3.13 uses __annotate__ (after class creation)
        if "__annotate__" in attrs:
            try:
                # __annotate__ format: 1=VALUE, 2=FORWARDREF, 3=STRING
                return attrs["__annotate__"](1)
            except Exception:
                pass

        return {}

    @staticmethod
    def _get_class_annotations(cls: type) -> Dict[str, Any]:
        """
        Get annotations from a class, handling Python 3.12, 3.13+, and 3.14+.

        :param type cls: The class to get annotations from
        :return: Dictionary of annotations
        :rtype: Dict[str, Any]
        """
        if hasattr(cls, "__annotations__"):
            return cls.__annotations__

        # Python 3.14+ may have __annotate_func__
        if hasattr(cls, "__annotate_func__"):
            try:
                return cls.__annotate_func__(1)
            except Exception:
                pass

        # Python 3.13 uses __annotate__
        if hasattr(cls, "__annotate__"):
            try:
                return cls.__annotate__(1)
            except Exception:
                pass

        return {}

    def __new__(cls, name: str, bases: Tuple[type, ...], attrs: Dict[str, Any]):
        """
        Creates new RsVariables class with properties for each configuration variable

        :param str name: The name of the class
        :param Tuple[type, ...] bases: The base classes of the class
        :param Dict[str, Any] attrs: The attributes of the class
        :return: The new RsVariables class
        """
        annotations = cls._get_annotations(attrs)

        for attr, config_type in annotations.items():
            if isinstance(config_type, RsVariableType):
                # Create a property for each configuration attribute
                getter = cls.create_getter(attr, config_type)
                attrs[attr] = RsVariableClassProperty(getter)

        # Add an __init__ method to initialize instance attributes
        def __init__(self):
            class_annotations = RsVariablesMeta._get_class_annotations(self.__class__)
            for attr in class_annotations:
                if isinstance(class_annotations[attr], RsVariableType):
                    getattr(self, attr)

        attrs["__init__"] = __init__
        return super(RsVariablesMeta, cls).__new__(cls, name, bases, attrs)

    @staticmethod
    def create_getter(attr: str, config_type: RsVariableType) -> Callable:
        """
        Creates a getter function for each property

        :param str attr: The name of the attribute
        :param RsVariableType config_type: The type of the attribute
        :return: The getter function for the attribute
        :rtype: Callable
        """

        def getter(cls: type) -> Any:
            return RsVariablesMeta.fetch_config_value(attr, config_type)

        return getter

    @staticmethod
    def _camel_to_snake_upper(name: str) -> str:
        """
        Converts a camelCase or snake_case attribute name to UPPER_SNAKE_CASE.

        This is used to derive environment variable names from configuration attribute names.
        For example:
            - qualysUrl -> QUALYS_URL
            - base_url -> BASE_URL
            - azureCloudTenantId -> AZURE_CLOUD_TENANT_ID

        :param str name: The attribute name in camelCase or snake_case
        :return: The name converted to UPPER_SNAKE_CASE
        :rtype: str
        """
        # Insert underscore before uppercase letters (camelCase boundaries)
        result = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
        return result.upper()

    @classmethod
    def _check_mock_override(cls, attr_name: str, app: Any) -> Optional[str]:
        """
        Checks for mock overrides via MOCK_* environment variables or mock* config keys.

        This allows test environments to override configuration values without modifying
        the actual config. The lookup order is:
            1. MOCK_<UPPER_SNAKE_CASE> environment variable
            2. mock<AttrName> config key (with first letter capitalized)

        :param str attr_name: The attribute name to check for mock overrides
        :param Any app: The application instance
        :return: The mock override value, or None if no override is found
        :rtype: Optional[str]
        """
        # Check for MOCK_* environment variable
        env_key = "MOCK_" + cls._camel_to_snake_upper(attr_name)
        mock_env_value = os.environ.get(env_key)
        if mock_env_value is not None:
            logger.debug("Using mock environment override for '%s' from '%s'", attr_name, env_key)
            return mock_env_value

        # Check for mock* config key (e.g., mockQualysUrl for qualysUrl)
        mock_config_key = "mock" + attr_name[0].upper() + attr_name[1:]
        mock_config_value = next(
            (value for key, value in app.config.items() if key == mock_config_key),
            None,
        )
        if mock_config_value is not None:
            logger.debug("Using mock config override for '%s' from '%s'", attr_name, mock_config_key)
            return mock_config_value

        return None

    @classmethod
    def _get_config_from_sources(cls, attr_name: str, app: Any) -> str:
        """
        Retrieves configuration value from environment variables or config file.

        Lookup order:
            1. Environment variable (case-insensitive exact match, e.g. tenableAccessKey)
            2. Environment variable (UPPER_SNAKE_CASE, e.g. TENABLE_ACCESS_KEY)
            3. init.yaml config (case-insensitive match)

        :param str attr_name: The name of the attribute
        :param Any app: The application instance
        :return: The configuration value
        :rtype: str
        """
        # 1. Check environment variable (case-insensitive exact match)
        config_value = next(
            (os.environ[key] for key in os.environ if key.lower() == attr_name.lower()),
            None,
        )
        # 2. Check UPPER_SNAKE_CASE environment variable (e.g. tenableScAccessKey -> TENABLE_SC_ACCESS_KEY)
        if config_value is None:
            snake_key = cls._camel_to_snake_upper(attr_name)
            config_value = os.environ.get(snake_key)

        # 3. Fall back to init.yaml config
        if config_value is None:
            config_value = next(
                (value for key, value in app.config.items() if key.lower() == attr_name.lower()),
                "",
            )
        return cls.replace_text_inside_brackets(config_value)

    @classmethod
    def _handle_missing_value(cls, attr_name: str, config_type: RsVariableType, app: Any) -> str:
        """
        Handles missing configuration values by prompting user or using defaults.

        :param str attr_name: The name of the attribute
        :param RsVariableType config_type: The type of the attribute
        :param Any app: The application instance
        :raises ValueError: If required config is missing and not running interactively
        :return: The configuration value
        :rtype: str
        """
        if config_type.required and config_type.default is None:
            return cls._prompt_for_required_value(attr_name, config_type, app)
        elif config_type.default is not None:
            logger.debug(f"Using default value for '{attr_name}': {config_type.default}")
            return config_type.default
        return ""

    @classmethod
    def _prompt_for_required_value(cls, attr_name: str, config_type: RsVariableType, app: Any) -> str:
        """
        Prompts user for required configuration value interactively.

        :param str attr_name: The name of the attribute
        :param RsVariableType config_type: The type of the attribute
        :param Any app: The application instance
        :raises ValueError: If not running interactively
        :return: The user-entered configuration value
        :rtype: str
        """
        if not sys.stdin.isatty():
            error_message = f"Required configuration '{attr_name}' is missing and script is not running interactively."
            logger.error(error_message)
            raise ValueError(error_message)

        prompt_message = (
            f"\033[91mREQUIRED: {attr_name} not set in init.yaml or environment variable.\033[0m \n"
            f"Enter value for {attr_name} (e.g., {config_type.example}):"
        )
        value = input(prompt_message)

        app.config[attr_name] = value
        if not config_type.hidden:
            app.save_config(app.config)
            log_value = "******" if config_type.sensitive else value
            logger.info(f"Configuration for '{attr_name}' saved to init.yaml: {log_value}")

        return value

    @classmethod
    def _convert_to_type(cls, attr_name: str, value: Any, config_type: RsVariableType) -> Any:
        """
        Converts configuration value to the specified type.

        :param str attr_name: The name of the attribute
        :param Any value: The value to convert
        :param RsVariableType config_type: The type of the attribute
        :return: The typed configuration value
        :rtype: Any
        """
        try:
            if config_type.type is dict:
                return cls._convert_to_dict(value)
            elif config_type.type is bool:
                return cls._convert_to_bool(value)
            else:
                return config_type.type(value)
        except (ValueError, SyntaxError):
            logger.error(f"Failed to cast '{attr_name}' to {config_type.type.__name__}. Using original value.")
            return value

    @staticmethod
    def _convert_to_dict(value: Any) -> dict:
        """Converts value to dictionary."""
        if isinstance(value, str):
            import ast

            return ast.literal_eval(value) if value else {}
        return value if value else {}

    @staticmethod
    def _convert_to_bool(value: Any) -> bool:
        """Converts value to boolean."""
        if isinstance(value, str):
            return value.lower() in ["true", "1", "yes"]
        elif isinstance(value, bool):
            return value
        return bool(value)

    @classmethod
    def fetch_config_value(cls, attr_name: str, config_type: RsVariableType) -> Any:
        """
        Fetches, processes, and returns the configuration value for a given attribute

        :param str attr_name: The name of the attribute
        :param RsVariableType config_type: The type of the attribute
        :raises ValueError: If a required configuration is missing and the script is not running interactively
        :return: The processed configuration value
        :rtype: Any
        """
        from regscale.core.app.application import Application

        app = Application()

        # Check for mock overrides first (MOCK_* env vars or mock* config keys)
        mock_value = cls._check_mock_override(attr_name, app)
        if mock_value is not None:
            return cls._convert_to_type(attr_name, mock_value, config_type)

        # Get configuration value from sources
        processed_value = cls._get_config_from_sources(attr_name, app)

        # Log configuration (safely)
        log_value = "******" if config_type.sensitive else processed_value
        logger.debug(f"Configuration for '{attr_name}' set to: {log_value}")

        # Handle missing or placeholder values
        from regscale.core.app.config import is_placeholder_value

        if processed_value == "" or is_placeholder_value(processed_value):
            processed_value = cls._handle_missing_value(attr_name, config_type, app)

        # Convert to the appropriate type using the helper method
        typed_value = cls._convert_to_type(attr_name, processed_value, config_type)
        return typed_value

    @staticmethod
    def replace_text_inside_brackets(text: str, replacement: str = "") -> str:
        """
        Removes text inside brackets from a given string

        :param str text: The string to remove text from
        :param str replacement: The replacement text
        :return: The string with text inside brackets removed
        :rtype: str
        """
        # if string
        if not isinstance(text, str):
            return text
        pattern = "<[^>]*>"
        return re.sub(pattern, replacement, text)

    @staticmethod
    def get_all_hidden_variables() -> set:
        """
        Collects all hidden variable names from all Variables classes in the codebase.

        This method scans all classes that use RsVariablesMeta as their metaclass
        and returns a set of variable names that have hidden=True.

        :return: Set of hidden variable names (lowercase for case-insensitive comparison)
        :rtype: set
        """
        import gc
        import inspect

        hidden_vars = set()

        # Iterate through all classes in memory
        for obj in gc.get_objects():
            if not inspect.isclass(obj):
                continue

            # Check if this class uses RsVariablesMeta
            if type(obj) is not RsVariablesMeta:
                continue

            # Get annotations for this class
            annotations = RsVariablesMeta._get_class_annotations(obj)

            # Check each annotated attribute
            for attr_name, config_type in annotations.items():
                if isinstance(config_type, RsVariableType) and config_type.hidden:
                    # Store in lowercase for case-insensitive comparison
                    hidden_vars.add(attr_name.lower())

        return hidden_vars
