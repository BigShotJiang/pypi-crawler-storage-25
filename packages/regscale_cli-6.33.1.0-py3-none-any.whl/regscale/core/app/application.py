#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Application Configuration"""

import contextlib
import inspect
import json
import os
import platform
import sys
from typing import Any, Optional, Tuple, Union
from urllib.parse import urljoin

import requests
import yaml
from pydantic import Field
from requests import Response
from yaml.scanner import ScannerError

from regscale.core.app.config import Config
from regscale.core.app.config_defaults import get_default_template
from regscale.core.app.internal.encrypt import IOA21H98
from regscale.core.app.logz import create_logger
from regscale.utils.threading.threadhandler import ThreadManager

CONTENT_TYPE_JSON = "application/json"
BEARER_PREFIX = "Bearer "

# Pre-computed control characters for stripping (0x00-0x1F and 0x7F-0x9F)
CONTROL_CHARS = "".join([chr(i) for i in range(0x00, 0x20)]) + "".join([chr(i) for i in range(0x7F, 0xA0)])


class Singleton(type):
    """
    Singleton class to prevent multiple instances of Application
    """

    _instances = {}

    def __call__(cls, *args, **kwargs):
        """Control instance creation for singleton pattern.

        :param args: Positional arguments for instance creation
        :param kwargs: Keyword arguments for instance creation
        :return: Singleton instance of the class
        """
        if cls not in cls._instances or kwargs.get("config"):
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

    @classmethod
    def reset_all(mcs):
        """Reset all singleton instances - for testing only.

        This method clears all singleton instances, allowing tests to start with a clean state.
        Should only be called from test fixtures or test setup/teardown methods.
        """
        mcs._instances.clear()

    @classmethod
    def reset_class(mcs, cls):
        """Reset specific singleton class - for testing only.

        This method removes a specific singleton instance, allowing tests to create a fresh instance.
        Should only be called from test fixtures or test setup/teardown methods.

        :param cls: The class to reset
        """
        if cls in mcs._instances:
            del mcs._instances[cls]


class Application(metaclass=Singleton):
    """
    RegScale CLI configuration class

    :param Optional[dict] config: Configuration dictionary to use instead of init.yaml, defaults to None
    :param bool local_config: Whether to use the local config file, defaults to True
    """

    config: dict = Field(default_factory=dict)

    def __init__(
        self,
        config: Optional[dict] = None,
        local_config: bool = True,
    ):
        self.config_file = os.getenv("REGSCALE_CONFIG_FILE", "init.yaml")
        self.api_handler = None
        # Get template from centralized config_defaults module
        template = get_default_template()
        logger = create_logger()
        if os.environ.get("LOGLEVEL", "INFO").upper() == "DEBUG":
            stack = inspect.stack()
            logger.debug("*" * 80)
            logger.debug(f"Initializing Application from {stack[1].filename}")
            logger.debug("*" * 80)
            logger.debug(f"Initializing in directory: {os.getcwd()}")
        self.template = template
        self.templated = False
        self.logger = logger
        self.local_config = local_config
        self.running_in_airflow = os.getenv("REGSCALE_AIRFLOW") == "true"
        if isinstance(config, str):
            config = self._read_config_from_str(config)
        if self.running_in_airflow:
            self.config = self._fetch_config_from_regscale(config)
        else:
            self.config = self._gen_config(config)
        self.os = platform.system()
        self.input_host = ""
        # Ensure maxThreads is an integer for ThreadManager
        max_threads = self.config.get("maxThreads", 100)
        if not isinstance(max_threads, int):
            logger.debug(f"maxThreads is not an integer: {max_threads} (type: {type(max_threads)})")
            try:
                max_threads = int(max_threads)
                logger.debug(f"Converted maxThreads to integer: {max_threads}")
            except (ValueError, TypeError) as e:
                logger.warning(
                    f"Failed to convert maxThreads '{max_threads}' to integer: {e}. Using default value 100."
                )
                max_threads = 100
        self.thread_manager = ThreadManager(max_threads)
        logger.debug("Finished Initializing Application")
        logger.debug("*" * 80)

    def __getitem__(self, key: Any) -> Any:
        """
        Get an item

        :param Any key: key to retrieve
        :return: value of provided key
        :rtype: Any
        """
        return self.config.__getitem__(key)

    def __setitem__(self, key: Any, value: Any) -> None:
        """
        Set an item

        :param Any key: Key to set the provided value
        :param Any value: Value to set the provided key
        :rtype: None
        """
        self.config.__setitem__(key, value)

    def __delitem__(self, key: Any) -> None:
        """
        Delete an item

        :param Any key: Key desired to delete
        :rtype: None
        """
        self.config.__delitem__(key)

    def __iter__(self):
        """
        Return iterator
        """
        return self.config.__iter__()

    def __len__(self) -> int:
        """
        Get the length of the config

        :return: # of items in config
        :rtype: int
        """
        return len(self.config) if self.config is not None else 0

    def __contains__(self, x: str) -> bool:
        """
        Check config if it contains string

        :param str x: String to check if it exists in the config
        :return: Whether the provided string exists in the config
        :rtype: bool
        """
        return self.config.__contains__(x)

    def _read_config_from_str(self, config: str) -> dict:
        """
        Tries to convert the provided config string to a dictionary, and if it fails, try to use the
        string as a file path, and if that fails it will return an empty dictionary

        :param str config: String to try and convert to a dictionary before trying to use as a file path
        :return: Dictionary of provided string or file, or an empty dictionary
        :rtype: dict
        """
        try:
            return json.loads(config)
        except json.JSONDecodeError:
            self.config_file = config
            try:
                config = self._get_conf()
                return config
            except Exception as ex:
                self.logger.debug(f"Unable to load config from file: {ex}")
                return {}

    def _try_local_config_fallback(self, config: dict) -> Optional[dict]:
        """Try loading from local init.yaml and environment variables.

        :param dict config: Configuration dictionary
        :return: Local config if successful, None otherwise
        :rtype: Optional[dict]
        """
        self.logger.info("Using local configuration fallback")
        try:
            local_config = self._gen_config(config)
            if local_config and "domain" in local_config and "token" in local_config:
                self.logger.info("Successfully loaded config from local sources")
                return local_config
        except Exception as ex:
            self.logger.warning("Local config fallback failed: %s", ex)
        return None

    def _try_minimal_config_fallback(self, config: dict, domain: Optional[str], token: Optional[str]) -> Optional[dict]:
        """Use minimal config from provided parameters and environment.

        :param dict config: Configuration dictionary
        :param Optional[str] domain: Domain URL
        :param Optional[str] token: Authentication token
        :return: Minimal config if valid, None otherwise
        :rtype: Optional[dict]
        """
        if not config or not isinstance(config, dict):
            return None

        self.logger.warning("Using minimal config from provided parameters")
        minimal_config = {**self.template, **config}

        # Ensure critical keys from environment if not in config
        if ("domain" not in minimal_config or minimal_config["domain"] == self.template["domain"]) and domain:
            minimal_config["domain"] = domain
        if "token" not in minimal_config and token:
            minimal_config["token"] = token

        if "domain" in minimal_config and "token" in minimal_config:
            return minimal_config
        return None

    def _parse_app_id(self, token: str) -> int:
        """
        Decode JWT from RegScale to get the app id from the payload

        :param str token: the JWT to decode
        :raises ValueError: if the JWT token is invalid
        :return: the app id
        :rtype: int
        """
        import json

        from regscale.core.app.internal.login import _decode_base64

        if token.startswith(BEARER_PREFIX):
            token = token.split(" ", 1)[1]

        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError(
                "Invalid JWT token format. Provided token is not a valid JWT token. Token: %s",
                token,
            )

        payload = json.loads(_decode_base64(parts[1]).decode("utf-8"))
        if "appId" not in payload:
            self.logger.debug("No app id found in JWT token, defaulting to 1")
            return 1
        else:
            return payload["appId"]

    def _determine_config_url(self, domain: str, token: str) -> Tuple[str, bool]:
        """Determine the configuration URL based on the domain.

        :param str domain: Domain URL
        :param str token: Authentication token, used to parse the app id
        :return: Configuration URL, and a boolean indicating if the config is in yaml format
        :rtype: Tuple[str, bool]
        """
        # use a different url if RegScale version >=  6.29.0.2
        from regscale.utils.version import RegscaleVersion

        if RegscaleVersion.compare_versions(RegscaleVersion.get_platform_version(), "6.29.0.2"):
            app_id = self._parse_app_id(token)
            return urljoin(domain, f"/api/apps/{app_id}/automation/cli-config/yaml"), True
        else:
            return urljoin(domain, "/api/tenants/getCliConfig"), False

    def _fetch_remote_config(self, domain: str, token: str) -> Optional[dict]:
        """Fetch configuration from RegScale API.

        :param str domain: Domain URL
        :param str token: Authentication token
        :return: Fetched config if successful, None otherwise
        :rtype: Optional[dict]
        """
        self.logger.info("Fetching config from %s...", domain)
        try:
            url, is_yaml = self._determine_config_url(domain, token)
            response = requests.get(
                url=url,
                headers={
                    "Content-Type": CONTENT_TYPE_JSON,
                    "Accept": CONTENT_TYPE_JSON,
                    "Authorization": token,
                },
            )
            self.logger.debug("Config fetch response status_code: %s", response.status_code)

            # Get the encrypted config from the response
            fetched_config = response.json()
            if not fetched_config or response.text == "":
                self.logger.warning("No secrets found in %s", domain)
                return None
            elif is_yaml:
                try:
                    parsed_dict = yaml.safe_load(fetched_config)
                except yaml.YAMLError as yaml_err:
                    self.logger.error("Failed to parse YAML config from %s: %s", domain, yaml_err)
                    return None
            elif isinstance(fetched_config, dict):
                # Config is already a dictionary
                parsed_dict = fetched_config
            else:
                # Config needs decryption
                decrypted_config = self._decrypt_config(fetched_config, token)
                parsed_dict = json.loads(decrypted_config)

            parsed_dict["token"] = token
            parsed_dict["domain"] = domain
            from regscale.core.app.internal.login import parse_user_id_from_jwt

            parsed_dict["userId"] = parsed_dict.get("userId") or parse_user_id_from_jwt(self, token)
            self.logger.info("Successfully fetched config from RegScale.")
            # fill in any missing keys with the template
            return {**self.template, **parsed_dict}
        except Exception as ex:
            self.logger.error("Unable to fetch config from RegScale: %s", str(ex))
            self.logger.info("Attempting fallback to local configuration...")
            return None

    def _parse_response_config(self, response: Response) -> Optional[Any]:
        """Parse configuration from API response.

        :param Response response: HTTP response object
        :return: Parsed config (dict or str) or None if empty
        :rtype: Optional[Any]
        """
        try:
            return response.json()
        except ValueError:
            # Response is not JSON, treat the text as encrypted config
            return response.text.strip().strip('"')  # Remove quotes if present

    def _parse_config_to_dict(self, fetched_config: Any, token: str) -> dict:
        """Convert fetched config to dictionary, decrypting if necessary.

        :param Any fetched_config: Config from API (dict or encrypted string)
        :param str token: Bearer token for decryption
        :return: Parsed configuration dictionary
        :rtype: dict
        """
        if isinstance(fetched_config, dict):
            return fetched_config
        decrypted_config = self._decrypt_config(fetched_config, token)
        # Try YAML first (handles both YAML and JSON), fall back to JSON
        try:
            return yaml.safe_load(decrypted_config)
        except yaml.YAMLError:
            return json.loads(decrypted_config)

    def _build_fallback_config(
        self,
        domain: Optional[str],
        token: Optional[str],
        provided_config: Optional[dict] = None,
    ) -> dict:
        """Build fallback config with domain and token preserved.

        Merges the provided config (e.g. dag_run.conf) so that integration-specific
        keys like wizUrl, wizClientId, etc. are not lost when remote fetch fails.

        :param Optional[str] domain: Domain URL
        :param Optional[str] token: Authentication token
        :param Optional[dict] provided_config: Original config dict to merge (e.g. dag_run.conf)
        :return: Fallback configuration dictionary
        :rtype: dict
        """
        fallback_config = self.template.copy()
        if provided_config:
            fallback_config.update(provided_config)
        if domain:
            fallback_config["domain"] = domain
        if token:
            # Ensure token has Bearer prefix for consistency
            if not token.startswith(BEARER_PREFIX):
                token = f"{BEARER_PREFIX}{token}"
            fallback_config["token"] = token
        return fallback_config

    def _fetch_config_from_regscale(self, config: Optional[dict] = None) -> dict:
        """
        Fetch config from RegScale via API with multi-tier fallback.

        Token resolution order:
        1. Provided config dict (e.g., from Airflow dag_run.conf)
        2. Environment variable REGSCALE_TOKEN

        Domain resolution order:
        1. Provided config dict
        2. Environment variable REGSCALE_DOMAIN
        3. Local init.yaml via retrieve_domain()

        :param Optional[dict] config: configuration dictionary, defaults to None
        :return: Combined config from RegScale and the provided config
        :rtype: dict
        """
        # Track whether config was explicitly provided (even if empty)
        config_was_provided = config is not None
        config = config or {}

        # Log config status at debug level only (security: don't expose config keys in production logs)
        if config_was_provided and config:
            self.logger.debug("Config provided with %d keys", len(config.keys()))
        else:
            self.logger.debug("No config provided, will use environment/local fallbacks")

        # Resolve token: config -> environment
        token = config.get("token") or os.getenv("REGSCALE_TOKEN")

        # Resolve domain: config -> environment -> local init.yaml
        domain = config.get("domain") or os.getenv("REGSCALE_DOMAIN")
        if not domain or "http" not in domain or domain == self.template.get("domain"):
            domain = self.retrieve_domain().rstrip("/")

        # Log token status (security: only log presence, not content)
        if token:
            self.logger.debug("Token found (length: %d)", len(token))
        elif config_was_provided and config:
            # Config was provided but no token - this is likely a problem
            self.logger.warning("Config provided but no token found! Check dag_run.conf or REGSCALE_TOKEN env var.")
        else:
            # No config provided at all - this is expected during early imports
            self.logger.debug("No token available (no config provided, no REGSCALE_TOKEN env var)")

        self.logger.debug("Domain resolved to: %s", domain)

        # Need both domain and token for remote fetch
        if not domain or not token:
            self.logger.debug("Skipping remote config fetch (domain=%s, token=%s)", bool(domain), bool(token))
            return self._build_fallback_config(domain, token, provided_config=config)

        # Try remote fetch
        result = self._attempt_remote_fetch(domain, token)
        if result is not None:
            self.logger.info("Using configuration fetched from RegScale API.")
            # Merge order: template (defaults) < config (dag_run.conf) < result (remote API)
            # This ensures integration-specific keys from dag_run.conf (wizUrl, wizClientId, etc.)
            # are preserved unless the remote API explicitly provides them.
            return {**self.template, **config, **result}

        return self._build_fallback_config(domain, token, provided_config=config)

    def _attempt_remote_fetch(self, domain: str, token: str) -> Optional[dict]:
        """Attempt to fetch configuration from remote RegScale API.

        :param str domain: Domain URL
        :param str token: Authentication token
        :return: Configuration dict if successful, None otherwise
        :rtype: Optional[dict]
        """
        # Ensure token has Bearer prefix for API requests
        if not token.startswith(BEARER_PREFIX):
            token = f"{BEARER_PREFIX}{token}"

        self.logger.info("Fetching config from %s...", domain)
        try:
            response = requests.get(
                url=urljoin(domain, "/api/tenants/getDetailedCliConfig"),
                headers={
                    "Content-Type": CONTENT_TYPE_JSON,
                    "Accept": CONTENT_TYPE_JSON,
                    "Authorization": token,
                },
            )
            self.logger.debug("Config fetch response status_code: %s", response.status_code)

            fetched_config = self._parse_response_config(response)
            if not fetched_config or response.text == "":
                self.logger.warning("No secrets found in %s", domain)
                return None  # Let caller use _build_fallback_config to preserve domain/token

            parsed_dict = self._parse_config_to_dict(fetched_config, token)
            parsed_dict["token"] = token
            parsed_dict["domain"] = domain

            from regscale.core.app.internal.login import parse_user_id_from_jwt

            parsed_dict["userId"] = parsed_dict.get("userId") or parse_user_id_from_jwt(self, token)
            self.logger.info("Successfully fetched config from RegScale.")
            return parsed_dict
        except Exception as ex:
            self.logger.error("Unable to fetch config from RegScale.\n%s", str(ex))
            return None

    def _clean_decrypted_string(self, decoded: str) -> str:
        """
        Clean decrypted string by removing padding, null bytes, and control characters.

        :param str decoded: The decoded UTF-8 string from decryption
        :return: Cleaned string ready for YAML/JSON parsing
        :rtype: str
        """
        import re

        # Remove trailing whitespace
        cleaned = decoded.rstrip()
        # Remove trailing null bytes
        cleaned = cleaned.rstrip("\0")
        # Remove trailing backslash patterns (handles literal backslashes and control chars like \x0e)
        cleaned = re.sub(r"\\[^\\]*$", "", cleaned)
        # Remove trailing control characters using pre-computed constant
        return cleaned.rstrip(CONTROL_CHARS)

    def _validate_yaml_json(self, content: str) -> bool:
        """
        Validate that content is valid YAML or JSON.

        :param str content: String content to validate
        :return: True if valid, False otherwise
        :rtype: bool
        """
        if not content or not content.strip():
            self.logger.error("Decryption produced empty result")
            return False
        try:
            yaml.safe_load(content)
            return True
        except yaml.YAMLError as yaml_err:
            self.logger.error("Decrypted config is not valid YAML/JSON: %s", yaml_err)
            return False

    def _decrypt_config(self, encrypted_text: str, bearer_token: str) -> str:
        """
        Decrypt the configuration using AES encryption with the bearer token as key

        :param str encrypted_text: Base64 encoded encrypted text
        :param str bearer_token: Bearer token used as encryption key
        :return: Decrypted configuration string
        :rtype: str
        """
        import base64
        import hashlib

        from cryptography.hazmat.backends import default_backend
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

        try:
            # Decode base64 and extract IV (first 16 bytes) and cipher text
            combined = base64.b64decode(encrypted_text)
            iv = combined[:16]
            cipher_text = combined[16:]

            # Generate key from bearer token using SHA256
            key = hashlib.sha256(bearer_token.encode()).digest()

            # Create cipher and decrypt
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
            decryptor = cipher.decryptor()
            decrypted = decryptor.update(cipher_text) + decryptor.finalize()

            # Clean the decrypted string
            cleaned = self._clean_decrypted_string(decrypted.decode("utf-8"))

            # Validate and return
            if not self._validate_yaml_json(cleaned):
                return "{}"
            return cleaned
        except Exception as err:
            self.logger.error("Unable to decrypt config: %s", err)
            return "{}"

    def _load_config_from_click_context(self) -> Optional[dict]:
        """
        Load configuration from Click context

        :return: Configuration dictionary
        :rtype: Optional[dict]
        """
        try:
            import click

            ctx = click.get_current_context()
            if ctx and ctx.obj and "CONFIG" in ctx.obj:
                self.logger.debug("Found config in Click context...")
                if click_config := ctx.obj["CONFIG"]:
                    self.logger.debug("Using config from Click context")
                    # Use Config class for proper merge with ExampleConfig handling
                    config_manager = Config(auto_load=False)
                    config_manager._data = click_config
                    config_manager.merge_defaults(self.template)
                    config = config_manager.to_dict()
                    self.save_config(config, reason="click_context")
                    ctx.obj["CONFIG"] = config
                    return config
        except (RuntimeError, ImportError):
            # RuntimeError is raised when there's no active Click context
            # ImportError is raised if Click is not available
            pass
        return None

    def _gen_config(self, config: Optional[Union[dict, str]] = None) -> dict:
        """
        Generate the Application config from file or environment

        :param Optional[Union[dict, str]] config: Configuration dictionary, defaults to None
        :raises: TypeError if unable to generate config file
        :return: configuration as a dictionary
        :rtype: dict
        """
        # Check for Click context first
        if click_config := self._load_config_from_click_context():
            self.logger.debug("Successfully retrieved config from Click context.")
            return click_config

        try:
            if config and self.local_config:
                self.logger.debug("Config provided as: %s", type(config))
                file_config = config
            elif not self.local_config:
                file_config = {}
            else:
                file_config = self._get_conf() or {}
            # Merge: file_config <- env overrides <- template defaults
            # Uses Config class for proper merge with ExampleConfig handling
            env = self._get_env()
            self.logger.debug(
                "Merging config: template keys=%d, file keys=%d, env overrides=%d",
                len(self.template),
                len(file_config),
                len(env),
            )
            # Apply env overrides to file_config
            user_config = {**file_config, **env}
            # Use verify_config to merge template defaults (handles ExampleConfig)
            config = self.verify_config(self.template, user_config)
            # Only save if we successfully loaded and merged config
            if config is not None:
                try:
                    self.save_config(config, reason="gen_config")
                except Exception as save_error:
                    # Don't crash CLI startup if save fails - config is still valid in memory
                    # This can happen with ConfigSafetyError or file permission issues
                    self.logger.warning(
                        "Could not save config during initialization: %s. Config loaded in memory.",
                        save_error,
                    )
        except ScannerError as e:
            # YAML parsing error - use template in memory but DON'T overwrite the file
            # The file may be corrupted or partially written, we don't want to lose data
            self.logger.error(
                "YAML parsing error in %s: %s\n"
                "Using template defaults in memory (config file NOT overwritten).\n"
                "To recover, either:\n"
                "  1. Fix the YAML syntax errors manually in %s\n"
                "  2. Restore from backup: regscale config_backups --restore-latest\n"
                "  3. Reset to defaults: regscale init --force",
                self.config_file,
                e,
                self.config_file,
            )
            config = self.template
        except TypeError:
            self.logger.error("ERROR: %s has been encrypted! Please decrypt it before proceeding.\n", self.config_file)
            IOA21H98(self.config_file)
            sys.exit()
        # Return config
        return config

    def _get_airflow_config(self, config: Optional[Union[dict, str]] = None) -> Optional[dict]:
        """
        Get config from Airflow DAG config, or from the environment variables if not provided.

        :param Optional[Union[dict, str]] config: Configuration dictionary, defaults to None
        :return: Configuration dictionary
        :rtype: Optional[dict]
        """
        if config:
            self.logger.debug(f"Received config from Airflow as: {type(config)}")
            # check to see if config is a string because airflow can pass a string instead of a dict
            try:
                config = json.loads(config.replace("'", '"')) if isinstance(config, str) else config
            except json.JSONDecodeError:
                return None
            if isinstance(config, dict):
                config = self._fetch_config_from_regscale(config=config)
            if isinstance(config, str):
                config = self._read_config_from_str(config)
            return config
        elif os.getenv("REGSCALE_TOKEN") and os.getenv("REGSCALE_DOMAIN"):
            self.logger.debug("No config provided, fetching from RegScale via api.")
            return self._fetch_config_from_regscale(
                config={
                    "token": os.getenv("REGSCALE_TOKEN"),
                    "domain": os.getenv("REGSCALE_DOMAIN"),
                }
            )
        return config or None

    def _get_env(self) -> dict:
        """
        Return dict of RegScale configuration keys from environment variables.

        Only returns keys that are actually set in the environment, not
        the full template. This prevents environment config from overwriting
        user-configured values in init.yaml during merge.

        :return: Dictionary of environment variable overrides
        :rtype: dict
        """
        all_keys = self.template.keys()
        sys_keys = [key for key in os.environ if key in all_keys]
        # Only include environment variables that are actually set
        dat = {}
        try:
            for k in sys_keys:
                dat[k] = os.environ[k]
        except KeyError as ex:
            self.logger.error("Key Error!!: %s", ex)
        self.logger.debug("Environment overrides: %s", list(dat.keys()))
        # templated is True when no environment variables override template keys
        self.templated = len(dat) == 0
        return dat

    def _get_conf(self) -> dict:
        """
        Get configuration from init.yaml if exists.

        Uses FileLock to prevent corruption when multiple processes
        (pytest workers, Airflow tasks, etc.) access the file simultaneously.

        :return: Application config
        :rtype: dict
        """
        # Lazy import to avoid circular dependency
        from regscale.models.locking import FileLock

        config = None
        # Use FileLock for cross-process file locking
        # Lock file is specific to the config file being read
        lock_file = f"results/{os.path.basename(self.config_file)}.lock"
        with FileLock(lock_file=lock_file):
            try:
                with open(self.config_file, encoding="utf-8") as stream:
                    self.logger.debug(f"Loading {self.config_file}")
                    from regscale.core.app.safe_config import SafeConfigManager

                    config = SafeConfigManager._yaml_load_tolerant(stream)
            except FileNotFoundError as ex:
                self.logger.debug(
                    "%s!\n This RegScale CLI application will create the %s file in the current working directory.",
                    ex,
                )
            except yaml.YAMLError as yaml_ex:
                self.logger.error(f"Failed to parse {self.config_file}: {yaml_ex}. File may be corrupted.")
                config = None
            finally:
                self.logger.debug("_get_conf: %s, %s", config, type(config))
        return config

    def save_config(self, conf: dict, reason: str = "unspecified", force: bool = False) -> None:
        """
        Save Configuration to init.yaml using atomic file operations and cross-process
        file locking to prevent corruption during parallel writes.

        SafeConfigManager handles:
        - Cross-process file locking (FileLock) to prevent concurrent writes
        - Atomic file writes (temp file + rename)
        - Automatic backups before changes
        - Validation to prevent data loss (critical keys, empty dicts, etc.)

        Hidden variables (those with hidden=True in RsVariableType) are automatically
        filtered out and will not be persisted to init.yaml. They can still be accessed
        via environment variables or set in memory at runtime.

        :param dict conf: Application configuration
        :param str reason: Reason for the config change (for logging/audit)
        :param bool force: If True, bypass safety checks (use with caution).
            Use force=True ONLY when:
            - Intentionally resetting config to minimal state
            - Restoring from backup
            - In test environments
            DO NOT use force=True for normal config updates.
        :raises ConfigSafetyError: If save would cause significant data loss (unless force=True)
        :rtype: None
        """
        self.config = conf
        if self.api_handler is not None:
            self.api_handler.config = conf
            self.api_handler.domain = conf.get("domain") or self.retrieve_domain()
        if self.running_in_airflow:
            self.logger.debug(
                "Updated config and not saving to %s because CLI is running in an Airflow container.",
                self.config_file,
            )
            return None

        # Filter out hidden variables before saving to init.yaml
        from regscale.core.app.utils.variables import RsVariablesMeta

        hidden_vars = RsVariablesMeta.get_all_hidden_variables()
        filtered_conf = {k: v for k, v in conf.items() if k.lower() not in hidden_vars}

        # Log filtered variables for debugging
        if hidden_vars:
            filtered_keys = [k for k in conf.keys() if k.lower() in hidden_vars]
            if filtered_keys:
                self.logger.debug(
                    "Filtering %d hidden variable(s) from init.yaml: %s",
                    len(filtered_keys),
                    ", ".join(filtered_keys),
                )

        # SafeConfigManager handles cross-process locking, atomic writes, and validation
        from regscale.core.app.safe_config import SafeConfigManager

        try:
            self.logger.debug("Saving config to %s (reason: %s).", self.config_file, reason)
            # SafeConfigManager handles cross-process locking, atomic writes, and validation
            safe_manager = SafeConfigManager(config_path=self.config_file)
            safe_manager.safe_save(filtered_conf, force=force, reason=reason)
        except OSError as e:
            self.logger.error("Could not save config to %s: %s", self.config_file, e)

    # Has to be Any class to prevent circular imports
    def get_regscale_license(self, api: Any) -> Optional[Response]:
        """
        Get RegScale license of provided application via provided API object

        :param Any api: API object
        :return: API response, if successful or None
        :rtype: Optional[Response]
        """
        config = self.config or api.config
        if config is None and self.running_in_airflow:
            config = self._get_airflow_config()
        elif config is None:
            config = self._gen_config()
        domain = config.get("domain") or self.retrieve_domain()
        if domain.endswith("/"):
            domain = domain[:-1]
        with contextlib.suppress(requests.RequestException):
            return api.get(url=urljoin(domain, "/api/config/getLicense").lower())
        return None

    def load_config(self) -> dict:
        """
        Load Configuration file: init.yaml using cross-process file locking.

        Uses FileLock to prevent corruption when multiple processes
        access the file simultaneously.

        :return: Dict of config
        :rtype: dict
        """
        # Lazy import to avoid circular dependency
        from regscale.models.locking import FileLock

        # Use FileLock for cross-process file locking
        lock_file = f"results/{os.path.basename(self.config_file)}.lock"
        try:
            with FileLock(lock_file=lock_file):
                with open(self.config_file, "r", encoding="utf-8") as stream:
                    from regscale.core.app.safe_config import SafeConfigManager

                    return SafeConfigManager._yaml_load_tolerant(stream)
        except FileNotFoundError:
            return {}
        except yaml.YAMLError as yaml_ex:
            self.logger.error(f"Failed to parse {self.config_file}: {yaml_ex}. File may be corrupted.")
            return {}

    def retrieve_domain(self) -> str:
        """
        Retrieve the domain from the OS environment if it exists

        :return: The domain
        :rtype: str
        """
        self.logger.debug("Unable to determine domain, using retrieve_domain()...")
        # REGSCALE_DOMAIN is the default host
        for envar in ["REGSCALE_DOMAIN", "PLATFORM_HOST", "domain"]:
            if host := os.environ.get(envar):
                if host.startswith("http"):
                    self.logger.debug(f"Found {envar}={host} in environment.")
                    return host
        return "https://regscale.yourcompany.com/"

    def verify_config(self, template: dict, config: dict) -> dict:
        """
        Verify and merge configuration with template defaults.

        This method merges template values into the config, preserving user values.
        Uses the Config class's non-destructive merge logic.

        :param dict template: Template configuration with default values
        :param dict config: User configuration to verify
        :return: Merged configuration dictionary
        :rtype: dict
        """
        # Use Config class for non-destructive merge
        config_manager = Config(auto_load=False)
        config_manager._data = config.copy()
        config_manager.merge_defaults(template)
        return config_manager.to_dict()

    def merge_defaults_non_destructive(self, defaults: Optional[dict] = None) -> dict:
        """
        Merge defaults into current config without overwriting user-modified values.

        This method uses the Config class to perform non-destructive merging:
        - Only adds keys that don't exist in the current config
        - Preserves all user-modified values
        - Handles nested dictionaries recursively

        :param Optional[dict] defaults: Default values to merge (uses template if None)
        :return: Merged configuration dictionary
        :rtype: dict
        """
        if defaults is None:
            defaults = self.template

        # Use the Config class for non-destructive merge
        config_manager = Config(config_path=self.config_file, auto_load=True)
        config_manager.merge_defaults(defaults)
        return config_manager.to_dict()

    def init_config(self, preserve_values: bool = True) -> dict:
        """
        Initialize or update the configuration file.

        When preserve_values is True (default), this method:
        - Preserves all user-modified values in the existing config
        - Only adds new keys from the template that don't exist
        - Uses type coercion where applicable

        When preserve_values is False:
        - Resets config to template defaults with environment variable overrides
        - Creates a backup of existing config before overwriting

        :param bool preserve_values: Whether to preserve existing user values (default: True)
        :return: The initialized configuration
        :rtype: dict
        """
        if preserve_values:
            # Non-destructive: merge template into existing config
            merged_config = self.merge_defaults_non_destructive(self.template)
            self.config = merged_config
            self.save_config(merged_config, reason="init_preserve")
            return merged_config
        else:
            # Destructive: reset to template defaults with environment overrides
            # IMPORTANT: Start from template, then apply env overrides
            # This ensures we never save an empty config
            import copy

            reset_config = copy.deepcopy(self.template)
            env_overrides = self._get_env()
            reset_config.update(env_overrides)
            self.config = reset_config
            self.save_config(reset_config, reason="init_reset", force=True)
            return reset_config
