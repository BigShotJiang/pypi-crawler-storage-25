#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI Logging"""

# standard python imports
import logging
import os
import sys
import tempfile
from logging.handlers import TimedRotatingFileHandler
from typing import Any, Optional


class ColoredFormatter(logging.Formatter):
    """
    A logging formatter that adds ANSI color codes based on log level.

    Colors:
        DEBUG: cyan
        INFO: green
        WARNING: yellow
        ERROR: red
        CRITICAL: bold red
    """

    RESET = "\033[0m"
    COLORS = {
        logging.DEBUG: "\033[36m",  # cyan
        logging.INFO: "\033[32m",  # green
        logging.WARNING: "\033[33m",  # yellow
        logging.ERROR: "\033[31m",  # red
        logging.CRITICAL: "\033[1;31m",  # bold red
    }

    def format(self, record: logging.LogRecord) -> str:
        """
        Format the log record with ANSI color codes around the level name.

        :param logging.LogRecord record: The log record to format
        :return: The formatted log string with color codes
        :rtype: str
        """
        color = self.COLORS.get(record.levelno, self.RESET)
        original_levelname = record.levelname
        record.levelname = f"{color}{record.levelname}{self.RESET}"
        result = super().format(record)
        record.levelname = original_levelname
        return result


class AirflowStreamHandler(logging.Handler):
    """
    Custom Handler for Airflow that writes all logs to stderr.

    Airflow only captures stderr (not stdout), so all logs must go to stderr to be visible.
    Airflow adds its own timestamp prefix, so we don't include a timestamp in our format.
    The log level is preserved in the formatted message (via [%(levelname)s]),
    which helps identify the actual log level even though Airflow may display them in the error section.
    """

    terminator = "\n"  # Line terminator for log records

    def __init__(self):
        super().__init__()

    def emit(self, record: logging.LogRecord) -> None:
        """
        Emit a log record to stderr (where Airflow captures logs).

        Since Airflow only captures stderr, all logs go there.
        The formatted message includes [INFO], [DEBUG], [WARNING], [ERROR], etc.
        so the log level is preserved even though Airflow may display them in the error section.

        :param logging.LogRecord record: The log record to emit
        """
        try:
            msg = self.format(record)
            formatted_msg = msg + self.terminator

            # Write all logs to stderr since Airflow only captures stderr
            # The log level is preserved in the formatted message format
            sys.stderr.write(formatted_msg)
            sys.stderr.flush()
        except (KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            # Log the error but don't let it propagate to avoid infinite loops
            # Use handleError which will write to stderr if possible
            self.handleError(record)


class TqdmLoggingHandler(logging.Handler):
    """Logging handler that uses tqdm.write() to avoid interleaving with progress bars.

    When tqdm progress bars are active, normal stderr writes corrupt the display.
    tqdm.write() clears the bar, writes the message, and redraws the bar cleanly.
    """

    def emit(self, record: logging.LogRecord) -> None:
        try:
            from tqdm import tqdm

            msg = self.format(record)
            tqdm.write(msg, file=sys.stderr)
        except (KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            # Fallback to stderr if tqdm.write fails
            try:
                sys.stderr.write(self.format(record) + "\n")
            except Exception:
                pass
            self.handleError(record)


def create_logger(propagate: Optional[bool] = None, custom_handler: Optional[Any] = None) -> logging.Logger:
    """
    Create a logger for use in all cases

    :param Optional[bool] propagate: Whether to propagate the logger, defaults to None
    :param Optional[Any] custom_handler: Custom handler to add to the logger, defaults to None
    :return: logger object
    :rtype: logging.Logger
    """
    loglevel = os.environ.get("LOGLEVEL", "INFO").upper()
    # Convert string log level to logging constant
    numeric_level = getattr(logging, loglevel, logging.INFO)

    # Check if running in Airflow - use simple StreamHandler instead of colored handler
    running_in_airflow = os.getenv("REGSCALE_AIRFLOW") == "true"

    if running_in_airflow:
        # Use custom AirflowStreamHandler that writes all logs to stderr
        # Airflow captures stderr and adds its own timestamp prefix, so we don't include timestamp
        # Disable propagation to avoid duplicates with Airflow's handlers
        stream_handler = AirflowStreamHandler()
        stream_handler.setLevel(numeric_level)
        # Format includes levelname but no timestamp (Airflow adds its own timestamp prefix)
        formatter = logging.Formatter("[%(levelname)s] %(name)s - %(message)s")
        stream_handler.setFormatter(formatter)
        handlers: list[logging.Handler] = [stream_handler]
    else:
        # Use tqdm-aware handler so log lines don't interleave with progress bars
        console_handler = TqdmLoggingHandler()
        console_handler.setLevel(numeric_level)
        colored_formatter = ColoredFormatter("[%(levelname)s] %(module)s - %(message)s")
        console_handler.setFormatter(colored_formatter)
        handlers: list[logging.Handler] = [console_handler]

        # Only create file handler if not in container
        if os.getenv("REGSCALE_ECS", False) != "True":
            file_handler = TimedRotatingFileHandler(
                filename=f"{tempfile.gettempdir()}{os.sep}RegScale.log",
                when="D",
                interval=3,
                backupCount=10,
            )
            file_handler.setLevel(numeric_level)
            handlers.append(file_handler)

    if custom_handler:
        handlers.append(custom_handler)

    logging.getLogger("botocore").setLevel(logging.CRITICAL)

    # In Airflow mode, configure logger with our custom handler
    if running_in_airflow:
        logger = logging.getLogger("regscale")
        # Remove any existing handlers of the same type to avoid duplicates
        logger.handlers = [h for h in logger.handlers if not isinstance(h, AirflowStreamHandler)]
        # Add our custom handler
        for handler in handlers:
            logger.addHandler(handler)
        logger.setLevel(numeric_level)
        # Disable propagation to avoid duplicates - our handler writes to stderr which Airflow captures
        logger.propagate = False
    else:
        logging.basicConfig(
            level=numeric_level,
            format="%(asctime)s [%(levelname)-5.5s]  %(message)s",
            datefmt="[%Y/%m/%d %H:%M;%S]",
            handlers=handlers,
            force=os.getenv("REGSCALE_ECS", False) == "True",
        )
        logger = logging.getLogger("regscale")
        logger.handlers = handlers
        logger.setLevel(numeric_level)
        logger.parent.handlers = []
        if propagate is not None:
            logger.propagate = propagate

    return logger
