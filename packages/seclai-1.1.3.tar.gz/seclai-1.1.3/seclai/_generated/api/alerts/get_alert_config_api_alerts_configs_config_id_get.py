from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_alert_config_api_alerts_configs_config_id_get_response_get_alert_config_api_alerts_configs_config_id_get import (
    GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    config_id: str,
    *,
    x_account_id: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_account_id, Unset):
        headers["X-Account-Id"] = x_account_id

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/alerts/configs/{config_id}".format(
            config_id=quote(str(config_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet
    | HTTPValidationError
    | None
):
    if response.status_code == 200:
        response_200 = GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet
    | HTTPValidationError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    config_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_account_id: str | Unset = UNSET,
) -> Response[
    GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet
    | HTTPValidationError
]:
    """Get alert config

     Get a specific alert configuration by ID.

    Returns all fields including type, enabled state, threshold, cooldown, distribution type, and
    recipient list.

    Auth & scoping:
    - Requires `X-API-Key` header or OAuth Bearer token.

    Args:
        config_id (str):
        x_account_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        config_id=config_id,
        x_account_id=x_account_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    config_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_account_id: str | Unset = UNSET,
) -> (
    GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet
    | HTTPValidationError
    | None
):
    """Get alert config

     Get a specific alert configuration by ID.

    Returns all fields including type, enabled state, threshold, cooldown, distribution type, and
    recipient list.

    Auth & scoping:
    - Requires `X-API-Key` header or OAuth Bearer token.

    Args:
        config_id (str):
        x_account_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet | HTTPValidationError
    """

    return sync_detailed(
        config_id=config_id,
        client=client,
        x_account_id=x_account_id,
    ).parsed


async def asyncio_detailed(
    config_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_account_id: str | Unset = UNSET,
) -> Response[
    GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet
    | HTTPValidationError
]:
    """Get alert config

     Get a specific alert configuration by ID.

    Returns all fields including type, enabled state, threshold, cooldown, distribution type, and
    recipient list.

    Auth & scoping:
    - Requires `X-API-Key` header or OAuth Bearer token.

    Args:
        config_id (str):
        x_account_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        config_id=config_id,
        x_account_id=x_account_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    config_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_account_id: str | Unset = UNSET,
) -> (
    GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet
    | HTTPValidationError
    | None
):
    """Get alert config

     Get a specific alert configuration by ID.

    Returns all fields including type, enabled state, threshold, cooldown, distribution type, and
    recipient list.

    Auth & scoping:
    - Requires `X-API-Key` header or OAuth Bearer token.

    Args:
        config_id (str):
        x_account_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetAlertConfigApiAlertsConfigsConfigIdGetResponseGetAlertConfigApiAlertsConfigsConfigIdGet | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            config_id=config_id,
            client=client,
            x_account_id=x_account_id,
        )
    ).parsed
