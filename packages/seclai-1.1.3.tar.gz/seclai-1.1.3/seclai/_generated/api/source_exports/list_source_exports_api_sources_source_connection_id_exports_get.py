from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.export_list_response import ExportListResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    source_connection_id: UUID,
    *,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    x_account_id: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_account_id, Unset):
        headers["X-Account-Id"] = x_account_id

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/sources/{source_connection_id}/exports".format(
            source_connection_id=quote(str(source_connection_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ExportListResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ExportListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ExportListResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    source_connection_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    x_account_id: str | Unset = UNSET,
) -> Response[ExportListResponse | HTTPValidationError]:
    """List exports

     List all export jobs for a source connection, ordered newest first.  Supports pagination via
    ``page`` and ``limit`` query parameters.  Returns status, progress, and file metadata for each
    export.

    Args:
        source_connection_id (UUID):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        x_account_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExportListResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        source_connection_id=source_connection_id,
        page=page,
        limit=limit,
        x_account_id=x_account_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    source_connection_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    x_account_id: str | Unset = UNSET,
) -> ExportListResponse | HTTPValidationError | None:
    """List exports

     List all export jobs for a source connection, ordered newest first.  Supports pagination via
    ``page`` and ``limit`` query parameters.  Returns status, progress, and file metadata for each
    export.

    Args:
        source_connection_id (UUID):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        x_account_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExportListResponse | HTTPValidationError
    """

    return sync_detailed(
        source_connection_id=source_connection_id,
        client=client,
        page=page,
        limit=limit,
        x_account_id=x_account_id,
    ).parsed


async def asyncio_detailed(
    source_connection_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    x_account_id: str | Unset = UNSET,
) -> Response[ExportListResponse | HTTPValidationError]:
    """List exports

     List all export jobs for a source connection, ordered newest first.  Supports pagination via
    ``page`` and ``limit`` query parameters.  Returns status, progress, and file metadata for each
    export.

    Args:
        source_connection_id (UUID):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        x_account_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExportListResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        source_connection_id=source_connection_id,
        page=page,
        limit=limit,
        x_account_id=x_account_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    source_connection_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    x_account_id: str | Unset = UNSET,
) -> ExportListResponse | HTTPValidationError | None:
    """List exports

     List all export jobs for a source connection, ordered newest first.  Supports pagination via
    ``page`` and ``limit`` query parameters.  Returns status, progress, and file metadata for each
    export.

    Args:
        source_connection_id (UUID):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        x_account_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExportListResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            source_connection_id=source_connection_id,
            client=client,
            page=page,
            limit=limit,
            x_account_id=x_account_id,
        )
    ).parsed
