"""lmdiff CLI — compare language model configurations from the terminal.

All heavy imports (transformers, torch, engine) happen inside command
functions so that ``lmdiff --help`` and ``lmdiff list-metrics``
remain fast.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="lmdiff",
    help="Compare language model configurations via behavioral distance and multi-level diagnostics.",
    add_completion=False,
)

_BUILTIN_PROBES_DIR = Path(__file__).parent / "probes"

_EVALUATOR_MAP = {
    "exact_match": "ExactMatch",
    "contains_answer": "ContainsAnswer",
    "multiple_choice": "MultipleChoice",
}


def _resolve_probes_path(probes: str) -> Path:
    """Resolve a probe specifier to a file path.

    Accepts: "v01", "v01.json", or a full/relative file path.
    """
    # Try as builtin name first
    builtin = _BUILTIN_PROBES_DIR / f"{probes}.json"
    if builtin.exists():
        return builtin
    builtin_raw = _BUILTIN_PROBES_DIR / probes
    if builtin_raw.exists():
        return builtin_raw
    # Try as literal path
    p = Path(probes)
    if p.exists():
        return p
    raise typer.BadParameter(
        f"Probe set not found: '{probes}'. "
        f"Tried builtin ({builtin}) and path ({p})."
    )


def _get_evaluator(name: str):
    """Lazily import and return an evaluator instance."""
    from lmdiff.tasks.evaluators import ContainsAnswer, ExactMatch, MultipleChoice

    mapping = {
        "exact_match": ExactMatch,
        "contains_answer": ContainsAnswer,
        "multiple_choice": MultipleChoice,
    }
    cls = mapping.get(name)
    if cls is None:
        raise typer.BadParameter(
            f"Unknown evaluator: '{name}'. Choose from: {', '.join(mapping)}"
        )
    return cls()


@app.command()
def compare(
    model_a: str = typer.Argument(..., help="HuggingFace model ID or path for config A"),
    model_b: str = typer.Argument(..., help="HuggingFace model ID or path for config B"),
    probes: str = typer.Option("v01", help="Probe set name or path (default: v01)"),
    level: str = typer.Option("output", help="Metric level to run"),
    output_json: bool = typer.Option(False, "--json", help="Output JSON instead of rich table"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Write output to file"),
    n_samples: int = typer.Option(5, help="Number of generation samples"),
    max_new_tokens: int = typer.Option(64, help="Max new tokens for generation"),
    dtype: Optional[str] = typer.Option(None, "--dtype", help="Model precision: bfloat16, float16, float32 (default: auto)"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show all per-probe details"),
) -> None:
    """Run metric-level comparison between two model configurations."""
    if level != "output":
        raise typer.BadParameter(f"Level '{level}' not implemented in Phase 1. Use 'output'.")

    probes_path = _resolve_probes_path(probes)

    from lmdiff.config import Config
    from lmdiff.diff import ModelDiff
    from lmdiff.probes.loader import ProbeSet

    ps = ProbeSet.from_json(probes_path)
    md = ModelDiff(
        Config(model=model_a, dtype=dtype),
        Config(model=model_b, dtype=dtype),
        ps,
        n_samples=n_samples,
    )
    report = md.run(level=level, max_new_tokens=max_new_tokens)

    if output_json:
        from lmdiff.report.json_report import to_json, write_json

        if output:
            write_json(report, output)
            Console().print(f"Written to {output}")
        else:
            typer.echo(to_json(report))
    else:
        from lmdiff.report.terminal import print_report

        print_report(report, verbose=verbose)


@app.command()
def radar(
    model_a: str = typer.Argument(..., help="HuggingFace model ID or path for config A"),
    model_b: str = typer.Argument(..., help="HuggingFace model ID or path for config B"),
    probes: str = typer.Option("v01", help="Probe set name or path (default: v01)"),
    evaluator: str = typer.Option("contains_answer", help="Evaluator: exact_match, contains_answer, multiple_choice"),
    max_new_tokens: int = typer.Option(16, help="Max new tokens for generation"),
    dtype: Optional[str] = typer.Option(None, "--dtype", help="Model precision: bfloat16, float16, float32 (default: auto)"),
    output_json: bool = typer.Option(False, "--json", help="Output JSON instead of rich table"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Write output to file"),
) -> None:
    """Run per-domain capability radar (accuracy + BD) on two models."""
    probes_path = _resolve_probes_path(probes)
    eval_instance = _get_evaluator(evaluator)

    from lmdiff.config import Config
    from lmdiff.diff import ModelDiff
    from lmdiff.probes.loader import ProbeSet

    ps = ProbeSet.from_json(probes_path)
    md = ModelDiff(
        Config(model=model_a, dtype=dtype),
        Config(model=model_b, dtype=dtype),
        ps,
    )
    result = md.run_radar(probes=ps, evaluator=eval_instance, max_new_tokens=max_new_tokens)

    if output_json:
        from lmdiff.report.json_report import to_json, write_json

        if output:
            write_json(result, output)
            Console().print(f"Written to {output}")
        else:
            typer.echo(to_json(result))
    else:
        from lmdiff.report.terminal import print_radar

        print_radar(result)


def _parse_variant_spec(spec: str) -> tuple[str, str]:
    """Split a 'name=model_id' variant spec into (name, model_id).

    Rejects specs missing '=', or with blank left/right, via typer.BadParameter.
    """
    if "=" not in spec:
        raise typer.BadParameter(
            f"Variant '{spec}' must be in 'name=model_id' format"
        )
    name, model_id = spec.split("=", 1)
    name = name.strip()
    model_id = model_id.strip()
    if not name:
        raise typer.BadParameter(f"Variant spec '{spec}' has an empty name")
    if not model_id:
        raise typer.BadParameter(f"Variant spec '{spec}' has an empty model id")
    return name, model_id


@app.command()
def geometry(
    base: str = typer.Argument(..., help="Base model HF id or path"),
    variants: list[str] = typer.Argument(
        ...,
        help=(
            "Variant specs in 'name=model_id' format, "
            "e.g. '13b=meta-llama/Llama-2-13b-hf'"
        ),
    ),
    probes: str = typer.Option("v01", help="Probe set name or path (default: v01)"),
    max_new_tokens: int = typer.Option(16, help="Max new tokens for generation"),
    dtype: Optional[str] = typer.Option(None, "--dtype", help="Model precision: bfloat16, float16, float32 (default: auto)"),
    output_json: bool = typer.Option(False, "--json", help="Output JSON instead of rich table"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Write output to file"),
) -> None:
    """Analyze change geometry: one base vs multiple named variants."""
    parsed: dict[str, str] = {}
    for spec in variants:
        name, model_id = _parse_variant_spec(spec)
        if name in parsed:
            raise typer.BadParameter(f"Duplicate variant name: '{name}'")
        parsed[name] = model_id

    probes_path = _resolve_probes_path(probes)

    from lmdiff.config import Config
    from lmdiff.geometry import ChangeGeometry
    from lmdiff.probes.loader import ProbeSet

    ps = ProbeSet.from_json(probes_path)
    variant_configs = {
        name: Config(model=model_id, dtype=dtype, name=name)
        for name, model_id in parsed.items()
    }
    cg = ChangeGeometry(
        base=Config(model=base, dtype=dtype),
        variants=variant_configs,
        prompts=ps,
    )
    result = cg.analyze(max_new_tokens=max_new_tokens)

    if output_json:
        from lmdiff.report.json_report import to_json, write_json

        if output:
            write_json(result, output)
            Console().print(f"Written to {output}")
        else:
            typer.echo(to_json(result))
    else:
        from lmdiff.report.terminal import print_geometry

        print_geometry(result)


@app.command(name="run-task")
def run_task(
    model: str = typer.Argument(..., help="HuggingFace model ID or path"),
    probes: str = typer.Option("v01", help="Probe set name or path (default: v01)"),
    evaluator: str = typer.Option("contains_answer", help="Evaluator: exact_match, contains_answer, multiple_choice"),
    max_new_tokens: int = typer.Option(16, help="Max new tokens for generation"),
    output_json: bool = typer.Option(False, "--json", help="Output JSON instead of rich table"),
) -> None:
    """Run task evaluation on a single model (no diff)."""
    probes_path = _resolve_probes_path(probes)
    eval_instance = _get_evaluator(evaluator)

    from lmdiff.config import Config
    from lmdiff.engine import InferenceEngine
    from lmdiff.probes.loader import ProbeSet
    from lmdiff.tasks.base import Task

    ps = ProbeSet.from_json(probes_path)
    engine = InferenceEngine(Config(model=model))
    task = Task(name="eval", probes=ps, evaluator=eval_instance, max_new_tokens=max_new_tokens)
    result = task.run(engine)

    if output_json:
        from lmdiff.report.json_report import to_json

        typer.echo(to_json(result))
    else:
        console = Console()
        console.rule(f"[bold]Task: {result.task_name} on {result.engine_name}[/bold]")
        console.print(f"Probes: {result.n_probes}  Correct: {result.n_correct}  Accuracy: {result.accuracy:.2%}")
        console.print()
        if result.per_domain:
            tbl = Table(title="Per-Domain", show_lines=True)
            tbl.add_column("Domain", style="cyan")
            tbl.add_column("N", justify="right")
            tbl.add_column("Correct", justify="right")
            tbl.add_column("Accuracy", justify="right")
            for d, info in sorted(result.per_domain.items()):
                tbl.add_row(d, str(info["n"]), str(info["correct"]), f"{info['accuracy']:.2%}")
            console.print(tbl)


@app.command(name="list-metrics")
def list_metrics(
    level: Optional[str] = typer.Option(None, help="Filter by metric level"),
) -> None:
    """List available metrics and their properties."""
    from lmdiff.metrics.base import MetricLevel
    from lmdiff.metrics.output.behavioral_distance import BehavioralDistance
    from lmdiff.metrics.output.token_entropy import TokenEntropy
    from lmdiff.metrics.output.token_kl import TokenKL

    all_metrics = [BehavioralDistance, TokenEntropy, TokenKL]

    if level:
        try:
            target_level = MetricLevel(level)
        except ValueError:
            valid = ", ".join(lv.value for lv in MetricLevel)
            raise typer.BadParameter(f"Unknown level '{level}'. Choose from: {valid}")
        all_metrics = [m for m in all_metrics if m.level == target_level]

    console = Console()
    tbl = Table(title="Available Metrics", show_lines=True)
    tbl.add_column("Name", style="cyan", min_width=25)
    tbl.add_column("Level", min_width=15)
    tbl.add_column("Requirements", min_width=30)

    for cls in all_metrics:
        reqs = cls.requirements()
        req_str = ", ".join(f"{k}={'yes' if v else 'no'}" for k, v in sorted(reqs.items()))
        tbl.add_row(cls.name, cls.level.value, req_str)

    console.print(tbl)


if __name__ == "__main__":
    app()
