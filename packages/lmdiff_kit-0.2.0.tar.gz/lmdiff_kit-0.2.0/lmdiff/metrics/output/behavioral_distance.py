from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any

from lmdiff.metrics.base import BaseMetric, MetricLevel, MetricResult
from lmdiff.metrics.output._degeneracy import is_degenerate_tokens
from lmdiff.tokenizer_utils import bpb_from_ce, tokenizers_equivalent

if TYPE_CHECKING:
    from lmdiff.engine import InferenceEngine


class BehavioralDistance(BaseMetric):
    """Symmetric behavioral distance with self-entropy baseline subtraction.

    BD(A, B) = ½[CE(A,B) − CE(B,B)] + ½[CE(B,A) − CE(A,A)]
    Asymmetry = [CE(B,A) − CE(A,A)] − [CE(A,B) − CE(B,B)]

    Code variable naming: ce_XY where X = scoring engine, Y = output owner.
    So ce_ab = engine_b scores A's output = CE(B,A) in the formula above.

    Assumes greedy decoding (n_samples=1). When tokenizers differ, all CE
    values are BPB-normalized (using continuation byte count) before the formula.
    """

    name = "behavioral_distance"
    level = MetricLevel.OUTPUT

    def compute(
        self,
        engine_a: InferenceEngine,
        engine_b: InferenceEngine,
        probes: list[str],
        **kwargs: Any,
    ) -> MetricResult:
        max_new_tokens = kwargs.get("max_new_tokens", 64)
        pre_gen_a = kwargs.get("pre_gen_a")
        pre_gen_b = kwargs.get("pre_gen_b")

        same_tok = engine_a.config.shares_tokenizer_with(engine_b.config)
        if same_tok is None:
            same_tok = tokenizers_equivalent(engine_a.tokenizer, engine_b.tokenizer)
        use_bpb = not same_tok

        # Allow callers (e.g. CapabilityRadar under sampling) to pass the same
        # generations used for task evaluation, so accuracy and BD reference
        # identical outputs.
        gen_a = pre_gen_a if pre_gen_a is not None else engine_a.generate(
            probes, n_samples=1, max_new_tokens=max_new_tokens,
        )
        gen_b = pre_gen_b if pre_gen_b is not None else engine_b.generate(
            probes, n_samples=1, max_new_tokens=max_new_tokens,
        )

        outputs_a = [comps[0] for comps in gen_a.completions]
        outputs_b = [comps[0] for comps in gen_b.completions]
        ids_a = [tids[0] for tids in gen_a.token_ids]
        ids_b = [tids[0] for tids in gen_b.token_ids]

        score_aa = engine_a.score(probes, continuation_ids=ids_a)
        score_bb = engine_b.score(probes, continuation_ids=ids_b)
        score_ab = engine_b.score(probes, continuations=outputs_a)
        score_ba = engine_a.score(probes, continuations=outputs_b)

        per_prompt: list[dict] = []
        bd_sum = 0.0
        asym_sum = 0.0
        n_used = 0
        n_skipped = 0
        n_degen_a = 0
        n_degen_b = 0
        healthy_bd_sum = 0.0
        n_healthy = 0

        for i, probe in enumerate(probes):
            ce_aa = score_aa.cross_entropies[i]
            ce_ab = score_ab.cross_entropies[i]
            ce_ba = score_ba.cross_entropies[i]
            ce_bb = score_bb.cross_entropies[i]

            degen_a = is_degenerate_tokens(ids_a[i])
            degen_b = is_degenerate_tokens(ids_b[i])
            if degen_a:
                n_degen_a += 1
            if degen_b:
                n_degen_b += 1

            if any(math.isnan(c) for c in (ce_aa, ce_ab, ce_ba, ce_bb)):
                n_skipped += 1
                per_prompt.append({
                    "probe": probe,
                    "ce_aa": ce_aa, "ce_ab": ce_ab,
                    "ce_ba": ce_ba, "ce_bb": ce_bb,
                    "bd": float("nan"), "asymmetry": float("nan"),
                    "skipped": True,
                    "degenerate_a": degen_a, "degenerate_b": degen_b,
                })
                continue

            if use_bpb:
                text_a = outputs_a[i]
                text_b = outputs_b[i]
                n_tok_aa = len(score_aa.token_ids[i])
                n_tok_ab = len(score_ab.token_ids[i])
                n_tok_ba = len(score_ba.token_ids[i])
                n_tok_bb = len(score_bb.token_ids[i])

                ce_aa = bpb_from_ce(ce_aa, n_tok_aa, text_a)
                ce_ab = bpb_from_ce(ce_ab, n_tok_ab, text_a)
                ce_ba = bpb_from_ce(ce_ba, n_tok_ba, text_b)
                ce_bb = bpb_from_ce(ce_bb, n_tok_bb, text_b)

            bd_i = 0.5 * (ce_ab - ce_bb) + 0.5 * (ce_ba - ce_aa)
            asym_i = (ce_ab - ce_aa) - (ce_ba - ce_bb)

            bd_sum += bd_i
            asym_sum += asym_i
            n_used += 1

            if not degen_a and not degen_b:
                healthy_bd_sum += bd_i
                n_healthy += 1

            per_prompt.append({
                "probe": probe,
                "ce_aa": ce_aa, "ce_ab": ce_ab,
                "ce_ba": ce_ba, "ce_bb": ce_bb,
                "bd": bd_i, "asymmetry": asym_i,
                "degenerate_a": degen_a, "degenerate_b": degen_b,
            })

        if n_used == 0:
            raise ValueError(
                "all probes had empty continuations; cannot compute BD"
            )

        bd = bd_sum / n_used
        asymmetry = asym_sum / n_used
        n_total = len(probes)

        valid = [p for p in per_prompt if not p.get("skipped")]
        mean_ce_aa = sum(p["ce_aa"] for p in valid) / n_used
        mean_ce_ab = sum(p["ce_ab"] for p in valid) / n_used
        mean_ce_ba = sum(p["ce_ba"] for p in valid) / n_used
        mean_ce_bb = sum(p["ce_bb"] for p in valid) / n_used

        bd_healthy = (healthy_bd_sum / n_healthy) if n_healthy >= 3 else None

        return MetricResult(
            name=self.name,
            level=self.level,
            value=bd,
            details={
                "ce_aa": mean_ce_aa,
                "ce_ab": mean_ce_ab,
                "ce_ba": mean_ce_ba,
                "ce_bb": mean_ce_bb,
                "asymmetry": asymmetry,
                "bpb_normalized": use_bpb,
                "n_probes_used": n_used,
                "n_probes_skipped": n_skipped,
                "degeneracy_rate_a": n_degen_a / n_total,
                "degeneracy_rate_b": n_degen_b / n_total,
                "bd_healthy": bd_healthy,
                "n_healthy": n_healthy,
                "per_prompt": per_prompt,
            },
        )

    @classmethod
    def is_applicable(cls, config_a: Any, config_b: Any) -> bool:
        return True

    @classmethod
    def requirements(cls) -> dict[str, bool]:
        return {"logits": False, "hidden_states": False, "generations": True}
