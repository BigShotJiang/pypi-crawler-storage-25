# Cinna CLI — Project Context

> This document orients a human or LLM working on the cinna-cli codebase for the first time. It explains **why** this project exists, **how** it fits into the Cinna Core platform, the key concepts and terminology, the live-sync architecture, and the important design decisions.

---

## What is Cinna Core?

**Cinna Core** is a platform for building and running AI agents. Each agent is a self-contained unit with Python scripts, prompt files, a webapp dashboard, integration credentials, and a knowledge base. Agents run inside managed cloud environments — Docker containers with a specific Python runtime, system packages, and mounted workspace files.

The platform has two main modes of interaction with an agent:

- **Building mode** — An AI-powered workflow where a cloud-based LLM (the "building agent") develops and iterates on the agent's scripts, prompts, and configurations. The building LLM receives a system prompt (the **building prompt**) assembled by the **env core** (the runtime engine inside the agent's container).
- **Conversation mode** — End users interact with the finished agent via chat.

The platform also handles scheduling, triggers, email, A2A, MCP serving, and session history. None of that is relevant to local development — it stays in the cloud.

## What is Cinna CLI?

**Cinna CLI** (`cinna-cli`) is a local development tool that lets developers work on agents from their own machine using their preferred editor and AI coding tools (Claude Code, opencode, Cursor). Instead of replicating the agent's runtime locally, the CLI treats the **remote agent environment** as the runtime and keeps the local workspace continuously synced to it.

### What local dev is for

- Writing and testing Python scripts
- Testing credential integrations (keys and tokens stay on the platform, exercised by the remote env)
- Installing and validating Python / system packages
- Writing and iterating on prompt files
- Building webapp dashboards and data endpoints
- Preparing output files and reports

### What stays in the cloud

- All agent runtime: scripts execute in the remote env (via `cinna exec`)
- Production sessions (building mode, conversation mode)
- Schedulers, triggers, email
- A2A / MCP protocol serving
- Session history, activity logging
- Credentials

## Why the live-sync model?

An earlier iteration of `cinna-cli` built a local Docker image mirroring the agent env, synced via `push`/`pull`, and ran scripts with `docker exec`. That model had real friction points:

- Developers had to install Docker and wait for image builds.
- Local `pip install` / apt install drifted from production over time.
- Credentials had to round-trip between platform and local disk, expanding the secrets blast radius.
- Push/pull was manual; conflicts were only detected on sync.

The live-sync rewrite removes the local container entirely. Mutagen keeps the workspace bidirectionally in step with the remote env over a WebSocket tunnel to the platform, and `cinna exec` streams commands through the platform to the remote env. Dev == prod, not dev ≈ prod.

---

## Glossary

### Agent

A self-contained automation unit on the platform. Has a name, template, scripts, prompts, webapp, credentials, and a knowledge base. Identified by `agent_id`.

### Environment

The runtime container configuration for an agent on the platform. Each agent has exactly one environment. Environments may be suspended when idle; opening a sync WebSocket auto-activates them.

### Template

Base configuration for an agent (e.g., `general-env`, `python-env-advanced`). Determines the Dockerfile, default packages, workspace structure. Shipped as `backend/app/env-templates/{template}/` in the platform repo.

### Workspace

The collection of files that make up an agent's working directory. Lives at `workspace/` in the local project — continuously synced with the remote env's `/app/workspace`.

Structure (managed by the remote env; the CLI just mirrors it):

Bundle-owned (replaced when the publisher pushes a new bundle revision):

- `scripts/` — Python scripts the agent executes
- `docs/` — Prompt files (`WORKFLOW_PROMPT.md`, etc.)
- `webapp/` — HTML/CSS/JS dashboard + Python data endpoints
- `knowledge/` — Static integration docs shipped with the bundle
- `files/` — Static publisher-shipped assets (lookup tables, fixtures)
- `workspace_requirements.txt`, `workspace_system_packages.txt`

Per-user persistent — **not part of the published bundle**. Backed by a platform
`AppDataVolume` keyed by `(user_id, bundle_id)`, stored on the platform host under
`${APP_DATA_STORAGE_DIR}/<user_id>/<bundle_id>/`, and bind-mounted into the agent
container at `/app/workspace/app-data`. The volume survives `apply-update` (bundle
folders get overwritten, `app-data/` is never touched) and uninstall/reinstall
(the row is marked orphaned, not deleted, and reattaches on next install of the
same `bundle_id`):

- `app-data/storage/` — Long-lived runtime output scripts should write here
  (databases, JSON, CSVs, reports, derived data). This is the canonical place
  for anything the agent needs to keep across sessions and bundle updates.
- `app-data/uploads/` — Destination for every user-supplied file at runtime:
  chat attachments, task attachments, MCP `get_file_upload_url` uploads.
- `app-data/cache/` — Disposable caches the scripts may rebuild on demand.

**What the CLI developer sees:** the `workspace/app-data/` directory synced to
your machine is the publisher working install's *own* app-data volume — the
developer's personal runtime state. It is **not** content that gets shipped
when you publish a new bundle revision: bundle revisions snapshot only the
bundle-owned folders above. Every other user who installs the bundle gets a
fresh, empty `(user_id, bundle_id)` volume on the platform.

`workspace/app-data/` is gitignored by default for the same reason — it is
runtime state, not source.

Synced from the platform:

- `credentials/` — Integration credentials (managed by the backend)

### Sync session

A single Mutagen sync session per agent, named `cinna-<short-agent-id>`. Created on `cinna setup` (and resumed / re-created by `cinna dev`), lives until `cinna disconnect`. The Mutagen daemon persists across sessions and across multiple agents.

### Building Mode / Building Prompt

The platform's cloud-based AI development workflow. The building prompt is assembled by the env core and returned from `GET /building-context`; the CLI writes it to `BUILDING_AGENT.md`.

### Setup Token

A short-lived (15 min, single-use) token generated by the platform UI when you click "Local Development". Embedded in the `curl | python3` bootstrap command. Exchanged for a CLI token via `POST /api/cli-setup/{token}`.

### CLI Token

A JWT issued when a setup token is exchanged. Authenticates all subsequent API calls and the sync WebSocket. Stored in `.cinna/config.json` (the workspace copy) and mirrored into `~/.cinna/agents.json` (the per-user registry read by the sync shim).

Key properties:

- **Rolling expiry** — renewed on each successful request (7-day window).
- **Revocable** — from the platform UI.
- **Agent-scoped** — one token per agent per user.
- **Probeable** — `cinna list` and `cinna status` call `GET /sync-runtime` as a cheap authenticated probe and label the token `valid` / `expired` / `no connection`.
- **Refreshable in place** — `cinna set-token <token_or_url>` re-exchanges a fresh setup token through `POST /api/cli-setup/{token}` and rewrites both stores without re-cloning the workspace. The refresh is bound to the agent already in the workspace: if the exchanged token belongs to a different agent, the command aborts.

### Knowledge Source

A documentation/data source attached to an agent. Queried via the MCP proxy's `knowledge_query` tool, backed by the platform's vector search.

### MCP (Model Context Protocol)

An open protocol for connecting AI tools to external data/capabilities. The CLI runs a local stdio MCP server (`cinna mcp-proxy`) that exposes `knowledge_query`. Configured via `.mcp.json` (Claude Code) and `opencode.json` (opencode).

---

## Architecture

### System Overview

```
┌──────────────────┐     ┌─────────────────────┐     ┌────────────────────────┐
│ Your IDE /       │     │ Cinna CLI           │     │ Cinna Core Platform    │
│ Claude Code /    │     │                     │     │                        │
│ opencode         │     │ cinna setup         │     │ POST /api/cli-setup/…  │
└────────┬─────────┘     │ cinna set-token     │     │ GET  /workspace        │
         │               │ cinna dev           │     │ GET  /building-context │
         │ edits files   │ cinna sync status   │     │ GET  /sync-runtime     │
         │               │ cinna exec          │     │ POST /exec (SSE)       │
         ▼               │ cinna list          │     │ WSS  /sync-stream      │
  ~/my-agent/            │ cinna disconnect    │     │                        │
    workspace/           └───┬────────┬────────┘     │  proxies to the agent  │
    mutagen.yml              │        │              │  env: /command/stream, │
                             │ HTTPS  │ WSS          │  /sync/exec            │
                             │ (JWT)  │ (Mutagen)    └──────────┬─────────────┘
  MCP proxy (stdio) ─────────┘        │                         │
    knowledge_query                   ▼                         ▼
                           cinna-sync-ssh shim         ┌─────────────────────┐
                             (SSH transport            │ Remote Agent Env    │
                              over WebSocket)          │  (Docker container) │
                                                       │  mutagen-agent      │
                                                       │  /app/workspace     │
                                                       └─────────────────────┘
```

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Remote env is the only runtime | Eliminates Docker dependency on dev machines; dev == prod by construction. |
| Mutagen over WebSocket tunnel | Battle-tested bidirectional sync; the WS hop lets the platform authn + auto-activate the env. |
| `cinna-sync-ssh` as a separate binary | Mutagen expects an SSH-style transport. A tiny shim translates `ssh user@host cmd` into a WebSocket call. Installed as a console script alongside `cinna`. Mutagen's `MUTAGEN_SSH_PATH` env var is a **directory search path** (not a binary pointer), so the CLI materializes `~/.cinna/mutagen-ssh/ssh` as a wrapper and points Mutagen at that directory. |
| Global agent registry at `~/.cinna/agents.json` | One Mutagen daemon serves every agent the user has synced, and its env is captured once at daemon start. The shim reads this per-user registry (keyed by the argv `agent_id`) on every SSH invocation to resolve the right CLI token / platform URL — so two or more agents can live-sync concurrently. 0600 perms, holds JWTs. |
| Platform pins Mutagen version | Mutagen's wire protocol evolves; `GET /sync-runtime` lets the CLI refuse to start with a mismatched version. |
| `cinna exec` uses SSE through the platform | Same auth channel as the rest of the API; streams back via parsed `data:` events. |
| No backwards compatibility | Push/pull/rebuild/credentials flows are deleted, not deprecated. Users rerun bootstrap. |
| Mutagen daemon owned by the user | CLI talks to a shared `mutagen daemon` started on demand — multiple agents reuse it. |

### Module Dependency Graph

```
main.py  (CLI commands — Click)
  │
  ├── bootstrap.py       — setup orchestration
  ├── config.py          — .cinna/config.json: load/save/find
  ├── auth.py            — JWT storage, Authorization headers
  ├── client.py          — PlatformClient: HTTP + SSE stream_exec
  ├── mutagen_runtime.py — detect/install Mutagen; gate on version match
  ├── sync_session.py    — wrap the `mutagen` CLI (start/stop/status/conflicts)
  ├── sync_tui.py        — live Textual TUI shown by `cinna dev` (Sync/Details/Conflicts tabs)
  ├── sync_ssh_shim.py   — `cinna-sync-ssh` entry point (WebSocket transport)
  ├── sync.py            — tarball/zip extraction helpers (initial clone only)
  ├── context.py         — CLAUDE.md, BUILDING_AGENT.md, .mcp.json, opencode.json
  ├── mcp_proxy.py       — MCP stdio server for knowledge_query
  ├── console.py         — Rich helpers
  ├── logging.py         — cinna.log (rotating file handler)
  └── errors.py          — exception hierarchy
```

### Local Directory Layout

After `cinna setup` (agent name normalized, e.g. "HR Manager Agent" → `hr-manager-agent/`):

```
hr-manager-agent/               (workspace root)
  .cinna/
    config.json                 (agent config, CLI token, mutagen_version pin)
  workspace/                    (continuously synced with remote /app/workspace)
    scripts/                    (bundle-owned — shipped in published revisions)
    docs/                       (bundle-owned)
    webapp/                     (bundle-owned)
    knowledge/                  (bundle-owned)
    files/                      (bundle-owned — static publisher assets)
    app-data/                   (per-user persistent — NOT part of bundle revisions;
                                 backed by AppDataVolume keyed by (user_id, bundle_id);
                                 platform mount: /app/workspace/app-data)
      storage/                    long-lived runtime output (DBs, reports, derived data)
      uploads/                    all user-supplied file uploads at runtime
      cache/                      disposable caches
    credentials/                (backend-managed)
    workspace_requirements.txt
    workspace_system_packages.txt
  mutagen.yml                   (sync rules — ignores, scan mode)
  CLAUDE.md                     (auto-generated local dev instructions)
  BUILDING_AGENT.md             (building mode system prompt from platform)
  .mcp.json                     (MCP config for Claude Code)
  opencode.json                 (MCP config for opencode)
  .gitignore
```

Per-user global state (one copy, shared across every agent workspace):

```
~/.cinna/
  agents.json                   (agent_id → {platform_url, cli_token, workspace_path}; 0600)
  mutagen-ssh/
    ssh                         (bash wrapper — execs cinna-sync-ssh; 0755)
```

---

## Sync Transport

### Wire path

```
local Mutagen daemon
     ↓ MUTAGEN_SSH_PATH=~/.cinna/mutagen-ssh   (directory search path)
     ↓ finds + execs the `ssh` wrapper inside that dir
     ↓ argv: "user@cinna-agent-<id> mutagen-agent <args…>"
     ↓
~/.cinna/mutagen-ssh/ssh   (bash wrapper)
     ↓ exec cinna-sync-ssh "$@"
     ↓
cinna-sync-ssh
     ↓ parse agent_id from argv host ("cinna-agent-<id>")
     ↓ resolve credentials:
     ↓   1. env fast path — used only when CINNA_AGENT_ID == argv agent_id
     ↓   2. ~/.cinna/agents.json registry lookup by agent_id (authoritative)
     ↓ open WebSocket: wss://<platform>/api/v1/cli/agents/<id>/sync-stream
     ↓ first frame: {"remote_command": ["mutagen-agent", …args]}
     ↓ pump: stdin → WS, WS → stdout
     ↓
Platform /sync-stream
     ↓ auth + scope + env-activation
     ↓ opens /sync/exec WS to the remote env core
     ↓ byte-pumps both ways (FIRST_COMPLETED)
     ↓
Env core `mutagen-agent` subprocess
     ↓ does the actual file reconciliation over the tunnel
```

**Why the shim never trusts env for agent identity:** the Mutagen daemon is a
long-lived process; its environment is captured when it first starts and is
shared across every SSH invocation it spawns thereafter. If you set up agent A
and then agent B, the daemon's env still has `CINNA_AGENT_ID=<A>`. Keying
credentials off the argv-derived agent_id plus the per-user registry lets a
single shared daemon serve any number of agents concurrently.

### Mutagen pinning

The platform exposes `GET /sync-runtime` returning `{"mutagen_version": "…", "mutagen_agent_sha256": "…", "platform_api_version": "…"}`. The CLI:

1. Calls this during `cinna setup` and on each `cinna dev`.
2. Runs `mutagen version` locally.
3. Refuses to start on mismatch (with an upgrade prompt) — Mutagen protocol bumps can break sync silently otherwise.

The version, once verified, is cached in `.cinna/config.json` under `mutagen_version` and `last_sync_runtime_check_at`.

### `mutagen.yml`

Seeded by `cinna setup` with `mode: two-way-safe`, `ignore.vcs: true`, and a starter ignore list (`__pycache__/`, `node_modules/`, `.venv/`, `.cinna/`, etc.). Users can customize freely — the CLI never overwrites an existing file.

### Env warmth

Opening the sync WebSocket keeps the remote env warm. The platform heartbeats `last_sync_activity_at` server-side while the WS is open; on disconnect it waits a grace period (default 5 min) before suspending. Reconnecting within grace cancels the timer. A suspended env auto-activates on the next sync-WS handshake — `cinna dev` may take a few seconds on first-of-day runs.

### Conflicts

Mutagen 0.18.1 in `two-way-safe` records conflicts in its session state (the `conflicts[]` array of `mutagen sync list --template '{{json .}}'`) but, contrary to older mutagen behavior, does **not** write `<name>.conflict.<side>.<timestamp>` files to disk — both sides simply retain their divergent content. See [`mutagen_capabilities.md` §7](./mutagen_capabilities.md#7--two-way-safe-does-not-write-conflictsidets-files) for the empirical proof and re-verification steps.

Two surfaces expose conflicts:

- **`cinna sync conflicts`** — a read-only Click subcommand that walks the workspace for any `*.conflict.*` files mutagen *does* end up writing (other sync modes, or future mutagen versions, may still produce them). Implementation lives in `sync_session.list_conflicts`.
- **The Conflicts tab in `cinna dev`** — sourced from mutagen's JSON `conflicts[]`, always populated when a conflict exists. The user navigates the list with `↑`/`↓` and resolves with `1` (take REMOTE) or `5` (take LOCAL). Resolution mechanism: delete the file on the losing side (locally with `unlink()`, remotely via `cinna exec rm`) then `mutagen sync reset <session>`; mutagen sees one side empty, no common ancestor, and propagates the survivor. Verified against 0.18.1; see [`interface.md`](./interface.md) for the full element-to-mutagen-capability mapping.

---

## Remote Exec

`cinna exec <cmd>` POSTs to `/api/v1/cli/agents/{id}/exec` with `{"command": "<cmd>"}` and consumes an SSE stream. Event types:

| Type | Payload | CLI action |
|------|---------|------------|
| `exec_id` | `{"exec_id": "<uuid>"}` | First event. Remember it for future interrupt routing. |
| `tool_result_delta` | `{"content": "…", "metadata": {"stream": "stdout"\|"stderr"}}` | Write chunk to stdout/stderr. |
| `done` | `{"exit_code": N, "duration_seconds": F}` | Terminal — exit with N. |
| `interrupted` | `{"exit_code": -1}` | Terminal — exit 130. |
| `error` | `{"content": "…"}` | Print error; exit 1. |

Ctrl+C closes the SSE stream; the platform cleans up the remote process. Interactive stdin (REPLs, debuggers) is out of scope for the current `/exec` endpoint.

---

## Bootstrap Flow

```
┌───────────────────────┐                  ┌──────────────────────────────┐
│ Platform UI           │  copy / paste    │ Local Terminal                │
│ [Local Development]   │ ────────────────►│ $ curl -sL …/api/cli-setup/… │
│ [Copy setup command]  │                  │     | python3 -               │
└───────────────────────┘                  └──────────────────────────────┘
```

1. UI generates a setup token (15 min, single-use).
2. The `curl | python3` bootstrap script (served by the backend, not in this repo):
   - Checks Python 3.10+.
   - Installs/upgrades `cinna-cli` (via `uv tool install`, `pipx`, or `pip`).
   - Runs `cinna setup <url>`.
3. `cinna setup` (in `bootstrap.py`) runs the 5-step flow:
   1. Exchange setup token for CLI token + agent info (`POST /api/cli-setup/{token}`).
   2. `GET /sync-runtime`, detect local Mutagen, prompt to install if missing/mismatched.
   3. `GET /workspace` (one-shot tarball), extract to `./workspace/`.
   4. `GET /building-context` → write `BUILDING_AGENT.md` + mirror referenced prompt docs; generate `CLAUDE.md`, `.mcp.json`, `opencode.json`, `.gitignore`.
   5. Write `mutagen.yml` and call `sync_session.start()` — the continuous sync session is live.

---

## Security Model

### Authentication

```
Setup token (15 min, single-use)
    │  POST /api/cli-setup/{token}
    ▼
CLI token (JWT, 7-day rolling window, revocable)
    │  Authorization: Bearer <jwt>   — HTTP + WebSocket
    ▼
Backend validates on every request:
    1. JWT signature + expiry
    2. DB lookup by token_id; is_revoked = False
    3. Agent exists and user still owns it
    4. last_used_at refreshed, expires_at rolled forward
```

### Token refresh

When a CLI token expires (or is revoked) the normal remedy is `cinna set-token <token_or_url>` from inside the agent directory. Internally it reuses `_exchange_setup_token()` from `bootstrap.py` — the same helper that backs `cinna setup` — so the server side is a plain re-run of `POST /api/cli-setup/{token}`. The workspace's existing `platform_url` is used as the fallback when a bare token is pasted, which lets agents registered against different platforms each refresh from their own directory without extra flags. The workspace tarball is **not** re-downloaded, and `CLAUDE.md` / `BUILDING_AGENT.md` / `.mcp.json` / `opencode.json` are left in place — only the stored CLI token changes.

### Authorization

| Resource | Rule |
|----------|------|
| `/workspace` | Token owner must own the agent |
| `/building-context` | Same |
| `/knowledge/search` | Same |
| `/sync-stream` (WebSocket) | Same; mid-session revocation is polled every 30s by the platform |
| `/exec` | Same; the remote env holds credentials and enforces its own limits |

### Input validation (CLI-side)

- Workspace tarball extraction validates against path traversal (`../`), absolute paths, symlinks, oversized files (>100MB).
- `cinna-sync-ssh` parses the agent_id from argv (`user@cinna-agent-<uuid>`) and resolves the platform URL + CLI token from the `~/.cinna/agents.json` registry; the resolved URL — never the argv host — decides where the WebSocket connects.
- `~/.cinna/agents.json` holds live CLI JWTs and is written with `0600`; `~/.cinna/` is a per-user directory.
- CLI token lives in `.cinna/config.json` (`.gitignore`d); `.cinna/` is gitignored by default.

---

## Platform API Endpoints

| Method | Route | Auth | Purpose |
|--------|-------|------|---------|
| POST | `/api/cli-setup/{token}` | Token | Exchange setup token for CLI token |
| GET  | `/api/v1/cli/agents/{id}/workspace` | CLI JWT | One-shot tarball for initial clone |
| GET  | `/api/v1/cli/agents/{id}/building-context` | CLI JWT | Assembled building prompt |
| POST | `/api/v1/cli/agents/{id}/knowledge/search` | CLI JWT | Knowledge base search (via MCP proxy) |
| GET  | `/api/v1/cli/agents/{id}/sync-runtime` | CLI JWT | Required Mutagen version + hash (also used by `cinna list` / `cinna status` as a cheap token-validity probe) |
| POST | `/api/v1/cli/agents/{id}/exec` | CLI JWT | Streaming SSE command execution |
| WSS  | `/api/v1/cli/agents/{id}/sync-stream` | CLI JWT | Mutagen transport tunnel |

Endpoints that were part of the old Docker-replica model (`build-context`, `workspace` POST, `workspace/manifest`, `credentials`) have been removed from the backend and from this CLI.

---

## Testing

- `pytest` + `respx` for HTTP mocking
- `click.testing.CliRunner` for CLI tests
- `tmp_path` fixture for filesystem operations

```bash
uv run pytest -v
uv run ruff check src/
uv run ruff format --check src/
```

---

## Tech Stack

| Component | Choice | Rationale |
|-----------|--------|-----------|
| CLI framework | Click | Subcommand support, option groups, good UX |
| HTTP client | httpx | Streaming, modern, consistent sync + async |
| WebSocket client | websockets | Minimal dep for the sync shim |
| Sync engine | Mutagen | Battle-tested bidirectional sync; OSS; cross-platform |
| Terminal | Rich | Spinners, panels, tables |
| Live TUI | Textual | Three-tab interactive view (`cinna dev`); built on Rich |
| MCP | mcp SDK | Official protocol SDK |
| Tests | pytest + respx | Standard; respx is purpose-built for httpx |
| Build | Hatchling | Minimal, standards-compliant |
| Python | >= 3.10 | Matches platform backend |

---

## Out of Scope (Future)

- **Interactive stdin for `cinna exec`** — REPLs, debuggers.
- **Port forwarding** — `cinna forward local:remote` (Mutagen supports it).
- **Post-sync hooks** — e.g. `uv sync` on `pyproject.toml` change.
- **Web UI conflict resolution** — the in-TUI Conflicts tab covers the common case; editor-based 3-way merge stays the fallback for ones the TUI can't handle (e.g. asymmetric directory/file conflicts).
- **Multi-device presence UI**.
- **Bundled Mutagen daemon** — stay with a user-installed daemon.
- **Telemetry pipe** to the backend.

---

## Related Projects

- **cinna-core** — the platform backend. Hosts the API routes this CLI calls, the agent runtime, env core, building mode, and the web UI. Source plan for this CLI feature: `cinna-core/docs/drafts/cinna-cli-live-sync_plan.md`.
