"""UI Components and widgets for the Yankit TUI."""

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import DataTable, Static, TextArea

from yankit.db import db


class EntryTable(DataTable):
    """Custom data table for clipboard entries with specific keybindings."""

    BINDINGS = [
        Binding("c", "copy_entry", "Copy"),
        Binding("enter", "show_detail", "Detail"),
        Binding("right", "show_detail", "Detail →", show=False),
        Binding("d", "delete_entry", "Delete"),
    ]

    def action_show_detail(self) -> None:
        self.app.action_show_detail()

    def action_hide_detail(self) -> None:
        self.app.action_hide_detail()

    def action_copy_entry(self) -> None:
        self.app.action_copy_entry()

    def action_delete_entry(self) -> None:
        self.app.action_delete_entry()

    def focus_by_id(self, entry_id: int) -> bool:
        """Find and focus the row with the given entry ID. Returns True if found."""
        for row_index in range(self.row_count):
            try:
                # Row ID is at column 0
                cell_value = self.get_cell_at((row_index, 0))
                if str(cell_value) == str(entry_id):
                    self.move_cursor(row=row_index)
                    return True
            except Exception:
                continue
        return False


class DetailLog(TextArea):
    """TextArea for the detail panel that supports text selection and partial copying."""

    BINDINGS = [
        Binding("c", "copy_selection", "Copy"),
        Binding("ctrl+left", "focus_list", show=False, priority=True),
        Binding("alt+left", "focus_list", show=False, priority=True),
        Binding("ctrl+right", "focus_detail", show=False, priority=True),
        Binding("alt+right", "focus_detail", show=False, priority=True),
    ]

    def on_key(self, event) -> None:
        """Handle specific navigation keys in the detail view."""
        if event.key == "left" and self.cursor_location == (0, 0) and not self.selected_text:
            self.app.action_focus_list()
            event.prevent_default()

    def action_focus_list(self) -> None:
        """Delegate to app action."""
        self.app.action_focus_list()

    def action_focus_detail(self) -> None:
        """Delegate to app action (keeps focus here)."""
        self.app.action_focus_detail()

    def action_hide_detail(self) -> None:
        self.app.action_hide_detail()

    def action_copy_selection(self) -> None:
        """Copy the selected text, or the whole entry if nothing is selected."""
        if self.selected_text:
            content = self.selected_text
            label = "selection"
        else:
            content = self.text
            label = "entry"

        if not content:
            return

        from yankit.clipboard import set_clipboard

        if set_clipboard(content):
            db.add_entry(content)  # Track the partial copy as a new entry!
            # Show a brief preview in status bar
            preview = content[:30].replace("\n", " ").replace("\r", "")
            self.app._show_status(f"✓ Copied {label}: {preview}...", "green bold")
            self.app.notify(f"Copied {label} to clipboard!", title="Success")
        else:
            self.app._show_status(f"✗ Failed to copy {label}", "red bold")


class StatusBar(Horizontal):
    """Bottom status bar showing contextual messages and database capacity."""

    DEFAULT_CSS = """
    StatusBar {
        layout: horizontal;
        width: 100%;
        height: 1;
        background: $panel;
        color: $text;
    }

    #status-spacer {
        width: 1fr;
    }

    #watcher-status {
        width: auto;
        padding-left: 2;
        padding-right: 2;
    }

    #watcher-status.online {
        color: green;
    }

    #watcher-status.offline {
        color: red;
        text-style: bold;
    }

    #status-text {
        width: 1fr;
        content-align: center middle;
    }

    #capacity-text {
        width: auto;
        content-align: right middle;
        padding-right: 2;
    }

    #capacity-text.danger {
        color: red;
        text-style: bold;
    }
    """

    def __init__(self, initial_text: str = ""):
        super().__init__()
        self._initial_text = initial_text

    def compose(self) -> ComposeResult:
        yield Static("● Watcher: Off", id="watcher-status")
        yield Static(self._initial_text, id="status-text")
        yield Static("", id="capacity-text")

    def _get_status_spacer(self) -> Static:
        return self.query_one("#status-spacer", Static)

    def update_watcher(self, is_running: bool) -> None:
        """Update the watcher status indicator."""
        status = self.query_one("#watcher-status", Static)
        if is_running:
            status.update("● Watcher: On")
            status.add_class("online")
            status.remove_class("offline")
        else:
            status.update("● Watcher: Off")
            status.add_class("offline")
            status.remove_class("online")

    def update(self, text: str) -> None:
        """Update the main status text."""
        self.query_one("#status-text", Static).update(text)

    def update_capacity(self, count: int, max_entries: int) -> None:
        """Update the capacity indicator."""
        cap_static = self.query_one("#capacity-text", Static)
        cap_static.update(f"{count}/{max_entries} records")
        if max_entries > 0 and count >= 0.95 * max_entries:
            cap_static.add_class("danger")
        else:
            cap_static.remove_class("danger")


class DetailPanel(Vertical):
    """Slide-out panel showing full content details."""

    DEFAULT_CSS = """
    DetailPanel {
        width: 0;
        height: 100%;
        dock: right;
        background: $surface;
        border-left: none;
        transition: width 0.3s in_out_cubic;
        overflow: hidden;
    }

    DetailPanel.visible {
        width: 50%;
        border-left: vkey $panel;
    }

    #detail-header {
        height: 3;
        padding: 1;
        background: $panel;
        color: $text;
        text-style: bold;
        border-bottom: solid $border;
    }

    #detail-content {
        padding: 1 2;
        height: 1fr;
    }

    #empty-message {
        width: 100%;
        height: 100%;
        content-align: center middle;
        color: $text-muted;
        text-style: italic;
    }
    """

    def compose(self) -> ComposeResult:
        yield Static("Entry Details", id="detail-header")
        log = DetailLog(id="detail-content")
        log.can_focus = True
        log.read_only = True
        log.show_line_numbers = False
        yield log

    def clear(self) -> None:
        """Clear the content and show empty message."""
        self.query_one("#detail-header", Static).update("Entry Details")
        self.query_one("#detail-content", DetailLog).text = ""

    def show_entry(self, entry: dict) -> None:
        """Populate and show the detail panel."""
        header = self.query_one("#detail-header", Static)
        header.update(
            f"Entry #{entry['id']} │ {entry['char_count']} chars │ {entry['word_count']} words"
        )

        log = self.query_one("#detail-content", DetailLog)
        log.text = entry["content"]

        self.add_class("visible")

    def hide_panel(self) -> None:
        """Hide the detail panel."""
        self.remove_class("visible")

    @property
    def is_visible(self) -> bool:
        """Check if the panel is currently visible."""
        return self.has_class("visible")
