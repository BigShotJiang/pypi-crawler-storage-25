::: startup_valuation.core
