::: startup_valuation.hardware
