::: startup_valuation.capm
