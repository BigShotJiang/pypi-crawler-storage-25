from setuptools import setup, find_packages
setup(
    name='ANIS_HAJJAJI',
    version='0.0.2',
    packages=find_packages(),
    install_requires=[
        "matplotlib",
        "mplsoccer" ,
        "numpy" ,
        "Pillow" ,
        "pandas"
        
    ],
)