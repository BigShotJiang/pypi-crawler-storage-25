import matplotlib.colors as mcolors

def get_zoom(img, target_size=40):
    """تثبيت حجم الصورة بالبكسل على المخطط"""
    return target_size / max(img.size)

def percent_to_number(value):
    # إذا كانت القيمة نص
    if isinstance(value, str):
        # إزالة أي مسافات
        value = value.strip()
        # إذا كانت تحتوي على %
        if "%" in value:
            return float(value.replace("%", ""))
        else:
            return float(value)
    # إذا كانت القيمة رقم (int أو float)
    elif isinstance(value, (int, float)):
        return float(value)
    else:
        # قيمة افتراضية إذا كان النوع غير متوقع
        return 0.0

def auto_split(text, max_len=12):
        # إذا كان النص قصير لا يحتاج تقسيم
        if len(text) <= max_len:
            return text
        
        # تقسيم النص إلى كلمات
        words = text.split()
        lines = []
        current_line = ""
        
        for word in words:
            if len(current_line + " " + word) <= max_len:
                current_line += " " + word if current_line else word
            else:
                lines.append(current_line)
                current_line = word
        lines.append(current_line)
        
        # دمج الأسطر مع فاصل سطر جديد
        return "\n".join(lines)

def make_lighter(color, factor=0.3):
    rgb = mcolors.to_rgb(color)
    lighter_rgb = [(1 - (1 - c) * (1 - factor)) for c in rgb]
    return lighter_rgb

def ordinal_suffix(n: int) -> str:
    # الحالات الخاصة للأرقام التي تنتهي بـ 11, 12, 13
    if 11 <= n % 100 <= 13:
        suffix = "th"
    else:
        # اختيار اللاحقة حسب الرقم الأخير
        last_digit = n % 10
        if last_digit == 1:
            suffix = "st"
        elif last_digit == 2:
            suffix = "nd"
        elif last_digit == 3:
            suffix = "rd"
        else:
            suffix = "th"
    return f"{n:.0f}{suffix}"

    