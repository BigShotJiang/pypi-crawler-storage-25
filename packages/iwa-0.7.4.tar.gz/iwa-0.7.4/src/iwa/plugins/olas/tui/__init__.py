"""Olas TUI view module."""
