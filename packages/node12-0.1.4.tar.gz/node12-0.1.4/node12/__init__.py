from pathlib import Path

__all__ = [
    "list_templates",
    "listtemplates",
    "get_template",
    "get_html",
    "get_css",
    "get_js",
    "get_combined",
    "print_template",
    "save_template",
]
__version__ = "0.1.4"

_TEMPLATES = {
    "product_entry": {
        "title": "Product Entry Form",
        "html": """<div class=\"container\">
    <h2>Product Entry Form</h2>
    <label>Product Name</label>
    <input type=\"text\" id=\"productName\" placeholder=\"Enter name\">

    <label>Price</label>
    <input type=\"number\" id=\"productPrice\" placeholder=\"Enter price\">

    <label>Category</label>
    <input type=\"text\" id=\"productCategory\" placeholder=\"Enter category\">

    <label>Description</label>
    <textarea id=\"productDescription\" placeholder=\"Enter description\"></textarea>

    <button onclick=\"submitProduct()\">Submit Product</button>
    <div id=\"productResult\" class=\"result\"></div>
</div>""",
        "css": """body {
    font-family: Arial, sans-serif;
    background: #eef2f7;
    margin: 0;
    padding: 20px;
}
.container {
    max-width: 500px;
    margin: 0 auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
h2 {
    margin-top: 0;
}
label {
    display: block;
    margin-top: 12px;
    font-weight: bold;
}
input, textarea {
    width: 100%;
    padding: 10px;
    margin-top: 6px;
    border: 1px solid #ccc;
    border-radius: 4px;
}
button {
    width: 100%;
    padding: 10px;
    margin-top: 16px;
    border: none;
    background: #007bff;
    color: white;
    border-radius: 4px;
    cursor: pointer;
}
button:hover {
    background: #0056b3;
}
.result {
    margin-top: 16px;
    padding: 12px;
    background: #f8f9fa;
    border: 1px solid #ddd;
    border-radius: 4px;
}""",
        "js": """function submitProduct() {
    var name = document.getElementById('productName').value;
    var price = document.getElementById('productPrice').value;
    var category = document.getElementById('productCategory').value;
    var description = document.getElementById('productDescription').value;
    if (!name || !price || !category) {
        alert('Please fill in name, price, and category.');
        return;
    }
    document.getElementById('productResult').innerText =
    'Product added: ' + name + ' | ₹' + price + ' | ' + category + '\\n' + description;
}""",
    },
    "job_application": {
        "title": "Job Application Form",
        "html": """<div class=\"container\">
    <h2>Job Application Form</h2>
    <label>Full Name</label>
    <input type=\"text\" id=\"applicantName\" placeholder=\"Full name\">

    <label>Email</label>
    <input type=\"email\" id=\"applicantEmail\" placeholder=\"Email address\">

    <label>Phone</label>
    <input type=\"tel\" id=\"applicantPhone\" placeholder=\"Phone number\">

    <label>Position Applied For</label>
    <input type=\"text\" id=\"position\" placeholder=\"Position\">

    <label>Experience</label>
    <textarea id=\"experience\" placeholder=\"Write your experience\"></textarea>

    <button onclick=\"submitApplication()\">Submit Application</button>
    <div id=\"applicationResult\" class=\"result\"></div>
</div>""",
        "css": """body {
    font-family: Arial, sans-serif;
    background: #f1f5f9;
    padding: 20px;
}
.container {
    max-width: 520px;
    margin: 0 auto;
    background: white;
    padding: 22px;
    border-radius: 8px;
    box-shadow: 0 4px 14px rgba(0,0,0,0.08);
}
label {
    display: block;
    margin-top: 14px;
    font-size: 0.95rem;
}
input, textarea {
    width: 100%;
    padding: 10px;
    margin-top: 6px;
    border-radius: 5px;
    border: 1px solid #ccd6dd;
}
button {
    margin-top: 18px;
    width: 100%;
    background: #28a745;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 5px;
    cursor: pointer;
}
button:hover {
    background: #218838;
}
.result {
    margin-top: 15px;
    padding: 12px;
    color: #155724;
    background: #d4edda;
    border: 1px solid #c3e6cb;
    border-radius: 4px;
    white-space: pre-wrap;
}""",
        "js": """function submitApplication() {
    var name = document.getElementById('applicantName').value;
    var email = document.getElementById('applicantEmail').value;
    var phone = document.getElementById('applicantPhone').value;
    var position = document.getElementById('position').value;
    var experience = document.getElementById('experience').value;
    if (!name || !email || !position) {
        alert('Name, email, and position are required.');
        return;
    }
    document.getElementById('applicationResult').innerText =
    'Application submitted for: ' + name + '\\nPosition: ' + position + '\\nEmail: ' + email + '\\nPhone: ' + phone;
}""",
    },
    "todo": {
        "title": "Todo List",
        "html": """<div class=\"container\">
    <h2>Todo List</h2>
    <div class=\"input-row\">
        <input type=\"text\" id=\"todoText\" placeholder=\"New task\">
        <button onclick=\"addTodo()\">Add</button>
    </div>

    <ul id=\"todoList\" class=\"todo-list\"></ul>
</div>""",
        "css": """body {
    font-family: Arial, sans-serif;
    margin: 0;
    background: #f8fafc;
    padding: 20px;
}
.container {
    max-width: 500px;
    margin: auto;
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
.input-row {
    display: flex;
    gap: 8px;
    margin-bottom: 14px;
}
input {
    flex: 1;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
}
button {
    padding: 10px 16px;
    border: none;
    border-radius: 5px;
    background: #007bff;
    color: white;
    cursor: pointer;
}
button:hover {
    background: #0069d9;
}
.todo-list {
    list-style: none;
    padding: 0;
    margin: 0;
}
.todo-list li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 12px;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    margin-bottom: 8px;
}
.todo-list button {
    background: #dc3545;
}""",
        "js": """function addTodo() {
    var value = document.getElementById('todoText').value;
    if (!value) {
        alert('Write a task first.');
        return;
    }
    var list = document.getElementById('todoList');
    var li = document.createElement('li');
    li.innerHTML =
    '<span>' + value + '</span>' +
    ' <button onclick=\"this.parentElement.remove()\">Delete</button>';
    list.appendChild(li);
    document.getElementById('todoText').value = '';
}""",
    },
    "complaint_registration": {
        "title": "Complaint Registration",
        "html": """
<div class=\"container\">
    <h2>Complaint Registration</h2>
    <label>Your Name</label>
    <input type=\"text\" id=\"complaintName\" placeholder=\"Name\">

    <label>Phone or Email</label>
    <input type=\"text\" id=\"complaintContact\" placeholder=\"Contact details\">

    <label>Complaint Type</label>
    <select id=\"complaintType\">
        <option value=\"Billing\">Billing</option>
        <option value=\"Service\">Service</option>
        <option value=\"Other\">Other</option>
    </select>

    <label>Complaint Details</label>
    <textarea id=\"complaintDetails\" placeholder=\"Describe problem\"></textarea>

    <button onclick=\"submitComplaint()\">Submit Complaint</button>
    <div id=\"complaintResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #eef2ff; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 8px; box-shadow: 0 3px 12px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; font-weight: 600; }
input, textarea, select { width: 100%; padding: 10px; margin-top: 6px; border-radius: 4px; border: 1px solid #b8c6db; }
button { width: 100%; margin-top: 16px; padding: 12px; border: none; border-radius: 5px; background: #17a2b8; color: white; cursor: pointer; }
button:hover { background: #117a8b; }
.result { margin-top: 16px; padding: 12px; border: 1px solid #c8e5ff; background: #e9f7ff; border-radius: 5px; }""",
        "js": """function submitComplaint() {
    var name = document.getElementById('complaintName').value;
    var contact = document.getElementById('complaintContact').value;
    var type = document.getElementById('complaintType').value;
    var details = document.getElementById('complaintDetails').value;
    if (!name || !contact || !details) {
        alert('Please fill name, contact, and details.');
        return;
    }
    document.getElementById('complaintResult').innerText =
    'Complaint submitted for ' + name + ' (' + type + ').\nContact: ' + contact + '\nDetails: ' + details;
}""",
    },
    "registration_login": {
        "title": "Registration and Login",
        "html": """
<div class=\"container\">
    <h2>Register / Login</h2>
    <div class=\"card\">
        <h3>Register</h3>
        <label>Name</label>
        <input type=\"text\" id=\"regName\" placeholder=\"Your name\">
        <label>Email</label>
        <input type=\"email\" id=\"regEmail\" placeholder=\"Email\">
        <label>Password</label>
        <input type=\"password\" id=\"regPassword\" placeholder=\"Password\">
        <button onclick=\"registerUser()\">Register</button>
    </div>
    <div class=\"card\">
        <h3>Login</h3>
        <label>Email</label>
        <input type=\"email\" id=\"loginEmail\" placeholder=\"Email\">
        <label>Password</label>
        <input type=\"password\" id=\"loginPassword\" placeholder=\"Password\">
        <button onclick=\"loginUser()\">Login</button>
    </div>
    <div id=\"authResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; margin: 0; background: #f4f7fc; padding: 20px; }
.container { max-width: 560px; margin: auto; }
.card { background: white; padding: 18px; border-radius: 8px; box-shadow: 0 2px 12px rgba(31,38,135,0.08); margin-bottom: 16px; }
label { display: block; margin-top: 12px; color: #333; }
input { width: 100%; padding: 10px; margin-top: 6px; border: 1px solid #cbd4e1; border-radius: 5px; }
button { width: 100%; padding: 12px; margin-top: 14px; background: #6610f2; color: white; border: none; border-radius: 5px; cursor: pointer; }
button:hover { background: #520dc2; }
.result { padding: 14px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 5px; }""",
        "js": """function registerUser() {
    var name = document.getElementById('regName').value;
    var email = document.getElementById('regEmail').value;
    var password = document.getElementById('regPassword').value;
    if (!name || !email || !password) {
        alert('Please fill all registration fields.');
        return;
    }
    document.getElementById('authResult').innerText =
    'Registered ' + name + ' with email ' + email + '.';
}
function loginUser() {
    var email = document.getElementById('loginEmail').value;
    var password = document.getElementById('loginPassword').value;
    if (!email || !password) {
        alert('Please fill login email and password.');
        return;
    }
    document.getElementById('authResult').innerText =
    'Login attempted for ' + email + '.';
}""",
    },
    "product_listing": {
        "title": "Product Listing and Cart",
        "html": """
<div class=\"container\">
    <h2>Product Listing</h2>
    <div class=\"product-grid\">
        <div class=\"product-card\">
            <h4>Notebook</h4>
            <p>₹120</p>
            <button onclick=\"addToCart('Notebook', 120)\">Add to Cart</button>
        </div>
        <div class=\"product-card\">
            <h4>Pen Set</h4>
            <p>₹80</p>
            <button onclick=\"addToCart('Pen Set', 80)\">Add to Cart</button>
        </div>
        <div class=\"product-card\">
            <h4>Water Bottle</h4>
            <p>₹150</p>
            <button onclick=\"addToCart('Water Bottle', 150)\">Add to Cart</button>
        </div>
    </div>
    <h3>Cart</h3>
    <ul id=\"cartList\" class=\"cart-list\"></ul>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #f6f9fc; margin: 0; padding: 20px; }
.container { max-width: 740px; margin: auto; }
.product-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; margin-bottom: 18px; }
.product-card { background: white; padding: 16px; border-radius: 10px; border: 1px solid #dde5f0; text-align: center; }
.product-card button { margin-top: 12px; padding: 8px 12px; border: none; border-radius: 6px; background: #17a2b8; color: white; cursor: pointer; }
.product-card button:hover { background: #138496; }
.cart-list { list-style: none; padding: 0; }
.cart-list li { display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; border: 1px solid #e8eef4; margin-bottom: 8px; border-radius: 8px; background: white; }
.cart-list button { background: #dc3545; color: white; border: none; border-radius: 5px; padding: 6px 10px; cursor: pointer; }""",
        "js": """function addToCart(name, price) {
    var list = document.getElementById('cartList');
    var li = document.createElement('li');
    li.innerHTML =
    '<span>' + name + ' - ₹' + price + '</span>' +
    ' <button onclick=\"this.parentElement.remove()\">Remove</button>';
    list.appendChild(li);
}""",
    },
    "appointment_booking": {
        "title": "Appointment Booking",
        "html": """
<div class=\"container\">
    <h2>Appointment Booking</h2>
    <label>Your Name</label>
    <input type=\"text\" id=\"bookName\" placeholder=\"Name\">

    <label>Service</label>
    <input type=\"text\" id=\"bookService\" placeholder=\"Service required\">

    <label>Date</label>
    <input type=\"date\" id=\"bookDate\">

    <label>Time</label>
    <input type=\"time\" id=\"bookTime\">

    <button onclick=\"bookAppointment()\">Book Appointment</button>
    <div id=\"bookingResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #f7f8fd; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 4px 14px rgba(0,0,0,0.07); }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #cbd5e1; }
button { width: 100%; margin-top: 16px; padding: 12px; background: #0069d9; color: white; border: none; border-radius: 5px; cursor: pointer; }
button:hover { background: #0056b3; }
.result { margin-top: 16px; padding: 14px; background: #e2f0ff; border: 1px solid #b8daff; border-radius: 5px; }""",
        "js": """function bookAppointment() {
    var name = document.getElementById('bookName').value;
    var service = document.getElementById('bookService').value;
    var date = document.getElementById('bookDate').value;
    var time = document.getElementById('bookTime').value;
    if (!name || !service || !date || !time) {
        alert('Please fill all fields before booking.');
        return;
    }
    document.getElementById('bookingResult').innerText =
    'Appointment booked for ' + name + ' on ' + date + ' at ' + time + ' for ' + service + '.';
}""",
    },
    "quiz_interface": {
        "title": "Quiz Interface",
        "html": """
<div class=\"container\">
    <h2>Quiz Interface</h2>
    <div class=\"question\">
        <p>1. HTML is used for?</p>
        <label><input type=\"radio\" name=\"q1\" value=\"a\"> Styling</label>
        <label><input type=\"radio\" name=\"q1\" value=\"b\"> Structure</label>
        <label><input type=\"radio\" name=\"q1\" value=\"c\"> Logic</label>
    </div>
    <div class=\"question\">
        <p>2. CSS stands for?</p>
        <label><input type=\"radio\" name=\"q2\" value=\"a\"> Cascading Style Sheets</label>
        <label><input type=\"radio\" name=\"q2\" value=\"b\"> Computer Style Syntax</label>
        <label><input type=\"radio\" name=\"q2\" value=\"c\"> Custom Script Source</label>
    </div>
    <div class=\"question\">
        <p>3. JavaScript is used to?</p>
        <label><input type=\"radio\" name=\"q3\" value=\"a\"> Create page structure</label>
        <label><input type=\"radio\" name=\"q3\" value=\"b\"> Add interactivity</label>
        <label><input type=\"radio\" name=\"q3\" value=\"c\"> Add server data</label>
    </div>
    <button onclick=\"submitQuiz()\">Submit Quiz</button>
    <div id=\"quizResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #fbfbfb; padding: 20px; }
.container { max-width: 620px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
.question { margin-bottom: 18px; }
.question p { margin-bottom: 8px; font-weight: bold; }
label { display: block; margin-bottom: 6px; cursor: pointer; }
button { background: #28a745; color: white; border: none; padding: 12px 16px; border-radius: 6px; cursor: pointer; }
button:hover { background: #218838; }
.result { margin-top: 16px; padding: 14px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 6px; }""",
        "js": """function submitQuiz() {
    var score = 0;
    if (document.querySelector('input[name=q1]:checked')?.value === 'b') score += 1;
    if (document.querySelector('input[name=q2]:checked')?.value === 'a') score += 1;
    if (document.querySelector('input[name=q3]:checked')?.value === 'b') score += 1;
    document.getElementById('quizResult').innerText =
    'Score: ' + score + ' / 3';
}""",
    },
    "quiz_timer": {
        "title": "Quiz App with Timer",
        "html": """<div class=\"container\">
    <h2>Quiz App with Timer</h2>
    <div class=\"timer-bar\">Time left: <span id=\"timerValue\">10</span> seconds</div>
    <div id=\"timerWarning\" class=\"warning\"></div>
    <div class=\"question\">
        <p>1. HTML stands for?</p>
        <label><input type=\"radio\" name=\"qt1\" value=\"a\"> Hyper Text Markup Language</label>
        <label><input type=\"radio\" name=\"qt1\" value=\"b\"> Home Tool Markup Language</label>
        <label><input type=\"radio\" name=\"qt1\" value=\"c\"> Hyperlinks Text Mark Language</label>
    </div>
    <div class=\"question\">
        <p>2. Which tag adds a paragraph?</p>
        <label><input type=\"radio\" name=\"qt2\" value=\"a\"> &lt;p&gt;</label>
        <label><input type=\"radio\" name=\"qt2\" value=\"b\"> &lt;div&gt;</label>
        <label><input type=\"radio\" name=\"qt2\" value=\"c\"> &lt;span&gt;</label>
    </div>
    <div class=\"question\">
        <p>3. CSS is used for?</p>
        <label><input type=\"radio\" name=\"qt3\" value=\"a\"> Structure</label>
        <label><input type=\"radio\" name=\"qt3\" value=\"b\"> Styling</label>
        <label><input type=\"radio\" name=\"qt3\" value=\"c\"> Data storage</label>
    </div>
    <div class=\"question\">
        <p>4. JavaScript runs in?</p>
        <label><input type=\"radio\" name=\"qt4\" value=\"a\"> Browser</label>
        <label><input type=\"radio\" name=\"qt4\" value=\"b\"> Printer</label>
        <label><input type=\"radio\" name=\"qt4\" value=\"c\"> Processor</label>
    </div>
    <div class=\"question\">
        <p>5. Which method stops a timer?</p>
        <label><input type=\"radio\" name=\"qt5\" value=\"a\"> clearInterval()</label>
        <label><input type=\"radio\" name=\"qt5\" value=\"b\"> setInterval()</label>
        <label><input type=\"radio\" name=\"qt5\" value=\"c\"> startTimer()</label>
    </div>
    <button onclick=\"submitQuizTimer()\">Submit Quiz</button>
    <div id=\"quizTimerResult\" class=\"result\"></div>
</div>""",
        "css": """body { font-family: Arial, sans-serif; background: #fdfdfd; padding: 20px; }
.container { max-width: 700px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 2px 16px rgba(0,0,0,0.08); }
.timer-bar { font-size: 1.1rem; margin-bottom: 10px; }
.warning { color: #d63384; margin-bottom: 12px; font-weight: bold; }
.question { margin-bottom: 16px; }
.question p { margin-bottom: 6px; font-weight: bold; }
label { display: block; margin-bottom: 6px; cursor: pointer; }
button { padding: 12px 16px; background: #0d6efd; color: white; border: none; border-radius: 6px; cursor: pointer; }
button:hover { background: #0b5ed7; }
.result { margin-top: 16px; padding: 14px; background: #e9f7ef; border: 1px solid #d1e7dd; border-radius: 6px; }""",
        "js": """var quizTimerInterval;
var quizTimerRemaining = 10;
var quizTimerFinished = false;
var quizTimerAnswers = {
    qt1: 'a',
    qt2: 'a',
    qt3: 'b',
    qt4: 'a',
    qt5: 'a'
};

function startQuizTimer() {
    updateQuizTimer();
    quizTimerInterval = setInterval(updateQuizTimer, 1000);
}

function updateQuizTimer() {
    document.getElementById('timerValue').innerText = quizTimerRemaining;
    if (quizTimerRemaining <= 5) {
        document.getElementById('timerWarning').innerText = 'Only 5 seconds remaining!';
    }
    if (quizTimerRemaining <= 0) {
        clearInterval(quizTimerInterval);
        submitQuizTimer();
        return;
    }
    quizTimerRemaining--;
}

function submitQuizTimer() {
    if (quizTimerFinished) return;
    quizTimerFinished = true;
    clearInterval(quizTimerInterval);
    var score = 0;
    for (var key in quizTimerAnswers) {
        var selected = document.querySelector('input[name=' + key + ']:checked');
        if (selected && selected.value === quizTimerAnswers[key]) {
            score++;
        }
    }
    document.querySelectorAll('input[type=radio]').forEach(function(input) {
        input.disabled = true;
    });
    document.getElementById('quizTimerResult').innerText =
        'Final Score: ' + score + ' / 5';
}

startQuizTimer();""",
    },
    "event_countdown": {
        "title": "Event Countdown Timer",
        "html": """<div class=\"container\">
    <h2>Event Registration Countdown</h2>
    <div class=\"countdown-box\">
        <div>Days: <span id=\"days\">0</span></div>
        <div>Hours: <span id=\"hours\">0</span></div>
        <div>Minutes: <span id=\"minutes\">0</span></div>
        <div>Seconds: <span id=\"seconds\">0</span></div>
    </div>
    <div id=\"countdownMessage\" class=\"message\"></div>
    <form>
        <label>Name</label>
        <input type=\"text\" id=\"eventName\" placeholder=\"Your name\">
        <label>Email</label>
        <input type=\"email\" id=\"eventEmail\" placeholder=\"Your email\">
        <button type=\"button\" onclick=\"submitRegistration()\">Register</button>
        <div id=\"registrationResult\" class=\"result\"></div>
    </form>
</div>""",
        "css": """body { font-family: Arial, sans-serif; background: #f7fbff; padding: 20px; }
.container { max-width: 560px; margin: auto; background: white; padding: 24px; border-radius: 10px; box-shadow: 0 2px 18px rgba(0,0,0,0.08); }
.countdown-box { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; margin-bottom: 16px; }
.countdown-box div { background: #eef5ff; padding: 12px; border-radius: 8px; font-weight: bold; text-align: center; }
.message { margin-bottom: 14px; font-size: 1rem; color: #0d6efd; }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border: 1px solid #cbd5e1; border-radius: 6px; }
button { width: 100%; margin-top: 16px; padding: 12px; background: #198754; color: white; border: none; border-radius: 6px; cursor: pointer; }
button:hover { background: #157347; }
.result { margin-top: 14px; padding: 12px; background: #d1e7dd; border: 1px solid #badbcc; border-radius: 6px; }""",
        "js": """var countdownInterval;
var targetDate = new Date('December 31, 2026 23:59:59').getTime();

function updateCountdown() {
    var now = new Date().getTime();
    var diff = targetDate - now;
    if (diff <= 0) {
        clearInterval(countdownInterval);
        document.getElementById('countdownMessage').innerText = 'Registration Closed';
        document.getElementById('days').innerText = '0';
        document.getElementById('hours').innerText = '0';
        document.getElementById('minutes').innerText = '0';
        document.getElementById('seconds').innerText = '0';
        return;
    }
    var days = Math.floor(diff / (1000 * 60 * 60 * 24));
    var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((diff % (1000 * 60)) / 1000);
    document.getElementById('days').innerText = days;
    document.getElementById('hours').innerText = hours;
    document.getElementById('minutes').innerText = minutes;
    document.getElementById('seconds').innerText = seconds;
}

function submitRegistration() {
    var name = document.getElementById('eventName').value;
    var email = document.getElementById('eventEmail').value;
    if (!name || !email) {
        alert('Please fill name and email to register.');
        return;
    }
    document.getElementById('registrationResult').innerText =
        'Registration complete for ' + name + '.';
}

countdownInterval = setInterval(updateCountdown, 1000);
updateCountdown();""",
    },
    "student_marks": {
        "title": "Student Marks Calculator",
        "html": """
<div class=\"container\">
    <h2>Student Marks Calculator</h2>
    <label>Maths</label>
    <input type=\"number\" id=\"mark1\" value=\"0\">
    <label>Science</label>
    <input type=\"number\" id=\"mark2\" value=\"0\">
    <label>English</label>
    <input type=\"number\" id=\"mark3\" value=\"0\">
    <label>Social</label>
    <input type=\"number\" id=\"mark4\" value=\"0\">
    <label>Hindi</label>
    <input type=\"number\" id=\"mark5\" value=\"0\">
    <button onclick=\"calculateMarks()\">Calculate Grade</button>
    <div id=\"marksResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #f2f6f9; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.09); }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #b8c7d4; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #007bff; color: white; cursor: pointer; }
button:hover { background: #0056d2; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #cce5ff; background: #e9f7ff; border-radius: 6px; }""",
        "js": """function calculateMarks() {
    var m1 = Number(document.getElementById('mark1').value);
    var m2 = Number(document.getElementById('mark2').value);
    var m3 = Number(document.getElementById('mark3').value);
    var m4 = Number(document.getElementById('mark4').value);
    var m5 = Number(document.getElementById('mark5').value);
    var total = m1 + m2 + m3 + m4 + m5;
    var percentage = total / 5;
    var grade = 'F';
    if (percentage >= 90) grade = 'A';
    else if (percentage >= 75) grade = 'B';
    else if (percentage >= 60) grade = 'C';
    else if (percentage >= 50) grade = 'D';
    document.getElementById('marksResult').innerText =
    'Total: ' + total + '\nPercentage: ' + percentage.toFixed(1) + '%\nGrade: ' + grade;
}""",
    },
    "math_operations": {
        "title": "Math Operations Calculator",
        "html": """
<div class=\"container\">
    <h2>Math Operations Calculator</h2>
    <label>Number 1</label>
    <input type=\"number\" id=\"mathValue1\" placeholder=\"Enter first number\">
    <label>Number 2</label>
    <input type=\"number\" id=\"mathValue2\" placeholder=\"Enter second number\">
    <label>Operation</label>
    <select id=\"mathOperation\">
        <option value=\"add\">Add</option>
        <option value=\"subtract\">Subtract</option>
        <option value=\"multiply\">Multiply</option>
        <option value=\"divide\">Divide</option>
    </select>
    <button onclick=\"calculateOperation()\">Calculate</button>
    <div id=\"mathResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #fff9f0; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; }
input, select { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #d1d5db; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #fd7e14; color: white; cursor: pointer; }
button:hover { background: #e8590c; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #ffe8cc; background: #fff4e6; border-radius: 6px; }""",
        "js": """function calculateOperation() {
    var a = Number(document.getElementById('mathValue1').value);
    var b = Number(document.getElementById('mathValue2').value);
    var op = document.getElementById('mathOperation').value;
    if (isNaN(a) || isNaN(b)) {
        alert('Please enter both numbers.');
        return;
    }
    var result;
    if (op === 'add') result = a + b;
    else if (op === 'subtract') result = a - b;
    else if (op === 'multiply') result = a * b;
    else if (op === 'divide') {
        if (b === 0) {
            alert('Cannot divide by zero.');
            return;
        }
        result = a / b;
    }
    document.getElementById('mathResult').innerText = 'Result: ' + result;
}""",
    },
    "bmi_calculator": {
        "title": "BMI Calculator",
        "html": """
<div class=\"container\">
    <h2>BMI Calculator</h2>
    <label>Weight (kg)</label>
    <input type=\"number\" id=\"bmiWeight\" placeholder=\"Enter weight\">
    <label>Height (cm)</label>
    <input type=\"number\" id=\"bmiHeight\" placeholder=\"Enter height\">
    <button onclick=\"calculateBMI()\">Calculate BMI</button>
    <div id=\"bmiResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #f0f7ff; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 16px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #cbd5e1; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #0d6efd; color: white; cursor: pointer; }
button:hover { background: #0b5ed7; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #cfe2ff; background: #e7f1ff; border-radius: 6px; }""",
        "js": """function calculateBMI() {
    var weight = Number(document.getElementById('bmiWeight').value);
    var heightCm = Number(document.getElementById('bmiHeight').value);
    if (!weight || !heightCm) {
        alert('Please enter weight and height.');
        return;
    }
    var height = heightCm / 100;
    var bmi = weight / (height * height);
    var category = 'Underweight';
    if (bmi >= 30) category = 'Obese';
    else if (bmi >= 25) category = 'Overweight';
    else if (bmi >= 18.5) category = 'Normal weight';
    document.getElementById('bmiResult').innerText =
        'BMI: ' + bmi.toFixed(1) + ' (' + category + ')';
}""",
    },
    "currency_converter": {
        "title": "Currency Converter",
        "html": """
<div class=\"container\">
    <h2>Currency Converter</h2>
    <label>Amount</label>
    <input type=\"number\" id=\"currencyAmount\" placeholder=\"Enter amount\">
    <label>From</label>
    <select id=\"currencyFrom\">
        <option value=\"INR\">INR</option>
        <option value=\"USD\">USD</option>
        <option value=\"EUR\">EUR</option>
    </select>
    <label>To</label>
    <select id=\"currencyTo\">
        <option value=\"USD\">USD</option>
        <option value=\"EUR\">EUR</option>
        <option value=\"INR\">INR</option>
    </select>
    <button onclick=\"convertCurrency()\">Convert</button>
    <div id=\"currencyResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #f9f8ff; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; }
input, select { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #d2d6dc; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #6610f2; color: white; cursor: pointer; }
button:hover { background: #520dc2; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #e2d9ff; background: #f5f3ff; border-radius: 6px; }""",
        "js": """function convertCurrency() {
    var amount = Number(document.getElementById('currencyAmount').value);
    var from = document.getElementById('currencyFrom').value;
    var to = document.getElementById('currencyTo').value;
    if (!amount) {
        alert('Please enter an amount.');
        return;
    }
    var rates = {
        'INR': { 'INR': 1, 'USD': 0.012, 'EUR': 0.011 },
        'USD': { 'INR': 83, 'USD': 1, 'EUR': 0.92 },
        'EUR': { 'INR': 90, 'USD': 1.09, 'EUR': 1 }
    };
    var converted = amount * rates[from][to];
    document.getElementById('currencyResult').innerText =
        amount + ' ' + from + ' = ' + converted.toFixed(2) + ' ' + to;
}""",
    },
    "cake_order": {
        "title": "Cake Order Calculator",
        "html": """
<div class=\"container\">
    <h2>Cake Order Calculator</h2>
    <label>Customer Name</label>
    <input type=\"text\" id=\"cakeName\" placeholder=\"Enter your name\">
    <label>Cake Flavor</label>
    <select id=\"cakeFlavor\">
        <option value=\"Chocolate\">Chocolate</option>
        <option value=\"Vanilla\">Vanilla</option>
        <option value=\"Strawberry\">Strawberry</option>
    </select>
    <label>Size</label>
    <select id=\"cakeSize\">
        <option value=\"small\">Small - ₹500</option>
        <option value=\"medium\">Medium - ₹800</option>
        <option value=\"large\">Large - ₹1100</option>
    </select>
    <label>Quantity</label>
    <input type=\"number\" id=\"cakeQuantity\" value=\"1\" min=\"1\">
    <button onclick=\"calculateCakeOrder()\">Calculate Total</button>
    <div id=\"cakeResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #fff5f5; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; }
input, select { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #e2d9dc; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #dc3545; color: white; cursor: pointer; }
button:hover { background: #c82333; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #f5c6cb; background: #f8d7da; border-radius: 6px; }""",
        "js": """function calculateCakeOrder() {
    var name = document.getElementById('cakeName').value;
    var size = document.getElementById('cakeSize').value;
    var flavor = document.getElementById('cakeFlavor').value;
    var qty = Number(document.getElementById('cakeQuantity').value);
    if (!name || qty < 1) {
        alert('Please enter your name and a valid quantity.');
        return;
    }
    var prices = { small: 500, medium: 800, large: 1100 };
    var total = prices[size] * qty;
    document.getElementById('cakeResult').innerText =
        'Order for ' + name + ': ' + qty + ' x ' + flavor + ' cake (' + size + ') = ₹' + total;
}""",
    },
    "student_registration": {
        "title": "Student Registration Form",
        "html": """
<div class=\"container\">
    <h2>Student Registration Form</h2>
    <label>Student Name</label>
    <input type=\"text\" id=\"studentName\" placeholder=\"Enter name\">
    <label>Class</label>
    <input type=\"text\" id=\"studentClass\" placeholder=\"Enter class\">
    <label>Roll Number</label>
    <input type=\"text\" id=\"studentRoll\" placeholder=\"Enter roll number\">
    <label>Parent Contact</label>
    <input type=\"tel\" id=\"parentContact\" placeholder=\"Enter contact\">
    <button onclick=\"registerStudent()\">Register Student</button>
    <div id=\"registrationResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #f2f8f5; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #cbd5d0; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #20c997; color: white; cursor: pointer; }
button:hover { background: #198754; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #d1e7dd; background: #e9f7ef; border-radius: 6px; }""",
        "js": """function registerStudent() {
    var name = document.getElementById('studentName').value;
    var studentClass = document.getElementById('studentClass').value;
    var roll = document.getElementById('studentRoll').value;
    var contact = document.getElementById('parentContact').value;
    if (!name || !studentClass || !roll || !contact) {
        alert('Please complete all registration fields.');
        return;
    }
    document.getElementById('registrationResult').innerText =
        'Student registered: ' + name + ' | Class: ' + studentClass + ' | Roll No: ' + roll + ' | Contact: ' + contact;
}""",
    },
    "student_attendance": {
        "title": "Student Attendance Sheet",
        "html": """
<div class=\"container\">
    <h2>Student Attendance Sheet</h2>
    <div class=\"attendance-row\">
        <span>Student Name</span>
        <span>Status</span>
    </div>
    <div class=\"attendance-row\">
        <span>Ravi</span>
        <select id=\"attendance1\">
            <option>Present</option>
            <option>Absent</option>
            <option>Leave</option>
        </select>
    </div>
    <div class=\"attendance-row\">
        <span>Priya</span>
        <select id=\"attendance2\">
            <option>Present</option>
            <option>Absent</option>
            <option>Leave</option>
        </select>
    </div>
    <div class=\"attendance-row\">
        <span>Aditi</span>
        <select id=\"attendance3\">
            <option>Present</option>
            <option>Absent</option>
            <option>Leave</option>
        </select>
    </div>
    <button onclick=\"saveAttendance()\">Save Attendance</button>
    <div id=\"attendanceResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #fff8e8; padding: 20px; }
.container { max-width: 560px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 14px rgba(0,0,0,0.08); }
.attendance-row { display: grid; grid-template-columns: 1.5fr 1fr; gap: 14px; align-items: center; margin-bottom: 12px; }
.attendance-row span { font-weight: 600; }
select { width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #d6d4c9; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #fd7e14; color: white; cursor: pointer; }
button:hover { background: #e8590c; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #ffe5cc; background: #fff4e6; border-radius: 6px; }""",
        "js": """function saveAttendance() {
    var status1 = document.getElementById('attendance1').value;
    var status2 = document.getElementById('attendance2').value;
    var status3 = document.getElementById('attendance3').value;
    document.getElementById('attendanceResult').innerText =
        'Attendance saved:\nRavi: ' + status1 + '\nPriya: ' + status2 + '\nAditi: ' + status3;
}""",
    },
    "contact_management": {
        "title": "Contact Management System",
        "html": """
<div class=\"container\">
    <h2>Contact Management System</h2>
    <label>Name</label>
    <input type=\"text\" id=\"contactName\" placeholder=\"Contact name\">
    <label>Phone</label>
    <input type=\"tel\" id=\"contactPhone\" placeholder=\"Phone number\">
    <label>Email</label>
    <input type=\"email\" id=\"contactEmail\" placeholder=\"Email address\">
    <button onclick=\"addContact()\">Add Contact</button>
    <ul id=\"contactList\" class=\"contact-list\"></ul>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #eef6ff; padding: 20px; }
.container { max-width: 560px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 14px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #cbd5e1; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #0d6efd; color: white; cursor: pointer; }
button:hover { background: #0b5ed7; }
.contact-list { list-style: none; padding: 0; margin-top: 16px; }
.contact-list li { display: flex; justify-content: space-between; align-items: center; padding: 12px; border: 1px solid #dbe5ff; border-radius: 6px; margin-bottom: 10px; }
.contact-list button { background: #dc3545; color: white; border: none; border-radius: 5px; padding: 6px 10px; cursor: pointer; }""",
        "js": """function addContact() {
    var name = document.getElementById('contactName').value;
    var phone = document.getElementById('contactPhone').value;
    var email = document.getElementById('contactEmail').value;
    if (!name || !phone || !email) {
        alert('Please fill in all contact details.');
        return;
    }
    var list = document.getElementById('contactList');
    var li = document.createElement('li');
    li.innerHTML = '<span>' + name + ' | ' + phone + ' | ' + email + '</span>' +
        ' <button onclick="this.parentElement.remove()">Delete</button>';
    list.appendChild(li);
    document.getElementById('contactName').value = '';
    document.getElementById('contactPhone').value = '';
    document.getElementById('contactEmail').value = '';
}""",
    },
    "event_management": {
        "title": "Event Management System",
        "html": """
<div class=\"container\">
    <h2>Event Management System</h2>
    <label>Event Name</label>
    <input type=\"text\" id=\"eventName\" placeholder=\"Enter event name\">
    <label>Date</label>
    <input type=\"date\" id=\"eventDate\">
    <label>Venue</label>
    <input type=\"text\" id=\"eventVenue\" placeholder=\"Enter venue\">
    <button onclick=\"createEvent()\">Create Event</button>
    <div id=\"eventResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #f8fff5; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #cbd9cc; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #198754; color: white; cursor: pointer; }
button:hover { background: #157347; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #d4edda; background: #e9f7ef; border-radius: 6px; }""",
        "js": """function createEvent() {
    var name = document.getElementById('eventName').value;
    var date = document.getElementById('eventDate').value;
    var venue = document.getElementById('eventVenue').value;
    if (!name || !date || !venue) {
        alert('Please enter event name, date, and venue.');
        return;
    }
    document.getElementById('eventResult').innerText =
        'Event created: ' + name + ' on ' + date + ' at ' + venue + '.';
}""",
    },
    "survey_form": {
        "title": "Survey Form",
        "html": """
<div class=\"container\">
    <h2>Survey Form</h2>
    <label>Name</label>
    <input type=\"text\" id=\"surveyName\" placeholder=\"Your name\">
    <label>Age Group</label>
    <select id=\"surveyAge\">
        <option value=\"under18\">Under 18</option>
        <option value=\"18to30\">18-30</option>
        <option value=\"31to50\">31-50</option>
        <option value=\"50plus\">50+</option>
    </select>
    <label>Feedback</label>
    <textarea id=\"surveyFeedback\" placeholder=\"Share your feedback\"></textarea>
    <button onclick=\"submitSurvey()\">Submit Survey</button>
    <div id=\"surveyResult\" class=\"result\"></div>
</div>
""",
        "css": """body { font-family: Arial, sans-serif; background: #f7f5ff; padding: 20px; }
.container { max-width: 560px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 14px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; }
input, select, textarea { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #d5d2e1; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #6f42c1; color: white; cursor: pointer; }
button:hover { background: #5a32a3; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #e2d9ff; background: #f3ecff; border-radius: 6px; }""",
        "js": """function submitSurvey() {
    var name = document.getElementById('surveyName').value;
    var ageGroup = document.getElementById('surveyAge').value;
    var feedback = document.getElementById('surveyFeedback').value;
    if (!name || !feedback) {
        alert('Please enter your name and feedback.');
        return;
    }
    document.getElementById('surveyResult').innerText =
        'Survey received from ' + name + ' (' + ageGroup + ').\nFeedback: ' + feedback;
}""",
    },
}


def list_templates():
    """Return the available template names."""
    return list(_TEMPLATES.keys())


def listtemplates():
    """Alias for list_templates()."""
    return list_templates()


def _get_template_data(name):
    try:
        return _TEMPLATES[name]
    except KeyError as exc:
        raise KeyError(f"Unknown template: {name}") from exc


def get_html(name):
    """Return the HTML body content for the named template."""
    return _get_template_data(name)["html"]


def get_css(name):
    """Return the CSS code for the named template."""
    return _get_template_data(name)["css"]


def get_js(name):
    """Return the JavaScript code for the named template."""
    return _get_template_data(name)["js"]


def get_template(name):
    """Return all code sections for the named template."""
    data = _get_template_data(name)
    return {
        "html": data["html"],
        "css": data["css"],
        "js": data["js"],
        "combined": get_combined(name),
        "title": data["title"],
    }


def get_combined(name):
    """Return a full HTML document with CSS and JS embedded."""
    data = _get_template_data(name)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{data['title']}</title>
    <style>
{data['css']}
    </style>
</head>
<body>
{data['html']}
    <script>
{data['js']}
    </script>
</body>
</html>"""


def print_template(name):
    """Print the template sections to the console with proper formatting."""
    data = get_template(name)
    print(f'=== {data["title"]} ===\n')
    print('HTML:')
    print(data["html"])
    print('\nCSS:')
    print(data["css"])
    print('\nJavaScript:')
    print(data["js"])
    print('\n=== Full Combined HTML ===')
    print(get_combined(name))


def save_template(name, path):
    """Save the full combined HTML file for the named template."""
    html = get_combined(name)
    destination = Path(path)
    destination.write_text(html, encoding="utf-8")
    return destination
