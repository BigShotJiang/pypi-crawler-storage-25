# web/

Static-site generator: home carousels, deck pages, viewer bridge, academic
notes pipeline (markdown + math + citations + Tufte sidenotes).

## Public surface

- `SiteConfig.load()` -- merge committed `site.toml` with env overrides
  (`SIMPLEX_GA_TAG`, `SIMPLEX_BASE_URL`, `SIMPLEX_BRAND`, `SIMPLEX_PREVIEW`).
- `notes.render(notes_md_path, slide_count=..., bibliography=...)` --
  markdown-it + dollarmath + footnotes + `[slide:N]` + `\cite{}` +
  `\ref{}` -> Tufte-style academic HTML (serif body, Lato headings,
  right-margin sidenotes, colour-coded theorem callouts, references
  appendix, auto-fitted display math).
- `bibliography.Bibliography.load(refs_bib)` -- parse a `.bib`, assign
  biblatex `alpha` labels (`[DHS11]`-style), render the cited subset.
- `callouts.transform(html)` -- rewrite `> **Theorem 3.1.** ...`
  blockquotes as anchored `<aside class="callout callout-theorem"
  id="theorem-3-1">` blocks; resolve `\ref{}` placeholders to the
  display label.
- `builder.build(decks_dir, site_dir, *, render=True, site_cfg=None, only=(), scenes=(), watch=False)`
  -- discover -> render -> pdf -> reconcile -> thumbnail -> notes ->
  emit per-deck `slides.html` + page + per-section pages + home.

## Don't

- Don't bundle JS or load CDNs. Tailwind / KaTeX / RevealJS / Lato /
  Merriweather are vendored under `static/` (see `static/README.md`).
- Don't hand-edit anything under `site/`. Edit templates / CSS instead.
- Don't import Jinja templates as Python modules. Loaded via
  `PackageLoader("simplex.web", "templates")`.
- Don't write a manual "References" section in `notes.md`. Use
  `\cite{key}` and ship a `refs.bib`; the renderer appends the list.
