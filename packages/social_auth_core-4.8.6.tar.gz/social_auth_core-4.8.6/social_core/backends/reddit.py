"""
Reddit OAuth2 backend, docs at:
    https://python-social-auth.readthedocs.io/en/latest/backends/reddit.html
"""

from typing import Any, cast

from .oauth import BaseOAuth2


class RedditOAuth2(BaseOAuth2):
    """Reddit OAuth2 authentication backend"""

    name = "reddit"
    AUTHORIZATION_URL = "https://ssl.reddit.com/api/v1/authorize"
    ACCESS_TOKEN_URL = "https://ssl.reddit.com/api/v1/access_token"
    REFRESH_TOKEN_METHOD = "POST"
    REDIRECT_STATE = False
    SCOPE_SEPARATOR = ","
    DEFAULT_SCOPE = ["identity"]
    EXTRA_DATA = [
        ("id", "id"),
        ("name", "username"),
        ("link_karma", "link_karma"),
        ("comment_karma", "comment_karma"),
        ("refresh_token", "refresh_token"),
        ("expires_in", "expires_in"),
    ]

    def get_user_details(self, response):
        """Return user details from Reddit account"""
        return {
            "username": response.get("name"),
            "email": "",
            "fullname": "",
            "first_name": "",
            "last_name": "",
        }

    def user_data(self, access_token: str, *args, **kwargs) -> dict[str, Any] | None:
        """Loads user data from service"""
        return self.get_json(
            "https://oauth.reddit.com/api/v1/me.json",
            headers={"Authorization": f"bearer {access_token}"},
        )

    def auth_headers(self):
        return {"Authorization": self.get_key_and_secret_basic_auth()}

    def refresh_token_params(self, token: str, *args, **kwargs) -> dict[str, str]:
        params = super().refresh_token_params(token)
        params["redirect_uri"] = self.redirect_uri or cast(
            "str", kwargs.get("redirect_uri")
        )
        return params

    def auth_complete_credentials(self):
        return self.get_key_and_secret()
