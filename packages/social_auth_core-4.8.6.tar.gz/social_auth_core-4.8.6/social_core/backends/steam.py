"""
Steam OpenId backend, docs at:
    https://python-social-auth.readthedocs.io/en/latest/backends/steam.html
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from social_core.exceptions import AuthFailed

from .open_id import OpenIdAuth

if TYPE_CHECKING:
    from social_core.store import OpenIdStore

USER_INFO = "http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?"


class SteamOpenId(OpenIdAuth):
    name = "steam"
    URL = "https://steamcommunity.com/openid"

    def get_user_id(self, details, response):
        """Return user unique id provided by service"""
        return self._user_id(response)

    def get_user_details(self, response):
        player = self.get_json(
            USER_INFO,
            params={
                "key": self.setting("API_KEY"),
                "steamids": self._user_id(response),
            },
        )
        if len(player["response"]["players"]) > 0:
            player = player["response"]["players"][0]
            details = {
                "username": player.get("personaname"),
                "email": "",
                "fullname": "",
                "first_name": "",
                "last_name": "",
                "player": player,
            }
        else:
            details = {}
        return details

    def get_consumer_store(self) -> OpenIdStore | None:
        # Steam seems to support stateless mode only, ignore store
        return None

    def _user_id(self, response):
        if not response.identity_url.startswith(self.URL):
            raise AuthFailed(self, "Openid identifier mismatch")
        user_id = response.identity_url.rsplit("/", 1)[-1]
        if not user_id.isdigit():
            raise AuthFailed(self, "Missing Steam Id")
        return user_id
