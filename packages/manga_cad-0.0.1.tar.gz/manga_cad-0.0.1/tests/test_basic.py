import unittest
from manga_cad import OlympusScraper, search_manga

class TestMangaCad(unittest.TestCase):
    def setUp(self):
        self.scraper = OlympusScraper()

    def test_search_manga_empty(self):
        """Test search with empty query."""
        results = search_manga("")
        self.assertEqual(results, [])

    def test_search_manga_invalid(self):
        """Test search with a query that likely has no results."""
        results = search_manga("NonExistentManga123456789")
        self.assertEqual(results, [])

if __name__ == '__main__':
    unittest.main()
