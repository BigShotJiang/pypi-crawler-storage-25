"""
Configuration settings for the manga-cad library.
"""

BASE_URL = "https://www.olympustaff.com"
SEARCH_URL = f"{BASE_URL}/series"

# Default headers to avoid being blocked
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
    "Referer": BASE_URL
}

# Time delay between requests (in seconds)
DELAY = 1
