"""
manga-cad: A Python library for scraping manga and manhwa data from OlympusStaff.
"""

from .olympus_scraper import (
    OlympusScraper,
    get_trending_manga,
    search_manga,
    get_manga_details,
    get_chapters,
    get_chapter_pages
)

__version__ = "0.0.1"
__author__ = "YOUR NAME"

__all__ = [
    "OlympusScraper",
    "get_trending_manga",
    "search_manga",
    "get_manga_details",
    "get_chapters",
    "get_chapter_pages"
]
