"""
Utility functions for the manga-cad library.
"""

import requests
from typing import Dict
from .config import HEADERS

def create_session() -> requests.Session:
    """
    Creates a requests.Session with default headers.

    Returns:
        requests.Session: A session object with pre-configured headers.
    """
    session = requests.Session()
    session.headers.update(HEADERS)
    return session

def get_default_headers() -> Dict[str, str]:
    """
    Returns the default headers used for requests.

    Returns:
        Dict[str, str]: A dictionary containing the default headers.
    """
    return HEADERS.copy()
