"""
Main scraper module for OlympusStaff.com.
"""

import re
import requests
from bs4 import BeautifulSoup
from typing import List, Dict, Optional, Any
from .config import BASE_URL
from .utils import create_session

class OlympusScraper:
    """
    A class to scrape manga and manhwa data from OlympusStaff.com.
    """

    def __init__(self):
        """
        Initializes the scraper with a requests session.
        """
        self.session = create_session()

    def get_trending_manga(self) -> List[Dict[str, Any]]:
        """
        Fetches trending manga/manhwa from the homepage.

        Returns:
            List[Dict[str, Any]]: A list of dictionaries containing title, url, and img.
        
        Raises:
            requests.exceptions.RequestException: If a network error occurs.
        """
        try:
            response = self.session.get(BASE_URL, timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            trending_list = []
            # Selector for slider elements based on the site structure
            slides = soup.select('.swiper-slide a')
            
            for slide in slides:
                title = slide.get_text(strip=True)
                url = slide.get('href')
                if url and not url.startswith('http'):
                    url = BASE_URL + url
                
                img_tag = slide.find('img')
                img_url = img_tag.get('src') if img_tag else None
                
                if title and url:
                    trending_list.append({
                        'title': title,
                        'url': url,
                        'img': img_url
                    })
            
            return trending_list
        except requests.exceptions.RequestException:
            return []
        except Exception:
            return []

    def search_manga(self, query: str) -> List[Dict[str, Any]]:
        """
        Searches for manga or manhwa by title.

        Args:
            query (str): The search query.

        Returns:
            List[Dict[str, Any]]: A list of dictionaries containing title, url, and img.
        """
        if not query:
            return []

        try:
            # Using the series page for searching as it contains all manga
            response = self.session.get(f"{BASE_URL}/series", timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            results = []
            seen_urls = set()
            
            # Search in all links containing /series/
            links = soup.find_all('a', href=re.compile(r'/series/'))
            
            for link in links:
                url = link.get('href')
                if not url:
                    continue
                if not url.startswith('http'):
                    url = BASE_URL + url
                
                # Avoid duplicate links or the series page itself
                if url in seen_urls or url.endswith('/series'):
                    continue
                
                # Extract title from text or img alt attribute
                title = link.get_text(strip=True)
                if not title:
                    img = link.find('img')
                    title = img.get('alt', '') if img else ''
                
                if query.lower() in title.lower():
                    img_tag = link.find('img')
                    img_url = img_tag.get('src') if img_tag else None
                    
                    results.append({
                        'title': title,
                        'url': url,
                        'img': img_url
                    })
                    seen_urls.add(url)
            
            return results
        except requests.exceptions.RequestException:
            return []
        except Exception:
            return []

    def get_manga_details(self, manga_url: str) -> Optional[Dict[str, Any]]:
        """
        Fetches detailed information about a specific manga.

        Args:
            manga_url (str): The URL of the manga.

        Returns:
            Optional[Dict[str, Any]]: A dictionary with manga details or None if not found.
        """
        if not manga_url:
            return None

        try:
            response = self.session.get(manga_url, timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            title_tag = soup.find('h1')
            title = title_tag.get_text(strip=True) if title_tag else "Unknown"
            
            # Extract description
            description = "No description available"
            desc_tag = soup.find('p', class_='text-sm') or soup.find('div', class_='mt-4')
            if desc_tag:
                description = desc_tag.get_text(strip=True)
            
            # Status and Genres
            status = "Unknown"
            status_tag = soup.find('a', string=re.compile(r'مستمرة|مكتملة|متوقف'))
            if status_tag:
                status = status_tag.get_text(strip=True)
            
            genre_tags = soup.find_all('a', href=re.compile(r'/genre/'))
            genres = [g.get_text(strip=True) for g in genre_tags]
            
            # Cover image
            img_tag = soup.find('img', class_='rounded-lg')
            img_url = img_tag.get('src') if img_tag else None
            
            # Chapter count from tab
            chapters_count = "0"
            chapters_count_tag = soup.find('a', id='chapter-contact-tab')
            if chapters_count_tag:
                match = re.search(r'\((\d+)\)', chapters_count_tag.text)
                if match:
                    chapters_count = match.group(1)
            
            return {
                'title': title,
                'status': status,
                'genres': genres,
                'chapters_count': chapters_count,
                'description': description,
                'img_url': img_url,
                'url': manga_url
            }
        except requests.exceptions.RequestException:
            return None
        except Exception:
            return None

    def get_chapters(self, manga_url: str) -> List[Dict[str, Any]]:
        """
        Extracts all chapters for a given manga.

        Args:
            manga_url (str): The URL of the manga.

        Returns:
            List[Dict[str, Any]]: A list of dictionaries containing chapter number, title, and url.
        """
        if not manga_url:
            return []

        try:
            response = self.session.get(manga_url, timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            chapters = []
            # Find chapter links following the pattern /series/name/number
            chapter_links = soup.find_all('a', href=re.compile(rf"{re.escape(manga_url)}/\d+"))
            
            seen_urls = set()
            for link in chapter_links:
                url = link.get('href')
                if not url.startswith('http'):
                    url = BASE_URL + url
                
                if url in seen_urls:
                    continue
                
                # Extract chapter number from the end of the URL
                match = re.search(r'/(\d+)$', url)
                if match:
                    ch_num = match.group(1)
                    title = link.get_text(strip=True).replace('\n', ' ')
                    title = ' '.join(title.split())
                    
                    chapters.append({
                        'number': int(ch_num),
                        'title': title if title else f"Chapter {ch_num}",
                        'url': url
                    })
                    seen_urls.add(url)
            
            # Sort chapters ascending by number
            chapters.sort(key=lambda x: x['number'])
            
            return chapters
        except requests.exceptions.RequestException:
            return []
        except Exception:
            return []

    def get_chapter_pages(self, chapter_url: str) -> List[Dict[str, Any]]:
        """
        Extracts image URLs for all pages in a chapter.

        Args:
            chapter_url (str): The URL of the chapter.

        Returns:
            List[Dict[str, Any]]: A list of dictionaries containing page number and image url.
        """
        if not chapter_url:
            return []

        try:
            response = self.session.get(chapter_url, timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            images = []
            img_tags = soup.find_all('img')
            
            page_count = 1
            for img in img_tags:
                src = img.get('src') or img.get('data-src')
                if not src:
                    continue
                
                # Check if the image is part of the manga content
                if 'uploads' in src or 'storage' in src:
                    if not src.startswith('http'):
                        src = BASE_URL + src
                    
                    # Avoid duplicate images
                    if any(img_data['url'] == src for img_data in images):
                        continue

                    images.append({
                        'page': page_count,
                        'url': src
                    })
                    page_count += 1
            
            return images
        except requests.exceptions.RequestException:
            return []
        except Exception:
            return []

# Wrapper functions for easier access
def get_trending_manga() -> List[Dict[str, Any]]:
    """Global function to get trending manga."""
    return OlympusScraper().get_trending_manga()

def search_manga(query: str) -> List[Dict[str, Any]]:
    """Global function to search for manga."""
    return OlympusScraper().search_manga(query)

def get_manga_details(manga_url: str) -> Optional[Dict[str, Any]]:
    """Global function to get manga details."""
    return OlympusScraper().get_manga_details(manga_url)

def get_chapters(manga_url: str) -> List[Dict[str, Any]]:
    """Global function to get chapters."""
    return OlympusScraper().get_chapters(manga_url)

def get_chapter_pages(chapter_url: str) -> List[Dict[str, Any]]:
    """Global function to get chapter pages."""
    return OlympusScraper().get_chapter_pages(chapter_url)
