# manga-cad

A professional Python library for scraping manga and manhwa data from **OlympusStaff.com**.

## Description
`manga-cad` is a lightweight and efficient Python library designed to help developers easily fetch data from OlympusStaff. It supports searching for manga, viewing trending titles, retrieving detailed information, listing chapters, and getting page images.

## Features
- **Trending Manga/Manhwa**: Fetch the latest trending titles from the homepage.
- **Search Functionality**: Search for specific manga or manhwa by title.
- **Detailed Information**: Get status, genres, description, and cover images.
- **Chapter Listing**: Retrieve a full list of available chapters for any title.
- **Chapter Pages**: Get direct image URLs for all pages in a specific chapter.
- **Type Hints**: Fully typed for better IDE support and developer experience.
- **Error Handling**: Robust handling for network errors and invalid URLs.

## Installation
You can install the library directly from PyPI:

```bash
pip install manga-cad
```

## Usage Example

```python
from manga_cad import search_manga, get_chapters, get_chapter_pages

# Search for a manga
results = search_manga("Solo Leveling")

for manga in results:
    print(f"Title: {manga['title']}")
    print(f"URL: {manga['url']}")

# Get chapters for the first result
if results:
    manga_url = results[0]['url']
    chapters = get_chapters(manga_url)
    
    for chapter in chapters:
        print(f"Chapter {chapter['number']}: {chapter['title']}")

    # Get pages for the first chapter
    if chapters:
        pages = get_chapter_pages(chapters[0]['url'])
        for page in pages:
            print(f"Page {page['page']}: {page['url']}")
```

## Project Structure
```text
manga-cad/
├── manga_cad/
│   ├── __init__.py
│   ├── config.py
│   ├── utils.py
│   └── olympus_scraper.py
├── tests/
│   └── test_basic.py
├── README.md
├── LICENSE
├── requirements.txt
├── pyproject.toml
└── .gitignore
```

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Author
YOUR NAME
