import re
import stouputils as stp
from stouputils.typing import JsonDict as JsonDict

def validate_config(pmc_config: dict[str, str]) -> str:
    """ Validate PlanetMinecraft configuration

\tArgs:
\t\tpmc_config (dict[str, str]): Configuration for the PlanetMinecraft project
\tReturns:
\t\tstr: Project url on PlanetMinecraft
\t"""
def table_to_bbcode(match: re.Match[str]) -> str:
    """ Convert a markdown table match to BBCode format

\tArgs:
\t\tmatch (re.Match[str]): Regex match object containing a markdown table block

\tReturns:
\t\tstr: BBCode table string
\t"""
def convert_list_block(block_lines: list[str]) -> str:
    """ Convert a block of markdown list lines (with possible nesting) to BBCode

\tArgs:
\t\tblock_lines (list[str]): Lines of the list block (each starting with optional indent + '- ')

\tReturns:
\t\tstr: BBCode list string
\t"""
def convert_markdown_to_bbcode(markdown: str, verbose: bool = True) -> str:
    """ Convert markdown to bbcode for PlanetMinecraft

\tArgs:
\t\tmarkdown (str): Markdown text
\t\tverbose (bool): If True, print the conversion comparison

\tReturns:
\t\tstr: BBcode text

\tExamples:
\t\t>>> markdown_text = '''
\t\t... [![Discord](https://img.shields.io/discord/1216400498488377467?label=Discord&logo=discord)](https://discord.gg/anxzu6rA9F)
\t\t... ![Discord](https://img.shields.io/discord/1216400498488377467?label=Discord&logo=discord)
\t\t... ## Changelog
\t\t...
\t\t... ### Build System
\t\t... - 🚀 Bump version to v1.2.3 ([2111fd2](https://github.com/Stoupy51/LifeSteal/commit/2111fd2f390b80a3aab77a4e7bcbb24b93845e5a))
\t\t...
\t\t...
\t\t...
\t\t... ### Features
\t\t... - ✨ Added new configuration for dropping heart (non pvp) ([cde8749](https://github.com/Stoupy51/LifeSteal/commit/cde8749aa9e447302481f50b9887a0b3a846c7fe))
\t\t...
\t\t... - 🔧 Another feature with multiple newlines before
\t\t...
\t\t... **Full Changelog**: https://github.com/Stoupy51/LifeSteal/compare/v1.2.2...v1.2.3
\t\t... '''
\t\t>>> bbcode = convert_markdown_to_bbcode(markdown_text, verbose=False)
\t\t>>> print(bbcode.strip())
\t\t[url=https://discord.gg/anxzu6rA9F][img]https://img.shields.io/discord/1216400498488377467?label=Discord&logo=discord[/img][/url] [img]https://img.shields.io/discord/1216400498488377467?label=Discord&logo=discord[/img]
\t\t[h2]Changelog[/h2][h4]Build System[/h4][list]
\t\t[*]🚀 Bump version to v1.2.3 ([url=https://github.com/Stoupy51/LifeSteal/commit/2111fd2f390b80a3aab77a4e7bcbb24b93845e5a]2111fd2[/url])[/*]
\t\t[/list][h4]Features[/h4][list]
\t\t[*]✨ Added new configuration for dropping heart (non pvp) ([url=https://github.com/Stoupy51/LifeSteal/commit/cde8749aa9e447302481f50b9887a0b3a846c7fe]cde8749[/url])[/*]
\t\t[*]🔧 Another feature with multiple newlines before[/*]
\t\t[/list]
\t\t[b]Full Changelog[/b]: [url]https://github.com/Stoupy51/LifeSteal/compare/v1.2.2...v1.2.3[/url]
\t\t>>> spoiler_md = '<details>\\n<summary>Preview</summary>\\n![screenshot](https://example.com/img.png)\\n</details>'
\t\t>>> print(convert_markdown_to_bbcode(spoiler_md, verbose=False))
\t\t[spoiler=Preview][img]https://example.com/img.png[/img][/spoiler]
\t\t>>> print(convert_markdown_to_bbcode('Line 1<br>Line 2<br/>Line 3<br />Line 4', verbose=False))
\t\tLine 1
\t\tLine 2
\t\tLine 3
\t\tLine 4
\t\t>>> table_md = '| A | B |\\n|---|---|\\n| 1 | 2 |\\n| 3 | 4 |'
\t\t>>> print(convert_markdown_to_bbcode(table_md, verbose=False))
\t\t[table][tbody][tr][td]A[/td][td]B[/td][/tr][tr][td]1[/td][td]2[/td][/tr][tr][td]3[/td][td]4[/td][/tr][/tbody][/table]
\t\t>>> print(convert_markdown_to_bbcode('```\\ncode block\\n```', verbose=False))
\t\t[code]code block[/code]
\t\t>>> print(convert_markdown_to_bbcode('`inline code`', verbose=False))
\t\t[color=#34495e]inline code[/color]
\t\t>>> print(convert_markdown_to_bbcode('[`Smithed Crafter`](https://wiki.smithed.dev/libraries/crafter/)', verbose=False))
\t\t[url=https://wiki.smithed.dev/libraries/crafter/][color=#34495e]Smithed Crafter[/color][/url]
\t\t>>> badges_md = '[![YouTube](https://img.shields.io/youtube/views/zkcQn23DRaw?style=flat&logo=youtube&logoColor=red&label=YouTube)](https://www.youtube.com/watch?v=zkcQn23DRaw)\\n[![GitHub](https://img.shields.io/github/v/release/Stoupy51/stewbeet?logo=github&label=GitHub)](https://github.com/Stoupy51/stewbeet/releases/latest)'
\t\t>>> print(convert_markdown_to_bbcode(badges_md, verbose=False))
\t\t[url=https://www.youtube.com/watch?v=zkcQn23DRaw][img]https://img.shields.io/youtube/views/zkcQn23DRaw?style=flat&logo=youtube&logoColor=red&label=YouTube[/img][/url] [url=https://github.com/Stoupy51/stewbeet/releases/latest][img]https://img.shields.io/github/v/release/Stoupy51/stewbeet?logo=github&label=GitHub[/img][/url]
\t\t>>> print(convert_markdown_to_bbcode('~~strikethrough~~', verbose=False))
\t\t[s]strikethrough[/s]
\t\t>>> print(convert_markdown_to_bbcode('*italic* and _also italic_', verbose=False))
\t\t[i]italic[/i] and [i]also italic[/i]
\t\t>>> print(convert_markdown_to_bbcode('> blockquote', verbose=False))
\t\t[quote]blockquote[/quote]
\t\t>>> nested_list_md = '- item 1\\n  - sub item 1\\n  - sub item 2\\n- item 2'
\t\t>>> print(convert_markdown_to_bbcode(nested_list_md, verbose=False))
\t\t[list]
\t\t[*]item 1[list]
\t\t[*]sub item 1[/*]
\t\t[*]sub item 2[/*]
\t\t[/list][/*]
\t\t[*]item 2[/*]
\t\t[/list]
\t\t>>> nested_list_urls = '- Actual projects:\\n  - https://github.com/Paralya/Switch\\n  - https://github.com/Stoupy51/LifeSteal'
\t\t>>> print(convert_markdown_to_bbcode(nested_list_urls, verbose=False))
\t\t[list]
\t\t[*]Actual projects:[list]
\t\t[*][url]https://github.com/Paralya/Switch[/url][/*]
\t\t[*][url]https://github.com/Stoupy51/LifeSteal[/url][/*]
\t\t[/list][/*]
\t\t[/list]
\t\t>>> print(convert_markdown_to_bbcode('---', verbose=False))
\t\t[hr]
\t"""
def upload_version(project_url: str, changelog: str) -> None:
    """ Upload new version by opening the project url with the browser

\tArgs:
\t\tproject_url\t\t(str):\tUrl of the project on PlanetMinecraft to open
\t\tchangelog\t\t(str):\tChangelog text
\t"""
@stp.handle_error
def upload_to_pmc(pmc_config: JsonDict, changelog: str = '') -> None:
    """ Upload the project to PlanetMinecraft using the configuration

\tDisclaimer:
\t\tThere is no API for PlanetMinecraft, so everything is done manually.
\tArgs:
\t\tpmc_config\t\t(dict):\t\tConfiguration for the PlanetMinecraft project
\t\tchangelog\t\t(str):\t\tChangelog text for the release
\t"""
