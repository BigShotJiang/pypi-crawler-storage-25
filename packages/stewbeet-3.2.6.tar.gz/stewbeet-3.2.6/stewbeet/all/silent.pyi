from beet import Context as Context
from collections.abc import Generator

def beet_default(ctx: Context) -> Generator[None]: ...
