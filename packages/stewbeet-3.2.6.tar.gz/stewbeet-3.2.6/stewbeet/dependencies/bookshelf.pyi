from stouputils.typing import JsonDict as JsonDict

BOOKSHELF_MODULES: dict[str, JsonDict]
