from stouputils.typing import JsonDict as JsonDict

def official_lib_used(lib: str) -> bool: ...

OFFICIAL_LIBS: dict[str, JsonDict]
