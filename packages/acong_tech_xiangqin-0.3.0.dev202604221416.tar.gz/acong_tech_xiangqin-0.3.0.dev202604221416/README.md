# xiangqin

**相亲平台 CLI —— 付费置顶曝光商业模式。**

给 Claude Code 用户的相亲工具。不做推荐算法、不做聊天、不做匹配评分 —— 只做两件事：

1. 你自己用受限 WHERE 表达式查匹配（查询权在用户 agent）
2. 付费可以让自己在别人 query 结果里**置顶 + 🔥 标记**

## 安装

```bash
# CLI（pypi 包）
pip install acong-tech-xiangqin
# 或
uv tool install acong-tech-xiangqin

# skill（openclaw / ClawHub）
skills install acong-tech/xiangqin
```

装完有 `xq` 命令：

```bash
xq --help
```

## 快速上手

```bash
# 1. 注册（mock 期验证码固定 123456）
xq register 13800001111
xq verify 123456 --request-id <上条返回的 ULID>

# 2. 填资料
xq profile set gender m
xq profile set age 28
xq profile set city hangzhou
xq profile set tags '程序,登山,做饭'
xq profile set bio '想找能一起爬山的人'

# 3. 查匹配
xq query 'gender=f AND city=hangzhou AND age>=25 AND age<=30'

# 4. 买曝光置顶（0.1 mock 期）
xq expose buy --count 100 --mock
xq expose balance   # 查剩余
xq expose history   # 查订单
```

## 心智模型

- **数据层**：sqlite @ epsilon 服务器（`https://…` 生产 URL）
- **排序规则固定公开**：`ORDER BY exposure_remaining>0 DESC, updated_at DESC`
- **每次被 query 命中**：付费用户的 exposure 余额 -1（事务保证）
- **隐私红线**：手机号 HMAC-SHA256，永不落明文
- **定价**：¥0.10 / 次曝光（0.1 mock 期占位）

## 为什么做这个

见 [决策记录](./decisions/2026-04-22-1800-commence-xiangqin.md)：
一、传统交友 app 推荐算法变相骗钱；付费置顶把游戏规则摊在桌面上。
二、xiangqin 是"自治单体实验"，除 vault 外不依赖生态里其它 CLI。

## 反馈

付费意愿反馈是这个项目能不能活下去的核心信号。装了之后告诉我你会不会花钱：

- 微信：待填
- issues：待发 GitHub 后填

## License

MIT
