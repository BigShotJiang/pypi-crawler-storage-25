#!/usr/bin/env bash
# 发 xiangqin skill 到 ClawHub + skills.sh，走 skill-publish-cli。
# 消费方项目只管调；凭证 / registry / repo 管理都是 skill-publish 内部做。
#
# 用法:
#   scripts/publish-skill.sh --version 0.1.0 --changelog "初始发布"
#   scripts/publish-skill.sh --version 0.1.0 --changelog "..." --canary   # 发 xiangqin-canary

set -euo pipefail

VERSION=""
CHANGELOG=""
CANARY=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --version) VERSION="$2"; shift 2 ;;
        --changelog) CHANGELOG="$2"; shift 2 ;;
        --canary) CANARY=1; shift ;;
        *) echo "未知参数: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$VERSION" || -z "$CHANGELOG" ]]; then
    echo "用法: $0 --version <x.y.z> --changelog <文本> [--canary]" >&2
    exit 2
fi

cd "$(dirname "$0")/.."
SKILL_DIR=".claude/skills/xiangqin"

if [[ ! -f "$SKILL_DIR/SKILL.md" ]]; then
    echo "✗ 找不到 $SKILL_DIR/SKILL.md" >&2
    exit 1
fi

ARGS=(publish "$SKILL_DIR" --version "$VERSION" --changelog "$CHANGELOG" --accept-mit-0)
if [[ "$CANARY" -eq 1 ]]; then
    ARGS+=(--canary)
fi

echo "▸ skill-publish-cli ${ARGS[*]}"
skill-publish-cli "${ARGS[@]}"
