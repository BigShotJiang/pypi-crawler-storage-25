# Decisions — xiangqin

倒序。最新在顶。点文件名看详情。

| 日期时间 | 标题 | 摘要 |
|---|---|---|
| 2026-04-22 22:45 | [归档列表 8 → 7：shipyard 保留改 Python](./2026-04-22-2245-keep-shipyard.md) | shipyard 不归档；改 Python 栈 |
| 2026-04-22 22:30 | [M4 改 skill 分发 + 视频宣传](./2026-04-22-2230-m4-switch-to-skill-distribution.md) | 从 1 对 1 访谈改为自助分发路线 |
| 2026-04-22 18:00 | [立项 xiangqin](./2026-04-22-1800-commence-xiangqin.md) | 相亲平台 + 付费置顶 + 自治单体实验；epsilon 部署 |
