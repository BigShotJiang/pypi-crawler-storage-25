---
date: 2026-04-22 22:30
slug: m4-switch-to-skill-distribution
title: M4 从 1 对 1 访谈改为 skill 发布 + 视频宣传
status: active
tags: [m4, distribution, go-to-market]
---

# M4 从 1 对 1 访谈改为 skill 发布 + 视频宣传

## 场景

原 M4 DoD：找 ≥ 1 真实用户访谈 + 观察他跑 happy path + 捕获"我愿意付 X 元"表态。

但老板 2026-04-22 指出：访谈 1 对 1 扩展性差 + xiangqin 的用户本来就有 Claude Code agent，付费引导可以内嵌在 skill 的提示里（agent 在合适对话场景自然触发）。

## 选项

- **A) 继续 1 对 1 访谈**（原方案，保守稳妥）
- B) **改走 skill 发布 + 视频宣传 + 靠 agent 自助提示引导付费**（采纳）
- C) 两个都做（先访谈 1 人打磨话术再分发）

## 选 B，因为

- xiangqin 目标用户 = Claude Code 重度用户，他们有 agent；skill 里写好"当用户说'想被看到'时提示花 X 元买曝光"，agent 会自然引导付费 —— 这是 Model B 自助哲学的标配用法
- 视频 + skill 分发比面对面访谈扩展性好 10x：投入一次宣传可触达 100+ 人
- A3 "先卖后做"的本质是**验证付费意愿**，不是"必须面对面才算数"。1 条真实的 skill 用户说"愿意付"同样满足
- matchmaker 当初的失败就在于没走到变现路径；xiangqin 必须早早把"买曝光"放到用户能摸到的位置

## 代价 / 放弃了

- 慢反馈：视频宣传一次要 1-2 周才有有效反馈量
- 采样偏差：skill 用户 ≠ 大众相亲用户，结论可能泡沫
- 需要额外工作：拍视频 + 写宣传文案 + 选发布渠道
- 若完全没付费意向，归因更难（是产品问题？定价问题？分发问题？）—— 比访谈失败后更难分析

## 记录源

老板 2026-04-22 22:30 对话原话："我直接发布 skill + 我拍视频宣传，收费的事情 他有 agent 我们的 skill 给提示，就行"

## 影响的其它文档

- `plan/M4-sell-first-user.md`：DoD 和任务清单已改为 skill 发布路线
- `.claude/skills/xiangqin/SKILL.md`：待加"付费置顶引导话术 + 定价"段（M4 任务清单第 1 项）
- 后续若分发结果完全空，回到 A 方案 1 对 1 访谈做对照（作为 fallback 选项）
