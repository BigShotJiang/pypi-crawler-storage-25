# xiangqin — 产出

**相亲平台**。付费置顶曝光商业模式。人人免费进池、免费录资料、免费 query，唯一收费点是"买曝光次数"—— 你想让自己在别人 query 时出现得更显眼，按曝光次数付费。
⚠️ 不做推荐算法 / 不做聊天 / 不做社交 / 不做 UGC 社区。匹配智能 100% 在用户 agent 端（查询权给用户自己）。

**自治单体实验**：除 vault + shipyard 外不依赖生态里其它项目 CLI。0.1 跑通后若模式成立，将归档 matchmaker / cashier / backup / membership / host / oss / hitch 7 项目。

---

## 📦 产出形态

| 组件 | 场景 | 使用者 |
|---|---|---|
| 服务端（FastAPI + sqlite） | 用户 / profile / query / 曝光订单数据层 + API | epsilon (112.124.27.213, 2C4G) |
| `xq` CLI | 注册 / profile / query / 买曝光 | 装 skill 的 Claude Code 用户 |
| `xiangqin` skill | 对话式引导填资料 + query + 买曝光 | 用户的 Claude |

---

## 🖥️ 产品产出（对外 SaaS）

- **访问入口**：http://112.124.27.213（0.1 期，后续绑域名 + TLS）
- **注册方式**：手机号 + 短信验证码（0.1 期 mock code 固定 123456；0.2 对接阿里云短信服务）
- **字段**：gender (f/m/nb) / age (18-99) / city / tags / bio
- **查询接口**：受限 WHERE DSL（参考 matchmaker query-dsl，但加 `ORDER BY exposure_weight DESC`）
- **曝光计费**：买 N 次 → 每被 query 命中一次扣 1，扣到 0 回到普通池
- **隐私红线**：手机号不出 stdout / stderr / 本地 / vault，走 ULID request_id
- **状态**：骨架期，服务端未部署

---

## 🔧 CLI 产出（`xq`）

```bash
# 注册 + 登录
xq register <phone>                       # 发验证码；返回 request_id
xq verify <code> --request-id <ULID>      # → session_token 写 vault
xq logout

# Profile
xq profile set gender f|m|nb
xq profile set age <18-99>
xq profile set city <≤30 字>
xq profile set tags <a,b,c>
xq profile set bio <≤500 字>
xq profile show                           # 手机号掩码

# 查匹配
xq query '<where-expr>' [--limit N] [--json]
                                          # 结果默认按 exposure_weight DESC 排
                                          # 付费用户带 🔥 标记

# 买曝光（0.1 mock）
xq expose buy --count <N> [--mock]        # 0.1 期强制 --mock
xq expose balance                         # 查剩余曝光次数
xq expose history                         # 查购买记录

# 删号
xq delete --confirm                       # 软删 → 7 天内物理清理

# 健康检查
xq health                                 # GET /health
```

**退出码**：0 成功 / 非 0 错误（`rate_limited` / `invalid_phone` / `invalid_value` / `unauthenticated` / `dsl_*` / `network_error` / `insufficient_exposure`）。

---

## 📊 快照（2026-04-22）

- 状态：骨架期（服务端未部署）
- 已注册用户：0
- 已支付金额：¥0
- 已购买曝光：0 次
- 团队编制：**0 agent**（零成员，team-lead 自推；需要时按 `team` skill § mentor 四步招）
- ECS：epsilon (2C4G, 到期 2026-07-13)
- DB：sqlite（还没建）

---

## 🔌 消费方接入

**TRIGGER when**：用户说"相亲"、"找对象"、"xiangqin"、"买曝光"、"买置顶"、"让更多人看到我"、"付费相亲"。

**DO NOT TRIGGER when**：
- 用户要聊天 / 推荐 / 匹配算法（本项目不做，查询权交给用户 agent）
- 用户想的是 matchmaker（已进入废弃期，引导用 xiangqin）
- 服务端不可达时（先查 `curl 112.124.27.213/health`）

**申请接入**：本项目是终端产品，用户装 skill + 跑 `xq register` 即可；跨项目集成**不走 mailbox**（本项目拒收跨项目邮件，自治实验期）。

**不变量 / 承诺**：
- 服务端零推荐 / 零排序算法，只按 `exposure_weight DESC` 排（付费决定可见性，公开规则）
- 查询结果只返回白名单字段（手机号永不出）
- WHERE 不能为空；LIMIT 默认 50 最大 100
- 曝光余额不足的付费用户降级到普通池，不退款
- 删号 7 天物理清理窗口，期间可撤销
- **vault 是唯一对外 CLI 依赖**

---

## 🚀 安装

**客户端**：0.1 期未发布；未来 `skills install xiangqin` + `pip install xiangqin-cli`。

**服务端**（epsilon 装机，只此一次）：
```bash
ssh root@112.124.27.213
curl -LsSf https://astral.sh/uv/install.sh | sh
# clone + uv sync + systemctl enable + systemctl start
```

详情见 `scripts/provision.sh`（待写）。

---

## 🧭 详情入口

| 想知道什么 | 去哪里 |
|---|---|
| 团队目标 + 指标 | [`objectives/INDEX.md`](./objectives/INDEX.md) |
| 当前里程碑 + 下一步 | [`plan/INDEX.md`](./plan/INDEX.md) |
| 历史决策 | [`decisions/INDEX.md`](./decisions/INDEX.md) |
| 团队怎么运作 | [`CLAUDE.md`](./CLAUDE.md) |
| skill 完整用法 | [`.claude/skills/xiangqin/SKILL.md`](./.claude/skills/xiangqin/SKILL.md) |
