# xiangqin — 项目指令

**相亲平台（自治单体实验）**。付费置顶商业模式：人人免费进池录资料，付费获得"被 query 到时置顶/高亮"的曝光权。重写替代 matchmaker。部署在 epsilon (112.124.27.213, 2C4G)。

## 🚀 Bootstrap（本项目会话开工协议）

1. 全局 Bootstrap 已在 `~/.claude/CLAUDE.md` 约定
2. 本项目必读：`objectives/INDEX.md` 北极星段 + `plan/INDEX.md` 当前阶段 + 最近 3 条 `decisions/`
3. 本项目关键 skill：`.claude/skills/xiangqin/SKILL.md`（CLI 用法 + 消费方接入）
4. 当前状态：M1 骨架 + epsilon 初始化中（2026-04-22 立项）

## 🧪 自治单体实验

**刻意**不依赖生态里其它项目的 CLI（host / oss / backup / cashier / membership / hitch / matchmaker 都不用），自己集成。保险箱（vault）保留 —— 凭证 / 资源台账还走它。shipyard 也保留（老板 2026-04-22 判定：改栈保存价值，不归档）。

跑通 0.1 闭环后：若自治模式可行，上述 8 个项目归档 `.archived/`；若不可行，回收 xiangqin 到标准生态。见 `decisions/2026-04-22-*-commence-xiangqin.md`。

## 👥 团队成员

**目前零成员**——只有 team-lead（主会话）。

遵循**渐进式招聘**原则（`team` skill § lifecycle）：不预设岗位；具体任务担责才招；走完 `team` skill § mentor 四步出师；职责消失 `team` skill § lifecycle 归档。

## 📏 团队原则

遵循 `team` skill § principles 的 11 条（A1-A11），尤其：
- **A3 先卖后做**：付费置顶的商业假设要先找第一个真愿意付钱的用户验证
- **A10 YAGNI**：mock 支付 / sqlite 不上 postgres 集群 / 不提前做推荐算法
- **A11 Unix 哲学**：CLI 第一公民；xq 一个命令敲完注册 + 查 + 买曝光

## 📡 召回方式

遵循 `team` skill § lifecycle（member-spawn 段）：默认 `Agent` tool spawn subagent，不用 TeamCreate 常驻。

## 📤 对外沟通规范

- 对老板：`team` skill § to-boss（给选项必写双面 / 禁用"拍"字 / 选择题走 AskUserQuestion）
- 团内 agent：`team` skill § comms（handoff 段）
- 跨项目：**本项目拒收跨项目邮件**（自治单体实验期纯内部运作）

## 📁 老板视图文档（team-lead 维护，3 件套）

| 目录 | 内容 | skill |
|---|---|---|
| [`objectives/`](./objectives/INDEX.md) | 北极星 + 年度 O + KR + 指标快照 + 风险 | `team` skill § objectives |
| [`plan/`](./plan/INDEX.md) | 对齐目标 + 当前里程碑 + 下一步 + backlog | `team` skill § plan |
| [`decisions/`](./decisions/INDEX.md) | ADR 模式（每条独立文件，倒序 INDEX） | `team` skill § decisions |

## 📚 知识库（wiki/）

4 层：[raw](./wiki/raw/) → [shares](./wiki/shares/) → [insights](./wiki/insights/) → [playbooks](./wiki/playbooks/)。遵循 `team` skill § docs（wiki 段）。

## 🔧 全局工具

| 命令 | 用途 |
|---|---|
| `xq` | 本项目产出（客户端 CLI，装完后 `which xq` 可用） |
| `vault` | 读凭证 / 资源台账（**唯一**对外 CLI 依赖） |

## 🗝️ 关键路径

- `src/xiangqin/app.py` — FastAPI entrypoint（注册 / query / exposure 接口）
- `src/xiangqin/db.py` — sqlite + WAL schema
- `src/xiangqin/cli.py` — 客户端 xq CLI（Click）
- `systemd/xiangqin.service` — epsilon 上的 systemd unit
- `scripts/deploy.sh` — scp + ssh restart 脚本
- `scripts/backup.sh` — sqlite → OSS rsync
- `data/` — 本地 sqlite 文件（生产在 epsilon 的 /var/lib/xiangqin/）

## 📊 当前状态

**M1 骨架 + epsilon 初始化**（2026-04-22 立项）。详见 [plan/M1-scaffold.md](./plan/M1-scaffold.md)。
