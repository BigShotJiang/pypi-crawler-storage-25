---
id: O2
slug: autonomy-validate
status: active
deadline: 2026-06-30
---

# O2 — 自治单体假设验证

## 目标描述

验证"业务团队不依赖生态 CLI 也能自洽运转"的工程假设。0.1 运行 30 天后复盘：xiangqin 是否**真**自足？哪些地方偷偷在用其它项目的能力？哪些地方如果借 CLI 会更省事但放弃了？

若自治假设成立：归档 `.archived/` 的 7 个项目（membership / cashier / backup / matchmaker / host / oss / hitch）。若不成立：xiangqin 回收进生态，保留这 7 个。**shipyard** 不在归档列表（老板 2026-04-22 判定保留，改 Python 栈）。

## KR（关键结果）

- [ ] **KR2.1**：部署 / 备份 / 监控 / 支付 / 凭证 5 类能力全部本项目内完成，除 vault 外不 exec 其它项目 CLI（审计方式：项目内 grep + 团队 dash 显示 `.team-dependencies.yaml` 为空）
- [ ] **KR2.2**：30 天稳定运行无生产事故（P1 = 0）
- [ ] **KR2.3**：写一份**实验报告** `reports/phase/2026-0X-autonomy-review.md`：自治 vs 生态各项成本 / 复用度 / 故障率对比 —— 让老板决定下一步
- [ ] **KR2.4**：基于报告，若决定归档 7 项目，产生 `decisions/*-archive-7-projects.md` 和执行记录

## 为什么是这个目标

承接北极星第二句。A10 YAGNI + 单体派工程假设：如果每个业务团队都能自治，生态里那些"基础设施团队"未必必要。用 xiangqin 做对照实验 —— 如果它能活得更好，证明生态是伪需求；如果它活不下去，证明生态有存在价值。
