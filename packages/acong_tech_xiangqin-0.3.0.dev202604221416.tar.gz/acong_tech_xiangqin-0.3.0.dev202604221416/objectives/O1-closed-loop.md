---
id: O1
slug: closed-loop
status: active
deadline: 2026-05-15
---

# O1 — 0.1 闭环跑通

## 目标描述

在 epsilon 上部署完整的注册 → profile → query → mock 付费置顶闭环，验证"付费置顶"模式的产品形态。**不含**真实支付（走 mock 标志位），**不含**推荐算法（纯 query + 付费权重）。

## KR（关键结果）

- [ ] **KR1.1**：epsilon 上 FastAPI 服务跑起来，systemd 自启，`curl /health` 返回 `{status: ok}`。deadline: 2026-04-25
- [ ] **KR1.2**：注册 + 填 profile + query + mock 付费置顶全链路，从 `xq` CLI 可演示完整用户旅程。deadline: 2026-05-05
- [ ] **KR1.3**：sqlite + WAL 数据库 schema 落地（users / profiles / exposure_orders 3 张核心表），单测覆盖核心 model
- [ ] **KR1.4**：sqlite → aliyun OSS 每日备份脚本跑通（cron + aliyun cli 直接 rsync，不走 backup-cli）。deadline: 2026-05-10
- [ ] **KR1.5**：第一个真实愿付费用户意向捕获（A3 先卖后做）—— 不一定真收钱，但要有真人说"如果有这个功能我会付 X 元"。deadline: 2026-05-15

## 为什么是这个目标

对齐北极星"付费置顶"核心假设：先跑通最小产品闭环，让一个真实用户走完旅程，验证体验可用 + 商业模型成立。闭环成立才进 O2（归档 8 项目）。
