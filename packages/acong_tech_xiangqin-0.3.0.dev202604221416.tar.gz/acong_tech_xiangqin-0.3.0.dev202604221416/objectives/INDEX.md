# Objectives — xiangqin

最后更新：2026-04-22

## 🔭 北极星（2-5 年愿景）

**"付费置顶"的相亲平台**——用户免费进池、免费录资料、免费 query，唯一收费点是**付费曝光**：你想让自己在别人 query 时出现得更显眼，按曝光次数付钱。

不做推荐算法 / 不做聊天 / 不做社交 / 不做 UGC 社区。用户 agent 自行 query + 自行决定是否联系。

**自治单体**——不依赖生态里其它项目 CLI（host / oss / backup / cashier / membership / hitch / matchmaker 都不用），只保留 vault（凭证 / 资源台账）+ shipyard（发布工坊，2026-04-22 保留）。验证"单体 > 微服务拆分"的工程假设。

## 📋 年度目标

- [O1-closed-loop](./O1-closed-loop.md)：0.1 闭环跑通（注册 + profile + query + mock 付费置顶） — 🆕 **doing**
- [O2-autonomy-validate](./O2-autonomy-validate.md)：自治单体假设验证 — 🆕 **new**

## 📈 指标快照（当前数字）

**产品**：
- 注册用户：0（骨架期）
- 活跃 query：0
- 付费曝光订单：0（mock 期）
- 已支付金额：¥0

**工程**：
- 已部署服务：0（epsilon 尚未 provision）
- 单测数：0
- 整测数：0

**资源**：
- ECS：epsilon (112.124.27.213, 2C4G, 到期 2026-07-13)
- OSS 备份桶：待申请（O1.KR3）
- 凭证：全部走 vault（`aliyun/main` 等，见 `.vault-mapping.yaml`）

## ⚠️ 风险与假设

- **R-1（核心假设）**：真有人愿意为"被 query 时置顶"付钱。A3 原则要求先卖后做 —— 0.1 闭环前要找到第一个真实意向付费用户，否则 pivot
- **R-2（自治假设）**：单体能独立完成部署 / 备份 / 支付 / 监控。若发现某块必须借其它 CLI（例如备份真得 oss-cli 才行），要承认回到生态。O2 的 KR 会测这个
- **R-3（架构假设）**：sqlite + WAL 撑得住 10k 用户 + 1 QPS query。压测前这是假设
- **R-4（法律 / 合规）**：交友平台涉及 PII、有地区备案要求。骨架期不面向公网真实用户，0.1 → 0.2 之间补备案 / 隐私政策
