---
name: publish
owner: team-lead
version: 1
last-updated: 2026-04-22
---

# SOP: 发布新版本到 PyPI + ClawHub

每次切版本号后，都按这个走。分 canary（金丝雀）和 live（正式）两档。

## 前置

- [ ] 本地 `uv run pytest test/ -q` 全绿
- [ ] `pyproject.toml` 版本号和 `src/xiangqin/__init__.py` 的 `__version__` 对齐
- [ ] `CHANGELOG.md` 新版本段写好
- [ ] vault 里 `pypi.api_tokens[name=acong-tech-publish]` 可用（`vault get pypi api_tokens --unmask --json | ...`）

## canary（每次开发完都应走这一步）

```bash
cd /Users/yarnb/xiangqin

# 1. PyPI canary（版本后缀 .devYYYYMMDDHHMM）
bash scripts/publish-pypi.sh --canary

# 2. ClawHub canary（slug 后缀 -canary）
bash scripts/publish-skill.sh --version 0.2.0 --changelog "0.2.0 canary" --canary

# 3. 干净环境装测
python3 -m venv /tmp/xq-verify
/tmp/xq-verify/bin/pip install --pre acong-tech-xiangqin
rm -rf /tmp/xq-clean && XIANGQIN_CONFIG_DIR=/tmp/xq-clean /tmp/xq-verify/bin/xq register 138****xxxx
/tmp/xq-verify/bin/xq health
# 全绿才进下一步
```

## live（正式发，谨慎）

```bash
# PyPI 正式（直接走 pyproject.toml 里的版本号）
bash scripts/publish-pypi.sh --live

# ClawHub 正式（slug 不带 -canary）
bash scripts/publish-skill.sh --version 0.2.0 --changelog "0.2.0 正式发布：付费置顶 + SMS/Payment provider 抽象"
```

## 验收

- [ ] `curl -s https://pypi.org/pypi/acong-tech-xiangqin/json | python3 -c 'import json,sys; d=json.load(sys.stdin); print(sorted(d["releases"].keys())[-3:])'` 看到新版本
- [ ] https://clawhub.ai/skills/xiangqin 页面版本号对
- [ ] skill-publish-cli status xiangqin 四栏全绿

## 版本 bump 规则

SemVer（https://semver.org/）：
- **0.x → 1.0.0**：生产就绪 + 对外 API 稳定承诺
- **patch**：bugfix，用户透明（0.2.0 → 0.2.1）
- **minor**：新功能，用户可选用（0.2.1 → 0.3.0）
- **major**：破坏性（0.3.0 → 1.0.0 / 1.0.0 → 2.0.0）

0.x 期间 minor bump 也允许破坏性，前提是在 CHANGELOG.md `### Changed (BREAKING)` 标清迁移。

## 回滚

- PyPI **不能删版本**（dev 版可等 180 天自然过期）。用 `pip install acong-tech-xiangqin==<旧版本>` 降级即可
- ClawHub 可 `skill-publish-cli delete xiangqin --yes` 软删（保留历史 + GitHub 仓库）
- GitHub repo `acong-tech/skill-xiangqin`：不建议删（破坏索引），用 deprecate 标签

## 坑

- `uv tool install --prerelease allow` 刚发完立即装有 simple index cache 问题，用 `pip install --pre` 替代
- httpx `[socks]` extra 忘了会在有 SOCKS 代理的环境崩（pyproject 要写 `httpx[socks]>=0.27,<1.0`）
- version 改了但 `__init__.py.__version__` 忘了跟进：`/health` 显示旧版本，用户迷惑
