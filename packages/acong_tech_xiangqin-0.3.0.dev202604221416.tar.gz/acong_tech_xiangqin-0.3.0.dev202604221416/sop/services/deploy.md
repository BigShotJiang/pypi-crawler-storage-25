---
name: deploy
owner: team-lead
version: 1
last-updated: 2026-04-22
---

# SOP: 发布新代码到 epsilon 生产

对谁承诺：xiangqin 团队内部 + 老板。每次改 `src/xiangqin/` 或 `scripts/` 后发布都按这个走。

## 前置条件

- [ ] 本地 `uv run pytest test/ -q` 全绿
- [ ] epsilon `curl http://112.124.27.213/health` 当前有响应（证明基线可用）
- [ ] 如果改了 pyproject.toml 依赖：`uv lock` 已执行
- [ ] 如果改了 pyproject.toml 版本号：`src/xiangqin/__init__.py` 的 `__version__` 也改了（两处对齐）

## 发布步骤

```bash
cd /Users/yarnb/xiangqin
bash scripts/deploy.sh
```

`deploy.sh` 做 4 步（见脚本）：
1. rsync 代码到 `root@epsilon:/opt/xiangqin/`（排除 .venv / data / .git / *.db*）
2. ssh root 跑 `uv sync`（用 UV_PYTHON_INSTALL_DIR=/opt/uv-python 共享路径）
3. chown -R xiangqin:xiangqin 让 app user 能读
4. 复制 `systemd/xiangqin.service` → `/etc/systemd/system/` + daemon-reload
5. `systemctl restart xiangqin` + 打印状态
6. 本机 `curl http://112.124.27.213/health` smoke test

## 验收

- [ ] 最后一行 `curl` 输出 `{"status":"ok","version":"<新版本>"}`
- [ ] `xq health` 本地（装好的 CLI 版本）也能过

## 失败回滚

```bash
ssh root@112.124.27.213 'cd /opt/xiangqin && git log --oneline -5'
# 不幸的是 /opt/xiangqin 不是 git 仓库，是 rsync 镜像。真回滚 = 本地 git checkout 旧 commit 再 deploy.sh

# 紧急：停服
ssh root@112.124.27.213 'systemctl stop xiangqin'
# 如数据损坏：按 sop/services/restore.md 从 OSS 备份恢复
```

## 配置变更（环境变量）

- `XIANGQIN_SMS_PROVIDER=mock|aliyun` —— 短信 provider
- `XIANGQIN_PAYMENT_PROVIDER=mock|wechat|alipay` —— 支付 provider
- `XIANGQIN_PHONE_SALT=<随机盐>` —— 手机号 hash 盐（⚠️ 不要改！改了等于让所有老手机号匹配失败）

修 systemd unit 的 `Environment=` 行后：
```bash
scp systemd/xiangqin.service root@112.124.27.213:/etc/systemd/system/
ssh root@112.124.27.213 'systemctl daemon-reload && systemctl restart xiangqin'
```

## 历史事故

- （初版，待事故充填）
