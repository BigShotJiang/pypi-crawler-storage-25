# xiangqin 操作手册

老板 / 未来的自己 / 未来的 ops agent 用。每一段都是遇到时直接抄。

---

## 1. 查状态

### 服务活不活

```bash
curl -s http://112.124.27.213/health
# 期望 {"status":"ok","version":"x.y.z"}
```

### systemd 详情

```bash
ssh root@112.124.27.213 'systemctl status --no-pager xiangqin'
# Active: active (running) 即正常
```

### 看日志

```bash
ssh root@112.124.27.213 'journalctl -u xiangqin --no-pager -n 50'
# 或者跟日志：
ssh root@112.124.27.213 'journalctl -u xiangqin -f'
```

### 备份日志

```bash
ssh root@112.124.27.213 'tail -50 /var/log/xiangqin-backup.log'
```

---

## 2. 重启 / 停 / 启

```bash
ssh root@112.124.27.213 'systemctl restart xiangqin'
ssh root@112.124.27.213 'systemctl stop xiangqin'
ssh root@112.124.27.213 'systemctl start xiangqin'
```

---

## 3. 查数据

### 数据库是 sqlite

```bash
ssh root@112.124.27.213
# xiangqin 用户有读权限，root 当然可以
sqlite3 /opt/xiangqin/data/xiangqin.db

# 常用查询:
.tables
SELECT COUNT(*) FROM users;
SELECT COUNT(*) FROM profiles WHERE city='hangzhou';
SELECT * FROM exposure_orders ORDER BY created_at DESC LIMIT 10;
SELECT user_id, remaining, total_purchased FROM exposure_usage ORDER BY remaining DESC LIMIT 10;
```

### 数据库大小 / 桶用量

```bash
# 本地 DB
ssh root@112.124.27.213 'ls -lh /opt/xiangqin/data/xiangqin.db*'

# OSS 备份用量
aliyun --profile xiangqin oss ls oss://agentaily-backup-xiangqin-prod/daily/ \
    -e oss-cn-hangzhou.aliyuncs.com \
    | awk '{sum+=$1} END {printf "%.2f KB\n", sum/1024}'
```

---

## 4. 配置变更

### 改 provider（短信 / 支付）

```bash
ssh root@112.124.27.213 'systemctl edit xiangqin'
```

弹出编辑器，加 / 改：
```ini
[Service]
Environment="XIANGQIN_SMS_PROVIDER=aliyun"
Environment="XIANGQIN_PAYMENT_PROVIDER=wechat"
```

保存退出后：
```bash
ssh root@112.124.27.213 'systemctl daemon-reload && systemctl restart xiangqin'
```

### 改手机号盐（⚠️ 危险）

改 `XIANGQIN_PHONE_SALT` 等于让**所有已注册老用户失联**（hash 不匹配）。不要改。

如果非改不可（例：盐泄漏），只能：
1. 宣布"所有用户重新注册"
2. drop users/profiles/sessions/auth_requests 表 + 重新 init_db
3. 新盐生效

---

## 5. 常见错误诊断

### "502 Bad Gateway"

nginx 工作但 uvicorn 挂了。查 `systemctl status xiangqin`。

最常见原因：
- Python 依赖错（最近 deploy 了新版本没 `uv sync`）
- 环境变量配错（例：`XIANGQIN_SMS_PROVIDER=aliyun` 但 vault 里 aliyun-sms 不存在，启动时 init 抛错）

查 `journalctl -u xiangqin --no-pager -n 30` 看 Python traceback。

### "health check failed: timed out"

epsilon 不通 / 80 端口被阿里云安全组封 / nginx 没起。

```bash
# 检查 SG
aliyun ecs DescribeSecurityGroupAttribute --SecurityGroupId sg-bp1b0ke3ei1y5n3k2qs1 --Direction ingress | grep 80
# 应该有 80/80 0.0.0.0/0 Accept

# 检查 nginx
ssh root@112.124.27.213 'systemctl status --no-pager nginx'
```

### "unauthenticated" / session 过期

session 30 天自然失效。用户重新 `xq register` + `xq verify` 即可。

### 验证码发不出（aliyun 生产）

```bash
ssh root@112.124.27.213 'journalctl -u xiangqin -n 20 | grep sms'
```

看是签名 / 模板 / 频率限制 / AK 权限的哪个问题。最常见：短信模板"审核中"还没通过。

---

## 6. 手动发一条测试验证码（绕开 xq CLI）

```bash
ssh root@112.124.27.213
curl -s -X POST http://127.0.0.1:8000/auth/register \
    -H 'Content-Type: application/json' \
    -d '{"phone":"13800001111"}'
# 应该返回 {"request_id":"01K...","masked_phone":"138****1111","expires_in_s":60,"mock_code_hint":"..."}
```

---

## 7. 回退到上个版本

本项目 prod 是 rsync 镜像，没版本历史。回退 = 本地 `git log` + `git checkout <旧 commit>` + `bash scripts/deploy.sh`。

## 8. 数据备份 / 恢复

见 [sop/services/restore.md](../sop/services/restore.md)。

## 9. 发新版本

见 [sop/services/publish.md](../sop/services/publish.md)。

## 10. 外部账号 onboarding

- 短信：[sop/operations/sms-onboarding.md](../sop/operations/sms-onboarding.md)
- 支付：[sop/operations/payment-onboarding.md](../sop/operations/payment-onboarding.md)
