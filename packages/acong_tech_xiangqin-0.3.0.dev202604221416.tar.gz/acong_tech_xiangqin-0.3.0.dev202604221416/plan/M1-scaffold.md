---
id: M1
name: 骨架 + epsilon 初始化
slug: scaffold
status: done
deadline: 2026-04-25
completed: 2026-04-22
dod: 本地 `uv run xq --help` 能跑；epsilon 上 `curl http://112.124.27.213/health` 返回 `{status: ok}`
---

# M1 — 骨架 + epsilon 初始化 ✅

## 通关 DoD（2026-04-22 全部达成）

- ✅ 本地：`uv run xq --help` 跑通
- ✅ epsilon：systemd unit `xiangqin.service` active + enabled
- ✅ nginx reverse proxy 80 → uvicorn 8000
- ✅ 全链路端到端：`uv run xq health` → `{"status":"ok","version":"0.1.0"}`

## 任务清单

- [x] 目录骨架（new-team skill 产出）
- [x] 老板视图 3 件套（objectives / plan / decisions）
- [x] DELIVERABLES.md + CHANGELOG.md
- [x] vault epsilon tenant=xiangqin 标注
- [x] pyproject.toml + uv 环境
- [x] `src/xiangqin/app.py` FastAPI 最小（/health 端点）
- [x] `src/xiangqin/cli.py` Click 最小（--help + `xq health`）
- [x] `systemd/xiangqin.service` unit 文件
- [x] `scripts/provision.sh` epsilon 一次性装机脚本（uv 自管 Python + nginx + aliyun cli）
- [x] `scripts/deploy.sh` 增量发布脚本（rsync + uv sync + systemctl restart）
- [x] 本机 git init + 首次 commit
- [x] SKILL.md + .vault-mapping.yaml + jarvis.code-workspace 添加
- [x] 真的 ssh 上去跑一次，`curl` 出 health:ok

## 实装时的小发现

- Ubuntu 22.04 没系统 python3.12，改走 **uv 自管 Python**（--python-preference managed）
- epsilon hostname 改为 `xiangqin`（原 `jarvis-openclaw`）
- 阿里云安全组新加 **80/80 0.0.0.0/0** Accept 规则（原只有 22/443/5432 等）
- **遗留**：SG 里还有老 openclaw 的 7000 / 9876 / 22000-22999 规则，建议 M2 期间清理
- 0.1 期服务跑在 root 用户下（简化），M2 前切 xiangqin app user

## 服务的目标

[O1-closed-loop](../objectives/O1-closed-loop.md) KR1.1
