---
id: M3
name: sqlite OSS 备份演练
slug: backup-smoke
status: done
deadline: 2026-05-10
completed: 2026-04-22
dod: 每日 02:00 cron → aliyun cli 上传 `xiangqin-YYYYMMDD.db.gz` 到 OSS；演练恢复一次（下载 → replace → systemctl restart）
---

# M3 — sqlite OSS 备份演练 ✅

## 通关 DoD（2026-04-22 全部达成）

- ✅ OSS 桶 `agentaily-backup-xiangqin-prod` 创建完毕（aliyun oss mb，不走 oss-cli）
- ✅ 首次备份上传成功，桶内有 `daily/xiangqin-20260422.db.gz`（2529B）
- ✅ `/etc/cron.d/xiangqin-backup` 装好，cron.service active，明日 02:00 自动跑
- ✅ 恢复演练：下载 → 解压 → sqlite integrity_check=ok → users=3 / orders=1 对得上
- 每日 cron 上传成功 ≥ 3 次（等明后天 cron 跑满 3 次自动 tick）

## 任务清单

- [x] `aliyun oss mb oss://agentaily-backup-xiangqin-prod`
- [x] vault resource 台账入库（`aliyun/oss/agentaily-backup-xiangqin-prod`）+ credential_ref=aliyun/main
- [x] .vault-mapping.yaml 去掉 optional 标志
- [x] aliyun cli 在 epsilon 上配 `xiangqin` profile（AK/SK 从 vault aliyun/main 取）
- [x] `scripts/backup.sh` 首次运行成功（sqlite .backup + gzip + oss cp）
- [x] `scripts/restore.sh` 写好 + 上传到 epsilon
- [x] 装 `/etc/cron.d/xiangqin-backup` 02:00 daily
- [x] 恢复演练：非 in-place 下载到 `/opt/xiangqin/data/restore-TS/`，完整性校验 ok

## 实装发现

- `systemctl reload cron` 不支持（Ubuntu 22.04），但 `/etc/cron.d/*` 自动生效，不需 reload
- 备份体积 2.5KB（3 用户 + 1 订单），未来 10k 用户估 ~30-50MB，OSS 存储成本可忽略
- `aliyun oss cp` 加 `--force` 可覆盖本地同名文件（restore 场景用到）

## 服务的目标

[O1-closed-loop](../objectives/O1-closed-loop.md) KR1.4

## 服务的目标

[O1-closed-loop](../objectives/O1-closed-loop.md) KR1.4
