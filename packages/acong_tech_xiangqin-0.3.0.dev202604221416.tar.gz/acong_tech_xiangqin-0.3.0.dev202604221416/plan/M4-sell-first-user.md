---
id: M4
name: 第一批付费意向用户
slug: sell-first-user
status: todo
deadline: 2026-05-15
dod: skill 发布到 openclaw hub + 宣传视频上线 + 至少 1 条"我愿意付 X 元"的真实反馈（来自任一渠道）
---

# M4 — 第一批付费意向用户（分发式验证）

## 方向（2026-04-22 老板调整）

从"找 1 个真人面对面访谈"改成"**发布 skill + 拍视频宣传 + 靠用户的 agent 自助触发付费**"。

理由：xiangqin 是给有 Claude Code 的用户用的 —— 他们本来就有 agent。装完 skill 后 agent 在合适场景（例如"想让女神看到我"）会提示"可以花 X 元买曝光"，这就是自然变现路径。比 1 对 1 访谈扩展性强得多，也更符合 Model B 自助哲学。

对应 decision：`decisions/2026-04-22-XXXX-m4-switch-to-skill-distribution.md`

## 通关 DoD

1. **skill 发布**：`xiangqin` skill 发布到 openclaw 一个可装渠道（canary 或正式）
2. **宣传视频**：≥ 1 条公开视频说清楚"这是什么 / 怎么用 / 为什么付费置顶"
3. **反馈捕获**：装了 skill 的用户里，≥ 1 个人**明确表达付费意向**（可以是：
   - 真在 mock 里买过曝光 + 在评论/消息里说"如果真能付我会付"
   - 或私信/评论直接说"愿意花 X 元 / 月买置顶"
4. **反馈记录**：写一份 `wiki/insights/first-paying-intent-YYYYMMDD.md`（≥ 500 字）

## 任务清单

### 发布链路准备

- [x] pyproject.toml 改名 `acong-tech-xiangqin`（对齐 shipyard 命名空间；CLI 二进制仍叫 `xq`）
- [x] README.md 写给外部用户（装 / 上手 / 心智模型）
- [x] `scripts/publish-pypi.sh`：dry-run / --live / --canary 三档，token 从 vault 取
- [x] `scripts/publish-skill.sh`：包装 `skill-publish-cli publish .claude/skills/xiangqin --version ... --accept-mit-0`
- [x] pypi dry-run 构建通过（`acong_tech_xiangqin-0.1.0-py3-none-any.whl`）
- [ ] 首发到 pypi canary：`bash scripts/publish-pypi.sh --canary` → 版本号 `0.1.0.dev<ts>`
- [ ] 首发到 ClawHub canary：`bash scripts/publish-skill.sh --version 0.1.0 --changelog '首发' --canary`
- [ ] canary 金丝雀真跑：`pip install acong-tech-xiangqin==0.1.0.dev...` 装到干净机器试

### 内容准备

- [x] 视频台词 `scenarios/promo-video-script.md`（2:30-3:00，8 个分镜）
- [ ] 老板录屏（按台词 + checklist 走）
- [ ] 视频后期 / 字幕 / 二维码
- [ ] SKILL.md 里加"付费置顶定价 + agent 引导话术"段（装 skill 的用户 agent 看到这段才知道怎么引导付费）

### 0.1 定价（mock 期占位，可调）

- [ ] ¥0.10 / 曝光（代码里是 `PRICE_PER_EXPOSURE_CENTS = 10`）
- [ ] 建议套餐：¥10 / 100 次（单价演示用）
- [ ] SKILL.md / README.md 都要同步同一定价

### 发布 + 反馈收集

- [ ] 正式发 pypi：`scripts/publish-pypi.sh --live`（canary 验证 OK 后）
- [ ] 正式发 ClawHub：`scripts/publish-skill.sh --version 0.1.0 --changelog '首发'`（去 canary）
- [ ] 视频发布到选定平台（老板拍：B 站 / 小红书 / X / 社群？）
- [ ] 视频 caption + SKILL.md 都留反馈入口（微信号 / GitHub issues / 邮箱）
- [ ] 收到首条付费意向反馈 → 立即 `wiki/insights/first-paying-intent-YYYYMMDD.md`（≥ 500 字）

## 服务的目标

[O1-closed-loop](../objectives/O1-closed-loop.md) KR1.5（A3 先卖后做的"自助变种"）

## 依赖的前置

- M1/M2/M3 ✅ 已全通
- skill-publish-cli 已装全局 ✅（`which skill-publish-cli`）
- vault pypi.api_tokens[name=acong-tech-publish] ✅ 已存
- 0.2 接真支付（独立里程碑，不阻塞 M4；mock 足够验证"意愿"）
