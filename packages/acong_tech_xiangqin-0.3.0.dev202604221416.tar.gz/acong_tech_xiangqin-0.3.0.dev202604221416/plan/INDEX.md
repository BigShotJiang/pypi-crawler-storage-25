# Plan — xiangqin

最后更新：2026-04-22 22:30

## 🎯 对齐的目标

服务 [O1-closed-loop](../objectives/O1-closed-loop.md)（0.1 闭环跑通）。O2 验证在 0.1 运行 30 天后启动。

## 🚦 当前阶段

**M1 ✅ + M2 ✅ + M3 ✅ → M4 第一个真实付费意向用户**（A3 先卖后做 go/no-go）。

## 🏁 本阶段里程碑

- [x] [M1-scaffold](./M1-scaffold.md) ✅ 2026-04-22
- [x] [M2-core-flow](./M2-core-flow.md) ✅ 2026-04-22
- [x] [M3-backup-smoke](./M3-backup-smoke.md) ✅ 2026-04-22
- [ ] [M4-sell-first-user](./M4-sell-first-user.md) — 第一个真实付费意向用户

## 🛣️ 下一步（最多 3 个）

1. 找 1-3 个目标真人（单身朋友 / 社区 / 交友平台老用户）
2. 写 `scenarios/day-in-life-first-user.md` 预想流程
3. 访谈后 `wiki/insights/first-user-review-YYYYMMDD.md`（≥500 字）

## 📦 Backlog

见 [backlog.md](./backlog.md)。
