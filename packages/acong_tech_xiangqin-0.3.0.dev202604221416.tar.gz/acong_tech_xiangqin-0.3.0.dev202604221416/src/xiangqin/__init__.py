"""xiangqin — 相亲平台（付费置顶）。"""

__version__ = "0.3.0"
