"""买曝光 / 余额 / 订单历史。

Payment provider 抽象后:
    - mock provider：立即 paid=1 并充值余额（兼容原 0.1 行为）
    - wechat/alipay provider：订单 pending，返回 qr_code_content；等 webhook 回调后再充值

订单表语义:
    - paid=1 且 provider_status=paid  → 已完成充值
    - paid=0 + status=pending          → 订单创建，待支付
    - paid=0 + status=failed/cancelled → 未付款，不充值

定价（0.1 期占位）:
    1 次曝光 = 10 分人民币（¥0.10）；amount_cents = count * 10
"""

from __future__ import annotations

from dataclasses import dataclass

from . import payment
from .db import get_conn, new_id, now_ts

PRICE_PER_EXPOSURE_CENTS = 10
COUNT_MIN = 1
COUNT_MAX = 10_000


class ExposureError(Exception):
    def __init__(self, code: str, msg: str):
        super().__init__(msg)
        self.code = code


@dataclass
class Order:
    id: str
    user_id: str
    count: int
    amount_cents: int
    mock: bool
    paid: bool
    created_at: int
    # 下面 3 字段仅 create 返回时带上；list_orders 不回（存 orders 表需加列，0.2 再扩）
    provider: str | None = None
    status: str | None = None
    qr_code_content: str | None = None


@dataclass
class Balance:
    remaining: int
    total_purchased: int
    last_consumed_at: int | None


def mark_paid(order_id: str, biz_order_id: str | None = None) -> bool:
    """幂等地把 pending 订单置 paid + 充值余额。

    返回 True 表示这次把订单从 pending→paid（需要真充值）；
    返回 False 表示订单已经是终态（paid / failed / cancelled），什么都没做。
    """
    with get_conn() as conn:
        row = conn.execute(
            "SELECT user_id, count, status FROM exposure_orders WHERE id = ?",
            (order_id,),
        ).fetchone()
        if row is None:
            raise ExposureError("order_not_found", f"订单 {order_id} 不存在")
        if row["status"] != "pending":
            return False

        conn.execute(
            "UPDATE exposure_orders SET status = 'paid', paid = 1"
            + (", biz_order_id = ?" if biz_order_id else "")
            + " WHERE id = ?",
            (biz_order_id, order_id) if biz_order_id else (order_id,),
        )
        conn.execute(
            "UPDATE exposure_usage "
            "SET remaining = remaining + ?, total_purchased = total_purchased + ? "
            "WHERE user_id = ?",
            (row["count"], row["count"], row["user_id"]),
        )
    return True


def mark_final(order_id: str, status: str) -> None:
    """把订单置终态（failed / cancelled）。不充值。"""
    if status not in {"failed", "cancelled"}:
        raise ExposureError("invalid_value", f"mark_final status 不合法：{status!r}")
    with get_conn() as conn:
        conn.execute(
            "UPDATE exposure_orders SET status = ? WHERE id = ? AND status = 'pending'",
            (status, order_id),
        )


def buy(user_id: str, count: int, mock: bool) -> Order:
    """下单（可能立即 paid，也可能返回 pending + qr_code）。

    `mock` 参数保留为"用户明示要走 mock" 的断言 —— 和 provider 必须匹配：
      - mock=True + provider=mock       → OK
      - mock=True + provider=wechat/... → error：用户明示要 mock 但配了真 provider
      - mock=False + provider=mock      → error：用户不要 mock 但 provider 是 mock
    """
    if not isinstance(count, int) or count < COUNT_MIN or count > COUNT_MAX:
        raise ExposureError(
            "invalid_value", f"count 范围 [{COUNT_MIN}, {COUNT_MAX}]，收到 {count!r}"
        )

    provider = payment.get_provider()
    is_mock_provider = provider.name == "mock"
    if mock and not is_mock_provider:
        raise ExposureError(
            "mock_mismatch",
            f"用户要 --mock 但服务端 provider={provider.name}（对接了真支付）",
        )
    if not mock and is_mock_provider:
        raise ExposureError(
            "mock_required",
            "服务端 provider=mock；用户调用需传 --mock（0.1 期）",
        )

    order_id = new_id()
    amount_cents = count * PRICE_PER_EXPOSURE_CENTS
    now = now_ts()
    description = f"xiangqin 曝光 {count} 次"

    pay_order = provider.create_order(
        order_id=order_id,
        user_id=user_id,
        amount_cents=amount_cents,
        description=description,
    )

    paid_flag = 1 if pay_order.status == "paid" else 0

    with get_conn() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO exposure_usage (user_id) VALUES (?)",
            (user_id,),
        )
        conn.execute(
            "INSERT INTO exposure_orders "
            "(id, user_id, count, amount_cents, mock, paid, created_at, "
            " provider, biz_order_id, status) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (order_id, user_id, count, amount_cents, 1 if is_mock_provider else 0,
             paid_flag, now, pay_order.provider, pay_order.biz_order_id,
             pay_order.status),
        )
        if paid_flag == 1:
            conn.execute(
                "UPDATE exposure_usage "
                "SET remaining = remaining + ?, total_purchased = total_purchased + ? "
                "WHERE user_id = ?",
                (count, count, user_id),
            )

    return Order(
        id=order_id,
        user_id=user_id,
        count=count,
        amount_cents=amount_cents,
        mock=is_mock_provider,
        paid=bool(paid_flag),
        created_at=now,
        provider=pay_order.provider,
        status=pay_order.status,
        qr_code_content=pay_order.qr_code_content,
    )


def get_balance(user_id: str) -> Balance:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT remaining, total_purchased, last_consumed_at "
            "FROM exposure_usage WHERE user_id = ?",
            (user_id,),
        ).fetchone()
    if row is None:
        return Balance(remaining=0, total_purchased=0, last_consumed_at=None)
    return Balance(
        remaining=row["remaining"],
        total_purchased=row["total_purchased"],
        last_consumed_at=row["last_consumed_at"],
    )


def list_orders(user_id: str, limit: int = 50) -> list[Order]:
    if limit < 1 or limit > 100:
        raise ExposureError("invalid_value", "limit 范围 [1, 100]")
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, user_id, count, amount_cents, mock, paid, created_at "
            "FROM exposure_orders WHERE user_id = ? "
            "ORDER BY created_at DESC, rowid DESC LIMIT ?",
            (user_id, limit),
        ).fetchall()
    return [
        Order(
            id=r["id"],
            user_id=r["user_id"],
            count=r["count"],
            amount_cents=r["amount_cents"],
            mock=bool(r["mock"]),
            paid=bool(r["paid"]),
            created_at=r["created_at"],
        )
        for r in rows
    ]
