"""WechatPaymentProvider —— 微信支付 Native（扫码支付）。

⚠️ 骨架代码，0.2 里程碑前**不会**真跑。需要外部资源（见 sop/operations/payment-onboarding.md）:
    - 微信支付商户号（MCHID）—— 企业认证 + 签约约 1-2 周
    - 商户 API V3 密钥（APIv3Key）
    - 商户 API 证书（apiclient_key.pem + apiclient_cert.pem）
    - 微信支付平台公钥（用于验证回调签名）
    - webhook endpoint（必须 HTTPS + 稳定 IP/域名；xiangqin 80 → 443 升级）

vault 凭证 schema（0.2 生效）:
    platform=wechat-pay, name=main:
        app_id / mch_id / apiv3_key / serial_no
        private_key      (PEM, 多行)
        platform_public_key (PEM, 多行)

流程:
    1. 调 /v3/pay/transactions/native 得到 code_url（二维码文本）
    2. 用户扫 → 微信支付平台通知我们的 /exposure/webhook/wechat
    3. verify_webhook 用平台公钥验签 → 更新订单状态 → exposure_usage 充值
"""

from __future__ import annotations

from .base import PayOrder, PaymentProvider, OrderStatus


class WechatPaymentProvider(PaymentProvider):
    name = "wechat"

    def __init__(self) -> None:
        raise NotImplementedError(
            "WechatPaymentProvider 待 0.2：需先申请商户号 + 证书。"
            "见 sop/operations/payment-onboarding.md"
        )

    def create_order(
        self,
        order_id: str,
        user_id: str,
        amount_cents: int,
        description: str,
    ) -> PayOrder:
        # TODO(0.2):
        #   1. vault 取 mch_id / apiv3_key / private_key / serial_no
        #   2. 构造 native 支付请求 body：
        #      {
        #        "appid", "mchid", "description", "out_trade_no"=order_id,
        #        "notify_url", "amount": {"total": amount_cents, "currency": "CNY"}
        #      }
        #   3. 对 body 做 V3 签名（HTTP Headers：Authorization: WECHATPAY2-SHA256-RSA2048）
        #   4. POST https://api.mch.weixin.qq.com/v3/pay/transactions/native
        #   5. 解析 response.code_url → qr_code_content
        raise NotImplementedError

    def verify_webhook(
        self, body: bytes, headers: dict[str, str]
    ) -> tuple[str, OrderStatus]:
        # TODO(0.2):
        #   1. 从 headers 取 Wechatpay-Signature / Serial / Timestamp / Nonce
        #   2. 用 vault 里存的 platform_public_key 验签
        #   3. AES-GCM 解密 resource.ciphertext（apiv3_key 作为密钥）
        #   4. 从解密的 resource 里取 out_trade_no（= order_id）和 trade_state
        #   5. trade_state=SUCCESS → paid；REFUND → 暂不支持；其它 → pending
        raise NotImplementedError
