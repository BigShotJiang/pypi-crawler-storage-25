"""Payment provider 基类 + 订单结构。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Literal

OrderStatus = Literal["pending", "paid", "failed", "cancelled"]


@dataclass
class PayOrder:
    """provider 下单返回。

    - status=paid 表示**即时充值**（mock 场景）
    - status=pending 表示需等待异步回调（真支付，真实 provider 必然返回此态）
    - pay_url / qr_code_content 二选一：前者用于跳转，后者是二维码要渲染的文本
    - biz_order_id 是 provider 在其系统里的订单号（便于排查）
    """
    provider: str
    order_id: str                 # 我们自己系统的订单 id（exposure_orders.id）
    biz_order_id: str | None      # provider 系统的订单号（mock 为 None）
    status: OrderStatus
    amount_cents: int
    pay_url: str | None = None
    qr_code_content: str | None = None
    expires_in_s: int = 300


class PaymentProvider(ABC):
    name: str

    @abstractmethod
    def create_order(
        self,
        order_id: str,
        user_id: str,
        amount_cents: int,
        description: str,
    ) -> PayOrder:
        """创建支付订单。失败抛 RuntimeError。

        order_id 由调用方预生成（和 exposure_orders.id 一致），provider 用它做
        幂等键传给底层 provider（provider 内部 biz_order_id 可以不同，但我们的
        order_id 必须唯一映射一个 provider 订单）。
        """
        raise NotImplementedError

    @abstractmethod
    def verify_webhook(self, body: bytes, headers: dict[str, str]) -> tuple[str, OrderStatus]:
        """处理 provider 的异步回调。

        返回 (order_id, status)。
        失败（签名错 / 格式错）抛 RuntimeError（上游应回 4xx 不重试太频繁，或
        按 provider 规则返回特定字符串）。
        """
        raise NotImplementedError
