"""AlipayPaymentProvider —— 支付宝当面付（扫码支付）。

复用 vault `alipay.enterprise.kongxuanpin` platform（2026-04-23 零等待接入，
已实测 prod precreate 返回真 qr_code）:
    app_id              应用 ID
    gateway_url         https://openapi.alipay.com/gateway.do
    app_private_key     RSA 2048 PEM（多行）
    alipay_public_key   支付宝平台公钥 PEM（用于验签回调）

流程:
    1. create_order 调 alipay.trade.precreate → 拿 qr_code（字符串，例 "https://qr.alipay.com/bax..."）
    2. CLI 把 qr_code 渲染为 ASCII 二维码（用户手机支付宝 app 扫）
    3. 用户支付 → 支付宝异步 POST /exposure/webhook/alipay
    4. verify_webhook 用 alipay_public_key 验签 → 返回 (order_id, status)
    5. 路由更新订单 + 充值 exposure_usage

参考:
    https://opendocs.alipay.com/open/194/105170
    https://opendocs.alipay.com/common/02khjm （RSA2 签名）
"""

from __future__ import annotations

import base64
import json
import os
import subprocess
from datetime import datetime
from typing import Any

import httpx
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from .base import OrderStatus, PayOrder, PaymentProvider

VAULT_PLATFORM = "alipay.enterprise.kongxuanpin"


class AlipayPaymentProvider(PaymentProvider):
    name = "alipay"

    def __init__(self) -> None:
        cred = _vault_get(VAULT_PLATFORM)
        self._app_id = cred["app_id"]
        self._gateway = cred["gateway_url"]
        # 去掉可能存在的字面 \n 转义（vault 存的是 '-----BEGIN...\n...'）
        self._app_private_key = _normalize_pem(cred["app_private_key"])
        self._alipay_public_key = _normalize_pem(cred["alipay_public_key"])

    def create_order(
        self,
        order_id: str,
        user_id: str,
        amount_cents: int,
        description: str,
    ) -> PayOrder:
        """调 alipay.trade.precreate 生成支付二维码。"""
        yuan = f"{amount_cents / 100:.2f}"  # 支付宝要元，保留 2 位
        biz_content = {
            "out_trade_no": order_id,
            "total_amount": yuan,
            "subject": description[:256],
        }
        params = self._build_public_params("alipay.trade.precreate", biz_content)
        params["sign"] = self._sign(params)

        # 支付宝要求 charset 参数必须在 URL 查询串中（否则 fallback GBK 返回 + 验签错）
        # 简单起见：所有参数都作为 POST body 的 form 字段 + 也作 URL query（冗余但安全）
        try:
            r = httpx.post(
                self._gateway,
                params={"charset": params["charset"]},
                data=params,
                timeout=15.0,
                trust_env=False,
            )
            r.raise_for_status()
            resp = json.loads(r.content.decode("utf-8"))
        except httpx.HTTPError as e:
            raise RuntimeError(f"alipay precreate HTTP 失败: {e}") from e
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise RuntimeError(
                f"alipay precreate 响应解码失败（content-type={r.headers.get('content-type')}）: "
                f"{r.content[:200]!r}"
            ) from e

        payload = resp.get("alipay_trade_precreate_response") or {}
        if payload.get("code") != "10000":
            raise RuntimeError(
                f"alipay precreate 业务错误 code={payload.get('code')} "
                f"msg={payload.get('msg')} sub_code={payload.get('sub_code')} "
                f"sub_msg={payload.get('sub_msg')}"
            )

        qr = payload.get("qr_code")
        biz_no = payload.get("out_trade_no") or order_id

        return PayOrder(
            provider="alipay",
            order_id=order_id,
            biz_order_id=biz_no,
            status="pending",
            amount_cents=amount_cents,
            pay_url=None,
            qr_code_content=qr,
            expires_in_s=300,  # 支付宝当面付二维码默认 5 分钟
        )

    def verify_webhook(
        self, body: bytes, headers: dict[str, str]
    ) -> tuple[str, OrderStatus]:
        """支付宝异步回调。

        body 是 `x-www-form-urlencoded` 的 k=v&k=v 串（不是 JSON）。
        验签规则：除 sign / sign_type 外的字段按 key 排序 + 拼 k=v&k=v + 用
        alipay_public_key 验证 sign（base64 解码后走 RSA-SHA256）。
        """
        from urllib.parse import parse_qsl

        # 保留原始 value（含空格、特殊字符）做验签
        pairs = parse_qsl(body.decode("utf-8"), keep_blank_values=True)
        data = dict(pairs)

        sign = data.pop("sign", None)
        data.pop("sign_type", None)
        if not sign:
            raise RuntimeError("alipay webhook 缺少 sign 字段")

        # 排序并拼接（k=v&k=v）
        canonical = "&".join(f"{k}={v}" for k, v in sorted(data.items()))

        # 用 alipay_public_key 验签
        public_key = serialization.load_pem_public_key(self._alipay_public_key.encode())
        try:
            public_key.verify(  # type: ignore[union-attr]
                base64.b64decode(sign),
                canonical.encode("utf-8"),
                padding.PKCS1v15(),
                hashes.SHA256(),
            )
        except Exception as e:  # noqa: BLE001
            raise RuntimeError(f"alipay webhook 验签失败: {e}") from e

        order_id = data.get("out_trade_no")
        if not order_id:
            raise RuntimeError("alipay webhook 缺 out_trade_no")

        trade_status = data.get("trade_status", "")
        status: OrderStatus
        if trade_status in ("TRADE_SUCCESS", "TRADE_FINISHED"):
            status = "paid"
        elif trade_status == "WAIT_BUYER_PAY":
            status = "pending"
        elif trade_status in ("TRADE_CLOSED",):
            status = "cancelled"
        else:
            status = "failed"
        return order_id, status

    # ---- 内部工具 ----

    def _build_public_params(self, method: str, biz_content: dict[str, Any]) -> dict[str, str]:
        params = {
            "app_id": self._app_id,
            "method": method,
            "format": "JSON",
            "charset": "utf-8",
            "sign_type": "RSA2",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version": "1.0",
            "biz_content": json.dumps(biz_content, ensure_ascii=False, separators=(",", ":")),
        }
        # XIANGQIN_BASE_URL 指向 xiangqin 服务端公网（例 http://112.124.27.213）
        # 支付宝会异步 POST 到 <base>/exposure/webhook/alipay
        base = os.environ.get("XIANGQIN_BASE_URL", "").rstrip("/")
        if base:
            params["notify_url"] = f"{base}/exposure/webhook/alipay"
        return params

    def _sign(self, params: dict[str, str]) -> str:
        """RSA2（RSA-SHA256）签名公共参数 + biz_content。

        规则：除 sign / sign_type 外字段按 key 升序，拼 k=v&k=v，然后用
        app_private_key 做 RSA-SHA256 签名，base64 输出。
        """
        # 支付宝验签字符串含 sign_type，只排除 sign 本身
        filtered = {k: v for k, v in params.items() if k != "sign"}
        canonical = "&".join(f"{k}={v}" for k, v in sorted(filtered.items()))

        private_key = serialization.load_pem_private_key(
            self._app_private_key.encode(), password=None
        )
        signature = private_key.sign(  # type: ignore[union-attr]
            canonical.encode("utf-8"),
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
        return base64.b64encode(signature).decode()


def _normalize_pem(pem: str) -> str:
    """把 vault 可能返回的字面 '\\n' 转成真换行。

    vault JSON 里 PEM 私钥可能以 '-----BEGIN ...-----\\n...\\n-----END ...-----'
    形式存（json.dumps 转义了 \\n）。反序列化后 Python 字符串里可能已经是真
    换行，也可能还带字面转义。统一处理。
    """
    if "\\n" in pem and "\n" not in pem:
        pem = pem.replace("\\n", "\n")
    # 常见 BEGIN / END 之间至少应有 1 行 base64 + 换行结尾
    if not pem.endswith("\n"):
        pem += "\n"
    return pem


def _vault_get(platform: str) -> dict[str, str]:
    result = subprocess.run(
        ["vault", "get", platform, "--unmask", "--json"],
        check=True,
        capture_output=True,
        text=True,
    )
    data = json.loads(result.stdout)
    creds = data.get("credentials") or {}
    if not creds:
        raise RuntimeError(f"vault {platform} 没有 credentials 字段")
    return creds
