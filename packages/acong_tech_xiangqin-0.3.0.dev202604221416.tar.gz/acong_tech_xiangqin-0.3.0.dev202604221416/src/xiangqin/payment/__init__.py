"""Payment provider 抽象层。

XIANGQIN_PAYMENT_PROVIDER 环境变量选实现：
    mock       (默认) —— 立即标记 paid，不真扣款
    wechat             —— 微信支付 Native（扫码）
    alipay             —— 支付宝当面付（扫码）

wechat / alipay 都需要外部商户号 + 证书/密钥（见 sop/operations/payment-onboarding.md）。
0.1 正式期走 mock；0.2 接真支付。
"""

from __future__ import annotations

import os

from .base import PaymentProvider, PayOrder
from .mock import MockPaymentProvider

__all__ = ["PaymentProvider", "PayOrder", "get_provider"]


def get_provider() -> PaymentProvider:
    choice = os.environ.get("XIANGQIN_PAYMENT_PROVIDER", "mock").lower()
    if choice == "mock":
        return MockPaymentProvider()
    if choice == "wechat":
        from .wechat import WechatPaymentProvider

        return WechatPaymentProvider()
    if choice == "alipay":
        from .alipay import AlipayPaymentProvider

        return AlipayPaymentProvider()
    raise ValueError(
        f"XIANGQIN_PAYMENT_PROVIDER={choice!r} 未识别（支持 mock / wechat / alipay）"
    )
