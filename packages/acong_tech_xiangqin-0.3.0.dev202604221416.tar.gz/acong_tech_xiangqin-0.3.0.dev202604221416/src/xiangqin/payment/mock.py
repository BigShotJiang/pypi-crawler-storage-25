"""MockPaymentProvider：立即 paid，不真扣款。"""

from __future__ import annotations

from .base import PayOrder, PaymentProvider


class MockPaymentProvider(PaymentProvider):
    name = "mock"

    def create_order(
        self,
        order_id: str,
        user_id: str,
        amount_cents: int,
        description: str,
    ) -> PayOrder:
        return PayOrder(
            provider="mock",
            order_id=order_id,
            biz_order_id=None,
            status="paid",
            amount_cents=amount_cents,
            pay_url=None,
            qr_code_content=None,
            expires_in_s=0,
        )

    def verify_webhook(self, body: bytes, headers: dict[str, str]) -> tuple[str, str]:
        # mock 不接收 webhook（同步模式）
        raise RuntimeError("mock provider 不处理 webhook")
