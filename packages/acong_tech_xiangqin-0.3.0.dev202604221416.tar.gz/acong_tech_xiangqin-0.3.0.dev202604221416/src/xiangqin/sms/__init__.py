"""SMS provider 抽象层。

XIANGQIN_SMS_PROVIDER 环境变量选实现：
    mock    (默认) —— 验证码固定 123456，不真发
    aliyun         —— 真调阿里云短信服务

aliyun 需要 vault 里存:
    aliyun/main:           access_key_id / access_key_secret
    aliyun-sms:            sign_name / template_code
"""

from __future__ import annotations

import os

from .base import SmsProvider
from .mock import MockSmsProvider

__all__ = ["SmsProvider", "get_provider"]


def get_provider() -> SmsProvider:
    choice = os.environ.get("XIANGQIN_SMS_PROVIDER", "mock").lower()
    if choice == "mock":
        return MockSmsProvider()
    if choice == "aliyun":
        from .aliyun import AliyunSmsProvider  # 按需 import 避免 mock 环境装多余依赖

        return AliyunSmsProvider()
    raise ValueError(f"XIANGQIN_SMS_PROVIDER={choice!r} 未识别（支持 mock / aliyun）")
