"""MockSmsProvider：不真发，只输出"已发"日志。验证码恒为 123456（由 auth 层保证）。"""

from __future__ import annotations

import logging

from .base import SmsProvider

log = logging.getLogger("xiangqin.sms.mock")


class MockSmsProvider(SmsProvider):
    name = "mock"

    def send_code(self, phone: str, code: str) -> None:
        masked = f"{phone[:3]}****{phone[-4:]}"
        log.info("[mock] 已发验证码到 %s（6 位数字，不真发；0.1 期固定 123456）", masked)
