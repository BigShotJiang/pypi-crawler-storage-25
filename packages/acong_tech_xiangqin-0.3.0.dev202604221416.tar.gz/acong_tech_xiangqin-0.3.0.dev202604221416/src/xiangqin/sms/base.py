"""SMS provider 基类接口。"""

from __future__ import annotations

from abc import ABC, abstractmethod


class SmsProvider(ABC):
    name: str

    @abstractmethod
    def send_code(self, phone: str, code: str) -> None:
        """真把 code 发到 phone 上。失败抛 RuntimeError。

        实现契约:
        - 单次调用阻塞直到发送返回（成功 / 失败）
        - 发送成功返回 None；失败抛 RuntimeError，message 含可诊断的原因
        - **不得**日志打印完整手机号（最多 138****1111 掩码）
        - **不得**日志打印完整验证码（最多显示"已发 6 位数字"字样）
        """
        raise NotImplementedError
