# 知识库索引

自动生成于 2026-04-22

（骨架期，wiki 为空。每次新增或修改 raw/shares/insights/playbooks 下的 .md
后，用 team-wiki skill 里的生成命令 regenerate 本文件。）
