"""Decorators for cached callables.

This module exposes a convenience decorator that wires a cache manager into
``cachetools.cached`` for synchronous functions and provides equivalent
result-caching behavior for asynchronous functions.
"""

from __future__ import annotations

import functools
import inspect
from collections.abc import Awaitable, Callable, Hashable
from contextlib import AbstractContextManager
from typing import Any, ParamSpec, TypeVar, cast

from cachetools import cached as cachetools_cached
from cachetools.keys import hashkey, methodkey

from .core import AsyncCacheManager, CacheManager, cache_function_context

P = ParamSpec("P")
R = TypeVar("R")
F = TypeVar("F", bound=Callable[..., Any])


def cached(
    manager: CacheManager[Hashable, Any],
    *,
    key: Callable[..., Hashable] = hashkey,
    info: bool = False,
) -> Callable[[F], F]:
    """Cache a function with a logged cache manager.

    This is a small convenience wrapper around ``cachetools.cached``. Pass the
    manager instead of wiring ``manager.cache`` and ``manager.lock`` manually.
    Async functions are supported too; their awaited result is cached.

    Args:
        manager: Cache manager that owns the logged cache and lock.
        key: Callable that creates a hashable cache key from function arguments.
        info: Whether to expose cache information on the wrapped callable.

    Returns:
        A decorator that returns a cached callable with the same call signature
        as the original function.
    """

    def decorator(func: F) -> F:
        """Wrap a callable with synchronous or asynchronous cache behavior.

        Args:
            func: Callable to cache.

        Returns:
            Cached callable preserving the original function type.
        """
        _ensure_cache_name(manager, func)
        function_name = _function_name(func)
        function_label = _function_label(func)
        if inspect.iscoroutinefunction(func):
            async_func = cast(Callable[..., Awaitable[Any]], func)
            return cast(
                F,
                _cached_async(
                    async_func,
                    manager=manager,
                    key=key,
                    info=info,
                    function_name=function_name,
                    function_label=function_label,
                ),
            )

        lock = cast(AbstractContextManager[Any], manager.lock)
        if info:
            wrapped_info = cachetools_cached(
                cache=manager.cache,
                key=key,
                lock=lock,
                info=True,
            )(func)
            return cast(F, _with_cache_function(wrapped_info, function_name, function_label))

        wrapped_plain = cachetools_cached(
            cache=manager.cache,
            key=key,
            lock=lock,
            info=False,
        )(func)
        return cast(F, _with_cache_function(wrapped_plain, function_name, function_label))

    return decorator


def _ensure_cache_name(
    manager: CacheManager[Hashable, Any] | AsyncCacheManager[Hashable, Any],
    func: Callable[..., Any],
) -> None:
    """Set a readable fallback cache name from a decorated callable.

    Args:
        manager: Cache manager to name.
        func: Callable whose module and qualified name identify the cache use.
    """
    manager.set_name(f"{func.__module__}.{func.__qualname__}")


def _function_name(func: Callable[..., Any]) -> str:
    """Return a full function name for structured logs.

    Args:
        func: Callable to identify.

    Returns:
        Module-qualified callable name.
    """
    return f"{func.__module__}.{func.__qualname__}"


def _function_label(func: Callable[..., Any]) -> str:
    """Return a short function label for human-readable logs.

    Args:
        func: Callable to identify.

    Returns:
        Callable qualified name without the module prefix.
    """
    return func.__qualname__


def _with_cache_function(func: F, function_name: str, function_label: str) -> F:
    """Wrap a callable so cache logs include function context.

    Args:
        func: Callable to wrap.
        function_name: Full function name for structured logs.
        function_label: Short function label for log messages.

    Returns:
        Wrapped callable preserving metadata and attributes.
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        """Call a wrapped function inside cache function context.

        Args:
            *args: Positional arguments forwarded to ``func``.
            **kwargs: Keyword arguments forwarded to ``func``.

        Returns:
            Return value from ``func``.
        """
        with cache_function_context(function_name, label=function_label):
            return func(*args, **kwargs)

    cache_clear = getattr(func, "cache_clear", None)
    if cache_clear is not None:

        def wrapped_cache_clear() -> Any:
            """Clear cache inside cache function context.

            Returns:
                Return value from the wrapped cache clear helper.
            """
            with cache_function_context(function_name, label=function_label):
                return cache_clear()

        wrapper.cache_clear = wrapped_cache_clear  # type: ignore[attr-defined]

    return cast(F, wrapper)


def cachedmethod(
    manager: CacheManager[Hashable, Any],
    *,
    key: Callable[..., Hashable] = methodkey,
    info: bool = False,
) -> Callable[[F], F]:
    """Cache an instance or class method with a logged cache manager.

    The default ``methodkey`` ignores the first positional argument, which is
    normally ``self`` for instance methods or ``cls`` for class methods. This
    keeps keys focused on the method's business arguments instead of object
    identity. Pass a custom ``key`` callable when object identity should be part
    of the cache key.

    Args:
        manager: Cache manager that owns the logged cache and lock.
        key: Callable that creates a hashable cache key from method arguments.
        info: Whether to expose cache information on the wrapped method.

    Returns:
        A decorator that returns a cached method with the same call signature as
        the original method.
    """
    return cached(manager, key=key, info=info)


def async_cached(
    manager: AsyncCacheManager[Hashable, Any],
    *,
    key: Callable[..., Hashable] = hashkey,
    info: bool = False,
) -> Callable[[Callable[P, Awaitable[R]]], Callable[P, Awaitable[R]]]:
    """Cache an async function with an async cache manager.

    Args:
        manager: Async cache manager that owns the logged cache and async lock.
        key: Callable that creates a hashable cache key from function arguments.
        info: Whether to expose cache information on the wrapped callable.

    Returns:
        A decorator that returns an async cached callable.
    """

    def decorator(func: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        """Wrap an async callable with async-lock cache behavior.

        Args:
            func: Async callable to cache.

        Returns:
            Async cached callable preserving the original signature.
        """
        _ensure_cache_name(manager, func)
        function_name = _function_name(func)
        function_label = _function_label(func)
        return _cached_async_with_async_lock(
            func,
            manager=manager,
            key=key,
            info=info,
            function_name=function_name,
            function_label=function_label,
        )

    return decorator


def async_cachedmethod(
    manager: AsyncCacheManager[Hashable, Any],
    *,
    key: Callable[..., Hashable] = methodkey,
    info: bool = False,
) -> Callable[[Callable[P, Awaitable[R]]], Callable[P, Awaitable[R]]]:
    """Cache an async method with an async cache manager.

    Args:
        manager: Async cache manager that owns the logged cache and async lock.
        key: Callable that creates a hashable cache key from method arguments.
        info: Whether to expose cache information on the wrapped method.

    Returns:
        A decorator that returns an async cached method.
    """
    return async_cached(manager, key=key, info=info)


def _cached_async(
    func: Callable[P, Awaitable[R]],
    *,
    manager: CacheManager[Hashable, R],
    key: Callable[..., Hashable],
    info: bool,
    function_name: str,
    function_label: str,
) -> Callable[P, Awaitable[R]]:
    """Cache an asynchronous callable by awaited result.

    Args:
        func: Asynchronous callable to wrap.
        manager: Cache manager that owns the logged cache and lock.
        key: Callable that creates a hashable cache key from function arguments.
        info: Whether to expose cache information on the wrapped callable.
        function_name: Full function name for structured logs.
        function_label: Short function label for log messages.

    Returns:
        An asynchronous callable that caches completed results.
    """
    hits = 0
    misses = 0

    @functools.wraps(func)
    async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        """Return a cached async result or await and cache a new value.

        Args:
            *args: Positional arguments forwarded to the wrapped callable.
            **kwargs: Keyword arguments forwarded to the wrapped callable.

        Returns:
            Cached or newly awaited result.
        """
        nonlocal hits, misses
        cache_key = key(*args, **kwargs)

        with cache_function_context(function_name, label=function_label):
            with manager.lock:
                try:
                    result = manager.cache[cache_key]
                except KeyError:
                    misses += 1
                else:
                    hits += 1
                    return result

        value = await func(*args, **kwargs)

        with cache_function_context(function_name, label=function_label):
            with manager.lock:
                try:
                    return cast(R, manager.cache.setdefault(cache_key, value))
                except ValueError:
                    return value

    def cache_clear() -> None:
        """Clear the async wrapper cache and reset local cache info counters."""
        nonlocal hits, misses
        with cache_function_context(function_name, label=function_label):
            manager.clear()
        hits = 0
        misses = 0

    def cache_info() -> tuple[int, int, int | None, int]:
        """Return cache information for the async wrapper.

        Returns:
            Tuple of ``hits``, ``misses``, ``maxsize``, and current cache size.
        """
        maxsize = getattr(manager.cache, "maxsize", None)
        return hits, misses, maxsize, len(manager.cache)

    wrapper.cache = manager.cache  # type: ignore[attr-defined]
    wrapper.cache_key = key  # type: ignore[attr-defined]
    wrapper.cache_lock = manager.lock  # type: ignore[attr-defined]
    wrapper.cache_clear = cache_clear  # type: ignore[attr-defined]
    wrapper.cache_info = cache_info if info else None  # type: ignore[attr-defined]
    return wrapper


def _cached_async_with_async_lock(
    func: Callable[P, Awaitable[R]],
    *,
    manager: AsyncCacheManager[Hashable, R],
    key: Callable[..., Hashable],
    info: bool,
    function_name: str,
    function_label: str,
) -> Callable[P, Awaitable[R]]:
    """Cache an asynchronous callable using an async cache manager.

    Args:
        func: Asynchronous callable to wrap.
        manager: Async cache manager that owns the logged cache and async lock.
        key: Callable that creates a hashable cache key from function arguments.
        info: Whether to expose cache information on the wrapped callable.
        function_name: Full function name for structured logs.
        function_label: Short function label for log messages.

    Returns:
        An asynchronous callable that caches completed results.
    """
    hits = 0
    misses = 0

    @functools.wraps(func)
    async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        """Return a cached async result or await and cache a new value.

        Args:
            *args: Positional arguments forwarded to the wrapped callable.
            **kwargs: Keyword arguments forwarded to the wrapped callable.

        Returns:
            Cached or newly awaited result.
        """
        nonlocal hits, misses
        cache_key = key(*args, **kwargs)

        with cache_function_context(function_name, label=function_label):
            async with manager.lock:
                try:
                    result = manager.cache[cache_key]
                except KeyError:
                    misses += 1
                else:
                    hits += 1
                    return result

        value = await func(*args, **kwargs)

        with cache_function_context(function_name, label=function_label):
            async with manager.lock:
                try:
                    return cast(R, manager.cache.setdefault(cache_key, value))
                except ValueError:
                    return value

    async def cache_clear() -> None:
        """Clear the async wrapper cache and reset local cache info counters."""
        nonlocal hits, misses
        with cache_function_context(function_name, label=function_label):
            await manager.clear()
        hits = 0
        misses = 0

    def cache_info() -> tuple[int, int, int | None, int]:
        """Return cache information for the async wrapper.

        Returns:
            Tuple of ``hits``, ``misses``, ``maxsize``, and current cache size.
        """
        maxsize = getattr(manager.cache, "maxsize", None)
        return hits, misses, maxsize, len(manager.cache)

    wrapper.cache = manager.cache  # type: ignore[attr-defined]
    wrapper.cache_key = key  # type: ignore[attr-defined]
    wrapper.cache_lock = manager.lock  # type: ignore[attr-defined]
    wrapper.cache_clear = cache_clear  # type: ignore[attr-defined]
    wrapper.cache_info = cache_info if info else None  # type: ignore[attr-defined]
    return wrapper
