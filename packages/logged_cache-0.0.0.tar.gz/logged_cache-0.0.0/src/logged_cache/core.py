"""Core cache wrappers and managers.

This module contains mapping wrappers and manager classes used by the public
``logged_cache`` API. The wrappers keep the cachetools-compatible mapping
surface while adding logging, simple in-memory counters, and event hooks.
"""

from __future__ import annotations

import abc
import asyncio
import contextlib
import contextvars
import logging
import re
from collections.abc import Callable, Iterator, MutableMapping
from dataclasses import dataclass
from threading import RLock
from typing import Any, Generic, Literal, TypeVar, cast

from cachetools import Cache, LRUCache, TTLCache

K = TypeVar("K")
V = TypeVar("V")

CacheEvent = Literal["hit", "miss", "set", "delete", "clear"]
KeyFormatter = Callable[[Any], str]
EventHook = Callable[[CacheEvent, Any], None]
CacheFunction = tuple[str, str]
DEFAULT_CACHE_NAME = "logged-cache"
DEFAULT_MAX_KEY_LENGTH = 300
_CACHE_FUNCTION: contextvars.ContextVar[CacheFunction | None] = contextvars.ContextVar(
    "logged_cache_function",
    default=None,
)
_OBJECT_REPR_PATTERN = re.compile(
    r"^<(?P<class>.+) object at 0x[0-9a-fA-F]+>$",
)
_EVENT_MESSAGES: dict[CacheEvent, str] = {
    "hit": "Cache hit",
    "miss": "Cache miss",
    "set": "Cache set",
    "delete": "Cache delete",
    "clear": "Cache cleared",
}


def default_key_formatter(key: Any) -> str:
    """Format a cache key for log output.

    Long keys are truncated and default object representations such as
    ``<module.Class object at 0x...>`` are converted into stable,
    human-readable class descriptions.

    Args:
        key: Cache key received by a logged cache operation.

    Returns:
        A stable string representation suitable for logs.
    """
    return format_cache_key(key)


def format_cache_key(key: Any, *, max_length: int = DEFAULT_MAX_KEY_LENGTH) -> str:
    """Format a cache key safely for log output.

    Args:
        key: Cache key received by a logged cache operation.
        max_length: Maximum number of characters to include in the returned
            representation.

    Returns:
        Human-readable key text capped at ``max_length`` characters.
    """
    return _truncate_text(_describe_value(key), max_length=max_length)


def _describe_value(value: object) -> str:
    """Return a stable, human-readable description of a value.

    Args:
        value: Value to describe.

    Returns:
        A readable text representation.
    """
    if isinstance(value, tuple):
        return _describe_tuple(cast(tuple[object, ...], value))
    return _describe_single_value(value)


def _describe_tuple(values: tuple[object, ...]) -> str:
    """Return a readable tuple representation.

    Args:
        values: Tuple to describe.

    Returns:
        Tuple-like text with readable item descriptions.
    """
    items = [_describe_single_value(value) for value in values]
    trailing_comma = "," if len(values) == 1 else ""
    return f"({', '.join(items)}{trailing_comma})"


def _describe_single_value(value: object) -> str:
    """Return a readable representation for a single value.

    Args:
        value: Value to describe.

    Returns:
        Readable text representation for ``value``.
    """
    try:
        text = repr(value)
    except Exception:  # pylint: disable=broad-exception-caught
        text = _describe_object(value)

    if _looks_like_default_object_repr(text):
        return _describe_object(value)
    return text


def _looks_like_default_object_repr(text: str) -> bool:
    """Check whether text looks like Python's default object repr.

    Args:
        text: Representation text to inspect.

    Returns:
        ``True`` when ``text`` matches ``<module.Class object at 0x...>``.
    """
    return _OBJECT_REPR_PATTERN.match(text) is not None


def _describe_object(value: object) -> str:
    """Describe an object without including memory addresses.

    Args:
        value: Object to describe.

    Returns:
        Class-qualified description for ``value``.
    """
    value_type: type[object] = type(value)
    return f"<{value_type.__module__}.{value_type.__qualname__}>"


def _truncate_text(text: str, *, max_length: int) -> str:
    """Truncate text while preserving total length bounds.

    Args:
        text: Text to truncate.
        max_length: Maximum output length.

    Returns:
        ``text`` when short enough, otherwise a shortened representation with a
        truncation marker.
    """
    if len(text) <= max_length:
        return text
    marker = "...<truncated>"
    if max_length <= len(marker):
        return marker[:max_length]
    return f"{text[: max_length - len(marker)]}{marker}"


@contextlib.contextmanager
def cache_function_context(
    function: str,
    *,
    label: str | None = None,
) -> Iterator[None]:
    """Temporarily attach a function name to cache log records.

    Args:
        function: Full function or method name for structured log records.
        label: Short human-readable function or method name for log messages.

    Yields:
        Control to the wrapped cache operation.
    """
    token = _CACHE_FUNCTION.set((function, label or function))
    try:
        yield
    finally:
        _CACHE_FUNCTION.reset(token)


@dataclass(slots=True)
class CacheStats:
    """Counters collected by ``LoggedCache``.

    Statistics are intentionally small and in-memory. They are useful for tests,
    local diagnostics, and exporting counters to your own metrics system.

    Attributes:
        hits: Number of successful cache lookups.
        misses: Number of failed cache lookups.
        sets: Number of values written into the cache.
        deletes: Number of values removed from the cache.
        clears: Number of full cache clear operations.
    """

    hits: int = 0
    misses: int = 0
    sets: int = 0
    deletes: int = 0
    clears: int = 0

    @property
    def lookups(self) -> int:
        """Return the total number of cache lookup events.

        Returns:
            The sum of ``hits`` and ``misses``.
        """
        return self.hits + self.misses

    @property
    def hit_rate(self) -> float:
        """Return the cache hit rate.

        Returns:
            ``hits / lookups`` when at least one lookup happened, otherwise
            ``0.0``.
        """
        if self.lookups == 0:
            return 0.0
        return self.hits / self.lookups

    def reset(self) -> None:
        """Reset all counters to zero."""
        self.hits = 0
        self.misses = 0
        self.sets = 0
        self.deletes = 0
        self.clears = 0


class CacheManager(abc.ABC, Generic[K, V]):
    """Common interface for cache managers.

    Attributes:
        cache: Logged mapping passed to ``cachetools`` decorators.
        lock: Re-entrant lock used to protect cache access.
        stats: Mutable counters shared with ``cache``.
    """

    cache: LoggedCache[K, V]
    lock: RLock
    stats: CacheStats

    @abc.abstractmethod
    def clear(self) -> None:
        """Remove all items from the cache."""

    @abc.abstractmethod
    def set_name(self, name: str, *, replace: bool = False) -> None:
        """Set the human-readable cache name.

        Args:
            name: New cache name to use in log messages.
            replace: Whether to replace an explicitly configured name.
        """


class AsyncCacheManager(abc.ABC, Generic[K, V]):
    """Common interface for async cache managers.

    Attributes:
        cache: Logged mapping used by async decorators.
        lock: Async lock used to protect cache access.
        stats: Mutable counters shared with ``cache``.
    """

    cache: LoggedCache[K, V]
    lock: asyncio.Lock
    stats: CacheStats

    @abc.abstractmethod
    async def clear(self) -> None:
        """Remove all items from the cache asynchronously."""

    @abc.abstractmethod
    def set_name(self, name: str, *, replace: bool = False) -> None:
        """Set the human-readable cache name.

        Args:
            name: New cache name to use in log messages.
            replace: Whether to replace an explicitly configured name.
        """


class LoggedCache(MutableMapping[K, V], Generic[K, V]):
    """A mapping wrapper that logs cache activity.

    ``LoggedCache`` is compatible with ``cachetools.cached`` because it
    implements the mutable mapping protocol. It records hits and misses from
    ``__getitem__`` and ``__contains__``; writes, deletes, and clears are also
    emitted as events.

    Args:
        inner: Mutable mapping to wrap. In normal use this is a ``cachetools``
            cache instance.
        logger: Logger used for cache events. If omitted, the root logger from
            ``logging.getLogger()`` is used.
        log_level: Logging level used for emitted cache events.
        stats: Existing stats object to update. If omitted, a new ``CacheStats``
            instance is created.
        key_formatter: Callable used to convert cache keys into log-safe text.
        on_event: Optional callback invoked for every cache event.
        name: Human-readable cache name used in log messages.
    """

    def __init__(
        self,
        inner: MutableMapping[K, V],
        *,
        logger: logging.Logger | None = None,
        log_level: int = logging.DEBUG,
        stats: CacheStats | None = None,
        key_formatter: KeyFormatter = default_key_formatter,
        on_event: EventHook | None = None,
        name: str | None = None,
    ) -> None:
        self._inner = inner
        self._logger = logger if logger is not None else logging.getLogger()
        self._log_level = log_level
        self._stats = stats if stats is not None else CacheStats()
        self._key_formatter = key_formatter
        self._on_event = on_event
        self._name = name or DEFAULT_CACHE_NAME
        self._name_is_default = name is None

    @property
    def inner(self) -> MutableMapping[K, V]:
        """Return the wrapped mutable mapping.

        Returns:
            The mapping passed to ``LoggedCache`` during initialization.
        """
        return self._inner

    @property
    def stats(self) -> CacheStats:
        """Return mutable cache statistics.

        Returns:
            The ``CacheStats`` object updated by this cache.
        """
        return self._stats

    @property
    def name(self) -> str:
        """Return the human-readable cache name.

        Returns:
            Cache name used in log messages and structured log fields.
        """
        return self._name

    def set_name(self, name: str, *, replace: bool = False) -> None:
        """Set the human-readable cache name.

        Args:
            name: New cache name to use in log messages.
            replace: Whether to replace an explicitly configured name. When
                ``False``, only the default fallback name is replaced.
        """
        if replace or self._name_is_default:
            self._name = name
            self._name_is_default = False

    def __getitem__(self, key: K) -> V:
        """Return a cached value and emit a hit or miss event.

        Args:
            key: Cache key to look up.

        Returns:
            The cached value for ``key``.

        Raises:
            KeyError: If ``key`` is not present in the wrapped cache.
        """
        try:
            value = self._inner[key]
        except KeyError:
            self._emit("miss", key)
            raise
        self._emit("hit", key)
        return value

    def __setitem__(self, key: K, value: V) -> None:
        """Store a value and emit a set event.

        Args:
            key: Cache key to write.
            value: Value to store under ``key``.
        """
        self._inner[key] = value
        self._emit("set", key)

    def __delitem__(self, key: K) -> None:
        """Delete a value and emit a delete event.

        Args:
            key: Cache key to delete.

        Raises:
            KeyError: If ``key`` is not present in the wrapped cache.
        """
        del self._inner[key]
        self._emit("delete", key)

    def __iter__(self) -> Iterator[K]:
        """Iterate over cached keys.

        Returns:
            Iterator over keys from the wrapped cache.
        """
        return iter(self._inner)

    def __len__(self) -> int:
        """Return the number of cached items.

        Returns:
            Current length of the wrapped cache.
        """
        return len(self._inner)

    def __contains__(self, key: object) -> bool:
        """Check whether a key is cached and emit a lookup event.

        Args:
            key: Cache key candidate to check.

        Returns:
            ``True`` when the key is present, otherwise ``False``.
        """
        exists = key in self._inner
        self._emit("hit" if exists else "miss", key)
        return exists

    def clear(self) -> None:
        """Remove all items and emit a clear event."""
        self._inner.clear()
        self._emit("clear", None)

    def setdefault(self, key: K, default: Any = None) -> Any:
        """Return an existing value or store ``default`` without double-counting misses.

        ``cachetools.cached`` uses ``setdefault`` after a miss to handle races
        between concurrent calls. The default implementation from
        ``MutableMapping`` performs another ``__getitem__`` lookup, which would
        emit a second miss for one logical cache lookup.

        Args:
            key: Cache key to look up.
            default: Value to store when ``key`` is missing.

        Returns:
            Existing cached value for ``key`` or the stored ``default``.
        """
        try:
            value = self._inner[key]
        except KeyError:
            self._inner[key] = default
            self._emit("set", key)
            return default
        self._emit("hit", key)
        return value

    def __getattr__(self, name: str) -> Any:
        """Delegate unknown attributes to the wrapped cache.

        Args:
            name: Attribute name to read from the wrapped cache.

        Returns:
            Attribute value from the wrapped cache.

        Raises:
            AttributeError: If the wrapped cache does not define ``name``.
        """
        return getattr(self._inner, name)

    def _emit(self, event: CacheEvent, key: Any) -> None:
        """Update counters, call hooks, and write a log event.

        Args:
            event: Cache event name.
            key: Cache key associated with the event, or ``None`` for clear.
        """
        if event == "hit":
            self._stats.hits += 1
        elif event == "miss":
            self._stats.misses += 1
        elif event == "set":
            self._stats.sets += 1
        elif event == "delete":
            self._stats.deletes += 1
        elif event == "clear":
            self._stats.clears += 1

        if self._on_event is not None:
            self._on_event(event, key)

        if self._logger:
            formatted_key = "<all>" if event == "clear" else self._key_formatter(key)
            function_context = _CACHE_FUNCTION.get()
            cache_function = function_context[0] if function_context else None
            cache_function_label = function_context[1] if function_context else None
            message = _EVENT_MESSAGES[event]
            if cache_function_label is not None:
                message = f"{message}: function={cache_function_label}"
            if event != "clear":
                separator = " " if cache_function_label is not None else ": "
                message = f"{message}{separator}key={formatted_key}"
            message = f"[{self._name}] {message}"
            self._logger.log(
                self._log_level,
                message,
                extra={
                    "cache_event": event,
                    "cache_function": cache_function,
                    "cache_key": formatted_key,
                    "cache_name": self._name,
                },
            )


class BaseCacheManager(CacheManager[K, V], Generic[K, V]):
    """Base class for concrete cache managers.

    Args:
        inner: Mutable mapping used as the backing cache.
        logger: Logger used for cache events. If omitted, the root logger is
            used by ``LoggedCache``.
        log_level: Logging level used for emitted cache events.
        key_formatter: Callable used to convert cache keys into log-safe text.
        on_event: Optional callback invoked for every cache event.
        name: Human-readable cache name used in log messages.
    """

    def __init__(
        self,
        inner: MutableMapping[K, V],
        *,
        logger: logging.Logger | None = None,
        log_level: int = logging.DEBUG,
        key_formatter: KeyFormatter = default_key_formatter,
        on_event: EventHook | None = None,
        name: str | None = None,
    ) -> None:
        self.stats = CacheStats()
        self.cache = LoggedCache(
            inner,
            logger=logger,
            log_level=log_level,
            stats=self.stats,
            key_formatter=key_formatter,
            on_event=on_event,
            name=name,
        )
        self.lock = RLock()

    @property
    def name(self) -> str:
        """Return the human-readable cache name.

        Returns:
            Cache name used by the wrapped ``LoggedCache``.
        """
        return self.cache.name

    def set_name(self, name: str, *, replace: bool = False) -> None:
        """Set the human-readable cache name.

        Args:
            name: New cache name to use in log messages.
            replace: Whether to replace an explicitly configured name.
        """
        self.cache.set_name(name, replace=replace)

    def clear(self) -> None:
        """Clear the cache while holding the manager lock."""
        with self.lock:
            self.cache.clear()


class BaseAsyncCacheManager(AsyncCacheManager[K, V], Generic[K, V]):
    """Base class for concrete async cache managers.

    Args:
        inner: Mutable mapping used as the backing cache.
        logger: Logger used for cache events. If omitted, the root logger is
            used by ``LoggedCache``.
        log_level: Logging level used for emitted cache events.
        key_formatter: Callable used to convert cache keys into log-safe text.
        on_event: Optional callback invoked for every cache event.
        name: Human-readable cache name used in log messages.
    """

    def __init__(
        self,
        inner: MutableMapping[K, V],
        *,
        logger: logging.Logger | None = None,
        log_level: int = logging.DEBUG,
        key_formatter: KeyFormatter = default_key_formatter,
        on_event: EventHook | None = None,
        name: str | None = None,
    ) -> None:
        self.stats = CacheStats()
        self.cache = LoggedCache(
            inner,
            logger=logger,
            log_level=log_level,
            stats=self.stats,
            key_formatter=key_formatter,
            on_event=on_event,
            name=name,
        )
        self.lock = asyncio.Lock()

    @property
    def name(self) -> str:
        """Return the human-readable cache name.

        Returns:
            Cache name used by the wrapped ``LoggedCache``.
        """
        return self.cache.name

    def set_name(self, name: str, *, replace: bool = False) -> None:
        """Set the human-readable cache name.

        Args:
            name: New cache name to use in log messages.
            replace: Whether to replace an explicitly configured name.
        """
        self.cache.set_name(name, replace=replace)

    async def clear(self) -> None:
        """Clear the cache while holding the async manager lock."""
        async with self.lock:
            self.cache.clear()


class LRUCacheManager(BaseCacheManager[K, V]):
    """Thread-safe manager for a least-recently-used cache.

    Args:
        maxsize: Maximum cache size accepted by ``cachetools.LRUCache``.
        logger: Logger used for cache events. If omitted, the root logger is
            used.
        log_level: Logging level used for emitted cache events.
        getsizeof: Optional size callback accepted by ``cachetools.LRUCache``.
        key_formatter: Callable used to convert cache keys into log-safe text.
        on_event: Optional callback invoked for every cache event.
        name: Human-readable cache name used in log messages.
    """

    def __init__(
        self,
        maxsize: int,
        *,
        logger: logging.Logger | None = None,
        log_level: int = logging.DEBUG,
        getsizeof: Callable[[V], int] | None = None,
        key_formatter: KeyFormatter = default_key_formatter,
        on_event: EventHook | None = None,
        name: str | None = None,
    ) -> None:
        inner: Cache[K, V] = LRUCache(maxsize=maxsize, getsizeof=getsizeof)
        super().__init__(
            inner,
            logger=logger,
            log_level=log_level,
            key_formatter=key_formatter,
            on_event=on_event,
            name=name,
        )


class AsyncLRUCacheManager(BaseAsyncCacheManager[K, V]):
    """Async-lock manager for a least-recently-used cache.

    Args:
        maxsize: Maximum cache size accepted by ``cachetools.LRUCache``.
        logger: Logger used for cache events. If omitted, the root logger is
            used.
        log_level: Logging level used for emitted cache events.
        getsizeof: Optional size callback accepted by ``cachetools.LRUCache``.
        key_formatter: Callable used to convert cache keys into log-safe text.
        on_event: Optional callback invoked for every cache event.
        name: Human-readable cache name used in log messages.
    """

    def __init__(
        self,
        maxsize: int,
        *,
        logger: logging.Logger | None = None,
        log_level: int = logging.DEBUG,
        getsizeof: Callable[[V], int] | None = None,
        key_formatter: KeyFormatter = default_key_formatter,
        on_event: EventHook | None = None,
        name: str | None = None,
    ) -> None:
        inner: Cache[K, V] = LRUCache(maxsize=maxsize, getsizeof=getsizeof)
        super().__init__(
            inner,
            logger=logger,
            log_level=log_level,
            key_formatter=key_formatter,
            on_event=on_event,
            name=name,
        )


class TTLCacheManager(BaseCacheManager[K, V]):
    """Thread-safe manager for a time-to-live cache.

    Args:
        maxsize: Maximum cache size accepted by ``cachetools.TTLCache``.
        ttl: Time-to-live value for each cache item.
        logger: Logger used for cache events. If omitted, the root logger is
            used.
        log_level: Logging level used for emitted cache events.
        timer: Optional timer callable accepted by ``cachetools.TTLCache``.
        getsizeof: Optional size callback accepted by ``cachetools.TTLCache``.
        key_formatter: Callable used to convert cache keys into log-safe text.
        on_event: Optional callback invoked for every cache event.
        name: Human-readable cache name used in log messages.
    """

    def __init__(
        self,
        maxsize: int,
        ttl: float,
        *,
        logger: logging.Logger | None = None,
        log_level: int = logging.DEBUG,
        timer: Callable[[], float] | None = None,
        getsizeof: Callable[[V], int] | None = None,
        key_formatter: KeyFormatter = default_key_formatter,
        on_event: EventHook | None = None,
        name: str | None = None,
    ) -> None:
        if timer is None:
            inner: Cache[K, V] = TTLCache[K, V](
                maxsize=maxsize,
                ttl=ttl,
                getsizeof=getsizeof,
            )
        else:
            inner = TTLCache[K, V](
                maxsize=maxsize,
                ttl=ttl,
                timer=timer,
                getsizeof=getsizeof,
            )
        super().__init__(
            inner,
            logger=logger,
            log_level=log_level,
            key_formatter=key_formatter,
            on_event=on_event,
            name=name,
        )


class AsyncTTLCacheManager(BaseAsyncCacheManager[K, V]):
    """Async-lock manager for a time-to-live cache.

    Args:
        maxsize: Maximum cache size accepted by ``cachetools.TTLCache``.
        ttl: Time-to-live value for each cache item.
        logger: Logger used for cache events. If omitted, the root logger is
            used.
        log_level: Logging level used for emitted cache events.
        timer: Optional timer callable accepted by ``cachetools.TTLCache``.
        getsizeof: Optional size callback accepted by ``cachetools.TTLCache``.
        key_formatter: Callable used to convert cache keys into log-safe text.
        on_event: Optional callback invoked for every cache event.
        name: Human-readable cache name used in log messages.
    """

    def __init__(
        self,
        maxsize: int,
        ttl: float,
        *,
        logger: logging.Logger | None = None,
        log_level: int = logging.DEBUG,
        timer: Callable[[], float] | None = None,
        getsizeof: Callable[[V], int] | None = None,
        key_formatter: KeyFormatter = default_key_formatter,
        on_event: EventHook | None = None,
        name: str | None = None,
    ) -> None:
        if timer is None:
            inner: Cache[K, V] = TTLCache[K, V](
                maxsize=maxsize,
                ttl=ttl,
                getsizeof=getsizeof,
            )
        else:
            inner = TTLCache[K, V](
                maxsize=maxsize,
                ttl=ttl,
                timer=timer,
                getsizeof=getsizeof,
            )
        super().__init__(
            inner,
            logger=logger,
            log_level=log_level,
            key_formatter=key_formatter,
            on_event=on_event,
            name=name,
        )
