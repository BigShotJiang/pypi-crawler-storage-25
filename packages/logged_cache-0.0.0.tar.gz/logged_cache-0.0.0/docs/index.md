# logged-cache

`logged-cache` adds observability to `cachetools` caches while staying close to
the mapping interface that `cachetools.cached` already expects.

## Basic Use

```python
import logging

from logged_cache import LRUCacheManager, cached, cachedmethod

cache = LRUCacheManager(maxsize=100, logger=logging.getLogger("cache"))


@cached(cache)
def expensive(value: int) -> int:
    return value * 2
```

## Method Caching

```python
class Calculator:
    cache = LRUCacheManager(maxsize=100)

    @cachedmethod(cache)
    def double(self, value: int) -> int:
        return value * 2
```

`cachedmethod` uses `cachetools.keys.methodkey` by default, so `self` or `cls`
is not part of the cache key.

The first call is a miss and stores the value. Later calls with the same key are
hits.

## Async Caching

Regular managers work with async functions through `cached`. Async-only
applications can use async managers and decorators backed by `asyncio.Lock`.

```python
from logged_cache import AsyncLRUCacheManager, async_cached

cache = AsyncLRUCacheManager(maxsize=100)


@async_cached(cache)
async def expensive(value: int) -> int:
    return value * 2
```

## Choosing a Manager

Use `LRUCacheManager` when you want a fixed-size cache where the least recently
used values are evicted first.

Use `TTLCacheManager` when cached values should expire after a number of
seconds.

Use `AsyncLRUCacheManager` and `AsyncTTLCacheManager` when cache operations
should be guarded by an async lock.

```python
from logged_cache import TTLCacheManager

cache = TTLCacheManager(maxsize=500, ttl=60)
```

## Stats and Hooks

Each manager exposes `stats`.

```python
cache.stats.hits
cache.stats.misses
cache.stats.hit_rate
cache.stats.reset()
```

For external metrics, pass `on_event`.

```python
def on_event(event, key):
    metrics.increment(f"cache.{event}")
```

## Key Formatting

Use `key_formatter` to prevent sensitive data from appearing in logs.

```python
cache = LRUCacheManager(maxsize=100, key_formatter=lambda key: "<hidden>")
```
