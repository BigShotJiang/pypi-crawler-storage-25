"""Tests for logged_cache behavior."""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Hashable

import pytest
from cachetools import LRUCache

from logged_cache import (
    AsyncLRUCacheManager,
    LoggedCache,
    LRUCacheManager,
    TTLCacheManager,
    async_cached,
    async_cachedmethod,
    cached,
    cachedmethod,
    format_cache_key,
)


def test_logged_cache_records_hit_miss_and_logs(caplog: pytest.LogCaptureFixture) -> None:
    """Verify item access records hit and miss events in logs and stats."""
    logger = logging.getLogger("tests.cache")
    cache: LoggedCache[str, int] = LoggedCache(
        LRUCache(maxsize=2),
        logger=logger,
        name="answers",
    )
    cache["answer"] = 42

    with caplog.at_level(logging.DEBUG, logger="tests.cache"):
        assert cache["answer"] == 42
        with pytest.raises(KeyError):
            _ = cache["missing"]

    assert cache.stats.hits == 1
    assert cache.stats.misses == 1
    assert cache.stats.sets == 1
    assert "[answers] Cache hit: key='answer'" in caplog.text
    assert "[answers] Cache miss: key='missing'" in caplog.text
    assert caplog.records[0].__dict__["cache_event"] == "hit"
    assert caplog.records[0].__dict__["cache_key"] == "'answer'"
    assert caplog.records[0].__dict__["cache_name"] == "answers"


def test_contains_records_lookup_events() -> None:
    """Verify membership checks record lookup events."""
    cache: LoggedCache[str, int] = LoggedCache(LRUCache(maxsize=2))
    cache["a"] = 1

    assert "a" in cache
    assert "b" not in cache
    assert cache.stats.hits == 1
    assert cache.stats.misses == 1


def test_logged_cache_uses_root_logger_by_default(caplog: pytest.LogCaptureFixture) -> None:
    """Verify a root logger is used when no logger is provided."""
    cache: LoggedCache[str, int] = LoggedCache(LRUCache(maxsize=2))

    with caplog.at_level(logging.DEBUG):
        cache["a"] = 1

    assert "[logged-cache] Cache set: key='a'" in caplog.text


def test_cached_decorator_names_default_cache_from_function(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Verify decorators provide a readable fallback cache name."""
    logger = logging.getLogger("tests.named")
    manager: LRUCacheManager[Hashable, int] = LRUCacheManager(maxsize=10, logger=logger)

    @cached(manager)
    def double(value: int) -> int:
        """Return twice the provided value."""
        return value * 2

    with caplog.at_level(logging.DEBUG, logger="tests.named"):
        assert double(21) == 42

    assert manager.name == f"{double.__module__}.{double.__qualname__}"
    assert f"[{manager.name}] Cache miss: function={double.__qualname__} key=(21,)" in caplog.text
    assert caplog.records[0].__dict__["cache_name"] == manager.name
    assert caplog.records[0].__dict__["cache_function"] == (
        f"{double.__module__}.{double.__qualname__}"
    )


def test_explicit_cache_name_is_not_replaced_by_decorator() -> None:
    """Verify explicit cache names are kept when decorators are applied."""
    manager: LRUCacheManager[Hashable, int] = LRUCacheManager(
        maxsize=10,
        name="users-by-id",
    )

    @cached(manager)
    def load_user(user_id: int) -> int:
        """Return a user identifier."""
        return user_id

    assert load_user(1) == 1
    assert manager.name == "users-by-id"


def test_manager_clear_uses_lock_and_records_clear() -> None:
    """Verify manager clear removes values and updates clear stats."""
    manager: LRUCacheManager[str, int] = LRUCacheManager(maxsize=2)
    manager.cache["a"] = 1

    manager.clear()

    assert len(manager.cache) == 0
    assert manager.stats.clears == 1


def test_cached_decorator_caches_function_calls() -> None:
    """Verify the decorator caches synchronous function results."""
    manager: LRUCacheManager[Hashable, int] = LRUCacheManager(maxsize=10)
    calls = 0

    @cached(manager)
    def double(value: int) -> int:
        """Return twice the provided value."""
        nonlocal calls
        calls += 1
        return value * 2

    assert double(21) == 42
    assert double(21) == 42
    assert calls == 1
    assert manager.stats.misses == 1
    assert manager.stats.hits == 1
    assert manager.stats.sets == 1


def test_cached_sync_cache_clear_logs_function_name(caplog: pytest.LogCaptureFixture) -> None:
    """Verify sync cache clear logs include function context."""
    logger = logging.getLogger("tests.clear")
    manager: LRUCacheManager[Hashable, int] = LRUCacheManager(maxsize=10, logger=logger)

    @cached(manager)
    def double(value: int) -> int:
        """Return twice the provided value."""
        return value * 2

    double(21)

    with caplog.at_level(logging.DEBUG, logger="tests.clear"):
        double.cache_clear()  # type: ignore[attr-defined]

    assert f"Cache cleared: function={double.__qualname__}" in caplog.text
    assert caplog.records[0].__dict__["cache_function"] == (
        f"{double.__module__}.{double.__qualname__}"
    )


def test_cached_decorator_caches_async_function_calls() -> None:
    """Verify the decorator caches awaited async function results."""
    manager: LRUCacheManager[Hashable, int] = LRUCacheManager(maxsize=10)
    calls = 0

    @cached(manager)
    async def double(value: int) -> int:
        """Return twice the provided value asynchronously."""
        nonlocal calls
        calls += 1
        await asyncio.sleep(0)
        return value * 2

    async def run() -> None:
        """Run the async cache assertions."""
        assert await double(21) == 42
        assert await double(21) == 42

    asyncio.run(run())

    assert calls == 1
    assert manager.stats.misses == 1
    assert manager.stats.hits == 1
    assert manager.stats.sets == 1


def test_cached_async_wrapper_exposes_info_and_clear() -> None:
    """Verify async wrappers expose cache info and clear helpers."""
    manager: LRUCacheManager[Hashable, int] = LRUCacheManager(maxsize=10)

    @cached(manager, info=True)
    async def double(value: int) -> int:
        """Return twice the provided value asynchronously."""
        return value * 2

    async def run() -> None:
        """Run async cache info assertions."""
        assert await double(21) == 42
        assert await double(21) == 42
        assert double.cache_info() == (1, 1, 10, 1)  # type: ignore[attr-defined]
        double.cache_clear()  # type: ignore[attr-defined]
        assert double.cache_info() == (0, 0, 10, 0)  # type: ignore[attr-defined]

    asyncio.run(run())


def test_async_cache_manager_caches_async_function_calls() -> None:
    """Verify async-only managers use async locks for async functions."""
    manager: AsyncLRUCacheManager[Hashable, int] = AsyncLRUCacheManager(maxsize=10)
    calls = 0

    @async_cached(manager, info=True)
    async def double(value: int) -> int:
        """Return twice the provided value asynchronously."""
        nonlocal calls
        calls += 1
        await asyncio.sleep(0)
        return value * 2

    async def run() -> None:
        """Run async manager cache assertions."""
        assert await double(21) == 42
        assert await double(21) == 42
        assert double.cache_info() == (1, 1, 10, 1)  # type: ignore[attr-defined]
        await double.cache_clear()  # type: ignore[attr-defined]
        assert double.cache_info() == (0, 0, 10, 0)  # type: ignore[attr-defined]

    asyncio.run(run())

    assert calls == 1
    assert manager.stats.misses == 1
    assert manager.stats.hits == 1
    assert manager.stats.clears == 1


def test_cachedmethod_caches_instance_method_calls() -> None:
    """Verify cachedmethod caches calls without including self in the key."""
    manager: LRUCacheManager[Hashable, int] = LRUCacheManager(maxsize=10)

    class Calculator:
        """Calculator used to verify instance method caching."""

        calls = 0

        @cachedmethod(manager)
        def double(self, value: int) -> int:
            """Return twice the provided value."""
            self.calls += 1
            return value * 2

    first = Calculator()
    second = Calculator()

    assert first.double(21) == 42
    assert second.double(21) == 42
    assert first.calls == 1
    assert second.calls == 0
    assert manager.stats.misses == 1
    assert manager.stats.hits == 1


def test_cachedmethod_caches_async_instance_method_calls() -> None:
    """Verify cachedmethod supports asynchronous instance methods."""
    manager: LRUCacheManager[Hashable, int] = LRUCacheManager(maxsize=10)

    class AsyncCalculator:
        """Calculator used to verify async instance method caching."""

        def __init__(self) -> None:
            """Initialize call counters."""
            self.calls = 0

        @cachedmethod(manager)
        async def double(self, value: int) -> int:
            """Return twice the provided value asynchronously."""
            self.calls += 1
            await asyncio.sleep(0)
            return value * 2

    calculator = AsyncCalculator()

    async def run() -> None:
        """Run the async method cache assertions."""
        assert await calculator.double(21) == 42
        assert await calculator.double(21) == 42

    asyncio.run(run())

    assert calculator.calls == 1
    assert manager.stats.misses == 1
    assert manager.stats.hits == 1


def test_async_cachedmethod_caches_async_instance_method_calls() -> None:
    """Verify async_cachedmethod supports async-only cache managers."""
    manager: AsyncLRUCacheManager[Hashable, int] = AsyncLRUCacheManager(maxsize=10)

    class AsyncCalculator:
        """Calculator used to verify async cachedmethod behavior."""

        def __init__(self) -> None:
            """Initialize call counters."""
            self.calls = 0

        @async_cachedmethod(manager)
        async def double(self, value: int) -> int:
            """Return twice the provided value asynchronously."""
            self.calls += 1
            await asyncio.sleep(0)
            return value * 2

    calculator = AsyncCalculator()

    async def run() -> None:
        """Run the async method cache assertions."""
        assert await calculator.double(21) == 42
        assert await calculator.double(21) == 42

    asyncio.run(run())

    assert calculator.calls == 1
    assert manager.stats.misses == 1
    assert manager.stats.hits == 1


def test_cached_decorator_returns_uncached_value_when_value_is_too_large() -> None:
    """Verify oversized values are returned and not stored."""
    manager: LRUCacheManager[Hashable, str] = LRUCacheManager(
        maxsize=1,
        getsizeof=len,
    )
    calls = 0

    @cached(manager)
    def load(value: str) -> str:
        """Return a value too large for the configured cache."""
        nonlocal calls
        calls += 1
        return value

    assert load("too-large") == "too-large"
    assert load("too-large") == "too-large"
    assert calls == 2
    assert len(manager.cache) == 0


def test_async_cached_returns_uncached_value_when_value_is_too_large() -> None:
    """Verify oversized async values are returned and not stored."""
    manager: AsyncLRUCacheManager[Hashable, str] = AsyncLRUCacheManager(
        maxsize=1,
        getsizeof=len,
    )
    calls = 0

    @async_cached(manager)
    async def load(value: str) -> str:
        """Return a value too large for the configured cache."""
        nonlocal calls
        calls += 1
        return value

    async def run() -> None:
        """Run async oversized value assertions."""
        assert await load("too-large") == "too-large"
        assert await load("too-large") == "too-large"

    asyncio.run(run())

    assert calls == 2
    assert len(manager.cache) == 0


def test_ttl_cache_expires_values() -> None:
    """Verify TTL caches expire values and record repeated misses."""
    manager: TTLCacheManager[Hashable, int] = TTLCacheManager(maxsize=10, ttl=0.01)
    calls = 0

    @cached(manager)
    def value() -> int:
        """Return an incrementing value for TTL cache assertions."""
        nonlocal calls
        calls += 1
        return calls

    assert value() == 1
    time.sleep(0.02)
    assert value() == 2
    assert manager.stats.misses == 2


def test_key_formatter_and_event_hook_are_used(caplog: pytest.LogCaptureFixture) -> None:
    """Verify custom key formatters and event hooks receive cache events."""
    events: list[tuple[str, object]] = []
    logger = logging.getLogger("tests.redacted")
    manager: LRUCacheManager[str, int] = LRUCacheManager(
        maxsize=2,
        logger=logger,
        key_formatter=lambda key: "<hidden>",
        on_event=lambda event, key: events.append((event, key)),
    )

    with caplog.at_level(logging.DEBUG, logger="tests.redacted"):
        manager.cache["secret"] = 1
        assert manager.cache["secret"] == 1

    assert events == [("set", "secret"), ("hit", "secret")]
    assert "secret" not in caplog.text
    assert "[logged-cache] Cache set: key=<hidden>" in caplog.text
    assert "key=<hidden>" in caplog.text
    assert caplog.records[0].__dict__["cache_event"] == "set"
    assert caplog.records[0].__dict__["cache_key"] == "<hidden>"


def test_default_key_formatter_truncates_large_keys() -> None:
    """Verify default key formatting prevents oversized log payloads."""
    formatted = format_cache_key("x" * 1000, max_length=40)

    assert len(formatted) == 40
    assert formatted.endswith("...<truncated>")


def test_default_key_formatter_describes_plain_objects() -> None:
    """Verify default key formatting avoids memory addresses for objects."""

    class Query:
        """Query object without a custom representation."""

    formatted = format_cache_key(Query())

    assert formatted == (
        "<test_logged_cache.test_default_key_formatter_describes_plain_objects.<locals>.Query>"
    )
    assert "object at 0x" not in formatted


def test_default_key_formatter_handles_broken_repr() -> None:
    """Verify key formatting survives objects with broken repr methods."""

    class BrokenRepr:
        """Object with a representation that raises."""

        def __repr__(self) -> str:
            """Raise during representation."""
            raise RuntimeError("boom")

    assert format_cache_key(BrokenRepr()).endswith(".BrokenRepr>")


def test_cache_stats_reset_and_hit_rate() -> None:
    """Verify cache stats compute and reset lookup counters."""
    manager: LRUCacheManager[str, int] = LRUCacheManager(maxsize=2)
    manager.cache["a"] = 1
    assert manager.cache["a"] == 1
    with pytest.raises(KeyError):
        _ = manager.cache["b"]

    assert manager.stats.lookups == 2
    assert manager.stats.hit_rate == 0.5
    manager.stats.reset()
    assert manager.stats.lookups == 0
    assert manager.stats.hit_rate == 0.0
