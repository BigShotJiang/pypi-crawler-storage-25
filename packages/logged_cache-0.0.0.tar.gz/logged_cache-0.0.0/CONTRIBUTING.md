# Contributing

## Setup

```bash
uv sync --extra dev --extra docs
```

Without `uv`:

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e ".[dev,docs]"
```

## Checks

```bash
ruff check .
mypy
pytest
python -m build
twine check dist/*
```

## Releases

Releases are automated with Python Semantic Release and Conventional Commits.
Pushes to `main` are analyzed and a release is created only when commits require
one:

- `fix: ...` creates a patch release.
- `feat: ...` creates a minor release.
- `feat!: ...` or a `BREAKING CHANGE:` footer creates a major release.

Release commits are generated as `chore(release): <version> [skip ci]`.

Please keep changes focused and include tests for behavior changes.
