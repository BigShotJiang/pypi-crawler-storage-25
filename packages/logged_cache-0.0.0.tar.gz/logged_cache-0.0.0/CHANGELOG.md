# Changelog

<!-- version list -->

## v0.0.0 (2026-05-23)

- Initial Release

## 0.1.0

- Initial package structure.
- Added `LoggedCache`, `LRUCacheManager`, `TTLCacheManager`, stats, hooks, and
  decorator helpers.
- Added tests, documentation, and GitHub Actions workflows.
