# Security Policy

Please do not open public issues for suspected security vulnerabilities.

Report privately by contacting the package maintainer. Include a minimal
reproduction, affected versions, and any known mitigations.
