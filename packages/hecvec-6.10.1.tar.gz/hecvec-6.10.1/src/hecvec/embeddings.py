"""
Embeddings: OpenAI (by model name) or local GloVe (see glove_embeddings).
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from openai import OpenAI

DEFAULT_MODEL = "text-embedding-3-small"
DEFAULT_BATCH_SIZE = 100
EmbeddingProvider = Literal["openai", "glove"]


def infer_embedding_provider(embedding_model: str) -> EmbeddingProvider:
    """
    Map an embedding model id to the API provider. Callers only need ``embedding_model``;
    this picks OpenAI for known OpenAI embedding model names.

    Raises ValueError if the name is not recognized (or looks like a non-OpenAI model).
    """
    m = embedding_model.strip().lower()
    if not m:
        raise ValueError("embedding_model must be a non-empty string.")
    from hecvec.glove_embeddings import is_known_glove_model

    if is_known_glove_model(embedding_model):
        return "glove"
    # Google / Gemini-style ids (not auto-routed to OpenAI here)
    if "gemini" in m or m == "text-embedding-004":
        raise ValueError(
            f"embedding_model={embedding_model!r} looks like a Google/Gemini embedding. "
            "This release only auto-routes OpenAI embedding models (e.g. 'text-embedding-3-small')."
        )
    if (
        m.startswith("text-embedding-")
        or m.startswith("text-search-")
        or m.startswith("text-similarity-")
    ):
        return "openai"
    raise ValueError(
        f"Unknown embedding_model={embedding_model!r}. "
        "Recognized OpenAI names typically start with 'text-embedding-' "
        "(e.g. 'text-embedding-3-small', 'text-embedding-ada-002')."
    )


def _get_openai_client(api_key: str | None = None) -> "OpenAI":
    from openai import OpenAI
    if not api_key:
        raise ValueError("api_key is required for embeddings")
    return OpenAI(api_key=api_key)


def embed_texts_openai(
    texts: list[str],
    *,
    api_key: str,
    model: str = DEFAULT_MODEL,
    batch_size: int = DEFAULT_BATCH_SIZE,
) -> list[list[float]]:
    """Embed a list of text strings with OpenAI."""
    client = _get_openai_client(api_key)
    out: list[list[float]] = []
    for start in range(0, len(texts), batch_size):
        batch = texts[start : start + batch_size]
        response = client.embeddings.create(model=model, input=batch)
        out.extend([item.embedding for item in response.data])
    return out


def embed_texts(
    texts: list[str],
    *,
    api_key: str | None = None,
    embedding_model: str | None = None,
    batch_size: int = DEFAULT_BATCH_SIZE,
    llm_model: str | None = None,
    model: str | None = None,
) -> list[list[float]]:
    """
    Embed texts. Provider is inferred from the model name.

    Accepts ``embedding_model`` (preferred), or ``llm_model``, or ``model`` as aliases.
    GloVe models (e.g. ``glove-6B-50d``) do not use ``api_key``; vectors cache under ``~/.slicer/models``.
    """
    resolved_model = embedding_model or llm_model or model or DEFAULT_MODEL
    provider = infer_embedding_provider(resolved_model)
    if provider == "openai":
        if not api_key:
            raise ValueError(
                "api_key is required for OpenAI embeddings. "
                "Pass llm_token=... / openai_api_key=... or set OPENAI_API_KEY."
            )
        return embed_texts_openai(
            texts,
            api_key=api_key,
            model=resolved_model,
            batch_size=batch_size,
        )
    if provider == "glove":
        from hecvec.glove_embeddings import embed_texts_glove

        return embed_texts_glove(texts, model=resolved_model)
    raise ValueError(f"Unsupported embedding provider: {provider!r}")
