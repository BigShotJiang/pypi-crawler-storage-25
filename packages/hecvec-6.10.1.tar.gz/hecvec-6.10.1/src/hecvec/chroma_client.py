"""
Chroma client and collection operations. One module = one responsibility: connect and add documents.
Requires: pip install hecvec (chromadb). Connects only to a Chroma server; server must be running.
"""
from __future__ import annotations

import logging
import os
import socket
import base64
import re
from time import perf_counter
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000

logger = logging.getLogger(__name__)

DEFAULT_ADD_BATCH_SIZE = 250


def _is_port_listening(host: str, port: int, timeout: float = 2.0) -> bool:
    """Return True if something is listening on host:port."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, socket.error):
        return False


def get_client(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    *,
    user: str | None = None,
    password: str | None = None,
):
    """
    Return a Chroma HttpClient connected to the server at host:port.
    Raises RuntimeError if nothing is listening. A Chroma server must be running.

    Auth options:
    - Pass user=... and password=... and we will build auth as "user:password".
    """
    import chromadb
    from chromadb.config import Settings
    logger.info("[5/5] Checking connectivity to %s:%s...", host, port)
    if not _is_port_listening(host, port):
        logger.error("[5/5] Nothing is listening at %s:%s", host, port)
        raise RuntimeError(
            f"Nothing is listening on {host}:{port}. A Chroma server is required. "
            f"Start one with: docker run -p 8000:8000 -v ./chroma-data:/chroma/chroma chromadb/chroma"
        )
    logger.info("[5/5] Port is open at %s:%s; verifying this is a Chroma server...", host, port)
    auth = None
    if user is not None or password is not None:
        if not user or not password:
            raise ValueError("Provide both user and password, or neither.")
        auth = f"{user}:{password}"

    headers = None
    if auth:
        # Standard HTTP Basic Auth header. This works when Chroma is deployed behind a reverse proxy
        # that enforces Basic Auth, and keeps auth transport consistent across future DB backends.
        basic = base64.b64encode(auth.encode("utf-8")).decode("utf-8")
        headers = {"Authorization": f"Basic {basic}"}

    settings = None
    if auth:
        settings = Settings(
            chroma_client_auth_provider="chromadb.auth.basic_authn.BasicAuthClientProvider",
            chroma_client_auth_credentials=auth,
        )
    client = chromadb.HttpClient(host=host, port=port, headers=headers, settings=settings)
    # Verify this is actually a working Chroma server (not just an open port).
    try:
        if hasattr(client, "heartbeat"):
            client.heartbeat()  # type: ignore[attr-defined]
        else:
            client.list_collections()
        logger.info("[5/5] Chroma server verified at %s:%s", host, port)
    except Exception as e:
        raise RuntimeError(
            f"Connected to {host}:{port} but Chroma health check failed. "
            f"This usually means the port is open but it is not a Chroma server, "
            f"or Basic Auth credentials are required/incorrect. Original error: {e!r}"
        ) from e
    return client


def get_cloud_client(*, api_key: str | None, tenant: str | None = None, database: str | None = None):
    """
    Return a Chroma Cloud client.

    Chroma Cloud uses API keys (not host/port + basic auth). The Chroma Python client exposes this
    via chromadb.CloudClient(...).
    """
    if not api_key:
        raise ValueError("chroma_cloud_api_key is required when db='chroma_cloud'")
    import chromadb
    if tenant is None and database is None:
        return chromadb.CloudClient(api_key=api_key)
    # If either is provided, require both for clarity.
    if not tenant or not database:
        raise ValueError("Provide both chroma_cloud_tenant and chroma_cloud_database, or neither.")
    return chromadb.CloudClient(api_key=api_key, tenant=tenant, database=database)


def get_or_create_collection(
    client: "chromadb.api.client.Client",
    name: str,
    metadata: dict | None = None,
):
    """Get or create a collection (cosine similarity by default)."""
    if metadata is None:
        metadata = {"hnsw:space": "cosine"}
    return client.get_or_create_collection(name=name, metadata=metadata)


def add_documents(
    client: "chromadb.api.client.Client",
    collection_name: str,
    ids: list[str],
    embeddings: list[list[float]],
    documents: list[str],
    *,
    add_batch_size: int = DEFAULT_ADD_BATCH_SIZE,
) -> dict:
    """
    Add documents to a collection. If dimension mismatch, deletes and recreates the collection.
    Returns {"collection_existed": bool} so the caller can log whether the collection was pre-existing.
    """
    import chromadb
    if add_batch_size <= 0:
        raise ValueError("add_batch_size must be > 0")

    existing_names = [c.name for c in client.list_collections()]
    collection_existed = collection_name in existing_names
    coll = get_or_create_collection(client, collection_name)
    # IDs produced by chunking restart at chunk_0 for each run; namespace by write to avoid collisions.
    # Use os.urandom (not uuid) so minimal Python builds without the uuid stdlib module still work.
    write_prefix = os.urandom(16).hex()
    unique_ids = [f"{write_prefix}:{chunk_id}" for chunk_id in ids]

    resolved_batch_size = add_batch_size
    if hasattr(client, "get_max_batch_size"):
        max_batch_size = client.get_max_batch_size()
        # Respect server-side limits while keeping our default request size small.
        resolved_batch_size = min(add_batch_size, max_batch_size)

    def _extract_batch_limit(error_message: str) -> int | None:
        # Examples:
        # - "Batch size 23036 exceeds maximum batch size 1000"
        # - "current usage of 500 exceeds limit of 300"
        patterns = (
            r"maximum batch size\s+(\d+)",
            r"exceeds limit of\s+(\d+)",
        )
        for pattern in patterns:
            match = re.search(pattern, error_message, flags=re.IGNORECASE)
            if match:
                parsed = int(match.group(1))
                if parsed > 0:
                    return parsed
        return None

    def _add_in_batches(target_coll) -> None:
        current_batch_size = resolved_batch_size
        total = len(unique_ids)
        total_batches = (total + current_batch_size - 1) // current_batch_size
        inserted = 0
        batch_index = 0
        started = perf_counter()

        logger.info(
            "[6/6] Chroma add progress | total_records=%d | batch_size=%d | total_batches=%d",
            total,
            current_batch_size,
            total_batches,
        )

        start = 0
        while start < len(unique_ids):
            end = min(start + current_batch_size, len(unique_ids))
            batch_index += 1
            try:
                target_coll.add(
                    ids=unique_ids[start:end],
                    embeddings=embeddings[start:end],
                    documents=documents[start:end],
                )
                inserted += end - start
                should_log = (
                    batch_index == 1
                    or inserted == total
                    or batch_index % 10 == 0
                )
                if should_log:
                    pct = (inserted / total) * 100 if total else 100.0
                    logger.info(
                        "[6/6] Chroma add progress | batch=%d/%d | inserted=%d/%d (%.1f%%) | elapsed=%.2fs",
                        batch_index,
                        total_batches,
                        inserted,
                        total,
                        pct,
                        perf_counter() - started,
                    )
                start = end
            except Exception as e:
                maybe_limit = _extract_batch_limit(str(e))
                if maybe_limit is None or maybe_limit >= current_batch_size:
                    raise
                logger.warning(
                    "Chroma rejected add batch size=%d; retrying with size=%d",
                    current_batch_size,
                    maybe_limit,
                )
                current_batch_size = maybe_limit
                total_batches = (total + current_batch_size - 1) // current_batch_size

    try:
        _add_in_batches(coll)
    except chromadb.errors.InvalidArgumentError as e:
        if "dimension" not in str(e).lower():
            raise
        client.delete_collection(name=collection_name)
        coll = client.create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        _add_in_batches(coll)
        collection_existed = False  # we recreated it
    return {"collection_existed": collection_existed}
