"""
List collections/tables across supported vector backends.
One module = one responsibility: inspect backend collection counts.
Requires chromadb only for Chroma-based servers.
"""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

from hecvec.chroma_client import get_client, get_cloud_client
from hecvec.env import (
    load_chroma_cloud_database,
    load_chroma_cloud_key,
    load_chroma_cloud_tenant,
    require_pgvector_password,
)
from hecvec.pgvector_client import (
    DEFAULT_PGVECTOR_PORT,
    get_connection as get_pgvector_connection,
    list_collection_tables,
)

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000


def list_collections(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    *,
    user: str | None = None,
    password: str | None = None,
    server: str = "chroma",
    cloud_api_key: str | None = None,
    cloud_tenant: str | None = None,
    cloud_database: str | None = None,
    database: str | None = None,
    table_name: str | None = None,
    dotenv_path: str | Path | None = None,
) -> list[tuple[str, int]]:
    """
    List all collection names and their document counts.

    - Self-hosted Chroma: ``server="chroma"`` (default) — uses host:port (optional user/password).
    - Chroma Cloud: ``server="chroma_cloud"`` — API key and optional tenant/database; host/port are ignored.
    - pgvector: ``server="pgvector"`` — requires database/table_name; password from args or ``.env`` (see README).
    """
    backend = server
    if backend == "chroma_cloud":
        key = cloud_api_key or load_chroma_cloud_key(dotenv_path)
        tenant = cloud_tenant or load_chroma_cloud_tenant(dotenv_path)
        database = cloud_database or load_chroma_cloud_database(dotenv_path)
        client = get_cloud_client(api_key=key, tenant=tenant, database=database)
        return list_collections_from_client(client)
    if backend == "pgvector":
        if not database:
            raise ValueError("database is required when server='pgvector'")
        if not table_name:
            raise ValueError("table_name is required when server='pgvector'")
        eff_port = port
        if eff_port == 8000:
            eff_port = DEFAULT_PGVECTOR_PORT
        password = require_pgvector_password(password, dotenv_path=dotenv_path)
        pg_conn = get_pgvector_connection(
            host=host,
            port=eff_port,
            database=database,
            user=user,
            password=password,
        )
        try:
            return list_collection_tables(pg_conn, table_name_prefix=table_name)
        finally:
            pg_conn.close()

    if backend != "chroma":
        raise ValueError(f"Unsupported server={backend!r}. Use 'chroma', 'chroma_cloud', or 'pgvector'.")
    client = get_client(host=host, port=port, user=user, password=password)
    return list_collections_from_client(client)


def list_collections_from_client(client: "chromadb.api.client.Client") -> list[tuple[str, int]]:
    """
    List all collection names and their document counts from any Chroma client
    Returns [(name, count), ...].
    """
    return [(c.name, c.count()) for c in client.list_collections()]
