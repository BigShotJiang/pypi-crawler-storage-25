"""
hecvec: modular library — listdir, read, chunk (token/recursive), embed, Chroma. No API.
"""
from hecvec.chunking import chunk_documents, chunk_text
from hecvec.chroma_client import add_documents, get_client, get_or_create_collection
from hecvec.chunkers import ChunkingMethod, chunk_documents as chunk_documents_by_method
from hecvec.backend_list import list_collections
from hecvec.embeddings import embed_texts, infer_embedding_provider
from hecvec.env import load_dotenv_if_available, load_openai_key
from hecvec.listdir import ALLOWED_EXTENSIONS, ListDir, ListDirTextFiles
from hecvec.pipeline import DbType, Slicer
from hecvec.reading import ReadText
from hecvec.token_splitter import token_chunk_documents, token_chunk_text

__all__ = [
    "ALLOWED_EXTENSIONS",
    "ChunkingMethod",
    "DbType",
    "Slicer",
    "ListDir",
    "ListDirTextFiles",
    "ReadText",
    "add_documents",
    "chunk_documents",
    "chunk_documents_by_method",
    "chunk_text",
    "embed_texts",
    "embed_texts_glove",
    "infer_embedding_provider",
    "get_client",
    "get_or_create_collection",
    "list_collections",
    "load_dotenv_if_available",
    "load_openai_key",
    "token_chunk_documents",
    "token_chunk_text",
    "__version__",
]

__version__ = "6.10.1"


def __getattr__(name: str):
    """Lazy import so `from hecvec import Slicer` does not load GloVe/urllib on minimal Pythons."""
    if name == "embed_texts_glove":
        from hecvec.glove_embeddings import embed_texts_glove

        return embed_texts_glove
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
