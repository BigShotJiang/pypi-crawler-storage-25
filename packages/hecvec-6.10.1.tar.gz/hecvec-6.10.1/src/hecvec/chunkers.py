"""
Chunking methods in one place. Dispatches by chunking_method to token, text, semantic, or llm.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Literal

logger = logging.getLogger(__name__)

ChunkingMethod = Literal["token", "text", "semantic", "llm"]


def _token_count(text: str) -> int:
    from hecvec._recursive_chunking import openai_token_count
    return openai_token_count(text)


def chunk_documents(
    path_and_texts: list[tuple[str | Path, str]],
    method: ChunkingMethod = "token",
    *,
    chunk_size: int = 200,
    chunk_overlap: int = 0,
    encoding_name: str = "cl100k_base",
    separators: list[str] | None = None,
    openai_api_key: str | None = None,
    semantic_max_chunk_size: int = 400,
    semantic_min_chunk_size: int = 50,
    llm_model: str = "gpt-4o-mini",
) -> tuple[list[str], list[str]]:
    """
    Chunk documents using the given method. Returns (ids, documents).
    """
    logger.info("Chunking %d document(s) with method=%s", len(path_and_texts), method)
    if method == "token":
        logger.debug("Using token splitter (chunk_size=%s, overlap=%s)", chunk_size, chunk_overlap)
        from hecvec.token_splitter import token_chunk_documents
        ids, docs = token_chunk_documents(
            path_and_texts,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            encoding_name=encoding_name,
        )
        logger.info("Token chunking produced %d chunks", len(docs))
        return ids, docs
    if method == "text":
        logger.debug("Using recursive character splitter (chunk_size=%s, overlap=%s)", chunk_size, chunk_overlap)
        from hecvec.chunking import chunk_documents as char_chunk_documents
        out = char_chunk_documents(
            path_and_texts,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=separators,
        )
        ids = [f"chunk_{i}" for i in range(len(out))]
        documents = [o["content"] for o in out]
        logger.info("Text chunking produced %d chunks", len(documents))
        return ids, documents
    if method == "semantic":
        ids, documents = _semantic_chunk_documents(
            path_and_texts,
            openai_api_key=openai_api_key,
            max_chunk_size=semantic_max_chunk_size,
            min_chunk_size=semantic_min_chunk_size,
        )
        logger.info("Semantic chunking produced %d chunks", len(documents))
        return ids, documents
    if method == "llm":
        ids, documents = _llm_chunk_documents(
            path_and_texts,
            openai_api_key=openai_api_key,
            model_name=llm_model,
            chunk_size=chunk_size,
        )
        logger.info("LLM chunking produced %d chunks", len(documents))
        return ids, documents
    raise ValueError(f"Unknown chunking_method: {method!r}. Use one of: token, text, semantic, llm")


# ---- Semantic (embedding + DP) ----

def _small_chunks(text: str, min_size: int) -> list[str]:
    """Split text into small token-sized pieces (RecursiveTokenChunker from python/chunking)."""
    from hecvec._recursive_chunking import RecursiveTokenChunker
    splitter = RecursiveTokenChunker(
        chunk_size=min_size,
        chunk_overlap=0,
        separators=["\n\n", "\n", ".", "?", "!", " ", ""],
    )
    return [c for c in splitter.split_text(text) if c.strip()]


def _embed_batch(texts: list[str], api_key: str, model: str = "text-embedding-3-small") -> list[list[float]]:
    from hecvec.embeddings import embed_texts
    return embed_texts(
        texts,
        api_key=api_key,
        embedding_model=model,
        batch_size=min(500, len(texts)),
    )


def _similarity_matrix(embeddings: list[list[float]]) -> list[list[float]]:
    n = len(embeddings)
    return [
        [sum((a[k] or 0) * (b[k] or 0) for k in range(len(a))) for j, b in enumerate(embeddings)]
        for i, a in enumerate(embeddings)
    ]


def _reward(matrix: list[list[float]], start: int, end: int) -> float:
    return sum(matrix[i][j] for i in range(start, end + 1) for j in range(start, end + 1))


def _optimal_segmentation(matrix: list[list[float]], max_cluster: int) -> list[tuple[int, int]]:
    n = len(matrix)
    total, count = 0.0, 0
    for i in range(n):
        for j in range(i + 1, n):
            total += matrix[i][j]
            count += 1
    mean_val = total / count if count else 0.0
    norm = [
        [0.0 if i == j else matrix[i][j] - mean_val for j in range(n)]
        for i in range(n)
    ]
    dp = [0.0] * n
    seg_start = [0] * n
    for i in range(n):
        for size in range(1, min(max_cluster + 1, i + 2)):
            if i - size + 1 >= 0:
                r = _reward(norm, i - size + 1, i)
                prev = dp[i - size] if i - size >= 0 else 0.0
                if r + prev > dp[i]:
                    dp[i] = r + prev
                    seg_start[i] = i - size + 1
    clusters: list[tuple[int, int]] = []
    i = n - 1
    while i >= 0:
        s = seg_start[i]
        clusters.append((s, i))
        i = s - 1
    clusters.reverse()
    return clusters


def _semantic_chunk_documents(
    path_and_texts: list[tuple[str | Path, str]],
    *,
    openai_api_key: str | None = None,
    max_chunk_size: int = 400,
    min_chunk_size: int = 50,
) -> tuple[list[str], list[str]]:
    from hecvec.env import load_openai_key
    api_key = openai_api_key or load_openai_key()
    if not api_key:
        raise ValueError(
            "OPENAI_API_KEY required for semantic chunking. "
            "Set it in a .env file in your project root or pass openai_api_key=."
        )
    ids: list[str] = []
    documents: list[str] = []
    max_cluster = max(1, max_chunk_size // min_chunk_size)
    logger.debug("Semantic: max_chunk_size=%s, min_chunk_size=%s, max_cluster=%s", max_chunk_size, min_chunk_size, max_cluster)
    for _path, text in path_and_texts:
        if not text.strip():
            continue
        pieces = _small_chunks(text, min_chunk_size)
        if not pieces:
            continue
        logger.debug("Semantic: document has %d pieces, embedding...", len(pieces))
        emb = _embed_batch(pieces, api_key)
        matrix = _similarity_matrix(emb)
        clusters = _optimal_segmentation(matrix, max_cluster)
        logger.debug("Semantic: DP produced %d segment(s)", len(clusters))
        for s, e in clusters:
            doc = " ".join(pieces[s : e + 1]).strip()
            if doc:
                ids.append(f"chunk_{len(ids)}")
                documents.append(doc)
    return ids, documents


# ---- LLM (OpenAI chat for split points) ----

def _llm_small_chunks(text: str, size: int = 50) -> list[str]:
    """Initial small chunks for LLM chunker (RecursiveTokenChunker from python/chunking)."""
    from hecvec._recursive_chunking import RecursiveTokenChunker
    splitter = RecursiveTokenChunker(chunk_size=size, chunk_overlap=0)
    return [c for c in splitter.split_text(text) if c.strip()]


def _llm_get_splits(chunks: list[str], api_key: str, model: str) -> list[int]:
    """Ask OpenAI where to split; returns indices (0-based) after which to split."""
    from openai import OpenAI
    client = OpenAI(api_key=api_key)
    split_after: list[int] = []
    current = 0
    while current < max(0, len(chunks) - 4):
        token_count = 0
        buf: list[str] = []
        i = current
        while i < len(chunks):
            c = chunks[i] or ""
            token_count += _token_count(c)
            buf.append(f"<|start_chunk_{i + 1}|>{c}<|end_chunk_{i + 1}|>")
            i += 1
            if token_count > 800:
                break
        chunked_input = "".join(buf)
        system = (
            "You are an assistant that splits text into thematically consistent sections. "
            "The text has chunks marked with <|start_chunk_X|> and <|end_chunk_X|>. "
            "Respond with chunk IDs where a split should occur. Example: 'split_after: 3, 5'. "
            "Respond only with IDs in ascending order, at least one split."
        )
        user = f"CHUNKED_TEXT: {chunked_input}\n\nRespond with split_after: <ids>. IDs must be >= {current + 1}, ascending."
        numbers: list[int] = []
        for _ in range(3):
            try:
                r = client.chat.completions.create(
                    model=model,
                    max_tokens=200,
                    temperature=0.2,
                    messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
                )
                content = (r.choices[0].message.content or "").strip()
                line = next((l for l in content.split("\n") if "split_after" in l), "")
                numbers = [int(n) - 1 for n in re.findall(r"\d+", line) if int(n) >= 1]
                if numbers and all(n >= current for n in numbers):
                    split_after.extend(numbers)
                    current = numbers[-1]
                    break
            except Exception:
                continue
        if not numbers:
            break
    return sorted(set(split_after))


def _llm_chunk_documents(
    path_and_texts: list[tuple[str | Path, str]],
    *,
    openai_api_key: str | None = None,
    model_name: str = "gpt-4o-mini",
    chunk_size: int = 50,
) -> tuple[list[str], list[str]]:
    from hecvec.env import load_openai_key
    api_key = openai_api_key or load_openai_key()
    if not api_key:
        raise ValueError(
            "OPENAI_API_KEY required for llm chunking. "
            "Set it in a .env file in your project root or pass openai_api_key=."
        )
    logger.debug("LLM chunking: model=%s, initial chunk_size=%s", model_name, chunk_size)
    ids: list[str] = []
    documents: list[str] = []
    for _path, text in path_and_texts:
        if not text.strip():
            continue
        chunks = _llm_small_chunks(text, chunk_size)
        if not chunks:
            continue
        logger.debug("LLM: document has %d small chunks, asking model for split points...", len(chunks))
        split_indices = _llm_get_splits(chunks, api_key, model_name)
        start = 0
        for i in split_indices:
            if i <= start:
                continue
            doc = " ".join(chunks[start:i]).strip()
            if doc:
                ids.append(f"chunk_{len(ids)}")
                documents.append(doc)
            start = i
        if start < len(chunks):
            doc = " ".join(chunks[start:]).strip()
            if doc:
                ids.append(f"chunk_{len(ids)}")
                documents.append(doc)
    return ids, documents
