#!/usr/bin/env python3
"""
Run semantic chunking on .txt/.md files: embeddings + DP segmentation.
Consumes hecvec.chunkers.chunk_documents(method="semantic").
Requires OPENAI_API_KEY in .env or environment.

Usage:
  uv run python -m hecvec.run_semantic_chunk [path]
  python -m hecvec.run_semantic_chunk .
  python -m hecvec.run_semantic_chunk /path/to/file.txt
"""
import logging
import sys
from pathlib import Path

# Project root (parent of src/hecvec/)
ROOT = Path(__file__).resolve().parent.parent.parent


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    logger = logging.getLogger(__name__)

    path = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else ROOT
    logger.info("Path: %s", path)
    if not path.exists():
        logger.error("Path does not exist: %s", path)
        print(f"Error: path does not exist: {path}", file=sys.stderr)
        return 1
    from hecvec import ListDirTextFiles, ReadText
    from hecvec.chunkers import chunk_documents

    root = path.parent if path.is_file() else path
    lister = ListDirTextFiles(root=root)
    if path.is_file():
        if path.suffix.lower() not in (".txt", ".md"):
            logger.error("File must be .txt or .md: %s", path)
            print(f"Error: file must be .txt or .md: {path}", file=sys.stderr)
            return 1
        paths = [path]
        logger.info("Single file: %s", path.name)
    else:
        paths = lister.listdir_recursive_txt_md(path)
        logger.info("Found %d .txt/.md file(s)", len(paths))
    if not paths:
        logger.warning("No .txt/.md files found")
        print("No .txt/.md files found.", file=sys.stderr)
        return 0
    reader = ReadText(paths)
    path_and_text = reader.read_all()
    logger.info("Read %d file(s)", len(path_and_text))
    if not path_and_text:
        logger.warning("No content read")
        print("No content read.", file=sys.stderr)
        return 0
    ids, documents = chunk_documents(path_and_text, method="semantic")
    logger.info("Semantic chunks: %d", len(documents))
    print(f"Semantic chunks: {len(documents)}")
    for i, doc in enumerate(documents):
        preview = doc[:80].replace("\n", " ") + "..." if len(doc) > 80 else doc.replace("\n", " ")
        print(f"  [{i}] {preview}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
