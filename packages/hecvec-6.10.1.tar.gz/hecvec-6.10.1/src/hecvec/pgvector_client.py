"""
PostgreSQL pgvector client helpers.
"""
from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_PGVECTOR_PORT = 5432
DEFAULT_PGVECTOR_BATCH_SIZE = 100
_TABLE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _require_safe_name(name: str, *, field: str) -> str:
    if not _TABLE_RE.match(name):
        raise ValueError(
            f"Invalid {field}={name!r}. Must match /^[A-Za-z_][A-Za-z0-9_]*$/."
        )
    return name


def resolve_collection_table_name(base_table_name: str, collection_name: str) -> str:
    """
    Resolve the physical table name for pgvector writes.

    Current behavior uses ``table_name`` as-is (no automatic collection suffixing).
    ``collection_name`` is accepted for API compatibility with older call sites.
    """
    _ = collection_name
    return _require_safe_name(base_table_name, field="table_name")


def _vector_literal(values: list[float]) -> str:
    return "[" + ",".join(str(x) for x in values) + "]"


def get_connection(
    *,
    host: str,
    port: int,
    database: str,
    user: str | None,
    password: str | None,
):
    import psycopg

    if not database:
        raise ValueError("database is required when db/server='pgvector'")

    kwargs: dict[str, Any] = {
        "host": host,
        "port": port,
        "dbname": database,
    }
    if user is not None:
        kwargs["user"] = user
    if password is not None:
        kwargs["password"] = password
    conn = psycopg.connect(**kwargs)
    conn.autocommit = True
    return conn


def initialize_collection_table(
    conn,
    *,
    table_name: str,
    embedding_dimension: int,
) -> bool:
    """
    Ensure pgvector extension and collection table exist.
    Returns True when table already existed.
    """
    if embedding_dimension <= 0:
        raise ValueError("embedding_dimension must be > 0")
    from psycopg import sql

    _require_safe_name(table_name, field="table_name")
    with conn.cursor() as cur:
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
        cur.execute("SELECT to_regclass(%s)", (f"public.{table_name}",))
        existed = cur.fetchone()[0] is not None
        cur.execute(
            sql.SQL(
                """
                CREATE TABLE IF NOT EXISTS {} (
                    key TEXT PRIMARY KEY,
                    embedding vector({}),
                    document TEXT NOT NULL
                )
                """
            ).format(sql.Identifier(table_name), sql.SQL(str(embedding_dimension)))
        )
    return existed


def add_documents_to_table(
    conn,
    *,
    table_name: str,
    ids: list[str],
    embeddings: list[list[float]],
    documents: list[str],
    batch_size: int = DEFAULT_PGVECTOR_BATCH_SIZE,
) -> None:
    if not (len(ids) == len(embeddings) == len(documents)):
        raise ValueError("ids, embeddings, and documents must have the same length")
    if batch_size <= 0:
        raise ValueError("batch_size must be > 0")
    from psycopg import sql
    _require_safe_name(table_name, field="table_name")

    total = len(ids)
    with conn.cursor() as cur:
        for start in range(0, total, batch_size):
            end = min(start + batch_size, total)
            batch_ids = ids[start:end]
            cur.execute(
                sql.SQL("DELETE FROM {} WHERE key = ANY(%s)").format(sql.Identifier(table_name)),
                (batch_ids,),
            )

        for start in range(0, total, batch_size):
            end = min(start + batch_size, total)
            batch_ids = ids[start:end]
            batch_embeddings = embeddings[start:end]
            batch_documents = documents[start:end]

            placeholders: list[Any] = []
            params: list[Any] = []
            for idx, key in enumerate(batch_ids):
                placeholders.append(sql.SQL("(%s, %s::vector, %s)"))
                params.extend([key, _vector_literal(batch_embeddings[idx]), batch_documents[idx]])

            insert_sql = sql.SQL("INSERT INTO {} (key, embedding, document) VALUES {}").format(
                sql.Identifier(table_name),
                sql.SQL(", ").join(placeholders),
            )
            cur.execute(insert_sql, params)

            logger.info(
                "[6/6] pgvector add progress | inserted=%d/%d",
                end,
                total,
            )


def finalize_table(conn, *, table_name: str) -> None:
    from psycopg import sql
    _require_safe_name(table_name, field="table_name")
    with conn.cursor() as cur:
        cur.execute(
            sql.SQL(
                "CREATE INDEX IF NOT EXISTS {} ON {} USING hnsw (embedding vector_cosine_ops)"
            ).format(
                sql.Identifier(f"{table_name}_embedding_idx"),
                sql.Identifier(table_name),
            )
        )
        cur.execute(sql.SQL("ANALYZE {}").format(sql.Identifier(table_name)))


def list_collection_tables(
    conn,
    *,
    table_name_prefix: str,
) -> list[tuple[str, int]]:
    from psycopg import sql
    _require_safe_name(table_name_prefix, field="table_name")
    out: list[tuple[str, int]] = []
    like_pattern = f"{table_name_prefix}\\_%"
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT tablename
            FROM pg_tables
            WHERE schemaname = 'public'
              AND (tablename = %s OR tablename LIKE %s ESCAPE '\\')
            ORDER BY tablename
            """,
            (table_name_prefix, like_pattern),
        )
        table_names = [row[0] for row in cur.fetchall()]

        for table in table_names:
            cur.execute(sql.SQL("SELECT count(*) FROM {}").format(sql.Identifier(table)))
            out.append((table, int(cur.fetchone()[0])))
    return out
