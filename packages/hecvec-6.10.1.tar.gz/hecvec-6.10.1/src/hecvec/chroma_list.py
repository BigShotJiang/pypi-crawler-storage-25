"""
Backward-compatible shim.

Use `hecvec.backend_list` for backend-neutral naming.
"""
from hecvec.backend_list import list_collections, list_collections_from_client

__all__ = ["list_collections", "list_collections_from_client"]
