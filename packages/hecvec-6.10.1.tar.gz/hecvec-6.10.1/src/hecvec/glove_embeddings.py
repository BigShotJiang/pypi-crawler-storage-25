"""
Local GloVe embeddings (parity with slicer local provider): Stanford GloVe .txt, mean pooling.

- Optional first-time download from glove.6B.zip via HTTP Range + ZIP central directory.
- Cache directory: ~/.slicer/models/ (fixed).
- Tokenization: lowercase, regex \\b[a-z']+\\b.
- One vector per text: mean of in-vocab token vectors; all OOV -> zero vector.

Uses only the Python standard library.
"""
from __future__ import annotations

import logging
import re
import struct
import zlib
from pathlib import Path
from typing import Dict, Tuple

logger = logging.getLogger(__name__)

GLOVE_CACHE_DIR = Path.home() / ".slicer" / "models"

GLOVE_MODELS: dict[str, dict] = {
    "glove-6B-50d": {
        "dims": 50,
        "url": "https://nlp.stanford.edu/data/glove.6B.zip",
        "file": "glove-6B-50d.txt",
        "entryName": "glove.6B.50d.txt",
    },
    "glove-6B-100d": {
        "dims": 100,
        "url": "https://nlp.stanford.edu/data/glove.6B.zip",
        "file": "glove-6B-100d.txt",
        "entryName": "glove.6B.100d.txt",
    },
}

_TOKEN_RE = re.compile(r"\b[a-z']+\b")

_glove_vocab_cache: dict[str, dict[str, tuple[float, ...]]] = {}


def is_known_glove_model(name: str) -> bool:
    n = name.strip().lower()
    return any(k.lower() == n for k in GLOVE_MODELS)


def resolve_glove_model_key(name: str) -> str:
    n = name.strip().lower()
    for k in GLOVE_MODELS:
        if k.lower() == n:
            return k
    raise ValueError(
        f"Unknown GloVe model: {name!r}. Supported: {', '.join(sorted(GLOVE_MODELS))}"
    )


def _read_u32_le(buf: bytes, offset: int) -> int:
    return struct.unpack_from("<I", buf, offset)[0]


def _read_u16_le(buf: bytes, offset: int) -> int:
    return struct.unpack_from("<H", buf, offset)[0]


def _fetch_range(url: str, start: int, end: int) -> bytes:
    import urllib.request

    req = urllib.request.Request(url, headers={"Range": f"bytes={start}-{end}"})
    with urllib.request.urlopen(req) as resp:
        if resp.status not in (200, 206):
            raise RuntimeError(f"HTTP {resp.status} fetching range {start}-{end}")
        return resp.read()


def _fetch_file_size(url: str) -> int:
    import urllib.request

    req = urllib.request.Request(url, method="HEAD")
    with urllib.request.urlopen(req) as resp:
        cl = resp.headers.get("Content-Length")
        if not cl:
            raise RuntimeError("Server did not return Content-Length")
        return int(cl)


def _extract_from_remote_zip(url: str, entry_name: str) -> bytes:
    logger.info("Fetching ZIP metadata from %s...", url)
    total_size = _fetch_file_size(url)

    tail_size = min(65536, total_size)
    tail = _fetch_range(url, total_size - tail_size, total_size - 1)

    eocd_offset = -1
    for i in range(len(tail) - 22, -1, -1):
        if (
            tail[i] == 0x50
            and tail[i + 1] == 0x4B
            and tail[i + 2] == 0x05
            and tail[i + 3] == 0x06
        ):
            eocd_offset = i
            break
    if eocd_offset < 0:
        raise RuntimeError("Could not find ZIP EOCD record")

    cd_size = _read_u32_le(tail, eocd_offset + 12)
    cd_offset = _read_u32_le(tail, eocd_offset + 16)

    logger.info("Reading central directory (%d KB)...", round(cd_size / 1024))
    cd = _fetch_range(url, cd_offset, cd_offset + cd_size - 1)

    pos = 0
    local_header_offset = -1
    compressed_size = -1
    compression_method = -1

    while pos < len(cd) - 4:
        if (
            cd[pos] != 0x50
            or cd[pos + 1] != 0x4B
            or cd[pos + 2] != 0x01
            or cd[pos + 3] != 0x02
        ):
            break

        method = _read_u16_le(cd, pos + 10)
        c_size = _read_u32_le(cd, pos + 20)
        fn_len = _read_u16_le(cd, pos + 28)
        extra_len = _read_u16_le(cd, pos + 30)
        comment_len = _read_u16_le(cd, pos + 32)
        local_off = _read_u32_le(cd, pos + 42)
        name = cd[pos + 46 : pos + 46 + fn_len].decode("utf-8", errors="replace")

        if name == entry_name:
            local_header_offset = local_off
            compressed_size = c_size
            compression_method = method

        pos += 46 + fn_len + extra_len + comment_len

    if local_header_offset < 0:
        raise RuntimeError(f'Entry "{entry_name}" not found in ZIP central directory')

    local_header = _fetch_range(url, local_header_offset, local_header_offset + 29)
    local_fn_len = _read_u16_le(local_header, 26)
    local_extra_len = _read_u16_le(local_header, 28)
    data_offset = local_header_offset + 30 + local_fn_len + local_extra_len

    logger.info(
        'Downloading "%s" (~%d MB compressed)...',
        entry_name,
        round(compressed_size / 1024 / 1024),
    )
    compressed = _fetch_range(url, data_offset, data_offset + compressed_size - 1)

    if compression_method == 0:
        return compressed
    if compression_method == 8:
        return zlib.decompress(compressed, -zlib.MAX_WBITS)
    raise RuntimeError(f"Unsupported ZIP compression method: {compression_method}")


def _ensure_model_downloaded(model_key: str) -> Path:
    meta = GLOVE_MODELS[model_key]
    GLOVE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    file_path = GLOVE_CACHE_DIR / meta["file"]

    if not file_path.is_file():
        logger.info(
            'Downloading GloVe model "%s" (one-time; see Stanford GloVe terms of use).',
            model_key,
        )
        data = _extract_from_remote_zip(meta["url"], meta["entryName"])
        file_path.write_bytes(data)
        logger.info("Saved GloVe vectors to %s", file_path)

    return file_path


def load_glove_vocab(file_path: Path) -> dict[str, tuple[float, ...]]:
    vocab: dict[str, tuple[float, ...]] = {}
    with file_path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            space_idx = line.find(" ")
            if space_idx == -1:
                continue
            word = line[:space_idx]
            parts = line[space_idx + 1 :].split()
            vocab[word] = tuple(float(x) for x in parts)
    return vocab


def mean_pool_glove_text(text: str, vocab: dict[str, tuple[float, ...]], dims: int) -> list[float]:
    tokens = _TOKEN_RE.findall(text.lower())
    vecs = [vocab[t] for t in tokens if t in vocab]
    if not vecs:
        return [0.0] * dims
    n = len(vecs)
    acc = [0.0] * dims
    for vec in vecs:
        for i in range(dims):
            acc[i] += vec[i] / n
    return acc


def embed_texts_glove(
    texts: list[str],
    *,
    model: str = "glove-6B-50d",
) -> list[list[float]]:
    """
    Embed each string as the mean of GloVe word vectors (in-vocab only; else zeros).
    Vectors are cached under ~/.slicer/models/.
    """
    model_key = resolve_glove_model_key(model)
    meta = GLOVE_MODELS[model_key]
    dims: int = meta["dims"]

    if not texts:
        return []

    vocab = _glove_vocab_cache.get(model_key)
    if vocab is None:
        path = _ensure_model_downloaded(model_key)
        logger.info("Loading GloVe vocabulary from disk...")
        vocab = load_glove_vocab(path)
        _glove_vocab_cache[model_key] = vocab
        logger.info("Loaded %s words.", f"{len(vocab):,}")

    return [mean_pool_glove_text(t, vocab, dims) for t in texts]
