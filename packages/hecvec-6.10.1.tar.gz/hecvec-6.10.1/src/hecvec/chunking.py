"""
Chunk text documents. Requires optional dependency: pip install hecvec[chunk]
"""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_text_splitters import RecursiveCharacterTextSplitter

_DEFAULT_CHUNK_SIZE = 400
_DEFAULT_CHUNK_OVERLAP = 0
_DEFAULT_SEPARATORS = ["\n\n\n", "\n\n", "\n", ". ", " ", ""]


def _get_splitter(
    chunk_size: int = _DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = _DEFAULT_CHUNK_OVERLAP,
    separators: list[str] | None = None,
) -> "RecursiveCharacterTextSplitter":
    try:
        from langchain_text_splitters import RecursiveCharacterTextSplitter
    except ImportError as e:
        raise ImportError(
            "Chunking requires langchain-text-splitters. Install with: pip install hecvec[chunk]"
        ) from e
    return RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=separators or _DEFAULT_SEPARATORS,
    )


def chunk_text(
    text: str,
    chunk_size: int = _DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = _DEFAULT_CHUNK_OVERLAP,
    separators: list[str] | None = None,
) -> list[str]:
    """
    Split a single document text into chunks.

    Requires optional dependency: pip install hecvec[chunk]
    """
    splitter = _get_splitter(chunk_size, chunk_overlap, separators)
    return splitter.split_text(text)


def chunk_documents(
    path_and_texts: list[tuple[str | Path, str]],
    chunk_size: int = _DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = _DEFAULT_CHUNK_OVERLAP,
    separators: list[str] | None = None,
) -> list[dict]:
    """
    Chunk multiple documents. Each input is (path, text).
    Returns a list of dicts: {"path": str, "chunk_index": int, "content": str}.

    Requires optional dependency: pip install hecvec[chunk]
    """
    splitter = _get_splitter(chunk_size, chunk_overlap, separators)
    out = []
    for path, text in path_and_texts:
        path_str = str(Path(path).resolve())
        chunks = splitter.split_text(text)
        for i, content in enumerate(chunks):
            out.append({"path": path_str, "chunk_index": i, "content": content})
    return out
