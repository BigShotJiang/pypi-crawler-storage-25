"""
Ported from python/chunking: token count, TextSplitter, RecursiveTokenChunker.
Used by semantic and LLM chunkers for initial text splitting.
"""
from __future__ import annotations

import re
from typing import Callable

try:
    import tiktoken
except ImportError:
    tiktoken = None  # type: ignore

_encoder = None


def _get_encoder():
    global _encoder
    if _encoder is None:
        if tiktoken is None:
            raise ImportError("tiktoken is required. Install with: pip install tiktoken")
        _encoder = tiktoken.get_encoding("cl100k_base")
    return _encoder


def openai_token_count(text: str) -> int:
    """Count tokens using OpenAI's cl100k_base encoding."""
    return len(_get_encoder().encode(text))


LengthFunction = Callable[[str], int]


class TextSplitter:
    """Base text splitter with merge logic (from python/chunking)."""

    def __init__(
        self,
        chunk_size: int = 4000,
        chunk_overlap: int = 200,
        length_function: LengthFunction | None = None,
        keep_separator: bool = True,
    ):
        if chunk_overlap > chunk_size:
            raise ValueError(
                f"Chunk overlap ({chunk_overlap}) cannot be larger than chunk size ({chunk_size})."
            )
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap
        self._length_function = length_function or openai_token_count
        self._keep_separator = keep_separator

    def split_text(self, text: str) -> list[str]:
        raise NotImplementedError

    def _join_docs(self, docs: list[str], separator: str) -> str | None:
        joined = separator.join(docs).strip()
        return joined if joined else None

    def _merge_splits(self, splits: list[str], separator: str) -> list[str]:
        separator_len = self._length_function(separator)
        docs: list[str] = []
        current_doc: list[str] = []
        total = 0
        for d in splits:
            length = self._length_function(d)
            if total + length + (separator_len if current_doc else 0) > self._chunk_size:
                if current_doc:
                    doc = self._join_docs(current_doc, separator)
                    if doc is not None:
                        docs.append(doc)
                    while (
                        total > self._chunk_overlap
                        or (
                            total + length + (separator_len if current_doc else 0) > self._chunk_size
                            and total > 0
                        )
                    ):
                        if not current_doc:
                            break
                        first = current_doc.pop(0)
                        total -= self._length_function(first) + (
                            separator_len if current_doc else 0
                        )
            current_doc.append(d)
            total += length + (separator_len if len(current_doc) > 1 else 0)
        doc = self._join_docs(current_doc, separator)
        if doc is not None:
            docs.append(doc)
        return docs


def _split_keep_separator(text: str, separator: str) -> list[str]:
    if not separator:
        return [c for c in text if c]
    pattern = f"({re.escape(separator)})"
    parts = re.split(pattern, text)
    out: list[str] = []
    i = 1
    while i < len(parts):
        out.append((parts[i] or "") + (parts[i + 1] if i + 1 < len(parts) else ""))
        i += 2
    if len(parts) % 2 == 0 and parts:
        out.append(parts[-1])
    if parts and parts[0].strip():
        out.insert(0, parts[0])
    return [x for x in out if x]


class RecursiveTokenChunker(TextSplitter):
    """Splits text by recursively trying separators to get ~chunk_size token chunks (from python/chunking)."""

    def __init__(
        self,
        chunk_size: int = 4000,
        chunk_overlap: int = 200,
        length_function: LengthFunction | None = None,
        keep_separator: bool = True,
        separators: list[str] | None = None,
    ):
        super().__init__(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=length_function or openai_token_count,
            keep_separator=keep_separator,
        )
        self._separators = separators or ["\n\n", "\n", ".", "?", "!", " ", ""]

    def _split_text(self, text: str, separators: list[str]) -> list[str]:
        final_chunks: list[str] = []
        separator = separators[-1] if separators else ""
        new_separators: list[str] = []
        for i, s in enumerate(separators):
            pat = re.escape(s)
            if s == "":
                separator = s
                break
            if re.search(pat, text):
                separator = s
                new_separators = separators[i + 1 :]
                break
        pat = re.escape(separator)
        splits = _split_keep_separator(text, separator) if pat else [c for c in text if c]
        sep_for_merge = "" if self._keep_separator else separator
        good_splits: list[str] = []
        for s in splits:
            if self._length_function(s) < self._chunk_size:
                good_splits.append(s)
            else:
                if good_splits:
                    merged = self._merge_splits(good_splits, sep_for_merge)
                    final_chunks.extend(merged)
                    good_splits = []
                if not new_separators:
                    final_chunks.append(s)
                else:
                    final_chunks.extend(self._split_text(s, new_separators))
        if good_splits:
            final_chunks.extend(self._merge_splits(good_splits, sep_for_merge))
        return final_chunks

    def split_text(self, text: str) -> list[str]:
        return self._split_text(text, self._separators)
