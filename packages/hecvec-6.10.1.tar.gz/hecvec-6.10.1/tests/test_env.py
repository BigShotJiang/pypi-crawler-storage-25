"""Tests for hecvec.env (no chroma/openai)."""
import os

import pytest

from hecvec.env import (
    load_dotenv_if_available,
    load_openai_key,
    require_pgvector_password,
)


def test_load_openai_key_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """OPENAI_API_KEY is read from os.environ."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key")
    assert load_openai_key() == "sk-test-key"


def test_load_openai_key_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    """Missing key returns None."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    assert load_openai_key() is None


def test_load_dotenv_if_available_no_error() -> None:
    """load_dotenv_if_available never raises (no-op if no dotenv)."""
    load_dotenv_if_available()
    load_dotenv_if_available("/nonexistent/.env")


def test_require_pgvector_password_prefers_arg(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PGPASSWORD", "from_env")
    assert require_pgvector_password("from_arg") == "from_arg"


def test_require_pgvector_password_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PGPASSWORD", "secret")
    assert require_pgvector_password(None) == "secret"


def test_require_pgvector_password_missing_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PGPASSWORD", raising=False)
    with pytest.raises(ValueError, match="password is required"):
        require_pgvector_password(None, dotenv_path="/nonexistent/hecvec_test_no_dotenv/.env")


def test_require_pgvector_password_env_empty_string_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PGPASSWORD", "")
    assert require_pgvector_password(None) == ""
