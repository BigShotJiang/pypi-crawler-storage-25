"""Tests for hecvec.reading (no external deps)."""
from pathlib import Path

import pytest

from hecvec.reading import ReadText


def test_read_all(tmp_path: Path) -> None:
    """Read files return (path, text)."""
    (tmp_path / "a.txt").write_text("hello", encoding="utf-8")
    (tmp_path / "b.md").write_text("world", encoding="utf-8")
    reader = ReadText([tmp_path / "a.txt", tmp_path / "b.md"])
    out = reader.read_all()
    assert len(out) == 2
    texts = [t for _, t in out]
    assert "hello" in texts
    assert "world" in texts


def test_read_skips_missing(tmp_path: Path) -> None:
    """Missing files are skipped."""
    (tmp_path / "exists.txt").write_text("x")
    reader = ReadText([tmp_path / "exists.txt", tmp_path / "missing.txt"])
    out = reader.read_all()
    assert len(out) == 1
    assert out[0][1] == "x"
