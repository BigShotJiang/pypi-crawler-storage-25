"""Unit tests for pgvector helper utilities."""

from hecvec.pgvector_client import resolve_collection_table_name


def test_resolve_collection_table_name_uses_base_table_name_as_is() -> None:
    table = resolve_collection_table_name("embeddings", "My Collection-v1")
    assert table == "embeddings"


def test_resolve_collection_table_name_rejects_invalid_base_name() -> None:
    try:
        resolve_collection_table_name("bad-name", "abc")
    except ValueError as exc:
        assert "table_name" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid base table_name")
