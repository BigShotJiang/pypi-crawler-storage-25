"""Tests for local GloVe mean-pooling (no download)."""

from hecvec.glove_embeddings import (
    is_known_glove_model,
    load_glove_vocab,
    mean_pool_glove_text,
    resolve_glove_model_key,
)


def test_is_known_glove_model_case_insensitive() -> None:
    assert is_known_glove_model("glove-6B-50d")
    assert is_known_glove_model("GLOVE-6b-100d")
    assert not is_known_glove_model("text-embedding-3-small")


def test_resolve_glove_model_key() -> None:
    assert resolve_glove_model_key("glove-6b-50d") == "glove-6B-50d"


def test_mean_pool_and_oov(tmp_path) -> None:
    p = tmp_path / "tiny.txt"
    p.write_text("hello 1.0 0.0\nworld 0.0 1.0\n", encoding="utf-8")
    vocab = load_glove_vocab(p)
    assert mean_pool_glove_text("hello world", vocab, 2) == [0.5, 0.5]
    assert mean_pool_glove_text("hello", vocab, 2) == [1.0, 0.0]
    assert mean_pool_glove_text("zzz unknown", vocab, 2) == [0.0, 0.0]


def test_infer_provider_glove() -> None:
    from hecvec.embeddings import infer_embedding_provider

    assert infer_embedding_provider("glove-6B-100d") == "glove"
