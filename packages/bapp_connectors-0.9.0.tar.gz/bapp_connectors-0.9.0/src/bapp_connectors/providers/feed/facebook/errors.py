"""
Facebook feed error mapping.
"""
