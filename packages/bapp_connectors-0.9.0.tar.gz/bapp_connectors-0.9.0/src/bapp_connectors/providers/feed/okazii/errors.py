"""
Okazii feed error mapping.
"""
