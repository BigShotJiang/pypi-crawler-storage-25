

def generator():
    pass
