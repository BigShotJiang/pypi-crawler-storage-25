# A library for converting to and from Aperture Science apf files, the custom extended apf2s, otb/wbmp images, and facedev's bruh format.

## basic usage: 

```
import apftool

apfString = apftool.encodeapf(pngObject) # turns image bytes object into apf string
pngObject = apftool.decodeapf(apfString) # turns apf string object into image bytes
```

additional tooling and software using apftool can be found at https://github.com/kbity/apftool, including custom MIME extensions.

## funcs and features

### encoders:

`encodeapf(img: bytes, lineskip: int = 1, findbestlineskip: bool = False)` takes image bytes and outputs apf string. lineskip is interleave value, findbestlineskip brute-forces different interleave values to the possible max of 199 and uses the smallest one.

`encodeaf2(img: bytes, lineskip: int = 1, findbestlineskip: bool = False, legacy: bool = False, trans = False, pal: int = 95, desc: str = ""):` takes image bytes and outputs af2 string. lineskip is interleave value, findbestlineskip brute-forces different interleave values to the provided lineskip and uses the smallest one. legacy uses apf1-style 2 color data instead of a 95 color palette. trans sets transparency mode, with mode 0 being off, mode 1 being index 0 transparency (GIF-like, it overrides a color), and mode 2 being indexed alpha. pal allows you to manually force a smaller or larger palette anything over 95 will use APF2-1994's Dual Indexed Mode.

`encodewbmp(img: Image)` takes pil image object and outputs wbmp bytes

`encodeotab(img: Image, width=255, height=255)` takes pil image object and outputs otb bytes. max size is 255x255. the size input is max size, the output may be smaller

`encodebruh(img: Image)` takes pil image object and outputs bruh bytes

### decoders:

`decodeany(data, format: str = 'PNG', returnImageObject: bool = False)` takes in string or bytes and outputs bytes image or PIL image using best-guess for the decoders

`decodeapf(apf: str, format: str = 'PNG', returnImageObject: bool = False)` takes apf string and outputs either image bytes in specified format or pil image object

`decodeaf2(af2: str, format: str = 'PNG', returnImageObject: bool = False)` hi i am the same thing, i am literally a dropin replacement for decodeapf too

`decodewbmp(wbmp: bytes, format: str = 'PNG', returnImageObject: bool = False)` takes wbmp bytes and outputs either image bytes in specified format or pil image object

`decodeotab(otab: bytes, format: str = 'PNG', returnImageObject: bool = False)` hi i have the same usage as decodewbmp but for .otb images

`decodebruh(bruh: bytes, format: str = 'PNG', returnImageObject: bool = False)` bruh decoder, acts the same as the others.

### misc:

apftool provides many extensions tuples:

`extensions` - apf/apf2 extensions

`extensions_apf` - apf extensions

`extensions_apf2` - apf2 extensions

`extensions_wbmp` - wbmp extensions

`extensions_otab` - otb extensions

`extensions_bruh` - bruh extensions

`extensions_txt` - txt extensions, useful for weeding out generic apf

`extensions_all` - all supported apftool extensions, useful for decodeany

## dependancies

`PIL (pillow)` is required

`numpy` and `scikit-learn` are needed for high-speed APF2-1994 257+ Color Encoding, if missing the code will use a very slow fallback.

## changelog:

0.5.7 - fix index 0 bug with transparency mode 2 in 9025 color mode

0.5.6 - damn it i left the file testing code in af2tool

0.5.5 - implement apf2-1994 encoding and decoding (broken release)

0.5.2 - add bruh heristic to decodeany

0.5.1 - attempt to fix bruh resolution parsing issue

0.5.0 - add bruh encoder and decoder

0.4.3 - actually improve otb quality

0.4.2 - did not improve otb quality

0.4.1 - improve readme.md, fix otb encoder skuing due to flushing

0.4.0 - add support for otb images, improve readme.md, and add decodeany to decode all suported formats automatically

0.3.3 - make the af2 decoder more lenient

0.3.2 - i forgot but i think it made the af2 decoder more lenient

0.3.1 - fix 0.3.0

0.3.0 - add support for wbmp images, broken release
