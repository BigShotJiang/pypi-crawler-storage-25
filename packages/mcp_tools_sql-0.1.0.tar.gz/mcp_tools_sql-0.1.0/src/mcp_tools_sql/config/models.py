"""Pydantic configuration models for mcp-tools-sql."""

from __future__ import annotations

from typing import Optional, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ConnectionConfig(BaseModel):
    """Database connection parameters (stored in database config)."""

    backend: str = "sqlite"  # sqlite | mssql | postgresql
    host: str = ""
    port: int = 0
    database: str = ""
    username: str = ""
    password: str = ""
    trusted_connection: bool = False
    encrypt: bool = True
    trust_server_certificate: bool = False
    driver: str = "ODBC Driver 18 for SQL Server"  # MSSQL only
    path: str = ""  # SQLite file path


class QueryParamConfig(BaseModel):
    """Definition of a single query parameter."""

    name: str
    type: str = "str"  # str | int | float | datetime
    description: str = ""
    required: bool = True


class BackendQueryConfig(BaseModel):
    """Per-backend SQL override for a query."""

    sql: str


class QueryConfig(BaseModel):
    """A configured SELECT query that becomes an MCP tool."""

    description: str = ""
    sql: str
    params: dict[str, QueryParamConfig] = {}
    max_rows_default: int = 100
    max_rows_hard: int | None = None
    filter_column: str = ""
    backends: dict[str, BackendQueryConfig] = {}

    @model_validator(mode="after")
    def _default_max_rows_hard(self) -> Self:
        if self.max_rows_hard is None:
            self.max_rows_hard = self.max_rows_default
        return self

    def resolve_sql(self, backend_name: str) -> str:
        """Return backend-specific SQL if override exists, else default sql."""
        if backend_name in self.backends:
            return self.backends[backend_name].sql
        return self.sql


class UpdateFieldConfig(BaseModel):
    """A field that can be updated."""

    field: str
    type: str = "str"
    description: str = ""
    required: bool = False


class UpdateKeyConfig(BaseModel):
    """Unique key that identifies the row to update."""

    field: str
    type: str = "int"
    description: str = ""


class UpdateConfig(BaseModel):
    """A configured UPDATE definition that becomes an MCP tool."""

    model_config = ConfigDict(populate_by_name=True)

    description: str = ""
    schema_name: str = Field(default="", alias="schema")
    table: str = ""
    key: Optional[UpdateKeyConfig] = None
    fields: list[UpdateFieldConfig] = []


class SecurityConfig(BaseModel):
    """Security settings (phase 2/3 placeholder)."""

    allow_updates: bool = True


class QueryFileConfig(BaseModel):
    """Root model for the project query config file (mcp-tools-sql.toml)."""

    connection: str = ""  # named connection reference
    queries: dict[str, QueryConfig] = {}
    updates: dict[str, UpdateConfig] = {}


class DatabaseConfig(BaseModel):
    """Root model for database config (~/.mcp-tools-sql/config.toml)."""

    connections: dict[str, ConnectionConfig] = {}
    security: SecurityConfig = SecurityConfig()
