"""Tests for TOML config loading functions."""

from __future__ import annotations

import logging
import stat
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

from mcp_tools_sql.config.loader import (
    discover_query_config,
    load_database_config,
    load_query_config,
    resolve_connection,
)
from mcp_tools_sql.config.models import (
    ConnectionConfig,
    DatabaseConfig,
    QueryFileConfig,
)


class TestLoadQueryConfig:
    """Tests for load_query_config."""

    def test_valid_query_config(self, tmp_path: Path) -> None:
        """Loads a complete mcp-tools-sql.toml exercising all nested models."""
        toml_content = """\
connection = "mydb"

[queries.get_users]
description = "Find users by department"
sql = "SELECT * FROM users WHERE dept = :dept"
max_rows_default = 50

[queries.get_users.params.dept]
name = "dept"
type = "str"
description = "Department name"
required = true

[updates.update_email]
description = "Update user email"
schema = "dbo"
table = "users"

[updates.update_email.key]
field = "id"
type = "int"
description = "User ID"

[[updates.update_email.fields]]
field = "email"
type = "str"
description = "New email address"
"""
        config_file = tmp_path / "mcp-tools-sql.toml"
        config_file.write_text(toml_content)

        config = load_query_config(config_file)

        assert isinstance(config, QueryFileConfig)
        assert config.connection == "mydb"
        assert "get_users" in config.queries
        assert config.queries["get_users"].max_rows_default == 50
        assert config.queries["get_users"].params["dept"].type == "str"
        assert "update_email" in config.updates
        assert config.updates["update_email"].schema_name == "dbo"
        assert config.updates["update_email"].table == "users"
        assert config.updates["update_email"].fields[0].field == "email"

    def test_empty_file_returns_defaults(self, tmp_path: Path) -> None:
        """Empty TOML file returns QueryFileConfig with defaults."""
        config_file = tmp_path / "mcp-tools-sql.toml"
        config_file.write_text("")

        config = load_query_config(config_file)

        assert config.connection == ""
        assert config.queries == {}
        assert config.updates == {}

    def test_missing_file_raises_value_error(self, tmp_path: Path) -> None:
        """Non-existent path raises ValueError with file path in message."""
        missing = tmp_path / "nonexistent.toml"

        with pytest.raises(ValueError, match="nonexistent.toml"):
            load_query_config(missing)

    def test_invalid_toml_raises_value_error(self, tmp_path: Path) -> None:
        """Malformed TOML raises ValueError with file path and line info."""
        config_file = tmp_path / "bad.toml"
        config_file.write_text("[invalid\n")

        with pytest.raises(ValueError, match="bad.toml"):
            load_query_config(config_file)

    def test_credential_warning(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """password in query config triggers a log warning."""
        toml_content = """\
connection = "mydb"
password = "secret123"
"""
        config_file = tmp_path / "mcp-tools-sql.toml"
        config_file.write_text(toml_content)

        with caplog.at_level(logging.WARNING):
            load_query_config(config_file)

        assert any("password" in record.message for record in caplog.records)

    def test_extra_fields_ignored(self, tmp_path: Path) -> None:
        """Unknown TOML keys are silently ignored by Pydantic."""
        toml_content = """\
connection = "mydb"
unknown_key = "should be ignored"
another_extra = 42
"""
        config_file = tmp_path / "mcp-tools-sql.toml"
        config_file.write_text(toml_content)

        config = load_query_config(config_file)

        assert config.connection == "mydb"

    def test_schema_alias_through_toml(self, tmp_path: Path) -> None:
        """TOML 'schema = dbo' maps to UpdateConfig.schema_name."""
        toml_content = """\
[updates.fix_record]
schema = "dbo"
table = "records"
"""
        config_file = tmp_path / "mcp-tools-sql.toml"
        config_file.write_text(toml_content)

        config = load_query_config(config_file)

        assert config.updates["fix_record"].schema_name == "dbo"


class TestLoadDatabaseConfig:
    """Tests for load_database_config."""

    def test_valid_database_config(self, tmp_path: Path) -> None:
        """Loads database config with multiple named connections."""
        toml_content = """\
[connections.local_sqlite]
backend = "sqlite"
path = "./test.db"

[connections.prod_mssql]
backend = "mssql"
host = "db.example.com"
port = 1433
database = "mydb"
username = "admin"
password = "secret"
"""
        config_file = tmp_path / "config.toml"
        config_file.write_text(toml_content)

        config = load_database_config(config_file)

        assert isinstance(config, DatabaseConfig)
        assert "local_sqlite" in config.connections
        assert config.connections["local_sqlite"].backend == "sqlite"
        assert "prod_mssql" in config.connections
        assert config.connections["prod_mssql"].host == "db.example.com"
        assert config.connections["prod_mssql"].password == "secret"

    def test_none_path_uses_default(self, tmp_path: Path) -> None:
        """None path defaults to ~/.mcp-tools-sql/config.toml."""
        # Point home to tmp_path so the default file won't exist
        with patch("mcp_tools_sql.config.loader.Path.home", return_value=tmp_path):
            config = load_database_config(None)

        assert isinstance(config, DatabaseConfig)
        assert config.connections == {}

    def test_missing_file_returns_defaults(self, tmp_path: Path) -> None:
        """Non-existent file returns DatabaseConfig() with empty connections."""
        missing = tmp_path / "nonexistent.toml"

        config = load_database_config(missing)

        assert isinstance(config, DatabaseConfig)
        assert config.connections == {}

    def test_invalid_toml_raises_value_error(self, tmp_path: Path) -> None:
        """Malformed database config raises ValueError."""
        config_file = tmp_path / "config.toml"
        config_file.write_text("[broken\n")

        with pytest.raises(ValueError, match="config.toml"):
            load_database_config(config_file)

    @pytest.mark.skipif(
        sys.platform == "win32", reason="Cannot reliably remove read on Windows"
    )
    def test_unreadable_file_raises_value_error(self, tmp_path: Path) -> None:
        """Existing but unreadable file raises ValueError (OSError wrapping)."""
        config_file = tmp_path / "config.toml"
        config_file.write_text("[connections]\n")
        config_file.chmod(0o000)

        try:
            with pytest.raises(ValueError, match=str(config_file)):
                load_database_config(config_file)
        finally:
            config_file.chmod(stat.S_IRUSR | stat.S_IWUSR)


class TestResolveConnection:
    """Tests for resolve_connection."""

    def test_valid_connection_found(self) -> None:
        """Returns ConnectionConfig when name matches."""
        conn = ConnectionConfig(backend="sqlite", path="./test.db")
        query_config = QueryFileConfig(connection="mydb")
        db_config = DatabaseConfig(connections={"mydb": conn})

        result = resolve_connection(query_config, db_config)

        assert result is conn
        assert result.backend == "sqlite"
        assert result.path == "./test.db"

    def test_missing_connection_raises(self) -> None:
        """ValueError when connection name not in database config."""
        conn = ConnectionConfig(backend="sqlite")
        query_config = QueryFileConfig(connection="missing")
        db_config = DatabaseConfig(connections={"other": conn})

        with pytest.raises(ValueError, match="missing"):
            resolve_connection(query_config, db_config)

    def test_empty_connection_name_raises(self) -> None:
        """ValueError when query_config.connection is empty."""
        query_config = QueryFileConfig(connection="")
        db_config = DatabaseConfig(connections={"mydb": ConnectionConfig()})

        with pytest.raises(ValueError, match="No connection name"):
            resolve_connection(query_config, db_config)

    def test_empty_connections_dict_raises(self) -> None:
        """ValueError when db_config has no connections."""
        query_config = QueryFileConfig(connection="mydb")
        db_config = DatabaseConfig(connections={})

        with pytest.raises(ValueError, match="mydb"):
            resolve_connection(query_config, db_config)


class TestEnvVarExpansion:
    """Tests for ``${VAR}`` expansion in load_database_config."""

    def test_expansion_present(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """A ``${VAR}`` placeholder is replaced by os.environ[VAR]."""
        monkeypatch.setenv("MY_PW", "secret")
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            "[connections.default]\n" 'backend = "mssql"\n' 'password = "${MY_PW}"\n',
            encoding="utf-8",
        )

        cfg = load_database_config(config_file)

        assert cfg.connections["default"].password == "secret"

    def test_expansion_unset_raises(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Unset env var raises ValueError including the ``${NAME}`` form."""
        monkeypatch.delenv("MISSING_VAR", raising=False)
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            "[connections.default]\n"
            'backend = "mssql"\n'
            'password = "${MISSING_VAR}"\n',
            encoding="utf-8",
        )

        with pytest.raises(ValueError, match=r"\$\{MISSING_VAR\}"):
            load_database_config(config_file)

    def test_expansion_multiple_substitutions_in_one_string(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Multiple ``${VAR}`` placeholders in one value all expand."""
        monkeypatch.setenv("PREFIX", "foo")
        monkeypatch.setenv("SUFFIX", "bar")
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            "[connections.default]\n"
            'backend = "mssql"\n'
            'database = "${PREFIX}_${SUFFIX}"\n',
            encoding="utf-8",
        )

        cfg = load_database_config(config_file)

        assert cfg.connections["default"].database == "foo_bar"

    def test_expansion_int_coercion(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Expanded string ``"1433"`` is coerced to int by Pydantic."""
        monkeypatch.setenv("MY_PORT", "1433")
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            "[connections.default]\n" 'backend = "mssql"\n' 'port = "${MY_PORT}"\n',
            encoding="utf-8",
        )

        cfg = load_database_config(config_file)

        assert cfg.connections["default"].port == 1433

    def test_query_config_is_not_expanded(self, tmp_path: Path) -> None:
        """load_query_config does NOT call _expand_env_vars: literal preserved."""
        config_file = tmp_path / "mcp-tools-sql.toml"
        config_file.write_text(
            'connection = "default"\n'
            "\n"
            "[queries.q]\n"
            "sql = \"SELECT '${NOPE}' AS x\"\n",
            encoding="utf-8",
        )

        cfg = load_query_config(config_file)

        assert cfg.queries["q"].sql == "SELECT '${NOPE}' AS x"


class TestDiscoverQueryConfig:
    """Tests for discover_query_config."""

    def test_explicit_flag_returned(self, tmp_path: Path) -> None:
        """--config flag path is returned directly."""
        config_file = tmp_path / "custom.toml"
        config_file.write_text("")

        result = discover_query_config(config_flag=config_file, project_dir=tmp_path)

        assert result == config_file

    def test_explicit_flag_missing_raises(self, tmp_path: Path) -> None:
        """ValueError when --config points to non-existent file."""
        missing = tmp_path / "nonexistent.toml"

        with pytest.raises(ValueError, match="nonexistent.toml"):
            discover_query_config(config_flag=missing, project_dir=tmp_path)

    def test_auto_discovery_in_project_dir(self, tmp_path: Path) -> None:
        """Finds mcp-tools-sql.toml in project_dir."""
        config_file = tmp_path / "mcp-tools-sql.toml"
        config_file.write_text("")

        result = discover_query_config(config_flag=None, project_dir=tmp_path)

        assert result == config_file

    def test_no_config_found_raises(self, tmp_path: Path) -> None:
        """ValueError with guidance when no config exists."""
        with pytest.raises(ValueError, match="mcp-tools-sql.toml"):
            discover_query_config(config_flag=None, project_dir=tmp_path)
