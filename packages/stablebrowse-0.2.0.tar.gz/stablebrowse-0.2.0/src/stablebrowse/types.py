"""Typed response wrappers for the stablebrowse API.

These are lightweight dataclasses over the raw JSON — they let IDEs
autocomplete known fields but don't reject unknown ones, so a server-side
addition (a new cost field, a new observability attribute) doesn't break
clients that haven't been upgraded. Unknown fields are preserved on the
`.raw` attribute for access.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


def _str(v: Any) -> str | None:
    return v if isinstance(v, str) and v else None


@dataclass
class Task:
    """Subset of TaskRecord fields most callers care about, plus the raw payload."""

    task_id: str
    session_id: str | None
    status: str
    task: str
    business_id: str | None = None
    end_user_id: str | None = None
    result: Any = None
    structured_content: dict | None = None
    html_dump: str | None = None
    error: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    raw: dict = field(default_factory=dict)

    @classmethod
    def from_json(cls, d: dict) -> Task:
        return cls(
            task_id=d["taskId"],
            session_id=_str(d.get("sessionId")),
            status=d["status"],
            task=d.get("task", ""),
            business_id=_str(d.get("businessId")),
            end_user_id=_str(d.get("endUserId")),
            result=d.get("result"),
            structured_content=d.get("structured_content"),
            html_dump=_str(d.get("html_dump")),
            error=_str(d.get("error")),
            created_at=_str(d.get("createdAt")),
            updated_at=_str(d.get("updatedAt")),
            raw=d,
        )

    @property
    def is_terminal(self) -> bool:
        return self.status in ("completed", "failed", "cancelled")


@dataclass
class SessionTasks:
    session_id: str
    tasks: list[Task]

    @classmethod
    def from_json(cls, d: dict) -> SessionTasks:
        return cls(
            session_id=d["sessionId"],
            tasks=[Task.from_json(t) for t in d.get("tasks", [])],
        )


@dataclass
class CredentialStatus:
    """What `GET /v1/end-users/{id}/credentials` returns — which platforms are
    configured, never the secrets themselves."""

    end_user_id: str
    platforms: dict[str, bool]
    raw: dict = field(default_factory=dict)

    @classmethod
    def from_json(cls, d: dict) -> CredentialStatus:
        return cls(
            end_user_id=d["endUserId"],
            platforms=dict(d.get("platforms") or {}),
            raw=d,
        )


