"""Main client class.

The public surface is small on purpose:

    client = Stablebrowse(api_key="sb_live_...")
    client.tasks.run(...)         # submit + poll until terminal
    client.tasks.submit(...)      # raw async primitive
    client.tasks.get(task_id)
    client.tasks.list()
    client.sessions.get(session_id)
    client.end_users("alice").credentials.set(...)
    client.end_users("alice").credentials.get()
    client.end_users("alice").credentials.delete()
"""

from __future__ import annotations

import os
import time
from typing import Any

import httpx

from .errors import StablebrowseError, TaskFailed, TaskTimeout
from .types import (
    CredentialStatus,
    SessionTasks,
    Task,
)

DEFAULT_BASE_URL = "https://api.stablebrowse.com/v1"
DEFAULT_TIMEOUT = 30.0  # seconds for a single HTTP call
DEFAULT_POLL_INTERVAL = 2.0
DEFAULT_POLL_TIMEOUT = 300.0  # 5 minutes upper bound for client.tasks.run


class Stablebrowse:
    """Entry point for the SDK.

    Args:
        api_key: Bearer token (sb_live_...). If omitted, read from the
            ``STABLEBROWSE_API_KEY`` environment variable.
        base_url: Override the API base URL. Defaults to the production
            endpoint; set to the beta endpoint (or a local dev API Gateway)
            when testing.
        timeout: Per-request HTTP timeout in seconds.
        http_client: Optional pre-configured ``httpx.Client``. Useful for
            custom transports, proxies, or test fixtures.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: httpx.Client | None = None,
    ) -> None:
        key = api_key or os.environ.get("STABLEBROWSE_API_KEY")
        if not key:
            raise StablebrowseError(
                "Missing API key. Pass api_key=... or set STABLEBROWSE_API_KEY.",
            )
        self._base_url = (base_url or os.environ.get("STABLEBROWSE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self._http = http_client or httpx.Client(
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "User-Agent": "stablebrowse-python/0.2.0",
            },
        )

        # Resource subclients.
        self.tasks = _Tasks(self)
        self.sessions = _Sessions(self)

    # ── HTTP plumbing ────────────────────────────────────────────────────

    def _request(self, method: str, path: str, json: Any = None) -> Any:
        url = f"{self._base_url}{path}"
        try:
            res = self._http.request(method, url, json=json)
        except httpx.TimeoutException as e:
            raise StablebrowseError(f"Request timeout: {e}") from e
        except httpx.HTTPError as e:
            raise StablebrowseError(f"HTTP error: {e}") from e

        # 204 No Content / empty body edge case.
        text = res.text or ""
        body: dict | None = None
        if text:
            try:
                body = res.json()
            except ValueError:
                body = None

        if not res.is_success:
            msg = (body or {}).get("error") or f"HTTP {res.status_code}"
            raise StablebrowseError(msg, status_code=res.status_code, body=body)

        return body

    # ── Nested API ───────────────────────────────────────────────────────

    def end_users(self, end_user_id: str) -> _EndUserRef:
        """Return a handle scoped to one end-user id so calls read cleanly:

            client.end_users("alice").credentials.set(...)
        """
        return _EndUserRef(self, end_user_id)

    def close(self) -> None:
        """Close the underlying HTTP client. Calling close() is optional —
        Python GC will handle it eventually, but calling it explicitly is
        cheap and safe for long-lived processes."""
        self._http.close()

    def __enter__(self) -> Stablebrowse:
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()


# ── Tasks ────────────────────────────────────────────────────────────────


class _Tasks:
    def __init__(self, client: Stablebrowse) -> None:
        self._c = client

    def submit(
        self,
        *,
        end_user_id: str,
        task: str,
        session_id: str | None = None,
        start_url: str | None = None,
        schema: dict | None = None,
        max_steps: int | None = None,
        include_html_dump: bool | None = None,
    ) -> Task:
        """Async submit. Returns immediately with a ``pending`` Task — the
        caller is responsible for polling (or streaming, once SSE ships)."""
        body: dict[str, Any] = {"endUserId": end_user_id, "task": task}
        if session_id is not None:
            body["sessionId"] = session_id
        if start_url is not None:
            body["startUrl"] = start_url
        if schema is not None:
            body["schema"] = schema
        if max_steps is not None:
            body["maxSteps"] = max_steps
        if include_html_dump is not None:
            body["include_html_dump"] = include_html_dump
        res = self._c._request("POST", "/tasks", json=body)
        # POST /tasks returns {taskId, sessionId, status, createdAt} — flesh
        # it out to the Task shape so the caller gets a uniform type.
        return Task.from_json({
            "taskId": res["taskId"],
            "sessionId": res.get("sessionId"),
            "status": res.get("status", "pending"),
            "task": task,
            "createdAt": res.get("createdAt"),
            "updatedAt": res.get("createdAt"),
        })

    def get(self, task_id: str) -> Task:
        res = self._c._request("GET", f"/tasks/{task_id}")
        return Task.from_json(res or {})

    def list(self, *, limit: int = 50) -> list[dict]:
        """List sessions the caller can see. Returns the raw session summaries
        for now — the server groups tasks into session buckets. If callers
        start needing a typed shape we'll add one."""
        res = self._c._request("GET", f"/tasks?limit={int(limit)}")
        return (res or {}).get("sessions", [])

    def run(
        self,
        *,
        end_user_id: str,
        task: str,
        session_id: str | None = None,
        start_url: str | None = None,
        schema: dict | None = None,
        max_steps: int | None = None,
        include_html_dump: bool | None = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        poll_timeout: float = DEFAULT_POLL_TIMEOUT,
    ) -> Task:
        """Submit + poll in one call. This is the sync-feeling happy path
        most integrators will use. Internally it's still async on the
        server — the SDK just hides the polling loop.

        Raises:
            TaskFailed: the task terminated with status=failed.
            TaskTimeout: the poll deadline expired before the task
                reached a terminal state. The still-running Task record
                is attached as ``.task`` so callers can keep polling.
        """
        submission = self.submit(
            end_user_id=end_user_id,
            task=task,
            session_id=session_id,
            start_url=start_url,
            schema=schema,
            max_steps=max_steps,
            include_html_dump=include_html_dump,
        )
        deadline = time.monotonic() + max(1.0, poll_timeout)
        current = submission
        while time.monotonic() < deadline:
            current = self.get(submission.task_id)
            if current.is_terminal:
                if current.status == "failed":
                    raise TaskFailed(current.error or "Task failed", task=current)
                return current
            time.sleep(poll_interval)
        raise TaskTimeout(
            f"Task {submission.task_id} did not terminate within {poll_timeout}s",
            task=current,
        )

    def stream(self, *_args: Any, **_kw: Any) -> Any:
        """Placeholder — the server-sent events path is not shipped yet.
        When SSE lands on GET /v1/tasks/{taskId}/stream, this method will
        yield step events. Today callers should use .get() in a loop."""
        raise NotImplementedError(
            "Streaming not shipped yet — poll client.tasks.get(task_id) instead.",
        )


# ── Sessions ─────────────────────────────────────────────────────────────


class _Sessions:
    def __init__(self, client: Stablebrowse) -> None:
        self._c = client

    def get(self, session_id: str) -> SessionTasks:
        res = self._c._request("GET", f"/sessions/{session_id}")
        return SessionTasks.from_json(res or {})


# ── End users / credentials ──────────────────────────────────────────────


class _EndUserRef:
    def __init__(self, client: Stablebrowse, end_user_id: str) -> None:
        self._c = client
        self._id = end_user_id
        self.credentials = _EndUserCreds(client, end_user_id)


class _EndUserCreds:
    def __init__(self, client: Stablebrowse, end_user_id: str) -> None:
        self._c = client
        self._id = end_user_id

    def set(self, **fields: str) -> None:
        """Upsert credentials for this end-user. Any combination of:
            twitter_auth_token, twitter_ct0,
            reddit_session,
            tiktok_session_id, tiktok_csrf_token,
            instagram_session_id, instagram_csrf_token, instagram_ds_user_id.

        Snake-case keys are converted to the API's camelCase on the wire so
        Python callers get idiomatic argument names.
        """
        if not fields:
            return
        # snake_case → camelCase for the wire.
        def camel(s: str) -> str:
            parts = s.split("_")
            return parts[0] + "".join(p.title() for p in parts[1:])
        body = {camel(k): v for k, v in fields.items() if v is not None}
        if not body:
            return
        self._c._request("PUT", f"/end-users/{self._id}/credentials", json=body)

    def get(self) -> CredentialStatus:
        res = self._c._request("GET", f"/end-users/{self._id}/credentials")
        return CredentialStatus.from_json(res or {})

    def delete(self, fields: list[str] | None = None) -> None:
        """Remove credentials. Pass `fields=[...]` to clear a subset, or
        omit to wipe every credential for this end-user."""
        body: dict[str, Any] = {}
        if fields:
            def camel(s: str) -> str:
                parts = s.split("_")
                return parts[0] + "".join(p.title() for p in parts[1:])
            body = {"fields": [camel(f) for f in fields]}
        self._c._request("DELETE", f"/end-users/{self._id}/credentials", json=body or None)


