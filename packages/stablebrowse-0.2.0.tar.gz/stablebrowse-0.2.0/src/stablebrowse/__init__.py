"""Python client for the stablebrowse browser agent API.

Typical use::

    from stablebrowse import Stablebrowse

    client = Stablebrowse(api_key="sb_live_...")

    # Upload per-end-user social-media credentials (optional).
    client.end_users("alice").credentials.set(
        twitter_auth_token="...",
        twitter_ct0="...",
    )

    # Sync-feeling submit: polls internally until the task terminates.
    result = client.tasks.run(
        end_user_id="alice",
        task="find the top AI tweets today",
    )
    print(result.result)

    # Or the raw async primitives if you want to drive the poll loop yourself.
    submission = client.tasks.submit(end_user_id="alice", task="...")
    task = client.tasks.get(submission.task_id)
"""

from .client import Stablebrowse
from .errors import StablebrowseError, TaskFailed, TaskTimeout
from .types import (
    CredentialStatus,
    SessionTasks,
    Task,
)

__all__ = [
    "Stablebrowse",
    "StablebrowseError",
    "TaskFailed",
    "TaskTimeout",
    "CredentialStatus",
    "SessionTasks",
    "Task",
]
