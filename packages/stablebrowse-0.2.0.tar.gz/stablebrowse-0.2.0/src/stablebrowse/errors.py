"""Exceptions raised by the stablebrowse client."""

from __future__ import annotations


class StablebrowseError(Exception):
    """Base class for every error the SDK raises.

    Inherits from Exception so callers can catch a single type. HTTP errors
    carry the status code and (if the server returned JSON) the parsed body.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        body: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class TaskFailed(StablebrowseError):
    """Raised by `client.tasks.run` when the task terminates in status=failed.

    The failed Task record is attached so the caller can inspect the error
    message, visited URLs, step summaries, etc.
    """

    def __init__(self, message: str, *, task) -> None:
        super().__init__(message)
        self.task = task


class TaskTimeout(StablebrowseError):
    """Raised by `client.tasks.run` when the poll deadline is reached before
    the task terminates. The in-progress Task record (status may still be
    "running") is attached so the caller can keep polling if they want to.
    """

    def __init__(self, message: str, *, task) -> None:
        super().__init__(message)
        self.task = task
