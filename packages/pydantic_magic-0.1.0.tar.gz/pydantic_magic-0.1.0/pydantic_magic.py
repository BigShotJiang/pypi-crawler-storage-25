import importlib
import re
from collections import defaultdict
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Self, cast

from pydantic import (
    BaseModel,
    Field,
    ModelWrapValidatorHandler,
    ValidationInfo,
    ValidatorFunctionWrapHandler,
    WrapValidator,
    model_validator,
)
from pydantic.config import ExtraValues

__all__ = ["MagicModel", "NamedMagicModel", "MagicInstanceContext", "MagicContextFrame"]

META_ATTR = "_meta_model_"
SUBCLS_ATTR = "_subclass_map_"
DEFAULT_ATTR = "_default_"
ABSTRACT_ATTR = "_abstract_"
CLASS_DISCRIMINATOR_ATTR = "_key_"
DEFAULT_CLASS_DISCRIMINATOR = "type"

_unspecified = object()


MagicContextFrame = dict[type["NamedMagicModel"], dict[str, "NamedMagicModel"]]


def to_snake(s: str) -> str:
    """Converts a pascal or camel case string into snake case."""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", s).lower()


def import_from_module[T](fqn: str, kind: type[T]) -> T:
    """Import a value by name from a dotted module path."""
    if "." not in fqn:
        raise ValueError(f"'{fqn}' is not a dotted path like 'pkg.mod.fn'")
    mod_path, attr = fqn.rsplit(".", 1)
    mod = importlib.import_module(mod_path, package="smagentic")
    val = getattr(mod, attr)
    if not isinstance(val, kind):
        raise ValueError(f"Value at {fqn!r} is not an instance of {kind.__name__}")
    return val


def _is_parameterized_variant(cls: type) -> bool:
    # NB: Pydantic prevents us from using __origin__ and __pydantic_generic_metadata__ is not
    # populated by __init_subclass__, so we need to check ourselves.
    if getattr(cls, "__origin__", None):
        return True
    if getattr(cls, "__pydantic_generic_metadata__", {}).get("origin", None):
        return True
    return "[" in cls.__name__


@dataclass
class MagicInstanceContext:
    """Provides heirarchical registration and lookup for NamedMagicModels. Used by default as the
    context for MagicModel validation. Every MagicModel creates a new "frame" when validating and
    if the validated model instance has a name, it is registered in by type and name in the frame
    of the model containing it. Once registered, sub-models can then reference those named models
    by string name.
    """

    context_stack: list[MagicContextFrame] = field(default_factory=list)

    def get[T: NamedMagicModel](self, cls: type[T], key: str) -> T | None:
        for context in reversed(self.context_stack):
            if cls in context and key in context[cls]:
                return cast(T, context[cls][key])
        return None

    def put[T: NamedMagicModel](self, cls: type[T], instance: T) -> None:
        if not self.context_stack:
            return
        instance_map = self.context_stack[-1][cls]
        if (existing := instance_map.get(instance.name)) and existing != instance:
            msg = f"Key {instance.name!r} already registered in current frame for {cls.__name__}"
            raise ValueError(msg)
        instance_map[instance.name] = instance

    def get_names_for_type[T: NamedMagicModel](self, cls: type[T]) -> Iterator[str]:
        for context in self.context_stack:
            yield from context[cls]

    def _push_frame(self) -> Self:
        self.context_stack.append(defaultdict(dict))
        return self

    def _pop_frame(self) -> Self:
        self.context_stack.pop()
        return self

    @classmethod
    def get_context(cls, info: ValidationInfo) -> MagicInstanceContext | None:
        return info.context if isinstance(info.context, MagicInstanceContext) else None

    def find_registered_type(self, key: str) -> type[NamedMagicModel] | None:
        """Find the most specific type under which `key` is registered in any frame."""
        for frame in reversed(self.context_stack):
            found = (cls for cls, instances in frame.items() if key in instances)
            return max(found, key=lambda c: len(c.__mro__), default=None)
        return None

    @classmethod
    @contextmanager
    def enter_frame(cls, info: ValidationInfo) -> Iterator[MagicInstanceContext | None]:
        if context := cls.get_context(info):
            context._push_frame()
            try:
                yield context
            finally:
                context._pop_frame()
        else:
            yield None


class MagicModel(BaseModel):
    """BaseModel variant which allows a model to be validated into any of its subclasses based on a given field
    rather than a discriminated union. By default, this field is "type" but this can be changed by passing an
    argument to the base model during creation:

        class Foo(MagicModel, key='kind'):
            pass

        class Bar(Foo):
            pass

        In : Foo.model_validate(kind='bar')
        Out: Bar(kind='bar')
        In : Bar()
        Out: Bar(kind='bar')

    The identifying name can be automatically determined from the class names or explicitly provided as `key=abc`
    for child classes. This field is injected into the model and is present in the serialized dict to support
    round tripping. It is an error to explicitly construct a subclass with the wrong identifier. Any logic relying
    on subclass discrimination should construct instances with `model_validate`.

    Extensions to MagicModel, such as NamedMagicModel, should provide meta=True without any other options. By default,
    model_validate will use MagicInstanceContext, which causes NamedMagicModel instances to be registered and available
    to other models nested under the same parent model. This can be disabled by providing any other context, including
    None. If the data being validated is a string starting with '%', the rest of the string between is loaded as a
    dotted path whose final part should correspond to an instance of the type being validated.
    """

    def get_type_key(self) -> str:
        return getattr(self, self.get_class_discriminator())

    @classmethod
    def get_class_discriminator(cls) -> str:
        return getattr(cls, CLASS_DISCRIMINATOR_ATTR) or DEFAULT_CLASS_DISCRIMINATOR

    @classmethod
    def get_meta_model(cls) -> type[MagicModel]:
        return getattr(cls, META_ATTR, MagicModel)

    @classmethod
    def get_base_model(cls: type[MagicModel]) -> type[MagicModel]:
        meta = cls.get_meta_model()
        index = cls.mro().index(meta)
        if index == 0:
            raise ValueError("No base for meta model")
        base = cls.mro()[index - 1]
        if not issubclass(base, MagicModel):
            raise ValueError(f"Found invalid base {base}")
        return base

    @classmethod
    def is_abstract(cls) -> bool:
        # NB: Only check cls and not its parents
        return getattr(cls, ABSTRACT_ATTR) if ABSTRACT_ATTR in dir(cls) else False

    @classmethod
    def get_default_impl(cls) -> str:
        return getattr(cls, DEFAULT_ATTR) if DEFAULT_ATTR in dir(cls) else ""

    @classmethod
    def _register_subclass(cls, key: str) -> str:
        base = cls.get_base_model()
        key = key or to_snake(cls.__name__.replace(base.__name__, ""))
        if not key:
            raise ValueError(f"Cannot determine key for {cls}, explicit value required")
        subclasses = getattr(base, SUBCLS_ATTR)
        if (existing := subclasses.get(key, cls)) and cls != existing:
            raise ValueError(
                f"{key} ({cls}) already registered by {existing} for {base}"
            )
        subclasses[key] = cls
        return key

    @classmethod
    def _get_subclass(cls, name: str) -> type[Self] | None:
        return cast(type[Self], getattr(cls, SUBCLS_ATTR).get(name))

    def __init_subclass__(
        cls,
        /,
        key: str = "",
        abstract: bool = False,
        default: str = "",
        meta: bool = False,
        **kwargs,
    ) -> None:
        super().__init_subclass__(**kwargs)
        if _is_parameterized_variant(cls):
            return  # Quit early to avoid registering subscripted variant
        if meta:
            if any((key, abstract, default)):
                raise ValueError(f"{cls}: 'meta' incompatible with other options")
            setattr(cls, META_ATTR, cls)
            return
        setattr(cls, ABSTRACT_ATTR, abstract)
        setattr(cls, DEFAULT_ATTR, default)
        if cls == cls.get_base_model():
            setattr(cls, SUBCLS_ATTR, {})
            setattr(cls, CLASS_DISCRIMINATOR_ATTR, key)
        else:
            key = cls._register_subclass(key)
            discriminator = cls.get_class_discriminator()
            if not hasattr(cls, discriminator):
                cls.__annotations__[discriminator] = str
                setattr(cls, discriminator, Field(default=key))

    @model_validator(mode="wrap")
    @classmethod
    def _parse_into_subclass(
        cls,
        data: Any,
        handler: ValidatorFunctionWrapHandler,
        info: ValidationInfo,
    ) -> Self:
        if cls == cls.get_meta_model():
            raise ValueError("Meta model cannot be instantiated")
        if not isinstance(data, dict):
            with MagicInstanceContext.enter_frame(info):
                if isinstance(data, str) and data.startswith("%"):
                    path = data[1:]
                    data = import_from_module(path, cls).model_copy()
                    if isinstance(data, NamedMagicModel) and not data.name:
                        data.name = path.rsplit(".", 1)[1]
                return handler(data)
        base = cls.get_base_model()
        discriminator = cls.get_class_discriminator()
        key = data.get(discriminator, cls.get_default_impl())
        subcls = base._get_subclass(key)
        if subcls:
            if issubclass(subcls, cls):
                if subcls != cls:
                    return subcls.model_validate(data, context=info.context)
                # subcls == cls falls through to final handler(data)
            else:
                msg = f"Key {key!r} resolved to {subcls.__name__} which is not a subclass of {cls.__name__}"
                raise ValueError(msg)
        elif key:
            ok = sorted(
                name
                for name, subcls in getattr(base, SUBCLS_ATTR).items()
                if issubclass(subcls, cls)
            )
            msg = (
                f"Unknown key {key!r} for class {cls.__name__} (ok: [{', '.join(ok)}])"
            )
            raise ValueError(msg)
        elif cls.is_abstract():
            msg = f"Abstract {cls.__name__} cannot be instanced"
            raise ValueError(msg)
        with MagicInstanceContext.enter_frame(info):
            return handler(data)

    def model_dump(self, **kwargs) -> dict[str, Any]:
        return super().model_dump(serialize_as_any=True, **kwargs)

    def model_dump_json(self, **kwargs) -> str:
        return super().model_dump_json(serialize_as_any=True, **kwargs)

    @classmethod
    def model_validate(
        cls,
        obj: Any,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        from_attributes: bool | None = None,
        context: Any = _unspecified,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        if context == _unspecified:
            context = MagicInstanceContext()
        return super().model_validate(
            obj,
            strict=strict,
            extra=extra,
            from_attributes=from_attributes,
            context=context,
            by_alias=by_alias,
            by_name=by_name,
        )

    @classmethod
    def model_validate_json(
        cls,
        json_data: str | bytes | bytearray,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        context: Any = _unspecified,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        if context == _unspecified:
            context = MagicInstanceContext()
        return super().model_validate_json(
            json_data,
            strict=strict,
            extra=extra,
            context=context,
            by_alias=by_alias,
            by_name=by_name,
        )


class NamedMagicModel(MagicModel, meta=True):
    """Specialized MagicModel which always has a string name field. If validating with a
    MagicInstanceContext context, instances are registered by name into it and strings
    resolve to existing instances if they match a registered name.
    """

    name: str = Field(default="")

    @model_validator(mode="wrap")
    @classmethod
    def _resolve_or_update_instance_map(
        cls, value: Any, handler: ModelWrapValidatorHandler, info: ValidationInfo
    ) -> Self:
        magic_context = MagicInstanceContext.get_context(info)
        if isinstance(value, str) and not value.startswith("%") and magic_context:
            if instance := magic_context.get(cls, value):
                return instance
            else:
                options = sorted(set(magic_context.get_names_for_type(cls)))
                msg = f"No instance {value!r} for {cls.__name__}, valid keys are {options}"
                if found_as := magic_context.find_registered_type(value):
                    msg += f"; {value!r} is registered as {found_as.__name__}"
                raise ValueError(msg)
        # Note: This handler calls the base MagicModel wrap validator which handles the context
        # frame for this instance. After handler returns, we are back in the parent frame so the
        # call to magic_context.put only registers in the parent, if there is one. The base wrap
        # validator does not enter a new context frame when switching from a base to a concrete
        # type, so if a subclass is instanced via its base class this method will be invoked for
        # and the instance will be registered for both classes.
        instance = handler(value)
        if instance.name and magic_context:
            magic_context.put(cls, instance)
        return instance

    @classmethod
    def meta_from_key(
        cls, kind_sep: str = ":", update_key: bool = False
    ) -> WrapValidator:
        """Validator for dict[str, NamedMagicModel] fields which uses the string key to determine a
        name and optionally type to use when validating the NamedMagicModel instance. This only affects
        values which are themselves also dictionaries, before model validation. If update_key is passed,
        the validated dictionary uses the validated instance name as the key of the resulting dictionary.
        A ValueError is raised if this is enabled and causes a key collision.
        """

        def validator(
            value: Any, handler: ModelWrapValidatorHandler, info: ValidationInfo
        ) -> Any:
            if not isinstance(value, dict):
                return handler(value)
            new_map = {}
            for k, v in value.items():
                new_v = v
                if isinstance(k, str) and isinstance(v, dict):
                    new_v = dict(v)
                    if kind_sep and kind_sep in k:
                        kind, name = k.split(kind_sep, 1)
                    else:
                        kind, name = "", k
                    name = new_v.setdefault("name", name)
                    disc = cls.get_class_discriminator()
                    if kind and disc not in new_v:
                        new_v[disc] = kind
                new_v = cls.model_validate(new_v, context=info.context)
                if update_key and new_v.name:
                    k = new_v.name
                if k in new_map:
                    raise ValueError(f"Key {k!r} already in validated map")
                new_map[k] = new_v

            return handler(new_map)

        return WrapValidator(validator)
