from typing import Annotated
from unittest import TestCase

from pydantic import Field, ValidationError

from pydantic_magic import DEFAULT_ATTR, MagicModel, NamedMagicModel


def unpack_validation_error(exc: ValidationError) -> Exception:
    return exc.errors()[0]["ctx"]["error"]


class A(MagicModel, abstract=True):
    a: int


class B(A):
    b: float


class C(A):
    c: str


top_level = C(a=321, c="c")


class Data(MagicModel):
    data: list[A]


class MagicModelTest(TestCase):
    def setUp(self):
        self.expected_b = B(a=123, b=3.14)
        self.expected_c = C(a=123, c="test")
        self.expected_data = Data(data=[self.expected_b, self.expected_c])
        self.raw_b = dict(type="b", a=123, b=3.14)
        self.raw_c = dict(type="c", a=123, c="test")
        self.raw_data = dict(data=[self.raw_b, self.raw_c])

    def test_subclass_redirect(self):
        self.assertEqual(self.expected_b, A.model_validate(self.raw_b))
        self.assertEqual(self.expected_c, A.model_validate(self.raw_c))
        self.assertEqual(self.raw_b, self.expected_b.model_dump())
        self.assertEqual(self.raw_c, self.expected_c.model_dump())

    def test_import_path_resolution(self):
        absolute = A.model_validate("%tests.test_pydantic_magic.top_level")
        self.assertEqual(top_level, absolute)
        self.assertIsNot(top_level, absolute)

    def test_nested_resolution(self):
        self.assertEqual(self.expected_data, Data.model_validate(self.raw_data))
        self.assertEqual(self.raw_data, self.expected_data.model_dump())

    def test_base_init_error(self):
        with self.assertRaises(ValidationError) as exc_info:
            MagicModel()
        exc = unpack_validation_error(exc_info.exception)
        self.assertEqual("Meta model cannot be instantiated", str(exc))

    def test_abstract_init_error(self):
        with self.assertRaises(ValidationError) as exc_info:
            A(a=123)
        exc = unpack_validation_error(exc_info.exception)
        expected = "Abstract A cannot be instanced"
        self.assertEqual(expected, str(exc))

    def test_init_default(self):
        setattr(A, DEFAULT_ATTR, "b")
        b = A.model_validate(dict(a=123, b=1.23))
        self.assertIsInstance(b, B)
        setattr(A, DEFAULT_ATTR, "")

    def test_unknown_key_error(self):
        with self.assertRaises(ValidationError) as exc_info:
            A.model_validate({"type": "d"})
        exc = unpack_validation_error(exc_info.exception)
        self.assertEqual("Unknown key 'd' for class A (ok: [b, c])", str(exc))

    def test_wrong_key_error(self):
        with self.assertRaises(ValidationError) as exc_info:
            B.model_validate({"type": "d"})
        exc = unpack_validation_error(exc_info.exception)
        self.assertEqual("Unknown key 'd' for class B (ok: [b])", str(exc))


class FooBar(NamedMagicModel, abstract=True):
    value: int


class FizzFooBar(FooBar):
    pass


class BuzzFooBar(FooBar):
    pass


class FoobarContainer(MagicModel):
    foobars: Annotated[dict[str, FooBar], FooBar.meta_from_key(update_key=True)]
    favorite: FooBar
    sub_container: FoobarContainer | None = Field(default=None)


class NoUpdateKeyFoobarContainer(MagicModel):
    foobars: Annotated[dict[str, FooBar], FooBar.meta_from_key()]


class ForwardRefContainer(MagicModel):
    # favorite appears before foobars — tests forward reference resolution
    favorite: FooBar
    foobars: Annotated[dict[str, FooBar], FooBar.meta_from_key(update_key=True)]


class BuzzOnlyContainer(MagicModel):
    foobars: Annotated[dict[str, FooBar], FooBar.meta_from_key(update_key=True)]
    favorite_buzz: BuzzFooBar


top_level_fizz = FizzFooBar(value=321)
top_level_buzz = BuzzFooBar(value=456)


class NamedMagicModelTest(TestCase):
    def test_context_registration_and_string_resolution(self):
        raw = {
            "foobars": {"fizz:a": {"value": 1}, "buzz:b": {"value": 2}},
            "favorite": "b",
        }
        container = FoobarContainer.model_validate(raw)
        assert set(container.foobars.keys()) == {"a", "b"}
        a = container.foobars["a"]
        b = container.foobars["b"]
        self.assertEqual(a, FizzFooBar(name="a", value=1))
        self.assertEqual(b, BuzzFooBar(name="b", value=2))
        self.assertEqual(container.favorite, b)

    def test_nested_models_namespaced_resolution(self):
        raw = {
            "foobars": {"fizz:a": {"value": 1}},
            "favorite": "a",
            "sub_container": {"foobars": {"fizz:a": {"value": 2}}, "favorite": "a"},
        }
        container = FoobarContainer.model_validate(raw)
        self.assertIsInstance(container.favorite, FizzFooBar)
        self.assertEqual(container.favorite.value, 1)
        assert container.sub_container
        self.assertIsInstance(container.sub_container.favorite, FizzFooBar)
        self.assertEqual(container.sub_container.favorite.value, 2)

    def test_registered_instance_name_conflict(self):
        raw = {"foobars": {"fizz:a": {"value": 1}, "a": {"type": "fizz", "value": 2}}}
        with self.assertRaises(ValidationError) as exc_info:
            NoUpdateKeyFoobarContainer.model_validate(raw)
        exc = unpack_validation_error(exc_info.exception)
        expected = "Key 'a' already registered in current frame for FizzFooBar"
        self.assertEqual(str(exc), expected)

    def test_top_level_named_model_validation(self):
        # Validating a NamedMagicModel as root (no parent MagicModel) should not raise
        raw = {"type": "fizz", "name": "standalone", "value": 42}
        instance = FooBar.model_validate(raw)
        self.assertIsInstance(instance, FizzFooBar)
        self.assertEqual(instance.name, "standalone")

    def test_forward_reference_order_error(self):
        # 'favorite' field is defined before 'foobars', so the reference cannot be resolved
        raw = {"favorite": "a", "foobars": {"fizz:a": {"value": 1}}}
        with self.assertRaises(ValidationError) as exc_info:
            ForwardRefContainer.model_validate(raw)
        exc = unpack_validation_error(exc_info.exception)
        self.assertIn("valid keys are []", str(exc))

    def test_string_reference_not_found(self):
        raw = {"foobars": {"fizz:a": {"value": 1}}, "favorite": "missing"}
        with self.assertRaises(ValidationError) as exc_info:
            FoobarContainer.model_validate(raw)
        exc = unpack_validation_error(exc_info.exception)
        self.assertIn("'missing'", str(exc))
        self.assertIn("valid keys are ['a']", str(exc))

    def test_concrete_type_mismatch_hint(self):
        # 'a' is registered as FizzFooBar but favorite_buzz expects BuzzFooBar
        raw = {"foobars": {"fizz:a": {"value": 1}}, "favorite_buzz": "a"}
        with self.assertRaises(ValidationError) as exc_info:
            BuzzOnlyContainer.model_validate(raw)
        exc = unpack_validation_error(exc_info.exception)
        self.assertIn("FizzFooBar", str(exc))

    def test_dict_instance_name_conflict(self):
        raw = {
            "foobars": {"fizz:a": {"value": 1}, "a": {"type": "fizz", "value": 2}},
            "favorite": "a",
        }
        with self.assertRaises(ValidationError) as exc_info:
            NoUpdateKeyFoobarContainer.model_validate(raw)
        exc = unpack_validation_error(exc_info.exception)
        expected = "Key 'a' already registered in current frame for FizzFooBar"
        self.assertEqual(str(exc), expected)

    def test_named_import_path_resolution(self):
        instance = FooBar.model_validate("%tests.test_pydantic_magic.top_level_fizz")
        self.assertEqual(instance.value, top_level_fizz.value)
        self.assertEqual(instance.name, "top_level_fizz")  # Module name is injected
        self.assertEqual(top_level_fizz.name, "")  # Original value not modified

        raw = {
            "foobars": {"fubar": "%tests.test_pydantic_magic.top_level_fizz"},
            "favorite": "top_level_fizz",
        }
        container = FoobarContainer.model_validate(raw)
        # Name is not overridden by dict key
        instance = container.favorite
        self.assertEqual(instance.name, "top_level_fizz")
        # update_key uses the instance name
        self.assertEqual(container.foobars, {"top_level_fizz": instance})
        self.assertEqual(top_level_fizz.name, "")  # Original value not modified

    def test_named_import_invalid_path_error(self):
        with self.assertRaises(ValidationError) as exc_info:
            FizzFooBar.model_validate("%badness")
        exc = unpack_validation_error(exc_info.exception)
        expected = "'badness' is not a dotted path like 'pkg.mod.fn'"
        self.assertEqual(str(exc), expected)

    def test_named_import_wrong_type_error(self):
        with self.assertRaises(ValidationError) as exc_info:
            FizzFooBar.model_validate("%tests.test_pydantic_magic.top_level_buzz")
        exc = unpack_validation_error(exc_info.exception)
        expected = "Value at 'tests.test_pydantic_magic.top_level_buzz' is not an instance of FizzFooBar"
        self.assertEqual(str(exc), expected)
