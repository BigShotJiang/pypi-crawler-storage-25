# arac_verisi.py - HUSUSİ ARAÇLAR PART 1
# Kullanım Kodları: 1: Hususi, 2: Taksi

arac_filtresi = {
    # --- FIAT ---
    'Fiat-Egea-Sedan': {'seg': 'C', 'izin': [1, 2], 'yil': 2015},
    'Fiat-Egea-Hatchback': {'seg': 'C', 'izin': [1], 'yil': 2016},
    'Fiat-Egea-Cross': {'seg': 'C', 'izin': [1], 'yil': 2020},
    'Fiat-Linea': {'seg': 'C', 'izin': [1, 2], 'yil': 2007},
    'Fiat-Albea': {'seg': 'B', 'izin': [1, 2], 'yil': 2002},
    'Fiat-Palio': {'seg': 'B', 'izin': [1], 'yil': 1996},
    'Fiat-Panda': {'seg': 'A', 'izin': [1], 'yil': 1980},
    'Fiat-500': {'seg': 'A', 'izin': [1], 'yil': 2007},
    'Fiat-500L': {'seg': 'C', 'izin': [1], 'yil': 2012},
    'Fiat-500X': {'seg': 'C', 'izin': [1], 'yil': 2014},
    'Fiat-Punto': {'seg': 'B', 'izin': [1], 'yil': 1993},
    'Fiat-Bravo': {'seg': 'C', 'izin': [1], 'yil': 1995},
    'Fiat-Marea': {'seg': 'D', 'izin': [1], 'yil': 1996},
    'Fiat-Tempra': {'seg': 'C', 'izin': [1], 'yil': 1990},
    'Fiat-Tipo': {'seg': 'C', 'izin': [1], 'yil': 1988},

    # --- RENAULT ---
    'Renault-Clio': {'seg': 'B', 'izin': [1, 2], 'yil': 1990},
    'Renault-Megane-Sedan': {'seg': 'C', 'izin': [1, 2], 'yil': 1995},
    'Renault-Megane-Hatchback': {'seg': 'C', 'izin': [1], 'yil': 1995},
    'Renault-Taliant': {'seg': 'B', 'izin': [1, 2], 'yil': 2021},
    'Renault-Symbol': {'seg': 'B', 'izin': [1, 2], 'yil': 1999},
    'Renault-Fluence': {'seg': 'C', 'izin': [1, 2], 'yil': 2009},
    'Renault-Captur': {'seg': 'B', 'izin': [1], 'yil': 2013},
    'Renault-Austral': {'seg': 'C', 'izin': [1], 'yil': 2022},
    'Renault-Kadjar': {'seg': 'C', 'izin': [1], 'yil': 2015},
    'Renault-Koleos': {'seg': 'D', 'izin': [1], 'yil': 2007},
    'Renault-Talisman': {'seg': 'D', 'izin': [1], 'yil': 2015},
    'Renault-Zoe': {'seg': 'B', 'izin': [1], 'yil': 2012},
    'Renault-Scenic': {'seg': 'C', 'izin': [1], 'yil': 1996},
    'Renault-Grand-Scenic': {'seg': 'C', 'izin': [1], 'yil': 2003},
    'Renault-Laguna': {'seg': 'D', 'izin': [1], 'yil': 1993},
    'Renault-Latitude': {'seg': 'D', 'izin': [1], 'yil': 2010},
    'Renault-R9-Broadway': {'seg': 'B', 'izin': [1, 2], 'yil': 1981},
    'Renault-R19-Europa': {'seg': 'C', 'izin': [1, 2], 'yil': 1988},
    'Renault-R21-Manager': {'seg': 'D', 'izin': [1], 'yil': 1986},
    'Renault-Modus': {'seg': 'B', 'izin': [1], 'yil': 2004},

    # --- VOLKSWAGEN ---
    'Volkswagen-Polo': {'seg': 'B', 'izin': [1, 2], 'yil': 1975},
    'Volkswagen-Golf': {'seg': 'C', 'izin': [1], 'yil': 1974},
    'Volkswagen-Passat': {'seg': 'D', 'izin': [1, 2], 'yil': 1973},
    'Volkswagen-Jetta': {'seg': 'C', 'izin': [1, 2], 'yil': 1979},
    'Volkswagen-Tiguan': {'seg': 'C', 'izin': [1], 'yil': 2007},
    'Volkswagen-T-Roc': {'seg': 'B', 'izin': [1], 'yil': 2017},
    'Volkswagen-Taigo': {'seg': 'B', 'izin': [1], 'yil': 2021},
    'Volkswagen-Arteon': {'seg': 'D', 'izin': [1], 'yil': 2017},
    'Volkswagen-Touareg': {'seg': 'E', 'izin': [1], 'yil': 2002},
    'Volkswagen-Scirocco': {'seg': 'C', 'izin': [1], 'yil': 1974},
    'Volkswagen-Beetle': {'seg': 'C', 'izin': [1], 'yil': 1938},
    'Volkswagen-Bora': {'seg': 'C', 'izin': [1, 2], 'yil': 1998},
    'Volkswagen-Vento': {'seg': 'C', 'izin': [1], 'yil': 1992},
    'Volkswagen-ID.3': {'seg': 'C', 'izin': [1], 'yil': 2019},
    'Volkswagen-ID.4': {'seg': 'C', 'izin': [1], 'yil': 2020},

    # --- TOYOTA ---
    'Toyota-Corolla': {'seg': 'C', 'izin': [1, 2], 'yil': 1966},
    'Toyota-Yaris': {'seg': 'B', 'izin': [1, 2], 'yil': 1999},
    'Toyota-Yaris-Cross': {'seg': 'B', 'izin': [1], 'yil': 2020},
    'Toyota-Auris': {'seg': 'C', 'izin': [1], 'yil': 2006},
    'Toyota-C-HR': {'seg': 'C', 'izin': [1], 'yil': 2016},
    'Toyota-Rav4': {'seg': 'D', 'izin': [1], 'yil': 1994},
    'Toyota-Avensis': {'seg': 'D', 'izin': [1], 'yil': 1997},
    'Toyota-Camry': {'seg': 'E', 'izin': [1], 'yil': 1982},
    'Toyota-Land-Cruiser': {'seg': 'E', 'izin': [1], 'yil': 1951},
    'Toyota-Hilux-SW': {'seg': 'D', 'izin': [1], 'yil': 1968},
    'Toyota-Verso': {'seg': 'C', 'izin': [1], 'yil': 2009},

    # --- HYUNDAI ---
    'Hyundai-i10': {'seg': 'A', 'izin': [1], 'yil': 2007},
    'Hyundai-i20': {'seg': 'B', 'izin': [1, 2], 'yil': 2008},
    'Hyundai-i30': {'seg': 'C', 'izin': [1], 'yil': 2007},
    'Hyundai-Accent-Era': {'seg': 'B', 'izin': [1, 2], 'yil': 2006},
    'Hyundai-Accent-Blue': {'seg': 'B', 'izin': [1, 2], 'yil': 2011},
    'Hyundai-Elantra': {'seg': 'C', 'izin': [1, 2], 'yil': 1990},
    'Hyundai-Tucson': {'seg': 'C', 'izin': [1], 'yil': 2004},
    'Hyundai-Santa-Fe': {'seg': 'D', 'izin': [1], 'yil': 2000},
    'Hyundai-Kona': {'seg': 'B', 'izin': [1], 'yil': 2017},
    'Hyundai-Bayon': {'seg': 'B', 'izin': [1], 'yil': 2021},
    'Hyundai-Getz': {'seg': 'B', 'izin': [1], 'yil': 2002},
    'Hyundai-Starex-Hususi': {'seg': 'D', 'izin': [1], 'yil': 1997},
    'Hyundai-Ioniq-5': {'seg': 'D', 'izin': [1], 'yil': 2021},
    'Hyundai-Ioniq-6': {'seg': 'D', 'izin': [1], 'yil': 2022}
}
# arac_verisi.py - HUSUSİ ARAÇLAR PART 2
# Kullanım Kodları: 1: Hususi, 2: Taksi

arac_filtresi.update({
    # --- BMW ---
    'BMW-1-Serisi': {'seg': 'C', 'izin': [1], 'yil': 2004},
    'BMW-2-Serisi': {'seg': 'C', 'izin': [1], 'yil': 2014},
    'BMW-3-Serisi': {'seg': 'D', 'izin': [1], 'yil': 1975},
    'BMW-4-Serisi': {'seg': 'D', 'izin': [1], 'yil': 2013},
    'BMW-5-Serisi': {'seg': 'E', 'izin': [1], 'yil': 1972},
    'BMW-7-Serisi': {'seg': 'E', 'izin': [1], 'yil': 1977},
    'BMW-X1': {'seg': 'C', 'izin': [1], 'yil': 2009},
    'BMW-X2': {'seg': 'C', 'izin': [1], 'yil': 2017},
    'BMW-X3': {'seg': 'D', 'izin': [1], 'yil': 2003},
    'BMW-X5': {'seg': 'E', 'izin': [1], 'yil': 1999},
    'BMW-i3': {'seg': 'B', 'izin': [1], 'yil': 2013},
    'BMW-i4': {'seg': 'D', 'izin': [1], 'yil': 2021},

    # --- MERCEDES-BENZ ---
    'Mercedes-A-Serisi': {'seg': 'C', 'izin': [1], 'yil': 1997},
    'Mercedes-B-Serisi': {'seg': 'C', 'izin': [1], 'yil': 2005},
    'Mercedes-C-Serisi': {'seg': 'D', 'izin': [1], 'yil': 1993},
    'Mercedes-E-Serisi': {'seg': 'E', 'izin': [1], 'yil': 1953},
    'Mercedes-S-Serisi': {'seg': 'E', 'izin': [1], 'yil': 1954},
    'Mercedes-CLA': {'seg': 'C', 'izin': [1], 'yil': 2013},
    'Mercedes-CLS': {'seg': 'E', 'izin': [1], 'yil': 2004},
    'Mercedes-GLA': {'seg': 'C', 'izin': [1], 'yil': 2013},
    'Mercedes-GLC': {'seg': 'D', 'izin': [1], 'yil': 2015},
    'Mercedes-EQS': {'seg': 'E', 'izin': [1], 'yil': 2021},

    # --- AUDI ---
    'Audi-A1': {'seg': 'B', 'izin': [1], 'yil': 2010},
    'Audi-A3': {'seg': 'C', 'izin': [1], 'yil': 1996},
    'Audi-A4': {'seg': 'D', 'izin': [1], 'yil': 1994},
    'Audi-A5': {'seg': 'D', 'izin': [1], 'yil': 2007},
    'Audi-A6': {'seg': 'E', 'izin': [1], 'yil': 1994},
    'Audi-Q2': {'seg': 'B', 'izin': [1], 'yil': 2016},
    'Audi-Q3': {'seg': 'C', 'izin': [1], 'yil': 2011},
    'Audi-Q5': {'seg': 'D', 'izin': [1], 'yil': 2008},

    # --- PEUGEOT ---
    'Peugeot-206': {'seg': 'B', 'izin': [1], 'yil': 1998},
    'Peugeot-207': {'seg': 'B', 'izin': [1], 'yil': 2006},
    'Peugeot-208': {'seg': 'B', 'izin': [1], 'yil': 2012},
    'Peugeot-301': {'seg': 'B', 'izin': [1, 2], 'yil': 2012},
    'Peugeot-307': {'seg': 'C', 'izin': [1], 'yil': 2001},
    'Peugeot-308': {'seg': 'C', 'izin': [1], 'yil': 2007},
    'Peugeot-407': {'seg': 'D', 'izin': [1], 'yil': 2004},
    'Peugeot-408': {'seg': 'C', 'izin': [1], 'yil': 2010},
    'Peugeot-508': {'seg': 'D', 'izin': [1], 'yil': 2010},
    'Peugeot-2008': {'seg': 'B', 'izin': [1], 'yil': 2013},
    'Peugeot-3008': {'seg': 'C', 'izin': [1], 'yil': 2008},
    'Peugeot-5008': {'seg': 'D', 'izin': [1], 'yil': 2009},

    # --- OPEL ---
    'Opel-Corsa': {'seg': 'B', 'izin': [1, 2], 'yil': 1982},
    'Opel-Astra': {'seg': 'C', 'izin': [1, 2], 'yil': 1991},
    'Opel-Insignia': {'seg': 'D', 'izin': [1], 'yil': 2008},
    'Opel-Mokka': {'seg': 'B', 'izin': [1], 'yil': 2012},
    'Opel-Crossland': {'seg': 'B', 'izin': [1], 'yil': 2017},
    'Opel-Grandland': {'seg': 'C', 'izin': [1], 'yil': 2017},
    'Opel-Vectra': {'seg': 'D', 'izin': [1], 'yil': 1988},
    'Opel-Zafira': {'seg': 'C', 'izin': [1], 'yil': 1999},

    # --- SKODA ---
    'Skoda-Fabia': {'seg': 'B', 'izin': [1, 2], 'yil': 1999},
    'Skoda-Octavia': {'seg': 'C', 'izin': [1, 2], 'yil': 1996},
    'Skoda-Superb': {'seg': 'D', 'izin': [1, 2], 'yil': 2001},
    'Skoda-Kamiq': {'seg': 'B', 'izin': [1], 'yil': 2019},
    'Skoda-Karoq': {'seg': 'C', 'izin': [1], 'yil': 2017},
    'Skoda-Kodiaq': {'seg': 'D', 'izin': [1], 'yil': 2016},
    'Skoda-Scala': {'seg': 'C', 'izin': [1], 'yil': 2019},
    'Skoda-Rapid': {'seg': 'B', 'izin': [1, 2], 'yil': 2012},

    # --- FORD ---
    'Ford-Fiesta': {'seg': 'B', 'izin': [1], 'yil': 1976},
    'Ford-Focus': {'seg': 'C', 'izin': [1, 2], 'yil': 1998},
    'Ford-Mondeo': {'seg': 'D', 'izin': [1, 2], 'yil': 1992},
    'Ford-Puma': {'seg': 'B', 'izin': [1], 'yil': 1997},
    'Ford-Kuga': {'seg': 'C', 'izin': [1], 'yil': 2008},
    'Ford-Mustang': {'seg': 'E', 'izin': [1], 'yil': 1964},
    'Ford-Fusion': {'seg': 'B', 'izin': [1], 'yil': 2002},
    'Ford-Escort': {'seg': 'C', 'izin': [1], 'yil': 1968}
})
# arac_verisi.py - HUSUSİ ARAÇLAR PART 3
# Kullanım Kodları: 1: Hususi, 2: Taksi

arac_filtresi.update({
    # --- DACIA ---
    'Dacia-Sandero': {'seg': 'B', 'izin': [1, 2], 'yil': 2008},
    'Dacia-Duster': {'seg': 'C', 'izin': [1], 'yil': 2010},
    'Dacia-Logan': {'seg': 'B', 'izin': [1, 2], 'yil': 2004},
    'Dacia-Lodgy': {'seg': 'C', 'izin': [1, 2], 'yil': 2012},
    'Dacia-Jogger': {'seg': 'C', 'izin': [1], 'yil': 2022},
    'Dacia-Solenza': {'seg': 'B', 'izin': [1, 2], 'yil': 2003},

    # --- KIA ---
    'Kia-Rio': {'seg': 'B', 'izin': [1, 2], 'yil': 2000},
    'Kia-Ceed': {'seg': 'C', 'izin': [1], 'yil': 2006},
    'Kia-Sportage': {'seg': 'C', 'izin': [1], 'yil': 1993},
    'Kia-Stonic': {'seg': 'B', 'izin': [1], 'yil': 2017},
    'Kia-Picanto': {'seg': 'A', 'izin': [1], 'yil': 2004},
    'Kia-Cerato': {'seg': 'C', 'izin': [1, 2], 'yil': 2003},
    'Kia-Sorento': {'seg': 'D', 'izin': [1], 'yil': 2002},
    'Kia-Niro': {'seg': 'C', 'izin': [1], 'yil': 2016},

    # --- HONDA ---
    'Honda-Civic': {'seg': 'C', 'izin': [1, 2], 'yil': 1972},
    'Honda-City': {'seg': 'B', 'izin': [1, 2], 'yil': 1981},
    'Honda-Accord': {'seg': 'D', 'izin': [1], 'yil': 1976},
    'Honda-Jazz': {'seg': 'B', 'izin': [1], 'yil': 1982},
    'Honda-CR-V': {'seg': 'D', 'izin': [1], 'yil': 1995},
    'Honda-HR-V': {'seg': 'B', 'izin': [1], 'yil': 1998},

    # --- NISSAN ---
    'Nissan-Micra': {'seg': 'B', 'izin': [1], 'yil': 1982},
    'Nissan-Juke': {'seg': 'B', 'izin': [1], 'yil': 2010},
    'Nissan-Qashqai': {'seg': 'C', 'izin': [1], 'yil': 2006},
    'Nissan-X-Trail': {'seg': 'D', 'izin': [1], 'yil': 2000},
    'Nissan-Pulsar': {'seg': 'C', 'izin': [1], 'yil': 1978},
    'Nissan-Note': {'seg': 'B', 'izin': [1], 'yil': 2004},

    # --- VOLVO ---
    'Volvo-S40': {'seg': 'C', 'izin': [1], 'yil': 1995},
    'Volvo-S60': {'seg': 'D', 'izin': [1], 'yil': 2000},
    'Volvo-S90': {'seg': 'E', 'izin': [1], 'yil': 1996},
    'Volvo-V40': {'seg': 'C', 'izin': [1], 'yil': 1995},
    'Volvo-XC40': {'seg': 'C', 'izin': [1], 'yil': 2017},
    'Volvo-XC60': {'seg': 'D', 'izin': [1], 'yil': 2008},
    'Volvo-XC90': {'seg': 'E', 'izin': [1], 'yil': 2002},

    # --- ELEKTRİKLİ & YENİ NESİL ---
    'Tesla-Model-3': {'seg': 'D', 'izin': [1], 'yil': 2017},
    'Tesla-Model-Y': {'seg': 'D', 'izin': [1], 'yil': 2020},
    'Tesla-Model-S': {'seg': 'E', 'izin': [1], 'yil': 2012},
    'Tesla-Model-X': {'seg': 'E', 'izin': [1], 'yil': 2015},
    'Togg-T10X': {'seg': 'C', 'izin': [1], 'yil': 2023},
    'Chery-Omoda-5': {'seg': 'C', 'izin': [1], 'yil': 2022},
    'Chery-Tiggo-7-Pro': {'seg': 'C', 'izin': [1], 'yil': 2020},
    'Chery-Tiggo-8-Pro': {'seg': 'D', 'izin': [1], 'yil': 2018},

    # --- DİĞER ---
    'Suzuki-Swift': {'seg': 'B', 'izin': [1], 'yil': 1983},
    'Suzuki-Vitara': {'seg': 'B', 'izin': [1], 'yil': 1988},
    'Citroen-C3': {'seg': 'B', 'izin': [1], 'yil': 2002},
    'Citroen-C4': {'seg': 'C', 'izin': [1], 'yil': 2004},
    'Citroen-C5-Aircross': {'seg': 'C', 'izin': [1], 'yil': 2017},
    'Citroen-C-Elysee': {'seg': 'B', 'izin': [1, 2], 'yil': 2012},
    'Seat-Leon': {'seg': 'C', 'izin': [1], 'yil': 1998},
    'Seat-Ibiza': {'seg': 'B', 'izin': [1, 2], 'yil': 1984},
    'Seat-Arona': {'seg': 'B', 'izin': [1], 'yil': 2017},
    'Seat-Ateca': {'seg': 'C', 'izin': [1], 'yil': 2016},
    'Mazda-3': {'seg': 'C', 'izin': [1], 'yil': 2003},
    'Mazda-6': {'seg': 'D', 'izin': [1], 'yil': 2002}
})
# arac_verisi.py - KAMYONET ARAÇLAR PART 1
# Kullanım Kodları: 1: Hususi, 3: Kamyonet, 5: Minibüs

arac_filtresi.update({
    # --- FORD (Ticari Devler) ---
    'Ford-Transit-Panelvan': {'seg': 'D', 'izin': [3], 'yil': 1965},
    'Ford-Transit-Kamyonet': {'seg': 'D', 'izin': [3], 'yil': 1965},
    'Ford-Transit-Minibus': {'seg': 'E', 'izin': [5], 'yil': 1965},
    'Ford-Tourneo-Custom': {'seg': 'D', 'izin': [1, 5], 'yil': 2012},
    'Ford-Transit-Custom': {'seg': 'D', 'izin': [3], 'yil': 2012},
    'Ford-Tourneo-Connect': {'seg': 'C', 'izin': [1, 3], 'yil': 2002},
    'Ford-Transit-Connect': {'seg': 'C', 'izin': [3], 'yil': 2002},
    'Ford-Tourneo-Courier': {'seg': 'B', 'izin': [1, 3], 'yil': 2014},
    'Ford-Transit-Courier': {'seg': 'B', 'izin': [3], 'yil': 2014},
    'Ford-Ranger': {'seg': 'D', 'izin': [3], 'yil': 1998}, # Pick-up

    # --- FIAT (Hafif Ticari) ---
    'Fiat-Doblo-Combi': {'seg': 'C', 'izin': [1, 3], 'yil': 2000},
    'Fiat-Doblo-Cargo': {'seg': 'C', 'izin': [3], 'yil': 2000},
    'Fiat-Fiorino-Combi': {'seg': 'B', 'izin': [1, 3], 'yil': 1977},
    'Fiat-Fiorino-Cargo': {'seg': 'B', 'izin': [3], 'yil': 1977},
    'Fiat-Ducato-Van': {'seg': 'E', 'izin': [3], 'yil': 1981},
    'Fiat-Ducato-Kamyonet': {'seg': 'E', 'izin': [3], 'yil': 1981},
    'Fiat-Ducato-Minibus': {'seg': 'E', 'izin': [5], 'yil': 1981},
    'Fiat-Scudo': {'seg': 'D', 'izin': [1, 3, 5], 'yil': 1996},
    'Fiat-Pratico': {'seg': 'C', 'izin': [3], 'yil': 2010},

    # --- VOLKSWAGEN (Premium Ticari) ---
    'Volkswagen-Caddy': {'seg': 'C', 'izin': [1, 3], 'yil': 1980},
    'Volkswagen-Transporter': {'seg': 'D', 'izin': [3], 'yil': 1950},
    'Volkswagen-Caravelle': {'seg': 'D', 'izin': [1, 5], 'yil': 1975},
    'Volkswagen-Crafter': {'seg': 'E', 'izin': [3, 5], 'yil': 2006},
    'Volkswagen-Amarok': {'seg': 'D', 'izin': [3], 'yil': 2010}, # Pick-up
    'Volkswagen-LT-Serisi': {'seg': 'E', 'izin': [3, 5], 'yil': 1975},

    # --- RENAULT (Hafif ve Orta Ticari) ---
    'Renault-Kangoo-Multix': {'seg': 'C', 'izin': [1, 3], 'yil': 1997},
    'Renault-Kangoo-Express': {'seg': 'C', 'izin': [3], 'yil': 1997},
    'Renault-Express-Combi': {'seg': 'B', 'izin': [1, 3], 'yil': 2021},
    'Renault-Express-Van': {'seg': 'B', 'izin': [3], 'yil': 2021},
    'Renault-Master-Panelvan': {'seg': 'E', 'izin': [3], 'yil': 1980},
    'Renault-Master-Kamyonet': {'seg': 'E', 'izin': [3], 'yil': 1980},
    'Renault-Master-Minibus': {'seg': 'E', 'izin': [5], 'yil': 1980},
    'Renault-Trafic-Multix': {'seg': 'D', 'izin': [1, 3, 5], 'yil': 1980},
    'Renault-Trafic-Panelvan': {'seg': 'D', 'izin': [3], 'yil': 1980}
})
# arac_verisi.py - KAMYONET ARAÇLAR PART 2
# Kullanım Kodları: 1: Hususi, 3: Kamyonet, 5: Minibüs

arac_filtresi.update({
    # --- MERCEDES-BENZ (Premium Ticari) ---
    'Mercedes-Vito-Panelvan': {'seg': 'D', 'izin': [3], 'yil': 1996},
    'Mercedes-Vito-Tourer': {'seg': 'D', 'izin': [1, 5], 'yil': 1996},
    'Mercedes-Sprinter-Panelvan': {'seg': 'E', 'izin': [3], 'yil': 1995},
    'Mercedes-Sprinter-Kamyonet': {'seg': 'E', 'izin': [3], 'yil': 1995},
    'Mercedes-Sprinter-Minibus': {'seg': 'E', 'izin': [5], 'yil': 1995},
    'Mercedes-X-Class': {'seg': 'E', 'izin': [1, 3], 'yil': 2017}, # Pick-up

    # --- PEUGEOT & CITROËN & OPEL (PSA Grubu) ---
    'Peugeot-Rifter': {'seg': 'C', 'izin': [1, 3], 'yil': 2018},
    'Peugeot-Partner': {'seg': 'C', 'izin': [3], 'yil': 1996},
    'Peugeot-Expert-Van': {'seg': 'D', 'izin': [3], 'yil': 1995},
    'Peugeot-Expert-Traveler': {'seg': 'D', 'izin': [1, 5], 'yil': 2016},
    'Peugeot-Boxer-Van': {'seg': 'E', 'izin': [3], 'yil': 1981},
    'Citroen-Berlingo-Combi': {'seg': 'C', 'izin': [1, 3], 'yil': 1996},
    'Citroen-Berlingo-Van': {'seg': 'C', 'izin': [3], 'yil': 1996},
    'Citroen-Jumpy-Van': {'seg': 'D', 'izin': [3], 'yil': 1994},
    'Citroen-Jumper-Van': {'seg': 'E', 'izin': [3], 'yil': 1981},
    'Opel-Combo-Life': {'seg': 'C', 'izin': [1, 3], 'yil': 1986},
    'Opel-Combo-Cargo': {'seg': 'C', 'izin': [3], 'yil': 1986},
    'Opel-Vivaro-Cargo': {'seg': 'D', 'izin': [3], 'yil': 2001},
    'Opel-Movano': {'seg': 'E', 'izin': [3, 5], 'yil': 1998},

    # --- PICK-UP GRUBU (Arazi & Ticari) ---
    'Toyota-Hilux': {'seg': 'D', 'izin': [1, 3], 'yil': 1968},
    'Mitsubishi-L200': {'seg': 'D', 'izin': [1, 3], 'yil': 1978},
    'Isuzu-D-Max': {'seg': 'D', 'izin': [1, 3], 'yil': 2002},
    'Nissan-Navara': {'seg': 'D', 'izin': [1, 3], 'yil': 1985},
    'Nissan-Skystar': {'seg': 'C', 'izin': [3], 'yil': 2002},
    'Dacia-Dokker-Combi': {'seg': 'B', 'izin': [1, 3], 'yil': 2012},
    'Dacia-Dokker-Van': {'seg': 'B', 'izin': [3], 'yil': 2012},
    'SsangYong-Musso-Grand': {'seg': 'D', 'izin': [1, 3], 'yil': 1993},

    # --- DİĞER TİCARİLER ---
    'Isuzu-NLR': {'seg': 'D', 'izin': [3], 'yil': 2007},
    'Isuzu-NNR': {'seg': 'D', 'izin': [3], 'yil': 2007},
    'Iveco-Daily-Van': {'seg': 'E', 'izin': [3, 5], 'yil': 1978},
    'Iveco-Daily-Kamyonet': {'seg': 'E', 'izin': [3], 'yil': 1978},
    'Hyundai-H100-Kamyonet': {'seg': 'C', 'izin': [3], 'yil': 1987},
    'Kia-Bongo-Kamyonet': {'seg': 'C', 'izin': [3], 'yil': 1980}
})
# arac_verisi.py - KAMYON VE ÇEKİCİ ARAÇLAR PART 1
# Kullanım Kodları: 4: Kamyon (Ağır Vasıta)

arac_filtresi.update({
    # --- MERCEDES-BENZ (Ağır Vasıta Lideri) ---
    'Mercedes-Actros-1845': {'seg': 'E', 'izin': [4], 'yil': 1996},
    'Mercedes-Actros-1848': {'seg': 'E', 'izin': [4], 'yil': 1996},
    'Mercedes-Arocs-3342': {'seg': 'E', 'izin': [4], 'yil': 2013},
    'Mercedes-Axor-1840': {'seg': 'E', 'izin': [4], 'yil': 2001},
    'Mercedes-Axor-3240': {'seg': 'E', 'izin': [4], 'yil': 2001},
    'Mercedes-Atego-1518': {'seg': 'D', 'izin': [4], 'yil': 1998},

    # --- SCANIA (İsveç Çeliği) ---
    'Scania-R450': {'seg': 'E', 'izin': [4], 'yil': 2004},
    'Scania-R500': {'seg': 'E', 'izin': [4], 'yil': 2004},
    'Scania-S500': {'seg': 'E', 'izin': [4], 'yil': 2016},
    'Scania-G400': {'seg': 'E', 'izin': [4], 'yil': 2007},
    'Scania-P360': {'seg': 'E', 'izin': [4], 'yil': 2004},

    # --- VOLVO TRUCKS ---
    'Volvo-FH-16': {'seg': 'E', 'izin': [4], 'yil': 1993},
    'Volvo-FH-500': {'seg': 'E', 'izin': [4], 'yil': 1993},
    'Volvo-FM-460': {'seg': 'E', 'izin': [4], 'yil': 1998},
    'Volvo-FMX-420': {'seg': 'E', 'izin': [4], 'yil': 2010},

    # --- FORD TRUCKS (Yerli Güç) ---
    'Ford-F-Max-500': {'seg': 'E', 'izin': [4], 'yil': 2018},
    'Ford-Cargo-1842T': {'seg': 'E', 'izin': [4], 'yil': 2003},
    'Ford-Cargo-2533': {'seg': 'E', 'izin': [4], 'yil': 2003},
    'Ford-Cargo-3242': {'seg': 'E', 'izin': [4], 'yil': 2003},
    'Ford-Cargo-4142': {'seg': 'E', 'izin': [4], 'yil': 2003},

    # --- MAN & RENAULT ---
    'MAN-TGX-18.470': {'seg': 'E', 'izin': [4], 'yil': 2000},
    'MAN-TGS-33.400': {'seg': 'E', 'izin': [4], 'yil': 2007},
    'Renault-Premium-460': {'seg': 'E', 'izin': [4], 'yil': 1996},
    'Renault-T-High-520': {'seg': 'E', 'izin': [4], 'yil': 2013},
    'Renault-K-460': {'seg': 'E', 'izin': [4], 'yil': 2013},

    # --- BMC & DAF ---
    'BMC-Tupro-1846': {'seg': 'E', 'izin': [4], 'yil': 2018},
    'BMC-Professional-827': {'seg': 'D', 'izin': [4], 'yil': 1996},
    'DAF-XF-480': {'seg': 'E', 'izin': [4], 'yil': 1997},
    'DAF-CF-450': {'seg': 'E', 'izin': [4], 'yil': 1992},

    # --- IVECO ---
    'Iveco-S-Way-530': {'seg': 'E', 'izin': [4], 'yil': 2019},
    'Iveco-Stralis-460': {'seg': 'E', 'izin': [4], 'yil': 2002},
    'Iveco-Eurocargo': {'seg': 'D', 'izin': [4], 'yil': 1991}
})
# arac_verisi.py - MOTOSİKLET GRUBU
# Kullanım Kodları: 1: Hususi (Motosikletlerde taksi perk'i yerine kurye mantığı ileride eklenebilir)

arac_filtresi.update({
    # --- HONDA ---
    'Honda-PCX-125': {'seg': 'A', 'izin': [6], 'yil': 2010},
    'Honda-Forza-250': {'seg': 'B', 'izin': [6], 'yil': 2000},
    'Honda-CB-125E': {'seg': 'A', 'izin': [6], 'yil': 2012},
    'Honda-CBR-650R': {'seg': 'C', 'izin': [6], 'yil': 2014},
    'Honda-Africa-Twin': {'seg': 'D', 'izin': [6], 'yil': 1988},
    'Honda-Goldwing': {'seg': 'E', 'izin': [6], 'yil': 1974},
    'Honda-NC-750X': {'seg': 'C', 'izin': [6], 'yil': 2012},

    # --- YAMAHA ---
    'Yamaha-NMAX-125': {'seg': 'A', 'izin': [6], 'yil': 2015},
    'Yamaha-XMAX-250': {'seg': 'B', 'izin': [6], 'yil': 2005},
    'Yamaha-MT-07': {'seg': 'C', 'izin': [6], 'yil': 2014},
    'Yamaha-MT-09': {'seg': 'C', 'izin': [6], 'yil': 2013},
    'Yamaha-R25': {'seg': 'B', 'izin': [6], 'yil': 2014},
    'Yamaha-R6': {'seg': 'C', 'izin': [6], 'yil': 1999},
    'Yamaha-R1': {'seg': 'D', 'izin': [6], 'yil': 1998},
    'Yamaha-Tenere-700': {'seg': 'C', 'izin': [6], 'yil': 2019},

    # --- BMW MOTORRAD ---
    'BMW-R-1250-GS': {'seg': 'E', 'izin': [6], 'yil': 2004},
    'BMW-S-1000-RR': {'seg': 'D', 'izin': [6], 'yil': 2009},
    'BMW-G-310-R': {'seg': 'B', 'izin': [6], 'yil': 2016},
    'BMW-F-850-GS': {'seg': 'D', 'izin': [6], 'yil': 2018},

    # --- KAWASAKI & DUCATI ---
    'Kawasaki-Ninja-400': {'seg': 'B', 'izin': [6], 'yil': 2018},
    'Kawasaki-Z-900': {'seg': 'C', 'izin': [6], 'yil': 2017},
    'Kawasaki-H2R': {'seg': 'E', 'izin': [6], 'yil': 2015},
    'Ducati-Panigale-V4': {'seg': 'E', 'izin': [6], 'yil': 2018},
    'Ducati-Monster': {'seg': 'C', 'izin': [6], 'yil': 1993},
    'Ducati-Multistrada': {'seg': 'D', 'izin': [6], 'yil': 2003},

    # --- BAJAJ & TVS ---
    'Bajaj-Pulsar-NS-200': {'seg': 'A', 'izin': [6], 'yil': 2012},
    'Bajaj-Dominar-400': {'seg': 'B', 'izin': [6], 'yil': 2017},
    'TVS-Apache-RTR-200': {'seg': 'A', 'izin': [6], 'yil': 2006},
    'KTM-Duke-390': {'seg': 'B', 'izin': [6], 'yil': 2013},
    'KTM-1290-Super-Adventure': {'seg': 'E', 'izin': [6], 'yil': 2015}
})
