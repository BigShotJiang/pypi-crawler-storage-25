# katsayilar.py

sehir_katsayilari = {
    '34': 1.30, '06': 1.20, '35': 1.15,
    '01': 1.10, '07': 1.10, '16': 1.10,
    '42': 1.00, '38': 1.00, '26': 1.00,
    'default': 0.90
}

kullanim_tarzi_katsayilari = {
    '1': ('Hususi Otomobil', 1.00),
    '2': ('Taksi', 3.50),
    '3': ('Kamyonet (Hususi/Ticari)', 1.45),
    '4': ('Kamyon', 2.10),
    '5': ('Minibüs', 1.80),
    '6': ('Motosiklet', 0.75)
}

def get_sehir_kat(plaka):
    return sehir_katsayilari.get(str(plaka).zfill(2), sehir_katsayilari['default'])

def get_arac_yas_kat(model_yili):
    yas = 2026 - int(model_yili)
    if yas <= 3: return 0.90
    if yas <= 10: return 1.00
    if yas <= 20: return 1.25
    return 1.50