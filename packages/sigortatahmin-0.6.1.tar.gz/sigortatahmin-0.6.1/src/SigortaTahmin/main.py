import difflib, time, sys
from arac_verisi import arac_filtresi
from katsayilar import get_sehir_kat, get_arac_yas_kat, kullanim_tarzi_katsayilari

# --- SEKTORAL PARAMETRELER ---
YUKLEME_GUVENLIK = 1.15   
YUKLEME_GIDER    = 1.20   
YUKLEME_KOMISYON = 1.15   
YUKLEME_KAR      = 1.10   
VERGI_FON_ORANI  = 1.12   

def loading_animasyonu():
    print("\n[+] Analiz Baslatiliyor...")
    animation = ["[----------]", "[###-------]", "[#####-----]", "[########--]", "[##########]"]
    for i in range(len(animation)):
        time.sleep(0.3)
        sys.stdout.write("\r" + animation[i] + " Prim hesabı yapılıyor...")
        sys.stdout.flush()
    print("\n[+] Hesaplama Tamamlandi!\n")

def arac_getir_filtreli(girdi, uygun_arac_listesi):
    eslesmeler = difflib.get_close_matches(girdi, uygun_arac_listesi, n=5, cutoff=0.4)
    if not eslesmeler:
        eslesmeler = [a for a in uygun_arac_listesi if girdi.lower() in a.lower()][:5]
    return eslesmeler

def girdi_al_pozitif(mesaj, min_deger=0):
    while True:
        try:
            deger = int(input(mesaj))
            if deger < min_deger:
                print(f"[!] Hata: Deger {min_deger}'den kucuk olamaz.")
                continue
            return deger
        except ValueError:
            print("[!] Hata: Lutfen sadece rakam girin.")

def girdi_al_oran(mesaj):
    while True:
        girdi = input(mesaj).strip()
        if not girdi: return 0.0
        try:
            oran = float(girdi)
            if -10.0 <= oran <= 10.0: return oran
            else: print("[!] Hata: Oran -10 ile 10 arasinda olmalidir.")
        except ValueError:
            print("[!] Hata: Gecersiz karakter! Rakam girin (Orn: -5 veya 3).")

def ana_program():
    print("\n" + "="*62)
    print(f"{'AKTUERYAL TRAFIK SIGORTASI FIYATLAMA OTOMASYONU v6.1':^62}")
    print("="*62)
    
    try:
        yas = girdi_al_pozitif("> Surucu Yasi: ", 18)
        while True:
            plaka = input("> Il Plaka Kodu (01-81): ").strip()
            if plaka.isdigit() and 1 <= int(plaka) <= 81: break
            print("[!] Gecersiz plaka! (01-81)")

        print("\n[ Kullanim Tarzi ]")
        for k, v in kullanim_tarzi_katsayilari.items():
            print(f"  {k}. {v[0]}")
        tarz_kod = input("> Seciminiz (1-6): ")
        tarz_adi, tarz_kat = kullanim_tarzi_katsayilari[tarz_kod]

        uygun_modeller = [isim for isim, veri in arac_filtresi.items() if int(tarz_kod) in veri['izin']]
        secilen_arac = None
        while not secilen_arac:
            girdi = input("> Arac Marka/Model Arama: ")
            bulunanlar = arac_getir_filtreli(girdi, uygun_modeller)
            if not bulunanlar:
                print("[!] Uygun arac bulunamadi.")
                continue
            print("\n[ Uygun Modeller ]")
            for i, arac in enumerate(bulunanlar, 1): print(f"  {i}. {arac}")
            secim = input("> Seciminiz: ").strip().lower()
            if secim.isdigit() and 0 < int(secim) <= len(bulunanlar):
                secilen_arac = bulunanlar[int(secim)-1]
            else:
                for a in bulunanlar:
                    if secim in a.lower(): secilen_arac = a; break

        dogum_yili = arac_filtresi[secilen_arac]['yil']
        model_yili = girdi_al_pozitif(f"> Model Yili ({dogum_yili}-2026): ", dogum_yili)
        police_yili = girdi_al_pozitif("> Toplam Police Suresi (Yil): ")
        kaza_sayisi = girdi_al_pozitif("> Son 1 Yildaki Hasar Sayisi: ")
        esneklik = girdi_al_oran("> Ek Risk/Indirim Puani (%) (Yoksa 0): ")

        loading_animasyonu()

        # --- HESAPLAMA ---
        segment = arac_filtresi[secilen_arac]['seg']
        baz = {'A':7500, 'B':8500, 'C':10000, 'D':13000, 'E':18000}.get(segment, 9000)
        yas_kat = 1.45 if yas < 26 else (0.90 if yas > 50 else 1.00)
        kademe = max(1, min(7, 4 + min(10, police_yili) - (kaza_sayisi * 2)))
        bm_kat = {1:2.35, 2:1.70, 3:1.30, 4:1.00, 5:0.80, 6:0.60, 7:0.45}[kademe]
        
        saf_prim = baz * yas_kat * bm_kat * get_sehir_kat(plaka) * tarz_kat * get_arac_yas_kat(model_yili)
        teknik_prim = saf_prim * YUKLEME_GUVENLIK * YUKLEME_GIDER * YUKLEME_KOMISYON * YUKLEME_KAR
        net_prim = teknik_prim * (1 + (esneklik / 100))
        brut_prim = net_prim * VERGI_FON_ORANI

        # --- FINAL RAPORU (KESIN HIZALAMA) ---
        W = 62 # Toplam genislik
        
        def print_row(text):
            print(f"| {text:<{W-4}} |")

        print("+" + "="*(W-2) + "+")
        print(f"|{'ZORUNLU TRAFIK SIGORTASI ANALIZ RAPORU':^60}|")
        print("+" + "="*(W-2) + "+")
        
        print_row(f"Surucu: {yas} Yas | Plaka: {plaka} | Basamak: {kademe}")
        print_row(f"Arac  : {secilen_arac} ({segment})")
        print_row(f"Tarz  : {tarz_adi} | Model: {model_yili}")
        
        print("|" + "-"*(W-2) + "|")
        
        # Fiyatlandirma Satirlari
        labels = [
            ("1. SAF PRIM (Hasar Beklentisi)", f"{saf_prim:,.2f} TL"),
            ("2. TEKNIK YUKLEMELER (Gider+Kar)", f"{teknik_prim - saf_prim:,.2f} TL"),
            ("3. EK RISK/INDIRIM PUANI", f"{esneklik:.1f} %"),
            ("4. VERGI VE FONLAR (%12)", f"{brut_prim - net_prim:,.2f} TL")
        ]
        
        for label, val in labels:
            print(f"| {label:<35} : {val:>20} |")
        
        print("+" + "="*(W-2) + "+")
        print(f"| {'ODENECEK TOPLAM TUTAR (BRUT)':<35} : {f'{brut_prim:,.2f} TL':>20} |")
        print("+" + "="*(W-2) + "+")
        
    except Exception as e: print(f"\n[!] Hata: {e}")

if __name__ == "__main__":
    ana_program()