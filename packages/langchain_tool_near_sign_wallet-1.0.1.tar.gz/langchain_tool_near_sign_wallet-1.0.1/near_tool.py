"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - NEAR sign wallet
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class SignWalletInput(BaseModel):
    account_id: str
    message: str
    private_key: str  # base58-encoded ed25519 private key (64 bytes: seed+pubkey or 32-byte seed)
    network: str = "mainnet"

class NEARSignWalletTool(BaseTool):
    name: str = "near_sign_wallet"
    description: str = (
        "Sign an arbitrary message with a NEAR wallet private key (ed25519). "
        "Verifies the account exists on-chain, signs the UTF-8 message, and returns "
        "the base58-encoded signature along with the public key. "
        "Inputs: account_id, message, private_key (base58 ed25519), network (mainnet/testnet)."
    )
    args_schema: Type[BaseModel] = SignWalletInput

    def _run(self, account_id: str, message: str, private_key: str, network: str = "mainnet") -> Dict[str, Any]:
        import base58  # type: ignore
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # type: ignore

        # Verify account exists on-chain
        result = _near_rpc(
            "query",
            {"request_type": "view_account", "finality": "final", "account_id": account_id},
            network=network,
        )
        if "error" in result:
            return {"success": False, "error": result["error"], "account_id": account_id}

        # Decode private key (strip "ed25519:" prefix if present)
        raw_key = private_key.replace("ed25519:", "")
        key_bytes = base58.b58decode(raw_key)
        # Ed25519 seed is first 32 bytes; full keypair is 64 bytes
        seed = key_bytes[:32]
        private_key_obj = Ed25519PrivateKey.from_private_bytes(seed)
        public_key_obj = private_key_obj.public_key()

        message_bytes = message.encode("utf-8")
        signature_bytes = private_key_obj.sign(message_bytes)

        pub_raw = public_key_obj.public_bytes_raw()
        signature_b58 = base58.b58encode(signature_bytes).decode()
        public_key_b58 = "ed25519:" + base58.b58encode(pub_raw).decode()

        return {
            "success": True,
            "account_id": account_id,
            "network": network,
            "message": message,
            "signature": signature_b58,
            "public_key": public_key_b58,
        }

    async def _arun(self, account_id: str, message: str, private_key: str, network: str = "mainnet") -> Dict[str, Any]:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._run(account_id, message, private_key, network)
        )


class VerifyWalletSignatureInput(BaseModel):
    account_id: str
    message: str
    signature: str   # base58-encoded signature
    public_key: str  # "ed25519:<base58>" or plain base58
    network: str = "mainnet"

class NEARVerifyWalletSignatureTool(BaseTool):
    name: str = "near_verify_wallet_signature"
    description: str = (
        "Verify a NEAR wallet ed25519 signature against a message and public key, "
        "and confirm the public key is an authorized key for the account on-chain. "
        "Inputs: account_id, message, signature (base58), public_key (ed25519:<base58>), network."
    )
    args_schema: Type[BaseModel] = VerifyWalletSignatureInput

    def _run(self, account_id: str, message: str, signature: str, public_key: str, network: str = "mainnet") -> Dict[str, Any]:
        import base58  # type: ignore
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey  # type: ignore
        from cryptography.exceptions import InvalidSignature  # type: ignore

        raw_pub = public_key.replace("ed25519:", "")
        pub_bytes = base58.b58decode(raw_pub)
        sig_bytes = base58.b58decode(signature)
        message_bytes = message.encode("utf-8")

        pub_obj = Ed25519PublicKey.from_public_bytes(pub_bytes)
        try:
            pub_obj.verify(sig_bytes, message_bytes)
            sig_valid = True
        except InvalidSignature:
            sig_valid = False

        # Check key is authorized for account on-chain
        key_result = _near_rpc(
            "query",
            {
                "request_type": "view_access_key",
                "finality": "final",
                "account_id": account_id,
                "public_key": f"ed25519:{raw_pub}",
            },
            network=network,
        )
        key_authorized = "error" not in key_result

        return {
            "success": True,
            "account_id": account_id,
            "network": network,
            "signature_valid": sig_valid,
            "key_authorized_on_chain": key_authorized,
            "verified": sig_valid and key_authorized,
        }

    async def _arun(self, account_id: str, message: str, signature: str, public_key: str, network: str = "mainnet") -> Dict[str, Any]:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._run(account_id, message, signature, public_key, network)
        )