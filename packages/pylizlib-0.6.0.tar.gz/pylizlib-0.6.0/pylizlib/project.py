# fmt: off
name = 'pylizlib'
version = '0.6.0'
description = 'Add your description here'
requires_python = '>=3.12'
authors = [('Gabliz', 'gabliz.dev@gmail.com')]
# fmt: on
