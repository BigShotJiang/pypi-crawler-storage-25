"""Tests for FanFu."""
