"""
cli.py
------
argparse entry point for RTLGuard.

Usage:
    rtlguard analyze FILE [FILE ...] [options]
    rtlguard verify  FILE [FILE ...] [options]
    rtlguard iterate --log TRANSCRIPT --testbench FILE [options]
"""

import sys
import argparse

from rtlguard.cli.commands import run_analyze
from rtlguard.cli.iterate_command import run_iterate
from rtlguard.cli.verify_command import run_verify


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rtlguard",
        description="RTLGuard — AI-assisted test case generation for RTL designs.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  rtlguard analyze counter.sv
  rtlguard analyze my_module.vhd --spec requirements.txt
  rtlguard verify  counter.sv                          # non-interactive, auto-fix
  rtlguard verify  counter.sv --sim-script             # also write ModelSim .do
  rtlguard iterate --log counter_transcript.log --testbench counter_tb.sv
""",
    )

    sub = parser.add_subparsers(dest="command", metavar="<command>")
    sub.required = True

    # ------------------------------------------------------------------ #
    # analyze                                                              #
    # ------------------------------------------------------------------ #
    analyze = sub.add_parser(
        "analyze",
        help="check FPGA practices and generate test cases for RTL source file(s)",
        description=(
            "Parse RTL source file(s), check FPGA best practices, generate "
            "test cases, and optionally produce a SystemVerilog testbench."
        ),
    )

    analyze.add_argument(
        "files",
        nargs="+",
        metavar="FILE",
        help="VHDL (.vhd/.vhdl) or SystemVerilog (.sv/.v) source file(s)",
    )
    analyze.add_argument(
        "--spec",
        default=None,
        metavar="FILE",
        help="optional design spec or requirements document for additional context",
    )
    analyze.add_argument(
        "-o", "--output-dir",
        default="./rtlguard_out",
        metavar="DIR",
        help="directory to write output files (default: ./rtlguard_out)",
    )
    analyze.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="print parser warnings and validation issues",
    )

    # ------------------------------------------------------------------ #
    # iterate                                                              #
    # ------------------------------------------------------------------ #
    iterate = sub.add_parser(
        "iterate",
        help="parse simulation transcript and AI-fix the testbench",
        description=(
            "Parse a ModelSim/Questa transcript log, identify failing test cases, "
            "and use AI to fix the testbench. Repeat until all tests pass or the "
            "maximum number of rounds is reached."
        ),
    )
    iterate.add_argument(
        "--log",
        required=True,
        metavar="FILE",
        help="ModelSim/Questa transcript log file",
    )
    iterate.add_argument(
        "--testbench",
        required=True,
        metavar="FILE",
        help="SystemVerilog testbench file to fix",
    )
    iterate.add_argument(
        "--max-rounds",
        type=int,
        default=5,
        metavar="N",
        help="maximum fix-and-rerun rounds (default: 5)",
    )

    # ------------------------------------------------------------------ #
    # verify                                                               #
    # ------------------------------------------------------------------ #
    verify = sub.add_parser(
        "verify",
        help="non-interactive: FPGA check, auto-fix, test cases, testbench in one shot",
        description=(
            "Run the full RTLGuard pipeline without prompts. "
            "FPGA violations are auto-fixed; test cases and a testbench are always "
            "generated. Exit code 0 = clean design, 1 = hard error, "
            "2 = violations remain after auto-fix."
        ),
    )
    verify.add_argument(
        "files",
        nargs="+",
        metavar="FILE",
        help="VHDL (.vhd/.vhdl) or SystemVerilog (.sv/.v) source file(s)",
    )
    verify.add_argument(
        "--spec",
        default=None,
        metavar="FILE",
        help="optional design spec for additional AI context",
    )
    verify.add_argument(
        "-o", "--output-dir",
        default="./rtlguard_out",
        metavar="DIR",
        help="directory for output files (default: ./rtlguard_out)",
    )
    verify.add_argument(
        "--no-fix",
        action="store_true",
        help="report violations but skip auto-fix (exit 2 if any found)",
    )
    verify.add_argument(
        "--sim-script",
        action="store_true",
        help="also generate a ModelSim/Questa .do simulation script",
    )

    return parser


def main():
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "analyze":
        sys.exit(run_analyze(args))
    elif args.command == "iterate":
        sys.exit(run_iterate(args))
    elif args.command == "verify":
        sys.exit(run_verify(args))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
