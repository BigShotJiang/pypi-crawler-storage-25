"""
iterate_command.py
------------------
'rtlguard iterate' subcommand:

  Parse simulation transcript → identify failures → AI fixes testbench →
  show diff → engineer confirms → write updated testbench → repeat until
  clean or engineer exits.
"""

import difflib
import sys
from pathlib import Path

from rtlguard.ai.api_key import get_api_key
from rtlguard.ai.anthropic_provider import AnthropicProvider
from rtlguard.ai.transcript_parser import parse_transcript_file
from rtlguard.ai.testbench_fixer import TestbenchFixer
from rtlguard.ai import usage_tracker


def _ask(prompt: str, choices: list[str]) -> str:
    choices_str = "/".join(choices)
    while True:
        try:
            answer = input(f"\n  {prompt} [{choices_str}]: ").strip().lower()
        except (EOFError, KeyboardInterrupt, OSError):
            print()
            return choices[-1]
        if answer in choices:
            return answer
        print(f"  Please enter one of: {choices_str}")


def _print_diff(original: str, fixed: str) -> None:
    orig_lines = original.splitlines(keepends=True)
    fixed_lines = fixed.splitlines(keepends=True)
    diff = list(difflib.unified_diff(orig_lines, fixed_lines,
                                     fromfile="current", tofile="proposed",
                                     lineterm=""))
    if not diff:
        print("  (no textual changes)")
        return
    for line in diff[:60]:
        print(f"  {line}")
    if len(diff) > 60:
        print(f"  ... ({len(diff) - 60} more lines)")
    print()


def _print_usage() -> None:
    u = usage_tracker.summary()
    if u["calls"] == 0:
        return
    total_in = u["input_tokens"]
    cached = u["cache_read_tokens"]
    pct = int(cached / total_in * 100) if total_in > 0 else 0
    print(
        f"\n  {u['calls']} AI calls · "
        f"{total_in:,} tokens in · "
        f"{u['output_tokens']:,} out · "
        f"{cached:,} cached ({pct}%)"
    )


def run_iterate(args) -> int:
    log_path = args.log
    tb_path = Path(args.testbench)
    max_rounds = args.max_rounds

    # ------------------------------------------------------------------ #
    # Initialise provider                                                  #
    # ------------------------------------------------------------------ #
    try:
        api_key = get_api_key()
        provider = AnthropicProvider(api_key=api_key)
    except RuntimeError as exc:
        print(f"  ✗  {exc}", file=sys.stderr)
        return 1

    if not tb_path.exists():
        print(f"  ✗  Testbench not found: {tb_path}", file=sys.stderr)
        return 1

    usage_tracker.reset()
    fixer = TestbenchFixer(provider)

    for round_num in range(1, max_rounds + 1):
        print(f"\n  Round {round_num} of {max_rounds}")

        # ---------------------------------------------------------------- #
        # 1. Parse transcript                                               #
        # ---------------------------------------------------------------- #
        print(f"  Parsing transcript: {log_path} ...", end="", flush=True)
        result = parse_transcript_file(log_path)

        if result.error:
            print(f" ✗\n  {result.error}", file=sys.stderr)
            return 1

        if not result.has_failures:
            print(" ✓  No failures found — simulation is clean!")
            break

        print(f" ✓  {len(result.failure_lines)} failure line(s) found")
        if result.failing_tc_ids:
            print(f"  Failing: {', '.join(result.failing_tc_ids)}")
        else:
            print("  (no TC-xxx IDs found in failure lines)")
        print()
        for line in result.failure_lines[:10]:
            print(f"    {line}")
        if len(result.failure_lines) > 10:
            print(f"    ... ({len(result.failure_lines) - 10} more lines)")

        choice = _ask("Fix testbench automatically, skip, or quit?",
                      ["auto", "skip", "quit"])

        if choice == "quit":
            break

        if choice == "skip":
            print("  Skipping AI fix for this round.")
            print("  Fix the testbench manually and re-run the simulation,")
            print(f"  then run:  rtlguard iterate --log {log_path} "
                  f"--testbench {tb_path}")
            break

        # ---------------------------------------------------------------- #
        # 2. AI fix                                                         #
        # ---------------------------------------------------------------- #
        tb_source = tb_path.read_text(encoding="utf-8")
        print("  Generating testbench fix ...", end="", flush=True)
        fix_result = fixer.fix(tb_source, result.failure_lines, result.failing_tc_ids)

        if fix_result.has_error:
            print(f" ✗\n  {fix_result.error}")
            choice2 = _ask("Continue anyway (manual fix) or quit?", ["continue", "quit"])
            if choice2 == "quit":
                break
            print("  Fix the testbench manually and re-run the simulation.")
            break

        if fix_result.fixed_testbench == tb_source:
            print(" ✓\n  No changes proposed by AI.")
            print("  The failures may require manual investigation.")
            break

        print(" ✓\n")
        for fix in fix_result.fixes_applied:
            tc = fix.get("test_case_id", "")
            desc = fix.get("description", "")
            print(f"  [{tc}] {desc}")
        print()
        _print_diff(tb_source, fix_result.fixed_testbench)

        confirm = _ask("Apply these changes?", ["y", "n"])
        if confirm != "y":
            print("  Changes discarded. Fix the testbench manually.")
            break

        tb_path.write_text(fix_result.fixed_testbench, encoding="utf-8")
        print(f"  Testbench updated: {tb_path}")

        # ---------------------------------------------------------------- #
        # 3. Prompt to re-run simulation                                    #
        # ---------------------------------------------------------------- #
        if round_num < max_rounds:
            print(f"\n  Re-run your simulation and update the transcript at:")
            print(f"    {log_path}")
            cont = _ask("Press Enter when the new transcript is ready, or q to quit",
                        ["", "q"])
            if cont == "q":
                break
        else:
            print(f"\n  Maximum rounds ({max_rounds}) reached.")

    _print_usage()
    return 0
