"""
commands.py
-----------
Interactive pipeline for the 'analyze' subcommand:
  parse → FPGA check (loop) → test case generation → testbench → sim script
"""

import difflib
import sys
from pathlib import Path
from typing import Optional

# Side-effect imports — register parsers with ParserFactory
import rtlguard.parser.vhdl_parser  # noqa: F401
import rtlguard.parser.sv_parser    # noqa: F401

from rtlguard.parser.base_parser import ParserFactory
from rtlguard.models.entity import Entity
from rtlguard.ai.api_key import get_api_key
from rtlguard.ai.anthropic_provider import AnthropicProvider
from rtlguard.ai.fpga_checker import FPGAChecker, FPGACheckResult
from rtlguard.ai.fpga_fixer import FPGAFixer
from rtlguard.ai.testcase_generator import TestCaseGenerator, TCResult
from rtlguard.ai.testbench_generator import TestbenchGenerator
from rtlguard.ai.modelsim_generator import ModelSimGenerator
from rtlguard.ai import usage_tracker

_SEVERITY_ORDER = ["critical", "high", "medium", "low"]


# ---------------------------------------------------------------------------
# Helpers — parsing
# ---------------------------------------------------------------------------

def _parse_source(source_file: str, verbose: bool) -> tuple[Entity, str]:
    path = Path(source_file)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {source_file}")
    source_text = path.read_text(encoding="utf-8", errors="replace")
    parser = ParserFactory.get_parser(source_file)
    entity = parser.parse()
    if verbose and parser.errors:
        for err in parser.errors:
            print(f"  {err}")
    if verbose and parser.warnings:
        for w in parser.warnings:
            print(f"  {w}")
    return entity, source_text


def _read_spec(spec_file: str) -> str:
    path = Path(spec_file)
    if not path.exists():
        raise FileNotFoundError(f"Spec file not found: {spec_file}")
    return path.read_text(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------------------
# Helpers — file writers
# ---------------------------------------------------------------------------

def _write_fpga_txt(result: FPGACheckResult, output_dir: Path, module_name: str) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{module_name}_fpga_check.txt"

    lines = []
    if result.clean or not result.violations:
        lines.append("No FPGA best-practice violations found.")
    else:
        for sev in _SEVERITY_ORDER:
            for v in result.violations:
                if v.severity == sev:
                    lines.append(f"[{v.id}] {v.severity.upper()} — {v.title}")
                    lines.append(f"  {v.description}")
                    lines.append(f"  Fix: {v.suggestion}")
                    lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _write_testcases_txt(result: TCResult, output_dir: Path, module_name: str) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{module_name}_test_cases.txt"

    lines = []
    for tc in result.test_cases:
        lines.append(f"[{tc.id}] {tc.name}  ({tc.priority.upper()})")
        if tc.description:
            lines.append(f"  {tc.description}")
        if tc.stimulus:
            lines.append("  Stimulus:")
            for s in tc.stimulus:
                lines.append(f"    {s.signal} = {s.value}")
        if tc.expected_outputs:
            lines.append("  Expected:")
            for e in tc.expected_outputs:
                lines.append(f"    {e.signal} == {e.value}")
        lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Helpers — diff display + auto-fix
# ---------------------------------------------------------------------------

def _build_diff(original: str, fixed: str) -> str:
    orig_lines = original.splitlines(keepends=True)
    fixed_lines = fixed.splitlines(keepends=True)
    diff = list(difflib.unified_diff(orig_lines, fixed_lines,
                                     fromfile="original", tofile="proposed",
                                     lineterm=""))
    return "".join(diff) if diff else "(no textual changes)\n"


def _write_fix_summary(
    result,
    original_source: str,
    output_dir: Path,
    module_name: str,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{module_name}_ai_fixes.txt"
    lines = [f"AI Auto-Fix Summary — {module_name}", "=" * 50, ""]
    lines.append("Fixes Applied:")
    for fix in result.fixes_applied:
        vid = fix.get("violation_id", "")
        desc = fix.get("description", "")
        lines.append(f"  [{vid}] {desc}")
    lines += ["", "Diff (original → proposed):", "-" * 50]
    lines.append(_build_diff(original_source, result.fixed_source))
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _auto_fix(
    source_file: str,
    entity,
    source_text: str,
    violations: list,
    provider,
    output_dir: Path,
) -> tuple[str, bool]:
    """Run AI auto-fix. Returns (updated_source_text, file_was_written)."""
    print("  Generating fixes ...", end="", flush=True)
    fixer = FPGAFixer(provider)
    result = fixer.fix(entity, source_text, violations)

    if result.has_error:
        print(f" ✗\n  {result.error}")
        return source_text, False

    if result.fixed_source == source_text:
        print(" ✓\n  No changes proposed.")
        return source_text, False

    summary_path = _write_fix_summary(result, source_text, output_dir, entity.name)
    n = len(result.fixes_applied)
    print(f" ✓  {n} fix(es) proposed — review: {summary_path}")
    for fix in result.fixes_applied:
        print(f"      [{fix.get('violation_id', '')}] {fix.get('description', '')}")

    confirm = _ask("Apply these changes?", ["y", "n"])
    if confirm != "y":
        return source_text, False

    Path(source_file).write_text(result.fixed_source, encoding="utf-8")
    return result.fixed_source, True


# ---------------------------------------------------------------------------
# Helpers — interactive prompt
# ---------------------------------------------------------------------------

def _ask(prompt: str, choices: list[str]) -> str:
    choices_str = "/".join(choices)
    while True:
        try:
            answer = input(f"\n  {prompt} [{choices_str}]: ").strip().lower()
        except (EOFError, KeyboardInterrupt, OSError):
            print()
            return choices[-1]
        if answer in choices:
            return answer
        print(f"  Please enter one of: {choices_str}")


# ---------------------------------------------------------------------------
# Per-file pipeline
# ---------------------------------------------------------------------------

def _run_one(
    source_file: str,
    spec_text: Optional[str],
    output_dir: Path,
    provider: AnthropicProvider,
    verbose: bool,
) -> int:
    usage_tracker.reset()
    label = Path(source_file).name
    print(f"\n  {label}")

    # ------------------------------------------------------------------ #
    # 1. Parse                                                             #
    # ------------------------------------------------------------------ #
    try:
        entity, source_text = _parse_source(source_file, verbose)
    except (FileNotFoundError, ValueError) as exc:
        print(f"  ✗  {exc}", file=sys.stderr)
        return 1

    # ------------------------------------------------------------------ #
    # 2. FPGA best-practice check (interactive loop)                      #
    # ------------------------------------------------------------------ #
    checker = FPGAChecker(provider)
    original_violations = None

    while True:
        print("  Checking FPGA best practices ...", end="", flush=True)

        if original_violations is None:
            fpga_result = checker.check(entity, source_text)
        else:
            fpga_result = checker.recheck(entity, source_text, original_violations)

        if fpga_result.error:
            print(f" ✗\n  AI error: {fpga_result.error}", file=sys.stderr)
            choice = _ask("Continue without FPGA check?", ["y", "n"])
            if choice == "n":
                return 1
            break

        if original_violations is None:
            original_violations = fpga_result.violations

        fpga_path = _write_fpga_txt(fpga_result, output_dir, entity.name)
        print(f" ✓  Saved to {fpga_path}")

        if fpga_result.clean or not fpga_result.violations:
            break

        choice = _ask(
            "Fix automatically, edit the file yourself, or proceed anyway?",
            ["auto", "manual", "proceed"],
        )

        if choice == "proceed":
            break

        if choice == "auto":
            source_text, _ = _auto_fix(
                source_file, entity, source_text,
                fpga_result.violations, provider, output_dir,
            )
        else:  # manual
            print("\n  Update your file and press Enter when ready ...", end="", flush=True)
            try:
                input()
            except (EOFError, KeyboardInterrupt):
                print()
                break

        try:
            entity, source_text = _parse_source(source_file, verbose)
        except (FileNotFoundError, ValueError) as exc:
            print(f"  ✗  {exc}", file=sys.stderr)
            return 1

    # ------------------------------------------------------------------ #
    # 3. Test case generation                                              #
    # ------------------------------------------------------------------ #
    print("  Generating test cases ...", end="", flush=True)
    gen = TestCaseGenerator(provider)
    tc_result = gen.generate(entity, source_text, spec_text)

    if tc_result.has_error:
        print(f" ✗\n  AI error: {tc_result.error}", file=sys.stderr)
        return 1

    tc_path = _write_testcases_txt(tc_result, output_dir, entity.name)
    print(f" ✓  Saved to {tc_path}")

    # ------------------------------------------------------------------ #
    # 4. Optional test case edit → reparse → confirm → testbench         #
    # ------------------------------------------------------------------ #
    tc_text = tc_path.read_text(encoding="utf-8")
    choice = _ask("Edit test cases before generating testbench?", ["y", "n"])

    if choice == "y":
        print(f"\n  Edit {tc_path} and press Enter when ready ...", end="", flush=True)
        try:
            input()
        except (EOFError, KeyboardInterrupt):
            print()

        edited_text = tc_path.read_text(encoding="utf-8")
        print("  Reparsing test cases ...", end="", flush=True)
        cleaned, err = gen.reformat(edited_text, entity)

        if err:
            print(f" ✗\n  Warning: {err} — using your edits as-is")
            tc_text = edited_text
        else:
            print(" ✓\n")
            sep = "  " + "-" * 60
            print(sep)
            for line in cleaned.splitlines():
                print(f"  {line}")
            print(sep + "\n")
            confirm = _ask("Proceed with these test cases?", ["y", "n"])
            if confirm == "y":
                tc_text = cleaned
                tc_path.write_text(tc_text, encoding="utf-8")
            else:
                tc_text = edited_text

    print("  Generating testbench ...", end="", flush=True)
    tb_gen = TestbenchGenerator(provider)
    try:
        sv_code = tb_gen.generate_from_text(entity, tc_text, source_text)
        tb_path = tb_gen.write(sv_code, str(output_dir), entity.name)
        print(f" ✓  Saved to {tb_path}")
    except Exception as exc:
        print(f" ✗\n  Testbench generation failed: {exc}", file=sys.stderr)
        return 1

    # ------------------------------------------------------------------ #
    # 5. Optional ModelSim/Questa .do script                              #
    # ------------------------------------------------------------------ #
    choice = _ask("Generate a ModelSim/Questa simulation script?", ["y", "n"])
    if choice == "y":
        do_gen = ModelSimGenerator()
        do_path = do_gen.write(entity, source_file, str(tb_path), str(output_dir))
        print(f"\n  Sim script saved to {do_path}")
        print(f"  Run it in ModelSim/Questa:  do {do_path.name}")
        print(f"  Transcript will be written to: {entity.name}_transcript.log")
        print(f"  Then run:  rtlguard iterate --log {entity.name}_transcript.log "
              f"--testbench {tb_path}")

    _print_usage()
    return 0


def _print_usage() -> None:
    u = usage_tracker.summary()
    if u["calls"] == 0:
        return
    total_in = u["input_tokens"]
    cached = u["cache_read_tokens"]
    pct = int(cached / total_in * 100) if total_in > 0 else 0
    print(
        f"\n  {u['calls']} AI calls · "
        f"{total_in:,} tokens in · "
        f"{u['output_tokens']:,} out · "
        f"{cached:,} cached ({pct}%)"
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_analyze(args) -> int:
    verbose: bool = args.verbose
    output_dir = Path(args.output_dir)

    # Load spec — either from --spec flag or ask the user interactively
    spec_text: Optional[str] = None
    if args.spec:
        try:
            spec_text = _read_spec(args.spec)
        except FileNotFoundError as exc:
            print(f"  ✗  {exc}", file=sys.stderr)
            return 1
    else:
        print("\n  Do you have a design specification, requirements document, or")
        print("  any notes you'd like the AI to consider? (e.g. expected behaviour,")
        print("  timing constraints, interface description)")
        has_spec = _ask("Provide a spec/requirements file?", ["y", "n"])
        if has_spec == "y":
            while True:
                try:
                    spec_path = input("  Path to file: ").strip()
                except (EOFError, KeyboardInterrupt, OSError):
                    print()
                    break
                if not spec_path:
                    continue
                try:
                    spec_text = _read_spec(spec_path)
                    print(f"  Loaded: {spec_path}")
                    break
                except FileNotFoundError as exc:
                    print(f"  ✗  {exc}  (try again or press Ctrl-C to skip)")

    # Initialise provider
    try:
        api_key = get_api_key()
        provider = AnthropicProvider(api_key=api_key)
    except RuntimeError as exc:
        print(f"  ✗  {exc}", file=sys.stderr)
        return 1

    for src in args.files:
        rc = _run_one(src, spec_text, output_dir, provider, verbose)
        if rc != 0:
            return rc

    return 0
