"""
verify_command.py
-----------------
'rtlguard verify' subcommand — single-command, non-interactive pipeline:

  parse → FPGA check → auto-fix (if violations) → test cases →
  testbench → ModelSim .do script

No prompts. Every decision is made automatically. Exit code reflects
whether the design was clean (0) or had violations that could not be
auto-fixed (2). Exit code 1 means a hard error (file not found, AI
failure, etc.).
"""

import sys
from pathlib import Path
from typing import Optional

import rtlguard.parser.vhdl_parser  # noqa: F401
import rtlguard.parser.sv_parser    # noqa: F401

from rtlguard.parser.base_parser import ParserFactory
from rtlguard.ai.api_key import get_api_key
from rtlguard.ai.anthropic_provider import AnthropicProvider
from rtlguard.ai.fpga_checker import FPGAChecker
from rtlguard.ai.fpga_fixer import FPGAFixer
from rtlguard.ai.testcase_generator import TestCaseGenerator
from rtlguard.ai.testbench_generator import TestbenchGenerator
from rtlguard.ai.modelsim_generator import ModelSimGenerator
from rtlguard.ai import usage_tracker
from rtlguard.cli.commands import _write_fix_summary

_SEVERITY_ORDER = ["critical", "high", "medium", "low"]


def _write_fpga_txt(result, output_dir: Path, module_name: str) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{module_name}_fpga_check.txt"
    lines = []
    if result.clean or not result.violations:
        lines.append("No FPGA best-practice violations found.")
    else:
        for sev in _SEVERITY_ORDER:
            for v in result.violations:
                if v.severity == sev:
                    lines.append(f"[{v.id}] {v.severity.upper()} — {v.title}")
                    lines.append(f"  {v.description}")
                    lines.append(f"  Fix: {v.suggestion}")
                    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _write_testcases_txt(result, output_dir: Path, module_name: str) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{module_name}_test_cases.txt"
    lines = []
    for tc in result.test_cases:
        lines.append(f"[{tc.id}] {tc.name}  ({tc.priority.upper()})")
        if tc.description:
            lines.append(f"  {tc.description}")
        if tc.stimulus:
            lines.append("  Stimulus:")
            for s in tc.stimulus:
                lines.append(f"    {s.signal} = {s.value}")
        if tc.expected_outputs:
            lines.append("  Expected:")
            for e in tc.expected_outputs:
                lines.append(f"    {e.signal} == {e.value}")
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _print_usage() -> None:
    u = usage_tracker.summary()
    if u["calls"] == 0:
        return
    total_in = u["input_tokens"]
    cached = u["cache_read_tokens"]
    pct = int(cached / total_in * 100) if total_in > 0 else 0
    print(
        f"\n  {u['calls']} AI calls · "
        f"{total_in:,} tokens in · "
        f"{u['output_tokens']:,} out · "
        f"{cached:,} cached ({pct}%)"
    )


def _verify_one(
    source_file: str,
    spec_text: Optional[str],
    output_dir: Path,
    provider: AnthropicProvider,
    no_fix: bool,
    sim_script: bool,
) -> int:
    usage_tracker.reset()
    label = Path(source_file).name
    print(f"\n  {label}")

    # ------------------------------------------------------------------ #
    # 1. Parse                                                             #
    # ------------------------------------------------------------------ #
    path = Path(source_file)
    if not path.exists():
        print(f"  ✗  File not found: {source_file}", file=sys.stderr)
        return 1
    source_text = path.read_text(encoding="utf-8", errors="replace")
    try:
        parser = ParserFactory.get_parser(source_file)
        entity = parser.parse()
    except (ValueError, Exception) as exc:
        print(f"  ✗  Parse error: {exc}", file=sys.stderr)
        return 1

    # ------------------------------------------------------------------ #
    # 2. FPGA check                                                        #
    # ------------------------------------------------------------------ #
    print("  Checking FPGA best practices ...", end="", flush=True)
    checker = FPGAChecker(provider)
    fpga_result = checker.check(entity, source_text)

    if fpga_result.error:
        print(f" ✗  AI error: {fpga_result.error}", file=sys.stderr)
        return 1

    fpga_path = _write_fpga_txt(fpga_result, output_dir, entity.name)

    violations_remain = False
    if fpga_result.clean or not fpga_result.violations:
        print(f" ✓  Clean  →  {fpga_path}")
    else:
        n = len(fpga_result.violations)
        print(f" ✗  {n} violation(s)  →  {fpga_path}")
        for v in fpga_result.violations:
            print(f"      [{v.id}] {v.severity.upper()}: {v.title}")

        if no_fix:
            violations_remain = True
        else:
            # Auto-fix
            print("  Auto-fixing ...", end="", flush=True)
            fixer = FPGAFixer(provider)
            fix_result = fixer.fix(entity, source_text, fpga_result.violations)

            if fix_result.has_error:
                print(f" ✗  {fix_result.error}")
                violations_remain = True
            elif fix_result.fixed_source == source_text:
                print(" ✓  No changes proposed.")
                violations_remain = True
            else:
                summary_path = _write_fix_summary(
                    fix_result, source_text, output_dir, entity.name
                )
                path.write_text(fix_result.fixed_source, encoding="utf-8")
                source_text = fix_result.fixed_source
                n = len(fix_result.fixes_applied)
                print(f" ✓  Applied {n} fix(es)  →  {summary_path}")
                for fix in fix_result.fixes_applied:
                    print(f"      [{fix.get('violation_id', '')}] "
                          f"{fix.get('description', '')}")
                # Re-parse after fix
                try:
                    parser2 = ParserFactory.get_parser(source_file)
                    entity = parser2.parse()
                except Exception:
                    pass  # Use stale entity; unlikely to matter for downstream steps

    # ------------------------------------------------------------------ #
    # 3. Test case generation                                              #
    # ------------------------------------------------------------------ #
    print("  Generating test cases ...", end="", flush=True)
    gen = TestCaseGenerator(provider)
    tc_result = gen.generate(entity, source_text, spec_text)

    if tc_result.has_error:
        print(f" ✗  AI error: {tc_result.error}", file=sys.stderr)
        return 1

    tc_path = _write_testcases_txt(tc_result, output_dir, entity.name)
    print(f" ✓  {len(tc_result.test_cases)} test cases  →  {tc_path}")

    # ------------------------------------------------------------------ #
    # 4. Testbench generation                                              #
    # ------------------------------------------------------------------ #
    print("  Generating testbench ...", end="", flush=True)
    tc_text = tc_path.read_text(encoding="utf-8")
    tb_gen = TestbenchGenerator(provider)
    try:
        sv_code = tb_gen.generate_from_text(entity, tc_text, source_text)
        tb_path = tb_gen.write(sv_code, str(output_dir), entity.name)
        print(f" ✓  {tb_path}")
    except Exception as exc:
        print(f" ✗  Testbench generation failed: {exc}", file=sys.stderr)
        return 1

    # ------------------------------------------------------------------ #
    # 5. ModelSim script (optional)                                        #
    # ------------------------------------------------------------------ #
    if sim_script:
        print("  Generating simulation script ...", end="", flush=True)
        do_gen = ModelSimGenerator()
        do_path = do_gen.write(entity, source_file, str(tb_path), str(output_dir))
        print(f" ✓  {do_path}")
        print(f"  Run:  do {do_path.name}   (in ModelSim/Questa)")
        print(f"  Then: rtlguard iterate --log {entity.name}_transcript.log "
              f"--testbench {tb_path}")

    _print_usage()
    return 2 if violations_remain else 0


def run_verify(args) -> int:
    output_dir = Path(args.output_dir)
    no_fix: bool = args.no_fix
    sim_script: bool = args.sim_script

    # Load spec
    spec_text: Optional[str] = None
    if args.spec:
        p = Path(args.spec)
        if not p.exists():
            print(f"  ✗  Spec file not found: {args.spec}", file=sys.stderr)
            return 1
        spec_text = p.read_text(encoding="utf-8", errors="replace")

    # Initialise provider
    try:
        api_key = get_api_key()
        provider = AnthropicProvider(api_key=api_key)
    except RuntimeError as exc:
        print(f"  ✗  {exc}", file=sys.stderr)
        return 1

    worst_rc = 0
    for src in args.files:
        rc = _verify_one(src, spec_text, output_dir, provider, no_fix, sim_script)
        if rc == 1:
            return 1
        if rc > worst_rc:
            worst_rc = rc

    return worst_rc
