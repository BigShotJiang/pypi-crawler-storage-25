"""
ast_builder.py
--------------
Builds RTLGuard's internal Entity representation from raw parsed tokens.
The parsers (vhdl_parser, sv_parser) extract raw data as dicts.
The ASTBuilder converts those dicts into proper model objects.

This separation means the parsers stay focused on reading text,
and the builder stays focused on constructing valid model objects.
"""

from rtlguard.models.signal import Signal, SignalKind, SignalType, SignalDirection
from rtlguard.models.entity import Entity, Process, ProcessKind, GenericParameter, LanguageSource
from rtlguard.parser.token_utils import parse_vhdl_type, parse_sv_vector_type


class ASTBuilder:
    """
    Converts raw dicts produced by the parsers into model objects.
    One ASTBuilder instance per parse run.
    """

    def __init__(self, source_file: str, language: LanguageSource):
        self.source_file = source_file
        self.language = language
        self._errors: list[str] = []

    # ------------------------------------------------------------------
    # Signal builders
    # ------------------------------------------------------------------

    def build_signal_from_vhdl_port(self, raw: dict, line: int = -1) -> Signal | None:
        """
        Convert a raw VHDL port dict (from parse_vhdl_port_line) into a Signal.

        raw keys: name, direction, type_str, default
        """
        try:
            type_info = parse_vhdl_type(raw["type_str"])
            signal_type = SignalType(
                base_type=type_info["base_type"],
                is_vector=type_info["is_vector"],
                vector_high=type_info["high"],
                vector_low=type_info["low"],
                is_descending=type_info["is_descending"],
                raw=type_info["raw"],
            )
            direction = self._map_vhdl_direction(raw["direction"])
            return Signal(
                name=raw["name"],
                kind=SignalKind.PORT,
                signal_type=signal_type,
                direction=direction,
                default_value=raw.get("default"),
                source_file=self.source_file,
                source_line=line if line > 0 else None,
            )
        except Exception as e:
            self._errors.append(f"Failed to build signal from {raw}: {e}")
            return None

    def build_signal_from_sv_port(self, raw: dict, line: int = -1) -> Signal | None:
        """
        Convert a raw SV port dict (from parse_sv_port_line) into a Signal.

        raw keys: name, direction, type_str, default
        """
        try:
            type_info = parse_sv_vector_type(raw["type_str"])
            signal_type = SignalType(
                base_type=type_info["base_type"],
                is_vector=type_info["is_vector"],
                vector_high=type_info["high"],
                vector_low=type_info["low"],
                is_descending=type_info["is_descending"],
                raw=type_info["raw"],
            )
            direction = self._map_sv_direction(raw["direction"])
            return Signal(
                name=raw["name"],
                kind=SignalKind.PORT,
                signal_type=signal_type,
                direction=direction,
                default_value=raw.get("default"),
                source_file=self.source_file,
                source_line=line if line > 0 else None,
            )
        except Exception as e:
            self._errors.append(f"Failed to build SV signal from {raw}: {e}")
            return None

    def build_internal_signal_from_vhdl(self, raw: dict, line: int = -1) -> Signal | None:
        """
        Build an internal Signal from a VHDL signal declaration.
        raw keys: name, type_str, default
        """
        try:
            type_info = parse_vhdl_type(raw["type_str"])
            signal_type = SignalType(
                base_type=type_info["base_type"],
                is_vector=type_info["is_vector"],
                vector_high=type_info["high"],
                vector_low=type_info["low"],
                is_descending=type_info["is_descending"],
                raw=type_info["raw"],
            )
            return Signal(
                name=raw["name"],
                kind=SignalKind.SIGNAL,
                signal_type=signal_type,
                direction=SignalDirection.INTERNAL,
                default_value=raw.get("default"),
                source_file=self.source_file,
                source_line=line if line > 0 else None,
            )
        except Exception as e:
            self._errors.append(f"Failed to build internal signal from {raw}: {e}")
            return None

    # ------------------------------------------------------------------
    # Generic / Parameter builder
    # ------------------------------------------------------------------

    def build_generic(self, raw: dict) -> GenericParameter | None:
        """
        Build a GenericParameter from a raw dict.
        raw keys: name, type_str, default
        """
        try:
            return GenericParameter(
                name=raw["name"],
                param_type=raw["type_str"],
                default_value=raw.get("default"),
            )
        except Exception as e:
            self._errors.append(f"Failed to build generic from {raw}: {e}")
            return None

    # ------------------------------------------------------------------
    # Process builder
    # ------------------------------------------------------------------

    def build_process(self, raw: dict) -> Process | None:
        """
        Build a Process from a raw dict extracted by the parser.

        raw keys:
            name              - optional process label
            sensitivity_list  - list of signal name strings
            signals_read      - list of signal name strings
            signals_written   - list of signal name strings
            line_start        - source line number
            line_end          - source line number
        """
        try:
            sensitivity = raw.get("sensitivity_list", [])

            # classify as sequential if any clock signal is in sensitivity list
            sens_lower = [s.lower() for s in sensitivity]
            has_clock = any(
                "clk" in s or "clock" in s for s in sens_lower
            )
            has_reset = any(
                "rst" in s or "reset" in s for s in sens_lower
            )
            kind = ProcessKind.SEQUENTIAL if has_clock else ProcessKind.COMBINATIONAL

            return Process(
                name=raw.get("name"),
                kind=kind,
                sensitivity_list=sensitivity,
                signals_read=raw.get("signals_read", []),
                signals_written=raw.get("signals_written", []),
                has_clock=has_clock,
                has_reset=has_reset,
                source_line_start=raw.get("line_start"),
                source_line_end=raw.get("line_end"),
            )
        except Exception as e:
            self._errors.append(f"Failed to build process from {raw}: {e}")
            return None

    # ------------------------------------------------------------------
    # Entity builder
    # ------------------------------------------------------------------

    def build_entity(
        self,
        name: str,
        ports: list[Signal],
        internal_signals: list[Signal],
        generics: list[GenericParameter],
        processes: list[Process],
        component_instances: list[str],
        architecture_body: str = "",
        header_comments: str = "",
    ) -> Entity:
        """
        Assemble the final Entity object from all parsed components.
        This is the last call the parser makes before returning.
        """
        return Entity(
            name=name,
            source_file=self.source_file,
            language=self.language,
            ports=[p for p in ports if p is not None],
            internal_signals=[s for s in internal_signals if s is not None],
            generics=[g for g in generics if g is not None],
            processes=[p for p in processes if p is not None],
            component_instances=component_instances,
            architecture_body=architecture_body or None,
            header_comments=header_comments or None,
        )

    # ------------------------------------------------------------------
    # Direction mappers
    # ------------------------------------------------------------------

    def _map_vhdl_direction(self, direction_str: str) -> SignalDirection:
        mapping = {
            "in": SignalDirection.IN,
            "out": SignalDirection.OUT,
            "inout": SignalDirection.INOUT,
            "buffer": SignalDirection.OUT,   # buffer behaves like out for our purposes
        }
        return mapping.get(direction_str.lower(), SignalDirection.IN)

    def _map_sv_direction(self, direction_str: str) -> SignalDirection:
        mapping = {
            "input": SignalDirection.IN,
            "output": SignalDirection.OUT,
            "inout": SignalDirection.INOUT,
        }
        return mapping.get(direction_str.lower(), SignalDirection.IN)

    # ------------------------------------------------------------------
    # Error access
    # ------------------------------------------------------------------

    @property
    def errors(self) -> list[str]:
        return self._errors

    @property
    def has_errors(self) -> bool:
        return len(self._errors) > 0