"""
sv_parser.py
------------
Parses SystemVerilog files into RTLGuard Entity objects.
Handles the subset of SV commonly found in FPGA designs:
    - Module declarations with port lists
    - always_ff and always_comb blocks
    - Internal logic/wire declarations
    - Submodule instantiations

Not supported in v0.1:
    - Interfaces and modports
    - Classes and OOP constructs
    - Assertions (SVA)
    - Parameterized types
"""

import re
from rtlguard.models.entity import LanguageSource
from rtlguard.parser.base_parser import BaseParser, ParserFactory
from rtlguard.parser.ast_builder import ASTBuilder
from rtlguard.parser.token_utils import (
    remove_sv_comments,
    normalize_whitespace,
    parse_sv_port_line,
    SV_KEYWORDS,
)


class SystemVerilogParser(BaseParser):

    def parse(self):
        """
        Main entry point. Reads the file and returns a populated Entity.
        """
        self.load()

        builder = ASTBuilder(
            source_file=self.source_file,
            language=LanguageSource.SYSTEM_VERILOG,
        )

        clean_text = remove_sv_comments(self._raw_text)

        entity_name = self._extract_module_name(clean_text)
        if not entity_name:
            self.log_error("Could not find module declaration")
            entity_name = self.path.stem

        header_comments = self._extract_header_comments()

        raw_ports = self._extract_ports(clean_text)
        ports = [
            builder.build_signal_from_sv_port(p, line=p.get("line", -1))
            for p in raw_ports
        ]

        raw_internals = self._extract_internal_signals(clean_text)
        internal_signals = [
            builder.build_internal_signal_from_vhdl(s, line=s.get("line", -1))
            for s in raw_internals
        ]

        raw_processes = self._extract_processes(clean_text)
        processes = [builder.build_process(p) for p in raw_processes]

        component_instances = self._extract_component_instances(clean_text)
        module_body = self._extract_module_body(clean_text)

        for err in builder.errors:
            self.log_warning(err)

        return builder.build_entity(
            name=entity_name,
            ports=[p for p in ports if p],
            internal_signals=[s for s in internal_signals if s],
            generics=[],
            processes=[p for p in processes if p],
            component_instances=component_instances,
            architecture_body=module_body,
            header_comments=header_comments,
        )

    # ------------------------------------------------------------------
    # Module name
    # ------------------------------------------------------------------

    def _extract_module_name(self, text: str) -> str | None:
        match = re.search(r'\bmodule\s+(\w+)', text, re.IGNORECASE)
        return match.group(1) if match else None

    # ------------------------------------------------------------------
    # Header comments
    # ------------------------------------------------------------------

    def _extract_header_comments(self) -> str:
        lines = []
        for line in self._lines:
            stripped = line.strip()
            if stripped.startswith("//"):
                lines.append(stripped[2:].strip())
            elif stripped == "":
                if lines:
                    lines.append("")
            else:
                break
        return "\n".join(lines).strip()

    # ------------------------------------------------------------------
    # Port extraction
    # ------------------------------------------------------------------

    def _extract_ports(self, text: str = None) -> list[dict]:
        """
        Extract ports from SV module header.
        Handles both ANSI style:
            module MyMod (
                input  logic clk,
                output logic data_out
            );
        """
        if text is None:
            text = remove_sv_comments(self._raw_text)

        ports = []

        # find module port list
        port_match = re.search(
            r'\bmodule\s+\w+\s*(?:#\s*\([^)]*\))?\s*\((.*?)\)\s*;',
            text,
            re.IGNORECASE | re.DOTALL
        )
        if not port_match:
            self.log_warning("No module port list found")
            return []

        port_content = port_match.group(1)
        declarations = [d.strip() for d in port_content.split(",") if d.strip()]

        for declaration in declarations:
            declaration = normalize_whitespace(declaration)
            if not declaration:
                continue
            line_num = self.find_line_number(declaration.split()[-1])
            parsed = parse_sv_port_line(declaration)
            if parsed:
                parsed["line"] = line_num
                ports.append(parsed)
            else:
                self.log_warning(f"Could not parse SV port: '{declaration}'")

        return ports

    # ------------------------------------------------------------------
    # Internal signal extraction
    # ------------------------------------------------------------------

    def _extract_internal_signals(self, text: str) -> list[dict]:
        """
        Extract internal logic/wire declarations:
            logic [7:0] counter;
            logic       state;
        """
        signals = []

        pattern = re.compile(
            r'\b(logic|wire|reg)\b\s*(?:\[(\d+):(\d+)\])?\s+(\w+)\s*(?:=\s*(.+?))?\s*;',
            re.IGNORECASE
        )

        for match in pattern.finditer(text):
            base_type = match.group(1)
            high = int(match.group(2)) if match.group(2) else None
            low = int(match.group(3)) if match.group(3) else None
            name = match.group(4)
            default = match.group(5)
            line_num = text[:match.start()].count("\n") + 1

            type_str = base_type
            if high is not None and low is not None:
                type_str = f"{base_type} [{high}:{low}]"

            signals.append({
                "name": name,
                "type_str": type_str,
                "default": default,
                "line": line_num,
            })

        return signals

    # ------------------------------------------------------------------
    # Process (always block) extraction
    # ------------------------------------------------------------------

    def _extract_processes(self, text: str = None) -> list[dict]:
        """
        Extract always, always_ff, always_comb blocks.
        """
        if text is None:
            text = remove_sv_comments(self._raw_text)

        processes = []
        lines = text.splitlines()

        always_pattern = re.compile(
            r'\b(always_ff|always_comb|always)\b\s*(?:@\s*\(([^)]*)\))?',
            re.IGNORECASE
        )
        end_pattern = re.compile(r'\bend\b', re.IGNORECASE)

        i = 0
        while i < len(lines):
            line = lines[i]
            match = always_pattern.search(line)
            if match:
                block_type = match.group(1).lower()
                sensitivity_raw = match.group(2) or ""

                # parse sensitivity list — strip posedge/negedge keywords
                sensitivity = []
                for token in re.split(r'[,\s]+', sensitivity_raw):
                    token = token.strip().lower()
                    if token and token not in ("posedge", "negedge", "or"):
                        sensitivity.append(token)

                line_start = i + 1
                line_end = line_start

                # find end of block — count begin/end pairs
                depth = 0
                for j in range(i, len(lines)):
                    if re.search(r'\bbegin\b', lines[j], re.IGNORECASE):
                        depth += 1
                    if end_pattern.search(lines[j]) and j > i:
                        depth -= 1
                        if depth <= 0:
                            line_end = j + 1
                            break

                block_text = "\n".join(lines[i:line_end])
                signals_written = self._find_assignments(block_text)
                signals_read = self._find_reads(block_text, signals_written)

                # classify
                has_clock = any("clk" in s or "clock" in s for s in sensitivity)
                is_ff = block_type == "always_ff" or has_clock

                processes.append({
                    "name": None,
                    "sensitivity_list": sensitivity,
                    "signals_read": signals_read,
                    "signals_written": signals_written,
                    "line_start": line_start,
                    "line_end": line_end,
                    "kind": "sequential" if is_ff else "combinational",
                })

                i = line_end
            else:
                i += 1

        return processes

    # ------------------------------------------------------------------
    # Module body extraction
    # ------------------------------------------------------------------

    def _extract_module_body(self, text: str) -> str:
        match = re.search(
            r'\bmodule\b.+?;(.*?)\bendmodule\b',
            text,
            re.IGNORECASE | re.DOTALL
        )
        return match.group(1).strip() if match else ""

    # ------------------------------------------------------------------
    # Component instance extraction
    # ------------------------------------------------------------------

    def _extract_component_instances(self, text: str) -> list[str]:
        """
        Find submodule instantiations:
            MySubModule u_sub (.clk(clk), .data(data));
        """
        pattern = re.compile(
            r'^\s*(\w+)\s+(\w+)\s*\(',
            re.MULTILINE
        )
        instances = []
        for match in pattern.finditer(text):
            module_name = match.group(1)
            if module_name.lower() not in SV_KEYWORDS:
                instances.append(module_name)
        return instances

    # ------------------------------------------------------------------
    # Signal read/write heuristics
    # ------------------------------------------------------------------

    def _find_assignments(self, block_text: str) -> list[str]:
        """Find signals assigned with <= or = inside always blocks."""
        pattern = re.compile(r'(\w+)\s*(?:<=|=)(?!=)', re.IGNORECASE)
        return list({m.group(1) for m in pattern.finditer(block_text)})

    def _find_reads(self, block_text: str, exclude: list[str]) -> list[str]:
        rhs_pattern = re.compile(r'(?:<=|=)(?!=)\s*(.+?);', re.DOTALL)
        condition_pattern = re.compile(r'\bif\s*\((.+?)\)', re.DOTALL | re.IGNORECASE)

        candidates = set()
        for match in rhs_pattern.finditer(block_text):
            words = re.findall(r'\b([a-zA-Z_]\w*)\b', match.group(1))
            candidates.update(words)
        for match in condition_pattern.finditer(block_text):
            words = re.findall(r'\b([a-zA-Z_]\w*)\b', match.group(1))
            candidates.update(words)

        exclude_set = set(w.lower() for w in exclude) | SV_KEYWORDS
        return [w for w in candidates if w.lower() not in exclude_set]

    # Override comment stripping for SV
    def strip_comments(self, text: str) -> str:
        return remove_sv_comments(text)


# ------------------------------------------------------------------
# Register with factory
# ------------------------------------------------------------------

ParserFactory.register(".sv", SystemVerilogParser)
ParserFactory.register(".v", SystemVerilogParser)