"""
base_parser.py
--------------
Abstract base class for all RTL parsers.
Defines the interface that vhdl_parser.py and sv_parser.py must implement.
Neither parser should be called directly — use ParserFactory at the bottom
of this file to get the right parser for a given file.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from rtlguard.models.entity import Entity


class BaseParser(ABC):
    """
    All parsers inherit from this. If you add a new language,
    subclass this and implement the three abstract methods.
    Everything else in RTLGuard will work without changes.
    """

    def __init__(self, source_file: str):
        self.source_file = source_file
        self.path = Path(source_file)
        self._raw_text: str = ""
        self._lines: list[str] = []
        self._errors: list[str] = []
        self._warnings: list[str] = []

    # ------------------------------------------------------------------
    # Abstract interface — subclasses must implement these
    # ------------------------------------------------------------------

    @abstractmethod
    def parse(self) -> Entity:
        """
        Parse the source file and return a fully populated Entity object.
        This is the main entry point for all parsers.
        """
        ...

    @abstractmethod
    def _extract_ports(self) -> list:
        """Extract and return all port declarations from the source."""
        ...

    @abstractmethod
    def _extract_processes(self) -> list:
        """Extract and return all process/always blocks from the source."""
        ...

    # ------------------------------------------------------------------
    # Shared utilities available to all subclasses
    # ------------------------------------------------------------------

    def load(self):
        """
        Read the source file into memory.
        Call this at the start of parse() in every subclass.
        """
        if not self.path.exists():
            raise FileNotFoundError(f"Source file not found: {self.source_file}")
        if not self.path.is_file():
            raise ValueError(f"Path is not a file: {self.source_file}")

        with open(self.path, "r", encoding="utf-8", errors="replace") as f:
            self._raw_text = f.read()

        self._lines = self._raw_text.splitlines()

    def strip_comments(self, text: str) -> str:
        """
        Remove comments from raw RTL text.
        Subclasses can override this if the comment syntax differs.
        Default handles VHDL double-dash comments.
        """
        cleaned = []
        for line in text.splitlines():
            # VHDL: -- comment
            if "--" in line:
                line = line[:line.index("--")]
            cleaned.append(line)
        return "\n".join(cleaned)

    def get_line(self, line_number: int) -> str:
        """Return a specific source line by 1-based line number."""
        if 1 <= line_number <= len(self._lines):
            return self._lines[line_number - 1]
        return ""

    def find_line_number(self, keyword: str, start: int = 0) -> int:
        """
        Find the 1-based line number of the first occurrence of a keyword.
        Returns -1 if not found.
        """
        for i, line in enumerate(self._lines[start:], start=start):
            if keyword.lower() in line.lower():
                return i + 1
        return -1

    def log_error(self, message: str, line: int = -1):
        location = f" (line {line})" if line > 0 else ""
        self._errors.append(f"ERROR{location}: {message}")

    def log_warning(self, message: str, line: int = -1):
        location = f" (line {line})" if line > 0 else ""
        self._warnings.append(f"WARNING{location}: {message}")

    @property
    def errors(self) -> list[str]:
        return self._errors

    @property
    def warnings(self) -> list[str]:
        return self._warnings

    @property
    def has_errors(self) -> bool:
        return len(self._errors) > 0

    def summary(self) -> dict:
        return {
            "source_file": self.source_file,
            "errors": self._errors,
            "warnings": self._warnings,
            "line_count": len(self._lines),
        }


# ------------------------------------------------------------------
# Parser factory — the only thing other modules should call
# ------------------------------------------------------------------

class ParserFactory:
    """
    Returns the right parser for a given file based on its extension.
    Usage:
        parser = ParserFactory.get_parser("my_design.vhd")
        entity = parser.parse()
    """

    _registry: dict[str, type] = {}

    @classmethod
    def register(cls, extension: str, parser_class: type):
        """Register a parser class for a file extension."""
        cls._registry[extension.lower()] = parser_class

    @classmethod
    def get_parser(cls, source_file: str) -> "BaseParser":
        ext = Path(source_file).suffix.lower()
        parser_class = cls._registry.get(ext)
        if parser_class is None:
            supported = list(cls._registry.keys())
            raise ValueError(
                f"No parser registered for extension '{ext}'. "
                f"Supported: {supported}"
            )
        return parser_class(source_file)