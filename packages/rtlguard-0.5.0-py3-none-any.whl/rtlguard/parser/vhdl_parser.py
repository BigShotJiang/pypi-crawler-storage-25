"""
vhdl_parser.py
--------------
Parses VHDL files into RTLGuard Entity objects.
Handles VHDL-93 and most VHDL-2008 constructs found in
nuclear I&C and safety-critical FPGA designs.

Supported:
    - Entity declarations with port and generic lists
    - Architecture bodies
    - Internal signal declarations
    - Process blocks with sensitivity lists
    - Component instantiations

Not supported (out of scope for RTLGuard v0.1):
    - Protected types
    - Generate statements (treated as opaque)
    - Configuration declarations
"""

import re
from rtlguard.models.entity import LanguageSource
from rtlguard.parser.base_parser import BaseParser, ParserFactory
from rtlguard.parser.ast_builder import ASTBuilder
from rtlguard.parser.token_utils import (
    remove_vhdl_comments,
    normalize_whitespace,
    split_on_semicolons,
    parse_vhdl_port_line,
    parse_vhdl_generic_line,
    VHDL_KEYWORDS,
)


class VHDLParser(BaseParser):

    def parse(self):
        """
        Main entry point. Reads the file, extracts all components,
        and returns a fully populated Entity.
        """
        self.load()

        builder = ASTBuilder(
            source_file=self.source_file,
            language=LanguageSource.VHDL,
        )

        clean_text = remove_vhdl_comments(self._raw_text)

        entity_name = self._extract_entity_name(clean_text)
        if not entity_name:
            self.log_error("Could not find entity declaration")
            entity_name = self.path.stem

        header_comments = self._extract_header_comments()

        raw_generics = self._extract_generics(clean_text)
        generics = [builder.build_generic(g) for g in raw_generics]

        raw_ports = self._extract_ports(clean_text)
        ports = [
            builder.build_signal_from_vhdl_port(p, line=p.get("line", -1))
            for p in raw_ports
        ]

        raw_internals = self._extract_internal_signals(clean_text)
        internal_signals = [
            builder.build_internal_signal_from_vhdl(s, line=s.get("line", -1))
            for s in raw_internals
        ]

        raw_processes = self._extract_processes(clean_text)
        processes = [builder.build_process(p) for p in raw_processes]

        component_instances = self._extract_component_instances(clean_text)
        arch_body = self._extract_architecture_body(clean_text)

        for err in builder.errors:
            self.log_warning(err)

        return builder.build_entity(
            name=entity_name,
            ports=[p for p in ports if p],
            internal_signals=[s for s in internal_signals if s],
            generics=[g for g in generics if g],
            processes=[p for p in processes if p],
            component_instances=component_instances,
            architecture_body=arch_body,
            header_comments=header_comments,
        )

    # ------------------------------------------------------------------
    # Entity name extraction
    # ------------------------------------------------------------------

    def _extract_entity_name(self, text: str) -> str | None:
        match = re.search(r'\bentity\s+(\w+)\s+is\b', text, re.IGNORECASE)
        return match.group(1) if match else None

    # ------------------------------------------------------------------
    # Header comment extraction
    # ------------------------------------------------------------------

    def _extract_header_comments(self) -> str:
        lines = []
        for line in self._lines:
            stripped = line.strip()
            if stripped.startswith("--"):
                lines.append(stripped[2:].strip())
            elif stripped == "":
                if lines:
                    lines.append("")
            else:
                break
        return "\n".join(lines).strip()

    # ------------------------------------------------------------------
    # Generic extraction
    # ------------------------------------------------------------------

    def _extract_generics(self, text: str) -> list[dict]:
        """
        Extract VHDL generics using paren-depth walking to correctly
        handle vector types like std_logic_vector(7 downto 0) inside
        the generic list without terminating early.
        """
        generic_start = re.search(r'\bgeneric\s*\(', text, re.IGNORECASE)
        if not generic_start:
            return []

        depth = 0
        start_idx = generic_start.end() - 1
        end_idx = start_idx

        for i in range(start_idx, len(text)):
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
                if depth == 0:
                    end_idx = i
                    break

        content = text[start_idx + 1:end_idx]
        generics = []

        for declaration in split_on_semicolons(content):
            parsed = parse_vhdl_generic_line(declaration)
            if parsed:
                generics.append(parsed)

        return generics

    # ------------------------------------------------------------------
    # Port extraction
    # ------------------------------------------------------------------

    def _extract_ports(self, text: str = None) -> list[dict]:
        """
        Extract port declarations using paren-depth walking to correctly
        handle vector types like std_logic_vector(7 downto 0) inside
        port declarations without terminating early.
        """
        if text is None:
            text = remove_vhdl_comments(self._raw_text)

        port_start = re.search(r'\bport\s*\(', text, re.IGNORECASE)
        if not port_start:
            self.log_warning("No port declaration found")
            return []

        depth = 0
        start_idx = port_start.end() - 1
        end_idx = start_idx

        for i in range(start_idx, len(text)):
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
                if depth == 0:
                    end_idx = i
                    break

        port_content = text[start_idx + 1:end_idx]
        ports = []

        for declaration in split_on_semicolons(port_content):
            declaration = normalize_whitespace(declaration)
            if not declaration:
                continue
            line_num = self.find_line_number(declaration.split()[0]) if declaration else -1
            parsed = parse_vhdl_port_line(declaration)
            if parsed:
                parsed["line"] = line_num
                ports.append(parsed)
            else:
                self.log_warning(f"Could not parse port declaration: '{declaration}'")

        return ports

    # ------------------------------------------------------------------
    # Internal signal extraction
    # ------------------------------------------------------------------

    def _extract_internal_signals(self, text: str) -> list[dict]:
        """
        Extract signals declared inside the architecture body:
            signal state        : std_logic;
            signal counter      : integer := 0;
            signal data_buffer  : std_logic_vector(7 downto 0);
        """
        signals = []

        pattern = re.compile(
            r'\bsignal\s+(\w+)\s*:\s*(.+?)(?::=\s*(.+?))?;',
            re.IGNORECASE
        )

        for match in pattern.finditer(text):
            line_num = text[:match.start()].count("\n") + 1
            signals.append({
                "name": match.group(1).strip(),
                "type_str": match.group(2).strip(),
                "default": match.group(3).strip() if match.group(3) else None,
                "line": line_num,
            })

        return signals

    # ------------------------------------------------------------------
    # Process extraction
    # ------------------------------------------------------------------

    def _extract_processes(self, text: str = None) -> list[dict]:
        """
        Extract all process blocks from the architecture body.
        Captures: optional label, sensitivity list, rough line range.
        """
        if text is None:
            text = remove_vhdl_comments(self._raw_text)

        processes = []

        process_pattern = re.compile(
            r'(?:(\w+)\s*:\s*)?process\s*(?:\(([^)]*)\))?',
            re.IGNORECASE
        )
        end_pattern = re.compile(r'\bend\s+process\b', re.IGNORECASE)

        lines = text.splitlines()
        i = 0
        while i < len(lines):
            line = lines[i]
            proc_match = process_pattern.search(line)
            if proc_match:
                label = proc_match.group(1)
                sensitivity_raw = proc_match.group(2) or ""
                sensitivity = [
                    s.strip() for s in sensitivity_raw.split(",") if s.strip()
                ]
                line_start = i + 1
                line_end = line_start

                for j in range(i + 1, len(lines)):
                    if end_pattern.search(lines[j]):
                        line_end = j + 1
                        break

                block_text = "\n".join(lines[i:line_end])
                signals_written = self._find_assignments(block_text)
                signals_read = self._find_reads(block_text, signals_written)

                processes.append({
                    "name": label,
                    "sensitivity_list": sensitivity,
                    "signals_read": signals_read,
                    "signals_written": signals_written,
                    "line_start": line_start,
                    "line_end": line_end,
                })

                i = line_end
            else:
                i += 1

        return processes

    # ------------------------------------------------------------------
    # Architecture body extraction
    # ------------------------------------------------------------------

    def _extract_architecture_body(self, text: str) -> str:
        match = re.search(
            r'\barchitecture\b.+?\bbegin\b(.*?)\bend\b',
            text,
            re.IGNORECASE | re.DOTALL
        )
        return match.group(1).strip() if match else ""

    # ------------------------------------------------------------------
    # Component instance extraction
    # ------------------------------------------------------------------

    def _extract_component_instances(self, text: str) -> list[str]:
        pattern = re.compile(
            r'(\w+)\s*:\s*(\w+)\s+port\s+map',
            re.IGNORECASE
        )
        return [m.group(2) for m in pattern.finditer(text)]

    # ------------------------------------------------------------------
    # Signal read/write heuristics
    # ------------------------------------------------------------------

    def _find_assignments(self, block_text: str) -> list[str]:
        pattern = re.compile(r'(\w+)\s*<=', re.IGNORECASE)
        return list({m.group(1) for m in pattern.finditer(block_text)})

    def _find_reads(self, block_text: str, exclude: list[str]) -> list[str]:
        rhs_pattern = re.compile(r'<=\s*(.+?);', re.DOTALL)
        condition_pattern = re.compile(r'\bif\b(.+?)\bthen\b', re.DOTALL | re.IGNORECASE)

        candidates = set()
        for match in rhs_pattern.finditer(block_text):
            words = re.findall(r'\b([a-zA-Z_]\w*)\b', match.group(1))
            candidates.update(words)
        for match in condition_pattern.finditer(block_text):
            words = re.findall(r'\b([a-zA-Z_]\w*)\b', match.group(1))
            candidates.update(words)

        exclude_set = set(w.lower() for w in exclude) | VHDL_KEYWORDS
        return [w for w in candidates if w.lower() not in exclude_set]


# ------------------------------------------------------------------
# Register this parser with the factory
# ------------------------------------------------------------------

ParserFactory.register(".vhd", VHDLParser)
ParserFactory.register(".vhdl", VHDLParser)