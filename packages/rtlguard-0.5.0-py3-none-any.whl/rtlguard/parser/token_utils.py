"""
token_utils.py
--------------
Lightweight tokenization and text utilities for RTL parsing.
Not a full lexer — just enough to reliably extract the patterns
RTLGuard needs without pulling in a heavy parser dependency.
"""

import re
from typing import Optional


# ------------------------------------------------------------------
# VHDL keyword sets
# ------------------------------------------------------------------

VHDL_KEYWORDS = {
    "entity", "architecture", "port", "map", "generic", "signal",
    "variable", "constant", "process", "begin", "end", "if", "then",
    "else", "elsif", "case", "when", "others", "in", "out", "inout",
    "buffer", "is", "of", "downto", "to", "rising_edge", "falling_edge",
    "std_logic", "std_logic_vector", "integer", "natural", "boolean",
    "unsigned", "signed", "type", "subtype", "component", "wait",
}

SV_KEYWORDS = {
    "module", "endmodule", "input", "output", "inout", "logic", "wire",
    "reg", "parameter", "localparam", "always", "always_ff", "always_comb",
    "posedge", "negedge", "begin", "end", "if", "else", "case", "endcase",
    "assign", "initial", "integer", "bit", "byte", "shortint", "int",
    "longint", "typedef", "enum", "struct", "interface", "modport",
}


# ------------------------------------------------------------------
# General text utilities
# ------------------------------------------------------------------

def normalize_whitespace(text: str) -> str:
    """Collapse all whitespace runs to single spaces."""
    return re.sub(r'\s+', ' ', text).strip()


def remove_vhdl_comments(text: str) -> str:
    """Remove VHDL -- comments from a block of text."""
    lines = []
    for line in text.splitlines():
        if "--" in line:
            line = line[:line.index("--")]
        lines.append(line)
    return "\n".join(lines)


def remove_sv_comments(text: str) -> str:
    """Remove SV // line comments and /* */ block comments."""
    # block comments first
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    # line comments
    lines = []
    for line in text.splitlines():
        if "//" in line:
            line = line[:line.index("//")]
        lines.append(line)
    return "\n".join(lines)


def extract_block(text: str, start_keyword: str, end_keyword: str) -> Optional[str]:
    """
    Extract the text between start_keyword and end_keyword (inclusive).
    Case-insensitive. Returns None if not found.
    Useful for pulling out entity blocks, architecture bodies, port lists.
    """
    pattern = re.compile(
        rf'\b{re.escape(start_keyword)}\b(.*?)\b{re.escape(end_keyword)}\b',
        re.IGNORECASE | re.DOTALL
    )
    match = pattern.search(text)
    if match:
        return match.group(0)
    return None


def find_all_matches(pattern: str, text: str, flags=re.IGNORECASE) -> list[re.Match]:
    """Return all regex matches in text."""
    return list(re.finditer(pattern, text, flags))


def split_on_semicolons(text: str) -> list[str]:
    """
    Split a block of HDL declarations on semicolons.
    Returns non-empty stripped tokens.
    Useful for splitting port lists and signal declarations.
    """
    return [t.strip() for t in text.split(";") if t.strip()]


# ------------------------------------------------------------------
# VHDL-specific token extractors
# ------------------------------------------------------------------

def parse_vhdl_type(type_str: str) -> dict:
    """
    Parse a VHDL type string into components.
    Returns a dict with keys: base_type, is_vector, high, low, is_descending.

    Examples:
        "std_logic"                      → scalar
        "std_logic_vector(7 downto 0)"   → vector, high=7, low=0, descending
        "std_logic_vector(0 to 7)"       → vector, high=7, low=0, ascending
        "integer"                         → scalar
    """
    type_str = type_str.strip().lower()

    vector_pattern = re.compile(
        r'(\w[\w_]*)\s*\(\s*(\d+)\s*(downto|to)\s*(\d+)\s*\)',
        re.IGNORECASE
    )
    match = vector_pattern.match(type_str)

    if match:
        base = match.group(1)
        left = int(match.group(2))
        direction = match.group(3).lower()
        right = int(match.group(4))
        is_descending = direction == "downto"
        high = left if is_descending else right
        low = right if is_descending else left
        return {
            "base_type": base,
            "is_vector": True,
            "high": high,
            "low": low,
            "is_descending": is_descending,
            "raw": type_str,
        }

    return {
        "base_type": type_str,
        "is_vector": False,
        "high": None,
        "low": None,
        "is_descending": True,
        "raw": type_str,
    }


def parse_vhdl_port_line(line: str) -> Optional[dict]:
    """
    Parse a single VHDL port declaration line.
    Returns a dict with keys: name, direction, type_str, default.
    Returns None if the line doesn't match a port pattern.

    Handles:
        clk       : in  std_logic
        data_in   : in  std_logic_vector(7 downto 0)
        data_out  : out std_logic_vector(7 downto 0) := (others => '0')
    """
    line = normalize_whitespace(line.strip().rstrip(";").rstrip(","))

    pattern = re.compile(
        r'^(\w+)\s*:\s*(in|out|inout|buffer)\s+(.+?)(?::=\s*(.+))?$',
        re.IGNORECASE
    )
    match = pattern.match(line)
    if not match:
        return None

    return {
        "name": match.group(1).strip(),
        "direction": match.group(2).strip().lower(),
        "type_str": match.group(3).strip(),
        "default": match.group(4).strip() if match.group(4) else None,
    }


def parse_vhdl_generic_line(line: str) -> Optional[dict]:
    """
    Parse a single VHDL generic declaration.
    Returns dict with keys: name, type_str, default. Or None.

    Handles:
        DATA_WIDTH : integer := 8
        RESET_VAL  : std_logic := '0'
    """
    line = normalize_whitespace(line.strip().rstrip(";").rstrip(","))
    pattern = re.compile(
        r'^(\w+)\s*:\s*(\w[\w_\s]*?)(?::=\s*(.+))?$',
        re.IGNORECASE
    )
    match = pattern.match(line)
    if not match:
        return None
    return {
        "name": match.group(1).strip(),
        "type_str": match.group(2).strip(),
        "default": match.group(3).strip() if match.group(3) else None,
    }


def extract_sensitivity_list(process_text: str) -> list[str]:
    """
    Extract signals from a VHDL process sensitivity list.
    process_text should be the process header line.

    Handles:
        process(clk, rst_n)
        process (clk)
        process(all)   -- VHDL-2008
    """
    match = re.search(r'process\s*\(([^)]*)\)', process_text, re.IGNORECASE)
    if not match:
        return []
    content = match.group(1).strip()
    if content.lower() == "all":
        return ["all"]
    return [s.strip() for s in content.split(",") if s.strip()]


# ------------------------------------------------------------------
# SV-specific token extractors
# ------------------------------------------------------------------

def parse_sv_port_line(line: str) -> Optional[dict]:
    """
    Parse a single SystemVerilog port declaration.
    Returns dict with keys: name, direction, type_str, default. Or None.

    Handles:
        input  logic        clk
        output logic [7:0]  data_out
        input  logic [7:0]  data_in = 8'h00
    """
    line = normalize_whitespace(line.strip().rstrip(",").rstrip(";"))

    pattern = re.compile(
        r'^(input|output|inout)\s+(logic|wire|reg)?\s*(\[\d+:\d+\])?\s*(\w+)(?:\s*=\s*(.+))?$',
        re.IGNORECASE
    )
    match = pattern.match(line)
    if not match:
        return None

    return {
        "direction": match.group(1).strip().lower(),
        "type_str": (match.group(2) or "logic").strip()
                    + (" " + match.group(3).strip() if match.group(3) else ""),
        "name": match.group(4).strip(),
        "default": match.group(5).strip() if match.group(5) else None,
    }


def parse_sv_vector_type(type_str: str) -> dict:
    """
    Parse a SV vector type like 'logic [7:0]' into components.
    """
    type_str = type_str.strip()
    pattern = re.compile(r'(\w+)\s*\[(\d+):(\d+)\]')
    match = pattern.search(type_str)
    if match:
        high = int(match.group(2))
        low = int(match.group(3))
        return {
            "base_type": match.group(1),
            "is_vector": True,
            "high": high,
            "low": low,
            "is_descending": high >= low,
            "raw": type_str,
        }
    return {
        "base_type": type_str,
        "is_vector": False,
        "high": None,
        "low": None,
        "is_descending": True,
        "raw": type_str,
    }