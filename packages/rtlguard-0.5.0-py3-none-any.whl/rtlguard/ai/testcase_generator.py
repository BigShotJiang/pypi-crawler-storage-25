"""
testcase_generator.py
---------------------
AI-powered test case generator.

Sends the RTL source code (and optional design spec) to the AI provider
and returns a structured list of concrete, module-specific test cases.
"""

import json
from dataclasses import dataclass, field
from typing import Optional

from rtlguard.ai.base import AIProvider
from rtlguard.models.entity import Entity


_SYSTEM_PROMPT = """\
You are an expert verification engineer specialising in FPGA and ASIC design. \
You generate comprehensive, concrete test cases for RTL modules. Your test cases \
are precise, cover both normal operation and edge/corner cases, and are directly \
usable by a simulation engineer without further interpretation.\
"""

_RESPONSE_SCHEMA = {
    "module": "<entity name>",
    "test_cases": [
        {
            "id": "TC-001",
            "name": "Short descriptive name",
            "description": "One sentence — what this test verifies",
            "stimulus": [
                {"signal": "<port name>", "value": "<value>"}
            ],
            "expected_outputs": [
                {"signal": "<port name>", "value": "<value>"}
            ],
            "priority": "critical | high | medium | low",
        }
    ],
}


@dataclass
class TCSignal:
    signal: str
    value: str


@dataclass
class TCItem:
    id: str
    name: str
    description: str
    stimulus: list[TCSignal]
    expected_outputs: list[TCSignal]
    priority: str = "medium"


@dataclass
class TCResult:
    module: str
    test_cases: list[TCItem] = field(default_factory=list)
    error: Optional[str] = None

    @property
    def has_error(self) -> bool:
        return self.error is not None


_REFORMAT_SYSTEM = """\
You are an expert verification engineer. You clean up and canonicalise lists \
of RTL test cases: removing duplicates, discarding incomplete entries, and \
fixing formatting.\
"""

_TC_FORMAT_SPEC = """\
[TC-001] Test case name  (PRIORITY)
  One-line description.
  Stimulus:
    signal_name = value
  Expected:
    signal_name == value\
"""


class TestCaseGenerator:
    """
    Generates concrete test cases for an RTL module using AI.

    Usage:
        gen    = TestCaseGenerator(provider)
        result = gen.generate(entity, source_text, spec_text=None)
    """

    def __init__(self, provider: AIProvider):
        self.provider = provider

    def reformat(self, tc_text: str, entity: Entity) -> tuple[str, Optional[str]]:
        """Reformat user-edited test case text into canonical format.

        Returns (cleaned_text, error). error is None on success; on failure
        the original tc_text is returned unchanged.
        """
        user_message = "\n\n".join([
            f"## Module: {entity.name}",
            "## Test Cases (user-edited — may contain notes or formatting issues)",
            tc_text,
            "## Task",
            (
                "Clean up the test cases above:\n"
                "1. Remove duplicate entries (same ID or same name — keep the first)\n"
                "2. Remove any entry that is missing a Stimulus or Expected section\n"
                "3. Renumber IDs sequentially as TC-001, TC-002, …\n"
                "4. Reformat every entry using exactly this layout:\n\n"
                f"{_TC_FORMAT_SPEC}\n\n"
                "Priority must be one of: CRITICAL, HIGH, MEDIUM, LOW (uppercase).\n"
                "Return ONLY the cleaned test cases. "
                "No introduction, no summary, no markdown fences."
            ),
        ])
        try:
            text, _ = self.provider.complete(
                system=_REFORMAT_SYSTEM,
                user=user_message,
                max_tokens=4096,
            )
            return text.strip(), None
        except Exception as exc:
            return tc_text, str(exc)

    def generate(
        self,
        entity: Entity,
        source_text: str,
        spec_text: Optional[str] = None,
    ) -> TCResult:
        user_message = self._build_user_message(entity, source_text, spec_text)
        try:
            text, _ = self.provider.complete(
                system=_SYSTEM_PROMPT,
                user=user_message,
                max_tokens=8192,
            )
        except Exception as exc:
            return TCResult(module=entity.name, error=str(exc))

        return self._parse(entity.name, text)

    def _build_user_message(
        self,
        entity: Entity,
        source_text: str,
        spec_text: Optional[str],
    ) -> list[dict]:
        source = (
            f"## RTL Source: {entity.name} ({entity.language.value})"
            f"\n\n```\n{source_text}\n```"
        )
        if spec_text:
            source += f"\n\n## Design Specification / Requirements\n\n{spec_text}"

        task = "\n\n".join([
            "## Task",
            (
                "Generate a concise set of test cases for this module. "
                "Use actual signal names and realistic values from the source. "
                "Cover reset behaviour, normal operation, and boundary/edge cases. "
                "No descriptions, no summaries, no extra fields — only what is in the schema."
            ),
            f"## Response Schema\n```json\n{json.dumps(_RESPONSE_SCHEMA, indent=2)}\n```",
            "Respond with JSON only. No markdown fences, no explanation outside the JSON.",
        ])

        return [
            {"type": "text", "text": source, "cache_control": {"type": "ephemeral"}},
            {"type": "text", "text": task},
        ]

    def _parse(self, module_name: str, text: str) -> TCResult:
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            stripped = text.strip()
            if stripped.startswith("```"):
                lines = stripped.splitlines()
                stripped = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])
            try:
                data = json.loads(stripped)
            except json.JSONDecodeError as exc:
                return TCResult(
                    module=module_name,
                    error=f"JSON parse error: {exc}. Raw: {text[:300]}",
                )

        test_cases = []
        for tc in data.get("test_cases", []):
            stimulus = [
                TCSignal(s.get("signal", ""), s.get("value", ""))
                for s in tc.get("stimulus", [])
            ]
            expected = [
                TCSignal(s.get("signal", ""), s.get("value", ""))
                for s in tc.get("expected_outputs", [])
            ]
            test_cases.append(TCItem(
                id=tc.get("id", "TC-???"),
                name=tc.get("name", ""),
                description=tc.get("description", ""),
                stimulus=stimulus,
                expected_outputs=expected,
                priority=tc.get("priority", "medium"),
            ))

        return TCResult(
            module=data.get("module", module_name),
            test_cases=test_cases,
        )
