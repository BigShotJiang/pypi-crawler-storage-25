"""
fpga_checker.py
---------------
AI-powered FPGA best-practice checker.

Sends the RTL source code to the AI provider and returns a structured
list of violations with suggested fixes. Called before test case
generation so the user can clean up the design first.
"""

import json
from dataclasses import dataclass, field
from typing import Optional

from rtlguard.ai.base import AIProvider
from rtlguard.models.entity import Entity


_SYSTEM_PROMPT = """\
You are an expert FPGA design engineer with deep knowledge of VHDL and \
SystemVerilog. You review RTL source code for correctness, safety, and \
adherence to industry-standard FPGA coding practices. You are concise, \
precise, and focus only on real issues — not style preferences.\
"""

_RESPONSE_SCHEMA = {
    "violations": [
        {
            "id": "FPGA-001",
            "severity": "critical | high | medium | low",
            "title": "Short title of the issue",
            "description": "What is wrong and where in the code",
            "suggestion": "Concrete fix the designer should apply",
        }
    ],
    "clean": False,
}

_RULES_CONTEXT = """\
Check for the following FPGA best-practice violations (not an exhaustive list — \
report anything else you find):

CRITICAL
- Combinational feedback loops (output of logic fed directly back to its own input)
- Multiple drivers on the same signal
- Undriven output ports (outputs that are never assigned)

HIGH
- Inferred latches (incomplete if/case in a combinational process — missing else \
or default assignment)
- Blocking assignments (=) used in clocked/sequential processes (SystemVerilog)
- Non-blocking assignments (<=) used in combinational always blocks (SystemVerilog)
- Asynchronous reset in a design that mixes async and sync resets inconsistently
- Clock gating without a dedicated clock buffer or enable register

MEDIUM
- Sequential process has no reset handler (no handling of rst/reset condition)
- Sensitivity list is incomplete for a combinational process (missing signals that \
are read inside the process)
- Magic numbers used instead of named constants/parameters/generics
- Processes or always blocks without labels/names
- Signals declared but never used

LOW
- Signal naming does not follow a consistent convention
- Missing port direction comments or block-level comments for complex logic
- Reset polarity inconsistency (some active-high, some active-low in the same design)\
"""


@dataclass
class FPGAViolation:
    id: str
    severity: str
    title: str
    description: str
    suggestion: str


@dataclass
class FPGACheckResult:
    violations: list[FPGAViolation] = field(default_factory=list)
    clean: bool = False
    error: Optional[str] = None



class FPGAChecker:
    """
    Sends RTL source code to the AI provider for FPGA best-practice review.

    Usage:
        checker = FPGAChecker(provider)
        result  = checker.check(entity, source_text)
    """

    def __init__(self, provider: AIProvider):
        self.provider = provider

    def check(self, entity: Entity, source_text: str) -> FPGACheckResult:
        """Full check — finds all violations in the source."""
        user_message = self._build_check_message(entity, source_text)
        try:
            text, _ = self.provider.complete(
                system=_SYSTEM_PROMPT,
                user=user_message,
                max_tokens=4096,
            )
        except Exception as exc:
            return FPGACheckResult(error=str(exc))

        return self._parse(text)

    def recheck(
        self,
        entity: Entity,
        source_text: str,
        original_violations: list[FPGAViolation],
    ) -> FPGACheckResult:
        """Re-check only the original violations — does not introduce new ones."""
        user_message = self._build_recheck_message(entity, source_text, original_violations)
        try:
            text, _ = self.provider.complete(
                system=_SYSTEM_PROMPT,
                user=user_message,
                max_tokens=2048,
            )
        except Exception as exc:
            return FPGACheckResult(error=str(exc))

        return self._parse(text)

    def _source_block(self, entity: Entity, source_text: str) -> dict:
        return {
            "type": "text",
            "text": (
                f"## RTL Source: {entity.name} ({entity.language.value})"
                f"\n\n```\n{source_text}\n```"
            ),
            "cache_control": {"type": "ephemeral"},
        }

    def _build_check_message(self, entity: Entity, source_text: str) -> list[dict]:
        return [
            self._source_block(entity, source_text),
            {
                "type": "text",
                "text": "\n\n".join([
                    "## Task",
                    _RULES_CONTEXT,
                    "Review the source code above for ALL violations listed. "
                    "Be specific — reference line numbers or signal names where possible. "
                    "If the design is clean, set `clean: true` and `violations: []`.",
                    f"## Response Schema\n```json\n{json.dumps(_RESPONSE_SCHEMA, indent=2)}\n```",
                    "Respond with JSON only. No markdown fences, no explanation outside the JSON.",
                ]),
            },
        ]

    def _build_recheck_message(
        self,
        entity: Entity,
        source_text: str,
        original_violations: list[FPGAViolation],
    ) -> list[dict]:
        violation_list = "\n".join(
            f"- [{v.id}] {v.severity.upper()}: {v.title}"
            for v in original_violations
        )
        return [
            self._source_block(entity, source_text),
            {
                "type": "text",
                "text": "\n\n".join([
                    "## Task",
                    "The designer has updated the source code. Check ONLY whether the "
                    "following previously identified violations have been fixed. "
                    "Do NOT introduce any new violations.\n\n"
                    f"Original violations to verify:\n{violation_list}",
                    "For each violation still present, include it in the response. "
                    "If all are fixed, set `clean: true` and `violations: []`.",
                    f"## Response Schema\n```json\n{json.dumps(_RESPONSE_SCHEMA, indent=2)}\n```",
                    "Respond with JSON only. No markdown fences, no explanation outside the JSON.",
                ]),
            },
        ]

    def _parse(self, text: str) -> FPGACheckResult:
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            # try stripping markdown fences if present
            stripped = text.strip()
            if stripped.startswith("```"):
                lines = stripped.splitlines()
                stripped = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])
            try:
                data = json.loads(stripped)
            except json.JSONDecodeError as exc:
                return FPGACheckResult(
                    error=f"JSON parse error: {exc}. Raw: {text[:300]}"
                )

        violations = [
            FPGAViolation(
                id=v.get("id", "FPGA-???"),
                severity=v.get("severity", "medium"),
                title=v.get("title", ""),
                description=v.get("description", ""),
                suggestion=v.get("suggestion", ""),
            )
            for v in data.get("violations", [])
        ]

        return FPGACheckResult(
            violations=violations,
            clean=data.get("clean", False),
        )
