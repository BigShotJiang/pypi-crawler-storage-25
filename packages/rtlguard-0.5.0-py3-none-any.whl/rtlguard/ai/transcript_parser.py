"""
transcript_parser.py
--------------------
Parses a ModelSim/Questa simulation transcript log to extract failing
test cases and simulation errors.

ModelSim emits lines like:
  ** Error: [TC-003] Reset behaviour: data_out expected 0x00, got 0xFF
  ** Fatal: (vsim-3601) Simulation stopped
  $error called at time 150ns in tb_counter.sv

We collect every failure line and the test-case IDs mentioned in them.
"""

import re
from dataclasses import dataclass, field
from pathlib import Path


_TC_ID_RE = re.compile(r"\[TC-\d{3}\]")
_ERROR_LINE_RE = re.compile(
    r"(\*\*\s*(Error|Fatal|Warning)|\$error|\bFAIL\b)", re.IGNORECASE
)


@dataclass
class TranscriptResult:
    failure_lines: list[str] = field(default_factory=list)
    failing_tc_ids: list[str] = field(default_factory=list)
    has_failures: bool = False
    error: str = ""


def parse_transcript(log_text: str) -> TranscriptResult:
    """Extract failure information from a ModelSim/Questa transcript."""
    failures = []
    tc_ids_seen: set[str] = set()

    for line in log_text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if _ERROR_LINE_RE.search(stripped):
            failures.append(stripped)
            for m in _TC_ID_RE.finditer(stripped):
                tc_id = m.group(0)           # e.g. "[TC-003]"
                tc_ids_seen.add(tc_id)

    return TranscriptResult(
        failure_lines=failures,
        failing_tc_ids=sorted(tc_ids_seen),
        has_failures=bool(failures),
    )


def parse_transcript_file(path: str) -> TranscriptResult:
    p = Path(path)
    if not p.exists():
        return TranscriptResult(error=f"Transcript file not found: {path}")
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return TranscriptResult(error=str(exc))
    return parse_transcript(text)
