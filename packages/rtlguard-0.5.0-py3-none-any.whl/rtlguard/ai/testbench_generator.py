"""
testbench_generator.py
----------------------
AI-powered SystemVerilog testbench generator.

Takes an entity interface and the previously generated test cases,
then produces a complete, runnable SystemVerilog testbench file.
"""

from pathlib import Path
from typing import Optional

from rtlguard.ai.base import AIProvider
from rtlguard.models.entity import Entity


_SYSTEM_PROMPT = """\
You are an expert verification engineer. You write clean, complete, and \
immediately runnable SystemVerilog testbenches. Your testbenches follow \
industry best practices: they instantiate the DUT correctly, generate clocks, \
apply resets, and implement each test case as a clearly labelled task or \
sequence. You produce self-checking testbenches with $display and $error \
statements wherever a pass/fail check can be automated.\
"""

_TASK_INSTRUCTIONS = (
    "Requirements:\n"
    "- Instantiate the DUT with correct port connections\n"
    "- Generate a clock (use a 10ns period unless the source specifies otherwise)\n"
    "- Apply a proper reset sequence at the start\n"
    "- Implement each test case above as a clearly labelled `initial` block "
    "or named task\n"
    "- Add $display messages identifying each test case by ID and name\n"
    "- Add automated pass/fail checks using $error or assertions where the "
    "expected output is deterministic\n"
    "- End with a $finish\n\n"
    "Return ONLY the SystemVerilog code. No explanation, no markdown fences."
)


def _source_block(entity: Entity, source_text: Optional[str]) -> dict:
    if source_text:
        text = (
            f"## Module: {entity.name} ({entity.language.value})"
            f"\n\n## RTL Source\n\n```\n{source_text}\n```"
        )
    else:
        ports = [f"  {p.direction.value} {p.data_type} {p.name}" for p in entity.ports]
        text = (
            f"## Module: {entity.name} ({entity.language.value})"
            f"\n\n## Module Interface\n\n```systemverilog\nmodule {entity.name} ("
            + ",\n".join(ports)
            + "\n);\n```"
        )
    return {"type": "text", "text": text, "cache_control": {"type": "ephemeral"}}


class TestbenchGenerator:
    """
    Generates a complete SystemVerilog testbench for a given module and test cases.

    Usage:
        gen  = TestbenchGenerator(provider)
        code = gen.generate_from_text(entity, tc_text, source_text)
        gen.write(code, output_dir, entity.name)
    """

    def __init__(self, provider: AIProvider):
        self.provider = provider

    def generate_from_text(
        self,
        entity: Entity,
        tc_text: str,
        source_text: Optional[str] = None,
    ) -> str:
        """Generate testbench from raw test-cases text (e.g. the saved .txt file)."""
        user_blocks = [
            _source_block(entity, source_text),
            {
                "type": "text",
                "text": "\n\n".join([
                    "## Test Cases to Implement",
                    tc_text,
                    "## Task",
                    f"Write a complete, runnable SystemVerilog testbench for `{entity.name}`. "
                    + _TASK_INSTRUCTIONS,
                ]),
            },
        ]
        text, _ = self.provider.complete(
            system=_SYSTEM_PROMPT,
            user=user_blocks,
            max_tokens=8192,
        )
        return self._extract_sv(text)

    def write(self, sv_code: str, output_dir: str, module_name: str) -> Path:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        path = out / f"{module_name}_tb.sv"
        path.write_text(sv_code)
        return path

    def _extract_sv(self, text: str) -> str:
        stripped = text.strip()
        # Strip markdown fences if the model wrapped the output
        if stripped.startswith("```"):
            lines = stripped.splitlines()
            end = len(lines) - 1 if lines[-1].strip() == "```" else len(lines)
            stripped = "\n".join(lines[1:end])
        return stripped
