"""
usage_tracker.py
----------------
Module-level session accumulator for AI token usage.

The provider records usage after every complete() call. commands.py
reads the summary at the end of each pipeline run and displays it.
"""

_session: dict = {
    "calls": 0,
    "input_tokens": 0,
    "output_tokens": 0,
    "cache_read_tokens": 0,
    "cache_creation_tokens": 0,
}


def record(usage: dict) -> None:
    _session["calls"] += 1
    _session["input_tokens"] += usage.get("input_tokens", 0)
    _session["output_tokens"] += usage.get("output_tokens", 0)
    _session["cache_read_tokens"] += usage.get("cache_read_tokens", 0)
    _session["cache_creation_tokens"] += usage.get("cache_creation_tokens", 0)


def summary() -> dict:
    return dict(_session)


def reset() -> None:
    for k in _session:
        _session[k] = 0
