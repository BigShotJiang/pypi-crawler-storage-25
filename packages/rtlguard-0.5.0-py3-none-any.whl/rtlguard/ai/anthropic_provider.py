"""
anthropic_provider.py
---------------------
AIProvider implementation backed by the Anthropic Messages API.

Wraps the system prompt in cache_control blocks so repeated calls
within a 5-minute window benefit from prompt caching.

Requires: pip install anthropic
Env var:  ANTHROPIC_API_KEY
"""

import os
from rtlguard.ai.base import AIProvider
from rtlguard.ai.usage_tracker import record as _record_usage

DEFAULT_MODEL = "claude-sonnet-4-6"


class AnthropicProvider(AIProvider):
    """
    Usage:
        provider = AnthropicProvider()  # reads ANTHROPIC_API_KEY from env
        provider = AnthropicProvider(model="claude-opus-4-7", api_key="sk-ant-...")
        text, usage = provider.complete(system, user, max_tokens=4096)
    """

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        api_key: str | None = None,
    ):
        try:
            import anthropic as _anthropic
        except ImportError:
            raise RuntimeError(
                "anthropic package not installed. Run: pip install anthropic"
            )
        self._anthropic = _anthropic
        self._model = model
        self._client = _anthropic.Anthropic(
            api_key=api_key or os.environ.get("ANTHROPIC_API_KEY")
        )

    @property
    def name(self) -> str:
        return "anthropic"

    @property
    def model(self) -> str:
        return self._model

    @property
    def supports_caching(self) -> bool:
        return True

    def complete(
        self,
        system: str,
        user: "str | list[dict]",
        max_tokens: int,
    ) -> tuple[str, dict]:
        system_blocks = [
            {
                "type": "text",
                "text": system,
                "cache_control": {"type": "ephemeral"},
            }
        ]
        user_content = (
            [{"type": "text", "text": user}] if isinstance(user, str) else user
        )
        try:
            response = self._client.messages.create(
                model=self._model,
                max_tokens=max_tokens,
                system=system_blocks,
                messages=[{"role": "user", "content": user_content}],
            )
        except self._anthropic.APIError as exc:
            raise RuntimeError(f"Anthropic API error: {exc}") from exc

        usage = response.usage
        usage_dict = {
            "input_tokens": usage.input_tokens,
            "output_tokens": usage.output_tokens,
            "cache_read_tokens": getattr(usage, "cache_read_input_tokens", 0),
            "cache_creation_tokens": getattr(usage, "cache_creation_input_tokens", 0),
        }
        _record_usage(usage_dict)
        return response.content[0].text, usage_dict
