"""
api_key.py
----------
Centralised API key access for RTLGuard.

Currently reads from the ANTHROPIC_API_KEY environment variable.
Structured so the key source can be swapped to a backend license
server later without touching any other code — callers always go
through get_api_key() and never reference the env var directly.
"""

import os


_ENV_VAR = "ANTHROPIC_API_KEY"


def get_api_key() -> str:
    """
    Return the Anthropic API key.

    Raises RuntimeError with a clear message if the key is not available.
    Future: replace the body of this function with a call to the
    RTLGuard license server — no other files need to change.
    """
    key = os.environ.get(_ENV_VAR, "").strip()
    if not key:
        raise RuntimeError(
            "RTLGuard API key not found.\n"
            f"Set the {_ENV_VAR} environment variable and try again.\n"
            "  macOS/Linux:  export ANTHROPIC_API_KEY=sk-ant-...\n"
            "  Windows:      set ANTHROPIC_API_KEY=sk-ant-..."
        )
    return key
