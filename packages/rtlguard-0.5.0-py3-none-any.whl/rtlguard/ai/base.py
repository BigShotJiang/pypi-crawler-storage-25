"""
base.py
-------
Abstract base class for all AI provider adapters.

Each provider implements complete() — one API call that takes a system
prompt and a user message and returns (response_text, usage_dict).

The rest of the review layer (AIReviewer, prompts) is provider-agnostic.
"""

from abc import ABC, abstractmethod


class AIProvider(ABC):
    """
    Transport adapter for a single AI API.

    Subclasses: AnthropicProvider, OpenAIProvider, GoogleProvider.

    Usage:
        provider = AnthropicProvider(model="claude-sonnet-4-6")
        text, usage = provider.complete(system, user, max_tokens=4096)
    """

    @abstractmethod
    def complete(
        self,
        system: str,
        user: "str | list[dict]",
        max_tokens: int,
    ) -> tuple[str, dict]:
        """
        Make one API call.

        Args:
            system:     System prompt as a plain string.
            user:       User message — either a plain string or a list of
                        Anthropic content blocks (dicts with 'type', 'text',
                        and optional 'cache_control'). Use content blocks to
                        mark stable sections (e.g. RTL source) for caching.
            max_tokens: Maximum tokens to generate.

        Returns:
            (response_text, usage_dict) where usage_dict has keys:
                input_tokens, output_tokens,
                cache_read_tokens, cache_creation_tokens
        """
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider identifier e.g. 'anthropic', 'openai', 'google'."""
        ...

    @property
    @abstractmethod
    def model(self) -> str:
        """Model name being used e.g. 'claude-sonnet-4-6', 'gpt-4o'."""
        ...

    @property
    def supports_caching(self) -> bool:
        """True if this provider supports prompt caching on the system block."""
        return False

    def _empty_usage(self) -> dict:
        return {
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_tokens": 0,
            "cache_creation_tokens": 0,
        }
