"""
modelsim_generator.py
---------------------
Generates a ModelSim/Questa TCL (.do) script for compiling and simulating
an RTL design plus its testbench. The script writes a transcript file so
the engineer can feed the simulation log back to `rtlguard iterate`.
"""

from pathlib import Path

from rtlguard.models.entity import Entity


_DO_TEMPLATE = """\
# RTLGuard-generated ModelSim/Questa simulation script
# Module : {module_name}
# Run    : do {script_name} (inside ModelSim/Questa)

# --- Transcript ----------------------------------------------------------
transcript file {transcript_file}
transcript on

# --- Compile -------------------------------------------------------------
vlib work
vmap work work

{compile_commands}

# --- Simulate ------------------------------------------------------------
vsim -t 1ps -novopt work.{tb_name} {extra_vsim_flags}

# Run until $finish or 10 ms, whichever comes first
run -all

# --- Finish --------------------------------------------------------------
transcript off
quit -f
"""


def _compile_commands(
    dut_file: str,
    tb_file: str,
    language: str,
) -> str:
    """Return the vlog/vcom lines for the DUT and testbench."""
    lang = language.lower()
    lines = []

    if lang == "vhdl":
        lines.append(f"vcom -2008 -work work {{{dut_file}}}")
    else:
        lines.append(f"vlog -sv -work work {{{dut_file}}}")

    # Testbench is always SystemVerilog
    lines.append(f"vlog -sv -work work {{{tb_file}}}")
    return "\n".join(lines)


class ModelSimGenerator:
    """
    Generates a ModelSim/Questa .do script for a DUT and its testbench.

    Usage:
        gen  = ModelSimGenerator()
        path = gen.write(entity, dut_file, tb_file, output_dir)
    """

    def generate(
        self,
        entity: Entity,
        dut_file: str,
        tb_file: str,
    ) -> str:
        """Return the .do script content as a string."""
        tb_name = f"{entity.name}_tb"
        script_name = f"{entity.name}_sim.do"
        transcript_file = f"{entity.name}_transcript.log"

        compile_cmds = _compile_commands(
            dut_file, tb_file, entity.language.value
        )

        return _DO_TEMPLATE.format(
            module_name=entity.name,
            script_name=script_name,
            transcript_file=transcript_file,
            compile_commands=compile_cmds,
            tb_name=tb_name,
            extra_vsim_flags="",
        )

    def write(
        self,
        entity: Entity,
        dut_file: str,
        tb_file: str,
        output_dir: str,
    ) -> Path:
        """Write the .do script to output_dir and return its path."""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        path = out / f"{entity.name}_sim.do"
        path.write_text(self.generate(entity, dut_file, tb_file), encoding="utf-8")
        return path
