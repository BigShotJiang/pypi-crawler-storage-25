"""
fpga_fixer.py
-------------
AI-powered fixer for FPGA best-practice violations.

Takes the RTL source and a list of violations, asks the AI to produce
a corrected version of the source, and returns the fixed source along
with a plain-English summary of each change made.
"""

import json
from dataclasses import dataclass, field
from typing import Optional

from rtlguard.ai.base import AIProvider
from rtlguard.ai.fpga_checker import FPGAViolation
from rtlguard.models.entity import Entity


_SYSTEM_PROMPT = """\
You are an expert FPGA design engineer. You fix RTL source code issues \
precisely and minimally — you change only what is needed to resolve the \
specified violations and nothing else. Preserve all comments, whitespace \
style, signal names, and unrelated logic exactly as written.\
"""

_RESPONSE_SCHEMA = {
    "fixed_source": "<complete corrected source code as a string>",
    "fixes_applied": [
        {
            "violation_id": "FPGA-001",
            "description": "One sentence describing what was changed and where",
        }
    ],
}


@dataclass
class FixResult:
    fixed_source: str = ""
    fixes_applied: list[dict] = field(default_factory=list)
    error: Optional[str] = None

    @property
    def has_error(self) -> bool:
        return self.error is not None


class FPGAFixer:
    """
    Proposes and applies AI-generated fixes for FPGA best-practice violations.

    Usage:
        fixer  = FPGAFixer(provider)
        result = fixer.fix(entity, source_text, violations)
    """

    def __init__(self, provider: AIProvider):
        self.provider = provider

    def fix(
        self,
        entity: Entity,
        source_text: str,
        violations: list[FPGAViolation],
    ) -> FixResult:
        user_blocks = self._build_message(entity, source_text, violations)
        try:
            text, _ = self.provider.complete(
                system=_SYSTEM_PROMPT,
                user=user_blocks,
                max_tokens=8192,
            )
        except Exception as exc:
            return FixResult(fixed_source=source_text, error=str(exc))
        return self._parse(text, source_text)

    def _build_message(
        self,
        entity: Entity,
        source_text: str,
        violations: list[FPGAViolation],
    ) -> list[dict]:
        violation_lines = "\n\n".join(
            f"[{v.id}] {v.severity.upper()}: {v.title}\n"
            f"  Issue: {v.description}\n"
            f"  Required fix: {v.suggestion}"
            for v in violations
        )
        return [
            {
                "type": "text",
                "text": (
                    f"## RTL Source: {entity.name} ({entity.language.value})"
                    f"\n\n```\n{source_text}\n```"
                ),
                "cache_control": {"type": "ephemeral"},
            },
            {
                "type": "text",
                "text": "\n\n".join([
                    "## Violations to Fix",
                    violation_lines,
                    "## Task",
                    "Fix ONLY the violations listed above. Do not refactor, rename, "
                    "reformat, or change anything unrelated to the listed violations. "
                    "Return the complete corrected source code.",
                    f"## Response Schema\n```json\n{json.dumps(_RESPONSE_SCHEMA, indent=2)}\n```",
                    "Respond with JSON only. No markdown fences, no explanation outside the JSON.",
                ]),
            },
        ]

    def _parse(self, text: str, original_source: str) -> FixResult:
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            stripped = text.strip()
            if stripped.startswith("```"):
                lines = stripped.splitlines()
                stripped = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])
            try:
                data = json.loads(stripped)
            except json.JSONDecodeError as exc:
                return FixResult(
                    fixed_source=original_source,
                    error=f"JSON parse error: {exc}. Raw: {text[:300]}",
                )

        return FixResult(
            fixed_source=data.get("fixed_source", original_source),
            fixes_applied=data.get("fixes_applied", []),
        )
