"""
testbench_fixer.py
------------------
AI-powered fixer for a failing SystemVerilog testbench.

Takes the current testbench source and the list of failure lines extracted
from a ModelSim/Questa transcript, asks the AI to produce a corrected
testbench, and returns it along with a plain-English summary of changes.
"""

import json
from dataclasses import dataclass, field
from typing import Optional

from rtlguard.ai.base import AIProvider


_SYSTEM_PROMPT = """\
You are an expert verification engineer. You fix SystemVerilog testbenches \
based on simulation failure messages. You change ONLY what is needed to \
make the failing test cases pass — you do not refactor, rename, or reformat \
unrelated code.\
"""

_RESPONSE_SCHEMA = {
    "fixed_testbench": "<complete corrected testbench source as a string>",
    "fixes_applied": [
        {
            "test_case_id": "TC-003",
            "description": "One sentence describing what was fixed and where",
        }
    ],
}


@dataclass
class TBFixResult:
    fixed_testbench: str = ""
    fixes_applied: list[dict] = field(default_factory=list)
    error: Optional[str] = None

    @property
    def has_error(self) -> bool:
        return self.error is not None


class TestbenchFixer:
    """
    Proposes and applies AI-generated fixes to a failing testbench.

    Usage:
        fixer  = TestbenchFixer(provider)
        result = fixer.fix(testbench_source, failure_lines, failing_tc_ids)
    """

    def __init__(self, provider: AIProvider):
        self.provider = provider

    def fix(
        self,
        testbench_source: str,
        failure_lines: list[str],
        failing_tc_ids: list[str],
    ) -> TBFixResult:
        user_blocks = self._build_message(testbench_source, failure_lines, failing_tc_ids)
        try:
            text, _ = self.provider.complete(
                system=_SYSTEM_PROMPT,
                user=user_blocks,
                max_tokens=8192,
            )
        except Exception as exc:
            return TBFixResult(fixed_testbench=testbench_source, error=str(exc))
        return self._parse(text, testbench_source)

    def _build_message(
        self,
        testbench_source: str,
        failure_lines: list[str],
        failing_tc_ids: list[str],
    ) -> list[dict]:
        ids_str = ", ".join(failing_tc_ids) if failing_tc_ids else "see failures below"
        failures_text = "\n".join(f"  {ln}" for ln in failure_lines)
        return [
            {
                "type": "text",
                "text": f"## Current Testbench\n\n```systemverilog\n{testbench_source}\n```",
                "cache_control": {"type": "ephemeral"},
            },
            {
                "type": "text",
                "text": "\n\n".join([
                    f"## Simulation Failures (failing test cases: {ids_str})",
                    f"```\n{failures_text}\n```",
                    "## Task",
                    "Fix ONLY the test cases listed above. "
                    "Do not change passing test cases, the DUT instantiation, "
                    "the clock generator, or the reset sequence unless they are "
                    "the direct cause of the listed failures. "
                    "Return the complete corrected testbench.",
                    f"## Response Schema\n```json\n{json.dumps(_RESPONSE_SCHEMA, indent=2)}\n```",
                    "Respond with JSON only. No markdown fences, no explanation outside the JSON.",
                ]),
            },
        ]

    def _parse(self, text: str, original: str) -> TBFixResult:
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            stripped = text.strip()
            if stripped.startswith("```"):
                lines = stripped.splitlines()
                stripped = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])
            try:
                data = json.loads(stripped)
            except json.JSONDecodeError as exc:
                return TBFixResult(
                    fixed_testbench=original,
                    error=f"JSON parse error: {exc}. Raw: {text[:300]}",
                )

        return TBFixResult(
            fixed_testbench=data.get("fixed_testbench", original),
            fixes_applied=data.get("fixes_applied", []),
        )
