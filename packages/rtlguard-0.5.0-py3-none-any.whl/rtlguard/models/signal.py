"""
signal.py
---------
Represents a single signal or port parsed from an RTL design.
This is the atomic unit of RTLGuard's internal representation.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class SignalDirection(str, Enum):
    IN = "in"
    OUT = "out"
    INOUT = "inout"
    INTERNAL = "internal"


class SignalKind(str, Enum):
    PORT = "port"
    SIGNAL = "signal"
    VARIABLE = "variable"
    CONSTANT = "constant"
    GENERIC = "generic"


@dataclass
class SignalType:
    base_type: str
    is_vector: bool = False
    vector_high: Optional[int] = None
    vector_low: Optional[int] = None
    is_descending: bool = True
    enum_values: list[str] = field(default_factory=list)
    raw: str = ""

    def __str__(self) -> str:
        if self.is_vector and self.vector_high is not None and self.vector_low is not None:
            direction = "downto" if self.is_descending else "to"
            return f"{self.base_type}({self.vector_high} {direction} {self.vector_low})"
        return self.base_type

    @property
    def width(self) -> int:
        if self.is_vector and self.vector_high is not None and self.vector_low is not None:
            return abs(self.vector_high - self.vector_low) + 1
        return 1


@dataclass
class Signal:
    name: str
    kind: SignalKind
    signal_type: SignalType
    direction: Optional[SignalDirection] = None
    default_value: Optional[str] = None
    description: Optional[str] = None
    source_file: Optional[str] = None
    source_line: Optional[int] = None
    is_clock: bool = False
    is_reset: bool = False
    is_enable: bool = False
    driven_by: list[str] = field(default_factory=list)
    drives: list[str] = field(default_factory=list)

    def __post_init__(self):
        self._auto_classify()

    def _auto_classify(self):
        name_lower = self.name.lower()
        if any(p in name_lower for p in ["clk", "clock", "ck"]):
            self.is_clock = True
        if any(p in name_lower for p in ["rst", "reset", "nrst", "resetn", "rst_n"]):
            self.is_reset = True
        if any(p in name_lower for p in ["en", "enable", "enb"]):
            self.is_enable = True

    @property
    def is_port(self) -> bool:
        return self.kind == SignalKind.PORT

    @property
    def is_internal(self) -> bool:
        return self.kind in (SignalKind.SIGNAL, SignalKind.VARIABLE)

    def summary(self) -> dict:
        return {
            "name": self.name,
            "kind": self.kind.value,
            "type": str(self.signal_type),
            "direction": self.direction.value if self.direction else None,
            "default_value": self.default_value,
            "is_clock": self.is_clock,
            "is_reset": self.is_reset,
            "is_enable": self.is_enable,
            "width": self.signal_type.width,
            "source_line": self.source_line,
        }