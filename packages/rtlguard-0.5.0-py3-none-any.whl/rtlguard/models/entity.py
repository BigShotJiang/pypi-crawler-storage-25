"""
entity.py
---------
Represents a complete RTL design unit.
In VHDL this is an entity/architecture pair.
In SystemVerilog this is a module.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
from rtlguard.models.signal import Signal, SignalDirection


class LanguageSource(str, Enum):
    VHDL = "vhdl"
    SYSTEM_VERILOG = "system_verilog"
    UNKNOWN = "unknown"


class ProcessKind(str, Enum):
    SEQUENTIAL = "sequential"       # clocked process (has rising_edge / posedge)
    COMBINATIONAL = "combinational" # purely combinational logic
    MIXED = "mixed"                 # both — usually a smell, flagged by analysis


@dataclass
class GenericParameter:
    """
    Represents a VHDL generic or SV parameter.
    e.g.  DATA_WIDTH : integer := 8
    """
    name: str
    param_type: str
    default_value: Optional[str] = None


@dataclass
class Process:
    """
    Represents a single process block inside an architecture/module.
    This is where sequential and combinational logic lives.
    """
    name: Optional[str] = None              # label if one exists, e.g. "REG_PROC"
    kind: ProcessKind = ProcessKind.COMBINATIONAL
    sensitivity_list: list[str] = field(default_factory=list)  # signals in sensitivity list
    signals_read: list[str] = field(default_factory=list)      # signals read inside process
    signals_written: list[str] = field(default_factory=list)   # signals assigned inside process
    has_clock: bool = False
    has_reset: bool = False
    source_line_start: Optional[int] = None
    source_line_end: Optional[int] = None

    def __post_init__(self):
        # auto-classify based on sensitivity list content
        sens_lower = [s.lower() for s in self.sensitivity_list]
        if any("clk" in s or "clock" in s for s in sens_lower):
            self.has_clock = True
            self.kind = ProcessKind.SEQUENTIAL
        if any("rst" in s or "reset" in s for s in sens_lower):
            self.has_reset = True


@dataclass
class Entity:
    """
    The top-level representation of a parsed RTL design unit.
    Produced by vhdl_parser.py or sv_parser.py.
    Consumed by everything in analysis/, validation/, and prompts/.

    One Entity = one VHDL entity+architecture pair, or one SV module.
    """
    name: str
    source_file: str
    language: LanguageSource = LanguageSource.UNKNOWN

    # ports are the external interface of the design
    ports: list[Signal] = field(default_factory=list)

    # internal signals declared inside the architecture body
    internal_signals: list[Signal] = field(default_factory=list)

    # generics / parameters
    generics: list[GenericParameter] = field(default_factory=list)

    # process blocks found inside the architecture
    processes: list[Process] = field(default_factory=list)

    # sub-components instantiated inside this entity
    component_instances: list[str] = field(default_factory=list)

    # raw architecture body text, preserved for LLM context injection
    architecture_body: Optional[str] = None

    # any comments found at the entity/module header level
    header_comments: Optional[str] = None

    def __post_init__(self):
        self._classify_special_signals()

    def _classify_special_signals(self):
        """
        Walks ports and internal signals and ensures clock/reset/enable
        flags are set correctly. Parser heuristics handle most cases,
        but this catches anything missed at construction time.
        """
        for signal in self.ports + self.internal_signals:
            name_lower = signal.name.lower()
            if any(p in name_lower for p in ["clk", "clock", "ck"]):
                signal.is_clock = True
            if any(p in name_lower for p in ["rst", "reset", "nrst", "rst_n"]):
                signal.is_reset = True
            if any(p in name_lower for p in ["en", "enable", "enb"]):
                signal.is_enable = True

    # ------------------------------------------------------------------
    # Convenience accessors — used heavily by analysis and prompt layers
    # ------------------------------------------------------------------

    @property
    def input_ports(self) -> list[Signal]:
        return [p for p in self.ports if p.direction == SignalDirection.IN]

    @property
    def output_ports(self) -> list[Signal]:
        return [p for p in self.ports if p.direction == SignalDirection.OUT]

    @property
    def clock_signals(self) -> list[Signal]:
        return [s for s in self.ports + self.internal_signals if s.is_clock]

    @property
    def reset_signals(self) -> list[Signal]:
        return [s for s in self.ports + self.internal_signals if s.is_reset]

    @property
    def sequential_processes(self) -> list[Process]:
        return [p for p in self.processes if p.kind == ProcessKind.SEQUENTIAL]

    @property
    def combinational_processes(self) -> list[Process]:
        return [p for p in self.processes if p.kind == ProcessKind.COMBINATIONAL]

    @property
    def all_signals(self) -> list[Signal]:
        return self.ports + self.internal_signals

    def get_signal(self, name: str) -> Optional[Signal]:
        """Look up any signal by name across ports and internals."""
        for s in self.all_signals:
            if s.name.lower() == name.lower():
                return s
        return None

    def summary(self) -> dict:
        """Serializable summary for prompts and reports."""
        return {
            "name": self.name,
            "source_file": self.source_file,
            "language": self.language.value,
            "input_ports": [s.summary() for s in self.input_ports],
            "output_ports": [s.summary() for s in self.output_ports],
            "internal_signals": [s.summary() for s in self.internal_signals],
            "generics": [
                {"name": g.name, "type": g.param_type, "default": g.default_value}
                for g in self.generics
            ],
            "processes": [
                {
                    "name": p.name,
                    "kind": p.kind.value,
                    "sensitivity_list": p.sensitivity_list,
                    "has_clock": p.has_clock,
                    "has_reset": p.has_reset,
                }
                for p in self.processes
            ],
            "clock_signals": [s.name for s in self.clock_signals],
            "reset_signals": [s.name for s in self.reset_signals],
            "component_instances": self.component_instances,
        }