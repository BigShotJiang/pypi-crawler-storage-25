"""
Logical Segmentation Finder
Recovers the intentional component structure of a webpage as a CSS-selector tree.
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass, field
from typing import Optional

from playwright.async_api import async_playwright, Page, ElementHandle

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PRUNE_TAGS = {"script", "style", "noscript", "meta", "link", "head",
              "template", "svg", "iframe"}

# Tags that are always leaf segments — never descend further
LEAF_TAGS = {"pre", "code", "table", "ul", "ol", "figure", "blockquote",
             "video", "audio", "canvas", "picture"}

from .config import get_config, SegmenterConfig

# Invisible / purely-technical ARIA roles with no user-visible content
PRUNE_ROLES: set[str] = set()  # nothing pruned by role — nav/banner/contentinfo are user-visible

# Class/id name fragments that identify transient noise zones with no persistent content
PRUNE_NAME_FRAGMENTS = {"modal", "popup", "overlay", "toast", "tooltip",
                        "dropdown", "flyout", "offcanvas", "cookie", "consent"}

# Tags that mark intentional component boundaries — always declared as leaf segments
SEMANTIC_SEGMENT_TAGS = {"main", "article", "section", "aside", "header", "footer", "nav", "form"}

# Known component vocabulary in class/id names
ROLE_VOCABULARY = {
    "hero": ["hero", "banner", "jumbotron", "splash"],
    "nav": ["nav", "navbar", "navigation", "menu", "topbar"],
    "sidebar": ["sidebar", "side-bar", "aside", "panel"],
    "footer": ["footer", "foot"],
    "header": ["header", "masthead", "top-bar"],
    "card": ["card", "tile", "item", "post", "product"],
    "grid": ["grid", "list", "feed", "gallery", "collection"],
    "cta": ["cta", "call-to-action", "promo", "promotion", "offer"],
    "features": ["features", "benefits", "services", "highlights"],
    "testimonials": ["testimonial", "review", "quote"],
    "pricing": ["pricing", "plan", "tier"],
    "faq": ["faq", "accordion", "collapse"],
    "form": ["form", "signup", "login", "contact", "subscribe"],
    "modal": ["modal", "dialog", "overlay", "popup"],
    "section": ["section", "block", "row", "container", "wrapper"],
}


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class Segment:
    selector: str
    role: str
    depth: int
    bounding_box: dict          # {x, y, width, height}
    identity_score: int = 0
    identity_signals: list = field(default_factory=list)
    raw_html: str = ""
    children: list[Segment] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "selector": self.selector,
            "role": self.role,
            "depth": self.depth,
            "boundingBox": self.bounding_box,
            "identityScore": self.identity_score,
            "identitySignals": self.identity_signals,
            "rawHtml": self.raw_html,
            "children": [c.to_dict() for c in self.children],
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _names(el_info: dict) -> str:
    """Combine tag, class, id into a single searchable string."""
    parts = [el_info.get("tag", "")]
    parts += el_info.get("classes", [])
    if el_info.get("id"):
        parts.append(el_info["id"])
    return " ".join(parts).lower()


def _infer_role(el_info: dict) -> str:
    names = _names(el_info)
    tag = el_info.get("tag", "")
    aria = el_info.get("ariaRole", "")

    # ARIA role takes top priority (div[role=navigation] etc.)
    if aria == "navigation":
        return "nav"
    if aria == "banner":
        return "header"
    if aria == "contentinfo":
        return "footer"
    if aria == "main":
        return "main"
    if aria in ("complementary", "search"):
        return "sidebar"

    # Semantic tag takes priority
    if tag == "nav":
        return "nav"
    if tag in ("header",):
        return "header"
    if tag in ("footer",):
        return "footer"
    if tag == "aside":
        return "sidebar"
    if tag == "main":
        return "main"
    if tag == "article":
        return "article"
    if tag == "form":
        return "form"

    # Vocabulary scan
    for role, keywords in ROLE_VOCABULARY.items():
        if any(kw in names for kw in keywords):
            return role

    return "section"


def _is_noise_class(cls: str) -> bool:
    """Filter out utility/layout classes that don't carry semantic meaning."""
    noise_patterns = [
        r"^(m[tblrxy]?|p[tblrxy]?)-",   # Tailwind spacing
        r"^(flex|grid|block|inline|hidden|relative|absolute)",
        r"^(text|font|bg|border|rounded|shadow|w-|h-|min-|max-)",
        r"^(sm:|md:|lg:|xl:)",            # responsive prefixes
        r"^\d",                            # starts with digit
    ]
    return any(re.match(p, cls) for p in noise_patterns)


# ---------------------------------------------------------------------------
# DOM info extraction (runs inside Playwright's JS context)
# ---------------------------------------------------------------------------

# Builds a grounded, verified-unique CSS selector by walking up the DOM
# until it finds an id anchor, then constructing a descendant path downward.
# Falls back to body-rooted positional path if no id anchor exists.
_JS_BUILD_UNIQUE_SELECTOR = """
(el) => {
    const NOISE = [
        /^(mt|mb|ml|mr|mx|my|pt|pb|pl|pr|px|py)-/,
        /^(flex|grid|block|inline|hidden|relative|absolute|sticky|fixed)/,
        /^(text|font|bg|border|rounded|shadow|w-|h-|min-|max-)/,
        /^(sm:|md:|lg:|xl:|2xl:)/,
        /^\\d/,
        /^(clearfix|container|wrapper|inner|outer|row|col)/,
    ];

    function isNoise(cls) {
        return NOISE.some(p => p.test(cls));
    }

    function semanticClasses(node) {
        return Array.from(node.classList).filter(c => !isNoise(c));
    }

    function nodeStep(node, parent) {
        // Prefer id
        if (node.id) return '#' + CSS.escape(node.id);
        const tag = node.tagName.toLowerCase();
        const classes = semanticClasses(node);
        // Try tag + up to 2 semantic classes
        if (classes.length > 0) {
            const candidate = tag + '.' + classes.slice(0, 2).map(CSS.escape).join('.');
            // Verify unique within parent scope
            const scope = parent || document;
            if (scope.querySelectorAll(candidate).length === 1) return candidate;
            // Try with more classes
            if (classes.length > 2) {
                const candidate2 = tag + '.' + classes.slice(0, 3).map(CSS.escape).join('.');
                if (scope.querySelectorAll(candidate2).length === 1) return candidate2;
            }
        }
        // Fall back to nth-of-type within parent
        const siblings = parent
            ? Array.from(parent.children).filter(c => c.tagName === node.tagName)
            : Array.from(document.body.children).filter(c => c.tagName === node.tagName);
        const idx = siblings.indexOf(node) + 1;
        return tag + ':nth-of-type(' + idx + ')';
    }

    // Walk up to find the nearest id anchor (or body)
    const path = [];
    let current = el;
    while (current && current !== document.body) {
        path.unshift(current);
        if (current.id) break;  // found anchor — stop walking up
        current = current.parentElement;
    }

    // Build selector from anchor downward
    let selector = '';
    for (let i = 0; i < path.length; i++) {
        const node = path[i];
        const parent = i === 0 ? node.parentElement : path[i - 1];
        const step = nodeStep(node, parent);
        if (i === 0 && node.id) {
            selector = step;  // anchor is just #id, no parent needed
        } else if (i === 0) {
            // No id anchor found anywhere — ground to body
            selector = 'body > ' + step;
        } else {
            selector += ' > ' + step;
        }
    }

    // Final uniqueness verification against full document
    try {
        const matches = document.querySelectorAll(selector);
        if (matches.length !== 1) {
            // Append nth-of-type to disambiguate if needed
            const parent = el.parentElement;
            const siblings = parent
                ? Array.from(parent.children).filter(c => c.tagName === el.tagName)
                : [];
            const idx = siblings.indexOf(el) + 1;
            selector += ':nth-of-type(' + idx + ')';
        }
    } catch(e) {
        // Invalid selector edge case — return as-is
    }

    return selector;
}
"""

_JS_HAS_CONTENT = """
(el) => {
    function isVisible(n) {
        const r = n.getBoundingClientRect();
        if (r.width === 0 || r.height === 0) return false;
        const s = window.getComputedStyle(n);
        return s.display !== 'none' && s.visibility !== 'hidden';
    }
    // Direct text
    for (const c of el.childNodes) {
        if (c.nodeType === Node.TEXT_NODE && c.textContent.trim()) return true;
    }
    // Visible text nodes
    for (const t of el.querySelectorAll('h1,h2,h3,h4,h5,h6,p,span,li,button,a')) {
        if (isVisible(t) && t.textContent.trim()) return true;
    }
    // Visible images
    for (const img of el.querySelectorAll('img[src]')) {
        if (isVisible(img)) return true;
    }
    return false;
}
"""

_JS_GET_NODE_INFO = """
(el) => {
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    const isHidden = (
        style.display === 'none' ||
        style.visibility === 'hidden' ||
        style.opacity === '0' ||
        rect.width === 0 ||
        rect.height === 0
    );
    return {
        tag: el.tagName.toLowerCase(),
        id: el.id || '',
        classes: Array.from(el.classList),
        ariaRole: el.getAttribute('role') || '',
        isHidden,
        childCount: el.children.length,
        boundingBox: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
    };
}
"""

_JS_SUBTREE_STATS = """
(el) => {
    let nodeCount = 0;
    let maxDepth = 0;
    function walk(node, depth) {
        nodeCount++;
        if (depth > maxDepth) maxDepth = depth;
        for (const child of node.children) walk(child, depth + 1);
    }
    walk(el, 0);
    return { nodeCount, maxDepth };
}
"""

_JS_PARENT_IDENTITY = """
([el, minHeight, minNodes]) => {
    const style = window.getComputedStyle(el);
    const parentStyle = el.parentElement ? window.getComputedStyle(el.parentElement) : null;
    let score = 0;
    const signals = [];

    // Signal 1: Background isolation (+1, reduced from +2)
    // Intentionally weak — canvas resets (white on grey body) are too common.
    // Only meaningful when combined with structural containment signals.
    const bg = style.backgroundColor;
    const parentBg = parentStyle ? parentStyle.backgroundColor : null;
    const isTransparent = bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent';
    if (!isTransparent && bg !== parentBg) {
        score += 1;
        signals.push('background-isolation');
    }

    // Signal 2: Border (+2)
    const hasBorder = ['borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth']
        .some(prop => parseFloat(style[prop]) > 0);
    if (hasBorder) {
        score += 2;
        signals.push('border');
    }

    // Signal 3: Box shadow (+2)
    const hasShadow = style.boxShadow && style.boxShadow !== 'none';
    if (hasShadow) {
        score += 2;
        signals.push('box-shadow');
    }

    // Signal 4: Border radius (+1)
    const hasRadius = parseFloat(style.borderRadius) > 0;
    if (hasRadius) {
        score += 1;
        signals.push('border-radius');
    }

    // Signal 5: Explicit padding creating internal space (+1)
    // Raised threshold to 16px — small padding is common on layout wrappers
    const hasPadding = ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft']
        .some(prop => parseFloat(style[prop]) >= 16);
    if (hasPadding) {
        score += 1;
        signals.push('padding');
    }

    // Guard: full-width layout containers (≥90% viewport width) without
    // hard visual isolation (border/shadow/bg/radius) are layout wrappers,
    // not components. Cap their score aggressively.
    const rect = el.getBoundingClientRect();
    const isFullWidth = rect.width >= window.innerWidth * 0.95;
    const hasHardIsolation = signals.includes('background-isolation') ||
                             signals.includes('border') ||
                             signals.includes('box-shadow') ||
                             signals.includes('border-radius');
    if (isFullWidth && !hasHardIsolation) {
        // Remove soft signals (padding, spatial-gap, compositional-completeness)
        // that fire on layout wrappers just as readily as on components
        score = 0;
    }

    // Guard: elements shorter than minHeight are UI atoms (buttons, badges, chips)
    // not page-level components — cap score regardless of visual signals
    if (rect.height < minHeight) {
        score = Math.min(score, 2);
    }

    // Guard: child diversity — a node with many independently meaningful or
    // semantic children is a layout container (page wrapper, content area),
    // not a component. Components rarely have more than 3 major sub-parts.
    // Count direct element children that are either semantic tags or have
    // substantial subtrees (nodeCount >= 10).
    const directChildren = Array.from(el.children);
    const SEMANTIC = new Set(['section','article','aside','main','header','footer','form','nav']);
    let diverseChildCount = 0;
    for (const child of directChildren) {
        const isSemantic = SEMANTIC.has(child.tagName.toLowerCase());
        if (isSemantic) { diverseChildCount++; continue; }
        // Count subtree nodes inline (avoid recursive call overhead)
        let n = 0;
        const walker = document.createTreeWalker(child, NodeFilter.SHOW_ELEMENT);
        while (walker.nextNode()) { n++; if (n >= minNodes) break; }
        if (n >= minNodes) diverseChildCount++;
    }
    if (diverseChildCount > 3) {
        // Too many independent children — demote background-isolation
        // which is the most common false-positive signal on wrappers
        if (signals.includes('background-isolation')) {
            score -= 1;
            signals.splice(signals.indexOf('background-isolation'), 1);
            signals.push('background-isolation-demoted');
        }
    }

    // Signal 6: Spatial gap from previous sibling (+1)
    // Gap of 16px+ above this element suggests intentional separation
    const prev = el.previousElementSibling;
    if (prev) {
        const prevRect = prev.getBoundingClientRect();
        const thisRect = el.getBoundingClientRect();
        const gap = thisRect.top - prevRect.bottom;
        if (gap >= 16) {
            score += 1;
            signals.push('spatial-gap');
        }
    }

    // Signal 7: Compositional completeness (+2)
    // Has both a text-bearing node and at least one other element type
    const allTags = Array.from(el.querySelectorAll('*')).map(n => n.tagName.toLowerCase());
    const hasText = allTags.some(t => ['p', 'h1','h2','h3','h4','h5','h6','span','li'].includes(t));
    const hasMedia = allTags.some(t => ['img', 'video', 'canvas', 'svg'].includes(t));
    const hasInteractive = allTags.some(t => ['a', 'button', 'input', 'select', 'textarea'].includes(t));
    const typeCount = [hasText, hasMedia, hasInteractive].filter(Boolean).length;
    if (typeCount >= 2) {
        score += 2;
        signals.push('compositional-completeness');
    }

    return { score, signals };
}
"""

_JS_SIBLINGS_HAVE_VISIBLE_CONTENT = """
(el) => {
    // Returns true if any SIBLING of el contains user-visible content
    // (rendered text, images with src, links with href, form inputs)
    // that would be orphaned if el alone were declared the segment boundary.
    function isVisible(node) {
        const rect = node.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return false;
        const style = window.getComputedStyle(node);
        if (style.display === 'none' || style.visibility === 'hidden') return false;
        return true;
    }

    function hasContent(node) {
        // Direct visible text (non-whitespace)
        for (const child of node.childNodes) {
            if (child.nodeType === Node.TEXT_NODE && child.textContent.trim().length > 0) {
                return true;
            }
        }
        // Visible img with src
        const imgs = node.querySelectorAll('img[src]');
        for (const img of imgs) {
            if (isVisible(img)) return true;
        }
        // Visible link with href containing real content
        const links = node.querySelectorAll('a[href]');
        for (const link of links) {
            if (isVisible(link) && link.textContent.trim().length > 0) return true;
        }
        // Visible heading or paragraph text
        const textNodes = node.querySelectorAll('h1,h2,h3,h4,h5,h6,p,span,li,button');
        for (const t of textNodes) {
            if (isVisible(t) && t.textContent.trim().length > 0) return true;
        }
        return false;
    }

    const parent = el.parentElement;
    if (!parent) return false;

    for (const sibling of parent.children) {
        if (sibling === el) continue;
        if (!isVisible(sibling)) continue;
        if (hasContent(sibling)) return true;
    }
    return false;
}
"""

_JS_STRUCTURAL_SIMILARITY = """
(el) => {
    // Deep fingerprint: tag + children tags + grandchildren tags
    function fingerprint(node) {
        const childTags = Array.from(node.children).map(c => c.tagName).join(',');
        const grandchildTags = Array.from(node.children)
            .map(c => Array.from(c.children).map(g => g.tagName).join(','))
            .join('|');
        return node.tagName + ':' + node.children.length + ':' + childTags + '::' + grandchildTags;
    }
    const children = Array.from(el.children);
    // Need at least 3 children to call it a repeating pattern
    if (children.length < 3) return { similar: false, fingerprints: [] };
    const fps = children.map(fingerprint);
    const unique = new Set(fps);
    // Require >75% similarity with deep fingerprint to avoid false positives
    const maxCount = Math.max(...[...unique].map(fp => fps.filter(f => f === fp).length));
    return {
        similar: maxCount / children.length > 0.75,
        fingerprints: fps,
    };
}
"""


# ---------------------------------------------------------------------------
# Core recursive segmenter
# ---------------------------------------------------------------------------

class LogicalSegmenter:

    def __init__(self, page: Page, config: SegmenterConfig):
        self.page = page
        self.config = config

    async def segment(self) -> list[Segment]:
        """Entry point. Returns top-level segments."""
        body = await self.page.query_selector("body")
        if not body:
            return []

        # Phase 1 — get direct children of body to start descent
        children = await body.query_selector_all(":scope > *")
        segments = []
        for i, child in enumerate(children):
            result = await self._process_node(child, dom_depth=0, sibling_index=i)
            if result is not None:
                if isinstance(result, list):
                    segments.extend(result)
                else:
                    segments.append(result)
        return segments

    async def _process_node(
        self,
        el: ElementHandle,
        dom_depth: int,
        sibling_index: int,
    ) -> Optional[Segment | list[Segment]]:
        """
        Decision logic for a single node.
        Returns:
          - None           → discard
          - Segment        → leaf segment (owns its subtree)
          - list[Segment]  → container expanded into children
        """
        info = await self.page.evaluate(_JS_GET_NODE_INFO, el)

        # ── Prune ──────────────────────────────────────────────────────────
        if info["isHidden"]:
            return None
        if info["tag"] in PRUNE_TAGS:
            return None
        if info["ariaRole"] in PRUNE_ROLES:
            return None
        # Prune elements too small to be real segments
        bb = info["boundingBox"]
        if bb["width"] < self.config.min_width or bb["height"] < self.config.min_height:
            return None
        # Prune known transient noise zones by class/id name fragments
        names = _names(info)
        if any(frag in names for frag in PRUNE_NAME_FRAGMENTS):
            return None

        # ── Build selector ─────────────────────────────────────────────────
        selector = await self.page.evaluate(_JS_BUILD_UNIQUE_SELECTOR, el)
        role = _infer_role(info)

        # ── Leaf tags — never descend, always a segment leaf ───────────────
        if info["tag"] in LEAF_TAGS:
            identity = await self.page.evaluate(_JS_PARENT_IDENTITY, [el, self.config.min_height, self.config.min_subtree_nodes])
            raw_html = await el.evaluate("el => el.outerHTML")
            return Segment(selector=selector, role=role, depth=dom_depth,
                           bounding_box=bb, identity_score=identity["score"],
                           identity_signals=identity["signals"], raw_html=raw_html)

        # ── ARIA landmark roles — always treat as leaf segments ──────────────
        # Elements with ARIA landmark roles are intentional page zones by
        # developer choice, equivalent to semantic HTML5 tags. Always leaf.
        ARIA_LANDMARK_ROLES = {"navigation", "banner", "contentinfo",
                               "complementary", "main", "search", "form",
                               "region"}
        if info["ariaRole"] in ARIA_LANDMARK_ROLES:
            identity = await self.page.evaluate(_JS_PARENT_IDENTITY, [el, self.config.min_height, self.config.min_subtree_nodes])
            raw_html = await el.evaluate("el => el.outerHTML")
            return Segment(selector=selector, role=role, depth=dom_depth,
                           bounding_box=bb, identity_score=identity["score"],
                           identity_signals=identity["signals"], raw_html=raw_html)

        # ── Semantic segment tags — trust developer intent, declare leaf ───
        # nav, header, footer, article, section, aside, main, form explicitly
        # mark intentional page zones. nav/header/footer are ALWAYS trusted
        # (they are definitionally page-chrome, never transparent wrappers).
        # EXCEPTION: article/section/main that span a very large area
        # (> 3x viewport height) are likely page-builder wrappers (e.g. Divi,
        # Elementor) that contain multiple distinct visual sections inside.
        # These should be descended into rather than treated as leaves.
        if info["tag"] in SEMANTIC_SEGMENT_TAGS:
            identity = await self.page.evaluate(_JS_PARENT_IDENTITY, [el, self.config.min_height, self.config.min_subtree_nodes])
            HARD_SIGNALS = {"background-isolation", "border", "box-shadow", "border-radius"}
            is_full_width = bb["width"] >= 1440 * 0.95
            has_hard = bool(HARD_SIGNALS & set(identity["signals"]))
            # Chrome tags are always leaf segments — they're compact by nature
            chrome_tags = {"nav", "header", "footer", "form", "aside"}
            # Content wrapper tags may need descent if they're page-spanning
            wrapper_tags = {"article", "section", "main"}
            is_page_spanning = bb["height"] > 900 * 3  # > 3x viewport height
            if info["tag"] in chrome_tags:
                raw_html = await el.evaluate("el => el.outerHTML")
                return Segment(selector=selector, role=role, depth=dom_depth,
                               bounding_box=bb, identity_score=identity["score"],
                               identity_signals=identity["signals"], raw_html=raw_html)
            elif info["tag"] in wrapper_tags and is_page_spanning:
                # Very tall wrapper — fall through to structural analysis
                pass
            elif has_hard or not is_full_width:
                raw_html = await el.evaluate("el => el.outerHTML")
                return Segment(selector=selector, role=role, depth=dom_depth,
                               bounding_box=bb, identity_score=identity["score"],
                               identity_signals=identity["signals"], raw_html=raw_html)

        # No children → leaf
        if info["childCount"] == 0:
            identity = await self.page.evaluate(_JS_PARENT_IDENTITY, [el, self.config.min_height, self.config.min_subtree_nodes])
            raw_html = await el.evaluate("el => el.outerHTML")
            return Segment(selector=selector, role=role, depth=dom_depth,
                           bounding_box=bb, identity_score=identity["score"],
                           identity_signals=identity["signals"], raw_html=raw_html)

        # ── Parent identity check (runs before structural analysis) ───────
        # Requires at least one hard visual signal (background/border/shadow/radius)
        # to fire — soft signals alone (padding, gap, mixed content) are too
        # common on layout wrappers to be reliable component indicators.
        # Also blocked if visible siblings would be orphaned by stopping here.
        identity = await self.page.evaluate(_JS_PARENT_IDENTITY, [el, self.config.min_height, self.config.min_subtree_nodes])
        HARD_SIGNALS = {"background-isolation", "border", "box-shadow", "border-radius"}
        has_hard_signal = bool(HARD_SIGNALS & set(identity["signals"]))
        if has_hard_signal and identity["score"] >= self.config.component_score_threshold:
            siblings_have_content = await self.page.evaluate(
                _JS_SIBLINGS_HAVE_VISIBLE_CONTENT, el
            )
            if siblings_have_content:
                # Visible content exists in siblings — don't stop here,
                # let the parent own this node and its siblings together.
                # Fall through to structural/descent logic.
                pass
            else:
                raw_html = await el.evaluate("el => el.outerHTML")
                return Segment(selector=selector, role=role, depth=dom_depth,
                               bounding_box=bb, identity_score=identity["score"],
                               identity_signals=identity["signals"], raw_html=raw_html)

        # ── Raw text node check ────────────────────────────────────────────
        # If this node has direct non-whitespace text node children it is a
        # content-mixed node — cannot safely split into sub-segments.
        # (Excludes script/style text which is code, not user content.)
        has_raw_text = await self.page.evaluate("""
            (el) => {
                for (const child of el.childNodes) {
                    if (child.nodeType === Node.TEXT_NODE &&
                        child.textContent.trim().length > 0) {
                        return true;
                    }
                }
                return false;
            }
        """, el)
        if has_raw_text:
            raw_html = await el.evaluate("el => el.outerHTML")
            return Segment(selector=selector, role=role, depth=dom_depth,
                           bounding_box=bb, identity_score=identity["score"],
                           identity_signals=identity["signals"], raw_html=raw_html)

        # ── Structural similarity check ────────────────────────────────────
        sim = await self.page.evaluate(_JS_STRUCTURAL_SIMILARITY, el)
        if sim["similar"]:
            # Repeating pattern → this node IS the segment (e.g. card grid)
            raw_html = await el.evaluate("el => el.outerHTML")
            return Segment(selector=selector, role=role, depth=dom_depth,
                           bounding_box=bb, identity_score=identity["score"],
                           identity_signals=identity["signals"], raw_html=raw_html)

        # ── Dissimilar children: check if they're independently meaningful ─
        children = await el.query_selector_all(":scope > *")
        meaningful = []
        for child in children:
            child_info = await self.page.evaluate(_JS_GET_NODE_INFO, child)
            is_semantic = child_info["tag"] in SEMANTIC_SEGMENT_TAGS
            stats = await self.page.evaluate(_JS_SUBTREE_STATS, child)
            if is_semantic or (stats["maxDepth"] >= self.config.min_subtree_depth and stats["nodeCount"] >= self.config.min_subtree_nodes):
                meaningful.append(child)

        if not meaningful:
            # Dissimilar but all shallow → composed unit, declare as leaf
            raw_html = await el.evaluate("el => el.outerHTML")
            return Segment(selector=selector, role=role, depth=dom_depth,
                           bounding_box=bb, identity_score=identity["score"],
                           identity_signals=identity["signals"], raw_html=raw_html)

        # ── Coupled-sibling check ──────────────────────────────────────────
        # If there are only 2-3 meaningful children and none individually score
        # high on identity, they are functionally coupled — the parent is the
        # component, not the children. Single-child nodes always descend.
        # EXCEPTION: If ANY child is a semantic tag (nav, header, footer, etc.),
        # always descend — semantic tags are independent segments by developer
        # intent, regardless of their visual identity score.
        if 2 <= len(meaningful) <= 3:
            has_semantic_child = False
            child_scores = []
            for child in meaningful:
                child_info = await self.page.evaluate(_JS_GET_NODE_INFO, child)
                if child_info["tag"] in SEMANTIC_SEGMENT_TAGS:
                    has_semantic_child = True
                child_identity = await self.page.evaluate(_JS_PARENT_IDENTITY, [child, self.config.min_height, self.config.min_subtree_nodes])
                child_scores.append(child_identity["score"])
            # If no child has strong individual identity AND no semantic children → parent owns them
            if not has_semantic_child and not any(s >= self.config.component_score_threshold for s in child_scores):
                raw_html = await el.evaluate("el => el.outerHTML")
                return Segment(selector=selector, role=role, depth=dom_depth,
                               bounding_box=bb, identity_score=identity["score"],
                               identity_signals=identity["signals"], raw_html=raw_html)

        # ── Container: descend into each meaningful child ──────────────────
        # Orphan check: a non-meaningful sibling should only block descent if
        # it looks like a label/header coupled to a meaningful sibling —
        # indicated by being significantly smaller (height < 20% of the largest
        # meaningful child). Large independent sections that happen to be shallow
        # are NOT orphans — they'll be handled by their own _process_node call.
        largest_meaningful_h = 0
        for child in meaningful:
            child_bb = await self.page.evaluate(
                '(e) => e.getBoundingClientRect().height', child
            )
            if child_bb > largest_meaningful_h:
                largest_meaningful_h = child_bb

        non_meaningful = [c for c in children if c not in meaningful]
        for nm_child in non_meaningful:
            nm_info = await self.page.evaluate(_JS_GET_NODE_INFO, nm_child)
            if nm_info["isHidden"]:
                continue
            nm_bb = nm_info["boundingBox"]
            # Skip invisible elements
            if nm_bb["width"] < 10 or nm_bb["height"] < 10:
                continue
            # Skip tags whose text content is never user-visible content
            if nm_info["tag"] in PRUNE_TAGS:
                continue
            # Leaf tags (ul, ol, table, etc.) are always independently processable
            # as leaf segments — they're not orphans, they'll be handled in their
            # own _process_node call just like semantic tags.
            if nm_info["tag"] in LEAF_TAGS:
                continue
            # Semantic tags are independent segments — they're not orphans,
            # they'll be processed in their own _process_node call
            if nm_info["tag"] in SEMANTIC_SEGMENT_TAGS:
                continue
            # Coupling guard: siblings that are very small relative to the
            # meaningful children are section titles / label headings — they
            # are naturally absorbed by the parent and do NOT constitute an
            # orphan. Only siblings that are substantial in size (≥ 15% of the
            # tallest meaningful child) could genuinely be left stranded.
            # ALSO: any non-meaningful child taller than 100px is a substantial
            # page section in its own right (it just has fewer DOM nodes) and
            # should be processed independently, not trigger orphan collapse.
            if nm_bb["height"] > 100:
                # Substantial section — not an orphan, will be processed in descent
                continue
            if largest_meaningful_h > 0:
                ratio = nm_bb["height"] / largest_meaningful_h
                if ratio < 0.15:
                    # Tiny compared to content — it's a heading/label, absorb
                    continue
            # Non-meaningful but visible — check if it carries content
            has_content = await self.page.evaluate(_JS_HAS_CONTENT, nm_child)
            if has_content:
                # Orphan detected — parent owns all children as one segment
                raw_html = await el.evaluate("el => el.outerHTML")
                return Segment(selector=selector, role=role, depth=dom_depth,
                               bounding_box=bb, identity_score=identity["score"],
                               identity_signals=identity["signals"], raw_html=raw_html)

        # ── Container: descend into each meaningful child ──────────────────
        # Semantic-tag children are always processed regardless of node count —
        # they represent intentional component boundaries by developer choice.
        results = []
        for i, child in enumerate(children):
            child_info = await self.page.evaluate(_JS_GET_NODE_INFO, child)
            if child_info["isHidden"]:
                continue
            is_semantic = child_info["tag"] in SEMANTIC_SEGMENT_TAGS
            is_leaf_tag = child_info["tag"] in LEAF_TAGS
            stats = await self.page.evaluate(_JS_SUBTREE_STATS, child)
            is_meaningful = (
                stats["maxDepth"] >= self.config.min_subtree_depth and
                stats["nodeCount"] >= self.config.min_subtree_nodes
            )
            
            should_process = is_meaningful or is_semantic or is_leaf_tag
            if not should_process:
                # Even if it's not a major structural component, if it contains
                # visible text/images we MUST process it. Otherwise it will be
                # completely lost from the output flat map, because the parent
                # disappears when it descends.
                has_content = await self.page.evaluate(_JS_HAS_CONTENT, child)
                if has_content:
                    should_process = True
            
            if should_process:
                result = await self._process_node(child, dom_depth + 1, i)
                if result is not None:
                    if isinstance(result, list):
                        results.extend(result)
                    else:
                        results.append(result)
            # Non-meaningful, non-semantic, non-leaf siblings with no content are silently absorbed

        # If descent yielded nothing useful, fall back to declaring self as leaf
        if not results:
            return Segment(selector=selector, role=role, depth=dom_depth,
                           bounding_box=bb, identity_score=identity["score"],
                           identity_signals=identity["signals"])

        return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def find_segments(url: str, page_type: str = "unknown") -> list[dict]:
    """Navigate to *url*, run the segmentation algorithm, and return the
    segment map as a list of dicts.

    Each dict has the shape::

        {
            "selector":       str,   # unique CSS selector for the element
            "role":           str,   # inferred component role (hero, card, …)
            "depth":          int,   # nesting depth (0 = top-level)
            "boundingBox":    {x, y, width, height},
            "identityScore":  int,   # visual-identity score (≥4 = strong component)
            "identitySignals": list[str],
            "children":       list[dict],  # nested sub-segments
        }

    Args:
        url: Fully-qualified URL to load (e.g. ``"https://example.com"``).

    Returns:
        List of top-level segment dicts (children are nested inside each dict).
    """
    async with async_playwright() as pw:
        browser = await pw.chromium.launch()
        page = await browser.new_page(viewport={"width": 1440, "height": 900})

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_load_state("networkidle", timeout=5000)
        except Exception:
            pass  # Handle SSR/React apps that poll and never reach networkidle

        # Let any lazy-loaded content settle
        await asyncio.sleep(1)

        config = get_config(page_type)
        segmenter = LogicalSegmenter(page, config)
        segments = await segmenter.segment()

        await browser.close()

    return [s.to_dict() for s in segments]


async def find_segments_from_html(html: str, base_url: str = "", page_type: str = "unknown") -> list[dict]:
    """Load raw *html* into a headless browser, run the segmentation algorithm,
    and return the segment map as a list of dicts.

    This is the HTML-input counterpart to :func:`find_segments`.  It is useful
    when you already have the page source (e.g. fetched by a crawler, read from
    disk, or generated programmatically) and do not want a second network round-
    trip.

    .. note::
        External assets (stylesheets, fonts, images) referenced by relative URLs
        in the HTML **will not resolve** unless you supply *base_url*.  Pass the
        origin of the page (e.g. ``"https://example.com"``) so that Playwright
        can fetch them correctly.  Without it the layout may differ from the live
        page and bounding-box measurements will be less accurate.

    Args:
        html:     Full HTML source string (``<!DOCTYPE html>…``).
        base_url: Optional origin URL used to resolve relative asset paths.
                  Defaults to ``""`` (no base — relative assets will 404).

    Returns:
        List of top-level segment dicts with the same shape as
        :func:`find_segments`.
    """
    async with async_playwright() as pw:
        browser = await pw.chromium.launch()
        page = await browser.new_page(viewport={"width": 1440, "height": 900})

        kwargs: dict = {"wait_until": "domcontentloaded", "timeout": 30000}
        if base_url:
            kwargs["url"] = base_url

        try:
            await page.set_content(html, **kwargs)
            await page.wait_for_load_state("networkidle", timeout=5000)
        except Exception:
            pass  # Handle SSR/React apps that poll and never reach networkidle

        # Allow lazy/deferred styles to apply
        await asyncio.sleep(1)

        config = get_config(page_type)
        segmenter = LogicalSegmenter(page, config)
        segments = await segmenter.segment()

        await browser.close()

    return [s.to_dict() for s in segments]