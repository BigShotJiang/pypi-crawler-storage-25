from .segmenter import find_segments, find_segments_from_html, LogicalSegmenter, Segment
from .config import SegmenterConfig, get_config

__version__ = "0.1.3"
__all__ = [
    "find_segments",
    "find_segments_from_html",
    "LogicalSegmenter",
    "Segment",
    "SegmenterConfig",
    "get_config",
]
