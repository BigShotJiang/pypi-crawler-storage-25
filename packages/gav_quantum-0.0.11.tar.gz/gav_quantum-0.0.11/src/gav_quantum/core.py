import numpy as np
from itertools import combinations, product
import math
import scipy


ZERO = np.array([1, 0])
ONE = np.array([0,1])
X = np.array([[0, 1], [1, 0]])
Y = np.array([[0, -1j],[1j, 0]])
Z = np.array([[1, 0], [0, -1]])
PAULIS = np.array([np.eye(2), X, Y, Z])


def bell_states():
    bell_states = {
        'PHI_PLUS': np.kron(ZERO, ZERO) + np.kron(ONE, ONE),
        'PHI_MINUS': np.kron(ZERO, ZERO) - np.kron(ONE, ONE),
        'PSI_PLUS': np.kron(ZERO, ONE) + np.kron(ONE, ZERO),
        'PSI_MINUS': np.kron(ZERO, ONE) - np.kron(ONE, ZERO)
    }
    bell_states = {k: v * 1/np.sqrt(2) for k, v in bell_states.items()}
    return bell_states
BELL_STATES = bell_states()


# Returns W-state of N qubits
def W(N):
    ret_state = np.zeros(2**N)
    for basis in np.identity(N):
        for index, entry in enumerate(basis):
            state = ZERO if entry == 0 else ONE
            if(index == 0):
                kron_state = ZERO if entry == 0 else ONE
            else:
                kron_state = np.kron(kron_state, state)

        ret_state += kron_state
    return ret_state/ np.sqrt(N)


# Returns GHZ-state of N qubits
def GHZ(N):
    ret_state = np.zeros(2**N)
    ret_state[0] = ret_state[-1] = 1
    return ret_state / np.sqrt(2)


# Returns the operator specified via tensor notation
# INPUTS
#     N - Number of qubits
#     nonidentities - List of tuples specifying qubit number (indexed at 0) in ascending order and Pauli operator 
#         Example: [(0,X),(2,'Y')]
def operator_from_sparse_pauli(N, nonidentities):
    tup = lambda value, tuples: next(((first, second) for first, second in tuples if first == value), 0)
    
    for iter in range(N):
        result = tup(iter, nonidentities)
        if(iter == 0):
            ret_arr = np.identity(2) if (result == 0) else result[1]
        else:
            ret_arr = np.kron(ret_arr, np.identity(2)) if result == 0 else np.kron(ret_arr, result[1])

    return ret_arr


# Generates a list of the subset of operator bases over N qubits of weight less than or equal to k
# It is a tensor product of N operators, each of which is in {I, X, Y, Z} such that at most k are not I
# INPUTS
#     N - Number of qubits
#     k - Maximum locality of Pauli operators acting upon qubits
def Paulis_N_k(N, k):
    retset = []
    retset_verbose = []
    retset.append(np.eye(2**N))
    retset_verbose.append([])
    for k_index in range(k):
        combos = combinations(range(N), k_index+1)
        sigmas = [p for p in product([X,Y,Z], repeat=(k_index+1))]
        sigmas_verbose = [p for p in product(['X','Y','Z'], repeat=(k_index+1))]
        for c in combos:
            for (sv_index, sv) in enumerate(sigmas_verbose):
                paulis = []
                paulis_verbose = []
                for (tup_index, tup) in enumerate(c):
                    paulis_verbose.append((tup, sv[tup_index]))
                    paulis.append((tup, sigmas[sv_index][tup_index]))
                retset_verbose.append(paulis_verbose)
                retset.append(operator_from_sparse_pauli(N, paulis))
            
    return retset, retset_verbose


# INPUTS:
#     N - Number of qubits
#     k - Locality of qubit interactions
#     mode - Ising (default) or Heisenberg
def QMaxCutHamiltonian(N, k, mode="Ising"):
    combos = combinations(range(N), k)

    hamiltonian = np.zeros((2**N, 2**N), dtype=complex)
    for c in combos:
        X_nonidentities = [(c[i], X) for i in range(k)]
        Y_nonidentities = [(c[i], Y) for i in range(k)]
        Z_nonidentities = [(c[i], Z) for i in range(k)]
        
        h_e = operator_from_sparse_pauli(N, Z_nonidentities)
        if(mode == "Heisenberg"):
            h_e = h_e.astype(complex)
            h_e += operator_from_sparse_pauli(N, Y_nonidentities)
            h_e += operator_from_sparse_pauli(N, X_nonidentities)

        h_e = np.identity(2**N) - h_e
        h_e = 0.5 * h_e if mode == "Ising" else 0.25 * h_e
        hamiltonian += h_e

    return hamiltonian


# INPUTS
#     N - The number of qubits in the quantum state or nodes in the constraint graph.
#     E - A 2-tuple corresponding to the edge of the constraint graph with constraint graph node numbers in ascending order as constraints.  Example: `(0, 2)`
#     k - The locality of qubit interactions.
def moment_cost_matrix(N, E, k):
    _, pauli_ops_verbose = Paulis_N_k(N, k)
    retmat = np.zeros((len(pauli_ops_verbose), len(pauli_ops_verbose)))
    A = E[0]
    B = E[1]
    for index_row, pauli_op_row in enumerate(pauli_ops_verbose):
        for index_col, pauli_op_col in enumerate(pauli_ops_verbose):
            if(len(pauli_ops_verbose[index_row]) > 1 and len(pauli_ops_verbose[index_col]) > 1):
                reference_pauli = next((p for i, p in pauli_ops_verbose[index_row] if i == A), [])

                valid = False
                for tup in pauli_ops_verbose[index_row]:
                    if(tup[0] == B and tup[1] == reference_pauli):
                        valid = True
                if(valid):
                    valid_A = False
                    valid_B = False
                    for tup in pauli_ops_verbose[index_col]:
                        if(tup[0] == A and tup[1] == reference_pauli):
                            valid_A = True
                        if(tup[0] == B and tup[1] == reference_pauli):
                            valid_B = True
                    if(valid_A and valid_B):
                        retmat[index_row][index_col] = -0.5
                        retmat[index_col][index_row] = -0.5    

    return retmat


# Returns list of the nth roots of unity, [1, \omega, \omega^2, ...]
def rootsOfUnity(n):
    return np.array([np.exp(2*np.pi*1j*ns/n) for ns in range(n)])


# # Generates explicit Clifford algebra representation from generalized Pauli operators
# Returns array of generators
# INPUTS
#   n - number of required Clifford generators
def WeylBrauer(n):
    nn = n if n%2 == 0 else n+1
    k = int(nn/2)
    operators = []
    for i in range(k):
        sparse_pauli_odd = []
        sparse_pauli_even = []
        for index in range(i):
            sparse_pauli_odd.append((index, Z))
            sparse_pauli_even.append((index, Z))
        sparse_pauli_odd.append((i, X))
        sparse_pauli_even.append((i, Y))
        operators.append(operator_from_sparse_pauli(k, sparse_pauli_odd))
        operators.append(operator_from_sparse_pauli(k, sparse_pauli_even))
    return operators[:n]


# Returns unitary matrix of Tsirelson's vector encoding
# NOTE: @vector must be unit vector
def vectorToUnitaryIsometry(vector):
    vector = vector / np.linalg.norm(vector)
    n = len(vector)
    operators = WeylBrauer(n)
    dim = 2**(math.ceil(n/2))
    unitary = np.zeros((dim, dim), dtype=complex)
    for i in range(n):
        unitary += vector[i] * operators[i]
    return unitary


# INPUTS
# @A - operator to be rounded
# @k - number of partitions
# @method - Type of rounding, based on 'polar' or 'schur'
def roundToOrderKUnitary(A, k, method='polar'):
    A = np.asarray(A, dtype=np.complex128)
    if(method == 'polar'):
        u, p = scipy.linalg.polar(A)
        rootsOfUnity = rootsOfUnity(k)
        eigs, eigvs = np.linalg.eig(u)
        nearestEigs = []
        for eig in eigs:
            phaseDeltaMin = np.inf
            nearestEig = complex(0,0)
            # If tie exists, picks first root of unity;
            #   introduces deterministic bias
            for root in rootsOfUnity:
                delta = abs(np.angle(np.exp(1j*(np.angle(root) - np.angle(eig)))))
                if(delta < phaseDeltaMin):
                    phaseDeltaMin = delta
                    nearestEig = root
            nearestEigs.append(nearestEig)

        roundedUnitary = eigvs @ np.diag(nearestEigs) @ np.linalg.inv(eigvs)
        # Re-"unitize" @roundedUnitary
        roundedUnitary, _ = scipy.linalg.polar(roundedUnitary)
        return roundedUnitary
    else:
        print('Schur')


# Generate random Haar unitary operator of dimension n by n
def randomHaarUnitary(n):
    Z = np.random.randn(n, n) + 1j*np.random.randn(n, n)
    Q, R = np.linalg.qr(Z)
    d = np.diag(R)
    Q = Q * (d / np.abs(d))   # broadcast across columns
    return Q


# Generate array of diagonal basis order-@k unitaries of dimension @d
def diagOrderKUnitaries(k, d):
    roots = rootsOfUnity(k)
    unitaries = []
    for diag_roots in product(roots, repeat=d):
        unitaries.append(np.diag(diag_roots))
    return unitaries