"""
Unit tests for the LLM provider layer.

Covers:
  - LLMProvider abstract interface contract
  - AnthropicProvider (Anthropic SDK mocked)
  - GeminiProvider (Google GenAI SDK mocked)
  - Both providers interchangeable via the shared interface
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import anthropic
import pytest

try:
    from google.genai.types import FinishReason
except ImportError:
    FinishReason = None  # type: ignore[assignment,misc]

from prompt_tester.llm.providers.base import CompletionResult, LLMProvider
from prompt_tester.llm.providers.anthropic import AnthropicProvider
from prompt_tester.llm.providers.gemini import GeminiProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_anthropic_response(
    text: str,
    input_tokens: int  = 10,
    output_tokens: int = 20,
    stop_reason:   str = "end_turn",
    model:         str = "claude-haiku-4-5-20251001",
    response_id:   str = "msg_abc123",
    cached_input:  int = 0,
    cache_creation: int = 0,
) -> MagicMock:
    block      = MagicMock()
    block.text = text
    response                              = MagicMock()
    response.content                      = [block]
    response.model                        = model
    response.id                           = response_id
    response.stop_reason                  = stop_reason
    response.usage.input_tokens           = input_tokens
    response.usage.output_tokens          = output_tokens
    response.usage.cache_read_input_tokens    = cached_input
    response.usage.cache_creation_input_tokens = cache_creation
    return response


def _make_gemini_response(
    text: str,
    input_tokens:    int          = 10,
    output_tokens:   int          = 20,
    finish_reason:   FinishReason = FinishReason.STOP,
    model_version:   str          = "gemini-3.1-flash-lite-001",
    response_id:     str          = "resp_xyz789",
    cached_tokens:   int          = 0,
    thoughts_tokens: int          = 0,
) -> MagicMock:
    candidate               = MagicMock()
    candidate.finish_reason = finish_reason

    response                                          = MagicMock()
    response.text                                     = text
    response.candidates                               = [candidate]
    response.model_version                            = model_version
    response.response_id                              = response_id
    response.usage_metadata.prompt_token_count        = input_tokens
    response.usage_metadata.candidates_token_count    = output_tokens
    response.usage_metadata.cached_content_token_count = cached_tokens
    response.usage_metadata.thoughts_token_count      = thoughts_tokens
    return response


# ---------------------------------------------------------------------------
# Interface contract
# ---------------------------------------------------------------------------

class TestLLMProviderInterface:
    def test_cannot_instantiate_abstract_base(self):
        with pytest.raises(TypeError):
            LLMProvider()  # type: ignore[abstract]

    def test_completion_result_is_dataclass(self):
        r = CompletionResult(text="hello", input_tokens=5, output_tokens=10)
        assert r.text          == "hello"
        assert r.input_tokens  == 5
        assert r.output_tokens == 10

    def test_anthropic_provider_is_llm_provider(self):
        with patch("prompt_tester.llm.providers.anthropic.anthropic.Anthropic"):
            provider = AnthropicProvider()
        assert isinstance(provider, LLMProvider)

    def test_gemini_provider_is_llm_provider(self):
        with patch("prompt_tester.llm.providers.gemini.genai.Client"):
            provider = GeminiProvider()
        assert isinstance(provider, LLMProvider)

    def test_both_providers_return_completion_result(self):
        """Both providers must return CompletionResult — the shared contract."""
        with patch("prompt_tester.llm.providers.anthropic.anthropic.Anthropic") as mock_anthropic:
            mock_anthropic.return_value.messages.create.return_value = \
                _make_anthropic_response("hello")
            ap = AnthropicProvider()
            result = ap.complete(model="claude-haiku-4-5-20251001", prompt="hi")
        assert isinstance(result, CompletionResult)

        with patch("prompt_tester.llm.providers.gemini.genai.Client") as mock_genai:
            mock_genai.return_value.models.generate_content.return_value = \
                _make_gemini_response("hello")
            gp = GeminiProvider()
            result = gp.complete(model="gemini-3.1-flash-lite", prompt="hi")
        assert isinstance(result, CompletionResult)


# ---------------------------------------------------------------------------
# AnthropicProvider
# ---------------------------------------------------------------------------

class TestAnthropicProvider:
    def _make_provider(self) -> tuple[AnthropicProvider, MagicMock]:
        with patch("prompt_tester.llm.providers.anthropic.anthropic.Anthropic") as mock_cls:
            provider = AnthropicProvider()
        return provider, mock_cls.return_value

    def test_returns_text_and_token_counts(self):
        provider, client = self._make_provider()
        client.messages.create.return_value = _make_anthropic_response("output", 15, 30)

        result = provider.complete(model="claude-haiku-4-5-20251001", prompt="hello")

        assert result.text          == "output"
        assert result.input_tokens  == 15
        assert result.output_tokens == 30

    def test_passes_model_and_prompt(self):
        provider, client = self._make_provider()
        client.messages.create.return_value = _make_anthropic_response("ok")

        provider.complete(model="claude-sonnet-4-6", prompt="test prompt")

        call_kwargs = client.messages.create.call_args[1]
        assert call_kwargs["model"]                    == "claude-sonnet-4-6"
        assert call_kwargs["messages"][0]["content"]   == "test prompt"

    def test_passes_max_tokens(self):
        provider, client = self._make_provider()
        client.messages.create.return_value = _make_anthropic_response("ok")

        provider.complete(model="claude-haiku-4-5-20251001", prompt="p", max_tokens=512)

        assert client.messages.create.call_args[1]["max_tokens"] == 512

    def test_system_prompt_included_when_provided(self):
        provider, client = self._make_provider()
        client.messages.create.return_value = _make_anthropic_response("ok")

        provider.complete(model="claude-haiku-4-5-20251001", prompt="p", system="Be brief.")

        call_kwargs = client.messages.create.call_args[1]
        assert call_kwargs.get("system") == "Be brief."

    def test_no_system_key_when_not_provided(self):
        provider, client = self._make_provider()
        client.messages.create.return_value = _make_anthropic_response("ok")

        provider.complete(model="claude-haiku-4-5-20251001", prompt="p")

        assert "system" not in client.messages.create.call_args[1]

    def test_concatenates_multiple_text_blocks(self):
        provider, client = self._make_provider()

        b1, b2     = MagicMock(), MagicMock()
        b1.text, b2.text = "Hello", " world"
        response         = MagicMock()
        response.content = [b1, b2]
        response.usage.input_tokens  = 5
        response.usage.output_tokens = 5
        client.messages.create.return_value = response

        result = provider.complete(model="claude-haiku-4-5-20251001", prompt="hi")
        assert result.text == "Hello world"

    def test_monitoring_fields_populated(self):
        provider, client = self._make_provider()
        client.messages.create.return_value = _make_anthropic_response(
            "ok", response_id="msg_123", model="claude-haiku-4-5-20251001",
            stop_reason="end_turn", cached_input=50, cache_creation=100,
        )

        result = provider.complete(model="claude-haiku-4-5-20251001", prompt="hi")

        assert result.provider              == "anthropic"
        assert result.request_id            == "msg_123"
        assert result.model_used            == "claude-haiku-4-5-20251001"
        assert result.stop_reason           == "end_turn"
        assert result.cached_input_tokens   == 50
        assert result.cache_creation_tokens == 100
        assert result.safety_filtered       is False

    def test_skips_non_text_blocks(self):
        provider, client = self._make_provider()

        text_block = MagicMock(spec=["text"])
        text_block.text = "text only"
        tool_block = MagicMock(spec=[])  # no .text attribute

        response         = MagicMock()
        response.content = [text_block, tool_block]
        response.usage.input_tokens  = 5
        response.usage.output_tokens = 5
        client.messages.create.return_value = response

        result = provider.complete(model="claude-haiku-4-5-20251001", prompt="hi")
        assert result.text == "text only"

    def test_retries_on_internal_server_error(self):
        provider, client = self._make_provider()
        success = _make_anthropic_response("ok")
        client.messages.create.side_effect = [
            anthropic.InternalServerError(
                message="503", response=MagicMock(status_code=503), body={}
            ),
            success,
        ]

        with patch("prompt_tester.llm.providers.anthropic.time.sleep") as mock_sleep:
            result = provider.complete(model="claude-haiku-4-5-20251001", prompt="hi")

        assert result.text == "ok"
        assert client.messages.create.call_count == 2
        mock_sleep.assert_called_once_with(1.0)

    def test_raises_after_max_retries(self):
        provider, client = self._make_provider()
        err = anthropic.InternalServerError(
            message="503", response=MagicMock(status_code=503), body={}
        )
        client.messages.create.side_effect = [err, err, err]

        with patch("prompt_tester.llm.providers.anthropic.time.sleep"):
            with pytest.raises(anthropic.InternalServerError):
                provider.complete(model="claude-haiku-4-5-20251001", prompt="hi")

        assert client.messages.create.call_count == 3

    def test_retries_on_rate_limit_error(self):
        provider, client = self._make_provider()
        success = _make_anthropic_response("ok")
        rate_limit_err = anthropic.RateLimitError(
            message="429", response=MagicMock(status_code=429), body={}
        )
        client.messages.create.side_effect = [rate_limit_err, success]

        with patch("prompt_tester.llm.providers.anthropic.time.sleep") as mock_sleep:
            result = provider.complete(model="claude-haiku-4-5-20251001", prompt="hi")

        assert result.text == "ok"
        assert client.messages.create.call_count == 2
        mock_sleep.assert_called_once_with(1.0)


# ---------------------------------------------------------------------------
# GeminiProvider
# ---------------------------------------------------------------------------

class TestGeminiProvider:
    def _make_provider(self) -> tuple[GeminiProvider, MagicMock]:
        with patch("prompt_tester.llm.providers.gemini.genai.Client") as mock_cls:
            provider = GeminiProvider()
        return provider, mock_cls.return_value

    def test_returns_text_and_token_counts(self):
        provider, client = self._make_provider()
        client.models.generate_content.return_value = _make_gemini_response("output", 15, 30)

        result = provider.complete(model="gemini-3.1-flash-lite", prompt="hello")

        assert result.text          == "output"
        assert result.input_tokens  == 15
        assert result.output_tokens == 30

    def test_passes_model_and_prompt(self):
        provider, client = self._make_provider()
        client.models.generate_content.return_value = _make_gemini_response("ok")

        provider.complete(model="gemini-3.1-flash-lite", prompt="test prompt")

        call_kwargs = client.models.generate_content.call_args[1]
        assert call_kwargs["model"]    == "gemini-3.1-flash-lite"
        assert call_kwargs["contents"] == "test prompt"

    def test_passes_max_tokens_in_config(self):
        provider, client = self._make_provider()
        client.models.generate_content.return_value = _make_gemini_response("ok")

        provider.complete(model="gemini-3.1-flash-lite", prompt="p", max_tokens=512)

        config = client.models.generate_content.call_args[1]["config"]
        assert config.max_output_tokens == 512

    def test_system_prompt_passed_in_config(self):
        provider, client = self._make_provider()
        client.models.generate_content.return_value = _make_gemini_response("ok")

        provider.complete(model="gemini-3.1-flash-lite", prompt="p", system="Be brief.")

        config = client.models.generate_content.call_args[1]["config"]
        assert config.system_instruction == "Be brief."

    def test_empty_text_handled(self):
        provider, client = self._make_provider()
        resp      = _make_gemini_response("ok")
        resp.text = None  # API may return None in edge cases
        client.models.generate_content.return_value = resp

        result = provider.complete(model="gemini-3.1-flash-lite", prompt="hi")
        assert result.text == ""

    def test_monitoring_fields_populated(self):
        provider, client = self._make_provider()
        client.models.generate_content.return_value = _make_gemini_response(
            "ok", response_id="resp_xyz", model_version="gemini-3.1-flash-lite-001",
            finish_reason=FinishReason.STOP, cached_tokens=30, thoughts_tokens=15,
        )

        result = provider.complete(model="gemini-3.1-flash-lite", prompt="hi")

        assert result.provider          == "google"
        assert result.request_id        == "resp_xyz"
        assert result.model_version     == "gemini-3.1-flash-lite-001"
        assert result.stop_reason       == "STOP"
        assert result.cached_input_tokens == 30
        assert result.thoughts_tokens   == 15
        assert result.safety_filtered   is False

    def test_safety_filtered_when_finish_reason_is_safety(self):
        provider, client = self._make_provider()
        client.models.generate_content.return_value = _make_gemini_response(
            "", finish_reason=FinishReason.SAFETY
        )

        result = provider.complete(model="gemini-3.1-flash-lite", prompt="hi")

        assert result.safety_filtered is True

    def test_retries_on_server_error(self):
        provider, client = self._make_provider()
        success = _make_gemini_response("ok")

        from google.genai import errors as genai_errors
        client.models.generate_content.side_effect = [
            genai_errors.ServerError(503, {"error": "UNAVAILABLE"}),
            success,
        ]

        with patch("prompt_tester.llm.providers.gemini.time.sleep") as mock_sleep:
            result = provider.complete(model="gemini-3.1-flash-lite", prompt="hi")

        assert result.text == "ok"
        assert client.models.generate_content.call_count == 2
        mock_sleep.assert_called_once_with(1.0)

    def test_raises_after_max_retries(self):
        provider, client = self._make_provider()
        from google.genai import errors as genai_errors
        err = genai_errors.ServerError(503, {"error": "UNAVAILABLE"})
        client.models.generate_content.side_effect = [err, err, err]

        with patch("prompt_tester.llm.providers.gemini.time.sleep"):
            with pytest.raises(genai_errors.ServerError):
                provider.complete(model="gemini-3.1-flash-lite", prompt="hi")

        assert client.models.generate_content.call_count == 3

    def test_retries_on_rate_limit_error(self):
        provider, client = self._make_provider()
        success = _make_gemini_response("ok")
        from google.genai import errors as genai_errors
        rate_limit_err = genai_errors.ClientError(429, {"error": "RESOURCE_EXHAUSTED"})
        client.models.generate_content.side_effect = [rate_limit_err, success]

        with patch("prompt_tester.llm.providers.gemini.time.sleep") as mock_sleep:
            result = provider.complete(model="gemini-3.1-flash-lite", prompt="hi")

        assert result.text == "ok"
        assert client.models.generate_content.call_count == 2
        mock_sleep.assert_called_once_with(1.0)

    def test_non_429_client_error_not_retried(self):
        provider, client = self._make_provider()
        from google.genai import errors as genai_errors
        err = genai_errors.ClientError(400, {"error": "BAD_REQUEST"})
        client.models.generate_content.side_effect = err

        with pytest.raises(genai_errors.ClientError):
            provider.complete(model="gemini-3.1-flash-lite", prompt="hi")

        assert client.models.generate_content.call_count == 1

    def test_none_token_counts_default_to_zero(self):
        provider, client = self._make_provider()
        resp = _make_gemini_response("ok")
        resp.usage_metadata.prompt_token_count     = None
        resp.usage_metadata.candidates_token_count = None
        client.models.generate_content.return_value = resp

        result = provider.complete(model="gemini-3.1-flash-lite", prompt="hi")
        assert result.input_tokens  == 0
        assert result.output_tokens == 0


# ---------------------------------------------------------------------------
# Interchangeability — same call signature, same return shape
# ---------------------------------------------------------------------------

class TestProviderInterchangeability:
    """
    Verify that AnthropicProvider and GeminiProvider can be used
    interchangeably through the LLMProvider interface.
    """

    @pytest.mark.parametrize("provider,client_attr,response_fn", [
        ("anthropic", "messages.create",         _make_anthropic_response),
        ("gemini",    "models.generate_content",  _make_gemini_response),
    ])
    def test_complete_accepts_same_kwargs(self, provider, client_attr, response_fn):
        if provider == "anthropic":
            with patch("prompt_tester.llm.providers.anthropic.anthropic.Anthropic") as mock_cls:
                p = AnthropicProvider()
            _set_mock(mock_cls.return_value, client_attr, response_fn("result", 5, 10))
        else:
            with patch("prompt_tester.llm.providers.gemini.genai.Client") as mock_cls:
                p = GeminiProvider()
            _set_mock(mock_cls.return_value, client_attr, response_fn("result", 5, 10))

        result = p.complete(
            model      = "any-model",
            prompt     = "any prompt",
            system     = "any system",
            max_tokens = 256,
        )
        assert isinstance(result, CompletionResult)
        assert result.text == "result"


def _set_mock(client: MagicMock, dotted_attr: str, return_value) -> None:
    """Set a return value on a dotted attribute path of a mock."""
    parts  = dotted_attr.split(".")
    target = client
    for part in parts[:-1]:
        target = getattr(target, part)
    getattr(target, parts[-1]).return_value = return_value
