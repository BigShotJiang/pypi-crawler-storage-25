"""
Unit tests for the prompt_tester library.

All LLM API calls are mocked — no network required.
"""

from __future__ import annotations

import inspect
import json
import threading
from unittest.mock import MagicMock

import pytest

import prompt_tester
from prompt_tester import Model, Provider, prompt_run
from prompt_tester.config import ConfigurationError
from prompt_tester.decorator import _get_judge, render_prompt
from prompt_tester.judge import Judge
from prompt_tester.models import (
    Assertion,
    AssertionType,
    UsageMetrics,
)
from prompt_tester.llm.providers.base import CompletionResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fake_judge_response(answer: str, snippet: str | None = "some text") -> CompletionResult:
    reasoning = f"I found: '{snippet}'" if snippet else "Not found in response."
    return CompletionResult(
        text          = json.dumps({"answer": answer, "snippet": snippet, "reasoning": reasoning}),
        input_tokens  = 5,
        output_tokens = 10,
    )


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

class TestConfiguration:
    def setup_method(self):
        prompt_tester.reset()

    def teardown_method(self):
        prompt_tester.reset()

    def test_configure_sets_model_and_provider(self):
        prompt_tester.configure(
            judge_model    = Model.GEMINI_2_5_FLASH,
            judge_provider = Provider.GOOGLE,
        )
        from prompt_tester.config import get_config
        cfg = get_config()
        assert cfg.judge_model    == "gemini-2.5-flash"
        assert cfg.judge_provider == "google"

    def test_configure_accepts_plain_strings(self):
        prompt_tester.configure(
            judge_model    = "gemini-2.5-flash",
            judge_provider = "google",
        )
        from prompt_tester.config import get_config
        assert get_config().judge_model == "gemini-2.5-flash"

    def test_reset_clears_config(self):
        prompt_tester.configure(
            judge_model    = Model.GEMINI_2_5_FLASH,
            judge_provider = Provider.GOOGLE,
        )
        prompt_tester.reset()
        from prompt_tester.config import get_config
        cfg = get_config()
        assert cfg.judge_model    is None
        assert cfg.judge_provider is None

    def test_get_judge_raises_if_not_configured(self):
        with pytest.raises(ConfigurationError, match="configure()"):
            _get_judge()

    def test_get_judge_raises_if_model_missing(self):
        # Manually set only provider to simulate partial state
        from prompt_tester.config import _config
        _config.judge_provider = "google"
        _config.judge_model    = None
        with pytest.raises(ConfigurationError):
            _get_judge()

    def test_get_judge_raises_if_provider_missing(self):
        from prompt_tester.config import _config
        _config.judge_model    = "gemini-2.5-flash"
        _config.judge_provider = None
        with pytest.raises(ConfigurationError):
            _get_judge()


# ---------------------------------------------------------------------------
# render_prompt
# ---------------------------------------------------------------------------

class TestRenderPrompt:
    def test_substitutes_single_var(self):
        assert render_prompt("Hello {name}.", {"name": "Alice"}) == "Hello Alice."

    def test_substitutes_multiple_vars(self):
        assert render_prompt("{a} and {b}", {"a": "X", "b": "Y"}) == "X and Y"

    def test_no_inputs_unchanged(self):
        prompt = "No variables here."
        assert render_prompt(prompt, {}) == prompt

    def test_literal_braces_untouched(self):
        result = render_prompt('{"json": "value"} and {name}', {"name": "Bob"})
        assert result == '{"json": "value"} and Bob'

    def test_non_string_value_converted(self):
        assert render_prompt("count={n}", {"n": 42}) == "count=42"


# ---------------------------------------------------------------------------
# Assertion validation
# ---------------------------------------------------------------------------

class TestAssertionValidation:
    def test_response_assertion_requires_question(self):
        with pytest.raises(Exception):
            Assertion(type=AssertionType.RESPONSE)

    def test_valid_response_assertion(self):
        a = Assertion(type=AssertionType.RESPONSE, question="Is X mentioned?")
        assert a.question == "Is X mentioned?"


# ---------------------------------------------------------------------------
# Judge
# ---------------------------------------------------------------------------

class TestAskParallel:
    def setup_method(self):
        prompt_tester.reset()

    def teardown_method(self):
        prompt_tester.reset()

    def test_returns_verdicts_in_question_order(self):
        # side_effect as a function is thread-safe: answer depends on the question
        # in the prompt, not on which call arrived first.
        def answer_by_question(*args, **kwargs):
            # Match on the question text in the prompt, not the response body
            # (the response itself contains "Alice", so matching on "Alice" alone
            # would hit every call).
            prompt = kwargs.get("prompt", "")
            if "Is Alice mentioned?" in prompt:
                return CompletionResult(
                    text=json.dumps({"answer": "yes", "snippet": "Alice"}),
                    input_tokens=5, output_tokens=5,
                )
            if "Is Bob mentioned?" in prompt:
                return CompletionResult(
                    text=json.dumps({"answer": "no", "snippet": None}),
                    input_tokens=5, output_tokens=5,
                )
            return CompletionResult(
                text=json.dumps({"answer": "yes", "snippet": "Q3"}),
                input_tokens=5, output_tokens=5,
            )

        judge_provider = MagicMock()
        judge_provider.complete.side_effect = answer_by_question

        from prompt_tester.decorator import _judges
        from prompt_tester.judge import Judge
        from prompt_tester.models import PromptRun

        prompt_tester.configure(
            judge_model    = Model.GEMINI_2_5_FLASH,
            judge_provider = Provider.GOOGLE,
        )
        judge = Judge(provider=judge_provider, model="gemini-2.5-flash", provider_name="google")
        _judges["google:gemini-2.5-flash"] = judge

        run = PromptRun(
            prompt="p", output="Alice is here. Q3 deadline.",
            model="gemini-2.5-flash", provider="google",
            input_tokens=10, output_tokens=5,
        )
        run._judge = judge

        q1, q2, q3 = run.ask_parallel([
            "Is Alice mentioned?",
            "Is Bob mentioned?",
            "Is Q3 mentioned?",
        ])

        # Order preserved and each question got its own distinct answer
        assert q1.question == "Is Alice mentioned?" and q1.passed is True
        assert q2.question == "Is Bob mentioned?"   and q2.passed is False
        assert q3.question == "Is Q3 mentioned?"    and q3.passed is True
        assert judge_provider.complete.call_count == 3

    def test_exception_collected_with_message(self):
        judge_provider = MagicMock()
        judge_provider.complete.side_effect = RuntimeError("API down")

        from prompt_tester.decorator import _judges
        from prompt_tester.judge import Judge
        from prompt_tester.models import PromptRun

        prompt_tester.configure(
            judge_model    = Model.GEMINI_2_5_FLASH,
            judge_provider = Provider.GOOGLE,
        )
        judge = Judge(provider=judge_provider, model="gemini-2.5-flash", provider_name="google")
        _judges["google:gemini-2.5-flash"] = judge

        run = PromptRun(
            prompt="p", output="x",
            model="m", provider="google",
            input_tokens=1, output_tokens=1,
        )
        run._judge = judge

        with pytest.raises(RuntimeError, match="judge call"):
            run.ask_parallel(["Q1?", "Q2?"])

    def test_raises_without_judge(self):
        from prompt_tester.models import PromptRun
        run = PromptRun(
            prompt="p", output="x",
            model="m", provider="google",
            input_tokens=1, output_tokens=1,
        )
        with pytest.raises(RuntimeError, match="No judge available"):
            run.ask_parallel(["Any question?"])

    def test_empty_questions_returns_empty_list(self):
        from prompt_tester.models import PromptRun
        run = PromptRun(
            prompt="p", output="x",
            model="m", provider="google",
            input_tokens=1, output_tokens=1,
        )
        from prompt_tester.judge import Judge
        run._judge = MagicMock(spec=Judge)
        assert run.ask_parallel([]) == []


class TestJudge:
    def _make_judge(self) -> tuple[Judge, MagicMock]:
        provider = MagicMock()
        judge    = Judge(provider=provider, model="claude-haiku-4-5-20251001")
        return judge, provider

    def test_yes_answer_passes(self):
        judge, provider = self._make_judge()
        assertion = Assertion(type=AssertionType.RESPONSE, question="Is Alice mentioned?")
        provider.complete.return_value = _fake_judge_response("yes", "Alice was present")

        result = judge.evaluate("Alice attended the meeting.", assertion)

        assert result.passed  is True
        assert result.snippet == "Alice was present"

    def test_no_answer_fails(self):
        judge, provider = self._make_judge()
        assertion = Assertion(type=AssertionType.RESPONSE, question="Is Bob mentioned?")
        provider.complete.return_value = _fake_judge_response("no", None)

        result = judge.evaluate("Alice attended the meeting.", assertion)

        assert result.passed  is False
        assert result.snippet is None

    def test_malformed_json_fails_gracefully(self):
        judge, provider = self._make_judge()
        assertion = Assertion(type=AssertionType.RESPONSE, question="Any question?")
        provider.complete.return_value = CompletionResult(
            text="not json at all", input_tokens=5, output_tokens=10
        )

        result = judge.evaluate("some response", assertion)

        assert result.passed is False

    def test_evaluate_all_truncation_pads_with_failed_verdicts(self):
        judge, provider = self._make_judge()
        # Judge returns only 1 answer for 2 questions
        provider.complete.return_value = CompletionResult(
            text=json.dumps([{"answer": "yes", "snippet": "found", "reasoning": "I found it"}]),
            input_tokens=10, output_tokens=5,
        )
        assertions = [
            Assertion(type=AssertionType.RESPONSE, question="Q1?"),
            Assertion(type=AssertionType.RESPONSE, question="Q2?"),
        ]
        results = judge.evaluate_all("some response", assertions)

        assert len(results) == 2
        assert results[0].passed is True
        assert results[1].passed is False
        assert "truncated" in (results[1].reasoning or "")

    def test_case_insensitive_yes(self):
        judge, provider = self._make_judge()
        assertion = Assertion(type=AssertionType.RESPONSE, question="Yes?")
        provider.complete.return_value = CompletionResult(
            text=json.dumps({"answer": "YES", "snippet": "x"}),
            input_tokens=5,
            output_tokens=10,
        )

        result = judge.evaluate("x", assertion)

        assert result.passed is True


class TestPromptRunAskAll:
    """Tests for PromptRun.ask_all() — the PromptRun → evaluate_all wiring."""

    def setup_method(self):
        prompt_tester.reset()

    def teardown_method(self):
        prompt_tester.reset()

    def _make_run_with_judge(self, judge_provider):
        from prompt_tester.decorator import _judges
        from prompt_tester.judge import Judge
        from prompt_tester.models import PromptRun

        prompt_tester.configure(
            judge_model    = Model.GEMINI_2_5_FLASH,
            judge_provider = Provider.GOOGLE,
        )
        judge = Judge(provider=judge_provider, model="gemini-2.5-flash", provider_name="google")
        _judges["google:gemini-2.5-flash"] = judge

        run = PromptRun(
            prompt="p", output="Alice is here. Budget $2M. Q3 deadline.",
            model="gemini-2.5-flash", provider="google",
            input_tokens=10, output_tokens=5,
        )
        run._judge = judge
        return run

    def test_ask_all_returns_verdicts_in_order(self):
        judge_provider = MagicMock()
        judge_provider.complete.return_value = CompletionResult(
            text=json.dumps([
                {"answer": "yes", "snippet": "Alice", "reasoning": "found Alice"},
                {"answer": "no",  "snippet": None,    "reasoning": "no budget"},
            ]),
            input_tokens=10, output_tokens=8,
        )
        run = self._make_run_with_judge(judge_provider)

        alice, budget = run.ask_all([
            "Is Alice mentioned?",
            "Is the $2M budget mentioned?",
        ])

        assert alice.passed  is True
        assert alice.question == "Is Alice mentioned?"
        assert budget.passed is False
        assert budget.question == "Is the $2M budget mentioned?"
        assert judge_provider.complete.call_count == 1

    def test_ask_all_empty_returns_empty(self):
        run = self._make_run_with_judge(MagicMock())
        assert run.ask_all([]) == []

    def test_ask_all_single_question_uses_single_call_path(self):
        """Single-item ask_all should call evaluate() not the batch path."""
        judge_provider = MagicMock()
        judge_provider.complete.return_value = _fake_judge_response("yes", "Alice")
        run = self._make_run_with_judge(judge_provider)

        (verdict,) = run.ask_all(["Is Alice mentioned?"])

        assert verdict.passed is True
        assert judge_provider.complete.call_count == 1


class TestToDict:
    def test_prompt_run_to_dict_contains_all_fields(self):
        from prompt_tester.models import PromptRun
        run = PromptRun(
            prompt="hello", output="world",
            model="m", provider="google",
            input_tokens=5, output_tokens=3,
            cost_usd=0.001,
        )
        d = run.to_dict()
        assert d["prompt"]        == "hello"
        assert d["output"]        == "world"
        assert d["cost_usd"]      == pytest.approx(0.001)
        assert d["input_tokens"]  == 5

    def test_judge_verdict_to_dict_contains_all_fields(self):
        from prompt_tester.models import JudgeVerdict
        v = JudgeVerdict(
            question="Is Alice mentioned?",
            answer="yes",
            passed=True,
            snippet="Alice",
            reasoning="found Alice",
            judge_model="gemini-2.5-flash",
            judge_provider="google",
            judge_input_tokens=10,
            judge_output_tokens=5,
            judge_cost_usd=0.0001,
        )
        d = v.to_dict()
        assert d["question"]             == "Is Alice mentioned?"
        assert d["passed"]               is True
        assert d["judge_model"]          == "gemini-2.5-flash"
        assert d["judge_input_tokens"]   == 10
        assert d["judge_cost_usd"]       == pytest.approx(0.0001)


# ---------------------------------------------------------------------------
# Pricing
# ---------------------------------------------------------------------------

class TestPricing:
    def test_known_model_returns_cost(self):
        from prompt_tester.config import compute_cost
        cost = compute_cost("claude-haiku-4-5-20251001", 1_000_000, 0)
        assert cost == pytest.approx(0.80)

    def test_output_tokens_more_expensive(self):
        from prompt_tester.config import compute_cost
        input_cost  = compute_cost("claude-haiku-4-5-20251001", 1_000_000, 0)
        output_cost = compute_cost("claude-haiku-4-5-20251001", 0, 1_000_000)
        assert output_cost > input_cost

    def test_unknown_model_returns_none(self):
        from prompt_tester.config import compute_cost
        assert compute_cost("gpt-5-turbo", 1000, 1000) is None

    def test_zero_tokens_zero_cost(self):
        from prompt_tester.config import compute_cost
        assert compute_cost("claude-haiku-4-5-20251001", 0, 0) == 0.0

    def test_cached_tokens_cheaper_than_regular(self):
        from prompt_tester.config import compute_cost
        regular = compute_cost("claude-haiku-4-5-20251001", 1_000_000, 0)
        cached  = compute_cost("claude-haiku-4-5-20251001", 1_000_000, 0,
                               cached_input_tokens=1_000_000)
        assert cached < regular

    def test_cache_creation_costs_more_than_regular(self):
        from prompt_tester.config import compute_cost
        regular  = compute_cost("claude-haiku-4-5-20251001", 1_000_000, 0)
        creating = compute_cost("claude-haiku-4-5-20251001", 1_000_000, 0,
                                cache_creation_tokens=1_000_000)
        assert creating > regular

    def test_cached_tokens_exceeding_input_raises(self):
        from prompt_tester.config import compute_cost
        with pytest.raises(ValueError, match="cached_input_tokens"):
            compute_cost("claude-haiku-4-5-20251001", 100, 0, cached_input_tokens=200)


# ---------------------------------------------------------------------------
# @prompt_run decorator — end-to-end with mocked provider
# ---------------------------------------------------------------------------

class TestPromptRunDecorator:
    def setup_method(self):
        prompt_tester.reset()

    def teardown_method(self):
        prompt_tester.reset()

    def _configure_with_mock_judge(self, provider_mock):
        """Wire up a mock judge provider and configure prompt_tester."""
        from prompt_tester.decorator import _judges, _providers
        from prompt_tester.judge import Judge

        prompt_tester.configure(
            judge_model    = Model.GEMINI_2_5_FLASH,
            judge_provider = Provider.GOOGLE,
        )
        judge = Judge(provider=provider_mock, model="gemini-2.5-flash", provider_name="google")
        _judges["google:gemini-2.5-flash"] = judge
        return judge

    def test_run_injects_output_into_test_function(self):
        subject_provider = MagicMock()
        subject_provider.complete.return_value = CompletionResult(
            text="Hello, Alice!", input_tokens=10, output_tokens=5
        )
        judge_provider = MagicMock()
        self._configure_with_mock_judge(judge_provider)

        from prompt_tester.decorator import _providers
        _providers["google"] = subject_provider

        captured = {}

        @prompt_run(
            target_prompt    = "Say hello to {name}.",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
            template_vars    = {"name": "Alice"},
        )
        def test_fn(run):
            captured["output"]        = run.output
            captured["prompt"]        = run.prompt
            captured["input_tokens"]  = run.input_tokens
            captured["output_tokens"] = run.output_tokens

        test_fn()
        assert captured["output"]        == "Hello, Alice!"
        assert captured["prompt"]        == "Say hello to Alice."
        assert captured["input_tokens"]  == 10
        assert captured["output_tokens"] == 5

    def test_pytest_marks_are_preserved(self):
        import pytest as _pytest

        @_pytest.mark.slow
        @prompt_run(
            target_prompt    = "Hello",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
        )
        def test_fn(run):
            pass

        marks = [m.name for m in getattr(test_fn, "pytestmark", [])]
        assert "slow" in marks

    def test_parametrize_with_prompt_run(self):
        """parametrize + @prompt_run: extra args pass through and run executes N times."""
        subject_provider = MagicMock()
        subject_provider.complete.return_value = CompletionResult(
            text="hello", input_tokens=5, output_tokens=2
        )
        self._configure_with_mock_judge(MagicMock())

        from prompt_tester.decorator import _providers
        _providers["google"] = subject_provider

        call_log = []

        @prompt_run(
            target_prompt    = "Hello",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
        )
        def test_fn(run, iteration):
            call_log.append(iteration)

        for i in range(3):
            test_fn(i)

        assert call_log == [0, 1, 2]
        assert subject_provider.complete.call_count == 3

    def test_run_ask_returns_verdict(self):
        subject_provider = MagicMock()
        subject_provider.complete.return_value = CompletionResult(
            text="Alice attended.", input_tokens=8, output_tokens=3
        )
        judge_provider = MagicMock()
        judge_provider.complete.return_value = _fake_judge_response("yes", "Alice attended")
        self._configure_with_mock_judge(judge_provider)

        from prompt_tester.decorator import _providers
        _providers["google"] = subject_provider

        captured = {}

        @prompt_run(
            target_prompt    = "Report",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
        )
        def test_fn(run):
            captured["verdict"] = run.ask("Is Alice mentioned?")

        test_fn()
        assert captured["verdict"].passed  is True
        assert captured["verdict"].snippet == "Alice attended"

    def test_run_ask_populates_reasoning(self):
        subject_provider = MagicMock()
        subject_provider.complete.return_value = CompletionResult(
            text="Bob was present.", input_tokens=6, output_tokens=2
        )
        judge_provider = MagicMock()
        judge_provider.complete.return_value = CompletionResult(
            text=json.dumps({
                "answer": "yes",
                "snippet": "Bob was present",
                "reasoning": "I found: 'Bob was present' in the response",
            }),
            input_tokens=5,
            output_tokens=10,
        )
        self._configure_with_mock_judge(judge_provider)

        from prompt_tester.decorator import _providers
        _providers["google"] = subject_provider

        captured = {}

        @prompt_run(
            target_prompt    = "Report",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
        )
        def test_fn(run):
            captured["verdict"] = run.ask("Is Bob mentioned?")

        test_fn()
        assert captured["verdict"].passed
        assert captured["verdict"].reasoning is not None
        assert "Bob" in captured["verdict"].reasoning


    def test_run_fn_bypasses_provider_and_feeds_judge(self):
        """run_fn output becomes run.output; judge evaluates it as normal."""
        judge_provider = MagicMock()
        judge_provider.complete.return_value = _fake_judge_response("yes", "Paris")
        self._configure_with_mock_judge(judge_provider)

        def my_agent(prompt: str, model: str, max_tokens: int) -> CompletionResult:
            # Simulates a full agentic loop (tool calls, multiple turns, etc.)
            return CompletionResult(
                text="The capital of France is Paris.",
                input_tokens=50,
                output_tokens=10,
                stop_reason="end_turn",
            )

        captured = {}

        @prompt_run(
            target_prompt    = "Find the capital of {country}.",
            subject_model    = Model.CLAUDE_SONNET_4_6,
            subject_provider = Provider.ANTHROPIC,
            template_vars    = {"country": "France"},
            run_fn           = my_agent,
        )
        def test_fn(run):
            captured["output"]     = run.output
            captured["model"]      = run.model
            captured["stop"]       = run.stop_reason
            captured["in_tokens"]  = run.input_tokens
            captured["out_tokens"] = run.output_tokens
            captured["verdict"]    = run.ask("Is Paris mentioned as the capital?")

        test_fn()
        assert captured["output"]     == "The capital of France is Paris."
        assert captured["model"]      == "claude-sonnet-4-6"
        assert captured["stop"]       == "end_turn"
        assert captured["in_tokens"]  == 50
        assert captured["out_tokens"] == 10
        assert captured["verdict"].passed is True

    def test_multi_run_all_pass(self):
        """runs=3 — all pass — wrapper asserts cleanly."""
        subject_provider = MagicMock()
        subject_provider.complete.return_value = CompletionResult(
            text="hello", input_tokens=5, output_tokens=2
        )
        self._configure_with_mock_judge(MagicMock())

        from prompt_tester.decorator import _providers
        _providers["google"] = subject_provider

        @prompt_run(
            target_prompt    = "Hello",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
            runs             = 3,
        )
        def test_fn(run):
            assert run.output == "hello"

        test_fn()
        assert subject_provider.complete.call_count == 3

    def test_multi_run_pass_threshold(self):
        """runs=3, pass_threshold=0.5 — one failure still passes overall (ceil(1.5)=2)."""
        call_count = {"n": 0}
        lock = threading.Lock()

        def make_provider():
            provider = MagicMock()
            def complete_side_effect(*args, **kwargs):
                with lock:
                    call_count["n"] += 1
                    n = call_count["n"]
                return CompletionResult(text=f"run{n}", input_tokens=1, output_tokens=1)
            provider.complete.side_effect = complete_side_effect
            return provider

        subject_provider = make_provider()
        self._configure_with_mock_judge(MagicMock())

        from prompt_tester.decorator import _providers
        _providers["google"] = subject_provider

        @prompt_run(
            target_prompt    = "Hello",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
            runs             = 3,
            pass_threshold   = 0.5,
        )
        def test_fn(run):
            if run.output == "run1":
                raise AssertionError("deliberate failure on run 1")

        test_fn()  # should not raise — 2/3 passes >= ceil(3 * 0.5) = 2

    def test_multi_run_below_threshold_raises(self):
        """runs=3, pass_threshold=1.0 — any failure raises AssertionError."""
        subject_provider = MagicMock()
        subject_provider.complete.return_value = CompletionResult(
            text="bad", input_tokens=1, output_tokens=1
        )
        self._configure_with_mock_judge(MagicMock())

        from prompt_tester.decorator import _providers
        _providers["google"] = subject_provider

        @prompt_run(
            target_prompt    = "Hello",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
            runs             = 3,
            pass_threshold   = 1.0,
        )
        def test_fn(run):
            raise AssertionError("always fails")

        with pytest.raises(AssertionError, match=r"0/3 runs passed"):
            test_fn()

    def test_multi_run_has_no_extra_params(self):
        """runs > 1 produces a zero-argument wrapper (no parametrize needed)."""
        subject_provider = MagicMock()
        subject_provider.complete.return_value = CompletionResult(
            text="x", input_tokens=1, output_tokens=1
        )
        self._configure_with_mock_judge(MagicMock())

        from prompt_tester.decorator import _providers
        _providers["google"] = subject_provider

        @prompt_run(
            target_prompt    = "Hello",
            subject_model    = Model.GEMINI_3_1_FLASH_LITE,
            subject_provider = Provider.GOOGLE,
            runs             = 2,
        )
        def test_fn(run):
            pass

        sig = inspect.signature(test_fn)
        assert len(sig.parameters) == 0

    def test_run_fn_prompt_is_rendered_before_passing(self):
        """template_vars are substituted into the prompt before run_fn is called."""
        judge_provider = MagicMock()
        self._configure_with_mock_judge(judge_provider)

        received = {}

        def capture_fn(prompt: str, model: str, max_tokens: int) -> CompletionResult:
            received["prompt"] = prompt
            return CompletionResult(text="ok", input_tokens=1, output_tokens=1)

        @prompt_run(
            target_prompt    = "Tell me about {topic}.",
            subject_model    = Model.CLAUDE_SONNET_4_6,
            subject_provider = Provider.ANTHROPIC,
            template_vars    = {"topic": "Paris"},
            run_fn           = capture_fn,
        )
        def test_fn(run):
            pass

        test_fn()
        assert received["prompt"] == "Tell me about Paris."

    def test_run_fn_wrong_return_type_raises(self):
        """run_fn returning a non-CompletionResult raises TypeError with helpful message."""
        self._configure_with_mock_judge(MagicMock())

        def bad_fn(prompt, model, max_tokens):
            return "not a CompletionResult"

        @prompt_run(
            target_prompt    = "Hello",
            subject_model    = Model.CLAUDE_SONNET_4_6,
            subject_provider = Provider.ANTHROPIC,
            run_fn           = bad_fn,
        )
        def test_fn(run):
            pass

        with pytest.raises(TypeError, match="CompletionResult"):
            test_fn()

    def test_runs_zero_raises(self):
        with pytest.raises(ValueError, match="runs must be >= 1"):
            @prompt_run(
                target_prompt    = "Hello",
                subject_model    = Model.GEMINI_3_1_FLASH_LITE,
                subject_provider = Provider.GOOGLE,
                runs             = 0,
            )
            def test_fn(run):
                pass

    def test_pass_threshold_zero_raises(self):
        with pytest.raises(ValueError, match="pass_threshold"):
            @prompt_run(
                target_prompt    = "Hello",
                subject_model    = Model.GEMINI_3_1_FLASH_LITE,
                subject_provider = Provider.GOOGLE,
                runs             = 3,
                pass_threshold   = 0.0,
            )
            def test_fn(run):
                pass

    def test_pass_threshold_above_one_raises(self):
        with pytest.raises(ValueError, match="pass_threshold"):
            @prompt_run(
                target_prompt    = "Hello",
                subject_model    = Model.GEMINI_3_1_FLASH_LITE,
                subject_provider = Provider.GOOGLE,
                runs             = 3,
                pass_threshold   = 1.5,
            )
            def test_fn(run):
                pass


# ---------------------------------------------------------------------------
# render_prompt — single-pass substitution
# ---------------------------------------------------------------------------

class TestRenderPromptSinglePass:
    def test_no_double_substitution(self):
        from prompt_tester.decorator import render_prompt
        # Value of 'a' contains '{b}' — second var must NOT be re-expanded.
        # No warning fires because the original prompt only has {a}, which IS
        # in inputs. The {b} in the substituted value is not in the original.
        result = render_prompt("start {a} end", {"a": "{b}", "b": "WRONG"})
        assert result == "start {b} end"

    def test_empty_inputs_returns_prompt_unchanged(self):
        from prompt_tester.decorator import render_prompt
        assert render_prompt("no vars here", {}) == "no vars here"

    def test_unmatched_placeholder_emits_warning(self):
        from prompt_tester.decorator import render_prompt
        with pytest.warns(UserWarning, match="unmatched placeholder"):
            result = render_prompt("Hello {name}!", {"greeting": "hi"})
        assert "{name}" in result  # left verbatim

    def test_placeholder_in_prompt_with_no_template_vars_warns(self):
        """Prompt with {placeholder} and empty inputs should still warn."""
        from prompt_tester.decorator import render_prompt
        with pytest.warns(UserWarning, match="unmatched placeholder"):
            result = render_prompt("Hello {name}!", {})
        assert "{name}" in result
