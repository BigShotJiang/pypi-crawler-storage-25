"""
Judge — evaluates yes/no assertions against a model response.

Two modes:
  evaluate(response, assertion)         — one API call per assertion
  evaluate_all(response, assertions)    — all RESPONSE assertions in one call

The batch mode trades potential cross-contamination risk for lower latency and
cost. Use the single-call mode (default) when assertion independence matters.
"""

from __future__ import annotations

import json
import logging

_log = logging.getLogger(__name__)

from prompt_tester.llm.providers.base import LLMProvider

from prompt_tester.models import Assertion, AssertionResult, AssertionType, UsageMetrics
from prompt_tester.config import compute_cost

_EQUIVALENCES = """\
Equivalences — these count as matches:
- Case: term matching is case-insensitive (e.g. "REST API" matches "rest api").
- Plurals/inflections: singular and plural forms of the same noun are equivalent (server = servers; child = children). Tense variants of the same verb are equivalent (run = ran = running) unless the question is specifically about tense.
- Numbers: Nk = N×1,000 (e.g. 5k = 5,000; 1.5k = 1,500); NM = N million (e.g. 2M = 2 million; 3.5M = 3.5 million); NB = N billion; commas in numbers ignored (1,000 = 1000); ~ prefix means "approximately" and is ignored for matching. Examples: $12k=$12,000 · $1.2M=$1,200,000 · 8M=8 million
- Currency: any currency symbol ($, €, £) followed by Nk or NM follows the same k/M rule. Currency symbols and ISO codes are equivalent in context ($5 = USD 5 = 5 dollars).
- Time: 15min=15 minutes · 30sec=30 seconds · Nh/Nhr=N hours (e.g. 2h=2 hours) · Nd=N days (e.g. 7d=7 days) · Nwk/Nwks=N weeks (e.g. 6wk=six weeks) · Nmo=N months · Nyr=N years · Q1/Q2/Q3/Q4=first/second/third/fourth quarter · written-out number words equal digits (two=2, six=6, etc.)
- Percents: N% = N percent for any N (e.g. 40% = 40 percent; ~40% = approximately 40 percent; 97.1% = 97.1 percent)
- Ordinals: 1st=first, 2nd=second, 3rd=third, 4th=fourth, and so on.
- Fractions/decimals: 0.5=1/2=half; 0.25=1/4=a quarter; 0.75=three quarters.
- Ranges: "5-10" = "5 to 10" = "between 5 and 10".
- Dates: 2024-01-15 = January 15, 2024 = Jan 15 2024 = 15 Jan 2024. For ambiguous slash-dates (e.g. 1/2/24), match either reading.
- Lists: "A, B, and C" = "A, B, C" = "A; B; C" (order is ignored unless the question asks about ordering).
- Signed numbers: -5 = "negative five"; +5 = "positive five".
- Shorthands: if the response defines an abbreviation via any clearly-equating construction — parentheses ("Project Phoenix (PP)"), "or" ("Project Phoenix, or PP"), "a.k.a.", "short for", "stands for" — treat that abbreviation as equivalent to its full term throughout. Do not guess at undefined abbreviations.
- Well-known technical abbreviations may be treated as equivalent to their expansion without needing an explicit in-response definition: AI, ML, API, URL, HTTP/HTTPS, SQL, JSON, XML, CSV, PDF, OS, USA/US, UK, EU. Product names, project names, and company-specific acronyms still require an explicit definition per the Shorthands rule above.
- Partial matches do NOT count: a related term is not the same as the asked-for term. The specific term in the question must appear directly or via an explicitly defined shorthand."""

_SYSTEM = f"""\
You are an automated evaluator. You receive a model response and a yes/no question. Decide strictly from what the response says — do not bring in outside knowledge.

STEP 1 — Identify the question type:
A. Factual presence: "does it mention / state / include / recommend X?"
B. Factual absence / avoidance: "does it NOT mention X?", "does it avoid X?", "is X absent?"
C. Format / validity: "is it in JSON?", "does it use bullet points?", "is it valid markdown?"
D. Structure / count: "does it have 3 sections?", "is it under 200 words?", "does it list N items?"
E. Tone / style: "is it polite?", "is it concise?", "is the tone professional?"
F. Comparison / preference: "does it recommend A over B?", "does it prefer X to Y?"
G. Multi-part: "does it cover both A and B?", "does it include X, Y, and Z?"

STEP 2 — Apply the rule for that type:
A: answer "yes" iff X (or an equivalent per the rules below) appears in the response.
B: answer "yes" iff the forbidden content is ABSENT. INVERT the usual logic — finding X means "no", not "yes".
C: structurally check the response as a whole for the format property.
D: count or measure carefully across the whole response.
E: judge the response holistically against the trait. A representative excerpt may serve as evidence.
F: answer "yes" only if the response expresses a clear preference in the asked-for direction; merely mentioning both sides is not enough.
G: answer "yes" only if EVERY listed part is satisfied. Quote evidence for each part, separated by "; ".
If the question is ambiguous or cannot be determined from the response, answer "no" with reasoning "Cannot determine from response: <reason>".

STEP 3 — Output ONLY a JSON object with these three fields in this exact order.

Type A — found:
{{"reasoning": "I found: '<verbatim excerpt from the response>'", "answer": "yes", "snippet": "<verbatim excerpt, max 200 chars, with surrounding context>"}}

Type A — not found:
{{"reasoning": "Searched entire response for '<term>'; not found", "answer": "no", "snippet": null}}

Type B — absent (answer is yes):
{{"reasoning": "Avoidance check: '<forbidden term>' not found in response", "answer": "yes", "snippet": null}}

Type B — present (answer is no):
{{"reasoning": "Forbidden content found: '<verbatim excerpt>'", "answer": "no", "snippet": "<verbatim excerpt, max 200 chars>"}}

Types C / D / E / F / G — yes:
{{"reasoning": "<justification referencing the property checked, with verbatim evidence where applicable>", "answer": "yes", "snippet": "<representative excerpt if any, else null>"}}

Types C / D / E / F / G — no:
{{"reasoning": "<justification referencing the property checked>", "answer": "no", "snippet": null}}

The "reasoning" field is mandatory. For type A "yes" and type B "no", it MUST contain a verbatim quoted excerpt in single quotes. Paraphrase is not acceptable — copy the actual text. Do not include literal {{ }} or [ ] characters inside string values as they break JSON parsing.

{_EQUIVALENCES}

Do NOT output markdown, code blocks, or any text outside the JSON object."""

_SYSTEM_BATCH = f"""\
You are an automated evaluator. You receive a model response and a numbered list of yes/no questions. Decide strictly from what the response says — do not bring in outside knowledge.

INDEPENDENCE: Treat each question as fully independent. Re-read the response for each one. Do not let your answer to one question influence another. Different questions may yield unrelated snippets, or the same snippet may support multiple answers.

STEP 1 — For each question, identify its type:
A. Factual presence: "does it mention / state / include / recommend X?"
B. Factual absence / avoidance: "does it NOT mention X?", "does it avoid X?", "is X absent?"
C. Format / validity: "is it in JSON?", "does it use bullet points?"
D. Structure / count: "does it have 3 sections?", "is it under 200 words?"
E. Tone / style: "is it polite?", "is it concise?", "is the tone professional?"
F. Comparison / preference: "does it recommend A over B?", "does it prefer X to Y?"
G. Multi-part: "does it cover both A and B?", "does it include X, Y, and Z?"

STEP 2 — Apply the rule for that type:
A: "yes" iff X (or an equivalent per the rules below) appears in the response.
B: "yes" iff the forbidden content is ABSENT. INVERT the usual logic — finding X means "no", not "yes".
C: structurally check the whole response for the format property.
D: count or measure carefully.
E: judge holistically; a representative excerpt may serve as evidence.
F: "yes" only if the response expresses a clear preference in the asked-for direction.
G: "yes" only if EVERY listed part is satisfied. Quote evidence for each part, separated by "; ".
If a question is ambiguous or cannot be determined, answer "no" with reasoning "Cannot determine from response: <reason>".

STEP 3 — Output ONLY a JSON array — one object per question, in the same order as the questions:

[
  {{"reasoning": "I found: '<verbatim excerpt>'", "answer": "yes", "snippet": "<verbatim excerpt, max 200 chars with surrounding context>"}},
  {{"reasoning": "Searched entire response for '<term>'; not found", "answer": "no", "snippet": null}},
  ...
]

Each object's "reasoning" field is mandatory. For type A "yes" and type B "no", it MUST contain a verbatim quoted excerpt in single quotes. Paraphrase is not acceptable — copy the actual text. Do not include literal {{ }} or [ ] characters inside string values as they break JSON parsing.

{_EQUIVALENCES}

Do NOT output markdown, code blocks, or any text outside the JSON array."""


def _build_user_msg(response: str, question: str) -> str:
    return (
        f"Model response:\n---\n{response}\n---\n\n"
        f"Question: {question}"
    )


def _build_batch_user_msg(response: str, assertions: list[Assertion]) -> str:
    questions = "\n".join(
        f"{i + 1}. {a.question}" for i, a in enumerate(assertions)
    )
    return (
        f"Model response:\n---\n{response}\n---\n\n"
        f"Questions:\n{questions}"
    )


def _extract_json(text: str) -> dict:
    """Extract first JSON object from text; returns {} on failure."""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start, end = text.find('{'), text.rfind('}')
    if start != -1 and end > start:
        try:
            return json.loads(text[start:end + 1])
        except json.JSONDecodeError:
            pass
    return {}


def _extract_json_list(text: str) -> list[dict]:
    """Extract first JSON array from text; returns [] on failure."""
    try:
        result = json.loads(text)
        if isinstance(result, list):
            return result
    except json.JSONDecodeError:
        pass
    start, end = text.find('['), text.rfind(']')
    if start != -1 and end > start:
        try:
            result = json.loads(text[start:end + 1])
            if isinstance(result, list):
                return result
        except json.JSONDecodeError:
            pass
    return []


class Judge:
    """
    Evaluates response assertions using an LLM provider.

    Parameters
    ----------
    provider : LLMProvider
        Provider instance to use for judge calls.
    model : str
        Model ID to pass to the provider.
    """

    def __init__(self, provider: LLMProvider, model: str, provider_name: str = "unknown") -> None:
        self._provider      = provider
        self._model         = model
        self._provider_name = provider_name

    def evaluate(self, response: str, assertion: Assertion) -> AssertionResult:
        """Evaluate one RESPONSE assertion — one API call."""
        result = self._provider.complete(
            model      = self._model,
            prompt     = _build_user_msg(response, assertion.question),
            system     = _SYSTEM,
            max_tokens = 512,
        )

        usage = UsageMetrics(
            input_tokens  = result.input_tokens,
            output_tokens = result.output_tokens,
            cost_usd      = compute_cost(
                self._model,
                result.input_tokens,
                result.output_tokens,
                cached_input_tokens   = result.cached_input_tokens,
                cache_creation_tokens = result.cache_creation_tokens,
            ),
        )

        parsed    = _extract_json(result.text.strip())
        passed    = str(parsed.get("answer", "no")).lower() == "yes"
        snippet   = parsed.get("snippet")   or None
        reasoning = parsed.get("reasoning") or None

        _log.debug("[JUDGE] Q: %s | A: %s | %s", assertion.question, parsed.get("answer", "?"), reasoning or "no reasoning")

        return AssertionResult(
            assertion = assertion,
            passed    = passed,
            snippet   = snippet,
            reasoning = reasoning,
            usage     = usage,
        )

    def evaluate_all(
        self, response: str, assertions: list[Assertion]
    ) -> list[AssertionResult]:
        """
        Evaluate all RESPONSE assertions in a single API call.

        Tokens are split evenly across assertions so that usage totals
        remain accurate when costs are aggregated.
        """
        if not assertions:
            return []

        for a in assertions:
            if a.type != AssertionType.RESPONSE:
                raise ValueError(
                    f"evaluate_all only handles RESPONSE assertions; got {a.type!r}. "
                    "Filter non-RESPONSE assertions before calling."
                )

        if len(assertions) == 1:
            return [self.evaluate(response, assertions[0])]

        result = self._provider.complete(
            model      = self._model,
            prompt     = _build_batch_user_msg(response, assertions),
            system     = _SYSTEM_BATCH,
            max_tokens = min(512 * len(assertions), 8192),
        )

        parsed_list = _extract_json_list(result.text.strip())

        n = len(assertions)
        if len(parsed_list) < n:
            _log.warning(
                "Judge returned %d answer(s) for %d question(s) — "
                "response may have been truncated. Missing answers will be marked failed.",
                len(parsed_list), n,
            )
            parsed_list += [None] * (n - len(parsed_list))

        n_extra = len(parsed_list) - n
        if n_extra > 0:
            _log.warning(
                "Judge returned %d answer(s) for %d question(s) — extra items ignored.",
                len(parsed_list), n,
            )
            parsed_list = parsed_list[:n]

        total_cost = compute_cost(
            self._model,
            result.input_tokens,
            result.output_tokens,
            cached_input_tokens   = result.cached_input_tokens,
            cache_creation_tokens = result.cache_creation_tokens,
        )
        # Tokens are divided evenly; any remainder goes to the last item.
        # When output_tokens < n, most per-item costs are 0.0 — this is an
        # approximation; the total across all items is always accurate.
        base_input  = result.input_tokens  // n
        base_output = result.output_tokens // n
        rem_input   = result.input_tokens  - base_input  * n
        rem_output  = result.output_tokens - base_output * n

        assertion_results: list[AssertionResult] = []
        for i, assertion in enumerate(assertions):
            raw = parsed_list[i]
            if raw is None:
                passed    = False
                snippet   = None
                reasoning = "Judge response was truncated — this answer was not returned."
            else:
                passed    = str(raw.get("answer", "no")).lower() == "yes"
                snippet   = raw.get("snippet")   or None
                reasoning = raw.get("reasoning") or None

            _log.debug("[JUDGE/batch] Q: %s | A: %s | %s", assertion.question, "yes" if passed else "no", reasoning or "no reasoning")

            is_last    = (i == n - 1)
            inp_tokens = base_input  + (rem_input  if is_last else 0)
            out_tokens = base_output + (rem_output if is_last else 0)
            # Split cached tokens proportionally so per-item costs sum to total_cost.
            base_cached   = result.cached_input_tokens   // n
            base_creation = result.cache_creation_tokens // n
            item_cached   = base_cached   + (result.cached_input_tokens   - base_cached   * n if is_last else 0)
            item_creation = base_creation + (result.cache_creation_tokens - base_creation * n if is_last else 0)
            item_cost  = (compute_cost(
                              self._model, inp_tokens, out_tokens,
                              cached_input_tokens   = item_cached,
                              cache_creation_tokens = item_creation,
                          ) if total_cost is not None else None)

            assertion_results.append(AssertionResult(
                assertion = assertion,
                passed    = passed,
                snippet   = snippet,
                reasoning = reasoning,
                usage     = UsageMetrics(
                    input_tokens  = inp_tokens,
                    output_tokens = out_tokens,
                    cost_usd      = item_cost,
                ),
            ))

        return assertion_results
