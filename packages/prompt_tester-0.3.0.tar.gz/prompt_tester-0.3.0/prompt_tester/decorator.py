"""
@prompt_run decorator — decorator-based prompt testing API.

Usage
-----
    from pathlib import Path
    import prompt_tester
    from prompt_tester import prompt_run, Model, Provider

    prompt_tester.configure(
        judge_model    = Model.GEMINI_2_5_FLASH,
        judge_provider = Provider.GOOGLE,
    )

    PROMPT = Path("prompts/compactor.md").read_text()
    INPUT  = "Alice leads Project Phoenix. Budget: $2M. Deadline: Q3."

    @prompt_run(
        target_prompt    = PROMPT,
        subject_model    = Model.GEMINI_3_1_FLASH_LITE,
        subject_provider = Provider.GOOGLE,
        template_vars    = {"text": INPUT},
        runs             = 5,
        pass_threshold   = 0.8,
    )
    def test_compactor_is_concise(run):
        assert len(run.output) < len(run.template_vars["text"]) * 0.6

        verdict = run.ask("Is Alice mentioned in the output?")
        assert verdict.passed, verdict.reasoning
"""

from __future__ import annotations

import functools
import inspect
import math
import re
import threading
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING, Callable

from prompt_tester.llm.providers.base import CompletionResult, LLMProvider

if TYPE_CHECKING:
    from prompt_tester.judge import Judge


def render_prompt(prompt: str, inputs: dict, _stacklevel: int = 2) -> str:
    """
    Substitute ``{key}`` placeholders in a single pass.

    Literal braces that do not match any key are left as-is. Single-pass
    substitution means a value containing ``{another_key}`` is never
    re-expanded.

    Raises ``UserWarning`` if the original prompt contains ``{word}`` patterns
    that have no matching key in ``inputs`` — likely a typo in a
    ``template_vars`` key or a forgotten variable.
    """
    # Scan the ORIGINAL prompt for unmatched placeholders before substitution
    # to avoid false positives from JSON-shaped content in substituted values.
    # Also catches the case where inputs is empty but the prompt has placeholders.
    all_placeholders = set(re.findall(r"\{([A-Za-z_]\w*)\}", prompt))
    unmatched = sorted(all_placeholders - set(inputs.keys()))
    if unmatched:
        warnings.warn(
            f"render_prompt: possible unmatched placeholder(s): {unmatched}. "
            "Check your template_vars keys for typos.",
            UserWarning,
            stacklevel=_stacklevel,
        )
    if not inputs:
        return prompt
    pattern = re.compile(r"\{(" + "|".join(re.escape(k) for k in inputs) + r")\}")
    return pattern.sub(lambda m: str(inputs[m.group(1)]), prompt)


# Module-level lazy caches — providers and judges are shared across tests.
# Note: pytest-xdist (parallel workers) is not supported; each worker runs
# in a separate process so these caches are not shared across workers.
_providers: dict[str, LLMProvider] = {}
_judges:    dict[str, "Judge"]     = {}
_cache_lock = threading.RLock()


def clear_caches() -> None:
    """Clear cached provider and judge instances. Called by config.reset()."""
    with _cache_lock:
        _judges.clear()
        _providers.clear()


_dotenv_loaded = False


def _load_dotenv() -> None:
    global _dotenv_loaded
    if _dotenv_loaded:
        return
    # find_dotenv(usecwd=True) walks up from the current working directory,
    # which is the project root when pytest is invoked normally.
    from dotenv import find_dotenv, load_dotenv
    load_dotenv(find_dotenv(usecwd=True))
    _dotenv_loaded = True


def _get_provider(name: str) -> LLMProvider:
    _load_dotenv()  # outside lock — idempotent, avoids I/O inside critical section
    with _cache_lock:
        if name not in _providers:
            if name == "anthropic":
                try:
                    from prompt_tester.llm.providers.anthropic import AnthropicProvider
                except ImportError:
                    raise ImportError(
                        "anthropic SDK not installed. Install it with:\n"
                        "    pip install prompt-tester[anthropic]"
                    ) from None
                _providers[name] = AnthropicProvider()
            elif name == "google":
                try:
                    from prompt_tester.llm.providers.gemini import GeminiProvider
                except ImportError:
                    raise ImportError(
                        "google-genai SDK not installed. Install it with:\n"
                        "    pip install prompt-tester[google]"
                    ) from None
                _providers[name] = GeminiProvider()
            else:
                raise ValueError(f"Unknown provider {name!r}. Supported: 'anthropic', 'google'")
    return _providers[name]


def _get_judge() -> "Judge":
    from prompt_tester.config import ConfigurationError, get_config

    # Read config inside _cache_lock so reset() can't clear the cache between
    # our config read and our cache write. reset() releases _config_lock before
    # calling clear_caches(), so lock ordering is always _cache_lock → _config_lock
    # with no risk of deadlock.
    with _cache_lock:
        cfg = get_config()
        if not cfg.judge_model or not cfg.judge_provider:
            raise ConfigurationError(
                "Judge model not configured. Call prompt_tester.configure() before using @prompt_run:\n\n"
                "    import prompt_tester\n"
                "    from prompt_tester import Model, Provider\n\n"
                "    prompt_tester.configure(\n"
                "        judge_model    = Model.GEMINI_2_5_FLASH,\n"
                "        judge_provider = Provider.GOOGLE,\n"
                "    )\n"
            )

        key = f"{cfg.judge_provider}:{cfg.judge_model}"
        if key not in _judges:
            from prompt_tester.judge import Judge
            _judges[key] = Judge(
                provider      = _get_provider(cfg.judge_provider),
                model         = cfg.judge_model,
                provider_name = cfg.judge_provider,
            )
    return _judges[key]


def prompt_run(
    *,
    target_prompt:    str,
    subject_model:    "Model | str",
    subject_provider: "Provider | str",
    template_vars:    dict | None = None,
    max_tokens:       int         = 2048,
    run_fn:           "Callable[[str, str, int], CompletionResult] | None" = None,
    runs:             int         = 1,
    pass_threshold:   float       = 1.0,
) -> Callable:
    """
    Decorator that runs a prompt and injects a PromptRun into the test function.

    Requires ``prompt_tester.configure()`` to be called first to set the judge.

    Parameters
    ----------
    target_prompt : str
        The prompt text to send to the model. Use ``{key}`` placeholders for
        values supplied via ``template_vars``.
    subject_model : Model | str
        The model to run the prompt against.
    subject_provider : Provider | str
        The provider for ``subject_model``: ``Provider.ANTHROPIC`` or ``Provider.GOOGLE``.
    template_vars : dict | None
        Values substituted into ``{key}`` placeholders in ``target_prompt``.
    max_tokens : int
        Maximum output tokens for the prompt call (default 2048).
    run_fn : callable | None
        Optional custom executor. When provided, replaces the built-in
        ``provider.complete()`` call entirely.

        Signature: ``(prompt: str, model: str, max_tokens: int) -> CompletionResult``

        Use this for prompts that require tool use, MCP calls, or any
        multi-turn agentic loop. Your function receives the rendered prompt and
        is responsible for running the full loop — including tool round-trips —
        and returning a single ``CompletionResult`` whose ``text`` field holds
        the final model output. The judge then evaluates that output via
        ``run.ask()`` / ``run.ask_all()`` as normal.

        ``subject_model`` and ``subject_provider`` are still recorded on the
        ``PromptRun`` for metadata, but the actual execution goes through
        ``run_fn``.
    runs : int
        Number of times to run the prompt (default 1). When greater than 1,
        each run executes in its own thread and the test passes if at least
        ``ceil(runs * pass_threshold)`` runs succeed.
    pass_threshold : float
        Fraction of runs that must pass (default 1.0 — all runs). Only
        meaningful when ``runs > 1``. For example, ``runs=5,
        pass_threshold=0.8`` requires 4 out of 5 runs to pass.
    """
    if runs < 1:
        raise ValueError(f"runs must be >= 1, got {runs}")
    if not (0.0 < pass_threshold <= 1.0):
        raise ValueError(f"pass_threshold must be in (0.0, 1.0], got {pass_threshold}")

    def decorator(fn: Callable) -> Callable:

        def _execute() -> "PromptRun":
            """Execute the prompt once and return a populated PromptRun."""
            from prompt_tester.models import PromptRun
            from prompt_tester.config import compute_cost

            _model    = subject_model.value    if hasattr(subject_model,    "value") else subject_model
            _provider = subject_provider.value if hasattr(subject_provider, "value") else subject_provider

            _vars    = template_vars or {}
            rendered = render_prompt(target_prompt, _vars, _stacklevel=4)

            if run_fn is not None:
                result = run_fn(rendered, _model, max_tokens)
                if not isinstance(result, CompletionResult):
                    raise TypeError(
                        f"run_fn must return a CompletionResult, got {type(result).__name__}. "
                        "Import it with: from prompt_tester import CompletionResult"
                    )
            else:
                llm_provider = _get_provider(_provider)
                result = llm_provider.complete(
                    model      = _model,
                    prompt     = rendered,
                    max_tokens = max_tokens,
                )

            cost = compute_cost(
                _model,
                result.input_tokens,
                result.output_tokens,
                cached_input_tokens   = result.cached_input_tokens,
                cache_creation_tokens = result.cache_creation_tokens,
            )

            run = PromptRun(
                prompt                = rendered,
                template_vars         = _vars,
                output                = result.text,
                model                 = _model,
                provider              = _provider,
                model_used            = result.model_used,
                model_version         = result.model_version,
                request_id            = result.request_id,
                stop_reason           = result.stop_reason,
                safety_filtered       = result.safety_filtered,
                input_tokens          = result.input_tokens,
                output_tokens         = result.output_tokens,
                cached_input_tokens   = result.cached_input_tokens,
                cache_creation_tokens = result.cache_creation_tokens,
                thoughts_tokens       = result.thoughts_tokens,
                cost_usd              = cost,
            )
            run._judge = _get_judge()
            return run

        if runs == 1:
            # Single run — inject PromptRun as first arg, pass remaining args
            # through so pytest.mark.parametrize works as normal.
            orig_params  = list(inspect.signature(fn).parameters.values())
            extra_params = orig_params[1:]  # drop 'run'
            wrapper_sig  = inspect.signature(fn).replace(parameters=extra_params)

            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                run = _execute()
                return fn(run, *args, **kwargs)

            wrapper.__signature__ = wrapper_sig
            return wrapper

        else:
            # Multi-run — each run gets its own thread; pass rate is asserted
            # after all threads complete. pytest.mark.parametrize is not needed.
            min_pass = math.ceil(runs * pass_threshold)

            @functools.wraps(fn)
            def wrapper():
                def _single_run(run_idx: int) -> tuple[bool, str | None]:
                    run = _execute()
                    try:
                        fn(run)
                        return True, None
                    except Exception as exc:
                        return False, str(exc)

                with ThreadPoolExecutor(max_workers=runs) as pool:
                    futures = {pool.submit(_single_run, i): i for i in range(runs)}
                    results: list[tuple[bool, str | None]] = [None] * runs  # type: ignore[list-item]
                    for future in as_completed(futures):
                        results[futures[future]] = future.result()

                pass_count = sum(1 for passed, _ in results if passed)
                for i, (passed, msg) in enumerate(results):
                    if not passed:
                        print(f"[run {i + 1}/{runs}] FAILED: {msg}")

                assert pass_count >= min_pass, (
                    f"{pass_count}/{runs} runs passed "
                    f"(need {min_pass}, threshold={pass_threshold:.0%})"
                )

            wrapper.__signature__ = inspect.Signature()
            return wrapper

    return decorator
