from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from enum import Enum
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, Field, PrivateAttr, model_validator

if TYPE_CHECKING:
    from prompt_tester.judge import Judge


# ---------------------------------------------------------------------------
# Internal types used by Judge
# ---------------------------------------------------------------------------

class AssertionType(str, Enum):
    RESPONSE = "response"


class Assertion(BaseModel):
    type:     AssertionType
    question: str | None = None

    @model_validator(mode="after")
    def _check_fields(self) -> "Assertion":
        if self.type == AssertionType.RESPONSE and not self.question:
            raise ValueError("response assertion requires 'question'")
        return self


class UsageMetrics(BaseModel):
    """Token usage and cost for a single API call."""
    input_tokens:  int
    output_tokens: int
    cost_usd:      float | None  # None when the model is not in the price table


class AssertionResult(BaseModel):
    assertion: Assertion
    passed:    bool
    snippet:   str | None          = None
    reasoning: str | None          = None
    usage:     UsageMetrics | None = None


# ---------------------------------------------------------------------------
# Decorator-based API — PromptRun + JudgeVerdict
# ---------------------------------------------------------------------------

class JudgeVerdict(BaseModel):
    """
    Result of a single judge evaluation — one yes/no question about a model response.

    Returned by ``PromptRun.ask(question)`` (one API call) and by each element
    of ``PromptRun.ask_all(questions)`` (one shared API call for all questions).

    The ``passed`` field is the primary assertion target. ``snippet`` and
    ``reasoning`` give you the judge's evidence and logic, which are most useful
    as failure messages::

        verdict = run.ask("Is Alice mentioned?")
        assert verdict.passed, verdict.reasoning

    All fields are serialisable via ``to_dict()``.
    """
    question:  str
    answer:    Literal["yes", "no"]
    passed:    bool
    snippet:   str | None = None
    reasoning: str | None = None

    judge_model:    str
    judge_provider: str | None = None

    judge_input_tokens:  int          = 0
    judge_output_tokens: int          = 0
    judge_cost_usd:      float | None = None

    def to_dict(self) -> dict:
        return self.model_dump()


class PromptRun(BaseModel):
    """
    Full result of a single ``@prompt_run`` execution.

    Injected into the decorated test function by the ``@prompt_run`` decorator.
    Use ``run.output`` for the raw response text. Use ``run.ask(question)`` or
    ``run.ask_all(questions)`` to evaluate the response with the judge.

    All fields are serialisable via ``to_dict()``. The internal ``_judge``
    reference is excluded from serialisation.
    """
    prompt:        str
    template_vars: dict[str, Any] = Field(default_factory=dict)

    output: str

    model:    str
    provider: str

    model_used:            str | None = None
    model_version:         str | None = None
    request_id:            str | None = None
    stop_reason:           str | None = None
    safety_filtered:       bool       = False

    input_tokens:          int = 0
    output_tokens:         int = 0
    cached_input_tokens:   int = 0
    cache_creation_tokens: int = 0
    thoughts_tokens:       int = 0

    cost_usd: float | None = None

    _judge: "Judge | None" = PrivateAttr(default=None)

    def ask(self, question: str) -> JudgeVerdict:
        """Ask the judge a single yes/no question — one API call."""
        if self._judge is None:
            raise RuntimeError(
                "No judge available — PromptRun was not created via @prompt_run"
            )
        assertion = Assertion(type=AssertionType.RESPONSE, question=question)
        ar = self._judge.evaluate(self.output, assertion)
        return JudgeVerdict(
            question            = question,
            answer              = "yes" if ar.passed else "no",
            passed              = ar.passed,
            snippet             = ar.snippet,
            reasoning           = ar.reasoning,
            judge_model         = self._judge._model,
            judge_provider      = self._judge._provider_name,
            judge_input_tokens  = ar.usage.input_tokens  if ar.usage else 0,
            judge_output_tokens = ar.usage.output_tokens if ar.usage else 0,
            judge_cost_usd      = ar.usage.cost_usd      if ar.usage else None,
        )

    def ask_all(self, questions: list[str]) -> list[JudgeVerdict]:
        """
        Ask the judge multiple yes/no questions in a single API call.

        More efficient than calling ask() repeatedly. Tokens are split evenly
        across verdicts so cost totals remain accurate.
        Returns an empty list immediately when ``questions`` is empty.
        """
        if self._judge is None:
            raise RuntimeError(
                "No judge available — PromptRun was not created via @prompt_run"
            )
        if not questions:
            return []
        assertions = [
            Assertion(type=AssertionType.RESPONSE, question=q) for q in questions
        ]
        results = self._judge.evaluate_all(self.output, assertions)
        return [
            JudgeVerdict(
                question            = q,
                answer              = "yes" if ar.passed else "no",
                passed              = ar.passed,
                snippet             = ar.snippet,
                reasoning           = ar.reasoning,
                judge_model         = self._judge._model,
                judge_provider      = self._judge._provider_name,
                judge_input_tokens  = ar.usage.input_tokens  if ar.usage else 0,
                judge_output_tokens = ar.usage.output_tokens if ar.usage else 0,
                judge_cost_usd      = ar.usage.cost_usd      if ar.usage else None,
            )
            for q, ar in zip(questions, results)
        ]

    def ask_parallel(self, questions: list[str]) -> list[JudgeVerdict]:
        """
        Ask multiple yes/no questions in parallel — one API call per question,
        fired concurrently via a thread pool.

        Results are returned in the same order as ``questions``.
        Returns an empty list immediately when ``questions`` is empty.

        Compared to ``ask_all()``:

        * No cross-contamination risk — each question is evaluated independently.
        * Higher total token cost — N questions = N API calls.
        * Lower wall-clock time than calling ``ask()`` N times sequentially.

        If any individual API call raises, the exception propagates after all
        in-flight calls finish (the thread pool waits for them to land). Results
        for already-completed questions are discarded.
        """
        if self._judge is None:
            raise RuntimeError(
                "No judge available — PromptRun was not created via @prompt_run"
            )
        if not questions:
            return []
        with ThreadPoolExecutor() as pool:
            futures = {pool.submit(self.ask, q): i for i, q in enumerate(questions)}
            results: list[JudgeVerdict] = [None] * len(questions)  # type: ignore[list-item]
            errors: list[tuple[int, BaseException]] = []
            for future in as_completed(futures):
                idx = futures[future]
                exc = future.exception()
                if exc is not None:
                    errors.append((idx, exc))
                else:
                    results[idx] = future.result()

        if errors:
            lines = [
                f"  [{i + 1}] {questions[i]!r}: {exc}"
                for i, exc in sorted(errors)
            ]
            raise RuntimeError(
                f"{len(errors)}/{len(questions)} judge call(s) failed:\n" + "\n".join(lines)
            )
        return results

    def to_dict(self) -> dict:
        """Return all fields as a plain dict. The private ``_judge`` is excluded."""
        return self.model_dump()
