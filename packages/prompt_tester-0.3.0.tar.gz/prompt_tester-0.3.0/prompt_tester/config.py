from __future__ import annotations

import threading
from dataclasses import dataclass
from enum import Enum


class Provider(str, Enum):
    ANTHROPIC = "anthropic"
    GOOGLE    = "google"


class Model(str, Enum):
    # Anthropic — Claude
    CLAUDE_HAIKU_4_5  = "claude-haiku-4-5-20251001"
    CLAUDE_SONNET_4_6 = "claude-sonnet-4-6"
    CLAUDE_OPUS_4_7   = "claude-opus-4-7"
    # Google — Gemini
    GEMINI_2_5_FLASH      = "gemini-2.5-flash"
    GEMINI_2_5_PRO        = "gemini-2.5-pro"
    GEMINI_2_0_FLASH      = "gemini-2.0-flash"
    GEMINI_2_0_FLASH_LITE = "gemini-2.0-flash-lite"
    GEMINI_3_1_FLASH_LITE     = "gemini-3.1-flash-lite"


# USD per million tokens: (input, output)
_PRICES: dict[Model, tuple[float, float]] = {
    Model.CLAUDE_HAIKU_4_5:       ( 0.80,   4.00),
    Model.CLAUDE_SONNET_4_6:      ( 3.00,  15.00),
    Model.CLAUDE_OPUS_4_7:        (15.00,  75.00),
    Model.GEMINI_2_5_FLASH:       ( 0.15,   0.60),
    Model.GEMINI_2_5_PRO:         ( 1.25,  10.00),
    Model.GEMINI_2_0_FLASH:       ( 0.10,   0.40),
    Model.GEMINI_2_0_FLASH_LITE:  ( 0.075,  0.30),
    Model.GEMINI_3_1_FLASH_LITE:      ( 0.25,   1.50),
}


def compute_cost(
    model:                 Model | str,
    input_tokens:          int,
    output_tokens:         int,
    cached_input_tokens:   int = 0,
    cache_creation_tokens: int = 0,
) -> float | None:
    """
    Return USD cost for a single API call, or None if the model is not in the
    price table.

    Cached token pricing (Anthropic prompt caching):
      cache reads    — 10%  of the normal input rate
      cache creation — 125% of the normal input rate
    Gemini context caching uses a similar read discount; we apply the same
    10% approximation when cached_input_tokens is non-zero.
    """
    price = _PRICES.get(model)
    if price is None:
        return None
    if cached_input_tokens > input_tokens:
        raise ValueError(
            f"cached_input_tokens ({cached_input_tokens}) cannot exceed "
            f"input_tokens ({input_tokens})"
        )
    input_price, output_price = price
    regular_input = input_tokens - cached_input_tokens
    return (
        regular_input            * input_price
        + cached_input_tokens    * input_price * 0.10
        + cache_creation_tokens  * input_price * 1.25
        + output_tokens          * output_price
    ) / 1_000_000


class ConfigurationError(Exception):
    """Raised when prompt_tester.configure() has not been called before use."""


@dataclass
class _Config:
    judge_model:    str | None = None
    judge_provider: str | None = None


_config      = _Config()
_config_lock = threading.Lock()


def configure(
    *,
    judge_model:    Model | str,
    judge_provider: Provider | str,
) -> None:
    """
    Set the judge model. Must be called before using ``@prompt_run``.

    Both parameters are required::

        import prompt_tester
        from prompt_tester import Model, Provider

        prompt_tester.configure(
            judge_model    = Model.GEMINI_2_5_FLASH,
            judge_provider = Provider.GOOGLE,
        )

    Plain strings are also accepted.
    """
    model    = judge_model.value    if isinstance(judge_model,    Enum) else judge_model
    provider = judge_provider.value if isinstance(judge_provider, Enum) else judge_provider
    with _config_lock:
        _config.judge_model    = model
        _config.judge_provider = provider


def reset() -> None:
    """Clear configuration. After calling this, ``configure()`` must be called again before use."""
    with _config_lock:
        _config.judge_model    = None
        _config.judge_provider = None
    from prompt_tester.decorator import clear_caches
    clear_caches()


def get_config() -> _Config:
    with _config_lock:
        return _Config(
            judge_model    = _config.judge_model,
            judge_provider = _config.judge_provider,
        )
