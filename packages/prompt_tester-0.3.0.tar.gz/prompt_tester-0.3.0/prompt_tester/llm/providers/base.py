from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class CompletionResult:
    """
    Unified return type for all LLM provider calls.

    Common fields are populated by every provider.
    Provider-specific fields default to None / 0 / False when not applicable.

    Field coverage by provider
    --------------------------
    field                  anthropic                          google
    ---------------------  ---------------------------------  ----------------------------------
    text                   response text                      response text
    input_tokens           usage.input_tokens                 usage_metadata.prompt_token_count
    output_tokens          usage.output_tokens                usage_metadata.candidates_token_count
    stop_reason            "end_turn"|"max_tokens"|           "STOP"|"MAX_TOKENS"|"SAFETY"|
                           "stop_sequence"|"tool_use"         "RECITATION"|"OTHER"
    model_used             response.model (actual)            model as requested
    model_version          —                                  response.model_version
    request_id             response.id                        response.response_id
    provider               "anthropic"                        "google"
    cached_input_tokens    usage.cache_read_input_tokens      usage_metadata.cached_content_token_count
    cache_creation_tokens  usage.cache_creation_input_tokens  —
    thoughts_tokens        —                                  usage_metadata.thoughts_token_count
    safety_filtered        —                                  True when finish_reason == SAFETY
    """

    # ------------------------------------------------------------------ core
    text:          str
    input_tokens:  int
    output_tokens: int

    # ---------------------------------------------------- stop / finish reason
    # Anthropic: "end_turn" | "max_tokens" | "stop_sequence" | "tool_use"
    # Gemini:    "STOP" | "MAX_TOKENS" | "SAFETY" | "RECITATION" | "OTHER"
    stop_reason: str | None = None

    # --------------------------------------------------------- model identity
    # Actual model that served the request (may differ from what was requested)
    model_used:    str | None = None
    # Provider's fine-grained version string (Gemini: modelVersion)
    model_version: str | None = None

    # -------------------------------------------------------------- tracing
    # Provider's own response / request ID for log correlation
    request_id: str | None = None
    # Which provider produced this result
    provider:   str | None = None

    # --------------------------------------------------------------- caching
    # Tokens read from an existing cache entry
    # Anthropic: usage.cache_read_input_tokens
    # Gemini:    usage_metadata.cached_content_token_count
    cached_input_tokens: int = 0

    # Tokens spent writing a new cache entry (Anthropic only)
    # Anthropic: usage.cache_creation_input_tokens
    cache_creation_tokens: int = 0

    # --------------------------------------------------- extended thinking
    # Reasoning / thinking tokens consumed before the final answer
    # Gemini: usage_metadata.thoughts_token_count
    # Anthropic extended thinking: counted in output_tokens
    thoughts_tokens: int = 0

    # --------------------------------------------------------------- safety
    # True when the provider blocked or filtered the response for safety reasons
    # Gemini: finish_reason == SAFETY or prompt blocked
    # Anthropic: not currently exposed at response level
    safety_filtered: bool = False


class LLMProvider(ABC):
    """
    Abstract base for LLM providers.

    Adding a new provider:
      1. Create ``llm/providers/<name>.py`` with a class that subclasses ``LLMProvider``.
      2. Implement ``complete()``.
      3. Add a branch for it in ``decorator._get_provider()``.
    """

    @abstractmethod
    def complete(
        self,
        model:      str,
        prompt:     str,
        *,
        system:     str | None = None,
        max_tokens: int        = 4096,
    ) -> CompletionResult:
        """
        Call the model with a fully-rendered prompt and return the result.

        Parameters
        ----------
        model : str
            Model identifier as understood by this provider.
        prompt : str
            Fully-rendered prompt (all {placeholders} already substituted).
        system : str | None
            Optional system prompt.
        max_tokens : int
            Maximum tokens to generate.
        """
