from __future__ import annotations

import logging
import time

import anthropic

from .base import CompletionResult, LLMProvider

_log = logging.getLogger(__name__)

_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0  # seconds; doubles each attempt (1s, 2s, 4s)


class AnthropicProvider(LLMProvider):
    """Calls Claude models via the Anthropic SDK."""

    def __init__(self) -> None:
        self._client = anthropic.Anthropic()

    def complete(
        self,
        model:      str,
        prompt:     str,
        *,
        system:     str | None = None,
        max_tokens: int        = 4096,
    ) -> CompletionResult:
        kwargs: dict = dict(
            model      = model,
            max_tokens = max_tokens,
            messages   = [{"role": "user", "content": prompt}],
        )
        if system:
            kwargs["system"] = system

        response = None
        for attempt in range(_MAX_RETRIES):
            try:
                response = self._client.messages.create(**kwargs)
                break
            except (anthropic.InternalServerError, anthropic.RateLimitError) as exc:
                if attempt < _MAX_RETRIES - 1:
                    delay = _RETRY_BASE_DELAY * (2 ** attempt)
                    _log.warning("Anthropic %s (attempt %d/%d): %s — retrying in %.1fs",
                                 type(exc).__name__, attempt + 1, _MAX_RETRIES, exc, delay)
                    time.sleep(delay)
                else:
                    raise

        text = "".join(
            block.text for block in response.content if hasattr(block, "text")
        )

        usage = response.usage
        cached_input    = getattr(usage, "cache_read_input_tokens",    None) or 0
        cache_creation  = getattr(usage, "cache_creation_input_tokens", None) or 0

        return CompletionResult(
            text                  = text,
            input_tokens          = usage.input_tokens,
            output_tokens         = usage.output_tokens,
            stop_reason           = response.stop_reason,
            model_used            = response.model,
            request_id            = response.id,
            provider              = "anthropic",
            cached_input_tokens   = cached_input,
            cache_creation_tokens = cache_creation,
        )
