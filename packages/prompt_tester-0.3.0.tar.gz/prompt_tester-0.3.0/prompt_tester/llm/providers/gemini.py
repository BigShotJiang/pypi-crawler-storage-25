from __future__ import annotations

import logging
import time

from google import genai
from google.genai import errors, types
from google.genai.types import FinishReason

from .base import CompletionResult, LLMProvider

_log = logging.getLogger(__name__)

_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0  # seconds; doubles each attempt (1s, 2s, 4s)


class GeminiProvider(LLMProvider):
    """Calls Gemini models via the Google GenAI SDK (GOOGLE_API_KEY env var)."""

    def __init__(self) -> None:
        self._client = genai.Client()

    def complete(
        self,
        model:      str,
        prompt:     str,
        *,
        system:     str | None = None,
        max_tokens: int        = 4096,
    ) -> CompletionResult:
        config_kwargs: dict = {"max_output_tokens": max_tokens}
        if system:
            config_kwargs["system_instruction"] = system

        response = None
        for attempt in range(_MAX_RETRIES):
            try:
                response = self._client.models.generate_content(
                    model    = model,
                    contents = prompt,
                    config   = types.GenerateContentConfig(**config_kwargs),
                )
                break
            except (errors.ServerError, errors.ClientError) as exc:
                # Retry on 5xx (ServerError) and 429 rate-limit (ClientError with code 429).
                if isinstance(exc, errors.ClientError) and getattr(exc, "code", None) != 429:
                    raise
                if attempt < _MAX_RETRIES - 1:
                    delay = _RETRY_BASE_DELAY * (2 ** attempt)
                    _log.warning("Gemini %s (attempt %d/%d): %s — retrying in %.1fs",
                                 type(exc).__name__, attempt + 1, _MAX_RETRIES, exc, delay)
                    time.sleep(delay)
                else:
                    raise

        usage     = response.usage_metadata
        candidate = response.candidates[0] if response.candidates else None

        if candidate is not None:
            finish_reason   = candidate.finish_reason.name
            safety_filtered = candidate.finish_reason == FinishReason.SAFETY
        else:
            # No candidates — prompt was blocked before generation started.
            feedback        = getattr(response, "prompt_feedback", None)
            block_reason    = getattr(feedback, "block_reason", None)
            finish_reason   = "BLOCKED" if block_reason else None
            safety_filtered = block_reason is not None

        try:
            text = response.text or ""
        except Exception:
            text = ""

        return CompletionResult(
            text                  = text,
            input_tokens          = usage.prompt_token_count          or 0,
            output_tokens         = usage.candidates_token_count      or 0,
            stop_reason           = finish_reason,
            model_used            = model,
            model_version         = getattr(response, "model_version", None),
            request_id            = getattr(response, "response_id",   None),
            provider              = "google",
            cached_input_tokens   = getattr(usage, "cached_content_token_count", None) or 0,
            thoughts_tokens       = getattr(usage, "thoughts_token_count",        None) or 0,
            safety_filtered       = safety_filtered,
        )
