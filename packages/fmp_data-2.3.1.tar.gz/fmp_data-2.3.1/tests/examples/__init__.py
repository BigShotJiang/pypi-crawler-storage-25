"""Tests for example files."""
