import json as json_mod
from pathlib import Path
from typing import Optional

import typer
from rich.panel import Panel
from rich.table import Table

from ..entities.agent import AgentRepository
from ..entities.evaluation import AgentEvaluationRepository, SessionEvaluationRepository, EvaluationRepository
from ..utils.agent_lock import load_agent_lock
from ..utils.config import (
    TITLE_STYLE,
    INFO_STYLE,
    ERROR_STYLE,
    ID_STYLE,
    SUCCESS_STYLE,
    WARNING_STYLE,
    NOT_AVAILABLE,
)
from ..utils.utils import console, print_table, print_json, should_output_json

app = typer.Typer(help="View evaluations and evaluation data.")


def print_section(title: str, items: list[tuple[str, str]]):
    """Print a section with key-value pairs."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style=INFO_STYLE, width=35)
    table.add_column("Value")

    for key, value in items:
        table.add_row(key, value)

    console.print(Panel(table, title=f"[{TITLE_STYLE}]{title}[/{TITLE_STYLE}]", border_style="dim"))


def _resolve_agent_id(agent: Optional[str]) -> tuple[str, Optional[str]]:
    """Resolve agent ID from argument or agent.lock. Returns (agent_id, agent_name)."""
    if agent:
        agent_repo = AgentRepository()
        agent_entity = agent_repo.get_by_name_or_id(agent)
        if not agent_entity:
            console.print(f"[{ERROR_STYLE}]Agent not found: {agent}[/{ERROR_STYLE}]")
            raise typer.Exit(1)
        return agent_entity.id, agent_entity.name

    voicerun_dir = Path.cwd() / ".voicerun"
    if voicerun_dir.exists():
        lock_data = load_agent_lock(voicerun_dir)
        if lock_data and "id" in lock_data:
            agent_id = lock_data["id"]
            agent_repo = AgentRepository()
            agent_entity = agent_repo.get_by_id(agent_id)
            name = agent_entity.name if agent_entity else agent_id
            return agent_id, name

    console.print(f"[{ERROR_STYLE}]No agent specified. Use --agent or run from within a voicerun project directory.[/{ERROR_STYLE}]")
    raise typer.Exit(1)


@app.command("list")
def evaluation_list(
    agent: Optional[str] = typer.Argument(None, help="Agent name or ID (defaults to current project agent)"),
    session_id: Optional[str] = typer.Option(None, "--session", "-S", help="Session ID to get evaluations for"),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status (pending, complete, error)"),
    eval_type: Optional[str] = typer.Option(None, "--type", "-T", help="Filter by eval type (judge, extraction, script)"),
    limit: Optional[int] = typer.Option(None, "--limit", "-l", help="Limit number of results"),
    page: Optional[int] = typer.Option(None, "--page", "-p", help="Page number"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """List evaluations for an agent, or for a specific session."""
    agent_id, agent_name = _resolve_agent_id(agent)

    if session_id:
        repo = SessionEvaluationRepository(session_id)
        result = repo.get(page=page, limit=limit)
    else:
        filters = {}
        if status:
            filters["status"] = status
        if eval_type:
            filters["evalType"] = eval_type
        repo = AgentEvaluationRepository(agent_id)
        result = repo.get(filters if filters else None, page=page, limit=limit)

    if should_output_json(json_output, table_output):
        print_json({
            "data": [e.__dict__ for e in result.data],
            "metadata": {"page": result.page, "limit": result.limit, "total": result.total},
        })
        return

    if not result.data:
        console.print(f"[{INFO_STYLE}]No evaluations found.[/{INFO_STYLE}]")
        return

    headers = ["STATUS", "ID", "EVAL TYPE", "EVALUATOR ID", "SESSION ID", "SUCCESS", "CREATED AT"]
    rows = []
    for ev in result.data:
        success_str = NOT_AVAILABLE
        if ev.eval_type == "judge" and ev.success is not None:
            success_str = "Yes" if ev.success else "No"

        rows.append([
            ev.status or NOT_AVAILABLE,
            ev.id or NOT_AVAILABLE,
            ev.eval_type or NOT_AVAILABLE,
            ev.evaluator_id or NOT_AVAILABLE,
            ev.session_id or NOT_AVAILABLE,
            success_str,
            ev.created_at or NOT_AVAILABLE,
        ])
    print_table(headers, rows)

    if result.total is not None:
        start = (result.page - 1) * result.limit + 1
        end = min(result.page * result.limit, result.total)
        console.print(f"\n[{INFO_STYLE}]Showing {start}-{end} of {result.total} (page {result.page} of {result.total_pages})[/{INFO_STYLE}]")
        if result.has_more:
            console.print(f"[{INFO_STYLE}]Use --page {result.page + 1} to see more[/{INFO_STYLE}]")


@app.command("info")
def evaluation_info(
    evaluation_id: str = typer.Argument(help="Evaluation ID"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as rich format (default for interactive terminals)"),
):
    """Show detailed information about an evaluation."""
    repo = EvaluationRepository()
    evaluation = repo.get_by_id(evaluation_id)

    if not evaluation:
        console.print(f"[{ERROR_STYLE}]Evaluation not found: {evaluation_id}[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    if should_output_json(json_output, table_output):
        print_json(evaluation.__dict__)
        return

    console.print()
    console.print(f"[{TITLE_STYLE}]Evaluation: {evaluation.id}[/{TITLE_STYLE}]")
    console.print()

    print_section("Evaluation Info", [
        ("ID", f"[{ID_STYLE}]{evaluation.id}[/{ID_STYLE}]"),
        ("Status", evaluation.status or NOT_AVAILABLE),
        ("Eval Type", evaluation.eval_type or NOT_AVAILABLE),
        ("Trigger", evaluation.trigger or NOT_AVAILABLE),
        ("Evaluator ID", evaluation.evaluator_id or NOT_AVAILABLE),
        ("Session ID", evaluation.session_id or NOT_AVAILABLE),
        ("Model", evaluation.model or NOT_AVAILABLE),
    ])

    if evaluation.eval_type == "judge":
        success_str = NOT_AVAILABLE
        if evaluation.success is not None:
            success_str = f"[{SUCCESS_STYLE}]Yes[/{SUCCESS_STYLE}]" if evaluation.success else f"[{WARNING_STYLE}]No[/{WARNING_STYLE}]"
        items = [("Success", success_str)]
        if evaluation.ruling is not None:
            items.append(("Ruling", json_mod.dumps(evaluation.ruling, indent=2, default=str)))
        if evaluation.success_criteria is not None:
            items.append(("Success Criteria", json_mod.dumps(evaluation.success_criteria, indent=2, default=str)))
        print_section("Judge Result", items)

    if evaluation.eval_type == "extraction":
        items = []
        if evaluation.extraction is not None:
            items.append(("Extraction", json_mod.dumps(evaluation.extraction, indent=2, default=str)))
        if items:
            print_section("Extraction Result", items)

    if evaluation.error_message:
        print_section("Error", [
            ("Error Message", evaluation.error_message),
        ])

    print_section("Usage", [
        ("Prompt Tokens", str(evaluation.prompt_tokens or 0)),
        ("Completion Tokens", str(evaluation.completion_tokens or 0)),
    ])

    print_section("Timestamps", [
        ("Created At", evaluation.created_at or NOT_AVAILABLE),
        ("Updated At", evaluation.updated_at or NOT_AVAILABLE),
    ])


if __name__ == "__main__":
    app()
