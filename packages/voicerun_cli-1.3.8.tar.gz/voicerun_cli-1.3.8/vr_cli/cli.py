from importlib.metadata import version

import typer

from .commands.auth import signin, signout


def version_callback(value: bool):
    if value:
        print(f"vr {version('voicerun-cli')}")
        raise typer.Exit()


def update_callback(value: bool):
    if value:
        run_update()
        raise typer.Exit()

from .commands.context import app as context_app
from .commands.create import app as create_app
from .commands.debug import debug
from .commands.delete import app as delete_app
from .commands.deploy import deploy
from .commands.describe import app as describe_app
from .commands.get import app as get_app
from .commands.evaluation import app as evaluation_app
from .commands.session import app as session_app
from .commands.docs import app as docs_app
from .commands.usage import app as usage_app
from .commands.init import init
from .commands.validate import validate
from .commands.pull import pull
from .commands.push import push
from .commands.render import render
from .commands.open import open_cmd
from .commands.setup import setup
from .commands.test import test
from .commands.update import run_update

app = typer.Typer(
    help="VoiceRun CLI to interact with the VoiceRun API.",
    add_completion=True,
)


@app.callback()
def main(
    version: bool = typer.Option(
        False, "--version", "-V", "-v", callback=version_callback, is_eager=True,
        help="Show the CLI version and exit.",
    ),
    update: bool = typer.Option(
        False, "--update", "-U", callback=update_callback, is_eager=True,
        help="Update the CLI to the latest version and refresh skills/MCP.",
    ),
):
    """VoiceRun CLI to interact with the VoiceRun API."""

# Register subcommands
app.add_typer(context_app, name="context", help="Manage API context for different environments.")
app.add_typer(create_app, name="create", help="Create resources.")
app.add_typer(delete_app, name="delete", help="Delete resources.")
app.add_typer(get_app, name="get", help="List resources by type.")
app.add_typer(describe_app, name="describe", help="Show detailed information about a resource.")
app.add_typer(evaluation_app, name="evaluation", help="View evaluations and evaluation data.")
app.add_typer(session_app, name="session", help="View sessions and session data.")
app.add_typer(docs_app, name="docs", help="Browse and search VoiceRun documentation.")
app.add_typer(usage_app, name="usage", help="View usage reports and billing data.")

# Register standalone commands
app.command("setup")(setup)
app.command("signin")(signin)
app.command("signout")(signout)
app.command("init")(init)
app.command("validate")(validate)
app.command("pull")(pull)
app.command("push")(push)
app.command("deploy")(deploy)
app.command("render")(render)
app.command("open")(open_cmd)
app.command("test")(test)
app.command("debug")(debug)

if __name__ == "__main__":
    app()
