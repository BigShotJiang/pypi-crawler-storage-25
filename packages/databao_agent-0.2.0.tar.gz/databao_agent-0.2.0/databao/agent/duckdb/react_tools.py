import json
import logging
from typing import Any

import pandas as pd
from duckdb import DuckDBPyConnection
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools import tool
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent
from pydantic import BaseModel

from databao.agent.core import Domain
from databao.agent.duckdb.schema_inspection import inspect_duckdb_schema, summarize_duckdb_schema
from databao.agent.executors.langchain_tools import make_search_context_tool

_LOGGER = logging.getLogger(__name__)


class AgentResponse(BaseModel):
    """Response model for ReAct DuckDB agent."""

    sql: str
    explanation: str


def execute_duckdb_sql(sql: str, con: DuckDBPyConnection, *, limit: int | None = None) -> pd.DataFrame:
    # Use duckdb's Relation API to inject a LIMIT clause
    rel = con.sql(sql)  # A lazy Relation

    # TODO Do we want to forbid non-SELECT statements?
    # Non-Select queries (CREATE TABLE, etc.) are executed immediately and return None
    if rel is None:
        return pd.DataFrame()

    if limit is not None:
        rel = rel.limit(limit)
    return rel.df()  # Execute and return DataFrame


def describe_duckdb_schema(con: DuckDBPyConnection, max_cols_per_table: int | None = None) -> str:
    """Return a compact textual description of tables and columns in DuckDB.

    Args:
        con: An open DuckDB connection.
        max_cols_per_table: Truncate column lists longer than this.
    """
    try:
        tables = inspect_duckdb_schema(con)
    except Exception as e:
        _LOGGER.warning(f"Failed to fetch schema: {e}")
        return "(failed to fetch schema)"
    db_schema = summarize_duckdb_schema(tables, max_cols_per_table, include_original_catalog_name=False)
    if len(db_schema) > 0:
        return db_schema
    return "(no tables found)"


def make_duckdb_tool(con: DuckDBPyConnection) -> Any:
    """
    Create a DuckDB SQL execution tool for LangChain executors.

    Args:
        con: DuckDB connection to execute queries against.

    Returns:
        A LangChain tool that executes SQL queries.
    """

    @tool("execute_sql")
    def execute_sql(sql: str, limit: int = 10) -> str:
        """
        Execute any SQL against DuckDB.

        Args:
            sql: The SQL statement to execute (single statement).
            limit: Optional row cap for result-returning statements (10 by default).

        Returns:
            JSON string: { "columns": [...], "rows": str, "limit": int, "note": str }
        """
        try:
            df = execute_duckdb_sql(sql, con, limit=limit)
            payload = {
                "columns": list(df.columns),
                "rows": df.to_string(index=False),
                "limit": limit,
                "note": "Query executed successfully",
            }
            return json.dumps(payload)
        except Exception as e:
            payload = {
                "columns": [],
                "rows": [],
                "limit": limit,
                "note": f"SQL error: {type(e).__name__}: {e}",
            }
            return json.dumps(payload)

    return execute_sql


def make_react_duckdb_agent(
    con: DuckDBPyConnection,
    llm: BaseChatModel,
    domain: Domain,
    extra_tools: list[Any] | None = None,
) -> CompiledStateGraph[Any]:
    """
    Create a ReAct agent configured to work with DuckDB.

    Args:
        con: DuckDB connection to execute queries against.
        llm: Language model to use for the agent.
        domain: Domain with schema and context.
        extra_tools: Optional additional tools (e.g. from MCP servers).

    Returns:
        A compiled LangGraph ReAct agent.
    """
    schema_text = describe_duckdb_schema(con)
    # TODO move to .jinja (and fix indendation)
    SYSTEM_PROMPT = f"""You are a careful data analyst using the ReAct pattern with tools.
    Use the `execute_sql` tool to run exactly one DuckDB SQL statement when needed.

    Guidelines:
    - Translate the NL question to ONE DuckDB SQL statement.
    - Use provided schema.
    - You can fetch extra details about schema/tables/columns if needed using SQL queries.
    - After running, write a concise, user-friendly explanation.
    - Do NOT write any tables/lists to the output.
    - Always include the exact SQL you ran.
    - Always use the full table name in query with db name and schema name.

    Available schema:
    {schema_text}
    """

    execute_sql_tool = make_duckdb_tool(con)
    tools = [execute_sql_tool]
    search_context_tool = make_search_context_tool(domain)
    if search_context_tool is not None:
        tools.append(search_context_tool)
    if extra_tools:
        tools.extend(extra_tools)

    # LangGraph prebuilt ReAct agent
    agent = create_react_agent(
        llm,
        tools=tools,
        prompt=SYSTEM_PROMPT,
        response_format=AgentResponse,
    )
    return agent
