from importlib.metadata import PackageNotFoundError, version

from . import utils, primitive
from .basics import CNOTEquivCliffordGate, fSwapEquivCliffordGate
from .compiler import compile_hamiltonian_simulation, optimize_phoenix_circuit_by_qiskit
from .hamiltonian import Hamiltonian

try:
    __version__ = version("phoenix-quantum")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = [
    "__version__",
    "Hamiltonian",
    "compile_hamiltonian_simulation",
    "optimize_phoenix_circuit_by_qiskit",
    "CNOTEquivCliffordGate",
    'fSwapEquivCliffordGate',
]
