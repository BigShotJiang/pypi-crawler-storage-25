"""Oris SDK exception hierarchy.

All exceptions carry structured error data from the API response when
available. The hierarchy is designed for precise catch patterns:

    try:
        agent.pay(...)
    except OrisPaymentError as e:
        # Payment-specific handling (policy violation, insufficient balance)
    except OrisAuthError as e:
        # Re-authenticate or rotate keys
    except OrisRateLimitError as e:
        # Back off, retry after e.retry_after seconds
    except OrisNetworkError as e:
        # Connection failure, timeout
    except OrisError as e:
        # Catch-all for any Oris error
"""

from __future__ import annotations


class OrisError(Exception):
    """Base exception for all Oris SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        error_code: str | None = None,
        request_id: str | None = None,
        details: dict | None = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        self.request_id = request_id
        self.details = details or {}
        super().__init__(message)

    def __repr__(self) -> str:
        parts = [f"OrisError({self.message!r}"]
        if self.status_code:
            parts.append(f"status={self.status_code}")
        if self.error_code:
            parts.append(f"code={self.error_code!r}")
        return ", ".join(parts) + ")"


class OrisAuthError(OrisError):
    """Authentication or authorization failure (HTTP 401, 403)."""
    pass


class OrisRateLimitError(OrisError):
    """Rate limit exceeded (HTTP 429).

    Attributes:
        retry_after: Seconds to wait before retrying.
    """

    def __init__(self, message: str, retry_after: int = 1, **kwargs) -> None:
        self.retry_after = retry_after
        super().__init__(message, **kwargs)


class OrisValidationError(OrisError):
    """Request validation failure (HTTP 422, 400)."""
    pass


class OrisPaymentError(OrisError):
    """Payment execution failure (policy violation, insufficient balance, compliance block)."""
    pass


class OrisNetworkError(OrisError):
    """Network-level failure (connection refused, timeout, DNS resolution)."""
    pass
