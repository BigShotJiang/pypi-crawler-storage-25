"""Marketplace resource: listings, orders, disputes, and reputation."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from oris.client import OrisClient


class MarketplaceResource:
    """Manage agent marketplace listings, orders, and reputation.

    Usage:
        listing = client.marketplace.create_listing(agent_id, "summarization", "...")
        results = client.marketplace.search_listings(capability="summarization")
        order = client.marketplace.place_order(buyer_id, listing.id)
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def acreate_listing(
        self,
        agent_id: str,
        capability: str,
        description: str,
        price: float,
        pricing_model: str = "per_call",
        capability_tags: list[str] | None = None,
        sla_response_time_ms: int | None = None,
        sla_uptime_percent: float | None = None,
    ) -> dict[str, Any]:
        """Create a marketplace listing for an agent capability (async)."""
        body: dict[str, Any] = {
            "agent_id": agent_id,
            "capability": capability,
            "description": description,
            "price_amount": price,
            "pricing_model": pricing_model,
        }
        if capability_tags is not None:
            body["capability_tags"] = capability_tags
        if sla_response_time_ms is not None:
            body["sla_response_time_ms"] = sla_response_time_ms
        if sla_uptime_percent is not None:
            body["sla_uptime_percent"] = sla_uptime_percent
        return await self._client.post("/oris/marketplace/listings", json=body)

    def create_listing(self, **kwargs) -> dict[str, Any]:
        """Create a marketplace listing (sync)."""
        return self._client._run_sync(self.acreate_listing(**kwargs))

    async def asearch_listings(
        self,
        capability: str | None = None,
        max_price: float | None = None,
        page: int = 1,
        per_page: int = 50,
    ) -> dict[str, Any]:
        """Search marketplace listings (async)."""
        params: dict[str, Any] = {"page": page, "per_page": per_page}
        if capability is not None:
            params["capability"] = capability
        if max_price is not None:
            params["max_price"] = max_price
        return await self._client.get(
            "/oris/marketplace/listings", params=params,
        )

    def search_listings(self, **kwargs) -> dict[str, Any]:
        """Search marketplace listings (sync)."""
        return self._client._run_sync(self.asearch_listings(**kwargs))

    async def aget_reputation(self, agent_id: str) -> dict[str, Any]:
        """Get agent reputation score and breakdown (async)."""
        return await self._client.get(
            f"/oris/marketplace/reputation/{agent_id}",
        )

    def get_reputation(self, agent_id: str) -> dict[str, Any]:
        """Get agent reputation (sync)."""
        return self._client._run_sync(self.aget_reputation(agent_id))

    async def aplace_order(
        self,
        buyer_agent_id: str,
        listing_id: str,
        quantity: int = 1,
        max_price: float | None = None,
        escrow_required: bool | None = None,
    ) -> dict[str, Any]:
        """Place an order for a marketplace listing (async)."""
        body: dict[str, Any] = {
            "buyer_agent_id": buyer_agent_id,
            "listing_id": listing_id,
            "quantity": quantity,
        }
        if max_price is not None:
            body["max_price"] = max_price
        if escrow_required is not None:
            body["escrow_required"] = escrow_required
        return await self._client.post("/oris/marketplace/orders", json=body)

    def place_order(self, **kwargs) -> dict[str, Any]:
        """Place a marketplace order (sync)."""
        return self._client._run_sync(self.aplace_order(**kwargs))

    async def acomplete_order(self, order_id: str) -> dict[str, Any]:
        """Mark an order as completed (async)."""
        return await self._client.post(
            f"/oris/marketplace/orders/{order_id}/complete",
        )

    def complete_order(self, order_id: str) -> dict[str, Any]:
        """Mark an order as completed (sync)."""
        return self._client._run_sync(self.acomplete_order(order_id))

    async def afile_dispute(
        self,
        order_id: str,
        reason: str,
        evidence: str | None = None,
    ) -> dict[str, Any]:
        """File a dispute against an order (async)."""
        body: dict[str, Any] = {"order_id": order_id, "reason": reason}
        if evidence is not None:
            body["evidence"] = evidence
        return await self._client.post("/oris/marketplace/disputes", json=body)

    def file_dispute(self, **kwargs) -> dict[str, Any]:
        """File a marketplace dispute (sync)."""
        return self._client._run_sync(self.afile_dispute(**kwargs))

    async def aget_earnings(self, agent_id: str) -> dict[str, Any]:
        """Get agent marketplace earnings and revenue share (async)."""
        return await self._client.get(
            f"/oris/marketplace/earnings/{agent_id}",
        )

    def get_earnings(self, agent_id: str) -> dict[str, Any]:
        """Get agent marketplace earnings (sync)."""
        return self._client._run_sync(self.aget_earnings(agent_id))
