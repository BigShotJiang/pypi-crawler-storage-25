"""Attestations resource: DID, EAS, and compliance attestation management."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from oris.client import OrisClient


class AttestationsResource:
    """Manage agent attestations, DIDs, and on-chain identity proofs.

    Usage:
        attestation = client.attestations.generate(agent_id, chain="base")
        latest = client.attestations.get_latest(agent_id)
        result = client.attestations.verify(agent_id, chain="base", kya_level=2)
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def agenerate(
        self,
        agent_id: str,
        chain: str = "base",
    ) -> dict[str, Any]:
        """Generate an on-chain attestation for the agent (async)."""
        return await self._client.post("/oris/attestations/generate", json={
            "agent_id": agent_id,
            "chain": chain,
        })

    def generate(self, agent_id: str, chain: str = "base") -> dict[str, Any]:
        """Generate an on-chain attestation (sync)."""
        return self._client._run_sync(self.agenerate(agent_id, chain=chain))

    async def aget_latest(self, agent_id: str) -> dict[str, Any]:
        """Get the latest attestation for the agent (async)."""
        return await self._client.get(f"/oris/attestations/latest/{agent_id}")

    def get_latest(self, agent_id: str) -> dict[str, Any]:
        """Get the latest attestation (sync)."""
        return self._client._run_sync(self.aget_latest(agent_id))

    async def averify(
        self,
        agent_id: str,
        chain: str = "base",
        kya_level: int | None = None,
    ) -> dict[str, Any]:
        """Verify an agent's attestation on-chain (async)."""
        body: dict[str, Any] = {"agent_id": agent_id, "chain": chain}
        if kya_level is not None:
            body["kya_level"] = kya_level
        return await self._client.post("/oris/attestations/verify", json=body)

    def verify(
        self,
        agent_id: str,
        chain: str = "base",
        kya_level: int | None = None,
    ) -> dict[str, Any]:
        """Verify an agent's attestation (sync)."""
        return self._client._run_sync(
            self.averify(agent_id, chain=chain, kya_level=kya_level)
        )

    async def aget_did(
        self, agent_id: str, resolve: bool = False,
    ) -> dict[str, Any]:
        """Get the W3C DID for the agent (async)."""
        params = {"resolve": "true"} if resolve else {}
        return await self._client.get(
            f"/oris/attestations/did/{agent_id}", params=params,
        )

    def get_did(self, agent_id: str, resolve: bool = False) -> dict[str, Any]:
        """Get the W3C DID (sync)."""
        return self._client._run_sync(self.aget_did(agent_id, resolve=resolve))

    async def aget_eas(
        self, agent_id: str, verify: bool = False,
    ) -> dict[str, Any]:
        """Get the latest EAS attestation for the agent (async)."""
        params = {"verify": "true"} if verify else {}
        return await self._client.get(
            f"/oris/attestations/eas/{agent_id}", params=params,
        )

    def get_eas(self, agent_id: str, verify: bool = False) -> dict[str, Any]:
        """Get the latest EAS attestation (sync)."""
        return self._client._run_sync(self.aget_eas(agent_id, verify=verify))
