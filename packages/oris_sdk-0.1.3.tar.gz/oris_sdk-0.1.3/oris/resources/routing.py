"""Routing resource: cross-chain quote and route optimization."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from oris.client import OrisClient


class RoutingResource:
    """Get cross-chain routing quotes and optimal transfer paths.

    Usage:
        quote = client.routing.get_quote(agent_id, "base", "polygon", 100.0)
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def aget_quote(
        self,
        agent_id: str,
        source_chain: str,
        dest_chain: str,
        amount: float,
        stablecoin: str = "USDC",
    ) -> dict[str, Any]:
        """Get a cross-chain routing quote (async)."""
        return await self._client.post("/oris/routing/quote", json={
            "agent_id": agent_id,
            "source_chain": source_chain,
            "destination_chain": dest_chain,
            "amount": amount,
            "stablecoin": stablecoin,
        })

    def get_quote(self, **kwargs) -> dict[str, Any]:
        """Get a cross-chain routing quote (sync)."""
        return self._client._run_sync(self.aget_quote(**kwargs))
