"""Wallets resource: ERC-4337 smart account creation and balance queries."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from oris.types import Wallet, WalletList, WalletBalance

if TYPE_CHECKING:
    from oris.client import OrisClient


class WalletsResource:
    """Manage ERC-4337 smart account wallets for AI agents.

    Usage:
        wallet = client.wallets.create(agent_id="...", chain="polygon")
        balance = client.wallets.get_balance(wallet.id)
        all_wallets = client.wallets.list(agent_id="...")
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def acreate(
        self,
        agent_id: str,
        chain: str = "base",
        wallet_type: str = "erc4337",
    ) -> Wallet:
        """Create a new wallet for an agent on the specified chain.

        The wallet is deployed as a counterfactual ERC-4337 smart account.
        Deployment happens on first transaction (gas-abstracted).
        """
        data = await self._client.post("/oris/wallets/create", json={
            "agent_id": agent_id,
            "chain": chain,
            "wallet_type": wallet_type,
        })
        return Wallet.from_dict(data)

    def create(self, **kwargs) -> Wallet:
        """Create a new wallet (sync)."""
        return self._client._run_sync(self.acreate(**kwargs))

    async def aget(self, wallet_id: str) -> Wallet:
        """Get wallet details by ID."""
        data = await self._client.get(f"/oris/wallets/{wallet_id}")
        return Wallet.from_dict(data)

    def get(self, wallet_id: str) -> Wallet:
        """Get wallet details (sync)."""
        return self._client._run_sync(self.aget(wallet_id))

    async def aget_balance(self, wallet_id: str) -> WalletBalance:
        """Get wallet balance (Redis-cached, sub-millisecond response)."""
        data = await self._client.get(f"/oris/wallets/{wallet_id}/balance")
        return WalletBalance.from_dict(data)

    def get_balance(self, wallet_id: str) -> WalletBalance:
        """Get wallet balance (sync)."""
        return self._client._run_sync(self.aget_balance(wallet_id))

    async def alist(self, agent_id: str) -> WalletList:
        """List all wallets for an agent across all chains."""
        data = await self._client.get(f"/oris/wallets/agent/{agent_id}")
        return WalletList.from_dict(data)

    def list(self, agent_id: str) -> WalletList:
        """List all wallets (sync)."""
        return self._client._run_sync(self.alist(agent_id))

    async def afreeze(self, wallet_id: str, reason: str) -> Wallet:
        """Freeze a wallet. All transactions are blocked until unfrozen."""
        data = await self._client.post(
            f"/oris/wallets/{wallet_id}/freeze",
            json={"reason": reason},
        )
        return Wallet.from_dict(data)

    def freeze(self, wallet_id: str, reason: str) -> Wallet:
        """Freeze a wallet (sync)."""
        return self._client._run_sync(self.afreeze(wallet_id, reason))

    async def aunfreeze(self, wallet_id: str) -> Wallet:
        """Unfreeze a previously frozen wallet."""
        data = await self._client.post(f"/oris/wallets/{wallet_id}/unfreeze")
        return Wallet.from_dict(data)

    def unfreeze(self, wallet_id: str) -> Wallet:
        """Unfreeze a wallet (sync)."""
        return self._client._run_sync(self.aunfreeze(wallet_id))
