from oris.resources.agents import AgentsResource
from oris.resources.wallets import WalletsResource
from oris.resources.policies import PoliciesResource
from oris.resources.payments import PaymentsResource
from oris.resources.attestations import AttestationsResource
from oris.resources.micropayments import MicropaymentsResource
from oris.resources.marketplace import MarketplaceResource
from oris.resources.fiat import FiatResource
from oris.resources.routing import RoutingResource
from oris.resources.kya import KyaResource
from oris.resources.whitelabel import WhitelabelResource
from oris.resources.providers import ProvidersResource

__all__ = [
    "AgentsResource",
    "WalletsResource",
    "PoliciesResource",
    "PaymentsResource",
    "AttestationsResource",
    "MicropaymentsResource",
    "MarketplaceResource",
    "FiatResource",
    "RoutingResource",
    "KyaResource",
    "WhitelabelResource",
    "ProvidersResource",
]
