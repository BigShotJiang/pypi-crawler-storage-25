"""White-label resource: brand configuration and customization."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from oris.client import OrisClient


class WhitelabelResource:
    """Manage white-label brand configuration.

    Usage:
        config = client.whitelabel.get_config()
        client.whitelabel.update_config(brand_name="Acme Payments")
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def aget_config(self) -> dict[str, Any]:
        """Get current white-label configuration (async)."""
        return await self._client.get("/oris/whitelabel/config")

    def get_config(self) -> dict[str, Any]:
        """Get white-label configuration (sync)."""
        return self._client._run_sync(self.aget_config())

    async def aupdate_config(
        self,
        brand_name: str | None = None,
        logo_url: str | None = None,
        primary_color: str | None = None,
        webhook_url: str | None = None,
        custom_domain: str | None = None,
    ) -> dict[str, Any]:
        """Update white-label configuration (async)."""
        body: dict[str, Any] = {}
        if brand_name is not None:
            body["brand_name"] = brand_name
        if logo_url is not None:
            body["logo_url"] = logo_url
        if primary_color is not None:
            body["primary_color"] = primary_color
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        if custom_domain is not None:
            body["custom_domain"] = custom_domain
        return await self._client.patch("/oris/whitelabel/config", json=body)

    def update_config(self, **kwargs) -> dict[str, Any]:
        """Update white-label configuration (sync)."""
        return self._client._run_sync(self.aupdate_config(**kwargs))
