"""Micropayments resource: state channel management and metered billing."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from oris.client import OrisClient


class MicropaymentsResource:
    """Manage micropayment state channels and metered transactions.

    Usage:
        channel = client.micropayments.open_channel(party_a_id, party_b_id)
        result = client.micropayments.meter(channel.id, payer_id, payee_id, 0.01)
        client.micropayments.close_channel(channel.id)
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def aopen_channel(
        self,
        party_a_id: str,
        party_b_id: str,
        chain: str = "base",
        stablecoin: str = "USDC",
        party_a_deposit: float | None = None,
        party_b_deposit: float | None = None,
        settlement_interval: str = "daily",
        min_settlement_amount: float | None = None,
    ) -> dict[str, Any]:
        """Open a micropayment state channel between two agents (async)."""
        body: dict[str, Any] = {
            "party_a_id": party_a_id,
            "party_b_id": party_b_id,
            "chain": chain,
            "stablecoin": stablecoin,
            "settlement_interval": settlement_interval,
        }
        if party_a_deposit is not None:
            body["party_a_deposit"] = party_a_deposit
        if party_b_deposit is not None:
            body["party_b_deposit"] = party_b_deposit
        if min_settlement_amount is not None:
            body["min_settlement_amount"] = min_settlement_amount
        return await self._client.post(
            "/oris/micropayments/channels/open", json=body,
        )

    def open_channel(self, **kwargs) -> dict[str, Any]:
        """Open a micropayment state channel (sync)."""
        return self._client._run_sync(self.aopen_channel(**kwargs))

    async def aget_channel(self, channel_id: str) -> dict[str, Any]:
        """Get channel details and current balances (async)."""
        return await self._client.get(
            f"/oris/micropayments/channels/{channel_id}",
        )

    def get_channel(self, channel_id: str) -> dict[str, Any]:
        """Get channel details (sync)."""
        return self._client._run_sync(self.aget_channel(channel_id))

    async def aclose_channel(self, channel_id: str) -> dict[str, Any]:
        """Close a channel and settle final balances on-chain (async)."""
        return await self._client.post(
            f"/oris/micropayments/channels/{channel_id}/close",
        )

    def close_channel(self, channel_id: str) -> dict[str, Any]:
        """Close a channel (sync)."""
        return self._client._run_sync(self.aclose_channel(channel_id))

    async def ameter(
        self,
        channel_id: str,
        payer_id: str,
        payee_id: str,
        amount: float,
        purpose: str | None = None,
        metering_type: str | None = None,
    ) -> dict[str, Any]:
        """Record a metered micropayment within a channel (async)."""
        body: dict[str, Any] = {
            "channel_id": channel_id,
            "payer_id": payer_id,
            "payee_id": payee_id,
            "amount": amount,
        }
        if purpose is not None:
            body["purpose"] = purpose
        if metering_type is not None:
            body["metering_type"] = metering_type
        return await self._client.post("/oris/micropayments/meter", json=body)

    def meter(self, **kwargs) -> dict[str, Any]:
        """Record a metered micropayment (sync)."""
        return self._client._run_sync(self.ameter(**kwargs))
