"""Providers resource: MPC provider key management and audit."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from oris.client import OrisClient


class ProvidersResource:
    """Manage MPC provider keys for wallet infrastructure.

    Usage:
        client.providers.save_keys("turnkey", {"orgId": "...", "apiPublicKey": "..."})
        status = client.providers.get_status()
        audit = client.providers.verify_audit()
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def asave_keys(
        self, provider: str, keys: dict[str, Any],
    ) -> dict[str, Any]:
        """Save encrypted provider keys to the backend (async)."""
        return await self._client.request(
            "PUT",
            f"/oris/developers/provider-keys/{provider}",
            json=keys,
        )

    def save_keys(self, provider: str, keys: dict[str, Any]) -> dict[str, Any]:
        """Save provider keys (sync)."""
        return self._client._run_sync(self.asave_keys(provider, keys))

    async def aget_status(self) -> dict[str, Any]:
        """Get configuration status for all providers (async)."""
        return await self._client.get("/oris/developers/provider-keys")

    def get_status(self) -> dict[str, Any]:
        """Get provider status (sync)."""
        return self._client._run_sync(self.aget_status())

    async def adelete_keys(self, provider: str) -> dict[str, Any]:
        """Delete provider keys (async)."""
        return await self._client.delete(
            f"/oris/developers/provider-keys/{provider}",
        )

    def delete_keys(self, provider: str) -> dict[str, Any]:
        """Delete provider keys (sync)."""
        return self._client._run_sync(self.adelete_keys(provider))

    async def averify_audit(self) -> dict[str, Any]:
        """Verify the provider key audit chain integrity (async)."""
        return await self._client.get(
            "/oris/developers/provider-keys/audit/verify",
        )

    def verify_audit(self) -> dict[str, Any]:
        """Verify audit chain (sync)."""
        return self._client._run_sync(self.averify_audit())
