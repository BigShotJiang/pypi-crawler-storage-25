"""Fiat resource: on-ramp, off-ramp, and exchange rate operations."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from oris.client import OrisClient


class FiatResource:
    """Manage fiat on-ramp, off-ramp, and currency conversion.

    Usage:
        result = client.fiat.onramp(agent_id, "USD", 100.0)
        rate = client.fiat.get_exchange_rate("USD", "USDC")
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def aonramp(
        self,
        agent_id: str,
        source_currency: str,
        amount: float,
        destination_stablecoin: str = "USDC",
        destination_chain: str = "base",
        payment_method: str = "bank_transfer",
    ) -> dict[str, Any]:
        """Convert fiat currency to stablecoin (async)."""
        return await self._client.post("/oris/fiat/onramp", json={
            "agent_id": agent_id,
            "source_currency": source_currency,
            "source_amount": amount,
            "destination_stablecoin": destination_stablecoin,
            "destination_chain": destination_chain,
            "payment_method": payment_method,
        })

    def onramp(self, **kwargs) -> dict[str, Any]:
        """Convert fiat to stablecoin (sync)."""
        return self._client._run_sync(self.aonramp(**kwargs))

    async def aofframp(
        self,
        agent_id: str,
        source_stablecoin: str,
        amount: float,
        source_chain: str = "base",
        destination_currency: str = "USD",
        destination_account: str = "",
    ) -> dict[str, Any]:
        """Convert stablecoin to fiat currency (async)."""
        return await self._client.post("/oris/fiat/offramp", json={
            "agent_id": agent_id,
            "source_stablecoin": source_stablecoin,
            "source_amount": amount,
            "source_chain": source_chain,
            "destination_currency": destination_currency,
            "destination_account": destination_account,
        })

    def offramp(self, **kwargs) -> dict[str, Any]:
        """Convert stablecoin to fiat (sync)."""
        return self._client._run_sync(self.aofframp(**kwargs))

    async def aget_exchange_rate(
        self, source: str, destination: str,
    ) -> dict[str, Any]:
        """Get current exchange rate between two currencies (async)."""
        return await self._client.get(
            "/oris/fiat/exchange-rate",
            params={"source": source, "destination": destination},
        )

    def get_exchange_rate(self, source: str, destination: str) -> dict[str, Any]:
        """Get exchange rate (sync)."""
        return self._client._run_sync(
            self.aget_exchange_rate(source, destination)
        )
