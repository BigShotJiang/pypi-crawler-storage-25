"""Payments resource: stablecoin transfer execution and status tracking."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from oris.types import Payment, PaymentList

if TYPE_CHECKING:
    from oris.client import OrisClient


class PaymentsResource:
    """Execute and track compliant stablecoin payments for AI agents.

    Every payment passes through the full Oris pipeline:
    KYA check, policy evaluation, compliance pre-screen, balance reservation,
    and gas-abstracted on-chain execution via ERC-4337.

    Usage:
        tx = client.payments.send(agent_id="...", to_address="0x...", amount=10.0)
        status = client.payments.get(tx.id)
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def asend(
        self,
        agent_id: str,
        to_address: str,
        amount: float,
        chain: str = "base",
        token: str = "USDC",
        purpose: str | None = None,
        category: str | None = None,
        protocol: str = "x402",
    ) -> Payment:
        """Send a compliant payment from an agent's wallet.

        Args:
            agent_id: Sending agent.
            to_address: Recipient wallet address.
            amount: Payment amount in token units.
            chain: Target blockchain.
            token: Token symbol (USDC, USDT, EURC, or native like POL/ETH).
            purpose: Transaction purpose for audit trail.
            category: Transaction category (compute_api, saas_subscription, etc.).
            protocol: Payment protocol (x402, direct, acp, mcp).

        Returns:
            Payment record with id, status, and tx_hash (populated after settlement).
        """
        data = await self._client.post("/oris/payments/send", json={
            "agent_id": agent_id,
            "amount": amount,
            "stablecoin": token,
            "chain": chain,
            "counterparty_address": to_address,
            "purpose": purpose,
            "category": category,
            "protocol": protocol,
        })
        return Payment.from_dict(data)

    def send(self, **kwargs) -> Payment:
        """Send a payment (sync)."""
        return self._client._run_sync(self.asend(**kwargs))

    async def aget(self, payment_id: str) -> Payment:
        """Get payment status and on-chain details."""
        data = await self._client.get(f"/oris/payments/{payment_id}")
        return Payment.from_dict(data)

    def get(self, payment_id: str) -> Payment:
        """Get payment status (sync)."""
        return self._client._run_sync(self.aget(payment_id))

    async def alist(
        self,
        agent_id: str,
        page: int = 1,
        per_page: int = 50,
    ) -> PaymentList:
        """List payment history for an agent (newest first)."""
        data = await self._client.get(
            f"/oris/payments/agent/{agent_id}",
            params={"page": page, "per_page": per_page},
        )
        return PaymentList.from_dict(data)

    def list(self, agent_id: str, **kwargs) -> PaymentList:
        """List payment history (sync)."""
        return self._client._run_sync(self.alist(agent_id, **kwargs))
