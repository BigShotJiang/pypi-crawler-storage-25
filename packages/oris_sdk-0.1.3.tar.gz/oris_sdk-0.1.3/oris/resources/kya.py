"""KYA resource: tier limits, promotion status, and tier advancement."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from oris.client import OrisClient


class KyaResource:
    """Manage KYA tier limits and promotion lifecycle.

    Usage:
        limits = client.kya.get_tier_limits(agent_id)
        status = client.kya.get_promotion_status(agent_id)
        result = client.kya.request_promotion(agent_id)
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def aget_tier_limits(self, agent_id: str) -> dict[str, Any]:
        """Get current tier limits and rolling usage (async)."""
        return await self._client.get(f"/oris/kya/{agent_id}/tier-limits")

    def get_tier_limits(self, agent_id: str) -> dict[str, Any]:
        """Get tier limits (sync)."""
        return self._client._run_sync(self.aget_tier_limits(agent_id))

    async def aget_promotion_status(self, agent_id: str) -> dict[str, Any]:
        """Get tier promotion eligibility and requirements (async)."""
        return await self._client.get(f"/oris/kya/{agent_id}/promotion")

    def get_promotion_status(self, agent_id: str) -> dict[str, Any]:
        """Get promotion status (sync)."""
        return self._client._run_sync(self.aget_promotion_status(agent_id))

    async def arequest_promotion(self, agent_id: str) -> dict[str, Any]:
        """Request tier promotion for an agent (async)."""
        return await self._client.post(f"/oris/kya/{agent_id}/promotion")

    def request_promotion(self, agent_id: str) -> dict[str, Any]:
        """Request tier promotion (sync)."""
        return self._client._run_sync(self.arequest_promotion(agent_id))
