"""Typed response objects for the Oris SDK.

Every API method returns a typed dataclass instead of a raw dict.
Objects support both attribute access (agent.id) and dict-style access
(agent["id"]) for backward compatibility.

Design:
    - @dataclass for zero extra dependencies (no Pydantic in SDK).
    - from_dict() classmethod ignores unknown fields from the API,
      making the SDK forward-compatible with new API fields.
    - dataclasses.asdict() works for serialization.
"""

from __future__ import annotations

from dataclasses import dataclass, fields, asdict
from typing import Any


class _DictAccessMixin:
    """Adds dict-style __getitem__ and __contains__ for backward compatibility.

    Allows code written as agent["id"] to keep working after the switch
    from raw dicts to typed objects.
    """

    def __getitem__(self, key: str) -> Any:
        try:
            return getattr(self, key)
        except AttributeError:
            raise KeyError(key)

    def __contains__(self, key: str) -> bool:
        return hasattr(self, key)

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def keys(self) -> list[str]:
        return [f.name for f in fields(self)]

    def values(self) -> list[Any]:
        return [getattr(self, f.name) for f in fields(self)]

    def items(self) -> list[tuple[str, Any]]:
        return [(f.name, getattr(self, f.name)) for f in fields(self)]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Any:
        """Construct from a dict, ignoring unknown keys."""
        known = {f.name for f in fields(cls)}
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

@dataclass
class AgentRegisterResponse(_DictAccessMixin):
    """Returned after successful agent registration."""

    id: str = ""
    external_agent_id: str = ""
    agent_name: str = ""
    kya_status: str = ""
    kya_level: int = 0


@dataclass
class Agent(_DictAccessMixin):
    """Full agent profile representation."""

    id: str = ""
    tenant_id: str = ""
    developer_id: str = ""
    external_agent_id: str = ""
    agent_name: str = ""
    agent_type: str = ""
    platform: str = ""
    kya_status: str = ""
    kya_level: int = 0
    kya_risk_score: str | None = None
    kya_verified_at: str | None = None
    declared_capabilities: list | None = None
    authority_scope: dict | None = None
    anomaly_count: int = 0
    operating_chains: list | None = None
    did: str | None = None


@dataclass
class AgentKyaTransition(_DictAccessMixin):
    """Returned after a KYA state transition."""

    agent_id: str = ""
    previous_status: str = ""
    new_status: str = ""
    previous_level: int = 0
    new_level: int = 0


# ---------------------------------------------------------------------------
# Wallet
# ---------------------------------------------------------------------------

@dataclass
class Wallet(_DictAccessMixin):
    """Full wallet representation."""

    id: str = ""
    agent_id: str = ""
    chain: str = ""
    wallet_type: str = ""
    status: str = ""
    smart_account_address: str | None = None
    is_deployed: bool | None = None
    balance_usdc: str = "0"
    balance_usdt: str = "0"
    balance_eurc: str = "0"
    balance_updated_at: str | None = None
    frozen_reason: str | None = None
    mpc_provider: str | None = None


@dataclass
class WalletList(_DictAccessMixin):
    """List of wallets for an agent."""

    items: list[Wallet] | None = None
    count: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WalletList:
        raw_items = data.get("items", [])
        wallets = [Wallet.from_dict(w) if isinstance(w, dict) else w for w in raw_items]
        return cls(items=wallets, count=data.get("count", len(wallets)))


@dataclass
class WalletBalance(_DictAccessMixin):
    """Current balance of a wallet."""

    wallet_id: str = ""
    chain: str = ""
    usdc: str = "0"
    usdt: str = "0"
    eurc: str = "0"
    source: str = ""


# ---------------------------------------------------------------------------
# Policy
# ---------------------------------------------------------------------------

@dataclass
class Policy(_DictAccessMixin):
    """Full spending policy representation."""

    id: str = ""
    agent_id: str = ""
    policy_name: str = ""
    priority: int = 0
    is_active: bool = True
    rules: dict | None = None
    enforcement_mode: str = ""
    violation_action: str = ""
    effective_from: str | None = None
    effective_until: str | None = None
    created_at: str | None = None


@dataclass
class PolicyList(_DictAccessMixin):
    """List of policies for an agent."""

    items: list[Policy] | None = None
    count: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PolicyList:
        raw_items = data.get("items", [])
        policies = [Policy.from_dict(p) if isinstance(p, dict) else p for p in raw_items]
        return cls(items=policies, count=data.get("count", len(policies)))


@dataclass
class PolicyEvaluation(_DictAccessMixin):
    """Result of a dry-run policy evaluation."""

    passed: bool = False
    verdict: str = ""
    violation_action: str = ""
    violated_rules: list[str] | None = None
    escalation_required: bool = False


# ---------------------------------------------------------------------------
# Payment
# ---------------------------------------------------------------------------

@dataclass
class Payment(_DictAccessMixin):
    """Payment transaction details."""

    id: str = ""
    agent_id: str = ""
    wallet_id: str = ""
    protocol: str = ""
    direction: str = ""
    amount: str = "0"
    stablecoin: str = ""
    chain: str = ""
    counterparty_address: str | None = None
    purpose: str | None = None
    status: str = ""
    tx_hash: str | None = None
    policy_result: str | None = None
    veris_pre_screen: str | None = None
    created_at: str = ""


@dataclass
class PaymentList(_DictAccessMixin):
    """Paginated list of payments."""

    items: list[Payment] | None = None
    total: int = 0
    page: int = 1
    per_page: int = 50

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PaymentList:
        raw_items = data.get("items", [])
        payments = [Payment.from_dict(p) if isinstance(p, dict) else p for p in raw_items]
        return cls(
            items=payments,
            total=data.get("total", len(payments)),
            page=data.get("page", 1),
            per_page=data.get("per_page", 50),
        )
