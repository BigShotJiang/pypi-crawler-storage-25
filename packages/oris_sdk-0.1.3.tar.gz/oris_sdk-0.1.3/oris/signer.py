"""Ed25519 request signer for Oris API authentication.

The signer computes an Ed25519 signature for every outgoing request
using the canonical request format defined by the Oris API:

    canonical = "{timestamp}.{nonce}.{METHOD}.{path}.{SHA-256(body)}"
    signature = Ed25519.sign(private_key, canonical)

The nonce is included in the signed payload to prevent replay attacks
where an attacker substitutes a different nonce within the timestamp
tolerance window.

The private key is decoded from the prefixed base64url format
(oris_pk_live_... or oris_pk_test_...) at initialization.

Security properties:
    - Raw private key bytes are held only by the Ed25519PrivateKey object
    - Nonces are 24-byte URL-safe random tokens (192 bits of entropy)
    - Timestamps use integer Unix epoch (no fractional seconds)
    - Ed25519 signatures are 64 bytes (128 hex characters)
"""

from __future__ import annotations

import base64
import hashlib
import secrets
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


class RequestSigner:
    """Ed25519 request signer.

    Initialized once with the prefixed private key string. The Ed25519
    private key object is held in memory for the lifetime of the signer
    instance. Thread-safe and async-safe (no mutable state after init).
    """

    __slots__ = ("_private_key",)

    def __init__(self, private_key_prefixed: str) -> None:
        """Decode the private key from the prefixed base64url format.

        Accepts keys with prefix oris_pk_live_ or oris_pk_test_ (13 chars).
        """
        raw = private_key_prefixed[13:]
        # Add base64url padding.
        padding = 4 - len(raw) % 4
        if padding < 4:
            raw += "=" * padding
        seed_bytes = base64.urlsafe_b64decode(raw)
        self._private_key = Ed25519PrivateKey.from_private_bytes(seed_bytes)

    def sign(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
        timestamp: int | None = None,
        nonce: str | None = None,
    ) -> tuple[str, str, str]:
        """Compute the Ed25519 request signature and generate timestamp/nonce.

        Returns:
            (signature_hex, timestamp_str, nonce_str)

        The caller must attach these as headers:
            X-Request-Signature: {signature_hex}  (128 hex chars)
            X-Timestamp: {timestamp_str}
            X-Nonce: {nonce_str}
        """
        ts = str(timestamp or int(time.time()))
        nc = nonce or secrets.token_urlsafe(24)

        body_hash = hashlib.sha256(body or b"").hexdigest()
        canonical = f"{ts}.{nc}.{method.upper()}.{path}.{body_hash}"

        sig = self._private_key.sign(canonical.encode())
        return sig.hex(), ts, nc

    def close(self) -> None:
        """Drop private key reference. Call when signer is no longer needed."""
        self._private_key = None  # type: ignore[assignment]
