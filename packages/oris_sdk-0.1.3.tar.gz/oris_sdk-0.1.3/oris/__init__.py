"""Oris SDK: Compliant payment infrastructure for autonomous AI agents.

Usage (Stripe-style):
    from oris import OrisClient

    client = OrisClient(api_key="oris_sk_live_...", private_key="oris_pk_live_...")
    agent = client.agents.register(name="Researcher-01", description="Data procurement")
    client.agents.verify(agent["id"])
    wallet = client.wallets.create(agent_id=agent["id"], chain="polygon")
    tx = client.payments.send(agent_id=agent["id"], to_address="0x...", amount=10.0)

Usage (legacy Agent class, still supported):
    from oris import Agent

    agent = Agent(api_key="oris_sk_live_...", private_key="oris_pk_live_...")
    agent.register(external_agent_id="r01", agent_name="Researcher-01")
    result = agent.pay(to="0x...", amount=12.50)
"""

from oris._version import __version__
from oris.client import OrisClient
from oris.agent import Agent
from oris.exceptions import (
    OrisError,
    OrisAuthError,
    OrisRateLimitError,
    OrisValidationError,
    OrisPaymentError,
    OrisNetworkError,
)
from oris.types import (
    AgentRegisterResponse,
    Agent as AgentProfile,
    AgentKyaTransition,
    Wallet,
    WalletList,
    WalletBalance,
    Policy,
    PolicyList,
    PolicyEvaluation,
    Payment,
    PaymentList,
)

# Async alias for README compatibility.
AsyncOrisClient = OrisClient

__all__ = [
    "__version__",
    "OrisClient",
    "AsyncOrisClient",
    "Agent",
    "OrisError",
    "OrisAuthError",
    "OrisRateLimitError",
    "OrisValidationError",
    "OrisPaymentError",
    "OrisNetworkError",
    "AgentRegisterResponse",
    "AgentProfile",
    "AgentKyaTransition",
    "Wallet",
    "WalletList",
    "WalletBalance",
    "Policy",
    "PolicyList",
    "PolicyEvaluation",
    "Payment",
    "PaymentList",
]
