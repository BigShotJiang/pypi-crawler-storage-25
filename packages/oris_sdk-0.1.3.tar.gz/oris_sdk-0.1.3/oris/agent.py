"""Oris Agent: high-level interface for autonomous AI agent operations.

The Agent class wraps OrisClient with domain-specific methods that map
directly to the Oris product brief's "3 lines of code" promise:

    import oris

    agent = oris.Agent(api_key="oris_sk_live_...", private_key="oris_pk_live_...")
    agent.set_policy(max_daily=500, max_per_tx=50)
    result = agent.pay(to="0x...", amount=12.50, purpose="compute_api")

The Agent provides both async and sync interfaces. Sync methods run the
async implementation on a managed event loop, making the SDK usable in
non-async contexts (scripts, notebooks, simple integrations) without
requiring the caller to manage asyncio.

For high-throughput production use, prefer the async interface to avoid
event loop overhead.
"""

from __future__ import annotations

import asyncio
import uuid
from decimal import Decimal
from typing import Any

from oris.client import OrisClient


class Agent:
    """High-level Oris agent interface.

    Encapsulates developer authentication, agent registration, wallet
    management, spending policies, and payment execution behind a
    minimal API surface.
    """

    def __init__(
        self,
        api_key: str,
        private_key: str,
        agent_id: str | None = None,
        base_url: str = "https://api.useoris.xyz",
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self._client = OrisClient(
            api_key=api_key,
            private_key=private_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            agent_id=agent_id,
        )
        self._agent_id = agent_id
        self._loop: asyncio.AbstractEventLoop | None = None

        # Expose OrisClient resources directly on the Agent facade so callers
        # can use `agent.marketplace.find_services()`, `agent.fiat.onramp()`,
        # `agent.providers.save_keys()`, etc. without reaching into `_client`.
        self.agents = self._client.agents
        self.wallets = self._client.wallets
        self.policies = self._client.policies
        self.payments = self._client.payments
        self.attestations = self._client.attestations
        self.micropayments = self._client.micropayments
        self.marketplace = self._client.marketplace
        self.fiat = self._client.fiat
        self.routing = self._client.routing
        self.kya = self._client.kya
        self.whitelabel = self._client.whitelabel
        self.providers = self._client.providers

    # -------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------

    async def aclose(self) -> None:
        """Close the underlying HTTP client (async)."""
        await self._client.close()

    def close(self) -> None:
        """Close the underlying HTTP client (sync).

        Silently ignores ``RuntimeError: Event loop is closed`` which can be
        raised in Python 3.12+ when an Agent is used via ``with`` blocks in
        successive ``asyncio.run()`` invocations (the httpx connection pool
        was created in an earlier event loop that has since been torn down).
        """
        try:
            self._run(self.aclose())
        except RuntimeError as exc:
            if "event loop" in str(exc).lower():
                return
            raise

    async def __aenter__(self) -> "Agent":
        return self

    async def __aexit__(self, *exc) -> None:
        await self.aclose()

    def __enter__(self) -> "Agent":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # -------------------------------------------------------------------
    # Agent registration
    # -------------------------------------------------------------------

    async def aregister(
        self,
        external_agent_id: str,
        agent_name: str,
        platform: str = "custom",
        agent_type: str = "autonomous",
        capabilities: list[str] | None = None,
        operating_chains: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register this agent on the Oris platform (async).

        After registration, the agent starts in PENDING KYA status.
        Call verify() to activate the agent for transactions.
        """
        result = await self._client.post("/oris/agents/register", json={
            "external_agent_id": external_agent_id,
            "agent_name": agent_name,
            "platform": platform,
            "agent_type": agent_type,
            "declared_capabilities": capabilities or [],
            "operating_chains": operating_chains or ["base"],
        })
        self._agent_id = result.get("id", self._agent_id)
        self._client._agent_id = self._agent_id
        return result

    def register(self, **kwargs) -> dict[str, Any]:
        """Register this agent on the Oris platform (sync)."""
        return self._run(self.aregister(**kwargs))

    # -------------------------------------------------------------------
    # KYA verification
    # -------------------------------------------------------------------

    async def averify(self) -> dict[str, Any]:
        """Verify this agent (transition PENDING -> VERIFIED, async)."""
        self._require_agent_id()
        return await self._client.post(
            f"/oris/agents/{self._agent_id}/kya",
            json={"action": "verify"},
        )

    def verify(self) -> dict[str, Any]:
        """Verify this agent (sync)."""
        return self._run(self.averify())

    # -------------------------------------------------------------------
    # Wallet management
    # -------------------------------------------------------------------

    async def acreate_wallet(
        self,
        chain: str = "base",
        wallet_type: str = "erc4337",
    ) -> dict[str, Any]:
        """Create a wallet for this agent on the specified chain (async)."""
        self._require_agent_id()
        return await self._client.post("/oris/wallets/create", json={
            "agent_id": self._agent_id,
            "chain": chain,
            "wallet_type": wallet_type,
        })

    def create_wallet(self, **kwargs) -> dict[str, Any]:
        """Create a wallet (sync)."""
        return self._run(self.acreate_wallet(**kwargs))

    async def aget_balance(self, wallet_id: str) -> dict[str, Any]:
        """Get wallet balance (async)."""
        return await self._client.get(f"/oris/wallets/{wallet_id}/balance")

    def get_balance(self, wallet_id: str) -> dict[str, Any]:
        """Get wallet balance (sync)."""
        return self._run(self.aget_balance(wallet_id))

    async def aget_wallets(self) -> dict[str, Any]:
        """List all wallets for this agent (async)."""
        self._require_agent_id()
        return await self._client.get(f"/oris/wallets/agent/{self._agent_id}")

    def get_wallets(self) -> dict[str, Any]:
        """List all wallets (sync)."""
        return self._run(self.aget_wallets())

    # -------------------------------------------------------------------
    # Spending policies
    # -------------------------------------------------------------------

    async def aset_policy(
        self,
        max_per_tx: float | None = None,
        max_daily: float | None = None,
        max_weekly: float | None = None,
        max_monthly: float | None = None,
        counterparty_whitelist: list[str] | None = None,
        counterparty_blacklist: list[str] | None = None,
        policy_name: str = "default",
        enforcement_mode: str = "enforce",
    ) -> dict[str, Any]:
        """Set a spending policy for this agent (async).

        Creates a new policy with the specified rules. If a policy with
        the same name exists, it should be updated or deleted first.
        """
        self._require_agent_id()

        rules: dict[str, Any] = {}
        if max_per_tx is not None:
            rules["max_per_transaction"] = max_per_tx
        if max_daily is not None:
            rules["max_daily"] = max_daily
        if max_weekly is not None:
            rules["max_weekly"] = max_weekly
        if max_monthly is not None:
            rules["max_monthly"] = max_monthly
        if counterparty_whitelist is not None:
            rules["counterparty_whitelist"] = counterparty_whitelist
        if counterparty_blacklist is not None:
            rules["counterparty_blacklist"] = counterparty_blacklist

        return await self._client.post("/oris/policies", json={
            "agent_id": self._agent_id,
            "policy_name": policy_name,
            "rules": rules,
            "enforcement_mode": enforcement_mode,
        })

    def set_policy(self, **kwargs) -> dict[str, Any]:
        """Set a spending policy (sync)."""
        return self._run(self.aset_policy(**kwargs))

    async def aget_policies(self) -> dict[str, Any]:
        """List active policies for this agent (async)."""
        self._require_agent_id()
        return await self._client.get(f"/oris/policies/agent/{self._agent_id}")

    def get_policies(self) -> dict[str, Any]:
        """List active policies (sync)."""
        return self._run(self.aget_policies())

    async def asimulate_payment(
        self,
        amount: float,
        stablecoin: str = "USDC",
        chain: str = "base",
        counterparty_address: str | None = None,
    ) -> dict[str, Any]:
        """Dry-run policy evaluation without executing payment (async)."""
        self._require_agent_id()
        return await self._client.post("/oris/policies/evaluate", json={
            "agent_id": self._agent_id,
            "amount": amount,
            "stablecoin": stablecoin,
            "chain": chain,
            "counterparty_address": counterparty_address,
        })

    def simulate_payment(self, **kwargs) -> dict[str, Any]:
        """Dry-run policy evaluation (sync)."""
        return self._run(self.asimulate_payment(**kwargs))

    # -------------------------------------------------------------------
    # Payments
    # -------------------------------------------------------------------

    async def apay(
        self,
        to: str,
        amount: float,
        stablecoin: str = "USDC",
        chain: str = "base",
        purpose: str | None = None,
        category: str | None = None,
        protocol: str = "x402",
    ) -> dict[str, Any]:
        """Send a payment from this agent's wallet (async).

        The payment goes through the full pipeline:
        KYA check -> policy evaluation -> balance reservation ->
        compliance pre-screen -> on-chain submission.
        """
        self._require_agent_id()
        return await self._client.post("/oris/payments/send", json={
            "agent_id": self._agent_id,
            "amount": amount,
            "stablecoin": stablecoin,
            "chain": chain,
            "counterparty_address": to,
            "purpose": purpose,
            "category": category,
            "protocol": protocol,
        })

    def pay(self, **kwargs) -> dict[str, Any]:
        """Send a payment (sync)."""
        return self._run(self.apay(**kwargs))

    async def aget_payment(self, payment_id: str) -> dict[str, Any]:
        """Get payment status (async)."""
        return await self._client.get(f"/oris/payments/{payment_id}")

    def get_payment(self, payment_id: str) -> dict[str, Any]:
        """Get payment status (sync)."""
        return self._run(self.aget_payment(payment_id))

    async def aget_payments(
        self, page: int = 1, per_page: int = 50,
    ) -> dict[str, Any]:
        """List payment history (async)."""
        self._require_agent_id()
        return await self._client.get(
            f"/oris/payments/agent/{self._agent_id}",
            params={"page": page, "per_page": per_page},
        )

    def get_payments(self, **kwargs) -> dict[str, Any]:
        """List payment history (sync)."""
        return self._run(self.aget_payments(**kwargs))

    # -------------------------------------------------------------------
    # Agent profile
    # -------------------------------------------------------------------

    async def aget_profile(self) -> dict[str, Any]:
        """Get this agent's profile (async)."""
        self._require_agent_id()
        return await self._client.get(f"/oris/agents/{self._agent_id}")

    def get_profile(self) -> dict[str, Any]:
        """Get this agent's profile (sync)."""
        return self._run(self.aget_profile())

    # -------------------------------------------------------------------
    # KYA, DID, and attestations
    # -------------------------------------------------------------------

    async def aget_tier_limits(self) -> dict[str, Any]:
        """Get KYA tier limits and rolling usage for this agent (async)."""
        self._require_agent_id()
        return await self._client.get(f"/oris/kya/{self._agent_id}/tier-limits")

    def get_tier_limits(self) -> dict[str, Any]:
        """Get KYA tier limits and rolling usage (sync)."""
        return self._run(self.aget_tier_limits())

    async def aget_did(self, resolve: bool = False) -> dict[str, Any]:
        """Get W3C DID and DID document for this agent (async)."""
        self._require_agent_id()
        params = {"resolve": "true"} if resolve else {}
        return await self._client.get(
            f"/oris/attestations/did/{self._agent_id}", params=params,
        )

    def get_did(self, resolve: bool = False) -> dict[str, Any]:
        """Get W3C DID and DID document (sync)."""
        return self._run(self.aget_did(resolve=resolve))

    async def aget_eas_attestation(self, verify: bool = False) -> dict[str, Any]:
        """Get latest on-chain EAS attestation for this agent (async)."""
        self._require_agent_id()
        params = {"verify": "true"} if verify else {}
        return await self._client.get(
            f"/oris/attestations/eas/{self._agent_id}", params=params,
        )

    def get_eas_attestation(self, verify: bool = False) -> dict[str, Any]:
        """Get latest on-chain EAS attestation (sync)."""
        return self._run(self.aget_eas_attestation(verify=verify))

    # -------------------------------------------------------------------
    # Internal
    # -------------------------------------------------------------------

    def _require_agent_id(self) -> None:
        """Raise if no agent_id is set."""
        if not self._agent_id:
            raise ValueError(
                "agent_id is required. Pass it to the constructor or call register() first."
            )

    def _run(self, coro) -> Any:
        """Run an async coroutine synchronously.

        Uses a dedicated event loop to avoid conflicts with existing loops
        (e.g. in Jupyter notebooks or async frameworks).
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Already inside an event loop (Jupyter, async framework).
            # Create a new loop in a thread to avoid deadlock.
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(asyncio.run, coro).result()
        else:
            return asyncio.run(coro)
