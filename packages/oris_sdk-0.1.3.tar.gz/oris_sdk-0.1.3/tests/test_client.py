"""Integration tests for OrisClient: Ed25519 signing, retry logic, error mapping.

Uses respx to mock httpx transport layer. No real network calls.
Tests verify:
    1. Ed25519 signature headers are injected on every request
    2. Idempotency-Key is auto-generated for POST/PATCH
    3. Exponential backoff retries on 429 and 5xx
    4. Correct exception types for each error class
    5. Rate limit Retry-After header is respected
    6. Non-retryable 4xx errors are raised immediately
"""

import uuid

import httpx
import pytest
import respx

from oris.client import OrisClient
from oris.exceptions import (
    OrisAuthError,
    OrisNetworkError,
    OrisPaymentError,
    OrisRateLimitError,
    OrisValidationError,
)

import base64

API_KEY = "oris_sk_live_test_key_abcdefghijklmnopqrstuvwx"
_TEST_SEED = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
PRIVATE_KEY = "oris_pk_live_" + base64.urlsafe_b64encode(_TEST_SEED).decode().rstrip("=")
BASE_URL = "https://test.oris.local"


@pytest.fixture
def client():
    return OrisClient(
        api_key=API_KEY,
        private_key=PRIVATE_KEY,
        base_url=BASE_URL,
        timeout=5.0,
        max_retries=1,
    )


@respx.mock
@pytest.mark.asyncio
async def test_ed25519_headers_present(client):
    """Every request must carry Authorization, X-Request-Signature, X-Timestamp, X-Nonce."""
    route = respx.get(f"{BASE_URL}/api/v1/oris/agents/123").mock(
        return_value=httpx.Response(200, json={"id": "123"})
    )
    async with client:
        await client.get("/oris/agents/123")

    assert route.called
    request = route.calls[0].request
    assert request.headers["authorization"] == API_KEY
    assert "x-request-signature" in request.headers
    assert "x-timestamp" in request.headers
    assert "x-nonce" in request.headers
    assert len(request.headers["x-request-signature"]) == 128  # Ed25519 hex (64 bytes)
    assert len(request.headers["x-nonce"]) >= 16


@respx.mock
@pytest.mark.asyncio
async def test_idempotency_key_on_post(client):
    """POST requests must include Idempotency-Key header."""
    route = respx.post(f"{BASE_URL}/api/v1/oris/agents/register").mock(
        return_value=httpx.Response(201, json={"id": "new-agent"})
    )
    async with client:
        await client.post("/oris/agents/register", json={"name": "test"})

    request = route.calls[0].request
    idem_key = request.headers.get("idempotency-key")
    assert idem_key is not None
    uuid.UUID(idem_key)  # Must be valid UUID


@respx.mock
@pytest.mark.asyncio
async def test_no_idempotency_key_on_get(client):
    """GET requests must not include Idempotency-Key header."""
    route = respx.get(f"{BASE_URL}/api/v1/oris/agents/123").mock(
        return_value=httpx.Response(200, json={"id": "123"})
    )
    async with client:
        await client.get("/oris/agents/123")

    request = route.calls[0].request
    assert "idempotency-key" not in request.headers


@respx.mock
@pytest.mark.asyncio
async def test_401_raises_auth_error(client):
    """HTTP 401 must raise OrisAuthError."""
    respx.get(f"{BASE_URL}/api/v1/oris/test").mock(
        return_value=httpx.Response(401, json={
            "error": {"code": "INVALID_CREDENTIALS", "message": "Bad key"}
        })
    )
    async with client:
        with pytest.raises(OrisAuthError) as exc_info:
            await client.get("/oris/test")
        assert exc_info.value.status_code == 401
        assert exc_info.value.error_code == "INVALID_CREDENTIALS"


@respx.mock
@pytest.mark.asyncio
async def test_422_raises_validation_error(client):
    """HTTP 422 must raise OrisValidationError."""
    respx.post(f"{BASE_URL}/api/v1/oris/test").mock(
        return_value=httpx.Response(422, json={
            "error": {"code": "VALIDATION_ERROR", "message": "Bad input"}
        })
    )
    async with client:
        with pytest.raises(OrisValidationError) as exc_info:
            await client.post("/oris/test", json={})
        assert exc_info.value.status_code == 422


@respx.mock
@pytest.mark.asyncio
async def test_payment_error_codes(client):
    """403 with POLICY_VIOLATED raises OrisAuthError (403 is auth-class)."""
    respx.post(f"{BASE_URL}/api/v1/oris/payments/send").mock(
        return_value=httpx.Response(403, json={
            "error": {"code": "POLICY_VIOLATED", "message": "Limit exceeded"}
        })
    )
    async with client:
        with pytest.raises(OrisAuthError) as exc_info:
            await client.post("/oris/payments/send", json={})
        assert exc_info.value.error_code == "POLICY_VIOLATED"


@respx.mock
@pytest.mark.asyncio
async def test_429_retry_with_backoff(client):
    """HTTP 429 must retry after Retry-After delay."""
    call_count = 0

    def side_effect(request):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(429, headers={"Retry-After": "0"}, json={
                "error": {"code": "RATE_LIMIT_EXCEEDED", "message": "Slow down"}
            })
        return httpx.Response(200, json={"ok": True})

    respx.get(f"{BASE_URL}/api/v1/oris/test").mock(side_effect=side_effect)
    async with client:
        result = await client.get("/oris/test")
    assert result == {"ok": True}
    assert call_count == 2


@respx.mock
@pytest.mark.asyncio
async def test_429_exhausted_retries(client):
    """HTTP 429 after all retries must raise OrisRateLimitError."""
    respx.get(f"{BASE_URL}/api/v1/oris/test").mock(
        return_value=httpx.Response(429, headers={"Retry-After": "0"}, json={
            "error": {"code": "RATE_LIMIT_EXCEEDED", "message": "Slow down"}
        })
    )
    async with client:
        with pytest.raises(OrisRateLimitError):
            await client.get("/oris/test")


@respx.mock
@pytest.mark.asyncio
async def test_503_retry(client):
    """HTTP 503 must retry with backoff."""
    call_count = 0

    def side_effect(request):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(503)
        return httpx.Response(200, json={"recovered": True})

    respx.get(f"{BASE_URL}/api/v1/oris/test").mock(side_effect=side_effect)
    async with client:
        result = await client.get("/oris/test")
    assert result == {"recovered": True}
    assert call_count == 2


@respx.mock
@pytest.mark.asyncio
async def test_204_returns_empty_dict(client):
    """HTTP 204 (No Content) must return empty dict."""
    respx.post(f"{BASE_URL}/api/v1/oris/wallets/123/freeze").mock(
        return_value=httpx.Response(204)
    )
    async with client:
        result = await client.post("/oris/wallets/123/freeze", json={"reason": "test"})
    assert result == {}


def test_invalid_api_key_raises():
    """Invalid api_key prefix must raise ValueError at init."""
    with pytest.raises(ValueError, match="oris_sk_live_"):
        OrisClient(api_key="bad_key", private_key=PRIVATE_KEY)


def test_invalid_private_key_raises():
    """Invalid private_key prefix must raise ValueError at init."""
    with pytest.raises(ValueError, match="oris_pk_live_"):
        OrisClient(api_key=API_KEY, private_key="bad_key")


@respx.mock
@pytest.mark.asyncio
async def test_unique_nonce_per_retry(client):
    """Each retry attempt must use a fresh nonce."""
    nonces = []

    def capture_nonce(request):
        nonces.append(request.headers["x-nonce"])
        if len(nonces) < 2:
            return httpx.Response(503)
        return httpx.Response(200, json={"ok": True})

    respx.get(f"{BASE_URL}/api/v1/oris/test").mock(side_effect=capture_nonce)
    async with client:
        await client.get("/oris/test")

    assert len(nonces) == 2
    assert nonces[0] != nonces[1], "Each retry must use a unique nonce"
