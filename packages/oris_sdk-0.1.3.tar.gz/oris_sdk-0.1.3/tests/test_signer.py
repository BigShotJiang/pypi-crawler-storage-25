"""Deterministic tests for the Ed25519 request signer.

These tests verify:
    1. Signature determinism (same input -> same output)
    2. Canonical string construction with nonce
    3. Signature changes when any input parameter changes
    4. Nonce generation produces sufficient entropy
    5. Cross-language compatibility with TypeScript SDK
"""

import base64
import hashlib

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from oris.signer import RequestSigner


# Test seed (known 32 bytes).
TEST_SEED = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
TEST_PRIVATE_KEY = "oris_pk_live_" + base64.urlsafe_b64encode(TEST_SEED).decode().rstrip("=")

# Pre-computed cross-language test vector (verified against TypeScript @noble/curves).
CROSS_LANG_PUBLIC_KEY = "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
CROSS_LANG_MESSAGE = "1710672000.test_nonce_abc123.POST./api/v1/test.e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
CROSS_LANG_SIGNATURE = "6cc69f89b9c2f96e7bd0d3e3124df7d23117db29e24061a3c74774b5ad4838e18348dcdc9255e2db66e350effcaa99478ab2678201e38abff5d6f4417c71810f"


def test_signature_determinism():
    """Same inputs must produce the same signature."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig1, _, _ = signer.sign("POST", "/api/v1/oris/payments/send", b'{"amount":10}', timestamp=1710672000, nonce="fixed-nonce-1234567890123456")
    sig2, _, _ = signer.sign("POST", "/api/v1/oris/payments/send", b'{"amount":10}', timestamp=1710672000, nonce="fixed-nonce-1234567890123456")
    assert sig1 == sig2


def test_cross_language_vector():
    """Must produce the exact same signature as the TypeScript SDK."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig, _, _ = signer.sign("POST", "/api/v1/test", None, timestamp=1710672000, nonce="test_nonce_abc123")
    assert sig == CROSS_LANG_SIGNATURE


def test_cross_language_public_key():
    """The seed must derive the same public key as the TypeScript SDK."""
    pk = Ed25519PrivateKey.from_private_bytes(TEST_SEED)
    pub_hex = pk.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex()
    assert pub_hex == CROSS_LANG_PUBLIC_KEY


def test_canonical_string_method_uppercase():
    """HTTP method must be uppercased in the canonical string."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig_lower, _, _ = signer.sign("post", "/path", None, timestamp=100, nonce="nonce_1234567890123456")
    sig_upper, _, _ = signer.sign("POST", "/path", None, timestamp=100, nonce="nonce_1234567890123456")
    assert sig_lower == sig_upper


def test_empty_body_uses_empty_hash():
    """None body and empty bytes body must produce the same signature."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig_none, _, _ = signer.sign("GET", "/path", None, timestamp=100, nonce="nonce_1234567890123456")
    sig_empty, _, _ = signer.sign("GET", "/path", b"", timestamp=100, nonce="nonce_1234567890123456")
    assert sig_none == sig_empty


def test_signature_changes_with_different_body():
    """Different body must produce different signature."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig1, _, _ = signer.sign("POST", "/path", b'{"a":1}', timestamp=100, nonce="nonce_1234567890123456")
    sig2, _, _ = signer.sign("POST", "/path", b'{"a":2}', timestamp=100, nonce="nonce_1234567890123456")
    assert sig1 != sig2


def test_signature_changes_with_different_path():
    """Different path must produce different signature."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig1, _, _ = signer.sign("GET", "/path/a", None, timestamp=100, nonce="nonce_1234567890123456")
    sig2, _, _ = signer.sign("GET", "/path/b", None, timestamp=100, nonce="nonce_1234567890123456")
    assert sig1 != sig2


def test_signature_changes_with_different_timestamp():
    """Different timestamp must produce different signature."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig1, _, _ = signer.sign("GET", "/path", None, timestamp=100, nonce="nonce_1234567890123456")
    sig2, _, _ = signer.sign("GET", "/path", None, timestamp=200, nonce="nonce_1234567890123456")
    assert sig1 != sig2


def test_signature_changes_with_different_method():
    """Different HTTP method must produce different signature."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig1, _, _ = signer.sign("GET", "/path", None, timestamp=100, nonce="nonce_1234567890123456")
    sig2, _, _ = signer.sign("DELETE", "/path", None, timestamp=100, nonce="nonce_1234567890123456")
    assert sig1 != sig2


def test_signature_changes_with_different_nonce():
    """Different nonce must produce different signature (nonce is in canonical)."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig1, _, _ = signer.sign("GET", "/path", None, timestamp=100, nonce="nonce_aaaaaaaaaaaaaaaa")
    sig2, _, _ = signer.sign("GET", "/path", None, timestamp=100, nonce="nonce_bbbbbbbbbbbbbbbb")
    assert sig1 != sig2


def test_nonce_generation_entropy():
    """Auto-generated nonces must be unique and sufficiently long."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    nonces = set()
    for _ in range(100):
        _, _, nonce = signer.sign("GET", "/path")
        assert len(nonce) >= 16, "Nonce must be at least 16 characters"
        nonces.add(nonce)
    assert len(nonces) == 100, "All 100 nonces must be unique"


def test_different_keys_produce_different_signatures():
    """Two signers with different keys must produce different signatures."""
    seed2 = bytes.fromhex("4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb")
    pk2 = "oris_pk_live_" + base64.urlsafe_b64encode(seed2).decode().rstrip("=")
    signer1 = RequestSigner(TEST_PRIVATE_KEY)
    signer2 = RequestSigner(pk2)
    sig1, _, _ = signer1.sign("GET", "/path", None, timestamp=100, nonce="nonce_1234567890123456")
    sig2, _, _ = signer2.sign("GET", "/path", None, timestamp=100, nonce="nonce_1234567890123456")
    assert sig1 != sig2


def test_signature_is_128_hex_chars():
    """Ed25519 signatures must be 64 bytes = 128 hex characters."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    sig, _, _ = signer.sign("POST", "/test", b"{}", timestamp=1710672000, nonce="nonce_1234567890123456")
    assert len(sig) == 128
    assert all(c in "0123456789abcdef" for c in sig)


def test_close_drops_reference():
    """close() must nullify the private key reference."""
    signer = RequestSigner(TEST_PRIVATE_KEY)
    signer.close()
    assert signer._private_key is None
