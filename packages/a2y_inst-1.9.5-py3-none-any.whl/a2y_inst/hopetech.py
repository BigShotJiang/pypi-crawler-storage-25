from a2y_handy import make_enum_instance_from_name as _make_enum_from_name
from a2y_kcom import create_serial_instance
from abc import ABC as _ABC, abstractmethod as _abstractmethod
from enum import Enum as _Enum
import re as _re
from socket import create_connection as _create_connection


_out_of_range_pattern = _re.compile(r'^[+-]1(0*)\.0+E\+(\d)$')
_channel_number_pattern = _re.compile(r'^\d{1,2}$')
class Function(_Enum):
	RES = 0
	VOLT = 1
	RV = 2


class SampleRate(_Enum):
	EX = 0
	FAST = 1
	MED = 2
	SLOW = 3


class HP3562Exception(Exception):
	def __init__(self, *args):
		Exception.__init__(self, *args)


class HP3562Base(_ABC):
	@_abstractmethod
	def send(self, data: str):
		pass

	@_abstractmethod
	def receive(self, size: int) -> str:
		pass

	def query(self, command: str, feedback_len: int):
		self.send(command)
		feedback = self.receive(feedback_len)
		return feedback.strip()

	@property
	@_abstractmethod
	def function(self) -> Function:
		pass

	@property
	@_abstractmethod
	def res_range(self) -> int:
		pass

	@property
	@_abstractmethod
	def volt_range(self) -> int:
		pass

	@property
	@_abstractmethod
	def auto_range(self) -> bool:
		pass


class OutOfRange(HP3562Exception):
	def __init__(self, inst: HP3562Base, value_type: Function):
		unknown = True
		cur_range = -1
		try:
			auto_range = inst.auto_range
			unknown = False
		except Exception as _e:
			auto_range = False
		if not unknown and not auto_range:
			try:
				if value_type == Function.RES:
					cur_range = inst.res_range
				else:
					cur_range = inst.volt_range
			except Exception as _e:
				pass

		if unknown:
			range_str = 'Unknown'
		elif auto_range:
			range_str = 'Auto'
		else:
			range_str = f'{cur_range}'
		msg = f'Measurement out of range. Type: {value_type.name}, Range: {range_str}'
		HP3562Exception.__init__(self, msg)


class HP3562SerialSCPI:
	def __init__(self, port: str, baudrate: int = 38400, timeout: float = 1):
		self.__serial = create_serial_instance(port, baudrate)
