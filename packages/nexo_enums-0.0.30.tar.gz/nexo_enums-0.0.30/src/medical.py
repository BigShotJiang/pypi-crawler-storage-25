from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class MedicalRole(StrEnum):
    # 1. Director and specializations
    DIRECTOR = "director"  # Level 1 Parent
    MEDICAL_DIRECTOR = "medical_director"
    PRESIDENT = "president"
    VICE_PRESIDENT = "vice_president"
    SECRETARY = "secretary"
    TREASURER = "treasurer"
    # 1. Management and specializations
    MANAGEMENT = "management"  # Level 1 Parent
    CEO = "ceo"
    COO = "coo"
    CFO = "cfo"
    CCO = "cco"
    HEAD = "head"
    LEAD = "lead"
    # 3. Administration and specializations
    ADMINISTRATION = "administration"  # Level 1 Parent
    ADMISSION = "admission"
    CASHIER = "cashier"
    # 4. Medical and specializations
    MEDICAL = "medical"  # Level 1 Parent
    CASEMIX = "casemix"
    MEDICAL_RECORD = "medical_record"
    DOCTOR = "doctor"  # Level 2 Parent
    DENTIST = "dentist"
    INTERNIST = "internist"
    PEDIATRICIAN = "pediatrician"
    OBSTETRICIAN = "obstetrician"
    GYNECOLOGIST = "gynecologist"
    OBGYN = "obgyn"
    PSYCHIATRIST = "psychiatrist"
    DERMATOLOGIST = "dermatologist"
    NEUROLOGIST = "neurologist"
    CARDIOLOGIST = "cardiologist"
    OPHTHALMOLOGIST = "ophthalmologist"
    RADIOLOGIST = "radiologist"
    ANESTHESIOLOGIST = "anesthesiologist"
    HEMATOLOGIST = "hematologist"
    ONCOLOGIST = "oncologist"
    ENDOCRINOLOGIST = "endocrinologist"
    GASTROENTEROLOGIST = "gastroenterologist"
    NEPHROLOGIST = "nephrologist"
    UROLOGIST = "urologist"
    PULMONOLOGIST = "pulmonologist"
    RHEUMATOLOGIST = "rheumatologist"
    SURGEON = "surgeon"  # Level 3 Parent
    ORTHOPEDIC_SURGEON = "orthopedic_surgeon"
    MIDWIFE = "midwife"
    NURSE = "nurse"  # Level 2 Parent
    SCRUB_NURSE = "scrub_nurse"
    TRIAGE_NURSE = "triage_nurse"
    ICU_NURSE = "icu_nurse"
    NICU_NURSE = "nicu_nurse"
    ER_NURSE = "er_nurse"
    OR_NURSE = "or_nurse"
    LABORATORY_TECHNICIAN = "laboratory_technician"
    RADIOGRAPHER = "radiographer"
    SONOGRAPHER = "sonographer"
    PHARMACIST = "pharmacist"
    NUTRITIONIST = "nutritionist"
    # 5. Technical and specializations
    TECHNICAL = "technical"  # Level 1 Parent
    TECHNICIAN = "technician"
    IT_TECHNICIAN = "it_technician"
    # 6. Therapeutic and specializations
    THERAPEUTIC = "therapeutic"  # Level 1 Parent
    THERAPIST = "therapist"
    PHYSIOTHERAPIST = "physiotherapist"
    OCCUPATIONAL_THERAPIST = "occupational_therapist"
    SPEECH_THERAPIST = "speech_therapist"
    PSYCHOLOGIST = "psychologist"
    # 7. Support and specializations
    SUPPORT = "support"  # Level 1 Parent

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptMedicalRole = MedicalRole | None


class SimpleMedicalRoleMixin[T: OptMedicalRole](BaseModel):
    role: Annotated[T, Field(..., description="Medical Role")]


class FullMedicalRoleMixin[T: OptMedicalRole](BaseModel):
    medical_role: Annotated[T, Field(..., description="Medical Role")]


ListOfMedicalRoles = list[MedicalRole]
OptListOfMedicalRoles = ListOfMedicalRoles | None
SeqOfMedicalRoles = Sequence[MedicalRole]
OptSeqOfMedicalRoles = SeqOfMedicalRoles | None


class SimpleMedicalRolesMixin[T: OptSeqOfMedicalRoles](BaseModel):
    roles: Annotated[T, Field(..., description="Medical Roles")]


class FullMedicalRolesMixin[T: OptSeqOfMedicalRoles](BaseModel):
    medical_roles: Annotated[T, Field(..., description="Medical Roles")]


class MedicalService(StrEnum):
    EMERGENCY = "emergency"
    INPATIENT = "inpatient"
    INTENSIVE = "intensive"
    OUTPATIENT = "outpatient"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptMedicalService = MedicalService | None


class SimpleMedicalServiceMixin[T: OptMedicalService](BaseModel):
    service: Annotated[T, Field(..., description="Medical Service")]


class FullMedicalServiceMixin[T: OptMedicalService](BaseModel):
    medical_service: Annotated[T, Field(..., description="Medical Service")]


ListOfMedicalServices = list[MedicalService]
OptListOfMedicalServices = ListOfMedicalServices | None
SeqOfMedicalServices = Sequence[MedicalService]
OptSeqOfMedicalServices = SeqOfMedicalServices | None


class SimpleMedicalServicesMixin[T: OptSeqOfMedicalServices](BaseModel):
    services: Annotated[T, Field(..., description="Medical Services")]


class FullMedicalServicesMixin[T: OptSeqOfMedicalServices](BaseModel):
    medical_services: Annotated[T, Field(..., description="Medical Services")]
