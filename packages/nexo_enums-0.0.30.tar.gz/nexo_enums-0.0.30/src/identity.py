from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class BloodType(StrEnum):
    A = "a"
    B = "b"
    AB = "ab"
    O = "o"  # noqa: E741

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptBloodType = BloodType | None


class BloodTypeMixin[T: OptBloodType](BaseModel):
    blood_type: Annotated[T, Field(..., description="Blood Type")]


ListOfBloodTypes = list[BloodType]
OptListOfBloodTypes = ListOfBloodTypes | None
SeqOfBloodTypes = Sequence[BloodType]
OptSeqOfBloodTypes = SeqOfBloodTypes | None


class BloodTypesMixin[T: OptSeqOfBloodTypes](BaseModel):
    blood_types: Annotated[T, Field(..., description="Blood Types")]


class Rhesus(StrEnum):
    POSITIVE = "positive"
    NEGATIVE = "negative"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptRhesus = Rhesus | None


class RhesusMixin[T: OptRhesus](BaseModel):
    rhesus: Annotated[T, Field(..., description="Rhesus")]


ListOfRhesuses = list[Rhesus]
OptListOfRhesuses = ListOfRhesuses | None
SeqOfRhesuses = Sequence[Rhesus]
OptSeqOfRhesuses = SeqOfRhesuses | None


class RhesusesMixin[T: OptSeqOfRhesuses](BaseModel):
    rhesuses: Annotated[T, Field(..., description="Rhesuses")]


class Gender(StrEnum):
    UNDISCLOSED = "undisclosed"
    FEMALE = "female"
    MALE = "male"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptGender = Gender | None


class GenderMixin[T: OptGender](BaseModel):
    gender: Annotated[T, Field(..., description="Gender")]


ListOfGenders = list[Gender]
OptListOfGenders = ListOfGenders | None
SeqOfGenders = Sequence[Gender]
OptSeqOfGenders = SeqOfGenders | None


class GendersMixin[T: OptSeqOfGenders](BaseModel):
    genders: Annotated[T, Field(..., description="Genders")]
