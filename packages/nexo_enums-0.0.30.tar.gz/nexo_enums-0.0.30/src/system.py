from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class SystemRole(StrEnum):
    ADMINISTRATOR = "administrator"
    ANALYST = "analyst"
    ENGINEER = "engineer"
    GUEST = "guest"
    MANAGER = "manager"
    OFFICER = "officer"
    OPERATIONS = "operations"
    RESEARCHER = "researcher"
    SECURITY = "security"
    SUPPORT = "support"
    TESTER = "tester"
    USER = "user"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptSystemRole = SystemRole | None


class SimpleSystemRoleMixin[T: OptSystemRole](BaseModel):
    role: Annotated[T, Field(..., description="System Role")]


class FullSystemRoleMixin[T: OptSystemRole](BaseModel):
    system_role: Annotated[T, Field(..., description="System Role")]


ListOfSystemRoles = list[SystemRole]
OptListOfSystemRoles = ListOfSystemRoles | None
SeqOfSystemRoles = Sequence[SystemRole]
OptSeqOfSystemRoles = SeqOfSystemRoles | None


class SimpleSystemRolesMixin[T: OptSeqOfSystemRoles](BaseModel):
    roles: Annotated[T, Field(..., description="System Roles")]


class FullSystemRolesMixin[T: OptSeqOfSystemRoles](BaseModel):
    system_roles: Annotated[T, Field(..., description="System Roles")]
