from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class OrganizationRelation(StrEnum):
    AFFILIATE = "affiliate"
    APPLICATION = "application"
    BRANCH = "branch"
    CLIENT = "client"
    DEPARTMENT = "department"
    DIVISION = "division"
    NETWORK_MEMBER = "network_member"
    PARENT = "parent"
    PARTNER = "partner"
    SUBSIDIARY = "subsidiary"
    VENDOR = "vendor"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptOrganizationRelation = OrganizationRelation | None


class SimpleOrganizationRelationMixin[T: OptOrganizationRelation](BaseModel):
    relation: Annotated[T, Field(..., description="Organization Relation")]


class FullOrganizationRelationMixin[T: OptOrganizationRelation](BaseModel):
    organization_relation: Annotated[T, Field(..., description="Organization Relation")]


ListOfOrganizationRelations = list[OrganizationRelation]
OptListOfOrganizationRelations = ListOfOrganizationRelations | None
SeqOfOrganizationRelations = Sequence[OrganizationRelation]
OptSeqOfOrganizationRelations = SeqOfOrganizationRelations | None


class SimpleOrganizationRelationsMixin[T: OptSeqOfOrganizationRelations](BaseModel):
    relations: Annotated[T, Field(..., description="Organization Relations")]


class FullOrganizationRelationsMixin[T: OptSeqOfOrganizationRelations](BaseModel):
    organization_relations: Annotated[
        T, Field(..., description="Organization Relations")
    ]  # noqa: E501


class OrganizationRole(StrEnum):
    OWNER = "owner"
    ADMINISTRATOR = "administrator"
    USER = "user"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptOrganizationRole = OrganizationRole | None


class SimpleOrganizationRoleMixin[T: OptOrganizationRole](BaseModel):
    role: Annotated[T, Field(..., description="Organization Role")]


class FullOrganizationRoleMixin[T: OptOrganizationRole](BaseModel):
    organization_role: Annotated[T, Field(..., description="Organization Role")]


ListOfOrganizationRoles = list[OrganizationRole]
OptListOfOrganizationRoles = ListOfOrganizationRoles | None
SeqOfOrganizationRoles = Sequence[OrganizationRole]
OptSeqOfOrganizationRoles = SeqOfOrganizationRoles | None


class SimpleOrganizationRolesMixin[T: OptSeqOfOrganizationRoles](BaseModel):
    roles: Annotated[T, Field(..., description="Organization Roles")]


class FullOrganizationRolesMixin[T: OptSeqOfOrganizationRoles](BaseModel):
    organization_roles: Annotated[T, Field(..., description="Organization Roles")]


class OrganizationType(StrEnum):
    APPLICATION = "application"
    BRANCH = "branch"
    CLIENT = "client"
    CLINIC = "clinic"
    CORPORATION = "corporation"
    DEPARTMENT = "department"
    DIVISION = "division"
    GOVERNMENT = "government"
    HOSPITAL_SYSTEM = "hospital_system"
    HOSPITAL = "hospital"
    INSURANCE_PROVIDER = "insurance_provider"
    INTERNAL = "internal"
    LABORATORY = "laboratory"
    MEDICAL_GROUP = "organization_group"
    NETWORK = "network"
    PARTNER = "partner"
    PHARMACY = "pharmacy"
    PRIMARY_HEALTH_CARE = "primary_health_care"
    PUBLIC_HEALTH_AGENCY = "public_health_agency"
    REGIONAL_OFFICE = "regional_office"
    REGULAR = "regular"
    RESEARCH_INSTITUTE = "research_institute"
    SUBSIDIARY = "subsidiary"
    THIRD_PARTY_ADMINISTRATOR = "third_party_administrator"
    UNIT = "unit"
    VENDOR = "vendor"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptOrganizationType = OrganizationType | None


class SimpleOrganizationTypeMixin[T: OptOrganizationType](BaseModel):
    type: Annotated[T, Field(..., description="Organization Type")]


class FullOrganizationTypeMixin[T: OptOrganizationType](BaseModel):
    organization_type: Annotated[T, Field(..., description="Organization Type")]


ListOfOrganizationTypes = list[OrganizationType]
OptListOfOrganizationTypes = ListOfOrganizationTypes | None
SeqOfOrganizationTypes = Sequence[OrganizationType]
OptSeqOfOrganizationTypes = SeqOfOrganizationTypes | None


class SimpleOrganizationTypesMixin[T: OptSeqOfOrganizationTypes](BaseModel):
    types: Annotated[T, Field(..., description="Organization Types")]


class FullOrganizationTypesMixin[T: OptSeqOfOrganizationTypes](BaseModel):
    organization_types: Annotated[T, Field(..., description="Organization Types")]
