from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class UserType(StrEnum):
    PROXY = "proxy"
    REGULAR = "regular"
    SERVICE = "service"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptUserType = UserType | None


class SimpleUserTypeMixin[T: OptUserType](BaseModel):
    type: Annotated[T, Field(..., description="User Type")]


class FullUserTypeMixin[T: OptUserType](BaseModel):
    user_type: Annotated[T, Field(..., description="User Type")]


ListOfUserTypes = list[UserType]
OptListOfUserTypes = ListOfUserTypes | None
SeqOfUserTypes = Sequence[UserType]
OptSeqOfUserTypes = SeqOfUserTypes | None


class SimpleUserTypesMixin[T: OptSeqOfUserTypes](BaseModel):
    types: Annotated[T, Field(..., description="User Types")]


class FullUserTypesMixin[T: OptSeqOfUserTypes](BaseModel):
    user_types: Annotated[T, Field(..., description="User Types")]
