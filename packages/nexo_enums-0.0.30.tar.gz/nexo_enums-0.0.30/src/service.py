from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class ServiceType(StrEnum):
    BACKEND = "backend"
    FRONTEND = "frontend"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptServiceType = ServiceType | None


class SimpleServiceTypeMixin[T: OptServiceType](BaseModel):
    type: Annotated[T, Field(..., description="Service Type")]


class FullServiceTypeMixin[T: OptServiceType](BaseModel):
    service_type: Annotated[T, Field(..., description="Service Type")]


ListOfServiceTypes = list[ServiceType]
OptListOfServiceTypes = ListOfServiceTypes | None
SeqOfServiceTypes = Sequence[ServiceType]
OptSeqOfServiceTypes = SeqOfServiceTypes | None


class SimpleServiceTypesMixin[T: OptSeqOfServiceTypes](BaseModel):
    types: Annotated[T, Field(..., description="Service Types")]


class FullServiceTypesMixin[T: OptSeqOfServiceTypes](BaseModel):
    service_types: Annotated[T, Field(..., description="Service Types")]


class ServiceCategory(StrEnum):
    CORE = "core"
    AI = "ai"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptServiceCategory = ServiceCategory | None


class SimpleServiceCategoryMixin[T: OptServiceCategory](BaseModel):
    category: Annotated[T, Field(..., description="Service Category")]


class FullServiceCategoryMixin[T: OptServiceCategory](BaseModel):
    service_category: Annotated[T, Field(..., description="Service Category")]


ListOfServiceCategories = list[ServiceCategory]
OptListOfServiceCategories = ListOfServiceCategories | None
SeqOfServiceCategories = Sequence[ServiceCategory]
OptSeqOfServiceCategories = SeqOfServiceCategories | None


class SimpleServiceCategoriesMixin[T: OptSeqOfServiceCategories](BaseModel):
    categories: Annotated[T, Field(..., description="Service Categories")]


class FullServiceCategoriesMixin[T: OptSeqOfServiceCategories](BaseModel):
    service_categories: Annotated[T, Field(..., description="Service Categories")]
