from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class Order(StrEnum):
    ASC = "asc"
    DESC = "desc"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptOrder = Order | None


class OrderMixin[T: OptOrder](BaseModel):
    order: Annotated[T, Field(..., description="Order")]


ListOfOrders = list[Order]
OptListOfOrders = ListOfOrders | None
SeqOfOrders = Sequence[Order]
OptSeqOfOrders = SeqOfOrders | None


class OrdersMixin[T: OptSeqOfOrders](BaseModel):
    orders: Annotated[T, Field(..., description="Orders")]
