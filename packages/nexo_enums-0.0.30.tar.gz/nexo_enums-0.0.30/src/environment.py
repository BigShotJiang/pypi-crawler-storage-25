from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class Environment(StrEnum):
    LOCAL = "local"
    STAGING = "staging"
    PRODUCTION = "production"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptEnvironment = Environment | None


class EnvironmentMixin[T: OptEnvironment](BaseModel):
    environment: Annotated[T, Field(..., description="Environment")]


ListOfEnvironments = list[Environment]
OptListOfEnvironments = ListOfEnvironments | None
SeqOfEnvironments = Sequence[Environment]
OptSeqOfEnvironments = SeqOfEnvironments | None


class EnvironmentsMixin[T: OptSeqOfEnvironments](BaseModel):
    environments: Annotated[T, Field(..., description="Environments")]
