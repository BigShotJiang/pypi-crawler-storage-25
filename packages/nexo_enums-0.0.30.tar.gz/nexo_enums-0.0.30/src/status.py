from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class DataStatus(StrEnum):
    DELETED = "deleted"
    INACTIVE = "inactive"
    ACTIVE = "active"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptDataStatus = DataStatus | None


class SimpleDataStatusMixin[T: OptDataStatus](BaseModel):
    status: Annotated[T, Field(..., description="Status")]


class FullDataStatusMixin[T: OptDataStatus](BaseModel):
    data_status: Annotated[T, Field(..., description="Status")]


ListOfDataStatuses = list[DataStatus]
OptListOfDataStatuses = ListOfDataStatuses | None
SeqOfDataStatuses = Sequence[DataStatus]
OptSeqOfDataStatuses = SeqOfDataStatuses | None


class SimpleDataStatusesMixin[T: OptSeqOfDataStatuses](BaseModel):
    statuses: Annotated[T, Field(..., description="Statuses")]


class FullDataStatusesMixin[T: OptSeqOfDataStatuses](BaseModel):
    data_statuses: Annotated[T, Field(..., description="Statuses")]


FULL_DATA_STATUSES: ListOfDataStatuses = [
    DataStatus.ACTIVE,
    DataStatus.INACTIVE,
    DataStatus.DELETED,
]

BASIC_DATA_STATUSES: ListOfDataStatuses = [
    DataStatus.ACTIVE,
    DataStatus.INACTIVE,
]
