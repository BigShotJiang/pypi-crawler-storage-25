from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class Cardinality(StrEnum):
    MULTIPLE = "multiple"
    SINGLE = "single"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptCardinality = Cardinality | None


class CardinalityMixin[T: OptCardinality](BaseModel):
    cardinality: Annotated[T, Field(..., description="Cardinality")]


ListOfCardinalities = list[Cardinality]
OptListOfCardinalities = ListOfCardinalities | None
SeqOfCardinalities = Sequence[Cardinality]
OptSeqOfCardinalities = SeqOfCardinalities | None


class CardinalitiesMixin[T: OptSeqOfCardinalities](BaseModel):
    cardinalities: Annotated[T, Field(..., description="Cardinalities")]


class Relationship(StrEnum):
    # One origin
    ONE_TO_ONE = "one_to_one"
    ONE_TO_OPTIONAL_ONE = "one_to_optional_one"
    ONE_TO_MANY = "one_to_many"
    ONE_TO_OPTIONAL_MANY = "one_to_optional_many"
    # Opt one origin
    OPTIONAL_ONE_TO_ONE = "optional_one_to_one"
    OPTIONAL_ONE_TO_OPTIONAL_ONE = "optional_one_to_optional_one"
    OPTIONAL_ONE_TO_MANY = "optional_one_to_many"
    OPTIONAL_ONE_TO_OPTIONAL_MANY = "optional_one_to_optional_many"
    # Many origin
    MANY_TO_ONE = "many_to_one"
    MANY_TO_OPTIONAL_ONE = "many_to_optional_one"
    MANY_TO_MANY = "many_to_many"
    MANY_TO_OPTIONAL_MANY = "many_to_optional_many"
    # Opt many origin
    OPTIONAL_MANY_TO_ONE = "optional_many_to_one"
    OPTIONAL_MANY_TO_OPTIONAL_ONE = "optional_many_to_optional_one"
    OPTIONAL_MANY_TO_MANY = "optional_many_to_many"
    OPTIONAL_MANY_TO_OPTIONAL_MANY = "optional_many_to_optional_many"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptRelationship = Relationship | None


class RelationshipMixin[T: OptRelationship](BaseModel):
    relationship: Annotated[T, Field(..., description="Relationship")]


ListOfRelationships = list[Relationship]
OptListOfRelationships = ListOfRelationships | None
SeqOfRelationships = Sequence[Relationship]
OptSeqOfRelationships = SeqOfRelationships | None


class RelationshipsMixin[T: OptSeqOfRelationships](BaseModel):
    relationships: Annotated[T, Field(..., description="Relationships")]
