"""
Core observability SDK — configures OTel tracing, structured logging, and
optional integrations (Sentry, Logfire, Django).

All configuration is driven by environment variables.  The single entry point
is ``configure_observability(config)``.
"""

from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from dataclasses import dataclass, field
from importlib.metadata import PackageNotFoundError, version
from typing import Literal

from opentelemetry import context, trace
from opentelemetry.baggage import set_baggage
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.util.types import AttributeValue

from infinity_observability_sdk._logging import configure_logging

__all__ = [
    "ObservabilityConfig",
    "configure_observability",
    "agent_context",
    "get_tracer",
    "get_environment",
    "get_current_config",
    "instrument_django",
]


try:
    _sdk_version = version("infinity-observability-sdk")
except PackageNotFoundError:
    _sdk_version = "0.0.0"  # fallback when running from source without installation

_tracer: trace.Tracer | None = None
_config: ObservabilityConfig | None = None
_environment: str = "production"


@dataclass(frozen=True)
class ObservabilityConfig:
    """Configuration for :func:`configure_observability`."""

    business_unit_name: str
    service_name: str

    # ---------- optional integrations ----------
    instrument_pydantic_ai: bool = True
    instrument_httpx: bool = True
    sentry_dsn: str | None = None
    sentry_environment: str | None = None
    sentry_traces_sample_rate: float = 0.0

    # ---------- logging ----------
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"

    # ---------- advanced ----------
    additional_resource_attributes: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.business_unit_name.strip():
            raise ValueError("business_unit_name must not be empty or whitespace-only")
        if not self.service_name.strip():
            raise ValueError("service_name must not be empty or whitespace-only")
        if not 0.0 <= self.sentry_traces_sample_rate <= 1.0:
            raise ValueError("sentry_traces_sample_rate must be between 0.0 and 1.0")


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


def get_tracer(name: str | None = None) -> trace.Tracer:
    """Return a tracer scoped to *name* (defaults to the SDK tracer)."""
    if _tracer is not None and name is None:
        return _tracer
    return trace.get_tracer(name or "infinity_observability_sdk")


def get_current_config() -> ObservabilityConfig | None:
    """Return the current SDK configuration, or ``None`` if not yet configured."""
    return _config


def get_environment() -> str:
    """Return the resolved deployment environment (e.g. ``"production"``, ``"development"``).

    Sourced once from the ``ENVIRONMENT`` env var during :func:`configure_observability`
    and cached for the lifetime of the process.  Defaults to ``"production"`` if the
    variable is not set or if called before :func:`configure_observability`.
    """
    return _environment


def reset_for_testing() -> None:
    """Reset all global SDK state.  For use in tests only."""
    global _tracer, _config, _environment
    from infinity_observability_sdk._logging import reset_handler_for_testing

    _tracer = None
    _config = None
    _environment = "production"
    reset_handler_for_testing()


@contextmanager
def agent_context(
    agent_employee_equivalent: str,
    hourly_rate: float,
    agent_name: str,
    task_description: str,
    task_instance_identifier: str,
    approximate_person_hours: float,
    business_unit_name: str,
    service_name: str,
    **metadata: AttributeValue,
):
    """Context manager that creates a span with rich agent metadata and sets
    OTel baggage for downstream propagation.

    This is the **backward-compatible** public API consumed by agent services.
    """
    tracer = get_tracer()

    attributes = {
        "infinity_observability_sdk.agent_employee_equivalent": agent_employee_equivalent,
        "infinity_observability_sdk.hourly_rate": hourly_rate,
        "infinity_observability_sdk.business_unit_name": business_unit_name,
        "infinity_observability_sdk.service_name": service_name,
        "infinity_observability_sdk.agent_name": agent_name,
        "infinity_observability_sdk.task_description": task_description,
        "infinity_observability_sdk.task_instance_identifier": task_instance_identifier,
        "infinity_observability_sdk.approximate_person_hours": approximate_person_hours,
        "infinity_observability_sdk.ai_wattage": approximate_person_hours * hourly_rate,
        "infinity_observability_sdk.is_tracked_agent": "true",
        "infinity_observability_sdk.version": _sdk_version,
        **{str(k): v for k, v in metadata.items()},
    }

    baggage_items = {
        "infinity_observability_sdk.baggage.business_unit_name": business_unit_name,
        "infinity_observability_sdk.baggage.service_name": service_name,
        "infinity_observability_sdk.baggage.agent_name": agent_name,
        "infinity_observability_sdk.baggage.is_tracked_agent": "true",
    }

    # Set baggage on the current context.
    ctx = context.get_current()
    for key, value in baggage_items.items():
        ctx = set_baggage(key, value, ctx)
    token = context.attach(ctx)

    try:
        with tracer.start_as_current_span(
            f"agent:{agent_name}", attributes=attributes
        ) as span:
            yield span
    finally:
        context.detach(token)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def configure_observability(config: ObservabilityConfig) -> None:
    """One-call setup for the full observability stack.

    * Configures an OTel ``TracerProvider`` with an OTLP HTTP exporter.
    * Sets up structured logging (JSON in prod, console in dev) with OTel
      trace correlation via *structlog*.
    * Optionally initialises Sentry (requires ``infinity-observability-sdk[sentry]``).
    * Optionally enables Logfire auto-instrumentation for pydantic-ai / httpx
      (requires ``infinity-observability-sdk[logfire]``).
    """
    global _tracer, _config, _environment

    if _config is not None:
        logging.getLogger("infinity_observability_sdk").debug(
            "configure_observability() called more than once; already configured (v%s), skipping.",
            _sdk_version,
        )
        return

    endpoint = (os.environ.get("INFINITY_OBSERVABILITY_ENDPOINT") or "").strip()
    api_key = (os.environ.get("INFINITY_OBSERVABILITY_API_KEY") or "").strip()
    _environment = os.environ.get("ENVIRONMENT", "production")

    if not endpoint:
        raise RuntimeError(
            "INFINITY_OBSERVABILITY_ENDPOINT environment variable is required. Set it to the observability collector endpoint."
        )

    if not api_key:
        raise RuntimeError(
            "INFINITY_OBSERVABILITY_API_KEY environment variable is required. Set it to your observability API key."
        )

    # ---- OTel Resource ----
    resource_attrs = {
        "service.name": f"{config.business_unit_name}.{config.service_name}",
        "service.version": _sdk_version,
        "deployment.environment": _environment,
        **config.additional_resource_attributes,
    }
    resource = Resource.create(resource_attrs)

    # ---- TracerProvider ----
    provider = TracerProvider(resource=resource)

    otlp_exporter = OTLPSpanExporter(
        endpoint=f"{endpoint}/v1/traces",
        headers={"X-Api-Key": api_key},
    )
    provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
    trace.set_tracer_provider(provider)

    _tracer = trace.get_tracer("infinity_observability_sdk", _sdk_version)

    # ---- Structured logging (structlog) ----
    configure_logging(
        service_name=f"{config.business_unit_name}.{config.service_name}",
        log_level=config.log_level,
        environment=_environment,
    )

    # ---- Optional: Sentry ----
    if config.sentry_dsn:
        _configure_sentry(config)

    # ---- Optional: Logfire auto-instrumentation ----
    _configure_logfire(config)

    _config = config

    logger = logging.getLogger("infinity_observability_sdk")
    logger.info(
        "Observability initialised",
        extra={
            "otlp_endpoint": endpoint,
            "service": f"{config.business_unit_name}.{config.service_name}",
            "sdk_version": _sdk_version,
        },
    )


# ---------------------------------------------------------------------------
# Optional integrations (soft dependencies)
# ---------------------------------------------------------------------------


def instrument_django() -> None:
    """Activate OTel auto-instrumentation for Django.

    Traces incoming HTTP requests automatically (``http.method``, ``http.route``,
    ``http.status_code``, etc.). Must be called **before** the Django ASGI/WSGI
    app is loaded — typically at the top of ``core/asgi.py`` right after
    :func:`configure_observability`. Requires ``infinity-observability-sdk[django]``.
    """
    try:
        from opentelemetry.instrumentation.django import DjangoInstrumentor
    except ImportError:
        logging.getLogger("infinity_observability_sdk").warning(
            "opentelemetry-instrumentation-django is not installed. Install with: pip install infinity-observability-sdk[django]"
        )
        return

    DjangoInstrumentor().instrument()
    logging.getLogger("infinity_observability_sdk").info(
        "Django OTel auto-instrumentation enabled"
    )


def _configure_sentry(config: ObservabilityConfig) -> None:
    """Initialise Sentry if ``sentry-sdk`` is installed."""
    try:
        import sentry_sdk
    except ImportError:
        logger = logging.getLogger("infinity_observability_sdk")
        logger.warning(
            "sentry_dsn provided but sentry-sdk is not installed. Install with: pip install infinity-observability-sdk[sentry]"
        )
        return

    _ = sentry_sdk.init(
        dsn=config.sentry_dsn,
        environment=config.sentry_environment or _environment,
        traces_sample_rate=config.sentry_traces_sample_rate,
        send_default_pii=True,
        # Link Sentry transactions to OTel traces.
        instrumenter="otel",
    )


def _configure_logfire(config: ObservabilityConfig) -> None:
    """Enable Logfire auto-instrumentation if ``logfire`` is installed."""
    try:
        import logfire
    except ImportError:
        # Logfire not installed — skip silently.
        return

    # Logfire piggy-backs on the already-configured OTel TracerProvider.
    # We do NOT call logfire.configure() since we own the provider.
    if config.instrument_httpx:
        try:
            logfire.instrument_httpx(capture_all=True)
        except ImportError:
            pass  # httpx not installed; skip

    if config.instrument_pydantic_ai:
        try:
            logfire.instrument_pydantic_ai()
        except ImportError:
            pass  # pydantic-ai not installed; skip
