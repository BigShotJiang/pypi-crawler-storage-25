"""Tests for the core observability SDK."""

from __future__ import annotations

import json
import logging
import sys
from collections.abc import Iterator
from typing import Any, TypedDict
from unittest.mock import MagicMock, patch

import pytest
import structlog
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from infinity_observability_sdk import (
    ObservabilityConfig,
    agent_context,
    configure_logging,
    configure_observability,
    get_environment,
    get_tracer,
)
from infinity_observability_sdk.sdk import get_current_config, reset_for_testing


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_sdk() -> Iterator[None]:
    """Reset global SDK state between tests."""
    reset_for_testing()
    setattr(trace, "_TRACER_PROVIDER", None)
    set_once = getattr(trace, "_TRACER_PROVIDER_SET_ONCE")
    setattr(set_once, "_done", False)
    yield


@pytest.fixture()
def env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Set the required environment variables."""
    monkeypatch.setenv(
        "INFINITY_OBSERVABILITY_ENDPOINT", "https://collector.example.com"
    )
    monkeypatch.setenv("INFINITY_OBSERVABILITY_API_KEY", "test-key-123")


@pytest.fixture()
def otel_provider() -> InMemorySpanExporter:
    """TracerProvider backed by an in-memory exporter, set as the global provider."""
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    return exporter


# ---------------------------------------------------------------------------
# ObservabilityConfig
# ---------------------------------------------------------------------------


class _BlankNameKwargs(TypedDict, total=False):
    business_unit_name: str
    service_name: str


class TestObservabilityConfig:
    def test_defaults(self) -> None:
        config = ObservabilityConfig(business_unit_name="bu", service_name="svc")
        assert config.instrument_pydantic_ai is True
        assert config.instrument_httpx is True
        assert config.sentry_dsn is None
        assert config.sentry_traces_sample_rate == 0.0
        assert config.log_level == "INFO"
        assert config.additional_resource_attributes == {}

    def test_all_fields(self) -> None:
        config = ObservabilityConfig(
            business_unit_name="bu",
            service_name="svc",
            instrument_pydantic_ai=False,
            instrument_httpx=False,
            sentry_dsn="https://example@sentry.io/123",
            sentry_environment="staging",
            sentry_traces_sample_rate=0.5,
            log_level="DEBUG",
            additional_resource_attributes={"custom.attr": "value"},
        )
        assert config.instrument_pydantic_ai is False
        assert config.sentry_dsn == "https://example@sentry.io/123"
        assert config.sentry_traces_sample_rate == 0.5
        assert config.log_level == "DEBUG"
        assert config.additional_resource_attributes == {"custom.attr": "value"}

    def test_is_frozen(self) -> None:
        config = ObservabilityConfig(business_unit_name="bu", service_name="svc")
        with pytest.raises((AttributeError, TypeError)):
            config.service_name = "other"  # pyright: ignore[reportAttributeAccessIssue]

    @pytest.mark.parametrize(
        "kwargs",
        [
            {"business_unit_name": "", "service_name": "svc"},
            {"business_unit_name": "   ", "service_name": "svc"},
            {"business_unit_name": "bu", "service_name": ""},
            {"business_unit_name": "bu", "service_name": "   "},
        ],
    )
    def test_raises_on_blank_name(self, kwargs: _BlankNameKwargs) -> None:
        with pytest.raises(ValueError, match="must not be empty"):
            _ = ObservabilityConfig(**kwargs)

    @pytest.mark.parametrize("rate", [-0.1, 1.1, -1.0, 2.0])
    def test_raises_on_invalid_sample_rate(self, rate: float) -> None:
        with pytest.raises(ValueError, match="sentry_traces_sample_rate"):
            _ = ObservabilityConfig(
                business_unit_name="bu",
                service_name="svc",
                sentry_traces_sample_rate=rate,
            )

    @pytest.mark.parametrize("rate", [0.0, 0.5, 1.0])
    def test_valid_sample_rate_boundaries(self, rate: float) -> None:
        config = ObservabilityConfig(
            business_unit_name="bu", service_name="svc", sentry_traces_sample_rate=rate
        )
        assert config.sentry_traces_sample_rate == rate


# ---------------------------------------------------------------------------
# configure_observability
# ---------------------------------------------------------------------------


class TestConfigureObservability:
    @pytest.mark.parametrize(
        "endpoint,api_key,match",
        [
            (None, "key", "ENDPOINT"),
            ("   ", "key", "ENDPOINT"),
            ("https://example.com", None, "API_KEY"),
            ("https://example.com", "   ", "API_KEY"),
        ],
    )
    def test_raises_on_missing_or_whitespace_env_vars(
        self,
        monkeypatch: pytest.MonkeyPatch,
        endpoint: str | None,
        api_key: str | None,
        match: str,
    ) -> None:
        if endpoint is None:
            monkeypatch.delenv("INFINITY_OBSERVABILITY_ENDPOINT", raising=False)
        else:
            monkeypatch.setenv("INFINITY_OBSERVABILITY_ENDPOINT", endpoint)

        if api_key is None:
            monkeypatch.delenv("INFINITY_OBSERVABILITY_API_KEY", raising=False)
        else:
            monkeypatch.setenv("INFINITY_OBSERVABILITY_API_KEY", api_key)

        config = ObservabilityConfig(business_unit_name="bu", service_name="svc")
        with pytest.raises(RuntimeError, match=match):
            configure_observability(config)

    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_sets_up_tracer_provider(
        self, mock_processor: MagicMock, mock_exporter: MagicMock, env: None
    ) -> None:
        config = ObservabilityConfig(business_unit_name="bu", service_name="svc")
        configure_observability(config)

        mock_exporter.assert_called_once_with(
            endpoint="https://collector.example.com/v1/traces",
            headers={"X-Api-Key": "test-key-123"},
        )
        mock_processor.assert_called_once_with(mock_exporter.return_value)
        assert isinstance(trace.get_tracer_provider(), TracerProvider)

    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_stores_config_and_tracer(
        self, mock_processor: MagicMock, mock_exporter: MagicMock, env: None
    ) -> None:
        config = ObservabilityConfig(business_unit_name="bu", service_name="svc")
        configure_observability(config)
        assert get_current_config() is config
        assert get_tracer() is not None

    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_idempotent_second_call_is_no_op(
        self, mock_processor: MagicMock, mock_exporter: MagicMock, env: None
    ) -> None:
        config = ObservabilityConfig(business_unit_name="bu", service_name="svc")
        configure_observability(config)
        configure_observability(config)

        assert get_current_config() is config
        mock_exporter.assert_called_once()  # not twice

    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_sentry_not_initialised_without_dsn(
        self, mock_processor: MagicMock, mock_exporter: MagicMock, env: None
    ) -> None:
        config = ObservabilityConfig(business_unit_name="bu", service_name="svc")
        with patch("infinity_observability_sdk.sdk._configure_sentry") as mock_sentry:
            configure_observability(config)
            mock_sentry.assert_not_called()

    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_sentry_initialised_with_dsn(
        self, mock_processor: MagicMock, mock_exporter: MagicMock, env: None
    ) -> None:
        config = ObservabilityConfig(
            business_unit_name="bu",
            service_name="svc",
            sentry_dsn="https://example@sentry.io/123",
        )
        with patch("infinity_observability_sdk.sdk._configure_sentry") as mock_sentry:
            configure_observability(config)
            mock_sentry.assert_called_once_with(config)

    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_configures_structlog(
        self, mock_processor: MagicMock, mock_exporter: MagicMock, env: None
    ) -> None:
        configure_observability(
            ObservabilityConfig(business_unit_name="bu", service_name="svc")
        )
        assert structlog.get_logger("test") is not None


# ---------------------------------------------------------------------------
# get_environment
# ---------------------------------------------------------------------------


class TestGetEnvironment:
    def test_defaults_to_production_before_configure(self) -> None:
        assert get_environment() == "production"

    @pytest.mark.parametrize(
        "env_value,expected",
        [
            ("staging", "staging"),
            ("development", "development"),
            ("production", "production"),
        ],
    )
    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_reflects_environment_env_var(
        self,
        mock_processor: MagicMock,
        mock_exporter: MagicMock,
        env_value: str,
        expected: str,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("INFINITY_OBSERVABILITY_ENDPOINT", "https://example.com")
        monkeypatch.setenv("INFINITY_OBSERVABILITY_API_KEY", "key")
        monkeypatch.setenv("ENVIRONMENT", env_value)
        configure_observability(
            ObservabilityConfig(business_unit_name="bu", service_name="svc")
        )
        assert get_environment() == expected

    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_defaults_to_production_when_env_var_absent(
        self,
        mock_processor: MagicMock,
        mock_exporter: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("INFINITY_OBSERVABILITY_ENDPOINT", "https://example.com")
        monkeypatch.setenv("INFINITY_OBSERVABILITY_API_KEY", "key")
        monkeypatch.delenv("ENVIRONMENT", raising=False)
        configure_observability(
            ObservabilityConfig(business_unit_name="bu", service_name="svc")
        )
        assert get_environment() == "production"


# ---------------------------------------------------------------------------
# get_tracer
# ---------------------------------------------------------------------------


class TestGetTracer:
    @patch("infinity_observability_sdk.sdk.OTLPSpanExporter")
    @patch("infinity_observability_sdk.sdk.BatchSpanProcessor")
    def test_returns_tracer_after_configure(
        self, mock_processor: MagicMock, mock_exporter: MagicMock, env: None
    ) -> None:
        configure_observability(
            ObservabilityConfig(business_unit_name="bu", service_name="svc")
        )
        assert get_tracer() is not None

    def test_returns_fallback_tracer_before_configure(self) -> None:
        assert get_tracer() is not None

    def test_returns_named_tracer(self) -> None:
        assert get_tracer("my_service.module") is not None


# ---------------------------------------------------------------------------
# agent_context
# ---------------------------------------------------------------------------


# Any annotation avoids TypedDict-spreading limitations with **metadata: AttributeValue
_AGENT_KWARGS: Any = {
    "agent_employee_equivalent": "data_engineer",
    "hourly_rate": 75.0,
    "agent_name": "test_agent",
    "task_description": "test task",
    "task_instance_identifier": "test-123",
    "approximate_person_hours": 2.0,
    "business_unit_name": "test_bu",
    "service_name": "test_service",
}


class TestAgentContext:
    def test_span_attributes(self, otel_provider: InMemorySpanExporter) -> None:
        with agent_context(**_AGENT_KWARGS) as span:
            assert span is not None
            assert span.is_recording()

        spans = otel_provider.get_finished_spans()
        assert len(spans) == 1
        attrs = spans[0].attributes
        assert attrs is not None
        assert spans[0].name == "agent:test_agent"
        assert (
            attrs["infinity_observability_sdk.agent_employee_equivalent"]
            == "data_engineer"
        )
        assert attrs["infinity_observability_sdk.hourly_rate"] == 75.0
        assert attrs["infinity_observability_sdk.business_unit_name"] == "test_bu"
        assert attrs["infinity_observability_sdk.service_name"] == "test_service"
        assert attrs["infinity_observability_sdk.agent_name"] == "test_agent"
        assert attrs["infinity_observability_sdk.ai_wattage"] == 150.0  # 2.0 * 75.0
        assert attrs["infinity_observability_sdk.is_tracked_agent"] == "true"

    def test_extra_metadata_forwarded_to_span(
        self, otel_provider: InMemorySpanExporter
    ) -> None:
        with agent_context(**_AGENT_KWARGS, custom_field="val", numeric=42):
            pass
        attrs = otel_provider.get_finished_spans()[0].attributes
        assert attrs is not None
        assert attrs["custom_field"] == "val"
        assert attrs["numeric"] == 42

    def test_baggage_set_inside_context(
        self, otel_provider: InMemorySpanExporter
    ) -> None:
        from opentelemetry import context
        from opentelemetry.baggage import get_baggage

        with agent_context(**_AGENT_KWARGS):
            ctx = context.get_current()
            assert (
                get_baggage(
                    "infinity_observability_sdk.baggage.business_unit_name", ctx
                )
                == "test_bu"
            )
            assert (
                get_baggage("infinity_observability_sdk.baggage.service_name", ctx)
                == "test_service"
            )
            assert (
                get_baggage("infinity_observability_sdk.baggage.agent_name", ctx)
                == "test_agent"
            )
            assert (
                get_baggage("infinity_observability_sdk.baggage.is_tracked_agent", ctx)
                == "true"
            )

    def test_baggage_cleared_after_context(
        self, otel_provider: InMemorySpanExporter
    ) -> None:
        from opentelemetry import context
        from opentelemetry.baggage import get_baggage

        with agent_context(**_AGENT_KWARGS):
            pass

        ctx = context.get_current()
        assert (
            get_baggage("infinity_observability_sdk.baggage.business_unit_name", ctx)
            is None
        )


# ---------------------------------------------------------------------------
# configure_logging
# ---------------------------------------------------------------------------


class TestConfigureLogging:
    def test_sets_log_level_and_stdout_handler(self) -> None:
        configure_logging(service_name="test.service", log_level="DEBUG")
        root = logging.getLogger()
        assert root.level == logging.DEBUG
        assert any(
            isinstance(h, logging.StreamHandler) and h.stream is sys.stdout
            for h in root.handlers
        )

    @pytest.mark.parametrize(
        "environment,expect_json",
        [("production", True), ("development", False)],
    )
    def test_log_format(
        self,
        environment: str,
        expect_json: bool,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        monkeypatch.setenv("ENVIRONMENT", environment)
        configure_logging(service_name="test.service", log_level="INFO")
        logging.getLogger("test.format").info("hello")

        out = capsys.readouterr().out.strip()
        if expect_json:
            data = json.loads(out)
            assert data["event"] == "hello"
            assert data["service"] == "test.service"
        else:
            with pytest.raises(json.JSONDecodeError):
                json.loads(out)
            assert "hello" in out

    def test_preserves_existing_handlers(self) -> None:
        pre_existing = logging.StreamHandler(sys.stderr)
        root = logging.getLogger()
        root.addHandler(pre_existing)
        try:
            configure_logging(service_name="test.service")
            assert pre_existing in root.handlers
        finally:
            root.removeHandler(pre_existing)

    def test_no_duplicate_handler_on_reconfigure(self) -> None:
        configure_logging(service_name="test.service")
        configure_logging(service_name="test.service")
        stdout_handlers = [
            h
            for h in logging.getLogger().handlers
            if isinstance(h, logging.StreamHandler) and h.stream is sys.stdout
        ]
        assert len(stdout_handlers) == 1


# ---------------------------------------------------------------------------
# Sentry integration
# ---------------------------------------------------------------------------


class TestSentryIntegration:
    def test_warns_when_sentry_not_installed(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        import infinity_observability_sdk.sdk as sdk_module

        configure_sentry = getattr(sdk_module, "_configure_sentry")
        config = ObservabilityConfig(
            business_unit_name="bu",
            service_name="svc",
            sentry_dsn="https://example@sentry.io/123",
        )
        with patch.dict("sys.modules", {"sentry_sdk": None}):
            configure_sentry(config)

        assert any("sentry" in r.message.lower() for r in caplog.records)

    @pytest.mark.parametrize(
        "sentry_env,global_env,expected_env",
        [
            ("staging", "production", "staging"),  # explicit sentry_environment wins
            (None, "staging", "staging"),  # falls back to global _environment
            (None, "production", "production"),  # falls back to default
        ],
    )
    def test_sentry_environment_resolution(
        self,
        monkeypatch: pytest.MonkeyPatch,
        sentry_env: str | None,
        global_env: str,
        expected_env: str,
    ) -> None:
        import infinity_observability_sdk.sdk as sdk_module

        monkeypatch.setattr(sdk_module, "_environment", global_env)
        configure_sentry = getattr(sdk_module, "_configure_sentry")
        mock_sentry = MagicMock()

        config = ObservabilityConfig(
            business_unit_name="bu",
            service_name="svc",
            sentry_dsn="https://example@sentry.io/123",
            sentry_environment=sentry_env,
            sentry_traces_sample_rate=0.5,
        )
        with patch.dict("sys.modules", {"sentry_sdk": mock_sentry}):
            configure_sentry(config)

        assert mock_sentry.init.call_args.kwargs["environment"] == expected_env
