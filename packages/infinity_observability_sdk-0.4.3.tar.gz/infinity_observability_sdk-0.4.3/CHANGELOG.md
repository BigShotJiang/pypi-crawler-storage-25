# CHANGELOG


## v0.4.3 (2026-04-02)

### Bug Fixes

- **sdk**: Include sdk_version in observability initialised log message
  ([`6b12e1c`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/6b12e1c28189163683b1845b1313e7cdaaff0add))


## v0.4.2 (2026-04-02)

### Bug Fixes

- **sdk**: Include sdk version in idempotency debug log message
  ([`30dffa5`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/30dffa5cb6c5548578cc86568ab3b51f53ba789e))

### Continuous Integration

- Add pypi environment to release job for OIDC trusted publisher
  ([`4bce7f5`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/4bce7f54eb1b1e0d6c433d77ccaf39c775189817))


## v0.4.1 (2026-04-02)

### Bug Fixes

- **sdk**: Use agent_name in span name for distinguishable traces
  ([`67628ed`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/67628ed2bb1a510dfe718267a6fd11f081e6814d))

Hard-coded span name 'agent_context' made all agent spans identical in trace UIs regardless of which
  agent produced them. Changed to 'agent:<name>' so each agent has a unique, human-readable span
  name.

### Build System

- **deps**: Add python-semantic-release to dev deps; set explicit angular commit_parser
  ([`a7062f4`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/a7062f4692e7378bef31d966261d2138b128679b))

### Continuous Integration

- Merge PyPI publish into release.yml to fix GITHUB_TOKEN event block
  ([`3050373`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/305037383434debc707724bef5509636274c5e75))

### Documentation

- **docs**: Update AGENTS.md to reflect post-hardening repo state
  ([`477babc`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/477babc46e88edfca9f7adc0194a28fe2cf7ac19))


## v0.4.0 (2026-03-25)

### Code Style

- Ruff format sdk.py
  ([`29c4e77`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/29c4e7746b9ad7341d4f46de832d14934d0814ce))

### Continuous Integration

- Extract Python/uv setup into composite action for single version source
  ([`66a1cba`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/66a1cba832edd7fea1c79509e643c12e897cc37e))

- Pin Python to 3.12 in setup action — python-version-file resolved to 3.14
  ([`bf098f9`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/bf098f94824c1b39560a19b20bc072d4c8c67de2))

- Read Python version from pyproject.toml requires-python
  ([`bdd250e`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/bdd250e514883962b3bc14a15fecc80a4903cf21))

- Remove push trigger from ci.yml — covered by release.yml on main
  ([`ec04dc4`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/ec04dc411e7a72f1134a8dd709a48b2a20044894))

- Rename job to 'check' to avoid redundant CI / ci label in GitHub
  ([`505475e`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/505475e1db557aa24d396709bada7b0d90e89f02))

### Features

- **sdk**: Harden SDK, add release automation, and improve DX
  ([`2cdfaae`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/2cdfaaee058ef1204965342467fea6f7ea9d52f2))

Public API: - Export instrument_django and get_current_config from top-level __init__.py - Add
  get_environment() — ENVIRONMENT env var read once at configure time - ObservabilityConfig
  frozen=True with __post_init__ validation (empty/whitespace names, sentry_traces_sample_rate
  bounds) - configure_observability() is now truly idempotent (no-op on second call) - _SDK_VERSION
  sourced from importlib.metadata — single source of truth

Defensive fixes: - Whitespace-only INFINITY_OBSERVABILITY_ENDPOINT/API_KEY now raises RuntimeError -
  reset_handler_for_testing() actually removes handler from root logger - Handler management:
  preserve existing handlers, no duplicate on reconfigure

CI/CD: - Replace scripts/run-ci.sh with Makefile (install, lint, lint-fix, format, format-check,
  test, test-verbose, build, check, ci) - Makefile uses uv build and uvx twine check (no build/twine
  dev deps) - Add release.yml: on push to main, runs make ci then python-semantic-release for fully
  automated versioning, tagging, and GitHub Release creation - deploy-to-pypi.yml: remove redundant
  CI job (already ran in release.yml), add tag/version validation step - Conventional commits drive
  semver bumps automatically

Code quality: - basedpyright: 0 errors, 0 warnings across all source and test files - Tests: 45
  parametrized tests (up from 21), DRY fixtures, otel_provider fixture eliminates repeated setup,
  _AGENT_KWARGS constant, _BlankNameKwargs TypedDict for precise parametrize typing - ruff format
  applied

Docs: - README: full usage docs, configuration reference, Django/logging/agent_context examples,
  release cycle explanation, commit convention table, CI badges - AGENTS.md: updated build commands
  (make), release workflow, versioning, removed stale run-ci.sh and OBSERVABILITY_DECISIONS.md
  references - .gitignore: replaced with toptal template (python/macos/linux/windows/
  vscode/jetbrains) + AI coding tools section (Claude, Cursor, Aider, etc.)

### Refactoring

- **sdk**: Fold instrument_django into sdk.py, delete _django.py
  ([`22cd93b`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/22cd93bcf7959eb83e670898f76905c91e8f8337))

- **sdk**: Inline version lookup, rename _SDK_VERSION to _sdk_version
  ([`323580d`](https://github.com/infinity-constellation/infinity-observability-sdk/commit/323580dc11ed3fd5a836574e48f91a7fef3e16d1))


## v0.3.0 (2026-02-09)
