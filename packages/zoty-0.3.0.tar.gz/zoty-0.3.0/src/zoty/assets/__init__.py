"""Bundled zoty assets."""
