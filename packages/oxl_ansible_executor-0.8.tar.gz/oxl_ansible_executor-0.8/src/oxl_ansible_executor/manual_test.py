#!/usr/bin/env python3
from time import sleep
from os import environ
from pathlib import Path
from sys import path as sys_path

sys_path.append(str(Path(__file__).parent.parent))

# pylint: disable=C0413
from oxl_ansible_executor.runner_execution import Execution
from oxl_ansible_executor.runner_config import ExecutionConfig

BECOME = environ.get('AR_TEST_BECOME')

def test_local():
    c = ExecutionConfig(
        debug=True,
        playbook_dir='/home/rath/code/ansible',
        playbook_file='infra_squid.yml',
        inventory_files='inv/sup/hosts.yml',
        limit='gw01',
        vault_pass_file='/home/rath/.vault/d.txt',
        become_pass_value=BECOME,
        ssh_key_file='/home/rath/.ssh/id_ed25519',
        ssh_known_hosts_file='/home/rath/.ssh/known_hosts',
        tags='config',
        mode_check=True,
        mode_diff=True,
        env_vars={'AW_TEST': 'me-me-me'},
        stats_live=True,
        stats_recap=True,
        load_log_stderr=True,
        load_log_stdout=True,
    )
    e = Execution(c)

    e.run(blocking=True)
    print(e.status)


def test_local_non_blocking():
    c = ExecutionConfig(
        debug=True,
        playbook_dir='/home/rath/code/ansible',
        playbook_file='infra_squid.yml',
        inventory_files='inv/sup/hosts.yml',
        limit='gw01',
        vault_pass_file='/home/rath/.vault/d.txt',
        become_pass_value=BECOME,
        ssh_key_file='/home/rath/.ssh/id_ed25519',
        ssh_known_hosts_file='/home/rath/.ssh/known_hosts',
        # tags='config',
        mode_check=True,
        mode_diff=True,
        env_vars={'AW_TEST': 'me-me-me'},
        stats_live=True,
        stats_recap=True,
        load_log_stderr=True,
        load_log_stdout=True,
    )
    e = Execution(c)

    e.run(blocking=False)
    sleep(5)
    print(e.status)
    sleep(12)
    print(e.status)
    e.stop()
    sleep(2)
    print(e.status)


def test_container_podman():
    c = ExecutionConfig(
        debug=True,
        containerized=True,
        container_engine='podman',
        playbook_dir='/home/rath/code/ansible',
        playbook_file='infra_squid.yml',
        inventory_files='inv/sup/hosts.yml',
        limit='gw01',
        vault_pass_file='/home/rath/.vault/d.txt',
        become_pass_value=BECOME,
        ssh_key_file='/home/rath/.ssh/id_ed25519',
        ssh_known_hosts_file='/home/rath/.ssh/known_hosts',
        tags='config',
        mode_check=True,
        mode_diff=True,
    )
    e = Execution(c)

    e.run(blocking=True)
    print(e.status)


def test_container_docker():
    c = ExecutionConfig(
        debug=True,
        containerized=True,
        container_engine='docker',
        playbook_dir='/home/rath/code/ansible',
        playbook_file='infra_squid.yml',
        inventory_files='inv/sup/hosts.yml',
        limit='gw01',
        vault_pass_file='/home/rath/.vault/d.txt',
        become_pass_value=BECOME,
        ssh_key_file='/home/rath/.ssh/id_ed25519',
        ssh_known_hosts_file='/home/rath/.ssh/known_hosts',
        tags='config',
        mode_check=True,
        mode_diff=True,
    )
    e = Execution(c)

    e.run(blocking=True)
    print(e.status)


test_local()
