"""Package data for hamnosys."""
