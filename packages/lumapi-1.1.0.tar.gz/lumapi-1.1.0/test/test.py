from LumAPI import *

x = np.linspace(0, 1, 100)
y = np.linspace(0, 1, 100)
X, Y = np.meshgrid(x, y)
E = np.ones_like(X)

data = {
    'x': x,
    'y': y,
    'E': E
}
savemat('test.mat', data)





