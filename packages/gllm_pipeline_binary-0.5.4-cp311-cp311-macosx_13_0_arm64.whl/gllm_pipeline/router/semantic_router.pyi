from _typeshed import Incomplete
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_pipeline.router.backend import AurelioSimilarityAdapter as AurelioSimilarityAdapter, NativeSimilarityAdapter as NativeSimilarityAdapter
from gllm_pipeline.router.backend.aurelio.index.aurelio_index import BaseAurelioIndex as BaseAurelioIndex
from gllm_pipeline.router.backend.base_adapter import BaseAdapter as BaseAdapter
from gllm_pipeline.router.router import BaseRouter as BaseRouter
from gllm_pipeline.router.schema import BackendType as BackendType, ModalityType as ModalityType, SemanticRouterStrategy as SemanticRouterStrategy
from semantic_router.encoders.base import DenseEncoder
from typing import Any

DEFAULT_SIMILARITY_THRESHOLD: float
BACKEND_ADAPTER_MAPPING: dict[BackendType, dict[SemanticRouterStrategy, type[BaseAdapter]]]

class SemanticRouter(BaseRouter):
    """A backend-agnostic router using semantic similarity.

    This router delegates all routing logic to a pluggable backend implementation,
    supporting multiple semantic routing algorithms (Aurelio, Similarity-based, etc.).

    The router provides a unified interface regardless of the underlying algorithm,
    allowing users to switch backends without changing their code.

    Supported backends:
        1. BackendType.AURELIO: Aurelio Labs semantic router (via `SemanticRouter.aurelio`).
        2. BackendType.NATIVE: Native GLLM semantic router (via `SemanticRouter.native`).


    Attributes:
        backend (BaseAdapter): The backend implementation handling routing logic.
        default_route (str): The default route to be used if no similar route is found.
        valid_routes (set[str]): A set of valid routes for the router.
    """
    backend: Incomplete
    def __init__(self, backend: BaseAdapter, default_route: str, valid_routes: set[str]) -> None:
        """Initialize the SemanticRouter.

        Args:
            backend (BaseAdapter): The backend implementation for routing.
            default_route (str): The default route to be used if no similar route is found.
            valid_routes (set[str]): A set of valid routes for the router.

        Raises:
            ValueError: If backend is not a BaseAdapter instance.
        """
    @classmethod
    def from_preset(cls, backend: BackendType | str, preset_name: str, modality: ModalityType | str = ..., strategy: SemanticRouterStrategy | None = ..., default_route: str | None = None, valid_routes: set[str] | None = None, **kwargs: Any) -> SemanticRouter:
        '''Create router from preset configuration.

        Uses the adapter\'s ``from_preset`` method to initialize the backend with
        preset route data, then wraps it in a SemanticRouter.

        Examples:
            ```python
            router = SemanticRouter.from_preset(
                backend=BackendType.AURELIO,
                modality="image",
            )
            ```
        Args:
            backend (BackendType | str): Backend to use. Currently only ``BackendType.AURELIO``
                (or the string ``"aurelio"``) is supported.
            preset_name (str): Name of the preset to use.
            modality (ModalityType | str, optional): Modality type for the preset.
                Defaults to ModalityType.IMAGE.
            strategy (SemanticRouterStrategy | None, optional): Routing strategy
                (e.g., SemanticRouterStrategy.SIMILARITY). Defaults to SemanticRouterStrategy.SIMILARITY.
            default_route (str | None, optional): Default route if no match found. If not provided,
                the first key of the preset routes is used. Defaults to None.
            valid_routes (set[str] | None, optional): Set of valid route names. If not provided,
                the keys of the preset routes are used. Defaults to None.
            **kwargs (Any): Backend and preset-specific arguments. May include `encoder` and `routes`.

        Returns:
            SemanticRouter: Initialized router instance.

        Raises:
            ValueError: If the backend does not support preset initialization.
        '''
    @classmethod
    def from_file(cls, backend_type: BackendType, strategy: SemanticRouterStrategy, file_path: str, default_route: str, valid_routes: set[str], **kwargs: Any) -> SemanticRouter:
        """Create a new SemanticRouter instance from a file.

        Args:
            backend_type (BackendType): Type of backend (BackendType.AURELIO or BackendType.NATIVE).
            strategy (SemanticRouterStrategy): Routing strategy (e.g., SIMILARITY).
            file_path (str): The path to the file containing the routes. Must be JSON or YAML.
            default_route (str): The default route to be used if no similar route is found.
            valid_routes (set[str]): A set of valid routes for the router.
            **kwargs: Additional arguments for backend initialization (e.g., encoder, em_invoker).

        Returns:
            SemanticRouter: A new instance of the SemanticRouter class.

        Raises:
            ValueError:
            1. If backend_type or strategy is not found in mapping.
            2. If failed to create adapter from file.
        """
    @classmethod
    def aurelio(cls, default_route: str, valid_routes: set[str], encoder: DenseEncoder | BaseEMInvoker, strategy: SemanticRouterStrategy | None = ..., similarity_threshold: float = ..., route_examples: dict[str, list[str | bytes]] | None = None, index: BaseAurelioIndex | None = None, **kwargs: Any) -> SemanticRouter:
        '''Create semantic router with Aurelio backend similarity routing.

        Uses Aurelio Labs semantic router for advanced semantic similarity routing.
        Supports custom encoders and vector store indexes.

        Examples:
            ```python
            from gllm_inference.em_invoker import build_em_invoker
            em_invoker = build_em_invoker("openai/text-embedding-3-small", credentials="sk-")
            router = SemanticRouter.aurelio(
                default_route="general",
                valid_routes={"greeting", "help", "general"},
                encoder=em_invoker,
                route_examples={
                    "greeting": ["hi", "hello", "hey"],
                    "help": ["help me", "assist", "support"],
                }
            )
            ```

        Args:
            default_route (str): Default route if no match found.
            valid_routes (set[str]): Set of valid route names.
            encoder (DenseEncoder | BaseEMInvoker): Dense encoder or EM invoker (required).
            strategy (SemanticRouterStrategy, optional): Routing strategy. Defaults to SIMILARITY.
            similarity_threshold (float, optional): Similarity threshold for routing. Defaults to
                DEFAULT_SIMILARITY_THRESHOLD.
            route_examples (dict[str, list[str | bytes]] | None, optional): Route examples. Defaults to None.
            index (BaseAurelioIndex | None, optional): Custom vector store index. Defaults to None.
            **kwargs (Any): Additional Aurelio-specific arguments (e.g., auto_sync).

        Returns:
            SemanticRouter: Initialized router instance.

        Raise:
            ValueError: If strategy is not supported for Aurelio backend.
        '''
    @classmethod
    def native(cls, default_route: str, valid_routes: set[str], em_invoker: BaseEMInvoker, strategy: SemanticRouterStrategy = ..., similarity_threshold: float = ..., route_examples: dict[str, list[str]] | None = None, route_embeddings: dict[str, list[list[float]]] | None = None) -> SemanticRouter:
        '''Create semantic router with native backend similarity routing.

        Uses native gllm-inference cosine similarity for fast, simple routing.
        No training required. Best for small to medium-sized route sets.

        Args:
            default_route (str): Default route if no match found.
            valid_routes (set[str]): Set of valid route names.
            em_invoker (BaseEMInvoker): EM invoker for vectorization.
            strategy (SemanticRouterStrategy, optional): Routing strategy.
                Defaults to SemanticRouterStrategy.SIMILARITY.
            similarity_threshold (float, optional): Minimum similarity score (0-1).
                Defaults to DEFAULT_SIMILARITY_THRESHOLD.
            route_examples (dict[str, list[str]] | None, optional): Route examples. Defaults to None.
            route_embeddings (dict[str, list[list[float]]] | None, optional): Route embeddings. Defaults to None.

        Returns:
            SemanticRouter: Initialized router instance.

        Examples:
            ```python
            from gllm_inference.em_invoker import build_em_invoker
            em_invoker = build_em_invoker(...)
            router = SemanticRouter.native(
                default_route="general",
                valid_routes={"greeting", "help", "general"},
                em_invoker=em_invoker,
                route_examples={
                    "greeting": ["hi", "hello", "hey"],
                    "help": ["help me", "assist", "support"],
                },
                similarity_threshold=0.7
            )
            ```

        Raise:
            ValueError: If strategy is not supported for Native backend.
        '''
