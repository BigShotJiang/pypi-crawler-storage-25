from _typeshed import Incomplete
from pydantic import BaseModel
from typing import Any

RESERVED_HYPERPARAMETER_KEYS: Incomplete

class SVMConfig(BaseModel):
    """Configuration for the SVM classifier.

    Attributes:
        num_classes (int): Number of output classes (models to route to).
    """
    num_classes: int

class MLPConfig(BaseModel):
    '''Configuration for the MLP classifier.

    Attributes:
        num_classes (int): Number of output classes (models to route to).
        input_dim (int): Dimensionality of the input embeddings.
        idx_to_model (dict[int, str]): Mapping from predicted class index to model name.
        hidden_layer_sizes (list[int]): Sizes of hidden layers.
        activation (str): Activation function name. Defaults to "relu".
        hyperparameters (dict[str, Any]): Additional hyperparameters. Defaults to {}.
    '''
    num_classes: int
    input_dim: int
    idx_to_model: dict[int, str]
    hidden_layer_sizes: list[int]
    activation: str
    hyperparameters: dict[str, Any]
    def build_hyperparameter(self, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
        """Build final hyperparameter dict with safe merging.

        Merges core config params, stored hyperparameters, and runtime overrides
        with protection against overriding reserved keys.

        Args:
            overrides (dict[str, Any], optional): Runtime hyperparameter overrides.
                Cannot override reserved keys (hidden_layer_sizes, activation).
                Defaults to None.

        Returns:
            dict[str, Any]: Final merged hyperparameter dictionary.

        Raises:
            ValueError: If overrides attempt to modify reserved keys.
        """
