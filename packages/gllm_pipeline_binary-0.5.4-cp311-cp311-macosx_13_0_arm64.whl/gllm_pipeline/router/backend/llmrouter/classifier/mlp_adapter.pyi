from _typeshed import Incomplete
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_pipeline.router.backend.llmrouter.classifier.llmrouter_adapter import LLMRouterBaseAdapter as LLMRouterBaseAdapter
from gllm_pipeline.router.backend.llmrouter.config import MLPConfig as MLPConfig
from gllm_pipeline.router.backend.llmrouter.utils import embedding_to_tensor as embedding_to_tensor
from typing import Any

class LLMRouterMLPAdapter(LLMRouterBaseAdapter):
    """Adapter for LLMRouter MLP-based classification routing.

    Bypasses MLPRouter.__init__ (training-coupled) via MLPRouter.__new__,
    reconstructing only the inference shell from MLPConfig metadata.

    Attributes:
        encoder (BaseEMInvoker | None): EM Invoker instance for custom embeddings.
            If None, uses llmrouter's built-in Longformer.
        router (MLPRouter): Initialized MLPRouter inference shell.
        device (str): Device for model inference.
    """
    device: Incomplete
    def __init__(self, model_path: str, config: MLPConfig, encoder: BaseEMInvoker | None = None, device: str = 'cpu', hyperparameters: dict[str, Any] | None = None) -> None:
        '''Initialize the MLP adapter.

        Args:
            model_path (str): Path to the trained MLP classifier model file.
            config (MLPConfig): Configuration holding inference metadata
                (idx_to_model, input_dim, hidden_layer_sizes, activation, num_classes).
                Must match the trained model weights.
            encoder (BaseEMInvoker | None, optional): EM Invoker instance for custom embeddings.
                If None, uses llmrouter\'s built-in Longformer. Defaults to None.
            device (str, optional): Device for model inference. Defaults to "cpu".
            hyperparameters (dict[str, Any] | None, optional): Runtime hyperparameter overrides.
                Cannot override reserved keys (hidden_layer_sizes, activation).
                Defaults to None.
        '''
