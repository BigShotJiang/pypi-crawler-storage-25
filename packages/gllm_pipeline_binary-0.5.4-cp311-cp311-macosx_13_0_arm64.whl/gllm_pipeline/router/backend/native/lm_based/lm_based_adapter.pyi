from _typeshed import Incomplete
from gllm_inference.request_processor import LMRequestProcessor
from gllm_pipeline.router.backend.base_adapter import BaseAdapter as BaseAdapter
from gllm_pipeline.router.preset.lm_based.image_domain_specific import DEFAULT_MODEL_ID as DEFAULT_MODEL_ID, IMAGE_ROUTER_SYSTEM_PROMPT as IMAGE_ROUTER_SYSTEM_PROMPT, IMAGE_ROUTER_USER_PROMPT as IMAGE_ROUTER_USER_PROMPT
from typing import Any

DEFAULT_LM_OUTPUT_KEY: str
DEFAULT_PRESET_MAPPING: dict[str, tuple[str, str, str]]
DEFAULT_OUTPUT_TRANSFORMER: Incomplete

class NativeLMBasedAdapter(BaseAdapter):
    """Native LM-based router backend adapter.

    This adapter implements LM-based routing using gllm-inference LMRequestProcessor.
    It extracts the route from LM output and returns it, or None if unable to determine.

    Attributes:
        lm_request_processor (LMRequestProcessor): The request processor that handles
            requests to the language model.
        lm_output_key (str): The key in the language model's output that contains the route.
    """
    lm_request_processor: Incomplete
    lm_output_key: Incomplete
    def __init__(self, lm_request_processor: LMRequestProcessor, lm_output_key: str = ...) -> None:
        """Initialize the LM-based adapter.

        Args:
            lm_request_processor (LMRequestProcessor): The request processor that handles
                requests to the language model.
            lm_output_key (str, optional): The key in the language model's output that
                contains the route. Defaults to DEFAULT_LM_OUTPUT_KEY.
        """
    async def route(self, source: str | bytes, route_filter: set[str] | None = None, **kwargs: Any) -> str | None:
        """Route using LM-based algorithm.

        Processes the input through a language model and extracts the route from the output.
        Returns None if unable to determine a valid route.

        The algorithm:
        1. Processes input through LM request processor
        2. Extracts route from dict or LMOutput
        3. Validates route against optional filter
        4. Returns route or None if any step fails

        Args:
            source (str | bytes): The input source to be routed.
            route_filter (set[str] | None, optional): Allowlist of routes to consider.
                If provided, only routes in the set are considered. Defaults to None.
            **kwargs (Any): Additional routing parameters (ignored).

        Returns:
            str | None: The selected route name, or None if unable to determine route.
        """
    @classmethod
    def from_preset(cls, modality: str = 'image', lm_invoker_kwargs: dict[str, Any] | None = None, prompt_builder_kwargs: dict[str, Any] | None = None, lm_output_key: str = ...) -> NativeLMBasedAdapter:
        '''Initialize adapter from a preset configuration.

        Args:
            modality (str): Modality type (e.g., "image"). Used to select default preset.
            lm_invoker_kwargs (dict[str, Any] | None): Keyword arguments for the LM invoker.
                Defaults to None.
            prompt_builder_kwargs (dict[str, Any] | None): Keyword arguments for the prompt builder.
                Defaults to None.
            lm_output_key (str, optional): The key in the LM output that contains the route.
                Defaults to DEFAULT_LM_OUTPUT_KEY.

        Returns:
            NativeLMBasedAdapter: Initialized adapter instance.

        Raises:
            ValueError: If the modality is not supported.
        '''
