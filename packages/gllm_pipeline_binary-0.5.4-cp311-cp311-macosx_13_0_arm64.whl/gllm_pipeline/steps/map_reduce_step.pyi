from _typeshed import Incomplete
from gllm_core.schema import Component
from gllm_core.utils.retry import RetryConfig
from gllm_pipeline.alias import InputMapSpec as InputMapSpec, PipelineState as PipelineState
from gllm_pipeline.steps.pipeline_step import BasePipelineStep as BasePipelineStep
from gllm_pipeline.steps.step_error_handler.step_error_handler import BaseStepErrorHandler as BaseStepErrorHandler
from gllm_pipeline.types import CacheConfig as CacheConfig
from gllm_pipeline.utils.async_utils import execute_callable as execute_callable
from gllm_pipeline.utils.error_handling import ErrorContext as ErrorContext
from gllm_pipeline.utils.has_inputs_mixin import HasInputsMixin as HasInputsMixin
from gllm_pipeline.utils.input_map import shallow_dump as shallow_dump
from langchain_core.runnables import RunnableConfig as RunnableConfig
from langgraph.runtime import Runtime
from typing import Any, Callable

class MapReduceStep(BasePipelineStep, HasInputsMixin):
    """A step that applies a mapping function to multiple inputs and reduces the results.

    This step performs parallel processing of multiple input items using:
    1. A map function that processes each input item independently. The map function receives a dictionary
        containing the input values for the current item (derived from input_map).
    2. A reduce function that combines all the mapped results.

    Note on parallel execution:
    1. For true parallelism, the map_func MUST be an async function or a Component.
    2. Synchronous map functions will block the event loop and run sequentially.

    Input handling:
    1. Automatically detects which inputs are lists/sequences.
    2. Ensures all list inputs have the same length.
    3. Broadcasts scalar values to match list lengths.
    4. If no list inputs, applies the map function once to the whole input.

    Internally, this step uses asyncio.gather() for efficient parallel execution.

    Attributes:
        name (str): A unique identifier for this step.
        map_func (Component | Callable[[dict[str, Any]], Any]): Function to apply to each input item.
            Will be run in parallel if the function is an asynchronous function.
        reduce_func (Callable[[list[Any]], Any]): Function to reduce the mapped results.
        input_map (InputMapSpec | None): Unified input map.
        output_state (str): Key to store the reduced result in the pipeline state.
        retry_config (RetryConfig | None): Configuration for retry behavior using GLLM Core's RetryConfig.
    """
    map_func: Incomplete
    reduce_func: Incomplete
    output_state: Incomplete
    def __init__(self, name: str, output_state: str, map_func: Component | Callable[[dict[str, Any]], Any], reduce_func: Callable[[list[Any]], Any] = ..., input_map: InputMapSpec | None = None, retry_config: RetryConfig | None = None, error_handler: BaseStepErrorHandler | None = None, cache: CacheConfig | None = None) -> None:
        """Initialize a new MapReduceStep.

        Args:
            name (str): A unique identifier for this step.
            output_state (str): Key to store the reduced result in the pipeline state.
            map_func (Component | Callable[[dict[str, Any]], Any]): Function to apply to each input item.
                The map function receives a dictionary containing the input values derived from input_map.
            reduce_func (Callable[[list[Any]], Any], optional): Function to reduce the mapped results.
                Defaults to a function that returns the list of results as is.
            input_map (InputMapSpec | None, optional):
                Unified input map. Can be a dict (arg -> str|Val) or a list with elements:
                1. str for identity mapping
                2. dict[str, str] for state/config mapping
                3. dict[str, Val] for fixed args.
                Defaults to None.
            retry_config (RetryConfig | None, optional): Configuration for retry behavior using
                GLLM Core's RetryConfig. Defaults to None, in which case no retry config is applied.
            error_handler (BaseStepErrorHandler | None, optional): Strategy to handle errors during execution.
                Defaults to None, in which case the RaiseStepErrorHandler is used.
            cache (CacheConfig | None, optional): Configuration for the cache store including the cache
                store instance and its settings. Defaults to None, in which case no caching will be used.
        """
    async def execute(self, state: PipelineState, runtime: Runtime, config: RunnableConfig | None = None) -> dict[str, Any]:
        """Execute the map and reduce operations.

        Args:
            state (PipelineState): The current state of the pipeline.
            runtime (Runtime): Runtime information for this step's execution.
            config (RunnableConfig | None, optional): The runnable configuration. Defaults to None.

        Returns:
            dict[str, Any]: The reduced result stored under output_state.

        Raises:
            RuntimeError: If an error occurs during execution.
        """
