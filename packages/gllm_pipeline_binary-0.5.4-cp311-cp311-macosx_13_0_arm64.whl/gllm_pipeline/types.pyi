from _typeshed import Incomplete
from dataclasses import dataclass
from gllm_datastore.cache.cache import Cache
from pydantic import BaseModel
from typing import Any, Callable

Cache = Any

@dataclass(frozen=True)
class Val:
    """A value wrapper that represents a fixed/literal input.

    Attributes:
        value (object): The literal value of the input.
    """
    value: object

class PipelineInvocation(BaseModel):
    '''A model representing the invocation parameters for a pipeline.

    This model is used to validate the structure of data returned by
    pre_invoke_transform functions. It ensures the data has the correct
    format for pipeline invocation.

    Examples:
        ```python
        invocation = PipelineInvocation(
            input={"user_query": "What is AI?"},
            config={"session_id": "abc123"}
        )

        # With no config
        invocation = PipelineInvocation(input={"query": "test"})
        ```

    Attributes:
        input (dict[str, Any]): The input data to pass to the pipeline.
            This is a required field and must be a dictionary.
        config (dict[str, Any] | None): Optional configuration for the
            pipeline execution. Must be a dictionary if provided.
    '''
    model_config: Incomplete
    input: dict[str, Any]
    config: dict[str, Any] | None

class CacheConfig(BaseModel):
    '''Configuration for caching in pipeline steps and pipelines.

    This model encapsulates the cache store instance and its key generation
    function. It provides a single parameter for configuring caching.

    Examples:
        ```python
        from gllm_pipeline.types import CacheConfig
        from gllm_datastore.cache.cache import Cache

        # Basic usage with just the store
        cache_config = CacheConfig(store=redis_cache)

        # With custom key function
        def custom_key_func(state: dict, runtime, config=None, **kwargs) -> str:
            user_id = state.get("user_id")
            return f"user:{user_id}"

        cache_config = CacheConfig(
            store=redis_cache,
            key_func=custom_key_func
        )

        # With custom cache name
        cache_config = CacheConfig(
            store=redis_cache,
            name="my_custom_cache"
        )
        ```

    Attributes:
        store (Cache): The cache store instance to use for caching results.
        name (str | None): A custom name for the cache. If not provided, defaults to
            "step_{step_name}" for steps and "pipeline_{pipeline_name}" for pipelines.
        key_func (Callable[..., str] | None): A function to generate cache keys. If None, the cache
            instance will use its own default key generation.
    '''
    model_config: Incomplete
    store: Cache
    name: str | None
    key_func: Callable[..., str] | None
