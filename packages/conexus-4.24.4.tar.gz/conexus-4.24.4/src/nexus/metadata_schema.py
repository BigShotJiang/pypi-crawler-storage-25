# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Hal Hildebrand. All rights reserved.
"""Single source of truth for T3 record metadata (nexus-40t).

Every write into ChromaDB funnels through :func:`normalize` so the key
set stays bounded and Chroma Cloud's 32-key ``MAX_RECORD_METADATA_KEYS``
quota is never breached. Every ``upsert``/``update`` then calls
:func:`validate` as a last-line guard that refuses to silently lose
fields.

Design:
  * :data:`ALLOWED_TOP_LEVEL` — the canonical schema. Keys are either
    read by a ``where=`` filter, consumed by scoring, or displayed to
    the user.
  * **Cargo keys** (``pdf_subject``, ``ast_chunked``, ``session_id``,
    etc.) are dropped by :func:`normalize` — they were written but
    never read.
  * **Consolidated keys**: the four ``git_*`` fields are packed into a
    single ``git_meta`` JSON string so that provenance is preserved at
    the cost of one metadata slot instead of four.

The function is **idempotent**: re-running it on output is a no-op.
Post-pass enrichers rely on this so they can merge additions with an
existing row without accreting keys.

Also see ``src/nexus/db/chroma_quotas.py`` for the upstream Chroma
quota that this module keeps us under.
"""
from __future__ import annotations

import json
from typing import Any

__all__ = [
    "ALLOWED_TOP_LEVEL",
    "CONTENT_TYPES",
    "MAX_SAFE_TOP_LEVEL_KEYS",
    "MetadataSchemaError",
    "make_chunk_metadata",
    "normalize",
    "validate",
]


# ── Schema ──────────────────────────────────────────────────────────────────

#: Top-level keys allowed on any T3 record. Populated by auditing every
#: ``where=`` filter, every ``meta.get(...)`` / ``metadata[...]`` read,
#: and every display formatter in the codebase.
ALLOWED_TOP_LEVEL: frozenset[str] = frozenset({
    # Identity (4) — RDR-102 D2 dropped ``source_path``. The catalog
    # tumbler in ``doc_id`` is the canonical reference; ``source_path``
    # was a regression vector against the prune verb (RF-8: it was the
    # only key in both ALLOWED_TOP_LEVEL and _PRUNE_DEPRECATED_KEYS,
    # which created a write-strip-rewrite cycle that never terminated).
    "content_hash",
    "chunk_text_hash",
    "chunk_index",
    "chunk_count",
    # Spans (5)
    "chunk_start_char",
    "chunk_end_char",
    "line_start",
    "line_end",
    "page_number",
    # Display / user-facing (6) — ``title`` is intentionally KEPT
    # per the rdr-101-phase4-reader-audit + 2026-05-03 re-verification:
    # ``find_ids_by_title`` (db/t3.py:1256) is load-bearing for
    # ``nx store delete --title`` and the MCP ``store_get`` title-
    # fallback path. Dropping it would silently break title-keyed
    # retrieval for MCP-promoted notes in ``knowledge__knowledge``.
    "title",
    "source_author",
    "section_title",
    "section_type",
    "tags",
    "category",
    # Routing (2) — RDR-101 Phase 5c (nexus-o6aa.13) dropped
    # ``store_type`` (legacy duplicate of ``content_type``; only
    # fallback reader at db/t3.py:122 remains for legacy chunks)
    # and ``corpus`` (zero non-write readers; catalog Document
    # carries the corpus binding at the document level).
    "content_type",
    "embedding_model",
    # Bibliographic (filtered via where=bib_year; displayed in results) (5).
    # ``bib_semantic_scholar_id`` is the load-bearing "this title was
    # enriched" marker (commands/enrich.py uses presence to skip
    # already-enriched titles; catalog/link_generator.py uses it for
    # citation links). Dropped together with the rest when all-empty.
    "bib_year",
    "bib_authors",
    "bib_venue",
    "bib_citation_count",
    "bib_semantic_scholar_id",
    # Lifecycle / scoring (5) — ``expires_at`` removed; expiry is
    # derived from ``indexed_at + ttl_days`` Python-side. ``ttl_days=0``
    # is the "permanent" sentinel.
    "indexed_at",
    "ttl_days",
    "frecency_score",
    "source_agent",
    "session_id",
    # RDR-101 Phase 5c dropped ``git_meta`` (consolidated git
    # provenance JSON blob): zero non-self-referential readers in
    # src/. Catalog Document carries source git provenance at the
    # document level.
    # RDR-101 Phase 3 PR δ — catalog cross-reference (1).
    # ``doc_id`` carries the catalog Tumbler string for the document
    # this chunk belongs to. RDR-101 Phase 4: every indexer writes
    # ``doc_id`` at chunk-creation time via ``make_chunk_metadata``;
    # ``_write_batch`` calls ``validate()`` which would otherwise
    # strip a non-whitelisted key. The Phase 2 t3-backfill-doc-id
    # migration verb was retired post Phase 5b (nexus-iftc); legacy
    # chunks predating Phase 4 are repopulated by re-indexing.
    "doc_id",
})

#: Allowed content_type values. Replaces the old overlapping pair
#: ``(store_type, category)``.
CONTENT_TYPES: frozenset[str] = frozenset({"code", "pdf", "markdown", "prose"})

#: Safety margin below Chroma's 32-key cap (:data:`~nexus.db.chroma_quotas.
#: QUOTAS.MAX_RECORD_METADATA_KEYS`). Any write producing more than this
#: many keys raises :class:`MetadataSchemaError`. RDR-101 Phase 3 PR δ
#: bumped this to 32 to admit the new ``doc_id`` field; RDR-102 D2 then
#: dropped ``source_path`` from the schema (one-key headroom restored,
#: schema sits at 31 of 32). The ``bib_*`` placeholder-drop and
#: ``git_meta``-omitted-when-empty filters in :func:`normalize` keep
#: typical chunks well under the cap (no-bib + no-git ≈ 25 keys).
MAX_SAFE_TOP_LEVEL_KEYS: int = 32

#: Git provenance sub-keys — packed into ``git_meta`` as a JSON string.
_GIT_FIELD_MAP: dict[str, str] = {
    "git_project_name": "project",
    "git_branch": "branch",
    "git_commit_hash": "commit",
    "git_remote_url": "remote",
}

#: Bibliographic slots. All four are dropped together when every value
#: is the placeholder (``0`` or ``""``) — without ``--enrich`` they are
#: pure cargo eating metadata budget (nexus-2my fix #2). When at least
#: one slot is populated the full set rides along so the search/display
#: contract stays uniform.
_BIB_FIELDS: tuple[str, ...] = (
    "bib_year", "bib_authors", "bib_venue", "bib_citation_count",
    "bib_semantic_scholar_id",
)

#: Primitive value types accepted by ChromaDB metadata.
_PRIMITIVE_TYPES: tuple[type, ...] = (str, int, float, bool, type(None))


# ── Error ───────────────────────────────────────────────────────────────────


class MetadataSchemaError(ValueError):
    """Raised when a metadata dict violates :mod:`nexus.metadata_schema`."""


# ── Normalise ───────────────────────────────────────────────────────────────


def normalize(raw: dict[str, Any], *, content_type: str) -> dict[str, Any]:
    """Return a canonical metadata dict for a T3 record.

    Operations (in order):

    1. Validate ``content_type`` against :data:`CONTENT_TYPES`.
    2. Drop cargo keys — anything outside :data:`ALLOWED_TOP_LEVEL`.
       Then drop the four ``bib_*`` slots together when every value is
       the placeholder (``0`` / ``""``).
    3. Drop ``doc_id`` when the call site did not populate it (RDR-101
       PR δ — empty values consume metadata slots for no payload).
    4. Inject ``content_type`` so routing code has a single canonical
       field to read.

    RDR-101 Phase 5c (``nexus-o6aa.13``) removed ``corpus``,
    ``store_type``, ``git_meta`` from :data:`ALLOWED_TOP_LEVEL`. The
    Step 2 cargo filter drops them. The Phase 5a/5b
    ``[catalog].event_sourced`` flag machinery is gone — there's no
    flag, the schema just doesn't have those fields.

    The function never raises on unknown keys (cargo is silently dropped).
    The companion :func:`validate` performs the strict post-write check.
    """
    if content_type not in CONTENT_TYPES:
        raise ValueError(
            f"invalid content_type {content_type!r}; "
            f"expected one of {sorted(CONTENT_TYPES)}"
        )

    working = dict(raw)

    # Drop the legacy flat ``git_*`` keys before the cargo filter so
    # they don't consume metadata budget. Pre-Phase-5c they were
    # consolidated into a ``git_meta`` JSON blob; post-5c they're
    # discarded entirely (catalog Document carries git provenance at
    # the document level).
    for raw_key in _GIT_FIELD_MAP:
        working.pop(raw_key, None)

    # Step 2: drop cargo.
    normalised = {k: v for k, v in working.items() if k in ALLOWED_TOP_LEVEL}

    # Step 2b: drop the bib_* placeholder set when every slot is empty.
    # When ``--enrich`` is off the indexer writes the four bib_* keys
    # with ``0`` / ``""`` defaults; without this filter they consume four
    # metadata slots for no payload (nexus-2my fix #2).
    if not any(normalised.get(field) for field in _BIB_FIELDS):
        for field in _BIB_FIELDS:
            normalised.pop(field, None)

    # Step 3 (RDR-101 PR δ): drop ``doc_id`` when the call site did not
    # populate it. Pre-PR-δ chunks have no doc_id; the field is opt-in
    # for indexers that have a Catalog handle. Empty value would
    # otherwise consume a metadata slot for no payload.
    if not normalised.get("doc_id"):
        normalised.pop("doc_id", None)

    # Step 4: stamp content_type.
    normalised["content_type"] = content_type

    return normalised


# ── Validate ────────────────────────────────────────────────────────────────


def validate(metadata: dict[str, Any]) -> None:
    """Raise :class:`MetadataSchemaError` if *metadata* is not writeable.

    Enforced invariants:
      * Key count ≤ :data:`MAX_SAFE_TOP_LEVEL_KEYS`.
      * Every key lives in :data:`ALLOWED_TOP_LEVEL`.
      * Every value is a Chroma-primitive (``str``, ``int``, ``float``,
        ``bool``, or ``None``).

    Runs in the T3 write path (``upsert_chunks_with_embeddings``,
    ``update_chunks``). A violation fails the write loudly rather than
    letting Chroma Cloud silently drop the keys that happen to sort last.
    """
    if len(metadata) > MAX_SAFE_TOP_LEVEL_KEYS:
        raise MetadataSchemaError(
            f"too many metadata keys: {len(metadata)} > "
            f"{MAX_SAFE_TOP_LEVEL_KEYS} (Chroma cap 32). "
            f"Keys: {sorted(metadata.keys())}"
        )

    unknown = set(metadata) - ALLOWED_TOP_LEVEL
    if unknown:
        raise MetadataSchemaError(
            f"unknown metadata keys: {sorted(unknown)}. "
            f"Add to ALLOWED_TOP_LEVEL or route them through normalize()."
        )

    for key, value in metadata.items():
        if not isinstance(value, _PRIMITIVE_TYPES):
            raise MetadataSchemaError(
                f"non-primitive metadata value for {key!r}: "
                f"{type(value).__name__} — "
                f"ChromaDB only accepts str/int/float/bool/None"
            )


# ── Factory ─────────────────────────────────────────────────────────────────


def make_chunk_metadata(
    *,
    content_type: str,
    # Identity (always required) — RDR-102 D2 hard-removed
    # ``source_path``; RDR-101 Phase 5c (nexus-o6aa.13) hard-removed
    # ``corpus``, ``store_type``, and ``git_meta``. Callers that still
    # pass any of those raise ``TypeError`` so the regression is caught
    # at the call site rather than silently dropped downstream.
    chunk_index: int,
    chunk_count: int,
    chunk_text_hash: str,
    content_hash: str,
    indexed_at: str,
    embedding_model: str,
    # Position (required where meaningful, default 0 elsewhere)
    chunk_start_char: int = 0,
    chunk_end_char: int = 0,
    line_start: int = 0,
    line_end: int = 0,
    page_number: int = 0,
    # Display — ``title`` kept (find_ids_by_title is load-bearing for
    # nx store / MCP store_get title-fallback per the .10.2 audit).
    title: str = "",
    source_author: str = "",
    section_title: str = "",
    section_type: str = "",
    tags: str = "",
    category: str = "",
    # Bibliographic (defaults dropped together by normalize when all-empty)
    bib_year: int = 0,
    bib_authors: str = "",
    bib_venue: str = "",
    bib_citation_count: int = 0,
    bib_semantic_scholar_id: str = "",
    # Lifecycle
    ttl_days: int = 0,
    frecency_score: float = 0.0,
    source_agent: str = "nexus-indexer",
    session_id: str = "",
    # RDR-101 Phase 3 PR δ — catalog cross-reference. Empty string is
    # the "not registered" sentinel; live-indexing call sites populate
    # it from ``Catalog.by_file_path(owner, rel_path).tumbler``. Empty
    # values flow through normalize() unchanged but are dropped from
    # the written metadata by the same cargo-key filter that handles
    # other empty optionals (see normalize() Step 3).
    doc_id: str = "",
) -> dict[str, Any]:
    """Build a complete chunk metadata dict and route through
    :func:`normalize` so it's safe to write directly to T3.

    Every :data:`ALLOWED_TOP_LEVEL` key gets a value (either explicit
    or a documented default). Bib placeholders are dropped together
    when all-empty (see :func:`normalize`).

    Indexers should never build chunk metadata dicts by hand — route
    through this factory so adding a new ``ALLOWED_TOP_LEVEL`` key
    is a single edit, not seven separate indexer changes.
    """
    raw: dict[str, Any] = {
        "content_hash": content_hash,
        "chunk_text_hash": chunk_text_hash,
        "chunk_index": chunk_index,
        "chunk_count": chunk_count,
        "chunk_start_char": chunk_start_char,
        "chunk_end_char": chunk_end_char,
        "line_start": line_start,
        "line_end": line_end,
        "page_number": page_number,
        "title": title,
        "source_author": source_author,
        "section_title": section_title,
        "section_type": section_type,
        "tags": tags,
        "category": category,
        "embedding_model": embedding_model,
        "bib_year": bib_year,
        "bib_authors": bib_authors,
        "bib_venue": bib_venue,
        "bib_citation_count": bib_citation_count,
        "bib_semantic_scholar_id": bib_semantic_scholar_id,
        "ttl_days": ttl_days,
        "indexed_at": indexed_at,
        "frecency_score": frecency_score,
        "source_agent": source_agent,
        "session_id": session_id,
        "doc_id": doc_id,
    }
    return normalize(raw, content_type=content_type)


# ── Expiry helper (replaces the dropped ``expires_at`` field) ────────────────


def is_expired(metadata: dict[str, Any], *, now_iso: str) -> bool:
    """Return ``True`` when *metadata* has elapsed its TTL.

    Replaces the previous ``where=expires_at < now`` filter. Computes
    expiry from ``indexed_at + ttl_days`` Python-side. ``ttl_days == 0``
    is the permanent sentinel — never expires regardless of indexed_at.
    """
    ttl = metadata.get("ttl_days", 0)
    if not ttl or ttl <= 0:
        return False
    indexed_at = metadata.get("indexed_at", "")
    if not indexed_at:
        return False
    from datetime import datetime, timedelta
    try:
        idx_dt = datetime.fromisoformat(indexed_at)
        now_dt = datetime.fromisoformat(now_iso)
    except (TypeError, ValueError):
        return False
    return (now_dt - idx_dt) >= timedelta(days=ttl)
