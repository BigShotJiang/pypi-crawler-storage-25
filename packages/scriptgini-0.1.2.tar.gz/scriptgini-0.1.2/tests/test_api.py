"""Health and project CRUD smoke tests."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

# Import models first so their tables are registered with Base.metadata
import app.models.project  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.generated_script  # noqa: F401

from alembic.config import Config as AlembicConfig
from alembic import command as alembic_command

from app.main import app as fastapi_app
from app.database import Base, get_db

# ── In-memory SQLite for tests ───────────────────────────────────────────────
# StaticPool ensures all connections share the same in-memory database so
# tables created by create_all() are visible to subsequent queries.
TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


def _run_alembic_upgrade():
    """Run alembic upgrade head against the shared in-memory engine."""
    cfg = AlembicConfig("alembic.ini")
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        alembic_command.upgrade(cfg, "head")
def _run_alembic_downgrade():
    """Run alembic downgrade base to fully reset the in-memory engine."""
    cfg = AlembicConfig("alembic.ini")
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        alembic_command.downgrade(cfg, "base")




@pytest.fixture(autouse=True)
def setup_db():
    _run_alembic_upgrade()
    yield
    _run_alembic_downgrade()


@pytest.fixture()
def client():
    fastapi_app.dependency_overrides[get_db] = override_get_db
    with TestClient(fastapi_app) as c:
        yield c
    fastapi_app.dependency_overrides.clear()


# ── Health check ─────────────────────────────────────────────────────────────

def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_ui_index(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "ScriptGini Control Deck" in resp.text


# ── Projects CRUD ─────────────────────────────────────────────────────────────

def test_create_project(client):
    payload = {
        "name": "Demo App",
        "aut_base_url": "https://demo.example.com",
        "default_framework": "playwright_python",
        "selector_preference": "role",
    }
    resp = client.post("/api/v1/projects/", json=payload)
    assert resp.status_code == 201
    data = resp.json()
    assert data["name"] == "Demo App"
    assert data["id"] is not None


def test_list_projects_empty(client):
    resp = client.get("/api/v1/projects/")
    assert resp.status_code == 200
    assert resp.json() == []


def test_load_demo_project_creates_project_and_cases(client):
    first = client.post("/api/v1/demo/load")
    assert first.status_code == 201
    payload = first.json()
    assert payload["created"] is True
    assert payload["project_name"] == "Demo Retail Checkout"
    assert payload["test_case_count"] == 3

    projects = client.get("/api/v1/projects/")
    assert projects.status_code == 200
    assert len(projects.json()) == 1

    project_id = projects.json()[0]["id"]
    test_cases = client.get(f"/api/v1/projects/{project_id}/test-cases/")
    assert test_cases.status_code == 200
    assert len(test_cases.json()) == 3

    second = client.post("/api/v1/demo/load")
    assert second.status_code == 200
    assert second.json()["created"] is False

    projects_again = client.get("/api/v1/projects/")
    assert len(projects_again.json()) == 1

    test_cases_again = client.get(f"/api/v1/projects/{project_id}/test-cases/")
    assert len(test_cases_again.json()) == 3


def test_get_project_not_found(client):
    resp = client.get("/api/v1/projects/999")
    assert resp.status_code == 404


def test_update_project(client):
    create = client.post("/api/v1/projects/", json={
        "name": "Old Name",
        "aut_base_url": "https://example.com",
    })
    pid = create.json()["id"]
    resp = client.patch(f"/api/v1/projects/{pid}", json={"name": "New Name"})
    assert resp.status_code == 200
    assert resp.json()["name"] == "New Name"


def test_delete_project(client):
    create = client.post("/api/v1/projects/", json={
        "name": "To Delete",
        "aut_base_url": "https://example.com",
    })
    pid = create.json()["id"]
    resp = client.delete(f"/api/v1/projects/{pid}")
    assert resp.status_code == 204
    assert client.get(f"/api/v1/projects/{pid}").status_code == 404


# ── Test Cases CRUD ───────────────────────────────────────────────────────────

@pytest.fixture()
def project_id(client):
    resp = client.post("/api/v1/projects/", json={
        "name": "TC Project",
        "aut_base_url": "https://example.com",
    })
    return resp.json()["id"]


def test_create_test_case(client, project_id):
    resp = client.post(f"/api/v1/projects/{project_id}/test-cases/", json={
        "title": "TC-001 Login",
        "format": "step_based",
        "content": "Step 1: Navigate to /login\nExpected: Login form is visible",
    })
    assert resp.status_code == 201
    assert resp.json()["title"] == "TC-001 Login"


def test_list_test_cases(client, project_id):
    client.post(f"/api/v1/projects/{project_id}/test-cases/", json={
        "title": "TC-001",
        "format": "step_based",
        "content": "Step 1: ...",
    })
    resp = client.get(f"/api/v1/projects/{project_id}/test-cases/")
    assert resp.status_code == 200
    assert len(resp.json()) == 1


def test_test_case_not_found(client, project_id):
    resp = client.get(f"/api/v1/projects/{project_id}/test-cases/999")
    assert resp.status_code == 404
