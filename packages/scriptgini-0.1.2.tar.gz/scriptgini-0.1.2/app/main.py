import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.llm.provider import get_llm_diagnostics
from app.routers import projects, test_cases, scripts, bulk_jobs, analytics, demo

logging.basicConfig(level=logging.DEBUG if settings.DEBUG else logging.INFO)
logger = logging.getLogger(__name__)

static_dir = Path(__file__).resolve().parent / "static"

app = FastAPI(
    title=settings.APP_NAME,
    description=(
        "Enterprise-grade Agentic AI system that converts functional test cases "
        "into high-quality automation scripts."
    ),
    version="1.0.4",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(projects.router, prefix="/api/v1")
app.include_router(test_cases.router, prefix="/api/v1")
app.include_router(scripts.router, prefix="/api/v1")
app.include_router(bulk_jobs.router, prefix="/api/v1")
app.include_router(analytics.router, prefix="/api/v1")
app.include_router(demo.router, prefix="/api/v1")
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.on_event("startup")
def log_llm_runtime_config() -> None:
    diagnostics = get_llm_diagnostics()
    logger.info(
        "Runtime LLM default: provider=%s model=%s api_key_env=%s api_key_present=%s api_key=%s",
        diagnostics["provider"],
        diagnostics["model"],
        diagnostics["api_key_env"],
        diagnostics["api_key_present"],
        diagnostics["api_key_masked"],
    )


@app.get("/api/v1/runtime/llm", tags=["Runtime"])
def runtime_llm():
    default_diagnostics = get_llm_diagnostics()
    return {
        "default_provider": default_diagnostics["provider"],
        "default_model": default_diagnostics["model"],
        "provider_diagnostics": {
            provider: get_llm_diagnostics(provider) for provider in ["openai", "openrouter", "gemini", "ollama", "bedrock"]
        },
    }


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(static_dir / "index.html")


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok", "app": settings.APP_NAME}
