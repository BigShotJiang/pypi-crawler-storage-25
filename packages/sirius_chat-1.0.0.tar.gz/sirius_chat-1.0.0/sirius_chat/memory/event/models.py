"""Event memory data models (v2 - observation-based).

v2 redesign: user-scoped observations extracted in batches,
replacing per-message heuristic event clustering.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from sirius_chat.mixins import JsonSerializable

# Supported observation categories
OBSERVATION_CATEGORIES = frozenset({
    "preference",    # 偏好：喜好、习惯
    "trait",         # 特质：性格、沟通风格
    "relationship",  # 关系：提到的人/组织
    "experience",    # 经历：工作、教育、生活
    "emotion",       # 情绪：情绪模式、触发点
    "goal",          # 目标：计划、当前项目
    "custom",        # 其他
})


@dataclass(slots=True)
class EventMemoryEntry(JsonSerializable):
    """User-scoped observation extracted from conversation (v2).

    Each entry represents a meaningful observation about a specific participant,
    extracted via batch LLM analysis rather than per-message heuristics.
    """

    event_id: str
    user_id: str = ""
    group_id: str = ""  # Group/chat identifier for memory isolation
    user_ids: list[str] = field(default_factory=list)  # Multi-user events
    category: str = "custom"  # preference|trait|relationship|experience|emotion|goal|custom
    summary: str = ""
    confidence: float = 0.5
    evidence_samples: list[str] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""
    mention_count: int = 0
    verified: bool = False
    # Activation-based forgetting (paper §4.2.4)
    activation: float = 1.0
    access_count: int = 0
    last_accessed: str = ""


# Kept for public API backward compatibility — unused in v2 production code.
@dataclass(slots=True)
class ContextualEventInterpretation:
    """Deprecated: contextual interpretation kept for API compatibility."""

    event_id: str
    event_summary: str
    base_confidence: float = 0.65
    keyword_alignment: float = 0.0
    role_alignment: float = 0.0
    emotion_alignment: float = 0.0
    entity_alignment: float = 0.0
    adjusted_confidence: float = 0.65
    recommended_category: str = "normal"
    interpretation_notes: list[str] = field(default_factory=list)
