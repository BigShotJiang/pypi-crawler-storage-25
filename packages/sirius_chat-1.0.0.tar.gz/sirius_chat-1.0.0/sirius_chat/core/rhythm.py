"""Rhythm analyzer: conversation state machine (paper §6.1).

Extends heat.py with:
- pace detection (accelerating/steady/decelerating/silent)
- topic stability
- attention window detection
- burst detection
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from sirius_chat.models.emotion import EmotionState


@dataclass(slots=True)
class RhythmAnalysis:
    """Conversation rhythm analysis result."""

    heat_level: str = "warm"           # cold | warm | hot | overheated
    heat_score: float = 0.0
    pace: str = "steady"               # accelerating | steady | decelerating | silent
    gap_since_last_message: float = 0.0  # seconds
    topic_stability: float = 0.5       # 0~1
    collective_mood: EmotionState | None = None
    attention_window_open: bool = False
    burst_detected: bool = False
    conversation_flows: int = 1


class RhythmAnalyzer:
    """Analyzes conversation rhythm beyond simple heat metrics."""

    def __init__(self) -> None:
        self._history: dict[str, list[dict[str, Any]]] = {}  # group_id -> message metadata list

    def analyze(
        self,
        group_id: str,
        messages: list[dict[str, Any]],  # {user_id, content, timestamp, ...}
    ) -> RhythmAnalysis:
        """Analyze rhythm from recent messages."""
        if not messages:
            return RhythmAnalysis(heat_level="cold", pace="silent")

        # Update history
        self._history.setdefault(group_id, [])
        self._history[group_id].extend(messages)
        self._history[group_id] = self._history[group_id][-100:]

        recent = messages[-20:]

        # Heat score (simplified from heat.py)
        heat_score = self._compute_heat(recent)
        heat_level = self._heat_level(heat_score)

        # Pace
        pace = self._compute_pace(recent)

        # Gap
        gap = self._compute_gap(recent)

        # Topic stability
        stability = self._compute_topic_stability(recent)

        # Attention window
        attention_open = self._attention_window(recent, stability)

        # Burst detection
        burst = self._detect_burst(recent)

        # Flows (simplified: count unique user transitions)
        flows = self._count_flows(recent)

        return RhythmAnalysis(
            heat_level=heat_level,
            heat_score=round(heat_score, 3),
            pace=pace,
            gap_since_last_message=gap,
            topic_stability=round(stability, 3),
            attention_window_open=attention_open,
            burst_detected=burst,
            conversation_flows=flows,
        )

    @staticmethod
    def _compute_heat(messages: list[dict[str, Any]]) -> float:
        if not messages:
            return 0.0
        # Message density in last 5 minutes
        now = datetime.now(timezone.utc)
        recent_count = 0
        for m in messages:
            ts = m.get("timestamp", "")
            if ts:
                try:
                    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                    if (now - dt).total_seconds() <= 300:
                        recent_count += 1
                except (ValueError, TypeError):
                    pass
        density = min(1.0, recent_count / 6.0)
        unique_users = len({m.get("user_id") for m in messages})
        crowd = min(1.0, max(0, unique_users - 1) / 4.0)
        return 0.45 * density + 0.35 * crowd + 0.20 * 0.0

    @staticmethod
    def _heat_level(score: float) -> str:
        if score < 0.2:
            return "cold"
        if score < 0.5:
            return "warm"
        if score < 0.8:
            return "hot"
        return "overheated"

    @staticmethod
    def _compute_pace(messages: list[dict[str, Any]]) -> str:
        if len(messages) < 3:
            return "steady"
        intervals = []
        for i in range(1, len(messages)):
            t1 = _parse_ts(messages[i - 1].get("timestamp", ""))
            t2 = _parse_ts(messages[i].get("timestamp", ""))
            if t1 and t2:
                intervals.append((t2 - t1).total_seconds())
        if len(intervals) < 2:
            return "steady"
        # EWMA of interval changes
        avg_interval = sum(intervals) / len(intervals)
        recent_avg = sum(intervals[-3:]) / len(intervals[-3:])
        if recent_avg < avg_interval * 0.7:
            return "accelerating"
        if recent_avg > avg_interval * 1.5:
            return "decelerating"
        if avg_interval > 300:
            return "silent"
        return "steady"

    @staticmethod
    def _compute_gap(messages: list[dict[str, Any]]) -> float:
        if not messages:
            return 0.0
        last_ts = messages[-1].get("timestamp", "")
        last_dt = _parse_ts(last_ts)
        if last_dt:
            return max(0.0, (datetime.now(timezone.utc) - last_dt).total_seconds())
        return 0.0

    @staticmethod
    def _compute_topic_stability(messages: list[dict[str, Any]]) -> float:
        """Simple keyword overlap topic stability."""
        if len(messages) < 2:
            return 0.5
        contents = [str(m.get("content", "")) for m in messages[-5:]]
        if not contents:
            return 0.5
        # Tokenize very simply (Chinese characters + words)
        sets = []
        for text in contents:
            tokens = set(text.lower().split())
            tokens.update(set(text.lower()))  # character-level
            sets.append(tokens)
        overlaps = []
        for i in range(1, len(sets)):
            inter = sets[i - 1] & sets[i]
            union = sets[i - 1] | sets[i]
            if union:
                overlaps.append(len(inter) / len(union))
        return sum(overlaps) / len(overlaps) if overlaps else 0.5

    @staticmethod
    def _attention_window(messages: list[dict[str, Any]], stability: float) -> bool:
        if len(messages) < 3:
            return False
        unique_users = len({m.get("user_id") for m in messages[-5:]})
        return unique_users >= 3 and stability > 0.3

    @staticmethod
    def _detect_burst(messages: list[dict[str, Any]]) -> bool:
        """Detect if a user sent >=3 messages within 30 seconds."""
        from collections import defaultdict
        user_msgs: dict[str, list[datetime]] = defaultdict(list)
        for m in messages[-10:]:
            uid = m.get("user_id", "")
            dt = _parse_ts(m.get("timestamp", ""))
            if uid and dt:
                user_msgs[uid].append(dt)
        for timestamps in user_msgs.values():
            if len(timestamps) >= 3:
                span = (timestamps[-1] - timestamps[-3]).total_seconds()
                if span <= 30:
                    return True
        return False

    @staticmethod
    def _count_flows(messages: list[dict[str, Any]]) -> int:
        """Count parallel conversation flows (simplified)."""
        if len(messages) < 4:
            return 1
        # Count topic shifts
        shifts = 0
        for i in range(1, len(messages)):
            if messages[i].get("user_id") != messages[i - 1].get("user_id"):
                shifts += 1
        return max(1, shifts // 3)


def _parse_ts(ts: str) -> datetime | None:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
