# polykin.properties.vaporization
