#!/usr/bin/env python3
import os
import hashlib
import astropy.io.fits as fits
from astropy.table import Table

path = '/home/wangliang/data/byspec/calib/yfosc'

indextable = Table(dtype=[
    ('fileid',  str),
    ('object',  str),
    ('exptime', float),
    ('dateobs', str),
    ('mode',    str),
    ('config',  str),
    ('slit',    str),
    ('binning', str),
    ('gain',    float),
    ('rdspeed', str),
    ('rms',     float),
    ('ntotal',  int),
    ('nused',   int),
    ('md5',     str),
    ], masked=True)

for fname in sorted(os.listdir(path)):
    if not fname.endswith('.fits'):
        continue
    filename = os.path.join(path, fname)

    # get md5 sum
    f = open(filename, 'rb')
    content = f.read()
    f.close()
    md5sum = hashlib.md5(content).hexdigest()

    f = fits.open(filename)
    header = f[0].header
    f.close()

    indextable.add_row((
        header['FILEID'],
        header['OBJECT'],
        header['EXPTIME'],
        header['DATEOBS'],
        header['MODE'],
        header['CONFIG'],
        header['SLIT'],
        header['BINNING'],
        header['GAIN'],
        header['RDSPEED'],
        header['WAVERMS'],
        header['NTOTAL'],
        header['NUSED'],
        md5sum,
        ))
indextable['exptime'].info.format = '%8.3f'
indextable['gain'].info.format = '%4.1f'
indextable['rms'].info.format = '%6.3f'
print(indextable)
indextable.write('wlcalib_yfosc.dat',
            format='ascii.fixed_width_two_line', overwrite=True)
