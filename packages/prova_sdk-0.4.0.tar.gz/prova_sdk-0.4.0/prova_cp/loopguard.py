"""In-process coordination-loop detection for multi-agent runtimes.

This is the wedge made real. The server-side detector at
``lib/detectors/inline/coordinationLoop.ts`` catches loops *after* a run is
ingested. By then the agents have already burned the budget. ``LoopGuard``
runs the same algorithm incrementally, in the developer's own process, so the
loop can be broken the moment it forms.

The algorithm is a faithful port of the canonical TypeScript detector:

  1. Walk steps and build a directed agent communication graph: edge A -> B
     iff agent A wrote a state key and agent B subsequently read it.
  2. Run Tarjan's SCC on the graph.
  3. Any SCC with >= 2 distinct agents (or a self-loop) is a cycle.
  4. Persistence check: if the SCC's agents collectively occupy
     >= PERSISTENCE_THRESHOLD steps, the cycle is persistent.

Keeping the algorithm byte-for-byte equivalent to the server means a loop
caught locally is the same loop an auditor would see in the signed receipt.

Usage:

    from prova_cp.loopguard import LoopGuard, CoordinationLoopError

    guard = LoopGuard()
    try:
        for node, reads, writes in run_agent():
            guard.observe(node, reads=reads, writes=writes)
    except CoordinationLoopError as e:
        # break the runtime; e.match has agents / persistence / born_at_step
        ...

Most callers never touch this directly: pass ``break_on_loop=True`` to
``ProvaCallbackHandler`` and it is wired automatically.
"""

from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence, Set

PERSISTENCE_THRESHOLD = 6


class CoordinationLoopError(RuntimeError):
    """Raised by LoopGuard when a persistent coordination loop is detected.

    ``match`` carries the same shape the server-side detector emits:
    ``{agents, born_at_step, persistence_steps, total_steps, total_agents}``.
    """

    def __init__(self, match: Mapping[str, Any]) -> None:
        agents = match.get("agents", [])
        persistence = match.get("persistence_steps", 0)
        total = match.get("total_steps", 0)
        super().__init__(
            f"Coordination loop across {len(agents)} agents "
            f"({' -> '.join(map(str, agents))}) persisted for "
            f"{persistence} of {total} steps."
        )
        self.match = dict(match)


def _keys(obj: Any) -> List[str]:
    if isinstance(obj, Mapping):
        return [str(k) for k in obj.keys()]
    return []


class LoopGuard:
    """Incremental coordination-loop detector over an agent step trace.

    Call :meth:`observe` once per agent step. State accumulates; each
    observation re-runs the detection over the trace so far. The work is
    O(V + E) per step, trivial for the trace sizes real agent runs produce
    (<= 30 agents, <= 200 steps), and the guard short-circuits once a loop
    has fired so a long run does not pay the cost repeatedly.
    """

    def __init__(
        self,
        *,
        persistence_threshold: int = PERSISTENCE_THRESHOLD,
        raise_on_detect: bool = True,
    ) -> None:
        self._threshold = persistence_threshold
        self._raise = raise_on_detect
        self._steps: List[Dict[str, Any]] = []
        self._fired = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def steps(self) -> List[Dict[str, Any]]:
        """The accumulated trace, in the `{node, reads, writes}` shape the
        server-side coordination-loop detector consumes."""
        return self._steps

    def observe(
        self,
        node: str,
        *,
        reads: Optional[Mapping[str, Any]] = None,
        writes: Optional[Mapping[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Record one agent step and re-check for a persistent loop.

        Returns the match dict if a loop is detected (and ``raise_on_detect``
        is False), otherwise None. Raises :class:`CoordinationLoopError` the
        first time a loop is detected when ``raise_on_detect`` is True.
        """
        if node:
            self._steps.append(
                {"node": node, "reads": dict(reads or {}), "writes": dict(writes or {})}
            )

        if self._fired:
            return None

        match = detect_loop(self._steps, persistence_threshold=self._threshold)
        if match is None:
            return None

        self._fired = True
        if self._raise:
            raise CoordinationLoopError(match)
        return match


# ----------------------------------------------------------------------
# Pure detection -- faithful port of coordinationLoop.ts
# ----------------------------------------------------------------------


def _build_graph(steps: Sequence[Mapping[str, Any]]):
    nodes: Set[str] = set()
    edges: List[tuple] = []
    last_write: Dict[str, str] = {}
    seen_edges: Set[tuple] = set()

    for step in steps:
        node = step.get("node")
        if not isinstance(node, str) or not node:
            continue
        nodes.add(node)

        for key in _keys(step.get("reads")):
            writer = last_write.get(key)
            if writer and writer != node:
                edge = (writer, node)
                if edge not in seen_edges:
                    seen_edges.add(edge)
                    edges.append(edge)

        for key in _keys(step.get("writes")):
            last_write[key] = node

    return nodes, edges


def _tarjan(nodes: Set[str], edges: List[tuple]) -> List[List[str]]:
    adj: Dict[str, List[str]] = {n: [] for n in nodes}
    for frm, to in edges:
        adj[frm].append(to)

    index: Dict[str, int] = {}
    lowlink: Dict[str, int] = {}
    on_stack: Set[str] = set()
    stack: List[str] = []
    counter = 0
    result: List[List[str]] = []

    # Iterative Tarjan -- agent traces can be long enough to blow the
    # recursion limit, so we manage an explicit work stack.
    for start in nodes:
        if start in index:
            continue
        work: List[tuple] = [(start, 0)]
        while work:
            v, pi = work[-1]
            if pi == 0:
                index[v] = counter
                lowlink[v] = counter
                counter += 1
                stack.append(v)
                on_stack.add(v)

            recursed = False
            neighbors = adj[v]
            i = pi
            while i < len(neighbors):
                w = neighbors[i]
                if w not in index:
                    work[-1] = (v, i + 1)
                    work.append((w, 0))
                    recursed = True
                    break
                elif w in on_stack:
                    lowlink[v] = min(lowlink[v], index[w])
                i += 1

            if recursed:
                continue

            if lowlink[v] == index[v]:
                component: List[str] = []
                while True:
                    w = stack.pop()
                    on_stack.discard(w)
                    component.append(w)
                    if w == v:
                        break
                if len(component) > 1 or (
                    len(component) == 1 and component[0] in adj[component[0]]
                ):
                    result.append(component)

            work.pop()
            if work:
                parent = work[-1][0]
                lowlink[parent] = min(lowlink[parent], lowlink[v])

    return result


def _persistence_count(steps: Sequence[Mapping[str, Any]], agents: Set[str]) -> int:
    return sum(1 for s in steps if isinstance(s.get("node"), str) and s["node"] in agents)


def _born_at_step(steps: Sequence[Mapping[str, Any]], agents: Set[str]) -> int:
    for i, s in enumerate(steps):
        n = s.get("node")
        if isinstance(n, str) and n in agents:
            return i
    return -1


def detect_loop(
    steps: Sequence[Mapping[str, Any]],
    *,
    persistence_threshold: int = PERSISTENCE_THRESHOLD,
) -> Optional[Dict[str, Any]]:
    """Return the largest persistent coordination loop in ``steps``, or None.

    Pure function, no side effects. Same result the server-side detector
    produces for the same trace.
    """
    if not steps:
        return None

    nodes, edges = _build_graph(steps)
    if len(nodes) < 2:
        return None

    sccs = _tarjan(nodes, edges)
    if not sccs:
        return None

    best: Optional[Dict[str, Any]] = None
    for scc in sccs:
        agents = set(scc)
        p = _persistence_count(steps, agents)
        if p < persistence_threshold:
            continue
        if best is None or p > best["persistence_steps"]:
            best = {
                "agents": scc,
                "born_at_step": _born_at_step(steps, agents),
                "persistence_steps": p,
                "total_steps": len(steps),
                "total_agents": len(nodes),
            }

    return best
