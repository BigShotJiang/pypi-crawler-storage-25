"""Drop-in wrappers for raw OpenAI / Anthropic clients.

For teams not on LangGraph or CrewAI. Wrap the vendor client once; every
completion is mirrored to Prova as a signed `model_call` receipt. The wrapper
returns the vendor response unchanged and never raises on a Prova failure, so
it is safe to wrap a production client.

    from openai import OpenAI
    from prova_cp import ProvaClient
    from prova_cp.wrap import wrap_openai

    prova = ProvaClient(api_key="prv_...")
    client = wrap_openai(OpenAI(), prova, app_id="support-bot", environment="production")

    client.chat.completions.create(model="gpt-4o", messages=[...])

Handles all four call shapes:
- synchronous (`OpenAI`, `Anthropic`)
- asynchronous (`AsyncOpenAI`, `AsyncAnthropic` -- `await client...create(...)`)
- streaming (`stream=True`, sync iterator)
- async streaming (`await ...create(..., stream=True)`, async iterator)

For streamed calls the wrapper passes the stream through untouched, accumulates
chunk text as the caller consumes it, and ingests one receipt after the stream
is exhausted. `wrap_anthropic` is identical for the Anthropic SDK.
"""

from __future__ import annotations

import inspect
import logging
from typing import Any

log = logging.getLogger(__name__)

_MAX_LEN = 4000


def _safe(obj: Any, depth: int = 0) -> Any:
    if isinstance(obj, str):
        return obj[:_MAX_LEN] + ("..." if len(obj) > _MAX_LEN else "")
    if depth > 5:
        return "[truncated]"
    if isinstance(obj, dict):
        return {k: _safe(v, depth + 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_safe(v, depth + 1) for v in list(obj)[:50]]
    if hasattr(obj, "model_dump"):
        try:
            return _safe(obj.model_dump(), depth + 1)
        except Exception:
            pass
    return obj if isinstance(obj, (int, float, bool, type(None))) else str(obj)[:_MAX_LEN]


def _extract_chunk_text(chunk: Any) -> str | None:
    """Best-effort text out of one stream chunk, across OpenAI / Anthropic
    shapes. Returns None for non-text events; never raises."""
    try:
        choices = getattr(chunk, "choices", None)
        if choices:
            delta = getattr(choices[0], "delta", None)
            content = getattr(delta, "content", None) if delta is not None else None
            if isinstance(content, str):
                return content
        delta = getattr(chunk, "delta", None)
        if delta is not None:
            text = getattr(delta, "text", None)
            if isinstance(text, str):
                return text
    except Exception:
        pass
    return None


class _Ingestor:
    """Shared receipt builder. Fail-silent."""

    def __init__(self, client: Any, source: dict, provider: str) -> None:
        self._client = client
        self._source = source
        self._provider = provider

    def emit(self, kwargs: dict, response_summary: Any) -> None:
        try:
            self._client.ingest({
                "kind": "model_call",
                "source": dict(self._source),
                "model": {"provider": self._provider, "name": kwargs.get("model")},
                "payload": {
                    "request": _safe({k: v for k, v in kwargs.items() if k != "api_key"}),
                    "response": response_summary,
                },
            })
        except Exception as exc:
            log.warning("prova_cp.wrap: ingest failed (%s): %s", self._provider, exc)


class _StreamTap:
    """Wraps a sync stream: yields every chunk untouched, accumulates text,
    ingests once when the stream is exhausted. Delegates everything else
    (close(), context manager) to the underlying stream."""

    def __init__(self, stream: Any, ingestor: _Ingestor, kwargs: dict) -> None:
        object.__setattr__(self, "_stream", stream)
        object.__setattr__(self, "_it", iter(stream))
        object.__setattr__(self, "_ing", ingestor)
        object.__setattr__(self, "_kw", kwargs)
        object.__setattr__(self, "_parts", [])
        object.__setattr__(self, "_n", 0)
        object.__setattr__(self, "_fired", False)

    def __getattr__(self, name: str) -> Any:
        return getattr(object.__getattribute__(self, "_stream"), name)

    def __iter__(self) -> "_StreamTap":
        return self

    def _fire(self) -> None:
        if object.__getattribute__(self, "_fired"):
            return
        object.__setattr__(self, "_fired", True)
        parts = object.__getattribute__(self, "_parts")
        object.__getattribute__(self, "_ing").emit(
            object.__getattribute__(self, "_kw"),
            {"streamed": True, "chunk_count": object.__getattribute__(self, "_n"),
             "text": _safe("".join(parts)) if parts else None},
        )

    def __next__(self) -> Any:
        try:
            chunk = next(object.__getattribute__(self, "_it"))
        except StopIteration:
            self._fire()
            raise
        object.__setattr__(self, "_n", object.__getattribute__(self, "_n") + 1)
        t = _extract_chunk_text(chunk)
        if t:
            object.__getattribute__(self, "_parts").append(t)
        return chunk

    def __enter__(self) -> "_StreamTap":
        s = object.__getattribute__(self, "_stream")
        if hasattr(s, "__enter__"):
            s.__enter__()
        return self

    def __exit__(self, *exc: Any) -> Any:
        s = object.__getattribute__(self, "_stream")
        self._fire()
        if hasattr(s, "__exit__"):
            return s.__exit__(*exc)
        return False


class _AsyncStreamTap:
    """Async counterpart of _StreamTap."""

    def __init__(self, stream: Any, ingestor: _Ingestor, kwargs: dict) -> None:
        object.__setattr__(self, "_stream", stream)
        object.__setattr__(self, "_it", stream.__aiter__())
        object.__setattr__(self, "_ing", ingestor)
        object.__setattr__(self, "_kw", kwargs)
        object.__setattr__(self, "_parts", [])
        object.__setattr__(self, "_n", 0)
        object.__setattr__(self, "_fired", False)

    def __getattr__(self, name: str) -> Any:
        return getattr(object.__getattribute__(self, "_stream"), name)

    def __aiter__(self) -> "_AsyncStreamTap":
        return self

    def _fire(self) -> None:
        if object.__getattribute__(self, "_fired"):
            return
        object.__setattr__(self, "_fired", True)
        parts = object.__getattribute__(self, "_parts")
        object.__getattribute__(self, "_ing").emit(
            object.__getattribute__(self, "_kw"),
            {"streamed": True, "chunk_count": object.__getattribute__(self, "_n"),
             "text": _safe("".join(parts)) if parts else None},
        )

    async def __anext__(self) -> Any:
        try:
            chunk = await object.__getattribute__(self, "_it").__anext__()
        except StopAsyncIteration:
            self._fire()
            raise
        object.__setattr__(self, "_n", object.__getattribute__(self, "_n") + 1)
        t = _extract_chunk_text(chunk)
        if t:
            object.__getattribute__(self, "_parts").append(t)
        return chunk

    async def __aenter__(self) -> "_AsyncStreamTap":
        s = object.__getattribute__(self, "_stream")
        if hasattr(s, "__aenter__"):
            await s.__aenter__()
        return self

    async def __aexit__(self, *exc: Any) -> Any:
        s = object.__getattribute__(self, "_stream")
        self._fire()
        if hasattr(s, "__aexit__"):
            return await s.__aexit__(*exc)
        return False


class _CreateProxy:
    """Wraps a single `create` callable. Detects sync / async / streaming at
    call time and records accordingly. Always returns the vendor object."""

    def __init__(self, fn: Any, client: Any, source: dict, provider: str) -> None:
        self._fn = fn
        self._ing = _Ingestor(client, source, provider)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        result = self._fn(*args, **kwargs)
        if inspect.isawaitable(result):
            return self._async_path(result, kwargs)
        # Sync path.
        if kwargs.get("stream"):
            try:
                return _StreamTap(result, self._ing, kwargs)
            except Exception as exc:
                log.warning("prova_cp.wrap: stream tap failed: %s", exc)
                return result
        self._ing.emit(kwargs, _safe(result))
        return result

    async def _async_path(self, awaitable: Any, kwargs: dict) -> Any:
        response = await awaitable
        if kwargs.get("stream"):
            try:
                return _AsyncStreamTap(response, self._ing, kwargs)
            except Exception as exc:
                log.warning("prova_cp.wrap: async stream tap failed: %s", exc)
                return response
        self._ing.emit(kwargs, _safe(response))
        return response


class _AttrProxy:
    """Transparently proxies attribute access, swapping in a _CreateProxy for
    the configured leaf method (e.g. completions.create)."""

    def __init__(self, target: Any, client: Any, source: dict, provider: str, path: tuple[str, ...]) -> None:
        self.__dict__["_t"] = target
        self.__dict__["_c"] = client
        self.__dict__["_s"] = source
        self.__dict__["_p"] = provider
        self.__dict__["_path"] = path

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self.__dict__["_t"], name)
        new_path = self.__dict__["_path"] + (name,)
        leaf = (("chat", "completions", "create"), ("messages", "create"), ("responses", "create"))
        if new_path in leaf and callable(attr):
            return _CreateProxy(attr, self.__dict__["_c"], self.__dict__["_s"], self.__dict__["_p"])
        if callable(attr) or isinstance(attr, (str, int, float, bool, type(None))):
            return attr
        return _AttrProxy(attr, self.__dict__["_c"], self.__dict__["_s"], self.__dict__["_p"], new_path)


def _wrap(vendor_client: Any, prova_client: Any, provider: str, app_id: str, environment: str) -> Any:
    source = {"app_id": app_id, "environment": environment, "framework": provider}
    return _AttrProxy(vendor_client, prova_client, source, provider, ())


def wrap_openai(vendor_client: Any, prova_client: Any, *, app_id: str = "agent", environment: str = "production") -> Any:
    """Wrap an `openai.OpenAI` / `openai.AsyncOpenAI` client. `chat.completions.create`
    and `responses.create` calls (sync, async, streamed) are mirrored to Prova."""
    return _wrap(vendor_client, prova_client, "openai", app_id, environment)


def wrap_anthropic(vendor_client: Any, prova_client: Any, *, app_id: str = "agent", environment: str = "production") -> Any:
    """Wrap an `anthropic.Anthropic` / `anthropic.AsyncAnthropic` client.
    `messages.create` calls (sync, async, streamed) are mirrored to Prova."""
    return _wrap(vendor_client, prova_client, "anthropic", app_id, environment)
