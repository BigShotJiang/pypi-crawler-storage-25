"""CrewAI auto-instrumentation for Prova.

CrewAI does not expose LangChain-style callbacks. Its stable, version-tolerant
hooks are the `step_callback` and `task_callback` parameters on a Crew (and
`step_callback` on an Agent). This module wires those to Prova ingest.

Usage:

    from prova_cp import ProvaClient
    from prova_cp.crewai import ProvaCrewAI

    prova = ProvaClient(api_key="prv_...")
    tap = ProvaCrewAI(prova, app_id="research-crew", environment="production")

    crew = Crew(
        agents=[...],
        tasks=[...],
        step_callback=tap.step_callback,
        task_callback=tap.task_callback,
    )

Both callbacks are fail-silent: a Prova outage logs at warning level and never
breaks the crew. Agent steps become `agent_step` receipts; completed tasks
become `agent_run` receipts.
"""

from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger(__name__)

_MAX_LEN = 2000


def _safe(obj: Any, depth: int = 0) -> Any:
    if isinstance(obj, str):
        return obj[:_MAX_LEN] + ("..." if len(obj) > _MAX_LEN else "")
    if depth > 4:
        return "[truncated]"
    if isinstance(obj, dict):
        return {k: _safe(v, depth + 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_safe(v, depth + 1) for v in list(obj)[:50]]
    # CrewAI output objects: pull common attributes without importing crewai.
    for attr in ("raw", "output", "result", "summary", "description"):
        if hasattr(obj, attr):
            return _safe(getattr(obj, attr), depth + 1)
    return str(obj)[:_MAX_LEN]


class ProvaCrewAI:
    def __init__(
        self,
        client: Any,
        *,
        app_id: str = "crew",
        environment: str = "production",
        framework: str = "crewai",
    ) -> None:
        self._client = client
        self._source = {
            "app_id": app_id,
            "environment": environment,
            "framework": framework,
        }

    def step_callback(self, step_output: Any) -> None:
        """Pass as Crew(step_callback=...) or Agent(step_callback=...)."""
        try:
            agent = getattr(step_output, "agent", None)
            tool = getattr(step_output, "tool", None)
            self._client.ingest({
                "kind": "agent_step",
                "source": dict(self._source),
                "payload": {
                    "agent": str(agent) if agent else None,
                    "tool": str(tool) if tool else None,
                    "output": _safe(step_output),
                },
            })
        except Exception as exc:
            log.warning("ProvaCrewAI.step_callback failed: %s", exc)

    def task_callback(self, task_output: Any) -> None:
        """Pass as Crew(task_callback=...)."""
        try:
            self._client.ingest({
                "kind": "agent_run",
                "source": dict(self._source),
                "payload": {
                    "task": getattr(task_output, "description", None)
                    or getattr(task_output, "name", None),
                    "output": _safe(task_output),
                },
            })
        except Exception as exc:
            log.warning("ProvaCrewAI.task_callback failed: %s", exc)
