"""One-shot migration of LangSmith / Langfuse / OpenAI logs into the Audit Vault."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterable, Iterator, Mapping, Optional, TextIO

from .client import ProvaClient

Mapper = Callable[[Mapping[str, Any]], Optional[Dict[str, Any]]]


def _provider_of(model: Optional[str]) -> str:
    m = (model or "").lower()
    if m.startswith(("gpt-", "o1", "o3")) or "openai" in m:
        return "openai"
    if m.startswith("claude"):
        return "anthropic"
    if m.startswith(("gemini", "text-bison")):
        return "google"
    if m.startswith(("mistral", "codestral")):
        return "mistral"
    if m.startswith(("llama", "meta-")):
        return "meta"
    return "other"


def _model_block(model: Optional[str]) -> Optional[Dict[str, Any]]:
    if not model:
        return None
    return {"provider": _provider_of(model), "name": model}


def langsmith_mapper(raw: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    rid = raw.get("id")
    if not isinstance(rid, str):
        return None
    run_type = raw.get("run_type") or "llm"
    extra = raw.get("extra") if isinstance(raw.get("extra"), Mapping) else {}
    invocation = extra.get("invocation_params") if isinstance(extra.get("invocation_params"), Mapping) else {}
    model = invocation.get("model") or raw.get("model")
    session = raw.get("session_name") or raw.get("session_id")
    kind = (
        "tool_call" if run_type == "tool"
        else "agent_run" if run_type in ("chain", "agent")
        else "model_call"
    )
    return {
        "idempotency_key": f"langsmith:{rid}",
        "occurred_at": raw.get("start_time"),
        "kind": kind,
        "source": {"org_id": "", "framework": "langgraph", "app_id": session or raw.get("name")},
        "model": _model_block(model if isinstance(model, str) else None),
        "payload": {
            "_migrated_from": "langsmith",
            "name": raw.get("name"),
            "run_type": run_type,
            "inputs": raw.get("inputs"),
            "outputs": raw.get("outputs"),
            "end_time": raw.get("end_time"),
            "latency_ms": raw.get("latency") if isinstance(raw.get("latency"), (int, float)) else None,
        },
    }


def langfuse_mapper(raw: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    rid = raw.get("id")
    if not isinstance(rid, str):
        return None
    obs_type = str(raw.get("type") or "GENERATION").upper()
    model = raw.get("model") if isinstance(raw.get("model"), str) else None
    start = raw.get("startTime") or raw.get("start_time")
    trace_id = raw.get("traceId") or raw.get("trace_id")
    kind = "agent_step" if obs_type in ("SPAN", "EVENT") else "model_call"
    return {
        "idempotency_key": f"langfuse:{rid}",
        "occurred_at": start if isinstance(start, str) else None,
        "kind": kind,
        "source": {"org_id": "", "framework": "custom", "app_id": trace_id},
        "model": _model_block(model),
        "payload": {
            "_migrated_from": "langfuse",
            "name": raw.get("name"),
            "type": obs_type,
            "input": raw.get("input"),
            "output": raw.get("output"),
            "metadata": raw.get("metadata"),
            "usage": raw.get("usage"),
        },
    }


def openai_mapper(raw: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    rid = raw.get("id") or raw.get("request_id")
    if not isinstance(rid, str):
        return None
    model = raw.get("model") if isinstance(raw.get("model"), str) else None
    created = raw.get("created") if isinstance(raw.get("created"), (int, float)) else None
    created_at = raw.get("created_at")
    if isinstance(created_at, str):
        occurred = created_at
    elif isinstance(created_at, (int, float)):
        occurred = datetime.fromtimestamp(created_at, tz=timezone.utc).isoformat()
    elif created is not None:
        occurred = datetime.fromtimestamp(created, tz=timezone.utc).isoformat()
    else:
        occurred = None
    usage = raw.get("usage")
    if not isinstance(usage, Mapping):
        usage = {
            "prompt_tokens": raw.get("input_tokens"),
            "completion_tokens": raw.get("output_tokens"),
        }
    return {
        "idempotency_key": f"openai:{rid}",
        "occurred_at": occurred,
        "kind": "model_call",
        "source": {"org_id": "", "framework": "custom"},
        "model": _model_block(model),
        "payload": {
            "_migrated_from": "openai",
            "request_id": rid,
            "choices": raw.get("choices"),
            "messages": raw.get("messages"),
            "usage": usage,
        },
    }


MAPPERS: Dict[str, Mapper] = {
    "langsmith": langsmith_mapper,
    "langfuse": langfuse_mapper,
    "openai": openai_mapper,
}


def read_ndjson(stream: TextIO) -> Iterator[Dict[str, Any]]:
    for line in stream:
        line = line.strip()
        if not line:
            continue
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            continue


def migrate(
    client: ProvaClient,
    source: str,
    rows: Iterable[Mapping[str, Any]],
    *,
    batch_size: int = 200,
    on_progress: Optional[Callable[[Dict[str, int]], None]] = None,
) -> Dict[str, int]:
    mapper = MAPPERS.get(source)
    if mapper is None:
        raise ValueError(f"unknown source format: {source}")
    size = max(1, min(1000, batch_size))
    batch: list[Dict[str, Any]] = []
    total = ingested = skipped = batch_n = 0

    def flush() -> None:
        nonlocal batch, ingested, batch_n
        if not batch:
            return
        batch_n += 1
        res = client.ingest(batch)
        ingested += int(res.get("count", 0))
        if on_progress:
            on_progress({"batch": batch_n, "ingested": ingested, "skipped": skipped, "total": total})
        batch = []

    for raw in rows:
        total += 1
        mapped = mapper(raw)
        if mapped is None:
            skipped += 1
            continue
        batch.append(mapped)
        if len(batch) >= size:
            flush()
    flush()
    return {"total": total, "ingested": ingested, "skipped": skipped, "batches": batch_n}
