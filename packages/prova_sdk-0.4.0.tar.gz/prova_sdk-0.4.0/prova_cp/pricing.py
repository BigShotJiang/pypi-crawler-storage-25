"""Built-in model pricing for the in-process cost circuit breaker.

This is a LOCAL ESTIMATE, not the canonical figure. The server prices every
model_call receipt from a maintained catalog (``lib/cost/compute.ts`` reading
the ``bench_model_pricing`` table) and signs ``payload.cost_usd`` into the
receipt. That signed figure is the one Finance and auditors read.

The SDK needs a price table it can use *without a network round-trip* so a
budget circuit breaker can stop a runaway run in-process, and so local mode
(no account) can estimate spend offline. The numbers below are published list
prices in USD per million tokens, rounded, and refreshed periodically. They
are deliberately approximate: the circuit breaker exists to stop a run that is
clearly blowing its budget, not to be penny-accurate. When you need exact
spend, read ``cost_usd`` off the signed receipt.

Override or extend the catalog when you run a model that is not listed, or want
your negotiated rate:

    from prova_cp import set_model_price
    set_model_price("my-finetune", prompt_per_mtok_usd=4.0, completion_per_mtok_usd=12.0)

The compute formula and the model-name lookup (exact, then case-insensitive,
then longest-prefix so ``gpt-4o-2024-08-06`` resolves to ``gpt-4o``) match the
server so a local estimate lands in the same ballpark as the signed figure.
"""

from __future__ import annotations

from typing import Dict, Optional

# USD per million tokens: model -> (prompt, completion). Lowercase keys; the
# lookup lowercases the requested model name before matching.
_BUILTIN_PRICES: Dict[str, tuple] = {
    # OpenAI
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4.1": (2.00, 8.00),
    "gpt-4.1-mini": (0.40, 1.60),
    "gpt-4-turbo": (10.00, 30.00),
    "gpt-4": (30.00, 60.00),
    "gpt-3.5-turbo": (0.50, 1.50),
    "o1": (15.00, 60.00),
    "o1-mini": (1.10, 4.40),
    "o3-mini": (1.10, 4.40),
    # Anthropic
    "claude-opus-4": (15.00, 75.00),
    "claude-sonnet-4": (3.00, 15.00),
    "claude-3-opus": (15.00, 75.00),
    "claude-3-5-sonnet": (3.00, 15.00),
    "claude-3-5-haiku": (0.80, 4.00),
    "claude-3-haiku": (0.25, 1.25),
    "claude-3-sonnet": (3.00, 15.00),
    # Google
    "gemini-1.5-pro": (1.25, 5.00),
    "gemini-1.5-flash": (0.075, 0.30),
    "gemini-2.0-flash": (0.10, 0.40),
    "gemini-2.5-pro": (1.25, 10.00),
}

# User overrides take precedence over the built-ins.
_OVERRIDES: Dict[str, tuple] = {}


def set_model_price(
    model: str,
    *,
    prompt_per_mtok_usd: float,
    completion_per_mtok_usd: float,
) -> None:
    """Register or override a model's price (USD per million tokens) for the
    local cost estimate. Affects the circuit breaker and local mode only; the
    signed receipt cost is always computed server-side."""
    if not isinstance(model, str) or not model:
        raise ValueError("model must be a non-empty string")
    _OVERRIDES[model.lower()] = (
        float(prompt_per_mtok_usd),
        float(completion_per_mtok_usd),
    )


def _lookup(model_name: str) -> Optional[tuple]:
    """Exact, then case-insensitive, then longest-prefix match. Overrides win.
    Mirrors lookupPrice in lib/cost/compute.ts."""
    lower = model_name.lower()
    if lower in _OVERRIDES:
        return _OVERRIDES[lower]
    if lower in _BUILTIN_PRICES:
        return _BUILTIN_PRICES[lower]
    best: Optional[tuple] = None
    best_len = 0
    for table in (_OVERRIDES, _BUILTIN_PRICES):
        for key, price in table.items():
            if lower.startswith(key) and len(key) > best_len:
                best = price
                best_len = len(key)
        if best is not None:
            return best
    return None


def estimate_cost_usd(
    model_name: Optional[str],
    prompt_tokens: float,
    completion_tokens: float,
) -> Optional[float]:
    """Estimate USD cost from token counts using the built-in catalog. Returns
    None when the model is unknown (caller treats unknown cost as zero so an
    unpriced model never trips the breaker on a phantom figure).

    Same arithmetic as the server's computeCostUsd; the catalog differs (local
    estimate vs the maintained server table)."""
    if not model_name:
        return None
    if prompt_tokens < 0 or completion_tokens < 0:
        return None
    price = _lookup(model_name)
    if price is None:
        return None
    prompt_per_mtok, completion_per_mtok = price
    cost = (
        (prompt_tokens / 1_000_000.0) * prompt_per_mtok
        + (completion_tokens / 1_000_000.0) * completion_per_mtok
    )
    # 6 dp, same rounding as the server, so local and signed figures line up.
    return round(cost, 6)


def estimate_cost_from_usage(
    model_name: Optional[str],
    token_usage: Optional[dict],
) -> Optional[float]:
    """Convenience over :func:`estimate_cost_usd` that reads the normalized
    ``{prompt, completion, total}`` token-usage shape the SDK produces."""
    if not isinstance(token_usage, dict):
        return None
    prompt = token_usage.get("prompt")
    completion = token_usage.get("completion")
    if not isinstance(prompt, (int, float)) or not isinstance(completion, (int, float)):
        return None
    return estimate_cost_usd(model_name, float(prompt), float(completion))
