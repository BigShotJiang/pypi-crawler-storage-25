"""One-line onboarding magic moment.

Usage:

    python -c "import prova_cp; prova_cp.demo()"

Hits the public Prova demo endpoint with no authentication, receives a
signed claims-pipeline trace receipt with a real coordination_loop
finding, and prints a shareable public URL plus a claim-to-real-org URL.

The endpoint is rate-limited per IP (60/hour); a 429 surfaces a clear
"sign up for a free API key" message rather than a noisy traceback.

The receipt is stored server-side for 7 days under a 128-bit random
share_code, so the printed URL is safe to share on Twitter / in a
Slack message without leaking anything sensitive (the entire payload is
synthetic).
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, Optional

import httpx

from .client import DEFAULT_BASE_URL


class ProvaDemoError(RuntimeError):
    """Raised when the demo endpoint returns a non-OK response and the SDK
    cannot recover (e.g. 500, network failure, malformed JSON)."""


def demo(
    *,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
    print_output: bool = True,
) -> Dict[str, Any]:
    """Generate a signed demo receipt and return the response payload.

    Args:
        base_url: override the Prova API base. Defaults to the
            ``PROVA_BASE_URL`` env var, then ``https://api.prova.cobound.dev``.
        timeout: HTTP timeout in seconds for the single POST.
        print_output: when True (the default), pretty-prints a banner with
            the public URL, claim URL, and finding summary to stdout. Set
            False from scripts or tests to suppress.

    Returns:
        Dict with ``share_code``, ``public_url``, ``claim_url``, ``receipt``.

    Raises:
        ProvaDemoError on rate-limit (429), persistence failure (500), or
        a malformed response. Network errors propagate as httpx exceptions.
    """
    resolved = (base_url or os.environ.get("PROVA_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
    url = f"{resolved}/api/v1/demo"

    headers = {
        "Content-Type": "application/json",
        "User-Agent": "prova-sdk python demo",
    }
    with httpx.Client(timeout=timeout) as client:
        try:
            resp = client.post(url, json={}, headers=headers)
        except httpx.RequestError as exc:
            raise ProvaDemoError(
                f"could not reach {url}: {exc}. "
                "Check your network and try again."
            ) from exc

    if resp.status_code == 429:
        try:
            body = resp.json()
        except Exception:
            body = {}
        retry = resp.headers.get("Retry-After") or body.get("retry_after_seconds")
        raise ProvaDemoError(
            "demo rate limit hit (60 requests per hour per IP). "
            f"Retry in ~{retry}s, or sign up at https://prova.cobound.dev/signup "
            "for a free API key with a higher quota."
        )

    if resp.status_code >= 400:
        raise ProvaDemoError(
            f"demo endpoint returned {resp.status_code}: {resp.text[:200]}"
        )

    try:
        data: Dict[str, Any] = resp.json()
    except Exception as exc:
        raise ProvaDemoError(f"demo endpoint returned non-JSON: {resp.text[:200]}") from exc

    for required in ("share_code", "public_url", "claim_url", "receipt"):
        if required not in data:
            raise ProvaDemoError(
                f"demo endpoint response missing '{required}': {data!r}"
            )

    if print_output:
        _print_banner(data)

    return data


def _print_banner(data: Dict[str, Any]) -> None:
    """Pretty-print the demo result. Kept separate so callers can suppress
    via print_output=False without losing the return-value contract."""
    receipt = data.get("receipt") or {}
    findings = receipt.get("findings") or []
    finding_summary = "no findings"
    if findings:
        first = findings[0]
        finding_summary = (
            f"{first.get('detector', 'detector:?')} "
            f"({first.get('severity', '?')}): {first.get('summary', '')}"
        )

    integrity = receipt.get("integrity") or {}
    sig = integrity.get("signature") or ""
    sig_preview = (sig[:16] + "...") if sig else "(none)"

    lines = [
        "",
        "Prova demo receipt generated.",
        "",
        f"  public URL: {data['public_url']}",
        f"  claim URL:  {data['claim_url']}",
        f"  share_code: {data['share_code']}",
        f"  finding:    {finding_summary}",
        f"  signed:     ed25519:{sig_preview}",
        "",
        "  Open the public URL to view the signed receipt.",
        "  Open the claim URL to attach it to a real Prova org.",
        "  Receipt is shareable for 7 days.",
        "",
    ]
    sys.stdout.write("\n".join(lines) + "\n")
    sys.stdout.flush()
