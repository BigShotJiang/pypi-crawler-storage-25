"""Token-usage normalization across LLM providers.

LangChain's `LLMResult` exposes provider-specific token counts in
different places. OpenAI puts them in `llm_output.token_usage`, Anthropic
on the generation's message (`usage_metadata` or `response_metadata.usage`),
Bedrock varies, and Google Gemini uses its own field names entirely. The
cost-attribution pipeline needs ONE normalized shape:

    {"prompt": int, "completion": int, "total": int}

`extract_token_usage` tries every known provider shape, returns the
normalized dict on success, or `None` when no recognizable token data is
present. The function is intentionally framework-light: no LangChain
import, so it can be unit-tested with plain dicts as fixtures.

Wire-up: `ProvaCallbackHandler.on_llm_end` calls this and attaches the
result to the emitted event's `payload.token_usage`. The server-side
cost transform (`lib/cost/compute.ts` `maybeAttachCost`) then computes
`payload.cost_usd` from the model name + token_usage before signing.
"""

from __future__ import annotations

from typing import Any, Mapping, Optional


def _coerce_int(value: Any) -> Optional[int]:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value) if value >= 0 else None
    return None


def _normalize(
    prompt: Any, completion: Any, total: Any = None
) -> Optional[dict]:
    p = _coerce_int(prompt)
    c = _coerce_int(completion)
    if p is None or c is None:
        return None
    t = _coerce_int(total)
    if t is None:
        t = p + c
    return {"prompt": p, "completion": c, "total": t}


def _from_openai_shape(d: Mapping[str, Any]) -> Optional[dict]:
    """OpenAI / LangChain canonical shape: `token_usage` dict with
    `prompt_tokens` / `completion_tokens` / `total_tokens`."""
    tu = d.get("token_usage")
    if isinstance(tu, Mapping):
        out = _normalize(
            tu.get("prompt_tokens"),
            tu.get("completion_tokens"),
            tu.get("total_tokens"),
        )
        if out is not None:
            return out
    # Some adapters skip `token_usage` and hoist the keys to `llm_output` directly.
    out = _normalize(
        d.get("prompt_tokens"), d.get("completion_tokens"), d.get("total_tokens")
    )
    if out is not None:
        return out
    return None


def _from_anthropic_shape(d: Mapping[str, Any]) -> Optional[dict]:
    """Anthropic shape: `usage` with `input_tokens` / `output_tokens`."""
    usage = d.get("usage")
    if isinstance(usage, Mapping):
        out = _normalize(usage.get("input_tokens"), usage.get("output_tokens"))
        if out is not None:
            return out
    out = _normalize(d.get("input_tokens"), d.get("output_tokens"))
    if out is not None:
        return out
    return None


def _from_gemini_shape(d: Mapping[str, Any]) -> Optional[dict]:
    """Google Gemini shape: `prompt_token_count` / `candidates_token_count`."""
    return _normalize(
        d.get("prompt_token_count"),
        d.get("candidates_token_count"),
        d.get("total_token_count"),
    )


def _from_generation_message(generation: Any) -> Optional[dict]:
    """Anthropic-via-LangChain often puts usage on the message itself:
    `generation.message.usage_metadata = {input_tokens, output_tokens, total_tokens}`
    or `generation.message.response_metadata.usage = {input_tokens, output_tokens}`.
    """
    message = getattr(generation, "message", None)
    if message is None:
        return None

    usage_meta = getattr(message, "usage_metadata", None)
    if isinstance(usage_meta, Mapping):
        out = _normalize(
            usage_meta.get("input_tokens"),
            usage_meta.get("output_tokens"),
            usage_meta.get("total_tokens"),
        )
        if out is not None:
            return out

    response_meta = getattr(message, "response_metadata", None)
    if isinstance(response_meta, Mapping):
        usage = response_meta.get("usage")
        if isinstance(usage, Mapping):
            out = _normalize(usage.get("input_tokens"), usage.get("output_tokens"))
            if out is not None:
                return out
            out = _normalize(
                usage.get("prompt_tokens"), usage.get("completion_tokens")
            )
            if out is not None:
                return out
    return None


def extract_token_usage(
    llm_output: Optional[Mapping[str, Any]] = None,
    generation: Any = None,
    model_name: Optional[str] = None,
) -> Optional[dict]:
    """Best-effort extraction of `{prompt, completion, total}` from an
    LLM response. Tries provider shapes in this order:

      1. OpenAI-canonical `token_usage` block on `llm_output`
      2. Anthropic `usage` block on `llm_output`
      3. Anthropic-via-LangChain on the message metadata
      4. Google Gemini fields on `llm_output`
      5. Anthropic-style flat keys on `llm_output`

    `model_name` is accepted but unused today; reserved so callers don't
    have to refactor when model-specific normalization becomes necessary.
    """
    _ = model_name  # reserved for future model-specific handling

    if isinstance(llm_output, Mapping):
        for finder in (_from_openai_shape, _from_anthropic_shape, _from_gemini_shape):
            out = finder(llm_output)
            if out is not None:
                return out

    if generation is not None:
        out = _from_generation_message(generation)
        if out is not None:
            return out

    return None
