"""Runtime autonomy boundaries -- client-side enforcement.

A developer declares what an agent run is allowed to do:

    boundaries = ProvaBoundaries(
        allowed_tools=["search", "send_email"],
        max_steps=20,
        budget_usd_per_run=0.50,
        data_scopes=["customer_id"],
    )

ProvaBoundaries observes the run as it progresses (one observation per
step / tool call / model call) and raises ``BoundaryViolationError`` the
instant any dimension is exceeded. The Python class is a faithful port
of ``lib/boundaries/schema.ts`` ``evaluateBoundaries``: dimension order
and detail shapes match exactly so a locally-caught violation matches
what the server-side ``boundary_violation`` policy reports.

Typical wiring is via ``ProvaCallbackHandler``:

    handler = ProvaCallbackHandler(
        prova_client,
        boundaries=boundaries,
        break_on_violation=True,
    )
    graph.invoke(inputs, config={"callbacks": [handler]})

A standalone use without the LangChain callback is also supported:

    guard = ProvaBoundaries(...)
    try:
        for step in run_agent():
            guard.observe_step(step.node)
            for tool in step.tools:
                guard.observe_tool(tool.name)
            guard.observe_cost(step.cost_usd)
    except BoundaryViolationError as e:
        # e.match carries dimension, summary, details
        ...

Failure mode mirrors LoopGuard: short-circuits after the first violation
fires so a long run does not pay the cost repeatedly.
"""

from __future__ import annotations

from typing import Any, Iterable, List, Mapping, Optional, Set


SCHEMA_VERSION = "1"
_MAX_TOOLS = 256
_MAX_DATA_SCOPES = 256
_MAX_STRING_LEN = 256
_MIN_STEPS = 1
_MAX_STEPS = 100_000
_MAX_BUDGET = 1_000_000.0


class BoundaryViolationError(RuntimeError):
    """Raised by ProvaBoundaries when a manifest dimension is exceeded.

    The ``match`` attribute mirrors the ``BoundaryViolationDetails`` shape
    from ``lib/boundaries/schema.ts``: ``{dimension, summary, details}``.
    """

    def __init__(self, match: Mapping[str, Any]) -> None:
        super().__init__(str(match.get("summary") or "Boundary violation"))
        self.match = dict(match)


def _validate_string_list(name: str, value: Any, max_len: int) -> List[str]:
    if not isinstance(value, (list, tuple)):
        raise ValueError(f"{name} must be a list of strings")
    if len(value) > max_len:
        raise ValueError(f"{name} too large (max {max_len})")
    out: List[str] = []
    for item in value:
        if not isinstance(item, str) or not item or len(item) > _MAX_STRING_LEN:
            raise ValueError(
                f"{name} must be non-empty strings under {_MAX_STRING_LEN} chars"
            )
        out.append(item)
    return out


class ProvaBoundaries:
    """Stateful in-process enforcement of a boundary manifest.

    Construct once per agent run. Call ``observe_step``,
    ``observe_tool``, and ``observe_cost`` as the run progresses (any
    order, any combination). The guard checks all four dimensions after
    every observation and raises ``BoundaryViolationError`` on the first
    violation (when ``raise_on_violation=True``, the default).
    """

    def __init__(
        self,
        *,
        allowed_tools: Iterable[str],
        max_steps: int,
        budget_usd_per_run: float,
        data_scopes: Iterable[str] = (),
        raise_on_violation: bool = True,
    ) -> None:
        tools = _validate_string_list("allowed_tools", list(allowed_tools), _MAX_TOOLS)
        scopes = _validate_string_list(
            "data_scopes", list(data_scopes), _MAX_DATA_SCOPES
        )
        if not isinstance(max_steps, int) or max_steps < _MIN_STEPS or max_steps > _MAX_STEPS:
            raise ValueError(
                f"max_steps must be int in [{_MIN_STEPS}, {_MAX_STEPS}]"
            )
        if (
            not isinstance(budget_usd_per_run, (int, float))
            or budget_usd_per_run < 0
            or budget_usd_per_run > _MAX_BUDGET
        ):
            raise ValueError(
                f"budget_usd_per_run must be non-negative number <= {_MAX_BUDGET}"
            )

        self._allowed_tools: Set[str] = set(tools)
        self._max_steps: int = max_steps
        self._budget_usd: float = float(budget_usd_per_run)
        self._data_scopes: Set[str] = set(scopes)
        self._raise = raise_on_violation

        # Mutable state across the run.
        self._step_count: int = 0
        self._cost_usd: float = 0.0
        self._tools_invoked: List[str] = []
        self._tools_seen: Set[str] = set()
        self._data_scopes_touched: List[str] = []
        self._scopes_seen: Set[str] = set()
        self._fired: bool = False

    # ------------------------------------------------------------------
    # Manifest snapshot (sent to /api/v1/runs/start)
    # ------------------------------------------------------------------

    def manifest(self) -> dict:
        """Return the JSON-serializable manifest. Matches BoundaryManifest
        in lib/boundaries/schema.ts."""
        return {
            "version": SCHEMA_VERSION,
            "allowed_tools": sorted(self._allowed_tools),
            "max_steps": self._max_steps,
            "budget_usd_per_run": self._budget_usd,
            "data_scopes": sorted(self._data_scopes),
        }

    # ------------------------------------------------------------------
    # Observations
    # ------------------------------------------------------------------

    def observe_step(self, node: Optional[str] = None) -> Optional[dict]:
        """Record one agent_step. ``node`` is recorded for debugging but
        not used in step-count enforcement."""
        _ = node
        if self._fired:
            return None
        self._step_count += 1
        return self._check()

    def observe_tool(self, tool: str) -> Optional[dict]:
        """Record an invocation of a named tool."""
        if self._fired:
            return None
        if not isinstance(tool, str) or not tool:
            return None
        if tool not in self._tools_seen:
            self._tools_seen.add(tool)
            self._tools_invoked.append(tool)
        return self._check()

    def observe_cost(self, cost_usd: float) -> Optional[dict]:
        """Add cost_usd to the running run cost."""
        if self._fired:
            return None
        if isinstance(cost_usd, (int, float)) and cost_usd > 0:
            self._cost_usd += float(cost_usd)
        return self._check()

    def observe_data_scope(self, scope: str) -> Optional[dict]:
        """Record a touched data scope."""
        if self._fired:
            return None
        if not isinstance(scope, str) or not scope:
            return None
        if scope not in self._scopes_seen:
            self._scopes_seen.add(scope)
            self._data_scopes_touched.append(scope)
        return self._check()

    def summary(self) -> dict:
        """Current run summary, in the same shape as RunSummary in
        lib/boundaries/schema.ts."""
        return {
            "step_count": self._step_count,
            "cost_usd": self._cost_usd,
            "tools_invoked": list(self._tools_invoked),
            "data_scopes_touched": list(self._data_scopes_touched),
        }

    # ------------------------------------------------------------------
    # Evaluation (faithful port of evaluateBoundaries in schema.ts)
    # ------------------------------------------------------------------

    def _check(self) -> Optional[dict]:
        violation = evaluate_boundaries(self.summary(), self.manifest())
        if violation is None:
            return None
        self._fired = True
        if self._raise:
            raise BoundaryViolationError(violation)
        return violation


def evaluate_boundaries(
    summary: Mapping[str, Any],
    manifest: Mapping[str, Any],
) -> Optional[dict]:
    """Pure function: compare a run summary against a manifest. Returns
    the FIRST violation (in dimension order: tools -> steps -> budget ->
    scopes) or None if the run is within bounds.

    Dimension order MUST match lib/boundaries/schema.ts
    evaluateBoundaries; the contract test pins this.
    """
    allowed_tools = list(manifest.get("allowed_tools") or [])
    max_steps = int(manifest.get("max_steps") or 0)
    budget = float(manifest.get("budget_usd_per_run") or 0.0)
    data_scopes = list(manifest.get("data_scopes") or [])

    step_count = int(summary.get("step_count") or 0)
    cost_usd = float(summary.get("cost_usd") or 0.0)
    tools_invoked = list(summary.get("tools_invoked") or [])
    scopes_touched = list(summary.get("data_scopes_touched") or [])

    # 1. Tools.
    if allowed_tools:
        allow = set(allowed_tools)
        for tool in tools_invoked:
            if tool not in allow:
                return {
                    "dimension": "allowed_tools",
                    "summary": f"Agent invoked tool '{tool}' which is not in the allowed list.",
                    "details": {
                        "disallowed_tool": tool,
                        "allowed_tools": list(allowed_tools),
                    },
                }

    # 2. Steps.
    if step_count > max_steps:
        return {
            "dimension": "max_steps",
            "summary": f"Agent exceeded max_steps ({step_count} of {max_steps}).",
            "details": {
                "step_count": step_count,
                "max_steps": max_steps,
            },
        }

    # 3. Budget.
    if cost_usd > budget:
        return {
            "dimension": "budget_usd_per_run",
            "summary": f"Agent exceeded run budget (${cost_usd:.4f} of ${budget:.4f}).",
            "details": {
                "cost_usd": cost_usd,
                "budget_usd_per_run": budget,
                "overage_usd": cost_usd - budget,
            },
        }

    # 4. Data scopes.
    if data_scopes:
        allow = set(data_scopes)
        for scope in scopes_touched:
            if scope not in allow:
                return {
                    "dimension": "data_scopes",
                    "summary": f"Agent touched data scope '{scope}' which is not declared on the manifest.",
                    "details": {
                        "disallowed_scope": scope,
                        "allowed_scopes": list(data_scopes),
                    },
                }

    return None
