"""Local-first analysis: run loop detection and cost estimation entirely on
your own machine. No account, no API key, no network. Nothing leaves the
process.

    prova-local --file trace.ndjson

Reads newline-delimited JSON (the shape the SDK emits: each line an object with
``kind`` and ``payload``, optionally ``model``) and prints a report: how many
steps ran, estimated spend, and whether a coordination loop formed. Useful
before you wire Prova into production, in CI as a gate, or air-gapped.

When you want a signed receipt and the dashboard, send the same events to Prova
(drop in the ``ProvaCallbackHandler``, or pipe the file through
``prova-migrate``). The loop algorithm here is the same one the server runs, so
a loop seen locally is the loop the signed receipt would report.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Mapping
from typing import Any, Dict, Iterable, List, Optional

from .loopguard import detect_loop
from .pricing import estimate_cost_from_usage


def analyze_events(events: Iterable[Mapping[str, Any]]) -> Dict[str, Any]:
    """Run loop detection + cost estimation over a sequence of events. Pure:
    no network, no side effects. Returns a JSON-serializable report."""
    steps: List[Dict[str, Any]] = []
    cost = 0.0
    model_calls = 0
    models: Dict[str, int] = {}
    event_count = 0

    for event in events:
        event_count += 1
        if not isinstance(event, Mapping):
            continue
        kind = event.get("kind")
        payload = event.get("payload") if isinstance(event.get("payload"), Mapping) else {}

        if kind == "agent_run":
            for s in payload.get("steps") or []:
                if isinstance(s, Mapping) and s.get("node"):
                    steps.append(
                        {
                            "node": s["node"],
                            "reads": dict(s.get("reads") or {}),
                            "writes": dict(s.get("writes") or {}),
                        }
                    )
        elif kind == "agent_step":
            node = payload.get("node")
            if node:
                steps.append(
                    {
                        "node": node,
                        "reads": dict(payload.get("reads") or {}),
                        "writes": dict(payload.get("writes") or {}),
                    }
                )
        elif kind == "model_call":
            model_calls += 1
            model_obj = event.get("model") if isinstance(event.get("model"), Mapping) else {}
            model_name = model_obj.get("name")
            if isinstance(model_name, str) and model_name:
                models[model_name] = models.get(model_name, 0) + 1
            est = estimate_cost_from_usage(model_name, payload.get("token_usage"))
            if est:
                cost += est

    loop = detect_loop(steps) if steps else None

    return {
        "events": event_count,
        "steps": len(steps),
        "model_calls": model_calls,
        "models": models,
        "estimated_cost_usd": round(cost, 6),
        "loop": loop,
    }


def format_report(report: Mapping[str, Any]) -> str:
    """Human-readable rendering of :func:`analyze_events` output."""
    lines = [
        "",
        "Prova local analysis (nothing left this machine).",
        "",
        f"  events:          {report.get('events', 0)}",
        f"  agent steps:     {report.get('steps', 0)}",
        f"  model calls:     {report.get('model_calls', 0)}",
        f"  estimated spend: ${report.get('estimated_cost_usd', 0.0):.4f} (local estimate)",
    ]
    loop = report.get("loop")
    if loop:
        agents = " -> ".join(str(a) for a in loop.get("agents", []))
        lines.append(
            f"  coordination loop: {agents} "
            f"(persisted {loop.get('persistence_steps')}/{loop.get('total_steps')} steps)"
        )
    else:
        lines.append("  coordination loop: none detected")
    lines.append("")
    lines.append("  Send these events to Prova for a signed receipt + dashboard.")
    lines.append("")
    return "\n".join(lines)


def _read_ndjson(stream) -> Iterable[Dict[str, Any]]:
    for line in stream:
        line = line.strip()
        if not line:
            continue
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            continue


def main(argv: Optional[list] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="prova-local",
        description=(
            "Run Prova loop detection + cost estimation locally. "
            "No account, no network."
        ),
    )
    parser.add_argument(
        "--file",
        required=True,
        help='Path to an NDJSON file of events, or "-" for stdin.',
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit the report as JSON instead of a human-readable summary.",
    )
    parser.add_argument(
        "--fail-on-loop",
        action="store_true",
        help="Exit non-zero (3) when a coordination loop is detected, for CI gating.",
    )
    args = parser.parse_args(argv)

    stream = sys.stdin if args.file == "-" else open(args.file, "r", encoding="utf-8")
    try:
        report = analyze_events(_read_ndjson(stream))
    finally:
        if stream is not sys.stdin:
            stream.close()

    if args.json:
        print(json.dumps(report))
    else:
        sys.stdout.write(format_report(report) + "\n")

    if args.fail_on_loop and report.get("loop"):
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
