"""ProvaClient: synchronous httpx wrapper around ingest, gateway-check, register."""

from __future__ import annotations

import os
import random
import time
from typing import Any, Iterable, Mapping, Optional, Union

import httpx

from .verify import verify_receipt, ReceiptVerificationError  # noqa: F401 (re-exported)

DEFAULT_BASE_URL = "https://api.prova.cobound.dev"
DEFAULT_TIMEOUT = 30.0
RETRYABLE_STATUS = {408, 425, 429, 500, 502, 503, 504}


class ProvaApiError(Exception):
    def __init__(self, status: int, code: str, detail: Any) -> None:
        super().__init__(f"Prova API {status} {code}: {detail}")
        self.status = status
        self.code = code
        self.detail = detail


class ProvaClient:
    def __init__(
        self,
        api_key: str,
        *,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        retry_attempts: int = 4,
        retry_backoff: float = 0.25,
        retry_max_backoff: float = 4.0,
        verify_receipts: bool = False,
        user_agent: str = "prova-sdk python",
        transport: Optional[httpx.BaseTransport] = None,
    ) -> None:
        if not api_key:
            raise ValueError("ProvaClient: api_key is required")
        self._api_key = api_key
        self._base_url = (base_url or os.environ.get("PROVA_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self._timeout = timeout
        self._attempts = retry_attempts
        self._backoff = retry_backoff
        self._max_backoff = retry_max_backoff
        self._verify_receipts = verify_receipts
        self._http = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers={"User-Agent": user_agent, "Content-Type": "application/json"},
            transport=transport,
        )

    def __enter__(self) -> "ProvaClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    def _request(self, path: str, body: Any, *, idempotency_key: Optional[str] = None) -> Any:
        headers = {"Authorization": f"Bearer {self._api_key}"}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        last_err: Optional[BaseException] = None
        for attempt in range(1, self._attempts + 1):
            try:
                resp = self._http.post(path, json=body, headers=headers)
            except httpx.RequestError as e:
                last_err = e
                resp = None
            if resp is not None:
                if resp.status_code < 400:
                    return resp.json()
                status = resp.status_code
                try:
                    parsed = resp.json()
                except Exception:
                    parsed = resp.text
                code = parsed.get("error") if isinstance(parsed, dict) else "http_error"
                if status not in RETRYABLE_STATUS or attempt == self._attempts:
                    raise ProvaApiError(status, str(code), parsed)
                last_err = ProvaApiError(status, str(code), parsed)
            sleep = min(self._max_backoff, self._backoff * (2 ** (attempt - 1)))
            time.sleep(sleep + random.random() * 0.05)
        assert last_err is not None
        raise last_err

    def ingest(self, events: Union[Mapping[str, Any], Iterable[Mapping[str, Any]]]) -> Mapping[str, Any]:
        body = events if isinstance(events, list) else (list(events) if not isinstance(events, Mapping) else events)
        res = self._request("/api/v1/audit/ingest", body)
        if self._verify_receipts:
            for r in res.get("receipts", []):
                verify_receipt(r, base_url=self._base_url, client=self._http)
        return res

    def gateway_check(self, event: Mapping[str, Any]) -> Mapping[str, Any]:
        res = self._request("/api/v1/gateway/check", event)
        if self._verify_receipts and res.get("receipt"):
            verify_receipt(res["receipt"], base_url=self._base_url, client=self._http)
        return res

    def register(
        self,
        integrations: Union[Mapping[str, Any], Iterable[Mapping[str, Any]]],
    ) -> Mapping[str, Any]:
        body = integrations if isinstance(integrations, (list, Mapping)) else list(integrations)
        return self._request("/api/v1/inventory", body)

    def register_run(
        self,
        run_id: str,
        boundaries: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        """Register a boundary manifest at the start of an agent run.

        Returns a signed receipt of kind ``agent_run_manifest``. Subsequent
        ingested events that carry ``payload.run_id == run_id`` are
        evaluated against this manifest by the server-side
        ``boundary_violation`` policy.
        """
        body = {"run_id": run_id, "boundaries": boundaries}
        return self._request("/api/v1/runs/start", body)

    def verify(self, receipt: Mapping[str, Any]) -> None:
        verify_receipt(receipt, base_url=self._base_url, client=self._http)
