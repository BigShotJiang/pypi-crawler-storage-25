"""LangChain / LangGraph callback handler for automatic Prova instrumentation.

Drop ProvaCallbackHandler into any LangGraph graph or LangChain chain and every
LLM call, chain invocation, and tool call is automatically ingested as a signed
Prova receipt.

Usage:

    from prova_cp import ProvaClient
    from prova_cp.callbacks import ProvaCallbackHandler

    prova = ProvaClient(api_key=os.environ["PROVA_API_KEY"])
    handler = ProvaCallbackHandler(
        client=prova,
        app_id="my-agent",
        environment="production",
        framework="langgraph",
    )

    # LangGraph:
    graph.invoke(inputs, config={"callbacks": [handler]})

    # LangChain:
    chain.invoke(inputs, config={"callbacks": [handler]})
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional, Sequence, Set, Union
from uuid import UUID

from .boundaries import BoundaryViolationError, ProvaBoundaries, _MAX_BUDGET, _MAX_STEPS
from .loopguard import CoordinationLoopError, LoopGuard
from .pricing import estimate_cost_from_usage
from .tokens import extract_token_usage

log = logging.getLogger(__name__)

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
    _LANGCHAIN_AVAILABLE = True
except ImportError:
    _LANGCHAIN_AVAILABLE = False

    class BaseCallbackHandler:  # type: ignore[no-redef]
        """Stub so the module is importable even without langchain_core."""
        pass

    class LLMResult:  # type: ignore[no-redef]
        """Stub."""
        generations: list = []
        llm_output: dict = {}


class ProvaCallbackHandler(BaseCallbackHandler):
    """LangChain/LangGraph callback handler that ingests every AI event into Prova.

    Thread-safe: each run_id gets its own timing state stored in a dict.
    Failures are swallowed and logged so a Prova outage never breaks the agent.
    """

    def __init__(
        self,
        client: Any,
        *,
        app_id: str = "agent",
        environment: str = "production",
        framework: str = "langgraph",
        provider: Optional[str] = None,
        detect_loops: bool = True,
        break_on_loop: bool = False,
        boundaries: Optional[ProvaBoundaries] = None,
        break_on_violation: bool = False,
        budget_usd: Optional[float] = None,
        max_steps: Optional[int] = None,
    ) -> None:
        if not _LANGCHAIN_AVAILABLE:
            raise ImportError(
                "langchain-core is required to use ProvaCallbackHandler. "
                "Install it with: pip install langchain-core"
            )
        super().__init__()
        self._client = client
        self._source = {
            "app_id": app_id,
            "environment": environment,
            "framework": framework,
        }
        self._provider = provider
        self._start_times: Dict[str, float] = {}
        self._prompts: Dict[str, Any] = {}
        self._inputs: Dict[str, Any] = {}
        # Loop detection. ``detect_loops`` accumulates a {node,reads,writes}
        # trace and emits one agent_run receipt per run so the server-side
        # coordination-loop detector actually fires from auto-instrumentation
        # (it only triggers on agent_run + steps, never per-step agent_step).
        # By default the guard also runs the same algorithm in-process and
        # logs a warning the moment a persistent loop forms, so the developer
        # sees it in real time instead of only later in the dashboard. It does
        # not stop the run, because a structural loop is also what a healthy
        # planner/executor iteration looks like and killing every cycle would
        # break working agents. ``break_on_loop`` upgrades that warning to a
        # raised CoordinationLoopError so the runtime stops before it burns
        # more budget.
        self._detect_loops = detect_loops or break_on_loop
        self._break_on_loop = break_on_loop
        self._guard = (
            LoopGuard(raise_on_detect=break_on_loop) if self._detect_loops else None
        )

        # Runtime autonomy boundaries. The manifest is sent once to the
        # server at the first emitted event so the boundary_violation
        # built-in policy can correlate the run server-side. Tools, steps,
        # and data scopes are enforced client-side here too (immediate
        # break). Budget is enforced server-side via the policy because
        # cost is computed server-side from token_usage.
        # Boundaries. An explicit ProvaBoundaries gives full control (tools /
        # steps / budget / scopes). budget_usd and max_steps are a dead-simple
        # shortcut: a cost and/or step circuit breaker with no tool or scope
        # restriction. Unlike break_on_loop (a heuristic, off by default), an
        # explicit cap is a hard limit the caller set, so the shortcut stops
        # the run by default.
        if boundaries is None and (budget_usd is not None or max_steps is not None):
            boundaries = ProvaBoundaries(
                allowed_tools=[],
                max_steps=int(max_steps) if max_steps is not None else _MAX_STEPS,
                budget_usd_per_run=(
                    float(budget_usd) if budget_usd is not None else _MAX_BUDGET
                ),
                data_scopes=[],
                raise_on_violation=True,
            )
            break_on_violation = True
        if boundaries is not None:
            boundaries._raise = break_on_violation  # type: ignore[attr-defined]
        self._boundaries = boundaries
        self._break_on_violation = break_on_violation
        self._run_id: Optional[str] = None
        self._manifest_registered: bool = False
        self._run_cost_usd: float = 0.0

    # ------------------------------------------------------------------
    # LLM callbacks
    # ------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        self._start_times[key] = time.time()
        self._prompts[key] = prompts

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[Any]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        self._start_times[key] = time.time()
        try:
            self._prompts[key] = [
                {"role": m.type, "content": m.content}
                for batch in messages
                for m in batch
            ]
        except Exception:
            self._prompts[key] = str(messages)

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        elapsed_ms = int((time.time() - self._start_times.pop(key, time.time())) * 1000)
        prompt = self._prompts.pop(key, None)

        try:
            generation = (
                response.generations[0][0] if response.generations and response.generations[0] else None
            )
            completion = getattr(generation, "text", None) or (
                getattr(generation, "message", None) and getattr(generation.message, "content", None)
            )

            llm_output = response.llm_output or {}
            model_name = (
                llm_output.get("model_name")
                or llm_output.get("model")
                or kwargs.get("invocation_params", {}).get("model_name")
                or kwargs.get("invocation_params", {}).get("model")
            )

            payload: Dict[str, Any] = {"elapsed_ms": elapsed_ms}
            if prompt is not None:
                payload["prompt"] = prompt
            if completion is not None:
                payload["completion"] = completion
            if llm_output:
                payload["llm_output"] = llm_output

            # Normalize token usage across providers and attach it to the
            # payload. The server-side cost transform computes cost_usd from
            # this + the model name before signing. Returns None when no
            # recognizable shape is present, in which case we just don't
            # attach (and cost attribution silently no-ops for this call).
            token_usage = extract_token_usage(
                llm_output=llm_output,
                generation=generation,
                model_name=model_name,
            )
            if token_usage is not None:
                payload["token_usage"] = token_usage

            event: Dict[str, Any] = {
                "kind": "model_call",
                "source": {**self._source, "run_id": key},
                "payload": payload,
            }
            if model_name or self._provider:
                event["model"] = {
                    k: v for k, v in {
                        "provider": self._provider,
                        "name": model_name,
                    }.items() if v
                }

            self._client.ingest(event)

            # Local cost circuit breaker. Estimate this call's cost from the
            # normalized token usage and feed the boundary guard so a
            # budget_usd cap stops the run in-process. The signed receipt's
            # cost_usd is still computed server-side from token_usage; the
            # local estimate is never written into the payload.
            if self._boundaries is not None and token_usage is not None:
                est = estimate_cost_from_usage(model_name, token_usage)
                if est:
                    self._run_cost_usd += est
                    self._boundaries.observe_cost(est)
        except BoundaryViolationError:
            # Budget exceeded: persist the trace so far, then let the
            # exception break the run.
            self._flush_agent_run(key, caught=True)
            raise
        except Exception as exc:
            log.warning("ProvaCallbackHandler.on_llm_end failed: %s", exc)

    def on_llm_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        self._start_times.pop(key, None)
        self._prompts.pop(key, None)

    # ------------------------------------------------------------------
    # Chain (agent node) callbacks
    # ------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        self._start_times[key] = time.time()
        if self._detect_loops and isinstance(inputs, dict):
            self._inputs[key] = inputs

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        elapsed_ms = int((time.time() - self._start_times.pop(key, time.time())) * 1000)

        if parent_run_id is None:
            # Top-level run boundary: flush the accumulated trace as one
            # agent_run so the server-side coordination-loop detector fires.
            self._flush_agent_run(key)
            return

        name = kwargs.get("name") or (
            serialized.get("name") if (serialized := kwargs.get("serialized")) else None
        )
        node = name or "unknown"

        inputs = self._inputs.pop(key, None)
        if self._guard is not None:
            # reads = state keys this node consumed, writes = keys it
            # produced. Same edge model the canonical detector uses.
            try:
                match = self._guard.observe(
                    node,
                    reads=inputs if isinstance(inputs, dict) else None,
                    writes=outputs if isinstance(outputs, dict) else None,
                )
            except CoordinationLoopError:
                # break_on_loop=True: persist the signed record of the caught
                # loop before we let the exception break the runtime.
                self._flush_agent_run(key, caught=True)
                raise
            if match is not None:
                # Default path (break_on_loop=False): the guard returns the
                # match instead of raising. Surface it loudly the moment it
                # forms. The guard returns the match exactly once per run, so
                # this fires once. Pass break_on_loop=True to stop the run.
                agents = match.get("agents", [])
                log.warning(
                    "prova: coordination loop forming across %d agents (%s), "
                    "persisted %s/%s steps. Pass break_on_loop=True to stop "
                    "the run automatically.",
                    len(agents),
                    " -> ".join(str(a) for a in agents),
                    match.get("persistence_steps"),
                    match.get("total_steps"),
                )

        # Boundary enforcement: count this step, observe any data scopes
        # carried in inputs/outputs. Budget is enforced server-side.
        if self._boundaries is not None:
            self._ensure_run_registered()
            try:
                self._boundaries.observe_step(node)
                for scope_key in _payload_data_scopes(inputs, outputs):
                    self._boundaries.observe_data_scope(scope_key)
            except BoundaryViolationError:
                self._flush_agent_run(key, caught=True)
                raise

        try:
            self._client.ingest({
                "kind": "agent_step",
                "source": {**self._source, "run_id": key, "parent_run_id": str(parent_run_id)},
                "payload": {
                    "node": node,
                    "outputs": _safe_truncate(outputs),
                    "elapsed_ms": elapsed_ms,
                },
            })
        except Exception as exc:
            log.warning("ProvaCallbackHandler.on_chain_end failed: %s", exc)

    def _ensure_run_registered(self) -> None:
        """Lazily register the boundary manifest on the first event. Fail
        silently if the server is unreachable; the local guard still
        enforces, and the server-side correlation just degrades to
        per-event evaluation when the manifest receipt is missing."""
        if self._boundaries is None or self._manifest_registered:
            return
        if self._run_id is None:
            from uuid import uuid4

            self._run_id = uuid4().hex[:16]
        try:
            self._client.register_run(self._run_id, self._boundaries.manifest())
        except Exception as exc:
            log.warning("ProvaCallbackHandler manifest register failed: %s", exc)
        self._manifest_registered = True

    def _flush_agent_run(self, run_key: str, *, caught: bool = False) -> None:
        """Emit one agent_run event carrying the full {node,reads,writes}
        trace. This is the shape the server-side coordination-loop detector
        consumes; per-step agent_step events never trigger it."""
        if self._guard is None:
            return
        steps = self._guard.steps
        if not steps:
            return
        try:
            self._client.ingest({
                "kind": "agent_run",
                "source": {**self._source, "run_id": run_key},
                "payload": {"steps": [_safe_truncate(s) for s in steps]},
            })
        except Exception as exc:
            log.warning("ProvaCallbackHandler agent_run flush failed: %s", exc)

    def on_chain_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        self._start_times.pop(key, None)
        self._inputs.pop(key, None)

    # ------------------------------------------------------------------
    # Tool callbacks
    # ------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        self._start_times[str(run_id)] = time.time()

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        elapsed_ms = int((time.time() - self._start_times.pop(key, time.time())) * 1000)

        name = kwargs.get("name") or "unknown"

        # Boundary enforcement: tool allow-list check.
        if self._boundaries is not None and name != "unknown":
            self._ensure_run_registered()
            self._boundaries.observe_tool(name)

        try:
            self._client.ingest({
                "kind": "tool_call",
                "source": {**self._source, "run_id": key},
                "payload": {
                    "tool": name,
                    "output": _safe_truncate(output),
                    "elapsed_ms": elapsed_ms,
                },
            })
        except Exception as exc:
            log.warning("ProvaCallbackHandler.on_tool_end failed: %s", exc)

    def on_tool_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        self._start_times.pop(str(run_id), None)


def _payload_data_scopes(*payloads: Any) -> List[str]:
    """Best-effort extraction of data-scope identifiers from chain
    inputs/outputs. Boundaries are matched against top-level keys of
    dict payloads (e.g. ``customer_id``, ``patient_record_id``) plus
    any list under a ``data_scopes`` key. This is a recall-over-precision
    heuristic; callers that want strict matching can call
    ``ProvaBoundaries.observe_data_scope`` directly."""
    scopes: Set[str] = set()
    for p in payloads:
        if isinstance(p, dict):
            for k in p.keys():
                if isinstance(k, str) and 0 < len(k) <= 256:
                    scopes.add(k)
            explicit = p.get("data_scopes")
            if isinstance(explicit, (list, tuple)):
                for s in explicit:
                    if isinstance(s, str) and s:
                        scopes.add(s)
    return list(scopes)


def _safe_truncate(obj: Any, max_len: int = 2000) -> Any:
    """Truncate large string values to keep receipt payloads reasonable."""
    if isinstance(obj, str):
        return obj[:max_len] + ("..." if len(obj) > max_len else "")
    if isinstance(obj, dict):
        return {k: _safe_truncate(v, max_len) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_safe_truncate(v, max_len) for v in obj[:50]]
    return obj
