"""Offline receipt verification using cryptography's Ed25519 primitives."""

from __future__ import annotations

import hashlib
from typing import Any, Mapping, MutableMapping, Optional

import httpx
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .canonical import canonicalize

DEFAULT_BASE_URL = "https://api.prova.cobound.dev"

_KEY_CACHE: MutableMapping[str, Ed25519PublicKey] = {}


class ReceiptVerificationError(Exception):
    def __init__(self, message: str, receipt_id: Optional[str] = None) -> None:
        super().__init__(message)
        self.receipt_id = receipt_id


def _load_public_key(
    key_id: str,
    *,
    public_key_pem: Optional[str],
    base_url: str,
    client: Optional[httpx.Client],
) -> Ed25519PublicKey:
    if public_key_pem:
        return serialization.load_pem_public_key(public_key_pem.encode("utf-8"))  # type: ignore[return-value]
    cached = _KEY_CACHE.get(key_id)
    if cached is not None:
        return cached
    base = base_url.rstrip("/")
    own_client = False
    if client is None:
        client = httpx.Client(timeout=10.0)
        own_client = True
    try:
        resp = client.get(f"{base}/api/v1/keys/{key_id}")
        if resp.status_code != 200:
            raise ReceiptVerificationError(
                f"failed to fetch public key {key_id}: HTTP {resp.status_code}",
                key_id,
            )
        body = resp.json()
        pem = body.get("public_key_pem")
        if not pem:
            raise ReceiptVerificationError(f"key registry returned no PEM for {key_id}", key_id)
        key = serialization.load_pem_public_key(pem.encode("utf-8"))
        _KEY_CACHE[key_id] = key  # type: ignore[assignment]
        return key  # type: ignore[return-value]
    finally:
        if own_client:
            client.close()


def verify_receipt(
    receipt: Mapping[str, Any],
    *,
    public_key_pem: Optional[str] = None,
    base_url: str = DEFAULT_BASE_URL,
    client: Optional[httpx.Client] = None,
) -> None:
    """Verify a receipt's hash and Ed25519 signature. Raises on mismatch."""
    integrity = receipt.get("integrity") or {}
    payload = receipt.get("payload")
    findings = receipt.get("findings", [])
    canonical = canonicalize({"findings": findings, "payload": payload})
    expected = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    if expected != integrity.get("hash"):
        raise ReceiptVerificationError(
            f"hash mismatch: expected {expected}, got {integrity.get('hash')}",
            receipt.get("event_id"),
        )
    key = _load_public_key(
        integrity["key_id"],
        public_key_pem=public_key_pem,
        base_url=base_url,
        client=client,
    )
    sig = bytes.fromhex(integrity["signature"])
    try:
        key.verify(sig, canonical.encode("utf-8"))
    except InvalidSignature as e:
        raise ReceiptVerificationError(
            f"signature does not verify against key {integrity['key_id']}",
            receipt.get("event_id"),
        ) from e


def _reset_key_cache_for_tests() -> None:
    _KEY_CACHE.clear()
