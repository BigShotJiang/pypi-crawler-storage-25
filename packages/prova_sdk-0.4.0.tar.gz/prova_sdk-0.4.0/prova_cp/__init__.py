"""Agent-side SDK for the Prova AI control plane."""

from .client import ProvaClient, ProvaApiError, ReceiptVerificationError
from .verify import verify_receipt
from .canonical import canonicalize
from .migrate import migrate, MAPPERS, langsmith_mapper, langfuse_mapper, openai_mapper
from .callbacks import ProvaCallbackHandler
from .crewai import ProvaCrewAI
from .boundaries import (
    BoundaryViolationError,
    ProvaBoundaries,
    evaluate_boundaries,
)
from .loopguard import LoopGuard, CoordinationLoopError, detect_loop
from .pricing import estimate_cost_usd, estimate_cost_from_usage, set_model_price
from .runguard import RunGuard
from .local import analyze_events
from .tokens import extract_token_usage
from ._demo import demo, ProvaDemoError
from .wrap import wrap_openai, wrap_anthropic

__all__ = [
    "ProvaClient",
    "ProvaApiError",
    "ReceiptVerificationError",
    "verify_receipt",
    "canonicalize",
    "migrate",
    "MAPPERS",
    "langsmith_mapper",
    "langfuse_mapper",
    "openai_mapper",
    "ProvaCallbackHandler",
    "ProvaCrewAI",
    "LoopGuard",
    "CoordinationLoopError",
    "detect_loop",
    "ProvaBoundaries",
    "BoundaryViolationError",
    "evaluate_boundaries",
    "RunGuard",
    "estimate_cost_usd",
    "estimate_cost_from_usage",
    "set_model_price",
    "analyze_events",
    "extract_token_usage",
    "demo",
    "ProvaDemoError",
    "wrap_openai",
    "wrap_anthropic",
]
__version__ = "0.4.0"
