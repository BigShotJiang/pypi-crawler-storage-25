"""RunGuard: a circuit breaker for any agent runtime.

LangGraph and LangChain users get loop, budget, and step protection
automatically from ``ProvaCallbackHandler``. RunGuard is the same protection for
runtimes that have no LangChain callbacks: AutoGen, a hand-rolled orchestrator,
a plain while-loop. Call :meth:`observe_step` and :meth:`observe_model_call` as
the run progresses; RunGuard runs the same coordination-loop algorithm and the
same budget / step checks the rest of the SDK uses, and stops the run the moment
a hard cap is hit.

    from prova_cp import RunGuard, CoordinationLoopError, BoundaryViolationError

    guard = RunGuard(budget_usd=0.50, max_steps=40, break_on_loop=True)
    try:
        for turn in run_agent():
            guard.observe_step(turn.agent, reads=turn.state_in, writes=turn.state_out)
            guard.observe_model_call(turn.model, turn.token_usage)
    except CoordinationLoopError as e:
        ...   # break_on_loop tripped
    except BoundaryViolationError as e:
        ...   # budget_usd or max_steps tripped

    print(guard.report())   # {steps, estimated_cost_usd, loop}

Consistency with the rest of the SDK:
  - the loop algorithm is the same one the server runs, so a loop caught here is
    the loop a signed receipt would report;
  - a coordination loop is a heuristic, so it warns by default (pass
    ``break_on_loop=True`` to stop);
  - ``budget_usd`` and ``max_steps`` are explicit caps you set, so they stop the
    run by default;
  - the cost figure is a local estimate; the canonical cost_usd is computed and
    signed server-side when you ingest.

RunGuard does not talk to the network. Pair it with a ProvaClient (or the SDK's
ingest) when you want signed receipts.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Mapping, Optional

from .boundaries import _MAX_BUDGET, _MAX_STEPS, BoundaryViolationError, ProvaBoundaries
from .loopguard import CoordinationLoopError, LoopGuard, detect_loop
from .pricing import estimate_cost_from_usage

log = logging.getLogger(__name__)


class RunGuard:
    def __init__(
        self,
        *,
        budget_usd: Optional[float] = None,
        max_steps: Optional[int] = None,
        break_on_loop: bool = False,
        warn_on_loop: bool = True,
    ) -> None:
        self._loop = LoopGuard(raise_on_detect=break_on_loop)
        self._break_on_loop = break_on_loop
        self._warn_on_loop = warn_on_loop
        self._loop_warned = False
        self._cost_usd = 0.0

        if budget_usd is not None or max_steps is not None:
            self._boundaries: Optional[ProvaBoundaries] = ProvaBoundaries(
                allowed_tools=[],
                max_steps=int(max_steps) if max_steps is not None else _MAX_STEPS,
                budget_usd_per_run=(
                    float(budget_usd) if budget_usd is not None else _MAX_BUDGET
                ),
                data_scopes=[],
                raise_on_violation=True,
            )
        else:
            self._boundaries = None

    def observe_step(
        self,
        node: str,
        *,
        reads: Optional[Mapping[str, Any]] = None,
        writes: Optional[Mapping[str, Any]] = None,
    ) -> None:
        """Record one agent step. Raises CoordinationLoopError if break_on_loop
        and a loop forms, or BoundaryViolationError if max_steps is exceeded."""
        match = self._loop.observe(node, reads=reads, writes=writes)
        if match is not None and not self._break_on_loop and self._warn_on_loop:
            if not self._loop_warned:
                self._loop_warned = True
                agents = match.get("agents", [])
                log.warning(
                    "prova: coordination loop forming across %d agents (%s), "
                    "persisted %s/%s steps. Pass break_on_loop=True to stop.",
                    len(agents),
                    " -> ".join(str(a) for a in agents),
                    match.get("persistence_steps"),
                    match.get("total_steps"),
                )
        if self._boundaries is not None:
            self._boundaries.observe_step(node)

    def observe_model_call(
        self,
        model_name: Optional[str],
        token_usage: Optional[Mapping[str, Any]],
    ) -> None:
        """Record a model call's token usage. Raises BoundaryViolationError if
        the running estimated spend exceeds budget_usd."""
        est = estimate_cost_from_usage(
            model_name, dict(token_usage) if token_usage is not None else None
        )
        if est:
            self._cost_usd += est
            if self._boundaries is not None:
                self._boundaries.observe_cost(est)

    @property
    def steps(self) -> list:
        return self._loop.steps

    @property
    def estimated_cost_usd(self) -> float:
        return round(self._cost_usd, 6)

    def report(self) -> Dict[str, Any]:
        """Snapshot of the run so far: step count, estimated spend, and the
        current loop match (if any)."""
        return {
            "steps": len(self._loop.steps),
            "estimated_cost_usd": round(self._cost_usd, 6),
            "loop": detect_loop(self._loop.steps) if self._loop.steps else None,
        }
