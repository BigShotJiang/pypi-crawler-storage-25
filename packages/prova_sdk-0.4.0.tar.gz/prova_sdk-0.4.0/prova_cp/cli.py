"""prova-migrate CLI. Reads NDJSON and bulk-ingests into the Audit Vault."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Optional

from .client import ProvaClient
from .migrate import migrate, read_ndjson, MAPPERS


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="prova-migrate",
        description="Bulk-import LangSmith / Langfuse / OpenAI logs into the Prova Audit Vault.",
    )
    parser.add_argument("--source", required=True, choices=sorted(MAPPERS.keys()))
    parser.add_argument("--file", required=True, help='Path to NDJSON file, or "-" for stdin.')
    parser.add_argument("--batch", type=int, default=200)
    parser.add_argument("--base-url", default=None)
    args = parser.parse_args(argv)

    api_key = os.environ.get("PROVA_API_KEY")
    if not api_key:
        print("PROVA_API_KEY is required", file=sys.stderr)
        return 2

    stream = sys.stdin if args.file == "-" else open(args.file, "r", encoding="utf-8")
    started = time.monotonic()
    with ProvaClient(api_key, base_url=args.base_url) as client:
        result = migrate(
            client,
            args.source,
            read_ndjson(stream),
            batch_size=args.batch,
            on_progress=lambda p: print(
                f"batch {p['batch']}: ingested={p['ingested']} skipped={p['skipped']} total={p['total']}",
                file=sys.stderr,
            ),
        )
    if stream is not sys.stdin:
        stream.close()
    result["elapsed_s"] = round(time.monotonic() - started, 1)
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    sys.exit(main())
