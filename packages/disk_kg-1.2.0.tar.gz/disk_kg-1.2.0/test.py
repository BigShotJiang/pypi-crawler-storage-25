class data:
    def __getitem__(self, index: slice = None):
        print(index)
        return index


a = "hello world"
s = slice(3)
print(s)
print(a[s])
