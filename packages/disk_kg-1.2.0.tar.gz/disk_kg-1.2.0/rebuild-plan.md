# 重构计划：DISK 知识图谱构建工具接口优化

该计划旨在重构 `disk_kg` 项目的接口，使其符合 `tests_kg/goal.py` 中定义的简洁、面向对象的调用方式。

`tests` 文件夹中的测试用例正在逐步被迁移和废弃，不需要担心它们的存在。我们将专注于实现 `goal.py` 中定义的接口，并确保其功能完整且易于使用。

新的测试文件夹是`tests_kg`。在重构后，你需要在必要时添加新的测试用例来验证新的接口设计。请确保所有测试用例都能通过，以验证重构的正确性和功能完整性。

## 核心目标

1.  **统一提取入口**：提供 `Distiller.distill(file_path)` 作为自动选择提取器的工厂，返回实例。
2.  **简化 DISK 初始化**：支持通过 `models` 和 `embeddings` 直接配置，屏蔽复杂的内部组件初始化。
3.  **增强知识图谱操作**：支持 `KnowledgeGraph` 的合并操作（`+`, `+=`）及统一持久化接口（`save_to`）。

## 任务分解

### 1. Distiller 模块重构 (优先级：高)
- [x] 在 `src/disk_kg/distiller/distiller.py` 中为 `Distiller` 基类添加 `distill` 静态方法，该方法返回子类。
- [x] 实现文件类型自动检测（根据扩展名选择 `PDFDistiller`, `DocxDistiller` 等）。
- [x] 所有的方法，不在需要需要临时传入 `file_path`，而是在初始化时传入并绑定。
- [x] 统一各接口的输出格式为 `list[str]` (paragraphs)。
- [x] 不再输出/保存到日志

### 2. Provider 模块对齐
- [x] 确保 `src/disk_kg/provider/chats.py` 中的 `ChatProxy` 和 `RateLimiter` 能够被正确组合使用。
- [x] 验证 `Embeddings.build_from("config.toml")` 的实现符合 `goal.py`。
- [-] 保证 `src/disk_kg/provider/llm.py` 中的功能被完全迁移到其他模块中，或适当重构以适应新的接口设计。之后，可以考虑删除 `llm.py` 文件。

### 3. KnowledgeGraph 模型增强
- [ ] 在 `src/disk_kg/models/knowledge_graph.py` 中实现 `__add__` 和 `__iadd__` 方法，支持两个 `KnowledgeGraph` 实例的合并（去重合并实体和关系）。
- [ ] 合并的具体算法，在`src/disk_kg/merger/merger.py`中实现，你可以移动这个文件到 `src/disk_kg/models/` 以便更好地组织代码。
- [ ] 确保 `KnowledgeGraph.save_to(connector)` 能够正确处理与 `Neo4jConnector` 的交互。

### 3.5 Connector 调整
- 跑通 `Neo4jConnector` 的基本功能，确保它能够正确连接到 Neo4j 数据库并执行基本的 CRUD 操作。
- 跑通 `KnowledgeGraph.save_to` 方法，确保它能够正确使用 `Neo4jConnector` 将图数据持久化到数据库中。
- 跑通 `SqliteConnector` 的基本功能，确保它能够正确连接到 SQLite 数据库并执行基本的 CRUD 操作。
- 跑通 `KnowledgeGraph.save_to` 方法，确保它能够正确使用 `SqliteConnector` 将图数据持久化到数据库中。

### 4. DISK 核心类重写
- [ ] 调整 `DISK.__init__`：
    - 接收 `models: ChatClient` (支持 `ChatProxy` 或 `RateLimiter` 包装后的实例)。
    - 接收 `embeddings: Embeddings`。
    - 移除或隐藏内部 Extractor/Merger 的显式初始化。
- [ ] 调整 `DISK.build_knowledge_graph`：
    - 输入参数改为 `distilled_content: list[str]`。
    - 保持现有的并行提取和合并逻辑，但适配新的输入格式。
- [ ] 暂时忽略token计数和日志输出相关的功能，专注于核心功能的实现。

### 5. 导出与清理
- [ ] 在 `src/disk_kg/__init__.py` 中导出 `DISK`。
- [ ] 在 `src/disk_kg/distiller/__init__.py` 中导出 `Distiller`。
- [ ] 在 `src/disk_kg/models/__init__.py` 中导出 `Neo4jConnector`。
- [ ] 在 `src/disk_kg/provider/__init__.py` 中导出 `ChatProxy`, `Embeddings`, `RateLimiter`。

## 验证标准
- 运行 `python tests_kg/goal.py` 无报错。
- 提取结果与重构前保持一致（通过现有测试用例验证）。
