from pathlib import Path

from disk_kg import DISK
from disk_kg.distiller import Distiller
from disk_kg.models import Neo4jConnector
from disk_kg.provider import ChatProxy, Embeddings, RateLimiter


class _SEG:
    def __getitem__(self, index: slice) -> slice:
        if not isinstance(index, slice):
            raise TypeError("SEG only supports slicing.")
        print(f"SEG received slice: {index}")
        return index


SEG = _SEG()


disk = DISK(
    model=RateLimiter(ChatProxy("config.toml"), 29),
    embedding=Embeddings.build_from("config.toml"),
    enable_token_track=False,
)

RED = "\033[91m"
RESET = "\033[0m"

for chapter in [
    "25",
    "26",
    "27",
]:
    files_path = Path(__file__).parent.parent / "logs"
    files = list(files_path.glob(f"{chapter}*.md"))
    assert len(files) == 1, f"Expected exactly one file for chapter {chapter}, found {len(files)}"

    file = files[0]
    file_dst = Distiller.distill(str(file))

    print(f"{RED}file is {file}{RESET}")
    # assert input("Is the file correct? (y/n) ").lower() == "y", "Please check the file and try again."

    kg = disk.build_knowledge_graph(file_dst, mode="serial")
    # kg += disk.build_knowledge_graph(file_dst2)

    with Neo4jConnector("bolt://localhost:7687", "neo4j", "your_neo4j_password") as connector:
        kg.save_to(connector)
