"""@udf — Phase D zaku-style binding.

The existing ``decorator.udf`` ships two semantics:

  * ``@udf``               — bare. Local-only Function.
  * ``@udf("mode")``       — remote, blocks on plain call.

Phase D adds a third — **queue-bound, returns a Future on plain call**:

    q = Queue("rpc-demo")

    @udf(queue=q, retry=0)
    def add(a: int, b: int) -> int:
        return a + b

    fut = add(1, 2)         # returns a QueueFuture
    result = fut.get()      # blocks (or `await fut`)

This is the canonical shape for the DAG-implicit-in-Python pattern —
each call returns a Future, futures chain into the next call, and the
graph is reconstructed by the controlplane from the parent/child
linkage on each invocation.

Wire shape (today): the decorator cloudpickles ``fn``, msgpack+ZData-
encodes the args, and enqueues ``{_fn_pickled, _args, _kwargs,
_request_id}`` via :meth:`Queue.add`. The Phase D daemon-side runner
(``daemon.udf_runner``) recognises that shape, cloudpickle.loads the
fn, runs it, and publishes the result on ``_request_id``.

Wire shape (Phase D.5): the payload moves to the
``payloadInline``/``payloadRef`` envelope from /dev-payload-store —
the decorator and runner gain a 5-line branch, no public surface
change.
"""

from __future__ import annotations

import cloudpickle
import inspect
import textwrap
from typing import TYPE_CHECKING, Any, Callable, Generic, TypeVar

from .future import QueueFuture
from .zdata import Payload

if TYPE_CHECKING:  # pragma: no cover
    from .queue import Queue

T = TypeVar("T")


class _QueueBoundUDF(Generic[T]):
    """A function bound to a :class:`Queue`. Calling it enqueues an
    Invocation and returns a :class:`QueueFuture`.

    Attributes:
      _fn      — the original undecorated callable.
      queue    — the Queue this UDF dispatches against.
      retry    — number of retries on failure (informational for v0).
      timeout  — default wait window for the returned Future's .get().
    """

    def __init__(
        self,
        fn: Callable[..., T],
        *,
        queue: "Queue",
        retry: int = 0,
        timeout: float = 30.0,
    ):
        self._fn = fn
        self.queue = queue
        self.retry = retry
        self.timeout = timeout
        # Pre-pickle once at decoration time. cloudpickle's output is
        # stable for a given function value, so we can hash it cheaply
        # for the version stamp the CP wants.
        self._fn_pickled = cloudpickle.dumps(fn)
        # Copy over the common dunder attrs so `help(some_fn)` and
        # frameworks like pytest still see the original metadata.
        self.__wrapped__ = fn
        for attr in ("__module__", "__name__", "__qualname__", "__doc__"):
            try:
                setattr(self, attr, getattr(fn, attr))
            except AttributeError:
                pass

    def __call__(self, *args: Any, **kwargs: Any) -> QueueFuture:
        # Enqueue the udf-runner-shape payload. The runner watches
        # for the `_fn_pickled` key to decide "this is a callable
        # job; cloudpickle.loads and run" vs "this is a raw payload;
        # deliver to take()".
        try:
            src = textwrap.dedent(inspect.getsource(self._fn))
        except (OSError, TypeError):
            src = ""
        payload = {
            "_fn_pickled": self._fn_pickled,
            "_fn_source": src,
            "_fn_qualname": getattr(self._fn, "__qualname__", self._fn.__name__),
            "_args": list(args),
            "_kwargs": dict(kwargs),
            "_retry": self.retry,
        }
        topic = self.queue.add(payload)
        return QueueFuture(self.queue, topic, timeout=self.timeout)

    def local(self, *args: Any, **kwargs: Any) -> T:
        """Bypass the queue and run in-process. Useful for debugging
        and unit tests."""
        return self._fn(*args, **kwargs)

    def __repr__(self) -> str:
        return (
            f"<udf {getattr(self, '__qualname__', '?')} "
            f"queue={self.queue.name!r}>"
        )


def _build_queue_from_kwargs(
    name: str,
    *,
    kind: str | None,
    priority_field: str | None,
    temperature: float | None,
    anneal: dict[str, Any] | None,
    server: str | None,
    namespace: str,
) -> "Queue":
    """Pick the right Queue subclass from the queue-ish kwargs.

    Priority: a non-None ``temperature`` wins (Boltzmann), then a
    non-None ``priority_field`` or explicit ``kind="priority"``
    (Priority), then ``kind="filo"`` (FILO). Falls back to the
    default fifo ``Queue``.
    """
    from .queue import BoltzmannQueue, FILOQueue, PriorityQueue, Queue

    if temperature is not None:
        return BoltzmannQueue(
            name,
            temperature=temperature,
            priority_field=priority_field or "priority",
            anneal=anneal,
            server=server,
            namespace=namespace,
        )
    if priority_field is not None or kind == "priority":
        return PriorityQueue(
            name,
            priority_field=priority_field or "priority",
            server=server,
            namespace=namespace,
        )
    if kind == "filo":
        return FILOQueue(name, server=server, namespace=namespace)
    return Queue(name, kind=kind, server=server, namespace=namespace)


def udf(
    fn: Callable[..., T] | None = None,
    *,
    queue: "Queue | str | None" = None,
    # Inline queue-construction shortcuts. When `queue` is None or a
    # bare string, these kwargs construct the underlying Queue.
    kind: str | None = None,
    priority_field: str | None = None,
    temperature: float | None = None,
    anneal: dict[str, Any] | None = None,
    server: str | None = None,
    namespace: str = "default",
    retry: int = 0,
    timeout: float = 30.0,
) -> Any:
    """Phase D ``@udf`` overload.

    Five usable shapes:

      ``@udf``                          — pass-through (no queue).
                                          Returns the function
                                          unchanged so existing
                                          call-sites still work.
      ``@udf(queue=q)``                 — queue-bound to a Queue
                                          instance. ``fn(...)`` returns
                                          a :class:`QueueFuture`.
      ``@udf(queue="foo")``             — bare-string queue. Constructs
                                          ``Queue("foo")`` at decoration
                                          time.
      ``@udf(kind="priority", ...)``    — queue name defaults to the
                                          function's ``__module__``;
                                          subclass picked from kwargs
                                          (``PriorityQueue``,
                                          ``BoltzmannQueue``, etc.).
      ``@udf(queue="foo", kind=...)``   — string queue + subclass kwargs.

    The mode-style ``@udf("h100")`` shape lives in ``decorator.udf``
    and is re-exported from the package root. Phase D doesn't shadow
    it — distinct call signatures.

    Default queue name when no ``queue=`` is given but Phase D kwargs
    are set: ``fn.__module__`` (logging.getLogger pattern). All
    ``@udf``-decorated functions in the same module share one queue
    by default; pass explicit ``queue=`` to opt out.
    """
    # Detect any Phase D signal — explicit queue= OR a queue-construction
    # kwarg. Without one of these, fall through to the legacy decorator.
    phase_d_signal = (
        queue is not None
        or kind is not None
        or priority_field is not None
        or temperature is not None
    )

    if fn is not None and not phase_d_signal:
        # Bare `@udf` — defer to the legacy local-only path.
        from .decorator import udf as _legacy_udf

        return _legacy_udf(fn)

    def decorator(_fn: Callable[..., T]) -> _QueueBoundUDF[T]:
        # Resolve the queue. Three input shapes:
        #   1. Queue instance → use as-is.
        #   2. str            → construct via kwargs.
        #   3. None           → derive name from _fn.__module__.
        if queue is not None and not isinstance(queue, str):
            q_obj = queue
        else:
            q_name = queue if isinstance(queue, str) else _fn.__module__
            q_obj = _build_queue_from_kwargs(
                q_name,
                kind=kind,
                priority_field=priority_field,
                temperature=temperature,
                anneal=anneal,
                server=server,
                namespace=namespace,
            )
        return _QueueBoundUDF(_fn, queue=q_obj, retry=retry, timeout=timeout)

    if fn is not None:
        # `@udf(...)` was actually `@udf` applied directly to fn with
        # kwargs already set above (bare-decorator form with Phase D
        # kwargs — rare but legal).
        return decorator(fn)
    return decorator


__all__ = ["udf", "_QueueBoundUDF"]
