"""DreamLake Lakeshore — Python client for the Lakeshore control plane.

The canonical import:

    import dreamlake.lakeshore as dls

    @dls.udf                                   # local-only Function
    @dls.udf("h100")                           # remote-by-default with a mode
    @dls.udf(mode="local" if DEBUG else "h100")

    @dls.pipeline                              # DAG builder (v1 stub for now)
    def video_seg(src: str): ...

    # Function form
    dls.apply(fn, *args, **kw)         # blocks, returns result
    dls.apply_spawn(fn, *args, **kw)   # → Future
    dls.apply_async(fn, *args, **kw)   # → coroutine (sync→async promote)

    # Thunk form
    t = dls.thunk(fn, *args, **kw)
    dls.call(t)                        # blocks
    dls.spawn(t)                       # → Future
    dls.call_async(t)                  # → coroutine

    # Orchestration
    dls.map / dls.gather / dls.as_completed                    # sync
    dls.map_async / dls.gather_async / dls.as_completed_async  # async

    # Managed constructs
    dls.Queue("training", mode="h100")
    dls.Pool(mode="h100", size=4)

    # In-callee run context
    dls.run.id
"""

from __future__ import annotations

import asyncio
import queue as _queue
import threading
from typing import Any, AsyncIterator, Awaitable, Iterable, Iterator, TypeVar

from .client import ControlPlaneClient, Daemon, LakeshoreClient
from .config import DreamRc, Provider, RunConfig, load_config, resolve
from .decorator import (
    Future,
    RunContext,
    Thunk,
    _FnOrThunk,
    _UDF,
    apply,
    apply_async,
    apply_spawn,
    call,
    call_async,
    compute as _compute,
    pure as _pure,
    run,
    bind,
    spawn,
    udf as _udf_local,
)
from .future import QueueFuture
from .queue import BoltzmannQueue, FILOQueue, Pool, PriorityQueue, Queue
from .storage import Storage, TemporaryCredentials
from .udf import udf as _udf_queue, _QueueBoundUDF
from .zdata import Payload, ZData

__version__ = "0.0.0"

T = TypeVar("T")


# ─── Decorators ──────────────────────────────────────────────────────


def udf(fn_or_mode: Any = None, **kwargs: Any) -> Any:
    """The `@udf` decorator. Bare or parametric.

        @udf                       — local-only Function
        @udf("h100")               — remote, mode="h100"
        @udf(mode="h100", ...)     — remote, with extra knobs
        @udf(queue=q)              — Phase D: queue-bound, returns
                                     a QueueFuture on plain call
        @udf(queue=q, retry=N)     — same, with retry

    The dispatch is on `queue=` keyword presence. When it's set the
    decorator routes through ``dreamlake.lakeshore.udf.udf`` (Phase D
    zaku-style); otherwise we hand off to the legacy mode-based
    decorator in ``dreamlake.lakeshore.decorator.udf``.
    """
    if "queue" in kwargs and kwargs["queue"] is not None:
        # Phase D path. Forward retry / timeout knobs through.
        return _udf_queue(fn_or_mode, **kwargs)
    if callable(fn_or_mode) and not isinstance(fn_or_mode, str):
        return _udf_local(fn_or_mode)
    if fn_or_mode is not None:
        if "mode" in kwargs:
            raise TypeError("udf() got mode both positionally and as a keyword")
        kwargs["mode"] = fn_or_mode
    return _compute(**kwargs)


udf.pure = _pure  # type: ignore[attr-defined]


def pipeline(fn: Any) -> Any:
    """The `@pipeline` decorator — declares a DAG-builder Function.

    v0 stub: returns the Function unchanged (eager execution). v1 will
    flip a contextvar so UDF calls inside the body return Futures and
    are wired together into a DAG submitted to Lakeshore at the end.

    For now, code can already get the DAG shape by passing Futures
    explicitly through `dls.apply_spawn(...)`.
    """
    return fn


# ─── Orchestration ───────────────────────────────────────────────────


async def _await_obj(awaitable: Any) -> Any:
    return await awaitable


def map(fn: _UDF[T], iterable: Iterable[Any]) -> list[T]:  # noqa: A001
    """Sync parallel map. Returns results in input order."""
    futs = [apply_spawn(fn, item) for item in iterable]
    return [f.result() for f in futs]


async def map_async(fn: _UDF[T], iterable: Iterable[Any]) -> list[T]:
    coros: list[Awaitable[T]] = [apply_async(fn, item) for item in iterable]
    return list(await asyncio.gather(*coros))


def gather(
    *futures: Any,
    timeout: float | None = None,
) -> list[Any]:
    """Block on a set of Futures and return results in submission order.

    Accepts both the decorator-backed :class:`Future` (resolved via
    ``.result()``) and the queue-backed :class:`QueueFuture` (resolved
    via ``.get()``) — see :mod:`dreamlake.lakeshore.gather` for the
    dispatch logic. The two flavours can be mixed in the same call.

    Two call shapes accepted, for backwards-compat with the pre-D
    surface:

      ``gather(f1, f2, f3)``        — varargs
      ``gather([f1, f2, f3])``      — single iterable

    And one new keyword: ``timeout`` — per-Future deadline forwarded to
    ``.result()`` / ``.get()``. Default is each Future's own configured
    deadline.
    """
    from .gather import gather as _gather

    if len(futures) == 1 and not hasattr(futures[0], "result") and not hasattr(futures[0], "get"):
        # Single iterable shape.
        items = list(futures[0])
    else:
        items = list(futures)
    return _gather(items, timeout=timeout)


async def gather_async(*futures: Any) -> list[Any]:
    """Async sibling of :func:`gather`. Same dispatch rules."""
    from .gather import gather_async as _gather_async

    if len(futures) == 1 and not hasattr(futures[0], "result") and not hasattr(futures[0], "get"):
        items = list(futures[0])
    else:
        items = list(futures)
    return await _gather_async(items)


def as_completed(
    futures: Iterable[Future[T]],
    timeout: float | None = None,
) -> Iterator[Future[T]]:
    fut_list = list(futures)
    q: "_queue.Queue[Future[T]]" = _queue.Queue()

    def _wait_one(f: Future[T]) -> None:
        try:
            f.result(timeout=timeout if timeout is not None else 60.0)
        except BaseException:
            pass
        q.put(f)

    for f in fut_list:
        threading.Thread(target=_wait_one, args=(f,), daemon=True).start()
    for _ in range(len(fut_list)):
        yield q.get(timeout=timeout)  # type: ignore[arg-type]


async def as_completed_async(
    futures: Iterable[Future[T]],
) -> AsyncIterator[Future[T]]:
    fut_list = list(futures)
    tasks: dict[asyncio.Task[Any], Future[T]] = {
        asyncio.ensure_future(_await_obj(f)): f for f in fut_list
    }
    pending: set[asyncio.Task[Any]] = set(tasks.keys())
    while pending:
        done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
        for d in done:
            yield tasks[d]


__all__ = [
    "ControlPlaneClient",
    "Daemon",
    "DreamRc",
    "LakeshoreClient",
    "Payload",
    "Provider",
    "Queue",
    "QueueFuture",
    "RunConfig",
    "RunContext",
    "Pool",
    "Storage",
    "TemporaryCredentials",
    "Thunk",
    "Future",
    "ZData",
    "apply",
    "apply_async",
    "apply_spawn",
    "as_completed",
    "as_completed_async",
    "bind",
    "call",
    "call_async",
    "gather",
    "gather_async",
    "load_config",
    "map",
    "map_async",
    "pipeline",
    "resolve",
    "run",
    "spawn",
    "udf",
]
