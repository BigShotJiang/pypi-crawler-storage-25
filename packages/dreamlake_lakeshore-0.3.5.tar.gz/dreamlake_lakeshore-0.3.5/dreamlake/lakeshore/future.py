"""Future — handle to a pending Queue.rpc result.

Phase D adds a second Future flavour alongside the existing
``decorator.Future`` (which is backed by ``ControlPlaneClient.await_result``
and an invocation_id). The Queue-backed flavour here is what
``@udf(queue=q)`` calls and ``q.rpc_future(...)`` return — it's bound
to a topic on a specific :class:`Queue` and resolves via
``Queue.subscribe_one`` / ``Queue.subscribe_stream``.

The two implementations share a public surface — ``.get()`` for sync,
``__await__`` for asyncio, ``__iter__`` for stream-backed futures —
so callers can pass either into :func:`gather`. We deliberately keep
the decorator-side ``Future`` untouched (it's wired through every test
in ``tests/e2e/test_smoke.py``); future.QueueFuture lives in its own
module to make the import path the task spec asks for:

    from dreamlake.lakeshore.future import Future
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any, Generator, Iterator

if TYPE_CHECKING:  # pragma: no cover — circular import dodge
    from .queue import Queue


class QueueFuture:
    """Handle to a pending zaku-style RPC result.

    Construct with ``QueueFuture(queue, request_id, timeout=...)``;
    resolve via ``.get(timeout=...)`` (sync) or ``await fut`` (async).
    For streaming RPCs, iterate the future to consume the stream::

        fut = queue.rpc_future("arg", _timeout=30.0)
        for chunk in fut:
            ...
    """

    def __init__(
        self,
        queue: "Queue",
        request_id: str,
        *,
        timeout: float = 30.0,
        stream: bool = False,
    ):
        self.queue = queue
        self.request_id = request_id
        self._timeout = timeout
        self._stream = stream
        self._cached: dict[str, Any] | None = None
        self._resolved = False

    # Convenience read-only aliases.
    @property
    def id(self) -> str:
        return self.request_id

    @property
    def topic(self) -> str:
        return self.request_id

    def get(self, timeout: float | None = None) -> Any:
        """Block for the result. Returns the decoded dict, or raises
        :class:`TimeoutError` when the wait window elapses with no
        publish on the topic. Memoised — repeat calls return the
        cached value."""
        if self._resolved:
            return self._cached
        t = self._timeout if timeout is None else timeout
        out = self.queue.subscribe_one(self.request_id, timeout=t)
        if out is None:
            raise TimeoutError(
                f"QueueFuture {self.request_id!r} did not resolve "
                f"within {t:.2f}s"
            )
        if isinstance(out, dict) and "_error" in out:
            err = out["_error"] or {}
            raise RuntimeError(
                f"{err.get('type', 'RemoteError')}: {err.get('message', '')}"
            )
        self._cached = out
        self._resolved = True
        return out

    def __await__(self) -> Generator[Any, None, Any]:
        # Push the (potentially long) blocking `.get()` onto the
        # default executor so the event loop stays responsive. Pattern
        # matches decorator.Future.__await__.
        return asyncio.to_thread(self.get).__await__()

    def __iter__(self) -> Iterator[Any]:
        """Iterate the topic as a stream — yields each publish until
        the underlying generator stops (either at the publisher's
        close signal or at the per-future timeout)."""
        # Wrap subscribe_stream so this future is reusable: it caches
        # the first yielded payload to satisfy `.get()` callers that
        # come after the stream is exhausted.
        first_seen = False
        for msg in self.queue.subscribe_stream(self.request_id, timeout=self._timeout):
            if not first_seen:
                self._cached = msg if isinstance(msg, dict) else {"value": msg}
                self._resolved = True
                first_seen = True
            yield msg

    def __repr__(self) -> str:
        return (
            f"<QueueFuture queue={self.queue.name!r} "
            f"topic={self.request_id!r} resolved={self._resolved}>"
        )


# Public alias — the task spec asks for ``from dreamlake.lakeshore.future
# import Future``. The two Future classes (decorator.Future for
# producer/await-backed @udf results, future.QueueFuture for
# zaku-style RPC) coexist; the name "Future" in this module resolves
# to the Queue-backed one.
Future = QueueFuture


__all__ = ["Future", "QueueFuture"]
