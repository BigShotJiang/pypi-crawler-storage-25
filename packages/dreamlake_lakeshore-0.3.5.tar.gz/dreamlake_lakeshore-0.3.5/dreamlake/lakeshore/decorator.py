"""@udf — Functions, thunks, and dispatch primitives.

Surface (see /functions docs page for the full table):

    @udf                              local-only Function
    @udf("mode")                      remote-by-default Function
    @udf("mode") async def            remote async Function
    @udf.pure                         local-only, safe to re-invoke in same runtime
    @udf.pure("mode")                 remote, safe to re-invoke in same runtime

    fn(...)        plain call. Decorator decides: local or remote+blocking.
    fn.local(...)  always local.

    udf.bind(fn, *args, **kw)        a deferred call bundle
    udf.spawn(thunk)                  → Future
    udf.call(thunk)                   → result (sync) | coroutine (async)
    udf.apply_spawn(fn, *args, **kw)  → Future
    udf.apply_async(fn, *args, **kw)  → coroutine
"""

from __future__ import annotations

import asyncio
import contextvars
import hashlib
import inspect
import textwrap
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Generator, Generic, TypeVar, Union

import cloudpickle
import msgpack
from ulid import ULID

from .client import ControlPlaneClient

T = TypeVar("T")


# ─── Run context (callee side) ───────────────────────────────────────


@dataclass
class RunContext:
    """Available as `dls.run` inside an Invocation's function body.

    The daemon installs an `event_sink` callable before invoking the
    function body. Calls to `dls.run.progress / .log / .emit` route
    through that sink to the control plane's event log."""

    id: str
    attempt: int = 0
    event_sink: Any | None = None  # Callable[[str, dict], None]
    parent_id: str | None = None
    root_id: str | None = None

    def _emit(self, kind: str, body: dict[str, Any]) -> None:
        sink = self.event_sink
        if sink is None:
            return
        try:
            sink(kind, body)
        except Exception:  # never let event delivery crash a UDF
            pass


_current_run: contextvars.ContextVar[RunContext | None] = contextvars.ContextVar(
    "_current_run", default=None
)


class _RunProxy:
    @property
    def id(self) -> str:
        ctx = _current_run.get()
        return ctx.id if ctx else ""

    @property
    def attempt(self) -> int:
        ctx = _current_run.get()
        return ctx.attempt if ctx else 0

    @property
    def parent_id(self) -> str | None:
        ctx = _current_run.get()
        return ctx.parent_id if ctx else None

    @property
    def root_id(self) -> str | None:
        ctx = _current_run.get()
        return ctx.root_id if ctx else None

    def progress(
        self,
        step: float | int,
        total: float | int | None = None,
        label: str | None = None,
    ) -> None:
        """Emit a progress event. `step` and `total` are arbitrary
        (counters, bytes, batches, seconds). The dashboard renders
        `step / total` as a progress bar when both are present."""
        ctx = _current_run.get()
        if not ctx:
            return
        body: dict[str, Any] = {"step": step}
        if total is not None:
            body["total"] = total
            try:
                body["fraction"] = float(step) / float(total) if total else 0.0
            except (TypeError, ZeroDivisionError):
                pass
        if label is not None:
            body["label"] = label
        ctx._emit("progress", body)

    def log(self, message: str, level: str = "info", **fields: Any) -> None:
        """Emit a log event from inside a UDF body."""
        ctx = _current_run.get()
        if not ctx:
            return
        body: dict[str, Any] = {"level": level, "message": message}
        if fields:
            body["extra"] = fields
        ctx._emit("log", body)

    def emit(self, name: str, body: dict[str, Any] | None = None) -> None:
        """Emit a user-defined event with an arbitrary `name` and `body`."""
        ctx = _current_run.get()
        if not ctx:
            return
        ctx._emit("event", {"name": name, "body": body or {}})

    def _set(self, ctx: RunContext | None) -> contextvars.Token:
        return _current_run.set(ctx)

    def _reset(self, token: contextvars.Token) -> None:
        _current_run.reset(token)


run = _RunProxy()


# ─── Future ──────────────────────────────────────────────────────────


class Future(Generic[T]):
    """Handle to an Invocation's outcome. Blocking via `.result()`,
    awaitable via `await fut` (offloads the wait to a thread for v0)."""

    def __init__(self, invocation_id: str, client: ControlPlaneClient):
        self.invocation_id = invocation_id
        self._client = client
        self._cached: dict[str, Any] | None = None

    @property
    def id(self) -> str:
        return self.invocation_id

    def done(self) -> bool:
        return self._cached is not None and self._cached.get("state") not in (None, "pending")

    def result(self, timeout: float = 300.0) -> T:
        if self._cached is None or self._cached.get("state") == "pending":
            self._cached = self._client.await_result(self.invocation_id, timeout_s=timeout)
        return self._unpack()

    def _unpack(self) -> T:
        state = (self._cached or {}).get("state")
        if state == "succeeded":
            blob = (self._cached or {}).get("result_blob")
            return msgpack.unpackb(blob, raw=False) if blob else None  # type: ignore[return-value]
        if state == "failed":
            err = (self._cached or {}).get("error") or {}
            raise RuntimeError(f"{err.get('type', 'Error')}: {err.get('message', '')}")
        if state == "killed":
            raise RuntimeError("Invocation was killed")
        if state == "timeout":
            raise TimeoutError("Invocation exceeded timeout_s")
        raise TimeoutError(f"Invocation {self.invocation_id} not done")

    def __await__(self) -> Generator[Any, None, T]:
        return asyncio.to_thread(self.result).__await__()


# ─── Function ────────────────────────────────────────────────────────


@dataclass
class _Defaults:
    mode: str | None = None
    timeout_s: float | None = None
    env: dict[str, str] = field(default_factory=dict)
    resources: dict[str, Any] = field(default_factory=dict)
    image: str | None = None
    pure: bool = False


class _UDF(Generic[T]):
    """A Function. Whether plain `fn(...)` goes local or remote is
    determined at decoration:

      @udf def f(...)              → fn(...) is local
      @udf("mode") def f(...)      → fn(...) is remote (blocks; awaits if async)

    `fn.local(...)` always runs in-process.
    """

    def __init__(
        self,
        fn: Callable[..., T],
        defaults: _Defaults | None = None,
        *,
        remote_by_default: bool = False,
    ):
        self._fn = fn
        self._defaults = defaults or _Defaults()
        self._remote_by_default = remote_by_default
        self._is_async = inspect.iscoroutinefunction(fn)
        self.pure = self._defaults.pure
        self.__wrapped__ = fn
        for attr in ("__module__", "__name__", "__qualname__", "__doc__"):
            try:
                setattr(self, attr, getattr(fn, attr))
            except AttributeError:
                pass

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        # Local short-circuit: `@udf` (no mode) or `@udf("local")` runs
        # in-process. Anything else dispatches via the fabric.
        if not self._remote_by_default or self._defaults.mode == "local":
            return self._fn(*args, **kwargs)
        # @udf(mode=...) — plain call dispatches remotely.
        if self._is_async:
            return self._await_remote(args, kwargs)
        return self._submit(args, kwargs).result()

    def local(self, *args: Any, **kwargs: Any) -> T:
        return self._fn(*args, **kwargs)

    # Internals used by udf.bind / udf.spawn / udf.apply_*

    def _submit(
        self,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        queue: str | None = None,
    ) -> Future[T]:
        fn_pickled = cloudpickle.dumps(self._fn)
        version = hashlib.sha256(fn_pickled).hexdigest()[:16]
        try:
            source = textwrap.dedent(inspect.getsource(self._fn))
        except (OSError, TypeError):
            source = ""
        args_blob = msgpack.packb(
            {"fn_pickled": fn_pickled, "args": list(args), "kwargs": kwargs},
            use_bin_type=True,
        )
        run_config: dict[str, Any] = {}
        if self._defaults.mode is not None:
            run_config["mode"] = self._defaults.mode
        if self._defaults.timeout_s is not None:
            run_config["timeout_s"] = self._defaults.timeout_s
        if self._defaults.env:
            run_config["env"] = self._defaults.env
        if self._defaults.resources:
            run_config["resources"] = self._defaults.resources
        if self._defaults.image is not None:
            run_config["image"] = self._defaults.image
        # If we're currently executing inside another UDF (the daemon
        # installed a RunContext before calling us), stamp the new
        # invocation's parent_invocation_id with that id. Lakeshore
        # uses this to build pipeline trees.
        parent_ctx = _current_run.get()
        envelope: dict[str, Any] = {
            "invocation_id": str(ULID()),
            "function": {
                "module": getattr(self._fn, "__module__", "__main__"),
                "qualname": getattr(self._fn, "__qualname__", self._fn.__name__),
                "version": version,
                "source": source,
            },
            "args_blob": args_blob,
            "run_config": run_config,
        }
        if parent_ctx is not None:
            envelope["parent_invocation_id"] = parent_ctx.id
        # Queue routing: explicit > mode name > "default"
        envelope["queue"] = queue or self._defaults.mode or "default"
        client = ControlPlaneClient()
        inv_id = client.submit(envelope)
        return Future(inv_id, client)

    async def _await_remote(self, args: tuple[Any, ...], kwargs: dict[str, Any]) -> T:
        return await self._submit(args, kwargs)


# ─── Decorator entrypoints ───────────────────────────────────────────


def udf(fn: Callable[..., T]) -> _UDF[T]:
    """Plain `@udf` — Function with no remote default. `fn(...)` is local."""
    return _UDF(fn, _Defaults(), remote_by_default=False)


def compute(
    mode: str | None = None,
    *,
    timeout_s: float | None = None,
    env: dict[str, str] | None = None,
    resources: dict[str, Any] | None = None,
    image: str | None = None,
    pure: bool = False,
) -> Callable[[Callable[..., T]], _UDF[T]]:
    """Parametric decorator builder used by `udf(...)`. `@udf("mode")`
    or `@udf(mode=..., timeout_s=...)` makes the Function dispatch
    remotely on plain call."""
    defaults = _Defaults(
        mode=mode,
        timeout_s=timeout_s,
        env=env or {},
        resources=resources or {},
        image=image,
        pure=pure,
    )

    def decorator(fn: Callable[..., T]) -> _UDF[T]:
        return _UDF(fn, defaults, remote_by_default=True)

    return decorator


def pure(fn_or_mode: Any = None, **kwargs: Any) -> Any:
    """Mark a Function as pure — safe to re-invoke in the same runtime.

        @udf.pure                      — local-only, pure
        @udf.pure("h100")              — remote, pure
        @udf.pure(mode="h100", ...)    — remote with options, pure
    """
    if callable(fn_or_mode) and not isinstance(fn_or_mode, str):
        return _UDF(fn_or_mode, _Defaults(pure=True), remote_by_default=False)
    if fn_or_mode is not None:
        if "mode" in kwargs:
            raise TypeError("udf.pure() got mode both positionally and as a keyword")
        kwargs["mode"] = fn_or_mode
    kwargs["pure"] = True
    return compute(**kwargs)


# ─── Thunks ──────────────────────────────────────────────────────────


@dataclass
class Thunk(Generic[T]):
    """A deferred Function call — `(fn, args, kwargs)` bundled together
    so it can be dispatched later via `udf.spawn(thunk)` or
    `udf.call(thunk)`."""

    fn: _UDF[T]
    args: tuple[Any, ...]
    kwargs: dict[str, Any]

    @property
    def is_async(self) -> bool:
        return self.fn._is_async


def bind(fn: _UDF[T], /, *args: Any, **kwargs: Any) -> Thunk[T]:
    """Build a deferred call (a `Thunk`). Does not dispatch — pass the
    result to `udf.spawn(...)` or `udf.call(...)`."""
    if not isinstance(fn, _UDF):
        raise TypeError(f"udf.bind() expects a @udf-decorated function, got {type(fn).__name__}")
    return Thunk(fn=fn, args=args, kwargs=kwargs)


# ─── Dispatch primitives ─────────────────────────────────────────────


_FnOrThunk = Union[_UDF[T], Thunk[T]]


def _split(target: _FnOrThunk[T], args: tuple[Any, ...], kwargs: dict[str, Any]):
    if isinstance(target, Thunk):
        if args or kwargs:
            raise TypeError("positional/keyword args not allowed when passing a Thunk")
        return target.fn, target.args, target.kwargs
    if isinstance(target, _UDF):
        return target, args, kwargs
    raise TypeError(
        f"expected @udf-decorated function or udf.bind(...), got {type(target).__name__}"
    )


def apply(target: _FnOrThunk[T], /, *args: Any, **kwargs: Any) -> T:
    """Sync **blocking** dispatch. Returns the result."""
    fn, a, k = _split(target, args, kwargs)
    return fn._submit(a, k).result()


def apply_spawn(target: _FnOrThunk[T], /, *args: Any, **kwargs: Any) -> Future[T]:
    """Sync **non-blocking** dispatch. Returns a Future."""
    fn, a, k = _split(target, args, kwargs)
    return fn._submit(a, k)


def apply_async(target: _FnOrThunk[T], /, *args: Any, **kwargs: Any) -> Awaitable[T]:
    """**Async** dispatch. Returns a coroutine — `await` to get the result.
    Forces a *sync* Function or Thunk into the async-caller world.

    Rejects async inputs: if the target is `async def`, just call it as
    `await fn(...)` (or pass through `udf.apply` to block in sync code).
    """
    fn, a, k = _split(target, args, kwargs)
    if fn._is_async:
        name = getattr(fn, "__qualname__", getattr(fn, "__name__", "<fn>"))
        raise TypeError(
            f"udf.apply_async / udf.call_async require a sync target; "
            f"{name!r} is async. Use `await {name}(...)` or `udf.apply(...)` instead."
        )

    async def _coro() -> T:
        return await fn._submit(a, k)

    return _coro()


# Thunk-flavored aliases. Same semantics, naming reads better when the
# argument is already a Thunk.

def call(thunk: Thunk[T]) -> T:
    """Sync blocking dispatch of a Thunk."""
    return apply(thunk)


def spawn(thunk: Thunk[T]) -> Future[T]:
    """Sync non-blocking dispatch of a Thunk. Returns a Future."""
    return apply_spawn(thunk)


def call_async(thunk: Thunk[T]) -> Awaitable[T]:
    """Async dispatch of a Thunk. Returns a coroutine — `await` for result."""
    return apply_async(thunk)
