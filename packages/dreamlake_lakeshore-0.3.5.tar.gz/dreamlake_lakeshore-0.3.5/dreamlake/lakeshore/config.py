"""Library-level config — the `.dreamrc` file.

`.dreamrc` is YAML. It declares named **compute modes** (`RunConfig`s)
that `@udf` can target. A mode resolves to a backend (local, fabric,
…) plus the parameters that backend needs.

It also declares **providers** under `providers:` — account / cloud
connections that DreamLake reaches through jaynes launchers. Each
provider entry carries a YAML tag (`!providers.SSH`, `!providers.EC2`,
…) and the body is the launcher kwargs. A `RunConfig` references a
provider by name and supplies the per-machine kwargs on top.

Lookup order (first match wins):

    1. explicit path passed to `load_config(path=...)`
    2. $DREAMRC (single file)
    3. ./.dreamrc, walking up to the filesystem root
    4. ~/.dreamrc
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

# ─── Known launcher tags ──────────────────────────────────────────────
# Order matters only for error messages. The tag is the type
# discriminator — there's no `type:` field on a provider entry.

KNOWN_PROVIDER_TAGS: tuple[str, ...] = ("SSH", "EC2", "GCE", "SLURM", "Kube")

# Default dispatch per launcher type (see providers docs).
DEFAULT_DISPATCH: dict[str, str] = {
    "SSH": "direct",
    "Kube": "direct",
    "EC2": "daemon",
    "GCE": "daemon",
    "SLURM": "direct",
}


@dataclass
class Provider:
    """A provider entry parsed from `.dreamrc`.

    `launcher` is the launcher class name (`"SSH"`, `"EC2"`, …) taken
    from the YAML tag. `kwargs` is the raw mapping body — passed to
    the jaynes launcher after deep-merge with the `RunConfig`. The
    launcher class itself is *not* imported at parse time.
    """

    launcher: str
    kwargs: dict[str, Any] = field(default_factory=dict)

    @property
    def dispatch(self) -> str:
        explicit = self.kwargs.get("dispatch")
        if explicit:
            return explicit
        return DEFAULT_DISPATCH.get(self.launcher, "direct")


@dataclass
class RunConfig:
    """A named compute mode. References a provider and supplies the
    per-machine launcher kwargs (instance_type, partition, …) plus the
    runtime-side knobs (runner, image, resources, …) the runtime layer
    consumes."""

    # "local" runs in-process; "fabric" dispatches through the elastic
    # fabric to a worker selected by tags + runner availability.
    backend: str = "local"
    server: str | None = None
    tags: Any = field(default_factory=list)
    # Sandbox the worker should use: "docker" | "gvisor" | "process".
    runner: str = "docker"
    resources: dict[str, Any] = field(default_factory=dict)
    image: str | None = None
    env: dict[str, str] = field(default_factory=dict)
    timeout_s: int | None = None
    # Compute backend this mode draws hosts from. Resolved against a
    # Provider record on Lakeshore. None / "local" means
    # operator-managed (Lakeshore won't try to launch hosts).
    provider: str | None = None
    # Any extra fields are forwarded to the launcher at dispatch time.
    # (instance_type, image_id, partition, time_limit, n_cpu, n_gpu, …)
    extras: dict[str, Any] = field(default_factory=dict)

    # Fields the runtime layer reads — *not* forwarded to the launcher.
    _RUNTIME_FIELDS = {
        "backend",
        "server",
        "runner",
        "resources",
        "image",
        "env",
        "timeout_s",
        "provider",
    }

    @classmethod
    def from_dict(cls, body: dict[str, Any]) -> "RunConfig":
        # Pull recognized fields off; everything else lands in extras.
        known = {
            "backend",
            "server",
            "tags",
            "runner",
            "resources",
            "image",
            "env",
            "timeout_s",
            "provider",
        }
        kw: dict[str, Any] = {}
        extras: dict[str, Any] = {}
        for k, v in body.items():
            if k in known:
                kw[k] = v
            else:
                extras[k] = v
        kw["extras"] = extras
        return cls(**kw)

    def launcher_kwargs(self) -> dict[str, Any]:
        """The portion of this RunConfig that gets deep-merged into the
        launcher kwargs at dispatch. Excludes runtime-only fields."""
        out: dict[str, Any] = dict(self.extras)
        # `tags` lives on the RunConfig but is also relevant to the
        # launcher (e.g., EC2 instance tags) — pass through.
        if self.tags:
            out.setdefault("tags", self.tags)
        return out


# ─── YAML tag handling ────────────────────────────────────────────────


class DreamRcLoader(yaml.SafeLoader):
    """Project-scoped SafeLoader so our `!providers.X` tags don't leak
    into other yaml.safe_load callers."""


def _provider_constructor_factory(tag_suffix: str):
    """Constructor for `!providers.<Name>` tags. Returns a Provider."""

    def _construct(loader: yaml.Loader, node: yaml.Node) -> Provider:
        if not isinstance(node, yaml.MappingNode):
            raise yaml.constructor.ConstructorError(
                None,
                None,
                f"!providers.{tag_suffix} expects a mapping body",
                node.start_mark,
            )
        kwargs = loader.construct_mapping(node, deep=True)
        if tag_suffix not in KNOWN_PROVIDER_TAGS:
            known = ", ".join(f"!providers.{t}" for t in KNOWN_PROVIDER_TAGS)
            raise yaml.constructor.ConstructorError(
                None,
                None,
                f"unknown provider tag '!providers.{tag_suffix}'. Known tags: {known}",
                node.start_mark,
            )
        return Provider(launcher=tag_suffix, kwargs=kwargs)

    return _construct


def _register_provider_tags() -> None:
    # Register a multi-constructor on the prefix so unknown
    # `!providers.Foo` tags hit our error path (instead of pyyaml's
    # generic "unknown tag" error).
    def _multi(loader: yaml.Loader, tag_suffix: str, node: yaml.Node) -> Provider:
        return _provider_constructor_factory(tag_suffix)(loader, node)

    DreamRcLoader.add_multi_constructor("!providers.", _multi)


_register_provider_tags()


# ─── DreamRc top-level ────────────────────────────────────────────────


@dataclass
class DreamRc:
    default_mode: str = "local"
    modes: dict[str, RunConfig] = field(default_factory=lambda: {"local": RunConfig()})
    providers: dict[str, Provider] = field(default_factory=dict)
    # Root-level RunConfig — populated when `.dreamrc` has fields like
    # `backend:` / `provider:` at the top level (per the docs spec).
    root: RunConfig | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DreamRc":
        # `modes:` block — explicit named modes.
        modes_block = data.get("modes") or data.get("mode") or {}
        modes: dict[str, RunConfig] = {}
        for name, body in modes_block.items():
            if body is None:
                body = {}
            if not isinstance(body, dict):
                raise ValueError(f"mode '{name}': body must be a mapping")
            modes[name] = RunConfig.from_dict(body)
        if "local" not in modes:
            modes["local"] = RunConfig()

        # `providers:` block — Provider entries (already constructed by
        # the YAML loader from `!providers.X` tags).
        providers: dict[str, Provider] = {}
        for name, entry in (data.get("providers") or {}).items():
            if not isinstance(entry, Provider):
                raise ValueError(
                    f"providers.{name}: must be a tagged mapping "
                    "(`!providers.SSH`, `!providers.EC2`, …)"
                )
            providers[name] = entry

        # Anything else at the root that looks like RunConfig fields
        # becomes the root RunConfig.
        skip = {"default_mode", "modes", "mode", "providers"}
        root_body = {k: v for k, v in data.items() if k not in skip}
        root = RunConfig.from_dict(root_body) if root_body else None

        return cls(
            default_mode=data.get("default_mode", "local"),
            modes=modes,
            providers=providers,
            root=root,
        )

    def mode(self, name: str | None = None) -> RunConfig:
        return self.modes[name or self.default_mode]


def _walk_for_dreamrc(start: Path) -> Path | None:
    cur = start.resolve()
    while True:
        candidate = cur / ".dreamrc"
        if candidate.is_file():
            return candidate
        if cur.parent == cur:
            return None
        cur = cur.parent


def _load_yaml(path: Path) -> dict[str, Any]:
    with open(path) as f:
        data = yaml.load(f, Loader=DreamRcLoader) or {}
    if not isinstance(data, dict):
        raise ValueError(f"{path}: top-level must be a mapping")
    return data


def load_yaml_string(text: str) -> dict[str, Any]:
    """Public helper — load `.dreamrc`-flavored YAML from a string with
    provider tags registered. Mostly for tests."""
    data = yaml.load(text, Loader=DreamRcLoader) or {}
    if not isinstance(data, dict):
        raise ValueError("top-level must be a mapping")
    return data


def load_config(path: str | Path | None = None) -> DreamRc:
    if path is not None:
        return DreamRc.from_dict(_load_yaml(Path(path)))

    env = os.environ.get("DREAMRC")
    if env and Path(env).is_file():
        return DreamRc.from_dict(_load_yaml(Path(env)))

    walked = _walk_for_dreamrc(Path.cwd())
    if walked:
        return DreamRc.from_dict(_load_yaml(walked))

    home = Path.home() / ".dreamrc"
    if home.is_file():
        return DreamRc.from_dict(_load_yaml(home))

    return DreamRc()


# ─── Resolver ─────────────────────────────────────────────────────────


def _deep_merge(a: Any, b: Any) -> Any:
    """Deep-merge `b` into `a`. Scalars from `b` win on conflict;
    dicts and lists merge recursively. Returns a new object — neither
    input is mutated."""
    if isinstance(a, dict) and isinstance(b, dict):
        out = dict(a)
        for k, v in b.items():
            if k in out:
                out[k] = _deep_merge(out[k], v)
            else:
                out[k] = v
        return out
    if isinstance(a, list) and isinstance(b, list):
        # Concatenate, dedupe order-preserving for hashables.
        merged: list[Any] = list(a)
        for item in b:
            try:
                if item not in merged:
                    merged.append(item)
            except TypeError:
                merged.append(item)
        return merged
    # Scalars / type mismatch: `b` wins.
    return b


def resolve(
    dreamrc: DreamRc, mode_name: str | None = None
) -> tuple[Provider, dict[str, Any], RunConfig]:
    """Resolve a mode → (provider, merged_launcher_kwargs, runconfig).

    - `mode_name=None` picks the root RunConfig if there is one, else
      the default mode.
    - Returns the matched Provider entry, the deep-merged launcher
      kwargs (provider kwargs ∪ runconfig launcher-shaped kwargs), and
      the RunConfig the runtime layer consumes.
    """
    if mode_name is None:
        runconfig = dreamrc.root or dreamrc.mode(None)
    else:
        runconfig = dreamrc.mode(mode_name)

    if not runconfig.provider:
        raise ValueError(
            f"RunConfig has no provider set — cannot resolve a launcher."
        )

    provider = dreamrc.providers.get(runconfig.provider)
    if provider is None:
        known = ", ".join(dreamrc.providers) or "(none)"
        raise KeyError(
            f"RunConfig references provider '{runconfig.provider}' "
            f"which is not declared. Known providers: {known}"
        )

    merged = _deep_merge(provider.kwargs, runconfig.launcher_kwargs())
    return provider, merged, runconfig


def resolve_by_provider(
    dreamrc: DreamRc, provider_name: str
) -> tuple[Provider, dict[str, Any], RunConfig]:
    """Resolve directly by provider name — for `dreamlake providers test
    <name>` which doesn't go through a RunConfig. Returns the provider,
    its kwargs as-is (no RunConfig merge), and a minimal inline RunConfig
    (`runner=process`, `backend=local`).
    """
    provider = dreamrc.providers.get(provider_name)
    if provider is None:
        known = ", ".join(dreamrc.providers) or "(none)"
        raise KeyError(
            f"Provider '{provider_name}' is not declared in .dreamrc. "
            f"Known providers: {known}"
        )
    runconfig = RunConfig(backend="local", runner="process", provider=provider_name)
    merged = dict(provider.kwargs)
    return provider, merged, runconfig
