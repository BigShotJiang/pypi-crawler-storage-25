"""Explicit Queue and Pool constructs.

A Queue is the addressable handle for a worker pool. Submit Invocations
to it; daemons attached to its name pull and run them.

A Pool is a Queue with `min_hosts == max_hosts == size` — no
auto-scaling, fixed-size worker set.

Phase D — the Queue also exposes a zaku-style RPC surface on top of
the existing CP wire:

    q = Queue("rpc-demo")
    q.add({"x": 1}, key="job-1")        # producer side
    q.publish({"y": 2}, topic="t-1")    # daemon-side return channel
    msg = q.subscribe_one("t-1", timeout=5.0)
    result = q.rpc(x=1, _timeout=5.0)   # add + subscribe_one combined

The transport is msgpack + ZData inline against the existing
producer/submit + daemon/poll + daemon/ack + producer/await routes —
no S3 hop and no new CP endpoints. Phase D.5 will swap this onto the
`payloadInline` / `payloadRef` shape from /dev-payload-store.
"""

from __future__ import annotations

import queue as _queue
import socket
import threading
import time
from typing import Any, AsyncIterator, Awaitable, Iterable, Iterator, TypeVar
from uuid import uuid4

from ulid import ULID

from .client import ControlPlaneClient
from .decorator import Future, Thunk, _UDF, _split
from .future import QueueFuture
from .zdata import Payload

T = TypeVar("T")


def _drain_internal_keys(payload: dict[str, Any]) -> dict[str, Any]:
    """Pop SDK-internal keys (`_fn_pickled`, `_args`, ...) so the caller
    sees a clean dict. Used in `take()` after decoding."""
    return payload


class Queue:
    """Named pipe of Invocations bound to a Pool.

    Lifecycle is explicit: construct to upsert, call `.drain()` to mark
    draining. Workers attach to the queue via `--queue NAME` on the
    daemon.

    The constructor is idempotent — same name + same args = no-op
    upsert. The Phase A.5 namespaced CRUD route (`/v1/namespaces/:ns/
    queues`) is the source of truth for queue rows; the legacy
    `/v1/producer/queues` upsert is also tickled so daemons that still
    poll for `name` see the row.
    """

    def __init__(
        self,
        name: str,
        *,
        # Phase D kwargs — wire to the namespaced CRUD route.
        kind: str | None = None,
        kind_params: dict[str, Any] | None = None,
        elasticity: dict[str, Any] | None = None,
        provider: str | None = None,
        daemon_template: dict[str, Any] | None = None,
        admission: dict[str, Any] | None = None,
        description: str | None = None,
        # Legacy `producer/queues` kwargs — kept for backwards-compat
        # with existing call-sites and the Pool subclass.
        mode: str | None = None,
        min_hosts: int = 0,
        max_hosts: int = 4,
        policy: str = "target_concurrency",
        idle_timeout_s: int = 120,
        # Connection.
        server: str | None = None,
        namespace: str = "default",
    ):
        self.name = name
        self.kind = kind
        self.kind_params = kind_params
        self.mode = mode
        self.min_hosts = min_hosts
        self.max_hosts = max_hosts
        self.policy = policy
        self.idle_timeout_s = idle_timeout_s
        self._client = ControlPlaneClient(base_url=server, namespace=namespace)
        # Idempotent: upsert via the modern CRUD route when any
        # Phase-A.5 knob is supplied. Otherwise fall back to the
        # name-only legacy upsert (cheaper, and the only path
        # available before the CRUD route landed).
        wants_crud = any(
            v is not None
            for v in (kind, kind_params, elasticity, provider, daemon_template, admission, description)
        )
        if wants_crud:
            try:
                self._client.upsert_queue_crud(
                    name,
                    kind=kind,
                    kind_params=kind_params,
                    elasticity=elasticity,
                    provider_ref=provider,
                    daemon_template=daemon_template,
                    admission=admission,
                    description=description,
                )
            except Exception:
                # If the CRUD route isn't available (older CP), fall
                # back to the legacy upsert so the SDK still works.
                self._client.ensure_queue(name)
        else:
            self._client.ensure_queue(
                name,
                mode=mode,
                min_hosts=min_hosts,
                max_hosts=max_hosts,
                policy=policy,
                idle_timeout_s=idle_timeout_s,
            )
        # Stable client-side worker_id used by the daemon-side helpers
        # (`take()`). The CP scopes worker_ids per call, so this
        # doesn't need to be globally unique — just stable enough that
        # claim+ack pair up.
        self._worker_id = f"{socket.gethostname()}-{ULID()}"

    # ─── Lifecycle ───────────────────────────────────────────────────

    def __enter__(self) -> "Queue":
        return self

    def __exit__(self, *_: object) -> None:
        # Explicit lifecycle — don't auto-drain on context exit.
        pass

    def drain(self) -> None:
        # TODO v1: PATCH the queue state to "draining" — currently a no-op.
        pass

    def close(self) -> None:
        self._client.close()

    # ─── Submission ──────────────────────────────────────────────────

    def submit(self, fn_or_thunk: _UDF[T] | Thunk[T], /, *args: Any, **kwargs: Any) -> Future[T]:
        fn, a, k = _split(fn_or_thunk, args, kwargs)
        return fn._submit(a, k, queue=self.name)

    # ─── Orchestration scoped to this queue ──────────────────────────

    def map(self, fn: _UDF[T], iterable: Iterable[Any]) -> list[T]:
        futs = [self.submit(fn, item) for item in iterable]
        return [f.result() for f in futs]

    async def map_async(self, fn: _UDF[T], iterable: Iterable[Any]) -> list[T]:
        import asyncio

        coros: list[Awaitable[T]] = []
        for item in iterable:
            fut = self.submit(fn, item)

            async def _await(f: Future[T] = fut) -> T:
                return await f

            coros.append(_await())
        return list(await asyncio.gather(*coros))

    def gather(self, *futures: Future[T]) -> list[T]:
        return [f.result() for f in futures]

    def as_completed(
        self,
        futures: Iterable[Future[T]],
        timeout: float | None = None,
    ) -> Iterator[Future[T]]:
        fut_list = list(futures)
        q: "_queue.Queue[Future[T]]" = _queue.Queue()

        def _wait_one(f: Future[T]) -> None:
            try:
                f.result(timeout=timeout if timeout is not None else 60.0)
            except BaseException:
                pass
            q.put(f)

        for f in fut_list:
            threading.Thread(target=_wait_one, args=(f,), daemon=True).start()
        for _ in range(len(fut_list)):
            yield q.get(timeout=timeout)  # type: ignore[arg-type]

    async def as_completed_async(
        self,
        futures: Iterable[Future[T]],
    ) -> AsyncIterator[Future[T]]:
        import asyncio

        fut_list = list(futures)
        tasks: dict[asyncio.Task[Any], Future[T]] = {}
        for f in fut_list:
            async def _await(fu: Future[T] = f) -> Any:
                return await fu

            tasks[asyncio.ensure_future(_await())] = f
        pending: set[asyncio.Task[Any]] = set(tasks.keys())
        while pending:
            done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
            for d in done:
                yield tasks[d]

    # ─── zaku-style RPC surface ──────────────────────────────────────
    #
    # `add` / `take` / `publish` / `subscribe_one` / `subscribe_stream`
    # mirror the zaku.TaskQ contract; the wire is the existing CP exec
    # path overlayed with msgpack+ZData payloads. Topic IDs are
    # invocation IDs — they're the addressable unit the CP already
    # speaks. The "Phase D.5 cutover" referenced in /dev-payload-store
    # swaps `args_blob` / `result_blob` for `payloadRef` shapes; the
    # public surface here doesn't change.

    def add(self, payload: dict[str, Any], *, key: str | None = None) -> str:
        """Enqueue a payload. Returns the job_id (=invocation_id).

        The payload is msgpack+ZData encoded inline. `key` is accepted
        for zaku-compat (Lakeshore's CP allocates a ULID server-side
        when omitted, but we honour `key` as the invocation_id when
        supplied so callers can pre-mint topic names).
        """
        invocation_id = key or str(uuid4())
        # The CP's /v1/producer/submit route requires `function.module`
        # / `qualname` / `version` — we synthesise stable values for
        # raw zaku-style enqueues. The udf_runner daemon-side loop
        # treats any qualname starting with `_queue_payload.` as
        # "no callable, just deliver the payload to take()". This
        # lets a generic worker pool consume queues filled with both
        # `@udf`-decorated calls (function = real qualname) and raw
        # payloads (function = synthetic).
        args_blob = Payload(**payload).serialize()
        envelope = {
            "invocation_id": invocation_id,
            "queue": self.name,
            "function": {
                "module": "_queue_payload",
                "qualname": f"_queue_payload.{self.name}",
                "version": "raw",
            },
            "args_blob": args_blob,
            "run_config": {"queue": self.name},
        }
        self._client.submit(envelope)
        return invocation_id

    def take(self, *, timeout_s: float = 30.0) -> dict[str, Any] | None:
        """Pop one job. Returns the decoded payload dict with
        `_request_id` injected (= the invocation_id the daemon must
        publish back to). Returns None on timeout.

        Daemon-side helper. The caller is expected to publish to
        `_request_id` once it has a result.
        """
        resp = self._client.poll(self._worker_id, timeout_s=timeout_s, queue=self.name)
        for cmd in resp.get("commands", []) or []:
            if cmd.get("kind") != "run":
                # Setup/exec/control commands aren't our shape.
                continue
            body = cmd.get("body") or {}
            inv_id = body.get("invocation_id")
            args_blob = body.get("args_blob")
            if not inv_id or args_blob is None:
                continue
            try:
                payload = Payload.deserialize(args_blob)
            except Exception:
                # Non-msgpack-ZData payload (e.g. raw cloudpickled @udf
                # envelope) — hand it back transparently for the caller
                # to interpret. Keep the raw bytes accessible.
                payload = {"_args_blob": args_blob}
            payload["_request_id"] = inv_id
            return payload
        return None

    def publish(self, value: dict[str, Any], *, topic: str) -> int:
        """Publish a value to a per-request return topic. Topic IDs are
        invocation IDs. Returns 1 on success, 0 on transport failure.

        Mirrors zaku.publish — fan-out subscriber counts are 0 or 1
        under the current CP wire (one subscriber per topic), with the
        return shape kept compatible for future broadcast support.
        """
        result_blob = Payload(**value).serialize()
        try:
            self._client.ack(topic, state="succeeded", result_blob=result_blob)
            return 1
        except Exception:
            return 0

    def subscribe_one(
        self, topic: str, timeout: float = 5.0
    ) -> dict[str, Any] | None:
        """Block for the next publish on `topic`. Returns the decoded
        dict, or None on timeout.

        Maps onto `/v1/producer/await` against the topic-as-
        invocation_id."""
        out = self._client.await_result(topic, timeout_s=timeout)
        state = out.get("state")
        if state == "pending" or state is None:
            return None
        blob = out.get("result_blob")
        if not blob:
            err = out.get("error") or None
            if state == "failed" and err:
                # zaku surfaces errors as a dict on the topic — match.
                return {"_error": err}
            return None
        try:
            return Payload.deserialize(blob)
        except Exception:
            # Treat non-Payload bytes as a single 'value' field.
            import msgpack as _mp

            return {"value": _mp.unpackb(blob, raw=False)}

    def subscribe_stream(
        self, topic: str, timeout: float = 5.0
    ) -> Iterator[dict[str, Any]]:
        """Stream messages on `topic` until the publisher closes or
        `timeout` seconds elapse with no new messages.

        Overlay note (Phase D): the existing CP wire is one-result-per-
        invocation; a true stream needs a per-topic event journal that
        Phase D.5 will deliver. Today the generator yields the
        terminal result exactly once and then stops, matching the
        baseline expected by single-shot RPC callers. The shape is
        future-proof — Phase D.5 just lifts the `break` below.
        """
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            remaining = max(0.05, deadline - time.monotonic())
            msg = self.subscribe_one(topic, timeout=remaining)
            if msg is None:
                # Either still pending or the publisher closed without
                # emitting. Spin until the deadline so callers waiting
                # on a slow publisher don't get a false-empty stream.
                continue
            yield msg
            # See docstring — single emit per invocation under the
            # current wire.
            break

    def rpc(self, *args: Any, _timeout: float = 5.0, **kwargs: Any) -> dict[str, Any] | None:
        """zaku-style synchronous RPC. Add a payload, wait for one
        response on the matching `_request_id` topic.

        Equivalent to::

            topic = self.add({"_args": args, **kwargs})
            return self.subscribe_one(topic, timeout=_timeout)
        """
        topic = self.add({"_args": list(args), **kwargs})
        return self.subscribe_one(topic, timeout=_timeout)

    def rpc_stream(
        self,
        *args: Any,
        _timeout: float = 5.0,
        **kwargs: Any,
    ) -> Iterator[dict[str, Any]]:
        """zaku-style streaming RPC. Returns a generator over the
        per-topic publishes."""
        topic = self.add({"_args": list(args), **kwargs})
        return self.subscribe_stream(topic, timeout=_timeout)

    def rpc_future(
        self,
        *args: Any,
        _timeout: float = 30.0,
        **kwargs: Any,
    ) -> "QueueFuture":
        """Non-blocking variant — returns a :class:`QueueFuture` you
        can `.get()` or `await` later. Used by gather()-style fan-out.
        """
        topic = self.add({"_args": list(args), **kwargs})
        return QueueFuture(self, topic, timeout=_timeout)

    def __repr__(self) -> str:
        return f"<udf.Queue {self.name!r} mode={self.mode!r}>"


class Pool(Queue):
    """A Queue with a fixed-size worker set. Equivalent to
    `Queue(..., min_hosts=size, max_hosts=size, policy='manual')`."""

    def __init__(
        self,
        *,
        mode: str | None = None,
        size: int = 1,
        name: str | None = None,
        server: str | None = None,
    ):
        from ulid import ULID

        super().__init__(
            name or f"pool-{ULID()}",
            mode=mode,
            min_hosts=size,
            max_hosts=size,
            policy="manual",
            server=server,
        )
        self.size = size

    def __repr__(self) -> str:
        return f"<udf.Pool size={self.size} mode={self.mode!r} name={self.name!r}>"


# ─── Typed queue subclasses ─────────────────────────────────────────
#
# Sugar over Queue(name, kind="…"). They pin a `kind` on the wire and
# expose only the kwargs that mean anything for that kind. The base
# class still works for power users who want to mix kinds or pass
# arbitrary kindParams.
#
# Inheritance is intentional — `isinstance(q, Queue)` returns True for
# every subclass, so downstream code that takes a `Queue` parameter
# accepts a `PriorityQueue`, `BoltzmannQueue`, or `FILOQueue` without
# any type-narrowing.


class PriorityQueue(Queue):
    """A Queue that dispatches the highest-priority job first.

    Jobs carry a numeric priority on submit (default 0). Higher = first.
    The optional ``priority_field`` selects which key on the job payload
    holds the priority — useful when wrapping an existing schema that
    already names it something other than ``"priority"``.

    Wire shape: ``kind="priority"``, ``kindParams = {"priority_field": …}``.
    """

    def __init__(
        self,
        name: str,
        *,
        priority_field: str = "priority",
        **kwargs: Any,
    ):
        params = {"priority_field": priority_field}
        super().__init__(name, kind="priority", kind_params=params, **kwargs)

    def __repr__(self) -> str:
        return f"<PriorityQueue {self.name!r}>"


class BoltzmannQueue(PriorityQueue):
    """A PriorityQueue with Boltzmann sampling at temperature ``T``.

    Instead of strict argmax over priority, the dispatcher samples
    proportional to ``exp(priority / T)``. ``T → 0`` collapses to the
    PriorityQueue behaviour; ``T → ∞`` approaches uniform random.

    Optional ``anneal`` schedule lets the temperature decay over time —
    a dict ``{kind: "linear" | "exp", to: <float>, steps: <int>}`` that
    the dispatcher consumes. Both fields opaque-JSON on the wire today;
    the dispatcher will interpret them in a later phase.

    Wire shape: ``kind="boltzmann"``,
    ``kindParams = {"temperature": T, "priority_field": …, "anneal": …}``.
    """

    def __init__(
        self,
        name: str,
        *,
        temperature: float = 1.0,
        priority_field: str = "priority",
        anneal: dict[str, Any] | None = None,
        **kwargs: Any,
    ):
        params: dict[str, Any] = {
            "temperature": temperature,
            "priority_field": priority_field,
        }
        if anneal is not None:
            params["anneal"] = anneal
        # Bypass PriorityQueue.__init__ to set our own kind + kindParams.
        Queue.__init__(self, name, kind="boltzmann", kind_params=params, **kwargs)
        self.temperature = temperature

    def __repr__(self) -> str:
        return f"<BoltzmannQueue {self.name!r} T={self.temperature}>"


class FILOQueue(Queue):
    """A Queue that dispatches the most-recently-submitted job first.

    Useful when only the latest request matters (autocomplete, live
    preview, debounce-style workloads) — older queued requests get
    superseded but stay around for retry in case the runner crashes.

    Wire shape: ``kind="filo"``.
    """

    def __init__(self, name: str, **kwargs: Any):
        super().__init__(name, kind="filo", **kwargs)

    def __repr__(self) -> str:
        return f"<FILOQueue {self.name!r}>"
