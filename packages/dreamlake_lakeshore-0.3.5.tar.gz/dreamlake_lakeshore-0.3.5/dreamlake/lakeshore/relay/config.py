"""Bootstrap configuration for the UDF relay.

Read once at launch. Live updates arrive from the control plane on the
upstream channel and are held in memory only.

The relay is a transparent HTTPS forwarder. It binds a TLS endpoint
that compute-node daemons treat as the control plane; each incoming
request is forwarded to the real upstream control plane. The relay
does not parse the msgpack body — it stays protocol-version-agnostic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import tomllib  # py311+
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore


DEFAULT_CONFIG_PATHS = (
    Path("/etc/dreamlake/udf-relay.toml"),
    Path.home() / ".config" / "dreamlake" / "udf-relay.toml",
)


@dataclass
class ListenConfig:
    # Address daemons in the cluster will connect to. Bind on the
    # cluster's internal interface, not 0.0.0.0, so the relay is not
    # reachable from outside.
    bind: str = "0.0.0.0"
    port: int = 8443
    # TLS material. The relay terminates TLS so daemons can verify it
    # the same way they would verify the control plane.
    tls_cert: str = "/etc/dreamlake/relay.crt"
    tls_key: str = "/etc/dreamlake/relay.key"


@dataclass
class UpstreamConfig:
    url: str = "https://compute.dreamlake.ai"
    # Relay's own bootstrap token. Daemons each carry their own token
    # in the Authorization header, which is passed through unchanged.
    token_file: str = "~/.config/dreamlake/relay.token"
    tls_verify: bool = True


@dataclass
class WireConfig:
    # Encoding the relay assumes for size limits. Bodies are forwarded
    # opaquely regardless of encoding.
    encoding: str = "msgpack"
    max_payload: int = 16 * 1024 * 1024


@dataclass
class RelayConfig:
    listen: ListenConfig = field(default_factory=ListenConfig)
    upstream: UpstreamConfig = field(default_factory=UpstreamConfig)
    wire: WireConfig = field(default_factory=WireConfig)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RelayConfig":
        return cls(
            listen=ListenConfig(**data.get("listen", {})),
            upstream=UpstreamConfig(**data.get("upstream", {})),
            wire=WireConfig(**data.get("wire", {})),
        )


def load_config(path: str | Path | None = None) -> RelayConfig:
    if path is not None:
        with open(path, "rb") as f:
            return RelayConfig.from_dict(tomllib.load(f))

    for candidate in DEFAULT_CONFIG_PATHS:
        if candidate.is_file():
            with open(candidate, "rb") as f:
                return RelayConfig.from_dict(tomllib.load(f))

    return RelayConfig()
