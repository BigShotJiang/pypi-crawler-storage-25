"""UDF relay.

A login-node HTTPS forwarder for HPC-style clusters where compute
nodes can't reach the public internet directly. The relay binds a
TLS endpoint that compute-node daemons treat as the control plane;
it forwards each request unchanged to the real upstream.

If your compute nodes have direct outbound HTTPS, you do not need
this — daemons can talk to the control plane themselves.
"""

from .config import RelayConfig, load_config

__all__ = ["RelayConfig", "load_config"]
