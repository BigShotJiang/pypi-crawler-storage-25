"""S3-backed storage access via the Lakeshore control plane.

The control plane holds the long-lived AWS credentials (encrypted in
its Secret store). This module talks to the CP's ``/storages`` routes
to obtain presigned URLs or temporary STS credentials — the caller
never sees the raw secret material.

Usage::

    from dreamlake.lakeshore.storage import Storage

    store = Storage("my-bucket")
    url   = store.presign("data/train.tar.gz")          # presigned GET
    creds = store.credentials()                         # STS temp creds
    data  = store.get("data/train.tar.gz")              # download bytes
    store.put("results/out.json", b'{"loss": 0.01}')    # upload bytes
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import httpx

from .client import _resolve_server_and_token


def _make_json_client(
    base_url: str,
    token: str | None,
    timeout: float,
) -> httpx.Client:
    headers: dict[str, str] = {
        "content-type": "application/json",
        "accept": "application/json",
    }
    if token:
        headers["authorization"] = f"Bearer {token}"
    return httpx.Client(base_url=base_url, timeout=timeout, headers=headers)


@dataclass
class TemporaryCredentials:
    """STS temporary credentials returned by the control plane."""

    access_key_id: str
    secret_access_key: str
    session_token: str
    expiration: str
    region: str
    bucket: str
    prefix: str | None = None
    endpoint: str | None = None

    def to_boto3_kwargs(self) -> dict[str, Any]:
        """Return a dict suitable for ``boto3.Session(**kwargs)``."""
        out: dict[str, Any] = {
            "aws_access_key_id": self.access_key_id,
            "aws_secret_access_key": self.secret_access_key,
            "aws_session_token": self.session_token,
            "region_name": self.region,
        }
        return out

    def to_env(self) -> dict[str, str]:
        """Return a dict of environment variables for AWS CLI/SDK."""
        env = {
            "AWS_ACCESS_KEY_ID": self.access_key_id,
            "AWS_SECRET_ACCESS_KEY": self.secret_access_key,
            "AWS_SESSION_TOKEN": self.session_token,
            "AWS_REGION": self.region,
        }
        if self.endpoint:
            env["AWS_ENDPOINT_URL"] = self.endpoint
        return env


@dataclass
class Storage:
    """Handle for a registered storage entry on the control plane.

    Provides presigned-URL and temporary-credential access to the
    underlying S3 bucket without exposing long-lived secrets to the
    caller.

    Parameters
    ----------
    name
        Name of the storage entry as registered on the CP.
    base_url
        Control plane URL (default: resolved from env / auth.yml).
    namespace
        CP namespace (default: resolved from env / auth.yml).
    timeout
        HTTP timeout for CP calls in seconds.
    """

    name: str
    base_url: str | None = None
    namespace: str | None = None
    timeout: float = 30.0
    _client: httpx.Client = field(init=False, repr=False)
    _ns: str = field(init=False, repr=False)

    def __post_init__(self) -> None:
        resolved_url, resolved_ns, resolved_token = _resolve_server_and_token(
            base_url=self.base_url, namespace=self.namespace
        )
        self._ns = resolved_ns
        self._client = _make_json_client(resolved_url, resolved_token, self.timeout)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Storage:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _storage_path(self, suffix: str = "") -> str:
        return f"/v1/namespaces/{self._ns}/storages/{self.name}{suffix}"

    # ─── Presigned URLs ──────────────────────────────────────────────

    def presign(
        self,
        key: str,
        *,
        operation: str = "get",
        expires_in: int = 3600,
    ) -> str:
        """Return a presigned S3 URL for *key*.

        Parameters
        ----------
        key
            Object key relative to the storage prefix.
        operation
            ``"get"`` (download) or ``"put"`` (upload).
        expires_in
            URL lifetime in seconds (max 86400).
        """
        resp = self._client.post(
            self._storage_path("/presign"),
            json={"key": key, "operation": operation, "expiresIn": expires_in},
        )
        resp.raise_for_status()
        return resp.json()["url"]

    # ─── Temporary credentials ───────────────────────────────────────

    def credentials(
        self,
        duration_seconds: int = 3600,
    ) -> TemporaryCredentials:
        """Obtain STS temporary credentials for this storage.

        The returned :class:`TemporaryCredentials` can be passed to
        ``boto3.Session`` via :meth:`~TemporaryCredentials.to_boto3_kwargs`
        or exported as env vars via :meth:`~TemporaryCredentials.to_env`.
        """
        resp = self._client.post(
            self._storage_path("/credentials"),
            json={"durationSeconds": duration_seconds},
        )
        resp.raise_for_status()
        data = resp.json()
        return TemporaryCredentials(
            access_key_id=data["accessKeyId"],
            secret_access_key=data["secretAccessKey"],
            session_token=data["sessionToken"],
            expiration=data["expiration"],
            region=data["region"],
            bucket=data["bucket"],
            prefix=data.get("prefix"),
            endpoint=data.get("endpoint"),
        )

    # ─── Convenience: download / upload via presigned URLs ───────────

    def get(self, key: str, *, expires_in: int = 300) -> bytes:
        """Download an object and return its bytes."""
        url = self.presign(key, operation="get", expires_in=expires_in)
        resp = httpx.get(url, timeout=self.timeout)
        resp.raise_for_status()
        return resp.content

    def put(self, key: str, data: bytes, *, expires_in: int = 3600) -> None:
        """Upload bytes to an object key."""
        url = self.presign(key, operation="put", expires_in=expires_in)
        resp = httpx.put(url, content=data, timeout=self.timeout)
        resp.raise_for_status()

    def get_text(self, key: str, *, encoding: str = "utf-8") -> str:
        """Download an object and return it as a string."""
        return self.get(key).decode(encoding)

    def put_text(self, key: str, text: str, *, encoding: str = "utf-8") -> None:
        """Upload a string as an object."""
        self.put(key, text.encode(encoding))
