"""Phase D daemon-side loop — pops queue jobs, runs the embedded UDF,
publishes the result.

This is the worker-pool process that pairs with Phase D's queue-bound
``@udf`` decorator. Run it next to the controlplane::

    python -m dreamlake.lakeshore.daemon.udf_runner --queue rpc-demo

Or invoke from inside the existing ``lakeshore-daemon`` via the
``--mode udf`` flag (see ``daemon.daemon``).

The wire shape it consumes is exactly what
:class:`dreamlake.lakeshore.udf._QueueBoundUDF` enqueues — a dict with
``_fn_pickled`` / ``_args`` / ``_kwargs`` keys, plus the SDK-injected
``_request_id`` topic. The runner:

  1. Calls ``queue.take()`` to claim one job.
  2. ``cloudpickle.loads`` the function value.
  3. Runs it with the decoded args/kwargs.
  4. Calls ``queue.publish({"value": result}, topic=_request_id)`` —
     callers waiting on ``QueueFuture.get()`` see the value.
  5. On exception, publishes ``{"_error": {type, message, traceback}}``
     so the caller's ``.get()`` raises a clean RemoteError.

One loop, one queue, one in-process executor — keep the rest for the
elasticity controller in Phase B / D.5.
"""

from __future__ import annotations

import logging
import time
import traceback
from typing import Any

import cloudpickle
from params_proto import proto

log = logging.getLogger("dreamlake.lakeshore.daemon.udf_runner")


def run_one_job(queue: Any, payload: dict[str, Any]) -> None:
    """Execute a single popped job. Best-effort: any exception inside
    the user function is captured + published as a structured error so
    the caller's QueueFuture.get() raises a clean RuntimeError."""
    topic = payload.get("_request_id")
    if not topic:
        log.warning("dropping job with no _request_id; payload=%r", payload)
        return
    fn_pickled = payload.get("_fn_pickled")
    args = payload.get("_args") or []
    kwargs = payload.get("_kwargs") or {}
    if fn_pickled:
        try:
            fn = cloudpickle.loads(fn_pickled)
        except Exception as e:
            log.exception("failed to cloudpickle.loads fn for topic=%s", topic)
            queue.publish(
                {
                    "_error": {
                        "type": type(e).__name__,
                        "message": f"cloudpickle.loads failed: {e}",
                        "traceback": traceback.format_exc(),
                    }
                },
                topic=topic,
            )
            return
        try:
            result = fn(*args, **kwargs)
        except Exception as e:
            log.exception("user fn raised for topic=%s", topic)
            queue.publish(
                {
                    "_error": {
                        "type": type(e).__name__,
                        "message": str(e),
                        "traceback": traceback.format_exc(),
                    }
                },
                topic=topic,
            )
            return
        # If the user function already returned a dict, publish it
        # verbatim (zaku convention). Otherwise wrap under "value" so
        # the wire is always a dict.
        if isinstance(result, dict):
            queue.publish(result, topic=topic)
        else:
            queue.publish({"value": result}, topic=topic)
    else:
        # Raw zaku-style payload — no callable. Echo it back wrapped
        # under "received" so the caller's RPC pair completes. This
        # path lets ``Queue.rpc`` work against a worker that has no
        # registered function — useful for trivial smoke tests.
        echo = {k: v for k, v in payload.items() if not k.startswith("_")}
        queue.publish({"received": echo}, topic=topic)


def main_loop(queue_obj: Any, *, idle_sleep_s: float = 0.5) -> None:
    """Forever-loop: pop one job, run it, publish, repeat."""
    log.info("udf_runner attached to queue=%r", queue_obj.name)
    backoff = 1.0
    while True:
        try:
            payload = queue_obj.take(timeout_s=30.0)
        except Exception as e:
            log.warning("take() failed: %s — retrying in %.1fs", e, backoff)
            time.sleep(backoff)
            backoff = min(backoff * 2, 30.0)
            continue
        backoff = 1.0
        if payload is None:
            # Nothing claimed in the wait window. Pause briefly so we
            # don't hammer the CP under sustained idle.
            time.sleep(idle_sleep_s)
            continue
        run_one_job(queue_obj, payload)


@proto.cli(prog="lakeshore-udf-worker")
def main(
    queue: str = "default",
    server: str = None,
    log_level: str = "INFO",
) -> None:
    """Run a worker that pops jobs from one queue and runs the embedded UDF.

    Args:
        queue: Queue name to attach to. Must match the @udf(queue=...) name
            used by clients submitting work.
        server: Control-plane base URL. When omitted, resolved from
            LAKESHORE_URL env, DREAMLAKE_SERVER env,
            ~/.config/lakeshore/auth.yml, or http://localhost:8080
            (first one wins, in that order).
        log_level: Python log level — DEBUG, INFO, WARNING, ERROR.
    """
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    # Local import — keeps the module importable without the package
    # __init__'s side effects when tests stub the queue out.
    from ..queue import Queue

    # Pass `server=server` (may be None) so Queue/ControlPlaneClient
    # runs the full env + auth.yml resolution chain (mirrors the CLI).
    # The token comes from LAKESHORE_TOKEN env or auth.yml — never
    # hard-coded.
    q = Queue(queue, server=server)
    log.info(
        "udf_runner attached to queue=%r server=%s",
        q.name,
        q._client.base_url,
    )
    main_loop(q)


if __name__ == "__main__":
    main()
