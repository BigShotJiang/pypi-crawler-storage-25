"""In-sandbox entrypoint for one Invocation.

The daemon (manager process, on the host) prepares a workdir per
Invocation:

    /var/lib/dreamlake/<invocation_id>/
      entry.py        <- this file, copied per invocation
      args.msgpack    <- {fn_pickled, args, kwargs} written by the daemon
      result.msgpack  <- written by this script on success
      error.json      <- written by this script on failure
      events.jsonl    <- one JSON line per dls.run.emit/log/progress call;
                         the daemon tails this and forwards to Lakeshore

Then the daemon launches a container (runsc / docker / a bare subprocess
in `runner: subprocess` mode) and invokes `python /work/entry.py`. The
sandbox sees only this directory; the daemon mediates all I/O.

No imports from dreamlake.lakeshore.* unless dls.run is needed inside
the function body — that's still resolved via cloudpickle's globals.
"""

from __future__ import annotations

import json
import os
import sys
import traceback
from pathlib import Path
from typing import Any

import cloudpickle
import msgpack


WORKDIR = Path(os.environ.get("DREAMLAKE_WORKDIR", Path(__file__).parent))


def _install_event_sink(invocation_id: str, parent_id: str | None, root_id: str | None) -> None:
    """Wire `dls.run.emit/log/progress` to write to events.jsonl.

    The daemon tails the file and forwards lines as POSTs to
    /v1/daemon/event. Sandbox never talks to Lakeshore directly."""
    try:
        from dreamlake.lakeshore.decorator import RunContext, run as run_proxy
    except ImportError:
        return  # dls isn't installed in the sandbox; UDF code can't use dls.run

    events_path = WORKDIR / "events.jsonl"

    def sink(kind: str, body: dict[str, Any]) -> None:
        line = json.dumps({"kind": kind, "body": body, "invocation_id": invocation_id})
        with open(events_path, "a") as f:
            f.write(line + "\n")
            f.flush()

    ctx = RunContext(
        id=invocation_id,
        event_sink=sink,
        parent_id=parent_id,
        root_id=root_id,
    )
    run_proxy._set(ctx)


def main() -> int:
    invocation_id = os.environ.get("DREAMLAKE_INVOCATION_ID", "unknown")
    parent_id = os.environ.get("DREAMLAKE_PARENT_INVOCATION_ID") or None
    root_id = os.environ.get("DREAMLAKE_ROOT_INVOCATION_ID") or None

    _install_event_sink(invocation_id, parent_id, root_id)

    with open(WORKDIR / "args.msgpack", "rb") as f:
        payload = msgpack.unpackb(f.read(), raw=False)

    fn = cloudpickle.loads(payload.get("_fn_pickled") or payload["fn_pickled"])
    args = payload.get("_args") or payload.get("args") or []
    kwargs = payload.get("_kwargs") or payload.get("kwargs") or {}

    try:
        import asyncio
        import inspect

        if inspect.iscoroutinefunction(fn):
            result = asyncio.run(fn(*args, **kwargs))
        else:
            result = fn(*args, **kwargs)
    except Exception as e:
        with open(WORKDIR / "error.json", "w") as f:
            json.dump(
                {
                    "type": type(e).__name__,
                    "message": str(e),
                    "traceback": traceback.format_exc(),
                },
                f,
            )
        return 1

    with open(WORKDIR / "result.msgpack", "wb") as f:
        f.write(msgpack.packb(result, use_bin_type=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
