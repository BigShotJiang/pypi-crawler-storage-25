"""UDF host daemon.

The daemon is a long-running process on a compute host. It opens a
long-polled, msgpack-encoded connection to the upstream control plane and
executes whatever the server asks it to: `run`, `kill`, `list`. The daemon
itself never accepts inbound connections and never re-reads its on-disk
config — live configuration is delivered by the connected server through
the same poll channel.
"""

from .config import DaemonConfig, load_config

__all__ = ["DaemonConfig", "load_config"]
