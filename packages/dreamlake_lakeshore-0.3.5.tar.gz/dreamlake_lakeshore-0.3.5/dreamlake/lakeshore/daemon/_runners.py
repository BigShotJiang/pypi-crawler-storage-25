"""Runner strategies — one per `mode.runner` value.

Each strategy implements the same contract:

    run(invocation_id, args_blob, client, parent_id, root_id) ->
        ("succeeded" | "failed", result_blob | None, error_dict | None)

The daemon's main loop pulls a run command from Lakeshore, picks a
runner based on the envelope's `run_config.runner`, and dispatches.

Strategies:
  - `process`    — execute the UDF in the daemon's own Python process.
                   Fastest, no isolation. v0 default.
  - `subprocess` — fork+exec entry.py in a child process with a fresh
                   workdir. Isolates the UDF's globals/imports from the
                   daemon, but shares the host's kernel.
  - `gvisor`     — wrap the subprocess invocation in `runsc run`. Real
                   sandbox; needed for BYOM and any cross-tenant work.

The `subprocess` and `gvisor` strategies share workdir-construction and
event-forwarding code; only the exec command differs."""

from __future__ import annotations

import asyncio
import inspect
import json
import os
import shutil
import subprocess
import sys
import threading
import traceback
from pathlib import Path
from typing import Any

import cloudpickle
import msgpack

from ..client import ControlPlaneClient
from ..decorator import RunContext, run as _run_proxy


Outcome = tuple[str, bytes | None, dict[str, Any] | None]


# ─── In-process runner (today's default) ─────────────────────────────


def run_in_process(
    invocation_id: str,
    args_blob: bytes,
    client: ControlPlaneClient,
    parent_id: str | None,
    root_id: str | None,
) -> Outcome:
    payload = msgpack.unpackb(args_blob, raw=False)
    fn = cloudpickle.loads(payload["fn_pickled"])
    args = payload.get("args", []) or []
    kwargs = payload.get("kwargs", {}) or {}

    def sink(kind: str, body: dict[str, Any]) -> None:
        client.event(invocation_id, kind, body)

    ctx = RunContext(
        id=invocation_id,
        event_sink=sink,
        parent_id=parent_id,
        root_id=root_id,
    )
    token = _run_proxy._set(ctx)
    try:
        if inspect.iscoroutinefunction(fn):
            result = asyncio.run(fn(*args, **kwargs))
        else:
            result = fn(*args, **kwargs)
        return "succeeded", msgpack.packb(result, use_bin_type=True), None
    except Exception as e:
        return (
            "failed",
            None,
            {
                "type": type(e).__name__,
                "message": str(e),
                "traceback": traceback.format_exc(),
            },
        )
    finally:
        _run_proxy._reset(token)


# ─── Subprocess / gVisor runners (share the workdir contract) ────────


DAEMON_WORKDIR_ROOT = Path(os.environ.get("DREAMLAKE_WORKDIR_ROOT", "/tmp/dreamlake-udf"))


def _entry_py_path() -> Path:
    from . import entry  # noqa: F401 — ensure module is locatable

    return Path(entry.__file__).resolve()


def _forward_events_until(workdir: Path, invocation_id: str, client: ControlPlaneClient, stop: threading.Event) -> None:
    """Tail workdir/events.jsonl and POST each line to /v1/daemon/event.

    Stops when `stop` is set AND the file has no more bytes to read.
    Runs in a background thread the runner spawns."""
    events_path = workdir / "events.jsonl"
    pos = 0
    while True:
        if events_path.exists():
            with open(events_path, "rb") as f:
                f.seek(pos)
                chunk = f.read()
                pos = f.tell()
            for line in chunk.splitlines():
                if not line.strip():
                    continue
                try:
                    rec = json.loads(line)
                    client.event(invocation_id, rec["kind"], rec.get("body", {}))
                except Exception:
                    pass
        if stop.is_set():
            return
        stop.wait(0.1)


def _prepare_workdir(invocation_id: str, args_blob: bytes) -> Path:
    workdir = DAEMON_WORKDIR_ROOT / invocation_id
    workdir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(_entry_py_path(), workdir / "entry.py")
    (workdir / "args.msgpack").write_bytes(args_blob)
    return workdir


def _read_outcome(workdir: Path, exit_code: int) -> Outcome:
    if exit_code == 0 and (workdir / "result.msgpack").exists():
        return "succeeded", (workdir / "result.msgpack").read_bytes(), None
    err_path = workdir / "error.json"
    if err_path.exists():
        try:
            err = json.loads(err_path.read_text())
            return "failed", None, err
        except Exception:
            pass
    return "failed", None, {
        "type": "RunnerError",
        "message": f"entry.py exited {exit_code} without result.msgpack or error.json",
        "traceback": "",
    }


def _spawn_with_workdir(
    invocation_id: str,
    args_blob: bytes,
    client: ControlPlaneClient,
    parent_id: str | None,
    root_id: str | None,
    cmd_builder,
) -> Outcome:
    """Common path for subprocess / gvisor / docker: prepare workdir,
    spawn the entry.py via `cmd_builder(workdir)`, forward events,
    collect the outcome, clean up."""
    workdir = _prepare_workdir(invocation_id, args_blob)
    stop = threading.Event()
    forwarder = threading.Thread(
        target=_forward_events_until,
        args=(workdir, invocation_id, client, stop),
        daemon=True,
    )
    forwarder.start()

    env = os.environ.copy()
    env["DREAMLAKE_WORKDIR"] = str(workdir)
    env["DREAMLAKE_INVOCATION_ID"] = invocation_id
    if parent_id:
        env["DREAMLAKE_PARENT_INVOCATION_ID"] = parent_id
    if root_id:
        env["DREAMLAKE_ROOT_INVOCATION_ID"] = root_id

    cmd = cmd_builder(workdir)
    try:
        proc = subprocess.run(cmd, env=env, cwd=str(workdir))
        exit_code = proc.returncode
    except Exception as e:
        exit_code = -1
        # fall through to _read_outcome which surfaces the missing-result case
    finally:
        stop.set()
        forwarder.join(timeout=2)

    outcome = _read_outcome(workdir, exit_code)
    # leave the workdir on failure for inspection; clear on success
    if outcome[0] == "succeeded":
        try:
            shutil.rmtree(workdir)
        except Exception:
            pass
    return outcome


def run_in_subprocess(
    invocation_id: str,
    args_blob: bytes,
    client: ControlPlaneClient,
    parent_id: str | None,
    root_id: str | None,
) -> Outcome:
    """Run entry.py in a fresh Python subprocess. No sandbox — same
    kernel, same user. Useful to validate the workdir contract without
    needing gVisor installed."""
    return _spawn_with_workdir(
        invocation_id,
        args_blob,
        client,
        parent_id,
        root_id,
        cmd_builder=lambda wd: [sys.executable, str(wd / "entry.py")],
    )


def run_in_gvisor(
    invocation_id: str,
    args_blob: bytes,
    client: ControlPlaneClient,
    parent_id: str | None,
    root_id: str | None,
    runsc_binary: str = "/usr/local/bin/runsc",
) -> Outcome:
    """Run entry.py inside a gVisor sandbox via `runsc run`.

    Requires gVisor installed on the host. For BYOM and untrusted
    workloads. The OCI spec is built on the fly from the workdir."""
    # NOTE: simplified — a real impl builds an OCI bundle (config.json
    # + rootfs) referencing a Python image, mounts the workdir, and
    # invokes `runsc run --bundle <bundle> <invocation_id>`. v0 stub:
    raise NotImplementedError(
        "run_in_gvisor: build an OCI bundle + invoke runsc. "
        "See https://gvisor.dev/docs/user_guide/quick_start/oci/"
    )


# ─── Dispatcher ──────────────────────────────────────────────────────


RUNNERS = {
    "process": run_in_process,
    "subprocess": run_in_subprocess,
    "gvisor": run_in_gvisor,
}


def dispatch(
    runner: str,
    invocation_id: str,
    args_blob: bytes,
    client: ControlPlaneClient,
    parent_id: str | None,
    root_id: str | None,
) -> Outcome:
    impl = RUNNERS.get(runner)
    if impl is None:
        return (
            "failed",
            None,
            {
                "type": "RunnerError",
                "message": f"unknown runner: {runner!r}; available: {sorted(RUNNERS)}",
                "traceback": "",
            },
        )
    return impl(invocation_id, args_blob, client, parent_id, root_id)
