"""Bootstrap configuration for the UDF daemon.

Loaded once at process launch. After launch, the on-disk file is never
re-read; any live updates arrive from the connected server over the
long-poll channel and live in-memory only.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import tomllib  # py311+
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore


DEFAULT_CONFIG_PATHS = (
    Path("/etc/dreamlake/udf-daemon.toml"),
    Path.home() / ".config" / "dreamlake" / "udf-daemon.toml",
)


@dataclass
class ServerConfig:
    # Transport. One of:
    #   "https" — msgpack-over-HTTPS long-poll to `url`. Standard path.
    #             For HPC clusters with blocked egress, set `url` to a
    #             login-node relay endpoint.
    #   "unix"  — bind a local SOCK_STREAM at `socket_path`. Niche:
    #             local IPC for parent-process / in-container setups
    #             that wrap a per-Invocation daemon. NOT the relay.
    transport: str = "https"
    url: str = "https://compute.dreamlake.ai"
    socket_path: str = "/var/run/dreamlake/udf-daemon.sock"
    token_file: str = "~/.config/dreamlake/daemon.token"
    tls_verify: bool = True


@dataclass
class RunnerConfig:
    """Per-runner knobs. Empty objects when the runner has no config."""

    docker_socket: str = "/var/run/docker.sock"
    gvisor_binary: str = "/usr/local/bin/runsc"


@dataclass
class DaemonIdentity:
    machine_id: str = "auto"
    label: str = ""
    tags: list[str] = field(default_factory=list)


@dataclass
class RuntimeConfig:
    workdir: str = "/var/lib/dreamlake/udf"
    max_invocations: int = 4
    default_image: str = "python:3.12-slim"
    # Execution sandboxes this daemon offers. Advertised to the control
    # plane at /hello; the scheduler only routes Invocations whose mode
    # requires one of these.
    #   "docker"  — `docker run` with image + env + mounts
    #   "gvisor"  — same as docker but with --runtime=runsc
    #   "process" — bare subprocess, no isolation
    runners: list[str] = field(default_factory=lambda: ["docker", "process"])
    default_runner: str = "docker"
    runner: RunnerConfig = field(default_factory=RunnerConfig)


@dataclass
class PollConfig:
    timeout_s: int = 60
    retry_min_s: float = 1.0
    retry_max_s: float = 30.0


@dataclass
class MetricsConfig:
    report_interval_s: int = 5
    include: list[str] = field(default_factory=lambda: ["cpu", "memory", "disk"])


@dataclass
class WireConfig:
    encoding: str = "msgpack"
    max_payload: int = 16 * 1024 * 1024


@dataclass
class DaemonConfig:
    server: ServerConfig = field(default_factory=ServerConfig)
    daemon: DaemonIdentity = field(default_factory=DaemonIdentity)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)
    poll: PollConfig = field(default_factory=PollConfig)
    metrics: MetricsConfig = field(default_factory=MetricsConfig)
    wire: WireConfig = field(default_factory=WireConfig)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DaemonConfig":
        runtime_data = dict(data.get("runtime", {}))
        runner_data = runtime_data.pop("runner", {})
        return cls(
            server=ServerConfig(**data.get("server", {})),
            daemon=DaemonIdentity(**data.get("daemon", {})),
            runtime=RuntimeConfig(runner=RunnerConfig(**runner_data), **runtime_data),
            poll=PollConfig(**data.get("poll", {})),
            metrics=MetricsConfig(**data.get("metrics", {})),
            wire=WireConfig(**data.get("wire", {})),
        )


def load_config(path: str | Path | None = None) -> DaemonConfig:
    if path is not None:
        with open(path, "rb") as f:
            return DaemonConfig.from_dict(tomllib.load(f))

    for candidate in DEFAULT_CONFIG_PATHS:
        if candidate.is_file():
            with open(candidate, "rb") as f:
                return DaemonConfig.from_dict(tomllib.load(f))

    return DaemonConfig()
