"""Daemon — manager process.

Long-polls Lakeshore, picks up `run` commands, dispatches each
invocation through a runner strategy (process / subprocess / gvisor)
in `_runners.py`, then acks the result. The daemon itself doesn't
execute UDF code in `subprocess` / `gvisor` modes — those spawn a
child process with the workdir contract (`entry.py`).
"""

from __future__ import annotations

import logging
import socket
import time

from params_proto import proto
from ulid import ULID

from ..client import ControlPlaneClient
from ._runners import dispatch

log = logging.getLogger("dreamlake.lakeshore.daemon")


def main_loop(server: str, worker_id: str, queue_name: str, default_runner: str) -> None:
    log.info(
        "daemon starting; worker_id=%s server=%s queue=%s default_runner=%s",
        worker_id, server, queue_name, default_runner,
    )
    backoff_s = 1.0
    with ControlPlaneClient(base_url=server, timeout=600.0) as client:
        while True:
            try:
                resp = client.poll(worker_id, timeout_s=30.0, queue=queue_name)
                backoff_s = 1.0
            except Exception as e:
                log.warning("poll failed: %s — retrying in %.1fs", e, backoff_s)
                time.sleep(backoff_s)
                backoff_s = min(backoff_s * 2, 30.0)
                continue

            for cmd in resp.get("commands", []):
                if cmd.get("kind") != "run":
                    log.warning("ignoring unknown command kind=%s", cmd.get("kind"))
                    continue
                body = cmd["body"]
                inv_id = body["invocation_id"]
                fn_meta = body.get("function", {})
                run_config = body.get("run_config") or {}
                runner = run_config.get("runner") or default_runner
                log.info(
                    "executing invocation_id=%s function=%s.%s runner=%s",
                    inv_id, fn_meta.get("module"), fn_meta.get("qualname"), runner,
                )
                state, result_blob, error = dispatch(
                    runner,
                    inv_id,
                    body["args_blob"],
                    client,
                    parent_id=body.get("parent_invocation_id"),
                    root_id=body.get("root_invocation_id"),
                )
                try:
                    client.ack(inv_id, state=state, result_blob=result_blob, error=error)
                    log.info("acked invocation_id=%s state=%s", inv_id, state)
                except Exception as e:
                    log.error("ack failed for invocation_id=%s: %s", inv_id, e)


@proto.cli(prog="lakeshore-daemon")
def main(
    server: str = None,
    queue: str = "default",
    runner: str = "process",
    worker_id: str = None,
    log_level: str = "INFO",
) -> None:
    """Start a Lakeshore daemon — a long-running worker that polls a queue.

    Args:
        server: Control-plane base URL. When omitted, resolved from
            LAKESHORE_URL env, DREAMLAKE_SERVER env,
            ~/.config/lakeshore/auth.yml, or http://localhost:8080
            (first one wins, in that order).
        queue: Queue this daemon attaches to. Trailing '*' subscribes to a
            prefix — '--queue train/*' consumes from any queue whose name
            starts with 'train/'.
        runner: Default sandbox for UDFs that don't pin one. 'process' runs
            in-daemon (fastest, no isolation). 'subprocess' spawns a fresh
            Python child per invocation. 'gvisor' uses runsc (requires
            gVisor installed).
        worker_id: Override the auto-generated worker id. Default is
            '<hostname>-<ulid>'.
        log_level: Python log level — DEBUG, INFO, WARNING, ERROR.
    """
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    wid = worker_id or f"{socket.gethostname()}-{ULID()}"
    # server=None triggers the resolution chain in ControlPlaneClient.
    main_loop(server, wid, queue, runner)


if __name__ == "__main__":
    main()
