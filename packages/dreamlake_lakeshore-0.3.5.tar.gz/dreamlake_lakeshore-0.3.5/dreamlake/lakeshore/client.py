"""HTTP+msgpack client for the control plane.

v0 surface: submit, await, poll, ack. Pure synchronous httpx for now;
the async future-aware variant can wrap this without changing the wire.

The daemon-list endpoints (``/v1/namespaces/:ns/workers``) speak plain
JSON, not msgpack — they share the content-type contract used by the
control plane's CRUD surfaces. We route those through a separate
``_get_json`` helper rather than swap headers on the shared client.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import msgpack
import yaml


# Mirrors the CLI's resolution chain (lakeshore/src/cli/server.ts):
#   1. Explicit `base_url=` kwarg → use it; token from LAKESHORE_TOKEN env.
#   2. LAKESHORE_URL env override → token from LAKESHORE_TOKEN env (NO
#      auth.yml fall-through, matching CLI: "if you explicitly set the
#      URL, you're in dev mode against a no-auth CP").
#   3. DREAMLAKE_SERVER env (legacy alias) → same shape as #2.
#   4. ~/.config/lakeshore/auth.yml → server + token + namespace.
#   5. Fallback: http://localhost:8080, no token (OPEN MODE dev).
def _resolve_server_and_token(
    base_url: str | None,
    namespace: str | None,
) -> tuple[str, str, str | None]:
    env_token = os.environ.get("LAKESHORE_TOKEN") or None
    if base_url:
        return base_url.rstrip("/"), namespace or "default", env_token
    env_url = os.environ.get("LAKESHORE_URL") or os.environ.get("DREAMLAKE_SERVER")
    if env_url:
        return (
            env_url.rstrip("/"),
            namespace or os.environ.get("LAKESHORE_NAMESPACE") or "default",
            env_token,
        )
    auth_path = Path.home() / ".config" / "lakeshore" / "auth.yml"
    if auth_path.is_file():
        try:
            doc = yaml.safe_load(auth_path.read_text()) or {}
            server = (doc.get("server") or "").rstrip("/")
            if server:
                return (
                    server,
                    namespace or doc.get("namespace") or "default",
                    env_token or doc.get("token") or None,
                )
        except Exception:
            pass  # malformed auth.yml — fall through to defaults
    return "http://localhost:8080", namespace or "default", env_token


@dataclass
class Daemon:
    """One row from ``GET /v1/namespaces/:ns/workers``.

    Mirrors the JSON shape the control plane returns. ``label`` and
    ``hostname`` are nullable in the API; we keep them as ``None`` when
    the row omits or null-sets them.
    """

    id: str
    machine_id: str
    state: str
    tags: list[str]
    runners: list[str]
    last_seen_at: str  # ISO 8601
    label: str | None = None
    hostname: str | None = None
    capabilities: Any = None
    created_at: str | None = None


def _unmarshal_daemon(row: dict[str, Any]) -> dict[str, Any]:
    """Translate one API row into ``Daemon`` constructor kwargs.

    The wire format uses camelCase (``machineId``, ``lastSeenAt``); the
    dataclass uses snake_case. Unknown fields are ignored so the client
    doesn't break when the server grows extra columns.
    """
    return {
        "id": row["id"],
        "machine_id": row["machineId"],
        "state": row["state"],
        "tags": list(row.get("tags") or []),
        "runners": list(row.get("runners") or []),
        "last_seen_at": row["lastSeenAt"],
        "label": row.get("label"),
        "hostname": row.get("hostname"),
        "capabilities": row.get("capabilities"),
        "created_at": row.get("createdAt"),
    }


class ControlPlaneClient:
    def __init__(
        self,
        base_url: str | None = None,
        timeout: float = 600.0,
        namespace: str | None = None,
        token: str | None = None,
    ):
        resolved_url, resolved_ns, resolved_token = _resolve_server_and_token(
            base_url=base_url, namespace=namespace
        )
        self.base_url = resolved_url
        self._ns = resolved_ns
        self._token = token or resolved_token
        headers = {
            "content-type": "application/x-msgpack",
            "accept": "application/x-msgpack",
        }
        if self._token:
            headers["authorization"] = f"Bearer {self._token}"
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=headers,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "ControlPlaneClient":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        resp = self._client.post(path, content=msgpack.packb(body, use_bin_type=True))
        resp.raise_for_status()
        return msgpack.unpackb(resp.content, raw=False)

    def _get_json(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        # The daemon-list routes are JSON, not msgpack — explicitly
        # override the msgpack headers for this one call.
        resp = self._client.get(
            path,
            params=params,
            headers={"accept": "application/json"},
        )
        resp.raise_for_status()
        return resp.json()

    def submit(self, envelope: dict[str, Any]) -> str:
        out = self._post("/v1/producer/submit", envelope)
        return out["invocation_id"]

    def ensure_queue(
        self,
        name: str,
        *,
        mode: str | None = None,
        min_hosts: int | None = None,
        max_hosts: int | None = None,
        policy: str | None = None,
        idle_timeout_s: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name}
        if mode is not None:
            body["mode"] = mode
        if min_hosts is not None:
            body["min_hosts"] = min_hosts
        if max_hosts is not None:
            body["max_hosts"] = max_hosts
        if policy is not None:
            body["policy"] = policy
        if idle_timeout_s is not None:
            body["idle_timeout_s"] = idle_timeout_s
        resp = self._client.put(
            "/v1/producer/queues",
            content=msgpack.packb(body, use_bin_type=True),
        )
        resp.raise_for_status()
        return msgpack.unpackb(resp.content, raw=False)

    def upsert_queue_crud(
        self,
        name: str,
        *,
        kind: str | None = None,
        kind_params: dict[str, Any] | None = None,
        elasticity: dict[str, Any] | None = None,
        provider_ref: str | None = None,
        daemon_template: dict[str, Any] | None = None,
        admission: dict[str, Any] | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        """Idempotent upsert against the Phase A.5 namespaced CRUD route.

        Tries ``POST /v1/namespaces/<ns>/queues`` first; on 409 (already
        exists) PATCHes the row. Returns the queue summary. JSON, not
        msgpack — these routes mirror ``/lanes``. Used by the public
        :class:`Queue` SDK so the user-facing constructor can pass
        kind/elasticity/provider/daemon_template knobs through to the
        modern surface rather than the legacy producer/queues upsert
        (which is a thin name-only no-op as of Phase A.5).
        """
        path = f"/v1/namespaces/{self._ns}/queues"
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        if kind is not None:
            body["kind"] = kind
        if kind_params is not None:
            body["kindParams"] = kind_params
        if elasticity is not None:
            body["elasticity"] = elasticity
        if provider_ref is not None:
            body["providerRef"] = provider_ref
        if daemon_template is not None:
            body["daemonTemplate"] = daemon_template
        if admission is not None:
            body["admission"] = admission
        # CRUD routes are JSON — override the msgpack headers for this
        # call.
        resp = self._client.post(
            path,
            json=body,
            headers={
                "accept": "application/json",
                "content-type": "application/json",
            },
        )
        if resp.status_code == 409:
            # Already exists — PATCH the patchable fields. `kind` /
            # `name` are immutable post-creation on the CP, so we drop
            # them from the patch body.
            patch_body = {k: v for k, v in body.items() if k not in ("name", "kind")}
            if not patch_body:
                # Nothing to update — fetch and return.
                show = self._client.get(
                    f"{path}/{name}",
                    headers={"accept": "application/json"},
                )
                show.raise_for_status()
                return show.json()
            patched = self._client.patch(
                f"{path}/{name}",
                json=patch_body,
                headers={
                    "accept": "application/json",
                    "content-type": "application/json",
                },
            )
            patched.raise_for_status()
            return patched.json()
        resp.raise_for_status()
        return resp.json()

    def await_result(self, invocation_id: str, timeout_s: float = 60.0) -> dict[str, Any]:
        return self._post(
            "/v1/producer/await",
            {"invocation_id": invocation_id, "timeout_s": timeout_s},
        )

    def poll(
        self,
        worker_id: str,
        timeout_s: float = 30.0,
        queue: str = "default",
    ) -> dict[str, Any]:
        return self._post(
            "/v1/daemon/poll",
            {"worker_id": worker_id, "timeout_s": timeout_s, "queue": queue},
        )

    def ack(
        self,
        invocation_id: str,
        state: str,
        result_blob: bytes | None = None,
        error: dict[str, Any] | None = None,
    ) -> None:
        self._post(
            "/v1/daemon/ack",
            {
                "invocation_id": invocation_id,
                "state": state,
                "result_blob": result_blob,
                "error": error,
            },
        )

    def event(self, invocation_id: str, kind: str, body: dict[str, Any]) -> None:
        """Emit one Invocation event (progress / log / user-defined)."""
        self._post(
            "/v1/daemon/event",
            {"invocation_id": invocation_id, "kind": kind, "body": body},
        )

    # ─── daemon-list / GPU filter ─────────────────────────────────────
    #
    # Read-only inventory of registered daemons. The server applies the
    # ``?tag=`` filter; we just normalize the wire shape into ``Daemon``.

    def daemons(self, tags: list[str] | None = None) -> list[Daemon]:
        """List daemons in the current namespace.

        ``tags`` is a list of glob patterns. All must match (AND).
        Examples::

            client.daemons()                       # all
            client.daemons(["gpu:h100"])           # exact tag
            client.daemons(["gpu:*"])              # any GPU tag
            client.daemons(["gpu:a100", "rack:5"]) # both must be present
        """
        params: dict[str, Any] = {}
        if tags:
            # httpx serializes list values as repeated query keys —
            # `tag=a&tag=b` — which is what the server expects.
            params["tag"] = list(tags)
        rows = self._get_json(
            f"/v1/namespaces/{self._ns}/workers",
            params=params,
        )
        return [Daemon(**_unmarshal_daemon(row)) for row in rows]

    def gpu_daemons(self, gpu_type: str | None = None) -> list[Daemon]:
        """Daemons with at least one GPU.

        Convenience over :meth:`daemons`. ``gpu_type=None`` resolves to
        ``["gpu:*"]`` (any GPU); ``gpu_type="h100"`` resolves to
        ``["gpu:h100"]``.
        """
        return self.daemons(tags=[f"gpu:{gpu_type or '*'}"])


# Public alias for the import path documented in the SDK README. The
# `ControlPlaneClient` name predates the rename to "Lakeshore"; keep
# both so downstream code (daemon, decorator, queue) still works.
LakeshoreClient = ControlPlaneClient
