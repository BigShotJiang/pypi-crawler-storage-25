"""gather — block on a list of Futures and return results in order.

Re-exports the existing :func:`gather` from the package __init__ for
the import path the task spec asks for::

    from dreamlake.lakeshore.gather import gather

The implementation here accepts both flavours of Future side-by-side:
the decorator-backed one (with ``.result()``) and the queue-backed one
(with ``.get()``). The shape is the canonical fan-out pattern — a list
comprehension produces N futures, ``gather`` collects them in
submission order::

    futs = [fn(x) for x in items]
    results = gather(futs)
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Iterable, Sequence


def _resolve_one(fut: Any, timeout: float | None) -> Any:
    """Resolve a single Future via whichever accessor it exposes.

    Order of preference: ``.result(timeout)`` (decorator.Future), then
    ``.get(timeout)`` (future.QueueFuture). Anything else gets a clear
    TypeError so callers don't silently fan-out over a list of plain
    values.
    """
    if hasattr(fut, "result") and callable(fut.result):
        try:
            return fut.result(timeout=timeout) if timeout is not None else fut.result()
        except TypeError:
            return fut.result()
    if hasattr(fut, "get") and callable(fut.get):
        try:
            return fut.get(timeout=timeout) if timeout is not None else fut.get()
        except TypeError:
            return fut.get()
    raise TypeError(
        f"gather() expected Future-like objects with .result() or .get(); "
        f"got {type(fut).__name__}"
    )


def gather(
    futures: Sequence[Any] | Iterable[Any],
    *,
    timeout: float | None = None,
) -> list[Any]:
    """Block until every Future in ``futures`` resolves; return the
    results in submission order.

    Both decorator.Future and future.QueueFuture are accepted in the
    same call — the dispatch picks ``.result()`` vs ``.get()`` per
    object."""
    fut_list = list(futures)
    return [_resolve_one(f, timeout) for f in fut_list]


async def gather_async(
    futures: Sequence[Any] | Iterable[Any],
) -> list[Any]:
    """Async sibling — turns each Future into an awaitable and gathers
    them via :func:`asyncio.gather`."""
    coros: list[Awaitable[Any]] = []
    for f in futures:
        if hasattr(f, "__await__"):
            async def _w(g: Any = f) -> Any:
                return await g
            coros.append(_w())
        else:
            async def _w_sync(g: Any = f) -> Any:
                return _resolve_one(g, None)
            coros.append(_w_sync())
    return list(await asyncio.gather(*coros))


__all__ = ["gather", "gather_async"]
