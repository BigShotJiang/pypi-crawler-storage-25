"""ZData — msgpack-with-numpy/torch/PIL encoding.

Vendored from zaku (`zaku/interfaces.py`, MIT, Ge Yang et al.). We carry
our own copy so the Lakeshore SDK doesn't take a hard dep on zaku — the
two projects share the wire format but have independent release cycles.

The encoding is a thin msgpack overlay: numpy arrays / torch tensors /
PIL images are converted to a small dict (`ztype`, raw bytes, dtype,
shape) before `msgpack.packb`; everything else passes through as-is.
The decode side inspects each dict for the `ztype` tag and restores
the original object.

Two public entry points:

    Payload(**data).serialize()           # bytes
    Payload.deserialize(bytes)            # dict

`Payload` is a thin SimpleNamespace wrapper that round-trips a flat
key→value mapping. Set ``_greedy=False`` to skip the ZData per-value
encoding pass (faster for payloads with no arrays/tensors/images).

The runtime imports of numpy / torch / PIL are deferred — none of the
three are required to import this module. Only the *encoding* path
needs them, and only for values of those types.
"""

from __future__ import annotations

from io import BytesIO
from types import SimpleNamespace
from typing import Any, Dict, Literal, Union

import msgpack

ZType = Literal["numpy.ndarray", "torch.Tensor", "image", "generic"]


def _is_numpy_array(data: Any) -> bool:
    """numpy.ndarray detection without forcing a numpy import."""
    try:
        import numpy as np  # type: ignore
    except ImportError:
        return False
    return isinstance(data, np.ndarray)


def _is_torch_tensor(data: Any) -> bool:
    """torch.Tensor detection without forcing a torch import."""
    try:
        import torch  # type: ignore
    except ImportError:
        return False
    return isinstance(data, torch.Tensor)


def _is_pil_image(data: Any) -> bool:
    """PIL.Image detection without forcing a Pillow import."""
    try:
        from PIL.Image import Image  # type: ignore
    except ImportError:
        return False
    return isinstance(data, Image)


class ZData:
    """Per-value encoder/decoder."""

    @staticmethod
    def encode(data: Any) -> Any:
        """Convert numpy/torch/PIL values to a transport-friendly dict.
        Returns the input unchanged for everything else."""
        if _is_pil_image(data):
            with BytesIO() as buffer:
                # use the format of the Image object, default to PNG.
                data.save(buffer, format=data.format or "PNG")
                binary = buffer.getvalue()
            return {"ztype": "image", "b": binary}
        if _is_numpy_array(data):
            return {
                "ztype": "numpy.ndarray",
                "b": data.tobytes(),
                "dtype": str(data.dtype),
                "shape": list(data.shape),
            }
        if _is_torch_tensor(data):
            np_v = data.cpu().numpy()
            return {
                "ztype": "torch.Tensor",
                "b": np_v.tobytes(),
                "dtype": str(np_v.dtype),
                "shape": list(np_v.shape),
            }
        return data

    @staticmethod
    def get_ztype(data: Any) -> Union[ZType, None]:
        if isinstance(data, dict) and "ztype" in data:
            return data["ztype"]
        return None

    @staticmethod
    def decode(zdata: Any) -> Any:
        T = ZData.get_ztype(zdata)
        if not T:
            return zdata
        if T == "image":
            from PIL import Image  # type: ignore

            return Image.open(BytesIO(zdata["b"]))
        if T == "numpy.ndarray":
            import numpy as np  # type: ignore

            array = np.frombuffer(zdata["b"], dtype=zdata["dtype"])
            return array.reshape(tuple(zdata["shape"]))
        if T == "torch.Tensor":
            import numpy as np  # type: ignore
            import torch  # type: ignore

            array = np.frombuffer(zdata["b"], dtype=zdata["dtype"])
            # frombuffer is non-writable — copy before handing to torch.
            array = array.reshape(tuple(zdata["shape"])).copy()
            return torch.from_numpy(array)
        raise TypeError(f"ZData type {T!r} is not supported")


class Payload(SimpleNamespace):
    """A flat key→value bundle that round-trips through msgpack+ZData.

    Greedy mode (default) runs ZData.encode on each value before
    packing, and ZData.decode on each value after unpacking. Set
    ``_greedy=False`` if you know nothing in the payload is a numpy
    array / torch tensor / PIL image — skips a no-op pass."""

    greedy = True

    def __init__(self, _greedy: bool | None = None, **payload: Any):
        if _greedy is not None:
            self.greedy = _greedy
        super().__init__(**payload)

    def serialize(self) -> bytes:
        data = dict(self.__dict__)
        # Stash the greedy flag so the decoder knows which path to take.
        if self.greedy:
            data = {k: ZData.encode(v) for k, v in data.items()}
        data["_greedy"] = self.greedy
        return msgpack.packb(data, use_bin_type=True)

    @staticmethod
    def deserialize(payload: bytes) -> Dict[str, Any]:
        unpacked = msgpack.unpackb(payload, raw=False)
        return Payload.deserialize_unpacked(unpacked)

    @staticmethod
    def deserialize_unpacked(unpacked: Dict[str, Any]) -> Dict[str, Any]:
        """Same as :meth:`deserialize` but starting from an already
        unpacked dict — used in streaming consumers driven by
        :class:`msgpack.Unpacker`."""
        is_greedy = unpacked.pop("_greedy", None)
        if not is_greedy:
            return unpacked
        return {k: ZData.decode(v) for k, v in unpacked.items()}


__all__ = ["ZData", "Payload"]
