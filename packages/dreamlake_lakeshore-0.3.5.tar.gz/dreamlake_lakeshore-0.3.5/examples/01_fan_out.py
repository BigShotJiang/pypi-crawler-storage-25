"""Phase D fan-out — N invocations, one `gather` call to collect.

Pre-flight: see ``00_hello_udf.py``. The worker queue here is
``fanout-demo``::

    lakeshore-udf-worker --queue fanout-demo

Then::

    python examples/01_fan_out.py
"""

from __future__ import annotations

from dreamlake.lakeshore import Queue, gather, udf


def main(n: int = 8) -> None:
    q = Queue("fanout-demo", kind="fifo")

    @udf(queue=q)
    def double(x: int) -> int:
        # Tiny "real work" stand-in.
        return x * 2

    # The canonical fan-out pattern: comprehension → list of Futures,
    # then gather() blocks until they all resolve, preserving order.
    futs = [double(i) for i in range(n)]
    results = gather(futs, timeout=60.0)
    print(f"submitted {n} jobs; results = {[r['value'] for r in results]}")
    assert [r["value"] for r in results] == [i * 2 for i in range(n)]


if __name__ == "__main__":
    main()
