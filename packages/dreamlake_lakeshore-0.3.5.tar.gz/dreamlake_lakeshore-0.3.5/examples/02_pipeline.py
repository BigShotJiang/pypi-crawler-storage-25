"""Phase D two-stage pipeline — shard → tokenize.

Demonstrates the **DAG-implicit-in-Python** pattern: stage 1 returns
N Futures, ``gather`` blocks for all of them, the resolved values
become the input to stage 2. There's no DSL — the call graph IS the
Python control flow.

Pre-flight: see ``00_hello_udf.py``. Attach the worker to ``pipeline-
demo``::

    lakeshore-udf-worker --queue pipeline-demo

Then::

    python examples/02_pipeline.py
"""

from __future__ import annotations

from dreamlake.lakeshore import Queue, gather, udf

# Plain text the pipeline processes.
SAMPLE = "the quick brown fox jumps over the lazy dog"


def main(n_shards: int = 4) -> None:
    q = Queue("pipeline-demo", kind="fifo")

    @udf(queue=q)
    def shard(text: str, k: int, n: int) -> list[str]:
        """Slice the input into the k-th of n shards (by word boundary)."""
        words = text.split()
        per = max(1, len(words) // n)
        start = k * per
        end = (k + 1) * per if k < n - 1 else len(words)
        return words[start:end]

    @udf(queue=q)
    def tokenize(words: list[str]) -> dict[str, int]:
        """Stage-2 reducer — frequency count over a shard."""
        out: dict[str, int] = {}
        for w in words:
            out[w] = out.get(w, 0) + 1
        return out

    # Stage 1: fan out shard computations.
    shard_futs = [shard(SAMPLE, k, n_shards) for k in range(n_shards)]
    sharded = [r["value"] for r in gather(shard_futs, timeout=30.0)]
    print(f"stage 1 — {n_shards} shards: {sharded}")

    # Stage 2: tokenize each shard. Each shard's resolved value feeds
    # the next call — that's the DAG, expressed in ordinary Python.
    tok_futs = [tokenize(s) for s in sharded]
    counts = [r for r in gather(tok_futs, timeout=30.0)]
    print(f"stage 2 — per-shard counts:")
    for k, c in enumerate(counts):
        print(f"  shard[{k}] = {c}")

    # Final reduce on the local side — just for demonstration.
    total: dict[str, int] = {}
    for c in counts:
        for k, v in c.items():
            total[k] = total.get(k, 0) + v
    print(f"merged counts = {total}")


if __name__ == "__main__":
    main()
