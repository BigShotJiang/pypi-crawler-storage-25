"""Phase D `@udf` hello-world — one function, one queue, one call.

Pre-flight (in one terminal)::

    cd lakeshore-workspace
    ./scripts/dev-up.sh                          # controlplane + nymph
    # then in another terminal, attach a UDF worker:
    cd dreamlake
    lakeshore-udf-worker --queue hello-udf

Then run this script::

    python examples/00_hello_udf.py

The script enqueues one ``add(2, 3)`` job, blocks on the returned
Future, and prints the result.
"""

from __future__ import annotations

from dreamlake.lakeshore import Queue, udf


def main() -> None:
    q = Queue("hello-udf", kind="fifo")

    @udf(queue=q)
    def add(a: int, b: int) -> int:
        return a + b

    fut = add(2, 3)
    print(f"enqueued; topic = {fut.topic}")
    result = fut.get(timeout=30.0)
    print(f"result = {result}")
    # `add` returns a non-dict, so the runner wraps under "value".
    assert result == {"value": 5}, result


if __name__ == "__main__":
    main()
