"""End-to-end tests for the Phase D Python SDK against a *live* controlplane.

These are the validation the in-process stub tests don't cover: real HTTP
calls into a real CP + a real daemon picking up the work.

# Profiles

Two profiles selected by `LAKESHORE_E2E_PROFILE`:

    # local — talks to ./scripts/dev-up.sh stack
    LAKESHORE_E2E_PROFILE=local pytest tests/e2e/test_udf_e2e.py -v

    # staging — talks to Heroku staging
    LAKESHORE_E2E_PROFILE=staging pytest tests/e2e/test_udf_e2e.py -v

If `LAKESHORE_E2E_PROFILE` is unset, the whole module is skipped (default
pytest run stays fast). Each test also auto-skips when no daemons are
registered in the target namespace — keeps CI green when the stack isn't
brought up.

# What we cover

Six round-trip cases that exercise the SDK surface end-to-end:
    1. Queue create + show
    2. Simple @udf add(a, b)
    3. @udf with numpy ndarray (exercises ZData encoding round-trip)
    4. Fan-out via list comp + gather
    5. Two-stage pipeline (shard → tokenize)
    6. Exception propagation (UDF raises ValueError; .get() re-raises)
"""
from __future__ import annotations

import os
import socket
import time
import uuid
from typing import Any

import numpy as np
import pytest

import dreamlake.lakeshore as dls
from dreamlake.lakeshore import Queue, gather, udf
from dreamlake.lakeshore.client import ControlPlaneClient


# ─── Profile resolution ────────────────────────────────────────────


_PROFILE = os.environ.get("LAKESHORE_E2E_PROFILE")

pytestmark = [
    pytest.mark.e2e,
    pytest.mark.skipif(
        _PROFILE not in {"local", "staging"},
        reason=(
            "set LAKESHORE_E2E_PROFILE=local|staging to run end-to-end "
            "tests (otherwise skipped — see module docstring)"
        ),
    ),
]


def _resolve_server() -> str:
    """Pick the CP URL for the chosen profile, with env override."""
    if explicit := os.environ.get("LAKESHORE_URL"):
        return explicit
    if _PROFILE == "staging":
        return "https://lakeshore-controlplane-staging-37e84854507a.herokuapp.com"
    return "http://localhost:8080"


# ─── Fixtures ──────────────────────────────────────────────────────


@pytest.fixture(scope="module")
def server() -> str:
    return _resolve_server()


@pytest.fixture(scope="module")
def cp(server: str) -> ControlPlaneClient:
    return ControlPlaneClient(base_url=server, namespace="default")


@pytest.fixture(scope="module", autouse=True)
def _require_daemon(cp: ControlPlaneClient) -> None:
    """Skip the whole module if no daemons are alive in the target namespace.

    CI safety: don't fail just because no one happened to spin up a daemon.
    For local: tells the developer to run `./scripts/dev-up.sh`.
    For staging: would only fail if the fleet drained.
    """
    try:
        workers = cp.daemons()
    except Exception as e:
        pytest.skip(
            f"controlplane unreachable at {cp.base_url}: {e}. "
            "For local: ./scripts/dev-up.sh. "
            "For staging: check Heroku app status."
        )
    if not workers:
        pytest.skip(
            f"no daemons registered in namespace 'default' at {cp.base_url}. "
            "For local: ./scripts/dev-up.sh. "
            "For staging: spin up a worker before running e2e."
        )


@pytest.fixture(scope="module")
def queue_name() -> str:
    """A unique transient queue per test run so reruns don't collide."""
    return f"e2e-{socket.gethostname().lower()}-{uuid.uuid4().hex[:6]}"


# ─── 1. Queue CRUD ─────────────────────────────────────────────────


def test_queue_create_and_show(cp: ControlPlaneClient, queue_name: str) -> None:
    # Create via SDK (which calls upsert_queue_crud under the hood).
    q = Queue(
        queue_name,
        kind="fifo",
        description="phase-D e2e — should be cleaned up by test exit",
        server=cp.base_url,
    )
    assert q.name == queue_name

    # Hit the namespaced GET /queues route directly (the SDK doesn't yet
    # expose a list-queues helper). Asserts the create call we just made
    # is visible to a fresh read.
    rows = cp._get_json(f"/v1/namespaces/{cp._ns}/queues")
    names = {r["name"] for r in rows}
    assert queue_name in names, (
        f"created queue {queue_name!r} but `queues ls` doesn't see it. "
        f"Saw: {sorted(names)}"
    )


# ─── 2. Simple UDF round-trip ──────────────────────────────────────


@udf(queue="e2e-add-queue")
def add(a: int, b: int) -> dict[str, Any]:
    return {"sum": a + b}


def test_simple_udf_roundtrip(server: str) -> None:
    # Ensure the queue exists; bind the daemon-side runner side too.
    Queue("e2e-add-queue", kind="fifo", server=server)
    future = add(2, 3)
    result = future.get(timeout=15.0)
    assert result == {"sum": 5}, f"unexpected: {result!r}"


# ─── 3. UDF + numpy (ZData round-trip) ─────────────────────────────


@udf(queue="e2e-numpy-queue")
def sum_array(arr: np.ndarray) -> dict[str, Any]:
    return {"sum": float(arr.sum()), "shape": list(arr.shape)}


def test_udf_with_numpy(server: str) -> None:
    Queue("e2e-numpy-queue", kind="fifo", server=server)
    arr = np.arange(100, dtype=np.float32).reshape(10, 10)
    future = sum_array(arr)
    result = future.get(timeout=15.0)
    assert result["shape"] == [10, 10]
    assert result["sum"] == pytest.approx(arr.sum())


# ─── 4. Fan-out + gather ───────────────────────────────────────────


@udf(queue="e2e-fanout-queue")
def double(x: int) -> dict[str, Any]:
    return {"value": x * 2}


def test_fan_out_gather(server: str) -> None:
    Queue("e2e-fanout-queue", kind="fifo", server=server)
    inputs = list(range(10))
    futures = [double(x) for x in inputs]
    results = gather(futures, timeout=30.0)
    assert [r["value"] for r in results] == [x * 2 for x in inputs]


# ─── 5. Two-stage pipeline ─────────────────────────────────────────


@udf(queue="e2e-shard-queue")
def shard(sentence: str) -> dict[str, Any]:
    return {"shards": sentence.split()}


@udf(queue="e2e-token-queue")
def tokenize(word: str) -> dict[str, Any]:
    # Trivial "tokenization" — lower + count.
    return {"word": word.lower(), "n": len(word)}


def test_pipeline_two_stage(server: str) -> None:
    for q in ("e2e-shard-queue", "e2e-token-queue"):
        Queue(q, kind="fifo", server=server)

    sentence = "Phase D ships a Python SDK"
    shard_future = shard(sentence)
    words = shard_future.get(timeout=15.0)["shards"]
    token_futures = [tokenize(w) for w in words]
    tokens = gather(token_futures, timeout=30.0)

    assert [t["word"] for t in tokens] == [w.lower() for w in words]
    assert sum(t["n"] for t in tokens) == sum(len(w) for w in words)


# ─── 6. Exception propagation ──────────────────────────────────────


@udf(queue="e2e-fail-queue")
def must_fail(reason: str) -> None:
    raise ValueError(reason)


def test_udf_exception_propagates(server: str) -> None:
    Queue("e2e-fail-queue", kind="fifo", server=server)
    future = must_fail("e2e-marker-xyz")
    with pytest.raises(Exception) as exc_info:
        future.get(timeout=15.0)
    # The original message should bubble up. The exact exception class
    # may be ValueError (if the SDK rehydrates) or a wrapped subclass
    # (if it only propagates the message + traceback string).
    msg = str(exc_info.value)
    assert "e2e-marker-xyz" in msg, (
        f"expected the UDF's ValueError message to surface in .get(); "
        f"got {exc_info.type.__name__}: {msg!r}"
    )
