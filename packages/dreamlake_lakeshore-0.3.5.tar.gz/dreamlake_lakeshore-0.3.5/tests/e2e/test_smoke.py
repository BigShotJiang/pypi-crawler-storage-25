"""End-to-end smoke test.

Requires the dev fabric to be up:
    mprocs
or manually:
    docker compose up -d
    pnpm --filter @dreamlake/lakeshore-controlplane prisma:push
    pnpm --filter @dreamlake/lakeshore-controlplane dev
    python -m dreamlake.lakeshore.daemon

Then:
    pytest tests/e2e -v
"""

from __future__ import annotations

import asyncio

import pytest

import dreamlake.lakeshore as dls
from dreamlake.lakeshore import udf


# ─── Functions: bare @udf is local-only ──────────────────────────────


@udf
def double(x: int) -> int:
    return x * 2


@udf
async def async_double(x: int) -> int:
    return x * 2


# ─── Functions: @udf(mode=...) is remote-by-default ──────────────────


@udf(mode="test")
def add(a: int, b: int) -> int:
    return a + b


@udf(mode="test", timeout_s=60)
def with_run_id(prefix: str) -> str:
    return f"{prefix}:{dls.run.id}"


@udf("test")
def boom() -> None:
    raise ValueError("intentional failure")


@udf(mode="test")
async def async_add(a: int, b: int) -> int:
    await asyncio.sleep(0)
    return a + b


# Local mode short-circuits — fn(...) runs in-process, no fabric.
@udf(mode="local")
def add_local(a: int, b: int) -> int:
    return a + b


# ─── Slow demo UDFs that emit progress + log + custom events ──────────


@udf(mode="test")
def slow_compute(steps: int = 10, delay_ms: int = 120) -> int:
    """Sleep `delay_ms` per step and emit a progress event after each.
    Used to populate the dashboard waterfall."""
    import time

    dls.run.log(f"starting slow_compute(steps={steps})")
    total = 0
    for i in range(steps):
        time.sleep(delay_ms / 1000)
        total += i
        dls.run.progress(i + 1, steps, label=f"step {i + 1}/{steps}")
    dls.run.emit("summary", {"steps": steps, "sum": total})
    dls.run.log("done", level="info", sum=total)
    return total


@udf(mode="test")
def quick_compute(x: int) -> int:
    """Short job for waterfall variety."""
    import time

    time.sleep(0.05)
    dls.run.progress(1, 1)
    return x * x


@udf(mode="test")
def child_step(x: int) -> int:
    """Inner step called from inside a parent UDF. Demonstrates nested
    invocations — the parent's id is stamped onto this invocation's
    parent_invocation_id by `_UDF._submit` reading the contextvar."""
    import time

    time.sleep(0.05)
    dls.run.log(f"child_step({x})", parent=dls.run.parent_id)
    return x * 2


@udf(mode="test")
def parent_pipeline(n: int) -> list[int]:
    """A pipeline-style UDF: spawns N child invocations, gathers their
    results. The dashboard's Pipelines view will render this as a root
    with N leaves."""
    dls.run.log(f"parent_pipeline(n={n}) starting")
    futs = [dls.apply_spawn(child_step, i) for i in range(n)]
    results = [f.result() for f in futs]
    dls.run.emit("done", {"n": n, "sum": sum(results)})
    return results


# ─── Plain @udf: local call ──────────────────────────────────────────


def test_plain_udf_runs_local() -> None:
    assert double(3) == 6


# ─── @udf(mode=...): plain call blocks remotely ──────────────────────


def test_compute_plain_call_blocks_remotely() -> None:
    assert add(2, 3) == 5


def test_compute_local_escape_hatch() -> None:
    assert add.local(2, 3) == 5


def test_compute_run_id_propagates() -> None:
    out = with_run_id("hi")
    assert out.startswith("hi:")


def test_compute_errors_surface() -> None:
    with pytest.raises(RuntimeError, match="ValueError: intentional failure"):
        boom()


# ─── Async functions: await the plain call ───────────────────────────


def test_async_compute_function_awaits_remotely() -> None:
    async def go() -> int:
        return await async_add(2, 3)

    assert asyncio.run(go()) == 5


# ─── Thunks ──────────────────────────────────────────────────────────


def test_thunk_then_spawn() -> None:
    t = dls.bind(double, 3)
    fut = dls.spawn(t)
    assert fut.result(timeout=15.0) == 6


def test_call_blocks_for_sync_thunk() -> None:
    t = dls.bind(double, 3)
    assert dls.call(t) == 6


def test_call_blocks_for_async_thunk_too() -> None:
    t = dls.bind(async_double, 3)
    assert dls.call(t) == 6


def test_call_async_returns_coroutine_for_sync_thunk() -> None:
    t = dls.bind(double, 3)
    coro = dls.call_async(t)
    assert asyncio.iscoroutine(coro)
    assert asyncio.run(coro) == 6


def test_call_async_rejects_async_thunk() -> None:
    t = dls.bind(async_double, 3)
    with pytest.raises(TypeError, match="require a sync target"):
        dls.call_async(t)


def test_apply_blocks_for_sync_function() -> None:
    assert dls.apply(double, 3) == 6


def test_apply_blocks_for_async_function() -> None:
    assert dls.apply(async_double, 3) == 6


def test_thunk_rejects_extra_args_on_spawn() -> None:
    t = dls.bind(double, 3)
    with pytest.raises(TypeError):
        dls.spawn(t, 99)


def test_thunk_rejects_non_udf() -> None:
    def plain(x: int) -> int:
        return x

    with pytest.raises(TypeError):
        dls.bind(plain, 3)  # type: ignore[arg-type]


# ─── Apply ───────────────────────────────────────────────────────────


def test_apply_spawn_with_function() -> None:
    fut = dls.apply_spawn(double, 3)
    assert fut.result(timeout=15.0) == 6


def test_apply_spawn_with_thunk() -> None:
    t = dls.bind(double, 3)
    fut = dls.apply_spawn(t)
    assert fut.result(timeout=15.0) == 6


def test_apply_async_with_sync_function() -> None:
    assert asyncio.run(dls.apply_async(double, 3)) == 6


def test_apply_async_rejects_async_function() -> None:
    with pytest.raises(TypeError, match="require a sync target"):
        dls.apply_async(async_double, 3)


def test_apply_async_with_sync_thunk() -> None:
    t = dls.bind(double, 3)
    assert asyncio.run(dls.apply_async(t)) == 6


# ─── Orchestration ───────────────────────────────────────────────────


def test_map_sync() -> None:
    assert dls.map(double, range(5)) == [0, 2, 4, 6, 8]


def test_map_async() -> None:
    assert asyncio.run(dls.map_async(double, range(5))) == [0, 2, 4, 6, 8]


def test_gather_sync() -> None:
    futs = [dls.apply_spawn(double, i) for i in range(5)]
    assert dls.gather(*futs) == [0, 2, 4, 6, 8]


def test_gather_async() -> None:
    async def go() -> list[int]:
        futs = [dls.apply_spawn(double, i) for i in range(5)]
        return await dls.gather_async(*futs)

    assert asyncio.run(go()) == [0, 2, 4, 6, 8]


def test_as_completed_sync() -> None:
    futs = [dls.apply_spawn(double, i) for i in range(5)]
    seen = sorted(f.result() for f in dls.as_completed(futs))
    assert seen == [0, 2, 4, 6, 8]


def test_as_completed_async() -> None:
    async def go() -> list[int]:
        futs = [dls.apply_spawn(double, i) for i in range(5)]
        out = []
        async for f in dls.as_completed_async(futs):
            out.append(f.result())
        return out

    assert sorted(asyncio.run(go())) == [0, 2, 4, 6, 8]


# ─── Events: progress / log / emit ────────────────────────────────────


def test_slow_compute_emits_events() -> None:
    """A slow UDF that emits progress and a custom event. We just check
    the result here; the dashboard renders the live waterfall."""
    out = slow_compute(steps=5, delay_ms=120)
    # sum of 0..4
    assert out == 10


def test_quick_compute_burst() -> None:
    """Submit a small batch in parallel — the dashboard's /invocations
    page should show them appearing and turning green almost at once."""
    futs = [dls.apply_spawn(quick_compute, i) for i in range(8)]
    assert sorted(f.result() for f in futs) == sorted(i * i for i in range(8))


def test_pipeline_nested_invocations() -> None:
    """parent_pipeline spawns child_step from inside its body. Each
    child's parent_invocation_id is stamped to the parent's id; all
    share the same rootInvocationId so they appear under one Pipeline
    row in the dashboard."""
    n = 4
    results = parent_pipeline(n)
    assert results == [i * 2 for i in range(n)]


# ─── Plain Python: local call always works ───────────────────────────


def test_plain_call_local_path() -> None:
    assert double(3) == 6
    assert double.local(3) == 6
    assert add.local(2, 3) == 5


def test_local_mode_short_circuits() -> None:
    # @udf(mode="local") doesn't go through the fabric — the call runs
    # in-process even though the decorator carries a mode.
    assert add_local(2, 3) == 5


# ─── Explicit Queue and Pool ─────────────────────────────────────────


def test_queue_submit() -> None:
    q = dls.Queue("test-queue-submit", mode="test")
    fut = q.submit(double, 7)
    assert fut.result(timeout=15.0) == 14


def test_queue_map() -> None:
    q = dls.Queue("test-queue-map", mode="test")
    assert q.map(double, range(5)) == [0, 2, 4, 6, 8]


def test_queue_with_thunk() -> None:
    q = dls.Queue("test-queue-thunk", mode="test")
    t = dls.bind(double, 9)
    fut = q.submit(t)
    assert fut.result(timeout=15.0) == 18


def test_pool_is_a_queue_with_fixed_size() -> None:
    p = dls.Pool(mode="test", size=2)
    assert p.min_hosts == p.max_hosts == 2
    fut = p.submit(double, 4)
    assert fut.result(timeout=15.0) == 8


def test_prefix_queue_routing() -> None:
    # Daemons started with `--queue 'sweep/*'` would consume from any of
    # these. Here the test daemon subscribes to `'*'` (catch-all), so
    # both queues drain through it.
    qa = dls.Queue("sweep/a", mode="test")
    qb = dls.Queue("sweep/b", mode="test")
    fa = qa.submit(double, 3)
    fb = qb.submit(double, 4)
    assert fa.result(timeout=15.0) == 6
    assert fb.result(timeout=15.0) == 8
