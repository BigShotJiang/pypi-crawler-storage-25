"""Mocked COLMAP reconstruction pipeline. Sketches the
`for batch in DataSource().chunks: run_colmap(batch)` shape from the
design discussion. The UDF doesn't actually run COLMAP — it sleeps
through realistic phases, emits progress + events, and returns a
plausible summary. Output paths are declared but no real files are
written. Replace the body with a `subprocess.run(["colmap", ...])`
call once the daemon's runner can pull `colmap/colmap:3.9` and mount
a workdir.
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass

import dreamlake.lakeshore as dls
from dreamlake.lakeshore import udf


@dataclass
class Batch:
    """One slice of a scene. In production: a list of S3 image URIs +
    associated metadata (intrinsics, exposure, timestamp range)."""

    id: str
    n_frames: int
    image_uris: list[str]


class DataSource:
    """v0 mock — yields a fixed sequence of Batches.
    Production-shape: backed by Iceberg / parquet / S3 prefix listing,
    streaming, with `mark(**flags)` writing back to a sidecar table."""

    def __init__(self, uri: str, n_batches: int = 3, frames_per_batch: int = 24):
        self.uri = uri
        self.n_batches = n_batches
        self.frames_per_batch = frames_per_batch

    @property
    def chunks(self):
        for i in range(self.n_batches):
            yield Batch(
                id=f"batch_{i:04d}",
                n_frames=self.frames_per_batch,
                image_uris=[
                    f"{self.uri}/img_{i:04d}_{f:04d}.jpg"
                    for f in range(self.frames_per_batch)
                ],
            )


# ─── UDFs — each phase emits progress + a phase-complete event ────────


@udf(mode="test")
def run_colmap(batch: Batch) -> dict:
    """Feature extraction → matching → sparse reconstruction.
    Phases mirror the real COLMAP pipeline; timings are mocked. Output
    paths are declared but no real files are written."""
    # In production, `dls.run.workdir` is the per-invocation host dir;
    # the pipeline's mount config syncs it to durable storage on ack.
    poses_out = f"./runs/{dls.run.id}/poses"
    dls.run.log("starting", batch=batch.id, n_frames=batch.n_frames, save_to=poses_out)

    # Phase 1: feature extraction
    n_feat_steps = 8
    for i in range(n_feat_steps):
        time.sleep(0.025)
        dls.run.progress(0.1 + (i + 1) * (0.3 / n_feat_steps), label="feature extraction")
    n_features = batch.n_frames * (180 + random.randint(0, 60))
    dls.run.emit("features_extracted", {"count": n_features})

    # Phase 2: exhaustive matching
    n_match_steps = 6
    for i in range(n_match_steps):
        time.sleep(0.02)
        dls.run.progress(0.4 + (i + 1) * (0.3 / n_match_steps), label="exhaustive matching")
    n_pairs = batch.n_frames * (batch.n_frames - 1) // 2
    dls.run.emit("matches_computed", {"pairs": n_pairs})

    # Phase 3: sparse reconstruction (bundle adjustment iterations)
    n_ba_steps = 5
    for i in range(n_ba_steps):
        time.sleep(0.03)
        dls.run.progress(0.7 + (i + 1) * (0.3 / n_ba_steps), label="bundle adjustment")
    n_poses = batch.n_frames - random.randint(0, 2)
    repr_err = round(0.42 + random.random() * 0.28, 3)
    dls.run.emit(
        "reconstruction_complete",
        {"n_poses": n_poses, "n_points": n_poses * 500, "reprojection_error": repr_err},
    )

    dls.run.progress(1.0, label="done")
    return {
        "batch_id": batch.id,
        "poses_dir": poses_out,
        "n_frames": batch.n_frames,
        "n_poses": n_poses,
        "mean_reprojection_error": repr_err,
    }


# ─── Pipeline orchestrators — sequential vs parallel patterns ─────────


@udf(mode="test")
def reconstruct(dataset_uri: str = "s3://demo/scene_seq/", n_batches: int = 3) -> list[dict]:
    """Sequential per-batch reconstruction. Body is straight Python —
    each `run_colmap(batch)` blocks before the next iteration."""
    dls.run.log("reconstruct starting", dataset=dataset_uri, n_batches=n_batches)
    results = []
    for batch in DataSource(dataset_uri, n_batches=n_batches).chunks:
        r = run_colmap(batch)
        results.append(r)
    dls.run.emit(
        "scene_reconstructed",
        {
            "mode": "sequential",
            "n_batches": len(results),
            "total_poses": sum(r["n_poses"] for r in results),
        },
    )
    return results


@udf(mode="test")
def reconstruct_parallel(
    dataset_uri: str = "s3://demo/scene_par/", n_batches: int = 4
) -> list[dict]:
    """Same pipeline, fan-out parallelism. Explicit `dls.apply_spawn`
    submits all batches at once; the body blocks on `gather`."""
    dls.run.log("reconstruct_parallel starting", dataset=dataset_uri, n_batches=n_batches)
    futs = [
        dls.apply_spawn(run_colmap, b)
        for b in DataSource(dataset_uri, n_batches=n_batches).chunks
    ]
    results = [f.result() for f in futs]
    dls.run.emit(
        "scene_reconstructed",
        {
            "mode": "parallel",
            "n_batches": len(results),
            "total_poses": sum(r["n_poses"] for r in results),
        },
    )
    return results


# ─── Tests ────────────────────────────────────────────────────────────


def test_colmap_sequential() -> None:
    r = reconstruct("s3://demo/scene_seq_001/", n_batches=3)
    assert len(r) == 3
    assert all(x["n_poses"] >= 22 for x in r)


def test_colmap_parallel() -> None:
    r = reconstruct_parallel("s3://demo/scene_par_001/", n_batches=4)
    assert len(r) == 4
    assert all(x["n_poses"] >= 22 for x in r)
