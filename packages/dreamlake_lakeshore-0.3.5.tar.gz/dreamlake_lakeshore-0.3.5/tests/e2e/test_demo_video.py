"""A realistic agentic pipeline that populates the dashboard with
something worth looking at.

Shape (each step is a separate UDF the daemon executes):

  caption_video                       <- root pipeline
   ├─ extract_frames                  <- decode the video to N frames
   ├─ caption_frame  ×N (parallel)    <- VLM captions each frame
   ├─ segment_subtasks                <- LLM groups captions into sub-tasks
   ├─ review_segments                 <- LLM critiques the segmentation
   ├─ request_human_review            <- pretends to wait for a human
   ├─ caption_frame  ×K (parallel)    <- re-caption uncertain frames
   └─ segment_subtasks                <- final pass

The UDF bodies are mocked (no real model calls) but emit progress, logs,
and user-defined events so the dashboard waterfall shows realistic flow.
Run `pytest tests/e2e -n auto` and open http://localhost:5173/pipelines.
"""

from __future__ import annotations

import random
import time

import dreamlake.lakeshore as dls
from dreamlake.lakeshore import udf

# ─── Mock VLM data — looks like a cooking video for variety ──────────

SAMPLE_CAPTIONS = [
    "A person reaches for a red mug from the upper shelf",
    "The mug is set on the wooden counter near the sink",
    "Hand turns on the cold water faucet",
    "Water fills the mug roughly halfway",
    "Faucet is turned off; mug is moved aside",
    "Person opens the cabinet above the stove",
    "Reaches for a box of green tea",
    "Tea bag is taken out and placed in the mug",
    "Microwave door is opened with the left hand",
    "Mug is placed on the rotating glass tray",
    "Door closes; numeric pad is pressed three times",
    "Microwave hum begins; light turns on inside",
    "Steam visibly rises through the door window",
    "Beep sounds; the door is opened",
    "Hand wraps around the mug with a folded napkin",
    "Mug is lifted out and placed on the counter",
    "Tea bag is squeezed against the rim with a spoon",
    "Used tea bag is dropped in the compost bin",
    "A small amount of honey is drizzled in",
    "Spoon stirs the tea in slow circles",
    "Person carries the mug toward the dining table",
    "Mug is set down on a folded paper napkin",
    "Person sits and wraps both hands around the mug",
    "First sip is taken; the steam lifts past the face",
]


# ─── UDFs — each a realistic step the daemon executes ─────────────────


@udf(mode="test")
def extract_frames(video_uri: str, fps: float = 3.0, n: int = 24) -> list[str]:
    """Decode `n` frames from a video. Returns frame URIs."""
    dls.run.log(f"opening {video_uri}", fps=fps, requested=n)
    out: list[str] = []
    for i in range(n):
        time.sleep(0.012)
        out.append(f"{video_uri}#frame={i:04d}")
        if (i + 1) % 4 == 0 or i == n - 1:
            dls.run.progress(i + 1, n, label=f"decoded {i + 1}/{n}")
    dls.run.emit("frames_extracted", {"count": n, "fps": fps, "video": video_uri})
    return out


@udf(mode="test")
def caption_frame(frame_uri: str) -> dict:
    """VLM caption for a single frame. Returns caption + confidence."""
    time.sleep(0.04 + random.random() * 0.06)
    idx = int(frame_uri.rsplit("=", 1)[-1])
    caption = SAMPLE_CAPTIONS[idx % len(SAMPLE_CAPTIONS)]
    confidence = round(0.62 + random.random() * 0.36, 3)
    dls.run.log("captioned frame", frame=frame_uri[-12:], conf=confidence)
    if confidence < 0.7:
        dls.run.emit("low_confidence", {"frame": frame_uri, "confidence": confidence})
    return {"frame": frame_uri, "caption": caption, "confidence": confidence}


@udf(mode="test")
def segment_subtasks(captions: list[dict]) -> list[dict]:
    """Group captions into sub-tasks (LLM, mocked)."""
    dls.run.log(f"segmenting {len(captions)} captions")
    segments: list[dict] = []
    n_groups = (len(captions) + 3) // 4
    for i, start in enumerate(range(0, len(captions), 4)):
        time.sleep(0.04)
        chunk = captions[start : start + 4]
        segments.append(
            {
                "id": f"seg_{i:02d}",
                "start_frame": start,
                "end_frame": start + len(chunk) - 1,
                "label": f"step_{i + 1}",
                "summary": chunk[0]["caption"] if chunk else "",
            }
        )
        dls.run.progress(i + 1, n_groups, label=f"segment {i + 1}/{n_groups}")
    dls.run.emit("segmentation_done", {"n_segments": len(segments)})
    return segments


@udf(mode="test")
def review_segments(captions: list[dict], segments: list[dict]) -> dict:
    """Review agent (LLM) checks segmentation. Returns confidence +
    list of frames the reviewer wants re-captioned."""
    dls.run.log(f"reviewing {len(segments)} segments over {len(captions)} captions")
    uncertain_frames: list[str] = []
    for i, seg in enumerate(segments):
        time.sleep(0.07)
        # Find low-confidence captions in this segment.
        for c in captions[seg["start_frame"] : seg["end_frame"] + 1]:
            if c["confidence"] < 0.72:
                uncertain_frames.append(c["frame"])
        dls.run.progress(i + 1, len(segments), label=f"reviewed seg {i + 1}")
    confidence = 1.0 - len(uncertain_frames) / max(len(captions), 1)
    dls.run.emit(
        "review_complete",
        {
            "confidence": round(confidence, 3),
            "n_uncertain": len(uncertain_frames),
            "approve": confidence > 0.85,
        },
    )
    return {
        "confidence": confidence,
        "uncertain_frames": uncertain_frames,
        "approve": confidence > 0.85,
    }


@udf(mode="test")
def request_human_review(items: list[str], task: str = "frame caption") -> dict:
    """Ask a human to approve/reject. v0 pretends to wait, then
    auto-approves; v1 will block on an external `/v1/external/events`
    POST from a human-review web form."""
    dls.run.log(f"awaiting human review on {len(items)} {task}(s)")
    dls.run.emit(
        "human_review_requested",
        {"task": task, "n_items": len(items), "reviewer_pool": "ml-team"},
    )
    time.sleep(0.35)  # placeholder for actual human wait
    dls.run.emit(
        "human_review_received",
        {"decision": "approve", "reviewer": "ge@dreamlake.ai", "notes": "looks good"},
    )
    return {"decision": "approve", "reviewer": "ge@dreamlake.ai", "n_items": len(items)}


@udf(mode="test")
def caption_video(video_uri: str = "s3://demo/clip_01.mp4", seed: int = 42) -> dict:
    """Top-level agentic pipeline: caption → segment → review → (maybe) human
    review → re-caption uncertain frames → final segmentation."""
    random.seed(seed)
    dls.run.log(f"caption_video starting", video_uri=video_uri)
    dls.run.emit("pipeline_started", {"video_uri": video_uri})

    # 1. extract frames
    frames = extract_frames(video_uri)
    dls.run.progress(1, 5, label="frames extracted")

    # 2. caption every frame in parallel — fan-out
    futs = [dls.apply_spawn(caption_frame, f) for f in frames]
    captions = [f.result() for f in futs]
    dls.run.progress(2, 5, label="captioned all frames")

    # 3. initial segmentation
    segments = segment_subtasks(captions)
    dls.run.progress(3, 5, label="initial segmentation")

    # 4. review pass
    review = review_segments(captions, segments)

    # 5. iterate if uncertain
    if not review["approve"] and review["uncertain_frames"]:
        dls.run.emit(
            "iteration_required",
            {"n_uncertain": len(review["uncertain_frames"]), "reason": "low_confidence"},
        )
        # human in the loop
        human = request_human_review(review["uncertain_frames"], task="caption verify")
        # re-caption (parallel again — but only the uncertain frames)
        refuts = [dls.apply_spawn(caption_frame, f) for f in review["uncertain_frames"]]
        better_captions = [f.result() for f in refuts]
        # final segmentation with improved captions blended in
        merged = list(captions)
        by_frame = {c["frame"]: c for c in better_captions}
        for i, c in enumerate(merged):
            if c["frame"] in by_frame:
                merged[i] = by_frame[c["frame"]]
        segments = segment_subtasks(merged)
        dls.run.emit("recaption_complete", {"refined": len(better_captions)})
        captions = merged

    dls.run.progress(5, 5, label="done")
    summary = {
        "video_uri": video_uri,
        "n_frames": len(captions),
        "n_segments": len(segments),
        "confidence": round(review["confidence"], 3),
        "approved": review["approve"],
    }
    dls.run.emit("pipeline_complete", summary)
    return summary


# ─── Tests ────────────────────────────────────────────────────────────


def test_caption_video_single() -> None:
    """One realistic video captioning run."""
    r = caption_video("s3://demo/cooking_clip_01.mp4", seed=11)
    assert r["n_frames"] == 24
    assert r["n_segments"] == 6


def test_caption_video_batch() -> None:
    """Three video captioning pipelines in parallel — the dashboard
    will show three roots, each with its own fan-out tree."""
    videos = [
        ("s3://demo/cooking_clip_02.mp4", 17),
        ("s3://demo/factory_clip_01.mp4", 23),
        ("s3://demo/lab_clip_01.mp4", 29),
    ]
    futs = [dls.apply_spawn(caption_video, v, s) for v, s in videos]
    results = [f.result() for f in futs]
    for r in results:
        assert r["n_frames"] == 24
        assert r["n_segments"] >= 6
