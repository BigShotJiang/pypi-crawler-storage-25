"""Ensures the e2e package's @udf decorators import from a stable module
path. The daemon and the test runner share the same venv, so cloudpickle
serializes/deserializes via this conftest's import."""
