"""Unit tests for :py:meth:`ControlPlaneClient.daemons` and friends.

These exercise the wire-format contract for the daemon-list endpoint
without standing up the control plane. We use httpx's :class:`MockTransport`
to capture the request and synthesize a canned response — so the test
asserts on the URL the SDK sends *and* on the dataclass it constructs
from the reply.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qs, urlsplit

import httpx
import pytest

from dreamlake.lakeshore.client import (
    ControlPlaneClient,
    Daemon,
    LakeshoreClient,
)


def _make_client(handler: Any) -> ControlPlaneClient:
    """Build a client whose HTTP layer is the supplied handler.

    We construct a real ``ControlPlaneClient`` and then swap its
    httpx.Client for one wired to a MockTransport — that way we test
    the production ``_get_json`` path end-to-end.
    """
    client = ControlPlaneClient(base_url="http://test")
    client._client.close()
    client._client = httpx.Client(
        base_url="http://test",
        transport=httpx.MockTransport(handler),
        headers={"content-type": "application/x-msgpack", "accept": "application/x-msgpack"},
    )
    return client


def _row(**overrides: Any) -> dict[str, Any]:
    base = {
        "id": "w_1",
        "machineId": "mach-1",
        "label": "node-1",
        "tags": ["gpu:h100"],
        "runners": ["process"],
        "capabilities": {"versions": {"daemon": "0.1.0"}},
        "state": "active",
        "hostname": "host-1.example",
        "lastSeenAt": "2026-05-20T00:00:00.000Z",
        "createdAt": "2026-05-19T00:00:00.000Z",
    }
    base.update(overrides)
    return base


def test_daemons_with_no_tags_omits_query_param() -> None:
    captured: list[httpx.Request] = []

    def handler(req: httpx.Request) -> httpx.Response:
        captured.append(req)
        return httpx.Response(200, json=[_row()])

    client = _make_client(handler)
    daemons = client.daemons()

    assert len(captured) == 1
    url = captured[0].url
    assert url.path == "/v1/namespaces/default/workers"
    # No `tag=` parameter at all when the caller passes nothing.
    assert "tag" not in parse_qs(url.query.decode() if isinstance(url.query, bytes) else url.query)
    assert isinstance(daemons[0], Daemon)
    assert daemons[0].machine_id == "mach-1"


def test_daemons_single_tag_serializes_as_query_param() -> None:
    captured: list[httpx.Request] = []

    def handler(req: httpx.Request) -> httpx.Response:
        captured.append(req)
        return httpx.Response(200, json=[])

    client = _make_client(handler)
    client.daemons(["gpu:h100"])

    qs = parse_qs(urlsplit(str(captured[0].url)).query)
    assert qs.get("tag") == ["gpu:h100"]


def test_daemons_multiple_tags_repeat_query_param() -> None:
    captured: list[httpx.Request] = []

    def handler(req: httpx.Request) -> httpx.Response:
        captured.append(req)
        return httpx.Response(200, json=[])

    client = _make_client(handler)
    client.daemons(["a", "b"])

    raw_qs = urlsplit(str(captured[0].url)).query
    qs = parse_qs(raw_qs)
    assert qs.get("tag") == ["a", "b"]
    # Two distinct `tag=` keys on the wire (not `tag=a,b`).
    assert raw_qs.count("tag=") == 2


def test_gpu_daemons_resolves_to_gpu_star_or_specific_type() -> None:
    captured: list[httpx.Request] = []

    def handler(req: httpx.Request) -> httpx.Response:
        captured.append(req)
        return httpx.Response(200, json=[])

    client = _make_client(handler)
    client.gpu_daemons()
    client.gpu_daemons("a100")

    assert parse_qs(urlsplit(str(captured[0].url)).query).get("tag") == ["gpu:*"]
    assert parse_qs(urlsplit(str(captured[1].url)).query).get("tag") == ["gpu:a100"]


def test_daemons_tolerates_null_hostname_and_label() -> None:
    """Server may send ``null`` for optional columns. The dataclass
    must still build without exploding."""
    rows = [
        _row(id="w_a", hostname=None, label=None, tags=[], runners=[]),
        _row(id="w_b"),
    ]

    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=rows)

    client = _make_client(handler)
    out = client.daemons()
    assert len(out) == 2
    assert out[0].hostname is None
    assert out[0].label is None
    assert out[0].tags == []
    assert out[1].hostname == "host-1.example"


def test_lakeshore_client_alias_is_the_same_class() -> None:
    """The public import name documented in the README is
    ``LakeshoreClient``; it must resolve to the underlying client."""
    assert LakeshoreClient is ControlPlaneClient
