"""Unit tests for Phase D — the queue-bound @udf decorator, the
QueueFuture handle, and the gather() fan-out helper.

All tests run against the stub controlplane in `_stub_server.py` — no
docker, no mongo. Each test drives the submit→poll→ack→await loop
itself so the ordering is explicit.
"""

from __future__ import annotations

import asyncio
import threading
import time

import pytest

from dreamlake.lakeshore.daemon.udf_runner import run_one_job
from dreamlake.lakeshore.future import Future, QueueFuture
from dreamlake.lakeshore.gather import gather, gather_async
from dreamlake.lakeshore.udf import udf as udf_phase_d
from dreamlake.lakeshore.zdata import Payload, ZData

from ._stub_server import make_stubbed_queue


# ─── cloudpickle round-trip ──────────────────────────────────────────


def test_payload_round_trips_through_msgpack_zdata() -> None:
    """The wire format must round-trip native types verbatim. This is
    the contract Phase D.5 will rely on when it lifts the same bytes
    onto `payloadInline` / `payloadRef`."""
    data = {"a": 1, "b": "two", "c": [1, 2, 3], "d": {"e": 4}}
    blob = Payload(**data).serialize()
    assert isinstance(blob, bytes)
    restored = Payload.deserialize(blob)
    assert restored == data


def test_payload_passes_unknown_types_through_zdata() -> None:
    """ZData.encode is greedy but conservative — non-array values are
    returned unchanged. Lets the SDK pack plain dicts without surprises."""
    enc = ZData.encode({"hello": "world"})
    assert enc == {"hello": "world"}
    assert ZData.decode("plain string") == "plain string"


# ─── Queue: add / take / publish / subscribe_one round-trip ──────────


def test_add_then_take_round_trips_payload() -> None:
    q, state = make_stubbed_queue("rpc-roundtrip")
    job_id = q.add({"x": 1, "y": "two"}, key="topic-1")
    assert job_id == "topic-1"
    assert "topic-1" in state.jobs

    msg = q.take()
    assert msg is not None
    # `_request_id` is injected by take() — equals the job_id.
    assert msg["_request_id"] == "topic-1"
    assert msg["x"] == 1
    assert msg["y"] == "two"


def test_take_returns_none_when_queue_empty() -> None:
    q, _ = make_stubbed_queue("empty")
    assert q.take(timeout_s=0.0) is None


def test_publish_then_subscribe_one_round_trips() -> None:
    q, _ = make_stubbed_queue("pubsub")
    q.add({"x": 1}, key="topic-pub")
    # Daemon-side: take, then publish to the same _request_id.
    msg = q.take()
    assert msg is not None
    n = q.publish({"answer": 42}, topic=msg["_request_id"])
    assert n == 1
    got = q.subscribe_one(msg["_request_id"], timeout=2.0)
    assert got == {"answer": 42}


def test_subscribe_one_times_out_with_none() -> None:
    q, _ = make_stubbed_queue("timeout")
    q.add({"x": 1}, key="topic-never")
    # Don't publish — subscribe_one should return None.
    assert q.subscribe_one("topic-never", timeout=0.1) is None


# ─── Queue.rpc — zaku-style ──────────────────────────────────────────


def test_rpc_pairs_add_and_subscribe_one() -> None:
    """rpc() = add() + subscribe_one() on the matching topic. Drive
    the daemon side in a thread so the foreground call blocks then
    resolves."""
    q, _ = make_stubbed_queue("rpc")

    def daemon_side() -> None:
        # Wait for the producer to enqueue.
        for _ in range(50):
            msg = q.take(timeout_s=0.0)
            if msg:
                q.publish({"answer": msg["_args"][0] * 2}, topic=msg["_request_id"])
                return
            time.sleep(0.02)

    t = threading.Thread(target=daemon_side, daemon=True)
    t.start()
    result = q.rpc(21, _timeout=2.0)
    t.join(timeout=2.0)
    assert result == {"answer": 42}


# ─── @udf(queue=q) — cloudpickle round-trip ──────────────────────────


def test_udf_queue_returns_future_and_runner_resolves_it() -> None:
    q, _ = make_stubbed_queue("udf-rpc")

    @udf_phase_d(queue=q)
    def add(a: int, b: int) -> int:
        return a + b

    fut = add(2, 3)
    assert isinstance(fut, QueueFuture)
    # Drive the daemon side: pop the job, run it, publish.
    msg = q.take()
    assert msg is not None
    run_one_job(q, msg)
    result = fut.get(timeout=2.0)
    # _QueueBoundUDF wraps non-dict returns under "value".
    assert result == {"value": 5}


def test_udf_local_escape_hatch_bypasses_queue() -> None:
    q, state = make_stubbed_queue("udf-local-escape")

    @udf_phase_d(queue=q)
    def add(a: int, b: int) -> int:
        return a + b

    # .local() bypasses the queue entirely — no submit/ack traffic.
    before_submits = len(state.submits)
    assert add.local(2, 3) == 5
    assert len(state.submits) == before_submits


def test_udf_propagates_user_exception_via_error_topic() -> None:
    q, _ = make_stubbed_queue("udf-err")

    @udf_phase_d(queue=q)
    def boom() -> int:
        raise ValueError("nope")

    fut = boom()
    msg = q.take()
    run_one_job(q, msg)
    with pytest.raises(RuntimeError, match="ValueError"):
        fut.get(timeout=2.0)


# ─── QueueFuture: sync + async ───────────────────────────────────────


def test_queue_future_await_works_in_asyncio() -> None:
    q, _ = make_stubbed_queue("future-async")
    job_id = q.add({"hi": 1}, key="t-async")
    q.take()  # claim
    q.publish({"out": 7}, topic="t-async")
    fut = QueueFuture(q, "t-async", timeout=2.0)

    async def go() -> dict:
        return await fut

    assert asyncio.run(go()) == {"out": 7}


def test_queue_future_iter_yields_stream_payloads() -> None:
    q, _ = make_stubbed_queue("future-stream")
    q.add({"hi": 1}, key="t-stream")
    q.take()
    q.publish({"chunk": 1}, topic="t-stream")
    fut = QueueFuture(q, "t-stream", timeout=2.0)
    msgs = list(fut)
    assert msgs == [{"chunk": 1}]


def test_future_alias_is_queue_future() -> None:
    """The public alias `Future` in dreamlake.lakeshore.future resolves
    to the queue-backed implementation per the task spec."""
    assert Future is QueueFuture


# ─── gather ──────────────────────────────────────────────────────────


def _drain_and_publish_each(q, n: int, fn) -> None:
    """Drive the daemon side for `n` queue jobs, applying `fn` to each
    job's args[0] before publishing."""
    for _ in range(n):
        for _ in range(100):
            msg = q.take(timeout_s=0.0)
            if msg:
                break
            time.sleep(0.01)
        else:
            raise AssertionError("expected a job to claim")
        out = fn(msg["_args"][0])
        q.publish({"value": out}, topic=msg["_request_id"])


def test_gather_returns_results_in_submission_order() -> None:
    q, _ = make_stubbed_queue("gather-fanout")

    @udf_phase_d(queue=q)
    def double(x: int) -> int:
        return x * 2

    futs = [double(i) for i in range(5)]
    # Drive the daemon side on a background thread so foreground
    # gather can block.
    t = threading.Thread(
        target=_drain_and_publish_each, args=(q, 5, lambda x: x * 2), daemon=True
    )
    t.start()
    results = gather(futs, timeout=3.0)
    t.join(timeout=3.0)
    assert results == [{"value": 0}, {"value": 2}, {"value": 4}, {"value": 6}, {"value": 8}]


def test_gather_async_works_with_queue_futures() -> None:
    q, _ = make_stubbed_queue("gather-async")

    @udf_phase_d(queue=q)
    def triple(x: int) -> int:
        return x * 3

    futs = [triple(i) for i in range(3)]
    t = threading.Thread(
        target=_drain_and_publish_each, args=(q, 3, lambda x: x * 3), daemon=True
    )
    t.start()
    results = asyncio.run(gather_async(futs))
    t.join(timeout=3.0)
    assert results == [{"value": 0}, {"value": 3}, {"value": 6}]


# ─── Pipeline / two-stage fan-out ────────────────────────────────────


def test_two_stage_pipeline_chains_through_gather() -> None:
    """Stage 1 doubles each input; stage 2 sums the doubled list.
    Demonstrates that gather() over QueueFutures lets the next stage
    consume their resolved values without a sentinel."""
    q, _ = make_stubbed_queue("pipeline")

    @udf_phase_d(queue=q)
    def doubler(x: int) -> int:
        return x * 2

    @udf_phase_d(queue=q)
    def summer(xs: list[int]) -> int:
        return sum(xs)

    stage1 = [doubler(i) for i in range(4)]
    t1 = threading.Thread(
        target=_drain_and_publish_each, args=(q, 4, lambda x: x * 2), daemon=True
    )
    t1.start()
    doubled = [r["value"] for r in gather(stage1, timeout=3.0)]
    t1.join(timeout=3.0)
    assert doubled == [0, 2, 4, 6]

    stage2 = summer(doubled)

    def stage2_daemon() -> None:
        for _ in range(100):
            msg = q.take(timeout_s=0.0)
            if msg:
                xs = msg["_args"][0]
                q.publish({"value": sum(xs)}, topic=msg["_request_id"])
                return
            time.sleep(0.01)

    t2 = threading.Thread(target=stage2_daemon, daemon=True)
    t2.start()
    out = stage2.get(timeout=3.0)
    t2.join(timeout=3.0)
    assert out == {"value": 12}


# ─── Queue construction is idempotent ─────────────────────────────────


def test_queue_construction_with_phase_a5_knobs_calls_crud() -> None:
    """`Queue(name, kind=...)` routes through the namespaced CRUD
    route so the modern Phase A.5 surface is the one the SDK uses."""
    q, state = make_stubbed_queue("crud", kind="fifo")
    assert "crud" in state.queues
    assert state.queues["crud"].get("kind") == "fifo"


def test_queue_construction_legacy_path_uses_producer_queues() -> None:
    """Without Phase A.5 knobs, fall through to the legacy
    producer/queues upsert — that's what existing daemons & older
    call-sites depend on."""
    q, state = make_stubbed_queue("legacy")
    # Either CRUD or legacy populates `state.queues[name]`; both fine.
    # The point is the construction succeeded without raising.
    assert "legacy" in state.queues
