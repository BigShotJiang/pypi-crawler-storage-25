"""Unit tests for the providers schema + resolver.

No network — these only parse `.dreamrc` flavored YAML and verify the
in-memory shape after resolution and deep-merge.
"""

from __future__ import annotations

import pytest

from dreamlake.lakeshore.config import (
    DreamRc,
    Provider,
    _deep_merge,
    load_yaml_string,
    resolve,
    resolve_by_provider,
)


DREAMRC_SSH = """
default_mode: local

providers:
  my-dev-box: !providers.SSH
    ip: 192.168.1.42
    username: gyang
    pem: ~/.ssh/id_ed25519
    tags:
      team: ml

modes:
  dev:
    provider: my-dev-box
    runner: process
    tags:
      project: alpha
"""


def _dreamrc_from(text: str) -> DreamRc:
    return DreamRc.from_dict(load_yaml_string(text))


def test_parses_ssh_provider_tag() -> None:
    dreamrc = _dreamrc_from(DREAMRC_SSH)
    assert "my-dev-box" in dreamrc.providers
    prov = dreamrc.providers["my-dev-box"]
    assert isinstance(prov, Provider)
    assert prov.launcher == "SSH"
    assert prov.kwargs["ip"] == "192.168.1.42"
    assert prov.kwargs["username"] == "gyang"
    # Default dispatch for SSH is `direct`.
    assert prov.dispatch == "direct"


def test_unknown_provider_tag_is_a_hard_error() -> None:
    bad = """
providers:
  weird: !providers.Foo
    ip: 1.2.3.4
"""
    with pytest.raises(Exception) as exc:
        load_yaml_string(bad)
    assert "providers.Foo" in str(exc.value)


def test_resolve_picks_provider_and_merges_kwargs() -> None:
    dreamrc = _dreamrc_from(DREAMRC_SSH)
    provider, merged, runconfig = resolve(dreamrc, "dev")

    assert provider.launcher == "SSH"
    # Runtime knobs land on RunConfig.
    assert runconfig.runner == "process"
    assert runconfig.provider == "my-dev-box"
    # Merge: provider field passes through.
    assert merged["ip"] == "192.168.1.42"
    # Deep-merge: nested dict from provider + RunConfig is combined,
    # not replaced.
    assert merged["tags"] == {"team": "ml", "project": "alpha"}


def test_deep_merge_scalars_runconfig_wins() -> None:
    a = {"a": 1, "b": {"x": 1, "y": 2}, "c": [1, 2]}
    b = {"a": 99, "b": {"y": 22, "z": 3}, "c": [2, 3]}
    out = _deep_merge(a, b)
    # Scalar conflict: b wins.
    assert out["a"] == 99
    # Nested dict: recursive merge.
    assert out["b"] == {"x": 1, "y": 22, "z": 3}
    # List: concatenation, dedupe.
    assert out["c"] == [1, 2, 3]


def test_resolve_by_provider_gives_minimal_runconfig() -> None:
    dreamrc = _dreamrc_from(DREAMRC_SSH)
    provider, merged, runconfig = resolve_by_provider(dreamrc, "my-dev-box")
    assert provider.launcher == "SSH"
    assert runconfig.runner == "process"
    assert runconfig.backend == "local"
    # No RunConfig in this path → provider kwargs verbatim.
    assert merged["ip"] == "192.168.1.42"


def test_resolve_errors_on_unknown_provider_reference() -> None:
    text = """
providers:
  good: !providers.SSH
    ip: 1.1.1.1
modes:
  bad:
    provider: nonexistent
    runner: process
"""
    dreamrc = _dreamrc_from(text)
    with pytest.raises(KeyError) as exc:
        resolve(dreamrc, "bad")
    assert "nonexistent" in str(exc.value)
