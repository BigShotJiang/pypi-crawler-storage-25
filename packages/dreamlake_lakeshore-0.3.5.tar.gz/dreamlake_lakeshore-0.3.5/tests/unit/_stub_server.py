"""In-memory controlplane stub for Phase D unit tests.

The await handler simulates the CP's long-poll semantics by sleeping
in 50ms increments up to the requested ``timeout_s`` — that's how the
real Fastify handler at ``/v1/producer/await`` waits for a job to
reach a terminal state. Without that sleep loop, a background daemon
thread doesn't get a chance to publish before the foreground caller's
single-shot await returns ``pending``.


Implements just enough of the CP wire that ``Queue`` /
:class:`QueueFuture` / ``@udf(queue=q)`` can be exercised without
docker, mongo, or a real Fastify server:

  PUT   /v1/producer/queues
  POST  /v1/namespaces/default/queues
  POST  /v1/producer/submit
  POST  /v1/producer/await
  POST  /v1/daemon/poll
  POST  /v1/daemon/ack
  GET   /v1/namespaces/default/workers

Backed by an httpx :class:`MockTransport` — the test installs the stub
on a real :class:`ControlPlaneClient` so the production HTTP code path
is exercised end-to-end.

Behaviour model:

  * `submit` stores ``{id, queue, args_blob, state="queued"}`` in
    ``state.jobs``.
  * `poll(queue=N)` claims the oldest queued job for that queue, flips
    state to "running", returns the run envelope. FIFO. Times out
    instantly (no long-poll simulation) for snappy tests.
  * `ack(state="succeeded", result_blob=...)` flips the job to
    "succeeded" and stores the result_blob.
  * `await(invocation_id, timeout_s)` returns the row when terminal,
    else ``{state: "pending"}`` after a tiny synthetic wait.

This is deliberately not a full FIFO + retry implementation. Each
test is expected to drive submit→poll→ack→await in the order it
wants.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx
import msgpack


@dataclass
class StubJob:
    id: str
    queue: str
    args_blob: bytes
    state: str = "queued"
    result_blob: bytes | None = None
    error: dict[str, Any] | None = None


@dataclass
class StubState:
    jobs: dict[str, StubJob] = field(default_factory=dict)
    # Optional history for assertions.
    submits: list[dict[str, Any]] = field(default_factory=list)
    acks: list[dict[str, Any]] = field(default_factory=list)
    polls: list[dict[str, Any]] = field(default_factory=list)
    awaits: list[dict[str, Any]] = field(default_factory=list)
    queues: dict[str, dict[str, Any]] = field(default_factory=dict)

    # Test hooks — override these to inject latency / failures.
    drop_next_ack: bool = False
    fail_next_poll: bool = False


def _msgpack_response(body: dict[str, Any], status: int = 200) -> httpx.Response:
    return httpx.Response(
        status,
        content=msgpack.packb(body, use_bin_type=True),
        headers={"content-type": "application/x-msgpack"},
    )


def _json_response(body: Any, status: int = 200) -> httpx.Response:
    return httpx.Response(
        status,
        content=json.dumps(body).encode("utf-8"),
        headers={"content-type": "application/json"},
    )


def _claim_next(state: StubState, queue_name: str) -> Optional[StubJob]:
    """FIFO claim. Mutates the job state to `running`."""
    for jid, job in state.jobs.items():
        if job.state == "queued" and job.queue == queue_name:
            job.state = "running"
            return job
    return None


def make_handler(state: StubState):
    """Build an httpx.MockTransport handler bound to ``state``."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        method = request.method

        if method == "PUT" and path == "/v1/producer/queues":
            body = msgpack.unpackb(request.content, raw=False)
            name = body["name"]
            state.queues[name] = body
            return _msgpack_response({"name": name, "state": "active"})

        if method == "POST" and path == "/v1/namespaces/default/queues":
            body = json.loads(request.content)
            name = body["name"]
            if name in state.queues:
                # Mimic CP 409 + name-collision shape.
                return _json_response(
                    {"error": f'queue "{name}" already exists'}, status=409
                )
            row = {
                "id": f"q-{name}",
                "name": name,
                "kind": body.get("kind", "fifo"),
                "state": "active",
                "memberCount": 0,
            }
            state.queues[name] = {**row, **body}
            return _json_response(row, status=201)

        if method == "PATCH" and path.startswith("/v1/namespaces/default/queues/"):
            name = path.rsplit("/", 1)[-1]
            if name not in state.queues:
                return _json_response({"error": "not found"}, status=404)
            body = json.loads(request.content)
            state.queues[name].update(body)
            return _json_response(state.queues[name])

        if method == "GET" and path.startswith("/v1/namespaces/default/queues/"):
            name = path.rsplit("/", 1)[-1]
            row = state.queues.get(name)
            if not row:
                return _json_response({"error": "not found"}, status=404)
            return _json_response(row)

        if method == "POST" and path == "/v1/producer/submit":
            body = msgpack.unpackb(request.content, raw=False)
            state.submits.append(body)
            inv_id = body.get("invocation_id") or f"inv-{len(state.jobs)+1}"
            queue = body.get("queue", "default")
            args = body.get("args_blob") or b""
            state.jobs[inv_id] = StubJob(id=inv_id, queue=queue, args_blob=args)
            return _msgpack_response({"invocation_id": inv_id, "queue": queue})

        if method == "POST" and path == "/v1/daemon/poll":
            body = msgpack.unpackb(request.content, raw=False)
            state.polls.append(body)
            if state.fail_next_poll:
                state.fail_next_poll = False
                return _msgpack_response({"error": "synthetic"}, status=500)
            queue = body.get("queue", "default")
            job = _claim_next(state, queue)
            if not job:
                return _msgpack_response({"commands": []})
            cmd = {
                "id": f"cmd-{job.id}",
                "kind": "run",
                "body": {
                    "invocation_id": job.id,
                    "function": {"module": "_queue_payload", "qualname": "x", "version": "raw"},
                    "args_blob": job.args_blob,
                    "run_config": {"queue": job.queue},
                },
            }
            return _msgpack_response({"commands": [cmd]})

        if method == "POST" and path == "/v1/daemon/ack":
            body = msgpack.unpackb(request.content, raw=False)
            state.acks.append(body)
            if state.drop_next_ack:
                state.drop_next_ack = False
                return _msgpack_response({"error": "drop"}, status=500)
            inv_id = body["invocation_id"]
            job = state.jobs.get(inv_id)
            if not job:
                return _msgpack_response({"error": "not found"}, status=404)
            job.state = body.get("state", "succeeded")
            job.result_blob = body.get("result_blob") or None
            job.error = body.get("error") or None
            return _msgpack_response({"ok": True})

        if method == "POST" and path == "/v1/producer/await":
            body = msgpack.unpackb(request.content, raw=False)
            state.awaits.append(body)
            inv_id = body["invocation_id"]
            # Long-poll: spin in 25ms increments up to the requested
            # window. Real CP uses 100ms; tighter is fine for tests.
            timeout_s = float(body.get("timeout_s") or 0.0)
            deadline = time.monotonic() + timeout_s
            terminal = {"succeeded", "failed", "killed", "timeout"}
            while True:
                job = state.jobs.get(inv_id)
                if job and job.state in terminal:
                    return _msgpack_response(
                        {
                            "state": job.state,
                            "result_blob": job.result_blob,
                            "error": job.error,
                        }
                    )
                if time.monotonic() >= deadline:
                    return _msgpack_response({"state": "pending"})
                time.sleep(0.025)

        if method == "GET" and path == "/v1/namespaces/default/workers":
            return _json_response([])

        return _json_response({"error": f"unhandled {method} {path}"}, status=404)

    return handler


def install_stub(client: Any, state: Optional[StubState] = None) -> StubState:
    """Replace the httpx.Client on a ControlPlaneClient with one wired
    to a fresh stub state. Returns the state so tests can poke it."""
    if state is None:
        state = StubState()
    old = client._client
    try:
        old.close()
    except Exception:
        pass
    client._client = httpx.Client(
        base_url=client.base_url,
        transport=httpx.MockTransport(make_handler(state)),
        headers={
            "content-type": "application/x-msgpack",
            "accept": "application/x-msgpack",
        },
    )
    return state


def make_stubbed_queue(name: str = "rpc-demo", **queue_kwargs: Any):
    """Build a :class:`dreamlake.lakeshore.queue.Queue` whose underlying
    ControlPlaneClient is wired to a fresh stub state. Returns
    ``(queue, state)``.

    The `Queue.__init__` constructs its own ControlPlaneClient and
    immediately calls ``ensure_queue``. We install the stub on a
    class-level hook before construction so the first network call
    lands on the stub, not a real CP."""
    from dreamlake.lakeshore.client import ControlPlaneClient
    from dreamlake.lakeshore.queue import Queue

    shared_state = StubState()
    original_init = ControlPlaneClient.__init__

    def patched_init(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        original_init(self, *args, **kwargs)
        install_stub(self, state=shared_state)

    # Patch only for the duration of this construction.
    ControlPlaneClient.__init__ = patched_init  # type: ignore[method-assign]
    try:
        q = Queue(name, server="http://stub", **queue_kwargs)
    finally:
        ControlPlaneClient.__init__ = original_init  # type: ignore[method-assign]
    # Ensure subsequent ControlPlaneClient() instantiations (e.g. via
    # the decorator) also see the stub. Easiest: alias the shared state
    # on the Queue object so tests can reference it directly.
    q._stub_state = shared_state  # type: ignore[attr-defined]
    return q, shared_state


__all__ = [
    "StubJob",
    "StubState",
    "make_handler",
    "install_stub",
    "make_stubbed_queue",
]
