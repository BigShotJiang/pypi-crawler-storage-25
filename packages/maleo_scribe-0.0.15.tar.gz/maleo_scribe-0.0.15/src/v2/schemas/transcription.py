from pydantic import BaseModel, Field
from typing import Annotated, Self
from uuid import UUID
from nexo.schemas.mixins.identity import (
    UUID as UUIDMixin,
    DataIdentifier,
    UUIDPrincipalId,
)
from nexo.schemas.mixins.timestamp import Duration
from ..dtos.soap import StrictSOAPDTO, SOAPDTOMixin
from ..mixins.transcription import Transcript
from ...common.dtos import (
    AudioMetadata,
    AudioMetadataMixin,
    TranscriptionMetadata,
    TranscriptionMetadataMixin,
    ProcessTranscriptMetadata,
    ProcessTranscriptMetadataMixin,
)
from ...common.mixins import Notes


class TranscribeParameter(BaseModel):
    transcription_id: Annotated[UUID, Field(..., description="Transcription's ID")]
    audio: Annotated[bytes, Field(..., description="Audio")]
    content_type: Annotated[str, Field(..., description="Content type")]
    filename: Annotated[str, Field(..., description="File name")]


class TranscribeResponseData(
    Notes[str],
    SOAPDTOMixin[StrictSOAPDTO],
    Transcript[str],
):
    pass


class InsertTranscriptionParameters(
    TranscribeResponseData,
    ProcessTranscriptMetadataMixin,
    TranscriptionMetadataMixin,
    AudioMetadataMixin,
    Duration[float],
    UUIDPrincipalId[UUID],
    UUIDMixin[UUID],
):
    @classmethod
    def from_data(
        cls,
        data: TranscribeResponseData,
        uuid: UUID,
        principal_id: UUID,
        duration: float,
        audio_metadata: AudioMetadata,
        transcription_metadata: TranscriptionMetadata,
        process_transcript_metadata: ProcessTranscriptMetadata,
    ) -> Self:
        return cls(
            uuid=uuid,
            principal_id=principal_id,
            duration=duration,
            audio_metadata=audio_metadata,
            transcription_metadata=transcription_metadata,
            process_transcript_metadata=process_transcript_metadata,
            transcript=data.transcript,
            soap=data.soap,
            notes=data.notes,
        )


class InsertTranscriptionSchema(
    TranscribeResponseData,
    ProcessTranscriptMetadataMixin,
    TranscriptionMetadataMixin,
    AudioMetadataMixin,
    Duration[float],
    UUIDPrincipalId[UUID],
    DataIdentifier,
):
    pass


class TranscriptionSchema(
    TranscribeResponseData,
    DataIdentifier,
):
    pass
