from setuptools import setup

setup(name='Login_and_Registration',
      version='1.0',
      description='A simple python login and registration package',
      author='Daniil.Prakhin',
      author_email='PrakhinDaniil@gmail.com',
      packages=['project'],
      install_requires=['jsonpickle', 'os'],
      zip_safe=False)