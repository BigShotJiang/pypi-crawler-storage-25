"""
Реалізувати систему входа та реєстрації:
+ документація
+ Pypi
"""
import os
import jsonpickle


# = КЛАС КОРИСТУВАЧА = #
class User:
    """
    Базовий клас користувача - має два стани: username, password
    """
    def __init__(self, username, password):
        self.username = username
        self.password = password


# = ФУНКЦІЯ ЧИТАННЯ ДАНИХ = #
def read_users_data(users_database):
    """
    Функція читання бази даних користувачів, якщо вона вже існує
    :param users_database: назва файлу з базою даних користувачів
    :return: повертає перелік користувачів, що вже зареєстровані в системі, або порожній список
    """
    if os.path.exists(users_database):
        with open(users_database, "rb") as users_file:
            return jsonpickle.loads(users_file.read())
    else:
        return []


# = ФУНКЦІЯ ОТРИМАННЯ ДАНИХ = #
def get_user_login():
    """
    Функція, яка отримує дані для логіна або реєстрації
    :return: повертає об'єкт класу User
    """
    user_login = input("Вкажіть логін користувача: ")
    user_password = input("Вкажіть пароль користувача: ")
    return User(user_login, user_password)


# = ФУНКЦІЯ ЗБЕРІГАННЯ ДАНИХ = #
def save_users_data(new_users_list, users_database):
    """
    Функція, яка зберігає базу даних користувачей
    :param new_users_list: перелік користувачей, які зареєстровані в системі
    :param users_database: файл, в якому будемо зберігати базу даних користувачів
    :return: повертає None
    """
    with open(users_database, "w") as users_file:
        users_file.write(jsonpickle.dumps(new_users_list))



# === ОСНОВНА ЧАСТИНА ПРОГРАМИ === #
USERS_DB = "users.json"
users_list = read_users_data(USERS_DB)

while True:
    user_choice = input("""
=== Оберіть потрібну дію ===
[1] Реєстрація в системі;
[2] Вхід до системи;
[q/Q] Завершити роботу:
""")

    if user_choice == '1':
        new_user = get_user_login()
        registration_success = True

        for single_user in users_list:
            if single_user.username == new_user.username:
                print(f"=> Увага! Користувача {new_user.username} вже зареєстрований <=")
                registration_success = False
                break

        if registration_success:
            users_list.append(new_user)
            save_users_data(users_list, USERS_DB)

    if user_choice == '2':
        if users_list:
            new_user = get_user_login()
            login_success = False

            for single_user in users_list:
                if single_user.username == new_user.username:
                    if single_user.password == new_user.password:
                        print("=> Успішний вхід в систему <=")
                        login_success = True
                        break

            if not login_success:
                print(f"=> Увага! Користувача {new_user.username} не зареєстрвовано, або пароль не вірний <=")

        else:
            print("=> Увага! Жодного користувача не зареєстровано <=")

    if user_choice.lower() == 'q':
        print("Завершуємо роботу. До побаченн!")
        break
