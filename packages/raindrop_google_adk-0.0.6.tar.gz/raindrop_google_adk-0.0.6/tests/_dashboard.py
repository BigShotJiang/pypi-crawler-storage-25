"""Shared dashboard polling + assertion helpers for the Google ADK e2e tests.

These helpers query the same TRPC ``events.list`` endpoint that the real
dashboard uses, so the tests assert the *exact* shape Raindrop renders for
customers — not just what the SDK happens to emit.

Real wire-format expectations (sourced from production `mv_events_v2`,
`raw_wide_events`, and `apps/dawn/aws/api/query/v1/services/events.ts`):

* Top-level event row keys (subset, see ``REQUIRED_EVENT_KEYS``):
  ``id``, ``_raindropDatabaseId``, ``name``, ``timestamp``, ``receivedAt``,
  ``userId``, ``aiData``, ``properties``, ``customEventId``, ``topics``,
  ``inputAttachments``, ``outputAttachments``, ``signals``, ``errorSpans``,
  ``toolCalls``, ``toolCallNames``, ``userTraits``.
* ``aiData`` keys: ``input``, ``output``, ``model``, ``convoId``.
* Each ``toolCalls[i]`` carries: ``tool_name`` (str), ``status`` (``OK`` /
  ``ERROR``), ``duration_ms`` (int), ``span_id`` (16 lowercase hex chars),
  ``started_at`` (ISO 8601 ``Z``-suffixed).
* Each ``errorSpans[i]`` carries: ``span_id``, ``span_name``, ``span_type``
  (``TOOL_CALL`` for tool errors), ``status`` (``ERROR``), ``duration_ms``,
  ``started_at``, ``output_payload`` (the error message).
* Each ``signals[i]`` (snake-case here even though the rest is camelCase,
  matching production) carries: ``name``, ``signalType`` (``default`` /
  ``feedback`` / ``edit``), ``timestamp``, ``properties``.
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.parse
from typing import Any

import pytest
import requests

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
GOOGLE_API_KEY = (
    os.getenv("GOOGLE_API_KEY")
    or os.getenv("GOOGLE_GENERATIVE_AI_API_KEY")
)
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")

skip_unless_e2e = pytest.mark.skipif(
    not all([WRITE_KEY, GOOGLE_API_KEY, DASHBOARD_TOKEN]),
    reason="RAINDROP_WRITE_KEY, GOOGLE_API_KEY, and RAINDROP_DASHBOARD_TOKEN required",
)

# Hex span ids emitted by the OpenTelemetry SDK + Traceloop are 8 bytes →
# 16 lowercase hex chars. The dashboard never re-cases them.
SPAN_ID_RE = re.compile(r"^[0-9a-f]{16}$")
ISO_8601_Z_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z$"
)

REQUIRED_EVENT_KEYS = {
    "id",
    "name",
    "timestamp",
    "userId",
    "aiData",
    "properties",
    "topics",
    "inputAttachments",
    "outputAttachments",
    "signals",
    "errorSpans",
    "toolCalls",
}

REQUIRED_AI_DATA_KEYS = {"input", "output", "model", "convoId"}


def _dashboard_get(
    path: str, *, params_json: dict[str, Any], timeout: int = 20
) -> requests.Response:
    """Issue an authenticated GET against a dashboard TRPC route.

    A 401 raises a hard error rather than skipping. Token expiry mid-run
    used to silently drop test coverage; the right response is to fail the
    suite so the operator refreshes the JWT and reruns.

    The TRPC endpoints sit behind Vercel's edge CDN, which serves stale
    responses for up to ~120s on the ``Cache-Control: public, max-age=0,
    must-revalidate`` we observe in production. Tests poll repeatedly for
    just-emitted events, so we add a per-request cache-busting query
    parameter and explicit ``Cache-Control: no-cache, no-store`` request
    headers to force a fresh upstream fetch on every poll.
    """
    encoded = urllib.parse.quote(json.dumps(params_json))
    cache_bust = str(int(time.time() * 1000))
    resp = requests.get(
        f"{BACKEND_URL}/api/trpc/{path}?input={encoded}&_cb={cache_bust}",
        headers={
            "Authorization": f"Bearer {DASHBOARD_TOKEN}",
            "Cache-Control": "no-cache, no-store",
            "Pragma": "no-cache",
        },
        timeout=timeout,
    )
    if resp.status_code == 401:
        raise RuntimeError(
            "RAINDROP_DASHBOARD_TOKEN is unauthorized (likely expired). "
            "Refresh the JWT and rerun the suite — we deliberately do not "
            "skip on auth errors so coverage is never silently lost."
        )
    resp.raise_for_status()
    return resp


def query_dashboard(limit: int = 50) -> list[dict[str, Any]]:
    """Fetch recent events from the dashboard TRPC API."""
    resp = _dashboard_get(
        "events.list",
        params_json={
            "json": {
                "limit": limit,
                "orderBy": {"field": "timestamp", "direction": "desc"},
            }
        },
    )
    return resp.json().get("result", {}).get("data", [])


def poll_events(
    user_id: str,
    *,
    min_count: int = 1,
    timeout: int = 120,
    interval: int = 5,
) -> list[dict[str, Any]]:
    """Poll until at least ``min_count`` events for ``user_id`` are available."""
    deadline = time.time() + timeout
    matched: list[dict[str, Any]] = []
    while time.time() < deadline:
        all_events = query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        if len(matched) >= min_count:
            return matched
        time.sleep(interval)
    raise TimeoutError(
        f"Expected >= {min_count} events for userId={user_id}, "
        f"got {len(matched)} after {timeout}s"
    )


def assert_event_shape(ev: dict[str, Any]) -> None:
    """Strict structural assertions for any dashboard event row."""
    missing = REQUIRED_EVENT_KEYS - ev.keys()
    assert not missing, (
        f"Dashboard event is missing required keys: {sorted(missing)}; "
        f"got keys: {sorted(ev.keys())}"
    )

    assert isinstance(ev["id"], str) and ev["id"], (
        f"event.id should be a non-empty string, got {ev['id']!r}"
    )
    assert isinstance(ev["name"], str) and ev["name"], (
        f"event.name should be a non-empty string, got {ev['name']!r}"
    )
    assert isinstance(ev["userId"], str) and ev["userId"], (
        f"event.userId should be a non-empty string, got {ev['userId']!r}"
    )
    assert isinstance(ev["timestamp"], str) and ev["timestamp"], (
        f"event.timestamp should be a non-empty string, got {ev['timestamp']!r}"
    )
    assert isinstance(ev["properties"], dict), (
        f"event.properties should be a dict, got {type(ev['properties']).__name__}"
    )
    for arr_key in ("topics", "inputAttachments", "outputAttachments", "signals", "errorSpans", "toolCalls"):
        assert isinstance(ev[arr_key], list), (
            f"event.{arr_key} should be a list, got {type(ev[arr_key]).__name__}"
        )

    ai = ev.get("aiData") or {}
    assert isinstance(ai, dict), f"aiData must be a dict, got {type(ai).__name__}"
    missing_ai = REQUIRED_AI_DATA_KEYS - ai.keys()
    assert not missing_ai, (
        f"aiData is missing required keys: {sorted(missing_ai)}; "
        f"got keys: {sorted(ai.keys())}"
    )


def assert_tool_call_shape(tc: dict[str, Any]) -> None:
    """Validate a single ``toolCalls[i]`` row matches production wire format."""
    expected_keys = {"tool_name", "status", "duration_ms", "span_id", "started_at"}
    missing = expected_keys - tc.keys()
    assert not missing, (
        f"tool_call missing keys: {sorted(missing)}; got: {sorted(tc.keys())}"
    )
    assert isinstance(tc["tool_name"], str) and tc["tool_name"], (
        f"tool_name should be a non-empty string, got {tc['tool_name']!r}"
    )
    assert tc["status"] in ("OK", "ERROR", "UNSET"), (
        f"tool_call status must be OK/ERROR/UNSET, got {tc['status']!r}"
    )
    assert isinstance(tc["duration_ms"], (int, float)), (
        f"duration_ms must be numeric, got {type(tc['duration_ms']).__name__}"
    )
    assert tc["duration_ms"] >= 0, f"duration_ms negative: {tc['duration_ms']}"
    assert isinstance(tc["span_id"], str), f"span_id must be string, got {tc['span_id']!r}"
    assert SPAN_ID_RE.match(tc["span_id"]), (
        f"span_id must be 16 lowercase hex chars, got {tc['span_id']!r}"
    )
    assert isinstance(tc["started_at"], str), (
        f"started_at must be string, got {tc['started_at']!r}"
    )
    assert ISO_8601_Z_RE.match(tc["started_at"]), (
        f"started_at must be ISO 8601 Z-suffixed, got {tc['started_at']!r}"
    )


def assert_error_span_shape(es: dict[str, Any]) -> None:
    """Validate a single ``errorSpans[i]`` row matches production wire format."""
    expected_keys = {
        "span_id",
        "span_name",
        "span_type",
        "status",
        "duration_ms",
        "started_at",
        "output_payload",
    }
    missing = expected_keys - es.keys()
    assert not missing, (
        f"error_span missing keys: {sorted(missing)}; got: {sorted(es.keys())}"
    )
    assert es["status"] == "ERROR", (
        f"error_span.status must be ERROR, got {es['status']!r}"
    )
    assert isinstance(es["span_id"], str) and SPAN_ID_RE.match(es["span_id"]), (
        f"error_span.span_id must be 16 lowercase hex chars, got {es['span_id']!r}"
    )
    assert isinstance(es["span_name"], str) and es["span_name"], (
        f"error_span.span_name must be non-empty string, got {es['span_name']!r}"
    )
    assert isinstance(es["span_type"], str) and es["span_type"], (
        f"error_span.span_type must be non-empty string, got {es['span_type']!r}"
    )
    assert isinstance(es["duration_ms"], (int, float)) and es["duration_ms"] >= 0
    assert ISO_8601_Z_RE.match(es["started_at"]), (
        f"error_span.started_at must be ISO 8601 Z-suffixed, got {es['started_at']!r}"
    )
    assert isinstance(es["output_payload"], str), (
        f"error_span.output_payload must be string, got {type(es['output_payload']).__name__}"
    )


def assert_signal_shape(sig: dict[str, Any]) -> None:
    """Validate a single ``signals[i]`` row matches production wire format.

    The dashboard TRPC ``events.list`` endpoint returns each attached signal
    with the shape:

    .. code-block:: json

       {
         "name": "thumbs_up",
         "signalType": "default",
         "timestamp": "2026-05-06 22:55:25",
         "properties": {"comment": "Spot on"}
       }
    """
    expected_keys = {"name", "signalType", "timestamp", "properties"}
    missing = expected_keys - sig.keys()
    assert not missing, (
        f"signal missing keys: {sorted(missing)}; got: {sorted(sig.keys())}"
    )
    assert sig["signalType"] in ("default", "feedback", "edit", "standard"), (
        f"signalType must be default/feedback/edit/standard, got {sig['signalType']!r}"
    )
    assert isinstance(sig["name"], str) and sig["name"], (
        f"signal.name must be non-empty string, got {sig['name']!r}"
    )
    # timestamp is a Tinybird DateTime-style string (no Z suffix).
    assert isinstance(sig["timestamp"], str), (
        f"signal.timestamp must be a string, got {sig['timestamp']!r}"
    )


_RESOURCE_EXHAUSTED_PATTERNS = (
    "RESOURCE_EXHAUSTED",
    " 429 ",
    "Quota exceeded",
)


def _looks_like_gemini_quota_error(exc: BaseException) -> bool:
    msg = str(exc)
    return (
        any(p in msg for p in _RESOURCE_EXHAUSTED_PATTERNS)
        or "ResourceExhaustedError" in type(exc).__name__
    )


def _parse_retry_delay_seconds(exc: BaseException) -> float | None:
    """Extract ``retryDelay`` (e.g. ``"50.7s"``) from a Gemini error message."""
    import re

    msg = str(exc)
    m = re.search(r"['\"]retryDelay['\"]\s*:\s*['\"](\d+(?:\.\d+)?)s['\"]", msg)
    if m:
        return float(m.group(1))
    m = re.search(r"Please retry in\s+(\d+(?:\.\d+)?)s", msg)
    if m:
        return float(m.group(1))
    return None


def call_with_gemini_backoff(
    fn,
    *,
    max_attempts: int = 4,
    default_delay_s: float = 30.0,
    max_delay_s: float = 90.0,
):
    """Execute ``fn`` and transparently retry on Gemini ``RESOURCE_EXHAUSTED``.

    Makes up to ``max_attempts`` total invocations of ``fn`` (one initial +
    ``max_attempts - 1`` retries). The Gemini API embeds a ``retryDelay``
    hint in 429 responses; we honor it (capped at ``max_delay_s``) and fall
    back to ``default_delay_s`` if the hint cannot be parsed. After the
    final attempt fails we re-raise the last exception.
    """
    import time as _time

    for attempt in range(max_attempts):
        try:
            return fn()
        except BaseException as exc:  # noqa: BLE001 - we re-raise non-quota errors
            if not _looks_like_gemini_quota_error(exc) or attempt == max_attempts - 1:
                raise
            delay = _parse_retry_delay_seconds(exc) or default_delay_s
            delay = min(max(delay + 2.0, 5.0), max_delay_s)
            _time.sleep(delay)


def collect_with_gemini_backoff(
    iter_factory,
    *,
    max_attempts: int = 4,
    default_delay_s: float = 30.0,
    max_delay_s: float = 90.0,
) -> list[Any]:
    """Drain a sync generator from ``iter_factory()`` retrying on 429.

    ``iter_factory`` must be a zero-arg callable returning a fresh generator
    each call so we can safely retry the whole iteration if Gemini 429s.

    Makes up to ``max_attempts`` total invocations (one initial +
    ``max_attempts - 1`` retries). Only **raised** ``RESOURCE_EXHAUSTED``
    errors trigger a retry — we deliberately do **not** retry on an empty
    drain: the ADK wrapper's ``interaction.begin``/``finish`` lifecycle has
    already executed by the time the generator returns, so retrying would
    create a fresh finalized "phantom" event each attempt — corrupting
    tests like ``TestE2ENoDoubleIngestion`` that count finalized events for
    a user. Empty results from ADK's silently-swallowed 429s should fail
    loudly so the test surface is honest about what actually shipped.
    """
    return call_with_gemini_backoff(
        lambda: list(iter_factory()),
        max_attempts=max_attempts,
        default_delay_s=default_delay_s,
        max_delay_s=max_delay_s,
    )


async def acollect_with_gemini_backoff(
    aiter_factory,
    *,
    max_attempts: int = 4,
    default_delay_s: float = 30.0,
    max_delay_s: float = 90.0,
) -> list[Any]:
    """Drain an async generator from ``aiter_factory()`` retrying on 429.

    Makes up to ``max_attempts`` total invocations (one initial +
    ``max_attempts - 1`` retries).
    """
    import asyncio as _asyncio

    last: BaseException | None = None
    for attempt in range(max_attempts):
        try:
            collected: list[Any] = []
            async for item in aiter_factory():
                collected.append(item)
            return collected
        except BaseException as exc:  # noqa: BLE001
            if not _looks_like_gemini_quota_error(exc) or attempt == max_attempts - 1:
                raise
            last = exc
            delay = _parse_retry_delay_seconds(exc) or default_delay_s
            delay = min(max(delay + 2.0, 5.0), max_delay_s)
            await _asyncio.sleep(delay)
    if last is not None:
        raise last
    return []
