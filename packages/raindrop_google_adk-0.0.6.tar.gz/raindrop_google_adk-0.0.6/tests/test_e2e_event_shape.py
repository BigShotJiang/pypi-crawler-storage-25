"""End-to-end shape checks for raindrop-google-adk → dashboard events.

``tests/test_e2e.py`` covers the happy paths with truthy assertions. This
file goes deeper: every field a customer sees on a real Raindrop event row
must have the exact shape, value, and type we promise — so the suite fails
loudly when the wrapper drifts away from production schemas.

Two structural invariants that ``test_e2e.py`` does not catch:

1. **No double ingestion.** ADK's sync ``Runner.run`` internally drives
   ``self.run_async`` on a worker thread. If we patch both methods at the
   class level, a single sync call risks producing **two** ingested events
   (one from the sync path, one from the inner async path). One Runner.run
   ⇒ one finalized dashboard row.
2. **Tool/error span shape parity with the dashboard.** Each entry in
   ``toolCalls`` and ``errorSpans`` must mirror the columns the dashboard's
   timeline and tool tables read. Missing/typo'd keys are a silent UI bug.

Run locally (after installing the package + its ``[adk]`` extras):

.. code-block:: bash

   export RAINDROP_WRITE_KEY=...
   export RAINDROP_DASHBOARD_TOKEN=eyJ...
   export GOOGLE_API_KEY=...
   python -m pytest tests/test_e2e_event_shape.py -v
"""

from __future__ import annotations

import asyncio
import os
import time
import uuid
from typing import Any

import pytest

from tests._dashboard import (
    GOOGLE_API_KEY,
    SPAN_ID_RE,
    WRITE_KEY,
    assert_error_span_shape,
    assert_event_shape,
    assert_tool_call_shape,
    collect_with_gemini_backoff,
    poll_events,
    skip_unless_e2e,
)

RUN_ID = uuid.uuid4().hex[:10]
# Use ``gemini-2.5-flash`` by default — it has a separate quota pool from
# ``gemini-2.0-flash``, which the wider Raindrop e2e fleet often saturates.
MODEL = os.getenv("RAINDROP_E2E_MODEL", "gemini-2.5-flash")


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_patch_state():
    """Restore Runner.run / Runner.run_async between tests so class-level
    patches do not stack and cause ghost duplicate ingestion across tests."""
    import raindrop_google_adk.wrapper as w

    original_patched = w._patched
    w._patched = False

    runner_cls = None
    original_run = None
    original_run_async = None
    try:
        from google.adk.runners import Runner

        runner_cls = Runner
        original_run = Runner.run
        original_run_async = Runner.run_async
    except ImportError:
        pass

    yield

    w._patched = original_patched
    if runner_cls is not None and original_run is not None:
        runner_cls.run = original_run
        runner_cls.run_async = original_run_async


# ---------------------------------------------------------------------------
# Real-agent helpers (kept tiny on purpose — Gemini quota is finite)
# ---------------------------------------------------------------------------


APP_NAME = "shape_app"


def _make_user(suffix: str) -> str:
    return f"e2e_shape_adk_{RUN_ID}_{suffix}"


def _make_convo(suffix: str) -> str:
    return f"e2e_shape_convo_{RUN_ID}_{suffix}"


def _get_weather(city: str) -> dict[str, Any]:
    """Stable tool — same input → same output, so we can assert on payload."""
    return {"temperature": 72, "condition": "sunny", "city": city}


def _build_agent(name: str = "shape_agent", tools=None):
    from google.adk.agents import LlmAgent

    return LlmAgent(
        name=name,
        model=MODEL,
        tools=tools or [_get_weather],
        instruction=(
            "You are a helpful assistant. ALWAYS call the get_weather tool to "
            "answer weather questions. Keep your final response short."
        ),
    )


def _build_runner(agent, app_name: str = APP_NAME):
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService

    return Runner(
        app_name=app_name,
        agent=agent,
        session_service=InMemorySessionService(),
    )


def _user_message(text: str):
    from google.genai import types

    return types.Content(parts=[types.Part(text=text)], role="user")


async def _ensure_session(runner, app_name: str, user_id: str, session_id: str):
    svc = runner.session_service
    existing = await svc.get_session(
        app_name=app_name, user_id=user_id, session_id=session_id
    )
    if existing is None:
        await svc.create_session(
            app_name=app_name, user_id=user_id, session_id=session_id
        )


def _run_sync(runner, user_id: str, session_id: str, text: str, app_name: str = APP_NAME):
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_ensure_session(runner, app_name, user_id, session_id))
    finally:
        loop.close()

    events = collect_with_gemini_backoff(
        lambda: runner.run(
            user_id=user_id, session_id=session_id, new_message=_user_message(text)
        )
    )

    final_text = None
    for event in events:
        if hasattr(event, "is_final_response") and event.is_final_response():
            if event.content and event.content.parts:
                final_text = " ".join(
                    p.text for p in event.content.parts if hasattr(p, "text") and p.text
                )
    return events, final_text


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestE2EFullEventShape:
    """Strict shape check on the most common path: setup_google_adk + sync run."""

    def test_full_event_shape_after_sync_run(self):
        from raindrop_google_adk import setup_google_adk

        user_id = _make_user("shape")
        convo_id = _make_convo("shape")
        prompt = "What's the weather in Paris?"

        rd = setup_google_adk(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        runner = _build_runner(_build_agent(name="shape_agent"))
        events, final_text = _run_sync(runner, user_id, "s-shape", prompt)
        assert events, "Runner should yield at least one event"
        assert final_text, "Runner should produce a final response"

        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)

        ev = rows[0]
        assert_event_shape(ev)

        # Strict equality on the customer-facing identity fields:
        ai = ev["aiData"]
        assert ai["input"] == prompt, (
            f"aiData.input must equal exactly the prompt sent. "
            f"prompt={prompt!r}, got={ai['input']!r}"
        )
        assert ai["convoId"] == convo_id
        assert ai["model"] and "gemini" in ai["model"].lower(), (
            f"aiData.model should contain 'gemini', got: {ai['model']!r}"
        )
        assert ai["output"], "aiData.output must be non-empty after a successful run"

        props = ev["properties"]

        # ADK-specific identity properties:
        assert props.get("google_adk.app_name") == APP_NAME
        assert props.get("google_adk.session_id") == "s-shape"
        assert props.get("google_adk.agent_name") == "shape_agent"
        assert props.get("google_adk.author") == "shape_agent"
        assert props.get("google_adk.finish_reason") == "FinishReason.STOP", (
            f"finish_reason should be FinishReason.STOP for happy path, got: "
            f"{props.get('google_adk.finish_reason')!r}"
        )

        # Token usage must be > 0 across all three counts and consistent:
        prompt_t = int(props["ai.usage.prompt_tokens"])
        completion_t = int(props["ai.usage.completion_tokens"])
        total_t = int(props["ai.usage.total_tokens"])
        assert prompt_t > 0 and completion_t > 0 and total_t > 0, (
            f"All token counts must be > 0; got prompt={prompt_t} "
            f"completion={completion_t} total={total_t}"
        )
        assert total_t >= prompt_t + completion_t, (
            f"total_tokens ({total_t}) must be >= prompt + completion "
            f"({prompt_t} + {completion_t})"
        )

        # Tool calls must mirror the production wire format exactly:
        tool_calls = ev["toolCalls"]
        assert len(tool_calls) >= 1, (
            "Expected at least one tool_call after a weather prompt; got 0"
        )
        for tc in tool_calls:
            assert_tool_call_shape(tc)
        assert any(tc["tool_name"].endswith("get_weather") for tc in tool_calls), (
            f"Expected get_weather among tool_calls, got: "
            f"{[tc['tool_name'] for tc in tool_calls]}"
        )

        # Pending row must be finalized by the time we read.
        assert "isPending" not in ev or not ev["isPending"], (
            "Event should be finalized after Runner.run + flush + shutdown"
        )


@skip_unless_e2e
class TestE2ENoDoubleIngestion:
    """One ``Runner.run`` call must produce exactly one finalized dashboard event.

    This guards against an instrumentation bug we have observed in production
    data: when ADK's sync ``Runner.run`` internally drives ``self.run_async``
    after we have class-level-patched both methods, the inner async path can
    re-enter the wrapper and emit a second event for the same logical run.
    """

    def test_one_run_one_event(self):
        from raindrop_google_adk import setup_google_adk

        user_id = _make_user("nodup")
        convo_id = _make_convo("nodup")
        prompt = "What's the weather in Berlin?"

        rd = setup_google_adk(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        runner = _build_runner(_build_agent(name="nodup_agent"))
        _run_sync(runner, user_id, "s-nodup", prompt)
        rd.flush()
        rd.shutdown()

        # Wait for at least one row, then give the pipeline a generous extra
        # window so any duplicate would have time to land.
        rows_initial = poll_events(user_id, min_count=1, timeout=120)
        time.sleep(20)
        rows_final = poll_events(user_id, min_count=1, timeout=10)

        finalized = [
            r for r in rows_final if not r.get("isPending")
        ]
        assert len(finalized) == 1, (
            "Expected exactly one finalized event for a single Runner.run call. "
            f"Got {len(finalized)} finalized events out of {len(rows_final)} total: "
            f"ids={[r.get('id') for r in rows_final]} "
            f"properties.error={[r.get('properties', {}).get('google_adk.error') for r in rows_final]}"
        )

        ev = finalized[0]
        assert ev["aiData"]["input"] == prompt
        assert ev["aiData"]["convoId"] == convo_id


@skip_unless_e2e
class TestE2ETokenAccumulationVsToolCallCount:
    """Token usage must be consistent with the number of tool round-trips we report."""

    def test_tokens_consistent_with_tool_count(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("tokcount")
        rd = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id)
        runner = _build_runner(_build_agent(name="tokcount_agent"))
        wrapped = rd.wrap(runner)

        _run_sync(wrapped, user_id, "s-tokcount", "Weather in Madrid?")
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        ev = rows[0]
        assert_event_shape(ev)

        props = ev["properties"]

        tool_calls_count = int(props.get("google_adk.tool_calls_count", "0"))
        assert tool_calls_count >= 1, (
            f"Expected tool_calls_count >= 1 for a weather prompt, got "
            f"{tool_calls_count}; tool_calls={ev['toolCalls']}"
        )

        # ADK can include reasoning between tool round-trips → completion_tokens
        # is per-LLM-call sum, must be > 0.
        prompt_t = int(props["ai.usage.prompt_tokens"])
        completion_t = int(props["ai.usage.completion_tokens"])
        assert prompt_t >= tool_calls_count, (
            "prompt_tokens should grow with each LLM/tool round trip; "
            f"prompt_tokens={prompt_t} but tool_calls_count={tool_calls_count}"
        )
        assert completion_t > 0


@skip_unless_e2e
class TestE2EConvoOrdering:
    """Multiple runs share a convo_id and timestamps must be strictly ordered."""

    def test_convo_groups_in_timestamp_order(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("convoord")
        convo_id = _make_convo("convoord")
        rd = create_raindrop_google_adk(
            api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id
        )
        runner = _build_runner(_build_agent(name="convoord_agent"))
        wrapped = rd.wrap(runner)

        cities = ["Tokyo", "Lima", "Cairo"]
        for i, city in enumerate(cities):
            _run_sync(wrapped, user_id, f"s-convoord-{i}", f"Weather in {city}?")
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id, min_count=3, timeout=180)
        finalized = [r for r in rows if not r.get("isPending")]
        assert len(finalized) >= 3

        # Every finalized row in this user's stream must carry the same convo_id.
        for r in finalized:
            assert r["aiData"]["convoId"] == convo_id, (
                f"All finalized events must carry convoId={convo_id}; "
                f"got {r['aiData']['convoId']!r}"
            )

        # Timestamps strictly non-decreasing (descending in dashboard order →
        # we sort ascending to assert).
        ascending = sorted(finalized, key=lambda r: r["timestamp"])
        for prev, nxt in zip(ascending, ascending[1:]):
            assert prev["timestamp"] <= nxt["timestamp"], (
                f"Event timestamps must be non-decreasing in run order: "
                f"{prev['timestamp']!r} > {nxt['timestamp']!r}"
            )

        captured_inputs = {r["aiData"]["input"] for r in finalized}
        for city in cities:
            expected = f"Weather in {city}?"
            assert expected in captured_inputs, (
                f"Lost the prompt for city={city!r}; captured_inputs={captured_inputs}"
            )
