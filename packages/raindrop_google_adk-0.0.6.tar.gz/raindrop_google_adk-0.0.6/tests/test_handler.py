"""Tests for Google ADK integration.

Uses unittest.mock.patch to mock the raindrop module.
Tests the Interaction-based flow (begin/finish) and telemetry extraction.

Google ADK API:
  - Runner.run()       — synchronous generator yielding Event objects
  - Runner.run_async() — async generator yielding Event objects
"""

import asyncio
import warnings
from unittest.mock import MagicMock, patch

from raindrop_google_adk.wrapper import (
    RaindropGoogleADK,
    create_raindrop_google_adk,
    setup_google_adk,
    wrap_runner,
    _extract_input_text,
    _extract_output_text,
    _extract_model_from_event,
    _build_properties,
    _is_final_response,
    _safe_str,
    _get_app_name,
    _get_agent_name_from_event,
    _process_event,
    _RunTracker,
    _build_properties_from_tracker,
)


# ============================================================
# Helper factories
# ============================================================


def _make_content(text="Hello!", role="user"):
    """Create a mock Google ADK Content object."""
    part = MagicMock()
    part.text = text
    part.inline_data = None
    part.file_data = None

    content = MagicMock()
    content.parts = [part]
    content.role = role
    return content


def _make_event(
    content_text="The weather is sunny",
    is_final=True,
    author="weather_agent",
    model_version=None,
    usage_metadata=None,
    function_calls=None,
):
    """Create a mock ADK Event."""
    event = MagicMock()

    if content_text is not None:
        content = _make_content(text=content_text, role="model")
        event.content = content
    else:
        event.content = None

    event.is_final_response = MagicMock(return_value=is_final)
    event.author = author
    event.agent_name = author
    event.model_version = model_version
    event.model = None

    if usage_metadata:
        event.usage_metadata = MagicMock()
        event.usage_metadata.prompt_token_count = usage_metadata.get("prompt_tokens")
        event.usage_metadata.candidates_token_count = usage_metadata.get("completion_tokens")
        event.usage_metadata.total_token_count = usage_metadata.get("total_tokens")
    else:
        event.usage_metadata = None

    if function_calls is not None:
        event.get_function_calls = MagicMock(return_value=function_calls)
    else:
        event.get_function_calls = MagicMock(return_value=[])

    return event


def _make_runner(app_name="test_app", events=None, async_events=None):
    """Create a mock Runner instance."""
    runner = MagicMock()
    runner.app_name = app_name

    if events is not None:
        runner.run = MagicMock(return_value=iter(events))

    if async_events is not None:
        async def mock_run_async(*args, **kwargs):
            for e in async_events:
                yield e
        runner.run_async = mock_run_async

    return runner


# ============================================================
# Test _extract_input_text
# ============================================================


class TestExtractInputText:
    """Test input extraction from Runner.run() kwargs."""

    def test_text_content(self):
        content = _make_content(text="What is the weather?")
        result = _extract_input_text({"new_message": content})
        assert result == "What is the weather?"

    def test_no_new_message(self):
        assert _extract_input_text({}) is None

    def test_none_new_message(self):
        assert _extract_input_text({"new_message": None}) is None

    def test_multi_part_content(self):
        part1 = MagicMock()
        part1.text = "Hello"
        part2 = MagicMock()
        part2.text = "World"
        content = MagicMock()
        content.parts = [part1, part2]
        result = _extract_input_text({"new_message": content})
        assert result == "Hello World"

    def test_no_text_parts(self):
        part = MagicMock()
        part.text = None
        content = MagicMock()
        content.parts = [part]
        result = _extract_input_text({"new_message": content})
        assert result is not None  # falls back to _safe_str

    def test_empty_parts(self):
        content = MagicMock()
        content.parts = []
        result = _extract_input_text({"new_message": content})
        assert result is not None  # falls back to _safe_str

    def test_extra_kwargs_ignored(self):
        content = _make_content(text="Hello")
        result = _extract_input_text({"new_message": content, "user_id": "u1", "session_id": "s1"})
        assert result == "Hello"


# ============================================================
# Test _extract_output_text
# ============================================================


class TestExtractOutputText:
    """Test output extraction from ADK Event."""

    def test_text_event(self):
        event = _make_event(content_text="The weather is sunny")
        assert _extract_output_text(event) == "The weather is sunny"

    def test_none_event(self):
        assert _extract_output_text(None) is None

    def test_no_content(self):
        event = _make_event(content_text=None)
        result = _extract_output_text(event)
        assert result is not None  # falls back to _safe_str

    def test_multi_part_output(self):
        part1 = MagicMock()
        part1.text = "The temperature"
        part2 = MagicMock()
        part2.text = "is 72F"
        content = MagicMock()
        content.parts = [part1, part2]
        event = MagicMock()
        event.content = content
        result = _extract_output_text(event)
        assert result == "The temperature is 72F"


# ============================================================
# Test _extract_model_from_event
# ============================================================


class TestExtractModelFromEvent:
    """Test model name extraction from Event."""

    def test_model_version(self):
        event = _make_event(model_version="gemini-2.0-flash")
        assert _extract_model_from_event(event) == "gemini-2.0-flash"

    def test_model_attribute(self):
        event = MagicMock()
        event.model_version = None
        event.model = "gemini-2.5-flash"
        assert _extract_model_from_event(event) == "gemini-2.5-flash"

    def test_no_model(self):
        event = MagicMock()
        event.model_version = None
        event.model = None
        assert _extract_model_from_event(event) is None

    def test_none_event(self):
        assert _extract_model_from_event(None) is None


# ============================================================
# Test _build_properties
# ============================================================


class TestBuildProperties:
    """Test properties builder with ADK-specific metadata."""

    def test_basic_properties(self):
        event = _make_event(author="weather_agent")
        props = _build_properties(event, "my_app", "user-1", "session-1")
        assert props["google_adk.app_name"] == "my_app"
        assert props["google_adk.user_id"] == "user-1"
        assert props["google_adk.session_id"] == "session-1"
        assert props["google_adk.author"] == "weather_agent"
        assert props["google_adk.agent_name"] == "weather_agent"

    def test_token_usage(self):
        event = _make_event(
            usage_metadata={"prompt_tokens": 50, "completion_tokens": 25, "total_tokens": 75}
        )
        props = _build_properties(event, "app", "user", "sess")
        assert props["ai.usage.prompt_tokens"] == 50
        assert props["ai.usage.completion_tokens"] == 25
        assert props["ai.usage.total_tokens"] == 75

    def test_tool_calls_count(self):
        fc1 = MagicMock()
        fc2 = MagicMock()
        event = _make_event(function_calls=[fc1, fc2])
        props = _build_properties(event, "app", None, None)
        assert props["google_adk.tool_calls_count"] == 2

    def test_none_event(self):
        props = _build_properties(None, "app", "user", None)
        assert props["google_adk.app_name"] == "app"
        assert props["google_adk.user_id"] == "user"
        assert "google_adk.author" not in props

    def test_no_optional_fields(self):
        props = _build_properties(None, None, None, None)
        assert "google_adk.app_name" not in props
        assert "google_adk.user_id" not in props
        assert "google_adk.session_id" not in props


# ============================================================
# Test _is_final_response
# ============================================================


class TestIsFinalResponse:
    """Test final response detection."""

    def test_final_event(self):
        event = _make_event(is_final=True)
        assert _is_final_response(event) is True

    def test_non_final_event(self):
        event = _make_event(is_final=False)
        assert _is_final_response(event) is False

    def test_no_method(self):
        event = MagicMock(spec=[])
        assert _is_final_response(event) is False


# ============================================================
# Test _safe_str
# ============================================================


class TestSafeStr:
    """Test safe string conversion."""

    def test_string_passthrough(self):
        assert _safe_str("hello") == "hello"

    def test_none(self):
        assert _safe_str(None) is None

    def test_dict(self):
        result = _safe_str({"key": "value"})
        assert "key" in result
        assert "value" in result

    def test_pydantic_model(self):
        model = MagicMock()
        model.model_dump_json = MagicMock(return_value='{"city": "Paris"}')
        result = _safe_str(model)
        assert '"city"' in result

    def test_non_serializable_falls_back_to_str(self):
        obj = object()
        result = _safe_str(obj)
        assert result is not None
        assert "object" in result

    def test_integer(self):
        assert _safe_str(42) == "42"

    def test_list(self):
        result = _safe_str(["a", "b"])
        assert "a" in result
        assert "b" in result


# ============================================================
# Test _get_app_name
# ============================================================


class TestGetAppName:
    """Test app name extraction from Runner."""

    def test_has_app_name(self):
        runner = MagicMock()
        runner.app_name = "weather_app"
        assert _get_app_name(runner) == "weather_app"

    def test_no_app_name(self):
        runner = MagicMock(spec=[])
        assert _get_app_name(runner) is None


# ============================================================
# Test _get_agent_name_from_event
# ============================================================


class TestGetAgentNameFromEvent:
    """Test agent name extraction from Event."""

    def test_agent_name_attr(self):
        event = MagicMock()
        event.agent_name = "my_agent"
        assert _get_agent_name_from_event(event) == "my_agent"

    def test_author_fallback(self):
        event = MagicMock()
        event.agent_name = None
        event.author = "agent_author"
        assert _get_agent_name_from_event(event) == "agent_author"

    def test_no_name(self):
        event = MagicMock()
        event.agent_name = None
        event.author = None
        assert _get_agent_name_from_event(event) is None


# ============================================================
# Test wrap_runner (sync)
# ============================================================


class TestWrapRunnerSync:
    """Test Runner wrapping with Interaction API (sync)."""

    def test_run_uses_begin_finish(self):
        final_event = _make_event(content_text="Sunny in SF", author="weather_agent")
        non_final = _make_event(content_text=None, is_final=False)
        runner = _make_runner(app_name="weather_app", events=[non_final, final_event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.id = "evt-123"
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="test-user")
            events = list(wrapped.run(
                user_id="test-user",
                session_id="test-session",
                new_message=_make_content("What is the weather in SF?"),
            ))

            assert len(events) == 2
            mock_rd.begin.assert_called_once()
            begin_kwargs = mock_rd.begin.call_args.kwargs
            assert begin_kwargs["user_id"] == "test-user"
            assert begin_kwargs["input"] == "What is the weather in SF?"
            assert begin_kwargs["event"] == "ai_generation"

            mock_interaction.finish.assert_called_once()
            finish_kwargs = mock_interaction.finish.call_args.kwargs
            assert finish_kwargs["output"] == "Sunny in SF"

    def test_run_error_finishes_interaction(self):
        def error_run(*args, **kwargs):
            raise RuntimeError("API Error")
            yield  # make it a generator

        runner = MagicMock()
        runner.app_name = "test_app"
        runner.run = MagicMock(side_effect=RuntimeError("API Error"))

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="test-user")
            try:
                list(wrapped.run(
                    new_message=_make_content("Hello"),
                ))
            except RuntimeError:
                pass

            mock_rd.begin.assert_called_once()
            mock_interaction.set_properties.assert_called_once()
            error_props = mock_interaction.set_properties.call_args[0][0]
            assert error_props["google_adk.error"] is True
            assert error_props["google_adk.error_message"] == "API Error"
            assert error_props.get("google_adk.app_name") == "test_app"
            mock_interaction.finish.assert_called_once()

    def test_multiple_calls_no_leak(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_rd.begin.return_value = MagicMock()

            for _ in range(5):
                runner = _make_runner(app_name="app", events=[_make_event()])
                wrapped = wrap_runner(runner, user_id="test-user")
                list(wrapped.run(new_message=_make_content("Hello")))
            assert mock_rd.begin.call_count == 5

    def test_error_in_telemetry_does_not_mask_result(self):
        event = _make_event(content_text="OK")
        runner = _make_runner(app_name="app", events=[event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.finish.side_effect = RuntimeError("telemetry broke")
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="test-user")
            events = list(wrapped.run(new_message=_make_content("Hello")))
            assert len(events) == 1
            assert events[0].content.parts[0].text == "OK"

    def test_wrap_is_idempotent(self):
        runner = _make_runner(app_name="app", events=[_make_event()])
        wrapped1 = wrap_runner(runner, user_id="u1")
        wrapped2 = wrap_runner(wrapped1, user_id="u2")
        assert wrapped1 is wrapped2  # second wrap is a no-op

    def test_wrap_skips_when_class_patched(self):
        """wrap_runner should skip instance wrapping when class-level patch is active."""
        import raindrop_google_adk.wrapper as w
        original_patched = w._patched
        try:
            w._patched = True
            runner = _make_runner(app_name="app", events=[_make_event()])
            original_run = runner.run
            wrapped = wrap_runner(runner)
            assert wrapped is runner
            assert wrapped.run is original_run
            assert getattr(wrapped, "_raindrop_wrapped", False) is True
        finally:
            w._patched = original_patched

    def test_wrap_warns_when_class_patched_with_user_id(self):
        """wrap_runner should warn when user_id/convo_id are silently discarded."""
        import raindrop_google_adk.wrapper as w
        original_patched = w._patched
        try:
            w._patched = True
            runner = _make_runner(app_name="app", events=[_make_event()])
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                wrap_runner(runner, user_id="u1", convo_id="c1")
                assert len(caught) == 1
                assert "class-level patch" in str(caught[0].message)
        finally:
            w._patched = original_patched

    def test_wrap_no_warn_when_class_patched_without_overrides(self):
        """wrap_runner should NOT warn when no user_id/convo_id passed."""
        import raindrop_google_adk.wrapper as w
        original_patched = w._patched
        try:
            w._patched = True
            runner = _make_runner(app_name="app", events=[_make_event()])
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                wrap_runner(runner)
                assert len(caught) == 0
        finally:
            w._patched = original_patched


# ============================================================
# Test wrap_runner (async)
# ============================================================


class TestWrapRunnerAsync:
    """Test Runner wrapping with Interaction API (async)."""

    def test_run_async_uses_begin_finish(self):
        final_event = _make_event(content_text="Berlin", author="geo_agent")

        async def mock_run_async(*args, **kwargs):
            yield final_event

        runner = MagicMock()
        runner.app_name = "geo_app"
        runner.run = MagicMock(return_value=iter([]))
        runner.run_async = mock_run_async

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="test-user")

            async def collect():
                events = []
                async for event in wrapped.run_async(
                    user_id="test-user",
                    session_id="test-session",
                    new_message=_make_content("Capital of Germany?"),
                ):
                    events.append(event)
                return events

            events = asyncio.run(collect())
            assert len(events) == 1
            mock_rd.begin.assert_called_once()
            mock_interaction.finish.assert_called_once()

    def test_run_async_error_finishes_interaction(self):
        async def error_run_async(*args, **kwargs):
            raise RuntimeError("Async Error")
            yield  # make it an async generator

        runner = MagicMock()
        runner.app_name = "app"
        runner.run = MagicMock(return_value=iter([]))
        runner.run_async = error_run_async

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="test-user")

            async def collect():
                events = []
                async for event in wrapped.run_async(
                    new_message=_make_content("Hello"),
                ):
                    events.append(event)
                return events

            try:
                asyncio.run(collect())
            except RuntimeError:
                pass

            mock_rd.begin.assert_called_once()
            mock_interaction.set_properties.assert_called_once()
            error_props = mock_interaction.set_properties.call_args[0][0]
            assert error_props["google_adk.error"] is True
            mock_interaction.finish.assert_called_once()


# ============================================================
# Test create_raindrop_google_adk (backward compat)
# ============================================================


class TestCreateRaindropGoogleAdk:
    """Test the factory function returns RaindropGoogleADK instance."""

    def test_returns_instance(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            result = create_raindrop_google_adk(api_key="test-write-key")
            assert isinstance(result, RaindropGoogleADK)
            mock_rd.init.assert_called_once_with(
                api_key="test-write-key", tracing_enabled=True, bypass_otel_for_tools=True,
            )

    def test_passes_tracing_params(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            create_raindrop_google_adk(
                api_key="test-write-key",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
            mock_rd.init.assert_called_once_with(
                api_key="test-write-key", tracing_enabled=False, bypass_otel_for_tools=False,
            )

    def test_has_wrap_flush_shutdown(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            result = create_raindrop_google_adk(api_key="test-write-key")
            assert callable(result.wrap)
            assert callable(result.flush)
            assert callable(result.shutdown)

    def test_wrap_creates_wrapped_instance(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            result = create_raindrop_google_adk(api_key="test-write-key", user_id="u1")
            runner = _make_runner(app_name="app", events=[_make_event()])
            wrapped = result.wrap(runner)
            assert getattr(wrapped, "_raindrop_wrapped", False) is True


# ============================================================
# Test setup_google_adk (backward compat)
# ============================================================


class TestSetupGoogleAdk:
    """Test the setup factory function returns RaindropGoogleADK instance."""

    def test_returns_instance(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            with patch("raindrop_google_adk.wrapper._patch_runner") as mock_patch:
                result = setup_google_adk(api_key="test-write-key")
                assert isinstance(result, RaindropGoogleADK)
                mock_patch.assert_called_once()

    def test_has_flush_shutdown(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            with patch("raindrop_google_adk.wrapper._patch_runner"):
                result = setup_google_adk(api_key="test-write-key")
                assert callable(result.flush)
                assert callable(result.shutdown)


# ============================================================
# Test RaindropGoogleADK class
# ============================================================


class TestRaindropGoogleADKClass:
    """Test the class-based API."""

    def test_instantiation_with_api_key(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            instance = RaindropGoogleADK(api_key="test-write-key", user_id="u1", convo_id="c1")
            mock_rd.init.assert_called_once_with(
                api_key="test-write-key", tracing_enabled=True, bypass_otel_for_tools=True,
            )
            assert instance._api_key == "test-write-key"
            assert instance._user_id == "u1"
            assert instance._convo_id == "c1"

    def test_tracing_params_passthrough(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            RaindropGoogleADK(
                api_key="test-write-key",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
            mock_rd.init.assert_called_once_with(
                api_key="test-write-key", tracing_enabled=False, bypass_otel_for_tools=False,
            )

    def test_empty_api_key_passes_empty_string(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                RaindropGoogleADK()
            mock_rd.init.assert_called_once_with(
                api_key="", tracing_enabled=True, bypass_otel_for_tools=True,
            )

    def test_instantiation_without_api_key_warns(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropGoogleADK()
                assert len(w) == 1
                assert "api_key not provided" in str(w[0].message)

    def test_instantiation_with_empty_string_warns(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropGoogleADK(api_key="")
                assert len(w) == 1
                assert "api_key not provided" in str(w[0].message)

    def test_setup_calls_patch_runner(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            with patch("raindrop_google_adk.wrapper._patch_runner") as mock_patch:
                instance = RaindropGoogleADK(api_key="test-write-key", user_id="u1", convo_id="c1")
                instance.setup()
                mock_patch.assert_called_once_with(user_id="u1", convo_id="c1")

    def test_wrap_calls_wrap_runner(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            instance = RaindropGoogleADK(api_key="test-write-key", user_id="u1")
            runner = _make_runner(app_name="app", events=[_make_event()])
            wrapped = instance.wrap(runner)
            assert getattr(wrapped, "_raindrop_wrapped", False) is True

    def test_flush_delegates(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            instance = RaindropGoogleADK(api_key="test-write-key")
            instance.flush()
            mock_rd.flush.assert_called_once()

    def test_shutdown_delegates(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            instance = RaindropGoogleADK(api_key="test-write-key")
            instance.shutdown()
            mock_rd.shutdown.assert_called_once()

    def test_debug_flag_sets_log_level(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            import logging
            logger = logging.getLogger("raindrop_google_adk.wrapper")
            original_level = logger.level
            try:
                RaindropGoogleADK(api_key="test-write-key", debug=True)
                assert logger.level == logging.DEBUG
            finally:
                logger.setLevel(original_level)


# ============================================================
# Test identify() and track_signal()
# ============================================================


class TestIdentifyAndTrackSignal:
    """Test identify and track_signal passthrough methods."""

    def test_identify_calls_raindrop(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            instance = RaindropGoogleADK(api_key="test-write-key")
            instance.identify(user_id="user-123", traits={"plan": "pro"})
            mock_rd.identify.assert_called_once_with(
                user_id="user-123", traits={"plan": "pro"}
            )

    def test_identify_defaults_empty_traits(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            instance = RaindropGoogleADK(api_key="test-write-key")
            instance.identify(user_id="user-123")
            mock_rd.identify.assert_called_once_with(
                user_id="user-123", traits={}
            )

    def test_track_signal_calls_raindrop_with_all_params(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            instance = RaindropGoogleADK(api_key="test-write-key")
            instance.track_signal(
                event_id="evt-123",
                name="thumbs_up",
                signal_type="feedback",
                timestamp="2026-01-01T00:00:00Z",
                properties={"source": "chat"},
                attachment_id="att-1",
                comment="Great response",
                after="edited text",
                sentiment="POSITIVE",
            )
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt-123",
                name="thumbs_up",
                signal_type="feedback",
                timestamp="2026-01-01T00:00:00Z",
                properties={"source": "chat"},
                attachment_id="att-1",
                comment="Great response",
                after="edited text",
                sentiment="POSITIVE",
            )

    def test_track_signal_defaults(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            instance = RaindropGoogleADK(api_key="test-write-key")
            instance.track_signal(event_id="evt-456", name="error")
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt-456",
                name="error",
                signal_type="default",
                timestamp=None,
                properties=None,
                attachment_id=None,
                comment=None,
                after=None,
                sentiment=None,
            )



# ============================================================
# Test token usage extraction via interaction
# ============================================================


class TestTokenUsageExtraction:
    """Test that token usage from ADK events is captured."""

    def test_tokens_forwarded_to_properties(self):
        event = _make_event(
            content_text="Result",
            usage_metadata={"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
        )
        runner = _make_runner(app_name="app", events=[event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.id = "evt-tok"
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="user")
            list(wrapped.run(new_message=_make_content("Test")))

            finish_kwargs = mock_interaction.finish.call_args.kwargs
            props = finish_kwargs["properties"]
            assert props["ai.usage.prompt_tokens"] == 100
            assert props["ai.usage.completion_tokens"] == 50
            assert props["ai.usage.total_tokens"] == 150


# ============================================================
# Test model tracking via _track_ai_partial
# ============================================================


class TestModelTracking:
    """Test model name is sent via _track_ai_partial."""

    def test_model_version_tracked(self):
        event = _make_event(content_text="Result", model_version="gemini-2.0-flash")
        runner = _make_runner(app_name="app", events=[event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.id = "evt-model"
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="user")
            list(wrapped.run(new_message=_make_content("Test")))

            mock_rd._track_ai_partial.assert_called()
            partial_kwargs = mock_rd.PartialTrackAIEvent.call_args.kwargs
            assert partial_kwargs["event_id"] == "evt-model"
            assert partial_kwargs["ai_data"] == {"model": "gemini-2.0-flash"}


# ============================================================
# Test generator early termination (GeneratorExit)
# ============================================================


class TestGeneratorEarlyTermination:
    """Verify interaction is finalized when consumer breaks out of generator."""

    def test_sync_break_finishes_interaction(self):
        events = [
            _make_event(content_text="step 1", is_final=False),
            _make_event(content_text="step 2", is_final=False),
            _make_event(content_text="final", is_final=True),
        ]
        runner = _make_runner(app_name="app", events=events)

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.id = "evt-break"
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="u1")
            gen = wrapped.run(
                user_id="u1", session_id="s1",
                new_message=_make_content("Hello"),
            )
            first = next(gen)
            assert first.content.parts[0].text == "step 1"
            gen.close()

            mock_interaction.finish.assert_called_once()

    def test_async_break_finishes_interaction(self):
        events = [
            _make_event(content_text="async step 1", is_final=False),
            _make_event(content_text="async final", is_final=True),
        ]

        async def mock_run_async(*args, **kwargs):
            for e in events:
                yield e

        runner = MagicMock()
        runner.app_name = "app"
        runner.run = MagicMock(return_value=iter([]))
        runner.run_async = mock_run_async

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.id = "evt-async-break"
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="u1")

            async def consume_one():
                async for event in wrapped.run_async(
                    user_id="u1", session_id="s1",
                    new_message=_make_content("Hi"),
                ):
                    return event

            asyncio.run(consume_one())
            mock_interaction.finish.assert_called_once()


# ============================================================
# Test None interaction handling
# ============================================================


class TestNoneInteractionHandling:
    """When raindrop.begin() returns None, events still flow."""

    def test_sync_none_interaction_still_yields(self):
        events = [_make_event(content_text="OK")]
        runner = _make_runner(app_name="app", events=events)

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_rd.begin.return_value = None

            wrapped = wrap_runner(runner, user_id="u1")
            result = list(wrapped.run(new_message=_make_content("Test")))
            assert len(result) == 1
            assert result[0].content.parts[0].text == "OK"

    def test_async_none_interaction_still_yields(self):
        events = [_make_event(content_text="Async OK")]

        async def mock_run_async(*args, **kwargs):
            for e in events:
                yield e

        runner = MagicMock()
        runner.app_name = "app"
        runner.run = MagicMock(return_value=iter([]))
        runner.run_async = mock_run_async

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_rd.begin.return_value = None

            wrapped = wrap_runner(runner, user_id="u1")

            async def collect():
                return [e async for e in wrapped.run_async(
                    new_message=_make_content("Test"),
                )]

            result = asyncio.run(collect())
            assert len(result) == 1
            assert result[0].content.parts[0].text == "Async OK"


# ============================================================
# Test multiple final events
# ============================================================


class TestMultipleFinalEvents:
    """When multiple events are final, last one wins."""

    def test_last_final_event_used_for_output(self):
        first_final = _make_event(content_text="First final", is_final=True)
        second_final = _make_event(content_text="Second final", is_final=True)
        runner = _make_runner(app_name="app", events=[first_final, second_final])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.id = "evt-multi"
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="u1")
            result = list(wrapped.run(new_message=_make_content("Test")))
            assert len(result) == 2

            finish_kwargs = mock_interaction.finish.call_args.kwargs
            assert finish_kwargs["output"] == "Second final"


# ============================================================
# Test empty and edge inputs
# ============================================================


class TestEmptyAndEdgeInputs:
    """Edge cases for input extraction."""

    def test_empty_string_input(self):
        part = MagicMock()
        part.text = ""
        content = MagicMock()
        content.parts = [part]
        result = _extract_input_text({"new_message": content})
        assert result is not None

    def test_message_without_parts_attr(self):
        msg = "plain string message"
        result = _extract_input_text({"new_message": msg})
        assert result is not None
        assert "plain string" in result


# ============================================================
# Test session_id type coercion
# ============================================================


class TestSessionIdTypeCoercion:
    """session_id gets str() coerced in properties."""

    def test_int_session_id(self):
        props = _build_properties(None, "app", "user", "42")
        assert props["google_adk.session_id"] == "42"

    def test_none_session_id(self):
        props = _build_properties(None, "app", "user", None)
        assert "google_adk.session_id" not in props

    def test_session_id_coerced_in_finish(self):
        event = _make_event(content_text="Done")
        runner = _make_runner(app_name="app", events=[event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.id = "evt-sess"
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="u1")
            list(wrapped.run(
                user_id="u1", session_id=12345,
                new_message=_make_content("Test"),
            ))

            finish_kwargs = mock_interaction.finish.call_args.kwargs
            assert finish_kwargs["properties"]["google_adk.session_id"] == "12345"


# ============================================================
# Test user_id fallback chain
# ============================================================


class TestUserIdFallbackChain:
    """user_id from kwargs vs wrapper fallback."""

    def test_kwargs_user_id_used(self):
        event = _make_event(content_text="OK")
        runner = _make_runner(app_name="app", events=[event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_rd.begin.return_value = MagicMock()
            wrapped = wrap_runner(runner, user_id="wrapper-user")
            list(wrapped.run(
                user_id="kwargs-user", session_id="s1",
                new_message=_make_content("Hi"),
            ))
            assert mock_rd.begin.call_args.kwargs["user_id"] == "kwargs-user"

    def test_none_kwargs_falls_back_to_wrapper(self):
        event = _make_event(content_text="OK")
        runner = _make_runner(app_name="app", events=[event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_rd.begin.return_value = MagicMock()
            wrapped = wrap_runner(runner, user_id="wrapper-user")
            list(wrapped.run(
                user_id=None, session_id="s1",
                new_message=_make_content("Hi"),
            ))
            assert mock_rd.begin.call_args.kwargs["user_id"] == "wrapper-user"

    def test_no_user_id_anywhere_uses_unknown(self):
        event = _make_event(content_text="OK")
        runner = _make_runner(app_name="app", events=[event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_rd.begin.return_value = MagicMock()
            wrapped = wrap_runner(runner, user_id=None)
            list(wrapped.run(
                new_message=_make_content("Hi"),
            ))
            assert mock_rd.begin.call_args.kwargs["user_id"] == "unknown"


# ============================================================
# Test concurrent sync runs
# ============================================================


class TestConcurrentSyncRuns:
    """Two wrapped runners get distinct interactions."""

    def test_two_runners_distinct_event_ids(self):
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            interaction_a = MagicMock()
            interaction_a.id = "evt-a"
            interaction_b = MagicMock()
            interaction_b.id = "evt-b"
            mock_rd.begin.side_effect = [interaction_a, interaction_b]

            runner_a = _make_runner(app_name="app-a", events=[_make_event(content_text="A")])
            runner_b = _make_runner(app_name="app-b", events=[_make_event(content_text="B")])
            wrapped_a = wrap_runner(runner_a, user_id="ua")
            wrapped_b = wrap_runner(runner_b, user_id="ub")

            list(wrapped_a.run(new_message=_make_content("Q-A")))
            list(wrapped_b.run(new_message=_make_content("Q-B")))

            assert mock_rd.begin.call_count == 2
            assert interaction_a.finish.call_count == 1
            assert interaction_b.finish.call_count == 1
            assert interaction_a.finish.call_args.kwargs["output"] == "A"
            assert interaction_b.finish.call_args.kwargs["output"] == "B"


class TestInnerAsyncDetection:
    """Stack-inspection guard for the sync-run re-entry protection.

    The wrapper distinguishes ADK's inner ``run_async`` (driven by
    ``Runner.run`` -> ``_invoke_run_async`` on a worker thread) from any
    other ``run_async`` invocation by walking the synchronous frame chain.
    Per-call detection is required so that an external direct
    ``run_async`` from another thread on the *same* runner instance is
    still instrumented while a sync run is in flight — the per-instance
    refcount it replaces would have silently dropped that external call.
    """

    @staticmethod
    def _make_fake_invoke(
        async_body: bool,
        module_name: str = "google.adk.runners",
    ):
        """Build a function literally named ``_invoke_run_async`` whose
        ``__name__`` global matches ADK's runners module so that stack
        inspection sees the same frame layout as the real ADK driver.
        """
        import textwrap

        src = textwrap.dedent(
            """
            async def _invoke_run_async(callee):
                return await callee()
            """
            if async_body
            else """
            def _invoke_run_async(callee):
                return callee()
            """
        )
        fake_globals = {"__name__": module_name, "__builtins__": __builtins__}
        exec(compile(src, f"<fake:{module_name}>", "exec"), fake_globals)
        return fake_globals["_invoke_run_async"]

    def test_returns_false_when_invoked_directly(self):
        from raindrop_google_adk.wrapper import _is_inner_async_from_adk_sync_run

        assert _is_inner_async_from_adk_sync_run() is False

    def test_returns_true_when_invoked_under_adk_invoke_run_async_frame(self):
        from raindrop_google_adk.wrapper import _is_inner_async_from_adk_sync_run

        fake_invoke = self._make_fake_invoke(async_body=False)

        async def callee():
            return _is_inner_async_from_adk_sync_run()

        # Sync caller: drive the fake invoker, which calls the checker.
        assert fake_invoke(lambda: _is_inner_async_from_adk_sync_run()) is True

        # Async caller: same module/name — should also be detected.
        async_invoke = self._make_fake_invoke(async_body=True)
        assert asyncio.run(async_invoke(callee)) is True

    def test_returns_false_for_unrelated_module_with_same_function_name(self):
        from raindrop_google_adk.wrapper import _is_inner_async_from_adk_sync_run

        # Same function name, but defined in a *different* module — must
        # not be confused with ADK's frame.
        fake_invoke = self._make_fake_invoke(
            async_body=False, module_name="some.other.module"
        )
        assert fake_invoke(lambda: _is_inner_async_from_adk_sync_run()) is False

    def test_returns_true_for_submodules_of_google_adk_runners(self):
        from raindrop_google_adk.wrapper import _is_inner_async_from_adk_sync_run

        fake_invoke = self._make_fake_invoke(
            async_body=False, module_name="google.adk.runners.internal"
        )
        assert fake_invoke(lambda: _is_inner_async_from_adk_sync_run()) is True

    def test_concurrent_external_run_async_not_skipped(self):
        """Direct ``run_async`` on a thread that does NOT have ADK's
        ``_invoke_run_async`` on its stack must instrument normally, even
        while another thread is mid-sync-run on the same runner.
        """
        import threading

        from raindrop_google_adk.wrapper import _is_inner_async_from_adk_sync_run

        fake_invoke = self._make_fake_invoke(async_body=False)
        sync_thread_started = threading.Event()
        let_sync_finish = threading.Event()
        results: dict[str, bool] = {}

        def sync_thread():
            def held_callee():
                sync_thread_started.set()
                let_sync_finish.wait(timeout=2)
                return _is_inner_async_from_adk_sync_run()

            results["inner"] = fake_invoke(held_callee)

        def external_thread():
            sync_thread_started.wait(timeout=2)
            results["external"] = _is_inner_async_from_adk_sync_run()
            let_sync_finish.set()

        t_sync = threading.Thread(target=sync_thread)
        t_ext = threading.Thread(target=external_thread)
        t_sync.start()
        t_ext.start()
        t_sync.join(timeout=5)
        t_ext.join(timeout=5)

        assert results["inner"] is True, (
            "Inner async driven by ADK's Runner.run must be detected as inner"
        )
        assert results["external"] is False, (
            "Concurrent external run_async on a different thread must NOT "
            "be falsely classified as inner — that would silently drop its "
            "instrumentation"
        )

    def test_instrumented_run_async_skips_only_when_under_invoke_run_async(self):
        """End-to-end: ``_instrumented_run_async`` must call ``raindrop.begin``
        zero times when invoked under a fake ``_invoke_run_async`` frame
        (matching ADK's runners module), and exactly once when invoked
        directly — even concurrently on the same runner instance.
        """
        import threading

        from raindrop_google_adk.wrapper import _instrumented_run_async

        runner = MagicMock()
        runner.app_name = "app"

        async def fake_original_run_async(*args, **kwargs):
            yield _make_event(content_text="inner-event-text", is_final=True)

        async def drive(coro_factory):
            agen = coro_factory()
            async for _ in agen:
                pass

        # 1. Inner-async path: invoked under a fake `_invoke_run_async`
        #    frame in `google.adk.runners`. begin() must not be called.
        fake_invoke_globals = {
            "__name__": "google.adk.runners",
            "__builtins__": __builtins__,
            "drive": drive,
            "asyncio": asyncio,
        }
        exec(
            compile(
                "def _invoke_run_async(coro_factory):\n"
                "    asyncio.run(drive(coro_factory))\n",
                "<fake:google.adk.runners>",
                "exec",
            ),
            fake_invoke_globals,
        )
        fake_invoke = fake_invoke_globals["_invoke_run_async"]

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_raindrop:
            mock_raindrop.begin.return_value = MagicMock()

            def _make_inner_agen():
                return _instrumented_run_async(
                    fake_original_run_async, runner, (), {}, None, None,
                )

            fake_invoke(_make_inner_agen)
            assert mock_raindrop.begin.call_count == 0, (
                "Inner async loop driven by ADK's Runner.run must bypass "
                "instrumentation to avoid double-ingestion"
            )

        # 2. External path: direct call, no `_invoke_run_async` on stack.
        #    begin() must be called exactly once.
        with patch("raindrop_google_adk.wrapper.raindrop") as mock_raindrop:
            mock_raindrop.begin.return_value = MagicMock()
            asyncio.run(
                drive(
                    lambda: _instrumented_run_async(
                        fake_original_run_async, runner, (), {}, None, None,
                    )
                )
            )
            assert mock_raindrop.begin.call_count == 1, (
                "Direct external run_async (no inner frame) must be "
                "instrumented exactly once"
            )

        # 3. Concurrent: an external direct call on one thread while another
        #    thread is mid-inner-async on the same runner. Begin must fire
        #    only for the external thread.
        external_started = threading.Event()
        let_inner_finish = threading.Event()

        async def held_inner_run_async(*args, **kwargs):
            external_started.wait(timeout=2)
            let_inner_finish.wait(timeout=2)
            yield _make_event(content_text="inner", is_final=True)

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_raindrop:
            mock_raindrop.begin.return_value = MagicMock()

            def inner_thread_target():
                def _make_held_inner_agen():
                    return _instrumented_run_async(
                        held_inner_run_async, runner, (), {}, None, None,
                    )
                fake_invoke(_make_held_inner_agen)

            def external_thread_target():
                external_started.set()
                asyncio.run(
                    drive(
                        lambda: _instrumented_run_async(
                            fake_original_run_async, runner, (), {}, None, None,
                        )
                    )
                )
                let_inner_finish.set()

            t_inner = threading.Thread(target=inner_thread_target)
            t_ext = threading.Thread(target=external_thread_target)
            t_inner.start()
            t_ext.start()
            t_ext.join(timeout=5)
            t_inner.join(timeout=5)

            assert mock_raindrop.begin.call_count == 1, (
                f"Expected exactly one begin() call (from the external "
                f"thread), got {mock_raindrop.begin.call_count}. The inner "
                f"thread's run_async must be skipped via stack inspection, "
                f"and the external thread's run_async must instrument "
                f"despite a concurrent in-flight sync run on the same runner."
            )


# ============================================================
# Helper: mock events with function calls / responses
# ============================================================


def _make_function_call_event(calls, author="agent", model_version=None):
    """Create an event with function calls (tool invocations)."""
    event = MagicMock()
    event.content = None
    event.is_final_response = MagicMock(return_value=False)
    event.author = author
    event.agent_name = author
    event.model_version = model_version
    event.model = None
    event.usage_metadata = None
    event.error_code = None
    event.error_message = None
    event.branch = None
    event.finish_reason = None

    fc_mocks = []
    for c in calls:
        fc = MagicMock()
        fc.id = c.get("id", c["name"])
        fc.name = c["name"]
        fc.args = c.get("args")
        fc_mocks.append(fc)
    event.get_function_calls = MagicMock(return_value=fc_mocks)
    event.get_function_responses = MagicMock(return_value=[])
    return event


def _make_function_response_event(responses, author="agent"):
    """Create an event with function responses (tool results)."""
    event = MagicMock()
    event.content = None
    event.is_final_response = MagicMock(return_value=False)
    event.author = author
    event.agent_name = author
    event.model_version = None
    event.model = None
    event.usage_metadata = None
    event.error_code = None
    event.error_message = None
    event.branch = None
    event.finish_reason = None

    fr_mocks = []
    for r in responses:
        fr = MagicMock()
        fr.id = r.get("id", r["name"])
        fr.name = r["name"]
        fr.response = r.get("response", {})
        fr_mocks.append(fr)
    event.get_function_calls = MagicMock(return_value=[])
    event.get_function_responses = MagicMock(return_value=fr_mocks)
    return event


def _make_model_event(text="Response", model_version="gemini-2.0-flash",
                      usage=None, is_final=True, author="agent",
                      error_code=None, error_message=None,
                      branch=None, finish_reason=None):
    """Create a model response event with optional metadata."""
    event = _make_event(
        content_text=text, is_final=is_final, author=author,
        model_version=model_version, usage_metadata=usage,
    )
    event.error_code = error_code
    event.error_message = error_message
    event.branch = branch
    event.finish_reason = finish_reason
    event.get_function_calls = MagicMock(return_value=[])
    event.get_function_responses = MagicMock(return_value=[])
    return event


# ============================================================
# Test _process_event and _RunTracker
# ============================================================


class TestToolTracking:
    """Verify individual tool spans are created via interaction.track_tool()."""

    def test_single_tool_call_tracked(self):
        tracker = _RunTracker()
        interaction = MagicMock()

        fc_event = _make_function_call_event([
            {"id": "fc-1", "name": "get_weather", "args": {"city": "Paris"}},
        ])
        _process_event(fc_event, interaction, tracker)
        assert "fc-1" in tracker.pending_calls
        assert tracker.pending_calls["fc-1"].name == "get_weather"

        fr_event = _make_function_response_event([
            {"id": "fc-1", "name": "get_weather", "response": {"temperature": 72}},
        ])
        _process_event(fr_event, interaction, tracker)
        assert "fc-1" not in tracker.pending_calls
        assert tracker.tool_call_names == ["get_weather"]

        interaction.track_tool.assert_called_once()
        call_kwargs = interaction.track_tool.call_args.kwargs
        assert call_kwargs["name"] == "get_weather"
        assert call_kwargs["input"] == {"city": "Paris"}
        assert call_kwargs["output"] == {"temperature": 72}
        assert call_kwargs["error"] is None
        assert call_kwargs["duration_ms"] >= 0

    def test_tool_error_tracked(self):
        tracker = _RunTracker()
        interaction = MagicMock()

        _process_event(
            _make_function_call_event([{"id": "fc-err", "name": "bad_tool", "args": {}}]),
            interaction, tracker,
        )
        _process_event(
            _make_function_response_event([
                {"id": "fc-err", "name": "bad_tool", "response": {"error": "something broke"}},
            ]),
            interaction, tracker,
        )

        call_kwargs = interaction.track_tool.call_args.kwargs
        assert call_kwargs["name"] == "bad_tool"
        assert call_kwargs["output"] is None
        assert isinstance(call_kwargs["error"], RuntimeError)
        assert "something broke" in str(call_kwargs["error"])

    def test_multiple_tools_tracked(self):
        tracker = _RunTracker()
        interaction = MagicMock()

        _process_event(
            _make_function_call_event([
                {"id": "fc-a", "name": "tool_a", "args": {"x": 1}},
                {"id": "fc-b", "name": "tool_b", "args": {"y": 2}},
            ]),
            interaction, tracker,
        )
        assert len(tracker.pending_calls) == 2

        _process_event(
            _make_function_response_event([
                {"id": "fc-a", "name": "tool_a", "response": {"result": "a"}},
            ]),
            interaction, tracker,
        )
        _process_event(
            _make_function_response_event([
                {"id": "fc-b", "name": "tool_b", "response": {"result": "b"}},
            ]),
            interaction, tracker,
        )

        assert len(tracker.pending_calls) == 0
        assert tracker.tool_call_names == ["tool_a", "tool_b"]
        assert interaction.track_tool.call_count == 2

    def test_none_interaction_skips_track_tool(self):
        tracker = _RunTracker()
        _process_event(
            _make_function_call_event([{"id": "fc-x", "name": "t", "args": {}}]),
            None, tracker,
        )
        _process_event(
            _make_function_response_event([{"id": "fc-x", "name": "t", "response": {}}]),
            None, tracker,
        )
        assert tracker.tool_call_names == ["t"]

    def test_tool_names_in_properties(self):
        tracker = _RunTracker()
        tracker.tool_call_names = ["get_weather", "search"]
        props = _build_properties_from_tracker(tracker, "app", "user", "sess")
        assert props["google_adk.tool_calls_count"] == 2
        assert '"get_weather"' in props["google_adk.tool_call_names"]
        assert '"search"' in props["google_adk.tool_call_names"]


class TestTokenAccumulation:
    """Verify tokens are accumulated across multiple events."""

    def test_accumulates_across_events(self):
        tracker = _RunTracker()
        interaction = MagicMock()

        event1 = _make_model_event(
            text="thinking...", is_final=False,
            usage={"prompt_tokens": 50, "completion_tokens": 10, "total_tokens": 60},
        )
        _process_event(event1, interaction, tracker)

        event2 = _make_model_event(
            text="answer", is_final=True,
            usage={"prompt_tokens": 80, "completion_tokens": 20, "total_tokens": 100},
        )
        _process_event(event2, interaction, tracker)

        assert tracker.total_prompt_tokens == 130
        assert tracker.total_completion_tokens == 30
        assert tracker.total_tokens == 160

    def test_accumulated_tokens_in_properties(self):
        tracker = _RunTracker()
        tracker.total_prompt_tokens = 200
        tracker.total_completion_tokens = 80
        tracker.total_tokens = 280
        tracker.cached_tokens = 50
        tracker.thoughts_tokens = 30

        props = _build_properties_from_tracker(tracker, None, None, None)
        assert props["ai.usage.prompt_tokens"] == 200
        assert props["ai.usage.completion_tokens"] == 80
        assert props["ai.usage.total_tokens"] == 280
        assert props["ai.usage.cached_tokens"] == 50
        assert props["ai.usage.thoughts_tokens"] == 30

    def test_zero_tokens_omitted(self):
        tracker = _RunTracker()
        props = _build_properties_from_tracker(tracker, None, None, None)
        assert "ai.usage.prompt_tokens" not in props
        assert "ai.usage.completion_tokens" not in props
        assert "ai.usage.cached_tokens" not in props

    def test_no_usage_metadata_safe(self):
        tracker = _RunTracker()
        interaction = MagicMock()
        event = _make_model_event(usage=None, is_final=True)
        _process_event(event, interaction, tracker)
        assert tracker.total_prompt_tokens == 0


class TestLLMErrorEvents:
    """Verify LLM-level errors (safety blocks, quota) are captured."""

    def test_error_code_captured(self):
        tracker = _RunTracker()
        interaction = MagicMock()
        event = _make_model_event(
            error_code="SAFETY", error_message="Content blocked by safety filter",
            is_final=True,
        )
        _process_event(event, interaction, tracker)
        assert tracker.error_code == "SAFETY"
        assert tracker.error_message == "Content blocked by safety filter"

    def test_error_in_properties(self):
        tracker = _RunTracker()
        tracker.error_code = "QUOTA_EXCEEDED"
        tracker.error_message = "Rate limit hit"
        props = _build_properties_from_tracker(tracker, None, None, None)
        assert props["google_adk.error_code"] == "QUOTA_EXCEEDED"
        assert props["google_adk.llm_error_message"] == "Rate limit hit"

    def test_no_error_no_properties(self):
        tracker = _RunTracker()
        props = _build_properties_from_tracker(tracker, None, None, None)
        assert "google_adk.error_code" not in props
        assert "google_adk.llm_error_message" not in props


class TestMultiAgentBranch:
    """Verify agent hierarchy is captured from event.branch."""

    def test_branch_captured(self):
        tracker = _RunTracker()
        interaction = MagicMock()
        event = _make_model_event(branch="root.sub_agent.leaf", is_final=True)
        _process_event(event, interaction, tracker)
        assert tracker.agent_branch == "root.sub_agent.leaf"

    def test_branch_in_properties(self):
        tracker = _RunTracker()
        tracker.agent_branch = "orchestrator.worker"
        props = _build_properties_from_tracker(tracker, None, None, None)
        assert props["google_adk.agent_branch"] == "orchestrator.worker"


class TestFinishReason:
    """Verify finish_reason is captured."""

    def test_finish_reason_captured(self):
        tracker = _RunTracker()
        interaction = MagicMock()
        event = _make_model_event(finish_reason="STOP", is_final=True)
        _process_event(event, interaction, tracker)
        assert tracker.finish_reason == "STOP"

    def test_finish_reason_in_properties(self):
        tracker = _RunTracker()
        tracker.finish_reason = "MAX_TOKENS"
        props = _build_properties_from_tracker(tracker, None, None, None)
        assert props["google_adk.finish_reason"] == "MAX_TOKENS"


class TestModelTrackingFromTracker:
    """Verify model name is captured from first event that has it."""

    def test_first_model_wins(self):
        tracker = _RunTracker()
        interaction = MagicMock()

        event1 = _make_model_event(model_version="gemini-2.0-flash", is_final=False)
        _process_event(event1, interaction, tracker)
        assert tracker.model_name == "gemini-2.0-flash"

        event2 = _make_model_event(model_version="gemini-2.5-pro", is_final=True)
        _process_event(event2, interaction, tracker)
        assert tracker.model_name == "gemini-2.0-flash"


class TestToolTrackingE2EFlow:
    """Full flow: function call -> function response -> final, with tool span."""

    def test_full_agentic_flow(self):
        fc_event = _make_function_call_event([
            {"id": "fc-1", "name": "get_weather", "args": {"city": "SF"}},
        ], model_version="gemini-2.0-flash")
        fr_event = _make_function_response_event([
            {"id": "fc-1", "name": "get_weather", "response": {"temp": 62}},
        ])
        final_event = _make_model_event(
            text="It's 62F in SF", is_final=True,
            usage={"prompt_tokens": 100, "completion_tokens": 20, "total_tokens": 120},
        )

        runner = _make_runner(app_name="weather_app", events=[fc_event, fr_event, final_event])

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.id = "evt-flow"
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="test-user")
            events = list(wrapped.run(
                user_id="test-user", session_id="s1",
                new_message=_make_content("Weather in SF?"),
            ))

            assert len(events) == 3
            mock_interaction.track_tool.assert_called_once()
            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["name"] == "get_weather"
            assert tool_kwargs["input"] == {"city": "SF"}
            assert tool_kwargs["output"] == {"temp": 62}

            mock_interaction.finish.assert_called_once()
            finish_kwargs = mock_interaction.finish.call_args.kwargs
            assert finish_kwargs["output"] == "It's 62F in SF"
            props = finish_kwargs["properties"]
            assert props["google_adk.tool_calls_count"] == 1
            assert '"get_weather"' in props["google_adk.tool_call_names"]
            assert props["ai.usage.prompt_tokens"] == 100
            assert props["ai.usage.completion_tokens"] == 20


# ============================================================
# Test function response name-based fallback matching
# ============================================================


class TestToolResponseFallbackMatching:
    """When response ID doesn't match, fall back to matching by name."""

    def test_name_fallback_when_ids_differ(self):
        tracker = _RunTracker()
        interaction = MagicMock()

        _process_event(
            _make_function_call_event([
                {"id": "call-abc", "name": "my_tool", "args": {"q": "test"}},
            ]),
            interaction, tracker,
        )

        fr_event = _make_function_response_event([
            {"id": "resp-xyz", "name": "my_tool", "response": {"ok": True}},
        ])
        _process_event(fr_event, interaction, tracker)

        assert len(tracker.pending_calls) == 0
        assert tracker.tool_call_names == ["my_tool"]
        call_kwargs = interaction.track_tool.call_args.kwargs
        assert call_kwargs["name"] == "my_tool"
        assert call_kwargs["input"] == {"q": "test"}
        assert call_kwargs["output"] == {"ok": True}

    def test_unmatched_response_still_tracked(self):
        """Response with no matching pending call still records the tool name."""
        tracker = _RunTracker()
        interaction = MagicMock()

        fr_event = _make_function_response_event([
            {"id": "orphan", "name": "orphan_tool", "response": {"data": 1}},
        ])
        _process_event(fr_event, interaction, tracker)

        assert tracker.tool_call_names == ["orphan_tool"]
        interaction.track_tool.assert_called_once()


# ============================================================
# Test error path preserves tracker data
# ============================================================


class TestErrorPathPreservesTrackerData:
    """When an exception occurs, accumulated tokens/tools should be in error properties."""

    def test_error_includes_accumulated_tokens(self):
        model_event = _make_model_event(
            text="partial", is_final=False,
            usage={"prompt_tokens": 50, "completion_tokens": 10, "total_tokens": 60},
        )

        def events_then_error():
            yield model_event
            raise RuntimeError("mid-stream crash")

        runner = MagicMock()
        runner.app_name = "app"
        runner.run = MagicMock(return_value=events_then_error())

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="u1")
            try:
                list(wrapped.run(
                    user_id="u1", session_id="s1",
                    new_message=_make_content("Test"),
                ))
            except RuntimeError:
                pass

            error_props = mock_interaction.set_properties.call_args[0][0]
            assert error_props["google_adk.error"] is True
            assert error_props["ai.usage.prompt_tokens"] == 50
            assert error_props["ai.usage.completion_tokens"] == 10

    def test_python_error_does_not_overwrite_llm_error(self):
        """LLM error fields must survive a subsequent Python exception."""
        llm_error_event = _make_model_event(
            text="blocked", is_final=False,
            error_code="SAFETY", error_message="Content blocked",
        )

        def events_then_crash():
            yield llm_error_event
            raise RuntimeError("downstream crash")

        runner = MagicMock()
        runner.app_name = "app"
        runner.run = MagicMock(return_value=events_then_crash())

        with patch("raindrop_google_adk.wrapper.raindrop") as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            wrapped = wrap_runner(runner, user_id="u1")
            try:
                list(wrapped.run(
                    user_id="u1", session_id="s1",
                    new_message=_make_content("Test"),
                ))
            except RuntimeError:
                pass

            error_props = mock_interaction.set_properties.call_args[0][0]
            assert error_props["google_adk.error"] is True
            assert error_props["google_adk.error_message"] == "downstream crash"
            assert error_props["google_adk.error_code"] == "SAFETY"
            assert error_props["google_adk.llm_error_message"] == "Content blocked"


# ============================================================
# Test ImportError warning in _patch_runner
# ============================================================


class TestPatchRunnerImportWarning:
    """_patch_runner warns when google-adk is not installed."""

    def test_import_error_warns(self):
        with patch("raindrop_google_adk.wrapper.raindrop"):
            import raindrop_google_adk.wrapper as w
            original_patched = w._patched
            try:
                w._patched = False
                with patch.dict("sys.modules", {"google.adk.runners": None}):
                    with warnings.catch_warnings(record=True) as caught:
                        warnings.simplefilter("always")
                        from raindrop_google_adk.wrapper import _patch_runner
                        _patch_runner()
                        warning_msgs = [str(w.message) for w in caught]
                        assert any("google-adk package not installed" in m for m in warning_msgs), (
                            f"Expected ImportError warning, got: {warning_msgs}"
                        )
            finally:
                w._patched = original_patched
