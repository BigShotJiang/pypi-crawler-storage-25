"""End-to-end tests for the Google ADK integration.

Exercises the REAL stack: Google ADK agent -> Gemini LLM -> Raindrop telemetry
-> Dashboard TRPC API verification.

Required environment variables:
  GOOGLE_API_KEY               — (or GOOGLE_GENERATIVE_AI_API_KEY) Gemini API key
  RAINDROP_WRITE_KEY           — (or RAINDROP_API_KEY) Raindrop write key
  RAINDROP_DASHBOARD_TOKEN     — Bearer token for backend.raindrop.ai TRPC API

Run locally:
  cd packages/google-adk-python
  source .venv/bin/activate
  export GOOGLE_API_KEY=...
  export RAINDROP_WRITE_KEY=your-write-key
  export RAINDROP_DASHBOARD_TOKEN=eyJ...
  python -m pytest tests/test_e2e.py -v -s
"""

from __future__ import annotations

import asyncio
import json
import os
import time
import urllib.parse
import uuid

import pytest
import requests

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY") or os.getenv("GOOGLE_GENERATIVE_AI_API_KEY")
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")

skip_unless_e2e = pytest.mark.skipif(
    not all([WRITE_KEY, GOOGLE_API_KEY, DASHBOARD_TOKEN]),
    reason="RAINDROP_WRITE_KEY, GOOGLE_API_KEY, and RAINDROP_DASHBOARD_TOKEN required",
)

RUN_ID = uuid.uuid4().hex[:10]
# ``gemini-2.5-flash`` has a separate quota pool from ``gemini-2.0-flash``,
# which the wider Raindrop e2e fleet has been hammering all day. Tests are
# also wrapped in a ``RESOURCE_EXHAUSTED``-aware retry helper.
MODEL = os.getenv("RAINDROP_E2E_MODEL", "gemini-2.5-flash")


# ======================================================================
# Dashboard TRPC query helpers
# ======================================================================


def _query_dashboard(limit: int = 50) -> list[dict]:
    """Fetch recent events from the dashboard TRPC API."""
    input_obj = {"json": {"limit": limit, "orderBy": {"field": "timestamp", "direction": "desc"}}}
    encoded = urllib.parse.quote(json.dumps(input_obj))
    resp = requests.get(
        f"{BACKEND_URL}/api/trpc/events.list?input={encoded}",
        headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        timeout=20,
    )
    resp.raise_for_status()
    data = resp.json()
    return data.get("result", {}).get("data", [])


def poll_events(
    user_id: str,
    min_count: int = 1,
    timeout: int = 120,
    interval: int = 5,
) -> list[dict]:
    """Poll the dashboard TRPC API until *min_count* events for *user_id* appear."""
    deadline = time.time() + timeout
    matched: list[dict] = []
    while time.time() < deadline:
        all_events = _query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        if len(matched) >= min_count:
            return matched
        time.sleep(interval)
    raise TimeoutError(
        f"Expected >= {min_count} events for userId={user_id}, "
        f"got {len(matched)} after {timeout}s"
    )


# ======================================================================
# ADK helpers — real agents, real Gemini
# ======================================================================


def _make_user(suffix: str) -> str:
    return f"e2e_adk_{RUN_ID}_{suffix}"


def _make_convo(suffix: str) -> str:
    return f"e2e_convo_{RUN_ID}_{suffix}"


def _get_weather(city: str) -> dict:
    """Get the current weather for a city."""
    return {"temperature": 72, "condition": "sunny", "city": city}


def _build_agent(name: str = "e2e_agent", tools=None):
    from google.adk.agents import LlmAgent

    return LlmAgent(
        name=name,
        model=MODEL,
        tools=tools or [_get_weather],
        instruction=(
            "You are a helpful assistant. "
            "When asked about weather, ALWAYS call the get_weather tool. "
            "Keep your response short."
        ),
    )


def _build_runner(agent, app_name: str = "e2e_app"):
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService

    return Runner(
        app_name=app_name,
        agent=agent,
        session_service=InMemorySessionService(),
    )


def _user_message(text: str):
    from google.genai import types

    return types.Content(parts=[types.Part(text=text)], role="user")


async def _ensure_session(runner, app_name: str, user_id: str, session_id: str):
    svc = runner.session_service
    existing = await svc.get_session(
        app_name=app_name, user_id=user_id, session_id=session_id,
    )
    if existing is None:
        await svc.create_session(
            app_name=app_name, user_id=user_id, session_id=session_id,
        )


def _final_text(events):
    final_text = None
    for event in events:
        if hasattr(event, "is_final_response") and event.is_final_response():
            if event.content and event.content.parts:
                final_text = " ".join(
                    p.text for p in event.content.parts if hasattr(p, "text") and p.text
                )
    return final_text


def _run_sync(runner, user_id, session_id, message_text, app_name="e2e_app"):
    """Run a sync agent invocation, return (events, final_text).

    Wrapped in :func:`tests._dashboard.collect_with_gemini_backoff` so a
    transient ``RESOURCE_EXHAUSTED`` is retried after the
    server-suggested delay rather than turned into a flaky failure.
    """
    from tests._dashboard import collect_with_gemini_backoff

    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(
            _ensure_session(runner, app_name, user_id, session_id)
        )
    finally:
        loop.close()

    events = collect_with_gemini_backoff(
        lambda: runner.run(
            user_id=user_id,
            session_id=session_id,
            new_message=_user_message(message_text),
        )
    )
    return events, _final_text(events)


async def _run_async(runner, user_id, session_id, message_text, app_name="e2e_app"):
    """Run an async agent invocation, return (events, final_text)."""
    from tests._dashboard import acollect_with_gemini_backoff

    await _ensure_session(runner, app_name, user_id, session_id)
    events = await acollect_with_gemini_backoff(
        lambda: runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=_user_message(message_text),
        )
    )
    return events, _final_text(events)


# ======================================================================
# Fixture: reset _patched global between tests
# ======================================================================


@pytest.fixture(autouse=True)
def _reset_patch_state():
    """Reset both the _patched flag AND restore original Runner methods.

    Without restoring the actual class methods, sequential tests that call
    setup_google_adk() would stack instrumentation layers on Runner.run/run_async.
    """
    import raindrop_google_adk.wrapper as w

    original_patched = w._patched
    w._patched = False

    original_run = None
    original_run_async = None
    runner_cls = None
    try:
        from google.adk.runners import Runner
        runner_cls = Runner
        original_run = Runner.run
        original_run_async = Runner.run_async
    except ImportError:
        pass

    yield

    w._patched = original_patched
    if runner_cls is not None and original_run is not None:
        runner_cls.run = original_run
        runner_cls.run_async = original_run_async


# ======================================================================
# E2E Tests
# ======================================================================


@skip_unless_e2e
class TestE2ESyncRun:
    """Core happy path: setup_google_adk + Runner.run() + verify via dashboard."""

    def test_event_shape(self):
        from raindrop_google_adk import setup_google_adk

        user_id = _make_user("sync")
        convo_id = _make_convo("sync")

        rd = setup_google_adk(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        agent = _build_agent()
        runner = _build_runner(agent)

        events, final_text = _run_sync(
            runner, user_id, "s1", "What's the weather in Paris?"
        )

        assert len(events) > 0, "Runner should yield at least one event"
        assert final_text, "Should have a final response"

        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        assert len(rows) >= 1, f"Expected at least 1 event, got {len(rows)}"
        ev = rows[0]

        assert ev["userId"] == user_id

        ai = ev.get("aiData") or {}
        assert ai.get("input"), "input should be captured"
        assert ai.get("output"), "output should be captured"
        assert ai.get("convoId") == convo_id

        props = ev.get("properties") or {}
        assert props.get("google_adk.app_name") == "e2e_app"
        assert props.get("google_adk.session_id") == "s1"
        assert "isPending" not in ev or not ev["isPending"], "Event should be finalized"


@skip_unless_e2e
class TestE2EAsyncRun:
    """Async path: Runner.run_async() produces the same telemetry."""

    def test_async_event_shape(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("async")

        rd = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id)
        agent = _build_agent()
        runner = _build_runner(agent)
        wrapped = rd.wrap(runner)

        events, final_text = asyncio.run(
            _run_async(wrapped, user_id, "s2", "What's the weather in Tokyo?")
        )

        assert len(events) > 0
        assert final_text

        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        ev = rows[0]

        assert ev["userId"] == user_id

        ai = ev.get("aiData") or {}
        assert ai.get("input"), "input should be captured"
        assert ai.get("output"), "output should be captured"

        props = ev.get("properties") or {}
        assert props.get("google_adk.app_name") == "e2e_app"
        assert props.get("google_adk.session_id") == "s2"


@skip_unless_e2e
class TestE2EModelTracking:
    """Model name is captured in the event."""

    def test_model_in_event(self):
        from raindrop_google_adk import setup_google_adk

        user_id = _make_user("model")
        rd = setup_google_adk(api_key=WRITE_KEY, user_id=user_id)
        agent = _build_agent()
        runner = _build_runner(agent)
        _run_sync(runner, user_id, "s-model", "What's the weather in London?")
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        ai = rows[0].get("aiData") or {}
        model = ai.get("model") or ""
        assert "gemini" in model.lower(), f"Expected gemini model, got: {model}"


@skip_unless_e2e
class TestE2EWrapAPI:
    """Per-instance wrapping via create_raindrop_google_adk + rd.wrap()."""

    def test_wrap_event_shape(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("wrap")

        rd = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id)
        agent = _build_agent()
        runner = _build_runner(agent)
        wrapped = rd.wrap(runner)

        _run_sync(wrapped, user_id, "s-wrap", "What's the weather in Berlin?")
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        ev = rows[0]
        assert ev["userId"] == user_id
        ai = ev.get("aiData") or {}
        assert ai.get("output"), "Should have output"
        assert ai.get("input"), "Should have input"


@skip_unless_e2e
class TestE2EClassAPI:
    """RaindropGoogleADK class with identify + track_signal."""

    def test_class_api_full(self):
        from raindrop_google_adk import RaindropGoogleADK

        user_id = _make_user("class")
        rd = RaindropGoogleADK(
            api_key=WRITE_KEY, user_id=user_id, convo_id=_make_convo("class"),
        )
        rd.setup()

        agent = _build_agent()
        runner = _build_runner(agent)
        _run_sync(runner, user_id, "s-class", "What's the weather in NYC?")

        rd.identify(user_id=user_id, traits={"plan": "pro", "e2e": True})
        # track_signal requires an event_id; use a placeholder for e2e
        rd.track_signal(event_id="e2e-placeholder", name="thumbs_up")

        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        assert len(rows) >= 1
        ev = rows[0]
        assert ev["userId"] == user_id


@skip_unless_e2e
class TestE2EMultipleRuns:
    """Three consecutive runs on the same runner produce 3 distinct events."""

    def test_three_runs_no_leak(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("multi")
        rd = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id)
        agent = _build_agent()
        runner = _build_runner(agent)
        wrapped = rd.wrap(runner)

        cities = ["Chicago", "Miami", "Seattle"]
        for i, city in enumerate(cities):
            _run_sync(
                wrapped, user_id, f"s-multi-{i}",
                f"What's the weather in {city}?",
            )

        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id, min_count=3, timeout=180)
        assert len(rows) >= 3, f"Expected 3 events, got {len(rows)}"

        unique_inputs = set()
        for r in rows:
            inp = (r.get("aiData") or {}).get("input", "")
            if inp:
                unique_inputs.add(inp)
        assert len(unique_inputs) >= 2, (
            f"Expected >= 2 distinct inputs (proving no cross-contamination), "
            f"got {len(unique_inputs)}: {unique_inputs}"
        )


@skip_unless_e2e
class TestE2EConvoIdGrouping:
    """Events with same convo_id are grouped."""

    def test_shared_convo_id(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("convo")
        shared_convo = _make_convo("shared")
        other_convo = _make_convo("other")

        rd1 = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id, convo_id=shared_convo)
        agent = _build_agent()
        runner = _build_runner(agent)
        wrapped = rd1.wrap(runner)

        _run_sync(wrapped, user_id, "s-c1", "What's the weather in Denver?")
        _run_sync(wrapped, user_id, "s-c2", "What's the weather in Austin?")
        rd1.flush()
        rd1.shutdown()

        rd2 = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id, convo_id=other_convo)
        runner2 = _build_runner(_build_agent())
        wrapped2 = rd2.wrap(runner2)
        _run_sync(wrapped2, user_id, "s-c3", "What's the weather in Portland?")
        rd2.flush()
        rd2.shutdown()

        rows = poll_events(user_id, min_count=3, timeout=180)
        convo_ids = [(r.get("aiData") or {}).get("convoId") for r in rows]
        assert convo_ids.count(shared_convo) >= 2, (
            f"Expected >= 2 events with convoId={shared_convo}, got {convo_ids}"
        )
        assert any(c == other_convo for c in convo_ids), (
            f"Expected at least 1 event with convoId={other_convo}, got {convo_ids}"
        )


@skip_unless_e2e
class TestE2EAgentName:
    """Agent name is captured in properties."""

    def test_custom_agent_name(self):
        from raindrop_google_adk import setup_google_adk

        user_id = _make_user("agname")
        rd = setup_google_adk(api_key=WRITE_KEY, user_id=user_id)
        agent = _build_agent(name="custom_weather_bot")
        runner = _build_runner(agent)
        _run_sync(runner, user_id, "s-name", "What's the weather in Rome?")
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        props = rows[0].get("properties") or {}
        agent_name = props.get("google_adk.agent_name", "")
        assert "custom_weather_bot" in agent_name, (
            f"Expected 'custom_weather_bot', got: {agent_name}"
        )


@skip_unless_e2e
class TestE2EIdempotentWrap:
    """Double-wrapping a runner is idempotent (second wrap is a no-op)."""

    def test_double_wrap_returns_same_runner(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("idwrap")
        rd = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id)
        agent = _build_agent()
        runner = _build_runner(agent)
        wrapped = rd.wrap(runner)
        wrapped2 = rd.wrap(wrapped)
        assert wrapped is wrapped2, "Second wrap should return the same runner"
        assert getattr(wrapped, "_raindrop_wrapped", False) is True

        _run_sync(wrapped, user_id, "s-idwrap", "What's the weather in Dublin?")
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id, min_count=1, timeout=60)
        ev = rows[0]
        assert ev["userId"] == user_id
        ai = ev.get("aiData") or {}
        assert ai.get("output"), "Should have output"
        assert ai.get("input"), "Should have input"


@skip_unless_e2e
class TestE2EToolCallNames:
    """Verify google_adk.tool_call_names property is populated."""

    def test_tool_names_captured(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("tcnames")
        rd = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id)
        agent = _build_agent()
        runner = _build_runner(agent)
        wrapped = rd.wrap(runner)

        _run_sync(wrapped, user_id, "s-tcnames", "What's the weather in Madrid?")
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        props = rows[0].get("properties") or {}
        tool_names_raw = props.get("google_adk.tool_call_names", "")
        assert "get_weather" in tool_names_raw, (
            f"Expected 'get_weather' in tool_call_names, got: {tool_names_raw}"
        )
        count = props.get("google_adk.tool_calls_count")
        assert count and int(count) >= 1, (
            f"Expected tool_calls_count >= 1, got: {count}"
        )


@skip_unless_e2e
class TestE2EAccumulatedTokens:
    """Verify tokens are accumulated across the full agent run."""

    def test_tokens_reflect_full_conversation(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("tokens")
        rd = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id)
        agent = _build_agent()
        runner = _build_runner(agent)
        wrapped = rd.wrap(runner)

        _run_sync(wrapped, user_id, "s-tokens", "What's the weather in Sydney?")
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        props = rows[0].get("properties") or {}

        prompt_tokens = int(props.get("ai.usage.prompt_tokens", 0))
        completion_tokens = int(props.get("ai.usage.completion_tokens", 0))
        total_tokens = int(props.get("ai.usage.total_tokens", 0))

        assert prompt_tokens > 0, f"prompt_tokens should be > 0, got {prompt_tokens}"
        assert completion_tokens > 0, f"completion_tokens should be > 0, got {completion_tokens}"
        assert total_tokens > 0, f"total_tokens should be > 0, got {total_tokens}"
        assert total_tokens >= prompt_tokens + completion_tokens, (
            f"total ({total_tokens}) should be >= prompt ({prompt_tokens}) + completion ({completion_tokens})"
        )


def _get_stock_price(symbol: str) -> dict:
    """Get the current stock price for a symbol."""
    return {"symbol": symbol, "price": 189.50, "currency": "USD"}


@skip_unless_e2e
class TestE2EMultiToolAgent:
    """Agent with 2 tools, verify both names appear in telemetry."""

    def test_two_tools_both_tracked(self):
        from raindrop_google_adk import create_raindrop_google_adk

        user_id = _make_user("2tools")
        rd = create_raindrop_google_adk(api_key=WRITE_KEY, user_id=user_id)

        from google.adk.agents import LlmAgent

        agent = LlmAgent(
            name="multi_tool_agent",
            model=MODEL,
            tools=[_get_weather, _get_stock_price],
            instruction=(
                "You have two tools: get_weather and get_stock_price. "
                "When asked about weather AND stocks, call BOTH tools. "
                "Keep your response short."
            ),
        )
        runner = _build_runner(agent)
        wrapped = rd.wrap(runner)

        _run_sync(
            wrapped, user_id, "s-2tools",
            "What's the weather in NYC and what's the stock price of AAPL?",
        )
        rd.flush()
        rd.shutdown()

        rows = poll_events(user_id)
        props = rows[0].get("properties") or {}
        tool_names_raw = props.get("google_adk.tool_call_names", "")
        assert "get_weather" in tool_names_raw, (
            f"Expected 'get_weather' in tool_call_names, got: {tool_names_raw}"
        )
        assert "get_stock_price" in tool_names_raw, (
            f"Expected 'get_stock_price' in tool_call_names, got: {tool_names_raw}"
        )
        count = int(props.get("google_adk.tool_calls_count", 0))
        assert count >= 2, f"Expected tool_calls_count >= 2, got {count}"
