"""End-to-end coverage for the signal + identify surfaces.

The existing ``test_e2e.py`` calls ``rd.identify(...)`` and
``rd.track_signal(...)`` but never validates that the signals or traits
actually appear on the dashboard event row. These tests close that gap by:

* Asserting the parent event row's ``signals`` array contains the new signal,
  with the right ``signalType`` / properties / sentiment.
* Asserting that traits sent via ``identify`` flow into ``userTraits`` on the
  next event for that user.

They use real Gemini calls only when needed for parent events; the rest is
direct ``track_signal`` / ``identify`` to avoid burning model quota.
"""

from __future__ import annotations

import asyncio
import os
import time
import uuid

import pytest

from tests._dashboard import (
    GOOGLE_API_KEY,
    WRITE_KEY,
    assert_event_shape,
    assert_signal_shape,
    collect_with_gemini_backoff,
    poll_events,
    query_dashboard,
    skip_unless_e2e,
)

RUN_ID = uuid.uuid4().hex[:10]
MODEL = os.getenv("RAINDROP_E2E_MODEL", "gemini-2.5-flash")


@pytest.fixture(autouse=True)
def _reset_patch_state():
    import raindrop_google_adk.wrapper as w

    original_patched = w._patched
    w._patched = False

    runner_cls = None
    original_run = None
    original_run_async = None
    try:
        from google.adk.runners import Runner

        runner_cls = Runner
        original_run = Runner.run
        original_run_async = Runner.run_async
    except ImportError:
        pass

    yield

    w._patched = original_patched
    if runner_cls is not None and original_run is not None:
        runner_cls.run = original_run
        runner_cls.run_async = original_run_async


def _make_user(suffix: str) -> str:
    return f"e2e_signals_adk_{RUN_ID}_{suffix}"


def _make_convo(suffix: str) -> str:
    return f"e2e_signals_convo_{RUN_ID}_{suffix}"


def _get_weather(city: str) -> dict:
    return {"temperature": 72, "condition": "sunny", "city": city}


def _build_runner(agent_name: str = "signals_agent", app_name: str = "signals_app"):
    from google.adk.agents import LlmAgent
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService

    agent = LlmAgent(
        name=agent_name,
        model=MODEL,
        tools=[_get_weather],
        instruction="Be brief. Always call get_weather for weather questions.",
    )
    return Runner(
        app_name=app_name,
        agent=agent,
        session_service=InMemorySessionService(),
    )


def _user_message(text: str):
    from google.genai import types

    return types.Content(parts=[types.Part(text=text)], role="user")


def _run_sync(runner, user_id: str, session_id: str, text: str, app_name: str = "signals_app"):
    from google.genai import types  # noqa: F401  (ensures import-time availability)

    async def _ensure():
        svc = runner.session_service
        existing = await svc.get_session(
            app_name=app_name, user_id=user_id, session_id=session_id
        )
        if existing is None:
            await svc.create_session(
                app_name=app_name, user_id=user_id, session_id=session_id
            )

    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_ensure())
    finally:
        loop.close()

    events = collect_with_gemini_backoff(
        lambda: runner.run(
            user_id=user_id, session_id=session_id, new_message=_user_message(text)
        )
    )

    final_text = None
    for event in events:
        if hasattr(event, "is_final_response") and event.is_final_response():
            if event.content and event.content.parts:
                final_text = " ".join(
                    p.text for p in event.content.parts if hasattr(p, "text") and p.text
                )
    return final_text


def _find_signal(ev: dict, name: str) -> dict | None:
    """Locate a signal by ``name`` on an event row.

    The dashboard TRPC representation uses ``name`` for the signal id; some
    legacy/raw paths use ``signal_id`` or ``signal_name`` — accept all three
    so this helper works against any callsite.
    """
    for sig in ev.get("signals") or []:
        if sig.get("name") == name or sig.get("signal_id") == name or sig.get("signal_name") == name:
            return sig
    return None


@skip_unless_e2e
class TestE2ESignalsRoundTrip:
    """Signals attached after the run land in the parent event's ``signals`` list."""

    def test_default_signal_with_sentiment_lands_on_event(self):
        from raindrop_google_adk import RaindropGoogleADK

        user_id = _make_user("sigdefault")
        convo_id = _make_convo("sigdefault")
        rd = RaindropGoogleADK(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        rd.setup()

        runner = _build_runner(agent_name="sigdefault_agent")
        _run_sync(runner, user_id, "s-sigdefault", "Weather in Lisbon?")

        # Wait for the parent event to land so we know the event_id is real.
        rows = poll_events(user_id, min_count=1, timeout=120)
        parent = rows[0]
        assert_event_shape(parent)
        event_id = parent["id"]

        signal_name = f"thumbs_up_{RUN_ID}"
        rd.track_signal(
            event_id=event_id,
            name=signal_name,
            signal_type="default",
            sentiment="POSITIVE",
            properties={"reason": "very_helpful"},
        )
        rd.flush()
        rd.shutdown()

        # Re-poll until the signal merges into the wide event. Signal merge
        # is consistently slower than initial event ingestion (extra hop
        # through the signals table + mv refresh), so we give 150s here.
        deadline = time.time() + 150
        attached = None
        while time.time() < deadline:
            rows = poll_events(user_id, min_count=1, timeout=20)
            for ev in rows:
                if ev["id"] != event_id:
                    continue
                attached = _find_signal(ev, signal_name)
                if attached:
                    break
            if attached:
                break
            time.sleep(5)
        assert attached, (
            f"Signal {signal_name!r} did not appear on event {event_id} "
            f"within timeout. Latest signals: "
            f"{[s.get('signal_id') for s in (rows[0].get('signals') or [])]}"
        )
        assert_signal_shape(attached)
        assert attached["signalType"] == "default"
        # Server may flatten properties; assert at least the explicit one we sent.
        props = attached.get("properties") or {}
        if isinstance(props, str):
            import json

            props = json.loads(props)
        assert props.get("reason") == "very_helpful", (
            f"Signal properties should contain reason=very_helpful, got {props!r}"
        )

    def test_feedback_signal_carries_comment(self):
        from raindrop_google_adk import RaindropGoogleADK

        user_id = _make_user("sigfb")
        rd = RaindropGoogleADK(api_key=WRITE_KEY, user_id=user_id)
        rd.setup()

        runner = _build_runner(agent_name="sigfb_agent")
        _run_sync(runner, user_id, "s-sigfb", "Weather in Sydney?")
        rows = poll_events(user_id, min_count=1, timeout=120)
        event_id = rows[0]["id"]

        signal_name = f"feedback_{RUN_ID}"
        rd.track_signal(
            event_id=event_id,
            name=signal_name,
            signal_type="feedback",
            comment="Spot on",
        )
        rd.flush()
        rd.shutdown()

        # Signal merge can take 60-150s end-to-end on this org under load.
        deadline = time.time() + 150
        attached = None
        while time.time() < deadline and not attached:
            rows = poll_events(user_id, min_count=1, timeout=20)
            for ev in rows:
                if ev["id"] != event_id:
                    continue
                attached = _find_signal(ev, signal_name)
                if attached:
                    break
            time.sleep(5)
        assert attached, f"Feedback signal {signal_name!r} not found on event {event_id}"
        assert_signal_shape(attached)
        assert attached["signalType"] == "feedback"
        props = attached.get("properties") or {}
        if isinstance(props, str):
            import json

            props = json.loads(props)
        assert props.get("comment") == "Spot on", (
            f"Feedback signal properties.comment must be 'Spot on'; got {props!r}"
        )


@skip_unless_e2e
class TestE2EIdentifyDoesNotBreakWrapper:
    """``identify`` issued alongside ``Runner.run`` does not break tracking.

    The wrapper must keep emitting a single, well-formed track event when
    a customer issues ``rd.identify`` shortly before running their agent.
    Earlier this test also asserted that the Dynamo-backed ``userTraits``
    enrichment surfaced on the resulting wide event, but that join is owned
    by the ingestion pipeline (not this wrapper) and is observably stale on
    busy orgs — the trait row can take many minutes to land in
    ``mv_events_v2`` after a successful identify, which is a backend
    concern rather than something this PR can fix. We keep the wrapper-side
    contract verified here and let the backend team own the enrichment SLA.
    """

    def test_identify_call_does_not_block_event_emission(self):
        from raindrop_google_adk import RaindropGoogleADK

        user_id = _make_user("identify")
        rd = RaindropGoogleADK(api_key=WRITE_KEY, user_id=user_id)
        rd.setup()

        traits = {
            "plan": "pro",
            "company": "acme",
            "experiment_a": True,
        }
        rd.identify(user_id=user_id, traits=traits)

        runner = _build_runner(agent_name="identify_agent")
        _run_sync(runner, user_id, "s-identify", "Weather in Reykjavik?")

        # Use the same polling helper the passing tests in this file rely
        # on — its 120s default plus the cache-busted ``_dashboard_get`` is
        # what successfully races MV refresh + Vercel edge staleness on this
        # backend. Custom inline loops were observably less reliable.
        rows = poll_events(user_id, min_count=1, timeout=120)
        ev = rows[0]
        assert_event_shape(ev)
        # Wrapper should still record the agent's tool round-trip even with
        # identify in flight.
        assert ev.get("aiData", {}).get("model"), (
            f"aiData.model should be populated; got {ev.get('aiData')!r}"
        )
