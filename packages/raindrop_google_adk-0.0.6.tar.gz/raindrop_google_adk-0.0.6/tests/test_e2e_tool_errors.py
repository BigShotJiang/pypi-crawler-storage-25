"""End-to-end coverage for tool failure paths and errorSpans wire format.

The wrapper has two distinct error code paths:

1. **Tool-level error.** A tool returns ``{"error": "..."}``. The wrapper
   forwards that to ``interaction.track_tool(error=RuntimeError(...))``,
   which produces an ``ERROR`` span. On the dashboard wide row this shows up
   in the ``errorSpans`` array (not ``toolCalls``), with a strict shape we
   want to lock in.
2. **Python exception.** The agent / tool raises an actual exception. The
   wrapper marks the interaction with ``google_adk.error = "true"`` and a
   ``google_adk.error_message``, then re-raises.

These paths are mocked in unit tests but never validated end-to-end against
the real dashboard schema.
"""

from __future__ import annotations

import asyncio
import os
import time
import uuid

import pytest

from tests._dashboard import (
    GOOGLE_API_KEY,
    WRITE_KEY,
    assert_error_span_shape,
    assert_event_shape,
    collect_with_gemini_backoff,
    poll_events,
    query_dashboard,
    skip_unless_e2e,
)

RUN_ID = uuid.uuid4().hex[:10]
MODEL = os.getenv("RAINDROP_E2E_MODEL", "gemini-2.5-flash")


@pytest.fixture(autouse=True)
def _reset_patch_state():
    import raindrop_google_adk.wrapper as w

    original_patched = w._patched
    w._patched = False

    runner_cls = None
    original_run = None
    original_run_async = None
    try:
        from google.adk.runners import Runner

        runner_cls = Runner
        original_run = Runner.run
        original_run_async = Runner.run_async
    except ImportError:
        pass

    yield

    w._patched = original_patched
    if runner_cls is not None and original_run is not None:
        runner_cls.run = original_run
        runner_cls.run_async = original_run_async


def _make_user(suffix: str) -> str:
    return f"e2e_toolerr_adk_{RUN_ID}_{suffix}"


def _failing_weather_tool(city: str) -> dict:
    """Returns the {'error': ...} sentinel ADK passes back as a function response."""
    return {"error": f"Weather provider unavailable for {city}"}


def _build_runner_with_tool(tool, agent_name: str = "err_agent", app_name: str = "err_app"):
    from google.adk.agents import LlmAgent
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService

    agent = LlmAgent(
        name=agent_name,
        model=MODEL,
        tools=[tool],
        instruction=(
            "You MUST call the provided tool exactly once for any weather "
            "request, then summarize whatever it returns (including errors)."
        ),
    )
    return Runner(
        app_name=app_name,
        agent=agent,
        session_service=InMemorySessionService(),
    )


def _user_message(text: str):
    from google.genai import types

    return types.Content(parts=[types.Part(text=text)], role="user")


def _run_sync(runner, user_id: str, session_id: str, text: str, app_name: str = "err_app"):
    async def _ensure():
        svc = runner.session_service
        existing = await svc.get_session(
            app_name=app_name, user_id=user_id, session_id=session_id
        )
        if existing is None:
            await svc.create_session(
                app_name=app_name, user_id=user_id, session_id=session_id
            )

    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_ensure())
    finally:
        loop.close()

    events = collect_with_gemini_backoff(
        lambda: runner.run(
            user_id=user_id, session_id=session_id, new_message=_user_message(text)
        )
    )

    final_text = None
    for event in events:
        if hasattr(event, "is_final_response") and event.is_final_response():
            if event.content and event.content.parts:
                final_text = " ".join(
                    p.text for p in event.content.parts if hasattr(p, "text") and p.text
                )
    return final_text


@skip_unless_e2e
class TestE2EToolErrorEndsUpInErrorSpans:
    """A tool returning ``{"error": ...}`` populates errorSpans with a strict shape."""

    def test_tool_error_produces_error_span(self):
        from raindrop_google_adk import setup_google_adk

        user_id = _make_user("toolerr")
        rd = setup_google_adk(api_key=WRITE_KEY, user_id=user_id)

        runner = _build_runner_with_tool(
            _failing_weather_tool, agent_name="toolerr_agent"
        )
        _run_sync(runner, user_id, "s-toolerr", "Weather in Atlantis?")
        rd.flush()
        rd.shutdown()

        # Event arrives in 1-3s, but the OTLP error-span merge into
        # mv_events_v2 is observably 30-60s on busy orgs. 120s gives a
        # generous-but-bounded window so a healthy run resolves quickly.
        deadline = time.time() + 120
        ev = None
        while time.time() < deadline:
            rows = [r for r in query_dashboard() if r.get("userId") == user_id]
            if rows:
                ev = rows[0]
                if ev.get("errorSpans"):
                    break
            time.sleep(3)

        assert ev is not None and ev.get("errorSpans"), (
            "Expected errorSpans to populate after a tool returned {'error': ...}; "
            f"got: errorSpans={ev.get('errorSpans') if ev else None}, "
            f"toolCalls={ev.get('toolCalls') if ev else None}, "
            f"properties.google_adk.error={ev.get('properties', {}).get('google_adk.error') if ev else None}"
        )

        assert_event_shape(ev)
        for es in ev["errorSpans"]:
            assert_error_span_shape(es)
            assert es["span_type"] == "TOOL_CALL", (
                f"Tool errors should mark span_type=TOOL_CALL, got {es['span_type']!r}"
            )
            assert "weather" in es["span_name"].lower() or "tool" in es["span_name"].lower(), (
                f"Tool error span_name should reference the tool; got {es['span_name']!r}"
            )
            assert "Weather provider unavailable" in es["output_payload"], (
                f"errorSpans output_payload should contain the original error "
                f"message; got {es['output_payload']!r}"
            )
