"""
Google ADK (Agent Development Kit) wrapper for Raindrop observability.

Wraps Google ADK Runner objects to automatically capture agent invocations,
tool calls (with individual spans), token usage, and multi-step reasoning,
shipping telemetry to Raindrop via the Interaction API.

Google ADK API:
  - Runner.run()       — synchronous generator yielding Event objects
  - Runner.run_async() — async generator yielding Event objects

The integration captures:
  - Runner invocations (input message, user_id, session_id)
  - Individual tool call spans (name, arguments, result, error, duration)
  - Accumulated token usage across all model calls in a run
  - Model name, agent hierarchy, finish reason
  - LLM-level errors (safety blocks, quota, etc.)
  - Python-level exceptions (captured and re-raised)

Usage:
    from raindrop_google_adk import RaindropGoogleADK, setup_google_adk
    from google.adk import Runner
    from google.adk.agents import LlmAgent
    from google.adk.sessions import InMemorySessionService

    # Class-based API
    rd = RaindropGoogleADK(api_key="your-write-key")
    rd.setup()  # auto-patch all Runner instances

    # Or use the factory functions (backward-compatible)
    setup_google_adk(api_key="your-write-key")

    agent = LlmAgent(
        name="my_agent",
        model="gemini-2.5-flash",
        tools=[get_weather],
    )
    session_service = InMemorySessionService()
    runner = Runner(app_name="my_app", agent=agent, session_service=session_service)

    # All runner.run() / runner.run_async() calls are now automatically traced
"""

from __future__ import annotations

import inspect
import json
import logging
import time
import warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, Generator, AsyncGenerator, Literal, Optional, Union

import raindrop.analytics as raindrop

if TYPE_CHECKING:
    from google.adk.runners import Runner as _RunnerType

logger = logging.getLogger(__name__)


# ======================================================================
# Per-run state tracking
# ======================================================================


@dataclass
class _PendingToolCall:
    """A tool call that has been started but not yet completed."""
    call_id: str
    name: str
    args: Optional[dict[str, object]]
    start_time_ns: int


@dataclass
class _RunTracker:
    """Accumulates telemetry data across all events in a single Runner.run() call."""
    pending_calls: dict[str, _PendingToolCall] = field(default_factory=dict)
    tool_call_names: list[str] = field(default_factory=list)
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    total_tokens: int = 0
    cached_tokens: int = 0
    thoughts_tokens: int = 0
    model_name: Optional[str] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    agent_branch: Optional[str] = None
    finish_reason: Optional[str] = None
    last_author: Optional[str] = None
    last_agent_name: Optional[str] = None


# ======================================================================
# Public API
# ======================================================================


class RaindropGoogleADK:
    """Main entry point for the Raindrop / Google ADK integration.

    Provides both auto-patching (``setup()``) and per-instance wrapping
    (``wrap()``) of Google ADK Runner objects, plus passthrough helpers
    for ``identify`` and ``track_signal``.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
        tracing_enabled: bool = True,
        bypass_otel_for_tools: bool = True,
        debug: bool = False,
    ) -> None:
        if not api_key:
            warnings.warn(
                "[raindrop-google-adk] api_key not provided; telemetry shipping is disabled",
                stacklevel=2,
            )

        self._api_key = api_key
        self._user_id = user_id
        self._convo_id = convo_id

        if debug:
            logger.setLevel(logging.DEBUG)

        raindrop.init(
            api_key=api_key or "",
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def setup(self) -> None:
        """Auto-patch all Runner instances (class-level monkey-patch)."""
        try:
            _patch_runner(user_id=self._user_id, convo_id=self._convo_id)
        except Exception:
            logger.debug("Failed to setup Google ADK patching", exc_info=True)

    def wrap(self, runner: _RunnerType) -> _RunnerType:
        """Wrap a specific Runner instance with Raindrop tracing."""
        try:
            return wrap_runner(runner, user_id=self._user_id, convo_id=self._convo_id)
        except Exception:
            logger.debug("Failed to wrap runner", exc_info=True)
            return runner

    def flush(self) -> None:
        """Flush any pending telemetry events."""
        try:
            raindrop.flush()
        except Exception:
            logger.debug("Failed to flush events", exc_info=True)

    def shutdown(self) -> None:
        """Flush pending events and shut down the telemetry transport."""
        try:
            raindrop.shutdown()
        except Exception:
            logger.debug("Failed to shutdown", exc_info=True)

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Union[str, int, bool, float]]] = None,
    ) -> None:
        """Identify a user with optional traits.

        Args:
            user_id: The user identifier.
            traits: Optional dictionary of user traits.
        """
        try:
            raindrop.identify(user_id=user_id, traits=traits or {})
        except Exception:
            logger.debug("Failed to identify user", exc_info=True)

    def track_signal(
        self,
        event_id: str,
        name: str,
        signal_type: Literal["default", "feedback", "edit"] = "default",
        *,
        timestamp: Optional[str] = None,
        properties: Optional[Dict[str, object]] = None,
        attachment_id: Optional[str] = None,
        comment: Optional[str] = None,
        after: Optional[str] = None,
        sentiment: Optional[Literal["POSITIVE", "NEGATIVE"]] = None,
    ) -> None:
        """Track a signal event.

        Args:
            event_id: The event ID to associate the signal with.
            name: Signal name.
            signal_type: One of "default", "feedback", or "edit".
            timestamp: Optional ISO-8601 timestamp string.
            properties: Optional extra properties dict.
            attachment_id: Optional attachment identifier.
            comment: Optional comment text.
            after: Optional "after" value for edit signals.
            sentiment: Optional sentiment ("POSITIVE" or "NEGATIVE").
        """
        try:
            raindrop.track_signal(
                event_id=event_id,
                name=name,
                signal_type=signal_type,
                timestamp=timestamp,
                properties=properties,
                attachment_id=attachment_id,
                comment=comment,
                after=after,
                sentiment=sentiment,
            )
        except Exception:
            logger.debug("Failed to track signal", exc_info=True)

# ======================================================================
# Backward-compatible factory functions
# ======================================================================


def _noop_instance() -> RaindropGoogleADK:
    """Create a no-op RaindropGoogleADK instance that skips __init__.

    Used as a safe fallback in factory functions when construction fails,
    so that the caller's code continues to work (all methods are try/except
    protected and will silently no-op).
    """
    inst = object.__new__(RaindropGoogleADK)
    inst._api_key = None
    inst._user_id = None
    inst._convo_id = None
    return inst


def setup_google_adk(
    api_key: Optional[str] = None,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = True,
    bypass_otel_for_tools: bool = True,
) -> RaindropGoogleADK:
    """Set up Raindrop instrumentation for Google ADK by monkey-patching
    the Runner class.

    Args:
        api_key: Raindrop API key. If None, telemetry shipping is disabled.
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.

    Returns:
        A :class:`RaindropGoogleADK` instance (with ``setup()`` already called).
    """
    try:
        instance = RaindropGoogleADK(
            api_key=api_key, user_id=user_id, convo_id=convo_id,
            tracing_enabled=tracing_enabled, bypass_otel_for_tools=bypass_otel_for_tools,
        )
        instance.setup()
        return instance
    except Exception:
        logger.debug("Failed to create RaindropGoogleADK via setup_google_adk", exc_info=True)
        return _noop_instance()


def create_raindrop_google_adk(
    api_key: str,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = True,
    bypass_otel_for_tools: bool = True,
) -> RaindropGoogleADK:
    """Create a Raindrop-instrumented Google ADK wrapper.

    This is an alternative to :func:`setup_google_adk` that requires an
    explicit API key and returns an instance with ``wrap`` / ``flush`` /
    ``shutdown`` methods.

    Args:
        api_key: Raindrop API key.
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.

    Returns:
        A :class:`RaindropGoogleADK` instance.
    """
    try:
        return RaindropGoogleADK(
            api_key=api_key, user_id=user_id, convo_id=convo_id,
            tracing_enabled=tracing_enabled, bypass_otel_for_tools=bypass_otel_for_tools,
        )
    except Exception:
        logger.debug("Failed to create RaindropGoogleADK", exc_info=True)
        return _noop_instance()


# ======================================================================
# Internal: class-level monkey-patching
# ======================================================================

_patched = False


def _patch_runner(user_id: Optional[str] = None, convo_id: Optional[str] = None) -> None:
    """Monkey-patch the Google ADK Runner class to add Raindrop tracing."""
    global _patched
    if _patched:
        return

    try:
        from google.adk.runners import Runner
    except ImportError:
        warnings.warn(
            "[raindrop-google-adk] google-adk package not installed; "
            "Runner patching skipped. Install with: pip install google-adk",
            stacklevel=2,
        )
        return

    original_run = Runner.run
    original_run_async = Runner.run_async

    def patched_run(self: _RunnerType, *args: object, **kwargs: object) -> Generator[object, None, None]:
        return _instrumented_run_sync(
            original_run, self, args, kwargs, user_id, convo_id,
        )
    Runner.run = patched_run  # type: ignore[assignment]

    async def patched_run_async(self: _RunnerType, *args: object, **kwargs: object) -> AsyncGenerator[object, None]:
        async for event in _instrumented_run_async(
            original_run_async, self, args, kwargs, user_id, convo_id,
        ):
            yield event
    Runner.run_async = patched_run_async  # type: ignore[assignment]

    _patched = True


# ======================================================================
# Internal: per-instance wrapping
# ======================================================================


def wrap_runner(
    runner: _RunnerType,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
) -> _RunnerType:
    """Wrap a specific Runner instance to capture run() and run_async() calls."""
    try:
        if getattr(runner, "_raindrop_wrapped", None) is True:
            return runner

        if _patched:
            if user_id or convo_id:
                warnings.warn(
                    "[raindrop-google-adk] wrap() called with user_id/convo_id but "
                    "setup_google_adk() was already called. The class-level patch's "
                    "user_id/convo_id will be used instead. Call create_raindrop_google_adk() "
                    "without setup() if you need per-runner user_id/convo_id.",
                    stacklevel=2,
                )
            runner._raindrop_wrapped = True  # type: ignore[attr-defined]
            return runner

        original_run = runner.run
        original_run_async = runner.run_async

        def wrapped_run(*args: object, **kwargs: object) -> Generator[object, None, None]:
            return _instrumented_run_sync(
                original_run, runner, args, kwargs, user_id, convo_id,
            )

        async def wrapped_run_async(*args: object, **kwargs: object) -> AsyncGenerator[object, None]:
            async for event in _instrumented_run_async(
                original_run_async, runner, args, kwargs, user_id, convo_id,
            ):
                yield event

        runner.run = wrapped_run  # type: ignore[assignment]
        runner.run_async = wrapped_run_async  # type: ignore[assignment]
        runner._raindrop_wrapped = True  # type: ignore[attr-defined]
    except Exception:
        logger.debug("Failed to wrap runner instance", exc_info=True)
    return runner


# ======================================================================
# Internal: instrumented generator wrappers
# ======================================================================


_ADK_RUNNERS_MODULE = "google.adk.runners"
_ADK_INNER_ASYNC_FRAME = "_invoke_run_async"


def _is_inner_async_from_adk_sync_run() -> bool:
    """``True`` if this ``run_async`` call is the inner async loop driven
    by ADK's ``Runner.run`` worker thread.

    ADK's sync ``Runner.run`` spawns a worker thread that runs an internal
    ``_invoke_run_async`` coroutine, which awaits ``self.run_async(...)``.
    With both ``run`` and ``run_async`` patched, that inner await re-enters
    our wrapper and emits a duplicate finalized event for one logical run.
    We detect the inner case by walking the synchronous frame chain for
    ``_invoke_run_async`` defined in ``google.adk.runners`` — the awaiter
    appears as ``f_back`` on an ``async def`` body's frame while it is
    executing. This is per-call rather than per-instance, so it is safe
    under arbitrary cross-thread concurrency on a shared runner: an
    external direct ``run_async`` call has no such frame on its stack and
    is correctly instrumented even while another thread's sync run is in
    flight on the same runner.

    Returning ``False`` when we should have returned ``True`` (e.g. ADK
    renames ``_invoke_run_async``) re-introduces the duplicate-event bug
    and is loudly visible in the dashboard. Returning ``True`` when we
    should have returned ``False`` would silently drop external concurrent
    ``run_async`` calls — exactly the failure mode this replaces. We bias
    toward the visible regression over the silent one.
    """
    try:
        frame = inspect.currentframe()
        while frame is not None:
            if frame.f_code.co_name == _ADK_INNER_ASYNC_FRAME:
                module = frame.f_globals.get("__name__", "")
                if (
                    module == _ADK_RUNNERS_MODULE
                    or module.startswith(_ADK_RUNNERS_MODULE + ".")
                ):
                    return True
            frame = frame.f_back
    except Exception:
        logger.debug(
            "Failed to inspect call stack for inner-async detection",
            exc_info=True,
        )
    return False


def _instrumented_run_sync(
    original_fn: object,
    runner: object,
    args: tuple[object, ...],
    kwargs: dict[str, object],
    user_id: Optional[str],
    convo_id: Optional[str],
) -> Generator[object, None, None]:
    """Instrument a synchronous Runner.run() call.

    ADK's real ``Runner.run`` drives ``self.run_async`` on a worker thread.
    When both methods are patched (class-level setup), that inner async
    iteration would re-enter our instrumentation and emit a duplicate
    finalized event for one logical run. ``_instrumented_run_async``
    detects the inner-async case via stack inspection and bypasses its
    own instrumentation in that case, so this function does not need
    per-runner state to coordinate with it.
    """
    try:
        input_text = _extract_input_text(kwargs)
        app_name = _get_app_name(runner)
        run_user_id = str(kwargs["user_id"]) if kwargs.get("user_id") else user_id
        session_id = kwargs.get("session_id")
    except Exception:
        logger.debug("Failed to extract run parameters", exc_info=True)
        yield from original_fn(runner, *args, **kwargs) if _is_unbound(original_fn) else original_fn(*args, **kwargs)
        return

    interaction = None
    try:
        interaction = raindrop.begin(
            user_id=run_user_id or "unknown",
            event="ai_generation",
            input=input_text,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to begin interaction", exc_info=True)

    tracker = _RunTracker()
    last_event: object = None
    error_occurred = False
    try:
        gen = original_fn(runner, *args, **kwargs) if _is_unbound(original_fn) else original_fn(*args, **kwargs)
        for event in gen:
            try:
                _process_event(event, interaction, tracker)
                if _is_final_response(event):
                    last_event = event
            except Exception:
                logger.debug("Failed to process event", exc_info=True)
            yield event
    except Exception as exc:
        error_occurred = True
        if interaction:
            try:
                props = _build_properties_from_tracker(
                    tracker, app_name, run_user_id,
                    str(session_id) if session_id else None,
                )
                props["google_adk.error"] = True
                props["google_adk.error_message"] = str(exc)
                interaction.set_properties(props)
            except Exception:
                logger.debug("Failed to set error properties", exc_info=True)
            try:
                interaction.finish()
            except Exception:
                logger.debug("Failed to finish interaction after error", exc_info=True)
        raise
    finally:
        if not error_occurred:
            try:
                _finish_interaction(interaction, last_event, tracker, app_name, run_user_id, session_id)
            except Exception:
                logger.debug("Failed to finish interaction", exc_info=True)


async def _instrumented_run_async(
    original_fn: object,
    runner: object,
    args: tuple[object, ...],
    kwargs: dict[str, object],
    user_id: Optional[str],
    convo_id: Optional[str],
) -> AsyncGenerator[object, None]:
    """Instrument an async Runner.run_async() call.

    If we are being called as the inner async loop of an already-instrumented
    sync ``Runner.run`` invocation, we skip our own instrumentation: the
    outer ``_instrumented_run_sync`` will record a single Raindrop event for
    the run. Without this guard, a single ``Runner.run`` call produces two
    finalized dashboard events. The detection is per-call (stack inspection),
    so concurrent direct ``run_async`` calls on the same runner from another
    thread are correctly instrumented even while a sync run is in flight.
    """
    if _is_inner_async_from_adk_sync_run():
        if _is_unbound(original_fn):
            async for event in original_fn(runner, *args, **kwargs):
                yield event
        else:
            async for event in original_fn(*args, **kwargs):
                yield event
        return

    try:
        input_text = _extract_input_text(kwargs)
        app_name = _get_app_name(runner)
        run_user_id = str(kwargs["user_id"]) if kwargs.get("user_id") else user_id
        session_id = kwargs.get("session_id")
    except Exception:
        logger.debug("Failed to extract async run parameters", exc_info=True)
        if _is_unbound(original_fn):
            async for event in original_fn(runner, *args, **kwargs):
                yield event
        else:
            async for event in original_fn(*args, **kwargs):
                yield event
        return

    interaction = None
    try:
        interaction = raindrop.begin(
            user_id=run_user_id or "unknown",
            event="ai_generation",
            input=input_text,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to begin async interaction", exc_info=True)

    tracker = _RunTracker()
    last_event: object = None
    error_occurred = False
    try:
        if _is_unbound(original_fn):
            async for event in original_fn(runner, *args, **kwargs):
                try:
                    _process_event(event, interaction, tracker)
                    if _is_final_response(event):
                        last_event = event
                except Exception:
                    logger.debug("Failed to process async event", exc_info=True)
                yield event
        else:
            async for event in original_fn(*args, **kwargs):
                try:
                    _process_event(event, interaction, tracker)
                    if _is_final_response(event):
                        last_event = event
                except Exception:
                    logger.debug("Failed to process async event", exc_info=True)
                yield event
    except Exception as exc:
        error_occurred = True
        if interaction:
            try:
                props = _build_properties_from_tracker(
                    tracker, app_name, run_user_id,
                    str(session_id) if session_id else None,
                )
                props["google_adk.error"] = True
                props["google_adk.error_message"] = str(exc)
                interaction.set_properties(props)
            except Exception:
                logger.debug("Failed to set async error properties", exc_info=True)
            try:
                interaction.finish()
            except Exception:
                logger.debug("Failed to finish async interaction after error", exc_info=True)
        raise
    finally:
        if not error_occurred:
            try:
                _finish_interaction(interaction, last_event, tracker, app_name, run_user_id, session_id)
            except Exception:
                logger.debug("Failed to finish async interaction", exc_info=True)


# ======================================================================
# Internal: per-event processing
# ======================================================================


def _process_event(event: object, interaction: object, tracker: _RunTracker) -> None:
    """Process a single ADK event, updating the tracker and creating tool spans."""

    # --- Function calls (tool invocation start) ---
    try:
        if hasattr(event, "get_function_calls"):
            for fc in event.get_function_calls():
                call_id = getattr(fc, "id", None) or getattr(fc, "name", "unknown")
                name = getattr(fc, "name", None) or "unknown"
                args = getattr(fc, "args", None)
                tracker.pending_calls[call_id] = _PendingToolCall(
                    call_id=call_id,
                    name=name,
                    args=args,
                    start_time_ns=time.time_ns(),
                )
    except Exception:
        logger.debug("Failed to extract function calls", exc_info=True)

    # --- Function responses (tool invocation end) ---
    try:
        if hasattr(event, "get_function_responses"):
            for fr in event.get_function_responses():
                resp_id = getattr(fr, "id", None) or getattr(fr, "name", "unknown")
                resp_name = getattr(fr, "name", None)
                response = getattr(fr, "response", None) or {}

                pending = tracker.pending_calls.pop(resp_id, None)
                if pending is None and resp_name:
                    for k, v in list(tracker.pending_calls.items()):
                        if v.name == resp_name:
                            pending = tracker.pending_calls.pop(k)
                            break

                tool_name = (pending.name if pending else resp_name) or "unknown"
                tool_input = pending.args if pending else None
                start_ns = pending.start_time_ns if pending else time.time_ns()
                duration_ms = (time.time_ns() - start_ns) / 1_000_000

                tool_error: Optional[str] = None
                if isinstance(response, dict) and "error" in response:
                    tool_error = str(response["error"])

                tool_output = response if not tool_error else None

                tracker.tool_call_names.append(tool_name)

                if interaction is not None:
                    try:
                        interaction.track_tool(
                            name=tool_name,
                            input=tool_input,
                            output=tool_output,
                            duration_ms=duration_ms,
                            error=RuntimeError(tool_error) if tool_error else None,
                        )
                    except Exception:
                        logger.debug("Failed to track tool span", exc_info=True)
    except Exception:
        logger.debug("Failed to extract function responses", exc_info=True)

    # --- Token usage accumulation ---
    try:
        usage = getattr(event, "usage_metadata", None)
        if usage:
            v = getattr(usage, "prompt_token_count", None)
            if v is not None:
                tracker.total_prompt_tokens += int(v)
            v = getattr(usage, "candidates_token_count", None)
            if v is not None:
                tracker.total_completion_tokens += int(v)
            v = getattr(usage, "total_token_count", None)
            if v is not None:
                tracker.total_tokens += int(v)
            v = getattr(usage, "cached_content_token_count", None)
            if v is not None:
                tracker.cached_tokens += int(v)
            v = getattr(usage, "thoughts_token_count", None)
            if v is not None:
                tracker.thoughts_tokens += int(v)
    except Exception:
        logger.debug("Failed to accumulate token usage", exc_info=True)

    # --- Model name (first non-None wins) ---
    if tracker.model_name is None:
        try:
            m = getattr(event, "model_version", None)
            if m:
                tracker.model_name = str(m)
            else:
                m = getattr(event, "model", None)
                if m:
                    tracker.model_name = str(m)
        except Exception:
            logger.debug("Failed to extract model", exc_info=True)

    # --- LLM-level errors ---
    try:
        ec = getattr(event, "error_code", None)
        if ec:
            tracker.error_code = str(ec)
        em = getattr(event, "error_message", None)
        if em:
            tracker.error_message = str(em)
    except Exception:
        logger.debug("Failed to extract LLM error", exc_info=True)

    # --- Agent hierarchy ---
    try:
        branch = getattr(event, "branch", None)
        if branch:
            tracker.agent_branch = str(branch)
    except Exception:
        logger.debug("Failed to extract agent branch", exc_info=True)

    # --- Finish reason ---
    try:
        fr = getattr(event, "finish_reason", None)
        if fr:
            tracker.finish_reason = str(fr)
    except Exception:
        logger.debug("Failed to extract finish_reason", exc_info=True)

    # --- Author / agent name (take latest) ---
    try:
        author = getattr(event, "author", None)
        if author and author != "user":
            tracker.last_author = str(author)
        agent_name = getattr(event, "agent_name", None)
        if agent_name:
            tracker.last_agent_name = str(agent_name)
        elif author and author != "user":
            tracker.last_agent_name = str(author)
    except Exception:
        logger.debug("Failed to extract author/agent_name", exc_info=True)


# ======================================================================
# Internal: interaction finalization
# ======================================================================


def _finish_interaction(
    interaction: object,
    last_event: object,
    tracker: _RunTracker,
    app_name: Optional[str],
    user_id: Optional[str],
    session_id: object,
) -> None:
    """Finalize the interaction using accumulated tracker data."""
    if interaction is None:
        return

    output_text = _extract_output_text(last_event)
    properties = _build_properties_from_tracker(
        tracker, app_name, user_id,
        str(session_id) if session_id else None,
    )

    model_name = tracker.model_name
    if model_name:
        try:
            raindrop._track_ai_partial(
                raindrop.PartialTrackAIEvent(
                    event_id=interaction.id, ai_data={"model": model_name}
                )
            )
        except Exception:
            logger.debug("Failed to track model via _track_ai_partial", exc_info=True)

    interaction.finish(
        output=output_text,
        properties=properties if properties else None,
    )


def _build_properties_from_tracker(
    tracker: _RunTracker,
    app_name: Optional[str],
    user_id: Optional[str],
    session_id: Optional[str],
) -> dict[str, object]:
    """Build properties dict from accumulated tracker data."""
    props: dict[str, object] = {}

    if app_name:
        props["google_adk.app_name"] = app_name
    if user_id:
        props["google_adk.user_id"] = user_id
    if session_id:
        props["google_adk.session_id"] = session_id

    if tracker.last_author:
        props["google_adk.author"] = tracker.last_author
    if tracker.last_agent_name:
        props["google_adk.agent_name"] = tracker.last_agent_name

    if tracker.total_prompt_tokens > 0:
        props["ai.usage.prompt_tokens"] = tracker.total_prompt_tokens
    if tracker.total_completion_tokens > 0:
        props["ai.usage.completion_tokens"] = tracker.total_completion_tokens
    if tracker.total_tokens > 0:
        props["ai.usage.total_tokens"] = tracker.total_tokens
    if tracker.cached_tokens > 0:
        props["ai.usage.cached_tokens"] = tracker.cached_tokens
    if tracker.thoughts_tokens > 0:
        props["ai.usage.thoughts_tokens"] = tracker.thoughts_tokens

    if tracker.tool_call_names:
        props["google_adk.tool_calls_count"] = len(tracker.tool_call_names)
        try:
            props["google_adk.tool_call_names"] = json.dumps(tracker.tool_call_names)
        except Exception:
            pass

    if tracker.error_code:
        props["google_adk.error_code"] = tracker.error_code
    if tracker.error_message:
        props["google_adk.llm_error_message"] = tracker.error_message

    if tracker.agent_branch:
        props["google_adk.agent_branch"] = tracker.agent_branch
    if tracker.finish_reason:
        props["google_adk.finish_reason"] = tracker.finish_reason

    return props


# ======================================================================
# Internal: extraction helpers
# ======================================================================


def _extract_input_text(kwargs: dict[str, object]) -> Optional[str]:
    """Extract the user's input text from Runner.run() keyword arguments."""
    new_message = kwargs.get("new_message")
    if new_message is None:
        return None

    try:
        if hasattr(new_message, "parts") and new_message.parts:
            texts: list[str] = []
            for part in new_message.parts:
                if hasattr(part, "text") and part.text:
                    texts.append(part.text)
            if texts:
                return " ".join(texts)
    except Exception:
        logger.debug("Failed to extract input text from parts", exc_info=True)

    return _safe_str(new_message)


def _extract_output_text(event: object) -> Optional[str]:
    """Extract the output text from a final ADK Event."""
    if event is None:
        return None

    try:
        content = getattr(event, "content", None)
        if content is not None and hasattr(content, "parts") and content.parts:
            texts: list[str] = []
            for part in content.parts:
                if hasattr(part, "text") and part.text:
                    texts.append(part.text)
            if texts:
                return " ".join(texts)
    except Exception:
        logger.debug("Failed to extract output text", exc_info=True)

    return _safe_str(event)


def _extract_model_from_event(event: object) -> Optional[str]:
    """Try to extract model name from an ADK Event."""
    if event is None:
        return None

    try:
        model_version = getattr(event, "model_version", None)
        if model_version:
            return str(model_version)
    except Exception:
        logger.debug("Failed to extract model_version", exc_info=True)

    try:
        model = getattr(event, "model", None)
        if model:
            return str(model)
    except Exception:
        logger.debug("Failed to extract model", exc_info=True)

    return None


def _build_properties(
    event: object,
    app_name: Optional[str],
    user_id: Optional[str],
    session_id: Optional[str],
) -> dict[str, object]:
    """Build properties dict with ADK-specific metadata (legacy, for unit test compat)."""
    props: dict[str, object] = {}

    if app_name:
        props["google_adk.app_name"] = app_name
    if user_id:
        props["google_adk.user_id"] = user_id
    if session_id:
        props["google_adk.session_id"] = session_id

    if event is None:
        return props

    try:
        author = getattr(event, "author", None)
        if author:
            props["google_adk.author"] = str(author)
    except Exception:
        logger.debug("Failed to extract author", exc_info=True)

    try:
        agent_name = _get_agent_name_from_event(event)
        if agent_name:
            props["google_adk.agent_name"] = agent_name
    except Exception:
        logger.debug("Failed to extract agent name", exc_info=True)

    try:
        usage_metadata = getattr(event, "usage_metadata", None)
        if usage_metadata:
            prompt_tokens = getattr(usage_metadata, "prompt_token_count", None)
            if prompt_tokens is not None:
                props["ai.usage.prompt_tokens"] = prompt_tokens
            completion_tokens = getattr(usage_metadata, "candidates_token_count", None)
            if completion_tokens is not None:
                props["ai.usage.completion_tokens"] = completion_tokens
            total_tokens = getattr(usage_metadata, "total_token_count", None)
            if total_tokens is not None:
                props["ai.usage.total_tokens"] = total_tokens
    except Exception:
        logger.debug("Failed to extract token usage", exc_info=True)

    try:
        if hasattr(event, "get_function_calls"):
            function_calls = event.get_function_calls()
            if function_calls:
                props["google_adk.tool_calls_count"] = len(function_calls)
    except Exception:
        logger.debug("Failed to extract function calls count", exc_info=True)

    return props


def _get_app_name(runner: object) -> Optional[str]:
    """Extract the app_name from a Runner instance."""
    try:
        return getattr(runner, "app_name", None)
    except Exception:
        logger.debug("Failed to get app_name", exc_info=True)
        return None


def _get_agent_name_from_event(event: object) -> Optional[str]:
    """Try to extract agent name from an ADK Event."""
    try:
        agent_name = getattr(event, "agent_name", None)
        if agent_name:
            return str(agent_name)
        author = getattr(event, "author", None)
        if author:
            return str(author)
    except Exception:
        logger.debug("Failed to extract agent name from event", exc_info=True)
    return None


def _is_final_response(event: object) -> bool:
    """Check if an ADK Event is the final response."""
    try:
        if hasattr(event, "is_final_response") and callable(event.is_final_response):
            return bool(event.is_final_response())
    except Exception:
        logger.debug("Failed to check is_final_response", exc_info=True)
    return False


def _is_unbound(fn: object) -> bool:
    """Check if a function is an unbound method (class method not bound to instance)."""
    try:
        return not hasattr(fn, "__self__")
    except Exception:
        logger.debug("Failed to check if function is unbound", exc_info=True)
        return False


def _safe_str(value: object) -> Optional[str]:
    """Convert a value to string safely."""
    if value is None:
        return None
    if isinstance(value, str):
        return value
    try:
        if hasattr(value, "model_dump_json"):
            return value.model_dump_json()
        if hasattr(value, "model_dump"):
            return json.dumps(value.model_dump(), default=str)
        return json.dumps(value, default=str)
    except Exception:
        try:
            return str(value)
        except Exception:
            logger.debug("Failed to convert value to string", exc_info=True)
            return None
