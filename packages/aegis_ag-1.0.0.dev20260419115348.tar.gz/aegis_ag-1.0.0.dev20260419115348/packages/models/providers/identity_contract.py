"""Provider-facing identity contract helpers.

These helpers forward the profile-built Aegis prompt contract to live providers
without layering a second hardcoded persona on top.
"""

from __future__ import annotations

from packages.models.runtime import ModelRequest

_FALLBACK_IDENTITY_LINES = (
    "identity-product=Aegis",
    "identity-source=calling-surface prompt contract plus canonical identity, user, relationship, and work state",
    "Stay coherent with the active Aegis identity and be truthful about uncertainty and capability.",
)


def build_provider_identity_contract(request: ModelRequest) -> str:
    """Return the system prompt contract for a live provider request."""

    frozen_prefix = str(request.context.get("frozen_prefix_prompt", "") or "").strip()
    session_snapshot = str(request.context.get("session_snapshot_prompt", "") or "").strip()
    sections = [section for section in (frozen_prefix, session_snapshot) if section]
    if sections:
        return "\n\n".join(sections)
    rendered_prompt = str(request.context.get("rendered_prompt", "") or "").strip()
    if rendered_prompt:
        return rendered_prompt
    return "\n".join(_FALLBACK_IDENTITY_LINES)


def build_provider_user_prompt(request: ModelRequest) -> str:
    """Return the user-facing prompt payload for a live provider request."""

    prompt = request.prompt.strip() or "acknowledged"
    turn_injections = str(request.context.get("turn_injections_prompt", "") or "").strip()
    if not turn_injections:
        return prompt
    return f"{prompt}\n\n{turn_injections}"
