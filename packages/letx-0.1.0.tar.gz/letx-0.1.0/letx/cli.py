"""
letx.cli
--------
Shared CLI dispatcher — each entry_point calls run_module(name).
Copyright (C) 2026 AMMAAR BAKSHI

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>6
"""
import sys
from argparse import ArgumentParser

from letx.modules import REGISTRY
from letx.utils.printer import console, error


def run_module(module_name: str):
    """Generic dispatcher. Called by each console_scripts entry point."""
    module = REGISTRY.get(module_name)
    if module is None:
        error(f"Unknown module: [bold]{module_name}[/bold]")
        sys.exit(1)

    parser = ArgumentParser(
        prog=module.name,
        description=module.description,
    )
    module.register_args(parser)

    args = parser.parse_args()
    sys.exit(module.run(args))


# ── Individual entry points ───────────────────────────────────────────────────

def letx_debug():
    run_module("letxDebug")


def letx_fix():
    run_module("letxFix")


# ── Global `letx` meta-command ────────────────────────────────────────────────

def letx_main():
    """
    `letx` — lists all available tools and their descriptions.
    """
    from rich.table import Table
    e = Table(box=box.ROUNDED, border_style="yellow", show_header=True)
    table.add_column("Command", style="bold cyan", no_wrap=True)
    table.add_column("Description", style="white")

    for name, mod in REGISTRY.items():
        table.add_row(name, mod.description)

    console.print(table)
    console.print("\n[dim]Run [bold]<command> --help[/bold] for usage details.[/dim]\n");