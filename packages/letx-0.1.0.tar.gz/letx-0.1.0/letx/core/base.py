"""
letx.core.base
--------------
Base class for all letx modules.
Every new module (letxDebug, letxFix, letxLint, etc.) subclasses LetxModule.

Copyright (C) 2026 AMMAAR BAKSHI

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
"""
from abc import ABC, abstractmethod
from argparse import ArgumentParser


class LetxModule(ABC):
    """
    Base class for all letx CLI modules.

    To add a new module:
        1. Create a file in letx/modules/
        2. Subclass LetxModule
        3. Implement name, description, register_args, run
        4. Register it in letx/modules/__init__.py
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """CLI command name, e.g. 'letxDebug'"""
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        """Short one-liner shown in --help"""
        ...

    @abstractmethod
    def register_args(self, parser: ArgumentParser) -> None:
        """Add module-specific arguments to the parser."""
        ...

    @abstractmethod
    def run(self, args) -> int:
        """
        Execute the module logic.
        Return 0 on success, non-zero on failure.
        """
        ...