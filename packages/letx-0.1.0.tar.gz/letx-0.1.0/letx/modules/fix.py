"""
letx.modules.fix
----------------
letxFix — Code fixer and cleaner.

Usage:
    letxFix -rm -cmt file.py          # remove all comments
    letxFix -rm -cmt file.py folder/  # remove all comments from file or folder
    letxFix -rm -cmt -s file.py       # remove only single-line comments (#)
    letxFix -rm -cmt -m file.py       # remove only multi-line comments ( / ''')

Copyright (C) 2026 AMMAAR BAKSHI

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
"""
import os
import re
import glob
from argparse import ArgumentParser
from pathlib import Path
from typing import List, Tuple

from letx.core.base import LetxModule
from letx.utils.printer import (
    console, header, section, success, error,
    warning, info, divider
)


# ── Comment removal logic ─────────────────────────────────────────────────────

def remove_single_line_comments(source: str) -> Tuple[str, int]:
    """Remove # comments, but not inside strings."""
    lines = source.splitlines(keepends=True)
    result = []
    count = 0
    in_multiline = False  # rough guard

    for line in lines:
        stripped = line.rstrip()
        # Very rough heuristic: skip removal inside triple-quoted blocks
        # (full string-aware parsing is handled by remove_all_comments)
        clean = re.sub(r'(?<!["\'])#[^\n]*', '', line)
        if clean.rstrip() != stripped:
            count += 1
        result.append(clean)

    return "".join(result), count


def remove_multiline_comments(source: str) -> Tuple[str, int]:
    """Remove triple-quoted strings used as comments (not assigned or returned)."""
    count = [0]

    def replacer(m):
        count[0] += 1
        return ""

    # Match triple-quoted strings at start of line (docstring-style standalone comments)
    cleaned = re.sub(
        r'(?m)^[ \t]*("""[\s\S]*?"""|\'\'\'[\s\S]*?\'\'\')\s*\n?',
        replacer,
        source,
    )
    return cleaned, count[0]


def remove_all_comments(source: str) -> Tuple[str, int]:
    """Remove both single-line and multi-line comments."""
    src, c1 = remove_multiline_comments(source)
    src, c2 = remove_single_line_comments(src)
    return src, c1 + c2


# ── File/folder collector ─────────────────────────────────────────────────────

def collect_python_files(targets: List[str]) -> List[str]:
    files = []
    for t in targets:
        if os.path.isfile(t) and t.endswith(".py"):
            files.append(t)
        elif os.path.isdir(t):
            files.extend(
                str(p) for p in Path(t).rglob("*.py")
            )
        else:
            matches = glob.glob(t)
            files.extend(f for f in matches if f.endswith(".py"))
    return sorted(set(files))


# ── Module ────────────────────────────────────────────────────────────────────

class FixModule(LetxModule):

    @property
    def name(self) -> str:
        return "letxFix"

    @property
    def description(self) -> str:
        return "Code fixer and cleaner — remove comments, strip dead code, and more"

    def register_args(self, parser: ArgumentParser) -> None:
        parser.add_argument("targets", nargs="+", help="File(s) or folder(s) to fix")

        # Actions
        rm_group = parser.add_argument_group("Remove actions")
        rm_group.add_argument("-rm", action="store_true", help="Enable removal mode")
        rm_group.add_argument("-cmt", action="store_true", help="Target: comments")

        # Comment type sub-flags
        cmt_type = parser.add_mutually_exclusive_group()
        cmt_type.add_argument("-s", "--single", action="store_true",
                               help="Only single-line comments (#)")
        cmt_type.add_argument("-m", "--multi", action="store_true",
                               help="Only multi-line comments (triple-quoted)")

        parser.add_argument("--dry-run", action="store_true",
                            help="Preview changes without writing files")

    def run(self, args) -> int:
        header("letxFix", "Code fixer & cleaner")

        # Validate flags
        if args.rm and not args.cmt:
            error("Use [bold]-rm[/bold] together with an action flag like [bold]-cmt[/bold]")
            return 1

        if not args.rm:
            error("No action specified. Try [bold]letxFix -rm -cmt file.py[/bold]")
            return 1

        if args.cmt:
            return self._run_remove_comments(args)

        return 0

    def _run_remove_comments(self, args) -> int:
        files = collect_python_files(args.targets)

        if not files:
            warning("No Python files found in the given targets.")
            return 1

        if args.single:
            mode_label = "single-line comments (#)"
            remover = remove_single_line_comments
        elif args.multi:
            mode_label = "multi-line comments (triple-quoted)"
            remover = remove_multiline_comments
        else:
            mode_label = "all comments"
            remover = remove_all_comments

        section(f"Removing {mode_label}", "🧹")
        if args.dry_run:
            warning("DRY RUN — no files will be modified")

        divider()
        total_removed = 0
        total_files = 0

        for fpath in files:
            try:
                original = Path(fpath).read_text(encoding="utf-8")
                cleaned, count = remover(original)

                if count == 0:
                    info(f"[dim]{fpath}[/dim] — no comments found")
                    continue

                total_removed += count
                total_files += 1

                if args.dry_run:
                    console.print(
                        f"[yellow]~[/yellow] {fpath} "
                        f"[dim]({count} comment(s) would be removed)[/dim]"
                    )
                else:
                    Path(fpath).write_text(cleaned, encoding="utf-8")
                    success(
                        f"{fpath} [dim]— {count} comment(s) removed[/dim]"
                    )

            except Exception as e:
                error(f"Could not process {fpath}: {e}")

        divider()
        if args.dry_run:
            info(
                f"DRY RUN complete: [bold]{total_removed}[/bold] comment(s) across "
                f"[bold]{total_files}[/bold] file(s) would be removed."
            )
        else:
            success(
                f"Done! Removed [bold]{total_removed}[/bold] comment(s) from "
                f"[bold]{total_files}[/bold] file(s)."
            )
        return 0