"""
letx.utils.runner
-----------------
Runs a Python file in a subprocess and captures stdout, stderr, exit code.
Copyright (C) 2026 AMMAAR BAKSHI

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>
"""
import subprocess
import sys
from dataclasses import dataclass
from typing import Optional


@dataclass
class RunResult:
    stdout: str
    stderr: str
    returncode: int
    traceback: Optional[str] = None
    error_type: Optional[str] = None
    error_message: Optional[str] = None
    error_line: Optional[int] = None

    @property
    def has_error(self) -> bool:
        return self.returncode != 0


def run_file(filepath: str) -> RunResult:
    """Execute a Python file and return structured result."""
    result = subprocess.run(
        [sys.executable, filepath],
        capture_output=True,
        text=True,
    )

    run = RunResult(
        stdout=result.stdout,
        stderr=result.stderr,
        returncode=result.returncode,
    )

    if run.has_error and result.stderr:
        run.traceback = result.stderr.strip()
        lines = result.stderr.strip().splitlines()

        # Extract error type and message from last line like "ValueError: something"
        for line in reversed(lines):
            line = line.strip()
            if ": " in line and not line.startswith("File ") and not line.startswith("Traceback"):
                parts = line.split(": ", 1)
                run.error_type = parts[0].strip()
                run.error_message = parts[1].strip() if len(parts) > 1 else ""
                break

        # Extract line number from traceback
        for line in lines:
            if "line " in line and filepath in line:
                try:
                    run.error_line = int(line.strip().split("line ")[-1].rstrip(","))
                except ValueError:
                    pass

    return run
