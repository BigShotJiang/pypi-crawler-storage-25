"""
letx.utils.printer
------------------
Centralized rich terminal output for all letx tools.
Copyright (C) 2026 AMMAAR BAKSHI

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>
"""
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from rich import box

console = Console()


def header(title: str, subtitle: str = ""):
    text = Text()
    text.append("⚡ letx", style="bold yellow")
    text.append(f" › {title}", style="bold white")
    if subtitle:
        text.append(f"\n{subtitle}", style="dim")
    console.print(Panel(text, box=box.ROUNDED, border_style="yellow", padding=(0, 2)))


def section(title: str, icon: str = "▸"):
    console.print(f"\n[bold cyan]{icon} {title}[/bold cyan]")


def success(msg: str):
    console.print(f"[bold green]✔[/bold green] {msg}")


def error(msg: str):
    console.print(f"[bold red]✘[/bold red] {msg}")


def warning(msg: str):
    console.print(f"[bold yellow]⚠[/bold yellow]  {msg}")


def info(msg: str):
    console.print(f"[dim]ℹ[/dim]  {msg}")


def code_block(code: str, language: str = "python"):
    syntax = Syntax(code, language, theme="monokai", line_numbers=True, word_wrap=True)
    console.print(syntax)


def divider():
    console.print("[dim]─" * 60 + "[/dim]")


def tip(msg: str):
    console.print(Panel(f"[bold green]💡 Tip:[/bold green] {msg}", border_style="green", box=box.SIMPLE))
