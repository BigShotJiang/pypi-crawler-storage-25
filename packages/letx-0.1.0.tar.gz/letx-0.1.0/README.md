# ⚡ letx

> The developer utility toolkit — debug smarter, fix faster.

`letx` is a modular Python CLI library built for everyone: beginners who need plain-English error explanations, and experienced devs who want fast, no-noise tooling.

---

## Installation

```bash
pip install letx
# or from source:
pip install -e .
```

---

## Tools

### `letxDebug` — Smart Debugger

Run a Python file with smarter output than a raw traceback.

| Command | What it does |
|---|---|
| `letxDebug file.py` | Run and show clean debug info |
| `letxDebug -e file.py` | Explain the error in plain English |
| `letxDebug -s file.py` | Suggest a fix / solution |
| `letxDebug -a file.py` | Everything: explain + solution |

**Example:**
```bash
$ letxDebug -a my_script.py

⚡ letx › letxDebug
Debugging → my_script.py

🔴 Traceback
  ...
  NameError: name 'pritn' is not defined

💬 Error Explanation
  You used a variable or function that Python doesn't know about yet.

🔧 Suggested Fix
  1. Check the spelling of the variable name
  2. Make sure you defined the variable before using it
  3. If it's a function from a module, did you import it?
```

---

### `letxFix` — Code Fixer

Fix and clean up your Python files.

#### Remove Comments

```bash
# Remove ALL comments from a file
letxFix -rm -cmt file.py

# Remove ALL comments from a folder
letxFix -rm -cmt src/

# Remove only single-line comments (#)
letxFix -rm -cmt -s file.py

# Remove only multi-line comments (triple-quoted)
letxFix -rm -cmt -m file.py

# Dry run — preview what would change, no files modified
letxFix -rm -cmt --dry-run src/
```

---

## `letx` — List all tools

```bash
$ letx

⚡ letx › The developer utility toolkit
┌────────────┬───────────────────────────────────────────────────────┐
│ Command    │ Description                                           │
├────────────┼───────────────────────────────────────────────────────┤
│ letxDebug  │ Smart Python debugger — run, explain, and fix errors  │
│ letxFix    │ Code fixer and cleaner                                │
└────────────┴───────────────────────────────────────────────────────┘
```

---

## Extending letx

Adding a new module takes 4 steps:

**1. Create `letx/modules/mymodule.py`:**

```python
from letx.core.base import LetxModule
from argparse import ArgumentParser

class MyModule(LetxModule):
    @property
    def name(self): return "letxMy"

    @property
    def description(self): return "Does something awesome"

    def register_args(self, parser: ArgumentParser):
        parser.add_argument("file", help="Target file")
        parser.add_argument("-x", action="store_true", help="Do X")

    def run(self, args) -> int:
        # your logic here
        return 0
```

**2. Register it in `letx/modules/__init__.py`:**
```python
from letx.modules.mymodule import MyModule

REGISTRY = {
    ...
    "letxMy": MyModule(),
}
```

**3. Add a CLI entry point in `letx/cli.py`:**
```python
def letx_my():
    run_module("letxMy")
```

**4. Register in `pyproject.toml`:**
```toml
[project.scripts]
letxMy = "letx.cli:letx_my"
```

Done. ✔

---

## License

This project is licensed under the GNU General Public License v3.0 - see the [LICENSE](LICENSE) file for details.
