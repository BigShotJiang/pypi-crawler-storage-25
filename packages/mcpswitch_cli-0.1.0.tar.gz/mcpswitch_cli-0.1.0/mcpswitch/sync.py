"""Multi-machine profile sync via GitHub Gists.

No backend server needed. Each user gets a private Gist as their sync target.

Pro feature:
  mcpswitch sync --setup <github-token>   → create private Gist, store token
  mcpswitch sync --push                   → upload local profiles to Gist
  mcpswitch sync --pull                   → download profiles from Gist
  mcpswitch sync --status                 → show sync state

GitHub token needs: gist scope only (minimal permissions).
Create at: https://github.com/settings/tokens/new?scopes=gist
"""

import json
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional

SYNC_CONFIG_FILE = Path.home() / ".mcpswitch" / "sync.json"
GIST_API = "https://api.github.com/gists"
GIST_FILENAME = "mcpswitch-profiles.json"


def _load_sync_config() -> dict:
    if not SYNC_CONFIG_FILE.exists():
        return {}
    try:
        with open(SYNC_CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_sync_config(data: dict) -> None:
    SYNC_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SYNC_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _github_request(
    url: str,
    method: str = "GET",
    token: str = "",
    payload: Optional[dict] = None,
) -> Optional[dict]:
    try:
        data = json.dumps(payload).encode("utf-8") if payload else None
        req = urllib.request.Request(
            url,
            data=data,
            method=method,
            headers={
                "Authorization": f"token {token}",
                "Accept": "application/vnd.github.v3+json",
                "Content-Type": "application/json",
                "User-Agent": "mcpswitch/0.1",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        return {"error": e.code, "message": body}
    except Exception as e:
        return {"error": str(e)}


def setup_sync(github_token: str) -> dict:
    """Create a private Gist and store the token for future syncs."""
    from .profiles import load_profiles

    profiles = load_profiles()
    payload = {
        "description": "MCPSwitch profile sync",
        "public": False,
        "files": {
            GIST_FILENAME: {
                "content": json.dumps({
                    "version": 1,
                    "profiles": profiles,
                    "synced_at": time.time(),
                    "machine": _get_machine_id(),
                }, indent=2)
            }
        }
    }

    result = _github_request(GIST_API, method="POST", token=github_token, payload=payload)

    if not result or "error" in result:
        return {"success": False, "message": f"Failed to create Gist: {result}"}

    gist_id = result.get("id")
    gist_url = result.get("html_url")

    _save_sync_config({
        "github_token": github_token,
        "gist_id": gist_id,
        "gist_url": gist_url,
        "last_push": time.time(),
        "last_pull": None,
    })

    return {
        "success": True,
        "gist_id": gist_id,
        "gist_url": gist_url,
        "message": f"Sync configured. Gist: {gist_url}",
    }


def push_profiles() -> dict:
    """Upload local profiles to the sync Gist."""
    config = _load_sync_config()
    if not config.get("gist_id"):
        return {"success": False, "message": "Sync not configured. Run: mcpswitch sync --setup"}

    from .profiles import load_profiles
    profiles = load_profiles()

    payload = {
        "files": {
            GIST_FILENAME: {
                "content": json.dumps({
                    "version": 1,
                    "profiles": profiles,
                    "synced_at": time.time(),
                    "machine": _get_machine_id(),
                }, indent=2)
            }
        }
    }

    url = f"{GIST_API}/{config['gist_id']}"
    result = _github_request(url, method="PATCH", token=config["github_token"], payload=payload)

    if not result or "error" in result:
        return {"success": False, "message": f"Push failed: {result}"}

    config["last_push"] = time.time()
    _save_sync_config(config)

    return {
        "success": True,
        "profiles_pushed": len(profiles),
        "message": f"Pushed {len(profiles)} profile(s) to Gist.",
    }


def pull_profiles(merge: bool = True) -> dict:
    """Download profiles from the sync Gist.

    If merge=True: remote profiles are merged with local (remote wins on conflict).
    If merge=False: remote profiles completely replace local.
    """
    config = _load_sync_config()
    if not config.get("gist_id"):
        return {"success": False, "message": "Sync not configured. Run: mcpswitch sync --setup"}

    url = f"{GIST_API}/{config['gist_id']}"
    result = _github_request(url, token=config["github_token"])

    if not result or "error" in result:
        return {"success": False, "message": f"Pull failed: {result}"}

    try:
        content = result["files"][GIST_FILENAME]["content"]
        remote_data = json.loads(content)
        remote_profiles = remote_data.get("profiles", {})
    except (KeyError, json.JSONDecodeError) as e:
        return {"success": False, "message": f"Invalid Gist format: {e}"}

    from .profiles import load_profiles, save_profiles
    local_profiles = load_profiles()

    if merge:
        merged = {**local_profiles, **remote_profiles}
    else:
        merged = remote_profiles

    save_profiles(merged)

    config["last_pull"] = time.time()
    _save_sync_config(config)

    new_count = len(set(remote_profiles) - set(local_profiles))
    updated_count = len(set(remote_profiles) & set(local_profiles))

    return {
        "success": True,
        "new_profiles": new_count,
        "updated_profiles": updated_count,
        "total_profiles": len(merged),
        "message": f"Pulled: {new_count} new, {updated_count} updated. Total: {len(merged)} profiles.",
    }


def get_sync_status() -> dict:
    """Return current sync configuration and status."""
    config = _load_sync_config()
    if not config.get("gist_id"):
        return {"configured": False}

    last_push = config.get("last_push")
    last_pull = config.get("last_pull")

    return {
        "configured": True,
        "gist_url": config.get("gist_url"),
        "gist_id": config.get("gist_id"),
        "last_push": last_push,
        "last_push_ago": _ago(last_push),
        "last_pull": last_pull,
        "last_pull_ago": _ago(last_pull),
    }


def _ago(ts: Optional[float]) -> str:
    if not ts:
        return "never"
    diff = time.time() - ts
    if diff < 60:
        return f"{int(diff)}s ago"
    if diff < 3600:
        return f"{int(diff/60)}m ago"
    if diff < 86400:
        return f"{int(diff/3600)}h ago"
    return f"{int(diff/86400)}d ago"


def _get_machine_id() -> str:
    import socket
    import platform
    return f"{socket.gethostname()}-{platform.system()}"
