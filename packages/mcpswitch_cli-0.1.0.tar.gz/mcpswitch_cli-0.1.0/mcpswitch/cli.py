"""MCPSwitch CLI -- smart MCP profile manager for Claude Code."""

import sys
import os
import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

from .config import (
    get_claude_code_config_path,
    get_claude_desktop_config_path,
    get_all_mcp_servers,
    set_mcp_servers,
)
from .profiles import (
    create_profile,
    get_profile,
    delete_profile,
    list_profiles,
    load_profiles,
    get_active_profile,
    set_active_profile,
    add_server_to_profile,
    remove_server_from_profile,
)
from .tokens import (
    estimate_total_tokens,
    format_token_count,
    clear_cache,
    list_cache,
)
from .hooks import install_hooks, uninstall_hooks
from .auto import auto_switch, select_best_profile, CONFIDENCE_THRESHOLD
from .usage import (
    get_server_usage_stats,
    get_waste_report,
    get_usage_summary,
    get_top_tools_by_server,
)
from .tier import require_pro, is_pro, maybe_show_donation_nudge

if sys.platform == "win32":
    os.environ.setdefault("PYTHONUTF8", "1")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

console = Console(highlight=False)
TARGET_CHOICES = ["code", "desktop", "both"]

SOURCE_LABELS = {
    "cache": "[dim]cached[/dim]",
    "known": "[dim]known[/dim]",
    "live":  "[green]live[/green]",
    "fallback": "[yellow]fallback[/yellow]",
}


def _get_config_path(target: str):
    if target == "code":
        return get_claude_code_config_path()
    elif target == "desktop":
        path = get_claude_desktop_config_path()
        if path is None:
            console.print("[red]Claude Desktop config not found on this platform.[/red]")
            sys.exit(1)
        return path
    return None


@click.group()
@click.version_option("0.1.0", prog_name="mcpswitch")
def cli():
    """MCPSwitch -- smart MCP profile manager for Claude Code.

    Save 30-40% of your context window by loading only the MCPs you need.
    Works with any MCP server -- known or unknown.
    """


# ─── STATUS ──────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--target", default="code", type=click.Choice(TARGET_CHOICES))
@click.option("--live", is_flag=True, help="Query each server live for exact token counts")
def status(target, live):
    """Show active profile and current token cost."""
    path = _get_config_path(target)
    servers = get_all_mcp_servers(path)
    active = get_active_profile()

    if not servers:
        console.print(Panel(
            "[yellow]No MCP servers configured.[/yellow]\n"
            "Run [bold]mcpswitch import --name <name>[/bold] to create a profile.",
            title="MCPSwitch Status"
        ))
        return

    if live:
        console.print("[dim]Querying servers live... (this may take a few seconds)[/dim]")

    est = estimate_total_tokens(servers, live=live)
    pct = est["context_pct"]
    color = "green" if pct < 5 else "yellow" if pct < 15 else "red"

    lines = [
        f"Active profile : [bold]{active or '[none]'}[/bold]",
        f"Servers loaded : [bold]{len(servers)}[/bold]",
        f"Token overhead : [bold {color}]{format_token_count(est['total'])}[/bold {color}] "
        f"([{color}]{pct}% of context window[/{color}])",
        f"Config         : [dim]{path}[/dim]",
    ]

    table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
    table.add_column("Server", style="cyan")
    table.add_column("Est. Tokens", justify="right")
    table.add_column("% of Budget", justify="right")
    table.add_column("Source", justify="center")

    for name, info in sorted(est["per_server"].items(), key=lambda x: -x[1]["tokens"]):
        tok = info["tokens"]
        src = info["source"]
        pct_s = round((tok / est["total"]) * 100) if est["total"] > 0 else 0
        table.add_row(name, format_token_count(tok), f"{pct_s}%", SOURCE_LABELS.get(src, src))

    console.print(Panel("\n".join(lines), title="[bold cyan]MCPSwitch Status[/bold cyan]"))
    console.print(table)


# ─── LIST ─────────────────────────────────────────────────────────────────────

@cli.command(name="list")
def list_cmd():
    """List all saved profiles with token estimates."""
    names = list_profiles()
    active = get_active_profile()

    if not names:
        console.print("[yellow]No profiles yet. Run [bold]mcpswitch import --name <name>[/bold] to create one.[/yellow]")
        return

    all_profiles = load_profiles()

    table = Table(title="MCP Profiles", box=box.ROUNDED)
    table.add_column("Profile", style="bold")
    table.add_column("Servers", justify="center")
    table.add_column("Est. Tokens", justify="right")
    table.add_column("Context %", justify="right")
    table.add_column("Active", justify="center")

    for name in names:
        servers = all_profiles[name]
        est = estimate_total_tokens(servers)
        pct = est["context_pct"]
        color = "green" if pct < 5 else "yellow" if pct < 15 else "red"
        is_active = "[bold green]yes[/bold green]" if name == active else ""
        table.add_row(
            name,
            str(len(servers)),
            format_token_count(est["total"]),
            f"[{color}]{pct}%[/{color}]",
            is_active,
        )

    console.print(table)


# ─── USE ──────────────────────────────────────────────────────────────────────

@cli.command()
@click.argument("profile_name")
@click.option("--target", default="both", type=click.Choice(TARGET_CHOICES))
def use(profile_name, target):
    """Switch to a profile -- rewrites your Claude MCP config."""
    servers = get_profile(profile_name)
    if servers is None:
        console.print(f"[red]Profile '{profile_name}' not found.[/red] Run [bold]mcpswitch list[/bold].")
        sys.exit(1)

    targets = []
    if target in ("code", "both"):
        targets.append(get_claude_code_config_path())
    if target in ("desktop", "both"):
        p = get_claude_desktop_config_path()
        if p and p.exists():
            targets.append(p)

    est = estimate_total_tokens(servers)

    for path in targets:
        set_mcp_servers(path, servers)
        console.print(f"[green]Updated[/green] {path}")

    set_active_profile(profile_name)

    pct = est["context_pct"]
    color = "green" if pct < 5 else "yellow" if pct < 15 else "red"
    console.print(
        f"\n[bold green]Switched to '{profile_name}'[/bold green] -- "
        f"[{color}]{format_token_count(est['total'])} tokens ({pct}% of context)[/{color}]"
    )
    console.print("[dim]Restart Claude Code for changes to take effect.[/dim]")


# ─── IMPORT ───────────────────────────────────────────────────────────────────

@cli.command(name="import")
@click.option("--name", required=True, prompt="Profile name")
@click.option("--target", default="code", type=click.Choice(["code", "desktop"]))
def import_cmd(name, target):
    """Import current MCP config as a named profile."""
    path = _get_config_path(target)
    servers = get_all_mcp_servers(path)

    if not servers:
        console.print(f"[yellow]No MCP servers found in {path}[/yellow]")
        return

    create_profile(name, servers)
    est = estimate_total_tokens(servers)
    console.print(
        f"[green]Saved[/green] profile '[bold]{name}[/bold]' "
        f"with {len(servers)} server(s) "
        f"({format_token_count(est['total'])} tokens, {est['context_pct']}% of context)"
    )


# ─── CREATE ───────────────────────────────────────────────────────────────────

@cli.command()
@click.argument("profile_name")
def create(profile_name):
    """Create a new empty profile."""
    create_profile(profile_name, {})
    console.print(f"[green]Created[/green] empty profile '[bold]{profile_name}[/bold]'")
    console.print(f"Add servers: [bold]mcpswitch add {profile_name} <server-name>[/bold]")


# ─── ADD ──────────────────────────────────────────────────────────────────────

@cli.command()
@click.argument("profile_name")
@click.argument("server_name")
@click.option("--from-target", default="code", type=click.Choice(["code", "desktop"]))
def add(profile_name, server_name, from_target):
    """Add a server from your current config into a profile."""
    path = _get_config_path(from_target)
    all_servers = get_all_mcp_servers(path)

    if server_name not in all_servers:
        console.print(f"[red]Server '{server_name}' not found in {path}[/red]")
        avail = ", ".join(all_servers.keys()) or "none"
        console.print(f"Available: {avail}")
        sys.exit(1)

    ok = add_server_to_profile(profile_name, server_name, all_servers[server_name])
    if not ok:
        console.print(f"[red]Profile '{profile_name}' not found.[/red]")
        sys.exit(1)

    console.print(f"[green]Added[/green] '[bold]{server_name}[/bold]' to profile '[bold]{profile_name}[/bold]'")


# ─── REMOVE ───────────────────────────────────────────────────────────────────

@cli.command()
@click.argument("profile_name")
@click.argument("server_name")
def remove(profile_name, server_name):
    """Remove a server from a profile."""
    ok = remove_server_from_profile(profile_name, server_name)
    if not ok:
        console.print("[red]Profile or server not found.[/red]")
        sys.exit(1)
    console.print(f"[green]Removed[/green] '[bold]{server_name}[/bold]' from '[bold]{profile_name}[/bold]'")


# ─── DELETE ───────────────────────────────────────────────────────────────────

@cli.command()
@click.argument("profile_name")
@click.confirmation_option(prompt="Are you sure you want to delete this profile?")
def delete(profile_name):
    """Delete a profile."""
    ok = delete_profile(profile_name)
    if not ok:
        console.print(f"[red]Profile '{profile_name}' not found.[/red]")
        sys.exit(1)
    console.print(f"[green]Deleted[/green] profile '[bold]{profile_name}[/bold]'")


# ─── ANALYZE ──────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--target", default="code", type=click.Choice(["code", "desktop"]))
@click.option("--live", is_flag=True, help="Query each server live for exact token counts")
def analyze(target, live):
    """Analyze current MCP config and show token savings potential."""
    path = _get_config_path(target)
    servers = get_all_mcp_servers(path)

    if not servers:
        console.print(f"[yellow]No MCP servers configured in {path}[/yellow]")
        return

    if live:
        console.print("[dim]Querying servers live... this may take a few seconds per server.[/dim]")

    est = estimate_total_tokens(servers, live=live)
    total = est["total"]
    pct = est["context_pct"]
    color = "green" if pct < 5 else "yellow" if pct < 15 else "red"

    console.print(
        f"\n[bold]Current MCP overhead:[/bold] "
        f"[{color}]{format_token_count(total)} ({pct}% of 200k context window)[/{color}]\n"
    )

    sorted_servers = sorted(est["per_server"].items(), key=lambda x: -x[1]["tokens"])

    table = Table(title="Token Cost by Server", box=box.ROUNDED)
    table.add_column("Server", style="cyan")
    table.add_column("Est. Tokens", justify="right")
    table.add_column("% of Total", justify="right")
    table.add_column("Savings if removed", justify="right", style="green")
    table.add_column("Source", justify="center")

    for name, info in sorted_servers:
        tok = info["tokens"]
        src = info["source"]
        pct_s = round((tok / total) * 100) if total > 0 else 0
        saved = total - tok
        table.add_row(
            name,
            format_token_count(tok),
            f"{pct_s}%",
            format_token_count(saved),
            SOURCE_LABELS.get(src, src),
        )

    console.print(table)

    if sorted_servers:
        top_name, top_info = sorted_servers[0]
        top_tok = top_info["tokens"]
        console.print(
            f"\n[yellow]Tip:[/yellow] '[bold]{top_name}[/bold]' costs "
            f"{format_token_count(top_tok)} tokens. "
            f"Create a lean profile without it:\n"
            f"  [bold]mcpswitch import --name lean[/bold]\n"
            f"  [bold]mcpswitch remove lean {top_name}[/bold]"
        )


# ─── SAVE ─────────────────────────────────────────────────────────────────────

@cli.command(name="save")
@click.argument("profile_name")
@click.option("--target", default="code", type=click.Choice(["code", "desktop"]))
def save_current(profile_name, target):
    """Save current active MCP config as a named profile."""
    path = _get_config_path(target)
    servers = get_all_mcp_servers(path)
    create_profile(profile_name, servers)
    est = estimate_total_tokens(servers)
    console.print(
        f"[green]Saved[/green] '[bold]{profile_name}[/bold]' "
        f"({len(servers)} servers, {format_token_count(est['total'])} tokens)"
    )


# ─── CACHE ────────────────────────────────────────────────────────────────────

@cli.group()
def cache():
    """Manage the token count cache."""


@cache.command(name="list")
def cache_list():
    """Show all cached server token counts."""
    entries = list_cache()
    if not entries:
        console.print("[yellow]Cache is empty. Run [bold]mcpswitch analyze --live[/bold] to populate it.[/yellow]")
        return

    table = Table(title="Token Cache", box=box.ROUNDED)
    table.add_column("Server", style="cyan")
    table.add_column("Tokens", justify="right")
    table.add_column("Tools", justify="right")
    table.add_column("Age (hours)", justify="right")

    for e in entries:
        table.add_row(e["server"], format_token_count(e["tokens"]), str(e["tools"]), str(e["age_hours"]))

    console.print(table)


@cache.command(name="clear")
@click.argument("server_name", required=False)
def cache_clear(server_name):
    """Clear cache for one server, or all servers if no name given."""
    n = clear_cache(server_name)
    if server_name:
        console.print(f"[green]Cleared[/green] cache for '{server_name}' ({n} entries removed)")
    else:
        console.print(f"[green]Cleared[/green] full cache ({n} entries removed)")


# ─── SCAN ─────────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--target", default="code", type=click.Choice(["code", "desktop"]))
def scan(target):
    """Live-query all configured servers and cache their exact token counts."""
    path = _get_config_path(target)
    servers = get_all_mcp_servers(path)

    if not servers:
        console.print(f"[yellow]No MCP servers configured.[/yellow]")
        return

    console.print(f"[bold]Scanning {len(servers)} server(s)...[/bold]\n")

    results = []
    for name, cfg in servers.items():
        console.print(f"  Querying [cyan]{name}[/cyan]...", end=" ")
        from .tokens import get_server_tokens
        tokens, source = get_server_tokens(name, cfg, live=True)
        label = "[green]live[/green]" if source == "live" else "[yellow]fallback[/yellow]"
        console.print(f"{format_token_count(tokens)} ({label})")
        results.append((name, tokens, source))

    total = sum(r[1] for r in results)
    pct = round((total / 200_000) * 100, 1)
    color = "green" if pct < 5 else "yellow" if pct < 15 else "red"

    live_count = sum(1 for r in results if r[2] == "live")
    fallback_count = sum(1 for r in results if r[2] == "fallback")

    console.print(
        f"\n[bold]Total:[/bold] [{color}]{format_token_count(total)} ({pct}% of context)[/{color}]"
    )
    if live_count:
        console.print(f"[dim]{live_count} server(s) queried live and cached. Fallbacks: {fallback_count}.[/dim]")
    else:
        console.print(f"[yellow]All {fallback_count} server(s) unreachable (not running?). Using fallback estimates.[/yellow]")


# ─── SETUP (install hooks) ────────────────────────────────────────────────────

@cli.command()
@click.option("--dry-run", is_flag=True, help="Show what would be changed without writing")
def setup(dry_run):
    """Install MCPSwitch hooks into Claude Code (PostToolUse + PreToolUse)."""
    result = install_hooks(dry_run=dry_run)

    if dry_run:
        console.print("[dim]Dry run — no changes made.[/dim]")

    if result["added"]:
        for hook_type in result["added"]:
            console.print(f"[green]Installed[/green] {hook_type} hook")
        console.print(f"\n[bold]Settings file:[/bold] {result['settings_path']}")
        console.print(
            "\n[bold green]Hooks active.[/bold green] "
            "MCPSwitch will now:\n"
            "  - Log every MCP tool call (usage tracking)\n"
            "  - Warn if a tool's MCP server is not in your active profile\n"
            "\nRestart Claude Code for hooks to take effect."
        )
    if result["already_existed"]:
        console.print(f"[dim]Already installed: {', '.join(result['already_existed'])}[/dim]")


@cli.command()
def uninstall():
    """Remove MCPSwitch hooks from Claude Code settings."""
    result = uninstall_hooks()
    if result["removed"]:
        for hook_type in result["removed"]:
            console.print(f"[green]Removed[/green] {hook_type} hook")
    else:
        console.print("[yellow]No MCPSwitch hooks found.[/yellow]")


# ─── AUTO (context-aware switch) ──────────────────────────────────────────────

@cli.command()
@click.option("--dir", "directory", default=None, help="Project directory to analyze")
@click.option("--dry-run", is_flag=True, help="Show recommendation without switching")
@click.option("--force", is_flag=True, help="Switch even if confidence is low")
@click.option("--silent", is_flag=True, help="No output if already on best profile")
def auto(directory, dry_run, force, silent):
    """Auto-select best profile based on project context and conversation history."""
    if dry_run:
        result = select_best_profile(directory=directory)
        scores = result["scores"]

        console.print(f"\n[bold]Context detected:[/bold]")
        if result["context_servers"]:
            console.print(f"  Project signals  : {', '.join(result['context_servers'])}")
        if result["conversation_servers"]:
            console.print(f"  Conversation     : {', '.join(result['conversation_servers'])}")

        if not result["context_servers"] and not result["conversation_servers"]:
            console.print("  [dim]No signals detected[/dim]")

        console.print(f"\n[bold]Profile scores:[/bold]")
        for name, score in sorted(scores.items(), key=lambda x: -x[1]):
            bar = "[green]" if name == result["recommended"] else "[dim]"
            console.print(f"  {bar}{name:<20} {score:.2f}[/{bar.strip('[]')}]")

        console.print(
            f"\n[bold]Recommendation:[/bold] [cyan]{result['recommended']}[/cyan] "
            f"(confidence: {result['confidence']:.0%})\n"
            f"[dim]{result['reason']}[/dim]"
        )
        return

    result = auto_switch(directory=directory, force=force)

    if result["needs_confirmation"]:
        console.print(
            f"\n[yellow]Low confidence ({result['confidence']:.0%})[/yellow] — "
            f"recommended: [bold]{result['to_profile']}[/bold]\n"
            f"[dim]{result['reason']}[/dim]\n"
        )
        if click.confirm(f"Switch to '{result['to_profile']}'?"):
            result = auto_switch(directory=directory, force=True)
        else:
            console.print("[dim]No change.[/dim]")
            return

    if result["switched"]:
        console.print(
            f"[green]Auto-switched[/green] "
            f"[dim]{result['from_profile'] or 'none'}[/dim] -> "
            f"[bold]{result['to_profile']}[/bold] "
            f"(confidence: {result['confidence']:.0%})\n"
            f"[dim]{result['reason']}[/dim]"
        )
    else:
        if not silent:
            console.print(
                f"[dim]Already on best profile: {result['to_profile']} "
                f"({result['confidence']:.0%} match)[/dim]"
            )


# ─── USAGE (Pro) ──────────────────────────────────────────────────────────────

@cli.command()
@click.option("--days", default=30, help="Number of days to report on")
@click.option("--server", default=None, help="Show top tools for a specific server")
def usage(days, server):
    """Show MCP tool usage stats. [Pro feature]"""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    if server:
        tools = get_top_tools_by_server(server, limit=20)
        if not tools:
            console.print(f"[yellow]No usage data for '{server}' yet.[/yellow]")
            return
        table = Table(title=f"Top Tools — {server}", box=box.ROUNDED)
        table.add_column("Tool", style="cyan")
        table.add_column("Calls", justify="right")
        for t in tools:
            table.add_row(t["tool"].replace(f"mcp__{server}__", ""), str(t["calls"]))
        console.print(table)
        return

    stats = get_server_usage_stats(days=days)
    summary = get_usage_summary(days=days)

    if not stats:
        console.print(
            f"[yellow]No usage data for the last {days} days.[/yellow]\n"
            "Make sure [bold]mcpswitch setup[/bold] was run to install hooks."
        )
        return

    console.print(Panel(
        f"Last {days} days | "
        f"Total calls: [bold]{summary['total_calls']}[/bold] | "
        f"Servers used: [bold]{summary['unique_servers']}[/bold]",
        title="[bold cyan]MCP Usage Summary[/bold cyan]"
    ))

    table = Table(box=box.ROUNDED)
    table.add_column("Server", style="cyan")
    table.add_column("Total Calls", justify="right")
    table.add_column("Sessions Used", justify="right")
    table.add_column("Active Days", justify="right")
    table.add_column("Last Used", justify="right")

    for s in stats:
        last = f"{s['last_used_days_ago']}d ago" if s["last_used_days_ago"] else "never"
        table.add_row(
            s["server"],
            str(s["total_calls"]),
            str(s["sessions_used"]),
            str(s["active_days"]),
            last,
        )
    console.print(table)


# ─── WASTE (Pro) ──────────────────────────────────────────────────────────────

@cli.command()
@click.option("--days", default=30, help="Look back N days")
@click.option("--target", default="code", type=click.Choice(["code", "desktop"]))
@click.option("--fix", is_flag=True, help="Auto-remove wasteful servers from active profile")
def waste(days, target, fix):
    """Find MCP servers loaded but never/rarely used. [Pro feature]"""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    path = _get_config_path(target)
    servers = get_all_mcp_servers(path)

    if not servers:
        console.print("[yellow]No MCP servers configured.[/yellow]")
        return

    waste_list = get_waste_report(list(servers.keys()), days=days)

    if not waste_list:
        console.print(
            f"[green]No waste detected.[/green] All loaded servers were called "
            f"in the last {days} days."
        )
        return

    est_current = estimate_total_tokens(servers)
    waste_tokens = sum(
        estimate_total_tokens({w["server"]: servers[w["server"]]})["total"]
        for w in waste_list
        if w["server"] in servers
    )

    console.print(f"\n[bold yellow]Waste detected:[/bold yellow] {len(waste_list)} server(s)\n")

    table = Table(box=box.ROUNDED)
    table.add_column("Server", style="cyan")
    table.add_column("Calls", justify="right")
    table.add_column("Waste Level", justify="center")
    table.add_column("Est. Tokens Wasted", justify="right", style="red")
    table.add_column("Recommendation")

    for w in waste_list:
        level_color = "red" if w["waste_level"] == "high" else "yellow"
        tok = estimate_total_tokens({w["server"]: servers.get(w["server"], {})})["total"]
        table.add_row(
            w["server"],
            str(w["total_calls"]),
            f"[{level_color}]{w['waste_level']}[/{level_color}]",
            format_token_count(tok),
            w["recommendation"],
        )

    console.print(table)
    console.print(
        f"\n[bold]Total tokens wasted per session:[/bold] "
        f"[red]{format_token_count(waste_tokens)}[/red] "
        f"({round(waste_tokens/est_current['total']*100)}% of your current overhead)"
    )

    if fix:
        active = get_active_profile()
        if not active:
            console.print("[yellow]No active profile. Use --fix with an active profile.[/yellow]")
            return
        removed = 0
        for w in waste_list:
            from .profiles import remove_server_from_profile
            ok = remove_server_from_profile(active, w["server"])
            if ok:
                console.print(f"[green]Removed[/green] '{w['server']}' from profile '{active}'")
                removed += 1
        if removed:
            console.print(f"\n[bold green]Fixed.[/bold green] Run [bold]mcpswitch use {active}[/bold] to apply.")
    else:
        console.print(
            f"\nTo fix: [bold]mcpswitch waste --fix[/bold]  (removes waste from active profile)"
        )


# ─── ACTIVATE (license) ───────────────────────────────────────────────────────

@cli.command()
@click.argument("license_key")
def activate(license_key):
    """Activate a Pro or Team license key."""
    from .tier import activate_license, get_tier
    result = activate_license(license_key)
    if result["success"]:
        console.print(f"[bold green]{result['message']}[/bold green]")
        console.print(f"Tier: [bold]{get_tier().upper()}[/bold]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@cli.command()
def tier():
    """Show current license tier."""
    from .tier import get_tier, _load_license
    from .billing import TEAM_PAYMENT_URL
    t   = get_tier()
    lic = _load_license()
    colors = {"free": "dim", "pro": "green", "team": "bold cyan"}
    color  = colors.get(t, "dim")
    console.print(f"Current tier: [{color}]{t.upper()}[/{color}]")
    if t == "team":
        seats = lic.get("seats", 1)
        console.print(f"Seats: [bold]{seats}[/bold]")
    if t == "free":
        console.print(
            f"Upgrade to Team for shared profiles & Slack alerts:\n"
            f"  [bold]mcpswitch upgrade[/bold]\n"
            f"  [cyan]{TEAM_PAYMENT_URL}[/cyan]"
        )


# ─── DONATE ──────────────────────────────────────────────────────────────────

@cli.command()
def donate():
    """Support MCPSwitch with a one-time tip (always optional)."""
    import webbrowser
    donate_url = "https://ko-fi.com/mcpswitch"
    webbrowser.open(donate_url)
    console.print(
        Panel(
            "[bold]Thanks for considering a tip![/bold]\n\n"
            "MCPSwitch is free and open-source. Every contribution helps\n"
            "keep development active.\n\n"
            f"[cyan]{donate_url}[/cyan]\n\n"
            "[dim]You can always close the browser — no pressure.[/dim]",
            title="Support MCPSwitch",
            border_style="yellow",
        )
    )
    from .tier import record_nudge_shown
    record_nudge_shown()   # reset the nudge timer after they've seen the page


# ─── UPGRADE ─────────────────────────────────────────────────────────────────

@cli.command()
def upgrade():
    """Open the Team tier checkout page in your browser."""
    from .billing import open_checkout, TEAM_PAYMENT_URL
    from .tier import is_team
    if is_team():
        console.print("[bold green]You already have the Team tier active.[/bold green]")
        return
    url = open_checkout()
    console.print(
        Panel(
            f"[bold]Opening Lemon Squeezy checkout...[/bold]\n\n"
            f"After payment you will receive a license key by email.\n"
            f"Activate it with:\n\n"
            f"  [bold cyan]mcpswitch activate <your-key>[/bold cyan]\n\n"
            f"If the browser didn't open, visit:\n[cyan]{url}[/cyan]",
            title="MCPSwitch Team",
            border_style="cyan",
        )
    )


# ─── DIGEST (Pro) ─────────────────────────────────────────────────────────────

@cli.group()
def digest():
    """Weekly token savings digest via email. [Pro feature]"""


@digest.command(name="setup")
@click.argument("email")
@click.option("--api-key", required=True, prompt="Resend API key", help="Resend.com API key")
def digest_setup(email, api_key):
    """Configure weekly digest email (requires Resend API key)."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .email import setup_digest
    result = setup_digest(email, api_key)
    console.print(f"[green]Digest configured.[/green] Reports will be sent to [bold]{result['email']}[/bold]")
    console.print("Send now: [bold]mcpswitch digest --send[/bold]")


@digest.command(name="send")
@click.option("--force", is_flag=True, help="Send even if already sent this week")
def digest_send(force):
    """Send the weekly digest email now."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .email import send_digest
    result = send_digest(force=force)

    if result.get("skipped"):
        console.print(f"[yellow]{result['message']}[/yellow]")
        return

    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@digest.command(name="preview")
def digest_preview():
    """Preview this week's digest without sending."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .email import preview_digest
    console.print(preview_digest())


@digest.command(name="status")
def digest_status():
    """Show digest configuration and last send time."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .email import get_digest_config
    import time
    config = get_digest_config()
    if not config:
        console.print("[yellow]Digest not configured. Run: mcpswitch digest setup <email> --api-key <key>[/yellow]")
        return

    last = config.get("last_sent")
    last_str = f"{round((time.time() - last) / 86400, 1)}d ago" if last else "never"
    console.print(f"Email   : [bold]{config.get('email', 'not set')}[/bold]")
    console.print(f"API key : [dim]{'configured' if config.get('resend_api_key') else 'missing'}[/dim]")
    console.print(f"Last sent: {last_str}")


# ─── COMMUNITY (Pro) ──────────────────────────────────────────────────────────

@cli.group()
def community():
    """Browse and install community MCP profile stacks. [Pro feature]"""


@community.command(name="list")
@click.option("--tag", default=None, help="Filter by tag (e.g. python, react, devops)")
def community_list(tag):
    """Browse available community profiles."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .community import list_community_profiles
    profiles = list_community_profiles(tag=tag)

    if not profiles:
        console.print(f"[yellow]No profiles found{' for tag: ' + tag if tag else ''}.[/yellow]")
        return

    table = Table(
        title=f"Community Profiles{' [tag: ' + tag + ']' if tag else ''}",
        box=box.ROUNDED
    )
    table.add_column("Name", style="bold cyan")
    table.add_column("Description")
    table.add_column("Tags", style="dim")
    table.add_column("Servers", justify="center")
    table.add_column("Stars", justify="right")
    table.add_column("Author", style="dim")

    for p in profiles:
        table.add_row(
            p["name"],
            p.get("description", ""),
            ", ".join(p.get("tags", [])),
            str(len(p.get("servers", []))),
            str(p.get("stars", 0)),
            p.get("author", ""),
        )

    console.print(table)
    console.print("\nInstall: [bold]mcpswitch community install <name>[/bold]")


@community.command(name="info")
@click.argument("profile_name")
def community_info(profile_name):
    """Show details about a community profile."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .community import get_profile_detail
    detail = get_profile_detail(profile_name)
    if not detail:
        console.print(f"[red]Profile '{profile_name}' not found.[/red]")
        sys.exit(1)

    console.print(Panel(
        f"[bold]{detail['name']}[/bold]\n"
        f"{detail.get('description', '')}\n\n"
        f"Author : {detail.get('author', 'unknown')}\n"
        f"Tags   : {', '.join(detail.get('tags', []))}\n"
        f"Servers: {', '.join(detail.get('servers', []))}",
        title="Community Profile"
    ))


@community.command(name="install")
@click.argument("profile_name")
def community_install(profile_name):
    """Install a community profile locally."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .community import install_community_profile
    result = install_community_profile(profile_name)
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
        console.print(f"Servers: {', '.join(result['servers'])}")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@community.command(name="search")
@click.argument("query")
def community_search(query):
    """Search community profiles by name, description, or tag."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .community import search_profiles
    results = search_profiles(query)
    if not results:
        console.print(f"[yellow]No profiles matching '{query}'.[/yellow]")
        return

    for p in results:
        console.print(
            f"[bold cyan]{p['name']}[/bold cyan] — {p.get('description', '')} "
            f"[dim]({', '.join(p.get('tags', []))})[/dim]"
        )


@community.command(name="publish")
@click.argument("profile_name")
@click.option("--author", default="", help="Your name or GitHub handle")
def community_publish(profile_name, author):
    """Get the URL to submit your profile to the community registry."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .community import publish_profile_url
    url = publish_profile_url(profile_name, author)
    console.print(f"Open this URL to submit your profile:\n[cyan]{url}[/cyan]")


# ─── SYNC (Pro) ───────────────────────────────────────────────────────────────

@cli.group()
def sync():
    """Multi-machine profile sync via GitHub Gists. [Pro feature]"""


@sync.command(name="setup")
@click.argument("github_token")
def sync_setup(github_token):
    """Create a private Gist and configure sync."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .sync import setup_sync
    result = setup_sync(github_token)
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
        console.print(f"Gist ID : [dim]{result['gist_id']}[/dim]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@sync.command(name="push")
def sync_push():
    """Push local profiles to GitHub Gist."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .sync import push_profiles
    result = push_profiles()
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@sync.command(name="pull")
@click.option("--no-merge", is_flag=True, help="Replace local profiles instead of merging")
def sync_pull(no_merge):
    """Pull profiles from GitHub Gist."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .sync import pull_profiles
    result = pull_profiles(merge=not no_merge)
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
        console.print(
            f"New: {result['new_profiles']} | "
            f"Updated: {result['updated_profiles']} | "
            f"Total: {result['total_profiles']}"
        )
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@sync.command(name="status")
def sync_status():
    """Show sync configuration and last push/pull times."""
    from .tier import maybe_show_donation_nudge
    maybe_show_donation_nudge(console)

    from .sync import get_sync_status
    s = get_sync_status()
    if not s.get("configured"):
        console.print("[yellow]Sync not configured. Run: mcpswitch sync setup <github-token>[/yellow]")
        return

    console.print(f"Gist    : [cyan]{s.get('gist_url', s.get('gist_id'))}[/cyan]")
    console.print(f"Last push: {s.get('last_push_ago', 'never')}")
    console.print(f"Last pull: {s.get('last_pull_ago', 'never')}")


# ─── TEAM (Team tier) ─────────────────────────────────────────────────────────

@cli.group()
def team():
    """Team shared profiles, analytics, and Slack alerts. [Team feature]"""


def _require_team():
    from .tier import is_team
    from .billing import TEAM_PAYMENT_URL
    if not is_team():
        console.print(
            "\n[bold yellow]Team features require the Team tier.[/bold yellow]\n\n"
            "Upgrade to Team to unlock:\n"
            "  - Shared team profiles via GitHub Gist\n"
            "  - Slack alerts for context overload and waste\n"
            "  - Team-wide analytics and monthly reports\n\n"
            "Run [bold cyan]mcpswitch upgrade[/bold cyan] to get started.\n"
            f"Or visit: [cyan]{TEAM_PAYMENT_URL}[/cyan]\n"
            "Then activate: [bold]mcpswitch activate <your-key>[/bold]\n"
        )
        return False
    return True


@team.command(name="create-gist")
@click.argument("github_token")
def team_create_gist(github_token):
    """Create a new shared team Gist (admin action)."""
    if not _require_team():
        return

    from .team import create_team_gist
    result = create_team_gist(github_token)
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@team.command(name="setup")
@click.argument("gist_id")
@click.argument("github_token")
def team_setup(gist_id, github_token):
    """Connect this machine to an existing team Gist."""
    if not _require_team():
        return

    from .team import setup_team
    result = setup_team(gist_id, github_token)
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@team.command(name="sync")
@click.option("--push/--no-push", default=True, help="Push local profiles to team Gist")
@click.option("--pull/--no-pull", default=True, help="Pull team profiles locally")
def team_sync(push, pull):
    """Sync profiles with the team Gist (bidirectional by default)."""
    if not _require_team():
        return

    from .team import sync_team_profiles
    result = sync_team_profiles(push=push, pull=pull)
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
        console.print(
            f"Pushed: {result['pushed']} | "
            f"Pulled: {result['pulled']} | "
            f"Team members: {result['team_members']} | "
            f"Total profiles: {result['total_profiles']}"
        )
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@team.command(name="status")
def team_status():
    """Show team sync status and member activity."""
    if not _require_team():
        return

    from .team import get_team_status
    import time
    s = get_team_status()
    if not s.get("configured"):
        console.print("[yellow]Team not configured. Run: mcpswitch team setup <gist-id> <token>[/yellow]")
        return

    console.print(f"Gist  : [cyan]{s.get('gist_url', s.get('gist_id'))}[/cyan]")
    console.print(f"Role  : {'[bold]Admin[/bold]' if s.get('is_admin') else 'Member'}")
    last = s.get("last_sync")
    last_str = f"{round((time.time() - last) / 60)}m ago" if last else "never"
    console.print(f"Last sync: {last_str}")

    members = s.get("members", [])
    if members:
        table = Table(title="Team Members", box=box.SIMPLE)
        table.add_column("Machine", style="cyan")
        table.add_column("Profiles", justify="right")
        table.add_column("Last Seen")
        table.add_column("Status", justify="center")
        for m in members:
            last_seen = m.get("last_seen")
            ago = f"{round((time.time() - last_seen) / 3600)}h ago" if last_seen else "never"
            status = "[green]active[/green]" if m.get("active") else "[dim]idle[/dim]"
            table.add_row(m["machine"], str(m.get("profiles", 0)), ago, status)
        console.print(table)


@team.command(name="report")
@click.option("--days", default=30)
def team_report(days):
    """Show team-wide analytics (aggregated from all members)."""
    if not _require_team():
        return

    from .team import get_full_team_analytics, get_team_report
    data = get_full_team_analytics()
    if not data.get("success"):
        console.print(f"[yellow]Using local stats only: {data.get('message', '')}[/yellow]")
        data = get_team_report(days=days)
        data["member_count"] = 1
        data["top_servers_across_team"] = data.get("top_servers", [])

    console.print(Panel(
        f"Members: [bold]{data.get('member_count', 1)}[/bold] | "
        f"Total calls: [bold]{data.get('total_calls', 0):,}[/bold] | "
        f"Waste alerts: [bold]{data.get('waste_count', 0)}[/bold]",
        title="[bold cyan]Team Analytics (30d)[/bold cyan]"
    ))

    top = data.get("top_servers_across_team", [])
    if top:
        table = Table(title="Top Servers (Team-wide)", box=box.ROUNDED)
        table.add_column("Server", style="cyan")
        table.add_column("Total Calls", justify="right")
        for s in top[:10]:
            table.add_row(s["server"], str(s["calls"]))
        console.print(table)

    waste = data.get("waste_servers", [])
    if waste:
        console.print(f"\n[yellow]{len(waste)} waste alert(s):[/yellow]")
        for w in waste[:5]:
            console.print(f"  [red]{w['server']}[/red] — {w.get('waste_level', '?')} ({w.get('total_calls', 0)} calls)")
        console.print("Fix: [bold]mcpswitch waste --fix[/bold]")


@team.command(name="push-analytics")
def team_push_analytics():
    """Upload this machine's usage stats to the team Gist."""
    if not _require_team():
        return

    from .team import push_analytics_to_gist
    result = push_analytics_to_gist()
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@team.group()
def slack():
    """Slack alert configuration."""


@slack.command(name="setup")
@click.argument("webhook_url")
@click.option("--threshold", default=80.0, help="Context % that triggers an alert (default: 80)")
def slack_setup(webhook_url, threshold):
    """Configure Slack webhook for waste and context alerts."""
    if not _require_team():
        return

    from .team import setup_slack
    result = setup_slack(webhook_url, threshold_pct=threshold)
    console.print(f"[green]{result['message']}[/green]")
    console.print("Test it: [bold]mcpswitch team slack test[/bold]")


@slack.command(name="test")
def slack_test():
    """Send a test message to verify the Slack webhook."""
    if not _require_team():
        return

    from .team import send_slack_test
    result = send_slack_test()
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@slack.command(name="alert")
@click.option("--force", is_flag=True, help="Send even if below threshold")
def slack_alert(force):
    """Check context usage and send Slack alert if over threshold."""
    if not _require_team():
        return

    from .team import check_and_alert
    result = check_and_alert(force=force)
    if result.get("alerted"):
        console.print(f"[green]{result['message']}[/green] (context: {result.get('context_pct', 0):.1f}%)")
    elif result.get("success"):
        console.print(f"[dim]{result['message']}[/dim]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


@slack.command(name="send-report")
def slack_send_report():
    """Post the monthly team analytics report to Slack."""
    if not _require_team():
        return

    from .team import send_monthly_report_to_slack
    result = send_monthly_report_to_slack()
    if result["success"]:
        console.print(f"[green]{result['message']}[/green]")
    else:
        console.print(f"[red]{result['message']}[/red]")
        sys.exit(1)


def main():
    cli()


if __name__ == "__main__":
    main()
