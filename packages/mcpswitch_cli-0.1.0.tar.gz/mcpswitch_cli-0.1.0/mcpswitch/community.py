"""Community profiles — discover and install curated MCP stacks.

Backend: GitHub repo (mcpswitch/community-profiles) — no server needed.
Anyone can submit a profile via PR. MCPSwitch fetches the index from GitHub.

Pro feature:
  mcpswitch community list               → browse available stacks
  mcpswitch community install react       → install a community profile locally
  mcpswitch community publish my-stack   → submit your profile (opens GitHub PR)
  mcpswitch community info react          → show details about a profile
"""

import json
import urllib.request
import urllib.error
from typing import Optional

# GitHub repo that hosts community profiles
COMMUNITY_REPO   = "mcpswitch-dev/community-profiles"
COMMUNITY_BRANCH = "main"
INDEX_URL = (
    f"https://raw.githubusercontent.com/{COMMUNITY_REPO}/"
    f"{COMMUNITY_BRANCH}/index.json"
)
PROFILE_BASE_URL = (
    f"https://raw.githubusercontent.com/{COMMUNITY_REPO}/"
    f"{COMMUNITY_BRANCH}/profiles"
)

# Fallback built-in profiles (used when GitHub is unreachable)
BUILTIN_PROFILES = {
    "react-fullstack": {
        "name": "react-fullstack",
        "description": "React + TypeScript + Postgres + GitHub",
        "author": "mcpswitch",
        "stars": 0,
        "tags": ["react", "typescript", "postgres", "frontend"],
        "servers": ["github", "playwright", "postgres", "context7"],
        "builtin": True,
    },
    "python-api": {
        "name": "python-api",
        "description": "FastAPI + Postgres + GitHub — Python backend development",
        "author": "mcpswitch",
        "stars": 0,
        "tags": ["python", "fastapi", "postgres", "backend"],
        "servers": ["github", "postgres", "context7", "sequential-thinking"],
        "builtin": True,
    },
    "go-backend": {
        "name": "go-backend",
        "description": "Go API development — GitHub + context7 only",
        "author": "mcpswitch",
        "stars": 0,
        "tags": ["go", "golang", "backend", "api"],
        "servers": ["github", "context7"],
        "builtin": True,
    },
    "writing-docs": {
        "name": "writing-docs",
        "description": "Documentation and writing — filesystem + fetch, no code tools",
        "author": "mcpswitch",
        "stars": 0,
        "tags": ["writing", "docs", "markdown"],
        "servers": ["filesystem", "fetch"],
        "builtin": True,
    },
    "data-analysis": {
        "name": "data-analysis",
        "description": "Data analysis — SQLite + Postgres + sequential thinking",
        "author": "mcpswitch",
        "stars": 0,
        "tags": ["data", "sql", "analysis", "sqlite"],
        "servers": ["sqlite", "postgres", "sequential-thinking", "filesystem"],
        "builtin": True,
    },
    "scraping": {
        "name": "scraping",
        "description": "Web scraping and automation — Playwright + Brave Search",
        "author": "mcpswitch",
        "stars": 0,
        "tags": ["scraping", "automation", "browser", "playwright"],
        "servers": ["playwright", "brave-search", "fetch"],
        "builtin": True,
    },
    "devops": {
        "name": "devops",
        "description": "DevOps and infra — GitHub + filesystem + fetch",
        "author": "mcpswitch",
        "stars": 0,
        "tags": ["devops", "ci", "github-actions", "infra"],
        "servers": ["github", "filesystem", "fetch"],
        "builtin": True,
    },
    "minimal": {
        "name": "minimal",
        "description": "Absolute minimum — sequential thinking only. Max context space.",
        "author": "mcpswitch",
        "stars": 0,
        "tags": ["minimal", "lean", "context"],
        "servers": ["sequential-thinking"],
        "builtin": True,
    },
}


def _fetch_url(url: str, timeout: int = 5) -> Optional[dict]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "mcpswitch/0.1"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except Exception:
        return None


def list_community_profiles(tag: Optional[str] = None) -> list[dict]:
    """Fetch community profile index. Falls back to built-ins if offline."""
    remote = _fetch_url(INDEX_URL)

    if remote and isinstance(remote, list):
        profiles = remote
    else:
        profiles = list(BUILTIN_PROFILES.values())

    if tag:
        profiles = [p for p in profiles if tag.lower() in [t.lower() for t in p.get("tags", [])]]

    return sorted(profiles, key=lambda p: p.get("stars", 0), reverse=True)


def get_profile_detail(name: str) -> Optional[dict]:
    """Fetch full profile detail including exact server configs."""
    # Try built-in first
    if name in BUILTIN_PROFILES:
        profile = dict(BUILTIN_PROFILES[name])
        # Convert server list to minimal configs (user still needs real configs)
        profile["server_configs"] = {
            srv: {"command": "npx", "args": [f"@modelcontextprotocol/server-{srv}"]}
            for srv in profile.get("servers", [])
        }
        return profile

    # Try remote
    url = f"{PROFILE_BASE_URL}/{name}.json"
    return _fetch_url(url)


def install_community_profile(name: str) -> dict:
    """Install a community profile locally.

    For built-in profiles: creates the profile with server name stubs.
    User configures actual server commands afterward.

    Returns {"success": bool, "profile_name": str, "servers": [...], "message": str}
    """
    from .profiles import create_profile

    detail = get_profile_detail(name)
    if not detail:
        return {"success": False, "profile_name": name,
                "servers": [], "message": f"Profile '{name}' not found."}

    # Build server config stubs from server list
    server_configs = detail.get("server_configs", {})
    if not server_configs and "servers" in detail:
        server_configs = {
            srv: {"command": "npx", "args": [f"@modelcontextprotocol/server-{srv}"]}
            for srv in detail["servers"]
        }

    create_profile(name, server_configs)

    return {
        "success": True,
        "profile_name": name,
        "servers": list(server_configs.keys()),
        "description": detail.get("description", ""),
        "message": (
            f"Installed '{name}' with {len(server_configs)} server stub(s).\n"
            f"Edit server commands: mcpswitch edit {name}"
        ),
    }


def publish_profile_url(profile_name: str, author: str = "") -> str:
    """Return the GitHub URL to submit a community profile PR."""
    import urllib.parse
    title = urllib.parse.quote(f"Add community profile: {profile_name}")
    body = urllib.parse.quote(
        f"**Profile name:** {profile_name}\n"
        f"**Author:** {author or 'anonymous'}\n\n"
        f"<!-- Add your profile JSON below -->\n"
    )
    return (
        f"https://github.com/{COMMUNITY_REPO}/issues/new"
        f"?title={title}&body={body}&labels=new-profile"
    )


def search_profiles(query: str) -> list[dict]:
    """Search profiles by name, description, or tags."""
    q = query.lower()
    all_profiles = list_community_profiles()
    return [
        p for p in all_profiles
        if q in p.get("name", "").lower()
        or q in p.get("description", "").lower()
        or any(q in t.lower() for t in p.get("tags", []))
    ]
