"""Team tier features — shared profiles, Slack alerts, team analytics.

Team tier ($49/month):
  mcpswitch team --setup <gist-id> <github-token>  → connect to shared team Gist
  mcpswitch team --sync                             → sync team profiles
  mcpswitch team --report                           → show team analytics
  mcpswitch team slack --setup <webhook-url>        → configure Slack alerts
  mcpswitch team slack --test                       → send test alert
  mcpswitch team slack --send-report                → send monthly report to Slack

Team Gist format:
  The team admin creates a shared (private) Gist.
  Everyone on the team adds the same Gist ID to their config.
  Profiles in the Gist are available to all team members.
"""

import json
import socket
import platform
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional

TEAM_CONFIG_FILE = Path.home() / ".mcpswitch" / "team.json"
GIST_API = "https://api.github.com/gists"
TEAM_GIST_FILENAME = "mcpswitch-team-profiles.json"
TEAM_ANALYTICS_FILENAME = "mcpswitch-team-analytics.json"


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _load_config() -> dict:
    if not TEAM_CONFIG_FILE.exists():
        return {}
    try:
        with open(TEAM_CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_config(data: dict) -> None:
    TEAM_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TEAM_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _machine_id() -> str:
    return f"{socket.gethostname()}-{platform.system()}"


# ---------------------------------------------------------------------------
# GitHub Gist helpers
# ---------------------------------------------------------------------------

def _gist_request(
    url: str,
    method: str = "GET",
    token: str = "",
    payload: Optional[dict] = None,
) -> Optional[dict]:
    try:
        data = json.dumps(payload).encode("utf-8") if payload else None
        req = urllib.request.Request(
            url,
            data=data,
            method=method,
            headers={
                "Authorization": f"token {token}",
                "Accept": "application/vnd.github.v3+json",
                "Content-Type": "application/json",
                "User-Agent": "mcpswitch/0.1",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        return {"error": e.code, "message": body}
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Team setup
# ---------------------------------------------------------------------------

def setup_team(gist_id: str, github_token: str) -> dict:
    """Connect this machine to a shared team Gist.

    The team admin should:
    1. Create a private Gist manually (or via mcpswitch team --create-gist)
    2. Share the Gist ID and a read token with team members
    3. Each member runs: mcpswitch team --setup <gist_id> <token>
    """
    # Verify we can read the Gist
    url = f"{GIST_API}/{gist_id}"
    result = _gist_request(url, token=github_token)

    if not result or "error" in result:
        return {"success": False, "message": f"Cannot access Gist {gist_id}: {result}"}

    gist_url = result.get("html_url", "")

    _save_config({
        "gist_id": gist_id,
        "gist_url": gist_url,
        "github_token": github_token,
        "machine": _machine_id(),
        "setup_at": time.time(),
        "last_sync": None,
    })

    return {
        "success": True,
        "gist_id": gist_id,
        "gist_url": gist_url,
        "message": f"Team sync configured. Gist: {gist_url}",
    }


def create_team_gist(github_token: str) -> dict:
    """Create a new shared team Gist (admin action)."""
    from .profiles import load_profiles

    profiles = load_profiles()
    initial_data = {
        "version": 1,
        "profiles": profiles,
        "members": {_machine_id(): {"last_seen": time.time(), "profiles_contributed": len(profiles)}},
        "created_at": time.time(),
    }

    payload = {
        "description": "MCPSwitch Team Profiles",
        "public": False,
        "files": {
            TEAM_GIST_FILENAME: {"content": json.dumps(initial_data, indent=2)},
            TEAM_ANALYTICS_FILENAME: {"content": json.dumps({
                "version": 1,
                "member_stats": {},
                "updated_at": time.time(),
            }, indent=2)},
        },
    }

    result = _gist_request(GIST_API, method="POST", token=github_token, payload=payload)
    if not result or "error" in result:
        return {"success": False, "message": f"Failed to create team Gist: {result}"}

    gist_id = result["id"]
    gist_url = result.get("html_url", "")

    _save_config({
        "gist_id": gist_id,
        "gist_url": gist_url,
        "github_token": github_token,
        "machine": _machine_id(),
        "setup_at": time.time(),
        "last_sync": None,
        "is_admin": True,
    })

    return {
        "success": True,
        "gist_id": gist_id,
        "gist_url": gist_url,
        "message": (
            f"Team Gist created.\n"
            f"Share this with your team:\n"
            f"  Gist ID: {gist_id}\n"
            f"  Setup command: mcpswitch team --setup {gist_id} <token>"
        ),
    }


# ---------------------------------------------------------------------------
# Profile sync
# ---------------------------------------------------------------------------

def sync_team_profiles(push: bool = True, pull: bool = True) -> dict:
    """Bidirectional sync: push local profiles + pull remote profiles.

    push=True: upload local profiles to the shared Gist
    pull=True: download team profiles to local (local profiles are not overwritten
               unless remote has a newer version of the same name)
    """
    config = _load_config()
    if not config.get("gist_id"):
        return {"success": False, "message": "Team not configured. Run: mcpswitch team --setup"}

    from .profiles import load_profiles, save_profiles

    gist_url = f"{GIST_API}/{config['gist_id']}"
    token = config["github_token"]
    machine = _machine_id()

    # 1. Read current Gist state
    remote = _gist_request(gist_url, token=token)
    if not remote or "error" in remote:
        return {"success": False, "message": f"Cannot read team Gist: {remote}"}

    try:
        gist_content = remote["files"][TEAM_GIST_FILENAME]["content"]
        remote_data = json.loads(gist_content)
    except (KeyError, json.JSONDecodeError) as e:
        # First push — Gist file may not exist yet
        remote_data = {"version": 1, "profiles": {}, "members": {}}

    remote_profiles = remote_data.get("profiles", {})
    members = remote_data.get("members", {})

    local_profiles = load_profiles()
    result_info = {"pushed": 0, "pulled": 0, "conflicts": []}

    # 2. Push: merge local into remote (local overrides on conflict)
    if push:
        merged_remote = {**remote_profiles, **local_profiles}
        result_info["pushed"] = len(local_profiles)
    else:
        merged_remote = remote_profiles

    # 3. Pull: add remote profiles that don't exist locally
    if pull:
        new_to_local = {k: v for k, v in remote_profiles.items() if k not in local_profiles}
        updated_local = {**local_profiles, **new_to_local}
        result_info["pulled"] = len(new_to_local)
        save_profiles(updated_local)

    # 4. Update member presence in Gist
    members[machine] = {
        "last_seen": time.time(),
        "profiles_contributed": len(local_profiles),
    }

    # 5. Write merged profiles + updated members back to Gist
    new_gist_data = {
        "version": 1,
        "profiles": merged_remote,
        "members": members,
        "updated_at": time.time(),
    }

    patch_result = _gist_request(
        gist_url, method="PATCH", token=token,
        payload={"files": {TEAM_GIST_FILENAME: {"content": json.dumps(new_gist_data, indent=2)}}}
    )

    if not patch_result or "error" in patch_result:
        return {"success": False, "message": f"Gist write failed: {patch_result}"}

    config["last_sync"] = time.time()
    _save_config(config)

    return {
        "success": True,
        "pushed": result_info["pushed"],
        "pulled": result_info["pulled"],
        "team_members": len(members),
        "total_profiles": len(merged_remote),
        "message": (
            f"Synced: pushed {result_info['pushed']}, pulled {result_info['pulled']} profiles. "
            f"{len(members)} team member(s) active."
        ),
    }


def get_team_status() -> dict:
    """Return team sync configuration and member list."""
    config = _load_config()
    if not config.get("gist_id"):
        return {"configured": False}

    gist_url_api = f"{GIST_API}/{config['gist_id']}"
    remote = _gist_request(gist_url_api, token=config["github_token"])
    if not remote or "error" in remote:
        return {
            "configured": True,
            "gist_id": config["gist_id"],
            "gist_url": config.get("gist_url"),
            "last_sync": config.get("last_sync"),
            "members": [],
            "error": "Cannot reach team Gist",
        }

    try:
        gist_content = remote["files"][TEAM_GIST_FILENAME]["content"]
        data = json.loads(gist_content)
        members = data.get("members", {})
    except Exception:
        members = {}

    return {
        "configured": True,
        "gist_id": config["gist_id"],
        "gist_url": config.get("gist_url"),
        "last_sync": config.get("last_sync"),
        "machine": _machine_id(),
        "is_admin": config.get("is_admin", False),
        "total_profiles": len(data.get("profiles", {})) if "data" in dir() else 0,
        "members": [
            {
                "machine": k,
                "last_seen": v.get("last_seen"),
                "profiles": v.get("profiles_contributed", 0),
                "active": (time.time() - v.get("last_seen", 0)) < 86400 * 7,
            }
            for k, v in members.items()
        ],
    }


# ---------------------------------------------------------------------------
# Slack alerts
# ---------------------------------------------------------------------------

def setup_slack(webhook_url: str, threshold_pct: float = 80.0) -> dict:
    """Store Slack webhook for waste/context alerts."""
    config = _load_config()
    config["slack_webhook"] = webhook_url
    config["slack_threshold_pct"] = threshold_pct
    _save_config(config)
    return {"success": True, "message": f"Slack webhook saved. Alert threshold: {threshold_pct}% context usage."}


def _post_slack(webhook_url: str, payload: dict) -> bool:
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            webhook_url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status == 200
    except Exception:
        return False


def send_slack_test(webhook_url: Optional[str] = None) -> dict:
    """Send a test message to Slack to verify the webhook works."""
    config = _load_config()
    url = webhook_url or config.get("slack_webhook")
    if not url:
        return {"success": False, "message": "No Slack webhook configured."}

    ok = _post_slack(url, {
        "text": ":white_check_mark: MCPSwitch team alert test — webhook is working.",
        "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "*MCPSwitch* | Test alert\n:white_check_mark: Webhook configured correctly.",
                },
            }
        ],
    })
    return {"success": ok, "message": "Test sent." if ok else "Slack delivery failed."}


def check_and_alert(force: bool = False) -> dict:
    """Check current context usage and send Slack alert if over threshold."""
    config = _load_config()
    if not config.get("slack_webhook"):
        return {"success": False, "message": "No Slack webhook configured."}

    from .config import get_claude_code_config_path, get_all_mcp_servers
    from .tokens import estimate_total_tokens

    servers = get_all_mcp_servers(get_claude_code_config_path())
    if not servers:
        return {"success": True, "alerted": False, "message": "No MCP servers configured."}

    est = estimate_total_tokens(servers)
    ctx_pct = est.get("context_pct", 0)
    threshold = config.get("slack_threshold_pct", 80.0)

    if ctx_pct < threshold and not force:
        return {"success": True, "alerted": False,
                "message": f"Context at {ctx_pct:.1f}% — below threshold ({threshold}%)."}

    token = est.get("total", 0)
    blocks = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": ":warning: MCPSwitch Context Alert"},
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Context used:*\n{ctx_pct:.1f}% ({token:,} tokens)"},
                {"type": "mrkdwn", "text": f"*Servers loaded:*\n{len(servers)}"},
                {"type": "mrkdwn", "text": f"*Threshold:*\n{threshold:.0f}%"},
                {"type": "mrkdwn", "text": f"*Machine:*\n{_machine_id()}"},
            ],
        },
        {
            "type": "section",
            "text": {"type": "mrkdwn",
                     "text": "Run `mcpswitch waste --fix` or switch to a lighter profile."},
        },
    ]

    ok = _post_slack(config["slack_webhook"], {"blocks": blocks})
    return {"success": ok, "alerted": True, "context_pct": ctx_pct,
            "message": "Alert sent." if ok else "Slack delivery failed."}


# ---------------------------------------------------------------------------
# Team analytics
# ---------------------------------------------------------------------------

def get_team_report(days: int = 30) -> dict:
    """Aggregate local usage stats for the team report.

    In a full Team product this would collect stats from all members via the
    shared Gist's analytics file. For now, it returns local stats with a
    structure ready for future aggregation.
    """
    from .usage import get_usage_summary, get_waste_report, get_server_usage_stats
    from .config import get_claude_code_config_path, get_all_mcp_servers

    summary = get_usage_summary(days=days)
    servers = get_all_mcp_servers(get_claude_code_config_path())
    waste = get_waste_report(list(servers.keys()), days=days) if servers else []
    server_stats = get_server_usage_stats(days=days)

    return {
        "machine": _machine_id(),
        "period_days": days,
        "total_calls": summary.get("total_calls", 0),
        "unique_servers": summary.get("unique_servers", 0),
        "top_servers": summary.get("top_servers", []),
        "server_stats": server_stats,
        "waste_count": len(waste),
        "waste_servers": waste,
        "active_servers": len(servers),
        "generated_at": time.time(),
    }


def push_analytics_to_gist() -> dict:
    """Upload this machine's analytics to the shared team Gist."""
    config = _load_config()
    if not config.get("gist_id"):
        return {"success": False, "message": "Team not configured."}

    report = get_team_report(days=30)
    gist_url_api = f"{GIST_API}/{config['gist_id']}"
    token = config["github_token"]
    machine = _machine_id()

    # Read current analytics file
    remote = _gist_request(gist_url_api, token=token)
    if not remote or "error" in remote:
        return {"success": False, "message": f"Cannot read team Gist: {remote}"}

    try:
        analytics_content = remote["files"].get(TEAM_ANALYTICS_FILENAME, {}).get("content", "{}")
        analytics = json.loads(analytics_content)
    except Exception:
        analytics = {"version": 1, "member_stats": {}}

    analytics["member_stats"][machine] = report
    analytics["updated_at"] = time.time()

    result = _gist_request(
        gist_url_api, method="PATCH", token=token,
        payload={"files": {TEAM_ANALYTICS_FILENAME: {"content": json.dumps(analytics, indent=2)}}}
    )

    if not result or "error" in result:
        return {"success": False, "message": f"Analytics push failed: {result}"}

    return {"success": True, "message": f"Analytics uploaded for {machine}."}


def get_full_team_analytics() -> dict:
    """Download and aggregate analytics from all team members."""
    config = _load_config()
    if not config.get("gist_id"):
        return {"success": False, "message": "Team not configured."}

    gist_url_api = f"{GIST_API}/{config['gist_id']}"
    remote = _gist_request(gist_url_api, token=config["github_token"])
    if not remote or "error" in remote:
        return {"success": False, "message": f"Cannot read team Gist: {remote}"}

    try:
        analytics_content = remote["files"][TEAM_ANALYTICS_FILENAME]["content"]
        analytics = json.loads(analytics_content)
    except Exception:
        return {"success": False, "message": "No team analytics data yet."}

    member_stats = analytics.get("member_stats", {})

    # Aggregate across all members
    total_calls = sum(m.get("total_calls", 0) for m in member_stats.values())
    all_waste = []
    server_call_totals: dict = {}

    for member_data in member_stats.values():
        for w in member_data.get("waste_servers", []):
            all_waste.append(w)
        for s in member_data.get("top_servers", []):
            srv = s["server"]
            server_call_totals[srv] = server_call_totals.get(srv, 0) + s["calls"]

    top_servers = sorted(
        [{"server": k, "calls": v} for k, v in server_call_totals.items()],
        key=lambda x: x["calls"],
        reverse=True,
    )[:10]

    # Deduplicate waste by server name, keep highest level
    waste_map: dict = {}
    for w in all_waste:
        srv = w["server"]
        if srv not in waste_map or w.get("total_calls", 0) > waste_map[srv].get("total_calls", 0):
            waste_map[srv] = w

    return {
        "success": True,
        "member_count": len(member_stats),
        "members": list(member_stats.keys()),
        "total_calls": total_calls,
        "top_servers_across_team": top_servers,
        "waste_count": len(waste_map),
        "waste_servers": list(waste_map.values()),
        "updated_at": analytics.get("updated_at"),
    }


# ---------------------------------------------------------------------------
# Slack monthly report
# ---------------------------------------------------------------------------

def send_monthly_report_to_slack() -> dict:
    """Build a team analytics report and post it to Slack."""
    config = _load_config()
    if not config.get("slack_webhook"):
        return {"success": False, "message": "No Slack webhook configured."}

    data = get_full_team_analytics()
    if not data.get("success"):
        # Fall back to local-only report
        data = get_team_report(days=30)
        data["member_count"] = 1
        data["top_servers_across_team"] = data.get("top_servers", [])

    top_text = "\n".join(
        f"  - *{s['server']}*: {s['calls']} calls"
        for s in data.get("top_servers_across_team", [])[:5]
    ) or "  No usage data."

    waste_text = (
        "\n".join(f"  - *{w['server']}* ({w.get('waste_level','?')})"
                  for w in data.get("waste_servers", [])[:5])
        if data.get("waste_count", 0) > 0
        else "  No waste detected."
    )

    blocks = [
        {"type": "header",
         "text": {"type": "plain_text", "text": ":bar_chart: MCPSwitch Team Monthly Report"}},
        {"type": "section",
         "fields": [
             {"type": "mrkdwn", "text": f"*Team members:*\n{data.get('member_count', 1)}"},
             {"type": "mrkdwn", "text": f"*Total tool calls (30d):*\n{data.get('total_calls', 0):,}"},
             {"type": "mrkdwn", "text": f"*Waste alerts:*\n{data.get('waste_count', 0)}"},
         ]},
        {"type": "section",
         "text": {"type": "mrkdwn", "text": f"*Top Servers (team-wide):*\n{top_text}"}},
        {"type": "section",
         "text": {"type": "mrkdwn", "text": f"*Waste Alerts:*\n{waste_text}"}},
        {"type": "context",
         "elements": [{"type": "mrkdwn",
                        "text": "Fix waste with `mcpswitch waste --fix` | MCPSwitch Team"}]},
    ]

    ok = _post_slack(config["slack_webhook"], {"blocks": blocks})
    return {"success": ok, "message": "Monthly report sent to Slack." if ok else "Slack delivery failed."}
