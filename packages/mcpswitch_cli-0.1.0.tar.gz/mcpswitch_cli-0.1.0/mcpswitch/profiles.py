"""Profile management — create, read, update, delete MCP profiles."""

import json
from pathlib import Path
from typing import Optional

PROFILES_DIR = Path.home() / ".mcpswitch"
PROFILES_FILE = PROFILES_DIR / "profiles.json"
STATE_FILE = PROFILES_DIR / "state.json"


def _ensure_dir():
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)


def load_profiles() -> dict:
    """Load all profiles from disk."""
    _ensure_dir()
    if not PROFILES_FILE.exists():
        return {}
    with open(PROFILES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_profiles(profiles: dict) -> None:
    """Save all profiles to disk."""
    _ensure_dir()
    with open(PROFILES_FILE, "w", encoding="utf-8") as f:
        json.dump(profiles, f, indent=2)


def get_active_profile() -> Optional[str]:
    """Return name of currently active profile."""
    _ensure_dir()
    if not STATE_FILE.exists():
        return None
    with open(STATE_FILE, "r", encoding="utf-8") as f:
        return json.load(f).get("active")


def set_active_profile(name: Optional[str]) -> None:
    """Set the active profile name."""
    _ensure_dir()
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump({"active": name}, f, indent=2)


def create_profile(name: str, servers: dict) -> None:
    """Create or overwrite a profile with the given servers."""
    profiles = load_profiles()
    profiles[name] = servers
    save_profiles(profiles)


def get_profile(name: str) -> Optional[dict]:
    """Get servers dict for a profile."""
    return load_profiles().get(name)


def delete_profile(name: str) -> bool:
    """Delete a profile. Returns False if not found."""
    profiles = load_profiles()
    if name not in profiles:
        return False
    del profiles[name]
    save_profiles(profiles)
    if get_active_profile() == name:
        set_active_profile(None)
    return True


def list_profiles() -> list[str]:
    """Return sorted list of profile names."""
    return sorted(load_profiles().keys())


def add_server_to_profile(profile_name: str, server_name: str, server_config: dict) -> bool:
    """Add a server to an existing profile. Returns False if profile not found."""
    profiles = load_profiles()
    if profile_name not in profiles:
        return False
    profiles[profile_name][server_name] = server_config
    save_profiles(profiles)
    return True


def remove_server_from_profile(profile_name: str, server_name: str) -> bool:
    """Remove a server from a profile. Returns False if not found."""
    profiles = load_profiles()
    if profile_name not in profiles:
        return False
    if server_name not in profiles[profile_name]:
        return False
    del profiles[profile_name][server_name]
    save_profiles(profiles)
    return True
