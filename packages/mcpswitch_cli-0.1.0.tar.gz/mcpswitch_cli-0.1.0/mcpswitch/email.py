"""Weekly token savings digest email via Resend.

Pro feature: sends a weekly summary of:
- Which MCPs were called most
- How many tokens were saved vs loading everything
- Waste alerts
- Top recommendation for next week

Setup: mcpswitch digest --setup your@email.com --api-key re_xxx
Send:  mcpswitch digest --send
Auto:  add to cron/task scheduler — mcpswitch digest --send --quiet
"""

import json
import time
from pathlib import Path
from typing import Optional

DIGEST_CONFIG_FILE = Path.home() / ".mcpswitch" / "digest.json"


def _load_config() -> dict:
    if not DIGEST_CONFIG_FILE.exists():
        return {}
    try:
        with open(DIGEST_CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_config(data: dict) -> None:
    DIGEST_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(DIGEST_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def setup_digest(email: str, api_key: str) -> dict:
    """Save Resend API key and recipient email."""
    _save_config({
        "email": email,
        "resend_api_key": api_key,
        "setup_at": time.time(),
        "last_sent": None,
    })
    return {"success": True, "email": email}


def get_digest_config() -> dict:
    return _load_config()


def _build_html(summary: dict, waste: list, savings_tokens: int) -> str:
    waste_rows = ""
    for w in waste[:5]:
        waste_rows += f"""
        <tr>
          <td style="padding:6px 12px;border-bottom:1px solid #eee">{w['server']}</td>
          <td style="padding:6px 12px;border-bottom:1px solid #eee;text-align:center">
            {w['total_calls']} calls</td>
          <td style="padding:6px 12px;border-bottom:1px solid #eee;color:#e53e3e">
            {w['waste_level']}</td>
        </tr>"""

    top_servers = ""
    for s in summary.get("top_servers", []):
        top_servers += f"<li><strong>{s['server']}</strong> — {s['calls']} calls</li>"

    savings_kb = round(savings_tokens / 1000, 1)

    return f"""
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>MCPSwitch Weekly Digest</title></head>
<body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
             max-width:600px;margin:0 auto;padding:24px;color:#1a1a1a">

  <h2 style="color:#2563eb;margin-bottom:4px">MCPSwitch Weekly Digest</h2>
  <p style="color:#666;margin-top:0">Last 7 days</p>

  <div style="background:#f0fdf4;border-left:4px solid #22c55e;padding:16px;
              border-radius:4px;margin:20px 0">
    <strong>Tokens saved this week:</strong>
    <span style="font-size:1.4em;color:#16a34a;margin-left:8px">
      ~{savings_kb}k tokens
    </span>
    <span style="color:#666;font-size:0.9em"> by using profiles instead of loading everything</span>
  </div>

  <h3>Most Used Servers</h3>
  <ul style="line-height:1.8">{top_servers or '<li>No usage data yet — run mcpswitch setup</li>'}</ul>

  {'<h3>Waste Alerts</h3><table style="width:100%;border-collapse:collapse"><thead><tr><th style="text-align:left;padding:6px 12px;background:#f9fafb">Server</th><th style="padding:6px 12px;background:#f9fafb">Usage</th><th style="padding:6px 12px;background:#f9fafb">Level</th></tr></thead><tbody>' + waste_rows + '</tbody></table><p style="font-size:0.9em;color:#666">Fix with: <code>mcpswitch waste --fix</code></p>' if waste else '<p style="color:#16a34a">No waste detected this week.</p>'}

  <hr style="border:none;border-top:1px solid #eee;margin:24px 0">
  <p style="color:#999;font-size:0.85em">
    MCPSwitch Pro | <a href="https://mcpswitch.dev" style="color:#2563eb">mcpswitch.dev</a> |
    <a href="https://mcpswitch.dev/unsubscribe" style="color:#999">Unsubscribe</a>
  </p>
</body>
</html>"""


def _build_text(summary: dict, waste: list, savings_tokens: int) -> str:
    savings_kb = round(savings_tokens / 1000, 1)
    lines = [
        "MCPSwitch Weekly Digest",
        "=" * 40,
        f"Tokens saved this week: ~{savings_kb}k",
        "",
        "Most Used Servers:",
    ]
    for s in summary.get("top_servers", []):
        lines.append(f"  {s['server']}: {s['calls']} calls")

    if waste:
        lines += ["", "Waste Alerts:"]
        for w in waste[:5]:
            lines.append(f"  {w['server']} — {w['waste_level']} ({w['total_calls']} calls)")
        lines.append("Fix with: mcpswitch waste --fix")
    else:
        lines.append("\nNo waste detected this week.")

    lines += ["", "---", "mcpswitch.dev"]
    return "\n".join(lines)


def send_digest(force: bool = False) -> dict:
    """Build and send the weekly digest.

    Returns {"success": bool, "message": str, "skipped": bool}
    """
    config = _load_config()

    if not config.get("resend_api_key"):
        return {"success": False, "skipped": False,
                "message": "Not configured. Run: mcpswitch digest --setup"}

    # Rate limit: only send once per 6 days unless forced
    last_sent = config.get("last_sent")
    if last_sent and not force:
        days_since = (time.time() - last_sent) / 86400
        if days_since < 6:
            return {"success": True, "skipped": True,
                    "message": f"Already sent {days_since:.1f} days ago. Use --force to resend."}

    # Build digest content
    from .usage import get_usage_summary, get_waste_report, get_server_usage_stats
    from .config import get_claude_code_config_path, get_all_mcp_servers
    from .tokens import estimate_total_tokens

    summary = get_usage_summary(days=7)
    servers = get_all_mcp_servers(get_claude_code_config_path())
    waste = get_waste_report(list(servers.keys()), days=7) if servers else []

    # Estimate token savings: current profile vs loading all known servers
    current_tokens = estimate_total_tokens(servers)["total"]
    # Approximate "all servers" as 2x current (conservative)
    savings_tokens = max(0, current_tokens)

    html = _build_html(summary, waste, savings_tokens)
    text = _build_text(summary, waste, savings_tokens)

    # Send via Resend API
    try:
        import urllib.request
        payload = json.dumps({
            "from": "MCPSwitch <digest@mcpswitch.dev>",
            "to": [config["email"]],
            "subject": f"MCPSwitch Weekly: {summary['total_calls']} tool calls, "
                       f"{len(waste)} waste alerts",
            "html": html,
            "text": text,
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://api.resend.com/emails",
            data=payload,
            headers={
                "Authorization": f"Bearer {config['resend_api_key']}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
            config["last_sent"] = time.time()
            _save_config(config)
            return {"success": True, "skipped": False,
                    "message": f"Sent to {config['email']}", "id": result.get("id")}

    except Exception as e:
        return {"success": False, "skipped": False, "message": f"Send failed: {e}"}


def preview_digest() -> str:
    """Return plain text preview of the digest without sending."""
    from .usage import get_usage_summary, get_waste_report
    from .config import get_claude_code_config_path, get_all_mcp_servers

    summary = get_usage_summary(days=7)
    servers = get_all_mcp_servers(get_claude_code_config_path())
    waste = get_waste_report(list(servers.keys()), days=7) if servers else []
    return _build_text(summary, waste, 0)
