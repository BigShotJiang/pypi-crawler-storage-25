"""Usage tracking — log every MCP tool call to SQLite.

This is the data moat. Every tool call logged here powers:
- Waste detection (Pro): "you loaded this MCP 200 sessions, called 0 tools"
- Predictive loading (Pro): "based on your history, you'll need github in 2 turns"
- Team analytics (Team): "your team wasted X tokens in MCP overhead this month"
"""

import json
import sqlite3
import time
from pathlib import Path
from typing import Optional

USAGE_DB = Path.home() / ".mcpswitch" / "usage.db"
USAGE_DB.parent.mkdir(parents=True, exist_ok=True)


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(USAGE_DB))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tool_calls (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id   TEXT,
            server_name  TEXT NOT NULL,
            tool_name    TEXT NOT NULL,
            called_at    REAL NOT NULL,
            profile_name TEXT,
            project_dir  TEXT,
            success      INTEGER DEFAULT 1
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            session_id   TEXT PRIMARY KEY,
            profile_name TEXT,
            project_dir  TEXT,
            started_at   REAL NOT NULL,
            ended_at     REAL,
            tools_called INTEGER DEFAULT 0,
            tokens_saved INTEGER DEFAULT 0
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_server ON tool_calls(server_name)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_called_at ON tool_calls(called_at)")
    conn.commit()
    return conn


def log_tool_call(
    tool_name: str,
    session_id: Optional[str] = None,
    profile_name: Optional[str] = None,
    project_dir: Optional[str] = None,
    success: bool = True,
) -> None:
    """Log a single MCP tool call. Called from PostToolUse hook."""
    # Extract server name from tool name (mcp__github__create_pr -> github)
    server_name = _extract_server(tool_name)
    if not server_name:
        return  # Not an MCP tool call

    try:
        conn = _get_db()
        conn.execute(
            """INSERT INTO tool_calls
               (session_id, server_name, tool_name, called_at, profile_name, project_dir, success)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (session_id, server_name, tool_name, time.time(),
             profile_name, project_dir, int(success))
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def _extract_server(tool_name: str) -> Optional[str]:
    """Extract server name from MCP tool name.

    mcp__github__create_pull_request  -> github
    mcp__brave-search__search          -> brave-search
    github__create_pull_request        -> github  (some servers drop the mcp__ prefix)
    """
    if tool_name.startswith("mcp__"):
        parts = tool_name.split("__")
        return parts[1] if len(parts) >= 2 else None
    # Some tools use server__tool format without mcp__ prefix
    if "__" in tool_name:
        return tool_name.split("__")[0]
    return None


def get_server_usage_stats(days: int = 30) -> list[dict]:
    """Return usage stats per server for the last N days.

    Used for waste detection: servers loaded but rarely/never called.
    """
    since = time.time() - (days * 86400)
    try:
        conn = _get_db()
        rows = conn.execute("""
            SELECT
                server_name,
                COUNT(*)           as total_calls,
                COUNT(DISTINCT DATE(called_at, 'unixepoch')) as active_days,
                COUNT(DISTINCT session_id) as sessions_used,
                MAX(called_at)     as last_used
            FROM tool_calls
            WHERE called_at > ?
            GROUP BY server_name
            ORDER BY total_calls DESC
        """, (since,)).fetchall()
        conn.close()
        return [
            {
                "server": r[0],
                "total_calls": r[1],
                "active_days": r[2],
                "sessions_used": r[3],
                "last_used": r[4],
                "last_used_days_ago": round((time.time() - r[4]) / 86400, 1) if r[4] else None,
            }
            for r in rows
        ]
    except Exception:
        return []


def get_waste_report(loaded_servers: list[str], days: int = 30) -> list[dict]:
    """Compare loaded servers vs actually called servers.

    Returns list of servers that are loaded but rarely/never used.
    This is the core Pro feature.
    """
    usage = {s["server"]: s for s in get_server_usage_stats(days)}
    waste = []

    for server in loaded_servers:
        stats = usage.get(server)
        if stats is None:
            # Loaded but NEVER called in last N days
            waste.append({
                "server": server,
                "total_calls": 0,
                "sessions_used": 0,
                "last_used_days_ago": None,
                "waste_level": "high",
                "recommendation": f"Never called in {days} days. Remove from profile.",
            })
        elif stats["total_calls"] < 3:
            # Loaded but almost never called
            waste.append({
                "server": server,
                "total_calls": stats["total_calls"],
                "sessions_used": stats["sessions_used"],
                "last_used_days_ago": stats["last_used_days_ago"],
                "waste_level": "medium",
                "recommendation": f"Only {stats['total_calls']} calls in {days} days. Consider removing.",
            })

    return sorted(waste, key=lambda x: x["total_calls"])


def get_session_tool_sequence(session_id: str) -> list[str]:
    """Return ordered list of tools called in a session.

    Used for predictive loading: if users always call github then playwright,
    preload both when github profile is active.
    """
    try:
        conn = _get_db()
        rows = conn.execute(
            "SELECT tool_name FROM tool_calls WHERE session_id = ? ORDER BY called_at",
            (session_id,)
        ).fetchall()
        conn.close()
        return [r[0] for r in rows]
    except Exception:
        return []


def get_top_tools_by_server(server_name: str, limit: int = 10) -> list[dict]:
    """Return the most-called tools from a specific server.

    Used to build minimal profiles: instead of loading ALL 30 github tools,
    load only the 5 you actually use.
    """
    try:
        conn = _get_db()
        rows = conn.execute("""
            SELECT tool_name, COUNT(*) as calls
            FROM tool_calls
            WHERE server_name = ?
            GROUP BY tool_name
            ORDER BY calls DESC
            LIMIT ?
        """, (server_name, limit)).fetchall()
        conn.close()
        return [{"tool": r[0], "calls": r[1]} for r in rows]
    except Exception:
        return []


def get_usage_summary(days: int = 7) -> dict:
    """High-level summary for the weekly digest email."""
    since = time.time() - (days * 86400)
    try:
        conn = _get_db()
        total_calls = conn.execute(
            "SELECT COUNT(*) FROM tool_calls WHERE called_at > ?", (since,)
        ).fetchone()[0]

        unique_servers = conn.execute(
            "SELECT COUNT(DISTINCT server_name) FROM tool_calls WHERE called_at > ?", (since,)
        ).fetchone()[0]

        most_used = conn.execute("""
            SELECT server_name, COUNT(*) as c FROM tool_calls
            WHERE called_at > ?
            GROUP BY server_name ORDER BY c DESC LIMIT 3
        """, (since,)).fetchall()

        conn.close()
        return {
            "days": days,
            "total_calls": total_calls,
            "unique_servers": unique_servers,
            "top_servers": [{"server": r[0], "calls": r[1]} for r in most_used],
        }
    except Exception:
        return {"days": days, "total_calls": 0, "unique_servers": 0, "top_servers": []}
