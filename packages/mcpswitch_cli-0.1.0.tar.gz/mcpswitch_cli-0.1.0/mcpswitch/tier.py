"""Tier management — Free, Pro (donation-ware), and Team (Lemon Squeezy).

Free:  profile management, token estimation, auto-switch, analyze
Pro:   waste detection, usage stats, weekly digest, community profiles, sync
       -> always free; a periodic donation nudge is shown (non-blocking)
Team:  team analytics, shared profiles, Slack alerts
       -> requires a paid Team license (Lemon Squeezy)

License keys are stored in ``~/.mcpswitch/license.json`` and validated
offline via HMAC (see ``mcpswitch.billing``).
"""

import json
import time
from pathlib import Path

from .billing import (
    TEAM_PAYMENT_URL,
    validate_license_key,
)

LICENSE_FILE = Path.home() / ".mcpswitch" / "license.json"
NUDGE_FILE   = Path.home() / ".mcpswitch" / "nudge.json"

# How often to show the donation nudge (seconds).  Default: once per 7 days.
_NUDGE_INTERVAL = 7 * 24 * 3600



# ── License persistence ───────────────────────────────────────────────────────

def _load_license() -> dict:
    if not LICENSE_FILE.exists():
        return {}
    try:
        with open(LICENSE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_license(data: dict) -> None:
    LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ── Activation ────────────────────────────────────────────────────────────────

def activate_license(key: str) -> dict:
    """Activate a Team license key.

    Returns ``{"success": bool, "tier": str, "message": str}``.
    """
    key = key.strip()

    result = validate_license_key(key)
    if not result["valid"]:
        return {
            "success": False,
            "tier":    "free",
            "message": f"Invalid license key: {result['error']}",
        }

    tier  = result["tier"]   # always "team" for Lemon Squeezy-issued keys
    seats = result.get("seats", 1)

    _save_license({
        "key":          key.upper(),
        "tier":         tier,
        "activated_at": time.time(),
        "seats":        seats,
        "email_hash":   result.get("email_hash", ""),
    })

    seat_str = f" ({seats} seat{'s' if seats != 1 else ''})"
    return {
        "success": True,
        "tier":    tier,
        "message": f"Activated {tier.upper()} tier{seat_str}.",
    }


# ── Tier queries ──────────────────────────────────────────────────────────────

def get_tier() -> str:
    """Return current tier: ``'free'``, ``'pro'``, or ``'team'``."""
    return _load_license().get("tier", "free")


def is_pro() -> bool:
    # Pro features are free — everyone is considered "pro".
    return True


def is_team() -> bool:
    return get_tier() == "team"


def deactivate() -> None:
    if LICENSE_FILE.exists():
        LICENSE_FILE.unlink()


# ── Feature gates ─────────────────────────────────────────────────────────────

def require_pro(feature_name: str) -> bool:
    """Always returns ``True`` — Pro features are free for everyone.

    Call ``maybe_show_donation_nudge()`` separately to show an optional nudge.
    """
    return True


def pro_gate_message(feature_name: str) -> str:
    """Kept for backward-compat; now returns the donation nudge message."""
    return donation_nudge_message()


# ── Donation nudge (non-blocking) ─────────────────────────────────────────────

def _load_nudge() -> dict:
    if not NUDGE_FILE.exists():
        return {}
    try:
        with open(NUDGE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_nudge(data: dict) -> None:
    NUDGE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(NUDGE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def should_show_nudge() -> bool:
    """Return True if enough time has passed since the last donation nudge."""
    if is_team():
        return False   # paid users don't see donation prompts
    nudge = _load_nudge()
    last  = nudge.get("last_shown", 0)
    return (time.time() - last) >= _NUDGE_INTERVAL


def record_nudge_shown() -> None:
    """Mark that the nudge was shown now."""
    _save_nudge({"last_shown": time.time()})


def donation_nudge_message() -> str:
    return (
        "\n[dim]─────────────────────────────────────────────────────[/dim]\n"
        "[bold yellow]MCPSwitch is free and open-source.[/bold yellow] "
        "If it saves you context, consider supporting it:\n\n"
        "  [bold cyan]mcpswitch donate[/bold cyan]   "
        "→ one-time tip, any amount, no account needed\n\n"
        "Want team features (shared profiles, Slack alerts)?\n"
        "  [bold cyan]mcpswitch upgrade[/bold cyan]  "
        f"→ {TEAM_PAYMENT_URL}\n"
        "[dim]─────────────────────────────────────────────────────[/dim]\n"
    )


def maybe_show_donation_nudge(console) -> None:
    """Print the donation nudge if the weekly timer has elapsed."""
    if should_show_nudge():
        console.print(donation_nudge_message())
        record_nudge_shown()
