"""Read and write Claude MCP config files."""

import json
import os
import platform
import shutil
from pathlib import Path
from typing import Optional


def get_claude_code_config_path() -> Path:
    """~/.claude/claude_desktop_config.json — used by Claude Code CLI."""
    return Path.home() / ".claude" / "claude_desktop_config.json"


def get_claude_desktop_config_path() -> Optional[Path]:
    """AppData/Roaming/Claude/claude_desktop_config.json — Claude Desktop app."""
    if platform.system() == "Windows":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            return Path(appdata) / "Claude" / "claude_desktop_config.json"
    elif platform.system() == "Darwin":
        return Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    elif platform.system() == "Linux":
        return Path.home() / ".config" / "Claude" / "claude_desktop_config.json"
    return None


def read_config(path: Path) -> dict:
    """Read a Claude config file. Returns empty dict if not found."""
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_config(path: Path, data: dict) -> None:
    """Write config atomically with backup."""
    path.parent.mkdir(parents=True, exist_ok=True)

    # Backup before overwrite
    if path.exists():
        backup = path.with_suffix(".json.bak")
        shutil.copy2(path, backup)

    tmp = path.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    tmp.replace(path)


def get_all_mcp_servers(path: Path) -> dict:
    """Return the mcpServers dict from a config file."""
    config = read_config(path)
    return config.get("mcpServers", {})


def set_mcp_servers(path: Path, servers: dict) -> None:
    """Replace mcpServers in config, preserving all other keys."""
    config = read_config(path)
    config["mcpServers"] = servers
    write_config(path, config)
