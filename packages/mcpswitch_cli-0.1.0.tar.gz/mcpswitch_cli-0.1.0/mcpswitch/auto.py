"""Context-aware automatic profile selection.

How it works:
1. Read conversation context from ~/.claude/history.jsonl (last N messages)
2. Scan project directory for tech stack signals
3. Score each profile against detected context
4. Switch to the best match — silently if confident, ask if not

This runs at session start via: mcpswitch auto
Or manually: mcpswitch auto --dir /path/to/project
"""

import json
import os
import re
from pathlib import Path
from typing import Optional

from .profiles import load_profiles, get_active_profile, set_active_profile
from .config import get_claude_code_config_path, set_mcp_servers
from .tokens import estimate_total_tokens

# ── Tech stack signals → MCP server names ────────────────────────────────────

# File presence signals: if these files exist, these servers are likely needed
FILE_SIGNALS: list[tuple[str, list[str]]] = [
    # (glob pattern, [relevant mcp server names])
    ("package.json",           ["github", "playwright", "context7"]),
    ("requirements.txt",       ["github", "context7", "postgres"]),
    ("pyproject.toml",         ["github", "context7", "postgres"]),
    ("go.mod",                 ["github", "context7"]),
    ("Cargo.toml",             ["github", "context7"]),
    ("docker-compose.yml",     ["github", "postgres", "sqlite"]),
    (".github/workflows/*.yml",["github"]),
    ("prisma/schema.prisma",   ["github", "postgres"]),
    ("supabase/**",            ["github", "postgres"]),
    ("*.test.*",               ["playwright", "github"]),
    ("playwright.config.*",    ["playwright"]),
    ("*.md",                   ["filesystem", "fetch"]),
    ("docs/**",                ["filesystem", "fetch"]),
]

# Conversation keyword signals: words in recent messages → relevant servers
KEYWORD_SIGNALS: dict[str, list[str]] = {
    # Code & git
    "pull request":   ["github"],
    "pr review":      ["github"],
    "github":         ["github"],
    "commit":         ["github"],
    "branch":         ["github"],
    "merge":          ["github"],

    # Browser / frontend
    "browser":        ["playwright"],
    "screenshot":     ["playwright"],
    "click":          ["playwright"],
    "scrape":         ["playwright"],
    "selenium":       ["playwright"],
    "test":           ["playwright", "github"],

    # Search
    "search":         ["brave-search"],
    "google":         ["brave-search"],
    "find online":    ["brave-search"],
    "look up":        ["brave-search"],

    # Database
    "database":       ["postgres", "sqlite"],
    "sql":            ["postgres", "sqlite"],
    "postgres":       ["postgres"],
    "sqlite":         ["sqlite"],
    "query":          ["postgres", "sqlite"],

    # Docs / files
    "documentation":  ["filesystem", "context7"],
    "readme":         ["filesystem"],
    "file":           ["filesystem"],
    "read file":      ["filesystem"],

    # API docs
    "api docs":       ["context7"],
    "documentation":  ["context7"],
    "latest docs":    ["context7"],
    "how to use":     ["context7"],

    # Notes / knowledge
    "obsidian":       ["obsidian"],
    "notes":          ["obsidian"],
    "vault":          ["obsidian"],
}

CONFIDENCE_THRESHOLD = 0.4  # switch silently above this, ask below


def _read_recent_history(n_messages: int = 20) -> str:
    """Read the last N messages from Claude Code history.

    Returns concatenated text of recent user messages.
    """
    history_file = Path.home() / ".claude" / "history.jsonl"
    if not history_file.exists():
        return ""

    lines = []
    try:
        with open(history_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return ""

    messages = []
    for line in reversed(lines[-200:]):  # look at last 200 lines max
        try:
            entry = json.loads(line.strip())
            # Extract user message text
            if isinstance(entry, dict):
                content = entry.get("message", "") or entry.get("content", "")
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "text":
                            messages.append(block.get("text", ""))
                elif isinstance(content, str):
                    messages.append(content)
        except Exception:
            continue
        if len(messages) >= n_messages:
            break

    return " ".join(messages).lower()


def _scan_project_signals(directory: str) -> list[str]:
    """Scan directory for tech stack files. Returns list of relevant MCP server names."""
    path = Path(directory)
    if not path.exists():
        return []

    relevant_servers = []
    for pattern, servers in FILE_SIGNALS:
        if "**" in pattern or "*" in pattern:
            matches = list(path.glob(pattern))
        else:
            matches = [path / pattern] if (path / pattern).exists() else []

        if matches:
            relevant_servers.extend(servers)

    return list(set(relevant_servers))


def _score_profile(
    profile_name: str,
    profile_servers: dict,
    context_servers: list[str],
    conversation_servers: list[str],
) -> float:
    """Score a profile 0.0–1.0 based on how well it matches detected context.

    Higher = better match.
    """
    if not profile_servers:
        return 0.0

    loaded = set(profile_servers.keys())
    needed = set(context_servers + conversation_servers)

    if not needed:
        return 0.0

    # Coverage: what % of needed servers does this profile have?
    coverage = len(loaded & needed) / len(needed)

    # Precision: what % of loaded servers are actually needed? (penalize bloat)
    precision = len(loaded & needed) / len(loaded) if loaded else 0.0

    # Weighted: coverage matters more than precision
    score = (coverage * 0.7) + (precision * 0.3)
    return round(score, 3)


def select_best_profile(
    directory: Optional[str] = None,
    conversation_text: Optional[str] = None,
) -> dict:
    """Select the best profile for current context.

    Returns:
    {
        "recommended": str,      # profile name
        "confidence": float,     # 0.0 - 1.0
        "reason": str,           # human-readable explanation
        "scores": {name: score}, # all profile scores
        "context_servers": [...],# servers detected from project
        "conversation_servers":[],# servers detected from conversation
        "current_profile": str,
    }
    """
    profiles = load_profiles()
    current = get_active_profile()

    if not profiles:
        return {
            "recommended": None,
            "confidence": 0.0,
            "reason": "No profiles configured. Run: mcpswitch import --name <name>",
            "scores": {},
            "context_servers": [],
            "conversation_servers": [],
            "current_profile": current,
        }

    # 1. Detect from project files
    project_dir = directory or os.getcwd()
    context_servers = _scan_project_signals(project_dir)

    # 2. Detect from conversation history
    if conversation_text is None:
        conversation_text = _read_recent_history(20)

    conversation_servers = []
    for keyword, servers in KEYWORD_SIGNALS.items():
        if keyword in conversation_text:
            conversation_servers.extend(servers)
    conversation_servers = list(set(conversation_servers))

    # 3. Score all profiles
    scores = {}
    for name, servers in profiles.items():
        scores[name] = _score_profile(name, servers, context_servers, conversation_servers)

    if not any(scores.values()):
        # No signals detected — recommend the profile with fewest tokens (lean default)
        config_path = get_claude_code_config_path()
        best = min(profiles.keys(), key=lambda n: estimate_total_tokens(profiles[n])["total"])
        return {
            "recommended": best,
            "confidence": 0.2,
            "reason": "No project signals detected. Recommending leanest profile.",
            "scores": scores,
            "context_servers": context_servers,
            "conversation_servers": conversation_servers,
            "current_profile": current,
        }

    best = max(scores, key=lambda k: scores[k])
    confidence = scores[best]

    # Build reason string
    reason_parts = []
    if context_servers:
        reason_parts.append(f"project signals: {', '.join(context_servers[:3])}")
    if conversation_servers:
        reason_parts.append(f"conversation context: {', '.join(conversation_servers[:3])}")
    reason = "Detected " + " | ".join(reason_parts) if reason_parts else "Best available match"

    return {
        "recommended": best,
        "confidence": confidence,
        "current_profile": current,
        "scores": scores,
        "context_servers": context_servers,
        "conversation_servers": conversation_servers,
        "reason": reason,
    }


def auto_switch(
    directory: Optional[str] = None,
    confirm_threshold: float = CONFIDENCE_THRESHOLD,
    force: bool = False,
    silent: bool = False,
) -> dict:
    """Auto-select and switch profile based on context.

    Returns:
    {
        "switched": bool,
        "from_profile": str,
        "to_profile": str,
        "confidence": float,
        "needs_confirmation": bool,  # True if confidence below threshold
        "reason": str,
    }
    """
    result = select_best_profile(directory=directory)
    recommended = result["recommended"]
    confidence = result["confidence"]
    current = result["current_profile"]

    if not recommended:
        return {
            "switched": False,
            "from_profile": current,
            "to_profile": None,
            "confidence": 0.0,
            "needs_confirmation": False,
            "reason": result["reason"],
        }

    # Already on the best profile
    if recommended == current and not force:
        return {
            "switched": False,
            "from_profile": current,
            "to_profile": recommended,
            "confidence": confidence,
            "needs_confirmation": False,
            "reason": f"Already on best profile '{current}'",
        }

    # Low confidence — ask user
    if confidence < confirm_threshold and not force:
        return {
            "switched": False,
            "from_profile": current,
            "to_profile": recommended,
            "confidence": confidence,
            "needs_confirmation": True,
            "reason": result["reason"],
        }

    # High confidence — switch silently
    from .profiles import get_profile
    from .config import get_claude_desktop_config_path

    servers = get_profile(recommended)
    if not servers and servers != {}:
        return {
            "switched": False,
            "from_profile": current,
            "to_profile": recommended,
            "confidence": confidence,
            "needs_confirmation": False,
            "reason": f"Profile '{recommended}' not found",
        }

    config_path = get_claude_code_config_path()
    set_mcp_servers(config_path, servers)

    desktop_path = get_claude_desktop_config_path()
    if desktop_path and desktop_path.exists():
        set_mcp_servers(desktop_path, servers)

    set_active_profile(recommended)

    return {
        "switched": True,
        "from_profile": current,
        "to_profile": recommended,
        "confidence": confidence,
        "needs_confirmation": False,
        "reason": result["reason"],
    }
