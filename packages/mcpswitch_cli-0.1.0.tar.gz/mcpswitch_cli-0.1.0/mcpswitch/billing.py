"""
Billing and license-key management for MCPSwitch — Team tier only.

Payment processor: Lemon Squeezy
Store: mcpswitch.lemonsqueezy.com
Product: MCPSwitch Team — ₹499/month subscription

License key format
------------------
    MCPS-TEAM-{PAYLOAD}-{SIG}

    PAYLOAD : Base32-encoded JSON {"e": email_sha256[:16], "t": unix_ts, "s": seats}
    SIG     : Base32-encoded first 10 bytes of HMAC-SHA256(secret, PAYLOAD)

Keys are validated offline — no network call required.
The same HMAC secret must be set in both the CLI build and the webhook server
via the MCPSWITCH_LICENSE_SECRET environment variable.
"""

import base64
import hashlib
import hmac
import json
import os
import time
import webbrowser

# ── HMAC secret ───────────────────────────────────────────────────────────────
# Must match in both the CLI build and the webhook server.
# Set MCPSWITCH_LICENSE_SECRET in your Railway environment variables.
_DEFAULT_SECRET = "mcpswitch-change-me-in-production-v1"
_HMAC_SECRET: bytes = os.environ.get(
    "MCPSWITCH_LICENSE_SECRET", _DEFAULT_SECRET
).encode()

# ── Lemon Squeezy config ──────────────────────────────────────────────────────
LEMONSQUEEZY_API_KEY       = os.environ.get("LEMONSQUEEZY_API_KEY", "")
LEMONSQUEEZY_WEBHOOK_SECRET = os.environ.get("LEMONSQUEEZY_WEBHOOK_SECRET", "")
LEMONSQUEEZY_STORE_ID      = os.environ.get("LEMONSQUEEZY_STORE_ID", "")
LEMONSQUEEZY_VARIANT_ID    = os.environ.get("LEMONSQUEEZY_VARIANT_ID", "1525680")
LEMONSQUEEZY_PRODUCT_ID    = os.environ.get("LEMONSQUEEZY_PRODUCT_ID", "971803")

# Checkout URL — Lemon Squeezy hosted checkout for the Team variant
TEAM_PAYMENT_URL = os.environ.get(
    "MCPSWITCH_TEAM_URL",
    f"https://mcpswitch.lemonsqueezy.com/buy/{LEMONSQUEEZY_VARIANT_ID}",
)


# ── Base32 helpers (no padding) ───────────────────────────────────────────────

def _b32_encode(data: bytes) -> str:
    return base64.b32encode(data).decode().rstrip("=")


def _b32_decode(s: str) -> bytes:
    s = s.upper()
    pad = (8 - len(s) % 8) % 8
    return base64.b32decode(s + "=" * pad)


# ── License key generation ────────────────────────────────────────────────────

def generate_license_key(email: str, seats: int = 1) -> str:
    """Generate a cryptographically signed Team license key.

    Args:
        email: Buyer's email address. Stored as a truncated SHA-256 hash —
               never in plaintext.
        seats: Number of seats included in the purchase.

    Returns:
        A key string like ``MCPS-TEAM-MNQWI...-ABCDE...``
    """
    email_hash   = hashlib.sha256(email.lower().strip().encode()).hexdigest()[:16]
    issued_at    = int(time.time())
    payload_json = json.dumps(
        {"e": email_hash, "t": issued_at, "s": seats},
        separators=(",", ":"),
    )
    payload = _b32_encode(payload_json.encode())
    sig_raw = hmac.digest(_HMAC_SECRET, payload.encode(), "sha256")[:10]
    sig     = _b32_encode(sig_raw)
    return f"MCPS-TEAM-{payload}-{sig}"


# ── License key validation ────────────────────────────────────────────────────

def validate_license_key(key: str) -> dict:
    """Validate a Team license key offline using HMAC.

    Returns on success::

        {"valid": True, "tier": "team", "issued_at": int, "seats": int, "email_hash": str}

    Returns on failure::

        {"valid": False, "error": "<reason>"}
    """
    key = key.strip().upper()

    parts = key.split("-", 3)
    if len(parts) != 4 or parts[0] != "MCPS" or parts[1] != "TEAM":
        return {"valid": False, "error": "Invalid key format — expected MCPS-TEAM-... key"}

    _, _tier, payload, claimed_sig = parts

    expected_raw = hmac.digest(_HMAC_SECRET, payload.encode(), "sha256")[:10]
    expected_sig = _b32_encode(expected_raw)

    if not hmac.compare_digest(expected_sig, claimed_sig):
        return {"valid": False, "error": "Key signature is invalid"}

    try:
        meta = json.loads(_b32_decode(payload).decode())
    except Exception:
        return {"valid": False, "error": "Key payload is corrupted"}

    return {
        "valid":      True,
        "tier":       "team",
        "issued_at":  meta.get("t", 0),
        "seats":      meta.get("s", 1),
        "email_hash": meta.get("e", ""),
    }


# ── Lemon Squeezy checkout ────────────────────────────────────────────────────

def open_checkout() -> str:
    """Open the Lemon Squeezy checkout page for the Team tier in the browser.

    Returns:
        The URL that was opened.
    """
    webbrowser.open(TEAM_PAYMENT_URL)
    return TEAM_PAYMENT_URL


# ── Lemon Squeezy webhook verification ───────────────────────────────────────

def verify_lemonsqueezy_webhook(payload: bytes, sig_header: str) -> dict:
    """Verify a Lemon Squeezy webhook signature and return the parsed event.

    Lemon Squeezy signs webhooks with HMAC-SHA256.
    The signature is in the X-Signature header as a hex digest.

    Args:
        payload:    Raw request body bytes.
        sig_header: Value of the ``X-Signature`` HTTP header.

    Returns:
        Parsed event dict.

    Raises:
        ValueError: If the webhook secret is not set or signature is invalid.
    """
    if not LEMONSQUEEZY_WEBHOOK_SECRET:
        raise ValueError(
            "LEMONSQUEEZY_WEBHOOK_SECRET is not configured. "
            "Set it to your webhook signing secret from the Lemon Squeezy Dashboard."
        )

    expected = hmac.digest(
        LEMONSQUEEZY_WEBHOOK_SECRET.encode(),
        payload,
        "sha256",
    ).hex()

    if not hmac.compare_digest(expected, sig_header.lower()):
        raise ValueError("Webhook signature is invalid")

    return json.loads(payload.decode())
