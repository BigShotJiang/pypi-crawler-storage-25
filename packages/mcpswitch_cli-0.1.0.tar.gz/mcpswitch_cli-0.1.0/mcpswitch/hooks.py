"""Claude Code hook handlers.

Hooks receive JSON on stdin, write response to stdout.

PreToolUse  — fires before every tool call
              → check if MCP is loaded, warn if not
PostToolUse — fires after every tool call
              → log the call to usage.db (data moat)

Install with: mcpswitch setup
"""

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

from .usage import log_tool_call, _extract_server
from .profiles import get_active_profile, load_profiles
from .config import get_claude_code_config_path, get_all_mcp_servers


def _read_stdin() -> Optional[dict]:
    try:
        raw = sys.stdin.read()
        return json.loads(raw) if raw.strip() else None
    except Exception:
        return None


def _write_response(data: dict) -> None:
    sys.stdout.write(json.dumps(data) + "\n")
    sys.stdout.flush()


def handle_post_tool_use() -> None:
    """PostToolUse hook — log every MCP tool call.

    stdin JSON:
    {
      "session_id": "abc123",
      "tool_name": "mcp__github__create_pull_request",
      "tool_input": {...},
      "tool_result": {...}
    }
    """
    data = _read_stdin()
    if not data:
        sys.exit(0)

    tool_name = data.get("tool_name", "")
    server = _extract_server(tool_name)

    if not server:
        sys.exit(0)  # Not an MCP tool, skip

    session_id = data.get("session_id")
    project_dir = os.getcwd()
    active_profile = get_active_profile()

    # Determine success from tool result
    result = data.get("tool_result", {})
    success = True
    if isinstance(result, dict):
        success = not result.get("isError", False)

    log_tool_call(
        tool_name=tool_name,
        session_id=session_id,
        profile_name=active_profile,
        project_dir=project_dir,
        success=success,
    )

    sys.exit(0)


def handle_pre_tool_use() -> None:
    """PreToolUse hook — check if MCP is loaded, warn user if not.

    Does NOT block the tool call (exit 0 always).
    Just warns the user so they know to switch profile next session.

    stdin JSON:
    {
      "session_id": "abc123",
      "tool_name": "mcp__github__create_pull_request",
      "tool_input": {...}
    }

    Output (if warning):
    {
      "hookSpecificOutput": {
        "permissionDecision": "allow",
        "userFacingMessage": "MCPSwitch: github not in active profile 'lean'. Run: mcpswitch use full"
      }
    }
    """
    data = _read_stdin()
    if not data:
        sys.exit(0)

    tool_name = data.get("tool_name", "")
    server = _extract_server(tool_name)

    if not server:
        sys.exit(0)

    # Check if this server is in the current Claude config
    try:
        config_path = get_claude_code_config_path()
        loaded_servers = get_all_mcp_servers(config_path)
        active_profile = get_active_profile()

        if server not in loaded_servers:
            # Find which profiles have this server
            all_profiles = load_profiles()
            profiles_with_server = [
                name for name, servers in all_profiles.items()
                if server in servers
            ]

            if profiles_with_server:
                suggestion = f"mcpswitch use {profiles_with_server[0]}"
            else:
                suggestion = f"mcpswitch add <profile> {server}"

            msg = (
                f"[MCPSwitch] '{server}' not in active profile '{active_profile or 'none'}'. "
                f"Tool may fail. Fix: {suggestion}"
            )
            _write_response({
                "hookSpecificOutput": {
                    "permissionDecision": "allow",
                    "userFacingMessage": msg,
                }
            })
    except Exception:
        pass

    sys.exit(0)


def get_hooks_config() -> dict:
    """Return the hooks config block to inject into ~/.claude/settings.json.

    Uses the mcpswitch module directly so no path issues.
    Python executable from current venv or system python.
    """
    python = sys.executable

    return {
        "PreToolUse": [
            {
                "matcher": "mcp__.*",
                "hooks": [
                    {
                        "type": "command",
                        "command": f'"{python}" -m mcpswitch.hooks pre_tool_use',
                    }
                ],
            }
        ],
        "PostToolUse": [
            {
                "matcher": "mcp__.*",
                "hooks": [
                    {
                        "type": "command",
                        "command": f'"{python}" -m mcpswitch.hooks post_tool_use',
                    }
                ],
            }
        ],
    }


def install_hooks(dry_run: bool = False) -> dict:
    """Install MCPSwitch hooks into ~/.claude/settings.json.

    Returns {"added": [...], "already_existed": [...], "settings_path": str}
    """
    import json as _json
    settings_path = Path.home() / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    if settings_path.exists():
        with open(settings_path, "r", encoding="utf-8") as f:
            settings = _json.load(f)
    else:
        settings = {}

    existing_hooks = settings.get("hooks", {})
    new_hooks = get_hooks_config()

    added = []
    already_existed = []

    for hook_type, hook_list in new_hooks.items():
        existing = existing_hooks.get(hook_type, [])
        # Check if mcpswitch hook already present
        already = any("mcpswitch" in str(h) for h in existing)
        if already:
            already_existed.append(hook_type)
        else:
            if not dry_run:
                existing_hooks[hook_type] = existing + hook_list
            added.append(hook_type)

    if not dry_run and added:
        settings["hooks"] = existing_hooks
        # Backup first
        if settings_path.exists():
            backup = settings_path.with_suffix(".json.bak")
            import shutil
            shutil.copy2(settings_path, backup)
        with open(settings_path, "w", encoding="utf-8") as f:
            _json.dump(settings, f, indent=2)

    return {
        "added": added,
        "already_existed": already_existed,
        "settings_path": str(settings_path),
    }


def uninstall_hooks() -> dict:
    """Remove MCPSwitch hooks from ~/.claude/settings.json."""
    import json as _json
    settings_path = Path.home() / ".claude" / "settings.json"

    if not settings_path.exists():
        return {"removed": [], "settings_path": str(settings_path)}

    with open(settings_path, "r", encoding="utf-8") as f:
        settings = _json.load(f)

    hooks = settings.get("hooks", {})
    removed = []

    for hook_type in list(hooks.keys()):
        original_count = len(hooks[hook_type])
        hooks[hook_type] = [
            h for h in hooks[hook_type]
            if "mcpswitch" not in str(h)
        ]
        if len(hooks[hook_type]) < original_count:
            removed.append(hook_type)
        if not hooks[hook_type]:
            del hooks[hook_type]

    settings["hooks"] = hooks
    with open(settings_path, "w", encoding="utf-8") as f:
        _json.dump(settings, f, indent=2)

    return {"removed": removed, "settings_path": str(settings_path)}


# Entry point when run as: python -m mcpswitch.hooks <command>
if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "pre_tool_use":
        handle_pre_tool_use()
    elif cmd == "post_tool_use":
        handle_post_tool_use()
    else:
        sys.exit(0)
