# MCPSwitch

**Smart MCP profile manager for Claude Code.**  
Stop wasting 30-40% of your context window on MCP tools you never use.

---

## The Problem

Every MCP server you install adds its tool schemas to Claude's context window at session start.  
84 tools across 6 servers = **15,540 tokens consumed before you type a single message.**  
That's up to 40% of your context window gone — every session, every time.

MCPSwitch lets you define lean profiles for different workflows and switch between them instantly.

---

## Install

```bash
pip install mcpswitch
```

Or run from source:
```bash
git clone https://github.com/sathibabu/mcpswitch
cd mcpswitch
pip install -e .
```

---

## Quick Start

```bash
# See what your current MCP config is costing you
mcpswitch analyze

# Save your current config as a profile
mcpswitch import --name full

# Create a lean profile
mcpswitch create python-backend

# Add only the servers you need for Python work
mcpswitch add python-backend github
mcpswitch add python-backend context7

# Switch to it before starting a Claude Code session
mcpswitch use python-backend

# See all profiles and their token costs
mcpswitch list
```

---

## Commands

| Command | What it does |
|---------|-------------|
| `mcpswitch status` | Show active profile + token cost of loaded servers |
| `mcpswitch analyze` | Break down token cost by server, show savings potential |
| `mcpswitch list` | List all profiles with token estimates |
| `mcpswitch use <profile>` | Switch to a profile (rewrites Claude config) |
| `mcpswitch import --name <n>` | Save current config as a named profile |
| `mcpswitch create <profile>` | Create a new empty profile |
| `mcpswitch add <profile> <server>` | Add a server to a profile |
| `mcpswitch remove <profile> <server>` | Remove a server from a profile |
| `mcpswitch save <profile>` | Save current active config as profile |
| `mcpswitch delete <profile>` | Delete a profile |

---

## Real-World Savings

| Scenario | All MCPs | Lean Profile | Saved |
|----------|----------|-------------|-------|
| Python backend work | 15,540 tokens | 3,200 tokens | 12,340 tokens (79%) |
| Frontend work | 15,540 tokens | 4,100 tokens | 11,440 tokens (74%) |
| Writing/docs | 15,540 tokens | 900 tokens | 14,640 tokens (94%) |

Fewer wasted tokens = more context for your actual code = better Claude responses.

---

## How It Works

MCPSwitch reads and writes the Claude MCP config files:
- **Claude Code CLI**: `~/.claude/claude_desktop_config.json`
- **Claude Desktop**: `~/AppData/Roaming/Claude/claude_desktop_config.json` (Windows)

Profiles are stored in `~/.mcpswitch/profiles.json`. Every config change is backed up automatically before overwriting.

---

## Pricing

- **Free**: unlimited profiles, all commands, open source
- **Pro** ($19/month): coming soon — auto-detect project type and switch profiles automatically, usage analytics, team profile sharing

---

## License

MIT
