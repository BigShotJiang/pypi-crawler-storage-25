from __future__ import annotations

"""
Build changelog.json files and generate docs pages for all repos in gitlab.toml.

Reads:
    gitlab.toml
    data/gitlab/{slug}/mrs.json
    data/gitlab/{slug}/tags.json

Writes (per repo):
    data/gitlab/{slug}/changelog.json
    docs/gitlab/{slug}/changelog.json   (copy served to browser)
    docs/gitlab/{slug}/index.md         (page with loader div)

Usage:
    python -m atlasdocs_theme.scripts.prepare_gitlab_pages [hub_dir]
    python -m atlasdocs_theme.scripts.prepare_gitlab_pages --dry-run

gitlab.toml format
------------------
    [[repos]]
    project     = "atlas/athena"
    label       = "Athena"
    tag_pattern = "release/*"    # fnmatch filter (default: all tags)
    max_releases = 50
"""

import fnmatch
import json
import re
import shutil
import sys
import tomllib
from datetime import datetime, timezone
from pathlib import Path


# ── Configuration ──────────────────────────────────────────────────────────────

GITLAB_CONFIG    = "gitlab.toml"
GITLAB_DEFAULT   = "https://gitlab.cern.ch"
PAGE_ICON        = "lucide/git-merge"
PAGE_TAGS_BASE   = ['"★ GITLAB"']


# ── Config loading ─────────────────────────────────────────────────────────────

def load_config(hub_dir: Path) -> tuple[str, list[dict]]:
    config_path = hub_dir / GITLAB_CONFIG
    if not config_path.exists():
        return GITLAB_DEFAULT, []
    with open(config_path, "rb") as f:
        data = tomllib.load(f)
    return data.get("gitlab", GITLAB_DEFAULT).rstrip("/"), data.get("repos", [])


# ── Conventional commit sorting ────────────────────────────────────────────────

# Priority order: lower index = shown first. Anything not matched = uncategorised (last).
_CC_ORDER = [
    "feat",
    "fix",
    "perf",
    "refactor",
    "docs",
    "style",
    "test",
    "build",
    "ci",
    "chore",
    "revert",
]

_CC_PATTERN = re.compile(r'^([a-z]+)(?:\([^)]*\))?!?:\s', re.IGNORECASE)


def _cc_sort_key(mr: dict) -> tuple[int, str]:
    """Return (type_rank, title) for stable conventional-commit ordering."""
    m = _CC_PATTERN.match(mr.get("title", ""))
    if m:
        cc_type = m.group(1).lower()
        rank = _CC_ORDER.index(cc_type) if cc_type in _CC_ORDER else len(_CC_ORDER)
    else:
        rank = len(_CC_ORDER)  # uncategorised
    return (rank, mr.get("title", "").lower())


def _sort_mrs(mrs: list[dict]) -> list[dict]:
    return sorted(mrs, key=_cc_sort_key)


# ── Changelog builder ──────────────────────────────────────────────────────────

def _slim_mr(mr: dict) -> dict:
    title = mr.get("title", "")
    m = _CC_PATTERN.match(title)
    cc_type = m.group(1).lower() if m else None
    return {
        "iid":           mr["iid"],
        "title":         title,
        "cc_type":       cc_type,
        "author":        (mr.get("author") or {}).get("name", ""),
        "merged_at":     (mr.get("merged_at") or "")[:10],
        "labels":        mr.get("labels") or [],
        "web_url":       mr.get("web_url", ""),
        "source_branch": mr.get("source_branch", ""),
    }


def _tag_date(tag: dict) -> str:
    return (tag.get("committed_date") or "")[:10]


def build_changelog(
    mrs: list[dict],
    tags: list[dict],
    tag_pattern: str | None,
    max_releases: int | None,
) -> list[dict]:
    merged = [mr for mr in mrs if mr.get("state") == "merged" and mr.get("merged_at")]

    filtered = tags if not tag_pattern else [t for t in tags if fnmatch.fnmatch(t["name"], tag_pattern)]
    filtered = sorted(
        [t for t in filtered if t.get("committed_date")],
        key=lambda t: t["committed_date"],
    )

    UNRELEASED = "__unreleased__"
    buckets: dict[str, list] = {UNRELEASED: []}
    for tag in filtered:
        buckets[tag["name"]] = []

    for mr in merged:
        merge_date = mr.get("merged_at", "")
        assigned   = UNRELEASED
        for tag in filtered:
            if (tag.get("committed_date") or "") >= merge_date:
                assigned = tag["name"]
                break
        buckets[assigned].append(_slim_mr(mr))

    releases: list[dict] = []

    unrel = buckets[UNRELEASED]
    if unrel:
        releases.append({"version": "Unreleased", "tag": None, "date": None, "mrs": _sort_mrs(unrel)})

    for tag in reversed(filtered):
        releases.append({
            "version": tag["name"],
            "tag":     tag["name"],
            "date":    _tag_date(tag),
            "mrs":     _sort_mrs(buckets[tag["name"]]),
        })

    if max_releases:
        releases = releases[:max_releases]

    return releases


# ── Page generator ─────────────────────────────────────────────────────────────

def _frontmatter(title: str, tags: list[str]) -> str:
    lines = [
        "---",
        f"title: {title}",
        f"icon: {PAGE_ICON}",
        "hide:",
        "  - toc",
        "pagestatus: script",
        f"dategenerated: \"{datetime.now().strftime('%Y-%m-%d')}\"",
        "tags:",
    ]
    for tag in tags:
        lines.append(f"  - {tag}")
    lines += ["---", ""]
    return "\n".join(lines)


def _generate_page(
    out_dir: Path,
    project: str,
    label: str,
    gitlab_base: str,
) -> None:
    slug = project.replace("/", "_")
    fm = _frontmatter(
        title=f'"{label} — Changelog"',
        tags=list(PAGE_TAGS_BASE) + [f'"▶ {slug}"'],
    )
    md = [
        fm,
        f'<div id="athena-changelog"',
        f'     data-json="./changelog.json"',
        f'     data-project="{project}"',
        f'     data-gitlab="{gitlab_base}"></div>',
        '<script src="/assets/javascripts/athena_changelog_loader.js"></script>',
        "",
    ]
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "index.md").write_text("\n".join(md), encoding="utf-8")


# ── Per-repo processing ────────────────────────────────────────────────────────

def process_repo(
    repo: dict,
    gitlab_base: str,
    hub_dir: Path,
    dry_run: bool = False,
) -> bool:
    project     = repo["project"]
    label       = repo.get("label", project.split("/")[-1].title())
    tag_pattern = repo.get("tag_pattern") or None
    max_rel     = repo.get("max_releases") or None
    slug        = project.replace("/", "_")

    data_dir  = hub_dir / "data" / "gitlab" / slug
    mrs_file  = data_dir / "mrs.json"
    tags_file = data_dir / "tags.json"

    if not mrs_file.exists() or not tags_file.exists():
        print(f"  SKIP {project}: data not found (run fetch-gitlab first)")
        return False

    mrs_data  = json.loads(mrs_file.read_text())
    tags_data = json.loads(tags_file.read_text())
    mrs       = mrs_data.get("mrs", [])
    tags      = tags_data.get("tags", [])

    merged_count = sum(1 for mr in mrs if mr.get("state") == "merged")
    print(f"\n── {project} ({label}) ──")
    print(f"  {len(mrs):,} MRs ({merged_count:,} merged), {len(tags):,} tags")
    if tag_pattern:
        print(f"  Tag pattern: {tag_pattern}")

    releases  = build_changelog(mrs, tags, tag_pattern=tag_pattern, max_releases=max_rel)
    total_mrs = sum(len(r["mrs"]) for r in releases)
    non_empty = sum(1 for r in releases if r["mrs"])
    print(f"  {len(releases)} releases ({non_empty} non-empty), {total_mrs:,} MRs assigned")

    if dry_run:
        for r in releases[:5]:
            n = len(r["mrs"])
            if n:
                print(f"    {r['version']:<40} {r['date'] or '—':<12} {n} MRs")
        return True

    out = {
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "project":  project,
        "releases": releases,
    }
    out_json = json.dumps(out, indent=2, ensure_ascii=False)

    # Save to data/
    changelog_data = data_dir / "changelog.json"
    changelog_data.write_text(out_json)
    print(f"  → {changelog_data}")

    # Copy to docs/ and write page
    docs_dir = hub_dir / "docs" / "gitlab" / slug
    docs_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(changelog_data, docs_dir / "changelog.json")

    _generate_page(docs_dir, project, label, gitlab_base)
    print(f"  → docs/gitlab/{slug}/index.md")

    return True


# ── Main ───────────────────────────────────────────────────────────────────────

def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Build changelogs and docs pages from fetched GitLab data.")
    parser.add_argument("hub_dir",   nargs="?", default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--project", default=None, help="Only process this project path")
    args = parser.parse_args()

    hub_dir = Path(args.hub_dir).resolve() if args.hub_dir else Path.cwd()
    gitlab_base, repos = load_config(hub_dir)

    if not repos:
        print("No repos configured in gitlab.toml.")
        return

    if args.project:
        repos = [r for r in repos if r.get("project") == args.project]
        if not repos:
            print(f"Project '{args.project}' not found in gitlab.toml.")
            return

    print(f"GitLab: {gitlab_base}  ({len(repos)} repos)")
    ok = 0
    for repo in repos:
        if process_repo(repo, gitlab_base, hub_dir, dry_run=args.dry_run):
            ok += 1

    print(f"\nDone: {ok}/{len(repos)} repos processed.")


if __name__ == "__main__":
    main()
