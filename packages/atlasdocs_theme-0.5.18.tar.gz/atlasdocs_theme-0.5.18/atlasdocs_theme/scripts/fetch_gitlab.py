from __future__ import annotations

"""
Fetch merge requests and tags from GitLab for all repos listed in gitlab.toml.

Reads:
    gitlab.toml

Writes (per repo):
    data/gitlab/{slug}/mrs.json
    data/gitlab/{slug}/tags.json

Usage:
    python -m atlasdocs_theme.scripts.fetch_gitlab [hub_dir]
    python -m atlasdocs_theme.scripts.fetch_gitlab --refresh      # ignore cache
    python -m atlasdocs_theme.scripts.fetch_gitlab --dry-run

gitlab.toml format
------------------
    # gitlab = "https://gitlab.cern.ch"   # optional, this is the default

    [[repos]]
    project     = "atlas/athena"
    label       = "Athena"
    branch      = "main"          # default MR target branch (default: main)
    since       = "-2y"           # fetch MRs created after: -Ny, -Nm, -Nd or ISO date
    tag_pattern = "release/*"     # fnmatch filter for tags (default: all tags)
    max_releases = 50             # passed to changelog builder

    [[repos]]
    project = "atlas/analysisbase"
    label   = "AnalysisBase"
    since   = "-1y"

Credentials: GITLAB_TOKEN env var or .env file in hub_dir.
"""

import json
import os
import re
import sys
import time
import tomllib
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote_plus, urlencode
from urllib.request import Request, urlopen


# ── Constants ──────────────────────────────────────────────────────────────────

GITLAB_DEFAULT  = "https://gitlab.cern.ch"
GITLAB_CONFIG   = "gitlab.toml"
PAGE_SIZE       = 100
REQUEST_DELAY   = 0.3


# ── Date helpers ───────────────────────────────────────────────────────────────

def _parse_since(s: str) -> str:
    """Parse '-2y', '-6m', '-90d' or pass through an ISO date string."""
    m = re.match(r'^-(\d+)([ymd])$', s.strip())
    if m:
        n, unit = int(m.group(1)), m.group(2)
        now = datetime.now(timezone.utc)
        if unit == 'y':   delta = timedelta(days=365 * n)
        elif unit == 'm': delta = timedelta(days=30  * n)
        else:             delta = timedelta(days=n)
        return (now - delta).strftime("%Y-%m-%dT%H:%M:%SZ")
    return s


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ── Auth ───────────────────────────────────────────────────────────────────────

def _load_token(hub_dir: Path) -> str:
    token = os.environ.get("GITLAB_TOKEN", "")
    if not token:
        env_path = hub_dir / ".env"
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                line = line.strip()
                if line.startswith("GITLAB_TOKEN="):
                    token = line.split("=", 1)[1].strip().strip('"').strip("'")
                    break
    if not token:
        print("ERROR: GITLAB_TOKEN not set. Export it or add to .env", file=sys.stderr)
        sys.exit(1)
    return token


# ── HTTP ───────────────────────────────────────────────────────────────────────

def _get(url: str, token: str, params: dict | None = None) -> tuple[list | dict, dict]:
    if params:
        url = url + "?" + urlencode(params)
    req = Request(url, headers={"PRIVATE-TOKEN": token, "Accept": "application/json"})
    with urlopen(req, timeout=30) as resp:
        body    = json.loads(resp.read().decode())
        headers = {k.lower(): v for k, v in resp.headers.items()}
    return body, headers


def _paginate(base_url: str, token: str, params: dict | None = None, label: str = "") -> list[dict]:
    params = dict(params or {})
    params["per_page"] = PAGE_SIZE
    params["page"]     = 1
    results: list[dict] = []
    total_pages = None
    while True:
        page, headers = _get(base_url, token, params)
        if not isinstance(page, list) or not page:
            break
        results.extend(page)

        tp = headers.get("x-total-pages", "").strip()
        if tp and total_pages is None:
            total_pages = int(tp)
        page_info = f"p{params['page']}" + (f"/{total_pages}" if total_pages else "")
        if label:
            print(f"\r  {label}: {page_info}  {len(results):,} items…", end="", flush=True)

        next_page = headers.get("x-next-page", "").strip()
        if next_page:
            params["page"] = int(next_page)
        elif len(page) < PAGE_SIZE:
            break
        else:
            params["page"] += 1
        time.sleep(REQUEST_DELAY)

    if label:
        print(f"\r  {label}: done — {len(results):,} items" + " " * 20)
    return results


# ── Fetchers ───────────────────────────────────────────────────────────────────

def _resolve_project(gitlab_base: str, token: str, project_path: str) -> dict:
    url    = f"{gitlab_base}/api/v4/projects/{quote_plus(project_path)}"
    meta, _ = _get(url, token)
    return meta


_MR_KEEP = {
    "iid", "title", "state", "author", "labels", "milestone",
    "created_at", "updated_at", "merged_at", "closed_at",
    "source_branch", "target_branch", "web_url",
    "merge_commit_sha", "squash_commit_sha",
}

def _fetch_mrs(
    gitlab_base: str,
    token: str,
    project_id: int,
    branch: str | None,
    since: str | None,
    created_after: str | None,
) -> list[dict]:
    base   = f"{gitlab_base}/api/v4/projects/{project_id}/merge_requests"
    params: dict = {"state": "all", "order_by": "updated_at", "sort": "desc"}
    if branch:
        params["target_branch"] = branch
    if since:
        params["updated_after"] = since
    if created_after:
        params["created_after"] = created_after
    raw = _paginate(base, token, params, label=f"MRs→{branch or 'any'}")
    results = []
    for mr in raw:
        item = {k: v for k, v in mr.items() if k in _MR_KEEP}
        if item.get("author"):
            item["author"] = {
                "name":     item["author"].get("name"),
                "username": item["author"].get("username"),
            }
        results.append(item)
    return results


def _fetch_tags(gitlab_base: str, token: str, project_id: int) -> list[dict]:
    base = f"{gitlab_base}/api/v4/projects/{project_id}/repository/tags"
    raw  = _paginate(base, token, label="tags")
    results = []
    for t in raw:
        commit = t.get("commit") or {}
        results.append({
            "name":           t["name"],
            "message":        t.get("message") or "",
            "committed_date": commit.get("committed_date") or commit.get("authored_date"),
            "commit_sha":     commit.get("id"),
        })
    return sorted(results, key=lambda t: t["committed_date"] or "", reverse=True)


# ── Cache helpers ──────────────────────────────────────────────────────────────

def _load_cache(path: Path) -> dict:
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            pass
    return {}


# ── Per-repo fetch ─────────────────────────────────────────────────────────────

def fetch_repo(
    repo: dict,
    gitlab_base: str,
    token: str,
    data_root: Path,
    refresh: bool = False,
    dry_run: bool = False,
) -> None:
    project = repo["project"]
    branch  = repo.get("branch", "main")
    since   = _parse_since(repo["since"]) if repo.get("since") else None
    slug    = project.replace("/", "_")
    out_dir = data_root / slug
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n── {project} ──")
    try:
        meta = _resolve_project(gitlab_base, token, project)
    except HTTPError as e:
        print(f"  ERROR resolving project: {e}", file=sys.stderr)
        return
    project_id = meta["id"]
    print(f"  id={project_id}  name={meta['name']}")

    # MRs
    mrs_file  = out_dir / "mrs.json"
    mrs_cache = _load_cache(mrs_file)
    since_mrs = None if refresh else mrs_cache.get("fetched_at")
    date_desc = (f" since {since_mrs[:10]}" if since_mrs else
                 f" created after {since[:10]}" if since else "")
    print(f"  Fetching MRs (target={branch}){date_desc}…")

    try:
        new_mrs = _fetch_mrs(
            gitlab_base, token, project_id,
            branch=branch,
            since=since_mrs,
            created_after=since if not since_mrs else None,
        )
    except HTTPError as e:
        print(f"  ERROR fetching MRs: {e}", file=sys.stderr)
        new_mrs = []

    if dry_run:
        print(f"  DRY RUN — {len(new_mrs)} MRs (first 5):")
        for mr in new_mrs[:5]:
            print(f"    !{mr['iid']}  {(mr.get('merged_at') or '')[:10]}  {mr['title'][:72]}")
    else:
        existing_mrs = mrs_cache.get("mrs", [])
        existing_iids = {mr["iid"] for mr in existing_mrs}
        merged_mrs = [mr for mr in new_mrs if mr["iid"] not in existing_iids] + existing_mrs
        mrs_file.write_text(json.dumps(
            {"fetched_at": _now_iso(), "project": project, "branch": branch, "mrs": merged_mrs},
            indent=2, ensure_ascii=False,
        ))
        print(f"  Saved {len(merged_mrs):,} MRs ({len(new_mrs):,} new) → {mrs_file.name}")

    # Tags
    tags_file = out_dir / "tags.json"
    print(f"  Fetching tags…")
    try:
        tags = _fetch_tags(gitlab_base, token, project_id)
    except HTTPError as e:
        print(f"  ERROR fetching tags: {e}", file=sys.stderr)
        tags = []

    if dry_run:
        print(f"  DRY RUN — {len(tags)} tags (first 10):")
        for t in tags[:10]:
            print(f"    {t['name']:<40}  {(t['committed_date'] or '')[:10]}")
    else:
        tags_file.write_text(json.dumps(
            {"fetched_at": _now_iso(), "project": project, "tags": tags},
            indent=2, ensure_ascii=False,
        ))
        print(f"  Saved {len(tags):,} tags → {tags_file.name}")


# ── Config loading ─────────────────────────────────────────────────────────────

def load_config(hub_dir: Path) -> tuple[str, list[dict]]:
    """Returns (gitlab_base, repos)."""
    config_path = hub_dir / GITLAB_CONFIG
    if not config_path.exists():
        print(f"[fetch_gitlab] {GITLAB_CONFIG} not found in {hub_dir}")
        return GITLAB_DEFAULT, []
    with open(config_path, "rb") as f:
        data = tomllib.load(f)
    gitlab_base = data.get("gitlab", GITLAB_DEFAULT).rstrip("/")
    repos = data.get("repos", [])
    return gitlab_base, repos


# ── Main ───────────────────────────────────────────────────────────────────────

def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Fetch GitLab MRs and tags for repos in gitlab.toml.")
    parser.add_argument("hub_dir",    nargs="?", default=None)
    parser.add_argument("--refresh",  action="store_true", help="Ignore cache, re-fetch all")
    parser.add_argument("--dry-run",  action="store_true", help="Fetch first page only, print, do not save")
    parser.add_argument("--project",  default=None, help="Only fetch this project (path, e.g. atlas/athena)")
    args = parser.parse_args()

    hub_dir   = Path(args.hub_dir).resolve() if args.hub_dir else Path.cwd()
    data_root = hub_dir / "data" / "gitlab"

    gitlab_base, repos = load_config(hub_dir)
    if not repos:
        print("No repos configured in gitlab.toml.")
        return

    if args.project:
        repos = [r for r in repos if r.get("project") == args.project]
        if not repos:
            print(f"Project '{args.project}' not found in gitlab.toml.")
            return

    token = _load_token(hub_dir)
    print(f"GitLab  : {gitlab_base}")
    print(f"Repos   : {len(repos)}")

    for repo in repos:
        fetch_repo(repo, gitlab_base, token, data_root, refresh=args.refresh, dry_run=args.dry_run)

    print("\nDone.")


if __name__ == "__main__":
    main()
