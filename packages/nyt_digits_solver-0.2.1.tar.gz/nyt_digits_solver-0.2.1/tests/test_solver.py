import pytest

from nyt_digits_solver.solver import Step, explore, solve


@pytest.mark.parametrize(
    "numbers,target,expected",
    [
        (
            [1, 1], 2,
            [[Step([1, 1], None), Step([2], "1+1")]],
        ),
        (
            [2, 3], 6,
            [[Step([2, 3], None), Step([6], "3*2")]],
        ),
        (
            [2, 3], 1,
            [[Step([2, 3], None), Step([1], "3-2")]],
        ),
        (
            [3, 9], 3,
            [[Step([3, 9], None), Step([3], "9/3")]],
        ),
        (
            [1, 2, 4], 12,
            [[Step([1, 2, 4], None), Step([3, 4], "2+1"), Step([12], "4*3")]],
        ),
    ]
)
def test_solve(numbers, target, expected):
    assert solve(numbers, target) == expected


@pytest.mark.parametrize(
    "numbers,expected",
    [
        (
            [1, 2],
            {
                3: [Step([1, 2], None), Step([3], "2+1")],
                1: [Step([1, 2], None), Step([1], "2-1")],
                2: [Step([1, 2], None), Step([2], "2*1")],
            },
        ),
        (
            [2, 3],
            {
                5: [Step([2, 3], None), Step([5], "3+2")],
                1: [Step([2, 3], None), Step([1], "3-2")],
                6: [Step([2, 3], None), Step([6], "3*2")],
            },
        ),
    ]
)
def test_explore_exact(numbers, expected):
    assert explore(numbers) == expected


def test_explore_contains_target():
    assert 12 in explore([1, 2, 4])


def test_explore_multistep():
    result = explore([1, 2, 3])
    assert result.keys() >= {1, 2, 3, 4, 5, 6, 7, 8, 9}
