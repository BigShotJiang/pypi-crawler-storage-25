"""
Framework-specific middleware and callbacks.
"""
import logging
from typing import Any, Optional

logger = logging.getLogger("veritasagent")


class VeritasLangChainCallback:
    """
    LangChain callback handler for automatic VeritasAgent tracking.

    Usage:
        from veritasagent import VeritasClient, VeritasLangChainCallback

        client = VeritasClient(agent_id="my-langchain-agent")
        callback = VeritasLangChainCallback(client)

        llm = ChatOpenAI(callbacks=[callback])
    """

    def __init__(self, client):
        self.client = client

    def on_llm_start(self, serialized: dict, prompts: list, **kwargs):
        """Called when LLM starts generating."""
        pass  # We track on completion, not start

    def on_llm_end(self, response, **kwargs):
        """Called when LLM finishes generating."""
        try:
            model = getattr(response, 'llm_output', {}).get('model_name', 'unknown') if hasattr(response, 'llm_output') and response.llm_output else 'unknown'
            token_usage = getattr(response, 'llm_output', {}).get('token_usage', {}) if hasattr(response, 'llm_output') and response.llm_output else {}
            token_count = token_usage.get('total_tokens', 0) if isinstance(token_usage, dict) else 0

            text = ""
            if hasattr(response, 'generations') and response.generations:
                for gen_list in response.generations:
                    for gen in gen_list:
                        text += getattr(gen, 'text', '')

            self.client.track_llm(
                model=model,
                response=text[:500],
                token_count=token_count,
            )
        except Exception as e:
            logger.debug(f"VeritasAgent LangChain callback error: {e}")

    def on_tool_start(self, serialized: dict, input_str: str, **kwargs):
        """Called when a tool starts executing."""
        pass

    def on_tool_end(self, output: str, **kwargs):
        """Called when a tool finishes executing."""
        try:
            tool_name = kwargs.get('name', 'unknown_tool')
            self.client.track_tool(tool_name=tool_name, result=output[:500])
        except Exception as e:
            logger.debug(f"VeritasAgent tool callback error: {e}")

    def on_chain_start(self, serialized: dict, inputs: dict, **kwargs):
        pass

    def on_chain_end(self, outputs: dict, **kwargs):
        pass

    def on_llm_error(self, error: Exception, **kwargs):
        pass

    def on_tool_error(self, error: Exception, **kwargs):
        pass

    def on_chain_error(self, error: Exception, **kwargs):
        pass


class VeritasOpenAIWrapper:
    """
    Wrapper for OpenAI client that automatically tracks calls.

    Usage:
        from openai import OpenAI
        from veritasagent import VeritasClient, VeritasOpenAIWrapper

        client = VeritasClient(agent_id="my-openai-agent")
        openai_client = VeritasOpenAIWrapper(OpenAI(), client)

        response = openai_client.chat("gpt-4o", [{"role": "user", "content": "Hello"}])
    """

    def __init__(self, openai_client, veritas_client):
        self._openai = openai_client
        self._veritas = veritas_client

    def chat(self, model: str, messages: list, **kwargs):
        """Tracked chat completion."""
        prompt_str = str(messages)
        response = self._openai.chat.completions.create(
            model=model,
            messages=messages,
            **kwargs,
        )

        token_count = 0
        cost_usd = 0.0
        response_text = ""

        if hasattr(response, 'usage') and response.usage:
            token_count = response.usage.total_tokens or 0

        if hasattr(response, 'choices') and response.choices:
            response_text = response.choices[0].message.content or ""

        self._veritas.track_llm(
            model=model,
            prompt=prompt_str,
            response=response_text,
            token_count=token_count,
            cost_usd=cost_usd,
            provider="openai",
        )

        return response
