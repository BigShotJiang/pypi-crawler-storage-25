"""
Core VeritasAgent SDK client.
Sends audit events to the VeritasAgent platform.
"""
import hashlib
import json
import logging
import os
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Optional, Any
from uuid import uuid4

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

logger = logging.getLogger("veritasagent")


class VeritasClient:
    """
    Client for sending audit telemetry to VeritasAgent.

    Usage:
        client = VeritasClient(
            endpoint="http://localhost:8000",
            agent_id="my-research-bot",
            api_key="vk_abc123",  # optional
        )

        # Send an event
        client.emit_event(
            event_type="LLM_INFERENCE_CALL",
            model_name="gpt-4o",
            token_count=1500,
            prompt_hash=client.hash_content("What is the weather?"),
        )
    """

    def __init__(
        self,
        endpoint: str = None,
        agent_id: str = None,
        api_key: str = None,
        session_id: str = None,
        parent_agent_id: str = None,
        container_image_hash: str = None,
        async_mode: bool = False,
        batch_size: int = 10,
        flush_interval: float = 5.0,
    ):
        self.endpoint = (endpoint or os.environ.get("VERITAS_ENDPOINT", "http://localhost:8000")).rstrip("/")
        self.agent_id = agent_id or os.environ.get("VERITAS_AGENT_ID", f"agent-{uuid4().hex[:8]}")
        self.api_key = api_key or os.environ.get("VERITAS_API_KEY", "")
        self.session_id = session_id or uuid4().hex[:16]
        self.parent_agent_id = parent_agent_id or os.environ.get("VERITAS_PARENT_AGENT_ID")
        self.container_image_hash = container_image_hash or os.environ.get("VERITAS_IMAGE_HASH")
        self.async_mode = async_mode
        self._batch: list[dict] = []
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._last_flush = time.time()
        self._invocation_depth = 0

        if not HAS_HTTPX:
            logger.warning("httpx not installed. Install with: pip install veritasagent-sdk")

    @property
    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def emit_event(
        self,
        event_type: str,
        destination_host: str = None,
        destination_port: int = 0,
        destination_service: str = None,
        file_path: str = None,
        process_name: str = None,
        process_cmdline: str = None,
        model_name: str = "",
        token_count: int = 0,
        prompt_hash: str = None,
        response_hash: str = None,
        details: dict = None,
        cost_usd: float = 0.0,
    ) -> Optional[dict]:
        """
        Emit a single audit event to VeritasAgent.

        Args:
            event_type: One of LLM_INFERENCE_CALL, TOOL_INVOCATION, FILE_READ, FILE_WRITE,
                       PROCESS_SPAWN, NETWORK_CONNECT, NETWORK_SEND, DNS_LOOKUP,
                       CREDENTIAL_ACCESS, MCP_TOOL_CALL, MCP_RESOURCE_ACCESS
            destination_host: Target hostname or IP
            destination_port: Target port number
            destination_service: Service name (e.g., "OpenAI API")
            file_path: File being accessed (for FILE_READ/FILE_WRITE)
            process_name: Process name (defaults to 'python')
            process_cmdline: Full command line
            model_name: LLM model name (for LLM_INFERENCE_CALL)
            token_count: Number of tokens used
            prompt_hash: SHA-256 hash of the prompt (opt-in privacy)
            response_hash: SHA-256 hash of the response
            details: Additional key-value metadata
            cost_usd: Cost in USD for this operation

        Returns:
            Server response dict, or None if async/batched
        """
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "rule": f"SDK:{event_type}",
            "output": f"Agent {self.agent_id} performed {event_type}",
            "priority": "NOTICE",
            "source": "veritasagent-sdk",
            "fields": {
                "agent_id": self.agent_id,
                "session_id": self.session_id,
                "proc_name": process_name or "python",
                "proc_cmdline": process_cmdline or "",
                "fd_name": "",
                "fd_dip": destination_host or "",
                "fd_dport": str(destination_port),
                "fd_dhost": destination_host or "",
                "fd_service": destination_service or "",
                "file_path": file_path or "",
                "model_name": model_name,
                "token_count": str(token_count),
                "cost_usd": str(cost_usd),
                "prompt_hash": prompt_hash or "",
                "response_hash": response_hash or "",
                "parent_agent_id": self.parent_agent_id or "",
                "session_graph_id": self.session_id,
                "invocation_depth": str(self._invocation_depth),
                "container_image_hash": self.container_image_hash or "",
                **(details or {}),
            },
        }

        if self.async_mode:
            self._batch.append(event)
            if len(self._batch) >= self._batch_size or (time.time() - self._last_flush) > self._flush_interval:
                return self.flush()
            return None
        else:
            return self._send_event(event)

    def _send_event(self, event: dict) -> Optional[dict]:
        """Send a single event to the ingest API."""
        if not HAS_HTTPX:
            logger.error("httpx required. pip install httpx")
            return None
        try:
            with httpx.Client(timeout=5.0) as client:
                resp = client.post(
                    f"{self.endpoint}/api/v1/events/ingest",
                    headers=self._headers,
                    json=event,
                )
                if resp.status_code == 200:
                    return resp.json()
                else:
                    logger.warning(f"VeritasAgent ingest failed: {resp.status_code} {resp.text}")
                    return None
        except Exception as e:
            logger.error(f"VeritasAgent send error: {e}")
            return None

    def flush(self) -> Optional[dict]:
        """Flush batched events."""
        if not self._batch:
            return None
        if not HAS_HTTPX:
            self._batch.clear()
            return None
        try:
            with httpx.Client(timeout=10.0) as client:
                resp = client.post(
                    f"{self.endpoint}/api/v1/events/ingest/bulk",
                    headers=self._headers,
                    json={"events": self._batch},
                )
                self._batch.clear()
                self._last_flush = time.time()
                return resp.json() if resp.status_code == 200 else None
        except Exception as e:
            logger.error(f"VeritasAgent flush error: {e}")
            return None

    @contextmanager
    def track(self, event_type: str, **kwargs):
        """
        Context manager for tracking an operation.

        Usage:
            with client.track("TOOL_INVOCATION", destination_service="GitHub API"):
                result = github.search(query)
        """
        start = time.time()
        self._invocation_depth += 1
        try:
            yield
        finally:
            duration_ms = (time.time() - start) * 1000
            self._invocation_depth -= 1
            kwargs.setdefault("details", {})
            kwargs["details"]["duration_ms"] = round(duration_ms, 2)
            self.emit_event(event_type=event_type, **kwargs)

    def track_llm(
        self,
        model: str,
        prompt: str = None,
        response: str = None,
        token_count: int = 0,
        cost_usd: float = 0.0,
        provider: str = None,
    ) -> Optional[dict]:
        """
        Track an LLM inference call.

        Args:
            model: Model name (e.g., "gpt-4o", "claude-3.5-sonnet")
            prompt: The prompt text (hashed, never stored raw)
            response: The response text (hashed, never stored raw)
            token_count: Total tokens used
            cost_usd: Cost in USD
            provider: Provider name for service fingerprinting
        """
        prompt_hash = self.hash_content(prompt) if prompt else None
        response_hash = self.hash_content(response) if response else None

        provider_hosts = {
            "openai": "api.openai.com",
            "anthropic": "api.anthropic.com",
            "google": "generativelanguage.googleapis.com",
            "cohere": "api.cohere.ai",
            "mistral": "api.mistral.ai",
        }
        host = provider_hosts.get((provider or "").lower(), provider or "api.openai.com")

        return self.emit_event(
            event_type="LLM_INFERENCE_CALL",
            destination_host=host,
            destination_port=443,
            destination_service=f"{provider or 'LLM'} API",
            model_name=model,
            token_count=token_count,
            cost_usd=cost_usd,
            prompt_hash=prompt_hash,
            response_hash=response_hash,
        )

    def track_tool(
        self,
        tool_name: str,
        tool_input: dict = None,
        result: Any = None,
        host: str = None,
    ) -> Optional[dict]:
        """Track a tool invocation."""
        return self.emit_event(
            event_type="TOOL_INVOCATION",
            destination_host=host or "localhost",
            destination_service=tool_name,
            details={
                "tool_name": tool_name,
                "input_hash": self.hash_content(json.dumps(tool_input)) if tool_input else "",
                "result_hash": self.hash_content(str(result)) if result else "",
            },
        )

    def track_mcp(
        self,
        server_name: str,
        tool_name: str,
        arguments: dict = None,
    ) -> Optional[dict]:
        """Track an MCP (Model Context Protocol) tool call."""
        return self.emit_event(
            event_type="MCP_TOOL_CALL",
            destination_service=f"MCP:{server_name}",
            destination_host="localhost",
            details={
                "mcp_server": server_name,
                "mcp_tool": tool_name,
                "args_hash": self.hash_content(json.dumps(arguments)) if arguments else "",
            },
        )

    def child_client(self, child_agent_id: str) -> "VeritasClient":
        """
        Create a child client for multi-agent tracing.

        Usage:
            parent = VeritasClient(agent_id="orchestrator")
            child = parent.child_client("research-sub-agent")
            child.track_llm(model="gpt-4o", prompt="Find papers on X")
        """
        return VeritasClient(
            endpoint=self.endpoint,
            agent_id=child_agent_id,
            api_key=self.api_key,
            session_id=self.session_id,
            parent_agent_id=self.agent_id,
            container_image_hash=self.container_image_hash,
        )

    @staticmethod
    def hash_content(content: str) -> str:
        """SHA-256 hash of content. Used for prompt/response privacy."""
        if not content:
            return ""
        return hashlib.sha256(content.encode()).hexdigest()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.flush()

    def __repr__(self):
        return f"VeritasClient(endpoint={self.endpoint!r}, agent_id={self.agent_id!r})"
