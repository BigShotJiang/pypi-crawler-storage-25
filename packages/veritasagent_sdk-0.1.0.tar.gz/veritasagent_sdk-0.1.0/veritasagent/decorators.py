"""
Decorator-based tracking for common AI agent operations.
"""
import functools
import time
from typing import Optional, Callable


def track_llm_call(client, model: str = None, provider: str = None):
    """
    Decorator to track LLM calls.

    Usage:
        @track_llm_call(client, model="gpt-4o", provider="openai")
        def generate(prompt):
            return openai.chat(prompt)
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start = time.time()
            prompt = args[0] if args else kwargs.get("prompt", kwargs.get("messages", ""))
            prompt_str = str(prompt)

            result = func(*args, **kwargs)

            duration_ms = (time.time() - start) * 1000
            response_str = str(result)

            # Try to extract token count from response
            token_count = 0
            if hasattr(result, 'usage'):
                token_count = getattr(result.usage, 'total_tokens', 0)

            client.track_llm(
                model=model or "unknown",
                prompt=prompt_str,
                response=response_str,
                token_count=token_count,
                provider=provider,
            )
            return result
        return wrapper
    return decorator


def track_tool_use(client, tool_name: str = None):
    """
    Decorator to track tool/function invocations.

    Usage:
        @track_tool_use(client, tool_name="web_search")
        def search(query):
            return requests.get(f"https://api.search.com?q={query}")
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            name = tool_name or func.__name__
            result = func(*args, **kwargs)
            client.track_tool(
                tool_name=name,
                tool_input={"args": str(args)[:200], "kwargs": {k: str(v)[:100] for k, v in kwargs.items()}},
                result=result,
            )
            return result
        return wrapper
    return decorator


def track_file_access(client, operation: str = "READ"):
    """
    Decorator to track file read/write operations.

    Usage:
        @track_file_access(client, operation="WRITE")
        def save_results(path, data):
            with open(path, 'w') as f:
                f.write(data)
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            file_path = args[0] if args else kwargs.get("path", kwargs.get("file_path", "unknown"))
            result = func(*args, **kwargs)
            client.emit_event(
                event_type=f"FILE_{operation.upper()}",
                file_path=str(file_path),
            )
            return result
        return wrapper
    return decorator
