# VeritasAgent SDK

Tamper-proof audit telemetry for AI agents.

## Install

```bash
pip install veritasagent-sdk
```

## Quick Start

```python
from veritasagent import VeritasClient

client = VeritasClient(
    endpoint="http://localhost:8000",
    agent_id="my-research-bot",
)

# Track an LLM call
client.track_llm(
    model="gpt-4o",
    prompt="What is quantum computing?",
    response="Quantum computing uses...",
    token_count=1500,
)

# Track a tool invocation
client.track_tool(tool_name="web_search", tool_input={"query": "AI safety"})

# Track an MCP tool call
client.track_mcp(server_name="filesystem", tool_name="read_file", arguments={"path": "/data/input.csv"})

# Multi-agent tracing
child = client.child_client("sub-agent-analyzer")
child.track_llm(model="claude-3.5-sonnet", prompt="Analyze this data...")
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `VERITAS_ENDPOINT` | VeritasAgent API URL (default: `http://localhost:8000`) |
| `VERITAS_AGENT_ID` | Agent identifier |
| `VERITAS_API_KEY` | API key for authentication |
| `VERITAS_PARENT_AGENT_ID` | Parent agent ID for multi-agent tracing |
| `VERITAS_IMAGE_HASH` | Container image hash for version tracking |

## LangChain Integration

```python
from veritasagent import VeritasClient, VeritasLangChainCallback
from langchain_openai import ChatOpenAI

client = VeritasClient(agent_id="langchain-agent")
llm = ChatOpenAI(model="gpt-4o", callbacks=[VeritasLangChainCallback(client)])
```

## OpenAI Wrapper

```python
from openai import OpenAI
from veritasagent import VeritasClient, VeritasOpenAIWrapper

client = VeritasClient(agent_id="openai-agent")
ai = VeritasOpenAIWrapper(OpenAI(), client)
response = ai.chat("gpt-4o", [{"role": "user", "content": "Hello"}])
```
