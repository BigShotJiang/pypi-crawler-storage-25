"""Shared fixtures, configuration, helpers, and data for live provider tests."""

from __future__ import annotations

# standard
import base64
import json
from collections.abc import Callable
from dataclasses import asdict
from enum import Enum
from pathlib import Path

# third party
# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.types import (
    FileAttachment,
    Message,
    Response,
    Role,
    StopReason,
    Tool,
    ToolCall,
)

# ---------------------------------------------------------------------------
# Engine matrix configuration
# ---------------------------------------------------------------------------

# Main test matrix — all scenario + TOOL_CALL_RESULT + image attachment tests.
# All engines are called with reasoning_effort=None (default). always-reasoning
# models must use their non-reasoning variant here to avoid model-name mismatches
# in response assertions (grok-4-1-fast auto-routes to grok-4-1-fast-reasoning).
ENGINES: list[tuple[str, str]] = [
    ("anthropic", "claude-haiku-4-5"),
    ("deepseek", "deepseek-chat"),
    ("google", "gemini-3.1-flash-lite-preview"),
    ("moonshot", "kimi-k2.5"),
    ("openai", "gpt-5.4-nano"),
    ("xai", "grok-4-1-fast-non-reasoning"),
]

# Vision-capable subset of ENGINES (deepseek-chat has supports_vision=False).
VISION_ENGINES: list[tuple[str, str]] = [e for e in ENGINES if e[1] != "deepseek-chat"]

# Cheapest models per provider for prompt-caching verification.
# All engines run with reasoning_effort=None (default) so no thinking block is
# sent, which allows normal prompt-cache behavior on all providers.
# Google/xAI: caching is implicit / undocumented; the test only asserts
#   cache_read_tokens >= 0 (request succeeds), not that there was a hit.
CACHE_ENGINES: list[tuple[str, str]] = [
    ("anthropic", "claude-haiku-4-5"),
    ("openai", "gpt-5.4-nano"),
    ("google", "gemini-3.1-flash-lite-preview"),
    ("xai", "grok-4-1-fast-non-reasoning"),
]

# Providers known to reliably report cache_read_tokens > 0 on a warm cache.
STRICT_CACHE_PROVIDERS: set[str] = {"anthropic", "openai", "xai"}

# Models used in the three-provider chain test (turn order: index 0 → 1 → 2).
THREE_CHAIN_PROVIDERS: list[tuple[str, str]] = [
    ("openai", "gpt-5-nano"),
    ("anthropic", "claude-haiku-4-5"),
    ("google", "gemini-3.1-flash-lite-preview"),
]

# ---------------------------------------------------------------------------
# Shared test data
# ---------------------------------------------------------------------------

# 32×32 solid-red PNG — meets xAI's 512-pixel minimum and all other providers' size floors.
_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAKElEQVR4nO3NsQ0AAAzCMP5/un0CNkuZ41wybXsHAAAAAAAAAAAAxR4yw/wuPL6QkAAAAABJRU5ErkJggg=="
)

# Static system prompt used for caching tests. Repeated to exceed the per-provider
# minimum cacheable block size:
#   - claude-haiku-4-5: 4,096 tokens  ← binding constraint
#   - claude-sonnet-4-6: 2,048 tokens
#   - openai (gpt-*): 1,024 tokens
# Each copy is ~1,067 tokens; ×4 ≈ 4,270 tokens, clearing the haiku threshold.
_STATIC_SYSTEM = """\
# ECOSYSTEM

SUNWAEE organizes all user data in a two-level hierarchy: Workspace → Project → {Chats, Notes, Tasks, Files}.

- Workspace: top-level container (e.g. "Personal", "Work"). Every user has a permanent "Personal" workspace.
- Project: optional sub-container within a workspace.

Object types:
- Chat: a conversation thread.
- Job: a completed AI turn (request + response cycle). Read-only.
- Note: free-form document (title + markdown body).
- Task: actionable item with status (todo/in_progress/done), priority (low/medium/high).
- File: virtual filesystem entry.
- Log: append-only activity history. Read-only.

Scope defaults: for create, list, and search operations pass the current workspace_id and project_id explicitly.

# AEGIS

When Aegis is enabled, sensitive values are replaced with typed placeholders (e.g. %%EMAIL_1%%, %%API_KEY_1%%).
Treat each placeholder as a stand-in for a real value. Never invent the underlying value.
Reference placeholders by name when needed. If a task requires the real value, tell the user.

# GUIDELINES

- Be concise; match response length to question complexity; no preamble or filler.
- Think and respond in the user's language.
- Use clean markdown.
- Do not introduce yourself unless asked; if asked: state name and current engine.
- Infer, don't interrogate: infer parameters from context; ask only when genuinely ambiguous.
- No IDs in responses: never show UUIDs; always refer to objects by name or title.
- No tool narration: don't say "I'll search your notes..."; act silently and present results naturally.
- Translate errors: never surface raw tool error messages; explain in plain language.
- Confirmation pattern: create → just do it and briefly confirm; update → state what's changing before acting.
- No delete: you cannot delete any object; suggest alternatives.
- Deliverable-first: when output is a document or script, produce the actual thing.

# VOICE

Be direct, capable, and unsentimental. Produce output, not commentary.
No "Certainly!", no "Great question!", no "I'd be happy to help."

# FORMATTING

- Inline math: use $...$
- Display math: use $$...$$
- Never use \\( \\) or \\[ \\] for inline/display math.
- Diagrams: use mermaid code fences — the UI renders them as SVG.
- Tool results: use a markdown table when presenting multiple items with several attributes.

# TOOLS

## Fetch Before Responding

When a query touches personal data, retrieve context before formulating a response.
Fetch triggers: possessive queries ("my tasks", "my notes"), status queries, history queries, continuation.
Pattern: list or search to find candidates → read only specific items → respond with current data.
Batch related fetches in the same turn rather than doing sequential round-trips.

## Limits

All list and search actions: default limit 25, maximum 100.
If results are truncated, the response includes {"_more": true, "hint": "..."}.
Re-call with a higher limit (up to 100) before responding.

## Note

- list/search to find notes; read only specific items needed.
- create/update only when explicitly requested; always pass workspace_id.
- Prefer over task for reference material, drafts, and long-form content.

## Task

- list excludes done tasks by default; use status_filter="done" to opt in.
- create/update only when explicitly requested; always pass workspace_id.
- Infer title, priority, and due date from context.
- Use ISO 8601 for all date fields; always include the UTC offset.
- Completing a recurring task auto-spawns the next instance.

## File

- list/search/read: call to answer questions about the user's files.
- create: text content only — use for scripts, documents, reports, and plans you generate.
- update: replaces full content — read first if you need to preserve existing text.

## Chat

- update: pass the current chat ID as id; can update title, workspace_id, and project_id.
- list/search/read: call when the user asks about other chats or past conversations.

## Workspace / Project

- Call only when explicitly requested, or to resolve a name to an ID.
- Never autonomously create a workspace or project mid-conversation.
- Personal workspace cannot be renamed or deleted.
""" * 4

TOOLS: list[Tool] = [
    Tool(
        name="update_chat",
        description="Update the current chat title.",
        parameters={
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "The new chat title."},
            },
            "required": ["title"],
        },
        fn=lambda title: json.dumps({"before": "New Chat", "after": title}),
    ),
]

_TOOL_FNS: dict[str, Callable] = {t.name: t.fn for t in TOOLS if t.fn}

SCENARIOS: dict[str, list[Message]] = {
    "ONLY_SYSTEM": [
        Message(role=Role.SYSTEM, content="Respond with 'ok'."),
    ],
    "ONLY_USER": [
        Message(role=Role.USER, content="Respond with 'ok'."),
    ],
    "SYSTEM_AND_USER": [
        Message(role=Role.SYSTEM, content="Start all your answers with <START>."),
        Message(role=Role.USER, content="Respond with 'ok'."),
    ],
    "TOOL_CALL": [
        Message(role=Role.USER, content="Update this chat name to 'Test Chat'."),
    ],
    "FILE_ATTACHMENT": [
        Message(
            role=Role.USER,
            content="What is the magic word in the attached file? Reply with only that word.",
            attachments=[
                FileAttachment(
                    data=b"The magic word is SUNWAEE.",
                    filename="secret.txt",
                )
            ],
        )
    ],
    "CONTEXT_ROLE": [
        Message(role=Role.SYSTEM, content="You are Sun, a helpful AI assistant."),
        Message(
            role=Role.CONTEXT,
            content=(
                "Current date: 2026-01-01\n" "Current engine: test-model\n" 'Current chat: abc123 "Test Chat"\n' 'Current workspace: ws1 "Personal"'
            ),
        ),
        Message(role=Role.USER, content="Respond with 'ok'."),
    ],
}

_TOOL_SCENARIOS = {"TOOL_CALL"}
SCENARIO_NAMES = list(SCENARIOS.keys())

RUN_DIR = Path(__file__).parent / "run"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _execute_tool(name: str, arguments: dict) -> str:
    fn = _TOOL_FNS.get(name)
    return fn(**arguments) if fn else json.dumps({"error": f"unknown tool: {name}"})


def _to_dict(obj):  # type: ignore[return]
    """Recursively convert dataclasses / Enums to plain JSON-serialisable types."""
    if hasattr(obj, "__dataclass_fields__"):
        return {k: _to_dict(v) for k, v in asdict(obj).items()}
    if isinstance(obj, list):
        return [_to_dict(i) for i in obj]
    if isinstance(obj, Enum):
        return obj.value
    return obj


def _save(data: dict, name: str) -> None:
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    safe = name.replace("/", "-")
    (RUN_DIR / f"{safe}.json").write_text(json.dumps(data, indent=2))


def _key_for(provider: str) -> str:
    return f"{provider.upper()}_API_KEY"


def _assert_base_fields(r: Response, *, streaming: bool) -> None:
    assert r.provider, "provider must be non-empty"
    assert r.model, "model must be non-empty"
    assert r.streaming is streaming, f"expected streaming={streaming}"
    assert r.synthetic is False
    assert r.error is None, f"unexpected error: {r.error}"
    assert r.stop_reason is not None, "stop_reason must be set on the final response"


def _assert_usage_cost_perf(r: Response) -> None:
    assert r.usage is not None, "usage must be set"
    assert r.usage.input_tokens > 0, "input_tokens must be > 0"
    assert r.usage.output_tokens > 0, "output_tokens must be > 0"
    assert r.usage.total_tokens > 0, "total_tokens must be > 0"

    assert r.performance is not None, "performance must be set"
    assert r.performance.total_duration > 0, "total_duration must be > 0"
    assert r.performance.throughput > 0, "throughput must be > 0"

    assert r.cost is not None, "cost must be set — engine did not call compute_cost()"
    assert r.cost.input >= 0, "cost.input must be >= 0"
    assert r.cost.output >= 0, "cost.output must be >= 0"
    assert r.cost.total > 0, "cost.total must be > 0"


def _assert_final_response(r: Response, *, streaming: bool, scenario_name: str) -> None:
    if scenario_name == "ONLY_SYSTEM":
        assert r.provider, "provider must be non-empty"
        assert r.model, "model must be non-empty"
        return

    _assert_base_fields(r, streaming=streaming)
    _assert_usage_cost_perf(r)

    if scenario_name in ("ONLY_USER", "SYSTEM_AND_USER", "FILE_ATTACHMENT", "CONTEXT_ROLE"):
        assert r.stop_reason == StopReason.END_TURN, f"expected END_TURN, got {r.stop_reason}"
        if not streaming:
            assert r.content, "content must be non-empty for a text reply"
            assert r.tool_calls is None, "tool_calls must be None when no tools given"

    elif scenario_name == "TOOL_CALL":
        assert r.stop_reason == StopReason.TOOL_USE, f"expected TOOL_USE, got {r.stop_reason}"
        if not streaming:
            assert r.tool_calls, "tool_calls must be populated for TOOL_CALL scenario"
            call = r.tool_calls[0]
            assert call.name == "update_chat", f"unexpected tool name: {call.name!r}"
            assert call.arguments.get("title") == "Test Chat", f"unexpected title argument: {call.arguments!r}"

    elif scenario_name == "TOOL_CALL_RESULT":
        assert r.stop_reason == StopReason.END_TURN, f"expected END_TURN, got {r.stop_reason}"
        if not streaming:
            assert r.content, "content must be non-empty after tool result"


def _assert_content_chunk(r: Response) -> None:
    assert r.provider, "provider must be non-empty"
    assert r.model, "model must be non-empty"
    assert r.streaming is True
    assert r.stop_reason is None, "intermediate chunks must not carry stop_reason"
    assert r.cost is None
    assert r.usage is None
    assert r.performance is None


def _collect_stream(chunks: list[Response]) -> tuple[str, str, list[ToolCall]]:
    content = "".join(c.content or "" for c in chunks if c.stop_reason is None and not c.synthetic)
    reasoning = "".join(c.reasoning_content or "" for c in chunks if c.stop_reason is None and not c.synthetic)
    tool_calls = [tc for c in chunks if c.tool_calls for tc in c.tool_calls]
    return content, reasoning, tool_calls


async def _run_full_turn(
    provider: str,
    model: str,
    history: list[Message],
) -> tuple[list[Message], Response]:
    """Run one complete agentic turn for a provider (reasoning_effort=None).

    Loops until END_TURN (or MAX_TOKENS), executing tool calls inline.
    Returns the updated history (all intermediate + final messages appended)
    and the terminal Response.
    """
    messages = list(history)
    engine = get_engine(provider, model, reasoning_effort=None)

    for _ in range(10):
        response = await engine.chat(messages, tools=TOOLS)

        if response.stop_reason == StopReason.TOOL_USE and response.tool_calls:
            assistant_msg = Message(
                role=Role.ASSISTANT,
                content=response.content,
                reasoning_content=response.reasoning_content,
                reasoning_signature=response.reasoning_signature,
                tool_calls=response.tool_calls,
            )
            tool_msgs = [
                Message(
                    role=Role.TOOL,
                    content=_execute_tool(tc.name, tc.arguments),
                    tool_call_id=tc.id,
                )
                for tc in response.tool_calls
            ]
            messages += [assistant_msg] + tool_msgs
        else:
            messages.append(Message(role=Role.ASSISTANT, content=response.content))
            return messages, response

    raise AssertionError(f"{provider}/{model}: turn did not finish within 10 iterations")


def _assert_tool_was_called(history: list[Message], expected_title: str) -> None:
    tool_msgs = [m for m in history if m.role == Role.TOOL]
    assert tool_msgs, "no tool messages found in history"
    last_result = json.loads(tool_msgs[-1].content or "{}")
    assert last_result.get("after") == expected_title, f"expected tool to set title to {expected_title!r}, got {last_result!r}"
