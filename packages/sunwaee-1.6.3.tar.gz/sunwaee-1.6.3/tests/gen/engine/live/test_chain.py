"""Live integration tests — three-provider conversation chain.

Each provider completes its ENTIRE turn (including any tool calls), appends a
final assistant message to the shared history, then hands off to the next
provider. The next provider sees the full accumulated history — including tool
call IDs, reasoning fields, and thought signatures from prior providers — and
must accept it without translation errors.

Run:
    pytest -m live tests/gen/engine/live/test_chain.py
"""

from __future__ import annotations

# standard
import os

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.types import Message, Role

from ._shared import (
    THREE_CHAIN_PROVIDERS,
    _assert_tool_was_called,
    _assert_usage_cost_perf,
    _key_for,
    _run_full_turn,
    _save,
    _to_dict,
)


@pytest.mark.live
async def test_chat_three_provider_chain() -> None:
    """Three providers each complete a full tool-call turn in one shared chat.

    Turn 1 — providers[0]: renames chat to '{provider} Chat'
    Turn 2 — providers[1]: sees [0]'s history, renames to its own name
    Turn 3 — providers[2]: sees full history, renames to its own name

    Each provider must call update_chat with the correct title and accept the
    accumulated history built by all preceding providers.
    """
    for provider, _ in THREE_CHAIN_PROVIDERS:
        if not os.environ.get(_key_for(provider)):
            pytest.skip(f"{_key_for(provider)} not set")

    (p1, m1), (p2, m2), (p3, m3) = THREE_CHAIN_PROVIDERS
    name1 = f"{p1.capitalize()} Chat"
    name2 = f"{p2.capitalize()} Chat"
    name3 = f"{p3.capitalize()} Chat"

    history: list[Message] = [
        Message(role=Role.USER, content=f"Rename this chat to '{name1}'."),
    ]

    history, r1 = await _run_full_turn(p1, m1, history)
    assert r1.stop_reason.value == "end_turn", f"turn1/{p1}: {r1.stop_reason}"
    assert r1.content
    _assert_tool_was_called(history, name1)
    _assert_usage_cost_perf(r1)

    history.append(Message(role=Role.USER, content=f"Now rename it to '{name2}'."))
    history, r2 = await _run_full_turn(p2, m2, history)
    assert r2.stop_reason.value == "end_turn", f"turn2/{p2}: {r2.stop_reason}"
    assert r2.content
    _assert_tool_was_called(history, name2)
    _assert_usage_cost_perf(r2)

    history.append(Message(role=Role.USER, content=f"Now rename it to '{name3}'."))
    history, r3 = await _run_full_turn(p3, m3, history)
    assert r3.stop_reason.value == "end_turn", f"turn3/{p3}: {r3.stop_reason}"
    assert r3.content
    _assert_tool_was_called(history, name3)
    _assert_usage_cost_perf(r3)

    _save(
        {
            f"turn1_{p1}": _to_dict(r1),
            f"turn2_{p2}": _to_dict(r2),
            f"turn3_{p3}": _to_dict(r3),
            "history_length": len(history),
        },
        "three_provider_chain_chat",
    )
