"""Live integration tests — reasoning ON / OFF per model.

Tests each reasoning-capable model with a valid reasoning_effort for ON and
reasoning_effort=None for OFF, verifying:
  - ON:  response is valid; raw-token budget/always models populate
         reasoning_content (effort/adaptive models may skip thinking on trivial
         prompts — not asserted).
  - OFF: response is valid; always-reasoning models with a non_reasoning_id
         swap to it; dynamic models produce no reasoning content (the factory
         coerces None → "off" for models with a reasoning_disabled_payload
         like kimi-k2.5, so the disabled payload merges).

One model is chosen per reasoning category to keep API spend low.
"""

from __future__ import annotations

# standard
import os

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.models import get_model
from sunwaee.modules.gen.engine.types import Message, Role, StopReason

from ._shared import (
    _assert_base_fields,
    _assert_usage_cost_perf,
    _key_for,
    _save,
    _to_dict,
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# (provider, model, on_effort).
# on_effort: "auto" for always-reasoning xAI + kimi + deepseek-reasoner; "high"
# for dynamic-effort models.
REASONING_ENGINES: list[tuple[str, str, str]] = [
    ("anthropic", "claude-haiku-4-5", "high"),
    ("anthropic", "claude-sonnet-4-6", "high"),
    ("deepseek", "deepseek-reasoner", "auto"),
    ("google", "gemini-3-flash-preview", "high"),
    ("google", "gemini-2.5-flash", "high"),
    ("moonshot", "kimi-k2.5", "auto"),
    ("openai", "gpt-5.4-nano", "high"),
    ("xai", "grok-4-1-fast", "auto"),
]

_PROMPT = [Message(role=Role.USER, content="Respond with the single word 'ok'.")]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _assert_valid_response(response, *, provider: str, model: str) -> None:
    _assert_base_fields(response, streaming=False)
    _assert_usage_cost_perf(response)
    assert response.stop_reason == StopReason.END_TURN, f"{provider}/{model}: unexpected stop_reason {response.stop_reason}"
    assert response.content, f"{provider}/{model}: content must be non-empty"


# ---------------------------------------------------------------------------
# Tests — reasoning ON
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model,on_effort", REASONING_ENGINES)
async def test_reasoning_on(provider: str, model: str, on_effort: str) -> None:
    """reasoning_effort=<on_effort>: response valid; always+raw models expose reasoning_content."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model, reasoning_effort=on_effort)
    response = await engine.chat(_PROMPT)

    _save(_to_dict(response), f"reasoning_on_{provider}_{model}")
    _assert_valid_response(response, provider=provider, model=model)

    model_info = get_model(model)
    if model_info and model_info.reasoning_tokens_type == "raw" and not model_info.reasoning_efforts:
        # budget_tokens + always-reasoning raw-token models produce thinking blocks
        # reliably even for trivial prompts; effort-based (adaptive) models may
        # skip thinking on simple prompts — we don't assert reasoning_content.
        assert response.reasoning_content, f"{provider}/{model}: expected reasoning_content with effort={on_effort!r}"


# ---------------------------------------------------------------------------
# Tests — reasoning OFF
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model,on_effort", REASONING_ENGINES)
async def test_reasoning_off(provider: str, model: str, on_effort: str) -> None:
    """reasoning_effort=None: response valid; always models swap; dynamic models don't reason."""
    del on_effort  # unused in OFF
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model, reasoning_effort=None)
    response = await engine.chat(_PROMPT)

    _save(_to_dict(response), f"reasoning_off_{provider}_{model}")
    _assert_valid_response(response, provider=provider, model=model)

    model_info = get_model(model)
    if model_info is None:
        return

    if model_info.non_reasoning_id:
        # always-reasoning model with a non-reasoning variant — factory must have swapped
        assert response.model == model_info.non_reasoning_id, (
            f"{provider}/{model}: expected model swap to {model_info.non_reasoning_id!r}, " f"got {response.model!r}"
        )
        assert not response.reasoning_content, f"non-reasoning variant {model_info.non_reasoning_id!r} must not populate reasoning_content"

    elif model_info.reasoning_mode == "dynamic":
        # dynamic models: thinking is disabled — no reasoning content expected
        assert not response.reasoning_content, f"{provider}/{model}: dynamic model must not produce reasoning_content when disabled"

    # always-reasoning models with no non_reasoning_id (e.g. deepseek-reasoner) still
    # reason when reasoning_effort=None because they cannot be disabled — no assertion.
