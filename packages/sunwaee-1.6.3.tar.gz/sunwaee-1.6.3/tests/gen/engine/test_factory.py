# standard
import asyncio

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import (
    _HTTP_CLIENTS,
    _SYNC_HTTP_CLIENTS,
    _get_client,
    close_all_clients,
    get_engine,
)
from sunwaee.modules.gen.engine.providers.anthropic import AnthropicEngine
from sunwaee.modules.gen.engine.providers.completions import CompletionsEngine
from sunwaee.modules.gen.engine.providers.google import GoogleEngine
from sunwaee.modules.gen.engine.providers.responses import ResponsesEngine

### HELPERS


def _monkeypatch_env(monkeypatch, provider: str, key: str = "env-key"):
    monkeypatch.setenv(f"{provider.upper()}_API_KEY", key)


### PROVIDER ROUTING


def test_get_engine_anthropic():
    engine = get_engine("anthropic", "claude-haiku-4-5", "key")
    assert isinstance(engine, AnthropicEngine)
    assert engine.model == "claude-haiku-4-5"


def test_get_engine_google():
    engine = get_engine("google", "gemini-2.5-flash", "key")
    assert isinstance(engine, GoogleEngine)
    assert engine.model == "gemini-2.5-flash"


def test_get_engine_openai_responses_model_routes_to_responses_engine():
    """gpt-5.4-mini has api_type=['responses','completions'] → prefer Responses."""
    engine = get_engine("openai", "gpt-5.4-mini", "key")
    assert isinstance(engine, ResponsesEngine)
    assert engine.base_url == "https://api.openai.com/v1"


def test_get_engine_deepseek_routes_to_completions():
    engine = get_engine("deepseek", "deepseek-chat", "key")
    assert isinstance(engine, CompletionsEngine)
    assert "deepseek" in engine.base_url


def test_get_engine_moonshot_routes_to_completions():
    engine = get_engine("moonshot", "kimi-k2.5", "key")
    assert isinstance(engine, CompletionsEngine)
    assert "moonshot" in engine.base_url


def test_get_engine_xai_responses_model_routes_to_responses():
    engine = get_engine("xai", "grok-4-1-fast-non-reasoning", "key")
    assert isinstance(engine, ResponsesEngine)
    assert "x.ai" in engine.base_url


def test_get_engine_unknown_openai_model_defaults_to_completions():
    """Unknown model (not in registry) → falls through to CompletionsEngine default."""
    engine = get_engine("openai", "totally-unknown-model", "key")
    assert isinstance(engine, CompletionsEngine)


def test_get_engine_case_insensitive():
    engine = get_engine("Anthropic", "claude-haiku-4-5", "key")
    assert isinstance(engine, AnthropicEngine)

    engine = get_engine("GOOGLE", "gemini-2.5-flash", "key")
    assert isinstance(engine, GoogleEngine)


def test_get_engine_max_tokens_uses_model_max_output_tokens():
    """Known models: factory always sends the model's full max_output_tokens."""
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", max_tokens=1024)
    assert engine.max_tokens == 64_000


def test_get_engine_max_tokens_fallback_for_unknown_model():
    """Unknown models: factory passes the kwarg through."""
    engine = get_engine("openai", "totally-unknown-model", "key", max_tokens=1024)
    assert engine.max_tokens == 1024


def test_get_engine_unknown_provider():
    with pytest.raises(ValueError, match="Unknown provider"):
        get_engine("banana", "some-model", "key")


### API KEY RESOLUTION


def test_get_engine_api_key_from_env(monkeypatch):
    _monkeypatch_env(monkeypatch, "anthropic")
    engine = get_engine("anthropic", "claude-haiku-4-5")
    assert engine.api_key == "env-key"


def test_get_engine_explicit_key_takes_precedence(monkeypatch):
    _monkeypatch_env(monkeypatch, "anthropic", key="env-key")
    engine = get_engine("anthropic", "claude-haiku-4-5", api_key="explicit-key")
    assert engine.api_key == "explicit-key"


def test_get_engine_no_key_raises(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    with pytest.raises(ValueError, match="ANTHROPIC_API_KEY"):
        get_engine("anthropic", "claude-haiku-4-5")


### REASONING_EFFORT — model swapping


def test_reasoning_effort_none_swaps_always_model_to_non_reasoning():
    engine = get_engine("xai", "grok-4-1-fast", "key", reasoning_effort=None)
    assert engine.model == "grok-4-1-fast-non-reasoning"


def test_reasoning_effort_auto_keeps_always_model():
    engine = get_engine("xai", "grok-4-1-fast", "key", reasoning_effort="auto")
    assert engine.model == "grok-4-1-fast"


def test_reasoning_effort_set_swaps_non_reasoning_model_to_reasoning():
    """reasoning_id exists on non-reasoning variants → swap when any effort is set."""
    engine = get_engine("xai", "grok-4-1-fast-non-reasoning", "key", reasoning_effort="auto")
    assert engine.model == "grok-4-1-fast"


def test_reasoning_effort_none_keeps_non_reasoning_model():
    engine = get_engine("xai", "grok-4-1-fast-non-reasoning", "key", reasoning_effort=None)
    assert engine.model == "grok-4-1-fast-non-reasoning"


def test_reasoning_effort_none_always_no_swap_when_no_non_reasoning_id():
    """grok-4 is always-reasoning but has no non_reasoning_id → stays as-is."""
    engine = get_engine("xai", "grok-4", "key", reasoning_effort=None)
    assert engine.model == "grok-4"


### REASONING_EFFORT — validation


def test_reasoning_effort_invalid_raises():
    with pytest.raises(ValueError, match="reasoning_effort"):
        get_engine("openai", "gpt-5.4-mini", "key", reasoning_effort="not-a-level")


def test_reasoning_effort_silently_dropped_for_non_reasoning_model():
    """gpt-4.1-nano doesn't support reasoning — the provider would 400 if we
    sent reasoning.effort. The factory drops the effort instead of erroring."""
    engine = get_engine("openai", "gpt-4.1-nano", "key", reasoning_effort="high")
    assert isinstance(engine, ResponsesEngine)
    assert engine.reasoning_effort is None


def test_reasoning_effort_minimal_not_in_model_efforts_raises():
    """gpt-5.4-mini.reasoning_efforts = ['none','low','medium','high','xhigh'] → 'minimal' invalid."""
    with pytest.raises(ValueError, match="reasoning_effort"):
        get_engine("openai", "gpt-5.4-mini", "key", reasoning_effort="minimal")


### REASONING_EFFORT — anthropic


def test_reasoning_effort_anthropic_effort_model_passes_through():
    """claude-opus-4-7 has reasoning_efforts → effort string passed directly."""
    engine = get_engine("anthropic", "claude-opus-4-7", "key", reasoning_effort="high")
    assert isinstance(engine, AnthropicEngine)
    assert engine.effort == "high"
    assert engine.thinking_budget is None


def test_reasoning_effort_anthropic_effort_model_max_passes_through():
    engine = get_engine("anthropic", "claude-opus-4-7", "key", reasoning_effort="max")
    assert engine.effort == "max"
    assert engine.thinking_budget is None


def test_reasoning_effort_none_anthropic_effort_model_no_effort():
    engine = get_engine("anthropic", "claude-opus-4-7", "key", reasoning_effort=None)
    assert engine.effort is None
    assert engine.thinking_budget is None


def test_reasoning_effort_anthropic_budget_model_low():
    """claude-haiku-4-5 has no reasoning_efforts → budget table."""
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", reasoning_effort="low")
    assert engine.thinking_budget == 2048
    assert engine.effort is None


def test_reasoning_effort_anthropic_budget_model_medium():
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", reasoning_effort="medium")
    assert engine.thinking_budget == 8192


def test_reasoning_effort_anthropic_budget_model_high():
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", reasoning_effort="high")
    assert engine.thinking_budget == 24_576


def test_reasoning_effort_anthropic_budget_model_unmapped_effort_falls_back():
    """An unmapped effort (xhigh) → fallback budget = max(1024, max_tokens-1024).
    max_tokens comes from the registry (haiku-4-5 = 64_000)."""
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", reasoning_effort="xhigh")
    assert engine.thinking_budget == max(1024, 64_000 - 1024)


def test_reasoning_effort_none_anthropic_budget_model_no_thinking():
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", reasoning_effort=None)
    assert engine.thinking_budget is None
    assert engine.effort is None


### REASONING_EFFORT — google


def test_reasoning_effort_gemini3_uses_thinking_level():
    engine = get_engine("google", "gemini-3-flash-preview", "key", reasoning_effort="high")
    assert engine.thinking_level == "high"
    assert engine.thinking_budget is None


def test_reasoning_effort_none_gemini3_falls_back_to_lowest_effort():
    """Gemini 3 cannot truly disable; we send the lowest available effort."""
    engine = get_engine("google", "gemini-3-flash-preview", "key", reasoning_effort=None)
    assert engine.thinking_level == "minimal"
    assert engine.thinking_budget is None


def test_reasoning_effort_gemini25_low_maps_to_budget():
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort="low")
    assert engine.thinking_budget == 1024


def test_reasoning_effort_gemini25_medium_maps_to_budget():
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort="medium")
    assert engine.thinking_budget == 8192


def test_reasoning_effort_gemini25_high_maps_to_budget():
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort="high")
    assert engine.thinking_budget == 24_576


def test_reasoning_effort_gemini25_unmapped_effort_dynamic_budget():
    """Unknown effort → dynamic budget (-1)."""
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort="xhigh")
    assert engine.thinking_budget == -1


def test_reasoning_effort_none_gemini25_budget_zero():
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort=None)
    assert engine.thinking_budget == 0
    assert engine.thinking_level is None


def test_reasoning_effort_gemini25_pro_always_no_swap():
    """gemini-2.5-pro always-reasoning with no non_reasoning_id → no explicit config."""
    engine = get_engine("google", "gemini-2.5-pro", "key", reasoning_effort=None)
    assert engine.model == "gemini-2.5-pro"
    assert engine.thinking_budget is None
    assert engine.thinking_level is None


### REASONING_EFFORT — openai-compat


def test_reasoning_effort_openai_responses_engine_pass_through():
    engine = get_engine("openai", "gpt-5.4-mini", "key", reasoning_effort="high")
    assert isinstance(engine, ResponsesEngine)
    assert engine.reasoning_effort == "high"


def test_reasoning_effort_none_openai_responses_engine():
    engine = get_engine("openai", "gpt-5.4-mini", "key", reasoning_effort=None)
    assert isinstance(engine, ResponsesEngine)
    assert engine.reasoning_effort is None


def test_reasoning_effort_xai_auto_on_always_model_routes_to_responses():
    """grok-4-1-fast with effort='auto' → ResponsesEngine, no reasoning block in payload."""
    engine = get_engine("xai", "grok-4-1-fast", "key", reasoning_effort="auto")
    assert isinstance(engine, ResponsesEngine)
    assert engine.reasoning_effort == "auto"


def test_reasoning_effort_moonshot_off_merges_disabled_payload():
    """kimi-k2.5 effort='off' → disabled payload tracked on engine."""
    engine = get_engine("moonshot", "kimi-k2.5", "key", reasoning_effort="off")
    assert isinstance(engine, CompletionsEngine)
    assert engine._reasoning_disabled_payload == {"thinking": {"type": "disabled"}}


def test_reasoning_effort_moonshot_auto_no_disabled_payload():
    engine = get_engine("moonshot", "kimi-k2.5", "key", reasoning_effort="auto")
    assert engine._reasoning_disabled_payload is None


def test_reasoning_effort_moonshot_none_coerced_to_off_merges_payload():
    """Models with reasoning_disabled_payload treat effort=None as explicit off —
    the factory coerces None → 'off' so the disabled payload merges. Without
    this, kimi would reason by default even when the user toggled reasoning off."""
    engine = get_engine("moonshot", "kimi-k2.5", "key", reasoning_effort=None)
    assert engine._reasoning_disabled_payload == {"thinking": {"type": "disabled"}}


### HTTP CLIENT POOL


@pytest.mark.asyncio
async def test_close_all_clients_clears_pool():
    get_engine("anthropic", "claude-haiku-4-5", "key")
    assert len(_HTTP_CLIENTS) > 0

    await close_all_clients()
    assert len(_HTTP_CLIENTS) == 0


@pytest.mark.asyncio
async def test_close_all_clients_is_idempotent():
    await close_all_clients()
    await close_all_clients()


@pytest.mark.asyncio
async def test_client_pool_keyed_by_loop_identity(monkeypatch):
    await close_all_clients()
    loop = asyncio.get_running_loop()
    c1 = _get_client("https://example.test")
    assert _HTTP_CLIENTS[loop]["https://example.test"] is c1
    assert _get_client("https://example.test") is c1
    await close_all_clients()


def test_sync_context_uses_fallback_bucket():
    asyncio.run(close_all_clients())
    c = _get_client("https://sync.test")
    assert _SYNC_HTTP_CLIENTS["https://sync.test"] is c
    asyncio.run(close_all_clients())
    assert "https://sync.test" not in _SYNC_HTTP_CLIENTS
