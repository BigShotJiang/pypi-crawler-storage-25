from __future__ import annotations

# standard
import asyncio
import os
import weakref

# third party
import httpx

# custom
from .base import BaseEngine
from .models import get_model
from .providers.anthropic import AnthropicEngine
from .providers.completions import CompletionsEngine
from .providers.google import GoogleEngine
from .providers.responses import ResponsesEngine

_OPENAI_COMPATIBLE: dict[str, str] = {
    "openai": "https://api.openai.com/v1",
    "deepseek": "https://api.deepseek.com/v1",
    "moonshot": "https://api.moonshot.ai/v1",
    "xai": "https://api.x.ai/v1",
}

# Effort → thinking_budget token mapping for providers whose API uses an
# integer budget instead of an effort string. Applied only for provider-models
# that don't accept effort natively: older Anthropic (4.5 family) and Gemini 2.5.
_ANTHROPIC_BUDGET: dict[str, int] = {"low": 2048, "medium": 8192, "high": 24_576}
_GOOGLE_BUDGET: dict[str, int] = {"low": 1024, "medium": 8192, "high": 24_576}

# Shared timeout and connection-pool settings for all provider clients.
# connect/write are short; read allows long-running model inference (5 min).
_TIMEOUT = httpx.Timeout(connect=5.0, read=300.0, write=30.0, pool=5.0)
_LIMITS = httpx.Limits(max_connections=50, max_keepalive_connections=20)

# One persistent AsyncClient per (event loop, base_url). We use a
# WeakKeyDictionary on the loop object so that when a loop is garbage-collected
# (common in tests) its pooled clients are dropped with it — keying by id(loop)
# is unsafe because Python can reuse the same integer id for a new loop after
# the previous one is freed, leading to "Event loop is closed" errors on reuse.
# In production (single long-running loop) this stays at O(providers) entries.
_HTTP_CLIENTS: weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, dict[str, httpx.AsyncClient]] = weakref.WeakKeyDictionary()
# Fallback bucket for the rare sync-context call where no running loop exists.
_SYNC_HTTP_CLIENTS: dict[str, httpx.AsyncClient] = {}


def _get_client(base_url: str) -> httpx.AsyncClient:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        bucket = _SYNC_HTTP_CLIENTS
    else:
        bucket = _HTTP_CLIENTS.setdefault(loop, {})
    if base_url not in bucket:
        bucket[base_url] = httpx.AsyncClient(timeout=_TIMEOUT, limits=_LIMITS)
    return bucket[base_url]


async def close_all_clients() -> None:
    """Close and drain all pooled HTTP clients.

    Call this once during graceful shutdown (e.g. in a FastAPI ``lifespan``
    shutdown handler) to release all open TCP connections cleanly.
    """
    clients: list[httpx.AsyncClient] = []
    for bucket in list(_HTTP_CLIENTS.values()):
        clients.extend(bucket.values())
    clients.extend(_SYNC_HTTP_CLIENTS.values())
    await asyncio.gather(*(c.aclose() for c in clients), return_exceptions=True)
    _HTTP_CLIENTS.clear()
    _SYNC_HTTP_CLIENTS.clear()


def get_engine(
    provider: str,
    model: str,
    api_key: str | None = None,
    max_tokens: int = 8192,
    reasoning_effort: str | None = None,
) -> BaseEngine:
    """Return the correct engine instance for the given provider.

    ``api_key`` is used as-is when provided. Otherwise the env var
    ``<PROVIDER>_API_KEY`` (e.g. ``ANTHROPIC_API_KEY``) is tried.

    ``reasoning_effort`` values:
      - None: reasoning off. For ``reasoning_mode="always"`` models with a
        ``non_reasoning_id``, swap to the non-reasoning variant.
      - "auto": model reasons at its default; no explicit effort sent. Used
        for xAI always-reasoning and kimi-k2.5.
      - "off": explicitly disable reasoning. Kimi-k2.5 merges its
        ``reasoning_disabled_payload``; other providers omit the reasoning
        block (model falls back to its default behavior).
      - "minimal"/"low"/"medium"/"high"/"xhigh"/"max": sent as the
        provider-native effort param (or translated to a token budget for
        providers that use one).

    For non-reasoning models with a ``reasoning_id`` counterpart, any non-None
    ``reasoning_effort`` triggers a swap to the reasoning variant.
    """
    p = provider.lower()

    resolved_key = api_key or os.environ.get(f"{p.upper()}_API_KEY")
    if not resolved_key:
        raise ValueError(f"No API key for provider '{provider}'. " f"Pass api_key= or set the {p.upper()}_API_KEY environment variable.")

    # --- model swapping -------------------------------------------------------
    model_info = get_model(model)
    if model_info is not None:
        if reasoning_effort is None and model_info.reasoning_mode == "always":
            if model_info.non_reasoning_id:
                model = model_info.non_reasoning_id
                model_info = get_model(model)
        elif reasoning_effort is not None and model_info.reasoning_mode is None:
            if model_info.reasoning_id:
                model = model_info.reasoning_id
                model_info = get_model(model)

    # --- non-reasoning models: drop effort -----------------------------------
    # If the resolved model doesn't support reasoning (e.g. gpt-4.1-nano), the
    # provider will reject any reasoning.* params. Silently drop effort rather
    # than error — the caller can't be expected to know every model's status.
    if model_info is not None and not model_info.supports_reasoning:
        reasoning_effort = None

    # --- disable-reasoning coercion ------------------------------------------
    # Models that reason by default (e.g. kimi-k2.5) only stop when we send
    # their reasoning_disabled_payload. reasoning_effort=None on such a model
    # is the user intent "off" — coerce to "off" so the engine merges the
    # disabled payload.
    if (
        reasoning_effort is None
        and model_info is not None
        and model_info.reasoning_disabled_payload
        and model_info.reasoning_efforts
        and "off" in model_info.reasoning_efforts
    ):
        reasoning_effort = "off"

    # --- effort validation ----------------------------------------------------
    if reasoning_effort is not None and model_info is not None and model_info.reasoning_efforts:
        if reasoning_effort not in model_info.reasoning_efforts:
            raise ValueError(f"reasoning_effort {reasoning_effort!r} not in model.reasoning_efforts={model_info.reasoning_efforts}")

    # --- max_tokens resolution -----------------------------------------------
    # When the provider API requires max_tokens, always send the model's full
    # max_output_tokens from the registry. The kwarg is only a fallback for
    # models not in the registry.
    if model_info is not None and model_info.max_output_tokens:
        max_tokens = model_info.max_output_tokens

    # --- provider routing -----------------------------------------------------
    if p in _OPENAI_COMPATIBLE:
        base_url = _OPENAI_COMPATIBLE[p]
        api_types = model_info.api_type if model_info and model_info.api_type else ["completions"]
        if "responses" in api_types:
            return ResponsesEngine(
                provider=p,
                model=model,
                api_key=resolved_key,
                base_url=base_url,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
                client=_get_client(base_url),
            )
        return CompletionsEngine(
            provider=p,
            model=model,
            api_key=resolved_key,
            base_url=base_url,
            max_tokens=max_tokens,
            reasoning_effort=reasoning_effort,
            client=_get_client(base_url),
        )

    if p == "anthropic":
        effort: str | None = None
        thinking_budget: int | None = None

        if model_info is not None and model_info.reasoning_efforts:
            # Newer models (Opus 4.7/4.6, Sonnet 4.6) accept effort directly.
            # "max" is treated as our product-level ceiling — still passed
            # through; AnthropicEngine maps it to the highest supported config.
            effort = reasoning_effort
        elif reasoning_effort is not None:
            # Older models (Opus 4.5, Haiku 4.5, Sonnet 4.5): translate effort
            # string to an explicit thinking_budget token count. Clamp to
            # max_tokens - 1024: the Anthropic API requires budget < max_tokens,
            # and we need headroom for the final answer.
            cap = max(1024, max_tokens - 1024)
            thinking_budget = min(_ANTHROPIC_BUDGET.get(reasoning_effort, cap), cap)
        # else: reasoning_effort=None on older model → no thinking block sent

        return AnthropicEngine(
            model=model,
            api_key=resolved_key,
            max_tokens=max_tokens,
            thinking_budget=thinking_budget,
            effort=effort,
            client=_get_client(AnthropicEngine.BASE_URL),
        )

    if p == "google":
        thinking_budget_g: int | None = None
        thinking_level: str | None = None

        if model_info is not None:
            if model_info.reasoning_mode == "always" and model_info.non_reasoning_id is None:
                # Can't disable — let model use its natural default (no explicit config)
                pass
            elif model_info.reasoning_efforts:
                # Gemini 3 series: use thinkingLevel directly
                if reasoning_effort is not None:
                    thinking_level = reasoning_effort
                else:
                    thinking_level = model_info.reasoning_efforts[0]  # "minimal" or "low"
            else:
                # Gemini 2.5 series: translate effort string to thinkingBudget
                if reasoning_effort is None:
                    thinking_budget_g = 0
                else:
                    thinking_budget_g = _GOOGLE_BUDGET.get(reasoning_effort, -1)

        return GoogleEngine(
            model=model,
            api_key=resolved_key,
            max_tokens=max_tokens,
            thinking_budget=thinking_budget_g,
            thinking_level=thinking_level,
            client=_get_client(GoogleEngine.BASE_URL),
        )

    raise ValueError(f"Unknown provider '{provider}'. " f"Supported: {', '.join(sorted({*_OPENAI_COMPATIBLE, 'anthropic', 'google'}))}")
