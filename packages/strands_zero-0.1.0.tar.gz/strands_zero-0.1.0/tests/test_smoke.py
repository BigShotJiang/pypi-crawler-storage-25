"""Smoke tests — exercise every tool against the real `zero` binary.

Skips gracefully if Zero isn't installed. Some tests tolerate upstream-binary
quirks (skills CLI, dyld LC_UUID on macOS) since this is an external tool.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from strands_zero._runner import find_zero_binary, run_zero
from strands_zero.tools import (
    zero_version, zero_doctor, zero_skills, zero_write, zero_check,
    zero_run, zero_build, zero_explain, zero_targets, zero_graph,
    zero_size, zero_fmt, zero_clean,
)


HELLO = '''pub fun main(world: World) -> Void raises {
    check world.out.write("hello from zero\\n")
}
'''


@pytest.fixture(scope="session")
def zero_available():
    if not find_zero_binary():
        pytest.skip("zero binary not installed")


def _unwrap(t):
    """Unwrap a Strands @tool to its underlying function for direct call."""
    return getattr(t, "__wrapped__", None) or getattr(t, "func", None) or t


def test_find_binary(zero_available):
    assert find_zero_binary() is not None


def test_version(zero_available):
    r = _unwrap(zero_version)(json_output=True)
    assert r["ok"], r
    assert "0.1" in r["stdout"] or (r.get("json") and "version" in r["json"])


def test_targets(zero_available):
    r = _unwrap(zero_targets)()
    assert r["ok"], r
    assert "darwin" in r["stdout"] or "linux" in r["stdout"]


def test_skills_runs(zero_available):
    """skills CLI may require repo-local bin/zero; just check our wrapper invokes it."""
    r = _unwrap(zero_skills)(action="list")
    assert "command" in r
    assert "skills" in r["command"]


def test_doctor(zero_available):
    r = _unwrap(zero_doctor)(json_output=True)
    assert r["exit_code"] in (0, 1, 2), r


def test_write_and_check(zero_available, tmp_path):
    w = _unwrap(zero_write)(HELLO, path=str(tmp_path / "hello.0"))
    assert w["ok"] and Path(w["path"]).exists()

    c = _unwrap(zero_check)(w["path"], json_output=True)
    assert c["ok"], c
    # Successful check should produce JSON diagnostics surface
    assert "json" in c or c["stdout"] != ""


def test_run_attempt(zero_available, tmp_path):
    """zero run may fail on macOS 26 due to dyld LC_UUID issue in prebuilt binary.
    We assert the wrapper invocation is correct, not that the program executes.
    """
    src = tmp_path / "hello.0"
    src.write_text(HELLO)
    r = _unwrap(zero_run)(str(src))
    assert "command" in r
    # If it ran, it should print our message; otherwise stderr should mention dyld
    if r["ok"]:
        assert "hello from zero" in r["stdout"]


def test_build_exe(zero_available, tmp_path):
    src = tmp_path / "h.0"
    src.write_text(HELLO)
    out = tmp_path / "h"
    b = _unwrap(zero_build)(str(src), emit="exe", out=str(out))
    assert "command" in b


def test_build_invalid_emit(zero_available):
    r = _unwrap(zero_build)("dummy.0", emit="bogus")
    assert not r["ok"]
    assert "emit" in r["error"]


def test_explain(zero_available):
    r = _unwrap(zero_explain)("E0001", json_output=True)
    assert "command" in r


def test_graph(zero_available, tmp_path):
    src = tmp_path / "g.0"
    src.write_text(HELLO)
    r = _unwrap(zero_graph)(str(src), json_output=True)
    assert "command" in r


def test_fmt(zero_available, tmp_path):
    src = tmp_path / "f.0"
    src.write_text(HELLO)
    r = _unwrap(zero_fmt)(str(src))
    assert "command" in r


def test_clean(zero_available, tmp_path):
    r = _unwrap(zero_clean)(target_dir=str(tmp_path), all_artifacts=True)
    assert "command" in r


def test_skills_get_requires_name():
    """Pure unit test - no zero binary needed."""
    r = _unwrap(zero_skills)(action="get")
    assert not r["ok"]
    assert "name required" in r["error"]


def test_unknown_skills_action():
    r = _unwrap(zero_skills)(action="bogus")
    assert not r["ok"]


def test_zero_new_invalid_kind():
    r = _unwrap(__import__("strands_zero.tools", fromlist=["zero_new"]).zero_new)(
        kind="bogus", name="x"
    )
    assert not r["ok"]


def test_run_zero_returns_error_when_missing(monkeypatch):
    """Wrapper handles missing binary gracefully."""
    monkeypatch.setattr("strands_zero._runner.find_zero_binary", lambda: None)
    r = run_zero(["--version"])
    assert not r["ok"]
    assert "not found" in r["error"]
