"""Use the tools directly without an agent."""
from strands_zero import zero_write, zero_check, zero_run, zero_version

print(zero_version())
w = zero_write('''
pub fun main(world: World) -> Void raises {
    check world.out.write("hello\\n")
}
''')
print(zero_check(w["path"]))
print(zero_run(w["path"])["stdout"])
