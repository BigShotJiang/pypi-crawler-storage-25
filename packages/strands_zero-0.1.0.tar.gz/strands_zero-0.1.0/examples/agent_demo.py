"""Minimal end-to-end demo: agent writes, checks, and runs Zero code."""
from strands import Agent
from strands_zero import (
    zero_write, zero_check, zero_run, zero_explain,
    zero_fix, zero_skills, zero_doctor, zero_version,
)

agent = Agent(
    tools=[
        zero_write, zero_check, zero_run, zero_explain,
        zero_fix, zero_skills, zero_doctor, zero_version,
    ],
    system_prompt=(
        "You are a Zero language expert. "
        "Use zero_skills('get','zero-language',full=True) when unsure of syntax. "
        "Always zero_check before zero_run. "
        "On diagnostics: use zero_explain + zero_fix, then retry."
    ),
)

if __name__ == "__main__":
    agent("Write a Zero program that prints the first 5 squares, type-check it, then run it.")
