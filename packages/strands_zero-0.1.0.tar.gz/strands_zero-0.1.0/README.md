# strands-zero

[![PyPI](https://img.shields.io/pypi/v/strands-zero.svg)](https://pypi.org/project/strands-zero/)

**Strands Agents tools for the [Zero programming language](https://zerolang.ai).**

Wraps the official `zero` CLI as a set of `@tool`-decorated Python functions
so AI agents (Claude, Strands, anything compatible) can write, type-check,
compile, run, ship, and inspect Zero programs with structured JSON feedback.

> Zero is the programming language for agents — small native tools, explicit
> effects, predictable memory, and machine-readable compiler output.

---

## Install

```bash
pip install strands-zero
```

This installs the Python wrappers. You also need the Zero compiler binary:

```bash
# one-shot from the package
strands-zero-install

# or manually
curl -fsSL https://zerolang.ai/install.sh | bash
export PATH="$HOME/.zero/bin:$PATH"
```

`strands-zero` finds the binary in this order:
1. `$ZERO_BIN` env var
2. `zero` on `$PATH`
3. `~/.zero/bin/zero`

---

## Quick start

```python
from strands import Agent
from strands_zero import (
    zero_write, zero_check, zero_run, zero_build,
    zero_explain, zero_fix, zero_doctor, zero_skills,
    zero_graph, zero_size, zero_test, zero_version,
)

agent = Agent(
    tools=[
        zero_write, zero_check, zero_run, zero_build,
        zero_explain, zero_fix, zero_doctor, zero_skills,
    ],
    system_prompt="You are a Zero language expert. Use zero_skills('get','zero-language',full=True) when unsure of syntax.",
)

agent("Write a Zero program that prints the first 10 fibonacci numbers, type-check it, then run it.")
```

---

## Tools

| Tool                | Purpose                                                             |
| ------------------- | ------------------------------------------------------------------- |
| `zero_version`      | Compiler version + host info                                        |
| `zero_install`      | Install/upgrade the Zero compiler                                   |
| `zero_doctor`       | Diagnose the toolchain                                              |
| `zero_skills`       | Access built-in language/diagnostics/builds/agent skill docs        |
| `zero_targets`      | List supported compilation targets                                  |
| `zero_write`        | Write `.0` source to disk (or temp file)                            |
| `zero_new`          | Scaffold a new `cli` / `lib` / `package`                            |
| `zero_check`        | Type-check; returns structured diagnostics JSON                     |
| `zero_explain`      | Explain a diagnostic code                                           |
| `zero_fix`          | Get a structured fix plan                                           |
| `zero_run`          | Compile and run a program (with stdin/args)                         |
| `zero_build`        | Build to `exe` / `obj` / `wasm`                                     |
| `zero_ship`         | Release-grade build (`release-small` / `tiny` / `audit`)            |
| `zero_test`         | Run `test` blocks                                                   |
| `zero_fmt`          | Format source                                                       |
| `zero_graph`        | Module / dep graph                                                  |
| `zero_size`         | Binary size breakdown                                               |
| `zero_mem`          | Static memory layout                                                |
| `zero_routes`       | List declared web routes                                            |
| `zero_clean`        | Clean `.zero/` cache                                                |

All tools accept a `cwd` arg; build/run tools accept `timeout`.
JSON-capable tools default to `json_output=True` and parse stdout into
`result["json"]`.

---

## Manual usage (no agent)

```python
from strands_zero import zero_write, zero_run

write = zero_write('''
pub fun main(world: World) -> Void raises {
    check world.out.write("hello\\n")
}
''')

run = zero_run(write["path"])
print(run["stdout"])  # hello
```

---

## Why?

Zero exposes everything an agent needs through `--json` flags
(`check --json`, `fix --plan --json`, `graph --json`, `size --json`, `doctor --json`, ...).
This package gives that surface area to a Strands agent verbatim, so an agent
can iterate on Zero code with the same explicit, machine-readable feedback the
language is designed for.

---

## License

Apache-2.0
