"""wxflywheel CLI package."""

__version__ = "0.2.1"
