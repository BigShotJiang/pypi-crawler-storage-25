import json
from pathlib import Path

from dep_guard_mcp.advisories import find_vulnerabilities
from dep_guard_mcp.cli import build_parser
from dep_guard_mcp.scanner import discover_dependencies, list_supported_files


def test_supported_files():
    names = list_supported_files()
    assert "requirements.txt" in names
    assert "pyproject.toml" in names
    assert "package.json" in names
    assert "pom.xml" in names
    assert "build.gradle" in names
    assert "composer.json" in names


def test_discover_dependencies_from_requirements(tmp_path: Path):
    req = tmp_path / "requirements.txt"
    req.write_text("requests==2.32.3\n# comment\n", encoding="utf-8")

    deps = discover_dependencies(str(tmp_path))

    assert len(deps) == 1
    assert deps[0].name == "requests"
    assert deps[0].version == "2.32.3"
    assert deps[0].ecosystem == "PyPI"


def test_discover_dependencies_from_pom_xml(tmp_path: Path):
    pom = tmp_path / "pom.xml"
    pom.write_text(
        """
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <dependencies>
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-core</artifactId>
      <version>5.3.39</version>
    </dependency>
  </dependencies>
</project>
""".strip(),
        encoding="utf-8",
    )

    deps = discover_dependencies(str(tmp_path))
    assert len(deps) == 1
    assert deps[0].ecosystem == "Maven"
    assert deps[0].name == "org.springframework:spring-core"
    assert deps[0].version == "5.3.39"


def test_discover_dependencies_from_gradle(tmp_path: Path):
    gradle = tmp_path / "build.gradle"
    gradle.write_text(
        """
dependencies {
  implementation 'org.springframework:spring-web:5.3.39'
  testImplementation("org.junit.jupiter:junit-jupiter:5.10.3")
}
""".strip(),
        encoding="utf-8",
    )

    deps = discover_dependencies(str(tmp_path))
    by_name = {d.name: d for d in deps}
    assert "org.springframework:spring-web" in by_name
    assert by_name["org.springframework:spring-web"].version == "5.3.39"
    assert "org.junit.jupiter:junit-jupiter" in by_name


def test_discover_dependencies_from_composer(tmp_path: Path):
    composer = tmp_path / "composer.json"
    composer.write_text(
        json.dumps(
            {
                "require": {
                    "php": ">=8.1",
                    "symfony/http-foundation": "6.4.10",
                },
                "require-dev": {
                    "phpunit/phpunit": "11.2.0",
                },
            }
        ),
        encoding="utf-8",
    )

    deps = discover_dependencies(str(tmp_path))
    by_name = {d.name: d for d in deps}
    assert "symfony/http-foundation" in by_name
    assert by_name["symfony/http-foundation"].ecosystem == "Packagist"
    assert by_name["symfony/http-foundation"].version == "6.4.10"
    assert "phpunit/phpunit" in by_name


def test_find_vulnerabilities_dedupes_sources(monkeypatch):
    from dep_guard_mcp.scanner import Dependency

    dep = Dependency(ecosystem="PyPI", name="requests", version="2.31.0")

    monkeypatch.setattr(
        "dep_guard_mcp.advisories._query_osv",
        lambda _: {
            "vulns": [
                {
                    "id": "GHSA-abc",
                    "summary": "osv summary",
                    "aliases": ["CVE-1"],
                    "severity": [],
                    "references": [],
                }
            ]
        },
    )
    monkeypatch.setattr(
        "dep_guard_mcp.advisories._query_github_advisories",
        lambda _: [
            {
                "ghsa_id": "GHSA-abc",
                "cve_id": "CVE-1",
                "summary": "github summary",
                "html_url": "https://github.com/advisories/GHSA-abc",
            }
        ],
    )

    findings = find_vulnerabilities([dep], include_github_advisories=True)
    assert len(findings) == 1
    assert len(findings[0]["vulnerabilities"]) == 1


def test_cli_parser_scan_command():
    parser = build_parser()
    args = parser.parse_args(["scan", ".", "--format", "summary", "--no-github-advisories"])
    assert args.command == "scan"
    assert args.format == "summary"
    assert args.no_github_advisories is True
