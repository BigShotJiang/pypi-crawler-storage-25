from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from .advisories import find_vulnerabilities
from .scanner import discover_dependencies, list_supported_files

try:
    from mcp.server.fastmcp import FastMCP
except Exception:  # pragma: no cover
    FastMCP = None


APP_NAME = "dep-guard-mcp"


def health_check() -> Dict[str, Any]:
    return {"status": "ok", "service": APP_NAME}


def scan_dependencies(target_path: str, include_github_advisories: bool = True) -> Dict[str, Any]:
    path = Path(target_path)
    if not path.exists():
        return {
            "ok": False,
            "error": f"Path not found: {target_path}",
            "supported_files": list_supported_files(),
        }

    dependencies = discover_dependencies(target_path)
    if not dependencies:
        return {
            "ok": True,
            "message": "No supported dependency manifests found or no pinned dependencies parsed.",
            "supported_files": list_supported_files(),
            "dependencies_scanned": 0,
            "findings": [],
        }

    findings = find_vulnerabilities(
        dependencies,
        include_github_advisories=include_github_advisories,
    )
    vuln_count = sum(len(item.get("vulnerabilities", [])) for item in findings)

    return {
        "ok": True,
        "dependencies_scanned": len(dependencies),
        "dependencies_with_vulns": sum(1 for item in findings if item.get("vulnerabilities")),
        "vulnerability_count": vuln_count,
        "data_sources": {
            "osv": True,
            "github_advisories": include_github_advisories,
            "github_advisories_free_tier": True,
        },
        "findings": findings,
    }


def main() -> None:
    if FastMCP is None:
        raise RuntimeError("The 'mcp' package is required. Install with: pip install -e .")

    mcp = FastMCP(APP_NAME)

    @mcp.tool
    def health_check_tool() -> Dict[str, Any]:
        return health_check()

    @mcp.tool
    def list_supported_files_tool() -> list[str]:
        return list_supported_files()

    @mcp.tool
    def scan_dependencies_tool(
        target_path: str,
        include_github_advisories: bool = True,
    ) -> Dict[str, Any]:
        return scan_dependencies(
            target_path,
            include_github_advisories=include_github_advisories,
        )

    mcp.run()


if __name__ == "__main__":
    main()
