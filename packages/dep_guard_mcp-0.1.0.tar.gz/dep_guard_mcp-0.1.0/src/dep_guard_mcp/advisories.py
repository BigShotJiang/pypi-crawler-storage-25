from __future__ import annotations

import json
import os
from typing import Any, Dict, List
from urllib import error, parse, request

from .scanner import Dependency


OSV_URL = "https://api.osv.dev/v1/query"
GITHUB_ADVISORIES_URL = "https://api.github.com/advisories"

ECOSYSTEM_TO_GITHUB = {
    "PyPI": "pip",
    "npm": "npm",
    "Maven": "maven",
    "Packagist": "composer",
}


def _query_osv(dep: Dependency) -> Dict[str, Any]:
    payload = {
        "package": {"name": dep.name, "ecosystem": dep.ecosystem},
        "version": dep.version,
    }
    body = json.dumps(payload).encode("utf-8")
    req = request.Request(
        OSV_URL,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with request.urlopen(req, timeout=12) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return data


def _query_github_advisories(dep: Dependency) -> List[Dict[str, Any]]:
    """Best-effort GitHub advisory lookup using free public advisory API.

    This endpoint is free to query and may be rate-limited when unauthenticated.
    If unavailable, we gracefully return an empty result and rely on OSV findings.
    """
    ecosystem = ECOSYSTEM_TO_GITHUB.get(dep.ecosystem)
    if not ecosystem:
        return []

    params = parse.urlencode(
        {
            "ecosystem": ecosystem,
            "affects": dep.name,
            "per_page": 100,
        }
    )
    url = f"{GITHUB_ADVISORIES_URL}?{params}"

    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "dep-guard-mcp",
    }
    token = os.getenv("GITHUB_TOKEN", "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"

    req = request.Request(url, headers=headers, method="GET")
    try:
        with request.urlopen(req, timeout=12) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except error.HTTPError:
        return []
    except error.URLError:
        return []


def _normalize_osv(vuln: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": vuln.get("id"),
        "summary": vuln.get("summary", ""),
        "aliases": vuln.get("aliases", []),
        "severity": vuln.get("severity", []),
        "references": vuln.get("references", []),
        "source": "osv",
    }


def _normalize_github(vuln: Dict[str, Any]) -> Dict[str, Any]:
    ghsa_id = vuln.get("ghsa_id")
    cve_id = vuln.get("cve_id")
    refs = []
    if vuln.get("html_url"):
        refs.append({"type": "ADVISORY", "url": vuln["html_url"]})

    aliases = []
    if cve_id:
        aliases.append(cve_id)
    if ghsa_id:
        aliases.append(ghsa_id)

    sev = []
    cvss = vuln.get("cvss", {})
    score = cvss.get("score")
    if score:
        sev.append({"type": "CVSS", "score": str(score)})

    return {
        "id": ghsa_id or cve_id,
        "summary": vuln.get("summary", ""),
        "aliases": aliases,
        "severity": sev,
        "references": refs,
        "source": "github_advisories",
    }


def _dedupe_vulnerabilities(vulns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    deduped: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for vuln in vulns:
        key_candidates = [vuln.get("id", "")] + vuln.get("aliases", [])
        key = next((candidate for candidate in key_candidates if candidate), "")
        if not key:
            key = json.dumps(vuln, sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(vuln)
    return deduped


def find_vulnerabilities(
    dependencies: List[Dependency],
    include_github_advisories: bool = True,
) -> List[Dict[str, Any]]:
    findings: List[Dict[str, Any]] = []
    for dep in dependencies:
        source_errors: List[str] = []
        normalized_vulns: List[Dict[str, Any]] = []

        try:
            result = _query_osv(dep)
        except Exception as exc:
            source_errors.append(f"osv: {exc}")
            result = {}

        for vuln in result.get("vulns", []):
            normalized_vulns.append(_normalize_osv(vuln))

        if include_github_advisories:
            try:
                gh_vulns = _query_github_advisories(dep)
            except Exception as exc:
                source_errors.append(f"github_advisories: {exc}")
                gh_vulns = []

            for vuln in gh_vulns:
                normalized_vulns.append(_normalize_github(vuln))

        vulns = _dedupe_vulnerabilities(normalized_vulns)

        item: Dict[str, Any] = {
            "dependency": dep.name,
            "version": dep.version,
            "ecosystem": dep.ecosystem,
            "vulnerabilities": vulns,
        }
        if source_errors and not vulns:
            item["error"] = "; ".join(source_errors)
        findings.append(item)

    return findings
