from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict

from .server import health_check, scan_dependencies
from .scanner import list_supported_files


def _severity_rank(score: str) -> int:
    score = score.lower().strip()
    if score == "critical":
        return 4
    if score == "high":
        return 3
    if score == "medium":
        return 2
    if score == "low":
        return 1
    return 0


def _extract_severity(vuln: Dict[str, Any]) -> str:
    for sev in vuln.get("severity", []):
        raw = str(sev.get("score", ""))
        if "AV:" in raw or "CVSS" in raw:
            return "high"
    return "unknown"


def _summarize(result: Dict[str, Any]) -> str:
    lines = []
    lines.append(f"Dependencies scanned: {result.get('dependencies_scanned', 0)}")
    lines.append(f"Dependencies with vulnerabilities: {result.get('dependencies_with_vulns', 0)}")
    lines.append(f"Total vulnerabilities: {result.get('vulnerability_count', 0)}")
    return "\n".join(lines)


def cmd_health(_: argparse.Namespace) -> int:
    print(json.dumps(health_check(), indent=2))
    return 0


def cmd_supported_files(_: argparse.Namespace) -> int:
    print(json.dumps({"supported_files": list_supported_files()}, indent=2))
    return 0


def cmd_scan(args: argparse.Namespace) -> int:
    result = scan_dependencies(
        args.target_path,
        include_github_advisories=not args.no_github_advisories,
    )

    content = json.dumps(result, indent=2) if args.format == "json" else _summarize(result)
    if args.output:
        out = Path(args.output)
        out.write_text(content + "\n", encoding="utf-8")
    else:
        print(content)

    if args.fail_on_severity:
        threshold = _severity_rank(args.fail_on_severity)
        max_found = 0
        for finding in result.get("findings", []):
            for vuln in finding.get("vulnerabilities", []):
                sev = _extract_severity(vuln)
                max_found = max(max_found, _severity_rank(sev))
        if max_found >= threshold and threshold > 0:
            return 2
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dep-guard-scan", description="Dependency vulnerability scanner")
    sub = parser.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="Scan target path")
    scan.add_argument("target_path", help="Path to scan")
    scan.add_argument("--format", choices=["json", "summary"], default="json")
    scan.add_argument("--output", help="Write report to output file")
    scan.add_argument(
        "--fail-on-severity",
        choices=["low", "medium", "high", "critical"],
        help="Return exit code 2 when vulnerability severity meets threshold",
    )
    scan.add_argument(
        "--no-github-advisories",
        action="store_true",
        help="Disable free GitHub advisory lookup",
    )
    scan.set_defaults(func=cmd_scan)

    health = sub.add_parser("health", help="Health check")
    health.set_defaults(func=cmd_health)

    supported = sub.add_parser("supported-files", help="List supported manifests")
    supported.set_defaults(func=cmd_supported_files)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    code = args.func(args)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
