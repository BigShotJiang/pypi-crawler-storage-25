#!/usr/bin/env python3
"""MCP Server for Dependency Vulnerability Scanning."""

import asyncio
import json
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from .scanner import discover_dependencies, list_supported_files
from .server import scan_dependencies as scan_dependencies_core

# Initialize FastMCP server
mcp = FastMCP("dep-guard-mcp")


@mcp.tool()
def health_check() -> dict:
    """Check if the MCP server is healthy."""
    return {"status": "ok", "service": "dep-guard-mcp"}


@mcp.tool()
def scan_dependencies(target_path: str, include_github_advisories: bool = True) -> dict:
    """
    Scan a target directory for dependencies and identify vulnerabilities.
    
    Args:
        target_path: Path to the directory containing dependency files
        
    Returns:
        Dictionary with scan results and vulnerabilities
    """
    path = Path(target_path)
    if not path.exists():
        return {
            "ok": False,
            "error": f"Path not found: {target_path}",
            "supported_files": list_supported_files(),
        }

    dependencies = discover_dependencies(target_path)
    if not dependencies:
        return {
            "ok": True,
            "message": "No supported dependency manifests found or no pinned dependencies parsed.",
            "supported_files": list_supported_files(),
            "dependencies_scanned": 0,
            "findings": [],
        }

    return scan_dependencies_core(
        target_path,
        include_github_advisories=include_github_advisories,
    )


@mcp.tool()
def get_supported_files() -> dict:
    """Get the list of supported dependency file formats."""
    return {
        "supported_files": list_supported_files(),
        "description": "These are the file formats that can be scanned for vulnerabilities"
    }


if __name__ == "__main__":
    mcp.run()

