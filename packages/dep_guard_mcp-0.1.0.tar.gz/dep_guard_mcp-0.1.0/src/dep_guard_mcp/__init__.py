"""Dep Guard MCP package."""

__all__ = ["server"]
