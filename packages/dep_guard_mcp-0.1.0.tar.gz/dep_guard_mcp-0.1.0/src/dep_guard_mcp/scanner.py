from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import tomllib


SUPPORTED_FILES = (
    "requirements.txt",
    "pyproject.toml",
    "package.json",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "composer.json",
)


@dataclass
class Dependency:
    ecosystem: str
    name: str
    version: str


def list_supported_files() -> List[str]:
    return list(SUPPORTED_FILES)


def _parse_requirements(path: Path) -> List[Dependency]:
    deps: List[Dependency] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "==" in line:
            name, version = line.split("==", 1)
            deps.append(Dependency(ecosystem="PyPI", name=name.strip(), version=version.strip()))
    return deps


def _parse_pyproject(path: Path) -> List[Dependency]:
    deps: List[Dependency] = []
    data = tomllib.loads(path.read_text(encoding="utf-8"))
    project = data.get("project", {})
    for item in project.get("dependencies", []):
        if "==" in item:
            name, version = item.split("==", 1)
            deps.append(Dependency(ecosystem="PyPI", name=name.strip(), version=version.strip()))
    return deps


def _parse_package_json(path: Path) -> List[Dependency]:
    deps: List[Dependency] = []
    data = json.loads(path.read_text(encoding="utf-8"))
    merged: Dict[str, str] = {}
    merged.update(data.get("dependencies", {}))
    merged.update(data.get("devDependencies", {}))
    for name, raw_version in merged.items():
        version = str(raw_version).lstrip("^~<>= ")
        if version:
            deps.append(Dependency(ecosystem="npm", name=name, version=version))
    return deps


def _parse_pom_xml(path: Path) -> List[Dependency]:
    deps: List[Dependency] = []
    try:
        tree = ET.parse(path)
    except ET.ParseError:
        return deps

    root = tree.getroot()
    for dep_node in root.findall(".//{*}dependency"):
        group = dep_node.findtext("{*}groupId", "").strip()
        artifact = dep_node.findtext("{*}artifactId", "").strip()
        version = dep_node.findtext("{*}version", "").strip()
        if group and artifact and version and not version.startswith("${"):
            deps.append(
                Dependency(ecosystem="Maven", name=f"{group}:{artifact}", version=version)
            )
    return deps


def _parse_gradle(path: Path) -> List[Dependency]:
    deps: List[Dependency] = []
    content = path.read_text(encoding="utf-8")

    patterns = [
        re.compile(r"(?:implementation|api|compileOnly|runtimeOnly|testImplementation)\s+['\"]([^:'\"]+):([^:'\"]+):([^'\"]+)['\"]"),
        re.compile(r"(?:implementation|api|compileOnly|runtimeOnly|testImplementation)\((?:\s*)['\"]([^:'\"]+):([^:'\"]+):([^'\"]+)['\"](?:\s*)\)"),
    ]

    seen: set[tuple[str, str]] = set()
    for pattern in patterns:
        for match in pattern.findall(content):
            group, artifact, version = (part.strip() for part in match)
            if not group or not artifact or not version or version.startswith("$"):
                continue
            key = (f"{group}:{artifact}", version)
            if key in seen:
                continue
            seen.add(key)
            deps.append(
                Dependency(ecosystem="Maven", name=f"{group}:{artifact}", version=version)
            )
    return deps


def _parse_composer_json(path: Path) -> List[Dependency]:
    deps: List[Dependency] = []
    data = json.loads(path.read_text(encoding="utf-8"))
    merged: Dict[str, str] = {}
    merged.update(data.get("require", {}))
    merged.update(data.get("require-dev", {}))

    for name, raw_version in merged.items():
        if name == "php":
            continue
        version = str(raw_version).strip().lstrip("^~<>= ")
        version = version.split(" ")[0]
        if version and "*" not in version:
            deps.append(Dependency(ecosystem="Packagist", name=name, version=version))
    return deps


def discover_dependencies(target_path: str) -> List[Dependency]:
    base = Path(target_path).resolve()
    if base.is_file():
        candidates = [base]
    else:
        candidates = [base / fname for fname in SUPPORTED_FILES]

    dependencies: List[Dependency] = []
    for file in candidates:
        if not file.exists():
            continue
        if file.name == "requirements.txt":
            dependencies.extend(_parse_requirements(file))
        elif file.name == "pyproject.toml":
            dependencies.extend(_parse_pyproject(file))
        elif file.name == "package.json":
            dependencies.extend(_parse_package_json(file))
        elif file.name == "pom.xml":
            dependencies.extend(_parse_pom_xml(file))
        elif file.name in ("build.gradle", "build.gradle.kts"):
            dependencies.extend(_parse_gradle(file))
        elif file.name == "composer.json":
            dependencies.extend(_parse_composer_json(file))

    return dependencies
