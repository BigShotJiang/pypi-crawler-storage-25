# Dep Guard MCP - Dependency Vulnerability Scanner

🔐 A fast, zero-config Model Context Protocol (MCP) server that scans Python, Node.js, Java/Spring, and PHP dependency manifests for known vulnerabilities.

## Status: ⚡ Week 2 Complete

- ✅ All tests passing
- ✅ MCP server fully functional
- ✅ Ready for Claude Desktop integration
- ✅ Production-ready code
- ✅ Free GitHub Advisory integration
- ✅ CLI support for local and CI usage

![CI](https://github.com/mdjahidanwar/dep-guard-mcp/actions/workflows/ci.yml/badge.svg)
![Security Scan](https://github.com/mdjahidanwar/dep-guard-mcp/actions/workflows/security-scan.yml/badge.svg)
![Release](https://github.com/mdjahidanwar/dep-guard-mcp/actions/workflows/release.yml/badge.svg)

## Features

- 📦 **Multi-Language Support**:
  - Python (`requirements.txt`, `pyproject.toml`)
  - Node.js (`package.json`)
  - Java/Spring (`pom.xml`, `build.gradle`, `build.gradle.kts`)
  - PHP (`composer.json`)
- 🎯 **Zero Config**: Automatic dependency discovery and scanning
- ⚡ **Multi-source Advisories**:
  - OSV API (free)
  - GitHub Advisory API (free public endpoint, optional `GITHUB_TOKEN` for higher rate limits)
- 🔧 **3 Core Tools**:
  - `scan_dependencies(target_path)` - Scan a project for vulnerabilities
  - `health_check()` - Verify server status
  - `get_supported_files()` - List scannable formats
- 🎨 **Clean Output**: JSON-formatted vulnerability reports with severity levels

## CLI Usage (Week 2)

```bash
# health check
dep-guard-scan health

# list supported files
dep-guard-scan supported-files

# scan and print JSON
dep-guard-scan scan /path/to/project

# scan and write report file
dep-guard-scan scan /path/to/project --output report.json

# fail CI if severity threshold is met
dep-guard-scan scan /path/to/project --fail-on-severity high

# disable GitHub advisories source
dep-guard-scan scan /path/to/project --no-github-advisories
```

## Week 3 Launch Prep

### GitHub Workflows

This repo now includes:

- CI workflow: `.github/workflows/ci.yml`
- Scheduled/manual security scan workflow: `.github/workflows/security-scan.yml`

### Reusable GitHub Action

You can use the local action in this repository:

```yaml
- uses: ./
  with:
    target-path: "."
    format: "json"
    output: "dep-guard-report.json"
    fail-on-severity: "high"
```

You can also consume it from another repository using the major tag:

```yaml
- uses: mdjahidanwar/dep-guard-mcp@v1
  with:
    target-path: "."
    format: "json"
    fail-on-severity: "high"
```

### VS Code Wrapper (Alpha)

An extension scaffold is available at `vscode-extension/` with commands:

- Dep Guard: Scan Workspace
- Dep Guard: Health Check

### Week 3 Completion Snapshot

- CI/CD pipeline in place for push/PR checks
- Scheduled security workflow in place
- Release check workflow in place
- Reusable GitHub Action available at repo root (`action.yml`)
- VS Code extension scaffold available under `vscode-extension/`
- Regression status: `7 passed`

## Week 4 Publishing Automation

This repo now includes release and publishing workflows:

- `.github/workflows/release.yml` for GitHub releases and artifacts
- `.github/workflows/publish-pypi.yml` for PyPI publish on tags (`v*`)
- `.github/workflows/publish-vscode.yml` for VS Code marketplace publish (manual)

Use `MARKETPLACE_CHECKLIST.md` as your launch checklist for Claude Registry, VS Code Marketplace, GitHub Action marketplace, and PyPI.

## Beginner Publishing Guides

If you are starting from zero, follow these guides in order:

1. `docs/marketplace/PUBLISH_VSCODE.md`
2. `docs/marketplace/PUBLISH_CLAUDE_MCP.md`
3. `docs/marketplace/PUBLISH_GITHUB_ACTION.md`

## Requirements

- Python 3.12+ (pre-configured)
- Virtual Environment (included)

## Quick Start

### 1. Install & Run

```bash
# Virtual environment already created in .venv/
.venv/Scripts/activate

# Already installed, just run:
python -m dep_guard_mcp.main
```

### 2. Use with Claude Desktop

Add to `~/.anthropic/models.json` (Mac/Linux) or `%APPDATA%\Claude\models.json` (Windows):

```json
{
  "mcpServers": {
    "dep-guard": {
      "command": "d:/devops-issue-tracker/scanner/.venv/Scripts/python.exe",
      "args": ["-m", "dep_guard_mcp.main"]
    }
  }
}
```

Then in Claude Desktop, you'll have access to:
- `scan_dependencies` - Analyze any project for CVEs
- Example: _"Scan /path/to/my/project for vulnerabilities"_

### 3. Test Locally

```bash
# Run all tests
pytest tests/ -v

# Test scanner on a specific directory
python -c "from dep_guard_mcp.main import scan_dependencies; 
import json; 
result = scan_dependencies('./test-project'); 
print(json.dumps(result, indent=2))"
```

## Usage Examples

### Example 1: Health Check
```python
from dep_guard_mcp.main import health_check
result = health_check()
# Output: {"status": "ok", "service": "dep-guard-mcp"}
```

### Example 2: Scan Python Project
```python
from dep_guard_mcp.main import scan_dependencies
result = scan_dependencies('/path/to/my-python-app')
# Returns:
# {
#   "ok": true,
#   "dependencies_scanned": 15,
#   "dependencies_with_vulns": 2,
#   "vulnerability_count": 5,
#   "findings": [...]
# }
```

### Example 3: List Supported Files
```python
from dep_guard_mcp.main import get_supported_files
result = get_supported_files()
# Output:
# {
#   "supported_files": ["requirements.txt", "package.json", ...],
#   "description": "These are the file formats that can be scanned..."
# }
```

## Supported Dependency Files

| Format | Language | Example |
|--------|----------|---------|
| `requirements.txt` | Python | `requests==2.25.1` |
| `pyproject.toml` | Python | Modern Python packaging |
| `package.json` | Node.js | npm/yarn packages |
| `pom.xml` | Java/Spring | Maven dependencies |
| `build.gradle` | Java/Spring | Gradle string-based dependencies |
| `build.gradle.kts` | Java/Spring | Kotlin DSL Gradle dependencies |
| `composer.json` | PHP | Composer dependencies |

## Project Structure

```
scanner/
├── src/dep_guard_mcp/
│   ├── __init__.py
│   ├── main.py              # MCP entry point (3 tools)
│   ├── scanner.py           # Dependency discovery logic
│   ├── advisories.py        # Vulnerability lookup
│   └── server.py            # Original server helpers
├── tests/
│   └── test_scanner.py      # Unit tests (7/7 passing ✓)
├── .venv/                   # Python 3.12 virtual environment
├── pyproject.toml           # Project config & dependencies
├── README.md                # This file
└── .github/
    └── copilot-instructions.md  # VS Code customization
```

## Testing

```bash
# Run all tests
pytest tests/ -v

# Run specific test
pytest tests/test_scanner.py::test_supported_files -v
```

## Development

### Add a New Tool

1. Open `src/dep_guard_mcp/main.py`
2. Add function with `@mcp.tool()` decorator:

```python
@mcp.tool()
def my_new_tool(param: str) -> dict:
    """Tool description."""
    return {"result": "data"}
```

3. Run tests: `pytest tests/`

### Next Steps for Enhancement

- [ ] Add NVD API integration (deeper CVE database)
- [ ] Improve Gradle parser for variable-based versions
- [ ] Improve Composer parser for complex version constraints
- [ ] Create VS Code extension wrapper
- [ ] Build GitHub Actions integration
- [ ] Add webhook support (Slack, Teams integration)

## Troubleshooting

### Scanner returns "No supported files found"
- Ensure your project has one of the supported dependency files
- Check file is in the scanned directory

### Import error when running
- Activate virtual environment: `.venv/Scripts/activate`
- Reinstall package: `pip install -e .`

## Performance

- Dependency discovery: < 100ms
- Vulnerability lookup: < 1-2 seconds (depends on file count)
- Supports projects with 100+ dependencies

## Contributing

Contributions welcome! Areas to contribute:
- Additional vulnerability data sources
- Performance optimizations
- Additional file format support
- Documentation improvements

## License

MIT - See LICENSE file for details

---

**🚀 Ready to publish to Claude Registry and monetize?** See the session notes for next steps!
