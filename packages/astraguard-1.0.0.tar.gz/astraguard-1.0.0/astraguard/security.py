"""
AstraGuard Python SDK - Security Utilities

Provides:
  - is_debugger_attached()  : detect common Python debuggers
  - get_hwid()              : deterministic, cross-platform hardware fingerprint
"""

from __future__ import annotations

import hashlib
import os
import platform
import sys
import uuid


# ---------------------------------------------------------------------------
# Debugger detection
# ---------------------------------------------------------------------------

def is_debugger_attached() -> bool:
    """
    Return True if a Python debugger is likely attached to this process.

    Checks performed (in order):
    1. sys.gettrace() - set by pdb, cProfile, coverage, and most debuggers
    2. PYTHONINSPECT environment variable - set by python -i / REPL mode
    3. debugpy module presence - VS Code debugger
    4. pydevd module presence - PyCharm / Eclipse debugger
    5. pdb module with active trace - standard library debugger
    """
    # 1. Trace function check (most reliable)
    if sys.gettrace() is not None:
        return True

    # 2. Interactive inspect mode
    if os.environ.get("PYTHONINSPECT"):
        return True

    # 3. VS Code / debugpy
    if "debugpy" in sys.modules:
        return True

    # 4. PyCharm / PyDev / Eclipse
    if "pydevd" in sys.modules:
        return True

    # 5. pdb with an active frame
    if "pdb" in sys.modules:
        import pdb as _pdb  # noqa: PLC0415
        if hasattr(_pdb, "current_frames"):
            try:
                if _pdb.current_frames():  # type: ignore[attr-defined]
                    return True
            except Exception:  # noqa: BLE001
                pass

    return False


# ---------------------------------------------------------------------------
# Hardware ID generation
# ---------------------------------------------------------------------------

def get_hwid() -> str:
    """
    Generate a deterministic hardware ID for this machine.

    Components used:
    - uuid.getnode()         : network interface MAC address
    - platform.node()        : hostname
    - platform.processor()   : CPU identifier

    The components are joined, hashed with SHA-256, and formatted as
    XXXX-XXXX-XXXX-XXXX (uppercase hex, first 16 hex chars) so that the
    result is compatible with the C++ and TypeScript SDKs.
    """
    mac_address = str(uuid.getnode())
    hostname = platform.node()
    processor = platform.processor()

    raw = f"{mac_address}:{hostname}:{processor}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()

    # Format as XXXX-XXXX-XXXX-XXXX (take first 16 hex chars)
    chunk = digest[:16]
    return "-".join(chunk[i:i + 4] for i in range(0, 16, 4))
