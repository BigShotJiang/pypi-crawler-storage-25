"""
AstraGuard Python SDK - Main Client
"""

from __future__ import annotations

import math
import sys
from datetime import datetime, timezone
from typing import Dict, List, Optional

try:
    import requests
    from requests import Response
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "The 'requests' library is required: pip install requests"
    ) from exc

from .models import LicenseInfo, LicenseResult
from .security import get_hwid, is_debugger_attached


class AstraGuardError(Exception):
    """Raised for all AstraGuard API and SDK errors."""

    def __init__(
        self,
        message: str,
        code: str = "UNKNOWN_ERROR",
        status_code: Optional[int] = None,
        details: Optional[object] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.details = details

    def __repr__(self) -> str:
        return f"AstraGuardError(code={self.code!r}, message={str(self)!r})"


class AstraGuard:
    """
    AstraGuard license management client.

    Usage::

        guard = AstraGuard(
            api_url="https://api.astraguard.io",
            product_id="your-product-uuid",
        )
        result = guard.validate("XXXX-XXXX-XXXX-XXXX")
        if result.valid:
            print("License OK")
    """

    DEFAULT_API_URL = "https://api.astraguard.io"
    DEFAULT_TIMEOUT = 10  # seconds

    def __init__(
        self,
        api_url: str,
        product_id: str,
        timeout: int = DEFAULT_TIMEOUT,
        debug: bool = False,
        version: Optional[str] = None,
    ) -> None:
        if not api_url:
            raise AstraGuardError("api_url is required", "INVALID_CONFIG")
        if not product_id:
            raise AstraGuardError("product_id is required", "INVALID_CONFIG")

        self._api_url = api_url.rstrip("/")
        self._product_id = product_id
        self._timeout = timeout
        self._debug = debug
        self._version = version
        self._cached_hwid: Optional[str] = None
        self._last_result: Optional[LicenseResult] = None

        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "X-Product-ID": self._product_id,
            "X-SDK-Language": "python",
        })

        self._log("AstraGuard SDK initialised", {"product_id": self._product_id})

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate(self, key: str, hwid: Optional[str] = None) -> LicenseResult:
        """
        Validate a license key against the AstraGuard API.

        Parameters
        ----------
        key:
            The license key string (e.g. ``VIZ-XXXX-XXXX-XXXX-XXXX``).
        hwid:
            Optional hardware ID.  When omitted the SDK generates one
            automatically via :func:`~astraguard.security.get_hwid`.

        Returns
        -------
        LicenseResult
            ``result.valid`` is ``True`` when the key is accepted.
        """
        self._log("Validating license...", {"key": self._mask_key(key)})
        hardware_id = hwid or self._get_hwid()

        payload: Dict[str, object] = {
            "key": key,
            "productId": self._product_id,
            "hwid": hardware_id,
        }
        if self._version:
            payload["version"] = self._version

        data = self._post("/validate", payload)
        result = self._parse_result(data)
        self._last_result = result
        return result

    def activate(self, key: str, hwid: Optional[str] = None) -> LicenseResult:
        """
        Activate a license key (binds the HWID on first use).

        Parameters
        ----------
        key:
            The license key string.
        hwid:
            Optional hardware ID.  Auto-generated when omitted.

        Returns
        -------
        LicenseResult
        """
        self._log("Activating license...", {"key": self._mask_key(key)})
        hardware_id = hwid or self._get_hwid()

        payload: Dict[str, object] = {
            "key": key,
            "productId": self._product_id,
            "hwid": hardware_id,
        }

        data = self._post("/activate", payload)
        result = self._parse_result(data)
        self._last_result = result
        return result

    def validate_or_exit(
        self,
        key: str,
        hwid: Optional[str] = None,
        message: Optional[str] = None,
        exit_code: int = 1,
    ) -> LicenseResult:
        """
        Validate a license and terminate the process if it is not valid.

        This is a convenience wrapper for desktop/CLI applications that
        should simply exit when a license check fails.

        Parameters
        ----------
        key:
            The license key to validate.
        hwid:
            Optional hardware ID.
        message:
            Custom message printed before exit.  Defaults to a generic
            "License invalid" message.
        exit_code:
            Exit status code passed to ``sys.exit()``.

        Returns
        -------
        LicenseResult
            Only returned when the license is valid.
        """
        result = self.validate(key, hwid=hwid)
        if not result.valid:
            reason = result.reason or "unknown"
            default_msg = f"License validation failed: {reason}"
            print(message or default_msg, file=sys.stderr)
            sys.exit(exit_code)
        return result

    def has_feature(self, feature: str) -> bool:
        """
        Check whether *feature* is enabled in the most recent validate/activate
        result.

        Returns ``False`` when no result has been cached yet.
        """
        if self._last_result is None:
            return False
        return self._last_result.has_feature(feature)

    def get_variable(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """
        Return the value of a remote variable from the most recent
        validate/activate result, or *default* when not found.

        Returns ``None`` when no result has been cached yet.
        """
        if self._last_result is None:
            return default
        return self._last_result.get_variable(key, default)

    def check_debug(self, exit_on_detect: bool = True) -> bool:
        """
        Run the anti-debug checks from :mod:`astraguard.security`.

        Parameters
        ----------
        exit_on_detect:
            When ``True`` (default) the process is terminated immediately
            if a debugger is detected.

        Returns
        -------
        bool
            ``True`` if a debugger is detected, ``False`` otherwise.
        """
        detected = is_debugger_attached()
        if detected:
            self._log("Debugger detected!")
            if exit_on_detect:
                sys.exit(1)
        return detected

    def get_hwid(self) -> str:
        """Return the cached (or freshly generated) hardware ID."""
        return self._get_hwid()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _get_hwid(self) -> str:
        if self._cached_hwid is None:
            self._cached_hwid = get_hwid()
            self._log("Generated HWID", {"hwid": self._cached_hwid})
        return self._cached_hwid

    def _post(self, path: str, payload: Dict[str, object]) -> Dict[str, object]:
        url = f"{self._api_url}{path}"
        self._log(f"POST {url}", payload)
        try:
            response: Response = self._session.post(
                url, json=payload, timeout=self._timeout
            )
        except requests.exceptions.Timeout as exc:
            raise AstraGuardError("Request timed out", "NETWORK_ERROR") from exc
        except requests.exceptions.ConnectionError as exc:
            raise AstraGuardError(
                f"Could not connect to {self._api_url}", "NETWORK_ERROR"
            ) from exc
        except requests.exceptions.RequestException as exc:
            raise AstraGuardError(str(exc), "NETWORK_ERROR") from exc

        return self._handle_response(response)

    def _handle_response(self, response: Response) -> Dict[str, object]:
        try:
            data: Dict[str, object] = response.json()
        except ValueError as exc:
            raise AstraGuardError(
                f"Invalid JSON response (HTTP {response.status_code})",
                "SERVER_ERROR",
                response.status_code,
            ) from exc

        if response.status_code == 503:
            raise AstraGuardError(
                "Service is under maintenance", "MAINTENANCE_MODE", 503
            )

        if not response.ok:
            error_msg = (
                data.get("error")        # type: ignore[assignment]
                or data.get("message")
                or f"HTTP {response.status_code}"
            )
            code = self._map_status_to_code(response.status_code)
            raise AstraGuardError(str(error_msg), code, response.status_code, data)

        # Unwrap envelope { success, data: {...} } if present
        if "data" in data and isinstance(data["data"], dict):
            return data["data"]  # type: ignore[return-value]
        return data

    @staticmethod
    def _map_status_to_code(status: int) -> str:
        mapping = {
            401: "UNAUTHORIZED",
            403: "LICENSE_REVOKED",
            404: "INVALID_LICENSE",
            429: "RATE_LIMITED",
            503: "MAINTENANCE_MODE",
        }
        return mapping.get(status, "SERVER_ERROR")

    @staticmethod
    def _parse_result(data: Dict[str, object]) -> LicenseResult:
        # Build optional LicenseInfo from nested "license" dict
        license_info: Optional[LicenseInfo] = None
        raw_license = data.get("license")
        if isinstance(raw_license, dict):
            license_info = LicenseInfo(
                id=str(raw_license.get("id", "")),
                key=str(raw_license.get("key", "")),
                product_id=str(raw_license.get("productId", "")),
                status=str(raw_license.get("status", "")),
                type=str(raw_license.get("type", "")),
                expires_at=raw_license.get("expiresAt"),  # type: ignore[arg-type]
                created_at=str(raw_license.get("createdAt", "")),
                activated_at=raw_license.get("activatedAt"),  # type: ignore[arg-type]
                hwid=raw_license.get("hwid"),  # type: ignore[arg-type]
                max_activations=int(raw_license.get("maxActivations", 1)),
                current_activations=int(raw_license.get("currentActivations", 0)),
            )

        # Resolve expires_at from the top-level or nested license
        expires_at: Optional[str] = (
            data.get("expiresAt")  # type: ignore[assignment]
            or (license_info.expires_at if license_info else None)
        )

        # Calculate remaining days
        remaining_days: Optional[int] = None
        if expires_at:
            try:
                expiry = datetime.fromisoformat(
                    expires_at.replace("Z", "+00:00")
                )
                now = datetime.now(tz=timezone.utc)
                diff_seconds = (expiry - now).total_seconds()
                remaining_days = max(0, math.ceil(diff_seconds / 86400))
            except (ValueError, AttributeError):
                pass

        # Features come as a list of names OR list of {name, enabled} dicts
        raw_features = data.get("features", [])
        features: List[str] = []
        if isinstance(raw_features, list):
            for f in raw_features:
                if isinstance(f, str):
                    features.append(f)
                elif isinstance(f, dict):
                    if f.get("enabled", True):
                        features.append(str(f.get("name", "")))

        variables: Dict[str, str] = {}
        raw_vars = data.get("variables")
        if isinstance(raw_vars, dict):
            variables = {str(k): str(v) for k, v in raw_vars.items()}

        return LicenseResult(
            valid=bool(data.get("valid", False)),
            reason=data.get("reason") or None,  # type: ignore[arg-type]
            message=data.get("message") or None,  # type: ignore[arg-type]
            expires_at=expires_at,
            features=features,
            variables=variables,
            license=license_info,
            remaining_days=remaining_days,
        )

    @staticmethod
    def _mask_key(key: str) -> str:
        if len(key) <= 8:
            return "****"
        return key[:4] + "****" + key[-4:]

    def _log(self, message: str, data: Optional[object] = None) -> None:
        if self._debug:
            suffix = f" {data}" if data else ""
            print(f"[AstraGuard] {message}{suffix}", file=sys.stderr)
