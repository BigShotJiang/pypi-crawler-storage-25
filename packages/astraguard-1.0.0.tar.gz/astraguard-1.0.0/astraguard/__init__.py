"""
AstraGuard Python SDK
~~~~~~~~~~~~~~~~~~~~~

License validation and management for software protected with AstraGuard.

Quick start::

    from astraguard import AstraGuard

    guard = AstraGuard(
        api_url="https://api.astraguard.io",
        product_id="your-product-uuid",
    )

    result = guard.validate("XXXX-XXXX-XXXX-XXXX")
    if result.valid:
        print("License accepted!")
    else:
        print(f"Rejected: {result.reason}")
"""

from .client import AstraGuard, AstraGuardError
from .models import LicenseInfo, LicenseResult
from .security import get_hwid, is_debugger_attached

__all__ = [
    "AstraGuard",
    "AstraGuardError",
    "LicenseResult",
    "LicenseInfo",
    "get_hwid",
    "is_debugger_attached",
]

__version__ = "1.0.0"
