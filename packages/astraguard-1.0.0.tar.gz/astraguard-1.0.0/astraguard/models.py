"""
AstraGuard Python SDK - Data Models
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class LicenseInfo:
    """Detailed license information returned by the API."""

    id: str
    key: str
    product_id: str
    status: str  # active | expired | revoked | frozen | unused | banned
    type: str    # perpetual | subscription | trial
    expires_at: Optional[str]
    created_at: str
    activated_at: Optional[str]
    hwid: Optional[str]
    max_activations: int
    current_activations: int


@dataclass
class LicenseResult:
    """Result returned from validate() and activate() calls."""

    valid: bool
    reason: Optional[str] = None
    message: Optional[str] = None
    expires_at: Optional[str] = None
    features: List[str] = field(default_factory=list)
    variables: Dict[str, str] = field(default_factory=dict)
    license: Optional[LicenseInfo] = None
    remaining_days: Optional[int] = None

    @property
    def is_expired(self) -> bool:
        return self.reason == "expired"

    @property
    def is_revoked(self) -> bool:
        return self.reason in ("revoked", "banned")

    @property
    def is_hwid_mismatch(self) -> bool:
        return self.reason == "hwid_mismatch"

    @property
    def needs_update(self) -> bool:
        return self.reason == "version_too_old"

    def has_feature(self, name: str) -> bool:
        """Check whether a named feature flag is present and enabled."""
        return name in self.features

    def get_variable(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Return the value of a remote variable, or *default* if not found."""
        return self.variables.get(key, default)
