# Changelog

## 0.1.0

- Add the `eventreg()` estimator for Sun-Abraham interaction-weighted event studies.
- Use `pyfixest.feols()` as the regression backend for high-dimensional fixed effects and covariance calculations.
- Support explicit relative-time columns, continuous controls, multiple fixed effects, manual binning, and manual heterogeneity columns.
- Add IW result methods: `tidy()`, `coef()`, `se()`, `vcov()`, `aggregate()`, `iplot_aggregate()`, `ate()`, `lincom()`, and `etable()`.
- Add count-share point weights and optional share-step covariance through `share_vcov`.
- Add parity checks against pyfixest saturated aggregation, Stata `eventstudyinteract`, and Julia `EventStudyInteracts.jl` where available.
- Add a usage-oriented agent skill for Codex, Claude Code, and similar coding agents.
