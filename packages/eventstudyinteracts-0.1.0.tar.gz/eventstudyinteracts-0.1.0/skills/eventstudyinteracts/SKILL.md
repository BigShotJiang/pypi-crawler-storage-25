---
name: eventstudyinteracts
description: Use when estimating Sun-Abraham interaction-weighted event studies in Python with EventStudyInteracts.py, including data preparation, eventreg formulas, control cohorts, binning, heterogeneity, plotting, ATE, lincom, and pyfixest-compatible options.
---

# EventStudyInteracts.py Usage

Use this skill to help users run `EventStudyInteracts.py`. This is a usage
skill, not a package-maintenance skill.

## Core Pattern

Import the package as:

```python
import eventstudyinteracts as esi
```

Estimate with:

```python
fit = esi.eventreg(
    "y ~ g_3 + g_2 + g0 + g1 + g2 | unit + year",
    data=df,
    cohort="first_treated",
    control_cohort="never_treated",
    vcov={"CRV1": "unit"},
)
```

Terms before `|` are the relative-time dummy columns to estimate. Fixed effects
go after `|`. Continuous controls go in `covariates=`.

## Data Preparation

1. Create a cohort column containing the first treated period for treated units.
2. Create a boolean control column such as `never_treated`.
3. Create event time, usually `rel_time = period - cohort`.
4. Create explicit 0/1 relative-time columns and omit the reference period,
   usually `-1`.

The `control_cohort` column is authoritative. Control units may have missing
cohort values or `0`; the estimate is correct as long as `control_cohort`
marks controls correctly.

For cross-package comparisons, use the same sample as the reference package.
For the `nlswork` example, keep never-treated workers and treated workers
observed in the omitted period `ry == -1`.

## Fixed Effects And Controls

Use pyfixest/fixest syntax:

```python
fit = esi.eventreg(
    "ln_wage ~ g_3 + g_2 + g0 + g1 | idcode + year + ind_code^year",
    data=df,
    cohort="first_union",
    control_cohort="never_union",
    covariates="south + tenure + age",
    vcov={"CRV1": "idcode"},
    demeaner_backend="numba",
)
```

Examples:

- `idcode + year`: unit and time fixed effects.
- `industry^year`: industry-by-year fixed effects.
- `province^year`: province-by-year fixed effects.

Do not put ordinary continuous controls in the event-study varlist before `|`.
Put them in `covariates=`.

## Binning And Heterogeneity

Binning and heterogeneity are manual. Create exactly the columns you want, then
put those columns in the formula.

```python
df["g_l4"] = df["ry"].le(-4).fillna(False).astype(int)
df["g1_collgrad1"] = (df["ry"].eq(1) & df["collgrad"].eq(1)).astype(int)
df["g1_collgrad0"] = (df["ry"].eq(1) & df["collgrad"].eq(0)).astype(int)
```

The estimator treats each supplied column as one event-study coefficient.
Columns should be 0/1 indicators and mutually exclusive within an observation.

## Results

Use:

```python
fit.tidy()
fit.coef()
fit.se()
fit.vcov()
fit.summary()
```

`eventreg()` already returns IW relative-time estimates. `fit.aggregate()` is
a pyfixest-compatible alias for the same period estimates, not a required
second estimation step.

Plot with:

```python
fit.iplot_aggregate()
```

Save the plot with:

```python
ax = fit.iplot_aggregate(show=False)
ax.figure.savefig("eventstudy.png", dpi=200, bbox_inches="tight")
```

## ATE And Lincom

`ate()` and `lincom()` use the IW covariance matrix:

```text
estimate = a' beta_iw
standard error = sqrt(a' V_iw a)
```

For simple names such as `g0`, `g1`, and `g18`, `fit.ate()` averages all
nonnegative periods.

```python
fit.ate(name="ATE_post")
fit.ate(["g0", "g1", "g2", "g3", "g4"], name="ATE_g0_g4")
fit.lincom({"g3": 1.0, "g0": -1.0}, name="g3_minus_g0")
```

For binned or heterogeneous names, pass the exact coefficient names to
`ate()`.

## Inference Conventions

Point IW weights use count shares. For valid 0/1 mutually exclusive event-time
columns, count shares and share-regression point weights are the same
mathematical weights.

Use the default:

```python
share_vcov="regression"
```

This adds the share-step covariance term. Use `share_vcov="none"` only when
the goal is to match pyfixest saturated `aggregate()` standard errors in the
unit/time fixed-effect benchmark.

## Common Pitfalls

- Do not call pyfixest saturated `aggregate()` for an `eventreg()` result with
  extra fixed effects or controls. Use `fit.aggregate()`, `fit.ate()`, and
  `fit.lincom()`.
- Do not generate overlapping event-time columns unless the overlap is an
  intentional heterogeneity design; the package expects supplied event columns
  to be valid 0/1 indicators.
- Do not compare Stata `eventstudyinteract` two-way-cluster `e(V_iw)` as the
  standard-error truth in the single-cohort diagnostic. The target there is
  direct pyfixest/TWFE and the fixed Julia implementation.
