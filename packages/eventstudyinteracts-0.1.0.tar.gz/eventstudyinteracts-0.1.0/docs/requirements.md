# EventStudyInteracts.py 需求文档

## 1. 项目目标

本项目要做一个 Python 版 `EventStudyInteracts`：借鉴
`EventStudyInteracts.jl` 对 Stata `eventstudyinteract` 的三步
interaction-weighted (IW) 估计流程，但底层回归、固定效应吸收、协方差和
性能能力都交给 `pyfixest`。

一句话目标：

> 提供一个 `eventreg(...)`，让用户用接近 `pyfixest.feols(...)` 的方式估计
> Sun and Abraham (2021) IW event-study，并保留 `pyfixest` 的 demeaner 后端、
> 高维固定效应、推断、压缩估计和分样本能力。

## 2. 上游约束

- `EventStudyInteracts.jl` 的核心入口是 `eventreg(df, formula, rel_varlist,
  control_cohort, cohort, vcov; ...)`。
- Julia 版通过 `FixedEffectModels.reg(...)` 拟合第一步交互回归，并将
  `method`、`nthreads`、`tol`、`maxiter`、`weights`、`drop_singletons` 等
  后端参数透传。
- Python 版应以 `pyfixest.feols(...)` 为唯一高维固定效应回归后端。
- 本项目当前以 `pyfixest>=0.50.1` 为基线，`feols` 暴露了
  `demeaner_backend`：`numba`、`rust`、`rust-cg`、`jax`、`cupy`、
  `cupy32`、`cupy64`、`scipy`。
- `pyfixest` 已有 `event_study(..., estimator="saturated")`，适合内置的
  unit/time fixed-effect event-study。它的公共接口不提供类似
  `feols("y ~ ... | fe1 + fe2 + fe3")` 的任意 absorbed fixed effects 写法。
  本项目不替代它，而是补足 Stata/Julia `eventstudyinteract` 风格的显式相对期
  列、多维/交互固定效应、连续控制变量、binning、异质性和 IW 线性组合。

## 3. 功能需求

### R1. 公共 API

必须提供主函数：

```python
eventreg(
    fml,
    data,
    rel_varlist=None,
    cohort=None,
    control_cohort=None,
    vcov=None,
    *,
    covariates=None,
    vcov_kwargs=None,
    weights=None,
    ssc=None,
    fixef_rm="singleton",
    fixef_tol=1e-6,
    fixef_maxiter=10_000,
    collin_tol=1e-6,
    drop_intercept=False,
    copy_data=True,
    store_data=True,
    lean=False,
    weights_type="aweights",
    solver="scipy.linalg.solve",
    demeaner_backend="numba",
    use_compression=False,
    reps=100,
    context=None,
    seed=None,
    split=None,
    fsplit=None,
    stage2_vcov="inherit",
    fixef_vcov_correction="pyfixest",
    keep_interacted_model=True,
    share_vcov="regression",
)
```

说明：

- `fml` 使用 `pyfixest`/`fixest` 公式语法，如
  `"ln_wage ~ g_4 + g_3 + g_2 + g0 + g1 | idcode + year"`。
  `|` 前面是 Stata `eventstudyinteract` 的相对期变量列表；输出顺序就是用户的
  书写顺序。
- `covariates` 对应 Stata `covariates()`，例如 `"south + tenure + age"`。
  控制变量和 `|` 后面的 fixed effects 原样交给 pyfixest。
- `rel_varlist` 只作为旧接口兼容参数保留；正常公共用法不需要写。若传入，
  它必须和 `fml` 中 `|` 前的相对期列一致。
- `cohort` 是首次处理时间 cohort 列；`control_cohort` 是是否对照组的权威
  判断。为了兼容 Stata/Julia 和 pyfixest，控制组的 `cohort` 可以是缺失值，
  也可以是 `0`；只要 `control_cohort` 标记正确，就不能进入 treated cohort
  列表。
- `control_cohort` 是控制组二元列，可以表示 never-treated 或 last-treated
  控制组。last-treated 作为控制组时，控制行可以保留真实 cohort 值，但必须
  由 `control_cohort` 标记并由用户限制到处理前样本。
- 所有 `pyfixest.feols` 后端参数必须透传，不能被本包装层吞掉。

### R2. IW 估计流程

必须实现 Sun-Abraham IW 三步：

1. 第一阶段：为每个相对时间 dummy 生成控制组置零版本，再与每个 treated
   cohort 交互，使用 `pyfixest.feols` 拟合交互回归。
2. 第二阶段：在 treated 样本内计算每个 cohort 在每个相对时间的 count-share
   权重；对标准互斥 0/1 相对期列，这与 share regression 系数相同。
3. 第三阶段：对第一阶段 cohort-by-relative-time 系数按第二阶段权重加权，
   生成 IW 系数和 delta-method 协方差矩阵。
4. `share_vcov="regression"` 时用 pyfixest share regression 协方差加入
   `delta' V_share delta`；`share_vcov="none"` 时只保留 `R V_delta R'`，
   对齐 pyfixest saturated aggregate 的推断口径。

### R3. 结果对象

结果对象应尽量贴近 `pyfixest` 的用户体验：

- `coef()`：返回 IW 系数。
- `se()`：返回 IW 标准误。
- `vcov()`：返回 IW 协方差矩阵。
- `tidy()`：返回含 `Estimate`、`Std. Error`、`t value`、`Pr(>|t|)`、
  confidence interval 的 `pandas.DataFrame`。
- `summary()`：打印/返回类似 `pyfixest` 的估计摘要。
- `confint()`、`tstat()`、`pvalue()`：提供常用推断方法。
- `aggregate(agg="period", weighting="shares")`：与 pyfixest saturated
  `aggregate()` 命名兼容；由于主输出已经是 IW period estimates，此方法只是
  `tidy()` 的 period-index 兼容别名，不是第二次加总。
- `lincom(weights, name=...)`：对 IW 系数做任意线性组合，点估计为 `a'b`，
  标准误为 `sqrt(a' V_iw a)`。
- `ate(periods=None, weights=None, name="ATE")`：不传 `periods` 时，自动平均
  可解析名称中的非负相对期；对用户显式选定的 period estimates 做 ATE/ATT 型
  平均；默认等权，传入权重时默认归一化为和为 1。
- `interacted_model_`：保存第一阶段 `pyfixest` 模型，除非 `lean=True`。
- `stage2_models_` 或 `stage2_diagnostics_`：保存 cohort-share 估计诊断。
- `iw_weights_`、`delta_`、`aggregation_matrix_`、`rel_varlist_`、
  `cohort_list_`：暴露可审计中间量。

### R4. pyfixest 特性保留

以下能力必须保留为一等功能：

- Demeaning 算法/后端选择：`demeaner_backend` 必须原样传给
  `pyfixest.feols`，并在文档中列明 `numba`、`rust`、`jax`、`cupy`、
  `cupy32`、`cupy64`、`scipy` 的适用场景。
- 收敛控制：`fixef_tol`、`fixef_maxiter` 必须透传。
- 固定效应样本处理：`fixef_rm` 必须透传。
- 推断：`vcov`、`vcov_kwargs`、`ssc` 必须透传至第一阶段；第二阶段
  cohort-share 回归也由 `pyfixest.feols` 估计，IW 包装层只补 pyfixest 未暴露的
  cross-equation delta-method 协方差。
- 标准误：默认 `fixef_vcov_correction="pyfixest"`，即保留第一阶段
  pyfixest 原生 `_vcov` 缩放；`"full"` 可显式使用 saturated Sun-Abraham
  方程的完整 absorbed-FE 小样本自由度校正，用于 Julia 修正版口径对照。
- 权重：`weights`、`weights_type` 必须透传；第二阶段 share 估计必须明确处理
  加权样本。
- 性能：`solver`、`use_compression`、`copy_data`、`store_data`、`lean` 必须可用。
- 分样本：`split`、`fsplit` 不能被忽略；若返回多模型，应提供
  `EventStudyInteractMulti` 或与 `pyfixest.FixestMulti` 类似的容器。

### R5. 协方差需求

MVP 必须支持：

- `"iid"`
- `"hetero"` / `"HC1"`
- `{"CRV1": "cluster_var"}`
- `{"CRV1": "cluster1 + cluster2"}`

后续增强：

- `"HC2"`、`"HC3"`
- `{"CRV3": ...}`
- `"NW"`、`"DK"` 等 HAC 协方差

如果第一阶段 `pyfixest` 已支持某种 `vcov`，但第二阶段 share 协方差还未支持，
必须明确报错或降级提示，不能静默返回不完整标准误。

### R6. 数据处理

- 输入数据可以是 pandas DataFrame；polars/narwhals 兼容作为后续增强。
- 默认 `copy_data=True`，避免在用户数据上新增临时列。
- 临时列必须带唯一前缀，避免和用户列名冲突。
- 公式中 `|` 前的全零或不可估计列应按 Julia 版逻辑处理：保留输出位置，但
  系数为 `0`、协方差为 `NaN` 或清晰标记不可估计。
- `cohort` 排序应稳定，缺失、`0` 编码的 pyfixest-style control rows、以及所有
  `control_cohort=True` 行都不进入 treated cohort 列表。
- binning 和异质性遵循 Stata/Julia 工作流：用户自行生成 bin 后或组别交互后的
  relative-time dummy，并把这些列显式写进公式中 `|` 前；估计器不再额外包装一套
  binning/heterogeneity DSL。

### R7. 验证需求

必须至少覆盖：

- 单 cohort 情况下，系数和标准误默认与直接 `pyfixest.feols(...)`
  event-study 回归一致，包括 `id + time` 双向固定效应和两维聚类；
  `fixef_vcov_correction="full"` 单独覆盖 saturated Sun-Abraham 完整自由度
  口径。
- `eventreg("y ~ rel0 + rel1 | fe1 + fe2 + fe3", covariates="x1 + x2")`
  这类连续控制变量和多维固定效应组合必须能运行，并与
  saturated/interacted 第一阶段方程一致。
- never-treated 的 cohort 取缺失值或 `0` 时，只要 `control_cohort` 一致，估计
  结果必须一致。
- 手动 binning 和手动异质性 relative-time 列必须能按公式中 `|` 前的顺序原样估计。
- 多 cohort 合成数据的手算 IW 权重与结果一致。
- 与 `EventStudyInteracts.jl` 的 `nlswork` 示例基准对齐。
- never-treated 控制组和 last-treated 控制组都能运行。
- `lincom()` / `ate()` 的点估计和标准误必须等于手工矩阵公式
  `a'b` 与 `sqrt(a'Va)`。
- `demeaner_backend` 至少覆盖 `numba`、`rust`、`scipy`，并在可用环境覆盖
  `jax`/`cupy`。
- `use_compression=True` 的限制和性能收益有独立测试或文档说明。

## 4. 非功能需求

- 项目结构必须是标准 `src/` 布局。
- 公开 API 应尽量稳定，内部临时列命名和中间矩阵不进入用户命名空间。
- 代码应优先复用 `pyfixest`、`numpy`、`pandas` 的成熟能力，不新增重型依赖。
- 性能目标：第一阶段回归不比直接调用 `pyfixest.feols` 多引入显著常数开销；
  交互列构造和权重矩阵计算应使用向量化或稀疏/分块策略。
- 文档必须诚实区分已实现、计划中和不支持。

## 5. 暂不纳入 MVP

- 自动生成相对时间 dummy。
- 自动强制 balanced panel。
- 复刻 Stata 输出格式的所有细节。
- 所有 `pyfixest.event_study` 绘图能力。
- 自动发布 PyPI。
