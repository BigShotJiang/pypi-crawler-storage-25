# 开发工作流

## 1. 本地环境

For maintainers:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

说明：

- `python -m pip install -e ".[dev]"` 是开发/测试用，不是普通用户安装命令。
- `-e` 是 editable install，表示从当前源码目录安装，改源码后不需要重新安装。
- `[dev]` 只安装开发工具：`pytest` 和 `ruff`。
- 运行 estimator 需要 Python 3.10+ 与 `pyfixest>=0.50.1`。
- GPU/JAX 后端由 `pyfixest` 可选依赖决定，本项目不直接强制安装。

## 2. 日常检查

```bash
python -m ruff check .
python -m ruff format --check .
python -m pytest
python -m compileall src
python scripts/check_external_parity.py
```

外部 parity 脚本会在本机有 R/fixest 时检查 R Sun-Abraham fixture，在有
Stata/eventstudyinteract 时检查 Stata fixture，在有 Julia 和
`EventStudyInteracts.jl` 项目路径时检查 Julia fixture。Julia 项目默认路径是
`/tmp/EventStudyInteracts.jl`，也可以用 `EVENTSTUDYINTERACTS_JL_PATH` 覆盖。
脚本会先检查单 cohort 双向固定效应 fixture 默认口径是否与直接
`pyfixest.feols(...)` 完全一致，包括两维聚类。随后用
`fixef_vcov_correction="full"` 检查 saturated/full-FE 口径下的 `simple`、
`robust` 和按 `unit` 聚类的完整 `V_iw`。Stata `eventstudyinteract` 的
`e(V_iw)` 在这个单 cohort 诊断中只报告 `EXPECTED_DIFF`，因为该路径没有匹配
直接 TWFE/saturated full-FE 的协方差目标；不要把 Stata 的 `e(V_iw)` 当作这个
标准误检查的真值。

## 3. 开发顺序

1. 先写/更新测试，尤其是单 cohort 等价测试。
2. 再改实现。
3. 保持 `pyfixest` 参数透传测试同步更新。
4. 对每个新支持的 `vcov` 增加 share 协方差测试。
5. 如果新增性能声明，同步更新 `benchmarks/` 输出。

## 4. 代码风格

- 标准 `src/` 布局。
- 公共 API 类型提示清楚，但不为了 typing 引入复杂抽象。
- 内部临时列统一 `__esi_` 前缀，并检测冲突。
- 尽量调用 `pyfixest` 公开接口；只有必要时读取受保护属性，并在代码中注释原因。
- 不新增重型依赖；优先使用 `pyfixest` 已经依赖的 `numpy`、`pandas`、`scipy`。
