# GitHub 工作流

## 1. 当前本机状态

- 当前目录初始时不是 git 仓库。
- 本机暂未发现 `gh` 命令。
- 因此 GitHub 登录/授权不能直接走 `gh auth login`，需要：
  - 安装 GitHub CLI 后授权；或
  - 在 GitHub 网页创建仓库后，用 HTTPS/SSH remote 推送。

## 2. 建议仓库

- Owner: `xiaobaaaa`
- Repository: `EventStudyInteracts.py`
- Visibility: 由项目主人决定，初期建议 private，等 API 和 reference 稳定后再公开。
- Default branch: `main`

## 3. 不通过 CLI 的上传流程

1. 在 GitHub 网页创建空仓库，不要勾选 README/license/gitignore。
2. 本地初始化：

   ```bash
   git init
   git branch -M main
   git add .
   git commit -m "Establish the Python project contract for IW event studies"
   ```

3. 添加 remote：

   ```bash
   git remote add origin git@github.com:xiaobaaaa/EventStudyInteracts.py.git
   ```

   或 HTTPS：

   ```bash
   git remote add origin https://github.com/xiaobaaaa/EventStudyInteracts.py.git
   ```

4. 推送：

   ```bash
   git push -u origin main
   ```

## 4. 安装 GitHub CLI 后的流程

```bash
brew install gh
gh auth login
gh repo create xiaobaaaa/EventStudyInteracts.py --private --source=. --remote=origin --push
```

注意：

- 不要把 personal access token 写入聊天或文档。
- 如果浏览器弹出授权页面，由项目主人在浏览器内完成授权。
- 如果使用 SSH，需先确认本机 SSH key 已加入 GitHub。

## 5. 仓库维护规则

- 每个 PR 必须跑 CI。
- estimator 行为变更必须包含 regression tests。
- 性能声明必须配 benchmark 脚本和输出。
- commit message 建议使用本工作区 AGENTS.md 里的 Lore Commit Protocol。
