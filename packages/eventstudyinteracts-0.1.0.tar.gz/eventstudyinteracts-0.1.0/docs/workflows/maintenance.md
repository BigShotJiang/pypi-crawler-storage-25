# 维护工作流

## 1. 每周检查

每周检查一次：

- `pyfixest` 最新 PyPI 版本。
- `pyfixest` `feols` 参数是否变化。
- `pyfixest` demeaner backend 是否新增/弃用。
- `EventStudyInteracts.jl` 是否有行为或 reference 更新。

## 2. 上游升级流程

1. 阅读 `pyfixest` changelog 和 `feols` 签名变化。
2. 更新本项目的兼容版本范围。
3. 运行完整测试。
4. 运行 reference parity。
5. 运行 benchmark。
6. 更新 README 和 `docs/design/upstream-analysis.md`。

## 3. 不能静默改变的行为

- `eventreg(...)` 参数默认值。
- 公式 RHS 中 relative-time varlist 的输出顺序。
- `vcov` 默认值。
- `demeaner_backend` 透传语义。
- 不可估计项的标记方式。
- `split`/`fsplit` 返回结构。

## 4. Release Gate

一次 release 至少需要：

- CI 通过。
- 单 cohort 等价测试通过。
- 多 cohort 合成测试通过。
- reference baseline 通过。
- 文档示例可运行。
- 已知不支持项写入 README 或 release notes。
