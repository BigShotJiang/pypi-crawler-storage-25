# 发布工作流

## 1. 版本阶段

- `0.0.x`：骨架和内部 API，不承诺 estimator 完成。
- `0.1.0`：单 cohort 等价和基础多 cohort IW estimator。
- `0.2.0`：CRV1 share 协方差和 reference parity。
- `0.3.0`：`split`/`fsplit`、压缩估计、更多后端验证。
- `1.0.0`：API 稳定，文档和 reference coverage 足够公开使用。

## 2. Release Checklist

- 更新 `CHANGELOG.md`。
- 更新版本号。
- 确认 `pyproject.toml` 和 `src/eventstudyinteracts/_version.py` 版本一致。
- 运行：

  ```bash
  python -m ruff check .
  python -m ruff format --check .
  python -m pytest
  python -m compileall src
  python -m build
  python -m twine check dist/*
  ```

- 运行 reference parity。
- 在 PyPI 配置 Trusted Publisher。
- 推 tag 并创建 GitHub Release。

## 2.1 PyPI / pip

当前用户安装命令是 GitHub URL：

```bash
python -m pip install "git+https://github.com/xiaobaaaa/EventStudyInteracts.py.git"
```

要支持直接按包名安装，需要先发布 PyPI：

```bash
python -m pip install eventstudyinteracts
```

本仓库使用 GitHub Actions + PyPI Trusted Publishing 发布，不在 GitHub 里保存
PyPI API token。PyPI 项目首次发布前，在 PyPI 账户里添加 pending publisher：

```text
PyPI project name: eventstudyinteracts
Owner: xiaobaaaa
Repository name: EventStudyInteracts.py
Workflow file: publish.yml
Environment: pypi
```

然后在 GitHub 仓库 Settings -> Environments 创建 `pypi` environment。发布时：

```bash
git tag v0.1.0
git push origin v0.1.0
```

再在 GitHub 创建 `v0.1.0` Release。`.github/workflows/publish.yml` 会构建
sdist/wheel，运行 `twine check`，并通过 Trusted Publishing 上传到 PyPI。

当前只准备发布 PyPI；pip 是唯一公开安装路径。其他包管理器渠道暂不安排。

## 3. Release Notes 必须包含

- 新增/修改的 estimator 行为。
- 支持的 `vcov` 类型。
- 支持的 `demeaner_backend` 测试矩阵。
- 与 `pyfixest` 的兼容版本。
- 已知限制。
