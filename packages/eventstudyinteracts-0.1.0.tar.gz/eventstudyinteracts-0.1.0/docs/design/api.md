# API 设计草案

## 1. 命名

- GitHub 仓库建议名：`EventStudyInteracts.py`
- Python 包名：`eventstudyinteracts`
- 主函数：`eventreg`
- 主结果对象：`EventStudyInteract`
- 多模型结果对象：`EventStudyInteractMulti`

## 2. 主函数

```python
import eventstudyinteracts as esi

fit = esi.eventreg(
    "ln_wage ~ g_4 + g_3 + g_2 + g0 + g1 + g2 + g3 | idcode + year",
    data=df,
    cohort="first_union",
    control_cohort="never_union",
    covariates="south + tenure + age",
    vcov={"CRV1": "idcode"},
    demeaner_backend="rust",
)
```

### 2.1 签名

```python
def eventreg(
    fml: str,
    data,
    rel_varlist: Sequence[str] | None = None,
    cohort: str | None = None,
    control_cohort: str | None = None,
    vcov: VcovSpec | None = None,
    *,
    covariates: str | Sequence[str] | None = None,
    vcov_kwargs: dict[str, str | int] | None = None,
    weights: str | None = None,
    ssc: dict[str, str | bool] | None = None,
    fixef_rm: Literal["singleton", "none"] = "singleton",
    fixef_tol: float = 1e-6,
    fixef_maxiter: int = 10_000,
    collin_tol: float = 1e-6,
    drop_intercept: bool = False,
    copy_data: bool = True,
    store_data: bool = True,
    lean: bool = False,
    weights_type: Literal["aweights", "fweights"] = "aweights",
    solver: SolverSpec = "scipy.linalg.solve",
    demeaner_backend: DemeanerBackendSpec = "numba",
    use_compression: bool = False,
    reps: int = 100,
    context: int | Mapping[str, Any] | None = None,
    seed: int | None = None,
    split: str | None = None,
    fsplit: str | None = None,
    stage2_vcov: Literal["inherit"] | VcovSpec = "inherit",
    share_vcov: Literal["regression", "none"] = "regression",
    fixef_vcov_correction: Literal["full", "pyfixest"] = "pyfixest",
    keep_interacted_model: bool = True,
) -> EventStudyInteract | EventStudyInteractMulti:
    ...
```

### 2.2 参数原则

- `fml` 遵从 pyfixest 公式语法。`|` 前面写 Stata
  `eventstudyinteract` 的相对期变量列表：
  `Y ~ relative-time variables | fixed effects`。
- `covariates` 对应 Stata 的 `covariates()`，用同样的公式片段写法，例如
  `"south + tenure + age"`。这些控制变量和 `|` 后固定效应原样传给 pyfixest。
- `rel_varlist` 仅作为旧接口兼容参数保留；公开示例不要求用户传。正常情况下
  `eventreg` 从 `fml` 中 `|` 前自动读取 relative-time 变量，并按用户书写顺序输出。
- `control_cohort` 是控制组的权威标记；`cohort` 对控制组可以是缺失值、
  `0`，或 last-treated 场景下的真实 cohort 值，只要 `control_cohort` 正确。
- binning 和异质性通过用户显式构造相对期列完成，例如 `rel_le_m4`、
  `rel0_high`、`rel0_low`；把这些列写进公式中 `|` 前即可，`eventreg` 不额外生成
  一套 DSL。
- 其余参数尽量保持 `pyfixest.feols(...)` 名称和默认值。
- `stage2_vcov="inherit"` 表示第二阶段 share 协方差默认跟随第一阶段
  `vcov`。
- `share_vcov="regression"` 是默认值，表示在 IW 协方差里加入 share-step
  covariance；`"none"` 表示把 share 当作固定权重，用来和 pyfixest saturated
  `aggregate()` 做严格标准误对比。
- `fixef_vcov_correction="pyfixest"` 是默认值，表示保留第一阶段 pyfixest
  `_vcov` 的原生小样本校正；`"full"` 显式使用 saturated Sun-Abraham 方程的
  完整 absorbed-FE 自由度口径。
- `keep_interacted_model` 只影响是否保存第一阶段模型，不影响估计。

## 3. 结果对象

### 3.1 用户方法

```python
fit.coef()
fit.se()
fit.vcov()
fit.tidy()
fit.summary()
fit.confint(level=0.95)
fit.tstat()
fit.pvalue()
fit.ate()
fit.ate(["g0", "g1", "g2", "g3"], name="ATE_g0_g3")
fit.lincom({"g3": 1.0, "g0": -1.0}, name="g3_minus_g0")
fit.iplot_aggregate()
```

`aggregate(agg="period", weighting="shares")` 与 pyfixest saturated event-study
的 period aggregation 命名保持兼容。由于 `eventreg(...)` 的主输出已经是
IW period estimates，`aggregate()` 是 `tidy()` 的兼容别名，不是第二次加总。
`ate()` 不传 period 时会自动平均可解析名称中的非负相对期，例如 `g0:g18`；
binning 或异质性列应显式传入 period 列表。更一般的 ATE 或异质性差异应使用
`ate()` / `lincom()`：

```text
lincom estimate = a' beta_iw
lincom variance = a' V_iw a
```

IW 点估计权重使用 count share。`share_vcov="regression"`（默认）在
`V_iw` 中加入 share regression 的协方差项；`share_vcov="none"` 只使用
`R V_delta R'`，用于和 pyfixest saturated aggregate 的标准误做严格对比。

### 3.2 可审计属性

```python
fit.rel_varlist_
fit.cohort_list_
fit.iw_weights_
fit.delta_
fit.aggregation_matrix_
fit.interacted_model_
fit.stage2_models_
fit.esample_
fit.demeaner_backend_
fit.vcov_spec
```

### 3.3 `tidy()` 输出

`tidy()` 返回 `pandas.DataFrame`，索引或 `term` 列为公式中 `|` 前
relative-time variables 的书写顺序：

| term | estimate | std_error | statistic | p_value | conf_low | conf_high |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `g_4` | ... | ... | ... | ... | ... | ... |

## 4. 公式构造

用户传入：

```python
fml = "y ~ g_2 + g0 + g1 | id + year"
covariates = "x1 + x2"
event_vars = ["g_2", "g0", "g1"]
cohort_list = [1980, 1981]
```

内部第一阶段生成临时列：

```text
__esi_n_g_2
__esi_n_g0
__esi_n_g1
__esi_n_g_2_x_1980
__esi_n_g_2_x_1981
...
```

第一阶段公式：

```text
y ~ __esi_n_g_2_x_1980 + __esi_n_g_2_x_1981 + ... + x1 + x2 | id + year
```

注意：

- 临时列前缀默认 `__esi_`，若冲突则生成更长随机/计数前缀。
- 公式拆分应使用稳健 parser 或严格的 formula section splitter，不能只做
  脆弱字符串拼接。

## 5. Stage 2 与 pyfixest

第二阶段 cohort-share 回归使用 `pyfixest.feols` 的多因变量公式：

```text
share_1980 + share_1981 + ... ~ 0 + n_rel0 + n_rel1 + ...
```

对角协方差块直接来自每个 pyfixest share 模型的 `_vcov`。由于 pyfixest 当前不
公开多方程交叉协方差，包装层只使用 `_bread`、`_scores` 和 CRV1 meat 函数拼接
delta-method 需要的 cross-equation blocks。
如果 pyfixest 模型暴露了额外系数（例如旧版本或公式差异导致的 intercept），
share covariance 会先按相对期变量对应的内部列名做子集和重排，避免聚合块
错位。

## 6. Split / Fsplit

`split` 或 `fsplit` 存在时，`eventreg(...)` 应返回
`EventStudyInteractMulti`：

```python
fits = eventreg(..., split="region")
fits.keys()
fits["east"].tidy()
fits.summary()
```

当前实现会逐组调用 `eventreg(...)`，并用 `"all"` 键保存 `fsplit` 的全样本结果。

## 7. 与 pyfixest 保持一致的错误策略

- 后端参数非法时，让 `pyfixest` 自身报错。
- 本项目只在 IW 语义层报错，如缺少公式中 `|` 前对应的 relative-time 列、没有 treated cohort、
  第二阶段无法支持给定 `vcov`。
- 不在包装层吞掉 `pyfixest` warnings。
