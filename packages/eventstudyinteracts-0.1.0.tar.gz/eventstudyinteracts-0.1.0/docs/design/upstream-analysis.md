# 上游实现分析

本文件记录第一轮只读分析结果，供后续实现时查证。

## 1. EventStudyInteracts.jl

来源：

- GitHub: <https://github.com/xiaobaaaa/EventStudyInteracts.jl>
- 本地临时源码分析目录：`/tmp/EventStudyInteracts.jl`

核心结论：

- 包的目标是复刻 Stata `eventstudyinteract`，实现 Sun and Abraham (2021)
  interaction-weighted estimator。
- Julia 版的主入口是 `eventreg(...)`，最终调用
  `StatsAPI.fit(EventStudyInteract, ...)`。
- 它依赖 `FixedEffectModels.reg(...)` 实现高维固定效应，相当于把 Stata
  `reghdfe` 这层换成 Julia 后端。

### 1.1 估计流程

Julia 版 `eventfit.jl` 的关键路径：

1. 对每个相对时间变量 `l` 生成 `n<l>`：
   - 初始复制 `l`。
   - 对 `control_cohort == 1` 的观察置零。
2. 删除全零的相对时间列。
3. 从非控制组样本中取 `cohort` 唯一值并排序。
   - Python 版保持这个语义：`control_cohort` 是权威标记，因此控制组
     `cohort` 可以是 Stata/Julia 风格的缺失值，也可以是 pyfixest 风格的 `0`。
4. 为每个 `n<l>` 和每个 cohort 生成交互项：
   - `n<l>_<cohort> = 1{cohort == yy} * n<l>`。
5. 构造第一阶段公式：
   - `lhs ~ all_interactions + covariates | fixed effects`
6. 用 `FixedEffectModels.reg(...)` 拟合第一阶段。
7. 根据第一阶段协方差矩阵判断估计后仍不可估计的相对时间。
8. 在第一阶段估计样本内，使用 treated observations 估计 cohort shares：
   - 对每个 cohort，回归 `cohort_ind ~ rel_varlist + 0`。
9. 将第一阶段系数 reshape 为 `ncohort x nrel_times` 矩阵。
10. 用第二阶段 share 权重对 cohort-specific 系数加权。
11. 用 delta method 合成：
    - 第一阶段交互系数不确定性。
    - 第二阶段 cohort-share 估计不确定性。
12. 将被删除的相对时间位置重新插回输出。

### 1.2 需要保留的行为

- 单 cohort 时，权重为 1，share 协方差为 0；结果应退化为直接 event-study
  回归。
- 相对时间列不可估计时，不应改变用户传入的输出顺序。
- 结果对象应保存第一阶段模型，便于检查 residuals、FE、迭代次数等后端诊断。
- 控制组可以是 never-treated 或 last-treated；last-treated 控制组需要用户
  自行排除其处理后的时期。

### 1.3 Julia 参数到 Python 参数的映射

| Julia / FixedEffectModels | Python / pyfixest |
| --- | --- |
| `formula` | `fml: str` |
| `df` | `data` |
| `rel_varlist::Vector{Symbol}` | `fml` RHS 的 relative-time varlist |
| `control_cohort::Symbol` | `control_cohort: str` |
| `cohort::Symbol` | `cohort: str` |
| `vcov` | `vcov`, `vcov_kwargs`, `ssc` |
| `weights` | `weights`, `weights_type` |
| `method`, `nthreads`, `double_precision` | `demeaner_backend`, `solver`, optional GPU backends |
| `tol`, `maxiter` | `fixef_tol`, `fixef_maxiter` |
| `drop_singletons` | `fixef_rm` |
| `save` | `store_data`, `lean`, result internals |

## 2. pyfixest

来源：

- GitHub: <https://github.com/py-econometrics/pyfixest>
- Docs: <https://pyfixest.org/>
- Local package inspected: `pyfixest==0.50.1`

### 2.1 `feols` 是本项目核心后端

`pyfixest.feols(...)` 当前关键参数：

```python
feols(
    fml,
    data,
    vcov=None,
    vcov_kwargs=None,
    weights=None,
    ssc=None,
    fixef_rm="singleton",
    fixef_tol=1e-06,
    fixef_maxiter=10_000,
    collin_tol=1e-09,
    drop_intercept=False,
    copy_data=True,
    store_data=True,
    lean=False,
    weights_type="aweights",
    solver="scipy.linalg.solve",
    demeaner_backend="numba",
    use_compression=False,
    reps=100,
    context=None,
    seed=None,
    split=None,
    fsplit=None,
)
```

### 2.2 Demeaner 后端

`pyfixest.estimation.backends.BACKENDS` 暴露：

- `numba`：默认 CPU alternating projections。
- `rust`：Rust 实现的 CPU alternating projections。
- `rust-cg`：Rust conjugate-gradient-schwarz 后端，适合困难稀疏固定效应。
- `jax`：JAX CPU/GPU alternating projections，需要 `jax`/`jaxlib`。
- `cupy` / `cupy64`：CuPy GPU float64 FWL sparse backend。
- `cupy32`：CuPy GPU float32 FWL sparse backend。
- `scipy`：CPU sparse FWL backend。

本项目不能在包装层重新发明 demeaning；只负责把选择透传给 `pyfixest`，并在
测试中确认参数确实生效。

### 2.3 已有 DiD 能力

`pyfixest.did.estimation.event_study(...)` 已支持：

- `estimator="twfe"`
- `estimator="did2s"`
- `estimator="saturated"`

官方 reference 中 `event_study` 的 `estimator` 参数列出 `"did2s"`、
`"twfe"` 和 `"saturated"`，并示例调用 `fit_twfe_saturated.aggregate()`。
本地 `pyfixest.did.saturated_twfe.SaturatedEventStudy.aggregate()` 的核心做法是
构造线性组合向量 `R`，再用 `R @ model._vcov @ R` 计算聚合标准误。

但该接口按 `yname/idname/tname/gname` 组织，不是
`relative-time varlist + cohort + control_cohort + formula + covariates()` 的
Stata/Julia 工作流。因此：

- 本地 `pyfixest==0.50.1` 的 saturated 估计函数内部构造
  `outcome ~ i(rel_time, first_treated_period, ref=-1, ref2=0) | unit + time`；
  顶层 `xfml` 没有被接入 saturated `feols` 公式。
- 本项目应提供显式 varlist 工作流：相对期列写在 `fml` RHS，普通控制变量写在
  `covariates=`。
- 后续可以用 `pyfixest.event_study(..., estimator="saturated")` 做 sanity check，
  但不能直接替代 `eventreg(...)`。
- 当前 Python 实现已保存 `aggregation_matrix_`，即与 saturated `aggregate()` 同类
  的线性组合矩阵；第一阶段聚合协方差走 `R @ V @ R.T`，再叠加 Stata/Julia
  `eventstudyinteract` 要求的 cohort-share 不确定性。
- 本地 `pyfixest==0.50.1` 的 saturated `aggregate()` 实现目前只接受
  `agg="period"` 和 `weighting="shares"`；它不是任意 ATE/lincom 接口。
  因此本项目在结果对象上提供 `lincom()` 与 `ate()`，对已经得到的 IW period
  estimates 使用 `a' beta` 与 `a' V a` 做推断。
- 用户调用 `eventreg("y ~ rel0 + rel1 | fe1 + fe2 + fe3",
  covariates="x1 + x2")` 会被展开成
  `y ~ cohort_by_rel_time + x1 + x2 | fe1 + fe2 + fe3`。因此连续控制变量和
  多维固定效应完全交给 pyfixest `feols` 的求解器、demeaner backend 和协方差
  路径处理。
- 双向和多维固定效应标准误以 saturated Sun-Abraham 方程的完整 absorbed-FE
  自由度口径为准。实现上仍读取 pyfixest 原生 `_vcov`，但在 IW 汇总前对
  多维固定效应的第一阶段协方差补一个小样本自由度标量校正；Stata 的
  `V_iw` 在该情形下是已知偏小的参考输出，不作为 parity 真值。

## 3. 初步风险

- `pyfixest` 的第一阶段协方差矩阵可以直接取用，但第二阶段 share 协方差需要
  自行实现，与 `vcov`/cluster small-sample correction 保持一致是核心风险。
- `use_compression=True` 在 `pyfixest` 内部有权重限制；本项目必须复用其错误
  语义，不额外承诺不支持的组合。
- `split`/`fsplit` 会让 `feols` 返回多模型容器；`eventreg` 需要显式设计
  `EventStudyInteractMulti`，避免只支持单模型却静默忽略参数。
- 相对时间交互项数量可能很大，临时列物化会带来内存压力；后续实现要考虑
  分块构造或 formulaic/context 方案。
