# 实现计划

## Phase 0: 项目骨架

状态：已完成。

交付物：

- `src/` 布局。
- `pyproject.toml`。
- README。
- 需求、API、上游分析和工作流文档。
- 最小 CI。

验收标准：

- `python -m compileall src` 通过。
- `pytest` 最小导入测试通过。
- 文档清楚标注已实现范围和剩余外部 parity 缺口。

## Phase 1: API 与结果对象骨架

状态：已完成。

任务：

- 新增 `eventstudyinteracts.api.eventreg`。
- 新增 `EventStudyInteract` dataclass 或轻量 class。
- 实现 `coef()`、`vcov()`、`se()`、`tidy()`、`confint()`、`summary()` 的空/基础路径。
- 将 `__init__.py` 导出 `eventreg`。

验收标准：

- 对人为构造的系数/协方差矩阵，结果对象方法和 `tidy()` 输出正确。
- 公开 API 文档和函数签名一致。

## Phase 2: 数据准备与第一阶段 pyfixest 回归

状态：已完成。

任务：

- 实现安全临时列前缀。
- 实现控制组置零后的相对时间列。
- 实现 cohort-by-relative-time 交互列构造。
- 实现 `pyfixest.feols` 参数透传。
- 保存第一阶段模型和估计样本。

验收标准：

- `demeaner_backend`、`fixef_tol`、`fixef_maxiter`、`solver`、`weights` 等参数在
  mock 或真实模型中确认传递。
- 单 cohort 第一阶段系数能按相对时间正确提取。

## Phase 3: 单 cohort 等价测试

状态：已完成基础路径。

任务：

- 构造 deterministic panel fixture。
- 在只有一个 treated cohort 的情况下比较：
  - 直接 `pyfixest.feols` event-study 回归。
  - `eventreg(...)`。
- 覆盖 `"iid"`、`"hetero"`、`{"CRV1": "id"}`。

验收标准：

- 系数、标准误和协方差在数值容差内一致。
- 单 cohort 时 share 协方差为零。

## Phase 4: 多 cohort IW 权重与协方差

状态：已完成 MVP。

任务：

- 实现 treated sample cohort-share 估计。
- 实现 pyfixest-backed share 协方差：
  - iid
  - hetero/HC1
  - one-way/two-way CRV1
- 实现 delta-method 合成总协方差。
- 处理不可估计相对时间的输出重插。

验收标准：

- 手算小样本 fixture 的 IW 权重和系数一致。
- 多 cohort 合成数据在不同 `vcov` 下给出稳定结果。
- 对未支持的 `vcov` 明确报错。

## Phase 5: pyfixest 特性完整化

状态：部分完成。

任务：

- `split`/`fsplit` 返回 `EventStudyInteractMulti`。已完成。
- `use_compression=True` 路径验证。
- `lean`、`store_data`、`copy_data` 行为验证。
- `demeaner_backend` 覆盖测试：
  - 必测：`numba`、`rust-cg`/`rust`、`scipy`
  - 可选环境：`jax`、`cupy*`

验收标准：

- 包装层不改变 `pyfixest` 参数语义。
- 不支持组合沿用或明确暴露 `pyfixest` 错误。

## Phase 6: 外部基准与文档示例

状态：进行中。

任务：

- 将 `EventStudyInteracts.jl` 的 `nlswork` 数据/结果转成 Python reference。
- 增加 `references/` 中的 baseline 文件。
- 编写 README usage 示例。已完成基础示例。
- 增加 `scripts/check_external_parity.py`。已完成 Python fixture、R fixest
  Sun-Abraham parity、Stata `eventstudyinteract` parity、Julia
  `EventStudyInteracts.jl` parity。
- 增加 `examples/` 脚本或 notebook。

验收标准：

- Python 结果与 Julia/Stata reference 在预设容差内一致。
- README 示例可运行。

## Phase 7: 性能与维护

任务：

- 建立基准脚本：
  - 不同样本规模。
  - 不同 `demeaner_backend`。
  - `use_compression` 开关。
- 每次重要 release 更新 benchmark 表。
- 增加上游 `pyfixest` 版本漂移检查。

验收标准：

- benchmark 输出入库。
- 文档中的性能声明都有脚本支持。

## Phase 8: GitHub 发布

任务：

- 初始化 git history。
- 创建 GitHub 仓库。
- 推送 `main`。
- 配置 Actions。
- 建立 issue labels 和 milestone。

验收标准：

- 远程仓库可访问。
- CI 通过。
- README 明确 pre-alpha 状态。
