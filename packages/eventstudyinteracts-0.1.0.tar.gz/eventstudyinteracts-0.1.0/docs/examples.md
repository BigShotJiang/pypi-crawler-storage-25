# EventStudyInteracts.py Examples

The public estimator is `eventstudyinteracts.eventreg()`. Examples use:

```python
import eventstudyinteracts as esi
```

The formula is pyfixest-style:

```text
Y ~ relative-time columns | fixed effects
```

The terms before `|` are the relative-time dummy columns that Stata
`eventstudyinteract` users would put in the varlist. Ordinary controls go in
`covariates=`.

## nlswork Setup

```python
import numpy as np
import pandas as pd
import eventstudyinteracts as esi

df = pd.read_stata("dataset/nlswork.dta")

df["union_year"] = np.where(df["union"].fillna(0).eq(1), df["year"], np.nan)
df["first_union"] = df.groupby("idcode")["union_year"].transform("min")
df = df.drop(columns=["union_year"])

df["ry"] = df["year"] - df["first_union"]
df["never_union"] = df["first_union"].isna()

ids_with_ref = df.loc[df["ry"].eq(-1), "idcode"].unique()
df = df.loc[df["never_union"] | df["idcode"].isin(ids_with_ref)].copy()

relmin = int(abs(np.nanmin(df["ry"])))
relmax = int(abs(np.nanmax(df["ry"])))

event_vars = []
for k in range(relmin, 1, -1):
    df[f"g_{k}"] = df["ry"].eq(-k).fillna(False).astype(int)
    event_vars.append(f"g_{k}")
for k in range(0, relmax + 1):
    df[f"g{k}"] = df["ry"].eq(k).fillna(False).astype(int)
    event_vars.append(f"g{k}")
```
The `ids_with_ref` filter keeps the omitted-period support the same across
`eventreg`, pyfixest saturated, Stata, and Julia. Without that filter, some
treated cohorts contribute different supported cohort-by-period cells.

## Never-Treated Controls

```python
m1 = esi.eventreg(
    f"ln_wage ~ {' + '.join(event_vars)} | idcode + year",
    data=df,
    cohort="first_union",
    control_cohort="never_union",
    vcov={"CRV1": "idcode"},
)

m1.tidy()
```

Selected current output:

| term | estimate | std. error |
| --- | ---: | ---: |
| `g_20` | 0.111521 | 0.117627 |
| `g_19` | 0.118273 | 0.123875 |
| `g_18` | -0.065599 | 0.143241 |
| `g0` | 0.131608 | 0.014452 |
| `g1` | 0.177707 | 0.021273 |
| `g18` | -0.120038 | 0.067475 |

`m1.tidy()` is already the IW event-study table. `m1.aggregate()` is retained
only as a pyfixest-compatible alias, mainly for users who want a numeric period
index or `iplot_aggregate()`.

## Plotting

```python
m1.iplot_aggregate()

ax = m1.iplot_aggregate(show=False)
ax.figure.savefig("nlswork_eventstudy.png", dpi=200, bbox_inches="tight")
```

## Multiple Fixed Effects

```python
m_fe = esi.eventreg(
    f"ln_wage ~ {' + '.join(event_vars)} | idcode + year + ind_code^year",
    data=df,
    cohort="first_union",
    control_cohort="never_union",
    covariates="south + tenure + age",
    vcov={"CRV1": "idcode"},
    demeaner_backend="rust-cg",
)
```

`ind_code^year` is an absorbed fixed effect. Province-by-year is written
`province^year`.

## ATE And Lincom

ATE is a linear combination of IW period estimates:

```text
estimate = a' beta_iw
std_error = sqrt(a' V_iw a)
```

```python
post = [f"g{k}" for k in range(0, 19)]
m1.ate(name="ATE_g0_g18")
m1.ate(post, name="ATE_g0_g18")
m1.lincom({"g3": 1.0, "g0": -1.0}, name="g3_minus_g0")
```

Current `nlswork` output:

| expression | estimate | std. error |
| --- | ---: | ---: |
| `ATE_g0_g18` | 0.111872 | 0.023011 |
| `g3_minus_g0` | 0.017982 | 0.027433 |

For simple names such as `g0`, `g1`, and `g18`, `ate()` without an explicit
period list averages all nonnegative periods. Pass `periods` when users want
only `g0:g4`, a binned window, or group-specific columns. `lincom(weights)` is
the general form; the dictionary gives the coefficient on each named estimate.

## Binning

```python
df["g_l4"] = df["ry"].le(-4).fillna(False).astype(int)

bin_vars = ["g_l4", "g_3", "g_2"]
bin_vars.extend([f"g{k}" for k in range(0, 19)])

m2 = esi.eventreg(
    f"ln_wage ~ {' + '.join(bin_vars)} | idcode + year",
    data=df,
    cohort="first_union",
    control_cohort="never_union",
    covariates="south",
    vcov={"CRV1": "idcode"},
)
```

## Last-Treated Controls

```python
df["last_union"] = df["first_union"].eq(88).fillna(False)
sample = df.loc[df["first_union"].notna() & df["year"].lt(88)].copy()

m3 = esi.eventreg(
    f"ln_wage ~ {' + '.join(bin_vars)} | idcode + year",
    data=sample,
    cohort="first_union",
    control_cohort="last_union",
    covariates="south",
    vcov={"CRV1": "idcode"},
)
```

## Heterogeneity

```python
het_vars = []

for group in [0, 1]:
    df[f"g_l4_collgrad{group}"] = (
        df["ry"].le(-4).fillna(False) & df["collgrad"].eq(group)
    ).astype(int)
    het_vars.append(f"g_l4_collgrad{group}")

    for k in range(3, 1, -1):
        name = f"g_{k}_collgrad{group}"
        df[name] = (
            df["ry"].eq(-k).fillna(False) & df["collgrad"].eq(group)
        ).astype(int)
        het_vars.append(name)

    for k in range(0, 19):
        name = f"g{k}_collgrad{group}"
        df[name] = (
            df["ry"].eq(k).fillna(False) & df["collgrad"].eq(group)
        ).astype(int)
        het_vars.append(name)

m4 = esi.eventreg(
    f"ln_wage ~ {' + '.join(het_vars)} | idcode + year",
    data=df,
    cohort="first_union",
    control_cohort="never_union",
    covariates="south",
    vcov={"CRV1": "idcode"},
)

m4.lincom(
    {"g1_collgrad1": 1.0, "g1_collgrad0": -1.0},
    name="collgrad_diff_g1",
)
m4.ate([f"g{k}_collgrad1" for k in range(0, 5)], name="ATE_collgrad1_g0_g4")
m4.ate([f"g{k}_collgrad0" for k in range(0, 5)], name="ATE_collgrad0_g0_g4")
```

Binning combines periods into columns. Heterogeneity splits periods into
group-specific columns. `eventreg()` estimates exactly the columns written
before `|` in the formula.

## Export

```python
m1.etable(type="df")
m1.etable(type="tex", file_name="eventstudy.tex")
m1.tidy().to_csv("eventstudy.csv")
m1.ate(name="ATE_g0_g18").to_csv("ate.csv")
```
