"""Interaction-weighted event-study estimator backed by pyfixest."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from importlib.metadata import version as package_version
from typing import Any, Literal

import numpy as np
import pandas as pd

from eventstudyinteracts._formula import (
    build_interacted_formula,
    relative_terms_from_formula,
)
from eventstudyinteracts._names import choose_prefix, safe_token
from eventstudyinteracts._vcov import share_vcov_from_pyfixest
from eventstudyinteracts.results import EventStudyInteract, EventStudyInteractMulti


def eventreg(
    fml: str,
    data: pd.DataFrame,
    rel_varlist: Sequence[str] | None = None,
    cohort: str | None = None,
    control_cohort: str | None = None,
    vcov: str | dict[str, str] | None = None,
    *,
    covariates: str | Sequence[str] | None = None,
    vcov_kwargs: dict[str, str | int] | None = None,
    weights: str | None = None,
    ssc: dict[str, str | bool] | None = None,
    fixef_rm: Literal["singleton", "none"] = "singleton",
    fixef_tol: float = 1e-6,
    fixef_maxiter: int = 10_000,
    collin_tol: float = 1e-6,
    drop_intercept: bool = False,
    copy_data: bool = True,
    store_data: bool = True,
    lean: bool = False,
    weights_type: Literal["aweights", "fweights"] = "aweights",
    solver: str = "scipy.linalg.solve",
    demeaner_backend: str = "numba",
    use_compression: bool = False,
    reps: int = 100,
    context: int | Mapping[str, Any] | None = None,
    seed: int | None = None,
    split: str | None = None,
    fsplit: str | None = None,
    stage2_vcov: Literal["inherit"] | str | dict[str, str] = "inherit",
    share_vcov: Literal["regression", "none"] = "regression",
    fixef_vcov_correction: Literal["full", "pyfixest"] = "pyfixest",
    keep_interacted_model: bool = True,
) -> EventStudyInteract | EventStudyInteractMulti:
    """Estimate a Sun-Abraham interaction-weighted event-study model.

    ``fml`` follows pyfixest formula syntax. Terms before ``|`` are the
    Stata-style event-study varlist. Ordinary controls should be supplied via
    ``covariates=`` and fixed effects after the pyfixest ``|``. For legacy
    callers, ``rel_varlist`` may still be provided explicitly if it exactly
    matches those formula terms; otherwise it is parsed from ``fml``.
    """
    if cohort is None:
        raise TypeError("cohort must be supplied.")
    if control_cohort is None:
        raise TypeError("control_cohort must be supplied.")

    resolved_rel_varlist = _resolve_rel_varlist(fml, rel_varlist)

    if split and fsplit:
        raise ValueError("Use only one of split or fsplit.")
    if split or fsplit:
        split_var = split or fsplit
        if split_var is None:
            raise ValueError("split or fsplit must name a column.")
        return _eventreg_split(
            fml=fml,
            data=data,
            rel_varlist=resolved_rel_varlist,
            cohort=cohort,
            control_cohort=control_cohort,
            vcov=vcov,
            split=split_var,
            include_full_sample=fsplit is not None,
            kwargs={
                "covariates": covariates,
                "vcov_kwargs": vcov_kwargs,
                "weights": weights,
                "ssc": ssc,
                "fixef_rm": fixef_rm,
                "fixef_tol": fixef_tol,
                "fixef_maxiter": fixef_maxiter,
                "collin_tol": collin_tol,
                "drop_intercept": drop_intercept,
                "copy_data": copy_data,
                "store_data": store_data,
                "lean": lean,
                "weights_type": weights_type,
                "solver": solver,
                "demeaner_backend": demeaner_backend,
                "use_compression": use_compression,
                "reps": reps,
                "context": context,
                "seed": seed,
                "stage2_vcov": stage2_vcov,
                "share_vcov": share_vcov,
                "fixef_vcov_correction": fixef_vcov_correction,
                "keep_interacted_model": keep_interacted_model,
            },
        )

    return _eventreg_single(
        fml=fml,
        data=data,
        rel_varlist=resolved_rel_varlist,
        cohort=cohort,
        control_cohort=control_cohort,
        covariates=covariates,
        vcov=vcov,
        vcov_kwargs=vcov_kwargs,
        weights=weights,
        ssc=ssc,
        fixef_rm=fixef_rm,
        fixef_tol=fixef_tol,
        fixef_maxiter=fixef_maxiter,
        collin_tol=collin_tol,
        drop_intercept=drop_intercept,
        copy_data=copy_data,
        store_data=store_data,
        lean=lean,
        weights_type=weights_type,
        solver=solver,
        demeaner_backend=demeaner_backend,
        use_compression=use_compression,
        reps=reps,
        context=context,
        seed=seed,
        stage2_vcov=stage2_vcov,
        share_vcov=share_vcov,
        fixef_vcov_correction=fixef_vcov_correction,
        keep_interacted_model=keep_interacted_model,
    )


def _eventreg_split(
    *,
    fml: str,
    data: pd.DataFrame,
    rel_varlist: Sequence[str],
    cohort: str,
    control_cohort: str,
    vcov: str | dict[str, str] | None,
    split: str,
    include_full_sample: bool,
    kwargs: dict[str, Any],
) -> EventStudyInteractMulti:
    if split not in data.columns:
        raise KeyError(f"split column {split!r} not found in data.")

    models: dict[Any, EventStudyInteract] = {}
    if include_full_sample:
        models["all"] = _eventreg_single(
            fml=fml,
            data=data,
            rel_varlist=list(rel_varlist),
            cohort=cohort,
            control_cohort=control_cohort,
            vcov=vcov,
            **kwargs,
        )

    for value, group in data.groupby(split, sort=True, dropna=False):
        models[value] = _eventreg_single(
            fml=fml,
            data=group.copy(),
            rel_varlist=list(rel_varlist),
            cohort=cohort,
            control_cohort=control_cohort,
            vcov=vcov,
            **kwargs,
        )
    return EventStudyInteractMulti(
        models=models,
        split=split,
        include_full_sample=include_full_sample,
    )


def _resolve_rel_varlist(fml: str, rel_varlist: Sequence[str] | None) -> list[str]:
    formula_terms = relative_terms_from_formula(fml)
    if rel_varlist is None:
        terms = formula_terms
    else:
        terms = [str(term).strip() for term in rel_varlist if str(term).strip()]
        if terms != formula_terms:
            raise ValueError(
                "rel_varlist, when supplied, must match the formula's "
                "relative-time variables exactly."
            )

    if not terms:
        raise ValueError(
            "event-study relative-time variables must appear before '|' in fml."
        )
    return terms


def _eventreg_single(
    *,
    fml: str,
    data: pd.DataFrame,
    rel_varlist: list[str],
    cohort: str,
    control_cohort: str,
    covariates: str | Sequence[str] | None,
    vcov: str | dict[str, str] | None,
    vcov_kwargs: dict[str, str | int] | None,
    weights: str | None,
    ssc: dict[str, str | bool] | None,
    fixef_rm: Literal["singleton", "none"],
    fixef_tol: float,
    fixef_maxiter: int,
    collin_tol: float,
    drop_intercept: bool,
    copy_data: bool,
    store_data: bool,
    lean: bool,
    weights_type: Literal["aweights", "fweights"],
    solver: str,
    demeaner_backend: str,
    use_compression: bool,
    reps: int,
    context: int | Mapping[str, Any] | None,
    seed: int | None,
    stage2_vcov: Literal["inherit"] | str | dict[str, str],
    share_vcov: Literal["regression", "none"],
    fixef_vcov_correction: Literal["full", "pyfixest"],
    keep_interacted_model: bool,
) -> EventStudyInteract:
    try:
        import pyfixest as pf
    except ImportError as exc:
        raise ImportError(
            "eventreg requires pyfixest. Install this package with its runtime "
            "dependencies before estimating models."
        ) from exc
    _require_pyfixest_version()

    _validate_inputs(data, rel_varlist, cohort, control_cohort, weights)

    df = data.copy() if copy_data else data
    prefix = choose_prefix(df.columns)
    df, nrel_names = _make_control_zero_relatives(
        df, rel_varlist, control_cohort, prefix
    )
    prekeep = np.array(
        [
            not np.isclose(df[name].to_numpy(dtype=float), 0.0).all()
            for name in nrel_names
        ]
    )

    if not prekeep.any():
        raise ValueError(
            "No estimable relative-time indicators remain after removing "
            "unsupported columns."
        )

    kept_rel = [rel for rel, keep in zip(rel_varlist, prekeep) if keep]
    kept_nrel = [name for name, keep in zip(nrel_names, prekeep) if keep]
    cohort_list = _cohort_list(df, cohort, control_cohort)
    if not cohort_list:
        raise ValueError("No treated cohorts found outside control_cohort.")

    df, interaction_terms = _make_interactions(
        df, kept_nrel, cohort, cohort_list, prefix
    )
    first_stage_fml = build_interacted_formula(
        fml, interaction_terms, rel_varlist, covariates
    )

    # eventreg needs the first-stage estimation sample for stage 2, so keep
    # pyfixest data internally even if the returned wrapper is lean.
    first_stage = pf.feols(
        first_stage_fml,
        df,
        vcov=vcov,
        vcov_kwargs=vcov_kwargs,
        weights=weights,
        ssc=ssc,
        fixef_rm=fixef_rm,
        fixef_tol=fixef_tol,
        fixef_maxiter=fixef_maxiter,
        collin_tol=collin_tol,
        drop_intercept=drop_intercept,
        copy_data=copy_data,
        store_data=True,
        lean=False,
        weights_type=weights_type,
        solver=solver,
        demeaner_backend=demeaner_backend,
        use_compression=use_compression,
        reps=reps,
        context=context,
        seed=seed,
    )

    sample = _first_stage_sample(first_stage, df)
    coef_series = first_stage.coef()
    coef_names = list(coef_series.index)
    first_vcov = _first_stage_vcov(first_stage, coef_names)
    first_vcov, first_vcov_adjustment = _apply_first_stage_vcov_correction(
        first_stage,
        first_vcov,
        vcov,
        fixef_vcov_correction,
    )

    postkeep = _postkeep_relatives(
        coef_names, first_vcov, kept_nrel, cohort_list, prefix
    )
    if not postkeep.any():
        raise ValueError(
            "No estimable relative-time indicators remain after fitting the "
            "interacted regression."
        )

    reduced_rel = [rel for rel, keep in zip(kept_rel, postkeep) if keep]
    reduced_nrel = [name for name, keep in zip(kept_nrel, postkeep) if keep]
    reduced_interactions = _interaction_names(reduced_nrel, cohort_list, prefix)

    weights_matrix, share_sigma, stage2, stage2_models = _estimate_shares(
        pf=pf,
        sample=sample,
        nrel_names=reduced_nrel,
        cohort=cohort,
        control_cohort=control_cohort,
        cohort_list=cohort_list,
        prefix=prefix,
        vcov=vcov if stage2_vcov == "inherit" else stage2_vcov,
        vcov_kwargs=vcov_kwargs,
        weights=weights,
        ssc=ssc,
        copy_data=copy_data,
        weights_type=weights_type,
        solver=solver,
        share_vcov=share_vcov,
    )

    delta = _interaction_coef_matrix(coef_series, reduced_nrel, cohort_list, prefix)
    coef_values = coef_series.to_numpy(dtype=float)
    first_vcov_values = first_vcov.to_numpy(dtype=float)
    ordered_aggregation_reduced = _ordered_aggregation_matrix(
        weights_matrix, reduced_nrel, cohort_list, prefix, coef_names
    )

    coef_reduced, vcov_reduced, aggregation_reduced = _aggregate_iw(
        weights_matrix,
        delta,
        coef_values,
        first_vcov_values,
        ordered_aggregation_reduced,
        share_sigma,
    )

    full_keep = np.zeros(len(rel_varlist), dtype=bool)
    pre_idx = np.flatnonzero(prekeep)
    full_keep[pre_idx] = postkeep
    coefficients, covariance = _reinsert_outputs(
        coef_reduced,
        vcov_reduced,
        rel_varlist,
        full_keep,
    )

    weights_df = pd.DataFrame(weights_matrix, index=cohort_list, columns=reduced_rel)
    delta_df = pd.DataFrame(delta, index=cohort_list, columns=reduced_rel)
    aggregation_df = pd.DataFrame(0.0, index=rel_varlist, columns=reduced_interactions)
    for rel, row in zip(reduced_rel, aggregation_reduced):
        aggregation_df.loc[rel, :] = row

    return EventStudyInteract(
        coefficients=coefficients,
        covariance=covariance,
        df_t=_result_df_t(
            first_stage,
            vcov,
            first_vcov_adjustment,
            max(len(sample) - len(coef_names), 1),
        ),
        fml=fml,
        first_stage_fml=first_stage_fml,
        vcov_spec=vcov if vcov is not None else "iid",
        nobs=int(getattr(first_stage, "_N", len(sample))),
        rel_varlist_=rel_varlist,
        cohort_list_=cohort_list,
        iw_weights_=weights_df,
        delta_=delta_df,
        aggregation_matrix_=aggregation_df,
        interacted_model_=first_stage
        if keep_interacted_model and not lean and store_data
        else None,
        stage2_models_=stage2_models if not lean and store_data else None,
        stage2_diagnostics_={**stage2, "first_stage_vcov": first_vcov_adjustment},
        demeaner_backend_=demeaner_backend,
    )


def _validate_inputs(
    data: pd.DataFrame,
    rel_varlist: list[str],
    cohort: str,
    control_cohort: str,
    weights: str | None,
) -> None:
    if not isinstance(data, pd.DataFrame):
        raise TypeError("data must be a pandas DataFrame.")
    if not rel_varlist:
        raise ValueError(
            "fml must contain at least one relative-time column before '|'."
        )
    missing = [col for col in [*rel_varlist, cohort, control_cohort] if col not in data]
    if weights is not None and weights not in data:
        missing.append(weights)
    if missing:
        raise KeyError(f"Columns not found in data: {missing}")


def _require_pyfixest_version(minimum: tuple[int, int, int] = (0, 50, 1)) -> None:
    raw_version = package_version("pyfixest")
    current = _parse_version(raw_version)
    if current < minimum:
        min_text = ".".join(str(part) for part in minimum)
        raise ImportError(
            f"eventreg requires pyfixest>={min_text}; found pyfixest {raw_version}."
        )


def _parse_version(raw_version: str) -> tuple[int, int, int]:
    parts = []
    for piece in raw_version.split(".")[:3]:
        number = ""
        for char in piece:
            if not char.isdigit():
                break
            number += char
        parts.append(int(number or 0))
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def _make_control_zero_relatives(
    df: pd.DataFrame,
    rel_varlist: list[str],
    control_cohort: str,
    prefix: str,
) -> tuple[pd.DataFrame, list[str]]:
    control = df[control_cohort].fillna(False).astype(bool)
    names = [f"{prefix}n_{safe_token(rel)}" for rel in rel_varlist]
    values = {}
    for rel, name in zip(rel_varlist, names):
        values[name] = pd.to_numeric(df[rel], errors="raise").astype(float)
    values_df = pd.DataFrame(values, index=df.index)
    values_df.loc[control, :] = 0.0
    return pd.concat([df, values_df], axis=1), names


def _cohort_list(df: pd.DataFrame, cohort: str, control_cohort: str) -> list[Any]:
    treated = ~df[control_cohort].fillna(False).astype(bool)
    cohorts = df.loc[treated, cohort].dropna().unique().tolist()
    return sorted(cohorts)


def _make_interactions(
    df: pd.DataFrame,
    nrel_names: list[str],
    cohort: str,
    cohort_list: list[Any],
    prefix: str,
) -> tuple[pd.DataFrame, list[str]]:
    names = []
    values = {}
    for nrel in nrel_names:
        rel_values = df[nrel].astype(float)
        for cohort_value in cohort_list:
            name = _interaction_name(nrel, cohort_value, prefix)
            indicator = (df[cohort] == cohort_value).fillna(False).astype(float)
            values[name] = rel_values * indicator
            names.append(name)
    return pd.concat([df, pd.DataFrame(values, index=df.index)], axis=1), names


def _interaction_names(
    nrel_names: list[str], cohort_list: list[Any], prefix: str
) -> list[str]:
    return [
        _interaction_name(nrel, cohort_value, prefix)
        for nrel in nrel_names
        for cohort_value in cohort_list
    ]


def _interaction_name(nrel: str, cohort_value: Any, prefix: str) -> str:
    return f"{prefix}x_{safe_token(nrel)}_{safe_token(cohort_value)}"


def _first_stage_sample(first_stage: Any, fallback: pd.DataFrame) -> pd.DataFrame:
    sample = getattr(first_stage, "_data", None)
    if isinstance(sample, pd.DataFrame) and not sample.empty:
        return sample.copy()
    return fallback.copy()


def _first_stage_vcov(first_stage: Any, coef_names: list[str]) -> pd.DataFrame:
    vcov = getattr(first_stage, "_vcov", None)
    if vcov is None or len(vcov) == 0:
        raise ValueError(
            "First-stage pyfixest model did not expose a covariance matrix."
        )
    return pd.DataFrame(
        np.asarray(vcov, dtype=float), index=coef_names, columns=coef_names
    )


def _apply_first_stage_vcov_correction(
    first_stage: Any,
    first_vcov: pd.DataFrame,
    vcov: str | dict[str, str] | None,
    correction: Literal["full", "pyfixest"],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    if correction not in {"full", "pyfixest"}:
        raise ValueError("fixef_vcov_correction must be 'full' or 'pyfixest'.")

    scale = 1.0
    reason = "pyfixest_native"
    if correction == "full":
        scale = _full_fixef_vcov_scale(first_stage, vcov)
        if not np.isclose(scale, 1.0):
            first_vcov = first_vcov * scale
            reason = "multiway_fixef_dof"

    return first_vcov, {"correction": correction, "scale": scale, "reason": reason}


def _full_fixef_vcov_scale(
    first_stage: Any, vcov: str | dict[str, str] | None
) -> float:
    """Apply the saturated event-study multiway-FE small-sample scalar.

    pyfixest supplies the native covariance matrix and all demeaning/score
    machinery. Correct saturated event-study inference counts one
    additional degree of freedom for each absorbed FE dimension beyond the first
    in the small-sample factor. Stata's eventstudyinteract does not apply this
    adjustment, so two-way FE standard errors are too small relative to the
    saturated Sun-Abraham implementation.
    """
    n_fe = _n_fixef(first_stage)
    if n_fe <= 1 or not _vcov_uses_small_sample_scalar(vcov):
        return 1.0

    base_df = _first_stage_base_residual_df(first_stage)
    extra_df = n_fe - 1
    if base_df <= extra_df:
        return 1.0
    return float(base_df / (base_df - extra_df))


def _first_stage_base_residual_df(first_stage: Any) -> float:
    nobs = getattr(first_stage, "_N", None)
    df_k = getattr(first_stage, "_df_k", None)
    if nobs is not None and df_k is not None:
        return max(float(nobs) - float(df_k), 1.0)
    return max(float(getattr(first_stage, "_df_t", 1.0)), 1.0)


def _result_df_t(
    first_stage: Any,
    vcov: str | dict[str, str] | None,
    first_vcov_adjustment: dict[str, Any],
    fallback: int,
) -> float:
    raw_df = max(float(getattr(first_stage, "_df_t", fallback)), 1.0)
    if first_vcov_adjustment.get("reason") != "multiway_fixef_dof":
        return raw_df

    n_fe = _n_fixef(first_stage)
    if _is_crv1(vcov):
        return max(raw_df - max(n_fe - 1, 0), 1.0)
    return max(raw_df - n_fe, 1.0)


def _n_fixef(first_stage: Any) -> int:
    value = getattr(first_stage, "_n_fe", 0)
    if value is None:
        return 0
    return int(value)


def _vcov_uses_small_sample_scalar(vcov: str | dict[str, str] | None) -> bool:
    if vcov is None:
        return True
    if isinstance(vcov, str):
        return vcov.lower() in {"iid", "simple", "hetero", "hc1"}
    return _is_crv1(vcov)


def _is_crv1(vcov: str | dict[str, str] | None) -> bool:
    return isinstance(vcov, dict) and any(str(key).upper() == "CRV1" for key in vcov)


def _postkeep_relatives(
    coef_names: list[str],
    first_vcov: pd.DataFrame,
    nrel_names: list[str],
    cohort_list: list[Any],
    prefix: str,
) -> np.ndarray:
    coef_set = set(coef_names)
    keep = []
    for nrel in nrel_names:
        block = [
            _interaction_name(nrel, cohort_value, prefix)
            for cohort_value in cohort_list
        ]
        block_keep = False
        for name in block:
            if name in coef_set and not np.isnan(first_vcov.loc[name, name]):
                block_keep = True
                break
        keep.append(block_keep)
    return np.array(keep, dtype=bool)


def _estimate_shares(
    *,
    pf: Any,
    sample: pd.DataFrame,
    nrel_names: list[str],
    cohort: str,
    control_cohort: str,
    cohort_list: list[Any],
    prefix: str,
    vcov: str | dict[str, str] | None,
    vcov_kwargs: dict[str, str | int] | None,
    weights: str | None,
    ssc: dict[str, str | bool] | None,
    copy_data: bool,
    weights_type: Literal["aweights", "fweights"],
    solver: str,
    share_vcov: Literal["regression", "none"],
) -> tuple[np.ndarray, np.ndarray, dict[str, Any], list[Any] | None]:
    if share_vcov not in {"regression", "none"}:
        raise ValueError("share_vcov must be 'regression' or 'none'.")

    nrel = len(nrel_names)
    ncohort = len(cohort_list)
    if ncohort == 1:
        return (
            np.ones((1, nrel), dtype=float),
            np.zeros((nrel, nrel), dtype=float),
            {"single_cohort": True},
            None,
        )

    treated = ~sample[control_cohort].fillna(False).astype(bool)
    stage2 = sample.loc[treated].copy()
    share_names = []
    for cohort_value in cohort_list:
        name = f"{prefix}share_{safe_token(cohort_value)}"
        share_names.append(name)
        stage2[name] = (stage2[cohort] == cohort_value).astype(float)

    share_fml = f"{' + '.join(share_names)} ~ 0 + {' + '.join(nrel_names)}"
    share_fit = pf.feols(
        share_fml,
        stage2,
        vcov=vcov,
        vcov_kwargs=vcov_kwargs,
        weights=weights,
        ssc=ssc,
        copy_data=copy_data,
        store_data=True,
        lean=False,
        weights_type=weights_type,
        solver=solver,
    )
    share_models = _ordered_share_models(share_fit, share_names, nrel_names)
    weights_matrix = _share_weights(stage2, nrel_names, cohort, cohort_list, weights)
    if share_vcov == "regression":
        sigma = share_vcov_from_pyfixest(share_models, vcov, nrel_names)
    else:
        sigma = np.zeros((ncohort * nrel, ncohort * nrel), dtype=float)
    diagnostics: dict[str, Any] = {
        "single_cohort": False,
        "cohorts": cohort_list,
        "share_formula": share_fml,
        "share_weight_method": "count_share",
        "share_vcov": share_vcov,
        "pyfixest_native_vcov": True,
    }
    return weights_matrix, sigma, diagnostics, share_models


def _share_weights(
    stage2: pd.DataFrame,
    nrel_names: list[str],
    cohort: str,
    cohort_list: list[Any],
    weights: str | None,
) -> np.ndarray:
    rel = stage2[nrel_names].to_numpy(dtype=float)
    if not np.isin(rel, [0.0, 1.0]).all():
        raise ValueError(
            "event-study relative-time columns must be 0/1 indicators. "
            "Create binned or heterogeneous indicators explicitly before "
            "calling eventreg()."
        )
    if (rel.sum(axis=1) > 1.0).any():
        raise ValueError(
            "event-study relative-time columns must be mutually exclusive within "
            "each observation. Check binning and heterogeneity columns for overlap."
        )

    if weights is None:
        obs_weights = np.ones(len(stage2), dtype=float)
    else:
        obs_weights = pd.to_numeric(stage2[weights], errors="raise").to_numpy(
            dtype=float
        )

    weighted_rel = rel * obs_weights[:, None]
    denom = weighted_rel.sum(axis=0)
    if np.isclose(denom, 0.0).any():
        raise ValueError(
            "At least one relative-time column has zero treated support in the "
            "first-stage estimation sample."
        )

    out = np.zeros((len(cohort_list), len(nrel_names)), dtype=float)
    cohort_values = stage2[cohort]
    for i, cohort_value in enumerate(cohort_list):
        cohort_rel = weighted_rel[cohort_values.eq(cohort_value).to_numpy()]
        out[i, :] = cohort_rel.sum(axis=0) / denom
    return out


def _ordered_share_models(
    share_fit: Any,
    share_names: list[str],
    nrel_names: list[str],
) -> list[Any]:
    if not hasattr(share_fit, "all_fitted_models"):
        return [share_fit]

    models_by_lhs: dict[str, Any] = {}
    for fml_key, model in share_fit.all_fitted_models.items():
        lhs = str(fml_key).split("~", maxsplit=1)[0].strip()
        models_by_lhs[lhs] = model

    missing = [name for name in share_names if name not in models_by_lhs]
    if missing:
        raise ValueError(f"pyfixest did not return share models for {missing}.")

    models = [models_by_lhs[name] for name in share_names]
    for model in models:
        missing_coef = [name for name in nrel_names if name not in model.coef().index]
        if missing_coef:
            raise ValueError(
                "pyfixest dropped share-regression columns required for IW weights: "
                f"{missing_coef}"
            )
    return models


def _interaction_coef_matrix(
    coef_series: pd.Series,
    nrel_names: list[str],
    cohort_list: list[Any],
    prefix: str,
) -> np.ndarray:
    out = np.zeros((len(cohort_list), len(nrel_names)), dtype=float)
    for rel_idx, nrel in enumerate(nrel_names):
        for cohort_idx, cohort_value in enumerate(cohort_list):
            name = _interaction_name(nrel, cohort_value, prefix)
            if name in coef_series.index:
                out[cohort_idx, rel_idx] = float(coef_series.loc[name])
    return out


def _interaction_vcov(
    first_vcov: pd.DataFrame,
    coef_names: list[str],
    interaction_names: list[str],
) -> np.ndarray:
    out = np.zeros((len(interaction_names), len(interaction_names)), dtype=float)
    name_to_pos = {name: pos for pos, name in enumerate(coef_names)}
    for i, name_i in enumerate(interaction_names):
        pos_i = name_to_pos.get(name_i)
        if pos_i is None:
            continue
        for j, name_j in enumerate(interaction_names):
            pos_j = name_to_pos.get(name_j)
            if pos_j is None:
                continue
            value = float(first_vcov.iat[pos_i, pos_j])
            if np.isfinite(value):
                out[i, j] = value
    return out


def _ordered_aggregation_matrix(
    weights: np.ndarray,
    nrel_names: list[str],
    cohort_list: list[Any],
    prefix: str,
    coef_names: list[str],
) -> np.ndarray:
    lookup = {}
    for rel_idx, nrel in enumerate(nrel_names):
        for cohort_idx, cohort_value in enumerate(cohort_list):
            lookup[_interaction_name(nrel, cohort_value, prefix)] = (
                rel_idx,
                weights[cohort_idx, rel_idx],
            )

    matrix = np.zeros((len(nrel_names), len(coef_names)), dtype=float)
    for coef_idx, coef_name in enumerate(coef_names):
        found = lookup.get(coef_name)
        if found is not None:
            rel_idx, weight = found
            matrix[rel_idx, coef_idx] = weight
    return matrix


def _aggregate_iw(
    weights: np.ndarray,
    delta: np.ndarray,
    coef_values: np.ndarray,
    first_vcov: np.ndarray,
    ordered_aggregation: np.ndarray,
    share_sigma: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    ncohort, nrel = weights.shape
    aggregation_matrix = _aggregation_matrix(weights)
    coef = np.sum(ordered_aggregation * coef_values, axis=1)
    vcov = ordered_aggregation @ first_vcov @ ordered_aggregation.T
    for i, row in enumerate(ordered_aggregation):
        vcov[i, i] = float(row @ first_vcov @ row)

    share_idx = np.arange(0, ncohort * nrel, nrel)
    for i in range(nrel):
        for j in range(i + 1):
            block = share_sigma[np.ix_(share_idx + i, share_idx + j)]
            increment = float(delta[:, i].T @ block @ delta[:, j])
            vcov[i, j] += increment
            if i != j:
                vcov[j, i] += increment

    return coef, vcov, aggregation_matrix


def _aggregation_matrix(weights: np.ndarray) -> np.ndarray:
    """Build pyfixest-style linear-combination rows for IW aggregation."""
    ncohort, nrel = weights.shape
    matrix = np.zeros((nrel, ncohort * nrel), dtype=float)
    for rel_idx in range(nrel):
        start = rel_idx * ncohort
        matrix[rel_idx, start : start + ncohort] = weights[:, rel_idx]
    return matrix


def _reinsert_outputs(
    coef_reduced: np.ndarray,
    vcov_reduced: np.ndarray,
    rel_varlist: list[str],
    keep: np.ndarray,
) -> tuple[pd.Series, pd.DataFrame]:
    coef_full = np.zeros(len(rel_varlist), dtype=float)
    vcov_full = np.full((len(rel_varlist), len(rel_varlist)), np.nan, dtype=float)

    keep_idx = np.flatnonzero(keep)
    coef_full[keep_idx] = coef_reduced
    vcov_full[np.ix_(keep_idx, keep_idx)] = vcov_reduced

    index = pd.Index(rel_varlist, name="Coefficient")
    return (
        pd.Series(coef_full, index=index, name="Estimate"),
        pd.DataFrame(vcov_full, index=index, columns=index),
    )
