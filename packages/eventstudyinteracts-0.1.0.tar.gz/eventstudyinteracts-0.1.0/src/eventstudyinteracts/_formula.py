"""Formula helpers for pyfixest-style formulas."""

from __future__ import annotations

from collections.abc import Sequence


def split_fixest_formula(fml: str) -> tuple[str, str, list[str]]:
    """Split a pyfixest formula into lhs, pre-fixed-effect, and trailing sections."""
    if "~" not in fml:
        raise ValueError("fml must contain '~'.")

    sections = [part.strip() for part in fml.split("|")]
    lhs_rhs = sections[0]
    trailing = sections[1:]
    lhs, rhs = lhs_rhs.split("~", 1)
    lhs = lhs.strip()
    rhs = rhs.strip()

    if not lhs:
        raise ValueError("fml must contain a dependent variable before '~'.")

    return lhs, rhs, trailing


def relative_terms_from_formula(fml: str) -> list[str]:
    """Return formula terms that define the public event-study varlist.

    In the Stata-style public API, terms before ``|`` are the relative-time
    varlist. Ordinary controls belong in ``covariates=`` and fixed effects
    remain after the pyfixest ``|``.
    """
    _lhs, rhs, _trailing = split_fixest_formula(fml)
    return [term for term in _split_rhs_terms(rhs) if term not in {"0", "1"}]


def build_interacted_formula(
    fml: str,
    interaction_terms: list[str],
    rel_varlist: list[str],
    covariates: str | Sequence[str] | None = None,
) -> str:
    """Replace relative-time formula terms with cohort interaction terms."""
    if not interaction_terms:
        raise ValueError("At least one interaction term is required.")

    lhs, rhs, trailing = split_fixest_formula(fml)
    rhs_terms_in = _split_rhs_terms(rhs)
    rel_set = set(rel_varlist)
    missing = [name for name in rel_varlist if name not in rhs_terms_in]
    if missing:
        raise ValueError(f"rel_varlist terms must appear before '|' in fml: {missing}")

    controls = _unique_terms(
        [term for term in rhs_terms_in if term not in rel_set]
        + _split_covariates(covariates)
    )
    rhs_terms = " + ".join(interaction_terms)
    if controls:
        rhs_terms = f"{rhs_terms} + {' + '.join(controls)}"

    rebuilt = f"{lhs} ~ {rhs_terms}"
    if trailing:
        rebuilt = " | ".join([rebuilt, *trailing])
    return rebuilt


def _split_covariates(covariates: str | Sequence[str] | None) -> list[str]:
    if covariates is None:
        return []
    if isinstance(covariates, str):
        return _split_rhs_terms(covariates)
    return [str(term).strip() for term in covariates if str(term).strip()]


def _unique_terms(terms: list[str]) -> list[str]:
    seen = set()
    out = []
    for term in terms:
        if term not in seen:
            seen.add(term)
            out.append(term)
    return out


def _split_rhs_terms(rhs: str) -> list[str]:
    terms = []
    current = []
    depth = 0
    for char in rhs:
        if char == "(":
            depth += 1
        elif char == ")":
            depth = max(depth - 1, 0)
        if char == "+" and depth == 0:
            term = "".join(current).strip()
            if term:
                terms.append(term)
            current = []
        else:
            current.append(char)

    term = "".join(current).strip()
    if term:
        terms.append(term)
    return terms
