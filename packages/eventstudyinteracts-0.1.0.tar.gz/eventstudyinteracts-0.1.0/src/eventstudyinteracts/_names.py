"""Temporary-name helpers."""

from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable


def safe_token(value: object) -> str:
    """Return a formula-safe token for a user value."""
    raw = str(value)
    token = re.sub(r"\W+", "_", raw).strip("_")
    if not token:
        token = "value"
    if token[0].isdigit():
        token = f"v_{token}"
    digest = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:8]
    return f"{token}_{digest}"


def choose_prefix(columns: Iterable[str], base: str = "__esi_") -> str:
    """Choose a temporary column prefix that does not collide with data columns."""
    existing = set(columns)
    prefix = base
    counter = 0
    while any(str(col).startswith(prefix) for col in existing):
        counter += 1
        prefix = f"{base}{counter}_"
    return prefix
