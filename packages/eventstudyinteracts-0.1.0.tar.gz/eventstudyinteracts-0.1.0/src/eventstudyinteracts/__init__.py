"""Python implementation of interaction-weighted event-study estimators."""

from eventstudyinteracts._version import __version__
from eventstudyinteracts.eventreg import eventreg

__all__ = ["__version__", "eventreg"]
