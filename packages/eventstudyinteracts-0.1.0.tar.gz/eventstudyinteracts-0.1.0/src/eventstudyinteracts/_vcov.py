"""pyfixest-backed covariance helpers for the cohort-share step."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class VcovSpec:
    """Normalized covariance specification for IW share uncertainty."""

    kind: str
    clusters: tuple[str, ...] = ()


def normalize_vcov(vcov: Any) -> VcovSpec:
    """Normalize the subset of pyfixest vcov inputs used by IW share covariance."""
    if vcov is None:
        return VcovSpec("iid")
    if isinstance(vcov, str):
        kind = vcov.lower()
        if kind in {"iid", "simple"}:
            return VcovSpec("iid")
        if kind in {"hetero", "hc1"}:
            return VcovSpec("hetero")
        raise NotImplementedError(
            "The IW cohort-share covariance currently supports iid/simple, "
            "hetero/HC1, and CRV1. The first-stage interacted regression is "
            "still estimated by pyfixest with the requested vcov."
        )
    if isinstance(vcov, dict):
        if len(vcov) != 1:
            raise ValueError("vcov dictionaries must contain exactly one entry.")
        key, value = next(iter(vcov.items()))
        if str(key).upper() != "CRV1":
            raise NotImplementedError(
                "The IW cohort-share covariance currently supports CRV1 clusters only."
            )
        clusters = tuple(part.strip() for part in str(value).split("+") if part.strip())
        if not clusters:
            raise ValueError("CRV1 vcov must specify at least one cluster variable.")
        return VcovSpec("CRV1", clusters)
    raise TypeError("vcov must be None, a string, or a CRV1 dictionary.")


def share_vcov_from_pyfixest(
    models: list[Any], vcov: Any, coef_names: Sequence[str] | None = None
) -> np.ndarray:
    """Build the stacked share covariance from fitted pyfixest share models.

    Each diagonal block is copied from the model's native ``_vcov``. Off-diagonal
    blocks use the same pyfixest cached bread, score, small-sample, and CRV1 meat
    machinery so the only custom work here is the cross-equation stacking that
    pyfixest does not expose as a public multivariate covariance result.
    """
    if not models:
        return np.zeros((0, 0), dtype=float)

    coef_idx = _coef_indices(models, coef_names)
    spec = normalize_vcov(vcov)
    if spec.kind == "iid":
        sigma = _iid_cross_vcov(models, coef_idx)
    elif spec.kind == "hetero":
        sigma = _hetero_cross_vcov(models, coef_idx)
    elif spec.kind == "CRV1":
        sigma = _crv1_cross_vcov(models, coef_idx)
    else:
        raise NotImplementedError(f"Unsupported share covariance kind {spec.kind!r}.")

    _copy_native_diagonal_blocks(sigma, models, coef_idx)
    return sigma


def _iid_cross_vcov(models: list[Any], coef_idx: np.ndarray) -> np.ndarray:
    first = models[0]
    bread = _subset_square(_matrix_attr(first, "_bread"), coef_idx)
    residuals = np.column_stack([_vector_attr(model, "_u_hat") for model in models])
    sigma_e = np.cov(residuals, rowvar=False)
    if sigma_e.ndim == 0:
        sigma_e = np.array([[float(sigma_e)]])

    scale = _ssc_scalar(first)
    return scale * np.kron(sigma_e, bread)


def _hetero_cross_vcov(models: list[Any], coef_idx: np.ndarray) -> np.ndarray:
    first = models[0]
    bread = _subset_square(_matrix_attr(first, "_bread"), coef_idx)
    scores = _stack_scores([_hetero_scores(model)[:, coef_idx] for model in models])
    meat = scores.T @ scores
    return (
        _ssc_scalar(first)
        * _block_bread(bread, len(models))
        @ meat
        @ _block_bread(bread, len(models))
    )


def _crv1_cross_vcov(models: list[Any], coef_idx: np.ndarray) -> np.ndarray:
    first = models[0]
    bread = _subset_square(_matrix_attr(first, "_bread"), coef_idx)
    scores = _stack_scores(
        [_matrix_attr(model, "_scores")[:, coef_idx] for model in models]
    )
    block_bread = _block_bread(bread, len(models))
    out = np.zeros((scores.shape[1], scores.shape[1]), dtype=float)

    cluster_df = getattr(first, "_cluster_df", None)
    if not isinstance(cluster_df, pd.DataFrame) or cluster_df.empty:
        raise ValueError("pyfixest did not expose CRV1 cluster data for share models.")

    ssc = np.asarray(getattr(first, "_ssc", np.array([1.0])), dtype=float).ravel()
    signs = [1.0, 1.0, -1.0]
    for idx, column in enumerate(cluster_df.columns):
        cluster_col = pd.factorize(cluster_df[column], sort=False)[0].astype(np.uintp)
        clustid = np.unique(cluster_col).astype(np.uintp)
        meat = first._crv1_meat_func(  # noqa: SLF001 - pyfixest internal is intentional.
            scores=scores.astype(np.float64),
            clustid=clustid,
            cluster_col=cluster_col,
        )
        scale = ssc[idx] if idx < len(ssc) else signs[idx]
        out += scale * block_bread @ meat @ block_bread
    return out


def _copy_native_diagonal_blocks(
    sigma: np.ndarray, models: list[Any], coef_idx: np.ndarray
) -> None:
    k = len(coef_idx)
    for idx, model in enumerate(models):
        block = _subset_square(np.asarray(model._vcov, dtype=float), coef_idx)  # noqa: SLF001
        sigma[idx * k : (idx + 1) * k, idx * k : (idx + 1) * k] = block


def _hetero_scores(model: Any) -> np.ndarray:
    scores = _matrix_attr(model, "_scores")
    if getattr(model, "_weights_type", None) == "fweights":
        weights = _matrix_attr(model, "_weights")
        scores = scores / np.sqrt(weights)
    return scores


def _stack_scores(score_blocks: list[np.ndarray]) -> np.ndarray:
    return np.column_stack(score_blocks)


def _block_bread(bread: np.ndarray, nblocks: int) -> np.ndarray:
    return np.kron(np.eye(nblocks), bread)


def _matrix_attr(model: Any, attr: str) -> np.ndarray:
    value = getattr(model, attr, None)
    if value is None:
        raise ValueError(f"pyfixest model did not expose {attr}.")
    array = np.asarray(value, dtype=float)
    if array.ndim != 2:
        raise ValueError(f"pyfixest model attribute {attr} is not a matrix.")
    return array


def _vector_attr(model: Any, attr: str) -> np.ndarray:
    value = getattr(model, attr, None)
    if value is None:
        raise ValueError(f"pyfixest model did not expose {attr}.")
    return np.asarray(value, dtype=float).reshape(-1)


def _ssc_scalar(model: Any) -> float:
    ssc = np.asarray(getattr(model, "_ssc", np.array([1.0])), dtype=float).ravel()
    if ssc.size == 0:
        return 1.0
    return float(ssc[0])


def _coef_indices(models: list[Any], coef_names: Sequence[str] | None) -> np.ndarray:
    available = [str(name) for name in models[0].coef().index]
    if coef_names is None:
        return np.arange(len(available), dtype=int)

    positions = []
    missing = []
    for name in coef_names:
        try:
            positions.append(available.index(str(name)))
        except ValueError:
            missing.append(str(name))
    if missing:
        raise ValueError(f"pyfixest model did not expose coefficients {missing}.")

    expected = [str(name) for name in coef_names]
    for model in models[1:]:
        model_names = [str(name) for name in model.coef().index]
        if [model_names[pos] for pos in positions] != expected:
            raise ValueError(
                "Share model coefficient order differs across pyfixest fits."
            )
    return np.asarray(positions, dtype=int)


def _subset_square(matrix: np.ndarray, idx: np.ndarray) -> np.ndarray:
    return matrix[np.ix_(idx, idx)]
