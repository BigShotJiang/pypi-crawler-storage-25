"""Result containers for EventStudyInteracts.py."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import t


@dataclass
class EventStudyInteract:
    """Interaction-weighted event-study result."""

    coefficients: pd.Series
    covariance: pd.DataFrame
    df_t: float
    fml: str
    first_stage_fml: str
    vcov_spec: Any
    nobs: int
    rel_varlist_: list[str]
    cohort_list_: list[Any]
    iw_weights_: pd.DataFrame
    delta_: pd.DataFrame
    aggregation_matrix_: pd.DataFrame
    interacted_model_: Any = None
    stage2_models_: Any = None
    stage2_diagnostics_: dict[str, Any] = field(default_factory=dict)
    demeaner_backend_: str = "numba"

    def coef(self) -> pd.Series:
        """Return IW coefficients."""
        return self.coefficients.copy()

    def vcov(self) -> pd.DataFrame:
        """Return IW variance-covariance matrix."""
        return self.covariance.copy()

    def se(self) -> pd.Series:
        """Return IW standard errors."""
        return pd.Series(
            np.sqrt(np.diag(self.covariance.to_numpy(dtype=float))),
            index=self.coefficients.index,
            name="Std. Error",
        )

    def tstat(self) -> pd.Series:
        """Return t statistics."""
        return self.coef() / self.se()

    def pvalue(self) -> pd.Series:
        """Return two-sided p-values."""
        return pd.Series(
            2 * (1 - t.cdf(np.abs(self.tstat()), self.df_t)),
            index=self.coefficients.index,
            name="Pr(>|t|)",
        )

    def confint(self, alpha: float = 0.05) -> pd.DataFrame:
        """Return pointwise confidence intervals."""
        crit = abs(t.ppf(alpha / 2, self.df_t))
        se = self.se()
        out = pd.DataFrame(
            {
                f"{alpha / 2 * 100:.1f}%": self.coefficients - crit * se,
                f"{(1 - alpha / 2) * 100:.1f}%": self.coefficients + crit * se,
            }
        )
        return out

    def tidy(self, alpha: float = 0.05) -> pd.DataFrame:
        """Return a pyfixest-like tidy DataFrame."""
        conf = self.confint(alpha=alpha)
        out = pd.DataFrame(
            {
                "Estimate": self.coef(),
                "Std. Error": self.se(),
                "t value": self.tstat(),
                "Pr(>|t|)": self.pvalue(),
            }
        )
        return out.join(conf)

    def etable(
        self,
        type: str = "df",
        *,
        file_name: str | Path | None = None,
        alpha: float = 0.05,
        **kwargs: Any,
    ) -> pd.DataFrame | str | None:
        """Export the IW coefficient table.

        This mirrors the common pyfixest ``etable`` output types for the
        already-aggregated IW results. Supported types are ``"df"``, ``"tex"``,
        ``"latex"``, ``"md"``, ``"markdown"``, ``"html"``, and ``"csv"``.
        """
        return _export_table(
            self.tidy(alpha=alpha),
            type=type,
            file_name=file_name,
            **kwargs,
        )

    def lincom(
        self,
        weights: Mapping[str, float] | Sequence[float] | pd.Series,
        *,
        name: str = "lincom",
        alpha: float = 0.05,
    ) -> pd.DataFrame:
        """Estimate an arbitrary linear combination of IW coefficients.

        ``weights`` may be a mapping/Series keyed by coefficient name, in which
        omitted coefficients receive weight zero, or a full-length sequence in
        the same order as ``coef()``. The reported standard error is computed as
        ``sqrt(w' V w)`` from the IW covariance matrix.
        """
        weight_vector = self._align_lincom_weights(weights)
        return self._lincom_from_vector(weight_vector, name=name, alpha=alpha)

    def ate(
        self,
        periods: Sequence[str] | None = None,
        weights: Mapping[str, float] | Sequence[float] | pd.Series | None = None,
        *,
        name: str = "ATE",
        normalize: bool = True,
        alpha: float = 0.05,
    ) -> pd.DataFrame:
        """Average selected IW period coefficients by linear combination.

        If ``periods`` is omitted, simple nonnegative event-time names such as
        ``g0``, ``g1``, and ``rel0`` are used. For binned or heterogeneous names,
        pass the exact coefficient names. By default, each selected period
        receives equal weight. To reproduce a custom ATE definition, pass
        explicit ``weights``. The selected weights are normalized to sum to one
        unless ``normalize=False``.
        """
        if periods is None:
            if weights is None:
                periods = _default_post_periods(self.coefficients.index)
            elif _is_named_weights(weights):
                periods = list(weights.keys())
            else:
                raise ValueError(
                    "ate requires periods when weights are provided as a sequence."
                )

        periods = list(periods)
        if not periods:
            raise ValueError("periods must contain at least one coefficient name.")

        if weights is None:
            values = np.ones(len(periods), dtype=float)
        elif _is_named_weights(weights):
            missing = [period for period in periods if period not in weights]
            if missing:
                raise KeyError(f"ATE weights missing periods: {missing}")
            values = np.array([weights[period] for period in periods], dtype=float)
        else:
            values = np.asarray(list(weights), dtype=float)
            if len(values) != len(periods):
                raise ValueError("ATE weights must match the number of periods.")

        if normalize:
            total = float(values.sum())
            if np.isclose(total, 0.0):
                raise ValueError("ATE weights must not sum to zero.")
            values = values / total

        coefficient_index = self.coefficients.index
        unknown = [period for period in periods if period not in coefficient_index]
        if unknown:
            raise KeyError(f"Unknown coefficient names in periods: {unknown}")

        full_weights = pd.Series(0.0, index=coefficient_index, dtype=float)
        full_weights.loc[periods] = values
        return self._lincom_from_vector(full_weights.to_numpy(), name=name, alpha=alpha)

    def aggregate(
        self,
        agg: str = "period",
        weighting: str | None = "shares",
        alpha: float = 0.05,
        period_index: bool | str = "auto",
    ) -> pd.DataFrame:
        """Return pyfixest-style period aggregation output.

        ``eventreg`` already returns interaction-weighted period estimates, so
        this method is an API-compatible alias for ``tidy()``. When the supplied
        coefficient names are simple event-time names such as ``g_2``, ``g0``,
        ``g1``, ``rel0``, and ``rel1``, the index is converted to pyfixest's
        numeric ``period`` index.
        """
        if agg != "period":
            raise ValueError("agg must be 'period'.")
        if weighting != "shares":
            raise ValueError("weighting must be 'shares'.")
        return _with_period_index(self.tidy(alpha=alpha), period_index=period_index)

    def iplot_aggregate(
        self,
        agg: str = "period",
        weighting: str | None = "shares",
        *,
        show: bool = True,
    ):
        """Plot pyfixest-style period estimates and return the Matplotlib axes."""
        df_agg = self.aggregate(agg=agg, weighting=weighting, period_index=True)
        try:
            time = np.asarray(df_agg.index, dtype=float)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                "iplot_aggregate requires event-time names that can be parsed "
                "as numeric periods, such as g_2, g0, g1, rel0, rel1."
            ) from exc

        import matplotlib.pyplot as plt

        estimate = df_agg["Estimate"].to_numpy(dtype=float)
        ci_lower = df_agg["2.5%"].to_numpy(dtype=float)
        ci_upper = df_agg["97.5%"].to_numpy(dtype=float)

        cmap = plt.get_cmap("Set1")
        _, ax = plt.subplots(figsize=(10, 6))
        color = cmap(len(ax.lines))
        ax.plot(time, estimate, marker="o", color=color)
        ax.fill_between(time, ci_lower, ci_upper, alpha=0.3, color=color)
        ax.axhline(0, color="black", linewidth=1, linestyle="--")
        ax.set_xlabel("Time")
        ax.set_ylabel("Coefficient (with 95% CI)")
        ax.set_title("Event Study Estimates")
        plt.tight_layout()
        if show:
            plt.show()
        return ax

    def _align_lincom_weights(
        self, weights: Mapping[str, float] | Sequence[float] | pd.Series
    ) -> np.ndarray:
        coefficient_index = self.coefficients.index
        if _is_named_weights(weights):
            unknown = [term for term in weights.keys() if term not in coefficient_index]
            if unknown:
                raise KeyError(
                    f"Unknown coefficient names in lincom weights: {unknown}"
                )
            vector = pd.Series(0.0, index=coefficient_index, dtype=float)
            for term, value in weights.items():
                vector.loc[term] = float(value)
            return vector.to_numpy(dtype=float)

        vector = np.asarray(list(weights), dtype=float)
        if len(vector) != len(coefficient_index):
            raise ValueError(
                "Sequence weights must have the same length and order as coef()."
            )
        return vector

    def _lincom_from_vector(
        self, weights: np.ndarray, *, name: str, alpha: float
    ) -> pd.DataFrame:
        if np.isclose(np.abs(weights).sum(), 0.0):
            raise ValueError("Linear-combination weights must not all be zero.")

        active = ~np.isclose(weights, 0.0)
        active_weights = weights[active]
        beta = self.coefficients.to_numpy(dtype=float)[active]
        vcov = self.covariance.to_numpy(dtype=float)[np.ix_(active, active)]
        estimate = float(active_weights @ beta)
        variance = float(active_weights @ vcov @ active_weights)
        if np.isfinite(variance) and variance < 0 and np.isclose(variance, 0.0):
            variance = 0.0
        std_error = float(np.sqrt(variance)) if variance >= 0 else np.nan

        if std_error > 0:
            statistic = estimate / std_error
            p_value = float(2 * (1 - t.cdf(abs(statistic), self.df_t)))
        elif np.isclose(std_error, 0.0):
            statistic = np.inf if estimate > 0 else -np.inf if estimate < 0 else np.nan
            p_value = 0.0 if not np.isnan(statistic) else np.nan
        else:
            statistic = np.nan
            p_value = np.nan

        crit = abs(t.ppf(alpha / 2, self.df_t))
        conf_low = estimate - crit * std_error if np.isfinite(std_error) else np.nan
        conf_high = estimate + crit * std_error if np.isfinite(std_error) else np.nan
        return pd.DataFrame(
            {
                "Estimate": [estimate],
                "Std. Error": [std_error],
                "t value": [statistic],
                "Pr(>|t|)": [p_value],
                f"{alpha / 2 * 100:.1f}%": [conf_low],
                f"{(1 - alpha / 2) * 100:.1f}%": [conf_high],
            },
            index=pd.Index([name], name="Coefficient"),
        )

    def summary(self, alpha: float = 0.05) -> str:
        """Return a compact text summary."""
        header = [
            "EventStudyInteract IW estimator",
            f"Formula: {self.fml}",
            f"First stage: {self.first_stage_fml}",
            f"Observations: {self.nobs}",
            f"Vcov: {self.vcov_spec}",
            f"Demeaner backend: {self.demeaner_backend_}",
        ]
        return "\n".join(header) + "\n\n" + self.tidy(alpha=alpha).to_string()


@dataclass
class EventStudyInteractMulti:
    """Container for split event-study fits."""

    models: dict[Any, EventStudyInteract]
    split: str
    include_full_sample: bool = False

    def keys(self):
        """Return split keys."""
        return self.models.keys()

    def __getitem__(self, key: Any) -> EventStudyInteract:
        return self.models[key]

    def items(self):
        """Return split model items."""
        return self.models.items()

    def tidy(self, alpha: float = 0.05) -> pd.DataFrame:
        """Return stacked tidy output for all split models."""
        frames = []
        for key, model in self.models.items():
            frame = model.tidy(alpha=alpha).copy()
            frame.insert(0, self.split, key)
            frames.append(frame)
        return pd.concat(frames, axis=0)

    def etable(
        self,
        type: str = "df",
        *,
        file_name: str | Path | None = None,
        alpha: float = 0.05,
        **kwargs: Any,
    ) -> pd.DataFrame | str | None:
        """Export stacked split-model coefficient tables."""
        return _export_table(
            self.tidy(alpha=alpha),
            type=type,
            file_name=file_name,
            **kwargs,
        )

    def aggregate(
        self,
        agg: str = "period",
        weighting: str | None = "shares",
        alpha: float = 0.05,
        period_index: bool | str = "auto",
    ) -> pd.DataFrame:
        """Return stacked aggregate output for all split models."""
        frames = []
        for key, model in self.models.items():
            frame = model.aggregate(
                agg=agg,
                weighting=weighting,
                alpha=alpha,
                period_index=period_index,
            ).copy()
            frame.insert(0, self.split, key)
            frames.append(frame)
        return pd.concat(frames, axis=0)

    def lincom(
        self,
        weights: Mapping[str, float] | Sequence[float] | pd.Series,
        *,
        name: str = "lincom",
        alpha: float = 0.05,
    ) -> pd.DataFrame:
        """Return stacked linear-combination output for all split models."""
        frames = []
        for key, model in self.models.items():
            frame = model.lincom(weights, name=name, alpha=alpha).copy()
            frame.insert(0, self.split, key)
            frames.append(frame)
        return pd.concat(frames, axis=0)

    def ate(
        self,
        periods: Sequence[str] | None = None,
        weights: Mapping[str, float] | Sequence[float] | pd.Series | None = None,
        *,
        name: str = "ATE",
        normalize: bool = True,
        alpha: float = 0.05,
    ) -> pd.DataFrame:
        """Return stacked ATE output for all split models."""
        frames = []
        for key, model in self.models.items():
            frame = model.ate(
                periods=periods,
                weights=weights,
                name=name,
                normalize=normalize,
                alpha=alpha,
            ).copy()
            frame.insert(0, self.split, key)
            frames.append(frame)
        return pd.concat(frames, axis=0)

    def summary(self, alpha: float = 0.05) -> str:
        """Return summaries for all split models."""
        return "\n\n".join(
            f"=== {self.split} = {key} ===\n{model.summary(alpha=alpha)}"
            for key, model in self.models.items()
        )


def _is_named_weights(value: Any) -> bool:
    return isinstance(value, Mapping) or isinstance(value, pd.Series)


def _default_post_periods(index: pd.Index) -> list[str]:
    periods = []
    for term in index:
        period = _parse_event_period(str(term))
        if period is not None and period >= 0:
            periods.append(str(term))
    if not periods:
        raise ValueError(
            "ate() could not infer post-treatment periods from coefficient names. "
            "Pass periods explicitly for binned or heterogeneous columns."
        )
    return periods


def _export_table(
    table: pd.DataFrame,
    *,
    type: str,
    file_name: str | Path | None,
    **kwargs: Any,
) -> pd.DataFrame | str | None:
    kind = type.lower()
    if kind == "df":
        if file_name is not None:
            table.to_csv(file_name, **kwargs)
            return None
        return table
    if kind in {"tex", "latex"}:
        try:
            out = table.to_latex(**kwargs)
        except ImportError:
            out = _plain_latex_table(table)
    elif kind in {"md", "markdown"}:
        try:
            out = table.to_markdown(**kwargs)
        except ImportError:
            out = _plain_markdown_table(table)
    elif kind == "html":
        out = table.to_html(**kwargs)
    elif kind == "csv":
        out = table.to_csv(**kwargs)
    else:
        raise ValueError(
            "type must be one of 'df', 'tex', 'latex', 'md', 'markdown', "
            "'html', or 'csv'."
        )

    if file_name is not None:
        Path(file_name).write_text(out, encoding="utf-8")
        return None
    return out


def _with_period_index(
    table: pd.DataFrame, *, period_index: bool | str
) -> pd.DataFrame:
    if period_index not in {True, False, "auto"}:
        raise ValueError("period_index must be True, False, or 'auto'.")
    if period_index is False:
        return table

    parsed = [_parse_event_period(str(term)) for term in table.index]
    parseable = all(period is not None for period in parsed)
    unique_periods = len(set(parsed)) == len(parsed)
    if not parseable or not unique_periods:
        if period_index is True:
            raise ValueError(
                "aggregate(period_index=True) requires one unique numeric "
                "event time per coefficient. Use simple names such as g_2, "
                "g0, g1, rel0, rel1, or pass period_index=False."
            )
        return table

    out = table.copy()
    out.index = pd.Index([float(period) for period in parsed], name="period")
    return out.sort_index()


def _parse_event_period(term: str) -> int | None:
    patterns = [
        (r"g_(\d+)", -1),
        (r"g(\d+)", 1),
        (r"rel_(\d+)", -1),
        (r"rel(-?\d+)", 1),
    ]
    for pattern, sign in patterns:
        match = re.fullmatch(pattern, term)
        if match:
            return sign * int(match.group(1))
    return None


def _plain_latex_table(table: pd.DataFrame) -> str:
    frame = table.reset_index()
    align = "l" + "r" * (len(frame.columns) - 1)
    lines = [f"\\begin{{tabular}}{{{align}}}", "\\toprule"]
    lines.append(" & ".join(_latex_escape(str(col)) for col in frame.columns) + r" \\")
    lines.append("\\midrule")
    for row in frame.itertuples(index=False, name=None):
        lines.append(
            " & ".join(_latex_escape(_format_cell(value)) for value in row) + r" \\"
        )
    lines.extend(["\\bottomrule", "\\end{tabular}"])
    return "\n".join(lines)


def _plain_markdown_table(table: pd.DataFrame) -> str:
    frame = table.reset_index()
    headers = [str(col) for col in frame.columns]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in frame.itertuples(index=False, name=None):
        lines.append("| " + " | ".join(_format_cell(value) for value in row) + " |")
    return "\n".join(lines)


def _format_cell(value: Any) -> str:
    if pd.isna(value):
        return ""
    if isinstance(value, float):
        return f"{value:.6g}"
    return str(value)


def _latex_escape(value: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(char, char) for char in value)
