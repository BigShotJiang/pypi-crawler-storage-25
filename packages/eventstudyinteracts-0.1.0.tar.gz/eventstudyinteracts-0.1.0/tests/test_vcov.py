from __future__ import annotations

import numpy as np
import pandas as pd
import pyfixest as pf

from eventstudyinteracts._vcov import share_vcov_from_pyfixest
from eventstudyinteracts.eventreg import _ordered_share_models


def test_share_vcov_uses_native_pyfixest_diagonal_blocks() -> None:
    data = pd.DataFrame(
        {
            "y1": [1.0, 0.0, 1.0, 0.0, 1.0, 0.0],
            "y2": [0.0, 1.0, 0.0, 1.0, 0.0, 1.0],
            "x1": [1.0, 2.0, 1.0, 3.0, 2.0, 1.0],
            "x2": [0.0, 1.0, 1.0, 0.0, 1.0, 0.0],
            "cluster": [1, 1, 2, 2, 3, 3],
        }
    )
    fit = pf.feols(
        "y1 + y2 ~ 0 + x1 + x2",
        data,
        vcov={"CRV1": "cluster"},
        store_data=True,
        lean=False,
    )
    models = _ordered_share_models(fit, ["y1", "y2"], ["x1", "x2"])

    sigma = share_vcov_from_pyfixest(models, {"CRV1": "cluster"}, ["x1", "x2"])

    np.testing.assert_allclose(sigma[:2, :2], models[0]._vcov)
    np.testing.assert_allclose(sigma[2:, 2:], models[1]._vcov)
    assert sigma.shape == (4, 4)
    assert np.allclose(sigma, sigma.T)


def test_share_vcov_subsets_extra_pyfixest_coefficients() -> None:
    data = pd.DataFrame(
        {
            "y1": [1.0, 0.0, 1.0, 0.0, 1.0, 0.0],
            "y2": [0.0, 1.0, 0.0, 1.0, 0.0, 1.0],
            "x1": [1.0, 2.0, 1.0, 3.0, 2.0, 1.0],
            "x2": [0.0, 1.0, 1.0, 0.0, 1.0, 0.0],
        }
    )
    fit = pf.feols(
        "y1 + y2 ~ x1 + x2", data, vcov="hetero", store_data=True, lean=False
    )
    models = _ordered_share_models(fit, ["y1", "y2"], ["x1", "x2"])

    sigma = share_vcov_from_pyfixest(models, "hetero", ["x1", "x2"])

    assert sigma.shape == (4, 4)
    for idx, model in enumerate(models):
        coef_names = [str(name) for name in model.coef().index]
        keep = np.asarray([coef_names.index("x1"), coef_names.index("x2")])
        expected = model._vcov[np.ix_(keep, keep)]
        np.testing.assert_allclose(
            sigma[idx * 2 : idx * 2 + 2, idx * 2 : idx * 2 + 2], expected
        )
