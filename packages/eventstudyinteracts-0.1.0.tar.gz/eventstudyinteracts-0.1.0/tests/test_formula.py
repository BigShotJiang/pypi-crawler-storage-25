import pytest

from eventstudyinteracts._formula import (
    build_interacted_formula,
    relative_terms_from_formula,
    split_fixest_formula,
)


def test_split_fixest_formula_preserves_sections() -> None:
    lhs, rhs, trailing = split_fixest_formula("y ~ x1 + x2 | id + year | x3 ~ z")

    assert lhs == "y"
    assert rhs == "x1 + x2"
    assert trailing == ["id + year", "x3 ~ z"]


def test_relative_terms_from_formula_reads_public_varlist() -> None:
    assert relative_terms_from_formula("y ~ g_2 + g0 + g1 + 0 | id") == [
        "g_2",
        "g0",
        "g1",
    ]


def test_build_interacted_formula_prepends_terms() -> None:
    fml = build_interacted_formula(
        "y ~ rel0 + rel1 | id + year",
        ["d0_c2000", "d1_c2000"],
        ["rel0", "rel1"],
        covariates="x",
    )

    assert fml == "y ~ d0_c2000 + d1_c2000 + x | id + year"


def test_build_interacted_formula_removes_dropped_relative_terms() -> None:
    fml = build_interacted_formula(
        "y ~ rel_empty + rel0 + rel1 | id + year",
        ["d0_c2000", "d1_c2000"],
        ["rel_empty", "rel0", "rel1"],
        covariates=["x1", "x2"],
    )

    assert fml == "y ~ d0_c2000 + d1_c2000 + x1 + x2 | id + year"
    assert "rel_empty" not in fml


def test_build_interacted_formula_requires_interactions() -> None:
    with pytest.raises(ValueError, match="interaction"):
        build_interacted_formula("y ~ rel0", [], ["rel0"])


def test_build_interacted_formula_requires_relative_terms_in_rhs() -> None:
    with pytest.raises(ValueError, match="rel_varlist"):
        build_interacted_formula("y ~ x", ["d0_c2000"], ["rel0"])
