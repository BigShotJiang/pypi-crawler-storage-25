from __future__ import annotations

from importlib import import_module
from pathlib import Path

import numpy as np
import pandas as pd
import pyfixest as pf
import pytest

from eventstudyinteracts import eventreg
from eventstudyinteracts.results import EventStudyInteractMulti

eventreg_module = import_module("eventstudyinteracts.eventreg")

NLSWORK_STATA_JULIA_COEFFICIENTS = {
    "g_20": 0.111521,
    "g_19": 0.118273,
    "g_18": -0.065599,
    "g_17": 0.045408,
    "g_16": -0.023468,
    "g_15": -0.208510,
    "g_14": -0.239402,
    "g_13": 0.030483,
    "g_12": -0.137610,
    "g_11": -0.072454,
    "g_10": -0.062828,
    "g_9": -0.005676,
    "g_8": -0.102414,
    "g_7": -0.157051,
    "g_6": -0.075605,
    "g_5": -0.082136,
    "g_4": -0.060458,
    "g_3": -0.024659,
    "g_2": 0.001476,
    "g0": 0.131608,
    "g1": 0.177707,
    "g2": 0.132955,
    "g3": 0.149590,
    "g4": 0.173574,
    "g5": 0.109222,
    "g6": 0.220026,
    "g7": 0.091162,
    "g8": 0.086815,
    "g9": 0.090069,
    "g10": 0.084064,
    "g11": 0.238607,
    "g12": 0.052962,
    "g13": 0.127699,
    "g14": 0.163854,
    "g15": 0.048220,
    "g16": 0.156411,
    "g17": 0.011056,
    "g18": -0.120038,
}

NLSWORK_STATA_JULIA_STD_ERRORS = {
    "g_20": 0.117627,
    "g_19": 0.123875,
    "g_18": 0.143241,
    "g_17": 0.091193,
    "g_16": 0.134788,
    "g_15": 0.098071,
    "g_14": 0.218520,
    "g_13": 0.082729,
    "g_12": 0.119322,
    "g_11": 0.081821,
    "g_10": 0.067886,
    "g_9": 0.113382,
    "g_8": 0.050492,
    "g_7": 0.096727,
    "g_6": 0.044112,
    "g_5": 0.041537,
    "g_4": 0.043256,
    "g_3": 0.023623,
    "g_2": 0.020685,
    "g0": 0.014452,
    "g1": 0.021273,
    "g2": 0.023436,
    "g3": 0.030111,
    "g4": 0.028911,
    "g5": 0.026382,
    "g6": 0.036536,
    "g7": 0.031269,
    "g8": 0.043150,
    "g9": 0.038735,
    "g10": 0.034473,
    "g11": 0.049075,
    "g12": 0.040980,
    "g13": 0.045539,
    "g14": 0.056483,
    "g15": 0.048456,
    "g16": 0.056808,
    "g17": 0.048943,
    "g18": 0.067475,
}


def _balanced_iw_data() -> pd.DataFrame:
    rows = []
    for cohort, effects in [(2, {0: 1.0, 1: 2.0}), (3, {0: 3.0, 1: 4.0})]:
        for unit in range(2):
            for rel in [0, 1]:
                rows.append(
                    {
                        "unit": f"{cohort}-{unit}",
                        "cohort": cohort,
                        "control": False,
                        "rel0": float(rel == 0),
                        "rel1": float(rel == 1),
                        "y": effects[rel],
                        "region": "east" if cohort == 2 else "west",
                    }
                )
    for unit, region in enumerate(["east", "west"]):
        for _rel in [0, 1]:
            rows.append(
                {
                    "unit": f"c-{unit}",
                    "cohort": 999,
                    "control": True,
                    "rel0": 0.0,
                    "rel1": 0.0,
                    "y": 0.0,
                    "region": region,
                }
            )
    return pd.DataFrame(rows)


def _fixed_effect_data() -> pd.DataFrame:
    rows = []
    for unit, cohort in enumerate([2, 2, 3, 3, 999, 999]):
        control = cohort == 999
        for time in range(1, 6):
            rel = -99 if control else time - cohort
            effect = 1.0 if rel == 0 else 2.0 if rel == 1 else 0.0
            rows.append(
                {
                    "unit": unit,
                    "time": time,
                    "cohort": cohort,
                    "control": control,
                    "rel0": float(rel == 0),
                    "rel1": float(rel == 1),
                    "y": unit * 0.2 + time * 0.3 + effect,
                }
            )
    return pd.DataFrame(rows)


def _single_cohort_twfe_data() -> pd.DataFrame:
    rows = []
    for unit, cohort in enumerate([2, 2, 999, 999, 999]):
        control = cohort == 999
        for time in range(1, 6):
            rel = -99 if control else time - cohort
            effect = 1.0 if rel == 0 else 2.0 if rel == 1 else 0.0
            noise = ((unit + 1) * (time + 2) % 5) * 0.1
            rows.append(
                {
                    "unit": unit,
                    "time": time,
                    "cohort": cohort,
                    "control": control,
                    "rel0": float(rel == 0),
                    "rel1": float(rel == 1),
                    "y": unit * 0.2 + time * 0.3 + effect + noise,
                }
            )
    return pd.DataFrame(rows)


def _single_cohort_dynamic_data() -> tuple[pd.DataFrame, list[str], list[str]]:
    rng = np.random.default_rng(123)
    rows = []
    n_ids = 96
    n_periods = 10
    treat_time = 5
    unit_fe = rng.normal(size=n_ids)
    time_fe = rng.normal(size=n_periods + 1)
    unit_slope = rng.normal(size=n_ids)
    treated_time_shock = rng.normal(size=n_periods + 1)
    id_noise = rng.normal(size=(n_ids, n_periods + 1))
    iid_noise = rng.normal(size=(n_ids, n_periods + 1))
    effects = {-3: 0.0, -2: 0.0, 0: 1.0, 1: 1.4, 2: 1.8, 3: 2.1}

    for unit in range(n_ids):
        treated = unit < n_ids // 2
        first_treat = treat_time if treated else 999
        for time in range(1, n_periods + 1):
            rel = -999 if not treated else time - first_treat
            centered_time = time - (n_periods + 1) / 2
            residual = (
                0.35 * unit_slope[unit] * centered_time / n_periods
                + 0.55 * treated * treated_time_shock[time]
                + 0.25 * id_noise[unit, time]
                + 0.20 * iid_noise[unit, time]
            )
            row = {
                "id": unit,
                "t": time,
                "first_treat": first_treat,
                "never_treat": not treated,
                "y": unit_fe[unit] + time_fe[time] + effects.get(rel, 0.0) + residual,
            }
            for lag in [3, 2]:
                row[f"g_{lag}"] = float(rel == -lag)
            for lead in [0, 1, 2, 3]:
                row[f"g{lead}"] = float(rel == lead)
            rows.append(row)

    rel_vars = ["g_3", "g_2", "g0", "g1", "g2", "g3"]
    post_vars = ["g0", "g1", "g2", "g3"]
    return pd.DataFrame(rows), rel_vars, post_vars


def _nlswork_reference_data() -> tuple[pd.DataFrame, list[str]]:
    path = Path(__file__).resolve().parents[1] / "dataset" / "nlswork.dta"
    df = pd.read_stata(path)
    df["union_year"] = np.where(df["union"].fillna(0).eq(1), df["year"], np.nan)
    df["first_union"] = df.groupby("idcode")["union_year"].transform("min")
    df = df.drop(columns=["union_year"])
    df["ry"] = df["year"] - df["first_union"]
    df["never_union"] = df["first_union"].isna()

    ids_with_ref = df.loc[df["ry"].eq(-1), "idcode"].unique()
    df = df.loc[df["never_union"] | df["idcode"].isin(ids_with_ref)].copy()

    rel_columns = {}
    event_vars = []
    for k in range(int(abs(np.nanmin(df["ry"]))), 1, -1):
        rel_columns[f"g_{k}"] = df["ry"].eq(-k).fillna(False).astype(int)
        event_vars.append(f"g_{k}")
    for k in range(0, int(abs(np.nanmax(df["ry"]))) + 1):
        rel_columns[f"g{k}"] = df["ry"].eq(k).fillna(False).astype(int)
        event_vars.append(f"g{k}")
    df = pd.concat(
        [
            df.drop(columns=list(rel_columns), errors="ignore"),
            pd.DataFrame(rel_columns, index=df.index),
        ],
        axis=1,
    )
    return df, event_vars


def _multife_control_data() -> pd.DataFrame:
    rows = []
    cohort_by_unit = {
        0: 2,
        1: 2,
        2: 3,
        3: 3,
        4: 4,
        5: 4,
        6: 999,
        7: 999,
        8: 999,
    }
    effects = {
        2: {0: 1.0, 1: 2.0},
        3: {0: 3.0, 1: 4.0},
        4: {0: 5.0, 1: 6.0},
    }
    for unit, cohort in cohort_by_unit.items():
        control = cohort == 999
        for time in range(1, 6):
            market = (unit + 2 * time) % 4
            x = ((3 * unit + 5 * time) % 13) / 10
            rel = -99 if control else time - cohort
            treatment_effect = effects.get(cohort, {}).get(rel, 0.0)
            y = unit * 0.2 + time * 0.3 + market * 0.4 + 0.7 * x + treatment_effect
            rows.append(
                {
                    "unit": unit,
                    "time": time,
                    "market": market,
                    "cohort": cohort,
                    "control": control,
                    "rel0": float(rel == 0),
                    "rel1": float(rel == 1),
                    "x": x,
                    "y": y,
                }
            )
    return pd.DataFrame(rows)


def _manual_heterogeneity_data() -> pd.DataFrame:
    effects = {
        "low": {0: 1.0, 1: 2.0},
        "high": {0: 3.0, 1: 4.0},
    }
    rows = []
    for cohort in [2, 3]:
        for group in ["low", "high"]:
            for rel in [0, 1]:
                row = {
                    "unit": f"{cohort}-{group}-{rel}",
                    "cohort": cohort,
                    "control": False,
                    "group": group,
                    "y": effects[group][rel],
                }
                for name in ["rel0_low", "rel0_high", "rel1_low", "rel1_high"]:
                    row[name] = 0.0
                row[f"rel{rel}_{group}"] = 1.0
                rows.append(row)

    for group in ["low", "high"]:
        row = {
            "unit": f"control-{group}",
            "cohort": 0,
            "control": True,
            "group": group,
            "y": 0.0,
        }
        for name in ["rel0_low", "rel0_high", "rel1_low", "rel1_high"]:
            row[name] = 0.0
        rows.append(row)
    return pd.DataFrame(rows)


def test_multi_cohort_iw_coefficients_and_weights() -> None:
    fit = eventreg(
        "y ~ rel0 + rel1 + 0",
        _balanced_iw_data(),
        cohort="cohort",
        control_cohort="control",
        vcov="hetero",
    )

    np.testing.assert_allclose(fit.coef().to_numpy(), [2.0, 3.0], atol=1e-10)
    np.testing.assert_allclose(fit.iw_weights_.to_numpy(), [[0.5, 0.5], [0.5, 0.5]])
    np.testing.assert_allclose(fit.delta_.to_numpy(), [[1.0, 2.0], [3.0, 4.0]])
    np.testing.assert_allclose(fit.aggregate().loc[[0.0, 1.0], "Estimate"], [2.0, 3.0])
    np.testing.assert_allclose(
        fit.aggregation_matrix_.loc[["rel0", "rel1"]].to_numpy(),
        [[0.5, 0.5, 0.0, 0.0], [0.0, 0.0, 0.5, 0.5]],
    )
    assert fit.stage2_diagnostics_["pyfixest_native_vcov"] is True
    assert fit.stage2_diagnostics_["share_weight_method"] == "count_share"
    assert fit.stage2_diagnostics_["share_vcov"] == "regression"
    assert fit.stage2_models_ is not None
    assert "rel0 + rel1" not in fit.first_stage_fml


def test_all_zero_relative_column_is_not_kept_as_control() -> None:
    data = _balanced_iw_data()
    data["rel_empty"] = 0.0

    fit = eventreg(
        "y ~ rel_empty + rel0 + rel1 + 0",
        data,
        cohort="cohort",
        control_cohort="control",
        vcov="hetero",
    )

    assert fit.coef().index.tolist() == ["rel_empty", "rel0", "rel1"]
    assert fit.coef().loc["rel_empty"] == 0.0
    assert np.isnan(fit.vcov().loc["rel_empty", "rel_empty"])
    assert "rel_empty" not in fit.first_stage_fml
    np.testing.assert_allclose(
        fit.ate(["rel0"], name="ATE_rel0").loc["ATE_rel0", "Std. Error"],
        fit.se().loc["rel0"],
    )


def test_formula_rhs_marks_relatives_and_keeps_controls() -> None:
    data = _fixed_effect_data()
    data["x"] = data["unit"] * 0.0 + 1.0

    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        data,
        cohort="cohort",
        control_cohort="control",
        covariates="x",
        vcov={"CRV1": "unit"},
    )

    np.testing.assert_allclose(fit.coef().to_numpy(), [1.0, 2.0], atol=1e-9)
    assert " + x | unit + time" in fit.first_stage_fml
    assert "rel0 + rel1" not in fit.first_stage_fml


def test_formula_must_include_public_event_study_varlist() -> None:
    with pytest.raises(ValueError, match="relative-time variables"):
        eventreg(
            "y ~ 1 | unit + time",
            _fixed_effect_data(),
            cohort="cohort",
            control_cohort="control",
        )


def test_legacy_rel_varlist_must_match_formula_terms() -> None:
    with pytest.raises(ValueError, match="must match the formula"):
        eventreg(
            "y ~ 1 | unit + time",
            _fixed_effect_data(),
            ["rel0", "rel1"],
            cohort="cohort",
            control_cohort="control",
        )

    with pytest.raises(ValueError, match="must match the formula"):
        eventreg(
            "y ~ rel0 + rel1 + x | unit + time",
            _fixed_effect_data().assign(x=1.0),
            ["rel0", "rel1"],
            cohort="cohort",
            control_cohort="control",
        )


def test_lincom_and_ate_use_iw_covariance() -> None:
    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        _single_cohort_twfe_data(),
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov="iid",
    )

    ate = fit.ate(["rel0", "rel1"])
    inferred_ate = fit.ate()
    ate_weights = np.array([0.5, 0.5])
    expected_ate = float(ate_weights @ fit.coef().loc[["rel0", "rel1"]])
    expected_ate_se = float(
        np.sqrt(
            ate_weights
            @ fit.vcov().loc[["rel0", "rel1"], ["rel0", "rel1"]]
            @ ate_weights
        )
    )

    np.testing.assert_allclose(ate.loc["ATE", "Estimate"], expected_ate)
    np.testing.assert_allclose(ate.loc["ATE", "Std. Error"], expected_ate_se)
    np.testing.assert_allclose(inferred_ate.loc["ATE", "Estimate"], expected_ate)
    np.testing.assert_allclose(inferred_ate.loc["ATE", "Std. Error"], expected_ate_se)

    diff = fit.lincom({"rel1": 1.0, "rel0": -1.0}, name="rel1_minus_rel0")
    diff_weights = np.array([-1.0, 1.0])
    expected_diff = float(diff_weights @ fit.coef().loc[["rel0", "rel1"]])
    expected_diff_se = float(
        np.sqrt(
            diff_weights
            @ fit.vcov().loc[["rel0", "rel1"], ["rel0", "rel1"]]
            @ diff_weights
        )
    )

    np.testing.assert_allclose(diff.loc["rel1_minus_rel0", "Estimate"], expected_diff)
    np.testing.assert_allclose(
        diff.loc["rel1_minus_rel0", "Std. Error"], expected_diff_se
    )


def test_etable_exports_iw_results() -> None:
    fit = eventreg(
        "y ~ rel0 + rel1 + 0",
        _balanced_iw_data(),
        cohort="cohort",
        control_cohort="control",
        vcov="hetero",
    )

    table = fit.etable(type="df")
    assert isinstance(table, pd.DataFrame)
    assert table.index.tolist() == ["rel0", "rel1"]
    assert "Estimate" in fit.etable(type="tex")
    assert "rel0" in fit.etable(type="csv")


def test_control_cohort_indicator_overrides_missing_or_zero_cohort_code() -> None:
    data = _fixed_effect_data()
    missing_control = data.copy()
    zero_control = data.copy()
    missing_control.loc[missing_control["control"], "cohort"] = np.nan
    zero_control.loc[zero_control["control"], "cohort"] = 0

    fit_missing = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        missing_control,
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov={"CRV1": "unit"},
    )
    fit_zero = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        zero_control,
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov={"CRV1": "unit"},
    )

    np.testing.assert_allclose(fit_missing.coef().to_numpy(), fit_zero.coef())
    np.testing.assert_allclose(fit_missing.vcov().to_numpy(), fit_zero.vcov())
    assert fit_missing.cohort_list_ == fit_zero.cohort_list_ == [2.0, 3.0]


def test_manual_binning_uses_user_supplied_relative_time_columns() -> None:
    data = _balanced_iw_data()
    data["rel_bin"] = data["rel0"] + data["rel1"]
    data["y_bin"] = np.select(
        [
            (~data["control"]) & (data["cohort"] == 2),
            (~data["control"]) & (data["cohort"] == 3),
        ],
        [2.0, 4.0],
        default=0.0,
    )

    fit = eventreg(
        "y_bin ~ rel_bin + 0",
        data,
        ["rel_bin"],
        cohort="cohort",
        control_cohort="control",
    )

    np.testing.assert_allclose(fit.coef().to_numpy(), [3.0], atol=1e-12)
    np.testing.assert_allclose(fit.iw_weights_.to_numpy(), [[0.5], [0.5]])
    np.testing.assert_allclose(fit.delta_.to_numpy(), [[2.0], [4.0]])


def test_manual_heterogeneity_uses_user_supplied_interacted_relatives() -> None:
    rel_vars = ["rel0_low", "rel0_high", "rel1_low", "rel1_high"]
    fit = eventreg(
        "y ~ rel0_low + rel0_high + rel1_low + rel1_high + 0",
        _manual_heterogeneity_data(),
        rel_vars,
        cohort="cohort",
        control_cohort="control",
    )

    expected = pd.Series(
        [1.0, 3.0, 2.0, 4.0],
        index=pd.Index(rel_vars, name="Coefficient"),
        name="Estimate",
    )
    pd.testing.assert_series_equal(fit.coef(), expected, check_exact=False, atol=1e-12)
    np.testing.assert_allclose(fit.iw_weights_.to_numpy(), np.full((2, 4), 0.5))
    assert fit.aggregate().index.tolist() == rel_vars


def test_fixed_effect_path_keeps_pyfixest_backend_choice() -> None:
    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        _fixed_effect_data(),
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov={"CRV1": "unit"},
        demeaner_backend="scipy",
    )

    np.testing.assert_allclose(fit.coef().to_numpy(), [1.0, 2.0], atol=1e-9)
    assert fit.demeaner_backend_ == "scipy"
    assert fit.interacted_model_._demeaner_backend == "scipy"


def test_saturated_path_supports_continuous_controls_and_multiway_fe() -> None:
    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time + market",
        _multife_control_data(),
        cohort="cohort",
        control_cohort="control",
        covariates="x",
        vcov="iid",
    )

    np.testing.assert_allclose(fit.coef().to_numpy(), [3.0, 4.0], atol=1e-9)
    np.testing.assert_allclose(fit.interacted_model_.coef().loc["x"], 0.7, atol=1e-9)
    np.testing.assert_allclose(
        fit.iw_weights_.to_numpy(),
        np.full((3, 2), 1 / 3),
        atol=1e-12,
    )
    assert fit.interacted_model_._n_fe == 3
    assert "x" in fit.first_stage_fml
    assert "| unit + time + market" in fit.first_stage_fml
    assert fit.stage2_diagnostics_["first_stage_vcov"] == {
        "correction": "pyfixest",
        "scale": 1.0,
        "reason": "pyfixest_native",
    }


def test_pyfixest_interacted_fixed_effect_syntax_is_preserved() -> None:
    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time + market^time",
        _multife_control_data(),
        cohort="cohort",
        control_cohort="control",
        covariates="x",
        vcov="iid",
    )

    np.testing.assert_allclose(fit.coef().to_numpy(), [3.0, 4.0], atol=1e-9)
    assert "| unit + time + market^time" in fit.first_stage_fml
    assert fit.interacted_model_._n_fe == 3


def test_single_cohort_twfe_defaults_match_direct_pyfixest_vcov() -> None:
    data = _single_cohort_twfe_data()
    specs = [
        "iid",
        "hetero",
        {"CRV1": "unit"},
        {"CRV1": "unit + time"},
    ]

    for spec in specs:
        direct = pf.feols("y ~ rel0 + rel1 | unit + time", data, vcov=spec)
        fit = eventreg(
            "y ~ rel0 + rel1 | unit + time",
            data,
            ["rel0", "rel1"],
            cohort="cohort",
            control_cohort="control",
            vcov=spec,
        )
        names = list(direct.coef().index)
        idx = [names.index("rel0"), names.index("rel1")]
        direct_vcov = np.asarray(direct._vcov)[np.ix_(idx, idx)]

        np.testing.assert_allclose(
            fit.coef().to_numpy(),
            direct.coef().reindex(["rel0", "rel1"]).to_numpy(),
            atol=1e-12,
        )
        np.testing.assert_allclose(fit.vcov().to_numpy(), direct_vcov, atol=1e-12)
        assert fit.stage2_diagnostics_["first_stage_vcov"] == {
            "correction": "pyfixest",
            "scale": 1.0,
            "reason": "pyfixest_native",
        }


def test_single_cohort_dynamic_two_way_cluster_matches_direct_pyfixest() -> None:
    data, rel_vars, post_vars = _single_cohort_dynamic_data()
    fml = f"y ~ {' + '.join(rel_vars)} | id + t"
    direct = pf.feols(fml, data, vcov={"CRV1": "id + t"})
    fit = eventreg(
        fml,
        data,
        cohort="first_treat",
        control_cohort="never_treat",
        vcov={"CRV1": "id + t"},
    )
    names = list(direct.coef().index)
    idx = [names.index(term) for term in rel_vars]
    direct_vcov = np.asarray(direct._vcov)[np.ix_(idx, idx)]

    np.testing.assert_allclose(
        fit.coef().to_numpy(),
        direct.coef().reindex(rel_vars).to_numpy(),
        atol=1e-12,
    )
    np.testing.assert_allclose(fit.vcov().to_numpy(), direct_vcov, atol=1e-12)

    weights = np.array(
        [1 / len(post_vars) if term in post_vars else 0 for term in rel_vars]
    )
    expected_ate = float(weights @ direct.coef().reindex(rel_vars).to_numpy())
    expected_ate_se = float(np.sqrt(weights @ direct_vcov @ weights))
    ate = fit.ate(post_vars, name="ATE_g0_g3")
    np.testing.assert_allclose(ate.loc["ATE_g0_g3", "Estimate"], expected_ate)
    np.testing.assert_allclose(ate.loc["ATE_g0_g3", "Std. Error"], expected_ate_se)


def test_twfe_iid_vcov_can_use_full_fixed_effect_correction() -> None:
    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        _single_cohort_twfe_data(),
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov="iid",
        fixef_vcov_correction="full",
    )

    expected = np.array(
        [
            [0.016144349477682833, 0.00403608736942071],
            [0.00403608736942071, 0.016144349477682833],
        ]
    )
    np.testing.assert_allclose(fit.vcov().to_numpy(), expected, atol=1e-12)
    assert fit.df_t == 12.0
    assert fit.stage2_diagnostics_["first_stage_vcov"] == {
        "correction": "full",
        "scale": 14.0 / 13.0,
        "reason": "multiway_fixef_dof",
    }


def test_twfe_vcov_can_keep_pyfixest_native_correction_explicitly() -> None:
    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        _single_cohort_twfe_data(),
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov="iid",
        fixef_vcov_correction="pyfixest",
    )

    expected = np.array(
        [
            [0.014991181657848327, 0.00374779541446208],
            [0.00374779541446208, 0.014991181657848327],
        ]
    )
    np.testing.assert_allclose(fit.vcov().to_numpy(), expected, atol=1e-12)
    assert fit.df_t == 14.0
    assert fit.stage2_diagnostics_["first_stage_vcov"] == {
        "correction": "pyfixest",
        "scale": 1.0,
        "reason": "pyfixest_native",
    }


def test_full_vcov_correction_does_not_touch_one_way_fixed_effects() -> None:
    data = _single_cohort_twfe_data()
    full = eventreg(
        "y ~ rel0 + rel1 | unit",
        data,
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov="iid",
        fixef_vcov_correction="full",
    )
    native = eventreg(
        "y ~ rel0 + rel1 | unit",
        data,
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov="iid",
        fixef_vcov_correction="pyfixest",
    )

    np.testing.assert_allclose(full.vcov().to_numpy(), native.vcov().to_numpy())
    assert full.df_t == native.df_t
    assert full.stage2_diagnostics_["first_stage_vcov"] == {
        "correction": "full",
        "scale": 1.0,
        "reason": "pyfixest_native",
    }


def test_twfe_hetero_and_cluster_vcov_match_full_adjusted_fixtures() -> None:
    data = _single_cohort_twfe_data()
    hetero = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        data,
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov="hetero",
        fixef_vcov_correction="full",
    )
    cluster = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        data,
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov={"CRV1": "unit"},
        fixef_vcov_correction="full",
    )

    np.testing.assert_allclose(
        hetero.vcov().to_numpy(),
        [
            [0.009430727023319634, 0.005602379444972046],
            [0.005602379444972046, 0.011300385142977768],
        ],
        atol=1e-12,
    )
    np.testing.assert_allclose(
        cluster.vcov().to_numpy(),
        [
            [0.00798838053740014, 0.006354393609295599],
            [0.006354393609295599, 0.01084785766158319],
        ],
        atol=1e-12,
    )
    assert hetero.df_t == 12.0
    assert cluster.df_t == 3.0


def test_dropped_interaction_vcov_entries_do_not_poison_aggregation() -> None:
    prefix = "__esi_"
    nrel_names = ["__esi_n_rel0"]
    cohort_list = [2, 3]
    names = [
        eventreg_module._interaction_name(nrel_names[0], cohort, prefix)
        for cohort in cohort_list
    ]
    coef_series = pd.Series([0.0, 1.0], index=names)
    first_vcov = pd.DataFrame(
        [[np.nan, np.nan], [np.nan, 0.25]], index=names, columns=names
    )

    delta = eventreg_module._interaction_coef_matrix(
        coef_series, nrel_names, cohort_list, prefix
    )
    interaction_vcov = eventreg_module._interaction_vcov(first_vcov, names, names)

    np.testing.assert_allclose(delta, [[0.0], [1.0]])
    np.testing.assert_allclose(interaction_vcov, [[0.0, 0.0], [0.0, 0.25]])


def test_matches_pyfixest_saturated_period_aggregation_when_fe_shape_matches() -> None:
    df = _fixed_effect_data()
    ours = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        df,
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov={"CRV1": "unit"},
        share_vcov="none",
    )
    pyfixest_data = df.copy()
    pyfixest_data["g"] = pyfixest_data["cohort"].where(~pyfixest_data["control"], 0)

    saturated = pf.event_study(
        pyfixest_data,
        yname="y",
        idname="unit",
        tname="time",
        gname="g",
        estimator="saturated",
        cluster="unit",
    )
    ours_agg = ours.aggregate().loc[[0.0, 1.0], ["Estimate", "Std. Error"]]
    saturated_agg = saturated.aggregate().loc[[0.0, 1.0], ["Estimate", "Std. Error"]]

    np.testing.assert_allclose(
        ours_agg["Estimate"].to_numpy(dtype=float),
        saturated_agg["Estimate"].to_numpy(dtype=float),
        atol=1e-12,
    )
    np.testing.assert_allclose(
        ours_agg["Std. Error"].to_numpy(dtype=float),
        saturated_agg["Std. Error"].to_numpy(dtype=float),
        atol=1e-12,
    )
    assert ours_agg.index.name == "period"


def test_iplot_aggregate_uses_pyfixest_style_period_index(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import matplotlib.pyplot as plt

    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        _fixed_effect_data(),
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        vcov={"CRV1": "unit"},
    )
    monkeypatch.setattr(plt, "show", lambda: None)

    ax = fit.iplot_aggregate()
    assert ax.get_xlabel() == "Time"


def test_nlswork_example_matches_stata_and_julia_reference_coefficients() -> None:
    df, event_vars = _nlswork_reference_data()

    fit = eventreg(
        f"ln_wage ~ {' + '.join(event_vars)} | idcode + year",
        df,
        cohort="first_union",
        control_cohort="never_union",
        vcov={"CRV1": "idcode"},
        demeaner_backend="numba",
    )

    expected = pd.Series(
        NLSWORK_STATA_JULIA_COEFFICIENTS,
        name="Estimate",
    ).rename_axis("Coefficient")
    pd.testing.assert_series_equal(
        fit.coef().reindex(expected.index),
        expected,
        check_exact=False,
        atol=1e-5,
        rtol=1e-5,
    )
    expected_se = pd.Series(
        NLSWORK_STATA_JULIA_STD_ERRORS,
        name="Std. Error",
    ).rename_axis("Coefficient")
    pd.testing.assert_series_equal(
        fit.se().reindex(expected_se.index),
        expected_se,
        check_exact=False,
        atol=1e-5,
        rtol=1e-5,
    )
    assert fit.nobs == 19813


def test_single_cohort_has_unit_share_and_zero_share_uncertainty() -> None:
    df = _balanced_iw_data()
    df = df[(df["cohort"] != 3) & (df["region"] != "west")]

    fit = eventreg(
        "y ~ rel0 + rel1 + 0",
        df,
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
    )

    np.testing.assert_allclose(fit.iw_weights_.to_numpy(), [[1.0, 1.0]])
    assert fit.stage2_models_ is None
    assert fit.stage2_diagnostics_["single_cohort"] is True


def test_split_and_fsplit_return_multi_results() -> None:
    split_fit = eventreg(
        "y ~ rel0 + rel1 + 0",
        _balanced_iw_data(),
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        split="region",
    )
    fsplit_fit = eventreg(
        "y ~ rel0 + rel1 + 0",
        _balanced_iw_data(),
        ["rel0", "rel1"],
        cohort="cohort",
        control_cohort="control",
        fsplit="region",
    )

    assert isinstance(split_fit, EventStudyInteractMulti)
    assert isinstance(fsplit_fit, EventStudyInteractMulti)
    assert "all" in fsplit_fit.keys()
    assert "all" not in split_fit.keys()


def test_missing_columns_raise_before_pyfixest() -> None:
    with pytest.raises(KeyError, match="missing"):
        eventreg(
            "y ~ missing + 0",
            _balanced_iw_data(),
            cohort="cohort",
            control_cohort="control",
        )


def test_pyfixest_version_guard(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(eventreg_module, "package_version", lambda _: "0.40.1")

    with pytest.raises(ImportError, match="pyfixest>=0.50.1"):
        eventreg(
            "y ~ rel0 + rel1 + 0",
            _balanced_iw_data(),
            ["rel0", "rel1"],
            cohort="cohort",
            control_cohort="control",
        )
