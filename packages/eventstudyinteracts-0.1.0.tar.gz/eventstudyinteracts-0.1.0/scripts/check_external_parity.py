"""Optional parity checks against external event-study implementations.

The script always checks a deterministic Python fixture. It also compares
against R fixest's Sun-Abraham implementation when Rscript and fixest are
available. It compares against Stata's eventstudyinteract when a batch-capable
Stata command is available. Stata's eventstudyinteract ``V_iw`` is reported as
an expected difference for the explicit saturated Sun-Abraham/full absorbed-FE
correction mode. The default Python path is also checked against direct
pyfixest TWFE in the single-cohort edge case. The script compares against Julia
EventStudyInteracts.jl when Julia and a local project path are available.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from eventstudyinteracts import eventreg


def build_fixture() -> pd.DataFrame:
    rows = []
    for unit, cohort in enumerate([2, 2, 3, 3, 999, 999]):
        control = cohort == 999
        for time in range(1, 6):
            rel = -99 if control else time - cohort
            effect = 1.0 if rel == 0 else 2.0 if rel == 1 else 0.0
            rows.append(
                {
                    "unit": unit,
                    "time": time,
                    "cohort": cohort,
                    "control": control,
                    "rel0": float(rel == 0),
                    "rel1": float(rel == 1),
                    "y": unit * 0.2 + time * 0.3 + effect,
                }
            )
    return pd.DataFrame(rows)


def build_single_cohort_fixture() -> pd.DataFrame:
    rows = []
    for unit, cohort in enumerate([2, 2, 999, 999, 999]):
        control = cohort == 999
        for time in range(1, 6):
            rel = -99 if control else time - cohort
            effect = 1.0 if rel == 0 else 2.0 if rel == 1 else 0.0
            noise = ((unit + 1) * (time + 2) % 5) * 0.1
            rows.append(
                {
                    "unit": unit,
                    "time": time,
                    "cohort": cohort,
                    "control": control,
                    "rel0": float(rel == 0),
                    "rel1": float(rel == 1),
                    "y": unit * 0.2 + time * 0.3 + effect + noise,
                }
            )
    return pd.DataFrame(rows)


def build_multife_control_fixture() -> pd.DataFrame:
    rows = []
    cohort_by_unit = {
        0: 2,
        1: 2,
        2: 3,
        3: 3,
        4: 4,
        5: 4,
        6: 999,
        7: 999,
        8: 999,
    }
    effects = {
        2: {0: 1.0, 1: 2.0},
        3: {0: 3.0, 1: 4.0},
        4: {0: 5.0, 1: 6.0},
    }
    for unit, cohort in cohort_by_unit.items():
        control = cohort == 999
        for time in range(1, 6):
            market = (unit + 2 * time) % 4
            x = ((3 * unit + 5 * time) % 13) / 10
            rel = -99 if control else time - cohort
            treatment_effect = effects.get(cohort, {}).get(rel, 0.0)
            rows.append(
                {
                    "unit": unit,
                    "time": time,
                    "market": market,
                    "cohort": cohort,
                    "control": control,
                    "rel0": float(rel == 0),
                    "rel1": float(rel == 1),
                    "x": x,
                    "y": (
                        unit * 0.2
                        + time * 0.3
                        + market * 0.4
                        + 0.7 * x
                        + treatment_effect
                    ),
                }
            )
    return pd.DataFrame(rows)


def build_nlswork_reference_sample() -> tuple[pd.DataFrame, list[str]]:
    path = Path(__file__).resolve().parents[1] / "dataset" / "nlswork.dta"
    df = pd.read_stata(path)
    df["union_year"] = np.where(df["union"].fillna(0).eq(1), df["year"], np.nan)
    df["first_union"] = df.groupby("idcode")["union_year"].transform("min")
    df = df.drop(columns=["union_year"])
    df["ry"] = df["year"] - df["first_union"]
    df["never_union"] = df["first_union"].isna()

    ids_with_ref = df.loc[df["ry"].eq(-1), "idcode"].unique()
    df = df.loc[df["never_union"] | df["idcode"].isin(ids_with_ref)].copy()

    relmin = int(abs(np.nanmin(df["ry"])))
    relmax = int(abs(np.nanmax(df["ry"])))
    event_vars = []
    rel_columns = {}
    for k in range(relmin, 1, -1):
        name = f"g_{k}"
        rel_columns[name] = df["ry"].eq(-k).fillna(False).astype(int)
        event_vars.append(name)
    for k in range(0, relmax + 1):
        name = f"g{k}"
        rel_columns[name] = df["ry"].eq(k).fillna(False).astype(int)
        event_vars.append(name)

    rel_frame = pd.DataFrame(rel_columns, index=df.index)
    df = pd.concat(
        [df.drop(columns=list(rel_columns), errors="ignore"), rel_frame],
        axis=1,
    )
    return df, event_vars


def check_python_fixture(data: pd.DataFrame) -> pd.Series:
    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time",
        data,
        cohort="cohort",
        control_cohort="control",
        vcov="iid",
        demeaner_backend="numba",
    )
    expected = np.array([1.0, 2.0])
    np.testing.assert_allclose(fit.coef().to_numpy(), expected, atol=1e-9)
    print("python fixture: PASS")
    return fit.coef()


def check_python_multife_control_fixture(data: pd.DataFrame) -> pd.Series:
    fit = eventreg(
        "y ~ rel0 + rel1 | unit + time + market",
        data,
        cohort="cohort",
        control_cohort="control",
        covariates="x",
        vcov="iid",
        demeaner_backend="numba",
    )
    expected = np.array([3.0, 4.0])
    np.testing.assert_allclose(fit.coef().to_numpy(), expected, atol=1e-9)
    np.testing.assert_allclose(fit.interacted_model_.coef().loc["x"], 0.7, atol=1e-9)
    print("python multi-FE + control fixture: PASS")
    return fit.coef()


def check_python_single_cohort_vcov(
    data: pd.DataFrame,
) -> tuple[pd.Series, dict[str, pd.DataFrame]]:
    specs = {
        "simple": "iid",
        "robust": "hetero",
        "cluster_unit": {"CRV1": "unit"},
    }
    fits = {
        label: eventreg(
            "y ~ rel0 + rel1 | unit + time",
            data,
            cohort="cohort",
            control_cohort="control",
            vcov=spec,
            demeaner_backend="numba",
            fixef_vcov_correction="full",
        )
        for label, spec in specs.items()
    }
    print("python single-cohort saturated-adjusted TWFE vcov fixtures: PASS")
    return fits["simple"].coef(), {label: fit.vcov() for label, fit in fits.items()}


def check_python_single_cohort_pyfixest_vcov(data: pd.DataFrame) -> None:
    import pyfixest as pf

    specs = {
        "simple": "iid",
        "robust": "hetero",
        "cluster_unit": {"CRV1": "unit"},
        "cluster_unit_time": {"CRV1": "unit + time"},
    }
    for spec in specs.values():
        direct = pf.feols("y ~ rel0 + rel1 | unit + time", data, vcov=spec)
        fit = eventreg(
            "y ~ rel0 + rel1 | unit + time",
            data,
            cohort="cohort",
            control_cohort="control",
            vcov=spec,
            demeaner_backend="numba",
        )
        names = list(direct.coef().index)
        idx = [names.index("rel0"), names.index("rel1")]
        direct_vcov = np.asarray(direct._vcov)[np.ix_(idx, idx)]
        np.testing.assert_allclose(
            fit.coef().to_numpy(),
            direct.coef().reindex(["rel0", "rel1"]).to_numpy(),
            atol=1e-12,
        )
        np.testing.assert_allclose(fit.vcov().to_numpy(), direct_vcov, atol=1e-12)
    print("python single-cohort direct pyfixest TWFE vcov parity: PASS")


def check_pyfixest_saturated_nlswork() -> None:
    import pyfixest as pf

    data, event_vars = build_nlswork_reference_sample()
    fit = eventreg(
        f"ln_wage ~ {' + '.join(event_vars)} | idcode + year",
        data,
        cohort="first_union",
        control_cohort="never_union",
        vcov={"CRV1": "idcode"},
        demeaner_backend="numba",
        share_vcov="none",
    )
    pyfixest_data = data.copy()
    pyfixest_data["g"] = (
        pyfixest_data["first_union"]
        .where(~pyfixest_data["never_union"], 0)
        .fillna(0)
        .astype(int)
    )
    saturated = pf.event_study(
        pyfixest_data,
        yname="ln_wage",
        idname="idcode",
        tname="year",
        gname="g",
        estimator="saturated",
        cluster="idcode",
    )
    ours = fit.aggregate()[["Estimate", "Std. Error"]]
    theirs = saturated.aggregate()[["Estimate", "Std. Error"]]
    common = ours.index.intersection(theirs.index)
    if len(common) != len(ours) or len(common) != len(theirs):
        raise AssertionError(
            "eventreg and pyfixest saturated aggregates do not expose the same "
            f"periods: eventreg={list(ours.index)}, pyfixest={list(theirs.index)}"
        )
    ours_coef = ours.loc[common, "Estimate"].to_numpy(dtype=float)
    theirs_coef = theirs.loc[common, "Estimate"].to_numpy(dtype=float)
    ours_se = ours.loc[common, "Std. Error"].to_numpy(dtype=float)
    theirs_se = theirs.loc[common, "Std. Error"].to_numpy(dtype=float)
    np.testing.assert_allclose(ours_coef, theirs_coef, rtol=0.0, atol=1e-12)
    np.testing.assert_allclose(ours_se, theirs_se, rtol=0.0, atol=1e-12)
    max_coef_diff = float(np.max(np.abs(ours_coef - theirs_coef)))
    max_se_diff = float(np.max(np.abs(ours_se - theirs_se)))
    print(
        "pyfixest saturated nlswork machine-precision aggregate parity: PASS "
        f"(max coef diff {max_coef_diff:.6g}; max SE diff {max_se_diff:.6g})"
    )


def check_r_fixest(data: pd.DataFrame, python_coef: pd.Series) -> None:
    rscript = shutil.which("Rscript")
    if rscript is None:
        print("R fixest parity: SKIP (Rscript not found)")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        data_path = tmp / "fixture.csv"
        out_path = tmp / "fixest-period.csv"
        script_path = tmp / "check_fixest.R"
        data.to_csv(data_path, index=False)
        script_path.write_text(
            f"""
            if (!requireNamespace("fixest", quietly = TRUE)) {{
              quit(status = 99)
            }}
            library(fixest)
            data <- read.csv("{data_path}")
            fit <- feols(y ~ sunab(cohort, time, ref.p = -1) | unit + time, data, vcov = "iid")
            agg <- as.data.frame(aggregate(fit, agg = "period"))
            agg$term <- rownames(agg)
            write.csv(agg, "{out_path}", row.names = FALSE)
            """,
            encoding="utf-8",
        )
        result = subprocess.run(
            [rscript, str(script_path)],
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode == 99:
            print("R fixest parity: SKIP (fixest R package not installed)")
            return
        if result.returncode != 0:
            raise RuntimeError(result.stderr or result.stdout)

        r_out = pd.read_csv(out_path).set_index("term")
        r_coef = pd.Series(
            {
                "rel0": float(r_out.loc["time::0", "Estimate"]),
                "rel1": float(r_out.loc["time::1", "Estimate"]),
            }
        )
    np.testing.assert_allclose(
        python_coef.reindex(["rel0", "rel1"]).to_numpy(),
        r_coef.to_numpy(),
        atol=1e-9,
    )
    print("R fixest parity: PASS")


def check_r_fixest_vcov(
    data: pd.DataFrame, python_coef: pd.Series, python_vcov: pd.DataFrame
) -> None:
    rscript = shutil.which("Rscript")
    if rscript is None:
        print("R fixest vcov parity: SKIP (Rscript not found)")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        data_path = tmp / "single.csv"
        out_path = tmp / "fixest-vcov.csv"
        script_path = tmp / "check_fixest_vcov.R"
        data.to_csv(data_path, index=False)
        script_path.write_text(
            f"""
            if (!requireNamespace("fixest", quietly = TRUE)) {{
              quit(status = 99)
            }}
            library(fixest)
            data <- read.csv("{data_path}")
            data$g <- ifelse(data$control, NA, data$cohort)
            fit <- feols(y ~ sunab(g, time, ref.p = -1) | unit + time, data, vcov = "iid")
            agg <- as.data.frame(aggregate(fit, agg = "period"))
            agg$term <- rownames(agg)
            out <- data.frame(
              rel0 = agg[agg$term == "time::0", "Estimate"],
              rel1 = agg[agg$term == "time::1", "Estimate"],
              se0 = agg[agg$term == "time::0", "Std. Error"],
              se1 = agg[agg$term == "time::1", "Std. Error"]
            )
            write.csv(out, "{out_path}", row.names = FALSE)
            """,
            encoding="utf-8",
        )
        result = subprocess.run(
            [rscript, str(script_path)],
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode == 99:
            print("R fixest vcov parity: SKIP (fixest R package not installed)")
            return
        if result.returncode != 0:
            if "collinear with the fixed effects" in result.stderr:
                print("R fixest vcov parity: SKIP (single-cohort saturated collinear)")
                return
            raise RuntimeError(result.stderr or result.stdout)

        out = pd.read_csv(out_path).iloc[0]

    np.testing.assert_allclose(
        python_coef.reindex(["rel0", "rel1"]).to_numpy(),
        [out["rel0"], out["rel1"]],
        atol=1e-6,
    )
    np.testing.assert_allclose(
        np.sqrt(np.diag(python_vcov.to_numpy(dtype=float))),
        [out["se0"], out["se1"]],
        atol=1e-6,
    )
    print("R fixest vcov parity: PASS")


def check_stata_eventstudyinteract(data: pd.DataFrame, python_coef: pd.Series) -> None:
    stata_cmd = _stata_command()
    if stata_cmd is None:
        print("Stata eventstudyinteract parity: SKIP (Stata CLI not found)")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        data_path = tmp / "fixture.csv"
        out_path = tmp / "stata-iw.csv"
        script_path = tmp / "check_stata.do"
        stata_data = data.copy()
        stata_data["control"] = stata_data["control"].astype(int)
        stata_data.to_csv(data_path, index=False)
        script_path.write_text(
            f"""
            set more off
            import delimited using "{data_path}", clear
            capture which eventstudyinteract
            if _rc {{
              exit 99
            }}
            quietly eventstudyinteract y rel0 rel1, cohort(cohort) control_cohort(control) absorb(unit time) vce(unadjusted)
            matrix b = e(b_iw)
            clear
            set obs 1
            svmat double b, names(col)
            export delimited rel0 rel1 using "{out_path}", replace
            exit
            """,
            encoding="utf-8",
        )
        result = subprocess.run(
            [stata_cmd, "-b", "do", str(script_path)],
            check=False,
            capture_output=True,
            cwd=tmp,
            text=True,
        )
        if result.returncode == 99:
            print("Stata eventstudyinteract parity: SKIP (ado not installed)")
            return
        if result.returncode != 0:
            log_path = tmp / "check_stata.log"
            log_text = log_path.read_text(encoding="utf-8") if log_path.exists() else ""
            raise RuntimeError(log_text or result.stderr or result.stdout)

        stata_out = pd.read_csv(out_path).iloc[0]

    stata_coef = pd.Series(
        {"rel0": float(stata_out["rel0"]), "rel1": float(stata_out["rel1"])}
    )
    np.testing.assert_allclose(
        python_coef.reindex(["rel0", "rel1"]).to_numpy(),
        stata_coef.to_numpy(),
        atol=1e-6,
    )
    print("Stata eventstudyinteract parity: PASS")


def check_stata_multife_control(data: pd.DataFrame, python_coef: pd.Series) -> None:
    stata_cmd = _stata_command()
    if stata_cmd is None:
        print("Stata multi-FE + control parity: SKIP (Stata CLI not found)")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        data_path = tmp / "multife.csv"
        out_path = tmp / "stata-multife-iw.csv"
        script_path = tmp / "check_stata_multife.do"
        stata_data = data.copy()
        stata_data["control"] = stata_data["control"].astype(int)
        stata_data.to_csv(data_path, index=False)
        script_path.write_text(
            f"""
            set more off
            import delimited using "{data_path}", clear
            capture which eventstudyinteract
            if _rc {{
              exit 99
            }}
            quietly eventstudyinteract y rel0 rel1, cohort(cohort) control_cohort(control) covariates(x) absorb(unit time market) vce(unadjusted)
            matrix b = e(b_iw)
            clear
            set obs 1
            svmat double b, names(col)
            export delimited rel0 rel1 using "{out_path}", replace
            exit
            """,
            encoding="utf-8",
        )
        result = subprocess.run(
            [stata_cmd, "-b", "do", str(script_path)],
            check=False,
            capture_output=True,
            cwd=tmp,
            text=True,
        )
        if result.returncode == 99:
            print("Stata multi-FE + control parity: SKIP (ado not installed)")
            return
        if result.returncode != 0:
            log_path = tmp / "check_stata_multife.log"
            log_text = log_path.read_text(encoding="utf-8") if log_path.exists() else ""
            raise RuntimeError(log_text or result.stderr or result.stdout)

        stata_out = pd.read_csv(out_path).iloc[0]

    stata_coef = pd.Series(
        {"rel0": float(stata_out["rel0"]), "rel1": float(stata_out["rel1"])}
    )
    np.testing.assert_allclose(
        python_coef.reindex(["rel0", "rel1"]).to_numpy(),
        stata_coef.to_numpy(),
        atol=1e-6,
    )
    print("Stata multi-FE + control parity: PASS")


def check_stata_eventstudyinteract_vcov(
    data: pd.DataFrame, python_coef: pd.Series, python_vcov: pd.DataFrame
) -> None:
    stata_cmd = _stata_command()
    if stata_cmd is None:
        print("Stata eventstudyinteract vcov parity: SKIP (Stata CLI not found)")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        data_path = tmp / "single.csv"
        out_path = tmp / "stata-vcov.csv"
        script_path = tmp / "check_stata_vcov.do"
        stata_data = data.copy()
        stata_data["control"] = stata_data["control"].astype(int)
        stata_data.loc[stata_data["control"] == 1, "cohort"] = np.nan
        stata_data.to_csv(data_path, index=False)
        script_path.write_text(
            f"""
            set more off
            import delimited using "{data_path}", clear
            capture which eventstudyinteract
            if _rc {{
              exit 99
            }}
            quietly eventstudyinteract y rel0 rel1, cohort(cohort) control_cohort(control) absorb(unit time) vce(unadjusted)
            matrix b = e(b_iw)
            matrix V = e(V_iw)
            clear
            set obs 1
            gen rel0 = b[1, 1]
            gen rel1 = b[1, 2]
            gen v00 = V[1, 1]
            gen v01 = V[1, 2]
            gen v11 = V[2, 2]
            export delimited rel0 rel1 v00 v01 v11 using "{out_path}", replace
            exit
            """,
            encoding="utf-8",
        )
        result = subprocess.run(
            [stata_cmd, "-b", "do", str(script_path)],
            check=False,
            capture_output=True,
            cwd=tmp,
            text=True,
        )
        if result.returncode == 99:
            print("Stata eventstudyinteract vcov parity: SKIP (ado not installed)")
            return
        if result.returncode != 0:
            log_path = tmp / "check_stata_vcov.log"
            log_text = log_path.read_text(encoding="utf-8") if log_path.exists() else ""
            raise RuntimeError(log_text or result.stderr or result.stdout)
        out = pd.read_csv(out_path).iloc[0]

    np.testing.assert_allclose(
        python_coef.reindex(["rel0", "rel1"]).to_numpy(),
        [out["rel0"], out["rel1"]],
        atol=1e-6,
    )
    expected_vcov = np.array([[out["v00"], out["v01"]], [out["v01"], out["v11"]]])
    max_diff = np.max(np.abs(python_vcov.to_numpy(dtype=float) - expected_vcov))
    if max_diff <= 1e-10:
        raise AssertionError(
            "Stata eventstudyinteract V_iw unexpectedly matched the "
            "saturated-adjusted covariance; this fixture should catch the "
            "known Stata standard-error gap."
        )
    print(
        "Stata eventstudyinteract vcov comparison: EXPECTED_DIFF "
        f"(Stata eventstudyinteract V_iw differs by max {max_diff:.6g})"
    )


def check_julia_eventstudyinteracts(python_coef: pd.Series) -> None:
    julia = shutil.which("julia")
    if julia is None:
        print("Julia EventStudyInteracts.jl parity: SKIP (julia not found)")
        return

    project = _julia_project_path()
    if not project.exists():
        print("Julia EventStudyInteracts.jl parity: SKIP (project path not found)")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        out_path = tmp / "julia-iw.csv"
        script_path = tmp / "check_julia.jl"
        script_path.write_text(
            f"""
            using DataFrames
            using EventStudyInteracts
            using FixedEffectModels
            using StatsModels
            using Vcov

            df = DataFrame(unit=Int[], time=Int[], cohort=Union{{Missing,Int}}[], control=Bool[], rel0=Float64[], rel1=Float64[], y=Float64[])
            for (unit, cohort_val) in enumerate([2, 2, 3, 3, missing, missing])
                control = ismissing(cohort_val)
                for time in 1:5
                    rel = control ? -99 : time - cohort_val
                    effect = rel == 0 ? 1.0 : rel == 1 ? 2.0 : 0.0
                    push!(df, (unit, time, cohort_val, control, Float64(rel == 0), Float64(rel == 1), (unit - 1) * 0.2 + time * 0.3 + effect))
                end
            end

            model = eventreg(df, @formula(y ~ fe(unit) + fe(time)), [:rel0, :rel1], :control, :cohort, Vcov.simple(); progress_bar=false)
            open("{out_path}", "w") do io
                println(io, "rel0,rel1")
                println(io, string(coef(model)[1], ",", coef(model)[2]))
            end
            """,
            encoding="utf-8",
        )
        result = subprocess.run(
            [julia, "--startup-file=no", str(script_path)],
            check=False,
            capture_output=True,
            env={**os.environ, "JULIA_PROJECT": str(project)},
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr or result.stdout)

        julia_out = pd.read_csv(out_path).iloc[0]

    julia_coef = pd.Series(
        {"rel0": float(julia_out["rel0"]), "rel1": float(julia_out["rel1"])}
    )
    np.testing.assert_allclose(
        python_coef.reindex(["rel0", "rel1"]).to_numpy(),
        julia_coef.to_numpy(),
        atol=1e-9,
    )
    print("Julia EventStudyInteracts.jl parity: PASS")


def check_julia_eventstudyinteracts_vcov(
    python_coef: pd.Series, python_vcovs: dict[str, pd.DataFrame]
) -> None:
    julia = shutil.which("julia")
    if julia is None:
        print("Julia EventStudyInteracts.jl vcov parity: SKIP (julia not found)")
        return

    project = _julia_project_path()
    if not project.exists():
        print("Julia EventStudyInteracts.jl vcov parity: SKIP (project path not found)")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        out_path = tmp / "julia-vcov.csv"
        script_path = tmp / "check_julia_vcov.jl"
        script_path.write_text(
            f"""
            using DataFrames
            using EventStudyInteracts
            using FixedEffectModels
            using LinearAlgebra
            using StatsAPI
            using StatsModels
            using Vcov

            df = DataFrame(unit=Int[], time=Int[], cohort=Union{{Missing,Int}}[], control=Bool[], rel0=Float64[], rel1=Float64[], y=Float64[])
            for (unit, cohort_val) in enumerate([2, 2, missing, missing, missing])
                control = ismissing(cohort_val)
                for time in 1:5
                    rel = control ? -99 : time - cohort_val
                    effect = rel == 0 ? 1.0 : rel == 1 ? 2.0 : 0.0
                    noise = mod(unit * (time + 2), 5) * 0.1
                    push!(df, (unit, time, cohort_val, control, Float64(rel == 0), Float64(rel == 1), (unit - 1) * 0.2 + time * 0.3 + effect + noise))
                end
            end

            function write_model(io, label, vc)
                model = eventreg(df, @formula(y ~ fe(unit) + fe(time)), [:rel0, :rel1], :control, :cohort, vc; progress_bar=false)
                V = vcov(model)
                println(io, string(label, ",", coef(model)[1], ",", coef(model)[2], ",", V[1, 1], ",", V[1, 2], ",", V[2, 2]))
            end

            open("{out_path}", "w") do io
                println(io, "label,rel0,rel1,v00,v01,v11")
                write_model(io, "simple", Vcov.simple())
                write_model(io, "robust", Vcov.robust())
                write_model(io, "cluster_unit", Vcov.cluster(:unit))
            end
            """,
            encoding="utf-8",
        )
        result = subprocess.run(
            [julia, "--startup-file=no", str(script_path)],
            check=False,
            capture_output=True,
            env={**os.environ, "JULIA_PROJECT": str(project)},
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr or result.stdout)

        out = pd.read_csv(out_path).set_index("label")

    for label, python_vcov in python_vcovs.items():
        row = out.loc[label]
        np.testing.assert_allclose(
            python_coef.reindex(["rel0", "rel1"]).to_numpy(),
            [row["rel0"], row["rel1"]],
            atol=1e-9,
        )
        expected_vcov = np.array([[row["v00"], row["v01"]], [row["v01"], row["v11"]]])
        np.testing.assert_allclose(
            python_vcov.to_numpy(dtype=float), expected_vcov, atol=1e-9
        )
    print("Julia EventStudyInteracts.jl TWFE vcov parity: PASS")


def check_julia_multife_control(
    python_coef: pd.Series,
) -> None:
    julia = shutil.which("julia")
    if julia is None:
        print("Julia multi-FE + control parity: SKIP (julia not found)")
        return

    project = _julia_project_path()
    if not project.exists():
        print("Julia multi-FE + control parity: SKIP (project path not found)")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        out_path = tmp / "julia-multife.csv"
        script_path = tmp / "check_julia_multife.jl"
        script_path.write_text(
            f"""
            using DataFrames
            using EventStudyInteracts
            using FixedEffectModels
            using StatsAPI
            using StatsModels
            using Vcov

            df = DataFrame(unit=Int[], time=Int[], market=Int[], cohort=Union{{Missing,Int}}[], control=Bool[], rel0=Float64[], rel1=Float64[], x=Float64[], y=Float64[])
            cohort_by_unit = Dict(0 => 2, 1 => 2, 2 => 3, 3 => 3, 4 => 4, 5 => 4, 6 => missing, 7 => missing, 8 => missing)
            effects = Dict(2 => Dict(0 => 1.0, 1 => 2.0), 3 => Dict(0 => 3.0, 1 => 4.0), 4 => Dict(0 => 5.0, 1 => 6.0))
            for unit in 0:8
                cohort_val = cohort_by_unit[unit]
                control = ismissing(cohort_val)
                for time in 1:5
                    market = mod(unit + 2 * time, 4)
                    x = mod(3 * unit + 5 * time, 13) / 10
                    rel = control ? -99 : time - cohort_val
                    treatment_effect = control ? 0.0 : get(effects[cohort_val], rel, 0.0)
                    y = unit * 0.2 + time * 0.3 + market * 0.4 + 0.7 * x + treatment_effect
                    push!(df, (unit, time, market, cohort_val, control, Float64(rel == 0), Float64(rel == 1), x, y))
                end
            end

            model = eventreg(df, @formula(y ~ x + fe(unit) + fe(time) + fe(market)), [:rel0, :rel1], :control, :cohort, Vcov.simple(); progress_bar=false)
            open("{out_path}", "w") do io
                println(io, "rel0,rel1")
                println(io, string(coef(model)[1], ",", coef(model)[2]))
            end
            """,
            encoding="utf-8",
        )
        result = subprocess.run(
            [julia, "--startup-file=no", str(script_path)],
            check=False,
            capture_output=True,
            env={**os.environ, "JULIA_PROJECT": str(project)},
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr or result.stdout)

        julia_out = pd.read_csv(out_path).iloc[0]

    julia_coef = pd.Series(
        {"rel0": float(julia_out["rel0"]), "rel1": float(julia_out["rel1"])}
    )
    np.testing.assert_allclose(
        python_coef.reindex(["rel0", "rel1"]).to_numpy(),
        julia_coef.to_numpy(),
        atol=1e-9,
    )
    print("Julia multi-FE + control parity: PASS")


def _julia_project_path() -> Path:
    if "EVENTSTUDYINTERACTS_JL_PATH" in os.environ:
        return Path(os.environ["EVENTSTUDYINTERACTS_JL_PATH"])
    local_clone = (
        Path(__file__).resolve().parents[1] / ".tmp" / "EventStudyInteracts.jl"
    )
    if local_clone.exists():
        return local_clone
    return Path("/tmp/EventStudyInteracts.jl")


def _stata_command() -> str | None:
    stata_candidates = [
        "stata-mp",
        "stata-se",
        "stata",
        "/Applications/Stata/StataMP.app/Contents/MacOS/stata-mp",
    ]
    return next((command for command in stata_candidates if _is_command(command)), None)


def _is_command(command: str) -> bool:
    return shutil.which(command) is not None or Path(command).exists()


def main() -> None:
    check_pyfixest_saturated_nlswork()

    data = build_fixture()
    python_coef = check_python_fixture(data)
    check_r_fixest(data, python_coef)
    check_stata_eventstudyinteract(data, python_coef)
    check_julia_eventstudyinteracts(python_coef)

    multife_data = build_multife_control_fixture()
    multife_coef = check_python_multife_control_fixture(multife_data)
    check_stata_multife_control(multife_data, multife_coef)
    check_julia_multife_control(multife_coef)

    single_data = build_single_cohort_fixture()
    check_python_single_cohort_pyfixest_vcov(single_data)
    single_coef, single_vcovs = check_python_single_cohort_vcov(single_data)
    check_r_fixest_vcov(single_data, single_coef, single_vcovs["simple"])
    check_stata_eventstudyinteract_vcov(
        single_data, single_coef, single_vcovs["simple"]
    )
    check_julia_eventstudyinteracts_vcov(single_coef, single_vcovs)


if __name__ == "__main__":
    main()
