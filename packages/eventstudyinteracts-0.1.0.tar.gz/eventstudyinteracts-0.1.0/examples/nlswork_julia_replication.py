"""Run the nlswork event-study example in Python.

For cross-package comparisons, the script keeps treated workers observed in the
omitted period, builds the full observed relative-time window, and compares the
Python result to saved Stata/Julia values from the same sample.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

import eventstudyinteracts as esi

DATA_PATH = Path(__file__).resolve().parents[1] / "dataset" / "nlswork.dta"
NLSWORK_STATA_JULIA_COEFFICIENTS = {
    "g_20": 0.111521,
    "g_19": 0.118273,
    "g_18": -0.065599,
    "g_17": 0.045408,
    "g_16": -0.023468,
    "g_15": -0.208510,
    "g_14": -0.239402,
    "g_3": -0.024659,
    "g_2": 0.001476,
    "g0": 0.131608,
    "g1": 0.177707,
    "g2": 0.132955,
    "g3": 0.149590,
    "g18": -0.120038,
}


def load_nlswork() -> pd.DataFrame:
    df = pd.read_stata(DATA_PATH)

    df["union_year"] = np.where(df["union"].fillna(0).eq(1), df["year"], np.nan)
    df["first_union"] = df.groupby("idcode")["union_year"].transform("min")
    df = df.drop(columns=["union_year"])

    df["ry"] = df["year"] - df["first_union"]
    df["never_union"] = df["first_union"].isna()

    return df


def add_relative_time_columns(
    df: pd.DataFrame,
) -> tuple[pd.DataFrame, list[str], int, int]:
    relmin = int(abs(np.nanmin(df["ry"])))
    relmax = int(abs(np.nanmax(df["ry"])))

    rel_columns = {}
    event_vars = []
    for k in range(relmin, 1, -1):
        rel_columns[f"g_{k}"] = df["ry"].eq(-k).fillna(False).astype(int)
        event_vars.append(f"g_{k}")
    for k in range(0, relmax + 1):
        rel_columns[f"g{k}"] = df["ry"].eq(k).fillna(False).astype(int)
        event_vars.append(f"g{k}")
    rel_frame = pd.DataFrame(rel_columns, index=df.index)
    df = pd.concat(
        [df.drop(columns=list(rel_columns), errors="ignore"), rel_frame], axis=1
    )
    return df, event_vars, relmin, relmax


def keep_ids_with_reference_period(
    df: pd.DataFrame,
    *,
    idname: str = "idcode",
    relname: str = "ry",
    control_cohort: str = "never_union",
    reference_period: int = -1,
) -> pd.DataFrame:
    """Keep never-treated units and treated ids observed in the omitted period.

    Package comparisons should use the same omitted-period support. Otherwise
    saturated implementations can have different cohort-by-period support and
    different collinearity drops.
    """
    reference_ids = df.loc[df[relname].eq(reference_period), idname].unique()
    keep = df[control_cohort].fillna(False).astype(bool) | df[idname].isin(
        reference_ids
    )
    return df.loc[keep].copy()


def add_binned_relative_columns(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    event_vars = ["g_l4"]
    event_vars.extend([f"g_{k}" for k in range(3, 1, -1)])
    event_vars.extend([f"g{k}" for k in range(0, 19)])
    rel_frame = pd.DataFrame(
        {"g_l4": df["ry"].le(-4).fillna(False).astype(int)}, index=df.index
    )
    return pd.concat(
        [df.drop(columns=["g_l4"], errors="ignore"), rel_frame], axis=1
    ), event_vars


def fit_never_union_example(df: pd.DataFrame, event_vars: list[str]):
    return esi.eventreg(
        f"ln_wage ~ {' + '.join(event_vars)} | idcode + year",
        data=df,
        cohort="first_union",
        control_cohort="never_union",
        vcov={"CRV1": "idcode"},
        demeaner_backend="numba",
        collin_tol=1e-6,
    )


def fit_industry_year_fixed_effect_example(df: pd.DataFrame, event_vars: list[str]):
    short_event_vars = [*event_vars[:5], "g0", "g1"]
    return esi.eventreg(
        f"ln_wage ~ {' + '.join(short_event_vars)} | idcode + year + ind_code^year",
        data=df,
        cohort="first_union",
        control_cohort="never_union",
        covariates="south + tenure + age",
        vcov={"CRV1": "idcode"},
        demeaner_backend="numba",
        collin_tol=1e-6,
    )


def fit_binned_example(df: pd.DataFrame):
    df, event_vars = add_binned_relative_columns(df)

    return esi.eventreg(
        f"ln_wage ~ {' + '.join(event_vars)} | idcode + year",
        data=df,
        cohort="first_union",
        control_cohort="never_union",
        covariates="south",
        vcov={"CRV1": "idcode"},
        collin_tol=1e-6,
    )


def fit_last_union_example(df: pd.DataFrame):
    df["last_union"] = df["first_union"].eq(88).fillna(False)
    sample = df.loc[df["first_union"].notna() & df["year"].lt(88)].copy()
    sample, event_vars = add_binned_relative_columns(sample)

    return esi.eventreg(
        f"ln_wage ~ {' + '.join(event_vars)} | idcode + year",
        data=sample,
        cohort="first_union",
        control_cohort="last_union",
        covariates="south",
        vcov={"CRV1": "idcode"},
        collin_tol=1e-6,
    )


def fit_collgrad_heterogeneity_example(df: pd.DataFrame):
    event_vars = []
    rel_columns = {}
    for group in [0, 1]:
        name = f"g_l4_collgrad{group}"
        rel_columns[name] = (
            df["ry"].le(-4).fillna(False) & df["collgrad"].eq(group)
        ).astype(int)
        event_vars.append(name)

        for k in range(3, 1, -1):
            name = f"g_{k}_collgrad{group}"
            rel_columns[name] = (
                df["ry"].eq(-k).fillna(False) & df["collgrad"].eq(group)
            ).astype(int)
            event_vars.append(name)

        for k in range(0, 19):
            name = f"g{k}_collgrad{group}"
            rel_columns[name] = (
                df["ry"].eq(k).fillna(False) & df["collgrad"].eq(group)
            ).astype(int)
            event_vars.append(name)

    rel_frame = pd.DataFrame(rel_columns, index=df.index)
    df = pd.concat([df.drop(columns=event_vars, errors="ignore"), rel_frame], axis=1)
    return esi.eventreg(
        f"ln_wage ~ {' + '.join(event_vars)} | idcode + year",
        data=df,
        cohort="first_union",
        control_cohort="never_union",
        covariates="south",
        vcov={"CRV1": "idcode"},
        collin_tol=1e-6,
    )


def main() -> None:
    df = load_nlswork()
    df = keep_ids_with_reference_period(df)
    df, event_vars, _relmin, _relmax = add_relative_time_columns(df)

    m1 = fit_never_union_example(df, event_vars)
    print("\n=== Never-union control cohort ===")
    print(
        m1.tidy().loc[
            ["g_20", "g_19", "g_18", "g_17", "g_16", "g_15", "g_14", "g0", "g1"]
        ]
    )
    reference = pd.Series(NLSWORK_STATA_JULIA_COEFFICIENTS, name="external_reference")
    comparison = pd.concat(
        [m1.coef().reindex(reference.index), reference],
        axis=1,
    )
    comparison["Abs. Diff"] = (
        comparison["Estimate"] - comparison["external_reference"]
    ).abs()
    print("\n=== Cross-package nlswork coefficient check ===")
    print(comparison)
    print(f"Max abs diff: {comparison['Abs. Diff'].max():.3g}")

    post_periods = [f"g{k}" for k in range(0, 19)]
    print("\n=== ATE over g0:g18 ===")
    print(m1.ate(post_periods, name="ATE_g0_g18"))

    m_fe = fit_industry_year_fixed_effect_example(df, event_vars)
    print("\n=== Multiple FE with industry-by-year FE ===")
    print(m_fe.tidy().head())

    m2 = fit_binned_example(df)
    print("\n=== Binned leads ===")
    print(m2.tidy().head())

    m3 = fit_last_union_example(df)
    print("\n=== Last-treated control cohort ===")
    print(m3.tidy().head())

    m4 = fit_collgrad_heterogeneity_example(df)
    print("\n=== Heterogeneity: college graduate vs non-college graduate ===")
    print(
        m4.lincom(
            {"g1_collgrad1": 1.0, "g1_collgrad0": -1.0},
            name="collgrad_diff_g1",
        )
    )
    print(m4.ate([f"g{k}_collgrad1" for k in range(0, 5)], name="ATE_collgrad1_g0_g4"))
    print(m4.ate([f"g{k}_collgrad0" for k in range(0, 5)], name="ATE_collgrad0_g0_g4"))


if __name__ == "__main__":
    main()
