#!/usr/bin/env bash
# One-click installation script for glm-cli
# Supports macOS and Linux with automatic Python environment detection

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="glm-cli"
PYPI_NAME="glm-cli"
REPO_URL="https://github.com/user/glm-cli"
MIN_PYTHON_VERSION="3.10"

# Helper functions
print_header() {
    echo -e "${BOLD}${BLUE}═══════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}${BLUE}║  🎨 GLM RichText - CLI Installer              ║${NC}"
    echo -e "${BOLD}${BLUE}═══════════════════════════════════════════════════${NC}"
    echo ""
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

# Detect OS and architecture
detect_system() {
    OS="$(uname -s)"
    ARCH="$(uname -m)"

    case "$OS" in
        Linux*)
            OS="linux"
            ;;
        Darwin*)
            OS="macos"
            ;;
        *)
            print_error "Unsupported operating system: $OS"
            exit 1
            ;;
    esac

    case "$ARCH" in
        x86_64|amd64)
            ARCH="x64"
            ;;
        aarch64|arm64)
            ARCH="arm64"
            ;;
        *)
            print_warning "Unknown architecture: $ARCH, proceeding anyway..."
            ;;
    esac

    print_info "Detected system: $OS $ARCH"
}

# Check Python version
check_python() {
    print_info "Checking Python version..."

    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is not installed"
        print_info "Please install Python 3.10 or higher from https://www.python.org/"
        exit 1
    fi

    PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
    PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
    PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)

    if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 10 ]); then
        print_error "Python $MIN_PYTHON_VERSION or higher is required (found $PYTHON_VERSION)"
        exit 1
    fi

    print_success "Python $PYTHON_VERSION detected"
}

# Try pipx first (recommended for CLI tools), fallback to pip
install_with_pipx_or_pip() {
    print_info "Installing $PROJECT_NAME..."

    # Try pipx first
    if command -v pipx &> /dev/null; then
        print_info "Using pipx (recommended for CLI tools)..."
        if pipx install "$PYPI_NAME"; then
            print_success "Installed with pipx!"
            return 0
        else
            print_warning "pipx installation failed, trying pip..."
        fi
    fi

    # Fallback to pip with user flag
    print_info "Using pip with user installation..."
    if python3 -m pip install --user --upgrade "$PYPI_NAME" 2>/dev/null; then
        print_success "Installed with pip!"
        return 0
    fi

    # If pip fails, try from git
    print_warning "PyPI installation failed, trying from Git repository..."
    if python3 -m pip install --user --upgrade "git+$REPO_URL.git@main#egg=$PYPI_NAME" 2>/dev/null; then
        print_success "Installed from Git repository!"
        return 0
    fi

    print_error "All installation methods failed"
    print_info "Please try manual installation:"
    print_info "  git clone $REPO_URL"
    print_info "  cd $PROJECT_NAME"
    print_info "  pip install -e ."
    exit 1
}

# Verify installation
verify_installation() {
    print_info "Verifying installation..."

    # Check if glm-cli command is available
    if command -v glm-cli &> /dev/null; then
        print_success "glm-cli command is available!"
        glm-cli version
        return 0
    fi

    # Check if installed but not in PATH
    if python3 -c "import $PROJECT_NAME" 2>/dev/null; then
        print_warning "Package is installed but glm-cli command not found in PATH"
        echo ""
        print_info "User base binary location:"
        python3 -m site --user-base | sed 's|$|/bin|'

        echo ""
        print_info "To fix, add the following to your shell profile (~/.bashrc, ~/.zshrc, etc.):"
        python3 -m site --user-base | sed 's|.*|export PATH="&/bin:$PATH"|'

        echo ""
        print_info "Then run: source ~/.bashrc (or ~/.zshrc)"
        return 1
    fi

    print_error "Installation verification failed"
    return 1
}

# Main installation flow
main() {
    print_header

    detect_system
    check_python

    echo ""

    # Installation
    install_with_pipx_or_pip

    echo ""
    echo -e "${BOLD}${BLUE}─────────────────────────────────────────────────${NC}"
    echo ""

    # Verification
    verify_installation

    echo ""
    if [ $? -eq 0 ]; then
        print_success "Installation completed successfully!"
        echo ""
        print_info "Try running:"
        echo "  ${BOLD}glm-cli${NC}          - Run demo"
        echo "  ${BOLD}glm-cli --help${NC}   - Show all commands"
        echo "  ${BOLD}glm-cli demo --full${NC} - Run full demo"
    else
        print_warning "Installation completed but PATH configuration needed"
        print_info "Restart your terminal or run 'source ~/.bashrc' (or ~/.zshrc)"
    fi

    echo ""
}

# Run main
main "$@"
