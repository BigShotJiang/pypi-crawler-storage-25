# GLM RichText - 快速入门指南

一个优雅美观的命令行文本渲染工具包，灵感来自 kimi-cli。

## 安装

```bash
cd /Users/shiyupeng/open_source/glm-cli
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

## 快速开始

### 1. 基础使用

```python
from glm_cli.richtext import console

# 打印简单文本
console.print("[bold red]Hello[/bold red], [italic blue]World[/italic blue]!")
```

### 2. Markdown 渲染

```python
from glm_cli.richtext import console, markdown

text = """
# 标题
这是 **粗体** 和 *斜体* 文本

## 代码示例

```python
def hello():
    print("Hello, World!")
```

- 列表项 1
- 列表项 2
- 列表项 3
"""

console.print(markdown(text))
```

### 3. 代码高亮

```python
from glm_cli.richtext import console, code

python_code = '''
from typing import List

def process(items: List[str]) -> List[str]:
    return [item.upper() for item in items]
'''

console.print(code(python_code, "python"))
```

### 4. 面板布局

```python
from glm_cli.richtext import console, panel, markdown

content = markdown("## 重要信息\n\n这是一个带边框的面板！")
console.print(panel(content, title="提示", border_style="yellow"))
```

### 5. 表格

```python
from glm_cli.richtext import console, table

headers = ["名称", "版本", "状态"]
rows = [
    ["Python", "3.12", "稳定"],
    ["Node.js", "20.0", "稳定"],
    ["Rust", "1.75", "稳定"],
]
console.print(table(headers, rows))
```

### 6. 状态消息

```python
from glm_cli.richtext import console, status_message

console.print(status_message("操作成功完成！", "success"))
console.print(status_message("请注意检查输入。", "warning"))
console.print(status_message("发生错误！", "error"))
```

## 运行演示

```bash
# 完整演示
python -m glm_cli.richtext.demo

# 基础示例
python examples/basic_usage.py
```

## API 参考

### 核心函数

- `console.print()` - 打印格式化内容
- `markdown(text)` - 创建 Markdown 渲染器
- `code(source, lexer)` - 创建代码高亮器
- `panel(content, title)` - 创建带边框的面板
- `table(headers, rows)` - 创建表格
- `status_message(message, status)` - 创建状态消息

### 自定义布局

- `bullet_columns(text)` - 带项目符号的文本
- `labeled_section(label, content)` - 带标签的区域
- `grid(items, columns)` - 网格布局
- `progress_steps(steps, current)` - 进度步骤

## 颜色和样式

```python
# 颜色
"[red]红色[/red]"
"[blue]蓝色[/blue]"
"[green]绿色[/green]"
"[yellow]黄色[/yellow]"
"[cyan]青色[/cyan]"
"[magenta]洋红色[/magenta]"

# 样式
"[bold]粗体[/bold]"
"[italic]斜体[/italic]"
"[dim]暗色[/dim]"
"[underline]下划线[/underline]"
"[strike]删除线[/strike]"

# 组合
"[bold red]粗体红色[/bold red]"
```

## 支持的语言

代码高亮支持所有 Pygments 词法分析器，包括：

- Python (`python`)
- JavaScript (`javascript`, `js`)
- TypeScript (`typescript`, `ts`)
- Bash (`bash`, `sh`)
- JSON (`json`)
- YAML (`yaml`)
- Markdown (`markdown`)
- SQL (`sql`)
- 等等...

## 项目结构

```
glm-cli/
├── glm_cli/
│   └── richtext/
│       ├── __init__.py       # 主入口
│       ├── console.py        # Console 配置
│       ├── themes.py         # 颜色主题
│       ├── formats.py        # 格式化组件
│       ├── markdown.py       # Markdown 渲染器
│       ├── custom.py         # 自定义布局
│       └── demo.py           # 演示程序
├── examples/
│   └── basic_usage.py        # 基础示例
├── tests/
│   └── test_richtext.py      # 测试
├── pyproject.toml            # 项目配置
└── README.md                 # 项目说明
```

## 贡献

欢迎提交问题报告和功能请求！

## 许可证

MIT License