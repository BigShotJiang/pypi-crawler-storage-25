"""Configuration management for glm-cli.

Handles API key storage and configuration file management.
Config file is stored at ~/.glm-cli/.env
"""

import os
from pathlib import Path
from dotenv import load_dotenv

CONFIG_DIR = Path.home() / ".glm-cli"
CONFIG_FILE = CONFIG_DIR / ".env"

DEFAULT_CONFIG = """# GLM CLI Configuration
# Get your API key from: https://open.bigmodel.cn/

ANTHROPIC_API_KEY=
ANTHROPIC_BASE_URL=https://open.bigmodel.cn/api/paas/v4/
MODEL_ID=glm-4-plus
"""


def ensure_config_dir() -> None:
    """Ensure config directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def config_exists() -> bool:
    """Check if config file exists and has API key."""
    if not CONFIG_FILE.exists():
        return False
    load_dotenv(CONFIG_FILE, override=True)
    return bool(os.getenv("ANTHROPIC_API_KEY"))


def get_config() -> dict:
    """Load and return current configuration."""
    if CONFIG_FILE.exists():
        load_dotenv(CONFIG_FILE, override=True)
    return {
        "api_key": os.getenv("ANTHROPIC_API_KEY", ""),
        "base_url": os.getenv("ANTHROPIC_BASE_URL", ""),
        "model_id": os.getenv("MODEL_ID", "glm-4-plus"),
    }


def save_config(api_key: str, base_url: str = "", model_id: str = "") -> None:
    """Save configuration to file."""
    ensure_config_dir()
    content = f"""# GLM CLI Configuration
# Get your API key from: https://open.bigmodel.cn/

ANTHROPIC_API_KEY={api_key}
ANTHROPIC_BASE_URL={base_url or "https://open.bigmodel.cn/api/paas/v4/"}
MODEL_ID={model_id or "glm-4-plus"}
"""
    CONFIG_FILE.write_text(content)
    # Set file permissions to 600 (owner read/write only)
    CONFIG_FILE.chmod(0o600)


def load_config() -> bool:
    """Load config and return True if API key is available."""
    if CONFIG_FILE.exists():
        load_dotenv(CONFIG_FILE, override=True)
    return bool(os.getenv("ANTHROPIC_API_KEY"))


def init_config_interactive() -> bool:
    """Interactive configuration initialization.

    Returns True if configuration is successful.
    """
    from rich.prompt import Prompt
    from glm_cli.richtext import console, panel

    console.print()
    console.print(panel(
        "[bold]GLM CLI Configuration[/bold]\n\n"
        "First-time setup: Please enter your API key.\n"
        "[dim]Get your key from: https://open.bigmodel.cn/[/dim]",
        title="[cyan]Setup[/cyan]",
        border_style="cyan",
    ))
    console.print()

    api_key = Prompt.ask("[bold cyan]API Key[/bold cyan]", password=True)

    if not api_key.strip():
        console.print("[red]Error: API key is required[/red]")
        return False

    base_url = Prompt.ask(
        "[bold cyan]Base URL[/bold cyan]",
        default="https://open.bigmodel.cn/api/paas/v4/"
    )

    model_id = Prompt.ask(
        "[bold cyan]Model ID[/bold cyan]",
        default="glm-5"
    )

    save_config(api_key.strip(), base_url.strip(), model_id.strip())

    console.print()
    console.print(f"[green]✓[/green] Configuration saved to [dim]{CONFIG_FILE}[/dim]")
    console.print()

    return True


def ensure_config() -> bool:
    """Ensure configuration is available.

    If config doesn't exist, prompt user to create it.
    Returns True if config is ready.
    """
    if load_config():
        return True

    # Try to load from environment variables first
    if os.getenv("ANTHROPIC_API_KEY"):
        return True

    # Need to initialize config
    return init_config_interactive()
