"""Custom layout components for rich text rendering.

This module provides custom layout components that extend Rich's
capabilities with specialized widgets for common CLI patterns.
"""

from __future__ import annotations

from rich.columns import Columns
from rich.console import Console, ConsoleOptions, RenderableType, RenderResult
from rich.measure import Measurement
from rich.segment import Segment
from rich.text import Text


class ShrinkToWidth:
    """Constrain a renderable to a maximum width.

    Args:
        renderable: The content to constrain
        max_width: Maximum width in characters
    """

    def __init__(self, renderable: RenderableType, max_width: int) -> None:
        self._renderable = renderable
        self._max_width = max(max_width, 1)

    def __rich_measure__(self, console: Console, options: ConsoleOptions) -> Measurement:
        width = self._resolve_width(options)
        return Measurement(0, width)

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        width = self._resolve_width(options)
        child_options = options.update(width=width)
        yield from console.render(self._renderable, child_options)

    def _resolve_width(self, options: ConsoleOptions) -> int:
        return max(1, min(self._max_width, options.max_width))


def _strip_trailing_spaces(segments: list[Segment]) -> list[Segment]:
    """Remove trailing spaces from each line in segments."""
    lines = list(Segment.split_lines(segments))
    trimmed: list[Segment] = []
    n_lines = len(lines)
    for index, line in enumerate(lines):
        line_segments = list(line)
        while line_segments:
            segment = line_segments[-1]
            if segment.control is not None:
                break
            trimmed_text = segment.text.rstrip(" ")
            if trimmed_text != segment.text:
                if trimmed_text:
                    line_segments[-1] = Segment(
                        trimmed_text, segment.style, segment.control
                    )
                    break
                line_segments.pop()
                continue
            break
        trimmed.extend(line_segments)
        if index != n_lines - 1:
            trimmed.append(Segment.line())
    if trimmed:
        trimmed.append(Segment.line())
    return trimmed


class BulletColumns:
    """Display content with a bullet point.

    The bullet is rendered on the left, and the content is wrapped
    to fit the available space. This is useful for:

    - Task lists
    - Feature descriptions
    - Bullet points with long text

    Args:
        renderable: The content to display
        bullet: Custom bullet (default: "•")
        bullet_style: Style for the bullet
        padding: Space between bullet and content
    """

    def __init__(
        self,
        renderable: RenderableType,
        *,
        bullet: RenderableType | None = None,
        bullet_style: str | None = None,
        padding: int = 1,
    ) -> None:
        self._renderable = renderable
        self._bullet = bullet
        self._bullet_style = bullet_style
        self._padding = padding

    def _bullet_renderable(self) -> RenderableType:
        if self._bullet is not None:
            return self._bullet
        return Text("•", style=self._bullet_style or "")

    def _available_width(
        self, console: Console, options: ConsoleOptions, bullet_width: int
    ) -> int:
        max_width = options.max_width or console.width or (bullet_width + self._padding + 1)
        available = max_width - bullet_width - self._padding
        return max(available, 1)

    def __rich_measure__(self, console: Console, options: ConsoleOptions) -> Measurement:
        bullet = self._bullet_renderable()
        bullet_measure = Measurement.get(console, options, bullet)
        bullet_width = max(bullet_measure.maximum, 1)
        available = self._available_width(console, options, bullet_width)
        constrained = ShrinkToWidth(self._renderable, available)
        columns = Columns([bullet, constrained], expand=False, padding=(0, self._padding))
        return Measurement.get(console, options, columns)

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        bullet = self._bullet_renderable()
        bullet_measure = Measurement.get(console, options, bullet)
        bullet_width = max(bullet_measure.maximum, 1)
        available = self._available_width(console, options, bullet_width)
        columns = Columns(
            [bullet, ShrinkToWidth(self._renderable, available)],
            expand=False,
            padding=(0, self._padding),
        )
        segments = list(console.render(columns, options))
        trimmed = _strip_trailing_spaces(segments)
        yield from trimmed


def bullet_columns(
    renderable: RenderableType,
    *,
    bullet: str = "•",
    bullet_style: str = "cyan",
    padding: int = 1,
) -> BulletColumns:
    """Create a bullet point layout.

    Args:
        renderable: The content to display
        bullet: Bullet character or text
        bullet_style: Style for the bullet
        padding: Space between bullet and content

    Returns:
        BulletColumns renderable
    """
    return BulletColumns(
        renderable, bullet=Text(bullet, style=bullet_style), padding=padding
    )


class LabeledSection:
    """A section with a label on the left and content on the right.

    Useful for displaying key-value pairs, field labels, or
    any content where you want a fixed-width label followed by
    wrapped content.

    Args:
        label: The label text
        content: The content to display
        label_width: Width of the label column (default: auto)
        label_style: Style for the label
        separator: Text between label and content (default: ": ")
    """

    def __init__(
        self,
        label: str,
        content: RenderableType,
        *,
        label_width: int | None = None,
        label_style: str = "cyan",
        separator: str = ": ",
    ) -> None:
        self.label = label
        self.content = content
        self.label_width = label_width
        self.label_style = label_style
        self.separator = separator

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        from rich.text import Text

        if self.label_width is None:
            label_width = len(self.label)
        else:
            label_width = self.label_width

        label_text = Text(self.label, style=self.label_style)
        label_text.append(self.separator)
        label_text.pad_right(label_width + len(self.separator) - len(self.label))

        available_width = options.max_width - label_text.cell_len - len(self.separator)
        if available_width < 1:
            available_width = 1

        constrained = ShrinkToWidth(self.content, available_width)
        columns = Columns(
            [label_text, constrained],
            expand=False,
            padding=(0, 0),
        )
        yield from console.render(columns, options)


def labeled_section(
    label: str,
    content: RenderableType,
    **kwargs,
) -> LabeledSection:
    """Create a labeled section.

    Args:
        label: The label text
        content: The content to display
        **kwargs: Additional arguments for LabeledSection

    Returns:
        LabeledSection renderable
    """
    return LabeledSection(label, content, **kwargs)


class Grid:
    """A simple grid layout with equal-width columns.

    Args:
        items: List of renderables to display in the grid
        columns: Number of columns (default: 2)
        padding: Space between cells
    """

    def __init__(
        self,
        items: list[RenderableType],
        *,
        columns: int = 2,
        padding: int = 2,
    ) -> None:
        self.items = items
        self.columns = columns
        self.padding = padding

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        from rich.columns import Columns

        for i in range(0, len(self.items), self.columns):
            row = self.items[i : i + self.columns]
            columns = Columns(row, padding=self.padding, expand=True)
            yield from console.render(columns, options)


def grid(items: list[RenderableType], *, columns: int = 2, padding: int = 2) -> Grid:
    """Create a grid layout.

    Args:
        items: List of renderables to display
        columns: Number of columns
        padding: Space between cells

    Returns:
        Grid renderable
    """
    return Grid(items, columns=columns, padding=padding)


class ProgressSteps:
    """Display progress through a series of steps.

    Each step can be pending, in progress, or completed.

    Args:
        steps: List of step names
        current: Index of current step (0-based)
    """

    # Icons for step states
    PENDING_ICON = "○"
    CURRENT_ICON = "◉"
    COMPLETED_ICON = "●"

    def __init__(self, steps: list[str], current: int = 0) -> None:
        self.steps = steps
        self.current = current

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        from rich.text import Text

        for i, step in enumerate(self.steps):
            text = Text()

            if i < self.current:
                icon = Text(self.COMPLETED_ICON, style="green")
            elif i == self.current:
                icon = Text(self.CURRENT_ICON, style="blue")
            else:
                icon = Text(self.PENDING_ICON, style="dim")

            text.append_text(icon)
            text.append(" ")

            if i < self.current:
                text.append(step, style="dim")
            elif i == self.current:
                text.append(step, style="bold")
            else:
                text.append(step, style="dim")

            yield text

            if i < len(self.steps) - 1:
                # Add connector line
                if i < self.current:
                    yield Text("  ↓", style="dim green")
                else:
                    yield Text("  ↓", style="dim")


def progress_steps(steps: list[str], current: int = 0) -> ProgressSteps:
    """Create a progress steps display.

    Args:
        steps: List of step names
        current: Index of current step

    Returns:
        ProgressSteps renderable
    """
    return ProgressSteps(steps, current)