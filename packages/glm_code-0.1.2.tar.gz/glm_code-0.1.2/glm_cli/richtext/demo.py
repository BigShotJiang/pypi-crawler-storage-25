"""Demo script showcasing the rich text rendering capabilities.

Run this script to see all the beautiful formatting options available
in the glm-cli richtext toolkit.
"""

from glm_cli.richtext import console
from glm_cli.richtext.custom import (
    bullet_columns,
    grid,
    labeled_section,
    progress_steps,
)
from glm_cli.richtext.formats import (
    code,
    key_value_table,
    markdown,
    panel,
    status_message,
    table,
)


def demo_markdown():
    """Showcase markdown rendering."""
    console.print("\n")
    md_content = """
# 🎨 GLM RichText Demo

Welcome to the **beautiful** world of *rich text* rendering!

## Features

- ✨ Syntax highlighting
- 📝 Markdown support
- 🎯 Custom layouts
- 🌈 Beautiful themes

### Code Example

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

print(greet("World"))
```

### Lists

1. First item
2. Second item
3. Third item

> This is a block quote with some important information.

---

**Bold**, *italic*, and `inline code`!
    """
    console.print(panel(markdown(md_content), title="📄 Markdown Rendering", border_style="blue"))


def demo_code():
    """Showcase syntax highlighting."""
    console.print("\n")

    python_code = '''
from typing import List

class DataProcessor:
    """Process and transform data."""

    def __init__(self, name: str):
        self.name = name
        self._cache: dict = {}

    def process(self, items: List[str]) -> List[str]:
        """Process a list of items."""
        results = []
        for item in items:
            processed = self._transform(item)
            results.append(processed)
        return results

    def _transform(self, item: str) -> str:
        # Transform the item
        return item.upper()
'''

    console.print(panel(code(python_code, "python"), title="🐍 Python Code", border_style="green"))


def demo_tables():
    """Showcase table rendering."""
    console.print("\n")

    # Standard table
    headers = ["Name", "Version", "Status"]
    rows = [
        ["Python", "3.12", "[green]✓ Stable[/green]"],
        ["Node.js", "20.0", "[green]✓ Stable[/green]"],
        ["Rust", "1.75", "[green]✓ Stable[/green]"],
    ]
    console.print(panel(table(headers, rows), title="📊 Standard Table", border_style="cyan"))

    console.print("\n")

    # Key-value table
    config = {
        "API Endpoint": "https://api.example.com",
        "Timeout": "30s",
        "Retries": "3",
        "Debug Mode": "false",
    }
    console.print(
        panel(key_value_table(config, title="Configuration"), title="⚙️ Key-Value Table", border_style="yellow")
    )


def demo_status_messages():
    """Showcase status messages."""
    console.print("\n")
    console.print(panel(status_message("Operation completed successfully!", "success"), title="✅ Status Messages"))


def demo_custom_layouts():
    """Showcase custom layout components."""
    console.print("\n")

    # Bullet columns
    console.print(panel(
        bullet_columns("This is a long piece of text that will be wrapped nicely next to the bullet point."),
        title="• Bullet Columns",
        border_style="magenta"
    ))

    console.print("\n")

    # Labeled section
    console.print(panel(
        labeled_section("Description", "This is a detailed description that explains what this feature does."),
        title="🏷️ Labeled Section",
        border_style="blue"
    ))

    console.print("\n")

    # Grid layout
    from rich.text import Text

    items = [
        Text("Item 1", style="bold green"),
        Text("Item 2", style="bold yellow"),
        Text("Item 3", style="bold blue"),
        Text("Item 4", style="bold magenta"),
    ]
    console.print(panel(
        grid(items, columns=2),
        title="🔲 Grid Layout",
        border_style="cyan"
    ))

    console.print("\n")

    # Progress steps
    steps = ["Initialize", "Load Data", "Process", "Validate", "Complete"]
    console.print(panel(
        progress_steps(steps, current=2),
        title="📈 Progress Steps",
        border_style="green"
    ))


def demo_combined():
    """Showcase combined elements."""
    console.print("\n")

    from rich.columns import Columns

    # Create a dashboard-like view
    left_content = panel(
        markdown("""
## System Status

All systems operational.

**Uptime:** 99.9%
**Memory:** 45%
**CPU:** 23%
        """),
        title="Status",
        border_style="green"
    )

    right_content = panel(
        table(
            ["Service", "Status"],
            [
                ["API", "[green]Running[/green]"],
                ["Database", "[green]Running[/green]"],
                ["Cache", "[green]Running[/green]"],
                ["Worker", "[yellow]Busy[/yellow]"],
            ],
        ),
        title="Services",
        border_style="cyan"
    )

    console.print(Columns([left_content, right_content], padding=2))


def main():
    """Run all demos."""
    # Print header
    console.print("\n")
    header = """
    ╔═══════════════════════════════════════════════════════╗
    ║                                                       ║
    ║        🎨 GLM RichText - Beautiful CLI Text          ║
    ║                                                       ║
    ║   A toolkit for elegant terminal text rendering      ║
    ║                                                       ║
    ╚═══════════════════════════════════════════════════════╝
    """
    console.print(header, style="bold cyan")

    demo_markdown()
    demo_code()
    demo_tables()
    demo_status_messages()
    demo_custom_layouts()
    demo_combined()

    console.print("\n")
    footer = "[dim]✨ For more information, visit the GitHub repository[/dim]"
    console.print(footer)


if __name__ == "__main__":
    main()