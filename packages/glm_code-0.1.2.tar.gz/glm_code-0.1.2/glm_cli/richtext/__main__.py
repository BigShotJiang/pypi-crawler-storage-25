"""Run the demo directly as a module."""

from glm_cli.richtext.demo import main

if __name__ == "__main__":
    main()