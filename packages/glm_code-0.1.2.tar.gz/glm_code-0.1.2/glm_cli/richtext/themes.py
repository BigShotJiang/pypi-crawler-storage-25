"""Beautiful color themes for syntax highlighting and markdown rendering.

This module provides carefully crafted color themes optimized for terminal
display. The themes are designed to be:

- Easy on the eyes for long coding sessions
- High contrast for readability
- Consistent across different code types
- Beautiful in both light and dark terminals
"""

from __future__ import annotations

from pygments.token import (
    Comment,
    Generic,
    Keyword,
    Name,
    Number,
    Operator,
    Punctuation,
    String,
)
from pygments.token import Literal as PygmentsLiteral
from pygments.token import Text as PygmentsText
from pygments.token import Token as PygmentsToken
from rich.style import Style
from rich.syntax import ANSISyntaxTheme
from rich.theme import Theme

# ---------------------------------------------------------------------------
# Syntax Theme - A beautiful, high-contrast theme for code
# ---------------------------------------------------------------------------

GLM_ANSI_THEME = ANSISyntaxTheme(
    {
        # Base text styles
        PygmentsToken: Style(color="default"),
        PygmentsText: Style(color="default"),
        # Comments - subtle gray with italic
        Comment: Style(color="bright_black", italic=True),
        # Keywords - magenta for control flow and declarations
        Keyword: Style(color="magenta"),
        Keyword.Constant: Style(color="cyan"),
        Keyword.Declaration: Style(color="magenta"),
        Keyword.Namespace: Style(color="magenta"),
        Keyword.Pseudo: Style(color="magenta"),
        Keyword.Reserved: Style(color="magenta"),
        Keyword.Type: Style(color="magenta"),
        # Names - various identifiers
        Name: Style(color="default"),
        Name.Attribute: Style(color="cyan"),
        Name.Builtin: Style(color="bright_yellow"),
        Name.Builtin.Pseudo: Style(color="cyan"),
        Name.Builtin.Type: Style(color="bright_yellow", bold=True),
        Name.Class: Style(color="bright_yellow", bold=True),
        Name.Constant: Style(color="cyan"),
        Name.Decorator: Style(color="bright_cyan"),
        Name.Entity: Style(color="bright_yellow"),
        Name.Exception: Style(color="bright_yellow", bold=True),
        Name.Function: Style(color="bright_cyan"),
        Name.Label: Style(color="cyan"),
        Name.Namespace: Style(color="magenta"),
        Name.Other: Style(color="bright_cyan"),
        Name.Property: Style(color="cyan"),
        Name.Tag: Style(color="bright_green"),
        Name.Variable: Style(color="bright_yellow"),
        # Literals - strings and numbers
        PygmentsLiteral: Style(color="bright_blue"),
        PygmentsLiteral.Date: Style(color="bright_blue"),
        String: Style(color="bright_blue"),
        String.Doc: Style(color="bright_blue", italic=True),
        String.Interpol: Style(color="bright_blue"),
        String.Affix: Style(color="cyan"),
        Number: Style(color="cyan"),
        # Operators and punctuation
        Operator: Style(color="default"),
        Operator.Word: Style(color="magenta"),
        Punctuation: Style(color="default"),
        # Generic styles
        Generic.Deleted: Style(color="red"),
        Generic.Emph: Style(italic=True),
        Generic.Error: Style(color="bright_red", bold=True),
        Generic.Heading: Style(color="cyan", bold=True),
        Generic.Inserted: Style(color="green"),
        Generic.Output: Style(color="bright_black"),
        Generic.Prompt: Style(color="bright_cyan"),
        Generic.Strong: Style(bold=True),
        Generic.Subheading: Style(color="cyan"),
        Generic.Traceback: Style(color="bright_red", bold=True),
    }
)

# ---------------------------------------------------------------------------
# Markdown Theme - Neutral theme for clean markdown rendering
# ---------------------------------------------------------------------------

GLM_NEUTRAL_MARKDOWN_THEME = Theme(
    {
        "markdown.paragraph": "none",
        "markdown.block_quote": "none",
        "markdown.hr": "none",
        "markdown.item": "none",
        "markdown.item.bullet": "none",
        "markdown.item.number": "none",
        "markdown.link": "none",
        "markdown.link_url": "none",
        "markdown.h1": "none",
        "markdown.h1.border": "none",
        "markdown.h2": "none",
        "markdown.h3": "none",
        "markdown.h4": "none",
        "markdown.h5": "none",
        "markdown.h6": "none",
        "markdown.em": "none",
        "markdown.strong": "none",
        "markdown.s": "none",
        "status.spinner": "none",
    },
    inherit=True,
)

# Fallback styles for markdown elements
MARKDOWN_FALLBACK_STYLES = {
    "markdown.paragraph": Style(),
    "markdown.h1": Style(color="bright_white", bold=True),
    "markdown.h1.underline": Style(color="bright_white", bold=True),
    "markdown.h2": Style(color="white", bold=True, underline=True),
    "markdown.h3": Style(bold=True),
    "markdown.h4": Style(bold=True),
    "markdown.h5": Style(bold=True),
    "markdown.h6": Style(dim=True, italic=True),
    "markdown.code": Style(color="bright_cyan", bold=True),
    "markdown.code_block": Style(color="bright_cyan"),
    "markdown.item": Style(),
    "markdown.item.bullet": Style(),
    "markdown.item.number": Style(),
    "markdown.em": Style(italic=True),
    "markdown.strong": Style(bold=True),
    "markdown.s": Style(strike=True),
    "markdown.link": Style(color="bright_blue", underline=True),
    "markdown.link_url": Style(color="cyan", underline=True),
    "markdown.block_quote": Style(),
    "markdown.hr": Style(color="grey58"),
}


def resolve_code_theme(theme):
    """Resolve theme name to actual theme object.

    Args:
        theme: Theme name string or SyntaxTheme object

    Returns:
        Resolved theme object
    """
    if isinstance(theme, str) and theme.lower() == "glm-ansi":
        return GLM_ANSI_THEME
    return theme