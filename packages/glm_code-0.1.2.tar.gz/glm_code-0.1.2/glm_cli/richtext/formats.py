"""High-level formatting components for rich text rendering.

This module provides convenient wrappers around Rich's renderables with
pre-configured themes and styles optimized for beautiful output.
"""

from __future__ import annotations

from typing import Any

from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table as RichTable
from rich.text import Text

from glm_cli.richtext.themes import (
    GLM_ANSI_THEME,
    resolve_code_theme,
)


class Code:
    """Syntax-highlighted code block.

    Args:
        code: The source code to highlight
        lexer: Pygments lexer name (e.g., "python", "javascript", "bash")
        theme: Syntax theme (defaults to GLM_ANSI_THEME)
        line_numbers: Show line numbers
        word_wrap: Wrap long lines
        **kwargs: Additional arguments passed to rich.syntax.Syntax
    """

    def __init__(
        self,
        code: str,
        lexer: str = "text",
        theme: Any = GLM_ANSI_THEME,
        line_numbers: bool = False,
        word_wrap: bool = True,
        **kwargs: Any,
    ) -> None:
        self.code = code
        self.lexer = lexer
        self.theme = resolve_code_theme(theme)
        self.line_numbers = line_numbers
        self.word_wrap = word_wrap
        self.kwargs = kwargs

    def __rich_console__(self, console, options):
        """Render the syntax-highlighted code."""
        syntax = Syntax(
            self.code,
            self.lexer,
            theme=self.theme,
            line_numbers=self.line_numbers,
            word_wrap=self.word_wrap,
            background_color=None,
            padding=0,
            **self.kwargs,
        )
        return console.render(syntax, options)


class Markdown:
    """Markdown text with beautiful rendering.

    Args:
        markup: Markdown string to render
        code_theme: Theme for code blocks (defaults to GLM_ANSI_THEME)
        justify: Text justification ("left", "center", "right", "full")
        hyperlinks: Enable clickable hyperlinks
        inline_code_lexer: Lexer for inline code (None = no highlighting)
        **kwargs: Additional arguments
    """

    def __init__(
        self,
        markup: str,
        code_theme: Any = GLM_ANSI_THEME,
        justify: str | None = None,
        hyperlinks: bool = True,
        inline_code_lexer: str | None = None,
        **kwargs: Any,
    ) -> None:
        from markdown_it import MarkdownIt as _MarkdownIt
        MarkdownIt = _MarkdownIt

        self.markup = markup
        self.code_theme = resolve_code_theme(code_theme)
        self.justify = justify
        self.hyperlinks = hyperlinks
        self.inline_code_lexer = inline_code_lexer
        self.kwargs = kwargs

        # Parse markdown
        parser = MarkdownIt().enable("strikethrough").enable("table")
        self.parsed = parser.parse(markup)

    def __rich_console__(self, console, options):
        """Render the markdown."""
        from glm_cli.richtext.markdown import render_markdown

        return render_markdown(
            console,
            options,
            self.parsed,
            self.markup,
            code_theme=self.code_theme,
            justify=self.justify,
            hyperlinks=self.hyperlinks,
            inline_code_lexer=self.inline_code_lexer,
        )


def code(source: str, lexer: str = "python", **kwargs) -> Code:
    """Create a syntax-highlighted code block.

    Shortcut for Code constructor with common defaults.

    Args:
        source: Source code to highlight
        lexer: Pygments lexer name
        **kwargs: Additional arguments

    Returns:
        Code renderable
    """
    return Code(source, lexer, **kwargs)


def markdown(text: str, **kwargs) -> Markdown:
    """Create a markdown renderable.

    Shortcut for Markdown constructor.

    Args:
        text: Markdown string
        **kwargs: Additional arguments

    Returns:
        Markdown renderable
    """
    return Markdown(text, **kwargs)


def panel(content, title: str = "", border_style: str = "dim", **kwargs) -> Panel:
    """Create a bordered panel.

    Args:
        content: Rich renderable for the panel content
        title: Optional panel title
        border_style: Style for the border
        **kwargs: Additional arguments passed to Panel

    Returns:
        Panel renderable
    """
    return Panel(content, title=title, border_style=border_style, **kwargs)


class Table:
    """Beautiful formatted table.

    Args:
        headers: Column header strings
        rows: List of rows, each row is a list of cell values
        title: Optional table title
        border_style: Style for table borders
        **kwargs: Additional arguments passed to rich.table.Table
    """

    def __init__(
        self,
        headers: list[str],
        rows: list[list[str]],
        title: str = "",
        border_style: str = "bright_black",
        **kwargs: Any,
    ) -> None:
        self.headers = headers
        self.rows = rows
        self.title = title
        self.border_style = border_style
        self.kwargs = kwargs

    def __rich_console__(self, console, options):
        """Render the table."""
        from rich import box

        table = RichTable(
            title=self.title,
            box=box.SIMPLE_HEAVY,
            border_style=self.border_style,
            **self.kwargs,
        )

        for header in self.headers:
            table.add_column(header)

        for row in self.rows:
            table.add_row(*row)

        return console.render(table, options)


def table(headers: list[str], rows: list[list[str]], **kwargs) -> Table:
    """Create a formatted table.

    Shortcut for Table constructor.

    Args:
        headers: Column header strings
        rows: List of rows, each row is a list of cell values
        **kwargs: Additional arguments

    Returns:
        Table renderable
    """
    return Table(headers, rows, **kwargs)


class KeyValueTable:
    """A table for displaying key-value pairs.

    Useful for configuration, environment variables, or metadata.

    Args:
        data: Dictionary of key-value pairs
        title: Optional table title
        key_style: Style for keys (default: "cyan")
        value_style: Style for values (default: "default")
    """

    def __init__(
        self,
        data: dict[str, str],
        title: str = "",
        key_style: str = "cyan",
        value_style: str = "default",
    ) -> None:
        self.data = data
        self.title = title
        self.key_style = key_style
        self.value_style = value_style

    def __rich_console__(self, console, options):
        """Render the key-value table."""
        from rich import box

        table = RichTable(
            title=self.title,
            box=box.SIMPLE,
            show_header=False,
            padding=(0, 1),
        )

        for key, value in self.data.items():
            key_text = Text(key, style=self.key_style)
            value_text = Text(value, style=self.value_style)
            table.add_row(key_text, value_text)

        return console.render(table, options)


def key_value_table(data: dict[str, str], **kwargs) -> KeyValueTable:
    """Create a key-value table.

    Args:
        data: Dictionary of key-value pairs
        **kwargs: Additional arguments

    Returns:
        KeyValueTable renderable
    """
    return KeyValueTable(data, **kwargs)


class StatusMessage:
    """A status message with icon and colored text.

    Args:
        message: The message text
        status: Status type ("success", "error", "warning", "info")
    """

    # Icons for different statuses
    ICONS = {
        "success": "✓",
        "error": "✗",
        "warning": "⚠",
        "info": "ℹ",
    }

    # Colors for different statuses
    COLORS = {
        "success": "green",
        "error": "red",
        "warning": "yellow",
        "info": "blue",
    }

    def __init__(self, message: str, status: str = "info") -> None:
        self.message = message
        self.status = status
        self.icon = self.ICONS.get(status, "•")
        self.color = self.COLORS.get(status, "white")

    def __rich_console__(self, console, options):
        """Render the status message."""
        text = Text()
        text.append(self.icon + " ", style=f"bold {self.color}")
        text.append(self.message)
        return console.render(text, options)


def status_message(message: str, status: str = "info") -> StatusMessage:
    """Create a status message.

    Args:
        message: The message text
        status: Status type ("success", "error", "warning", "info")

    Returns:
        StatusMessage renderable
    """
    return StatusMessage(message, status)