r"""Beautiful markdown rendering with syntax highlighting and custom styling.

This module provides a custom markdown renderer built on top of Rich's
rendering system, with support for:

- Headers with underlines
- Code blocks with syntax highlighting
- Inline code with optional highlighting
- Lists with proper indentation
- Block quotes with styled borders
- Tables with beautiful formatting
- Links with hyperlinks
- Images with placeholder rendering
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from markdown_it.token import Token
from rich._loop import loop_first
from rich._stack import Stack
from rich.console import Console, ConsoleOptions, JustifyMethod, RenderResult
from rich.containers import Renderables
from rich.rule import Rule
from rich.segment import Segment
from rich.style import Style, StyleStack
from rich.syntax import Syntax
from rich.text import Text, TextType

from glm_cli.richtext.themes import MARKDOWN_FALLBACK_STYLES, resolve_code_theme

LIST_INDENT_WIDTH = 2


def _strip_background(text: Text) -> Text:
    """Return a copy of text with all background colors removed."""
    clean = Text(
        text.plain,
        justify=text.justify,
        overflow=text.overflow,
        no_wrap=text.no_wrap,
        end=text.end,
        tab_size=text.tab_size,
    )

    if text.style:
        base_style = text.style
        if not isinstance(base_style, Style):
            base_style = Style.parse(str(base_style))
        base_style = base_style.copy()
        if base_style._bgcolor is not None:
            base_style._bgcolor = None
        clean.stylize(base_style, 0, len(clean))

    for span in text.spans:
        style = span.style
        if style is None:
            continue
        new_style = Style.parse(str(style)) if not isinstance(style, Style) else style.copy()
        if new_style._bgcolor is not None:
            new_style._bgcolor = None
        clean.stylize(new_style, span.start, span.end)

    return clean


class MarkdownElement:
    """Base class for markdown elements."""

    new_line: bool = True

    @classmethod
    def create(cls, markdown_ctx, token: Token) -> "MarkdownElement":
        """Factory to create markdown element."""
        return cls()

    def on_enter(self, context: "MarkdownContext") -> None:
        """Called when the node is entered."""

    def on_text(self, context: "MarkdownContext", text: TextType) -> None:
        """Called when text is parsed."""

    def on_leave(self, context: "MarkdownContext") -> None:
        """Called when the parser leaves the element."""

    def on_child_close(
        self, context: "MarkdownContext", child: "MarkdownElement"
    ) -> bool:
        """Called when a child element is closed."""
        return True

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        return ()


class TextElement(MarkdownElement):
    """Base class for elements that render text."""

    style_name = "none"

    def on_enter(self, context: "MarkdownContext") -> None:
        self.style = context.enter_style(self.style_name)
        self.text = Text(justify="left")

    def on_text(self, context: "MarkdownContext", text: TextType) -> None:
        self.text.append(text, context.current_style if isinstance(text, str) else None)

    def on_leave(self, context: "MarkdownContext") -> None:
        context.leave_style()


class Paragraph(TextElement):
    """A paragraph."""

    style_name = "markdown.paragraph"

    def __init__(self, justify: JustifyMethod = "left"):
        self.justify = justify

    @classmethod
    def create(cls, markdown_ctx, token: Token) -> "Paragraph":
        return cls(justify=markdown_ctx.justify or "left")

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        self.text.justify = self.justify
        yield self.text


class Heading(TextElement):
    """A heading."""

    def __init__(self, tag: str = "h1"):
        self.tag = tag
        self.style_name = f"markdown.{tag}"

    @classmethod
    def create(cls, markdown_ctx, token: Token) -> "Heading":
        return cls(token.tag)

    def on_enter(self, context: "MarkdownContext") -> None:
        self.text = Text()
        context.enter_style(self.style_name)

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        text = self.text
        text.justify = "left"
        width = max(1, text.cell_len)

        if self.tag == "h1":
            underline = Text("═" * width)
            underline.stylize("markdown.h1.underline")
            yield text
            yield underline
        else:
            yield text


class CodeBlock(TextElement):
    """A code block with syntax highlighting."""

    style_name = "markdown.code_block"

    def __init__(self, lexer_name: str = "text", theme: Any = None):
        self.lexer_name = lexer_name
        self.theme = theme

    @classmethod
    def create(cls, markdown_ctx, token: Token) -> "CodeBlock":
        node_info = token.info or ""
        lexer_name = node_info.partition(" ")[0]
        return cls(lexer_name or "text", markdown_ctx.code_theme)

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        code = str(self.text).rstrip()
        syntax = Syntax(
            code,
            self.lexer_name,
            theme=self.theme,
            word_wrap=True,
            background_color=None,
            padding=0,
        )
        highlighted = syntax.highlight(code)
        highlighted.rstrip()
        stripped = _strip_background(highlighted)
        stripped.rstrip()
        yield stripped


class BlockQuote(TextElement):
    """A block quote."""

    style_name = "markdown.block_quote"

    def __init__(self) -> None:
        self.elements: Renderables = Renderables()

    def on_child_close(
        self, context: "MarkdownContext", child: "MarkdownElement"
    ) -> bool:
        self.elements.append(child)
        return False

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        render_options = options.update(width=options.max_width - 4)
        style = self.style.without_color
        lines = console.render_lines(self.elements, render_options, style=style)
        new_line = Segment("\n")
        padding = Segment("▌ ", style)
        for line in lines:
            yield padding
            yield from line
            yield new_line


class HorizontalRule(MarkdownElement):
    """A horizontal rule."""

    new_line = False

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        style = MARKDOWN_FALLBACK_STYLES["markdown.hr"].copy()
        yield Rule(style=style)


class ListElement(MarkdownElement):
    """A list element."""

    def __init__(self, list_type: str = "bullet", list_start: int = 1):
        self.items: list["ListItem"] = []
        self.list_type = list_type
        self.list_start = list_start

    @classmethod
    def create(cls, markdown_ctx, token: Token) -> "ListElement":
        return cls(token.type, int(token.attrs.get("start", 1)))

    def on_child_close(
        self, context: "MarkdownContext", child: "MarkdownElement"
    ) -> bool:
        self.items.append(child)
        return False

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        if self.list_type == "bullet_list_open":
            for item in self.items:
                yield from item.render_bullet(console, options)
        else:
            number = self.list_start
            for index, item in enumerate(self.items):
                yield from item.render_number(console, options, number + index)


class ListItem(TextElement):
    """An item in a list."""

    style_name = "markdown.item"

    @staticmethod
    def _line_starts_with_list_marker(text: str) -> bool:
        stripped = text.lstrip()
        if not stripped:
            return False
        if stripped.startswith(("• ", "- ", "* ")):
            return True
        index = 0
        while index < len(stripped) and stripped[index].isdigit():
            index += 1
        if index == 0 or index >= len(stripped):
            return False
        marker = stripped[index]
        has_space = index + 1 < len(stripped) and stripped[index + 1] == " "
        return marker in {".", ")"} and has_space

    @classmethod
    def create(cls, markdown_ctx, token: Token) -> "ListItem":
        depth = max(0, (token.level - 1) // 2)
        return cls(indent=depth)

    def __init__(self, indent: int = 0) -> None:
        self.indent = indent
        self.elements: Renderables = Renderables()

    def on_child_close(
        self, context: "MarkdownContext", child: "MarkdownElement"
    ) -> bool:
        self.elements.append(child)
        return False

    def render_bullet(self, console: Console, options: ConsoleOptions) -> RenderResult:
        lines = console.render_lines(self.elements, options, style=self.style)
        indent_padding_len = LIST_INDENT_WIDTH * self.indent
        indent_text = " " * indent_padding_len
        bullet = Segment("• ")
        new_line = Segment("\n")
        bullet_width = len(bullet.text)
        for first, line in loop_first(lines):
            if first:
                if indent_text:
                    yield Segment(indent_text)
                yield bullet
            else:
                plain = "".join(segment.text for segment in line)
                if self._line_starts_with_list_marker(plain):
                    prefix = ""
                else:
                    existing = len(plain) - len(plain.lstrip(" "))
                    target = indent_padding_len + bullet_width
                    missing = max(0, target - existing)
                    prefix = " " * missing
                if prefix:
                    yield Segment(prefix)
            yield from line
            yield new_line

    def render_number(
        self, console: Console, options: ConsoleOptions, number: int
    ) -> RenderResult:
        lines = console.render_lines(self.elements, options, style=self.style)
        new_line = Segment("\n")
        indent_padding_len = LIST_INDENT_WIDTH * self.indent
        indent_text = " " * indent_padding_len
        numeral_text = f"{number}. "
        numeral = Segment(numeral_text)
        numeral_width = len(numeral_text)
        for first, line in loop_first(lines):
            if first:
                if indent_text:
                    yield Segment(indent_text)
                yield numeral
            else:
                plain = "".join(segment.text for segment in line)
                if self._line_starts_with_list_marker(plain):
                    prefix = ""
                else:
                    existing = len(plain) - len(plain.lstrip(" "))
                    target = indent_padding_len + numeral_width
                    missing = max(0, target - existing)
                    prefix = " " * missing
                if prefix:
                    yield Segment(prefix)
            yield from line
            yield new_line


class ImageItem(MarkdownElement):
    """Placeholder for an image."""

    new_line = False

    def __init__(self, destination: str, hyperlinks: bool = True):
        self.destination = destination
        self.hyperlinks = hyperlinks

    @classmethod
    def create(cls, markdown_ctx, token: Token) -> "ImageItem":
        return cls(str(token.attrs.get("src", "")), markdown_ctx.hyperlinks)

    def on_enter(self, context: "MarkdownContext") -> None:
        self.link = context.current_style.link
        super().on_enter(context)

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        from rich.style import Style

        link_style = Style(link=self.link or self.destination or None)
        title = self.destination.strip("/").rsplit("/", 1)[-1]
        title_text = Text(title)
        if self.hyperlinks:
            title_text.stylize(link_style)
        text = Text.assemble("🌆 ", title_text, " ", end="")
        yield text


class MarkdownContext:
    """Manages the console render state for markdown."""

    def __init__(
        self,
        console: Console,
        options: ConsoleOptions,
        style: Style,
        fallback_styles: dict,
        code_theme: Any = None,
        inline_code_lexer: str | None = None,
        justify: JustifyMethod | None = None,
        hyperlinks: bool = True,
    ) -> None:
        self.console = console
        self.options = options
        self.style_stack: StyleStack = StyleStack(style)
        self.stack: Stack[MarkdownElement] = Stack()
        self._fallback_styles = fallback_styles
        self.code_theme = code_theme
        self.inline_code_lexer = inline_code_lexer
        self.justify = justify
        self.hyperlinks = hyperlinks

        self._syntax: Syntax | None = None
        if inline_code_lexer is not None:
            theme = resolve_code_theme(code_theme)
            self._syntax = Syntax("", inline_code_lexer, theme=theme)

    @property
    def current_style(self) -> Style:
        """Current style which is the product of all styles on the stack."""
        return self.style_stack.current

    def on_text(self, text: str, node_type: str) -> None:
        """Called when the parser visits text."""
        if node_type in {"fence", "code_inline"} and self._syntax is not None:
            highlighted = self._syntax.highlight(text)
            highlighted.rstrip()
            stripped = _strip_background(highlighted)
            combined = Text.assemble(stripped, style=self.style_stack.current)
            self.stack.top.on_text(self, combined)
        else:
            self.stack.top.on_text(self, text)

    def enter_style(self, style_name: str | Style) -> Style:
        """Enter a style context."""
        if isinstance(style_name, Style):
            style = style_name
        else:
            fallback = self._fallback_styles.get(style_name, Style())
            style = self.console.get_style(style_name, default=fallback)
            style = fallback + style
        style = style.copy()
        if isinstance(style_name, str) and style_name == "markdown.block_quote":
            style = style.without_color
        if (
            isinstance(style_name, str)
            and style_name in {"markdown.code", "markdown.code_block"}
            and style._bgcolor is not None
        ):
            style._bgcolor = None
        self.style_stack.push(style)
        return self.current_style

    def leave_style(self) -> Style:
        """Leave a style context."""
        style = self.style_stack.pop()
        return style


def render_markdown(
    console: Console,
    options: ConsoleOptions,
    parsed: list[Token],
    markup: str,
    code_theme: Any = None,
    justify: JustifyMethod | None = None,
    hyperlinks: bool = True,
    inline_code_lexer: str | None = None,
) -> RenderResult:
    """Render parsed markdown tokens to the console.

    Args:
        console: Rich console instance
        options: Console rendering options
        parsed: Parsed markdown tokens from markdown-it
        markup: Original markdown string
        code_theme: Theme for code blocks
        justify: Text justification
        hyperlinks: Enable hyperlinks
        inline_code_lexer: Lexer for inline code

    Yields:
        RenderResult segments
    """
    style = console.get_style("none", default="none")
    options = options.update(height=None)

    context = MarkdownContext(
        console,
        options,
        style,
        MARKDOWN_FALLBACK_STYLES,
        code_theme=code_theme,
        inline_code_lexer=inline_code_lexer,
        justify=justify,
        hyperlinks=hyperlinks,
    )

    elements = {
        "paragraph_open": Paragraph,
        "paragraph_close": Paragraph,
        "heading_open": Heading,
        "heading_close": Heading,
        "fence": CodeBlock,
        "code_block": CodeBlock,
        "blockquote_open": BlockQuote,
        "blockquote_close": BlockQuote,
        "hr": HorizontalRule,
        "bullet_list_open": ListElement,
        "bullet_list_close": ListElement,
        "ordered_list_open": ListElement,
        "ordered_list_close": ListElement,
        "list_item_open": ListItem,
        "list_item_close": ListItem,
        "image": ImageItem,
    }

    inlines = {"em", "strong", "code", "s"}

    def _flatten_tokens(tokens: Iterable[Token]) -> Iterable[Token]:
        """Flattens the token stream."""
        for token in tokens:
            is_fence = token.type == "fence"
            is_image = token.tag == "img"
            if token.children and not (is_image or is_fence):
                yield from _flatten_tokens(token.children)
            else:
                yield token

    class MarkdownRenderer:
        def __init__(self):
            self.justify = justify
            self.code_theme = code_theme
            self.hyperlinks = hyperlinks
            self.inline_code_lexer = inline_code_lexer

    markdown_renderer = MarkdownRenderer()

    tokens = parsed
    inline_style_tags = inlines
    new_line = False
    _new_line_segment = Segment.line()
    render_started = False

    for token in _flatten_tokens(tokens):
        node_type = token.type
        tag = token.tag

        entering = token.nesting == 1
        exiting = token.nesting == -1
        self_closing = token.nesting == 0

        if node_type in {"text", "html_inline", "html_block"}:
            if context.stack:
                context.on_text(token.content, node_type)
            else:
                paragraph = Paragraph(justify=justify or "left")
                paragraph.on_enter(context)
                paragraph.on_text(context, token.content)
                paragraph.on_leave(context)
                if new_line and render_started:
                    yield _new_line_segment
                rendered = console.render(paragraph, context.options)
                for segment in rendered:
                    render_started = True
                    yield segment
                new_line = paragraph.new_line
        elif node_type == "hardbreak":
            context.on_text("\n", node_type)
        elif node_type == "softbreak":
            context.on_text(" ", node_type)
        elif node_type == "link_open":
            href = str(token.attrs.get("href", ""))
            if hyperlinks:
                link_style = console.get_style("markdown.link_url", default="none")
                link_style += Style(link=href)
                context.enter_style(link_style)
            else:
                # Store link for later rendering
                context._link_href = href
                context._link_text = []
        elif node_type == "link_close":
            if hyperlinks:
                context.leave_style()
        elif tag in inline_style_tags and node_type != "fence" and node_type != "code_block":
            if entering:
                context.enter_style(f"markdown.{tag}")
            elif exiting:
                context.leave_style()
            else:
                context.enter_style(f"markdown.{tag}")
                if token.content:
                    context.on_text(token.content, node_type)
                context.leave_style()
        else:
            element_class = elements.get(token.type)
            if element_class:
                element = element_class.create(markdown_renderer, token)

                if entering or self_closing:
                    context.stack.push(element)
                    element.on_enter(context)

                if exiting:
                    element = context.stack.pop()

                    should_render = not context.stack or (
                        context.stack and context.stack.top.on_child_close(context, element)
                    )

                    if should_render:
                        if new_line and render_started:
                            yield _new_line_segment

                        rendered = console.render(element, context.options)
                        for segment in rendered:
                            render_started = True
                            yield segment
                elif self_closing:
                    context.stack.pop()
                    text = token.content
                    if text is not None:
                        element.on_text(context, text)

                    should_render = (
                        not context.stack
                        or context.stack
                        and context.stack.top.on_child_close(context, element)
                    )
                    if should_render:
                        if new_line and node_type != "inline" and render_started:
                            yield _new_line_segment
                        rendered = console.render(element, context.options)
                        for segment in rendered:
                            render_started = True
                            yield segment

                if exiting or self_closing:
                    element.on_leave(context)
                    new_line = element.new_line