"""Beautiful rich text rendering toolkit.

This module provides a high-level API for rendering beautiful formatted text
in terminal applications. It includes:

- Console helpers with pre-configured themes
- Markdown rendering with syntax highlighting
- Code highlighting with custom themes
- Panel layouts and structured content
- Diff rendering with inline highlighting

Example:
    >>> from glm_cli.richtext import console, markdown
    >>> console.print(markdown("# Hello\\n\\nThis is **rich** text!"))
"""

from glm_cli.richtext.console import console, render_to_ansi
from glm_cli.richtext.formats import code, markdown, panel, table
from glm_cli.richtext.themes import GLM_ANSI_THEME

__all__ = [
    "console",
    "render_to_ansi",
    "code",
    "markdown",
    "panel",
    "table",
    "GLM_ANSI_THEME",
]