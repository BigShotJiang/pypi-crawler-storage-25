"""Console configuration with pre-configured themes and helpers."""

from __future__ import annotations

from rich.console import Console, RenderableType

from glm_cli.richtext.themes import GLM_NEUTRAL_MARKDOWN_THEME

# Global console instance with neutral markdown theme
console = Console(
    highlight=False,
    theme=GLM_NEUTRAL_MARKDOWN_THEME,
    force_terminal=True,
)

# Console for forcing colors even when not in a terminal
force_color_console = Console(
    highlight=False,
    theme=GLM_NEUTRAL_MARKDOWN_THEME,
    force_terminal=True,
)


def render_to_ansi(renderable: RenderableType, *, columns: int) -> str:
    """Render a Rich renderable to an ANSI string.

    This is useful for integrating with prompt_toolkit or other TUI frameworks
    that accept ANSI strings.

    Args:
        renderable: A Rich renderable object
        columns: Width of the output in characters

    Returns:
        ANSI string containing the rendered output
    """
    from io import StringIO

    width = max(20, columns)
    buf = StringIO()
    temp = Console(
        file=buf,
        force_terminal=True,
        color_system="truecolor",
        width=width,
        theme=GLM_NEUTRAL_MARKDOWN_THEME,
        highlight=False,
    )
    temp.print(renderable, end="")
    return buf.getvalue()


def print_markdown(text: str, **kwargs) -> None:
    """Print markdown text to the console.

    Args:
        text: Markdown string to render
        **kwargs: Additional arguments passed to Markdown renderer
    """
    from glm_cli.richtext.formats import Markdown

    console.print(Markdown(text, **kwargs))


def print_code(code: str, lexer: str = "text", **kwargs) -> None:
    """Print syntax-highlighted code to the console.

    Args:
        code: Code string to render
        lexer: Pygments lexer name (e.g., "python", "javascript")
        **kwargs: Additional arguments passed to Syntax renderer
    """
    from glm_cli.richtext.formats import Code

    console.print(Code(code, lexer, **kwargs))


def print_panel(content: RenderableType, title: str = "", **kwargs) -> None:
    """Print content in a bordered panel.

    Args:
        content: Rich renderable to display
        title: Optional title for the panel
        **kwargs: Additional arguments passed to Panel
    """
    from rich.panel import Panel

    console.print(Panel(content, title=title, **kwargs))


def print_table(headers: list[str], rows: list[list[str]], **kwargs) -> None:
    """Print data as a formatted table.

    Args:
        headers: Column headers
        rows: List of rows, each row is a list of cell values
        **kwargs: Additional arguments passed to Table
    """
    from glm_cli.richtext.formats import Table

    console.print(Table(headers, rows, **kwargs))