"""Module entry point for python -m glm_cli execution.

This allows the package to be run as a module:
    python -m glm_cli
"""

from glm_cli.cli import main

if __name__ == "__main__":
    main()
