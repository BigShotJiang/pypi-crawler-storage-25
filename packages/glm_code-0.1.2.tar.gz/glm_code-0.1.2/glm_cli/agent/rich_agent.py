"""Rich agent loop with beautiful terminal output.

A coding agent that uses the GLM API (Anthropic-compatible) with tool use,
rendered beautifully using glm-cli's richtext library.

Based on the agent loop pattern from learn-claude-code/s01_agent_loop.py,
enhanced with rich rendering and additional file tools.

Configuration is stored in ~/.glm-cli/.env
Run 'glm-cli agent' to start - will prompt for API key on first run.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from rich.prompt import Prompt

from glm_cli.config import ensure_config, CONFIG_FILE
from glm_cli.richtext import console, markdown, panel
from glm_cli.richtext.formats import status_message

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

MAX_TOOL_OUTPUT = 50_000
TOOL_TIMEOUT = 120

SYSTEM_TEMPLATE = (
    "You are a coding agent at {cwd}. "
    "Use the available tools to solve tasks. "
    "Be concise and act rather than explain."
)

# ---------------------------------------------------------------------------
# Tool definitions (Anthropic tool schema)
# ---------------------------------------------------------------------------

TOOLS = [
    {
        "name": "bash",
        "description": "Run a shell command and return its output.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to run",
                }
            },
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read the contents of a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to read",
                }
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "Write content to a file, creating it if it doesn't exist.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to write",
                },
                "content": {
                    "type": "string",
                    "description": "The content to write",
                },
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "edit_file",
        "description": (
            "Edit a file by replacing an exact string with a new string. "
            "The old_string must match exactly (including whitespace)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to edit",
                },
                "old_string": {
                    "type": "string",
                    "description": "The exact text to find and replace",
                },
                "new_string": {
                    "type": "string",
                    "description": "The replacement text",
                },
            },
            "required": ["path", "old_string", "new_string"],
        },
    },
]

# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------

_DANGEROUS_PATTERNS = ["rm -rf /", "sudo", "shutdown", "reboot", "> /dev/sd"]


def _run_bash(command: str) -> str:
    """Execute a shell command and return its output."""
    if any(d in command for d in _DANGEROUS_PATTERNS):
        return "Error: Dangerous command blocked for safety"
    try:
        r = subprocess.run(
            command,
            shell=True,
            cwd=os.getcwd(),
            capture_output=True,
            text=True,
            timeout=TOOL_TIMEOUT,
        )
        out = (r.stdout + r.stderr).strip()
        if not out:
            return "(no output)"
        return out[:MAX_TOOL_OUTPUT]
    except subprocess.TimeoutExpired:
        return f"Error: Command timed out after {TOOL_TIMEOUT}s"


def _read_file(path: str) -> str:
    """Read and return file contents."""
    file_path = Path(path)
    if not file_path.exists():
        return f"Error: File not found: {path}"
    try:
        return file_path.read_text(encoding="utf-8")[:MAX_TOOL_OUTPUT]
    except Exception as e:
        return f"Error reading file: {e}"


def _write_file(path: str, content: str) -> str:
    """Write content to a file."""
    try:
        file_path = Path(path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return f"Successfully wrote {len(content)} characters to {path}"
    except Exception as e:
        return f"Error writing file: {e}"


def _edit_file(path: str, old_string: str, new_string: str) -> str:
    """Replace exact text in a file."""
    file_path = Path(path)
    if not file_path.exists():
        return f"Error: File not found: {path}"
    try:
        content = file_path.read_text(encoding="utf-8")
        count = content.count(old_string)
        if count == 0:
            return "Error: old_string not found in file"
        if count > 1:
            return f"Error: old_string found {count} times; it must be unique"
        new_content = content.replace(old_string, new_string, 1)
        file_path.write_text(new_content, encoding="utf-8")
        return f"Successfully edited {path}"
    except Exception as e:
        return f"Error editing file: {e}"


TOOL_HANDLERS = {
    "bash": _run_bash,
    "read_file": _read_file,
    "write_file": _write_file,
    "edit_file": _edit_file,
}

# ---------------------------------------------------------------------------
# Rich display helpers
# ---------------------------------------------------------------------------


def _display_banner() -> None:
    """Show the startup banner."""
    banner = panel(
        "[bold]GLM Code Agent[/bold]\n"
        "[dim]Beautiful CLI coding assistant[/dim]",
        title="[cyan]Agent[/cyan]",
        border_style="cyan",
    )
    console.print(banner)
    console.print()


def _rich_prompt(session: str = "agent") -> str:
    """Beautiful input prompt using Rich."""
    return Prompt.ask(f"[bold cyan]{session}[/bold cyan] >> ")


def _display_tool_call(name: str, tool_input: dict) -> None:
    """Display a tool invocation with styling."""
    if name == "bash":
        cmd = tool_input.get("command", "")
        console.print(f"  [yellow]  $[/yellow] [dim]{cmd}[/dim]")
    elif name == "read_file":
        p = tool_input.get("path", "")
        console.print(f"  [green]  read[/green] [dim]{p}[/dim]")
    elif name == "write_file":
        p = tool_input.get("path", "")
        size = len(tool_input.get("content", ""))
        console.print(f"  [green]  write[/green] [dim]{p}[/dim] [dim]({size} chars)[/dim]")
    elif name == "edit_file":
        p = tool_input.get("path", "")
        console.print(f"  [green]  edit[/green] [dim]{p}[/dim]")
    else:
        console.print(f"  [yellow]  {name}[/yellow]")


def _display_tool_output(name: str, output: str) -> None:
    """Display truncated tool output."""
    if len(output) > 300:
        lines = output.split("\n")
        shown = lines[:8]
        remaining = len(lines) - 8
        truncated = "\n".join(shown)
        console.print(f"  [dim]{truncated}[/dim]")
        if remaining > 0:
            console.print(f"  [dim]... ({remaining} more lines)[/dim]")
    else:
        for line in output.split("\n"):
            console.print(f"  [dim]{line}[/dim]")


def _display_response(content_blocks) -> None:
    """Render agent text response as markdown."""
    for block in content_blocks:
        if hasattr(block, "text") and block.text:
            console.print(markdown(block.text))
            console.print()


# ---------------------------------------------------------------------------
# Agent loop
# ---------------------------------------------------------------------------


def _init_client():
    """Initialize the Anthropic client from config."""
    # Ensure config is available (will prompt if needed)
    if not ensure_config():
        console.print(status_message("Configuration failed", "error"))
        raise SystemExit(1)

    # Config is now loaded into environment
    base_url = os.getenv("ANTHROPIC_BASE_URL")
    model = os.environ.get("MODEL_ID", "glm-4-plus")

    # Clear conflicting env var if using custom base URL
    if base_url:
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)

    try:
        from anthropic import Anthropic

        client = Anthropic(base_url=base_url) if base_url else Anthropic()
        return client, model
    except Exception as e:
        console.print(status_message(f"Failed to initialize client: {e}", "error"))
        raise SystemExit(1)


def _agent_loop(client, model: str, system: str, messages: list) -> None:
    """Run the core agent loop: call LLM, execute tools, repeat."""
    while True:
        try:
            response = client.messages.create(
                model=model,
                system=system,
                messages=messages,
                tools=TOOLS,
                max_tokens=8000,
            )
        except Exception as e:
            console.print(status_message(f"API error: {e}", "error"))
            return

        # Append assistant turn
        messages.append({"role": "assistant", "content": response.content})

        # If the model didn't call a tool, display the response and exit loop
        if response.stop_reason != "tool_use":
            _display_response(response.content)
            return

        # Execute each tool call, collect results
        results = []
        for block in response.content:
            if block.type == "tool_use":
                _display_tool_call(block.name, block.input)
                handler = TOOL_HANDLERS.get(block.name)
                if handler is None:
                    output = f"Error: Unknown tool '{block.name}'"
                else:
                    output = handler(**block.input)
                _display_tool_output(block.name, output)
                results.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": output,
                    }
                )
        messages.append({"role": "user", "content": results})


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run_agent(session: str = "agent") -> None:
    """Run the interactive rich agent loop."""
    client, model = _init_client()
    system = SYSTEM_TEMPLATE.format(cwd=os.getcwd())
    history: list = []

    _display_banner()

    while True:
        try:
            query = _rich_prompt(session)
        except (EOFError, KeyboardInterrupt):
            console.print(status_message("Goodbye!", "info"))
            break

        query = query.strip()
        if query.lower() in ("q", "exit", "quit"):
            console.print(status_message("Goodbye!", "info"))
            break
        if not query:
            continue

        history.append({"role": "user", "content": query})
        _agent_loop(client, model, system, history)


if __name__ == "__main__":
    run_agent()
