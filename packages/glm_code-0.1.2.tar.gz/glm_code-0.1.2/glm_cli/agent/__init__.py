"""Agent module - Rich agent loop with beautiful terminal output."""

from glm_cli.agent.rich_agent import run_agent

__all__ = ["run_agent"]
