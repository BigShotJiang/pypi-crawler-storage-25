"""CLI command handler for glm-cli.

This module provides command-line interface for the GLM RichText toolkit,
including demo execution, markdown rendering, code highlighting, and more.
"""

import argparse
import sys
from pathlib import Path
from glm_cli.richtext import console, markdown, code, panel
from glm_cli.richtext.demo import main as demo_main
from glm_cli.config import init_config_interactive, config_exists, CONFIG_FILE


VERSION = "0.1.3"


def cmd_demo(args):
    """Run the demo program."""
    if args.full:
        # Run full demo with all components
        demo_main()
    else:
        # Run quick demo
        console.print("\n")
        header = """
        ╔═══════════════════════════════════════════════════════╗
        ║                                                       ║
        ║        🎨 GLM RichText - Beautiful CLI Text          ║
        ║                                                       ║
        ╚═══════════════════════════════════════════════════════╝
        """
        console.print(header, style="bold cyan")

        md_content = """
# Quick Demo

Welcome to **GLM RichText**! This is a fast, elegant toolkit for beautiful terminal rendering.

## Features

- 📝 Markdown rendering
- 🎨 Syntax highlighting
- 📐 Custom layouts
- 🌈 Beautiful themes

### Try These Commands

```bash
glm-cli demo --full    # Full demo
glm-cli markdown FILE  # Render markdown
glm-cli code FILE      # Highlight code
```

> Run `glm-cli --help` for more information.
        """
        console.print(panel(markdown(md_content), title="✨ Quick Demo", border_style="blue"))
        console.print("\n[dim]For full demo, run: glm-cli demo --full[/dim]\n")


def cmd_markdown(args):
    """Render a markdown file."""
    if not args.file:
        console.print("[red]Error: Please specify a file to render[/red]")
        console.print("[dim]Usage: glm-cli markdown <file>[/dim]")
        sys.exit(1)

    file_path = Path(args.file)
    if not file_path.exists():
        console.print(f"[red]Error: File not found: {args.file}[/red]")
        sys.exit(1)

    try:
        content = file_path.read_text(encoding="utf-8")
        console.print(markdown(content))
    except Exception as e:
        console.print(f"[red]Error reading file: {e}[/red]")
        sys.exit(1)


def cmd_code(args):
    """Render a code file with syntax highlighting."""
    if not args.file:
        console.print("[red]Error: Please specify a file to render[/red]")
        console.print("[dim]Usage: glm-cli code <file> [--lang LANGUAGE][/dim]")
        sys.exit(1)

    file_path = Path(args.file)
    if not file_path.exists():
        console.print(f"[red]Error: File not found: {args.file}[/red]")
        sys.exit(1)

    try:
        content = file_path.read_text(encoding="utf-8")

        # Auto-detect language from extension if not specified
        if args.lang:
            lang = args.lang
        else:
            ext_map = {
                ".py": "python",
                ".js": "javascript",
                ".ts": "typescript",
                ".jsx": "jsx",
                ".tsx": "tsx",
                ".json": "json",
                ".yaml": "yaml",
                ".yml": "yaml",
                ".xml": "xml",
                ".html": "html",
                ".css": "css",
                ".scss": "scss",
                ".sh": "bash",
                ".bash": "bash",
                ".zsh": "zsh",
                ".fish": "fish",
                ".rs": "rust",
                ".go": "go",
                ".java": "java",
                ".c": "c",
                ".cpp": "cpp",
                ".h": "c",
                ".hpp": "cpp",
                ".cs": "csharp",
                ".php": "php",
                ".rb": "ruby",
                ".kt": "kotlin",
                ".swift": "swift",
                ".sql": "sql",
                ".md": "markdown",
                ".toml": "toml",
                ".ini": "ini",
                ".cfg": "ini",
            }
            lang = ext_map.get(file_path.suffix.lower(), "text")

        console.print(code(content, lang))
    except Exception as e:
        console.print(f"[red]Error reading file: {e}[/red]")
        sys.exit(1)


def cmd_agent(args):
    """Run the interactive rich agent loop."""
    try:
        from glm_cli.agent import run_agent
    except ImportError:
        console.print(
            "[red]Error: Agent dependencies not installed.[/red]\n"
            "[dim]Install with: pip install glm-code[agent][/dim]"
        )
        sys.exit(1)
    run_agent(session=args.session)


def cmd_version(args):
    """Show version information."""
    console.print(f"[bold cyan]glm-cli[/bold cyan] version [bold green]{VERSION}[/bold green]")
    console.print("\n[dim]A beautiful rich text rendering toolkit for CLI applications[/dim]")


def cmd_init(args):
    """Initialize or update configuration."""
    if config_exists() and not args.force:
        console.print(f"[green]✓[/green] Configuration already exists at [dim]{CONFIG_FILE}[/dim]")
        console.print("[dim]Use --force to reconfigure[/dim]")
        return

    if init_config_interactive():
        console.print("[green]✓[/green] Configuration complete!")
    else:
        console.print("[red]Configuration cancelled[/red]")
        sys.exit(1)


def render_main():
    """Entry point for glm-render command (direct rendering for pipe usage).

    This reads from stdin and renders as markdown by default,
    suitable for shell pipe usage like: cat file.md | glm-render
    """
    import sys

    content = sys.stdin.read()
    if content.strip():
        console.print(markdown(content))


def main():
    """Main entry point for glm-cli command."""
    parser = argparse.ArgumentParser(
        prog="glm-cli",
        description="A beautiful rich text rendering toolkit for CLI applications",
    )

    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run the demo program")
    demo_parser.add_argument(
        "--full", "-f", action="store_true", help="Run full demo with all components"
    )
    demo_parser.set_defaults(func=cmd_demo)

    # Markdown command
    md_parser = subparsers.add_parser("markdown", help="Render a markdown file")
    md_parser.add_argument("file", nargs="?", help="Path to markdown file")
    md_parser.set_defaults(func=cmd_markdown)

    # Code command
    code_parser = subparsers.add_parser("code", help="Render code with syntax highlighting")
    code_parser.add_argument("file", nargs="?", help="Path to code file")
    code_parser.add_argument(
        "--lang", "-l", help="Language for syntax highlighting (auto-detected if not specified)"
    )
    code_parser.set_defaults(func=cmd_code)

    # Version command
    version_parser = subparsers.add_parser("version", help="Show version information")
    version_parser.set_defaults(func=cmd_version)

    # Agent command
    agent_parser = subparsers.add_parser("agent", help="Run the interactive coding agent")
    agent_parser.add_argument(
        "--session", "-s", default="agent", help="Session name for the prompt (default: agent)"
    )
    agent_parser.set_defaults(func=cmd_agent)

    # Init command
    init_parser = subparsers.add_parser("init", help="Initialize or update API configuration")
    init_parser.add_argument(
        "--force", "-f", action="store_true", help="Force reconfiguration even if config exists"
    )
    init_parser.set_defaults(func=cmd_init)

    # Parse arguments
    args = parser.parse_args()

    # If no command specified, run agent
    if args.command is None:
        args = argparse.Namespace(func=cmd_agent, session="agent")

    # Execute the command
    args.func(args)


if __name__ == "__main__":
    main()
