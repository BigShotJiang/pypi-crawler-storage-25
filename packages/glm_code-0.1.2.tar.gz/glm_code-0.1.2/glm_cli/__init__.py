"""GLM CLI - Beautiful Rich Text Rendering Toolkit."""

__version__ = "0.1.0"