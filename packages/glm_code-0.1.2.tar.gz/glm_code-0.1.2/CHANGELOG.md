# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- CLI entry points (`glm-cli` and `glm-render` commands)
- One-click installation script (`install.sh`)
- Publishing guide (`PUBLISHING.md`)

## [0.1.0] - 2024-03-31

### Added
- Initial release
- Beautiful Markdown rendering with syntax highlighting
- Code highlighting with custom themes
- Panel layouts and structured content
- Table rendering with Rich formatting
- Status messages (success, warning, error)
- Custom layouts (bullet columns, labeled sections, grid, progress steps)
- Console helpers with pre-configured themes

[Unreleased]: https://github.com/user/glm-cli/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/user/glm-cli/releases/tag/v0.1.0
