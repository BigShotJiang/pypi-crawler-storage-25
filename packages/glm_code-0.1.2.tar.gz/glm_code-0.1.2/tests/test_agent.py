"""Tests for the rich agent module."""

import os
import tempfile
from unittest.mock import MagicMock

from dotenv import load_dotenv

load_dotenv(override=True)

if os.getenv("ANTHROPIC_BASE_URL"):
    os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)


# ---------------------------------------------------------------------------
# Display tests
# ---------------------------------------------------------------------------


def test_display_response_with_text():
    """_display_response should print text from content blocks."""
    from glm_cli.agent.rich_agent import _display_response

    block = MagicMock()
    block.text = "你好！有什么可以帮你的？"
    _display_response([block])


def test_display_response_empty():
    """_display_response should skip empty/None text."""
    from glm_cli.agent.rich_agent import _display_response

    block = MagicMock()
    block.text = ""
    _display_response([block])

    block.text = None
    _display_response([block])


def test_display_response_markdown():
    """_display_response should render markdown formatting."""
    from glm_cli.agent.rich_agent import _display_response

    block = MagicMock()
    block.text = "Hello\n\n- item 1\n- item 2"
    _display_response([block])


def test_display_tool_call_bash():
    """_display_tool_call should show bash command."""
    from glm_cli.agent.rich_agent import _display_tool_call

    _display_tool_call("bash", {"command": "ls -la"})


def test_display_tool_call_read_file():
    """_display_tool_call should show file path for read."""
    from glm_cli.agent.rich_agent import _display_tool_call

    _display_tool_call("read_file", {"path": "/tmp/test.txt"})


def test_display_tool_call_write_file():
    """_display_tool_call should show path and size for write."""
    from glm_cli.agent.rich_agent import _display_tool_call

    _display_tool_call("write_file", {"path": "/tmp/test.txt", "content": "hello"})


def test_display_tool_call_edit_file():
    """_display_tool_call should show path for edit."""
    from glm_cli.agent.rich_agent import _display_tool_call

    _display_tool_call("edit_file", {"path": "/tmp/test.txt", "old_string": "a", "new_string": "b"})


def test_display_tool_output_short():
    """_display_tool_output should show short output."""
    from glm_cli.agent.rich_agent import _display_tool_output

    _display_tool_output("bash", "hello world")


def test_display_tool_output_long():
    """_display_tool_output should truncate long output."""
    from glm_cli.agent.rich_agent import _display_tool_output

    lines = [f"line {i}" for i in range(20)]
    long_output = "\n".join(lines)
    _display_tool_output("bash", long_output)


# ---------------------------------------------------------------------------
# Tool handler tests
# ---------------------------------------------------------------------------


def test_bash_echo():
    """bash handler should execute command."""
    from glm_cli.agent.rich_agent import _run_bash

    output = _run_bash("echo hello")
    assert "hello" in output


def test_bash_no_output():
    """bash handler should handle empty output."""
    from glm_cli.agent.rich_agent import _run_bash

    output = _run_bash("true")
    assert "no output" in output or output == ""


def test_bash_dangerous():
    """bash handler should block dangerous commands."""
    from glm_cli.agent.rich_agent import _run_bash

    assert "blocked" in _run_bash("sudo rm -rf /").lower()
    assert "blocked" in _run_bash("shutdown now").lower()


def test_read_file():
    """read_file handler should return file contents."""
    from glm_cli.agent.rich_agent import _read_file

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("hello world")
        f.flush()
        assert _read_file(f.name) == "hello world"


def test_read_file_not_found():
    """read_file handler should return error for missing file."""
    from glm_cli.agent.rich_agent import _read_file

    assert "Error" in _read_file("/nonexistent/file.txt")


def test_write_file():
    """write_file handler should write content to file."""
    from glm_cli.agent.rich_agent import _write_file

    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "test.txt")
        result = _write_file(path, "test content")
        assert "Successfully" in result
        with open(path) as f:
            assert f.read() == "test content"


def test_write_file_creates_dirs():
    """write_file handler should create parent directories."""
    from glm_cli.agent.rich_agent import _write_file

    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "subdir", "test.txt")
        result = _write_file(path, "nested content")
        assert "Successfully" in result
        assert os.path.exists(path)


def test_edit_file():
    """edit_file handler should replace text in file."""
    from glm_cli.agent.rich_agent import _edit_file

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("hello world")
        f.flush()
        result = _edit_file(f.name, "hello", "goodbye")
        assert "Successfully" in result
        with open(f.name) as rf:
            assert rf.read() == "goodbye world"


def test_edit_file_not_unique():
    """edit_file should fail if old_string is not unique."""
    from glm_cli.agent.rich_agent import _edit_file

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("aaa bbb aaa")
        f.flush()
        result = _edit_file(f.name, "aaa", "ccc")
        assert "2 times" in result


def test_edit_file_string_not_found():
    """edit_file should fail if old_string not in file."""
    from glm_cli.agent.rich_agent import _edit_file

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("hello")
        f.flush()
        result = _edit_file(f.name, "xyz", "abc")
        assert "not found" in result


def test_edit_file_not_found():
    """edit_file should fail if file doesn't exist."""
    from glm_cli.agent.rich_agent import _edit_file

    result = _edit_file("/nonexistent/file.txt", "a", "b")
    assert "Error" in result


# ---------------------------------------------------------------------------
# API tests (require network)
# ---------------------------------------------------------------------------


def test_api_simple():
    """Test basic API call."""
    from anthropic import Anthropic

    base_url = os.getenv("ANTHROPIC_BASE_URL")
    model = os.environ.get("MODEL_ID", "glm-5")

    client = Anthropic(base_url=base_url)
    response = client.messages.create(
        model=model,
        max_tokens=256,
        messages=[{"role": "user", "content": "回复OK"}],
    )

    assert response.stop_reason == "end_turn"
    assert len(response.content) > 0
    assert response.content[0].text


def test_api_tool_use():
    """Test API call that triggers tool use."""
    from anthropic import Anthropic
    from glm_cli.agent.rich_agent import TOOLS

    base_url = os.getenv("ANTHROPIC_BASE_URL")
    model = os.environ.get("MODEL_ID", "glm-5")

    client = Anthropic(base_url=base_url)
    response = client.messages.create(
        model=model,
        max_tokens=256,
        messages=[{"role": "user", "content": "列出当前目录文件"}],
        tools=TOOLS,
    )

    assert response.stop_reason == "tool_use"
    tool_blocks = [b for b in response.content if b.type == "tool_use"]
    assert len(tool_blocks) > 0
    assert tool_blocks[0].name == "bash"


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import traceback

    tests = [
        test_display_response_with_text,
        test_display_response_empty,
        test_display_response_markdown,
        test_display_tool_call_bash,
        test_display_tool_call_read_file,
        test_display_tool_call_write_file,
        test_display_tool_call_edit_file,
        test_display_tool_output_short,
        test_display_tool_output_long,
        test_bash_echo,
        test_bash_no_output,
        test_bash_dangerous,
        test_read_file,
        test_read_file_not_found,
        test_write_file,
        test_write_file_creates_dirs,
        test_edit_file,
        test_edit_file_not_unique,
        test_edit_file_string_not_found,
        # test_api_simple,      # requires network
        # test_api_tool_use,   # requires network
    ]

    passed = 0
    failed = 0
    for t in tests:
        name = t.__name__
        try:
            t()
            print(f"  PASS  {name}")
            passed += 1
        except Exception as e:
            print(f"  FAIL  {name}: {e}")
            traceback.print_exc()
            failed += 1

    print(f"\n{passed} passed, {failed} failed")
