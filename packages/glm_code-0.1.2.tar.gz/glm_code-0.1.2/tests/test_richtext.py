"""Tests for GLM RichText toolkit."""

import pytest
from glm_cli.richtext.formats import Code, Markdown, StatusMessage, Table
from glm_cli.richtext.custom import BulletColumns, LabeledSection
from rich.text import Text


def test_code_creation():
    """Test Code renderable creation."""
    code_obj = Code("print('hello')", "python")
    assert code_obj.code == "print('hello')"
    assert code_obj.lexer == "python"
    assert code_obj.word_wrap is True


def test_markdown_creation():
    """Test Markdown renderable creation."""
    md = Markdown("# Hello\n\nThis is **bold**.")
    assert md.markup == "# Hello\n\nThis is **bold**."
    assert md.justify is None
    assert md.hyperlinks is True


def test_table_creation():
    """Test Table renderable creation."""
    table = Table(["A", "B"], [["1", "2"]])
    assert table.headers == ["A", "B"]
    assert table.rows == [["1", "2"]]


def test_status_message():
    """Test StatusMessage creation."""
    msg = StatusMessage("Test message", "success")
    assert msg.message == "Test message"
    assert msg.status == "success"
    assert msg.icon == "✓"
    assert msg.color == "green"


def test_bullet_columns():
    """Test BulletColumns creation."""
    text = Text("Test content")
    bullets = BulletColumns(text)
    assert bullets._renderable == text
    assert bullets._padding == 1


def test_labeled_section():
    """Test LabeledSection creation."""
    content = Text("Content here")
    section = LabeledSection("Label", content)
    assert section.label == "Label"
    assert section.content == content


if __name__ == "__main__":
    pytest.main([__file__, "-v"])