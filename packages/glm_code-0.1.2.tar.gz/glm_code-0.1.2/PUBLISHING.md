# 发布指南

本文档描述如何将 glm-cli 发布到 PyPI。

## 前置准备

### 1. 安装发布工具

```bash
pip install build twine
```

### 2. PyPI 账号

1. 注册 [PyPI 账号](https://pypi.org/account/register/)
2. 开启两步验证（推荐）
3. 创建 [API Token](https://pypi.org/manage/account/token/)
   - Scope: Entire account (所有项目)
   - 保存 Token，只显示一次

### 3. TestPyPI 账号（可选，用于测试）

1. 注册 [TestPyPI 账号](https://test.pypi.org/account/register/)
2. 同样创建 API Token

## 发布流程

### 步骤 1: 更新版本号

编辑 `pyproject.toml` 中的版本号：

```toml
version = "0.1.0"  # 改为新版本，如 "0.1.1" 或 "0.2.0"
```

遵循 [语义化版本](https://semver.org/lang/zh-CN/)：
- **主版本号**: 不兼容的 API 修改
- **次版本号**: 向下兼容的功能新增
- **修订号**: 向下兼容的问题修正

### 步骤 2: 更新 CHANGELOG（推荐）

记录本次版本的变更内容。

### 步骤 3: 构建分发包

```bash
# 清理旧的构建文件
rm -rf dist/ build/ *.egg-info

# 构建
python -m build
```

构建完成后，`dist/` 目录包含：
- `glm_cli-0.1.0-py3-none-any.whl` - Wheel 包
- `glm-cli-0.1.0.tar.gz` - 源码包

### 步骤 4: 检查包

```bash
# 检查包的元数据是否正确
twine check dist/*
```

### 步骤 5: 上传到 TestPyPI（推荐先测试）

```bash
twine upload --repository testpypi dist/*
```

提示输入时：
- Username: `__token__`
- Password: 你的 TestPyPI API Token

测试安装：
```bash
pip install --index-url https://test.pypi.org/simple/ glm-cli
```

### 步骤 6: 上传到 PyPI

```bash
twine upload dist/*
```

提示输入时：
- Username: `__token__`
- Password: 你的 PyPI API Token

### 步骤 7: 验证发布

```bash
# 等待几分钟后
pipx install glm-cli

# 或
pip install glm-cli

# 测试
glm-cli version
```

## 自动化发布（可选）

### 使用 GitHub Actions

创建 `.github/workflows/publish.yml`：

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.10'

      - name: Install build tools
        run: |
          pip install build twine

      - name: Build package
        run: python -m build

      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: twine upload dist/*
```

配置步骤：
1. 在 GitHub 仓库的 Settings > Secrets and variables > Actions
2. 添加 `PYPI_API_TOKEN` secret，值为你的 PyPI API Token
3. 在 GitHub 创建 Release 时会自动发布到 PyPI

## 常见问题

### 包名已被占用

如果 `glm-cli` 已被他人注册，需要：
1. 修改 `pyproject.toml` 中的 `name`
2. 考虑使用其他名称，如 `glm-cli-tool`、`glm-richtext` 等

### 上传失败

```bash
# 检查版本号是否已存在
# PyPI 不允许覆盖已发布的版本

# 如果是新版本，确保更新了 pyproject.toml 中的版本号
```

### 本地测试安装

```bash
# 从本地源码安装
pip install -e .

# 从构建的 wheel 安装
pip install dist/glm_cli-0.1.0-py3-none-any.whl
```

## 发布检查清单

- [ ] 更新版本号 (`pyproject.toml`)
- [ ] 更新 CHANGELOG
- [ ] 运行测试 (`pytest tests/`)
- [ ] 清理旧构建文件 (`rm -rf dist/ build/`)
- [ ] 构建包 (`python -m build`)
- [ ] 检查包 (`twine check dist/*`)
- [ ] 测试上传到 TestPyPI（可选）
- [ ] 上传到 PyPI
- [ ] 验证安装
- [ ] 创建 Git tag (`git tag v0.1.0 && git push --tags`)
- [ ] 创建 GitHub Release
