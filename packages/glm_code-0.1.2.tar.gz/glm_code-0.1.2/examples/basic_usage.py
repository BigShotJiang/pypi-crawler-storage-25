"""Basic usage examples for GLM RichText.

These examples show the most common use cases for the richtext toolkit.
"""

from glm_cli.richtext import console
from glm_cli.richtext.formats import code, markdown, panel, status_message, table


def example_1_simple_text():
    """Example 1: Simple markdown text."""
    console.print("\n[bold cyan]Example 1: Simple Markdown[/bold cyan]\n")

    text = markdown("""
# Welcome

This is **bold** and this is *italic*.

You can also use `inline code`!
    """)
    console.print(text)


def example_2_code_highlighting():
    """Example 2: Syntax highlighted code."""
    console.print("\n[bold cyan]Example 2: Code Highlighting[/bold cyan]\n")

    python_code = '''
def fibonacci(n: int) -> int:
    """Calculate the nth Fibonacci number."""
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
'''
    console.print(code(python_code, "python"))


def example_3_panels():
    """Example 3: Panels with content."""
    console.print("\n[bold cyan]Example 3: Panels[/bold cyan]\n")

    content = markdown("""
## Important Notice

This is a **panel** with a title and border.
Great for highlighting important information!
    """)
    console.print(panel(content, title="📌 Notice", border_style="yellow"))


def example_4_tables():
    """Example 4: Formatted tables."""
    console.print("\n[bold cyan]Example 4: Tables[/bold cyan]\n")

    headers = ["Name", "Age", "City"]
    rows = [
        ["Alice", "28", "New York"],
        ["Bob", "32", "San Francisco"],
        ["Charlie", "25", "Seattle"],
    ]
    console.print(table(headers, rows))


def example_5_status_messages():
    """Example 5: Status messages."""
    console.print("\n[bold cyan]Example 5: Status Messages[/bold cyan]\n")

    console.print(status_message("Success! Operation completed.", "success"))
    console.print(status_message("Warning! Check your input.", "warning"))
    console.print(status_message("Error! Something went wrong.", "error"))


def main():
    """Run all examples."""
    console.print("\n[bold green]╔════════════════════════════════════════╗[/bold green]")
    console.print("[bold green]║     GLM RichText - Basic Usage        ║[/bold green]")
    console.print("[bold green]╚════════════════════════════════════════╝[/bold green]")

    example_1_simple_text()
    example_2_code_highlighting()
    example_3_panels()
    example_4_tables()
    example_5_status_messages()

    console.print("\n[dim]For more examples, run: python -m glm_cli.richtext.demo[/dim]\n")


if __name__ == "__main__":
    main()