# GLM RichText

> 🎨 一个美观优雅的命令行文本渲染工具包，灵感来自 kimi-cli

GLM RichText 是一个专为 CLI 应用设计的富文本渲染工具包，提供美观优雅的终端文本输出。

## ✨ 特性

- **📝 美观的 Markdown 渲染** - 完整的 Markdown 支持，带语法高亮
- **🎨 自定义语法主题** - 精心设计的代码高亮配色方案
- **📐 优雅的布局组件** - 项目符号列表、标签区域、网格布局等
- **🔍 差异渲染** - 带内联高亮的精美 diff 显示
- **🖥️ Console 集成** - 开箱即用的控制台助手函数
- **🎯 简洁的 API** - 简单直观的接口设计
- **🤖 RichAgent** - 美观终端输出的 AI 编码代理

## 📦 安装

### 一键安装（推荐）

```bash
curl -sSL https://dev.aminer.cn/wudao/glm-cli/-/raw/main/install.sh | bash
```

### 其他安装方式

**使用 pipx（推荐用于 CLI 工具）**
```bash
pipx install glm-code
```

**使用 pip**
```bash
pip install --user glm-code
```

**从源码安装**
```bash
git clone <repo-url>
cd glm-cli
pip install -e .
```

**开发模式安装**
```bash
# 克隆项目
git clone <repo-url>
cd glm-cli

# 创建虚拟环境
python3 -m venv .venv
source .venv/bin/activate

# 安装依赖
pip install -e .
```

## 🚀 快速开始

### CLI 命令使用

安装后，可以直接使用 `glm-code` 命令：

```bash
# 运行演示
glm-code                    # 快速演示
glm-code demo               # 同上
glm-code demo --full        # 完整演示（所有组件）

# 渲染文件
glm-code markdown README.md # 渲染 Markdown 文件
glm-code code script.py     # 渲染代码文件（自动检测语言）
glm-code code main.rs --lang rust  # 指定语言

# 管道使用
cat README.md | glm-render  # 从 stdin 渲染 Markdown

# 查看版本
glm-code version
```

### Python 库使用

```python
from glm_cli.richtext import console, markdown, code, panel

# 渲染 Markdown
text = """
# Hello, World!

这是 **粗体** 和 *斜体* 文本。

## 代码示例

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"
```
"""
console.print(markdown(text))

# 渲染代码
console.print(code("print('Hello')", "python"))

# 渲染面板
console.print(panel("重要内容", title="提示"))
```

## 🤖 RichAgent - AI 编码代理

RichAgent 是一个基于 GLM API（兼容 Anthropic）的 AI 编码代理，具有美观的终端输出。

### 功能特点

- **工具调用支持** - 内置 `bash`、`read_file`、`write_file`、`edit_file` 工具
- **美观输出** - 使用 glm-cli richtext 库渲染工具调用和响应
- **交互式 REPL** - 持续对话的命令行界面
- **安全机制** - 自动拦截危险命令（如 `rm -rf /`、`sudo` 等）
- **自动配置** - 首次运行自动引导配置 API Key

### 快速配置

```bash
# 首次使用，初始化配置
glm-code init

# 或强制重新配置
glm-code init --force
```

配置文件保存在 `~/.glm-cli/.env`，包含：
- `ANTHROPIC_API_KEY` - API 密钥（从 https://open.bigmodel.cn/ 获取）
- `ANTHROPIC_BASE_URL` - API 地址（默认：https://open.bigmodel.cn/api/paas/v4/）
- `MODEL_ID` - 模型名称（默认：glm-4-plus）

### 运行代理

```bash
# 运行交互式代理
glm-code agent

# 指定会话名称
glm-code agent --session my-project
```

### 使用示例

```
╔═══════════════════════════════════════════════════════╗
║                    [cyan]Agent[/cyan]                    ║
║           GLM Code Agent                              ║
║       Beautiful CLI coding assistant                  ║
╚═══════════════════════════════════════════════════════╝

agent >> 帮我创建一个 hello.py 文件
  $ [dim]write hello.py[/dim] [dim](50 chars)[/dim]
  [dim]Successfully wrote 50 characters to hello.py[/dim]

已创建 hello.py 文件，内容如下...
```

### 可用工具

| 工具 | 描述 |
|------|------|
| `bash` | 执行 shell 命令 |
| `read_file` | 读取文件内容 |
| `write_file` | 写入文件（自动创建目录） |
| `edit_file` | 精确替换文件中的文本 |

## 📚 文档

详细文档请查看：

- [快速入门指南](docs/getting_started.md) - 新手友好的入门教程
- [API 文档](docs/api.md) - 完整的 API 参考

## 🎭 示例

### 运行演示

```bash
# 完整功能演示
python -m glm_cli.richtext.demo

# 基础示例
python examples/basic_usage.py
```

### 代码高亮

```python
from glm_cli.richtext import console, code

python_code = '''
from typing import List

class Processor:
    def process(self, items: List[str]) -> List[str]:
        return [item.upper() for item in items]
'''

console.print(code(python_code, "python"))
```

### 表格

```python
from glm_cli.richtext import console, table

headers = ["服务", "状态", "版本"]
rows = [
    ["API", "运行中", "1.0"],
    ["数据库", "运行中", "2.1"],
    ["缓存", "运行中", "3.5"],
]
console.print(table(headers, rows))
```

### 状态消息

```python
from glm_cli.richtext import console, status_message

console.print(status_message("操作成功！", "success"))
console.print(status_message("请注意...", "warning"))
console.print(status_message("出错了！", "error"))
```

## 🎨 预览

运行演示程序可以看到各种组件的效果：

```
╔═══════════════════════════════════════════════════════╗
║        🎨 GLM RichText - Beautiful CLI Text          ║
║   A toolkit for elegant terminal text rendering      ║
╚═══════════════════════════════════════════════════════╝
```

## 📁 项目结构

```
glm-cli/
├── glm_cli/
│   ├── richtext/          # 核心工具包
│   │   ├── __init__.py    # 主入口
│   │   ├── console.py     # Console 配置
│   │   ├── themes.py      # 颜色主题
│   │   ├── formats.py     # 格式化组件
│   │   ├── markdown.py    # Markdown 渲染器
│   │   ├── custom.py      # 自定义布局
│   │   └── demo.py        # 演示程序
│   └── agent/             # AI 代理模块
│       ├── __init__.py    # 模块入口
│       └── rich_agent.py  # RichAgent 实现
├── examples/              # 示例代码
├── tests/                 # 测试文件
├── docs/                  # 文档
└── pyproject.toml         # 项目配置
```

## 🧪 测试

```bash
# 运行测试
pytest tests/

# 带覆盖率
pytest tests/ --cov=glm_cli/richtext
```

## 🔧 故障排除

### 命令未找到

如果安装后 `glm-code` 命令未找到，可能需要将用户 bin 目录添加到 PATH：

```bash
# 查看用户 bin 目录
python3 -m site --user-base

# 添加到 PATH（将输出路径的 /bin 子目录添加）
# 例如：export PATH="$HOME/.local/bin:$PATH"

# 添加到 shell 配置文件（~/.bashrc 或 ~/.zshrc）
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

### Python 版本要求

需要 Python 3.10 或更高版本。检查版本：

```bash
python3 --version
```

### 升级到最新版本

```bash
# 使用 pipx
pipx upgrade glm-code

# 使用 pip
pip install --upgrade glm-code
```

## 🤝 贡献

欢迎提交 Pull Request 或创建 Issue！

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 🙏 致谢

本项目灵感来自 [kimi-cli](https://github.com/moonshot-kimiauto/kimi-cli) 的 rich text 渲染实现。

---

**Made with ❤️ for beautiful CLI applications**