# BrowserTrace Owner Next Actions

This is the shortest owner-facing checklist. Use it when the repo is ready and
the owner can perform account/login actions personally.

Chinese version: `docs/launch/owner-next-actions.zh-CN.md`

Do not ask for stars, upvotes, reposts, vote swaps, or artificial engagement.
Ask for workflow feedback from people building browser agents.

## 10-Minute Owner Unblock

If you only have one short session, do these in order and let Codex handle the
follow-up verification, README updates, metrics, and issue comments:

1. Publish the Day 1 X/LinkedIn/WeChat/Jike posts from
   `docs/launch/day-1-publish-packet.md`, using `docs/demo.mp4`.
2. Send the ready owner-email submissions from
   `docs/launch/directory-submission-sheet.md`:
   `hello@console.dev` and `agdex.ai@gmail.com` for console.dev and AgDex.
3. If you have a second short pass, submit the browser-form directories from
   `docs/launch/directory-submission-sheet.md`:
   AgentKart, OSS AI Hub, FOSSHUNTER, AgentsTide, and BuilderAI Tools. Use
   `hello@agentstide.com` as the AgentsTide email fallback and
   `AI Observability & Evaluation` for BuilderAI Tools.
4. If that batch is already done, use the second-pass directory field notes in
   `docs/launch/directory-submission-sheet.md` for CLIHunt, DeepYard,
   OpenAgent.bot, ForgeIndex, and AgentShelf.
5. If you still have time for developer-tool directories, use the same sheet for
   CLIs.dev, DevTool Center, ToolHunter, and ToolShelf.

Send the posted URLs, email-sent note, or any replies so Codex can log metrics
and update the tracking issues.

Fast copy/paste blocks:

- X: `docs/launch/channel-copy.md#x`
- X follow-up: `docs/launch/channel-copy.md#x-follow-up`
- LinkedIn: `docs/launch/channel-copy.md#linkedin`
- WeChat group: `docs/launch/channel-copy.md#wechat-group`
- Jike: `docs/launch/channel-copy.md#jike`
- Show HN: `docs/launch/day-2-show-hn-packet.md#first-comment-draft`
- Product Hunt: `docs/launch/day-4-product-hunt-packet.md#maker-comment`
- console.dev email:
  `docs/launch/directory-submission-sheet.md#consoledev-email-draft`
- AgDex email: `docs/launch/directory-submission-sheet.md#agdex-email-draft`

## 1. PyPI Published

PyPI is no longer the install blocker. BrowserTrace is published as version
`0.1.17`:

```text
https://pypi.org/project/browsertrace/
https://pypi.org/pypi/browsertrace/json -> HTTP 200
```

Use this install command in public posts:

```bash
pip install "browsertrace[ui]"
```

The no-install PyPI trial path is:

```bash
uvx --from "browsertrace[ui]" browsertrace doctor
uvx --from "browsertrace[ui]" browsertrace demo
uvx --from "browsertrace[ui]" browsertrace list
uvx --from "browsertrace[ui]" browsertrace
```

Publish verification completed:

```bash
uv venv --python 3.11 --seed /tmp/browsertrace-pypi-verify
/tmp/browsertrace-pypi-verify/bin/python -m pip index versions browsertrace
/tmp/browsertrace-pypi-verify/bin/python -m pip install "browsertrace[ui]"
/tmp/browsertrace-pypi-verify/bin/browsertrace --help
uvx --python 3.11 --from "browsertrace[ui]" browsertrace doctor --json
```

Tracking issue: https://github.com/aaronlab/browsertrace/issues/5

## 2. Maintain The GitHub Profile README

The live public profile README repo is `aaronlab/aaronlab`. Do not use the old
profile redirect in launch copy.

Use this source draft when refreshing the profile README:

```text
docs/launch/github-profile-readme.md
```

Keep BrowserTrace as the first featured project during launch.

Profile pin: completed. GraphQL now shows `aaronlab/browsertrace` in the
public profile pinned repositories.

Tracking issue: https://github.com/aaronlab/browsertrace/issues/13

## 3. GitHub Social Preview

Social preview: completed. GitHub now reports
`usesCustomOpenGraphImage=true` for `aaronlab/browsertrace`.

Keep the reusable asset here for future launches, Product Hunt galleries, and
manual link-preview checks:

```text
docs/social-preview.png
```

## 4. Submit The Sitemap To Search Consoles

Search indexing is a slower growth channel, but it compounds after launch. The
sitemap and robots file are already live:

```text
https://aaronlab.github.io/browsertrace/sitemap.xml
https://aaronlab.github.io/browsertrace/robots.txt
```

Use:

```text
docs/launch/search-indexing-submission.md
```

Tracking issue: https://github.com/aaronlab/browsertrace/issues/16

## 5. Publish Day 1 Posts

Use this packet:

```text
docs/launch/day-1-publish-packet.md
```

Recommended order:

1. X
2. LinkedIn
3. One or two relevant WeChat AI-builder groups
4. Jike

Use `docs/demo.mp4` as primary media and `docs/demo-poster.png` as backup.

Tracking issue: https://github.com/aaronlab/browsertrace/issues/9

## 6. Submit Directories And Newsletters

Use:

```text
docs/launch/directory-submission-sheet.md
docs/launch/outreach-targets.md
```

Submit once per target. Do not repeatedly submit or ask for votes.

Tracking issue: https://github.com/aaronlab/browsertrace/issues/10

## 7. Monitor High-Fit GitHub Awesome List PRs

Use:

```text
docs/launch/github-awesome-list-submissions.md
```

Current open high-fit PRs:

- `bradvin/agentfirst.directory#30` - enrichment check passed.
- `angrykoala/awesome-browser-automation#112`
- `mxschmitt/awesome-playwright#136`
- `Jenqyang/Awesome-AI-Agents#220`
- `wjhou/awesome-computer-use-agents#2`
- `cdxeve/awesome-computer-use-agents#2`
- `steel-dev/awesome-web-agents#56`
- `ai-boost/awesome-harness-engineering#23`
- `Agent-Tools/awesome-autonomous-web#21`
- `e2b-dev/awesome-ai-sdks#187` - E2B CLA check has passed; monitor
  maintainer feedback.
- `jim-schwoebel/awesome_ai_agents#266`
- `ranpox/awesome-computer-use#24`

Monitor maintainer feedback and do not open additional list PRs unless a target
is clearly high-fit and non-duplicative. Respond only when maintainers request
changes.

Tracking issue: https://github.com/aaronlab/browsertrace/issues/18

## Reply To Contribution Questions

If someone asks how to make a small docs fix, point to the current good first
issue:
https://github.com/aaronlab/browsertrace/labels/good%20first%20issue

Then share the First PR Recipe:
https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe keeps the first contribution small and reviewable.

If someone says they want to work on it, acknowledge it and leave a short claim window
before implementing it yourself. If that issue is already finished,
point them to the good first issue label instead of letting the thread stall.

## Reply To Troubleshooting Questions

For local first-run issues, CI failures, or AI/coding-agent troubleshooting replies, ask for debugging/workflow details plus JSON CLI diagnostics when safe to share:

For security-sensitive reports or changes, or anything that includes private trace data, point people to the private path in the Security Policy before they share details publicly:
https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md

```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```

## 8. Record Metrics After Each Action

After every public post, profile update, PyPI publish, or directory submission:

```bash
uv run --python 3.11 python scripts/launch_metrics.py --append --note "after <action>: <URL or note>"
uv run --python 3.11 python scripts/launch_metrics.py --json
```

The goal remains incomplete until GitHub reports more than 1000 stars:

```bash
gh repo view aaronlab/browsertrace --json stargazerCount,forkCount,watchers,url,homepageUrl
```
