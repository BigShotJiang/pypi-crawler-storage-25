# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the Cryptographic Receipt Validator.

All tests construct real ``OracleExecutionReceipt`` Pydantic objects
from ``coreason-manifest``, ensuring type-safe cross-package binding.
"""

from __future__ import annotations

import pytest
from coreason_manifest.spec.ontology import OracleExecutionReceipt
from pydantic import ValidationError

from coreason_urn_authority.crypto.validator import (
    ThermodynamicQuota,
    validate_receipt,
)

_CLAW_URN = "urn:coreason:solver:claw_developer:v1"
_VALID_HASH = "a" * 64


def _make_receipt(
    execution_hash: str = _VALID_HASH,
    solver_urn: str = _CLAW_URN,
    tokens_burned: int = 100,
) -> OracleExecutionReceipt:
    """Helper to construct a valid OracleExecutionReceipt."""
    return OracleExecutionReceipt(
        execution_hash=execution_hash,
        solver_urn=solver_urn,
        tokens_burned=tokens_burned,
    )


class TestExecutionHashValidation:
    """Rule 1: execution_hash must be exactly 64 lowercase hex chars.

    Note: Pydantic's own regex constraint on OracleExecutionReceipt.execution_hash
    (``^[a-f0-9]{64}$``) enforces this at construction time, so invalid hashes
    cannot even be instantiated.  We validate that our validator also catches
    this for defense-in-depth.
    """

    def test_valid_hash_passes(self) -> None:
        receipt = _make_receipt(execution_hash=_VALID_HASH)
        result = validate_receipt(receipt)
        assert result.valid

    def test_mixed_valid_hex_passes(self) -> None:
        receipt = _make_receipt(execution_hash="0123456789abcdef" * 4)
        result = validate_receipt(receipt)
        assert result.valid

    def test_invalid_hash_rejected_by_pydantic(self) -> None:
        """Pydantic's regex constraint prevents construction of invalid hashes."""
        with pytest.raises(ValidationError, match="execution_hash"):
            _make_receipt(execution_hash="invalid")


class TestTokenBoundsValidation:
    """Rule 2: tokens_burned must be in [0, 10_000_000]."""

    def test_zero_tokens_valid(self) -> None:
        receipt = _make_receipt(tokens_burned=0)
        result = validate_receipt(receipt)
        assert result.valid

    def test_max_tokens_triggers_quota_not_schema(self) -> None:
        """10M is within schema bounds but exceeds the 5M Claw quota."""
        receipt = _make_receipt(tokens_burned=10_000_000)
        result = validate_receipt(receipt)
        assert not result.valid
        # Should be a quota violation, not a schema bounds violation
        assert not any("schema bounds" in v for v in result.violations)
        assert any("Thermodynamic Quota" in v for v in result.violations)

    def test_negative_tokens_rejected_by_pydantic(self) -> None:
        """Pydantic's ge=0 constraint prevents construction of negative tokens."""
        with pytest.raises(ValidationError, match="tokens_burned"):
            _make_receipt(tokens_burned=-1)

    def test_above_schema_max_rejected_by_pydantic(self) -> None:
        """Pydantic's le=10_000_000 constraint prevents construction."""
        with pytest.raises(ValidationError, match="tokens_burned"):
            _make_receipt(tokens_burned=10_000_001)


class TestThermodynamicQuotaAudit:
    """Rule 3: solver-specific thermodynamic quota enforcement."""

    def test_claw_within_quota_passes(self) -> None:
        receipt = _make_receipt(tokens_burned=1_000_000)
        result = validate_receipt(receipt)
        assert result.valid

    def test_claw_exactly_at_quota_passes(self) -> None:
        receipt = _make_receipt(tokens_burned=5_000_000)
        result = validate_receipt(receipt)
        assert result.valid

    def test_claw_exceeds_quota_fails(self) -> None:
        receipt = _make_receipt(tokens_burned=5_000_001)
        result = validate_receipt(receipt)
        assert not result.valid
        assert any("Thermodynamic Quota Violation" in v for v in result.violations)

    def test_custom_quota_override(self) -> None:
        custom_quotas = {
            _CLAW_URN: ThermodynamicQuota(solver_urn=_CLAW_URN, max_tokens=100),
        }
        receipt = _make_receipt(tokens_burned=101)
        result = validate_receipt(receipt, quotas=custom_quotas)
        assert not result.valid

    def test_solver_without_quota_is_unconstrained(self) -> None:
        """Solvers not in the quota ledger skip the quota check."""
        receipt = _make_receipt(
            solver_urn="urn:coreason:solver:unknown:v1",
            tokens_burned=9_999_999,
        )
        result = validate_receipt(receipt)
        assert result.valid

    def test_empty_quota_dict_means_unconstrained(self) -> None:
        receipt = _make_receipt(tokens_burned=9_999_999)
        result = validate_receipt(receipt, quotas={})
        assert result.valid


class TestReceiptValidationResultStructure:
    """Tests for the ReceiptValidationResult dataclass."""

    def test_valid_result_has_no_violations(self) -> None:
        receipt = _make_receipt()
        result = validate_receipt(receipt)
        assert result.valid
        assert result.violations == ()

    def test_invalid_result_has_violations(self) -> None:
        receipt = _make_receipt(tokens_burned=5_000_001)
        result = validate_receipt(receipt)
        assert not result.valid
        assert len(result.violations) > 0
