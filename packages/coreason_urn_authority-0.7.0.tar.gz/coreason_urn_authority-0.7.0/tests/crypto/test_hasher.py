from coreason_urn_authority.crypto.hasher import CIDGenerator


def test_generate_cid_deterministic() -> None:
    payload1 = {"b": 2, "a": 1}
    payload2 = {"a": 1, "b": 2}

    cid1 = CIDGenerator.generate_cid(payload1)
    cid2 = CIDGenerator.generate_cid(payload2)

    assert cid1 == cid2
    assert cid1.startswith("sha256:")
    assert len(cid1) == 71  # "sha256:" (7) + hash (64)
