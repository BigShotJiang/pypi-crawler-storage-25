# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

import sys
from pathlib import Path
from textwrap import dedent
from typing import Any

import pytest
import yaml

_scripts_dir = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(_scripts_dir))

from compile_registry import compile_registry  # noqa: E402


def setup_mock_project(
    tmp_path: Path,
    manifest_override: dict[str, Any] | None = None,
    urn: str = "urn:coreason:actionspace:solver:test_cap:v1",
) -> Path:
    assets_dir = tmp_path / "assets"
    schemas_dir = tmp_path / "schemas"
    schemas_dir.mkdir()

    # Copy real schema to mock dir
    real_schema = Path(__file__).resolve().parent.parent / "schemas" / "manifest.schema.json"
    (schemas_dir / "manifest.schema.json").write_text(real_schema.read_text(encoding="utf-8"), encoding="utf-8")

    bundle_dir = assets_dir / "solver" / "test_cap_v1"
    bundle_dir.mkdir(parents=True)

    (bundle_dir / "__init__.py").write_text(f'__action_space_urn__ = "{urn}"\n', encoding="utf-8")

    manifest_data = {
        "urn": urn,
        "default_clearance_tiers": [200],
        "default_minimum_rigidity_tier": 255,
        "epistemic_status": "DRAFT",
        "composition": {"topology": "ATOMIC", "dependencies": []},
        "economics": {"license_class": "OPEN_SOURCE", "billing_tier": "TIER_0_FREE"},
        "provenance": {"author_id": "agent:test", "created_at": "2026-01-01T00:00:00Z"},
        "validation": {"test_coverage_pct": 100, "latency_ms": 10, "cryptographic_hash": None},
    }
    if manifest_override:
        manifest_data.update(manifest_override)

    (bundle_dir / "manifest.yaml").write_text(
        yaml.dump(manifest_data, default_flow_style=False, sort_keys=False), encoding="utf-8"
    )

    (bundle_dir / "schema.py").write_text(
        dedent("""\
        from coreason_manifest.spec.ontology import CoreasonBaseState
        class Input(CoreasonBaseState): pass
    """),
        encoding="utf-8",
    )

    (bundle_dir / "server.py").write_text(
        dedent("""\
        from mcp import tool
        from schema import Input
        
        @tool
        def run() -> Input:
            return Input()
    """),
        encoding="utf-8",
    )

    return tmp_path


def test_compile_registry_success(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    compile_registry(project_root)
    assert (project_root / "registry" / "compiled_matrix.json").exists()


def test_compile_registry_missing_schema(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "schemas" / "manifest.schema.json").unlink()
    with pytest.raises(FileNotFoundError, match="Constitutional Fault"):
        compile_registry(project_root)


def test_compile_registry_syntax_error_init(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    # Syntax error in __init__.py makes it silently skip (as per logic)
    (project_root / "assets" / "solver" / "test_cap_v1" / "__init__.py").write_text("invalid syntax(", encoding="utf-8")
    compile_registry(project_root)


def test_compile_registry_urn_mismatch(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path, manifest_override={"urn": "urn:coreason:actionspace:solver:other:v1"})
    with pytest.raises(ValueError, match="URN mismatch"):
        compile_registry(project_root)


def test_compile_registry_invalid_urn_geometry(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path, urn="invalid_urn")
    with pytest.raises(ValueError, match="Topological Fault: Invalid URN geometry"):
        compile_registry(project_root)


def test_compile_registry_unrecognized_category(tmp_path: Path) -> None:
    # Set urn to have invalid category (e.g. unknown)
    urn = "urn:coreason:actionspace:unknown:test_cap:v1"
    project_root = setup_mock_project(tmp_path, urn=urn)
    # Move directory to unknown
    (project_root / "assets" / "solver").rename(project_root / "assets" / "unknown")
    with pytest.raises(ValueError, match="Unrecognized asset category"):
        compile_registry(project_root)


def test_compile_registry_directory_map_fault(tmp_path: Path) -> None:
    # URN says oracle, but directory is solver
    urn = "urn:coreason:actionspace:oracle:test_cap:v1"
    project_root = setup_mock_project(tmp_path, urn=urn)
    with pytest.raises(ValueError, match="violates Directory Map Formula"):
        compile_registry(project_root)


def test_compile_registry_missing_manifest(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "manifest.yaml").unlink()
    with pytest.raises(FileNotFoundError, match=r"Missing manifest\.yaml"):
        compile_registry(project_root)


def test_compile_registry_empty_manifest(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "manifest.yaml").write_text("", encoding="utf-8")
    with pytest.raises(ValueError, match=r"Empty manifest\.yaml"):
        compile_registry(project_root)


def test_compile_registry_pvv_consensus_failure(tmp_path: Path) -> None:
    # PUBLISHED without signatures
    project_root = setup_mock_project(tmp_path, manifest_override={"epistemic_status": "PUBLISHED"})
    with pytest.raises(ValueError, match="lacks strict consensus"):
        compile_registry(project_root)


def test_compile_registry_pvv_consensus_genesis_success(tmp_path: Path) -> None:
    # PUBLISHED with genesis signature
    project_root = setup_mock_project(
        tmp_path,
        manifest_override={
            "epistemic_status": "PUBLISHED",
            "validation": {
                "test_coverage_pct": 100,
                "latency_ms": 10,
                "cryptographic_hash": None,
                "genesis_node_signature": "jwt_token",
            },
        },
    )
    compile_registry(project_root)


def test_compile_registry_pvv_consensus_mesh_success(tmp_path: Path) -> None:
    # PUBLISHED with 5 mesh signatures
    project_root = setup_mock_project(
        tmp_path,
        manifest_override={
            "epistemic_status": "PUBLISHED",
            "validation": {
                "test_coverage_pct": 100,
                "latency_ms": 10,
                "cryptographic_hash": None,
                "consensus_signatures": ["s1", "s2", "s3", "s4", "s5"],
            },
        },
    )
    compile_registry(project_root)


def test_compile_registry_ontological_fault_basemodel(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "schema.py").write_text(
        dedent("""\
        from pydantic import BaseModel
        class BadModel(BaseModel): pass
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="illegally inherits from BaseModel"):
        compile_registry(project_root)


def test_compile_registry_ontological_fault_missing_isomorphic(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "schema.py").write_text(
        dedent("""\
        class MissingInheritance: pass
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="lacks isomorphic inheritance"):
        compile_registry(project_root)


def test_compile_registry_architectural_fault_schema_in_server(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "server.py").write_text(
        dedent("""\
        from pydantic import BaseModel
        class BadSchema(BaseModel): pass
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="Schema Decoupling mandates"):
        compile_registry(project_root)


def test_compile_registry_epistemic_fault_missing_return_type(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "server.py").write_text(
        dedent("""\
        from mcp import tool
        @tool
        def run(): pass
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="lacks a return type hint"):
        compile_registry(project_root)


def test_compile_registry_epistemic_fault_raw_return_type(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "server.py").write_text(
        dedent("""\
        from mcp import tool
        @tool
        def run() -> dict: return {}
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="contains a raw"):
        compile_registry(project_root)


def test_compile_registry_epistemic_fault_raw_return_type_string(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "server.py").write_text(
        dedent("""\
        from mcp import tool
        @tool
        def run() -> "dict[str, Any]": return {}
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="contains a raw"):
        compile_registry(project_root)


def test_compile_registry_default_args(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    import compile_registry as cr

    monkeypatch.setattr(cr, "__file__", str(project_root / "scripts" / "compile_registry.py"))
    cr.compile_registry(None)
    assert (project_root / "registry" / "compiled_matrix.json").exists()


def test_compile_registry_skips_invalid_directories(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "__init__.py").write_text("", encoding="utf-8")
    (project_root / "assets" / "solver" / "__init__.py").write_text("", encoding="utf-8")
    tests_dir = project_root / "assets" / "solver" / "test_cap_v1" / "tests"
    tests_dir.mkdir()
    (tests_dir / "__init__.py").write_text("__action_space_urn__ = 'urn:123'", encoding="utf-8")
    compile_registry(project_root)


def test_compile_registry_missing_validation_in_manifest(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    mf = project_root / "assets" / "solver" / "test_cap_v1" / "manifest.yaml"
    import yaml

    manifest = yaml.safe_load(mf.read_text(encoding="utf-8"))
    del manifest["validation"]
    mf.write_text(yaml.dump(manifest, sort_keys=False), encoding="utf-8")
    import jsonschema.exceptions

    with pytest.raises(jsonschema.exceptions.ValidationError):
        compile_registry(project_root)


def test_compile_registry_ast_attribute_bases_schema(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "schema.py").write_text(
        dedent("""\
        import pydantic
        class BadModel(pydantic.BaseModel): pass
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="illegally inherits from BaseModel"):
        compile_registry(project_root)


def test_compile_registry_ast_attribute_bases_server(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "server.py").write_text(
        dedent("""\
        import pydantic
        class BadSchema(pydantic.BaseModel): pass
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="Schema Decoupling mandates"):
        compile_registry(project_root)


def test_compile_registry_ast_decorator_call(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "server.py").write_text(
        dedent("""\
        import mcp
        @mcp.tool()
        def run(): pass
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="lacks a return type hint"):
        compile_registry(project_root)


def test_compile_registry_ast_attribute_return_type(tmp_path: Path) -> None:
    project_root = setup_mock_project(tmp_path)
    (project_root / "assets" / "solver" / "test_cap_v1" / "server.py").write_text(
        dedent("""\
        import mcp
        import typing
        @mcp.tool()
        def run() -> typing.Dict: return {}
    """),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="contains a raw"):
        compile_registry(project_root)


def test_compile_registry_merkle_dag_null_prior_event(tmp_path: Path) -> None:
    # Genesis node with null prior_event_hash
    project_root = setup_mock_project(
        tmp_path,
        manifest_override={
            "provenance": {"author_id": "agent:test", "created_at": "2026-01-01T00:00:00Z", "prior_event_hash": None}
        },
    )
    compile_registry(project_root)
    assert (project_root / "registry" / "compiled_matrix.json").exists()


def test_compile_registry_merkle_dag_valid_prior_event(tmp_path: Path) -> None:
    # Upgrade node with valid prior_event_hash
    valid_hash = "sha256:" + "a" * 64
    project_root = setup_mock_project(
        tmp_path,
        manifest_override={
            "provenance": {
                "author_id": "agent:test",
                "created_at": "2026-01-01T00:00:00Z",
                "prior_event_hash": valid_hash,
            }
        },
    )
    compile_registry(project_root)
    assert (project_root / "registry" / "compiled_matrix.json").exists()


def test_compile_registry_merkle_dag_invalid_prior_event(tmp_path: Path) -> None:
    # Invalid hash format
    invalid_hash = "sha256:invalid"
    project_root = setup_mock_project(
        tmp_path,
        manifest_override={
            "provenance": {
                "author_id": "agent:test",
                "created_at": "2026-01-01T00:00:00Z",
                "prior_event_hash": invalid_hash,
            }
        },
    )
    import jsonschema.exceptions

    with pytest.raises(jsonschema.exceptions.ValidationError):
        compile_registry(project_root)
