import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from hydrate_docs import hydrate


def test_hydrate_docs(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    import hydrate_docs as hd

    monkeypatch.setattr(hd, "__file__", str(tmp_path / "hydrate_docs.py"))

    # Run the function
    hydrate()

    # Assert directories are created
    assert (tmp_path / "schemas").exists()
    assert (tmp_path / "runbooks").exists()
    assert (tmp_path / "docs/tutorials").exists()
    assert (tmp_path / "docs/guides").exists()
    assert (tmp_path / "docs/architecture").exists()
    assert (tmp_path / "docs/reference").exists()

    # Assert files are created
    assert (tmp_path / "schemas/manifest.schema.json").exists()
    assert (tmp_path / "runbooks/VPC_HYDRATION.md").exists()
    assert (tmp_path / "docs/reference/manifest_specification.md").exists()
    assert (tmp_path / "docs/tutorials/scaffolding_first_urn.md").exists()
