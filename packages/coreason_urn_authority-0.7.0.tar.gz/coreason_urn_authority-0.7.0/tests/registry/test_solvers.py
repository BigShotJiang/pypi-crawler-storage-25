# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the Solver Registry Matrix."""

from __future__ import annotations

import pytest

from coreason_urn_authority.registry.solvers import (
    EpistemicClearance,
    get_all_solvers,
    get_solver,
    is_emission_authorized,
)


class TestSolverRegistryLookup:
    """Tests for solver lookup operations."""

    def test_claw_developer_registered(self) -> None:
        entry = get_solver("urn:coreason:actionspace:solver:claw_developer:v1")
        assert entry is not None
        assert entry.urn == "urn:coreason:actionspace:solver:claw_developer:v1"

    def test_clinical_extractor_registered(self) -> None:
        entry = get_solver("urn:coreason:actionspace:solver:clinical_extractor:v1")
        assert entry is not None

    def test_unknown_urn_returns_none(self) -> None:
        assert get_solver("urn:coreason:actionspace:solver:nonexistent:v1") is None

    def test_get_all_solvers_contains_both(self) -> None:
        all_solvers = get_all_solvers()
        assert "urn:coreason:actionspace:solver:claw_developer:v1" in all_solvers
        assert "urn:coreason:actionspace:solver:clinical_extractor:v1" in all_solvers


class TestSolverEmissionAuthorization:
    """Tests for emission authorization checks."""

    def test_claw_authorized_strategic_thought_node(self) -> None:
        assert is_emission_authorized(
            "urn:coreason:actionspace:solver:claw_developer:v1",
            "StrategicThoughtNodeIntent",
        )

    def test_claw_authorized_oracle_execution_receipt(self) -> None:
        assert is_emission_authorized(
            "urn:coreason:actionspace:solver:claw_developer:v1",
            "OracleExecutionReceipt",
        )

    def test_claw_not_authorized_for_arbitrary_type(self) -> None:
        assert not is_emission_authorized(
            "urn:coreason:actionspace:solver:claw_developer:v1",
            "SomeUnknownType",
        )

    def test_clinical_extractor_authorized_receipt(self) -> None:
        assert is_emission_authorized(
            "urn:coreason:actionspace:solver:clinical_extractor:v1",
            "OracleExecutionReceipt",
        )

    def test_clinical_extractor_not_authorized_thought_node(self) -> None:
        assert not is_emission_authorized(
            "urn:coreason:actionspace:solver:clinical_extractor:v1",
            "StrategicThoughtNodeIntent",
        )

    def test_unknown_solver_never_authorized(self) -> None:
        assert not is_emission_authorized(
            "urn:coreason:actionspace:solver:nonexistent:v1",
            "OracleExecutionReceipt",
        )


class TestSolverRegistryEntry:
    """Tests for the SolverRegistryEntry dataclass."""

    def test_immutability(self) -> None:
        entry = get_solver("urn:coreason:actionspace:solver:claw_developer:v1")
        assert entry is not None
        with pytest.raises(AttributeError):
            entry.urn = "tampered"  # type: ignore[misc]

    def test_claw_clearance_is_internal(self) -> None:
        entry = get_solver("urn:coreason:actionspace:solver:claw_developer:v1")
        assert entry is not None
        assert entry.clearance == EpistemicClearance.INTERNAL

    def test_clinical_clearance_is_confidential(self) -> None:
        entry = get_solver("urn:coreason:actionspace:solver:clinical_extractor:v1")
        assert entry is not None
        assert entry.clearance == EpistemicClearance.CONFIDENTIAL

    def test_authorized_emissions_is_frozenset(self) -> None:
        entry = get_solver("urn:coreason:actionspace:solver:claw_developer:v1")
        assert entry is not None
        assert isinstance(entry.authorized_emissions, frozenset)

    def test_description_populated(self) -> None:
        entry = get_solver("urn:coreason:actionspace:solver:claw_developer:v1")
        assert entry is not None
        assert "Claw Code" in entry.description


class TestEpistemicClearanceComparability:
    """IntEnum clearance tiers must support mathematical comparison
    for Zero-Trust authorization (e.g. ``user.clearance >= solver.clearance``)."""

    def test_public_less_than_internal(self) -> None:
        assert EpistemicClearance.PUBLIC < EpistemicClearance.INTERNAL

    def test_internal_less_than_confidential(self) -> None:
        assert EpistemicClearance.INTERNAL < EpistemicClearance.CONFIDENTIAL

    def test_confidential_less_than_restricted(self) -> None:
        assert EpistemicClearance.CONFIDENTIAL < EpistemicClearance.RESTRICTED

    def test_restricted_is_maximum(self) -> None:
        assert EpistemicClearance.RESTRICTED == 255

    def test_public_is_zero(self) -> None:
        assert EpistemicClearance.PUBLIC == 0

    def test_internal_user_cannot_access_confidential_solver(self) -> None:
        """A user at INTERNAL (100) must NOT invoke a CONFIDENTIAL (200) solver."""
        user_clearance = EpistemicClearance.INTERNAL
        solver = get_solver("urn:coreason:actionspace:solver:clinical_extractor:v1")
        assert solver is not None
        assert not (user_clearance >= solver.clearance)

    def test_confidential_user_can_access_internal_solver(self) -> None:
        """A user at CONFIDENTIAL (200) CAN invoke an INTERNAL (100) solver."""
        user_clearance = EpistemicClearance.CONFIDENTIAL
        solver = get_solver("urn:coreason:actionspace:solver:claw_developer:v1")
        assert solver is not None
        assert user_clearance >= solver.clearance
