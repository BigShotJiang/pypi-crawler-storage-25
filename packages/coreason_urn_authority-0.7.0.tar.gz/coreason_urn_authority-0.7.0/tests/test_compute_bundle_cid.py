# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the Merkle-style CID computation in compile_registry.py.

These tests validate that the content-addressed hashing algorithm is:
- Deterministic: same files always produce the same hash
- Idempotent: running twice doesn't change the result
- Sensitive: any single-byte change in any file produces a different hash
- Merkle-correct: the output matches a hand-computed Merkle root
- Self-referentially stable: the hash doesn't depend on the stored hash value
"""

from __future__ import annotations

import hashlib

# ────────────────────────────────────────────────────────────────────
# Import the function under test
# ────────────────────────────────────────────────────────────────────
import sys
from pathlib import Path
from textwrap import dedent

import yaml

# compile_registry.py is a script, not a package — add its directory to path
_scripts_dir = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(_scripts_dir))

from compile_registry import compute_bundle_cid  # noqa: E402

# ────────────────────────────────────────────────────────────────────
# Helpers
# ────────────────────────────────────────────────────────────────────


def _make_bundle(tmp_path: Path, overrides: dict[str, str | None] | None = None) -> Path:
    """Create a minimal 4-file Action Space bundle in a temp directory."""
    defaults = {
        "__init__.py": dedent("""\
            __action_space_urn__ = "urn:coreason:actionspace:solver:test_cap:v1"
            __all__ = ["mcp", "__action_space_urn__"]
        """),
        "manifest.yaml": yaml.dump(
            {
                "urn": "urn:coreason:actionspace:solver:test_cap:v1",
                "default_clearance_tiers": [200],
                "default_minimum_rigidity_tier": 255,
                "epistemic_status": "DRAFT",
                "provenance": {
                    "author_id": "agent:test",
                    "created_at": "2026-01-01T00:00:00Z",
                    "oracle_validator": None,
                },
                "validation": {"test_coverage_pct": 0.0, "latency_ms": 0, "cryptographic_hash": None},
            },
            default_flow_style=False,
            sort_keys=False,
        ),
        "schema.py": dedent("""\
            from pydantic import BaseModel
            class TestInput(BaseModel):
                query: str
        """),
        "server.py": dedent("""\
            async def run(query: str) -> str:
                return f"result: {query}"
        """),
    }
    if overrides:
        for k, v in overrides.items():
            if v is None:
                defaults.pop(k, None)
            else:
                defaults[k] = v

    bundle_dir = tmp_path / "test_bundle"
    bundle_dir.mkdir(parents=True, exist_ok=True)
    for filename, content in defaults.items():
        (bundle_dir / filename).write_text(content, encoding="utf-8")
    return bundle_dir


def _hand_compute_merkle(bundle_dir: Path) -> str:
    """Independently compute the expected Merkle CID without using the production code."""
    canonical_files = ["__init__.py", "manifest.yaml", "schema.py", "server.py"]
    file_hashes: list[str] = []
    for filename in sorted(canonical_files):
        filepath = bundle_dir / filename
        if not filepath.exists():
            continue
        if filename == "manifest.yaml":
            manifest_data = yaml.safe_load(filepath.read_bytes())
            if manifest_data and "validation" in manifest_data:
                manifest_data["validation"]["cryptographic_hash"] = None
            canonical_bytes = yaml.dump(manifest_data, default_flow_style=False, sort_keys=True).encode("utf-8")
            file_hash = hashlib.sha256(canonical_bytes).hexdigest()
        else:
            file_hash = hashlib.sha256(filepath.read_bytes()).hexdigest()
        file_hashes.append(f"{filename}:{file_hash}")
    merkle_input = "\n".join(file_hashes).encode("utf-8")
    return f"sha256:{hashlib.sha256(merkle_input).hexdigest()}"


# ────────────────────────────────────────────────────────────────────
# Tests
# ────────────────────────────────────────────────────────────────────


class TestComputeBundleCID:
    """Core CID computation tests."""

    def test_determinism(self, tmp_path: Path) -> None:
        """Same files must always produce the same hash."""
        bundle_dir = _make_bundle(tmp_path)
        cid1 = compute_bundle_cid(bundle_dir)
        cid2 = compute_bundle_cid(bundle_dir)
        assert cid1 == cid2

    def test_format(self, tmp_path: Path) -> None:
        """CID must follow the sha256:<64 hex chars> pattern."""
        bundle_dir = _make_bundle(tmp_path)
        cid = compute_bundle_cid(bundle_dir)
        assert cid.startswith("sha256:")
        hex_part = cid.removeprefix("sha256:")
        assert len(hex_part) == 64
        assert all(c in "0123456789abcdef" for c in hex_part)

    def test_matches_hand_computed_merkle(self, tmp_path: Path) -> None:
        """The CID must exactly match an independently computed Merkle root."""
        bundle_dir = _make_bundle(tmp_path)
        production_cid = compute_bundle_cid(bundle_dir)
        expected_cid = _hand_compute_merkle(bundle_dir)
        assert production_cid == expected_cid

    def test_idempotency_across_manifest_writes(self, tmp_path: Path) -> None:
        """Writing the CID back into manifest.yaml and recomputing must yield the same hash.

        This proves the self-referential loop is correctly broken by zeroing
        cryptographic_hash before hashing.
        """
        bundle_dir = _make_bundle(tmp_path)
        cid1 = compute_bundle_cid(bundle_dir)

        # Simulate what compile_registry.py does: write CID back into manifest.yaml
        manifest_file = bundle_dir / "manifest.yaml"
        manifest = yaml.safe_load(manifest_file.read_text(encoding="utf-8"))
        manifest["validation"]["cryptographic_hash"] = cid1
        manifest_file.write_text(yaml.dump(manifest, default_flow_style=False, sort_keys=False), encoding="utf-8")

        # Recompute — must be identical
        cid2 = compute_bundle_cid(bundle_dir)
        assert cid1 == cid2

    def test_triple_idempotency(self, tmp_path: Path) -> None:
        """Triple run: compute → write → compute → write → compute must be stable."""
        bundle_dir = _make_bundle(tmp_path)
        manifest_file = bundle_dir / "manifest.yaml"

        cids: list[str] = []
        for _ in range(3):
            cid = compute_bundle_cid(bundle_dir)
            cids.append(cid)
            manifest = yaml.safe_load(manifest_file.read_text(encoding="utf-8"))
            manifest["validation"]["cryptographic_hash"] = cid
            manifest_file.write_text(yaml.dump(manifest, default_flow_style=False, sort_keys=False), encoding="utf-8")

        assert cids[0] == cids[1] == cids[2]

    def test_sensitivity_init(self, tmp_path: Path) -> None:
        """Changing __init__.py must change the CID."""
        bundle_dir = _make_bundle(tmp_path)
        cid1 = compute_bundle_cid(bundle_dir)
        (bundle_dir / "__init__.py").write_text("# modified\n", encoding="utf-8")
        cid2 = compute_bundle_cid(bundle_dir)
        assert cid1 != cid2

    def test_sensitivity_schema(self, tmp_path: Path) -> None:
        """Changing schema.py must change the CID."""
        bundle_dir = _make_bundle(tmp_path)
        cid1 = compute_bundle_cid(bundle_dir)
        (bundle_dir / "schema.py").write_text("# modified schema\n", encoding="utf-8")
        cid2 = compute_bundle_cid(bundle_dir)
        assert cid1 != cid2

    def test_sensitivity_server(self, tmp_path: Path) -> None:
        """Changing server.py must change the CID."""
        bundle_dir = _make_bundle(tmp_path)
        cid1 = compute_bundle_cid(bundle_dir)
        (bundle_dir / "server.py").write_text("# modified server\n", encoding="utf-8")
        cid2 = compute_bundle_cid(bundle_dir)
        assert cid1 != cid2

    def test_sensitivity_manifest_non_hash_field(self, tmp_path: Path) -> None:
        """Changing a non-hash field in manifest.yaml must change the CID."""
        bundle_dir = _make_bundle(tmp_path)
        cid1 = compute_bundle_cid(bundle_dir)

        manifest_file = bundle_dir / "manifest.yaml"
        manifest = yaml.safe_load(manifest_file.read_text(encoding="utf-8"))
        manifest["epistemic_status"] = "PUBLISHED"
        manifest_file.write_text(yaml.dump(manifest, default_flow_style=False, sort_keys=False), encoding="utf-8")

        cid2 = compute_bundle_cid(bundle_dir)
        assert cid1 != cid2

    def test_sensitivity_single_byte(self, tmp_path: Path) -> None:
        """A single byte change must produce a completely different hash (avalanche effect)."""
        bundle_dir = _make_bundle(tmp_path)
        cid1 = compute_bundle_cid(bundle_dir)

        original = (bundle_dir / "server.py").read_text(encoding="utf-8")
        (bundle_dir / "server.py").write_text(original + " ", encoding="utf-8")
        cid2 = compute_bundle_cid(bundle_dir)

        assert cid1 != cid2
        # Verify avalanche: at least 50% of hex digits should differ
        hex1 = cid1.removeprefix("sha256:")
        hex2 = cid2.removeprefix("sha256:")
        differing = sum(1 for a, b in zip(hex1, hex2, strict=False) if a != b)
        assert differing >= 16, f"Only {differing}/64 hex digits differ — weak avalanche"

    def test_missing_file_gracefully_handled(self, tmp_path: Path) -> None:
        """Missing optional files should not crash, but produce a different CID."""
        bundle_dir = _make_bundle(tmp_path)
        cid_full = compute_bundle_cid(bundle_dir)

        # Remove server.py
        (bundle_dir / "server.py").unlink()
        cid_partial = compute_bundle_cid(bundle_dir)

        assert cid_full != cid_partial

    def test_no_concatenation_ambiguity(self, tmp_path: Path) -> None:
        """Merkle approach prevents the concatenation ambiguity attack.

        In naive concatenation, file A="xy" + file B="z" hashes the same
        as file A="x" + file B="yz". The Merkle approach hashes each file
        independently, so boundary shifts cannot produce collisions.
        """
        # Bundle 1: schema.py = "abc", server.py = "def"
        dir1 = _make_bundle(tmp_path / "b1", overrides={"schema.py": "abc", "server.py": "def"})
        # Bundle 2: schema.py = "abcd", server.py = "ef"
        dir2 = _make_bundle(tmp_path / "b2", overrides={"schema.py": "abcd", "server.py": "ef"})

        cid1 = compute_bundle_cid(dir1)
        cid2 = compute_bundle_cid(dir2)

        # These would collide with naive concatenation; Merkle prevents it
        assert cid1 != cid2
