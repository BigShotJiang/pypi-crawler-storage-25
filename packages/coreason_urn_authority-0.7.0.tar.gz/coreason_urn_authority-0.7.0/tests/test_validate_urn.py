import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from compile_registry import validate_urn


@pytest.fixture
def mock_matrix_path(tmp_path: Path) -> Path:
    matrix_path = tmp_path / "compiled_matrix.json"
    matrix_path.write_text(
        json.dumps({"urn:coreason:actionspace:solver:clinical_extractor:v1": {}}),
        encoding="utf-8",
    )
    return matrix_path


def test_validate_urn_success(mock_matrix_path: Path) -> None:
    assert validate_urn("urn:coreason:actionspace:solver:clinical_extractor:v1", mock_matrix_path) is True


def test_validate_urn_failure(mock_matrix_path: Path) -> None:
    with pytest.raises(ValueError, match=r"Warning: URN not found in Epistemic Ledger\."):
        validate_urn("urn:coreason:actionspace:custom:flawed:v1", mock_matrix_path)


def test_validate_urn_missing_matrix(tmp_path: Path) -> None:
    missing_path = tmp_path / "missing_matrix.json"
    with pytest.raises(ValueError, match=r"Warning: Epistemic Ledger \(compiled_matrix\.json\) not found\."):
        validate_urn("urn:coreason:actionspace:solver:clinical_extractor:v1", missing_path)
