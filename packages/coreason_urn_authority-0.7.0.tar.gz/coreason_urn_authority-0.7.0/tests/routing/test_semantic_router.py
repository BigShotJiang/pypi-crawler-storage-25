# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the Semantic Router — Dynamic Intent Routing."""

from __future__ import annotations

from coreason_urn_authority.routing.semantic_router import (
    ClusterTier,
    EntropyClass,
    route,
)


class TestLowEntropyRouting:
    """Low-entropy URNs should route to LOCAL_OPEN_WEIGHTS."""

    def test_bash_tool(self) -> None:
        decision = route("urn:coreason:tool:bash")
        assert decision.entropy_class == EntropyClass.LOW
        assert decision.cluster_tier == ClusterTier.LOCAL_OPEN_WEIGHTS

    def test_file_read_tool(self) -> None:
        decision = route("urn:coreason:tool:file_read")
        assert decision.entropy_class == EntropyClass.LOW
        assert decision.cluster_tier == ClusterTier.LOCAL_OPEN_WEIGHTS

    def test_file_write_tool(self) -> None:
        decision = route("urn:coreason:tool:file_write")
        assert decision.entropy_class == EntropyClass.LOW
        assert decision.cluster_tier == ClusterTier.LOCAL_OPEN_WEIGHTS

    def test_grep_tool(self) -> None:
        decision = route("urn:coreason:tool:grep")
        assert decision.entropy_class == EntropyClass.LOW
        assert decision.cluster_tier == ClusterTier.LOCAL_OPEN_WEIGHTS

    def test_list_dir_tool(self) -> None:
        decision = route("urn:coreason:tool:list_dir")
        assert decision.entropy_class == EntropyClass.LOW
        assert decision.cluster_tier == ClusterTier.LOCAL_OPEN_WEIGHTS

    def test_unknown_tool_prefix_defaults_low(self) -> None:
        """Unknown tool: URNs default to LOW via the prefix heuristic."""
        decision = route("urn:coreason:tool:some_new_tool")
        assert decision.entropy_class == EntropyClass.LOW
        assert decision.cluster_tier == ClusterTier.LOCAL_OPEN_WEIGHTS


class TestHighEntropyRouting:
    """High-entropy URNs should route to FRONTIER_MAAS."""

    def test_escalation_intent(self) -> None:
        decision = route("urn:coreason:actionspace:intent:escalation:v1")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS

    def test_ast_mutation_tool(self) -> None:
        decision = route("urn:coreason:tool:ast_mutation")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS

    def test_strategic_thought_node(self) -> None:
        decision = route("urn:coreason:actionspace:solver:strategic_thought_node_intent:v1")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS

    def test_claw_developer_solver(self) -> None:
        decision = route("urn:coreason:actionspace:solver:claw_developer:v1")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS

    def test_strategic_mcts_oracle(self) -> None:
        decision = route("urn:coreason:oracle:strategic_mcts")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS

    def test_combinatorial_asp_oracle(self) -> None:
        decision = route("urn:coreason:oracle:combinatorial_asp")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS

    def test_defeasible_logic_oracle(self) -> None:
        decision = route("urn:coreason:oracle:defeasible_logic")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS


class TestFailSafeRouting:
    """Unknown non-tool URNs should default to HIGH (fail-safe)."""

    def test_unknown_solver_defaults_high(self) -> None:
        decision = route("urn:coreason:actionspace:solver:unknown:v1")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS

    def test_completely_unknown_urn_defaults_high(self) -> None:
        decision = route("urn:unknown:namespace:something")
        assert decision.entropy_class == EntropyClass.HIGH
        assert decision.cluster_tier == ClusterTier.FRONTIER_MAAS


class TestRoutingDecisionStructure:
    """Tests for the RoutingDecision dataclass."""

    def test_urn_is_preserved(self) -> None:
        decision = route("urn:coreason:tool:bash")
        assert decision.urn == "urn:coreason:tool:bash"

    def test_immutability(self) -> None:
        decision = route("urn:coreason:tool:bash")
        try:
            decision.urn = "tampered"  # type: ignore[misc]
            raise AssertionError("Should have raised")
        except AttributeError:
            pass
