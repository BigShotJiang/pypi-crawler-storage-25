# Manifest Specification (`manifest.yaml`)

The `manifest.yaml` is the cryptographic identity card for every Sovereign capability.
All manifests MUST validate against `schemas/manifest.schema.json`.

## 1. Identity & Clearance
* **`urn`**: The globally unique Uniform Resource Name. Must match the directory path.
* **`clearance`**: `PUBLIC`, `CONFIDENTIAL`, or `RESTRICTED`.
* **`epistemic_status`**: `DRAFT` (AI scaffolded) or `PUBLISHED` (Oracle approved).

## 2. Composition & Economics
* **`topology`**: `ATOMIC` (Standalone) or `COMPOSITE` (Invokes other URNs).
* **`license_class`**: e.g., `PROSPERITY_3.0_COMMERCIAL` or `ENTERPRISE_CUSTOM`.
* **`billing_tier`**: Abstract cost category for thermodynamic pricing.
