import json
from pathlib import Path


def hydrate() -> None:
    root = Path(__file__).parent

    # 1. Scaffold Directories
    dirs = ["schemas", "runbooks", "docs/tutorials", "docs/guides", "docs/architecture", "docs/reference"]
    for d in dirs:
        (root / d).mkdir(parents=True, exist_ok=True)

    # 2. Write the JSON Schema
    schema_payload = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": "CoReason Epistemic Manifest",
        "description": "Strict schema validation for URN capability bundles.",
        "type": "object",
        "required": [
            "urn",
            "default_clearance_tiers",
            "default_minimum_rigidity_tier",
            "epistemic_status",
            "composition",
            "economics",
            "provenance",
            "validation",
        ],
        "properties": {
            "urn": {
                "type": "string",
                "pattern": (
                    "^urn:coreason:actionspace:(oracle|solver|effector|substrate|sensory|node):[a-z0-9_]+:v[0-9]+$"
                ),
            },
            "default_clearance_tiers": {"type": "array", "items": {"type": "integer", "minimum": 0, "maximum": 255}},
            "default_minimum_rigidity_tier": {"type": "integer", "minimum": 0, "maximum": 255},
            "provided_epistemic_security": {"type": "string", "enum": ["PUBLIC", "CONFIDENTIAL", "RESTRICTED"]},
            "provided_vram_gb": {"type": "integer", "minimum": 0},
            "supported_remote_decoding_protocols": {
                "type": "array",
                "items": {
                    "type": "string",
                    "enum": ["STRICT_JSON_SCHEMA", "NATIVE_PDA_GRAMMAR", "LOOSE_JSON_MODE", "NONE"],
                },
            },
            "epistemic_status": {"type": "string", "enum": ["DRAFT", "SRB_APPROVED", "CLIENT_APPROVED", "PUBLISHED"]},
            "composition": {
                "type": "object",
                "required": ["topology", "dependencies"],
                "properties": {
                    "topology": {"type": "string", "enum": ["ATOMIC", "COMPOSITE"]},
                    "dependencies": {"type": "array", "items": {"type": "string"}},
                },
            },
            "economics": {
                "type": "object",
                "required": ["license_class", "billing_tier"],
                "properties": {
                    "license_class": {
                        "type": "string",
                        "enum": ["OPEN_SOURCE", "PROSPERITY_3.0_COMMERCIAL", "ENTERPRISE_CUSTOM"],
                    },
                    "billing_tier": {
                        "type": "string",
                        "enum": ["TIER_0_FREE", "TIER_1_STANDARD", "TIER_2_HEAVY", "TIER_3_PREMIUM"],
                    },
                },
            },
            "provenance": {
                "type": "object",
                "required": ["author_id", "created_at"],
                "properties": {
                    "author_id": {"type": "string"},
                    "created_at": {"type": "string", "format": "date-time"},
                    "oracle_validator": {"type": ["string", "null"]},
                    "certification": {"type": "string"},
                },
            },
            "validation": {
                "type": "object",
                "required": ["test_coverage_pct", "latency_ms", "cryptographic_hash"],
                "properties": {
                    "test_coverage_pct": {"type": "number", "minimum": 0, "maximum": 100},
                    "latency_ms": {"type": "integer", "minimum": 0},
                    "cryptographic_hash": {
                        "type": ["string", "null"],
                        "pattern": "^sha256:[a-f0-9]{64}$",
                        "description": "SHA-256 content hash of the canonical Action Space bundle, "
                        "computed by compile_registry.py",
                    },
                    "formal_guarantees": {"type": "array", "items": {"type": "string"}},
                },
            },
        },
    }
    with open(root / "schemas/manifest.schema.json", "w") as f:
        json.dump(schema_payload, f, indent=2)

    # 3. Write the VPC Runbook
    runbook_payload = """# Runbook: VPC Hydration & Matrix Sync

**Target Audience:** CoReason Deployment Engineers
**Objective:** Synchronize the global Epistemic Ledger (`compiled_matrix.json`) into an air-gapped
Enterprise VPC and hydrate the Master MCP.

## Execution Steps
1. **Artifact Retrieval:** Download `compiled_matrix.json` and OCI containers from CoReason Global.
2. **Matrix Injection:** `cp compiled_matrix.json /mnt/coreason-state/registry/compiled_matrix.json`
3. **Image Sideloading:** `docker load -i coreason_assets_v2.1.tar`
4. **Hydrate Master MCP:** `systemctl restart coreason-master-mcp`
"""
    with open(root / "runbooks/VPC_HYDRATION.md", "w") as f:
        f.write(runbook_payload)

    # 4. Write the Manifest Reference
    reference_payload = """# Manifest Specification (`manifest.yaml`)

The `manifest.yaml` is the cryptographic identity card for every Sovereign capability.
All manifests MUST validate against `schemas/manifest.schema.json`.

## 1. Identity & Clearance
* **`urn`**: The globally unique Uniform Resource Name. Must match the directory path.
* **`default_clearance_tiers`**: An array of integers (0-255) dictating the baseline authorized compartments.
* **`epistemic_status`**: `DRAFT` (AI scaffolded) or `PUBLISHED` (Oracle approved).

## 2. Composition & Economics
* **`topology`**: `ATOMIC` (Standalone) or `COMPOSITE` (Invokes other URNs).
* **`license_class`**: e.g., `PROSPERITY_3.0_COMMERCIAL` or `ENTERPRISE_CUSTOM`.
* **`billing_tier`**: Abstract cost category for thermodynamic pricing.
"""
    with open(root / "docs/reference/manifest_specification.md", "w") as f:
        f.write(reference_payload)

    # 5. Touch Stubs to prevent 404 Build Crashes
    stubs = [
        "docs/tutorials/scaffolding_first_urn.md",
        "docs/tutorials/the_oracle_review.md",
        "docs/guides/deploying_custom_client_urns.md",
        "docs/guides/resolving_topological_faults.md",
        "docs/guides/updating_economic_ledgers.md",
        "docs/architecture/the_epistemic_ledger.md",
        "docs/architecture/the_archetype_model.md",
        "docs/architecture/quality_guillotines.md",
    ]
    for stub in stubs:
        with open(root / stub, "w") as f:
            f.write(f"# {stub.split('/')[-1].replace('.md', '').replace('_', ' ').title()}\n\n*Documentation pending.*")

    print("[SUCCESS] Hydration Complete! All schemas, runbooks, and stubs generated successfully.")


if __name__ == "__main__":
    hydrate()
