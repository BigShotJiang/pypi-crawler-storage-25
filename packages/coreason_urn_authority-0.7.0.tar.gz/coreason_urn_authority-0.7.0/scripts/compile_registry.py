# Copyright (c) 2026 CoReason, Inc.
# This software is proprietary and dual-licensed under the Prosperity Public License 3.0.

"""AST parser for building the routing registry matrix and enforcing topographical bounds."""

import ast
import hashlib
import json
import re
from pathlib import Path

import jsonschema  # <-- Hoisted global import
import yaml

try:
    from coreason_manifest.utils.algebra import compute_merkle_directory_cid  # type: ignore[attr-defined]
except ImportError:
    # Fallback for environments where coreason-manifest is not installed.
    # This is a verbatim copy of the canonical implementation from coreason-manifest.
    def compute_merkle_directory_cid(file_contents: dict[str, bytes]) -> str:
        """Merkle-style SHA-256 CID (local fallback)."""
        file_hashes: list[str] = []
        for filename in sorted(file_contents.keys()):
            file_hash = hashlib.sha256(file_contents[filename]).hexdigest()
            file_hashes.append(f"{filename}:{file_hash}")
        merkle_input = "\n".join(file_hashes).encode("utf-8")
        return f"sha256:{hashlib.sha256(merkle_input).hexdigest()}"


def compute_bundle_cid(bundle_dir: Path) -> str:
    """Compute a Merkle-style SHA-256 CID over the canonical Action Space bundle.

    Delegates the core Merkle hash to ``compute_merkle_directory_cid()``
    from the shared kernel (``coreason-manifest``).  This function handles
    only the domain-specific concerns: which files to include and zeroing
    the self-referential ``cryptographic_hash`` field in ``manifest.yaml``.

    Args:
        bundle_dir: Path to the Action Space bundle directory.

    Returns:
        A string in the format ``sha256:<64-char hex digest>``.
    """
    canonical_filenames = sorted(
        [
            "__init__.py",
            "manifest.yaml",
            "schema.py",
            "server.py",
        ]
    )

    file_contents: dict[str, bytes] = {}
    for filename in canonical_filenames:
        filepath = bundle_dir / filename
        if not filepath.exists():
            continue

        if filename == "manifest.yaml":
            # Zero the hash field to break self-referential instability.
            # We hash the manifest as-if cryptographic_hash were null.
            manifest_data = yaml.safe_load(filepath.read_bytes())
            if manifest_data and "validation" in manifest_data:
                manifest_data["validation"]["cryptographic_hash"] = None
            # Canonical YAML serialization (sorted keys for determinism)
            file_contents[filename] = yaml.dump(manifest_data, default_flow_style=False, sort_keys=True).encode("utf-8")
        else:
            file_contents[filename] = filepath.read_bytes()

    return str(compute_merkle_directory_cid(file_contents))


def validate_urn(urn: str, matrix_path: Path | None = None) -> bool:
    """
    Passively cross-reference the declared URN against the local compiled_matrix.json.
    Raises ValueError with a specific warning if the URN is missing.
    """
    if matrix_path is None:
        project_root = Path(__file__).resolve().parent.parent
        matrix_path = project_root / "registry" / "compiled_matrix.json"

    if not matrix_path.exists():
        raise ValueError("Warning: Epistemic Ledger (compiled_matrix.json) not found. Please run compile_registry.py.")

    with open(matrix_path, encoding="utf-8") as f:
        matrix = json.load(f)

    if urn not in matrix:
        raise ValueError(
            "Warning: URN not found in Epistemic Ledger. "
            "Please scaffold your action space in coreason_urn_authority/assets/ and run compile_registry.py."
        )

    return True


def compile_registry(project_root: Path | None = None) -> None:
    if project_root is None:
        project_root = Path(__file__).parent.parent
    assets_dir = project_root / "assets"
    registry_dir = project_root / "registry"
    registry_dir.mkdir(exist_ok=True)

    # --- THERMODYNAMIC OPTIMIZATION ---
    # Load the manifest schema into memory exactly ONCE before the execution loop.
    manifest_schema_path = project_root / "schemas" / "manifest.schema.json"
    if not manifest_schema_path.exists():
        raise FileNotFoundError(f"Constitutional Fault: Missing {manifest_schema_path}")

    with open(manifest_schema_path, encoding="utf-8") as msf:
        manifest_schema = json.load(msf)
    # ----------------------------------

    routing_table = {}

    for init_file in assets_dir.rglob("__init__.py"):
        if init_file.parent == assets_dir or init_file.parent.parent == assets_dir:
            continue
        if "tests" in init_file.parts:
            continue

        with open(init_file, encoding="utf-8") as f:
            try:
                tree = ast.parse(f.read(), filename=str(init_file))
            except SyntaxError:
                continue

        urn: str | None = None
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if (
                        isinstance(target, ast.Name)
                        and target.id == "__action_space_urn__"
                        and isinstance(node.value, ast.Constant)
                        and isinstance(node.value.value, str)
                    ):
                        urn = node.value.value
                        break

        if urn:
            # 1. Topographical Bounds Verification
            urn_parts = urn.split(":")
            if len(urn_parts) != 6:
                raise ValueError(f"Topological Fault: Invalid URN geometry '{urn}' in {init_file}")

            expected_category = urn_parts[3]
            expected_bundle_name = f"{urn_parts[4]}_{urn_parts[5]}"

            actual_bundle_name = init_file.parent.name
            actual_category = init_file.parent.parent.name

            allowed_categories = {"oracle", "solver", "effector", "substrate", "sensory", "node"}
            if actual_category not in allowed_categories:
                raise ValueError(
                    f"Topological Fault: Unrecognized asset category '{actual_category}' in {init_file}. "
                    f"Asset category must be one of {allowed_categories}."
                )

            if expected_category != actual_category or expected_bundle_name != actual_bundle_name:
                raise ValueError(
                    f"Topological Fault: URN '{urn}' violates Directory Map Formula. "
                    f"Expected path: assets/{expected_category}/{expected_bundle_name}/..., "
                    f"but found in assets/{actual_category}/{actual_bundle_name}/"
                )

            # 2. Manifest Verification
            manifest_file = init_file.parent / "manifest.yaml"
            if manifest_file.exists():
                with open(manifest_file, encoding="utf-8") as mf:
                    manifest = yaml.safe_load(mf)

                if not manifest:
                    raise ValueError(f"Empty manifest.yaml in {init_file.parent}")

                # --- Content-Addressed Identity (CID) Computation ---
                # Compute SHA-256 BEFORE schema validation so the hash field
                # passes the new pattern constraint. We hash the 3 code files
                # plus the manifest with cryptographic_hash zeroed to avoid
                # self-referential instability.
                bundle_cid = compute_bundle_cid(init_file.parent)

                # Inject the computed CID into the in-memory manifest
                if "validation" not in manifest:
                    manifest["validation"] = {}
                manifest["validation"]["cryptographic_hash"] = bundle_cid

                # Persist the CID back into manifest.yaml on disk
                with open(manifest_file, "w", encoding="utf-8") as mf_out:
                    yaml.dump(manifest, mf_out, default_flow_style=False, sort_keys=False)

                # NOW validate against schema (with a real sha256 hash in place)
                jsonschema.validate(instance=manifest, schema=manifest_schema)

                if manifest.get("urn") != urn:
                    raise ValueError(
                        f"URN mismatch in {init_file.parent}: __init__.py has {urn}, manifest has {manifest.get('urn')}"
                    )

                # 2b. The Quality Guillotine (Hybrid Decentralized Consensus)
                epistemic_status = manifest.get("epistemic_status", "DRAFT")
                if epistemic_status == "PUBLISHED":
                    validation_section = manifest.get("validation", {})
                    genesis_sig = validation_section.get("genesis_node_signature")
                    consensus_sigs = validation_section.get("consensus_signatures", [])

                    if not genesis_sig and len(consensus_sigs) < 5:
                        raise ValueError(
                            f"Topological Fault: URN '{urn}' in {init_file.parent} claims to be PUBLISHED, "
                            f"but lacks strict consensus. It MUST possess either a valid 'genesis_node_signature' "
                            f"(Tier 0 Override) or at least 5 'consensus_signatures' (PVV Mesh Consensus)."
                        )

                # 3. Ontological Bounds Verification (The Inheritance Guillotine)
                schema_file = init_file.parent / "schema.py"
                if schema_file.exists():
                    with open(schema_file, encoding="utf-8") as sf:
                        schema_tree = ast.parse(sf.read(), filename=str(schema_file))

                    safe_bases = {"CoreasonBaseState", "Enum", "StrEnum", "IntEnum"}

                    for schema_node in schema_tree.body:
                        if isinstance(schema_node, ast.ClassDef):
                            bases = []
                            for base in schema_node.bases:
                                if isinstance(base, ast.Name):
                                    bases.append(base.id)
                                elif isinstance(base, ast.Attribute):
                                    bases.append(base.attr)

                            if "BaseModel" in bases and "CoreasonBaseState" not in bases:
                                raise ValueError(
                                    f"Ontological Fault: Class '{schema_node.name}' in {schema_file.name} "
                                    f"illegally inherits from BaseModel. It MUST inherit from CoreasonBaseState "
                                    f"to guarantee RFC-8785 cryptographic determinism."
                                )

                            has_valid_base = any(b in safe_bases or "Enum" in b for b in bases)
                            if not has_valid_base:
                                raise ValueError(
                                    f"Ontological Fault: Class '{schema_node.name}' in {schema_file.name} "
                                    f"lacks isomorphic inheritance. It MUST inherit from "
                                    f"CoreasonBaseState, an Enum variant, or a previously validated base class."
                                )

                            safe_bases.add(schema_node.name)

                # 4. Execution Boundaries Verification (Epistemic Filter & Schema Decoupling)
                server_file = init_file.parent / "server.py"
                if server_file.exists():
                    with open(server_file, encoding="utf-8") as svf:
                        server_tree = ast.parse(svf.read(), filename=str(server_file))

                    for server_node in ast.walk(server_tree):
                        if isinstance(server_node, ast.ClassDef):
                            bases = []
                            for b in server_node.bases:
                                if isinstance(b, ast.Name):
                                    bases.append(b.id)
                                elif isinstance(b, ast.Attribute):
                                    bases.append(b.attr)

                            if "CoreasonBaseState" in bases or "BaseModel" in bases:
                                raise ValueError(
                                    f"Architectural Fault: Class '{server_node.name}' defined in {server_file.name}. "
                                    f"Schema Decoupling mandates all Pydantic states MUST be defined in schema.py."
                                )

                        if isinstance(server_node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            is_mcp_tool = False
                            for dec in server_node.decorator_list:
                                if isinstance(dec, ast.Call):
                                    if (isinstance(dec.func, ast.Attribute) and dec.func.attr == "tool") or (
                                        isinstance(dec.func, ast.Name) and dec.func.id == "tool"
                                    ):
                                        is_mcp_tool = True
                                elif (isinstance(dec, ast.Attribute) and dec.attr == "tool") or (
                                    isinstance(dec, ast.Name) and dec.id == "tool"
                                ):
                                    is_mcp_tool = True

                            if is_mcp_tool:
                                if not server_node.returns:
                                    raise ValueError(
                                        f"Epistemic Fault: MCP Tool '{server_node.name}' in "
                                        f"{server_file.parent.name}/{server_file.name} lacks a return type hint. "
                                        f"The Epistemic Filter Axiom mandates strict serialization."
                                    )

                                blocked_types = {"dict", "Dict", "Any", "Mapping", "MutableMapping"}
                                for ret_node in ast.walk(server_node.returns):
                                    ret_name = None
                                    if isinstance(ret_node, ast.Name):
                                        ret_name = ret_node.id
                                    elif isinstance(ret_node, ast.Attribute):
                                        ret_name = ret_node.attr
                                    elif isinstance(ret_node, ast.Constant) and isinstance(ret_node.value, str):
                                        for bt in blocked_types:
                                            if re.search(rf"\b{bt}\b", ret_node.value):
                                                ret_name = bt
                                                break

                                    if ret_name in blocked_types:
                                        raise ValueError(
                                            f"Epistemic Fault: MCP Tool '{server_node.name}' in "
                                            f"{server_file.parent.name}/{server_file.name} "
                                            f"contains a raw '{ret_name}' in its return signature. "
                                            f"The Epistemic Filter Axiom mathematically forbids returning unvalidated "
                                            f"external JSON. You MUST return a rigid CoreasonBaseState model."
                                        )

                routing_table[urn] = {
                    "path": str(init_file.parent.relative_to(project_root)).replace("\\", "/"),
                    "content_hash": bundle_cid,
                    "default_clearance_tiers": manifest.get("default_clearance_tiers", [255]),
                    "default_minimum_rigidity_tier": manifest.get("default_minimum_rigidity_tier", 255),
                    "provided_epistemic_security": manifest.get("provided_epistemic_security", "PUBLIC"),
                    "provided_vram_gb": manifest.get("provided_vram_gb", 0),
                    "supported_remote_decoding_protocols": manifest.get(
                        "supported_remote_decoding_protocols", ["NONE"]
                    ),
                    "epistemic_status": manifest.get("epistemic_status", "DRAFT"),
                }
            else:
                raise FileNotFoundError(f"Missing manifest.yaml in {init_file.parent}")

    with open(registry_dir / "compiled_matrix.json", "w", encoding="utf-8") as out:
        json.dump(routing_table, out, indent=2)
    print(f"Successfully compiled registry matrix with {len(routing_table)} URN bounds.")


if __name__ == "__main__":
    compile_registry()
