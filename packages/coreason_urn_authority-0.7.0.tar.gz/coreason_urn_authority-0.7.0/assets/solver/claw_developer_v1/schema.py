# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Pydantic I/O geometries for the Claw Code Developer Solver.

All models inherit from ``CoreasonBaseState`` to guarantee RFC 8785
cryptographic canonicalization during Swarm execution.
"""

from __future__ import annotations

from typing import Annotated

from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field, StringConstraints


class ClawDeveloperTaskState(CoreasonBaseState):
    """Input geometry for a Claw Code development task.

    Carries the epistemic deficit description and the thermodynamic
    budget ceiling that the Sovereign LLM Proxy will enforce.
    """

    epistemic_deficit: Annotated[str, StringConstraints(min_length=1, max_length=10000)] = Field(
        description=(
            "A structured description of the deterministic logic that "
            "failed, including the specific AST node, formal solver, or "
            "constraint that could not be satisfied."
        )
    )
    thermodynamic_budget: int = Field(
        ge=1,
        le=10_000_000,
        description=(
            "Maximum tokens the Sovereign LLM Proxy is authorized to "
            "burn before triggering the circuit breaker (HTTP 429)."
        ),
    )


class ClawDeveloperResultState(CoreasonBaseState):
    """Output geometry for a Claw Code development task.

    Carries the execution hash and the token accounting.
    """

    execution_hash: Annotated[str, StringConstraints(pattern=r"^[a-f0-9]{64}$")] = Field(
        description="SHA-256 hash of the complete execution payload."
    )
    tokens_burned: int = Field(
        ge=0,
        le=10_000_000,
        description="Total tokens consumed during this execution.",
    )
