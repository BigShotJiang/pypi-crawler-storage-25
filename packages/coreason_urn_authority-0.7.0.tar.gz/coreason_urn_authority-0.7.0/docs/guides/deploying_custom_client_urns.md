# Deploying Custom Client URNs

To integrate a new `Action Space` seamlessly onto the internal core, physical boundaries established via AST must be fully upheld dynamically testing. Follow these native limits:

## Step 1: Scaffold The Strict Category Environment
Create the module directly inside `assets/`.
Example: `assets/solver/my_tool_v1/`

You MUST generate precisely 5 files natively to trigger compilation:
- `__init__.py`: Export native `__action_space_urn__`.
- `manifest.yaml`: Set native JSonschema limits natively matching `schemas/`.
- `schema.py`: Embed strictly Pydantic structures.
- `server.py`: Enforce native MCP logic endpoints limits.
- `tests/test_server.py`: Provide explicit Property-Based testing testing arrays explicitly matching WASM serialization sizes (10MB).

## Step 2: Set DRAFT Status
Your metadata inherently requires `epistemic_status: "DRAFT"` upon initialization! It remains within DRAFT dynamically bound to the Ouroboros loop safely bridging PR interactions until Oracle validation.

## Step 3: Run Baseline CI Emulations
Once written, execute local validation directly resolving `uv run pytest --cov=assets` and `uv run ruff check .` to safely evaluate physical arrays before submitting upstream!
