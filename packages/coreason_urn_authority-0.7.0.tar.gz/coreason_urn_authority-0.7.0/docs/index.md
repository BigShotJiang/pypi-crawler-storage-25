# CoReason Epistemic Ledger (URN Authority)

Welcome to the **Central Authority**. This repository is the cryptographic source of truth for all URN-addressable capabilities within the CoReason Swarm Ecosystem. It maps abstract mathematical intent to physical, containerized Sovereign MCP (Model Context Protocol) Action Spaces.

## Documentation Architecture

This documentation is structured according to the [Diátaxis](https://diataxis.fr/) framework to serve both Human Oracles (Maintainers) and Enterprise Clients (Deployers).

### 🎓 [Tutorials](tutorials/scaffolding_first_urn.md)
*Learning-oriented paths for new Reasoning Engineers.*
- Scaffolding your first Sovereign URN.
- Executing the Human Oracle PR review process.

### 🛠️ [How-To Guides](guides/deploying_custom_client_urns.md)
*Action-oriented guides for daily operations.*
- **Enterprise Ops:** Deploying custom, air-gapped URNs to Client VPCs.
- Resolving AST Topological Faults in CI/CD.
- Updating Economic Ledgers and Billing Tiers.

### 🧠 [Explanation](architecture/the_epistemic_ledger.md)
*Understanding the Information Science behind the system.*
- The Tripartite Architecture (Why we decouple Identity from Execution).
- The 6 Universal Archetypes (Oracles, Solvers, Effectors, Substrates, Sensory, Nodes).
- Understanding the Quality Guillotines (WASM bounds & Canonical Sorting).

### 📖 [Reference](reference/manifest_specification.md)
*Information-oriented technical specs.*
- Exhaustive `manifest.yaml` Schema definition.
- Auto-generated API documentation for the active Registry matrix.

---
**Agentic Note:** Autonomous agents (`coreason-meta-engineering`) MUST consult `llms.txt` and `AGENTS.md` located in the root of the repository to internalize the mathematical constraints of the ledger before contributing.
