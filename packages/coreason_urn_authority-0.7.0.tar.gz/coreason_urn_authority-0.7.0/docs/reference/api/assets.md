# Assets API

This documentation exposes python payloads utilized within capability geometries.

::: assets
