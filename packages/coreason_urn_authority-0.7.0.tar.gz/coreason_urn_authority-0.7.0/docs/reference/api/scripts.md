# Scripts Documentation

::: compile_registry
