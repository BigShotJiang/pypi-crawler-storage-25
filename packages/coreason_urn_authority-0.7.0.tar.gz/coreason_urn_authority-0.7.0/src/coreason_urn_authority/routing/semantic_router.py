# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Semantic Router — Dynamic Intent Routing for the Sovereign LLM Proxy.

Implements the URN-Aware Semantic Router documented in the MCP External
Routing Doctrine (``08_mcp_external_routing_doctrine.md``).  Every MCP tool
invocation carries a target URN; this module classifies that URN by
*entropy class* and maps it to the most thermodynamically efficient
intelligence cluster.

Architecture
────────────
* **Low-Entropy Class** — Routine environment interactions (bash, file
  reads, grep).  Routed to internal, air-gapped vLLM clusters running
  sub-70B open-weight models for fast TTFT and zero external API cost.

* **High-Entropy Class** — Complex reasoning, AST mutation, MCTS
  deliberation, and escalation intents.  Routed to premium frontier
  model APIs (Anthropic, Google) or internal premium GPU clusters.

The router is a pure, deterministic function with zero side-effects.
It does not execute inference; it only *classifies and maps*.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

# ────────────────────────────────────────────────────────────────────
# Entropy Classification
# ────────────────────────────────────────────────────────────────────


class EntropyClass(StrEnum):
    """Shannon-inspired entropy classification for MCP tool invocations."""

    LOW = "LOW"
    HIGH = "HIGH"


class ClusterTier(StrEnum):
    """Physical intelligence cluster destinations.

    ``LOCAL_OPEN_WEIGHTS``
        Internal vLLM clusters running sub-70B open-weight models.
        Fast TTFT, zero external API cost, zero data-leakage risk.

    ``FRONTIER_MAAS``
        External premium model-as-a-service APIs (Anthropic, Google)
        or internal premium GPU clusters.  Maximum System 2 capacity.
    """

    LOCAL_OPEN_WEIGHTS = "LOCAL_OPEN_WEIGHTS"
    FRONTIER_MAAS = "FRONTIER_MAAS"


@dataclass(frozen=True, slots=True)
class RoutingDecision:
    """The deterministic output of the semantic router.

    Attributes:
        urn: The URN that was classified.
        entropy_class: Whether the URN is low- or high-entropy.
        cluster_tier: The physical cluster to route the request to.
    """

    urn: str
    entropy_class: EntropyClass
    cluster_tier: ClusterTier


# ────────────────────────────────────────────────────────────────────
# URN → Entropy Mapping (Static Policy)
# ────────────────────────────────────────────────────────────────────

_HIGH_ENTROPY_URNS: frozenset[str] = frozenset(
    {
        # Escalation intents — Forge-to-Claw handoffs
        "urn:coreason:actionspace:intent:escalation:v1",
        # AST mutation tools — complex spatial reasoning
        "urn:coreason:tool:ast_mutation",
        # MCTS thought nodes — strategic planning
        "urn:coreason:actionspace:solver:strategic_thought_node_intent:v1",
        # Claw Code developer solver — heuristic AI
        "urn:coreason:actionspace:solver:claw_developer:v1",
        # Strategic MCTS Oracle — cognitive coprocessor
        "urn:coreason:oracle:strategic_mcts",
        # Combinatorial logic oracle
        "urn:coreason:oracle:combinatorial_asp",
        # Defeasible logic oracle
        "urn:coreason:oracle:defeasible_logic",
    }
)

_LOW_ENTROPY_URNS: frozenset[str] = frozenset(
    {
        # Standard environment interactions
        "urn:coreason:tool:bash",
        "urn:coreason:tool:file_read",
        "urn:coreason:tool:file_write",
        "urn:coreason:tool:grep",
        "urn:coreason:tool:list_dir",
    }
)


def _classify_entropy(urn: str) -> EntropyClass:
    """Classify a URN into an entropy class.

    Explicit membership in the high-entropy set takes precedence.
    Explicit membership in the low-entropy set returns LOW.
    Unknown URNs default to HIGH (fail-safe: route to frontier to
    avoid capability degradation on novel tools).
    """
    if urn in _HIGH_ENTROPY_URNS:
        return EntropyClass.HIGH
    if urn in _LOW_ENTROPY_URNS:
        return EntropyClass.LOW
    # Heuristic: tool-class URNs that are not explicitly HIGH
    # are assumed to be routine environment interactions.
    if urn.startswith("urn:coreason:tool:"):
        return EntropyClass.LOW
    # Fail-safe: unknown URNs route to frontier.
    return EntropyClass.HIGH


# ────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────


def route(urn: str) -> RoutingDecision:
    """Classify a URN and return the deterministic routing decision.

    This function is the primary entry-point for the Sovereign LLM
    Proxy's request interceptor.

    Args:
        urn: The target Uniform Resource Name from the MCP payload.

    Returns:
        A ``RoutingDecision`` containing the entropy class and the
        target intelligence cluster.
    """
    entropy = _classify_entropy(urn)
    cluster = ClusterTier.FRONTIER_MAAS if entropy == EntropyClass.HIGH else ClusterTier.LOCAL_OPEN_WEIGHTS
    return RoutingDecision(urn=urn, entropy_class=entropy, cluster_tier=cluster)
