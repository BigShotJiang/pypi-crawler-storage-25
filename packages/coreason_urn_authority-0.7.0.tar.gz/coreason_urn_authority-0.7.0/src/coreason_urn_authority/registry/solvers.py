# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Solver Registry Matrix for the CoReason URN Authority.

This module defines the authoritative, typed registry of all solver URNs
and their structurally authorized emission geometries. Each solver entry
declares:

  - The solver's canonical URN.
  - The set of ``coreason-manifest`` ontological types (Intents, Receipts)
    that the solver is authorized to emit into the Merkle-DAG ledger.
  - The ``EpistemicClearance`` tier required to invoke the solver.

The registry is the static, compile-time source of truth consumed by the
``compile_registry.py`` AST parser and the runtime's MCP routing layer.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class EpistemicClearance(IntEnum):
    """Clearance tiers controlling solver invocation authorization.

    Each tier maps to a numeric value within the ``manifest.yaml``
    ``default_clearance_tiers`` range (0-255).  Using ``IntEnum``
    enables mathematical comparability for Zero-Trust authorization
    checks (e.g. ``if user.clearance >= solver.clearance``).
    """

    PUBLIC = 0
    INTERNAL = 100
    CONFIDENTIAL = 200
    RESTRICTED = 255


@dataclass(frozen=True, slots=True)
class SolverRegistryEntry:
    """An immutable, typed record in the Solver Registry Matrix.

    Attributes:
        urn: The solver's canonical Uniform Resource Name.
        authorized_emissions: Frozenset of fully-qualified ``coreason-manifest``
            class names (e.g. ``"StrategicThoughtNodeIntent"``) that this solver
            is structurally authorized to emit.
        clearance: The minimum epistemic clearance required to invoke the solver.
        description: A human-readable summary of the solver's purpose.
    """

    urn: str
    authorized_emissions: frozenset[str]
    clearance: EpistemicClearance
    description: str = ""


# ────────────────────────────────────────────────────────────────────
# The Canonical Solver Registry Matrix
# ────────────────────────────────────────────────────────────────────

_SOLVER_REGISTRY: dict[str, SolverRegistryEntry] = {}


def _register(entry: SolverRegistryEntry) -> None:
    """Register a solver entry, rejecting duplicates at import time."""
    if entry.urn in _SOLVER_REGISTRY:
        raise ValueError(f"Duplicate solver URN registration: {entry.urn}")
    _SOLVER_REGISTRY[entry.urn] = entry


# ── Clinical Extractor (existing) ──────────────────────────────────
_register(
    SolverRegistryEntry(
        urn="urn:coreason:actionspace:solver:clinical_extractor:v1",
        authorized_emissions=frozenset({"OracleExecutionReceipt"}),
        clearance=EpistemicClearance.CONFIDENTIAL,
        description=(
            "Extracts structured clinical entities from unstructured medical text using deterministic NLP pipelines."
        ),
    )
)

# ── Claw Code Developer Solver ─────────────────────────────────────
_register(
    SolverRegistryEntry(
        urn="urn:coreason:actionspace:solver:claw_developer:v1",
        authorized_emissions=frozenset(
            {
                "StrategicThoughtNodeIntent",
                "OracleExecutionReceipt",
            }
        ),
        clearance=EpistemicClearance.INTERNAL,
        description=(
            "High-entropy heuristic AI solver (Claw Code) for complex "
            "software engineering tasks. Operates within the Sovereign LLM "
            "Proxy perimeter and emits MCTS thought nodes for strategic "
            "planning via the deliberation envelope."
        ),
    )
)


# ────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────


def get_solver(urn: str) -> SolverRegistryEntry | None:
    """Look up a solver by its canonical URN.

    Returns ``None`` if the URN is not registered.
    """
    return _SOLVER_REGISTRY.get(urn)


def get_all_solvers() -> dict[str, SolverRegistryEntry]:
    """Return a read-only snapshot of the full solver registry."""
    return dict(_SOLVER_REGISTRY)


def is_emission_authorized(solver_urn: str, emission_type: str) -> bool:
    """Check whether a solver is authorized to emit a given ontological type.

    Args:
        solver_urn: The solver's canonical URN.
        emission_type: The ``coreason-manifest`` class name (e.g.
            ``"StrategicThoughtNodeIntent"``).

    Returns:
        ``True`` if the solver is registered and the emission type is in
        its ``authorized_emissions`` set; ``False`` otherwise.
    """
    entry = _SOLVER_REGISTRY.get(solver_urn)
    if entry is None:
        return False
    return emission_type in entry.authorized_emissions
