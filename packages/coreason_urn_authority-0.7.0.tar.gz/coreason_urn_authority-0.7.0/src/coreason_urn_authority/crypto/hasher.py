# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

import hashlib
from typing import Any

# Since coreason-manifest uses canonicaljson under the hood, we can either use it directly
# or implement a simple sorted serialization if it's not a direct dependency here.
import canonicaljson


def _encode_canonical(payload: dict[str, Any]) -> bytes:
    return canonicaljson.encode_canonical_json(payload)


class CIDGenerator:
    """Generates RFC-8785 canonical hashes for decentralized content addressing."""

    @staticmethod
    def generate_cid(payload: dict[str, Any]) -> str:
        """
        Generates a SHA-256 content identifier for a given payload using
        RFC-8785 Canonical JSON serialization.
        """
        canonical_bytes = _encode_canonical(payload)
        hash_hex = hashlib.sha256(canonical_bytes).hexdigest()
        return f"sha256:{hash_hex}"
