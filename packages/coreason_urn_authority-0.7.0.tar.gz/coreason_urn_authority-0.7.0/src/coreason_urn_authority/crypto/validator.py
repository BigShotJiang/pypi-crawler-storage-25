# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Cryptographic Receipt Validator for the URN Authority.

Defines deterministic validation rules for ``OracleExecutionReceipt``
objects submitted by solver agents.  The primary rule enforces that
receipts from the Claw Code solver (``claw_developer:v1``) must have
their ``tokens_burned`` audited against the ``ThermodynamicQuota``
ledger before the Content Identifier (CID) is legally sealed into the
Merkle-DAG.

This module is a pure validation layer -- it inspects and rejects; it
never mutates state.  The validator is bound directly to the
``coreason-manifest`` data plane type (``OracleExecutionReceipt``)
to guarantee compile-time safety across package boundaries.
"""

from __future__ import annotations

from dataclasses import dataclass

from coreason_manifest.spec.ontology import OracleExecutionReceipt

# ────────────────────────────────────────────────────────────────────
# Thermodynamic Quota Ledger (in-process stub)
# ────────────────────────────────────────────────────────────────────

_CLAW_DEVELOPER_URN = "urn:coreason:solver:claw_developer:v1"


@dataclass(frozen=True, slots=True)
class ThermodynamicQuota:
    """Defines the maximum token budget for a solver session.

    Attributes:
        solver_urn: The solver this quota applies to.
        max_tokens: The absolute ceiling on tokens_burned before the
            Sovereign LLM Proxy triggers a circuit breaker (HTTP 429).
    """

    solver_urn: str
    max_tokens: int


# Default quotas -- in production these are loaded from the
# coreason-ecosystem governance plane.
_DEFAULT_QUOTAS: dict[str, ThermodynamicQuota] = {
    _CLAW_DEVELOPER_URN: ThermodynamicQuota(
        solver_urn=_CLAW_DEVELOPER_URN,
        max_tokens=5_000_000,
    ),
}


# ────────────────────────────────────────────────────────────────────
# Validation Result
# ────────────────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class ReceiptValidationResult:
    """The result of validating an ``OracleExecutionReceipt``.

    Attributes:
        valid: ``True`` if all validation rules passed.
        violations: A tuple of human-readable violation descriptions.
            Empty when ``valid`` is ``True``.
    """

    valid: bool
    violations: tuple[str, ...]


# ────────────────────────────────────────────────────────────────────
# Validation Rules
# ────────────────────────────────────────────────────────────────────


def validate_receipt(
    receipt: OracleExecutionReceipt,
    quotas: dict[str, ThermodynamicQuota] | None = None,
) -> ReceiptValidationResult:
    """Validate an ``OracleExecutionReceipt`` before CID sealing.

    Performs the following deterministic checks:

    1. **Execution hash format** -- must be exactly 64 lowercase hex
       characters (SHA-256).
    2. **Token bounds** -- ``tokens_burned`` must be in ``[0, 10_000_000]``
       per the manifest schema bounds.
    3. **Thermodynamic quota audit** -- if the solver has a registered
       quota, ``tokens_burned`` must not exceed ``max_tokens``.

    Args:
        receipt: The ``OracleExecutionReceipt`` Pydantic object from
            ``coreason-manifest``.
        quotas: Optional override for the quota ledger (for testing).

    Returns:
        A ``ReceiptValidationResult`` with the outcome.
    """
    effective_quotas = quotas if quotas is not None else _DEFAULT_QUOTAS
    violations: list[str] = []

    # Rule 1: execution_hash format (defense-in-depth; Pydantic regex
    # enforces this at construction time)
    if len(receipt.execution_hash) != 64 or not all(c in "0123456789abcdef" for c in receipt.execution_hash):
        violations.append("Invalid execution_hash: expected 64 lowercase hex chars.")

    # Rule 2: tokens_burned schema bounds (defense-in-depth; Pydantic
    # ge/le constraints enforce this at construction time)
    if receipt.tokens_burned < 0 or receipt.tokens_burned > 10_000_000:
        violations.append(
            f"tokens_burned={receipt.tokens_burned} is outside the manifest schema bounds [0, 10_000_000]."
        )

    # Rule 3: Thermodynamic quota audit (solver-specific)
    quota = effective_quotas.get(receipt.solver_urn)
    if quota is not None and receipt.tokens_burned > quota.max_tokens:
        violations.append(
            f"Thermodynamic Quota Violation: solver '{receipt.solver_urn}' "
            f"burned {receipt.tokens_burned} tokens, exceeding the quota "
            f"ceiling of {quota.max_tokens}."
        )

    return ReceiptValidationResult(
        valid=len(violations) == 0,
        violations=tuple(violations),
    )
