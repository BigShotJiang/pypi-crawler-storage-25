# coreason-urn-authority

> **The Epistemic Ledger of the Tripartite Architecture**
> This repository acts as the central, cryptographic authority for all URN-addressable capabilities (Model Context Protocol servers) utilized by the CoReason runtime. It enforces strict topographical bounds, 95% test coverage guillotines, and WASM memory limits before capabilities can be dynamically projected into client VPCs.

[![CI/CD](https://github.com/CoReason-AI/coreason-urn-authority/actions/workflows/ci.yml/badge.svg)](https://github.com/CoReason-AI/coreason-urn-authority/actions/workflows/ci.yml)
[![PyPI](https://img.shields.io/pypi/v/coreason-urn-authority.svg)](https://pypi.org/project/coreason-urn-authority/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/coreason-urn-authority.svg)](https://pypi.org/project/coreason-urn-authority/)
[![License](https://img.shields.io/github/license/CoReason-AI/coreason-urn-authority)](https://github.com/CoReason-AI/coreason-urn-authority/blob/main/LICENSE)
[![Codecov](https://codecov.io/gh/CoReason-AI/coreason-urn-authority/branch/main/graph/badge.svg)](https://codecov.io/gh/CoReason-AI/coreason-urn-authority)
[![Downloads](https://static.pepy.tech/badge/coreason-urn-authority)](https://pepy.tech/project/coreason-urn-authority)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)

## Getting Started

### Prerequisites

- Python 3.14+
- uv

### Installation

1.  Clone the repository:
    ```sh
    git clone https://github.com/CoReason-AI/coreason-urn-authority.git
    cd coreason-urn-authority
    ```
2.  Install dependencies:
    ```sh
    uv sync --all-extras --dev
    ```

### Usage

-   Run the linter:
    ```sh
    uv run pre-commit run --all-files
    ```
-   Run the tests:
    ```sh
    uv run pytest
    ```
