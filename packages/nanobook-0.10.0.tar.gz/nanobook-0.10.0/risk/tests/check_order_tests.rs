// Allow our dollar.cents digit grouping convention (e.g., 100_00 = $100.00)
#![allow(clippy::inconsistent_digit_grouping)]

//! Tests for RiskEngine::check_order — currently has ZERO tests.

use nanobook::Symbol;
use nanobook_broker::{Account, BrokerSide};
use nanobook_risk::{RiskConfig, RiskEngine, RiskStatus};

fn aapl() -> Symbol {
    Symbol::new("AAPL")
}

fn account(equity: i64) -> Account {
    Account {
        equity_cents: equity,
        buying_power_cents: equity,
        cash_cents: equity,
        gross_position_value_cents: 0,
    }
}

fn engine() -> RiskEngine {
    RiskEngine::new(RiskConfig {
        max_position_pct: 0.25,
        max_trade_usd: 50_000.0,
        ..RiskConfig::default()
    })
    .expect("test RiskConfig is valid")
}

// ============================================================================
// Basic pass/fail
// ============================================================================

#[test]
fn small_order_passes() {
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Buy,
        10,
        150_00,
        &account(10_000_000), // $100K equity
        &[],
    );
    assert!(!report.has_failures());
}

#[test]
fn large_position_fails() {
    // 500 shares * $150 = $75K = 75% of $100K equity > 25% limit
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Buy,
        500,
        150_00,
        &account(10_000_000),
        &[],
    );
    assert!(report.has_failures());
}

#[test]
fn boundary_exactly_at_limit_passes() {
    // 25% of $100K = $25K. 166 shares * $150.50 ≈ $24,983 < 25%
    // We need exact: 25% of 10_000_000 = 2_500_000 cents
    // 2_500_000 / 150_00 = 166.67 → 166 shares → 166*15000=2_490_000 → 24.9% → Pass
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Buy,
        166,
        150_00,
        &account(10_000_000),
        &[],
    );
    assert!(!report.has_failures());
}

#[test]
fn boundary_one_share_over_fails() {
    // 167 shares * $150 = $25,050 → 25.05% > 25% → Fail
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Buy,
        167,
        150_00,
        &account(10_000_000),
        &[],
    );
    assert!(report.has_failures());
}

// ============================================================================
// Existing position affects check
// ============================================================================

#[test]
fn buy_increases_existing_long() {
    // Already have 100 shares long. Buying 100 more → 200 * $150 = $30K → 30% > 25% → Fail
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Buy,
        100,
        150_00,
        &account(10_000_000),
        &[(aapl(), 100)],
    );
    assert!(report.has_failures());
}

#[test]
fn sell_reduces_existing_long() {
    // Have 200 shares long. Selling 100 → 100 * $150 = $15K → 15% < 25% → Pass
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Sell,
        100,
        150_00,
        &account(10_000_000),
        &[(aapl(), 200)],
    );
    assert!(!report.has_failures());
}

// ============================================================================
// Short selling checks
// ============================================================================

#[test]
fn short_allowed_passes() {
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Sell,
        10,
        150_00,
        &account(10_000_000),
        &[], // selling from flat = going short
    );
    // Default allows short
    assert!(!report.has_failures());
}

#[test]
fn short_not_allowed_fails() {
    let eng = RiskEngine::new(RiskConfig {
        max_position_pct: 0.25,
        allow_short: false,
        ..RiskConfig::default()
    })
    .expect("test RiskConfig is valid");
    let report = eng.check_order(
        &aapl(),
        BrokerSide::Sell,
        10,
        150_00,
        &account(10_000_000),
        &[], // this creates a short
    );
    assert!(report.has_failures());
}

// ============================================================================
// Zero equity / zero quantity / zero price
// ============================================================================

#[test]
fn zero_equity_does_not_panic() {
    let report = engine().check_order(&aapl(), BrokerSide::Buy, 10, 150_00, &account(0), &[]);
    // Should not panic; position check defaults to 0%
    assert!(!report.has_failures());
}

#[test]
fn zero_quantity_does_not_panic() {
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Buy,
        0,
        150_00,
        &account(10_000_000),
        &[],
    );
    assert!(!report.has_failures());
}

#[test]
fn zero_price_does_not_panic() {
    let report = engine().check_order(&aapl(), BrokerSide::Buy, 100, 0, &account(10_000_000), &[]);
    assert!(!report.has_failures());
}

// ============================================================================
// Order size warnings
// ============================================================================

#[test]
fn large_order_warns() {
    // 1000 shares * $150 = $150K > $50K max_trade_usd → Warn
    let report = engine().check_order(
        &aapl(),
        BrokerSide::Buy,
        1000,
        150_00,
        &account(100_000_000), // $1M equity (so position % is fine)
        &[],
    );
    assert!(report.has_warnings());
}

#[test]
fn large_order_fails_order_value() {
    let report = RiskEngine::new(RiskConfig {
        max_position_pct: 0.25,
        max_trade_usd: 100_000.0,
        max_order_value_cents: 10_000,
        ..RiskConfig::default()
    })
    .expect("test RiskConfig is valid")
    .check_order(
        &aapl(),
        BrokerSide::Buy,
        1000,
        150_00,
        &account(100_000_000),
        &[],
    );

    assert!(report.has_failures());
    let order_limit = report
        .checks
        .iter()
        .find(|r| r.name == "Max order value")
        .unwrap();
    assert_eq!(order_limit.status, RiskStatus::Fail);
}

#[test]
fn large_order_passes_order_value_boundary() {
    let report = RiskEngine::new(RiskConfig {
        max_position_pct: 0.25,
        max_trade_usd: 100_000.0,
        max_order_value_cents: 10_000,
        ..RiskConfig::default()
    })
    .expect("test RiskConfig is valid")
    .check_order(
        &aapl(),
        BrokerSide::Buy,
        50,
        200,
        &account(100_000_000),
        &[],
    );

    assert!(!report.has_failures());
    let order_limit = report
        .checks
        .iter()
        .find(|r| r.name == "Max order value")
        .unwrap();
    assert_eq!(order_limit.status, RiskStatus::Pass);
    assert_eq!(order_limit.detail, "$100 <= $100 max_order_value_cents");
}

#[test]
fn check_order_reports_expected_check_names() {
    let report = RiskEngine::new(RiskConfig {
        max_position_pct: 0.25,
        max_trade_usd: 100_000.0,
        max_order_value_cents: 10_000,
        ..RiskConfig::default()
    })
    .expect("test RiskConfig is valid")
    .check_order(
        &aapl(),
        BrokerSide::Buy,
        50,
        200,
        &account(100_000_000),
        &[],
    );

    let names: Vec<_> = report.checks.iter().map(|c| c.name).collect();
    assert!(names.contains(&"Max order value"));
    assert!(names.contains(&"Max position"));
    assert!(names.contains(&"Order size"));
}

// ============================================================================
// RiskConfig::validate
// ============================================================================

#[test]
fn default_config_validates() {
    assert!(RiskConfig::default().validate().is_ok());
}

#[test]
fn nan_max_position_fails_validation() {
    let config = RiskConfig {
        max_position_pct: f64::NAN,
        ..RiskConfig::default()
    };
    assert!(config.validate().is_err());
}

#[test]
fn inf_max_leverage_fails_validation() {
    let config = RiskConfig {
        max_leverage: f64::INFINITY,
        ..RiskConfig::default()
    };
    assert!(config.validate().is_err());
}

#[test]
fn negative_max_drawdown_fails_validation() {
    let config = RiskConfig {
        max_drawdown_pct: -0.01,
        ..RiskConfig::default()
    };
    assert!(config.validate().is_err());
}

#[test]
fn zero_max_position_fails_validation() {
    let config = RiskConfig {
        max_position_pct: 0.0,
        ..RiskConfig::default()
    };
    assert!(config.validate().is_err());
}

#[test]
fn negative_max_order_value_cents_fails_validation() {
    let config = RiskConfig {
        max_order_value_cents: -1,
        ..RiskConfig::default()
    };
    assert!(config.validate().is_err());
}

#[test]
fn negative_max_batch_value_cents_fails_validation() {
    let config = RiskConfig {
        max_batch_value_cents: -1,
        ..RiskConfig::default()
    };
    assert!(config.validate().is_err());
}

#[test]
fn leverage_below_one_fails_validation() {
    let config = RiskConfig {
        max_leverage: 0.5,
        ..RiskConfig::default()
    };
    assert!(config.validate().is_err());
}

#[test]
fn boundary_values_validate() {
    let config = RiskConfig {
        max_position_pct: 1.0, // exactly 100%
        max_leverage: 1.0,     // exactly 1x
        max_drawdown_pct: 0.0, // zero drawdown allowed
        max_short_pct: 0.0,    // no short allowed
        min_trade_usd: 0.0,    // zero minimum
        max_trade_usd: 0.0,    // zero maximum
        ..RiskConfig::default()
    };
    assert!(config.validate().is_ok());
}

/// Regression for S5: `RiskEngine::new` no longer panics on an
/// invalid config. It now returns `RiskError::InvalidConfig(msg)`
/// whose message includes the offending field name — important so
/// users loading configs from files get an actionable error instead
/// of a stack trace.
#[test]
fn risk_engine_returns_err_on_invalid_config() {
    let config = RiskConfig {
        max_position_pct: f64::NAN,
        ..RiskConfig::default()
    };
    let err = RiskEngine::new(config).expect_err("NaN max_position_pct should reject");
    match err {
        nanobook_risk::RiskError::InvalidConfig(msg) => {
            assert!(
                msg.contains("max_position_pct"),
                "error should mention the offending field, got {msg:?}"
            );
        }
    }
}

/// A valid config round-trips to `Ok`. Sanity test to bracket the
/// invalid-config case.
#[test]
fn risk_engine_accepts_valid_config() {
    assert!(
        RiskEngine::new(RiskConfig::default()).is_ok(),
        "default RiskConfig must be valid"
    );
}
