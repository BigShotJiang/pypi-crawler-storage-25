"""Abstract base provider for CalDAV calendar operations.

All providers inherit from BaseProvider and can override methods
for provider-specific behavior (URL construction, auth quirks, etc.).

Uses only the Python standard library — no caldav/icalendar packages.
Communicates with CalDAV servers via raw HTTP (urllib) and XML (xml.etree).
"""

from __future__ import annotations

import re
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from base64 import b64encode
from datetime import date, datetime, timedelta, timezone
from typing import Any

from ..config import Config
from ..utils import (
    build_vcalendar,
    build_vevent,
    events_in_range,
    format_datetime,
    parse_iso_datetime,
    parse_vevent,
)

# CalDAV XML namespaces
DAV_NS = "DAV:"
CALDAV_NS = "urn:ietf:params:xml:ns:caldav"
CS_NS = "http://calendarserver.org/ns/"

NS_MAP = {
    "d": DAV_NS,
    "c": CALDAV_NS,
    "cs": CS_NS,
}


def _register_namespaces() -> None:
    """Register XML namespaces for clean output."""
    for prefix, uri in NS_MAP.items():
        ET.register_namespace(prefix, uri)


_register_namespaces()


class BaseProvider:
    """Base CalDAV provider with standard operations.

    Subclasses can override:
        - _build_principal_url(): for custom principal URL discovery
        - _build_calendar_home_url(): for custom calendar home URL
        - _calendar_url(): for custom calendar URL construction
        - _auth_headers(): for custom authentication
    """

    def __init__(self, config: Config) -> None:
        self.config = config
        self._calendar_cache: dict[str, dict[str, str]] | None = None

    def _auth_headers(self) -> dict[str, str]:
        """Build HTTP Basic Auth headers."""
        credentials = f"{self.config.username}:{self.config.password}"
        encoded = b64encode(credentials.encode()).decode()
        return {
            "Authorization": f"Basic {encoded}",
            "Content-Type": "application/xml; charset=utf-8",
        }

    def _request(
        self,
        method: str,
        url: str,
        body: str | None = None,
        extra_headers: dict[str, str] | None = None,
        content_type: str | None = None,
    ) -> tuple[int, str, dict[str, str]]:
        """Make an HTTP request to the CalDAV server.

        Returns (status_code, response_body, response_headers).
        """
        headers = self._auth_headers()
        if extra_headers:
            headers.update(extra_headers)
        if content_type:
            headers["Content-Type"] = content_type

        data = body.encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                resp_body = resp.read().decode("utf-8", errors="replace")
                resp_headers = dict(resp.headers)
                return resp.status, resp_body, resp_headers
        except urllib.error.HTTPError as e:
            resp_body = e.read().decode("utf-8", errors="replace") if e.fp else ""
            return e.code, resp_body, dict(e.headers) if e.headers else {}

    def _propfind(self, url: str, body: str, depth: str = "0") -> tuple[int, str]:
        """Send a PROPFIND request."""
        status, resp_body, _ = self._request(
            "PROPFIND",
            url,
            body=body,
            extra_headers={"Depth": depth},
        )
        return status, resp_body

    def _report(self, url: str, body: str, depth: str = "1") -> tuple[int, str]:
        """Send a REPORT request."""
        status, resp_body, _ = self._request(
            "REPORT",
            url,
            body=body,
            extra_headers={"Depth": depth},
        )
        return status, resp_body

    # ------------------------------------------------------------------
    # URL construction (override in subclasses)
    # ------------------------------------------------------------------

    def _principal_url(self) -> str:
        """Get the principal URL for the authenticated user."""
        return self.config.url

    def _calendar_home_url(self) -> str | None:
        """Discover the calendar home set URL via PROPFIND.

        Returns None if discovery fails.
        """
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">'
            "<d:prop>"
            "<c:calendar-home-set/>"
            "</d:prop>"
            "</d:propfind>"
        )
        status, resp_body = self._propfind(self._principal_url(), body, depth="0")
        if status not in (200, 207):
            return None

        # Parse the multistatus response
        try:
            root = ET.fromstring(resp_body)
            href_elem = root.find(f".//{{{CALDAV_NS}}}calendar-home-set/{{{DAV_NS}}}href")
            if href_elem is not None and href_elem.text:
                href = href_elem.text
                if href.startswith("/"):
                    # Relative URL — combine with base
                    parsed = urllib.parse.urlparse(self.config.url)
                    return f"{parsed.scheme}://{parsed.netloc}{href}"
                return href
        except ET.ParseError:
            pass

        return None

    def _discover_calendars_from_home(self, home_url: str) -> list[dict[str, str]]:
        """List calendars under a calendar-home-set URL via PROPFIND."""
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav" '
            'xmlns:cs="http://calendarserver.org/ns/">'
            "<d:prop>"
            "<d:displayname/>"
            "<d:resourcetype/>"
            "<cs:getctag/>"
            "</d:prop>"
            "</d:propfind>"
        )
        status, resp_body = self._propfind(home_url, body, depth="1")
        if status not in (200, 207):
            return []

        calendars: list[dict[str, str]] = []
        try:
            root = ET.fromstring(resp_body)
            for response in root.findall(f"{{{DAV_NS}}}response"):
                href_elem = response.find(f"{{{DAV_NS}}}href")
                if href_elem is None or not href_elem.text:
                    continue

                # Check if this is a calendar resource
                resourcetype = response.find(
                    f".//{{{DAV_NS}}}resourcetype/{{{CALDAV_NS}}}calendar"
                )
                if resourcetype is None:
                    continue

                displayname_elem = response.find(f".//{{{DAV_NS}}}displayname")
                name = displayname_elem.text if displayname_elem is not None and displayname_elem.text else ""

                href = href_elem.text
                if href.startswith("/"):
                    parsed = urllib.parse.urlparse(self.config.url)
                    href = f"{parsed.scheme}://{parsed.netloc}{href}"

                ctag_elem = response.find(f".//{{{CS_NS}}}getctag")
                ctag = ctag_elem.text if ctag_elem is not None and ctag_elem.text else ""

                calendars.append({
                    "url": href,
                    "name": name,
                    "ctag": ctag,
                })
        except ET.ParseError:
            pass

        return calendars

    def _get_calendar_url(self, calendar_id: str = "") -> str:
        """Get the URL for a specific calendar, or the default one.

        If calendar_id is provided, tries to match by name or URL.
        Otherwise uses the configured default or the first discovered calendar.
        """
        cal_id = calendar_id or self.config.calendar_id

        if self._calendar_cache is None:
            home = self._calendar_home_url()
            if home:
                cals = self._discover_calendars_from_home(home)
                self._calendar_cache = {c["name"]: c for c in cals}
                if not self._calendar_cache:
                    self._calendar_cache = {c["url"]: c for c in cals}
            else:
                self._calendar_cache = {}

        # Try to find by name
        if cal_id and cal_id in self._calendar_cache:
            return self._calendar_cache[cal_id]["url"]

        # Try to find by partial URL match
        if cal_id:
            for cal_info in self._calendar_cache.values():
                if cal_id in cal_info.get("url", "") or cal_id in cal_info.get("name", ""):
                    return cal_info["url"]

        # Fall back to first calendar
        if self._calendar_cache:
            first = next(iter(self._calendar_cache.values()))
            return first["url"]

        # Last resort: use the base URL
        return self.config.url

    # ------------------------------------------------------------------
    # Event retrieval
    # ------------------------------------------------------------------

    def _fetch_events_raw(
        self,
        calendar_url: str,
        time_range_start: datetime | None = None,
        time_range_end: datetime | None = None,
    ) -> list[str]:
        """Fetch raw iCalendar event data from a calendar.

        Uses a calendar-query REPORT if a time range is specified,
        otherwise falls back to PROPFIND + GET.

        Returns a list of raw iCalendar text blocks (each containing a VEVENT).
        """
        if time_range_start and time_range_end:
            start_str = time_range_start.strftime("%Y%m%dT%H%M%SZ")
            end_str = time_range_end.strftime("%Y%m%dT%H%M%SZ")

            body = (
                '<?xml version="1.0" encoding="UTF-8"?>'
                '<c:calendar-query xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">'
                "<d:prop>"
                "<d:getetag/>"
                "<c:calendar-data/>"
                "</d:prop>"
                "<c:filter>"
                '<c:comp-filter name="VCALENDAR">'
                '<c:comp-filter name="VEVENT">'
                f'<c:time-range start="{start_str}" end="{end_str}"/>'
                "</c:comp-filter>"
                "</c:comp-filter>"
                "</c:filter>"
                "</c:calendar-query>"
            )
            status, resp_body = self._report(calendar_url, body, depth="1")
        else:
            # No time range — get all events
            body = (
                '<?xml version="1.0" encoding="UTF-8"?>'
                '<c:calendar-query xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">'
                "<d:prop>"
                "<d:getetag/>"
                "<c:calendar-data/>"
                "</d:prop>"
                "<c:filter>"
                '<c:comp-filter name="VCALENDAR">'
                '<c:comp-filter name="VEVENT"/>'
                "</c:comp-filter>"
                "</c:filter>"
                "</c:calendar-query>"
            )
            status, resp_body = self._report(calendar_url, body, depth="1")

        if status not in (200, 207):
            return []

        # Parse multistatus response to extract calendar-data
        events: list[str] = []
        try:
            root = ET.fromstring(resp_body)
            for cal_data in root.iter(f"{{{CALDAV_NS}}}calendar-data"):
                if cal_data.text:
                    events.append(cal_data.text)
        except ET.ParseError:
            pass

        return events

    def _parse_events(self, raw_events: list[str]) -> list[dict[str, Any]]:
        """Parse a list of raw iCalendar strings into structured event dicts."""
        parsed: list[dict[str, Any]] = []
        for ical_text in raw_events:
            # Extract VEVENT blocks (there might be multiple in one calendar object)
            vevent_blocks = re.findall(
                r"BEGIN:VEVENT.*?END:VEVENT",
                ical_text,
                re.DOTALL,
            )
            for block in vevent_blocks:
                event = parse_vevent(block)
                if event.get("summary") or event.get("uid"):
                    parsed.append(event)
        return parsed

    # ------------------------------------------------------------------
    # High-level operations (used by MCP tools)
    # ------------------------------------------------------------------

    def list_calendars(self) -> dict[str, Any]:
        """List all calendars available on the account."""
        home = self._calendar_home_url()
        if not home:
            return {"error": "Could not discover calendar home", "calendars": []}

        calendars = self._discover_calendars_from_home(home)
        # Cache for later use
        self._calendar_cache = {c["name"]: c for c in calendars}

        return {
            "account": self.config.username,
            "provider": self.config.provider,
            "calendars": [
                {"name": c["name"], "url": c["url"]}
                for c in calendars
            ],
            "count": len(calendars),
        }

    def get_events(
        self,
        calendar_id: str = "",
        days_ahead: int = 7,
        days_back: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Get events from a calendar within a date range.

        Args:
            calendar_id: Calendar name or URL (default: first/configured calendar)
            days_ahead: Number of days into the future (default: 7)
            days_back: Number of days into the past (default: 0)
            limit: Maximum events to return (default: 50)
        """
        cal_url = self._get_calendar_url(calendar_id)

        now = datetime.now(timezone.utc)
        start = now - timedelta(days=days_back)
        end = now + timedelta(days=days_ahead)

        raw = self._fetch_events_raw(cal_url, start, end)
        events = self._parse_events(raw)

        # Sort by start time
        events.sort(key=lambda e: e.get("dtstart", ""))

        # Apply limit
        events = events[:limit]

        return {
            "events": events,
            "count": len(events),
            "range_start": format_datetime(start),
            "range_end": format_datetime(end),
            "calendar": calendar_id or "(default)",
        }

    def get_event(self, uid: str, calendar_id: str = "") -> dict[str, Any]:
        """Get a single event by its UID.

        Args:
            uid: The event's unique identifier
            calendar_id: Calendar name or URL
        """
        cal_url = self._get_calendar_url(calendar_id)

        # Fetch all events and filter (CalDAV doesn't have a great UID-based query)
        raw = self._fetch_events_raw(cal_url)
        events = self._parse_events(raw)

        for event in events:
            if event.get("uid") == uid:
                return event

        return {"error": f"Event with UID '{uid}' not found"}

    def search_events(
        self,
        query: str,
        calendar_id: str = "",
        days_ahead: int = 30,
        days_back: int = 30,
        limit: int = 20,
    ) -> dict[str, Any]:
        """Search events by text in summary, description, or location.

        Args:
            query: Search text
            calendar_id: Calendar name or URL
            days_ahead: Days into the future to search
            days_back: Days into the past to search
            limit: Maximum results
        """
        cal_url = self._get_calendar_url(calendar_id)

        now = datetime.now(timezone.utc)
        start = now - timedelta(days=days_back)
        end = now + timedelta(days=days_ahead)

        raw = self._fetch_events_raw(cal_url, start, end)
        events = self._parse_events(raw)

        # Filter by query (case-insensitive)
        query_lower = query.lower()
        matches: list[dict[str, Any]] = []
        for event in events:
            searchable = " ".join([
                event.get("summary", ""),
                event.get("description", ""),
                event.get("location", ""),
            ]).lower()
            if query_lower in searchable:
                matches.append(event)

        matches.sort(key=lambda e: e.get("dtstart", ""))
        matches = matches[:limit]

        return {
            "events": matches,
            "count": len(matches),
            "query": query,
        }

    def today(self, calendar_id: str = "") -> dict[str, Any]:
        """Get today's events.

        Args:
            calendar_id: Calendar name or URL
        """
        cal_url = self._get_calendar_url(calendar_id)

        now = datetime.now(timezone.utc)
        start = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
        end = start + timedelta(days=1)

        raw = self._fetch_events_raw(cal_url, start, end)
        events = self._parse_events(raw)
        events.sort(key=lambda e: e.get("dtstart", ""))

        return {
            "events": events,
            "count": len(events),
            "date": start.strftime("%Y-%m-%d"),
            "calendar": calendar_id or "(default)",
        }

    def upcoming(
        self,
        calendar_id: str = "",
        hours: int = 4,
        limit: int = 10,
    ) -> dict[str, Any]:
        """Get upcoming events in the next N hours.

        Args:
            calendar_id: Calendar name or URL
            hours: Hours ahead to look (default: 4)
            limit: Maximum events
        """
        cal_url = self._get_calendar_url(calendar_id)

        now = datetime.now(timezone.utc)
        end = now + timedelta(hours=hours)

        raw = self._fetch_events_raw(cal_url, now, end)
        events = self._parse_events(raw)
        events.sort(key=lambda e: e.get("dtstart", ""))
        events = events[:limit]

        return {
            "events": events,
            "count": len(events),
            "range_hours": hours,
        }

    def create_event(
        self,
        summary: str,
        start: str,
        end: str | None = None,
        description: str = "",
        location: str = "",
        all_day: bool = False,
        calendar_id: str = "",
    ) -> dict[str, Any]:
        """Create a new calendar event.

        Args:
            summary: Event title
            start: Start datetime in ISO 8601 format (e.g., "2026-04-13T10:30")
            end: End datetime (default: start + 1 hour, or + 1 day for all-day)
            description: Event description
            location: Event location
            all_day: Whether this is an all-day event
            calendar_id: Calendar name or URL
        """
        cal_url = self._get_calendar_url(calendar_id)

        dtstart = parse_iso_datetime(start)
        dtend = parse_iso_datetime(end) if end else None

        uid = f"{__import__('uuid').uuid4()}@calendar-mcp"

        vevent = build_vevent(
            summary=summary,
            dtstart=dtstart,
            dtend=dtend,
            description=description,
            location=location,
            uid=uid,
            all_day=all_day,
        )
        vcal = build_vcalendar([vevent])

        # PUT the event to the CalDAV server
        event_url = cal_url.rstrip("/") + f"/{uid}.ics"
        status, resp_body, _ = self._request(
            "PUT",
            event_url,
            body=vcal,
            content_type="text/calendar; charset=utf-8",
            extra_headers={"If-None-Match": "*"},
        )

        if status in (200, 201, 204):
            return {
                "created": True,
                "uid": uid,
                "summary": summary,
                "start": format_datetime(dtstart),
                "end": format_datetime(dtend) if dtend else "",
            }

        return {
            "error": f"Failed to create event (HTTP {status})",
            "detail": resp_body[:500],
        }

    def update_event(
        self,
        uid: str,
        summary: str | None = None,
        start: str | None = None,
        end: str | None = None,
        description: str | None = None,
        location: str | None = None,
        calendar_id: str = "",
    ) -> dict[str, Any]:
        """Update an existing calendar event.

        Only provided fields are changed. The event is identified by UID.

        Args:
            uid: Event UID to update
            summary: New title (or None to keep current)
            start: New start datetime in ISO 8601
            end: New end datetime in ISO 8601
            description: New description
            location: New location
            calendar_id: Calendar name or URL
        """
        # First, fetch the current event
        existing = self.get_event(uid, calendar_id)
        if "error" in existing:
            return existing

        # Merge changes
        new_summary = summary if summary is not None else existing.get("summary", "")
        new_description = description if description is not None else existing.get("description", "")
        new_location = location if location is not None else existing.get("location", "")

        if start:
            new_start = parse_iso_datetime(start)
        else:
            dtstart_str = existing.get("dtstart", "")
            if dtstart_str:
                new_start = parse_iso_datetime(dtstart_str)
            else:
                return {"error": "Cannot determine event start time"}

        if end:
            new_end = parse_iso_datetime(end)
        else:
            dtend_str = existing.get("dtend", "")
            if dtend_str:
                new_end = parse_iso_datetime(dtend_str)
            else:
                new_end = None

        all_day = existing.get("all_day", False)

        vevent = build_vevent(
            summary=new_summary,
            dtstart=new_start,
            dtend=new_end,
            description=new_description,
            location=new_location,
            uid=uid,
            all_day=all_day,
        )
        vcal = build_vcalendar([vevent])

        cal_url = self._get_calendar_url(calendar_id)
        event_url = cal_url.rstrip("/") + f"/{uid}.ics"

        status, resp_body, _ = self._request(
            "PUT",
            event_url,
            body=vcal,
            content_type="text/calendar; charset=utf-8",
        )

        if status in (200, 201, 204):
            return {
                "updated": True,
                "uid": uid,
                "summary": new_summary,
                "start": format_datetime(new_start),
                "end": format_datetime(new_end) if new_end else "",
            }

        return {
            "error": f"Failed to update event (HTTP {status})",
            "detail": resp_body[:500],
        }

    def delete_event(self, uid: str, calendar_id: str = "") -> dict[str, Any]:
        """Delete a calendar event by UID.

        Args:
            uid: Event UID to delete
            calendar_id: Calendar name or URL
        """
        cal_url = self._get_calendar_url(calendar_id)
        event_url = cal_url.rstrip("/") + f"/{uid}.ics"

        status, resp_body, _ = self._request("DELETE", event_url)

        if status in (200, 204):
            return {"deleted": True, "uid": uid}

        if status == 404:
            return {"error": f"Event '{uid}' not found", "uid": uid}

        return {
            "error": f"Failed to delete event (HTTP {status})",
            "detail": resp_body[:500],
        }

    def free_busy(
        self,
        calendar_id: str = "",
        days_ahead: int = 7,
    ) -> dict[str, Any]:
        """Get a free/busy summary for the next N days.

        Returns blocks of busy time and total free/busy hours.

        Args:
            calendar_id: Calendar name or URL
            days_ahead: Days to look ahead (default: 7)
        """
        result = self.get_events(
            calendar_id=calendar_id,
            days_ahead=days_ahead,
            days_back=0,
            limit=200,
        )

        events = result.get("events", [])
        busy_blocks: list[dict[str, str]] = []

        for event in events:
            if event.get("all_day"):
                continue
            if event.get("dtstart") and event.get("dtend"):
                busy_blocks.append({
                    "start": event["dtstart"],
                    "end": event["dtend"],
                    "summary": event.get("summary", ""),
                })

        # Calculate total busy minutes
        total_busy_minutes = 0
        for block in busy_blocks:
            try:
                s = datetime.fromisoformat(block["start"])
                e = datetime.fromisoformat(block["end"])
                total_busy_minutes += int((e - s).total_seconds() / 60)
            except (ValueError, TypeError):
                pass

        total_hours = days_ahead * 24
        busy_hours = total_busy_minutes / 60
        free_hours = total_hours - busy_hours

        return {
            "busy_blocks": busy_blocks,
            "busy_count": len(busy_blocks),
            "busy_hours": round(busy_hours, 1),
            "free_hours": round(free_hours, 1),
            "days": days_ahead,
        }
