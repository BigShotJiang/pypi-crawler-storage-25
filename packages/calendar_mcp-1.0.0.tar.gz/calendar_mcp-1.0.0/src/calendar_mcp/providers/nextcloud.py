"""Nextcloud/ownCloud CalDAV provider.

Nextcloud CalDAV:
- URL pattern: https://{host}/remote.php/dav/
- Principal: /remote.php/dav/principals/users/{username}/
- Calendar home: /remote.php/dav/calendars/{username}/
- Supports app passwords
"""

from __future__ import annotations

import urllib.parse

from .base import BaseProvider


class NextcloudProvider(BaseProvider):
    """Nextcloud/ownCloud CalDAV provider."""

    def _principal_url(self) -> str:
        """Nextcloud principal URL follows a known pattern."""
        parsed = urllib.parse.urlparse(self.config.url)
        username = urllib.parse.quote(self.config.username)
        return f"{parsed.scheme}://{parsed.netloc}/remote.php/dav/principals/users/{username}/"

    def _calendar_home_url(self) -> str | None:
        """Nextcloud calendar home follows a known pattern."""
        parsed = urllib.parse.urlparse(self.config.url)
        username = urllib.parse.quote(self.config.username)
        return f"{parsed.scheme}://{parsed.netloc}/remote.php/dav/calendars/{username}/"
