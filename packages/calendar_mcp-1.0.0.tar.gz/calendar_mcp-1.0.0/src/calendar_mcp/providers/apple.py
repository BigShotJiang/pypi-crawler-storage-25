"""Apple iCloud CalDAV provider.

Apple's CalDAV implementation:
- URL: https://caldav.icloud.com/
- Requires app-specific password (generated at appleid.apple.com)
- Principal discovery via PROPFIND on base URL
- Calendar home returned with numeric user ID in path
"""

from __future__ import annotations

from .base import BaseProvider


class AppleProvider(BaseProvider):
    """Apple iCloud CalDAV provider."""

    def _principal_url(self) -> str:
        """Apple uses standard PROPFIND discovery from base URL."""
        return "https://caldav.icloud.com/"
