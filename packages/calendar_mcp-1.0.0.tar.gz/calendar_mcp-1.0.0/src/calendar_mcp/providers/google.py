"""Google Calendar CalDAV provider.

Google's CalDAV implementation has specific URL patterns and quirks:
- Principal URL: https://apidata.googleusercontent.com/caldav/v2/{email}/
- Calendar home: same as principal
- Calendar URLs: https://apidata.googleusercontent.com/caldav/v2/{email}/events/
- Requires app-specific password (not regular Google password)
- Uses OAuth2 for production (app passwords for personal use)
"""

from __future__ import annotations

import urllib.parse

from .base import BaseProvider


class GoogleProvider(BaseProvider):
    """Google Calendar CalDAV provider."""

    def _principal_url(self) -> str:
        """Google's principal URL is user-specific."""
        base = "https://apidata.googleusercontent.com/caldav/v2/"
        return f"{base}{urllib.parse.quote(self.config.username)}/"

    def _calendar_home_url(self) -> str | None:
        """Google's calendar home is the same as the principal URL."""
        return self._principal_url()
