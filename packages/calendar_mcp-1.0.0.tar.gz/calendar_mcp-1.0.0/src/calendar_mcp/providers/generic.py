"""Generic CalDAV provider — works with any standard CalDAV server."""

from __future__ import annotations

from .base import BaseProvider


class GenericProvider(BaseProvider):
    """Generic CalDAV provider with no special handling.

    Works with any CalDAV server that follows RFC 4791.
    Used as the fallback when no specific provider is detected.
    Also used for Radicale, Baikal, and other self-hosted servers.
    """

    pass
