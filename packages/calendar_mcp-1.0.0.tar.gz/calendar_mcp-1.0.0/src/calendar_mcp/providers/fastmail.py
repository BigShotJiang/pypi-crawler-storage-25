"""Fastmail CalDAV provider.

Fastmail CalDAV:
- URL: https://caldav.fastmail.com/dav/calendars/user/{email}/
- Uses app-specific passwords
- Standard CalDAV with good RFC compliance
"""

from __future__ import annotations

import urllib.parse

from .base import BaseProvider


class FastmailProvider(BaseProvider):
    """Fastmail CalDAV provider."""

    def _principal_url(self) -> str:
        """Fastmail principal URL uses the email address."""
        email = urllib.parse.quote(self.config.username)
        return f"https://caldav.fastmail.com/dav/principals/user/{email}/"

    def _calendar_home_url(self) -> str | None:
        """Fastmail calendar home uses the email address."""
        email = urllib.parse.quote(self.config.username)
        return f"https://caldav.fastmail.com/dav/calendars/user/{email}/"
