"""CalDAV providers for calendar-mcp."""

from __future__ import annotations

from .base import BaseProvider
from .generic import GenericProvider
from .google import GoogleProvider
from .apple import AppleProvider
from .nextcloud import NextcloudProvider
from .fastmail import FastmailProvider

PROVIDERS: dict[str, type[BaseProvider]] = {
    "google": GoogleProvider,
    "apple": AppleProvider,
    "nextcloud": NextcloudProvider,
    "fastmail": FastmailProvider,
    "radicale": GenericProvider,
    "baikal": GenericProvider,
    "outlook": GenericProvider,
    "generic": GenericProvider,
}


def get_provider(name: str) -> type[BaseProvider]:
    """Get a provider class by name. Falls back to GenericProvider."""
    return PROVIDERS.get(name, GenericProvider)


__all__ = [
    "BaseProvider",
    "GenericProvider",
    "GoogleProvider",
    "AppleProvider",
    "NextcloudProvider",
    "FastmailProvider",
    "PROVIDERS",
    "get_provider",
]
