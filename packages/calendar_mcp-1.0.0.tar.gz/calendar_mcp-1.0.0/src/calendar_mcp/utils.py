"""Utility functions for iCalendar (RFC 5545) parsing and formatting.

Handles VEVENT parsing, date/time formatting, timezone conversions,
and iCalendar generation — all without external dependencies beyond
the Python standard library.
"""

from __future__ import annotations

import re
import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Any


def generate_uid() -> str:
    """Generate a unique UID for a new calendar event."""
    return f"{uuid.uuid4()}@calendar-mcp"


def parse_datetime(value: str) -> datetime | date | None:
    """Parse an iCalendar date or datetime string.

    Supports formats:
        - 20260413T103000Z     (UTC datetime)
        - 20260413T103000      (local datetime)
        - 20260413             (date only, all-day event)
    """
    if not value:
        return None

    # Strip any TZID prefix (e.g., TZID=Europe/Vienna:20260413T103000)
    if ":" in value and not value.startswith("http"):
        value = value.rsplit(":", 1)[-1]

    value = value.strip()

    # Date only: YYYYMMDD
    if len(value) == 8 and value.isdigit():
        return date(int(value[:4]), int(value[4:6]), int(value[6:8]))

    # DateTime with Z suffix (UTC)
    if value.endswith("Z"):
        value = value[:-1]
        try:
            dt = datetime.strptime(value, "%Y%m%dT%H%M%S")
            return dt.replace(tzinfo=timezone.utc)
        except ValueError:
            return None

    # DateTime without timezone
    try:
        return datetime.strptime(value, "%Y%m%dT%H%M%S")
    except ValueError:
        return None


def format_datetime(dt: datetime | date | None) -> str:
    """Format a datetime/date into a human-readable string.

    Returns:
        - "2026-04-13" for all-day events
        - "2026-04-13 10:30" for timed events
        - "" if None
    """
    if dt is None:
        return ""
    if isinstance(dt, datetime):
        return dt.strftime("%Y-%m-%d %H:%M")
    return dt.strftime("%Y-%m-%d")


def format_ical_datetime(dt: datetime | date) -> str:
    """Format a datetime/date into iCalendar format.

    Returns:
        - "20260413" for dates
        - "20260413T103000Z" for UTC datetimes
        - "20260413T103000" for naive datetimes
    """
    if isinstance(dt, datetime):
        if dt.tzinfo is not None:
            utc_dt = dt.astimezone(timezone.utc)
            return utc_dt.strftime("%Y%m%dT%H%M%SZ")
        return dt.strftime("%Y%m%dT%H%M%S")
    return dt.strftime("%Y%m%d")


def parse_duration(value: str) -> timedelta | None:
    """Parse an iCalendar DURATION value (e.g., PT1H30M, P1D).

    Supports: P[n]D, PT[n]H[n]M[n]S, P[n]W
    """
    if not value:
        return None

    match = re.match(
        r"P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?",
        value,
    )
    if not match:
        return None

    weeks = int(match.group(1) or 0)
    days = int(match.group(2) or 0)
    hours = int(match.group(3) or 0)
    minutes = int(match.group(4) or 0)
    seconds = int(match.group(5) or 0)

    return timedelta(
        weeks=weeks, days=days, hours=hours, minutes=minutes, seconds=seconds
    )


def parse_rrule(rrule_str: str) -> dict[str, str]:
    """Parse an RRULE string into a dict of key-value pairs.

    Example: "FREQ=WEEKLY;BYDAY=MO,WE,FR;COUNT=10"
    -> {"FREQ": "WEEKLY", "BYDAY": "MO,WE,FR", "COUNT": "10"}
    """
    result: dict[str, str] = {}
    if not rrule_str:
        return result
    for part in rrule_str.split(";"):
        if "=" in part:
            key, val = part.split("=", 1)
            result[key.strip()] = val.strip()
    return result


def describe_rrule(rrule: dict[str, str]) -> str:
    """Create a human-readable description of a recurrence rule.

    Examples:
        - "Weekly on MO, WE, FR"
        - "Monthly, 10 occurrences"
        - "Daily until 2026-12-31"
    """
    if not rrule:
        return ""

    freq = rrule.get("FREQ", "").lower()
    parts = [freq.capitalize() if freq else "Recurring"]

    if "BYDAY" in rrule:
        parts.append(f"on {rrule['BYDAY']}")
    if "BYMONTHDAY" in rrule:
        parts.append(f"on day {rrule['BYMONTHDAY']}")
    if "COUNT" in rrule:
        parts.append(f"{rrule['COUNT']} occurrences")
    if "UNTIL" in rrule:
        until_dt = parse_datetime(rrule["UNTIL"])
        if until_dt:
            parts.append(f"until {format_datetime(until_dt)}")
    if "INTERVAL" in rrule and rrule["INTERVAL"] != "1":
        parts.insert(1, f"every {rrule['INTERVAL']}")

    return ", ".join(parts)


def extract_vevent_property(ical_text: str, prop: str) -> str:
    """Extract a single property value from a VEVENT block.

    Handles folded lines (continuation lines starting with space/tab).
    Returns empty string if property not found.
    """
    # Unfold: lines starting with space/tab are continuations
    unfolded = re.sub(r"\r?\n[ \t]", "", ical_text)

    for line in unfolded.split("\n"):
        line = line.strip()
        # Match property name (may have params like DTSTART;TZID=...)
        if line.upper().startswith(prop.upper() + ":") or line.upper().startswith(prop.upper() + ";"):
            # Get everything after the first ':'
            _, _, value = line.partition(":")
            return value.strip()

    return ""


def parse_vevent(ical_text: str) -> dict[str, Any]:
    """Parse a VEVENT block from iCalendar text into a structured dict.

    Returns a dict with: uid, summary, description, location, dtstart, dtend,
    all_day, duration, rrule, status, organizer, attendees.
    """
    uid = extract_vevent_property(ical_text, "UID")
    summary = extract_vevent_property(ical_text, "SUMMARY")
    description = extract_vevent_property(ical_text, "DESCRIPTION")
    location = extract_vevent_property(ical_text, "LOCATION")
    status = extract_vevent_property(ical_text, "STATUS")
    organizer = extract_vevent_property(ical_text, "ORGANIZER")

    dtstart_raw = extract_vevent_property(ical_text, "DTSTART")
    dtend_raw = extract_vevent_property(ical_text, "DTEND")
    duration_raw = extract_vevent_property(ical_text, "DURATION")
    rrule_raw = extract_vevent_property(ical_text, "RRULE")

    dtstart = parse_datetime(dtstart_raw)
    dtend = parse_datetime(dtend_raw)
    duration = parse_duration(duration_raw)

    # Determine if all-day event
    all_day = isinstance(dtstart, date) and not isinstance(dtstart, datetime)

    # If no DTEND but we have DURATION, calculate it
    if dtend is None and duration is not None and dtstart is not None:
        if isinstance(dtstart, datetime):
            dtend = dtstart + duration
        elif isinstance(dtstart, date):
            dtend = dtstart + duration

    # Parse recurrence
    rrule = parse_rrule(rrule_raw)
    recurrence = describe_rrule(rrule) if rrule else ""

    # Parse attendees
    attendees: list[str] = []
    unfolded = re.sub(r"\r?\n[ \t]", "", ical_text)
    for line in unfolded.split("\n"):
        if line.strip().upper().startswith("ATTENDEE"):
            # Extract mailto: or CN= value
            mailto_match = re.search(r"mailto:([^\s]+)", line, re.IGNORECASE)
            if mailto_match:
                attendees.append(mailto_match.group(1))
            else:
                cn_match = re.search(r'CN="?([^";]+)', line, re.IGNORECASE)
                if cn_match:
                    attendees.append(cn_match.group(1))

    # Clean organizer (extract email if mailto:)
    if organizer:
        mailto_match = re.search(r"mailto:(.+)", organizer, re.IGNORECASE)
        if mailto_match:
            organizer = mailto_match.group(1)

    # Unescape iCal text values
    description = _unescape_ical(description)
    summary = _unescape_ical(summary)
    location = _unescape_ical(location)

    return {
        "uid": uid,
        "summary": summary,
        "description": description,
        "location": location,
        "dtstart": format_datetime(dtstart),
        "dtend": format_datetime(dtend),
        "all_day": all_day,
        "duration_minutes": int(duration.total_seconds() / 60) if duration else None,
        "recurrence": recurrence,
        "rrule": rrule_raw,
        "status": status,
        "organizer": organizer,
        "attendees": attendees,
    }


def _unescape_ical(value: str) -> str:
    """Unescape iCalendar text values (RFC 5545 section 3.3.11)."""
    if not value:
        return value
    return (
        value.replace("\\n", "\n")
        .replace("\\N", "\n")
        .replace("\\,", ",")
        .replace("\\;", ";")
        .replace("\\\\", "\\")
    )


def _escape_ical(value: str) -> str:
    """Escape a string for inclusion in an iCalendar property value."""
    if not value:
        return value
    return (
        value.replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace("\n", "\\n")
    )


def build_vcalendar(events_ical: list[str]) -> str:
    """Wrap VEVENT blocks in a VCALENDAR container."""
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//breact//calendar-mcp//EN",
    ]
    for event in events_ical:
        lines.append(event)
    lines.append("END:VCALENDAR")
    return "\r\n".join(lines)


def build_vevent(
    summary: str,
    dtstart: datetime | date,
    dtend: datetime | date | None = None,
    description: str = "",
    location: str = "",
    uid: str | None = None,
    all_day: bool = False,
) -> str:
    """Build a VEVENT iCalendar block from structured data.

    Args:
        summary: Event title
        dtstart: Start date/time
        dtend: End date/time (defaults to dtstart + 1 hour or + 1 day for all-day)
        description: Event description
        location: Event location
        uid: Event UID (generated if not provided)
        all_day: Whether this is an all-day event
    """
    if uid is None:
        uid = generate_uid()

    # Default end time
    if dtend is None:
        if all_day or isinstance(dtstart, date) and not isinstance(dtstart, datetime):
            dtend = dtstart + timedelta(days=1)
        elif isinstance(dtstart, datetime):
            dtend = dtstart + timedelta(hours=1)

    now = datetime.now(timezone.utc)

    lines = [
        "BEGIN:VEVENT",
        f"UID:{uid}",
        f"DTSTAMP:{format_ical_datetime(now)}",
    ]

    if all_day and isinstance(dtstart, datetime):
        # Convert to date for all-day event
        lines.append(f"DTSTART;VALUE=DATE:{dtstart.strftime('%Y%m%d')}")
        if dtend and isinstance(dtend, datetime):
            lines.append(f"DTEND;VALUE=DATE:{dtend.strftime('%Y%m%d')}")
        elif dtend:
            lines.append(f"DTEND;VALUE=DATE:{format_ical_datetime(dtend)}")
    else:
        lines.append(f"DTSTART:{format_ical_datetime(dtstart)}")
        if dtend:
            lines.append(f"DTEND:{format_ical_datetime(dtend)}")

    lines.append(f"SUMMARY:{_escape_ical(summary)}")

    if description:
        lines.append(f"DESCRIPTION:{_escape_ical(description)}")
    if location:
        lines.append(f"LOCATION:{_escape_ical(location)}")

    lines.append("END:VEVENT")
    return "\r\n".join(lines)


def parse_iso_datetime(value: str) -> datetime | date:
    """Parse an ISO 8601 date or datetime string (user input).

    Supports:
        - 2026-04-13              (date)
        - 2026-04-13T10:30        (datetime without seconds)
        - 2026-04-13T10:30:00     (datetime with seconds)
        - 2026-04-13T10:30:00Z    (UTC)
        - 2026-04-13T10:30+02:00  (with offset)
    """
    value = value.strip()

    # Date only
    if len(value) == 10 and "-" in value:
        return date.fromisoformat(value)

    # Try standard fromisoformat (Python 3.11+ handles Z)
    try:
        # Handle Z suffix for older Python
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        return datetime.fromisoformat(value)
    except ValueError:
        pass

    # Fallback: try without seconds
    try:
        return datetime.strptime(value, "%Y-%m-%dT%H:%M")
    except ValueError:
        pass

    raise ValueError(f"Cannot parse datetime: {value!r}")


def events_in_range(
    events: list[dict[str, Any]],
    start: datetime | date,
    end: datetime | date,
) -> list[dict[str, Any]]:
    """Filter a list of parsed events to those overlapping a date range.

    Events with no parseable start date are excluded.
    """
    result: list[dict[str, Any]] = []
    for event in events:
        dtstart_str = event.get("dtstart", "")
        if not dtstart_str:
            continue

        # Parse the formatted datetime back
        try:
            if len(dtstart_str) == 10:
                event_start: datetime | date = date.fromisoformat(dtstart_str)
            else:
                event_start = datetime.fromisoformat(dtstart_str)
        except ValueError:
            continue

        # Normalize for comparison
        if isinstance(start, datetime) and isinstance(event_start, date) and not isinstance(event_start, datetime):
            event_start_cmp = datetime(event_start.year, event_start.month, event_start.day)
        else:
            event_start_cmp = event_start  # type: ignore[assignment]

        if isinstance(end, datetime) and isinstance(event_start, date) and not isinstance(event_start, datetime):
            event_start_cmp = datetime(event_start.year, event_start.month, event_start.day)

        # Simple overlap: event starts before range ends and after range starts
        try:
            if event_start_cmp >= start and event_start_cmp < end:  # type: ignore[operator]
                result.append(event)
        except TypeError:
            # Incomparable types (date vs datetime) — skip
            continue

    return result
