"""calendar-mcp: Provider-agnostic CalDAV calendar MCP server for AI assistants."""

__version__ = "1.0.0"
__all__ = ["__version__"]
