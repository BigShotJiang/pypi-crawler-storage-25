"""calendar-mcp server — provider-agnostic CalDAV calendar access via MCP.

Exposes 10 tools for reading and managing calendar events over CalDAV.
Uses the MCP SDK's FastMCP for clean tool registration.
Supports Google Calendar, Apple iCloud, Nextcloud, Fastmail, and any CalDAV server.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from .config import Config
from .providers import get_provider
from .providers.base import BaseProvider

# Global provider instance, initialized on first use
_provider: BaseProvider | None = None


def _get_provider() -> BaseProvider:
    """Get or create the CalDAV provider instance."""
    global _provider
    if _provider is None:
        config = Config.from_env()
        provider_cls = get_provider(config.provider)
        _provider = provider_cls(config)
    return _provider


def _get_config() -> Config:
    """Get the current config (from the provider)."""
    return _get_provider().config


# Create the FastMCP server
mcp = FastMCP(
    name="calendar-mcp",
    instructions=(
        "Calendar access tools for reading and managing CalDAV calendars. "
        "Supports Google Calendar, Apple iCloud, Nextcloud, Fastmail, "
        "and any standard CalDAV server. "
        "Provides event listing, search, creation, updates, and deletion."
    ),
)


def _json_result(data: dict[str, Any]) -> str:
    """Format a dict as a JSON string for tool output."""
    return json.dumps(data, indent=2, ensure_ascii=False)


@mcp.tool()
def list_calendars() -> str:
    """List all calendars available on the CalDAV account.

    Returns calendar names, URLs, and count.
    """
    provider = _get_provider()
    result = provider.list_calendars()
    return _json_result(result)


@mcp.tool()
def get_events(
    calendar_id: str = "",
    days_ahead: int = 7,
    days_back: int = 0,
    limit: int = 50,
) -> str:
    """Get events from a calendar within a date range.

    Args:
        calendar_id: Calendar name (default: first/configured calendar)
        days_ahead: Days into the future to fetch (default: 7)
        days_back: Days into the past to fetch (default: 0)
        limit: Maximum number of events (default: 50)
    """
    provider = _get_provider()
    result = provider.get_events(
        calendar_id=calendar_id,
        days_ahead=days_ahead,
        days_back=days_back,
        limit=limit,
    )
    return _json_result(result)


@mcp.tool()
def get_event(uid: str, calendar_id: str = "") -> str:
    """Get a single event by its UID.

    Args:
        uid: The event's unique identifier
        calendar_id: Calendar name (default: first/configured calendar)
    """
    provider = _get_provider()
    result = provider.get_event(uid=uid, calendar_id=calendar_id)
    return _json_result(result)


@mcp.tool()
def today(calendar_id: str = "") -> str:
    """Get all events for today.

    Args:
        calendar_id: Calendar name (default: first/configured calendar)
    """
    provider = _get_provider()
    result = provider.today(calendar_id=calendar_id)
    return _json_result(result)


@mcp.tool()
def upcoming(
    calendar_id: str = "",
    hours: int = 4,
    limit: int = 10,
) -> str:
    """Get upcoming events in the next N hours.

    Args:
        calendar_id: Calendar name (default: first/configured calendar)
        hours: Hours ahead to look (default: 4)
        limit: Maximum events to return (default: 10)
    """
    provider = _get_provider()
    result = provider.upcoming(
        calendar_id=calendar_id,
        hours=hours,
        limit=limit,
    )
    return _json_result(result)


@mcp.tool()
def search_events(
    query: str,
    calendar_id: str = "",
    days_ahead: int = 30,
    days_back: int = 30,
    limit: int = 20,
) -> str:
    """Search events by text in title, description, or location.

    Args:
        query: Search text (case-insensitive)
        calendar_id: Calendar name (default: first/configured calendar)
        days_ahead: Days into the future to search (default: 30)
        days_back: Days into the past to search (default: 30)
        limit: Maximum results (default: 20)
    """
    provider = _get_provider()
    result = provider.search_events(
        query=query,
        calendar_id=calendar_id,
        days_ahead=days_ahead,
        days_back=days_back,
        limit=limit,
    )
    return _json_result(result)


@mcp.tool()
def free_busy(calendar_id: str = "", days_ahead: int = 7) -> str:
    """Get a free/busy summary for the next N days.

    Shows busy time blocks and total free vs busy hours.

    Args:
        calendar_id: Calendar name (default: first/configured calendar)
        days_ahead: Days to look ahead (default: 7)
    """
    provider = _get_provider()
    result = provider.free_busy(
        calendar_id=calendar_id,
        days_ahead=days_ahead,
    )
    return _json_result(result)


@mcp.tool()
def create_event(
    summary: str,
    start: str,
    end: str = "",
    description: str = "",
    location: str = "",
    all_day: bool = False,
    calendar_id: str = "",
) -> str:
    """Create a new calendar event.

    Args:
        summary: Event title
        start: Start date/time in ISO 8601 (e.g., "2026-04-13T10:30" or "2026-04-13" for all-day)
        end: End date/time in ISO 8601 (default: start + 1 hour, or + 1 day for all-day)
        description: Event description
        location: Event location
        all_day: Whether this is an all-day event (default: false)
        calendar_id: Calendar name (default: first/configured calendar)
    """
    config = _get_config()
    if config.read_only:
        return _json_result({"error": "Server is in read-only mode"})
    provider = _get_provider()
    result = provider.create_event(
        summary=summary,
        start=start,
        end=end or None,
        description=description,
        location=location,
        all_day=all_day,
        calendar_id=calendar_id,
    )
    return _json_result(result)


@mcp.tool()
def update_event(
    uid: str,
    summary: str = "",
    start: str = "",
    end: str = "",
    description: str = "",
    location: str = "",
    calendar_id: str = "",
) -> str:
    """Update an existing calendar event. Only provided fields are changed.

    Args:
        uid: Event UID to update
        summary: New title (leave empty to keep current)
        start: New start date/time in ISO 8601
        end: New end date/time in ISO 8601
        description: New description
        location: New location
        calendar_id: Calendar name (default: first/configured calendar)
    """
    config = _get_config()
    if config.read_only:
        return _json_result({"error": "Server is in read-only mode"})
    provider = _get_provider()
    result = provider.update_event(
        uid=uid,
        summary=summary or None,
        start=start or None,
        end=end or None,
        description=description or None,
        location=location or None,
        calendar_id=calendar_id,
    )
    return _json_result(result)


@mcp.tool()
def delete_event(uid: str, calendar_id: str = "") -> str:
    """Delete a calendar event by its UID.

    Args:
        uid: Event UID to delete
        calendar_id: Calendar name (default: first/configured calendar)
    """
    config = _get_config()
    if config.read_only:
        return _json_result({"error": "Server is in read-only mode"})
    provider = _get_provider()
    result = provider.delete_event(uid=uid, calendar_id=calendar_id)
    return _json_result(result)


def main() -> None:
    """Entry point for the calendar-mcp server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
