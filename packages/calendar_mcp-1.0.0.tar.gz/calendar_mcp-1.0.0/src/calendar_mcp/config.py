"""Configuration management for calendar-mcp.

Reads settings from environment variables with CALENDAR_MCP_ prefix.
Auto-detects CalDAV provider from the server URL.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


# Provider detection: URL pattern -> provider name
URL_PROVIDER_MAP: dict[str, str] = {
    "google": "google",
    "googleapis": "google",
    "caldav.icloud.com": "apple",
    "icloud.com": "apple",
    "outlook.office365.com": "outlook",
    "outlook.live.com": "outlook",
    "nextcloud": "nextcloud",
    "owncloud": "nextcloud",
    "radicale": "radicale",
    "baikal": "baikal",
    "fastmail": "fastmail",
}

# Default CalDAV URLs per provider
PROVIDER_URLS: dict[str, str] = {
    "google": "https://apidata.googleusercontent.com/caldav/v2/",
    "apple": "https://caldav.icloud.com/",
    "outlook": "https://outlook.office365.com/caldav/v2/",
    "fastmail": "https://caldav.fastmail.com/dav/calendars/user/{email}/",
    "radicale": "",
    "baikal": "",
    "nextcloud": "",
    "generic": "",
}


def detect_provider(url: str) -> str:
    """Detect CalDAV provider from server URL.

    Returns provider name: 'google', 'apple', 'outlook', 'nextcloud',
    'radicale', 'baikal', 'fastmail', or 'generic'.
    """
    url_lower = url.lower()
    for pattern, provider in URL_PROVIDER_MAP.items():
        if pattern in url_lower:
            return provider
    return "generic"


@dataclass
class Config:
    """Server configuration loaded from environment variables."""

    url: str
    username: str
    password: str
    provider: str
    calendar_id: str
    read_only: bool
    default_timezone: str

    @classmethod
    def from_env(cls) -> Config:
        """Load configuration from environment variables.

        Required:
            CALENDAR_MCP_URL: CalDAV server URL
            CALENDAR_MCP_USERNAME: Username (usually email)
            CALENDAR_MCP_PASSWORD: Password or app-specific password

        Optional:
            CALENDAR_MCP_PROVIDER: Force provider detection (auto-detected from URL)
            CALENDAR_MCP_CALENDAR_ID: Default calendar ID/name (default: auto-discover first)
            CALENDAR_MCP_READ_ONLY: Set to 'true' for read-only mode (default: false)
            CALENDAR_MCP_TIMEZONE: Default timezone (default: UTC)
        """
        url = os.environ.get("CALENDAR_MCP_URL", "")
        username = os.environ.get("CALENDAR_MCP_USERNAME", "")
        password = os.environ.get("CALENDAR_MCP_PASSWORD", "")

        if not url:
            raise ValueError(
                "CALENDAR_MCP_URL environment variable is required. "
                "Set it to your CalDAV server URL."
            )
        if not username or not password:
            raise ValueError(
                "CALENDAR_MCP_USERNAME and CALENDAR_MCP_PASSWORD environment variables are required."
            )

        provider = os.environ.get("CALENDAR_MCP_PROVIDER", "") or detect_provider(url)
        calendar_id = os.environ.get("CALENDAR_MCP_CALENDAR_ID", "")
        read_only = os.environ.get("CALENDAR_MCP_READ_ONLY", "false").lower() in ("true", "1", "yes")
        default_timezone = os.environ.get("CALENDAR_MCP_TIMEZONE", "UTC")

        # Ensure URL ends with /
        if not url.endswith("/"):
            url += "/"

        return cls(
            url=url,
            username=username,
            password=password,
            provider=provider,
            calendar_id=calendar_id,
            read_only=read_only,
            default_timezone=default_timezone,
        )
