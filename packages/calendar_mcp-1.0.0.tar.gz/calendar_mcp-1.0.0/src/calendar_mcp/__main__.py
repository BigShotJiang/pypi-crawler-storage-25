"""Allow running as: python -m calendar_mcp"""

from .server import main

main()
