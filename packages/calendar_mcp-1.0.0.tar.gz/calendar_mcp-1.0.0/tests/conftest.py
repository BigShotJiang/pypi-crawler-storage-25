"""Pytest fixtures for calendar-mcp tests."""

from __future__ import annotations

import pytest

from calendar_mcp.config import Config
from calendar_mcp.providers.base import BaseProvider


@pytest.fixture
def config():
    """Create a test config."""
    return Config(
        url="https://caldav.example.com/",
        username="user@example.com",
        password="testpass",
        provider="generic",
        calendar_id="",
        read_only=False,
        default_timezone="UTC",
    )


@pytest.fixture
def readonly_config():
    """Create a read-only test config."""
    return Config(
        url="https://caldav.example.com/",
        username="user@example.com",
        password="testpass",
        provider="generic",
        calendar_id="",
        read_only=True,
        default_timezone="UTC",
    )


@pytest.fixture
def provider(config):
    """Create a test provider."""
    return BaseProvider(config)
