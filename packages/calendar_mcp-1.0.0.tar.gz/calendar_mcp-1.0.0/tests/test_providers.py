"""Tests for calendar_mcp.providers — provider detection and CalDAV operations."""

from __future__ import annotations

from unittest.mock import patch, MagicMock
import urllib.error

from calendar_mcp.config import Config, detect_provider, PROVIDER_URLS
from calendar_mcp.providers import get_provider, PROVIDERS
from calendar_mcp.providers.base import BaseProvider
from calendar_mcp.providers.google import GoogleProvider
from calendar_mcp.providers.apple import AppleProvider
from calendar_mcp.providers.nextcloud import NextcloudProvider
from calendar_mcp.providers.fastmail import FastmailProvider
from calendar_mcp.providers.generic import GenericProvider

from tests.fixtures import (
    SAMPLE_PROPFIND_HOME,
    SAMPLE_PROPFIND_CALENDARS,
    SAMPLE_REPORT_EVENTS,
    SAMPLE_VEVENT_TIMED,
)


class TestProviderDetection:
    def test_google(self):
        assert detect_provider("https://apidata.googleusercontent.com/caldav/v2/") == "google"

    def test_apple(self):
        assert detect_provider("https://caldav.icloud.com/123/") == "apple"

    def test_nextcloud(self):
        assert detect_provider("https://cloud.example.com/remote.php/dav/nextcloud") == "nextcloud"

    def test_fastmail(self):
        assert detect_provider("https://caldav.fastmail.com/dav/") == "fastmail"

    def test_generic(self):
        assert detect_provider("https://my-server.example.com/caldav/") == "generic"


class TestGetProvider:
    def test_google(self):
        assert get_provider("google") is GoogleProvider

    def test_apple(self):
        assert get_provider("apple") is AppleProvider

    def test_nextcloud(self):
        assert get_provider("nextcloud") is NextcloudProvider

    def test_fastmail(self):
        assert get_provider("fastmail") is FastmailProvider

    def test_generic(self):
        assert get_provider("generic") is GenericProvider

    def test_unknown_falls_back(self):
        assert get_provider("unknown") is GenericProvider


class TestConfigFromEnv:
    def test_required_fields(self):
        env = {
            "CALENDAR_MCP_URL": "https://caldav.example.com/",
            "CALENDAR_MCP_USERNAME": "user",
            "CALENDAR_MCP_PASSWORD": "pass",
        }
        with patch.dict("os.environ", env, clear=True):
            config = Config.from_env()
            assert config.url == "https://caldav.example.com/"
            assert config.username == "user"
            assert config.provider == "generic"
            assert config.read_only is False

    def test_auto_detect_google(self):
        env = {
            "CALENDAR_MCP_URL": "https://apidata.googleusercontent.com/caldav/v2/",
            "CALENDAR_MCP_USERNAME": "user@gmail.com",
            "CALENDAR_MCP_PASSWORD": "pass",
        }
        with patch.dict("os.environ", env, clear=True):
            config = Config.from_env()
            assert config.provider == "google"

    def test_read_only(self):
        env = {
            "CALENDAR_MCP_URL": "https://caldav.example.com/",
            "CALENDAR_MCP_USERNAME": "user",
            "CALENDAR_MCP_PASSWORD": "pass",
            "CALENDAR_MCP_READ_ONLY": "true",
        }
        with patch.dict("os.environ", env, clear=True):
            config = Config.from_env()
            assert config.read_only is True

    def test_missing_url_raises(self):
        import pytest
        with patch.dict("os.environ", {}, clear=True):
            with pytest.raises(ValueError, match="CALENDAR_MCP_URL"):
                Config.from_env()

    def test_trailing_slash_added(self):
        env = {
            "CALENDAR_MCP_URL": "https://caldav.example.com",
            "CALENDAR_MCP_USERNAME": "user",
            "CALENDAR_MCP_PASSWORD": "pass",
        }
        with patch.dict("os.environ", env, clear=True):
            config = Config.from_env()
            assert config.url.endswith("/")


class TestBaseProviderAuth:
    def test_auth_headers(self, provider):
        headers = provider._auth_headers()
        assert "Authorization" in headers
        assert headers["Authorization"].startswith("Basic ")
        assert "Content-Type" in headers


def _mock_request(responses):
    """Create a mock _request method that returns predefined responses."""
    call_count = [0]

    def mock_fn(method, url, body=None, extra_headers=None, content_type=None):
        idx = min(call_count[0], len(responses) - 1)
        call_count[0] += 1
        status, resp_body = responses[idx]
        return status, resp_body, {}

    return mock_fn


class TestBaseProviderCalendarDiscovery:
    def test_calendar_home_discovery(self, provider):
        provider._request = _mock_request([(207, SAMPLE_PROPFIND_HOME)])
        home = provider._calendar_home_url()
        assert home is not None
        assert "calendars/user@example.com" in home

    def test_calendar_home_failure(self, provider):
        provider._request = _mock_request([(401, "Unauthorized")])
        assert provider._calendar_home_url() is None

    def test_discover_calendars(self, provider):
        provider._request = _mock_request([(207, SAMPLE_PROPFIND_CALENDARS)])
        home = "https://caldav.example.com/calendars/user@example.com/"
        cals = provider._discover_calendars_from_home(home)
        assert len(cals) == 2
        names = [c["name"] for c in cals]
        assert "Personal" in names
        assert "Work" in names

    def test_list_calendars(self, provider):
        responses = [
            (207, SAMPLE_PROPFIND_HOME),
            (207, SAMPLE_PROPFIND_CALENDARS),
        ]
        provider._request = _mock_request(responses)
        result = provider.list_calendars()
        assert result["count"] == 2
        assert result["account"] == "user@example.com"


class TestBaseProviderEventOperations:
    def _setup_provider_with_events(self, provider):
        """Set up provider with mocked calendar discovery + events."""
        responses = [
            (207, SAMPLE_PROPFIND_HOME),
            (207, SAMPLE_PROPFIND_CALENDARS),
            (207, SAMPLE_REPORT_EVENTS),
        ]
        provider._request = _mock_request(responses)
        return provider

    def test_get_events(self, provider):
        provider = self._setup_provider_with_events(provider)
        result = provider.get_events(days_ahead=7, days_back=0)
        assert "events" in result
        assert result["count"] >= 0

    def test_today(self, provider):
        provider = self._setup_provider_with_events(provider)
        result = provider.today()
        assert "events" in result
        assert "date" in result

    def test_upcoming(self, provider):
        provider = self._setup_provider_with_events(provider)
        result = provider.upcoming(hours=4)
        assert "events" in result
        assert result["range_hours"] == 4

    def test_search_events(self, provider):
        provider = self._setup_provider_with_events(provider)
        result = provider.search_events("Standup")
        assert "events" in result
        assert "query" in result

    def test_get_event_by_uid(self, provider):
        responses = [
            (207, SAMPLE_PROPFIND_HOME),
            (207, SAMPLE_PROPFIND_CALENDARS),
            (207, SAMPLE_REPORT_EVENTS),
        ]
        provider._request = _mock_request(responses)
        result = provider.get_event("test-event-1@calendar-mcp")
        assert result.get("summary") == "Team Standup"

    def test_get_event_not_found(self, provider):
        responses = [
            (207, SAMPLE_PROPFIND_HOME),
            (207, SAMPLE_PROPFIND_CALENDARS),
            (207, SAMPLE_REPORT_EVENTS),
        ]
        provider._request = _mock_request(responses)
        result = provider.get_event("nonexistent-uid")
        assert "error" in result

    def test_free_busy(self, provider):
        provider = self._setup_provider_with_events(provider)
        result = provider.free_busy(days_ahead=7)
        assert "busy_hours" in result
        assert "free_hours" in result
        assert result["days"] == 7


class TestBaseProviderWriteOperations:
    def test_create_event(self, provider):
        responses = [
            (207, SAMPLE_PROPFIND_HOME),
            (207, SAMPLE_PROPFIND_CALENDARS),
            (201, ""),
        ]
        provider._request = _mock_request(responses)
        result = provider.create_event(
            summary="New Meeting",
            start="2026-04-13T10:00",
        )
        assert result.get("created") is True
        assert result["summary"] == "New Meeting"

    def test_create_event_failure(self, provider):
        responses = [
            (207, SAMPLE_PROPFIND_HOME),
            (207, SAMPLE_PROPFIND_CALENDARS),
            (403, "Forbidden"),
        ]
        provider._request = _mock_request(responses)
        result = provider.create_event(summary="Fail", start="2026-04-13T10:00")
        assert "error" in result

    def test_delete_event(self, provider):
        responses = [
            (207, SAMPLE_PROPFIND_HOME),
            (207, SAMPLE_PROPFIND_CALENDARS),
            (204, ""),
        ]
        provider._request = _mock_request(responses)
        result = provider.delete_event("some-uid")
        assert result.get("deleted") is True

    def test_delete_event_not_found(self, provider):
        responses = [
            (207, SAMPLE_PROPFIND_HOME),
            (207, SAMPLE_PROPFIND_CALENDARS),
            (404, "Not Found"),
        ]
        provider._request = _mock_request(responses)
        result = provider.delete_event("missing-uid")
        assert "error" in result


class TestReadOnlyMode:
    def test_create_blocked(self, readonly_config):
        provider = BaseProvider(readonly_config)
        # Read-only is enforced at the server.py level, not provider level
        # But we test that config is accessible
        assert provider.config.read_only is True
