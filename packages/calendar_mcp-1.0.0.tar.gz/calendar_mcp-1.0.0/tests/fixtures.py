"""Shared test fixtures and sample data for calendar-mcp tests."""

SAMPLE_VEVENT_TIMED = """\
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//Test//EN
BEGIN:VEVENT
UID:test-event-1@calendar-mcp
DTSTART:20260413T103000Z
DTEND:20260413T113000Z
SUMMARY:Team Standup
DESCRIPTION:Daily standup meeting
LOCATION:Conference Room A
STATUS:CONFIRMED
ORGANIZER:mailto:boss@example.com
ATTENDEE;CN=Alice:mailto:alice@example.com
ATTENDEE;CN=Bob:mailto:bob@example.com
END:VEVENT
END:VCALENDAR"""

SAMPLE_VEVENT_ALLDAY = """\
BEGIN:VCALENDAR
VERSION:2.0
BEGIN:VEVENT
UID:test-event-2@calendar-mcp
DTSTART;VALUE=DATE:20260413
DTEND;VALUE=DATE:20260414
SUMMARY:Company Holiday
DESCRIPTION:Easter Monday
END:VEVENT
END:VCALENDAR"""

SAMPLE_VEVENT_RECURRING = """\
BEGIN:VCALENDAR
VERSION:2.0
BEGIN:VEVENT
UID:test-event-3@calendar-mcp
DTSTART:20260413T090000Z
DTEND:20260413T093000Z
SUMMARY:Weekly Review
RRULE:FREQ=WEEKLY;BYDAY=MO;COUNT=10
LOCATION:Office
END:VEVENT
END:VCALENDAR"""

SAMPLE_VEVENT_DURATION = """\
BEGIN:VCALENDAR
VERSION:2.0
BEGIN:VEVENT
UID:test-event-4@calendar-mcp
DTSTART:20260413T140000Z
DURATION:PT1H30M
SUMMARY:Workshop
END:VEVENT
END:VCALENDAR"""

SAMPLE_VEVENT_ESCAPED = """\
BEGIN:VCALENDAR
VERSION:2.0
BEGIN:VEVENT
UID:test-event-5@calendar-mcp
DTSTART:20260413T160000Z
DTEND:20260413T170000Z
SUMMARY:Meeting\\, with commas\\; and semicolons
DESCRIPTION:Line 1\\nLine 2\\nLine 3
LOCATION:Room\\, Floor 3
END:VEVENT
END:VCALENDAR"""

SAMPLE_PROPFIND_HOME = """\
<?xml version="1.0" encoding="UTF-8"?>
<d:multistatus xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">
  <d:response>
    <d:href>/principals/user@example.com/</d:href>
    <d:propstat>
      <d:prop>
        <c:calendar-home-set>
          <d:href>/calendars/user@example.com/</d:href>
        </c:calendar-home-set>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>"""

SAMPLE_PROPFIND_CALENDARS = """\
<?xml version="1.0" encoding="UTF-8"?>
<d:multistatus xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"
               xmlns:cs="http://calendarserver.org/ns/">
  <d:response>
    <d:href>/calendars/user@example.com/</d:href>
    <d:propstat>
      <d:prop>
        <d:displayname>Calendar Home</d:displayname>
        <d:resourcetype><d:collection/></d:resourcetype>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
  <d:response>
    <d:href>/calendars/user@example.com/personal/</d:href>
    <d:propstat>
      <d:prop>
        <d:displayname>Personal</d:displayname>
        <d:resourcetype><d:collection/><c:calendar/></d:resourcetype>
        <cs:getctag>abc123</cs:getctag>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
  <d:response>
    <d:href>/calendars/user@example.com/work/</d:href>
    <d:propstat>
      <d:prop>
        <d:displayname>Work</d:displayname>
        <d:resourcetype><d:collection/><c:calendar/></d:resourcetype>
        <cs:getctag>def456</cs:getctag>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>"""

SAMPLE_REPORT_EVENTS = f"""\
<?xml version="1.0" encoding="UTF-8"?>
<d:multistatus xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">
  <d:response>
    <d:href>/calendars/user@example.com/personal/event1.ics</d:href>
    <d:propstat>
      <d:prop>
        <d:getetag>"etag1"</d:getetag>
        <c:calendar-data>{SAMPLE_VEVENT_TIMED}</c:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
  <d:response>
    <d:href>/calendars/user@example.com/personal/event2.ics</d:href>
    <d:propstat>
      <d:prop>
        <d:getetag>"etag2"</d:getetag>
        <c:calendar-data>{SAMPLE_VEVENT_ALLDAY}</c:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>"""
