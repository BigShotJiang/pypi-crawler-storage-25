"""Tests for calendar_mcp.server — MCP tool registration and execution."""

from __future__ import annotations

import json
from unittest.mock import patch, MagicMock

from calendar_mcp.server import mcp, _json_result
from calendar_mcp.config import Config
from calendar_mcp.providers.base import BaseProvider

from tests.fixtures import (
    SAMPLE_PROPFIND_HOME,
    SAMPLE_PROPFIND_CALENDARS,
    SAMPLE_REPORT_EVENTS,
)


def _mock_responses(responses):
    """Create mock _request for provider."""
    call_count = [0]

    def mock_fn(method, url, body=None, extra_headers=None, content_type=None):
        idx = min(call_count[0], len(responses) - 1)
        call_count[0] += 1
        status, resp_body = responses[idx]
        return status, resp_body, {}

    return mock_fn


def _get_mock_provider():
    """Create a provider with mocked HTTP."""
    config = Config(
        url="https://caldav.example.com/",
        username="user@example.com",
        password="testpass",
        provider="generic",
        calendar_id="",
        read_only=False,
        default_timezone="UTC",
    )
    provider = BaseProvider(config)
    provider._request = _mock_responses([
        (207, SAMPLE_PROPFIND_HOME),
        (207, SAMPLE_PROPFIND_CALENDARS),
        (207, SAMPLE_REPORT_EVENTS),
    ])
    return provider


def _get_readonly_provider():
    """Create a read-only provider."""
    config = Config(
        url="https://caldav.example.com/",
        username="user@example.com",
        password="testpass",
        provider="generic",
        calendar_id="",
        read_only=True,
        default_timezone="UTC",
    )
    return BaseProvider(config)


class TestToolRegistration:
    def test_all_tools_registered(self):
        tool_names = [t.name for t in mcp._tool_manager.list_tools()]
        expected = [
            "list_calendars",
            "get_events",
            "get_event",
            "today",
            "upcoming",
            "search_events",
            "free_busy",
            "create_event",
            "update_event",
            "delete_event",
        ]
        for name in expected:
            assert name in tool_names, f"Tool '{name}' not registered"

    def test_tool_count(self):
        tools = mcp._tool_manager.list_tools()
        assert len(tools) == 10


class TestJsonResult:
    def test_formats_dict(self):
        result = _json_result({"key": "value", "num": 42})
        parsed = json.loads(result)
        assert parsed["key"] == "value"
        assert parsed["num"] == 42

    def test_unicode(self):
        result = _json_result({"text": "Besprechung für Überprüfung"})
        assert "Besprechung" in result
        assert "\\u" not in result


class TestToolExecution:
    def test_list_calendars(self):
        import calendar_mcp.server as srv
        srv._provider = _get_mock_provider()
        try:
            result = json.loads(srv.list_calendars())
            assert "calendars" in result
            assert result["count"] == 2
        finally:
            srv._provider = None

    def test_get_events(self):
        import calendar_mcp.server as srv
        srv._provider = _get_mock_provider()
        try:
            result = json.loads(srv.get_events())
            assert "events" in result
        finally:
            srv._provider = None

    def test_today(self):
        import calendar_mcp.server as srv
        srv._provider = _get_mock_provider()
        try:
            result = json.loads(srv.today())
            assert "events" in result
            assert "date" in result
        finally:
            srv._provider = None

    def test_upcoming(self):
        import calendar_mcp.server as srv
        srv._provider = _get_mock_provider()
        try:
            result = json.loads(srv.upcoming())
            assert "events" in result
            assert result["range_hours"] == 4
        finally:
            srv._provider = None

    def test_search_events(self):
        import calendar_mcp.server as srv
        srv._provider = _get_mock_provider()
        try:
            result = json.loads(srv.search_events("Standup"))
            assert "events" in result
            assert result["query"] == "Standup"
        finally:
            srv._provider = None

    def test_free_busy(self):
        import calendar_mcp.server as srv
        srv._provider = _get_mock_provider()
        try:
            result = json.loads(srv.free_busy())
            assert "busy_hours" in result
            assert "free_hours" in result
        finally:
            srv._provider = None


class TestReadOnlyMode:
    def test_create_blocked(self):
        import calendar_mcp.server as srv
        srv._provider = _get_readonly_provider()
        try:
            result = json.loads(srv.create_event(summary="Test", start="2026-04-13T10:00"))
            assert result["error"] == "Server is in read-only mode"
        finally:
            srv._provider = None

    def test_update_blocked(self):
        import calendar_mcp.server as srv
        srv._provider = _get_readonly_provider()
        try:
            result = json.loads(srv.update_event(uid="test-uid"))
            assert result["error"] == "Server is in read-only mode"
        finally:
            srv._provider = None

    def test_delete_blocked(self):
        import calendar_mcp.server as srv
        srv._provider = _get_readonly_provider()
        try:
            result = json.loads(srv.delete_event(uid="test-uid"))
            assert result["error"] == "Server is in read-only mode"
        finally:
            srv._provider = None
