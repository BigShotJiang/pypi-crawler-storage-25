"""Tests for calendar_mcp.utils — iCalendar parsing and formatting."""

from datetime import date, datetime, timedelta, timezone

from calendar_mcp.utils import (
    build_vcalendar,
    build_vevent,
    describe_rrule,
    extract_vevent_property,
    format_datetime,
    format_ical_datetime,
    generate_uid,
    parse_datetime,
    parse_duration,
    parse_iso_datetime,
    parse_rrule,
    parse_vevent,
    events_in_range,
)

from tests.fixtures import SAMPLE_VEVENT_TIMED, SAMPLE_VEVENT_ALLDAY, SAMPLE_VEVENT_RECURRING, SAMPLE_VEVENT_DURATION, SAMPLE_VEVENT_ESCAPED


class TestGenerateUid:
    def test_unique(self):
        assert generate_uid() != generate_uid()

    def test_format(self):
        uid = generate_uid()
        assert "@calendar-mcp" in uid


class TestParseDateTime:
    def test_utc_datetime(self):
        result = parse_datetime("20260413T103000Z")
        assert isinstance(result, datetime)
        assert result.year == 2026
        assert result.month == 4
        assert result.hour == 10
        assert result.minute == 30
        assert result.tzinfo == timezone.utc

    def test_local_datetime(self):
        result = parse_datetime("20260413T103000")
        assert isinstance(result, datetime)
        assert result.tzinfo is None

    def test_date_only(self):
        result = parse_datetime("20260413")
        assert isinstance(result, date)
        assert not isinstance(result, datetime)
        assert result == date(2026, 4, 13)

    def test_with_tzid_prefix(self):
        result = parse_datetime("TZID=Europe/Vienna:20260413T103000")
        assert isinstance(result, datetime)
        assert result.hour == 10

    def test_empty(self):
        assert parse_datetime("") is None

    def test_invalid(self):
        assert parse_datetime("not-a-date") is None


class TestFormatDatetime:
    def test_datetime(self):
        dt = datetime(2026, 4, 13, 10, 30)
        assert format_datetime(dt) == "2026-04-13 10:30"

    def test_date(self):
        d = date(2026, 4, 13)
        assert format_datetime(d) == "2026-04-13"

    def test_none(self):
        assert format_datetime(None) == ""


class TestFormatIcalDatetime:
    def test_utc_datetime(self):
        dt = datetime(2026, 4, 13, 10, 30, tzinfo=timezone.utc)
        assert format_ical_datetime(dt) == "20260413T103000Z"

    def test_naive_datetime(self):
        dt = datetime(2026, 4, 13, 10, 30)
        assert format_ical_datetime(dt) == "20260413T103000"

    def test_date(self):
        d = date(2026, 4, 13)
        assert format_ical_datetime(d) == "20260413"


class TestParseDuration:
    def test_hours_minutes(self):
        result = parse_duration("PT1H30M")
        assert result == timedelta(hours=1, minutes=30)

    def test_days(self):
        result = parse_duration("P1D")
        assert result == timedelta(days=1)

    def test_weeks(self):
        result = parse_duration("P2W")
        assert result == timedelta(weeks=2)

    def test_seconds(self):
        result = parse_duration("PT30S")
        assert result == timedelta(seconds=30)

    def test_complex(self):
        result = parse_duration("P1DT2H30M")
        assert result == timedelta(days=1, hours=2, minutes=30)

    def test_empty(self):
        assert parse_duration("") is None

    def test_invalid(self):
        assert parse_duration("invalid") is None


class TestParseRrule:
    def test_weekly(self):
        result = parse_rrule("FREQ=WEEKLY;BYDAY=MO,WE,FR;COUNT=10")
        assert result["FREQ"] == "WEEKLY"
        assert result["BYDAY"] == "MO,WE,FR"
        assert result["COUNT"] == "10"

    def test_daily(self):
        result = parse_rrule("FREQ=DAILY;INTERVAL=2")
        assert result["FREQ"] == "DAILY"
        assert result["INTERVAL"] == "2"

    def test_empty(self):
        assert parse_rrule("") == {}


class TestDescribeRrule:
    def test_weekly_with_days(self):
        rrule = {"FREQ": "WEEKLY", "BYDAY": "MO,WE,FR"}
        result = describe_rrule(rrule)
        assert "Weekly" in result
        assert "MO,WE,FR" in result

    def test_monthly_with_count(self):
        rrule = {"FREQ": "MONTHLY", "COUNT": "12"}
        result = describe_rrule(rrule)
        assert "Monthly" in result
        assert "12 occurrences" in result

    def test_with_interval(self):
        rrule = {"FREQ": "DAILY", "INTERVAL": "3"}
        result = describe_rrule(rrule)
        assert "every 3" in result

    def test_empty(self):
        assert describe_rrule({}) == ""


class TestExtractVeventProperty:
    def test_summary(self):
        result = extract_vevent_property(SAMPLE_VEVENT_TIMED, "SUMMARY")
        assert result == "Team Standup"

    def test_uid(self):
        result = extract_vevent_property(SAMPLE_VEVENT_TIMED, "UID")
        assert result == "test-event-1@calendar-mcp"

    def test_missing(self):
        result = extract_vevent_property(SAMPLE_VEVENT_TIMED, "NONEXISTENT")
        assert result == ""

    def test_with_params(self):
        result = extract_vevent_property(SAMPLE_VEVENT_ALLDAY, "DTSTART")
        assert result == "20260413"


class TestParseVevent:
    def test_timed_event(self):
        result = parse_vevent(SAMPLE_VEVENT_TIMED)
        assert result["uid"] == "test-event-1@calendar-mcp"
        assert result["summary"] == "Team Standup"
        assert result["description"] == "Daily standup meeting"
        assert result["location"] == "Conference Room A"
        assert result["status"] == "CONFIRMED"
        assert result["all_day"] is False
        assert "2026-04-13 10:30" in result["dtstart"]
        assert "2026-04-13 11:30" in result["dtend"]

    def test_allday_event(self):
        result = parse_vevent(SAMPLE_VEVENT_ALLDAY)
        assert result["uid"] == "test-event-2@calendar-mcp"
        assert result["summary"] == "Company Holiday"
        assert result["all_day"] is True
        assert result["dtstart"] == "2026-04-13"

    def test_recurring_event(self):
        result = parse_vevent(SAMPLE_VEVENT_RECURRING)
        assert result["summary"] == "Weekly Review"
        assert "Weekly" in result["recurrence"]
        assert "MO" in result["recurrence"]
        assert result["rrule"] == "FREQ=WEEKLY;BYDAY=MO;COUNT=10"

    def test_duration_event(self):
        result = parse_vevent(SAMPLE_VEVENT_DURATION)
        assert result["summary"] == "Workshop"
        assert result["duration_minutes"] == 90
        assert result["dtend"] != ""

    def test_escaped_values(self):
        result = parse_vevent(SAMPLE_VEVENT_ESCAPED)
        assert "," in result["summary"]
        assert ";" in result["summary"]
        assert "\n" in result["description"]
        assert "," in result["location"]

    def test_attendees(self):
        result = parse_vevent(SAMPLE_VEVENT_TIMED)
        assert "alice@example.com" in result["attendees"]
        assert "bob@example.com" in result["attendees"]

    def test_organizer(self):
        result = parse_vevent(SAMPLE_VEVENT_TIMED)
        assert result["organizer"] == "boss@example.com"


class TestParseIsoDatetime:
    def test_date(self):
        result = parse_iso_datetime("2026-04-13")
        assert result == date(2026, 4, 13)

    def test_datetime_no_seconds(self):
        result = parse_iso_datetime("2026-04-13T10:30")
        assert isinstance(result, datetime)
        assert result.hour == 10
        assert result.minute == 30

    def test_datetime_with_seconds(self):
        result = parse_iso_datetime("2026-04-13T10:30:00")
        assert isinstance(result, datetime)

    def test_utc(self):
        result = parse_iso_datetime("2026-04-13T10:30:00Z")
        assert isinstance(result, datetime)
        assert result.tzinfo is not None

    def test_invalid_raises(self):
        import pytest
        with pytest.raises(ValueError):
            parse_iso_datetime("not-a-date")


class TestBuildVevent:
    def test_basic(self):
        dt = datetime(2026, 4, 13, 10, 30, tzinfo=timezone.utc)
        result = build_vevent("Test Event", dt, uid="test-uid")
        assert "SUMMARY:Test Event" in result
        assert "UID:test-uid" in result
        assert "DTSTART:20260413T103000Z" in result

    def test_with_description_and_location(self):
        dt = datetime(2026, 4, 13, 10, 0, tzinfo=timezone.utc)
        result = build_vevent("Meeting", dt, description="Notes here", location="Room 1", uid="uid1")
        assert "DESCRIPTION:Notes here" in result
        assert "LOCATION:Room 1" in result

    def test_allday(self):
        dt = datetime(2026, 4, 13, 0, 0, tzinfo=timezone.utc)
        result = build_vevent("Holiday", dt, all_day=True, uid="uid2")
        assert "VALUE=DATE:20260413" in result

    def test_default_end_timed(self):
        dt = datetime(2026, 4, 13, 10, 0, tzinfo=timezone.utc)
        result = build_vevent("Test", dt, uid="uid3")
        assert "DTEND:20260413T110000Z" in result

    def test_escaping(self):
        dt = datetime(2026, 4, 13, 10, 0, tzinfo=timezone.utc)
        result = build_vevent("Meeting, important; urgent", dt, uid="uid4")
        assert "\\," in result
        assert "\\;" in result


class TestBuildVcalendar:
    def test_wraps_events(self):
        result = build_vcalendar(["BEGIN:VEVENT\r\nEND:VEVENT"])
        assert result.startswith("BEGIN:VCALENDAR")
        assert result.endswith("END:VCALENDAR")
        assert "PRODID:-//breact//calendar-mcp//EN" in result
        assert "BEGIN:VEVENT" in result


class TestEventsInRange:
    def test_filters_correctly(self):
        events = [
            {"dtstart": "2026-04-13 10:00", "summary": "In range"},
            {"dtstart": "2026-04-10 10:00", "summary": "Before range"},
            {"dtstart": "2026-04-20 10:00", "summary": "After range"},
        ]
        start = datetime(2026, 4, 12, 0, 0)
        end = datetime(2026, 4, 15, 0, 0)
        result = events_in_range(events, start, end)
        assert len(result) == 1
        assert result[0]["summary"] == "In range"

    def test_empty_dtstart(self):
        events = [{"dtstart": "", "summary": "No date"}]
        start = datetime(2026, 4, 12, 0, 0)
        end = datetime(2026, 4, 15, 0, 0)
        assert events_in_range(events, start, end) == []

    def test_date_range(self):
        events = [{"dtstart": "2026-04-13", "summary": "All day"}]
        start = date(2026, 4, 12)
        end = date(2026, 4, 15)
        result = events_in_range(events, start, end)
        assert len(result) == 1
