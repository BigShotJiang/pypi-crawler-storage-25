# Changelog

## 1.0.0 (2026-04-13)

- Initial release
- 10 CalDAV calendar tools (list, get, search, create, update, delete, free/busy)
- 6 providers: Google, Apple iCloud, Nextcloud, Fastmail, Radicale/Baikal, generic CalDAV
- RFC 5545 iCalendar parsing (recurrence rules, durations, timezones, attendees)
- Read-only mode
- AGPL-3.0 + commercial dual-license
- 99 tests passing
