"""This finds all elements related to the specified element by the specified relationship type,
that match the property value for the properties specified"""

import argparse
import os
import sys
import time

from jedi import Project
from rich import box
from rich.console import Console
from rich.markdown import Markdown
from rich.prompt import Prompt
from rich.table import Table

from pyegeria import (
    PyegeriaException,
    print_basic_exception,
    config_logging,
    EgeriaTech,
    settings,
    EgeriaTech,
    settings,
    settings,
    EgeriaTech,
    PyegeriaException,
    ValidMetadataManager,
    print_basic_exception,
    config_logging
)

EGERIA_USER = os.environ.get("EGERIA_USER", "erinoverview")
EGERIA_USER_PASSWORD = os.environ.get("EGERIA_USER_PASSWORD", "secret")

app_config = settings.Environment
config_logging()
console = Console(width=settings.Environment.egeria_width)


def list_related_elements_with_prop_value(
    element_guid: str,
    relationship_type: str,
    property_value: str,
    property_names: [str],
    om_type: str,
    server: str,
    url: str,
    username: str,
    password: str,
    jupyter: bool = settings.Environment.egeria_jupyter,
    width: int = settings.Environment.egeria_width,
):
    c_client = EgeriaTech(server, url, user_id=username, user_pwd=password)
    token = c_client.create_egeria_bearer_token()

    if om_type is not None:
        om_typedef = c_client.get_typedef_by_name(om_type)
        if type(om_typedef) is str:
            print(
                f"The type name '{om_type}' is not known to the Egeria platform at {url} - {server}"
            )
            sys.exit(1)

    def generate_table() -> Table:
        """Make a new table."""
        table = Table(
            caption=f"Metadata Elements for: {url} - {server} @ {time.asctime()}",
            style="bold bright_white on black",
            row_styles=["bold bright_white on black"],
            header_style="white on dark_blue",
            title_style="bold bright_white on black",
            caption_style="white on black",
            show_lines=True,
            box=box.ROUNDED,
            title=f"Elements related to: '{element_guid}' ",
            expand=True,
            # width=500
        )
        table.add_column("Relationship GUID", width=38, no_wrap=True)
        table.add_column("Rel Header", width=38, no_wrap=True)
        table.add_column("Relationship Props")
        table.add_column("Related GUID", width=38, no_wrap=True)
        table.add_column("Properties")
        table.add_column("Element Header")

        elements = c_client.get_related_elements(
            element_guid, relationship_type, om_type
        )

        if type(elements) is list:
            for element in elements:
                header = element["relationshipHeader"]
                el_type = header["type"]["typeName"]
                el_home = header["origin"]["homeMetadataCollectionName"]
                el_create_time = header["versions"]["createTime"][:-10]
                el_guid = header["guid"]
                el_class = header.get("classifications", "---")
                rel_header_md = (
                    f"* Type: {el_type}\n"
                    f"* Home: {el_home}\n"
                    f"* Created: {el_create_time}\n"
                )
                rel_header_out = Markdown(rel_header_md)
                rel_props = element.get("relationshipProperties", "---")

                rel_props_md = ""
                if type(rel_props) is list:
                    for prop in rel_props.keys():
                        rel_props_md += (
                            f"* **{prop}**: {element['relationshipProperties'][prop]}\n"
                        )
                rel_props_out = Markdown(rel_props_md)

                c_md = ""
                if type(el_class) is list:
                    for classification in el_class:
                        classification_name = classification.get(
                            "classificationName", "---"
                        )
                        c_md = f"* **{classification_name}**\n"
                        class_props = classification.get(
                            "classificationProperties", "---"
                        )
                        if type(class_props) is dict:
                            for prop in class_props.keys():
                                c_md += f"  * **{prop}**: {class_props[prop]}\n"
                c_md_out = Markdown(c_md)

                rel_element = element["relatedElement"]
                rel_el_header = rel_element["elementHeader"]
                rel_type = rel_el_header["type"]["typeName"]
                rel_home = rel_el_header["origin"]["homeMetadataCollectionName"]
                rel_guid = rel_el_header["guid"]

                rel_el_header_md = f"* Type: {rel_type}\n" f"* Home: {rel_home}\n"
                rel_el_header_out = Markdown(rel_el_header_md)

                rel_el_props_md = ""
                for prop in rel_element["properties"].keys():
                    rel_el_props_md += (
                        f"* **{prop}**: {rel_element['properties'][prop]}\n"
                    )
                rel_el_props_out = Markdown(rel_el_props_md)

                table.add_row(
                    el_guid,
                    rel_header_out,
                    rel_props_out,
                    # el_q_name,
                    rel_guid,
                    rel_el_props_out,
                    rel_el_header_out,
                )

            return table
        else:
            print("No instances found")
            sys.exit(1)

    try:
        console = Console(width=width, force_terminal=not jupyter)

        with console.pager(styles=True):
            console.print(generate_table())

    except (
        PyegeriaException
    ) as e:
        print_basic_exception(e)
        print("\n\nPerhaps the type name isn't known")
    finally:
        c_client.close_session()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", help="Name of the server to display status for")
    parser.add_argument("--url", help="URL Platform to connect to")
    parser.add_argument("--userid", help="User Id")
    parser.add_argument("--password", help="Password")

    args = parser.parse_args()

    server = args.server.strip() if args.server is not None else app_config.egeria_view_server
    url = args.url.strip if args.url is not None else app_config.egeria_platform_url
    userid = args.userid.strip() if args.userid is not None else EGERIA_USER
    password = (
        args.password.strip() if args.password is not None else EGERIA_USER_PASSWORD
    )

    try:
        element_guid = Prompt.ask("Guid of base element").strip()
        relationship_type = Prompt.ask("Enter the relationship type to follow").strip()
        property_value = Prompt.ask("Enter the property value to search for").strip()
        property_names = Prompt.ask(
            "Enter a comma seperated list of properties to search"
        ).strip()
        om_type = Prompt.ask(
            "Enter the Open Metadata Type to find elements of", default="Referenceable"
        )
        om_type = om_type.strip() if type(om_type) is str else None
        list_related_elements_with_prop_value(
            element_guid,
            relationship_type,
            property_value,
            [property_names],
            om_type,
            server,
            url,
            userid,
            password,
        )
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
