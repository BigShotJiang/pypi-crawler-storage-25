#!/usr/bin/env python3
"""
SPDX-License-Identifier: Apache-2.0
Copyright Contributors to the ODPi Egeria project.

Display Asset Graph Information using generic functions.
"""
from __future__ import annotations
import argparse
import os

from rich.console import Console
from rich.prompt import Prompt

from commands.cat.run_report import list_generic
from pyegeria.core.config import settings
from pyegeria import (
    PyegeriaException,
    print_basic_exception,
    settings,
    settings,
    PyegeriaAPIException, PyegeriaClientException, print_basic_exception, print_exception_table, PyegeriaException
)

EGERIA_USER = os.environ.get("EGERIA_USER", "erinoverview")
EGERIA_USER_PASSWORD = os.environ.get("EGERIA_USER_PASSWORD", "secret")


app_config = settings.Environment

guid_list = []

console = Console(width=settings.Environment.egeria_width, force_terminal=(not app_config.egeria_jupyter))


def asset_viewer(asset_guid: str, output_format: str = "TABLE", view_server: str = app_config.egeria_view_server,
                 view_url: str = app_config.egeria_view_server_url, user: str = EGERIA_USER,
                 user_pass: str = EGERIA_USER_PASSWORD, jupyter: bool = settings.Environment.egeria_jupyter,
                 width: int = settings.Environment.egeria_width, prompt_missing: bool = False, write_file: bool = False,
                 render_table: bool = False, table_caption: str | None = None, use_pager: bool = True):
    try:
        list_generic(report_spec="Asset-Graph", output_format=output_format, view_server=view_server,
                 view_url=view_url, user=user, user_pass=user_pass, params={"asset_guid": asset_guid},
                 render_table=render_table, write_file = write_file, table_caption=table_caption, use_pager=use_pager,
                     width=width, jupyter=jupyter, prompt_missing=prompt_missing)

    except PyegeriaAPIException as e:
        if e.response_egeria_msg_id == "OMAG-REPOSITORY-HANDLER-404-001":
            print(e.response_egeria_msg)
            return

    except (PyegeriaException, PyegeriaClientException) as e:
        print_basic_exception(e)


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--server", help="Name of the server to display status for")
    parser.add_argument("--url", help="URL Platform to connect to")
    parser.add_argument("--userid", help="User Id")
    parser.add_argument("--password", help="User Password")
    args = parser.parse_args()

    server = args.server if args.server is not None else app_config.egeria_view_server
    url = args.url if args.url is not None else app_config.egeria_view_server_url
    userid = args.userid if args.userid is not None else EGERIA_USER
    user_pass = args.password if args.password is not None else EGERIA_USER_PASSWORD
    try:
        asset_guid = Prompt.ask("Enter the Asset GUID to view:", default="")
        output_format = Prompt.ask("Enter the output format:", default="TABLE")
        asset_viewer(asset_guid, output_format, server, url, userid, user_pass, prompt_missing=True, write_file=True,
                     render_table=True, table_caption="Asset Graph")
    except KeyboardInterrupt as e:
        # console.print_exception()
        pass
    except Exception as e:
        console.print_exception()


if __name__ == "__main__":
    main()
